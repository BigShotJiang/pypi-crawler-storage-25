"""Human-readable optimisation report generator with section-based rendering."""

from __future__ import annotations

import textwrap
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol

from sparktimise.types import AnalysisResult, PipelineRun

_LINE_WIDTH: int = 120

_MODE_LABELS: dict[str, str] = {
    "baseline": "BASELINE  —  Analysis only, no transformations applied",
    "optimised": "OPTIMISED  —  Transformations applied automatically",
    "report_only": "REPORT ONLY  —  Manually optimised pipeline, metrics captured",
}

_IMPACT_ORDER: dict[str, int] = {"high": 3, "medium": 2, "low": 1}
_CONFIDENCE_ORDER: dict[str, int] = {"high": 3, "medium": 2, "low": 1}


# ---------------------------------------------------------------------------
# Section protocol and helpers
# ---------------------------------------------------------------------------


class ReportSection(Protocol):
    """Interface for a single report section."""

    def render_text(self, ctx: ReportContext) -> list[str] | None: ...
    def render_dict(self, ctx: ReportContext) -> dict[str, Any] | None: ...


@dataclass
class ReportContext:
    """Pre-extracted data shared by all sections to avoid repeated parsing."""

    pipeline_run: PipelineRun
    analysis_results: list[AnalysisResult]
    mode: str
    function_name: str
    timestamp: str

    # Derived once, used by many sections
    em_full: dict[str, Any] = field(default_factory=dict)
    recommendations_detailed: list[dict[str, Any]] = field(default_factory=list)
    config_delta: list[dict[str, Any]] = field(default_factory=list)
    runtime_snapshot: dict[str, Any] = field(default_factory=dict)
    resource_context: dict[str, Any] = field(default_factory=dict)
    history_trend: dict[str, Any] = field(default_factory=dict)
    session_settings: dict[str, str] = field(default_factory=dict)


def _build_context(
    pipeline_run: PipelineRun,
    analysis_results: list[AnalysisResult],
    mode: str,
    function_name: str,
) -> ReportContext:
    ts = datetime.now(tz=timezone.utc).isoformat(timespec="seconds")
    em_full = pipeline_run.execution_metrics or {}
    recommendations_detailed = list(em_full.get("recommendations", []) or [])

    session_settings: dict[str, str] = {}
    for step in pipeline_run.step_results:
        for key in ("settings_applied", "session_settings_applied"):
            for k, v in step.metadata.get(key, {}).items():
                session_settings[k] = str(v)
    if not session_settings:
        for ar in analysis_results:
            ss = ar.signals.get("session_settings", {})
            if isinstance(ss, dict):
                for k, v in ss.items():
                    if k not in session_settings:
                        session_settings[k] = str(v)

    return ReportContext(
        pipeline_run=pipeline_run,
        analysis_results=analysis_results,
        mode=mode,
        function_name=function_name,
        timestamp=ts,
        em_full=em_full,
        recommendations_detailed=recommendations_detailed,
        config_delta=list(em_full.get("config_delta", []) or []),
        runtime_snapshot=dict(em_full.get("runtime_snapshot", {}) or {}),
        resource_context=dict(em_full.get("resource_context", {}) or {}),
        history_trend=dict(em_full.get("history_trend", {}) or {}),
        session_settings=session_settings,
    )


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------


def _wrap(text: str, prefix: str, subsequent: str | None = None) -> list[str]:
    sub = subsequent if subsequent is not None else " " * len(prefix)
    return textwrap.wrap(text, width=_LINE_WIDTH, initial_indent=prefix, subsequent_indent=sub)


def _kv(label: str, value: Any, col_w: int = 28) -> str:
    val = str(value)
    max_val = _LINE_WIDTH - col_w - 3
    if len(val) > max_val:
        val = val[: max_val - 3] + "..."
    return f"  {label:<{col_w}} {val}"


# ---------------------------------------------------------------------------
# Concrete sections
# ---------------------------------------------------------------------------


class HeaderSection:
    def render_text(self, ctx: ReportContext) -> list[str]:
        sep = "═" * _LINE_WIDTH
        lines = [
            sep,
            f"{'sparktimise  ·  Optimisation Report':^{_LINE_WIDTH}}",
            sep,
            _kv("Mode", _MODE_LABELS.get(ctx.mode, ctx.mode.upper())),
            _kv("Generated", ctx.timestamp),
        ]
        if ctx.function_name:
            lines.append(_kv("Function", ctx.function_name))
        lines.append(sep)
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any]:
        return {
            "generated_at": ctx.timestamp,
            "mode": ctx.mode,
            "function_name": ctx.function_name,
        }


class RunSummarySection:
    def render_text(self, ctx: ReportContext) -> list[str]:
        thin = "─" * _LINE_WIDTH
        dm = ctx.pipeline_run.dataset_metrics or {}
        em = ctx.pipeline_run.execution_metrics or {}
        steps = ctx.pipeline_run.step_results
        total_changes = len(ctx.pipeline_run.all_transformations)
        lines: list[str] = ["", "  RUN SUMMARY", thin]

        row_count = dm.get("row_count")
        total_size_mb = dm.get("total_size_mb")
        duration = em.get("function_duration_seconds")

        if row_count is not None:
            lines.append(_kv("Row count", f"{row_count:,}"))
        if total_size_mb is not None:
            lines.append(_kv("Estimated size", f"{total_size_mb} MB"))
        if duration is not None:
            total_secs = int(float(duration))
            h, remainder = divmod(total_secs, 3600)
            m, s = divmod(remainder, 60)
            lines.append(_kv("Pipeline duration", f"{h:02d}:{m:02d}:{s:02d}"))
        if ctx.mode == "report_only":
            lines.append(_kv("Steps recorded", "0  (metrics only)"))
        else:
            lines.append(_kv("Steps recorded", str(len(steps))))
            lines.append(_kv("Transformations", str(total_changes)))
        if ctx.recommendations_detailed:
            lines.append(_kv("Ranked recommendations", len(ctx.recommendations_detailed)))
        if ctx.config_delta:
            lines.append(_kv("Config delta entries", len(ctx.config_delta)))
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any]:
        dm = ctx.pipeline_run.dataset_metrics or {}
        em = ctx.pipeline_run.execution_metrics or {}
        return {
            "run_summary": {
                **dm,
                **{k: v for k, v in em.items() if k == "function_duration_seconds"},
                "steps_recorded": len(ctx.pipeline_run.step_results),
                "transformations_applied": len(ctx.pipeline_run.all_transformations),
            },
        }


class SessionConfigSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        if not ctx.session_settings:
            return None
        thin = "─" * _LINE_WIDTH
        lines: list[str] = ["", "  SESSION CONFIGURATION", thin]
        k_w = min(58, max((len(k) for k in ctx.session_settings), default=20) + 2)
        lines.append(f"  {'Setting':<{k_w}} Value")
        lines.append(f"  {'─' * k_w} {'─' * (min(30, _LINE_WIDTH - k_w - 4))}")
        for k, v in ctx.session_settings.items():
            max_v = _LINE_WIDTH - k_w - 6
            val_str = v if len(v) <= max_v else v[: max_v - 3] + "..."
            marker = "✓" if ctx.mode == "optimised" else "·"
            lines.append(f"  {marker}  {k:<{k_w - 3}} {val_str}")
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any]:
        return {"session_configuration": ctx.session_settings}


class DataAnalysisSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        thin = "─" * _LINE_WIDTH
        skew_signals: dict[str, Any] = {}
        partition_signals: dict[str, Any] = {}
        cache_signals: dict[str, Any] = {}

        for ar in ctx.analysis_results:
            n = ar.analyser_name
            if n == "SkewAnalyser":
                skew_signals = ar.signals
            elif n == "PartitionAnalyser":
                partition_signals = ar.signals
            elif n == "CacheAnalyser":
                cache_signals = ar.signals

        if not partition_signals:
            for step in ctx.pipeline_run.step_results:
                if step.optimiser_name == "PartitionOptimiser":
                    prev = step.metadata.get("previous_partitions")
                    new = step.metadata.get("new_partitions")
                    if prev is not None:
                        partition_signals = {
                            "current_partitions": prev,
                            "recommended_partitions": new,
                        }

        if not any([skew_signals, partition_signals, cache_signals]):
            return None

        lines: list[str] = ["", "  DATA ANALYSIS", thin]

        if partition_signals:
            cur = partition_signals.get("current_partitions")
            rec = partition_signals.get("recommended_partitions")
            cands = partition_signals.get("partition_by_candidates", [])
            if cur is not None:
                lines.append(_kv("Current partitions", cur))
            if rec is not None:
                lines.append(_kv("Recommended partitions", rec))
            if cands:
                col_list = "[" + ", ".join(f"'{c}'" for c in cands) + "]"
                lines.extend(_wrap(f"Partition-by candidates:  {col_list}", "  ", "    "))

        if skew_signals:
            skewed = skew_signals.get("skewed_columns", {})
            total_rows = skew_signals.get("total_rows")
            if total_rows is not None:
                lines.append(_kv("Rows analysed (skew)", f"{total_rows:,}"))
            if skewed:
                for col, frac in skewed.items():
                    lines.append(_kv(f"  Skew — '{col}'", f"{frac:.1%} dominated by one key"))
            else:
                lines.append(_kv("Skew detected", "None"))

        if cache_signals:
            rec_level = cache_signals.get("recommended_storage_level")
            if rec_level:
                lines.append(_kv("Recommended cache level", rec_level))

        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any] | None:
        return None  # Covered by schema_and_data_analysis in PerFunctionSection


class PerFunctionSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        thin = "─" * _LINE_WIDTH
        func_assessments = [ar for ar in ctx.analysis_results if ar.signals.get("qualified_function_name")]
        if not func_assessments:
            return None
        lines: list[str] = ["", "  PER-FUNCTION BREAKDOWN", thin]
        for i, ar in enumerate(func_assessments, 1):
            fn_name = ar.signals["qualified_function_name"]
            risk = ar.signals.get("risk_score", 0)
            risk_label = "CRITICAL" if risk >= 90 else "HIGH" if risk >= 50 else "MEDIUM" if risk >= 20 else "LOW"
            lines.extend(_wrap(f"{i}.  {fn_name}", "  ", "      "))
            source_file = ar.signals.get("source_file")
            source_line = ar.signals.get("source_line")
            if source_file:
                loc = f"{source_file}:{source_line}" if source_line is not None else source_file
                lines.append(f"      Source: {loc}")
            lines.append(f"      Risk: {risk} ({risk_label})")

            for w in ar.signals.get("warnings", []):
                lines.extend(_wrap(w, "      ⚠  ", "         "))

            fn_conf = ar.signals.get("session_settings", {})
            if fn_conf:
                lines.append("      Recommended config:")
                for k, v in fn_conf.items():
                    lines.append(f"        {k} = {v}")

            pm = ar.signals.get("plan_metrics") or ar.metadata.get("plan_metrics", {})
            if pm:
                joins = pm.get("join_strategies", [])
                exchanges = pm.get("exchange_count")
                bc = pm.get("broadcast_exchange_count")
                sv = pm.get("sample_validation", {})
                if joins:
                    lines.extend(_wrap(f"Joins: {', '.join(joins)}", "      ", "            "))
                if exchanges is not None:
                    lines.append(f"      Shuffle exchanges: {exchanges}")
                if bc is not None:
                    lines.append(f"      Broadcast exchanges: {bc}")
                if isinstance(sv, dict) and sv:
                    sr = sv.get("sampled_rows")
                    sf = sv.get("sample_fraction")
                    dc = sv.get("dominant_key_column")
                    ds = sv.get("dominant_key_share")
                    if sr is not None:
                        lines.append(f"      Sampled rows: {sr}")
                    if sf is not None:
                        lines.append(f"      Sample fraction: {sf}")
                    if dc is not None and ds is not None:
                        lines.append(f"      Dominant sampled key: {dc} ({float(ds):.2%} share)")
            lines.append("")
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any]:
        return {
            "schema_and_data_analysis": [
                {
                    "function": ar.signals.get("qualified_function_name", ar.analyser_name),
                    "source_file": ar.signals.get("source_file") or ar.metadata.get("source_file"),
                    "source_line": ar.signals.get("source_line") or ar.metadata.get("source_line"),
                    "risk_score": ar.signals.get("risk_score"),
                    "warnings": ar.signals.get("warnings", []),
                    "session_settings": ar.signals.get("session_settings", {}),
                    "plan_metrics": ar.signals.get("plan_metrics") or ar.metadata.get("plan_metrics", {}),
                    "plan_hash": ar.signals.get("plan_hash"),
                }
                for ar in ctx.analysis_results
            ],
        }


class RecommendationsSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        thin = "─" * _LINE_WIDTH
        seen: set[str] = set()
        deduped: list[str] = []
        for item in ctx.recommendations_detailed:
            rec = str(item.get("recommendation", "")).strip()
            if rec and rec not in seen:
                seen.add(rec)
                deduped.append(rec)
        if not deduped:
            return None
        lines: list[str] = ["", "  RECOMMENDATIONS", thin]
        for i, rec in enumerate(deduped, 1):
            lines.extend(_wrap(rec, f"  {i:>2}.  ", "       "))
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any] | None:
        recs = [
            str(item.get("recommendation", "")).strip()
            for item in ctx.recommendations_detailed
            if str(item.get("recommendation", "")).strip()
        ]
        if recs:
            return {"recommendations": recs}
        return None


class RankedRecommendationsSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        if not ctx.recommendations_detailed:
            return None
        thin = "─" * _LINE_WIDTH
        lines: list[str] = ["", "  RANKED RECOMMENDATIONS", thin]
        ranked = sorted(
            ctx.recommendations_detailed,
            key=lambda item: (
                _IMPACT_ORDER.get(str(item.get("impact", "low")), 1),
                _CONFIDENCE_ORDER.get(str(item.get("confidence", "low")), 1),
            ),
            reverse=True,
        )
        for idx, item in enumerate(ranked, 1):
            title = str(item.get("title") or item.get("recommendation") or "Recommendation")
            impact = str(item.get("impact", "low")).upper()
            confidence = str(item.get("confidence", "low")).upper()
            category = str(item.get("category", "general"))
            applies = "yes" if bool(item.get("applies_in_optimise", False)) else "no"
            lines.extend(_wrap(f"{idx}. {title}", "  ", "     "))
            lines.append(f"     Category: {category} | Impact: {impact} | Confidence: {confidence}")
            lines.append(f"     Auto-apply in optimise: {applies}")
            recommendation_text = str(item.get("recommendation", "")).strip()
            if recommendation_text:
                lines.extend(_wrap(recommendation_text, "     Action: ", "             "))
            evidence = item.get("evidence", [])
            if isinstance(evidence, list) and evidence:
                lines.append("     Evidence:")
                for ev in evidence:
                    lines.extend(_wrap(str(ev), "       - ", "         "))
            proposed = item.get("proposed_settings", {})
            if isinstance(proposed, dict) and proposed:
                lines.append("     Proposed settings:")
                for key, val in proposed.items():
                    lines.append(f"       {key} = {val}")
            lines.append("")
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any] | None:
        if not ctx.recommendations_detailed:
            return None
        ranked = sorted(
            ctx.recommendations_detailed,
            key=lambda item: (
                _IMPACT_ORDER.get(str(item.get("impact", "low")), 1),
                _CONFIDENCE_ORDER.get(str(item.get("confidence", "low")), 1),
            ),
            reverse=True,
        )
        return {"ranked_recommendations": ranked}


class ConfigDeltaSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        if not ctx.config_delta:
            return None
        thin = "─" * _LINE_WIDTH
        lines: list[str] = ["", "  CONFIG DELTA (CURRENT VS PROPOSED)", thin]
        lines.append("  Setting                                               Before                     After")
        lines.append("  " + "-" * 52 + "  " + "-" * 25 + "  " + "-" * 25)
        for row in ctx.config_delta:
            key = str(row.get("key", ""))
            before = str(row.get("before", "<unset>"))
            after = str(row.get("after", "<unset>"))
            lines.append(f"  {key[:52]:<52}  {before[:25]:<25}  {after[:25]:<25}")
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any] | None:
        if not ctx.config_delta:
            return None
        return {"config_delta": ctx.config_delta}


class TransformationsSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        thin = "─" * _LINE_WIDTH
        non_baseline = [s for s in ctx.pipeline_run.step_results if not s.metadata.get("baseline")]
        if non_baseline:
            lines: list[str] = ["", "  TRANSFORMATIONS APPLIED", thin]
            for i, step in enumerate(non_baseline, 1):
                dur = step.metadata.get("duration_ms")
                dur_str = f"  ⏱ {dur:.0f} ms" if dur is not None else ""
                lines.append(f"  {i}.  {step.optimiser_name}{dur_str}")
                for t in step.transformations_applied:
                    lines.extend(_wrap(t, "       →  ", "          "))
                skipped: dict[str, Any] = step.metadata.get("settings_skipped", {})
                for k, v in skipped.items():
                    lines.extend(_wrap(f"✗  {k} = {v}  (skipped)", "       ", "          "))
            return lines
        if ctx.mode == "report_only":
            return [
                "",
                "  TRANSFORMATIONS APPLIED",
                thin,
                "  Not applicable — report_only mode records metrics only.",
            ]
        return None

    def render_dict(self, ctx: ReportContext) -> dict[str, Any]:
        return {
            "transformations": [
                {
                    "step": step.optimiser_name,
                    "transformations": step.transformations_applied,
                    "settings_skipped": step.metadata.get("settings_skipped", {}),
                    "duration_ms": step.metadata.get("duration_ms"),
                }
                for step in ctx.pipeline_run.step_results
                if not step.metadata.get("baseline")
            ],
        }


class QueryPlanMetricsSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        thin = "─" * _LINE_WIDTH
        em = ctx.em_full
        join_strategies: list[str] = em.get("join_strategies", [])
        exchange_count = em.get("exchange_count")
        bc_exchange_count = em.get("broadcast_exchange_count")
        has_aqe = em.get("has_aqe")
        has_pp = em.get("has_partition_pruning")

        has_plan_metrics = any(v is not None for v in (exchange_count, bc_exchange_count, has_aqe, has_pp))
        if not has_plan_metrics and not join_strategies:
            return None

        lines: list[str] = ["", "  QUERY PLAN METRICS", thin]
        if has_aqe is not None:
            lines.append(_kv("AQE active", "Yes" if has_aqe else "No"))
        if exchange_count is not None:
            lines.append(_kv("Shuffle exchanges", str(exchange_count)))
        if bc_exchange_count is not None:
            lines.append(_kv("Broadcast exchanges", str(bc_exchange_count)))
        if has_pp is not None:
            lines.append(_kv("Partition pruning", "Yes (dynamic)" if has_pp else "No"))
        if join_strategies:
            lines.append(_kv("Join strategies", ", ".join(join_strategies)))
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any]:
        em = ctx.em_full
        qpm = {
            k: em[k]
            for k in (
                "physical_plan",
                "join_strategies",
                "exchange_count",
                "broadcast_exchange_count",
                "has_aqe",
                "has_partition_pruning",
            )
            if k in em
        }
        return {"query_plan_metrics": qpm}


class RuntimeContextSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        if not ctx.runtime_snapshot and not ctx.resource_context:
            return None
        thin = "─" * _LINE_WIDTH
        lines: list[str] = ["", "  RUNTIME AND RESOURCE CONTEXT", thin]
        for key, val in sorted(ctx.runtime_snapshot.items()):
            lines.append(_kv(f"runtime.{key}", val))
        for key, val in sorted(ctx.resource_context.items()):
            lines.append(_kv(f"resource.{key}", val))
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any]:
        return {
            "runtime_metrics": ctx.runtime_snapshot,
            "resource_context": ctx.resource_context,
        }


class HistoricalTrendSection:
    def render_text(self, ctx: ReportContext) -> list[str] | None:
        if not ctx.history_trend:
            return None
        thin = "─" * _LINE_WIDTH
        lines: list[str] = ["", "  HISTORICAL TREND", thin]
        for key in (
            "status",
            "previous_total_risk",
            "current_total_risk",
            "delta_total_risk",
            "previous_generated_at",
        ):
            if key in ctx.history_trend:
                lines.append(_kv(key, ctx.history_trend[key]))
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any]:
        return {"historical_trend": ctx.history_trend}


class FooterSection:
    def render_text(self, ctx: ReportContext) -> list[str]:
        sep = "═" * _LINE_WIDTH
        total_changes = len(ctx.pipeline_run.all_transformations)
        lines = ["", sep]
        if ctx.mode == "optimised":
            footer = f"  {total_changes} transformation(s) applied  ·  Mode: {ctx.mode}  ·  {ctx.timestamp}"
        elif ctx.mode == "baseline":
            deduped_count = len(
                {
                    str(item.get("recommendation", "")).strip()
                    for item in ctx.recommendations_detailed
                    if str(item.get("recommendation", "")).strip()
                }
            )
            count = len(ctx.recommendations_detailed) or deduped_count
            footer = f"  {count} recommendation(s) surfaced  ·  Mode: {ctx.mode}  ·  {ctx.timestamp}"
        else:
            footer = f"  Mode: {ctx.mode}  ·  {ctx.timestamp}"
        lines.append(footer[:_LINE_WIDTH])
        lines.append(sep)
        return lines

    def render_dict(self, ctx: ReportContext) -> dict[str, Any] | None:
        return None


# ---------------------------------------------------------------------------
# Default section ordering
# ---------------------------------------------------------------------------

DEFAULT_SECTIONS: list[ReportSection] = [
    HeaderSection(),
    RunSummarySection(),
    SessionConfigSection(),
    DataAnalysisSection(),
    PerFunctionSection(),
    RecommendationsSection(),
    RankedRecommendationsSection(),
    ConfigDeltaSection(),
    TransformationsSection(),
    QueryPlanMetricsSection(),
    RuntimeContextSection(),
    HistoricalTrendSection(),
    FooterSection(),
]


# ---------------------------------------------------------------------------
# Report class
# ---------------------------------------------------------------------------


@dataclass
class OptimisationReport:
    """Aggregate report produced from a pipeline run.

    Parameters
    ----------
    pipeline_run : PipelineRun
        The completed pipeline run to summarise.
    analysis_results : list[AnalysisResult], optional
        Analysis results from analyse_* functions (baseline mode).
    mode : str, optional
        One of ``"baseline"``, ``"optimised"``, or ``"report_only"``.
    sections : list[ReportSection], optional
        Override the default section list to add, remove, or reorder
        report sections.

    Examples
    --------
    >>> report = OptimisationReport(pipeline_run=my_run, mode="optimised")
    >>> print(report.to_text())
    >>> report_dict = report.to_dict()
    """

    pipeline_run: PipelineRun
    analysis_results: list[AnalysisResult] = field(default_factory=list)
    mode: str = "optimised"
    function_name: str = ""
    sections: list[ReportSection] = field(default_factory=lambda: list(DEFAULT_SECTIONS))

    def to_text(self) -> str:
        """Render the report as a plain-text string."""
        ctx = _build_context(self.pipeline_run, self.analysis_results, self.mode, self.function_name)
        lines: list[str] = []
        for section in self.sections:
            result = section.render_text(ctx)
            if result is not None:
                lines.extend(result)
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Serialise the report to a plain Python dictionary."""
        ctx = _build_context(self.pipeline_run, self.analysis_results, self.mode, self.function_name)
        payload: dict[str, Any] = {}
        for section in self.sections:
            result = section.render_dict(ctx)
            if result is not None:
                payload.update(result)
        return payload
