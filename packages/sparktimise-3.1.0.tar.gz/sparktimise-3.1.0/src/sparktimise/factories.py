"""Public context-manager entry points for Spark plan tuning."""

from __future__ import annotations

import contextlib
import contextvars
from collections.abc import Generator
from typing import Any

from sparktimise.context import SparkPipelineAutoTuner, optimise_context

_pipeline_run_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_pipeline_run_id",
    default=None,
)


@contextlib.contextmanager
def pipeline_run(run_id: str) -> Generator[None, None, None]:
    """Set a shared run identifier for nested sparktimise context managers."""
    token = _pipeline_run_id.set(run_id)
    try:
        yield
    finally:
        _pipeline_run_id.reset(token)


def optimise(
    spark: Any,
    pipeline_name: str = "sparktimise_pipeline",
    *,
    run_type: str = "optimise",
    run_id: str | None = None,
    **kwargs: Any,
) -> SparkPipelineAutoTuner:
    """Create a context-manager driven Spark pipeline optimiser.

    The returned
    :class:`~sparktimise.context.SparkPipelineAutoTuner` auto-assesses watched
    DataFrame-returning functions inside the ``with`` block and dispatches the
    final run through ``optimise``, ``baseline``, or ``report`` behaviour.

    Parameters
    ----------
    spark:
        Existing SparkSession-like object whose ``conf`` API can be tuned.
    pipeline_name:
        Human-readable pipeline name used in reports and exported filenames.
    run_type:
        One of ``"optimise"``, ``"baseline"``, or ``"report"``.
    run_id:
        Optional report folder run id.  If omitted, any active
        :func:`pipeline_run` value is used.
    **kwargs:
        Additional ``SparkPipelineAutoTuner`` options such as
        ``watched_functions``, ``watched_modules``, ``output_path``, and
        ``auto_capture``.  ``watched_modules`` accepts either a list of
        module prefixes or a path to a ``.txt`` file containing one entry
        per line.
    """
    selected_run_id = run_id or _pipeline_run_id.get()
    return optimise_context(
        spark=spark,
        pipeline_name=pipeline_name,
        run_type=run_type,
        run_id=selected_run_id,
        **kwargs,
    )
