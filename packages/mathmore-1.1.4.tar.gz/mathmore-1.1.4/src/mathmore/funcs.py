def info():
    return '''
This module is made by HZY.
This is a mathematical module.
The version of the module is 1.1.4.
'''

def root_of_unity(exponent):
    import cmath
    list_root=[]
    for term in range(0,exponent):
        item=2*term/exponent
        in_list=cmath.exp(item*(1j)*cmath.pi)
        real=in_list.real
        imag=in_list.imag
        if abs(in_list.imag)<=1e-10:
            imag=0
            in_list=real+imag*(1j)
        if abs(in_list.real-round(in_list.real,5))<=1e-10:
           real=round(in_list.real,5)
           in_list=real+imag*(1j)
        list_root.append(in_list)
    return list_root

def distance(tuple1,tuple2):
    from math import sqrt
    if tuple(tuple1)!=tuple1 or tuple(tuple2)!=tuple2:
        raise TypeError("input type error")
    if tuple1==():
        tuple1=(0,0)
    if tuple2==():
        tuple2=(0,0)
    if len(tuple1)>2 or len(tuple1)==1 or len(tuple2)>2 or len(tuple2)==1:
        raise SyntaxError("tuple len error")
    dist=sqrt((tuple1[0]-tuple2[0])**2+(tuple1[1]-tuple2[1])**2)
    return dist

def fib(n):
    if n==int(n):
        a, b = 0, 1
        for _ in range(n):
            a, b = b, a + b
        return a
    else:
        from cmath import sqrt
        aphi=(1+sqrt(5))/2
        bphi=(1-sqrt(5))/2
        fib=(aphi**n-bphi**n)/(sqrt(5))
        fibr=fib.real
        fibi=fib.imag
        if abs(fibi)<=1e-10:
            fibi=0
            fib=fibr+fibi*(1j)
        if abs(fibr-round(fibr,5))<=1e-10:
           fibr=round(fibr,5)
        return fib
    
def is_prime(x):
    from math import floor,sqrt
    loop=0
    if int(x)!=x:
        raise ValueError("input type error")
    elif x==2:
        loop=1
    elif x==1:
        loop=0
    elif x==0:
        raise ValueError("math domain error")
    else:
        for term in range(2,floor(sqrt(x))+1):
            if x%term==0:
                loop=0
                break
            else:
                loop=1
    out=bool(loop)
    return out

def Si(x):
    from math import factorial
    total=0
    for k in range(0,500):
        term=(((-1)**k)*(x**(2*k+1)))/(factorial(2*k+1)*(2*k+1))
        total+=term
    return total

def Ci(x):
    from math import factorial,log
    gamma=0.577215664901533
    total=gamma+log(x)
    if x<=0:
        raise ValueError("math domain error")
    for k in range(1,50):
        term=(((-1)**k)*(x**(2*k)))/((2*k)*factorial(2*k))
        total+=term
    return total

def Ei(x):
    from math import factorial,log
    gamma=0.577215664901533
    total=gamma+log(x)
    if x<=0:
        raise ValueError("math domain error")
    for k in range(1,50):
        term=(x**(k))/((k)*factorial(k))
        total+=term
    return total

def Ti(x):
    from math import pi,log
    if abs(x)<=1:
        total=0
        for n in range(0,300):
            term=(((-1)**n)*(x**(2*n+1)))/((2*n+1)**2)
            total+=term
        return total
    else:
        return pi/2*log(x)-Ti(1/x)
    
def En(n,x):
    from math import exp,factorial,log
    gamma=0.577215664901533
    if n<=0 or x<=0:
        raise ValueError("value input error")
    else:
        if n==1:
            total=-gamma-log(x)
            for k in range(1,100):
                term=((-x)**k)/(k*(factorial(k)))
                total-=term
            return total
        else:
            return (exp(-x)-x*En(n-1,x))/(n-1)

def LambertW(x): 
    import cmath
    resultW=x/2
    for count in range (1,101):
        differenceW=(resultW*cmath.exp(resultW)-x)/((resultW+1)*cmath.exp(resultW))
        resultW-=differenceW
    return resultW

def sqrtn(x,n=2):
    return x**(1/n)

def fw(x):
    fw_list=[]
    for p in range(1,x+1):
        if x%p==0:
            fw_list.append(p)
    return fw_list

def pf(x):
    from sympy import isprime
    prime_list=[]
    res=[]
    for p in range(1,x+1):
        loop=isprime(p)
        if loop==True and x%p==0:
            prime_list.append(p)
    for q in prime_list:
        expon=0
        while x%q==0:
            x/=q
            expon+=1
        inlist=[q,expon]
        res.append(inlist)
        inlist=[]
    return res

def is_triangle(x):
    determine=(((8*x+1)**(1/2))-1)/2
    if x<=0 or int(x)!=x:
        raise ValueError('value input error')
    else:
        if int(determine)==determine:
            return True
        else:
            return False
        

omega=0.567143290409784
gamma=0.577215664901533
conwayconstant=1.303577269034296
dottienumber=0.7390851332151606
phi=1.618033988749895
aperyconstant=1.202056903159594
MillsA=1.306377883863081
CatalanG=0.915965594177219

def get_help():
    help="""
This module is made by HZY.
USAGE FUNCTIONS:
info()                      You can get the informations of the module.
get_help()                  You can get all the functions and usages of the module.

MATHEMATICAL FUNCTIONS:
root_of_unity(exponent)     This function can return n n-dimensional unit roots.
distance(tuple1,tuple2)     This function can return the distance between two points.
fib(n)                      This function can return the n-th term of the Fibonacci sequence.(n can be float)
Si(x),Ci(x)                 These functions are both trigonometric integral functions.
Ti(x)                       This function is an inverse trigonometric integral function.
Ei(x),En(n,x)               These functions are both exponential integral function.
LambertW(x)                 This function can return the value of (Lambert)W(x).(x can be complex)
sqrtn(x,n=2)                This function can return the value of the nth root of x.
is_prime(x)                 This function can determine if x is a prime number.
fw(x)                       This function can list all the factors of x.
pf(x)                       This function can factorize x into its prime factors.(return like [[the first factor,exponent],[the second factor,exponent],the last factor,exponent])
is_triangle(x)              This function can determine if x is a triangle number.

CONSTANTS:
omega                       This constant is the solution of this equation:xe^x=1.
gamma                       This constant refers to this limit expression:lim x→∞ H(x)-lnx.H(x)=1+1/2+1/3+···+1/x.
conwayconstant              This constant refers to the limit of the growth rate of the look-and-say sequence.
dottienumber                This constant is the solution of this equation:x=cosx.
phi                         This constant refers to this limit expression:lim n→∞ F(n+1)/F(n).F(n) refers to the n-th term of the Fibonacci sequence. 
aperyconstant               This constant is the value of (Riemman)ζ(3).
MillsA                      This constant can be a generator of prime numbers.
CatalanG                    This constant refers to the value of 1-1/3^2+1/5^2-1/7^2······
"""
    return help
