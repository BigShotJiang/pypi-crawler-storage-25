from .funcs import *
__version__="1.1.4"
AUTHOR="HZY"