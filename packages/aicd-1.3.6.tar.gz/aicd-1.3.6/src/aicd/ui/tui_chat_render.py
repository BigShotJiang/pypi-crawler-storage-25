"""将助手回复渲染为适合 Textual RichLog 的 Rich 对象（Markdown 表格、标题、粗体等）。"""

from __future__ import annotations

import os
import re
from io import StringIO
from typing import TYPE_CHECKING

from rich import box
from rich.console import Console
from rich.console import Group
from rich.markdown import Markdown
from rich.table import Table
from rich.text import Text

if TYPE_CHECKING:
    from rich.console import RenderableType


def _looks_like_table_header(line: str) -> bool:
    s = line.strip()
    return "|" in s and s.count("|") >= 2 and not s.startswith("```")


def _is_gfm_table_row(line: str) -> bool:
    """表体行：含至少两个 |，且不是代码围栏。"""
    s = line.strip()
    if not s or s.startswith("```"):
        return False
    return "|" in s and s.count("|") >= 2


def _is_table_separator_row(line: str) -> bool:
    """GFM 表格第二行：仅由 |、-、:、空白 组成各列。"""
    s = (line or "").strip()
    if "|" not in s:
        return False
    core = s.strip("|").split("|")
    if len(core) < 1:
        return False
    for cell in core:
        c = cell.strip()
        if not c:
            return False
        if not all(ch in "-:" for ch in c):
            return False
    return True


def _split_pipe_row(line: str) -> list[str]:
    s = (line or "").strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [c.strip() for c in s.split("|")]


def _strip_inline_md_for_display(cell: str) -> str:
    """弱化 TUI 里表格单元格中的 Markdown 噪音（粗体、行内代码）。"""
    t = cell.strip()
    t = re.sub(r"\*\*(.+?)\*\*", r"\1", t)
    t = re.sub(r"`([^`]+)`", r"\1", t)
    return t.strip()


def _line_indices_inside_fenced_blocks(lines: list[str]) -> set[int]:
    """Markdown 围栏（```）内行下标，避免把示例里的 ``|`` 当成 GFM 表。"""
    inside = False
    blocked: set[int] = set()
    for i, ln in enumerate(lines):
        if ln.strip().startswith("```"):
            inside = not inside
            continue
        if inside:
            blocked.add(i)
    return blocked


def _iter_gfm_table_spans(lines: list[str]) -> list[tuple[int, int]]:
    """返回每段 GFM 表格的 [start, end) 行下标（含表头与分隔行）。"""
    blocked = _line_indices_inside_fenced_blocks(lines)
    spans: list[tuple[int, int]] = []
    n = len(lines)
    i = 0
    while i < n:
        if i in blocked:
            i += 1
            continue
        if (
            i + 1 < n
            and _looks_like_table_header(lines[i])
            and _is_table_separator_row(lines[i + 1])
            and i not in blocked
            and (i + 1) not in blocked
        ):
            start = i
            j = i + 2
            while j < n and lines[j].strip() and _is_gfm_table_row(lines[j]):
                if j in blocked:
                    break
                j += 1
            if not any(k in blocked for k in range(start, j)):
                spans.append((start, j))
            i = j
            continue
        i += 1
    return spans


def _tui_table_console_width() -> int:
    raw = (os.environ.get("AICD_TUI_TABLE_WIDTH") or "").strip()
    if raw.isdigit():
        return max(40, min(int(raw), 260))
    return 100


def _render_gfm_table_block(block_lines: list[str], *, width: int) -> str:
    """将已解析的表头+分隔+表体行渲染为 Rich Table 的纯文本（等宽）。"""
    if len(block_lines) < 2:
        return "\n".join(block_lines)
    header_cells = [_strip_inline_md_for_display(c) for c in _split_pipe_row(block_lines[0])]
    body_lines = block_lines[2:]
    rows = [
        [_strip_inline_md_for_display(c) for c in _split_pipe_row(bl)]
        for bl in body_lines
        if bl.strip()
    ]
    if not header_cells:
        return "\n".join(block_lines)

    table = Table(
        show_header=True,
        header_style="bold",
        box=box.SIMPLE_HEAD,
        pad_edge=False,
    )
    for h in header_cells:
        table.add_column(h)
    for row in rows:
        # 列数不齐时右侧补空，避免 Rich 报错
        padded = list(row)
        while len(padded) < len(header_cells):
            padded.append("")
        if len(padded) > len(header_cells):
            padded = padded[: len(header_cells)]
        table.add_row(*padded)

    buf = StringIO()
    console = Console(
        file=buf,
        width=width,
        force_terminal=False,
        legacy_windows=False,
        color_system=None,
        highlight=False,
    )
    console.print(table)
    return buf.getvalue()


def replace_gfm_tables_with_plain_text_tables(
    text: str,
    *,
    width: int | None = None,
    wrap_fenced: bool = False,
) -> str:
    """
    将 GFM 管道表格替换为 Rich 渲染的**纯文本表**（无 ``| :--- |`` 语法噪音）。

    TUI 默认不启用 Markdown 时，模型仍常输出 GFM 表；本函数在渲染前统一转换。
    **wrap_fenced**：为 True 时用 Markdown 围栏包起来，便于在 ``use_markdown=True`` 时保持等宽对齐。
    """
    w = width if width is not None else _tui_table_console_width()
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    spans = _iter_gfm_table_spans(lines)
    if not spans:
        return text

    segments: list[str] = []
    prev = 0
    for start, end in spans:
        if start > prev:
            segments.append("\n".join(lines[prev:start]))
        rendered = _render_gfm_table_block(lines[start:end], width=w).rstrip() + "\n"
        if wrap_fenced:
            segments.append("```text\n" + rendered.rstrip("\n") + "\n```\n")
        else:
            segments.append(rendered)
        prev = end
    if prev < len(lines):
        segments.append("\n".join(lines[prev:]))
    return "\n".join(segments)


def normalize_markdown_blocks(raw: str) -> str:
    """
    宽松规整：统一换行；在「紧邻上一段文本的 GFM 表格」前插入空行，避免整张表被当成普通段落。
    """
    text = (raw or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    out: list[str] = []
    for i, line in enumerate(lines):
        if (
            i > 0
            and out
            and out[-1].strip() != ""
            and _looks_like_table_header(line)
            and i + 1 < len(lines)
            and _is_table_separator_row(lines[i + 1])
        ):
            out.append("")
        out.append(line)
    return "\n".join(out)


def _base_line_style_for_markdown(line: str) -> tuple[str, str]:
    """返回 (去标记后的文本, 基础行样式)。"""
    s = line.rstrip("\n")
    m = re.match(r"^\s{0,3}(#{1,6})\s+(.*)$", s)
    if m:
        level = len(m.group(1))
        body = m.group(2)
        style_map = {
            1: "bold bright_cyan",
            2: "bold cyan",
            3: "bold bright_blue",
            4: "bold blue",
            5: "bold bright_magenta",
            6: "bold magenta",
        }
        return body, style_map.get(level, "bold cyan")
    if re.match(r"^\s*>\s?", s):
        return re.sub(r"^\s*>\s?", "", s), "italic green"
    if re.match(r"^\s*([-*+]|(\d+\.))\s+", s):
        return s, "bright_white"
    return s, ""


def _heading_prefix(level: int) -> str:
    return {
        1: "◆ ",
        2: "◇ ",
        3: "▣ ",
        4: "▢ ",
        5: "• ",
        6: "· ",
    }.get(level, "• ")


def _line_heading_level(line: str) -> int:
    m = re.match(r"^\s{0,3}(#{1,6})\s+.*$", line.rstrip("\n"))
    if not m:
        return 0
    return len(m.group(1))


def _style_inline_markdown(text: str) -> Text:
    """
    轻量 Markdown 着色：
    - **strong** / __strong__
    - *em* / _em_
    - `code`
    - 按标题/引用/列表行赋基础色
    """
    src = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = src.split("\n")
    out = Text()
    token_re = re.compile(
        r"(\*\*[^*\n](?:.*?[^*])?\*\*|__[^_\n](?:.*?[^_])?__|`[^`\n]+`|\*[^*\n](?:.*?[^*])?\*|_[^_\n](?:.*?[^_])?_)"
    )
    in_fence = False
    fence_lang = ""
    for i, raw_line in enumerate(lines):
        stripped = raw_line.strip()
        if stripped.startswith("```"):
            if not in_fence:
                in_fence = True
                fence_lang = stripped[3:].strip()
                label = fence_lang if fence_lang else "text"
                out.append(f"╭─ code ({label})\n", style="bold cyan")
            else:
                in_fence = False
                out.append("╰─ end code", style="bold cyan")
                if i < len(lines) - 1:
                    out.append("\n")
            continue
        if in_fence:
            out.append("│ ", style="cyan")
            out.append(raw_line, style="bold bright_cyan on black")
            if i < len(lines) - 1:
                out.append("\n")
            continue

        line, base_style = _base_line_style_for_markdown(raw_line)
        lv = _line_heading_level(raw_line)
        if lv > 0:
            out.append(_heading_prefix(lv), style=base_style or "bold cyan")
        pos = 0
        for m in token_re.finditer(line):
            if m.start() > pos:
                out.append(line[pos : m.start()], style=base_style or None)
            tk = m.group(0)
            if tk.startswith("**") and tk.endswith("**"):
                out.append(tk[2:-2], style="bold bright_yellow")
            elif tk.startswith("__") and tk.endswith("__"):
                out.append(tk[2:-2], style="bold bright_yellow")
            elif tk.startswith("`") and tk.endswith("`"):
                out.append(tk[1:-1], style="bold black on bright_cyan")
            elif tk.startswith("*") and tk.endswith("*"):
                out.append(tk[1:-1], style="italic bright_magenta")
            elif tk.startswith("_") and tk.endswith("_"):
                out.append(tk[1:-1], style="italic bright_magenta")
            else:
                out.append(tk, style=base_style or None)
            pos = m.end()
        if pos < len(line):
            out.append(line[pos:], style=base_style or None)
        if i < len(lines) - 1:
            out.append("\n")
    return out


def render_assistant_message(
    markdown_body: str,
    *,
    label: str = "[助手]",
    use_markdown: bool = False,
) -> RenderableType:
    """
    返回可交给 ``RichLog.write`` 的单块渲染结果。

    - **use_markdown=True**（TUI 默认，见 ``resolve_tui_assistant_markdown_chat``）：Rich **Markdown**
      将 ``**`` 转为**粗体**、标题/列表/行内代码等转为终端样式；GFM 管道表先转为 `` ```text``
      等宽块，避免 ``| :--- |`` 与 Rich 表格在窄终端下难读。
    - **use_markdown=False**：整段为 ``Text``，不解析 ``**``（完全纯文本）。
    - 剪贴板 / 持久化请仍使用模型返回的原始字符串。
    """
    body = (markdown_body or "").strip()
    label_t = Text(label, style="bold cyan")
    if not body:
        return Group(label_t, Text("（空回复）", style="dim"))

    normalized = normalize_markdown_blocks(body)
    width = _tui_table_console_width()
    try:
        table_replaced = replace_gfm_tables_with_plain_text_tables(
            normalized,
            width=width,
            wrap_fenced=use_markdown,
        )
    except Exception:
        table_replaced = normalized

    if not use_markdown:
        return Group(label_t, Text(table_replaced))

    # 为了让 **强调** / *斜体* / `代码` 在各种终端都稳定有色，优先使用轻量行内着色。
    try:
        colored = _style_inline_markdown(table_replaced)
        return Group(label_t, colored)
    except Exception:
        md = Markdown(
            table_replaced,
            code_theme="ansi_dark",
            hyperlinks=False,
        )
        return Group(label_t, md)
