"""可选搜索 API：Google CSE、Bing Web、阿里 IQS、GitHub Search、GitLab Search（由 `integrations.*` + 环境变量控制）。"""

from __future__ import annotations

import json
import os
from typing import Any
from urllib.parse import quote
from urllib.parse import urlencode

import httpx

from aicd.config import AppConfig
from aicd.network_policy import outbound_tool_url_blocked_reason
from aicd.version import VERSION


def _ua() -> str:
    return f"AICD/{VERSION} (https://github.com/)"


def google_cse_effective_config(cfg: AppConfig) -> tuple[str, str]:
    c = cfg.integrations.google_cse_search
    key = (c.api_key or os.environ.get("AICD_GOOGLE_CSE_API_KEY") or "").strip()
    cx = (c.cx or os.environ.get("AICD_GOOGLE_CSE_CX") or "").strip()
    return key, cx


def bing_subscription_effective(cfg: AppConfig) -> str:
    c = cfg.integrations.bing_web_search
    return (
        c.subscription_key or os.environ.get("AICD_BING_SEARCH_SUBSCRIPTION_KEY") or ""
    ).strip()


def github_token_effective(cfg: AppConfig) -> str:
    c = cfg.integrations.github
    return (c.token or os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN") or "").strip()


def aliyun_iqs_key_effective(cfg: AppConfig) -> str:
    c = cfg.integrations.aliyun_iqs_search
    return (
        c.api_key
        or os.environ.get("AICD_ALIYUN_IQS_API_KEY")
        or os.environ.get("TONGXIAO_API_KEY")
        or ""
    ).strip()


def gitlab_token_effective(cfg: AppConfig) -> str:
    c = cfg.integrations.gitlab_search
    return (c.private_token or os.environ.get("AICD_GITLAB_PRIVATE_TOKEN") or "").strip()


def search_integrations_status_payload(cfg: AppConfig) -> dict[str, Any]:
    """供 **search_integrations_status** 与错误提示；不含密钥原文。"""
    gk, gc = google_cse_effective_config(cfg)
    bk = bing_subscription_effective(cfg)
    ai_key = aliyun_iqs_key_effective(cfg)
    gh_tok = github_token_effective(cfg)
    gl_tok = gitlab_token_effective(cfg)
    return {
        "google_cse_search": {
            "enabled": cfg.integrations.google_cse_search.enabled,
            "ready": bool(cfg.integrations.google_cse_search.enabled and gk and gc),
            "api_key_configured": bool(gk),
            "cx_configured": bool(gc),
            "env": ["AICD_GOOGLE_CSE_API_KEY", "AICD_GOOGLE_CSE_CX"],
        },
        "bing_web_search": {
            "enabled": cfg.integrations.bing_web_search.enabled,
            "ready": bool(cfg.integrations.bing_web_search.enabled and bk),
            "subscription_key_configured": bool(bk),
            "endpoint": cfg.integrations.bing_web_search.endpoint,
            "env": ["AICD_BING_SEARCH_SUBSCRIPTION_KEY"],
        },
        "github_search": {
            "enabled": cfg.integrations.github_search.enabled,
            "ready": bool(cfg.integrations.github_search.enabled and gh_tok),
            "github_token_configured": bool(gh_tok),
            "env": ["GITHUB_TOKEN", "GH_TOKEN"],
        },
        "aliyun_iqs_search": {
            "enabled": cfg.integrations.aliyun_iqs_search.enabled,
            "ready": bool(cfg.integrations.aliyun_iqs_search.enabled and ai_key),
            "api_key_configured": bool(ai_key),
            "endpoint": cfg.integrations.aliyun_iqs_search.endpoint,
            "env": ["AICD_ALIYUN_IQS_API_KEY", "TONGXIAO_API_KEY"],
        },
        "gitlab_search": {
            "enabled": cfg.integrations.gitlab_search.enabled,
            "ready": bool(cfg.integrations.gitlab_search.enabled and gl_tok),
            "private_token_configured": bool(gl_tok),
            "base_url": cfg.integrations.gitlab_search.base_url,
            "env": ["AICD_GITLAB_PRIVATE_TOKEN"],
        },
    }


_GOOGLE_CSE_URL = "https://www.googleapis.com/customsearch/v1"


async def run_search_google_cse(
    cfg: AppConfig,
    *,
    q: str,
    num: int,
    timeout_sec: float,
) -> dict[str, Any]:
    if router_block := _block_check(_GOOGLE_CSE_URL, cfg):
        return router_block
    if not cfg.integrations.google_cse_search.enabled:
        return {
            "ok": False,
            "error": "search_google_cse_disabled",
            "hint": "在 config.yaml 设置 integrations.googleCseSearch.enabled=true，并配置 apiKey、cx；"
            "或用 agent_settings_update 写入；密钥可辅以环境变量 AICD_GOOGLE_CSE_API_KEY / AICD_GOOGLE_CSE_CX。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    key, cx = google_cse_effective_config(cfg)
    if not key or not cx:
        return {
            "ok": False,
            "error": "search_google_cse_incomplete",
            "hint": "已启用但缺少 apiKey 或 cx（或环境变量）。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    n = max(1, min(10, int(num)))
    params = {"key": key, "cx": cx, "q": q.strip(), "num": n}
    url = f"{_GOOGLE_CSE_URL}?{urlencode(params, quote_via=quote, safe='/')}"
    try:
        async with httpx.AsyncClient(
            timeout=timeout_sec,
            headers={"User-Agent": _ua(), "Accept": "application/json"},
        ) as client:
            r = await client.get(url)
        text = r.text[:500_000]
        pj = None
        try:
            pj = json.loads(r.text)
        except Exception:  # noqa: BLE001
            pj = None
        return {
            "ok": r.is_success,
            "status_code": r.status_code,
            "url": _GOOGLE_CSE_URL,
            "json": pj,
            "text": text if pj is None else None,
            "truncated": len(r.text) > len(text),
            "hint": None if r.is_success else text[:2000],
        }
    except httpx.TimeoutException:
        return {"ok": False, "error": "timeout"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)}


def _block_check(url: str, cfg: AppConfig) -> dict[str, Any] | None:
    br = outbound_tool_url_blocked_reason(
        url, block_external=cfg.agent.block_external_network
    )
    if br:
        return {
            "ok": False,
            "error": br,
            "network_policy": "block_external_network",
        }
    return None


async def run_search_bing_web(
    cfg: AppConfig,
    *,
    q: str,
    count: int,
    mkt: str | None,
    timeout_sec: float,
) -> dict[str, Any]:
    ep = (cfg.integrations.bing_web_search.endpoint or "").strip().rstrip("/")
    if not ep.startswith("http"):
        ep = "https://api.bing.microsoft.com/v7.0/search"
    if router_block := _block_check(ep, cfg):
        return router_block
    if not cfg.integrations.bing_web_search.enabled:
        return {
            "ok": False,
            "error": "search_bing_web_disabled",
            "hint": "设置 integrations.bingWebSearch.enabled=true 与 subscriptionKey；"
            "或环境变量 AICD_BING_SEARCH_SUBSCRIPTION_KEY。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    key = bing_subscription_effective(cfg)
    if not key:
        return {
            "ok": False,
            "error": "search_bing_web_incomplete",
            "hint": "已启用但缺少 subscriptionKey。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    cnt = max(1, min(50, int(count)))
    params: dict[str, str] = {"q": q.strip(), "count": str(cnt)}
    if mkt and str(mkt).strip():
        params["mkt"] = str(mkt).strip()
    url = f"{ep}?{urlencode(params, quote_via=quote)}"
    headers = {
        "User-Agent": _ua(),
        "Accept": "application/json",
        "Ocp-Apim-Subscription-Key": key,
    }
    try:
        async with httpx.AsyncClient(timeout=timeout_sec, headers=headers) as client:
            r = await client.get(url)
        text = r.text[:500_000]
        pj = None
        try:
            pj = json.loads(r.text)
        except Exception:  # noqa: BLE001
            pj = None
        return {
            "ok": r.is_success,
            "status_code": r.status_code,
            "url": ep,
            "json": pj,
            "text": text if pj is None else None,
            "truncated": len(r.text) > len(text),
            "hint": None if r.is_success else text[:2000],
        }
    except httpx.TimeoutException:
        return {"ok": False, "error": "timeout"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)}


async def run_search_aliyun_iqs(
    cfg: AppConfig,
    *,
    q: str,
    engine_type: str | None,
    timeout_sec: float,
) -> dict[str, Any]:
    ep = (cfg.integrations.aliyun_iqs_search.endpoint or "").strip().rstrip("/")
    if not ep.startswith("http"):
        ep = "https://cloud-iqs.aliyuncs.com/search/genericSearch"
    if router_block := _block_check(ep, cfg):
        return router_block
    if not cfg.integrations.aliyun_iqs_search.enabled:
        return {
            "ok": False,
            "error": "search_aliyun_iqs_disabled",
            "hint": "设置 integrations.aliyunIqsSearch.enabled=true 与 apiKey；"
            "或环境变量 AICD_ALIYUN_IQS_API_KEY / TONGXIAO_API_KEY。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    key = aliyun_iqs_key_effective(cfg)
    if not key:
        return {
            "ok": False,
            "error": "search_aliyun_iqs_incomplete",
            "hint": "已启用但缺少 apiKey（或环境变量）。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    payload: dict[str, str] = {"query": q.strip()}
    et = (engine_type or "").strip()
    if et:
        payload["engineType"] = et
    headers = {
        "User-Agent": _ua(),
        "Accept": "application/json",
        "X-API-Key": key,
    }
    try:
        async with httpx.AsyncClient(timeout=timeout_sec, headers=headers) as client:
            low_ep = ep.lower()
            if low_ep.endswith("/search/genericsearch"):
                qparams: dict[str, str] = {"query": payload["query"]}
                if et:
                    qparams["engineType"] = et
                r = await client.get(
                    ep,
                    params=qparams,
                )
            else:
                r = await client.post(ep, json=payload)
        text = r.text[:500_000]
        pj = None
        try:
            pj = json.loads(r.text)
        except Exception:  # noqa: BLE001
            pj = None
        return {
            "ok": r.is_success,
            "status_code": r.status_code,
            "url": ep,
            "method": (
                "GET"
                if ep.lower().endswith("/search/genericsearch")
                else "POST"
            ),
            "json": pj,
            "text": text if pj is None else None,
            "truncated": len(r.text) > len(text),
            "hint": None if r.is_success else text[:2000],
        }
    except httpx.TimeoutException:
        return {"ok": False, "error": "timeout"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)}


_GH_SEARCH_RESOURCES = frozenset(
    {
        "repositories",
        "code",
        "issues",
        "commits",
        "users",
        "topics",
        "labels",
    }
)


async def run_search_github(
    cfg: AppConfig,
    *,
    resource: str,
    q: str,
    query: dict[str, Any] | None,
    timeout_sec: float,
) -> dict[str, Any]:
    base = (cfg.integrations.github.api_base_url or "https://api.github.com").strip().rstrip("/")
    res = str(resource or "repositories").strip().lower()
    if res not in _GH_SEARCH_RESOURCES:
        return {
            "ok": False,
            "error": "invalid_search_github_resource",
            "hint": f"resource 必须是其一：{', '.join(sorted(_GH_SEARCH_RESOURCES))}",
        }
    path = f"/search/{res}"
    url = base + path
    if router_block := _block_check(url, cfg):
        return router_block
    if not cfg.integrations.github_search.enabled:
        return {
            "ok": False,
            "error": "search_github_disabled",
            "hint": "设置 integrations.githubSearch.enabled=true 并配置 integrations.github.token（或 GITHUB_TOKEN）。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    token = github_token_effective(cfg)
    if not token:
        return {
            "ok": False,
            "error": "search_github_incomplete",
            "hint": "已启用但缺少 GitHub token。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    flat: dict[str, str] = {"q": q.strip()}
    if isinstance(query, dict):
        for k, v in query.items():
            if v is None or str(v) == "":
                continue
            flat[str(k)] = str(v)
    qstr = "?" + urlencode(flat, quote_via=quote, safe="/")
    full_url = base + path + qstr
    headers = {
        "Accept": cfg.integrations.github.accept or "application/vnd.github+json",
        "User-Agent": _ua(),
        "Authorization": f"Bearer {token}",
    }
    try:
        async with httpx.AsyncClient(timeout=timeout_sec, headers=headers) as client:
            r = await client.get(full_url)
        text = r.text[:500_000]
        pj = None
        try:
            pj = json.loads(r.text)
        except Exception:  # noqa: BLE001
            pj = None
        hint = None
        if r.status_code == 401:
            hint = "401：检查 integrations.github.token 或 GITHUB_TOKEN"
        elif r.status_code == 403 and "rate limit" in text.lower():
            hint = "速率限制：配置 token 可提高限额"
        return {
            "ok": r.is_success,
            "status_code": r.status_code,
            "url": full_url.split("?")[0],
            "json": pj,
            "text": text if pj is None else None,
            "truncated": len(r.text) > len(text),
            "hint": hint,
            "github_token_configured": True,
        }
    except httpx.TimeoutException:
        return {"ok": False, "error": "timeout"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)}


_GITLAB_SCOPES = frozenset(
    {
        "projects",
        "issues",
        "merge_requests",
        "milestones",
        "snippet_titles",
        "users",
        "wiki_blobs",
        "commits",
        "blobs",
        "notes",
    }
)


async def run_search_gitlab(
    cfg: AppConfig,
    *,
    scope: str,
    search: str,
    timeout_sec: float,
) -> dict[str, Any]:
    if not cfg.integrations.gitlab_search.enabled:
        return {
            "ok": False,
            "error": "search_gitlab_disabled",
            "hint": "设置 integrations.gitlabSearch.enabled=true、baseUrl、privateToken；"
            "或环境变量 AICD_GITLAB_PRIVATE_TOKEN。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    token = gitlab_token_effective(cfg)
    if not token:
        return {
            "ok": False,
            "error": "search_gitlab_incomplete",
            "hint": "已启用但缺少 privateToken。",
            "search_integrations_status": search_integrations_status_payload(cfg),
        }
    sc = str(scope or "projects").strip().lower()
    if sc not in _GITLAB_SCOPES:
        return {
            "ok": False,
            "error": "invalid_search_gitlab_scope",
            "hint": f"scope 必须是其一：{', '.join(sorted(_GITLAB_SCOPES))}",
        }
    base = (cfg.integrations.gitlab_search.base_url or "https://gitlab.com").strip().rstrip("/")
    api = f"{base}/api/v4/search"
    params = {"search": search.strip(), "scope": sc}
    url = f"{api}?{urlencode(params, quote_via=quote)}"
    if router_block := _block_check(url, cfg):
        return router_block
    headers = {
        "User-Agent": _ua(),
        "Accept": "application/json",
        "PRIVATE-TOKEN": token,
    }
    try:
        async with httpx.AsyncClient(timeout=timeout_sec, headers=headers) as client:
            r = await client.get(url)
        text = r.text[:500_000]
        pj = None
        try:
            pj = json.loads(r.text)
        except Exception:  # noqa: BLE001
            pj = None
        return {
            "ok": r.is_success,
            "status_code": r.status_code,
            "url": api,
            "json": pj,
            "text": text if pj is None else None,
            "truncated": len(r.text) > len(text),
            "hint": None if r.is_success else text[:2000],
        }
    except httpx.TimeoutException:
        return {"ok": False, "error": "timeout"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)}
