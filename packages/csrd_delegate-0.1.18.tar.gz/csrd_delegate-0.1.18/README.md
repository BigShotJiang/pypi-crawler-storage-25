# csrd-delegate

HTTP client delegate base class with retry support for FastAPI microservices.

**Package**: `csrd.delegate` · **Import**: `from csrd.delegate import BaseDelegate`

## What's included

- `BaseDelegate` — async HTTP client with header forwarding, retry via tenacity, and lifecycle (`close()` / `async with`)
- Response parsing via `csrd.models.model_parser`
- Configurable retry profiles (`conservative`, `aggressive`, `resilient`)
- httpx-specific response types (`ResponseHandler`, `ResponseHandlerMap`)

## Installation

```bash
uv pip install "csrd-delegate @ git+ssh://git@github.com/csrd-api/fastapi-common.git#subdirectory=packages/delegate"
```

## Dependencies

- `csrd-models`, `csrd-context` (Tier 2)
