import pytest
from dataclasses import dataclass
from typing import Any, AsyncGenerator, Type

from pydantic import BaseModel, ConfigDict
from sqlalchemy import inspect as sqla_inspect
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.ext.asyncio import AsyncSession

from simple_repository.utils import BaseDomainModel, BaseSchema
from src.simple_repository.abctract import IAsyncCrud, SA, DM, CS, PS
from src.simple_repository.implementation import AsyncCrud
from src.simple_repository.factory import crud_factory
from src.simple_repository.protocols import SqlaModel, DomainModel
from src.simple_repository.exceptions import NotFoundException

from tests.database import Base, async_session_maker, create_db, drop_db


@pytest.fixture(autouse=True)
async def setup_database():
    """Setup and teardown the test database."""
    await drop_db()
    await create_db()
    yield
    await drop_db()


@pytest.fixture
async def session() -> AsyncGenerator[AsyncSession, None]:
    """Provide an async session for tests."""
    async with async_session_maker() as session:
        yield session


class SqlaTestModel(Base):
    """SQLAlchemy model for testing."""

    __tablename__ = "test_table"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str]
    description: Mapped[str | None]


# --- Конкретная реализация для тестов ---
# Мы используем BaseDomainModel и BaseSchema из твоих utils,
# чтобы показать, как они работают в связке с репозиторием.
class BaseTestCrud(AsyncCrud[SA, DM, CS, PS]):
    def to_repr(self, object: SA) -> DM:
        if self.domain_model == self.sqla_model:
            return object
        if issubclass(self.domain_model, BaseDomainModel):
            return self.domain_model.model_validate(object)
        if issubclass(self.domain_model, BaseModel):
            return self.domain_model.model_validate(object)
        if self.domain_model is dict:
            return {col.key: getattr(object, col.key) for col in sqla_inspect(object.__class__).mapper.columns}
        return object

    def to_inner(self, data: CS | DM | PS) -> dict:
        if isinstance(data, dict):
            return data
        if isinstance(data, (BaseDomainModel, BaseSchema, BaseModel)):
            return data.model_dump(exclude_unset=True)
        return {k: v for k, v in data.__dict__.items() if not k.startswith("_")}


def factory_test(sqla_m, dom_m, c_s, p_s) -> _:
    """Вспомогательная функция для создания тестового репозитория"""
    base_class = crud_factory(sqla_m, dom_m, c_s, p_s)
    # Динамически подмешиваем логику маппинга
    return type(f"Test{base_class.__name__}", (BaseTestCrud, base_class), {})()


@pytest.fixture
def sqla_model() -> Type[SqlaTestModel]:
    """SQLAlchemy model for basic tests."""
    return SqlaTestModel


class DomainTestModel(BaseModel):
    """Pydantic model for testing."""

    id: int
    name: str
    description: str | None = None

    model_config = ConfigDict(from_attributes=True)


@pytest.fixture
def domain_model() -> Type[DomainTestModel]:
    """Pydantic model for basic tests."""
    return DomainTestModel


class CreateSchema(BaseModel):
    name: str
    description: str | None = None


@pytest.fixture
def create_schema() -> Type[CreateSchema]:
    """Pydantic schema for basic tests."""
    return CreateSchema


class PatchSchema(BaseModel):
    name: str | None = None
    description: str | None = None


@pytest.fixture
def patch_schema() -> Type[PatchSchema]:
    """Pydantic schema for basic tests."""
    return PatchSchema


@pytest.fixture
def crud(
    sqla_model, domain_model, create_schema, patch_schema
) -> IAsyncCrud[SqlaModel, DomainModel, CreateSchema, PatchSchema]:
    """Create CRUD repository for tests."""
    return factory_test(sqla_model, domain_model, create_schema, patch_schema)


def test_crud_factory_with_pydantic(
    sqla_model: Type[SqlaTestModel],
    domain_model: Type[DomainTestModel],
    create_schema: Type[CreateSchema],
    patch_schema: Type[PatchSchema],
):
    """Test crud_factory with Pydantic model."""

    crud = crud_factory(sqla_model, domain_model, create_schema, patch_schema)
    assert crud is not None


@pytest.mark.asyncio
async def test_crud_factory_with_dataclass(session: AsyncSession):
    """Test crud_factory with dataclass model."""

    @dataclass
    class SimpleDomainModel(BaseDomainModel):
        id: int
        name: str
        description: str | None = None

    @dataclass
    class DCCreateSchema(BaseSchema):
        name: str
        description: str | None = None

    @dataclass
    class DCPatchSchema(BaseSchema):
        name: str | None = None
        description: str | None = None

    impl_crud = factory_test(SqlaTestModel, SimpleDomainModel, DCCreateSchema, DCPatchSchema)
    assert impl_crud is not None

    dm = DCCreateSchema(name="filled")
    created = await impl_crud.create(session, dm)

    assert created.id > 0
    assert created.name == "filled"
    assert created.description is None

    data = DCPatchSchema(description="...")
    patched = await impl_crud.patch(session, data, created.id)

    assert patched.name == "filled"
    assert patched.description == "..."


@pytest.mark.asyncio
async def test_crud_factory_with_class(session: AsyncSession):
    """Test crud_factory with class model."""

    class SimpleDomainModel(BaseDomainModel):
        id: int
        name: str
        description: str | None

        def __init__(self, id: int = 0, name: str = "", description: str | None = None) -> None:
            self.id = id
            self.name = name
            self.description = description

    class ClassPatchSchema(BaseSchema):
        name: str | None = None
        description: str | None = None

        def __init__(self, name: str | None = None, description: str | None = None) -> None:
            self.name = name
            self.description = description

    class ClassCreateSchema(BaseSchema):
        name: str
        description: str | None

        def __init__(self, name: str, description: str | None = None) -> None:
            self.name = name
            self.description = description

    impl_crud = factory_test(SqlaTestModel, SimpleDomainModel, ClassCreateSchema, ClassPatchSchema)
    assert impl_crud is not None

    dm = ClassCreateSchema(name="filled")
    created = await impl_crud.create(session, dm)

    assert created.id > 0
    assert created.name == "filled"
    assert created.description is None

    data = ClassPatchSchema(description="...")
    patched = await impl_crud.patch(session, data, created.id)

    assert patched.name == "filled"
    assert patched.description == "..."


@pytest.mark.asyncio
async def test_crud_with_pure_dicts(session: AsyncSession):
    """Test CRUD using only dictionaries for models and schemas."""
    # Настраиваем репозиторий на работу со словарями
    impl_crud = factory_test(SqlaTestModel, dict, dict, dict)

    # Create
    data = {"name": "Dict Entity", "description": "I am a dict"}
    created = await impl_crud.create(session, data)
    assert isinstance(created, dict)
    assert created["name"] == "Dict Entity"
    assert "id" in created

    # Update (проверка логики извлечения ID из dict)
    created["name"] = "Updated Dict"
    updated = await impl_crud.update(session, created)
    assert updated["name"] == "Updated Dict"

    # Get Many with list
    results = await impl_crud.get_many(session, filter=[created["id"]])
    assert len(results) == 1
    assert results[0]["id"] == created["id"]


@pytest.mark.asyncio
async def test_crud_with_sqla_as_domain(session: AsyncSession):
    """Test using SQLAlchemy model as the Domain Model (zero-mapping)."""
    impl_crud = factory_test(SqlaTestModel, SqlaTestModel, dict, dict)

    created = await impl_crud.create(session, {"name": "Direct SA"})
    assert isinstance(created, SqlaTestModel)
    assert created.name == "Direct SA"

    # Проверка, что update работает с объектом SA (у которого есть .id)
    created.name = "Direct SA Updated"
    updated = await impl_crud.update(session, created)
    assert updated.name == "Direct SA Updated"


@pytest.mark.asyncio
async def test_filtering_and_pagination(session: AsyncSession, crud: IAsyncCrud):
    """Test advanced filtering and pagination."""
    # Создаем несколько записей
    for i in range(5):
        await crud.create(session, CreateSchema(name=f"User {i}", description="Test"))

    # Test count with filters
    count = await crud.count(session, filters={"description": "Test"})
    assert count == 5

    # Test get_all with limit/offset
    models, total = await crud.get_all(session, limit=2, offset=0, order_by="name")
    assert len(models) == 2
    assert total == 5


@pytest.mark.asyncio
async def test_bulk_operations(session: AsyncSession, crud: IAsyncCrud):
    """Test create_many and remove_many."""
    items = [DomainTestModel(id=123, name="Bulk 1"), DomainTestModel(id=124, name="Bulk 2")]

    # Create Many
    created_list = await crud.create_many(session, items, return_models=True)
    assert isinstance(created_list, list)
    assert len(created_list) == 2

    # Remove Many
    ids = [m.id for m in created_list]
    removed_count = await crud.remove_many(session, ids)
    assert removed_count == 2


def test_crud_class_name():
    class SimpleSqlaModel:
        __tablename__ = "simple"
        id: Mapped[int]
        field: Mapped[str]

    class SimpleDomainModel(BaseModel):
        id: int
        field: str

    crud = crud_factory(SimpleSqlaModel, SimpleDomainModel, CreateSchema, PatchSchema)
    assert crud.__name__ == "SimpleSqlaModelRepository"


@pytest.mark.asyncio
async def test_crud_operations(
    session: AsyncSession,
    crud: AsyncCrud[SqlaTestModel, DomainTestModel, CreateSchema, PatchSchema],
    domain_model: Type[DomainTestModel],
    create_schema: Type[CreateSchema],
    patch_schema: Type[PatchSchema],
):
    """Test basic CRUD operations."""
    # Create
    model = create_schema(name="Test", description="Description")
    created = await crud.create(session, model)
    assert created.id > 0
    assert created.name == "Test"

    # Read
    retrieved = await crud.get_one(session, created.id)
    assert retrieved is not None
    assert retrieved.name == created.name

    # Update
    retrieved.name = "Updated"
    updated = await crud.update(session, retrieved)
    assert updated.name == "Updated"

    # Patch
    data = patch_schema(name="Patched")

    patched = await crud.patch(session, data, retrieved.id)
    assert patched.name == "Patched"
    assert patched.description == "Description"

    # List
    models, count = await crud.get_all(session, order_by="id")
    assert len(models) == 1
    assert count == 1
    assert models[0].name == "Patched"
    assert isinstance(models[0], domain_model)

    # Filter
    filtred = await crud.get_many(session, filter="Description", column="description")
    assert len(filtred) == 1

    # Delete
    await crud.remove(session, created.id)

    with pytest.raises(NotFoundException):
        await crud.get_one(session, created.id)
