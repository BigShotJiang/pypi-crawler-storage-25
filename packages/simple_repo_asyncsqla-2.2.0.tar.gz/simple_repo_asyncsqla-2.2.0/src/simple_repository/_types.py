"""Type definitions for the repository pattern implementation."""

from typing import Any, TypeVar, Union
from uuid import UUID

from .protocols import SqlaModel, DomainModel, Schema

SA = TypeVar("SA", bound=SqlaModel)
DM = TypeVar("DM", bound=Union[DomainModel, dict, SqlaModel])
CS = TypeVar("CS", bound=Schema | dict)
PS = TypeVar("PS", bound=Schema | dict)

PrimitiveValue = Union[str, UUID, int, float, bool, None]
FilterValue = Union[PrimitiveValue, list[PrimitiveValue]]
IdValue = Union[str, UUID, int]
Filters = dict[str, Any]
