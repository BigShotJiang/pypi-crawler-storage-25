from typing import Any, Protocol

class SqlaModel(Protocol):
    __tablename__: str
    id: Any


class DomainModel(Protocol):
    pass

class Schema(Protocol):
    pass
