from typing import Type, cast

from .implementation import AsyncCrud
from ._types import DM, SA, CS, PS


def crud_factory(
    sqla_model: Type[SA],
    domain_model: Type[DM],
    create_schema: Type[CS],
    update_schema: Type[PS],
) -> Type[AsyncCrud[SA, DM, CS, PS]]:
    """Creates a type-safe CRUD repository for the given models."""
    new_class_name = f"{sqla_model.__name__}Repository"

    new_cls = type(
        new_class_name,
        (AsyncCrud,),
        {
            "sqla_model": sqla_model,
            "domain_model": domain_model,
        },
    )
    return cast(Type[AsyncCrud[SA, DM, CS, PS]], new_cls)
