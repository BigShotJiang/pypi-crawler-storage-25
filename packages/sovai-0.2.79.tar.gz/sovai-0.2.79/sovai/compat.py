"""
SDK-side compatibility checker.

On first API call, reads server response headers to detect version deprecation
warnings. Never crashes -- degraded functionality is better than no functionality.
"""
from __future__ import annotations

import logging
import warnings
from typing import Optional

logger = logging.getLogger(__name__)

# Module-level flag so we warn at most once per process
_COMPAT_CHECKED: bool = False
_DEPRECATION_WARNING_SHOWN: bool = False


def get_sdk_version() -> str:
    """Return the installed SDK version, falling back to '0.0.0'."""
    try:
        from importlib.metadata import version as _pkg_version
        return _pkg_version("sovai")
    except Exception:
        return "0.0.0"


def check_response_compat(response_headers: dict[str, str]) -> None:
    """
    Inspect server response headers for SDK compatibility signals.

    Called after every API response. Emits at most one user-facing warning
    per process lifetime to avoid log spam.

    Headers checked:
        X-SDK-Deprecation-Warning  -- soft warning, SDK is below recommended
        X-SDK-Upgrade-Required     -- hard signal, SDK is critically outdated
    """
    global _COMPAT_CHECKED, _DEPRECATION_WARNING_SHOWN

    deprecation_msg: Optional[str] = response_headers.get("X-SDK-Deprecation-Warning")
    upgrade_msg: Optional[str] = response_headers.get("X-SDK-Upgrade-Required")

    if upgrade_msg and not _DEPRECATION_WARNING_SHOWN:
        _DEPRECATION_WARNING_SHOWN = True
        warnings.warn(
            f"[sovai] SDK upgrade required: {upgrade_msg}. "
            f"Run: pip install --upgrade sovai",
            UserWarning,
            stacklevel=3,
        )
        logger.warning("sdk.upgrade_required", extra={"detail": upgrade_msg})

    elif deprecation_msg and not _DEPRECATION_WARNING_SHOWN:
        _DEPRECATION_WARNING_SHOWN = True
        warnings.warn(
            f"[sovai] {deprecation_msg}. "
            f"Run: pip install --upgrade sovai",
            DeprecationWarning,
            stacklevel=3,
        )
        logger.info("sdk.deprecation_warning", extra={"detail": deprecation_msg})

    _COMPAT_CHECKED = True


def reset_compat_state() -> None:
    """Reset module state -- useful for testing."""
    global _COMPAT_CHECKED, _DEPRECATION_WARNING_SHOWN
    _COMPAT_CHECKED = False
    _DEPRECATION_WARNING_SHOWN = False
