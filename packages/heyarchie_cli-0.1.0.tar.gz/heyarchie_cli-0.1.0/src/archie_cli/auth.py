"""Credential storage for the `archie` CLI.

Lookup order: explicit flag → env var → on-disk credentials → prompt the
user. The on-disk file at ``~/.archie/credentials.toml`` is chmod 600.
"""

from __future__ import annotations

import os
import stat
import sys
from dataclasses import dataclass
from pathlib import Path

try:
    import tomllib  # py311+
except ImportError:  # pragma: no cover
    import tomli as tomllib  # type: ignore[no-redef]


CREDENTIALS_PATH = Path.home() / ".archie" / "credentials.toml"
DEFAULT_PROFILE = "default"
DEFAULT_API_URL = "https://api.heyarchie.ai"


@dataclass(frozen=True)
class Credentials:
    """Resolved CLI credentials."""

    api_url: str
    api_key: str
    profile: str


class CredentialError(Exception):
    """Raised when credentials are missing or unreadable."""


def load_credentials(
    *,
    profile: str = DEFAULT_PROFILE,
    api_url_override: str | None = None,
    api_key_override: str | None = None,
) -> Credentials:
    """Resolve credentials, preferring explicit overrides → env → on-disk."""
    api_url = (
        api_url_override
        or os.environ.get("ARCHIE_API_URL")
        or _from_disk(profile, "api_url")
        or DEFAULT_API_URL
    )
    api_key = api_key_override or os.environ.get("ARCHIE_API_KEY") or _from_disk(profile, "api_key")
    if not api_key:
        raise CredentialError(
            "No API key found. Set ARCHIE_API_KEY, run `archie login`, or pass --api-key."
        )
    return Credentials(api_url=api_url.rstrip("/"), api_key=api_key, profile=profile)


def save_credentials(api_url: str, api_key: str, *, profile: str = DEFAULT_PROFILE) -> Path:
    """Persist credentials to ``~/.archie/credentials.toml`` (chmod 600)."""
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    existing: dict[str, dict[str, str]] = {}
    if CREDENTIALS_PATH.exists():
        try:
            with CREDENTIALS_PATH.open("rb") as fh:
                existing = tomllib.load(fh)  # type: ignore[assignment]
        except Exception:  # pragma: no cover — corrupt file → overwrite
            existing = {}
    existing[profile] = {"api_url": api_url.rstrip("/"), "api_key": api_key}
    text = _render_toml(existing)
    CREDENTIALS_PATH.write_text(text)
    os.chmod(CREDENTIALS_PATH, stat.S_IRUSR | stat.S_IWUSR)
    return CREDENTIALS_PATH


def _from_disk(profile: str, key: str) -> str | None:
    if not CREDENTIALS_PATH.exists():
        return None
    try:
        with CREDENTIALS_PATH.open("rb") as fh:
            data = tomllib.load(fh)
    except Exception as exc:  # pragma: no cover
        print(f"warning: failed to read {CREDENTIALS_PATH}: {exc}", file=sys.stderr)
        return None
    section = data.get(profile)
    if not isinstance(section, dict):
        return None
    value = section.get(key)
    return str(value) if value else None


def _render_toml(data: dict[str, dict[str, str]]) -> str:
    out: list[str] = []
    for profile, fields in sorted(data.items()):
        out.append(f"[{profile}]")
        for k in sorted(fields):
            v = fields[k].replace('"', '\\"')
            out.append(f'{k} = "{v}"')
        out.append("")
    return "\n".join(out)
