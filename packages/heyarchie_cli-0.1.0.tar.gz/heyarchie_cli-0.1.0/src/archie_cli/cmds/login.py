"""``archie login`` — paste an API key, persist to ~/.archie/credentials.toml."""

from __future__ import annotations

import click

from archie_cli.auth import (
    DEFAULT_API_URL,
    DEFAULT_PROFILE,
    save_credentials,
)


@click.command("login")
@click.option(
    "--api-url",
    default=DEFAULT_API_URL,
    show_default=True,
    help="API base URL. Override for staging or self-hosted tiers.",
)
@click.option(
    "--api-key",
    default=None,
    help="Paste here, or omit and we'll prompt without echoing.",
)
@click.option(
    "--profile",
    default=DEFAULT_PROFILE,
    show_default=True,
    help="Save under a named profile (e.g. dev, staging).",
)
def login_cmd(api_url: str, api_key: str | None, profile: str) -> None:
    """Save an API key to ~/.archie/credentials.toml.

    Today this expects an Archie session JWT or Archie OAuth JWT (sent as
    a Bearer token). WorkOS-issued `sk_*` keys are not yet validated
    server-side — see docs/connect/api-keys-flow.md.
    """
    if not api_key:
        api_key = click.prompt("API key", hide_input=True, confirmation_prompt=False)
    api_key = api_key.strip()
    if not api_key:
        raise click.ClickException("API key cannot be empty.")
    path = save_credentials(api_url=api_url, api_key=api_key, profile=profile)
    click.echo(f"Saved credentials to {path} (profile={profile!r}).")
    click.echo("Try: archie workstreams list")
