"""``archie skills …`` — generic skill catalogue + invoke.

Extends the CLI beyond the 9 workstream-specific commands to the full
public skill catalogue (51 skills at the time of writing). Mirrors the
SDK shape: ``client.skills.list()`` + ``client.skills.invoke(slug, ...)``.

* ``archie skills list [--category X] [--search Q]`` — table of every
  visible skill, with category + cluster + streaming flag.
* ``archie skills invoke <slug> [--input @file.json | --input '{json}']``
  — POST the input to ``/api/v1/skills/{slug}/invoke`` and render the
  unwrapped response.

Auth + ``--json`` + ``--profile`` flags share the same decorator as the
workstream commands.
"""

from __future__ import annotations

import asyncio
import json as jsonlib
import sys
from pathlib import Path
from typing import Any

import click
import httpx
from rich.console import Console
from rich.json import JSON
from rich.table import Table

from archie_cli.auth import CredentialError, load_credentials
from archie_cli.client import ArchieAPIError, ArchieClient

_console = Console()
_err_console = Console(stderr=True, style="bold red")


def _global_options(fn):
    """Auth + output flags — same shape as workstreams.py to keep UX uniform."""
    fn = click.option(
        "--json",
        "as_json",
        is_flag=True,
        default=False,
        help="Emit raw JSON to stdout (machine-friendly).",
    )(fn)
    fn = click.option(
        "--profile",
        default=None,
        help="Credentials profile in ~/.archie/credentials.toml (default: 'default').",
    )(fn)
    fn = click.option(
        "--api-url",
        default=None,
        envvar="ARCHIE_API_URL",
        help="API base URL. Falls back to env ARCHIE_API_URL or saved credentials.",
    )(fn)
    fn = click.option(
        "--api-key",
        default=None,
        envvar="ARCHIE_API_KEY",
        help="Bearer token. Falls back to env ARCHIE_API_KEY or saved credentials.",
    )(fn)
    return fn


def _resolve_creds(api_url: str | None, api_key: str | None, profile: str | None):
    try:
        return load_credentials(
            profile=profile or "default",
            api_url_override=api_url,
            api_key_override=api_key,
        )
    except CredentialError as exc:
        raise click.ClickException(str(exc)) from exc


def _run(coro):
    try:
        return asyncio.run(coro)
    except ArchieAPIError as exc:
        _err_console.print(str(exc))
        raise click.exceptions.Exit(2) from exc
    except KeyboardInterrupt:
        _err_console.print("\nInterrupted.")
        raise click.exceptions.Exit(130) from None


@click.group("skills")
def skills_group() -> None:
    """Browse and invoke the Archie skill catalogue."""


@skills_group.command("list")
@_global_options
@click.option("--category", default=None, help="Filter by category (e.g. transactions, tax).")
@click.option(
    "--search",
    "search",
    default=None,
    help="Case-insensitive substring match on slug or description.",
)
def list_cmd(
    api_key: str | None,
    api_url: str | None,
    profile: str | None,
    as_json: bool,
    category: str | None,
    search: str | None,
) -> None:
    """List the skill catalogue visible to the caller."""
    creds = _resolve_creds(api_url, api_key, profile)

    async def go() -> list[dict[str, Any]]:
        # The catalogue lives at /api/v1/skills (GET) — separate from the
        # /api/v1/skills/{slug}/invoke surface. We hit it directly to avoid
        # adding a bespoke client method just for the CLI.
        async with httpx.AsyncClient(
            base_url=creds.api_url,
            headers={"Authorization": f"Bearer {creds.api_key}"},
            timeout=15.0,
        ) as cli:
            resp = await cli.get("/api/v1/skills")
            if resp.status_code >= 400:
                raise ArchieAPIError(
                    resp.status_code,
                    resp.json()
                    if resp.headers.get("content-type", "").startswith("application/json")
                    else resp.text,
                )
            body = resp.json()
        return body.get("data") if isinstance(body, dict) else body

    skills = _run(go()) or []
    if category:
        skills = [s for s in skills if s.get("category") == category]
    if search:
        needle = search.lower()
        skills = [
            s
            for s in skills
            if needle in (s.get("slug", "") + " " + s.get("description", "")).lower()
        ]

    if as_json:
        sys.stdout.write(jsonlib.dumps(skills, indent=2, default=str))
        sys.stdout.write("\n")
        return

    if not skills:
        _console.print("[dim]No skills match.[/dim]")
        return

    table = Table(title=f"{len(skills)} skill(s)")
    table.add_column("Slug", style="cyan")
    table.add_column("Category", style="magenta")
    table.add_column("Streams")
    table.add_column("Description")
    for s in sorted(skills, key=lambda x: x.get("slug", "")):
        table.add_row(
            s.get("slug", ""),
            s.get("category", ""),
            "yes" if s.get("streaming") else "no",
            (s.get("description") or "")[:80],
        )
    _console.print(table)


@skills_group.command("invoke")
@_global_options
@click.argument("slug")
@click.option(
    "--input",
    "input_",
    default="{}",
    show_default=True,
    help=(
        "Skill input as inline JSON (e.g. '--input \\'{\"query\":\"...\"}\\'') "
        "or a file path prefixed with @ (e.g. '--input @body.json'). "
        "Default is empty object."
    ),
)
def invoke_cmd(
    api_key: str | None,
    api_url: str | None,
    profile: str | None,
    as_json: bool,
    slug: str,
    input_: str,
) -> None:
    """Invoke a skill by its public slug (e.g. ``ask_archie``, ``tax.advise``).

    The slug accepts both the friendly name (``tax.advise``) and the
    internal slug (``advise_tax``). The route translates either to
    ``/api/v1/skills/{slug}/invoke`` server-side.
    """
    payload = _parse_input(input_)
    creds = _resolve_creds(api_url, api_key, profile)

    async def go() -> dict[str, Any]:
        async with ArchieClient(creds) as cli:
            return await cli.invoke_skill(slug, payload)

    out = _run(go())
    if as_json:
        sys.stdout.write(jsonlib.dumps(out, indent=2, default=str))
        sys.stdout.write("\n")
    else:
        _console.print(JSON.from_data(out))


def _parse_input(value: str) -> dict[str, Any]:
    """``--input`` accepts inline JSON, ``@path``, or ``-`` for stdin."""
    text = value
    if value.startswith("@"):
        path = Path(value[1:])
        if not path.exists():
            raise click.BadParameter(f"input file not found: {path}", param_hint="--input")
        text = path.read_text()
    elif value == "-":
        text = sys.stdin.read()
    try:
        parsed = jsonlib.loads(text)
    except jsonlib.JSONDecodeError as exc:
        raise click.BadParameter(
            f"--input is not valid JSON: {exc.msg} (at line {exc.lineno} col {exc.colno})",
            param_hint="--input",
        ) from exc
    if not isinstance(parsed, dict):
        raise click.BadParameter(
            "--input must be a JSON object (got non-object)", param_hint="--input"
        )
    return parsed
