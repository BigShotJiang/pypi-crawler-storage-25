"""``archie workstreams …`` — list, describe, run, status, cancel, logs."""

from __future__ import annotations

import asyncio
import json as jsonlib
import sys
from typing import Any

import click
from rich.console import Console
from rich.json import JSON
from rich.table import Table

from archie_cli.auth import CredentialError, load_credentials
from archie_cli.client import ArchieAPIError, ArchieClient

_console = Console()
_err_console = Console(stderr=True, style="bold red")


def _global_options(fn):
    """Attach the auth + output flags every workstream command needs."""
    fn = click.option(
        "--json",
        "as_json",
        is_flag=True,
        default=False,
        help="Emit raw JSON to stdout (machine-friendly).",
    )(fn)
    fn = click.option(
        "--profile",
        default=None,
        help="Credentials profile in ~/.archie/credentials.toml (default: 'default').",
    )(fn)
    fn = click.option(
        "--api-url",
        default=None,
        envvar="ARCHIE_API_URL",
        help="API base URL. Falls back to env ARCHIE_API_URL or saved credentials.",
    )(fn)
    fn = click.option(
        "--api-key",
        default=None,
        envvar="ARCHIE_API_KEY",
        help="Bearer token. Falls back to env ARCHIE_API_KEY or saved credentials.",
    )(fn)
    return fn


def _resolve_creds(api_url: str | None, api_key: str | None, profile: str | None):
    try:
        return load_credentials(
            profile=profile or "default",
            api_url_override=api_url,
            api_key_override=api_key,
        )
    except CredentialError as exc:
        raise click.ClickException(str(exc)) from exc


def _emit(payload: Any, *, as_json: bool) -> None:
    if as_json:
        sys.stdout.write(jsonlib.dumps(payload, indent=2, default=str))
        sys.stdout.write("\n")
    else:
        _console.print(JSON.from_data(payload))


def _run(coro):
    """Bridge sync click handlers to async client calls."""
    try:
        return asyncio.run(coro)
    except ArchieAPIError as exc:
        _err_console.print(str(exc))
        raise click.exceptions.Exit(2) from exc
    except KeyboardInterrupt:
        _err_console.print("\nInterrupted.")
        raise click.exceptions.Exit(130) from None


@click.group("workstreams")
def workstreams_group() -> None:
    """Operate on Archie workstreams (templates, blueprints, cycles, tasks)."""


@workstreams_group.command("list")
@_global_options
@click.option("--scope", type=click.Choice(["plan", "user", "team", "firm", "gallery"]))
@click.option("--status", type=click.Choice(["draft", "active", "archived"]))
@click.option("--limit", type=click.IntRange(1, 100), default=20, show_default=True)
@click.option("--cursor", default=None, help="Opaque pagination cursor from a previous response.")
def list_cmd(
    api_key: str | None,
    api_url: str | None,
    profile: str | None,
    as_json: bool,
    scope: str | None,
    status: str | None,
    limit: int,
    cursor: str | None,
) -> None:
    """List workstreams visible to the caller."""
    creds = _resolve_creds(api_url, api_key, profile)

    async def go():
        async with ArchieClient(creds) as cli:
            return await cli.workstreams_list(
                scope=scope,
                status=status,
                limit=limit,
                cursor=cursor,
            )

    out = _run(go())
    if as_json:
        _emit(out, as_json=True)
        return
    items = out.get("items") or []
    if not items:
        _console.print("[dim]No workstreams visible.[/dim]")
        return
    table = Table(title=f"{len(items)} workstream(s)")
    table.add_column("Permakey", style="cyan")
    table.add_column("Name")
    table.add_column("Mode", style="magenta")
    table.add_column("Status")
    for w in items:
        table.add_row(
            w.get("permakey", ""),
            w.get("name", ""),
            w.get("execution_mode", ""),
            w.get("status", ""),
        )
    _console.print(table)
    next_cursor = out.get("next_cursor")
    if next_cursor:
        _console.print(f"\n[dim]More results: --cursor {next_cursor}[/dim]")


@workstreams_group.command("describe")
@_global_options
@click.argument("workstream_id")
def describe_cmd(
    api_key: str | None,
    api_url: str | None,
    profile: str | None,
    as_json: bool,
    workstream_id: str,
) -> None:
    """Describe a workstream (UUID, slug, or 7-char permakey)."""
    creds = _resolve_creds(api_url, api_key, profile)

    async def go():
        async with ArchieClient(creds) as cli:
            return await cli.workstreams_describe(workstream_id)

    out = _run(go())
    _emit(out, as_json=as_json)


@workstreams_group.command("run")
@_global_options
@click.argument("workstream_id")
@click.option("--client-id", default=None, help="Client UUID to run against.")
@click.option("--period", default=None, help="Period label (e.g. FY26-Q1).")
@click.option(
    "--var",
    "vars_",
    multiple=True,
    metavar="K=V",
    help="Runtime variable. May be repeated. Use JSON for non-string values: --var qty='[1,2]'.",
)
@click.option(
    "--idempotency-key",
    default=None,
    help="Caller-supplied stable token; safe-retry within 24h.",
)
def run_cmd(
    api_key: str | None,
    api_url: str | None,
    profile: str | None,
    as_json: bool,
    workstream_id: str,
    client_id: str | None,
    period: str | None,
    vars_: tuple[str, ...],
    idempotency_key: str | None,
) -> None:
    """Start a workstream cycle and print the cycle id + URLs."""
    runtime_vars: dict[str, Any] = {}
    for v in vars_:
        if "=" not in v:
            raise click.BadParameter(f"--var must be K=V (got {v!r})")
        key, _, val = v.partition("=")
        try:
            runtime_vars[key] = jsonlib.loads(val)
        except jsonlib.JSONDecodeError:
            runtime_vars[key] = val
    creds = _resolve_creds(api_url, api_key, profile)

    async def go():
        async with ArchieClient(creds) as cli:
            return await cli.workstreams_run(
                workstream_id,
                client_id=client_id,
                period=period,
                runtime_vars=runtime_vars or None,
                idempotency_key=idempotency_key,
            )

    out = _run(go())
    _emit(out, as_json=as_json)


@workstreams_group.command("status")
@_global_options
@click.argument("cycle_id")
def status_cmd(
    api_key: str | None,
    api_url: str | None,
    profile: str | None,
    as_json: bool,
    cycle_id: str,
) -> None:
    """Show the current state of a cycle."""
    creds = _resolve_creds(api_url, api_key, profile)

    async def go():
        async with ArchieClient(creds) as cli:
            return await cli.workstreams_status(cycle_id)

    out = _run(go())
    _emit(out, as_json=as_json)


@workstreams_group.command("cancel")
@_global_options
@click.argument("cycle_id")
@click.option("--reason", default=None, help="Audit-trail reason (recommended).")
@click.option("--idempotency-key", default=None, help="Caller-supplied stable token.")
def cancel_cmd(
    api_key: str | None,
    api_url: str | None,
    profile: str | None,
    as_json: bool,
    cycle_id: str,
    reason: str | None,
    idempotency_key: str | None,
) -> None:
    """Cancel a running cycle."""
    creds = _resolve_creds(api_url, api_key, profile)

    async def go():
        async with ArchieClient(creds) as cli:
            return await cli.workstreams_cancel(
                cycle_id,
                reason=reason,
                idempotency_key=idempotency_key,
            )

    out = _run(go())
    _emit(out, as_json=as_json)


@workstreams_group.command("logs")
@_global_options
@click.argument("cycle_id")
@click.option("--follow/--no-follow", "follow", default=True, show_default=True)
def logs_cmd(
    api_key: str | None,
    api_url: str | None,
    profile: str | None,
    as_json: bool,
    cycle_id: str,
    follow: bool,
) -> None:
    """Stream cycle events via SSE.

    Default is `--follow` (long-lived); use `--no-follow` to read whatever is
    buffered and exit.
    """
    creds = _resolve_creds(api_url, api_key, profile)

    async def go():
        async with ArchieClient(creds) as cli:
            async for event in cli.workstreams_events(cycle_id):
                if as_json:
                    sys.stdout.write(jsonlib.dumps(event, default=str) + "\n")
                    sys.stdout.flush()
                else:
                    _console.print(JSON.from_data(event))
                if not follow:
                    # Snapshot mode — exit after the first batch lull.
                    if event.get("kind") in {"finalization", "completed", "failed", "cancelled"}:
                        break

    _run(go())
