"""Archie Connect CLI — `archie` console script.

Surfaces the Connect platform as terminal commands. Read-friendly when
attached to a TTY (rich-rendered tables, colors); machine-friendly when
piped (`--json`).

Auth is bearer-only today: an Archie session JWT or an Archie OAuth JWT.
WorkOS-managed `sk_*` API keys are not yet validated server-side — see
`docs/connect/api-keys-flow.md` for the architectural decision pending.
"""

__version__ = "0.1.0"
