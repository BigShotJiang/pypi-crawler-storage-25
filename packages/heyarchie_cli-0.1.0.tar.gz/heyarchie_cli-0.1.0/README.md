# archie CLI

Command-line interface for the Archie Connect platform.

## Install

```bash
# from PyPI (when published)
pipx install heyarchie-cli

# or from this repo for development
pip install -e apps/cli
```

`pipx` is recommended; it installs `archie` as a self-contained executable on
your PATH without touching system Python packages.

## Authenticate

```bash
archie login --api-url https://api.heyarchie.ai
# Then paste your bearer token at the prompt (input is hidden).
```

This writes `~/.archie/credentials.toml` (chmod 600) under the `[default]`
profile. Override per-call with `--profile`, `--api-key`, or env vars
`ARCHIE_API_KEY` / `ARCHIE_API_URL`.

> Today the bearer must be an **Archie session JWT** or **Archie OAuth JWT**.
> WorkOS-issued `sk_*` API keys are not yet validated server-side — see
> [`docs/connect/api-keys-flow.md`](../../docs/connect/api-keys-flow.md) for
> the architectural decision pending.

## Commands

```text
archie login                                 Save bearer credentials.
archie workstreams list [--scope ...]        List visible workstreams.
archie workstreams describe <id>             Show metadata + step graph.
archie workstreams run <id> [--var k=v]      Start a cycle.
archie workstreams status <cycle_id>         Show cycle progress.
archie workstreams cancel <cycle_id>         Cancel a running cycle.
archie workstreams logs <cycle_id>           Stream SSE events live.
```

`workstream_id` accepts a UUID, a workstream slug, or a 7-char permakey;
the API resolves all three.

## Examples

```bash
# List workstreams
archie workstreams list

# JSON output (pipe-friendly)
archie workstreams list --json | jq '.items[].permakey'

# Start a cycle and watch it run
CYCLE=$(archie workstreams run abc1234 --period 2026-Q1 --json | jq -r .cycle_id)
archie workstreams logs "$CYCLE"
```

## Environment variables

| Variable | Purpose | Default |
|---|---|---|
| `ARCHIE_API_URL` | API base URL | `https://api.heyarchie.ai` |
| `ARCHIE_API_KEY` | Bearer token | (none) |

CLI flags take precedence over env, which takes precedence over the
on-disk credentials file.

## Where this lives

`apps/cli/` in the `archie-platform-v2` monorepo. PRs welcome.
