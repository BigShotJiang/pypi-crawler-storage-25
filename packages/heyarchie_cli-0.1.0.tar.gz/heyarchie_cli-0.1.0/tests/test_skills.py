"""Tests for ``archie skills`` subcommand group.

Covers the input-parsing edge cases (inline JSON, ``@path``, ``-`` stdin,
non-object payloads, bad JSON) plus a smoke that the command group
registers and renders --help cleanly. The actual HTTP roundtrip is
exercised by the back-to-front UAT, not unit tests.
"""

from __future__ import annotations

from pathlib import Path

import click
import pytest
from click.testing import CliRunner

from archie_cli.cmds.skills import _parse_input, skills_group


def test_skills_help_lists_subcommands() -> None:
    runner = CliRunner()
    result = runner.invoke(skills_group, ["--help"])
    assert result.exit_code == 0, result.output
    assert "list" in result.output
    assert "invoke" in result.output


def test_skills_invoke_help_documents_input_flag() -> None:
    runner = CliRunner()
    result = runner.invoke(skills_group, ["invoke", "--help"])
    assert result.exit_code == 0
    assert "--input" in result.output
    assert "JSON" in result.output


def test_parse_input_inline_json_object() -> None:
    assert _parse_input('{"query": "hello"}') == {"query": "hello"}


def test_parse_input_default_empty_object() -> None:
    assert _parse_input("{}") == {}


def test_parse_input_from_file(tmp_path: Path) -> None:
    body = tmp_path / "body.json"
    body.write_text('{"foo": 1, "bar": [2, 3]}')
    assert _parse_input(f"@{body}") == {"foo": 1, "bar": [2, 3]}


def test_parse_input_missing_file_raises(tmp_path: Path) -> None:
    nope = tmp_path / "does-not-exist.json"
    with pytest.raises(click.BadParameter, match="input file not found"):
        _parse_input(f"@{nope}")


def test_parse_input_invalid_json_raises() -> None:
    with pytest.raises(click.BadParameter, match="not valid JSON"):
        _parse_input("{not json")


def test_parse_input_non_object_raises() -> None:
    with pytest.raises(click.BadParameter, match="must be a JSON object"):
        _parse_input("[1, 2, 3]")


def test_parse_input_string_literal_rejected() -> None:
    with pytest.raises(click.BadParameter, match="must be a JSON object"):
        _parse_input('"just a string"')


def test_parse_input_stdin(monkeypatch: pytest.MonkeyPatch) -> None:
    import io
    import sys

    monkeypatch.setattr(sys, "stdin", io.StringIO('{"from": "stdin"}'))
    assert _parse_input("-") == {"from": "stdin"}
