"""Tests for MarketDataClient."""

import pytest

from trading_mcp_sdk.market_data import MarketDataClient


class TestMarketDataClient:
    @pytest.mark.asyncio
    async def test_get_quote(self, fake_conn):
        client = MarketDataClient(fake_conn)
        await client.get_quote("AAPL")
        fake_conn.call_tool.assert_called_once_with(
            "get_quote", {"symbol": "AAPL", "exchange": "AUTO"}
        )

    @pytest.mark.asyncio
    async def test_get_quote_custom_exchange(self, fake_conn):
        client = MarketDataClient(fake_conn)
        await client.get_quote("AAPL", exchange="NASDAQ")
        fake_conn.call_tool.assert_called_once_with(
            "get_quote", {"symbol": "AAPL", "exchange": "NASDAQ"}
        )

    @pytest.mark.asyncio
    async def test_get_ohlcv(self, fake_conn):
        client = MarketDataClient(fake_conn)
        await client.get_ohlcv("AAPL", "1d")
        fake_conn.call_tool.assert_called_once_with(
            "get_ohlcv",
            {
                "symbol": "AAPL",
                "timeframe": "1d",
                "from_date": "",
                "to_date": "",
                "limit": 200,
            },
        )

    @pytest.mark.asyncio
    async def test_get_ohlcv_custom_params(self, fake_conn):
        client = MarketDataClient(fake_conn)
        await client.get_ohlcv(
            "MSFT", "1h", from_date="2024-01-01", to_date="2024-06-01", limit=50
        )
        fake_conn.call_tool.assert_called_once_with(
            "get_ohlcv",
            {
                "symbol": "MSFT",
                "timeframe": "1h",
                "from_date": "2024-01-01",
                "to_date": "2024-06-01",
                "limit": 50,
            },
        )

    @pytest.mark.asyncio
    async def test_search_symbols(self, fake_conn):
        client = MarketDataClient(fake_conn)
        await client.search_symbols("Apple")
        fake_conn.call_tool.assert_called_once_with(
            "search_symbols",
            {"query": "Apple", "asset_type": "all", "limit": 10},
        )

    @pytest.mark.asyncio
    async def test_search_symbols_custom(self, fake_conn):
        client = MarketDataClient(fake_conn)
        await client.search_symbols("BTC", asset_type="crypto", limit=5)
        fake_conn.call_tool.assert_called_once_with(
            "search_symbols",
            {"query": "BTC", "asset_type": "crypto", "limit": 5},
        )

    @pytest.mark.asyncio
    async def test_get_market_movers(self, fake_conn):
        client = MarketDataClient(fake_conn)
        await client.get_market_movers("gainers")
        fake_conn.call_tool.assert_called_once_with(
            "get_market_movers",
            {"mover_type": "gainers", "market": "stocks", "limit": 10},
        )

    @pytest.mark.asyncio
    async def test_get_company_info(self, fake_conn):
        client = MarketDataClient(fake_conn)
        await client.get_company_info("AAPL")
        fake_conn.call_tool.assert_called_once_with(
            "get_company_info", {"symbol": "AAPL"}
        )

    @pytest.mark.asyncio
    async def test_return_value_passthrough(self, fake_conn):
        fake_conn.call_tool.return_value = {"price": 150.0, "symbol": "AAPL"}
        client = MarketDataClient(fake_conn)
        result = await client.get_quote("AAPL")
        assert result["price"] == 150.0
