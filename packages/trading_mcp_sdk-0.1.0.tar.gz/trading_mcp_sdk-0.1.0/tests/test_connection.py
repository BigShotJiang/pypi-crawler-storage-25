"""Tests for the MCPConnection class."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from trading_mcp_sdk._connection import MCPConnection


class TestMCPConnection:
    def test_init(self):
        conn = MCPConnection("python", ["-m", "server"])
        assert not conn.connected

    @pytest.mark.asyncio
    async def test_call_tool_not_connected(self):
        conn = MCPConnection("python")
        with pytest.raises(RuntimeError, match="Not connected"):
            await conn.call_tool("get_quote", {"symbol": "AAPL"})

    @pytest.mark.asyncio
    async def test_list_tools_not_connected(self):
        conn = MCPConnection("python")
        with pytest.raises(RuntimeError, match="Not connected"):
            await conn.list_tools()

    @pytest.mark.asyncio
    async def test_call_tool_json_result(self):
        conn = MCPConnection("python")
        # Manually set session to a mock
        mock_session = AsyncMock()
        result_data = {"price": 150.0, "symbol": "AAPL"}

        text_block = MagicMock()
        text_block.text = json.dumps(result_data)

        mock_result = MagicMock()
        mock_result.content = [text_block]

        mock_session.call_tool = AsyncMock(return_value=mock_result)
        conn._session = mock_session

        result = await conn.call_tool("get_quote", {"symbol": "AAPL"})
        assert result == result_data
        mock_session.call_tool.assert_called_once_with("get_quote", {"symbol": "AAPL"})

    @pytest.mark.asyncio
    async def test_call_tool_text_result(self):
        conn = MCPConnection("python")
        mock_session = AsyncMock()

        text_block = MagicMock()
        text_block.text = "not json"

        mock_result = MagicMock()
        mock_result.content = [text_block]

        mock_session.call_tool = AsyncMock(return_value=mock_result)
        conn._session = mock_session

        result = await conn.call_tool("some_tool", {})
        assert result == "not json"

    @pytest.mark.asyncio
    async def test_call_tool_empty_content(self):
        conn = MCPConnection("python")
        mock_session = AsyncMock()

        mock_result = MagicMock()
        mock_result.content = []

        mock_session.call_tool = AsyncMock(return_value=mock_result)
        conn._session = mock_session

        result = await conn.call_tool("some_tool", {})
        assert result is None

    @pytest.mark.asyncio
    async def test_call_tool_no_text_attr(self):
        conn = MCPConnection("python")
        mock_session = AsyncMock()

        block = MagicMock(spec=[])  # no attributes
        mock_result = MagicMock()
        mock_result.content = [block]

        mock_session.call_tool = AsyncMock(return_value=mock_result)
        conn._session = mock_session

        result = await conn.call_tool("some_tool", {})
        assert result is None

    @pytest.mark.asyncio
    async def test_call_tool_default_arguments(self):
        conn = MCPConnection("python")
        mock_session = AsyncMock()
        mock_result = MagicMock()
        mock_result.content = []
        mock_session.call_tool = AsyncMock(return_value=mock_result)
        conn._session = mock_session

        await conn.call_tool("tool_name")
        mock_session.call_tool.assert_called_once_with("tool_name", {})

    @pytest.mark.asyncio
    async def test_list_tools(self):
        conn = MCPConnection("python")
        mock_session = AsyncMock()

        tool1 = MagicMock()
        tool1.name = "get_quote"
        tool2 = MagicMock()
        tool2.name = "get_ohlcv"

        list_result = MagicMock()
        list_result.tools = [tool1, tool2]

        mock_session.list_tools = AsyncMock(return_value=list_result)
        conn._session = mock_session

        names = await conn.list_tools()
        assert names == ["get_quote", "get_ohlcv"]

    @pytest.mark.asyncio
    async def test_connected_property(self):
        conn = MCPConnection("python")
        assert not conn.connected
        conn._session = MagicMock()
        assert conn.connected

    @pytest.mark.asyncio
    async def test_disconnect_clears_state(self):
        conn = MCPConnection("python")
        conn._session = MagicMock()
        conn._stack = AsyncMock()
        await conn.disconnect()
        assert not conn.connected
        assert conn._stack is None

    @pytest.mark.asyncio
    async def test_disconnect_noop_when_not_connected(self):
        conn = MCPConnection("python")
        await conn.disconnect()  # should not raise
        assert not conn.connected
