"""Tests for SECClient."""

import pytest

from trading_mcp_sdk.sec import SECClient


class TestSECClient:
    @pytest.mark.asyncio
    async def test_search_filings_defaults(self, fake_conn):
        client = SECClient(fake_conn)
        await client.search_filings("Apple")
        fake_conn.call_tool.assert_called_once_with(
            "search_filings",
            {"query": "Apple", "form_type": "all", "limit": 5},
        )

    @pytest.mark.asyncio
    async def test_search_filings_custom(self, fake_conn):
        client = SECClient(fake_conn)
        await client.search_filings("AAPL", form_type="10-K", limit=3)
        fake_conn.call_tool.assert_called_once_with(
            "search_filings",
            {"query": "AAPL", "form_type": "10-K", "limit": 3},
        )

    @pytest.mark.asyncio
    async def test_get_filing_summary_defaults(self, fake_conn):
        client = SECClient(fake_conn)
        await client.get_filing_summary("0001234567-24-000001")
        fake_conn.call_tool.assert_called_once_with(
            "get_filing_summary",
            {"accession_number": "0001234567-24-000001", "max_chars": 3000},
        )

    @pytest.mark.asyncio
    async def test_get_filing_summary_with_sections(self, fake_conn):
        client = SECClient(fake_conn)
        await client.get_filing_summary(
            "0001234567-24-000001",
            sections=["risk_factors", "mda"],
            max_chars=5000,
        )
        fake_conn.call_tool.assert_called_once_with(
            "get_filing_summary",
            {
                "accession_number": "0001234567-24-000001",
                "sections": ["risk_factors", "mda"],
                "max_chars": 5000,
            },
        )

    @pytest.mark.asyncio
    async def test_get_filing_summary_no_sections(self, fake_conn):
        """When sections=None, the key should not be sent."""
        client = SECClient(fake_conn)
        await client.get_filing_summary("acc-123")
        args = fake_conn.call_tool.call_args[0][1]
        assert "sections" not in args

    @pytest.mark.asyncio
    async def test_get_key_financials_defaults(self, fake_conn):
        client = SECClient(fake_conn)
        await client.get_key_financials("AAPL")
        fake_conn.call_tool.assert_called_once_with(
            "get_key_financials", {"symbol": "AAPL", "period": "annual"}
        )

    @pytest.mark.asyncio
    async def test_get_key_financials_quarterly(self, fake_conn):
        client = SECClient(fake_conn)
        await client.get_key_financials("MSFT", period="quarterly")
        fake_conn.call_tool.assert_called_once_with(
            "get_key_financials", {"symbol": "MSFT", "period": "quarterly"}
        )

    @pytest.mark.asyncio
    async def test_get_risk_factors_defaults(self, fake_conn):
        client = SECClient(fake_conn)
        await client.get_risk_factors("AAPL")
        fake_conn.call_tool.assert_called_once_with(
            "get_risk_factors", {"symbol": "AAPL", "chunk_size": 800}
        )

    @pytest.mark.asyncio
    async def test_get_risk_factors_custom_chunk(self, fake_conn):
        client = SECClient(fake_conn)
        await client.get_risk_factors("TSLA", chunk_size=1200)
        fake_conn.call_tool.assert_called_once_with(
            "get_risk_factors", {"symbol": "TSLA", "chunk_size": 1200}
        )

    @pytest.mark.asyncio
    async def test_return_value_passthrough(self, fake_conn):
        fake_conn.call_tool.return_value = {"filings": [], "count": 0}
        client = SECClient(fake_conn)
        result = await client.search_filings("Apple")
        assert result["count"] == 0
