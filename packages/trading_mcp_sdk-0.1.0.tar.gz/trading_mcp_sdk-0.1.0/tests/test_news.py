"""Tests for NewsClient."""

import pytest

from trading_mcp_sdk.news import NewsClient


class TestNewsClient:
    @pytest.mark.asyncio
    async def test_get_news_defaults(self, fake_conn):
        client = NewsClient(fake_conn)
        await client.get_news("AAPL")
        fake_conn.call_tool.assert_called_once_with(
            "get_news",
            {
                "symbol": "AAPL",
                "from_date": "7d",
                "limit": 10,
                "include_sentiment": True,
            },
        )

    @pytest.mark.asyncio
    async def test_get_news_custom(self, fake_conn):
        client = NewsClient(fake_conn)
        await client.get_news("TSLA", from_date="30d", limit=5, include_sentiment=False)
        fake_conn.call_tool.assert_called_once_with(
            "get_news",
            {
                "symbol": "TSLA",
                "from_date": "30d",
                "limit": 5,
                "include_sentiment": False,
            },
        )

    @pytest.mark.asyncio
    async def test_get_sentiment_score(self, fake_conn):
        client = NewsClient(fake_conn)
        await client.get_sentiment_score("AAPL")
        fake_conn.call_tool.assert_called_once_with(
            "get_sentiment_score", {"symbol": "AAPL", "window": "7d"}
        )

    @pytest.mark.asyncio
    async def test_get_sentiment_score_custom_window(self, fake_conn):
        client = NewsClient(fake_conn)
        await client.get_sentiment_score("MSFT", window="30d")
        fake_conn.call_tool.assert_called_once_with(
            "get_sentiment_score", {"symbol": "MSFT", "window": "30d"}
        )

    @pytest.mark.asyncio
    async def test_get_trending_tickers(self, fake_conn):
        client = NewsClient(fake_conn)
        await client.get_trending_tickers()
        fake_conn.call_tool.assert_called_once_with(
            "get_trending_tickers", {"market": "all", "limit": 10}
        )

    @pytest.mark.asyncio
    async def test_get_trending_tickers_custom(self, fake_conn):
        client = NewsClient(fake_conn)
        await client.get_trending_tickers(market="crypto", limit=5)
        fake_conn.call_tool.assert_called_once_with(
            "get_trending_tickers", {"market": "crypto", "limit": 5}
        )

    @pytest.mark.asyncio
    async def test_get_earnings_sentiment(self, fake_conn):
        client = NewsClient(fake_conn)
        await client.get_earnings_sentiment("NVDA")
        fake_conn.call_tool.assert_called_once_with(
            "get_earnings_sentiment", {"symbol": "NVDA"}
        )

    @pytest.mark.asyncio
    async def test_return_value_passthrough(self, fake_conn):
        fake_conn.call_tool.return_value = {"score": 0.75, "label": "bullish"}
        client = NewsClient(fake_conn)
        result = await client.get_sentiment_score("AAPL")
        assert result["score"] == 0.75
