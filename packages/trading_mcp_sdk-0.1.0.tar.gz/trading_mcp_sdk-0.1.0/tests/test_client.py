"""Tests for the unified TradingMCP client."""

from __future__ import annotations

import sys
from unittest.mock import AsyncMock, patch

import pytest

from trading_mcp_sdk.client import ServerConfig, TradingMCP


class TestServerConfig:
    def test_from_false(self):
        assert ServerConfig.from_value(False, "market_data") is None

    def test_from_true(self):
        cfg = ServerConfig.from_value(True, "market_data")
        assert cfg is not None
        assert cfg.command == sys.executable
        assert cfg.args == ["-m", "market_data_server"]

    def test_from_string(self):
        cfg = ServerConfig.from_value("uv run market-server", "market_data")
        assert cfg is not None
        assert cfg.command == "uv"
        assert cfg.args == ["run", "market-server"]

    def test_from_dict(self):
        cfg = ServerConfig.from_value(
            {"command": "python", "args": ["-m", "custom"], "env": {"KEY": "val"}},
            "market_data",
        )
        assert cfg is not None
        assert cfg.command == "python"
        assert cfg.args == ["-m", "custom"]
        assert cfg.env == {"KEY": "val"}

    def test_from_invalid_type(self):
        with pytest.raises(TypeError, match="Invalid server config"):
            ServerConfig.from_value(42, "market_data")

    def test_all_server_defaults(self):
        for name in ("market_data", "news", "sec", "backtest"):
            cfg = ServerConfig.from_value(True, name)
            assert cfg is not None
            assert cfg.command == sys.executable


class TestTradingMCPInit:
    def test_all_enabled_by_default(self):
        client = TradingMCP()
        assert len(client._configs) == 4

    def test_disable_some_servers(self):
        client = TradingMCP(news=False, backtest=False)
        assert "market_data" in client._configs
        assert "sec" in client._configs
        assert "news" not in client._configs
        assert "backtest" not in client._configs

    def test_custom_command(self):
        client = TradingMCP(market_data="uv run market-data-server")
        cfg = client._configs["market_data"]
        assert cfg.command == "uv"

    def test_all_disabled(self):
        client = TradingMCP(market_data=False, news=False, sec=False, backtest=False)
        assert len(client._configs) == 0


class TestTradingMCPProperties:
    def test_market_data_not_connected(self):
        client = TradingMCP()
        with pytest.raises(RuntimeError, match="not available"):
            _ = client.market_data

    def test_news_not_connected(self):
        client = TradingMCP()
        with pytest.raises(RuntimeError, match="not available"):
            _ = client.news

    def test_sec_not_connected(self):
        client = TradingMCP()
        with pytest.raises(RuntimeError, match="not available"):
            _ = client.sec

    def test_backtest_not_connected(self):
        client = TradingMCP()
        with pytest.raises(RuntimeError, match="not available"):
            _ = client.backtest


class TestTradingMCPLifecycle:
    @pytest.mark.asyncio
    async def test_connect_and_disconnect(self):
        client = TradingMCP(market_data=False, news=False, sec=False, backtest=False)
        await client.connect()
        assert client.connected_servers == []
        await client.disconnect()

    @pytest.mark.asyncio
    async def test_context_manager(self):
        client = TradingMCP(market_data=False, news=False, sec=False, backtest=False)
        async with client as c:
            assert c is client
        assert client.connected_servers == []

    @pytest.mark.asyncio
    async def test_connected_servers_with_mock(self):
        client = TradingMCP(news=False, sec=False, backtest=False)

        mock_conn = AsyncMock()
        mock_conn.connected = True
        mock_conn.connect = AsyncMock()

        with patch("trading_mcp_sdk.client.MCPConnection", return_value=mock_conn):
            await client.connect()
            assert "market_data" in client.connected_servers
            assert client._market_data is not None

        await client.disconnect()

    @pytest.mark.asyncio
    async def test_disconnect_clears_subcients(self):
        client = TradingMCP(market_data=False, news=False, sec=False, backtest=False)
        await client.connect()
        await client.disconnect()
        assert client._market_data is None
        assert client._news is None
        assert client._sec is None
        assert client._backtest is None

    @pytest.mark.asyncio
    async def test_connect_creates_all_subclients(self):
        client = TradingMCP()
        mock_conn = AsyncMock()
        mock_conn.connected = True

        with patch("trading_mcp_sdk.client.MCPConnection", return_value=mock_conn):
            await client.connect()
            assert client._market_data is not None
            assert client._news is not None
            assert client._sec is not None
            assert client._backtest is not None

        await client.disconnect()

    @pytest.mark.asyncio
    async def test_disconnect_error_handling(self):
        client = TradingMCP(news=False, sec=False, backtest=False)
        mock_conn = AsyncMock()
        mock_conn.connected = True
        mock_conn.disconnect = AsyncMock(side_effect=OSError("boom"))

        with patch("trading_mcp_sdk.client.MCPConnection", return_value=mock_conn):
            await client.connect()

        with pytest.raises(ExceptionGroup):
            await client.disconnect()
