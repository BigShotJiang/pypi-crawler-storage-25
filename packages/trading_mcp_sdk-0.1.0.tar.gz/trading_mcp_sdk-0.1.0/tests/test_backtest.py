"""Tests for BacktestClient."""

import pytest

from trading_mcp_sdk.backtest import BacktestClient


class TestBacktestClient:
    @pytest.mark.asyncio
    async def test_run_backtest_defaults(self, fake_conn):
        client = BacktestClient(fake_conn)
        await client.run_backtest("AAPL", "x = 1")
        fake_conn.call_tool.assert_called_once_with(
            "run_backtest",
            {
                "symbol": "AAPL",
                "strategy": "x = 1",
                "start_date": "",
                "end_date": "",
                "initial_capital": 10000,
                "commission": 0.001,
            },
        )

    @pytest.mark.asyncio
    async def test_run_backtest_custom(self, fake_conn):
        client = BacktestClient(fake_conn)
        await client.run_backtest(
            "MSFT",
            "import pandas",
            start_date="2023-01-01",
            end_date="2024-01-01",
            initial_capital=50000,
            commission=0.002,
        )
        fake_conn.call_tool.assert_called_once_with(
            "run_backtest",
            {
                "symbol": "MSFT",
                "strategy": "import pandas",
                "start_date": "2023-01-01",
                "end_date": "2024-01-01",
                "initial_capital": 50000,
                "commission": 0.002,
            },
        )

    @pytest.mark.asyncio
    async def test_list_backtests(self, fake_conn):
        client = BacktestClient(fake_conn)
        await client.list_backtests()
        fake_conn.call_tool.assert_called_once_with("list_backtests", {})

    @pytest.mark.asyncio
    async def test_compare_backtests(self, fake_conn):
        client = BacktestClient(fake_conn)
        await client.compare_backtests(["id1", "id2"])
        fake_conn.call_tool.assert_called_once_with(
            "compare_backtests", {"ids": ["id1", "id2"]}
        )

    @pytest.mark.asyncio
    async def test_return_value_passthrough(self, fake_conn):
        fake_conn.call_tool.return_value = {
            "id": "abc123",
            "totalReturn": 15.5,
        }
        client = BacktestClient(fake_conn)
        result = await client.run_backtest("AAPL", "x = 1")
        assert result["totalReturn"] == 15.5
