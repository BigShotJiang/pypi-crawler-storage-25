"""Typed client for the SEC Filings MCP server (4 tools)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from trading_mcp_sdk._connection import MCPConnection


class SECClient:
    """Wrapper around the 4 SEC-filings MCP tools."""

    def __init__(self, connection: MCPConnection) -> None:
        self._conn = connection

    async def search_filings(
        self, query: str, form_type: str = "all", limit: int = 5
    ) -> dict[str, Any]:
        """Search for SEC filings by company name, ticker, or CIK."""
        return await self._conn.call_tool(
            "search_filings",
            {"query": query, "form_type": form_type, "limit": limit},
        )

    async def get_filing_summary(
        self,
        accession_number: str,
        sections: list[str] | None = None,
        max_chars: int = 3000,
    ) -> dict[str, Any]:
        """Get an LLM-ready summary of a specific SEC filing."""
        args: dict[str, Any] = {
            "accession_number": accession_number,
            "max_chars": max_chars,
        }
        if sections is not None:
            args["sections"] = sections
        return await self._conn.call_tool("get_filing_summary", args)

    async def get_key_financials(
        self, symbol: str, period: str = "annual"
    ) -> dict[str, Any]:
        """Extract structured financial metrics from the most recent 10-K/10-Q."""
        return await self._conn.call_tool(
            "get_key_financials", {"symbol": symbol, "period": period}
        )

    async def get_risk_factors(
        self, symbol: str, chunk_size: int = 800
    ) -> dict[str, Any]:
        """Extract and chunk Risk Factors section from the most recent 10-K."""
        return await self._conn.call_tool(
            "get_risk_factors", {"symbol": symbol, "chunk_size": chunk_size}
        )
