"""Low-level MCP connection management via stdio transport."""

from __future__ import annotations

import asyncio
import json
import os
import sys
from contextlib import AsyncExitStack
from typing import Any

from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

# API-key env vars that must be forwarded to MCP server subprocesses.
# The MCP library's default env whitelist only includes system vars
# (PATH, TEMP, etc.), so these would be silently dropped otherwise.
_API_KEY_VARS = [
    "POLYGON_API_KEY",
    "FINNHUB_API_KEY",
    "ALPHAVANTAGE_API_KEY",
    "COINGECKO_API_KEY",
]


def _get_errlog():
    """Return a stderr stream safe for subprocess creation.

    Jupyter (and other non-terminal hosts) replace sys.stderr with an
    object that lacks fileno(), which breaks subprocess.Popen and
    anyio.open_process on Windows.  Fall back to os.devnull in that case.
    """
    try:
        sys.stderr.fileno()
        return sys.stderr
    except Exception:
        return open(os.devnull, "w")


class MCPConnection:
    """Manages a stdio connection to a single MCP server process."""

    def __init__(
        self,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ):
        # Ensure API-key env vars are forwarded to the server subprocess,
        # since the MCP library's default whitelist excludes them.
        merged_env: dict[str, str] = {}
        for key in _API_KEY_VARS:
            val = os.environ.get(key)
            if val:
                merged_env[key] = val
        if env:
            merged_env.update(env)

        self._params = StdioServerParameters(
            command=command,
            args=args or [],
            env=merged_env or None,
        )
        self._session: ClientSession | None = None
        self._stack: AsyncExitStack | None = None
        self._errlog_file = None  # track devnull handle for cleanup

    async def connect(self) -> None:
        """Open stdio transport and initialise the MCP session."""
        self._stack = AsyncExitStack()
        errlog = _get_errlog()
        if errlog is not sys.stderr:
            self._errlog_file = errlog
        transport = await self._stack.enter_async_context(
            stdio_client(self._params, errlog=errlog)
        )
        # stdio_client yields (read_stream, write_stream)
        read, write = transport
        self._session = await self._stack.enter_async_context(
            ClientSession(read, write)
        )
        await self._session.initialize()

    async def disconnect(self) -> None:
        """Tear down the MCP session and stdio transport.

        On Windows the MCP library's FallbackProcess.__aexit__ can raise
        CancelledError (anyio checkpoint inside a torn-down cancel scope).
        We suppress it here so callers don't see a spurious failure.
        """
        if self._stack:
            try:
                await self._stack.aclose()
            except (asyncio.CancelledError, Exception):
                # Best-effort teardown — the subprocess will be reaped by
                # the OS even if the graceful shutdown path fails.
                pass
            self._stack = None
            self._session = None
        if self._errlog_file:
            self._errlog_file.close()
            self._errlog_file = None

    @property
    def connected(self) -> bool:
        return self._session is not None

    async def call_tool(
        self, name: str, arguments: dict[str, Any] | None = None
    ) -> Any:
        """Call an MCP tool and return parsed JSON result."""
        if not self._session:
            raise RuntimeError(
                "Not connected — use 'async with' or call connect() first."
            )
        result = await self._session.call_tool(name, arguments or {})
        if result.content:
            for block in result.content:
                if hasattr(block, "text"):
                    try:
                        return json.loads(block.text)
                    except (json.JSONDecodeError, TypeError):
                        return block.text
        return None

    async def list_tools(self) -> list[str]:
        """Return names of all tools exposed by the connected server."""
        if not self._session:
            raise RuntimeError("Not connected.")
        result = await self._session.list_tools()
        return [t.name for t in result.tools]
