"""Unified TradingMCP client — connects to one or more MCP servers."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import Any

from trading_mcp_sdk._connection import MCPConnection
from trading_mcp_sdk.backtest import BacktestClient
from trading_mcp_sdk.market_data import MarketDataClient
from trading_mcp_sdk.news import NewsClient
from trading_mcp_sdk.sec import SECClient


# ── Default server commands ───────────────────────────────────────

# Use sys.executable so subprocesses use the same Python (venv-safe on Windows)
_PYTHON = sys.executable

_DEFAULT_COMMANDS: dict[str, tuple[str, list[str]]] = {
    "market_data": (_PYTHON, ["-m", "market_data_server"]),
    "news": (_PYTHON, ["-m", "news_server"]),
    "sec": (_PYTHON, ["-m", "sec_server"]),
    "backtest": (_PYTHON, ["-m", "backtest_server"]),
}


# ── Server config ─────────────────────────────────────────────────


@dataclass
class ServerConfig:
    """Configuration for connecting to one MCP server."""

    command: str
    args: list[str] = field(default_factory=list)
    env: dict[str, str] | None = None

    @classmethod
    def from_value(
        cls, value: str | dict[str, Any] | bool, name: str
    ) -> ServerConfig | None:
        """Build config from various shorthand forms.

        - ``True``  → default command for *name*
        - ``False`` → disabled (returns None)
        - ``str``   → custom command (split on spaces)
        - ``dict``  → passed as keyword args to ServerConfig
        """
        if value is False:
            return None
        if value is True:
            cmd, args = _DEFAULT_COMMANDS[name]
            return cls(command=cmd, args=args)
        if isinstance(value, str):
            parts = value.split()
            return cls(command=parts[0], args=parts[1:])
        if isinstance(value, dict):
            return cls(**value)
        raise TypeError(f"Invalid server config for '{name}': {value!r}")


# ── Main client ───────────────────────────────────────────────────


class TradingMCP:
    """Unified async client for the Trading MCP ecosystem.

    Usage::

        async with TradingMCP() as t:
            quote = await t.market_data.get_quote("AAPL")
            news  = await t.news.get_news("AAPL")

    Each sub-client is only available if its server was enabled at init.
    Pass ``False`` to disable a server, or a command string / dict to
    override the default launch command.
    """

    def __init__(
        self,
        market_data: str | dict[str, Any] | bool = True,
        news: str | dict[str, Any] | bool = True,
        sec: str | dict[str, Any] | bool = True,
        backtest: str | dict[str, Any] | bool = True,
    ) -> None:
        self._configs: dict[str, ServerConfig] = {}
        self._connections: dict[str, MCPConnection] = {}

        for name, value in [
            ("market_data", market_data),
            ("news", news),
            ("sec", sec),
            ("backtest", backtest),
        ]:
            cfg = ServerConfig.from_value(value, name)
            if cfg is not None:
                self._configs[name] = cfg

        # Sub-clients — set after connect()
        self._market_data: MarketDataClient | None = None
        self._news: NewsClient | None = None
        self._sec: SECClient | None = None
        self._backtest: BacktestClient | None = None

    # ── Properties ────────────────────────────────────────────────

    @property
    def market_data(self) -> MarketDataClient:
        if self._market_data is None:
            raise RuntimeError(
                "MarketDataClient not available — server disabled or not connected."
            )
        return self._market_data

    @property
    def news(self) -> NewsClient:
        if self._news is None:
            raise RuntimeError(
                "NewsClient not available — server disabled or not connected."
            )
        return self._news

    @property
    def sec(self) -> SECClient:
        if self._sec is None:
            raise RuntimeError(
                "SECClient not available — server disabled or not connected."
            )
        return self._sec

    @property
    def backtest(self) -> BacktestClient:
        if self._backtest is None:
            raise RuntimeError(
                "BacktestClient not available — server disabled or not connected."
            )
        return self._backtest

    # ── Lifecycle ─────────────────────────────────────────────────

    async def connect(self) -> None:
        """Open connections to all enabled servers."""
        client_map = {
            "market_data": (MarketDataClient, "_market_data"),
            "news": (NewsClient, "_news"),
            "sec": (SECClient, "_sec"),
            "backtest": (BacktestClient, "_backtest"),
        }
        for name, cfg in self._configs.items():
            conn = MCPConnection(command=cfg.command, args=cfg.args, env=cfg.env)
            await conn.connect()
            self._connections[name] = conn
            cls, attr = client_map[name]
            setattr(self, attr, cls(conn))

    async def disconnect(self) -> None:
        """Close all server connections."""
        errors: list[Exception] = []
        for conn in self._connections.values():
            try:
                await conn.disconnect()
            except Exception as e:
                errors.append(e)
        self._connections.clear()
        self._market_data = None
        self._news = None
        self._sec = None
        self._backtest = None
        if errors:
            raise ExceptionGroup("Errors during disconnect", errors)

    async def __aenter__(self) -> TradingMCP:
        await self.connect()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.disconnect()

    @property
    def connected_servers(self) -> list[str]:
        """Return names of currently connected servers."""
        return [name for name, conn in self._connections.items() if conn.connected]
