"""Typed client for the Backtest MCP server (3 tools)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from trading_mcp_sdk._connection import MCPConnection


class BacktestClient:
    """Wrapper around the 3 backtest MCP tools."""

    def __init__(self, connection: MCPConnection) -> None:
        self._conn = connection

    async def run_backtest(
        self,
        symbol: str,
        strategy: str,
        start_date: str = "",
        end_date: str = "",
        initial_capital: float = 10000,
        commission: float = 0.001,
    ) -> dict[str, Any]:
        """Run a trading strategy backtest over historical data."""
        return await self._conn.call_tool(
            "run_backtest",
            {
                "symbol": symbol,
                "strategy": strategy,
                "start_date": start_date,
                "end_date": end_date,
                "initial_capital": initial_capital,
                "commission": commission,
            },
        )

    async def list_backtests(self) -> dict[str, Any]:
        """List all backtests run in the current server session."""
        return await self._conn.call_tool("list_backtests", {})

    async def compare_backtests(self, ids: list[str]) -> dict[str, Any]:
        """Side-by-side comparison of two or more previously run backtests."""
        return await self._conn.call_tool("compare_backtests", {"ids": ids})
