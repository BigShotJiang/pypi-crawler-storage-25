"""Typed client for the Market Data MCP server (5 tools)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from trading_mcp_sdk._connection import MCPConnection


class MarketDataClient:
    """Wrapper around the 5 market-data MCP tools."""

    def __init__(self, connection: MCPConnection) -> None:
        self._conn = connection

    async def get_quote(self, symbol: str, exchange: str = "AUTO") -> dict[str, Any]:
        """Get latest price quote for a stock or crypto symbol."""
        return await self._conn.call_tool(
            "get_quote", {"symbol": symbol, "exchange": exchange}
        )

    async def get_ohlcv(
        self,
        symbol: str,
        timeframe: str,
        from_date: str = "",
        to_date: str = "",
        limit: int = 200,
    ) -> dict[str, Any]:
        """Fetch OHLCV candlestick data for a symbol and timeframe."""
        return await self._conn.call_tool(
            "get_ohlcv",
            {
                "symbol": symbol,
                "timeframe": timeframe,
                "from_date": from_date,
                "to_date": to_date,
                "limit": limit,
            },
        )

    async def search_symbols(
        self, query: str, asset_type: str = "all", limit: int = 10
    ) -> dict[str, Any]:
        """Search for stock or crypto symbols by name or ticker."""
        return await self._conn.call_tool(
            "search_symbols",
            {"query": query, "asset_type": asset_type, "limit": limit},
        )

    async def get_market_movers(
        self, mover_type: str, market: str = "stocks", limit: int = 10
    ) -> dict[str, Any]:
        """Get top gainers, losers, or most active tickers."""
        return await self._conn.call_tool(
            "get_market_movers",
            {"mover_type": mover_type, "market": market, "limit": limit},
        )

    async def get_company_info(self, symbol: str) -> dict[str, Any]:
        """Get company profile and fundamental information."""
        return await self._conn.call_tool("get_company_info", {"symbol": symbol})
