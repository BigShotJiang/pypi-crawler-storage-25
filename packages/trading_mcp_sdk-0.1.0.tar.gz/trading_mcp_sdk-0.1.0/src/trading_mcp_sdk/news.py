"""Typed client for the News & Sentiment MCP server (4 tools)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from trading_mcp_sdk._connection import MCPConnection


class NewsClient:
    """Wrapper around the 4 news-sentiment MCP tools."""

    def __init__(self, connection: MCPConnection) -> None:
        self._conn = connection

    async def get_news(
        self,
        symbol: str,
        from_date: str = "7d",
        limit: int = 10,
        include_sentiment: bool = True,
    ) -> dict[str, Any]:
        """Fetch recent news articles for a specific ticker or topic."""
        return await self._conn.call_tool(
            "get_news",
            {
                "symbol": symbol,
                "from_date": from_date,
                "limit": limit,
                "include_sentiment": include_sentiment,
            },
        )

    async def get_sentiment_score(
        self, symbol: str, window: str = "7d"
    ) -> dict[str, Any]:
        """Get aggregated sentiment score for a ticker over a time window."""
        return await self._conn.call_tool(
            "get_sentiment_score", {"symbol": symbol, "window": window}
        )

    async def get_trending_tickers(
        self, market: str = "all", limit: int = 10
    ) -> dict[str, Any]:
        """Get currently trending tickers based on news volume spike."""
        return await self._conn.call_tool(
            "get_trending_tickers", {"market": market, "limit": limit}
        )

    async def get_earnings_sentiment(self, symbol: str) -> dict[str, Any]:
        """Get pre/post earnings sentiment analysis for a ticker."""
        return await self._conn.call_tool("get_earnings_sentiment", {"symbol": symbol})
