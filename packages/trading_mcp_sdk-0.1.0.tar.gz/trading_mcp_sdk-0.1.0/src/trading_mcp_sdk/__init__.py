"""Trading MCP Python SDK — typed wrappers for all MCP server tools."""

from trading_mcp_sdk.backtest import BacktestClient
from trading_mcp_sdk.client import ServerConfig, TradingMCP
from trading_mcp_sdk.market_data import MarketDataClient
from trading_mcp_sdk.news import NewsClient
from trading_mcp_sdk.sec import SECClient

__all__ = [
    "TradingMCP",
    "ServerConfig",
    "MarketDataClient",
    "NewsClient",
    "SECClient",
    "BacktestClient",
]
