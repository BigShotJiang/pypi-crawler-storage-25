"""Inbound bridges (EVM-signed) — return paths to Hyperliquid.

Two commands and two top-level env prefixes:
  arbitrum bridge hypercore --to self <amount>      (Arbitrum USDC -> HL perp)
  hyperevm bridge hypercore --to self <amount> --token <tok>   (HyperEVM -> HL spot)

Both use src/regard/core/evm.py's chain-agnostic transfer_erc20 / transfer_native
helpers — same EVM-signing infra that polygon send already exercises against
Polygon. The only chain-specific pieces are the RPC URL, contract addresses,
and (for HYPE) the gas-limit override per locked decision 15.

USDC on HyperEVM is special: Circle deployed a `CoreDepositWallet` proxy at
the address spotMeta returns under `evmContract.address`, and the actual ERC-20
token lives at a different address that the proxy exposes via a `token()`
getter. The CoreDepositWallet path uses `depositWithAuth` (EIP-3009) for
single-tx atomic bridge-back; other linked tokens (USDH/USDT0/USDE/PURR) are
direct ERC-20s and use the standard `transfer(systemAddress, amount)` path.
HYPE is the native gas token (no ERC-20). See V025-IMPLEMENTATION.md
Decision 24.

Per V025-IMPLEMENTATION.md locked decisions 11-20, 24.
"""

import secrets
import sys
import time
from decimal import Decimal
from typing import Annotated

import typer

from regard.core.output import die, output
from regard.core.proposal import create_proposal, register_executor, register_safety_validator
from regard.venues.hyperliquid.bridge_constants import (
    ARB_GAS_HARD_THRESHOLD,
    ARB_MIN_DEPOSIT,
    ARB_USDC_CONTRACT,
    ARB_USDC_DECIMALS,
    HL_BRIDGE2_CONTRACT,
    HYPE_BRIDGE_GAS_LIMIT,
    HYPE_SYSTEM_ADDRESS,
    HYPEREVM_GAS_HARD_THRESHOLD,
)

# ---------------------------------------------------------------------------
# Web3 client factories
# ---------------------------------------------------------------------------


def _make_retry_session():
    """Build a requests session with retries on 429/5xx."""
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry

    session = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["POST", "GET"],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def _get_arbitrum_web3():
    """Web3 client for Arbitrum One via the shared RPC pool (chainId 42161)."""
    from regard.core.rpc_pool import get_web3
    return get_web3(42161)


def _get_hyperevm_web3():
    """Web3 client for HyperEVM via the shared RPC pool (chainId 999)."""
    from regard.core.rpc_pool import get_web3
    return get_web3(999)


# ---------------------------------------------------------------------------
# Hard-block source-gas check (locked decision 14)
# ---------------------------------------------------------------------------


def _native_balance(w3, address: str) -> Decimal | None:
    """Return native gas balance in tokens (Decimal), or None on RPC error."""
    try:
        from web3 import Web3
        balance_wei = w3.eth.get_balance(Web3.to_checksum_address(address))
        return Decimal(balance_wei) / Decimal(10**18)
    except Exception:
        return None


def require_source_gas(chain: str, w3, address: str) -> None:
    """Hard-block if source-chain native gas is insufficient to sign a tx.

    Inbound bridges sign EVM transactions on the source chain; with no gas
    the tx cannot be broadcast at all. Per locked decision 14 this is a
    hard block, not a warning.

    RPC failure dies with RPC_UNREACHABLE rather than silently passing —
    we cannot proceed without confirming gas.
    """
    threshold = {
        "arbitrum": ARB_GAS_HARD_THRESHOLD,
        "hyperevm": HYPEREVM_GAS_HARD_THRESHOLD,
    }[chain]
    native = "ETH" if chain == "arbitrum" else "HYPE"

    balance = _native_balance(w3, address)
    if balance is None:
        die("validation_error", "RPC_UNREACHABLE",
            f"Cannot verify {chain} gas balance for {address}. RPC is unreachable.",
            hint=f"Retry, or set {chain.upper()}_RPC in config to a working endpoint.")
    if balance < threshold:
        die("validation_error", "BRIDGE_SOURCE_NO_GAS",
            f"Sender {address} has {balance} {native} on {chain}; need at least {threshold} to sign the bridge tx.",
            hint=f"Fund the sender with {native} on {chain} before retrying.")


# ---------------------------------------------------------------------------
# HyperEVM linked-token resolution (used by hyperevm bridge hypercore)
# ---------------------------------------------------------------------------

# Selectors for on-chain calls.
_TOKEN_SELECTOR = "0xfc0c546a"  # token() — Circle CoreDepositWallet getter
_NAME_SELECTOR = "0x06fdde03"  # name()
_VERSION_SELECTOR = "0x54fd4d50"  # version()
_PAUSED_SELECTOR = "0x5c975abb"  # paused()

# L1Read precompile for checking HyperCore account existence (HIP-1 docs).
_CORE_USER_EXISTS_PRECOMPILE = "0x0000000000000000000000000000000000000810"

# CoreDepositWallet ABI fragments — only the bits we call.
COREDEPOSIT_DEPOSITWITHAUTH_ABI = {
    "name": "depositWithAuth",
    "type": "function",
    "stateMutability": "nonpayable",
    "inputs": [
        {"name": "amount", "type": "uint256"},
        {"name": "authValidAfter", "type": "uint256"},
        {"name": "authValidBefore", "type": "uint256"},
        {"name": "authNonce", "type": "bytes32"},
        {"name": "v", "type": "uint8"},
        {"name": "r", "type": "bytes32"},
        {"name": "s", "type": "bytes32"},
        {"name": "destinationDex", "type": "uint32"},
    ],
    "outputs": [],
}

# uint32.max — Core Spot dex routing per CoreDepositWallet.sol CORE_SPOT_DEX_ID.
_CORE_SPOT_DEX_ID = 0xFFFFFFFF


def _decode_string_result(data: bytes) -> str:
    """Decode an ABI-encoded dynamic string return value (32 offset + 32 length + data)."""
    if len(data) < 64:
        return ""
    length = int.from_bytes(data[32:64], "big")
    if length == 0:
        return ""
    return bytes(data[64:64 + length]).decode("utf-8", errors="replace")


def _resolve_token_evm_contract(token, w3) -> dict | None:
    """Resolve the EVM contract for a single spot_meta token entry.

    Returns the structured shape used by `_resolve_hyperevm_erc20`, or None if
    the token has no linked EVM contract / malformed evmContract.

    `token` is expected to be a mapping (the SDK's `SpotTokenInfo` TypedDict
    or a plain dict) — left untyped so both shapes pass static checks.
    """
    evm_contract = token.get("evmContract")
    if evm_contract is None:
        return None
    # Real API: dict with `address` field. Defensive: accept a plain string
    # too (older fixtures, alternate API versions).
    if isinstance(evm_contract, dict):
        evm_addr = evm_contract.get("address")
        extra = evm_contract.get("evm_extra_wei_decimals", 0)
    elif isinstance(evm_contract, str):
        evm_addr = evm_contract
        extra = 0
    else:
        return None
    if not evm_addr:
        return None

    wei_decimals = token.get("weiDecimals", 0) + extra
    token_index = token.get("index", 0)

    from web3 import Web3
    # web3.py rejects non-checksum addresses; spot_meta returns lowercase.
    # Checksum once up front for all subsequent eth_call usage.
    evm_addr_cs = Web3.to_checksum_address(evm_addr)

    # Try `token()` getter — Circle CoreDepositWallet pattern detection.
    # Reverts or returns self/zero → direct ERC-20.
    try:
        result = w3.eth.call({"to": evm_addr_cs, "data": _TOKEN_SELECTOR})
        inner_hex = "0x" + result.hex()[-40:] if hasattr(result, "hex") else "0x" + result[-20:].hex()
        inner_addr = Web3.to_checksum_address(inner_hex) if int(inner_hex, 16) != 0 else None
        if (
            inner_addr is not None
            and inner_addr.lower() != evm_addr_cs.lower()
        ):
            return {
                "erc20_address": inner_addr,
                "bridge_address": evm_addr_cs,
                "is_circle_pattern": True,
                "wei_decimals": wei_decimals,
                "token_index": token_index,
            }
    except Exception:
        pass  # token() reverted or doesn't exist → direct ERC-20

    return {
        "erc20_address": evm_addr_cs,
        "bridge_address": evm_addr_cs,
        "is_circle_pattern": False,
        "wei_decimals": wei_decimals,
        "token_index": token_index,
    }


def _resolve_hyperevm_erc20(token_name: str, info, w3) -> dict | None:
    """Resolve the actual HyperEVM ERC-20 contract for a linked HL spot token.

    Most linked tokens (USDH/USDT0/USDE/PURR): `spotMeta.evmContract.address` IS
    the ERC-20 contract — `balanceOf` and `transfer` work directly against it.

    USDC: `spotMeta.evmContract.address` returns Circle's CoreDepositWallet
    bridge contract (e.g. `0x6b9e7731…` on mainnet), not the actual ERC-20.
    The bridge exposes a `token()` getter returning the underlying token
    address (e.g. `0xb88339…` for USDC). The bridge mechanism is also
    different — use `depositWithAuth` (EIP-3009) instead of plain `transfer`.

    Detection: call `token()` on the contract. If it returns a non-zero
    address different from the contract itself, treat as Circle pattern.
    Reverts or self-references mean direct ERC-20.

    Returns: {
        "erc20_address": <actual ERC-20 contract — read balanceOf here>,
        "bridge_address": <CoreDepositWallet for Circle pattern, else same as erc20>,
        "is_circle_pattern": bool,
        "wei_decimals": int,
        "token_index": int,  # spot_meta token index
    }
    Returns None if the token has no linked EVM contract (unlinked).
    HYPE callers must short-circuit before reaching this helper.
    """
    try:
        spot_meta = info.spot_meta()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SPOT_META_UNAVAILABLE",
            f"Could not fetch spot_meta for token link check: {e}",
            exit_code=4)

    upper = token_name.upper()
    for t in spot_meta.get("tokens", []):
        if t.get("name", "").upper() == upper:
            return _resolve_token_evm_contract(t, w3)
    return None


def _hyperevm_linked_erc20(token_name: str, info) -> str | None:
    """Backwards-compat shim around `_resolve_hyperevm_erc20` returning just the
    bridge address (matches pre-v0.25.9 callers). Prefer the structured helper.
    """
    # Some callers (test_bridges.py legacy schema test) pass a mock without a
    # working w3; the test only exercises the spot_meta path. Construct a no-op
    # w3 mock that makes token() reject so we always hit the direct-ERC-20
    # branch in the resolver.
    class _NoOpW3:
        class _Eth:
            def call(self, *a, **kw):
                raise RuntimeError("no-op")
        eth = _Eth()

    resolved = _resolve_hyperevm_erc20(token_name, info, _NoOpW3())
    if resolved is None:
        return None
    return resolved["bridge_address"]


def _is_fresh_hl_core_user(w3, address: str) -> bool:
    """Return True if `address` has no HyperCore account yet (will incur the
    1 USDC newCoreAccountFee on first inbound bridge via CoreDepositWallet).

    Uses the L1Read precompile at 0x...0810 (`coreUserExists`). Fail-soft on
    any RPC error — assumes account exists (no fee surfaced) rather than
    over-warning. Mirrors the v0.25.2 spot-send activation-fee surface.
    """
    try:
        from web3 import Web3
        # ABI-encode address as 32-byte left-padded big-endian.
        padded = address[2:].lower().rjust(64, "0")
        result = w3.eth.call({
            "to": Web3.to_checksum_address(_CORE_USER_EXISTS_PRECOMPILE),
            "data": "0x" + padded,
        })
        # Result is a single bool (32-byte): 0x...01 = exists, 0x...00 = does not.
        raw = bytes(result) if isinstance(result, (bytes, bytearray)) else result
        if hasattr(raw, "hex"):
            exists = int(raw.hex(), 16) != 0
        else:
            exists = int(raw, 16) != 0
        return not exists
    except Exception:
        return False  # fail-soft: assume exists, no warning


def _read_eip712_domain(w3, token_addr: str) -> tuple[str, str]:
    """Read `name()` and `version()` from a token contract for EIP-712 domain.

    Falls back to ("USD Coin", "2") if version() reverts (FiatTokenV2_2 default).
    Defensive on-chain read avoids silent EIP-3009 signature mismatch if Circle
    deploys a custom variant. Per Codex peer review 2026-05-07.
    """
    from web3 import Web3
    addr_cs = Web3.to_checksum_address(token_addr)
    try:
        name_result = w3.eth.call({"to": addr_cs, "data": _NAME_SELECTOR})
        raw = bytes(name_result) if not isinstance(name_result, bytes) else name_result
        name = _decode_string_result(raw) or "USD Coin"
    except Exception:
        name = "USD Coin"
    try:
        version_result = w3.eth.call({"to": addr_cs, "data": _VERSION_SELECTOR})
        raw = bytes(version_result) if not isinstance(version_result, bytes) else version_result
        version = _decode_string_result(raw) or "2"
    except Exception:
        version = "2"
    return name, version


def _is_bridge_paused(w3, bridge_addr: str) -> bool:
    """Check if a Circle CoreDepositWallet bridge has been paused. Fail-soft."""
    try:
        from web3 import Web3
        result = w3.eth.call({
            "to": Web3.to_checksum_address(bridge_addr),
            "data": _PAUSED_SELECTOR,
        })
        raw = bytes(result) if not isinstance(result, bytes) else result
        if hasattr(raw, "hex"):
            return int(raw.hex(), 16) != 0
        return int(raw, 16) != 0
    except Exception:
        return False  # fail-soft: assume not paused


def _sign_eip3009_receive_with_auth(
    private_key: str,
    erc20_addr: str,
    domain_name: str,
    domain_version: str,
    chain_id: int,
    from_addr: str,
    to_addr: str,
    value: int,
    valid_after: int,
    valid_before: int,
    nonce: bytes,
) -> tuple[int, bytes, bytes]:
    """Sign an EIP-3009 receiveWithAuthorization message via EIP-712 typed data.

    Returns (v, r, s). Used by Circle CoreDepositWallet `depositWithAuth`.
    The signature authorizes the bridge to pull `value` raw token units from
    `from_addr`'s balance (on `erc20_addr`) and forward to `to_addr` (the
    CoreDepositWallet itself), valid in the [validAfter, validBefore] window.
    """
    from eth_account import Account
    from eth_account.messages import encode_typed_data

    typed_data = {
        "types": {
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
            "ReceiveWithAuthorization": [
                {"name": "from", "type": "address"},
                {"name": "to", "type": "address"},
                {"name": "value", "type": "uint256"},
                {"name": "validAfter", "type": "uint256"},
                {"name": "validBefore", "type": "uint256"},
                {"name": "nonce", "type": "bytes32"},
            ],
        },
        "primaryType": "ReceiveWithAuthorization",
        "domain": {
            "name": domain_name,
            "version": domain_version,
            "chainId": chain_id,
            "verifyingContract": erc20_addr,
        },
        "message": {
            "from": from_addr,
            "to": to_addr,
            "value": value,
            "validAfter": valid_after,
            "validBefore": valid_before,
            "nonce": nonce,
        },
    }
    encoded = encode_typed_data(full_message=typed_data)
    signed = Account.sign_message(encoded, private_key=private_key)
    return signed.v, signed.r.to_bytes(32, "big"), signed.s.to_bytes(32, "big")


def _system_address_for_token(token_name: str, info) -> str:
    """Compute the HyperCore system address for a token (used as the EVM dest)."""
    if token_name.upper() == "HYPE":
        return HYPE_SYSTEM_ADDRESS

    try:
        spot_meta = info.spot_meta()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SPOT_META_UNAVAILABLE",
            f"Could not fetch spot_meta: {e}", exit_code=4)

    for t in spot_meta.get("tokens", []):
        if t.get("name", "").upper() == token_name.upper():
            idx = t.get("index")
            if idx is None:
                die("venue_error", "SPOT_META_UNAVAILABLE",
                    f"spot_meta entry for {token_name} has no index field", exit_code=4)
            return "0x20" + idx.to_bytes(19, "big").hex()

    die("validation_error", "UNKNOWN_TOKEN",
        f"Token '{token_name}' not found in Hyperliquid spot_meta",
        hint="Check available tokens with: regard hypercore spot-balances")
    return ""  # unreachable


# ---------------------------------------------------------------------------
# Click subapps
# ---------------------------------------------------------------------------


arbitrum_app = typer.Typer(
    name="arbitrum",
    no_args_is_help=True,
    help="Arbitrum One. EVM-signed transactions on chainId 42161.",
    pretty_exceptions_enable=False,
)
arbitrum_bridge_app = typer.Typer(
    name="bridge",
    no_args_is_help=True,
    help="Move tokens from Arbitrum to a different chain.",
    pretty_exceptions_enable=False,
)


@arbitrum_app.callback()
def arbitrum_main(ctx: typer.Context):
    """Arbitrum One CLI."""
    ctx.ensure_object(dict)
    # Match polygon's pattern: testnet flag is not relevant here (Arbitrum
    # mainnet only for v0.25.0).
    ctx.obj.setdefault("testnet", False)


hyperevm_app = typer.Typer(
    name="hyperevm",
    no_args_is_help=True,
    help="HyperEVM execution layer. EVM-signed transactions on chainId 999.",
    pretty_exceptions_enable=False,
)
hyperevm_bridge_app = typer.Typer(
    name="bridge",
    no_args_is_help=True,
    help="Move tokens from HyperEVM to a different chain.",
    pretty_exceptions_enable=False,
)


@hyperevm_app.callback()
def hyperevm_main(ctx: typer.Context):
    """HyperEVM execution layer CLI."""
    ctx.ensure_object(dict)
    ctx.obj.setdefault("testnet", False)


# ---------------------------------------------------------------------------
# hyperevm balance — read-only HyperEVM-side balance(s)
# ---------------------------------------------------------------------------


def _resolve_query_address(explicit: str | None) -> str:
    """Resolve the address to query for a read-only command.

    Explicit `--address` wins. Otherwise derive from the project wallet (same
    EVM key used for inbound bridges and polymarket sends). Soft-fails when
    no wallet is configured — read-only commands shouldn't require one if
    the user passed `--address` explicitly.
    """
    import os

    from web3 import Web3

    if explicit is not None:
        try:
            return Web3.to_checksum_address(explicit)
        except Exception:
            die("validation_error", "INVALID_ADDRESS",
                f"--address must be a valid 0x-prefixed EVM address: {explicit}")

    key = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or os.environ.get("POLYMARKET_PRIVATE_KEY")
    if not key:
        try:
            from regard.core.project_state import load_project_env
            env = load_project_env()
            key = env.get("HYPERLIQUID_PRIVATE_KEY") or env.get("POLYMARKET_PRIVATE_KEY")
        except Exception:
            pass
    if not key:
        die("validation_error", "WALLET_REQUIRED",
            "No wallet configured and no --address provided.",
            hint="Pass --address 0x..., or run `regard wallet --prompt` to set up a wallet.")

    import eth_account
    return eth_account.Account.from_key(key).address


@hyperevm_app.command("balance")
def hyperevm_balance(
    ctx: typer.Context,
    token: Annotated[str | None, typer.Argument(help="Token name (HYPE, USDC, USDH, USDT0, USDE, ...). Omit to list all known linked tokens + native HYPE.")] = None,
    address: Annotated[str | None, typer.Option("--address", help="Address to query. Defaults to the wallet's own address.")] = None,
):
    """Read HyperEVM-side balance(s) for a token (or all known tokens).

    Native HYPE uses `eth_getBalance`. ERC-20 tokens are resolved via
    spot_meta — handles both direct ERC-20s (USDH/USDT0/USDE/PURR) and
    Circle's CoreDepositWallet pattern (USDC), where the bridge contract
    exposes the actual ERC-20 via a `token()` getter (see V025-IMPLEMENTATION.md
    Decision 24).

    Read-only — no signing, no proposal. Output is a structured JSON envelope.
    """
    opts = ctx.obj
    from decimal import Decimal as _D

    from regard.venues.hyperliquid.client import get_info

    query_addr = _resolve_query_address(address)
    w3 = _get_hyperevm_web3()
    info = get_info(opts.get("testnet", False))

    try:
        spot_meta = info.spot_meta()
    except Exception as e:
        die("venue_error", "SPOT_META_UNAVAILABLE",
            f"Could not fetch spot_meta: {e}", exit_code=4)

    def _read_native_hype() -> dict:
        try:
            balance_raw = w3.eth.get_balance(query_addr)
        except Exception as e:
            die("venue_error", "RPC_UNREACHABLE",
                f"Cannot read HYPE balance for {query_addr}: {e}",
                hint="Set HYPEREVM_RPC in config to a working endpoint, or retry.",
                exit_code=4)
        return {
            "token": "HYPE",
            "is_native": True,
            "amount": str(_D(balance_raw) / _D(10**18)),
            "raw": str(balance_raw),
            "wei_decimals": 18,
            "erc20_address": None,
            "bridge_address": None,
            "is_circle_pattern": False,
            "token_index": None,
        }

    def _read_erc20(t, resolved: dict) -> dict:
        from regard.core.evm import get_erc20_balance
        wei_decimals = resolved["wei_decimals"]  # int — INT_NAME_LITERALS allow
        try:
            balance_raw = get_erc20_balance(w3, query_addr, resolved["erc20_address"])
        except Exception as e:
            return {
                "token": t.get("name", "?"),
                "is_native": False,
                "amount": None,
                "raw": None,
                "wei_decimals": wei_decimals,
                "erc20_address": resolved["erc20_address"],
                "bridge_address": resolved["bridge_address"],
                "is_circle_pattern": resolved["is_circle_pattern"],
                "token_index": resolved["token_index"],
                "error": f"BALANCE_READ_FAILED: {e}",
            }
        amount = _D(balance_raw) / _D(10**wei_decimals)
        return {
            "token": t.get("name", "?"),
            "is_native": False,
            "amount": str(amount),
            "raw": str(balance_raw),
            "wei_decimals": wei_decimals,
            "erc20_address": resolved["erc20_address"],
            "bridge_address": resolved["bridge_address"],
            "is_circle_pattern": resolved["is_circle_pattern"],
            "token_index": resolved["token_index"],
        }

    # Single-token mode.
    if token is not None:
        upper = token.upper()
        if upper == "HYPE":
            entry = _read_native_hype()
            entry["address"] = query_addr
            output(entry, opts.get("fields"))
            return

        token_dict = None
        for t in spot_meta.get("tokens", []):
            if t.get("name", "").upper() == upper:
                token_dict = t
                break
        if token_dict is None:
            die("validation_error", "UNKNOWN_TOKEN",
                f"Token '{token}' not found in HL spot_meta",
                hint="List available tokens with `regard hypercore spot pairs`.")

        resolved = _resolve_token_evm_contract(token_dict, w3)
        if resolved is None:
            die("validation_error", "TOKEN_NOT_LINKED",
                f"Token '{token}' has no HyperEVM contract — not bridgeable.",
                hint="Only tokens with a linked evmContract have a HyperEVM-side balance.")

        entry = _read_erc20(token_dict, resolved)
        if "error" in entry:
            die("venue_error", "BALANCE_READ_FAILED",
                entry["error"].removeprefix("BALANCE_READ_FAILED: "),
                exit_code=4)
        entry["address"] = query_addr
        output(entry, opts.get("fields"))
        return

    # All-tokens mode: HYPE + every spot_meta token with an evmContract.
    balances = [_read_native_hype()]
    for t in spot_meta.get("tokens", []):
        if t.get("evmContract") is None:
            continue
        if t.get("name", "").upper() == "HYPE":
            continue  # already handled
        resolved = _resolve_token_evm_contract(t, w3)
        if resolved is None:
            continue
        balances.append(_read_erc20(t, resolved))

    output({
        "address": query_addr,
        "balances": balances,
        "total": len(balances),
    }, opts.get("fields"))


# ---------------------------------------------------------------------------
# arbitrum bridge hypercore
# ---------------------------------------------------------------------------


@arbitrum_bridge_app.command("hypercore")
def arbitrum_bridge_hypercore(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="USDC amount (>=5 USDC; below this funds are LOST)")],
    to: Annotated[str, typer.Option("--to", help="Must be 'self' (Bridge2 credits sender's HL perp)")] = "",
):
    """Bridge native USDC from Arbitrum to HL perp clearinghouse.

    Sends an ERC-20 transfer of native USDC to Hyperliquid's Bridge2 contract
    (0x2df1c5...). Validators auto-credit the sender's HL perp account in
    under 1 minute. USDC is implicit; min 5 USDC (HL-enforced; below this
    funds are silently LOST).
    """
    opts = ctx.obj
    import eth_account

    from regard.core.audit import log_event
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()

    if not to:
        die("validation_error", "MISSING_DESTINATION",
            "Bridge commands require --to with no implicit default",
            hint="Bridge2 credits the sender's address — use --to self.")

    if to != "self":
        die("validation_error", "BRIDGE_RECIPIENT_NOT_SELF",
            f"arbitrum bridge hypercore credits the sender's HL perp; got --to '{to}'",
            hint="Use --to self. Bridge2 protocol credits sender — no third-party recipient.")

    amt = Decimal(amount)
    if amt < ARB_MIN_DEPOSIT:
        die("validation_error", "MIN_DEPOSIT_NOT_MET",
            f"Arbitrum -> HL deposit is {amt} USDC; minimum is {ARB_MIN_DEPOSIT} USDC. "
            f"Below this minimum, Hyperliquid silently loses the deposit.",
            hint=f"Increase amount to at least {ARB_MIN_DEPOSIT}, or use a different path.")

    # Resolve sender address from EVM key.
    key = _get_key()
    sender = eth_account.Account.from_key(key).address

    # Source-gas hard block — must verify before proposing (can't sign without gas).
    w3 = _get_arbitrum_web3()
    require_source_gas("arbitrum", w3, sender)

    # USDC ERC-20 source-balance check.
    from regard.core.evm import get_erc20_balance
    try:
        balance_raw = get_erc20_balance(w3, sender, ARB_USDC_CONTRACT)
        balance = Decimal(balance_raw) / Decimal(10**ARB_USDC_DECIMALS)
    except Exception as e:
        die("venue_error", "BALANCE_CHECK_FAILED",
            f"Could not read Arbitrum USDC balance for {sender}: {e}",
            exit_code=4)

    if balance < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"Arbitrum USDC balance is {balance}, cannot bridge {amt}",
            hint="Fund the sender's Arbitrum address with USDC.",
            exit_code=4)

    # Safety gates (per-venue daily cap + cooldown + amount cap).
    check_amount_cap(amt, "USDC", settings_env)
    check_daily_cap(amt, "USDC", "arbitrum", settings_env)
    check_cooldown(HL_BRIDGE2_CONTRACT, settings_env)

    risk = classify_risk(amt, balance)

    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Bridging {amt/balance*100:.0f}% of Arbitrum USDC balance"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Bridging {amt/balance*100:.0f}% of Arbitrum USDC balance. Approve will require --confirm-addr"})

    amount_raw = int(amt * Decimal(10**ARB_USDC_DECIMALS))

    params = {
        "sender": sender,
        "dest_address": HL_BRIDGE2_CONTRACT,  # the EVM tx target (Bridge2 contract)
        "dest_label": "HL_BRIDGE2",
        "recipient_on_hl": sender,  # user's own HL EOA, used by CRITICAL gate (locked decision 18)
        "token_address": ARB_USDC_CONTRACT,
        "token": "USDC",
        "amount": str(amt),
        "amount_raw": str(amount_raw),
        "chain": "arbitrum",
    }
    checks = {
        "sender": sender,
        "arbitrum_usdc_balance": str(balance),
        "projected_arbitrum_usdc": str(balance - amt),
        "credited_on_hl_perp": str(amt),  # full amount credits — no fee on the deposit side
        "estimated_credit_minutes": "<1",
        "risk": risk,
    }

    log_event("proposed", command="bridge.hypercore", venue="arbitrum",
              to=HL_BRIDGE2_CONTRACT, to_label="HL_BRIDGE2", token="USDC", amount=str(amt), risk=risk)
    proposal = create_proposal("arbitrum", "bridge.hypercore", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_arbitrum_bridge_hypercore_safety(params: dict) -> None:
    """Re-check safety at approve time (defense-in-depth + source-gas re-check)."""
    import eth_account

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), "USDC", "arbitrum", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    key = _get_key()
    current_addr = eth_account.Account.from_key(key).address
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")

    # Re-check source gas — could have been spent between propose and approve.
    w3 = _get_arbitrum_web3()
    require_source_gas("arbitrum", w3, current_addr)


def execute_arbitrum_bridge_hypercore(params: dict) -> dict:
    """Sign + broadcast the Arbitrum ERC-20 transfer to the Bridge2 contract."""
    import eth_account

    from regard.core.audit import log_event
    from regard.core.evm import transfer_erc20
    from regard.venues.polymarket.client import _get_key

    validate_arbitrum_bridge_hypercore_safety(params)

    key = _get_key()
    account = eth_account.Account.from_key(key)
    w3 = _get_arbitrum_web3()

    dest = params["dest_address"]
    token_address = params["token_address"]
    amount_raw = int(params["amount_raw"])

    try:
        tx_hash = transfer_erc20(w3, account, dest, token_address, amount_raw)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "BRIDGE_FAILED", str(e), exit_code=4)

    tx_hex = f"0x{tx_hash.hex()}"

    try:
        log_event("executed", command="bridge.hypercore", venue="arbitrum",
                  to=dest, to_label=params["dest_label"], token="USDC",
                  amount=params["amount"], tx_hash=tx_hex)
    except Exception as e:
        print(f"WARNING: audit log write failed ({e}) — bridge tx broadcast: {tx_hex}", file=sys.stderr)

    return {
        "status": "bridged",
        "destination": dest,
        "destination_label": params["dest_label"],
        "recipient_on_hl": params["recipient_on_hl"],
        "chain": "arbitrum",
        "token": "USDC",
        "amount": params["amount"],
        "tx_hash": tx_hex,
        "estimated_credit_minutes": "<1",
    }


register_executor("arbitrum", "bridge.hypercore", execute_arbitrum_bridge_hypercore)
register_safety_validator("arbitrum", "bridge.hypercore", validate_arbitrum_bridge_hypercore_safety)


# ---------------------------------------------------------------------------
# hyperevm bridge hypercore
# ---------------------------------------------------------------------------


@hyperevm_bridge_app.command("hypercore")
def hyperevm_bridge_hypercore(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Token amount")],
    to: Annotated[str, typer.Option("--to", help="Must be 'self' (system tx credits msg.sender)")] = "",
    token: Annotated[str, typer.Option("--token", help="Token name (HYPE, USDC, USDH, ...) — required")] = "",
):
    """Bridge a HyperEVM token back to HL spot.

    For HYPE: native value-send to system address 0x2222...2222 (the system
    contract emits Received event). For ERC-20 tokens: transfer to the token's
    system address; HL credits sender's spot account next-block.
    """
    opts = ctx.obj
    import eth_account

    from regard.core.audit import log_event
    from regard.core.evm import get_erc20_balance
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk
    from regard.venues.hyperliquid.client import get_info
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()

    if not to:
        die("validation_error", "MISSING_DESTINATION",
            "Bridge commands require --to with no implicit default",
            hint="HyperEVM->HyperCore credits msg.sender — use --to self.")

    if to != "self":
        die("validation_error", "BRIDGE_RECIPIENT_NOT_SELF",
            f"hyperevm bridge hypercore credits the sender's HL spot; got --to '{to}'",
            hint="Use --to self. The system tx credits msg.sender — no third-party recipient.")

    if not token:
        die("validation_error", "MISSING_TOKEN",
            "Must specify --token (e.g. HYPE, USDC, USDH)",
            hint="regard hyperevm bridge hypercore --to self <amount> --token HYPE")

    # Locked decision 15: normalize token name BEFORE branching.
    token = token.upper()

    key = _get_key()
    sender = eth_account.Account.from_key(key).address

    # Source-gas hard block.
    w3 = _get_hyperevm_web3()
    require_source_gas("hyperevm", w3, sender)

    info = get_info(opts["testnet"])
    system_addr = _system_address_for_token(token, info)

    is_native = (token == "HYPE")
    is_circle_pattern = False
    erc20_address = None  # actual ERC-20 contract for balance reads
    bridge_address = None  # CoreDepositWallet for Circle pattern, else same as erc20
    auth_payload = None  # EIP-3009 signed authorization for Circle pattern
    if is_native:
        # HYPE balance is the native gas token balance — read via eth_getBalance.
        # Note: the same balance was just checked by require_source_gas, so we read
        # it again here only to validate amount fits (gas threshold is independent).
        balance_native = _native_balance(w3, sender)
        if balance_native is None:
            die("venue_error", "BALANCE_CHECK_FAILED",
                f"Could not read HyperEVM HYPE balance for {sender}",
                exit_code=4)
        balance = balance_native
        token_address = None
        amount_raw = int(Decimal(amount) * Decimal(10**18))
    else:
        # Linked-token resolution: detect Circle CoreDepositWallet pattern
        # (USDC) vs direct ERC-20 (USDH/USDT0/USDE/PURR). Returns the actual
        # ERC-20 address for balanceOf, the bridge address for the execute
        # path, and is_circle_pattern flag.
        resolved = _resolve_hyperevm_erc20(token, info, w3)
        if resolved is None:
            die("validation_error", "BRIDGE_TOKEN_NOT_LINKED",
                f"Token {token} has no linked HyperEVM ERC-20 contract.",
                hint=f"Pick a linked token (USDC, HYPE, USDH, USDE, USDT0, PURR), or wait for {token} to be linked.")
        erc20_address = resolved["erc20_address"]
        bridge_address = resolved["bridge_address"]
        is_circle_pattern = resolved["is_circle_pattern"]
        wei_decimals = resolved["wei_decimals"]
        # token_address in the proposal params is the contract the execute
        # path interacts with: bridge_address for Circle (CoreDepositWallet),
        # erc20_address for direct ERC-20 (`transfer` to system addr).
        token_address = bridge_address if is_circle_pattern else erc20_address

        # For Circle pattern: hard-block at propose if the bridge is paused.
        # No point letting the user sign an auth that will revert at execute.
        if is_circle_pattern and _is_bridge_paused(w3, bridge_address):
            die("venue_error", "BRIDGE_PAUSED",
                f"{token} bridge contract at {bridge_address} is paused.",
                hint="Circle has paused the CoreDepositWallet. Retry later.",
                exit_code=4)

        # Read balanceOf from the ACTUAL ERC-20 (Circle pattern: not the
        # CoreDepositWallet, which has no balanceOf). Direct ERC-20 path:
        # balance read works as before.
        try:
            balance_raw = get_erc20_balance(w3, sender, erc20_address)
        except Exception as e:
            die("venue_error", "BALANCE_CHECK_FAILED",
                f"Could not read {token} ERC-20 balance for {sender} at {erc20_address}: {e}",
                exit_code=4)
        balance = Decimal(balance_raw) / Decimal(10**wei_decimals)
        amount_raw = int(Decimal(amount) * Decimal(10**wei_decimals))

    amt = Decimal(amount)
    if balance < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"HyperEVM {token} balance is {balance}, cannot bridge {amt}",
            hint=f"Fund the sender with {token} on HyperEVM.",
            exit_code=4)

    # Safety gates.
    check_amount_cap(amt, token, settings_env)
    check_daily_cap(amt, token, "hyperevm", settings_env)
    check_cooldown(system_addr, settings_env)

    risk = classify_risk(amt, balance)
    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Bridging {amt/balance*100:.0f}% of HyperEVM {token} balance"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Bridging {amt/balance*100:.0f}% of HyperEVM {token} balance. Approve will require --confirm-addr"})

    # Circle pattern: sign EIP-3009 receiveWithAuthorization at propose time
    # so execute can broadcast a single atomic depositWithAuth tx (no separate
    # approve required). Read EIP-712 domain on-chain (defensive — Circle's
    # FiatTokenV2_2 uses name="USD Coin", version="2", but reading avoids
    # silent mismatch if HyperEVM has a custom variant).
    # Activation-fee disclosure: CoreDepositWallet deducts 1 USDC (newCoreAccountFee
    # at default 100000000 in 8-decimal Core units) from the credited amount
    # when bridging to a fresh HyperCore account. Surface this in the proposal
    # checks so users see the exact `recipient_credited` before approving.
    credited_on_hl_spot = amt
    activation_fee_quote: Decimal | None = None
    recipient_is_fresh = False
    if is_circle_pattern:
        # Type narrowing: is_circle_pattern only set True after _resolve returns
        # a dict with non-None erc20_address + bridge_address.
        assert erc20_address is not None
        assert bridge_address is not None
        recipient_is_fresh = _is_fresh_hl_core_user(w3, sender)
        if recipient_is_fresh:
            # 1 USDC fee deducted in Core units (8 decimals = $1.00).
            activation_fee_quote = Decimal("1")
            credited_on_hl_spot = max(amt - activation_fee_quote, Decimal(0)).quantize(Decimal("0.000001"))
            warnings.append({
                "type": "RECIPIENT_FRESH_CORE_ACCOUNT",
                "message": (
                    f"Recipient {sender} is a fresh HyperCore account. Per "
                    f"CoreDepositWallet, the first deposit credits "
                    f"{credited_on_hl_spot} {token} (full amount minus 1 {token} "
                    f"newCoreAccountFee), not the full {amt} {token}."
                ),
                "fee_amount": "1",
                "fee_token": token,
            })
            if amt <= activation_fee_quote:
                warnings.append({
                    "type": "ACTIVATION_FEE_EXCEEDS_AMOUNT",
                    "message": (
                        f"Bridge amount ({amt} {token}) does not exceed the "
                        f"1 {token} newCoreAccountFee. CoreDepositWallet "
                        f"will revert with 'Amount must exceed new account fee'."
                    ),
                })

        domain_name, domain_version = _read_eip712_domain(w3, erc20_address)
        try:
            chain_id = w3.eth.chain_id
        except Exception:
            chain_id = 999  # HyperEVM mainnet (per docs/CONSTANTS.md)
        nonce_bytes = secrets.token_bytes(32)
        # validBefore covers the entire pending TTL window so the auth can't
        # expire before the proposal does. Default project pending-ttl is 15
        # min; max is 1440 (24h). Bound at 24h + 5min buffer to cover any
        # configuration. Per Codex peer review 2026-05-07.
        valid_after = 0
        valid_before = int(time.time()) + 24 * 3600 + 300
        v, r_bytes, s_bytes = _sign_eip3009_receive_with_auth(
            private_key=key,
            erc20_addr=erc20_address,
            domain_name=domain_name,
            domain_version=domain_version,
            chain_id=chain_id,
            from_addr=sender,
            to_addr=bridge_address,  # CoreDepositWallet receives the auth-pulled tokens
            value=amount_raw,
            valid_after=valid_after,
            valid_before=valid_before,
            nonce=nonce_bytes,
        )
        auth_payload = {
            "valid_after": valid_after,
            "valid_before": valid_before,
            "nonce": "0x" + nonce_bytes.hex(),
            "v": v,
            "r": "0x" + r_bytes.hex(),
            "s": "0x" + s_bytes.hex(),
            "domain_name": domain_name,
            "domain_version": domain_version,
            "chain_id": chain_id,
        }

    params = {
        "sender": sender,
        "dest_address": system_addr,  # EVM tx target (system address for the token)
        "dest_label": f"HYPERCORE_SYSTEM_{token}",
        "recipient_on_hl": sender,  # user's HL EOA, used by CRITICAL gate (locked decision 18)
        "token": token,
        "token_address": token_address,  # None for HYPE, bridge_address for Circle, erc20 for direct
        "erc20_address": erc20_address,  # actual ERC-20 (None for HYPE)
        "bridge_address": bridge_address,  # CoreDepositWallet for Circle pattern (None for HYPE/direct)
        "is_native": is_native,
        "is_circle_pattern": is_circle_pattern,
        "amount": str(amt),
        "amount_raw": str(amount_raw),
        "chain": "hyperevm",
    }
    if auth_payload is not None:
        params["auth"] = auth_payload

    checks = {
        "sender": sender,
        "system_address": system_addr,
        "hyperevm_balance": str(balance),
        "projected_hyperevm": str((balance - amt).quantize(Decimal("0.000001"))),
        "credited_on_hl_spot": str(credited_on_hl_spot),
        "estimated_credit_block": "next",
        "risk": risk,
    }
    if is_circle_pattern:
        checks["bridge_contract"] = bridge_address
        checks["erc20_contract"] = erc20_address
        checks["bridge_mechanism"] = "CoreDepositWallet.depositWithAuth (EIP-3009)"
    if activation_fee_quote is not None:
        checks["new_core_account_fee"] = str(activation_fee_quote)
        checks["new_core_account_fee_basis"] = (
            "CoreDepositWallet.newCoreAccountFee = 100000000 (8-decimal Core "
            "units = 1 USDC); deducted when recipient does not exist on "
            "HyperCore (verified via L1Read coreUserExists precompile 0x...0810)"
        )

    log_event("proposed", command="bridge.hypercore", venue="hyperevm",
              to=system_addr, to_label=f"HYPERCORE_SYSTEM_{token}", token=token, amount=str(amt), risk=risk)
    proposal = create_proposal("hyperevm", "bridge.hypercore", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_hyperevm_bridge_hypercore_safety(params: dict) -> None:
    """Re-check safety at approve time (defense-in-depth + source-gas re-check)."""
    import eth_account

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), params["token"], "hyperevm", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    key = _get_key()
    current_addr = eth_account.Account.from_key(key).address
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")

    w3 = _get_hyperevm_web3()
    require_source_gas("hyperevm", w3, current_addr)


def _execute_circle_deposit_with_auth(w3, account, params: dict) -> bytes:
    """Build, sign, and broadcast a CoreDepositWallet.depositWithAuth call.

    The EIP-3009 receiveWithAuthorization signature (v, r, s, nonce, validAfter,
    validBefore) was produced at propose time with the same key now signing the
    transaction wrapper. The sign-now-broadcast-later split is fine because the
    auth window is generous (24h+5min from propose time per Codex peer review
    2026-05-07) and the auth nonce is single-use, so a replay attempt would
    revert with "FiatTokenV2: authorization is used or canceled".

    destinationDex is hardcoded to uint32.max (Core Spot dex) — the symmetric
    inverse of the K Test 2 outbound path. A `--dex perp|spot` flag could be
    added later if a use case emerges.
    """
    from web3 import Web3

    bridge_address = params["bridge_address"]
    auth = params.get("auth") or {}
    contract = w3.eth.contract(address=Web3.to_checksum_address(bridge_address), abi=[COREDEPOSIT_DEPOSITWITHAUTH_ABI])

    amount_raw = int(params["amount_raw"])
    valid_after = int(auth["valid_after"])
    valid_before = int(auth["valid_before"])
    nonce_bytes = bytes.fromhex(auth["nonce"][2:])
    v = int(auth["v"])
    r = bytes.fromhex(auth["r"][2:])
    s = bytes.fromhex(auth["s"][2:])

    # Build the tx with explicit gas + nonce. depositWithAuth runs ECDSA
    # recover + transferFrom + Transfer event + CoreWriter precompile; budget
    # 500k gas as a safe upper bound (typical usage: ~150-200k).
    nonce = w3.eth.get_transaction_count(account.address)
    from regard.core.evm import get_safe_gas_price
    gas_price = get_safe_gas_price(w3)

    tx = contract.functions.depositWithAuth(
        amount_raw,
        valid_after,
        valid_before,
        nonce_bytes,
        v,
        r,
        s,
        _CORE_SPOT_DEX_ID,
    ).build_transaction({
        "from": account.address,
        "nonce": nonce,
        "gas": 500_000,
        "gasPrice": gas_price,
        "chainId": w3.eth.chain_id,
    })
    signed = account.sign_transaction(tx)
    raw_tx = signed.raw_transaction if hasattr(signed, "raw_transaction") else signed.rawTransaction
    return w3.eth.send_raw_transaction(raw_tx)


def execute_hyperevm_bridge_hypercore(params: dict) -> dict:
    """Sign + broadcast the HyperEVM tx.

    Three execute paths:

    - **HYPE (is_native)**: native value-send to the system address. Gas limit
      explicitly overridden to 100_000 per locked decision 15 (the default 21k
      is insufficient because the system contract emits a LOG3).

    - **Circle CoreDepositWallet (is_circle_pattern, e.g. USDC)**: call
      `depositWithAuth(amount, validAfter, validBefore, nonce, v, r, s,
      destinationDex)` on the bridge contract. The EIP-3009 receiveWithAuth
      signature was generated at propose time and lives in `params['auth']`.
      Single atomic tx — no separate approve required (per V025-IMPLEMENTATION.md
      Decision 24, post-Codex peer review 2026-05-07).

    - **Direct ERC-20 (USDH/USDT0/USDE/PURR)**: `transfer(systemAddress, amount)`
      on the ERC-20 directly. The token contract's transfer event is what HL
      indexes to credit the user's spot account.
    """
    import eth_account

    from regard.core.audit import log_event
    from regard.core.evm import transfer_erc20, transfer_native
    from regard.venues.polymarket.client import _get_key

    validate_hyperevm_bridge_hypercore_safety(params)

    key = _get_key()
    account = eth_account.Account.from_key(key)
    w3 = _get_hyperevm_web3()

    dest = params["dest_address"]
    amount_raw = int(params["amount_raw"])

    try:
        if params.get("is_native"):
            # HYPE: native value-send with explicit gas_limit override.
            tx_hash = transfer_native(w3, account, dest, amount_raw, gas_limit=HYPE_BRIDGE_GAS_LIMIT)
        elif params.get("is_circle_pattern"):
            # Circle CoreDepositWallet: depositWithAuth (EIP-3009 atomic).
            tx_hash = _execute_circle_deposit_with_auth(w3, account, params)
        else:
            # Direct ERC-20: transfer to the token's system address.
            token_address = params["token_address"]
            tx_hash = transfer_erc20(w3, account, dest, token_address, amount_raw)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "BRIDGE_FAILED", str(e), exit_code=4)

    tx_hex = f"0x{tx_hash.hex()}"

    try:
        log_event("executed", command="bridge.hypercore", venue="hyperevm",
                  to=dest, to_label=params["dest_label"], token=params["token"],
                  amount=params["amount"], tx_hash=tx_hex)
    except Exception as e:
        print(f"WARNING: audit log write failed ({e}) — bridge tx broadcast: {tx_hex}", file=sys.stderr)

    return {
        "status": "bridged",
        "destination": dest,
        "destination_label": params["dest_label"],
        "recipient_on_hl": params["recipient_on_hl"],
        "chain": "hyperevm",
        "token": params["token"],
        "amount": params["amount"],
        "tx_hash": tx_hex,
        "is_native": params.get("is_native", False),
    }


register_executor("hyperevm", "bridge.hypercore", execute_hyperevm_bridge_hypercore)
register_safety_validator("hyperevm", "bridge.hypercore", validate_hyperevm_bridge_hypercore_safety)


# Wire bridge subapps onto their env apps.
arbitrum_app.add_typer(arbitrum_bridge_app, name="bridge")
hyperevm_app.add_typer(hyperevm_bridge_app, name="bridge")
