"""regard — AI trading partner for the unified speculator."""

import json
import sys
from importlib.metadata import version as pkg_version
from typing import Annotated

import click
import typer


def _version_callback(value: bool):
    if value:
        print(pkg_version("regard-cli"))
        raise typer.Exit()


app = typer.Typer(
    name="regard",
    add_completion=False,
    no_args_is_help=True,
    help="AI trading partner for the unified speculator.",
    pretty_exceptions_enable=False,
    pretty_exceptions_show_locals=False,
    rich_markup_mode=None,
)

hypercore_app = typer.Typer(
    name="hypercore",
    no_args_is_help=True,
    help="Hyperliquid (Hypercore L1 trading layer): perps, spot CLOB, HIP-3 dexes, HIP-4 outcomes. JSON output by default.",
    pretty_exceptions_enable=False,
)

polygon_app = typer.Typer(
    name="polygon",
    no_args_is_help=True,
    help="Polygon chain operations: token transfers and sends among Polygon-native tokens (USDC, USDC.e, pUSD, POL).",
    pretty_exceptions_enable=False,
)

polymarket_app = typer.Typer(
    name="polymarket",
    no_args_is_help=True,
    help="Polymarket prediction market trading. JSON output by default.",
    pretty_exceptions_enable=False,
)


# ---------------------------------------------------------------------------
# Global safety net — every exit path must produce valid JSON on stdout.
# Monkey-patch Click exception classes so even Typer parse errors (missing
# args, unknown flags, bad types) produce JSON instead of Rich formatting.
# ---------------------------------------------------------------------------

def _json_show(self, file=None):
    err = {
        "ok": False,
        "error": {
            "type": "validation_error",
            "code": "USAGE_ERROR",
            "message": self.format_message(),
            "retryable": False,
        },
        "meta": {"exit_code": 2},
    }
    print(json.dumps(err, separators=(",", ":")), file=file or sys.stdout, flush=True)

click.ClickException.show = _json_show
click.UsageError.show = _json_show
click.BadParameter.show = _json_show


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit"),
    fields: str | None = typer.Option(None, "--fields", help="Comma-separated field projection"),
    verbose: bool = typer.Option(False, "--verbose", help="Debug info to stderr"),
):
    """Regard CLI — multi-venue trading."""
    ctx.ensure_object(dict)
    ctx.obj["fields"] = fields
    ctx.obj["verbose"] = verbose


@hypercore_app.callback()
def hypercore_main(
    ctx: typer.Context,
    testnet: bool = typer.Option(False, "--testnet", help="Use testnet endpoints"),
):
    """Hyperliquid Hypercore (L1 trading layer) CLI."""
    ctx.ensure_object(dict)
    ctx.obj["testnet"] = testnet


@polygon_app.callback()
def polygon_main(ctx: typer.Context):
    """Polygon chain operations CLI."""
    ctx.ensure_object(dict)


@polymarket_app.callback()
def polymarket_main(ctx: typer.Context):
    """Polymarket trading CLI."""
    ctx.ensure_object(dict)


# Per V025 locked decision 20, arbitrum_app and hyperevm_app are constructed
# in venues/hyperliquid/inbound_bridge.py and imported here for registration.
# Their callbacks live there too.

app.add_typer(hypercore_app)
app.add_typer(polygon_app)
app.add_typer(polymarket_app)

# Session commands (top-level, not venue-specific)
from regard.commands.session import session_app  # noqa: E402

app.add_typer(session_app)

# Update check (top-level)
from regard.commands.update import update_app  # noqa: E402

app.add_typer(update_app)

# Wallet setup (top-level)
from regard.commands.wallet import wallet_app  # noqa: E402

app.add_typer(wallet_app)

# Config (top-level)
from regard.commands.config import config_app  # noqa: E402

app.add_typer(config_app)

# Address book (top-level)
from regard.commands.address import address_app  # noqa: E402

app.add_typer(address_app)

# Killswitch (top-level)
from regard.commands.killswitch import killswitch_app  # noqa: E402

app.add_typer(killswitch_app)

# Watchers (top-level)
from regard.commands.watch import watch_app  # noqa: E402

app.add_typer(watch_app)

# Register all hypercore venue commands — must be after hypercore_app is defined
# Cross-venue portfolio
from regard.commands.portfolio import portfolio_app  # noqa: E402
from regard.venues.hyperliquid.commands import act, orient, research, review  # noqa: E402, F401

# Inbound bridges (EVM-signed) — defines arbitrum_app and hyperevm_app top-level
# typer subapps + registers their executors. Per V025 locked decision 20.
from regard.venues.hyperliquid.inbound_bridge import (  # noqa: E402
    arbitrum_app,
    hyperevm_app,
)

# Polymarket / Polygon venue commands — must be after polymarket_app + polygon_app are defined
from regard.venues.polymarket.commands import act as _poly_act  # noqa: E402, F401
from regard.venues.polymarket.commands import orient as _poly_orient  # noqa: E402, F401
from regard.venues.polymarket.commands import research as _poly_research  # noqa: E402, F401
from regard.venues.polymarket.commands import review as _poly_review  # noqa: E402, F401

app.add_typer(arbitrum_app)
app.add_typer(hyperevm_app)

app.add_typer(portfolio_app)


# ---------------------------------------------------------------------------
# Approve — execute a pending proposal (Constitution Article II)
# ---------------------------------------------------------------------------

@app.command()
def approve(
    proposal_id: Annotated[str, typer.Argument(help="Proposal ID (e.g. p_7f3a8b2c1d4e)")],
    confirm_addr: Annotated[str | None, typer.Option("--confirm-addr", help="Required for CRITICAL-risk sends: first 6 hex chars of dest address")] = None,
):
    """Approve and execute a pending proposal."""
    import math

    from regard.core.output import die, output
    from regard.core.proposal import (
        approve_proposal,
        claim_proposal,
        find_approved_result,
        get_executor,
        get_safety_validator,
        read_proposal,
        reject_proposal,
    )

    # 0. Validate proposal ID format (prevents path traversal)
    try:
        from regard.core.proposal import _validate_proposal_id
        _validate_proposal_id(proposal_id)
    except ValueError:
        die("validation_error", "INVALID_PROPOSAL_ID",
            f"Invalid proposal ID format: {proposal_id}",
            hint="Proposal IDs are p_ followed by 12 hex characters (e.g. p_7f3a8b2c1d4e)")

    # 1. Idempotency — already approved?
    cached = find_approved_result(proposal_id)
    if cached is not None:
        output({"status": "already_approved", "proposal_id": proposal_id, "result": cached})
        return

    # 2. Read proposal
    proposal = read_proposal(proposal_id)
    if proposal is None:
        die("validation_error", "PROPOSAL_NOT_FOUND",
            f"No pending proposal '{proposal_id}'",
            hint="Check pending proposals or verify the ID")

    # 2b. CRITICAL-risk gate — require --confirm-addr
    # Matches sends (`*.send`, `send`) and bridges (`*.bridge.*`). Any wallet-
    # to-wallet or chain-crossing transfer at CRITICAL risk requires the gate.
    # Per V025 locked decision 18: when the proposal sets `recipient_on_hl`
    # (e.g. `--to self` bridges or inbound bridges where dest_address is a
    # protocol-constant contract), confirm against `recipient_on_hl` (the
    # user's HL EOA, which IS user-specific) rather than dest_address (which
    # would be a constant for every user).
    _cmd = proposal.get("command", "")
    _cmd_parts = _cmd.split(".")
    _is_destination_cmd = (
        _cmd == "send"
        or _cmd_parts[-1] == "send"
        or "bridge" in _cmd_parts
    )
    if (
        _is_destination_cmd
        and proposal.get("checks", {}).get("risk") == "CRITICAL"
    ):
        params = proposal.get("params", {})
        confirm_field = params.get("recipient_on_hl") or params.get("dest_address", "")
        # Expect first 6 hex chars after 0x prefix (e.g. "F373B4")
        expected = confirm_field[2:8].lower() if confirm_field.startswith("0x") and len(confirm_field) >= 8 else confirm_field[:6].lower()
        if not confirm_addr:
            die("validation_error", "CONFIRM_ADDR_REQUIRED",
                f"CRITICAL-risk operation: pass --confirm-addr {expected} to confirm destination",
                hint=f"Confirming address: {confirm_field}")
        if confirm_addr.lower().removeprefix("0x")[:6] != expected:
            die("validation_error", "CONFIRM_ADDR_MISMATCH",
                f"--confirm-addr '{confirm_addr}' does not match {confirm_field}",
                hint=f"Expected: --confirm-addr {expected}")

    # 3. Price delta check — reject if price moved beyond threshold
    mark_price = proposal["checks"].get("mark_price")
    if mark_price is not None:
        try:
            old = float(mark_price)
        except (ValueError, TypeError):
            old = float("nan")  # route to the rejection below
        if not math.isfinite(old) or old <= 0:
            reject_proposal(proposal_id, "invalid_mark_price", mark_price=str(mark_price))
            die("validation_error", "INVALID_MARK_PRICE",
                f"Proposal has invalid mark_price: {mark_price}",
                hint="Create a new proposal",
                extra={"execution_state": "not_executed"})

        current_price = _fetch_current_price(proposal["venue"], proposal["params"])

        # 3c. Fail-closed: if we can't fetch the current price, refuse
        if current_price is None:
            die("venue_error", "PRICE_FETCH_FAILED",
                f"Could not fetch current price for {proposal['venue']} — cannot verify price safety",
                hint="Retry shortly. If the venue is down, wait and try again.",
                retryable=True,
                extra={"execution_state": "not_executed"},
                exit_code=4)

        # 3b + 3d. Price delta with Decimal precision and crash protection.
        # HIP-4 outcomes get an additional absolute-price threshold (0.01)
        # because the [0.001, 0.999] domain makes percentage-only checks
        # too loose on thin books. "Whichever is stricter" — reject if
        # either pct OR absolute delta exceeds its threshold.
        try:
            from decimal import Decimal
            d_old = Decimal(str(mark_price))
            d_new = Decimal(str(current_price))
            if d_new > 0:
                abs_delta = abs(d_new - d_old)
                delta_pct = float(abs_delta / d_old * 100)
                threshold_pct, threshold_abs = _get_price_threshold(
                    proposal["venue"], proposal.get("params")
                )
                pct_exceeded = delta_pct > threshold_pct
                abs_exceeded = (
                    threshold_abs is not None
                    and float(abs_delta) > threshold_abs
                )
                if pct_exceeded or abs_exceeded:
                    threshold_label = (
                        f"{threshold_pct}% pct or {threshold_abs} absolute"
                        if threshold_abs is not None
                        else f"{threshold_pct}%"
                    )
                    reject_proposal(
                        proposal_id, "price_delta",
                        delta=f"{delta_pct:.2f}%",
                        old_price=mark_price,
                        new_price=current_price,
                        threshold=threshold_label,
                    )
                    # Surface threshold components as separate machine-readable
                    # fields so agents can pattern-match on which condition
                    # triggered without parsing the human-readable label.
                    # `triggered_by`: "pct" / "abs" / "both" so an agent
                    # surfaces the right recovery hint.
                    triggered_by = (
                        "both" if pct_exceeded and abs_exceeded
                        else "abs" if abs_exceeded
                        else "pct"
                    )
                    die("validation_error", "PRICE_DELTA_EXCEEDED",
                        f"Price moved {delta_pct:.2f}% (abs {float(abs_delta):.6f}) since proposal "
                        f"(was {mark_price}, now {current_price}, threshold {threshold_label})",
                        hint="Create a new proposal with current prices",
                        extra={
                            "old_price": mark_price,
                            "new_price": current_price,
                            "delta": f"{delta_pct:.2f}%",
                            "abs_delta": str(abs_delta),
                            "threshold": threshold_label,
                            "threshold_pct": threshold_pct,
                            "threshold_abs": threshold_abs,
                            "triggered_by": triggered_by,
                            "execution_state": "not_executed",
                        })
        except SystemExit:
            raise
        except Exception:
            # Non-numeric current_price or other conversion error
            die("venue_error", "PRICE_CHECK_FAILED",
                f"Price delta check failed — could not compare prices (proposal: {mark_price}, current: {current_price})",
                hint="Create a new proposal",
                extra={"execution_state": "not_executed"},
                exit_code=4)

    # 4. Look up executor
    venue = proposal["venue"]
    command = proposal["command"]
    executor = get_executor(venue, command)
    if executor is None:
        die("internal_error", "NO_EXECUTOR",
            f"No executor registered for {venue}.{command}",
            exit_code=7)

    # 5. Rate limit executions — check BEFORE claim so the proposal isn't
    #    consumed if the rate limit fires.
    from regard.core.proposal import _check_rate_limit, get_workspace_dir
    _check_rate_limit(get_workspace_dir(), "approved", "EXECUTION_RATE_EXCEEDED")

    # 5b. Pre-claim safety re-checks (sender key, cooldown, daily cap). These
    # verify state that may have drifted between propose and approve. Run here
    # so a fixable mismatch (wrong env key, short cooldown) doesn't consume the
    # pending file — the user can fix and retry the same proposal.
    validator = get_safety_validator(venue, command)
    if validator is not None:
        validator(proposal["params"])

    # 6. Claim — atomic compare-and-swap BEFORE execution.
    #    If another process already claimed this proposal, return idempotent result.
    claimed = claim_proposal(proposal_id)
    if not claimed:
        # Another process claimed it. Check if it was approved already.
        cached = find_approved_result(proposal_id)
        if cached is not None:
            output({"status": "already_approved", "proposal_id": proposal_id, "result": cached})
            return
        die("venue_error", "ALREADY_CLAIMED",
            f"Proposal '{proposal_id}' was already claimed by another process",
            extra={"execution_state": "not_executed"},
            exit_code=4)

    # 7. Execute — pending file is gone, only this process proceeds
    try:
        result = executor(proposal["params"])
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "EXECUTION_FAILED", str(e),
            extra={"execution_state": "unknown", "proposal_id": proposal_id},
            exit_code=4)

    # 7. Log approval — event stream is the durable record.
    #    If logging fails (disk full, permission), the trade is already live.
    #    Output the result regardless — don't hide a successful trade behind an audit failure.
    import sys as _sys
    try:
        approve_proposal(proposal_id, result)
    except Exception as audit_err:
        _sys.stderr.write(f"[warn] approve_proposal audit failed for {proposal_id}: {audit_err}\n")
    output(result)


def _fetch_current_price(venue: str, params: dict) -> str | None:
    """Re-fetch the current mark price for a proposal's asset.

    Returns None if the price cannot be fetched (non-fatal — skip delta check).

    For HIP-4 outcomes (`#<encoding>` coins), `all_mids` doesn't surface the
    side mids, so we compute mid from the side's `l2_snapshot` (top_bid +
    top_ask) / 2 with Decimal precision. For perps/spot, the standard
    `all_mids` lookup applies.
    """
    testnet = params.get("testnet", False)
    try:
        if venue == "hypercore":
            asset = params.get("asset")
            if not asset:
                return None
            from regard.venues.hyperliquid.client import get_all_mids, get_info
            info = get_info(testnet)
            if isinstance(asset, str) and asset.startswith("#"):
                # HIP-4 outcome — mid from l2 book.
                from decimal import Decimal as _D

                from regard.venues.hyperliquid.resolver import get_resolver
                # Lazy-load outcomeMeta so info.coin_to_asset[asset] is
                # populated. Without this, the SDK's l2_snapshot raises on
                # unknown coin and the approve flow fails with
                # PRICE_FETCH_FAILED — discovered live during HIP-4 Cycle C
                # on bonbonki 2026-05-04 (v0.22.0).
                get_resolver(info).get_outcomes()
                if asset not in info.coin_to_asset:
                    return None
                snap = info.l2_snapshot(asset)
                levels = snap.get("levels", [[], []]) if snap else [[], []]
                if not levels or not levels[0] or not levels[1]:
                    return None
                top_bid = _D(levels[0][0]["px"])
                top_ask = _D(levels[1][0]["px"])
                return str((top_bid + top_ask) / _D(2))
            mids = get_all_mids(info)
            return mids.get(asset)
        elif venue == "polymarket":
            slug = params.get("market_slug")
            outcome = params.get("outcome")
            if not slug or not outcome:
                return None
            from regard.venues.polymarket.client import get_gamma_client
            from regard.venues.polymarket.market import resolve_market
            gamma = get_gamma_client()
            m = resolve_market(slug, gamma)
            if not m:
                return None
            price = m["yes_price"] if outcome == "yes" else m["no_price"]
            return str(price) if price > 0 else None
    except Exception:
        pass
    return None


def _get_price_threshold(venue: str, params: dict | None = None) -> tuple[float, float | None]:
    """Get the (pct_max, abs_max) price delta threshold for a proposal.

    `pct_max` is the percentage threshold; `abs_max` is an absolute-price
    threshold that, when not None, fires in addition to the pct check
    ("whichever is stricter" per Constitutional alignment).

    HIP-4 outcomes (`asset.startswith("#")`) get a tighter absolute floor
    of 0.01 because the [0.001, 0.999] price domain means percentage
    thresholds tuned for perps are too loose on a thin book — 5% on
    mark=0.50 is 0.025, half a major price move.
    """
    if venue == "hypercore" and params and isinstance(params.get("asset"), str) and params["asset"].startswith("#"):
        return 5.0, 0.01  # HIP-4: 5% pct OR 0.01 absolute, whichever rejects first
    if venue == "hypercore":
        return 0.5, None
    if venue == "polymarket":
        return 1.0, None
    return 0.5, None


# ---------------------------------------------------------------------------
# Schema — introspect the live command tree (Constitution Article V)
# ---------------------------------------------------------------------------

# Command classification per CLI Constitution Article I
_MUTATING = frozenset({
    # Hypercore trading
    "hypercore.order", "hypercore.stop", "hypercore.cancel", "hypercore.cancel-all",
    "hypercore.leverage",
    # Hypercore HIP-4 outcome split/merge (Phase 3 — userOutcome write actions)
    "hypercore.outcome-split", "hypercore.outcome-merge",
    # Hypercore HIP-4 question-level primitives (Phase 4 — userOutcome write actions)
    "hypercore.question-merge", "hypercore.question-negate",
    # Hypercore wallet-to-wallet send (spot + perp)
    "hypercore.spot.send", "hypercore.perp.send",
    # Hypercore fund-movement (compartment shifts via send_asset)
    "hypercore.perp.transfer.spot", "hypercore.perp.transfer.dex",
    "hypercore.spot.transfer.perp", "hypercore.spot.transfer.dex",
    "hypercore.dex.transfer.spot", "hypercore.dex.transfer.perp",
    "hypercore.dex.transfer.dex",
    # Hypercore outbound bridges (HL-signed)
    "hypercore.perp.bridge.arbitrum", "hypercore.spot.bridge.hyperevm",
    # Polymarket trading
    "polymarket.approve", "polymarket.order", "polymarket.cancel", "polymarket.cancel-all",
    "polymarket.redeem", "polymarket.merge",
    # Polygon chain operations
    "polygon.usdc.transfer.usdce", "polygon.usdce.transfer.pusd",
    "polygon.pusd.transfer.usdce", "polygon.send",
    # Inbound bridges (EVM-signed)
    "arbitrum.bridge.hypercore", "hyperevm.bridge.hypercore",
})
_HUMAN_ONLY = frozenset({"approve", "killswitch"})
_META = frozenset({"help"})

_TYPE_MAP = {
    "TEXT": "string",
    "STRING": "string",
    "INT": "integer",
    "INTEGER": "integer",
    "FLOAT": "number",
    "BOOL": "boolean",
    "BOOLEAN": "boolean",
    "UUID": "string",
    "PATH": "string",
    "CHOICE": "string",
}


def _command_class(name):
    if name in _MUTATING:
        return "mutating"
    if name in _HUMAN_ONLY:
        return "human-only"
    if name in _META:
        return "meta"
    return "agent-safe"


def generate_schema(typer_app):
    """Walk the Typer command tree and return agent-friendly structured schema."""
    from typer.main import get_command

    click_app = get_command(typer_app)
    all_entries = {}  # path -> (cmd, is_group)

    def _walk(cmd, path=""):
        if isinstance(cmd, click.Group):
            ctx = click.Context(cmd, info_name=path.split()[-1] if path else "regard")
            for name in sorted(cmd.list_commands(ctx)):
                subcmd = cmd.get_command(ctx, name)
                if subcmd:
                    _walk(subcmd, f"{path} {name}".strip())
        if path:
            all_entries[path] = (cmd, isinstance(cmd, click.Group))

    _walk(click_app)

    # Groups with children are structural — skip them.
    # Groups with no children are invoke_without_command — include as commands.
    group_paths = {p for p, (_, is_g) in all_entries.items() if is_g}
    has_children = {g for g in group_paths if any(
        p != g and p.startswith(g + " ") for p in all_entries
    )}

    commands = []
    for path, (cmd, is_group) in sorted(all_entries.items()):
        if is_group and path in has_children:
            continue

        dot_name = path.replace(" ", ".")
        params = {}
        for p in cmd.params:
            if p.name == "help":
                continue
            try:
                type_name = p.type.name
            except AttributeError:
                type_name = str(p.type)

            schema_type = _TYPE_MAP.get(type_name.upper(), "string")
            info = {"type": schema_type, "required": p.required}

            if isinstance(p, click.Option) and p.is_flag:
                info["type"] = "boolean"
            if hasattr(p.type, "choices") and p.type.choices:
                info["enum"] = list(p.type.choices)
            if not p.required and p.default is not None:
                info["default"] = str(p.default)
            if hasattr(p, "help") and p.help:
                info["description"] = p.help

            params[p.name] = info

        commands.append({
            "name": dot_name,
            "description": (cmd.help or "").strip(),
            "class": _command_class(dot_name),
            "params": params,
        })

    return {
        "version": pkg_version("regard-cli"),
        "total_commands": len(commands),
        "commands": commands,
    }


@app.command()
def schema(
    command: str | None = typer.Argument(None, help="Command in dot notation (e.g. hl.order)"),
):
    """Introspect the CLI command tree as structured JSON."""
    from regard.core.output import die, output

    data = generate_schema(app)

    if command:
        match = [c for c in data["commands"] if c["name"] == command]
        if not match:
            die("validation_error", "UNKNOWN_COMMAND",
                f"No command '{command}'. Run 'regard schema' to see all.",
                retryable=False)
        output(match[0])
    else:
        output(data)


# ---------------------------------------------------------------------------
# Wrapped entry point — last-resort catch for any exception that escapes
# all command-level handlers. Ensures stdout is always valid JSON.
# ---------------------------------------------------------------------------

def run():
    """Entry point with global exception safety net."""
    try:
        app()
    except SystemExit:
        raise
    except Exception as e:
        error = {
            "ok": False,
            "error": {
                "type": "internal_error",
                "code": type(e).__name__,
                "message": str(e),
                "retryable": False,
            },
            "meta": {"exit_code": 7},
        }
        print(json.dumps(error, separators=(",", ":")), flush=True)
        sys.exit(7)
