"""Behavioral tests for `regard hl outcomes` and `regard hl outcome <id>`.

The contract tests in test_contract.py verify the JSON envelope on every
command/error path. This module pins the field-level contract: numeric values
ARE strings (Constitution Article I), implied probability arithmetic uses
Decimal precision, and `<id>` argument parsing routes correctly.
"""

import json

from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# `regard hl outcomes` — list-view
# ---------------------------------------------------------------------------


class TestOutcomesList:
    def test_returns_envelope_with_outcomes_array(self, patched):
        result = runner.invoke(app, ["hypercore", "outcomes"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        assert isinstance(envelope["data"]["outcomes"], list)

    def test_seeded_outcome_present(self, patched):
        result = runner.invoke(app, ["hypercore", "outcomes"])
        envelope = json.loads(result.stdout)
        outcomes = envelope["data"]["outcomes"]
        assert len(outcomes) >= 1
        btc = outcomes[0]
        assert btc["outcome"] == 1
        assert btc["underlying"] == "BTC"
        assert btc["class"] == "priceBinary"
        assert btc["yes_coin"] == "#10"
        assert btc["no_coin"] == "#11"

    def test_target_price_is_string(self, patched):
        """Article I: financial values are strings, not JSON numbers."""
        result = runner.invoke(app, ["hypercore", "outcomes"])
        envelope = json.loads(result.stdout)
        btc = envelope["data"]["outcomes"][0]
        assert isinstance(btc["target_price"], str)
        assert btc["target_price"] == "78213"

    def test_has_display(self, patched):
        result = runner.invoke(app, ["hypercore", "outcomes"])
        envelope = json.loads(result.stdout)
        assert envelope["display"]


# ---------------------------------------------------------------------------
# `regard hl outcome <id>` — single market
# ---------------------------------------------------------------------------


class TestOutcomeSingle:
    def test_bare_integer_returns_both_sides(self, patched):
        result = runner.invoke(app, ["hypercore", "outcome", "1"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        data = envelope["data"]
        assert data["outcome"] == 1
        assert "yes" in data
        assert "no" in data

    def test_full_coin_form_returns_only_that_side(self, patched):
        # `#10` is YES — only that side should appear in the response.
        result = runner.invoke(app, ["hypercore", "outcome", "#10"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert "yes" in data
        assert "no" not in data
        assert data["yes"]["coin"] == "#10"

    def test_named_side_yes(self, patched):
        result = runner.invoke(app, ["hypercore", "outcome", "1:yes"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert "yes" in data
        assert "no" not in data

    def test_named_side_no(self, patched):
        result = runner.invoke(app, ["hypercore", "outcome", "1:no"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert "no" in data
        assert "yes" not in data

    def test_numeric_side_form(self, patched):
        result = runner.invoke(app, ["hypercore", "outcome", "1:1"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert "no" in data
        assert "yes" not in data

    def test_book_prices_are_strings(self, patched):
        """Article I: every numeric field in the book must be a JSON string."""
        result = runner.invoke(app, ["hypercore", "outcome", "1"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        for side in ("yes", "no"):
            book = data[side]
            assert isinstance(book["top_bid"], str)
            assert isinstance(book["top_ask"], str)
            assert isinstance(book["mid"], str)
            for level in book["bids"] + book["asks"]:
                assert isinstance(level["price"], str)
                assert isinstance(level["size"], str)

    def test_implied_total_uses_decimal_precision(self, patched):
        """The fixture has YES mid (0.45+0.46)/2=0.455 and NO mid (0.54+0.55)/2=0.545.
        Sum = exactly 1.000 — would also match if computed via float, but the
        Decimal path guarantees the string is faithful to the inputs."""
        result = runner.invoke(app, ["hypercore", "outcome", "1"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert isinstance(data["implied_total"], str)
        # Allow `1.000` / `1.00` / `1.0` — Decimal preserves trailing zeros.
        # The relevant assertion is the value rounds to 1.0.
        from decimal import Decimal
        assert Decimal(data["implied_total"]) == Decimal("1.000")

    def test_parsed_description_present(self, patched):
        result = runner.invoke(app, ["hypercore", "outcome", "1"])
        envelope = json.loads(result.stdout)
        parsed = envelope["data"]["parsed_description"]
        assert parsed["class"] == "priceBinary"
        assert parsed["underlying"] == "BTC"
        assert parsed["target_price"] == "78213"  # string
        assert parsed["expiry"] == "20260504-0600"
        assert parsed["period"] == "1d"

    def test_unknown_outcome_id_dies_with_structured_error(self, patched):
        result = runner.invoke(app, ["hypercore", "outcome", "99999"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "UNKNOWN_OUTCOME"
        assert envelope["error"]["type"] == "validation_error"

    def test_invalid_id_dies_with_structured_error(self, patched):
        result = runner.invoke(app, ["hypercore", "outcome", "1:bogus"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "INVALID_OUTCOME_ID"

    def test_side_out_of_range_dies_with_structured_error(self, patched):
        """Regression (peer-review SIDE-OOB): `#12` decodes to outcome=1,
        side=2. Pre-fix, the command silently emitted `{ok: true,
        implied_total: null}` with no yes/no keys — agent couldn't
        distinguish from a thin market. Now rejected at parse time."""
        result = runner.invoke(app, ["hypercore", "outcome", "#12"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "INVALID_OUTCOME_ID"
        assert envelope["error"]["type"] == "validation_error"
        assert "side 2" in envelope["error"]["message"]

    def test_unicode_digit_in_coin_id_returns_validation_error(self, patched):
        """Regression (peer-review UNICODE-VAL): pre-fix, `'²'.isdigit()`
        was True, `int('²')` raised ValueError, caller's `is None` check
        missed it, exited with internal_error / exit 7. Now rejected at
        parse time as validation_error / exit 2 per Article IV."""
        result = runner.invoke(app, ["hypercore", "outcome", "#²"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["type"] == "validation_error"
        assert envelope["error"]["code"] == "INVALID_OUTCOME_ID"
        # Critical: exit code is 2 (validation), not 7 (internal_error)
        assert result.exit_code == 2

    def test_leading_zero_coin_rejected(self, patched):
        """Regression (peer-review LEAD-ZERO): pre-fix, `#010` silently
        aliased `#10`. Now decode_coin returns None and the parser
        surfaces INVALID_OUTCOME_ID."""
        result = runner.invoke(app, ["hypercore", "outcome", "#010"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "INVALID_OUTCOME_ID"

    def test_has_display(self, patched):
        result = runner.invoke(app, ["hypercore", "outcome", "1"])
        envelope = json.loads(result.stdout)
        assert envelope["display"]


class TestOutcomeParity:
    """`--parity` flag invokes Polymarket equivalent lookup. v0.23.2.

    The conftest `patched` fixture seeds outcome 1 = BTC binary expiring
    `20260504-0600`. We mock the gamma httpx client so the test runs
    offline.
    """

    def test_parity_returns_match_when_polymarket_has_one(self, patched):
        """`--parity` adds a populated `parity` block when a defensible
        match exists."""
        from unittest.mock import MagicMock
        from unittest.mock import patch as _patch

        pm_market = {
            "id": "12345",
            "conditionId": "0xabc",
            "slug": "bitcoin-above-78213-may-4",
            "question": "Will Bitcoin be above $78,213 on May 4?",
            "outcomePrices": '["0.51", "0.49"]',
            "endDateIso": "2026-05-04T06:00:00Z",
            "active": True,
            "closed": False,
        }
        resp = MagicMock()
        resp.json.return_value = [pm_market]
        gamma = MagicMock()
        gamma.get.return_value = resp

        with _patch(
            "regard.venues.polymarket.client.get_gamma_client",
            return_value=gamma,
        ):
            result = runner.invoke(app, ["hypercore", "outcome", "1", "--parity"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        parity = envelope["data"]["parity"]
        assert parity is not None
        assert parity["market_id"] == "12345"
        assert parity["yes_price"] == "0.51"
        assert parity["match_quality"] in ("exact", "themed")
        # Spread is computed from HL yes mid vs Polymarket yes price.
        assert "spread_yes" in parity
        assert "spread_no" in parity

    def test_parity_returns_null_when_no_match(self, patched):
        """No matching market → `parity: null`. Caller distinguishes from
        `parity` field absent (flag was off)."""
        from unittest.mock import MagicMock
        from unittest.mock import patch as _patch

        # Only an unrelated market in the response.
        unrelated = {
            "id": "999",
            "slug": "election-2028",
            "question": "Will candidate X win in 2028?",
            "outcomePrices": '["0.50","0.50"]',
            "endDateIso": "2026-05-04T06:00:00Z",
        }
        resp = MagicMock()
        resp.json.return_value = [unrelated]
        gamma = MagicMock()
        gamma.get.return_value = resp

        with _patch(
            "regard.venues.polymarket.client.get_gamma_client",
            return_value=gamma,
        ):
            result = runner.invoke(app, ["hypercore", "outcome", "1", "--parity"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        assert envelope["data"]["parity"] is None

    def test_parity_omitted_when_flag_off(self, patched):
        """Without `--parity`, no `parity` key in the response (no extra
        network call paid)."""
        result = runner.invoke(app, ["hypercore", "outcome", "1"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        assert "parity" not in envelope["data"]

    def test_parity_degrades_to_null_on_gamma_failure(self, patched):
        """Polymarket network failure → parity: null, NEVER raise. Caller
        treats it as 'no match found'."""
        from unittest.mock import MagicMock
        from unittest.mock import patch as _patch

        gamma = MagicMock()
        gamma.get.side_effect = Exception("network down")
        with _patch(
            "regard.venues.polymarket.client.get_gamma_client",
            return_value=gamma,
        ):
            result = runner.invoke(app, ["hypercore", "outcome", "1", "--parity"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        assert envelope["data"]["parity"] is None


# ---------------------------------------------------------------------------
# `regard hypercore questions` and `regard hypercore question <id>` —
# HIP-4 multi-outcome surface (HL shipped 2026-05-07).
# ---------------------------------------------------------------------------


# Mainnet capture — BTC daily price-range question with 3 named outcomes
# (bucket-position-bound) + 1 fallback. The question owns the priceBucket spec;
# named outcomes carry only `index:N`; fallback carries `description: "other"`.
OUTCOME_META_WITH_QUESTION = {
    "outcomes": [
        # Standalone binary outcome — coexists with the question's outcomes
        {
            "outcome": 5,
            "name": "Recurring",
            "description": "class:priceBinary|underlying:BTC|expiry:20260508-0600|targetPrice:81041|period:1d",
            "sideSpecs": [{"name": "Yes"}, {"name": "No"}],
        },
        # Question 0 fallback outcome
        {
            "outcome": 6,
            "name": "Recurring Fallback",
            "description": "other",
            "sideSpecs": [{"name": "Yes"}, {"name": "No"}],
        },
        # Question 0 named outcomes — bucket positions 0, 1, 2
        {
            "outcome": 7,
            "name": "Recurring Named Outcome",
            "description": "index:0",
            "sideSpecs": [{"name": "Yes"}, {"name": "No"}],
        },
        {
            "outcome": 8,
            "name": "Recurring Named Outcome",
            "description": "index:1",
            "sideSpecs": [{"name": "Yes"}, {"name": "No"}],
        },
        {
            "outcome": 9,
            "name": "Recurring Named Outcome",
            "description": "index:2",
            "sideSpecs": [{"name": "Yes"}, {"name": "No"}],
        },
    ],
    "questions": [
        {
            "question": 0,
            "name": "Recurring",
            "description": "class:priceBucket|underlying:BTC|expiry:20260508-0600|priceThresholds:79303,82540|period:1d",
            "fallbackOutcome": 6,
            "namedOutcomes": [7, 8, 9],
            "settledNamedOutcomes": [],
        }
    ],
}


def _override_outcome_meta(mock_info, override_meta):
    """Swap the conftest mock_info's outcomeMeta response for a test-specific one."""
    original = mock_info.post.side_effect

    def _post(endpoint, payload):
        if payload.get("type") == "outcomeMeta":
            return dict(override_meta)
        return original(endpoint, payload)

    mock_info.post.side_effect = _post


class TestQuestionsList:
    def test_returns_envelope_with_questions_array(self, patched):
        # Default fixture has questions: [] — list returns empty array, not error.
        result = runner.invoke(app, ["hypercore", "questions"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        assert isinstance(envelope["data"]["questions"], list)
        assert envelope["data"]["questions"] == []

    def test_with_question_fixture_lists_one_question(self, patched):
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        result = runner.invoke(app, ["hypercore", "questions"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        questions = envelope["data"]["questions"]
        assert len(questions) == 1
        q = questions[0]
        assert q["question"] == 0
        assert q["class"] == "priceBucket"
        assert q["underlying"] == "BTC"
        assert q["expiry"] == "20260508-0600"
        assert q["thresholds"] == ["79303", "82540"]
        assert q["named_outcomes"] == [7, 8, 9]
        assert q["fallback_outcome"] == 6


class TestQuestionDetail:
    def test_unknown_question_dies_with_unknown_question(self, patched):
        result = runner.invoke(app, ["hypercore", "question", "999"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "UNKNOWN_QUESTION"

    def test_returns_full_question_with_outcomes_in_bucket_order(self, patched):
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        result = runner.invoke(app, ["hypercore", "question", "0"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        data = envelope["data"]
        assert data["question"] == 0
        assert data["fallback_outcome"] == 6
        assert data["named_outcomes"] == [7, 8, 9]
        # Outcomes list: named first (bucket-ordered), fallback last
        outcome_ids = [o["outcome"] for o in data["outcomes"]]
        assert outcome_ids == [7, 8, 9, 6]
        assert data["outcomes"][0]["bucket_label"] == "<79303"
        assert data["outcomes"][1]["bucket_label"] == "[79303, 82540)"
        assert data["outcomes"][2]["bucket_label"] == "≥82540"
        assert data["outcomes"][3]["bucket_label"] == "fallback"
        assert data["outcomes"][3]["is_fallback"] is True

    def test_priceBucket_spec_in_parsed_description(self, patched):
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        result = runner.invoke(app, ["hypercore", "question", "0"])
        envelope = json.loads(result.stdout)
        parsed = envelope["data"]["parsed_description"]
        assert parsed["class"] == "priceBucket"
        assert parsed["underlying"] == "BTC"
        assert parsed["price_thresholds"] == ["79303", "82540"]

    def test_settled_named_outcomes_present(self, patched):
        """settled_named_outcomes is populated post-settlement; pre-settlement empty."""
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        result = runner.invoke(app, ["hypercore", "question", "0"])
        envelope = json.loads(result.stdout)
        assert envelope["data"]["settled_named_outcomes"] == []

    def test_implied_total_aggregates_named_yes_mids_only(self, patched):
        """Sum-to-1 check uses NAMED outcome YES mids; fallback excluded.
        With ALL named outcomes priced, implied_total is the sum + note is null."""
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        # Mock l2_snapshot to return a deterministic mid for each named outcome.
        # Outcomes 7/8/9 yes coins are #70/#80/#90; with mid 0.3/0.4/0.3 each
        # the named-only sum is 1.0 (efficient market). Fallback also gets a
        # mid, but it's excluded from the sum.
        def _l2_snapshot(coin):
            mids = {"#70": "0.3", "#80": "0.4", "#90": "0.3", "#60": "0.0", "#61": "0.0"}
            mid = mids.get(coin, "0.5")
            return {
                "coin": coin,
                "time": 1000000000000,
                "levels": [
                    [{"px": mid, "sz": "10", "n": 1}],  # bids
                    [{"px": mid, "sz": "10", "n": 1}],  # asks
                ],
            }
        patched["info"].l2_snapshot.side_effect = _l2_snapshot
        result = runner.invoke(app, ["hypercore", "question", "0"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        # Sum = 0.3 + 0.4 + 0.3 = 1.0 (named yes mids only)
        from decimal import Decimal
        assert Decimal(envelope["data"]["implied_total"]) == Decimal("1.0")
        # Note is None when all named outcomes have open books (no gap to surface)
        assert envelope["data"]["implied_total_note"] is None

    def test_implied_total_null_with_partial_books_note(self, patched):
        """Peer-review fix (codex blind-debate, 2026-05-07): if ANY named
        outcome lacks an open book, return implied_total=None plus a
        structured note explaining the gap. A partial sum looks like a
        pricing inefficiency; it's actually missing data. Per CLAUDE.md
        fintech-accuracy doctrine: 'honest gap > misleading zero'."""
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        # Outcomes 7 and 9 have books; outcome 8 has empty levels (no mid).
        def _l2_snapshot(coin):
            if coin in ("#80", "#81"):  # outcome 8's both sides — no levels
                return {"coin": coin, "time": 1000000000000, "levels": [[], []]}
            mids = {"#70": "0.3", "#90": "0.3"}
            mid = mids.get(coin, "0.5")
            return {
                "coin": coin,
                "time": 1000000000000,
                "levels": [
                    [{"px": mid, "sz": "10", "n": 1}],
                    [{"px": mid, "sz": "10", "n": 1}],
                ],
            }
        patched["info"].l2_snapshot.side_effect = _l2_snapshot
        result = runner.invoke(app, ["hypercore", "question", "0"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        # Critical: implied_total is None (NOT a partial sum like "0.6")
        assert envelope["data"]["implied_total"] is None
        # Note explains the gap: 2 of 3 named outcomes have open books
        note = envelope["data"]["implied_total_note"]
        assert note is not None
        assert "partial" in note.lower()
        assert "2/3" in note  # 2 of 3 named outcomes have books

    def test_implied_total_null_with_all_books_empty_note(self, patched):
        """All named outcomes have empty books → implied_total=None + note."""
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        def _l2_snapshot(coin):
            return {"coin": coin, "time": 1000000000000, "levels": [[], []]}
        patched["info"].l2_snapshot.side_effect = _l2_snapshot
        result = runner.invoke(app, ["hypercore", "question", "0"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        assert envelope["data"]["implied_total"] is None
        assert envelope["data"]["implied_total_note"] is not None
        assert "0/3" in envelope["data"]["implied_total_note"]

    def test_has_display(self, patched):
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        result = runner.invoke(app, ["hypercore", "question", "0"])
        envelope = json.loads(result.stdout)
        assert envelope["display"]


class TestOutcomesListWithQuestions:
    """`regard hl outcomes` lists question-bound outcomes alongside binary."""

    def test_question_bound_outcomes_show_bucket_label(self, patched):
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        result = runner.invoke(app, ["hypercore", "outcomes"])
        envelope = json.loads(result.stdout)
        outcomes = envelope["data"]["outcomes"]
        # Find outcome 7 (bucket 0)
        rec7 = next(o for o in outcomes if o["outcome"] == 7)
        assert rec7["question_id"] == 0
        assert rec7["bucket_label"] == "<79303"
        assert rec7["is_fallback"] is False
        # Outcome 6 (fallback)
        rec6 = next(o for o in outcomes if o["outcome"] == 6)
        assert rec6["question_id"] == 0
        assert rec6["bucket_label"] == "fallback"
        assert rec6["is_fallback"] is True

    def test_question_bound_outcomes_inherit_underlying_from_question(self, patched):
        """Outcomes 6-9 carry only `index:N` / `other` — underlying must be
        inherited from the parent question's priceBucket spec."""
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        result = runner.invoke(app, ["hypercore", "outcomes"])
        envelope = json.loads(result.stdout)
        outcomes = envelope["data"]["outcomes"]
        rec7 = next(o for o in outcomes if o["outcome"] == 7)
        assert rec7["underlying"] == "BTC"
        assert rec7["expiry"] == "20260508-0600"
        assert rec7["period"] == "1d"
        # target_price is binary-only — null for question-bound named outcomes
        assert rec7["target_price"] is None

    def test_standalone_binary_outcome_unchanged(self, patched):
        """Outcome 5 (standalone binary) keeps its priceBinary spec untouched."""
        _override_outcome_meta(patched["info"], OUTCOME_META_WITH_QUESTION)
        result = runner.invoke(app, ["hypercore", "outcomes"])
        envelope = json.loads(result.stdout)
        outcomes = envelope["data"]["outcomes"]
        rec5 = next(o for o in outcomes if o["outcome"] == 5)
        assert rec5["question_id"] is None
        assert rec5["bucket_label"] is None
        assert rec5["class"] == "priceBinary"
        assert rec5["target_price"] == "81041"
