"""Tests for venues/hyperliquid/outcomes.py — HIP-4 encoding and parsing.

Pure-logic module, no mocks. Round-trip tests anchor the contract; rejection
tests pin the boundary so the resolver can use `decode_coin` as a safe
discriminator against any coin string (perps, spot, outcomes).
"""

from decimal import Decimal

import pytest

from regard.venues.hyperliquid.outcomes import (
    ASSET_ID_BASE,
    SIDE_NO,
    SIDE_YES,
    OutcomeValidationError,
    decode_balance_coin,
    decode_coin,
    encode_asset_id,
    encode_balance_coin,
    encode_coin,
    parse_description,
    validate_outcome_order,
)

# ---------------------------------------------------------------------------
# encode_coin — `#<encoding>` form for l2Book / Exchange.order
# ---------------------------------------------------------------------------


class TestEncodeCoin:
    def test_outcome_zero_yes(self):
        # Edge: outcome=0 produces "#0" / "#1" — valid encodings.
        assert encode_coin(0, SIDE_YES) == "#0"

    def test_outcome_zero_no(self):
        assert encode_coin(0, SIDE_NO) == "#1"

    def test_brief_example_yes(self):
        # Brief §3 #10/#11 UX gotcha: outcome=1 yields sequential-looking
        # coin strings that are actually two sides of the same market.
        assert encode_coin(1, SIDE_YES) == "#10"

    def test_brief_example_no(self):
        assert encode_coin(1, SIDE_NO) == "#11"

    def test_btc_daily_yes(self):
        # Brief §3 worked example: outcome=5915 → #59150 / #59151
        assert encode_coin(5915, SIDE_YES) == "#59150"

    def test_btc_daily_no(self):
        assert encode_coin(5915, SIDE_NO) == "#59151"

    def test_rejects_invalid_side(self):
        with pytest.raises(ValueError, match="side must be 0"):
            encode_coin(5915, 2)

    def test_rejects_negative_side(self):
        with pytest.raises(ValueError, match="side must be 0"):
            encode_coin(5915, -1)

    def test_rejects_negative_outcome(self):
        with pytest.raises(ValueError, match="non-negative integer"):
            encode_coin(-1, SIDE_YES)

    def test_rejects_float_outcome(self):
        with pytest.raises(ValueError, match="non-negative integer"):
            encode_coin(1.5, SIDE_YES)  # type: ignore[arg-type]

    def test_rejects_bool_outcome(self):
        # True/False are int subclasses; reject them explicitly so a typo
        # like encode_coin(True, 0) doesn't silently produce "#1".
        with pytest.raises(ValueError, match="non-negative integer"):
            encode_coin(True, SIDE_YES)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# encode_balance_coin — `+<encoding>` form for spotClearinghouseState
# ---------------------------------------------------------------------------


class TestEncodeBalanceCoin:
    def test_brief_example_yes(self):
        assert encode_balance_coin(1, SIDE_YES) == "+10"

    def test_brief_example_no(self):
        assert encode_balance_coin(1, SIDE_NO) == "+11"

    def test_btc_daily_yes(self):
        assert encode_balance_coin(5915, SIDE_YES) == "+59150"

    def test_rejects_invalid_side(self):
        with pytest.raises(ValueError, match="side must be 0"):
            encode_balance_coin(1, 7)


# ---------------------------------------------------------------------------
# encode_asset_id — `100_000_000 + encoding` integer form
# ---------------------------------------------------------------------------


class TestEncodeAssetId:
    def test_base_constant(self):
        assert ASSET_ID_BASE == 100_000_000

    def test_outcome_zero_yes(self):
        assert encode_asset_id(0, SIDE_YES) == 100_000_000

    def test_btc_daily_yes(self):
        # Brief §3: outcome=5915, YES → 100_059_150
        assert encode_asset_id(5915, SIDE_YES) == 100_059_150

    def test_btc_daily_no(self):
        assert encode_asset_id(5915, SIDE_NO) == 100_059_151

    def test_rejects_invalid_side(self):
        with pytest.raises(ValueError):
            encode_asset_id(5915, 2)


# ---------------------------------------------------------------------------
# decode_coin — `#<encoding>` → (outcome, side); None for non-matching strings.
# Safety contract: resolver uses this as a discriminator against any coin.
# ---------------------------------------------------------------------------


class TestDecodeCoin:
    def test_outcome_zero_yes(self):
        assert decode_coin("#0") == (0, 0)

    def test_outcome_zero_no(self):
        assert decode_coin("#1") == (0, 1)

    def test_brief_example(self):
        assert decode_coin("#10") == (1, 0)
        assert decode_coin("#11") == (1, 1)

    def test_btc_daily_both_sides(self):
        assert decode_coin("#59150") == (5915, 0)
        assert decode_coin("#59151") == (5915, 1)

    def test_round_trip(self):
        for outcome in (0, 1, 7, 100, 5915, 999_999):
            for side in (SIDE_YES, SIDE_NO):
                assert decode_coin(encode_coin(outcome, side)) == (outcome, side)

    def test_returns_none_for_perp(self):
        assert decode_coin("BTC") is None

    def test_returns_none_for_hip3(self):
        assert decode_coin("xyz:TSLA") is None

    def test_returns_none_for_spot_pair(self):
        # `@1338` (the USDC↔USDH spot pair) is not an outcome coin.
        assert decode_coin("@1338") is None

    def test_returns_none_for_balance_form(self):
        # `+59150` is the BALANCE form, not the trade form. decode_coin
        # only handles `#`. The resolver uses decode_balance_coin for `+`.
        assert decode_coin("+59150") is None

    def test_returns_none_for_empty_body(self):
        assert decode_coin("#") is None

    def test_returns_none_for_non_digit_body(self):
        assert decode_coin("#abc") is None
        assert decode_coin("#1.5") is None
        assert decode_coin("#-5") is None
        assert decode_coin("#10 ") is None  # trailing whitespace not stripped

    def test_returns_none_for_unicode_digit(self):
        # Regression (peer-review UNICODE-VAL): `'²'.isdigit()` is True
        # in Python (Unicode digit category), but `int('²')` raises
        # ValueError. Pre-fix, decode_coin('#²') propagated the ValueError
        # past the caller's `if decoded is None` guard, exiting with
        # internal_error / exit 7 instead of validation_error / exit 2.
        # Article IV exit-code consistency: validation errors must exit 2.
        assert decode_coin("#²") is None
        assert decode_coin("#½") is None
        # Arabic-Indic digits: Unicode-digit but not ASCII
        assert decode_coin("#١٠") is None

    def test_returns_none_for_leading_zero(self):
        # Regression (peer-review LEAD-ZERO): pre-fix, `decode_coin('#010')`
        # returned (1, 0) — the same as `#10`. The CLI hint already
        # documents "no leading zeros allowed" so the encoder/decoder
        # contract must enforce it; aliasing creates ID-confusion in
        # logs and audit trails.
        assert decode_coin("#010") is None
        assert decode_coin("#01") is None
        assert decode_coin("#0010") is None
        # Single zero is still valid (outcome=0, side=0).
        assert decode_coin("#0") == (0, 0)

    def test_returns_none_for_empty_string(self):
        assert decode_coin("") is None

    def test_returns_none_for_non_string(self):
        assert decode_coin(None) is None  # type: ignore[arg-type]
        assert decode_coin(59150) is None  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# decode_balance_coin — same contract for `+<encoding>`
# ---------------------------------------------------------------------------


class TestDecodeBalanceCoin:
    def test_round_trip(self):
        for outcome in (0, 1, 5915, 999_999):
            for side in (SIDE_YES, SIDE_NO):
                assert decode_balance_coin(encode_balance_coin(outcome, side)) == (outcome, side)

    def test_returns_none_for_trade_form(self):
        # Mirror discrimination — `#59150` is the TRADE form, not balance.
        assert decode_balance_coin("#59150") is None

    def test_returns_none_for_non_outcome(self):
        assert decode_balance_coin("USDC") is None
        assert decode_balance_coin("HYPE") is None
        assert decode_balance_coin("") is None
        assert decode_balance_coin("+") is None
        assert decode_balance_coin("+abc") is None

    def test_returns_none_for_unicode_digit(self):
        # Same UNICODE-VAL regression as decode_coin — symmetric contract.
        assert decode_balance_coin("+²") is None
        assert decode_balance_coin("+١٠") is None

    def test_returns_none_for_leading_zero(self):
        # Same LEAD-ZERO regression as decode_coin.
        assert decode_balance_coin("+010") is None
        assert decode_balance_coin("+0") == (0, 0)  # single zero remains valid


# ---------------------------------------------------------------------------
# parse_description — pipe-separated description from outcomeMeta
# ---------------------------------------------------------------------------


class TestParseDescription:
    def test_real_btc_daily_binary(self):
        # From the captured mainnet golden fixture.
        desc = "class:priceBinary|underlying:BTC|expiry:20260504-0600|targetPrice:78213|period:1d"
        parsed = parse_description(desc)
        assert parsed["class"] == "priceBinary"
        assert parsed["underlying"] == "BTC"
        assert parsed["expiry"] == "20260504-0600"
        assert parsed["target_price"] == "78213"  # kept as string per Article I
        assert parsed["period"] == "1d"

    def test_target_price_with_decimal_kept_as_string(self):
        # Article I: financial values MUST be strings end-to-end.
        # IEEE 754 float would lose precision past 15 sig digits.
        desc = "class:priceBinary|underlying:HYPE|expiry:20260310-1100|targetPrice:34.5|period:3m"
        parsed = parse_description(desc)
        assert parsed["target_price"] == "34.5"
        assert isinstance(parsed["target_price"], str)

    def test_missing_keys_become_none(self):
        # Malformed description with only some keys → others are None.
        desc = "class:priceBinary|underlying:BTC"
        parsed = parse_description(desc)
        assert parsed["class"] == "priceBinary"
        assert parsed["underlying"] == "BTC"
        assert parsed["expiry"] is None
        assert parsed["target_price"] is None
        assert parsed["period"] is None

    def test_unknown_keys_ignored(self):
        # Future protocol additions (new keys) MUST not raise — they're
        # silently dropped per Article IV (production extra="ignore" semantics).
        desc = "class:priceBinary|newField:newValue|underlying:BTC"
        parsed = parse_description(desc)
        assert parsed["class"] == "priceBinary"
        assert parsed["underlying"] == "BTC"
        # newField doesn't appear anywhere
        assert "newField" not in parsed

    # Per-shape default expectations — the keys whose default values differ
    # from None (added 2026-05-07 for question support):
    #   index: None        — bucket position for question-bound named outcomes
    #   is_fallback: False — true only for question-bound fallback outcomes
    # All other keys default to None, so the "no match" tests check those.
    _SPEC_KEYS = ("class", "underlying", "expiry", "target_price", "period",
                  "price_thresholds")

    def test_empty_string(self):
        parsed = parse_description("")
        assert all(parsed[k] is None for k in self._SPEC_KEYS)
        assert parsed["index"] is None
        assert parsed["is_fallback"] is False

    def test_malformed_no_colons(self):
        parsed = parse_description("classpriceBinary|underlyingBTC")
        assert all(parsed[k] is None for k in self._SPEC_KEYS)
        assert parsed["index"] is None
        assert parsed["is_fallback"] is False

    def test_whitespace_tolerant(self):
        # A future API response might have whitespace; don't be brittle.
        desc = "class: priceBinary | underlying: BTC | period: 1d"
        parsed = parse_description(desc)
        assert parsed["class"] == "priceBinary"
        assert parsed["underlying"] == "BTC"
        assert parsed["period"] == "1d"

    def test_value_with_internal_colon(self):
        # `expiry: 20260504-0600` has no colons but a future format like
        # `expiry:2026-05-04T06:00:00Z` would have them. partition(":", 1)
        # equivalent must keep the rest of the value intact.
        desc = "expiry:2026-05-04T06:00:00Z"
        parsed = parse_description(desc)
        assert parsed["expiry"] == "2026-05-04T06:00:00Z"

    def test_non_string_input(self):
        parsed = parse_description(None)  # type: ignore[arg-type]
        assert all(parsed[k] is None for k in self._SPEC_KEYS)
        assert parsed["index"] is None
        assert parsed["is_fallback"] is False

    # --- Question-bound description shapes (HIP-4 multi-outcome, 2026-05-07) ---

    def test_question_fallback_outcome(self):
        """Fallback outcome description is the literal string `other`."""
        parsed = parse_description("other")
        assert parsed["is_fallback"] is True
        assert parsed["index"] is None
        # No spec on the outcome — spec lives on the parent question.
        assert all(parsed[k] is None for k in self._SPEC_KEYS)

    def test_question_named_outcome_index_zero(self):
        """Named outcome description is `index:N` (0-based bucket position)."""
        parsed = parse_description("index:0")
        assert parsed["index"] == 0
        assert parsed["is_fallback"] is False
        assert all(parsed[k] is None for k in self._SPEC_KEYS)

    def test_question_named_outcome_index_two(self):
        parsed = parse_description("index:2")
        assert parsed["index"] == 2
        assert parsed["is_fallback"] is False

    def test_question_priceBucket_spec(self):
        """priceBucket lives on the question, not on outcomes — same parser."""
        desc = "class:priceBucket|underlying:BTC|expiry:20260508-0600|priceThresholds:79303,82540|period:1d"
        parsed = parse_description(desc)
        assert parsed["class"] == "priceBucket"
        assert parsed["underlying"] == "BTC"
        assert parsed["expiry"] == "20260508-0600"
        assert parsed["price_thresholds"] == ["79303", "82540"]
        assert parsed["period"] == "1d"
        assert parsed["index"] is None
        assert parsed["is_fallback"] is False

    def test_question_priceBucket_three_thresholds(self):
        """priceThresholds:P1,P2,P3 partitions into 4 buckets (forward-compat)."""
        desc = "class:priceBucket|underlying:ETH|expiry:20260508-0600|priceThresholds:3000,3500,4000|period:1d"
        parsed = parse_description(desc)
        assert parsed["price_thresholds"] == ["3000", "3500", "4000"]

    def test_question_priceBucket_malformed_index(self):
        """Index that isn't an integer leaves the field None — defensive."""
        parsed = parse_description("index:not-a-number")
        assert parsed["index"] is None
        assert parsed["is_fallback"] is False


class TestBucketLabel:
    """`bucket_label` renders the human bucket-position label for a
    question-bound named outcome given (index, price_thresholds)."""

    def test_three_buckets_first(self):
        from regard.venues.hyperliquid.outcomes import bucket_label
        # priceThresholds: [P1, P2] partitions into 3 buckets: <P1, [P1,P2), ≥P2
        assert bucket_label(0, ["79303", "82540"]) == "<79303"

    def test_three_buckets_middle(self):
        from regard.venues.hyperliquid.outcomes import bucket_label
        assert bucket_label(1, ["79303", "82540"]) == "[79303, 82540)"

    def test_three_buckets_last(self):
        from regard.venues.hyperliquid.outcomes import bucket_label
        assert bucket_label(2, ["79303", "82540"]) == "≥82540"

    def test_four_buckets_all_positions(self):
        # priceThresholds: [P1, P2, P3] partitions into 4 buckets — generalizes.
        from regard.venues.hyperliquid.outcomes import bucket_label
        thresholds = ["3000", "3500", "4000"]
        assert bucket_label(0, thresholds) == "<3000"
        assert bucket_label(1, thresholds) == "[3000, 3500)"
        assert bucket_label(2, thresholds) == "[3500, 4000)"
        assert bucket_label(3, thresholds) == "≥4000"

    def test_empty_thresholds_fallback(self):
        # Defensive — malformed question with no thresholds → fallback label.
        from regard.venues.hyperliquid.outcomes import bucket_label
        assert bucket_label(0, []) == "index 0"
        assert bucket_label(2, []) == "index 2"

    def test_index_out_of_range_fallback(self):
        from regard.venues.hyperliquid.outcomes import bucket_label
        # Index beyond the partition (shouldn't happen on the wire, but defensive).
        assert bucket_label(99, ["79303", "82540"]) == "index 99"


# ---------------------------------------------------------------------------
# validate_outcome_order — client-side enforcement of brief §6 constraints
#
# Article II: every rule MUST reject (raise), never silently truncate.
# These tests are the named per-rule mapping required by Constitutional
# alignment §IV "Article II rule → test mapping" — they pin the contract
# the act.py:order() handler relies on.
# ---------------------------------------------------------------------------


class TestValidateOutcomeOrderSize:
    def test_valid_integer_size_no_price_passes(self):
        # Market order: only size validated.
        validate_outcome_order("27")  # no raise

    def test_valid_integer_size_with_valid_price_passes(self):
        validate_outcome_order("27", "0.5")  # 27 × 0.5 = 13.5 USDH ≥ 10

    def test_rejects_non_integer_size(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("1.5", "0.5")
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_rejects_zero_size(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("0", "0.5")
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_rejects_negative_size(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("-5", "0.5")
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_rejects_nan_size(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("NaN", "0.5")
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_rejects_infinity_size(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("Infinity", "0.5")
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_rejects_non_numeric_size(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("abc", "0.5")
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_rejects_bool_size(self):
        # bool is int subclass; reject explicitly so a typo like
        # validate_outcome_order(True, "0.5") doesn't silently parse as size=1.
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order(True, "0.5")  # type: ignore[arg-type]
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_rejects_scientific_notation_size(self):
        """Regression (peer-review): pre-fix `Decimal("1e500")` is finite,
        integer, and positive — slipped past size guards. Without an
        upper bound the client emitted a "valid" proposal that the server
        rejects as insufficient balance — agent gets a misleading
        "pending" instead of a structured validation error.

        Article II: silent acceptance of operationally-impossible values
        is a correctness violation. Fix: cap at OUTCOME_MAX_SIZE (1e15).
        """
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("1e500", "0.5")
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_rejects_huge_integer_size(self):
        """Plain integer above the cap — same regression class as scientific
        notation but typed differently. Both must reject."""
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("1" + "0" * 16, "0.5")  # 1e16
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_accepts_max_size_at_boundary(self):
        """1e15 itself is the inclusive upper bound."""
        # 1e15 × 0.5 = 5e14 USDH ≥ 10 — passes notional
        validate_outcome_order("1000000000000000", "0.5")  # 1e15


class TestValidateOutcomeOrderPriceRange:
    def test_price_at_min_passes(self):
        # 0.001 is the inclusive lower bound (notional 27×0.001=0.027 < 10
        # so this would fail OUTCOME_MIN_NOTIONAL — use larger size).
        validate_outcome_order("10000", "0.001")  # notional 10.0 == min

    def test_price_at_max_passes(self):
        validate_outcome_order("11", "0.999")  # notional 10.989 ≥ 10

    def test_rejects_price_below_min(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "0.0009")
        assert exc.value.code == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_rejects_price_above_max(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "0.9991")
        assert exc.value.code == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_rejects_negative_price(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "-0.5")
        assert exc.value.code == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_rejects_zero_price(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "0")
        assert exc.value.code == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_rejects_nan_price(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "NaN")
        assert exc.value.code == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_rejects_infinity_price(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "Infinity")
        assert exc.value.code == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_rejects_non_numeric_price(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "abc")
        assert exc.value.code == "OUTCOME_PRICE_OUT_OF_RANGE"


class TestValidateOutcomeOrderTick:
    def test_aligned_price_passes(self):
        # Use sizes that satisfy min notional at each price.
        validate_outcome_order("100", "0.4561")     # 45.61 USDH ≥ 10
        validate_outcome_order("100", "0.5000")     # 50 USDH
        validate_outcome_order("11", "0.999")       # 10.989 USDH
        # 0.001 needs a much bigger size to clear $10 notional —
        # 10000 × 0.001 = 10.
        validate_outcome_order("10000", "0.001")

    def test_rejects_sub_tick_price(self):
        # 0.50005 is half a tick — server would reject as "must be a multiple"
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "0.50005")
        assert exc.value.code == "OUTCOME_TICK_VIOLATION"

    def test_rejects_sub_tick_at_low_end(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "0.00115")  # 0.001 + 0.00015
        assert exc.value.code == "OUTCOME_TICK_VIOLATION"

    def test_custom_tick_overrides_default(self):
        # Future markets may have larger ticks (0.005, 0.01, etc.).
        # 0.025 is a multiple of 0.005 but NOT of 0.0001? Actually 0.025
        # is a multiple of 0.0001 too (250×0.0001). Pick a price that's
        # a multiple of 0.0001 but NOT of 0.005 to test custom-tick logic.
        validate_outcome_order("400", "0.025", tick=Decimal("0.005"))  # passes — 5 ticks
        with pytest.raises(OutcomeValidationError):
            validate_outcome_order("400", "0.0251", tick=Decimal("0.005"))


class TestValidateOutcomeOrderMinNotional:
    def test_at_min_notional_passes(self):
        # Exactly $10 USDH is OK (>= boundary).
        validate_outcome_order("20", "0.5")  # 10.0 USDH

    def test_rejects_below_min_notional(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("27", "0.001")  # 0.027 USDH
        assert exc.value.code == "OUTCOME_MIN_NOTIONAL"

    def test_rejects_just_below_min_notional(self):
        # 19 × 0.5 = 9.5 < 10 — typical buy-the-min-shares trap.
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("19", "0.5")
        assert exc.value.code == "OUTCOME_MIN_NOTIONAL"

    def test_min_notional_hint_suggests_recovery_size(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("19", "0.5")
        # Hint should suggest size ≥ 20 at price 0.5.
        assert "20" in (exc.value.hint or "")

    def test_custom_min_notional(self):
        # Custom $1 floor — useful for testnet experiments.
        validate_outcome_order("2", "0.5", min_notional=Decimal("1"))
        with pytest.raises(OutcomeValidationError):
            validate_outcome_order("1", "0.5", min_notional=Decimal("1"))  # 0.5 < 1


class TestValidateOutcomeOrderMarketMode:
    def test_market_order_skips_price_validation(self):
        # Market order signaled by price=None — only size is checked.
        validate_outcome_order("27")

    def test_market_order_still_rejects_bad_size(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("1.5")
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"


class TestValidateOutcomeOrderCheckOrder:
    """Validation order matters: size is checked before price, so a
    bad size always produces OUTCOME_SIZE_NON_INTEGER even when the
    price would also fail. This stabilises the error code agents
    pattern-match."""

    def test_size_error_takes_precedence_over_price_error(self):
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("1.5", "5.0")  # both fail
        assert exc.value.code == "OUTCOME_SIZE_NON_INTEGER"

    def test_price_range_takes_precedence_over_tick(self):
        # 1.5 is out of range; tick alignment is irrelevant.
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("100", "1.5")
        assert exc.value.code == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_tick_takes_precedence_over_min_notional(self):
        # 0.50005 (sub-tick) at size 1 — also fails min notional, but tick fires first.
        with pytest.raises(OutcomeValidationError) as exc:
            validate_outcome_order("1", "0.50005")
        assert exc.value.code == "OUTCOME_TICK_VIOLATION"
