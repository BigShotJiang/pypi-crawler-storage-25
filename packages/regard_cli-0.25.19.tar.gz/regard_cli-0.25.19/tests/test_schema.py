"""Schema introspection tests — verify CLI command tree introspection."""

import json

from regard.main import app, generate_schema


def test_schema_structure():
    """Schema has expected top-level keys."""
    s = generate_schema(app)
    assert "version" in s
    assert "total_commands" in s
    assert "commands" in s
    assert isinstance(s["commands"], list)


def test_schema_command_shape():
    """Each command has name, description, class, params."""
    for cmd in generate_schema(app)["commands"]:
        assert "name" in cmd
        assert "description" in cmd
        assert "class" in cmd
        assert "params" in cmd
        assert cmd["class"] in ("agent-safe", "mutating", "human-only", "meta")


def test_schema_dot_notation():
    """Command names use dot notation."""
    names = [c["name"] for c in generate_schema(app)["commands"]]
    assert "hypercore.order" in names
    assert "hypercore.status" in names
    assert "polymarket.markets" in names


def test_schema_includes_hypercore_commands():
    """Known hypercore commands appear."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in (
        "hypercore.status", "hypercore.order", "hypercore.preflight",
        "hypercore.positions", "hypercore.stop",
    ):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_includes_polymarket_commands():
    """Known polymarket commands appear."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in ("polymarket.status", "polymarket.order", "polymarket.markets"):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_includes_polygon_commands():
    """Polygon chain commands appear under their dot-paths."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in (
        "polygon.send",
        "polygon.usdc.transfer.usdce",
        "polygon.usdce.transfer.pusd",
        "polygon.pusd.transfer.usdce",
    ):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_includes_hypercore_transfer_commands():
    """Hypercore fund-movement commands appear under their compartment paths."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in (
        "hypercore.perp.transfer.spot",
        "hypercore.perp.transfer.dex",
        "hypercore.spot.transfer.perp",
        "hypercore.spot.transfer.dex",
        "hypercore.dex.transfer.spot",
        "hypercore.dex.transfer.perp",
        "hypercore.dex.transfer.dex",
        "hypercore.spot.send",
    ):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_includes_session_commands():
    """Session commands appear."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in ("session.gm", "session.gg", "session.cope", "session.pnl"):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_includes_invoke_without_command():
    """Directly invocable groups (killswitch, selfup, port) appear as commands."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in ("killswitch", "selfup", "port"):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_excludes_structural_groups():
    """Structural groups (hypercore, polymarket, polygon, session) are not commands.

    Note: `wallet` is invoke_without_command — bare `regard wallet` is callable
    (reports status), and `regard wallet <key>` saves a key. So it IS in the
    schema as a leaf command.
    """
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for group in ("hypercore", "polymarket", "polygon", "session"):
        assert group not in names, f"Structural group should be excluded: {group}"


def test_schema_params_structure():
    """Command params have type and required fields."""
    cmds = {c["name"]: c for c in generate_schema(app)["commands"]}
    order = cmds["hypercore.order"]
    assert isinstance(order["params"], dict)
    for name, info in order["params"].items():
        assert "type" in info
        assert "required" in info


def test_schema_param_types():
    """Param types are JSON Schema types, not Click types."""
    cmds = {c["name"]: c for c in generate_schema(app)["commands"]}
    order = cmds["hypercore.order"]
    valid_types = {"string", "integer", "number", "boolean"}
    for name, info in order["params"].items():
        assert info["type"] in valid_types, f"Param {name} has non-schema type: {info['type']}"


def test_schema_command_classes():
    """Mutating and human-only commands are correctly classified."""
    cmds = {c["name"]: c for c in generate_schema(app)["commands"]}
    assert cmds["hypercore.order"]["class"] == "mutating"
    # Mutating fund-movement under the new compartment-shift dot-paths.
    assert cmds["hypercore.perp.transfer.spot"]["class"] == "mutating"
    assert cmds["hypercore.spot.transfer.perp"]["class"] == "mutating"
    assert cmds["polygon.usdce.transfer.pusd"]["class"] == "mutating"
    assert cmds["polygon.send"]["class"] == "mutating"
    assert cmds["polymarket.approve"]["class"] == "mutating"
    # HIP-4 outcome split/merge — both sign L1 actions, must be mutating
    # (peer-review v0.25.17 ratchet — initial implementation omitted these
    # from _MUTATING; agents consulting the schema would have classified
    # them as agent-safe and bypassed the gate).
    assert cmds["hypercore.outcome-split"]["class"] == "mutating"
    assert cmds["hypercore.outcome-merge"]["class"] == "mutating"
    # HIP-4 question-level primitives — same constraint (Phase 4, v0.25.18).
    assert cmds["hypercore.question-merge"]["class"] == "mutating"
    assert cmds["hypercore.question-negate"]["class"] == "mutating"
    assert cmds["killswitch"]["class"] == "human-only"
    # `wallet` is agent-safe — bare `regard wallet` returns JSON status (no
    # mutation). The write path (`regard wallet <key>`) is still safe at the
    # classifier level because agents have no key to pass; the real safety
    # gate is that keys never appear in the transcript (SKILL.md hygiene).
    assert cmds["wallet"]["class"] == "agent-safe"
    assert cmds["hypercore.status"]["class"] == "agent-safe"
    assert cmds["hypercore.positions"]["class"] == "agent-safe"


def test_schema_no_unclassified_commands():
    """Every command has a valid class — no orphans."""
    for cmd in generate_schema(app)["commands"]:
        assert cmd["class"] in ("agent-safe", "mutating", "human-only", "meta"), \
            f"{cmd['name']} has invalid class: {cmd['class']}"


def test_schema_total_count():
    """Total commands is reasonable."""
    s = generate_schema(app)
    assert s["total_commands"] >= 40, f"Only {s['total_commands']} commands"


def test_schema_cli_all_commands():
    """The schema CLI command (no arg) produces valid JSON envelope with all commands."""
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["schema"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["ok"] is True
    assert data["data"]["total_commands"] >= 40


def test_schema_cli_single_command():
    """The schema CLI command with an arg returns a single command."""
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["schema", "hypercore.order"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["ok"] is True
    assert data["data"]["name"] == "hypercore.order"
    assert data["data"]["class"] == "mutating"
    assert "params" in data["data"]


def test_schema_cli_unknown_command():
    """The schema CLI command with unknown arg returns structured error."""
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["schema", "nonexistent.command"])
    assert result.exit_code != 0
    data = json.loads(result.output)
    assert data["ok"] is False
    assert data["error"]["code"] == "UNKNOWN_COMMAND"
