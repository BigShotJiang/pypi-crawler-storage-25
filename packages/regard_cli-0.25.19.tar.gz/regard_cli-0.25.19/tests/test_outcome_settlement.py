"""Tests for SettlementWatcher — HIP-4 outcome settlement detection.

Pure-logic tests against synthetic poll sequences. The watcher's I/O loop
in commands/watch.py is covered separately in test_watch.py.

Coverage paths:
- Settled (won) — outcome disappears, USDH delta ≈ size held
- Settled (lost) — outcome disappears, USDH delta ≈ 0
- Sale (Cycle D) — balance clears while outcome stays in meta → no event
- Cold start — first poll never emits (no prior state)
- Multi-outcome — separate tracking per outcome_id
- USDH unobservable — payout reports "unknown"
"""

from regard.venues.hyperliquid.outcome_settlement import (
    SettlementWatcher,
    _classify_settlement,
)


def _meta_entry(outcome: int, *, expiry: str = "20260505-0600", target_price: str = "80000") -> dict:
    """Build a synthetic outcomeMeta record matching resolver.get_outcomes() shape."""
    return {
        "outcome": outcome,
        "name": "Recurring",
        "description": f"class:priceBinary|underlying:BTC|expiry:{expiry}|targetPrice:{target_price}|period:1d",
        "parsed_description": {
            "class": "priceBinary",
            "underlying": "BTC",
            "expiry": expiry,
            "target_price": target_price,
            "period": "1d",
        },
        "sides": [
            {"side": 0, "name": "Yes", "coin": f"#{outcome*10}", "balance_coin": f"+{outcome*10}", "asset_id": 100_000_000 + outcome*10},
            {"side": 1, "name": "No", "coin": f"#{outcome*10+1}", "balance_coin": f"+{outcome*10+1}", "asset_id": 100_000_001 + outcome*10},
        ],
    }


def _balance_outcome(outcome: int, side: int, size: str) -> dict:
    """Build a synthetic +<enc> spot balance row matching get_spot_balances output."""
    return {
        "coin": f"+{outcome*10 + side}",
        "balance": size,
        "token_index": None,
        "kind": "outcome",
        "outcome": outcome,
        "side": side,
        "side_name": "yes" if side == 0 else "no",
    }


def _balance_usdh(amount: str) -> dict:
    return {"coin": "USDH", "balance": amount, "token_index": 360, "kind": "spot", "token": "USDH"}


# ---------------------------------------------------------------------------
# Settlement detection paths
# ---------------------------------------------------------------------------


def test_settles_won_when_outcome_disappears_with_full_payout():
    """Held YES position 21 contracts → outcome removed → USDH +21 → won."""
    w = SettlementWatcher()
    # Tick 1: position visible, outcome 2 in meta.
    events = w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_outcome(2, 0, "21"), _balance_usdh("3.62")],
        now_iso="2026-05-04T05:59:00Z",
    )
    assert events == []  # silent on first tracking

    # Tick 2: outcome gone, USDH credited ≈ 21.
    events = w.poll(
        outcomes_meta=[],  # outcome 2 removed by validators
        spot_balances=[_balance_usdh("24.62")],  # +21 credit
        now_iso="2026-05-04T06:00:30Z",
    )
    assert len(events) == 1
    e = events[0]
    assert e["event"] == "outcome_settled"
    assert e["outcome"] == 2
    assert e["side_held"] == "yes"
    assert e["size"] == "21"
    assert e["payout_usdh"] == "21.00"
    assert e["implied_winning_side"] == "held"
    assert e["settled_at"] == "2026-05-04T06:00:30Z"
    assert e["expiry"] == "20260505-0600"


def test_settles_lost_when_outcome_disappears_with_zero_payout():
    """Held NO position 15 contracts → outcome removed → USDH +0 → lost."""
    w = SettlementWatcher()
    w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_outcome(2, 1, "15"), _balance_usdh("10.0")],
        now_iso="2026-05-04T05:59:00Z",
    )
    events = w.poll(
        outcomes_meta=[],
        spot_balances=[_balance_usdh("10.0")],
        now_iso="2026-05-04T06:00:30Z",
    )
    assert len(events) == 1
    e = events[0]
    assert e["payout_usdh"] == "0.0"
    assert e["implied_winning_side"] == "opposite"
    assert e["side_held"] == "no"


def test_sale_does_not_emit_settlement():
    """Cycle D pattern: position closed via sell while outcome still active.
    Watcher MUST NOT emit a settlement event."""
    w = SettlementWatcher()
    w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_outcome(2, 0, "21"), _balance_usdh("3.62")],
        now_iso="2026-05-04T07:00:00Z",
    )
    # Sale: balance row disappears, USDH up, outcome STILL in meta.
    events = w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_usdh("13.97")],
        now_iso="2026-05-04T07:05:00Z",
    )
    assert events == []


def test_cold_start_first_poll_silent():
    """A fresh watcher's first tick takes inventory; never emits.
    Prevents spurious 'settled' events on watcher restart."""
    w = SettlementWatcher()
    events = w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_outcome(2, 0, "21"), _balance_usdh("3.62")],
        now_iso="2026-05-04T08:00:00Z",
    )
    assert events == []


def test_no_holdings_emits_nothing():
    """Wallet with no outcome positions never emits."""
    w = SettlementWatcher()
    for _ in range(3):
        events = w.poll(
            outcomes_meta=[_meta_entry(2)],
            spot_balances=[_balance_usdh("10.0")],
            now_iso="2026-05-04T08:00:00Z",
        )
        assert events == []


def test_multi_outcome_separate_tracking():
    """Holding two different outcomes: one settles, the other stays active.
    Only the settled one emits."""
    w = SettlementWatcher()
    w.poll(
        outcomes_meta=[_meta_entry(2), _meta_entry(3)],
        spot_balances=[
            _balance_outcome(2, 0, "21"),
            _balance_outcome(3, 1, "15"),
            _balance_usdh("5.0"),
        ],
        now_iso="2026-05-04T08:00:00Z",
    )
    events = w.poll(
        outcomes_meta=[_meta_entry(3)],  # only #2 settled
        spot_balances=[
            _balance_outcome(3, 1, "15"),
            _balance_usdh("26.0"),  # +21 credit from #2
        ],
        now_iso="2026-05-04T08:05:00Z",
    )
    assert len(events) == 1
    assert events[0]["outcome"] == 2


def test_payout_unknown_when_usdh_unobservable():
    """If we transition straight from cold-start to settlement (no prior
    USDH observation), payout reports 'unknown'."""
    w = SettlementWatcher()
    # Manually seed tracking without a prior USDH observation.
    w._tracked[2] = {
        "side": 0, "side_name": "yes", "size": "21",
        "name": "Recurring", "expiry": "20260505-0600", "target_price": "80000",
    }
    # _prev_usdh stays None.
    events = w.poll(
        outcomes_meta=[],
        spot_balances=[_balance_usdh("10.0")],
        now_iso="2026-05-04T09:00:00Z",
    )
    assert len(events) == 1
    assert events[0]["payout_usdh"] == "unknown"
    assert events[0]["implied_winning_side"] == "unknown"


# ---------------------------------------------------------------------------
# _classify_settlement helper
# ---------------------------------------------------------------------------


def test_classify_held_won_full_payout():
    from decimal import Decimal
    payout, winner = _classify_settlement("21", Decimal("3"), Decimal("24"))
    assert payout == "21"
    assert winner == "held"


def test_classify_held_lost_zero_payout():
    from decimal import Decimal
    payout, winner = _classify_settlement("21", Decimal("3"), Decimal("3"))
    assert payout == "0"
    assert winner == "opposite"


def test_classify_first_poll_unknown():
    payout, winner = _classify_settlement("21", None, None)
    assert payout == "unknown"
    assert winner == "unknown"


def test_classify_negative_delta_does_not_infer_winner():
    """USDH went down across the window — likely an unrelated outflow.
    Payout reports the negative delta but winner stays unknown."""
    from decimal import Decimal
    payout, winner = _classify_settlement("21", Decimal("10"), Decimal("9"))
    assert payout.startswith("-")
    assert winner == "unknown"


def test_classify_partial_payout_at_threshold():
    """Payout >= 50% of size counts as held-won (covers fee haircut /
    multi-position aggregation drift)."""
    from decimal import Decimal
    payout, winner = _classify_settlement("20", Decimal("0"), Decimal("10"))
    assert winner == "held"
    payout, winner = _classify_settlement("20", Decimal("0"), Decimal("9"))
    assert winner == "opposite"


# ---------------------------------------------------------------------------
# count_held_outcomes_near_expiry — tilt indicator helper
# ---------------------------------------------------------------------------


def test_near_expiry_counts_within_threshold():
    """Held outcome expiring 30 min from now → counts at 60 min threshold."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)  # 30 min before 06:00 expiry
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 1


def test_near_expiry_excludes_far_outcomes():
    """Held outcome expiring 90 min from now is NOT near at 60 min threshold."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 4, 30, tzinfo=timezone.utc)  # 90 min before 06:00
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 0


def test_near_expiry_excludes_past_expiry():
    """Already-expired outcome counts as 0 — past the actionable window."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 6, 30, tzinfo=timezone.utc)  # 30 min after expiry
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 0


def test_near_expiry_zero_threshold_returns_zero():
    """`threshold_minutes` ≤ 0 disables detection."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
    assert count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=0,
        now_utc=now,
    ) == 0


def test_near_expiry_multi_position():
    """Holding two outcomes; one near, one far → count = 1."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
    count = count_held_outcomes_near_expiry(
        spot_balances=[
            _balance_outcome(2, 0, "21"),  # near (06:00)
            _balance_outcome(3, 1, "15"),  # far (next day)
        ],
        outcomes_meta=[
            _meta_entry(2, expiry="20260505-0600"),
            _meta_entry(3, expiry="20260506-0600"),
        ],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 1


def test_near_expiry_outcome_not_in_meta_skipped():
    """Held outcome with no matching record in outcomeMeta — skip silently
    (the resolver lazy-load might be stale; safer to under-count than over-)."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 0


def test_near_expiry_zero_balance_not_counted():
    """Dust row at balance 0 is ignored — defensive against stale spot rows."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "0")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 0


def test_parse_expiry_canonical():
    """`20260505-0600` parses to UTC datetime."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcomes import parse_expiry
    assert parse_expiry("20260505-0600") == datetime(2026, 5, 5, 6, 0, tzinfo=timezone.utc)


def test_parse_expiry_invalid_returns_none():
    from regard.venues.hyperliquid.outcomes import parse_expiry
    assert parse_expiry(None) is None
    assert parse_expiry("") is None
    assert parse_expiry("garbage") is None
    assert parse_expiry("2026-05-05") is None  # wrong shape
    assert parse_expiry("20260505-99") is None  # wrong length
    assert parse_expiry("20260505-9999") is None  # invalid HHMM


# ---------------------------------------------------------------------------
# v0.23.3 peer-review regression tests
# ---------------------------------------------------------------------------


class TestResolverForceReloadFailureRegression:
    """RESOLVE-FALSE-SETTLE — Critical (peer-review v0.23.3 ratchet).

    `_load_outcomes(force=True)` previously cleared `_outcomes` and
    `_outcomes_by_id` BEFORE the network call. On any transient HL API
    failure during a watcher's force-reload, the resolver was left with
    empty outcomes meta — and the SettlementWatcher would then read
    `current_outcome_ids = set()`, see every tracked outcome as missing,
    and fire false `outcome_settled` events for the whole portfolio.
    The fix defers `clear()` until after a successful network + Pydantic
    validation. These tests pin the recovery shape.
    """

    def test_force_reload_preserves_state_when_network_fails(self):
        """Force-reload that hits a network exception MUST keep the prior
        outcomes intact (caller falls through to stale-but-correct data)."""
        from unittest.mock import MagicMock

        from regard.venues.hyperliquid.resolver import Resolver

        info = MagicMock()
        info.coin_to_asset = {}
        info.name_to_coin = {}
        # First load — succeeds.
        info.post.return_value = {
            "outcomes": [
                {"outcome": 7, "name": "Recurring",
                 "description": "class:priceBinary|underlying:BTC|expiry:20260505-0600|targetPrice:80000|period:1d",
                 "sideSpecs": [{"name": "Yes"}, {"name": "No"}]}
            ],
            "questions": [],
        }
        resolver = Resolver(info)
        first = resolver.get_outcomes()
        assert len(first) == 1 and first[0]["outcome"] == 7

        # Force reload — network blows up.
        info.post.side_effect = Exception("transient HL API failure")
        second = resolver.get_outcomes(force_reload=True)
        # State preserved — caller still sees outcome 7.
        assert len(second) == 1 and second[0]["outcome"] == 7

    def test_force_reload_preserves_state_when_pydantic_fails(self):
        """Same protection when validation fails on a malformed response."""
        from unittest.mock import MagicMock

        from regard.venues.hyperliquid.resolver import Resolver

        info = MagicMock()
        info.coin_to_asset = {}
        info.name_to_coin = {}
        info.post.return_value = {
            "outcomes": [
                {"outcome": 7, "name": "Recurring",
                 "description": "class:priceBinary|underlying:BTC|expiry:20260505-0600|targetPrice:80000|period:1d",
                 "sideSpecs": [{"name": "Yes"}, {"name": "No"}]}
            ],
            "questions": [],
        }
        resolver = Resolver(info)
        resolver.get_outcomes()
        # Force reload returns garbage that won't validate.
        info.post.return_value = {"unexpected": "shape"}
        second = resolver.get_outcomes(force_reload=True)
        assert len(second) == 1 and second[0]["outcome"] == 7

    def test_watcher_does_not_emit_false_settle_on_resolver_failure(self):
        """End-to-end: SettlementWatcher fed by a resolver whose
        force-reload silently failed must NOT classify the still-held
        outcome as settled. This is the live failure mode the v0.23.3
        ratchet was filed for."""
        w = SettlementWatcher()
        # Tick 1 — observe held position.
        w.poll(
            outcomes_meta=[_meta_entry(7)],
            spot_balances=[_balance_outcome(7, 0, "21"), _balance_usdh("5.0")],
            now_iso="2026-05-04T08:00:00Z",
        )
        # Tick 2 — resolver returned its PRESERVED last-good outcomes
        # (exactly what the fixed _load_outcomes does on transient
        # failure). Because the outcome is still in current_outcome_ids,
        # the watcher must NOT emit.
        events = w.poll(
            outcomes_meta=[_meta_entry(7)],  # same as tick 1
            spot_balances=[_balance_outcome(7, 0, "21"), _balance_usdh("5.0")],
            now_iso="2026-05-04T08:05:00Z",
        )
        assert events == []


class TestSimultaneousSettlement:
    """SIMULT-CLASSIFY — Important (peer-review v0.23.3 ratchet).

    When >1 outcome settles in the same poll, the wallet-level USDH delta
    cannot be attributed to individual outcomes. `_classify_settlement`
    used to apply the per-outcome heuristic to each, mis-tagging a loser
    as `held` because the winner's payout dominated the wallet delta.
    Fix: when len(to_settle) > 1, set implied_winning_side = "unknown"
    for all simultaneous events.
    """

    def test_simultaneous_settle_marks_winner_unknown(self):
        """Two outcomes settle in the same poll, one wins (50 contracts)
        and one loses (30 contracts). USDH delta = +50. Pre-fix, the loser
        was mis-classified as `held` because 50 ≥ 30*0.5. Post-fix, both
        events report `implied_winning_side = "unknown"`."""
        w = SettlementWatcher()
        w.poll(
            outcomes_meta=[_meta_entry(1), _meta_entry(2)],
            spot_balances=[
                _balance_outcome(1, 0, "50"),  # YES, will win
                _balance_outcome(2, 1, "30"),  # NO, will lose
                _balance_usdh("100.0"),
            ],
            now_iso="2026-05-04T08:00:00Z",
        )
        events = w.poll(
            outcomes_meta=[],  # both settled simultaneously
            spot_balances=[_balance_usdh("150.0")],  # +50 from outcome 1 only
            now_iso="2026-05-04T08:05:00Z",
        )
        assert len(events) == 2
        for e in events:
            assert e["implied_winning_side"] == "unknown", e
        # `payout_usdh` reports the wallet-level delta (still useful as a
        # bound), not per-outcome attribution.
        assert events[0]["payout_usdh"] == "50.0"
        assert events[1]["payout_usdh"] == "50.0"

    def test_single_settle_still_classifies_normally(self):
        """The fix only triggers when len(to_settle) > 1. Single
        settlements continue to use _classify_settlement's heuristic."""
        w = SettlementWatcher()
        w.poll(
            outcomes_meta=[_meta_entry(1)],
            spot_balances=[_balance_outcome(1, 0, "50"), _balance_usdh("100.0")],
            now_iso="2026-05-04T08:00:00Z",
        )
        events = w.poll(
            outcomes_meta=[],
            spot_balances=[_balance_usdh("150.0")],
            now_iso="2026-05-04T08:05:00Z",
        )
        assert len(events) == 1
        assert events[0]["implied_winning_side"] == "held"


# ---------------------------------------------------------------------------
# v0.25.15 — HIP-4 multi-outcome question settlement Phase 2
# ---------------------------------------------------------------------------


def _question_meta_entry(
    qid: int,
    *,
    named_outcomes: list[int],
    fallback_outcome: int,
    settled_named_outcomes: list[int] | None = None,
    underlying: str = "BTC",
    expiry: str = "20260508-0600",
    thresholds: tuple[str, ...] = ("79303", "82540"),
    period: str = "1d",
) -> dict:
    """Build a synthetic question record matching resolver.get_questions() shape."""
    thr_str = ",".join(thresholds)
    return {
        "question": qid,
        "name": "Recurring",
        "description": f"class:priceBucket|underlying:{underlying}|expiry:{expiry}|priceThresholds:{thr_str}|period:{period}",
        "parsed_description": {
            "class": "priceBucket",
            "underlying": underlying,
            "expiry": expiry,
            "price_thresholds": list(thresholds),
            "period": period,
        },
        "fallback_outcome": fallback_outcome,
        "named_outcomes": list(named_outcomes),
        "settled_named_outcomes": list(settled_named_outcomes or []),
        # 'outcomes' field omitted — watcher reads from outcomes_meta/questions_meta
        # directly via question_id linkage on outcome records.
    }


def _question_outcome_meta(
    outcome: int,
    *,
    question_id: int,
    bucket_label: str,
    is_fallback: bool = False,
    index: int | None = None,
) -> dict:
    """Build an outcomeMeta record for a question-bound outcome (description=index:N or 'other')."""
    if is_fallback:
        description = "other"
        parsed = {
            "class": None,
            "underlying": None,
            "expiry": None,
            "target_price": None,
            "period": None,
            "price_thresholds": None,
            "index": None,
            "is_fallback": True,
        }
    else:
        description = f"index:{index}"
        parsed = {
            "class": None,
            "underlying": None,
            "expiry": None,
            "target_price": None,
            "period": None,
            "price_thresholds": None,
            "index": index,
            "is_fallback": False,
        }
    return {
        "outcome": outcome,
        "name": "Recurring",
        "description": description,
        "parsed_description": parsed,
        "sides": [
            {"side": 0, "name": "Yes", "coin": f"#{outcome*10}", "balance_coin": f"+{outcome*10}", "asset_id": 100_000_000 + outcome*10},
            {"side": 1, "name": "No", "coin": f"#{outcome*10+1}", "balance_coin": f"+{outcome*10+1}", "asset_id": 100_000_001 + outcome*10},
        ],
        "question_id": question_id,
        "bucket_label": bucket_label,
        "is_fallback": is_fallback,
    }


class TestQuestionAwareSettlement:
    """Path A — settledNamedOutcomes-driven question settlement.

    The authoritative signal: when a question's `settled_named_outcomes`
    transitions `[]` → `[winner_id]`, the watcher emits deterministic
    per-outcome events (no USDH-delta inference). The event payload carries
    `question_id`, `bucket_label`, `is_fallback`, `winning_outcome_ids`, and
    `settlement_source: "settledNamedOutcomes"` so consumers can aggregate
    per-question and audit which signal fired.
    """

    def test_settlednamedoutcomes_transition_emits_winner_held(self):
        """User holds outcome 7 YES. Question settles with winner=7. Event:
        side_held=yes, implied_winning_side=held, deterministic (no USDH delta)."""
        w = SettlementWatcher()
        outcomes_pre = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
            _question_outcome_meta(9, question_id=0, bucket_label="≥82540", index=2),
            _question_outcome_meta(10, question_id=0, bucket_label="fallback", is_fallback=True),
        ]
        questions_pre = [_question_meta_entry(0, named_outcomes=[7, 8, 9], fallback_outcome=10)]
        # Tick 1 — observe held position on outcome 7 YES.
        events = w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_pre,
        )
        assert events == []

        # Tick 2 — question settles (settled_named_outcomes=[7]).
        questions_post = [
            _question_meta_entry(0, named_outcomes=[7, 8, 9], fallback_outcome=10, settled_named_outcomes=[7])
        ]
        events = w.poll(
            outcomes_meta=outcomes_pre,  # outcomes still in meta — Path A fires before removal
            spot_balances=[_balance_usdh("15.0")],  # +5 credit (deterministic; not used by Path A)
            now_iso="2026-05-08T06:00:30Z",
            questions_meta=questions_post,
        )
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "outcome_settled"
        assert e["outcome"] == 7
        assert e["side_held"] == "yes"
        assert e["implied_winning_side"] == "held"  # deterministic — held YES of winner
        assert e["question_id"] == 0
        assert e["bucket_label"] == "<79303"
        assert e["is_fallback"] is False
        assert e["winning_outcome_ids"] == [7]
        assert e["settlement_source"] == "settledNamedOutcomes"

    def test_settlednamedoutcomes_transition_emits_loser_opposite(self):
        """User holds outcome 8 YES. Winner=7. Event: side_held=yes, implied=opposite."""
        w = SettlementWatcher()
        outcomes_pre = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
        ]
        questions_pre = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10)]
        w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_pre,
        )
        questions_post = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10, settled_named_outcomes=[7])]
        events = w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_usdh("10.0")],
            now_iso="2026-05-08T06:00:30Z",
            questions_meta=questions_post,
        )
        assert len(events) == 1
        e = events[0]
        assert e["outcome"] == 8
        assert e["implied_winning_side"] == "opposite"  # held YES of loser
        assert e["winning_outcome_ids"] == [7]

    def test_settlednamedoutcomes_no_path_b_double_emit(self):
        """Path A drains tracking; if outcomes are also removed in the same
        poll (or next poll), Path B must not double-emit."""
        w = SettlementWatcher()
        outcomes_pre = [_question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0)]
        questions_pre = [_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10)]
        w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_pre,
        )
        # Settlement + removal in same poll (the validators may do both).
        events = w.poll(
            outcomes_meta=[],  # outcome 7 removed
            spot_balances=[_balance_usdh("15.0")],
            now_iso="2026-05-08T06:00:30Z",
            questions_meta=[_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10, settled_named_outcomes=[7])],
        )
        # Exactly ONE event — Path A fires, Path B sees empty tracking.
        assert len(events) == 1
        assert events[0]["settlement_source"] == "settledNamedOutcomes"

    def test_holds_no_position_no_event_on_question_settle(self):
        """User has no holdings — question settling triggers no events."""
        w = SettlementWatcher()
        outcomes_pre = [_question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0)]
        questions_pre = [_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10)]
        w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_pre,
        )
        questions_post = [_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10, settled_named_outcomes=[7])]
        events = w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_usdh("10.0")],
            now_iso="2026-05-08T06:00:30Z",
            questions_meta=questions_post,
        )
        assert events == []

    def test_holds_multiple_buckets_one_winner_each_classified_correctly(self):
        """User holds outcome 7 YES + outcome 8 NO. Winner=7 settles question.
        Both events fire deterministically: 7-YES=held, 8-NO=held (since 8 lost
        and user held NO of 8)."""
        w = SettlementWatcher()
        outcomes_pre = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
        ]
        questions_pre = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10)]
        w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[
                _balance_outcome(7, 0, "5"),  # YES of 7
                _balance_outcome(8, 1, "5"),  # NO of 8
                _balance_usdh("10.0"),
            ],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_pre,
        )
        questions_post = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10, settled_named_outcomes=[7])]
        events = w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_usdh("20.0")],  # +10 credit (5 from 7-YES win + 5 from 8-NO win)
            now_iso="2026-05-08T06:00:30Z",
            questions_meta=questions_post,
        )
        assert len(events) == 2
        events_by_oid = {e["outcome"]: e for e in events}
        assert events_by_oid[7]["implied_winning_side"] == "held"  # held YES of winner
        assert events_by_oid[8]["implied_winning_side"] == "held"  # held NO of loser
        assert events_by_oid[7]["winning_outcome_ids"] == [7]
        assert events_by_oid[8]["winning_outcome_ids"] == [7]

    def test_question_outcome_falls_through_to_path_b_without_questions_meta(self):
        """Pre-Phase-2 callers passing only outcomes_meta/balances/now_iso
        still get settlement detection via outcome removal (Path B). Question
        fields on the event are still populated from the tracked record."""
        w = SettlementWatcher()
        outcomes_pre = [_question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0)]
        # No questions_meta passed.
        w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
        )
        events = w.poll(
            outcomes_meta=[],
            spot_balances=[_balance_usdh("15.0")],
            now_iso="2026-05-08T06:00:30Z",
        )
        assert len(events) == 1
        e = events[0]
        assert e["settlement_source"] == "meta_removal"
        assert e["question_id"] == 0
        assert e["bucket_label"] == "<79303"
        assert e["winning_outcome_ids"] == []  # empty — Path B can't determine

    def test_standalone_binary_question_id_is_none(self):
        """Settlement event for a standalone binary outcome carries question_id=None."""
        w = SettlementWatcher()
        w.poll(
            outcomes_meta=[_meta_entry(2)],
            spot_balances=[_balance_outcome(2, 0, "21"), _balance_usdh("3.62")],
            now_iso="2026-05-04T05:59:00Z",
        )
        events = w.poll(
            outcomes_meta=[],
            spot_balances=[_balance_usdh("24.62")],
            now_iso="2026-05-04T06:00:30Z",
        )
        assert len(events) == 1
        e = events[0]
        assert e["question_id"] is None
        assert e["bucket_label"] is None
        assert e["is_fallback"] is False
        assert e["settlement_source"] == "meta_removal"


# ---------------------------------------------------------------------------
# v0.25.15 — Settlement prediction events
# ---------------------------------------------------------------------------


class TestPredictionPriceBucket:
    """outcome_settlement_predicted for HIP-4 question (priceBucket).

    Mark price falling into bucket k → predicted_winner = named_outcomes[k].
    Quiet on stable predictions; emits on entry into the window AND on flips.
    """

    def test_emits_prediction_inside_window_with_correct_bucket(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
            _question_outcome_meta(9, question_id=0, bucket_label="≥82540", index=2),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8, 9], fallback_outcome=10)]
        # 30 min before 06:00 expiry; mark price 80500 → bucket 1.
        now_utc = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:30:00Z",
            questions_meta=questions,
            mids={"BTC": "80500"},
            now_utc=now_utc,
            prediction_window_minutes=60,
        )
        # First poll: silent on settlement (no transition) but DOES emit
        # the entry-into-window prediction.
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions) == 1
        p = predictions[0]
        assert p["kind"] == "question"
        assert p["question_id"] == 0
        assert p["predicted_winner"] == 8
        assert p["predicted_bucket_label"] == "[79303, 82540)"
        assert p["mark_price"] == "80500"
        assert "BTC" in p["mark_price_basis"]
        assert p["settlement_in_seconds"] == 30 * 60

    def test_quiet_on_stable_prediction(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
            _question_outcome_meta(9, question_id=0, bucket_label="≥82540", index=2),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8, 9], fallback_outcome=10)]
        now1 = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:30:00Z",
            questions_meta=questions,
            mids={"BTC": "80500"},
            now_utc=now1,
            prediction_window_minutes=60,
        )
        # Same prediction → no event.
        now2 = datetime(2026, 5, 8, 5, 31, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:31:00Z",
            questions_meta=questions,
            mids={"BTC": "80501"},
            now_utc=now2,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert predictions == []

    def test_emits_on_flip(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
            _question_outcome_meta(9, question_id=0, bucket_label="≥82540", index=2),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8, 9], fallback_outcome=10)]
        now1 = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:30:00Z",
            questions_meta=questions,
            mids={"BTC": "80500"},
            now_utc=now1,
            prediction_window_minutes=60,
        )
        # BTC dumps below 79303 → flip to bucket 0.
        now2 = datetime(2026, 5, 8, 5, 35, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:35:00Z",
            questions_meta=questions,
            mids={"BTC": "78900"},
            now_utc=now2,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions) == 1
        assert predictions[0]["predicted_winner"] == 7
        assert predictions[0]["predicted_bucket_label"] == "<79303"

    def test_silent_outside_window(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10)]
        # 2 hours before expiry, window = 60 min → outside.
        now_utc = datetime(2026, 5, 8, 4, 0, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T04:00:00Z",
            questions_meta=questions,
            mids={"BTC": "80500"},
            now_utc=now_utc,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert predictions == []

    def test_one_prediction_per_question_even_with_multiple_held_buckets(self):
        """Holding 2 outcomes of the same question → 1 prediction event per
        poll keyed by question_id, not 2."""
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
            _question_outcome_meta(9, question_id=0, bucket_label="≥82540", index=2),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8, 9], fallback_outcome=10)]
        now_utc = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[
                _balance_outcome(7, 0, "3"),
                _balance_outcome(8, 0, "5"),
                _balance_outcome(9, 0, "2"),
                _balance_usdh("10.0"),
            ],
            now_iso="2026-05-08T05:30:00Z",
            questions_meta=questions,
            mids={"BTC": "80500"},
            now_utc=now_utc,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions) == 1

    def test_no_prediction_when_underlying_missing_from_mids(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10)]
        now_utc = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:30:00Z",
            questions_meta=questions,
            mids={"ETH": "3000"},  # BTC missing
            now_utc=now_utc,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert predictions == []

    def test_no_predictions_without_holdings(self):
        """Predictions only fire for held positions — pure observers stay silent."""
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10)]
        now_utc = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_usdh("10.0")],
            now_iso="2026-05-08T05:30:00Z",
            questions_meta=questions,
            mids={"BTC": "80500"},
            now_utc=now_utc,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert predictions == []


class TestPredictionPriceBinary:
    """outcome_settlement_predicted for standalone binary outcomes.

    Mark ≥ target → predicted_side=yes, else no. Quiet on stable predictions.
    """

    def test_binary_predicts_yes_when_mark_above_target(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        # Standalone binary: target_price=80000, mark=82000 → yes resolves.
        now_utc = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=[_meta_entry(2, expiry="20260505-0600", target_price="80000")],
            spot_balances=[_balance_outcome(2, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-05T05:30:00Z",
            mids={"BTC": "82000"},
            now_utc=now_utc,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions) == 1
        p = predictions[0]
        assert p["kind"] == "binary"
        assert p["outcome"] == 2
        assert p["predicted_side"] == "yes"
        assert p["mark_price"] == "82000"
        assert p["target_price"] == "80000"

    def test_binary_predicts_no_when_mark_below_target(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        now_utc = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=[_meta_entry(2, expiry="20260505-0600", target_price="80000")],
            spot_balances=[_balance_outcome(2, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-05T05:30:00Z",
            mids={"BTC": "78000"},
            now_utc=now_utc,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions) == 1
        assert predictions[0]["predicted_side"] == "no"

    def test_binary_emits_on_threshold_cross(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [_meta_entry(2, expiry="20260505-0600", target_price="80000")]
        spot = [_balance_outcome(2, 0, "5"), _balance_usdh("10.0")]
        now1 = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
        w.poll(
            outcomes_meta=outcomes,
            spot_balances=spot,
            now_iso="2026-05-05T05:30:00Z",
            mids={"BTC": "82000"},
            now_utc=now1,
            prediction_window_minutes=60,
        )
        # Cross threshold → flip to no.
        now2 = datetime(2026, 5, 5, 5, 35, tzinfo=timezone.utc)
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=spot,
            now_iso="2026-05-05T05:35:00Z",
            mids={"BTC": "79000"},
            now_utc=now2,
            prediction_window_minutes=60,
        )
        predictions = [e for e in events if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions) == 1
        assert predictions[0]["predicted_side"] == "no"


# ---------------------------------------------------------------------------
# v0.25.15 — count_held_outcomes_near_expiry constrained-risk fix
# ---------------------------------------------------------------------------


class TestNearExpiryConstrainedRisk:
    """Holding multiple buckets of one HIP-4 question = ONE unit of question
    risk, not N. Counter dedupes by question_id for question-bound outcomes;
    standalone binaries continue to count individually."""

    def test_multi_buckets_of_one_question_count_as_one(self):
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
            _question_outcome_meta(9, question_id=0, bucket_label="≥82540", index=2),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8, 9], fallback_outcome=10, expiry="20260508-0600")]
        balances = [
            _balance_outcome(7, 0, "3"),
            _balance_outcome(8, 0, "5"),
            _balance_outcome(9, 0, "2"),
        ]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 1

    def test_question_outcome_plus_standalone_counts_two(self):
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _meta_entry(2, expiry="20260508-0600"),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10, expiry="20260508-0600")]
        balances = [_balance_outcome(7, 0, "5"), _balance_outcome(2, 0, "10")]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 2

    def test_two_distinct_questions_count_as_two(self):
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
            _question_outcome_meta(11, question_id=1, bucket_label="<3500", index=0),
        ]
        questions = [
            _question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10, expiry="20260508-0600"),
            _question_meta_entry(1, named_outcomes=[11], fallback_outcome=12, underlying="ETH", expiry="20260508-0600", thresholds=("3500",)),
        ]
        balances = [
            _balance_outcome(7, 0, "5"),
            _balance_outcome(8, 0, "5"),
            _balance_outcome(11, 0, "5"),
        ]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 2

    def test_question_bound_without_questions_meta_silently_skipped(self):
        """Backward-compat: if caller doesn't pass questions_meta, question-bound
        outcomes (no expiry on the outcome itself) get skipped — same as before
        Phase 2."""
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes = [_question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0)]
        balances = [_balance_outcome(7, 0, "5")]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        # No questions_meta — outcome has no expiry on it → skipped.
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now
        )
        assert count == 0


# ---------------------------------------------------------------------------
# v0.25.19 — Phase 5: tilt counter skips fully-hedged questions
# ---------------------------------------------------------------------------


class TestNearExpiryFullyHedged:
    """Phase 5 fully-hedged exclusion. A question position is fully hedged
    when the user holds ≥1 Yes of every bound outcome (named + fallback).
    Such stacks have a deterministic exit path via question-merge — they're
    not tilt risk regardless of orderbook depth or expiry proximity. Phase 5
    skips them from the count. Partial hedges and concentrated bets still
    count (existing v0.25.15 behavior).
    """

    def _outcomes_and_question(self):
        """Standard 3-named + 1-fallback question fixture for these tests."""
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
            _question_outcome_meta(9, question_id=0, bucket_label="≥82540", index=2),
            _question_outcome_meta(10, question_id=0, bucket_label="fallback", is_fallback=True),
        ]
        questions = [
            _question_meta_entry(
                0, named_outcomes=[7, 8, 9], fallback_outcome=10, expiry="20260508-0600"
            )
        ]
        return outcomes, questions

    def test_fully_hedged_question_skipped(self):
        """Holding ≥1 Yes of every bound outcome (3 named + fallback) → 0 tilt."""
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes, questions = self._outcomes_and_question()
        balances = [
            _balance_outcome(7, 0, "1"),   # Yes of named 7
            _balance_outcome(8, 0, "1"),   # Yes of named 8
            _balance_outcome(9, 0, "1"),   # Yes of named 9
            _balance_outcome(10, 0, "1"),  # Yes of fallback 10
        ]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 0  # fully hedged → not counted

    def test_partial_hedge_missing_fallback_yes_counts(self):
        """Yes of every named but NOT fallback → still tilt risk (per Phase 4
        live finding: HL DOES require fallback Yes for mergeQuestion)."""
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes, questions = self._outcomes_and_question()
        balances = [
            _balance_outcome(7, 0, "1"),
            _balance_outcome(8, 0, "1"),
            _balance_outcome(9, 0, "1"),
            # No Yes of fallback (10) → not fully hedged
        ]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 1

    def test_concentrated_bet_counts(self):
        """Yes of one outcome only → still tilt risk."""
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes, questions = self._outcomes_and_question()
        balances = [_balance_outcome(8, 0, "5")]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 1

    def test_holding_no_only_counts(self):
        """Yes-only check: holding No of every outcome (and zero Yes of any)
        is NOT a fully-hedged stack — the user can't merge it. Counts."""
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes, questions = self._outcomes_and_question()
        balances = [
            _balance_outcome(7, 1, "1"),   # No of 7
            _balance_outcome(8, 1, "1"),   # No of 8
            _balance_outcome(9, 1, "1"),   # No of 9
            _balance_outcome(10, 1, "1"),  # No of fallback
        ]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 1  # No-only doesn't qualify as merge-exitable

    def test_fractional_yes_below_one_doesnt_qualify(self):
        """Phase 4 wire format requires integer amounts ≥1 for merge — so a
        fractional Yes (e.g. 0.5) of one outcome breaks the hedge even if
        every other outcome has integer Yes."""
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes, questions = self._outcomes_and_question()
        balances = [
            _balance_outcome(7, 0, "1"),
            _balance_outcome(8, 0, "0.5"),  # below the integer-merge threshold
            _balance_outcome(9, 0, "1"),
            _balance_outcome(10, 0, "1"),
        ]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 1

    def test_two_questions_one_hedged_one_partial(self):
        """Mixed wallet: question A fully hedged (skip), question B partial (count).
        Counter returns 1."""
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes_a = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="≥79303", index=1),
            _question_outcome_meta(10, question_id=0, bucket_label="fallback", is_fallback=True),
        ]
        outcomes_b = [
            _question_outcome_meta(20, question_id=1, bucket_label="<3500", index=0),
            _question_outcome_meta(21, question_id=1, bucket_label="≥3500", index=1),
            _question_outcome_meta(22, question_id=1, bucket_label="fallback", is_fallback=True),
        ]
        questions = [
            _question_meta_entry(
                0, named_outcomes=[7, 8], fallback_outcome=10, expiry="20260508-0600"
            ),
            _question_meta_entry(
                1, named_outcomes=[20, 21], fallback_outcome=22,
                underlying="ETH", expiry="20260508-0600", thresholds=("3500",)
            ),
        ]
        balances = [
            _balance_outcome(7, 0, "1"), _balance_outcome(8, 0, "1"), _balance_outcome(10, 0, "1"),  # q0 fully hedged
            _balance_outcome(20, 0, "1"),  # q1 partial (missing 21 + 22 Yes)
        ]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes_a + outcomes_b, threshold_minutes=60, now_utc=now,
            questions_meta=questions
        )
        assert count == 1  # only q1 counts

    def test_fully_hedged_with_extras(self):
        """Yes of every bound outcome PLUS extra No positions → still fully
        hedged (No positions are surplus, don't break the merge invariant)."""
        from datetime import datetime, timezone

        from regard.venues.hyperliquid.outcome_settlement import (
            count_held_outcomes_near_expiry,
        )
        outcomes, questions = self._outcomes_and_question()
        balances = [
            _balance_outcome(7, 0, "1"), _balance_outcome(7, 1, "1"),   # Yes + No of 7
            _balance_outcome(8, 0, "1"), _balance_outcome(8, 1, "1"),   # Yes + No of 8
            _balance_outcome(9, 0, "1"),                                # Yes only of 9
            _balance_outcome(10, 0, "1"),                               # Yes only of fallback
        ]
        now = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        count = count_held_outcomes_near_expiry(
            balances, outcomes, threshold_minutes=60, now_utc=now, questions_meta=questions
        )
        assert count == 0  # still fully hedged


# ---------------------------------------------------------------------------
# v0.25.16 — peer-review fixes (CANON-1 through CANON-6)
# ---------------------------------------------------------------------------


class TestPathARetrackNoDoubleEmit:
    """CANON-2 — Path A drains tracking; the held-loop must NOT re-add the
    outcome even if the balance row is still present (HL clears the balance
    one or more polls after populating settledNamedOutcomes). Without the
    skip-set, Path A fires on poll N, the held-loop re-tracks, then Path B
    fires on poll N+1 when validators finally remove the outcome from meta —
    duplicate `outcome_settled` for the same position.
    """

    def test_path_a_then_meta_removal_emits_exactly_once(self):
        w = SettlementWatcher()
        outcomes_pre = [_question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0)]
        questions_pre = [_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10)]
        # Tick 1 — establish tracking.
        w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_pre,
        )
        # Tick 2 — Path A fires (settledNamedOutcomes populated). Balance row
        # is STILL present because validators haven't cleared it yet.
        questions_post = [
            _question_meta_entry(0, named_outcomes=[7], fallback_outcome=10, settled_named_outcomes=[7])
        ]
        events_t2 = w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("15.0")],
            now_iso="2026-05-08T06:00:30Z",
            questions_meta=questions_post,
        )
        # Tick 3 — outcome finally removed from meta + balance cleared.
        events_t3 = w.poll(
            outcomes_meta=[],
            spot_balances=[_balance_usdh("15.0")],
            now_iso="2026-05-08T06:01:00Z",
            questions_meta=[],
        )
        # Exactly ONE outcome_settled total — Path A on tick 2.
        all_settled = [e for e in events_t2 + events_t3 if e["event"] == "outcome_settled"]
        assert len(all_settled) == 1
        assert all_settled[0]["settlement_source"] == "settledNamedOutcomes"


class TestPathAContaminatesPathB:
    """CANON-3 — When Path A and Path B fire in the same poll, the wallet-
    wide USDH delta now contains BOTH paths' payouts, so Path B's per-
    outcome attribution is unreliable. Force `implied_winning_side="unknown"`
    on Path B in this case.
    """

    def test_mixed_path_a_and_path_b_same_poll_forces_unknown(self):
        w = SettlementWatcher()
        # Hold:
        #   - question outcome 7 YES (will win via Path A)
        #   - standalone binary 99 YES (will lose via Path B — outcome removed)
        outcomes_pre = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _meta_entry(99, expiry="20260508-0600", target_price="80000"),
        ]
        questions_pre = [_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10)]
        w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[
                _balance_outcome(7, 0, "5"),
                _balance_outcome(99, 0, "5"),
                _balance_usdh("10.0"),
            ],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_pre,
        )
        # Tick 2 — question settles (Path A: outcome 7 wins) AND binary 99
        # removed (Path B). USDH +5 from outcome 7's payout (binary 99 lost,
        # 0 payout). Without the contamination guard, Path B's per-outcome
        # _classify_settlement would see delta=5, size=5, classify "held"
        # (wrong — binary 99 lost).
        # Tick 2 — outcome 7 question settles via Path A (still in meta but
        # settled_named_outcomes populated); binary 99 removed from meta
        # (Path B). Both paths fire in the SAME poll.
        outcomes_t2 = [_question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0)]
        questions_post = [
            _question_meta_entry(0, named_outcomes=[7], fallback_outcome=10, settled_named_outcomes=[7])
        ]
        events = w.poll(
            outcomes_meta=outcomes_t2,  # binary 99 removed; outcome 7 still in
            spot_balances=[_balance_usdh("15.0")],  # +5 from outcome 7 only
            now_iso="2026-05-08T06:00:30Z",
            questions_meta=questions_post,
        )
        events_by_oid = {e["outcome"]: e for e in events if e["event"] == "outcome_settled"}
        # Path A outcome 7: deterministic.
        assert events_by_oid[7]["implied_winning_side"] == "held"
        # Path B outcome 99: forced to unknown because Path A also fired.
        assert events_by_oid[99]["implied_winning_side"] == "unknown"
        assert events_by_oid[99]["settlement_source"] == "meta_removal"


class TestStaleLastPredictionCleared:
    """CANON-1 — `_last_prediction` must be cleared when an outcome leaves
    tracking. HL recurring markets re-use outcome IDs; without cleanup, the
    next period's first prediction is suppressed if it matches the prior
    period's final state.
    """

    def test_binary_settlement_clears_prediction_state(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        # Period A: hold binary outcome 2 YES, prediction fires "yes".
        now_a = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
        events_a = w.poll(
            outcomes_meta=[_meta_entry(2, expiry="20260505-0600", target_price="80000")],
            spot_balances=[_balance_outcome(2, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-05T05:30:00Z",
            mids={"BTC": "82000"},
            now_utc=now_a,
            prediction_window_minutes=60,
        )
        predictions_a = [e for e in events_a if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions_a) == 1 and predictions_a[0]["predicted_side"] == "yes"
        # Period A settles via meta_removal.
        w.poll(
            outcomes_meta=[],
            spot_balances=[_balance_usdh("15.0")],
            now_iso="2026-05-05T06:00:30Z",
            mids={"BTC": "82000"},
            now_utc=datetime(2026, 5, 5, 6, 0, 30, tzinfo=timezone.utc),
            prediction_window_minutes=60,
        )
        # Period B: same outcome ID 2, new expiry, BTC still > target.
        # Without the cleanup, _last_prediction[("binary", 2)] == "yes" would
        # suppress the new prediction.
        now_b = datetime(2026, 5, 6, 5, 30, tzinfo=timezone.utc)
        events_b = w.poll(
            outcomes_meta=[_meta_entry(2, expiry="20260506-0600", target_price="80000")],
            spot_balances=[_balance_outcome(2, 0, "5"), _balance_usdh("15.0")],
            now_iso="2026-05-06T05:30:00Z",
            mids={"BTC": "82000"},
            now_utc=now_b,
            prediction_window_minutes=60,
        )
        predictions_b = [e for e in events_b if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions_b) == 1, "next-period prediction must fire after settlement"
        assert predictions_b[0]["predicted_side"] == "yes"

    def test_question_settlement_clears_prediction_state_only_when_last_bound_outcome_leaves(self):
        from datetime import datetime, timezone
        w = SettlementWatcher()
        outcomes = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
        ]
        questions = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10)]
        now_1 = datetime(2026, 5, 8, 5, 30, tzinfo=timezone.utc)
        # Hold both outcome 7 and outcome 8 of question 0; prediction fires.
        events_1 = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(7, 0, "3"), _balance_outcome(8, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:30:00Z",
            questions_meta=questions,
            mids={"BTC": "80500"},
            now_utc=now_1,
            prediction_window_minutes=60,
        )
        predictions_1 = [e for e in events_1 if e["event"] == "outcome_settlement_predicted"]
        assert len(predictions_1) == 1
        # Sale of outcome 7 — outcome 8 still bound to question 0 → don't drop ("question", 0) prediction state yet.
        now_2 = datetime(2026, 5, 8, 5, 31, tzinfo=timezone.utc)
        events_2 = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(8, 0, "5"), _balance_usdh("13.0")],  # sold outcome 7
            now_iso="2026-05-08T05:31:00Z",
            questions_meta=questions,
            mids={"BTC": "80500"},  # same prediction
            now_utc=now_2,
            prediction_window_minutes=60,
        )
        # Same prediction → suppressed (question state still tracked because outcome 8 holds).
        assert [e for e in events_2 if e["event"] == "outcome_settlement_predicted"] == []


class TestPeriodRollover:
    """CANON-4 — If a tracked outcome's expiry changes in current outcomeMeta
    (HL recycled the integer ID for a new market period), emit a synthetic
    `outcome_settled` event with `settlement_source: "period_rollover"`.
    Otherwise the old period's settlement vanishes silently via the sale
    path."""

    def test_outcome_id_recycled_with_new_expiry_emits_period_rollover(self):
        w = SettlementWatcher()
        # Period A: hold outcome 7 (priceBinary, expiry day-1).
        outcomes_a = [_meta_entry(7, expiry="20260508-0600", target_price="80000")]
        w.poll(
            outcomes_meta=outcomes_a,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
        )
        # Period B: outcome 7 still in meta but with NEW expiry (recycled ID).
        # User no longer holds the position (already credited off-stage).
        outcomes_b = [_meta_entry(7, expiry="20260509-0600", target_price="81000")]
        events = w.poll(
            outcomes_meta=outcomes_b,
            spot_balances=[_balance_usdh("15.0")],
            now_iso="2026-05-08T06:01:00Z",
        )
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "outcome_settled"
        assert e["outcome"] == 7
        assert e["settlement_source"] == "period_rollover"
        assert e["payout_usdh"] == "unknown"
        assert e["implied_winning_side"] == "unknown"
        assert e["expiry"] == "20260508-0600"  # the OLD period's expiry on the event

    def test_question_outcome_id_recycled_emits_period_rollover(self):
        w = SettlementWatcher()
        # Period A: hold outcome 7 of question 0 (BTC daily range, day 1).
        outcomes_a = [_question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0)]
        questions_a = [_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10, expiry="20260508-0600")]
        w.poll(
            outcomes_meta=outcomes_a,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_a,
        )
        # Period B: outcome 7 / question 0 still present with new expiry.
        outcomes_b = [_question_outcome_meta(7, question_id=0, bucket_label="<80000", index=0)]
        questions_b = [_question_meta_entry(0, named_outcomes=[7], fallback_outcome=10, expiry="20260509-0600", thresholds=("80000",))]
        events = w.poll(
            outcomes_meta=outcomes_b,
            spot_balances=[_balance_usdh("15.0")],
            now_iso="2026-05-08T06:01:00Z",
            questions_meta=questions_b,
        )
        rollovers = [e for e in events if e.get("settlement_source") == "period_rollover"]
        assert len(rollovers) == 1
        assert rollovers[0]["outcome"] == 7
        assert rollovers[0]["expiry"] == "20260508-0600"

    def test_no_rollover_when_expiry_unchanged(self):
        """Same expiry across polls = same period. No rollover event."""
        w = SettlementWatcher()
        outcomes = [_meta_entry(7, expiry="20260508-0600")]
        w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
        )
        events = w.poll(
            outcomes_meta=outcomes,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:56:00Z",
        )
        rollovers = [e for e in events if e.get("settlement_source") == "period_rollover"]
        assert rollovers == []


class TestWinningOutcomeIdsList:
    """CANON-6 — `winning_outcome_ids` is a list[int] reflecting the full
    `settled_named_outcomes` from the question, not just index 0. Defends
    against future protocol extensions where multiple outcomes could resolve
    Yes simultaneously."""

    def test_multi_entry_settled_named_outcomes_serialized_in_full(self):
        w = SettlementWatcher()
        outcomes_pre = [
            _question_outcome_meta(7, question_id=0, bucket_label="<79303", index=0),
            _question_outcome_meta(8, question_id=0, bucket_label="[79303, 82540)", index=1),
        ]
        questions_pre = [_question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10)]
        w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_outcome(7, 0, "5"), _balance_usdh("10.0")],
            now_iso="2026-05-08T05:55:00Z",
            questions_meta=questions_pre,
        )
        # Hypothetical multi-resolution (defensive — HL spec says exactly
        # one named outcome, but we serialize the full list either way).
        questions_post = [
            _question_meta_entry(0, named_outcomes=[7, 8], fallback_outcome=10, settled_named_outcomes=[7, 8])
        ]
        events = w.poll(
            outcomes_meta=outcomes_pre,
            spot_balances=[_balance_usdh("20.0")],
            now_iso="2026-05-08T06:00:30Z",
            questions_meta=questions_post,
        )
        assert len(events) == 1
        assert events[0]["winning_outcome_ids"] == [7, 8]
        # The boolean classification: outcome 7 is in winning_set → "held"
        # (we held YES of a winner).
        assert events[0]["implied_winning_side"] == "held"
