"""Tests for v0.25.0 bridge surface (outbound + inbound + perp send).

Per V025-IMPLEMENTATION.md. Five new commands across two signing paths:

Outbound (HL-signed via SDK actions):
- hypercore perp bridge arbitrum --to <addr> <amount>     (withdraw_from_bridge)
- hypercore spot bridge hyperevm --to self <amount> --token <tok>  (send_asset)
- hypercore perp send <addr> <amount>                     (usd_transfer)

Inbound (EVM-signed via core/evm.py):
- arbitrum bridge hypercore --to self <amount>            (ERC-20 to Bridge2)
- hyperevm bridge hypercore --to self <amount> --token <tok>  (ERC-20 or native)
"""

import json
import time
from decimal import Decimal
from unittest.mock import MagicMock, patch

from regard.main import app
from tests.conftest import load_fixture


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


# Address book entries for tests — both EVM addresses are checksummed.
MOCK_ADDRESSES = {
    "trading": {
        "address": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
        "chains": ["hypercore", "polygon", "arbitrum"],
        "added_at": "2026-04-16T12:00:00Z",
    },
    "reserve": {
        "address": "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411",
        "chains": ["hypercore", "polygon"],
        "added_at": "2026-04-16T12:00:00Z",
    },
}

# Mock spot_meta with a linked USDC + a HYPE entry + an unlinked custom token.
# Pulled from golden fixture for canonical tokens to satisfy Article IV.
_SPOT_GOLDEN = load_fixture("hyperliquid", "spot_meta")


def _spot_token(name: str) -> dict:
    for t in _SPOT_GOLDEN["tokens"]:
        if t["name"] == name:
            return dict(t)
    raise KeyError(f"{name} not in golden spot_meta tokens")


# Build a custom spot_meta with explicit evmContract values for testing.
# Schema MUST match the real HL API: `evmContract` is a dict
# {"address": "0x...", "evm_extra_wei_decimals": <int>}, NOT a flat string.
# Earlier mock divergence from this shape masked two critical bugs caught by
# the v0.25.0 round-3 peer review (token_address became a dict; evm extra
# decimals always read 0 because the field doesn't exist as a top-level key).
def _build_mock_spot_meta(usdc_evm_addr=None, include_unlinked=False,
                          usdc_extra_decimals=-2):
    """Build a spot_meta dict matching the real API schema.

    For canonical USDC: weiDecimals=8, evmContract.evm_extra_wei_decimals=-2
    → ERC-20 decimals = 8 + (-2) = 6 (matches native USDC's 6 decimals).
    """
    usdc_entry = _spot_token("USDC")
    # Keep weiDecimals from golden (8); override the contract to a known test addr.
    usdc_entry["evmContract"] = {
        "address": usdc_evm_addr or "0x5555555555555555555555555555555555555555",
        "evm_extra_wei_decimals": usdc_extra_decimals,
    }
    usdh_entry = _spot_token("USDH")
    usdh_entry["evmContract"] = {
        "address": "0x6666666666666666666666666666666666666666",
        "evm_extra_wei_decimals": 0,
    }
    tokens = [
        usdc_entry,
        usdh_entry,
        # HYPE has no evmContract — it's the native gas token on EVM.
        # Mainnet HYPE is non-canonical (`isCanonical: False`); the SDK
        # send_asset call requires the `name:tokenId` colon form for non-
        # canonical tokens. Fixture mirrors mainnet shape so the bridge
        # tests catch the v0.25.7 short-circuit bug if it ever regresses.
        {"name": "HYPE", "index": 150, "weiDecimals": 8,
         "isCanonical": False, "tokenId": "0x0d01dc56dcaaca66ad901c959b4011ec",
         "evmContract": None},
    ]
    if include_unlinked:
        tokens.append({"name": "LICK", "index": 200, "weiDecimals": 6,
                       "isCanonical": False, "tokenId": "0x" + "ff" * 32,
                       "evmContract": None})
    return {"tokens": tokens, "universe": []}


MOCK_SPOT_META = _build_mock_spot_meta()


# ---------------------------------------------------------------------------
# Outbound: hypercore perp bridge arbitrum
# ---------------------------------------------------------------------------


class TestPerpBridgeArbitrum:
    def test_propose_to_self_succeeds(self, runner, patched):
        """--to self resolves to wallet address; proposal carries amount + chain."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None):
            patched["info"].post.side_effect = lambda endpoint, payload: (
                {"withdrawable": "100.0"} if payload.get("type") == "clearinghouseState"
                else []
            )
            result = runner.invoke(app, ["hypercore", "perp", "bridge", "arbitrum",
                                          "--to", "self", "10"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["command"] == "perp.bridge.arbitrum"
            assert d["data"]["params"]["chain"] == "arbitrum"
            # Decimal preserves the user's input representation exactly:
            # `Decimal("10")` → "10". Pre-Decimal code did float() round-trip → "10.0".
            assert d["data"]["params"]["amount"] == "10"
            # --to self ⇒ recipient_on_hl is set (locked decision 18).
            assert d["data"]["params"]["recipient_on_hl"] == "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"

    def test_propose_to_arbitrary_addr(self, runner, patched):
        """--to <addr> stores user-supplied address; recipient_on_hl unset (gate falls back to dest_address)."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={"SEND_ALLOW_RAW_ADDRESS": "true"}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None):
            patched["info"].post.side_effect = lambda endpoint, payload: (
                {"withdrawable": "100.0"} if payload.get("type") == "clearinghouseState"
                else []
            )
            result = runner.invoke(app, ["hypercore", "perp", "bridge", "arbitrum",
                                          "--to", "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411", "10"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["params"]["dest_address"] == "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411"
            assert "recipient_on_hl" not in d["data"]["params"]

    def test_missing_to_flag(self, runner, patched):
        """No --to flag fails with MISSING_DESTINATION."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hypercore", "perp", "bridge", "arbitrum", "10"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "MISSING_DESTINATION"

    def test_executor_calls_withdraw_from_bridge(self):
        """Executor invokes the right SDK method exactly once."""
        mock_exchange = MagicMock()
        mock_exchange.withdraw_from_bridge.return_value = {"status": "ok"}

        with patch("regard.venues.hyperliquid.commands.act.get_exchange", return_value=mock_exchange), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.commands.act import execute_perp_bridge_arbitrum
            result = execute_perp_bridge_arbitrum({
                "sender": "0xSENDER",
                "dest_address": "0xDEST",
                "dest_label": "test",
                "amount": "10.0",
                "chain": "arbitrum",
                "testnet": False,
            })
            mock_exchange.withdraw_from_bridge.assert_called_once_with(10.0, "0xDEST")
            assert result["status"] == "bridged"
            assert result["fee_usdc"] == "1"
            # Decimal quantize to 6 decimals (USDC precision) preserves explicit
            # zeros — more precise than float round() which trims to "9.0".
            assert result["credited_amount"] == "9.000000"


# ---------------------------------------------------------------------------
# Outbound: hypercore spot bridge hyperevm
# ---------------------------------------------------------------------------


class TestSpotBridgeHyperevm:
    def test_propose_to_self_with_usdc_succeeds(self, runner, patched):
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "100.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["params"]["token"] == "USDC"
            assert d["data"]["params"]["chain"] == "hyperevm"
            # System address is computed from the token index.
            assert d["data"]["params"]["dest_address"].startswith("0x20")
            assert d["data"]["params"]["recipient_on_hl"] == "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"

    def test_to_other_addr_rejected(self, runner, patched):
        """Any --to other than 'self' must fail (HL only credits sender)."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411", "5", "--token", "USDC"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_RECIPIENT_NOT_SELF"

    def test_missing_token(self, runner, patched):
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "MISSING_TOKEN"

    def test_token_lowercase_normalized(self, runner, patched):
        """Locked decision 15: --token usdc must route the same as --token USDC."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "100.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "usdc"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["params"]["token"] == "USDC"  # normalized

    def test_hype_routes_to_system_address(self, runner, patched):
        """HYPE special-case: dest_address is 0x222...2222 and sdk_token uses
        the non-canonical `name:tokenId` colon form (HL's send_asset rejects
        the bare `HYPE` name with `Unknown token HYPE` — caught live during
        L Test 2 prep on bonbonki 2026-05-07, fixed in v0.25.7)."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "HYPE", "balance": "100.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "HYPE"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["params"]["dest_address"] == "0x2222222222222222222222222222222222222222"
            # sdk_token MUST be the colon form for non-canonical HYPE — bare
            # "HYPE" causes BRIDGE_FAILED at execute time.
            assert d["data"]["params"]["sdk_token"] == "HYPE:0x0d01dc56dcaaca66ad901c959b4011ec"

    def test_unlinked_token_hard_blocked(self, runner, patched):
        """Locked decision 19: tokens with evmContract: None must hard-block."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "LICK", "balance": "100.0"}]):
            patched["info"].spot_meta.return_value = _build_mock_spot_meta(include_unlinked=True)
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "LICK"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_TOKEN_UNLINKED"

    def test_propose_discloses_fee_estimate_with_oracle(self, runner, patched):
        """Fee estimate is computed and disclosed when RPC + HYPE oracle are available.

        Per HL docs: 200k gas × next-block HyperEVM baseFee, charged in token-equivalent
        at the HYPE oracle rate. The proposal MUST disclose this so users can predict
        their post-bridge balance accurately. Fintech accuracy: silent under-disclosure
        of fees is a defect, not a cosmetic issue.
        """
        from decimal import Decimal

        mock_w3 = MagicMock()
        mock_w3.eth.get_block.return_value = {"baseFeePerGas": 500_000_000}  # 0.5 gwei
        mock_info_for_mids = MagicMock()
        mock_info_for_mids.all_mids.return_value = {"HYPE": "44.0"}

        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.core.rpc_pool.get_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "10.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            patched["info"].all_mids.return_value = {"HYPE": "44.0"}
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "3", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            checks = d["data"]["checks"]
            # Fee = 200_000 * 500_000_000 / 1e18 HYPE = 0.0001 HYPE
            # In USDC at $44 = 0.0044
            expected_fee = Decimal("200000") * Decimal("500000000") / Decimal(10**18) * Decimal("44.0")
            assert checks["bridge_fee_estimate"] == str(expected_fee.quantize(Decimal("0.000001")))
            assert "200,000 gas" in checks["bridge_fee_basis"]
            assert "500000000 wei" in checks["bridge_fee_basis"]
            assert "HYPE oracle $44.0" in checks["bridge_fee_basis"]
            # projected_spot = balance - amount - fee = 10 - 3 - 0.0044 = 6.9956
            expected_projected = (Decimal("10") - Decimal("3") - expected_fee).quantize(Decimal("0.000001"))
            assert checks["projected_spot"] == str(expected_projected)
            assert "next-block" in checks["bridge_fee_note"]

    def test_propose_discloses_when_estimate_unavailable(self, runner, patched):
        """When RPC or oracle is unavailable, the proposal must say so explicitly.

        Silent fallback to a zero-fee projection would mislead the user about their
        post-bridge balance. Disclaimer must include: bridge_fee_estimate='unavailable',
        formula in bridge_fee_basis, projected_spot annotated with '(excludes ...)'.
        """
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.core.rpc_pool.get_web3", side_effect=RuntimeError("RPC unreachable")), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "10.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "3", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True
            checks = d["data"]["checks"]
            assert checks["bridge_fee_estimate"] == "unavailable"
            assert "200,000 gas" in checks["bridge_fee_basis"]
            assert "USDC" in checks["bridge_fee_basis"]
            assert "Could not estimate" in checks["bridge_fee_note"]
            # projected_spot annotated to flag the missing fee deduction
            assert "excludes unestimated bridge fee" in checks["projected_spot"]

    def test_propose_hype_fee_paid_in_hype_no_oracle(self, runner, patched):
        """HYPE bridge: fee paid in HYPE itself, no oracle conversion needed.

        Validates the gas-token-only branch: 200k * baseFee (in wei) / 1e18 = HYPE.
        """
        from decimal import Decimal

        mock_w3 = MagicMock()
        mock_w3.eth.get_block.return_value = {"baseFeePerGas": 1_000_000_000}  # 1 gwei

        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.core.rpc_pool.get_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "HYPE", "balance": "10.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "3", "--token", "HYPE"])
            d = parse(result)
            assert d["ok"] is True
            checks = d["data"]["checks"]
            # Fee = 200_000 * 1e9 / 1e18 = 0.0002 HYPE
            expected_fee = Decimal("0.0002")
            assert checks["bridge_fee_estimate"] == str(expected_fee.quantize(Decimal("0.000001")))
            # No HYPE oracle string for HYPE → HYPE
            assert "HYPE oracle" not in checks["bridge_fee_basis"]
            assert "200,000 gas" in checks["bridge_fee_basis"]

    def test_propose_warns_when_fee_exceeds_remainder(self, runner, patched):
        """If estimated fee > balance - amount, propose adds BRIDGE_FEE_INSUFFICIENT_BALANCE warning.

        This is a soft warning, not a hard block — the estimate has uncertainty
        and the user may still want to attempt the bridge. But the user MUST be
        warned that the bridge will likely fail at execution time.
        """
        # Massive baseFee → large fee that will exceed the remaining balance after a tiny bridge
        mock_w3 = MagicMock()
        mock_w3.eth.get_block.return_value = {"baseFeePerGas": 10_000_000_000_000}  # 10000 gwei

        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.core.rpc_pool.get_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "5.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            patched["info"].all_mids.return_value = {"HYPE": "44.0"}
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True
            warnings = d["data"]["warnings"]
            warning_types = [w["type"] for w in warnings]
            assert "BRIDGE_FEE_INSUFFICIENT_BALANCE" in warning_types

    def test_executor_calls_send_asset(self):
        mock_exchange = MagicMock()
        mock_exchange.send_asset.return_value = {"status": "ok"}

        with patch("regard.venues.hyperliquid.commands.act.get_exchange", return_value=mock_exchange), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.commands.act import execute_spot_bridge_hyperevm
            execute_spot_bridge_hyperevm({
                "sender": "0xSENDER",
                "dest_address": "0x20" + "00" * 19,
                "dest_label": "HYPEREVM_SYSTEM_USDC",
                "recipient_on_evm": "0xSENDER",
                "token": "USDC",
                "sdk_token": "USDC",
                "amount": "5.0",
                "chain": "hyperevm",
                "testnet": False,
            })
            mock_exchange.send_asset.assert_called_once_with(
                "0x20" + "00" * 19, "spot", "spot", "USDC", 5.0
            )


# ---------------------------------------------------------------------------
# Outbound: hypercore perp send
# ---------------------------------------------------------------------------


class TestPerpSend:
    def test_propose_to_label_succeeds(self, runner, patched):
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"):
            patched["info"].post.side_effect = lambda endpoint, payload: (
                {"withdrawable": "100.0"} if payload.get("type") == "clearinghouseState"
                else []
            )
            result = runner.invoke(app, ["hypercore", "perp", "send", "reserve", "5"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["command"] == "perp.send"
            assert d["data"]["params"]["dest_address"] == "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411"

    def test_self_send_blocked(self, runner, patched):
        with patch("regard.commands.address._load_addresses", return_value={
            "myself": {"address": "0xTEST", "chains": ["hypercore"], "added_at": ""},
        }), patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xTEST"):
            patched["info"].post.side_effect = lambda e, p: {"withdrawable": "100.0"}
            result = runner.invoke(app, ["hypercore", "perp", "send", "myself", "1"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "SELF_SEND"

    def test_unified_account_hard_blocked(self, runner, patched):
        """v0.25.1: HL disables usd_transfer when account is in unifiedAccount /
        portfolioMargin mode. Discovered live 2026-05-06: HL returns 'Action
        disabled when unified account is active' at execution. Propose must
        hard-block so the user never approves a doomed proposal — point them
        at `hypercore spot send` which works for all account modes.
        """
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.commands.act.get_account_mode",
                   return_value="unifiedAccount"):
            result = runner.invoke(app, ["hypercore", "perp", "send", "reserve", "5"])
            assert result.exit_code == 2
            d = parse(result)
            assert d["error"]["code"] == "PERP_SEND_DISABLED_UNIFIED_MODE"
            assert "unifiedAccount" in d["error"]["message"]
            assert "hypercore spot send" in d["error"]["hint"]

    def test_portfolio_margin_hard_blocked(self, runner, patched):
        """Same hard block applies to portfolioMargin mode."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.commands.act.get_account_mode",
                   return_value="portfolioMargin"):
            result = runner.invoke(app, ["hypercore", "perp", "send", "reserve", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "PERP_SEND_DISABLED_UNIFIED_MODE"

    def test_executor_calls_usd_transfer(self):
        mock_exchange = MagicMock()
        mock_exchange.usd_transfer.return_value = {"status": "ok"}

        with patch("regard.venues.hyperliquid.commands.act.get_exchange", return_value=mock_exchange), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.commands.act import execute_perp_send
            execute_perp_send({
                "sender": "0xSENDER",
                "dest_address": "0xDEST",
                "dest_label": "test",
                "amount": "5.0",
                "testnet": False,
            })
            mock_exchange.usd_transfer.assert_called_once_with(5.0, "0xDEST")


# ---------------------------------------------------------------------------
# Inbound: arbitrum bridge hypercore
# ---------------------------------------------------------------------------


class TestArbitrumBridgeHypercore:
    def _patch_w3(self, balance_eth: Decimal = Decimal("1.0"), usdc_balance_raw: int = 100_000_000):
        """Build a mocked Web3 + key + sender for inbound tests.

        balance_eth: native ETH balance in tokens (Decimal). 1.0 ETH > hard threshold.
        usdc_balance_raw: ERC-20 USDC balance in raw units (6 decimals — 100M = 100 USDC).
        """
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(balance_eth * Decimal(10**18))
        # `Web3.to_checksum_address` is a static; use a passthrough for the test.
        return sender, mock_w3

    def test_propose_to_self_succeeds(self, runner, patched):
        sender, mock_w3 = self._patch_w3()
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=100_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "5"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["command"] == "bridge.hypercore"
            assert d["data"]["params"]["chain"] == "arbitrum"
            # Bridge2 contract address is the EVM tx target.
            assert d["data"]["params"]["dest_address"] == "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7"
            assert d["data"]["params"]["recipient_on_hl"] == sender

    def test_below_min_deposit_rejected(self, runner, patched):
        """Locked decision 13: amount < 5 USDC must hard-block with MIN_DEPOSIT_NOT_MET."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "4.5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "MIN_DEPOSIT_NOT_MET"

    def test_min_deposit_boundary(self, runner, patched):
        """Exactly 5 USDC should pass the min check."""
        sender, mock_w3 = self._patch_w3()
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=100_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "5"])
            d = parse(result)
            assert d["ok"] is True

    def test_to_other_addr_rejected(self, runner, patched):
        """--to anything other than 'self' must fail (Bridge2 credits sender)."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_RECIPIENT_NOT_SELF"

    def test_source_no_gas_hard_blocks(self, runner, patched):
        """Locked decision 14: 0 ETH on Arbitrum must hard-block at propose time."""
        sender, mock_w3 = self._patch_w3(balance_eth=Decimal("0"))
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_SOURCE_NO_GAS"

    def test_rpc_unreachable_hard_blocks(self, runner, patched):
        """RPC failure on inbound must hard-block (we can't proceed without verifying gas)."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.side_effect = Exception("RPC down")
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "RPC_UNREACHABLE"

    def test_executor_calls_transfer_erc20(self):
        from regard.venues.hyperliquid.bridge_constants import (
            ARB_USDC_CONTRACT,
            HL_BRIDGE2_CONTRACT,
        )

        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_account = MagicMock()
        mock_account.address = sender
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("1.0") * Decimal(10**18))

        with patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.core.evm.transfer_erc20", return_value=b"\x00" * 32) as mock_transfer, \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key", return_value=mock_account), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.inbound_bridge import execute_arbitrum_bridge_hypercore
            result = execute_arbitrum_bridge_hypercore({
                "sender": sender,
                "dest_address": HL_BRIDGE2_CONTRACT,
                "dest_label": "HL_BRIDGE2",
                "recipient_on_hl": sender,
                "token_address": ARB_USDC_CONTRACT,
                "token": "USDC",
                "amount": "5.0",
                "amount_raw": "5000000",
                "chain": "arbitrum",
            })
            mock_transfer.assert_called_once_with(
                mock_w3, mock_account, HL_BRIDGE2_CONTRACT, ARB_USDC_CONTRACT, 5_000_000
            )
            assert result["status"] == "bridged"
            assert result["chain"] == "arbitrum"


# ---------------------------------------------------------------------------
# Inbound: hyperevm bridge hypercore
# ---------------------------------------------------------------------------


class TestHyperevmBridgeHypercore:
    def test_hype_routes_to_native_path(self, runner, patched):
        """--token HYPE: is_native=True, dest is 0x222...2222."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "0.5", "--token", "HYPE"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["params"]["is_native"] is True
            assert d["data"]["params"]["dest_address"] == "0x2222222222222222222222222222222222222222"
            assert d["data"]["params"]["token"] == "HYPE"

    def test_hype_lowercase_normalized(self, runner, patched):
        """--token hype must route to native path (locked decision 15)."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "0.5", "--token", "hype"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["params"]["token"] == "HYPE"
            assert d["data"]["params"]["is_native"] is True

    def test_usdc_routes_to_erc20_path(self, runner, patched):
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        # inbound_bridge.py imports get_info directly from venues.hyperliquid.client,
        # so we patch at that import site (the conftest `patched` fixture doesn't cover it).
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = MOCK_SPOT_META

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=100_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Failed: {d}"
            assert d["data"]["params"]["is_native"] is False
            assert d["data"]["params"]["token"] == "USDC"
            # ERC-20 dest is the system address (0x20 + token_index_bytes).
            assert d["data"]["params"]["dest_address"].startswith("0x20")
            # token_address is the linked HyperEVM ERC-20 contract.
            assert d["data"]["params"]["token_address"] == "0x5555555555555555555555555555555555555555"

    def test_unlinked_token_hard_blocked(self, runner, patched):
        """Token with evmContract: None must hard-block with BRIDGE_TOKEN_NOT_LINKED.

        Patches `regard.venues.hyperliquid.client.get_info` directly because
        inbound_bridge.py imports get_info lazily inside the function body —
        the conftest `patched` fixture only covers `commands.act.get_info`.
        Without this patch, the test makes live API calls (round-3 peer review
        Important #1).
        """
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = _build_mock_spot_meta(include_unlinked=True)

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "LICK"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_TOKEN_NOT_LINKED"

    def test_to_other_addr_rejected(self, runner, patched):
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411", "5", "--token", "USDC"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_RECIPIENT_NOT_SELF"

    # ---------------------------------------------------------------------
    # v0.25.9 — Circle CoreDepositWallet pattern detection + bridge mechanism
    # ---------------------------------------------------------------------
    # USDC.hl's spotMeta.evmContract.address is Circle's CoreDepositWallet
    # bridge contract, NOT the actual ERC-20 token. The bridge exposes a
    # `token()` getter returning the underlying ERC-20 (`0xb88339...` on
    # mainnet). Detection: if `token()` returns a different non-zero address,
    # treat as Circle pattern; balanceOf reads from the inner ERC-20; bridge
    # mechanism is `depositWithAuth` (EIP-3009), not plain `transfer`.

    def _build_call_handler(self, evm_addr, inner_token, name="USD Coin",
                             version="2", paused=False, fresh=False, balance_raw=10_000_000):
        """Build an eth_call side_effect that mimics CoreDepositWallet behavior."""
        from regard.venues.hyperliquid.inbound_bridge import _CORE_USER_EXISTS_PRECOMPILE

        def encode_string(s: str) -> bytes:
            data = s.encode()
            length = len(data)
            offset = (32).to_bytes(32, "big")
            length_bytes = length.to_bytes(32, "big")
            padded = data + b"\x00" * ((32 - (length % 32)) % 32)
            return offset + length_bytes + padded

        def handler(tx, *_args, **_kwargs):
            to = (tx.get("to") or "").lower()
            data = tx.get("data", "")
            if to == evm_addr.lower():
                if data.startswith("0xfc0c546a"):  # token()
                    return bytes.fromhex(inner_token[2:].rjust(64, "0"))
                if data.startswith("0x5c975abb"):  # paused()
                    return (b"\x00" * 31 + (b"\x01" if paused else b"\x00"))
            if to == inner_token.lower():
                if data.startswith("0x70a08231"):  # balanceOf
                    return balance_raw.to_bytes(32, "big")
                if data.startswith("0x06fdde03"):  # name()
                    return encode_string(name)
                if data.startswith("0x54fd4d50"):  # version()
                    return encode_string(version)
            if to == _CORE_USER_EXISTS_PRECOMPILE.lower():
                # exists=true → not fresh; exists=false → fresh
                return (b"\x00" * 32) if fresh else (b"\x00" * 31 + b"\x01")
            return b"\x00" * 32

        return handler

    def test_resolver_detects_circle_pattern(self, patched):
        """`_resolve_hyperevm_erc20` returns is_circle_pattern=True when
        evmContract.address.token() returns a different address."""
        from regard.venues.hyperliquid.inbound_bridge import _resolve_hyperevm_erc20

        # MOCK_SPOT_META has USDC at evmContract.address = 0x5555...5555.
        # Configure mock w3 to make token() return a DIFFERENT address.
        inner_token = "0xb88339cb7199b77e23db6e890353e22632ba630f"
        mock_w3 = MagicMock()
        mock_w3.eth.call.side_effect = self._build_call_handler(
            evm_addr="0x5555555555555555555555555555555555555555",
            inner_token=inner_token,
        )
        mock_info = MagicMock()
        mock_info.spot_meta.return_value = MOCK_SPOT_META

        resolved = _resolve_hyperevm_erc20("USDC", mock_info, mock_w3)
        assert resolved is not None
        assert resolved["is_circle_pattern"] is True
        assert resolved["erc20_address"].lower() == inner_token.lower()
        assert resolved["bridge_address"] == "0x5555555555555555555555555555555555555555"

    def test_resolver_direct_erc20_when_token_call_reverts(self, patched):
        """Direct ERC-20 path: token() reverts, resolver returns
        evmContract.address as BOTH erc20 and bridge."""
        from regard.venues.hyperliquid.inbound_bridge import _resolve_hyperevm_erc20

        mock_w3 = MagicMock()
        mock_w3.eth.call.side_effect = RuntimeError("execution reverted")
        mock_info = MagicMock()
        mock_info.spot_meta.return_value = MOCK_SPOT_META

        resolved = _resolve_hyperevm_erc20("USDH", mock_info, mock_w3)
        assert resolved is not None
        assert resolved["is_circle_pattern"] is False
        assert resolved["erc20_address"] == resolved["bridge_address"]

    def test_usdc_propose_signs_eip3009_auth(self, runner, patched):
        """USDC bridge propose runs the Circle flow: signs an EIP-3009
        receiveWithAuthorization at propose time, stores auth payload in
        params for execute. Balance is read from the inner ERC-20, not the
        CoreDepositWallet."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        bridge_addr = "0x5555555555555555555555555555555555555555"
        inner_token = "0xb88339cb7199b77e23db6e890353e22632ba630f"

        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        mock_w3.eth.chain_id = 999
        mock_w3.eth.call.side_effect = self._build_call_handler(
            evm_addr=bridge_addr, inner_token=inner_token, fresh=False,
            balance_raw=10_000_000,  # 10 USDC at 6 decimals
        )
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = MOCK_SPOT_META

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=10_000_000) as mock_bal, \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            params = d["data"]["params"]
            assert params["is_circle_pattern"] is True
            assert params["bridge_address"] == bridge_addr
            assert params["erc20_address"].lower() == inner_token.lower()
            # Balance read must be against the inner ERC-20, NOT the bridge.
            assert mock_bal.call_args[0][2].lower() == inner_token.lower()
            # EIP-3009 auth payload signed at propose time
            auth = params.get("auth")
            assert auth is not None
            assert auth["v"] in (27, 28)
            assert auth["nonce"].startswith("0x") and len(auth["nonce"]) == 66
            assert auth["valid_before"] > auth["valid_after"]
            # Window must cover the proposal TTL window (24h+5min bound)
            assert auth["valid_before"] >= int(time.time()) + 24 * 3600
            checks = d["data"]["checks"]
            assert checks["bridge_mechanism"] == "CoreDepositWallet.depositWithAuth (EIP-3009)"
            assert checks["bridge_contract"] == bridge_addr
            assert checks["erc20_contract"].lower() == inner_token.lower()

    def test_usdc_propose_fresh_recipient_discloses_account_fee(self, runner, patched):
        """Fresh HyperCore recipient: surface RECIPIENT_FRESH_CORE_ACCOUNT
        warning + accurate `credited_on_hl_spot` (amount minus 1 USDC fee)."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        bridge_addr = "0x5555555555555555555555555555555555555555"
        inner_token = "0xb88339cb7199b77e23db6e890353e22632ba630f"

        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        mock_w3.eth.chain_id = 999
        mock_w3.eth.call.side_effect = self._build_call_handler(
            evm_addr=bridge_addr, inner_token=inner_token, fresh=True,  # NEW account
            balance_raw=10_000_000,
        )
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = MOCK_SPOT_META

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=10_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True
            warning_types = [w["type"] for w in d["data"]["warnings"]]
            assert "RECIPIENT_FRESH_CORE_ACCOUNT" in warning_types
            checks = d["data"]["checks"]
            assert checks["new_core_account_fee"] == "1"
            assert checks["credited_on_hl_spot"] == "4.000000"  # 5 - 1

    def test_usdc_propose_blocks_when_paused(self, runner, patched):
        """If CoreDepositWallet.paused() returns true, propose hard-blocks
        with BRIDGE_PAUSED — don't let the user sign an auth that will
        revert at execute."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        bridge_addr = "0x5555555555555555555555555555555555555555"
        inner_token = "0xb88339cb7199b77e23db6e890353e22632ba630f"

        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        mock_w3.eth.chain_id = 999
        mock_w3.eth.call.side_effect = self._build_call_handler(
            evm_addr=bridge_addr, inner_token=inner_token, paused=True,
        )
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = MOCK_SPOT_META

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "USDC"])
            assert result.exit_code == 4
            assert parse(result)["error"]["code"] == "BRIDGE_PAUSED"

    def test_executor_hype_passes_explicit_gas_limit(self):
        """Locked decision 15: HYPE path MUST pass gas_limit=100_000 explicitly.

        transfer_native's default 21k is insufficient because the system
        contract emits a LOG3 op (~65k gas total). 100k is the safe override.
        Catch any future regression.
        """
        from regard.venues.hyperliquid.bridge_constants import (
            HYPE_BRIDGE_GAS_LIMIT,
            HYPE_SYSTEM_ADDRESS,
        )

        sender_addr = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_account = MagicMock()
        mock_account.address = sender_addr
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))

        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.core.evm.transfer_native", return_value=b"\x00" * 32) as mock_transfer, \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key", return_value=mock_account), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.inbound_bridge import execute_hyperevm_bridge_hypercore
            execute_hyperevm_bridge_hypercore({
                "sender": sender_addr,
                "dest_address": HYPE_SYSTEM_ADDRESS,
                "dest_label": "HYPERCORE_SYSTEM_HYPE",
                "recipient_on_hl": sender_addr,
                "token": "HYPE",
                "token_address": None,
                "is_native": True,
                "amount": "0.5",
                "amount_raw": str(int(Decimal("0.5") * Decimal(10**18))),
                "chain": "hyperevm",
            })
            mock_transfer.assert_called_once_with(
                mock_w3, mock_account, HYPE_SYSTEM_ADDRESS,
                int(Decimal("0.5") * Decimal(10**18)),
                gas_limit=HYPE_BRIDGE_GAS_LIMIT,
            )

    def test_executor_erc20_does_not_pass_gas_limit(self):
        """ERC-20 path uses transfer_erc20's default 100k — no explicit override needed."""
        sender_addr = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_account = MagicMock()
        mock_account.address = sender_addr
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))

        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.core.evm.transfer_erc20", return_value=b"\x00" * 32) as mock_transfer, \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key", return_value=mock_account), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.inbound_bridge import execute_hyperevm_bridge_hypercore
            execute_hyperevm_bridge_hypercore({
                "sender": sender_addr,
                "dest_address": "0x20" + "00" * 19,
                "dest_label": "HYPERCORE_SYSTEM_USDC",
                "recipient_on_hl": sender_addr,
                "token": "USDC",
                "token_address": "0x5555555555555555555555555555555555555555",
                "is_native": False,
                "amount": "5.0",
                "amount_raw": "5000000",
                "chain": "hyperevm",
            })
            mock_transfer.assert_called_once_with(
                mock_w3, mock_account, "0x20" + "00" * 19,
                "0x5555555555555555555555555555555555555555", 5_000_000,
            )


# ---------------------------------------------------------------------------
# Schema regression: real golden spot_meta USDC entry (catches API-shape bugs)
# ---------------------------------------------------------------------------


class TestDecimalArithmeticInvariants:
    """Demonstrates the IEEE 754 cases the Article II Decimal rule prevents.

    Article IV ("Every financial safety rule in Article II MUST have a
    corresponding test") makes these tests load-bearing — the new rule
    needs a test that demonstrates its necessity, not just one that
    verifies the output format change. These tests document the actual
    bug class the rule is designed to prevent.
    """

    def test_decimal_from_string_preserves_precision(self):
        """The bug: Decimal(float_var) carries IEEE 754 representation error.

        For 0.1 — the canonical IEEE 754 unfriendly value — the float
        representation is 0.1000000000000000055511151231257827021181583... .
        When that float is converted to Decimal, the error propagates through
        every downstream multiplication.
        """
        from decimal import Decimal

        # The correct path: string -> Decimal is exact.
        decimal_from_string = Decimal("0.1") * Decimal(10**18)
        assert int(decimal_from_string) == 100000000000000000

        # The dangerous path: float -> Decimal carries IEEE 754 drift.
        decimal_from_float = Decimal(float("0.1")) * Decimal(10**18)
        assert int(decimal_from_float) == 100000000000000005, (
            "If this changes, Python's Decimal(float) representation may have "
            "changed. The rule's premise depends on Decimal(float_var) carrying "
            "float's representation error verbatim."
        )

        # The two paths produce different amount_raw values — exactly the
        # silent drift Article II clause 1 is designed to prevent.
        assert decimal_from_string != decimal_from_float
        assert int(decimal_from_float) - int(decimal_from_string) == 5

    def test_string_intermediary_recovers_safety(self):
        """Decimal(str(float_var)) recovers safety for typical amounts.

        Python's str(float) uses repr-equivalent shortest round-trip
        representation for non-extreme values. `str(0.1) == "0.1"` exactly
        in Python 3, so `Decimal(str(0.1)) == Decimal("0.1")`.
        """
        from decimal import Decimal

        f = float("0.1")
        assert Decimal(str(f)) == Decimal("0.1")

        # The string-intermediary path produces the safe Decimal.
        safe = Decimal(str(f)) * Decimal(10**18)
        assert int(safe) == 100000000000000000

    def test_float_decimal_inequality_for_typical_amounts(self):
        """For 6-decimal USDC and 8-decimal HYPE inputs, the rule still applies.

        Even though `float * 10^N` happens to be exact for these typical
        amounts (verified empirically — see Article 11), the
        `Decimal(float_var)` path is unsafe regardless of magnitude.
        """
        from decimal import Decimal

        # 5.123456 USDC at 6 decimals
        amount_str = "5.123456"
        d_correct = int(Decimal(amount_str) * Decimal(10**6))
        d_unsafe = int(Decimal(float(amount_str)) * Decimal(10**6))
        # For this specific value the two paths happen to agree; but the
        # rule's guarantee is unconditional. Document the safe path:
        assert d_correct == 5123456


class TestHyperevmBalance:
    """`regard hyperevm balance` — read-only HyperEVM-side balance reads.

    Native HYPE goes through `eth_getBalance`; ERC-20 tokens go through the
    same resolver that the inbound bridge uses (`_resolve_token_evm_contract`),
    so Circle pattern detection (USDC) and direct-ERC-20 (USDH/USDT0/USDE/PURR)
    both work through one code path. Exercises:
    - HYPE native balance via wallet-derived default address
    - USDC Circle-pattern resolution (balanceOf hits inner ERC-20, not bridge)
    - USDH direct-ERC-20 path
    - All-tokens listing
    - --address override
    - UNKNOWN_TOKEN / TOKEN_NOT_LINKED / WALLET_REQUIRED error codes
    """

    SENDER = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
    INNER_USDC = "0xb88339cb7199b77e23db6e890353e22632ba630f"
    BRIDGE_USDC = "0x5555555555555555555555555555555555555555"
    DIRECT_USDH = "0x6666666666666666666666666666666666666666"

    def _call_handler(self, *, usdc_balance_raw: int = 0, usdh_balance_raw: int = 0):
        """Return a side_effect for `w3.eth.call` that mimics the
        `token()` getter on USDC's CoreDepositWallet but reverts elsewhere.

        ERC-20 balanceOf is patched at `regard.core.evm.get_erc20_balance` —
        this handler only services the resolver's `token()` probe and any
        other call-shaped accesses.
        """
        usdc_inner_padded = bytes.fromhex(self.INNER_USDC[2:].rjust(64, "0"))

        def handler(tx, *_a, **_kw):
            to = (tx.get("to") or "").lower()
            data = tx.get("data", "")
            if to == self.BRIDGE_USDC.lower() and data.startswith("0xfc0c546a"):
                return usdc_inner_padded  # token() returns inner ERC-20
            if to == self.DIRECT_USDH.lower() and data.startswith("0xfc0c546a"):
                raise RuntimeError("execution reverted: token() not implemented")
            return b"\x00" * 32

        return handler

    def _patches(self, mock_w3, sender_override: str | None = None):
        """Common patch context: wallet → sender, hyperevm web3 mock, info mock."""
        sender = sender_override or self.SENDER
        mock_info = MagicMock()
        mock_info.spot_meta.return_value = MOCK_SPOT_META

        return [
            patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3),
            patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info),
            patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "11" * 32}, clear=False),
            patch("eth_account.Account.from_key",
                  return_value=MagicMock(address=sender)),
        ]

    def test_native_hype_balance(self, runner):
        """`regard hyperevm balance HYPE` reads via eth_getBalance, formats wei→HYPE."""
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = 50_000_000_000_000_000  # 0.05 HYPE
        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=MagicMock(spot_meta=MagicMock(return_value=MOCK_SPOT_META))), \
             patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "11" * 32}, clear=False), \
             patch("eth_account.Account.from_key", return_value=MagicMock(address=self.SENDER)):
            result = runner.invoke(app, ["hyperevm", "balance", "HYPE"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["address"] == self.SENDER
            assert d["data"]["token"] == "HYPE"
            assert d["data"]["is_native"] is True
            assert d["data"]["amount"] == "0.05"
            assert d["data"]["raw"] == "50000000000000000"
            assert d["data"]["wei_decimals"] == 18
            mock_w3.eth.get_balance.assert_called_once_with(self.SENDER)

    def test_usdc_circle_pattern_balance(self, runner):
        """USDC: resolver detects Circle pattern via `token()` getter; balanceOf
        is read from the inner ERC-20 (`0xb88339...`), NOT the CoreDepositWallet
        bridge address. wei_decimals reflects the inner token (8 + (-2) = 6)."""
        mock_w3 = MagicMock()
        mock_w3.eth.call.side_effect = self._call_handler(usdc_balance_raw=3_000_000)

        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=MagicMock(spot_meta=MagicMock(return_value=MOCK_SPOT_META))), \
             patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "11" * 32}, clear=False), \
             patch("eth_account.Account.from_key", return_value=MagicMock(address=self.SENDER)), \
             patch("regard.core.evm.get_erc20_balance", return_value=3_000_000) as mock_bal:
            result = runner.invoke(app, ["hyperevm", "balance", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["token"] == "USDC"
            assert d["data"]["is_native"] is False
            assert d["data"]["amount"] == "3"
            assert d["data"]["raw"] == "3000000"
            assert d["data"]["wei_decimals"] == 6  # 8 + (-2) from evm_extra_wei_decimals
            assert d["data"]["is_circle_pattern"] is True
            assert d["data"]["erc20_address"].lower() == self.INNER_USDC.lower()
            assert d["data"]["bridge_address"].lower() == self.BRIDGE_USDC.lower()
            # balanceOf MUST hit the inner ERC-20, NOT the bridge.
            assert mock_bal.call_args[0][2].lower() == self.INNER_USDC.lower()

    def test_usdh_direct_erc20_balance(self, runner):
        """USDH: resolver's `token()` probe reverts → direct-ERC-20 path.
        erc20_address == bridge_address; is_circle_pattern == False."""
        mock_w3 = MagicMock()
        mock_w3.eth.call.side_effect = self._call_handler()

        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=MagicMock(spot_meta=MagicMock(return_value=MOCK_SPOT_META))), \
             patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "11" * 32}, clear=False), \
             patch("eth_account.Account.from_key", return_value=MagicMock(address=self.SENDER)), \
             patch("regard.core.evm.get_erc20_balance", return_value=50_000_000) as mock_bal:
            # USDH golden weiDecimals=8 + evm_extra_wei_decimals=0 → 8 ERC-20 decimals.
            # 50_000_000 raw → 0.5 USDH at 8 decimals.
            result = runner.invoke(app, ["hyperevm", "balance", "USDH"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["token"] == "USDH"
            assert d["data"]["amount"] == "0.5"
            assert d["data"]["wei_decimals"] == 8
            assert d["data"]["is_circle_pattern"] is False
            assert d["data"]["erc20_address"].lower() == self.DIRECT_USDH.lower()
            assert d["data"]["bridge_address"].lower() == self.DIRECT_USDH.lower()
            assert mock_bal.call_args[0][2].lower() == self.DIRECT_USDH.lower()

    def test_all_tokens_listing_includes_hype_and_linked(self, runner):
        """No token arg → list HYPE (native) + every spot_meta token with an
        evmContract. MOCK_SPOT_META has USDC + USDH linked, HYPE unlinked."""
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = 100_000_000_000_000_000  # 0.1 HYPE
        mock_w3.eth.call.side_effect = self._call_handler()

        # ERC-20 balanceOf returns sentinel-different values per token to verify
        # we read each token's actual balance, not just the same value twice.
        # USDC: weiDecimals=8 + evm_extra=-2 = 6 decimals → 4_000_000 raw = 4 USDC.
        # USDH: weiDecimals=8 + evm_extra=0  = 8 decimals → 100_000_000 raw = 1 USDH.
        balance_by_addr = {
            self.INNER_USDC.lower(): 4_000_000,
            self.DIRECT_USDH.lower(): 100_000_000,
        }

        def fake_balance(_w3, _owner, addr):
            return balance_by_addr.get(addr.lower(), 0)

        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=MagicMock(spot_meta=MagicMock(return_value=MOCK_SPOT_META))), \
             patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "11" * 32}, clear=False), \
             patch("eth_account.Account.from_key", return_value=MagicMock(address=self.SENDER)), \
             patch("regard.core.evm.get_erc20_balance", side_effect=fake_balance):
            result = runner.invoke(app, ["hyperevm", "balance"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["address"] == self.SENDER
            tokens = {b["token"]: b for b in d["data"]["balances"]}
            # HYPE native first, then every linked token.
            assert "HYPE" in tokens
            assert tokens["HYPE"]["is_native"] is True
            assert tokens["HYPE"]["amount"] == "0.1"
            assert "USDC" in tokens
            assert tokens["USDC"]["amount"] == "4"
            assert tokens["USDC"]["is_circle_pattern"] is True
            assert "USDH" in tokens
            assert tokens["USDH"]["amount"] == "1"
            assert tokens["USDH"]["is_circle_pattern"] is False
            assert d["data"]["total"] == 3

    def test_address_override_skips_wallet(self, runner):
        """`--address 0x...` queries that address directly; wallet not consulted."""
        other = "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = 25_000_000_000_000_000  # 0.025 HYPE

        # Critically — clear wallet env to confirm --address works without one.
        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=MagicMock(spot_meta=MagicMock(return_value=MOCK_SPOT_META))), \
             patch.dict("os.environ", {}, clear=True), \
             patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hyperevm", "balance", "HYPE", "--address", other])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["address"] == other  # checksummed override
            assert d["data"]["amount"] == "0.025"
            mock_w3.eth.get_balance.assert_called_once_with(other)

    def test_unknown_token_dies_with_unknown_token(self, runner):
        """Unknown token name → UNKNOWN_TOKEN."""
        mock_w3 = MagicMock()
        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=MagicMock(spot_meta=MagicMock(return_value=MOCK_SPOT_META))), \
             patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "11" * 32}, clear=False), \
             patch("eth_account.Account.from_key", return_value=MagicMock(address=self.SENDER)):
            result = runner.invoke(app, ["hyperevm", "balance", "FAKETOKEN"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "UNKNOWN_TOKEN"

    def test_unlinked_token_dies_with_token_not_linked(self, runner):
        """Token with evmContract: None (e.g. LICK) → TOKEN_NOT_LINKED."""
        mock_w3 = MagicMock()
        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info",
                   return_value=MagicMock(spot_meta=MagicMock(return_value=_build_mock_spot_meta(include_unlinked=True)))), \
             patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "11" * 32}, clear=False), \
             patch("eth_account.Account.from_key", return_value=MagicMock(address=self.SENDER)):
            result = runner.invoke(app, ["hyperevm", "balance", "LICK"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "TOKEN_NOT_LINKED"

    def test_no_wallet_no_address_dies_with_wallet_required(self, runner):
        """No env wallet + no project wallet + no --address → WALLET_REQUIRED."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hyperevm", "balance", "HYPE"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "WALLET_REQUIRED"

    def test_invalid_address_dies_with_invalid_address(self, runner):
        """Malformed `--address` → INVALID_ADDRESS."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hyperevm", "balance", "HYPE", "--address", "not-an-address"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "INVALID_ADDRESS"


class TestEvmContractSchemaRegression:
    """Regression tests against the unmodified golden spot_meta fixture.

    Round-3 peer review (2026-05-05) caught two Critical bugs that the
    previous mock had masked:
    1. `evmContract` is a dict {"address": ..., "evm_extra_wei_decimals": ...},
       not a flat string. Returning the dict broke `to_checksum_address`.
    2. The decimals offset is `evm_extra_wei_decimals` (snake_case) nested
       inside the dict, NOT `evmExtraWeiDecimals` at the token level.

    These tests bind the implementation to the actual golden fixture so any
    future schema drift between mock and reality re-surfaces immediately.
    """

    def test_linked_erc20_returns_address_string_from_golden(self):
        """`_hyperevm_linked_erc20('USDC', info)` must return a string, not a dict."""
        from regard.venues.hyperliquid.inbound_bridge import _hyperevm_linked_erc20
        mock_info = MagicMock()
        # Use the unmodified golden fixture — no overrides.
        mock_info.spot_meta.return_value = _SPOT_GOLDEN
        result = _hyperevm_linked_erc20("USDC", mock_info)
        assert isinstance(result, str), f"Expected str, got {type(result).__name__}: {result!r}"
        assert result.startswith("0x")
        assert len(result) == 42

    def test_evm_contract_for_token_returns_address_string_from_golden(self):
        """Outbound helper: same string-return contract as inbound."""
        from regard.venues.hyperliquid.commands.act import _evm_contract_for_token
        mock_info = MagicMock()
        mock_info.spot_meta.return_value = _SPOT_GOLDEN
        result = _evm_contract_for_token("USDC", mock_info)
        assert isinstance(result, str)
        assert result.startswith("0x")
        assert len(result) == 42

    def test_amount_raw_uses_correct_decimals_from_golden(self, runner, patched):
        """End-to-end: bridging 5 USDC must compute amount_raw with the linked
        ERC-20's actual decimals (Core 8 + extra -2 = EVM 6 decimals = 5_000_000),
        NOT the wrong default that masked the bug.
        """
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = _SPOT_GOLDEN

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=10_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Failed: {d}"
            # 5 USDC at 6 effective decimals = 5_000_000 raw, NOT 500_000_000 (8 decimals)
            # NOR 5_000_000_000_000_000_000 (18 decimals fallback).
            assert d["data"]["params"]["amount_raw"] == "5000000", (
                f"amount_raw is {d['data']['params']['amount_raw']!r} — implementation "
                "is using wrong wei_decimals (should be 8 + -2 = 6)"
            )
            # token_address must be a string (the address from the dict),
            # not a dict (which would fail at to_checksum_address).
            assert isinstance(d["data"]["params"]["token_address"], str)
            assert d["data"]["params"]["token_address"].startswith("0x")


# ---------------------------------------------------------------------------
# CRITICAL gate uses recipient_on_hl, not dest_address (locked decision 18)
# ---------------------------------------------------------------------------


class TestCriticalGateRecipientOnHl:
    """Locked decision 18: when proposal sets recipient_on_hl, gate confirms against it."""

    def test_gate_uses_recipient_on_hl_when_set(self, runner, tmp_path):
        """Approve a CRITICAL bridge with recipient_on_hl: gate checks user EOA, not constant dest."""
        from regard.core.proposal import create_proposal

        # Construct a synthetic CRITICAL-risk bridge proposal where dest_address
        # is the Bridge2 contract (a constant) but recipient_on_hl is the user's
        # actual address.
        proposal = create_proposal(
            "arbitrum", "bridge.hypercore",
            params={
                "sender": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
                "dest_address": "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7",
                "dest_label": "HL_BRIDGE2",
                "recipient_on_hl": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
                "token_address": "0xaf88d065e77c8cC2239327C5EDb3A432268e5831",
                "token": "USDC",
                "amount": "5.0",
                "amount_raw": "5000000",
                "chain": "arbitrum",
            },
            checks={
                "sender": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
                "risk": "CRITICAL",
            },
            warnings=[],
        )

        # Without --confirm-addr the gate should fire; the expected hex
        # comes from recipient_on_hl[2:8], not from dest_address[2:8].
        # User EOA: 0xF373B4... → expected = "f373b4"
        # Bridge2:  0x2df1c5... → would be "2df1c5"
        result = runner.invoke(app, ["approve", proposal["id"]])
        # Print the actual output for debugging if assertion fails.
        d = parse(result)
        assert d["ok"] is False, f"Expected CONFIRM_ADDR_REQUIRED; got: {d}"
        err = d["error"]
        assert err["code"] == "CONFIRM_ADDR_REQUIRED", f"Got: {err}"
        # Either "f373b4" appears (gate uses recipient_on_hl) OR "2df1c5"
        # (gate fell back to dest_address — fix did not apply). The test
        # passes only on the former.
        assert "f373b4" in err["message"].lower(), f"Gate confirmed wrong field: {err['message']}"
        assert "2df1c5" not in err["message"].lower(), f"Gate confirmed dest_address (Bridge2 constant) instead of recipient_on_hl: {err['message']}"


# ---------------------------------------------------------------------------
# session.py regex coverage for new commands
# ---------------------------------------------------------------------------


class TestSessionRegex:
    """Session command extraction must include the 5 new bridge/send commands.

    `_extract_hypercore_command` parses Bash-tool-call entry text where the
    command is embedded as JSON: '"command": "regard hypercore ..."'.
    """

    def _entry(self, cmd: str) -> str:
        return f'Bash: {{"command": "{cmd}"}}'

    def test_extract_perp_bridge_arbitrum(self):
        from regard.commands.session import _extract_hypercore_command
        out = _extract_hypercore_command(self._entry("regard hypercore perp bridge arbitrum --to self 10"))
        assert out == "regard hypercore perp bridge arbitrum --to self 10"

    def test_extract_spot_bridge_hyperevm(self):
        from regard.commands.session import _extract_hypercore_command
        out = _extract_hypercore_command(self._entry("regard hypercore spot bridge hyperevm --to self 5 --token USDC"))
        assert out == "regard hypercore spot bridge hyperevm --to self 5 --token USDC"

    def test_extract_perp_send(self):
        from regard.commands.session import _extract_hypercore_command
        out = _extract_hypercore_command(self._entry("regard hypercore perp send reserve 5"))
        assert out == "regard hypercore perp send reserve 5"
