"""
Run coverage expansion tests on Databricks using an existing job-like approach.
Uploads source + tests to workspace, creates a notebook, runs it as a job.
"""
import base64
import os
import sys
import time
import json
import urllib.request
import urllib.error

env_path = os.path.expanduser("~/.config/burning-cost/databricks.env")
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            os.environ[k] = v

HOST = os.environ["DATABRICKS_HOST"].rstrip("/")
TOKEN = os.environ["DATABRICKS_TOKEN"]


def api(method, path, body=None):
    url = f"{HOST}{path}"
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(
        url, data=data, method=method,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Content-Type": "application/json",
        }
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        raise RuntimeError(f"HTTP {e.code}: {body}") from e


def upload_notebook(path, content):
    encoded = base64.b64encode(content.encode()).decode()
    api("POST", "/api/2.0/workspace/import", {
        "path": path,
        "format": "SOURCE",
        "language": "PYTHON",
        "content": encoded,
        "overwrite": True,
    })


# Build notebook content that installs deps, uploads source, and runs pytest
notebook_content = r'''# Databricks notebook source
import subprocess, sys, shutil, os, tempfile, base64, json

# Install dependencies (insurance-frequency-severity from PyPI + test deps)
result = subprocess.run(
    ["pip", "install", "--quiet",
     "insurance-frequency-severity[neural]",  # gets torch + scipy + numpy etc
     "pytest", "statsmodels"],
    capture_output=True, text=True
)
print("pip install stdout:", result.stdout[-2000:] if result.stdout else "")
print("pip install stderr:", result.stderr[-1000:] if result.stderr else "")
if result.returncode != 0:
    raise RuntimeError(f"pip install failed: {result.stderr[-500:]}")
print("Base deps installed")

# Now install from workspace source (to pick up our new test file)
ws_src = "/Workspace/Users/pricing.frontier@gmail.com/insurance-frequency-severity-src"
dst = "/tmp/ifs-coverage"

if os.path.exists(dst):
    shutil.rmtree(dst)
shutil.copytree(ws_src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
print(f"Copied source to {dst}")

# Install editable so our test file is picked up
result = subprocess.run(
    ["pip", "install", "--quiet", "-e", dst],
    capture_output=True, text=True
)
if result.returncode != 0:
    print("editable install stderr:", result.stderr[-1000:])
    raise RuntimeError("editable install failed")
print("Editable install done")

# Run ONLY the new test file first, then all tests
r = subprocess.run(
    ["python", "-m", "pytest",
     f"{dst}/tests/test_coverage_expansion.py",
     "--tb=short", "-v", "--no-header", "-p", "no:warnings",
     "-p", "no:cacheprovider", "--timeout=120"],
    capture_output=True, text=True, cwd=dst
)

out = r.stdout + ("\nSTDERR:\n" + r.stderr if r.stderr else "")
print(out[-8000:])

# Count results
lines = r.stdout.split("\n")
summary = [l for l in lines if "passed" in l or "failed" in l or "error" in l]
print("\n=== SUMMARY ===")
for l in summary[-5:]:
    print(l)

dbutils.notebook.exit(out[-5000:])
'''

# Upload our project source to workspace
print("Uploading project source to Databricks workspace...")
ws_dir = "/Workspace/Users/pricing.frontier@gmail.com/insurance-frequency-severity-src"

# We need to import the whole directory. Use import-dir via CLI or SDK.
# Since CLI doesn't have ls, let's use the REST API directly to upload key files.

# Upload via Databricks CLI (which supports import-dir)
import subprocess

repo_dir = "/home/ralph/repos/insurance-frequency-severity"

# Use databricks CLI to sync the directory
env = {**os.environ, "DATABRICKS_HOST": HOST + "/", "DATABRICKS_TOKEN": TOKEN}
r = subprocess.run(
    ["databricks", "workspace", "import-dir",
     "--overwrite",
     repo_dir,
     ws_dir],
    capture_output=True, text=True, env=env
)
if r.returncode != 0:
    print("import-dir stderr:", r.stderr[-2000:])
    print("import-dir stdout:", r.stdout[-2000:])
    # May have partial success, continue anyway
else:
    print("import-dir OK:", r.stdout[-500:] if r.stdout else "done")

print(f"Source uploaded to {ws_dir}")

# Upload test notebook
nb_path = "/Workspace/Users/pricing.frontier@gmail.com/ifs-coverage-tests"
print(f"Uploading test notebook to {nb_path}...")
upload_notebook(nb_path, notebook_content)
print("Notebook uploaded")

# Create a job to run it
print("Creating job...")
job_resp = api("POST", "/api/2.1/jobs/create", {
    "name": "ifs-coverage-expansion-tests",
    "tasks": [{
        "task_key": "run_tests",
        "notebook_task": {
            "notebook_path": nb_path,
            "source": "WORKSPACE",
        },
        "environments": [{"environment_key": "default"}],
        "environment_key": "default",
    }],
    "environments": [{
        "environment_key": "default",
        "spec": {
            "client": "1",
            "dependencies": [],
        }
    }],
    "queue": {"enabled": True},
})
job_id = job_resp["job_id"]
print(f"Job created: {job_id}")

# Trigger a run
print("Triggering run...")
run_resp = api("POST", "/api/2.1/jobs/run-now", {"job_id": job_id})
run_id = run_resp["run_id"]
print(f"Run ID: {run_id}")
print(f"URL: {HOST}/#job/{job_id}/run/{run_id}")

# Poll
print("\nPolling for completion...")
while True:
    run = api("GET", f"/api/2.1/jobs/runs/get?run_id={run_id}")
    state = run.get("state", {})
    lc = state.get("life_cycle_state", "?")
    rs = state.get("result_state", "")
    print(f"  [{time.strftime('%H:%M:%S')}] {lc} / {rs}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break
    time.sleep(20)

print("\n=== Fetching output ===")
tasks = run.get("tasks", [])
success = False
if tasks:
    task_run_id = tasks[0]["run_id"]
    out = api("GET", f"/api/2.1/jobs/runs/get-output?run_id={task_run_id}")
    nb_out = out.get("notebook_output", {})
    if nb_out.get("result"):
        print("NOTEBOOK RESULT:")
        print(nb_out["result"])
    logs = out.get("logs", "")
    if logs:
        print("LOGS (last 4000):")
        print(logs[-4000:])
    error = out.get("error", "")
    if error:
        print("ERROR:", error)
    trace = out.get("error_trace", "")
    if trace:
        print("TRACE:", trace[-2000:])

result_state = state.get("result_state", "")
success = (result_state == "SUCCESS")
print(f"\n=== TEST {'PASSED' if success else 'FAILED'} (result={result_state}) ===")

# Clean up job
print(f"Deleting job {job_id}...")
api("POST", "/api/2.1/jobs/delete", {"job_id": job_id})

sys.exit(0 if success else 1)
