"""
Run coverage expansion tests on Databricks.
Uploads only the essential source files (not .git), then creates a job.
"""
import base64
import os
import sys
import time
import json
import urllib.request
import urllib.error

env_path = os.path.expanduser("~/.config/burning-cost/databricks.env")
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            os.environ[k] = v

HOST = os.environ["DATABRICKS_HOST"].rstrip("/")
TOKEN = os.environ["DATABRICKS_TOKEN"]


def api(method, path, body=None):
    url = f"{HOST}{path}"
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(
        url, data=data, method=method,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Content-Type": "application/json",
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body_text = e.read().decode()
        raise RuntimeError(f"HTTP {e.code}: {body_text}") from e


def upload_file(workspace_path, local_path):
    with open(local_path, "rb") as f:
        content = f.read()
    encoded = base64.b64encode(content).decode()
    api("POST", "/api/2.0/workspace/import", {
        "path": workspace_path,
        "format": "AUTO",
        "content": encoded,
        "overwrite": True,
    })


def mkdirs(path):
    try:
        api("POST", "/api/2.0/workspace/mkdirs", {"path": path})
    except Exception:
        pass  # may already exist


repo_dir = "/home/ralph/repos/insurance-frequency-severity"
ws_base = "/Workspace/Users/pricing.frontier@gmail.com/ifs-test-src"

# Files to upload (relative to repo_dir)
files_to_upload = []

# src/ tree
import os
for dirpath, dirnames, filenames in os.walk(os.path.join(repo_dir, "src")):
    # Exclude __pycache__
    dirnames[:] = [d for d in dirnames if d != "__pycache__"]
    for fn in filenames:
        if fn.endswith(".py") or fn.endswith(".typed"):
            local = os.path.join(dirpath, fn)
            rel = os.path.relpath(local, repo_dir)
            files_to_upload.append(rel)

# tests/ tree
for dirpath, dirnames, filenames in os.walk(os.path.join(repo_dir, "tests")):
    dirnames[:] = [d for d in dirnames if d != "__pycache__"]
    for fn in filenames:
        if fn.endswith(".py"):
            local = os.path.join(dirpath, fn)
            rel = os.path.relpath(local, repo_dir)
            files_to_upload.append(rel)

# pyproject.toml
files_to_upload.append("pyproject.toml")

print(f"Uploading {len(files_to_upload)} files to {ws_base}...")

# Create all directories
dirs_created = set()
for rel in files_to_upload:
    d = os.path.dirname(rel)
    parts = []
    while d:
        parts.append(d)
        d = os.path.dirname(d)
    for p in reversed(parts):
        ws_p = f"{ws_base}/{p}"
        if ws_p not in dirs_created:
            mkdirs(ws_p)
            dirs_created.add(ws_p)

for rel in files_to_upload:
    local = os.path.join(repo_dir, rel)
    ws_path = f"{ws_base}/{rel}"
    # For Python notebooks, workspace strips .py — we want raw files
    # Use format AUTO which detects notebook vs raw
    try:
        upload_file(ws_path, local)
        print(f"  OK: {rel}")
    except Exception as e:
        print(f"  FAIL: {rel}: {e}")

print("Upload complete")

# Build notebook that installs from PyPI then patches with our new test file
# We need to embed the test file content directly into the notebook since
# the workspace import may convert .py files to notebooks
with open(f"{repo_dir}/tests/test_coverage_expansion.py") as f:
    test_file_content = f.read()

# Escape for embedding in Python string
test_file_escaped = test_file_content.replace("\\", "\\\\").replace('"""', '\\"\\"\\"').replace("'''", "\\'\\'\\'")

notebook_content = f'''# Databricks notebook source
import subprocess, sys, shutil, os, tempfile

# Install the published package plus test deps
result = subprocess.run(
    ["pip", "install", "--quiet",
     "insurance-frequency-severity[neural]",
     "pytest", "pytest-timeout", "statsmodels"],
    capture_output=True, text=True
)
print("pip install stderr:", result.stderr[-500:] if result.stderr else "")
if result.returncode != 0:
    print("pip stdout:", result.stdout[-500:])
    raise RuntimeError(f"pip install failed")
print("Deps installed")

# Write the new test file to a temp location
import importlib, site
site_pkgs = site.getsitepackages()[0]
pkg_dir = os.path.join(site_pkgs, "insurance_frequency_severity")
print(f"Package at: {{pkg_dir}}")

# Write test file to /tmp and run from there
test_dir = "/tmp/ifs_tests"
os.makedirs(test_dir, exist_ok=True)

# Write test_coverage_expansion.py
test_content = {repr(test_file_content)}
with open(f"{{test_dir}}/test_coverage_expansion.py", "w") as f:
    f.write(test_content)

# Write a minimal conftest.py
conftest = """
import numpy as np
import pytest

RNG_SEED = 42

@pytest.fixture(scope="session")
def rng():
    return np.random.default_rng(RNG_SEED)
"""
with open(f"{{test_dir}}/conftest.py", "w") as f:
    f.write(conftest)

print(f"Test files written to {{test_dir}}")

# Run the new tests only
r = subprocess.run(
    ["python", "-m", "pytest",
     f"{{test_dir}}/test_coverage_expansion.py",
     "--tb=short", "-v", "--no-header",
     "-p", "no:warnings", "-p", "no:cacheprovider",
     "--timeout=120"],
    capture_output=True, text=True,
    cwd=test_dir,
)

out = r.stdout + ("\\nSTDERR:\\n" + r.stderr[:2000] if r.stderr else "")
print(out[-8000:])

# Parse summary
lines = out.split("\\n")
summary_lines = [l for l in lines if "passed" in l or "failed" in l or "error" in l or "====" in l]
print("\\n=== FINAL SUMMARY ===")
for l in summary_lines[-10:]:
    print(l)

dbutils.notebook.exit(out[-5000:])
'''

# Upload the test notebook
nb_path = "/Workspace/Users/pricing.frontier@gmail.com/ifs-coverage-expansion-nb"
print(f"Uploading test notebook to {nb_path}...")
encoded = base64.b64encode(notebook_content.encode()).decode()
api("POST", "/api/2.0/workspace/import", {
    "path": nb_path,
    "format": "SOURCE",
    "language": "PYTHON",
    "content": encoded,
    "overwrite": True,
})
print("Notebook uploaded")

# Create the job
print("Creating job...")
job_resp = api("POST", "/api/2.1/jobs/create", {
    "name": "ifs-coverage-expansion-tests-v2",
    "tasks": [{
        "task_key": "run_tests",
        "notebook_task": {
            "notebook_path": nb_path,
            "source": "WORKSPACE",
        },
        "environment_key": "default",
    }],
    "environments": [{
        "environment_key": "default",
        "spec": {"client": "1", "dependencies": []},
    }],
    "queue": {"enabled": True},
})
job_id = job_resp["job_id"]
print(f"Job created: {job_id}")

# Trigger run
run_resp = api("POST", "/api/2.1/jobs/run-now", {"job_id": job_id})
run_id = run_resp["run_id"]
print(f"Run ID: {run_id}")
print(f"URL: {HOST}/#job/{job_id}/run/{run_id}")

# Poll
print("\nPolling for completion...")
while True:
    run = api("GET", f"/api/2.1/jobs/runs/get?run_id={run_id}")
    state = run.get("state", {})
    lc = state.get("life_cycle_state", "?")
    rs = state.get("result_state", "")
    print(f"  [{time.strftime('%H:%M:%S')}] {lc} / {rs}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break
    time.sleep(20)

print("\n=== Fetching output ===")
tasks = run.get("tasks", [])
success = False
if tasks:
    task_run_id = tasks[0]["run_id"]
    out = api("GET", f"/api/2.1/jobs/runs/get-output?run_id={task_run_id}")
    nb_out = out.get("notebook_output", {})
    if nb_out.get("result"):
        print("NOTEBOOK RESULT:")
        print(nb_out["result"])
    logs = out.get("logs", "")
    if logs:
        print("LOGS (last 3000):")
        print(logs[-3000:])
    error = out.get("error", "")
    if error:
        print("ERROR:", error)
    trace = out.get("error_trace", "")
    if trace:
        print("TRACE:", trace[-1500:])

result_state = state.get("result_state", "")
success = (result_state == "SUCCESS")
print(f"\n=== TEST {'PASSED' if success else 'FAILED'} (result={result_state}) ===")

# Clean up
try:
    api("POST", "/api/2.1/jobs/delete", {"job_id": job_id})
    print(f"Job {job_id} deleted")
except Exception:
    pass

sys.exit(0 if success else 1)
