# -*- coding: utf-8 -*-
__version__ = '1.6'

kwebsinfo={}
kwebsinfo['name']='kwebs'                             #项目的名称
kwebsinfo['version']=__version__							#项目版本
kwebsinfo['description']='kwebs作为web开发而设计的高性能框架'       #项目的简单描述
kwebsinfo['long_description']='kwebs作为web开发而设计的高性能框架，采用全新的架构思想，注重易用性。遵循MIT开源许可协议发布，意味着个人和企业可以免费使用kwebs，甚至允许把你基于kwebs开发的应用开源或商业产品发布或销售。完整文档请访问：https://docs.kwebapp.cn/index/index/2'     #项目详细描述
kwebsinfo['license']='MIT License'                    #开源协议   mit开源
kwebsinfo['url']='https://docs.kwebapp.cn/index/index/2'
kwebsinfo['author']='百里-坤坤'  					 #名字
kwebsinfo['author_email']='kcweb@kwebapp.cn' 	     #邮件地址
kwebsinfo['maintainer']='坤坤' 						 #维护人员的名字
kwebsinfo['maintainer_email']='fk1402936534@qq.com'    #维护人员的邮件地址
kwebsinfo['username']=''
kwebsinfo['password']=''