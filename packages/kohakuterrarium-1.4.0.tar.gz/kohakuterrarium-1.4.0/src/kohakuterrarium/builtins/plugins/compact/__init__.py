"""Compact plugins."""
