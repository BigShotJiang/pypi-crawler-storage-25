"""Handle installation events — created, deleted, suspend, unsuspend."""

from __future__ import annotations

import logging

from canon import analytics

from . import fire_and_forget
from .onboarding import onboard_repos

logger = logging.getLogger(__name__)


def _get_app_state():
    """Import app and return its state. Returns None if unavailable."""
    try:
        from canon.main import app

        return app.state
    except Exception:
        return None


async def on_installation(client, payload: dict, *, _app_state=None) -> None:
    """Handle a GitHub App installation event.

    Args:
        client: GitHubClient instance (scoped to the installation).
        payload: The webhook payload.
        _app_state: Injected app state (for testing). Falls back to main app.
    """
    action = payload.get("action", "")
    installation = payload.get("installation", {})
    installation_id = installation.get("id", 0)
    account = installation.get("account", {})
    org_login = account.get("login", "")
    org_id = account.get("id", 0)
    app_id = str(installation.get("app_id", ""))

    logger.info(
        "installation event: action=%s org=%s installation_id=%s",
        action,
        org_login,
        installation_id,
    )

    state = _app_state or _get_app_state()
    if state is None:
        logger.warning("Could not access app state for installation event")
        return

    registry = getattr(state, "registry", None)
    if registry is None:
        logger.info("No registry available — skipping installation event")
        return

    if action == "created":
        await registry.upsert_installation(
            installation_id=installation_id,
            org_login=org_login,
            org_id=org_id,
            app_id=app_id,
        )
        logger.info("Registered installation %s for %s", installation_id, org_login)

        analytics.group("organization", org_login, {"installation_id": installation_id})
        analytics.track(
            "app_installed",
            properties={"org": org_login, "installation_id": installation_id},
            groups={"organization": org_login},
        )

        # Schedule background indexing
        indexer = getattr(state, "indexer", None)
        search_index = getattr(state, "search_index", None)
        embed_client = getattr(state, "embed_client", None)

        if indexer is not None and search_index is not None:
            indexer.schedule_org_index(
                installation_id=installation_id,
                org_login=org_login,
                client=client,
                search_index=search_index,
                embed_client=embed_client,
                registry=registry,
            )
            logger.info("Scheduled background indexing for %s", org_login)

        # Auto-provision Auth0 org (fire-and-forget — don't block webhook)
        provider = getattr(state, "oidc_provider", None)
        if provider and hasattr(provider, "create_organization"):
            fire_and_forget(_provision_auth0_org(provider, registry, installation_id, org_login))

        # Schedule background onboarding (repos are already in the payload)
        repos = payload.get("repositories", [])
        if repos:
            fire_and_forget(onboard_repos(client, repos))

    elif action == "deleted":
        # Disable Auth0 org connections (fire-and-forget)
        provider = getattr(state, "oidc_provider", None)
        if provider and hasattr(provider, "disable_org_connections"):
            installation = await registry.get_installation_by_id(installation_id)
            if installation and installation.oidc_org_id:
                fire_and_forget(provider.disable_org_connections(installation.oidc_org_id))

        await registry.mark_removed(installation_id)
        logger.info("Marked installation %s as removed", installation_id)

        analytics.track(
            "app_uninstalled",
            properties={"org": org_login, "installation_id": installation_id},
            groups={"organization": org_login},
        )

    elif action == "suspend":
        await registry.mark_suspended(installation_id)
        logger.info("Marked installation %s as suspended", installation_id)

    elif action == "unsuspend":
        await registry.mark_unsuspended(installation_id)
        logger.info("Marked installation %s as unsuspended", installation_id)


async def _provision_auth0_org(provider, registry, installation_id: int, org_login: str) -> None:
    """Create an Auth0 Organization and link it to the installation.

    Idempotent: reuses an existing Auth0 org if one already exists for this org_login.
    """
    try:
        org_name = org_login.lower()
        # Reuse existing org if present (handles reinstalls and partial failures)
        org_id = await provider.get_organization_by_name(org_name)
        if org_id:
            logger.info("Reusing existing Auth0 org %s for %s", org_id, org_login)
        else:
            org_id = await provider.create_organization(name=org_name, display_name=org_login)
        # Always enable connections — idempotent (409 ignored), fixes reinstall
        # after uninstall where disable_org_connections stripped them.
        github_conn_id = await provider.get_connection_by_name("github")
        db_conn_id = await provider.get_connection_by_name("Username-Password-Authentication")
        await provider.enable_org_connections(org_id, github_conn_id, db_conn_id)
        await registry.set_oidc_org_id(installation_id, org_id)
        logger.info("Provisioned Auth0 org %s for installation %s", org_id, installation_id)
    except Exception:
        logger.exception("Failed to provision Auth0 org for installation %s", installation_id)
