"""Google Search resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.google_search import (
    GoogleSearchAIModeResponse,
    GoogleSearchAIOverviewResponse,
    GoogleSearchImagesResponse,
    GoogleSearchNewsResponse,
    GoogleSearchShoppingResponse,
    GoogleSearchWebResponse,
)



class GoogleSearchResource:
    """Resource for Google Search operations.

    Search the web using Google - includes web results, news, images,
    shopping, and AI features.

    Example:
        # Web search
        results = client.google_search.web(
            query="best seo tools",
            max_results=10,
        )

        # News search
        results = client.google_search.news(
            query="AI technology",
            country="us",
        )

        # Image search
        results = client.google_search.images(
            query="modern website design",
        )

        for result in results.results:
            print(f"{result.title}: {result.url}")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def web(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
        language: Optional[str] = None,
    ) -> GoogleSearchWebResponse:
        """Search the web using Google.

        Returns organic results (with sitelinks when present) plus classic SERP
        surfaces when Google includes them for the query: featured snippet
        (answer_box), People Also Ask (related_questions), knowledge panel
        (knowledge_graph), local pack (local_results), inline images / videos /
        top stories, inline AI Overview (ai_overview), and related_searches.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').
            language: ISO 639-1 language code (e.g., 'en', 'de', 'fr').

        Returns:
            GoogleSearchWebResponse with organic results and any SERP features
            present for the query.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country
        if language is not None:
            payload["language"] = language

        data = self._http.post("/google-search/web", json=payload)
        return GoogleSearchWebResponse.model_validate(data)

    def news(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
        language: Optional[str] = None,
    ) -> GoogleSearchNewsResponse:
        """Search Google News.

        Returns news articles matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').
            language: ISO 639-1 language code (e.g., 'en', 'de', 'fr').

        Returns:
            GoogleSearchNewsResponse with news results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country
        if language is not None:
            payload["language"] = language

        data = self._http.post("/google-search/news", json=payload)
        return GoogleSearchNewsResponse.model_validate(data)

    def images(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> GoogleSearchImagesResponse:
        """Search Google Images.

        Returns image results matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            GoogleSearchImagesResponse with image results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/google-search/images", json=payload)
        return GoogleSearchImagesResponse.model_validate(data)

    def shopping(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> GoogleSearchShoppingResponse:
        """Search Google Shopping.

        Returns shopping/product results matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            GoogleSearchShoppingResponse with shopping results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/google-search/shopping", json=payload)
        return GoogleSearchShoppingResponse.model_validate(data)

    def ai_overview(
        self,
        query: str,
        *,
        country: Optional[str] = None,
        language: Optional[str] = None,
    ) -> GoogleSearchAIOverviewResponse:
        """Fetch Google's inline AI Overview block.

        This returns the AI summary that sometimes appears above the organic
        results on a regular Google SERP — i.e. what Google considers
        suitable for a generative answer. For Google's standalone AI Mode
        product (a different surface with conversational responses), see
        :meth:`ai_mode`.

        Args:
            query: The search query to execute.
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').
            language: ISO 639-1 language code (e.g., 'en', 'de', 'fr').

        Returns:
            GoogleSearchAIOverviewResponse with AI-generated answer and sources.
        """
        payload: dict[str, object] = {"query": query}
        if country is not None:
            payload["country"] = country
        if language is not None:
            payload["language"] = language

        data = self._http.post("/google-search/ai-overview", json=payload)
        return GoogleSearchAIOverviewResponse.model_validate(data)

    def ai_mode(
        self,
        query: str,
        *,
        country: Optional[str] = None,
        language: Optional[str] = None,
    ) -> GoogleSearchAIModeResponse:
        """Query Google's dedicated AI Mode product (the udm=50 surface).

        AI Mode is Google's conversational AI tab — a separate product from
        the inline AI Overview block. It returns a richer payload than
        :meth:`ai_overview`: a `markdown` field with the full answer rendered
        as markdown, plus structured `text_blocks` and `references`.

        Args:
            query: The search query to execute.
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').
            language: ISO 639-1 language code (e.g., 'en', 'de', 'fr').

        Returns:
            GoogleSearchAIModeResponse with markdown answer, structured text
            blocks, and cited references.
        """
        payload: dict[str, object] = {"query": query}
        if country is not None:
            payload["country"] = country
        if language is not None:
            payload["language"] = language

        data = self._http.post("/google-search/ai-mode", json=payload)
        return GoogleSearchAIModeResponse.model_validate(data)
