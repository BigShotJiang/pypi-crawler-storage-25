"""Bing Search resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.bing_search import BingSearchWebResponse


class BingSearchResource:
    """Resource for Bing Search operations.

    Only Bing web search is supported. (Bing News/Images/Videos/Shopping/Copilot
    are not available because the SERP backend does not surface them.)

    Example:
        results = client.bing_search.web(
            query="best seo tools",
            max_results=10,
        )

        for result in results.results:
            print(f"{result.title}: {result.url}")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def web(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> BingSearchWebResponse:
        """Search the web using Bing.

        Returns organic results (with sitelinks when present) plus the SERP
        surfaces Bing includes for the query: answer box, People Also Ask
        (related_questions), and related_searches.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            BingSearchWebResponse with organic results and any SERP features
            present for the query.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/bing-search/web", json=payload)
        return BingSearchWebResponse.model_validate(data)
