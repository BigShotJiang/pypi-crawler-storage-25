"""Skills resource for Agent Berlin SDK.

CRUD over the calling user's own skills, plus read-only access to the
curated system catalog. A skill is a markdown playbook (a prompt, rubric,
strategy, etc.) saved for reuse.
"""

from typing import Any, Dict, List, Literal, Optional

from .._http import HTTPClient
from ..models.skills import Skill, SkillListResponse

Scope = Literal["user", "system"]


class SkillsResource:
    """Resource for managing skills.

    Example:
        my_skills = client.skills.list()
        for s in my_skills:
            print(f"{s.id}: {s.name}")

        # Browse the curated catalog instead.
        catalog = client.skills.list(scope="system")

        new = client.skills.create(name="Backlink audit", details="...markdown...")
        client.skills.update(new.id, name="Backlink audit v2")
        client.skills.delete(new.id)
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self, *, scope: Scope = "user") -> List[Skill]:
        """Return skills owned by the calling user (default), or the system catalog."""
        data = self._http.post("/skills/list", json={"scope": scope})
        return SkillListResponse.model_validate(data).skills

    def get(self, id: str, *, scope: Scope = "user") -> Skill:
        """Fetch a single skill by ID.

        Raises:
            AgentBerlinNotFoundError: If the ID does not match a skill in
                the requested scope (or the user does not own the row).
        """
        data = self._http.post("/skills/get", json={"id": id, "scope": scope})
        return Skill.model_validate(data)

    def create(self, *, name: str, details: str) -> Skill:
        """Save a new skill owned by the calling user."""
        data = self._http.post("/skills/create", json={"name": name, "details": details})
        return Skill.model_validate(data)

    def update(
        self,
        id: str,
        *,
        name: Optional[str] = None,
        details: Optional[str] = None,
    ) -> Skill:
        """Partial update of one of the caller's skills.

        Pass either or both of ``name`` / ``details``. Raises a ValueError
        if both are None.
        """
        if name is None and details is None:
            raise ValueError("update requires at least one of name, details")
        body: Dict[str, Any] = {"id": id}
        if name is not None:
            body["name"] = name
        if details is not None:
            body["details"] = details
        data = self._http.post("/skills/update", json=body)
        return Skill.model_validate(data)

    def delete(self, id: str) -> None:
        """Delete one of the caller's skills.

        Raises:
            AgentBerlinNotFoundError: If the ID does not match a skill
                owned by the caller.
        """
        self._http.post("/skills/delete", json={"id": id})
