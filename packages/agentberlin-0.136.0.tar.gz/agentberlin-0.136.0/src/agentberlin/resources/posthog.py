"""PostHog resource for Agent Berlin SDK."""

import json
from typing import Any, Dict

from .._http import HTTPClient
from ..models.posthog import PostHogQueryResponse
from ..utils import get_project_domain


class PostHogResource:
    """Resource for PostHog product & web analytics.

    Exposes a single generic `query()` method that forwards a PostHog query
    body to PostHog's /api/projects/:id/query/ endpoint. Any query `kind` that
    PostHog supports works without backend changes — `HogQLQuery`, `TrendsQuery`,
    `FunnelsQuery`, `RetentionQuery`, etc.

    Example — top pages by pageviews (HogQL):
        result = client.posthog.query({
            "kind": "HogQLQuery",
            "query": (
                "SELECT properties.$pathname AS path, count() AS pageviews "
                "FROM events WHERE event = '$pageview' "
                "AND timestamp >= now() - INTERVAL 30 DAY "
                "GROUP BY path ORDER BY pageviews DESC LIMIT 20"
            ),
        })
        for row in result.result.get("results", []):
            path, pageviews = row[0], row[1]
            print(f"{path}: {pageviews}")

    Example — daily active users trend (TrendsQuery):
        result = client.posthog.query({
            "kind": "TrendsQuery",
            "series": [{"event": "$pageview", "math": "dau"}],
            "dateRange": {"date_from": "-30d"},
        })
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def query(self, query: Dict[str, Any]) -> PostHogQueryResponse:
        """Run a query against the connected PostHog project.

        Args:
            query: The PostHog query body (the *inner* object, not wrapped in
                {"query": ...}). Must include a "kind" field — one of:
                "HogQLQuery", "TrendsQuery", "FunnelsQuery", "RetentionQuery",
                "EventsQuery", "PathsQuery", ... See PostHog's docs for shape.

        Returns:
            PostHogQueryResponse with a `result` dict mirroring PostHog's raw
            response. Shape depends on the query kind you sent.

        Raises:
            ValueError: If `query` is empty or missing a "kind" field.
            AgentBerlinNotFoundError: If no PostHog integration is connected.
            AgentBerlinAPIError: If PostHog rejects the query or returns an error.
        """
        if not query:
            raise ValueError("query is required")
        if "kind" not in query:
            raise ValueError("query must include a 'kind' field (e.g. 'HogQLQuery')")

        project_domain = get_project_domain()
        payload: Dict[str, Any] = {
            "project_domain": project_domain,
            "query": query,
        }

        data = self._http.post("/posthog/query", json=payload)

        raw_result = data.get("result")
        if isinstance(raw_result, (bytes, bytearray)):
            raw_result = raw_result.decode("utf-8")
        if isinstance(raw_result, str):
            try:
                raw_result = json.loads(raw_result)
            except json.JSONDecodeError:
                raw_result = {"raw": raw_result}
        if not isinstance(raw_result, dict):
            raw_result = {}

        return PostHogQueryResponse(result=raw_result)
