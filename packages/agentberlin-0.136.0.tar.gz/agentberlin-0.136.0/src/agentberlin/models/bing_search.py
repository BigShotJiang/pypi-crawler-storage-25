"""Pydantic models for Bing Search API responses."""

from typing import List, Optional

from pydantic import BaseModel, Field


class BingSearchSitelink(BaseModel):
    """Sub-link listed under a Bing organic result."""

    title: str
    link: str
    snippet: Optional[str] = None


class BingSearchResult(BaseModel):
    """Single search result from Bing Search."""

    title: str
    url: str
    snippet: str
    displayed_link: Optional[str] = None
    date: Optional[str] = None
    sitelinks: List[BingSearchSitelink] = Field(default_factory=list)


class BingSearchMetadata(BaseModel):
    """Metadata about the Bing search."""

    id: Optional[str] = None
    status: Optional[str] = None
    total_time_taken: Optional[float] = None


class BingSearchAnswerBox(BaseModel):
    """Featured snippet / direct answer shown above Bing organic results."""

    type: Optional[str] = None
    title: Optional[str] = None
    answer: Optional[str] = None
    snippet: Optional[str] = None
    link: Optional[str] = None
    displayed_link: Optional[str] = None
    list: List[str] = Field(default_factory=list)


class BingSearchRelatedQuestion(BaseModel):
    """Single entry in the 'People Also Ask' box on Bing."""

    question: str
    snippet: Optional[str] = None
    title: Optional[str] = None
    link: Optional[str] = None
    displayed_link: Optional[str] = None


class BingSearchRelatedSearch(BaseModel):
    """Single 'Related searches' suggestion from Bing."""

    query: str
    link: Optional[str] = None


class BingSearchWebResponse(BaseModel):
    """Response for Bing web search (organic results + SERP features).

    Non-organic surfaces (answer_box, related_questions, related_searches)
    are populated only when Bing actually returned them for the query; absent
    otherwise.
    """

    query: str
    results: List[BingSearchResult] = Field(default_factory=list)
    total: int
    answer_box: Optional[BingSearchAnswerBox] = None
    related_questions: List[BingSearchRelatedQuestion] = Field(default_factory=list)
    related_searches: List[BingSearchRelatedSearch] = Field(default_factory=list)
    search_metadata: Optional[BingSearchMetadata] = None
