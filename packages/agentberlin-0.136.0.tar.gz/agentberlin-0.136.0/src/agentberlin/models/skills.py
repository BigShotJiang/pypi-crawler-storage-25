"""Pydantic models for the Skills API."""

from typing import List

from pydantic import BaseModel


class Skill(BaseModel):
    """A single skill — a markdown playbook the user has saved for reuse."""

    id: str
    name: str
    details: str


class SkillListResponse(BaseModel):
    """Wire shape for POST /skills/list."""

    skills: List[Skill]
