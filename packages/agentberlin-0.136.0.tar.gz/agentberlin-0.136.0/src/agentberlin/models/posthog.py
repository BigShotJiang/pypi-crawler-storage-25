"""Pydantic models for PostHog API responses."""

from typing import Any, Dict

from pydantic import BaseModel, Field


class PostHogQueryResponse(BaseModel):
    """Response from posthog.query().

    Wraps PostHog's raw query response. The exact shape depends on the query
    `kind` you sent:
      - HogQLQuery → `result` typically contains `results`, `columns`, `types`,
        `hogql`, `query`, `timings`, `is_cached`, ...
      - TrendsQuery → `result.results` is a list of series with `data`, `labels`, ...
      - FunnelsQuery → `result.results` describes step-by-step conversion.
      - RetentionQuery → `result.results` is the retention cohort table.

    Because the shape is polymorphic, `result` is exposed as a loose dict.
    Callers parse it according to the query they sent.
    """

    result: Dict[str, Any] = Field(
        default_factory=dict,
        description="Raw PostHog response body. Shape depends on query kind.",
    )
