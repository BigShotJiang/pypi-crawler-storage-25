"""Pydantic models for brand profile API responses."""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class Topic(BaseModel):
    """A topic with value and page URLs."""

    value: str
    pillar_page_url: Optional[str] = None
    landing_page_url: Optional[str] = None


class BrandProfileResponse(BaseModel):
    """Brand profile configuration for a project."""

    domain: str
    name: str
    brand_context: Optional[str] = None
    domain_authority: int
    competitors: List[str] = Field(default_factory=list)
    industries: List[str] = Field(default_factory=list)
    business_models: List[str] = Field(default_factory=list)
    company_size: str
    target_customer_segments: List[str] = Field(default_factory=list)
    geographies: List[str] = Field(default_factory=list)
    topics: List[Topic] = Field(default_factory=list)
    sitemaps: List[str] = Field(default_factory=list)
    profile_urls: List[str] = Field(default_factory=list)


class BrandProfileUpdateResponse(BaseModel):
    """Response for brand profile update."""

    success: bool
    profile: BrandProfileResponse


# ---------------------------------------------------------------------------
# Brand stats (precomputed aggregates from bifrost build, served via proxy).
# ---------------------------------------------------------------------------


class StatusClassCounts(BaseModel):
    two_xx: int = Field(0, alias="2xx")
    three_xx: int = Field(0, alias="3xx")
    four_xx: int = Field(0, alias="4xx")
    five_xx: int = Field(0, alias="5xx")

    model_config = {"populate_by_name": True}


class PageCrawlHealth(BaseModel):
    status_class_counts: StatusClassCounts = Field(default_factory=StatusClassCounts)
    indexable_count: Optional[int] = None
    non_indexable_count: Optional[int] = None
    indexability_reasons: Dict[str, int] = Field(default_factory=dict)
    canonicalized_count: Optional[int] = None


class PageContentStructure(BaseModel):
    missing_title_count: int = 0
    missing_meta_description_count: int = 0
    missing_h1_count: int = 0
    # Pages with more than one H1 tag (SEO violation).
    multiple_h1_count: int = 0
    duplicate_titles_count: int = 0
    duplicate_h1_count: int = 0
    duplicate_meta_description_count: int = 0
    empty_content_count: Optional[int] = None
    thin_content_count: Optional[int] = None


class PathPrefixCount(BaseModel):
    prefix: str
    count: int


class PageURLShape(BaseModel):
    top_path_prefixes: List[PathPrefixCount] = Field(default_factory=list)
    query_string_pages_count: int = 0
    https_count: int = 0
    http_count: int = 0
    trailing_slash_count: int = 0


class PageRedirects(BaseModel):
    self_referential_redirects_count: int = 0


class ResponseTimeStats(BaseModel):
    mean: float
    p50: float
    p90: float
    p99: float


class FreshnessDistribution(BaseModel):
    lt_7d: int = 0
    lt_30d: int = 0
    lt_90d: int = 0
    lt_1y: int = 0
    gt_1y: int = 0
    unknown: int = 0


class PagePerformance(BaseModel):
    response_time_stats: Optional[ResponseTimeStats] = None
    slow_pages_count: Optional[int] = None
    freshness_distribution: Optional[FreshnessDistribution] = None
    oldest_page_last_modified: Optional[int] = None
    newest_page_last_modified: Optional[int] = None


class PagesStats(BaseModel):
    total: int
    crawl_health: Optional[PageCrawlHealth] = None
    content_structure: Optional[PageContentStructure] = None
    url_shape: Optional[PageURLShape] = None
    redirects: Optional[PageRedirects] = None
    performance: Optional[PagePerformance] = None


class URLCount(BaseModel):
    url: str
    count: int


class DomainCount(BaseModel):
    domain: str
    count: int


class LinkClassificationCounts(BaseModel):
    content: int = 0
    boilerplate: int = 0
    ambiguous: int = 0


class LinksStats(BaseModel):
    total_inlinks: int = 0
    total_outlinks: int = 0
    orphan_pages_count: Optional[int] = None
    dead_end_pages_count: Optional[int] = None
    top_linked_pages: List[URLCount] = Field(default_factory=list)
    top_linking_pages: List[URLCount] = Field(default_factory=list)
    broken_outlink_count: Optional[int] = None
    internal_outlink_count: Optional[int] = None
    external_outlink_count: Optional[int] = None
    top_external_domains: List[DomainCount] = Field(default_factory=list)
    anchor_text_diversity: Optional[int] = None
    link_classification_counts: Optional[LinkClassificationCounts] = None
    link_type_counts: Dict[str, int] = Field(default_factory=dict)


class VolumeBuckets(BaseModel):
    zero: int = Field(0)
    one_to_10: int = Field(0, alias="1_10")
    ten_to_100: int = Field(0, alias="10_100")
    hundred_to_1k: int = Field(0, alias="100_1k")
    one_k_to_10k: int = Field(0, alias="1k_10k")
    ten_k_to_100k: int = Field(0, alias="10k_100k")
    gte_100k: int = 0

    model_config = {"populate_by_name": True}


class KeywordVolumeStats(BaseModel):
    total_search_volume: int = 0
    volume_buckets: VolumeBuckets = Field(default_factory=VolumeBuckets)
    total_cpc_weighted_volume: Optional[float] = None


class DifficultyBuckets(BaseModel):
    b_0_20: int = Field(0, alias="0_20")
    b_20_40: int = Field(0, alias="20_40")
    b_40_60: int = Field(0, alias="40_60")
    b_60_80: int = Field(0, alias="60_80")
    b_80_100: int = Field(0, alias="80_100")
    unknown: int = 0

    model_config = {"populate_by_name": True}


class KeywordDifficultyStats(BaseModel):
    difficulty_buckets: DifficultyBuckets = Field(default_factory=DifficultyBuckets)


class PositionBuckets(BaseModel):
    top_3: int = 0
    b_4_10: int = Field(0, alias="4_10")
    b_11_20: int = Field(0, alias="11_20")
    b_21_50: int = Field(0, alias="21_50")
    b_51_100: int = Field(0, alias="51_100")
    unranked: int = 0

    model_config = {"populate_by_name": True}


class KeywordRankingStats(BaseModel):
    ranking_count: int = 0
    position_buckets: PositionBuckets = Field(default_factory=PositionBuckets)
    top_3_count: int = 0
    first_page_count: int = 0


class IntentCounts(BaseModel):
    informational: int = 0
    commercial: int = 0
    transactional: int = 0
    navigational: int = 0
    unknown: int = 0


class KeywordIntentStats(BaseModel):
    counts: IntentCounts = Field(default_factory=IntentCounts)
    volume_share: Optional[IntentCounts] = None


class KeywordsStats(BaseModel):
    total: int = 0
    volume: Optional[KeywordVolumeStats] = None
    difficulty: Optional[KeywordDifficultyStats] = None
    ranking: Optional[KeywordRankingStats] = None
    intent: Optional[KeywordIntentStats] = None


class LandingPage(BaseModel):
    url: str
    keyword_count: int
    total_volume: int = 0


class CrossStats(BaseModel):
    keyword_to_page_matches_count: Optional[int] = None
    ranking_pages_count: Optional[int] = None
    top_landing_pages: List[LandingPage] = Field(default_factory=list)
    topics_count: Optional[int] = None
    topics_with_pillar_page_count: Optional[int] = None
    topics_with_landing_page_count: Optional[int] = None


class BrandStatsResponse(BaseModel):
    """Precomputed aggregate statistics for a brand.

    Every section is optional — if the underlying source data was missing at
    build time, that section is absent. Callers should treat any field as
    potentially `None` and guard accordingly.
    """

    brand_name: str
    generated_at: int
    pages: Optional[PagesStats] = None
    links: Optional[LinksStats] = None
    keywords: Optional[KeywordsStats] = None
    cross: Optional[CrossStats] = None
