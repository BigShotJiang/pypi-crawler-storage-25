"""Tests for the `agentberlin skills` SDK resource and CLI commands.

Covers list / get / create / update / delete for the user's own skills, plus
the `--system` flag that falls back to the curated catalog. HTTP calls are
stubbed via the `responses` library.
"""

import json

import pytest
import responses
from click.testing import CliRunner

from agentberlin import AgentBerlin
from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _skill(id: str, name: str = "S") -> dict:
    return {
        "id": id,
        "name": name,
        "details": "do the thing",
    }


class TestSkillsResource:
    @responses.activate
    def test_list_default_posts_user_scope(self, mock_token):
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/list",
            json={"skills": [_skill("a"), _skill("b")]},
            status=200,
        )

        client = AgentBerlin(token=mock_token)
        out = client.skills.list()

        assert [s.id for s in out] == ["a", "b"]
        assert json.loads(responses.calls[0].request.body) == {"scope": "user"}

    @responses.activate
    def test_list_system_scope(self, mock_token):
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/list",
            json={"skills": [_skill("a")]},
            status=200,
        )

        client = AgentBerlin(token=mock_token)
        out = client.skills.list(scope="system")

        assert [s.id for s in out] == ["a"]
        assert json.loads(responses.calls[0].request.body) == {"scope": "system"}

    @responses.activate
    def test_get_default_user_scope(self, mock_token):
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/get",
            json=_skill("abc"),
            status=200,
        )

        client = AgentBerlin(token=mock_token)
        s = client.skills.get("abc")

        assert s.id == "abc"
        assert json.loads(responses.calls[0].request.body) == {
            "id": "abc",
            "scope": "user",
        }

    @responses.activate
    def test_create_posts_name_and_details(self, mock_token):
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/create",
            json=_skill("new", name="New"),
            status=200,
        )

        client = AgentBerlin(token=mock_token)
        s = client.skills.create(name="New", details="body")

        assert s.id == "new"
        assert json.loads(responses.calls[0].request.body) == {
            "name": "New",
            "details": "body",
        }

    @responses.activate
    def test_update_sends_only_provided_fields(self, mock_token):
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/update",
            json=_skill("abc", name="Renamed"),
            status=200,
        )

        client = AgentBerlin(token=mock_token)
        client.skills.update("abc", name="Renamed")

        assert json.loads(responses.calls[0].request.body) == {
            "id": "abc",
            "name": "Renamed",
        }

    def test_update_without_fields_raises(self, mock_token):
        client = AgentBerlin(token=mock_token)
        with pytest.raises(ValueError, match="name, details"):
            client.skills.update("abc")

    @responses.activate
    def test_delete(self, mock_token):
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/delete",
            status=204,
        )

        client = AgentBerlin(token=mock_token)
        client.skills.delete("abc")

        assert json.loads(responses.calls[0].request.body) == {"id": "abc"}


class TestSkillsListCLI:
    @responses.activate
    def test_default_renders_user_table(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/list",
            json={"skills": [_skill("alpha", name="Alpha")]},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["skills", "list", "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "alpha" in result.output
        assert "Alpha" in result.output
        assert json.loads(responses.calls[0].request.body) == {"scope": "user"}

    @responses.activate
    def test_system_flag_switches_scope(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/list",
            json={"skills": [_skill("beta", name="Beta")]},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main, ["skills", "list", "--system", "--token", "t"]
        )

        assert result.exit_code == 0, result.output
        assert "beta" in result.output
        assert json.loads(responses.calls[0].request.body) == {"scope": "system"}

    @responses.activate
    def test_empty_list_message(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/list",
            json={"skills": []},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["skills", "list", "--token", "t"])

        assert result.exit_code == 0
        assert "no skills" in result.output.lower()


class TestSkillsGetCLI:
    @responses.activate
    def test_prints_details_body(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/get",
            json=_skill("alpha", name="Alpha"),
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["skills", "get", "alpha", "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "do the thing" in result.output
        assert json.loads(responses.calls[0].request.body) == {
            "id": "alpha",
            "scope": "user",
        }

    @responses.activate
    def test_writes_output_file(self, tmp_path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/get",
            json=_skill("alpha"),
            status=200,
        )

        out = tmp_path / "out.md"
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["skills", "get", "alpha", "--token", "t", "--output", str(out)],
        )

        assert result.exit_code == 0, result.output
        assert out.read_text() == "do the thing"


class TestSkillsCreateCLI:
    @responses.activate
    def test_create_uploads_file_contents(self, tmp_path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/create",
            json=_skill("new", name="New"),
            status=200,
        )

        body = tmp_path / "body.md"
        body.write_text("# Heading\n\nbody text")

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["skills", "create", str(body), "--name", "New", "--token", "t"],
        )

        assert result.exit_code == 0, result.output
        assert "Created skill new" in result.output
        assert json.loads(responses.calls[0].request.body) == {
            "name": "New",
            "details": "# Heading\n\nbody text",
        }


class TestSkillsUpdateCLI:
    @responses.activate
    def test_rename_only(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/update",
            json=_skill("abc", name="Renamed"),
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main, ["skills", "update", "abc", "--name", "Renamed", "--token", "t"]
        )

        assert result.exit_code == 0, result.output
        assert json.loads(responses.calls[0].request.body) == {
            "id": "abc",
            "name": "Renamed",
        }

    @responses.activate
    def test_replace_body(self, tmp_path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/update",
            json=_skill("abc"),
            status=200,
        )

        body = tmp_path / "body.md"
        body.write_text("new body")

        runner = CliRunner()
        result = runner.invoke(
            main, ["skills", "update", "abc", str(body), "--token", "t"]
        )

        assert result.exit_code == 0, result.output
        assert json.loads(responses.calls[0].request.body) == {
            "id": "abc",
            "details": "new body",
        }

    def test_no_changes_errors(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["skills", "update", "abc", "--token", "t"])

        assert result.exit_code != 0
        assert "nothing to update" in result.output.lower()


class TestSkillsDeleteCLI:
    @responses.activate
    def test_delete_with_yes(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/skills/delete",
            status=204,
        )

        runner = CliRunner()
        result = runner.invoke(
            main, ["skills", "delete", "abc", "--yes", "--token", "t"]
        )

        assert result.exit_code == 0, result.output
        assert "Deleted skill abc" in result.output
        assert json.loads(responses.calls[0].request.body) == {"id": "abc"}

    def test_delete_aborts_without_confirmation(self) -> None:
        runner = CliRunner()
        # No --yes, and we feed "n" to the prompt
        result = runner.invoke(
            main, ["skills", "delete", "abc", "--token", "t"], input="n\n"
        )

        assert result.exit_code != 0
        assert "abort" in result.output.lower()
