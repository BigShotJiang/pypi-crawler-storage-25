"""Tests for the `agentberlin findings` CLI subcommand group.

Covers save (multipart upload), list (table + --json), get (download to disk),
and update (metadata-only and content-replacement). HTTP calls are stubbed via
the `responses` library.
"""

import json
from pathlib import Path

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


class TestFindingsSave:
    @responses.activate
    def test_save_markdown_uploads_with_inferred_type(self, tmp_path: Path) -> None:
        finding_file = tmp_path / "audit.md"
        finding_file.write_text("# Audit\n\nFindings here.\n")

        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/findings/save",
            json={
                "id": "fnd_abc",
                "title": "Audit",
                "artifact_type": "markdown",
                "size_bytes": 20,
                "url": "https://files.example/audit.md",
                "created_at": "2026-05-14T00:00:00Z",
                "updated_at": "2026-05-14T00:00:00Z",
            },
            status=201,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "findings",
                "save",
                str(finding_file),
                "--title",
                "Audit",
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "Saved finding fnd_abc" in result.output

        # Verify multipart body shape: project_domain, title, artifact_type, and the file all in one POST.
        assert len(responses.calls) == 1
        body = responses.calls[0].request.body
        assert b"name=\"project_domain\"" in body
        assert b"example.com" in body
        assert b"name=\"title\"" in body
        assert b"name=\"artifact_type\"" in body
        assert b"markdown" in body
        assert b"name=\"file\"" in body

    def test_save_rejects_unknown_extension(self, tmp_path: Path) -> None:
        bad = tmp_path / "notes.txt"
        bad.write_text("not allowed")

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "findings",
                "save",
                str(bad),
                "--title",
                "X",
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code != 0
        assert "Cannot infer artifact_type" in result.output


class TestFindingsList:
    @responses.activate
    def test_list_renders_table(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/findings/list",
            json={
                "findings": [
                    {
                        "id": "fnd_a",
                        "title": "SEO audit",
                        "artifact_type": "markdown",
                        "size_bytes": 1024,
                        "url": "https://files.example/a.md",
                        "generated_by": "Alex",
                        "created_at": "2026-05-14T00:00:00Z",
                        "updated_at": "2026-05-14T00:00:00Z",
                    },
                    {
                        "id": "fnd_b",
                        "title": "Competitors",
                        "artifact_type": "json",
                        "size_bytes": 512,
                        "url": "https://files.example/b.json",
                        "created_at": "2026-05-13T00:00:00Z",
                        "updated_at": "2026-05-13T00:00:00Z",
                    },
                ]
            },
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["findings", "list", "--project-domain", "example.com", "--token", "t"],
        )

        assert result.exit_code == 0, result.output
        assert "findings (2):" in result.output
        assert "fnd_a" in result.output
        assert "SEO audit" in result.output
        assert "Alex" in result.output
        # Missing generated_by falls back to em-dash.
        assert "—" in result.output

    @responses.activate
    def test_list_empty_renders_none(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/findings/list",
            json={"findings": []},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["findings", "list", "--project-domain", "example.com", "--token", "t"],
        )

        assert result.exit_code == 0, result.output
        assert "findings: (none)" in result.output

    @responses.activate
    def test_list_json_flag_emits_raw_array(self) -> None:
        payload = [
            {
                "id": "fnd_a",
                "title": "SEO audit",
                "artifact_type": "markdown",
                "size_bytes": 1024,
                "url": "https://files.example/a.md",
                "created_at": "2026-05-14T00:00:00Z",
                "updated_at": "2026-05-14T00:00:00Z",
            }
        ]
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/findings/list",
            json={"findings": payload},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["findings", "list", "--project-domain", "example.com", "--token", "t", "--json"],
        )

        assert result.exit_code == 0, result.output
        parsed = json.loads(result.output)
        assert parsed == payload


class TestFindingsGet:
    @responses.activate
    def test_get_downloads_to_explicit_output(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/findings/get",
            body=b"# Audit\n\nFindings.\n",
            status=200,
            content_type="text/markdown",
        )

        out = tmp_path / "downloaded.md"
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "findings",
                "get",
                "fnd_abc",
                "--output",
                str(out),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert out.read_bytes() == b"# Audit\n\nFindings.\n"
        assert "Downloaded" in result.output

    @responses.activate
    def test_get_404_is_friendly(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/findings/get",
            json={"error": "Finding not found"},
            status=404,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "findings",
                "get",
                "fnd_missing",
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code != 0
        assert "not found" in result.output.lower()


class TestFindingsUpdate:
    def test_update_requires_some_change(self) -> None:
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "findings",
                "update",
                "fnd_abc",
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code != 0
        assert "Nothing to update" in result.output

    @responses.activate
    def test_update_metadata_only(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/findings/update",
            json={
                "id": "fnd_abc",
                "title": "Renamed audit",
                "artifact_type": "markdown",
                "size_bytes": 20,
                "url": "https://files.example/a.md",
                "created_at": "2026-05-14T00:00:00Z",
                "updated_at": "2026-05-14T00:01:00Z",
            },
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "findings",
                "update",
                "fnd_abc",
                "--title",
                "Renamed audit",
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "Updated finding fnd_abc" in result.output
