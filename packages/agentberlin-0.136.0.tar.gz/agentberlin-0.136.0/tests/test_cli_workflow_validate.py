"""Tests for the `agentberlin workflow validate` CLI subcommand.

Validates the JSON contract the build agent depends on (`{"valid": true}` or
`{"valid": false, "errors": [...]}`), the exit code (0/1), and that the
command surfaces in the public `workflow --help` listing — humans editing
main.py locally should be able to discover it.
"""

import json
from pathlib import Path

from click.testing import CliRunner

from agentberlin.cli import main


# Minimal valid workflow main.py that should pass all three checks. The script
# body intentionally avoids any SDK call so the test does not depend on
# network or real type stubs — mypy ships its own stubs for the stdlib.
_VALID_MAIN_PY = '''\
import json
from pydantic import BaseModel


class OutputSchema(BaseModel):
    count: int


def main() -> None:
    result = OutputSchema(count=1)
    with open("output.json", "w") as f:
        f.write(result.model_dump_json())


if __name__ == "__main__":
    main()
'''


def _write(tmp_path: Path, contents: str, name: str = "main.py") -> Path:
    p = tmp_path / name
    p.write_text(contents)
    return p


class TestWorkflowValidate:
    def test_valid_main_passes(self, tmp_path: Path) -> None:
        target = _write(tmp_path, _VALID_MAIN_PY)
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "validate", str(target)])
        assert result.exit_code == 0, result.output
        payload = json.loads(result.output.strip())
        assert payload == {"valid": True}

    def test_syntax_error_reports_py_compile(self, tmp_path: Path) -> None:
        # Bad syntax: dangling open paren after function name.
        target = _write(tmp_path, "def foo(:\n    pass\n")
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "validate", str(target)])
        assert result.exit_code == 1
        payload = json.loads(result.output.strip())
        assert payload["valid"] is False
        tools = {e["tool"] for e in payload["errors"]}
        assert "py_compile" in tools

    def test_type_error_reports_mypy(self, tmp_path: Path) -> None:
        # Adds a type error on top of the otherwise-valid skeleton — return
        # type is `int` but the function returns `str`.
        contents = '''\
from pydantic import BaseModel


class OutputSchema(BaseModel):
    count: int


def get_count() -> int:
    return "not an int"


def main() -> None:
    result = OutputSchema(count=get_count())
    with open("output.json", "w") as f:
        f.write(result.model_dump_json())
'''
        target = _write(tmp_path, contents)
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "validate", str(target)])
        assert result.exit_code == 1
        payload = json.loads(result.output.strip())
        assert payload["valid"] is False
        tools = {e["tool"] for e in payload["errors"]}
        assert "mypy" in tools

    def test_missing_output_schema_reports_output_schema(self, tmp_path: Path) -> None:
        contents = '''\
def main() -> None:
    pass
'''
        target = _write(tmp_path, contents)
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "validate", str(target)])
        assert result.exit_code == 1
        payload = json.loads(result.output.strip())
        assert payload["valid"] is False
        tools = {e["tool"] for e in payload["errors"]}
        assert "output_schema" in tools

    def test_indented_output_schema_fails(self, tmp_path: Path) -> None:
        # Declared inside a function — must NOT satisfy the regex (which
        # requires column 0). The build pipeline imports OutputSchema from
        # the module top level, so an indented declaration is not the
        # contract we want.
        contents = '''\
from pydantic import BaseModel


def main() -> None:
    class OutputSchema(BaseModel):
        count: int
'''
        target = _write(tmp_path, contents)
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "validate", str(target)])
        assert result.exit_code == 1
        payload = json.loads(result.output.strip())
        assert payload["valid"] is False
        tools = {e["tool"] for e in payload["errors"]}
        assert "output_schema" in tools

    def test_pydantic_basemodel_qualified_passes(self, tmp_path: Path) -> None:
        # `pydantic.BaseModel` (qualified) is also a valid contract — the
        # regex tolerates the prefix. Use a simple shape so mypy is content.
        contents = '''\
import pydantic


class OutputSchema(pydantic.BaseModel):
    count: int


def main() -> None:
    result = OutputSchema(count=1)
    with open("output.json", "w") as f:
        f.write(result.model_dump_json())
'''
        target = _write(tmp_path, contents)
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "validate", str(target)])
        assert result.exit_code == 0, result.output
        assert json.loads(result.output.strip()) == {"valid": True}

    def test_validate_listed_in_workflow_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "--help"])
        assert result.exit_code == 0
        # The subcommand must surface in the public listing — humans editing
        # main.py locally should be able to discover it.
        assert "validate" in result.output

    def test_validate_help_shows_full_usage(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "validate", "--help"])
        assert result.exit_code == 0
        # The detailed help text must explain the three checks and the JSON
        # contract — that's the discoverability contract the prompt relies on.
        assert "py_compile" in result.output
        assert "mypy" in result.output
        assert "OutputSchema" in result.output
