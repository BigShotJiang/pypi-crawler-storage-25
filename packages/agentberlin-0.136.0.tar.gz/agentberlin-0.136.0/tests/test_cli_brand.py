"""Tests for the `agentberlin brand` CLI subcommand group.

Covers `brand info` (profile + file catalog merged into one view) and
`brand get` (file-by-id). HTTP calls are stubbed via the `responses`
library so tests don't hit a real backend.
"""

import json
from pathlib import Path

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


# ---------------------------------------------------------------------------
# brand info
# ---------------------------------------------------------------------------


class TestBrandInfo:
    @responses.activate
    def test_info_renders_profile_and_files_together(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/brand/profile",
            json={
                "domain": "example.com",
                "name": "Example Inc",
                "industries": ["SaaS", "Marketing"],
                "business_models": ["B2B"],
                "company_size": "smb",
                "target_customer_segments": ["Marketing managers"],
                "geographies": ["US", "EU"],
                "competitors": ["foo.com", "bar.com"],
                "domain_authority": 42,
                "topics": [
                    {"value": "SEO", "pillar_page_url": "https://example.com/seo"},
                    {"value": "Content"},
                ],
                "sitemaps": ["https://example.com/sitemap.xml"],
                "profile_urls": [],
            },
            status=200,
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/brand/files/list",
            json={
                "files": [
                    {
                        "id": "bf_abc",
                        "filename": "tone.md",
                        "size_bytes": 2048,
                        "description": "Voice & tone",
                    }
                ]
            },
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["brand", "info", "--project-domain", "example.com", "--token", "t"],
        )

        assert result.exit_code == 0, result.output
        # Profile section
        assert "domain" in result.output
        assert "example.com" in result.output
        assert "industries" in result.output
        assert "SaaS, Marketing" in result.output
        assert "topics" in result.output
        assert "- SEO" in result.output
        assert "pillar=https://example.com/seo" in result.output
        # Empty list renders as (none), not an error.
        assert "(none)" in result.output
        # Files section is folded into the same view.
        assert "brand files (1)" in result.output
        assert "bf_abc" in result.output
        assert "tone.md" in result.output
        assert "Voice & tone" in result.output

        # Confirm both endpoints were hit with the project_domain.
        assert len(responses.calls) == 2
        for call in responses.calls:
            assert json.loads(call.request.body)["project_domain"] == "example.com"

    @responses.activate
    def test_info_with_no_files_says_none(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/brand/profile",
            json={
                "domain": "example.com",
                "name": "Example",
                "industries": ["SaaS"],
                "business_models": [],
                "company_size": "",
                "target_customer_segments": [],
                "geographies": [],
                "competitors": [],
                "domain_authority": 0,
                "topics": [],
                "sitemaps": [],
                "profile_urls": [],
            },
            status=200,
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/brand/files/list",
            json={"files": []},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["brand", "info", "--project-domain", "example.com", "--token", "t"],
        )

        assert result.exit_code == 0, result.output
        assert "brand files: (none)" in result.output

    @responses.activate
    def test_info_json_flag_emits_combined_payload(self) -> None:
        profile = {
            "domain": "example.com",
            "name": "Example",
            "industries": ["SaaS"],
            "business_models": [],
            "company_size": "",
            "target_customer_segments": [],
            "geographies": [],
            "competitors": [],
            "domain_authority": 0,
            "topics": [],
            "sitemaps": [],
            "profile_urls": [],
        }
        files = [{"id": "bf_x", "filename": "x.md", "size_bytes": 10}]
        responses.add(responses.POST, f"{DEFAULT_BASE_URL}/brand/profile", json=profile, status=200)
        responses.add(
            responses.POST, f"{DEFAULT_BASE_URL}/brand/files/list", json={"files": files}, status=200
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "brand",
                "info",
                "--project-domain",
                "example.com",
                "--token",
                "t",
                "--json",
            ],
        )

        assert result.exit_code == 0, result.output
        assert json.loads(result.output) == {"profile": profile, "files": files}


# ---------------------------------------------------------------------------
# brand get
# ---------------------------------------------------------------------------


class TestBrandGet:
    @responses.activate
    def test_get_writes_file_to_explicit_output(self, tmp_path: Path) -> None:
        content = b"# brand voice\nuse first person.\n"
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/brand/files/content",
            body=content,
            status=200,
            content_type="text/markdown",
            adding_headers={
                "Content-Disposition": 'attachment; filename="voice.md"',
            },
        )

        runner = CliRunner()
        out = tmp_path / "voice.md"
        result = runner.invoke(
            main,
            [
                "brand",
                "get",
                "bf_xyz",
                "--project-domain",
                "example.com",
                "--token",
                "t",
                "-o",
                str(out),
            ],
        )

        assert result.exit_code == 0, result.output
        assert out.read_bytes() == content
        body = json.loads(responses.calls[0].request.body)
        assert body == {"project_domain": "example.com", "file_id": "bf_xyz"}

    @responses.activate
    def test_get_404_raises_friendly_error(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/brand/files/content",
            json={"error": "not found"},
            status=404,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "brand",
                "get",
                "bf_missing",
                "--project-domain",
                "example.com",
                "--token",
                "t",
                "-o",
                str(tmp_path / "out.bin"),
            ],
        )

        assert result.exit_code != 0
        assert "bf_missing" in result.output
        assert "not found" in result.output.lower()


# ---------------------------------------------------------------------------
# Removed surface — guard against accidental restoration
# ---------------------------------------------------------------------------


class TestBrandFilesLegacyRemoved:
    def test_top_level_brand_files_group_is_gone(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["brand-files", "--help"])
        assert result.exit_code != 0
        assert "No such command" in result.output or "Usage" in result.output

    def test_nested_brand_files_subgroup_is_gone(self) -> None:
        # The interim `brand files` sub-group was folded into `info` + `get`.
        runner = CliRunner()
        result = runner.invoke(main, ["brand", "files", "--help"])
        assert result.exit_code != 0
