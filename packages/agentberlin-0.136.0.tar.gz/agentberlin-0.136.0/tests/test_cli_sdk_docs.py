"""Tests for the `agentberlin sdk-docs` CLI subcommand group.

Covers `sdk-docs overview` (prints the SDK introduction) and `sdk-docs show`
(method-level docs with helpful errors for unknown resource/method). The docs
source is the bundled `readme.yaml`, so these tests run against real data.
"""

from click.testing import CliRunner

from agentberlin.cli import _load_sdk_docs, main


class TestSdkDocsOverview:
    def test_overview_prints_introduction(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["sdk-docs", "overview"])
        assert result.exit_code == 0, result.output
        docs = _load_sdk_docs()
        expected = (docs.get("introduction") or "").strip()
        assert expected, "fixture sanity: readme.yaml must have an introduction"
        assert expected in result.output


class TestSdkDocsShow:
    def test_show_known_method_prints_docs(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["sdk-docs", "show", "pages", "search"])
        assert result.exit_code == 0, result.output
        expected = _load_sdk_docs()["resources"]["pages"]["methods"]["search"].rstrip("\n")
        assert expected in result.output

    def test_show_unknown_resource_errors_and_lists_resources(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["sdk-docs", "show", "nope_resource", "search"])
        assert result.exit_code != 0
        assert "Resource 'nope_resource' not found" in result.output
        assert "Available resources:" in result.output

    def test_show_unknown_method_errors_and_lists_methods(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["sdk-docs", "show", "pages", "nope_method"])
        assert result.exit_code != 0
        assert "Method 'nope_method' not found in resource 'pages'" in result.output
        assert "Available methods:" in result.output
