# Copyright 2025 DataRobot, Inc. and its affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import typing
import warnings
from collections.abc import AsyncGenerator

from a2a.types import AgentSkill
from nat.cli.register_workflow import register_front_end
from nat.data_models.api_server import GlobalTypeConverter
from nat.data_models.config import Config
from nat.front_ends.fastapi.fastapi_front_end_config import FastApiFrontEndConfig
from nat.plugins.a2a.server.front_end_config import A2AFrontEndConfig
from pydantic import BaseModel
from pydantic import Field

from .converters import convert_chat_request_to_run_agent_input
from .converters import convert_dragent_event_response_to_chat_response_chunk
from .converters import convert_dragent_event_response_to_str
from .converters import convert_dragent_run_agent_input_to_chat_request
from .converters import convert_dragent_run_agent_input_to_chat_request_or_message
from .converters import convert_str_to_dragent_event_response
from .converters import convert_tool_message_to_str
from .logging import logging_handler_setup
from .server_auth import CrossApplicationAccessConfig

# Suppress specific non-actionable NAT warning messages by content.
# Patch Handler.handle (inherited by all subclasses - they only override emit)
# because root-logger filters are skipped during log propagation.
logging_handler_setup()

# Suppress UserWarning from langchain about non-default parameters (uses warnings.warn, not logging)
warnings.filterwarnings("ignore", message=".*stream_options is not default parameter.*")


class DRAgentA2AExternalConfig(BaseModel):
    """Customer-provided external identity and URL override for the agent card."""

    id: str | None = Field(
        default=None, description="External agent identifier for catalog discovery."
    )
    url: str | None = Field(
        default=None, description="Custom external URL override for the agent card endpoint."
    )


class DRAgentA2AConfig(BaseModel):
    """DR-owned wrapper around NAT's A2AFrontEndConfig with optional skill definitions."""

    server: A2AFrontEndConfig = Field(description="NAT A2A server configuration.")
    cross_application_access: CrossApplicationAccessConfig | None = Field(
        default=None,
        description=(
            "Configuration for Cross-Application Access utilizing a hybrid RFC 8693 / "
            "RFC 7523 flow."
        ),
    )
    skills: list[AgentSkill] = Field(
        default=[],
        description="Skills to advertise in the A2A agent card. "
        "If empty, a single default skill is generated from the agent name and description.",
    )
    external: DRAgentA2AExternalConfig | None = Field(
        default=None,
        description="External identity and URL override for the agent card.",
    )


# Register frontend
class DRAgentFastApiFrontEndConfig(FastApiFrontEndConfig, name="dragent_fastapi"):  # type: ignore
    a2a: DRAgentA2AConfig | None = Field(
        default=None,
        description="Expose this agent via the Agent2Agent protocol. "
        "A2A server endpoints are mounted under /a2a/.",
    )
    workflow: typing.Annotated[
        FastApiFrontEndConfig.EndpointBase,
        Field(description="Endpoint for the default workflow."),
    ] = FastApiFrontEndConfig.EndpointBase(
        method="POST",
        path="/v1/workflow",
        openai_api_v1_path="/chat/completions",
        legacy_path="/generate",
        legacy_openai_api_path="/chat",
        description="Executes the default NAT workflow from the loaded configuration ",
    )


@register_front_end(config_type=DRAgentFastApiFrontEndConfig)
async def dragent_fastapi_front_end(
    config: DRAgentFastApiFrontEndConfig, full_config: Config
) -> AsyncGenerator[typing.Any, None]:
    from .fastapi import DRAgentFastApiFrontEndPlugin

    yield DRAgentFastApiFrontEndPlugin(full_config=full_config)


# Register console frontend for `nat dragent run`
from .console import DRAgentConsoleFrontEndConfig  # noqa: E402


@register_front_end(config_type=DRAgentConsoleFrontEndConfig)
async def dragent_console_front_end(
    config: DRAgentConsoleFrontEndConfig, full_config: Config
) -> AsyncGenerator[typing.Any, None]:
    from .console import DRAgentConsoleFrontEndPlugin

    yield DRAgentConsoleFrontEndPlugin(full_config=full_config)


# Register converters
GlobalTypeConverter.register_converter(convert_dragent_run_agent_input_to_chat_request)
GlobalTypeConverter.register_converter(convert_chat_request_to_run_agent_input)
GlobalTypeConverter.register_converter(convert_dragent_run_agent_input_to_chat_request_or_message)
GlobalTypeConverter.register_converter(convert_tool_message_to_str)
GlobalTypeConverter.register_converter(convert_str_to_dragent_event_response)
GlobalTypeConverter.register_converter(convert_dragent_event_response_to_str)
GlobalTypeConverter.register_converter(convert_dragent_event_response_to_chat_response_chunk)
