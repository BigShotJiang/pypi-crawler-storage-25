"""Final-gate aggregation for PR-scoped review sessions."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

from gh_address_cr.core.github_thread_state import (
    GITHUB_THREAD_TERMINAL_STATES,
    is_resolved_github_thread,
    is_stale_or_outdated_github_thread,
    is_terminal_github_thread,
)
from gh_address_cr.core.session import SessionError, SessionManager
from gh_address_cr.github.client import GitHubClient


FINAL_GATE_UNRESOLVED_REMOTE_THREADS = "FINAL_GATE_UNRESOLVED_REMOTE_THREADS"
FINAL_GATE_MISSING_REPLY_EVIDENCE = "FINAL_GATE_MISSING_REPLY_EVIDENCE"
FINAL_GATE_PENDING_CURRENT_LOGIN_REVIEW = "FINAL_GATE_PENDING_CURRENT_LOGIN_REVIEW"
FINAL_GATE_BLOCKING_GITHUB_ITEMS = "FINAL_GATE_BLOCKING_GITHUB_ITEMS"
FINAL_GATE_BLOCKING_LOCAL_ITEMS = "FINAL_GATE_BLOCKING_LOCAL_ITEMS"
FINAL_GATE_MISSING_VALIDATION_EVIDENCE = "FINAL_GATE_MISSING_VALIDATION_EVIDENCE"
FINAL_GATE_PR_CHECKS_NOT_GREEN = "FINAL_GATE_PR_CHECKS_NOT_GREEN"

PASS_EXIT_CODE = 0
FAIL_EXIT_CODE = 5

GITHUB_TERMINAL_STATES = GITHUB_THREAD_TERMINAL_STATES
LOCAL_TERMINAL_STATES = {
    "closed",
    "fixed",
    "clarified",
    "deferred",
    "rejected",
    "verified",
    "published",
}

COUNT_KEYS = (
    "unresolved_github_threads_count",
    "pending_review_count",
    "blocking_items_count",
    "blocking_github_items_count",
    "github_threads_missing_reply_count",
    "missing_validation_evidence_count",
    "blocking_local_items_count",
    "pending_current_login_review_count",
    "unresolved_remote_threads_count",
    "pr_checks_count",
    "pr_checks_failed_count",
    "pr_checks_pending_count",
    "pr_checks_not_green_count",
)

FAILURE_ORDER = (
    (FINAL_GATE_UNRESOLVED_REMOTE_THREADS, "unresolved_remote_threads_count", "remote_threads"),
    (FINAL_GATE_MISSING_REPLY_EVIDENCE, "github_threads_missing_reply_count", "reply_evidence"),
    (FINAL_GATE_PENDING_CURRENT_LOGIN_REVIEW, "pending_current_login_review_count", "pending_review"),
    (FINAL_GATE_BLOCKING_GITHUB_ITEMS, "blocking_github_items_count", "github_items"),
    (FINAL_GATE_BLOCKING_LOCAL_ITEMS, "blocking_local_items_count", "local_items"),
    (FINAL_GATE_MISSING_VALIDATION_EVIDENCE, "missing_validation_evidence_count", "validation_evidence"),
    (FINAL_GATE_PR_CHECKS_NOT_GREEN, "pr_checks_not_green_count", "checks"),
)


@dataclass(frozen=True)
class GateResult:
    repo: str
    pr_number: str
    counts: dict[str, int]
    failure_codes: list[str]
    check_requirement: str | None = None

    @property
    def passed(self) -> bool:
        return not self.failure_codes

    @property
    def reason_code(self) -> str | None:
        return self.failure_codes[0] if self.failure_codes else None

    @property
    def waiting_on(self) -> str | None:
        if not self.reason_code:
            return None
        for code, _, waiting_on in FAILURE_ORDER:
            if code == self.reason_code:
                return waiting_on
        return "final_gate"

    @property
    def exit_code(self) -> int:
        return PASS_EXIT_CODE if self.passed else FAIL_EXIT_CODE

    def to_machine_summary(self) -> dict[str, Any]:
        return {
            "status": "PASSED" if self.passed else "FAILED",
            "repo": self.repo,
            "pr_number": self.pr_number,
            "item_id": None,
            "item_kind": None,
            "counts": dict(self.counts),
            "artifact_path": None,
            "reason_code": self.reason_code,
            "waiting_on": self.waiting_on,
            "next_action": _next_action(self.reason_code, repo=self.repo, pr_number=self.pr_number, passed=self.passed),
            "exit_code": self.exit_code,
            "failure_codes": list(self.failure_codes),
            "check_requirement": self.check_requirement,
            "commands": _final_gate_commands(self.repo, self.pr_number),
        }


class Gatekeeper:
    def __init__(self, *, github_client: Any | None = None):
        self.github_client = github_client or GitHubClient()

    def run(
        self,
        repo: str,
        pr_number: str,
        *,
        snapshot_path: str | Path | None = None,
        require_checks: bool = False,
        require_required_checks: bool = False,
    ) -> GateResult:
        manager = SessionManager(repo, str(pr_number))
        try:
            session = manager.load()
        except SessionError:
            session = manager.create(status="WAITING_FOR_GATE")
        current_login = self.github_client.viewer_login()
        remote_threads = (
            _load_thread_snapshot(snapshot_path)
            if snapshot_path
            else self.github_client.list_threads(repo, str(pr_number))
        )
        pending_reviews = self.github_client.list_pending_reviews(repo, str(pr_number), current_login)
        check_runs = (
            self.github_client.list_pr_checks(repo, str(pr_number), required=require_required_checks)
            if require_checks or require_required_checks
            else []
        )
        merged_session = _session_with_remote_threads(session, remote_threads, current_login=current_login)
        result = evaluate_final_gate(
            merged_session,
            remote_threads=remote_threads,
            pending_reviews=pending_reviews,
            current_login=current_login,
            check_runs=check_runs,
            check_requirement="required" if require_required_checks else ("all" if require_checks else None),
        )
        metrics = dict(merged_session.get("metrics") or {})
        metrics.update(
            {
                "blocking_items_count": result.counts["blocking_items_count"],
                "unresolved_github_threads_count": result.counts["unresolved_github_threads_count"],
                "github_threads_missing_reply_count": result.counts["github_threads_missing_reply_count"],
                "pending_current_login_review_count": result.counts["pending_current_login_review_count"],
                "pr_checks_failed_count": result.counts["pr_checks_failed_count"],
                "pr_checks_pending_count": result.counts["pr_checks_pending_count"],
            }
        )
        merged_session["metrics"] = metrics
        manager.save(merged_session)
        return result


def evaluate_final_gate(
    session: Mapping[str, Any],
    *,
    remote_threads: Iterable[Mapping[str, Any]] = (),
    pending_reviews: Iterable[Mapping[str, Any]] = (),
    current_login: str | None = None,
    check_runs: Iterable[Mapping[str, Any]] = (),
    check_requirement: str | None = None,
) -> GateResult:
    items = _session_items(session)
    github_items = [item for item in items if _item_kind(item) == "github_thread"]
    local_items = [item for item in items if _item_kind(item) == "local_finding"]

    remote_thread_rows = list(remote_threads)
    remote_by_id = {thread_id: thread for thread in remote_thread_rows if (thread_id := _thread_identifier(thread))}
    unresolved_remote_threads = [thread for thread in remote_thread_rows if not _thread_is_resolved(thread)]
    pending_current_login_reviews = [
        review for review in pending_reviews if _is_current_login_pending_review(review, current_login)
    ]
    check_rows = list(check_runs)
    failed_checks = [check for check in check_rows if _check_bucket(check) in {"fail", "cancel", "unknown"}]
    pending_checks = [check for check in check_rows if _check_bucket(check) == "pending"]
    blocking_local_items = [item for item in local_items if _is_local_blocking(item)]
    blocking_github_items = [item for item in github_items if _is_blocking_item(item)]
    blocking_items = [item for item in items if _is_blocking_item(item)]
    missing_reply_items = [
        item
        for item in github_items
        if _github_thread_requires_reply_evidence(item, remote_by_id) and not _has_reply_evidence(item, current_login)
    ]
    missing_validation_items = [
        item for item in local_items if _is_terminal_local_item(item) and not _has_validation_evidence(item)
    ]

    counts = {
        "unresolved_github_threads_count": len(unresolved_remote_threads),
        "pending_review_count": len(pending_current_login_reviews),
        "blocking_items_count": len(blocking_items),
        "blocking_github_items_count": len(blocking_github_items),
        "github_threads_missing_reply_count": len(missing_reply_items),
        "missing_validation_evidence_count": len(missing_validation_items),
        "blocking_local_items_count": len(blocking_local_items),
        "pending_current_login_review_count": len(pending_current_login_reviews),
        "unresolved_remote_threads_count": len(unresolved_remote_threads),
        "pr_checks_count": len(check_rows),
        "pr_checks_failed_count": len(failed_checks),
        "pr_checks_pending_count": len(pending_checks),
        "pr_checks_not_green_count": len(failed_checks) + len(pending_checks) if check_requirement else 0,
    }
    failure_codes = [code for code, count_key, _ in FAILURE_ORDER if counts[count_key] > 0]

    return GateResult(
        repo=str(session.get("repo") or ""),
        pr_number=str(session.get("pr_number") or ""),
        counts={key: counts[key] for key in COUNT_KEYS},
        failure_codes=failure_codes,
        check_requirement=check_requirement,
    )


def _load_thread_snapshot(snapshot_path: str | Path | None) -> list[dict[str, Any]]:
    if not snapshot_path:
        return []
    path = Path(snapshot_path)
    if not path.exists():
        raise FileNotFoundError(f"Snapshot file not found: {path}")
    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        return []
    if raw.startswith("["):
        payload = json.loads(raw)
        if not isinstance(payload, list):
            raise ValueError(f"Snapshot file must contain a JSON array or JSONL rows: {path}")
        return [row for row in payload if isinstance(row, dict)]
    rows: list[dict[str, Any]] = []
    for line_number, line in enumerate(raw.splitlines(), start=1):
        if not line.strip():
            continue
        row = json.loads(line)
        if not isinstance(row, dict):
            raise ValueError(f"Snapshot row {line_number} must be a JSON object: {path}")
        rows.append(row)
    return rows


def session_with_remote_threads(
    session: Mapping[str, Any],
    remote_threads: Iterable[Mapping[str, Any]],
    *,
    current_login: str | None = None,
) -> dict[str, Any]:
    return _session_with_remote_threads(session, remote_threads, current_login=current_login)


def _session_with_remote_threads(
    session: Mapping[str, Any],
    remote_threads: Iterable[Mapping[str, Any]],
    *,
    current_login: str | None = None,
) -> dict[str, Any]:
    merged: dict[str, Any] = dict(session)
    raw_items = session.get("items") or {}
    items = dict(raw_items) if isinstance(raw_items, Mapping) else {}
    for thread in remote_threads:
        thread_id = _thread_identifier(thread)
        if not thread_id:
            continue
        item_id = f"github-thread:{thread_id}"
        existing = items.get(item_id)
        item = dict(existing) if isinstance(existing, Mapping) else {}
        item.setdefault("item_id", item_id)
        item.setdefault("item_kind", "github_thread")
        item.setdefault("source", "github")
        item["thread_id"] = thread_id
        item["origin_ref"] = thread_id
        item["path"] = thread.get("path") or item.get("path")
        item["line"] = thread.get("line") or item.get("line")
        item["url"] = thread.get("url") or item.get("url")
        item["body"] = thread.get("body") or item.get("body")
        is_resolved = _thread_is_resolved(thread)
        is_outdated = is_stale_or_outdated_github_thread(thread)
        item["is_outdated"] = is_outdated
        if is_resolved:
            item["state"] = (
                item.get("state") if str(item.get("state") or "").lower() in GITHUB_TERMINAL_STATES else "closed"
            )
            item["status"] = "CLOSED"
            item["blocking"] = False
            item["handled"] = True
        elif _has_publish_ready_evidence(item):
            item["state"] = "publish_ready"
            item["status"] = item.get("status") or "OPEN"
            item["blocking"] = True
        elif is_outdated:
            item["state"] = "stale"
            item["status"] = "STALE"
            item["blocking"] = True
        else:
            item["state"] = "open"
            item["status"] = "OPEN"
            item["blocking"] = True
        if thread.get("viewer_replied") and thread.get("viewer_reply_url"):
            item["reply_evidence"] = {
                "reply_url": thread["viewer_reply_url"],
                "author_login": thread.get("viewer_login") or item.get("reply_author_login") or current_login,
            }
            item["reply_url"] = thread["viewer_reply_url"]
            item["reply_posted"] = True
        items[item_id] = item
    merged["items"] = items
    return merged


def _has_publish_ready_evidence(item: Mapping[str, Any]) -> bool:
    if isinstance(item.get("accepted_response"), Mapping):
        return True
    return _has_content(item.get("publish_resolution"))


def _session_items(session: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    raw_items = session.get("items") or {}
    if isinstance(raw_items, Mapping):
        return [item for item in raw_items.values() if isinstance(item, Mapping)]
    return [item for item in raw_items if isinstance(item, Mapping)]


def _item_kind(item: Mapping[str, Any]) -> str:
    return str(item.get("item_kind") or item.get("kind") or "").lower()


def _state(item: Mapping[str, Any]) -> str:
    return str(item.get("state") or item.get("status") or "").lower()


def _thread_identifier(row: Mapping[str, Any]) -> str | None:
    for key in ("thread_id", "remote_thread_id", "github_thread_id", "id", "node_id"):
        value = row.get(key)
        if value:
            return str(value)
    item_id = row.get("item_id")
    if isinstance(item_id, str) and item_id.startswith("github-thread:"):
        return item_id.split(":", 1)[1]
    return None


def _thread_is_resolved(thread: Mapping[str, Any]) -> bool:
    return is_resolved_github_thread(thread)


def _github_thread_requires_reply_evidence(
    item: Mapping[str, Any],
    remote_by_id: Mapping[str, Mapping[str, Any]],
) -> bool:
    thread_id = _thread_identifier(item)
    if thread_id and thread_id in remote_by_id:
        return _thread_is_resolved(remote_by_id[thread_id])
    return is_terminal_github_thread(item)


def _has_reply_evidence(item: Mapping[str, Any], current_login: str | None) -> bool:
    evidence = item.get("reply_evidence")
    if isinstance(evidence, Mapping):
        reply_url = evidence.get("reply_url") or evidence.get("url") or evidence.get("external_url")
        author_login = evidence.get("author_login") or evidence.get("login")
        if not author_login and isinstance(evidence.get("author"), Mapping):
            author_login = evidence["author"].get("login")
        return bool(reply_url) and _login_matches(author_login, current_login)

    reply_url = item.get("reply_url") or item.get("reply_evidence_url")
    reply_posted = item.get("reply_posted", True)
    author_login = item.get("reply_author_login")
    return bool(reply_url) and bool(reply_posted) and _login_matches(author_login, current_login)


def _login_matches(author_login: Any, current_login: str | None) -> bool:
    if not current_login or not author_login:
        return True
    return str(author_login) == current_login


def _is_current_login_pending_review(review: Mapping[str, Any], current_login: str | None) -> bool:
    if str(review.get("state") or "").upper() != "PENDING":
        return False
    if not current_login:
        return True
    return _review_login(review) == current_login


def _review_login(review: Mapping[str, Any]) -> str | None:
    if review.get("author_login"):
        return str(review["author_login"])
    if isinstance(review.get("user"), Mapping) and review["user"].get("login"):
        return str(review["user"]["login"])
    if isinstance(review.get("author"), Mapping) and review["author"].get("login"):
        return str(review["author"]["login"])
    if review.get("login"):
        return str(review["login"])
    return None


def _check_bucket(check: Mapping[str, Any]) -> str:
    bucket = str(check.get("bucket") or "").strip().lower()
    if bucket in {"pass", "pending", "fail", "skipping", "cancel"}:
        return bucket
    state = str(check.get("state") or "").strip().lower()
    if state in {"success", "passed", "completed"}:
        return "pass"
    if state in {"queued", "pending", "in_progress", "requested", "waiting"}:
        return "pending"
    if state in {"failure", "failed", "error", "timed_out", "action_required"}:
        return "fail"
    if state in {"cancelled", "canceled", "neutral"}:
        return "cancel"
    if state in {"skipped", "skipping"}:
        return "skipping"
    return "unknown"


def _is_local_blocking(item: Mapping[str, Any]) -> bool:
    if "blocking" in item:
        return bool(item["blocking"])
    return _state(item) not in LOCAL_TERMINAL_STATES


def _is_blocking_item(item: Mapping[str, Any]) -> bool:
    if _item_kind(item) == "local_finding":
        return _is_local_blocking(item)
    return bool(item.get("blocking"))


def _is_terminal_local_item(item: Mapping[str, Any]) -> bool:
    return _state(item) in LOCAL_TERMINAL_STATES


def _has_validation_evidence(item: Mapping[str, Any]) -> bool:
    for key in ("validation_evidence", "validation_commands", "validation_results"):
        if _has_content(item.get(key)):
            return True
    evidence = item.get("evidence")
    if isinstance(evidence, Mapping):
        return _has_content(evidence.get("validation")) or _has_content(evidence.get("validation_evidence"))
    if _has_content(item.get("resolution_note")) and str(item.get("decision") or "").lower() in {
        "accept",
        "manual",
        "sync",
    }:
        return True
    return False


def _has_content(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, Mapping):
        return bool(value)
    if isinstance(value, Iterable):
        return any(True for _ in value)
    return bool(value)


def _final_gate_commands(repo: str, pr_number: str) -> dict[str, str]:
    if not repo or not pr_number:
        return {}
    return {
        "address": f"gh-address-cr address {repo} {pr_number} --lean",
        "publish": f"gh-address-cr agent publish {repo} {pr_number}",
        "final_gate": f"gh-address-cr final-gate {repo} {pr_number}",
        "fix_all": (
            f"gh-address-cr agent fix-all {repo} {pr_number} "
            "--commit <sha> --files <paths> --validation <cmd=passed>"
        ),
        "resolve_stale": (
            f"gh-address-cr agent resolve-stale {repo} {pr_number} "
            "--commit <sha> --files <paths> --validation <cmd=passed> --match-files"
        ),
    }


def _next_action(reason_code: str | None, *, repo: str = "", pr_number: str = "", passed: bool = False) -> str:
    if reason_code is None:
        if passed:
            return "Completion may be claimed."
        return "Status unknown: pending check results."
    if repo and pr_number:
        final_gate = f"`gh-address-cr final-gate {repo} {pr_number}`"
        if reason_code == FINAL_GATE_UNRESOLVED_REMOTE_THREADS:
            return f"Run `gh-address-cr address {repo} {pr_number} --lean`, publish accepted evidence, then rerun {final_gate}."
        if reason_code == FINAL_GATE_MISSING_REPLY_EVIDENCE:
            return f"Run `gh-address-cr agent publish {repo} {pr_number}`, then rerun {final_gate}."
        if reason_code == FINAL_GATE_PENDING_CURRENT_LOGIN_REVIEW:
            return f"Submit or dismiss pending reviews for the current GitHub login, then rerun {final_gate}."
        if reason_code == FINAL_GATE_BLOCKING_GITHUB_ITEMS:
            return f"Run `gh-address-cr agent publish {repo} {pr_number}` or `gh-address-cr address {repo} {pr_number} --lean`, then rerun {final_gate}."
        if reason_code == FINAL_GATE_BLOCKING_LOCAL_ITEMS:
            return f"Run `gh-address-cr review {repo} {pr_number}` or close/defer local items, then rerun {final_gate}."
        if reason_code == FINAL_GATE_MISSING_VALIDATION_EVIDENCE:
            return f"Run `gh-address-cr agent evidence add {repo} {pr_number} ...`, then rerun {final_gate}."
        if reason_code == FINAL_GATE_PR_CHECKS_NOT_GREEN:
            return f"Wait for PR checks to pass or fix failing checks, then rerun {final_gate}."
    if reason_code == FINAL_GATE_UNRESOLVED_REMOTE_THREADS:
        return "Resolve all remote GitHub review threads, then rerun final-gate."
    if reason_code == FINAL_GATE_MISSING_REPLY_EVIDENCE:
        return "Record durable reply evidence for terminal GitHub threads, then rerun final-gate."
    if reason_code == FINAL_GATE_PENDING_CURRENT_LOGIN_REVIEW:
        return "Submit or dismiss pending reviews for the current GitHub login, then rerun final-gate."
    if reason_code == FINAL_GATE_BLOCKING_GITHUB_ITEMS:
        return "Publish or resolve blocking GitHub review-thread items, then rerun final-gate."
    if reason_code == FINAL_GATE_BLOCKING_LOCAL_ITEMS:
        return "Close or explicitly defer blocking local items, then rerun final-gate."
    if reason_code == FINAL_GATE_MISSING_VALIDATION_EVIDENCE:
        return "Record validation evidence for terminal local findings, then rerun final-gate."
    if reason_code == FINAL_GATE_PR_CHECKS_NOT_GREEN:
        return "Wait for PR checks to pass or fix failing checks, then rerun final-gate."
    return "Inspect final-gate diagnostics, fix blockers, then rerun final-gate."
