# BCIJelly

## Welcome

Welcome to BCIJelly, a Python toolkit for invasive BCI workflows.

BCIJelly provides a unified pipeline for:

- loading datasets
- splitting train/val/test data
- creating and training baseline models
- evaluating model performance
- summarizing experiment outputs

## Install

Install from PyPI:

```bash
pip install -U bcijelly
```

Install LFADS extras only when needed:

```bash
pip install -U "bcijelly[lfads]"
```

Verify installation:

```bash
python -c "import bcijelly; print(bcijelly.__file__)"
python -c "from bcijelly import load_data, summary; print('bcijelly import OK')"
```

## Links to Docs

Primary docs entry:

- [docs/General/overview.en.md](docs/General/overview.en.md)

Demo docs:

- [docs/Demo/demo.en.md](docs/Demo/demo.en.md)
- [docs/Demo/complex_scenarios.en.md](docs/Demo/complex_scenarios.en.md)

API docs:

- [docs/API/load_data.en.md](docs/API/load_data.en.md)
- [docs/API/model.en.md](docs/API/model.en.md)
- [docs/API/model.train.en.md](docs/API/model.train.en.md)
- [docs/API/model.test.en.md](docs/API/model.test.en.md)
- [docs/API/summary.en.md](docs/API/summary.en.md)

## License

BCIJelly is licensed under the MIT License.

- [LICENSE](LICENSE)

## Contributors

- Liyuan Han (hanliyuan@ion.ac.cn)

## References

Project-level publication references are not finalized yet.

- TODO: add official BCIJelly citation when available.

Related model reference:

- Sedler AR, Pandarinath C. lfads-torch: A modular and extensible implementation of latent factor analysis via dynamical systems. arXiv:2309.01230.
