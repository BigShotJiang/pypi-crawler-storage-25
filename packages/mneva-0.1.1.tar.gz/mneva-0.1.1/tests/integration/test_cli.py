from __future__ import annotations

import json
from pathlib import Path

from click.testing import CliRunner

from mneva.cli import app


def test_version_flag_prints_version() -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "0.1.1" in result.output


def test_help_lists_core_commands() -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for cmd in ("init", "capture", "search", "status", "forget", "config", "serve"):
        assert cmd in result.output


def test_init_creates_home_token_and_bootstrap(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["init"])
    assert result.exit_code == 0, result.output
    assert (tmp_mneva_home / "config.json").exists()
    cfg = json.loads((tmp_mneva_home / "config.json").read_text())
    assert len(cfg["token"]) == 32
    assert cfg["port"] == 7432
    assert (tmp_mneva_home / "bootstrap.md").exists()
    assert "Mneva Bootstrap" in (tmp_mneva_home / "bootstrap.md").read_text()
    assert "Token (save this — shown only on init)" in result.output
    assert cfg["token"] in result.output


def test_init_is_idempotent_but_does_not_overwrite_token(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init"])
    cfg_before = json.loads((tmp_mneva_home / "config.json").read_text())
    result = runner.invoke(app, ["init"])
    assert result.exit_code == 0
    cfg_after = json.loads((tmp_mneva_home / "config.json").read_text())
    assert cfg_before["token"] == cfg_after["token"]


def test_capture_writes_record_from_argument(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init"])
    result = runner.invoke(
        app,
        ["capture", "--scope", "ticket-7", "--tool", "claude-code", "Hello world"],
    )
    assert result.exit_code == 0, result.output
    files = list((tmp_mneva_home / "store").glob("*.md"))
    assert len(files) == 1
    body = files[0].read_text()
    assert "Hello world" in body
    assert "scope: ticket-7" in body
    assert "tool: claude-code" in body


def test_capture_reads_stdin_when_body_is_dash(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init"])
    result = runner.invoke(
        app, ["capture", "--scope", "s", "-"], input="from stdin\n"
    )
    assert result.exit_code == 0, result.output
    files = list((tmp_mneva_home / "store").glob("*.md"))
    assert "from stdin" in files[0].read_text()


def test_capture_errors_when_body_omitted(tmp_mneva_home: Path) -> None:
    """Regression: omitting body must error, never silently read stdin.

    Earlier behavior fell through to sys.stdin.read() when body was None,
    which hung indefinitely against non-closing harness pipes.
    """
    runner = CliRunner()
    runner.invoke(app, ["init"])
    result = runner.invoke(app, ["capture", "--scope", "s"])
    assert result.exit_code != 0
    assert "body required" in result.output
    assert "'-' for stdin" in result.output


def test_search_returns_captured_record(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init"])
    runner.invoke(
        app,
        ["capture", "--scope", "s", "--lifespan", "permanent", "the brown fox jumps"],
    )
    result = runner.invoke(app, ["search", "brown fox"])
    assert result.exit_code == 0
    assert "brown fox" in result.output


def test_search_scope_filter(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init"])
    runner.invoke(app, ["capture", "--scope", "x", "--lifespan", "permanent", "alpha"])
    runner.invoke(app, ["capture", "--scope", "y", "--lifespan", "permanent", "alpha"])
    result = runner.invoke(app, ["search", "alpha", "--scope", "x"])
    assert result.exit_code == 0
    assert result.output.count("scope: x") == 1
    assert "scope: y" not in result.output


def test_status_reports_mode_and_count(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init"])
    runner.invoke(app, ["capture", "--scope", "s", "alpha"])
    runner.invoke(app, ["capture", "--scope", "s", "beta"])
    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "mode:" in result.output.lower()
    assert "count: 2" in result.output


def test_forget_requires_confirm_flag(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    runner.invoke(app, ["init"])
    out = runner.invoke(app, ["capture", "--scope", "s", "to-be-deleted"]).output.strip()
    record_id = out.splitlines()[-1]
    result = runner.invoke(app, ["forget", record_id])
    assert result.exit_code != 0
    result = runner.invoke(app, ["forget", record_id, "--confirm"])
    assert result.exit_code == 0
    assert (tmp_mneva_home / "store" / f"{record_id}.md").exists() is False


def test_serve_port_collision_returns_friendly_error(tmp_mneva_home: Path) -> None:
    import socket

    runner = CliRunner()
    runner.invoke(app, ["init"])
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    sock.listen(1)
    busy_port = sock.getsockname()[1]
    try:
        result = runner.invoke(app, ["serve", "--port", str(busy_port)])
        assert result.exit_code != 0
        assert f"port {busy_port} is already in use" in result.output.lower()
    finally:
        sock.close()


def test_serve_requires_init(tmp_mneva_home: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["serve"])
    assert result.exit_code != 0
    assert "run `mneva init` first" in result.output


def test_capture_collision_surfaces_friendly_message(
    tmp_mneva_home: Path, monkeypatch
) -> None:
    """Regression: FileExistsError from write_record must be caught + friendly."""
    runner = CliRunner()
    runner.invoke(app, ["init"])

    def _raise(*args: object, **kwargs: object) -> None:
        raise FileExistsError("simulated collision")

    monkeypatch.setattr("mneva.cli.write_record", _raise)
    result = runner.invoke(app, ["capture", "--scope", "s", "Hello"])
    assert result.exit_code != 0
    assert "record id collision" in result.output
    # Stack trace must NOT be in user output
    assert "Traceback" not in result.output
