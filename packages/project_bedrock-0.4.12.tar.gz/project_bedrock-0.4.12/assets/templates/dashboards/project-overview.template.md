---
note_type: dashboard
dashboard: project-overview
project: <project-name>
last_updated: <date>
tags:
  - bedrock
  - dashboard
---

# Project Overview

## Current State

- Memory root: [../Memory/PROJECT.md](../Memory/PROJECT.md)
- Evidence roots: [../Evidence/raw/README.md](../Evidence/raw/README.md), [../Evidence/imports/README.md](../Evidence/imports/README.md)

## Durable Changes

- No durable rollup recorded yet.

## Open Questions

- Which branch should be backfilled first?
