from inspqcommun.identity.keycloak_tools import KeycloakEnvironment
from requests import Response, get
import os
import socket
class UtilitaireNAMClient():
    __kcenv = None
    __headers = {}
    __unam_default_port = "14101"
    __generer_uri = "/generer"
    __valider_uri = "/valider"
    __info_uri = "/info"
    __province = "QC"
    __description_sexe = {
        "M": "MASCULIN",
        "F": "FEMININ"
    }
    __unam_base_url = None

    def __init__(self, unam_base_url:str=None):
        if 'UNAM_BASE_URL' in os.environ:
            self.__unam_base_url = f"{os.environ.get('UNAM_BASE_URL')}/nam"
        elif unam_base_url is not None:
            self.__unam_base_url = f"{unam_base_url}/nam"
        else:
            self.__unam_base_url = "http://{0}:{1}/nam".format(socket.getfqdn(), self.__unam_default_port)
        self.__kcenv = KeycloakEnvironment(defaultKeycloakEnabled=False)
        if self.__kcenv.keycloak_enabled:
            self.__headers = self.__kcenv.authenticate()

    def set_province(self, province:str) -> None:
        self.__province = province

    def get_province(self) -> str:
        return self.__province
    
    def generer(self, nom:str, prenom:str, date_naissance:str, sexe:str) -> Response:
        params = {
            "prenom": prenom,
            "nom": nom,
            "datenaissance": date_naissance,
            "sexe": sexe
        }
        rep = get(url=self.__unam_base_url+self.__generer_uri,
                  params=params,
                  headers=self.__headers)
        return rep
    
    def extraire_nam_generes_from_response(self, response:Response) -> list[str]:
        liste_nam = []
        if response.status_code == 200:
            liste_nam = response.json()
        return liste_nam
    
    def generer_une_liste_de_nam_pour_un_usager(self, nom:str, prenom:str, date_naissance:str, sexe:str) -> list[str]:
        return self.extraire_nam_generes_from_response(self.generer(nom=nom,
                                                                    prenom=prenom,
                                                                    date_naissance=date_naissance,
                                                                    sexe=sexe))
    
    def valider(self, nam:str, province:str = None) -> Response:
        params = {
            "nam": nam,
            "province": province if province is not None else self.get_province()
        }
        rep = get(url=self.__unam_base_url+self.__valider_uri,
                  params=params,
                  headers=self.__headers)
        return rep
    
    def extraire_validite_from_response(self, response:Response) -> bool:
        if response.status_code == 200:
            resultat = response.json()
        else:
            resultat = None
        return resultat
    
    def is_nam_valide(self, nam:str, province:str=None) -> bool:
        return self.extraire_validite_from_response(self.valider(nam=nam,
                                                                province=province))

    def info(self, nam:str) -> Response:
        params = {
            "nam": nam
        }
        rep = get(url=self.__unam_base_url+self.__info_uri,
                  params=params,
                  headers=self.__headers)
        return rep
    
    def extraire_info_from_response(self, response:Response) -> dict:
        if response.status_code == 200:
            return response.json()
        else:
            return {}

    def obtenir_les_info_pour_un_nam(self, nam:str) -> dict:
        return self.extraire_info_from_response(self.info(nam=nam))

    def get_description_sexe(self, code:str) -> str:
        return self.__description_sexe.get(code)