"""
Comprehensive v4 Test Suite

Tests every component of the fractal memory architecture
against the PRODUCTION database with 282K fragments.
"""
import os
import sys
import time
import json
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "src"))
os.environ["MEMORY_V3_DB"] = "C:/Users/Sean/Saranna/memory_v3_claude/memory.db"

from memory_v3.db import (
    get_connection, get_fragment, get_fragment_stats, add_fragment, add_edge,
    get_edges_from, get_edges_to, strengthen_edge, create_assembly, get_assembly,
    get_system_registry, get_edge_type_registry, register_system,
    get_fragment_by_hash, get_child_fragments, get_fragments_for_memory,
    log_correction, schedule_retrieval, get_due_retrievals,
    get_palace_stats, add_place, get_place, get_adjacent_places,
    anchor_fragment_to_place, get_fragments_at_place,
)

PASS = 0
FAIL = 0
ERRORS = []


def test(name, condition, detail=""):
    global PASS, FAIL, ERRORS
    if condition:
        PASS += 1
        print(f"  PASS: {name}")
    else:
        FAIL += 1
        ERRORS.append(f"{name}: {detail}")
        print(f"  FAIL: {name} -- {detail}")


def section(name):
    print(f"\n{'='*60}")
    print(f"  {name}")
    print(f"{'='*60}")


conn = get_connection()
print("=== V4 COMPREHENSIVE TEST SUITE ===")
print(f"Database: {os.environ['MEMORY_V3_DB']}")
print(f"Started: {time.strftime('%Y-%m-%d %H:%M:%S')}")

# ============================================================
section("1. SCHEMA & REGISTRIES")
# ============================================================

stats = get_fragment_stats(conn)
test("Fragments exist", stats["total_fragments"] > 200000,
     f"got {stats['total_fragments']}")
test("Edges exist", stats["total_edges"] > 500000,
     f"got {stats['total_edges']}")
test("Assemblies exist", stats["total_assemblies"] > 10000,
     f"got {stats['total_assemblies']}")

systems = get_system_registry(conn)
test("6 systems registered", len(systems) == 6, f"got {len(systems)}")
sys_names = {s["name"] for s in systems}
for expected in ["meaning", "timeline", "importance", "structure", "method", "reasoning"]:
    test(f"System '{expected}' exists", expected in sys_names)

edge_types = get_edge_type_registry(conn)
test("15+ edge types registered", len(edge_types) >= 15, f"got {len(edge_types)}")

# ============================================================
section("2. FRAGMENT CRUD")
# ============================================================

# Create a test fragment
fake_embed = np.random.randn(768).astype(np.float32)
fake_embed = (fake_embed / np.linalg.norm(fake_embed)).tolist()

fid = add_fragment(conn, "TEST: v4 test suite fragment", embedding=fake_embed,
                   content_type="fact", source="test_suite", importance=0.7)
test("Create fragment", fid > 0, f"id={fid}")

frag = get_fragment(conn, fid)
test("Read fragment", frag is not None)
test("Fragment content correct", frag["content"] == "TEST: v4 test suite fragment")
test("Fragment importance stored", abs(frag["importance"] - 0.7) < 0.01,
     f"got {frag['importance']}")
# get_fragment returns pre-increment row, so first read returns 0
# Second read should return 1
frag2 = get_fragment(conn, fid)
test("Access count increments on read", frag2["access_count"] >= 1, f"got {frag2['access_count']}")

# Hash lookup -- finds ANY fragment with this hash (may be from previous run)
import hashlib as _hl
expected_hash = _hl.sha256("TEST: v4 test suite fragment".encode()).hexdigest()[:16]
by_hash = get_fragment_by_hash(conn, expected_hash)
test("Lookup by hash finds match", by_hash is not None, f"hash={expected_hash}")
test("Hash lookup returns valid fragment", by_hash is not None and by_hash["content"] == "TEST: v4 test suite fragment")

# ============================================================
section("3. EDGE CRUD")
# ============================================================

fid2 = add_fragment(conn, "TEST: second fragment for edge testing",
                    embedding=fake_embed, source="test_suite")
fid3 = add_fragment(conn, "TEST: third fragment for edge testing",
                    embedding=fake_embed, source="test_suite")

eid = add_edge(conn, fid, fid2, "meaning", "SIMILAR_TO", weight=0.7)
test("Create edge", eid > 0)

eid2 = add_edge(conn, fid, fid3, "reasoning", "BECAUSE", weight=0.8)
test("Create edge different system", eid2 > 0)

edges = get_edges_from(conn, fid)
test("Get outgoing edges", len(edges) >= 2, f"got {len(edges)}")
test("Edges sorted by weight desc", edges[0]["weight"] >= edges[1]["weight"])

edges_to = get_edges_to(conn, fid2)
test("Get incoming edges", len(edges_to) >= 1)

# Strengthen
old_weight = edges[0]["weight"]
result = strengthen_edge(conn, fid, fid3, "BECAUSE", boost=0.1)
test("Strengthen edge returns True", result is True)
edges_after = get_edges_from(conn, fid, edge_type="BECAUSE")
test("Edge weight increased", edges_after[0]["weight"] > old_weight,
     f"was {old_weight}, now {edges_after[0]['weight']}")

# Auto-register new edge type
add_edge(conn, fid2, fid3, "meaning", "TEST_NEW_TYPE", weight=0.5)
new_types = get_edge_type_registry(conn)
found = [t for t in new_types if t["type_name"] == "TEST_NEW_TYPE"]
test("Auto-register new edge type", len(found) == 1)

# Duplicate edge handling (should update, not duplicate)
add_edge(conn, fid, fid2, "meaning", "SIMILAR_TO", weight=0.9)
edges_dedup = get_edges_from(conn, fid, system="meaning", edge_type="SIMILAR_TO")
test("Duplicate edge updates weight", len(edges_dedup) == 1,
     f"got {len(edges_dedup)} edges")

# ============================================================
section("4. ASSEMBLY CRUD")
# ============================================================

aid = create_assembly(conn, [fid, fid2, fid3], convergence_score=0.85,
                      confidence=0.9, contributing_systems=["meaning", "reasoning"])
test("Create assembly", aid > 0)

asm = get_assembly(conn, aid)
test("Read assembly", asm is not None)
test("Assembly fragment_ids is list", isinstance(asm["fragment_ids"], list))
test("Assembly has 3 fragments", len(asm["fragment_ids"]) == 3)
test("Assembly systems deserialized", "meaning" in asm["contributing_systems"])

# ============================================================
section("5. DECOMPOSITION")
# ============================================================

from memory_v3.lifecycle.decomposition import decompose

result = decompose("Sean chose PostgreSQL over MongoDB because of vector support. Docker is uninstalled.")
test("Decompose returns fragments", len(result["fragments"]) >= 2,
     f"got {len(result['fragments'])}")
test("Decompose returns edges", len(result["edges"]) >= 1,
     f"got {len(result['edges'])}")
test("Decompose method is rule", result["method"] == "rule")

# Empty input
empty = decompose("")
test("Empty input returns no fragments", len(empty["fragments"]) == 0)

# Short input
short = decompose("hi")
test("Short input returns no fragments", len(short["fragments"]) == 0)

# Long complex input
long_text = """The v4 architecture uses wave propagation for retrieval.
Each system runs an independent wave from entry points.
Convergence occurs when multiple waves arrive at the same fragment.
The error correction loop creates differentiating fragments.
The memory palace provides spatial anchoring for navigation."""
long_result = decompose(long_text)
test("Complex text produces 3+ fragments", len(long_result["fragments"]) >= 3,
     f"got {len(long_result['fragments'])}")

# ============================================================
section("6. DEDUPLICATION")
# ============================================================

from memory_v3.lifecycle.dedup import deduplicate_fragment, check_exact_duplicate

dup = check_exact_duplicate(conn, "TEST: v4 test suite fragment")
test("Exact dedup finds existing", dup is not None)
test("Exact dedup returns matching content", dup is not None and dup["content"] == "TEST: v4 test suite fragment")

no_dup = check_exact_duplicate(conn, "This text definitely does not exist anywhere")
test("Exact dedup returns None for new content", no_dup is None)

full_dedup = deduplicate_fragment(conn, "TEST: v4 test suite fragment", embedding=fake_embed)
test("Full dedup detects exact duplicate", full_dedup["is_duplicate"] is True)
test("Full dedup tier is exact", full_dedup["tier"] == "exact")

# ============================================================
section("7. COORDINATE PIPELINE")
# ============================================================

from memory_v3.scoring.coordinates import (
    compute_all_coordinates, compute_single_coordinate,
    build_metric_tensor, compute_fragment_vector, tensor_distance,
    tensor_similarity, DIMENSIONS, N_DIMS,
)
from memory_v3.scoring.importance import compute_importance

test("6 dimensions defined", N_DIMS == 6)
test("Dimensions are correct", DIMENSIONS == ["meaning", "timeline", "importance", "structure", "method", "reasoning"])

coords = compute_all_coordinates(
    "Sean decided to use PostgreSQL on 2026-03-05 because of vector support",
    governance_layer=3, content_type="decision", surprise_score=0.7,
)
test("Coordinates computed", len(coords) >= 2, f"got keys: {list(coords.keys())}")
test("Timeline extracted", "timeline" in coords)
test("Importance computed", "importance" in coords)
test("Reasoning detected", "reasoning" in coords)

# Importance scoring
imp_high = compute_importance("NEVER use Docker", governance_layer=1, protected=True)
imp_low = compute_importance("The weather is nice", governance_layer=4)
test("Protected rule has high importance", imp_high >= 0.9, f"got {imp_high}")
test("Ephemeral fact has low importance", imp_low < 0.5, f"got {imp_low}")
test("Importance ordering correct", imp_high > imp_low)

# ============================================================
section("8. METRIC TENSOR")
# ============================================================

g = build_metric_tensor()
test("Tensor is 6x6", g.shape == (6, 6))
test("Tensor is symmetric", np.allclose(g, g.T))
test("Diagonal is 1.0", np.allclose(np.diag(g), 1.0))
test("Off-diagonal has coupling", np.any(g[np.triu_indices(6, k=1)] > 0))

vec_a = compute_fragment_vector({"meaning_score": 0.9, "importance": 0.8,
    "timeline": time.time(), "reasoning": {"signals": [{"phrase": "because"}]}})
vec_b = compute_fragment_vector({"meaning_score": 0.2, "importance": 0.3})
test("Fragment vectors are 6-dim", vec_a.shape == (6,) and vec_b.shape == (6,))

dist = tensor_distance(vec_a, vec_b, g)
test("Tensor distance > 0", dist > 0, f"got {dist}")

sim = tensor_similarity(vec_a, vec_b, g)
test("Tensor similarity in [0,1]", 0 <= sim <= 1, f"got {sim}")

# Self-similarity should be 1.0
self_sim = tensor_similarity(vec_a, vec_a, g)
test("Self-similarity is 1.0", abs(self_sim - 1.0) < 0.001, f"got {self_sim}")

# ============================================================
section("9. CSR MATRIX CACHE")
# ============================================================

from memory_v3.cache.csr_manager import get_csr_manager

mgr = get_csr_manager()
start = time.monotonic()
mgr.rebuild(conn)
build_ms = (time.monotonic() - start) * 1000
cache_stats = mgr.stats()

test("CSR cache built", not cache_stats["dirty"])
test("CSR build < 10 seconds", build_ms < 10000, f"took {build_ms:.0f}ms")
test("Timeline system in cache", "timeline" in cache_stats["systems"])
test("Cache has edges", cache_stats["total_edges"] > 0,
     f"got {cache_stats['total_edges']}")

# ============================================================
section("10. WAVE PROPAGATION")
# ============================================================

from memory_v3.retrieval.wave import (
    propagate_single_system, find_entry_points_keyword,
    find_entry_points_importance,
)

# Entry point discovery
kw_entries = find_entry_points_keyword(conn, "memory", limit=5)
test("Keyword entry points found", len(kw_entries) > 0,
     f"got {len(kw_entries)}")

imp_entries = find_entry_points_importance(conn, min_importance=0.8, limit=5)
test("Importance entry points found", len(imp_entries) > 0,
     f"got {len(imp_entries)}")

# Single-system propagation
if kw_entries:
    start = time.monotonic()
    activations = propagate_single_system(conn, "timeline", kw_entries[:3])
    wave_ms = (time.monotonic() - start) * 1000
    test("Wave propagation returns results", len(activations) > 0,
         f"got {len(activations)} activations")
    test("Wave propagation < 100ms", wave_ms < 100, f"took {wave_ms:.1f}ms")
    test("Entry points have highest energy",
         all(activations.get(e[0], 0) >= 0.5 for e in kw_entries[:3] if e[0] in activations))

# ============================================================
section("11. CONVERGENCE DETECTION")
# ============================================================

from memory_v3.retrieval.convergence import detect_convergence, detect_convergence_single_system

# Create synthetic activations for testing
sys_acts = {
    "meaning": {fid: 0.9, fid2: 0.7, fid3: 0.3},
    "reasoning": {fid: 0.8, fid3: 0.6},
    "timeline": {fid: 0.7, fid2: 0.5},
}

convergence = detect_convergence(sys_acts, min_systems=2)
test("Convergence detected", len(convergence) > 0, f"got {len(convergence)}")
test("fid has highest convergence (3 systems)", convergence[0]["fragment_id"] == fid)
test("fid has system_count 3", convergence[0]["system_count"] == 3)
test("Convergence score > 0", convergence[0]["convergence_score"] > 0)

# Single system fallback
single = detect_convergence_single_system({"meaning": {fid: 0.9}})
test("Single system fallback works", len(single) > 0)

# No convergence case
no_conv = detect_convergence({"meaning": {fid: 0.9}}, min_systems=2)
test("No convergence with 1 system", len(no_conv) == 0)

# ============================================================
section("12. ASSEMBLY CONSTRUCTION")
# ============================================================

from memory_v3.retrieval.assembly import build_assembly

assembly = build_assembly(conn, convergence, context="test query", use_tensor_rerank=False)
test("Assembly built from convergence", assembly is not None)
if assembly:
    test("Assembly has fragments", assembly["fragment_count"] > 0)
    test("Assembly has convergence score", assembly["convergence_score"] > 0)
    test("Assembly has contributing systems", len(assembly["contributing_systems"]) > 0)
    test("Assembly tensor_reranked is False", assembly["tensor_reranked"] is False)

# With tensor re-ranking
query_coords = {"meaning_score": 0.9, "importance": 0.8,
    "reasoning": {"signals": [{"phrase": "because"}]}}
assembly_t = build_assembly(conn, convergence, context="test query",
                            use_tensor_rerank=True, query_coords=query_coords)
if assembly_t:
    test("Tensor re-ranked assembly built", assembly_t is not None)
    test("Tensor flag set", assembly_t["tensor_reranked"] is True)
    has_tensor = any(f.get("tensor_similarity") is not None for f in assembly_t["fragments"])
    test("Fragments have tensor_similarity", has_tensor)

# ============================================================
section("13. ERROR CORRECTION")
# ============================================================

from memory_v3.lifecycle.correction import correct_assembly as do_correct

# Create a wrong assembly to correct
wrong_aid = create_assembly(conn, [fid, fid2], convergence_score=0.75,
                            confidence=0.8, contributing_systems=["meaning"])
correction = do_correct(conn, wrong_aid,
    error_description="Fragment fid2 is wrong context",
    correct_info="The correct answer is something else entirely",
)
test("Correction returns result", "correction_id" in correction)
test("Differentiator created", correction.get("differentiator_id") is not None)
test("Correction strength > 0", correction.get("correction_strength", 0) > 0)
test("Scheduled retrievals created", correction.get("scheduled_retrievals", 0) > 0)

# Verify differentiator is protected
diff = get_fragment(conn, correction["differentiator_id"])
test("Differentiator is protected", diff["protected"] == 1)
test("Differentiator is governance layer 2", diff["governance_layer"] == 2)

# Verify CORRECTED_BY edges exist
corrected_edges = get_edges_from(conn, fid, edge_type="CORRECTED_BY")
test("CORRECTED_BY edges created", len(corrected_edges) > 0)

# ============================================================
section("14. NAVIGATION")
# ============================================================

from memory_v3.retrieval.navigate import navigate

# Forward
fwd = navigate(conn, fragment_id=fid, direction="forward", limit=5)
test("Forward navigation returns", "fragments" in fwd)

# Backward
bwd = navigate(conn, fragment_id=fid, direction="backward", limit=5)
test("Backward navigation returns", "fragments" in bwd)

# Lateral
lat = navigate(conn, fragment_id=fid, direction="lateral", limit=5)
test("Lateral navigation returns", "fragments" in lat)

# Why (causal)
why = navigate(conn, fragment_id=fid, direction="why", limit=5)
test("Why navigation returns", "fragments" in why)
test("Why has causal chain", "causal_chain" in why)

# What changed
wc = navigate(conn, fragment_id=fid, direction="what_changed", limit=5)
test("What_changed navigation returns", "fragments" in wc)

# Zoom (will be empty without hierarchy on test fragments)
zi = navigate(conn, fragment_id=fid, direction="zoom_in", limit=5)
test("Zoom_in navigation returns", "fragments" in zi)

zo = navigate(conn, fragment_id=fid, direction="zoom_out", limit=5)
test("Zoom_out navigation returns", "fragments" in zo)

# Invalid direction
bad = navigate(conn, fragment_id=fid, direction="invalid_direction")
test("Invalid direction returns error", "error" in bad)

# From assembly
asm_nav = navigate(conn, assembly_id=aid, direction="lateral", limit=5)
test("Navigate from assembly", "fragments" in asm_nav)

# ============================================================
section("15. PALACE")
# ============================================================

# Create test places
p1 = add_place(conn, "Test Building", "architectural", resolution=5)
test("Create place", p1 > 0)

p2 = add_place(conn, "Test Room", "architectural", parent_id=p1, resolution=3)
test("Create child place", p2 > 0)

from memory_v3.db import link_places
link_places(conn, p1, p2, "contains")

adj = get_adjacent_places(conn, p1)
test("Adjacent places found", len(adj) > 0)

anchor_fragment_to_place(conn, fid, p2)
frags_at = get_fragments_at_place(conn, p2)
test("Fragment anchored to place", len(frags_at) > 0)
test("Correct fragment at place", frags_at[0]["id"] == fid)

# Walk navigation
walk = navigate(conn, fragment_id=fid, direction="walk", limit=5)
test("Walk navigation returns", "fragments" in walk or "places_visited" in walk)

# ============================================================
section("16. PRODUCTION DATA INTEGRITY")
# ============================================================

# v3 memories untouched
mem_count = conn.execute("SELECT COUNT(*) FROM memories WHERE archived=0").fetchone()[0]
test("v3 memories intact", mem_count >= 17000, f"got {mem_count}")

# No orphan fragments (all have content)
orphans = conn.execute(
    "SELECT COUNT(*) FROM fragments WHERE content IS NULL OR content = ''"
).fetchone()[0]
test("No orphan fragments", orphans == 0, f"got {orphans}")

# Edge types all have registrations
unregistered = conn.execute(
    """SELECT DISTINCT edge_type FROM fragment_edges
    WHERE edge_type NOT IN (SELECT type_name FROM edge_type_registry)"""
).fetchall()
test("All edge types registered", len(unregistered) == 0,
     f"unregistered: {[r[0] for r in unregistered]}")

# Embeddings coverage
total_frags = conn.execute("SELECT COUNT(*) FROM fragments").fetchone()[0]
embedded = conn.execute("SELECT COUNT(*) FROM fragment_vec").fetchone()[0]
coverage = embedded * 100 // max(total_frags, 1)
test(f"Embedding coverage >= 80%", coverage >= 80, f"got {coverage}%")

# ============================================================
section("17. PERFORMANCE BENCHMARKS")
# ============================================================

# CSR build time (already measured above)
test(f"CSR build time: {build_ms:.0f}ms", True)

# Wave propagation timing
if kw_entries:
    times = []
    for _ in range(5):
        start = time.monotonic()
        propagate_single_system(conn, "timeline", kw_entries[:3])
        times.append((time.monotonic() - start) * 1000)
    avg_ms = sum(times) / len(times)
    p95_ms = sorted(times)[int(len(times) * 0.95)]
    test(f"Wave propagation avg: {avg_ms:.1f}ms", True)
    test(f"Wave propagation p95: {p95_ms:.1f}ms", p95_ms < 50)

# Fragment read timing
times = []
for _ in range(100):
    start = time.monotonic()
    get_fragment(conn, fid)
    times.append((time.monotonic() - start) * 1000)
avg_read = sum(times) / len(times)
test(f"Fragment read avg: {avg_read:.2f}ms", avg_read < 50)

# ============================================================
section("CLEANUP")
# ============================================================

# Remove test data
test_ids = [fid, fid2, fid3]
if correction.get("differentiator_id"):
    test_ids.append(correction["differentiator_id"])
if correction.get("correct_fragment_id"):
    test_ids.append(correction["correct_fragment_id"])

# Disable FK checks for cleanup
conn.execute("PRAGMA foreign_keys=OFF")
for tid in test_ids:
    conn.execute("DELETE FROM fragment_edges WHERE source_id=? OR target_id=?", (tid, tid))
    conn.execute("DELETE FROM fragment_places WHERE fragment_id=?", (tid,))
    conn.execute("DELETE FROM corrections WHERE confused_fragment_id=? OR correct_fragment_id=? OR differentiator_id=?", (tid, tid, tid))
    conn.execute("DELETE FROM retrieval_schedule WHERE fragment_id=?", (tid,))
conn.execute("DELETE FROM fragment_vec WHERE id IN ({})".format(",".join("?" * len(test_ids))), test_ids)
conn.execute("DELETE FROM fragments WHERE id IN ({})".format(",".join("?" * len(test_ids))), test_ids)
conn.execute("PRAGMA foreign_keys=ON")
conn.execute("DELETE FROM places WHERE name LIKE 'Test %'")
conn.execute("DELETE FROM place_adjacency WHERE place_a IN (SELECT id FROM places WHERE name LIKE 'Test %')")
conn.execute("DELETE FROM edge_type_registry WHERE type_name = 'TEST_NEW_TYPE'")
conn.commit()

post_clean = get_fragment_stats(conn)
test("Cleanup: fragment count stable",
     abs(post_clean["total_fragments"] - stats["total_fragments"]) < 10)

conn.close()

# ============================================================
print(f"\n{'='*60}")
print(f"  RESULTS: {PASS} passed, {FAIL} failed")
print(f"{'='*60}")
if ERRORS:
    print("\nFailed tests:")
    for e in ERRORS:
        print(f"  - {e}")
else:
    print("\nALL TESTS PASSED")
print(f"\nCompleted: {time.strftime('%Y-%m-%d %H:%M:%S')}")
