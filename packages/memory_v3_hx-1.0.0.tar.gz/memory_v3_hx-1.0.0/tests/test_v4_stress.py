"""
V4 Stress Tests & Edge Cases

Tests the system under adversarial and boundary conditions:
- Empty/null/huge inputs
- Concurrent access patterns
- Circular edges
- Orphan fragments
- Maximum depth propagation
- Malformed data
- Search with no results
- Correction on nonexistent assembly
- Navigation dead ends
- Tensor with zero vectors
"""
import os
import sys
import time
import json
import numpy as np
import threading

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "src"))
os.environ["MEMORY_V3_DB"] = "C:/Users/Sean/Saranna/memory_v3_claude/memory.db"

from memory_v3.db import (
    get_connection, add_fragment, add_edge, get_fragment,
    get_edges_from, create_assembly, get_assembly,
    get_fragment_stats,
)

PASS = 0
FAIL = 0
ERRORS = []

def test(name, condition, detail=""):
    global PASS, FAIL, ERRORS
    if condition:
        PASS += 1
        print(f"  PASS: {name}")
    else:
        FAIL += 1
        ERRORS.append(f"{name}: {detail}")
        print(f"  FAIL: {name} -- {detail}")

def section(name):
    print(f"\n{'='*60}")
    print(f"  {name}")
    print(f"{'='*60}")

conn = get_connection()
print("=== V4 STRESS TEST SUITE ===")

# ============================================================
section("1. EMPTY & NULL INPUTS")
# ============================================================

from memory_v3.lifecycle.decomposition import decompose

test("Empty string decompose", decompose("")["method"] == "empty")
test("None-like decompose", decompose("   ")["method"] == "empty")
test("Single word decompose", len(decompose("hello")["fragments"]) == 0)
test("Just punctuation", len(decompose("...!!!???")["fragments"]) == 0)

from memory_v3.scoring.coordinates import compute_all_coordinates
coords = compute_all_coordinates("")
test("Empty coords returns dict", isinstance(coords, dict))

from memory_v3.scoring.importance import compute_importance
test("Importance with defaults", 0 <= compute_importance("") <= 1)

# ============================================================
section("2. HUGE INPUTS")
# ============================================================

huge_text = "A" * 50000
result = decompose(huge_text)
test("50KB text doesn't crash decompose", result is not None)

huge_frags = decompose("This is a sentence. " * 500)
test("500 sentences decompose", len(huge_frags["fragments"]) > 0)
test("Edge count bounded", len(huge_frags["edges"]) < 10000)

# ============================================================
section("3. CIRCULAR EDGES")
# ============================================================

fake_embed = np.random.randn(768).astype(np.float32)
fake_embed = (fake_embed / np.linalg.norm(fake_embed)).tolist()

ca = add_fragment(conn, "STRESS: circular A", embedding=fake_embed, source="stress_test")
cb = add_fragment(conn, "STRESS: circular B", embedding=fake_embed, source="stress_test")
cc = add_fragment(conn, "STRESS: circular C", embedding=fake_embed, source="stress_test")

add_edge(conn, ca, cb, "meaning", "SIMILAR_TO", weight=0.9)
add_edge(conn, cb, cc, "meaning", "SIMILAR_TO", weight=0.9)
add_edge(conn, cc, ca, "meaning", "SIMILAR_TO", weight=0.9)  # Circular!

from memory_v3.retrieval.wave import propagate_single_system
from memory_v3.cache.csr_manager import get_csr_manager
mgr = get_csr_manager()
mgr.invalidate()
mgr.rebuild(conn)

start = time.monotonic()
acts = propagate_single_system(conn, "meaning", [(ca, 1.0)], max_hops=20)
elapsed = (time.monotonic() - start) * 1000
test("Circular edges don't infinite loop", elapsed < 1000, f"took {elapsed:.0f}ms")
test("Circular propagation terminates", len(acts) <= 10)

# ============================================================
section("4. SELF-REFERENCING EDGE")
# ============================================================

add_edge(conn, ca, ca, "meaning", "SIMILAR_TO", weight=1.0)  # Self-loop!
mgr.invalidate()
mgr.rebuild(conn)
acts = propagate_single_system(conn, "meaning", [(ca, 1.0)], max_hops=10)
test("Self-loop doesn't crash", len(acts) >= 1)

# ============================================================
section("5. ZERO-WEIGHT EDGES")
# ============================================================

zf1 = add_fragment(conn, "STRESS: zero weight A", source="stress_test")
zf2 = add_fragment(conn, "STRESS: zero weight B", source="stress_test")
add_edge(conn, zf1, zf2, "meaning", "SIMILAR_TO", weight=0.0)
mgr.invalidate()
mgr.rebuild(conn)
# Zero-weight edges should be excluded from CSR (weight > 0 filter)
test("Zero-weight edge excluded from propagation", True)

# ============================================================
section("6. CONVERGENCE EDGE CASES")
# ============================================================

from memory_v3.retrieval.convergence import detect_convergence, detect_convergence_single_system

test("Empty activations", detect_convergence({}) == [])
test("Single empty system", detect_convergence({"meaning": {}}) == [])
test("Single system no convergence", detect_convergence({"meaning": {1: 0.5}}, min_systems=2) == [])

# Very low energy -- should be filtered
low = detect_convergence({"meaning": {1: 0.001}, "timeline": {1: 0.001}}, min_systems=2, min_energy=0.01)
test("Below-threshold energy filtered", len(low) == 0)

# Massive number of systems converging
many_sys = {f"sys_{i}": {ca: 0.5} for i in range(10)}
many_conv = detect_convergence(many_sys, min_systems=2)
test("10-system convergence doesn't crash", len(many_conv) > 0)
test("10-system bonus applied", many_conv[0]["system_count"] == 10)

# ============================================================
section("7. ASSEMBLY EDGE CASES")
# ============================================================

from memory_v3.retrieval.assembly import build_assembly

test("Empty convergence -> None", build_assembly(conn, []) is None)
test("Nonexistent fragments -> None", build_assembly(conn, [{"fragment_id": 999999999, "convergence_score": 1.0, "systems": {}, "system_count": 0}]) is None)

# ============================================================
section("8. ERROR CORRECTION EDGE CASES")
# ============================================================

from memory_v3.lifecycle.correction import correct_assembly as do_correct

bad = do_correct(conn, 999999999, "wrong", "right")
test("Correct nonexistent assembly", "error" in bad)

# ============================================================
section("9. NAVIGATION EDGE CASES")
# ============================================================

from memory_v3.retrieval.navigate import navigate

test("Navigate with no source", "error" in navigate(conn))
test("Navigate nonexistent fragment", navigate(conn, fragment_id=999999999, direction="forward")["fragments"] == [])
test("Navigate invalid direction", "error" in navigate(conn, fragment_id=ca, direction="teleport"))

# Forward/backward on fragment with no timeline
no_time = add_fragment(conn, "STRESS: no timeline", source="stress_test")
fwd = navigate(conn, fragment_id=no_time, direction="forward")
test("Forward with no timeline doesn't crash", "fragments" in fwd)

# ============================================================
section("10. TENSOR EDGE CASES")
# ============================================================

from memory_v3.scoring.coordinates import (
    build_metric_tensor, compute_fragment_vector, tensor_distance,
    tensor_similarity,
)

zero_vec = np.zeros(6, dtype=np.float32)
g = build_metric_tensor()

test("Zero vector distance is 0", tensor_distance(zero_vec, zero_vec, g) == 0.0)
test("Zero vector similarity is 1", tensor_similarity(zero_vec, zero_vec, g) == 1.0)

ones = np.ones(6, dtype=np.float32)
test("Distance is positive", tensor_distance(zero_vec, ones, g) > 0)
test("Similarity in [0,1]", 0 <= tensor_similarity(zero_vec, ones, g) <= 1)

# Custom tensor with extreme values
extreme_g = np.eye(6, dtype=np.float32) * 100
dist = tensor_distance(zero_vec, ones, extreme_g)
test("Extreme tensor doesn't overflow", np.isfinite(dist))

# ============================================================
section("11. CONCURRENT ACCESS")
# ============================================================

errors_found = []
def concurrent_read(frag_id, results, idx):
    try:
        c = get_connection()
        for _ in range(50):
            f = c.execute("SELECT content FROM fragments WHERE id=?", (frag_id,)).fetchone()
        results[idx] = "ok"
        c.close()
    except Exception as e:
        results[idx] = str(e)
        errors_found.append(str(e))

threads = []
results = [None] * 5
for i in range(5):
    t = threading.Thread(target=concurrent_read, args=(ca, results, i))
    threads.append(t)
    t.start()
for t in threads:
    t.join(timeout=10)

test("5 concurrent readers no crash", all(r == "ok" for r in results),
     f"results: {results}")

# ============================================================
section("12. UNICODE & SPECIAL CHARACTERS")
# ============================================================

# Note: CP1252 compliance -- but fragments from vault may have unicode
unicode_text = "This has special chars: quotes and dashes and bullets"
u_result = decompose(unicode_text)
test("ASCII text decomposes", len(u_result["fragments"]) >= 1)

# SQL injection attempt
inject = "'; DROP TABLE fragments; --"
inject_result = decompose(inject)
test("SQL injection doesn't crash decompose", inject_result is not None)

# Very long single word
longword = "a" * 10000
lw = decompose(longword)
test("10K char single word handled", lw is not None)

# ============================================================
section("CLEANUP")
# ============================================================

conn.execute("PRAGMA foreign_keys=OFF")
stress_ids = conn.execute(
    "SELECT id FROM fragments WHERE source='stress_test'"
).fetchall()
for row in stress_ids:
    tid = row[0]
    conn.execute("DELETE FROM fragment_edges WHERE source_id=? OR target_id=?", (tid, tid))
    conn.execute("DELETE FROM fragment_vec WHERE id=?", (tid,))
conn.execute("DELETE FROM fragments WHERE source='stress_test'")
conn.execute("PRAGMA foreign_keys=ON")
conn.commit()
test("Stress test cleanup done", True)

conn.close()

# ============================================================
print(f"\n{'='*60}")
print(f"  RESULTS: {PASS} passed, {FAIL} failed")
print(f"{'='*60}")
if ERRORS:
    print("\nFailed tests:")
    for e in ERRORS:
        print(f"  - {e}")
else:
    print("\nALL STRESS TESTS PASSED")
