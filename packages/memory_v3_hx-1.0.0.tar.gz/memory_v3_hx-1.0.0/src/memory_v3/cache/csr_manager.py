"""
v4 CSR Matrix Cache Manager

Loads fragment_edges from SQLite into scipy.sparse CSR matrices for fast
wave propagation. One matrix per system. Lazy load on first access,
background refresh on writes.

Performance target: ~100ms initial load, 0ms per query after caching.
Memory target: <500MB at 100K nodes.
"""

import sqlite3
import threading
import time
from collections import defaultdict

import numpy as np
from scipy.sparse import csr_matrix

from ..db import get_system_registry


class CSRManager:
    """Manages per-system CSR adjacency matrices for wave propagation."""

    def __init__(self):
        self._matrices: dict[str, csr_matrix] = {}
        self._node_maps: dict[str, dict[int, int]] = {}  # system -> {fragment_id: matrix_idx}
        self._reverse_maps: dict[str, dict[int, int]] = {}  # system -> {matrix_idx: fragment_id}
        self._dirty = True
        self._lock = threading.Lock()
        self._last_build_time = 0.0
        self._edge_count = 0

    def get_matrix(self, conn: sqlite3.Connection, system: str) -> tuple[csr_matrix | None, dict, dict]:
        """Get the CSR matrix for a system. Rebuilds if dirty.

        Returns: (matrix, node_map, reverse_map) or (None, {}, {}) if no edges.
        """
        if self._dirty:
            self.rebuild(conn)
        return (
            self._matrices.get(system),
            self._node_maps.get(system, {}),
            self._reverse_maps.get(system, {}),
        )

    def rebuild(self, conn: sqlite3.Connection):
        """Rebuild all CSR matrices from fragment_edges table."""
        with self._lock:
            if not self._dirty:
                return

            start = time.monotonic()

            # Load all edges grouped by system
            rows = conn.execute(
                """SELECT source_id, target_id, system, weight
                FROM fragment_edges
                WHERE weight > 0
                ORDER BY system"""
            ).fetchall()

            # Group edges by system
            system_edges: dict[str, list[tuple[int, int, float]]] = defaultdict(list)
            for row in rows:
                src, tgt, sys, wt = row[0], row[1], row[2], row[3]
                system_edges[sys].append((src, tgt, wt))

            self._matrices.clear()
            self._node_maps.clear()
            self._reverse_maps.clear()
            self._edge_count = 0

            for sys, edges in system_edges.items():
                if not edges:
                    continue

                # Build node ID mapping (fragment_id -> contiguous index)
                all_nodes = set()
                for src, tgt, _ in edges:
                    all_nodes.add(src)
                    all_nodes.add(tgt)

                sorted_nodes = sorted(all_nodes)
                node_map = {fid: idx for idx, fid in enumerate(sorted_nodes)}
                reverse_map = {idx: fid for fid, idx in node_map.items()}
                n = len(sorted_nodes)

                # Build COO data
                row_indices = []
                col_indices = []
                weights = []
                for src, tgt, wt in edges:
                    row_indices.append(node_map[src])
                    col_indices.append(node_map[tgt])
                    weights.append(wt)

                # Create CSR matrix
                matrix = csr_matrix(
                    (np.array(weights, dtype=np.float32),
                     (np.array(row_indices, dtype=np.int32),
                      np.array(col_indices, dtype=np.int32))),
                    shape=(n, n),
                )

                self._matrices[sys] = matrix
                self._node_maps[sys] = node_map
                self._reverse_maps[sys] = reverse_map
                self._edge_count += len(edges)

            self._dirty = False
            self._last_build_time = time.monotonic() - start

    def invalidate(self):
        """Mark matrices as dirty. Next access triggers rebuild."""
        self._dirty = True

    def stats(self) -> dict:
        """Return cache statistics."""
        system_stats = {}
        for sys, matrix in self._matrices.items():
            system_stats[sys] = {
                "nodes": matrix.shape[0],
                "edges": matrix.nnz,
                "density": matrix.nnz / max(matrix.shape[0] ** 2, 1),
                "memory_bytes": matrix.data.nbytes + matrix.indices.nbytes + matrix.indptr.nbytes,
            }
        return {
            "systems": system_stats,
            "total_edges": self._edge_count,
            "dirty": self._dirty,
            "last_build_seconds": round(self._last_build_time, 4),
        }


# Module-level singleton
_manager = CSRManager()


def get_csr_manager() -> CSRManager:
    """Get the global CSR manager singleton."""
    return _manager
