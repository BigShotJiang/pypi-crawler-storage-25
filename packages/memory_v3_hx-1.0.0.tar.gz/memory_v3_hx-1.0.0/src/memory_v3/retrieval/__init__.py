"""
memory-v3/v4 -- Retrieval Subpackage

v3: 3-stage search pipeline (coarse -> fine -> organize) on memories.
v4: Wave propagation + convergence detection on fragments.

The v4 pipeline runs first. If it finds convergence (2+ systems),
it returns the assembly. If not, it falls back to v3 3-stage search.

Public API
----------
search(conn, query, query_embedding, limit=10, content_type=None, config=None)
    Unified search: tries v4 wave propagation first, falls back to v3.
search_v4(conn, query, query_embedding, limit=10)
    Pure v4 wave propagation + convergence search.
"""

from __future__ import annotations

import logging
import sqlite3
import time
from typing import TYPE_CHECKING, Optional

from . import stage1_coarse, stage2_fine, stage3_organize

if TYPE_CHECKING:
    from ..config import Config

logger = logging.getLogger(__name__)

__all__ = [
    "search",
    "search_v4",
    "stage1_coarse",
    "stage2_fine",
    "stage3_organize",
]


def search_v4(
    conn: sqlite3.Connection,
    query: str,
    query_embedding: list[float],
    limit: int = 10,
    query_timestamp: float | None = None,
) -> dict | None:
    """v4 wave propagation + convergence search.

    Returns assembly dict if convergence found, None otherwise.
    """
    from .wave import propagate_all_systems
    from .convergence import detect_convergence, detect_convergence_single_system
    from .assembly import build_assembly

    start = time.monotonic()

    # Run wave propagation across all systems
    system_activations = propagate_all_systems(
        conn,
        query_embedding=query_embedding,
        query_text=query,
        query_timestamp=query_timestamp,
    )

    if not system_activations:
        return None

    propagation_ms = (time.monotonic() - start) * 1000

    # Detect convergence (2+ systems)
    convergence = detect_convergence(system_activations, min_systems=2)

    if not convergence:
        # Try single-system results as fallback within v4
        convergence = detect_convergence_single_system(system_activations)
        if not convergence:
            return None

    convergence_ms = (time.monotonic() - start) * 1000

    # Build query coordinates for tensor re-ranking
    query_coords = None
    try:
        from ..scoring.coordinates import compute_all_coordinates
        query_coords = compute_all_coordinates(query, query_timestamp=query_timestamp)
        # Add meaning score (self-similarity = 1.0 for the query itself)
        query_coords["meaning_score"] = 1.0
    except Exception:
        pass

    # Build assembly (with tensor re-ranking if query_coords available)
    assembly = build_assembly(
        conn, convergence[:limit], context=query,
        query_coords=query_coords,
    )

    total_ms = (time.monotonic() - start) * 1000

    if assembly:
        assembly["_timing"] = {
            "propagation_ms": round(propagation_ms, 1),
            "convergence_ms": round(convergence_ms - propagation_ms, 1),
            "assembly_ms": round(total_ms - convergence_ms, 1),
            "total_ms": round(total_ms, 1),
        }
        assembly["_systems_activated"] = list(system_activations.keys())

    return assembly


def search(
    conn: sqlite3.Connection,
    query: str,
    query_embedding: list[float],
    limit: int = 10,
    content_type: Optional[str] = None,
    config: Optional["Config"] = None,
) -> list[dict]:
    """
    Unified search pipeline: v4 wave propagation first, v3 fallback.

    v4 runs wave propagation across fragment systems, detects convergence,
    and builds assemblies. If v4 finds results, they're returned as
    fragment-based results. If not, falls back to v3 3-stage pipeline
    on the original memories table.

    Args:
        conn: SQLite connection with full v3+v4 schema.
        query: The raw user query string.
        query_embedding: Pre-computed embedding vector for the query.
        limit: Maximum number of results to return.
        content_type: Optional filter by content_type (fact, episode, etc.).
        config: Optional Config override.

    Returns:
        List of scored result dicts (from either v4 or v3 pipeline).
    """
    from ..config import get_config
    cfg = config or get_config()

    # Try v4 first (if fragments exist)
    try:
        frag_count = conn.execute("SELECT COUNT(*) FROM fragments").fetchone()[0]
    except Exception:
        frag_count = 0

    if frag_count > 0:
        assembly = search_v4(conn, query, query_embedding, limit=limit)
        if assembly and assembly.get("fragments"):
            # Convert assembly fragments to result format compatible with v3
            results = []
            for frag in assembly["fragments"]:
                results.append({
                    "id": frag["id"],
                    "content": frag["content"],
                    "content_type": "fragment",
                    "final_score": frag["convergence_score"],
                    "convergence_score": frag["convergence_score"],
                    "contributing_systems": frag.get("systems", {}),
                    "system_count": frag.get("system_count", 0),
                    "resolution_level": frag.get("resolution_level", 0),
                    "importance": frag.get("importance", 0.5),
                    "timeline_coord": frag.get("timeline_coord"),
                    "_source": "v4_wave",
                    "_assembly_id": assembly.get("assembly_id"),
                    "_timing": assembly.get("_timing"),
                })
            logger.info(
                "v4 search: %d fragments, convergence=%.3f, %s",
                len(results),
                assembly.get("convergence_score", 0),
                assembly.get("_timing", {}),
            )
            return results

    # Fall back to v3 3-stage pipeline
    logger.debug("v4 search returned no results; falling back to v3 pipeline")
    return _search_v3(conn, query, query_embedding, limit, content_type, cfg)


def _search_v3(
    conn: sqlite3.Connection,
    query: str,
    query_embedding: list[float],
    limit: int,
    content_type: Optional[str],
    cfg: "Config",
) -> list[dict]:
    """v3 3-stage search pipeline (preserved as fallback)."""
    if getattr(cfg, "enable_three_stage", True):
        candidates = stage1_coarse.get_candidates(conn, query, query_embedding, cfg)

        if not candidates:
            return _fallback_search(conn, query, query_embedding, limit, content_type)

        scored = stage2_fine.score_candidates(conn, candidates, query, query_embedding, cfg)

        if content_type:
            scored = [r for r in scored if r.get("content_type") == content_type]

        organized = stage3_organize.organize(conn, scored[:limit], query, cfg)
        return organized
    else:
        return _fallback_search(conn, query, query_embedding, limit, content_type)


def _fallback_search(
    conn: sqlite3.Connection,
    query: str,
    query_embedding: list[float],
    limit: int,
    content_type: Optional[str],
) -> list[dict]:
    """v2-compatible direct hybrid search with scoring."""
    from .. import db
    from ..scoring import rank_results

    results = db.hybrid_search(
        conn, query, query_embedding, limit=limit, content_type=content_type,
    )
    return rank_results(conn, results, query)
