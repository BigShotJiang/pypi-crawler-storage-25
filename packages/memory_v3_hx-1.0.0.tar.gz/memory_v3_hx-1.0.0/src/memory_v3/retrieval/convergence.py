"""
v4 Convergence Detection

Vivid recall = convergence: multiple waves from independent systems arriving
at the same fragment simultaneously. The more systems converge, the stronger
the recall.

Convergence scoring:
  - 1 system = recognition ("sounds familiar")
  - 2 systems = recall ("I remember something about that")
  - 3+ systems = vivid recall ("I remember exactly")

Score = geometric_mean(energies) * system_count_bonus
"""

from math import prod, log


def detect_convergence(
    system_activations: dict[str, dict[int, float]],
    min_systems: int = 2,
    min_energy: float = 0.01,
) -> list[dict]:
    """Detect convergence points across multiple system activations.

    Args:
        system_activations: {system_name: {fragment_id: energy}} from wave propagation.
        min_systems: Minimum number of systems that must converge (default 2).
        min_energy: Minimum energy from each system to count.

    Returns:
        Sorted list of convergence results:
        [{"fragment_id": int, "convergence_score": float,
          "systems": {name: energy}, "system_count": int}, ...]
    """
    if not system_activations:
        return []

    # Collect all activated fragments with their per-system energies
    fragment_systems: dict[int, dict[str, float]] = {}

    for sys_name, activations in system_activations.items():
        for frag_id, energy in activations.items():
            if energy >= min_energy:
                if frag_id not in fragment_systems:
                    fragment_systems[frag_id] = {}
                fragment_systems[frag_id][sys_name] = energy

    # Find convergence points (fragments activated by min_systems+ systems)
    results = []
    for frag_id, systems in fragment_systems.items():
        system_count = len(systems)
        if system_count < min_systems:
            continue

        energies = list(systems.values())

        # Geometric mean of energies (multiplicative, not additive)
        geo_mean = prod(energies) ** (1.0 / len(energies))

        # System count bonus: more systems converging = stronger signal
        # 2 systems = 1.0x, 3 = 1.5x, 4 = 2.0x, 5 = 2.5x, 6 = 3.0x
        system_bonus = 1.0 + (system_count - 2) * 0.5

        convergence_score = geo_mean * system_bonus

        results.append({
            "fragment_id": frag_id,
            "convergence_score": convergence_score,
            "systems": systems,
            "system_count": system_count,
        })

    # Sort by convergence score descending
    results.sort(key=lambda x: x["convergence_score"], reverse=True)
    return results


def detect_convergence_single_system(
    system_activations: dict[str, dict[int, float]],
    min_energy: float = 0.1,
) -> list[dict]:
    """Fallback: when only 1 system has activations, return top fragments.
    This is equivalent to v3-style single-system retrieval."""
    all_frags = {}
    for sys_name, activations in system_activations.items():
        for frag_id, energy in activations.items():
            if energy >= min_energy:
                if frag_id not in all_frags:
                    all_frags[frag_id] = {"systems": {}, "max_energy": 0.0}
                all_frags[frag_id]["systems"][sys_name] = energy
                all_frags[frag_id]["max_energy"] = max(
                    all_frags[frag_id]["max_energy"], energy
                )

    results = []
    for frag_id, info in all_frags.items():
        results.append({
            "fragment_id": frag_id,
            "convergence_score": info["max_energy"],
            "systems": info["systems"],
            "system_count": len(info["systems"]),
        })

    results.sort(key=lambda x: x["convergence_score"], reverse=True)
    return results
