"""
v4 Navigation Interface

Memory becomes browsable, not just searchable.
Every navigation action is a new wave propagation that reinforces traversed paths.

Operations:
- forward/backward: Temporal navigation along Timeline edges
- lateral: What else was happening at the same time?
- zoom_in/zoom_out: Resolution hierarchy traversal
- walk: Move through memory palace (spatial)
- why: Follow BECAUSE/DEPENDS_ON edges (causal reasoning)
- what_changed: Follow SUPERSEDES/EVOLVED_FROM edges
"""

import sqlite3

from ..db import (
    get_fragment, get_child_fragments, get_edges_from, get_edges_to,
    get_assembly, strengthen_edge, add_edge,
    get_place, get_adjacent_places, get_child_places, get_fragments_at_place,
)


def navigate(
    conn: sqlite3.Connection,
    assembly_id: int | None = None,
    fragment_id: int | None = None,
    direction: str = "forward",
    limit: int = 10,
) -> dict:
    """Navigate from an assembly or fragment.

    Args:
        assembly_id: Navigate from this assembly's fragments.
        fragment_id: Navigate from this specific fragment.
        direction: One of: forward, backward, lateral, zoom_in, zoom_out,
                   walk, why, what_changed
        limit: Max results.

    Returns:
        dict with navigated fragments and metadata.
    """
    # Get source fragments
    source_ids = []
    if assembly_id:
        assembly = get_assembly(conn, assembly_id)
        if assembly:
            source_ids = assembly.get("fragment_ids", [])
    if fragment_id:
        source_ids = [fragment_id]
    if not source_ids:
        return {"error": "No source fragments to navigate from"}

    handler = _HANDLERS.get(direction)
    if handler is None:
        return {"error": f"Unknown direction: {direction}. Valid: {list(_HANDLERS.keys())}"}

    results = handler(conn, source_ids, limit)

    # Reinforce traversed edges
    for r in results.get("fragments", []):
        for sid in source_ids[:3]:
            strengthen_edge(conn, sid, r["id"], "CO_DISCOVERED", boost=0.03)

    results["direction"] = direction
    results["source_ids"] = source_ids
    return results


# ---------- Direction handlers ----------

def _navigate_forward(conn, source_ids, limit):
    """Temporal: what was learned/decided next?"""
    fragments = []
    for sid in source_ids:
        # Get fragments with later timeline coordinates
        frag = get_fragment(conn, sid)
        if not frag or not frag.get("timeline_coord"):
            continue
        ts = frag["timeline_coord"]
        rows = conn.execute(
            """SELECT * FROM fragments
            WHERE timeline_coord > ? AND timeline_coord IS NOT NULL AND id NOT IN ({})
            ORDER BY timeline_coord ASC LIMIT ?""".format(
                ','.join('?' * len(source_ids))
            ),
            [ts] + source_ids + [limit]
        ).fetchall()
        for r in rows:
            fragments.append(dict(r))

    # Also follow PRECEDED_BY edges (reverse = what comes after)
    for sid in source_ids:
        edges = get_edges_to(conn, sid)
        for e in edges:
            if e["edge_type"] == "PRECEDED_BY":
                f = get_fragment(conn, e["source_id"])
                if f:
                    fragments.append(f)

    return {"fragments": _dedupe_and_limit(fragments, limit)}


def _navigate_backward(conn, source_ids, limit):
    """Temporal: what came before this?"""
    fragments = []
    for sid in source_ids:
        frag = get_fragment(conn, sid)
        if not frag or not frag.get("timeline_coord"):
            continue
        ts = frag["timeline_coord"]
        rows = conn.execute(
            """SELECT * FROM fragments
            WHERE timeline_coord < ? AND timeline_coord IS NOT NULL AND id NOT IN ({})
            ORDER BY timeline_coord DESC LIMIT ?""".format(
                ','.join('?' * len(source_ids))
            ),
            [ts] + source_ids + [limit]
        ).fetchall()
        for r in rows:
            fragments.append(dict(r))

    # Follow PRECEDED_BY edges forward
    for sid in source_ids:
        edges = get_edges_from(conn, sid, edge_type="PRECEDED_BY")
        for e in edges:
            f = get_fragment(conn, e["target_id"])
            if f:
                fragments.append(f)

    return {"fragments": _dedupe_and_limit(fragments, limit)}


def _navigate_lateral(conn, source_ids, limit):
    """What else was happening at the same time? CO_DISCOVERED edges."""
    fragments = []
    for sid in source_ids:
        edges = get_edges_from(conn, sid, edge_type="CO_DISCOVERED")
        for e in edges:
            if e["target_id"] not in source_ids:
                f = get_fragment(conn, e["target_id"])
                if f:
                    fragments.append(f)
        # Also check incoming CO_DISCOVERED
        edges_in = get_edges_to(conn, sid)
        for e in edges_in:
            if e["edge_type"] == "CO_DISCOVERED" and e["source_id"] not in source_ids:
                f = get_fragment(conn, e["source_id"])
                if f:
                    fragments.append(f)
    return {"fragments": _dedupe_and_limit(fragments, limit)}


def _navigate_zoom_in(conn, source_ids, limit):
    """Finer detail: expand to child fragments."""
    fragments = []
    for sid in source_ids:
        children = get_child_fragments(conn, sid)
        fragments.extend(children)
    if not fragments:
        return {"fragments": [], "note": "No finer-grained fragments available (already at leaf level)"}
    return {"fragments": _dedupe_and_limit(fragments, limit)}


def _navigate_zoom_out(conn, source_ids, limit):
    """Broader context: ascend to parent summary."""
    fragments = []
    for sid in source_ids:
        frag = get_fragment(conn, sid)
        if frag and frag.get("parent_id"):
            parent = get_fragment(conn, frag["parent_id"])
            if parent:
                fragments.append(parent)
    if not fragments:
        return {"fragments": [], "note": "No coarser-level summary available (already at top level)"}
    return {"fragments": _dedupe_and_limit(fragments, limit)}


def _navigate_walk(conn, source_ids, limit):
    """Move through memory palace: activate fragments at adjacent places."""
    fragments = []
    places_visited = []

    for sid in source_ids:
        # Find which place this fragment is anchored to
        row = conn.execute(
            "SELECT place_id FROM fragment_places WHERE fragment_id = ?", (sid,)
        ).fetchone()
        if not row:
            continue

        place_id = row[0]
        place = get_place(conn, place_id)
        if place:
            places_visited.append({"id": place_id, "name": place.get("name")})

        # Get adjacent places
        adjacent = get_adjacent_places(conn, place_id)
        for adj in adjacent:
            adj_frags = get_fragments_at_place(conn, adj["id"])
            fragments.extend(adj_frags)
            places_visited.append({"id": adj["id"], "name": adj.get("name")})

        # Also get child places (entering the room)
        children = get_child_places(conn, place_id)
        for child in children:
            child_frags = get_fragments_at_place(conn, child["id"])
            fragments.extend(child_frags)

    return {
        "fragments": _dedupe_and_limit(fragments, limit),
        "places_visited": places_visited[:limit],
    }


def _navigate_why(conn, source_ids, limit):
    """Reasoning: follow BECAUSE/DEPENDS_ON edges."""
    fragments = []
    chain = []
    for sid in source_ids:
        for edge_type in ("BECAUSE", "DEPENDS_ON", "DECIDED_OVER"):
            edges = get_edges_from(conn, sid, edge_type=edge_type)
            for e in edges:
                f = get_fragment(conn, e["target_id"])
                if f:
                    f["_edge_type"] = e["edge_type"]
                    f["_edge_weight"] = e["weight"]
                    fragments.append(f)
                    chain.append(f"f{sid} --{e['edge_type']}--> f{e['target_id']}")
            # Also check incoming (what caused THIS)
            edges_in = get_edges_to(conn, sid)
            for e in edges_in:
                if e["edge_type"] in ("BECAUSE", "DEPENDS_ON"):
                    f = get_fragment(conn, e["source_id"])
                    if f:
                        f["_edge_type"] = e["edge_type"]
                        fragments.append(f)
                        chain.append(f"f{e['source_id']} --{e['edge_type']}--> f{sid}")
    return {
        "fragments": _dedupe_and_limit(fragments, limit),
        "causal_chain": chain[:limit],
    }


def _navigate_what_changed(conn, source_ids, limit):
    """Follow SUPERSEDES/EVOLVED_FROM edges: how understanding changed."""
    fragments = []
    evolution = []
    for sid in source_ids:
        for edge_type in ("SUPERSEDES", "EVOLVED_FROM", "CORRECTED_BY"):
            edges = get_edges_from(conn, sid, edge_type=edge_type)
            for e in edges:
                f = get_fragment(conn, e["target_id"])
                if f:
                    f["_edge_type"] = e["edge_type"]
                    fragments.append(f)
                    evolution.append(f"f{sid} --{e['edge_type']}--> f{e['target_id']}")
            edges_in = get_edges_to(conn, sid)
            for e in edges_in:
                if e["edge_type"] in ("SUPERSEDES", "EVOLVED_FROM", "CORRECTED_BY"):
                    f = get_fragment(conn, e["source_id"])
                    if f:
                        f["_edge_type"] = e["edge_type"]
                        fragments.append(f)
                        evolution.append(f"f{e['source_id']} --{e['edge_type']}--> f{sid}")
    return {
        "fragments": _dedupe_and_limit(fragments, limit),
        "evolution_chain": evolution[:limit],
    }


def _dedupe_and_limit(fragments: list[dict], limit: int) -> list[dict]:
    """Deduplicate by ID and limit results."""
    seen = set()
    result = []
    for f in fragments:
        fid = f.get("id")
        if fid and fid not in seen:
            seen.add(fid)
            result.append({
                "id": fid,
                "content": f.get("content", ""),
                "importance": f.get("importance"),
                "resolution_level": f.get("resolution_level"),
                "timeline_coord": f.get("timeline_coord"),
            })
        if len(result) >= limit:
            break
    return result


# Handler registry
_HANDLERS = {
    "forward": _navigate_forward,
    "backward": _navigate_backward,
    "lateral": _navigate_lateral,
    "zoom_in": _navigate_zoom_in,
    "zoom_out": _navigate_zoom_out,
    "walk": _navigate_walk,
    "why": _navigate_why,
    "what_changed": _navigate_what_changed,
}
