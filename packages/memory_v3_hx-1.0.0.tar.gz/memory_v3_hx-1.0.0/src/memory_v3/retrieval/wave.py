"""
v4 Wave Propagation Engine

Retrieval is wave propagation: a cue activates entry-point fragments,
energy spreads along weighted edges, splits at nodes, loses energy per hop,
and gets boosted by strong connections.

Each system runs an independent wave. Convergence (detected in convergence.py)
happens when waves from 2+ systems arrive at the same fragment.

Algorithm: Budget-capped BFS with energy decay.
Performance: 10-30ms per system on 100K nodes with 500-node budget.
"""

import heapq
import sqlite3
import time
from collections import defaultdict

import numpy as np

from ..cache.csr_manager import get_csr_manager
from ..db import _serialize_f32, EMBEDDING_DIM


def propagate_single_system(
    conn: sqlite3.Connection,
    system: str,
    entry_points: list[tuple[int, float]],
    energy_loss: float = 0.3,
    fan_split: float = 0.5,
    boost_threshold: float = 0.1,
    max_hops: int = 8,
    budget: int = 500,
    min_energy: float = 0.01,
) -> dict[int, float]:
    """Run wave propagation from entry points through one system's graph.

    Args:
        conn: Database connection.
        system: System name (e.g., "meaning", "reasoning").
        entry_points: List of (fragment_id, initial_energy) tuples.
        energy_loss: Fraction of energy lost per hop (0.0 = no loss, 1.0 = total loss).
        fan_split: How much energy splits at branching nodes (0.0 = no split, 1.0 = divide equally).
        boost_threshold: Edge weight above which signal gets a 1.5x boost.
        max_hops: Maximum propagation depth.
        budget: Maximum nodes to activate (prevents runaway on dense graphs).
        min_energy: Minimum energy to continue propagating.

    Returns:
        dict of {fragment_id: energy} for all activated fragments.
    """
    mgr = get_csr_manager()
    matrix, node_map, reverse_map = mgr.get_matrix(conn, system)

    if matrix is None or not entry_points:
        return {}

    # Map entry points to matrix indices
    activations: dict[int, float] = {}  # fragment_id -> energy
    # Priority queue: (-energy, matrix_idx) -- max-energy-first via negation
    frontier = []

    for frag_id, energy in entry_points:
        if frag_id in node_map:
            idx = node_map[frag_id]
            heapq.heappush(frontier, (-energy, idx))
            activations[frag_id] = energy

    visited = set()
    hop = 0

    while frontier and len(visited) < budget and hop < max_hops:
        next_frontier = []

        # Process current frontier
        batch_size = min(len(frontier), budget - len(visited))
        for _ in range(batch_size):
            if not frontier:
                break

            neg_energy, idx = heapq.heappop(frontier)
            energy = -neg_energy

            if idx in visited or energy < min_energy:
                continue

            visited.add(idx)
            frag_id = reverse_map[idx]
            activations[frag_id] = max(activations.get(frag_id, 0.0), energy)

            # Get neighbors from CSR matrix
            row_start = matrix.indptr[idx]
            row_end = matrix.indptr[idx + 1]

            if row_start == row_end:
                continue  # No outgoing edges

            neighbor_indices = matrix.indices[row_start:row_end]
            neighbor_weights = matrix.data[row_start:row_end]
            fan_out = len(neighbor_indices)

            for n_idx, weight in zip(neighbor_indices, neighbor_weights):
                if n_idx in visited:
                    continue

                # Compute transmitted energy
                transmitted = energy * (1.0 - energy_loss) * float(weight)

                # Fan split: divide energy among neighbors
                if fan_split > 0 and fan_out > 1:
                    transmitted *= (1.0 - fan_split) + (fan_split / fan_out)

                # Boost for strong connections
                if float(weight) >= boost_threshold:
                    transmitted *= 1.5

                if transmitted >= min_energy:
                    heapq.heappush(next_frontier, (-transmitted, int(n_idx)))

        frontier = next_frontier
        hop += 1

    return activations


def find_entry_points_semantic(
    conn: sqlite3.Connection,
    query_embedding: list[float],
    limit: int = 5,
) -> list[tuple[int, float]]:
    """Find entry points for the Meaning system via vector similarity.

    Returns: list of (fragment_id, initial_energy) tuples.
    Energy is based on similarity (closer = higher energy).
    Handles both normalized and unnormalized stored vectors.
    """
    try:
        rows = conn.execute(
            """SELECT fv.id, fv.distance
            FROM fragment_vec fv
            WHERE fv.embedding MATCH ?
            ORDER BY fv.distance ASC
            LIMIT ?""",
            (_serialize_f32(query_embedding), limit)
        ).fetchall()

        if not rows:
            return []

        # Use relative ranking instead of absolute distance thresholds
        # (handles both normalized and unnormalized vectors)
        min_dist = rows[0][1]
        max_dist = rows[-1][1] if len(rows) > 1 else min_dist + 1.0

        results = []
        for row in rows:
            frag_id = row[0]
            l2_dist = row[1]
            # Convert to relative energy: closest = 1.0, farthest in batch = 0.1
            if max_dist > min_dist:
                energy = 1.0 - 0.9 * ((l2_dist - min_dist) / (max_dist - min_dist))
            else:
                energy = 1.0
            energy = max(0.1, energy)
            results.append((frag_id, energy))
        return results
    except Exception:
        return []


def find_entry_points_timeline(
    conn: sqlite3.Connection,
    target_timestamp: float,
    window_seconds: float = 86400 * 7,  # 1 week default window
    limit: int = 5,
) -> list[tuple[int, float]]:
    """Find entry points for the Timeline system via temporal proximity.

    Returns: list of (fragment_id, initial_energy) tuples.
    Energy decays with temporal distance.
    """
    try:
        rows = conn.execute(
            """SELECT id, timeline_coord
            FROM fragments
            WHERE timeline_coord IS NOT NULL
            AND ABS(timeline_coord - ?) < ?
            ORDER BY ABS(timeline_coord - ?) ASC
            LIMIT ?""",
            (target_timestamp, window_seconds, target_timestamp, limit)
        ).fetchall()

        results = []
        for row in rows:
            frag_id = row[0]
            ts = row[1]
            # Energy decays with temporal distance
            distance = abs(ts - target_timestamp)
            energy = max(0.1, 1.0 - (distance / window_seconds))
            results.append((frag_id, energy))
        return results
    except Exception:
        return []


def find_entry_points_importance(
    conn: sqlite3.Connection,
    min_importance: float = 0.7,
    limit: int = 5,
) -> list[tuple[int, float]]:
    """Find entry points for the Importance system -- high-importance fragments.

    Returns: list of (fragment_id, initial_energy) tuples.
    """
    try:
        rows = conn.execute(
            """SELECT id, importance
            FROM fragments
            WHERE importance >= ?
            ORDER BY importance DESC
            LIMIT ?""",
            (min_importance, limit)
        ).fetchall()
        return [(row[0], row[1]) for row in rows]
    except Exception:
        return []


def find_entry_points_keyword(
    conn: sqlite3.Connection,
    query: str,
    limit: int = 5,
) -> list[tuple[int, float]]:
    """Find entry points via FTS5 keyword search on fragments.

    Returns: list of (fragment_id, initial_energy) tuples.
    """
    try:
        # Escape FTS5 special characters
        escaped = ' '.join(f'"{w}"' for w in query.split() if w)
        rows = conn.execute(
            """SELECT f.id, 1.0 as energy
            FROM fragments f
            WHERE f.content LIKE ? OR f.content LIKE ?
            ORDER BY f.access_count DESC
            LIMIT ?""",
            (f'%{query}%', f'%{query.lower()}%', limit)
        ).fetchall()
        return [(row[0], row[1]) for row in rows]
    except Exception:
        return []


def propagate_all_systems(
    conn: sqlite3.Connection,
    query_embedding: list[float] | None = None,
    query_text: str | None = None,
    query_timestamp: float | None = None,
) -> dict[str, dict[int, float]]:
    """Run wave propagation across all enabled systems.

    Args:
        conn: Database connection.
        query_embedding: For Meaning system entry points.
        query_text: For keyword-based entry points.
        query_timestamp: For Timeline system entry points.

    Returns:
        dict of {system_name: {fragment_id: energy}} for each system.
    """
    from ..db import get_system_registry
    systems = get_system_registry(conn)
    all_activations = {}

    for sys_info in systems:
        sys_name = sys_info["name"]
        params = sys_info.get("propagation_params", {})

        # Find entry points based on system type
        entry_points = []

        if sys_name == "meaning" and query_embedding is not None:
            entry_points = find_entry_points_semantic(conn, query_embedding)

        elif sys_name == "timeline" and query_timestamp is not None:
            entry_points = find_entry_points_timeline(conn, query_timestamp)

        elif sys_name == "importance":
            entry_points = find_entry_points_importance(conn)

        elif sys_name == "reasoning" and query_embedding is not None:
            # Reasoning uses semantic entry points but propagates through causal edges
            entry_points = find_entry_points_semantic(conn, query_embedding, limit=3)

        elif sys_name == "method" and query_text is not None:
            entry_points = find_entry_points_keyword(conn, query_text, limit=3)

        elif sys_name == "structure":
            # Structure entry points come from palace (Phase 5) -- skip for now
            continue

        if not entry_points:
            continue

        # Propagate through this system's graph
        activations = propagate_single_system(
            conn, sys_name, entry_points,
            energy_loss=params.get("energy_loss", 0.3),
            fan_split=params.get("fan_split", 0.5),
            boost_threshold=params.get("boost_threshold", 0.1),
            max_hops=params.get("max_hops", 8),
        )

        if activations:
            all_activations[sys_name] = activations

    return all_activations
