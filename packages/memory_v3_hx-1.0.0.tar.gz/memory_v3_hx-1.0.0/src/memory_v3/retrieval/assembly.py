"""
v4 Assembly Construction

Takes convergence results and constructs an Assembly -- the v4 equivalent
of a "retrieved memory." An assembly is a real-time reconstruction from
fragments, ordered by timeline coordinate and annotated with convergence
metadata.

Optional tensor re-ranking: after convergence identifies candidates,
the metric tensor refines ordering by accounting for cross-dimensional
coupling that independent convergence scoring misses.
"""

import sqlite3

from ..db import get_fragment, create_assembly, add_edge


def build_assembly(
    conn: sqlite3.Connection,
    convergence_results: list[dict],
    context: str | None = None,
    max_fragments: int = 20,
    strengthen_edges: bool = True,
    use_tensor_rerank: bool = True,
    query_coords: dict | None = None,
) -> dict | None:
    """Build an assembly from convergence results.

    Args:
        conn: Database connection.
        convergence_results: Output from detect_convergence().
        context: The query/cue that triggered this assembly.
        max_fragments: Maximum fragments to include.
        strengthen_edges: Whether to strengthen edges between assembled fragments.
        use_tensor_rerank: Apply metric tensor re-ranking to refine ordering.
        query_coords: Query coordinate dict for tensor distance computation.

    Returns:
        Assembly dict with fragments, scores, and metadata, or None if empty.
    """
    if not convergence_results:
        return None

    # Take top fragments by convergence score
    top = convergence_results[:max_fragments]

    # Fetch full fragment data
    fragments = []
    fragment_ids = []
    for result in top:
        frag = get_fragment(conn, result["fragment_id"])
        if frag is None:
            continue
        frag["_convergence_score"] = result["convergence_score"]
        frag["_contributing_systems"] = result["systems"]
        frag["_system_count"] = result["system_count"]
        fragments.append(frag)
        fragment_ids.append(result["fragment_id"])

    if not fragments:
        return None

    # Tensor re-ranking: refine convergence scores with cross-dimensional coupling
    tensor_applied = False
    if use_tensor_rerank and query_coords:
        try:
            from ..scoring.coordinates import (
                compute_fragment_vector, tensor_similarity, get_metric_tensor,
            )
            g = get_metric_tensor()
            query_vec = compute_fragment_vector(query_coords)

            for frag in fragments:
                # Build coordinate dict for this fragment
                frag_coords = {
                    "meaning_score": 0.5,  # Default -- would need embedding similarity
                    "timeline": frag.get("timeline_coord"),
                    "importance": frag.get("importance", 0.5),
                    "structure": frag.get("structure_place_id"),
                    "method": None,
                    "reasoning": {"signals": []} if frag.get("_contributing_systems", {}).get("reasoning") else {},
                }
                # If reasoning system contributed, mark it
                if "reasoning" in frag.get("_contributing_systems", {}):
                    energy = frag["_contributing_systems"]["reasoning"]
                    frag_coords["reasoning"] = {"signals": [{"phrase": "has_reasoning", "role": "cause"}] * max(1, int(energy * 3))}
                if "meaning" in frag.get("_contributing_systems", {}):
                    frag_coords["meaning_score"] = frag["_contributing_systems"]["meaning"]

                frag_vec = compute_fragment_vector(frag_coords)
                t_sim = tensor_similarity(query_vec, frag_vec, g)

                # Blend: 70% convergence + 30% tensor similarity
                original = frag["_convergence_score"]
                frag["_tensor_similarity"] = round(t_sim, 4)
                frag["_convergence_score"] = round(original * 0.7 + t_sim * 0.3, 4)

            tensor_applied = True
        except Exception:
            pass  # Tensor is optional -- fall through to pure convergence

    # Sort by timeline coordinate (narrative order), then by convergence score
    fragments.sort(key=lambda f: (
        f.get("timeline_coord") or 0.0,
        -f.get("_convergence_score", 0.0),
    ))

    # Compute assembly-level scores
    avg_convergence = sum(f["_convergence_score"] for f in fragments) / len(fragments)
    max_convergence = max(f["_convergence_score"] for f in fragments)
    all_systems = set()
    for f in fragments:
        all_systems.update(f.get("_contributing_systems", {}).keys())

    # Confidence based on convergence strength and system coverage
    # More systems + higher convergence = higher confidence
    confidence = min(1.0, avg_convergence * (len(all_systems) / 6.0) * 2.0)

    # Persist the assembly
    assembly_id = create_assembly(
        conn,
        fragment_ids=[f["id"] for f in fragments],
        convergence_score=round(max_convergence, 4),
        confidence=round(confidence, 4),
        contributing_systems=sorted(all_systems),
        context=context,
    )

    # Strengthen edges between assembled fragments (retrieval reinforcement)
    if strengthen_edges and len(fragment_ids) > 1:
        _reinforce_assembly_edges(conn, fragment_ids)

    return {
        "assembly_id": assembly_id,
        "fragment_count": len(fragments),
        "convergence_score": round(max_convergence, 4),
        "avg_convergence": round(avg_convergence, 4),
        "confidence": round(confidence, 4),
        "contributing_systems": sorted(all_systems),
        "system_count": len(all_systems),
        "fragments": [
            {
                "id": f["id"],
                "content": f["content"],
                "convergence_score": round(f["_convergence_score"], 4),
                "systems": f.get("_contributing_systems", {}),
                "system_count": f.get("_system_count", 0),
                "resolution_level": f.get("resolution_level", 0),
                "importance": f.get("importance", 0.5),
                "timeline_coord": f.get("timeline_coord"),
                "tensor_similarity": f.get("_tensor_similarity"),
            }
            for f in fragments
        ],
        "tensor_reranked": tensor_applied,
    }


def _reinforce_assembly_edges(
    conn: sqlite3.Connection,
    fragment_ids: list[int],
    boost: float = 0.05,
):
    """Strengthen edges between fragments that were co-assembled.
    This is the retrieval reinforcement mechanism -- accessing fragments
    together makes their connections stronger."""
    from ..db import strengthen_edge, add_edge

    for i, fid_a in enumerate(fragment_ids):
        for fid_b in fragment_ids[i + 1:]:
            # Try to strengthen existing edge
            strengthened = strengthen_edge(
                conn, fid_a, fid_b, "CO_DISCOVERED", boost=boost
            )
            if not strengthened:
                # Also try reverse direction
                strengthen_edge(
                    conn, fid_b, fid_a, "CO_DISCOVERED", boost=boost
                )
