"""
v4 Importance Scoring (replaces emotional V/A/D for knowledge artifacts)

Computes a 0.0-1.0 importance score based on:
- Governance layer (constitutional > legislative > factual > ephemeral)
- Surprise score (novel = more important)
- Access patterns (frequently accessed = more important)
- Content signals (decisions, corrections, rules > general facts)
"""

import re

# Governance layer base importance
GOVERNANCE_IMPORTANCE = {
    1: 0.95,  # Constitutional -- always critical
    2: 0.80,  # Legislative -- high importance
    3: 0.50,  # Factual -- moderate baseline
    4: 0.25,  # Ephemeral -- low baseline
}

# Content type importance modifiers
TYPE_MODIFIERS = {
    "identity": 0.15,
    "decision": 0.12,
    "correction": 0.12,
    "rule": 0.10,
    "person": 0.08,
    "episode": 0.05,
    "fact": 0.0,
}

# Keyword patterns that signal high importance
HIGH_IMPORTANCE_PATTERNS = [
    (r'\b(?:never|always|must|critical|important|rule)\b', 0.10),
    (r'\b(?:decided|chose|picked|selected)\b', 0.08),
    (r'\b(?:wrong|corrected|fixed|mistake|error)\b', 0.08),
    (r'\b(?:architecture|design|system|framework)\b', 0.05),
    (r'\b(?:hard rule|do not|don\'t|stop)\b', 0.10),
]


def compute_importance(
    content: str,
    governance_layer: int = 3,
    content_type: str = "fact",
    surprise_score: float = 0.5,
    access_count: int = 0,
    protected: bool = False,
) -> float:
    """Compute importance score for a fragment.

    Returns: float in [0.0, 1.0]
    """
    # Base from governance layer
    base = GOVERNANCE_IMPORTANCE.get(governance_layer, 0.5)

    # Content type modifier
    type_mod = TYPE_MODIFIERS.get(content_type, 0.0)

    # Surprise contributes (novel = important)
    surprise_mod = surprise_score * 0.15

    # Access frequency contributes (log scale, capped)
    import math
    access_mod = min(math.log(access_count + 1) / 10.0, 0.10)

    # Keyword pattern scan
    keyword_mod = 0.0
    content_lower = content.lower()
    for pattern, mod in HIGH_IMPORTANCE_PATTERNS:
        if re.search(pattern, content_lower):
            keyword_mod = max(keyword_mod, mod)  # Take highest, don't stack

    # Combine
    score = base + type_mod + surprise_mod + access_mod + keyword_mod

    # Protected floor
    if protected:
        score = max(score, 0.90)

    # Clamp
    return max(0.0, min(1.0, score))
