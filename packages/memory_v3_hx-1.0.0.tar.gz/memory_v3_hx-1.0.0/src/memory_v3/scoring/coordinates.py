"""
v4 Multi-System Coordinate Pipeline + Knowledge Metric Tensor

Each fragment is mapped using a metric tensor inspired by Einstein's
approach to spacetime -- a symmetric matrix that encodes BOTH the position
in each knowledge dimension AND how those dimensions interact.

The 6 knowledge dimensions:
  0. Meaning    -- semantic embedding similarity
  1. Timeline   -- temporal position
  2. Importance -- governance weight / criticality
  3. Structure  -- position in project architecture
  4. Method     -- procedural / action relevance
  5. Reasoning  -- causal chain position

The metric tensor g_ij is a 6x6 symmetric matrix (21 independent components)
that describes the local geometry of knowledge-space at each fragment.
Off-diagonal terms capture cross-dimensional relationships:
  g[meaning][reasoning] -- how semantic meaning curves near causal chains
  g[timeline][importance] -- how recency affects importance
  g[structure][meaning] -- how project location biases semantic relevance

Distance between two fragments follows the geodesic:
  ds^2 = sum_ij g_ij * dx_i * dx_j

This replaces 6 independent distance calculations with one unified metric.
"""

import re
from datetime import datetime, timezone
from typing import Callable

import numpy as np

from .importance import compute_importance

# ---------- Tensor dimensions ----------

DIMENSIONS = ["meaning", "timeline", "importance", "structure", "method", "reasoning"]
DIM_INDEX = {name: i for i, name in enumerate(DIMENSIONS)}
N_DIMS = len(DIMENSIONS)

# ---------- Coordinate function registry ----------

_COORD_FUNCTIONS: dict[str, Callable] = {}


def register_coordinate_fn(system_name: str, fn: Callable):
    """Register a coordinate computation function for a system.
    fn signature: (content: str, **kwargs) -> any"""
    _COORD_FUNCTIONS[system_name] = fn


# ---------- Built-in coordinate functions ----------

def _compute_meaning(content: str, embed_fn=None, **kwargs) -> list[float] | None:
    """Compute semantic embedding. Requires embed_fn."""
    if embed_fn is None:
        return None
    return embed_fn(content)


def _compute_timeline(content: str, **kwargs) -> float | None:
    """Extract temporal coordinate from content.
    Returns unix timestamp or None."""
    # Try explicit date patterns
    date_patterns = [
        (r'\b(\d{4}-\d{2}-\d{2})\b', '%Y-%m-%d'),
        (r'\b(\d{4}-\d{2}-\d{2}T\d{2}:\d{2})\b', '%Y-%m-%dT%H:%M'),
    ]
    for pattern, fmt in date_patterns:
        match = re.search(pattern, content)
        if match:
            try:
                dt = datetime.strptime(match.group(1), fmt).replace(tzinfo=timezone.utc)
                return dt.timestamp()
            except ValueError:
                continue

    # Try dateutil for natural language dates
    try:
        from dateutil import parser as dateutil_parser
        # Look for month-day-year patterns
        month_patterns = [
            r'\b((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{1,2},?\s+\d{4})\b',
            r'\b(\d{1,2}/\d{1,2}/\d{2,4})\b',
        ]
        for pattern in month_patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                try:
                    dt = dateutil_parser.parse(match.group(1))
                    return dt.timestamp()
                except (ValueError, OverflowError):
                    continue
    except ImportError:
        pass

    # Use context timestamp if provided
    return kwargs.get("context_timestamp")


def _compute_importance_coord(content: str, **kwargs) -> float:
    """Compute importance score."""
    return compute_importance(
        content=content,
        governance_layer=kwargs.get("governance_layer", 3),
        content_type=kwargs.get("content_type", "fact"),
        surprise_score=kwargs.get("surprise_score", 0.5),
        access_count=kwargs.get("access_count", 0),
        protected=kwargs.get("protected", False),
    )


def _compute_structure(content: str, **kwargs) -> int | None:
    """Structure coordinate = place ID in memory palace.
    Returns None until Phase 5 (palace) is built."""
    return kwargs.get("structure_place_id")


def _compute_method(content: str, embed_fn=None, **kwargs) -> list[float] | None:
    """Compute procedural/method embedding.
    Extracts action phrases and embeds them.
    Falls back to full content embedding if no action phrases found."""
    if embed_fn is None:
        return None

    # Extract verb-led phrases (action patterns)
    action_patterns = [
        r'\b(run|execute|install|build|deploy|configure|set up|create|delete|update|restart|stop|start)\b[^.!?]*',
        r'\b(how to|steps to|process for|workflow for|procedure for)\b[^.!?]*',
        r'\b(use|apply|implement|call|invoke|trigger)\b[^.!?]*',
    ]

    action_text = ""
    content_lower = content.lower()
    for pattern in action_patterns:
        matches = re.findall(pattern, content_lower)
        if matches:
            action_text = content  # Use full content if it contains action language
            break

    if not action_text:
        return None  # Not a procedural fragment

    return embed_fn(action_text)


def _compute_reasoning(content: str, **kwargs) -> dict | None:
    """Reasoning coordinate = position in causal DAG.
    This is computed via edge creation (BECAUSE, DEPENDS_ON edges),
    not as a standalone coordinate. Returns metadata about causal signals found."""
    causal_signals = []
    content_lower = content.lower()

    causal_words = [
        ('because', 'cause'),
        ('therefore', 'effect'),
        ('so that', 'effect'),
        ('due to', 'cause'),
        ('as a result', 'effect'),
        ('depends on', 'dependency'),
        ('requires', 'dependency'),
        ('led to', 'effect'),
        ('caused by', 'cause'),
    ]
    for phrase, role in causal_words:
        if phrase in content_lower:
            causal_signals.append({"phrase": phrase, "role": role})

    return {"signals": causal_signals} if causal_signals else None


# Register built-in coordinate functions
register_coordinate_fn("meaning", _compute_meaning)
register_coordinate_fn("timeline", _compute_timeline)
register_coordinate_fn("importance", _compute_importance_coord)
register_coordinate_fn("structure", _compute_structure)
register_coordinate_fn("method", _compute_method)
register_coordinate_fn("reasoning", _compute_reasoning)


# ---------- Main pipeline ----------

def compute_all_coordinates(
    content: str,
    embed_fn=None,
    **kwargs,
) -> dict:
    """Compute coordinates for a fragment across all registered systems.

    Args:
        content: The fragment text.
        embed_fn: Embedding function (required for meaning/method systems).
        **kwargs: Additional context (governance_layer, content_type, surprise_score,
                  access_count, protected, context_timestamp, structure_place_id).

    Returns:
        dict of {system_name: coordinate_value} for each system that produced a result.
        Systems that return None are omitted.
    """
    results = {}
    for system_name, fn in _COORD_FUNCTIONS.items():
        try:
            value = fn(content, embed_fn=embed_fn, **kwargs)
            if value is not None:
                results[system_name] = value
        except Exception:
            continue
    return results


def compute_single_coordinate(
    system_name: str,
    content: str,
    embed_fn=None,
    **kwargs,
) -> any:
    """Compute a single system coordinate for a fragment."""
    fn = _COORD_FUNCTIONS.get(system_name)
    if fn is None:
        return None
    try:
        return fn(content, embed_fn=embed_fn, **kwargs)
    except Exception:
        return None


# ========== Knowledge Metric Tensor ==========

# Default cross-dimensional coupling strengths.
# These define how much each pair of dimensions influences each other.
# Diagonal = 1.0 (pure dimension). Off-diagonal = coupling strength.
# Tunable -- these are starting values based on domain knowledge.

DEFAULT_COUPLING = {
    ("meaning", "reasoning"):   0.6,   # Semantic meaning curves near causal chains
    ("meaning", "method"):      0.4,   # Related concepts share procedures
    ("meaning", "structure"):   0.3,   # Project location biases semantics
    ("timeline", "importance"): 0.5,   # Recency affects importance
    ("timeline", "reasoning"):  0.3,   # Causal chains have temporal ordering
    ("importance", "reasoning"):0.5,   # Important things tend to be causal
    ("importance", "structure"): 0.3,  # Critical things cluster in key places
    ("structure", "method"):    0.4,   # Same project area = similar procedures
    ("structure", "reasoning"): 0.2,   # Architectural position relates to causal role
    ("method", "reasoning"):    0.3,   # Procedures have causal logic
    ("meaning", "timeline"):    0.1,   # Weak: meaning doesn't depend much on time
    ("meaning", "importance"):  0.2,   # Somewhat: important things get richer semantics
    ("timeline", "method"):     0.1,   # Weak: procedures don't depend on when
    ("timeline", "structure"):  0.1,   # Weak: time doesn't determine location much
    ("method", "importance"):   0.2,   # Somewhat: critical procedures matter more
}


def build_metric_tensor(
    coupling: dict | None = None,
) -> np.ndarray:
    """Build the 6x6 knowledge metric tensor.

    The tensor is symmetric with 1.0 on diagonal and coupling
    strengths on off-diagonal elements.

    Returns: 6x6 numpy array (float32).
    """
    g = np.eye(N_DIMS, dtype=np.float32)
    couplings = coupling or DEFAULT_COUPLING

    for (dim_a, dim_b), strength in couplings.items():
        i = DIM_INDEX.get(dim_a)
        j = DIM_INDEX.get(dim_b)
        if i is not None and j is not None:
            g[i, j] = strength
            g[j, i] = strength  # Symmetric

    return g


def compute_fragment_vector(
    coordinates: dict,
) -> np.ndarray:
    """Convert a fragment's per-system coordinates into a 6-dim vector.

    Each dimension is normalized to [0, 1]:
    - meaning: cosine similarity to query (0-1), or 0.5 default
    - timeline: normalized timestamp (0-1 within a reasonable range)
    - importance: already 0-1
    - structure: 1.0 if placed, 0.0 if not
    - method: 1.0 if procedural, 0.0 if not
    - reasoning: count of causal signals, normalized

    Returns: 6-dim numpy array.
    """
    vec = np.zeros(N_DIMS, dtype=np.float32)

    # Meaning: use a default if embedding-based similarity isn't available
    vec[DIM_INDEX["meaning"]] = coordinates.get("meaning_score", 0.5)

    # Timeline: normalize timestamp to 0-1 range
    # Use a 1-year window centered on "now"
    ts = coordinates.get("timeline")
    if ts is not None:
        import time
        now = time.time()
        year_seconds = 365.25 * 86400
        normalized = 0.5 + (ts - now) / year_seconds
        vec[DIM_INDEX["timeline"]] = max(0.0, min(1.0, normalized))
    else:
        vec[DIM_INDEX["timeline"]] = 0.5

    # Importance: already 0-1
    vec[DIM_INDEX["importance"]] = coordinates.get("importance", 0.5)

    # Structure: binary -- has place or not
    vec[DIM_INDEX["structure"]] = 1.0 if coordinates.get("structure") else 0.0

    # Method: binary -- is procedural or not
    vec[DIM_INDEX["method"]] = 1.0 if coordinates.get("method") else 0.0

    # Reasoning: normalize causal signal count
    reasoning = coordinates.get("reasoning")
    if reasoning and isinstance(reasoning, dict):
        signals = reasoning.get("signals", [])
        vec[DIM_INDEX["reasoning"]] = min(1.0, len(signals) * 0.3)
    else:
        vec[DIM_INDEX["reasoning"]] = 0.0

    return vec


def tensor_distance(
    vec_a: np.ndarray,
    vec_b: np.ndarray,
    g: np.ndarray | None = None,
) -> float:
    """Compute geodesic distance between two fragments using the metric tensor.

    ds^2 = sum_ij g_ij * dx_i * dx_j

    This replaces 6 independent distance calculations with one unified metric
    that accounts for cross-dimensional coupling.

    Args:
        vec_a: 6-dim coordinate vector for fragment A.
        vec_b: 6-dim coordinate vector for fragment B.
        g: 6x6 metric tensor. Uses default if None.

    Returns: Distance (float). Lower = more related.
    """
    if g is None:
        g = build_metric_tensor()

    dx = vec_a - vec_b
    # ds^2 = dx^T @ g @ dx
    ds_squared = float(dx @ g @ dx)
    return max(0.0, ds_squared) ** 0.5


def tensor_similarity(
    vec_a: np.ndarray,
    vec_b: np.ndarray,
    g: np.ndarray | None = None,
) -> float:
    """Convert tensor distance to a similarity score (0-1).
    Higher = more similar."""
    dist = tensor_distance(vec_a, vec_b, g)
    # Map distance to similarity: e^(-dist^2)
    return float(np.exp(-dist * dist))


# Module-level cached tensor
_METRIC_TENSOR = None


def get_metric_tensor() -> np.ndarray:
    """Get the cached metric tensor (builds on first call)."""
    global _METRIC_TENSOR
    if _METRIC_TENSOR is None:
        _METRIC_TENSOR = build_metric_tensor()
    return _METRIC_TENSOR
