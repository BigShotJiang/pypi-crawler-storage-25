"""
v4 Error Correction Pipeline

When a retrieval is wrong, the system learns from the error:
1. Detect: Compare assembly against user correction
2. Surprise: correction_strength = confidence * error_magnitude
3. Separate: Push confused fragments apart (contrastive orthogonalization)
4. Differentiate: Create disambiguation fragment (protected from decay)
5. Schedule: Re-retrieval at spaced intervals (1, 3, 7, 21 days)

Based on:
- Hypercorrection effect (Metcalfe & Butterfield, 2012)
- Pattern separation (dentate gyrus, Yassa & Stark, 2011)
- Reconsolidation via prediction error (Nader, 2000; Sevenster et al., 2013)
- Contrastive learning (Khosla et al., 2020)
"""

import sqlite3

import numpy as np

from ..db import (
    add_fragment,
    add_edge,
    strengthen_edge,
    get_fragment,
    get_assembly,
    log_correction,
    schedule_retrieval,
    _serialize_f32,
    EMBEDDING_DIM,
)


def correct_assembly(
    conn: sqlite3.Connection,
    assembly_id: int,
    error_description: str,
    correct_info: str,
    embed_fn=None,
) -> dict:
    """Full error correction pipeline.

    Args:
        conn: Database connection.
        assembly_id: The assembly that was wrong.
        error_description: What was wrong about it.
        correct_info: What the correct answer should be.
        embed_fn: Embedding function for creating differentiator fragment.

    Returns:
        dict with correction details, new fragment IDs, edge changes.
    """
    # Step 0: Get the assembly
    assembly = get_assembly(conn, assembly_id)
    if assembly is None:
        return {"error": f"Assembly {assembly_id} not found"}

    confidence_at_error = assembly.get("confidence", 0.5)
    fragment_ids = assembly.get("fragment_ids", [])

    # Step 1: Compute surprise (hypercorrection scaling)
    # Higher confidence at time of error = stronger correction
    error_magnitude = 1.0  # Could be computed from semantic distance
    if embed_fn and correct_info:
        try:
            # Error magnitude = distance between wrong and right
            wrong_texts = []
            for fid in fragment_ids[:3]:  # Top 3 fragments
                frag = get_fragment(conn, fid)
                if frag:
                    wrong_texts.append(frag["content"])
            if wrong_texts:
                wrong_embedding = np.array(embed_fn(' '.join(wrong_texts)), dtype=np.float32)
                correct_embedding = np.array(embed_fn(correct_info), dtype=np.float32)
                # Cosine distance
                cos_sim = np.dot(wrong_embedding, correct_embedding) / (
                    np.linalg.norm(wrong_embedding) * np.linalg.norm(correct_embedding) + 1e-8
                )
                error_magnitude = max(0.1, 1.0 - cos_sim)
        except Exception:
            pass

    correction_strength = confidence_at_error * error_magnitude

    # Step 2: Create differentiating fragment
    diff_content = f"CORRECTION: {error_description}. Correct: {correct_info}"
    diff_embedding = embed_fn(diff_content) if embed_fn else None

    differentiator_id = add_fragment(
        conn,
        content=diff_content,
        embedding=diff_embedding,
        content_type="correction",
        source="error_correction",
        protected=True,  # Corrections are protected from decay
        governance_layer=2,  # Legislative -- high importance
        importance=min(1.0, 0.7 + correction_strength * 0.3),
    )

    # Step 3: Pattern separation -- push confused fragments apart
    # Create CORRECTED_BY edges from confused fragments to differentiator
    confused_fragment_id = fragment_ids[0] if fragment_ids else None
    for fid in fragment_ids[:5]:  # Link top fragments to correction
        add_edge(
            conn, fid, differentiator_id,
            system="reasoning",
            edge_type="CORRECTED_BY",
            weight=min(1.0, 0.5 + correction_strength * 0.5),
        )

    # Step 4: Create correct-info fragment if we have it
    correct_fragment_id = None
    if correct_info and embed_fn:
        correct_embedding = embed_fn(correct_info)
        correct_fragment_id = add_fragment(
            conn,
            content=correct_info,
            embedding=correct_embedding,
            content_type="fact",
            source="error_correction",
            importance=min(1.0, 0.6 + correction_strength * 0.4),
        )

        # Link differentiator to correct fragment
        add_edge(
            conn, differentiator_id, correct_fragment_id,
            system="reasoning",
            edge_type="BECAUSE",
            weight=0.9,
        )

        # Create REPULSION edges between confused and correct (push apart)
        for fid in fragment_ids[:3]:
            add_edge(
                conn, fid, correct_fragment_id,
                system="meaning",
                edge_type="REPULSION",
                weight=-0.3 * correction_strength,  # Negative weight
            )

        # Contrastive orthogonalization on embeddings
        # Nudge the confused fragments' importance down slightly
        for fid in fragment_ids[:3]:
            frag = get_fragment(conn, fid)
            if frag:
                current_imp = frag.get("importance", 0.5)
                # Don't modify protected fragments
                if not frag.get("protected"):
                    new_imp = max(0.1, current_imp - 0.1 * correction_strength)
                    conn.execute(
                        "UPDATE fragments SET importance = ? WHERE id = ?",
                        (new_imp, fid)
                    )

        # Boost correct fragment's importance
        conn.execute(
            "UPDATE fragments SET importance = ? WHERE id = ?",
            (min(1.0, 0.8 + correction_strength * 0.2), correct_fragment_id)
        )
        conn.commit()

    # Step 5: Log correction
    correction_id = log_correction(
        conn,
        assembly_id=assembly_id,
        confused_fragment_id=confused_fragment_id,
        correct_fragment_id=correct_fragment_id,
        differentiator_id=differentiator_id,
        error_description=error_description,
        correct_info=correct_info,
        surprise_score=error_magnitude,
        confidence_at_error=confidence_at_error,
        correction_strength=correction_strength,
    )

    # Step 6: Schedule spaced re-retrieval
    schedule_count = 0
    if correct_fragment_id:
        schedule_count = schedule_retrieval(
            conn, correct_fragment_id,
            correction_id=correction_id,
            context=f"Re-test correction: {error_description}",
        )
    if differentiator_id:
        schedule_count += schedule_retrieval(
            conn, differentiator_id,
            correction_id=correction_id,
            context=f"Reinforce differentiator: {error_description}",
        )

    return {
        "correction_id": correction_id,
        "differentiator_id": differentiator_id,
        "correct_fragment_id": correct_fragment_id,
        "correction_strength": round(correction_strength, 4),
        "error_magnitude": round(error_magnitude, 4),
        "confidence_at_error": round(confidence_at_error, 4),
        "edges_created": len(fragment_ids[:5]) + (2 if correct_fragment_id else 0),
        "repulsion_edges": min(3, len(fragment_ids)) if correct_fragment_id else 0,
        "scheduled_retrievals": schedule_count,
    }
