"""
v4 Fractal Hierarchy -- Auto-summarization

When a community of fragments stabilizes (appears in N+ consolidation cycles),
generate a summary fragment at the next resolution level. The summary's
coordinates are centroids of its children.

Resolution levels:
  0: atomic detail
  1: fact
  2: decision
  3: event
  4: episode
  5: project
  6: theme
"""

import logging
import sqlite3
import struct
from collections import defaultdict

from ..db import (
    add_fragment, add_edge, get_fragment, _now_iso, _serialize_f32,
)

log = logging.getLogger(__name__)


def discover_hierarchy(
    conn: sqlite3.Connection,
    min_cluster_size: int = 3,
    max_resolution: int = 6,
    llm_summarize_fn=None,
    target_level: int | None = None,
    embed_fn=None,
    max_cluster_size: int = 100,
) -> dict:
    """Discover fractal hierarchy from the fragment graph.

    Groups fragments by shared edges, creates parent summaries at higher
    resolution levels. This is the computational analog of Conway's SMS:
    event-specific knowledge -> general events -> lifetime periods.

    Args:
        conn: Database connection.
        min_cluster_size: Minimum fragments to form a cluster.
        max_resolution: Maximum resolution level to generate.
        llm_summarize_fn: Optional LLM function for generating summaries.
                          Signature: fn(texts: list[str]) -> str
        target_level: If given, only cluster fragments AT this level to
                      build level+1 summaries. If None, clusters unparented
                      fragments regardless of level (original behavior).
        embed_fn: Optional embedding function for new summaries.
                  Signature: fn(text: str) -> list[float]

    Returns:
        dict with stats about hierarchy changes.
    """
    stats = {"clusters_found": 0, "summaries_created": 0, "links_created": 0,
             "target_level": target_level}

    # Step 1: Find natural clusters via shared edges
    clusters = _find_clusters(conn, min_cluster_size, target_level=target_level)

    # Split any cluster bigger than max_cluster_size into chunks
    split_clusters = {}
    next_synth_id = -1
    for cid, members in clusters.items():
        if len(members) <= max_cluster_size:
            split_clusters[cid] = members
        else:
            # Split into chunks of max_cluster_size
            for chunk_start in range(0, len(members), max_cluster_size):
                chunk = members[chunk_start:chunk_start + max_cluster_size]
                if len(chunk) >= min_cluster_size:
                    split_clusters[next_synth_id] = chunk
                    next_synth_id -= 1
    clusters = split_clusters
    stats["clusters_found"] = len(clusters)
    log.info("discover_hierarchy: %d clusters after size-capping (max=%d)",
             len(clusters), max_cluster_size)

    # BATCH: preload resolution levels and importance for all clustered fragments
    all_cluster_ids = set()
    for fids in clusters.values():
        all_cluster_ids.update(fids)

    frag_meta = {}
    if all_cluster_ids:
        id_list = list(all_cluster_ids)
        for chunk_start in range(0, len(id_list), 5000):
            chunk = id_list[chunk_start:chunk_start + 5000]
            placeholders = ",".join("?" * len(chunk))
            rows = conn.execute(
                f"""SELECT id, resolution_level, importance, content
                FROM fragments WHERE id IN ({placeholders})""",
                chunk
            ).fetchall()
            for r in rows:
                frag_meta[r[0]] = {
                    "resolution_level": r[1] or 0,
                    "importance": r[2] if isinstance(r[2], (int, float)) else 0.5,
                    "content": r[3],
                }

    new_summary_ids = []
    # Collect all (parent_id, child_id) pairs for batch operations
    parent_updates = []  # list of (parent_id, child_id) tuples
    hierarchy_edge_rows = []  # list of edge tuples for batch insert

    # Step 2: Process each cluster
    for cluster_id, fragment_ids in clusters.items():
        if not fragment_ids:
            continue

        child_levels = [frag_meta.get(fid, {}).get("resolution_level", 0) for fid in fragment_ids]
        if not child_levels:
            continue

        max_child_level = max(child_levels)
        summary_level = min(max_child_level + 1, max_resolution)

        # If we have a target_level, enforce that summaries go to target_level+1
        if target_level is not None:
            summary_level = min(target_level + 1, max_resolution)

        child_contents = []
        for fid in fragment_ids[:10]:
            meta = frag_meta.get(fid)
            if meta and meta.get("content"):
                child_contents.append(meta["content"])

        if not child_contents:
            continue

        if llm_summarize_fn:
            try:
                summary_text = llm_summarize_fn(child_contents)
            except Exception:
                summary_text = _simple_summary(child_contents)
        else:
            summary_text = _simple_summary(child_contents)

        max_importance = max(
            (frag_meta.get(fid, {}).get("importance", 0.5) for fid in fragment_ids),
            default=0.5,
        )

        # Compute embedding for the new summary if fn provided
        summary_embedding = None
        if embed_fn is not None:
            try:
                summary_embedding = embed_fn(summary_text)
            except Exception as e:
                log.warning("Failed to embed summary: %s", e)

        parent_id = add_fragment(
            conn,
            content=summary_text,
            embedding=summary_embedding,
            content_type="summary",
            source="hierarchy_discovery",
            resolution_level=summary_level,
            importance=max_importance,
        )
        new_summary_ids.append(parent_id)
        stats["summaries_created"] += 1

        # Collect for batch operations (do NOT call add_edge per row)
        now_ts = _now_iso()
        for fid in fragment_ids:
            parent_updates.append((parent_id, fid))
            hierarchy_edge_rows.append(
                (parent_id, fid, "structure", 0.8, "HIERARCHY", now_ts, 0.1)
            )

        # Commit summaries in batches
        if stats["summaries_created"] % 50 == 0:
            conn.commit()

    conn.commit()

    # Batch-apply parent_id updates
    if parent_updates:
        log.info("Batch updating parent_id for %d children", len(parent_updates))
        conn.executemany(
            "UPDATE fragments SET parent_id = ? WHERE id = ?",
            parent_updates,
        )
        conn.commit()

    # Batch-insert HIERARCHY edges
    if hierarchy_edge_rows:
        log.info("Batch inserting %d HIERARCHY edges", len(hierarchy_edge_rows))
        # Ensure HIERARCHY is in the registry
        conn.execute(
            """INSERT INTO edge_type_registry (type_name, description, default_weight, default_system, first_seen)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(type_name) DO NOTHING""",
            ("HIERARCHY", "Parent-child resolution relationship", 0.8, "structure", _now_iso()),
        )
        conn.executemany(
            """INSERT INTO fragment_edges
            (source_id, target_id, system, weight, edge_type, created_at, decay_rate)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(source_id, target_id, edge_type) DO UPDATE SET
                weight = MAX(fragment_edges.weight, excluded.weight),
                last_traversed = excluded.created_at""",
            hierarchy_edge_rows,
        )
        conn.commit()
        stats["links_created"] = len(hierarchy_edge_rows)

    # Step 3: If we created summaries at a specific level, auto-link them
    # so the NEXT hierarchy pass can cluster them into the level above.
    if new_summary_ids and target_level is not None:
        target_summary_level = min(target_level + 1, max_resolution)
        linked = auto_link_summaries_at_level(conn, target_summary_level, embed_fn=embed_fn)
        stats["summary_links_created"] = linked

    return stats


def build_next_level(
    conn: sqlite3.Connection,
    from_level: int,
    min_cluster_size: int = 3,
    max_resolution: int = 6,
    llm_summarize_fn=None,
    embed_fn=None,
) -> dict:
    """Build level (from_level + 1) by clustering summaries at from_level.

    This is the explicit level-by-level builder. Prerequisites:
    - Summaries at from_level must have embeddings (for auto-linking)
    - SIMILAR_TO edges between same-level summaries will be auto-created

    Args:
        conn: Database connection.
        from_level: The resolution level to cluster (will build from_level + 1).
        min_cluster_size: Minimum fragments to form a cluster.
        max_resolution: Maximum resolution level (caps from_level + 1).
        llm_summarize_fn: Optional LLM summary function.
        embed_fn: Optional embedding function for new summaries.

    Returns:
        dict with stats including level_built.
    """
    if from_level >= max_resolution:
        return {"status": "max_resolution_reached", "level_built": None}

    log.info("Building level %d from level %d", from_level + 1, from_level)

    # Step 1: Ensure summaries at from_level have SIMILAR_TO edges to each other
    linked = auto_link_summaries_at_level(conn, from_level, embed_fn=embed_fn)
    log.info("Auto-linked %d pairs of level-%d summaries", linked, from_level)

    # Step 2: Cluster them
    stats = discover_hierarchy(
        conn,
        min_cluster_size=min_cluster_size,
        max_resolution=max_resolution,
        llm_summarize_fn=llm_summarize_fn,
        target_level=from_level,
        embed_fn=embed_fn,
    )

    stats["level_built"] = from_level + 1
    stats["summaries_auto_linked"] = linked
    return stats


def auto_link_summaries_at_level(
    conn: sqlite3.Connection,
    level: int,
    top_k: int = 5,
    min_similarity: float = 0.75,
    embed_fn=None,
) -> int:
    """Create SIMILAR_TO edges between summaries at the same resolution level.

    For each summary at the given level, finds its top-K nearest neighbors
    among other summaries at the same level (via vector similarity) and
    creates SIMILAR_TO edges with weight = cosine_similarity.

    If a summary lacks an embedding, skips it (or computes one if embed_fn given).

    Args:
        conn: Database connection.
        level: Resolution level to process.
        top_k: Number of nearest neighbors per summary.
        min_similarity: Minimum cosine similarity to create an edge.
        embed_fn: Optional embedding function to backfill missing embeddings.

    Returns:
        Number of SIMILAR_TO edges created (or updated).
    """
    # Get all summaries at this level
    summary_rows = conn.execute(
        """SELECT id, content FROM fragments
           WHERE resolution_level = ? AND content_type = 'summary'
           ORDER BY id""",
        (level,),
    ).fetchall()

    if len(summary_rows) < 2:
        return 0

    summary_ids = [r[0] for r in summary_rows]
    id_to_content = {r[0]: r[1] for r in summary_rows}

    # Get existing embeddings for these summaries
    # fragment_vec is a vec0 virtual table -- query in chunks
    id_to_embedding = {}
    for chunk_start in range(0, len(summary_ids), 500):
        chunk = summary_ids[chunk_start:chunk_start + 500]
        placeholders = ",".join("?" * len(chunk))
        try:
            rows = conn.execute(
                f"SELECT id, embedding FROM fragment_vec WHERE id IN ({placeholders})",
                chunk,
            ).fetchall()
            for r in rows:
                # Deserialize the f32 blob
                vec_bytes = r[1]
                if isinstance(vec_bytes, bytes):
                    n = len(vec_bytes) // 4
                    vec = list(struct.unpack(f"{n}f", vec_bytes))
                    id_to_embedding[r[0]] = vec
        except sqlite3.OperationalError as e:
            log.warning("fragment_vec query failed: %s", e)
            break

    # Backfill missing embeddings
    missing = [sid for sid in summary_ids if sid not in id_to_embedding]
    if missing and embed_fn is not None:
        log.info("Backfilling embeddings for %d level-%d summaries", len(missing), level)
        backfilled = 0
        for sid in missing:
            content = id_to_content.get(sid, "")
            if not content:
                continue
            try:
                emb = embed_fn(content)
                if emb:
                    conn.execute(
                        "INSERT OR REPLACE INTO fragment_vec (id, embedding) VALUES (?, ?)",
                        (sid, _serialize_f32(emb)),
                    )
                    id_to_embedding[sid] = emb
                    backfilled += 1
                    if backfilled % 100 == 0:
                        conn.commit()
                        log.info("Backfilled %d/%d embeddings", backfilled, len(missing))
            except Exception as e:
                log.warning("Failed to embed summary %d: %s", sid, e)
        conn.commit()
        log.info("Backfilled %d embeddings total", backfilled)

    if len(id_to_embedding) < 2:
        return 0

    # Compute similarity and create edges
    # For 6K summaries, an N^2 compare is 42M comparisons -- fast in numpy
    try:
        import numpy as np
    except ImportError:
        log.error("numpy required for auto_link_summaries")
        return 0

    ids_with_emb = list(id_to_embedding.keys())
    matrix = np.array([id_to_embedding[sid] for sid in ids_with_emb], dtype=np.float32)

    # Normalize for cosine similarity
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    matrix = matrix / norms

    # Cosine similarity matrix (N x N)
    sim_matrix = matrix @ matrix.T

    # Collect edges in memory first (vectorized), then batch insert.
    # This avoids per-call registry updates in add_edge() which are slow.
    n = len(ids_with_emb)
    log.info("Computing top-%d neighbors for %d summaries", top_k, n)

    edge_rows = []
    now = _now_iso()

    for i in range(n):
        sim_row = sim_matrix[i].copy()
        sim_row[i] = -1.0  # Exclude self
        if top_k >= n - 1:
            top_indices = np.argsort(-sim_row)[: n - 1]
        else:
            top_indices = np.argpartition(-sim_row, top_k)[:top_k]

        source_id = ids_with_emb[i]
        for j in top_indices:
            similarity = float(sim_row[j])
            if similarity < min_similarity:
                continue
            target_id = ids_with_emb[j]
            if source_id == target_id:
                continue
            edge_rows.append(
                (source_id, target_id, "meaning", similarity, "SIMILAR_TO", now, 0.1)
            )

    log.info("Prepared %d edges for batch insert", len(edge_rows))

    # Ensure SIMILAR_TO is in the registry (one-time check)
    conn.execute(
        """INSERT INTO edge_type_registry (type_name, description, default_weight, default_system, first_seen)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(type_name) DO NOTHING""",
        ("SIMILAR_TO", "Auto-linked summary similarity", 0.5, "meaning", now),
    )

    # Batch insert using executemany
    # Use INSERT OR REPLACE semantics via ON CONFLICT update
    conn.executemany(
        """INSERT INTO fragment_edges
        (source_id, target_id, system, weight, edge_type, created_at, decay_rate)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(source_id, target_id, edge_type) DO UPDATE SET
            weight = MAX(fragment_edges.weight, excluded.weight),
            last_traversed = excluded.created_at""",
        edge_rows,
    )

    conn.commit()
    log.info("Batch inserted %d edges", len(edge_rows))
    return len(edge_rows)


def _find_clusters(
    conn: sqlite3.Connection,
    min_size: int = 3,
    max_clusters: int = 500,
    target_level: int | None = None,
) -> dict[int, list[int]]:
    """Find natural clusters of fragments via connected components.

    OPTIMIZED for 281K+ scale: batch queries, no per-row lookups.

    Args:
        conn: Database connection.
        min_size: Minimum cluster size.
        max_clusters: Maximum number of clusters to return.
        target_level: If given, only clusters fragments AT this exact level.
                      If None, considers all unparented fragments.
    """
    # If target_level specified, get the set of fragment IDs at that level
    level_filter = None
    if target_level is not None:
        level_rows = conn.execute(
            "SELECT id FROM fragments WHERE resolution_level = ?",
            (target_level,),
        ).fetchall()
        level_filter = set(r[0] for r in level_rows)
        if not level_filter:
            return {}

    # Get all strong edges
    rows = conn.execute(
        """SELECT source_id, target_id FROM fragment_edges
        WHERE edge_type IN ('CO_DISCOVERED', 'SIMILAR_TO', 'PART_OF', 'BECAUSE')
        AND weight > 0.3"""
    ).fetchall()

    if not rows:
        return {}

    # If we have a level filter, only keep edges between fragments at that level
    if level_filter is not None:
        rows = [(s, t) for s, t in rows if s in level_filter and t in level_filter]
        if not rows:
            return {}

    # Union-find
    parent = {}
    rank = {}

    def find(x):
        if x not in parent:
            parent[x] = x
            rank[x] = 0
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:
            parent[x], x = root, parent[x]
        return root

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return
        if rank.get(ra, 0) < rank.get(rb, 0):
            ra, rb = rb, ra
        parent[rb] = ra
        if rank.get(ra, 0) == rank.get(rb, 0):
            rank[ra] = rank.get(ra, 0) + 1

    for row in rows:
        union(row[0], row[1])

    clusters = defaultdict(list)
    for node in parent:
        clusters[find(node)].append(node)

    # Get already-parented fragments
    parented_ids = set()
    parented_rows = conn.execute(
        "SELECT id FROM fragments WHERE parent_id IS NOT NULL"
    ).fetchall()
    for r in parented_rows:
        parented_ids.add(r[0])

    # Filter: min size, exclude already-parented, cap total clusters
    filtered = {}
    for root, members in sorted(clusters.items(), key=lambda x: -len(x[1])):
        unparented = [m for m in members if m not in parented_ids]
        if len(unparented) >= min_size:
            filtered[root] = unparented
        if len(filtered) >= max_clusters:
            break

    return filtered


def _simple_summary(contents: list[str]) -> str:
    """Generate a simple summary without LLM (concatenate key phrases)."""
    if not contents:
        return "Empty cluster"
    if len(contents) == 1:
        return contents[0]

    summaries = []
    for c in contents[:3]:
        first_sentence = c.split('.')[0].strip()
        if first_sentence:
            summaries.append(first_sentence)

    if summaries:
        return "Summary: " + ". ".join(summaries) + "."
    return f"Cluster of {len(contents)} related fragments"
