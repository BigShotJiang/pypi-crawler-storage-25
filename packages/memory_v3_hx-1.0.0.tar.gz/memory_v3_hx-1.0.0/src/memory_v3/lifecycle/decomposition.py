"""
v4 Fragment Decomposition Pipeline

Takes text (conversation turns, observations, decisions) and decomposes it
into atomic knowledge fragments with edge relationships.

Three tiers:
  Tier A: LLM-based (Dense X Retrieval pattern) -- best quality
  Tier B: Rule-based fallback -- fast, no LLM needed
  Tier C: Passthrough -- single fragment, no decomposition

The decomposer also extracts edge relationships between fragments
(BECAUSE, DECIDED_OVER, DEPENDS_ON, etc.) during decomposition.
"""

import hashlib
import json
import re
from datetime import datetime, timezone

from ..config import get_config

# ---------- Causal connective patterns ----------

CAUSAL_PATTERNS = [
    (r'\bbecause\b', 'BECAUSE'),
    (r'\bsince\b', 'BECAUSE'),
    (r'\btherefore\b', 'BECAUSE'),
    (r'\bso that\b', 'BECAUSE'),
    (r'\bas a result\b', 'BECAUSE'),
    (r'\bdue to\b', 'BECAUSE'),
    (r'\bcaused by\b', 'BECAUSE'),
    (r'\bled to\b', 'BECAUSE'),
    (r'\bin order to\b', 'BECAUSE'),
]

DECISION_PATTERNS = [
    (r'\bchose\s+(\S+)\s+over\s+(\S+)', 'DECIDED_OVER'),
    (r'\bpicked\s+(\S+)\s+instead of\s+(\S+)', 'DECIDED_OVER'),
    (r'\bprefer(?:s|red)?\s+(\S+)\s+(?:over|to)\s+(\S+)', 'DECIDED_OVER'),
    (r'\bswitched from\s+(\S+)\s+to\s+(\S+)', 'SUPERSEDES'),
    (r'\breplaced\s+(\S+)\s+with\s+(\S+)', 'SUPERSEDES'),
]

DEPENDENCY_PATTERNS = [
    (r'\bdepends on\b', 'DEPENDS_ON'),
    (r'\brequires\b', 'DEPENDS_ON'),
    (r'\bneeds\b', 'DEPENDS_ON'),
    (r'\bblocked by\b', 'DEPENDS_ON'),
]

CORRECTION_PATTERNS = [
    (r'\bactually\b', 'CORRECTED_BY'),
    (r'\bnot\s+\S+\s*[,;]\s*but\b', 'CORRECTED_BY'),
    (r'\bwrong\b.*\bcorrect\b', 'CORRECTED_BY'),
    (r'\bfix(?:ed)?\b', 'CORRECTED_BY'),
]

HIERARCHY_PATTERNS = [
    (r'\bpart of\b', 'PART_OF'),
    (r'\bbelongs to\b', 'PART_OF'),
    (r'\bwithin\b', 'PART_OF'),
    (r'\binside\b', 'PART_OF'),
    (r'\bcontains\b', 'PART_OF'),
    (r'\bincludes\b', 'PART_OF'),
]


# ---------- LLM decomposition prompt ----------

DECOMPOSITION_PROMPT = """Decompose the following text into atomic knowledge fragments.

Rules:
- Each fragment should be ONE discrete fact, decision, observation, or relationship.
- Split compound sentences into simple ones.
- Replace pronouns with the full entity name (decontextualize).
- Each fragment must stand alone -- someone reading ONLY that fragment should understand it.
- Output one fragment per line, nothing else. No numbering, no bullets.

Text:
{text}

Fragments:"""


EDGE_EXTRACTION_PROMPT = """Given these knowledge fragments, identify relationships between them.

Output format: one relationship per line as JSON:
{{"source": 0, "target": 1, "type": "BECAUSE", "system": "reasoning"}}

Valid relationship types: BECAUSE, DECIDED_OVER, PART_OF, SUPERSEDES, CONTRADICTS, DEPENDS_ON, CORRECTED_BY, APPLIED_IN, CO_DISCOVERED, EVOLVED_FROM, SIMILAR_TO, PRECEDED_BY

Valid systems: meaning, timeline, importance, structure, method, reasoning

Only output relationships you are confident about. If none, output nothing.

Fragments:
{fragments}

Relationships:"""


# ---------- Decomposition functions ----------

def decompose_with_llm(text: str, llm_func=None) -> dict:
    """Tier A: LLM-based atomic proposition extraction.

    Args:
        text: The text to decompose.
        llm_func: Callable that takes a prompt string and returns a response string.
                  If None, falls back to Tier B.

    Returns:
        {
            "fragments": [{"content": str, "content_hash": str}, ...],
            "edges": [{"source_idx": int, "target_idx": int, "edge_type": str, "system": str}, ...],
            "method": "llm" | "rule" | "passthrough"
        }
    """
    if llm_func is None:
        return decompose_with_rules(text)

    try:
        # Pass 1: Extract fragments
        prompt = DECOMPOSITION_PROMPT.format(text=text)
        response = llm_func(prompt)

        fragments = []
        for line in response.strip().split('\n'):
            line = line.strip()
            if not line or len(line) < 10:
                continue
            content_hash = hashlib.sha256(line.encode()).hexdigest()[:16]
            fragments.append({"content": line, "content_hash": content_hash})

        if not fragments:
            return decompose_with_rules(text)

        # Pass 2: Extract edges between fragments
        frag_text = '\n'.join(
            f"[{i}] {f['content']}" for i, f in enumerate(fragments)
        )
        edge_prompt = EDGE_EXTRACTION_PROMPT.format(fragments=frag_text)
        edge_response = llm_func(edge_prompt)

        edges = []
        for line in edge_response.strip().split('\n'):
            line = line.strip()
            if not line:
                continue
            try:
                edge = json.loads(line)
                if all(k in edge for k in ('source', 'target', 'type')):
                    edges.append({
                        "source_idx": int(edge["source"]),
                        "target_idx": int(edge["target"]),
                        "edge_type": edge["type"],
                        "system": edge.get("system", "meaning"),
                    })
            except (json.JSONDecodeError, ValueError, KeyError):
                continue

        return {"fragments": fragments, "edges": edges, "method": "llm"}

    except Exception:
        return decompose_with_rules(text)


def decompose_with_rules(text: str) -> dict:
    """Tier B: Rule-based decomposition.
    Splits on sentence boundaries and extracts edges via pattern matching."""

    # Split into sentences
    sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', text.strip())
    if not sentences:
        return _passthrough(text)

    # Further split compound sentences on conjunctions
    fragments = []
    for sent in sentences:
        # Split on common conjunctions that join independent clauses
        parts = re.split(r'\s*(?:,\s*(?:and|but|so|yet)\s+|;\s*)', sent)
        for part in parts:
            part = part.strip()
            if len(part) >= 10:  # Minimum meaningful length
                content_hash = hashlib.sha256(part.encode()).hexdigest()[:16]
                fragments.append({"content": part, "content_hash": content_hash})

    if not fragments:
        return _passthrough(text)

    # Extract edges via pattern matching
    edges = _extract_edges_by_pattern(text, fragments)

    # All fragments from same text are CO_DISCOVERED
    for i in range(len(fragments)):
        for j in range(i + 1, len(fragments)):
            edges.append({
                "source_idx": i,
                "target_idx": j,
                "edge_type": "CO_DISCOVERED",
                "system": "timeline",
            })

    return {"fragments": fragments, "edges": edges, "method": "rule"}


def _passthrough(text: str) -> dict:
    """Tier C: No decomposition -- treat entire text as one fragment."""
    content_hash = hashlib.sha256(text.encode()).hexdigest()[:16]
    return {
        "fragments": [{"content": text, "content_hash": content_hash}],
        "edges": [],
        "method": "passthrough",
    }


def _extract_edges_by_pattern(text: str, fragments: list[dict]) -> list[dict]:
    """Extract edge relationships from text using regex patterns."""
    edges = []
    text_lower = text.lower()

    # Check causal patterns
    for pattern, edge_type in CAUSAL_PATTERNS:
        if re.search(pattern, text_lower):
            # Link first fragment to second (cause -> effect)
            if len(fragments) >= 2:
                edges.append({
                    "source_idx": 0,
                    "target_idx": 1,
                    "edge_type": edge_type,
                    "system": "reasoning",
                })
            break  # One causal link per text

    # Check decision patterns
    for pattern, edge_type in DECISION_PATTERNS:
        if re.search(pattern, text_lower):
            if len(fragments) >= 2:
                edges.append({
                    "source_idx": 0,
                    "target_idx": 1,
                    "edge_type": edge_type,
                    "system": "reasoning",
                })
            break

    # Check dependency patterns
    for pattern, edge_type in DEPENDENCY_PATTERNS:
        if re.search(pattern, text_lower):
            if len(fragments) >= 2:
                edges.append({
                    "source_idx": 0,
                    "target_idx": 1,
                    "edge_type": edge_type,
                    "system": "reasoning",
                })
            break

    # Check hierarchy patterns
    for pattern, edge_type in HIERARCHY_PATTERNS:
        if re.search(pattern, text_lower):
            if len(fragments) >= 2:
                edges.append({
                    "source_idx": 1,
                    "target_idx": 0,
                    "edge_type": edge_type,
                    "system": "structure",
                })
            break

    return edges


# ---------- Temporal coordinate extraction ----------

def extract_timeline_coord(text: str) -> float | None:
    """Extract a temporal coordinate (unix timestamp) from text.
    Returns None if no temporal reference found."""
    try:
        from dateutil import parser as dateutil_parser
        # Try to find a date in the text
        # Look for common date patterns first
        date_patterns = [
            r'\b(\d{4}-\d{2}-\d{2})\b',
            r'\b(\d{1,2}/\d{1,2}/\d{2,4})\b',
            r'\b((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{1,2},?\s+\d{4})\b',
        ]
        for pattern in date_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                try:
                    dt = dateutil_parser.parse(match.group(1))
                    return dt.timestamp()
                except (ValueError, OverflowError):
                    continue
        return None
    except ImportError:
        return None


# ---------- Main entry point ----------

def decompose(
    text: str,
    source: str | None = None,
    llm_func=None,
    min_fragment_length: int = 10,
) -> dict:
    """Decompose text into atomic knowledge fragments with edges.

    Args:
        text: The text to decompose.
        source: Source identifier (e.g., "conversation", "vault_indexer").
        llm_func: Optional LLM callable for Tier A decomposition.
        min_fragment_length: Minimum character length for a fragment.

    Returns:
        {
            "fragments": [{"content": str, "content_hash": str}, ...],
            "edges": [{"source_idx": int, "target_idx": int,
                       "edge_type": str, "system": str}, ...],
            "method": "llm" | "rule" | "passthrough",
            "source": str | None,
            "timeline_coord": float | None,
        }
    """
    if not text or len(text.strip()) < min_fragment_length:
        return {
            "fragments": [],
            "edges": [],
            "method": "empty",
            "source": source,
            "timeline_coord": None,
        }

    # Try LLM first, fall back to rules
    result = decompose_with_llm(text, llm_func=llm_func)

    # Extract timeline coordinate from the original text
    result["source"] = source
    result["timeline_coord"] = extract_timeline_coord(text)

    return result
