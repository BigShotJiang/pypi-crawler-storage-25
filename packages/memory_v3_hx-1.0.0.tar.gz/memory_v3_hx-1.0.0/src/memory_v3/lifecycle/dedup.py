"""
v4 Fragment Deduplication

Three-tier dedup strategy:
  Tier 1: Exact content hash (instant, O(1))
  Tier 2: Semantic embedding similarity (cosine > threshold)
  Tier 3: (Future) MinHash/SimHash for surface near-duplicates

When a duplicate is detected, instead of creating a new fragment,
the existing fragment's edges are STRENGTHENED (P8: exposure builds
density, not copies).
"""

import hashlib
import sqlite3

import numpy as np

from ..db import (
    get_fragment_by_hash,
    strengthen_edge,
    add_edge,
    _serialize_f32,
    EMBEDDING_DIM,
)


def check_exact_duplicate(
    conn: sqlite3.Connection,
    content: str,
) -> dict | None:
    """Tier 1: Check for exact content match via SHA-256 hash.
    Returns the existing fragment dict if found, None otherwise."""
    content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
    return get_fragment_by_hash(conn, content_hash)


def check_semantic_duplicate(
    conn: sqlite3.Connection,
    embedding: list[float],
    threshold: float = 0.88,
    limit: int = 5,
) -> list[dict]:
    """Tier 2: Check for semantically equivalent fragments via vector search.
    Returns list of (fragment_dict, similarity) tuples above threshold."""
    try:
        rows = conn.execute(
            """SELECT f.*, fv.distance
            FROM fragment_vec fv
            JOIN fragments f ON f.id = fv.id
            WHERE fv.embedding MATCH ?
            ORDER BY fv.distance ASC
            LIMIT ?""",
            (_serialize_f32(embedding), limit)
        ).fetchall()
    except Exception:
        return []

    results = []
    for row in rows:
        d = dict(row)
        # sqlite-vec returns L2 distance; convert to cosine similarity approximation
        # For normalized vectors: cos_sim ~ 1 - (L2^2 / 2)
        l2_dist = d.pop("distance", 1.0)
        similarity = max(0.0, 1.0 - (l2_dist ** 2) / 2.0)
        if similarity >= threshold:
            d["_similarity"] = similarity
            results.append(d)

    return results


def deduplicate_fragment(
    conn: sqlite3.Connection,
    content: str,
    embedding: list[float] | None = None,
    context_fragment_ids: list[int] | None = None,
    semantic_threshold: float = 0.88,
) -> dict:
    """Run the full dedup pipeline on a candidate fragment.

    Returns:
        {
            "is_duplicate": bool,
            "existing_fragment": dict | None,  # The fragment it duplicates
            "similarity": float | None,        # How similar (for semantic matches)
            "tier": "exact" | "semantic" | None,
            "edges_strengthened": int,          # How many edges were boosted
        }
    """
    result = {
        "is_duplicate": False,
        "existing_fragment": None,
        "similarity": None,
        "tier": None,
        "edges_strengthened": 0,
    }

    # Tier 1: Exact hash
    existing = check_exact_duplicate(conn, content)
    if existing:
        result["is_duplicate"] = True
        result["existing_fragment"] = existing
        result["similarity"] = 1.0
        result["tier"] = "exact"

        # Strengthen edges from this fragment to any context fragments
        strengthened = _strengthen_context_edges(
            conn, existing["id"], context_fragment_ids
        )
        result["edges_strengthened"] = strengthened
        return result

    # Tier 2: Semantic similarity
    if embedding is not None:
        matches = check_semantic_duplicate(
            conn, embedding, threshold=semantic_threshold
        )
        if matches:
            best = matches[0]  # Highest similarity
            result["is_duplicate"] = True
            result["existing_fragment"] = best
            result["similarity"] = best.get("_similarity", 0.0)
            result["tier"] = "semantic"

            strengthened = _strengthen_context_edges(
                conn, best["id"], context_fragment_ids
            )
            result["edges_strengthened"] = strengthened
            return result

    return result


def _strengthen_context_edges(
    conn: sqlite3.Connection,
    fragment_id: int,
    context_fragment_ids: list[int] | None,
    boost: float = 0.1,
) -> int:
    """Strengthen edges between an existing fragment and current context.
    If no edges exist yet, create CO_DISCOVERED edges.
    Returns count of edges modified."""
    if not context_fragment_ids:
        return 0

    count = 0
    for ctx_id in context_fragment_ids:
        if ctx_id == fragment_id:
            continue
        # Try to strengthen existing edge
        strengthened = strengthen_edge(
            conn, fragment_id, ctx_id, "CO_DISCOVERED", boost=boost
        )
        if not strengthened:
            # Create new edge if none existed
            add_edge(
                conn, fragment_id, ctx_id,
                system="timeline",
                edge_type="CO_DISCOVERED",
                weight=0.3,
            )
        count += 1
    return count
