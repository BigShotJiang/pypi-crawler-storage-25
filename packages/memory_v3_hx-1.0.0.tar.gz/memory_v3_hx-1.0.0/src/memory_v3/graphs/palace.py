"""
v4 Memory Palace Auto-Construction

Builds a navigable spatial structure from the fragment graph:
- Projects -> Buildings
- Topic clusters (Leiden communities) -> Rooms
- High-importance fragments -> Landmarks
- Temporal sequences -> Corridors
- Dense rooms -> Geometric shapes (cube, pyramid, sphere)

The palace emerges from the fragment graph during consolidation.
It is not imposed top-down; it is discovered bottom-up.
"""

import sqlite3
from collections import defaultdict

from ..db import (
    add_place, get_child_places, link_places,
    anchor_fragment_to_place, get_fragments_at_place,
    _now_iso,
)


# Geometric shape definitions for dense rooms
GEOMETRIC_SHAPES = {
    "cube": {"stations": 6, "description": "6 faces for categorical organization"},
    "pyramid": {"stations": 4, "description": "4 faces + apex for hierarchical organization"},
    "sphere": {"stations": 6, "description": "Poles + 4 cardinal sectors for continuous gradients"},
    "dodecahedron": {"stations": 12, "description": "12 faces for dense categorical storage"},
}

MAX_FRAGMENTS_PER_ROOM = 15  # Before a geometric shape auto-generates


def build_palace_from_fragments(
    conn: sqlite3.Connection,
    palace_name: str = "Knowledge Palace",
) -> dict:
    """Build or update the memory palace from the current fragment graph.

    Returns stats about what was created/updated.
    """
    stats = {"buildings": 0, "rooms": 0, "landmarks": 0, "corridors": 0,
             "shapes": 0, "anchored": 0}

    # Step 1: Create or find the root palace
    root = _get_or_create_root(conn, palace_name)

    # Step 2: Discover projects/topics from fragments
    # Group fragments by source (source_memory_id -> project/topic)
    source_groups = _group_fragments_by_source(conn)

    # Step 3: Create buildings for each major group
    for group_name, fragment_ids in source_groups.items():
        building_id = _get_or_create_child(
            conn, root, group_name, "architectural", resolution=5
        )
        stats["buildings"] += 1

        # Step 4: Cluster fragments within the building into rooms
        rooms = _cluster_into_rooms(conn, fragment_ids)
        prev_room_id = None

        for room_name, room_frags in rooms.items():
            room_id = _get_or_create_child(
                conn, building_id, room_name, "architectural", resolution=3
            )
            stats["rooms"] += 1

            # Link rooms as corridors (sequential)
            if prev_room_id is not None:
                link_places(conn, prev_room_id, room_id, "corridor")
                stats["corridors"] += 1
            prev_room_id = room_id

            # Step 5: Anchor fragments to the room
            for fid in room_frags:
                anchor_fragment_to_place(conn, fid, room_id)
                stats["anchored"] += 1

            # Step 6: Check if room is too dense -> add geometric shape
            if len(room_frags) > MAX_FRAGMENTS_PER_ROOM:
                shape_id = _add_geometric_shape(conn, room_id, room_frags)
                if shape_id:
                    stats["shapes"] += 1

        # Step 7: Mark high-importance fragments as landmarks
        for fid in fragment_ids:
            frag = conn.execute(
                "SELECT importance, protected FROM fragments WHERE id = ?", (fid,)
            ).fetchone()
            if frag and (frag[0] >= 0.8 or frag[1]):
                stats["landmarks"] += 1

    return stats


def _get_or_create_root(conn: sqlite3.Connection, name: str) -> int:
    """Get or create the root palace place."""
    row = conn.execute(
        "SELECT id FROM places WHERE name = ? AND parent_id IS NULL",
        (name,)
    ).fetchone()
    if row:
        return row[0]
    return add_place(conn, name, "architectural", resolution=6, salience=1.0)


def _get_or_create_child(
    conn: sqlite3.Connection,
    parent_id: int,
    name: str,
    place_type: str = "architectural",
    resolution: int = 3,
) -> int:
    """Get or create a child place under a parent."""
    row = conn.execute(
        "SELECT id FROM places WHERE name = ? AND parent_id = ?",
        (name, parent_id)
    ).fetchone()
    if row:
        return row[0]

    place_id = add_place(
        conn, name, place_type, parent_id=parent_id, resolution=resolution
    )
    # Link to parent as containment
    link_places(conn, parent_id, place_id, "contains")
    return place_id


def _group_fragments_by_source(conn: sqlite3.Connection) -> dict[str, list[int]]:
    """Group fragments by their source/topic into building-level groups."""
    rows = conn.execute(
        """SELECT id, source, content_type, content
        FROM fragments
        ORDER BY source, id"""
    ).fetchall()

    groups = defaultdict(list)
    for row in rows:
        fid, source, ctype, content = row[0], row[1], row[2], row[3]
        # Use source as group name, or content_type, or "General"
        group = source or ctype or "General"
        # Clean up group name
        if len(group) > 40:
            group = group[:40]
        groups[group].append(fid)

    return dict(groups)


def _cluster_into_rooms(
    conn: sqlite3.Connection,
    fragment_ids: list[int],
    max_room_size: int = 20,
) -> dict[str, list[int]]:
    """Cluster fragments into room-sized groups.
    Simple approach: chunk by order. Phase 6 will use Leiden for smarter clustering."""
    if not fragment_ids:
        return {}

    rooms = {}
    chunk_idx = 0
    for i in range(0, len(fragment_ids), max_room_size):
        chunk = fragment_ids[i:i + max_room_size]
        # Name room by first fragment's content
        first_frag = conn.execute(
            "SELECT content FROM fragments WHERE id = ?", (chunk[0],)
        ).fetchone()
        room_name = f"Room {chunk_idx + 1}"
        if first_frag:
            # Use first few words as room name
            words = first_frag[0].split()[:4]
            room_name = ' '.join(words) + "..."
        rooms[room_name] = chunk
        chunk_idx += 1

    return rooms


def _add_geometric_shape(
    conn: sqlite3.Connection,
    room_id: int,
    fragment_ids: list[int],
) -> int | None:
    """Add a geometric shape inside a room when it's too dense.
    Redistributes excess fragments onto the shape's stations."""
    if len(fragment_ids) <= MAX_FRAGMENTS_PER_ROOM:
        return None

    # Choose shape based on count
    excess = len(fragment_ids) - MAX_FRAGMENTS_PER_ROOM
    if excess <= 6:
        shape_type = "cube"
    elif excess <= 12:
        shape_type = "dodecahedron"
    else:
        shape_type = "sphere"

    shape_info = GEOMETRIC_SHAPES[shape_type]
    shape_id = add_place(
        conn,
        name=f"{shape_type.title()} in room",
        place_type="geometric",
        shape=shape_type,
        parent_id=room_id,
        resolution=2,
        salience=0.7,
    )
    link_places(conn, room_id, shape_id, "contains")

    # Create stations on the shape
    station_ids = []
    for i in range(shape_info["stations"]):
        station_id = add_place(
            conn,
            name=f"{shape_type} face {i + 1}",
            place_type="geometric",
            shape=shape_type,
            parent_id=shape_id,
            resolution=1,
        )
        station_ids.append(station_id)
        # Link stations in rotation sequence
        if station_ids and len(station_ids) > 1:
            link_places(conn, station_ids[-2], station_id, "rotation_next")

    # Close the rotation loop
    if len(station_ids) >= 2:
        link_places(conn, station_ids[-1], station_ids[0], "rotation_next")

    # Move excess fragments to shape stations
    excess_frags = fragment_ids[MAX_FRAGMENTS_PER_ROOM:]
    for i, fid in enumerate(excess_frags):
        station = station_ids[i % len(station_ids)]
        anchor_fragment_to_place(conn, fid, station)

    return shape_id
