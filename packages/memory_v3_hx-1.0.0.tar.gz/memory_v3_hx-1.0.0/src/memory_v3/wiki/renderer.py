"""
memory-v3 -- Wiki Renderer Core
Generates and syncs Obsidian wiki pages from v4 fractal memory.
"""

import hashlib
import json
import logging
import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from ..config import Config, get_config
from .slugify import slugify, page_path, wiki_link, unique_slug
from .templates import (
    render_topic_page,
    render_entity_page,
    render_moc_page,
    render_index_page,
    render_contradiction_page,
    render_log_entry,
)

log = logging.getLogger(__name__)

# Folder names inside the wiki vault
FOLDERS = ["topics", "entities", "concepts", "moc", "corrections", "lint"]

# Meta file for sync tracking
META_FILE = ".wiki_meta.json"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_wiki(conn, config=None, force=False):
    """Full render of wiki from v4 database state.

    Args:
        conn: SQLite connection to v4 database.
        config: Config object (defaults to get_config()).
        force: If True, overwrite all pages (except manual_edit ones).

    Returns:
        Dict with stats: pages_written, pages_skipped, errors, etc.
    """
    cfg = config or get_config()
    wiki_root = cfg.wiki_output_path
    if not wiki_root:
        return {"error": "wiki_output_path not configured"}

    _ensure_folders(wiki_root)
    slug_registry = set()
    stats = {
        "pages_written": 0,
        "pages_skipped_manual": 0,
        "pages_skipped_unchanged": 0,
        "errors": 0,
        "topics": 0,
        "entities": 0,
        "mocs": 0,
        "contradictions": 0,
    }

    # --- 1. Topic pages (hierarchy summaries) ---
    topics = _get_topic_candidates(conn, cfg.wiki_min_resolution)
    topic_slugs = {}  # fragment_id -> slug mapping for cross-linking
    for frag in topics:
        frag_id = frag["id"]
        title = _extract_title(frag["content"])
        slug = unique_slug(title, slug_registry, frag_id)
        topic_slugs[frag_id] = slug

        children = _get_children(conn, frag_id)
        child_links = []
        for child in children[:50]:
            child_slug = unique_slug(
                _extract_title(child["content"]), slug_registry, child["id"]
            )
            topic_slugs[child["id"]] = child_slug
            child_links.append({
                "slug": child_slug,
                "display": _extract_title(child["content"]),
                "content_preview": child["content"][:80] if child["content"] else "",
            })

        related = _get_related(conn, frag_id)
        related_links = []
        for rel in related[:20]:
            rel_slug = unique_slug(
                _extract_title(rel["content"]), slug_registry, rel["target_id"]
            )
            related_links.append({
                "slug": rel_slug,
                "display": _extract_title(rel["content"]),
                "edge_type": rel.get("edge_type", ""),
            })

        contras = _get_fragment_contradictions(conn, frag_id)
        contra_links = []
        for c in contras:
            contra_links.append({
                "slug": "contradiction-%d" % c["edge_id"],
                "display": "Contradiction #%d" % c["edge_id"],
            })

        fm = {
            "type": "topic",
            "source": "memory-v4",
            "domain": _guess_domain(frag),
            "resolution": frag.get("resolution_level", 0),
            "fragment_ids": [frag_id],
            "importance": round(frag.get("importance", 0.5), 2),
            "created": _date_str(frag.get("created_at", "")),
            "updated": _now_date(),
            "tags": ["topic", "v4-wiki"],
            "status": "auto-generated",
        }

        content = render_topic_page(
            title=title,
            summary_content=frag["content"],
            children=child_links,
            related=related_links,
            contradictions=contra_links,
            frontmatter_fields=fm,
        )

        path = page_path(wiki_root, "topics", slug)
        written = _write_page(path, content, force=force)
        if written == "written":
            stats["pages_written"] += 1
            stats["topics"] += 1
        elif written == "skipped_manual":
            stats["pages_skipped_manual"] += 1
        elif written == "skipped_unchanged":
            stats["pages_skipped_unchanged"] += 1
        else:
            stats["errors"] += 1

    # --- 2. Entity pages (high-degree nodes) ---
    entities = _get_entity_candidates(conn, cfg.wiki_entity_min_degree)
    for ent in entities:
        ent_id = ent["id"]
        name = _extract_title(ent["content"])
        slug = unique_slug(name, slug_registry, ent_id)

        frags = _get_entity_fragments(conn, ent_id)
        frag_list = []
        for f in frags[:30]:
            frag_list.append({
                "content": f["content"],
                "importance": f.get("importance", 0),
                "created_at": f.get("created_at", ""),
            })

        rels = _get_related(conn, ent_id)
        rel_links = []
        for r in rels[:20]:
            r_slug = unique_slug(
                _extract_title(r["content"]), slug_registry, r["target_id"]
            )
            rel_links.append({
                "slug": r_slug,
                "display": _extract_title(r["content"]),
                "edge_type": r.get("edge_type", ""),
            })

        fm = {
            "type": "entity",
            "source": "memory-v4",
            "domain": _guess_domain(ent),
            "fragment_ids": [ent_id],
            "importance": round(ent.get("importance", 0.5), 2),
            "edge_count": ent.get("edge_count", 0),
            "created": _date_str(ent.get("created_at", "")),
            "updated": _now_date(),
            "tags": ["entity", "v4-wiki"],
            "status": "auto-generated",
        }

        content = render_entity_page(
            entity_name=name,
            entity_type=ent.get("content_type", "concept"),
            description=ent["content"],
            fragments=frag_list,
            relationships=rel_links,
            frontmatter_fields=fm,
        )

        path = page_path(wiki_root, "entities", slug)
        written = _write_page(path, content, force=force)
        if written == "written":
            stats["pages_written"] += 1
            stats["entities"] += 1
        elif written == "skipped_manual":
            stats["pages_skipped_manual"] += 1

    # --- 3. Contradiction reports ---
    contradictions = _get_contradictions(conn)
    for contra in contradictions:
        edge_id = contra["edge_id"]
        slug = "contradiction-%d" % edge_id

        source_slug = topic_slugs.get(contra["source_id"], "fragment-%d" % contra["source_id"])
        target_slug = topic_slugs.get(contra["target_id"], "fragment-%d" % contra["target_id"])

        fm = {
            "type": "contradiction",
            "source": "memory-v4",
            "edge_id": edge_id,
            "created": _now_date(),
            "updated": _now_date(),
            "tags": ["contradiction", "needs-review", "v4-wiki"],
            "status": "needs-review",
        }

        content = render_contradiction_page(
            edge_id=edge_id,
            frag_a={
                "content": contra["source_content"],
                "slug": source_slug,
                "created_at": contra.get("source_created", ""),
                "importance": contra.get("source_importance", 0),
            },
            frag_b={
                "content": contra["target_content"],
                "slug": target_slug,
                "created_at": contra.get("target_created", ""),
                "importance": contra.get("target_importance", 0),
            },
            frontmatter_fields=fm,
        )

        path = page_path(wiki_root, "corrections", slug)
        written = _write_page(path, content, force=force)
        if written == "written":
            stats["pages_written"] += 1
            stats["contradictions"] += 1

    # --- 4. MOC pages (domain clusters) ---
    domains = _get_domain_clusters(conn, cfg.wiki_min_resolution)
    moc_links = []
    for domain_name, frag_ids in domains.items():
        domain_slug = unique_slug(domain_name + "-moc", slug_registry)
        page_links = []
        for fid in frag_ids[:cfg.wiki_moc_max_links]:
            if fid in topic_slugs:
                s = topic_slugs[fid]
            else:
                row = conn.execute(
                    "SELECT content, resolution_level, importance FROM fragments WHERE id = ?",
                    (fid,),
                ).fetchone()
                if not row:
                    continue
                s = unique_slug(_extract_title(row[0]), slug_registry, fid)
            page_links.append({
                "slug": s,
                "display": s.replace("-", " ").title(),
                "resolution": 0,
                "importance": 0,
            })

        fm = {
            "type": "moc",
            "source": "memory-v4",
            "domain": domain_name,
            "created": _now_date(),
            "updated": _now_date(),
            "tags": ["moc", "v4-wiki", domain_name],
            "status": "auto-generated",
        }

        content = render_moc_page(
            domain=domain_name.replace("-", " ").title(),
            description="Map of Content for %s" % domain_name,
            page_links=page_links,
            frontmatter_fields=fm,
        )

        path = page_path(wiki_root, "moc", domain_slug)
        written = _write_page(path, content, force=force)
        if written == "written":
            stats["pages_written"] += 1
            stats["mocs"] += 1

        moc_links.append({
            "slug": domain_slug,
            "display": domain_name.replace("-", " ").title(),
            "page_count": len(page_links),
        })

    # --- 5. Master index ---
    db_stats = _get_db_stats(conn)
    fm = {
        "type": "index",
        "source": "memory-v4",
        "created": _now_date(),
        "updated": _now_date(),
        "tags": ["index", "v4-wiki"],
        "status": "auto-generated",
    }
    index_content = render_index_page(
        moc_links=moc_links,
        stats={
            "Total wiki pages": stats["pages_written"],
            "Topic pages": stats["topics"],
            "Entity pages": stats["entities"],
            "MOC pages": stats["mocs"],
            "Contradiction reports": stats["contradictions"],
            "Source fragments": db_stats.get("fragments", 0),
            "Source edges": db_stats.get("edges", 0),
        },
        frontmatter_fields=fm,
    )
    index_path = os.path.join(wiki_root, "_index.md")
    _write_page(index_path, index_content, force=True)

    # --- 6. Append to log ---
    _append_log(wiki_root, "generate", stats)

    # --- 7. Write metadata ---
    _write_meta(wiki_root, stats)

    log.info("Wiki generate complete: %s", stats)
    return stats


def sync_wiki(conn, config=None):
    """Incremental wiki update: only changed fragments since last render.

    Args:
        conn: SQLite connection.
        config: Config object.

    Returns:
        Dict with stats.
    """
    cfg = config or get_config()
    wiki_root = cfg.wiki_output_path
    if not wiki_root:
        return {"error": "wiki_output_path not configured"}

    meta = _read_meta(wiki_root)
    last_render = meta.get("last_render", "1970-01-01T00:00:00Z")

    # Check if any fragments changed since last render
    changed = conn.execute(
        "SELECT COUNT(*) FROM fragments WHERE created_at > ? OR last_accessed_at > ?",
        (last_render, last_render),
    ).fetchone()[0]

    if changed == 0:
        stats = {"status": "no_changes", "changed_fragments": 0}
        _append_log(wiki_root, "sync", stats)
        return stats

    # For now, sync does a full generate when changes detected
    # Future optimization: only re-render affected pages
    return generate_wiki(conn, config=cfg, force=False)


# ---------------------------------------------------------------------------
# Data queries
# ---------------------------------------------------------------------------

def _get_topic_candidates(conn, min_resolution=3):
    """Hierarchy summary fragments at resolution >= min_resolution."""
    rows = conn.execute(
        """SELECT id, content, content_type, source, resolution_level,
                  parent_id, importance, created_at
           FROM fragments
           WHERE resolution_level >= ?
             AND content_type = 'summary'
           ORDER BY resolution_level DESC, importance DESC""",
        (min_resolution,),
    ).fetchall()
    return [dict(r) for r in rows]


def _get_entity_candidates(conn, min_degree=5):
    """Fragments with min_degree+ edges (high-connectivity nodes)."""
    rows = conn.execute(
        """SELECT f.id, f.content, f.content_type, f.importance, f.created_at,
                  COUNT(DISTINCT fe.id) as edge_count
           FROM fragments f
           JOIN fragment_edges fe ON (fe.source_id = f.id OR fe.target_id = f.id)
           WHERE f.content_type NOT IN ('summary')
           GROUP BY f.id
           HAVING edge_count >= ?
           ORDER BY edge_count DESC
           LIMIT 2000""",
        (min_degree,),
    ).fetchall()
    return [dict(r) for r in rows]


def _get_children(conn, parent_id):
    """Get child fragments of a parent (via parent_id or HIERARCHY edge)."""
    # Try parent_id first
    rows = conn.execute(
        """SELECT id, content, content_type, resolution_level, importance
           FROM fragments WHERE parent_id = ?
           ORDER BY importance DESC LIMIT 50""",
        (parent_id,),
    ).fetchall()
    if rows:
        return [dict(r) for r in rows]

    # Fallback: HIERARCHY edges
    rows = conn.execute(
        """SELECT f.id, f.content, f.content_type, f.resolution_level, f.importance
           FROM fragment_edges fe
           JOIN fragments f ON f.id = fe.target_id
           WHERE fe.source_id = ? AND fe.edge_type = 'HIERARCHY'
           ORDER BY f.importance DESC LIMIT 50""",
        (parent_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def _get_related(conn, fragment_id):
    """Related fragments via edges (excluding HIERARCHY and CONTRADICTS)."""
    rows = conn.execute(
        """SELECT f.id as target_id, f.content, f.resolution_level,
                  fe.edge_type, fe.weight
           FROM fragment_edges fe
           JOIN fragments f ON f.id = fe.target_id
           WHERE fe.source_id = ?
             AND fe.edge_type NOT IN ('HIERARCHY', 'CONTRADICTS', 'ASSEMBLY')
             AND fe.weight > 0.3
           ORDER BY fe.weight DESC LIMIT 20""",
        (fragment_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def _get_entity_fragments(conn, entity_id):
    """Get fragments connected to an entity node."""
    rows = conn.execute(
        """SELECT DISTINCT f.id, f.content, f.importance, f.created_at
           FROM fragment_edges fe
           JOIN fragments f ON (
               (fe.target_id = f.id AND fe.source_id = ?)
               OR (fe.source_id = f.id AND fe.target_id = ?)
           )
           WHERE f.id != ?
           ORDER BY f.importance DESC LIMIT 30""",
        (entity_id, entity_id, entity_id),
    ).fetchall()
    return [dict(r) for r in rows]


def _get_fragment_contradictions(conn, fragment_id):
    """CONTRADICTS edges involving a fragment."""
    rows = conn.execute(
        """SELECT fe.id as edge_id, fe.source_id, fe.target_id
           FROM fragment_edges fe
           WHERE (fe.source_id = ? OR fe.target_id = ?)
             AND fe.edge_type = 'CONTRADICTS'""",
        (fragment_id, fragment_id),
    ).fetchall()
    return [dict(r) for r in rows]


def _get_contradictions(conn):
    """All CONTRADICTS edges with full fragment content."""
    rows = conn.execute(
        """SELECT fe.id as edge_id, fe.source_id, fe.target_id, fe.weight,
                  fs.content as source_content, fs.importance as source_importance,
                  fs.created_at as source_created,
                  ft.content as target_content, ft.importance as target_importance,
                  ft.created_at as target_created
           FROM fragment_edges fe
           JOIN fragments fs ON fs.id = fe.source_id
           JOIN fragments ft ON ft.id = fe.target_id
           WHERE fe.edge_type = 'CONTRADICTS'
           ORDER BY fe.weight DESC""",
    ).fetchall()
    return [dict(r) for r in rows]


def _get_domain_clusters(conn, min_resolution=3):
    """Group high-resolution fragments into domain clusters by source."""
    rows = conn.execute(
        """SELECT id, source, content_type
           FROM fragments
           WHERE resolution_level >= ?
           ORDER BY source, content_type""",
        (min_resolution,),
    ).fetchall()

    clusters = {}
    for row in rows:
        # Use source as domain key, falling back to content_type
        domain = row[1] or row[2] or "uncategorized"
        # Normalize domain name
        domain = slugify(domain, max_length=40)
        clusters.setdefault(domain, []).append(row[0])

    return clusters


def _get_db_stats(conn):
    """Quick stats from the database."""
    frag_count = conn.execute("SELECT COUNT(*) FROM fragments").fetchone()[0]
    edge_count = conn.execute("SELECT COUNT(*) FROM fragment_edges").fetchone()[0]
    return {"fragments": frag_count, "edges": edge_count}


# ---------------------------------------------------------------------------
# File I/O helpers
# ---------------------------------------------------------------------------

def _write_page(path, content, force=False):
    """Write a wiki page to disk, respecting manual_edit protection.

    Returns: 'written', 'skipped_manual', 'skipped_unchanged', or 'error'.
    """
    try:
        if os.path.exists(path) and not force:
            if _is_manual_edit(path):
                return "skipped_manual"
            # Check if content unchanged
            existing = ""
            try:
                with open(path, "r", encoding="utf-8") as f:
                    existing = f.read()
            except Exception:
                pass
            if existing == content:
                return "skipped_unchanged"

        # Atomic write: temp file then rename
        dir_path = os.path.dirname(path)
        os.makedirs(dir_path, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(dir=dir_path, suffix=".md.tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(content)
            os.replace(tmp_path, path)
        except Exception:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise

        return "written"
    except Exception as e:
        log.error("Failed to write %s: %s", path, e)
        return "error"


def _is_manual_edit(path):
    """Check if existing file has manual_edit: true in frontmatter."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f):
                if i > 20:
                    break
                if "manual_edit:" in line and "true" in line.lower():
                    return True
                if i > 0 and line.strip() == "---":
                    break  # End of frontmatter
    except Exception:
        pass
    return False


def _ensure_folders(wiki_root):
    """Create wiki folder structure if not exists."""
    os.makedirs(wiki_root, exist_ok=True)
    for folder in FOLDERS:
        os.makedirs(os.path.join(wiki_root, folder), exist_ok=True)


def _append_log(wiki_root, operation, stats):
    """Append an entry to the wiki operation log."""
    log_path = os.path.join(wiki_root, "_log.md")
    entry = render_log_entry(operation, stats)

    # Create log file with header if it does not exist
    if not os.path.exists(log_path):
        header = "# Wiki Operation Log\n\nAppend-only record of wiki operations.\n\n"
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(header)

    # Rotate if too large (>10000 lines)
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            line_count = sum(1 for _ in f)
        if line_count > 10000:
            archive_name = "_log_archive_%s.md" % _now_date()
            archive_path = os.path.join(wiki_root, archive_name)
            os.replace(log_path, archive_path)
            header = "# Wiki Operation Log\n\nAppend-only record. Previous log archived.\n\n"
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(header)
    except Exception:
        pass

    with open(log_path, "a", encoding="utf-8") as f:
        f.write(entry)
        f.write("\n")


def _read_meta(wiki_root):
    """Read wiki metadata for sync tracking."""
    meta_path = os.path.join(wiki_root, META_FILE)
    if os.path.exists(meta_path):
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _write_meta(wiki_root, stats):
    """Write wiki metadata for sync tracking."""
    meta_path = os.path.join(wiki_root, META_FILE)
    meta = {
        "last_render": _now_iso(),
        "last_stats": stats,
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------

def _extract_title(content):
    """Extract a reasonable title from fragment content."""
    if not content:
        return "Untitled"
    # Take first line or first 80 chars
    first_line = content.split("\n")[0].strip()
    # Remove markdown headers
    first_line = first_line.lstrip("#").strip()
    # Truncate
    if len(first_line) > 80:
        first_line = first_line[:77] + "..."
    return first_line or "Untitled"


def _guess_domain(frag):
    """Guess a domain label from fragment metadata."""
    source = frag.get("source", "") or ""
    content_type = frag.get("content_type", "") or ""
    if "vault" in source.lower():
        return "vault"
    if source:
        return slugify(source, max_length=30)
    return content_type or "general"


def _now_iso():
    """Current UTC timestamp."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _now_date():
    """Current date string."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _date_str(iso_str):
    """Extract date from ISO timestamp."""
    if not iso_str:
        return _now_date()
    return iso_str[:10]
