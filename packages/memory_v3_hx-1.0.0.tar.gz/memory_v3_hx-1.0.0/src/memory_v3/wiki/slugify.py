"""
Deterministic filename generation for wiki pages.
CP1252-safe: no em dashes, no unicode arrows, no special characters.
"""

import os
import re
import unicodedata


def slugify(text, max_length=80):
    """Convert text to a safe, deterministic Obsidian filename.

    Lowercase, hyphens for spaces, strip non-alphanum, truncate.
    Same input always produces the same output.

    Args:
        text: Any string to slugify.
        max_length: Max slug length (truncates on word boundary).

    Returns:
        Slug string like 'memory-architecture-v4'.
    """
    if not text:
        return "untitled"

    # Normalize unicode -> ASCII decomposition, strip accents
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")

    # Lowercase
    text = text.lower()

    # Replace common separators with hyphens
    text = re.sub(r"[_\s/\\|:]+", "-", text)

    # Strip anything that is not alphanumeric or hyphen
    text = re.sub(r"[^a-z0-9-]", "", text)

    # Collapse multiple hyphens
    text = re.sub(r"-{2,}", "-", text)

    # Strip leading/trailing hyphens
    text = text.strip("-")

    # Truncate on word boundary (hyphen boundary)
    if len(text) > max_length:
        truncated = text[:max_length]
        last_hyphen = truncated.rfind("-")
        if last_hyphen > max_length // 2:
            truncated = truncated[:last_hyphen]
        text = truncated.rstrip("-")

    return text or "untitled"


def page_path(wiki_root, folder, slug):
    """Build full file path for a wiki page.

    Args:
        wiki_root: Root directory of the wiki vault.
        folder: Subfolder (e.g. 'topics', 'entities').
        slug: Page slug (without .md extension).

    Returns:
        Full path string like 'C:/wiki/topics/memory-architecture.md'.
    """
    return os.path.join(wiki_root, folder, slug + ".md")


def wiki_link(target_slug, display_text=None):
    """Build an Obsidian wiki-link.

    Args:
        target_slug: The target page slug (filename without .md).
        display_text: Optional display text. If None, uses slug.

    Returns:
        '[[target-slug|Display Text]]' or '[[target-slug]]'.
    """
    if display_text and display_text != target_slug:
        return "[[%s|%s]]" % (target_slug, display_text)
    return "[[%s]]" % target_slug


def unique_slug(text, existing_slugs, fragment_id=None):
    """Generate a unique slug, appending fragment_id on collision.

    Args:
        text: Text to slugify.
        existing_slugs: Set of already-used slugs.
        fragment_id: Optional fragment ID for disambiguation.

    Returns:
        A unique slug string.
    """
    base = slugify(text)
    if base not in existing_slugs:
        existing_slugs.add(base)
        return base

    # Collision -- append fragment ID
    if fragment_id is not None:
        candidate = "%s-%d" % (base, fragment_id)
    else:
        n = 2
        candidate = "%s-%d" % (base, n)
        while candidate in existing_slugs:
            n += 1
            candidate = "%s-%d" % (base, n)

    existing_slugs.add(candidate)
    return candidate
