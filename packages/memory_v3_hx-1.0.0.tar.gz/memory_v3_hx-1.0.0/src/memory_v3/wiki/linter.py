"""
memory-v3 -- Wiki Linter
Health checks for the generated wiki against current v4 state.
"""

import logging
import os
import re
import sqlite3
from datetime import datetime, timezone

from ..config import Config, get_config
from .slugify import page_path
from .templates import render_frontmatter, render_log_entry

log = logging.getLogger(__name__)


def lint_wiki(conn, config=None):
    """Run all lint checks on the wiki.

    Args:
        conn: SQLite connection to v4 database.
        config: Config object.

    Returns:
        Dict with lint results and report path.
    """
    cfg = config or get_config()
    wiki_root = cfg.wiki_output_path
    if not wiki_root or not os.path.isdir(wiki_root):
        return {"error": "wiki_output_path not found: %s" % wiki_root}

    results = {
        "stale_pages": [],
        "broken_links": [],
        "orphan_pages": [],
        "missing_entities": [],
        "contradictions": [],
    }

    # Run checks
    results["broken_links"] = _check_broken_links(wiki_root)
    results["orphan_pages"] = _check_orphan_pages(wiki_root)
    results["missing_entities"] = _check_missing_entities(
        conn, wiki_root, cfg.wiki_entity_min_degree
    )
    results["contradictions"] = _check_contradictions(conn)

    # Summary stats
    summary = {
        "broken_links": len(results["broken_links"]),
        "orphan_pages": len(results["orphan_pages"]),
        "missing_entities": len(results["missing_entities"]),
        "contradictions_needing_review": len(results["contradictions"]),
        "total_issues": (
            len(results["broken_links"])
            + len(results["orphan_pages"])
            + len(results["missing_entities"])
            + len(results["contradictions"])
        ),
    }

    # Write lint report
    report_path = _write_lint_report(wiki_root, results, summary)
    summary["report_path"] = report_path

    # Append to log
    _append_lint_log(wiki_root, summary)

    log.info("Wiki lint complete: %d issues found", summary["total_issues"])
    return summary


# ---------------------------------------------------------------------------
# Lint checks
# ---------------------------------------------------------------------------

def _check_broken_links(wiki_root):
    """Find wiki-links that point to nonexistent pages."""
    # Build set of all page slugs (filenames without .md)
    existing_slugs = set()
    for dirpath, _dirs, files in os.walk(wiki_root):
        for f in files:
            if f.endswith(".md"):
                existing_slugs.add(f[:-3])  # strip .md

    broken = []
    link_pattern = re.compile(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]")

    for dirpath, _dirs, files in os.walk(wiki_root):
        for f in files:
            if not f.endswith(".md"):
                continue
            filepath = os.path.join(dirpath, f)
            try:
                with open(filepath, "r", encoding="utf-8") as fh:
                    content = fh.read()
            except Exception:
                continue

            for match in link_pattern.finditer(content):
                target = match.group(1).strip()
                if target not in existing_slugs:
                    broken.append({
                        "source_file": f,
                        "target": target,
                        "line": content[:match.start()].count("\n") + 1,
                    })

    return broken


def _check_orphan_pages(wiki_root):
    """Find pages with zero inbound wiki-links from other pages."""
    # Count inbound links per slug
    inbound_counts = {}
    link_pattern = re.compile(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]")

    all_pages = []
    for dirpath, _dirs, files in os.walk(wiki_root):
        for f in files:
            if f.endswith(".md"):
                slug = f[:-3]
                all_pages.append(slug)
                inbound_counts.setdefault(slug, 0)

    for dirpath, _dirs, files in os.walk(wiki_root):
        for f in files:
            if not f.endswith(".md"):
                continue
            filepath = os.path.join(dirpath, f)
            try:
                with open(filepath, "r", encoding="utf-8") as fh:
                    content = fh.read()
            except Exception:
                continue

            for match in link_pattern.finditer(content):
                target = match.group(1).strip()
                if target in inbound_counts:
                    inbound_counts[target] += 1

    # Orphans: pages with 0 inbound links (excluding _index and _log)
    orphans = []
    skip = {"_index", "_log"}
    for slug, count in inbound_counts.items():
        if count == 0 and slug not in skip and not slug.startswith("_log_archive"):
            orphans.append({"slug": slug, "inbound_links": 0})

    return orphans


def _check_missing_entities(conn, wiki_root, min_degree=5):
    """High-degree entity nodes that lack a wiki page."""
    # Get existing entity page slugs
    entity_dir = os.path.join(wiki_root, "entities")
    existing = set()
    if os.path.isdir(entity_dir):
        for f in os.listdir(entity_dir):
            if f.endswith(".md"):
                existing.add(f[:-3])

    # Get high-degree nodes from DB
    rows = conn.execute(
        """SELECT f.id, f.content, COUNT(DISTINCT fe.id) as edge_count
           FROM fragments f
           JOIN fragment_edges fe ON (fe.source_id = f.id OR fe.target_id = f.id)
           WHERE f.content_type NOT IN ('summary')
           GROUP BY f.id
           HAVING edge_count >= ?
           ORDER BY edge_count DESC
           LIMIT 500""",
        (min_degree,),
    ).fetchall()

    missing = []
    for row in rows:
        # Simple check: see if any existing page contains this fragment ID
        # This is approximate -- a proper check would track fragment->slug mapping
        content_preview = (row[1] or "")[:60]
        from .slugify import slugify as _slugify
        expected_slug = _slugify(content_preview)
        if expected_slug and expected_slug not in existing:
            missing.append({
                "fragment_id": row[0],
                "edge_count": row[2],
                "content_preview": content_preview,
            })

    return missing[:50]  # Cap at 50 for readability


def _check_contradictions(conn):
    """CONTRADICTS edges that need human review."""
    rows = conn.execute(
        """SELECT fe.id, fe.source_id, fe.target_id, fe.weight,
                  fs.content, ft.content
           FROM fragment_edges fe
           JOIN fragments fs ON fs.id = fe.source_id
           JOIN fragments ft ON ft.id = fe.target_id
           WHERE fe.edge_type = 'CONTRADICTS'
           ORDER BY fe.weight DESC""",
    ).fetchall()

    return [
        {
            "edge_id": r[0],
            "source_id": r[1],
            "target_id": r[2],
            "weight": r[3],
            "source_preview": (r[4] or "")[:80],
            "target_preview": (r[5] or "")[:80],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Report writing
# ---------------------------------------------------------------------------

def _write_lint_report(wiki_root, results, summary):
    """Write a lint report to the lint/ folder."""
    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")
    filename = "lint-%s.md" % date_str

    lint_dir = os.path.join(wiki_root, "lint")
    os.makedirs(lint_dir, exist_ok=True)
    report_path = os.path.join(lint_dir, filename)

    parts = []
    fm = {
        "type": "lint-report",
        "source": "memory-v4",
        "created": date_str,
        "tags": ["lint", "v4-wiki"],
        "status": "auto-generated",
    }
    parts.append(render_frontmatter(fm))
    parts.append("")
    parts.append("# Wiki Lint Report -- %s" % date_str)
    parts.append("")

    # Summary
    parts.append("## Summary")
    parts.append("")
    parts.append("| Check | Issues |")
    parts.append("|-------|--------|")
    for key, count in summary.items():
        if key != "report_path" and key != "total_issues":
            parts.append("| %s | %d |" % (key, count))
    parts.append("| **Total** | **%d** |" % summary.get("total_issues", 0))
    parts.append("")

    # Broken links
    if results["broken_links"]:
        parts.append("## Broken Links")
        parts.append("")
        for bl in results["broken_links"][:50]:
            parts.append(
                "- `%s` line %d -> `%s` (not found)"
                % (bl["source_file"], bl["line"], bl["target"])
            )
        parts.append("")

    # Orphan pages
    if results["orphan_pages"]:
        parts.append("## Orphan Pages (no inbound links)")
        parts.append("")
        for op in results["orphan_pages"][:50]:
            parts.append("- `%s`" % op["slug"])
        parts.append("")

    # Missing entities
    if results["missing_entities"]:
        parts.append("## Missing Entity Pages")
        parts.append("")
        for me in results["missing_entities"][:30]:
            parts.append(
                "- Fragment #%d (%d edges): %s"
                % (me["fragment_id"], me["edge_count"], me["content_preview"])
            )
        parts.append("")

    # Contradictions
    if results["contradictions"]:
        parts.append("## Contradictions Needing Review")
        parts.append("")
        for c in results["contradictions"][:20]:
            parts.append(
                "- Edge #%d (weight %.2f): `%s` vs `%s`"
                % (c["edge_id"], c["weight"], c["source_preview"], c["target_preview"])
            )
        parts.append("")

    parts.append("---")
    parts.append(
        "*Auto-generated lint report. %s*"
        % now.strftime("%Y-%m-%dT%H:%M:%SZ")
    )

    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))

    return report_path


def _append_lint_log(wiki_root, summary):
    """Append lint results to the wiki log."""
    log_path = os.path.join(wiki_root, "_log.md")
    if not os.path.exists(log_path):
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("# Wiki Operation Log\n\n")

    entry = render_log_entry("lint", summary)
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(entry)
        f.write("\n")
