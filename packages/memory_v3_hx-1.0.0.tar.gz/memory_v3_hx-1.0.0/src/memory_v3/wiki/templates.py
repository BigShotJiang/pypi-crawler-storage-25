"""
Markdown page templates for wiki rendering.
All output is CP1252-safe: no em dashes, no unicode arrows.
"""

from datetime import datetime, timezone


def _now_iso():
    """Current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _safe_text(text):
    """Strip non-ASCII characters for CP1252 safety."""
    if not text:
        return ""
    return text.encode("ascii", "ignore").decode("ascii").strip()


def _yaml_list(items):
    """Format a list as YAML inline list."""
    if not items:
        return "[]"
    escaped = []
    for item in items:
        s = str(item).replace('"', '\\"')
        escaped.append('"%s"' % s)
    return "[%s]" % ", ".join(escaped)


def render_frontmatter(fields):
    """Render YAML frontmatter block with --- delimiters.

    Args:
        fields: Dict of frontmatter fields. Lists are rendered as YAML lists.

    Returns:
        String starting and ending with '---'.
    """
    lines = ["---"]
    for key, value in fields.items():
        if isinstance(value, list):
            lines.append("%s: %s" % (key, _yaml_list(value)))
        elif isinstance(value, bool):
            lines.append("%s: %s" % (key, "true" if value else "false"))
        elif isinstance(value, (int, float)):
            lines.append("%s: %s" % (key, value))
        elif value is None:
            continue
        else:
            # String value -- quote if it contains special YAML chars
            sv = _safe_text(str(value))
            if any(c in sv for c in ":#{}[]|>&*!"):
                lines.append('%s: "%s"' % (key, sv.replace('"', '\\"')))
            else:
                lines.append("%s: %s" % (key, sv))
    lines.append("---")
    return "\n".join(lines)


def render_topic_page(title, summary_content, children, related,
                      contradictions, frontmatter_fields):
    """Full topic page: frontmatter + summary + child links + see also.

    Args:
        title: Page title.
        summary_content: Main summary text.
        children: List of dicts with 'slug', 'display', 'content_preview'.
        related: List of dicts with 'slug', 'display', 'edge_type'.
        contradictions: List of dicts with 'slug', 'display'.
        frontmatter_fields: Dict for frontmatter.

    Returns:
        Complete markdown page string.
    """
    parts = []

    # Frontmatter
    parts.append(render_frontmatter(frontmatter_fields))
    parts.append("")

    # Title
    parts.append("# %s" % _safe_text(title))
    parts.append("")

    # Summary
    if summary_content:
        parts.append(_safe_text(summary_content))
        parts.append("")

    # Key Details (children)
    if children:
        parts.append("## Key Details")
        parts.append("")
        for child in children[:50]:
            link = "[[%s|%s]]" % (child["slug"], _safe_text(child["display"]))
            preview = _safe_text(child.get("content_preview", ""))
            if preview:
                parts.append("- %s -- %s" % (link, preview[:80]))
            else:
                parts.append("- %s" % link)
        parts.append("")

    # See Also (related)
    if related:
        parts.append("## See Also")
        parts.append("")
        for rel in related[:20]:
            link = "[[%s|%s]]" % (rel["slug"], _safe_text(rel["display"]))
            edge_type = rel.get("edge_type", "")
            if edge_type:
                parts.append("- %s (%s)" % (link, edge_type))
            else:
                parts.append("- %s" % link)
        parts.append("")

    # Contradictions
    if contradictions:
        parts.append("## Contradictions")
        parts.append("")
        parts.append("> [!warning] Conflicting information detected")
        for contra in contradictions[:10]:
            link = "[[%s|%s]]" % (contra["slug"], _safe_text(contra["display"]))
            parts.append("> - See %s" % link)
        parts.append("")

    # Footer
    parts.append("---")
    parts.append("*Auto-generated from v4 memory. Last updated: %s*" % _now_iso())

    return "\n".join(parts)


def render_entity_page(entity_name, entity_type, description,
                       fragments, relationships, frontmatter_fields):
    """Entity page for a person, project, tool, or concept.

    Args:
        entity_name: Display name.
        entity_type: Type string (person, project, tool, concept).
        description: Summary description.
        fragments: List of dicts with 'content', 'importance', 'created_at'.
        relationships: List of dicts with 'slug', 'display', 'edge_type'.
        frontmatter_fields: Dict for frontmatter.

    Returns:
        Complete markdown page string.
    """
    parts = []

    parts.append(render_frontmatter(frontmatter_fields))
    parts.append("")
    parts.append("# %s" % _safe_text(entity_name))
    parts.append("")

    if entity_type:
        parts.append("**Type:** %s" % _safe_text(entity_type))
        parts.append("")

    if description:
        parts.append(_safe_text(description))
        parts.append("")

    # Key fragments
    if fragments:
        parts.append("## Key Facts")
        parts.append("")
        for frag in fragments[:30]:
            content = _safe_text(frag.get("content", ""))[:120]
            importance = frag.get("importance", 0)
            if importance >= 0.7:
                parts.append("- **%s**" % content)
            else:
                parts.append("- %s" % content)
        parts.append("")

    # Relationships
    if relationships:
        parts.append("## Relationships")
        parts.append("")
        for rel in relationships[:20]:
            link = "[[%s|%s]]" % (rel["slug"], _safe_text(rel["display"]))
            edge_type = rel.get("edge_type", "related")
            parts.append("- %s -> %s" % (edge_type, link))
        parts.append("")

    parts.append("---")
    parts.append("*Auto-generated from v4 memory. Last updated: %s*" % _now_iso())

    return "\n".join(parts)


def render_moc_page(domain, description, page_links, frontmatter_fields):
    """Map of Content page linking to all pages in a domain.

    Args:
        domain: Domain name.
        description: Brief domain description.
        page_links: List of dicts with 'slug', 'display', 'resolution', 'importance'.
        frontmatter_fields: Dict for frontmatter.

    Returns:
        Complete markdown page string.
    """
    parts = []

    parts.append(render_frontmatter(frontmatter_fields))
    parts.append("")
    parts.append("# %s" % _safe_text(domain))
    parts.append("")

    if description:
        parts.append(_safe_text(description))
        parts.append("")

    # Group by resolution level
    by_level = {}
    for link in page_links[:400]:
        level = link.get("resolution", 0)
        by_level.setdefault(level, []).append(link)

    level_names = {
        6: "Themes",
        5: "Projects",
        4: "Episodes",
        3: "Events",
        2: "Decisions",
        1: "Facts",
        0: "Details",
    }

    for level in sorted(by_level.keys(), reverse=True):
        name = level_names.get(level, "Level %d" % level)
        items = by_level[level]
        parts.append("## %s" % name)
        parts.append("")
        for item in sorted(items, key=lambda x: x.get("importance", 0), reverse=True):
            link = "[[%s|%s]]" % (item["slug"], _safe_text(item["display"]))
            parts.append("- %s" % link)
        parts.append("")

    parts.append("---")
    parts.append("*Auto-generated from v4 memory. Last updated: %s*" % _now_iso())

    return "\n".join(parts)


def render_index_page(moc_links, stats, frontmatter_fields):
    """Master index page linking to all MOCs.

    Args:
        moc_links: List of dicts with 'slug', 'display', 'page_count'.
        stats: Dict with 'total_pages', 'total_fragments', 'total_edges', etc.
        frontmatter_fields: Dict for frontmatter.

    Returns:
        Complete markdown page string.
    """
    parts = []

    parts.append(render_frontmatter(frontmatter_fields))
    parts.append("")
    parts.append("# Knowledge Wiki")
    parts.append("")
    parts.append("Auto-generated knowledge base from the v4 fractal memory system.")
    parts.append("")

    # Stats
    parts.append("## Statistics")
    parts.append("")
    parts.append("| Metric | Value |")
    parts.append("|--------|-------|")
    for key, value in stats.items():
        parts.append("| %s | %s |" % (_safe_text(str(key)), value))
    parts.append("")

    # MOC links
    parts.append("## Domains")
    parts.append("")
    for moc in sorted(moc_links, key=lambda x: x.get("page_count", 0), reverse=True):
        link = "[[%s|%s]]" % (moc["slug"], _safe_text(moc["display"]))
        count = moc.get("page_count", 0)
        parts.append("- %s (%d pages)" % (link, count))
    parts.append("")

    parts.append("---")
    parts.append("*Auto-generated from v4 memory. Last updated: %s*" % _now_iso())

    return "\n".join(parts)


def render_contradiction_page(edge_id, frag_a, frag_b, frontmatter_fields):
    """Contradiction report showing both sides.

    Args:
        edge_id: The CONTRADICTS edge ID.
        frag_a: Dict with 'content', 'slug', 'created_at', 'importance'.
        frag_b: Dict with 'content', 'slug', 'created_at', 'importance'.
        frontmatter_fields: Dict for frontmatter.

    Returns:
        Complete markdown page string.
    """
    parts = []

    parts.append(render_frontmatter(frontmatter_fields))
    parts.append("")
    parts.append("# Contradiction Report #%s" % edge_id)
    parts.append("")
    parts.append("> [!warning] These two pieces of knowledge contradict each other.")
    parts.append("")

    # Side A
    parts.append("## Side A")
    parts.append("")
    if frag_a.get("slug"):
        parts.append("**Source:** [[%s]]" % frag_a["slug"])
    parts.append("")
    parts.append(_safe_text(frag_a.get("content", "(no content)")))
    parts.append("")
    parts.append("- **Importance:** %s" % frag_a.get("importance", "?"))
    parts.append("- **Created:** %s" % frag_a.get("created_at", "?"))
    parts.append("")

    # Side B
    parts.append("## Side B")
    parts.append("")
    if frag_b.get("slug"):
        parts.append("**Source:** [[%s]]" % frag_b["slug"])
    parts.append("")
    parts.append(_safe_text(frag_b.get("content", "(no content)")))
    parts.append("")
    parts.append("- **Importance:** %s" % frag_b.get("importance", "?"))
    parts.append("- **Created:** %s" % frag_b.get("created_at", "?"))
    parts.append("")

    parts.append("## Resolution")
    parts.append("")
    parts.append("*Needs human review. Edit this section to resolve.*")
    parts.append("")

    parts.append("---")
    parts.append("*Auto-generated from v4 memory. Last updated: %s*" % _now_iso())

    return "\n".join(parts)


def render_log_entry(operation, stats, timestamp=None):
    """Single append-only log entry for _log.md.

    Args:
        operation: Operation name (generate, sync, lint).
        stats: Dict of operation stats.
        timestamp: ISO timestamp (defaults to now).

    Returns:
        Markdown log entry string with ## heading.
    """
    ts = timestamp or _now_iso()
    lines = []
    lines.append("## [%s] %s" % (ts, operation))
    lines.append("")
    for key, value in stats.items():
        lines.append("- **%s:** %s" % (key, value))
    lines.append("")
    return "\n".join(lines)
