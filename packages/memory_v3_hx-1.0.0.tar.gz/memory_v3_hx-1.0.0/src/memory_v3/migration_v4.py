"""
v4 Migration Tool: v3 memories -> v4 fragment graph

Converts existing v3 memories into v4 fragments with edges,
coordinates, and assemblies. v3 data is preserved untouched --
v4 tables are additive.

Migration pipeline:
1. For each v3 memory: decompose into fragments
2. Compute coordinates for all fragments
3. Convert v3 knowledge graph edges -> v4 fragment_edges
4. Preserve governance layers
5. Create assembly for each original memory
6. Build initial palace
7. Run one consolidation cycle
"""

import sqlite3
import json
import time
from datetime import datetime, timezone

from .db import (
    init_db, add_fragment, add_edge, create_assembly,
    get_fragment_stats, _serialize_f32, _now_iso,
)
from .lifecycle.decomposition import decompose
from .lifecycle.dedup import deduplicate_fragment
from .scoring.coordinates import compute_all_coordinates


def migrate_v3_to_v4(
    conn: sqlite3.Connection,
    embed_fn=None,
    batch_size: int = 100,
    verbose: bool = True,
) -> dict:
    """Migrate all v3 memories to v4 fragment graph.

    Args:
        conn: Database connection (already initialized with v4 schema).
        embed_fn: Embedding function. Required for semantic dedup and coordinates.
        batch_size: Process this many memories per batch.
        verbose: Print progress.

    Returns:
        Migration stats.
    """
    stats = {
        "memories_processed": 0,
        "fragments_created": 0,
        "fragments_deduped": 0,
        "edges_created": 0,
        "assemblies_created": 0,
        "errors": 0,
        "elapsed_seconds": 0,
    }

    start = time.monotonic()

    # Count total memories
    total = conn.execute(
        "SELECT COUNT(*) FROM memories WHERE archived = 0"
    ).fetchone()[0]

    if verbose:
        print(f"Migrating {total} v3 memories to v4 fragments...")

    offset = 0
    while offset < total:
        rows = conn.execute(
            """SELECT id, content, content_type, protected, governance_layer,
                      importance_score, surprise_score, created_at, tags
            FROM memories
            WHERE archived = 0
            ORDER BY id
            LIMIT ? OFFSET ?""",
            (batch_size, offset)
        ).fetchall()

        if not rows:
            break

        for row in rows:
            mem = dict(row)
            mem_id = mem["id"]

            try:
                # Check if already migrated
                existing = conn.execute(
                    "SELECT COUNT(*) FROM fragments WHERE source_memory_id = ?",
                    (mem_id,)
                ).fetchone()[0]
                if existing > 0:
                    stats["memories_processed"] += 1
                    continue

                content = mem["content"]
                content_type = mem.get("content_type", "fact")
                protected = bool(mem.get("protected", 0))
                governance = mem.get("governance_layer", 3)
                importance = mem.get("importance_score", 0.5)

                # Decompose into fragments
                result = decompose(content, source=f"migration_v3_memory_{mem_id}")

                created_ids = []
                for frag_data in result.get("fragments", []):
                    frag_content = frag_data["content"]
                    frag_embedding = embed_fn(frag_content) if embed_fn else None

                    # Dedup
                    if embed_fn:
                        dedup = deduplicate_fragment(
                            conn, frag_content, embedding=frag_embedding,
                            context_fragment_ids=created_ids,
                        )
                        if dedup["is_duplicate"]:
                            created_ids.append(dedup["existing_fragment"]["id"])
                            stats["fragments_deduped"] += 1
                            continue

                    # Compute coordinates
                    coords = {}
                    if embed_fn:
                        coords = compute_all_coordinates(
                            frag_content, embed_fn=embed_fn,
                            governance_layer=governance,
                            content_type=content_type,
                            surprise_score=mem.get("surprise_score", 0.5),
                            protected=protected,
                        )

                    # Create fragment
                    frag_id = add_fragment(
                        conn, content=frag_content, embedding=frag_embedding,
                        content_type=content_type,
                        source=f"v3_memory_{mem_id}",
                        source_memory_id=mem_id,
                        protected=protected, governance_layer=governance,
                        importance=coords.get("importance", importance),
                        timeline_coord=coords.get("timeline") or result.get("timeline_coord"),
                    )
                    created_ids.append(frag_id)
                    stats["fragments_created"] += 1

                # Create edges from decomposition
                for edge_data in result.get("edges", []):
                    src_idx = edge_data.get("source_idx", 0)
                    tgt_idx = edge_data.get("target_idx", 0)
                    if src_idx < len(created_ids) and tgt_idx < len(created_ids):
                        add_edge(
                            conn,
                            source_id=created_ids[src_idx],
                            target_id=created_ids[tgt_idx],
                            system=edge_data.get("system", "meaning"),
                            edge_type=edge_data.get("edge_type", "CO_DISCOVERED"),
                        )
                        stats["edges_created"] += 1

                # Create assembly linking back to original memory
                if created_ids:
                    create_assembly(
                        conn, created_ids,
                        convergence_score=0.5,  # Baseline for migrated
                        confidence=0.7,
                        contributing_systems=["migration"],
                        context=f"Migrated from v3 memory #{mem_id}",
                    )
                    stats["assemblies_created"] += 1

                stats["memories_processed"] += 1

            except Exception as e:
                stats["errors"] += 1
                if verbose:
                    print(f"  Error migrating memory #{mem_id}: {e}")

        offset += batch_size
        if verbose:
            pct = min(100, round(offset / total * 100))
            print(f"  Progress: {pct}% ({stats['memories_processed']}/{total} memories, "
                  f"{stats['fragments_created']} fragments created)")

    stats["elapsed_seconds"] = round(time.monotonic() - start, 2)

    if verbose:
        print(f"\nMigration complete in {stats['elapsed_seconds']}s:")
        print(f"  Memories processed: {stats['memories_processed']}")
        print(f"  Fragments created: {stats['fragments_created']}")
        print(f"  Fragments deduped: {stats['fragments_deduped']}")
        print(f"  Edges created: {stats['edges_created']}")
        print(f"  Assemblies created: {stats['assemblies_created']}")
        print(f"  Errors: {stats['errors']}")

    return stats


def migrate_v3_graph_edges(conn: sqlite3.Connection) -> dict:
    """Convert v3 knowledge graph edges into v4 fragment_edges.

    Maps v3 graph layer -> v4 system:
      semantic -> meaning
      temporal -> timeline
      causal -> reasoning
      entity -> meaning (entities are semantic)
    """
    stats = {"edges_migrated": 0}

    V3_TO_V4_SYSTEM = {
        "semantic": "meaning",
        "temporal": "timeline",
        "causal": "reasoning",
        "entity": "meaning",
    }

    # Try to load v3 graph edges from the graphs directory
    try:
        from .graphs import GraphManager
        gm = GraphManager(conn)

        for layer_name, graph in gm._graphs.items():
            v4_system = V3_TO_V4_SYSTEM.get(layer_name, "meaning")

            for src, tgt, data in graph.edges(data=True):
                edge_type = data.get("type", "RELATED_TO")
                weight = data.get("weight", 0.5)

                # Map v3 node IDs (which are memory IDs) to fragment IDs
                src_frags = conn.execute(
                    "SELECT id FROM fragments WHERE source_memory_id = ? LIMIT 1",
                    (src,)
                ).fetchone()
                tgt_frags = conn.execute(
                    "SELECT id FROM fragments WHERE source_memory_id = ? LIMIT 1",
                    (tgt,)
                ).fetchone()

                if src_frags and tgt_frags:
                    add_edge(
                        conn, src_frags[0], tgt_frags[0],
                        system=v4_system,
                        edge_type=edge_type.upper(),
                        weight=weight,
                    )
                    stats["edges_migrated"] += 1

    except Exception as e:
        stats["error"] = str(e)

    return stats
