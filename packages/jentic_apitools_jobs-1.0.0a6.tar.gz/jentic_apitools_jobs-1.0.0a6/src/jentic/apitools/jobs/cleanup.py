"""Job cleanup utilities: retention-based cleanup with optional filesystem deletion."""

from __future__ import annotations

import logging
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path

from jentic.apitools.common.models import JobStatus
from jentic.apitools.jobs.storage import JobStorage


logger = logging.getLogger(__name__)

_TERMINAL_STATUSES = (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED)
_SAFE_DIR_PREFIXES = ("jentic-", "tmp")


def cleanup_expired_jobs(
    storage: JobStorage,
    older_than_hours: int,
    cleanup_output_dirs: bool = False,
) -> int:
    """Remove expired jobs and optionally delete their output directories.

    For each terminal job (COMPLETED, FAILED, CANCELLED) older than
    *older_than_hours*, this function will optionally delete the output
    directory from disk, then delegate to ``storage.cleanup_old_jobs()``
    for data removal.

    Returns the number of jobs removed.
    """
    if cleanup_output_dirs:
        _delete_output_dirs_for_expired(storage, older_than_hours)

    removed = storage.cleanup_old_jobs(older_than_hours)
    if removed > 0:
        logger.info("Cleaned up %d expired jobs (retention=%dh)", removed, older_than_hours)
    return removed


def extract_output_dir(storage: JobStorage, job_id: str) -> str | None:
    """Extract the output_dir for a job from request_data or result."""
    request_data = storage.get_job_request_data(job_id)
    if request_data:
        meta = request_data.get("meta")
        if meta and meta.get("output_dir"):
            return meta["output_dir"]

    result = storage.get_job_result(job_id)
    if result and result.get("output_dir"):
        return result["output_dir"]

    return None


def safe_delete_dir(dir_path: str, context: str = "") -> None:
    """Delete a directory tree if it looks like an auto-generated temp dir.

    Validates both the directory name prefix AND that the resolved path
    resides under the system temp directory to prevent traversal attacks.
    """
    path = Path(dir_path)
    if not path.exists():
        return
    resolved = path.resolve()
    if not resolved.name.startswith(_SAFE_DIR_PREFIXES):
        logger.warning(
            "Skipping deletion of non-temp directory %s (%s)",
            dir_path,
            context,
        )
        return
    # Ensure the resolved path is actually under the system temp directory
    import tempfile

    temp_root = Path(tempfile.gettempdir()).resolve()
    if not resolved.is_relative_to(temp_root):
        logger.warning(
            "Skipping deletion of directory outside temp root %s (%s)",
            dir_path,
            context,
        )
        return
    try:
        shutil.rmtree(resolved)
        logger.debug("Deleted output directory %s (%s)", dir_path, context)
    except OSError:
        logger.warning(
            "Failed to delete output directory %s (%s)",
            dir_path,
            context,
            exc_info=True,
        )


def _delete_output_dirs_for_expired(
    storage: JobStorage,
    older_than_hours: int,
) -> None:
    """Delete output directories for jobs that are about to be cleaned up."""
    cutoff = datetime.now(timezone.utc) - timedelta(hours=older_than_hours)
    jobs, _total = storage.list_jobs(limit=10000)
    for job_info in jobs:
        if job_info.status not in _TERMINAL_STATUSES:
            continue
        if job_info.created_at >= cutoff:
            continue
        output_dir = extract_output_dir(storage, job_info.job_id)
        if output_dir:
            safe_delete_dir(output_dir, context=f"job:{job_info.job_id}")
