"""Jobs package configuration.

Delegates to the central settings in ``jentic.apitools.common.settings``.
The :class:`JobsSettings` class is re-exported here for backward compatibility.
"""

from __future__ import annotations

from jentic.apitools.common.settings import JobsSettings, settings


__all__ = ["JobsSettings", "get_jobs_settings"]


def get_jobs_settings() -> JobsSettings:
    """Return the jobs settings section from the central configuration."""
    return settings.jobs
