"""Sync processor wrappers that bridge job execution to pipeline functions.

Each processor:
1. Builds an :class:`OASJsonRequest` from primitive parameters.
2. Calls the corresponding pipeline function with ``progress_callback``.
3. Returns a JSON-serialisable result dict.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from jentic.apitools.common.models import (
    MetaZipUrl,
    OASJsonRequest,
    OASProcessConfiguration,
    OASRequestMeta,
    SpecSourceUrl,
)
from jentic.apitools.common.utils.diagnostic_utils import classify_error, serialize_diagnostic
from jentic.apitools.jobs.progress import ProgressReporter
from jentic.apitools.pipelines import import_openapi, score_openapi


logger = logging.getLogger(__name__)


class ProcessingError(Exception):
    """Raised when a pipeline operation fails.

    Carries optional structured diagnostic information so that callers can
    propagate rich error details to API consumers.
    """

    def __init__(
        self,
        message: str,
        *,
        diagnostics: list | None = None,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.diagnostics: list = diagnostics or []
        self.error_code: str | None = error_code


# ---------------------------------------------------------------------------
# Request builders
# ---------------------------------------------------------------------------


def _build_request(
    spec_url: str,
    label: str | None = None,
    output_dir: str | None = None,
    enable_llm_analysis: bool = False,
    include_diagnostics: bool = False,
    skip_bundle: bool = False,
) -> OASJsonRequest:
    """Build an :class:`OASJsonRequest` from primitive params."""
    derived_label = label or spec_url
    process_config = OASProcessConfiguration(
        enable_llm_analysis=enable_llm_analysis,
        include_diagnostics_in_score=include_diagnostics,
        skip_bundle=skip_bundle,
    )
    meta = OASRequestMeta(
        label=derived_label,
        output_dir=output_dir,
        oas_process_configuration=process_config,
    )
    return OASJsonRequest(
        spec=SpecSourceUrl(kind="url", url=spec_url),
        meta=meta,
    )


# ---------------------------------------------------------------------------
# Processors
# ---------------------------------------------------------------------------


def process_score(
    *,
    spec_url: str,
    reporter: ProgressReporter,
    enable_llm_analysis: bool = False,
    include_diagnostics: bool = False,
    skip_bundle: bool = False,
    label: str | None = None,
    output_dir: str | None = None,
) -> dict:
    """Run the scoring pipeline and return a scorecard dict."""
    reporter.report(2, "Preparing scoring request")
    oas_request = _build_request(
        spec_url,
        label=label,
        output_dir=output_dir,
        enable_llm_analysis=enable_llm_analysis,
        include_diagnostics=include_diagnostics,
        skip_bundle=skip_bundle,
    )
    reporter.report(3, "Starting scoring pipeline")
    result = score_openapi(
        oas_request,
        spec_url=spec_url,
        progress_callback=reporter.report,
    )
    if not result.success:
        error_code, error_message = classify_error(result.diagnostics)
        serialized = [serialize_diagnostic(d) for d in result.diagnostics]
        raise ProcessingError(error_message, diagnostics=serialized, error_code=error_code)

    reporter.report(92, "Loading scorecard")
    scorecard = _load_scorecard(result)
    reporter.report(95, "Finalizing")
    return {"scorecard": scorecard}


def process_import(
    *,
    spec_url: str,
    reporter: ProgressReporter,
    meta_zip_url: str | None = None,
    validate_unbundled: bool = True,
    label: str | None = None,
    output_dir: str | None = None,
    enable_llm_analysis: bool = False,
) -> dict:
    """Run the import pipeline and return a result dict."""
    reporter.report(2, "Preparing import request")
    oas_request = _build_request(
        spec_url,
        label=label,
        output_dir=output_dir,
        enable_llm_analysis=enable_llm_analysis,
    )
    # Override meta_zip if provided
    if meta_zip_url:
        oas_request = oas_request.model_copy(
            update={"meta_zip": MetaZipUrl(kind="url", url=meta_zip_url)}
        )

    reporter.report(3, "Starting import pipeline")
    result = import_openapi(
        oas_request,
        spec_url=spec_url,
        meta_zip_url=meta_zip_url,
        validate_unbundled=validate_unbundled,
        progress_callback=reporter.report,
    )
    if not result.success:
        error_code, error_message = classify_error(result.diagnostics)
        serialized = [serialize_diagnostic(d) for d in result.diagnostics]
        raise ProcessingError(error_message, diagnostics=serialized, error_code=error_code)

    reporter.report(95, "Finalizing")
    return {
        "success": True,
        "version_path": result.version_dir,
        "output_dir": result.output_dir,
        "endpoint_name": result.endpoint_name,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_scorecard(result) -> dict:
    """Extract scorecard from the pipeline result."""
    if result.output_dir is None:
        raise ProcessingError("Pipeline completed but produced no output directory")

    # The pipeline writes scorecard.json into the version directory
    if result.version_dir:
        scorecard_path = Path(result.version_dir) / "scorecard.json"
        if scorecard_path.exists():
            return json.loads(scorecard_path.read_text(encoding="utf-8"))

    # Fallback: search in output_dir
    output_path = Path(result.output_dir)
    for candidate in output_path.rglob("scorecard.json"):
        return json.loads(candidate.read_text(encoding="utf-8"))

    raise ProcessingError("Scorecard not found in pipeline output")
