"""Celery application for distributed job execution.

Only imported when ``storage_backend=redis`` and the ``redis`` extra is
installed.  Attempting to import without Celery raises :class:`ImportError`.

Start the worker with::

    celery -A jentic.apitools.jobs.celery_app worker --loglevel=info
"""

from __future__ import annotations


try:
    from celery import Celery  # type: ignore[import-untyped]
except ImportError as exc:
    raise ImportError(
        "Celery is required for the Redis job backend. Install it with: pip install 'jobs[redis]'"
    ) from exc

from jentic.apitools.common.settings import settings


_settings = settings.jobs

celery_app = Celery(
    "jentic_jobs",
    broker=_settings.redis_url,
    backend=_settings.redis_url,
)
celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    worker_concurrency=_settings.max_concurrent_jobs,
    task_track_started=True,
)
