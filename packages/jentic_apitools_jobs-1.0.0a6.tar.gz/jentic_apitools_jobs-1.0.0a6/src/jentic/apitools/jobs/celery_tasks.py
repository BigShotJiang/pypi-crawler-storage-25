"""Celery task definitions for job processing.

Each task creates its own :class:`RedisJobStorage` and
:class:`JobProgressReporter`, then delegates to the corresponding
processor function.
"""

from __future__ import annotations

import logging

from jentic.apitools.jobs.celery_app import _settings, celery_app
from jentic.apitools.jobs.processors import process_import, process_score
from jentic.apitools.jobs.progress import JobProgressReporter
from jentic.apitools.jobs.redis_storage import RedisJobStorage


logger = logging.getLogger(__name__)


def _make_reporter(job_id: str) -> JobProgressReporter:
    storage = RedisJobStorage(redis_url=_settings.redis_url)
    return JobProgressReporter(job_id, storage)


@celery_app.task(bind=True, name="jentic.jobs.score")
def celery_score_task(self, job_id: str, **params) -> None:  # noqa: ANN001
    reporter = _make_reporter(job_id)
    reporter.start()
    try:
        result = process_score(reporter=reporter, **params)
        reporter.complete(result)
    except Exception as exc:
        reporter.fail(f"{type(exc).__name__}: {exc}")
        raise


@celery_app.task(bind=True, name="jentic.jobs.import")
def celery_import_task(self, job_id: str, **params) -> None:  # noqa: ANN001
    reporter = _make_reporter(job_id)
    reporter.start()
    try:
        result = process_import(reporter=reporter, **params)
        reporter.complete(result)
    except Exception as exc:
        reporter.fail(f"{type(exc).__name__}: {exc}")
        raise
