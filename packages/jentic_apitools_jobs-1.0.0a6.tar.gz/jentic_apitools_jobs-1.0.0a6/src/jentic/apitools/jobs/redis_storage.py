"""Redis-backed job storage using sync redis-py."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone


try:
    import redis  # type: ignore[import-untyped]
except ImportError as exc:
    raise ImportError(
        "The 'redis' package is required for RedisJobStorage. "
        "Install it with: pip install 'jobs[redis]'"
    ) from exc

from jentic.apitools.common.models import (
    JobInfo,
    JobOperation,
    JobStatus,
    ProgressEvent,
)
from jentic.apitools.jobs.storage import JobStorage


_KEY_PREFIX = "jentic:job"


class RedisJobStorage(JobStorage):
    """Thread-safe Redis-backed job storage.

    Key layout::

        jentic:job:{job_id}           — hash  (metadata fields)
        jentic:job:{job_id}:request   — string (JSON request data)
        jentic:job:{job_id}:result    — string (JSON result data)
        jentic:job:{job_id}:events    — list   (JSON progress events)
        jentic:job:index              — sorted set (score = timestamp)
    """

    def __init__(self, redis_url: str = "redis://localhost:6379/0") -> None:
        self._redis: redis.Redis = redis.Redis.from_url(redis_url, decode_responses=True)

    def close(self) -> None:
        self._redis.close()

    # -- key helpers ------------------------------------------------------

    @staticmethod
    def _job_key(job_id: str) -> str:
        return f"{_KEY_PREFIX}:{job_id}"

    @staticmethod
    def _request_key(job_id: str) -> str:
        return f"{_KEY_PREFIX}:{job_id}:request"

    @staticmethod
    def _result_key(job_id: str) -> str:
        return f"{_KEY_PREFIX}:{job_id}:result"

    @staticmethod
    def _events_key(job_id: str) -> str:
        return f"{_KEY_PREFIX}:{job_id}:events"

    @staticmethod
    def _index_key() -> str:
        return f"{_KEY_PREFIX}:index"

    # -- serialisation helpers -------------------------------------------

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)

    @staticmethod
    def _dt_to_str(dt: datetime | None) -> str:
        return dt.isoformat() if dt else ""

    @staticmethod
    def _str_to_dt(s: str) -> datetime | None:
        if not s:
            return None
        return datetime.fromisoformat(s)

    def _hash_to_job_info(self, h: dict[str, str]) -> JobInfo:
        return JobInfo(
            job_id=h["job_id"],
            operation=JobOperation(h["operation"]),
            status=JobStatus(h["status"]),
            progress=int(h.get("progress", "0")),
            progress_message=h.get("progress_message", ""),
            created_at=self._str_to_dt(h["created_at"]),  # type: ignore[arg-type]
            started_at=self._str_to_dt(h.get("started_at", "")),
            completed_at=self._str_to_dt(h.get("completed_at", "")),
            error=h.get("error") or None,
        )

    # -- public API -------------------------------------------------------

    def create_job(
        self,
        job_id: str,
        operation: JobOperation,
        request_data: dict | None = None,
        accept_header: str | None = None,
    ) -> JobInfo:
        now = self._now()
        mapping = {
            "job_id": job_id,
            "operation": operation.value,
            "status": JobStatus.PENDING.value,
            "progress": "0",
            "progress_message": "",
            "created_at": self._dt_to_str(now),
            "started_at": "",
            "completed_at": "",
            "error": "",
            "accept_header": accept_header or "",
        }
        pipe = self._redis.pipeline()
        pipe.hset(self._job_key(job_id), mapping=mapping)
        if request_data is not None:
            pipe.set(self._request_key(job_id), json.dumps(request_data))
        pipe.zadd(self._index_key(), {job_id: now.timestamp()})
        pipe.execute()

        return JobInfo(
            job_id=job_id,
            operation=operation,
            status=JobStatus.PENDING,
            progress=0,
            progress_message="",
            created_at=now,
        )

    def get_job(self, job_id: str) -> JobInfo | None:
        h = self._redis.hgetall(self._job_key(job_id))
        if not h:
            return None
        return self._hash_to_job_info(h)

    def update_job_status(
        self,
        job_id: str,
        status: JobStatus,
        error: str | None = None,
    ) -> None:
        now = self._now()
        updates: dict[str, str] = {"status": status.value}
        if error is not None:
            updates["error"] = error
        if status == JobStatus.RUNNING:
            # only set started_at if not already set
            current = self._redis.hget(self._job_key(job_id), "started_at")
            if not current:
                updates["started_at"] = self._dt_to_str(now)
        if status in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED):
            updates["completed_at"] = self._dt_to_str(now)
        self._redis.hset(self._job_key(job_id), mapping=updates)

    def update_job_progress(
        self,
        job_id: str,
        progress: int,
        message: str,
    ) -> None:
        now = self._now()
        pipe = self._redis.pipeline()
        pipe.hset(
            self._job_key(job_id),
            mapping={"progress": str(progress), "progress_message": message},
        )
        event = json.dumps(
            {
                "timestamp": self._dt_to_str(now),
                "progress": progress,
                "message": message,
            }
        )
        pipe.rpush(self._events_key(job_id), event)
        pipe.execute()

    def set_job_result(self, job_id: str, result: dict) -> None:
        self._redis.set(self._result_key(job_id), json.dumps(result))

    def get_job_result(self, job_id: str) -> dict | None:
        raw = self._redis.get(self._result_key(job_id))
        if raw is None:
            return None
        return json.loads(raw)

    def get_job_request_data(self, job_id: str) -> dict | None:
        raw = self._redis.get(self._request_key(job_id))
        if raw is None:
            return None
        return json.loads(raw)

    def get_job_accept_header(self, job_id: str) -> str | None:
        val = self._redis.hget(self._job_key(job_id), "accept_header")
        return val if val else None

    def list_jobs(
        self,
        status: JobStatus | None = None,
        operation: JobOperation | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[JobInfo], int]:
        # Get all job IDs ordered newest first
        all_ids: list[str] = self._redis.zrevrange(self._index_key(), 0, -1)
        results: list[JobInfo] = []
        for job_id in all_ids:
            h = self._redis.hgetall(self._job_key(job_id))
            if not h:
                continue
            if status is not None and h.get("status") != status.value:
                continue
            if operation is not None and h.get("operation") != operation.value:
                continue
            results.append(self._hash_to_job_info(h))
        total = len(results)
        page = results[offset : offset + limit]
        return page, total

    def delete_job(self, job_id: str) -> bool:
        key = self._job_key(job_id)
        existed = self._redis.exists(key)
        if not existed:
            return False
        pipe = self._redis.pipeline()
        pipe.delete(
            key, self._request_key(job_id), self._result_key(job_id), self._events_key(job_id)
        )
        pipe.zrem(self._index_key(), job_id)
        pipe.execute()
        return True

    def cleanup_old_jobs(self, older_than_hours: int) -> int:
        cutoff = self._now() - timedelta(hours=older_than_hours)
        cutoff_ts = cutoff.timestamp()
        # IDs created before cutoff
        old_ids: list[str] = self._redis.zrangebyscore(self._index_key(), "-inf", cutoff_ts)
        removed = 0
        for job_id in old_ids:
            status_val = self._redis.hget(self._job_key(job_id), "status")
            if status_val in (
                JobStatus.COMPLETED.value,
                JobStatus.FAILED.value,
                JobStatus.CANCELLED.value,
            ):
                self.delete_job(job_id)
                removed += 1
        return removed

    def get_progress_events(self, job_id: str) -> list[ProgressEvent]:
        raw_events = self._redis.lrange(self._events_key(job_id), 0, -1)
        events: list[ProgressEvent] = []
        for raw in raw_events:
            evt = json.loads(raw)
            events.append(
                ProgressEvent(
                    timestamp=datetime.fromisoformat(evt["timestamp"]),
                    progress=evt["progress"],
                    message=evt["message"],
                )
            )
        return events
