"""Celery-based task runner for distributed job execution."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from jentic.apitools.common.models import JobOperation
from jentic.apitools.jobs.runner import TaskRunner
from jentic.apitools.jobs.storage import JobStorage


if TYPE_CHECKING:
    from jentic.apitools.jobs.config import JobsSettings

logger = logging.getLogger(__name__)


class CeleryRunner(TaskRunner):
    """Task runner that dispatches jobs to Celery workers.

    Requires the ``redis`` extra to be installed.
    """

    def __init__(self, storage: JobStorage, settings: JobsSettings) -> None:
        self._storage = storage
        self._settings = settings
        # Lazy imports so the module can be imported without Celery installed
        # as long as CeleryRunner is not actually instantiated.
        from jentic.apitools.jobs.celery_app import celery_app

        self._celery_app = celery_app

    @property
    def storage(self) -> JobStorage:
        return self._storage

    def submit_job(
        self,
        job_id: str,
        operation: JobOperation,
        params: dict,
    ) -> None:
        from jentic.apitools.jobs.celery_tasks import (
            celery_import_task,
            celery_score_task,
        )

        if operation == JobOperation.SCORE:
            celery_score_task.delay(job_id, **params)
        elif operation == JobOperation.IMPORT:
            celery_import_task.delay(job_id, **params)
        else:
            raise ValueError(f"Unknown operation: {operation}")

    def cancel_job(self, job_id: str) -> bool:
        self._celery_app.control.revoke(job_id, terminate=True)
        return True

    def shutdown(self, wait: bool = True) -> None:
        # Celery workers manage their own lifecycle.
        pass
