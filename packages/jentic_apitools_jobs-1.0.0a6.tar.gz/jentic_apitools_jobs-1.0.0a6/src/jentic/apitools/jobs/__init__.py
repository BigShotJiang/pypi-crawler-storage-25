"""Jentic API Tools — Async job execution with pluggable backends."""

from __future__ import annotations

from typing import TYPE_CHECKING

from jentic.apitools.jobs.config import JobsSettings
from jentic.apitools.jobs.processors import ProcessingError, process_import, process_score
from jentic.apitools.jobs.progress import JobProgressReporter, ProgressReporter
from jentic.apitools.jobs.runner import TaskRunner, ThreadPoolRunner
from jentic.apitools.jobs.storage import JobStorage, MemoryJobStorage, create_job_storage


if TYPE_CHECKING:
    pass

__all__ = [
    "JobsSettings",
    "JobStorage",
    "MemoryJobStorage",
    "create_job_storage",
    "ProgressReporter",
    "JobProgressReporter",
    "TaskRunner",
    "ThreadPoolRunner",
    "ProcessingError",
    "process_score",
    "process_import",
    "create_task_runner",
]


def create_task_runner(settings: JobsSettings | None = None) -> TaskRunner:
    """Factory: return a :class:`ThreadPoolRunner` or :class:`CeleryRunner`.

    - ``memory`` backend → :class:`ThreadPoolRunner`
    - ``redis`` backend  → :class:`CeleryRunner`
    """
    if settings is None:
        settings = JobsSettings()
    storage = create_job_storage(settings)
    if settings.storage_backend == "redis":
        from jentic.apitools.jobs.celery_runner import CeleryRunner

        return CeleryRunner(storage, settings)
    return ThreadPoolRunner(storage, settings)
