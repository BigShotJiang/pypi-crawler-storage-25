"""Progress reporting: protocol + concrete implementation."""

from __future__ import annotations

import time
from typing import Protocol, runtime_checkable

from jentic.apitools.common.models import JobStatus
from jentic.apitools.jobs.storage import JobStorage


@runtime_checkable
class ProgressReporter(Protocol):
    """Sync-only interface for reporting progress from worker threads."""

    def report(self, progress: int, message: str) -> None: ...


class JobProgressReporter:
    """Concrete reporter that writes directly to :class:`JobStorage`.

    Features:
    - **Monotonic guard**: ignores updates whose progress is lower than the
      last accepted value.
    - **Throttling**: skips intermediate updates that arrive faster than
      *min_interval_s* (boundary values 0 and 100 are never throttled).
    """

    def __init__(
        self,
        job_id: str,
        storage: JobStorage,
        *,
        min_interval_s: float = 0.5,
    ) -> None:
        self._job_id = job_id
        self._storage = storage
        self._min_interval = min_interval_s
        self._last_progress: int = -1
        self._last_update: float = 0.0

    # -- progress callback (matches ProgressCallback signature) -----------

    def report(self, progress: int, message: str) -> None:
        """Record a progress milestone.

        Silently drops out-of-order or too-frequent updates.
        """
        if progress < self._last_progress:
            return

        now = time.monotonic()
        if now - self._last_update < self._min_interval and progress not in (0, 100):
            return

        self._storage.update_job_progress(self._job_id, progress, message)
        self._last_progress = progress
        self._last_update = now

    # -- lifecycle helpers (called by the runner, not by pipelines) --------

    def start(self) -> None:
        """Mark the job as RUNNING."""
        self._storage.update_job_status(self._job_id, JobStatus.RUNNING)

    def complete(self, result: dict) -> None:
        """Store the result and mark the job as COMPLETED.

        Result is persisted before the status transition so that clients
        polling ``/jobs/{id}/result`` always find data once status is COMPLETED.
        """
        self._storage.set_job_result(self._job_id, result)
        self._storage.update_job_progress(self._job_id, 100, "Completed")
        self._storage.update_job_status(self._job_id, JobStatus.COMPLETED)

    def fail(
        self,
        error: str,
        *,
        error_code: str | None = None,
        diagnostics: list | None = None,
    ) -> None:
        """Mark the job as FAILED with an error message.

        When *error_code* and *diagnostics* are provided they are persisted as
        the job result so that callers polling ``/jobs/{id}/result`` receive
        structured error information.
        """
        self._storage.set_job_result(
            self._job_id,
            {
                "success": False,
                "error": error,
                "error_code": error_code,
                "diagnostics": diagnostics or [],
            },
        )
        self._storage.update_job_status(self._job_id, JobStatus.FAILED, error=error)
