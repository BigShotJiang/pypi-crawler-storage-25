"""Task runner interface and ThreadPoolExecutor-based implementation."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from concurrent.futures import Future, ThreadPoolExecutor
from typing import TYPE_CHECKING

from jentic.apitools.common.models import JobOperation
from jentic.apitools.jobs.processors import ProcessingError, process_import, process_score
from jentic.apitools.jobs.progress import JobProgressReporter
from jentic.apitools.jobs.storage import JobStorage


if TYPE_CHECKING:
    from jentic.apitools.jobs.config import JobsSettings


logger = logging.getLogger(__name__)


class TaskRunner(ABC):
    """Abstract interface for submitting background jobs."""

    @abstractmethod
    def submit_job(
        self,
        job_id: str,
        operation: JobOperation,
        params: dict,
    ) -> None:
        """Submit a job for background execution.

        The job must already exist in storage (PENDING state).
        """

    @abstractmethod
    def cancel_job(self, job_id: str) -> bool:
        """Attempt to cancel a running job. Returns ``True`` if cancelled."""

    @abstractmethod
    def shutdown(self, wait: bool = True) -> None:
        """Shut down the runner, optionally waiting for in-flight jobs."""

    @property
    def storage(self) -> JobStorage:
        """Return the underlying storage instance."""
        raise NotImplementedError


class ThreadPoolRunner(TaskRunner):
    """Default runner backed by :class:`~concurrent.futures.ThreadPoolExecutor`."""

    def __init__(self, storage: JobStorage, settings: JobsSettings) -> None:
        self._storage = storage
        self._settings = settings
        self._executor = ThreadPoolExecutor(
            max_workers=settings.max_concurrent_jobs,
            thread_name_prefix="job-worker",
        )
        self._futures: dict[str, Future] = {}

    @property
    def storage(self) -> JobStorage:
        return self._storage

    def submit_job(
        self,
        job_id: str,
        operation: JobOperation,
        params: dict,
    ) -> None:
        future = self._executor.submit(self._run_job, job_id, operation, params)
        self._futures[job_id] = future
        future.add_done_callback(lambda _f: self._futures.pop(job_id, None))

    def cancel_job(self, job_id: str) -> bool:
        future = self._futures.get(job_id)
        if future is not None and future.cancel():
            return True
        return False

    def shutdown(self, wait: bool = True) -> None:
        self._executor.shutdown(wait=wait)

    # -- internal ---------------------------------------------------------

    def _run_job(
        self,
        job_id: str,
        operation: JobOperation,
        params: dict,
    ) -> None:
        reporter = JobProgressReporter(job_id, self._storage)
        reporter.start()
        try:
            if operation == JobOperation.SCORE:
                result = process_score(reporter=reporter, **params)
            elif operation == JobOperation.IMPORT:
                result = process_import(reporter=reporter, **params)
            else:
                raise ValueError(f"Unknown operation: {operation}")
            reporter.complete(result)
        except ProcessingError as exc:
            logger.exception("Job %s failed", job_id)
            reporter.fail(
                str(exc),
                error_code=exc.error_code,
                diagnostics=exc.diagnostics,
            )
        except Exception as exc:
            logger.exception("Job %s failed", job_id)
            reporter.fail(f"{type(exc).__name__}: {exc}")
