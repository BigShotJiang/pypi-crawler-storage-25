"""Job storage interface and in-memory implementation."""

from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING

from jentic.apitools.common.models import (
    JobInfo,
    JobOperation,
    JobStatus,
    ProgressEvent,
)


if TYPE_CHECKING:
    from jentic.apitools.jobs.config import JobsSettings


class JobStorage(ABC):
    """Abstract interface for job persistence.

    All methods are synchronous and thread-safe.
    """

    @abstractmethod
    def create_job(
        self,
        job_id: str,
        operation: JobOperation,
        request_data: dict | None = None,
        accept_header: str | None = None,
    ) -> JobInfo:
        """Create a new job record in PENDING state."""

    @abstractmethod
    def get_job(self, job_id: str) -> JobInfo | None:
        """Return job info, or ``None`` if not found."""

    @abstractmethod
    def update_job_status(
        self,
        job_id: str,
        status: JobStatus,
        error: str | None = None,
    ) -> None:
        """Update the status (and optionally the error message) of a job."""

    @abstractmethod
    def update_job_progress(
        self,
        job_id: str,
        progress: int,
        message: str,
    ) -> None:
        """Record a progress update for a job."""

    @abstractmethod
    def set_job_result(self, job_id: str, result: dict) -> None:
        """Store the result payload for a completed job."""

    @abstractmethod
    def get_job_result(self, job_id: str) -> dict | None:
        """Retrieve the stored result, or ``None``."""

    @abstractmethod
    def get_job_request_data(self, job_id: str) -> dict | None:
        """Retrieve the original request data."""

    @abstractmethod
    def get_job_accept_header(self, job_id: str) -> str | None:
        """Retrieve the Accept header stored with the job."""

    @abstractmethod
    def list_jobs(
        self,
        status: JobStatus | None = None,
        operation: JobOperation | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[JobInfo], int]:
        """List jobs with optional filtering and pagination.

        Returns ``(jobs, total_count)``.
        """

    @abstractmethod
    def delete_job(self, job_id: str) -> bool:
        """Delete a job and its associated data. Returns ``True`` if deleted."""

    @abstractmethod
    def cleanup_old_jobs(self, older_than_hours: int) -> int:
        """Remove jobs older than *older_than_hours*. Returns count removed."""

    @abstractmethod
    def get_progress_events(self, job_id: str) -> list[ProgressEvent]:
        """Return the ordered list of progress events for a job."""


class MemoryJobStorage(JobStorage):
    """Thread-safe in-memory job storage backed by a plain ``dict``."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._jobs: dict[str, dict] = {}

    # -- helpers ----------------------------------------------------------

    def _now(self) -> datetime:
        return datetime.now(timezone.utc)

    def _to_job_info(self, data: dict) -> JobInfo:
        return JobInfo(
            job_id=data["job_id"],
            operation=data["operation"],
            status=data["status"],
            progress=data["progress"],
            progress_message=data["progress_message"],
            created_at=data["created_at"],
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
            error=data.get("error"),
        )

    # -- public API -------------------------------------------------------

    def create_job(
        self,
        job_id: str,
        operation: JobOperation,
        request_data: dict | None = None,
        accept_header: str | None = None,
    ) -> JobInfo:
        now = self._now()
        record: dict = {
            "job_id": job_id,
            "operation": operation,
            "status": JobStatus.PENDING,
            "progress": 0,
            "progress_message": "",
            "created_at": now,
            "started_at": None,
            "completed_at": None,
            "error": None,
            "request_data": request_data,
            "accept_header": accept_header,
            "result": None,
            "progress_events": [],
        }
        with self._lock:
            self._jobs[job_id] = record
        return self._to_job_info(record)

    def get_job(self, job_id: str) -> JobInfo | None:
        with self._lock:
            data = self._jobs.get(job_id)
        if data is None:
            return None
        return self._to_job_info(data)

    def update_job_status(
        self,
        job_id: str,
        status: JobStatus,
        error: str | None = None,
    ) -> None:
        now = self._now()
        with self._lock:
            data = self._jobs.get(job_id)
            if data is None:
                return
            data["status"] = status
            if error is not None:
                data["error"] = error
            if status == JobStatus.RUNNING and data.get("started_at") is None:
                data["started_at"] = now
            if status in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED):
                data["completed_at"] = now

    def update_job_progress(
        self,
        job_id: str,
        progress: int,
        message: str,
    ) -> None:
        now = self._now()
        with self._lock:
            data = self._jobs.get(job_id)
            if data is None:
                return
            data["progress"] = progress
            data["progress_message"] = message
            data["progress_events"].append(
                {"timestamp": now, "progress": progress, "message": message}
            )

    def set_job_result(self, job_id: str, result: dict) -> None:
        with self._lock:
            data = self._jobs.get(job_id)
            if data is not None:
                data["result"] = result

    def get_job_result(self, job_id: str) -> dict | None:
        with self._lock:
            data = self._jobs.get(job_id)
        if data is None:
            return None
        return data.get("result")

    def get_job_request_data(self, job_id: str) -> dict | None:
        with self._lock:
            data = self._jobs.get(job_id)
        if data is None:
            return None
        return data.get("request_data")

    def get_job_accept_header(self, job_id: str) -> str | None:
        with self._lock:
            data = self._jobs.get(job_id)
        if data is None:
            return None
        return data.get("accept_header")

    def list_jobs(
        self,
        status: JobStatus | None = None,
        operation: JobOperation | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[JobInfo], int]:
        with self._lock:
            candidates = list(self._jobs.values())
        if status is not None:
            candidates = [j for j in candidates if j["status"] == status]
        if operation is not None:
            candidates = [j for j in candidates if j["operation"] == operation]
        candidates.sort(key=lambda j: j["created_at"], reverse=True)
        total = len(candidates)
        page = candidates[offset : offset + limit]
        return [self._to_job_info(j) for j in page], total

    def delete_job(self, job_id: str) -> bool:
        with self._lock:
            return self._jobs.pop(job_id, None) is not None

    def cleanup_old_jobs(self, older_than_hours: int) -> int:
        cutoff = self._now() - timedelta(hours=older_than_hours)
        removed = 0
        with self._lock:
            to_remove = [
                jid
                for jid, data in self._jobs.items()
                if data["created_at"] < cutoff
                and data["status"] in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED)
            ]
            for jid in to_remove:
                del self._jobs[jid]
                removed += 1
        return removed

    def get_progress_events(self, job_id: str) -> list[ProgressEvent]:
        with self._lock:
            data = self._jobs.get(job_id)
        if data is None:
            return []
        return [
            ProgressEvent(
                timestamp=evt["timestamp"],
                progress=evt["progress"],
                message=evt["message"],
            )
            for evt in data.get("progress_events", [])
        ]


def create_job_storage(settings: JobsSettings) -> JobStorage:
    """Factory: return the appropriate storage backend."""
    if settings.storage_backend == "redis":
        from jentic.apitools.jobs.redis_storage import RedisJobStorage

        return RedisJobStorage(redis_url=settings.redis_url)
    return MemoryJobStorage()
