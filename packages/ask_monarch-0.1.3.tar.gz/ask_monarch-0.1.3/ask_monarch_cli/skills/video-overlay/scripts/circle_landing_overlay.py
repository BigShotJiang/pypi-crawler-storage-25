#!/usr/bin/env python3
"""YOLO-track side-by-side Heptanamide videos by whole assay circle."""

from __future__ import annotations

import argparse
import csv
import json
from dataclasses import dataclass, field
from itertools import zip_longest
from pathlib import Path

import cv2
import numpy as np
from ultralytics import YOLO


PANEL_WIDTH = 380


@dataclass
class TrackStats:
    track_id: int
    individual_id: str
    circle_label: str
    condition: str
    first_frame: int | None = None
    last_frame: int | None = None
    circle_landing_time_s: float = 0.0
    circle_landing_frames: int = 0
    total_detections: int = 0
    landing_detections: int = 0
    confidences: list[float] = field(default_factory=list)


@dataclass
class StreamState:
    condition: str
    circle_label: str
    prefix: str
    zone: dict
    stats: dict[int, TrackStats] = field(default_factory=dict)
    local_ids: dict[int, str] = field(default_factory=dict)
    total_circle_landing_time_s: float = 0.0
    current_landing_count: int = 0


def video_fps(path: Path) -> float:
    cap = cv2.VideoCapture(str(path))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
    cap.release()
    return fps if fps > 0 else 30.0


def on_circle(x: float, y: float, zone: dict, margin_px: float) -> bool:
    cx = float(zone["cx"])
    cy = float(zone["cy"])
    outer = float(zone["outer_radius"]) + margin_px
    return ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5 <= outer


def draw_circle_zone(frame, zone: dict, label: str) -> None:
    cx = int(round(float(zone["cx"])))
    cy = int(round(float(zone["cy"])))
    outer = int(round(float(zone["outer_radius"])))
    cv2.circle(frame, (cx, cy), outer, (60, 60, 255), 2)
    cv2.putText(
        frame,
        label,
        (max(8, cx - outer), max(24, cy - outer - 12)),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.58,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )


def label_box(frame, x1: float, y1: float, x2: float, y2: float, text: str, color: tuple[int, int, int]) -> None:
    cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), color, 1)
    text_origin = (int(x1), max(14, int(y1) - 4))
    (text_w, text_h), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.38, 1)
    cv2.rectangle(
        frame,
        (text_origin[0] - 1, text_origin[1] - text_h - 3),
        (text_origin[0] + text_w + 2, text_origin[1] + 2),
        (0, 0, 0),
        -1,
    )
    cv2.putText(frame, text, text_origin, cv2.FONT_HERSHEY_SIMPLEX, 0.38, color, 1, cv2.LINE_AA)


def draw_total_banner(frame, state: StreamState) -> None:
    text = f"{state.circle_label}: {state.total_circle_landing_time_s:.1f}s"
    subtext = f"landed now: {state.current_landing_count}"
    cv2.rectangle(frame, (8, 8), (300, 60), (0, 0, 0), -1)
    cv2.putText(frame, text, (18, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(frame, subtext, (18, 52), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (220, 220, 220), 1, cv2.LINE_AA)


def process_result(result, state: StreamState, frame_idx: int, dt: float, margin_px: float, det_writer):
    frame = result.orig_img.copy()
    draw_circle_zone(frame, state.zone, state.circle_label)
    visible_rows = []
    state.current_landing_count = 0
    boxes = result.boxes
    if boxes is None or boxes.id is None:
        draw_total_banner(frame, state)
        return frame, visible_rows

    xyxy = boxes.xyxy.cpu().numpy()
    ids = boxes.id.cpu().numpy().astype(int)
    confs = boxes.conf.cpu().numpy()
    for bbox, track_id, conf in zip(xyxy, ids, confs):
        if track_id not in state.local_ids:
            state.local_ids[track_id] = f"{state.prefix}{len(state.local_ids) + 1:03d}"
        individual_id = state.local_ids[track_id]
        x1, y1, x2, y2 = [float(v) for v in bbox]
        x = (x1 + x2) / 2.0
        y = (y1 + y2) / 2.0
        is_landing = on_circle(x, y, state.zone, margin_px)
        track = state.stats.setdefault(
            track_id,
            TrackStats(
                track_id=track_id,
                individual_id=individual_id,
                circle_label=state.circle_label,
                condition=state.condition,
            ),
        )
        if track.first_frame is None:
            track.first_frame = frame_idx
        track.last_frame = frame_idx
        track.total_detections += 1
        track.confidences.append(float(conf))
        if is_landing:
            track.circle_landing_time_s += dt
            track.circle_landing_frames += 1
            track.landing_detections += 1
            state.total_circle_landing_time_s += dt
            state.current_landing_count += 1

        det_writer.writerow(
            {
                "condition": state.condition,
                "circle_label": state.circle_label,
                "frame": frame_idx,
                "time_s": round(frame_idx * dt, 4),
                "individual_id": individual_id,
                "track_id": track_id,
                "confidence": round(float(conf), 6),
                "x_center": round(x, 3),
                "y_center": round(y, 3),
                "bbox_x1": round(x1, 3),
                "bbox_y1": round(y1, 3),
                "bbox_x2": round(x2, 3),
                "bbox_y2": round(y2, 3),
                "on_circle": int(is_landing),
                "circle_landing_time_s_so_far": round(track.circle_landing_time_s, 4),
            }
        )

        color = (0, 220, 80) if is_landing else (180, 180, 180)
        status = "ON" if is_landing else "--"
        label_box(frame, x1, y1, x2, y2, f"{individual_id} {status} {track.circle_landing_time_s:.1f}s", color)
        visible_rows.append(
            {
                "circle": state.circle_label,
                "individual_id": individual_id,
                "landing": is_landing,
                "time": track.circle_landing_time_s,
                "color": color,
            }
        )

    draw_total_banner(frame, state)
    return frame, visible_rows


def draw_side_panel(left_state: StreamState, right_state: StreamState, left_rows: list[dict], right_rows: list[dict], height: int, time_s: float):
    panel = np.zeros((height, PANEL_WIDTH, 3), dtype=np.uint8)
    panel[:, :] = (12, 12, 12)
    cv2.putText(panel, f"t={time_s:.1f}s", (14, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (240, 240, 240), 1, cv2.LINE_AA)
    cv2.putText(panel, "cumulative mosquito-seconds", (14, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.43, (210, 210, 210), 1, cv2.LINE_AA)
    cv2.putText(panel, f"LEFT  {left_state.total_circle_landing_time_s:7.1f}s", (14, 86), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (0, 220, 80), 2, cv2.LINE_AA)
    cv2.putText(panel, f"RIGHT {right_state.total_circle_landing_time_s:7.1f}s", (14, 118), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (0, 180, 255), 2, cv2.LINE_AA)
    cv2.putText(panel, f"now: L {left_state.current_landing_count} / R {right_state.current_landing_count}", (14, 146), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (220, 220, 220), 1, cv2.LINE_AA)

    y = 184
    for title, rows in [("LEFT CIRCLE", left_rows), ("RIGHT CIRCLE", right_rows)]:
        cv2.putText(panel, title, (14, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (245, 245, 245), 1, cv2.LINE_AA)
        y += 24
        cv2.putText(panel, "ID    on?   time", (14, y), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (220, 220, 220), 1, cv2.LINE_AA)
        y += 12
        cv2.line(panel, (14, y), (PANEL_WIDTH - 14, y), (70, 70, 70), 1)
        y += 22
        for row in sorted(rows, key=lambda r: r["individual_id"])[:11]:
            on_text = "yes" if row["landing"] else "no "
            cv2.putText(
                panel,
                f"{row['individual_id']}  {on_text}  {row['time']:5.1f}s",
                (14, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.43,
                row["color"],
                1,
                cv2.LINE_AA,
            )
            y += 20
        if len(rows) > 11:
            cv2.putText(panel, f"+{len(rows) - 11} more visible", (14, y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (190, 190, 190), 1, cv2.LINE_AA)
            y += 20
        y += 28
    return panel


def write_track_csv(path: Path, states: list[StreamState], dt: float) -> None:
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "condition",
                "circle_label",
                "individual_id",
                "track_id",
                "circle_landing_time_s",
                "circle_landing_frames",
                "landing_detections",
                "total_detections",
                "first_time_s",
                "last_time_s",
                "mean_confidence",
            ],
        )
        writer.writeheader()
        for state in states:
            for track_id in sorted(state.stats, key=lambda tid: (state.stats[tid].first_frame or 0, tid)):
                track = state.stats[track_id]
                if track.landing_detections == 0:
                    continue
                writer.writerow(
                    {
                        "condition": track.condition,
                        "circle_label": track.circle_label,
                        "individual_id": track.individual_id,
                        "track_id": track.track_id,
                        "circle_landing_time_s": round(track.circle_landing_time_s, 4),
                        "circle_landing_frames": track.circle_landing_frames,
                        "landing_detections": track.landing_detections,
                        "total_detections": track.total_detections,
                        "first_time_s": round((track.first_frame or 0) * dt, 4),
                        "last_time_s": round((track.last_frame or 0) * dt, 4),
                        "mean_confidence": round(float(np.mean(track.confidences)), 6) if track.confidences else "",
                    }
                )


def summarize(states: list[StreamState], fps: float) -> list[dict]:
    summaries = []
    for state in states:
        landing_tracks = [t for t in state.stats.values() if t.landing_detections > 0]
        times = np.array([t.circle_landing_time_s for t in landing_tracks], dtype=float)
        summaries.append(
            {
                "condition": state.condition,
                "circle_label": state.circle_label,
                "fps": fps,
                "landing_definition": "bbox center inside the assay circle outer boundary",
                "all_track_count": len(state.stats),
                "landing_track_count": len(landing_tracks),
                "total_circle_landing_time_s": float(times.sum()) if len(times) else 0.0,
                "total_circle_landing_time_s_from_frame_ticks": state.total_circle_landing_time_s,
                "mean_circle_landing_time_per_landing_track_s": float(times.mean()) if len(times) else 0.0,
                "sd_circle_landing_time_per_landing_track_s": float(times.std(ddof=1)) if len(times) > 1 else 0.0,
            }
        )
    return summaries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--left-video", type=Path, required=True)
    parser.add_argument("--right-video", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--conf", type=float, default=0.10)
    parser.add_argument("--iou", type=float, default=0.5)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--tracker", default="bytetrack.yaml")
    parser.add_argument("--device", default=None)
    parser.add_argument("--circle-margin-px", type=float, default=5.0)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    fps = video_fps(args.left_video)
    dt = 1.0 / fps
    left_zone = {"cx": 317, "cy": 321, "outer_radius": 143}
    right_zone = {"cx": 318, "cy": 321, "outer_radius": 148}
    left_state = StreamState("control", "LEFT CIRCLE", "L", left_zone)
    right_state = StreamState("heptanamide_contact", "RIGHT CIRCLE", "R", right_zone)

    left_model = YOLO(str(args.model))
    right_model = YOLO(str(args.model))
    left_results = left_model.track(
        source=str(args.left_video),
        stream=True,
        persist=True,
        conf=args.conf,
        iou=args.iou,
        imgsz=args.imgsz,
        tracker=args.tracker,
        device=args.device,
        verbose=False,
    )
    right_results = right_model.track(
        source=str(args.right_video),
        stream=True,
        persist=True,
        conf=args.conf,
        iou=args.iou,
        imgsz=args.imgsz,
        tracker=args.tracker,
        device=args.device,
        verbose=False,
    )

    overlay_path = args.out_dir / "heptanamide_left_right_circle_landing_overlay.mp4"
    detections_path = args.out_dir / "heptanamide_left_right_circle_landing_detections.csv"
    tracks_path = args.out_dir / "heptanamide_left_right_circle_landing_by_individual.csv"
    summary_path = args.out_dir / "heptanamide_left_right_circle_landing_summary.json"

    writer = cv2.VideoWriter(str(overlay_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (640 * 2 + PANEL_WIDTH, 640))
    with detections_path.open("w", newline="") as det_f:
        det_writer = csv.DictWriter(
            det_f,
            fieldnames=[
                "condition",
                "circle_label",
                "frame",
                "time_s",
                "individual_id",
                "track_id",
                "confidence",
                "x_center",
                "y_center",
                "bbox_x1",
                "bbox_y1",
                "bbox_x2",
                "bbox_y2",
                "on_circle",
                "circle_landing_time_s_so_far",
            ],
        )
        det_writer.writeheader()
        for frame_idx, (left_result, right_result) in enumerate(zip_longest(left_results, right_results)):
            if left_result is None or right_result is None:
                break
            left_frame, left_rows = process_result(left_result, left_state, frame_idx, dt, args.circle_margin_px, det_writer)
            right_frame, right_rows = process_result(right_result, right_state, frame_idx, dt, args.circle_margin_px, det_writer)
            left_frame = cv2.resize(left_frame, (640, 640))
            right_frame = cv2.resize(right_frame, (640, 640))
            panel = draw_side_panel(left_state, right_state, left_rows, right_rows, 640, frame_idx * dt)
            canvas = np.hstack([left_frame, right_frame, panel])
            writer.write(canvas)
    writer.release()

    write_track_csv(tracks_path, [left_state, right_state], dt)
    summaries = summarize([left_state, right_state], fps)
    summary_path.write_text(json.dumps(summaries, indent=2) + "\n")
    print(json.dumps({"overlay": str(overlay_path), "tracks_csv": str(tracks_path), "summary": summaries}, indent=2))


if __name__ == "__main__":
    main()
