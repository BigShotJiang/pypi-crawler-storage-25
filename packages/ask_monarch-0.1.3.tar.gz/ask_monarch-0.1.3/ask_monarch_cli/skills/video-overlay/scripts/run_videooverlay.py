#!/usr/bin/env python3
"""Run the default Monarch side-by-side assay video overlay workflow."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path


def run(cmd: list[str], cwd: Path) -> None:
    print("+", " ".join(cmd))
    subprocess.run(cmd, cwd=cwd, check=True)


def normalize(input_path: Path, output_path: Path, cwd: Path) -> None:
    run(
        [
            "ffmpeg",
            "-y",
            "-v",
            "error",
            "-i",
            str(input_path),
            "-vf",
            "fps=10,scale=640:640:force_original_aspect_ratio=decrease,pad=640:640:(ow-iw)/2:(oh-ih)/2,format=yuv420p",
            "-an",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "23",
            "-movflags",
            "+faststart",
            str(output_path),
        ],
        cwd,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, default=Path("/Users/josh/projects/ask-monarch"))
    parser.add_argument("--left-video", type=Path, required=True)
    parser.add_argument("--right-video", type=Path, required=True)
    parser.add_argument("--model", type=Path, default=Path("artifacts/yolo/models/yolo26_mosquito_contact _repel_model_version_3_data.pt"))
    parser.add_argument("--out-dir", type=Path, default=Path("output/videooverlay-run"))
    parser.add_argument("--download-dir", type=Path, default=Path.home() / "Downloads" / "videooverlay")
    parser.add_argument("--conf", type=float, default=0.10)
    parser.add_argument("--device", default="mps")
    parser.add_argument("--skip-normalize", action="store_true")
    args = parser.parse_args()

    repo = args.repo.expanduser().resolve()
    skill_dir = Path(__file__).resolve().parents[1]
    renderer = skill_dir / "scripts" / "circle_landing_overlay.py"
    python = repo / ".venv-yolo" / "bin" / "python"
    if not python.exists():
        raise SystemExit(f"Missing YOLO Python env: {python}")

    out_dir = args.out_dir if args.out_dir.is_absolute() else repo / args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    normalized_dir = out_dir / "normalized"
    normalized_dir.mkdir(parents=True, exist_ok=True)

    left_video = args.left_video.expanduser()
    right_video = args.right_video.expanduser()
    if not left_video.is_absolute():
        left_video = repo / left_video
    if not right_video.is_absolute():
        right_video = repo / right_video

    if args.skip_normalize:
        left_norm = left_video
        right_norm = right_video
    else:
        left_norm = normalized_dir / "left_640_10fps.mp4"
        right_norm = normalized_dir / "right_640_10fps.mp4"
        normalize(left_video, left_norm, repo)
        normalize(right_video, right_norm, repo)

    model = args.model if args.model.is_absolute() else repo / args.model
    run(
        [
            str(python),
            str(renderer),
            "--model",
            str(model),
            "--left-video",
            str(left_norm),
            "--right-video",
            str(right_norm),
            "--out-dir",
            str(out_dir),
            "--conf",
            str(args.conf),
            "--device",
            args.device,
        ],
        repo,
    )

    full_overlay = out_dir / "heptanamide_left_right_circle_landing_overlay.mp4"
    clean_overlay = out_dir / "clean-side-by-side.mp4"
    sanity = out_dir / "sanity-120s.png"
    run(
        [
            "ffmpeg",
            "-y",
            "-v",
            "error",
            "-i",
            str(full_overlay),
            "-vf",
            "crop=1280:640:0:0,format=yuv420p",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "20",
            "-an",
            str(clean_overlay),
        ],
        repo,
    )
    run(
        [
            "ffmpeg",
            "-y",
            "-v",
            "error",
            "-ss",
            "00:02:00",
            "-i",
            str(clean_overlay),
            "-frames:v",
            "1",
            str(sanity),
        ],
        repo,
    )

    args.download_dir.mkdir(parents=True, exist_ok=True)
    for path in out_dir.glob("*"):
        if path.is_file():
            shutil.copy2(path, args.download_dir / path.name)

    print(
        json.dumps(
            {
                "out_dir": str(out_dir),
                "download_dir": str(args.download_dir),
                "clean_overlay": str(clean_overlay),
                "full_overlay": str(full_overlay),
                "sanity_frame": str(sanity),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
