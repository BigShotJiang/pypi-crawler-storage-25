---
name: video-overlay
description: Render Monarch assay video overlays from vision-model detections. Use when the user invokes `$video-overlay` or `/video-overlay`, asks to overlay mosquito or fly assay detections on video, compare two assay videos side by side, show cumulative landing/contact time, count mosquito-seconds, or build OpenCV/Remotion overlays from Monarch YOLO/ByteTrack tracks.
---

# Video Overlay

Use this skill for Monarch assay videos where the user wants a visual overlay,
not just a numeric answer.

Default to the **OpenCV renderer** for scientific audit work. Use Remotion only
when the user explicitly wants a polished presentation render or React-authored
video.

## Core Contract

- Use a Monarch-trained YOLO model for detections.
- Use ByteTrack to keep per-individual IDs across frames.
- Be explicit about the measurement definition before rendering.
- For side-by-side landing assays, "left" and "right" usually mean the whole
  left assay circle and the whole right assay circle, not halves of one ring.
- Report both totals and standard deviations when summarizing per-individual
  dwell times.
- Create visual proof: at least one overlay video, one CSV, and one sanity
  frame.

## Preferred Workflow

1. Locate the repo and model environment:

```bash
cd /Users/josh/projects/ask-monarch
test -x .venv-yolo/bin/python
```

2. Confirm the model weights. The proven mosquito contact/repel model is:

```text
artifacts/yolo/models/yolo26_mosquito_contact _repel_model_version_3_data.pt
```

If missing, use the repo-local YOLO helper or Ask Monarch source evidence to
download the correct model. Do not silently switch to a generic YOLO model.

3. Normalize input videos to 640x640 at 10 fps before comparing:

```bash
ffmpeg -y -v error -i INPUT.mov \
  -vf "fps=10,scale=640:640:force_original_aspect_ratio=decrease,pad=640:640:(ow-iw)/2:(oh-ih)/2,format=yuv420p" \
  -an -c:v libx264 -preset veryfast -crf 23 -movflags +faststart OUTPUT_640_10fps.mp4
```

4. Run the bundled whole-circle side-by-side overlay renderer:

```bash
.venv-yolo/bin/python "$CODEX_HOME/skills/video-overlay/scripts/circle_landing_overlay.py" \
  --model "artifacts/yolo/models/yolo26_mosquito_contact _repel_model_version_3_data.pt" \
  --left-video LEFT_640_10fps.mp4 \
  --right-video RIGHT_640_10fps.mp4 \
  --out-dir output/videooverlay-run \
  --conf 0.10 \
  --device mps
```

Use `--device cpu` if Apple MPS is unavailable. Check availability with:

```bash
.venv-yolo/bin/python - <<'PY'
import torch
print(torch.backends.mps.is_available())
PY
```

5. Produce the clean side-by-side view by cropping off the audit panel:

```bash
ffmpeg -y -v error \
  -i output/videooverlay-run/heptanamide_left_right_circle_landing_overlay.mp4 \
  -vf "crop=1280:640:0:0,format=yuv420p" \
  -c:v libx264 -preset veryfast -crf 20 -an \
  output/videooverlay-run/clean-side-by-side.mp4
```

6. Extract a sanity frame:

```bash
ffmpeg -y -v error -ss 00:02:00 \
  -i output/videooverlay-run/clean-side-by-side.mp4 \
  -frames:v 1 output/videooverlay-run/sanity-120s.png
```

7. Copy deliverables to Downloads:

```bash
mkdir -p "$HOME/Downloads/videooverlay"
cp -f output/videooverlay-run/* "$HOME/Downloads/videooverlay/"
open "$HOME/Downloads/videooverlay"
```

## Outputs

The bundled renderer writes:

- `heptanamide_left_right_circle_landing_overlay.mp4`: full audit render with
  side panel.
- `heptanamide_left_right_circle_landing_detections.csv`: frame-level
  detections and cumulative time.
- `heptanamide_left_right_circle_landing_by_individual.csv`: per-individual
  landing time rows.
- `heptanamide_left_right_circle_landing_summary.json`: totals, means, and SD.

For a clean user-facing comparison, prefer the cropped `clean-side-by-side.mp4`.

## Renderer Choice

- **OpenCV**: use by default. It is fastest, closer to source colors, and best
  for scientific audit overlays.
- **Remotion**: use for polished presentation videos, typography, title cards,
  and React-authored motion. Check for browser color shifts before recommending
  it for scientific review.
- **ffmpeg only**: use for layout/crop/transcode operations, not for detection
  or tracking logic.

## Common Pitfalls

- Do not confuse left/right halves of one circle with left/right assay videos.
- Do not claim hand-labeled accuracy. Say "model-tracked" unless manual review
  was performed.
- Do not count only unique mosquitoes if the user asks for seconds. The assay
  total should be mosquito-seconds: at 10 fps, 3 landed mosquitoes in one frame
  adds 0.3 seconds.
- Do not present aggregate totals without the CSV and overlay proof.
