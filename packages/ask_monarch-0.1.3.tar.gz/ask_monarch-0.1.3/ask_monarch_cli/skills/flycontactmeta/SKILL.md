---
name: flycontactmeta
description: Create and optionally upload Monarch fly contact/no-contact metadata spreadsheets. Use when the user invokes `/flycontactmeta`, asks for fly contact metadata, or asks to create metadata for checked fly videos in the Monarch `contact_repel_videos/flies` bucket folder.
---

# Fly Contact Metadata

Use this skill for Monarch fly contact, non-contact, and control video metadata
sheets.

## Contract

- `/flycontactmeta` means: create one local metadata workbook for the target fly
  contact/no-contact videos, and upload it to the fly contact/no-contact bucket
  folder only when the user asks for upload.
- Destination folder, when uploading:
  `gs://monarch-videos-new/contact_repel_videos/flies/`
- Preserve the fly metadata shape from
  `gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx`,
  sheet `trials`.
- Always make a local copy in `~/Downloads`.
- Never edit the source template workbook unless the user explicitly asks.

## Required Defaults

For every generated video row, set:

- `solvent`: `DPG`
- `dilution`: `0.01`

Do this for control, contact, and non-contact rows unless the user explicitly
gives different values.

## Field Policy

- Fill filename-derived fields from names such as
  `IMG_0113_NonContact_1O3OL.mov`.
- Fill `date` from the verified source row when there is one. If no exact
  source row exists, use the live GCS object date for the batch.
- Leave lab-only fields blank unless a verified metadata row or the user supplies
  the value. Lab-only fields include `time started`, `temp`, `rh`, `age`,
  `state`, `class`, `tube`, `slot`, `n_flies`, `left_condition`,
  `right_condition`, `treatment_position`, `inchikey`, and `usable_data`.
- Do not infer temperature or humidity from video metadata.
- Add a `Source_Provenance` sheet that records the checked GCS objects, the
  template source, and which values were defaults versus verified source values.

## Helper

Use the bundled helper for repeatability:

```bash
python3 "$CODEX_HOME/skills/flycontactmeta/scripts/create_fly_contact_meta.py" \
  --filenames IMG_0112_Control_1O3OL.mov IMG_0113_NonContact_1O3OL.mov \
  --upload
```

Helpful options:

- `--output /Users/josh/Downloads/name.xlsx`
- `--destination gs://monarch-videos-new/contact_repel_videos/flies/`
- `--template /tmp/ask-monarch-meta/repellency_screen_metadata_sheet.xlsx`
- `--no-upload`

## Verification

After creating the file:

1. Read it back with `openpyxl`.
2. Confirm there are no cells whose string value starts with `#`.
3. Confirm every generated data row has `solvent = DPG` and `dilution = 0.01`.
4. If uploading, run `gcloud storage ls -l` on the final object.

