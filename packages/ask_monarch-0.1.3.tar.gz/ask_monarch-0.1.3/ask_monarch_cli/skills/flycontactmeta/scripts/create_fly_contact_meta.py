#!/usr/bin/env python3
"""Create Monarch fly contact/no-contact metadata workbooks."""

from __future__ import annotations

import argparse
import re
import subprocess
from copy import copy
from datetime import datetime, timezone
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


DEFAULT_DESTINATION = "gs://monarch-videos-new/contact_repel_videos/flies/"
DEFAULT_TEMPLATE_LOCATOR = "gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx"
DEFAULT_TEMPLATE = Path("/tmp/ask-monarch-meta/repellency_screen_metadata_sheet.xlsx")


def run(args: list[str]) -> str:
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT)


def ensure_template(path: Path, locator: str) -> Path:
    if path.exists():
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    run(["gcloud", "storage", "cp", locator, str(path)])
    return path


def gcs_object_rows(destination: str, filenames: list[str]) -> dict[str, dict[str, str]]:
    rows: dict[str, dict[str, str]] = {}
    for filename in filenames:
        uri = destination.rstrip("/") + "/" + filename
        out = run(["gcloud", "storage", "ls", "-l", uri])
        line = next((line for line in out.splitlines() if uri in line), "")
        if not line:
            raise RuntimeError(f"Could not verify GCS object: {uri}")
        parts = line.split()
        rows[filename] = {"size": parts[0], "updated": parts[1], "uri": uri}
    return rows


def excel_date_from_gcs(updated: str) -> int | None:
    if not updated:
        return None
    dt = datetime.fromisoformat(updated.replace("Z", "+00:00")).astimezone(timezone.utc)
    return int(f"{dt.month}{dt.day:02d}{dt.year}")


def copy_style(src, dst) -> None:
    if not src.has_style:
        return
    dst.font = copy(src.font)
    dst.fill = copy(src.fill)
    dst.border = copy(src.border)
    dst.alignment = copy(src.alignment)
    dst.number_format = src.number_format
    dst.protection = copy(src.protection)


def parse_filename(filename: str) -> dict[str, str | None]:
    match = re.match(r"IMG_\d+_(Control|NonContact|Contact)_(.+)\.mov$", filename, flags=re.I)
    mode = match.group(1) if match else ""
    compound = match.group(2) if match else ""
    treatment = "control" if mode == "Control" else compound
    return {
        "mode": mode,
        "compound": compound,
        "treatment": treatment,
        "context": "none",
        "can_feed": "N",
        "dilution": 0.01,
        "solvent": "DPG",
    }


def create_workbook(
    filenames: list[str],
    output: Path,
    destination: str,
    template: Path,
    template_locator: str,
) -> Path:
    template = ensure_template(template, template_locator)
    gcs_rows = gcs_object_rows(destination, filenames)

    src_wb = load_workbook(template)
    src_ws = src_wb["trials"]
    headers = [src_ws.cell(1, col).value for col in range(1, src_ws.max_column + 1)]

    wb = Workbook()
    ws = wb.active
    ws.title = "Metadata"

    for col, header in enumerate(headers, start=1):
        letter = get_column_letter(col)
        ws.column_dimensions[letter].width = src_ws.column_dimensions[letter].width
        cell = ws.cell(1, col, header)
        copy_style(src_ws.cell(1, col), cell)
        if not cell.has_style:
            cell.font = Font(name="Arial", bold=True)
            cell.fill = PatternFill("solid", fgColor="D9EAF7")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for row_idx, filename in enumerate(filenames, start=2):
        parsed = parse_filename(filename)
        object_row = gcs_rows[filename]
        values = {
            "date": excel_date_from_gcs(object_row["updated"]),
            "filename": filename,
            "time started": None,
            "temp": None,
            "rh": None,
            "age": None,
            "state": None,
            "class": None,
            "tube": None,
            "slot": None,
            "n_flies": None,
            "context": parsed["context"],
            "can_feed": parsed["can_feed"],
            "treatment": parsed["treatment"],
            "dilution": parsed["dilution"],
            "solvent": parsed["solvent"],
            "left_condition": None,
            "right_condition": None,
            "treatment_position": None,
            "inchikey": None,
            "usable_data": None,
        }
        for col, header in enumerate(headers, start=1):
            cell = ws.cell(row_idx, col, values.get(header))
            copy_style(src_ws.cell(2, col), cell)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(filenames) + 1}"
    ws.sheet_view.showGridLines = src_ws.sheet_view.showGridLines

    prov = wb.create_sheet("Source_Provenance")
    for idx, header in enumerate(["Field", "Value"], start=1):
        cell = prov.cell(1, idx, header)
        cell.font = Font(name="Arial", bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(horizontal="center")

    rows = [
        ("created_as", "fly contact/no-contact metadata workbook"),
        ("destination_folder", destination),
        ("source_template_locator", template_locator),
        ("source_template_sheet", "trials"),
        ("required_defaults", "solvent=DPG and dilution=0.01 for every generated video row"),
        (
            "field_policy",
            "Filename-derived fields are filled. Lab-only fields stay blank unless a verified source row or user value supplies them.",
        ),
    ]
    for filename in filenames:
        object_row = gcs_rows[filename]
        rows.append(
            (
                f"gcs_object_{filename}",
                f"{object_row['uri']} | size_bytes={object_row['size']} | updated={object_row['updated']}",
            )
        )

    thin = Side(style="thin", color="D9E2F3")
    for row_idx, (field, value) in enumerate(rows, start=2):
        for col, val in [(1, field), (2, value)]:
            cell = prov.cell(row_idx, col, val)
            cell.font = Font(name="Arial", size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for cell in prov[1]:
        cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    prov.column_dimensions["A"].width = 34
    prov.column_dimensions["B"].width = 130
    prov.freeze_panes = "A2"
    prov.auto_filter.ref = f"A1:B{prov.max_row}"

    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)
    return output


def verify(path: Path) -> None:
    wb = load_workbook(path, data_only=False)
    ws = wb["Metadata"]
    headers = [ws.cell(1, col).value for col in range(1, ws.max_column + 1)]
    solvent_col = headers.index("solvent") + 1
    dilution_col = headers.index("dilution") + 1
    errors = []
    for sheet in wb.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith("#"):
                    errors.append(f"{sheet.title}!{cell.coordinate}={cell.value}")
    bad_rows = []
    for row in range(2, ws.max_row + 1):
        if ws.cell(row, solvent_col).value != "DPG" or ws.cell(row, dilution_col).value != 0.01:
            bad_rows.append(row)
    if errors:
        raise RuntimeError("Excel error cells found: " + ", ".join(errors))
    if bad_rows:
        raise RuntimeError("Rows missing required DPG/0.01 defaults: " + ", ".join(map(str, bad_rows)))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--filenames", nargs="+", required=True)
    parser.add_argument("--output", default="/Users/josh/Downloads/fly_contact_metadata.xlsx")
    parser.add_argument("--destination", default=DEFAULT_DESTINATION)
    parser.add_argument("--template", default=str(DEFAULT_TEMPLATE))
    parser.add_argument("--template-locator", default=DEFAULT_TEMPLATE_LOCATOR)
    parser.add_argument("--upload", action="store_true")
    parser.add_argument("--no-upload", action="store_true")
    args = parser.parse_args()

    output = create_workbook(
        filenames=args.filenames,
        output=Path(args.output).expanduser(),
        destination=args.destination,
        template=Path(args.template).expanduser(),
        template_locator=args.template_locator,
    )
    verify(output)
    print(output)

    if args.upload and not args.no_upload:
        target = args.destination.rstrip("/") + "/" + output.name
        run(["gcloud", "storage", "cp", str(output), target])
        print(target)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
