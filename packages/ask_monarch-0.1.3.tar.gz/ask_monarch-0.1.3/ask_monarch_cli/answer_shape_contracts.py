"""Validate retrieved Ask Monarch rows against declared answer shapes."""

from __future__ import annotations

import json
import re
from typing import Any


VIDEO_EXTENSIONS = (".mov", ".mp4", ".m4v", ".avi", ".webm")
IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".tif", ".tiff")

CONTRACTED_ANSWER_SHAPES = frozenset(
    {
        "advisor_roster",
        "assay_runs_with_meeting_commentary",
        "assay_runs_with_media",
        "assay_inventory_count",
        "assay_best_result_environment_conditions",
        "assay_result_list",
        "assay_run_list",
        "assay_summary_file_explanation",
        "alphafold_confidence_score_list",
        "chemistry_artifact_list",
        "chemistry_ligand_compound_list",
        "chemistry_model_artifact_list",
        "chemistry_species_result_summary",
        "company_fact",
        "compound_inventory_all_names",
        "compound_property_lookup",
        "contact_noncontact_ranked_comparison",
        "cross_assay_run_inventory",
        "deck_summary",
        "dart_individual_assay_timepoint_ranking",
        "docking_results",
        "document_fact_summary",
        "experiment_run_list",
        "fly_assay_count",
        "inventory_item_lookup",
        "inventory_list",
        "individual_assay_timepoint_ranking",
        "media_evidence",
        "media_overlay_evidence",
        "meeting_list",
        "meeting_summary",
        "meeting_utterance_lookup",
        "metric_definition",
        "mixed_advisor_roster_plus_entity_mentions",
        "mixed_ai_evidence_summary",
        "mixed_assay_list_plus_media",
        "mixed_assay_list_plus_meeting_summary",
        "mixed_assay_media_plus_meeting_summary",
        "mixed_docking_plus_assay_results",
        "mixed_inventory_assay_presentation",
        "mixed_inventory_plus_assay_results",
        "mixed_inventory_plus_entity_mentions",
        "mixed_literature_plus_experiment_results",
        "mixed_meeting_reference_plus_media",
        "mixed_metric_value_plus_definition",
        "mixed_phytotoxicity_ranking_plus_comments",
        "mixed_ranking_plus_entity_mentions",
        "mixed_ranking_plus_media",
        "mixed_recent_tested_plus_ranking",
        "mixed_roster_plus_entity_mentions",
        "model_metadata",
        "named_person_profile",
        "people_relationship_roster",
        "presentation_lookup",
        "protein_structure_artifact_list",
        "protein_structure_species_list",
        "protein_structure_target_list",
        "public_web_lookup_requested",
        "ranked_compound_property_list",
        "ranked_compounds_with_inventory_status",
        "ranked_cross_assay_repellent_compounds",
        "ranked_contact_effect_compounds",
        "ranked_dart_compounds",
        "ranked_fly_repellent_compounds",
        "ranked_fly_repellency_compounds",
        "ranked_mosquito_dart_compounds",
        "ranked_noncontact_effect_compounds",
        "ranked_oviposition_compounds",
        "ranked_phytotoxicity_compounds",
        "ranked_phytotoxicity_compounds_with_assay_species_constraint",
        "ranked_repellent_compounds",
        "ranked_repellents_with_media",
        "ranked_repellents_with_milestone_mentions",
        "ranked_species_repellent_compounds",
        "rank_expectation_explanation",
        "recent_contact_no_contact_assays",
        "recent_media_by_mode",
        "recent_tested_compound_list",
        "roster_list",
        "script_method_evidence",
        "source_gap",
        "source_gap_document",
        "source_gap_media",
        "source_gap_private_mail",
        "source_gap_unmapped_source",
        "tested_compound_date_window",
        "tested_compound_list",
        "unknown",
        "upload_activity_list",
    }
)

SOURCE_GAP_SHAPES = frozenset(
    {
        "public_web_lookup_requested",
        "source_gap",
        "source_gap_document",
        "source_gap_media",
        "source_gap_private_mail",
        "source_gap_unmapped_source",
    }
)

RANKING_SHAPES = frozenset(
    {
        "mixed_ranking_plus_entity_mentions",
        "mixed_ranking_plus_media",
        "mixed_recent_tested_plus_ranking",
        "dart_individual_assay_timepoint_ranking",
        "individual_assay_timepoint_ranking",
        "ranked_compound_property_list",
        "ranked_compounds_with_inventory_status",
        "ranked_cross_assay_repellent_compounds",
        "ranked_contact_effect_compounds",
        "ranked_dart_compounds",
        "ranked_fly_repellent_compounds",
        "ranked_fly_repellency_compounds",
        "ranked_mosquito_dart_compounds",
        "ranked_noncontact_effect_compounds",
        "ranked_oviposition_compounds",
        "ranked_phytotoxicity_compounds",
        "ranked_phytotoxicity_compounds_with_assay_species_constraint",
        "ranked_repellent_compounds",
        "ranked_repellents_with_media",
        "ranked_repellents_with_milestone_mentions",
        "ranked_species_repellent_compounds",
    }
)

MEDIA_SHAPES = frozenset({"media_evidence", "media_overlay_evidence", "ranked_repellents_with_media", "recent_media_by_mode"})
PEOPLE_SHAPES = frozenset({"advisor_roster", "named_person_profile", "people_relationship_roster", "roster_list"})
MEETING_SHAPES = frozenset({"meeting_list", "meeting_summary", "meeting_utterance_lookup"})
ASSAY_SHAPES = frozenset({"assay_run_list", "experiment_run_list", "cross_assay_run_inventory"})
ASSAY_RESULT_SHAPES = frozenset({"assay_result_list"})
ASSAY_COUNT_SHAPES = frozenset({"assay_inventory_count"})
INVENTORY_SHAPES = frozenset({"compound_inventory_all_names", "compound_property_lookup", "inventory_item_lookup", "inventory_list"})
TESTED_COMPOUND_WINDOW_SHAPES = frozenset({"tested_compound_date_window"})
CONTACT_NONCONTACT_COMPARISON_SHAPES = frozenset({"contact_noncontact_ranked_comparison"})
ENVIRONMENT_CONDITION_SHAPES = frozenset({"assay_best_result_environment_conditions"})
FLY_ASSAY_COUNT_SHAPES = frozenset({"fly_assay_count"})
RANK_EXPECTATION_SHAPES = frozenset({"rank_expectation_explanation"})
SUMMARY_FILE_EXPLANATION_SHAPES = frozenset({"assay_summary_file_explanation"})
RECENT_CONTACT_NONCONTACT_SHAPES = frozenset({"recent_contact_no_contact_assays"})
SCRIPT_METHOD_SHAPES = frozenset({"script_method_evidence"})
CHEMISTRY_ANALYSIS_SHAPES = frozenset(
    {
        "alphafold_confidence_score_list",
        "chemistry_artifact_list",
        "chemistry_ligand_compound_list",
        "chemistry_model_artifact_list",
        "chemistry_species_result_summary",
        "protein_structure_artifact_list",
        "protein_structure_species_list",
        "protein_structure_target_list",
    }
)
ASSAY_METRIC_UNCERTAINTY_SHAPES = frozenset(
    {
        "contact_noncontact_ranked_comparison",
        "mixed_ranking_plus_entity_mentions",
        "mixed_ranking_plus_media",
        "mixed_recent_tested_plus_ranking",
        "ranked_cross_assay_repellent_compounds",
        "ranked_species_repellent_compounds",
        "ranked_fly_repellent_compounds",
        "ranked_fly_repellency_compounds",
        "ranked_dart_compounds",
        "ranked_mosquito_dart_compounds",
        "ranked_contact_effect_compounds",
        "ranked_noncontact_effect_compounds",
        "ranked_phytotoxicity_compounds",
        "ranked_phytotoxicity_compounds_with_assay_species_constraint",
        "ranked_repellent_compounds",
        "ranked_repellents_with_media",
        "ranked_repellents_with_milestone_mentions",
    }
)

PROVENANCE_KEYS = frozenset(
    {
        "provenance_grain",
        "source_actions",
        "source_name",
        "source_names",
        "source_id",
        "source_file",
        "locator",
        "example_locator",
        "example_provenance",
        "example_provenance_grain",
        "example_source_actions",
        "raw_path",
        "assay_locator",
        "raw_video_provenance_grain",
    }
)

CHEMISTRY_PROVENANCE_TERMS = (
    "monarch-chemistry-analysis",
    "protein_structure",
    "json_path",
    "csv_row",
    "gcs_object",
    "model_metadata",
    "alignment_metadata",
    "text_metadata",
)


def flatten_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if isinstance(payload.get("rows"), list):
        source = payload.get("source")
        for row in payload["rows"]:
            if isinstance(row, dict):
                item = dict(row)
                if source:
                    item.setdefault("_source", source)
                rows.append(item)
        return rows

    source_plan = payload.get("source_plan") if isinstance(payload.get("source_plan"), list) else []
    ordered_sources: list[str] = []
    for step in source_plan:
        if not isinstance(step, dict) or not step.get("source"):
            continue
        source = str(step["source"])
        ordered_sources.append(source)
        for adapter_key in ("planned_adapter", "adapter"):
            if step.get(adapter_key):
                ordered_sources.append(f"{source}:{step[adapter_key]}")
    if not ordered_sources:
        ordered_sources = [
            key
            for key, value in payload.items()
            if isinstance(value, dict) and isinstance(value.get("rows"), list)
        ]
    seen_sources: set[str] = set()
    for source in ordered_sources:
        if source in seen_sources:
            continue
        seen_sources.add(source)
        source_payload = payload.get(source)
        if not isinstance(source_payload, dict):
            continue
        for row in source_payload.get("rows", []):
            if isinstance(row, dict):
                item = dict(row)
                item.setdefault("_source", source)
                rows.append(item)
    return rows


def answer_shapes(payload: dict[str, Any]) -> list[str]:
    shapes: list[str] = []
    for key in ("requested_routing_decision", "routing_decision"):
        routing = payload.get(key)
        if isinstance(routing, dict):
            for field in ("answer_shape",):
                if routing.get(field):
                    shapes.append(str(routing[field]))
            for shape in routing.get("answer_shapes") or []:
                if shape:
                    shapes.append(str(shape))
    for value in payload.values():
        if not isinstance(value, dict):
            continue
        nested = value.get("routing_decision")
        if isinstance(nested, dict):
            for field in ("answer_shape",):
                if nested.get(field):
                    shapes.append(str(nested[field]))
            for shape in nested.get("answer_shapes") or []:
                if shape:
                    shapes.append(str(shape))

    unique: list[str] = []
    for shape in shapes:
        if shape not in unique:
            unique.append(shape)
    return unique


def primary_answer_shape(payload: dict[str, Any]) -> str | None:
    shapes = answer_shapes(payload)
    if not shapes:
        return None
    for shape in shapes:
        if shape.startswith("mixed_"):
            return shape
    return shapes[0]


def _row_text(row: dict[str, Any]) -> str:
    return json.dumps(row, ensure_ascii=False, sort_keys=True).lower()


def _present(value: Any) -> bool:
    return value not in (None, "", [], {})


def _has_any_key(row: dict[str, Any], keys: set[str] | frozenset[str]) -> bool:
    return any(_present(row.get(key)) for key in keys)


def _has_provenance(row: dict[str, Any]) -> bool:
    if any(_present(row.get(key)) for key in PROVENANCE_KEYS):
        return True
    provenance = row.get("provenance")
    return isinstance(provenance, dict) and bool(provenance)


def _has_any_provenance(rows: list[dict[str, Any]]) -> bool:
    return any(_has_provenance(row) for row in rows)


def _question_is_count(question: str) -> bool:
    q = question.lower()
    return any(term in q for term in ("how many", "count", "number of"))


def _question_requests_all_inventory_rows(question: str) -> bool:
    q = question.lower()
    return (
        not _question_is_count(question)
        and "inventory" in q
        and any(term in q for term in ("list all", "list", "show all", "what compounds", "which compounds"))
    )


def _is_inventory_item_row(row: dict[str, Any]) -> bool:
    if _has_any_key(
        row,
        {
            "compound_name",
            "compound",
            "chemical_name",
            "name",
            "name_value",
            "cas",
            "vendor",
            "catalog_number",
            "storage_location",
            "location",
        },
    ):
        return True
    return str(row.get("column_name") or "").strip().lower() in {
        "name",
        "cas",
        "vendor",
        "catalog number",
        "location/bin",
        "location",
        "quantity",
    }


def _has_inventory_identity(rows: list[dict[str, Any]]) -> bool:
    identity_keys = {"compound_name", "compound", "chemical_name", "name", "name_value"}
    return any(_has_any_key(row, identity_keys) for row in rows)


def _has_inventory_detail(rows: list[dict[str, Any]]) -> bool:
    detail_keys = {"cas", "vendor", "catalog_number", "storage_location", "location", "quantity", "row_number", "cell"}
    return any(_has_any_key(row, detail_keys) for row in rows)


def _requested_species(question: str) -> str | None:
    species = _requested_species_all(question)
    if species:
        return species[0]
    return None


def _requested_species_all(question: str) -> list[str]:
    q = question.lower()
    species: list[str] = []
    if any(term in q for term in ("fly", "flies", "swd", "drosophila")):
        species.append("flies")
    if "mosquito" in q or "mosquitoes" in q:
        species.append("mosquitoes")
    if any(term in q for term in ("moth", "moths", "diamond back", "diamondback")):
        species.append("moths")
    if "plant" in q or "plants" in q or "soybean" in q:
        species.append("plants")
    return species


def _row_matches_species(row: dict[str, Any], requested: str) -> bool:
    species = str(row.get("species") or "").lower()
    if not species:
        return True
    if requested == "flies":
        return any(term in species for term in ("flies", "fly", "drosophila", "swd"))
    if requested == "mosquitoes":
        return "mosquito" in species
    if requested == "moths":
        return "moth" in species
    if requested == "plants":
        return any(term in species for term in ("plant", "soybean"))
    return True


def _has_media_row(rows: list[dict[str, Any]]) -> bool:
    media_extensions = VIDEO_EXTENSIONS + IMAGE_EXTENSIONS
    for row in rows:
        text = _row_text(row)
        if str(row.get("kind") or row.get("media_kind") or "").lower() in {"video", "image", "media"}:
            return True
        if row.get("media_uri") or row.get("video_uri") or row.get("video") or row.get("uri") or row.get("locator"):
            if any(ext in text for ext in media_extensions):
                return True
        if any(ext in text for ext in media_extensions):
            return True
    return False


def _has_ranking_row(rows: list[dict[str, Any]]) -> bool:
    metric_keys = {
        "mean_avg_pi",
        "best_single_avg_pi",
        "composite_score",
        "damaged_fraction",
        "trt_pi_grand_mean",
        "chlorosis_fraction",
        "browning_fraction",
        "score",
        "rank",
        "avg_damaged_fraction",
        "effect_score",
        "metric_value",
    }
    return any(any(_present(row.get(key)) for key in metric_keys) for row in rows)


def _has_ranking_compound(row: dict[str, Any]) -> bool:
    return _has_any_key(
        row,
        {
            "treatment_label",
            "treatment_normalized",
            "treatment_name",
            "tested_compound",
            "compound_name",
            "compound",
            "chemical_name",
            "name_value",
        },
    )


def _has_complete_ranking_row(rows: list[dict[str, Any]]) -> bool:
    return any(_has_ranking_row([row]) and _has_ranking_compound(row) and _has_provenance(row) for row in rows)


def _has_cross_assay_repellent_metric(row: dict[str, Any]) -> bool:
    return _has_any_key(row, {"metric_name", "metric_basis"}) and _has_any_key(
        row,
        {
            "metric_value",
            "ranking_score",
            "mean_avg_pi",
            "composite_score",
            "adj_contact_pi_mean",
            "best_single_avg_pi",
        },
    )


def _has_standard_deviation(row: dict[str, Any]) -> bool:
    return _has_any_key(
        row,
        {
            "standard_deviation",
            "stddev",
            "std_dev",
            "std_contact_pi",
            "std_contact_pi__contact",
            "std_contact_pi__non_contact",
            "standard_deviation_status",
        },
    )


def _has_uncertainty_basis(row: dict[str, Any]) -> bool:
    return _has_any_key(
        row,
        {
            "standard_deviation_basis",
            "uncertainty_basis",
            "standard_error_basis",
            "replicate_count",
            "n_replicates",
            "evidence_rows",
            "scored_rows",
        },
    )


def _question_requests_metric_uncertainty(question: str) -> bool:
    q = question.lower()
    return any(
        term in q
        for term in (
            "standard deviation",
            "stddev",
            "std dev",
            "variance",
            "confidence interval",
            "confidence",
            "p-value",
            "p value",
            "statistical",
            "significance",
            "sem",
            "standard error",
            "replicate variability",
        )
    )


def _validate_metric_uncertainty(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    metric_rows = [
        row
        for row in rows
        if row.get("ranking_status") != "no_rankable_rows"
        and _has_ranking_row([row])
        and _has_ranking_compound(row)
    ]
    if not metric_rows:
        return []
    missing_standard_deviation = [row for row in metric_rows if not _has_standard_deviation(row)]
    if missing_standard_deviation:
        return [f"{shape} requires standard deviation for every assay metric row"]
    missing_basis = [row for row in metric_rows if not _has_uncertainty_basis(row)]
    if missing_basis:
        return [f"{shape} requires standard deviation basis for every assay metric row"]
    return []


def _validate_cross_assay_repellent_ranking(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not any(_has_any_key(row, {"assay_family", "assay_type"}) for row in rows):
        errors.append(f"{shape} requires assay family for broad repellent rankings")
    if not any(_has_cross_assay_repellent_metric(row) for row in rows):
        errors.append(f"{shape} requires metric basis for broad repellent rankings")
    if not any(
        _has_ranking_compound(row)
        and _has_any_key(row, {"assay_family", "assay_type"})
        and _has_cross_assay_repellent_metric(row)
        and _has_provenance(row)
        for row in rows
    ):
        errors.append(f"{shape} requires rows with compound identity, assay family, metric basis, and provenance")
    errors.extend(_validate_metric_uncertainty(shape, rows))
    return errors


def _has_assay_row(rows: list[dict[str, Any]]) -> bool:
    for row in rows:
        if row.get("assay_family") or row.get("assay_type") or row.get("assay_date"):
            return True
        text = _row_text(row)
        if "assay" in text or "avg_pi" in text or "preference index" in text:
            return True
    return False


def _has_complete_assay_row(rows: list[dict[str, Any]]) -> bool:
    for row in rows:
        if not _has_provenance(row):
            continue
        if not _has_any_key(row, {"assay_family", "assay_type"}) and "assay" not in _row_text(row):
            continue
        if not _has_any_key(row, {"assay_date", "assay_date_iso", "first_assay_date", "latest_assay_date", "date_code", "date", "event_date_iso", "updated"}):
            continue
        if not _has_any_key(row, {"species", "insect_class", "top_folder"}) and not any(
            term in _row_text(row) for term in ("mosquito", "flies", "fly", "drosophila", "moth", "beetle", "plant")
        ):
            continue
        return True
    return False


def _has_people_row(rows: list[dict[str, Any]]) -> bool:
    return any(row.get("name") and (row.get("role") or row.get("lane") or row.get("text")) for row in rows)


def _has_complete_people_row(rows: list[dict[str, Any]]) -> bool:
    return any(row.get("name") and (row.get("role") or row.get("lane") or row.get("text")) and _has_provenance(row) for row in rows)


def _has_meeting_row(rows: list[dict[str, Any]]) -> bool:
    return any(row.get("_source") == "teams_recaps" or "meeting" in _row_text(row) or "speaker" in _row_text(row) for row in rows)


def _validate_species_scope(question: str, rows: list[dict[str, Any]]) -> list[str]:
    requested = _requested_species_all(question)
    if not requested:
        return []
    bad_rows = [
        row
        for row in rows
        if row.get("species") and not any(_row_matches_species(row, species) for species in requested)
    ]
    if bad_rows:
        return [
            f"species scope requested {', '.join(requested)}, but returned {len(bad_rows)} row(s) outside that scope"
        ]
    return []


def _validate_inventory_family(shape: str, question: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if _question_is_count(question) and shape == "inventory_list":
        if not _has_any_provenance(rows):
            errors.append(f"{shape} requires provenance for inventory count rows")
        return errors
    if _question_requests_all_inventory_rows(question) and not any(_is_inventory_item_row(row) for row in rows):
        errors.append(f"{shape} requires compound item rows for list-all inventory questions, not a count/summary row")
    if not _has_inventory_identity(rows):
        errors.append(f"{shape} requires inventory rows with compound identity")
    if not _has_inventory_detail(rows):
        errors.append(f"{shape} requires inventory rows with row, cell, vendor, CAS, or storage detail")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires inventory provenance")
    return errors


def _validate_tested_compound_window(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not any(_has_any_key(row, {"tested_compound", "compound", "treatment_name", "treatment_label"}) for row in rows):
        errors.append(f"{shape} requires tested compound identity")
    if not any(_has_any_key(row, {"date_window", "first_evidence_date", "latest_evidence_date", "normalized_latest_evidence_date", "assay_date"}) for row in rows):
        errors.append(f"{shape} requires date-window evidence")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    return errors


def _validate_ranking_family(shape: str, rows: list[dict[str, Any]], question: str = "") -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if any(row.get("ranking_status") == "no_rankable_rows" for row in rows):
        if not any(_has_any_key(row, {"assay_rows_in_window", "scored_rows_in_window"}) for row in rows):
            errors.append(f"{shape} no-rankable result requires checked row counts")
        if not _has_any_provenance(rows):
            errors.append(f"{shape} no-rankable result requires provenance")
        return errors
    if not _has_ranking_row(rows):
        errors.append(f"{shape} requires metric ranking rows")
    if not any(_has_ranking_compound(row) for row in rows):
        errors.append(f"{shape} requires ranking rows with compound or treatment identity")
    if not _has_complete_ranking_row(rows):
        errors.append(f"{shape} requires ranking rows with metric, compound identity, and provenance")
    media_proof_without_uncertainty_request = shape in MEDIA_SHAPES and not _question_requests_metric_uncertainty(question)
    if shape in ASSAY_METRIC_UNCERTAINTY_SHAPES and not media_proof_without_uncertainty_request:
        errors.extend(_validate_metric_uncertainty(shape, rows))
    return errors


def _validate_media_family(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not _has_media_row(rows):
        errors.append(f"{shape} requires media/video rows")
    if not any(_has_media_row([row]) and _has_provenance(row) for row in rows):
        errors.append(f"{shape} requires media/video provenance")
    return errors


def _question_requires_assay_date(question: str) -> bool:
    q = question.lower()
    return any(
        term in q
        for term in (
            "run date",
            "assay date",
            "yesterday",
            "last week",
            "last month",
            "today",
            "this week",
            "this month",
            "recent",
            "latest",
            "may ",
            "apr ",
            "date_basis",
        )
    ) or bool(re.search(r"\b20\d{2}-\d{2}-\d{2}\b", q))


def _has_complete_assay_evidence_row(row: dict[str, Any], *, require_date: bool) -> bool:
    if not _has_provenance(row):
        return False
    if not _has_any_key(row, {"assay_family", "assay_type"}) and "assay" not in _row_text(row):
        return False
    if not _has_any_key(row, {"species", "insect_class", "top_folder"}) and not any(
        term in _row_text(row) for term in ("mosquito", "flies", "fly", "drosophila", "moth", "beetle", "plant")
    ):
        return False
    date_keys = {"assay_date", "assay_date_iso", "first_assay_date", "latest_assay_date", "date_code", "date", "event_date_iso", "updated"}
    if require_date and not _has_any_key(row, date_keys):
        return False
    source_identity_keys = date_keys | {"source_name", "filename", "locator", "source_actions"}
    if not require_date and not _has_any_key(row, source_identity_keys):
        return False
    return True


def _validate_assay_family(shape: str, rows: list[dict[str, Any]], question: str = "") -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not _has_assay_row(rows):
        errors.append(f"{shape} requires assay evidence")
    require_date = _question_requires_assay_date(question)
    if not any(_has_complete_assay_evidence_row(row, require_date=require_date) for row in rows):
        if require_date:
            errors.append(f"{shape} requires assay rows with family/type, date, species, and provenance")
        else:
            errors.append(f"{shape} requires assay rows with family/type, species, source identity, and provenance")
    return errors


def _validate_assay_result_list(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    family_keys = {"assay_family", "assay_type", "assay_mode"}
    date_keys = {
        "assay_date",
        "assay_date_iso",
        "date",
        "date_window",
        "event_date_iso",
        "first_assay_date",
        "latest_assay_date",
        "updated",
    }
    species_keys = {"species", "organism", "insect_class", "top_folder"}
    result_keys = {
        "avg_pi",
        "avg_pref_index",
        "corrected_mean_trt_pi",
        "metric_name",
        "metric_value",
        "preference_index",
        "ranking_score",
        "result_role",
    }
    identity_keys = {"treatment", "compound", "treatment_normalized", "result_source_name", "run_source_name"}
    if not any(_has_any_key(row, family_keys) for row in rows):
        errors.append(f"{shape} requires assay family/type context")
    if not any(_has_any_key(row, date_keys) for row in rows):
        errors.append(f"{shape} requires assay date or date-window context")
    if not any(_has_any_key(row, species_keys) for row in rows):
        errors.append(f"{shape} requires species or organism context")
    if not any(_has_any_key(row, result_keys) for row in rows):
        errors.append(f"{shape} requires assay result metric evidence")
    if not any(_has_any_key(row, identity_keys) for row in rows):
        errors.append(f"{shape} requires treatment, compound, or result-source identity")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    if not any(
        _has_any_key(row, family_keys)
        and _has_any_key(row, date_keys)
        and _has_any_key(row, species_keys)
        and _has_any_key(row, result_keys)
        and _has_any_key(row, identity_keys)
        and _has_provenance(row)
        for row in rows
    ):
        errors.append(f"{shape} requires assay result rows with family/type, date, species, metric, identity, and provenance")
    return errors

    return errors


def _validate_assay_inventory_count(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not any(_has_any_key(row, {"assay_family", "assay_type"}) for row in rows):
        errors.append(f"{shape} requires assay family or assay type")
    if not any(_has_any_key(row, {"species"}) for row in rows):
        errors.append(f"{shape} requires species scope")
    if not any(_has_any_key(row, {"assay_count", "unit_count", "file_count", "run_count"}) for row in rows):
        errors.append(f"{shape} requires count fields")
    if not any(_has_any_key(row, {"count_unit", "native_count_units"}) for row in rows):
        errors.append(f"{shape} requires explicit count unit")
    if not any(_has_any_key(row, {"date_window", "first_evidence_date", "latest_evidence_date"}) for row in rows):
        errors.append(f"{shape} requires date-window evidence")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    return errors


def _validate_people_family(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not _has_people_row(rows):
        errors.append(f"{shape} requires people rows with name plus role, lane, or text")
    if not _has_complete_people_row(rows):
        errors.append(f"{shape} requires people rows with name and provenance")
    return errors


def _validate_meeting_family(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not _has_meeting_row(rows):
        errors.append(f"{shape} requires meeting or Teams recap evidence")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires meeting provenance")
    return errors


def _validate_fly_assay_count(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not any(_has_any_key(row, {"trial_rows", "distinct_filenames"}) for row in rows):
        errors.append(f"{shape} requires fly assay count fields")
    if not any(_has_any_key(row, {"count_unit", "date_range", "first_date_iso", "last_date_iso"}) for row in rows):
        errors.append(f"{shape} requires count basis or date-range evidence")
    if not any(
        (row.get("species") and _row_matches_species(row, "flies")) or "flies/" in _row_text(row) or "fly" in _row_text(row)
        for row in rows
    ):
        errors.append(f"{shape} requires fly-scoped rows")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    return errors


def _validate_environment_conditions(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    gap_rows = [
        row for row in rows
        if str(row.get("environment_status") or "").lower() in {"source_gap", "metadata_gap"}
        or _has_any_key(row, {"source_gap_reason"})
    ]
    evidence_rows = [row for row in rows if row not in gap_rows]
    rows_to_check = evidence_rows if evidence_rows else rows
    if not evidence_rows and gap_rows:
        if not any(_has_any_key(row, {"source_gap_reason"}) for row in gap_rows):
            errors.append(f"{shape} source-gap rows require a source gap reason")
        if not any(_has_any_key(row, {"species", "assay_family", "assay_type"}) for row in gap_rows):
            errors.append(f"{shape} source-gap rows require species or assay-family context")
        if not _has_any_provenance(gap_rows):
            errors.append(f"{shape} source-gap rows require provenance")
        return errors
    if not any(_has_any_key(row, {"temperature_c", "temp", "temp_c"}) for row in rows_to_check):
        errors.append(f"{shape} requires temperature evidence")
    if not any(_has_any_key(row, {"relative_humidity_pct", "rh", "humidity_pct"}) for row in rows_to_check):
        errors.append(f"{shape} requires humidity evidence")
    if not any(_has_any_key(row, {"metric_name", "metric_value", "ranking_score", "avg_pi", "corrected_mean_trt_pi"}) for row in rows_to_check):
        errors.append(f"{shape} requires the result metric used to define promising")
    if not any(_has_any_key(row, {"species", "assay_family", "assay_type"}) for row in rows):
        errors.append(f"{shape} requires species or assay-family context")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    return errors


def _normalized_assay_mode(value: Any) -> str:
    return str(value or "").strip().lower().replace("_", "-")


def _validate_contact_noncontact_comparison(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    modes = {_normalized_assay_mode(row.get("assay_mode")) for row in rows}
    if "contact" not in modes or "non-contact" not in modes:
        errors.append(f"{shape} requires both contact and non-contact rows")
    if not any(_has_any_key(row, {"rank", "adj_contact_pi_mean"}) for row in rows):
        errors.append(f"{shape} requires adjusted contact PI ranking fields")
    if not any(_has_any_key(row, {"compound", "video_stem", "treatment_label"}) for row in rows):
        errors.append(f"{shape} requires compound or video identity")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    errors.extend(_validate_metric_uncertainty(shape, rows))
    return errors


def _validate_recent_contact_noncontact_assays(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    modes = {_normalized_assay_mode(row.get("assay_mode")) for row in rows}
    if not modes.intersection({"contact", "non-contact"}):
        errors.append(f"{shape} requires contact or non-contact assay mode")
    if not any(_has_any_key(row, {"species"}) for row in rows):
        errors.append(f"{shape} requires species scope")
    if not any(_has_any_key(row, {"assay_count", "video_count", "object_name", "uri", "locator"}) for row in rows):
        errors.append(f"{shape} requires count or media-object evidence")
    if not any(_has_any_key(row, {"date_window", "evidence_time", "latest_evidence_time", "updated", "time_created"}) for row in rows):
        errors.append(f"{shape} requires date-window or evidence-time basis")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    return errors


def _validate_rank_expectation(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not any(_has_any_key(row, {"compound", "target_compound", "treatment_label"}) for row in rows):
        errors.append(f"{shape} requires the target compound")
    if not any(_has_any_key(row, {"actual_rank", "rank", "nearby_rank"}) for row in rows):
        errors.append(f"{shape} requires actual or nearby rank evidence")
    if not any(_has_any_key(row, {"ranking_metric", "metric_name", "adj_contact_pi_mean"}) for row in rows):
        errors.append(f"{shape} requires the ranking metric")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    return errors


def _validate_summary_file_explanation(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not any(_has_any_key(row, {"source_file", "file_version", "source_name"}) for row in rows):
        errors.append(f"{shape} requires summary-file identity")
    if not any(_has_any_key(row, {"row_count", "column_name", "metric_definition", "updated", "time_created"}) for row in rows):
        errors.append(f"{shape} requires file schema, metric, or version evidence")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    return errors


def _validate_script_method_evidence(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not any(_has_any_key(row, {"script_name", "name", "source_name"}) for row in rows):
        errors.append(f"{shape} requires script file identity")
    if not any(_has_any_key(row, {"script_line", "line_number", "sub_id"}) for row in rows):
        errors.append(f"{shape} requires script line numbers")
    if not any(_has_any_key(row, {"evidence_text", "text", "snippet"}) for row in rows):
        errors.append(f"{shape} requires script line text")
    if not any(_has_any_key(row, {"script_uri", "uri", "locator"}) or _has_provenance(row) for row in rows):
        errors.append(f"{shape} requires script locator or provenance")
    if not _has_any_provenance(rows):
        errors.append(f"{shape} requires provenance")
    return errors


def _has_chemistry_provenance(rows: list[dict[str, Any]]) -> bool:
    if not _has_any_provenance(rows):
        return False
    return any(any(term in _row_text(row) for term in CHEMISTRY_PROVENANCE_TERMS) for row in rows)


def _validate_chemistry_analysis(shape: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if not rows:
        return [f"{shape} returned no rows"]
    if not _has_chemistry_provenance(rows):
        errors.append(f"{shape} requires chemistry_analysis provenance")
    if shape in {"protein_structure_artifact_list", "protein_structure_target_list"}:
        if not any(_has_any_key(row, {"name", "target"}) for row in rows):
            errors.append(f"{shape} requires protein structure file or target identity")
    elif shape == "protein_structure_species_list":
        if not any(_has_any_key(row, {"species"}) for row in rows):
            errors.append(f"{shape} requires species")
        if not any(_has_any_key(row, {"structure_count"}) for row in rows):
            errors.append(f"{shape} requires structure counts")
    elif shape == "alphafold_confidence_score_list":
        if not any(_has_any_key(row, {"mean_plddt", "ranking_confidence"}) for row in rows):
            errors.append(f"{shape} requires mean_plddt or ranking_confidence")
    elif shape == "chemistry_model_artifact_list":
        if not any(_has_any_key(row, {"name", "metadata_json", "uri"}) for row in rows):
            errors.append(f"{shape} requires model artifact identity")
    elif shape == "chemistry_artifact_list":
        if not any(_has_any_key(row, {"name", "kind", "uri"}) for row in rows):
            errors.append(f"{shape} requires artifact object identity")
    elif shape == "chemistry_species_result_summary":
        if not any(_has_any_key(row, {"species"}) for row in rows):
            errors.append(f"{shape} requires species")
        if not any(_has_any_key(row, {"artifact_count", "protein_structure_count", "result_sidecar_count"}) for row in rows):
            errors.append(f"{shape} requires artifact/result counts")
    elif shape == "chemistry_ligand_compound_list":
        if not any(_has_any_key(row, {"evidence_text", "name", "sub_id"}) for row in rows):
            errors.append(f"{shape} requires ligand or compound row evidence")
    return errors


def _validate_registered_shape(shape: str, question: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if shape not in CONTRACTED_ANSWER_SHAPES:
        return [f"{shape} has no registered answer contract"]
    if shape == "unknown":
        return ["unknown answer shape cannot satisfy a production answer"]
    if shape in SOURCE_GAP_SHAPES:
        return []
    if not rows:
        errors.append(f"{shape} requires at least one evidence row")
    if shape == "ranked_cross_assay_repellent_compounds":
        errors.extend(_validate_cross_assay_repellent_ranking(shape, rows))
        return errors
    if shape in PEOPLE_SHAPES:
        errors.extend(_validate_people_family(shape, rows))
    if shape in RANKING_SHAPES:
        errors.extend(_validate_ranking_family(shape, rows, question))
    if shape in MEDIA_SHAPES:
        errors.extend(_validate_media_family(shape, rows))
    if shape in MEETING_SHAPES:
        errors.extend(_validate_meeting_family(shape, rows))
    if shape in ASSAY_SHAPES:
        errors.extend(_validate_assay_family(shape, rows, question))
        errors.extend(_validate_species_scope(question, rows))
    if shape in ASSAY_RESULT_SHAPES:
        errors.extend(_validate_assay_result_list(shape, rows))
        errors.extend(_validate_species_scope(question, rows))
    if shape in ASSAY_COUNT_SHAPES:
        errors.extend(_validate_assay_inventory_count(shape, rows))
        errors.extend(_validate_species_scope(question, rows))
    if shape in INVENTORY_SHAPES:
        errors.extend(_validate_inventory_family(shape, question, rows))
    if shape in TESTED_COMPOUND_WINDOW_SHAPES:
        errors.extend(_validate_tested_compound_window(shape, rows))
    if shape in FLY_ASSAY_COUNT_SHAPES:
        errors.extend(_validate_fly_assay_count(shape, rows))
    if shape in ENVIRONMENT_CONDITION_SHAPES:
        errors.extend(_validate_environment_conditions(shape, rows))
    if shape in CONTACT_NONCONTACT_COMPARISON_SHAPES:
        errors.extend(_validate_contact_noncontact_comparison(shape, rows))
    if shape in RECENT_CONTACT_NONCONTACT_SHAPES:
        errors.extend(_validate_recent_contact_noncontact_assays(shape, rows))
    if shape in RANK_EXPECTATION_SHAPES:
        errors.extend(_validate_rank_expectation(shape, rows))
    if shape in SUMMARY_FILE_EXPLANATION_SHAPES:
        errors.extend(_validate_summary_file_explanation(shape, rows))
    if shape in SCRIPT_METHOD_SHAPES:
        errors.extend(_validate_script_method_evidence(shape, rows))
    if shape in CHEMISTRY_ANALYSIS_SHAPES:
        errors.extend(_validate_chemistry_analysis(shape, rows))
    return errors


def _validate_mixed(shape: str, question: str, rows: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    if shape in {"mixed_ranking_plus_media", "mixed_assay_list_plus_media"} and not _has_media_row(rows):
        errors.append(f"{shape} requires at least one media/video row")
    if shape == "mixed_ranking_plus_media" and not _has_ranking_row(rows):
        errors.append(f"{shape} requires at least one metric ranking row")
    if shape in {"mixed_ranking_plus_media", "mixed_ranking_plus_entity_mentions", "mixed_recent_tested_plus_ranking"}:
        errors.extend(_validate_ranking_family(shape, rows, question))
    if shape in {"mixed_ranking_plus_media", "mixed_assay_list_plus_media", "mixed_assay_media_plus_meeting_summary", "mixed_meeting_reference_plus_media"}:
        errors.extend(_validate_media_family(shape, rows))
    if shape in {
        "assay_runs_with_meeting_commentary",
        "assay_runs_with_media",
        "mixed_assay_list_plus_media",
        "mixed_assay_list_plus_meeting_summary",
        "mixed_assay_media_plus_meeting_summary",
        "mixed_docking_plus_assay_results",
        "mixed_inventory_plus_assay_results",
        "mixed_inventory_assay_presentation",
    }:
        errors.extend(_validate_assay_family(shape, rows))
    if shape in {"assay_runs_with_meeting_commentary", "mixed_assay_list_plus_meeting_summary", "mixed_assay_media_plus_meeting_summary"}:
        errors.extend(_validate_meeting_family(shape, rows))
    if shape in {"mixed_inventory_plus_assay_results", "mixed_inventory_assay_presentation", "mixed_inventory_plus_entity_mentions"}:
        errors.extend(_validate_inventory_family(shape, "", rows))
    return errors


def validate_answer_payload(question: str, payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {"ok": False, "checked": False, "answer_shape": None, "row_count": 0, "errors": ["payload is not an object"]}

    shape = primary_answer_shape(payload)
    rows = flatten_rows(payload)
    if not payload.get("ok", True):
        return {
            "ok": True,
            "checked": False,
            "answer_shape": shape,
            "row_count": len(rows),
            "errors": [],
            "skipped_reason": "upstream payload is not ok",
        }
    if not shape:
        return {"ok": True, "checked": False, "answer_shape": shape, "row_count": len(rows), "errors": []}

    errors = _validate_registered_shape(shape, question, rows)
    if shape.startswith("mixed_"):
        errors.extend(_validate_mixed(shape, question, rows))

    return {"ok": not errors, "checked": True, "answer_shape": shape, "row_count": len(rows), "errors": errors}


def enforce_answer_contract(question: str, payload: dict[str, Any]) -> dict[str, Any]:
    validation = validate_answer_payload(question, payload)
    payload["answer_shape_validation"] = validation
    if validation["ok"]:
        return payload

    source_gap = dict(payload.get("source_gap") or {})
    source_gap.update(
        {
            "reason": "answer_shape_gap",
            "expected_answer_shape": validation.get("answer_shape"),
            "row_count": validation.get("row_count", 0),
            "errors": validation.get("errors", []),
            "message": "; ".join(validation.get("errors", [])) or "returned rows did not satisfy the requested answer shape",
        }
    )
    payload["ok"] = False
    payload["mode"] = "source_gap"
    payload["error"] = "answer_shape_gap"
    payload["source_gap"] = source_gap
    return payload
