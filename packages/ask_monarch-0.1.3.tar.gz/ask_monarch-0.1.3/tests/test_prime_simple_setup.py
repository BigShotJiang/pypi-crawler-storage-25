import os
import pathlib
import tempfile
import tomllib
import unittest
from importlib import resources
from unittest import mock

from ask_monarch_cli import cli
from ask_monarch_cli import routing_decision
from ask_monarch_cli.agent_setup import ASK_MONARCH_SKILLS, setup_agents


ROOT = pathlib.Path(__file__).resolve().parents[1]


class PrimeSimpleSetupTests(unittest.TestCase):
    def test_pyproject_exposes_ask_monarch_console_script(self):
        data = tomllib.loads((ROOT / "pyproject.toml").read_text())
        self.assertEqual(data["project"]["name"], "ask-monarch")
        self.assertEqual(data["project"]["requires-python"], ">=3.10")
        self.assertEqual(data["project"]["scripts"]["ask-monarch"], "ask_monarch_cli.cli:main")
        self.assertIn("skills/*/SKILL.md", data["tool"]["setuptools"]["package-data"]["ask_monarch_cli"])
        self.assertIn("skills/*/scripts/*", data["tool"]["setuptools"]["package-data"]["ask_monarch_cli"])
        self.assertIn("skills/*/agents/*", data["tool"]["setuptools"]["package-data"]["ask_monarch_cli"])
        self.assertIn("config/*.json", data["tool"]["setuptools"]["package-data"]["ask_monarch_cli"])

    def test_routing_config_files_are_packaged_with_cli(self):
        config_root = resources.files("ask_monarch_cli").joinpath("config")
        for name in ("query-routing.json", "source-capabilities.json", "adapter-modifiers.json"):
            self.assertTrue(config_root.joinpath(name).is_file())

        self.assertIn("/ask_monarch_cli/config/", routing_decision.DEFAULT_SOURCE_CAPABILITIES_CONFIG)
        self.assertIn("people_directory", routing_decision.load_source_capabilities()["sources"])

    def test_setup_agents_writes_company_scoped_codex_and_claude_files(self):
        with tempfile.TemporaryDirectory() as home:
            result = setup_agents(home=home, agents=("codex", "claude"))
            self.assertTrue(result["ok"])

            root = pathlib.Path(home)
            for skill_name in ASK_MONARCH_SKILLS:
                self.assertTrue((root / ".codex" / "skills" / skill_name / "SKILL.md").exists())
            self.assertEqual((root / ".codex" / "AGENTS.md").read_text().count("ASK_MONARCH_INSTALLER_BEGIN"), 1)
            for skill_name in ASK_MONARCH_SKILLS:
                self.assertTrue((root / ".claude" / "skills" / skill_name / "SKILL.md").exists())
            self.assertEqual((root / ".claude" / "CLAUDE.md").read_text().count("ASK_MONARCH_INSTALLER_BEGIN"), 1)
            self.assertTrue((root / ".codex" / "skills" / "video-overlay" / "scripts" / "circle_landing_overlay.py").exists())
            self.assertTrue((root / ".claude" / "skills" / "video-overlay" / "scripts" / "circle_landing_overlay.py").exists())

    def test_setup_command_uses_stable_code_without_printing_token(self):
        def fake_request_json(url, token=None, method="GET", payload=None):
            if url.endswith("/onboarding/exchange"):
                self.assertEqual(payload, {"code": "MNR-STABLE"})
                return {"ok": True, "token": "secret-token", "email": "teammate@example.com", "label": "team"}
            if url.endswith("/health"):
                return {"ok": True}
            if url.endswith("/summary"):
                return {"ok": True, "summary": {"company_profile": {"rows": 1}}}
            if url.endswith("/query"):
                self.assertEqual(payload["q"], "what is Monarch?")
                return {
                    "ok": True,
                    "answer": "Monarch is an R&D company.",
                    "source": "company_profile",
                    "rows": [{"row_number": 1}],
                }
            return {"ok": True}

        with tempfile.TemporaryDirectory() as home:
            config_path = pathlib.Path(home) / ".config" / "ask-monarch" / "config.json"
            env = {
                "HOME": home,
                "ASK_MONARCH_BIN": str(pathlib.Path(home) / ".local" / "bin" / "ask-monarch"),
                "CODEX_HOME": str(pathlib.Path(home) / ".codex"),
            }
            bin_path = pathlib.Path(env["ASK_MONARCH_BIN"])

            def fake_persistent_cli():
                bin_path.parent.mkdir(parents=True, exist_ok=True)
                bin_path.write_text("#!/usr/bin/env sh\n")
                bin_path.chmod(0o755)
                os.environ["PATH"] = str(bin_path.parent) + os.pathsep + os.environ.get("PATH", "")
                return str(bin_path)

            with (
                mock.patch.object(cli, "CONFIG_PATH", str(config_path)),
                mock.patch.object(cli, "request_json", side_effect=fake_request_json),
                mock.patch.object(cli, "ensure_persistent_cli", side_effect=fake_persistent_cli),
                mock.patch.dict(os.environ, env, clear=False),
                mock.patch("sys.stdout") as stdout,
            ):
                code = cli.main(["setup", "--code", "MNR-STABLE"])
                output = "".join(call.args[0] for call in stdout.write.call_args_list)

        self.assertEqual(code, 0)
        self.assertNotIn("secret-token", output)
        self.assertIn('"status": "ready"', output)
        self.assertIn('"source_id": "company_profile"', output)

    def test_setup_prefers_uv_tool_install_for_persistent_cli(self):
        with tempfile.TemporaryDirectory() as home:
            bin_path = pathlib.Path(home) / ".local" / "bin" / "ask-monarch"
            env = {
                "HOME": home,
                "ASK_MONARCH_BIN": str(bin_path),
                "ASK_MONARCH_TOOL_SOURCE": ".",
                "PATH": os.pathsep.join(["/tmp/uvx-shadow", str(bin_path.parent), os.environ.get("PATH", "")]),
            }
            completed = mock.Mock(returncode=0)
            with (
                mock.patch.object(cli.shutil, "which", return_value="/usr/local/bin/uv"),
                mock.patch.object(cli.subprocess, "run", return_value=completed) as run,
                mock.patch.dict(os.environ, env, clear=False),
            ):
                self.assertEqual(cli.ensure_persistent_cli(), str(bin_path))
                self.assertEqual(os.environ["PATH"].split(os.pathsep)[0], str(bin_path.parent))

        self.assertEqual(run.call_args.args[0], ["/usr/local/bin/uv", "tool", "install", "-U", "--from", ".", "ask-monarch"])

    def test_login_command_exchanges_stable_code_and_refreshes_agents(self):
        def fake_request_json(url, token=None, method="GET", payload=None):
            if url.endswith("/onboarding/exchange"):
                self.assertEqual(payload, {"code": "MNR-STABLE"})
                return {"ok": True, "token": "secret-token", "email": "teammate@example.com", "label": "team"}
            return {"ok": True}

        with tempfile.TemporaryDirectory() as home:
            config_path = pathlib.Path(home) / ".config" / "ask-monarch" / "config.json"
            with (
                mock.patch.object(cli, "CONFIG_PATH", str(config_path)),
                mock.patch.object(cli, "request_json", side_effect=fake_request_json),
                mock.patch.dict(os.environ, {"HOME": home}, clear=False),
                mock.patch("sys.stdout") as stdout,
            ):
                code = cli.main(["login", "--setup-code", "MNR-STABLE"])
                output = "".join(call.args[0] for call in stdout.write.call_args_list)

            self.assertEqual(code, 0)
            self.assertNotIn("secret-token", output)
            self.assertIn('"login": "configured"', output)
            for skill_name in ASK_MONARCH_SKILLS:
                self.assertTrue((pathlib.Path(home) / ".codex" / "skills" / skill_name / "SKILL.md").exists())
                self.assertTrue((pathlib.Path(home) / ".claude" / "skills" / skill_name / "SKILL.md").exists())

    def test_clean_home_verifier_uses_local_tool_source(self):
        text = (ROOT / "scripts" / "verify_prime_simple_setup.py").read_text()
        self.assertIn("ASK_MONARCH_SETUP_CODE", text)
        self.assertIn("ASK_MONARCH_TOOL_SOURCE", text)
        self.assertIn('"uvx"', text)
        self.assertIn('"--from"', text)
        self.assertIn('"ask-monarch"', text)
        self.assertIn('"setup"', text)


if __name__ == "__main__":
    unittest.main()
