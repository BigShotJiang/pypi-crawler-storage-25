import json
import os
import sqlite3
import sys
import tempfile
import unittest
from unittest import mock
from argparse import Namespace


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class RefreshSourceIndexTests(unittest.TestCase):
    def test_systemd_refresh_runs_main_bucket_chemistry_and_teams(self):
        service_path = os.path.join(ROOT, "deploy/systemd/ask-monarch-refresh.service")

        with open(service_path, "r", encoding="utf-8") as handle:
            service = handle.read()

        self.assertIn("scripts/refresh_bucket_sources.py", service)

        import refresh_bucket_sources

        jobs = refresh_bucket_sources.default_jobs()
        self.assertEqual([job["source"] for job in jobs], ["bucket", "chemistry_analysis", "teams_recaps"])
        self.assertIn("scripts/refresh_source_index.py", jobs[0]["cmd"])
        self.assertIn("scripts/refresh_chemistry_analysis_source.py", jobs[1]["cmd"])
        self.assertIn("scripts/refresh_teams_recaps_source.py", jobs[2]["cmd"])

    def test_systemd_refresh_timer_runs_just_after_midnight_pacific(self):
        timer_path = os.path.join(ROOT, "deploy/systemd/ask-monarch-refresh.timer")

        with open(timer_path, "r", encoding="utf-8") as handle:
            timer = handle.read()

        self.assertIn("OnCalendar=*-*-* 00:05:00 America/Los_Angeles", timer)

    def test_chemistry_refresh_stage_verifier_accepts_complete_stage(self):
        import parse_monarch_chemistry_analysis as chemistry
        import refresh_chemistry_analysis_source

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = chemistry.connect(db_path)
            try:
                chemistry.init_db(conn)
                obj = {
                    "name": "chemical_registry/chemical_activity_registry.csv",
                    "size": "10",
                    "contentType": "text/csv",
                    "generation": "1",
                    "metageneration": "1",
                    "md5Hash": "abc",
                    "crc32c": "def",
                    "updated": "2026-05-13T00:00:00Z",
                    "timeCreated": "2026-05-13T00:00:00Z",
                }
                chemistry.insert_object(conn, obj)
                chemistry.set_status(conn, obj, "parsed", "csv_parser", 1)
                conn.execute(
                    "INSERT INTO source_search(unit_type, name, sub_id, body, provenance_grain) VALUES (?, ?, ?, ?, ?)",
                    ("object", obj["name"], obj["name"], "DEET", "{}"),
                )
                conn.commit()
                chemistry.write_outputs(conn, tmp, metadata={"name": "monarch-chemistry-analysis"})
                with open(os.path.join(tmp, "object_manifest.jsonl"), "w", encoding="utf-8") as handle:
                    handle.write(json.dumps(obj) + "\n")
            finally:
                conn.close()

            summary = refresh_chemistry_analysis_source.verify_stage(tmp)

            self.assertEqual(summary["object_count"], 1)
            self.assertEqual(summary["gap_count"], 0)

    def test_chemistry_refresh_stage_verifier_refuses_gaps(self):
        import parse_monarch_chemistry_analysis as chemistry
        import refresh_chemistry_analysis_source

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = chemistry.connect(db_path)
            try:
                chemistry.init_db(conn)
                obj = {
                    "name": "bad.json",
                    "size": "2",
                    "contentType": "application/json",
                    "generation": "1",
                    "metageneration": "1",
                    "md5Hash": "abc",
                    "crc32c": "def",
                    "updated": "2026-05-13T00:00:00Z",
                    "timeCreated": "2026-05-13T00:00:00Z",
                }
                chemistry.insert_object(conn, obj)
                chemistry.set_status(conn, obj, "gap", "json_parser", 0, "parse_exception", "boom")
                conn.commit()
                chemistry.write_outputs(conn, tmp, metadata={"name": "monarch-chemistry-analysis"})
                with open(os.path.join(tmp, "object_manifest.jsonl"), "w", encoding="utf-8") as handle:
                    handle.write(json.dumps(obj) + "\n")
            finally:
                conn.close()

            with self.assertRaises(SystemExit):
                refresh_chemistry_analysis_source.verify_stage(tmp)

    def test_teams_refresh_stage_verifier_accepts_multi_series_stage(self):
        import parse_monarch_r_and_d_teams_recaps as teams_parser
        import refresh_teams_recaps_source

        vtt = """WEBVTT

00:00:00.000 --> 00:00:02.000
<v Josh>Daily sync evidence is queryable now.</v>
"""
        with tempfile.TemporaryDirectory() as tmp:
            raw_dir = os.path.join(tmp, "profiles", "monarch_team_sync_teams_recaps", "raw")
            os.makedirs(raw_dir, exist_ok=True)
            raw_path = os.path.join(raw_dir, "2026-05-06.vtt")
            with open(raw_path, "w", encoding="utf-8") as handle:
                handle.write(vtt)
            manifest = {
                "source_id": "monarch_recurring_teams_recaps",
                "subject": "Monarch recurring Teams recaps",
                "start_date": "2026-05-06",
                "end_date": "2026-05-06",
                "event_count": 1,
                "transcript_count_total": 1,
                "downloaded_count": 1,
                "gap_count": 0,
                "downloaded": [
                    {
                        "source_id": "monarch_team_sync_teams_recaps",
                        "date": "2026-05-06",
                        "event": {
                            "id": "event-1",
                            "subject": "Monarch Team Sync",
                            "type": "occurrence",
                            "seriesMasterId": "series-1",
                            "start": {"dateTime": "2026-05-06T17:00:00.0000000"},
                            "end": {"dateTime": "2026-05-06T18:00:00.0000000"},
                            "onlineMeeting": {"joinUrl": "https://teams.example/join"},
                            "webLink": "https://teams.example/event",
                            "organizer": {"emailAddress": {"address": "josh@monarchcrops.com"}},
                        },
                        "transcript": {"id": "transcript-1", "createdDateTime": "2026-05-06T19:00:00Z"},
                        "file": {
                            "parse_path": raw_path,
                            "raw_path": "artifacts/monarch-r-and-d-teams-recaps/profiles/monarch_team_sync_teams_recaps/raw/2026-05-06.vtt",
                        },
                    }
                ],
                "gaps": [],
            }
            with open(os.path.join(tmp, "meeting_manifest.json"), "w", encoding="utf-8") as handle:
                json.dump(manifest, handle)

            old_argv = sys.argv
            try:
                sys.argv = ["parse_monarch_r_and_d_teams_recaps.py", "--out", tmp]
                self.assertEqual(teams_parser.main(), 0)
            finally:
                sys.argv = old_argv

            summary = refresh_teams_recaps_source.verify_stage(tmp)
            self.assertEqual(summary["meeting_count"], 1)
            self.assertEqual(summary["utterance_count"], 1)
            self.assertEqual(summary["gap_count"], 0)

            conn = sqlite3.connect(os.path.join(tmp, "source_index.sqlite"))
            try:
                row = conn.execute("SELECT id, provenance_grain FROM meetings").fetchone()
            finally:
                conn.close()
            self.assertEqual(row[0], "monarch_team_sync_teams_recaps:2026-05-06")
            self.assertEqual(json.loads(row[1])["source_id"], "monarch_team_sync_teams_recaps")

    def test_teams_refresh_stage_verifier_refuses_gaps(self):
        import refresh_teams_recaps_source

        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "source_status.json"), "w", encoding="utf-8") as handle:
                json.dump({"source_id": "monarch_recurring_teams_recaps", "fully_parsed": False, "gap_count": 1}, handle)
            with open(os.path.join(tmp, "gaps.json"), "w", encoding="utf-8") as handle:
                json.dump([{"date": "2026-05-06", "kind": "missing_transcript"}], handle)
            with open(os.path.join(tmp, "source_receipt.json"), "w", encoding="utf-8") as handle:
                json.dump({"source_id": "monarch_recurring_teams_recaps"}, handle)
            with open(os.path.join(tmp, "meeting_manifest.json"), "w", encoding="utf-8") as handle:
                json.dump({"source_id": "monarch_recurring_teams_recaps"}, handle)
            sqlite3.connect(os.path.join(tmp, "source_index.sqlite")).close()

            with self.assertRaises(SystemExit):
                refresh_teams_recaps_source.verify_stage(tmp)

    def test_incremental_delta_invalidates_only_changed_and_deleted_objects(self):
        import refresh_source_index
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = sqlite3.connect(db_path)
            source_pipeline.init_db(conn)
            conn.executemany(
                """
                INSERT INTO objects
                (name, uri, kind, top_folder, ext, size, content_type, generation,
                 metageneration, md5_hash, crc32c, updated, time_created)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    ("changed.csv", "gs://monarch-videos-new/changed.csv", "csv", "(root)", ".csv", 10, "text/csv", "1", "1", "old", "oldcrc", "2026-05-01T00:00:00Z", "2026-05-01T00:00:00Z"),
                    ("unchanged.txt", "gs://monarch-videos-new/unchanged.txt", "text", "(root)", ".txt", 7, "text/plain", "1", "1", "same", "samecrc", "2026-05-01T00:00:00Z", "2026-05-01T00:00:00Z"),
                    ("deleted.json", "gs://monarch-videos-new/deleted.json", "json", "(root)", ".json", 2, "application/json", "1", "1", "gone", "gonecrc", "2026-05-01T00:00:00Z", "2026-05-01T00:00:00Z"),
                ],
            )
            conn.executemany(
                """
                INSERT INTO parse_status
                (name, kind, status, parser, parsed_at, unit_count, gap, error)
                VALUES (?, ?, 'parsed', 'test', '2026-05-01T00:00:00Z', 1, NULL, NULL)
                """,
                [("changed.csv", "csv"), ("unchanged.txt", "text"), ("deleted.json", "json")],
            )
            conn.execute("INSERT INTO csv_columns VALUES ('changed.csv', 'a', 1, '1')")
            conn.execute("INSERT INTO text_lines VALUES ('unchanged.txt', 1, 'keep', '1')")
            conn.execute("INSERT INTO json_units VALUES ('deleted.json', '$', '{}', 'object', '1')")
            conn.commit()
            conn.close()

            manifest = [
                {
                    "name": "changed.csv",
                    "size": "11",
                    "contentType": "text/csv",
                    "generation": "2",
                    "metageneration": "1",
                    "md5Hash": "new",
                    "crc32c": "newcrc",
                    "updated": "2026-05-02T00:00:00Z",
                    "timeCreated": "2026-05-01T00:00:00Z",
                },
                {
                    "name": "unchanged.txt",
                    "size": "7",
                    "contentType": "text/plain",
                    "generation": "1",
                    "metageneration": "1",
                    "md5Hash": "same",
                    "crc32c": "samecrc",
                    "updated": "2026-05-01T00:00:00Z",
                    "timeCreated": "2026-05-01T00:00:00Z",
                },
                {
                    "name": "added.json",
                    "size": "4",
                    "contentType": "application/json",
                    "generation": "1",
                    "metageneration": "1",
                    "md5Hash": "add",
                    "crc32c": "addcrc",
                    "updated": "2026-05-02T00:00:00Z",
                    "timeCreated": "2026-05-02T00:00:00Z",
                },
            ]
            with open(os.path.join(tmp, "object_manifest.jsonl"), "w", encoding="utf-8") as handle:
                for row in manifest:
                    handle.write(json.dumps(row) + "\n")

            delta = refresh_source_index.prepare_incremental_delta(tmp)

            self.assertEqual(delta["manifest_objects"], 3)
            self.assertEqual(delta["source_objects_before"], 3)
            self.assertEqual(delta["source_objects_after"], 3)
            self.assertEqual(delta["counts"], {"add": 1, "change": 1, "delete": 1})

            conn = sqlite3.connect(db_path)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM parse_status WHERE name='unchanged.txt'").fetchone()[0], 1)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM parse_status WHERE name='changed.csv'").fetchone()[0], 0)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM csv_columns WHERE name='changed.csv'").fetchone()[0], 0)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM text_lines WHERE name='unchanged.txt'").fetchone()[0], 1)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM objects WHERE name='deleted.json'").fetchone()[0], 0)
            conn.close()

    def test_serving_tables_promote_method_development_and_dbm_oviposition(self):
        import source_pipeline

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        source_pipeline.init_db(conn)
        conn.executemany(
            """
            INSERT INTO objects
            (name, uri, kind, top_folder, ext, size, content_type, generation,
             metageneration, md5_hash, crc32c, updated, time_created)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    "flies/Method Development/Oviposition/Images/Screenshot 2026-05-12 12-10-22.png",
                    "gs://monarch-videos-new/flies/Method Development/Oviposition/Images/Screenshot 2026-05-12 12-10-22.png",
                    "image",
                    "flies",
                    ".png",
                    100,
                    "image/png",
                    "img1",
                    "1",
                    "md5",
                    "crc",
                    "2026-05-12T19:31:44Z",
                    "2026-05-12T19:31:44Z",
                ),
                (
                    "DBM/Oviposition/Images/DBM_eggs1.png",
                    "gs://monarch-videos-new/DBM/Oviposition/Images/DBM_eggs1.png",
                    "image",
                    "DBM",
                    ".png",
                    200,
                    "image/png",
                    "dbm1",
                    "1",
                    "md5",
                    "crc",
                    "2026-05-12T22:32:37Z",
                    "2026-05-12T22:32:37Z",
                ),
            ],
        )
        conn.executemany(
            """
            INSERT INTO xlsx_cells
            (name, sheet, cell, row_number, value, generation)
            VALUES ('flies/Method Development/Oviposition/fly_oviposition_metadata.xlsx', 'Sheet1', ?, 2, ?, 'xlsx1')
            """,
            [
                ("A2", "5122026"),
                ("B2", "trial_1"),
                ("C2", "3"),
                ("D2", "sucrose"),
                ("E2", "agar"),
                ("F2", "2"),
                ("G2", "4"),
                ("H2", "6"),
                ("I2", "0.3333333333333333"),
                ("J2", "Screenshot 2025-05-12 12-10-22.png"),
                ("K2", "method development row"),
            ],
        )

        counts = source_pipeline.build_serving_tables(conn)

        self.assertEqual(counts["assay_runs"], 2)
        fly = conn.execute(
            """
            SELECT *
            FROM assay_runs
            WHERE source_name = 'flies/Method Development/Oviposition/fly_oviposition_metadata.xlsx'
            """
        ).fetchone()
        self.assertEqual(fly["species"], "flies")
        self.assertEqual(fly["assay_family"], "fly_oviposition")
        self.assertEqual(fly["run_date"], "2026-05-12")
        self.assertEqual(fly["treatment_normalized"], "agar")
        self.assertIsNone(fly["source_gap_reason"])

        pi = conn.execute(
            "SELECT * FROM assay_results WHERE run_id = ? AND metric_name = 'pi'",
            (fly["run_id"],),
        ).fetchone()
        self.assertAlmostEqual(pi["metric_value"], 0.3333333333333333)
        self.assertIn("xlsx_row", pi["provenance_grain"])

        fly_media = conn.execute(
            "SELECT * FROM media_links WHERE run_id = ?",
            (fly["run_id"],),
        ).fetchone()
        self.assertEqual(
            fly_media["media_name"],
            "flies/Method Development/Oviposition/Images/Screenshot 2026-05-12 12-10-22.png",
        )
        self.assertEqual(fly_media["match_method"], "metadata_image_file_year_corrected_to_2026")

        moth = conn.execute(
            "SELECT * FROM assay_runs WHERE source_name = 'DBM/Oviposition/Images/DBM_eggs1.png'"
        ).fetchone()
        self.assertEqual(moth["species"], "moths")
        self.assertEqual(moth["assay_family"], "moth_oviposition")
        self.assertEqual(moth["run_date"], "2026-05-12")
        self.assertIn("DBM oviposition images are indexed", moth["source_gap_reason"])

    def test_subset_manifest_does_not_delete_omitted_existing_objects(self):
        import refresh_source_index
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = sqlite3.connect(db_path)
            source_pipeline.init_db(conn)
            conn.executemany(
                """
                INSERT INTO objects
                (name, uri, kind, top_folder, ext, size, content_type, generation,
                 metageneration, md5_hash, crc32c, updated, time_created)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    ("existing.txt", "gs://monarch-videos-new/existing.txt", "text", "(root)", ".txt", 7, "text/plain", "1", "1", "same", "samecrc", "2026-05-01T00:00:00Z", "2026-05-01T00:00:00Z"),
                ],
            )
            conn.execute(
                """
                INSERT INTO parse_status
                (name, kind, status, parser, parsed_at, unit_count, gap, error)
                VALUES ('existing.txt', 'text', 'parsed', 'test', '2026-05-01T00:00:00Z', 1, NULL, NULL)
                """
            )
            conn.commit()
            conn.close()

            with open(os.path.join(tmp, "object_manifest.jsonl"), "w", encoding="utf-8") as handle:
                handle.write(
                    json.dumps(
                        {
                            "name": "friday.json",
                            "size": "4",
                            "contentType": "application/json",
                            "generation": "9",
                            "metageneration": "1",
                            "md5Hash": "new",
                            "crc32c": "newcrc",
                            "updated": "2026-05-02T03:00:00Z",
                            "timeCreated": "2026-05-02T03:00:00Z",
                        }
                    )
                    + "\n"
                )

            delta = refresh_source_index.prepare_incremental_delta(tmp, manifest_scope="subset")

            self.assertEqual(delta["manifest_objects"], 1)
            self.assertEqual(delta["source_objects_before"], 1)
            self.assertEqual(delta["source_objects_after"], 2)
            self.assertEqual(delta["counts"], {"add": 1, "change": 0, "delete": 0})

            conn = sqlite3.connect(db_path)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM objects WHERE name='existing.txt'").fetchone()[0], 1)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM parse_status WHERE name='existing.txt'").fetchone()[0], 1)
            conn.close()

    def test_incremental_delta_guard_requires_expected_counts(self):
        import refresh_source_index

        delta = {
            "manifest_objects": 103,
            "source_objects_after": 2302666,
            "changes_total": 3,
            "counts": {"add": 3, "change": 0, "delete": 0},
        }
        args = Namespace(
            expected_additions=3,
            expected_changes=0,
            expected_deletions=0,
            expected_manifest_objects=103,
            expected_total_objects=2302666,
            max_changed_objects=5,
            allow_deletes=False,
        )

        guard = refresh_source_index.validate_incremental_delta(delta, args)

        self.assertTrue(guard["passed"])
        self.assertEqual(guard["failures"], [])
        self.assertEqual(guard["expected_additions"], 3)

    def test_incremental_delta_guard_refuses_unexpected_deletes(self):
        import refresh_source_index

        delta = {
            "manifest_objects": 99,
            "source_objects_after": 99,
            "changes_total": 1,
            "counts": {"add": 0, "change": 0, "delete": 1},
        }
        args = Namespace(
            expected_additions=None,
            expected_changes=None,
            expected_deletions=None,
            expected_manifest_objects=None,
            expected_total_objects=None,
            max_changed_objects=None,
            allow_deletes=False,
        )

        with self.assertRaises(SystemExit):
            refresh_source_index.validate_incremental_delta(delta, args)

        guard = refresh_source_index.incremental_delta_guard(delta, args)
        self.assertFalse(guard["passed"])
        self.assertEqual(guard["failures"], ["deletions require --allow-deletes or --expected-deletions: 1"])

    def test_incremental_delta_receipt_can_record_guard_failure(self):
        import refresh_source_index

        delta = {
            "manifest_objects": 99,
            "manifest_scope": "full",
            "source_objects_before": 100,
            "source_objects_after": 99,
            "changes_total": 1,
            "counts": {"add": 0, "change": 0, "delete": 1},
            "samples": [],
            "samples_by_action": {
                "add": [],
                "change": [],
                "delete": [{"name": "old.mov", "action": "delete"}],
            },
        }
        guard = {
            "passed": False,
            "failures": ["deletions require --allow-deletes or --expected-deletions: 1"],
            "allow_deletes": False,
        }

        with tempfile.TemporaryDirectory() as tmp:
            refresh_source_index.write_incremental_delta_receipt(tmp, delta, guard, "delta_prepared")

            with open(os.path.join(tmp, "incremental_receipt.json"), "r", encoding="utf-8") as handle:
                receipt = json.load(handle)

        self.assertEqual(receipt["status"], "delta_prepared")
        self.assertFalse(receipt["guard"]["passed"])
        self.assertEqual(receipt["samples_by_action"]["delete"][0]["name"], "old.mov")

    def test_main_preserves_failed_incremental_stage_with_receipt(self):
        import refresh_source_index

        with tempfile.TemporaryDirectory() as tmp:
            live_dir = os.path.join(tmp, "monarch-videos-new")
            stage_dir = os.path.join(tmp, "monarch-videos-new.refresh-test")
            os.makedirs(live_dir)

            def fail_after_receipt(_live_dir, _stage_dir, _args):
                os.makedirs(_stage_dir, exist_ok=True)
                with open(os.path.join(_stage_dir, "incremental_receipt.json"), "w", encoding="utf-8") as handle:
                    json.dump({"status": "delta_prepared"}, handle)
                raise SystemExit("guard failed")

            argv = [
                "refresh_source_index.py",
                "--incremental",
                "--stage-dir",
                stage_dir,
                "--no-restart",
            ]
            with mock.patch.dict(os.environ, {"ASK_MONARCH_ARTIFACT_DIR": live_dir}):
                with mock.patch.object(sys, "argv", argv):
                    with mock.patch.object(refresh_source_index, "build_incremental_stage", fail_after_receipt):
                        with self.assertRaises(SystemExit):
                            refresh_source_index.main()

            self.assertTrue(os.path.exists(os.path.join(stage_dir, "incremental_receipt.json")))

    def test_incremental_build_removes_copied_stale_receipt_before_manifest(self):
        import refresh_source_index

        args = Namespace(
            include_csv_rows_in_search=False,
            dry_run=False,
            manifest_path=None,
            manifest_scope="full",
        )

        with tempfile.TemporaryDirectory() as tmp:
            live_dir = os.path.join(tmp, "live")
            stage_dir = os.path.join(tmp, "stage")
            os.makedirs(stage_dir)
            stale_receipt = os.path.join(stage_dir, "incremental_receipt.json")
            with open(stale_receipt, "w", encoding="utf-8") as handle:
                json.dump({"status": "verified"}, handle)

            with mock.patch.object(refresh_source_index, "copy_live_artifacts", return_value=True):
                with mock.patch.object(refresh_source_index, "run", side_effect=SystemExit("manifest failed")):
                    with self.assertRaises(SystemExit):
                        refresh_source_index.build_incremental_stage(live_dir, stage_dir, args)

            self.assertFalse(os.path.exists(stale_receipt))

    def test_bucket_manifest_listing_retries_transient_http_503(self):
        import urllib.error
        import parse_monarch_bucket

        class Response:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read(self):
                return b'{"items": [], "nextPageToken": null}'

        error = urllib.error.HTTPError("https://example.invalid", 503, "Service Unavailable", hdrs=None, fp=None)
        with mock.patch("urllib.request.urlopen", side_effect=[error, Response()]):
            with mock.patch.object(parse_monarch_bucket.time, "sleep") as sleep:
                payload = parse_monarch_bucket.request_json("https://example.invalid", "token")

        self.assertEqual(payload["items"], [])
        sleep.assert_called_once_with(1)

    def test_delta_search_index_updates_only_changed_names(self):
        import query_source
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = sqlite3.connect(db_path)
            try:
                source_pipeline.init_db(conn)
                conn.execute(
                    """
                    INSERT INTO objects
                    (name, uri, kind, top_folder, ext, size, content_type, generation,
                     metageneration, md5_hash, crc32c, updated, time_created)
                    VALUES
                    ('old.txt', 'gs://monarch-videos-new/old.txt', 'text', '(root)', '.txt',
                     1, 'text/plain', '1', '1', NULL, NULL, '2026-05-01T00:00:00Z', '2026-05-01T00:00:00Z'),
                    ('keep.txt', 'gs://monarch-videos-new/keep.txt', 'text', '(root)', '.txt',
                     1, 'text/plain', '1', '1', NULL, NULL, '2026-05-01T00:00:00Z', '2026-05-01T00:00:00Z')
                    """
                )
                conn.commit()

                query_source.build_index(conn)
                self.assertEqual(conn.execute("SELECT COUNT(*) FROM source_search WHERE name='old.txt'").fetchone()[0], 1)

                conn.execute("DELETE FROM objects WHERE name='old.txt'")
                conn.execute(
                    """
                    INSERT INTO objects
                    (name, uri, kind, top_folder, ext, size, content_type, generation,
                     metageneration, md5_hash, crc32c, updated, time_created)
                    VALUES ('new.txt', 'gs://monarch-videos-new/new.txt', 'text', '(root)', '.txt',
                     1, 'text/plain', '1', '1', NULL, NULL, '2026-05-02T00:00:00Z', '2026-05-02T00:00:00Z')
                    """
                )
                conn.execute(
                    """
                    CREATE TABLE incremental_refresh_delta (
                      name TEXT PRIMARY KEY,
                      action TEXT NOT NULL,
                      old_kind TEXT,
                      new_kind TEXT,
                      old_generation TEXT,
                      new_generation TEXT,
                      old_updated TEXT,
                      new_updated TEXT
                    )
                    """
                )
                conn.executemany(
                    "INSERT INTO incremental_refresh_delta(name, action) VALUES (?, ?)",
                    [("old.txt", "delete"), ("new.txt", "add")],
                )
                conn.commit()

                query_source.build_delta_index(conn)

                self.assertEqual(conn.execute("SELECT COUNT(*) FROM source_search WHERE name='old.txt'").fetchone()[0], 0)
                self.assertEqual(conn.execute("SELECT COUNT(*) FROM source_search WHERE name='new.txt'").fetchone()[0], 1)
                self.assertEqual(conn.execute("SELECT COUNT(*) FROM source_search WHERE name='keep.txt'").fetchone()[0], 1)
            finally:
                conn.close()

    def test_finalize_stage_sqlite_checkpoint_leaves_swappable_database(self):
        import refresh_source_index
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA journal_mode=WAL")
            source_pipeline.init_db(conn)
            conn.execute(
                """
                INSERT INTO objects
                (name, uri, kind, top_folder, ext, size, content_type, generation,
                 metageneration, md5_hash, crc32c, updated, time_created)
                VALUES ('ok.txt', 'gs://monarch-videos-new/ok.txt', 'text', '(root)', '.txt',
                        2, 'text/plain', '1', '1', NULL, NULL,
                        '2026-05-02T00:00:00Z', '2026-05-02T00:00:00Z')
                """
            )
            conn.execute(
                """
                INSERT INTO parse_status
                (name, kind, status, parser, parsed_at, unit_count, gap, error)
                VALUES ('ok.txt', 'text', 'parsed', 'test', '2026-05-02T00:00:00Z', 1, NULL, NULL)
                """
            )
            conn.execute("CREATE TABLE source_search(body TEXT)")
            conn.execute("INSERT INTO source_search VALUES ('ok')")
            conn.execute("CREATE TABLE source_search_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            conn.execute("INSERT INTO source_search_meta VALUES ('status', '{\"indexed_rows\": 1}')")
            conn.commit()
            conn.close()

            refresh_source_index.finalize_stage_sqlite(tmp)

            self.assertFalse(os.path.exists(db_path + "-wal"))
            self.assertFalse(os.path.exists(db_path + "-shm"))
            conn = sqlite3.connect(db_path)
            self.assertEqual(conn.execute("PRAGMA quick_check").fetchone()[0], "ok")
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM source_search").fetchone()[0], 1)
            conn.close()

    def test_finalize_stage_sqlite_refuses_corrupt_database(self):
        import refresh_source_index

        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "source_index.sqlite"), "wb") as handle:
                handle.write(b"not a sqlite database")

            with self.assertRaises((sqlite3.DatabaseError, SystemExit)):
                refresh_source_index.finalize_stage_sqlite(tmp)


if __name__ == "__main__":
    unittest.main()
