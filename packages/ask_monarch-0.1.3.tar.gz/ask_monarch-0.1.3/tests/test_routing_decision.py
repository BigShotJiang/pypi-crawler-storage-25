import os
import sqlite3
import sys
import unittest
from datetime import date, timedelta


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class RoutingDecisionTests(unittest.TestCase):
    def test_hosted_script_and_package_router_sources_stay_identical(self):
        script_router = os.path.join(ROOT, "scripts", "routing_decision.py")
        package_router = os.path.join(ROOT, "ask_monarch_cli", "routing_decision.py")

        with open(script_router, "r", encoding="utf-8") as handle:
            script_text = handle.read()
        with open(package_router, "r", encoding="utf-8") as handle:
            package_text = handle.read()

        self.assertEqual(script_text, package_text)

    def test_advisors_route_to_structured_people_directory(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "who are the advisors at Monarch?",
            "people_directory",
        )

        self.assertEqual(route["intent"], "advisor_roster")
        self.assertEqual(route["source_lane"], "people_directory")
        self.assertEqual(route["retrieval_shape"], "structured")
        self.assertEqual(route["adapter"], "people_directory_advisor_roster_sql")
        self.assertEqual(route["fallback_policy"], "no_silent_prose_fallback")
        self.assertEqual(
            route["structured_first"],
            {
                "checked": True,
                "source_lane": "people_directory",
                "answer_adapter": "people_directory_advisor_roster_sql",
                "anchor_adapter": "no_match",
                "result": "structured_answer",
            },
        )

    def test_r_and_d_discussion_routes_to_structured_teams_recaps(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what did R&D discuss last Friday?",
            "teams_recaps",
        )

        self.assertEqual(route["intent"], "meeting_digest_by_date")
        self.assertEqual(route["source_lane"], "teams_recaps")
        self.assertEqual(route["retrieval_shape"], "structured")
        self.assertEqual(route["adapter"], "teams_recaps_meeting_digest_by_date_sql")
        self.assertEqual(route["fallback_policy"], "no_silent_prose_fallback")

    def test_r_and_d_meeting_date_digest_routes_to_structured_adapter(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what did the team discuss during last Friday's R&D meeting?",
            "auto",
        )

        self.assertEqual(route["intent"], "meeting_digest_by_date")
        self.assertEqual(route["source_lane"], "teams_recaps")
        self.assertEqual(route["retrieval_shape"], "structured")
        self.assertEqual(route["adapter"], "teams_recaps_meeting_digest_by_date_sql")
        self.assertEqual(route["adapter_execution"], "sql")

    def test_dated_team_discussion_routes_to_structured_meeting_digest_without_meeting_word(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what did the team discuss yesterday?",
            "auto",
        )

        self.assertEqual(route["intent"], "meeting_digest_by_date")
        self.assertEqual(route["source_lane"], "teams_recaps")
        self.assertEqual(route["retrieval_shape"], "structured")
        self.assertEqual(route["adapter"], "teams_recaps_meeting_digest_by_date_sql")
        self.assertEqual(route["fallback_policy"], "no_silent_prose_fallback")

    def test_meeting_topic_speaker_rollup_routes_topic_questions(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "which speakers discussed assays",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "teams_recaps")
        self.assertEqual(payload["routing_decision"]["adapter"], "teams_recaps_topic_speaker_rollup_sql")
        self.assertEqual(payload["routing_decision"]["evidence_shape"], "meeting_topic_speaker_rollup")
        self.assertIn("GROUP BY", payload["sql"])
        self.assertIn("utterances", payload["sql"])

    def test_scientific_refs_route_to_source_specific_prose(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what does the literature say about odorant receptors?",
            "scientific_refs",
        )

        self.assertEqual(route["intent"], "source_specific_prose")
        self.assertEqual(route["source_lane"], "scientific_refs")
        self.assertEqual(route["retrieval_shape"], "prose")
        self.assertEqual(route["adapter"], "scientific_refs_source_text_retrieval")
        self.assertEqual(
            route["structured_first"],
            {
                "checked": True,
                "source_lane": "scientific_refs",
                "answer_adapter": "no_match",
                "anchor_adapter": "no_match",
                "result": "prose_allowed",
            },
        )

    def test_bucket_interpretation_routes_to_structured_anchor_before_prose(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "why might peppermint oil be working?",
            "auto",
        )

        self.assertEqual(route["intent"], "bucket_structured_anchor")
        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["adapter"], "bucket_structured_anchor_probe_sql")
        self.assertEqual(route["adapter_execution"], "structured_anchor_then_text_retrieval")
        self.assertEqual(route["fallback_policy"], "structured_first_then_prose")
        self.assertEqual(
            route["structured_first"],
            {
                "checked": True,
                "source_lane": "bucket",
                "answer_adapter": "no_match",
                "anchor_adapter": "bucket_structured_anchor_probe_sql",
                "result": "structured_anchor",
            },
        )

    def test_answer_shape_selects_phytotox_ranking_before_tested_compound_list(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "list the most phytoxic compounds we have tested, from 1-5",
            "auto",
        )

        self.assertEqual(route["answer_shape"], "ranked_phytotoxicity_compounds")
        self.assertEqual(route["selection_policy"], "answer_shape_first")
        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["retrieval_shape"], "structured")
        self.assertEqual(route["intent"], "assay_serving_table")
        self.assertEqual(route["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(route["evidence_shape"], "assay_serving_table")
        self.assertEqual(route["fallback_policy"], "no_silent_prose_fallback")
        self.assertTrue(route["candidate_routes"])
        self.assertIn(
            "bucket_phytotox_rank_compounds_sql",
            [candidate["adapter"] for candidate in route["candidate_routes"]],
        )

    def test_answer_shape_keeps_phytotox_ranking_with_assay_species_constraint(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list the most phytoxic compounds we have tested in flies/mosquitoes assays",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(
            payload["routing_decision"]["answer_shape"],
            "ranked_phytotoxicity_compounds_with_assay_species_constraint",
        )
        self.assertEqual(payload["routing_decision"]["selection_policy"], "answer_shape_first")
        self.assertEqual(
            payload["routing_decision"]["adapter"],
            "bucket_phytotox_rank_compounds_by_assay_species_sql",
        )
        self.assertIn("standard_deviation", payload["sql"])
        self.assertIn("standard_deviation_basis", payload["sql"])
        self.assertEqual(
            payload["routing_decision"]["extracted_parameters"]["assay_species"],
            ["flies", "mosquitoes"],
        )
        self.assertIn("phytotoxicity/results", payload["sql"])
        self.assertIn("dart_assay_results", payload["sql"])
        self.assertIn("flies/repellency_screen_metadata_sheet.xlsx", payload["sql"])
        self.assertIn("assay_species", payload["sql"])

    def test_compositional_route_preserves_fly_ranking_and_phytotox_comparison(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what are the top fly repellents, and compare against phytotoxicity",
            "auto",
        )

        self.assertEqual(route["intent"], "compositional_answer_contract")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["adapter_execution"], "route_plan")
        self.assertEqual(
            route["answer_shapes"],
            ["ranked_fly_repellent_compounds", "ranked_phytotoxicity_compounds"],
        )
        self.assertEqual(
            [(step["source_lane"], step["adapter"]) for step in route["route_plan"]],
            [
                ("bucket", "bucket_fly_repellency_rankings_sql"),
                ("bucket", "bucket_phytotox_rank_compounds_sql"),
            ],
        )
        self.assertEqual(
            [step["question"] for step in route["route_plan"]],
            [
                "what are the top fly repellents",
                "what are the most phytotoxic compounds",
            ],
        )

    def test_phytotox_species_constrained_sql_requires_matching_assay_evidence(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE objects (
              name TEXT,
              top_folder TEXT,
              kind TEXT,
              updated TEXT,
              time_created TEXT
            );
            CREATE TABLE csv_rows (
              name TEXT,
              row_number INTEGER,
              row_json TEXT
            );
            CREATE TABLE csv_rows_with_provenance (
              name TEXT,
              row_number INTEGER,
              row_json TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE xlsx_cells (
              name TEXT,
              sheet TEXT,
              cell TEXT,
              row_number INTEGER,
              value TEXT,
              generation TEXT
            );
            CREATE TABLE dart_assay_results (
              source_name TEXT,
              sheet TEXT,
              row_number INTEGER,
              species TEXT,
              assay_type TEXT,
              assay_date TEXT,
              filename TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              provenance_grain TEXT
            );
            """
        )
        conn.execute(
            "INSERT INTO objects VALUES ('phytotoxicity/results/run/predictions/analysis/features_all.csv', 'phytotoxicity', 'csv', '2026-05-01', '2026-05-01')"
        )
        conn.execute(
            """
            INSERT INTO csv_rows VALUES
            ('phytotoxicity/results/run/predictions/analysis/features_all.csv', 1,
             '{"treatment_name":"Linalool","condition":"treatment","damaged_fraction":"1.0","chlorosis_fraction":"0.5","browning_fraction":"0.1","necrosis_fraction":"0.0"}')
            """
        )
        conn.execute(
            """
            INSERT INTO csv_rows VALUES
            ('phytotoxicity/results/run/predictions/analysis/features_all.csv', 2,
             '{"treatment_name":"Plant Only","condition":"treatment","damaged_fraction":"1.0","chlorosis_fraction":"0.6","browning_fraction":"0.2","necrosis_fraction":"0.0"}')
            """
        )
        conn.execute(
            """
            INSERT INTO dart_assay_results
            (source_name, sheet, row_number, species, assay_type, assay_date, filename, treatment, treatment_normalized, provenance_grain)
            VALUES ('mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx', 'Assays', 10, 'mosquitoes', 'DART', '5012026', 'linalool.mov', 'Linalool', 'Linalool', '{"grain_type":"dart_assay_row"}')
            """
        )
        conn.executemany(
            "INSERT INTO xlsx_cells VALUES ('flies/repellency_screen_metadata_sheet.xlsx', 'trials', ?, 2, ?, '1')",
            [("B2", "fly-linalool.mp4"), ("N2", "LIN")],
        )
        conn.executemany(
            "INSERT INTO xlsx_cells VALUES ('flies/repellency_screen_metadata_sheet.xlsx', 'key to chem names and abbrev', ?, 2, ?, '1')",
            [("A2", "LIN"), ("B2", "Linalool"), ("C2", "TESTINCHI")],
        )

        payload = routing_decision.query_payload_for_question(
            "list the most phytoxic compounds we have tested in flies/mosquitoes assays",
            "auto",
            limit=10,
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual([row["compound"] for row in rows], ["Linalool"])
        self.assertEqual(rows[0]["assay_species"], "flies,mosquitoes")
        self.assertEqual(rows[0]["assay_evidence_rows"], 2)
        self.assertIn("phytotox_assay_constrained_rank", rows[0]["provenance_grain"])

    def test_answer_shape_selector_does_not_run_candidate_that_cannot_produce_shape(self):
        import routing_decision

        candidate = routing_decision._route_candidate(
            intent="compounds_tested_all_structured",
            source_lane="bucket",
            retrieval_shape="structured",
            adapter="bucket_compounds_tested_all_structured_sql",
            adapter_execution="sql",
            reason="broad tested-compound list",
            sql="SELECT 1",
            answer_shapes=["tested_compound_list"],
        )

        selected, answer_shape, candidate_routes, rejected_routes = routing_decision._select_candidate_for_answer_shape(
            "list the most phytoxic compounds we have tested, from 1-5",
            [candidate],
        )

        self.assertIsNone(selected)
        self.assertEqual(answer_shape, "ranked_phytotoxicity_compounds")
        self.assertEqual(candidate_routes[0]["rejected_reason"], "cannot_produce_answer_shape")
        self.assertEqual(rejected_routes[0]["adapter"], "bucket_compounds_tested_all_structured_sql")

    def test_answer_shape_turns_repellency_plus_milestones_into_mixed_plan(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "show me the top compounds per repellency data and whether they are mentioned in our milestones",
            "auto",
        )

        self.assertEqual(route["answer_shape"], "ranked_repellents_with_milestone_mentions")
        self.assertEqual(route["selection_policy"], "answer_shape_first")
        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["adapter_execution"], "route_plan")
        self.assertEqual(route["fallback_policy"], "structured_first_then_fts")
        self.assertEqual(
            [(step["source_lane"], step["adapter"]) for step in route["route_plan"]],
            [
                ("bucket", "bucket_cross_assay_repellent_rank_compounds_sql"),
                ("milestones_doc", "milestones_doc_source_text_retrieval"),
            ],
        )
        self.assertNotIn(
            "bucket_fly_result_video_bridge_sql",
            [rejected["adapter"] for rejected in route["rejected_routes"]],
        )

    def test_answer_shape_turns_top_fly_repellent_videos_into_direct_bridge(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "show the video for the top fly repellents",
            "auto",
        )

        self.assertEqual(route["answer_shape"], "ranked_repellents_with_media")
        self.assertEqual(route["selection_policy"], "answer_shape_first")
        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["retrieval_shape"], "structured")
        self.assertEqual(route["adapter_execution"], "sql")
        self.assertEqual(route["adapter"], "bucket_fly_result_video_bridge_sql")
        self.assertEqual(route["fallback_policy"], "no_silent_prose_fallback")
        self.assertIn("top_performing_chemicals.csv", route["sql"])

    def test_answer_shape_turns_assays_plus_meeting_commentary_into_mixed_plan(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what assays team ran yesterday and what they said about them in the team meeting friday am",
            "auto",
        )

        self.assertEqual(route["answer_shape"], "assay_runs_with_meeting_commentary")
        self.assertEqual(route["selection_policy"], "answer_shape_first")
        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["adapter_execution"], "route_plan")
        self.assertEqual(
            [(step["source_lane"], step["adapter"]) for step in route["route_plan"]],
            [
                ("bucket", "bucket_cross_assay_run_inventory_sql"),
                ("teams_recaps", "teams_recaps_topic_speaker_rollup_sql"),
            ],
        )
        rejected_by_adapter = {
            rejected["adapter"]: rejected
            for rejected in route["rejected_routes"]
        }
        self.assertEqual(
            rejected_by_adapter["bucket_cross_assay_run_inventory_sql"]["rejected_reason"],
            "partial_answer_only",
        )

    def test_assay_meeting_bridge_route_plan_uses_step_specific_questions(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what fly assays ran last week and what did the meeting say",
            "auto",
        )

        self.assertEqual(route["intent"], "assay_runs_with_meeting_commentary")
        self.assertEqual(
            [step["question"] for step in route["route_plan"]],
            [
                "what fly assays ran last week",
                "what did the team say about fly assays last week",
            ],
        )

    def test_exact_fact_source_gap_exposes_structured_first_check(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what did Slack say about the latest assay?",
            "auto",
        )

        self.assertEqual(route["retrieval_shape"], "source_gap")
        self.assertEqual(
            route["structured_first"],
            {
                "checked": True,
                "source_lane": "slack",
                "answer_adapter": "no_match",
                "anchor_adapter": "no_match",
                "result": "source_gap",
            },
        )

    def test_dated_meeting_interpretation_routes_to_meeting_anchor_before_prose(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what was the team uncertain about in last Friday's R&D meeting?",
            "auto",
        )

        self.assertEqual(route["intent"], "meeting_anchor_by_date")
        self.assertEqual(route["source_lane"], "teams_recaps")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["adapter"], "teams_recaps_meeting_anchor_sql")
        self.assertEqual(route["adapter_execution"], "structured_anchor_then_text_retrieval")
        self.assertEqual(route["fallback_policy"], "structured_first_then_prose")

    def test_mixed_anchor_payload_keeps_question_and_anchor_sql(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "why might peppermint oil be working?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("structured_anchor_sql", payload)
        self.assertIn("dart_assay_results", payload["structured_anchor_sql"])
        self.assertEqual(payload["question"], "why might peppermint oil be working?")
        self.assertNotIn("sql", payload)
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "mixed")

    def test_meeting_anchor_payload_keeps_question_and_anchor_sql(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what was the team uncertain about in last Friday's R&D meeting?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "teams_recaps")
        self.assertIn("structured_anchor_sql", payload)
        self.assertIn("meetings", payload["structured_anchor_sql"])
        self.assertEqual(payload["question"], "what was the team uncertain about in last Friday's R&D meeting?")
        self.assertNotIn("sql", payload)
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "mixed")

    def test_recent_noncontact_video_routes_to_structured_object_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "show me a recent no contact video",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["intent"], "recent_media_by_mode")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_recent_media_by_mode_sql")
        self.assertEqual(payload["routing_decision"]["fallback_policy"], "no_silent_prose_fallback")
        self.assertIn("sql", payload)
        self.assertNotIn("question", payload)
        self.assertIn("FROM objects", payload["sql"])
        self.assertIn("kind = 'video'", payload["sql"])
        self.assertIn("%noncontact%", payload["sql"])
        self.assertIn("NOT LIKE '%/processed/%'", payload["sql"])

    def test_recent_contact_video_adapter_excludes_noncontact_objects(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "show me a recent contact video",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["routing_decision"]["intent"], "recent_media_by_mode")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_recent_media_by_mode_sql")
        self.assertIn("LIKE '%_contact_%'", payload["sql"])
        self.assertIn("NOT LIKE '%noncontact%'", payload["sql"])

    def test_recent_contact_no_contact_assays_route_to_structured_objects_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list the most recent contact / no contact assays - the most recent 2",
            "auto",
            limit=2,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertNotIn("question", payload)
        self.assertEqual(payload["routing_decision"]["intent"], "recent_contact_no_contact_assays")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(
            payload["routing_decision"]["adapter"],
            "bucket_recent_contact_no_contact_assays_sql",
        )
        self.assertEqual(payload["routing_decision"]["evidence_shape"], "recent_contact_no_contact_assays")
        self.assertIn("FROM objects", payload["sql"])
        self.assertIn("contact_repel_videos", payload["sql"])
        self.assertIn("kind = 'video'", payload["sql"])
        self.assertIn("NOT LIKE '%/processed/%'", payload["sql"])
        self.assertIn("NOT LIKE '%control%'", payload["sql"])

    def test_recent_contact_no_contact_assays_sql_runs_on_objects_fixture(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE objects (
              name TEXT,
              uri TEXT,
              kind TEXT,
              ext TEXT,
              size INTEGER,
              content_type TEXT,
              updated TEXT,
              time_created TEXT
            );
            """
        )
        rows = [
            ("contact_repel_videos/mosquitoes_new_solvent/IMG_0109_Contact_Menthol.mov", "gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/IMG_0109_Contact_Menthol.mov", "video", ".mov", 1, "video/quicktime", "2026-05-08T23:06:06Z", "2026-05-08T23:06:06Z"),
            ("contact_repel_videos/mosquitoes_new_solvent/IMG_0108_NonContact_Menthol.mov", "gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/IMG_0108_NonContact_Menthol.mov", "video", ".mov", 1, "video/quicktime", "2026-05-08T23:05:17Z", "2026-05-08T23:05:17Z"),
            ("contact_repel_videos/mosquitoes_new_solvent/IMG_0056_Contact_PEA.mov", "gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/IMG_0056_Contact_PEA.mov", "video", ".mov", 1, "video/quicktime", "2026-05-05T23:38:46Z", "2026-05-05T23:38:46Z"),
            ("contact_repel_videos/mosquitoes_new_solvent/IMG_0055_NonContact_PEA_mov.MOV", "gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/IMG_0055_NonContact_PEA_mov.MOV", "video", ".MOV", 1, "video/quicktime", "2026-05-05T23:37:40Z", "2026-05-05T23:37:40Z"),
            ("contact_repel_videos/mosquitoes_new_solvent/IMG_0107_Control_Menthol.mov", "gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/IMG_0107_Control_Menthol.mov", "video", ".mov", 1, "video/quicktime", "2026-05-08T23:04:00Z", "2026-05-08T23:04:00Z"),
            ("contact_repel_videos/mosquitoes_new_solvent/processed/annotated_IMG_0109_Contact_Menthol.png", "gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/processed/annotated_IMG_0109_Contact_Menthol.png", "image", ".png", 1, "image/png", "2026-05-09T01:00:00Z", "2026-05-09T01:00:00Z"),
        ]
        conn.executemany("INSERT INTO objects VALUES (?, ?, ?, ?, ?, ?, ?, ?)", rows)

        payload = routing_decision.query_payload_for_question(
            "list the most recent contact / no contact assays - the most recent 2",
            "auto",
            limit=2,
        )
        result_rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual([row["assay_mode"] for row in result_rows[:2]], ["contact", "non-contact"])
        self.assertEqual([row["compound"] for row in result_rows[:2]], ["Menthol", "Menthol"])
        pea_rows = [row for row in result_rows if "PEA" in row["object_name"]]
        self.assertEqual([row["compound"] for row in pea_rows], ["PEA", "PEA"])
        self.assertTrue(all("Control" not in row["object_name"] for row in result_rows))
        self.assertTrue(all("/processed/" not in row["object_name"] for row in result_rows))
        self.assertIn("recent_contact_no_contact_assay", result_rows[0]["provenance_grain"])

    def test_recent_contact_no_contact_assay_count_groups_by_species_and_mode(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        run_date = (routing_decision._local_today() - timedelta(days=4)).isoformat()
        conn.executescript(
            """
            CREATE TABLE assay_runs (
              run_id TEXT PRIMARY KEY,
              source_table TEXT,
              source_name TEXT,
              sheet TEXT,
              row_number INTEGER,
              species TEXT,
              assay_family TEXT,
              assay_type TEXT,
              assay_mode TEXT,
              run_date TEXT,
              filename TEXT,
              tube TEXT,
              slot TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              dilution TEXT,
              dilution_real REAL,
              solvent TEXT,
              left_condition TEXT,
              right_condition TEXT,
              treatment_position TEXT,
              n_subjects TEXT,
              n_subjects_real REAL,
              temp TEXT,
              rh TEXT,
              usable_data TEXT,
              source_gap_reason TEXT,
              provenance_grain TEXT
            );
            """
        )
        rows = [
            ("m-contact", "mosquitoes", "contact", "Menthol", "IMG_0109_Contact_Menthol.mov"),
            ("m-noncontact", "mosquitoes", "non_contact", "Menthol", "IMG_0108_NonContact_Menthol.mov"),
            ("f-contact", "flies", "contact", "DEET", "fly_Contact_DEET.mov"),
            ("f-noncontact", "flies", "non_contact", "DEET", "fly_NonContact_DEET.mov"),
        ]
        conn.executemany(
            """
            INSERT INTO assay_runs
            (run_id, source_table, source_name, sheet, row_number, species, assay_family, assay_type, assay_mode, run_date, filename, tube, slot, treatment, treatment_normalized, dilution, dilution_real, solvent, left_condition, right_condition, treatment_position, n_subjects, n_subjects_real, temp, rh, usable_data, source_gap_reason, provenance_grain)
            VALUES (?, 'assay_runs', 'fixture', NULL, 1, ?, 'contact_no_contact', 'contact/no-contact', ?, ?, ?, NULL, NULL, ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, '{"locator":"fixture"}')
            """,
            [(run_id, species, mode, run_date, filename, treatment, treatment) for run_id, species, mode, treatment, filename in rows],
        )

        payload = routing_decision.query_payload_for_question(
            "how many contact / no contact assays were run in last 30 days for flies and for mosquitoes",
            "auto",
            limit=20,
        )
        result_rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]
        by_key = {(row["species"], row["assay_mode"]): row["assay_count"] for row in result_rows}

        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_inventory_count")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("count_unit", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("assay_mode", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertEqual(payload["routing_decision"]["species_scope"], ["flies", "mosquitoes"])
        self.assertEqual(by_key[("flies", "contact")], 1)
        self.assertEqual(by_key[("flies", "non_contact")], 1)
        self.assertEqual(by_key[("mosquitoes", "contact")], 1)
        self.assertEqual(by_key[("mosquitoes", "non_contact")], 1)
        self.assertTrue(all(row["count_unit"] == "serving_table_assay_runs" for row in result_rows))
        self.assertTrue(all(row["provenance_grain"] for row in result_rows))

    def test_cross_assay_count_uses_inventory_shape_for_all_families(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "how many assays were run in the last 30 days across all assay families",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_inventory_count")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("assay_family", payload["sql"])
        self.assertIn("count_unit", payload["sql"])

    def test_cross_assay_count_supports_processed_result_requirement(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "how many assays have processed results in the last 30 days",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_inventory_count")
        self.assertIn("result_requirement", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("EXISTS (SELECT 1 FROM assay_results", payload["sql"])
        self.assertIn("'processed_result_rows' AS count_unit", payload["sql"])

    def test_cross_assay_count_supports_complete_contact_pairs(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "how many complete contact and non-contact pairs did we run in the last 30 days for flies and mosquitoes",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_inventory_count")
        self.assertIn("pairing_requirement", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("complete_contact_non_contact_pairs", payload["sql"])
        self.assertIn("HAVING modes_present = 2", payload["sql"])

    def test_attach_routing_decision_adds_visible_structured_routing_log(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "show me a recent no contact video",
            "auto",
            limit=5,
        )
        result = routing_decision.attach_routing_decision(
            payload,
            {
                "mode": "sql",
                "source": "bucket",
                "rows": [
                    {
                        "provenance_grain": '{"grain_type":"bucket_object","locator":"gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/IMG_0108_NonContact_Menthol.mov"}',
                        "source_actions": [
                            {
                                "type": "resolve_source",
                                "locator": "gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/IMG_0108_NonContact_Menthol.mov",
                            }
                        ]
                    }
                ],
            },
        )

        self.assertEqual(result["routing_log"]["path"], "query -> router -> bucket -> structured -> bucket_recent_media_by_mode_sql -> objects table -> resolve-source")
        self.assertEqual(result["routing_log"]["source_lane_ran"], "bucket")
        self.assertEqual(result["routing_log"]["winning_lane"], "bucket")
        self.assertEqual(result["routing_log"]["winning_adapter"], "bucket_recent_media_by_mode_sql")
        self.assertTrue(result["routing_log"]["short_circuit_fired"])
        self.assertEqual(result["routing_log"]["short_circuit_reason"], "no_silent_prose_fallback")
        self.assertEqual(result["routing_log"]["policy"], "no_silent_prose_fallback")
        self.assertEqual(
            result["routing_log"]["structured_result"],
            {
                "clean": True,
                "error": False,
                "expected_grain_type": "bucket_object",
                "matched_grain_type": "bucket_object",
                "row_count": 1,
            },
        )
        self.assertEqual(
            result["routing_log"]["extracted_parameters"],
            {
                "media_kind": "video",
                "media_mode": "noncontact",
                "matched_alias": "no contact",
                "order_by": "coalesce(updated, time_created) DESC",
                "exclude": ["processed artifacts"],
            },
        )
        self.assertEqual(
            result["routing_log"]["translation_steps"],
            [
                {"step": "source lane selection", "output": "bucket", "source": "system"},
                {"step": "alias matching", "input": "no contact", "output": "noncontact", "source": "user", "match_type": "deterministic_alias"},
                {"step": "parameter extraction", "input": "video", "output": "media_kind=video", "source": "user"},
                {"step": "parameter extraction", "input": "no contact", "output": "media_mode=noncontact", "source": "user"},
                {"step": "parameter extraction", "input": "recent", "output": "recent_first=true", "source": "user"},
                {"step": "parameter default", "output": "exclude=processed artifacts", "source": "default"},
                {"step": "adapter selection", "output": "bucket_recent_media_by_mode_sql", "source": "system"},
                {"step": "sql target", "output": "objects table", "source": "system"},
                {"step": "source action", "output": "resolve-source", "source": "system"},
            ],
        )

    def test_structured_clean_requires_expected_grain_type(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "show me a recent no contact video",
            "auto",
            limit=5,
        )
        result = routing_decision.attach_routing_decision(
            payload,
            {
                "mode": "sql",
                "source": "bucket",
                "rows": [
                    {
                        "name": "contact_repel_videos/mosquitoes_new_solvent/IMG_0108_NonContact_Menthol.mov",
                        "provenance_grain": '{"grain_type":"csv_row","locator":"wrong#row"}',
                    }
                ],
            },
        )

        self.assertEqual(payload["routing_decision"]["expected_grain_type"], "bucket_object")
        self.assertFalse(result["routing_log"]["structured_result"]["clean"])
        self.assertEqual(result["routing_log"]["structured_result"]["expected_grain_type"], "bucket_object")
        self.assertEqual(result["routing_log"]["structured_result"]["matched_grain_type"], "csv_row")
        self.assertFalse(result["routing_log"]["short_circuit_fired"])
        self.assertIsNone(result["routing_log"]["short_circuit_reason"])

    def test_structured_clean_requires_at_least_one_row_and_no_error(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "show me a recent no contact video",
            "auto",
            limit=5,
        )

        empty_result = routing_decision.attach_routing_decision(
            payload,
            {"mode": "sql", "source": "bucket", "rows": []},
        )
        error_result = routing_decision.attach_routing_decision(
            payload,
            {"mode": "sql", "source": "bucket", "rows": [{"provenance_grain": '{"grain_type":"bucket_object"}'}], "error": "boom"},
        )

        self.assertFalse(empty_result["routing_log"]["structured_result"]["clean"])
        self.assertEqual(empty_result["routing_log"]["structured_result"]["row_count"], 0)
        self.assertFalse(empty_result["routing_log"]["short_circuit_fired"])
        self.assertFalse(error_result["routing_log"]["structured_result"]["clean"])
        self.assertTrue(error_result["routing_log"]["structured_result"]["error"])
        self.assertFalse(error_result["routing_log"]["short_circuit_fired"])

    def test_source_gap_result_adds_visible_routing_log(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what does Monarch know from Slack?",
            "auto",
        )
        result = routing_decision.source_gap_result(payload)

        self.assertEqual(result["routing_log"]["source_lane_ran"], "slack")
        self.assertEqual(result["routing_log"]["winning_lane"], "slack")
        self.assertEqual(result["routing_log"]["winning_adapter"], "slack_source_text_retrieval")
        self.assertTrue(result["routing_log"]["short_circuit_fired"])
        self.assertEqual(result["routing_log"]["short_circuit_reason"], "fail_with_source_gap")

    def test_run_date_adapter_filters_explicit_iso_date_against_compact_assay_dates(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE dart_assay_results (
              assay_date TEXT,
              species TEXT,
              assay_type TEXT,
              treatment_normalized TEXT,
              filename TEXT,
              source_name TEXT,
              sheet TEXT,
              row_number INTEGER
            );
            """
        )
        for row_number in range(1, 19):
            conn.execute(
                """
                INSERT INTO dart_assay_results
                (assay_date, species, assay_type, treatment_normalized, filename, source_name, sheet, row_number)
                VALUES (?, 'mosquitoes', 'DART', ?, ?, 'mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx', 'Assays', ?)
                """,
                (
                    "5082026",
                    "Menthone" if row_number <= 9 else "Control",
                    f"run_{row_number}.mov",
                    1327 + row_number,
                ),
            )
        conn.execute(
            """
            INSERT INTO dart_assay_results
            (assay_date, species, assay_type, treatment_normalized, filename, source_name, sheet, row_number)
            VALUES ('5072026', 'mosquitoes', 'DART', 'PepOil', 'older.mov', 'mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx', 'Assays', 1310)
            """
        )

        payload = routing_decision.query_payload_for_question(
            "what DART assay did we run on 2026-05-08",
            "auto",
            limit=20,
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["assay_date"], "5082026")
        self.assertEqual(rows[0]["date_window"], "2026-05-08")
        self.assertEqual(rows[0]["assay_rows"], 18)
        self.assertEqual(rows[0]["treatments"], "Menthone,Control")
        self.assertEqual(
            payload["routing_decision"]["extracted_parameters"]["interpreted_date"],
            "2026-05-08",
        )
        self.assertEqual(
            payload["routing_decision"]["extracted_parameters"]["applied_filter"],
            "date(assay_date_iso) = date('2026-05-08')",
        )

    def test_run_date_adapter_filters_month_name_date(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what DART assay did we run on May 14 2026",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_experiments_by_run_date_sql")
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("exact_date", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertEqual(
            payload["routing_decision"]["extracted_parameters"]["interpreted_date"],
            "2026-05-14",
        )
        self.assertIn("date(assay_date_iso) = date('2026-05-14')", payload["sql"])

    def test_run_date_adapter_exposes_yesterday_date_translation(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what assay did we run yesterday",
            "auto",
            limit=20,
        )
        params = payload["routing_decision"]["extracted_parameters"]

        self.assertEqual(params["relative_date"], "yesterday")
        self.assertIn("interpreted_date", params)
        self.assertIn("applied_filter", params)
        self.assertIn("assay_date_iso", payload["sql"])
        self.assertNotIn("date(assay_date) = date('now', '-1 day')", payload["sql"])

        result = routing_decision.attach_routing_decision(
            payload,
            {"mode": "sql", "source": "bucket", "rows": []},
        )
        self.assertEqual(result["answer_metadata"]["interpreted_date"], params["interpreted_date"])
        self.assertEqual(result["answer_metadata"]["applied_filter"], params["applied_filter"])
        self.assertIn(
            {
                "step": "date interpretation",
                "input": "yesterday",
                "output": params["interpreted_date"],
                "source": "user",
            },
            result["routing_log"]["translation_steps"],
        )
        self.assertIn(
            {
                "step": "field normalization",
                "input": "assay_date",
                "output": "assay_date_iso",
                "source": "system",
            },
            result["routing_log"]["translation_steps"],
        )
        self.assertIn(
            {
                "step": "applied filter",
                "output": params["applied_filter"],
                "source": "system",
            },
            result["routing_log"]["translation_steps"],
        )

    def test_bucket_structured_anchor_sql_runs_on_union_shape(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE dart_assay_results (
              source_name TEXT,
              row_number INTEGER,
              species TEXT,
              assay_type TEXT,
              treatment_normalized TEXT,
              treatment TEXT,
              dilution TEXT,
              filename TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE assay_media_links (
              media_name TEXT,
              assay_row_number INTEGER,
              species TEXT,
              treatment_normalized TEXT,
              condition TEXT,
              media_uri TEXT,
              assay_source_name TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE model_metadata (
              name TEXT,
              metadata_json TEXT,
              provenance_grain TEXT
            );
            """
        )
        conn.execute(
            """
            INSERT INTO dart_assay_results
            (source_name, row_number, species, assay_type, treatment_normalized, treatment, dilution, filename, provenance_grain)
            VALUES ('mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx', 7, 'mosquitoes', 'DART', 'PepOil', 'Peppermint oil', '1x', 'pep.mov', '{"locator":"dart#7"}')
            """
        )

        payload = routing_decision.query_payload_for_question(
            "why might peppermint oil be working?",
            "auto",
        )
        rows = [dict(row) for row in conn.execute(payload["structured_anchor_sql"]).fetchall()]

        self.assertEqual(rows[0]["anchor_type"], "dart_assay_result")
        self.assertEqual(rows[0]["sub_id"], "7")

    def test_bucket_structured_anchor_sql_does_not_broaden_peppermint_oil_to_all_oils(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE dart_assay_results (
              source_name TEXT,
              row_number INTEGER,
              species TEXT,
              assay_type TEXT,
              treatment_normalized TEXT,
              treatment TEXT,
              dilution TEXT,
              filename TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE assay_media_links (
              media_name TEXT,
              assay_row_number INTEGER,
              species TEXT,
              treatment_normalized TEXT,
              condition TEXT,
              media_uri TEXT,
              assay_source_name TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE model_metadata (
              name TEXT,
              metadata_json TEXT,
              provenance_grain TEXT
            );
            """
        )
        conn.executemany(
            """
            INSERT INTO dart_assay_results
            (source_name, row_number, species, assay_type, treatment_normalized, treatment, dilution, filename, provenance_grain)
            VALUES ('mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx', ?, 'mosquitoes', 'DART', ?, ?, '1x', ?, ?)
            """,
            [
                (1, "seed", "seed oil", "Beetles/seed.mov", '{"locator":"dart#1"}'),
                (2, "PepOil", "Peppermint oil", "pep.mov", '{"locator":"dart#2"}'),
            ],
        )

        payload = routing_decision.query_payload_for_question(
            "why might peppermint oil be working?",
            "auto",
        )
        rows = [dict(row) for row in conn.execute(payload["structured_anchor_sql"]).fetchall()]

        self.assertEqual([row["sub_id"] for row in rows], ["2"])

    def test_top_mosquito_repellents_route_to_structured_bucket_adapter(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "top mosquito repellents",
            "bucket",
        )

        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["retrieval_shape"], "structured")
        self.assertEqual(route["intent"], "assay_serving_table")
        self.assertEqual(route["adapter"], "bucket_assay_serving_table_sql")

    def test_top_mosquito_dart_repellents_supports_last_month_date_window(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "rank the most effective repellents in the dart assay for mosquitoes in the last 1 month",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "ranked_species_repellent_compounds")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertNotIn("recency_order", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("'last_1_month' AS date_window", payload["sql"])
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("r.assay_family IN ('DART')", payload["sql"])

    def test_species_top_repellent_questions_route_to_specific_ranking_adapter(self):
        import routing_decision

        cases = [
            ("what are the top repellents in mosquito assays?", "mosquitoes"),
        ]

        for question, species in cases:
            with self.subTest(question=question):
                route = routing_decision.route_decision_for_question(question, "auto")

                self.assertEqual(route["intent"], "assay_serving_table")
                self.assertEqual(route["source_lane"], "bucket")
                self.assertEqual(route["retrieval_shape"], "structured")
                self.assertEqual(route["adapter"], "bucket_assay_serving_table_sql")
                self.assertEqual(route["species"], species)

    def test_fly_top_repellent_questions_route_to_fly_ranking_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what are the most repellent compoudns on flies",
            "auto",
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["intent"], "assay_serving_table")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(
            payload["routing_decision"]["adapter"],
            "bucket_assay_serving_table_sql",
        )
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("r.species = 'flies'", payload["sql"])

    def test_fly_ranking_route_exposes_evidence_shape(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what are the most repellent compounds on flies",
            "auto",
        )

        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(route["evidence_shape"], "assay_serving_table")
        self.assertEqual(route["latency_target_ms"]["p95"], 3000)

    def test_broad_top_repellent_questions_route_to_cross_assay_ranking(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what are the top repellent compounds",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["intent"], "assay_serving_table")
        self.assertEqual(
            payload["routing_decision"]["adapter"],
            "bucket_assay_serving_table_sql",
        )
        self.assertEqual(
            payload["routing_decision"]["answer_shape"],
            "ranked_cross_assay_repellent_compounds",
        )
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("ranking_score", payload["sql"])

    def test_explicit_dart_top_repellent_questions_keep_dart_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "which DART treatments look most repellent?",
            "auto",
        )

        self.assertEqual(payload["routing_decision"]["intent"], "assay_metric_or_ranking")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_dart_assay_results_sql")
        self.assertIn("dart_assay_results", payload["sql"])

    def test_dart_recent_timepoint_ranking_sql_uses_only_last_n_processed_assays(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE csv_rows_with_provenance (
              name TEXT,
              row_number INTEGER,
              row_json TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE csv_columns_with_provenance (
              name TEXT,
              column_name TEXT
            );
            CREATE TABLE xlsx_cells_with_provenance (
              name TEXT,
              sheet TEXT,
              row_number INTEGER,
              cell TEXT,
              value TEXT
            );
            """
        )
        rows = []
        for day in range(1, 13):
            metric = -0.99 if day == 1 else -0.10
            if day == 12:
                metric = -0.50
            source_name = (
                "mosquitoes/processed/"
                f"_2026_04_{day:02d}_12_00_00_Chem_mov_results/"
                f"_2026_04_{day:02d}_12_00_00_Chem_mov_results/results_by_time.csv"
            )
            rows.append(
                (
                    source_name,
                    day,
                    (
                        "{"
                        '"time_bin":"2",'
                        '"time_start_min":"2.0",'
                        '"time_mid_min":"2.5",'
                        '"time_end_min":"3.0",'
                        '"n_frames":"180",'
                        f'"T1_total":"1000","T1_trt_PI":"{metric}"'
                        "}"
                    ),
                    f'{{"locator":"{source_name}#row={day}"}}',
                )
            )
        conn.executemany(
            """
            INSERT INTO csv_rows_with_provenance
            (name, row_number, row_json, provenance_grain)
            VALUES (?, ?, ?, ?)
            """,
            rows,
        )
        conn.executemany(
            """
            INSERT INTO csv_columns_with_provenance
            (name, column_name)
            VALUES (?, 'time_bin')
            """,
            [(row[0],) for row in rows],
        )

        payload = routing_decision.query_payload_for_question(
            "what time point in the last 10 dart assays was the most repellent",
            "auto",
            limit=20,
        )
        result_rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_individual_assay_timepoint_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "individual_assay_timepoint_ranking")
        self.assertEqual(result_rows[0]["ranking_status"], "ranked")
        self.assertEqual(result_rows[0]["source_row_number"], 12)
        self.assertEqual(result_rows[0]["metric_value"], -0.50)
        self.assertEqual(result_rows[0]["effect_score"], 0.50)
        self.assertEqual(result_rows[0]["treatment_label"], "Chem")
        self.assertEqual(result_rows[0]["recent_assay_files"], 10)
        self.assertEqual(result_rows[0]["time_window"], "2.0-3.0 min")

    def test_contact_recent_timepoint_ranking_sql_uses_frame_metrics(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE csv_rows_with_provenance (
              name TEXT,
              row_number INTEGER,
              row_json TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE csv_columns_with_provenance (
              name TEXT,
              column_name TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE objects (
              name TEXT,
              updated TEXT,
              time_created TEXT
            );
            """
        )
        source_name = "contact_repel_videos/mosquitoes_new_solvent/processed/IMG_0109_Contact_Menthol/frame_metrics.csv"
        older_source = "contact_repel_videos/mosquitoes_new_solvent/processed/IMG_0001_Contact_Older/frame_metrics.csv"
        conn.executemany(
            """
            INSERT INTO csv_columns_with_provenance
            (name, column_name, provenance_grain)
            VALUES (?, 'time_sec', '{}')
            """,
            [(source_name,), (older_source,)],
        )
        conn.executemany(
            """
            INSERT INTO objects (name, updated, time_created)
            VALUES (?, ?, ?)
            """,
            [
                (source_name, "2026-05-09T05:56:01Z", "2026-05-09T05:56:01Z"),
                (older_source, "2026-05-01T05:56:01Z", "2026-05-01T05:56:01Z"),
            ],
        )
        conn.executemany(
            """
            INSERT INTO csv_rows_with_provenance
            (name, row_number, row_json, provenance_grain)
            VALUES (?, ?, ?, ?)
            """,
            [
                (
                    source_name,
                    1,
                    '{"frame_idx":"10","time_sec":"3.0","n_total":"8","contact_pi":"0.25"}',
                    f'{{"locator":"{source_name}#row=1"}}',
                ),
                (
                    source_name,
                    2,
                    '{"frame_idx":"20","time_sec":"6.0","n_total":"9","contact_pi":"0.90"}',
                    f'{{"locator":"{source_name}#row=2"}}',
                ),
                (
                    older_source,
                    1,
                    '{"frame_idx":"10","time_sec":"3.0","n_total":"7","contact_pi":"1.00"}',
                    f'{{"locator":"{older_source}#row=1"}}',
                ),
            ],
        )

        payload = routing_decision.query_payload_for_question(
            "what time point in contact assays for mosquitoes on 2026-05-09 was the most repellent",
            "auto",
            limit=20,
        )
        result_rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_individual_assay_timepoint_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "individual_assay_timepoint_ranking")
        self.assertEqual(result_rows[0]["ranking_status"], "ranked")
        self.assertEqual(result_rows[0]["assay_family"], "contact/no-contact")
        self.assertEqual(result_rows[0]["species"], "mosquitoes")
        self.assertEqual(result_rows[0]["assay_mode"], "contact")
        self.assertEqual(result_rows[0]["treatment_label"], "Menthol")
        self.assertEqual(result_rows[0]["source_row_number"], 2)
        self.assertEqual(result_rows[0]["metric_value"], 0.90)
        self.assertEqual(result_rows[0]["time_window"], "6.0 sec")

    def test_cross_assay_repellent_ranking_sql_runs_on_minimal_fixture(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE assay_runs (
              run_id TEXT PRIMARY KEY,
              run_date TEXT,
              species TEXT,
              assay_family TEXT,
              assay_type TEXT,
              assay_mode TEXT,
              filename TEXT,
              tube TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              dilution TEXT,
              temp TEXT,
              rh TEXT,
              source_gap_reason TEXT
            );
            CREATE TABLE assay_results (
              result_id TEXT PRIMARY KEY,
              run_id TEXT,
              source_table TEXT,
              source_name TEXT,
              row_number INTEGER,
              species TEXT,
              assay_family TEXT,
              assay_mode TEXT,
              compound TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              dilution TEXT,
              metric_name TEXT,
              metric_value REAL,
              ranking_score REAL,
              metric_direction TEXT,
              result_role TEXT,
              timepoint TEXT,
              usable_data TEXT,
              provenance_grain TEXT
            );
            """
        )
        conn.executemany(
            """
            INSERT INTO assay_runs
            (run_id, run_date, species, assay_family, assay_type, assay_mode, filename, tube, treatment, treatment_normalized, dilution, temp, rh, source_gap_reason)
            VALUES (?, '2026-05-01', ?, ?, ?, ?, ?, ?, ?, ?, '0.01', NULL, NULL, NULL)
            """,
            [
                ("fly-run-1", "flies", "DART", "DART aggregate ranking", "DART", "fly.csv", None, "PEPO", "PEPO"),
                ("mosq-run-1", "mosquitoes", "DART", "DART aggregate ranking", "DART", "mosq.csv", None, "2PP", "2PP"),
            ],
        )
        conn.executemany(
            """
            INSERT INTO assay_results
            (result_id, run_id, source_table, source_name, row_number, species, assay_family, assay_mode, compound, treatment, treatment_normalized, dilution, metric_name, metric_value, ranking_score, metric_direction, result_role, timepoint, usable_data, provenance_grain)
            VALUES (?, ?, 'csv_rows', ?, ?, ?, 'DART', 'DART', ?, ?, ?, '0.01', ?, ?, ?, ?, 'primary', NULL, '1', ?)
            """,
            [
                ("fly-result-1", "fly-run-1", "flies/summary/agg_summary/top_performing_chemicals.csv", 1, "flies", "PEPO", "PEPO", "PEPO", "composite_score", 0.91, 0.91, "higher_is_more_repellent", '{"locator":"fly#1"}'),
                ("mosq-result-1", "mosq-run-1", "mosquitoes/summary/agg_summary/top_performing_chemicals.csv", 1, "mosquitoes", "2PP", "2PP", "2PP", "composite_score", 0.80, 0.80, "higher_is_more_repellent", '{"locator":"dart#1"}'),
            ],
        )

        payload = routing_decision.query_payload_for_question(
            "what are the top repellent compounds",
            "auto",
            limit=10,
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual([row["species"] for row in rows], ["flies", "mosquitoes"])
        self.assertEqual(rows[0]["compound"], "PEPO")
        self.assertEqual(rows[0]["metric_name"], "composite_score")
        self.assertEqual(rows[1]["compound"], "2PP")
        self.assertEqual(rows[1]["metric_name"], "composite_score")
        self.assertTrue(all(row["provenance_grain"] for row in rows))

    def test_cross_assay_repellent_ranking_sql_passes_http_read_only_guard(self):
        import routing_decision
        import serve_http

        payload = routing_decision.query_payload_for_question(
            "what are the top repellent compounds",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(serve_http.ensure_read_only_sql(payload["sql"]), payload["sql"].strip())

    def test_fly_result_video_bridge_routes_top_repellent_video_question(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "pull up the top 2 repellent compounds and the videos associated",
            "auto",
            limit=2,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_fly_result_video_bridge_sql")
        self.assertEqual(payload["routing_decision"]["adapter_execution"], "sql")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertIn("top_performing_chemicals.csv", payload["sql"])
        self.assertIn("standard_deviation_status", payload["sql"])

    def test_fly_result_video_bridge_routes_exact_treatment_video_question(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "show fly video for 1O3OL",
            "auto",
            limit=3,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_fly_result_video_bridge_sql")
        self.assertIn("treatment_key = lower('1O3OL')", payload["sql"])

    def test_fly_result_video_bridge_routes_exact_treatment_video_question_with_bucket_source(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "show fly video for 1O3OL",
            "bucket",
            limit=3,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_fly_result_video_bridge_sql")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertIn("treatment_key = lower('1O3OL')", payload["sql"])

    def test_fly_result_video_bridge_sql_runs_on_minimal_fixture(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE csv_rows_with_provenance (name TEXT, row_number INTEGER, row_json TEXT, provenance_grain TEXT);
            CREATE TABLE objects (name TEXT, uri TEXT, kind TEXT, updated TEXT, time_created TEXT);
            """
        )
        conn.execute(
            """
            INSERT INTO csv_rows_with_provenance VALUES
            ('flies/summary/agg_summary/top_performing_chemicals.csv', 1,
             '{"treatment_label":"2PP (20)","direction":"repellent","composite_score":"0.93","trt_pi_grand_mean":"-0.61","n_replicates":"8"}',
             '{"grain_type":"csv_row","locator":"fly#row=1"}')
            """
        )
        conn.execute(
            """
            INSERT INTO objects VALUES
            ('contact_repel_videos/flies/2PP/2PP_non_contact.MOV', 'gs://monarch-videos-new/contact_repel_videos/flies/2PP/2PP_non_contact.MOV', 'video', '2026-02-05T12:00:00Z', '2026-02-05T12:00:00Z')
            """
        )

        payload = routing_decision.query_payload_for_question(
            "pull up the top 2 repellent compounds and the videos associated",
            "auto",
            limit=2,
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual(rows[0]["treatment_label"], "2PP (20)")
        self.assertEqual(rows[0]["treatment_normalized"], "2pp")
        self.assertEqual(rows[0]["media_uri"], "gs://monarch-videos-new/contact_repel_videos/flies/2PP/2PP_non_contact.MOV")
        self.assertEqual(rows[0]["standard_deviation_status"], "source_gap: fly media bridge does not carry replicate-level standard deviation")
        self.assertIn("gs://monarch-videos-new/flies/summary/agg_summary/top_performing_chemicals.csv#row=1", rows[0]["provenance_grain"])
        self.assertIn("fly_result_video_bridge", rows[0]["provenance_grain"])

    def test_recent_no_contact_trace_exposes_registered_evidence_shape(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "show me a recent no contact video",
            "auto",
        )

        self.assertEqual(route["adapter"], "bucket_recent_media_by_mode_sql")
        self.assertEqual(route["evidence_shape"], "assay_media_evidence")
        self.assertEqual(route["expected_grain_type"], "bucket_object")

    def test_assay_quality_report_routes_processed_warning_questions(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "which processed runs have warnings",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_quality_report_sql")
        self.assertEqual(payload["routing_decision"]["evidence_shape"], "assay_quality_report")
        self.assertIn("text_lines_with_provenance", payload["sql"])
        self.assertIn("accuracy", payload["sql"].lower())

    def test_insect_image_taxonomy_routes_to_bucket_not_inventory(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "do we have diamondback moth images",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_insect_image_taxonomy_inventory_sql")
        self.assertEqual(payload["routing_decision"]["evidence_shape"], "insect_image_taxonomy_inventory")
        self.assertIn("objects", payload["sql"])
        self.assertNotEqual(payload["source"], "compound_inventory")

    def test_insect_image_taxonomy_sql_forces_name_index(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "do we have diamondback moth images",
            "auto",
            limit=10,
        )

        self.assertIn("objects INDEXED BY sqlite_autoindex_objects_1", payload["sql"])
        self.assertIn("name >= 'insect-images/Lepidoptera/Lepidoptera/Plutellidae/'", payload["sql"])

    def test_fly_trial_metadata_join_routes_solvent_and_abbreviation_questions(self):
        import routing_decision

        for question in [
            "what solvent was used in the fly trials",
            "what does 1O3OL mean in the fly metadata",
            "which side was treatment in fly trial 2026-02-05 12-52-51",
        ]:
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(question, "auto", limit=10)
                self.assertEqual(payload["source"], "bucket")
                self.assertEqual(payload["routing_decision"]["adapter"], "bucket_fly_trial_metadata_join_sql")
                self.assertEqual(payload["routing_decision"]["evidence_shape"], "fly_trial_metadata_join")
                self.assertIn("flies/repellency_screen_metadata_sheet.xlsx", payload["sql"])
                self.assertIn("GROUP BY name, sheet, row_number", payload["sql"])
                self.assertNotIn("LEFT JOIN xlsx_cells_with_provenance filename", payload["sql"])

    def test_phytotox_summary_routes_to_named_evidence_shape(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "which treatments look safe on plants",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_phytotox_experiment_summary_sql")
        self.assertEqual(payload["routing_decision"]["evidence_shape"], "phytotox_experiment_summary")
        self.assertIn("phytotoxicity/results", payload["sql"])

    def test_phytotox_metric_questions_route_to_reference_guide_before_result_schema(self):
        import routing_decision

        for question in [
            "list the phytotoxicity metrics",
            "what are the phytotoxicity metrics",
            "what does NGRDI mean for phytotoxicity",
            "explain phytotoxicity thresholds",
        ]:
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(
                    question,
                    "auto",
                    limit=20,
                )

                self.assertEqual(payload["source"], "bucket")
                self.assertEqual(payload["routing_decision"]["answer_shape"], "metric_definition")
                self.assertEqual(payload["routing_decision"]["adapter"], "bucket_phytotox_metric_reference_sql")
                self.assertEqual(payload["routing_decision"]["selection_policy"], "answer_shape_first")
                self.assertIn("phytotoxicity_metrics_reference_guide.pdf", payload["sql"])
                self.assertIn("features_all.csv", payload["sql"])
                self.assertIn("features_baseline_corrected.csv", payload["sql"])
                self.assertIn("ranked_features.csv", payload["sql"])
                self.assertNotIn("ORDER BY damaged_fraction DESC", payload["sql"])

    def test_short_assay_metric_definition_questions_route_to_reference_guides(self):
        import routing_decision

        cases = {
            "what is PI": "documentation/insect_assay_metrics_reference.pdf",
            "what does PI mean": "documentation/insect_assay_metrics_reference.pdf",
            "what is adj_contact_pi": "documentation/contact_repellency_assay_detection_and_analysis_reference.pdf",
            "what is frac_time_avoiding": "documentation/contact_repellency_assay_detection_and_analysis_reference.pdf",
        }
        for question, expected_doc in cases.items():
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(
                    question,
                    "auto",
                    limit=5,
                )

                self.assertEqual(payload["source"], "bucket")
                self.assertEqual(payload["routing_decision"]["answer_shape"], "metric_definition")
                self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_metric_reference_sql")
                self.assertEqual(payload["routing_decision"]["selection_policy"], "answer_shape_first")
                self.assertIn("pdf_pages", payload["sql"])
                self.assertIn(expected_doc, payload["sql"])
                self.assertNotIn("bucket_structured_anchor_probe_sql", payload["routing_decision"]["adapter"])

    def test_phytotox_inventory_ranking_uses_answer_shape_before_inventory_keyword(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "list the most phytotoxic compounds in our inventory from 1-5",
            "auto",
        )

        self.assertEqual(route["intent"], "phytotox_inventory_ranking")
        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["adapter"], "bucket_phytotox_inventory_ranking_plan")
        self.assertEqual(route["adapter_execution"], "route_plan")
        self.assertEqual(route["answer_shape"], "ranked_compounds_with_inventory_status")
        self.assertEqual(route["rank_direction"], "most")
        self.assertEqual(route["limit"], 5)
        self.assertEqual(route["fallback_policy"], "fail_on_missing_structured_step")
        self.assertEqual(route["route_plan"][0]["source_lane"], "bucket")
        self.assertEqual(route["route_plan"][0]["adapter"], "bucket_phytotox_rank_compounds_sql")
        self.assertEqual(route["route_plan"][1]["source_lane"], "compound_inventory")
        self.assertEqual(route["route_plan"][1]["adapter"], "compound_inventory_all_names_sql")

    def test_weak_one_word_inventory_alias_does_not_match_rich_phytotox_question(self):
        import routing_decision

        match = routing_decision.semantic_adapter_match(
            "list the most phytotoxic compounds in our inventory from 1-5",
            "compound_inventory",
        )

        self.assertIsNone(match)

    def test_assay_video_routes_to_mixed_media_proof(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "show me the assay video for this result",
            "bucket",
        )

        self.assertEqual(route["intent"], "media_proof")
        self.assertEqual(route["source_lane"], "bucket")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["adapter"], "bucket_assay_media_links")

    def test_assay_video_claim_routes_to_candidate_media_sql(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "show me the assay video that shows Avinash reported a strong mosquito contact effect with good PI contrast",
            "auto",
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("assay_media_links", payload["sql"])
        self.assertIn("dart_assay_results", payload["sql"])
        self.assertEqual(payload["routing_decision"]["intent"], "assay_media_candidates")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_media_candidates_sql")

    def test_inventory_to_assay_question_gets_ordered_route_plan(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what are assay results from the last 10 chemicals ordered in inventory?",
            "auto",
        )

        self.assertEqual(route["intent"], "inventory_to_assay_results")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["fallback_policy"], "fail_on_missing_structured_step")
        self.assertEqual(route["route_plan"][0]["source_lane"], "compound_inventory")
        self.assertEqual(route["route_plan"][0]["adapter"], "compound_inventory_latest_ordered_compounds")
        self.assertEqual(route["route_plan"][1]["source_lane"], "bucket")
        self.assertEqual(route["route_plan"][1]["adapter"], "bucket_assay_results_by_compound_list")

    def test_inventory_sample_with_assay_gets_route_plan(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "list 10 compounds in our inventory and 1 assay that used 1 of them",
            "auto",
        )

        self.assertEqual(route["intent"], "inventory_sample_with_assay")
        self.assertEqual(route["retrieval_shape"], "mixed")
        self.assertEqual(route["adapter_execution"], "route_plan")
        self.assertEqual(route["route_plan"][0]["source_lane"], "compound_inventory")
        self.assertEqual(route["route_plan"][1]["source_lane"], "bucket")

    def test_existing_inventory_semantically_routes_to_inventory_summary_adapter(self):
        import routing_decision

        cases = [
            "what is the existing inventory?",
            "what inventory do we have?",
            "show inventory by storage location",
        ]

        for question in cases:
            with self.subTest(question=question):
                route = routing_decision.route_decision_for_question(question, "auto")

                self.assertEqual(route["intent"], "compound_inventory_summary")
                self.assertEqual(route["source_lane"], "compound_inventory")
                self.assertEqual(route["retrieval_shape"], "structured")
                self.assertEqual(route["adapter"], "compound_inventory_summary_sql")
                self.assertEqual(route["adapter_execution"], "sql")
                self.assertEqual(route["semantic_adapter_match"]["adapter"], "compound_inventory_summary_sql")
                self.assertGreaterEqual(route["semantic_adapter_match"]["confidence"], 0.5)

    def test_current_inventory_chemical_lists_route_to_compound_list_adapter(self):
        import routing_decision

        cases = [
            "what chemicals are in stock?",
            "what is in the Monarch chemical library?",
            "list current inventory of chemicals",
        ]

        for question in cases:
            with self.subTest(question=question):
                route = routing_decision.route_decision_for_question(question, "auto")

                self.assertEqual(route["intent"], "compound_inventory_list_or_count")
                self.assertEqual(route["source_lane"], "compound_inventory")
                self.assertEqual(route["retrieval_shape"], "structured")
                self.assertEqual(route["adapter"], "compound_inventory_master_count_sql")
                self.assertEqual(route["adapter_execution"], "sql")

    def test_all_inventory_compounds_route_to_full_name_list_adapter(self):
        import routing_decision

        cases = [
            "list all compounds in our inventory",
            "show every chemical in the inventory",
        ]

        for question in cases:
            with self.subTest(question=question):
                route = routing_decision.route_decision_for_question(question, "auto")

                self.assertEqual(route["intent"], "compound_inventory_all_names")
                self.assertEqual(route["source_lane"], "compound_inventory")
                self.assertEqual(route["retrieval_shape"], "structured")
                self.assertEqual(route["adapter"], "compound_inventory_all_names_sql")
                self.assertEqual(route["adapter_execution"], "sql")
                self.assertEqual(route["fallback_policy"], "no_silent_prose_fallback")

    def test_all_inventory_compounds_payload_uses_one_structured_sql_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list all compounds in our inventory",
            "auto",
        )

        self.assertEqual(payload["source"], "compound_inventory")
        self.assertIn("sql", payload)
        self.assertNotIn("source_gap", payload)
        self.assertIn("compound_name", payload["sql"])
        self.assertIn("vendor", payload["sql"])
        self.assertIn("catalog_number", payload["sql"])
        self.assertIn("row_number", payload["sql"])
        self.assertIn("provenance_grain", payload["sql"])
        self.assertNotIn("compounds_json", payload["sql"])
        self.assertNotIn("first_50_compounds", payload["sql"])
        self.assertGreaterEqual(payload["limit"], 1000)
        self.assertEqual(payload["routing_decision"]["adapter"], "compound_inventory_all_names_sql")

    def test_inventory_entity_questions_route_to_master_row_lookup(self):
        import routing_decision

        cases = [
            "where do we store DEET?",
            "who is the vendor for DEET?",
            "what is the CAS for DEET?",
        ]

        for question in cases:
            with self.subTest(question=question):
                route = routing_decision.route_decision_for_question(question, "auto")

                self.assertEqual(route["source_lane"], "compound_inventory")
                self.assertEqual(route["retrieval_shape"], "structured")
                self.assertEqual(route["adapter"], "compound_inventory_master_row_lookup")

    def test_auto_source_routes_people_variants_to_people_directory(self):
        import routing_decision

        cases = [
            "who advises Monarch?",
            "who are the founders?",
        ]

        for question in cases:
            with self.subTest(question=question):
                route = routing_decision.route_decision_for_question(question, "auto")

                self.assertEqual(route["source_lane"], "people_directory")
                self.assertEqual(route["retrieval_shape"], "structured")
                self.assertIn(route["adapter"], {
                    "people_directory_advisor_roster_sql",
                    "people_directory_employee_roster_sql",
                })

    def test_auto_source_routes_company_scientific_milestone_variants(self):
        import routing_decision

        cases = {
            "where is Monarch based?": ("company_profile", "company_profile_unit_lookup_sql"),
            "what insects does Monarch work on?": ("company_profile", "company_profile_unit_lookup_sql"),
            "what does the literature say about odorant receptors?": ("scientific_refs", "scientific_refs_source_text_retrieval"),
            "what milestones mention phytotoxicity?": ("milestones_doc", "milestones_doc_source_text_retrieval"),
            "what does Monarch say about secure storage bucket results upload?": ("milestones_doc", "milestones_doc_source_text_retrieval"),
            "what is the strongest mosquito treatment?": ("bucket", "bucket_top_repellents_by_species_sql"),
        }

        for question, (source, adapter) in cases.items():
            with self.subTest(question=question):
                route = routing_decision.route_decision_for_question(question, "auto")

                self.assertEqual(route["source_lane"], source)
                self.assertEqual(route["adapter"], adapter)

    def test_bucket_experiment_listing_routes_to_structured_adapter(self):
        import routing_decision

        cases = [
            "list the experiments from last week",
            "what experiments were uploaded today?",
            "what new assay runs are in the bucket?",
        ]

        for question in cases:
            with self.subTest(question=question):
                route = routing_decision.route_decision_for_question(question, "auto")

                self.assertEqual(route["intent"], "experiment_listing")
                self.assertEqual(route["source_lane"], "bucket")
                self.assertEqual(route["retrieval_shape"], "structured")
                self.assertEqual(route["adapter"], "bucket_experiment_listing_sql")
                self.assertEqual(route["adapter_execution"], "sql")

    def test_bucket_experiment_listing_payload_uses_sql(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list the experiments from last week",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertNotIn("source_gap", payload)
        self.assertIn("experiment_key", payload["sql"])
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_experiment_listing_sql")

    def test_run_date_experiment_questions_route_to_assay_ledger(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what DART assays were run last week - list all",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("dart_assay_results", payload["sql"])
        self.assertIn("assay_date", payload["sql"])
        self.assertNotIn("objects", payload["sql"])
        self.assertEqual(payload["routing_decision"]["intent"], "experiments_by_run_date")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_experiments_by_run_date_sql")

    def test_broad_assay_run_questions_route_to_cross_assay_inventory(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list the assays we ran last week",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("date(r.run_date)", payload["sql"])
        self.assertEqual(payload["routing_decision"]["intent"], "assay_serving_table")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["evidence_shape"], "assay_serving_table")

    def test_team_fly_assay_count_routes_to_metadata_count_not_dart(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "how many total assays have we run on flies",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("r.species = 'flies'", payload["sql"])
        self.assertNotIn(";", payload["sql"].rstrip(";"))
        self.assertNotEqual(payload["routing_decision"]["adapter"], "bucket_dart_assay_results_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "fly_assay_count")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")

    def test_team_recent_fly_dart_assays_route_to_fly_metadata_listing(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list the most recent fly dart assays",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("recency_order", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertNotIn("rank", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("r.species = 'flies'", payload["sql"])
        self.assertIn("r.assay_family IN ('DART')", payload["sql"])
        self.assertNotEqual(payload["routing_decision"]["adapter"], "bucket_fly_repellency_rankings_sql")

    def test_species_specific_beetle_assay_listing_routes_to_dart_ledger_rows(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list all the beetle assays",
            "auto",
            limit=50,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertEqual(payload["routing_decision"]["intent"], "assay_serving_table")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertEqual(payload["routing_decision"]["selection_policy"], "answer_shape_first")
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("r.species = 'beetles'", payload["sql"])
        self.assertIn("source_name", payload["sql"])
        self.assertIn("row_number", payload["sql"])
        self.assertIn("provenance_grain", payload["sql"])
        self.assertNotIn("source_search", payload["sql"])
        self.assertNotEqual(payload["routing_decision"]["adapter"], "bucket_experiments_by_organism_sql")

    def test_team_run_wording_routes_to_bucket_assay_inventory_not_people(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what assays did the team run yesterday",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertNotEqual(payload["routing_decision"]["source_lane"], "people_directory")

    def test_do_we_have_diamondback_moth_assays_routes_to_assay_serving_table(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "do we have diamondback moth assays",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("r.species = 'moths'", payload["sql"])
        self.assertNotEqual(payload["source"], "compound_inventory")

    def test_oviposition_assay_listing_scopes_fly_and_moth_oviposition(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list oviposition assays",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("'fly_oviposition'", payload["sql"])
        self.assertIn("'moth_oviposition'", payload["sql"])

    def test_oviposition_data_listing_uses_assay_serving_table_not_fly_metadata(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list all fly oviposition data",
            "auto",
            limit=100,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("r.species = 'flies'", payload["sql"])
        self.assertIn("'fly_oviposition'", payload["sql"])
        self.assertNotIn("flies/repellency_screen_metadata_sheet.xlsx", payload["sql"])

    def test_family_data_listing_generalizes_to_oviposition_without_species(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list all oviposition data",
            "auto",
            limit=100,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("'fly_oviposition'", payload["sql"])
        self.assertIn("'moth_oviposition'", payload["sql"])

    def test_oviposition_assays_with_results_join_assay_results_not_inventory_count(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE assay_runs (
              run_id TEXT PRIMARY KEY,
              run_date TEXT,
              species TEXT,
              assay_family TEXT,
              assay_type TEXT,
              assay_mode TEXT,
              filename TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              source_name TEXT,
              row_number INTEGER
            );
            CREATE TABLE assay_results (
              result_id TEXT PRIMARY KEY,
              run_id TEXT,
              species TEXT,
              assay_family TEXT,
              assay_mode TEXT,
              compound TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              metric_name TEXT,
              metric_value REAL,
              ranking_score REAL,
              metric_direction TEXT,
              result_role TEXT,
              timepoint TEXT,
              usable_data TEXT,
              source_name TEXT,
              row_number INTEGER,
              provenance_grain TEXT
            );
            """
        )
        conn.execute(
            """
            INSERT INTO assay_runs
            (run_id, run_date, species, assay_family, assay_type, assay_mode, filename, treatment, treatment_normalized, source_name, row_number)
            VALUES ('fly-ovi-1', '2026-05-12', 'flies', 'fly_oviposition', 'oviposition method development', 'oviposition', 'image.png', 'agar', 'agar', 'fly_oviposition_metadata.xlsx', 2)
            """
        )
        conn.execute(
            """
            INSERT INTO assay_results
            (result_id, run_id, species, assay_family, assay_mode, compound, treatment, treatment_normalized, metric_name, metric_value, ranking_score, metric_direction, result_role, timepoint, usable_data, source_name, row_number, provenance_grain)
            VALUES ('result-1', 'fly-ovi-1', 'flies', 'fly_oviposition', 'oviposition', 'agar', 'agar', 'agar', 'pi', 0.42, 0.42, 'higher_is_more_oviposition', 'primary', NULL, '1', 'fly_oviposition_metadata.xlsx', 2, '{"locator":"row=2"}')
            """
        )

        payload = routing_decision.query_payload_for_question(
            "list the oviposition assays we've ran and the results",
            "auto",
            limit=50,
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_result_list")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("LEFT JOIN assay_runs a", payload["sql"])
        self.assertIn("'fly_oviposition'", payload["sql"])
        self.assertIn("'moth_oviposition'", payload["sql"])
        self.assertNotIn("GROUP BY r.species", payload["sql"])
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["species"], "flies")
        self.assertEqual(rows[0]["assay_family"], "fly_oviposition")
        self.assertEqual(rows[0]["metric_name"], "pi")
        self.assertAlmostEqual(rows[0]["metric_value"], 0.42)

    def test_insects_run_assays_with_uses_cross_assay_serving_table_not_company_profile(self):
        import routing_decision

        for question in [
            "list the insects we've run assays with",
            "what insects have we run assays with",
        ]:
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(question, "auto", limit=50)

                self.assertEqual(payload["source"], "bucket")
                self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_inventory_count")
                self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
                self.assertIn("FROM assay_runs r", payload["sql"])
                self.assertIn("GROUP BY r.species", payload["sql"])
                self.assertIn("r.species != 'plants'", payload["sql"])
                self.assertNotEqual(payload["source"], "company_profile")

    def test_broad_assay_inventory_questions_do_not_default_to_dart_run_dates(self):
        import routing_decision

        for question in [
            "what did we test",
            "what assays have we run",
            "list assays we ran",
        ]:
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(question, "auto", limit=50)

                self.assertEqual(payload["source"], "bucket")
                self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_inventory_count")
                self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
                self.assertIn("FROM assay_runs r", payload["sql"])
                self.assertNotEqual(payload["routing_decision"]["adapter"], "bucket_experiments_by_run_date_sql")
                self.assertNotIn("FROM dart_assay_results", payload["sql"])

    def test_compounds_tested_questions_use_all_assay_test_events_not_teams_prose(self):
        import routing_decision

        for question, answer_shape in [
            ("what compounds did we test", "tested_compound_list"),
            ("what compounds did we test last week", "tested_compound_date_window"),
        ]:
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(question, "auto", limit=50)

                self.assertEqual(payload["source"], "bucket")
                self.assertEqual(payload["routing_decision"]["answer_shape"], answer_shape)
                self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
                self.assertIn("FROM compound_test_events e", payload["sql"])
                self.assertNotEqual(payload["source"], "teams_recaps")

    def test_compounds_tested_question_tolerates_mosquito_typo_species_filter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what list all the compounds we tested on mosquiotes int the last 14 days",
            "auto",
            limit=50,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "tested_compound_date_window")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("FROM compound_test_events e", payload["sql"])
        self.assertIn("e.species = 'mosquitoes'", payload["sql"])
        self.assertNotIn("e.species = 'plants'", payload["sql"])

    def test_team_run_yesterday_includes_unledgered_fly_contact_media(self):
        import routing_decision

        target_date = routing_decision._local_today() - timedelta(days=1)

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE assay_runs (
              run_id TEXT PRIMARY KEY,
              source_table TEXT,
              source_name TEXT,
              sheet TEXT,
              row_number INTEGER,
              species TEXT,
              assay_family TEXT,
              assay_type TEXT,
              assay_mode TEXT,
              run_date TEXT,
              filename TEXT,
              tube TEXT,
              slot TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              dilution TEXT,
              dilution_real REAL,
              solvent TEXT,
              left_condition TEXT,
              right_condition TEXT,
              treatment_position TEXT,
              n_subjects TEXT,
              n_subjects_real REAL,
              temp TEXT,
              rh TEXT,
              usable_data TEXT,
              source_gap_reason TEXT,
              provenance_grain TEXT
            );
            """
        )
        conn.executemany(
            """
            INSERT INTO assay_runs
            (run_id, source_table, source_name, sheet, row_number, species, assay_family, assay_type, assay_mode, run_date, filename, tube, slot, treatment, treatment_normalized, dilution, dilution_real, solvent, left_condition, right_condition, treatment_position, n_subjects, n_subjects_real, temp, rh, usable_data, source_gap_reason, provenance_grain)
            VALUES (?, 'assay_runs', ?, NULL, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, ?)
            """,
            [
                ("beetle-1", "fixture", 6, "beetles", "DART", "DART", "DART", target_date.isoformat(), "heat.mov", "Heat", "Heat", '{"locator":"beetle"}'),
                ("fly-1", "fixture", 1, "flies", "contact_no_contact", "contact/no-contact", "control", target_date.isoformat(), "IMG_0112_Control_1O3OL.mov", "1O3OL", "1O3OL", '{"locator":"fly1"}'),
                ("fly-2", "fixture", 2, "flies", "contact_no_contact", "contact/no-contact", "non_contact", target_date.isoformat(), "IMG_0113_NonContact_1O3OL.mov", "1O3OL", "1O3OL", '{"locator":"fly2"}'),
                ("fly-3", "fixture", 3, "flies", "contact_no_contact", "contact/no-contact", "contact", target_date.isoformat(), "IMG_0115_Contact_1O3OL.mov", "1O3OL", "1O3OL", '{"locator":"fly3"}'),
                ("fly-4", "fixture", 4, "flies", "contact_no_contact", "contact/no-contact", "control", target_date.isoformat(), "IMG_0116_Control_PepOil.mov", "PepOil", "PepOil", '{"locator":"fly4"}'),
                ("fly-5", "fixture", 5, "flies", "contact_no_contact", "contact/no-contact", "non_contact", target_date.isoformat(), "IMG_0117_NonContact_PepOil.mov", "PepOil", "PepOil", '{"locator":"fly5"}'),
                ("fly-6", "fixture", 6, "flies", "contact_no_contact", "contact/no-contact", "contact", target_date.isoformat(), "IMG_0118_Contact_PepOil.mov", "PepOil", "PepOil", '{"locator":"fly6"}'),
            ],
        )

        payload = routing_decision.query_payload_for_question(
            "what assays did the team run yesterday",
            "auto",
            limit=20,
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(len(rows), 7)
        self.assertIn(("DART", "beetles"), {(row["assay_family"], row["species"]) for row in rows})
        self.assertIn(("contact_no_contact", "flies"), {(row["assay_family"], row["species"]) for row in rows})
        self.assertEqual(
            {row["treatment_normalized"] for row in rows if row["species"] == "flies"},
            {"1O3OL", "PepOil"},
        )
        self.assertTrue(all(row["provenance_grain"] for row in rows))

    def test_team_best_result_environment_routes_to_species_join_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what is the temp and humidity at which we found the most promising results in our assays",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("LEFT JOIN assay_runs a", payload["sql"])
        self.assertIn("source_gap_reason", payload["sql"])
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_best_result_environment_conditions")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")

    def test_mosquito_repellency_ideal_temp_routes_to_environment_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what temp seems to be ideal for mosquito repellency",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_best_result_environment_conditions")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("temperature", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("r.species = 'mosquitoes'", payload["sql"])
        self.assertIn("ranking_score", payload["sql"])
        self.assertNotEqual(payload["routing_decision"]["adapter"], "bucket_top_repellents_by_species_sql")

    def test_environment_conditions_cover_all_assay_families_and_gaps(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what temp seems ideal across all assays",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_best_result_environment_conditions")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("LEFT JOIN assay_runs a", payload["sql"])
        self.assertIn("source_gap_reason", payload["sql"])

    def test_contact_noncontact_environment_question_routes_to_gap_aware_environment_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what temp seems ideal for contact / no contact repellency",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_best_result_environment_conditions")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("r.assay_family IN ('contact_no_contact')", payload["sql"])
        self.assertIn("source_gap_reason", payload["sql"])
        self.assertNotEqual(payload["routing_decision"]["adapter"], "bucket_contact_noncontact_adjusted_pi_comparison_sql")

    def test_phytotoxicity_environment_question_routes_to_phytotox_join(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what temp seems ideal for phytotoxicity",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_best_result_environment_conditions")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("r.assay_family IN ('phytotoxicity')", payload["sql"])
        self.assertIn("damaged_fraction", payload["sql"])

    def test_team_contact_noncontact_comparison_routes_to_adjusted_summary(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "compare contact and non-contact repellents against each other",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("adj_contact_pi_mean", payload["sql"])
        self.assertIn("r.assay_family = 'contact_no_contact'", payload["sql"])
        self.assertEqual(payload["routing_decision"]["answer_shape"], "contact_noncontact_ranked_comparison")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")

    def test_contact_noncontact_serving_table_prefers_adjusted_pi_when_available(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE assay_runs (
              run_id TEXT PRIMARY KEY,
              run_date TEXT,
              species TEXT,
              assay_family TEXT,
              assay_type TEXT,
              assay_mode TEXT,
              filename TEXT,
              tube TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              dilution TEXT,
              temp TEXT,
              rh TEXT,
              source_gap_reason TEXT
            );
            CREATE TABLE assay_results (
              result_id TEXT PRIMARY KEY,
              run_id TEXT,
              source_table TEXT,
              source_name TEXT,
              row_number INTEGER,
              species TEXT,
              assay_family TEXT,
              assay_mode TEXT,
              compound TEXT,
              treatment TEXT,
              treatment_normalized TEXT,
              dilution TEXT,
              metric_name TEXT,
              metric_value REAL,
              ranking_score REAL,
              metric_direction TEXT,
              result_role TEXT,
              timepoint TEXT,
              usable_data TEXT,
              provenance_grain TEXT
            );
            """
        )
        conn.executemany(
            """
            INSERT INTO assay_runs
            (run_id, run_date, species, assay_family, assay_type, assay_mode, filename, tube, treatment, treatment_normalized, dilution, temp, rh, source_gap_reason)
            VALUES (?, '2026-05-01', 'mosquitoes', 'contact_no_contact', 'contact/no-contact', ?, ?, NULL, ?, ?, NULL, NULL, NULL, NULL)
            """,
            [
                ("contact-2pp", "contact", "IMG_0030_Contact_2PP.mov", "2PP", "2PP"),
                ("noncontact-2pp", "non_contact", "IMG_0029_NonContact_2PP.mov", "2PP", "2PP"),
                ("fly-contact-deet", "contact", "fly_Contact_DEET.mov", "DEET", "DEET"),
            ],
        )
        conn.executemany(
            """
            INSERT INTO assay_results
            (result_id, run_id, source_table, source_name, row_number, species, assay_family, assay_mode, compound, treatment, treatment_normalized, dilution, metric_name, metric_value, ranking_score, metric_direction, result_role, timepoint, usable_data, provenance_grain)
            VALUES (?, ?, 'csv_rows', 'fixture.csv', ?, ?, 'contact_no_contact', ?, ?, ?, ?, NULL, ?, ?, ?, 'higher_is_more_repellent', 'primary', NULL, '1', ?)
            """,
            [
                ("contact-mean", "contact-2pp", 1, "mosquitoes", "contact", "2PP", "2PP", "2PP", "mean_contact_pi", 0.9, 0.9, '{"locator":"mean"}'),
                ("contact-adj", "contact-2pp", 1, "mosquitoes", "contact", "2PP", "2PP", "2PP", "adj_contact_pi_mean", 0.3, 0.3, '{"locator":"adj"}'),
                ("noncontact-mean", "noncontact-2pp", 2, "mosquitoes", "non_contact", "2PP", "2PP", "2PP", "mean_contact_pi", 0.8, 0.8, '{"locator":"nonmean"}'),
                ("noncontact-adj", "noncontact-2pp", 2, "mosquitoes", "non_contact", "2PP", "2PP", "2PP", "adj_contact_pi_mean", 0.4, 0.4, '{"locator":"nonadj"}'),
                ("fly-contact-mean", "fly-contact-deet", 3, "flies", "contact", "DEET", "DEET", "DEET", "mean_contact_pi", 0.7, 0.7, '{"locator":"flymean"}'),
            ],
        )

        payload = routing_decision.query_payload_for_question(
            "what compound has been the most repellent in contact / no contact for mosquitoes",
            "auto",
            limit=20,
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual({row["metric_name"] for row in rows}, {"adj_contact_pi_mean"})
        self.assertEqual({row["assay_mode"] for row in rows}, {"contact", "non_contact"})
        by_mode = {row["assay_mode"]: row for row in rows}
        self.assertAlmostEqual(by_mode["contact"]["ranking_score"], 0.3)
        self.assertAlmostEqual(by_mode["non_contact"]["ranking_score"], 0.4)

    def test_team_rank_expectation_routes_to_rank_explanation(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "for the contact, DEET should be in the top - why is it not there",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("nearby_rank", payload["sql"])
        self.assertIn("DEET", payload["sql"])
        self.assertEqual(payload["routing_decision"]["answer_shape"], "rank_expectation_explanation")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_rank_expectation_explanation_sql")

    def test_team_adjusted_summary_explanation_routes_to_file_schema_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "explain the newer adjusted summary",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("csv_columns_with_provenance", payload["sql"])
        self.assertIn("objects", payload["sql"])
        self.assertNotIn(";", payload["sql"].rstrip(";"))
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_summary_file_explanation")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_summary_file_explanation_sql")

    def test_cross_assay_inventory_sql_uses_range_for_oviposition_objects(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what assay did we run on 2026-05-08",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("date(r.run_date) = date('2026-05-08')", payload["sql"])

    def test_cross_assay_inventory_sql_uses_month_name_date(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what assays did we run on May 14 2026",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["question_family"], "assays_run_in_window")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("exact_date", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("date(r.run_date) = date('2026-05-14')", payload["sql"])
        self.assertEqual(
            payload["routing_decision"]["extracted_parameters"]["applied_filter"],
            "date(r.run_date) = date('2026-05-14')",
        )

    def test_compounds_tested_date_window_routes_to_structured_bucket_adapter(self):
        import routing_decision

        cases = [
            "list the compounds we have tested in experiments in the last 2 weeks",
            "what chemicals were tested last week?",
            "what compounds were run in experiments last week?",
            "which treatments did we assay over the past couple weeks?",
        ]

        for question in cases:
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(
                    question,
                    "auto",
                    limit=10,
                )

                self.assertEqual(payload["source"], "bucket")
                self.assertIn("sql", payload)
                self.assertIn("FROM compound_test_events e", payload["sql"])
                self.assertIn("e.compound AS tested_compound", payload["sql"])
                self.assertNotIn("FROM objects", payload["sql"])
                self.assertEqual(payload["routing_decision"]["intent"], "assay_serving_table")
                self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")

    def test_compounds_tested_date_window_sql_runs_on_compact_assay_dates(self):
        import routing_decision

        def compact_date(day):
            return f"{day.month}{day.day:02d}{day.year}"

        today = date.today()
        in_window_day = today - timedelta(days=1)
        edge_day = today - timedelta(days=14)
        out_of_window_day = today - timedelta(days=15)

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE compound_test_events (
              event_id TEXT PRIMARY KEY,
              run_id TEXT,
              source_table TEXT NOT NULL,
              source_name TEXT NOT NULL,
              row_number INTEGER,
              species TEXT,
              assay_family TEXT NOT NULL,
              assay_mode TEXT,
              compound TEXT NOT NULL,
              treatment TEXT,
              treatment_normalized TEXT,
              dilution TEXT,
              dilution_real REAL,
              solvent TEXT,
              test_date TEXT,
              control_excluded INTEGER NOT NULL DEFAULT 1,
              provenance_grain TEXT NOT NULL
            );
            CREATE TABLE xlsx_cells_with_provenance (
              name TEXT,
              sheet TEXT,
              cell TEXT,
              row_number INTEGER,
              value TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE csv_rows (
              name TEXT,
              row_number INTEGER,
              row_json TEXT
            );
            CREATE TABLE csv_rows_with_provenance (
              name TEXT,
              row_number INTEGER,
              row_json TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE objects (
              name TEXT,
              updated TEXT
            );
            """
        )
        conn.executemany(
            """
            INSERT INTO compound_test_events
            (event_id, run_id, source_table, source_name, row_number, species, assay_family, assay_mode, compound, treatment, treatment_normalized, dilution, dilution_real, solvent, test_date, control_excluded, provenance_grain)
            VALUES (?, ?, 'dart_assay_results', ?, ?, ?, ?, ?, ?, ?, ?, '0.01', 0.01, NULL, ?, 1, ?)
            """,
            [
                ("event-1", "run-1", "mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx", 1, "mosquitoes", "DART", "DART", "Menthone", "Menthone", "Menthone", in_window_day.isoformat(), '{"locator":"row=1"}'),
                ("event-2", "run-2", "mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx", 2, "mosquitoes", "DART", "DART", "PepOil", "PepOil", "PepOil", edge_day.isoformat(), '{"locator":"row=2"}'),
                ("event-3", "run-3", "mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx", 3, "mosquitoes", "DART", "DART", "OldChem", "OldChem", "OldChem", out_of_window_day.isoformat(), '{"locator":"row=4"}'),
            ],
        )

        payload = routing_decision.query_payload_for_question(
            "list the compounds we have tested in experiments in the last 2 weeks",
            "auto",
            limit=10,
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual([row["tested_compound"] for row in rows], ["Menthone", "PepOil"])
        self.assertEqual(rows[0]["evidence_rows"], 1)
        self.assertEqual(rows[0]["first_test_date"], in_window_day.isoformat())
        self.assertEqual(rows[0]["latest_test_date"], in_window_day.isoformat())
        self.assertEqual(rows[1]["first_test_date"], edge_day.isoformat())
        self.assertEqual(rows[1]["latest_test_date"], edge_day.isoformat())

    def test_bucket_experiment_listing_sql_scopes_to_assay_top_folders(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list the experiments from last week",
            "auto",
            limit=10,
        )

        self.assertIn("top_folder IN", payload["sql"])
        self.assertIn("'mosquitoes'", payload["sql"])
        self.assertIn("'flies'", payload["sql"])
        self.assertIn("'phytotoxicity'", payload["sql"])
        self.assertIn("'contact_repel_videos'", payload["sql"])
        self.assertNotIn("'insect-images'", payload["sql"])

    def test_organism_experiment_search_routes_to_structured_bucket_sql(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "do you see any experiments with the diamond back moths?",
            "auto",
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("source_search", payload["sql"])
        self.assertNotIn("csv_rows_with_provenance", payload["sql"])
        self.assertEqual(payload["routing_decision"]["intent"], "experiments_by_organism")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_experiments_by_organism_sql")

    def test_docking_questions_route_to_structured_bucket_adapters(self):
        import routing_decision

        cases = {
            "find the docking results": ("docking_results", "bucket_docking_results_sql"),
        }

        for question, (intent, adapter) in cases.items():
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(question, "auto")

                self.assertEqual(payload["source"], "bucket")
                self.assertIn("sql", payload)
                self.assertEqual(payload["routing_decision"]["intent"], intent)
                self.assertEqual(payload["routing_decision"]["adapter"], adapter)

    def test_bucket_script_method_question_returns_script_lines(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what script computes entropy in the fly metrics?",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "script_method_evidence")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_script_method_evidence_sql")
        self.assertIn("text_lines t", payload["sql"])
        self.assertIn("scripts/advanced_population_metrics.py", payload["sql"])
        self.assertIn("script_name", payload["sql"])
        self.assertIn("script_line", payload["sql"])
        self.assertIn("script_uri", payload["sql"])

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE text_lines (name TEXT, line_number INTEGER, text TEXT, generation TEXT);
            CREATE TABLE objects (name TEXT, uri TEXT, updated TEXT, time_created TEXT);
            INSERT INTO objects VALUES ('scripts/advanced_population_metrics.py', 'gs://monarch-videos-new/scripts/advanced_population_metrics.py', '2026-05-01T00:00:00Z', '2026-05-01T00:00:00Z');
            INSERT INTO text_lines VALUES ('scripts/advanced_population_metrics.py', 3, 'Advanced Population Metrics for Behavioral Assays', '1');
            INSERT INTO text_lines VALUES ('scripts/advanced_population_metrics.py', 171, 'def compute_entropy(zone_counts):', '1');
            """
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertTrue(rows)
        self.assertEqual(rows[0]["unit_type"], "script_line")
        self.assertEqual(rows[0]["script_name"], "scripts/advanced_population_metrics.py")
        self.assertIn("line=", rows[0]["provenance_grain"])

    def test_chemistry_script_method_question_returns_chemistry_script_lines(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "how does the chemical registry work?",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "chemistry_analysis")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "script_method_evidence")
        self.assertEqual(payload["routing_decision"]["adapter"], "chemistry_analysis_script_method_evidence_sql")
        self.assertIn("scripts/chemical_registry.py", payload["sql"])
        self.assertIn("script_name", payload["sql"])

    def test_script_question_beats_phytotoxicity_result_route(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what script made the phytotoxicity feature table?",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "script_method_evidence")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_script_method_evidence_sql")
        self.assertIn("scripts/leaf_phytotoxicity_analysis.py", payload["sql"])
        self.assertNotIn("bucket_phytotox_experiment_summary_sql", payload["routing_decision"]["adapter"])

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE text_lines (name TEXT, line_number INTEGER, text TEXT, generation TEXT);
            CREATE TABLE objects (name TEXT, uri TEXT, updated TEXT, time_created TEXT);
            INSERT INTO objects VALUES ('scripts/leaf_phytotoxicity_analysis.py', 'gs://monarch-videos-new/scripts/leaf_phytotoxicity_analysis.py', '2026-05-01T00:00:00Z', '2026-05-01T00:00:00Z');
            INSERT INTO objects VALUES ('scripts/generate_leaf_configs.py', 'gs://monarch-videos-new/scripts/generate_leaf_configs.py', '2026-05-01T00:00:00Z', '2026-05-01T00:00:00Z');
            INSERT INTO text_lines VALUES ('scripts/generate_leaf_configs.py', 3, 'Leaf Phytotoxicity Experiment Config Generator', '1');
            INSERT INTO text_lines VALUES ('scripts/leaf_phytotoxicity_analysis.py', 3, 'Leaf Phytotoxicity Feature Analysis', '1');
            INSERT INTO text_lines VALUES ('scripts/leaf_phytotoxicity_analysis.py', 1294, 'features_all.csv', '1');
            """
        )
        rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

        self.assertEqual(rows[0]["script_name"], "scripts/leaf_phytotoxicity_analysis.py")

    def test_object_backed_bucket_adapters_run_on_live_bucket_object_schema(self):
        import routing_decision

        conn = sqlite3.connect(":memory:")
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE objects (
              name TEXT,
              uri TEXT,
              kind TEXT,
              top_folder TEXT,
              ext TEXT,
              size INTEGER,
              content_type TEXT,
              generation TEXT,
              metageneration TEXT,
              md5_hash TEXT,
              crc32c TEXT,
              updated TEXT,
              time_created TEXT
            );
            CREATE TABLE csv_rows_with_provenance (
              name TEXT,
              row_number INTEGER,
              row_json TEXT,
              generation TEXT,
              provenance_grain TEXT
            );
            CREATE TABLE text_lines_with_provenance (
              name TEXT,
              line_number INTEGER,
              text TEXT,
              provenance_grain TEXT
            );
            CREATE VIRTUAL TABLE source_search USING fts5(
              unit_type UNINDEXED,
              name UNINDEXED,
              sub_id UNINDEXED,
              body,
              provenance_grain UNINDEXED
            );
            """
        )
        conn.executemany(
            "INSERT INTO source_search (unit_type, name, sub_id, body, provenance_grain) VALUES (?, ?, ?, ?, ?)",
            [
                (
                    "object",
                    "Beetles/diamondback_moth/run_1/video.mov",
                    "Beetles/diamondback_moth/run_1/video.mov",
                    "Beetles diamondback moth video mov",
                    '{"grain_type":"gcs_object","locator":"gs://monarch-videos-new/Beetles/diamondback_moth/run_1/video.mov"}',
                ),
                (
                    "object",
                    "docking/results/vina_report.txt",
                    "docking/results/vina_report.txt",
                    "docking vina affinity report text",
                    '{"grain_type":"gcs_object","locator":"gs://monarch-videos-new/docking/results/vina_report.txt"}',
                ),
            ],
        )

        for question in (
            "do you see any experiments with the diamond back moths?",
            "find the docking results",
        ):
            with self.subTest(question=question):
                payload = routing_decision.query_payload_for_question(question, "auto")
                rows = [dict(row) for row in conn.execute(payload["sql"]).fetchall()]

                self.assertGreaterEqual(len(rows), 1)
                self.assertTrue(any("gcs_object" in row["provenance_grain"] for row in rows))

    def test_existing_inventory_payload_uses_sql_not_source_gap(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what is the existing inventory?",
            "auto",
        )

        self.assertEqual(payload["source"], "compound_inventory")
        self.assertIn("sql", payload)
        self.assertNotIn("source_gap", payload)
        self.assertIn("inventory_scope", payload["sql"])
        self.assertEqual(payload["routing_decision"]["adapter"], "compound_inventory_summary_sql")

    def test_apply_authoritative_route_returns_source_gap_for_missing_multihop_adapter(self):
        import routing_decision

        payload = routing_decision.apply_authoritative_route(
            {
                "question": "what are assay results from the last 10 chemicals ordered in inventory?",
                "source": "auto",
            }
        )

        self.assertEqual(payload["source"], "compound_inventory")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "mixed")
        self.assertIn("source_gap", payload)
        self.assertEqual(
            payload["source_gap"]["missing_adapter"],
            "compound_inventory_latest_ordered_compounds",
        )

    def test_apply_authoritative_route_returns_source_gap_for_media_proof_without_exact_row(self):
        import routing_decision

        payload = routing_decision.apply_authoritative_route(
            {
                "question": "show me the assay video for this result",
                "source": "bucket",
            }
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["intent"], "media_proof")
        self.assertIn("source_gap", payload)
        self.assertEqual(payload["source_gap"]["missing_adapter"], "bucket_assay_media_links")

    def test_slack_questions_return_source_gap_instead_of_bucket_search(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what does Monarch know from Slack?",
            "auto",
        )

        self.assertIn("source_gap", payload)
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "source_gap")
        self.assertEqual(payload["source_gap"]["intent"], "unsupported_source_lane")
        self.assertEqual(payload["source_gap"]["source_lane"], "slack")

    def test_metric_date_window_assay_question_builds_result_contract(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "list the avg pref index in the last 2 weeks of assays",
            "auto",
        )

        contract = route["question_contract"]
        self.assertEqual(contract["answer_class"], "direct_fact")
        self.assertEqual(contract["answer_shape"], "assay_result_list")
        self.assertEqual(contract["source_plane_candidates"], ["bucket"])
        self.assertEqual(contract["evidence_domain"], "assay_results")
        self.assertEqual(contract["required_modifiers"]["metric"], "preference_index")
        self.assertEqual(contract["required_modifiers"]["source_date_basis"], "run_date")
        self.assertIn("date_window", contract["required_modifiers"])
        self.assertEqual(route["answer_shape"], "assay_result_list")
        self.assertEqual(route["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("FROM assay_results r", route["sql"])
        self.assertIn("r.metric_name IN", route["sql"])
        self.assertIn("avg_pi", route["sql"])
        self.assertNotIn("FROM assay_runs r", route["sql"])

    def test_preference_index_date_window_empty_rows_source_gap_names_precise_gap(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list the avg pref index in the last 2 weeks of assays",
            "auto",
        )
        result = routing_decision.structured_result_or_source_gap(
            payload,
            {"mode": "sql", "source": "bucket", "rows": []},
        )

        self.assertEqual(result["mode"], "source_gap")
        message = result["source_gap"]["message"]
        self.assertIn("preference-index", message)
        self.assertIn("run-date window", message)
        self.assertIn("structured assay-results route", message)
        self.assertNotIn("returned no clean", message)

    def test_deep_analysis_question_builds_synthesized_analysis_contract(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "which fly compounds should we prioritize next and why?",
            "auto",
        )

        contract = route["question_contract"]
        self.assertEqual(contract["answer_class"], "synthesized_analysis")
        self.assertEqual(contract["gap_policy"], "analysis_gap")
        self.assertTrue(contract["reasoning_policy"]["may_recommend"])
        self.assertTrue(contract["reasoning_policy"]["must_separate_evidence_from_judgment"])
        self.assertIn("bucket", contract["source_plane_candidates"])
        self.assertIn("compound_inventory", contract["source_plane_candidates"])

    def test_media_pull_up_question_builds_source_backed_action_contract(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "pull up the assay and video for the most repellent compound we have tested in flies",
            "auto",
        )

        contract = route["question_contract"]
        self.assertEqual(contract["answer_class"], "source_backed_action")
        self.assertEqual(contract["answer_shape"], "ranked_repellents_with_media")
        self.assertEqual(contract["gap_policy"], "action_gap")
        self.assertTrue(contract["action_policy"]["requires_action_receipt"])
        self.assertIn("media", contract["required_modifiers"])

    def test_open_questions_are_not_source_backed_actions(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what open questions do teams recaps mention?",
            "teams_recaps",
        )

        self.assertEqual(route["question_contract"]["answer_class"], "direct_fact")

    def test_explicit_cross_experiment_docs_source_stays_in_contract_candidates(self):
        import routing_decision

        route = routing_decision.route_decision_for_question(
            "what does the figure guide say about top_performing_chemicals.csv?",
            "cross_experiment_docs",
        )

        self.assertEqual(route["source_lane"], "cross_experiment_docs")
        self.assertEqual(route["question_contract"]["source_plane_candidates"], ["cross_experiment_docs"])

    def test_every_declared_source_plane_emits_contract_trace(self):
        import routing_decision

        cases = {
            "bucket": "list assays from the last 2 weeks",
            "chemistry_analysis": "what chemistry analysis script generated protein structures?",
            "compound_inventory": "list all compounds in our inventory",
            "presentations": "what do presentations say about DART?",
            "teams_recaps": "what did the team discuss yesterday?",
            "company_profile": "what organisms does Monarch work on?",
            "people_directory": "who are the advisors?",
            "company_context": "what does company context say about the platform?",
            "scientific_refs": "what does the literature say about odorant receptors?",
            "milestones_doc": "what milestones mention repellency?",
        }
        for source, question in cases.items():
            with self.subTest(source=source):
                route = routing_decision.route_decision_for_question(question, source)
                self.assertIn("question_contract", route)
                self.assertIn(source, route["question_contract"]["source_plane_candidates"])
                self.assertEqual(route["question_contract"]["latency_target_ms"], 20000)
                self.assertIn("required_provenance", route["question_contract"])


if __name__ == "__main__":
    unittest.main()
