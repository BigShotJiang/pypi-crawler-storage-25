import contextlib
import io
import json
import os
import sys
import tempfile
import types
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import ask_monarch


class AskMonarchSetupTest(unittest.TestCase):
    def make_config_path(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        return os.path.join(tmp.name, ".config", "ask-monarch", "config.json")

    def test_exchange_saves_returned_token_without_printing_it(self):
        config_path = self.make_config_path()

        def fake_request_json(url, token=None, method="GET", payload=None):
            return {"ok": True, "token": "new-secret-token", "email": "amir@example.com"}

        args = types.SimpleNamespace(
            url="https://ask-monarch.example",
            token=None,
            code="MNR-ABCD-1234",
            no_configure=False,
        )
        buffer = io.StringIO()
        with mock.patch.object(ask_monarch, "CONFIG_PATH", config_path), mock.patch.object(
            ask_monarch, "request_json", side_effect=fake_request_json
        ), contextlib.redirect_stdout(buffer):
            code = ask_monarch.onboarding_code_exchange(args)

        self.assertEqual(code, 0)
        raw = buffer.getvalue()
        self.assertNotIn("new-secret-token", raw)
        payload = json.loads(raw)
        self.assertTrue(payload["configured"])
        with open(config_path, encoding="utf-8") as handle:
            saved = json.load(handle)
        self.assertEqual(saved["token"], "new-secret-token")
        self.assertEqual(saved["url"], "https://ask-monarch.example")

    def test_doctor_passes_when_global_codex_setup_is_ready(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = os.path.join(tmp, "home")
            codex_home = os.path.join(tmp, ".codex")
            local_bin = os.path.join(home, ".local", "bin")
            bin_path = os.path.join(local_bin, "ask-monarch")
            config_path = os.path.join(home, ".config", "ask-monarch", "config.json")
            os.makedirs(local_bin)
            os.makedirs(os.path.dirname(config_path))
            os.makedirs(codex_home)
            with open(bin_path, "w", encoding="utf-8") as handle:
                handle.write("#!/bin/sh\n")
            os.chmod(bin_path, 0o755)
            with open(config_path, "w", encoding="utf-8") as handle:
                json.dump({"url": "https://ask-monarch.example", "token": "secret-token"}, handle)
            skill_names = ask_monarch.EXPECTED_CODEX_SKILLS
            config_lines = []
            for skill_name in skill_names:
                skill_path = os.path.join(codex_home, "skills", skill_name, "SKILL.md")
                os.makedirs(os.path.dirname(skill_path))
                with open(skill_path, "w", encoding="utf-8") as handle:
                    handle.write(f"# {skill_name}\n")
                config_lines.extend(["[[skills.config]]", f'path = "{skill_path}"', "enabled = true", ""])
            with open(os.path.join(codex_home, "config.toml"), "w", encoding="utf-8") as handle:
                handle.write("\n".join(config_lines))
            with open(os.path.join(codex_home, "AGENTS.md"), "w", encoding="utf-8") as handle:
                handle.write("\n".join(ask_monarch.PARITY_GLOBAL_PHRASES))

            def fake_request_json(url, token=None, method="GET", payload=None):
                if url.endswith("/health"):
                    return {"ok": True}
                if url.endswith("/summary"):
                    return {"ok": True, "summary": {"bucket": {"rows": 12}}}
                return {"ok": False, "error": "unexpected url"}

            args = types.SimpleNamespace(url=None, token=None)
            buffer = io.StringIO()
            with mock.patch.object(ask_monarch, "CONFIG_PATH", config_path), mock.patch.dict(
                os.environ,
                {
                    "HOME": home,
                    "CODEX_HOME": codex_home,
                    "PATH": local_bin,
                    "ASK_MONARCH_BIN": bin_path,
                },
                clear=False,
            ), mock.patch("shutil.which", return_value=bin_path), mock.patch.object(
                ask_monarch, "request_json", side_effect=fake_request_json
            ), contextlib.redirect_stdout(buffer):
                code = ask_monarch.doctor(args)

            self.assertEqual(code, 0)
            payload = json.loads(buffer.getvalue())
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["required_gaps"], [])
            self.assertCountEqual(payload["enabled_skills"], list(skill_names))

    def test_doctor_reports_missing_global_agents_rule(self):
        with tempfile.TemporaryDirectory() as tmp:
            config_path = os.path.join(tmp, "config.json")
            with open(config_path, "w", encoding="utf-8") as handle:
                json.dump({"url": "https://ask-monarch.example", "token": "secret-token"}, handle)

            args = types.SimpleNamespace(url=None, token=None)
            buffer = io.StringIO()
            with mock.patch.object(ask_monarch, "CONFIG_PATH", config_path), mock.patch.dict(
                os.environ,
                {"CODEX_HOME": os.path.join(tmp, ".codex"), "ASK_MONARCH_BIN": os.path.join(tmp, "ask-monarch")},
                clear=False,
            ), mock.patch("shutil.which", return_value=None), mock.patch.object(
                ask_monarch, "request_json", return_value={"ok": True, "summary": {"bucket": {"rows": 1}}}
            ), contextlib.redirect_stdout(buffer):
                code = ask_monarch.doctor(args)

            self.assertEqual(code, 1)
            payload = json.loads(buffer.getvalue())
            self.assertIn("global_agents_ask_monarch_rule_missing", payload["required_gaps"])

    def test_parity_passes_when_teammate_experience_contract_is_installed(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = os.path.join(tmp, "home")
            codex_home = os.path.join(tmp, ".codex")
            local_bin = os.path.join(home, ".local", "bin")
            bin_path = os.path.join(local_bin, "ask-monarch")
            config_path = os.path.join(home, ".config", "ask-monarch", "config.json")
            os.makedirs(local_bin)
            os.makedirs(os.path.dirname(config_path))
            os.makedirs(codex_home)
            with open(bin_path, "w", encoding="utf-8") as handle:
                handle.write("#!/bin/sh\n")
            os.chmod(bin_path, 0o755)
            with open(config_path, "w", encoding="utf-8") as handle:
                json.dump({"url": "https://ask-monarch.example", "token": "secret-token"}, handle)
            skill_names = ask_monarch.EXPECTED_CODEX_SKILLS
            config_lines = []
            for skill_name in skill_names:
                skill_path = os.path.join(codex_home, "skills", skill_name, "SKILL.md")
                os.makedirs(os.path.dirname(skill_path))
                body = "# skill\n"
                if skill_name == "askmonarch":
                    body += "\n".join(ask_monarch.PARITY_SKILL_PHRASES)
                with open(skill_path, "w", encoding="utf-8") as handle:
                    handle.write(body)
                config_lines.extend(["[[skills.config]]", f'path = "{skill_path}"', "enabled = true", ""])
            with open(os.path.join(codex_home, "config.toml"), "w", encoding="utf-8") as handle:
                handle.write("\n".join(config_lines))
            with open(os.path.join(codex_home, "AGENTS.md"), "w", encoding="utf-8") as handle:
                handle.write("\n".join(ask_monarch.PARITY_GLOBAL_PHRASES))

            def fake_request_json(url, token=None, method="GET", payload=None):
                if url.endswith("/summary"):
                    return {
                        "ok": True,
                        "summary": {lane: {"rows": 1} for lane in ask_monarch.PARITY_REQUIRED_SOURCE_LANES},
                    }
                return {"ok": True}

            args = types.SimpleNamespace(url=None, token=None)
            buffer = io.StringIO()
            with mock.patch.object(ask_monarch, "CONFIG_PATH", config_path), mock.patch.dict(
                os.environ,
                {
                    "HOME": home,
                    "CODEX_HOME": codex_home,
                    "PATH": local_bin,
                    "ASK_MONARCH_BIN": bin_path,
                },
                clear=False,
            ), mock.patch("shutil.which", return_value=bin_path), mock.patch.object(
                ask_monarch, "request_json", side_effect=fake_request_json
            ), contextlib.redirect_stdout(buffer):
                code = ask_monarch.parity(args)

            self.assertEqual(code, 0)
            payload = json.loads(buffer.getvalue())
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["required_gaps"], [])
            self.assertEqual(payload["status"], "parity_ready")

    def test_parity_fails_when_skill_lacks_experience_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = os.path.join(tmp, "home")
            codex_home = os.path.join(tmp, ".codex")
            local_bin = os.path.join(home, ".local", "bin")
            bin_path = os.path.join(local_bin, "ask-monarch")
            config_path = os.path.join(home, ".config", "ask-monarch", "config.json")
            os.makedirs(local_bin)
            os.makedirs(os.path.dirname(config_path))
            os.makedirs(os.path.join(codex_home, "skills", "askmonarch"))
            with open(bin_path, "w", encoding="utf-8") as handle:
                handle.write("#!/bin/sh\n")
            os.chmod(bin_path, 0o755)
            with open(config_path, "w", encoding="utf-8") as handle:
                json.dump({"url": "https://ask-monarch.example", "token": "secret-token"}, handle)
            with open(os.path.join(codex_home, "skills", "askmonarch", "SKILL.md"), "w", encoding="utf-8") as handle:
                handle.write("# Ask Monarch\n")
            with open(os.path.join(codex_home, "AGENTS.md"), "w", encoding="utf-8") as handle:
                handle.write("\n".join(ask_monarch.PARITY_GLOBAL_PHRASES))

            args = types.SimpleNamespace(url=None, token=None)
            buffer = io.StringIO()
            with mock.patch.object(ask_monarch, "CONFIG_PATH", config_path), mock.patch.dict(
                os.environ,
                {"HOME": home, "CODEX_HOME": codex_home, "PATH": local_bin, "ASK_MONARCH_BIN": bin_path},
                clear=False,
            ), mock.patch("shutil.which", return_value=bin_path), mock.patch.object(
                ask_monarch, "request_json", return_value={"ok": True, "summary": {lane: {} for lane in ask_monarch.PARITY_REQUIRED_SOURCE_LANES}}
            ), contextlib.redirect_stdout(buffer):
                code = ask_monarch.parity(args)

            self.assertEqual(code, 1)
            payload = json.loads(buffer.getvalue())
            self.assertIn("parity_skill_contract_missing", payload["required_gaps"])


if __name__ == "__main__":
    unittest.main()
