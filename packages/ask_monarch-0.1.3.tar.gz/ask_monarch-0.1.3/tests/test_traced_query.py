import os
import json
import sqlite3
import sys
import tempfile
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class FakeSource:
    def __init__(self):
        self.health_calls = 0

    def query(self, payload):
        return {
            "mode": "search",
            "source": payload.get("source", "bucket"),
            "rows": [
                {
                    "text": "Monarch develops agricultural repellency assays.",
                    "provenance_grain": '{"grain_id":"unit:1","grain_type":"slide_text","locator":"https://docs.google.com/presentation/d/deck-id/edit#slide=2"}',
                }
            ],
        }

    def health(self, deep=False):
        self.health_calls += 1
        return {"ok": True, "source": "fake", "health_mode": "deep" if deep else "cached"}


class FakeMixedSource:
    def __init__(self):
        self.payloads = []

    def query(self, payload):
        self.payloads.append(dict(payload))
        if "sql" in payload:
            return {
                "mode": "sql",
                "source": payload.get("source", "bucket"),
                "rows": [{"kind": "anchor", "provenance_grain": '{"locator":"anchor#1"}'}],
            }
        return {
            "mode": "search",
            "source": payload.get("source", "bucket"),
            "rows": [{"kind": "prose", "provenance_grain": '{"locator":"prose#1"}'}],
        }

    def health(self, deep=False):
        return {"ok": True}


class FakeMeetingMixedSource:
    def __init__(self):
        self.payloads = []

    def query(self, payload):
        self.payloads.append(dict(payload))
        if "sql" in payload and "FROM meetings" in payload["sql"]:
            return {
                "mode": "sql",
                "source": "teams_recaps",
                "rows": [
                    {
                        "meeting_date": "2026-05-08",
                        "title": "Monarch R&D",
                        "provenance_grain": '{"locator":"meeting#2026-05-08"}',
                    }
                ],
            }
        if "sql" in payload and "FROM utterances" in payload["sql"]:
            return {
                "mode": "sql",
                "source": "teams_recaps",
                "rows": [
                    {
                        "meeting_date": "2026-05-08",
                        "text": "The team was uncertain about docking verification.",
                        "provenance_grain": '{"locator":"utterance#1"}',
                    }
                ],
            }
        return {"mode": "search", "source": "teams_recaps", "rows": []}

    def health(self, deep=False):
        return {"ok": True}


class FakeEmptyStructuredSource:
    def __init__(self):
        self.payloads = []

    def query(self, payload):
        import routing_decision

        self.payloads.append(dict(payload))
        result = {"mode": "sql", "source": payload.get("source", "bucket"), "rows": []}
        return routing_decision.structured_result_or_source_gap(payload, result)

    def health(self, deep=False):
        return {"ok": True}


class FakeWrongShapeSource:
    def query(self, payload):
        return {
            "ok": True,
            "mode": "sql",
            "source": payload.get("source", "bucket"),
            "rows": [
                {
                    "assay_family": "dart",
                    "assay_date": "2026-05-08",
                    "species": "mosquitoes",
                    "provenance_grain": '{"locator":"row#1"}',
                }
            ],
        }

    def health(self, deep=False):
        return {"ok": True}


class FakeTableSource:
    def __init__(self, source_name, rows):
        self.source_name = source_name
        self.rows = rows
        self.payloads = []

    def query(self, payload):
        self.payloads.append(dict(payload))
        return {
            "ok": True,
            "mode": "sql",
            "source": self.source_name,
            "rows": self.rows,
        }


class FakePhytotoxInventoryRoutePlanSource:
    def __init__(self):
        self.bucket = FakeTableSource(
            "bucket",
            [
                {
                    "rank": 1,
                    "compound": "Linalyl acetate",
                    "avg_damaged_fraction": 0.9376,
                    "provenance_grain": '{"grain_type":"phytotox_result_row"}',
                },
                {
                    "rank": 2,
                    "compound": "Beta-cyclocitral",
                    "avg_damaged_fraction": 0.8993,
                    "provenance_grain": '{"grain_type":"phytotox_result_row"}',
                },
            ],
        )
        self.compound_inventory = FakeTableSource(
            "compound_inventory",
            [
                {"row_number": 701, "compound_name": "Linalyl acetate"},
                {"row_number": 507, "compound_name": "BETA-CYCLOCITRAL"},
            ],
        )

    def query(self, payload):
        raise AssertionError("route-plan questions should execute source steps, not fall through to generic query")

    def health(self, deep=False):
        return {"ok": True}


class FakeAnswerShapeRoutePlanSource:
    def __init__(self):
        self.bucket = FakeTableSource(
            "bucket",
            [
                {
                    "compound": "2PP",
                    "score": 0.91,
                    "assay_family": "dart",
                    "assay_date": "2026-05-08",
                    "species": "mosquitoes",
                    "standard_deviation": 0.07,
                    "standard_deviation_basis": "sample_stddev_of_avg_pi_real_across_dart_rows",
                    "provenance_grain": '{"grain_type":"dart_assay_row"}',
                }
            ],
        )
        self.milestones_doc = FakeTableSource(
            "milestones_doc",
            [
                {
                    "text": "2PP was mentioned in the milestone notes.",
                    "provenance_grain": '{"grain_type":"paragraph"}',
                }
            ],
        )
        self.teams_recaps = FakeTableSource(
            "teams_recaps",
            [
                {
                    "speaker": "Avinash",
                    "text": "The team discussed assay results.",
                    "provenance_grain": '{"grain_type":"meeting_utterance"}',
                }
            ],
        )
        self.compound_inventory = FakeTableSource(
            "compound_inventory",
            [
                {
                    "compound_name": "Menthone",
                    "provenance_grain": '{"grain_type":"xlsx_cell"}',
                }
            ],
        )

    def query(self, payload):
        raise AssertionError("route-plan questions should execute source steps, not fall through to generic query")

    def health(self, deep=False):
        return {"ok": True}


class TracedQueryTests(unittest.TestCase):
    def test_execute_query_adds_latency_ms_to_routing_log(self):
        import braintrust_tracing
        import serve_http

        source = FakeMixedSource()
        with mock.patch(
            "serve_http.braintrust_tracing.start_trace",
            return_value=braintrust_tracing.NoopTraceRecorder(),
        ):
            result = serve_http.execute_query(
                source,
                {"question": "why might peppermint oil be working?", "source": "auto", "limit": 5},
            )

        self.assertIn("latency_ms", result["routing_log"])
        self.assertIsInstance(result["routing_log"]["latency_ms"], int)

    def test_execute_query_converts_late_answers_to_latency_gap(self):
        import braintrust_tracing
        import serve_http

        with mock.patch(
            "serve_http.braintrust_tracing.start_trace",
            return_value=braintrust_tracing.NoopTraceRecorder(),
        ):
            with mock.patch("serve_http.time.perf_counter", side_effect=[0, 21]):
                result = serve_http.execute_query(
                    FakeSource(),
                    {
                        "question": "mission",
                        "source": "company_profile",
                        "routing_decision": {
                            "question_contract": {"latency_target_ms": 20000}
                        },
                    },
                )

        self.assertFalse(result["ok"])
        self.assertEqual(result["mode"], "source_gap")
        self.assertEqual(result["source_gap"]["gap_type"], "latency_gap")
        self.assertEqual(result["routing_log"]["latency_ms"], 21000)

    def test_execute_query_adds_health_and_trace_fields(self):
        import serve_http

        with mock.patch("serve_http.braintrust_tracing.start_trace") as start_trace:
            recorder = start_trace.return_value
            recorder.finish.return_value = {
                "trace_id": "trace-123",
                "trace_url": "https://www.braintrust.dev/app/Andes/p/ask-monarch/trace?r=trace-123",
            }

            result = serve_http.execute_query(
                FakeSource(),
                {"question": "mission", "source": "company_profile", "include_health": True, "trace": True},
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["routing_decision"]["source_lane"], "company_profile")
        self.assertEqual(result["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(result["trace_id"], "trace-123")
        self.assertEqual(result["health"]["ok"], True)
        user_question_events = [
            call
            for call in recorder.event.call_args_list
            if call.args and call.args[0] == "trace.user_question"
        ]
        self.assertEqual(len(user_question_events), 1)
        user_question_output = user_question_events[0].kwargs["output"]
        self.assertEqual(user_question_output["question"], "mission")
        self.assertEqual(user_question_output["source"], "company_profile")
        self.assertEqual(user_question_output["kind"], "all")
        self.assertEqual(
            user_question_output["routing_decision"]["adapter"],
            "company_profile_unit_lookup_sql",
        )
        self.assertEqual(
            result["rows"][0]["source_actions"][0]["label"],
            "Open presentation slide",
        )
        self.assertEqual(
            result["rows"][0]["source_actions"][0]["locator"],
            "https://docs.google.com/presentation/d/deck-id/edit#slide=2",
        )

    def test_execute_query_skips_trace_health_when_not_requested(self):
        import braintrust_tracing
        import serve_http

        source = FakeSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {"question": "mission", "source": "company_profile", "include_health": False},
            )

        self.assertTrue(result["ok"])
        self.assertIn("routing_decision", result)
        self.assertNotIn("trace_id", result)
        self.assertEqual(source.health_calls, 0)

    def test_execute_query_marks_direct_sql_as_router_bypass(self):
        import braintrust_tracing
        import serve_http

        source = FakeSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {"sql": "select 1", "source": "bucket"},
            )

        self.assertTrue(result["ok"])
        self.assertTrue(result["router_bypassed"])
        self.assertEqual(result["bypass_reason"], "direct_sql_command")

    def test_execute_query_runs_structured_anchor_before_text_retrieval(self):
        import braintrust_tracing
        import serve_http

        source = FakeMixedSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {
                    "question": "why might peppermint oil be working?",
                    "source": "auto",
                    "limit": 5,
                },
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["mode"], "mixed")
        self.assertEqual(result["source"], "bucket")
        self.assertEqual(result["structured_anchor_rows"][0]["kind"], "anchor")
        self.assertEqual(result["prose_rows"][0]["kind"], "prose")
        self.assertEqual(result["rows"], result["structured_anchor_rows"])
        self.assertIn("sql", source.payloads[0])
        self.assertNotIn("question", source.payloads[0])
        self.assertIn("question", source.payloads[1])
        self.assertNotIn("sql", source.payloads[1])
        self.assertEqual(
            result["routing_decision"]["adapter_execution"],
            "structured_anchor_then_text_retrieval",
        )

    def test_execute_query_runs_phytotox_inventory_route_plan(self):
        import braintrust_tracing
        import serve_http

        source = FakePhytotoxInventoryRoutePlanSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {
                    "question": "list the most phytotoxic compounds in our inventory from 1-5",
                    "source": "auto",
                    "limit": 5,
                },
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["mode"], "phytotox_inventory_ranking")
        self.assertEqual(result["source"], "route_plan")
        self.assertEqual(result["routing_decision"]["answer_shape"], "ranked_compounds_with_inventory_status")
        self.assertEqual(result["source_plan"][0]["adapter"], "bucket_phytotox_rank_compounds_sql")
        self.assertEqual(result["source_plan"][1]["adapter"], "compound_inventory_all_names_sql")
        self.assertEqual([row["compound"] for row in result["rows"]], ["Linalyl acetate", "Beta-cyclocitral"])
        self.assertIn("sql", source.bucket.payloads[0])
        self.assertIn("sql", source.compound_inventory.payloads[0])
        self.assertEqual(source.compound_inventory.payloads[0]["limit"], 1000)

    def test_execute_query_runs_answer_shape_route_plan_steps(self):
        import braintrust_tracing
        import serve_http

        source = FakeAnswerShapeRoutePlanSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {
                    "question": "show me the top compounds per repellency data and whether they are mentioned in our milestones",
                    "source": "auto",
                    "limit": 5,
                },
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["mode"], "mixed")
        self.assertEqual(result["source"], "bucket")
        self.assertEqual(result["routing_decision"]["adapter"], "bucket_repellency_milestone_mention_plan")
        self.assertEqual(
            [(step["source"], step["adapter"]) for step in result["source_plan"]],
            [
                ("bucket", "bucket_cross_assay_repellent_rank_compounds_sql"),
                ("milestones_doc", "milestones_doc_source_text_retrieval"),
            ],
        )
        self.assertIn("sql", source.bucket.payloads[0])
        self.assertIn("question", source.milestones_doc.payloads[0])
        self.assertNotIn("sql", source.milestones_doc.payloads[0])

    def test_execute_query_runs_assays_plus_meeting_route_plan_steps(self):
        import braintrust_tracing
        import serve_http

        source = FakeAnswerShapeRoutePlanSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {
                    "question": "show me what assays the team ran yesterday and what they said about them in the team meeting friday am",
                    "source": "auto",
                    "limit": 5,
                },
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["mode"], "mixed")
        self.assertEqual(result["source"], "bucket")
        self.assertEqual(result["routing_decision"]["adapter"], "bucket_assays_teams_commentary_plan")
        self.assertEqual(
            [(step["source"], step["adapter"]) for step in result["source_plan"]],
            [
                ("bucket", "bucket_assay_serving_table_sql"),
                ("teams_recaps", "teams_recaps_topic_speaker_rollup_sql"),
            ],
        )
        self.assertIn("sql", source.bucket.payloads[0])
        self.assertIn("sql", source.teams_recaps.payloads[0])

    def test_execute_query_keeps_missing_route_plan_as_source_gap(self):
        import braintrust_tracing
        import serve_http

        source = FakeAnswerShapeRoutePlanSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {
                    "question": "what are assay results from the last 10 chemicals ordered in the inventory?",
                    "source": "auto",
                    "limit": 5,
                },
            )

        self.assertFalse(result["ok"])
        self.assertEqual(result["mode"], "source_gap")
        self.assertEqual(result["source_gap"]["missing_adapter"], "compound_inventory_latest_ordered_compounds")

    def test_execute_query_scopes_meeting_anchor_text_to_anchor_date(self):
        import braintrust_tracing
        import serve_http

        source = FakeMeetingMixedSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {
                    "question": "what was the team uncertain about in last Friday's R&D meeting?",
                    "source": "auto",
                    "limit": 5,
                },
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["mode"], "mixed")
        self.assertEqual(result["source"], "teams_recaps")
        self.assertEqual(result["structured_anchor_rows"][0]["meeting_date"], "2026-05-08")
        self.assertEqual(result["prose_rows"][0]["meeting_date"], "2026-05-08")
        self.assertIn("FROM utterances", source.payloads[1]["sql"])
        self.assertIn("2026-05-08", source.payloads[1]["sql"])
        self.assertNotIn("question", source.payloads[1])

    def test_source_gap_result_remains_not_ok(self):
        import braintrust_tracing
        import routing_decision
        import serve_http

        class GapSource:
            def query(self, payload):
                return routing_decision.source_gap_result(payload, "slack")

            def health(self, deep=False):
                return {"ok": True}

        payload = routing_decision.query_payload_for_question(
            "what does Monarch know from Slack?",
            "auto",
        )
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(GapSource(), payload)

        self.assertFalse(result["ok"])
        self.assertEqual(result["mode"], "source_gap")
        self.assertIn("source_gap", result)

    def test_shape_mismatch_short_circuits_to_source_gap(self):
        import braintrust_tracing
        import serve_http

        source = FakeWrongShapeSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {
                    "question": "what fly assays ran last week?",
                    "source": "auto",
                    "limit": 5,
                },
            )

        self.assertFalse(result["ok"])
        self.assertEqual(result["mode"], "source_gap")
        self.assertEqual(result["error"], "answer_shape_gap")
        self.assertEqual(result["source_gap"]["expected_answer_shape"], "assay_run_list")
        self.assertIn("species scope", " ".join(result["source_gap"]["errors"]))

    def test_structured_sql_empty_rows_fail_with_source_gap_before_prose(self):
        import braintrust_tracing
        import serve_http

        source = FakeEmptyStructuredSource()
        with mock.patch("serve_http.braintrust_tracing.start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http.execute_query(
                source,
                {
                    "question": "show me a recent no contact video",
                    "source": "auto",
                    "limit": 5,
                },
            )

        self.assertFalse(result["ok"])
        self.assertEqual(result["mode"], "source_gap")
        self.assertEqual(len(source.payloads), 1)
        self.assertIn("bucket_recent_media_by_mode_sql", result["source_gap"]["message"])
        self.assertEqual(result["routing_log"]["short_circuit_reason"], "no_silent_prose_fallback")
        self.assertEqual(
            result["routing_log"]["structured_result"],
            {
                "clean": False,
                "error": False,
                "expected_grain_type": "bucket_object",
                "row_count": 0,
            },
        )

    def test_teams_digest_query_returns_answer_metadata_absolute_date(self):
        import serve_http

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "teams.sqlite")
            status_path = os.path.join(tmp, "status.json")
            gaps_path = os.path.join(tmp, "gaps.json")
            conn = sqlite3.connect(db_path)
            conn.execute("CREATE TABLE meetings (meeting_date TEXT)")
            conn.execute("CREATE TABLE utterances (meeting_date TEXT)")
            conn.commit()
            conn.close()
            with open(status_path, "w", encoding="utf-8") as handle:
                json.dump({"meeting_count": 1, "utterance_count": 1, "gap_count": 0, "fully_parsed": True}, handle)
            with open(gaps_path, "w", encoding="utf-8") as handle:
                json.dump([], handle)

            source = serve_http.TeamsRecapIndex(db_path, status_path, gaps_path)
            result = source.query(
                {
                    "source": "teams_recaps",
                    "sql": "SELECT '2026-05-01' AS meeting_date, 'latest' AS date_window, '{\"source_id\":\"monarch_r_and_d_teams_recaps\",\"locator\":\"meeting#2026-05-01\"}' AS provenance_grain",
                    "routing_decision": {"intent": "meeting_digest_by_date"},
                    "limit": 5,
                }
            )

        self.assertEqual(result["answer_metadata"]["absolute_date"], "2026-05-01")
        self.assertEqual(result["answer_metadata"]["date_window"], "latest")

    def test_attach_source_actions_handles_bucket_video_and_workbook(self):
        import serve_http

        payload = {
            "rows": [
                {
                    "provenance_grain": '{"grain_type":"assay_media_link","locator":"gs://monarch-videos-new/path/video.mov"}',
                },
                {
                    "provenance_grain": '{"grain_type":"xlsx_cell","locator":"sources/example.xlsx#sheet=Master&cell=D2"}',
                },
            ],
        }

        result = serve_http.attach_source_actions(payload)

        self.assertEqual(result["rows"][0]["source_actions"][0]["label"], "Open/download source video")
        self.assertEqual(result["rows"][0]["source_actions"][0]["transport"], "gcs")
        self.assertEqual(result["rows"][1]["source_actions"][0]["label"], "Open source workbook cell")
        self.assertEqual(result["rows"][1]["source_actions"][0]["transport"], "path")

    def test_attach_source_actions_adds_assay_overlay_for_metric_rows(self):
        import serve_http

        payload = {
            "rows": [
                {
                    "provenance_grain": (
                        '{"grain_type":"csv_row",'
                        '"locator":"gs://monarch-videos-new/mosquitoes/processed/run_results/run_results/advanced_metrics.csv#row=6"}'
                    ),
                },
                {
                    "provenance_grain": (
                        '{"grain_type":"csv_row",'
                        '"locator":"gs://monarch-videos-new/mosquitoes/processed/run_results/run_results/summary.csv#row=6"}'
                    ),
                },
                {
                    "provenance_grain": (
                        '{"grain_type":"csv_row",'
                        '"locator":"gs://monarch-videos-new/contact_repel_videos/flies/processed/2PP_non_contact/frame_metrics.csv#row=10"}'
                    ),
                },
            ],
        }

        result = serve_http.attach_source_actions(payload)

        actions = result["rows"][0]["source_actions"]
        self.assertEqual(actions[0]["label"], "Open/download source CSV")
        self.assertEqual(actions[1]["type"], "assay_overlay")
        self.assertEqual(
            actions[1]["metric_csv"],
            "mosquitoes/processed/run_results/run_results/advanced_metrics.csv",
        )
        self.assertIn("ask-monarch assay-overlay", actions[1]["command"])
        self.assertEqual(len(result["rows"][1]["source_actions"]), 1)
        frame_actions = result["rows"][2]["source_actions"]
        self.assertEqual(frame_actions[1]["type"], "assay_overlay")
        self.assertEqual(
            frame_actions[1]["metric_csv"],
            "contact_repel_videos/flies/processed/2PP_non_contact/frame_metrics.csv",
        )


if __name__ == "__main__":
    unittest.main()
