import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class InstallScriptTest(unittest.TestCase):
    def test_installer_delegates_to_prime_simple_setup(self):
        text = (ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn("uvx ask-monarch setup --code", text)
        self.assertIn("ASK_MONARCH_SETUP_CODE", text)
        self.assertNotIn("exec uvx ask-monarch setup", text)
        self.assertIn("falling back to hosted installer", text)

    def make_hosted_files(self, tmp_path):
        cli_path = tmp_path / "ask_monarch.py"
        cli_path.write_text(
            textwrap.dedent(
                """\
                #!/usr/bin/env python3
                import json
                import os
                import sys

                args = sys.argv[1:]
                command = args[0] if args else ""
                if command == "--url":
                    args = args[2:]
                    command = args[0] if args else ""
                if command == "onboarding-code" and len(args) > 1 and args[1] == "exchange":
                    config_path = os.path.join(os.environ["HOME"], ".config", "ask-monarch", "config.json")
                    os.makedirs(os.path.dirname(config_path), exist_ok=True)
                    with open(config_path, "w", encoding="utf-8") as handle:
                        json.dump({"url": os.environ.get("ASK_MONARCH_URL", "https://ask-monarch.example"), "token": "secret-token"}, handle)
                    print(json.dumps({"ok": True, "configured": True}))
                    sys.exit(0)
                if command == "health":
                    sys.exit(0)
                if command == "summary":
                    print(json.dumps({"ok": True, "python": sys.executable, "wrapper_python": os.environ.get("ASK_MONARCH_WRAPPER_PYTHON")}))
                    sys.exit(0)
                if command == "configure":
                    sys.exit(0)
                if command == "doctor":
                    print(json.dumps({"ok": True, "status": "ready", "required_gaps": []}))
                    sys.exit(0)
                if command == "parity":
                    marker = os.environ.get("ASK_MONARCH_FAKE_PARITY_MARKER")
                    if marker:
                        with open(marker, "w", encoding="utf-8") as handle:
                            handle.write("parity ran\\n")
                    print(json.dumps({"ok": True, "status": "parity_ready", "required_gaps": []}))
                    sys.exit(0)
                print(json.dumps({"ok": False, "error": "unexpected command", "args": args}))
                sys.exit(1)
                """
            ),
            encoding="utf-8",
        )
        cli_path.chmod(0o755)
        routing_decision_path = tmp_path / "routing_decision.py"
        routing_decision_path.write_text("# installer dependency fixture\n", encoding="utf-8")
        evidence_shapes_py_path = tmp_path / "evidence_shapes.py"
        evidence_shapes_py_path.write_text("# evidence shape dependency fixture\n", encoding="utf-8")
        answer_shape_contracts_path = tmp_path / "answer_shape_contracts.py"
        answer_shape_contracts_path.write_text("# answer shape contract dependency fixture\n", encoding="utf-8")
        renderer_path = tmp_path / "render_assay_metric_overlay.py"
        renderer_path.write_text("#!/usr/bin/env python3\n", encoding="utf-8")
        renderer_path.chmod(0o755)
        skills_root = tmp_path / "skills"
        for skill_name in (
            "askmonarch",
            "monarch-source",
            "mosquitometa",
            "flycontactmeta",
            "video-overlay",
            "correction",
            "braintrust",
        ):
            skill_dir = skills_root / skill_name
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text(f"# {skill_name}\n", encoding="utf-8")
        video_scripts = skills_root / "video-overlay" / "scripts"
        video_scripts.mkdir()
        (video_scripts / "circle_landing_overlay.py").write_text("# video overlay fixture\n", encoding="utf-8")
        (video_scripts / "run_videooverlay.py").write_text("# video overlay runner fixture\n", encoding="utf-8")
        video_agents = skills_root / "video-overlay" / "agents"
        video_agents.mkdir()
        (video_agents / "openai.yaml").write_text("model: fixture\n", encoding="utf-8")
        query_routing_path = tmp_path / "query-routing.json"
        query_routing_path.write_text('{"sources": {}}\n', encoding="utf-8")
        source_capabilities_path = tmp_path / "source-capabilities.json"
        source_capabilities_path.write_text('{"sources": {}}\n', encoding="utf-8")
        evidence_shapes_config_path = tmp_path / "evidence-shapes.json"
        evidence_shapes_config_path.write_text('{"version": 1, "shapes": [{"shape_id": "fixture", "description": "fixture", "source_lanes": ["bucket"], "grain": ["row"], "required_fields": ["id"], "adapter": "fixture_sql", "indexes": ["fixture"], "answer_limit": 1, "source_gap_rule": "gap", "fallback_policy": "no_silent_prose_fallback", "trace_fields": ["adapter"], "latency_target_ms": {"p95": 1}, "eval_examples": ["fixture"]}]}\n', encoding="utf-8")
        adapter_modifiers_path = tmp_path / "adapter-modifiers.json"
        adapter_modifiers_path.write_text('{"version": 1, "modifiers": {}, "adapters": {}}\n', encoding="utf-8")
        return cli_path, routing_decision_path, evidence_shapes_py_path, answer_shape_contracts_path, renderer_path, query_routing_path, source_capabilities_path, evidence_shapes_config_path, adapter_modifiers_path, skills_root

    def test_quiet_reset_installs_global_codex_setup_and_uses_setup_code(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            codex_home = tmp_path / ".codex"
            claude_home = tmp_path / ".claude"
            bin_path = home / ".local" / "bin" / "ask-monarch"
            home.mkdir()
            codex_home.mkdir()
            claude_home.mkdir()
            cli_path, routing_decision_path, evidence_shapes_py_path, answer_shape_contracts_path, renderer_path, query_routing_path, source_capabilities_path, evidence_shapes_config_path, adapter_modifiers_path, skills_root = self.make_hosted_files(tmp_path)
            parity_marker = tmp_path / "parity-ran.txt"

            env = {
                **os.environ,
                "HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "CLAUDE_HOME": str(claude_home),
                "ASK_MONARCH_URL": "https://ask-monarch.example",
                "ASK_MONARCH_CLI_URL": cli_path.as_uri(),
                "ASK_MONARCH_PACKAGE_CLI_URL": cli_path.as_uri(),
                "ASK_MONARCH_PACKAGE_AGENT_SETUP_URL": routing_decision_path.as_uri(),
                "ASK_MONARCH_PACKAGE_ROUTING_DECISION_URL": routing_decision_path.as_uri(),
                "ASK_MONARCH_PACKAGE_ANSWER_SHAPE_CONTRACTS_URL": answer_shape_contracts_path.as_uri(),
                "ASK_MONARCH_PACKAGE_INIT_URL": routing_decision_path.as_uri(),
                "ASK_MONARCH_ROUTING_DECISION_URL": routing_decision_path.as_uri(),
                "ASK_MONARCH_EVIDENCE_SHAPES_PY_URL": evidence_shapes_py_path.as_uri(),
                "ASK_MONARCH_ANSWER_SHAPE_CONTRACTS_URL": answer_shape_contracts_path.as_uri(),
                "ASK_MONARCH_QUERY_ROUTING_URL": query_routing_path.as_uri(),
                "ASK_MONARCH_SOURCE_CAPABILITIES_URL": source_capabilities_path.as_uri(),
                "ASK_MONARCH_EVIDENCE_SHAPES_URL": evidence_shapes_config_path.as_uri(),
                "ASK_MONARCH_ADAPTER_MODIFIERS_URL": adapter_modifiers_path.as_uri(),
                "ASK_MONARCH_RENDERER_URL": renderer_path.as_uri(),
                "ASK_MONARCH_SKILLS_URL": skills_root.as_uri(),
                "ASK_MONARCH_BIN": str(bin_path),
                "ASK_MONARCH_SETUP_CODE": "MNR-ABCD-1234",
                "ASK_MONARCH_RESET": "1",
                "ASK_MONARCH_QUIET": "1",
                "ASK_MONARCH_FAKE_PARITY_MARKER": str(parity_marker),
                "PATH": f"{home / '.local' / 'bin'}:{os.environ.get('PATH', '')}",
            }
            result = subprocess.run(
                ["bash", str(ROOT / "install.sh")],
                cwd=str(ROOT),
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), "Ask Monarch is how you have a conversation with the company.")
            self.assertEqual(result.stderr.strip(), "")
            self.assertTrue(bin_path.exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "scripts" / "ask_monarch.py").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "scripts" / "routing_decision.py").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "scripts" / "evidence_shapes.py").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "scripts" / "answer_shape_contracts.py").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "config" / "query-routing.json").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "config" / "source-capabilities.json").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "config" / "evidence-shapes.json").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "config" / "adapter-modifiers.json").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "python" / "config" / "query-routing.json").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "python" / "config" / "source-capabilities.json").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "python" / "config" / "adapter-modifiers.json").exists())
            self.assertTrue((home / ".local" / "share" / "ask-monarch" / "python" / "evidence_shapes.py").exists())
            self.assertIn("ASK_MONARCH_INSTALLER_BEGIN", (codex_home / "AGENTS.md").read_text(encoding="utf-8"))
            self.assertIn("Do not use web search", (codex_home / "AGENTS.md").read_text(encoding="utf-8"))
            self.assertIn("$HOME/.local/bin/ask-monarch", (codex_home / "AGENTS.md").read_text(encoding="utf-8"))
            self.assertTrue((codex_home / "skills" / "askmonarch" / "SKILL.md").exists())
            self.assertIn("[[skills.config]]", (codex_home / "config.toml").read_text(encoding="utf-8"))
            self.assertIn("ASK_MONARCH_INSTALLER_BEGIN", (claude_home / "CLAUDE.md").read_text(encoding="utf-8"))
            self.assertIn("Do not use web search", (claude_home / "CLAUDE.md").read_text(encoding="utf-8"))
            self.assertIn("$HOME/.local/bin/ask-monarch", (claude_home / "CLAUDE.md").read_text(encoding="utf-8"))
            self.assertTrue((claude_home / "skills" / "ask-monarch" / "SKILL.md").exists())
            self.assertTrue(parity_marker.exists())

    def test_installed_wrapper_uses_codex_bundled_python_when_python3_is_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            codex_home = tmp_path / ".codex"
            claude_home = tmp_path / ".claude"
            fakebin = tmp_path / "fakebin"
            bin_path = home / ".local" / "bin" / "ask-monarch"
            bundled_python = home / ".cache" / "codex-runtimes" / "codex-primary-runtime" / "dependencies" / "python" / "bin" / "python3"
            home.mkdir()
            codex_home.mkdir()
            claude_home.mkdir()
            fakebin.mkdir()
            bundled_python.parent.mkdir(parents=True)
            bundled_python.write_text(
                f"#!/usr/bin/env bash\nexport ASK_MONARCH_WRAPPER_PYTHON=bundled\nexec {sys.executable!r} \"$@\"\n",
                encoding="utf-8",
            )
            bundled_python.chmod(0o755)
            cli_path, routing_decision_path, evidence_shapes_py_path, answer_shape_contracts_path, renderer_path, query_routing_path, source_capabilities_path, evidence_shapes_config_path, adapter_modifiers_path, skills_root = self.make_hosted_files(tmp_path)

            env = {
                **os.environ,
                "HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "CLAUDE_HOME": str(claude_home),
                "ASK_MONARCH_URL": "https://ask-monarch.example",
                "ASK_MONARCH_CLI_URL": cli_path.as_uri(),
                "ASK_MONARCH_PACKAGE_CLI_URL": cli_path.as_uri(),
                "ASK_MONARCH_PACKAGE_AGENT_SETUP_URL": routing_decision_path.as_uri(),
                "ASK_MONARCH_PACKAGE_ROUTING_DECISION_URL": routing_decision_path.as_uri(),
                "ASK_MONARCH_PACKAGE_ANSWER_SHAPE_CONTRACTS_URL": answer_shape_contracts_path.as_uri(),
                "ASK_MONARCH_PACKAGE_INIT_URL": routing_decision_path.as_uri(),
                "ASK_MONARCH_ROUTING_DECISION_URL": routing_decision_path.as_uri(),
                "ASK_MONARCH_EVIDENCE_SHAPES_PY_URL": evidence_shapes_py_path.as_uri(),
                "ASK_MONARCH_ANSWER_SHAPE_CONTRACTS_URL": answer_shape_contracts_path.as_uri(),
                "ASK_MONARCH_QUERY_ROUTING_URL": query_routing_path.as_uri(),
                "ASK_MONARCH_SOURCE_CAPABILITIES_URL": source_capabilities_path.as_uri(),
                "ASK_MONARCH_EVIDENCE_SHAPES_URL": evidence_shapes_config_path.as_uri(),
                "ASK_MONARCH_ADAPTER_MODIFIERS_URL": adapter_modifiers_path.as_uri(),
                "ASK_MONARCH_RENDERER_URL": renderer_path.as_uri(),
                "ASK_MONARCH_SKILLS_URL": skills_root.as_uri(),
                "ASK_MONARCH_BIN": str(bin_path),
                "ASK_MONARCH_SETUP_CODE": "MNR-ABCD-1234",
                "ASK_MONARCH_RESET": "1",
                "ASK_MONARCH_QUIET": "1",
                "PATH": f"{fakebin}:{os.environ.get('PATH', '')}",
            }
            install_result = subprocess.run(
                ["/bin/bash", str(ROOT / "install.sh")],
                cwd=str(ROOT),
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(install_result.returncode, 0, install_result.stderr)

            run_result = subprocess.run(
                [str(bin_path), "summary"],
                cwd=str(ROOT),
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(run_result.returncode, 0, run_result.stderr)
            self.assertIn('"ok": true', run_result.stdout)
            self.assertIn('"wrapper_python": "bundled"', run_result.stdout)


if __name__ == "__main__":
    unittest.main()
