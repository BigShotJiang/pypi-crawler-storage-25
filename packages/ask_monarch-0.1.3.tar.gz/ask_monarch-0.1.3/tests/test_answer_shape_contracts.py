import importlib.util
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
CONTRACTS_PATH = ROOT / "scripts" / "answer_shape_contracts.py"


def load_contracts():
    spec = importlib.util.spec_from_file_location("answer_shape_contracts", CONTRACTS_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules["answer_shape_contracts"] = module
    spec.loader.exec_module(module)
    return module


class AnswerShapeContractTests(unittest.TestCase):
    def test_unknown_answer_shape_fails_closed(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "future question",
            {
                "ok": True,
                "routing_decision": {"answer_shape": "future_unregistered_shape"},
                "rows": [{"text": "looks plausible"}],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("has no registered answer contract", " ".join(result["errors"]))

    def test_inventory_list_rejects_summary_row_for_list_all_question(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "list all compounds in our inventory",
            {
                "ok": True,
                "source": "compound_inventory",
                "routing_decision": {"answer_shape": "inventory_list"},
                "rows": [
                    {
                        "compound_count": 905,
                        "first_50_compounds": "2PP, DEET",
                        "provenance_grain": "{}",
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("inventory_list requires compound item rows", " ".join(result["errors"]))

    def test_mixed_ranking_plus_media_requires_media_rows(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "pull up the top 2 repellent compounds and the videos associated",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "mixed_ranking_plus_media"},
                "rows": [
                    {
                        "treatment_normalized": "2PP",
                        "mean_avg_pi": -0.31,
                        "provenance_grain": '{"locator":"assay#1"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("media", " ".join(result["errors"]))

    def test_mixed_ranking_plus_media_accepts_ranking_and_video(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "pull up the top 2 repellent compounds and the videos associated",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "mixed_ranking_plus_media"},
                "rows": [
                    {
                        "treatment_normalized": "2PP",
                        "mean_avg_pi": -0.31,
                        "standard_deviation": 0.07,
                        "standard_deviation_basis": "sample_stddev_of_avg_pi_real_across_dart_rows",
                        "provenance_grain": '{"locator":"assay#1"}',
                    },
                    {
                        "media_uri": "gs://monarch-videos-new/mosquitoes/IMG_0108_NonContact_Menthol.mov",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/mosquitoes/IMG_0108_NonContact_Menthol.mov"}',
                    },
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_ranked_repellents_with_media_requires_media_rows(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "show the video for the top fly repellents",
            {
                "ok": True,
                "source": "route_plan",
                "routing_decision": {"answer_shape": "ranked_repellents_with_media"},
                "rows": [
                    {
                        "treatment_normalized": "2PP",
                        "mean_avg_pi": -0.31,
                        "provenance_grain": '{"locator":"fly#1"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("media", " ".join(result["errors"]))

    def test_ranked_repellents_with_media_accepts_ranking_and_video(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "show the video for the top fly repellents",
            {
                "ok": True,
                "source": "route_plan",
                "routing_decision": {"answer_shape": "ranked_repellents_with_media"},
                "rows": [
                    {
                        "treatment_normalized": "2PP",
                        "mean_avg_pi": -0.31,
                        "standard_deviation": 0.07,
                        "standard_deviation_basis": "sample_stddev_of_avg_pi_real_across_dart_rows",
                        "provenance_grain": '{"locator":"fly#1"}',
                    },
                    {
                        "media_uri": "gs://monarch-videos-new/flies/top-repellent-2PP.mov",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/flies/top-repellent-2PP.mov"}',
                    },
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_ranked_repellents_with_media_does_not_require_standard_deviation_unless_requested(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "pull up the assay and video for the most repellent compound we have tested in flies",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_repellents_with_media"},
                "rows": [
                    {
                        "treatment_label": "1O3OL (20)",
                        "composite_score": 0.8534765899356594,
                        "media_uri": "gs://monarch-videos-new/contact_repel_videos/flies/IMG_0112_Control_1O3OL.mov",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/contact_repel_videos/flies/IMG_0112_Control_1O3OL.mov","result_locator":"gs://monarch-videos-new/flies/summary/agg_summary/top_performing_chemicals.csv#row=1"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_ranked_repellents_with_media_requires_standard_deviation_when_requested(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "show the standard deviation and video for the top fly repellent",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_repellents_with_media"},
                "rows": [
                    {
                        "treatment_label": "1O3OL (20)",
                        "composite_score": 0.8534765899356594,
                        "media_uri": "gs://monarch-videos-new/contact_repel_videos/flies/IMG_0112_Control_1O3OL.mov",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/contact_repel_videos/flies/IMG_0112_Control_1O3OL.mov","result_locator":"gs://monarch-videos-new/flies/summary/agg_summary/top_performing_chemicals.csv#row=1"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("standard deviation", " ".join(result["errors"]))

    def test_cross_assay_repellent_ranking_requires_family_metric_and_provenance(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what are the top repellent compounds",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_cross_assay_repellent_compounds"},
                "rows": [
                    {
                        "compound": "2PP",
                        "mean_avg_pi": -0.31,
                        "provenance_grain": '{"locator":"dart#1"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        joined = " ".join(result["errors"])
        self.assertIn("assay family", joined)
        self.assertIn("metric basis", joined)

    def test_cross_assay_repellent_ranking_accepts_family_metric_and_provenance(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what are the top repellent compounds",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_cross_assay_repellent_compounds"},
                "rows": [
                    {
                        "compound": "IR3535",
                        "assay_family": "contact_no_contact",
                        "species": "mosquitoes",
                        "metric_name": "adj_contact_pi_mean",
                        "metric_value": 0.5087,
                        "standard_deviation": 0.12,
                        "standard_deviation_basis": "frame_level_contact_pi",
                        "rank": 1,
                        "provenance_grain": '{"locator":"contact#1"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_script_method_evidence_requires_script_identity_line_text_and_provenance(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what script computes entropy in the fly metrics?",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "script_method_evidence"},
                "rows": [
                    {
                        "script_name": "scripts/advanced_population_metrics.py",
                        "script_line": 171,
                        "evidence_text": "def compute_entropy(zone_counts):",
                        "script_uri": "gs://monarch-videos-new/scripts/advanced_population_metrics.py",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/scripts/advanced_population_metrics.py#line=171"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_script_method_evidence_rejects_rows_without_script_identity(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what script computes entropy in the fly metrics?",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "script_method_evidence"},
                "rows": [
                    {
                        "script_line": 171,
                        "evidence_text": "def compute_entropy(zone_counts):",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/scripts/advanced_population_metrics.py#line=171"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("script file identity", " ".join(result["errors"]))

    def test_cross_assay_repellent_ranking_rejects_mean_without_uncertainty(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what are the top repellent compounds",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_cross_assay_repellent_compounds"},
                "rows": [
                    {
                        "compound": "IR3535",
                        "assay_family": "contact_no_contact",
                        "species": "mosquitoes",
                        "metric_name": "adj_contact_pi_mean",
                        "metric_value": 0.5087,
                        "rank": 1,
                        "provenance_grain": '{"locator":"contact#1"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("standard deviation", " ".join(result["errors"]))

    def test_cross_assay_repellent_ranking_rejects_sem_without_standard_deviation(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what are the top repellent compounds",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_cross_assay_repellent_compounds"},
                "rows": [
                    {
                        "compound": "IR3535",
                        "assay_family": "fly_repellency",
                        "species": "flies",
                        "metric_name": "composite_score",
                        "metric_value": 0.5087,
                        "standard_error": 0.04,
                        "standard_deviation_basis": "sem_only_mock",
                        "rank": 1,
                        "provenance_grain": '{"locator":"fly#1"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("standard deviation", " ".join(result["errors"]))

    def test_cross_assay_repellent_ranking_rejects_partial_standard_deviation_rows(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what are the top repellent compounds",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_cross_assay_repellent_compounds"},
                "rows": [
                    {
                        "compound": "IR3535",
                        "assay_family": "contact_no_contact",
                        "species": "mosquitoes",
                        "metric_name": "adj_contact_pi_mean",
                        "metric_value": 0.5087,
                        "standard_deviation": 0.12,
                        "standard_deviation_basis": "frame_level_contact_pi",
                        "rank": 1,
                        "provenance_grain": '{"locator":"contact#1"}',
                    },
                    {
                        "compound": "2PP",
                        "assay_family": "fly_repellency",
                        "species": "flies",
                        "metric_name": "composite_score",
                        "metric_value": 0.42,
                        "rank": 2,
                        "provenance_grain": '{"locator":"fly#2"}',
                    },
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("every assay metric row", " ".join(result["errors"]))

    def test_phytotoxicity_ranking_rejects_mean_without_standard_deviation(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "which phytotoxicity treatments have the highest damaged fraction",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_phytotoxicity_compounds"},
                "rows": [
                    {
                        "rank": 1,
                        "compound": "beta-cyclocitral",
                        "avg_damaged_fraction": 0.41,
                        "source_name": "phytotoxicity/results/run/predictions/analysis/features_all.csv",
                        "source_row_number": 12,
                        "provenance_grain": '{"locator":"phyto#12"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("standard deviation", " ".join(result["errors"]))

    def test_species_repellent_ranking_accepts_no_rankable_rows_diagnostic(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "rank the most effective repellents in the dart assay for mosquitoes in the last 1 month",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "ranked_species_repellent_compounds"},
                "rows": [
                    {
                        "ranking_status": "no_rankable_rows",
                        "species": "mosquitoes",
                        "assay_type": "DART",
                        "date_window": "last_1_month",
                        "assay_rows_in_window": 378,
                        "scored_rows_in_window": 0,
                        "example_provenance_grain": '{"grain_type":"dart_assay_row","locator":"gs://monarch-videos-new/mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx#sheet=Assays&row=1000"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_species_scoped_assay_list_rejects_wrong_species_rows(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what fly assays ran last week?",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "assay_run_list"},
                "rows": [
                    {
                        "assay_family": "dart",
                        "assay_date": "2026-05-08",
                        "species": "mosquitoes",
                        "provenance_grain": '{"locator":"row#1"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("species scope", " ".join(result["errors"]))

    def test_assay_result_list_accepts_metric_rows_with_context_and_provenance(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "list the avg pref index in the last 2 weeks of assays",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "assay_result_list"},
                "rows": [
                    {
                        "assay_family": "dart",
                        "assay_type": "DART preference index",
                        "assay_date": "2026-05-08",
                        "date_window": "last_2_weeks",
                        "species": "mosquitoes",
                        "metric_name": "avg_pref_index",
                        "metric_value": -0.31,
                        "result_role": "treatment_mean",
                        "provenance_grain": '{"grain_type":"assay_result","locator":"gs://monarch-videos-new/mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx#sheet=Assays&row=28"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_assay_result_list_rejects_run_rows_without_result_metric(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "list the avg pref index in the last 2 weeks of assays",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "assay_result_list"},
                "rows": [
                    {
                        "assay_family": "dart",
                        "assay_type": "DART assay",
                        "assay_date": "2026-05-08",
                        "species": "mosquitoes",
                        "provenance_grain": '{"grain_type":"assay_run","locator":"gs://monarch-videos-new/mosquitoes/run#28"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("result metric", " ".join(result["errors"]))

    def test_tested_compound_date_window_accepts_compound_date_and_provenance(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "list compounds tested in the last 2 weeks",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "tested_compound_date_window"},
                "rows": [
                    {
                        "tested_compound": "1C4EB",
                        "date_window": "last_2_weeks",
                        "normalized_latest_evidence_date": "2026-05-09",
                        "provenance_grain": '{"locator":"row#1"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_people_roster_requires_provenance(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "list all employees",
            {
                "ok": True,
                "source": "people_directory",
                "routing_decision": {"answer_shape": "roster_list"},
                "rows": [{"name": "Joel Kowalewski", "role": "CTO"}],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("provenance", " ".join(result["errors"]))

    def test_fly_assay_count_accepts_metadata_count_row(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "how many total assays have we run on flies",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "fly_assay_count"},
                "rows": [
                    {
                        "species": "flies",
                        "assay_family": "fly repellency screen metadata",
                        "trial_rows": 1015,
                        "distinct_filenames": 140,
                        "count_unit": "distinct_filenames_are_assay_runs; trial_rows_are_tube_rows",
                        "date_range": "2026-01-08 to 2026-05-08",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx#sheet=trials&rows=2-1016"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_fly_assay_count_rejects_dart_summary_row(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "how many total assays have we run on flies",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "fly_assay_count"},
                "rows": [
                    {
                        "species": "mosquitoes",
                        "assay_family": "dart",
                        "n": 1345,
                        "provenance_grain": '{"locator":"mosquito dart"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        joined = " ".join(result["errors"])
        self.assertIn("fly assay count fields", joined)
        self.assertIn("fly-scoped", joined)

    def test_assay_inventory_count_accepts_explicit_count_grain(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "how many assays were run in the last 30 days for flies and mosquitoes",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "assay_inventory_count"},
                "rows": [
                    {
                        "assay_family": "contact_no_contact",
                        "species": "mosquitoes",
                        "assay_type": "raw contact/no-contact video",
                        "assay_mode": "contact",
                        "date_window": "last_30_days",
                        "count_unit": "raw_video_objects",
                        "assay_count": 29,
                        "unit_count": 29,
                        "file_count": 29,
                        "latest_evidence_date": "2026-05-08",
                        "provenance_grain": '{"grain_type":"assay_inventory_count","locator":"gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_environment_conditions_accepts_species_metric_and_conditions(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what is the temp and humidity at which we found the most promising results in our assays",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "assay_best_result_environment_conditions"},
                "rows": [
                    {
                        "species": "mosquitoes",
                        "assay_family": "dart",
                        "compound": "2PP",
                        "temperature_c": 26.8,
                        "relative_humidity_pct": 57,
                        "metric_name": "avg_pi",
                        "metric_value": -0.858,
                        "provenance_grain": '{"locator":"mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx#sheet=Assays&row=28"}',
                    },
                    {
                        "species": "flies",
                        "assay_family": "fly_repellency",
                        "compound": "C3HB",
                        "temperature_c": 22.8,
                        "relative_humidity_pct": 50,
                        "metric_name": "corrected_mean_trt_pi",
                        "metric_value": -0.7862,
                        "provenance_grain": '{"locator":"flies/processed/run/corrected/pi_correction_summary.csv#row=1"}',
                    },
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_environment_conditions_accepts_source_gap_rows_for_unindexed_metadata(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "what temp seems ideal for contact / no contact repellency",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "assay_best_result_environment_conditions"},
                "rows": [
                    {
                        "environment_status": "source_gap",
                        "species": "mosquitoes",
                        "assay_family": "contact_no_contact",
                        "assay_mode": "contact/no-contact",
                        "source_gap_reason": "contact/no-contact summaries have effect metrics but no indexed temperature or humidity fields",
                        "provenance_grain": '{"locator":"contact_repel_videos/mosquitoes_new_solvent/processed/adjusted_contact_pi_summary.csv"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_contact_noncontact_comparison_requires_both_modes(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "compare contact and non-contact repellents against each other",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "contact_noncontact_ranked_comparison"},
                "rows": [
                    {
                        "rank": 1,
                        "assay_mode": "contact",
                        "compound": "PepOil",
                        "adj_contact_pi_mean": 0.674,
                        "provenance_grain": '{"locator":"contact#41"}',
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("both contact and non-contact", " ".join(result["errors"]))

    def test_contact_noncontact_comparison_accepts_ranked_adjusted_rows(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "compare contact and non-contact repellents against each other",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "contact_noncontact_ranked_comparison"},
                "rows": [
                    {
                        "rank": 1,
                        "assay_mode": "contact",
                        "compound": "PepOil",
                        "adj_contact_pi_mean": 0.674,
                        "metric_name": "adj_contact_pi_mean",
                        "standard_deviation": 0.11,
                        "standard_deviation_basis": "frame_level_contact_pi",
                        "provenance_grain": '{"locator":"contact#41"}',
                    },
                    {
                        "rank": 1,
                        "assay_mode": "non_contact",
                        "compound": "2PP",
                        "adj_contact_pi_mean": 0.430,
                        "metric_name": "adj_contact_pi_mean",
                        "standard_deviation": 0.09,
                        "standard_deviation_basis": "frame_level_contact_pi",
                        "provenance_grain": '{"locator":"noncontact#18"}',
                    },
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_contact_noncontact_comparison_rejects_mean_without_uncertainty(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "compare contact and non-contact repellents against each other",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "contact_noncontact_ranked_comparison"},
                "rows": [
                    {
                        "rank": 1,
                        "assay_mode": "contact",
                        "compound": "PepOil",
                        "adj_contact_pi_mean": 0.674,
                        "metric_name": "adj_contact_pi_mean",
                        "provenance_grain": '{"locator":"contact#41"}',
                    },
                    {
                        "rank": 1,
                        "assay_mode": "non-contact",
                        "compound": "2PP",
                        "adj_contact_pi_mean": 0.430,
                        "metric_name": "adj_contact_pi_mean",
                        "provenance_grain": '{"locator":"noncontact#18"}',
                    },
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertIn("standard deviation", " ".join(result["errors"]))

    def test_recent_contact_noncontact_assays_accepts_count_rows(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "how many contact / no contact assays were run in last 30 days for flies and for mosquitoes",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "recent_contact_no_contact_assays"},
                "rows": [
                    {
                        "species": "flies",
                        "assay_mode": "contact",
                        "assay_family": "contact_no_contact",
                        "date_window": "last_30_days",
                        "date_basis": "bucket_object_updated_or_created_time",
                        "count_unit": "raw_video_objects",
                        "assay_count": 1,
                        "video_count": 1,
                        "provenance_grain": '{"grain_type":"contact_no_contact_assay_count","locator":"gs://monarch-videos-new/contact_repel_videos/flies/"}',
                    },
                    {
                        "species": "mosquitoes",
                        "assay_mode": "non_contact",
                        "assay_family": "contact_no_contact",
                        "date_window": "last_30_days",
                        "date_basis": "bucket_object_updated_or_created_time",
                        "count_unit": "raw_video_objects",
                        "assay_count": 12,
                        "video_count": 12,
                        "provenance_grain": '{"grain_type":"contact_no_contact_assay_count","locator":"gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/"}',
                    },
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_rank_expectation_accepts_target_rank_context(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "for the contact, DEET should be in the top - why is it not there",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "rank_expectation_explanation"},
                "rows": [
                    {
                        "compound": "DEET",
                        "actual_rank": 8,
                        "assay_mode": "contact",
                        "adj_contact_pi_mean": 0.381,
                        "ranking_metric": "adj_contact_pi_mean",
                        "nearby_rank": 7,
                        "nearby_compound": "IR3535",
                        "provenance_grain": '{"locator":"contact#19"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_assay_summary_file_explanation_accepts_schema_and_version_rows(self):
        contracts = load_contracts()

        result = contracts.validate_answer_payload(
            "explain the newer adjusted summary",
            {
                "ok": True,
                "source": "bucket",
                "routing_decision": {"answer_shape": "assay_summary_file_explanation"},
                "rows": [
                    {
                        "source_file": "contact_repel_videos/mosquitoes_new_solvent/processed/adjusted_contact_pi_summary.csv",
                        "row_count": 51,
                        "updated": "2026-05-09T00:00:00Z",
                        "column_name": "video_stem, is_control, adj_contact_pi_mean",
                        "metric_definition": "higher values indicate stronger adjusted contact repellency",
                        "file_version": "newer_adjusted_summary",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/processed/adjusted_contact_pi_summary.csv"}',
                    }
                ],
            },
        )

        self.assertTrue(result["ok"], result["errors"])

    def test_enforcement_converts_shape_mismatch_to_source_gap(self):
        contracts = load_contracts()

        result = contracts.enforce_answer_contract(
            "list all compounds in our inventory",
            {
                "ok": True,
                "mode": "sql",
                "source": "compound_inventory",
                "routing_decision": {"answer_shape": "inventory_list"},
                "rows": [{"compound_count": 905, "provenance_grain": "{}"}],
            },
        )

        self.assertFalse(result["ok"])
        self.assertEqual(result["mode"], "source_gap")
        self.assertEqual(result["error"], "answer_shape_gap")
        self.assertEqual(result["source_gap"]["reason"], "answer_shape_gap")
        self.assertEqual(result["source_gap"]["expected_answer_shape"], "inventory_list")


if __name__ == "__main__":
    unittest.main()
