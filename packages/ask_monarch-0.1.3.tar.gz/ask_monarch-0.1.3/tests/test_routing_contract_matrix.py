import json
import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
FIXTURE = os.path.join(ROOT, "tests", "fixtures", "routing_contract_questions.jsonl")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


def _load_cases():
    cases = []
    with open(FIXTURE, "r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            case = json.loads(line)
            case["_line_number"] = line_number
            cases.append(case)
    return cases


def _sql_for(payload):
    return " ".join(str(payload.get("sql", "")).split())


class RoutingContractMatrixTests(unittest.TestCase):
    def test_every_contract_case_names_a_question_family(self):
        cases = _load_cases()
        for case in cases:
            label = case.get("id") or f"line-{case['_line_number']}"
            with self.subTest(label=label):
                self.assertIn("expected_question_family", case)
                self.assertTrue(case["expected_question_family"])

    def test_routing_contract_questions_land_on_expected_shapes(self):
        import routing_decision

        cases = _load_cases()
        self.assertGreaterEqual(len(cases), 80)

        for case in cases:
            label = case.get("id") or f"line-{case['_line_number']}"
            with self.subTest(label=label, question=case["question"]):
                payload = routing_decision.query_payload_for_question(
                    case["question"],
                    case.get("source", "auto"),
                    limit=case.get("limit", 20),
                )
                route = payload.get("routing_decision") or {}
                sql = _sql_for(payload)

                if "expected_source" in case:
                    self.assertEqual(payload.get("source"), case["expected_source"])
                if "expected_question_family" in case:
                    self.assertEqual(route.get("question_family"), case["expected_question_family"])
                if "expected_answer_shape" in case:
                    self.assertEqual(route.get("answer_shape"), case["expected_answer_shape"])
                if "expected_adapter" in case:
                    self.assertEqual(route.get("adapter"), case["expected_adapter"])
                if "expected_intent" in case:
                    self.assertEqual(route.get("intent"), case["expected_intent"])
                if "expected_retrieval_shape" in case:
                    self.assertEqual(route.get("retrieval_shape"), case["expected_retrieval_shape"])

                detected_modifiers = set((route.get("modifier_trace") or {}).get("detected_modifiers") or [])
                for modifier in case.get("required_modifiers", []):
                    self.assertIn(modifier, detected_modifiers)
                for modifier in case.get("forbidden_modifiers", []):
                    self.assertNotIn(modifier, detected_modifiers)

                for required in case.get("required_sql_contains", []):
                    self.assertIn(required, sql)
                for forbidden in case.get("forbidden_sql_contains", []):
                    self.assertNotIn(forbidden, sql)

                if case.get("requires_sql", True):
                    self.assertIn("sql", payload)


if __name__ == "__main__":
    unittest.main()
