from __future__ import annotations

import base64
import gzip
import json
import os
import platform
import re
import sys
import uuid
from pathlib import Path
from typing import Dict
from urllib.parse import quote

from deepline_core.command_decorators import SubcommandRouter
from deepline_core.command_decorators import build_command_handler
from deepline_core.command_common import SHARE_SESSION_USER_PROMPTS_ENV, parse_cli_bool, read_cli_text_input, require_api_key
from deepline_core.command_common import EXIT_AUTH, EXIT_OK, EXIT_SERVER, EXIT_USAGE, EXIT_VALIDATION
from deepline_core.http import http_request, report_failure, should_report_failure

router = SubcommandRouter()


_WINDOWS_DRIVE_PATH_RE = re.compile(r"^[A-Za-z]:[\\/]")


def _basename_shell(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    normalized = raw.replace("\\", "/").rstrip("/")
    return normalized.rsplit("/", 1)[-1].lower()


def _detect_shell_context() -> dict:
    shell_path = str(os.environ.get("SHELL") or "").strip()
    shell_source = "SHELL" if shell_path else ""
    if not shell_path:
        shell_path = str(os.environ.get("ComSpec") or os.environ.get("COMSPEC") or "").strip()
        shell_source = "ComSpec" if shell_path else ""

    shell_name = _basename_shell(shell_path)
    if shell_name.endswith(".exe"):
        shell_name = shell_name[:-4]
    if not shell_name and os.environ.get("PSModulePath"):
        shell_name = "powershell"
        shell_source = "PSModulePath"

    cwd = os.getcwd()
    path_style = _detect_path_style(cwd)
    return {
        "shell": shell_name or "unknown",
        "shell_path": shell_path or None,
        "shell_source": shell_source or None,
        "os": platform.system() or sys.platform,
        "sys_platform": sys.platform,
        "cwd": cwd,
        "path_style": path_style,
    }


def _detect_path_style(path: str) -> str:
    value = str(path or "").strip()
    if _WINDOWS_DRIVE_PATH_RE.match(value):
        return "windows"
    if value.startswith("/") and re.match(r"^/[A-Za-z]/", value):
        return "msys"
    if value.startswith("/"):
        return "posix"
    if "\\" in value:
        return "windows"
    return "relative_or_unknown"


def _format_session_context(context: dict) -> str:
    shell = context.get("shell") or "unknown"
    os_name = context.get("os") or "unknown"
    path_style = context.get("path_style") or "unknown"
    cwd = context.get("cwd") or ""
    return f"Session context: shell={shell}, os={os_name}, path_style={path_style}, cwd={cwd}"


def _resolve_cli_session_id(explicit_id: str | None = None) -> str:
    """Resolve a stable session ID for the current CLI session.

    Resolution order:
    1. Explicit --session-id flag
    2. DEEPLINE_SESSION_ID env var
    3. JSONL auto-detect: most recently modified Claude/Codex/Cursor transcript
    4. Fallback: generate a fresh UUID
    """
    # 1. Explicit
    if explicit_id and explicit_id.strip():
        return explicit_id.strip()

    # 2. Env var
    from_env = os.environ.get("DEEPLINE_SESSION_ID", "").strip()
    if from_env:
        return from_env

    # 3. JSONL auto-detect
    sid = _detect_session_from_jsonl()
    if sid:
        return sid

    # 4. Fallback: fresh UUID
    return str(uuid.uuid4())


def _detect_session_from_jsonl() -> str | None:
    """Find the most recently modified local transcript and extract a session id."""
    home = Path(os.environ.get("HOME", str(Path.home())))
    candidate_patterns = (
        # Claude Code transcripts.
        (home / ".claude" / "projects", "*/*.jsonl"),
        # Codex local transcripts.
        (home / ".codex" / "sessions", "**/*.jsonl"),
        # Cursor agent transcripts (top-level transcript files only, not subagents).
        (home / ".cursor" / "projects", "**/agent-transcripts/*/*.jsonl"),
    )

    candidates: list[tuple[float, Path]] = []
    for root, pattern in candidate_patterns:
        if not root.is_dir():
            continue
        for transcript in root.glob(pattern):
            try:
                mtime = transcript.stat().st_mtime
            except Exception:
                continue
            candidates.append((mtime, transcript))

    if not candidates:
        return None

    import time
    now = time.time()
    # Prefer newest transcript, but skip malformed/unparseable entries.
    for mtime, transcript in sorted(candidates, key=lambda item: item[0], reverse=True):
        if now - mtime > 60:
            # Remaining entries are older because we're iterating newest->oldest.
            break
        session_id = _extract_session_id_from_transcript(transcript)
        if session_id:
            return session_id

    return None


_UUID_RE = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")


def _extract_session_id_from_transcript(path: Path) -> str | None:
    """Extract session identity from transcript filename or first JSONL line."""
    stem = str(path.stem or "").strip()
    if stem:
        # Fast path: exact UUID filename (Claude/Cursor).
        try:
            uuid.UUID(stem)
            return stem
        except Exception:
            pass
        # Codex-style filenames may include UUID suffixes.
        stem_uuid_matches = _UUID_RE.findall(stem)
        if stem_uuid_matches:
            return stem_uuid_matches[-1]

    try:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            first_line = handle.readline().strip()
    except Exception:
        return None

    if not first_line:
        return None

    # Try structured extraction first.
    try:
        payload = json.loads(first_line)
    except Exception:
        payload = None

    if isinstance(payload, dict):
        extracted = _extract_session_id_from_payload(payload)
        if extracted:
            return extracted

    # Last fallback: regex scan.
    line_uuid_matches = _UUID_RE.findall(first_line)
    if line_uuid_matches:
        return line_uuid_matches[0]
    return None


def _extract_session_id_from_payload(value) -> str | None:
    """Recursively scan a JSON object for session-like id fields."""
    if isinstance(value, dict):
        for key in ("session_id", "sessionId", "thread_id", "threadId", "id"):
            candidate = value.get(key)
            if isinstance(candidate, str):
                normalized = candidate.strip()
                if normalized:
                    return normalized
        for nested in value.values():
            found = _extract_session_id_from_payload(nested)
            if found:
                return found
        return None
    if isinstance(value, list):
        for item in value:
            found = _extract_session_id_from_payload(item)
            if found:
                return found
    return None


_EMBEDDED_VIEWER_CSS_B64 = "__VIEWER_CSS_B64__"
_EMBEDDED_VIEWER_JS_B64 = "__VIEWER_JS_B64__"

_FALLBACK_VIEWER_CSS = """
body { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; margin: 0; padding: 16px; background: #fafafa; color: #111; }
.section { background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 12px; margin-bottom: 12px; }
.section h2 { margin: 0 0 8px 0; font-size: 14px; }
pre { margin: 0; white-space: pre-wrap; word-break: break-word; background: #f6f8fa; border: 1px solid #e3e5e8; border-radius: 6px; padding: 10px; }
""".strip()

_FALLBACK_VIEWER_JS = """
(function () {
  const root = document.getElementById("main-content");
  const rawEl = document.getElementById("raw-sessions");
  if (!root || !rawEl) return;
  let sessions = [];
  try { sessions = JSON.parse(rawEl.textContent || "[]"); } catch (_) { sessions = []; }
  root.innerHTML = "";
  sessions.forEach((session) => {
    const section = document.createElement("section");
    section.className = "section";
    const title = document.createElement("h2");
    title.textContent = String(session.label || "session");
    const pre = document.createElement("pre");
    const events = Array.isArray(session.events) ? session.events : [];
    pre.textContent = events.map((e) => JSON.stringify(e)).join("\\n");
    section.appendChild(title);
    section.appendChild(pre);
    root.appendChild(section);
  });
})();
""".strip()

_MAX_SESSION_UPLOAD_BYTES = 3_500_000
_CHUNK_SIZE_BYTES = 2_500_000  # 2.5MB raw → ~3.3MB b64, safe under Vercel's ~4.5MB body limit
_MAX_EVENT_STRING_CHARS = 8_000
_MAX_EVENT_LIST_ITEMS = 40
_MAX_EVENT_DICT_ITEMS = 80
_TRUNCATION_MARKER = "...[truncated]"

# Event types that are pure streaming noise — stripped before any compression
_NOISE_EVENT_TYPES = frozenset({"progress", "file-history-snapshot"})


def usage_session_computed() -> list[str]:
    return router.usage_lines("deepline session")


def _truncate_string(value: str, limit: int = _MAX_EVENT_STRING_CHARS) -> str:
    if len(value) <= limit:
        return value
    keep = max(0, limit - len(_TRUNCATION_MARKER))
    return value[:keep] + _TRUNCATION_MARKER


def _compact_event_value(value):
    if isinstance(value, str):
        return _truncate_string(value)
    if isinstance(value, list):
        compacted = [_compact_event_value(item) for item in value[:_MAX_EVENT_LIST_ITEMS]]
        if len(value) > _MAX_EVENT_LIST_ITEMS:
            compacted.append(f"{_TRUNCATION_MARKER} {len(value) - _MAX_EVENT_LIST_ITEMS} more item(s)")
        return compacted
    if isinstance(value, dict):
        compacted: dict = {}
        items = list(value.items())
        for key, item in items[:_MAX_EVENT_DICT_ITEMS]:
            compacted[key] = _compact_event_value(item)
        if len(items) > _MAX_EVENT_DICT_ITEMS:
            compacted["_truncated_keys"] = len(items) - _MAX_EVENT_DICT_ITEMS
        return compacted
    return value


def _strip_noise_events(raw: bytes) -> bytes:
    """Strip progress/file-history-snapshot events — they're streaming noise."""
    lines: list[str] = []
    for line in raw.decode("utf-8", errors="replace").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            parsed = json.loads(stripped)
        except Exception:
            lines.append(stripped)
            continue
        if isinstance(parsed, dict) and parsed.get("type") in _NOISE_EVENT_TYPES:
            continue
        lines.append(stripped)
    return ("\n".join(lines) + ("\n" if lines else "")).encode("utf-8")


def _dedup_consecutive_events(raw: bytes) -> bytes:
    """Collapse runs of repeating user/assistant exchanges into a single pair with _repeat_count.

    Handles both same-type runs (A A A) and the common alternating pattern (A U A U A U).
    Two events are considered identical if they share the same `type` and message content.
    UUIDs, timestamps, and metadata are excluded from the comparison key.

    Example: 297k alternating "Invalid API key" + "Stop hook feedback" messages collapse to
    one assistant event and one user event, each annotated with _repeat_count.
    """

    def _content_key(parsed: dict) -> str | None:
        msg = parsed.get("message", {})
        if not isinstance(msg, dict):
            return None
        content = msg.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            texts = []
            for block in content:
                if isinstance(block, dict):
                    btype = block.get("type", "")
                    if btype == "tool_use":
                        # Include tool name + id so different tool calls are never deduped
                        texts.append(f"tool_use:{block.get('name', '')}:{block.get('id', '')}")
                    elif btype == "tool_result":
                        texts.append(f"tool_result:{block.get('tool_use_id', '')}")
                    else:
                        texts.append(block.get("text") or btype or "")
                else:
                    texts.append(str(block))
            return "\n".join(texts)
        return None

    parsed_events: list[dict | None] = []  # None = unparseable, kept as raw
    raw_lines: list[str] = []

    for line in raw.decode("utf-8", errors="replace").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        raw_lines.append(stripped)
        try:
            parsed_events.append(json.loads(stripped))
        except Exception:
            parsed_events.append(None)

    n = len(parsed_events)
    out_lines: list[str] = []
    i = 0
    while i < n:
        ev = parsed_events[i]
        if not isinstance(ev, dict) or ev.get("type") not in ("user", "assistant"):
            out_lines.append(raw_lines[i])
            i += 1
            continue

        ev_type = ev.get("type")
        ev_key = _content_key(ev)
        if ev_key is None:
            out_lines.append(raw_lines[i])
            i += 1
            continue

        # Try to detect a repeating pair: (ev_type, next_type) pattern
        # e.g. assistant → user → assistant → user
        if i + 1 < n and isinstance(parsed_events[i + 1], dict):
            next_ev = parsed_events[i + 1]
            next_type = next_ev.get("type") if next_ev else None
            next_key = _content_key(next_ev) if next_ev else None
            if (
                next_type in ("user", "assistant")
                and next_type != ev_type
                and next_key is not None
            ):
                # Count how many times this (ev, next_ev) pair repeats
                pair_count = 1
                j = i + 2
                while j + 1 < n:
                    a = parsed_events[j]
                    b = parsed_events[j + 1]
                    if (
                        isinstance(a, dict)
                        and isinstance(b, dict)
                        and a.get("type") == ev_type
                        and b.get("type") == next_type
                        and _content_key(a) == ev_key
                        and _content_key(b) == next_key
                    ):
                        pair_count += 1
                        j += 2
                    else:
                        break
                if pair_count > 1:
                    ev["_repeat_count"] = pair_count
                    ev["_repeat_summary"] = (
                        f"{pair_count} identical {ev_type}+{next_type} exchange(s) collapsed"
                    )
                    next_ev["_repeat_count"] = pair_count
                    next_ev["_repeat_summary"] = (
                        f"{pair_count} identical {ev_type}+{next_type} exchange(s) collapsed"
                    )
                    out_lines.append(json.dumps(ev, ensure_ascii=False, separators=(",", ":")))
                    out_lines.append(json.dumps(next_ev, ensure_ascii=False, separators=(",", ":")))
                    i = j
                    continue

        # Try same-type consecutive run: A A A
        run_count = 1
        j = i + 1
        while j < n and isinstance(parsed_events[j], dict) and parsed_events[j].get("type") == ev_type and _content_key(parsed_events[j]) == ev_key:  # type: ignore[arg-type]
            run_count += 1
            j += 1
        if run_count > 1:
            ev["_repeat_count"] = run_count
            ev["_repeat_summary"] = f"{run_count} consecutive identical {ev_type} messages collapsed"
        out_lines.append(json.dumps(ev, ensure_ascii=False, separators=(",", ":")))
        i = j if run_count > 1 else i + 1

    return ("\n".join(out_lines) + ("\n" if out_lines else "")).encode("utf-8")


def _selective_compact_tool_results(raw: bytes) -> bytes:
    """Only truncate tool_result content blocks inside user messages.

    Leaves assistant text, tool_use inputs, and system events intact.
    """
    lines: list[str] = []
    for line in raw.decode("utf-8", errors="replace").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            parsed = json.loads(stripped)
        except Exception:
            lines.append(stripped)
            continue
        if isinstance(parsed, dict) and parsed.get("type") == "user":
            msg = parsed.get("message", {})
            content = msg.get("content")
            if isinstance(content, list):
                compacted_content = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_result":
                        compacted_content.append(_compact_event_value(block))
                    else:
                        compacted_content.append(block)
                msg["content"] = compacted_content
        lines.append(json.dumps(parsed, ensure_ascii=False, separators=(",", ":")))
    return ("\n".join(lines) + ("\n" if lines else "")).encode("utf-8")


def _build_session_upload_content(raw: bytes) -> tuple[str, bool]:
    """Returns (encoded_content, needs_chunking).

    Tries progressively heavier compaction. If everything fits in a single
    request, returns (b64_gzipped, False). If still too large, returns
    (b64_gzipped_of_best_effort, True) so the caller can chunk.
    """
    # Stage 1: strip noise events + deduplicate consecutive identical messages
    stripped = _strip_noise_events(raw)
    deduped = _dedup_consecutive_events(stripped)

    compressed = gzip.compress(deduped)
    encoded = base64.b64encode(compressed).decode("ascii")
    if len(encoded) <= _MAX_SESSION_UPLOAD_BYTES:
        return encoded, False

    # Stage 2: selective compaction (tool_result content only)
    compacted = _selective_compact_tool_results(deduped)
    compressed = gzip.compress(compacted)
    encoded = base64.b64encode(compressed).decode("ascii")
    if len(encoded) <= _MAX_SESSION_UPLOAD_BYTES:
        return encoded, False

    # Stage 3: still too large — return gzipped bytes for chunked upload
    # Return the gzip of the compacted version (best we can do)
    return base64.b64encode(compressed).decode("ascii"), True


def _find_session_file(session_id: str | None, current: bool) -> tuple[str | None, str | None]:
    root = Path(os.environ.get("HOME", str(Path.home()))) / ".claude" / "projects"
    if current:
        newest_path: Path | None = None
        newest_mtime = -1.0
        for path in root.glob("*/*.jsonl"):
            try:
                mtime = path.stat().st_mtime
            except Exception:
                continue
            if mtime > newest_mtime:
                newest_mtime = mtime
                newest_path = path
        if newest_path is None:
            return None, None
        return newest_path.stem, str(newest_path)
    if not session_id:
        return None, None
    try:
        uuid.UUID(session_id)
    except Exception:
        return None, None
    for path in root.glob(f"*/{session_id}.jsonl"):
        if path.is_file():
            return session_id, str(path)
    return None, None


def _resolve_session_id_and_file(
    session_id: str | None, current: bool
) -> tuple[int | None, str | None, str | None]:
    if current:
        sid, fpath = _find_session_file("", True)
        if sid and fpath:
            return None, sid, fpath
        print("No session files found in ~/.claude/projects/*/", file=os.sys.stderr)
        return EXIT_VALIDATION, None, None

    normalized = (session_id or "").strip()
    if not normalized:
        print("Either --session-id or --current-session is required.", file=os.sys.stderr)
        return EXIT_USAGE, None, None
    if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", normalized):
        print(
            "Invalid session ID format. Expected a UUID (e.g. 5a3bfb97-a2d9-49d9-82c6-52ccc03dadca).",
            file=os.sys.stderr,
        )
        return EXIT_VALIDATION, None, None

    sid, fpath = _find_session_file(normalized, False)
    if sid and fpath:
        return None, sid, fpath
    print(f"Session file not found: ~/.claude/projects/*/{normalized}.jsonl", file=os.sys.stderr)
    return EXIT_VALIDATION, None, None


def _load_viewer_assets() -> tuple[str, str]:
    css_unset = "__VIEWER" "_CSS_B64__"
    js_unset = "__VIEWER" "_JS_B64__"
    if _EMBEDDED_VIEWER_CSS_B64 != css_unset and _EMBEDDED_VIEWER_JS_B64 != js_unset:
        try:
            return (
                base64.b64decode(_EMBEDDED_VIEWER_CSS_B64).decode("utf-8"),
                base64.b64decode(_EMBEDDED_VIEWER_JS_B64).decode("utf-8"),
            )
        except Exception:
            pass

    candidates: list[Path] = []
    env_dir = os.environ.get("DEEPLINE_CLI_VIEWER_DIR", "").strip()
    if env_dir:
        candidates.append(Path(env_dir))
    # Local repo layout: src/lib/cli/python/deepline_core/commands/session.py -> parents[3] == src/lib/cli
    candidates.append(Path(__file__).resolve().parents[3] / "viewer")
    # Common site-packages layout fallback
    candidates.append(Path(__file__).resolve().parents[2] / "viewer")

    for base in candidates:
        css_path = base / "viewer.css"
        js_path = base / "viewer.js"
        if css_path.is_file() and js_path.is_file():
            return (
                css_path.read_text(encoding="utf-8"),
                js_path.read_text(encoding="utf-8"),
            )

    print(
        "Viewer assets not found; using built-in fallback renderer.",
        file=os.sys.stderr,
    )
    return _FALLBACK_VIEWER_CSS, _FALLBACK_VIEWER_JS


def _compact_api_error_message(body: str, *, max_chars: int = 280) -> str:
    raw = str(body or "").strip()
    if not raw:
        return "unknown error"
    message = raw
    try:
        parsed = json.loads(raw)
    except Exception:
        parsed = None
    if isinstance(parsed, dict):
        candidate = parsed.get("error") or parsed.get("message") or parsed.get("details")
        if isinstance(candidate, str) and candidate.strip():
            message = candidate.strip()
        else:
            message = raw
    message = re.sub(r"\s+", " ", message).strip()
    if len(message) > max_chars:
        return f"{message[:max_chars - 3]}..."
    return message


def _warn_cli_event_non_fatal(action: str, status_code: int, body: str) -> int:
    message = _compact_api_error_message(body)
    print(
        f"Warning: {action} skipped (status {status_code}): {message}",
        file=os.sys.stderr,
    )
    return EXIT_OK


@router.route(
    "send",
    summary="Upload session(s) or a file to backend.",
    usage="deepline session send [--session-id UUID [--label L]]... [--current-session] [--file PATH] [--json]",
)
def handle_send(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    session_ids: list[str] = []
    labels: list[str] = []
    file_path = ""
    current = False
    output_json = False
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--session-id":
            if i + 1 >= len(args):
                print("Missing value for --session-id", file=os.sys.stderr)
                return EXIT_USAGE
            session_ids.append(args[i + 1])
            i += 2
            continue
        if arg == "--label":
            if i + 1 >= len(args):
                print("Missing value for --label", file=os.sys.stderr)
                return EXIT_USAGE
            labels.append(args[i + 1])
            i += 2
            continue
        if arg == "--file":
            if i + 1 >= len(args):
                print("Missing value for --file", file=os.sys.stderr)
                return EXIT_USAGE
            file_path = args[i + 1]
            i += 2
            continue
        if arg == "--current-session":
            current = True
            i += 1
            continue
        if arg == "--json":
            output_json = True
            i += 1
            continue
        if arg.startswith("--"):
            print(f"Unknown session send option: {arg}", file=os.sys.stderr)
            return EXIT_USAGE
        i += 1

    if not session_ids and not current and not file_path:
        print("One of --session-id, --current-session, or --file is required.", file=os.sys.stderr)
        return EXIT_USAGE

    missing = require_api_key(env)
    if missing is not None:
        return missing

    # --- Mode 1: Raw file upload ---
    if file_path:
        fp = Path(file_path)
        if not fp.is_file():
            print(f"File not found: {file_path}", file=os.sys.stderr)
            return EXIT_VALIDATION
        raw = fp.read_bytes()
        payload: dict = {
            "file": base64.b64encode(raw).decode("ascii"),
            "filename": fp.name,
        }
        return _send_payload(base_url, env, payload, output_json, f"File '{fp.name}' uploaded to #internal-reports.")

    # --- Mode 2: Session(s) ---
    resolved: list[tuple[str, str, str]] = []  # (session_id, file_path, label)
    if current:
        err, sid, fpath = _resolve_session_id_and_file("", True)
        if err is not None:
            return err
        if sid and fpath:
            resolved.append((sid, fpath, f"session-{sid}"))
    for idx, sid_arg in enumerate(session_ids):
        err, sid, fpath = _resolve_session_id_and_file(sid_arg, False)
        if err is not None:
            return err
        if sid and fpath:
            label = labels[idx] if idx < len(labels) else f"session-{sid}"
            resolved.append((sid, fpath, label))

    if not resolved:
        print("No sessions resolved. Check --session-id or --current-session.", file=os.sys.stderr)
        return EXIT_VALIDATION

    # Build content for each session, detect if any need chunking
    built: list[tuple[str, str, str, str, bool]] = []  # (sid, fpath, label, encoded, needs_chunking)
    for sid, fpath, label in resolved:
        raw = Path(fpath).read_bytes()
        content, needs_chunking = _build_session_upload_content(raw)
        built.append((sid, fpath, label, content, needs_chunking))

    any_chunked = any(nc for _, _, _, _, nc in built)

    if any_chunked:
        # Chunked upload path
        return _send_chunked(base_url, env, built, output_json)

    # Single-request path
    if len(built) == 1 and not labels:
        sid, _, _, content, _ = built[0]
        payload = {
            "session_id": sid,
            "content": content,
            "environment": _detect_shell_context(),
        }
    else:
        sessions = []
        for sid, _, label, content, _ in built:
            sessions.append({
                "session_id": sid,
                "content": content,
                "label": label,
                "environment": _detect_shell_context(),
            })
        payload = {"sessions": sessions, "environment": _detect_shell_context()}

    return _send_payload(base_url, env, payload, output_json, "Session uploaded to #internal-reports.")


def _send_chunked(
    base_url: str,
    env: Dict[str, str],
    built: list[tuple[str, str, str, str, bool]],
    output_json: bool,
) -> int:
    """Upload sessions via chunk + finalize when they exceed the single-request limit."""
    api_key = env.get("DEEPLINE_API_KEY")
    upload_id = str(uuid.uuid4())
    session_ids: list[str] = []
    labels: list[str] = []
    environments: list[dict] = []

    for sid, _, label, encoded_b64, _ in built:
        session_ids.append(sid)
        labels.append(label)
        environments.append(_detect_shell_context())

        # Decode b64 back to raw gzipped bytes for chunking
        gz_bytes = base64.b64decode(encoded_b64)
        chunks = [gz_bytes[i:i + _CHUNK_SIZE_BYTES] for i in range(0, len(gz_bytes), _CHUNK_SIZE_BYTES)]
        total_chunks = len(chunks)

        print(f"Uploading {label} in {total_chunks} chunk(s)...", file=os.sys.stderr)

        for idx, chunk in enumerate(chunks):
            chunk_b64 = base64.b64encode(chunk).decode("ascii")
            chunk_payload = {
                "upload_id": upload_id,
                "session_id": sid,
                "index": idx,
                "total_chunks": total_chunks,
                "data": chunk_b64,
            }
            status, body = http_request(
                "POST", f"{base_url}/api/v2/cli/send-session/chunk",
                api_key, chunk_payload, timeout=60,
            )
            if status >= 400:
                print(f"Chunk {idx}/{total_chunks} upload failed (status {status}).", file=os.sys.stderr)
                if body.strip():
                    print(body.strip(), file=os.sys.stderr)
                if should_report_failure(status):
                    report_failure(
                        base_url, api_key,
                        command="session send (chunk)",
                        error_status=status,
                        error_body=body.strip()[:2000] if body else None,
                        payload_size_bytes=len(chunk),
                        context={"upload_id": upload_id, "session_id": sid, "chunk_index": idx, "total_chunks": total_chunks},
                    )
                return EXIT_SERVER

    # Finalize
    finalize_payload: dict = {
        "upload_id": upload_id,
        "session_ids": session_ids,
    }
    if labels:
        finalize_payload["labels"] = labels
    if environments:
        finalize_payload["environments"] = environments

    return _send_payload(
        base_url, env, finalize_payload, output_json,
        "Session uploaded to #internal-reports (chunked).",
        endpoint="/api/v2/cli/send-session/finalize",
    )


def _send_payload(base_url: str, env: Dict[str, str], payload: dict, output_json: bool, success_msg: str, endpoint: str = "/api/v2/cli/send-session") -> int:
    api_key = env.get("DEEPLINE_API_KEY")
    status, body = http_request("POST", f"{base_url}{endpoint}", api_key, payload, timeout=60)
    if status >= 400:
        if should_report_failure(status):
            _report_session_failure(base_url, api_key, status, body, payload, endpoint)
        if status in (401, 403):
            print(f"Auth error (status {status}). Check DEEPLINE_API_KEY.", file=os.sys.stderr)
            return EXIT_AUTH
        print(f"Upload failed (status {status}).", file=os.sys.stderr)
        raw_body = body.strip()
        if raw_body:
            try:
                data = json.loads(raw_body)
                message = str(data.get("message") or data.get("error") or "").strip()
                details = data.get("details")
                if message:
                    print(message, file=os.sys.stderr)
                elif raw_body:
                    print(raw_body, file=os.sys.stderr)
                if details and str(details) not in message:
                    print(f"Details: {details}", file=os.sys.stderr)
            except Exception:
                print(raw_body, file=os.sys.stderr)
        if status in (400, 422):
            return EXIT_VALIDATION
        return EXIT_SERVER
    if output_json:
        print(body)
    else:
        print(success_msg)
    return EXIT_OK


def _report_session_failure(
    base_url: str,
    api_key: str | None,
    status: int,
    body: str,
    payload: dict,
    endpoint: str,
) -> None:
    """Fire error beacon for session send failures."""
    # Estimate payload size without including the actual content
    payload_size = len(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    context: dict = {"endpoint": endpoint}
    if "session_id" in payload:
        context["session_id"] = payload["session_id"]
    if "sessions" in payload:
        context["session_count"] = len(payload["sessions"])
    if "upload_id" in payload:
        context["upload_id"] = payload["upload_id"]
    report_failure(
        base_url, api_key,
        command="session send",
        error_status=status,
        error_body=body.strip()[:2000] if body else None,
        payload_size_bytes=payload_size,
        context=context,
    )


def _share_session_user_prompts_enabled(env: Dict[str, str]) -> bool:
    return parse_cli_bool(env.get(SHARE_SESSION_USER_PROMPTS_ENV)) is True


def _post_session_start_activity(
    base_url: str,
    env: Dict[str, str],
    session_id: str,
    steps: list[dict],
    user_prompt: str,
) -> int:
    prompt = str(user_prompt or "").strip()
    if not prompt or not _share_session_user_prompts_enabled(env):
        return EXIT_OK

    api_key = env.get("DEEPLINE_API_KEY")
    if not api_key:
        print(
            f"Warning: skipped session prompt delivery because {SHARE_SESSION_USER_PROMPTS_ENV}=true but DEEPLINE_API_KEY is missing.",
            file=os.sys.stderr,
        )
        return EXIT_OK

    status, body = http_request(
        "POST",
        f"{base_url}/api/v2/cli/session-start",
        api_key,
        {
            "session_id": session_id,
            "steps": steps,
            "user_prompt": prompt,
        },
        timeout=30,
    )
    if status < 400:
        return EXIT_OK

    raw_message = _compact_api_error_message(body)
    if status in (401, 403):
        raw_message = "auth failed while sending prompt activity"
    print(
        f"Warning: plan was set locally, but prompt delivery to Slack failed: {raw_message}",
        file=os.sys.stderr,
    )
    return EXIT_OK


def _handle_session_plan_or_start(base_url: str, env: Dict[str, str], args: list[str], *, command_label: str) -> int:
    """Post or update an agent plan to the playground Session UI via cli-event API."""
    if any(arg in {"-h", "--help", "help"} for arg in args):
        print("Usage:")
        print('  deepline session start --steps \'["Step 1","Step 2"]\' [--user-prompt "Prompt text"] [--update INDEX --status STATUS] [--session-id UUID]')
        print("    Start a Session UI plan and optionally send the user prompt to session activity.")
        return EXIT_OK

    steps_json: str | None = None
    update_index: int | None = None
    step_status: str | None = None
    plan_status: str | None = None
    explicit_session_id: str | None = None
    user_prompt: str | None = None
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--steps" and i + 1 < len(args):
            steps_json = args[i + 1]; i += 2
        elif arg == "--update" and i + 1 < len(args):
            update_index = int(args[i + 1]); i += 2
        elif arg == "--status" and i + 1 < len(args):
            step_status = args[i + 1]; i += 2
        elif arg == "--plan-status" and i + 1 < len(args):
            plan_status = args[i + 1]; i += 2
        elif arg in ("--user-prompt", "--userprompt") and i + 1 < len(args):
            user_prompt = args[i + 1]; i += 2
        elif arg == "--session-id" and i + 1 < len(args):
            explicit_session_id = args[i + 1]; i += 2
        else:
            i += 1

    from deepline_core.playground_helpers import (
        ensure_local_playground_backend,
        playground_api_request,
        playground_read_state,
        playground_write_state,
    )

    backend_rc, playground_api = ensure_local_playground_backend(base_url, install_mode="auto", quiet=True)
    if backend_rc != EXIT_OK:
        return backend_rc
    session_id = _resolve_cli_session_id(explicit_session_id)

    if update_index is not None:
        if not step_status:
            print("--status is required with --update", file=os.sys.stderr)
            return EXIT_USAGE
        payload: dict = {
            "action": "update_plan_step",
            "step_index": update_index,
            "status": step_status,
            "session_id": session_id,
        }
        status_code, body = playground_api_request("POST", playground_api, "/api/cli-event", payload)
        if status_code >= 400:
            message = _compact_api_error_message(body)
            print(
                f"Warning: skipped plan step update #{update_index} -> {step_status}: {message}",
                file=os.sys.stderr,
            )
            return EXIT_OK
        print(f"Plan step updated: #{update_index} -> {step_status}.")
        return EXIT_OK

    if not steps_json:
        print("--steps is required (JSON array of step labels or objects)", file=os.sys.stderr)
        print(f'Example: deepline session {command_label} --steps \'["Inspect CSV","Search tools","Run pilot"]\'', file=os.sys.stderr)
        return EXIT_USAGE

    try:
        parsed_steps = json.loads(
            read_cli_text_input(steps_json, argument_name="--steps")
        )
    except json.JSONDecodeError as exc:
        hint = ""
        if not str(steps_json or "").strip().startswith("@"):
            hint = " Tip: on PowerShell or Windows terminals, prefer --steps @path/to/steps.json."
        print(f"Invalid JSON for --steps: {exc}.{hint}", file=os.sys.stderr)
        return EXIT_VALIDATION
    except ValueError as exc:
        print(str(exc), file=os.sys.stderr)
        return EXIT_VALIDATION

    if not isinstance(parsed_steps, list) or not parsed_steps:
        print("--steps must be a non-empty JSON array", file=os.sys.stderr)
        return EXIT_VALIDATION

    step_objects = []
    for item in parsed_steps:
        if isinstance(item, str):
            step_objects.append({"label": item})
        elif isinstance(item, dict):
            step_objects.append(item)
        else:
            print(f"Invalid step entry (expected string or object): {item}", file=os.sys.stderr)
            return EXIT_VALIDATION

    session_context = _detect_shell_context()
    payload = {
        "action": "set_plan",
        "steps": step_objects,
        "session_id": session_id,
        "environment": session_context,
    }
    if plan_status:
        payload["status"] = plan_status

    status_code, body = playground_api_request("POST", playground_api, "/api/cli-event", payload)
    if status_code >= 400:
        return _warn_cli_event_non_fatal("set plan", status_code, body)
    print(f"Plan set: {len(step_objects)} step(s).")

    _post_session_start_activity(base_url, env, session_id, step_objects, user_prompt or "")

    state = playground_read_state()
    api_url = str(state.get("backend_api_url") or "http://127.0.0.1:4173").rstrip("/")
    session_url = f"{api_url}?session_id={session_id}"
    print(f"Session ID: {session_id}")
    print(f"Session URL: {session_url}")
    print(_format_session_context(session_context))
    from deepline_core.browser import open_url_in_browser
    open_url_in_browser(session_url, force_focus=True)
    if not state.get("session_ui_opened"):
        state["session_ui_opened"] = True
        playground_write_state(state)

    return EXIT_OK


@router.route(
    "start",
    summary="Start a Session UI plan and optionally send the user prompt to session activity.",
    usage='deepline session start --steps \'["Step 1","Step 2"]\' [--user-prompt "Prompt text"] [--update INDEX --status STATUS] [--session-id UUID]',
)
def handle_start(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    return _handle_session_plan_or_start(base_url, env, args, command_label="start")


@router.route(
    "output",
    summary="Register an output CSV with the Session UI so a table card appears.",
    usage='deepline session output --csv /path/to/output.csv [--label "My Results"] [--session-id UUID] [--meta "{...}"]',
)
def handle_output(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    _ = env

    csv_path: str | None = None
    label: str | None = None
    explicit_session_id: str | None = None
    meta_json: str | None = None

    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--csv" and i + 1 < len(args):
            csv_path = args[i + 1]; i += 2
        elif arg == "--label" and i + 1 < len(args):
            label = args[i + 1]; i += 2
        elif arg == "--session-id" and i + 1 < len(args):
            explicit_session_id = args[i + 1]; i += 2
        elif arg == "--meta" and i + 1 < len(args):
            meta_json = args[i + 1]; i += 2
        else:
            i += 1

    if not csv_path:
        print("--csv is required", file=os.sys.stderr)
        return EXIT_USAGE

    resolved = Path(csv_path).resolve()
    if not resolved.is_file():
        print(f"File not found: {resolved}", file=os.sys.stderr)
        return EXIT_VALIDATION

    if label is None:
        label = resolved.stem

    from deepline_core.playground_helpers import ensure_local_playground_backend, playground_api_request

    backend_rc, playground_api = ensure_local_playground_backend(base_url, install_mode="auto", quiet=True)
    if backend_rc != EXIT_OK:
        return backend_rc
    meta: dict | None = None
    if meta_json:
        try:
            meta = json.loads(meta_json)
        except json.JSONDecodeError:
            print("--meta must be valid JSON", file=os.sys.stderr)
            return EXIT_VALIDATION

    payload: dict = {
        "action": "append_event",
        "csv_path": str(resolved),
        "status": "completed",
        "message": label,
        "source": "cli_output",
        "session_id": _resolve_cli_session_id(explicit_session_id),
    }
    if meta is not None:
        payload["meta"] = meta
    status_code, body = playground_api_request("POST", playground_api, "/api/cli-event", payload)
    if status_code >= 400:
        return _warn_cli_event_non_fatal("register output", status_code, body)

    print(f'Output registered: "{label}".')
    return EXIT_OK


@router.route(
    "alert",
    summary="Send an alert banner to the Session UI.",
    usage='deepline session alert --message "Approve full run?" [--session-id UUID]',
)
def handle_alert(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    _ = env
    message: str | None = None
    explicit_session_id: str | None = None
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--message" and i + 1 < len(args):
            message = args[i + 1]; i += 2
        elif arg == "--session-id" and i + 1 < len(args):
            explicit_session_id = args[i + 1]; i += 2
        else:
            i += 1
    if not message:
        print("--message is required", file=os.sys.stderr)
        return EXIT_USAGE

    from deepline_core.playground_helpers import ensure_local_playground_backend, playground_api_request

    backend_rc, playground_api = ensure_local_playground_backend(base_url, install_mode="auto", quiet=True)
    if backend_rc != EXIT_OK:
        return backend_rc

    payload: dict = {
        "action": "set_alert",
        "message": message,
        "session_id": _resolve_cli_session_id(explicit_session_id),
    }
    status_code, body = playground_api_request("POST", playground_api, "/api/cli-event", payload)
    if status_code >= 400:
        return _warn_cli_event_non_fatal("send alert", status_code, body)
    print("Alert sent.")
    return EXIT_OK


@router.route(
    "usage",
    summary="Show current session spend and limit state.",
    usage="deepline session usage [--session-id UUID] [--json]",
)
def handle_usage(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    _ = env
    explicit_session_id: str | None = None
    output_json = False

    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--session-id" and i + 1 < len(args):
            explicit_session_id = args[i + 1]
            i += 2
        elif arg == "--json":
            output_json = True
            i += 1
        else:
            i += 1

    from deepline_core.playground_helpers import ensure_local_playground_backend, playground_api_request

    backend_rc, playground_api = ensure_local_playground_backend(base_url, install_mode="auto", quiet=True)
    if backend_rc != EXIT_OK:
        return backend_rc

    session_id = _resolve_cli_session_id(explicit_session_id)
    status_code, body = playground_api_request(
        "GET",
        playground_api,
        f"/api/cli-event?session_id={quote(session_id, safe='')}",
        None,
    )
    if status_code >= 400:
        print(f"Failed to read session usage (status {status_code}).", file=os.sys.stderr)
        message = _compact_api_error_message(body)
        if message:
            print(message, file=os.sys.stderr)
        return EXIT_SERVER

    try:
        parsed = json.loads(body or "{}")
    except Exception:
        print("Failed to parse session usage response.", file=os.sys.stderr)
        return EXIT_SERVER

    cli_event = parsed.get("cli_event") if isinstance(parsed, dict) else {}
    billing = cli_event.get("billing") if isinstance(cli_event, dict) else {}
    credits_used = float((billing or {}).get("credits_used") or 0)
    cost_usd = float((billing or {}).get("cost_usd") or 0)
    raw_limit = (billing or {}).get("dollar_limit")
    dollar_limit = float(raw_limit) if isinstance(raw_limit, (int, float)) else None
    limit_reached = dollar_limit is not None and cost_usd >= dollar_limit

    response_payload = {
        "session_id": session_id,
        "credits_used": credits_used,
        "cost_usd": cost_usd,
        "dollar_limit": dollar_limit,
        "limit_reached": limit_reached,
    }
    if output_json:
        print(json.dumps(response_payload))
        return EXIT_OK

    print(f"Session ID: {session_id}")
    print(f"Credits used: {credits_used:.2f}")
    print(f"Estimated spend: ${cost_usd:.2f}")
    print(f"Session limit: {'off' if dollar_limit is None else f'${dollar_limit:.2f}'}")
    print(f"Status: {'limit reached' if limit_reached else 'under limit'}")
    return EXIT_OK


@router.route(
    "limit",
    summary="Set or clear a per-session spending limit (USD).",
    usage="deepline session limit --dollars N | --clear [--session-id UUID]",
)
def handle_limit(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    """Set a dollar spending limit for the current session."""
    _ = env
    dollars: float | None = None
    clear = False
    explicit_session_id: str | None = None

    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--dollars" and i + 1 < len(args):
            try:
                dollars = float(args[i + 1])
            except ValueError:
                print("--dollars must be a positive number", file=os.sys.stderr)
                return EXIT_VALIDATION
            i += 2
        elif arg == "--clear":
            clear = True
            i += 1
        elif arg == "--session-id" and i + 1 < len(args):
            explicit_session_id = args[i + 1]
            i += 2
        else:
            i += 1

    if not clear and dollars is None:
        print("--dollars N or --clear is required", file=os.sys.stderr)
        print("Example: deepline session limit --dollars 5", file=os.sys.stderr)
        return EXIT_USAGE

    if dollars is not None and dollars <= 0:
        print("--dollars must be a positive number", file=os.sys.stderr)
        return EXIT_VALIDATION

    from deepline_core.playground_helpers import ensure_local_playground_backend, playground_api_request

    backend_rc, playground_api = ensure_local_playground_backend(base_url, install_mode="auto", quiet=True)
    if backend_rc != EXIT_OK:
        return backend_rc

    payload: dict = {
        "action": "set_dollar_limit",
        "session_id": _resolve_cli_session_id(explicit_session_id),
    }
    if clear:
        payload["clear"] = True
    else:
        payload["dollars"] = dollars

    status_code, body = playground_api_request("POST", playground_api, "/api/cli-event", payload)
    if status_code >= 400:
        return _warn_cli_event_non_fatal("set spending limit", status_code, body)

    if clear:
        print("Session spending limit cleared.")
    else:
        print(f"Session spending limit set to ${dollars:.2f}.")
    return EXIT_OK


@router.route(
    "status",
    summary="Send a status update to the currently-running plan step in the Session UI.",
    usage='deepline session status --message "Extracting domains from response" [--step-index 0] [--session-id UUID]',
)
def handle_status(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    _ = env
    message: str | None = None
    step_index: int | None = None
    explicit_session_id: str | None = None
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--message" and i + 1 < len(args):
            message = args[i + 1]; i += 2
        elif arg == "--step-index" and i + 1 < len(args):
            step_index = int(args[i + 1]); i += 2
        elif arg == "--session-id" and i + 1 < len(args):
            explicit_session_id = args[i + 1]; i += 2
        else:
            i += 1
    if not message:
        print("--message is required", file=os.sys.stderr)
        return EXIT_USAGE

    from deepline_core.playground_helpers import ensure_local_playground_backend, playground_api_request

    backend_rc, playground_api = ensure_local_playground_backend(base_url, install_mode="auto", quiet=True)
    if backend_rc != EXIT_OK:
        return backend_rc

    payload: dict = {
        "action": "set_status",
        "message": message,
        "session_id": _resolve_cli_session_id(explicit_session_id),
    }
    if step_index is not None:
        payload["step_index"] = step_index
    status_code, body = playground_api_request("POST", playground_api, "/api/cli-event", payload)
    if status_code >= 400:
        return _warn_cli_event_non_fatal("status update", status_code, body)
    step_label = "running step"
    raw_body = (body or "").strip()
    if raw_body:
        try:
            parsed = json.loads(raw_body)
            response_step_index = parsed.get("step_index")
            if isinstance(response_step_index, int):
                step_label = f"step #{response_step_index}"
        except Exception:
            pass
    print(f"Status added to {step_label}.")
    return EXIT_OK


@router.route(
    "render",
    summary="Render one or more sessions to HTML.",
    usage="deepline session render [--session-id UUID]... [--current-session] [--auto-refresh N] [-o path]",
)
def handle_render(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    _ = base_url
    _ = env
    session_ids: list[str] = []
    labels: list[str] = []
    current = False
    output_path = ""
    auto_refresh_seconds = ""
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--session-id":
            if i + 1 >= len(args):
                print("Missing value for --session-id", file=os.sys.stderr)
                return EXIT_USAGE
            session_ids.append(args[i + 1])
            i += 2
            continue
        if arg == "--label":
            if i + 1 >= len(args):
                print("Missing value for --label", file=os.sys.stderr)
                return EXIT_USAGE
            labels.append(args[i + 1])
            i += 2
            continue
        if arg == "--current-session":
            current = True
            i += 1
            continue
        if arg == "--auto-refresh":
            if i + 1 >= len(args):
                print("Missing value for --auto-refresh", file=os.sys.stderr)
                return EXIT_USAGE
            raw_seconds = str(args[i + 1]).strip()
            if not raw_seconds.isdigit() or int(raw_seconds) <= 0:
                print("Invalid value for --auto-refresh (expected positive integer seconds)", file=os.sys.stderr)
                return EXIT_USAGE
            auto_refresh_seconds = raw_seconds
            i += 2
            continue
        if arg in {"-o", "--output"}:
            if i + 1 >= len(args):
                print("Missing value for --output", file=os.sys.stderr)
                return EXIT_USAGE
            output_path = args[i + 1]
            i += 2
            continue
        if arg.startswith("--"):
            print(f"Unknown session render option: {arg}", file=os.sys.stderr)
            return EXIT_USAGE
        i += 1
    if not current and not session_ids:
        print("Either --session-id or --current-session is required.", file=os.sys.stderr)
        return EXIT_USAGE

    resolved: list[tuple[str, str, str]] = []
    if current:
        err, sid, fpath = _resolve_session_id_and_file("", True)
        if err is not None:
            return err
        if sid and fpath:
            resolved.append((sid, f"session-{sid}", fpath))
    for idx, sid in enumerate(session_ids):
        err, rsid, fpath = _resolve_session_id_and_file(sid, False)
        if err is not None:
            return err
        if rsid and fpath:
            label = labels[idx] if idx < len(labels) else f"session-{rsid}"
            resolved.append((rsid, label, fpath))
    if not resolved:
        print("Either --session-id or --current-session is required.", file=os.sys.stderr)
        return EXIT_USAGE
    if not output_path:
        output_dir = Path("deepline") / "data"
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(output_dir / ("session-viewer.html" if len(resolved) > 1 else f"session-{resolved[0][0]}.html"))

    raw_sessions = []
    for _, label, fpath in resolved:
        raw = Path(fpath).read_bytes()
        # Apply same compression pipeline as send: strip noise, dedup, compact tool results
        stripped = _strip_noise_events(raw)
        deduped = _dedup_consecutive_events(stripped)
        compacted = _selective_compact_tool_results(deduped)
        events = []
        for line in compacted.decode("utf-8", errors="replace").splitlines():
            line = line.strip()
            if line:
                events.append(json.loads(line))
        raw_sessions.append({"label": label, "events": events})

    css, js = _load_viewer_assets()
    raw_json = json.dumps(raw_sessions).replace("</", "<\\/")
    refresh_meta = f'<meta http-equiv="refresh" content="{auto_refresh_seconds}">' if auto_refresh_seconds else ""
    html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
{refresh_meta}
<title>Session Viewer</title>
<style>{css}</style>
</head>
<body>
<div class="layout">
    <div class="sidebar hidden" id="sidebar"></div>
    <div class="main" id="main-content"></div>
</div>
<script type="application/json" id="raw-sessions">{raw_json}</script>
<script>{js}</script>
</body>
</html>"""
    Path(output_path).write_text(html_doc, encoding="utf-8")
    print(f"Rendered session viewer: {output_path}")
    return EXIT_OK


handle = build_command_handler(
    command_name="session",
    router=router,
    usage_factory=usage_session_computed,
    unknown_to_stderr=True,
)
