from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import time
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urlparse

from deepline_core.command_decorators import OptionSpec, ParsedRouteOptions, SubcommandRouter
from deepline_core.command_decorators import build_command_handler
from deepline_core.browser import open_url_in_browser
from deepline_core.command_common import (
    env_file_path,
    log,
    print_auth_instructions,
    print_lines,
    save_cli_env_values,
)
from deepline_core.command_common import EXIT_AUTH, EXIT_OK, EXIT_PENDING, EXIT_SERVER, EXIT_USAGE
from deepline_core.http import http_request, http_request_with_headers


router = SubcommandRouter()

_AUTH_HELP_HIDDEN_PRIMARY_ROUTES = {"org-switch", "orgs", "org-list"}


def _usage_lines_without_hidden_routes(command_path: str, hidden_primary_routes: set[str]) -> list[str]:
    lines: list[str] = ["Usage:"]
    primary_specs: dict[str, Any] = {}
    for spec in router._specs.values():
        key = spec.primary or spec.name
        if key in hidden_primary_routes or key in primary_specs:
            continue
        primary_specs[key] = spec

    for _, spec in sorted(primary_specs.items(), key=lambda kv: kv[0]):
        line = spec.usage.strip() if spec.usage else f"{command_path} {spec.name} [options]"
        lines.append(f"  {line}")
        if spec.summary:
            lines.append(f"    {spec.summary}")
        if spec.description:
            lines.append(f"    {spec.description}")
        if spec.options:
            lines.append("    Options:")
            for opt in spec.options:
                opt_text = f"{opt.flag} {opt.value_name}".strip() if opt.takes_value else opt.flag
                lines.append(f"      {opt_text:<28} {opt.description}".rstrip())
    return lines


def _is_localhost_base_url(base_url: str) -> bool:
    try:
        host = (urlparse(base_url).hostname or "").lower()
    except Exception:
        return False
    return (
        host == "localhost"
        or host.startswith("127.")
        or host == "0.0.0.0"
        or host == "::1"
        or host.endswith(".localhost")
    )


def _print_deepline_logo() -> None:
    if os.isatty(1):
        cols = shutil.get_terminal_size(fallback=(80, 24)).columns
        if cols >= 70:
            print(" ██████╗  ███████╗ ███████╗ ██████╗  ██╗      ██╗ ███╗   ██╗ ███████╗")
            print(" ██╔══██╗ ██╔════╝ ██╔════╝ ██╔══██╗ ██║      ██║ ████╗  ██║ ██╔════╝")
            print(" ██║  ██║ █████╗   █████╗   ██████╔╝ ██║      ██║ ██╔██╗ ██║ █████╗")
            print(" ██║  ██║ ██╔══╝   ██╔══╝   ██╔═══╝  ██║      ██║ ██║╚██╗██║ ██╔══╝")
            print(" ██████╔╝ ███████╗ ███████╗ ██║      ███████╗ ██║ ██║ ╚████║ ███████╗")
            print(" ╚═════╝  ╚══════╝ ╚══════╝ ╚═╝      ╚══════╝ ╚═╝ ╚═╝  ╚═══╝ ╚══════╝")
            print("")
            return
    print("DEEPLINE")


def usage_auth_computed() -> list[str]:
    lines = _usage_lines_without_hidden_routes("deepline auth", _AUTH_HELP_HIDDEN_PRIMARY_ROUTES)
    lines.append("")
    lines.append("Tips:")
    lines.append("  Use --no-wait in CI/non-interactive environments, then 'deepline auth wait' after approval.")
    lines.append("  Use 'deepline auth status --reveal' to persist returned API keys.")
    lines.append("  Use 'deepline org --help' for organization commands.")
    return lines


def _print_host_health(base_url: str) -> None:
    print(f"Host: {base_url}")
    health_status, health_body = http_request("GET", f"{base_url}/api/v2/health", None)
    if health_status == 200:
        try:
            health = json.loads(health_body)
        except Exception:
            health = {}
        print(f"Host status: {health.get('status') or 'ok'}")
        print(f"Host version: {health.get('version') or '(unknown)'}")
        return
    print("Host status: (unknown)")
    print("Host version: (unknown)")


def build_status_params(parsed: ParsedRouteOptions) -> bool:
    return bool(parsed.options.get("reveal"))


def _should_skip_skills_status() -> bool:
    raw = str(os.environ.get("DEEPLINE_SKIP_SKILLS_SYNC", "")).strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _parse_bool_env(name: str) -> bool | None:
    raw = str(os.environ.get(name, "")).strip().lower()
    if raw in {"1", "true", "yes", "on", "y"}:
        return True
    if raw in {"0", "false", "no", "off", "n"}:
        return False
    return None


def _magic_link_preview_enabled() -> bool:
    if _parse_bool_env("RESEND_TEST_MODE") is not True:
        return False
    if _parse_bool_env("DEEPLINE_PREVIEW_MAGIC_LINK") is False:
        return False
    node_env = str(os.environ.get("NODE_ENV", "")).strip().lower()
    if node_env == "production":
        return False
    vercel_env = str(os.environ.get("VERCEL_ENV", "")).strip().lower()
    return vercel_env != "production"


def _get_magic_link_email() -> str:
    for key in (
        "DEEPLINE_MAGIC_LINK_TEST_EMAIL",
        "DEEPLINE_E2E_MAGIC_LINK_EMAIL",
        "DEEPLINE_E2E_EMAIL",
        "DEEPLINE_AUTH_TEST_EMAIL",
        "DEEPLINE_CLI_MAGIC_LINK_EMAIL",
    ):
        candidate = str(os.environ.get(key, "")).strip()
        if candidate:
            return candidate
    return ""


def _request_cli_magic_link(
    base_url: str,
    email: str,
    claim_token: str,
) -> str:
    if not email:
        return ""

    callback_url = f"{base_url.rstrip('/')}/cli/claim/{claim_token}/finalize"
    headers = {"x-deepline-cli-magic-link": "1"}
    response = http_request_with_headers(
        "POST",
        f"{base_url}/api/auth/sign-in/magic-link",
        None,
        {"email": email, "callbackURL": callback_url},
        extra_headers=headers,
    )
    if response.status >= 400:
        log(
            f"Magic-link request failed (status {response.status}). {response.body}",
            err=True,
        )
        return ""

    for key, value in response.headers.items():
        if key.lower() == "x-deepline-magic-link":
            return str(value)
    return ""


@router.route_typed(
    "status",
    summary="Show auth connection status.",
    usage="deepline auth status [--reveal]",
    options=[OptionSpec("--reveal", "Persist returned API key to ~/.local/deepline/.env.", key="reveal")],
    params_parser=build_status_params,
)
def handle_status(base_url: str, env: Dict[str, str], reveal: bool) -> int:
    _print_host_health(base_url)

    if not _should_skip_skills_status():
        from deepline_core.main import print_skills_status
        print_skills_status(base_url)

    api_key = env.get("DEEPLINE_API_KEY", "").strip()
    claim_token = env.get("DEEPLINE_CLAIM_TOKEN", "").strip()
    if not api_key and not claim_token:
        print("Status: not connected")
        print_auth_instructions(has_claim_token=False)
        return EXIT_OK
    if claim_token and not api_key:
        print("Status: pending")
        print_auth_instructions(has_claim_token=True)
        return EXIT_OK

    payload = {"api_key": api_key, "reveal": bool(reveal)}
    status, body = http_request("POST", f"{base_url}/api/v2/auth/cli/status", api_key, payload)
    if status in (401, 403):
        print("Status: unauthorized")
        print("Run: deepline auth register")
        return EXIT_AUTH
    if status >= 400:
        print(f"Auth status error (status {status}).")
        if body:
            log(body, err=True)
        return EXIT_SERVER

    try:
        data = json.loads(body or "{}")
    except Exception:
        data = {}
    print(f"Status: {data.get('status', '(unknown)')}")
    print(f"Rate limit tier: {data.get('rate_limit_tier', '(unknown)')}")
    if data.get("org_name"):
        print(f"Workspace: {data['org_name']}")
    if data.get("org_slug"):
        print(f"Workspace slug: {data['org_slug']}")
    if data.get("org_id") is not None:
        print(f"Org ID: {data.get('org_id')}")
    if data.get("user_id") is not None:
        print(f"User ID: {data.get('user_id')}")
    if data.get("user_email"):
        print(f"User email: {data.get('user_email')}")

    if reveal:
        api_key_resp = data.get("api_key") or api_key
        if api_key_resp:
            save_cli_env_values({"DEEPLINE_API_KEY": str(api_key_resp), "DEEPLINE_CLAIM_TOKEN": ""}, base_url)
            print(f"Saved API key to {env_file_path(os.environ.get('HOME', str(Path.home())), base_url, write=True)}")
    return EXIT_OK


def _is_cloud_sandbox() -> bool:
    """Detect cloud-sandbox runtimes (Cowork, Claude Code on the web).

    Two signals — we accept either:
      1. CLAUDE_CODE_REMOTE=true (documented by Anthropic for Claude Code on the web)
      2. HOME under /sessions/<id>/ (empirically true for Cowork sandboxes)
    """
    if str(os.environ.get("CLAUDE_CODE_REMOTE", "")).strip().lower() in {"1", "true", "yes", "on"}:
        return True
    home = os.environ.get("HOME", "")
    return home.startswith("/sessions/")


_COWORK_SYSTEM_MNT_NAMES = frozenset({"outputs", "uploads"})


def _resolve_remote_workspace_dir() -> str:
    """Return the connected workspace folder in cloud sandboxes, if any.

    Order of preference:
      1. CLAUDE_PROJECT_DIR env var (set on laptop and possibly future Cowork)
      2. $HOME/mnt/<workspace-name>/ — Cowork's connected-workspace mount.
         Picks the first non-dot-prefixed directory under $HOME/mnt/ that
         isn't a known Cowork system path (`outputs`, `uploads`).
    """
    explicit = (os.environ.get("CLAUDE_PROJECT_DIR") or "").strip()
    if explicit:
        return explicit
    home = os.environ.get("HOME", "")
    if not home.startswith("/sessions/"):
        return ""
    mnt = Path(home) / "mnt"
    if not mnt.is_dir():
        return ""
    try:
        candidates = [
            p for p in mnt.iterdir()
            if p.is_dir()
            and not p.name.startswith(".")
            and p.name not in _COWORK_SYSTEM_MNT_NAMES
        ]
    except Exception:
        return ""
    if not candidates:
        return ""
    # Prefer a folder explicitly named "deepline" if the user picked that as
    # their workspace name (deterministic across multi-workspace setups).
    for p in candidates:
        if p.name.lower() == "deepline":
            return str(p)
    return str(sorted(candidates)[0])


def _persist_to_workspace_if_remote(api_key: str) -> None:
    """In cloud sandboxes with a connected workspace, also persist the api_key to
    <workspace>/.deepline/.env so it survives sandbox teardown. The shim sources
    this file on startup. Non-fatal: any error is swallowed.

    Skips silently when there's no detectable cloud sandbox or no workspace path.
    """
    if not _is_cloud_sandbox():
        return
    workspace = _resolve_remote_workspace_dir()
    if not workspace:
        return
    try:
        target_dir = Path(workspace) / ".deepline"
        target_dir.mkdir(parents=True, exist_ok=True)
        gitignore = target_dir / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("*\n", encoding="utf-8")
        env_path = target_dir / ".env"
        env_path.write_text(f"DEEPLINE_API_KEY={api_key}\n", encoding="utf-8")
    except Exception:
        pass


def _print_claim_success_banner(
    base_url: str,
    api_key: str,
    status_data: Dict[str, Any],
) -> None:
    """Shared post-claim-success output. Non-fatal: bonus + multi-org checks swallow errors."""
    print("")
    _print_deepline_logo()
    print("✓ All set! Your CLI is connected.")
    # Claim install bonus discount code (non-fatal)
    try:
        bonus_status, bonus_body = http_request(
            "POST",
            f"{base_url}/api/v2/billing/claim-install-bonus",
            api_key,
            {},
        )
        if bonus_status == 200:
            bonus_data = json.loads(bonus_body)
            granted = bonus_data.get("credits_granted", 0)
            already = bonus_data.get("already_granted", False)
            if granted > 0:
                print(f"\n  • \033[32m+{granted} free credits added to your account!\033[0m")
            elif already:
                print(f"\n  • \033[32mFree credits already applied to your account.\033[0m")
    except Exception:
        pass
    # Check for multi-org (non-fatal)
    try:
        _, orgs = _fetch_user_organizations(base_url, api_key)
        org_name = str(status_data.get("org_name") or "")
        if org_name:
            print(f"\n  • Signed in with organization: {org_name}")
        if len(orgs) > 1:
            print(
                f"  • You belong to {len(orgs)} organizations. "
                "Run 'deepline org list' to review or 'deepline org switch <number>' to change."
            )
    except Exception:
        pass


def build_wait_params(parsed: ParsedRouteOptions) -> Dict[str, Any]:
    raw = str(parsed.options.get("timeout") or "").strip()
    try:
        seconds = int(raw) if raw else 40
    except ValueError:
        seconds = 40
    # Clamp to a reasonable range. Default 40s fits cloud sandbox bash timeouts (~45s).
    return {"timeout": max(1, min(seconds, 300))}


@router.route_typed(
    "wait",
    summary="Wait for browser approval to redeem a pending claim and persist the API key.",
    usage="deepline auth wait [--timeout SECONDS]",
    options=[
        OptionSpec(
            "--timeout",
            "Maximum seconds to poll for approval (default 40, max 300).",
            takes_value=True,
            value_name="SECONDS",
            key="timeout",
        ),
    ],
    params_parser=build_wait_params,
)
def handle_wait(base_url: str, env: Dict[str, str], params: Dict[str, Any]) -> int:
    if env.get("DEEPLINE_API_KEY", "").strip():
        print("Already authenticated. Nothing to wait for.")
        return EXIT_OK

    claim_token = env.get("DEEPLINE_CLAIM_TOKEN", "").strip()
    if not claim_token:
        print(
            "No pending claim. Run: deepline auth register --no-wait",
            file=os.sys.stderr,
        )
        return EXIT_AUTH

    # `build_wait_params` already clamped to [1, 300] and coerced to int.
    timeout = params["timeout"]
    deadline = time.monotonic() + timeout
    poll_interval = 2
    print(
        f"Waiting up to {timeout}s for browser approval...",
        file=os.sys.stderr,
    )

    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            print(
                "Still pending — re-run `deepline auth wait` after approving in your browser.",
                file=os.sys.stderr,
            )
            return EXIT_PENDING

        s, b = http_request(
            "POST",
            f"{base_url}/api/v2/auth/cli/status",
            None,
            {"claim_token": claim_token, "reveal": True},
        )
        if s in (401, 403):
            print("Claim is invalid. Run: deepline auth register", file=os.sys.stderr)
            return EXIT_AUTH
        if s >= 500 or s == 0 or s == 400:
            time.sleep(min(poll_interval, max(0.0, remaining)))
            continue
        if s >= 400:
            print(f"Auth status error (status {s}).", file=os.sys.stderr)
            if b.strip():
                print(b.strip(), file=os.sys.stderr)
            return EXIT_SERVER

        try:
            status_data = json.loads(b)
        except Exception:
            time.sleep(min(poll_interval, max(0.0, remaining)))
            continue

        state = str(status_data.get("status") or "").strip().lower()
        if state == "claimed":
            api_key = str(status_data.get("api_key") or "")
            if not api_key:
                print(
                    "Server marked claim approved but did not return an api_key.",
                    file=os.sys.stderr,
                )
                return EXIT_SERVER
            save_cli_env_values(
                {"DEEPLINE_API_KEY": api_key, "DEEPLINE_CLAIM_TOKEN": ""},
                base_url,
            )
            _persist_to_workspace_if_remote(api_key)
            _print_claim_success_banner(base_url, api_key, status_data)
            return EXIT_OK
        if state == "expired":
            print(
                "That approval link expired. Run: deepline auth register",
                file=os.sys.stderr,
            )
            return EXIT_AUTH

        time.sleep(min(poll_interval, max(0.0, remaining)))


def build_register_params(parsed: ParsedRouteOptions) -> Dict[str, str | bool]:
    return {
        "org_name": str(parsed.options.get("org_name") or ""),
        "agent_name": str(parsed.options.get("agent_name") or ""),
        "no_wait": bool(parsed.options.get("no_wait")),
    }


@router.route_typed(
    "register",
    summary="Begin browser-based auth registration.",
    usage="deepline auth register [--org-name NAME] [--agent-name NAME] [--no-wait] [--browser-mode MODE]",
    options=[
        OptionSpec("--org-name", "Organization name hint for registration.", takes_value=True, value_name="NAME", key="org_name"),
        OptionSpec("--agent-name", "Agent/device display name.", takes_value=True, value_name="NAME", key="agent_name"),
        OptionSpec("--no-wait", "Do not wait for approval completion.", key="no_wait"),
        OptionSpec("--browser-mode", "Accepted for parity.", takes_value=True, value_name="MODE", key="browser_mode"),
    ],
    params_parser=build_register_params,
)
def handle_register(base_url: str, env: Dict[str, str], params: Dict[str, str | bool]) -> int:
    _ = env
    agent_name = str(params.get("agent_name") or "") or (os.uname().nodename if hasattr(os, "uname") else platform.node()) or "Deepline CLI"
    payload: Dict[str, Any] = {}
    if params.get("org_name"):
        payload["org_name"] = params["org_name"]
    if agent_name:
        payload["agent_name"] = agent_name

    status, body = http_request("POST", f"{base_url}/api/v2/auth/cli/register", None, payload)
    if status >= 400:
        print(f"Auth register failed (status {status}).", file=os.sys.stderr)
        if body.strip():
            print(body.strip(), file=os.sys.stderr)
        return EXIT_SERVER
    try:
        data = json.loads(body)
    except Exception:
        print("Auth register failed: invalid response.", file=os.sys.stderr)
        return EXIT_SERVER

    claim_url = str(data.get("claim_url") or "")
    claim_token = str(data.get("claim_token") or "")
    if claim_token:
        save_cli_env_values({"DEEPLINE_CLAIM_TOKEN": claim_token}, base_url)
    if claim_url:
        if _is_localhost_base_url(base_url):
            print("  • Opening localhost approval in your browser.")
        else:
            print("  • Opening approval page in your browser.")
        print("If it didn't pop up, click this:")
        print(f"  • If it didn't open, cmd+click: {claim_url}")
        try:
            open_url_in_browser(claim_url)
        except Exception:
            pass
    magic_email = _get_magic_link_email()
    if _magic_link_preview_enabled() and claim_token and magic_email:
        magic_link = _request_cli_magic_link(base_url, magic_email, claim_token)
        if magic_link:
            print("\n  • Deterministic magic-link preview URL:")
            print(f"  • CLI_MAGIC_LINK={magic_link}")
    if bool(params.get("no_wait")):
        return EXIT_OK
    if not claim_token:
        print("Missing claim token from register response.", file=os.sys.stderr)
        return EXIT_SERVER

    while True:
        s, b = http_request("POST", f"{base_url}/api/v2/auth/cli/status", None, {"claim_token": claim_token, "reveal": True})
        if s in (401, 403):
            print("Status: unauthorized")
            print("Run: deepline auth register")
            return EXIT_AUTH
        if s >= 500 or s in (0, 400):
            time.sleep(2)
            continue
        if s >= 400:
            print(f"Auth status error (status {s}).", file=os.sys.stderr)
            if b.strip():
                print(b.strip(), file=os.sys.stderr)
            return EXIT_SERVER
        try:
            status_data = json.loads(b)
        except Exception:
            time.sleep(2)
            continue
        state = str(status_data.get("status") or "").strip().lower()
        if state == "claimed":
            api_key = str(status_data.get("api_key") or "")
            if api_key:
                save_cli_env_values(
                    {"DEEPLINE_API_KEY": api_key, "DEEPLINE_CLAIM_TOKEN": ""},
                    base_url,
                )
                _persist_to_workspace_if_remote(api_key)
                _print_claim_success_banner(base_url, api_key, status_data)
                return EXIT_OK
        if state == "expired":
            print("That approval link expired. Please run: deepline auth register")
            return EXIT_AUTH
        time.sleep(2)


def _fetch_user_organizations(base_url: str, api_key: str) -> tuple[str | None, List[Dict[str, Any]]]:
    """Fetch the user's organizations. Returns (current_org_id, orgs_list) or (None, []) on failure."""
    s, b = http_request("POST", f"{base_url}/api/v2/auth/cli/organizations", api_key, {"api_key": api_key})
    if s != 200:
        return None, []
    try:
        data = json.loads(b or "{}")
    except Exception:
        return None, []
    return data.get("current_org_id"), data.get("organizations", [])


def _print_org_list(current_org_id: str | None, orgs: List[Dict[str, Any]]) -> None:
    for i, org in enumerate(orgs, 1):
        marker = " (current)" if org.get("is_current") else ""
        role = org.get("role", "")
        role_suffix = f" [{role}]" if role else ""
        print(f"  {i}. {org.get('name', '(unnamed)')}{role_suffix}{marker}")


def _print_org_switch_help(current_org_id: str | None, orgs: List[Dict[str, Any]]) -> None:
    print("Your organizations:")
    _print_org_list(current_org_id, orgs)
    print("")
    print("Switching is non-interactive.")
    print("Run: deepline org switch <number>")
    print("Then run: deepline org list")
    print("Tip: 'deepline auth org-switch' is still supported as a legacy alias.")


@router.route(
    "orgs",
    "org-list",
    summary="List your organizations.",
    usage="deepline auth orgs",
)
def handle_orgs(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print_lines([
            "Usage:",
            "  deepline auth orgs",
            "",
            "List your organizations and show which one is current.",
        ])
        return EXIT_OK

    api_key = env.get("DEEPLINE_API_KEY", "").strip()
    if not api_key:
        print("Not connected. Run: deepline auth register")
        return EXIT_AUTH

    current_org_id, orgs = _fetch_user_organizations(base_url, api_key)
    if not orgs:
        print("Could not fetch organizations. Are you connected?")
        return EXIT_SERVER

    _print_org_switch_help(current_org_id, orgs)
    return EXIT_OK


@router.route(
    "org-switch",
    summary="Switch to a different organization.",
    usage="deepline auth org-switch [ORG_NUMBER]",
)
def handle_switch(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print_lines([
            "Usage:",
            "  deepline auth org-switch [ORG_NUMBER]",
            "",
            "Switch your CLI to a different organization.",
            "Legacy alias for 'deepline org switch'.",
            "If ORG_NUMBER is omitted, lists your organizations and shows how to switch.",
        ])
        return EXIT_OK

    api_key = env.get("DEEPLINE_API_KEY", "").strip()
    if not api_key:
        print("Not connected. Run: deepline auth register")
        return EXIT_AUTH

    current_org_id, orgs = _fetch_user_organizations(base_url, api_key)
    if not orgs:
        print("Could not fetch organizations. Are you connected?")
        return EXIT_SERVER
    if len(orgs) == 1:
        print(f"You only belong to one organization: {orgs[0].get('name', '(unnamed)')}")
        print("Run: deepline org list")
        return EXIT_OK

    if not args:
        _print_org_switch_help(current_org_id, orgs)
        return EXIT_OK

    choice_str = args[0]

    try:
        choice = int(choice_str)
    except ValueError:
        print(f"Invalid selection: {choice_str}")
        return EXIT_USAGE

    if choice < 1 or choice > len(orgs):
        print(f"Invalid selection: {choice}. Choose 1-{len(orgs)}.")
        return EXIT_USAGE

    target = orgs[choice - 1]
    if target.get("is_current"):
        print(f"Already on {target.get('name', '(unnamed)')}.")
        print("Run: deepline org list")
        return EXIT_OK

    target_org_id = target.get("org_id", "")
    s, b = http_request(
        "POST", f"{base_url}/api/v2/auth/cli/switch", api_key,
        {"api_key": api_key, "org_id": target_org_id},
    )
    if s != 200:
        print(f"Switch failed (status {s}).", file=os.sys.stderr)
        if b and b.strip():
            log(b.strip(), err=True)
        return EXIT_SERVER

    try:
        switch_data = json.loads(b or "{}")
    except Exception:
        print("Switch failed: invalid response.", file=os.sys.stderr)
        return EXIT_SERVER

    new_api_key = switch_data.get("api_key", "")
    if not new_api_key:
        print("Switch failed: no API key returned.", file=os.sys.stderr)
        return EXIT_SERVER

    save_cli_env_values({"DEEPLINE_API_KEY": new_api_key, "DEEPLINE_CLAIM_TOKEN": ""}, base_url)
    print(f"\nSwitched to: {switch_data.get('org_name', target.get('name', '(unnamed)'))}")
    print("Run: deepline org list")
    return EXIT_OK


@router.route(
    "org-create",
    summary="Create a new organization.",
    usage="deepline auth org-create <NAME>",
)
def handle_org_create(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print_lines([
            "Usage:",
            "  deepline auth org-create <NAME>",
            "",
            "Create a new organization and switch to it.",
            "You can belong to at most 3 organizations.",
        ])
        return EXIT_OK

    api_key = env.get("DEEPLINE_API_KEY", "").strip()
    if not api_key:
        print("Not connected. Run: deepline auth register")
        return EXIT_AUTH

    # Collect org name from args or prompt
    org_name = " ".join(args).strip() if args else ""
    if not org_name:
        if not os.isatty(0):
            print("Organization name required: deepline auth org-create <NAME>")
            return EXIT_USAGE
        try:
            org_name = input("Organization name: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("")
            return EXIT_OK
    if not org_name:
        print("Organization name cannot be empty.")
        return EXIT_USAGE

    s, b = http_request(
        "POST", f"{base_url}/api/v2/auth/cli/org-create", api_key,
        {"api_key": api_key, "name": org_name},
    )
    if s != 200:
        try:
            err_data = json.loads(b or "{}")
            err_msg = err_data.get("error", f"status {s}")
        except Exception:
            err_msg = f"status {s}"
        print(f"Failed to create organization: {err_msg}", file=os.sys.stderr)
        return EXIT_SERVER

    try:
        data = json.loads(b or "{}")
    except Exception:
        print("Failed to create organization: invalid response.", file=os.sys.stderr)
        return EXIT_SERVER

    new_api_key = data.get("api_key", "")
    created_name = data.get("org_name", org_name)

    print(f"Created organization: {created_name}")

    if new_api_key:
        if not os.isatty(0):
            # Non-interactive: auto-switch
            save_cli_env_values({"DEEPLINE_API_KEY": new_api_key, "DEEPLINE_CLAIM_TOKEN": ""}, base_url)
            print(f"Switched to: {created_name}")
        else:
            try:
                answer = input(f"Switch to {created_name} now? [Y/n] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                answer = "n"
            if answer in ("", "y", "yes"):
                save_cli_env_values({"DEEPLINE_API_KEY": new_api_key, "DEEPLINE_CLAIM_TOKEN": ""}, base_url)
                print(f"Switched to: {created_name}")
            else:
                print("Staying on current organization. Run 'deepline org switch <number>' to switch later.")

    return EXIT_OK


@router.route(
    "wait",
    summary="Wait for DEEPLINE_CLAIM_TOKEN approval.",
    usage="deepline auth wait",
)
def handle_wait(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print_lines(["Usage:", "  deepline auth wait", "", "Tip: waits for DEEPLINE_CLAIM_TOKEN to be claimed."])
        return EXIT_OK
    claim_token = str(env.get("DEEPLINE_CLAIM_TOKEN") or "").strip()
    if not claim_token:
        print("We couldn't find a pending approval. Please run: deepline auth register")
        return EXIT_AUTH
    while True:
        s, b = http_request("POST", f"{base_url}/api/v2/auth/cli/status", None, {"claim_token": claim_token, "reveal": True})
        if s in (401, 403):
            print("Status: unauthorized")
            return EXIT_AUTH
        if s >= 500:
            time.sleep(2)
            continue
        if s == 400:
            try:
                status_data = json.loads(b or "{}")
            except Exception:
                status_data = {}
            err_message = str(status_data.get("error") or status_data.get("message") or "").lower()
            if "expired" in err_message:
                print("That approval link expired. Please run: deepline auth register")
                return EXIT_AUTH
            print("We couldn't find a pending approval. Please run: deepline auth register")
            return EXIT_AUTH
        if s >= 400:
            print(f"Auth status error (status {s}).", file=os.sys.stderr)
            if b.strip():
                print(b.strip(), file=os.sys.stderr)
            return EXIT_SERVER
        try:
            status_data = json.loads(b)
        except Exception:
            time.sleep(2)
            continue
        state = str(status_data.get("status") or "").strip().lower()
        if state == "claimed":
            api_key = str(status_data.get("api_key") or "")
            if api_key:
                save_cli_env_values({"DEEPLINE_API_KEY": api_key, "DEEPLINE_CLAIM_TOKEN": ""}, base_url)
                print("")
                _print_deepline_logo()
                print("✓ All set! Your CLI is connected.")
                return EXIT_OK
        if state == "expired":
            print("That approval link expired. Please run: deepline auth register")
            return EXIT_AUTH
        time.sleep(2)


def _auth_unknown(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    # preserve legacy auth status invocation: "deepline auth status --reveal" and "deepline auth --reveal"
    return handle_status(base_url, env, bool("--reveal" in args))


handle = build_command_handler(
    command_name="auth",
    router=router,
    usage_factory=usage_auth_computed,
    on_unknown=_auth_unknown,
)
