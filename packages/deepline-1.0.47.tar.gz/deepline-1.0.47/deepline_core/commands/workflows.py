from __future__ import annotations

import json
import os
import time
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

from deepline_core.browser import open_url_in_browser
from deepline_core.command_common import (
    EXIT_AUTH,
    EXIT_NOT_FOUND,
    EXIT_OK,
    EXIT_SERVER,
    EXIT_USAGE,
    EXIT_VALIDATION,
    require_api_key,
)
from deepline_core.command_decorators import OptionSpec, ParsedRouteOptions, SubcommandRouter, build_command_handler
from deepline_core.http import http_request

router = SubcommandRouter()
WORKFLOW_BROWSER_OPEN_COOLDOWN_SECONDS = 600.0
WORKFLOW_RUN_DUMP_DIR = Path("deepline") / "data"


def usage_workflows_computed() -> list[str]:
    lines = router.usage_lines("deepline workflows")
    lines.extend([
        "",
        "Tips:",
        "  Use `deepline workflows schema --json` to inspect the live workflow request schemas.",
        "  `apply` uses the enrich config schema for `config`, plus workflow trigger fields.",
        "  `call` wraps your JSON payload as `{ \"input\": ... }` on the API.",
    ])
    return lines


def _format_workflows_error(status: int, body: str) -> None:
    if status in (401, 403):
        print(f"Auth error (status {status}). Check DEEPLINE_API_KEY.", file=sys.stderr)
        return
    if status == 404:
        print("Workflow not found.", file=sys.stderr)
        return
    print(f"API error (status {status}).", file=sys.stderr)
    try:
        parsed = json.loads(body or "{}")
    except Exception:
        parsed = {}
    if isinstance(parsed, dict) and parsed.get("error"):
        print(parsed["error"], file=sys.stderr)
        details = parsed.get("details")
        if isinstance(details, list) and details:
            print("Details:", file=sys.stderr)
            for detail in details:
                if not isinstance(detail, dict):
                    continue
                path = str(detail.get("path") or "").strip()
                message = str(detail.get("message") or "").strip()
                if path and message:
                    print(f"- {path}: {message}", file=sys.stderr)
                elif message:
                    print(f"- {message}", file=sys.stderr)
        hints = parsed.get("hints")
        if isinstance(hints, list) and hints:
            print("Hints:", file=sys.stderr)
            for hint in hints:
                if not isinstance(hint, dict):
                    continue
                path = str(hint.get("path") or "").strip()
                message = str(hint.get("message") or "").strip()
                if path and message:
                    print(f"- {path}: {message}", file=sys.stderr)
                elif message:
                    print(f"- {message}", file=sys.stderr)
        return
    elif body:
        print(body, file=sys.stderr)


def _workflow_exit_code(status: int) -> int:
    if status in (400, 422):
        return EXIT_VALIDATION
    if status in (401, 403):
        return EXIT_AUTH
    if status == 404:
        return EXIT_NOT_FOUND
    return EXIT_SERVER


def _safe_json_object(body: str) -> Dict[str, object]:
    try:
        parsed = json.loads(body or "{}")
    except Exception:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _workflow_browser_state_file() -> Path:
    home_dir = os.environ.get("HOME", str(Path.home()))
    return Path(home_dir) / ".local" / "deepline" / "runtime" / "state" / "workflow-browser-open.json"


def _lock_state_file(handle: object) -> None:
    try:
        import fcntl
    except Exception:
        return
    fileno = getattr(handle, "fileno", None)
    if callable(fileno):
        fcntl.flock(fileno(), fcntl.LOCK_EX)


def _unlock_state_file(handle: object) -> None:
    try:
        import fcntl
    except Exception:
        return
    fileno = getattr(handle, "fileno", None)
    if callable(fileno):
        fcntl.flock(fileno(), fcntl.LOCK_UN)


def _should_open_workflow_browser(now: float | None = None) -> bool:
    current_time = time.time() if now is None else float(now)
    state_path = _workflow_browser_state_file()
    try:
        state_path.parent.mkdir(parents=True, exist_ok=True)
        state_path.touch(exist_ok=True)
        with state_path.open("r+", encoding="utf-8") as handle:
            _lock_state_file(handle)
            try:
                handle.seek(0)
                payload_raw = handle.read().strip()
                last_opened_at = 0.0
                if payload_raw:
                    payload = json.loads(payload_raw)
                    if isinstance(payload, dict):
                        last_value = payload.get("last_opened_at")
                        if isinstance(last_value, (int, float)):
                            last_opened_at = max(0.0, float(last_value))
                if current_time - last_opened_at < WORKFLOW_BROWSER_OPEN_COOLDOWN_SECONDS:
                    return False
                handle.seek(0)
                handle.truncate()
                json.dump({"last_opened_at": current_time}, handle)
                handle.flush()
                os.fsync(handle.fileno())
                return True
            finally:
                _unlock_state_file(handle)
    except Exception:
        return True


def _open_workflow_dashboard(base_url: str, workflow_id: object) -> None:
    workflow_id_text = str(workflow_id or "").strip()
    if not workflow_id_text or not _should_open_workflow_browser():
        return
    open_url_in_browser(f"{base_url.rstrip('/')}/dashboard/workflows/{workflow_id_text}")


def _format_duration_ms(value: object) -> str:
    if not isinstance(value, (int, float)):
        return "unknown"
    millis = max(0, int(value))
    if millis < 1000:
        return f"{millis}ms"
    seconds = millis / 1000.0
    if seconds < 60:
        return f"{seconds:.2f}s"
    minutes = int(seconds // 60)
    remaining = seconds - (minutes * 60)
    return f"{minutes}m {remaining:.1f}s"


def _compact_json(value: object, limit: int = 160) -> str:
    try:
        rendered = json.dumps(value, sort_keys=True)
    except Exception:
        rendered = str(value)
    if len(rendered) <= limit:
        return rendered
    return f"{rendered[: limit - 3]}..."


def _summarize_value(value: object, depth: int = 0) -> object:
    if depth > 3:
        return _compact_json(value, limit=80)
    if isinstance(value, dict):
        kind = str(value.get("__type") or "").strip()
        if kind == "array":
            length = value.get("length")
            return f"{length} items" if isinstance(length, int) else "array"
        if kind == "object":
            keys = value.get("keys")
            key_count = value.get("key_count")
            if isinstance(keys, list) and keys:
                preview = ", ".join(str(key) for key in keys[:6])
                remaining = max(0, len(keys) - 6)
                suffix = f", +{remaining} more" if remaining else ""
                return f"object ({key_count or len(keys)} keys): {preview}{suffix}"
            return f"object ({key_count or 0} keys)"
        if kind == "truncated_string":
            preview = str(value.get("preview") or "").strip()
            original_length = value.get("original_length")
            suffix = "..." if preview and not preview.endswith("...") else ""
            if isinstance(original_length, int) and original_length > 0:
                return f"{preview[:200]}{suffix} ({original_length} chars)"
            return f"{preview[:200]}{suffix}"
        if depth == 0:
            summarized: Dict[str, object] = {}
            for key, entry in value.items():
                if isinstance(entry, list) and len(entry) > 3:
                    summarized[key] = {
                        "count": len(entry),
                        "sample": [_summarize_value(item, depth + 1) for item in entry[:2]],
                    }
                    continue
                summarized[key] = _summarize_value(entry, depth + 1)
            return summarized
        return {key: _summarize_value(entry, depth + 1) for key, entry in value.items()}
    if isinstance(value, list):
        if not value:
            return []
        if len(value) > 4:
            return {
                "count": len(value),
                "sample": [_summarize_value(item, depth + 1) for item in value[:2]],
            }
        return [_summarize_value(item, depth + 1) for item in value]
    return value


def _print_json_block(label: str, value: object) -> None:
    print(f"{label}:")
    print(json.dumps(_summarize_value(value), indent=2, sort_keys=True))


def _write_run_detail_dump(payload: Dict[str, object], run_id: str) -> str | None:
    safe_run_id = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in run_id).strip()
    if not safe_run_id:
        safe_run_id = "unknown"
    output_dir = WORKFLOW_RUN_DUMP_DIR
    output_dir.mkdir(parents=True, exist_ok=True)
    path = str(output_dir / f"deepline-workflow-run-{safe_run_id}.json")
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
    except Exception:
        return None
    return path


def _step_heading(step: Dict[str, object]) -> str:
    alias = str(step.get("alias") or "").strip()
    block_id = str(step.get("block_id") or "").strip() or "(unknown)"
    tool_id = str(step.get("tool_id") or "").strip()
    label = alias or block_id
    if tool_id:
        return f"{label} [{tool_id}]"
    return label


def _run_summary_text(run: Dict[str, object]) -> str:
    output_summary = run.get("output_summary")
    if isinstance(output_summary, dict):
        error = output_summary.get("error")
        if isinstance(error, str) and error.strip():
            return error.strip()
    active_step = run.get("active_step_block_id")
    if isinstance(active_step, str) and active_step.strip():
        return f"active_step={active_step.strip()}"
    if output_summary is not None:
        return _compact_json(output_summary, limit=120)
    return "-"


def _extract_run_error(run: Dict[str, object]) -> str:
    output_summary = run.get("output_summary")
    if isinstance(output_summary, dict):
        error = output_summary.get("error")
        if isinstance(error, str) and error.strip():
            return error.strip()
    return ""


def _workflow_list_trigger_type(workflow: Dict[str, object]) -> str:
    trigger = workflow.get("trigger")
    if isinstance(trigger, dict):
        trigger_type = str(trigger.get("type") or "").strip().lower()
        if trigger_type:
            return trigger_type
    return "unbound"


def _workflow_list_schedule(workflow: Dict[str, object]) -> str:
    trigger = workflow.get("trigger")
    activity = workflow.get("activity")
    trigger_type = _workflow_list_trigger_type(workflow)
    if trigger_type == "cron" and isinstance(trigger, dict):
        cron = str(trigger.get("cron") or "").strip() or "(missing cron)"
        next_at = ""
        if isinstance(activity, dict):
            next_at = str(activity.get("next_scheduled_at") or "").strip()
        if not next_at:
            next_at = str(trigger.get("next_scheduled_at") or "").strip()
        return f"{cron} | next {next_at}" if next_at else cron
    if trigger_type == "webhook" and isinstance(trigger, dict):
        trigger_name = str(trigger.get("trigger_name") or "").strip()
        trigger_tool = str(trigger.get("trigger_tool") or "").strip()
        trigger_id = str(trigger.get("trigger_id") or "").strip()
        detail = trigger_name or trigger_id or trigger_tool
        return detail or "webhook"
    if trigger_type == "api":
        return "on-demand API"
    return "-"


def _print_workflow_list(workflows: list[object]) -> None:
    normalized: list[Dict[str, object]] = [workflow for workflow in workflows if isinstance(workflow, dict)]
    if not normalized:
        print("No workflows configured.")
        return

    print("STATUS\tTRIGGER\tSCHEDULE\tNAME\tID")
    for workflow in normalized:
        print(
            f"{workflow.get('status', '(unknown)')}\t"
            f"{_workflow_list_trigger_type(workflow)}\t"
            f"{_workflow_list_schedule(workflow)}\t"
            f"{workflow.get('name', '(unnamed)')}\t"
            f"{workflow.get('id', '(unknown)')}"
        )


def _print_runs_table(runs: list[object]) -> None:
    normalized: list[Dict[str, object]] = [run for run in runs if isinstance(run, dict)]
    if not normalized:
        print("No runs found.")
        return

    print("RUN ID\tSTATUS\tDURATION\tUPDATED\tSUMMARY")
    for run in normalized:
        print(
            f"{run.get('id', '(unknown)')}\t"
            f"{run.get('status', '(unknown)')}\t"
            f"{_format_duration_ms(run.get('duration_ms'))}\t"
            f"{run.get('updated_at', '-')}\t"
            f"{_run_summary_text(run)}"
        )


def _print_run_detail_summary(payload: Dict[str, object]) -> None:
    run = payload.get("run")
    if not isinstance(run, dict):
        print(json.dumps(payload, indent=2))
        return

    run_id = str(run.get("id") or "").strip()
    dump_path = _write_run_detail_dump(payload, run_id)

    run_status = str(run.get("status", "(unknown)"))
    run_duration = _format_duration_ms(run.get("duration_ms"))
    active_step = str(run.get("active_step_block_id") or "").strip()
    run_error = _extract_run_error(run)
    summary = f"Run status: {run_status} ({run_duration})"
    if active_step and not run_error:
        summary = f"{summary} - active node: {active_step}"
    print(summary)
    if dump_path:
        print(f"Full run detail: {dump_path}")
    if run_error:
        print("Run error:")
        print(run_error)

    run_input = payload.get("run_input")
    if run_input is None:
        run_input = run.get("input_summary")
    if run_input is not None:
        _print_json_block("Run input", run_input)

    output_summary = run.get("output_summary")
    if output_summary is not None:
        _print_json_block("Run output", output_summary)

    steps = payload.get("steps")
    if isinstance(steps, list) and steps:
        print("Nodes:")
        grouped_steps: Dict[str, List[Dict[str, object]]] = {}
        step_order: List[str] = []
        for step in steps:
            if not isinstance(step, dict):
                continue
            block_id = str(step.get("block_id") or "").strip() or "(unknown)"
            if block_id not in grouped_steps:
                grouped_steps[block_id] = []
                step_order.append(block_id)
            grouped_steps[block_id].append(step)

        for index, block_id in enumerate(step_order, start=1):
            attempts = grouped_steps[block_id]
            latest = attempts[-1]
            status = str(latest.get("status", "(unknown)"))
            attempt_count = len(attempts)
            attempt_suffix = "" if attempt_count == 1 else f", retries={attempt_count - 1}"
            print(
                f"{index}. {_step_heading(latest)} - {status} "
                f"({_format_duration_ms(latest.get('duration_ms'))}{attempt_suffix})"
            )

            step_input = latest.get("input_summary")
            if step_input is not None:
                _print_json_block("Input", step_input)

            step_output = latest.get("output_summary")
            if step_output is not None:
                _print_json_block("Output", step_output)

            error_summary = latest.get("error_summary")
            if error_summary:
                print("Error:")
                print(str(error_summary))

    child_runs = payload.get("child_runs")
    if isinstance(child_runs, list) and child_runs:
        grouped: Dict[str, Counter[str]] = {}
        errors_by_workflow: Dict[str, List[str]] = {}
        ids_by_workflow: Dict[str, List[str]] = {}
        kicked_off_by_workflow: Dict[str, List[str]] = {}
        workflow_ids_by_name: Dict[str, str] = {}
        for child in child_runs:
            if not isinstance(child, dict):
                continue
            workflow_id = str(child.get("workflow_id") or "").strip()
            workflow_name = str(child.get("workflow_name") or workflow_id or "(unknown)")
            status = str(child.get("status") or "(unknown)")
            grouped.setdefault(workflow_name, Counter())[status] += 1
            if workflow_id and workflow_name not in workflow_ids_by_name:
                workflow_ids_by_name[workflow_name] = workflow_id
            child_id = str(child.get("id") or "").strip()
            if child_id:
                ids = ids_by_workflow.setdefault(workflow_name, [])
                ids.append(child_id)
            created_at = str(child.get("created_at") or "").strip()
            if created_at:
                created_times = kicked_off_by_workflow.setdefault(workflow_name, [])
                created_times.append(created_at)
            error = str(child.get("error_summary") or "").strip()
            if error:
                errors = errors_by_workflow.setdefault(workflow_name, [])
                if error not in errors:
                    errors.append(error)
        print("Child workflows:")
        for workflow_name, status_counts in grouped.items():
            counts = ", ".join(f"{count} {status}" for status, count in sorted(status_counts.items()))
            workflow_id_suffix = ""
            workflow_id = workflow_ids_by_name.get(workflow_name, "")
            if workflow_id:
                workflow_id_suffix = f" (workflow id: {workflow_id})"
            print(f"- {workflow_name}{workflow_id_suffix}: {counts}")
            kicked_off_at = min(kicked_off_by_workflow.get(workflow_name, []) or [""])
            if kicked_off_at:
                print(f"  kicked off: {kicked_off_at}")
            child_ids = ids_by_workflow.get(workflow_name, [])
            if child_ids:
                joined_ids = ", ".join(child_ids[:5])
                suffix = f", +{len(child_ids) - 5} more" if len(child_ids) > 5 else ""
                print(f"  workflow run ids: {joined_ids}{suffix}")
            for error in errors_by_workflow.get(workflow_name, [])[:2]:
                print(f"  error: {error}")


def _fetch_workflow_run_detail(base_url: str, env: Dict[str, str], workflow_id: str, run_id: str) -> tuple[int, str]:
    return http_request(
        "GET",
        f"{base_url}/api/v2/workflows/{workflow_id}/runs/{run_id}",
        env.get("DEEPLINE_API_KEY"),
        timeout=90,
        connect_timeout=5,
    )


def _terminal_run_status(status: object) -> bool:
    # `stopped` = a step intentionally halted the run via the
    # `__workflow_stop` sentinel. Terminal, distinct from `failed`.
    return str(status or "").strip().lower() in {
        "completed",
        "failed",
        "canceled",
        "cancelled",
        "stopped",
    }


def _is_workflow_run_not_found(status: int, body: str) -> bool:
    if status != 404:
        return False
    payload = _safe_json_object(body)
    error = payload.get("error")
    return isinstance(error, str) and error.strip().lower() == "workflow run not found."


def _is_retryable_workflow_run_detail_failure(status: int, body: str) -> bool:
    if status in {408, 429, 500, 502, 503, 504}:
        return True
    if status != 404:
        return False
    # Run detail fetches can briefly 404 while auth/Convex recovers or right after queueing.
    return True


def _fetch_workflow_run_detail_with_retry(
    base_url: str,
    env: Dict[str, str],
    workflow_id: str,
    run_id: str,
    *,
    max_retryable_retries: int,
    interval_ms: int,
) -> tuple[int, str]:
    attempts = 0
    while True:
        status, body = _fetch_workflow_run_detail(base_url, env, workflow_id, run_id)
        if not _is_retryable_workflow_run_detail_failure(status, body) or attempts >= max_retryable_retries:
            return status, body
        attempts += 1
        time.sleep(max(interval_ms, 100) / 1000.0)


@dataclass(frozen=True)
class WorkflowListParams:
    output_json: bool
    org: str | None
    org_name: str | None
    org_id: str | None


def parse_list(parsed: ParsedRouteOptions) -> WorkflowListParams:
    org = str(parsed.options.get("org") or "").strip() or None
    return WorkflowListParams(
        output_json=bool(parsed.options.get("json")),
        org=org,
        org_name=str(parsed.options.get("org_name") or "").strip() or org,
        org_id=str(parsed.options.get("org_id") or "").strip() or None,
    )


def _fetch_user_orgs(base_url: str, api_key: str) -> tuple[str | None, List[Dict[str, object]]]:
    """Fetch orgs for the current user. Returns (current_org_id, orgs_list)."""
    s, b = http_request("POST", f"{base_url}/api/v2/auth/cli/organizations", api_key, {"api_key": api_key})
    if s != 200:
        return None, []
    try:
        data = json.loads(b or "{}")
    except Exception:
        return None, []
    return data.get("current_org_id"), data.get("organizations", [])


def _switch_org(base_url: str, api_key: str, org_id: str) -> str | None:
    """Switch to org_id, return new api_key or None on failure."""
    s, b = http_request("POST", f"{base_url}/api/v2/auth/cli/switch", api_key, {"api_key": api_key, "org_id": org_id})
    if s != 200:
        return None
    try:
        data = json.loads(b or "{}")
    except Exception:
        return None
    return data.get("api_key")


def _resolve_org_context(
    base_url: str,
    api_key: str,
    *,
    org: str | None = None,
    org_name: str | None = None,
    org_id: str | None = None,
) -> tuple[str, str | None, str | None]:
    current_org_id, orgs = _fetch_user_orgs(base_url, api_key)
    if not orgs:
        return api_key, None, None

    target = None
    exact_id = org_id or (org if any(str(item.get("org_id") or "").strip() == org for item in orgs) else None)
    name_query = org_name or (None if exact_id else org)
    if exact_id:
        for org in orgs:
            if str(org.get("org_id") or "").strip() == exact_id:
                target = org
                break
        if target is None:
            raise ValueError(f"No organization matched --org-id {exact_id}.")
    elif name_query:
        lowered = name_query.lower()
        matches = [
            org
            for org in orgs
            if lowered in str(org.get("name") or "").strip().lower()
        ]
        if not matches:
            raise ValueError(f"No organization matched --org {name_query!r}.")
        if len(matches) > 1:
            names = ", ".join(str(match.get("name") or "").strip() for match in matches[:5])
            raise ValueError(
                f"Multiple organizations matched --org {name_query!r}: {names}. Use --org-id for an exact target."
            )
        target = matches[0]
    else:
        for org in orgs:
            if str(org.get("org_id") or "").strip() == str(current_org_id or "").strip():
                target = org
                break

    if target is None:
        return api_key, None, current_org_id

    target_org_id = str(target.get("org_id") or "").strip() or None
    target_org_name = str(target.get("name") or "").strip() or None
    if not target_org_id:
        return api_key, target_org_name, None
    if target_org_id == str(current_org_id or "").strip():
        return api_key, target_org_name, target_org_id

    switched_key = _switch_org(base_url, api_key, target_org_id)
    if not switched_key:
        raise ValueError(
            f"Could not switch to organization {target_org_name or target_org_id}."
        )
    return switched_key, target_org_name, target_org_id


def _print_resolved_org(org_name: str | None, org_id: str | None) -> None:
    if org_name and org_id:
        print(f"Resolved org: {org_name} ({org_id})", file=sys.stderr)
    elif org_name:
        print(f"Resolved org: {org_name}", file=sys.stderr)
    elif org_id:
        print(f"Resolved org: {org_id}", file=sys.stderr)


def _list_workflows_single_org(base_url: str, api_key: str, output_json: bool) -> int:
    """Fallback: list workflows for the current org only."""
    status, body = http_request("GET", f"{base_url}/api/v2/workflows", api_key)
    if status >= 400:
        _format_workflows_error(status, body)
        return _workflow_exit_code(status)
    if output_json:
        print(body)
        return EXIT_OK
    try:
        payload = json.loads(body or "{}")
    except Exception:
        payload = {}
    workflows = payload.get("workflows") if isinstance(payload, dict) else None
    if not isinstance(workflows, list) or not workflows:
        print("No workflows configured.")
        return EXIT_OK
    _print_workflow_list(workflows)
    return EXIT_OK


@router.route_typed(
    "list",
    summary="List workflows across all orgs. Filter with --org or --org-id.",
    usage="deepline workflows list [--org NAME_OR_ID] [--org-id ID] [--json]",
    options=[
        OptionSpec("--org", "Filter by organization name or exact org id.", takes_value=True, value_name="NAME_OR_ID", key="org"),
        OptionSpec("--org-name", "Filter by org name (substring match).", takes_value=True, value_name="NAME", key="org_name"),
        OptionSpec("--org-id", "Filter by org id (exact match).", takes_value=True, value_name="ID", key="org_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_list,
)
def handle_list(base_url: str, env: Dict[str, str], params: WorkflowListParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    api_key = env.get("DEEPLINE_API_KEY", "")

    current_org_id, orgs = _fetch_user_orgs(base_url, api_key)
    if not orgs:
        # Org endpoint unavailable — fall back to single-org listing
        return _list_workflows_single_org(base_url, api_key, params.output_json)

    name_filter = params.org_name.lower() if params.org_name else None
    id_filter = params.org_id.strip() if params.org_id else None

    all_results: List[Dict[str, object]] = []
    for org in orgs:
        org_id = str(org.get("org_id", ""))
        org_name = str(org.get("name", "(unnamed)"))
        is_current = bool(org.get("is_current"))

        if name_filter and name_filter not in org_name.lower():
            continue
        if id_filter and id_filter != org_id:
            continue

        if is_current:
            key_for_org = api_key
        else:
            key_for_org = _switch_org(base_url, api_key, org_id)
            if not key_for_org:
                print(f"  (could not switch to {org_name}, skipping)", file=sys.stderr)
                continue

        status, body = http_request("GET", f"{base_url}/api/v2/workflows", key_for_org)
        if status >= 400:
            print(f"  (error listing {org_name}: status {status})", file=sys.stderr)
            continue
        try:
            payload = json.loads(body or "{}")
        except Exception:
            payload = {}
        workflows = payload.get("workflows") if isinstance(payload, dict) else None
        if isinstance(workflows, list):
            for wf in workflows:
                if isinstance(wf, dict):
                    wf["_org_name"] = org_name
            all_results.extend(workflows)

    if params.output_json:
        print(json.dumps(all_results))
        return EXIT_OK

    if not all_results:
        print("No workflows found.")
        return EXIT_OK

    print("ORG\tSTATUS\tTRIGGER\tSCHEDULE\tNAME\tID")
    for wf in all_results:
        if not isinstance(wf, dict):
            continue
        print(
            f"{wf.get('_org_name', '?')}\t"
            f"{wf.get('status', '(unknown)')}\t"
            f"{_workflow_list_trigger_type(wf)}\t"
            f"{_workflow_list_schedule(wf)}\t"
            f"{wf.get('name', '(unnamed)')}\t"
            f"{wf.get('id', '(unknown)')}"
        )
    return EXIT_OK


@dataclass(frozen=True)
class WorkflowGetParams:
    workflow_id: str
    output_json: bool


def parse_get(parsed: ParsedRouteOptions) -> WorkflowGetParams:
    workflow_id = str(parsed.options.get("workflow_id") or "").strip()
    if not workflow_id:
        raise ValueError("Missing --workflow-id <ID>.")
    return WorkflowGetParams(workflow_id=workflow_id, output_json=bool(parsed.options.get("json")))


@router.route_typed(
    "get",
    summary="Fetch a single workflow.",
    usage="deepline workflows get --workflow-id <ID> [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_get,
)
def handle_get(base_url: str, env: Dict[str, str], params: WorkflowGetParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    status, body = http_request(
        "GET",
        f"{base_url}/api/v2/workflows/{params.workflow_id}",
        env.get("DEEPLINE_API_KEY"),
    )
    if status >= 400:
        _format_workflows_error(status, body)
        return _workflow_exit_code(status)
    if params.output_json:
        print(body)
        return EXIT_OK
    try:
        payload = json.loads(body or "{}")
    except Exception:
        payload = {}
    workflow = payload.get("workflow") if isinstance(payload, dict) else None
    validation = payload.get("validation") if isinstance(payload, dict) else None
    if not isinstance(workflow, dict):
        print(body)
        return EXIT_OK
    print(f"ID: {workflow.get('id', '(unknown)')}")
    print(f"Name: {workflow.get('name', '(unnamed)')}")
    print(f"Status: {workflow.get('status', '(unknown)')}")
    print(f"Published version: {workflow.get('current_published_version', '(unknown)')}")
    if isinstance(validation, dict):
        validation_status = str(validation.get("status") or "").strip() or "unknown"
        if validation_status == "valid":
            print("Schema: valid")
        else:
            print("Schema drift detected")
            revisions = validation.get("revisions")
            if isinstance(revisions, list):
                for revision in revisions:
                    if not isinstance(revision, dict):
                        continue
                    if str(revision.get("status") or "").strip() != "schema_drift":
                        continue
                    publish_state = str(revision.get("publish_state") or "unknown")
                    revision_id = str(revision.get("revision_id") or "(unknown)")
                    message = str(revision.get("message") or "Workflow config no longer validates.")
                    print(f"- {publish_state} revision {revision_id}: {message}")
    return EXIT_OK


@dataclass(frozen=True)
class WorkflowDeleteParams:
    workflow_id: str
    output_json: bool
    org: str | None
    org_name: str | None
    org_id: str | None


def parse_delete(parsed: ParsedRouteOptions) -> WorkflowDeleteParams:
    workflow_id = str(parsed.options.get("workflow_id") or "").strip()
    if not workflow_id:
        raise ValueError("Missing --workflow-id <ID>.")
    return WorkflowDeleteParams(
        workflow_id=workflow_id,
        output_json=bool(parsed.options.get("json")),
        org=str(parsed.options.get("org") or "").strip() or None,
        org_name=str(parsed.options.get("org_name") or "").strip() or None,
        org_id=str(parsed.options.get("org_id") or "").strip() or None,
    )


@router.route_typed(
    "delete",
    summary="Delete a workflow and its stored runs/revisions.",
    usage="deepline workflows delete --workflow-id <ID> [--org NAME_OR_ID | --org-id ID] [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--org", "Target organization name or exact org id.", takes_value=True, value_name="NAME_OR_ID", key="org"),
        OptionSpec("--org-name", "Target organization name (substring match).", takes_value=True, value_name="NAME", key="org_name"),
        OptionSpec("--org-id", "Target organization id.", takes_value=True, value_name="ID", key="org_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_delete,
)
def handle_delete(base_url: str, env: Dict[str, str], params: WorkflowDeleteParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    api_key = env.get("DEEPLINE_API_KEY", "")
    try:
        api_key, org_name, org_id = _resolve_org_context(
            base_url,
            api_key,
            org=params.org,
            org_name=params.org_name,
            org_id=params.org_id,
        )
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return EXIT_USAGE
    _print_resolved_org(org_name, org_id)
    status, body = http_request(
        "DELETE",
        f"{base_url}/api/v2/workflows/{params.workflow_id}",
        api_key,
    )
    if status >= 400:
        _format_workflows_error(status, body)
        return _workflow_exit_code(status)
    if params.output_json:
        print(body)
        return EXIT_OK
    payload = _safe_json_object(body)
    deleted = payload.get("deleted")
    if not isinstance(deleted, dict):
        print("Deleted workflow.")
        return EXIT_OK
    workflow_id = str(deleted.get("workflow_id") or params.workflow_id or "").strip() or "(unknown)"
    workflow_name = str(deleted.get("workflow_name") or "").strip() or "(unnamed)"
    print(f"Deleted workflow {workflow_name} ({workflow_id}).")
    print(
        "Removed "
        f"{int(deleted.get('deleted_binding_count') or 0)} binding(s), "
        f"{int(deleted.get('deleted_revision_count') or 0)} revision(s), "
        f"{int(deleted.get('deleted_run_count') or 0)} run(s), "
        f"{int(deleted.get('deleted_step_count') or 0)} step(s), "
        f"{int(deleted.get('deleted_dispatch_count') or 0)} dispatch(es), and "
        f"{int(deleted.get('deleted_delivery_count') or 0)} delivery record(s)."
    )
    return EXIT_OK


@router.route_typed(
    "disable",
    summary="Disable a workflow without deleting it.",
    usage="deepline workflows disable --workflow-id <ID> [--org NAME_OR_ID | --org-id ID] [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--org", "Target organization name or exact org id.", takes_value=True, value_name="NAME_OR_ID", key="org"),
        OptionSpec("--org-name", "Target organization name (substring match).", takes_value=True, value_name="NAME", key="org_name"),
        OptionSpec("--org-id", "Target organization id.", takes_value=True, value_name="ID", key="org_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_delete,
)
def handle_disable(base_url: str, env: Dict[str, str], params: WorkflowDeleteParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    api_key = env.get("DEEPLINE_API_KEY", "")
    try:
        api_key, org_name, org_id = _resolve_org_context(
            base_url,
            api_key,
            org=params.org,
            org_name=params.org_name,
            org_id=params.org_id,
        )
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return EXIT_USAGE
    _print_resolved_org(org_name, org_id)
    status, body = http_request(
        "POST",
        f"{base_url}/api/v2/workflows/{params.workflow_id}/disable",
        api_key,
    )
    if status >= 400:
        _format_workflows_error(status, body)
        return _workflow_exit_code(status)
    if params.output_json:
        print(body)
        return EXIT_OK
    payload = _safe_json_object(body)
    workflow = payload.get("workflow")
    previous_status = str(payload.get("previous_status") or "").strip() or "active"
    next_status = str(payload.get("status") or "").strip() or "disabled"
    workflow_id = params.workflow_id
    workflow_name = "(unnamed)"
    if isinstance(workflow, dict):
        workflow_id = str(workflow.get("id") or workflow_id or "").strip() or workflow_id
        workflow_name = str(workflow.get("name") or workflow_name).strip() or workflow_name
    print(f"Disabled workflow {workflow_name} ({workflow_id}).")
    print(f"Status: {previous_status} -> {next_status}")
    return EXIT_OK


@router.route_typed(
    "enable",
    summary="Enable a previously disabled workflow.",
    usage="deepline workflows enable --workflow-id <ID> [--org NAME_OR_ID | --org-id ID] [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--org", "Target organization name or exact org id.", takes_value=True, value_name="NAME_OR_ID", key="org"),
        OptionSpec("--org-name", "Target organization name (substring match).", takes_value=True, value_name="NAME", key="org_name"),
        OptionSpec("--org-id", "Target organization id.", takes_value=True, value_name="ID", key="org_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_delete,
)
def handle_enable(base_url: str, env: Dict[str, str], params: WorkflowDeleteParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    api_key = env.get("DEEPLINE_API_KEY", "")
    try:
        api_key, org_name, org_id = _resolve_org_context(
            base_url,
            api_key,
            org=params.org,
            org_name=params.org_name,
            org_id=params.org_id,
        )
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return EXIT_USAGE
    _print_resolved_org(org_name, org_id)
    status, body = http_request(
        "POST",
        f"{base_url}/api/v2/workflows/{params.workflow_id}/enable",
        api_key,
    )
    if status >= 400:
        _format_workflows_error(status, body)
        return _workflow_exit_code(status)
    if params.output_json:
        print(body)
        return EXIT_OK
    payload = _safe_json_object(body)
    workflow = payload.get("workflow")
    previous_status = str(payload.get("previous_status") or "").strip() or "disabled"
    next_status = str(payload.get("status") or "").strip() or "active"
    workflow_id = params.workflow_id
    workflow_name = "(unnamed)"
    if isinstance(workflow, dict):
        workflow_id = str(workflow.get("id") or workflow_id or "").strip() or workflow_id
        workflow_name = str(workflow.get("name") or workflow_name).strip() or workflow_name
    print(f"Enabled workflow {workflow_name} ({workflow_id}).")
    print(f"Status: {previous_status} -> {next_status}")
    return EXIT_OK


@dataclass(frozen=True)
class WorkflowApplyParams:
    payload: str
    output_json: bool
    org: str | None
    org_name: str | None
    org_id: str | None


@dataclass(frozen=True)
class WorkflowLintParams:
    payload: str
    output_json: bool


@dataclass(frozen=True)
class WorkflowSchemaParams:
    subject: str
    output_json: bool


def parse_schema(parsed: ParsedRouteOptions) -> WorkflowSchemaParams:
    subject = str(parsed.options.get("subject") or "all").strip().lower() or "all"
    return WorkflowSchemaParams(subject=subject, output_json=bool(parsed.options.get("json")))


@router.route_typed(
    "schema",
    summary="Inspect live workflow request schemas.",
    description="Fetches the workflow TypeBox/JSON schemas exposed by the API so CLI help stays aligned with the server.",
    usage="deepline workflows schema [--subject apply|call|call_body|trigger|enrich_config|all] [--json]",
    options=[
        OptionSpec(
            "--subject",
            "Schema to print. One of: apply, call, call_body, trigger, enrich_config, all.",
            takes_value=True,
            value_name="NAME",
            key="subject",
        ),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_schema,
)
def handle_schema(base_url: str, env: Dict[str, str], params: WorkflowSchemaParams) -> int:
    status, raw = http_request(
        "GET",
        f"{base_url}/api/v2/workflows/schema",
        None,
        None,
    )
    if status >= 400:
        _format_workflows_error(status, raw)
        return _workflow_exit_code(status)
    payload = _safe_json_object(raw)
    schemas = payload.get("schemas")
    if not isinstance(schemas, dict):
        print("Workflow schema payload missing `schemas`.", file=sys.stderr)
        return EXIT_SERVER
    subject = params.subject
    if subject != "all":
        selected = schemas.get(subject)
        if selected is None:
            print(
                "Unknown schema subject. Valid subjects: apply, call, call_body, trigger, enrich_config, all.",
                file=sys.stderr,
            )
            return EXIT_USAGE
        payload = {"schema": selected, "subject": subject}
    if params.output_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return EXIT_OK
    if subject == "all":
        print("Workflow schemas:")
        for key in sorted(schemas.keys()):
            print(f"- {key}")
        print("")
        print("Next:")
        print("  deepline workflows schema --subject apply --json")
        print("  deepline workflows schema --subject call --json")
        return EXIT_OK
    print(f"Workflow schema: {subject}")
    print(json.dumps(payload.get("schema"), indent=2, sort_keys=True))
    return EXIT_OK


def parse_apply(parsed: ParsedRouteOptions) -> WorkflowApplyParams:
    payload = str(parsed.options.get("payload") or "").strip()
    file_path = str(parsed.options.get("file") or "").strip()
    if payload and file_path:
        raise ValueError("Use only one of --payload or --file.")
    if not payload and not file_path:
        raise ValueError("Provide --payload JSON or --file <PATH>.")
    if file_path:
        try:
            payload = Path(file_path).read_text(encoding="utf-8")
        except OSError as error:
            raise ValueError(f"Could not read --file {file_path}: {error}") from error
    return WorkflowApplyParams(
        payload=payload,
        output_json=bool(parsed.options.get("json")),
        org=str(parsed.options.get("org") or "").strip() or None,
        org_name=str(parsed.options.get("org_name") or "").strip() or None,
        org_id=str(parsed.options.get("org_id") or "").strip() or None,
    )


def parse_lint(parsed: ParsedRouteOptions) -> WorkflowLintParams:
    payload = str(parsed.options.get("payload") or "").strip()
    file_path = str(parsed.options.get("file") or "").strip()
    if payload and file_path:
        raise ValueError("Use only one of --payload or --file.")
    if not payload and not file_path:
        raise ValueError("Provide --payload JSON or --file <PATH>.")
    if file_path:
        try:
            payload = Path(file_path).read_text(encoding="utf-8")
        except OSError as error:
            raise ValueError(f"Could not read --file {file_path}: {error}") from error
    return WorkflowLintParams(payload=payload, output_json=bool(parsed.options.get("json")))


@router.route_typed(
    "apply",
    summary="Create or update a workflow.",
    usage="deepline workflows apply (--payload JSON | --file PATH) [--org NAME_OR_ID | --org-id ID] [--json]",
    options=[
        OptionSpec("--payload", "Workflow apply payload JSON.", takes_value=True, value_name="JSON", key="payload"),
        OptionSpec("--file", "Path to a workflow apply payload JSON file.", takes_value=True, value_name="PATH", key="file"),
        OptionSpec("--org", "Target organization name or exact org id.", takes_value=True, value_name="NAME_OR_ID", key="org"),
        OptionSpec("--org-name", "Target organization name (substring match).", takes_value=True, value_name="NAME", key="org_name"),
        OptionSpec("--org-id", "Target organization id.", takes_value=True, value_name="ID", key="org_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_apply,
)
def handle_apply(base_url: str, env: Dict[str, str], params: WorkflowApplyParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    try:
        body = json.loads(params.payload)
    except Exception:
        print("Invalid JSON in --payload.", file=sys.stderr)
        return EXIT_USAGE
    api_key = env.get("DEEPLINE_API_KEY", "")
    try:
        api_key, org_name, org_id = _resolve_org_context(
            base_url,
            api_key,
            org=params.org,
            org_name=params.org_name,
            org_id=params.org_id,
        )
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return EXIT_USAGE
    _print_resolved_org(org_name, org_id)
    status, raw = http_request(
        "POST",
        f"{base_url}/api/v2/workflows/apply",
        api_key,
        body,
    )
    if status >= 400:
        _format_workflows_error(status, raw)
        return _workflow_exit_code(status)
    if params.output_json:
        print(raw)
    else:
        print("Applied workflow.")
    payload = _safe_json_object(raw)
    workflow = payload.get("workflow")
    if isinstance(workflow, dict):
        if not params.output_json:
            trigger = workflow.get("trigger")
            if isinstance(trigger, dict):
                webhook_url = str(trigger.get("webhook_url") or "").strip()
                if webhook_url:
                    print(f"Webhook URL: {webhook_url}")
        _open_workflow_dashboard(base_url, workflow.get("id"))
    return EXIT_OK


@router.route_typed(
    "lint",
    summary="Validate a workflow apply payload without saving it.",
    usage="deepline workflows lint (--payload JSON | --file PATH) [--json]",
    options=[
        OptionSpec("--payload", "Workflow apply payload JSON.", takes_value=True, value_name="JSON", key="payload"),
        OptionSpec("--file", "Path to a workflow apply payload JSON file.", takes_value=True, value_name="PATH", key="file"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_lint,
)
def handle_lint(base_url: str, env: Dict[str, str], params: WorkflowLintParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    try:
        body = json.loads(params.payload)
    except Exception:
        print("Invalid JSON in workflow payload.", file=sys.stderr)
        return EXIT_USAGE
    status, raw = http_request(
        "POST",
        f"{base_url}/api/v2/workflows/lint",
        env.get("DEEPLINE_API_KEY"),
        body,
    )
    if status >= 400:
        _format_workflows_error(status, raw)
        return _workflow_exit_code(status)
    if params.output_json:
        print(raw)
        return EXIT_OK
    payload = _safe_json_object(raw)
    print("Workflow apply payload is valid.")
    hints = payload.get("hints")
    if isinstance(hints, list) and hints:
        print("Hints:")
        for hint in hints:
            if not isinstance(hint, dict):
                continue
            path = str(hint.get("path") or "").strip()
            message = str(hint.get("message") or "").strip()
            if not message:
                continue
            print(f"- {path}: {message}" if path else f"- {message}")
    warnings = payload.get("specification_warnings")
    if isinstance(warnings, list) and warnings:
        print("Specification warnings:")
        for warning in warnings:
            if not isinstance(warning, dict):
                continue
            step = str(warning.get("step") or "").strip()
            field = str(warning.get("field") or "").strip()
            message = str(warning.get("message") or "").strip()
            prefix = ".".join(part for part in [step, field] if part)
            if prefix and message:
                print(f"- {prefix}: {message}")
            elif message:
                print(f"- {message}")
    return EXIT_OK


VALID_EXECUTION_MODES = {"live", "dry_run", "smoke_test"}


def _detect_caller() -> str:
    """Detect the calling agent from environment variables."""
    if os.environ.get("CLAUDECODE") == "1":
        return "claude_code"
    if os.environ.get("CODEX_THREAD_ID"):
        return "codex"
    if os.environ.get("CLINE_ACTIVE") == "true":
        return "cline"
    return "cli"


@dataclass(frozen=True)
class WorkflowCallParams:
    workflow_id: str | None
    workflow_name: str | None
    payload: str
    output_json: bool
    execution_mode: str | None
    org: str | None
    org_name: str | None
    org_id: str | None


def parse_call(parsed: ParsedRouteOptions) -> WorkflowCallParams:
    workflow_id = str(parsed.options.get("workflow_id") or "").strip() or None
    workflow_name = str(parsed.options.get("workflow_name") or "").strip() or None
    if not workflow_id and not workflow_name:
        raise ValueError("Provide --workflow-id <ID> or --workflow-name <NAME>.")
    if workflow_id and workflow_name:
        raise ValueError("Use only one of --workflow-id or --workflow-name.")
    payload = str(parsed.options.get("payload") or "").strip()
    if not payload:
        raise ValueError("Missing --payload JSON.")
    mode = str(parsed.options.get("mode") or "").strip() or "live"
    if mode not in VALID_EXECUTION_MODES:
        raise ValueError(f"Invalid --mode: {mode}. Must be one of: {', '.join(sorted(VALID_EXECUTION_MODES))}")
    return WorkflowCallParams(
        workflow_id=workflow_id,
        workflow_name=workflow_name,
        payload=payload,
        output_json=bool(parsed.options.get("json")),
        execution_mode=mode,
        org=str(parsed.options.get("org") or "").strip() or None,
        org_name=str(parsed.options.get("org_name") or "").strip() or None,
        org_id=str(parsed.options.get("org_id") or "").strip() or None,
    )


@router.route_typed(
    "call",
    summary="Queue a workflow run.",
    usage="deepline workflows call (--workflow-id <ID> | --workflow-name <NAME>) --payload JSON [--mode MODE] [--org NAME_OR_ID | --org-id ID] [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--workflow-name", "Workflow name.", takes_value=True, value_name="NAME", key="workflow_name"),
        OptionSpec("--payload", "Workflow call payload JSON.", takes_value=True, value_name="JSON", key="payload"),
        OptionSpec("--mode", "Execution mode: live (default), dry_run (skip side effects), smoke_test (fixture data + skip side effects).", takes_value=True, value_name="MODE", key="mode"),
        OptionSpec("--org", "Target organization name or exact org id.", takes_value=True, value_name="NAME_OR_ID", key="org"),
        OptionSpec("--org-name", "Target organization name (substring match).", takes_value=True, value_name="NAME", key="org_name"),
        OptionSpec("--org-id", "Target organization id.", takes_value=True, value_name="ID", key="org_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_call,
)
def handle_call(base_url: str, env: Dict[str, str], params: WorkflowCallParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    try:
        body = json.loads(params.payload)
    except Exception:
        print("Invalid JSON in --payload.", file=sys.stderr)
        return EXIT_USAGE
    # Inject caller and execution mode metadata into the input payload.
    if isinstance(body, dict):
        caller = _detect_caller()
        if caller != "cli":
            body["__caller"] = caller
        if params.execution_mode:
            body["__execution_mode"] = params.execution_mode
    request_body = {"input": body}
    if params.workflow_id:
        request_body["workflow_id"] = params.workflow_id
    if params.workflow_name:
        request_body["workflow_name"] = params.workflow_name
    api_key = env.get("DEEPLINE_API_KEY", "")
    try:
        api_key, org_name, org_id = _resolve_org_context(
            base_url,
            api_key,
            org=params.org,
            org_name=params.org_name,
            org_id=params.org_id,
        )
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return EXIT_USAGE
    _print_resolved_org(org_name, org_id)
    status, raw = http_request(
        "POST",
        f"{base_url}/api/v2/workflows/call",
        api_key,
        request_body,
    )
    if status >= 400:
        _format_workflows_error(status, raw)
        return _workflow_exit_code(status)
    if params.output_json:
        print(raw)
        return EXIT_OK
    payload = _safe_json_object(raw)
    run = payload.get("run")
    dispatch = payload.get("dispatch")
    metadata = payload.get("metadata")
    if isinstance(run, dict):
        print(f"Queued workflow run: {run.get('id', '(unknown)')}")
        print(f"Workflow ID: {run.get('workflow_id', '(unknown)')}")
        print(f"Status: {run.get('status', '(unknown)')}")
    else:
        print("Queued workflow run.")
    if isinstance(dispatch, dict):
        print(f"Dispatch ID: {dispatch.get('id', '(unknown)')}")
    if isinstance(metadata, dict) and metadata.get("run_url"):
        print(f"Run URL: {metadata.get('run_url')}")
    if isinstance(run, dict) and run.get("id") and run.get("workflow_id"):
        _open_workflow_dashboard(base_url, run.get("workflow_id"))
        print(f"Next: deepline workflows runs --workflow-id {run.get('workflow_id')} --run-id {run.get('id')}")
        print(f"Next: deepline workflows runs --workflow-id {run.get('workflow_id')} --run-id {run.get('id')} --tail")
    return EXIT_OK


@dataclass(frozen=True)
class WorkflowRunsParams:
    workflow_id: str
    run_ids: list[str] | None
    tail: bool
    interval_ms: int
    output_json: bool


def _normalize_run_ids(raw_run_id: object) -> list[str]:
    text = str(raw_run_id or "").strip()
    if not text:
        return []
    normalized = text.replace(",", " ")
    return [token for token in normalized.split() if token]


def parse_runs(parsed: ParsedRouteOptions) -> WorkflowRunsParams:
    workflow_id = str(parsed.options.get("workflow_id") or "").strip()
    if not workflow_id:
        raise ValueError("Missing --workflow-id <ID>.")
    run_ids = _normalize_run_ids(parsed.options.get("run_id"))
    interval_raw = parsed.options.get("interval_ms")
    interval_ms = 1000
    if interval_raw not in (None, False):
        try:
            interval_ms = max(100, int(str(interval_raw)))
        except Exception:
            raise ValueError("Invalid --interval-ms <N>.")
    tail = bool(parsed.options.get("tail"))
    if tail and not run_ids:
        raise ValueError("Use --tail with --run-id <ID>.")
    if tail and len(run_ids) != 1:
        raise ValueError("Use --tail with a single --run-id <ID>.")
    return WorkflowRunsParams(
        workflow_id=workflow_id,
        run_ids=run_ids or None,
        tail=tail,
        interval_ms=interval_ms,
        output_json=bool(parsed.options.get("json")),
    )


@router.route_typed(
    "runs",
    summary="Inspect workflow runs. Use --run-id for one run and --tail to follow it live.",
    usage="deepline workflows runs --workflow-id <ID> [--run-id <RUN_ID>] [--tail] [--interval-ms <N>] [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--run-id", "Run id for detailed inspection.", takes_value=True, value_name="RUN_ID", key="run_id"),
        OptionSpec("--tail", "Poll the selected run until it finishes.", key="tail"),
        OptionSpec("--interval-ms", "Polling interval in milliseconds.", takes_value=True, value_name="N", key="interval_ms"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_runs,
)
def handle_runs(base_url: str, env: Dict[str, str], params: WorkflowRunsParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    if params.run_ids:
        if len(params.run_ids) > 1:
            if params.output_json:
                payloads: list[object] = []
                for run_id in params.run_ids:
                    status, body = _fetch_workflow_run_detail_with_retry(
                        base_url,
                        env,
                        params.workflow_id,
                        run_id,
                        max_retryable_retries=5,
                        interval_ms=250,
                    )
                    if status >= 400:
                        _format_workflows_error(status, body)
                        return _workflow_exit_code(status)
                    try:
                        payloads.append(json.loads(body or "{}"))
                    except Exception:
                        payloads.append({})
                print(json.dumps({"runs": payloads}))
                return EXIT_OK
            exit_code = EXIT_OK
            for index, run_id in enumerate(params.run_ids):
                run_params = WorkflowRunParams(
                    workflow_id=params.workflow_id,
                    run_id=run_id,
                    output_json=False,
                )
                result = handle_run(base_url, env, run_params)
                if result != EXIT_OK:
                    return result
                if index < len(params.run_ids) - 1:
                    print("")
            return exit_code
        run_id = params.run_ids[0]
        if params.tail:
            tail_params = WorkflowTailParams(
                workflow_id=params.workflow_id,
                run_id=run_id,
                output_json=params.output_json,
                interval_ms=params.interval_ms,
            )
            return handle_tail(base_url, env, tail_params)
        run_params = WorkflowRunParams(
            workflow_id=params.workflow_id,
            run_id=run_id,
            output_json=params.output_json,
        )
        return handle_run(base_url, env, run_params)
    status, body = http_request(
        "GET",
        f"{base_url}/api/v2/workflows/{params.workflow_id}/runs",
        env.get("DEEPLINE_API_KEY"),
    )
    if status >= 400:
        _format_workflows_error(status, body)
        return _workflow_exit_code(status)
    if params.output_json:
        print(body)
        return EXIT_OK
    try:
        payload = json.loads(body or "{}")
    except Exception:
        payload = {}
    runs = payload.get("runs") if isinstance(payload, dict) else None
    if not isinstance(runs, list) or not runs:
        print("No runs found.")
        return EXIT_OK
    _print_runs_table(runs)
    return EXIT_OK


@dataclass(frozen=True)
class WorkflowRunParams:
    workflow_id: str
    run_id: str
    output_json: bool


def parse_run(parsed: ParsedRouteOptions) -> WorkflowRunParams:
    workflow_id = str(parsed.options.get("workflow_id") or "").strip()
    run_id = str(parsed.options.get("run_id") or "").strip()
    if not workflow_id:
        raise ValueError("Missing --workflow-id <ID>.")
    if not run_id:
        raise ValueError("Missing --run-id <ID>.")
    return WorkflowRunParams(
        workflow_id=workflow_id,
        run_id=run_id,
        output_json=bool(parsed.options.get("json")),
    )


@router.route_typed(
    "run",
    summary="Fetch full execution detail for a workflow run.",
    usage="deepline workflows run --workflow-id <ID> --run-id <ID> [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--run-id", "Run id.", takes_value=True, value_name="ID", key="run_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_run,
)
def handle_run(base_url: str, env: Dict[str, str], params: WorkflowRunParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    status, body = _fetch_workflow_run_detail_with_retry(
        base_url,
        env,
        params.workflow_id,
        params.run_id,
        max_retryable_retries=5,
        interval_ms=250,
    )
    if status >= 400:
        _format_workflows_error(status, body)
        return _workflow_exit_code(status)
    if params.output_json:
        print(body)
        return EXIT_OK
    _print_run_detail_summary(_safe_json_object(body))
    return EXIT_OK


@dataclass(frozen=True)
class WorkflowTailParams:
    workflow_id: str
    run_id: str
    output_json: bool
    interval_ms: int


def parse_tail(parsed: ParsedRouteOptions) -> WorkflowTailParams:
    workflow_id = str(parsed.options.get("workflow_id") or "").strip()
    run_id = str(parsed.options.get("run_id") or "").strip()
    interval_raw = parsed.options.get("interval_ms")
    interval_ms = 1000
    if interval_raw not in (None, False):
      try:
        interval_ms = max(100, int(str(interval_raw)))
      except Exception:
        raise ValueError("Invalid --interval-ms <N>.")
    if not workflow_id:
        raise ValueError("Missing --workflow-id <ID>.")
    if not run_id:
        raise ValueError("Missing --run-id <ID>.")
    return WorkflowTailParams(
        workflow_id=workflow_id,
        run_id=run_id,
        output_json=bool(parsed.options.get("json")),
        interval_ms=interval_ms,
    )


@dataclass(frozen=True)
class WorkflowCancelParams:
    workflow_id: str
    run_id: str
    output_json: bool


def parse_cancel(parsed: ParsedRouteOptions) -> WorkflowCancelParams:
    workflow_id = str(parsed.options.get("workflow_id") or "").strip()
    run_id = str(parsed.options.get("run_id") or "").strip()
    if not workflow_id:
        raise ValueError("Missing --workflow-id <ID>.")
    if not run_id:
        raise ValueError("Missing --run-id <ID>.")
    return WorkflowCancelParams(
        workflow_id=workflow_id,
        run_id=run_id,
        output_json=bool(parsed.options.get("json")),
    )


@router.route_typed(
    "cancel",
    summary="Cancel a running or pending workflow run.",
    usage="deepline workflows cancel --workflow-id <ID> --run-id <ID> [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--run-id", "Run id to cancel.", takes_value=True, value_name="ID", key="run_id"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_cancel,
)
def handle_cancel(base_url: str, env: Dict[str, str], params: WorkflowCancelParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    status, body = http_request(
        "POST",
        f"{base_url}/api/v2/workflows/{params.workflow_id}/runs/{params.run_id}/cancel",
        env.get("DEEPLINE_API_KEY"),
    )
    if status >= 400:
        _format_workflows_error(status, body)
        return _workflow_exit_code(status)
    if params.output_json:
        print(body)
        return EXIT_OK
    payload = _safe_json_object(body)
    run = payload.get("run")
    run_id = params.run_id
    if isinstance(run, dict):
        run_id = str(run.get("id") or params.run_id)
    child_count = int(payload.get("cancelled_child_run_count") or 0)
    print(f"Cancelled run {run_id}.")
    if child_count > 0:
        print(f"  {child_count} child run(s) also cancelled.")
    return EXIT_OK


@router.route_typed(
    "tail",
    summary="Poll a workflow run until it finishes, printing step transitions.",
    usage="deepline workflows tail --workflow-id <ID> --run-id <ID> [--interval-ms <N>] [--json]",
    options=[
        OptionSpec("--workflow-id", "Workflow id.", takes_value=True, value_name="ID", key="workflow_id"),
        OptionSpec("--run-id", "Run id.", takes_value=True, value_name="ID", key="run_id"),
        OptionSpec("--interval-ms", "Polling interval in milliseconds.", takes_value=True, value_name="N", key="interval_ms"),
        OptionSpec("--json", "Emit final raw JSON response.", key="json"),
    ],
    params_parser=parse_tail,
)
def handle_tail(base_url: str, env: Dict[str, str], params: WorkflowTailParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing

    seen_run_status = ""
    seen_step_states: dict[str, tuple[object, object]] = {}
    last_body = "{}"

    while True:
        status, body = _fetch_workflow_run_detail_with_retry(
            base_url,
            env,
            params.workflow_id,
            params.run_id,
            max_retryable_retries=10 if not seen_run_status else 3,
            interval_ms=params.interval_ms,
        )
        if status >= 400:
            _format_workflows_error(status, body)
            return _workflow_exit_code(status)

        last_body = body
        payload = _safe_json_object(body)
        run = payload.get("run")
        run_status = ""
        if isinstance(run, dict):
            run_status = str(run.get("status") or "").strip().lower()
            if run_status != seen_run_status:
                seen_run_status = run_status
                print(f"Run status: {run_status or '(unknown)'}")
            run_error = _extract_run_error(run)
            if run_error:
                print(f"Run error: {run_error}")

        steps = payload.get("steps")
        if isinstance(steps, list):
            for step in steps:
                if not isinstance(step, dict):
                    continue
                block_id = str(step.get("block_id") or "").strip() or "(unknown)"
                state = (step.get("status"), step.get("attempt_number"))
                if seen_step_states.get(block_id) == state:
                    continue
                seen_step_states[block_id] = state
                print(
                    f"Step {block_id}: {step.get('status', '(unknown)')} "
                    f"attempt={step.get('attempt_number', '(unknown)')} "
                    f"duration={_format_duration_ms(step.get('duration_ms'))}"
                )
                if step.get("error_summary"):
                    print(f"  error: {step.get('error_summary')}")

        if _terminal_run_status(run_status):
            if params.output_json:
                print(last_body)
            else:
                print("")
                _print_run_detail_summary(payload)
            # `stopped` is a successful terminal state — a step intentionally
            # halted the run (e.g. an ICP gate rejected the input). Exit 0,
            # same as `completed`. `failed` and `cancelled` keep exit-1.
            normalized_status = str(run_status or "").strip().lower()
            if normalized_status in ("completed", "stopped"):
                return EXIT_OK
            return EXIT_SERVER

        time.sleep(params.interval_ms / 1000.0)


handle = build_command_handler(
    command_name="workflows",
    router=router,
    usage_factory=usage_workflows_computed,
)
