#!/usr/bin/env python3
"""
Processor contract regression tests.

These tests focus on stricter runtime validation introduced in BatchProcessor:
typed output enforcement, duplicate/unknown task ids, and richer input conversion
errors.
"""

from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from typing import Any, Generator, List

from test_support import install_sdk_dependency_stubs

install_sdk_dependency_stubs()

from pydantic import BaseModel

sys.path.insert(0, str(Path(__file__).parent.parent))

from sandai.operator.processor import (
    BatchProcessor,
    OperatorConfigurationError,
    OutputEnvelope,
    PreparedTask,
)
from sandai.operator.types import TaskInput, TaskOutput


class ContractOptions(BaseModel):
    value: int = 1


class ContractResults(BaseModel):
    echoed: int


def _base_processor() -> BatchProcessor:
    processor = BatchProcessor("contract-processor", "v1", ignore_nongil_check=True)
    processor._setup_temp_directory()
    return processor


def test_convert_input_to_taskinput_rejects_missing_task_id() -> None:
    processor = _base_processor()

    async def run_case() -> None:
        try:
            await processor.convert_input_to_taskinput({"options": {}, "artifacts": []})
            raise AssertionError("expected missing task_id failure")
        except Exception as exc:
            assert "task_id" in str(exc)

    asyncio.run(run_case())


def test_convert_input_to_taskinput_rejects_invalid_artifact_shape() -> None:
    processor = _base_processor()

    async def run_case() -> None:
        try:
            await processor.convert_input_to_taskinput(
                {"task_id": "bad-artifact", "options": {}, "artifacts": ["oops"]}
            )
            raise AssertionError("expected invalid artifact failure")
        except Exception as exc:
            assert "artifact" in str(exc).lower()

    asyncio.run(run_case())


def test_safe_process_func_rejects_non_taskoutput_values() -> None:
    processor = _base_processor()

    @processor.on_batch(max_batch_size=1)
    def process_batch(
        batch_inputs: List[TaskInput[ContractOptions]],
        operator_config: dict,
        context,
    ) -> Generator[TaskOutput[ContractResults], None, None]:
        yield {"task_id": batch_inputs[0].task_id, "status": "success"}  # type: ignore[misc]

    task_input = TaskInput[ContractOptions](
        task_id="task-1",
        options=ContractOptions(value=3),
        artifacts=[],
    )
    outputs = processor._safe_process_func([task_input], {})

    assert len(outputs) == 1
    assert outputs[0].status == "error"
    assert outputs[0].error is not None
    assert outputs[0].error.error_type == "OutputValidationError"


def test_safe_process_func_rejects_duplicate_task_ids() -> None:
    processor = _base_processor()

    @processor.on_batch(max_batch_size=2)
    def process_batch(
        batch_inputs: List[TaskInput[ContractOptions]],
        operator_config: dict,
        context,
    ) -> Generator[TaskOutput[ContractResults], None, None]:
        first_task_id = batch_inputs[0].task_id
        yield TaskOutput(task_id=first_task_id, results=ContractResults(echoed=1))
        yield TaskOutput(task_id=first_task_id, results=ContractResults(echoed=2))

    task_inputs = [
        TaskInput[ContractOptions](task_id="task-a", options=ContractOptions(value=1), artifacts=[]),
        TaskInput[ContractOptions](task_id="task-b", options=ContractOptions(value=2), artifacts=[]),
    ]
    outputs = processor._safe_process_func(task_inputs, {})

    assert len(outputs) == 2
    assert outputs[0].status == "success"
    assert outputs[1].status == "error"
    assert outputs[1].error is not None
    assert outputs[1].error.error_type == "OutputValidationError"


def test_safe_process_func_rejects_unknown_task_ids() -> None:
    processor = _base_processor()

    @processor.on_batch(max_batch_size=1)
    def process_batch(
        batch_inputs: List[TaskInput[ContractOptions]],
        operator_config: dict,
        context,
    ) -> Generator[TaskOutput[ContractResults], None, None]:
        yield TaskOutput(task_id="foreign-task", results=ContractResults(echoed=99))

    task_input = TaskInput[ContractOptions](
        task_id="known-task",
        options=ContractOptions(value=4),
        artifacts=[],
    )
    outputs = processor._safe_process_func([task_input], {})

    assert len(outputs) == 1
    assert outputs[0].status == "error"
    assert outputs[0].error is not None
    assert outputs[0].error.error_type == "OutputValidationError"


def test_execute_batch_rejects_output_count_mismatch() -> None:
    processor = _base_processor()

    async def broken_process_batch(task_inputs):
        return [
            TaskOutput(
                task_id=task_inputs[0].task_id,
                results=ContractResults(echoed=task_inputs[0].options.value),
            )
        ]

    processor.process_batch = broken_process_batch  # type: ignore[method-assign]

    prepared_tasks = [
        PreparedTask(
            task_input=TaskInput[ContractOptions](
                task_id="task-a", options=ContractOptions(value=1), artifacts=[]
            )
        ),
        PreparedTask(
            task_input=TaskInput[ContractOptions](
                task_id="task-b", options=ContractOptions(value=2), artifacts=[]
            )
        ),
    ]

    output_batch = asyncio.run(processor._execute_batch(prepared_tasks))

    assert len(output_batch) == 2
    assert all(isinstance(envelope, OutputEnvelope) for envelope in output_batch)
    assert all(envelope.output.status == "error" for envelope in output_batch)
    assert output_batch[0].output.error is not None
    assert output_batch[0].output.error.error_type == "ProcessingError"
    assert "different number of outputs" in output_batch[0].output.error.error_message


def test_convert_taskoutput_to_output_serializes_nested_results_model() -> None:
    processor = _base_processor()
    processor._output_executor = None

    async def run_case() -> None:
        output = TaskOutput(
            task_id="task-nested",
            results=ContractResults(echoed=7),
            artifacts=[],
        )
        converted = await processor.convert_taskoutput_to_output(output)
        assert converted["task_id"] == "task-nested"
        assert converted["results"] == {"echoed": 7}

    asyncio.run(run_case())


def test_convert_input_to_taskinput_downloads_artifacts_in_parallel() -> None:
    """All artifacts must be downloaded concurrently, not one-by-one."""
    processor = _base_processor()
    DELAY = 0.3
    NUM_ARTIFACTS = 4

    original_uri_to_path = processor._uri_to_path

    def slow_uri_to_path(uri: str, task_id: str, file_type: str = "inputs") -> str:
        time.sleep(DELAY)
        return original_uri_to_path(uri, task_id, file_type)

    processor._uri_to_path = slow_uri_to_path  # type: ignore[method-assign]

    import tempfile, os

    tmp_files = []
    artifacts = []
    for i in range(NUM_ARTIFACTS):
        f = tempfile.NamedTemporaryFile(delete=False, suffix=f"_artifact_{i}.txt")
        f.write(b"data")
        f.close()
        tmp_files.append(f.name)
        artifacts.append({"uri": f.name})

    async def run_case() -> None:
        start = time.monotonic()
        result = await processor.convert_input_to_taskinput(
            {"task_id": "parallel-dl-task", "options": {}, "artifacts": artifacts}
        )
        elapsed = time.monotonic() - start

        assert len(result.artifacts) == NUM_ARTIFACTS
        # Sequential would take >= NUM_ARTIFACTS * DELAY; parallel should finish well under that
        assert elapsed < NUM_ARTIFACTS * DELAY * 0.8, (
            f"Downloads appear sequential: took {elapsed:.2f}s, "
            f"expected < {NUM_ARTIFACTS * DELAY * 0.8:.2f}s for parallel execution"
        )

    try:
        asyncio.run(run_case())
    finally:
        for f in tmp_files:
            try:
                os.unlink(f)
            except Exception:
                pass


def test_convert_taskoutput_uploads_artifacts_in_parallel() -> None:
    """Artifacts within a single task must be uploaded concurrently."""
    import os
    import tempfile

    processor = _base_processor()
    DELAY = 0.3
    NUM_ARTIFACTS = 4

    async def slow_upload(local_file_path, ephemeral=True):
        await asyncio.sleep(DELAY)
        return f"fake://bucket/{Path(local_file_path).name}", {}

    processor._upload_to_storage = slow_upload  # type: ignore[method-assign]

    tmp_files = []
    artifact_dicts = []
    for i in range(NUM_ARTIFACTS):
        f = tempfile.NamedTemporaryFile(delete=False, suffix=f"_out_{i}.txt")
        f.write(b"result")
        f.close()
        tmp_files.append(f.name)
        artifact_dicts.append({"uri": f.name})

    from sandai.operator.types import OutputArtifact, TaskOutput

    task_output = TaskOutput[Any](
        task_id="parallel-upload-task",
        status="success",
        artifacts=[OutputArtifact(**a) for a in artifact_dicts],
    )

    async def run_case() -> None:
        start = time.monotonic()
        await processor.convert_taskoutput_to_output(task_output, ephemeral=True)
        elapsed = time.monotonic() - start
        assert elapsed < NUM_ARTIFACTS * DELAY * 0.8, (
            f"Uploads appear sequential: took {elapsed:.2f}s, "
            f"expected < {NUM_ARTIFACTS * DELAY * 0.8:.2f}s for parallel execution"
        )

    try:
        asyncio.run(run_case())
    finally:
        for f in tmp_files:
            try:
                os.unlink(f)
            except Exception:
                pass


def test_prepare_concurrency_from_env() -> None:
    """SANDAI_OPERATOR_PREPARE_CONCURRENCY env var sets prepare_concurrency on BatchProcessor."""
    import os

    os.environ["SANDAI_OPERATOR_PREPARE_CONCURRENCY"] = "7"
    try:
        processor = BatchProcessor("env-prep-test", "v1", ignore_nongil_check=True)
        assert processor.prepare_concurrency == 7, (
            f"Expected prepare_concurrency=7, got {processor.prepare_concurrency}"
        )
        assert processor._prepare_worker_count() == 7, (
            f"Expected _prepare_worker_count()=7, got {processor._prepare_worker_count()}"
        )
    finally:
        del os.environ["SANDAI_OPERATOR_PREPARE_CONCURRENCY"]


def test_output_concurrency_from_env() -> None:
    """SANDAI_OPERATOR_OUTPUT_CONCURRENCY env var sets output_concurrency on BatchProcessor."""
    import os

    os.environ["SANDAI_OPERATOR_OUTPUT_CONCURRENCY"] = "5"
    try:
        processor = BatchProcessor("env-out-test", "v1", ignore_nongil_check=True)
        assert processor.output_concurrency == 5, (
            f"Expected output_concurrency=5, got {processor.output_concurrency}"
        )
        assert processor._output_worker_count() == 5, (
            f"Expected _output_worker_count()=5, got {processor._output_worker_count()}"
        )
    finally:
        del os.environ["SANDAI_OPERATOR_OUTPUT_CONCURRENCY"]


def test_async_run_requires_registered_process_function() -> None:
    processor = BatchProcessor("missing-handler", "v1", ignore_nongil_check=True)

    async def run_case() -> None:
        try:
            await processor._async_run(job_mode=True)
            raise AssertionError("expected missing process function failure")
        except OperatorConfigurationError as exc:
            assert "No process function defined" in str(exc)

    asyncio.run(run_case())


def main() -> int:
    tests = [
        ("missing_task_id", test_convert_input_to_taskinput_rejects_missing_task_id),
        ("invalid_artifact", test_convert_input_to_taskinput_rejects_invalid_artifact_shape),
        ("non_taskoutput", test_safe_process_func_rejects_non_taskoutput_values),
        ("duplicate_task_id", test_safe_process_func_rejects_duplicate_task_ids),
        ("unknown_task_id", test_safe_process_func_rejects_unknown_task_ids),
        ("output_count_mismatch", test_execute_batch_rejects_output_count_mismatch),
        ("serialize_nested_results", test_convert_taskoutput_to_output_serializes_nested_results_model),
        ("missing_process_func", test_async_run_requires_registered_process_function),
        ("parallel_artifact_downloads", test_convert_input_to_taskinput_downloads_artifacts_in_parallel),
        ("parallel_artifact_uploads", test_convert_taskoutput_uploads_artifacts_in_parallel),
        ("prepare_concurrency_from_env", test_prepare_concurrency_from_env),
        ("output_concurrency_from_env", test_output_concurrency_from_env),
    ]

    passed = 0
    failed = 0

    print("Processor contract regression tests")
    print("=" * 60)
    for name, test_func in tests:
        try:
            test_func()
            print(f"PASS {name}")
            passed += 1
        except Exception as exc:
            print(f"FAIL {name}: {exc}")
            import traceback

            traceback.print_exc()
            failed += 1
    print("=" * 60)
    print(f"passed={passed} failed={failed}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
