#!/usr/bin/env python3
"""
Regression tests for the GPU utilization monitor feature.

Tests cover:
- env var defaults and overrides (get_gpu_monitor_interval, get_gpu_monitor_min_power)
- gpu_monitor module: try_init when pynvml missing, get_metrics when not inited
- gpu_monitor module: get_metrics with mocked pynvml
- BatchProcessor: gpu_monitor_interval ctor param and env fallback
- _gpu_monitor_loop: logs when power < threshold
- _gpu_monitor_loop: silent when power >= threshold

All tests use mocks — no real CUDA or pynvml required.
"""
from __future__ import annotations

import asyncio
import os
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

from test_support import install_sdk_dependency_stubs

install_sdk_dependency_stubs()

TESTS_DIR = Path(__file__).parent
REPO_ROOT = TESTS_DIR.parent.parent
sys.path.insert(0, str(REPO_ROOT / "operator-sdk"))

from sandai.operator.env import get_gpu_monitor_interval, get_gpu_monitor_min_power
import sandai.operator.gpu_monitor as gpu_monitor


# ---------------------------------------------------------------------------
# 1. env defaults and overrides
# ---------------------------------------------------------------------------

def test_gpu_monitor_interval_default() -> None:
    os.environ.pop("SANDAI_OPERATOR_GPU_MONITOR_INTERVAL", None)
    assert get_gpu_monitor_interval() == 0


def test_gpu_monitor_interval_env_override() -> None:
    with patch.dict(os.environ, {"SANDAI_OPERATOR_GPU_MONITOR_INTERVAL": "30"}):
        assert get_gpu_monitor_interval() == 30


def test_gpu_min_power_default() -> None:
    os.environ.pop("SANDAI_OPERATOR_GPU_MIN_POWER_WATTS", None)
    assert get_gpu_monitor_min_power() == 50.0


def test_gpu_min_power_env_override() -> None:
    with patch.dict(os.environ, {"SANDAI_OPERATOR_GPU_MIN_POWER_WATTS": "100.5"}):
        assert get_gpu_monitor_min_power() == 100.5


# ---------------------------------------------------------------------------
# 2. gpu_monitor.try_init — pynvml missing → returns False
# ---------------------------------------------------------------------------

def test_try_init_returns_false_when_pynvml_missing() -> None:
    gpu_monitor._reset_for_testing()

    real_import = __builtins__.__import__ if hasattr(__builtins__, "__import__") else __import__

    def import_raiser(name, *args, **kwargs):
        if name == "pynvml":
            raise ImportError("no module named pynvml")
        return real_import(name, *args, **kwargs)

    with patch("builtins.__import__", side_effect=import_raiser):
        result = gpu_monitor.try_init()

    assert result is False
    gpu_monitor._reset_for_testing()


# ---------------------------------------------------------------------------
# 3. gpu_monitor.get_metrics — not inited → empty list
# ---------------------------------------------------------------------------

def test_get_metrics_returns_empty_when_not_inited() -> None:
    gpu_monitor._reset_for_testing()
    assert gpu_monitor.get_metrics() == []


# ---------------------------------------------------------------------------
# 4. gpu_monitor.get_metrics — with mocked pynvml → per-device GpuMetrics
# ---------------------------------------------------------------------------

def _make_pynvml_mock(
    device_count: int = 1,
    power_mw: int = 150_000,    # 150 W
    util_pct: int = 85,
    mem_used: int = 8 * 1024 * 1024 * 1024,   # 8 GB
    mem_total: int = 24 * 1024 * 1024 * 1024,  # 24 GB
) -> MagicMock:
    mock_pynvml = MagicMock()
    mock_pynvml.nvmlDeviceGetCount.return_value = device_count
    handle = MagicMock()
    mock_pynvml.nvmlDeviceGetHandleByIndex.return_value = handle
    mock_pynvml.nvmlDeviceGetPowerUsage.return_value = power_mw
    util = MagicMock()
    util.gpu = util_pct
    mock_pynvml.nvmlDeviceGetUtilizationRates.return_value = util
    mem = MagicMock()
    mem.used = mem_used
    mem.total = mem_total
    mock_pynvml.nvmlDeviceGetMemoryInfo.return_value = mem
    return mock_pynvml


def test_get_metrics_returns_per_device_data() -> None:
    mock_pynvml = _make_pynvml_mock(
        device_count=1,
        power_mw=200_000,   # 200 W
        util_pct=90,
        mem_used=4 * 1024 * 1024 * 1024,
        mem_total=24 * 1024 * 1024 * 1024,
    )
    gpu_monitor._reset_for_testing(pynvml_mod=mock_pynvml)

    metrics = gpu_monitor.get_metrics()

    assert len(metrics) == 1
    m = metrics[0]
    assert m.device_index == 0
    assert abs(m.power_watts - 200.0) < 0.01
    assert m.utilization_pct == 90
    assert m.memory_used_mb == 4 * 1024
    assert m.memory_total_mb == 24 * 1024

    gpu_monitor._reset_for_testing()


def test_get_metrics_multi_device() -> None:
    mock_pynvml = _make_pynvml_mock(device_count=2)
    gpu_monitor._reset_for_testing(pynvml_mod=mock_pynvml)

    metrics = gpu_monitor.get_metrics()

    assert len(metrics) == 2
    assert metrics[0].device_index == 0
    assert metrics[1].device_index == 1

    gpu_monitor._reset_for_testing()


# ---------------------------------------------------------------------------
# 5. BatchProcessor — ctor param and env fallback
# ---------------------------------------------------------------------------

def test_processor_gpu_monitor_interval_ctor_param() -> None:
    from sandai.operator import BatchProcessor
    p = BatchProcessor("test", "v1", gpu_monitor_interval=45, ignore_nongil_check=True)
    assert p.gpu_monitor_interval == 45


def test_processor_gpu_monitor_interval_from_env() -> None:
    from sandai.operator import BatchProcessor
    with patch.dict(os.environ, {"SANDAI_OPERATOR_GPU_MONITOR_INTERVAL": "20"}):
        p = BatchProcessor("test", "v1", ignore_nongil_check=True)
    assert p.gpu_monitor_interval == 20


def test_processor_gpu_min_power_ctor_param() -> None:
    from sandai.operator import BatchProcessor
    p = BatchProcessor("test", "v1", gpu_monitor_min_power=75.0, ignore_nongil_check=True)
    assert p.gpu_monitor_min_power == 75.0


def test_processor_gpu_min_power_from_env() -> None:
    from sandai.operator import BatchProcessor
    with patch.dict(os.environ, {"SANDAI_OPERATOR_GPU_MIN_POWER_WATTS": "80.0"}):
        p = BatchProcessor("test", "v1", ignore_nongil_check=True)
    assert p.gpu_monitor_min_power == 80.0


# ---------------------------------------------------------------------------
# 6. _gpu_monitor_loop — logs when power < threshold
# ---------------------------------------------------------------------------

def test_gpu_monitor_loop_logs_when_power_below_threshold() -> None:
    from sandai.operator import BatchProcessor
    from unittest.mock import AsyncMock

    processor = BatchProcessor("test", "v1", ignore_nongil_check=True)

    # Set up fake queues
    processor._input_queue = asyncio.Queue()
    processor._prepared_queue = asyncio.Queue()
    processor._output_queue = asyncio.Queue()
    processor._compute_active_count = 2

    # Fake channel with pending tasks
    channel = MagicMock()
    channel.get_pending_task_count.return_value = 5

    # GPU returning low power (10 W, below threshold of 50 W)
    low_power_metrics = [gpu_monitor.GpuMetrics(0, 10.0, 5, 2048, 24576)]

    log_calls = []

    async def _run():
        processor._stop_event.clear()

        with patch.object(gpu_monitor, "get_metrics", return_value=low_power_metrics), \
             patch.object(processor.logger, "info", side_effect=lambda *a, **kw: log_calls.append(a)):
            task = asyncio.create_task(
                processor._gpu_monitor_loop(channel, interval=0, min_power=50.0)
            )
            await asyncio.sleep(0.05)
            processor._stop_event.set()
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    asyncio.run(_run())

    assert any("LOW POWER" in str(c) for c in log_calls), \
        f"Expected low-power log, got: {log_calls}"
    assert any("celery_pending" in str(c) or "5" in str(c) for c in log_calls), \
        f"Expected queue stats in log, got: {log_calls}"


# ---------------------------------------------------------------------------
# 7. _gpu_monitor_loop — silent when power >= threshold
# ---------------------------------------------------------------------------

def test_gpu_monitor_loop_silent_when_power_above_threshold() -> None:
    from sandai.operator import BatchProcessor

    processor = BatchProcessor("test", "v1", ignore_nongil_check=True)
    processor._input_queue = asyncio.Queue()
    processor._prepared_queue = asyncio.Queue()
    processor._output_queue = asyncio.Queue()
    processor._compute_active_count = 0

    channel = MagicMock()
    channel.get_pending_task_count.return_value = 10

    # GPU at 200 W — well above threshold
    high_power_metrics = [gpu_monitor.GpuMetrics(0, 200.0, 90, 8192, 24576)]

    log_calls = []

    async def _run():
        processor._stop_event.clear()

        with patch.object(gpu_monitor, "get_metrics", return_value=high_power_metrics), \
             patch.object(processor.logger, "info", side_effect=lambda *a, **kw: log_calls.append(a)):
            task = asyncio.create_task(
                processor._gpu_monitor_loop(channel, interval=0, min_power=50.0)
            )
            await asyncio.sleep(0.05)
            processor._stop_event.set()
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    asyncio.run(_run())

    assert not any("LOW POWER" in str(c) for c in log_calls), \
        f"Should NOT log LOW POWER when power is high, got: {log_calls}"


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

def main() -> int:
    tests = [
        ("interval_default", test_gpu_monitor_interval_default),
        ("interval_env_override", test_gpu_monitor_interval_env_override),
        ("min_power_default", test_gpu_min_power_default),
        ("min_power_env_override", test_gpu_min_power_env_override),
        ("try_init_false_when_missing", test_try_init_returns_false_when_pynvml_missing),
        ("get_metrics_empty_when_not_inited", test_get_metrics_returns_empty_when_not_inited),
        ("get_metrics_per_device", test_get_metrics_returns_per_device_data),
        ("get_metrics_multi_device", test_get_metrics_multi_device),
        ("processor_interval_ctor", test_processor_gpu_monitor_interval_ctor_param),
        ("processor_interval_env", test_processor_gpu_monitor_interval_from_env),
        ("processor_min_power_ctor", test_processor_gpu_min_power_ctor_param),
        ("processor_min_power_env", test_processor_gpu_min_power_from_env),
        ("loop_logs_low_power", test_gpu_monitor_loop_logs_when_power_below_threshold),
        ("loop_silent_high_power", test_gpu_monitor_loop_silent_when_power_above_threshold),
    ]

    passed = failed = 0
    print("GPU Monitor regression tests")
    print("=" * 60)
    for name, fn in tests:
        try:
            fn()
            print(f"PASS {name}")
            passed += 1
        except Exception as exc:
            print(f"FAIL {name}: {exc}")
            import traceback
            traceback.print_exc()
            failed += 1
    print("=" * 60)
    print(f"passed={passed} failed={failed}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
