#!/usr/bin/env python3
"""
Regression tests for per-job OpenTelemetry tracing support.

Tests cover:
- No-op behavior when tracing is disabled (default)
- Span lifecycle (start → stage events → finish) when OTel is available
- Error status propagation
- Context extraction from payload
- Client-side inject_trace_context
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest import mock

from test_support import install_sdk_dependency_stubs

install_sdk_dependency_stubs()

sys.path.insert(0, str(Path(__file__).parent.parent))

import sandai.operator.tracing as sdk_tracing


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_ot():
    """Return (mock_ot_trace, mock_StatusCode, mock_span, mock_tracer)."""
    mock_span = mock.MagicMock(name="span")
    mock_tracer = mock.MagicMock(name="tracer")
    mock_tracer.start_span.return_value = mock_span
    mock_ot_trace = mock.MagicMock(name="ot_trace")
    mock_ot_trace.get_tracer.return_value = mock_tracer
    mock_sc = mock.MagicMock(name="StatusCode")
    mock_sc.OK = "OK"
    mock_sc.ERROR = "ERROR"
    return mock_ot_trace, mock_sc, mock_span, mock_tracer


def _patch_sdk_tracing(ot_trace, status_code):
    sdk_tracing._ot_trace = ot_trace
    sdk_tracing._StatusCode = status_code
    sdk_tracing._active_spans.clear()


def _restore_sdk_tracing():
    sdk_tracing._reset_for_testing(enabled=False)


# ---------------------------------------------------------------------------
# SDK tracing tests
# ---------------------------------------------------------------------------

def test_sdk_tracing_all_noop_when_disabled() -> None:
    """When disabled (default), task_started / task_stage_event / task_finished are no-ops."""
    sdk_tracing._reset_for_testing(enabled=False)

    sdk_tracing.task_started("t1", "my-op")
    sdk_tracing.task_stage_event("t1", "prepare.complete")
    sdk_tracing.task_finished("t1", "success")

    assert "t1" not in sdk_tracing._active_spans, "No span should be stored when disabled"


def test_sdk_tracing_task_started_creates_span() -> None:
    """task_started stores a span keyed by task_id."""
    ot, sc, span, tracer = _make_mock_ot()
    _patch_sdk_tracing(ot, sc)
    try:
        sdk_tracing.task_started("t2", "op-name")

        tracer.start_span.assert_called_once()
        call_kwargs = tracer.start_span.call_args
        assert call_kwargs[0][0] == "operator.task"
        attrs = call_kwargs[1].get("attributes", {})
        assert attrs.get("task.id") == "t2"
        assert attrs.get("operator.name") == "op-name"
        assert "t2" in sdk_tracing._active_spans
    finally:
        _restore_sdk_tracing()


def test_sdk_tracing_task_stage_event_added_to_span() -> None:
    """task_stage_event calls add_event on the active span."""
    ot, sc, span, tracer = _make_mock_ot()
    _patch_sdk_tracing(ot, sc)
    try:
        sdk_tracing.task_started("t3", "op")
        sdk_tracing.task_stage_event("t3", "prepare.complete", batch_size=4)

        span.add_event.assert_called_once_with(
            "prepare.complete", attributes={"batch_size": 4}
        )
    finally:
        _restore_sdk_tracing()


def test_sdk_tracing_task_finished_ends_span_success() -> None:
    """task_finished ends the span and sets OK status on success."""
    ot, sc, span, tracer = _make_mock_ot()
    _patch_sdk_tracing(ot, sc)
    try:
        sdk_tracing.task_started("t4", "op")
        sdk_tracing.task_finished("t4", "success")

        span.set_attribute.assert_any_call("task.status", "success")
        span.set_status.assert_called_once_with("OK")
        span.end.assert_called_once()
        assert "t4" not in sdk_tracing._active_spans
    finally:
        _restore_sdk_tracing()


def test_sdk_tracing_task_finished_sets_error_status() -> None:
    """task_finished sets ERROR status and records error attributes on failure."""
    ot, sc, span, tracer = _make_mock_ot()
    _patch_sdk_tracing(ot, sc)
    try:
        sdk_tracing.task_started("t5", "op")
        sdk_tracing.task_finished("t5", "error", "ProcessingError", "boom")

        set_attr_calls = {c[0][0]: c[0][1] for c in span.set_attribute.call_args_list}
        assert set_attr_calls.get("task.status") == "error"
        assert set_attr_calls.get("error.type") == "ProcessingError"
        assert "boom" in set_attr_calls.get("error.message", "")
        span.set_status.assert_called_once_with("ERROR", "boom")
        span.end.assert_called_once()
    finally:
        _restore_sdk_tracing()


def test_sdk_tracing_task_finished_unknown_task_is_noop() -> None:
    """task_finished for an unknown task_id is a safe no-op."""
    ot, sc, span, tracer = _make_mock_ot()
    _patch_sdk_tracing(ot, sc)
    try:
        sdk_tracing.task_finished("nonexistent", "success")
        span.end.assert_not_called()
    finally:
        _restore_sdk_tracing()


def test_sdk_extract_parent_context_returns_none_when_disabled() -> None:
    """extract_parent_context returns None when OTel is not available."""
    sdk_tracing._reset_for_testing(enabled=False)
    result = sdk_tracing.extract_parent_context({"_tracing": {"traceparent": "x"}})
    assert result is None


def test_sdk_extract_parent_context_returns_none_without_tracing_key() -> None:
    """extract_parent_context returns None when payload has no _tracing key."""
    ot, sc, span, tracer = _make_mock_ot()
    _patch_sdk_tracing(ot, sc)
    try:
        result = sdk_tracing.extract_parent_context({"task_id": "t6", "meta": {}})
        assert result is None
    finally:
        _restore_sdk_tracing()


def test_sdk_extract_parent_context_calls_ot_extract() -> None:
    """extract_parent_context delegates to opentelemetry.propagate.extract when key present."""
    ot, sc, span, tracer = _make_mock_ot()
    _patch_sdk_tracing(ot, sc)
    fake_ctx = object()
    with mock.patch.dict(
        "sys.modules",
        {"opentelemetry.propagate": mock.MagicMock(extract=mock.MagicMock(return_value=fake_ctx))},
    ):
        result = sdk_tracing.extract_parent_context({"_tracing": {"traceparent": "abc"}})
    assert result is fake_ctx
    _restore_sdk_tracing()


# ---------------------------------------------------------------------------
# Client tracing tests (imported separately to avoid import-time OTel check)
# ---------------------------------------------------------------------------

_CLIENT_PATH = str(Path(__file__).parent.parent.parent / "operator-client")
if _CLIENT_PATH not in sys.path:
    sys.path.insert(0, _CLIENT_PATH)
    # Force the sandai namespace package to pick up the new path
    import importlib
    import pkgutil
    import sandai
    sandai.__path__ = list(pkgutil.extend_path(sandai.__path__, sandai.__name__))


def test_client_tracing_inject_noop_when_disabled() -> None:
    """inject_trace_context returns payload unchanged when tracing is disabled."""
    import sandai.operator_client.tracing as ct
    ct._reset_for_testing(enabled=False)

    payload = {"task_id": "c1", "artifacts": []}
    result = ct.inject_trace_context(payload)
    assert result is payload
    assert "_tracing" not in result


def test_client_tracing_inject_adds_tracing_key_when_active() -> None:
    """inject_trace_context adds _tracing when a span context is active."""
    import sandai.operator_client.tracing as ct

    mock_ot = mock.MagicMock()
    ct._ot_trace = mock_ot
    ct._active_spans_noop = False  # not used but set

    fake_carrier = {"traceparent": "00-abc-01"}

    def fake_inject(carrier):
        carrier.update(fake_carrier)

    try:
        with mock.patch.dict(
            "sys.modules",
            {
                "opentelemetry.propagate": mock.MagicMock(inject=fake_inject),
            },
        ):
            payload = {"task_id": "c2", "meta": {}}
            result = ct.inject_trace_context(payload)

        assert "_tracing" in result
        assert result["_tracing"] == fake_carrier
    finally:
        ct._reset_for_testing(enabled=False)


def test_client_operator_span_noop_when_disabled() -> None:
    """operator_span is a no-op context manager when tracing is disabled."""
    import sandai.operator_client.tracing as ct
    ct._reset_for_testing(enabled=False)

    with ct.operator_span("my-op") as span:
        assert span is None


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

def main() -> int:
    tests = [
        ("sdk_noop_when_disabled", test_sdk_tracing_all_noop_when_disabled),
        ("sdk_task_started_creates_span", test_sdk_tracing_task_started_creates_span),
        ("sdk_stage_event", test_sdk_tracing_task_stage_event_added_to_span),
        ("sdk_finished_success", test_sdk_tracing_task_finished_ends_span_success),
        ("sdk_finished_error", test_sdk_tracing_task_finished_sets_error_status),
        ("sdk_finished_unknown_noop", test_sdk_tracing_task_finished_unknown_task_is_noop),
        ("sdk_extract_noop_disabled", test_sdk_extract_parent_context_returns_none_when_disabled),
        ("sdk_extract_no_key", test_sdk_extract_parent_context_returns_none_without_tracing_key),
        ("sdk_extract_delegates_ot", test_sdk_extract_parent_context_calls_ot_extract),
        ("client_inject_noop_disabled", test_client_tracing_inject_noop_when_disabled),
        ("client_inject_adds_key", test_client_tracing_inject_adds_tracing_key_when_active),
        ("client_span_noop_disabled", test_client_operator_span_noop_when_disabled),
    ]

    passed = failed = 0
    print("Tracing regression tests")
    print("=" * 60)
    for name, fn in tests:
        try:
            fn()
            print(f"PASS {name}")
            passed += 1
        except Exception as exc:
            print(f"FAIL {name}: {exc}")
            import traceback
            traceback.print_exc()
            failed += 1
    print("=" * 60)
    print(f"passed={passed} failed={failed}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
