"""
Optional GPU utilization monitoring via pynvml (nvidia-ml-py3).

Usage:
    if gpu_monitor.try_init():
        metrics = gpu_monitor.get_metrics()   # List[GpuMetrics]
    ...
    gpu_monitor.shutdown()

Install: pip install nvidia-ml-py3
If pynvml is not installed all functions are safe no-ops.
"""
from __future__ import annotations

import logging
from typing import List, NamedTuple, Optional

logger = logging.getLogger(__name__)

# Module-level state — re-settable via _reset_for_testing()
_pynvml = None    # pynvml module reference, set by try_init()
_nvml_loaded: bool = False


class GpuMetrics(NamedTuple):
    device_index: int
    power_watts: float      # W (0.0 if unsupported by driver)
    utilization_pct: int    # 0–100
    memory_used_mb: int
    memory_total_mb: int


def try_init() -> bool:
    """Try to import pynvml, call nvmlInit(), and verify at least one GPU exists.

    Returns True when ready to call get_metrics(). Returns False if pynvml is
    not installed, CUDA is unavailable, or initialisation fails for any reason.
    """
    global _pynvml, _nvml_loaded
    try:
        import pynvml as _pynvml_mod  # type: ignore[import]
        _pynvml_mod.nvmlInit()
        count = _pynvml_mod.nvmlDeviceGetCount()
        if count == 0:
            logger.warning("[GPU Monitor] No GPU devices found — monitoring disabled.")
            return False
        _pynvml = _pynvml_mod
        _nvml_loaded = True
        logger.info("[GPU Monitor] Initialized with %d GPU(s).", count)
        return True
    except ImportError:
        logger.warning(
            "[GPU Monitor] pynvml not installed "
            "(run: pip install nvidia-ml-py3) — GPU monitoring disabled."
        )
        return False
    except Exception as exc:
        logger.warning("[GPU Monitor] Failed to initialize: %s — disabled.", exc)
        return False


def get_metrics() -> List[GpuMetrics]:
    """Return per-device GPU metrics. Returns an empty list when not initialised
    or when any top-level error occurs. Per-device errors yield 0 values."""
    if _pynvml is None:
        return []
    try:
        count = _pynvml.nvmlDeviceGetCount()
    except Exception:
        return []

    metrics: List[GpuMetrics] = []
    for i in range(count):
        try:
            handle = _pynvml.nvmlDeviceGetHandleByIndex(i)
        except Exception:
            continue

        try:
            power_w = _pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
        except Exception:
            power_w = 0.0

        try:
            util = _pynvml.nvmlDeviceGetUtilizationRates(handle)
            util_pct = int(util.gpu)
        except Exception:
            util_pct = 0

        try:
            mem = _pynvml.nvmlDeviceGetMemoryInfo(handle)
            mem_used_mb = int(mem.used) // (1024 * 1024)
            mem_total_mb = int(mem.total) // (1024 * 1024)
        except Exception:
            mem_used_mb = 0
            mem_total_mb = 0

        metrics.append(GpuMetrics(i, power_w, util_pct, mem_used_mb, mem_total_mb))

    return metrics


def shutdown() -> None:
    """Call nvmlShutdown() if pynvml was loaded. Safe to call multiple times."""
    global _pynvml, _nvml_loaded
    if _nvml_loaded and _pynvml is not None:
        try:
            _pynvml.nvmlShutdown()
        except Exception:
            pass
        _nvml_loaded = False


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

def _reset_for_testing(pynvml_mod=None) -> None:
    """Reset module state. **Do not call in production code.**"""
    global _pynvml, _nvml_loaded
    _pynvml = pynvml_mod
    _nvml_loaded = pynvml_mod is not None
