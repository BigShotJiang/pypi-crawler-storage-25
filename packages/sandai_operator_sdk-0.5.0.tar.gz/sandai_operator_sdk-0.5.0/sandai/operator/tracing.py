"""
Per-job OpenTelemetry tracing support for sandai-operator-sdk.

Install  : pip install sandai-operator-sdk[tracing]
Enable   : export SANDAI_OPERATOR_TRACING_ENABLED=true
Configure: set up a TracerProvider (e.g. via opentelemetry-sdk) before calling run().

When SANDAI_OPERATOR_TRACING_ENABLED is not "true" / "1", all functions are no-ops
regardless of whether opentelemetry-api is installed. This keeps the hot path free of
overhead in deployments that do not configure tracing.

Span hierarchy per job
----------------------
operator.task
  event: prepare.complete   (artifact download + input conversion done)
  event: compute.complete   (user batch function returned)
  event: compute.error      (user batch function raised)
  attribute task.status set to "success" / "error" / "partial" on finish
"""
from __future__ import annotations

import os
from typing import Any, Dict, Optional

# ---------------------------------------------------------------------------
# Module-level initialisation — re-configurable via _reset_for_testing()
# ---------------------------------------------------------------------------

_TRACING_ENABLED: bool = os.getenv("SANDAI_OPERATOR_TRACING_ENABLED", "false").lower() in (
    "true",
    "1",
)

# These are None when disabled or when opentelemetry-api is not installed.
_ot_trace: Any = None
_StatusCode: Any = None

if _TRACING_ENABLED:
    try:
        import opentelemetry.trace as _ot_trace  # type: ignore[assignment]
        from opentelemetry.trace import StatusCode as _StatusCode  # type: ignore[assignment]
    except ImportError:
        pass

_TRACER_NAME = "sandai.operator.sdk"

# task_id -> root Span; one entry per in-flight task while the span is open.
_active_spans: Dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _tracer() -> Optional[Any]:
    if _ot_trace is None:
        return None
    return _ot_trace.get_tracer(_TRACER_NAME)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def task_started(
    task_id: str,
    operator_name: str,
    parent_context: Optional[Any] = None,
) -> None:
    """Start the root span for a job entering the Prepare stage.

    Args:
        task_id: Unique task identifier.
        operator_name: Name of the BatchProcessor (used as operator.name attribute).
        parent_context: Optional OTel Context extracted from the client payload.
                        When provided, the new span becomes a child of the client span.
    """
    t = _tracer()
    if t is None:
        return
    span = t.start_span(
        "operator.task",
        context=parent_context,
        attributes={
            "task.id": task_id,
            "operator.name": operator_name,
        },
    )
    _active_spans[task_id] = span


def task_stage_event(task_id: str, event: str, **attrs: Any) -> None:
    """Attach a named pipeline-stage event to the active span.

    Args:
        task_id: Task identifier.
        event: Event name, e.g. ``"prepare.complete"``, ``"compute.complete"``.
        **attrs: Arbitrary key/value attributes attached to the event.
    """
    span = _active_spans.get(task_id)
    if span is None:
        return
    span.add_event(event, attributes=attrs)


def task_finished(
    task_id: str,
    status: str,
    error_type: Optional[str] = None,
    error_message: Optional[str] = None,
) -> None:
    """End the root span after the output has been delivered to the channel.

    Args:
        task_id: Task identifier.
        status: Final task status, e.g. ``"success"``, ``"error"``, ``"partial"``.
        error_type: Optional error type string set as ``error.type`` attribute.
        error_message: Optional error message (truncated to 512 chars).
    """
    span = _active_spans.pop(task_id, None)
    if span is None:
        return

    span.set_attribute("task.status", status)

    if _StatusCode is not None:
        if status == "error":
            if error_type:
                span.set_attribute("error.type", error_type)
            if error_message:
                span.set_attribute("error.message", error_message[:512])
            span.set_status(_StatusCode.ERROR, error_message or "")
        else:
            span.set_status(_StatusCode.OK)

    span.end()


def extract_parent_context(raw_input: Dict[str, Any]) -> Optional[Any]:
    """Extract an OTel context propagated by the client into the task payload.

    The client injects a ``_tracing`` dict (W3C traceparent / tracestate headers)
    at the top level of the Celery task payload. This function extracts that dict
    and returns an OpenTelemetry Context object suitable for use as ``parent_context``
    in :func:`task_started`.

    Returns ``None`` when tracing is disabled, OTel is unavailable, or no context
    was propagated.
    """
    if _ot_trace is None:
        return None
    headers = raw_input.get("_tracing")
    if not headers or not isinstance(headers, dict):
        return None
    try:
        from opentelemetry.propagate import extract  # type: ignore[import]

        return extract(headers)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

def _reset_for_testing(enabled: bool = True) -> None:
    """Reset module-level state. **Do not call in production code.**"""
    global _TRACING_ENABLED, _ot_trace, _StatusCode
    _active_spans.clear()
    _TRACING_ENABLED = enabled
    if enabled:
        try:
            import opentelemetry.trace

            _ot_trace = opentelemetry.trace
            from opentelemetry.trace import StatusCode

            _StatusCode = StatusCode
        except ImportError:
            _ot_trace = None
            _StatusCode = None
    else:
        _ot_trace = None
        _StatusCode = None
