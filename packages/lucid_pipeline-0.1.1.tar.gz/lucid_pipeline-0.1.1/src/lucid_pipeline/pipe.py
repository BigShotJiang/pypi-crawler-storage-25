from abc import ABC, abstractmethod
from typing import Any, Callable


class Pipe(ABC):
    """Abstract base class for class-based pipes.

    Subclasses must implement `handle(data, next_pipe)`.
    Call `next_pipe(data)` to continue the pipeline, or return
    without calling it to short-circuit.
    """

    @abstractmethod
    def handle(self, data: Any, next_pipe: Callable[[Any], Any]) -> Any:
        ...
