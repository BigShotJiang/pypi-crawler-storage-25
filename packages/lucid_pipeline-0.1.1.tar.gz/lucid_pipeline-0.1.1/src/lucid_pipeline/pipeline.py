from __future__ import annotations

from typing import Any, Callable

from lucid_pipeline.pipe import Pipe


class Pipeline:
    """A clean, expressive pipeline for passing data through a series of steps."""

    def __init__(self, passable: Any) -> None:
        self._passable = passable
        self._pipes: list[Callable[[Any], Any] | Pipe] = []
        self._failure_handler: Callable[[Any, Exception], Any] | None = None

    def through(self, pipes: list[Callable[[Any], Any] | Pipe]) -> Pipeline:
        """Append a list of pipes to the pipeline."""
        self._pipes.extend(pipes)
        return self

    def pipe(self, single_pipe: Callable[[Any], Any] | Pipe) -> Pipeline:
        """Append a single pipe. Syntactic sugar for `.through([single_pipe])`."""
        self._pipes.append(single_pipe)
        return self

    def when(
        self,
        condition: bool | Callable[[Any], bool],
        pipes: list[Callable[[Any], Any] | Pipe],
    ) -> Pipeline:
        """Conditionally add pipes. They run only if condition is truthy."""
        if callable(condition):
            self._pipes.append(_ConditionalSegment(condition, pipes, invert=False))
        elif condition:
            self._pipes.extend(pipes)
        return self

    def unless(
        self,
        condition: bool | Callable[[Any], bool],
        pipes: list[Callable[[Any], Any] | Pipe],
    ) -> Pipeline:
        """Inverse of `.when()` — pipes run only if the condition is falsy."""
        if callable(condition):
            self._pipes.append(_ConditionalSegment(condition, pipes, invert=True))
        elif not condition:
            self._pipes.extend(pipes)
        return self

    def tap(self, callback: Callable[[Any], None]) -> Pipeline:
        """Run a side effect without modifying the passable."""
        self._pipes.append(_TapPipe(callback))
        return self

    def on_failure(self, handler: Callable[[Any, Exception], Any]) -> Pipeline:
        """Register an exception handler."""
        self._failure_handler = handler
        return self

    def then(self, destination: Callable[[Any], Any]) -> Any:
        """Execute the pipeline and pass the result to a destination function."""
        result = self._execute()
        return destination(result)

    def then_return(self) -> Any:
        """Execute the pipeline and return the result directly."""
        return self._execute()

    def _execute(self) -> Any:
        """Build and run the pipeline chain."""
        try:
            # Flatten conditional segments and build the full pipe list
            pipeline = self._build_chain()
            return pipeline(self._passable)
        except Exception as exc:
            if self._failure_handler is not None:
                return self._failure_handler(self._passable, exc)
            raise

    def _build_chain(self) -> Callable[[Any], Any]:
        """Build a nested callable chain from all pipes."""
        # Start with identity as the innermost function
        def identity(data: Any) -> Any:
            return data

        # Build chain from right to left
        chain = identity
        for p in reversed(self._pipes):
            chain = self._wrap_pipe(p, chain)
        return chain

    def _wrap_pipe(
        self,
        p: Callable[[Any], Any] | Pipe | _ConditionalSegment | _TapPipe,
        next_pipe: Callable[[Any], Any],
    ) -> Callable[[Any], Any]:
        """Wrap a single pipe with the next_pipe continuation."""
        if isinstance(p, _ConditionalSegment):
            return p.wrap(next_pipe, self._wrap_pipe)
        if isinstance(p, _TapPipe):
            return p.wrap(next_pipe)
        if isinstance(p, Pipe):
            def pipe_handler(data: Any, _p: Pipe = p, _next: Callable[[Any], Any] = next_pipe) -> Any:
                return _p.handle(data, _next)
            return pipe_handler
        # Plain callable — call it, then pass result to next
        def func_handler(data: Any, _f: Callable[[Any], Any] = p, _next: Callable[[Any], Any] = next_pipe) -> Any:
            return _next(_f(data))
        return func_handler


class _ConditionalSegment:
    """Internal: represents a `.when()` or `.unless()` with a callable condition."""

    def __init__(
        self,
        condition: Callable[[Any], bool],
        pipes: list[Callable[[Any], Any] | Pipe],
        invert: bool,
    ) -> None:
        self.condition = condition
        self.pipes = pipes
        self.invert = invert

    def wrap(
        self,
        next_pipe: Callable[[Any], Any],
        wrap_fn: Callable[..., Callable[[Any], Any]],
    ) -> Callable[[Any], Any]:
        # Build a sub-chain for the conditional pipes that leads into next_pipe
        sub_chain = next_pipe
        for p in reversed(self.pipes):
            sub_chain = wrap_fn(p, sub_chain)

        def handler(data: Any) -> Any:
            result = self.condition(data)
            should_run = (not result) if self.invert else result
            if should_run:
                return sub_chain(data)
            return next_pipe(data)

        return handler


class _TapPipe:
    """Internal: represents a `.tap()` side effect."""

    def __init__(self, callback: Callable[[Any], None]) -> None:
        self.callback = callback

    def wrap(self, next_pipe: Callable[[Any], Any]) -> Callable[[Any], Any]:
        def handler(data: Any) -> Any:
            self.callback(data)
            return next_pipe(data)
        return handler
