from abc import ABC, abstractmethod
from typing import Any, Callable, Coroutine


class AsyncPipe(ABC):
    """Abstract base class for async class-based pipes.

    Subclasses must implement `async handle(data, next_pipe)`.
    Await `next_pipe(data)` to continue the pipeline, or return
    without calling it to short-circuit.
    """

    @abstractmethod
    async def handle(
        self, data: Any, next_pipe: Callable[[Any], Coroutine[Any, Any, Any]]
    ) -> Any:
        ...
