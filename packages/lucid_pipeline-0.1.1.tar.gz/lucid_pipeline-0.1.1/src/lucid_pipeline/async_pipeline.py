from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable, Coroutine

from lucid_pipeline.async_pipe import AsyncPipe
from lucid_pipeline.pipe import Pipe


class AsyncPipeline:
    """Async version of Pipeline. Supports both sync and async callables."""

    def __init__(self, passable: Any) -> None:
        self._passable = passable
        self._pipes: list[Any] = []
        self._failure_handler: Callable[[Any, Exception], Any] | None = None

    def through(self, pipes: list[Any]) -> AsyncPipeline:
        """Append a list of pipes to the pipeline."""
        self._pipes.extend(pipes)
        return self

    def pipe(self, single_pipe: Any) -> AsyncPipeline:
        """Append a single pipe."""
        self._pipes.append(single_pipe)
        return self

    def when(self, condition: Any, pipes: list[Any]) -> AsyncPipeline:
        """Conditionally add pipes."""
        if callable(condition) and not isinstance(condition, bool):
            self._pipes.append(_AsyncConditionalSegment(condition, pipes, invert=False))
        elif condition:
            self._pipes.extend(pipes)
        return self

    def unless(self, condition: Any, pipes: list[Any]) -> AsyncPipeline:
        """Inverse of `.when()`."""
        if callable(condition) and not isinstance(condition, bool):
            self._pipes.append(_AsyncConditionalSegment(condition, pipes, invert=True))
        elif not condition:
            self._pipes.extend(pipes)
        return self

    def tap(self, callback: Callable[[Any], None]) -> AsyncPipeline:
        """Run a side effect without modifying the passable."""
        self._pipes.append(_AsyncTapPipe(callback))
        return self

    def on_failure(self, handler: Callable[[Any, Exception], Any]) -> AsyncPipeline:
        """Register an exception handler."""
        self._failure_handler = handler
        return self

    async def then(self, destination: Callable[[Any], Any]) -> Any:
        """Execute the pipeline and pass the result to a destination function."""
        result = await self._execute()
        if asyncio.iscoroutinefunction(destination):
            return await destination(result)
        return destination(result)

    async def then_return(self) -> Any:
        """Execute the pipeline and return the result directly."""
        return await self._execute()

    async def _execute(self) -> Any:
        """Build and run the async pipeline chain."""
        try:
            chain = self._build_chain()
            return await chain(self._passable)
        except Exception as exc:
            if self._failure_handler is not None:
                if asyncio.iscoroutinefunction(self._failure_handler):
                    return await self._failure_handler(self._passable, exc)
                return self._failure_handler(self._passable, exc)
            raise

    def _build_chain(self) -> Callable[[Any], Coroutine[Any, Any, Any]]:
        """Build a nested async callable chain from all pipes."""

        async def identity(data: Any) -> Any:
            return data

        chain = identity
        for p in reversed(self._pipes):
            chain = self._wrap_pipe(p, chain)
        return chain

    def _wrap_pipe(self, p: Any, next_pipe: Any) -> Callable[[Any], Coroutine[Any, Any, Any]]:
        """Wrap a single pipe with the next_pipe continuation."""
        if isinstance(p, _AsyncConditionalSegment):
            return p.wrap(next_pipe, self._wrap_pipe)

        if isinstance(p, _AsyncTapPipe):
            return p.wrap(next_pipe)

        if isinstance(p, AsyncPipe):
            async def async_pipe_handler(
                data: Any, _p: AsyncPipe = p, _next: Any = next_pipe
            ) -> Any:
                return await _p.handle(data, _next)
            return async_pipe_handler

        if isinstance(p, Pipe):
            async def sync_pipe_handler(
                data: Any, _p: Pipe = p, _next: Any = next_pipe
            ) -> Any:
                # Wrap async next_pipe into a sync-compatible call for sync Pipe
                # Sync Pipe's handle expects a sync next_pipe, but we're in async context.
                # We need to collect the result from the async next and return it.
                result_holder: list[Any] = []

                async def async_next_wrapper(d: Any) -> Any:
                    return await _next(d)

                # Since sync Pipe can't await, we run the inner chain differently:
                # We let the sync pipe call a sync function that stores the data,
                # then we await the rest after.
                captured_data: list[Any] = []

                def sync_next(d: Any) -> Any:
                    captured_data.append(d)
                    # Return a placeholder; the actual async result will be resolved
                    return d

                sync_result = _p.handle(data, sync_next)

                if captured_data:
                    # next_pipe was called; await the async continuation
                    return await _next(captured_data[0])
                else:
                    # short-circuited
                    return sync_result

            return sync_pipe_handler

        if asyncio.iscoroutinefunction(p):
            async def async_func_handler(
                data: Any, _f: Any = p, _next: Any = next_pipe
            ) -> Any:
                result = await _f(data)
                return await _next(result)
            return async_func_handler

        # Plain sync callable
        async def sync_func_handler(
            data: Any, _f: Any = p, _next: Any = next_pipe
        ) -> Any:
            result = _f(data)
            return await _next(result)
        return sync_func_handler


class _AsyncConditionalSegment:
    """Internal: represents an async `.when()` or `.unless()` with a callable condition."""

    def __init__(self, condition: Any, pipes: list[Any], invert: bool) -> None:
        self.condition = condition
        self.pipes = pipes
        self.invert = invert

    def wrap(self, next_pipe: Any, wrap_fn: Any) -> Callable[[Any], Coroutine[Any, Any, Any]]:
        sub_chain = next_pipe
        for p in reversed(self.pipes):
            sub_chain = wrap_fn(p, sub_chain)

        async def handler(data: Any) -> Any:
            if asyncio.iscoroutinefunction(self.condition):
                result = await self.condition(data)
            else:
                result = self.condition(data)
            should_run = (not result) if self.invert else result
            if should_run:
                return await sub_chain(data)
            return await next_pipe(data)

        return handler


class _AsyncTapPipe:
    """Internal: represents an async `.tap()` side effect."""

    def __init__(self, callback: Callable[[Any], None]) -> None:
        self.callback = callback

    def wrap(self, next_pipe: Any) -> Callable[[Any], Coroutine[Any, Any, Any]]:
        async def handler(data: Any) -> Any:
            if asyncio.iscoroutinefunction(self.callback):
                await self.callback(data)
            else:
                self.callback(data)
            return await next_pipe(data)
        return handler
