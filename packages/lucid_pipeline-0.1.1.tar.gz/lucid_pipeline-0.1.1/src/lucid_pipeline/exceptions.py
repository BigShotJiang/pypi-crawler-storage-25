class PipelineError(Exception):
    """Base exception for all pipeline errors."""


class PipelineFlowError(PipelineError):
    """Raised when pipeline is misconfigured (e.g., no pipes set)."""
