from lucid_pipeline import Pipeline, Pipe


def test_pipeline_with_no_pipes():
    result = Pipeline(42).then_return()
    assert result == 42


def test_pipeline_with_none_passable():
    result = Pipeline(None).then_return()
    assert result is None


def test_pipeline_with_none_passable_through_pipes():
    result = Pipeline(None).through([lambda x: x is None]).then_return()
    assert result is True


def test_pipe_returns_none_explicitly():
    result = Pipeline(5).through([lambda x: None]).then_return()
    assert result is None


def test_none_propagates_through_chain():
    result = (
        Pipeline(5)
        .through([lambda x: None, lambda x: x is None])
        .then_return()
    )
    assert result is True


def test_deeply_nested_pipes():
    pipes = [lambda x, i=i: x + 1 for i in range(200)]
    result = Pipeline(0).through(pipes).then_return()
    assert result == 200


def test_pipe_method_equivalent_to_through():
    result_pipe = Pipeline(5).pipe(lambda x: x * 2).pipe(lambda x: x + 1).then_return()
    result_through = Pipeline(5).through([lambda x: x * 2, lambda x: x + 1]).then_return()
    assert result_pipe == result_through


def test_through_called_multiple_times_appends():
    result = (
        Pipeline(0)
        .through([lambda x: x + 1])
        .through([lambda x: x + 2])
        .through([lambda x: x + 3])
        .then_return()
    )
    assert result == 6  # 0 + 1 + 2 + 3


def test_empty_through_list():
    result = Pipeline(42).through([]).then_return()
    assert result == 42


def test_pipeline_with_string_passable():
    result = (
        Pipeline("hello world")
        .through([str.upper, lambda s: s.replace(" ", "_")])
        .then_return()
    )
    assert result == "HELLO_WORLD"


def test_pipeline_preserves_complex_types():
    class MyObj:
        def __init__(self, value):
            self.value = value

    obj = MyObj(10)
    result = Pipeline(obj).through([lambda o: o]).then_return()
    assert result is obj
    assert result.value == 10


def test_class_pipe_short_circuit_with_mixed():
    class GuardPipe(Pipe):
        def handle(self, data, next_pipe):
            if data < 0:
                return "negative"
            return next_pipe(data)

    result = Pipeline(-5).through([GuardPipe(), lambda x: x * 2]).then_return()
    assert result == "negative"

    result = Pipeline(5).through([GuardPipe(), lambda x: x * 2]).then_return()
    assert result == 10


def test_then_with_complex_destination():
    result = (
        Pipeline({"items": [1, 2, 3]})
        .through([lambda d: {**d, "total": sum(d["items"])}])
        .then(lambda d: f"Total: {d['total']}")
    )
    assert result == "Total: 6"
