from lucid_pipeline import Pipeline, Pipe


class DoublePipe(Pipe):
    def handle(self, data, next_pipe):
        return next_pipe(data * 2)


class AddTenPipe(Pipe):
    def handle(self, data, next_pipe):
        return next_pipe(data + 10)


class ShortCircuitPipe(Pipe):
    def handle(self, data, next_pipe):
        if data > 100:
            return -1  # short-circuit
        return next_pipe(data)


class MiddlewarePipe(Pipe):
    def __init__(self):
        self.before = False
        self.after = False

    def handle(self, data, next_pipe):
        self.before = True
        result = next_pipe(data)
        self.after = True
        return result


def test_pipe_handle_called_with_data_and_next():
    result = Pipeline(5).through([DoublePipe()]).then_return()
    assert result == 10


def test_pipe_next_continues_pipeline():
    result = Pipeline(5).through([DoublePipe(), AddTenPipe()]).then_return()
    assert result == 20  # (5 * 2) + 10


def test_pipe_short_circuit():
    result = Pipeline(200).through([ShortCircuitPipe(), DoublePipe()]).then_return()
    assert result == -1


def test_pipe_short_circuit_does_not_trigger_when_condition_not_met():
    result = Pipeline(5).through([ShortCircuitPipe(), DoublePipe()]).then_return()
    assert result == 10


def test_pipe_middleware_pattern():
    middleware = MiddlewarePipe()
    Pipeline(5).through([middleware, DoublePipe()]).then_return()
    assert middleware.before is True
    assert middleware.after is True


def test_pipe_logic_after_next():
    log = []

    class LoggingPipe(Pipe):
        def handle(self, data, next_pipe):
            log.append("before")
            result = next_pipe(data)
            log.append("after")
            return result

    Pipeline(5).through([LoggingPipe(), DoublePipe()]).then_return()
    assert log == ["before", "after"]


def test_mixed_function_and_class_pipes():
    result = (
        Pipeline(5)
        .through([lambda x: x + 1, DoublePipe(), lambda x: x + 3])
        .then_return()
    )
    # (5 + 1) = 6, then DoublePipe: 6 * 2 = 12, then + 3 = 15
    assert result == 15


def test_pipe_with_constructor_args():
    class MultiplyPipe(Pipe):
        def __init__(self, factor):
            self.factor = factor

        def handle(self, data, next_pipe):
            return next_pipe(data * self.factor)

    result = Pipeline(5).through([MultiplyPipe(3)]).then_return()
    assert result == 15
