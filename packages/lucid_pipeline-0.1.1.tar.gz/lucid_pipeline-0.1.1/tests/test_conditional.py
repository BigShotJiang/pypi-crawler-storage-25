from lucid_pipeline import Pipeline


def double(x):
    return x * 2


def add_ten(x):
    return x + 10


def test_when_true_includes_pipes():
    result = Pipeline(5).when(True, [double]).then_return()
    assert result == 10


def test_when_false_skips_pipes():
    result = Pipeline(5).when(False, [double]).then_return()
    assert result == 5


def test_when_callable_evaluated_at_execution_time():
    result = (
        Pipeline(5)
        .through([double])  # 10
        .when(lambda data: data > 5, [add_ten])  # 10 > 5, so +10 = 20
        .then_return()
    )
    assert result == 20


def test_when_callable_false_skips():
    result = (
        Pipeline(5)
        .through([double])  # 10
        .when(lambda data: data > 100, [add_ten])  # 10 > 100 is False
        .then_return()
    )
    assert result == 10


def test_unless_true_skips_pipes():
    result = Pipeline(5).unless(True, [double]).then_return()
    assert result == 5


def test_unless_false_includes_pipes():
    result = Pipeline(5).unless(False, [double]).then_return()
    assert result == 10


def test_unless_callable_true_skips():
    result = (
        Pipeline(5)
        .unless(lambda data: data < 10, [double])  # 5 < 10 is True, so skip
        .then_return()
    )
    assert result == 5


def test_unless_callable_false_includes():
    result = (
        Pipeline(5)
        .unless(lambda data: data > 10, [double])  # 5 > 10 is False, so include
        .then_return()
    )
    assert result == 10


def test_callable_condition_receives_current_passable():
    received = []

    def capture_condition(data):
        received.append(data)
        return True

    Pipeline(42).when(capture_condition, [lambda x: x]).then_return()
    assert received == [42]


def test_when_with_multiple_conditional_pipes():
    result = (
        Pipeline(5)
        .when(True, [double, add_ten])  # 5 * 2 = 10, + 10 = 20
        .then_return()
    )
    assert result == 20


def test_chained_when_and_unless():
    result = (
        Pipeline(5)
        .when(True, [double])       # 10
        .unless(False, [add_ten])    # 20
        .when(False, [double])       # skipped
        .then_return()
    )
    assert result == 20


def test_callable_condition_with_intermediate_data():
    """Callable condition should see data as transformed by prior pipes."""
    result = (
        Pipeline(3)
        .through([double])  # 6
        .when(lambda data: data == 6, [add_ten])  # 6 == 6 -> +10 = 16
        .then_return()
    )
    assert result == 16
