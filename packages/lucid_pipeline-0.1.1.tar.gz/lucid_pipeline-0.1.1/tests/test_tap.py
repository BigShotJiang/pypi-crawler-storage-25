import pytest

from lucid_pipeline import Pipeline


def test_tap_receives_current_passable():
    received = []
    Pipeline(42).tap(lambda data: received.append(data)).then_return()
    assert received == [42]


def test_tap_return_value_is_ignored():
    result = Pipeline(5).tap(lambda data: 999).then_return()
    assert result == 5


def test_tap_does_not_modify_passable():
    result = (
        Pipeline(5)
        .through([lambda x: x * 2])      # 10
        .tap(lambda data: None)
        .through([lambda x: x + 1])      # 11
        .then_return()
    )
    assert result == 11


def test_tap_exceptions_propagate():
    def bad_tap(data):
        raise RuntimeError("tap error")

    with pytest.raises(RuntimeError, match="tap error"):
        Pipeline(5).tap(bad_tap).then_return()


def test_tap_sees_intermediate_value():
    seen = []

    result = (
        Pipeline(5)
        .through([lambda x: x * 2])      # 10
        .tap(lambda data: seen.append(data))
        .through([lambda x: x + 1])      # 11
        .then_return()
    )
    assert result == 11
    assert seen == [10]


def test_multiple_taps():
    log = []

    result = (
        Pipeline(1)
        .tap(lambda d: log.append(f"a:{d}"))
        .through([lambda x: x + 1])
        .tap(lambda d: log.append(f"b:{d}"))
        .then_return()
    )
    assert result == 2
    assert log == ["a:1", "b:2"]


def test_tap_with_on_failure():
    """If tap raises, on_failure catches it."""
    def bad_tap(data):
        raise ValueError("tap boom")

    def handler(data, error):
        return f"caught: {error}"

    result = (
        Pipeline(5)
        .tap(bad_tap)
        .on_failure(handler)
        .then_return()
    )
    assert result == "caught: tap boom"
