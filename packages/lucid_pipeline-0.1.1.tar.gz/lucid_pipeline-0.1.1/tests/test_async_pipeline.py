import pytest

from lucid_pipeline import AsyncPipeline, AsyncPipe, Pipe


async def async_double(x):
    return x * 2


async def async_add_ten(x):
    return x + 10


class AsyncDoublePipe(AsyncPipe):
    async def handle(self, data, next_pipe):
        return await next_pipe(data * 2)


class AsyncMiddlewarePipe(AsyncPipe):
    def __init__(self):
        self.before = False
        self.after = False

    async def handle(self, data, next_pipe):
        self.before = True
        result = await next_pipe(data)
        self.after = True
        return result


# --- Async function pipes ---

@pytest.mark.asyncio
async def test_async_function_pipes():
    result = await AsyncPipeline(5).through([async_double, async_add_ten]).then_return()
    assert result == 20


@pytest.mark.asyncio
async def test_async_single_pipe():
    result = await AsyncPipeline(5).through([async_double]).then_return()
    assert result == 10


# --- Async Pipe subclass ---

@pytest.mark.asyncio
async def test_async_pipe_subclass():
    result = await AsyncPipeline(5).through([AsyncDoublePipe()]).then_return()
    assert result == 10


@pytest.mark.asyncio
async def test_async_pipe_middleware_pattern():
    middleware = AsyncMiddlewarePipe()
    await AsyncPipeline(5).through([middleware, AsyncDoublePipe()]).then_return()
    assert middleware.before is True
    assert middleware.after is True


@pytest.mark.asyncio
async def test_async_pipe_short_circuit():
    class AsyncGuard(AsyncPipe):
        async def handle(self, data, next_pipe):
            if data < 0:
                return "negative"
            return await next_pipe(data)

    result = await AsyncPipeline(-1).through([AsyncGuard(), AsyncDoublePipe()]).then_return()
    assert result == "negative"


# --- Sync functions inside AsyncPipeline ---

@pytest.mark.asyncio
async def test_sync_functions_in_async_pipeline():
    result = await (
        AsyncPipeline(5)
        .through([lambda x: x * 2, lambda x: x + 10])
        .then_return()
    )
    assert result == 20


@pytest.mark.asyncio
async def test_mixed_sync_and_async_functions():
    result = await (
        AsyncPipeline(5)
        .through([lambda x: x * 2, async_add_ten])
        .then_return()
    )
    assert result == 20


# --- .when() / .unless() async ---

@pytest.mark.asyncio
async def test_async_when_true():
    result = await AsyncPipeline(5).when(True, [async_double]).then_return()
    assert result == 10


@pytest.mark.asyncio
async def test_async_when_false():
    result = await AsyncPipeline(5).when(False, [async_double]).then_return()
    assert result == 5


@pytest.mark.asyncio
async def test_async_when_callable():
    result = await (
        AsyncPipeline(5)
        .when(lambda data: data > 3, [async_double])
        .then_return()
    )
    assert result == 10


@pytest.mark.asyncio
async def test_async_when_async_callable():
    async def check(data):
        return data > 3

    result = await AsyncPipeline(5).when(check, [async_double]).then_return()
    assert result == 10


@pytest.mark.asyncio
async def test_async_unless_true():
    result = await AsyncPipeline(5).unless(True, [async_double]).then_return()
    assert result == 5


@pytest.mark.asyncio
async def test_async_unless_false():
    result = await AsyncPipeline(5).unless(False, [async_double]).then_return()
    assert result == 10


# --- .tap() async ---

@pytest.mark.asyncio
async def test_async_tap():
    received = []
    result = await (
        AsyncPipeline(42)
        .tap(lambda data: received.append(data))
        .then_return()
    )
    assert result == 42
    assert received == [42]


@pytest.mark.asyncio
async def test_async_tap_async_callback():
    received = []

    async def async_log(data):
        received.append(data)

    result = await AsyncPipeline(42).tap(async_log).then_return()
    assert result == 42
    assert received == [42]


# --- .on_failure() async ---

@pytest.mark.asyncio
async def test_async_on_failure():
    async def explode(data):
        raise ValueError("async boom")

    def handler(data, error):
        return f"caught: {error}"

    result = await (
        AsyncPipeline(5)
        .through([explode])
        .on_failure(handler)
        .then_return()
    )
    assert result == "caught: async boom"


@pytest.mark.asyncio
async def test_async_on_failure_receives_original_passable():
    received_data = []

    def handler(data, error):
        received_data.append(data)
        return "handled"

    async def transform(data):
        return data * 2

    async def explode(data):
        raise ValueError("boom")

    result = await (
        AsyncPipeline(5)
        .through([transform, explode])
        .on_failure(handler)
        .then_return()
    )
    assert result == "handled"
    assert received_data == [5]


@pytest.mark.asyncio
async def test_async_without_on_failure_propagates():
    async def explode(data):
        raise ValueError("boom")

    with pytest.raises(ValueError, match="boom"):
        await AsyncPipeline(5).through([explode]).then_return()


# --- .then() async ---

@pytest.mark.asyncio
async def test_async_then():
    result = await (
        AsyncPipeline(5)
        .through([async_double])
        .then(lambda x: f"Result: {x}")
    )
    assert result == "Result: 10"


@pytest.mark.asyncio
async def test_async_then_with_async_destination():
    async def save(data):
        return f"saved: {data}"

    result = await AsyncPipeline(5).through([async_double]).then(save)
    assert result == "saved: 10"


# --- Edge cases ---

@pytest.mark.asyncio
async def test_async_empty_pipeline():
    result = await AsyncPipeline(42).then_return()
    assert result == 42


@pytest.mark.asyncio
async def test_async_none_passable():
    result = await AsyncPipeline(None).then_return()
    assert result is None
