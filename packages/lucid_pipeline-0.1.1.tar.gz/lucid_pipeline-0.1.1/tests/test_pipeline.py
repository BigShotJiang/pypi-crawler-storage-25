from lucid_pipeline import Pipeline


def test_empty_pipeline_returns_passable():
    result = Pipeline(42).then_return()
    assert result == 42


def test_single_function_pipe():
    result = Pipeline(5).through([lambda x: x * 2]).then_return()
    assert result == 10


def test_multiple_function_pipes_execute_in_order():
    def double(x):
        return x * 2

    def add_ten(x):
        return x + 10

    result = Pipeline(5).through([double, add_ten]).then_return()
    assert result == 20  # (5 * 2) + 10


def test_then_passes_result_to_destination():
    result = Pipeline(5).through([lambda x: x * 2]).then(lambda x: f"Result: {x}")
    assert result == "Result: 10"


def test_then_return_returns_directly():
    result = Pipeline("hello").through([str.upper]).then_return()
    assert result == "HELLO"


def test_through_appends_pipes():
    result = (
        Pipeline(1)
        .through([lambda x: x + 1])
        .through([lambda x: x + 1])
        .through([lambda x: x + 1])
        .then_return()
    )
    assert result == 4


def test_through_is_chainable():
    pipeline = Pipeline(5)
    returned = pipeline.through([lambda x: x])
    assert returned is pipeline


def test_pipe_syntactic_sugar():
    result = (
        Pipeline(1)
        .pipe(lambda x: x + 1)
        .pipe(lambda x: x * 3)
        .then_return()
    )
    assert result == 6  # (1 + 1) * 3


def test_pipeline_with_dict_data():
    def add_name(data):
        data["name"] = "John"
        return data

    def add_age(data):
        data["age"] = 30
        return data

    result = Pipeline({}).through([add_name, add_age]).then_return()
    assert result == {"name": "John", "age": 30}


def test_pipeline_with_list_data():
    result = (
        Pipeline([3, 1, 2])
        .pipe(sorted)
        .pipe(lambda x: [v * 2 for v in x])
        .then_return()
    )
    assert result == [2, 4, 6]
