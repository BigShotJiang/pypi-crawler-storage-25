import pytest

from lucid_pipeline import Pipeline


def test_without_on_failure_exceptions_propagate():
    def explode(data):
        raise ValueError("boom")

    with pytest.raises(ValueError, match="boom"):
        Pipeline(5).through([explode]).then_return()


def test_on_failure_handler_receives_passable_and_exception():
    received = {}

    def handler(data, error):
        received["data"] = data
        received["error"] = error
        return "handled"

    def explode(data):
        raise ValueError("boom")

    result = Pipeline(42).through([explode]).on_failure(handler).then_return()
    assert result == "handled"
    assert received["data"] == 42
    assert isinstance(received["error"], ValueError)
    assert str(received["error"]) == "boom"


def test_on_failure_handler_return_value_becomes_result():
    def handler(data, error):
        return {"success": False, "error": str(error)}

    def explode(data):
        raise RuntimeError("fail")

    result = Pipeline("input").through([explode]).on_failure(handler).then_return()
    assert result == {"success": False, "error": "fail"}


def test_on_failure_receives_original_passable_not_intermediate():
    """Handler gets the original passable, not any intermediate state."""
    received_data = []

    def handler(data, error):
        received_data.append(data)
        return "handled"

    def transform(data):
        return data * 2

    def explode(data):
        raise ValueError("boom")

    result = (
        Pipeline(5)
        .through([transform, explode])
        .on_failure(handler)
        .then_return()
    )
    assert result == "handled"
    assert received_data == [5]  # original passable, not 10


def test_on_failure_with_then():
    def handler(data, error):
        return "recovered"

    def explode(data):
        raise ValueError("boom")

    # When on_failure catches, then() still receives the handler's result
    result = (
        Pipeline(5)
        .through([explode])
        .on_failure(handler)
        .then(lambda x: f"final: {x}")
    )
    assert result == "final: recovered"


def test_no_exception_handler_not_called():
    called = []

    def handler(data, error):
        called.append(True)
        return "handled"

    result = (
        Pipeline(5)
        .through([lambda x: x * 2])
        .on_failure(handler)
        .then_return()
    )
    assert result == 10
    assert called == []


def test_exception_in_class_pipe():
    from lucid_pipeline import Pipe

    class ExplodingPipe(Pipe):
        def handle(self, data, next_pipe):
            raise TypeError("class pipe error")

    def handler(data, error):
        return f"caught: {error}"

    result = (
        Pipeline(5)
        .through([ExplodingPipe()])
        .on_failure(handler)
        .then_return()
    )
    assert result == "caught: class pipe error"
