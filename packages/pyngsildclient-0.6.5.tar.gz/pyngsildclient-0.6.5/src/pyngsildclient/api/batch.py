# Software Name: pyngsildclient
# SPDX-FileCopyrightText: Copyright (c) 2021 Orange
# SPDX-License-Identifier: Apache 2.0
#
# This software is distributed under the Apache 2.0;
# see the NOTICE file for more details.
#
# Author: Fabien BATTELLO <fabien.battello@orange.com> et al.

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal, Self

if TYPE_CHECKING:
    from pyngsildclient.model.constants import EntityOrId

import json
import logging

if TYPE_CHECKING:
    from .client import Client

from pyngsildclient.model.utils import NgsiEncoder
from pyngsildclient.utils.console import Console, MsgLvl

from ..model.entity import Entity
from .constants import BATCHSIZE
from .exceptions import NgsiApiError, rfc7807_error_handle

BatchOp = Literal["create", "upsert", "update", "delete"]

logger = logging.getLogger(__name__)


@dataclass
class BatchResult:
    op: BatchOp = "N/A"
    success: list = field(default_factory=list)
    errors: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.errors == []

    @property
    def n_ok(self) -> int:
        return len(self.success)

    @property
    def n_err(self) -> int:
        return len(self.errors)

    @property
    def n_tot(self) -> int:
        return self.n_ok + self.n_err

    @property
    def ratio(self) -> float:
        r = self.n_ok / (self.n_ok + self.n_err)
        return round(r, 2)

    @property
    def level(self) -> MsgLvl:
        if self.ratio == 0.0:
            return "error"
        elif self.ratio < 1.0:
            return "warning"
        else:
            return "success"

    def raise_for_status(self):
        if not self.ok:
            raise NgsiApiError(f"Error while processing batch {self.op} operation", self)

    def __repr__(self):
        return f"op: {self.op}, success: {self.n_ok}, errors: {self.n_err}"

    def __iadd__(self, r: Self):
        self.success.extend(r.success)
        self.errors.extend(r.errors)
        return self


class Batch:
    """A wrapper for the NGSI-LD API batch endpoint."""

    def __init__(self, client: Client, url: str):
        self._client = client
        self._session = client.session
        self.url = url
        self.console = Console()

    @rfc7807_error_handle
    def _create(self, entities: Sequence[Entity]) -> BatchResult:
        r = self._session.post(f"{self.url}/create/", data=json.dumps([e for e in entities], cls=NgsiEncoder))
        self._client.raise_for_status(r)
        if r.status_code == 201:
            success, errors = r.json(), []
        elif r.status_code == 207:
            content = r.json()
            success, errors = content["success"], content["errors"]
        else:
            raise NgsiApiError("Batch Create : Unkown HTTP response code {}", r.status_code)
        return BatchResult("create", success, errors)

    @rfc7807_error_handle
    def create(self, entities: Sequence[Entity], *, batchsize: int = BATCHSIZE) -> BatchResult:
        r = BatchResult("create")
        for i in range(0, len(entities), batchsize):
            r += self._create(entities[i : i + batchsize])
        self.console.message(f"Entities created : {r.n_ok}/{r.n_tot} [{r.ratio:.2f}]", lvl=r.level)
        return r

    @rfc7807_error_handle
    def _upsert(self, entities: Sequence[Entity], opt: Literal["replace", "update"] = "replace") -> BatchResult:
        params = {"options": opt} if opt else {}
        r = self._session.post(
            f"{self.url}/upsert/", data=json.dumps([e for e in entities], cls=NgsiEncoder), params=params
        )
        self._client.raise_for_status(r)
        if r.status_code == 201:
            success, errors = r.json(), []
        elif r.status_code == 204:
            success, errors = [e.id for e in entities], []
        elif r.status_code == 207:
            content = r.json()
            success, errors = content["success"], content["errors"]
        else:
            raise NgsiApiError("Batch Upsert : Unkown HTTP response code {}", r.status_code)
        return BatchResult("upsert", success, errors)

    @rfc7807_error_handle
    def upsert(self, entities: Sequence[Entity], *, update: bool = False, batchsize: int = BATCHSIZE) -> BatchResult:
        # default mode (without any option) is "replace", anyway always force the option
        opt = "update" if update else "replace"
        r = BatchResult("upsert")
        for i in range(0, len(entities), batchsize):
            r += self._upsert(entities[i : i + batchsize], opt)
        self.console.message(f"Entities upserted : {r.n_ok}/{r.n_tot} [{r.ratio:.2f}]", lvl=r.level)
        return r

    @rfc7807_error_handle
    def _update(self, entities: Sequence[Entity], opt: Literal["noOverwrite"] | None = None) -> BatchResult:
        params = {"options": opt} if opt else {}
        r = self._session.post(
            f"{self.url}/update/", data=json.dumps([e for e in entities], cls=NgsiEncoder), params=params
        )
        self._client.raise_for_status(r)
        if r.status_code == 204:
            success, errors = [e.id for e in entities], []
        elif r.status_code == 207:
            content = r.json()
            success, errors = content["success"], content["errors"]
        else:
            raise NgsiApiError("Batch Update : Unkown HTTP response code {}", r.status_code)
        return BatchResult("update", success, errors)

    @rfc7807_error_handle
    def update(self, entities: Sequence[Entity], *, overwrite: bool = True, batchsize: int = BATCHSIZE) -> BatchResult:
        opt = "noOverwrite" if not overwrite else None
        r = BatchResult("update")
        for i in range(0, len(entities), batchsize):
            r += self._update(entities[i : i + batchsize], opt)
        self.console.message(f"Entities updated : {r.n_ok}/{r.n_tot} [{r.ratio:.2f}]", lvl=r.level)
        return r

    @rfc7807_error_handle
    def _delete(self, entities: Sequence[EntityOrId]) -> BatchResult:
        r = self._session.post(f"{self.url}/delete/", json=[e.id if isinstance(e, Entity) else e for e in entities])
        self._client.raise_for_status(r)
        if r.status_code == 204:
            success, errors = [e.id for e in entities], []
        elif r.status_code == 207:
            content = r.json()
            success, errors = content["success"], content["errors"]
        else:
            raise NgsiApiError("Batch Delete : Unkown HTTP response code {}", r.status_code)
        return BatchResult("delete", success, errors)

    @rfc7807_error_handle
    def delete(self, entities: Sequence[EntityOrId], *, batchsize: int = BATCHSIZE) -> BatchResult:
        r = BatchResult("delete")
        for i in range(0, len(entities), batchsize):
            r += self._delete(entities[i : i + batchsize])
        self.console.message(f"Entities deleted : {r.n_ok}/{r.n_tot} [{r.ratio:.2f}]", lvl=r.level)
        return r
