# Software Name: ngsildclient
# SPDX-FileCopyrightText: Copyright (c) 2021 Orange
# SPDX-License-Identifier: Apache 2.0
#
# This software is distributed under the Apache 2.0;
# see the NOTICE file for more details.
#
# Author: Fabien BATTELLO <fabien.battello@orange.com> et al.

import json
from pathlib import Path

from pyngsildclient.model.entity import Entity
from pyngsildclient.model.helper.postal import PostalAddressBuilder


def expected_dict(basename: str) -> dict:
    filename: str = Path(__file__).parent.resolve() / "data" / f"{basename}.json"
    with open(filename) as fp:
        expected = json.load(fp)
    return expected


def test_poi():
    """
    https://smart-data-models.github.io/dataModel.PointOfInterest/PointOfInterest/examples/example-normalized.jsonld
    """
    e = Entity(
        "PointOfInterest",
        "PointOfInterest:PointOfInterest-A-Concha-123456",
        ctx=[
            "https://smartdatamodels.org/context.jsonld",
            "https://uri.etsi.org/ngsi-ld/v1/ngsi-ld-core-context.jsonld",
        ],
    )
    e.prop("name", "Playa de a Concha")

    builder = PostalAddressBuilder()
    address = builder.country("ES").locality("Vilagarcía de Arousa").build()
    e.prop("address", address)

    e.prop("category", [113])
    e.prop(
        "description",
        "La Playa de A Concha se presenta como una continuación de la Playa de Compostela, una de las más frecuentadas de Vilagarcía.",
    )
    e.gprop("location", (42.60214472222222, -8.768460000000001))
    e.prop("refSeeAlso", "urn:ngsi-ld:SeeAlso:Beach-A-Concha-123456")
    e.prop("source", "http://www.tourspain.es")

    assert e.to_dict() == expected_dict("poi")
