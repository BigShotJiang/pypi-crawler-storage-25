"""Sherpa transform annotations to categories processor"""

__version__ = "1.6.29"
