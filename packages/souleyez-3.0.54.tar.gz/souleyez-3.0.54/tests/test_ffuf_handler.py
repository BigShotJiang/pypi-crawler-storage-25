#!/usr/bin/env python3
"""
Tests for the FfufHandler.

Tests parsing accuracy and display functionality.
"""

import json
import os
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from souleyez.engine.job_status import (
    STATUS_DONE,
    STATUS_ERROR,
    STATUS_NO_RESULTS,
    STATUS_WARNING,
)
from souleyez.handlers.ffuf_handler import FfufHandler


@pytest.fixture
def handler():
    """Provide a fresh handler instance."""
    return FfufHandler()


@pytest.fixture
def mock_managers():
    """Mock database managers."""
    host_manager = MagicMock()
    findings_manager = MagicMock()
    credentials_manager = MagicMock()

    # Default: host exists
    host_manager.get_host_by_ip.return_value = {"id": 1}
    host_manager.add_or_update_host.return_value = {"id": 1}

    return {
        "host_manager": host_manager,
        "findings_manager": findings_manager,
        "credentials_manager": credentials_manager,
    }


def create_ffuf_json_output(results, target="http://192.168.1.10/FUZZ", method="GET"):
    """Create a valid ffuf JSON output string."""
    data = {
        "commandline": f"ffuf -u {target} -w wordlist.txt",
        "time": "2024-01-15T10:00:00Z",
        "config": {
            "url": target,
            "method": method,
            "wordlist": "/usr/share/wordlists/common.txt",
        },
        "results": results,
    }
    return json.dumps(data)


class TestHandlerMetadata:
    """Test handler metadata."""

    def test_tool_name(self, handler):
        """Handler should have correct tool name."""
        assert handler.tool_name == "ffuf"

    def test_display_name(self, handler):
        """Handler should have human-readable display name."""
        assert handler.display_name == "Ffuf"

    def test_capability_flags(self, handler):
        """Handler should have all capability flags enabled."""
        assert handler.has_done_handler is True
        assert handler.has_warning_handler is True
        assert handler.has_error_handler is True
        assert handler.has_no_results_handler is True


class TestParseJobSuccess:
    """Test successful path enumeration parsing."""

    def test_paths_detected(self, handler, mock_managers):
        """Discovered paths should be detected."""
        results = [
            {"url": "http://192.168.1.10/admin", "status": 200, "length": 1234},
            {
                "url": "http://192.168.1.10/images",
                "status": 301,
                "length": 169,
                "redirectlocation": "http://192.168.1.10/images/",
            },
            {"url": "http://192.168.1.10/robots.txt", "status": 200, "length": 128},
        ]
        log_content = create_ffuf_json_output(results)

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            with patch(
                "souleyez.engine.result_handler.detect_tool_error", return_value=None
            ):
                with patch("souleyez.storage.web_paths.WebPathsManager"):
                    job = {"target": "http://192.168.1.10/FUZZ"}
                    result = handler.parse_job(1, log_path, job, **mock_managers)

                    assert result["status"] == STATUS_DONE
                    assert result["results_found"] == 3
        finally:
            os.unlink(log_path)

    def test_method_extracted(self, handler, mock_managers):
        """HTTP method should be extracted from config."""
        results = [{"url": "http://192.168.1.10/login", "status": 200, "length": 500}]
        log_content = create_ffuf_json_output(results, method="POST")

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            with patch(
                "souleyez.engine.result_handler.detect_tool_error", return_value=None
            ):
                with patch("souleyez.storage.web_paths.WebPathsManager"):
                    job = {"target": "http://192.168.1.10/FUZZ"}
                    result = handler.parse_job(1, log_path, job, **mock_managers)

                    assert result["method"] == "POST"
        finally:
            os.unlink(log_path)


class TestParseJobNoResults:
    """Test no results scenario."""

    def test_no_paths_returns_no_results(self, handler, mock_managers):
        """No paths found should return no_results."""
        log_content = create_ffuf_json_output([])

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            with patch(
                "souleyez.engine.result_handler.detect_tool_error", return_value=None
            ):
                with patch("souleyez.storage.web_paths.WebPathsManager"):
                    job = {"target": "http://192.168.1.10/FUZZ"}
                    result = handler.parse_job(1, log_path, job, **mock_managers)

                    assert result["status"] == STATUS_NO_RESULTS
                    assert result["results_found"] == 0
        finally:
            os.unlink(log_path)


class TestParseJobError:
    """Test error scenario."""

    def test_invalid_json_returns_error(self, handler, mock_managers):
        """Invalid JSON should return error."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("not valid json")
            log_path = f.name

        try:
            job = {"target": "http://192.168.1.10/FUZZ"}
            result = handler.parse_job(1, log_path, job, **mock_managers)

            assert "error" in result
        finally:
            os.unlink(log_path)


class TestSecurityConcerns:
    """Test security concern detection."""

    def test_sensitive_paths_detected(self, handler):
        """Sensitive paths should be identified."""
        paths = [
            {"url": "http://example.com/.git/config", "status_code": 200},
            {"url": "http://example.com/backup.sql", "status_code": 200},
            {"url": "http://example.com/.env", "status_code": 200},
            {"url": "http://example.com/admin/", "status_code": 200},
        ]
        concerns = handler._identify_security_concerns(paths)

        assert len(concerns) >= 4
        severities = [c["severity"] for c in concerns]
        assert "high" in severities
        assert "medium" in severities

    def test_high_severity_for_config_files(self, handler):
        """Config files should be high severity."""
        paths = [
            {"url": "http://example.com/.env", "status_code": 200},
        ]
        concerns = handler._identify_security_concerns(paths)

        assert len(concerns) == 1
        assert concerns[0]["severity"] == "high"
        assert "Configuration" in concerns[0]["label"]


class TestDisplayMethods:
    """Test display method existence and basic functionality."""

    def test_display_done_exists(self, handler):
        """display_done method should exist."""
        assert hasattr(handler, "display_done")

    def test_display_warning_exists(self, handler):
        """display_warning method should exist."""
        assert hasattr(handler, "display_warning")

    def test_display_error_exists(self, handler):
        """display_error method should exist."""
        assert hasattr(handler, "display_error")

    def test_display_no_results_exists(self, handler):
        """display_no_results method should exist."""
        assert hasattr(handler, "display_no_results")

    def test_display_no_results_shows_tips(self, handler, capsys):
        """display_no_results should show helpful tips."""
        job = {"target": "http://example.com/FUZZ"}
        handler.display_no_results(job, "/fake/path")
        captured = capsys.readouterr()
        assert "No paths discovered" in captured.out
        assert "This could mean" in captured.out

    def test_display_error_shows_timeout(self, handler, capsys):
        """display_error should identify timeout errors."""
        log_content = "Command timed out after 300 seconds"
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            job = {}
            handler.display_error(job, log_path)
            captured = capsys.readouterr()
            assert "timeout" in captured.out.lower()
        finally:
            os.unlink(log_path)

    def test_display_done_shows_paths(self, handler, capsys):
        """display_done should show discovered paths."""
        results = [
            {"url": "http://192.168.1.10/admin", "status": 200, "length": 1234},
            {"url": "http://192.168.1.10/login", "status": 200, "length": 500},
        ]
        log_content = create_ffuf_json_output(results)

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            job = {"target": "http://192.168.1.10/FUZZ"}
            handler.display_done(job, log_path)
            captured = capsys.readouterr()
            assert "FFUF DISCOVERED PATHS" in captured.out
            assert "Total found: 2" in captured.out
        finally:
            os.unlink(log_path)


class TestRegistryIntegration:
    """Test that handler is discovered by registry."""

    def test_handler_discovered(self):
        """Handler should be discovered by registry."""
        from souleyez.handlers.registry import get_registry

        registry = get_registry()
        registry.reset()

        from souleyez.handlers import ffuf_handler  # noqa: F401

        handler = registry.get_handler("ffuf")
        assert handler is not None
        assert handler.tool_name == "ffuf"

    def test_registry_reports_capabilities(self):
        """Registry should report handler capabilities correctly."""
        from souleyez.handlers.registry import get_registry

        registry = get_registry()
        registry.reset()

        from souleyez.handlers import ffuf_handler  # noqa: F401

        assert registry.has_warning_handler("ffuf") is True
        assert registry.has_error_handler("ffuf") is True
        assert registry.has_no_results_handler("ffuf") is True
        assert registry.has_done_handler("ffuf") is True


class TestUniformResponseDetection:
    """Test uniform response detection (false positive filter)."""

    def test_uniform_403_all_same_size(self, handler, mock_managers):
        """50 results all 403/23B should be filtered → STATUS_WARNING, 0 stored."""
        results = [
            {
                "url": f"http://api.example.com/{word}",
                "status": 403,
                "length": 23,
            }
            for word in [f"word{i}" for i in range(50)]
        ]
        log_content = create_ffuf_json_output(
            results, target="http://api.example.com/FUZZ"
        )

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            with patch(
                "souleyez.engine.result_handler.detect_tool_error", return_value=None
            ):
                with patch("souleyez.storage.web_paths.WebPathsManager") as mock_wpm:
                    job = {"target": "http://api.example.com/FUZZ"}
                    result = handler.parse_job(1, log_path, job, **mock_managers)

                    assert result["status"] == STATUS_WARNING
                    assert result["uniform_detected"] is True
                    assert result["uniform_removed"] == 50
                    assert len(result["parameters_found"]) == 0
                    # bulk_add_web_paths should NOT be called (no active paths)
                    mock_wpm.return_value.bulk_add_web_paths.assert_not_called()
        finally:
            os.unlink(log_path)

    def test_uniform_with_legitimate_mixed_in(self, handler, mock_managers):
        """48 uniform 403s + 2 real results → WARNING, only 2 paths kept."""
        uniform_results = [
            {
                "url": f"http://api.example.com/{word}",
                "status": 403,
                "length": 23,
            }
            for word in [f"word{i}" for i in range(48)]
        ]
        real_results = [
            {"url": "http://api.example.com/admin", "status": 200, "length": 1234},
            {
                "url": "http://api.example.com/docs",
                "status": 301,
                "length": 169,
                "redirectlocation": "http://api.example.com/docs/",
            },
        ]
        log_content = create_ffuf_json_output(
            uniform_results + real_results, target="http://api.example.com/FUZZ"
        )

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            with patch(
                "souleyez.engine.result_handler.detect_tool_error", return_value=None
            ):
                with patch("souleyez.storage.web_paths.WebPathsManager"):
                    job = {"target": "http://api.example.com/FUZZ"}
                    result = handler.parse_job(1, log_path, job, **mock_managers)

                    assert result["status"] == STATUS_WARNING
                    assert result["uniform_detected"] is True
                    assert result["uniform_removed"] == 48
                    assert len(result["parameters_found"]) == 2
        finally:
            os.unlink(log_path)

    def test_no_uniform_varied_responses(self, handler, mock_managers):
        """20 varied results → STATUS_DONE, all paths kept."""
        results = [
            {
                "url": f"http://example.com/path{i}",
                "status": [200, 301, 403, 404][i % 4],
                "length": 100 + i * 50,
            }
            for i in range(20)
        ]
        log_content = create_ffuf_json_output(results)

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            with patch(
                "souleyez.engine.result_handler.detect_tool_error", return_value=None
            ):
                with patch("souleyez.storage.web_paths.WebPathsManager"):
                    job = {"target": "http://192.168.1.10/FUZZ"}
                    result = handler.parse_job(1, log_path, job, **mock_managers)

                    assert result["status"] == STATUS_DONE
                    assert result["uniform_detected"] is False
                    assert len(result["parameters_found"]) == 20
        finally:
            os.unlink(log_path)

    def test_no_uniform_small_set(self, handler, mock_managers):
        """5 identical results (under threshold) → STATUS_DONE, no filtering."""
        results = [
            {
                "url": f"http://api.example.com/{word}",
                "status": 403,
                "length": 23,
            }
            for word in [f"word{i}" for i in range(5)]
        ]
        log_content = create_ffuf_json_output(
            results, target="http://api.example.com/FUZZ"
        )

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            with patch(
                "souleyez.engine.result_handler.detect_tool_error", return_value=None
            ):
                with patch("souleyez.storage.web_paths.WebPathsManager"):
                    job = {"target": "http://api.example.com/FUZZ"}
                    result = handler.parse_job(1, log_path, job, **mock_managers)

                    assert result["status"] == STATUS_DONE
                    assert result["uniform_detected"] is False
                    assert len(result["parameters_found"]) == 5
        finally:
            os.unlink(log_path)

    def test_uniform_skips_findings_creation(self, handler, mock_managers):
        """Uniform results matching sensitive patterns should NOT create findings."""
        # These would normally trigger findings (.env, backup.sql)
        results = [
            {"url": "http://api.example.com/.env", "status": 403, "length": 23},
            {"url": "http://api.example.com/backup.sql", "status": 403, "length": 23},
            {"url": "http://api.example.com/.git/config", "status": 403, "length": 23},
        ] + [
            {
                "url": f"http://api.example.com/{word}",
                "status": 403,
                "length": 23,
            }
            for word in [f"word{i}" for i in range(20)]
        ]
        log_content = create_ffuf_json_output(
            results, target="http://api.example.com/FUZZ"
        )

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write(log_content)
            log_path = f.name

        try:
            with patch(
                "souleyez.engine.result_handler.detect_tool_error", return_value=None
            ):
                with patch("souleyez.storage.web_paths.WebPathsManager"):
                    job = {"target": "http://api.example.com/FUZZ"}
                    result = handler.parse_job(1, log_path, job, **mock_managers)

                    assert result["uniform_detected"] is True
                    assert result["findings_added"] == 0
                    # add_finding should never be called
                    mock_managers["findings_manager"].add_finding.assert_not_called()
        finally:
            os.unlink(log_path)

    def test_detect_uniform_responses_method(self, handler):
        """Direct unit test of _detect_uniform_responses()."""
        # 15 uniform + 2 outliers
        paths = [
            {"status_code": 403, "size": 23, "url": f"http://x.com/{i}"}
            for i in range(15)
        ] + [
            {"status_code": 200, "size": 500, "url": "http://x.com/real1"},
            {"status_code": 301, "size": 169, "url": "http://x.com/real2"},
        ]

        detected, sigs, filtered, removed = handler._detect_uniform_responses(paths)

        assert detected is True
        assert (403, 23) in sigs
        assert removed == 15
        assert len(filtered) == 2
        assert all(p["status_code"] != 403 for p in filtered)

    def test_detect_uniform_empty_paths(self, handler):
        """Empty paths list should return no detection."""
        detected, sigs, filtered, removed = handler._detect_uniform_responses([])

        assert detected is False
        assert sigs == []
        assert filtered == []
        assert removed == 0
