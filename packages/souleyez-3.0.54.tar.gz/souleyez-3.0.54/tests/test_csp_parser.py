#!/usr/bin/env python3
"""
Tests for CSP (Content-Security-Policy) parsing in http_fingerprint_parser.

Covers parse_csp_header, extract_csp_from_headers, and the integration
into parse_http_fingerprint_output (csp field on the result dict).
"""

from souleyez.parsers.http_fingerprint_parser import (
    extract_csp_from_headers, parse_csp_header, parse_http_fingerprint_output)

# =============================================================================
# parse_csp_header
# =============================================================================


def test_empty_input_returns_empty_structure():
    result = parse_csp_header("")
    assert result == {"directives": {}, "domains": [], "security_issues": []}

    result = parse_csp_header("   ")
    assert result["directives"] == {}
    assert result["domains"] == []
    assert result["security_issues"] == []


def test_simple_default_src_self():
    result = parse_csp_header("default-src 'self'")
    assert result["directives"] == {"default-src": ["'self'"]}
    assert result["domains"] == []
    assert result["security_issues"] == []


def test_extracts_plain_domain():
    result = parse_csp_header("script-src 'self' https://cdn.example.com")
    domains = [d["domain"] for d in result["domains"]]
    assert "cdn.example.com" in domains


def test_strips_scheme_port_and_path():
    result = parse_csp_header("connect-src https://api.example.com:8443/v1/endpoint")
    domains = [d["domain"] for d in result["domains"]]
    assert "api.example.com" in domains


def test_classifies_s3_bucket():
    result = parse_csp_header("img-src https://my-bucket.s3.us-east-1.amazonaws.com")
    entry = next(
        d
        for d in result["domains"]
        if d["domain"] == "my-bucket.s3.us-east-1.amazonaws.com"
    )
    assert entry["infra_type"] == "s3_bucket"


def test_classifies_api_gateway():
    result = parse_csp_header(
        "connect-src https://abc123.execute-api.us-west-2.amazonaws.com"
    )
    entry = result["domains"][0]
    assert entry["infra_type"] == "api_gateway"


def test_classifies_cdns():
    cases = [
        ("https://d111111.cloudfront.net", "cdn_cloudfront"),
        ("https://assets.cloudflare.com", "cdn_cloudflare"),
        ("https://cdn.akamaized.net", "cdn_akamai"),
        ("https://cdn.fastly.net", "cdn_fastly"),
        ("https://cdn.azureedge.net", "cdn_azure"),
    ]
    for src, expected in cases:
        result = parse_csp_header(f"script-src {src}")
        assert (
            result["domains"][0]["infra_type"] == expected
        ), f"Expected {expected} for {src}"


def test_classifies_google_apis_and_sentry():
    result = parse_csp_header(
        "script-src https://maps.googleapis.com https://sentry.io"
    )
    types = {d["domain"]: d["infra_type"] for d in result["domains"]}
    assert types["maps.googleapis.com"] == "google_api"
    assert types["sentry.io"] == "error_tracking"


def test_wildcard_subdomain_preserved_with_base_domain():
    result = parse_csp_header("script-src *.example.com")
    entry = result["domains"][0]
    assert entry["domain"] == "*.example.com"
    assert entry["base_domain"] == "example.com"


def test_unsafe_inline_in_script_src_flagged():
    result = parse_csp_header("script-src 'self' 'unsafe-inline'")
    issues = [i["issue"] for i in result["security_issues"]]
    assert any("unsafe-inline in script-src" in i for i in issues)


def test_unsafe_eval_in_script_src_flagged():
    result = parse_csp_header("script-src 'self' 'unsafe-eval'")
    issues = [i["issue"] for i in result["security_issues"]]
    assert any("unsafe-eval in script-src" in i for i in issues)


def test_unsafe_inline_in_style_src_flagged_low():
    result = parse_csp_header("style-src 'self' 'unsafe-inline'")
    issue = next(i for i in result["security_issues"] if "style-src" in i["issue"])
    assert issue["severity"] == "low"


def test_bare_wildcard_flagged():
    result = parse_csp_header("img-src *")
    issues = [i["issue"] for i in result["security_issues"]]
    assert any("bare wildcard" in i and "img-src" in i for i in issues)
    # Bare * should not also produce a domain entry
    assert result["domains"] == []


def test_skips_csp_keywords_as_domains():
    result = parse_csp_header(
        "default-src 'self' 'none' 'unsafe-inline' 'unsafe-eval' " "data: blob:"
    )
    assert result["domains"] == []


def test_skips_nonces_and_hashes():
    result = parse_csp_header("script-src 'nonce-abc123' 'sha256-AAAA' 'sha384-BBBB'")
    assert result["domains"] == []


def test_multiple_directives_parsed():
    csp = (
        "default-src 'self'; "
        "script-src 'self' https://cdn.example.com; "
        "img-src 'self' data: https://images.example.com"
    )
    result = parse_csp_header(csp)
    assert "default-src" in result["directives"]
    assert "script-src" in result["directives"]
    assert "img-src" in result["directives"]
    domains = {d["domain"] for d in result["domains"]}
    assert "cdn.example.com" in domains
    assert "images.example.com" in domains


def test_report_uri_directive_does_not_extract_domains():
    # report-uri is a path/URI directive; we skip domain extraction for it
    # to avoid noise. The directive itself is still recorded.
    result = parse_csp_header(
        "default-src 'self'; report-uri https://csp-report.example.com/"
    )
    assert "report-uri" in result["directives"]
    domains = [d["domain"] for d in result["domains"]]
    assert "csp-report.example.com" not in domains


def test_dedup_within_same_directive():
    # Same domain appearing twice in the same directive is deduplicated
    csp = "script-src https://cdn.example.com https://cdn.example.com"
    result = parse_csp_header(csp)
    cdn_count = sum(1 for d in result["domains"] if d["domain"] == "cdn.example.com")
    assert cdn_count == 1


# =============================================================================
# extract_csp_from_headers
# =============================================================================


def test_extract_returns_none_for_empty_headers():
    assert extract_csp_from_headers({}) is None
    assert extract_csp_from_headers(None) is None


def test_extract_returns_none_when_no_csp_header():
    assert extract_csp_from_headers({"Server": "nginx"}) is None


def test_extract_case_insensitive_header_name():
    headers = {"content-security-policy": "default-src 'self'"}
    result = extract_csp_from_headers(headers)
    assert result is not None
    assert "enforced" in result

    headers = {"Content-Security-Policy": "default-src 'self'"}
    assert extract_csp_from_headers(headers) is not None

    headers = {"CONTENT-SECURITY-POLICY": "default-src 'self'"}
    assert extract_csp_from_headers(headers) is not None


def test_extract_report_only_header():
    headers = {
        "Content-Security-Policy-Report-Only": (
            "default-src 'self'; script-src https://cdn.example.com"
        )
    }
    result = extract_csp_from_headers(headers)
    assert result is not None
    assert "report_only" in result
    assert "enforced" not in result
    domains = [d["domain"] for d in result["report_only"]["domains"]]
    assert "cdn.example.com" in domains


def test_extract_both_enforced_and_report_only():
    headers = {
        "Content-Security-Policy": "default-src 'self'",
        "Content-Security-Policy-Report-Only": (
            "default-src 'self' https://example.com"
        ),
    }
    result = extract_csp_from_headers(headers)
    assert "enforced" in result
    assert "report_only" in result


# =============================================================================
# Integration: parse_http_fingerprint_output populates csp field
# =============================================================================


def test_parse_output_with_json_block_includes_csp():
    output = """
=== JSON_RESULT ===
{
  "headers": {
    "Server": "nginx",
    "Content-Security-Policy": "default-src 'self'; script-src https://cdn.example.com"
  }
}
=== END_JSON_RESULT ===
"""
    result = parse_http_fingerprint_output(output, "https://target.example")
    assert result["csp"] is not None
    assert "enforced" in result["csp"]
    domains = [d["domain"] for d in result["csp"]["enforced"]["domains"]]
    assert "cdn.example.com" in domains


def test_parse_output_without_csp_header_has_none():
    output = """
=== JSON_RESULT ===
{"headers": {"Server": "nginx"}}
=== END_JSON_RESULT ===
"""
    result = parse_http_fingerprint_output(output, "https://target.example")
    assert result["csp"] is None


def test_parse_output_text_mode_csp_defaults_none():
    # Text-mode output never carries headers; csp should default to None
    output = "HTTP Status: 200\nServer: nginx\n"
    result = parse_http_fingerprint_output(output, "https://target.example")
    assert result["csp"] is None


# =============================================================================
# result_handler glue: _csp_infra_to_osint_type
# =============================================================================


def test_infra_type_to_osint_type_mapping():
    from souleyez.engine.result_handler import _csp_infra_to_osint_type

    # Specific infra types map to specialized OSINT types
    assert _csp_infra_to_osint_type("s3_bucket") == "csp_s3_bucket"
    assert _csp_infra_to_osint_type("api_gateway") == "csp_api_gateway"
    assert _csp_infra_to_osint_type("cdn_cloudfront") == "csp_cdn"
    assert _csp_infra_to_osint_type("cdn_cloudflare") == "csp_cdn"
    assert _csp_infra_to_osint_type("cdn_akamai") == "csp_cdn"
    assert _csp_infra_to_osint_type("cdn_fastly") == "csp_cdn"
    assert _csp_infra_to_osint_type("cdn_azure") == "csp_cdn"
    assert _csp_infra_to_osint_type("google_api") == "csp_service"
    assert _csp_infra_to_osint_type("error_tracking") == "csp_service"

    # Unknown / generic / None all fall back to plain csp_domain
    assert _csp_infra_to_osint_type("domain") == "csp_domain"
    assert _csp_infra_to_osint_type("") == "csp_domain"
    assert _csp_infra_to_osint_type(None) == "csp_domain"
    assert _csp_infra_to_osint_type("totally_unknown") == "csp_domain"


# =============================================================================
# result_handler glue: _csp_issue_to_finding
# =============================================================================


def test_unsafe_inline_script_src_maps_to_finding():
    from souleyez.engine.result_handler import _csp_issue_to_finding

    spec = _csp_issue_to_finding(
        {
            "issue": "unsafe-inline in script-src",
            "severity": "medium",
            "directive": "script-src",
        }
    )
    assert spec is not None
    assert spec["title"] == "CSP allows 'unsafe-inline' in script-src"
    assert spec["severity"] == "medium"
    assert "XSS" in spec["description"]


def test_unsafe_eval_script_src_maps_to_finding():
    from souleyez.engine.result_handler import _csp_issue_to_finding

    spec = _csp_issue_to_finding(
        {
            "issue": "unsafe-eval in script-src",
            "severity": "medium",
            "directive": "script-src",
        }
    )
    assert spec is not None
    assert spec["title"] == "CSP allows 'unsafe-eval' in script-src"
    assert spec["severity"] == "medium"
    assert "eval" in spec["description"].lower()


def test_unsafe_inline_style_src_maps_to_low_finding():
    from souleyez.engine.result_handler import _csp_issue_to_finding

    spec = _csp_issue_to_finding(
        {
            "issue": "unsafe-inline in style-src",
            "severity": "low",
            "directive": "style-src",
        }
    )
    assert spec is not None
    assert spec["title"] == "CSP allows 'unsafe-inline' in style-src"
    assert spec["severity"] == "low"


def test_bare_wildcard_includes_directive_in_title():
    from souleyez.engine.result_handler import _csp_issue_to_finding

    spec = _csp_issue_to_finding(
        {
            "issue": "bare wildcard (*) in img-src",
            "severity": "low",
            "directive": "img-src",
        }
    )
    assert spec is not None
    assert "img-src" in spec["title"]
    assert "*" in spec["title"]
    assert spec["severity"] == "low"

    spec2 = _csp_issue_to_finding(
        {
            "issue": "bare wildcard (*) in default-src",
            "severity": "low",
            "directive": "default-src",
        }
    )
    assert spec2 is not None
    assert "default-src" in spec2["title"]
    assert spec["title"] != spec2["title"]


def test_unknown_issue_returns_none():
    from souleyez.engine.result_handler import _csp_issue_to_finding

    assert (
        _csp_issue_to_finding(
            {
                "issue": "some-future-issue-pattern",
                "severity": "info",
                "directive": "default-src",
            }
        )
        is None
    )
    assert _csp_issue_to_finding({}) is None


def test_csp_issue_titles_are_distinct_for_dedup():
    """Findings dedupe by title; ensure each issue category has a unique title."""
    from souleyez.engine.result_handler import _csp_issue_to_finding

    titles = set()
    for issue in (
        {
            "issue": "unsafe-inline in script-src",
            "severity": "medium",
            "directive": "script-src",
        },
        {
            "issue": "unsafe-eval in script-src",
            "severity": "medium",
            "directive": "script-src",
        },
        {
            "issue": "unsafe-inline in style-src",
            "severity": "low",
            "directive": "style-src",
        },
        {
            "issue": "bare wildcard (*) in default-src",
            "severity": "low",
            "directive": "default-src",
        },
    ):
        spec = _csp_issue_to_finding(issue)
        titles.add(spec["title"])
    assert len(titles) == 4
