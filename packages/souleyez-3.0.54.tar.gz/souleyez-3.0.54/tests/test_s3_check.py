#!/usr/bin/env python3
"""
Tests for s3_check plugin and handler.

Covers region parsing, HEAD/LIST classification, severity mapping,
and the scope-guard helpers used by the chain trigger.
"""

import json
import os
import re
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from souleyez.plugins.s3_check import (S3CheckPlugin, _classify_listing,
                                       parse_bucket_target)

# =============================================================================
# Region/bucket parsing
# =============================================================================


def test_parse_dotted_region():
    bucket, region = parse_bucket_target("my-bucket.s3.us-west-2.amazonaws.com")
    assert bucket == "my-bucket"
    assert region == "us-west-2"


def test_parse_dash_region_legacy():
    bucket, region = parse_bucket_target("foo.s3-eu-west-1.amazonaws.com")
    assert bucket == "foo"
    assert region == "eu-west-1"


def test_parse_legacy_us_east_1():
    bucket, region = parse_bucket_target("foo.s3.amazonaws.com")
    assert bucket == "foo"
    assert region == "us-east-1"


def test_parse_with_scheme_and_path():
    bucket, region = parse_bucket_target(
        "https://my-bucket.s3.us-east-1.amazonaws.com/some/object"
    )
    assert bucket == "my-bucket"
    assert region == "us-east-1"


def test_parse_non_s3_returns_none():
    assert parse_bucket_target("example.com") is None
    assert parse_bucket_target("https://app.freshpaint.io") is None
    assert parse_bucket_target("") is None
    assert parse_bucket_target(None) is None


# =============================================================================
# Listing XML parsing
# =============================================================================


def test_classify_listing_extracts_keys():
    body = """<?xml version="1.0" encoding="UTF-8"?>
<ListBucketResult>
  <Contents><Key>secret.txt</Key></Contents>
  <Contents><Key>backup.zip</Key></Contents>
  <Contents><Key>logs/2026.log</Key></Contents>
</ListBucketResult>
"""
    count, sample = _classify_listing(body)
    assert count == 3
    assert sample == ["secret.txt", "backup.zip", "logs/2026.log"]


def test_classify_listing_empty_body():
    assert _classify_listing("") == (0, [])
    assert _classify_listing(None) == (0, [])


def test_classify_listing_caps_sample_at_5():
    body = "".join(f"<Key>k{i}</Key>" for i in range(10))
    count, sample = _classify_listing(body)
    assert count == 10
    assert len(sample) == 5
    assert sample[0] == "k0"


# =============================================================================
# Plugin run() — mocked HTTP
# =============================================================================


def _make_mock_response(status_code, headers=None, text=""):
    resp = MagicMock()
    resp.status_code = status_code
    resp.headers = headers or {}
    resp.text = text
    return resp


@pytest.fixture
def temp_log():
    fd, path = tempfile.mkstemp(suffix=".log")
    os.close(fd)
    yield path
    if os.path.exists(path):
        os.unlink(path)


def _read_json_result(log_path):
    with open(log_path) as f:
        text = f.read()
    m = re.search(
        r"=== JSON_RESULT ===\n(.+?)\n=== END_JSON_RESULT ===",
        text,
        re.DOTALL,
    )
    assert m, f"No JSON_RESULT block in log: {text!r}"
    return json.loads(m.group(1))


def test_run_unparseable_target_writes_error(temp_log):
    plugin = S3CheckPlugin()
    rc = plugin.run("not-an-s3-bucket.example.com", log_path=temp_log)
    assert rc == 0
    parsed = _read_json_result(temp_log)
    assert parsed["bucket"] is None
    assert parsed["error"] is not None
    assert "S3" in parsed["error"]


def test_run_403_private_bucket(temp_log):
    plugin = S3CheckPlugin()
    with patch("souleyez.plugins.s3_check.requests") as mock_req:
        mock_req.head.return_value = _make_mock_response(403)
        plugin.run("private-bucket.s3.amazonaws.com", log_path=temp_log)
    parsed = _read_json_result(temp_log)
    assert parsed["bucket"] == "private-bucket"
    assert parsed["region"] == "us-east-1"
    assert parsed["head_status"] == 403
    assert parsed["public"] is False
    assert parsed["listable"] is False


def test_run_404_stale_reference(temp_log):
    plugin = S3CheckPlugin()
    with patch("souleyez.plugins.s3_check.requests") as mock_req:
        mock_req.head.return_value = _make_mock_response(404)
        plugin.run("stale-bucket.s3.us-west-2.amazonaws.com", log_path=temp_log)
    parsed = _read_json_result(temp_log)
    assert parsed["head_status"] == 404
    assert parsed["public"] is False
    assert "does not exist" in parsed["error"].lower()


def test_run_301_wrong_region_with_hint(temp_log):
    plugin = S3CheckPlugin()
    with patch("souleyez.plugins.s3_check.requests") as mock_req:
        mock_req.head.return_value = _make_mock_response(
            301, headers={"x-amz-bucket-region": "eu-west-1"}
        )
        plugin.run("misplaced.s3.us-east-1.amazonaws.com", log_path=temp_log)
    parsed = _read_json_result(temp_log)
    assert parsed["head_status"] == 301
    assert "eu-west-1" in parsed["error"]


def test_run_200_publicly_listable_with_objects(temp_log):
    plugin = S3CheckPlugin()
    list_body = "<ListBucketResult><Contents><Key>a</Key></Contents><Contents><Key>b</Key></Contents></ListBucketResult>"
    with patch("souleyez.plugins.s3_check.requests") as mock_req:
        mock_req.head.return_value = _make_mock_response(200)
        mock_req.get.return_value = _make_mock_response(200, text=list_body)
        plugin.run("open-bucket.s3.amazonaws.com", log_path=temp_log)
    parsed = _read_json_result(temp_log)
    assert parsed["public"] is True
    assert parsed["listable"] is True
    assert parsed["object_count"] == 2
    assert parsed["sample_keys"] == ["a", "b"]


def test_run_200_listable_but_empty(temp_log):
    plugin = S3CheckPlugin()
    list_body = "<ListBucketResult></ListBucketResult>"
    with patch("souleyez.plugins.s3_check.requests") as mock_req:
        mock_req.head.return_value = _make_mock_response(200)
        mock_req.get.return_value = _make_mock_response(200, text=list_body)
        plugin.run("empty-bucket.s3.amazonaws.com", log_path=temp_log)
    parsed = _read_json_result(temp_log)
    assert parsed["public"] is True
    assert parsed["listable"] is True
    assert parsed["object_count"] == 0


def test_run_200_public_but_not_listable(temp_log):
    plugin = S3CheckPlugin()
    with patch("souleyez.plugins.s3_check.requests") as mock_req:
        mock_req.head.return_value = _make_mock_response(200)
        mock_req.get.return_value = _make_mock_response(403)
        plugin.run("public-no-list.s3.amazonaws.com", log_path=temp_log)
    parsed = _read_json_result(temp_log)
    assert parsed["public"] is True
    assert parsed["listable"] is False
    assert parsed["list_status"] == 403


def test_run_timeout_propagates_as_error(temp_log):
    plugin = S3CheckPlugin()
    with patch("souleyez.plugins.s3_check.requests") as mock_req:

        class _Timeout(Exception):
            pass

        # Use real exception class so our except-clause matches
        import requests

        mock_req.head.side_effect = requests.Timeout("boom")
        mock_req.Timeout = requests.Timeout
        mock_req.RequestException = requests.RequestException
        plugin.run("slow.s3.amazonaws.com", log_path=temp_log, args=["--timeout", "2"])
    parsed = _read_json_result(temp_log)
    assert parsed["error"] is not None
    assert "timed out" in parsed["error"].lower()


# =============================================================================
# Scope guard helpers used by chain trigger
# =============================================================================


def test_scope_label_strips_subdomains():
    from souleyez.core.tool_chaining import _s3_scope_label

    assert _s3_scope_label("app.freshpaint.io") == "freshpaint"
    assert _s3_scope_label("freshpaint.io") == "freshpaint"
    assert _s3_scope_label("a.b.c.example.co.uk") == "co"  # crude, second-to-last
    assert _s3_scope_label("") == ""
    assert _s3_scope_label(None) == ""


def test_bucket_in_scope_matches_target_label():
    from souleyez.core.tool_chaining import _bucket_in_scope

    # Bucket subdomain contains the target label -> in scope
    assert _bucket_in_scope("freshpaint-prod.s3.amazonaws.com", "freshpaint") is True
    assert _bucket_in_scope("uploads-freshpaint.s3.amazonaws.com", "freshpaint") is True

    # Unrelated third-party bucket -> out of scope
    assert _bucket_in_scope("cloudflare-cdn.s3.amazonaws.com", "freshpaint") is False
    assert (
        _bucket_in_scope("acme-assets.s3.us-west-2.amazonaws.com", "freshpaint")
        is False
    )


def test_bucket_in_scope_safety_for_short_labels():
    from souleyez.core.tool_chaining import _bucket_in_scope

    # 2-character target label is too short to be a useful filter; reject.
    assert _bucket_in_scope("anything.s3.amazonaws.com", "io") is False
    assert _bucket_in_scope("anything.s3.amazonaws.com", "") is False


# =============================================================================
# Handler severity mapping
# =============================================================================


def _build_log(result):
    fd, path = tempfile.mkstemp(suffix=".log")
    with os.fdopen(fd, "w") as f:
        f.write("=== Plugin: S3 Check ===\n")
        f.write("=== JSON_RESULT ===\n")
        f.write(json.dumps(result))
        f.write("\n=== END_JSON_RESULT ===\n")
    return path


def _run_handler_with_result(result):
    """
    Drive the handler against a synthetic plugin log. Mocks the host /
    findings managers so we can assert the severity and title chosen.
    """
    from souleyez.handlers.s3_check_handler import S3CheckHandler

    log_path = _build_log(result)
    try:
        handler = S3CheckHandler()
        host_mgr = MagicMock()
        host_mgr.add_or_update_host.return_value = {"id": 42}
        host_mgr.get_host_by_ip.return_value = {"id": 42}
        findings_mgr = MagicMock()
        findings_mgr.add_finding.return_value = 100

        parse_result = handler.parse_job(
            engagement_id=1,
            log_path=log_path,
            job={"target": "https://x.s3.amazonaws.com"},
            host_manager=host_mgr,
            findings_manager=findings_mgr,
        )
        return parse_result, findings_mgr
    finally:
        os.unlink(log_path)


def test_handler_critical_when_listable_with_objects():
    result = {
        "target": "x",
        "bucket": "open-bucket",
        "region": "us-east-1",
        "head_status": 200,
        "list_status": 200,
        "public": True,
        "listable": True,
        "object_count": 42,
        "sample_keys": ["a", "b"],
    }
    parse_result, fm = _run_handler_with_result(result)
    assert parse_result["status"] == "done"
    assert parse_result["findings_added"] == 1
    fm.add_finding.assert_called_once()
    kwargs = fm.add_finding.call_args.kwargs
    assert kwargs["severity"] == "critical"
    assert "42" in kwargs["title"]
    assert kwargs["finding_type"] == "s3_misconfiguration"


def test_handler_high_when_listable_empty():
    result = {
        "target": "x",
        "bucket": "empty-bucket",
        "region": "us-east-1",
        "head_status": 200,
        "list_status": 200,
        "public": True,
        "listable": True,
        "object_count": 0,
        "sample_keys": [],
    }
    _, fm = _run_handler_with_result(result)
    assert fm.add_finding.call_args.kwargs["severity"] == "high"


def test_handler_medium_when_public_not_listable():
    result = {
        "target": "x",
        "bucket": "public-no-list",
        "region": "us-east-1",
        "head_status": 200,
        "list_status": 403,
        "public": True,
        "listable": False,
        "object_count": 0,
    }
    _, fm = _run_handler_with_result(result)
    assert fm.add_finding.call_args.kwargs["severity"] == "medium"


def test_handler_no_finding_for_403_private():
    result = {
        "target": "x",
        "bucket": "private-bucket",
        "region": "us-east-1",
        "head_status": 403,
        "list_status": None,
        "public": False,
        "listable": False,
        "object_count": 0,
    }
    parse_result, fm = _run_handler_with_result(result)
    assert parse_result["status"] == "no_results"
    fm.add_finding.assert_not_called()


def test_handler_warning_for_404_stale():
    result = {
        "target": "x",
        "bucket": "stale",
        "region": "us-east-1",
        "head_status": 404,
        "list_status": None,
        "public": False,
        "listable": False,
        "object_count": 0,
        "error": "Bucket does not exist (HTTP 404)",
    }
    parse_result, fm = _run_handler_with_result(result)
    assert parse_result["status"] == "warning"
    fm.add_finding.assert_not_called()
