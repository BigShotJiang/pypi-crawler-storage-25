"""
CDN/Cloud provider IP ranges for filtering.

These are shared infrastructure IPs that should be skipped when auto-chaining
nmap scans from OSINT tools like theHarvester. Scanning CDN IPs yields no
useful results as they're shared infrastructure serving thousands of websites.

Last updated: 2026-02-04

Sources:
- AWS: https://ip-ranges.amazonaws.com/ip-ranges.json (CLOUDFRONT service)
- CloudFlare: https://www.cloudflare.com/ips/
- Akamai: Common ranges (dynamic, approximated)
- Fastly: https://api.fastly.com/public-ip-list
"""

# AWS CloudFront IP ranges
# These are published by AWS and updated periodically
AWS_CLOUDFRONT_RANGES = [
    # Global edge locations
    "3.160.0.0/14",
    "3.164.0.0/18",
    "13.32.0.0/15",
    "13.35.0.0/16",
    "13.224.0.0/14",
    "13.249.0.0/16",
    "15.158.0.0/16",
    "15.160.0.0/16",
    "15.161.0.0/16",
    "18.64.0.0/14",
    "18.68.0.0/16",
    "18.154.0.0/15",
    "18.160.0.0/15",
    "18.164.0.0/15",
    "52.46.0.0/18",
    "52.84.0.0/15",
    "52.222.0.0/17",
    "54.182.0.0/16",
    "54.192.0.0/16",
    "54.230.0.0/17",
    "54.239.128.0/18",
    "54.239.192.0/19",
    "64.252.64.0/18",
    "64.252.128.0/18",
    "65.8.0.0/16",
    "65.9.0.0/17",
    "70.132.0.0/18",
    "99.84.0.0/16",
    "99.86.0.0/16",
    "108.138.0.0/15",
    "108.156.0.0/14",
    "116.129.226.0/25",
    "120.52.22.96/27",
    "130.176.0.0/17",
    "143.204.0.0/16",
    "144.220.0.0/16",
    "204.246.164.0/22",
    "204.246.168.0/22",
    "205.251.200.0/21",
    "205.251.249.0/24",
    "205.251.250.0/23",
    "205.251.252.0/23",
    "205.251.254.0/24",
]

# CloudFlare IP ranges
# Published at https://www.cloudflare.com/ips/
CLOUDFLARE_RANGES = [
    # IPv4 ranges
    "103.21.244.0/22",
    "103.22.200.0/22",
    "103.31.4.0/22",
    "104.16.0.0/13",
    "104.24.0.0/14",
    "108.162.192.0/18",
    "131.0.72.0/22",
    "141.101.64.0/18",
    "162.158.0.0/15",
    "172.64.0.0/13",
    "173.245.48.0/20",
    "188.114.96.0/20",
    "190.93.240.0/20",
    "197.234.240.0/22",
    "198.41.128.0/17",
]

# Akamai IP ranges
# Akamai uses dynamic IP allocation - these are common ranges
# Note: Akamai ranges change frequently, this is an approximation
AKAMAI_RANGES = [
    "23.32.0.0/11",
    "23.192.0.0/11",
    "72.246.0.0/15",
    "96.16.0.0/15",
    "104.64.0.0/10",
    "184.24.0.0/13",
    "184.50.0.0/15",
    "184.84.0.0/14",
]

# Fastly IP ranges
# Published at https://api.fastly.com/public-ip-list
FASTLY_RANGES = [
    "23.235.32.0/20",
    "43.249.72.0/22",
    "103.244.50.0/24",
    "103.245.222.0/23",
    "103.245.224.0/24",
    "104.156.80.0/20",
    "140.248.64.0/18",
    "140.248.128.0/17",
    "146.75.0.0/17",
    "151.101.0.0/16",
    "157.52.64.0/18",
    "167.82.0.0/17",
    "167.82.128.0/20",
    "167.82.160.0/20",
    "167.82.224.0/20",
    "172.111.64.0/18",
    "185.31.16.0/22",
    "199.27.72.0/21",
    "199.232.0.0/16",
]

# Google Cloud CDN / GCP ranges (common)
GOOGLE_CDN_RANGES = [
    "34.64.0.0/10",
    "35.184.0.0/13",
    "35.192.0.0/14",
    "35.196.0.0/15",
    "35.198.0.0/16",
    "35.199.0.0/17",
    "35.199.128.0/18",
    "35.200.0.0/13",
    "35.208.0.0/12",
    "35.224.0.0/12",
    "35.240.0.0/13",
]

# Azure CDN / Front Door ranges (common)
AZURE_CDN_RANGES = [
    "13.107.246.0/24",
    "13.107.247.0/24",
    "147.243.0.0/16",
]

# Combined list for easy iteration
ALL_CDN_RANGES = (
    AWS_CLOUDFRONT_RANGES
    + CLOUDFLARE_RANGES
    + AKAMAI_RANGES
    + FASTLY_RANGES
    + GOOGLE_CDN_RANGES
    + AZURE_CDN_RANGES
)
