#!/usr/bin/env python3
"""
souleyez.storage.api_endpoints - API endpoint discovery management

Stores API endpoints detected by http_fingerprint including:
- GraphQL endpoints (with introspection status)
- REST APIs
- OpenAPI/Swagger specifications
"""

import json
from typing import Any, Dict, List, Optional

from .database import get_db


class ApiEndpointsManager:
    """Manages discovered API endpoints in the database."""

    def __init__(self):
        self.db = get_db()

    def add_api_endpoint(
        self,
        engagement_id: int,
        host_id: int,
        url: str,
        path: str = None,
        api_type: str = "unknown",
        status_code: int = None,
        confirmed: bool = False,
        introspection_enabled: bool = False,
        auth_methods: List[str] = None,
        details_json: Dict = None,
        tool: str = "http_fingerprint",
    ) -> int:
        """
        Add an API endpoint to the database.

        Args:
            engagement_id: Associated engagement ID
            host_id: Associated host ID
            url: Full URL of the API endpoint
            path: Path component (e.g., /api/v1, /graphql)
            api_type: Type of API (graphql, rest, openapi, swagger)
            status_code: HTTP status code when probed
            confirmed: Whether the API was confirmed (vs just detected path)
            introspection_enabled: For GraphQL, whether introspection is enabled
            auth_methods: List of auth methods detected (jwt, bearer, api_key, etc.)
            details_json: Full details dict (schema, endpoints, parameters)
            tool: Tool that discovered this endpoint

        Returns:
            API endpoint ID
        """
        # Serialize JSON fields
        auth_methods_str = json.dumps(auth_methods) if auth_methods else None
        details_str = json.dumps(details_json) if details_json else None

        # Check if this exact endpoint already exists
        existing = self.db.execute_one(
            "SELECT id FROM api_endpoints WHERE engagement_id = ? AND host_id = ? AND url = ?",
            (engagement_id, host_id, url),
        )

        if existing:
            # Update existing record with new data
            update_data = {
                "api_type": api_type,
                "confirmed": 1 if confirmed else 0,
                "introspection_enabled": 1 if introspection_enabled else 0,
            }
            if status_code is not None:
                update_data["status_code"] = status_code
            if path:
                update_data["path"] = path
            if auth_methods_str:
                update_data["auth_methods"] = auth_methods_str
            if details_str:
                update_data["details_json"] = details_str

            set_clause = ", ".join([f"{k} = ?" for k in update_data.keys()])
            values = list(update_data.values()) + [existing["id"]]
            self.db.execute(
                f"UPDATE api_endpoints SET {set_clause} WHERE id = ?", tuple(values)
            )
            return existing["id"]

        # Insert new endpoint
        data = {
            "engagement_id": engagement_id,
            "host_id": host_id,
            "url": url,
            "api_type": api_type,
            "confirmed": 1 if confirmed else 0,
            "introspection_enabled": 1 if introspection_enabled else 0,
            "tool": tool,
        }

        if path:
            data["path"] = path
        if status_code is not None:
            data["status_code"] = status_code
        if auth_methods_str:
            data["auth_methods"] = auth_methods_str
        if details_str:
            data["details_json"] = details_str

        return self.db.insert("api_endpoints", data)

    def bulk_add_api_endpoints(
        self,
        engagement_id: int,
        host_id: int,
        endpoints: List[Dict[str, Any]],
        tool: str = "http_fingerprint",
    ) -> int:
        """
        Add multiple API endpoints for a host.

        Args:
            engagement_id: Associated engagement ID
            host_id: Associated host ID
            endpoints: List of endpoint dicts from http_fingerprint parser
            tool: Tool that discovered these endpoints

        Returns:
            Number of new endpoints added
        """
        count = 0
        for endpoint in endpoints:
            details = endpoint.get("details") or {}
            existing = self.db.execute_one(
                "SELECT id FROM api_endpoints WHERE engagement_id = ? AND host_id = ? AND url = ?",
                (engagement_id, host_id, endpoint.get("url", "")),
            )
            if not existing:
                self.add_api_endpoint(
                    engagement_id=engagement_id,
                    host_id=host_id,
                    url=endpoint.get("url", ""),
                    path=endpoint.get("path", ""),
                    api_type=endpoint.get("type", "unknown"),
                    status_code=endpoint.get("status_code"),
                    confirmed=endpoint.get("confirmed", False),
                    introspection_enabled=details.get("introspection_enabled", False),
                    auth_methods=details.get("auth_methods", []),
                    details_json=details,
                    tool=tool,
                )
                count += 1
        return count

    def get_api_endpoint(self, endpoint_id: int) -> Optional[Dict[str, Any]]:
        """Get an API endpoint by ID."""
        query = "SELECT * FROM api_endpoints WHERE id = ?"
        result = self.db.execute_one(query, (endpoint_id,))
        if result:
            return self._deserialize_endpoint(result)
        return None

    def list_api_endpoints(
        self,
        engagement_id: int = None,
        host_id: int = None,
        api_type: str = None,
    ) -> List[Dict[str, Any]]:
        """
        List API endpoints with optional filters.

        Args:
            engagement_id: Filter by engagement ID
            host_id: Filter by host ID
            api_type: Filter by API type (graphql, rest, openapi, etc.)

        Returns:
            List of API endpoint dicts
        """
        if engagement_id:
            query = """
                SELECT ae.*, h.ip_address, h.hostname
                FROM api_endpoints ae
                JOIN hosts h ON ae.host_id = h.id
                WHERE ae.engagement_id = ?
            """
            params = [engagement_id]
        elif host_id:
            query = """
                SELECT ae.*, h.ip_address, h.hostname
                FROM api_endpoints ae
                JOIN hosts h ON ae.host_id = h.id
                WHERE ae.host_id = ?
            """
            params = [host_id]
        else:
            query = """
                SELECT ae.*, h.ip_address, h.hostname
                FROM api_endpoints ae
                JOIN hosts h ON ae.host_id = h.id
                WHERE 1=1
            """
            params = []

        if api_type:
            query += " AND ae.api_type = ?"
            params.append(api_type)

        query += " ORDER BY ae.created_at DESC"

        results = self.db.execute(query, tuple(params))
        return [self._deserialize_endpoint(r) for r in results]

    def get_summary(self, engagement_id: int) -> Dict[str, int]:
        """
        Get summary of API endpoints by type.

        Returns:
            Dict with counts: {'graphql': 2, 'rest': 5, 'openapi': 1, ...}
        """
        query = """
            SELECT api_type, COUNT(*) as count
            FROM api_endpoints
            WHERE engagement_id = ?
            GROUP BY api_type
        """
        results = self.db.execute(query, (engagement_id,))

        summary = {}
        for row in results:
            api_type = row.get("api_type", "unknown")
            count = row.get("count", 0)
            summary[api_type] = count

        return summary

    def get_total_count(self, engagement_id: int) -> int:
        """Get total count of API endpoints for an engagement."""
        query = "SELECT COUNT(*) as cnt FROM api_endpoints WHERE engagement_id = ?"
        result = self.db.execute_one(query, (engagement_id,))
        return result["cnt"] if result else 0

    def delete_api_endpoint(self, endpoint_id: int) -> bool:
        """Delete an API endpoint."""
        try:
            self.db.execute("DELETE FROM api_endpoints WHERE id = ?", (endpoint_id,))
            return True
        except Exception:
            return False

    def _deserialize_endpoint(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Deserialize JSON fields in an endpoint row."""
        result = dict(row)

        # Parse auth_methods JSON
        if result.get("auth_methods"):
            try:
                result["auth_methods"] = json.loads(result["auth_methods"])
            except (json.JSONDecodeError, TypeError):
                result["auth_methods"] = []
        else:
            result["auth_methods"] = []

        # Parse details_json
        if result.get("details_json"):
            try:
                result["details_json"] = json.loads(result["details_json"])
            except (json.JSONDecodeError, TypeError):
                result["details_json"] = {}
        else:
            result["details_json"] = {}

        return result
