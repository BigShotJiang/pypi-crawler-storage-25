"""
Migration 028: Add api_endpoints table for API discovery results.

Stores API endpoints detected by http_fingerprint plugin including
GraphQL, REST, OpenAPI/Swagger endpoints with auth methods and schema details.
"""


def upgrade(db):
    """Add api_endpoints table."""
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS api_endpoints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            engagement_id INTEGER NOT NULL,
            host_id INTEGER NOT NULL,
            url TEXT NOT NULL,
            path TEXT,
            api_type TEXT NOT NULL,
            status_code INTEGER,
            confirmed INTEGER DEFAULT 0,
            introspection_enabled INTEGER DEFAULT 0,
            auth_methods TEXT,
            details_json TEXT,
            tool TEXT DEFAULT 'http_fingerprint',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (engagement_id) REFERENCES engagements(id) ON DELETE CASCADE,
            FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE,
            UNIQUE(engagement_id, host_id, url)
        )
    """
    )

    db.execute(
        "CREATE INDEX IF NOT EXISTS idx_api_endpoints_engagement ON api_endpoints(engagement_id)"
    )
    db.execute(
        "CREATE INDEX IF NOT EXISTS idx_api_endpoints_host ON api_endpoints(host_id)"
    )
    db.execute(
        "CREATE INDEX IF NOT EXISTS idx_api_endpoints_type ON api_endpoints(api_type)"
    )


def downgrade(db):
    """Rollback api_endpoints table."""
    db.execute("DROP TABLE IF EXISTS api_endpoints")
