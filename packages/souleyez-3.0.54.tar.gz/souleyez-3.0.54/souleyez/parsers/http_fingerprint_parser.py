#!/usr/bin/env python3
"""
souleyez.parsers.http_fingerprint_parser

Parses HTTP fingerprint output to extract WAF, CDN, managed hosting,
and technology information.
"""

import json
import re
from typing import Any, Dict, List, Optional


def parse_http_fingerprint_output(output: str, target: str = "") -> Dict[str, Any]:
    """
    Parse HTTP fingerprint output and extract detection results.

    Args:
        output: Raw output from http_fingerprint plugin
        target: Target URL from job

    Returns:
        Dict with structure:
        {
            'target': str,
            'status_code': int,
            'server': str,
            'server_version': str,
            'waf': [str],
            'cdn': [str],
            'managed_hosting': str or None,
            'technologies': [str],
            'tls': {'version': str, 'cipher': str, 'bits': int},
            'headers': {str: str},
            'redirect_url': str or None,
            'error': str or None,
            'csp': dict or None,
        }
    """
    result = {
        "target": target,
        "status_code": None,
        "server": None,
        "server_version": None,
        "waf": [],
        "cdn": [],
        "managed_hosting": None,
        "technologies": [],
        "tls": None,
        "headers": {},
        "redirect_url": None,
        "error": None,
        "csp": None,
    }

    # Try to extract JSON result first (most reliable)
    json_match = re.search(
        r"=== JSON_RESULT ===\n(.+?)\n=== END_JSON_RESULT ===", output, re.DOTALL
    )
    if json_match:
        try:
            json_result = json.loads(json_match.group(1))
            result.update(json_result)
            result["target"] = target or result.get("target", "")
            result["csp"] = extract_csp_from_headers(result.get("headers") or {})
            return result
        except json.JSONDecodeError:
            pass

    # Fall back to parsing text output
    lines = output.split("\n")

    for line in lines:
        line = line.strip()

        # Parse HTTP status
        if line.startswith("HTTP Status:"):
            match = re.search(r"HTTP Status:\s+(\d+)", line)
            if match:
                result["status_code"] = int(match.group(1))

        # Parse server
        elif line.startswith("Server:"):
            result["server"] = line.replace("Server:", "").strip()

        # Parse redirect
        elif line.startswith("Redirected to:"):
            result["redirect_url"] = line.replace("Redirected to:", "").strip()

        # Parse TLS
        elif line.startswith("TLS:"):
            match = re.search(r"TLS:\s+(\S+)\s+\((.+?)\)", line)
            if match:
                result["tls"] = {
                    "version": match.group(1),
                    "cipher": match.group(2),
                }

        # Parse managed hosting
        elif line.startswith("MANAGED HOSTING DETECTED:"):
            result["managed_hosting"] = line.replace(
                "MANAGED HOSTING DETECTED:", ""
            ).strip()

        # Parse WAF (multi-line section)
        elif line.startswith("WAF/Protection Detected:"):
            continue  # Header line, actual entries follow

        # Parse CDN (multi-line section)
        elif line.startswith("CDN Detected:"):
            continue  # Header line, actual entries follow

        # Parse technologies (multi-line section)
        elif line.startswith("Technologies:"):
            continue  # Header line, actual entries follow

        # Parse list items (WAF, CDN, Technologies)
        elif line.startswith("- "):
            item = line[2:].strip()
            # Determine which list this belongs to based on context
            # This is a simple heuristic - JSON parsing is more reliable
            if any(
                waf_keyword in item.lower()
                for waf_keyword in [
                    "waf",
                    "cloudflare",
                    "akamai",
                    "imperva",
                    "sucuri",
                    "f5",
                ]
            ):
                if item not in result["waf"]:
                    result["waf"].append(item)
            elif any(
                cdn_keyword in item.lower()
                for cdn_keyword in ["cdn", "cloudfront", "fastly", "varnish", "edge"]
            ):
                if item not in result["cdn"]:
                    result["cdn"].append(item)
            else:
                if item not in result["technologies"]:
                    result["technologies"].append(item)

        # Parse error
        elif line.startswith("ERROR:"):
            result["error"] = line.replace("ERROR:", "").strip()

    result["csp"] = extract_csp_from_headers(result.get("headers") or {})
    return result


def is_managed_hosting(parsed_data: Dict[str, Any]) -> bool:
    """
    Check if target is a managed hosting platform.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        True if managed hosting platform detected
    """
    return parsed_data.get("managed_hosting") is not None


def get_managed_hosting_platform(parsed_data: Dict[str, Any]) -> Optional[str]:
    """
    Get the name of the managed hosting platform.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        Platform name or None
    """
    return parsed_data.get("managed_hosting")


def has_waf(parsed_data: Dict[str, Any]) -> bool:
    """
    Check if WAF is detected.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        True if WAF detected
    """
    return len(parsed_data.get("waf", [])) > 0


def get_wafs(parsed_data: Dict[str, Any]) -> List[str]:
    """
    Get list of detected WAFs.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        List of WAF names
    """
    return parsed_data.get("waf", [])


def has_cdn(parsed_data: Dict[str, Any]) -> bool:
    """
    Check if CDN is detected.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        True if CDN detected
    """
    return len(parsed_data.get("cdn", [])) > 0


def get_cdns(parsed_data: Dict[str, Any]) -> List[str]:
    """
    Get list of detected CDNs.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        List of CDN names
    """
    return parsed_data.get("cdn", [])


def build_fingerprint_context(parsed_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build context dict for use in tool chaining.

    This is used to pass fingerprint data to downstream tools
    so they can make smarter decisions.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        Context dict for tool chaining
    """
    return {
        "http_fingerprint": {
            "managed_hosting": parsed_data.get("managed_hosting"),
            "waf": parsed_data.get("waf", []),
            "cdn": parsed_data.get("cdn", []),
            "server": parsed_data.get("server"),
            "technologies": parsed_data.get("technologies", []),
            "status_code": parsed_data.get("status_code"),
            "effective_url": parsed_data.get("effective_url"),
            "protocol_detection": parsed_data.get("protocol_detection"),
        }
    }


def get_effective_url(parsed_data: Dict[str, Any], fallback_target: str = "") -> str:
    """
    Get the effective URL from fingerprint results.

    If smart protocol detection upgraded/switched the protocol,
    returns the URL that actually worked. Otherwise returns the original.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()
        fallback_target: URL to use if no effective_url found

    Returns:
        The effective URL for downstream tools to use
    """
    return (
        parsed_data.get("effective_url") or parsed_data.get("target") or fallback_target
    )


def get_tool_recommendations(parsed_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get recommendations for tool configuration based on fingerprint.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        Dict with tool-specific recommendations
    """
    recommendations = {
        "nikto": {
            "skip_cgi": False,
            "extra_args": [],
            "reason": None,
        },
        "nuclei": {
            "extra_args": [],
            "skip_tags": [],
            "reason": None,
        },
        "sqlmap": {
            "tamper_scripts": [],
            "extra_args": [],
            "reason": None,
        },
        "general": {
            "notes": [],
        },
    }

    # Managed hosting recommendations
    if parsed_data.get("managed_hosting"):
        platform = parsed_data["managed_hosting"]
        recommendations["nikto"]["skip_cgi"] = True
        recommendations["nikto"]["extra_args"] = ["-C", "none", "-Tuning", "x6"]
        recommendations["nikto"][
            "reason"
        ] = f"Managed hosting ({platform}) - CGI enumeration skipped"

        recommendations["general"]["notes"].append(
            f"Target is hosted on {platform} - limited vulnerability surface expected"
        )

    # WAF recommendations
    wafs = parsed_data.get("waf", [])
    if wafs:
        waf_list = ", ".join(wafs)
        recommendations["general"]["notes"].append(f"WAF detected: {waf_list}")

        # SQLMap tamper scripts for common WAFs
        for waf in wafs:
            waf_lower = waf.lower()
            if "cloudflare" in waf_lower:
                recommendations["sqlmap"]["tamper_scripts"].extend(
                    ["between", "randomcase", "space2comment"]
                )
            elif "akamai" in waf_lower:
                recommendations["sqlmap"]["tamper_scripts"].extend(
                    ["charencode", "space2plus"]
                )
            elif "imperva" in waf_lower or "incapsula" in waf_lower:
                recommendations["sqlmap"]["tamper_scripts"].extend(
                    ["randomcase", "between"]
                )

        if recommendations["sqlmap"]["tamper_scripts"]:
            # Dedupe
            recommendations["sqlmap"]["tamper_scripts"] = list(
                set(recommendations["sqlmap"]["tamper_scripts"])
            )
            recommendations["sqlmap"][
                "reason"
            ] = f"WAF bypass tamper scripts for {waf_list}"

    # CDN recommendations
    cdns = parsed_data.get("cdn", [])
    if cdns:
        cdn_list = ", ".join(cdns)
        recommendations["general"]["notes"].append(
            f"CDN detected: {cdn_list} - responses may be cached, hitting edge not origin"
        )

    return recommendations


def generate_next_steps(
    parsed_data: Dict[str, Any], target: str = ""
) -> List[Dict[str, Any]]:
    """
    Generate suggested manual next steps based on fingerprint findings.

    Each step includes:
    - title: Short description of what to try
    - command: Example command to run (if applicable)
    - reason: Why this step is suggested

    Args:
        parsed_data: Output from parse_http_fingerprint_output()
        target: Target URL for command examples

    Returns:
        List of next step dicts
    """
    next_steps = []
    target_url = target or parsed_data.get("target", "")

    # Extract base URL for commands
    base_url = target_url.rstrip("/")

    # CGI paths detected - command injection testing
    robots_paths = parsed_data.get("robots_paths", [])
    cgi_paths = [
        p
        for p in robots_paths
        if "/cgi-bin/" in p or p.endswith(".cgi") or p.endswith(".pl")
    ]
    if cgi_paths:
        cgi_example = cgi_paths[0]
        next_steps.append(
            {
                "title": "Test CGI scripts for command injection",
                "commands": [
                    f'curl "{cgi_example}?param=;id"',
                    f'curl "{cgi_example}?param=|id"',
                    f'curl "{cgi_example}?param=`id`"',
                ],
                "reason": f"Found {len(cgi_paths)} CGI script(s) - common command injection targets",
            }
        )
        next_steps.append(
            {
                "title": "Test for Shellshock vulnerability",
                "commands": [
                    f"curl -A '() {{ :; }}; /bin/id' \"{cgi_example}\"",
                    f'curl -H "Cookie: () {{ :; }}; /bin/id" "{cgi_example}"',
                ],
                "reason": "CGI scripts on older systems may be vulnerable to Shellshock (CVE-2014-6271)",
            }
        )

    # Admin panels detected - authentication testing
    admin_panels = parsed_data.get("admin_panels", [])
    if admin_panels:
        admin_url = admin_panels[0].get("url", "")
        next_steps.append(
            {
                "title": "Test admin panel with default credentials",
                "commands": [
                    f'hydra -L users.txt -P passwords.txt {admin_url} http-post-form "/login:user=^USER^&pass=^PASS^:Invalid"',
                ],
                "reason": f"Found {len(admin_panels)} admin panel(s) - try default/common credentials",
            }
        )

    # CMS detected - CMS-specific attacks
    cms_detected = parsed_data.get("cms_detected")
    if cms_detected:
        cms_name = cms_detected.get("name", "").lower()
        if "wordpress" in cms_name:
            next_steps.append(
                {
                    "title": "Enumerate WordPress users and plugins",
                    "commands": [
                        f"wpscan --url {base_url} --enumerate u,p,t",
                        f"wpscan --url {base_url} --passwords data/wordlists/passwords_brute.txt --usernames admin",
                    ],
                    "reason": "WordPress detected - enumerate users, plugins, themes for vulnerabilities",
                }
            )
        elif "joomla" in cms_name:
            next_steps.append(
                {
                    "title": "Enumerate Joomla components",
                    "commands": [
                        f"joomscan -u {base_url}",
                    ],
                    "reason": "Joomla detected - scan for vulnerable components",
                }
            )
        elif "drupal" in cms_name:
            next_steps.append(
                {
                    "title": "Check for Drupalgeddon vulnerabilities",
                    "commands": [
                        f"droopescan scan drupal -u {base_url}",
                    ],
                    "reason": "Drupal detected - check for known vulnerabilities",
                }
            )

    # API endpoints detected - API testing
    api_endpoints = parsed_data.get("api_endpoints", [])
    if api_endpoints:
        api_url = api_endpoints[0].get("url", "")
        next_steps.append(
            {
                "title": "Enumerate API endpoints and test authentication",
                "commands": [
                    f"curl -s {api_url} | jq .",
                    f'ffuf -u "{base_url}/api/FUZZ" -w data/wordlists/api_endpoints_large.txt',
                ],
                "reason": f"Found {len(api_endpoints)} API endpoint(s) - test for auth bypass and injection",
            }
        )

    # Old server version - CVE lookup
    server = parsed_data.get("server", "")
    if server:
        # Extract version info
        version_match = re.search(r"[\d.]+", server)
        if version_match:
            next_steps.append(
                {
                    "title": f"Search for {server} exploits",
                    "commands": [
                        f'searchsploit "{server}"',
                    ],
                    "reason": f"Check for known vulnerabilities in {server}",
                }
            )

    # WAF detected - bypass techniques
    waf = parsed_data.get("waf", [])
    if waf:
        waf_name = waf[0] if waf else "WAF"
        next_steps.append(
            {
                "title": f"WAF bypass techniques for {waf_name}",
                "commands": [
                    f"wafw00f {base_url}",
                ],
                "reason": f"{waf_name} detected - may need encoding/tamper techniques for injection attacks",
            }
        )

    # Interesting paths in robots.txt (non-CGI)
    interesting_paths = [
        p
        for p in robots_paths
        if any(
            kw in p.lower()
            for kw in [
                "admin",
                "backup",
                "config",
                "db",
                "secret",
                "private",
                "upload",
                "api",
                ".git",
                ".env",
            ]
        )
    ]
    if interesting_paths and not cgi_paths:  # Don't duplicate if CGI already shown
        next_steps.append(
            {
                "title": "Check sensitive paths from robots.txt",
                "commands": [f'curl -s "{p}"' for p in interesting_paths[:3]],
                "reason": f"Found {len(interesting_paths)} potentially sensitive path(s) in robots.txt",
            }
        )

    # If redirect detected - follow it
    redirect_url = parsed_data.get("redirect_url")
    if redirect_url:
        next_steps.append(
            {
                "title": "Follow redirect and scan new target",
                "commands": [
                    f'curl -Ls "{redirect_url}"',
                ],
                "reason": f"Site redirects to {redirect_url} - scan the actual destination",
            }
        )

    return next_steps


# =========================================================================
# API FINGERPRINT HELPER FUNCTIONS
# Used by result handler and tool chaining to make decisions based on
# API detection results.
# =========================================================================


def has_graphql_introspection(parsed_data: Dict[str, Any]) -> bool:
    """
    Check if GraphQL introspection is enabled on any detected endpoint.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        True if any GraphQL endpoint has introspection enabled
    """
    for api in parsed_data.get("api_endpoints", []):
        if "graphql" in api.get("type", "").lower():
            details = api.get("details") or {}
            if details.get("introspection_enabled"):
                return True
    return False


def has_graphql_endpoint(parsed_data: Dict[str, Any]) -> bool:
    """
    Check if any GraphQL endpoint was detected (confirmed or not).

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        True if any GraphQL endpoint was found
    """
    for api in parsed_data.get("api_endpoints", []):
        if "graphql" in api.get("type", "").lower():
            return True
    return False


def has_rest_api(parsed_data: Dict[str, Any]) -> bool:
    """
    Check if any REST API endpoint was detected.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        True if any REST API endpoint was found
    """
    for api in parsed_data.get("api_endpoints", []):
        api_type = api.get("type", "").lower()
        # REST API, API v1, API v2, etc.
        if "rest" in api_type or ("api" in api_type and "graphql" not in api_type):
            return True
    return False


def has_swagger_spec(parsed_data: Dict[str, Any]) -> bool:
    """
    Check if Swagger/OpenAPI spec was found and successfully parsed.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        True if Swagger/OpenAPI spec was parsed with endpoints
    """
    for api in parsed_data.get("api_endpoints", []):
        api_type = api.get("type", "").lower()
        if "swagger" in api_type or "openapi" in api_type:
            details = api.get("details") or {}
            if details.get("endpoints"):
                return True
    return False


def has_api_base_path(parsed_data: Dict[str, Any]) -> bool:
    """
    Check if an API base path was detected (e.g., /api/, /api/v1/).

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        True if API base path was found
    """
    for api in parsed_data.get("api_endpoints", []):
        path = api.get("path", "")
        if "/api" in path.lower():
            return True
    return False


def get_api_endpoints_by_type(
    parsed_data: Dict[str, Any], api_type: str
) -> List[Dict[str, Any]]:
    """
    Get all API endpoints of a specific type.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()
        api_type: Type to filter by (e.g., "graphql", "rest", "swagger")

    Returns:
        List of matching API endpoint dicts
    """
    results = []
    api_type_lower = api_type.lower()
    for api in parsed_data.get("api_endpoints", []):
        if api_type_lower in api.get("type", "").lower():
            results.append(api)
    return results


def get_api_parameters(parsed_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract all discovered API parameters from OpenAPI specs.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        List of parameter dicts: [{name, in, type, required}, ...]
    """
    params = []
    for api in parsed_data.get("api_endpoints", []):
        details = api.get("details") or {}
        api_params = details.get("parameters", [])
        for param in api_params:
            if param not in params:
                params.append(param)
    return params


def get_openapi_endpoints(parsed_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract all endpoints from parsed OpenAPI/Swagger specs.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        List of endpoint dicts: [{path, methods, summary}, ...]
    """
    endpoints = []
    for api in parsed_data.get("api_endpoints", []):
        api_type = api.get("type", "").lower()
        if "swagger" in api_type or "openapi" in api_type:
            details = api.get("details") or {}
            spec_endpoints = details.get("endpoints", [])
            for endpoint in spec_endpoints:
                if endpoint not in endpoints:
                    endpoints.append(endpoint)
    return endpoints


def get_graphql_schema(parsed_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Get the GraphQL schema from introspection results.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        Schema dict {types, queries, mutations, subscriptions} or None
    """
    for api in parsed_data.get("api_endpoints", []):
        if "graphql" in api.get("type", "").lower():
            details = api.get("details") or {}
            if details.get("schema"):
                return details["schema"]
    return None


def get_detected_auth_methods(parsed_data: Dict[str, Any]) -> List[str]:
    """
    Get all authentication methods detected across API endpoints.

    Args:
        parsed_data: Output from parse_http_fingerprint_output()

    Returns:
        List of auth method strings (e.g., ["jwt", "bearer", "api_key"])
    """
    auth_methods = set()
    for api in parsed_data.get("api_endpoints", []):
        details = api.get("details") or {}
        for method in details.get("auth_methods", []):
            auth_methods.add(method)
        # Also check OpenAPI security schemes
        for scheme in details.get("security_schemes", []):
            # Parse scheme string like "api_key (apiKey)"
            scheme_lower = scheme.lower()
            if "bearer" in scheme_lower or "jwt" in scheme_lower:
                auth_methods.add("bearer")
            elif "apikey" in scheme_lower or "api_key" in scheme_lower:
                auth_methods.add("api_key")
            elif "oauth" in scheme_lower:
                auth_methods.add("oauth")
            elif "basic" in scheme_lower:
                auth_methods.add("basic")
    return list(auth_methods)


# =========================================================================
# CSP HEADER PARSING
# Extracts domains, infrastructure, and security issues from
# Content-Security-Policy headers for passive recon.
# =========================================================================

# CSP keywords to skip (not domains)
_CSP_KEYWORDS = {
    "'self'",
    "'unsafe-inline'",
    "'unsafe-eval'",
    "'none'",
    "'strict-dynamic'",
    "'unsafe-hashes'",
    "'report-sample'",
    "data:",
    "blob:",
    "mediastream:",
    "filesystem:",
}

# Known CSP directive names
_CSP_DIRECTIVES = {
    "default-src",
    "script-src",
    "style-src",
    "img-src",
    "font-src",
    "connect-src",
    "frame-src",
    "form-action",
    "media-src",
    "object-src",
    "report-uri",
    "report-to",
    "base-uri",
    "worker-src",
    "child-src",
    "frame-ancestors",
    "navigate-to",
    "manifest-src",
    "prefetch-src",
    "script-src-elem",
    "script-src-attr",
    "style-src-elem",
    "style-src-attr",
    "upgrade-insecure-requests",
    "block-all-mixed-content",
    "sandbox",
    "plugin-types",
    "require-trusted-types-for",
    "trusted-types",
}


def _classify_csp_domain(domain: str) -> str:
    """Classify a CSP domain by infrastructure type."""
    d = domain.lower()
    if re.search(r"\.s3[.-].*\.amazonaws\.com$", d) or d.endswith(".s3.amazonaws.com"):
        return "s3_bucket"
    if re.search(r"\.execute-api\..*\.amazonaws\.com$", d):
        return "api_gateway"
    if d.endswith(".cloudfront.net"):
        return "cdn_cloudfront"
    if d.endswith(".googleapis.com"):
        return "google_api"
    if d.endswith("sentry.io") or d.endswith(".sentry.io"):
        return "error_tracking"
    if d.endswith(".cloudflare.com"):
        return "cdn_cloudflare"
    if d.endswith(".akamaized.net") or d.endswith(".akamai.net"):
        return "cdn_akamai"
    if d.endswith(".fastly.net"):
        return "cdn_fastly"
    if d.endswith(".azureedge.net") or d.endswith(".azure.com"):
        return "cdn_azure"
    return "domain"


def _extract_domain_from_source(source: str) -> Optional[str]:
    """Extract hostname from a CSP source value, stripping scheme/port/path."""
    s = source.strip()
    # Strip scheme
    for prefix in ("https://", "http://", "wss://", "ws://"):
        if s.lower().startswith(prefix):
            s = s[len(prefix) :]
            break
    # Strip path
    s = s.split("/")[0]
    # Strip port
    s = s.split(":")[0]
    # Validate: must have at least one dot and only valid chars
    if not s or "." not in s:
        return None
    if not re.match(r"^[\w.*-]+$", s):
        return None
    return s.lower()


def parse_csp_header(csp_value: str) -> Dict[str, Any]:
    """
    Parse a Content-Security-Policy header value.

    Returns:
        Dict with directives, extracted domains, and security issues.
    """
    result: Dict[str, Any] = {
        "directives": {},
        "domains": [],
        "security_issues": [],
    }

    if not csp_value or not csp_value.strip():
        return result

    seen_domains = set()

    for directive_str in csp_value.split(";"):
        directive_str = directive_str.strip()
        if not directive_str:
            continue

        parts = directive_str.split()
        if not parts:
            continue

        directive_name = parts[0].lower()
        sources = parts[1:] if len(parts) > 1 else []
        result["directives"][directive_name] = sources

        # Security issue detection for script-src
        if directive_name == "script-src":
            if "'unsafe-inline'" in sources:
                result["security_issues"].append(
                    {
                        "issue": "unsafe-inline in script-src",
                        "severity": "medium",
                        "directive": directive_name,
                    }
                )
            if "'unsafe-eval'" in sources:
                result["security_issues"].append(
                    {
                        "issue": "unsafe-eval in script-src",
                        "severity": "medium",
                        "directive": directive_name,
                    }
                )

        # Security issue: unsafe-inline in style-src
        if directive_name == "style-src" and "'unsafe-inline'" in sources:
            result["security_issues"].append(
                {
                    "issue": "unsafe-inline in style-src",
                    "severity": "low",
                    "directive": directive_name,
                }
            )

        # Check for bare wildcard in any directive
        if "*" in sources:
            result["security_issues"].append(
                {
                    "issue": f"bare wildcard (*) in {directive_name}",
                    "severity": "low",
                    "directive": directive_name,
                }
            )

        # Skip non-source directives
        if directive_name in (
            "report-uri",
            "report-to",
            "sandbox",
            "plugin-types",
            "upgrade-insecure-requests",
            "block-all-mixed-content",
            "require-trusted-types-for",
            "trusted-types",
        ):
            continue

        # Extract domains from sources
        for source in sources:
            source_lower = source.lower()
            # Skip CSP keywords
            if source_lower in _CSP_KEYWORDS:
                continue
            # Skip nonce/hash values
            if source_lower.startswith("'nonce-") or source_lower.startswith("'sha"):
                continue
            # Skip bare wildcard (already flagged)
            if source == "*":
                continue

            domain = _extract_domain_from_source(source)
            if not domain:
                continue

            # Handle wildcard subdomains: *.example.com
            base_domain = domain
            if domain.startswith("*."):
                base_domain = domain[2:]

            dedup_key = (domain, directive_name)
            if dedup_key in seen_domains:
                continue
            seen_domains.add(dedup_key)

            infra_type = _classify_csp_domain(base_domain)
            result["domains"].append(
                {
                    "domain": domain,
                    "base_domain": base_domain,
                    "directive": directive_name,
                    "infra_type": infra_type,
                }
            )

    return result


def extract_csp_from_headers(headers: Dict[str, str]) -> Optional[Dict[str, Any]]:
    """
    Extract and parse CSP headers from an HTTP response headers dict.

    Handles case-insensitive header names. Checks both enforced and
    report-only CSP headers.

    Returns:
        Dict with 'enforced' and 'report_only' parse results, or None.
    """
    if not headers:
        return None

    # Normalize header keys to lowercase for lookup
    lower_headers = {k.lower(): v for k, v in headers.items()}

    enforced_val = lower_headers.get("content-security-policy")
    report_val = lower_headers.get("content-security-policy-report-only")

    if not enforced_val and not report_val:
        return None

    result = {}
    if enforced_val:
        result["enforced"] = parse_csp_header(enforced_val)
    if report_val:
        result["report_only"] = parse_csp_header(report_val)

    return result


# Export the main functions
__all__ = [
    "parse_http_fingerprint_output",
    "is_managed_hosting",
    "get_managed_hosting_platform",
    "has_waf",
    "get_wafs",
    "has_cdn",
    "get_cdns",
    "build_fingerprint_context",
    "get_tool_recommendations",
    "get_effective_url",
    "generate_next_steps",
    # API fingerprinting helpers
    "has_graphql_introspection",
    "has_graphql_endpoint",
    "has_rest_api",
    "has_swagger_spec",
    "has_api_base_path",
    "get_api_endpoints_by_type",
    "get_api_parameters",
    "get_openapi_endpoints",
    "get_graphql_schema",
    "get_detected_auth_methods",
    # CSP parsing
    "parse_csp_header",
    "extract_csp_from_headers",
]
