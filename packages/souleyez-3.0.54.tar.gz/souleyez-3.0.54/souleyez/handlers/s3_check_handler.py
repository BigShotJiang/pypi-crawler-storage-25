#!/usr/bin/env python3
"""
S3 Check handler.

Parses s3_check plugin output and creates findings for misconfigured
S3 buckets. Pure-Python plugin, so logic mirrors http_fingerprint's
JSON_RESULT-based parsing.

Severity mapping (set in v3.0.54):
- Listable + has objects -> critical
- Listable + empty       -> high
- Public read, no list   -> medium
- Stale reference (404)  -> info (not a finding by default)
"""

import json
import logging
import os
import re
from typing import Any, Dict, Optional

import click

from souleyez.engine.job_status import (STATUS_DONE, STATUS_ERROR,
                                        STATUS_NO_RESULTS, STATUS_WARNING)
from souleyez.handlers.base import BaseToolHandler

logger = logging.getLogger(__name__)


def _parse_log(log_path: str) -> Dict[str, Any]:
    """Extract the JSON_RESULT block from an s3_check log."""
    if not log_path or not os.path.exists(log_path):
        return {}
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception:
        return {}
    m = re.search(
        r"=== JSON_RESULT ===\n(.+?)\n=== END_JSON_RESULT ===",
        text,
        re.DOTALL,
    )
    if not m:
        return {}
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return {}


class S3CheckHandler(BaseToolHandler):
    """Handler for s3_check plugin jobs."""

    tool_name = "s3_check"
    display_name = "S3 Check"

    has_error_handler = True
    has_warning_handler = True
    has_no_results_handler = True
    has_done_handler = True

    def parse_job(
        self,
        engagement_id: int,
        log_path: str,
        job: Dict[str, Any],
        host_manager: Optional[Any] = None,
        findings_manager: Optional[Any] = None,
        credentials_manager: Optional[Any] = None,
    ) -> Dict[str, Any]:
        try:
            if (
                not log_path
                or not os.path.exists(log_path)
                or os.path.getsize(log_path) == 0
            ):
                return {
                    "tool": self.tool_name,
                    "status": STATUS_NO_RESULTS,
                    "summary": "Empty output (plugin produced no log)",
                }

            parsed = _parse_log(log_path)
            target = job.get("target", "")
            bucket = parsed.get("bucket")
            region = parsed.get("region")

            if not parsed or not bucket:
                # Plugin couldn't parse the target as an S3 URL.
                err = parsed.get("error") if parsed else "Unparseable s3_check output"
                return {
                    "tool": self.tool_name,
                    "status": STATUS_WARNING,
                    "target": target,
                    "summary": err or "Target did not look like an S3 bucket URL",
                }

            head_status = parsed.get("head_status")
            list_status = parsed.get("list_status")
            public = bool(parsed.get("public"))
            listable = bool(parsed.get("listable"))
            object_count = int(parsed.get("object_count") or 0)
            sample_keys = parsed.get("sample_keys") or []
            err = parsed.get("error")

            # Best-effort host link — bucket virtual-hosted URL is unique enough.
            host_id = None
            if host_manager is None:
                from souleyez.storage.hosts import HostManager

                host_manager = HostManager()
            try:
                bucket_host = f"{bucket}.s3.{region}.amazonaws.com"
                host_record = host_manager.add_or_update_host(
                    engagement_id,
                    {
                        "ip": bucket_host,
                        "hostname": bucket_host,
                        "status": "up",
                        "notes": "S3 bucket discovered via s3_check",
                    },
                )
                # add_or_update_host returns id in some impls, host dict in others
                if isinstance(host_record, int):
                    host_id = host_record
                elif isinstance(host_record, dict):
                    host_id = host_record.get("id")
                else:
                    found = host_manager.get_host_by_ip(engagement_id, bucket_host)
                    host_id = found["id"] if found else None
            except Exception as e:
                logger.debug(f"S3 check: host upsert failed: {e}")

            # Findings
            from souleyez.storage.findings import FindingsManager

            fm = findings_manager or FindingsManager()
            findings_added = 0

            severity = None
            title = None
            description = None
            evidence_lines = [
                f"Bucket: {bucket}",
                f"Region: {region}",
                f"HEAD: {head_status}",
            ]
            if list_status is not None:
                evidence_lines.append(f"LIST: {list_status}")
            if listable:
                evidence_lines.append(f"Object count: {object_count}")
                if sample_keys:
                    evidence_lines.append("Sample keys:")
                    for k in sample_keys:
                        evidence_lines.append(f"  - {k}")

            if listable and object_count > 0:
                severity = "critical"
                title = (
                    f"Public S3 bucket listable with {object_count} object(s): {bucket}"
                )
                description = (
                    f"S3 bucket '{bucket}' (region {region}) is publicly "
                    f"listable via anonymous GET ?list-type=2 and contains "
                    f"{object_count} object(s). Anonymous users can enumerate "
                    "and likely download bucket contents."
                )
            elif listable and object_count == 0:
                severity = "high"
                title = f"Public S3 bucket listable (empty): {bucket}"
                description = (
                    f"S3 bucket '{bucket}' (region {region}) is publicly "
                    "listable via anonymous GET ?list-type=2 but currently "
                    "empty. Misconfiguration is exploitable as soon as "
                    "objects are added."
                )
            elif public:
                severity = "medium"
                title = f"Public S3 bucket (read, not listable): {bucket}"
                description = (
                    f"S3 bucket '{bucket}' (region {region}) responded HTTP "
                    "200 to anonymous HEAD requests. Object listing is "
                    "denied, but individual objects may be retrievable if "
                    "their keys are known."
                )

            if severity and host_id:
                fm.add_finding(
                    engagement_id=engagement_id,
                    host_id=host_id,
                    title=title,
                    finding_type="s3_misconfiguration",
                    severity=severity,
                    description=description,
                    tool=self.tool_name,
                    path=target,
                    evidence="\n".join(evidence_lines),
                )
                findings_added = 1

            # Status
            if err and not public:
                # Stale reference / region issue / probe failure — informational
                status = STATUS_WARNING
                summary = err
            elif severity:
                status = STATUS_DONE
                summary = title
            elif head_status == 403:
                status = STATUS_NO_RESULTS
                summary = f"Bucket '{bucket}' exists but rejects anonymous access (403)"
            else:
                status = STATUS_NO_RESULTS
                summary = f"Bucket '{bucket}': HEAD={head_status}" + (
                    f", LIST={list_status}" if list_status is not None else ""
                )

            return {
                "tool": self.tool_name,
                "status": status,
                "target": target,
                "bucket": bucket,
                "region": region,
                "head_status": head_status,
                "list_status": list_status,
                "public": public,
                "listable": listable,
                "object_count": object_count,
                "findings_added": findings_added,
                "summary": summary,
            }

        except Exception as e:
            logger.error(f"Error parsing s3_check job: {e}")
            return {
                "tool": self.tool_name,
                "status": STATUS_ERROR,
                "error": str(e),
                "summary": f"Parse error: {e}",
            }

    def display_done(
        self,
        job: Dict[str, Any],
        log_path: str,
        show_all: bool = False,
        show_passwords: bool = False,
    ) -> None:
        parsed = _parse_log(log_path)
        bucket = parsed.get("bucket") or "(unknown)"
        region = parsed.get("region") or "(unknown)"
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo(click.style("S3 BUCKET CHECK", bold=True, fg="cyan"))
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo()
        click.echo(f"  Bucket: {bucket}")
        click.echo(f"  Region: {region}")
        click.echo(f"  HEAD:   {parsed.get('head_status')}")
        if parsed.get("list_status") is not None:
            click.echo(f"  LIST:   {parsed.get('list_status')}")
        if parsed.get("listable"):
            click.echo(
                click.style(
                    f"  Public + Listable ({parsed.get('object_count')} objects)",
                    fg="red",
                    bold=True,
                )
            )
            for k in parsed.get("sample_keys") or []:
                click.echo(f"    - {k}")
        elif parsed.get("public"):
            click.echo(
                click.style("  Public read (listing denied)", fg="yellow", bold=True)
            )
        else:
            click.echo(click.style("  Not publicly accessible", fg="green"))
        click.echo()

    def display_warning(
        self,
        job: Dict[str, Any],
        log_path: str,
        log_content: Optional[str] = None,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="yellow"))
        click.echo(click.style("[WARNING] S3 CHECK", bold=True, fg="yellow"))
        click.echo(click.style("=" * 70, fg="yellow"))
        click.echo()
        if parsed.get("error"):
            click.echo(f"  {parsed['error']}")
        else:
            click.echo("  Probe completed with warnings. Check raw logs.")
        click.echo()

    def display_error(
        self,
        job: Dict[str, Any],
        log_path: str,
        log_content: Optional[str] = None,
    ) -> None:
        click.echo(click.style("=" * 70, fg="red"))
        click.echo(click.style("[ERROR] S3 CHECK FAILED", bold=True, fg="red"))
        click.echo(click.style("=" * 70, fg="red"))
        click.echo("  Probe failed - see raw logs for details (press 'r')")
        click.echo()

    def display_no_results(
        self,
        job: Dict[str, Any],
        log_path: str,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo(click.style("S3 BUCKET CHECK", bold=True, fg="cyan"))
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo()
        bucket = parsed.get("bucket") or "(unknown)"
        click.echo(f"  Bucket: {bucket}")
        click.echo(
            click.style("  Result: not publicly accessible", fg="green", bold=True)
        )
        click.echo()
