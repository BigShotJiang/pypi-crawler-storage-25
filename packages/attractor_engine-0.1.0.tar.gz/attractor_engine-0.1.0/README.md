# attractor

A Hopfield Network-based memory engine that stores and retrieves contextual memory the way a brain does — but fast.

Attractor is a standalone memory service purpose-built for storing and retrieving contextual memory. It is designed to work like a brain — not like a key-value store or a vector database.

Named after the concept of **attractors** in dynamical systems: stored memories are energy minima, retrieval is gradient descent to the nearest basin. Give it a partial or noisy cue and it converges to the full memory.

## Install

```bash
pip install attractor-engine
```

## Usage

### Start the service

```bash
attractor start                                      # default port 7747
attractor start --port 8000                          # custom port
attractor start --db postgresql://localhost/attractor  # custom db url
attractor connect                                    # verify service is running
```

### Write a memory

```bash
curl -X POST http://localhost:7747/memories \
  -H "Content-Type: application/json" \
  -d '{
    "content": "auth tokens should never be stored in localStorage",
    "context": {
      "topic": "security review",
      "entities": ["auth", "frontend team"],
      "task": "reviewing PR #42",
      "session_id": "abc123"
    },
    "tags": ["security", "auth"]
  }'
```

### Retrieve by ID

```bash
curl http://localhost:7747/memories/<id>
```

### Search

```bash
curl -X POST http://localhost:7747/memories/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "where did we land on auth token storage",
    "context_filter": { "topic": "security review" },
    "limit": 5
  }'
```

## Requirements

- Python 3.10+
- PostgreSQL with [pgvector](https://github.com/pgvector/pgvector) extension

## Status

Phase 1 complete — storage, retrieval, and semantic search are working.
Phases 2–4 (association graph, decay, Hopfield retrieval) are in development.

## Source

[github.com/aag1091-alt/attractor](https://github.com/aag1091-alt/attractor)
