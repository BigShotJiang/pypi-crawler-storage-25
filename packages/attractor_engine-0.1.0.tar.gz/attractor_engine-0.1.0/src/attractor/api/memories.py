import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Request

from ..models.memory import Memory, MemoryRecord, MemoryResponse

router = APIRouter()


@router.post("/memories", response_model=MemoryResponse, status_code=201)
async def write_memory(body: Memory, request: Request) -> MemoryResponse:
    encoder = request.app.state.encoder
    store = request.app.state.store

    vector = await encoder.encode(body.content)
    now = datetime.now(timezone.utc)

    record = MemoryRecord(
        id=str(uuid.uuid4()),
        content=body.content,
        context=body.context,
        tags=body.tags,
        created_at=now,
        accessed_at=now,
        access_count=0,
        vector=vector,
    )
    await store.write(record)
    return MemoryResponse(id=record.id, created_at=record.created_at)


@router.get("/memories/{memory_id}", response_model=MemoryRecord)
async def get_memory(memory_id: str, request: Request) -> MemoryRecord:
    store = request.app.state.store
    record = await store.get(memory_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Memory not found")
    record.vector = None  # don't expose the vector in API responses
    return record


@router.delete("/memories/{memory_id}", status_code=204)
async def delete_memory(memory_id: str, request: Request) -> None:
    store = request.app.state.store
    deleted = await store.delete(memory_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Memory not found")
