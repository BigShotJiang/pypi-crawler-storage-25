from fastapi import APIRouter, Request

from ..models.query import SearchQuery, SearchResponse, SearchResult

router = APIRouter()


@router.post("/memories/search", response_model=SearchResponse)
async def search_memories(body: SearchQuery, request: Request) -> SearchResponse:
    encoder = request.app.state.encoder
    store = request.app.state.store

    vector = await encoder.encode(body.query)
    context_filter = (
        body.context_filter.model_dump(exclude_none=True)
        if body.context_filter
        else {}
    )

    hits = await store.search(vector, context_filter, body.limit)

    results = [
        SearchResult(
            id=record.id,
            content=record.content,
            context=record.context,
            tags=record.tags,
            score=score,
            created_at=record.created_at,
        )
        for record, score in hits
    ]
    return SearchResponse(results=results)
