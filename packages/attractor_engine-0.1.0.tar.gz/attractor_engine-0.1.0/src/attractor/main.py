from contextlib import asynccontextmanager

from fastapi import FastAPI

from .config import settings
from .embeddings.encoder import Encoder
from .store.pg_store import PgStore
from .api.memories import router as memories_router
from .api.search import router as search_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup
    encoder = Encoder(settings.model_name)
    encoder.load()  # blocking — runs once, model cached after first call

    store = PgStore(settings.db_url)
    await store.initialize()

    app.state.encoder = encoder
    app.state.store = store

    yield

    # shutdown
    await store.close()


app = FastAPI(
    title="Attractor",
    description="Brain-inspired memory engine",
    version="0.0.1",
    lifespan=lifespan,
)

app.include_router(memories_router)
app.include_router(search_router)


@app.get("/health")
async def health():
    return {"status": "ok"}
