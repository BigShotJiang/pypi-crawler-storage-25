import json
from datetime import datetime, timezone

import asyncpg
from pgvector.asyncpg import register_vector

from .base import MemoryStore
from ..models.memory import ContextFrame, MemoryRecord

# Dimension for all-MiniLM-L6-v2
VECTOR_DIM = 384

_EXTENSION_SQL = "CREATE EXTENSION IF NOT EXISTS vector"

_TABLE_SQL = f"""
CREATE TABLE IF NOT EXISTS memories (
    id           TEXT PRIMARY KEY,
    content      TEXT NOT NULL,
    context      JSONB NOT NULL,
    tags         JSONB NOT NULL DEFAULT '[]',
    created_at   TIMESTAMPTZ NOT NULL,
    accessed_at  TIMESTAMPTZ NOT NULL,
    access_count INTEGER NOT NULL DEFAULT 0,
    vector       vector({VECTOR_DIM})
);
"""


class PgStore(MemoryStore):
    def __init__(self, db_url: str) -> None:
        self._db_url = db_url
        self._pool: asyncpg.Pool | None = None

    async def initialize(self) -> None:
        # Create extension first using a plain connection — register_vector
        # requires the extension to already exist when the pool initializes.
        bootstrap = await asyncpg.connect(self._db_url)
        try:
            await bootstrap.execute(_EXTENSION_SQL)
        finally:
            await bootstrap.close()

        self._pool = await asyncpg.create_pool(
            self._db_url,
            init=_register_vector,
        )
        async with self._pool.acquire() as conn:
            await conn.execute(_TABLE_SQL)

    async def close(self) -> None:
        if self._pool:
            await self._pool.close()

    async def write(self, record: MemoryRecord) -> str:
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO memories
                    (id, content, context, tags, created_at, accessed_at, access_count, vector)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                """,
                record.id,
                record.content,
                json.dumps(record.context.model_dump()),
                json.dumps(record.tags),
                record.created_at,
                record.accessed_at,
                record.access_count,
                record.vector,
            )
        return record.id

    async def get(self, id: str) -> MemoryRecord | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                UPDATE memories
                SET accessed_at  = NOW(),
                    access_count = access_count + 1
                WHERE id = $1
                RETURNING *
                """,
                id,
            )
        if row is None:
            return None
        return _row_to_record(row)

    async def search(
        self,
        vector: list[float],
        context_filter: dict,
        limit: int,
    ) -> list[tuple[MemoryRecord, float]]:
        params: list = [vector, limit]
        conditions: list[str] = []

        for key in ("topic", "task", "session_id"):
            value = context_filter.get(key)
            if value is not None:
                params.append(value)
                conditions.append(f"context->>{repr(key)} = ${len(params)}")

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        sql = f"""
            SELECT *, 1 - (vector <=> $1) AS score
            FROM memories
            {where}
            ORDER BY vector <=> $1
            LIMIT $2
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        return [(_row_to_record(row), float(row["score"])) for row in rows]

    async def delete(self, id: str) -> bool:
        async with self._pool.acquire() as conn:
            result = await conn.execute("DELETE FROM memories WHERE id = $1", id)
        return result == "DELETE 1"


async def _register_vector(conn: asyncpg.Connection) -> None:
    await register_vector(conn)


def _row_to_record(row: asyncpg.Record) -> MemoryRecord:
    raw_context = row["context"]
    context_data = (
        json.loads(raw_context) if isinstance(raw_context, str) else dict(raw_context)
    )
    raw_tags = row["tags"]
    tags = json.loads(raw_tags) if isinstance(raw_tags, str) else list(raw_tags)

    return MemoryRecord(
        id=row["id"],
        content=row["content"],
        context=ContextFrame(**context_data),
        tags=tags,
        created_at=row["created_at"],
        accessed_at=row["accessed_at"],
        access_count=row["access_count"],
        vector=list(row["vector"]) if row["vector"] is not None else None,
    )
