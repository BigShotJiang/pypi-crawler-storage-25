from abc import ABC, abstractmethod
from ..models.memory import MemoryRecord


class MemoryStore(ABC):
    @abstractmethod
    async def initialize(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    async def write(self, record: MemoryRecord) -> str: ...

    @abstractmethod
    async def get(self, id: str) -> MemoryRecord | None: ...

    @abstractmethod
    async def search(
        self,
        vector: list[float],
        context_filter: dict,
        limit: int,
    ) -> list[tuple[MemoryRecord, float]]: ...

    @abstractmethod
    async def delete(self, id: str) -> bool: ...
