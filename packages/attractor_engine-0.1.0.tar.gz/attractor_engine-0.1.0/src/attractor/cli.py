import sys

import click
import httpx
import uvicorn


@click.group()
def main():
    """Attractor — brain-inspired memory engine."""


@main.command()
@click.option("--port", default=7747, show_default=True, help="Port to listen on")
@click.option(
    "--db",
    default="postgresql://localhost/attractor",
    show_default=True,
    envvar="ATTRACTOR_DB_URL",
    help="PostgreSQL connection URL",
)
@click.option("--model", default="all-MiniLM-L6-v2", show_default=True, help="Embedding model")
def start(port: int, db: str, model: str):
    """Start the Attractor service."""
    import os
    os.environ.setdefault("ATTRACTOR_DB_URL", db)
    os.environ.setdefault("ATTRACTOR_MODEL_NAME", model)

    click.echo(f"Starting Attractor on port {port}  (db: {db})")
    uvicorn.run(
        "attractor.main:app",
        host="0.0.0.0",
        port=port,
        log_level="info",
    )


@main.command()
@click.option("--port", default=7747, show_default=True, help="Port to check")
def connect(port: int):
    """Verify the Attractor service is running."""
    url = f"http://localhost:{port}/health"
    try:
        response = httpx.get(url, timeout=5)
        response.raise_for_status()
        click.echo(f"Attractor is running at {url}")
    except httpx.ConnectError:
        click.echo(f"Cannot connect to Attractor at {url} — is it running?", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Unexpected error: {e}", err=True)
        sys.exit(1)
