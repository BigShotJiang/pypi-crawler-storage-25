from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    port: int = 7747
    db_url: str = "postgresql://localhost/attractor"
    model_name: str = "all-MiniLM-L6-v2"

    model_config = {"env_prefix": "ATTRACTOR_"}


settings = Settings()
