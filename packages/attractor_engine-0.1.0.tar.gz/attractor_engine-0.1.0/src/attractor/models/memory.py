from datetime import datetime
from pydantic import BaseModel


class ContextFrame(BaseModel):
    topic: str | None = None
    entities: list[str] = []
    task: str | None = None
    session_id: str | None = None


class Memory(BaseModel):
    content: str
    context: ContextFrame = ContextFrame()
    tags: list[str] = []


class MemoryResponse(BaseModel):
    id: str
    created_at: datetime


class MemoryRecord(BaseModel):
    id: str
    content: str
    context: ContextFrame
    tags: list[str]
    created_at: datetime
    accessed_at: datetime
    access_count: int
    vector: list[float] | None = None
