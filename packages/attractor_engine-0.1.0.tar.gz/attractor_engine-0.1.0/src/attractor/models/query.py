from datetime import datetime
from pydantic import BaseModel, Field
from .memory import ContextFrame


class SearchQuery(BaseModel):
    query: str
    context_filter: ContextFrame | None = None
    limit: int = Field(default=5, ge=1, le=100)


class SearchResult(BaseModel):
    id: str
    content: str
    context: ContextFrame
    tags: list[str]
    score: float
    created_at: datetime


class SearchResponse(BaseModel):
    results: list[SearchResult]
