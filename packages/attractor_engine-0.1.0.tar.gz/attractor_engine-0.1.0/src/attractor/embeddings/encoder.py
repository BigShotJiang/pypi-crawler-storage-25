import asyncio
from functools import partial

from sentence_transformers import SentenceTransformer


class Encoder:
    def __init__(self, model_name: str = "all-MiniLM-L6-v2") -> None:
        self._model_name = model_name
        self._model: SentenceTransformer | None = None

    def load(self) -> None:
        """Load the model. Call once at startup (blocking)."""
        self._model = SentenceTransformer(self._model_name)

    async def encode(self, text: str) -> list[float]:
        """Encode text to a vector. Runs in a thread pool to avoid blocking the event loop."""
        loop = asyncio.get_running_loop()
        vector = await loop.run_in_executor(
            None, partial(self._model.encode, text, normalize_embeddings=True)
        )
        return vector.tolist()
