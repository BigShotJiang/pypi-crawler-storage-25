"""Tests for picolayer_mcp.auth — API key resolution and recovery."""

from __future__ import annotations

from pathlib import Path

import pytest

from picolayer_mcp import auth as auth_mod
from picolayer_mcp.auth import (
    DEFAULT_API_ENDPOINT,
    AuthContext,
    AuthError,
    clear_sticky_auth,
    current_auth,
    fallback_auth,
    recover_auth,
    resolve_auth,
    set_sticky_auth,
)


class TestResolveAuth:
    def test_env_var_wins(self, monkeypatch: pytest.MonkeyPatch, fake_config_dir: Path) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "env-key-123")
        ctx = resolve_auth()
        assert ctx.api_key == "env-key-123"
        assert ctx.api_endpoint == DEFAULT_API_ENDPOINT

    def test_env_endpoint_overrides_default(
        self, monkeypatch: pytest.MonkeyPatch, fake_config_dir: Path
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        monkeypatch.setenv("PICOLAYER_API_ENDPOINT", "https://staging.picolayer.dev")
        ctx = resolve_auth()
        assert ctx.api_endpoint == "https://staging.picolayer.dev"

    def test_falls_back_to_config_file(self, fake_config_dir: Path) -> None:
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text(
            '[auth]\napi_key = "file-key"\napi_endpoint = "https://from-file"\n'
        )
        ctx = resolve_auth()
        assert ctx.api_key == "file-key"
        assert ctx.api_endpoint == "https://from-file"

    def test_env_key_overrides_file_key(
        self, monkeypatch: pytest.MonkeyPatch, fake_config_dir: Path
    ) -> None:
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "file-key"\n')
        monkeypatch.setenv("PICOLAYER_API_KEY", "env-key")
        ctx = resolve_auth()
        assert ctx.api_key == "env-key"

    def test_no_key_anywhere_raises(self, fake_config_dir: Path) -> None:
        with pytest.raises(AuthError):
            resolve_auth()

    def test_malformed_config_file_treated_as_missing(self, fake_config_dir: Path) -> None:
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text("not toml at all }}}")
        with pytest.raises(AuthError):
            resolve_auth()


class TestFallbackAuth:
    """Tests for the backwards-compatible ``fallback_auth`` wrapper."""

    def test_config_source_rereads_file(self, fake_config_dir: Path) -> None:
        """When source is 'config' and the file has a new key, return it."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "new-key"\n')
        current = AuthContext(api_key="old-key", api_endpoint=DEFAULT_API_ENDPOINT, source="config")
        result = fallback_auth(current)
        assert result is not None
        assert result.api_key == "new-key"

    def test_config_source_same_key_returns_none(self, fake_config_dir: Path) -> None:
        """When source is 'config' and the file has the same key, no fallback."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "same-key"\n')
        current = AuthContext(
            api_key="same-key", api_endpoint=DEFAULT_API_ENDPOINT, source="config"
        )
        assert fallback_auth(current) is None

    def test_env_source_no_config_file_returns_none(self, fake_config_dir: Path) -> None:
        """Env key was used but no config file exists — nothing to fall back to."""
        current = AuthContext(api_key="env-key", api_endpoint=DEFAULT_API_ENDPOINT, source="env")
        assert fallback_auth(current) is None

    def test_env_source_same_key_in_config_returns_none(self, fake_config_dir: Path) -> None:
        """Env key and config file hold the same key — retrying would not help."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "env-key"\n')
        current = AuthContext(api_key="env-key", api_endpoint=DEFAULT_API_ENDPOINT, source="env")
        assert fallback_auth(current) is None

    def test_env_source_different_config_key_returns_config_context(
        self, fake_config_dir: Path
    ) -> None:
        """Config file has a different (presumably fresher) key — return it."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text(
            '[auth]\napi_key = "fresh-cfg-key"\napi_endpoint = "https://from-cfg"\n'
        )
        current = AuthContext(
            api_key="stale-env-key", api_endpoint=DEFAULT_API_ENDPOINT, source="env"
        )
        result = fallback_auth(current)
        assert result is not None
        assert result.api_key == "fresh-cfg-key"
        assert result.api_endpoint == "https://from-cfg"
        assert result.source == "config"

    def test_fallback_uses_current_endpoint_when_config_has_none(
        self, fake_config_dir: Path
    ) -> None:
        """If the config file has a key but no endpoint, fall back to the
        current context's endpoint (or the default)."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "cfg-key"\n')
        current = AuthContext(
            api_key="env-key", api_endpoint="https://custom-endpoint", source="env"
        )
        result = fallback_auth(current)
        assert result is not None
        assert result.api_key == "cfg-key"
        assert result.api_endpoint == "https://custom-endpoint"


class TestRecoverAuth:
    """Tests for the richer ``recover_auth`` function."""

    def test_sticky_stale_cleared_and_config_used(self, fake_config_dir: Path) -> None:
        """When _STICKY_AUTH holds a stale key and config has a new key,
        recovery clears the sticky cache and returns the config key."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "newest-key"\n')
        auth_mod._STICKY_AUTH = AuthContext(
            api_key="old-sticky", api_endpoint=DEFAULT_API_ENDPOINT, source="config"
        )
        rejected = AuthContext(
            api_key="old-sticky", api_endpoint=DEFAULT_API_ENDPOINT, source="config"
        )
        result = recover_auth(rejected)
        assert result is not None
        assert result.api_key == "newest-key"
        # Sticky auth should be cleared (recover_auth clears it)
        assert auth_mod._STICKY_AUTH is None

    def test_sticky_same_key_as_config_returns_none(self, fake_config_dir: Path) -> None:
        """When _STICKY_AUTH and config have the same key, no recovery."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "same-key"\n')
        auth_mod._STICKY_AUTH = AuthContext(
            api_key="same-key", api_endpoint=DEFAULT_API_ENDPOINT, source="config"
        )
        rejected = AuthContext(
            api_key="same-key", api_endpoint=DEFAULT_API_ENDPOINT, source="config"
        )
        result = recover_auth(rejected)
        assert result is None

    def test_config_source_rereads_rotated_key(self, fake_config_dir: Path) -> None:
        """When source is 'config' and the file now has a different key, use it."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "rotated-key"\n')
        rejected = AuthContext(
            api_key="original-key", api_endpoint=DEFAULT_API_ENDPOINT, source="config"
        )
        result = recover_auth(rejected)
        assert result is not None
        assert result.api_key == "rotated-key"

    def test_config_source_same_key_returns_none(self, fake_config_dir: Path) -> None:
        """When source is 'config' and the file still has the same key, no recovery."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "unchanged"\n')
        rejected = AuthContext(
            api_key="unchanged", api_endpoint=DEFAULT_API_ENDPOINT, source="config"
        )
        result = recover_auth(rejected)
        assert result is None

    def test_env_source_falls_back_to_config(
        self, monkeypatch: pytest.MonkeyPatch, fake_config_dir: Path
    ) -> None:
        """When source is 'env' and config has a different key, use config."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "cfg-key"\n')
        rejected = AuthContext(
            api_key="stale-env-key", api_endpoint=DEFAULT_API_ENDPOINT, source="env"
        )
        result = recover_auth(rejected)
        assert result is not None
        assert result.api_key == "cfg-key"
        assert result.source == "config"


class TestCurrentAuth:
    """Tests for ``current_auth``."""

    def test_returns_sticky_when_set(self, fake_config_dir: Path) -> None:
        sticky = AuthContext(
            api_key="sticky-key", api_endpoint=DEFAULT_API_ENDPOINT, source="config"
        )
        set_sticky_auth(sticky)
        assert current_auth() is sticky

    def test_resolves_when_no_sticky(
        self, monkeypatch: pytest.MonkeyPatch, fake_config_dir: Path
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "env-key")
        clear_sticky_auth()
        ctx = current_auth()
        assert ctx.api_key == "env-key"


class TestStickyAuthHelpers:
    """Tests for ``set_sticky_auth`` and ``clear_sticky_auth``."""

    def test_set_and_clear(self, fake_config_dir: Path) -> None:
        ctx = AuthContext(api_key="k", api_endpoint=DEFAULT_API_ENDPOINT, source="env")
        set_sticky_auth(ctx)
        assert auth_mod._STICKY_AUTH is ctx
        clear_sticky_auth()
        assert auth_mod._STICKY_AUTH is None
