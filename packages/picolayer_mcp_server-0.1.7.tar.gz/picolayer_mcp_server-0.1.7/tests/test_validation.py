"""Tests for picolayer_mcp.validation — picolayer.yml validator."""

from __future__ import annotations

from picolayer_mcp.validation import validate_config_string


def _ok(text: str) -> None:
    result = validate_config_string(text)
    assert result.ok, f"Unexpected errors: {result.errors}"


def _fail(text: str, expected_substr: str) -> None:
    result = validate_config_string(text)
    assert not result.ok, f"Expected failure for: {text}"
    assert any(expected_substr in e for e in result.errors), result.errors


class TestSimpleMode:
    def test_minimal_board(self) -> None:
        _ok("board: stm32f4_discovery\n")

    def test_unknown_board_fails(self) -> None:
        _fail("board: not_a_real_board\n", "Unknown board")

    def test_board_xor_hardware(self) -> None:
        _fail("board: nrf52840dk\nhardware:\n  cpu: cortex-m4f\n", "both")

    def test_neither_specified(self) -> None:
        _fail("timeout: 300\n", "either")


class TestHardwareMode:
    def test_minimal_hardware(self) -> None:
        _ok(
            """
hardware:
  cpu: cortex-m4f
  memory:
    flash:
      base: 0x08000000
      size: 1MB
    sram:
      base: 0x20000000
      size: 256KB
"""
        )

    def test_unknown_cpu_warns_not_errors(self) -> None:
        result = validate_config_string(
            """
hardware:
  cpu: cortex-m99
  memory:
    flash:
      base: 0x0
      size: 1MB
"""
        )
        assert result.ok
        assert any("not in the built-in CPU map" in w for w in result.warnings)

    def test_memory_overlap_detected(self) -> None:
        _fail(
            """
hardware:
  cpu: cortex-m4f
  memory:
    a:
      base: 0x20000000
      size: 256KB
    b:
      base: 0x20020000
      size: 256KB
""",
            "overlap",
        )

    def test_memory_no_overlap_passes(self) -> None:
        _ok(
            """
hardware:
  cpu: cortex-m4f
  memory:
    flash:
      base: 0x08000000
      size: 1MB
    sram:
      base: 0x20000000
      size: 256KB
"""
        )

    def test_peripheral_base_conflict_detected(self) -> None:
        _fail(
            """
hardware:
  cpu: cortex-m4f
  peripherals:
    uart0:
      type: uart
      base: 0x40000000
    timer0:
      type: timer
      base: 0x40000000
""",
            "register at 0x40000000",
        )

    def test_unknown_peripheral_type_warns(self) -> None:
        result = validate_config_string(
            """
hardware:
  cpu: cortex-m4f
  peripherals:
    crypto:
      type: aes_engine
      base: 0x50000000
"""
        )
        assert result.ok
        assert any("unknown type" in w for w in result.warnings)

    def test_uart_naming_consistency_warning(self) -> None:
        result = validate_config_string(
            """
hardware:
  cpu: cortex-m4f
  peripherals:
    uart0:
      type: gpio
      base: 0x40000000
"""
        )
        assert any("UART" in w for w in result.warnings)


class TestTimeout:
    def test_too_short(self) -> None:
        result = validate_config_string("board: nrf52840dk\ntimeout: 5\n")
        assert result.ok
        assert any("very short" in w for w in result.warnings)

    def test_too_long(self) -> None:
        result = validate_config_string("board: nrf52840dk\ntimeout: 7200\n")
        assert result.ok
        assert any("infrastructure max" in w for w in result.warnings)

    def test_negative(self) -> None:
        _fail("board: nrf52840dk\ntimeout: -1\n", "positive integer")


class TestEscapeHatches:
    def test_renode_block_marks_unverified(self) -> None:
        result = validate_config_string(
            """
board: stm32f4_discovery
renode:
  init_resc: |
    logLevel 0 sysbus.uart0
"""
        )
        assert result.ok
        assert result.escape_hatch_unverified

    def test_custom_peripheral_kind_validated(self) -> None:
        _fail(
            """
board: stm32f4_discovery
renode:
  custom_peripherals:
    - name: x
      kind: rust
      source: x.rs
""",
            "kind must be one of",
        )

    def test_custom_peripheral_register_at_syntax(self) -> None:
        _fail(
            """
board: stm32f4_discovery
renode:
  custom_peripherals:
    - name: x
      kind: python
      source: x.py
      register_at: not-a-real-syntax
""",
            "invalid syntax",
        )

    def test_custom_peripheral_register_at_valid(self) -> None:
        result = validate_config_string(
            """
board: stm32f4_discovery
renode:
  custom_peripherals:
    - name: x
      kind: python
      source: x.py
      register_at: "sysbus <0x50000000, +0x1000>"
"""
        )
        assert result.ok
        assert result.escape_hatch_unverified

    def test_cosim_invalid_simulator(self) -> None:
        _fail(
            """
board: stm32f4_discovery
renode:
  cosimulation:
    - name: x
      simulator: ghdl
      bus: axi4
      library: x.so
""",
            "simulator must be one of",
        )

    def test_cosim_direct_link_only_verilator(self) -> None:
        _fail(
            """
board: stm32f4_discovery
renode:
  cosimulation:
    - name: x
      simulator: questa
      mode: direct_link
      bus: axi4
      library: x.so
""",
            "direct_link",
        )

    def test_cosim_invalid_bus(self) -> None:
        _fail(
            """
board: stm32f4_discovery
renode:
  cosimulation:
    - name: x
      simulator: verilator
      bus: i2c
      library: x.so
""",
            "bus must be one of",
        )

    def test_machines_xor_board_hardware(self) -> None:
        _fail(
            """
board: stm32f4_discovery
renode:
  machines:
    - name: m1
      board: nrf52840dk
      hardware:
        cpu: cortex-m4f
""",
            "both 'board' and 'hardware'",
        )


class TestMultiMachine:
    def test_machines_only_config_passes(self) -> None:
        """Multi-device config with renode.machines and no top-level board."""
        result = validate_config_string(
            """
renode:
  machines:
    - name: hrm-sensor
      board: nrf52840dk
    - name: wrist-display
      board: nrf52840dk
  init_resc: |
    emulation CreateBLEMedium "ble"
timeout: 300
"""
        )
        assert result.ok, f"Unexpected errors: {result.errors}"
        assert result.escape_hatch_unverified

    def test_machines_without_board_or_hardware_fails(self) -> None:
        """A machine entry without board or hardware should fail."""
        _fail(
            """
renode:
  machines:
    - name: bad
""",
            "either 'board' or 'hardware'",
        )


class TestYamlErrors:
    def test_yaml_parse_error(self) -> None:
        _fail("board: [unclosed\n", "YAML parse error")

    def test_non_mapping_input(self) -> None:
        _fail("- not a map\n", "must be a YAML mapping")
