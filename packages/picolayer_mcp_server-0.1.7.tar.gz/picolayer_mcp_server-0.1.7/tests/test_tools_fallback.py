"""Tests for the 401-retry recovery logic in jobs._with_recovery and sessions._call_with_recovery.

The auth module maintains a shared ``_STICKY_AUTH`` sentinel that caches
a known-good auth context.  These tests verify:
  - A successful call returns directly without recovery.
  - A 401 with a valid recovery retries and succeeds.
  - A 401 with no valid recovery re-raises the original error.
  - A 401 when ``_STICKY_AUTH`` is already set clears it and re-resolves.
  - A 401 with config-source re-reads the config file for a rotated key.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

import pytest

from picolayer_mcp import auth as auth_mod
from picolayer_mcp.api_client import ApiError
from picolayer_mcp.auth import DEFAULT_API_ENDPOINT, AuthContext
from picolayer_mcp.tools import jobs as jobs_mod
from picolayer_mcp.tools import sessions as sessions_mod

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_auth(source: str = "env", key: str = "env-key") -> AuthContext:
    return AuthContext(api_key=key, api_endpoint=DEFAULT_API_ENDPOINT, source=source)


def _api_401() -> ApiError:
    return ApiError(status_code=401, detail="Unauthorized")


def _api_500() -> ApiError:
    return ApiError(status_code=500, detail="Internal Server Error")


# ---------------------------------------------------------------------------
# jobs._with_recovery
# ---------------------------------------------------------------------------


class TestJobsWithRecovery:
    """Unit tests for ``picolayer_mcp.tools.jobs._with_recovery``."""

    @pytest.fixture(autouse=True)
    def _reset_sticky(self) -> Iterator[None]:
        """Ensure each test starts with a clean _STICKY_AUTH."""
        auth_mod._STICKY_AUTH = None
        yield
        auth_mod._STICKY_AUTH = None

    def test_success_returns_result(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When the callable succeeds, the result passes through unchanged."""
        result = jobs_mod._with_recovery(lambda: {"ok": True})
        assert result == {"ok": True}

    def test_non_401_error_propagates(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Non-401 ApiErrors are not caught by the recovery logic."""

        def _boom() -> dict[str, Any]:
            raise _api_500()

        with pytest.raises(ApiError, match="500"):
            jobs_mod._with_recovery(_boom)

    def test_401_with_valid_fallback_retries(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """A 401 triggers a retry with config-file credentials when they
        differ from the env key."""
        monkeypatch.setenv("PICOLAYER_API_KEY", "stale-env-key")
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "fresh-cfg-key"\n')

        call_count = 0

        def _fn() -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise _api_401()
            return {"ok": True, "attempt": call_count}

        result = jobs_mod._with_recovery(_fn)
        assert result == {"ok": True, "attempt": 2}
        assert call_count == 2
        # Sticky auth should now be set to the config-file credentials
        assert auth_mod._STICKY_AUTH is not None
        assert auth_mod._STICKY_AUTH.source == "config"
        assert auth_mod._STICKY_AUTH.api_key == "fresh-cfg-key"

    def test_401_no_fallback_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """A 401 with no fallback available re-raises the original error."""
        monkeypatch.setenv("PICOLAYER_API_KEY", "only-key")
        # No config file written — recover_auth returns None

        def _fn() -> dict[str, Any]:
            raise _api_401()

        with pytest.raises(ApiError, match="401"):
            jobs_mod._with_recovery(_fn)

    def test_401_same_key_in_config_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """A 401 where env and config hold the same key does not retry."""
        monkeypatch.setenv("PICOLAYER_API_KEY", "same-key")
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "same-key"\n')

        def _fn() -> dict[str, Any]:
            raise _api_401()

        with pytest.raises(ApiError, match="401"):
            jobs_mod._with_recovery(_fn)

    def test_401_sticky_stale_clears_and_retries(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """When _STICKY_AUTH is stale and the config file has a new key,
        the sticky auth is cleared, the new key is used, and the retry
        succeeds."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "newest-key"\n')

        # Simulate a prior successful fallback with a now-stale key
        auth_mod._STICKY_AUTH = _make_auth(source="config", key="old-cfg-key")

        call_count = 0

        def _fn() -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise _api_401()
            return {"ok": True, "attempt": call_count}

        result = jobs_mod._with_recovery(_fn)
        assert result == {"ok": True, "attempt": 2}
        assert call_count == 2
        assert auth_mod._STICKY_AUTH is not None
        assert auth_mod._STICKY_AUTH.api_key == "newest-key"

    def test_401_sticky_same_key_as_config_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """When _STICKY_AUTH is set but config has the same key, 401 is
        re-raised (no infinite loop)."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "stale-key"\n')

        auth_mod._STICKY_AUTH = _make_auth(source="config", key="stale-key")

        call_count = 0

        def _fn() -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            raise _api_401()

        with pytest.raises(ApiError, match="401"):
            jobs_mod._with_recovery(_fn)
        assert call_count == 1

    def test_401_config_source_rereads_rotated_key(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """When source is 'config' and a 401 occurs, re-reading the config
        file picks up a key that was rotated on disk."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "original-key"\n')

        call_count = 0

        def _fn() -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # Simulate: user ran `picolayer login` between calls
                fake_config_dir.write_text('[auth]\napi_key = "rotated-key"\n')
                raise _api_401()
            return {"ok": True, "attempt": call_count}

        result = jobs_mod._with_recovery(_fn)
        assert result == {"ok": True, "attempt": 2}
        assert auth_mod._STICKY_AUTH is not None
        assert auth_mod._STICKY_AUTH.api_key == "rotated-key"


# ---------------------------------------------------------------------------
# sessions._call_with_recovery
# ---------------------------------------------------------------------------


class TestSessionsCallWithRecovery:
    """Unit tests for ``picolayer_mcp.tools.sessions._call_with_recovery``."""

    @pytest.fixture(autouse=True)
    def _reset_sticky(self) -> Iterator[None]:
        """Ensure each test starts with a clean _STICKY_AUTH."""
        auth_mod._STICKY_AUTH = None
        yield
        auth_mod._STICKY_AUTH = None

    def test_success_returns_result(self) -> None:
        """A successful call passes through without any recovery attempt."""

        def _fn(x: int) -> dict[str, Any]:
            return {"ok": True, "value": x}

        result = sessions_mod._call_with_recovery(_fn, (42,), {})
        assert result == {"ok": True, "value": 42}

    def test_non_401_error_propagates(self) -> None:
        """Non-401 ApiErrors bubble up immediately."""

        def _fn() -> dict[str, Any]:
            raise _api_500()

        with pytest.raises(ApiError, match="500"):
            sessions_mod._call_with_recovery(_fn, (), {})

    def test_401_with_valid_fallback_retries(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """A 401 triggers a retry with config-file credentials."""
        monkeypatch.setenv("PICOLAYER_API_KEY", "stale-env-key")
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "fresh-cfg-key"\n')

        call_count = 0

        def _fn(greeting: str) -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise _api_401()
            return {"ok": True, "msg": greeting}

        result = sessions_mod._call_with_recovery(_fn, ("hello",), {})
        assert result == {"ok": True, "msg": "hello"}
        assert call_count == 2
        assert auth_mod._STICKY_AUTH is not None
        assert auth_mod._STICKY_AUTH.source == "config"

    def test_401_no_fallback_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """A 401 with no available fallback re-raises."""
        monkeypatch.setenv("PICOLAYER_API_KEY", "only-key")

        def _fn() -> dict[str, Any]:
            raise _api_401()

        with pytest.raises(ApiError, match="401"):
            sessions_mod._call_with_recovery(_fn, (), {})

    def test_401_same_key_in_config_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """When env and config keys match, retrying would not help."""
        monkeypatch.setenv("PICOLAYER_API_KEY", "same-key")
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "same-key"\n')

        def _fn() -> dict[str, Any]:
            raise _api_401()

        with pytest.raises(ApiError, match="401"):
            sessions_mod._call_with_recovery(_fn, (), {})

    def test_401_sticky_stale_clears_and_retries(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """When _STICKY_AUTH is stale and config has new key, recovery
        clears the stale cache and retries with the new key."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "newest-key"\n')

        auth_mod._STICKY_AUTH = _make_auth(source="config", key="old-cfg-key")

        call_count = 0

        def _fn() -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise _api_401()
            return {"ok": True}

        result = sessions_mod._call_with_recovery(_fn, (), {})
        assert result == {"ok": True}
        assert call_count == 2
        assert auth_mod._STICKY_AUTH is not None
        assert auth_mod._STICKY_AUTH.api_key == "newest-key"

    def test_kwargs_forwarded_on_retry(
        self,
        monkeypatch: pytest.MonkeyPatch,
        fake_config_dir: Path,
    ) -> None:
        """Positional and keyword arguments are forwarded correctly on retry."""
        monkeypatch.setenv("PICOLAYER_API_KEY", "stale-key")
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "new-key"\n')

        call_count = 0

        def _fn(a: int, *, b: str = "default") -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise _api_401()
            return {"ok": True, "a": a, "b": b}

        result = sessions_mod._call_with_recovery(_fn, (1,), {"b": "custom"})
        assert result == {"ok": True, "a": 1, "b": "custom"}
        assert call_count == 2

    def test_401_config_source_rereads_rotated_key(
        self,
        fake_config_dir: Path,
    ) -> None:
        """When source is 'config' and the config file key changed on disk,
        the rotated key is used for the retry."""
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "original-key"\n')

        call_count = 0

        def _fn() -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # Simulate user running `picolayer login`
                fake_config_dir.write_text('[auth]\napi_key = "rotated-key"\n')
                raise _api_401()
            return {"ok": True}

        result = sessions_mod._call_with_recovery(_fn, (), {})
        assert result == {"ok": True}
        assert call_count == 2
        assert auth_mod._STICKY_AUTH is not None
        assert auth_mod._STICKY_AUTH.api_key == "rotated-key"
