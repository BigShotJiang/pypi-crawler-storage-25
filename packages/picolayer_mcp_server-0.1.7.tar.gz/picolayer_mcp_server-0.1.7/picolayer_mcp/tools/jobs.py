"""MCP tools for the existing job (Use Case A) flow."""

from __future__ import annotations

import base64
from collections.abc import Callable
from typing import Any

from picolayer_mcp.api_client import ApiError, PicolayerApiClient
from picolayer_mcp.auth import (
    AuthError,
    current_auth,
    recover_auth,
    set_sticky_auth,
)
from picolayer_mcp.git_context import collect_git_context


def _client() -> PicolayerApiClient:
    auth = current_auth()
    return PicolayerApiClient(api_key=auth.api_key, base_url=auth.api_endpoint)


def _with_recovery[T](fn: Callable[[], T]) -> T:
    """Run ``fn``; on 401 retry once with recovered credentials."""
    # Snapshot the auth that will be used for this request so we can
    # compare against it after a 401.  If auth resolution itself fails,
    # let fn surface the error naturally.
    try:
        used_auth = current_auth()
    except AuthError:
        return fn()
    try:
        return fn()
    except ApiError as exc:
        if exc.status_code != 401:
            raise
        recovered = recover_auth(used_auth)
        if recovered is None:
            raise
        set_sticky_auth(recovered)
        return fn()


def submit_job(
    firmware_b64: str,
    firmware_name: str,
    test_script_b64: str,
    test_script_name: str,
    *,
    test_type: str = "auto",
    timeout_seconds: int | None = None,
    picolayer_config: str | None = None,
) -> dict[str, Any]:
    """Submit a fire-and-forget test job (Use Case A — CI/CD flow).

    Firmware and test script are passed as base64-encoded blobs so an agent
    can submit a job without needing filesystem access on the host.
    """
    try:
        firmware_bytes = base64.b64decode(firmware_b64, validate=True)
        test_script_bytes = base64.b64decode(test_script_b64, validate=True)
    except (ValueError, TypeError) as exc:
        return {"ok": False, "error": f"base64 decode failed: {exc}"}

    git = collect_git_context()

    def _do() -> dict[str, Any]:
        with _client() as client:
            firmware_url = client.upload_file_bytes(firmware_name, firmware_bytes)
            test_script_url = client.upload_file_bytes(test_script_name, test_script_bytes)
            job = client.submit_job(
                firmware_url=firmware_url,
                test_script=test_script_name,
                test_script_url=test_script_url,
                test_type=test_type,
                timeout_seconds=timeout_seconds,
                picolayer_config=picolayer_config,
                github_repo=git.repo,
                github_ref=git.ref,
            )
            return {
                "ok": True,
                "job_id": job.job_id,
                "status": job.status,
            }

    try:
        return _with_recovery(_do)
    except (AuthError, ApiError) as exc:
        return {"ok": False, "error": str(exc)}


def get_job(job_id: str) -> dict[str, Any]:
    """Fetch the current status, result, and output of a job."""

    def _do() -> dict[str, Any]:
        with _client() as client:
            job = client.get_job(job_id)
            return {
                "ok": True,
                "job_id": job.job_id,
                "status": job.status,
                "result": job.result,
                "output": job.output,
                "error_message": job.error_message,
                "test_type": job.test_type,
            }

    try:
        return _with_recovery(_do)
    except (AuthError, ApiError) as exc:
        return {"ok": False, "error": str(exc)}


def list_jobs(status: str | None = None, limit: int = 25) -> dict[str, Any]:
    """List the current tenant's recent jobs, optionally filtered by status."""

    def _do() -> dict[str, Any]:
        with _client() as client:
            jobs = client.list_jobs(status=status, limit=limit)
            return {
                "ok": True,
                "jobs": [
                    {
                        "job_id": j.job_id,
                        "status": j.status,
                        "result": j.result,
                    }
                    for j in jobs
                ],
            }

    try:
        return _with_recovery(_do)
    except (AuthError, ApiError) as exc:
        return {"ok": False, "error": str(exc)}


def get_artifacts(job_id: str) -> dict[str, Any]:
    """List a job's artifacts with presigned download URLs."""

    def _do() -> dict[str, Any]:
        with _client() as client:
            artifacts = client.get_artifacts(job_id)
            return {
                "ok": True,
                "job_id": artifacts.job_id,
                "is_streaming": artifacts.is_streaming,
                "artifacts": [
                    {
                        "name": a.name,
                        "size_bytes": a.size_bytes,
                        "content_type": a.content_type,
                        "download_url": a.download_url,
                    }
                    for a in artifacts.artifacts
                ],
            }

    try:
        return _with_recovery(_do)
    except (AuthError, ApiError) as exc:
        return {"ok": False, "error": str(exc)}
