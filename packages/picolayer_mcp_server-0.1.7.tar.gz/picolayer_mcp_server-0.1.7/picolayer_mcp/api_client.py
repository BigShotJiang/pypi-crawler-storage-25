"""HTTP client for the Picolayer REST API.

Mirrors ``cli/picolayer/api_client.py`` so the MCP server and CLI hit the
same endpoints with the same auth pattern.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


class ApiError(Exception):
    """Raised when the API returns an error response."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"API error {status_code}: {detail}")


@dataclass
class JobInfo:
    """Subset of job fields used by MCP tools."""

    job_id: str
    status: str
    result: str | None = None
    output: str | None = None
    error_message: str | None = None
    test_type: str | None = None


@dataclass
class ArtifactInfo:
    name: str
    size_bytes: int
    content_type: str
    download_url: str


@dataclass
class ArtifactList:
    job_id: str
    artifacts: list[ArtifactInfo]
    is_streaming: bool


class PicolayerApiClient:
    """Thin wrapper around the Picolayer REST API."""

    def __init__(self, api_key: str, base_url: str, timeout: float = 30.0) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> PicolayerApiClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.status_code >= 400:
            try:
                body = resp.json()
                detail = body.get("detail", body.get("message", resp.text))
            except Exception:
                detail = resp.text
            raise ApiError(resp.status_code, str(detail))

    # ── Jobs ───────────────────────────────────────────────────────────

    def upload_file_bytes(self, name: str, content: bytes) -> str:
        """Upload raw bytes to the API and return a presigned download URL."""
        resp = self._client.post(
            "/api/v1/upload",
            files={"file": (name, content)},
        )
        self._raise_for_status(resp)
        return str(resp.json()["url"])

    def submit_job(
        self,
        *,
        firmware_url: str,
        test_script: str = "test.robot",
        test_script_url: str | None = None,
        test_type: str = "auto",
        timeout_seconds: int | None = None,
        picolayer_config: str | None = None,
        github_repo: str | None = None,
        github_ref: str | None = None,
        github_run_id: int | None = None,
    ) -> JobInfo:
        body: dict[str, Any] = {
            "firmware_url": firmware_url,
            "test_script": test_script,
            "test_type": test_type,
        }
        if test_script_url:
            body["test_script_url"] = test_script_url
        if timeout_seconds:
            body["timeout_seconds"] = timeout_seconds
        if picolayer_config:
            body["picolayer_config"] = picolayer_config
        if github_repo:
            body["github_repo"] = github_repo
        if github_ref:
            body["github_ref"] = github_ref
        if github_run_id is not None:
            body["github_run_id"] = github_run_id
        resp = self._client.post("/api/v1/jobs", json=body)
        self._raise_for_status(resp)
        return _to_job_info(resp.json())

    def get_job(self, job_id: str) -> JobInfo:
        resp = self._client.get(f"/api/v1/jobs/{job_id}")
        self._raise_for_status(resp)
        return _to_job_info(resp.json())

    def list_jobs(
        self,
        *,
        status: str | None = None,
        limit: int = 25,
    ) -> list[JobInfo]:
        params: dict[str, str | int] = {"limit": limit}
        if status:
            params["status"] = status
        resp = self._client.get("/api/v1/jobs", params=params)
        self._raise_for_status(resp)
        data = resp.json()
        items = data.get("jobs") if isinstance(data, dict) else data
        if not isinstance(items, list):
            return []
        return [_to_job_info(item) for item in items]

    def get_artifacts(self, job_id: str) -> ArtifactList:
        resp = self._client.get(f"/api/v1/jobs/{job_id}/artifacts")
        self._raise_for_status(resp)
        data = resp.json()
        artifacts = [
            ArtifactInfo(
                name=a["name"],
                size_bytes=a["size_bytes"],
                content_type=a["content_type"],
                download_url=a["download_url"],
            )
            for a in data["artifacts"]
        ]
        return ArtifactList(
            job_id=data["job_id"],
            artifacts=artifacts,
            is_streaming=data.get("is_streaming", False),
        )

    # ── Sessions (P1 — added later, calls fail gracefully until backend ships) ──

    def create_session(self, body: dict[str, Any]) -> dict[str, Any]:
        resp = self._client.post("/api/v1/sessions", json=body)
        self._raise_for_status(resp)
        return dict(resp.json())

    def get_session(self, session_id: str) -> dict[str, Any]:
        resp = self._client.get(f"/api/v1/sessions/{session_id}")
        self._raise_for_status(resp)
        return dict(resp.json())

    def list_sessions(self, **params: Any) -> list[dict[str, Any]]:
        resp = self._client.get("/api/v1/sessions", params=params)
        self._raise_for_status(resp)
        data = resp.json()
        if isinstance(data, dict) and "sessions" in data:
            data = data["sessions"]
        return list(data) if isinstance(data, list) else []

    def destroy_session(self, session_id: str) -> dict[str, Any]:
        resp = self._client.delete(f"/api/v1/sessions/{session_id}")
        self._raise_for_status(resp)
        return dict(resp.json()) if resp.text else {}

    def session_proxy(
        self, session_id: str, path: str, method: str = "POST", **kwargs: Any
    ) -> dict[str, Any]:
        """Generic proxy to a session container endpoint."""
        url = f"/api/v1/sessions/{session_id}{path}"
        resp = self._client.request(method, url, **kwargs)
        self._raise_for_status(resp)
        return dict(resp.json()) if resp.text else {}


def _to_job_info(data: dict[str, Any]) -> JobInfo:
    return JobInfo(
        job_id=str(data["job_id"]),
        status=str(data.get("status", "unknown")),
        result=data.get("result"),
        output=data.get("output"),
        error_message=data.get("error_message"),
        test_type=data.get("test_type"),
    )
