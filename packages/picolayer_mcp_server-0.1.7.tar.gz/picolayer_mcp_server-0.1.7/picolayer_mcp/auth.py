"""API key resolution for the Picolayer MCP server.

Resolution order:
  1. ``PICOLAYER_API_KEY`` environment variable
  2. ``~/.picolayer/config.toml`` (what ``picolayer login`` writes)

The same fallback applies to ``PICOLAYER_API_ENDPOINT``.

Stale-credential recovery: the MCP server is a long-running process, so
credentials can go stale after the user runs ``picolayer login`` to rotate
their key.  :func:`recover_auth` handles this by:

  - **env → config** — if the env-var key is rejected, retry with
    whatever is in the config file (the user ran ``picolayer login``
    after launching the server with a stale env var).
  - **config re-read** — if the config-file key is rejected, re-read
    the file; if the key changed on disk the new one is used.
  - **sticky-auth invalidation** — if the cached ``_STICKY_AUTH`` is
    rejected, clear it and fall through to a fresh ``resolve_auth()``.

All tool modules share a single ``_STICKY_AUTH`` sentinel stored here so
the fallback state is consistent across jobs, sessions, and any future
tool modules.
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path

DEFAULT_API_ENDPOINT = "https://api.picolayer.dev"
CONFIG_PATH = Path.home() / ".picolayer" / "config.toml"


class AuthError(Exception):
    """Raised when no API key can be located."""


@dataclass(frozen=True)
class AuthContext:
    """Resolved API key + endpoint."""

    api_key: str
    api_endpoint: str
    source: str = "env"  # "env" | "config" — for diagnostics


# Process-wide cached auth.  Once a fallback or recovery succeeds, the
# winning AuthContext is stored here so subsequent tool calls skip the
# env/config resolution dance.  Cleared on 401 so a fresh read can pick
# up a rotated key.
_STICKY_AUTH: AuthContext | None = None


def _read_config_file() -> dict[str, object]:
    if not CONFIG_PATH.exists():
        return {}
    try:
        with open(CONFIG_PATH, "rb") as f:
            return tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):  # fmt: skip
        return {}


def _config_auth() -> tuple[str | None, str | None]:
    """Return ``(api_key, api_endpoint)`` from ``~/.picolayer/config.toml``."""
    cfg = _read_config_file()
    auth_section = cfg.get("auth", {})
    if not isinstance(auth_section, dict):
        return None, None
    api_key_value = auth_section.get("api_key")
    api_key = str(api_key_value) if isinstance(api_key_value, str) else None
    api_endpoint_value = auth_section.get("api_endpoint")
    api_endpoint = str(api_endpoint_value) if isinstance(api_endpoint_value, str) else None
    return api_key, api_endpoint


def resolve_auth() -> AuthContext:
    """Resolve API credentials from env or the CLI's shared config file."""
    api_key = os.environ.get("PICOLAYER_API_KEY")
    api_endpoint = os.environ.get("PICOLAYER_API_ENDPOINT")
    source = "env" if api_key else "config"

    if not api_key or not api_endpoint:
        cfg_key, cfg_endpoint = _config_auth()
        if not api_key and cfg_key:
            api_key = cfg_key
            source = "config"
        if not api_endpoint and cfg_endpoint:
            api_endpoint = cfg_endpoint

    if not api_key:
        raise AuthError(
            "No Picolayer API key found. Set PICOLAYER_API_KEY or run `picolayer login`."
        )

    return AuthContext(
        api_key=api_key,
        api_endpoint=api_endpoint or DEFAULT_API_ENDPOINT,
        source=source,
    )


def current_auth() -> AuthContext:
    """Return the best-known auth context.

    If a previous fallback stored a sticky override, return that;
    otherwise resolve fresh from env / config file.
    """
    if _STICKY_AUTH is not None:
        return _STICKY_AUTH
    return resolve_auth()


def recover_auth(rejected: AuthContext) -> AuthContext | None:
    """Try to find a working auth context after a 401 rejection.

    Recovery strategies (tried in order):

    1. If ``_STICKY_AUTH`` was used, clear it and re-resolve from env /
       config.  The config file may have been updated since the sticky
       value was cached.
    2. If the rejected context came from the env var, try the config
       file (the classic "stale env" scenario).
    3. If the rejected context came from the config file, re-read the
       file.  If the key on disk differs from the rejected key (the
       user ran ``picolayer login``), use the new key.

    Returns ``None`` when no alternative credentials are available.
    """
    global _STICKY_AUTH  # noqa: PLW0603

    # 1. Sticky auth is stale — clear and re-resolve.
    if _STICKY_AUTH is not None:
        stale_key = _STICKY_AUTH.api_key
        _STICKY_AUTH = None
        fresh = resolve_auth()
        if fresh.api_key != stale_key:
            return fresh
        # Re-resolved key is the same; fall through to source-based
        # recovery below using the fresh context.
        rejected = fresh

    # 2. Env → config fallback.
    if rejected.source == "env":
        cfg_key, cfg_endpoint = _config_auth()
        if cfg_key and cfg_key != rejected.api_key:
            return AuthContext(
                api_key=cfg_key,
                api_endpoint=cfg_endpoint or rejected.api_endpoint or DEFAULT_API_ENDPOINT,
                source="config",
            )

    # 3. Config re-read (key may have been rotated on disk).
    if rejected.source == "config":
        cfg_key, cfg_endpoint = _config_auth()
        if cfg_key and cfg_key != rejected.api_key:
            return AuthContext(
                api_key=cfg_key,
                api_endpoint=cfg_endpoint or rejected.api_endpoint or DEFAULT_API_ENDPOINT,
                source="config",
            )

    return None


def set_sticky_auth(ctx: AuthContext) -> None:
    """Cache a known-good auth context so subsequent calls skip resolution."""
    global _STICKY_AUTH  # noqa: PLW0603
    _STICKY_AUTH = ctx


def clear_sticky_auth() -> None:
    """Clear the cached auth context (for testing or manual invalidation)."""
    global _STICKY_AUTH  # noqa: PLW0603
    _STICKY_AUTH = None


# ── Backwards compatibility ───────────────────────────────────────────
# ``fallback_auth`` is kept for any external callers but now delegates
# to the richer ``recover_auth`` logic.


def fallback_auth(current: AuthContext) -> AuthContext | None:
    """Return a second chance at authentication after a 401.

    Delegates to :func:`recover_auth`.
    """
    return recover_auth(current)
