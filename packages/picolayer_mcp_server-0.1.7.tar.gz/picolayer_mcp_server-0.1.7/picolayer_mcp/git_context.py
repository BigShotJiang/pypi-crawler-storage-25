"""Best-effort git context detection for run submissions from agents.

When an AI agent (or any MCP client) submits a job, the dashboard's Run
History page benefits from knowing *where* the job came from. This module
shells out to ``git`` in the cwd of the MCP server process — typically the
same project directory the agent is editing — and returns whatever it can.
All failures are silent: git context is optional, never required.

Mirrors ``cli/picolayer/git_context.py`` so both code paths populate the
same fields the API already accepts.
"""

from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class GitContext:
    """Snapshot of the git state at the cwd at submission time."""

    repo: str | None = None
    ref: str | None = None
    sha: str | None = None


_GITHUB_RE = re.compile(
    r"""
    (?:git@github\.com:|https?://github\.com/|ssh://git@github\.com/)
    (?P<owner>[^/]+)/
    (?P<name>[^/]+?)
    (?:\.git)?$
    """,
    re.VERBOSE,
)


def collect_git_context(cwd: Path | None = None) -> GitContext:
    """Return git metadata for ``cwd`` (defaults to the current directory)."""
    workdir = Path(cwd) if cwd is not None else Path.cwd()

    if not _is_git_repo(workdir):
        return GitContext(repo=f"local:{workdir.name}")

    repo = _parse_remote(_run(workdir, "config", "--get", "remote.origin.url"))
    ref = _run(workdir, "symbolic-ref", "--short", "HEAD") or _run(
        workdir, "rev-parse", "--short", "HEAD"
    )
    sha = _run(workdir, "rev-parse", "HEAD")

    return GitContext(
        repo=repo or f"local:{workdir.name}",
        ref=ref or None,
        sha=sha or None,
    )


def _is_git_repo(workdir: Path) -> bool:
    return _run(workdir, "rev-parse", "--is-inside-work-tree") == "true"


def _run(workdir: Path, *args: str) -> str | None:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(workdir),
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    out = result.stdout.strip()
    return out or None


def _parse_remote(remote: str | None) -> str | None:
    if not remote:
        return None
    match = _GITHUB_RE.search(remote)
    if match:
        return f"{match.group('owner')}/{match.group('name')}"
    cleaned = remote.removesuffix(".git").strip()
    return cleaned or None
