"""
Legacy choices for backward compatibility.

The onboarding flow now uses interest presets (see profile.py TUI screen).
"""

# Keep TOPIC_CHOICES available — imported by commands/config.py for topic editing.
TOPIC_CHOICES = [
    {"name": "Python", "value": "python"},
    {"name": "Java", "value": "java"},
    {"name": "JavaScript", "value": "javascript"},
    {"name": "Go", "value": "go"},
    {"name": "Rust", "value": "rust"},
    {"name": "C / C++", "value": "c"},
    {"name": "TypeScript", "value": "typescript"},
    {"name": "SQL", "value": "sql"},
    {"name": "Kubernetes", "value": "kubernetes"},
    {"name": "Docker", "value": "docker"},
    {"name": "Terraform", "value": "terraform"},
    {"name": "AWS", "value": "aws"},
    {"name": "CI/CD", "value": "cicd"},
    {"name": "Linux", "value": "linux"},
    {"name": "Spark", "value": "spark"},
    {"name": "Kafka", "value": "kafka"},
    {"name": "Airflow", "value": "airflow"},
    {"name": "Data Modeling", "value": "data-modeling"},
    {"name": "PyTorch", "value": "pytorch"},
    {"name": "LLMs", "value": "llms"},
    {"name": "Deep Learning", "value": "deep-learning"},
    {"name": "Machine Learning", "value": "machine-learning"},
    {"name": "REST APIs", "value": "rest-api"},
    {"name": "Redis", "value": "redis"},
    {"name": "Spring Boot", "value": "spring-boot"},
    {"name": "Distributed Systems", "value": "distributed-systems"},
    {"name": "DSA", "value": "dsa"},
    {"name": "Design Patterns", "value": "patterns"},
    {"name": "System Design", "value": "system-design"},
    {"name": "Git", "value": "git"},
    {"name": "Maven", "value": "maven"},
    {"name": "Bazel", "value": "bazel"},
]
