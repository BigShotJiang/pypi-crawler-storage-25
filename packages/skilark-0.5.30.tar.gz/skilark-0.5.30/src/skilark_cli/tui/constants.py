"""Shared constants for TUI widgets."""

DIFFICULTY_STARS = {1: "★☆☆", 2: "★★☆", 3: "★★★"}
