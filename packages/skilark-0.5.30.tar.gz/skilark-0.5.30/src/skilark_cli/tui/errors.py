"""User-friendly error messages for TUI screens."""

import httpx


def friendly_error_message(exc: Exception) -> str:
    """Convert an exception into a friendly message for display."""
    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        if status == 429:
            return "Slow down! Please wait a moment and try again."
        if status == 503:
            return "Service temporarily unavailable. Please try again shortly."
        if status >= 500:
            return "Server error — please try again in a moment."
        if status == 404:
            return "Not found."
        return f"Request failed (HTTP {status}). Please try again."
    if isinstance(exc, httpx.TimeoutException):
        return "Request timed out. Check your connection and try again."
    if isinstance(exc, (httpx.ConnectError, ConnectionError)):
        return "Could not connect to Skilark. Check your network connection."
    return "Something unexpected happened. Please try again."
