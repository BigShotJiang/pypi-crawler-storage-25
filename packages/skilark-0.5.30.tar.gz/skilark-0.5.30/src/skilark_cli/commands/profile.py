"""
`skilark profile` command.

Shows the user's current profile. For interest editing, use the TUI
(`skilark` with no arguments).
"""

import logging

from rich.console import Console

from skilark_cli.config_store import ConfigStore

console = Console()
logger = logging.getLogger(__name__)


def run() -> None:
    """Show profile summary and direct users to the TUI for editing."""
    config_store = ConfigStore()

    if config_store.is_first_run():
        console.print("[yellow]Run [bold]skilark login[/bold] to sign in first.[/yellow]")
        return

    config = config_store.load()

    topics = config.get("topics", [])

    console.print()
    console.print("[bold]Your profile[/bold]")
    console.print(f"  Topics: {', '.join(topics) if topics else '(none)'}")
    console.print()
    console.print("[dim]To edit your interests, run [bold]skilark[/bold] (TUI) and open the Profile tab.[/dim]")
    console.print()
