"""Tests for TUI error message helper."""

import httpx

from skilark_cli.tui.errors import friendly_error_message


class TestFriendlyErrorMessage:
    def test_rate_limit_429(self):
        response = httpx.Response(429, json={"error": "rate limit exceeded"})
        exc = httpx.HTTPStatusError("", request=httpx.Request("GET", "http://x"), response=response)
        msg = friendly_error_message(exc)
        assert "rate limit" in msg.lower() or "slow down" in msg.lower()
        assert "429" not in msg  # no raw status code

    def test_server_error_500(self):
        response = httpx.Response(500)
        exc = httpx.HTTPStatusError("", request=httpx.Request("GET", "http://x"), response=response)
        msg = friendly_error_message(exc)
        assert "try again" in msg.lower()

    def test_server_error_503(self):
        response = httpx.Response(503)
        exc = httpx.HTTPStatusError("", request=httpx.Request("GET", "http://x"), response=response)
        msg = friendly_error_message(exc)
        assert "unavailable" in msg.lower() or "try again" in msg.lower()

    def test_connection_error(self):
        exc = httpx.ConnectError("Connection refused")
        msg = friendly_error_message(exc)
        assert "connection" in msg.lower() or "network" in msg.lower()

    def test_timeout_error(self):
        exc = httpx.ReadTimeout("timed out")
        msg = friendly_error_message(exc)
        assert "timed out" in msg.lower() or "timeout" in msg.lower()

    def test_generic_exception(self):
        exc = RuntimeError("something broke")
        msg = friendly_error_message(exc)
        assert "something broke" not in msg  # no raw exception leak
        assert "unexpected" in msg.lower() or "try again" in msg.lower()
