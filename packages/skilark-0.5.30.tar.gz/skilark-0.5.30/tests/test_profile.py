"""
Tests for the simplified `skilark profile` command.

The command now shows topics and directs users to the TUI for interest
editing.  Role/language/direction editing has been removed.
"""

from unittest.mock import MagicMock, patch

from skilark_cli.commands.profile import run
from skilark_cli.config_store import ConfigStore


def _setup_store(tmp_path, *, topics=None):
    """Create a ConfigStore with optional topics."""
    store = ConfigStore(config_dir=tmp_path)
    store.save(
        user_id="test-uuid",
        topics=["python", "dsa"] if topics is None else topics,
        api_url="http://localhost:8000",
    )
    return store


def test_first_run_prints_hint(tmp_path, capsys):
    """First-run (no config) prints login hint and returns."""
    with patch("skilark_cli.commands.profile.ConfigStore") as mock_cls:
        mock_store = MagicMock()
        mock_store.is_first_run.return_value = True
        mock_cls.return_value = mock_store

        run()

        # Should not crash; prints a hint message.
        mock_store.load.assert_not_called()


def test_shows_topics(tmp_path, capsys):
    """Profile display shows topics list."""
    store = _setup_store(tmp_path, topics=["python", "go"])

    with patch("skilark_cli.commands.profile.ConfigStore", return_value=store):
        run()

    captured = capsys.readouterr()
    assert "python" in captured.out
    assert "go" in captured.out


def test_shows_tui_hint(tmp_path, capsys):
    """Profile display shows hint to use TUI for editing."""
    store = _setup_store(tmp_path)

    with patch("skilark_cli.commands.profile.ConfigStore", return_value=store):
        run()

    captured = capsys.readouterr()
    assert "TUI" in captured.out or "Profile tab" in captured.out


def test_shows_none_when_no_topics(tmp_path, capsys):
    """Profile display shows (none) when topics list is empty."""
    store = _setup_store(tmp_path, topics=[])

    with patch("skilark_cli.commands.profile.ConfigStore", return_value=store):
        run()

    captured = capsys.readouterr()
    assert "(none)" in captured.out
