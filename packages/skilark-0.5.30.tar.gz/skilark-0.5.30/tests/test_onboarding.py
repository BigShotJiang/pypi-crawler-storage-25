"""
Tests for onboarding legacy choices.

ROLE_CHOICES, LANGUAGE_CHOICES, DIRECTION_CHOICES, and derive_topics have
been removed.  Identity is now established via `skilark login` (OAuth) and
interests are managed through interest presets.
"""

from skilark_cli.config_store import ConfigStore
from skilark_cli.onboarding import TOPIC_CHOICES


def test_topic_choices_cover_key_sources():
    values = {t["value"] for t in TOPIC_CHOICES}
    assert "python" in values
    assert "java" in values
    assert "go" in values
    assert "docker" in values
    assert "kubernetes" in values
    assert "dsa" in values
    assert "sql" in values


def test_config_store_has_profile(tmp_path):
    store = ConfigStore(config_dir=tmp_path)
    assert not store.has_profile()

    store.save(user_id="test-id", topics=["python"], api_url="http://localhost:8000")
    assert not store.has_profile()

    store.update_profile(current_role="swe")
    assert store.has_profile()
