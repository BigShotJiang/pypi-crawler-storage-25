"""
uk-legal-mcp gateway

Single FastMCP v3 gateway that mounts all eight legal research sub-modules in-process.
One deployed service. One MCP connection. 24 tools across 8 namespaced modules.

Architecture:
  gateway
  ├── case_law     (namespace: case_law_)     — TNA Find Case Law
  ├── legislation  (namespace: legislation_)  — legislation.gov.uk + i.AI Lex API
  ├── parliament   (namespace: parliament_)   — Hansard + Members + Petitions
  ├── bills        (namespace: bills_)        — Parliamentary Bills API
  ├── votes        (namespace: votes_)        — Commons + Lords division records
  ├── committees   (namespace: committees_)   — Select committees + evidence
  ├── citations    (namespace: citations_)    — OSCOLA parser (self-contained ★)
  └── hmrc         (namespace: hmrc_)         — VAT rates, MTD, GOV.UK guidance

Transport: Streamable HTTP, port 8000
Region:    lhr (London) — co-located with UK legal data sources
"""

import asyncio
import logging
import os
import time

from fastmcp import FastMCP
from fastmcp.server.middleware import Middleware, MiddlewareContext
from fastmcp.server.middleware.caching import (
    CallToolSettings,
    ReadResourceSettings,
    ResponseCachingMiddleware,
)
from fastmcp.server.middleware.error_handling import ErrorHandlingMiddleware
from fastmcp.server.middleware.logging import StructuredLoggingMiddleware
from fastmcp.server.middleware.timing import DetailedTimingMiddleware
from fastmcp.server.transforms import PromptsAsTools
from prometheus_client import CONTENT_TYPE_LATEST, Counter as PromCounter, Histogram, generate_latest
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from curl_cffi.requests import AsyncSession as CurlAsyncSession

from .deps import LegislationClient, LegislationUpstreamError, http_lifespan
from typing import Annotated

from pydantic import Field

from .modules.bills import bills_mcp
from .modules.case_law import case_law_mcp
from .modules.case_law.resources import TNA_BASE, register_case_law_resources
from .modules.case_law import parsers as case_law_parsers
from .modules.citations import citations_mcp
from .modules.committees import committees_mcp
from .modules.hmrc import hmrc_mcp
from .modules.legislation import legislation_mcp
from .modules.legislation.resources import (
    LEGISLATION_BASE,
    _parse_toc,
    register_legislation_resources,
)
from .modules.parliament import parliament_mcp
from .modules.votes import votes_mcp

# ---------------------------------------------------------------------------
# Prometheus metrics
# ---------------------------------------------------------------------------

TRANSPORT = os.getenv("FASTMCP_TRANSPORT", "http")
REGION = os.getenv("FLY_REGION", "local")

tool_calls_total = PromCounter(
    "uk_legal_tool_calls_total",
    "Count of MCP tool invocations.",
    labelnames=["tool", "transport", "region", "status"],
)
tool_duration_seconds = Histogram(
    "uk_legal_tool_duration_seconds",
    "Tool invocation latency in seconds.",
    labelnames=["tool", "transport", "region"],
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
)
client_connections_total = PromCounter(
    "uk_legal_client_connections_total",
    "Count of MCP client initialize handshakes.",
    labelnames=["client_name", "client_version", "transport", "region"],
)

_log = logging.getLogger("fastmcp.uk_legal_mcp.clients")


class ClientTrackingMiddleware(Middleware):
    """Log clientInfo and increment connection counter on every initialize."""

    async def on_request(self, context: MiddlewareContext, call_next):
        result = await call_next(context)
        if context.method == "initialize":
            params = context.message.params
            info = getattr(params, "clientInfo", None)
            client_name = getattr(info, "name", "unknown") or "unknown"
            client_version = getattr(info, "version", "unknown") or "unknown"
            caps = getattr(params, "capabilities", None)
            cap_keys = [k for k, v in (caps.model_dump().items() if caps else []) if v is not None]
            _log.info("client_connected client=%s version=%s capabilities=%s transport=%s region=%s",
                      client_name, client_version, cap_keys, TRANSPORT, REGION)
            client_connections_total.labels(client_name, client_version, TRANSPORT, REGION).inc()
        return result


class PrometheusMiddleware(Middleware):
    """Emit fleet-standard Prometheus metrics on every tool call."""

    async def on_call_tool(self, context: MiddlewareContext, call_next):
        tool_name = context.message.name
        t0 = time.perf_counter()
        try:
            result = await call_next(context)
            tool_calls_total.labels(tool_name, TRANSPORT, REGION, "ok").inc()
            return result
        except BaseException:
            tool_calls_total.labels(tool_name, TRANSPORT, REGION, "error").inc()
            raise
        finally:
            tool_duration_seconds.labels(tool_name, TRANSPORT, REGION).observe(
                time.perf_counter() - t0
            )

# ---------------------------------------------------------------------------
# Gateway server
# ---------------------------------------------------------------------------

gateway = FastMCP(
    name="uk-legal-mcp",
    lifespan=http_lifespan,
    instructions=(
        "UK legal research server. Eight namespaced modules:\n\n"
        "• case_law_search / case_law_grep_judgment\n"
        "  Search UK court judgments from TNA Find Case Law and grep within them.\n"
        "  Read judgment content via judgment://{slug}/{header,index,para/{eId}} resources.\n\n"
        "• legislation_search / legislation_get_toc / legislation_get_section\n"
        "  Find Acts of Parliament and Statutory Instruments. Always check 'extent' field.\n\n"
        "• parliament_search_hansard / parliament_vibe_check / parliament_find_member / parliament_member_interests / parliament_search_petitions\n"
        "  Search Hansard debates, assess parliamentary reception, member interests, and petitions.\n\n"
        "• bills_search_bills / bills_get_bill\n"
        "  Search and retrieve UK parliamentary bills, stages, and sponsors.\n\n"
        "• votes_search_divisions / votes_get_division\n"
        "  Search Commons and Lords division records. See how members voted.\n\n"
        "• committees_search_committees / committees_get_committee / committees_search_evidence\n"
        "  Search select committees, membership, and evidence submissions.\n\n"
        "• citations_parse / citations_resolve / citations_network\n"
        "  Parse OSCOLA legal citations from free text. Resolve to canonical URLs.\n"
        "  Fully self-contained — no API key required.\n\n"
        "• hmrc_get_vat_rate / hmrc_check_mtd_status / hmrc_search_guidance\n"
        "  UK VAT rate lookups, Making Tax Digital status, and HMRC guidance search.\n\n"
        "All tools are read-only. Judgments and statutes are cached aggressively."
    ),
)

# ---------------------------------------------------------------------------
# Gateway-level middleware
# Executes in add order (first added = outermost).
# ---------------------------------------------------------------------------

# Error handling (outermost — catches unhandled exceptions, tracks error counts)
gateway.add_middleware(ErrorHandlingMiddleware(include_traceback=False))

# Structured JSON logging — every tool call logged with duration, payload size, token estimate
gateway.add_middleware(StructuredLoggingMiddleware(
    log_level=logging.INFO,
    include_payload_length=True,
    estimate_payload_tokens=True,
))

# Client tracking — logs clientInfo + increments client_connections_total on initialize
gateway.add_middleware(ClientTrackingMiddleware())

# Prometheus metrics — fleet-standard tool_calls_total + tool_duration_seconds
gateway.add_middleware(PrometheusMiddleware())

# Per-tool timing — logs "Tool 'X' completed in Y ms"
gateway.add_middleware(DetailedTimingMiddleware())

# Response caching at the gateway level — covers resources/read (gateway-
# registered judgment:// and legislation:// templates) AND tools/call
# on the gateway surface. Sub-MCP-level caching remains on case_law and
# legislation sub-MCPs for their tools (belt-and-braces).
#
# Judgments rarely change (append-only corrections over months); statute
# text at a point-in-time is immutable; search results stable over short
# windows. 1-hour TTL is the sweet spot — balances freshness with upstream
# load. In-memory only (single Fly machine); move to Redis if we scale
# horizontally.
gateway.add_middleware(ResponseCachingMiddleware(
    read_resource_settings=ReadResourceSettings(ttl=3600),
    call_tool_settings=CallToolSettings(ttl=3600),
))
gateway.add_transform(PromptsAsTools(gateway))

# NOTE: ResponseLimitingMiddleware was removed because it silently drops
# structured_content from oversize tool responses, which fails strict MCP
# clients (claude.ai) that validate against the advertised outputSchema.
# Per-tool truncation (via a max_chars parameter on the tool itself) or
# structural drill-down via resource sub-paths is the correct place to
# control payload size. See case_law/resources.py for the drill-down
# pattern (judgment://{slug*}/header, /index, /para/{eId}) and
# legislation/tools.py for max_chars-based truncation.

# ---------------------------------------------------------------------------
# Mount sub-modules (in-process — zero network hop)
# ---------------------------------------------------------------------------

gateway.mount(case_law_mcp,    namespace="case_law")
gateway.mount(legislation_mcp, namespace="legislation")
gateway.mount(parliament_mcp,  namespace="parliament")
gateway.mount(bills_mcp,       namespace="bills")
gateway.mount(votes_mcp,       namespace="votes")
gateway.mount(committees_mcp,  namespace="committees")
gateway.mount(citations_mcp,   namespace="citations")
gateway.mount(hmrc_mcp,        namespace="hmrc")

# ---------------------------------------------------------------------------
# Resource templates — registered at GATEWAY level (not on sub-MCPs).
# Mounting silently breaks RFC 6570 wildcard substitution; see issue #3.
# ---------------------------------------------------------------------------

register_case_law_resources(gateway)
register_legislation_resources(gateway)


# ---------------------------------------------------------------------------
# Named companion tools for tool-only clients (lesson 35 pattern).
# Mirrors the judgment:// and legislation:// resources but returns dict
# instead of str, so FastMCP emits clean structuredContent without the
# double-encoding caused by ResourcesAsTools.
# ---------------------------------------------------------------------------

from fastmcp import Context  # noqa: E402 (after gateway instantiation)


@gateway.tool(
    name="judgment_get_header",
    annotations={"title": "Get Judgment Header", "readOnlyHint": True, "idempotentHint": True},
)
async def judgment_get_header(
    slug: Annotated[str, Field(description="Judgment slug, e.g. 'uksc/2024/12' or 'ewca/civ/2023/450'", min_length=3, max_length=200)],
    ctx: Context,
) -> dict:
    """Get metadata for a UK court judgment: parties, judges, neutral citation, court, dates.

    Use case_law_search to find the slug, then call this for orientation before
    reading specific paragraphs via judgment_get_paragraph.
    """
    import httpx
    client: httpx.AsyncClient = ctx.lifespan_context["xml_http"]
    resp = await client.get(f"{TNA_BASE}/{slug.lstrip('/')}/data.xml")
    resp.raise_for_status()
    return {"slug": slug, "header": case_law_parsers.extract_header(resp.text)}


@gateway.tool(
    name="judgment_get_index",
    annotations={"title": "Get Judgment Paragraph Index", "readOnlyHint": True, "idempotentHint": True},
)
async def judgment_get_index(
    slug: Annotated[str, Field(description="Judgment slug, e.g. 'uksc/2024/12'", min_length=3, max_length=200)],
    ctx: Context,
) -> dict:
    """Get the paragraph navigation index for a UK court judgment.

    Returns eId: first_line pairs for every paragraph. Use this to discover
    paragraph identifiers, then call judgment_get_paragraph to read specific ones.
    """
    import httpx
    client: httpx.AsyncClient = ctx.lifespan_context["xml_http"]
    resp = await client.get(f"{TNA_BASE}/{slug.lstrip('/')}/data.xml")
    resp.raise_for_status()
    raw = case_law_parsers.extract_index(resp.text)
    paragraphs = []
    for line in raw.strip().splitlines():
        if ":" in line:
            eid, _, preview = line.partition(":")
            paragraphs.append({"eId": eid.strip(), "preview": preview.strip()})
    return {"slug": slug, "paragraphs": paragraphs}


@gateway.tool(
    name="judgment_get_paragraph",
    annotations={"title": "Get Judgment Paragraph", "readOnlyHint": True, "idempotentHint": True},
)
async def judgment_get_paragraph(
    slug: Annotated[str, Field(description="Judgment slug, e.g. 'uksc/2024/12'", min_length=3, max_length=200)],
    eId: Annotated[str, Field(description="Paragraph eId from judgment_get_index, e.g. 'para_12'. Numeric strings like '12' are accepted and normalized to 'para_12'.", min_length=1, max_length=100)],
    ctx: Context,
) -> dict:
    """Get a single paragraph from a UK court judgment by its LegalDocML eId.

    Use judgment_get_index first to discover available eIds. Returns the paragraph
    XML content (400–1,700 tokens typical).
    """
    import httpx
    client: httpx.AsyncClient = ctx.lifespan_context["xml_http"]
    resp = await client.get(f"{TNA_BASE}/{slug.lstrip('/')}/data.xml")
    resp.raise_for_status()
    normalized_eid = eId.strip()
    if normalized_eid.isdigit():
        normalized_eid = f"para_{normalized_eid}"
    content = case_law_parsers.extract_paragraph(resp.text, normalized_eid)
    return {"slug": slug, "eId": normalized_eid, "content": content}


# ---------------------------------------------------------------------------
# Custom HTTP routes — /health and /stats
# ---------------------------------------------------------------------------

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
}


@gateway.custom_route("/health", methods=["GET", "OPTIONS"])
async def health(request: Request) -> Response:
    if request.method == "OPTIONS":
        return Response(status_code=204, headers=CORS_HEADERS)
    return JSONResponse({
        "status": "ok",
        "server": "uk-legal-mcp",
        "modules": 8,
    }, headers=CORS_HEADERS)


@gateway.custom_route("/metrics", methods=["GET"])
async def metrics_endpoint(request: Request) -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@gateway.custom_route("/.well-known/mcp/server-card.json", methods=["GET"])
async def smithery_server_card(request: Request) -> Response:
    return JSONResponse({
        "serverInfo": {"name": "uk-legal-mcp", "version": "0.4.4"},
    }, headers=CORS_HEADERS)


@gateway.custom_route("/.well-known/glama.json", methods=["GET"])
async def glama_connector_manifest(request: Request) -> Response:
    return JSONResponse({
        "$schema": "https://glama.ai/mcp/schemas/connector.json",
        "maintainers": [{"email": "paul@bouch.dev"}],
    }, headers=CORS_HEADERS)



# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

class _HttpGuard:
    """Return a held-open SSE stream for GET /mcp; 405 for DELETE /mcp.

    claude.ai proxies all MCP traffic through its own relay. The browser opens a
    GET to that relay to establish an SSE stream for server-initiated messages;
    the relay forwards the GET here. With stateless_http=True FastMCP only registers
    POST+DELETE, so GET 405s — the relay relays the 405 and the connection fails,
    even though POST works fine. (OpenAI never probes GET, so it was unaffected.)

    Fix: intercept GET /mcp and return 200 text/event-stream held open until the
    client disconnects. FastMCP never sees the GET; stateless semantics are preserved.
    DELETE is rejected (405) — stateless servers have no sessions to terminate.
    """
    def __init__(self, app, mcp_path: bytes = b"/mcp"):
        self.app = app
        self._mcp_path = mcp_path.rstrip(b"/")

    async def __call__(self, scope, receive, send):
        if scope.get("type") == "http":
            path = scope.get("path", "").rstrip("/").encode()
            method = scope.get("method", "").upper().encode()
            if path == self._mcp_path:
                if method == b"GET":
                    await send({
                        "type": "http.response.start",
                        "status": 200,
                        "headers": [
                            (b"content-type", b"text/event-stream"),
                            (b"cache-control", b"no-cache"),
                            (b"connection", b"keep-alive"),
                        ],
                    })
                    await send({
                        "type": "http.response.body",
                        "body": b"",
                        "more_body": True,
                    })
                    while True:
                        event = await receive()
                        if event["type"] == "http.disconnect":
                            break
                    return
                if method == b"DELETE":
                    from starlette.responses import Response as StarletteResponse
                    await StarletteResponse(
                        "Method Not Allowed",
                        status_code=405,
                        headers={"Allow": "POST"},
                    )(scope, receive, send)
                    return
        await self.app(scope, receive, send)


class _AcceptNormalizer:
    """Stamp Accept to the MCP-spec value on /mcp only, so json_response=True never 406s.

    Anthropic sends mixed Accept headers per request type (application/json for
    initialize, text/event-stream for tools/list). Only stamp the MCP endpoint —
    leave /metrics, /health, /.well-known/* with their original Accept headers.
    """
    def __init__(self, app, mcp_path: bytes = b"/mcp"):
        self.app = app
        self._mcp_path = mcp_path.rstrip(b"/")

    async def __call__(self, scope, receive, send):
        if scope.get("type") == "http" and scope.get("path", "").rstrip("/").encode() == self._mcp_path:
            headers = [
                (b"accept", b"application/json, text/event-stream")
                if name.lower() == b"accept"
                else (name, value)
                for name, value in scope.get("headers", [])
            ]
            scope = {**scope, "headers": headers}
        await self.app(scope, receive, send)


def main() -> None:
    """Run the gateway server on Streamable HTTP transport."""
    import uvicorn
    from fastmcp.server.http import create_streamable_http_app

    port = int(os.getenv("PORT", "8080"))
    # stateless_http=True: Lesson 2 — without it, clients hit "Missing
    # session ID" on any request not preceded by initialize on the same
    # machine. Required for safe deploys (machine restart drops sessions)
    # and future horizontal scaling.
    app = create_streamable_http_app(
        gateway,
        streamable_http_path="/mcp",
        json_response=True,
        stateless_http=True,
    )
    uvicorn.run(
        _HttpGuard(_AcceptNormalizer(app)),  # guard → normalizer → FastMCP
        host="0.0.0.0",
        port=port,
        forwarded_allow_ips="*",
        proxy_headers=True,
        lifespan="on",
        log_level="info",
    )


def main_stdio() -> None:
    """Run the gateway on stdio transport (for PyPI install / Claude Desktop)."""
    gateway.run(transport="stdio")


if __name__ == "__main__":
    main()
