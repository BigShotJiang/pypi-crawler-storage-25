"""Unit tests for CLI configuration, settings, and utility functions."""

import json
import os
import time
from unittest.mock import MagicMock, patch

import jwt as pyjwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa


# ── RSA key fixtures ────────────────────────────────────────────


def _generate_rsa_keypair():
    """Generate an RSA private key and return (private_key, public_key)."""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    return private_key, private_key.public_key()


_PRIVATE_KEY, _PUBLIC_KEY = _generate_rsa_keypair()


def _make_token(
    sub: str = "5" + "A" * 47,
    iss: str = "https://test-auth.taostats.io",
    aud: str = "bittensor-apps",
    scopes: list[str] | None = None,
    exp_offset: int = 3600,
) -> str:
    """Create a signed RS256 JWT for testing."""
    now = int(time.time())
    scope_list = scopes or ["subnet:19:miner"]
    payload = {
        "sub": sub,
        "iss": iss,
        "aud": aud,
        "iat": now,
        "exp": now + exp_offset,
        "scope": " ".join(scope_list),
    }
    return pyjwt.encode(payload, _PRIVATE_KEY, algorithm="RS256")


def _mock_jwks_client():
    """Return a mock PyJWKClient that returns our test public key."""
    mock_client = MagicMock()
    mock_signing_key = MagicMock()
    mock_signing_key.key = _PUBLIC_KEY
    mock_client.get_signing_key_from_jwt.return_value = mock_signing_key
    return mock_client


# ── settings tests ──────────────────────────────────────────────


class TestSettings:
    """Test that settings.py picks up environment variable overrides."""

    def test_defaults(self):
        """Settings have correct defaults when no env vars set."""
        import cli.settings as s

        env_keys = ["BM_AUTH_URL", "BM_API_URL", "BM_CLIENT_ID", "BM_NETUID"]
        saved = {k: os.environ.pop(k, None) for k in env_keys}
        try:
            s.set_network(s.MAINNET)
            assert s.auth_url() == "https://auth.taostats.io"
            assert s.api_url() == "https://api.blockmachine.io"
            assert s.CLIENT_ID == "07f5c729-5ca7-412a-b5e7-4966e132548e"
            assert s.jwks_uri() == ("https://auth.taostats.io/.well-known/jwks.json")
            assert s.miner_scopes() == ["subnet:19:miner"]
            assert s.validator_scopes() == ["subnet:19:validator"]
        finally:
            for k, v in saved.items():
                if v is not None:
                    os.environ[k] = v
                else:
                    os.environ.pop(k, None)

    def test_env_overrides(self):
        """Environment variables override defaults."""
        import importlib

        import cli.settings as s

        saved = {
            "BM_AUTH_URL": os.environ.get("BM_AUTH_URL"),
            "BM_API_URL": os.environ.get("BM_API_URL"),
            "BM_CLIENT_ID": os.environ.get("BM_CLIENT_ID"),
        }
        try:
            os.environ["BM_AUTH_URL"] = "https://custom-auth.example.com"
            os.environ["BM_API_URL"] = "https://custom-api.example.com"
            os.environ["BM_CLIENT_ID"] = "custom-client-id"
            importlib.reload(s)

            assert s.auth_url() == "https://custom-auth.example.com"
            assert s.api_url() == "https://custom-api.example.com"
            assert s.CLIENT_ID == "custom-client-id"
            assert s.jwks_uri() == (
                "https://custom-auth.example.com/.well-known/jwks.json"
            )
        finally:
            for k, v in saved.items():
                if v is not None:
                    os.environ[k] = v
                else:
                    os.environ.pop(k, None)
            importlib.reload(s)

    def test_testnet_config(self):
        """--testnet flag switches to testnet network config."""
        import cli.settings as s

        env_keys = ["BM_AUTH_URL", "BM_API_URL", "BM_NETUID"]
        saved = {k: os.environ.pop(k, None) for k in env_keys}
        try:
            s.set_network(s.TESTNET)
            assert s.auth_url() == "https://test-auth.taostats.io"
            assert s.netuid() == 417
            assert s.miner_scopes() == ["subnet:417:miner"]
            assert s.validator_scopes() == ["subnet:417:validator"]
        finally:
            s.set_network(s.MAINNET)
            for k, v in saved.items():
                if v is not None:
                    os.environ[k] = v
                else:
                    os.environ.pop(k, None)


# ── config.py tests ─────────────────────────────────────────────


class TestValidateToken:
    """Test JWT validation in cli.config.validate_token."""

    @pytest.fixture(autouse=True)
    def _use_testnet(self):
        """Tests use testnet issuer in tokens."""
        import cli.settings as s

        s.set_network(s.TESTNET)
        yield
        s.set_network(s.MAINNET)

    def test_valid_token(self):
        """A properly signed, unexpired token returns claims."""
        import cli.config as config_mod

        with patch.object(
            config_mod, "_get_jwks_client", return_value=_mock_jwks_client()
        ):
            token = _make_token()
            claims = config_mod.validate_token(token)
            assert claims is not None
            assert claims["sub"] == "5" + "A" * 47
            assert claims["iss"] == "https://test-auth.taostats.io"

    def test_expired_token(self):
        """An expired token returns None."""
        import cli.config as config_mod

        with patch.object(
            config_mod, "_get_jwks_client", return_value=_mock_jwks_client()
        ):
            token = _make_token(exp_offset=-3600)
            assert config_mod.validate_token(token) is None

    def test_wrong_issuer(self):
        """A token with wrong issuer returns None."""
        import cli.config as config_mod

        with patch.object(
            config_mod, "_get_jwks_client", return_value=_mock_jwks_client()
        ):
            token = _make_token(iss="https://evil.example.com")
            assert config_mod.validate_token(token) is None

    def test_malformed_token(self):
        """A garbage string returns None."""
        import cli.config as config_mod

        with patch.object(
            config_mod, "_get_jwks_client", return_value=_mock_jwks_client()
        ):
            assert config_mod.validate_token("not.a.jwt") is None

    def test_wrong_audience(self):
        """A token with wrong audience returns None."""
        import cli.config as config_mod

        with patch.object(
            config_mod, "_get_jwks_client", return_value=_mock_jwks_client()
        ):
            token = _make_token(aud="wrong-audience")
            assert config_mod.validate_token(token) is None

    def test_jwks_fetch_failure(self):
        """If JWKS fetch fails, returns None."""
        import cli.config as config_mod

        mock_client = MagicMock()
        mock_client.get_signing_key_from_jwt.side_effect = (
            pyjwt.PyJWKClientConnectionError("connection refused")
        )
        with patch.object(config_mod, "_get_jwks_client", return_value=mock_client):
            token = _make_token()
            assert config_mod.validate_token(token) is None


class TestIsTokenValid:
    """Test the is_token_valid convenience wrapper."""

    @pytest.fixture(autouse=True)
    def _use_testnet(self):
        import cli.settings as s

        s.set_network(s.TESTNET)
        yield
        s.set_network(s.MAINNET)

    def test_no_token(self):
        from cli.config import CLIConfig, is_token_valid

        config = CLIConfig(access_token=None)
        assert is_token_valid(config) is False

    def test_empty_token(self):
        from cli.config import CLIConfig, is_token_valid

        config = CLIConfig(access_token="")
        assert is_token_valid(config) is False

    def test_valid_token(self):
        import cli.config as config_mod
        from cli.config import CLIConfig

        with patch.object(
            config_mod, "_get_jwks_client", return_value=_mock_jwks_client()
        ):
            token = _make_token()
            config = CLIConfig(access_token=token)
            assert config_mod.is_token_valid(config) is True


class TestLoadSaveConfig:
    """Test config round-trip serialization."""

    def test_round_trip(self, tmp_path):
        """Save and load should produce the same values."""
        from cli.config import CLIConfig

        config_dir = tmp_path / ".blockmachine"
        config_file = config_dir / "config.json"

        with (
            patch("cli.auth_config.get_config_dir", return_value=config_dir),
            patch("cli.auth_config.get_config_path", return_value=config_file),
        ):
            from cli.config import load_config, save_config

            original = CLIConfig(
                api_url="https://api.example.com",
                access_token="test-token",
                refresh_token="test-refresh",
                token_expires_at="2026-01-01T00:00:00+00:00",
                active_miner_node="my-node",
            )
            save_config(original)

            loaded = load_config()
            assert loaded.api_url == original.api_url
            assert loaded.access_token == original.access_token
            assert loaded.refresh_token == original.refresh_token
            assert loaded.token_expires_at == original.token_expires_at
            assert loaded.active_miner_node == original.active_miner_node

    def test_load_missing_file(self, tmp_path):
        """Loading from a nonexistent path returns defaults."""
        config_file = tmp_path / "nope" / "config.json"

        with patch("cli.auth_config.get_config_path", return_value=config_file):
            from cli.config import load_config

            config = load_config()
            assert config.access_token is None
            assert config.active_miner_node is None

    def test_load_corrupt_json(self, tmp_path):
        """Loading a corrupt file returns defaults."""
        config_file = tmp_path / "config.json"
        config_file.write_text("not json {{{")

        with patch("cli.auth_config.get_config_path", return_value=config_file):
            from cli.config import load_config

            config = load_config()
            assert config.access_token is None

    def test_load_legacy_config_is_replaced(self, tmp_path):
        """Legacy flat config is replaced with empty new-format config."""
        config_dir = tmp_path / ".blockmachine"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(
            json.dumps(
                {
                    "api_url": "https://testnet-registry.blockmachine.io",
                    "access_token": None,
                    "auth_url": "https://test-auth.taostats.io",
                }
            )
        )

        with (
            patch("cli.auth_config.get_config_dir", return_value=config_dir),
            patch("cli.auth_config.get_config_path", return_value=config_file),
        ):
            from cli.config import load_config

            config = load_config()
            assert config.access_token is None
            # File should now be in the new format
            saved = json.loads(config_file.read_text())
            assert "networks" in saved

    def test_save_sets_permissions(self, tmp_path):
        """Saved config file should have 0600 permissions."""
        config_dir = tmp_path / ".blockmachine"
        config_file = config_dir / "config.json"

        with (
            patch("cli.auth_config.get_config_dir", return_value=config_dir),
            patch("cli.auth_config.get_config_path", return_value=config_file),
        ):
            from cli.config import CLIConfig, save_config

            save_config(CLIConfig())
            assert oct(config_file.stat().st_mode & 0o777) == "0o600"


class TestClearToken:
    """Test clear_token wipes credentials."""

    def test_clears_all_token_fields(self, tmp_path):
        config_dir = tmp_path / ".blockmachine"
        config_file = config_dir / "config.json"

        with (
            patch("cli.auth_config.get_config_dir", return_value=config_dir),
            patch("cli.auth_config.get_config_path", return_value=config_file),
        ):
            from cli.config import CLIConfig, clear_token

            config = CLIConfig(
                access_token="tok",
                refresh_token="ref",
                token_expires_at="2026-01-01",
            )
            result = clear_token(config)
            assert result.access_token is None
            assert result.refresh_token is None
            assert result.token_expires_at is None


# ── utils.py tests ──────────────────────────────────────────────


class TestResolveNodeId:
    """Test resolve_node_id alias/ID lookup."""

    def test_resolve_by_id(self):
        from cli.utils import resolve_node_id

        resp = {"nodes": [{"id": "abc-123", "alias": "my-node"}]}
        assert resolve_node_id(resp, "abc-123") == "abc-123"

    def test_resolve_by_alias(self):
        from cli.utils import resolve_node_id

        resp = {"nodes": [{"id": "abc-123", "alias": "my-node"}]}
        assert resolve_node_id(resp, "my-node") == "abc-123"

    def test_not_found(self):
        from cli.utils import resolve_node_id

        resp = {"nodes": [{"id": "abc-123", "alias": "my-node"}]}
        assert resolve_node_id(resp, "nope") is None

    def test_empty_nodes(self):
        from cli.utils import resolve_node_id

        assert resolve_node_id({"nodes": []}, "anything") is None
        assert resolve_node_id({}, "anything") is None

    def test_id_takes_priority(self):
        """If alias equals another node's ID, ID match wins."""
        from cli.utils import resolve_node_id

        resp = {
            "nodes": [
                {"id": "node-1", "alias": "node-2"},
                {"id": "node-2", "alias": "other"},
            ]
        }
        assert resolve_node_id(resp, "node-2") == "node-2"


class TestFormatTimestamp:
    """Test timestamp formatting."""

    def test_none(self):
        from cli.utils import format_timestamp

        assert format_timestamp(None) == "N/A"

    def test_empty_string(self):
        from cli.utils import format_timestamp

        assert format_timestamp("") == "N/A"

    def test_iso_format(self):
        from cli.utils import format_timestamp

        result = format_timestamp("2026-01-15T10:30:00Z")
        assert result == "2026-01-15 10:30:00"

    def test_invalid_format(self):
        from cli.utils import format_timestamp

        assert format_timestamp("not-a-date") == "not-a-date"


# ── miner.py helper tests ──────────────────────────────────────


class TestDefaultAlias:
    """Test _default_alias endpoint → alias derivation."""

    def test_wss_domain(self):
        from cli.commands.miner import _default_alias

        assert _default_alias("wss://1.2.3.4") == "tao-1-2-3-4"

    def test_wss_hostname(self):
        from cli.commands.miner import _default_alias

        result = _default_alias("wss://my-node.example.com:9944")
        assert result == "tao-my-node-example-com"

    def test_ws_scheme(self):
        from cli.commands.miner import _default_alias

        assert _default_alias("ws://10.0.0.1") == "tao-10-0-0-1"

    def test_with_path(self):
        from cli.commands.miner import _default_alias

        result = _default_alias("wss://node.example.com/ws")
        assert result == "tao-node-example-com"


class TestTruncate:
    """Test _truncate helper."""

    def test_short_string(self):
        from cli.commands.miner import _truncate

        assert _truncate("hello", 10) == "hello"

    def test_exact_length(self):
        from cli.commands.miner import _truncate

        assert _truncate("hello", 5) == "hello"

    def test_long_string(self):
        from cli.commands.miner import _truncate

        assert _truncate("hello world", 5) == "hello..."


class TestGetAlias:
    """Test _get_alias resolution from arg vs active context."""

    def test_explicit_alias(self):
        from cli.commands.miner import _get_alias

        assert _get_alias("my-node") == "my-node"

    def test_active_node_fallback(self, tmp_path):
        from cli.config import CLIConfig

        config = CLIConfig(active_miner_node="saved-node")
        with patch("cli.commands.miner.load_config", return_value=config):
            from cli.commands.miner import _get_alias

            assert _get_alias(None) == "saved-node"

    def test_no_alias_no_active_exits(self, tmp_path):
        from click.exceptions import Exit

        from cli.config import CLIConfig

        config = CLIConfig(active_miner_node=None)
        with (
            patch("cli.commands.miner.load_config", return_value=config),
            pytest.raises(Exit),
        ):
            from cli.commands.miner import _get_alias

            _get_alias(None)
