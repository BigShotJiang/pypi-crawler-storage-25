"""Miner commands: node registration, secrets, and pricing"""

import getpass
import logging
from typing import Callable, Optional
from urllib.parse import urlparse

import typer
from rich.console import Console
from rich.table import Table

from cli import settings
from cli.client import RegistryClient
from cli.commands.auth import check_status, device_login, do_logout, save_miner_token
from cli.commands.leaderboard import _fetch_leaderboard, _get_own_hotkey
from cli.config import load_config, save_config
from cli.endpoints import get_cert_fingerprint, is_ip_endpoint, test_tls
from cli.testing import test_health, test_rpc, test_wss
from cli.utils import format_timestamp, resolve_node_id

app = typer.Typer(help="Miner node management")
secret_app = typer.Typer(help="Secret management")
price_app = typer.Typer(help="Pricing management")

app.add_typer(secret_app, name="secret")
app.add_typer(price_app, name="price")

console = Console()
logger = logging.getLogger(__name__)

CHAIN = "tao"


def _get_alias(alias: Optional[str]) -> str:
    """Resolve alias from argument or active node context."""
    if alias:
        return alias
    config = load_config()
    if config.active_miner_node:
        return config.active_miner_node
    console.print(
        "[red]No node specified and no active node set.[/red]\n"
        "Run 'bm miner use <alias>' first."
    )
    raise typer.Exit(1)


def _resolve_node(client: RegistryClient, id_or_alias: str) -> str:
    """Resolve an alias or ID to a node UUID."""
    response = client.get("/nodes")
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code}")
        raise typer.Exit(1)
    node_id = resolve_node_id(response.json(), id_or_alias)
    if not node_id:
        console.print(f"[red]Node not found:[/red] {id_or_alias}")
        raise typer.Exit(1)
    return node_id


# ── Auth ─────────────────────────────────────────────────────────


@app.command("login")
def login(
    client_id: str = typer.Option(None, "--client-id", help="OAuth client ID"),
    auth_url: str = typer.Option(None, "--auth-url", help="TaoStats auth URL"),
    api_url: str = typer.Option(None, "--api-url", "-u", help="Registry API URL"),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Don't auto-open browser"
    ),
) -> None:
    """Login with miner scopes."""
    token_data = device_login(
        scopes=settings.miner_scopes(),
        client_id=client_id,
        auth_url=auth_url,
        no_browser=no_browser,
    )
    save_miner_token(
        token_data, client_id=client_id, auth_url=auth_url, api_url=api_url
    )


@app.command("status")
def status() -> None:
    """Check authentication status."""
    check_status()


@app.command("logout")
def logout() -> None:
    """Clear stored authentication tokens."""
    do_logout()


# ── Node CRUD ────────────────────────────────────────────────────


@app.command("add")
def add(
    endpoint: str = typer.Option(None, "--endpoint", "-e", help="WSS endpoint URL"),
    alias: str = typer.Option(None, "--alias", "-a", help="Friendly name"),
    secret: str = typer.Option(None, "--secret", "-s", help="Bearer token secret"),
    price: str = typer.Option(None, "--price", "-p", help="USD per 1M compute units"),
) -> None:
    """Register a new miner node (interactive if flags omitted)."""
    if not endpoint:
        endpoint = typer.prompt("Endpoint (wss://...)")
    if not alias:
        default = _default_alias(endpoint)
        alias = typer.prompt("Alias", default=default)
    if not secret:
        secret = getpass.getpass("Secret: ")
    if len(secret) < 16:
        console.print("[red]Secret must be at least 16 characters[/red]")
        raise typer.Exit(1)

    fp = None
    if is_ip_endpoint(endpoint):
        fp = get_cert_fingerprint(endpoint)
        if fp:
            console.print(f"[dim]TLS fingerprint (pinned): {fp}[/dim]")
        else:
            console.print(
                "[yellow]Warning: Could not fetch TLS certificate from endpoint.[/yellow]\n"
                "[yellow]The gateway will not be able to verify this miner's identity.[/yellow]"
            )
    else:
        console.print("[dim]Domain endpoint — using standard CA verification[/dim]")

    config = load_config()
    with RegistryClient(config) as client:
        # Check pricing before creating the node so all prompting
        # happens upfront and we only mutate state afterwards.
        needs_pricing = _needs_chain_default_pricing(client, CHAIN)
        if needs_pricing and not price:
            price = typer.prompt("Price (USD/1M CU)")

        _create_node(client, endpoint, alias, secret, cert_fingerprint=fp)

        if needs_pricing and price:
            _create_default_pricing_rule(client, CHAIN, price)

    config.active_miner_node = alias
    save_config(config)

    console.print(f"\n[dim]Active node set to '{alias}'[/dim]")


def _default_alias(endpoint: str) -> str:
    """Derive a default alias from an endpoint URL."""
    host = endpoint.replace("wss://", "").replace("ws://", "")
    host = host.split(":")[0].split("/")[0]
    return f"tao-{host.replace('.', '-')}"


def _create_node(
    client: RegistryClient,
    endpoint: str,
    alias: str,
    secret: str,
    cert_fingerprint: Optional[str] = None,
) -> str:
    """Register a node with its secret and return its ID."""
    payload: dict = {
        "endpoint": endpoint,
        "chain": CHAIN,
        "alias": alias,
        "secret": secret,
    }
    if cert_fingerprint is not None:
        payload["cert_fingerprint"] = cert_fingerprint
    response = client.post("/nodes", json=payload)
    if response.status_code == 201:
        data = response.json()
        console.print(f"[green]Node registered:[/green] {data['id'][:8]}")
        return data["id"]
    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code == 409:
        detail = response.json().get("detail", "Alias already exists")
        console.print(f"[red]Conflict:[/red] {detail}")
        raise typer.Exit(1)
    console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
    raise typer.Exit(1)


def _needs_chain_default_pricing(client: RegistryClient, chain: str) -> bool:
    """Check if the miner needs a chain-default pricing rule.

    Returns True only when no chain-default (region=null, archive=null)
    rule exists. Region- or archive-specific rules don't count.
    Fails closed: auth errors exit, server errors exit.
    """
    resp = client.get("/pricing/rules")
    if resp.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if resp.status_code != 200:
        console.print(f"[red]Failed to check pricing:[/red] {resp.status_code}")
        raise typer.Exit(1)

    existing = resp.json().get("rules", [])
    has_default = any(
        r["chain"] == chain and r.get("region") is None and r.get("archive") is None
        for r in existing
    )
    if has_default:
        console.print(
            f"[dim]Pricing already configured for {chain}."
            " See: bm miner price show[/dim]"
        )
    return not has_default


def _create_default_pricing_rule(
    client: RegistryClient, chain: str, price: str
) -> None:
    """Create a chain-default pricing rule (region=null, archive=null)."""
    response = client.post(
        "/pricing/rules",
        json={"chain": chain, "target_usd_per_million_cu": price},
    )
    if response.status_code == 201:
        data = response.json()
        console.print(
            f"[green]Default price set:[/green]"
            f" {data['target_usd_per_million_cu']} USD/1M CU"
            f" for {chain} (epoch {data['effective_from_epoch']})"
        )
        return
    console.print(
        f"[red]Failed to set price:[/red] {response.status_code} - {response.text}"
    )
    raise typer.Exit(1)


@app.command("use")
def use(
    alias: str = typer.Argument(..., help="Node alias to set as active"),
) -> None:
    """Set the active miner node for subsequent commands."""
    config = load_config()
    config.active_miner_node = alias
    save_config(config)
    console.print(f"Active miner node: [bold]{alias}[/bold]")


@app.command("ls")
def ls() -> None:
    """List all miner nodes."""
    config = load_config()
    with RegistryClient(config) as client:
        response = client.get("/nodes")

    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    nodes = response.json().get("nodes", [])
    if not nodes:
        console.print("[dim]No nodes registered[/dim]")
        return

    active = config.active_miner_node
    table = Table(title="Miner Nodes")
    table.add_column("", width=1)
    table.add_column("Alias")
    table.add_column("Chain")
    table.add_column("Status")
    table.add_column("Endpoint")
    table.add_column("Last Seen")

    for node in nodes:
        status_color = {
            "active": "green",
            "pending": "yellow",
            "unreachable": "red",
            "suspended": "red",
        }.get(node["status"], "white")
        marker = "*" if node.get("alias") == active else ""

        table.add_row(
            marker,
            node.get("alias") or node["id"][:8],
            node["chain"],
            f"[{status_color}]{node['status']}[/{status_color}]",
            _truncate(node["endpoint"], 40),
            format_timestamp(node.get("last_seen_at")),
        )

    console.print(table)


def _truncate(text: str, length: int) -> str:
    if len(text) <= length:
        return text
    return text[:length] + "..."


@app.command("show")
def show(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show details of a miner node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}")

        if response.status_code == 404:
            console.print(f"[red]Node not found:[/red] {alias}")
            raise typer.Exit(1)
        if response.status_code != 200:
            console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
            raise typer.Exit(1)

        node = response.json()
        console.print(f"[bold]ID:[/bold] {node['id']}")
        console.print(f"[bold]Alias:[/bold] {node.get('alias') or '-'}")
        console.print(f"[bold]Chain:[/bold] {node['chain']}")
        console.print(f"[bold]Status:[/bold] {node['status']}")
        console.print(f"[bold]Endpoint:[/bold] {node['endpoint']}")
        console.print(f"[bold]Created:[/bold] {format_timestamp(node['created_at'])}")
        console.print(
            f"[bold]Last Seen:[/bold] {format_timestamp(node.get('last_seen_at'))}"
        )

        m_resp = client.get(f"/nodes/{node_id}/metrics")
        if m_resp.status_code == 200:
            m = m_resp.json()
            if m.get("available"):
                console.print()
                console.print("[bold]Routing Metrics[/bold]")
                _print_metrics(m)


def _fmt_success_rate(v: float) -> str:
    pct = v * 100
    color = "green" if pct >= 99 else "yellow" if pct >= 95 else "red"
    return f"[{color}]{pct:.1f}%[/{color}]"


_METRIC_FIELDS: list[tuple[str, str, Callable]] = [
    ("request_count", "Requests", lambda v: f"{v:,}"),
    ("success_rate", "Success Rate", _fmt_success_rate),
    ("p95_ms", "P95 Latency", lambda v: f"{v:.0f} ms"),
    ("latency_score", "Latency Score", lambda v: f"{v:.4f}"),
    ("routing_score", "Routing Score", lambda v: f"{v:.4f}"),
    ("traffic_pct", "Traffic Share", lambda v: f"{v:.1f}%"),
    ("reliability", "Reliability", lambda v: f"{v:.4f}"),
    ("epochs_good", "Epochs Good", str),
    ("bid", "Bid", lambda v: f"${v:.6f}"),
    ("cohort_median", "Cohort Median", lambda v: f"${v:.6f}"),
    ("price_factor", "Price Factor", lambda v: f"{v:.4f}"),
    ("bid_archive", "Bid (Archive)", lambda v: f"${v:.6f}"),
    ("cohort_median_archive", "Cohort Median (Archive)", lambda v: f"${v:.6f}"),
    ("price_factor_archive", "Price Factor (Archive)", lambda v: f"{v:.4f}"),
    ("routing_score_archive", "Routing Score (Archive)", lambda v: f"{v:.4f}"),
]


def _print_metrics(m: dict) -> None:
    """Print routing metrics from a metrics API response."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="bold")
    table.add_column("Value")

    for key, label, fmt in _METRIC_FIELDS:
        val = m.get(key)
        if val is not None:
            table.add_row(label, fmt(val))

    console.print(table)


@app.command("metrics")
def metrics(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show routing metrics for a miner node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/metrics")

        if response.status_code == 503:
            console.print(
                "[yellow]Metrics not available (scoring not enabled)[/yellow]"
            )
            raise typer.Exit(1)
        if response.status_code != 200:
            console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
            raise typer.Exit(1)

        m = response.json()
        if not m.get("available"):
            console.print(
                f"[yellow]No metrics available for {alias}[/yellow]\n"
                "[dim]The gateway may not have routed traffic to this"
                " node yet.[/dim]"
            )
            return

        console.print(f"[bold]Routing Metrics: {alias}[/bold]\n")
        _print_metrics(m)


@app.command("rm")
def rm(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Remove a miner node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)

        if not force:
            confirm = typer.confirm(f"Delete node {alias}?")
            if not confirm:
                console.print("[dim]Cancelled[/dim]")
                return

        response = client.delete(f"/nodes/{node_id}")

    if response.status_code == 204:
        console.print("[green]Node deleted[/green]")
        if config.active_miner_node == alias:
            config.active_miner_node = None
            save_config(config)
    elif response.status_code == 404:
        console.print(f"[red]Node not found:[/red] {alias}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@app.command("update")
def update(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    new_alias: str = typer.Option(None, "--alias", "-a", help="New alias"),
    endpoint: str = typer.Option(None, "--endpoint", "-e", help="New endpoint"),
) -> None:
    """Update a node's alias or endpoint."""
    alias = _get_alias(alias)

    if not new_alias and not endpoint:
        console.print(
            "[yellow]Nothing to update. Specify --alias or --endpoint[/yellow]"
        )
        return

    config = load_config()
    update_data: dict = {}
    if new_alias:
        update_data["alias"] = new_alias
    if endpoint:
        update_data["endpoint"] = endpoint

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.patch(f"/nodes/{node_id}", json=update_data)

    if response.status_code == 200:
        console.print("[green]Node updated[/green]")
        if new_alias and config.active_miner_node == alias:
            config.active_miner_node = new_alias
            save_config(config)
    elif response.status_code == 409:
        detail = response.json().get("detail", "Alias already exists")
        console.print(f"[red]Conflict:[/red] {detail}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


# ── Test ─────────────────────────────────────────────────────────


def _fetch_active_secret(client: RegistryClient, node_id: str) -> Optional[str]:
    """Fetch the decrypted active secret from the registry."""
    response = client.get(f"/nodes/{node_id}/secret")
    if response.status_code != 200:
        return None
    for s in response.json().get("secrets", []):
        if s.get("state") == "active" and s.get("secret"):
            return s["secret"]
    return None


@app.command("test")
def test(
    alias: Optional[str] = typer.Argument(None, help="Node alias or ID"),
    endpoint: Optional[str] = typer.Option(
        None, "--endpoint", "-e", help="Endpoint URL (skip registry lookup)"
    ),
    secret: Optional[str] = typer.Option(
        None, "--secret", help="Bearer token (overrides registry)"
    ),
) -> None:
    """Test connectivity to a miner node (TLS, health, auth, RPC).

    For registered nodes, fetches the secret from the registry
    automatically. Use --endpoint and --secret for pre-registration
    testing.
    """
    if not endpoint:
        alias = _get_alias(alias)
        config = load_config()
        with RegistryClient(config) as client:
            node_id = _resolve_node(client, alias)
            response = client.get(f"/nodes/{node_id}")
            if response.status_code != 200:
                console.print(f"[red]Error:[/red] {response.status_code}")
                raise typer.Exit(1)
            node = response.json()
            endpoint = node["endpoint"]
            if not secret:
                secret = _fetch_active_secret(client, node_id)
        console.print(f"[bold]Alias:[/bold]    {alias}")

    parsed = urlparse(endpoint)
    hostname = parsed.hostname
    port = parsed.port or 443

    if not hostname:
        console.print(f"[red]Cannot parse endpoint:[/red] {endpoint}")
        raise typer.Exit(1)

    console.print(f"[bold]Endpoint:[/bold] {endpoint}\n")

    all_ok = True

    # 1. TLS
    console.print("TLS handshake... ", end="")
    tls_ok, fingerprint, tls_msg = test_tls(hostname, port)
    if tls_ok:
        is_ip = is_ip_endpoint(endpoint)
        mode = "pinned" if is_ip else "CA-verified"
        fp_short = fingerprint[:16] + "..." if fingerprint else "none"
        console.print(f"[green]OK[/green] ({mode}, {fp_short})")
    else:
        console.print(f"[red]FAIL[/red] {tls_msg}")
        all_ok = False

    # 2. Health
    console.print("Health check...  ", end="")
    health_ok, health_msg = test_health(hostname)
    if health_ok:
        console.print("[green]OK[/green]")
    else:
        console.print(f"[red]FAIL[/red] {health_msg}")
        all_ok = False

    # 3. RPC with auth (only if secret provided)
    if secret:
        console.print("RPC query...     ", end="")
        rpc_ok, latency, rpc_msg = test_rpc(hostname, port, secret)
        if rpc_ok:
            console.print(f"[green]OK[/green] ({rpc_msg}, {latency:.0f}ms)")
        else:
            console.print(f"[red]FAIL[/red] {rpc_msg}")
            all_ok = False
    else:
        console.print("[dim]Pass --secret to also test auth and RPC[/dim]")

    # 4. WSS (mirrors the registry liveness checker)
    if secret:
        console.print("WSS liveness...  ", end="")
        wss_ok, wss_latency, wss_msg = test_wss(hostname, port, secret)
        if wss_ok:
            console.print(f"[green]OK[/green] ({wss_msg}, {wss_latency:.0f}ms)")
        else:
            console.print(f"[red]FAIL[/red] {wss_msg}")
            if rpc_ok:
                console.print(
                    "[yellow]  ↳ HTTPS works but WSS fails — the registry "
                    "liveness checker uses WSS, so the node will show as "
                    "unreachable.[/yellow]"
                )
                console.print(
                    "[yellow]  ↳ Check your nginx/reverse-proxy WebSocket "
                    "upgrade config.[/yellow]"
                )
            all_ok = False

    console.print()
    if all_ok:
        console.print("[green]All checks passed[/green]")
    else:
        console.print("[red]Some checks failed[/red]")
        raise typer.Exit(1)


# ── Snapshots ────────────────────────────────────────────────────


@app.command("snapshot")
def snapshot() -> None:
    """Get a pre-signed URL to download an archive node snapshot."""
    config = load_config()
    with RegistryClient(config) as client:
        response = client.get("/snapshots/url")

    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code == 404:
        console.print("[yellow]No snapshot available[/yellow]")
        raise typer.Exit(1)
    if response.status_code == 503:
        console.print("[yellow]Snapshots are not configured on this registry[/yellow]")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    data = response.json()
    expiry_hours = data["expires_in_seconds"] // 3600

    console.print("\n[bold]Archive Snapshot[/bold]")
    console.print(f"  Size:   {data['size_mb']} MB")
    console.print(f"  Valid:  {expiry_hours} hours")
    console.print("\n[bold]Snapshot URL:[/bold]\n")
    console.print(f"  {data['url']}")
    console.print(
        "\n[dim]Paste this URL when prompted during install,"
        " or download manually on your VPS.[/dim]\n"
    )


# ── Secrets ──────────────────────────────────────────────────────


@secret_app.command("set")
def secret_set(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    secret: str = typer.Option(
        None,
        "--secret",
        "-s",
        help="Secret value (will prompt if not provided)",
    ),
) -> None:
    """Set the bearer token secret for a node."""
    alias = _get_alias(alias)

    if not secret:
        secret = getpass.getpass("Enter secret: ")
        confirm = getpass.getpass("Confirm secret: ")
        if secret != confirm:
            console.print("[red]Secrets do not match[/red]")
            raise typer.Exit(1)

    if len(secret) < 16:
        console.print("[red]Secret must be at least 16 characters[/red]")
        raise typer.Exit(1)

    config = load_config()
    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.post(
            f"/nodes/{node_id}/secret",
            json={"secret": secret, "rotate": False},
        )

    if response.status_code == 201:
        data = response.json()
        console.print("[green]Secret set[/green]")
        console.print(f"[bold]Version:[/bold] {data['version']}")
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@secret_app.command("show")
def secret_show(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show secret metadata (not the secret itself)."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/secret")

    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    secrets = response.json().get("secrets", [])
    if not secrets:
        console.print("[dim]No secrets configured[/dim]")
        return

    table = Table(title="Secrets")
    table.add_column("Version")
    table.add_column("State")
    table.add_column("Created")

    for s in secrets:
        color = {"active": "green", "next": "yellow", "retired": "dim"}.get(
            s["state"], "white"
        )
        table.add_row(
            str(s["version"]),
            f"[{color}]{s['state']}[/{color}]",
            format_timestamp(s["created_at"]),
        )

    console.print(table)


@secret_app.command("promote")
def secret_promote(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Promote the 'next' secret to 'active'."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.post(f"/nodes/{node_id}/secret/promote")

    if response.status_code == 200:
        data = response.json()
        console.print("[green]Secret promoted[/green]")
        console.print(f"[bold]Version:[/bold] {data['version']}")
    else:
        detail = response.json().get("detail", response.text)
        console.print(f"[red]Error:[/red] {detail}")
        raise typer.Exit(1)


# ── Pricing ──────────────────────────────────────────────────────


def _fmt_region(region: Optional[str]) -> str:
    return region or "all"


def _fmt_archive(archive: Optional[bool]) -> str:
    if archive is None:
        return "all"
    return "archive" if archive else "non-archive"


@price_app.command("set")
def price_set(
    price: str = typer.Option(
        ..., "--price", "-p", help="Target USD per 1M compute units"
    ),
    chain: str = typer.Option(CHAIN, "--chain", "-c", help="Chain identifier"),
    region: Optional[str] = typer.Option(None, "--region", "-r", help="Region filter"),
    archive: Optional[bool] = typer.Option(
        None, "--archive/--no-archive", help="Archive filter"
    ),
) -> None:
    """Set a pricing rule for your miner."""
    config = load_config()
    payload: dict = {"chain": chain, "target_usd_per_million_cu": price}
    if region is not None:
        payload["region"] = region
    if archive is not None:
        payload["archive"] = archive

    with RegistryClient(config) as client:
        response = client.post("/pricing/rules", json=payload)

    if response.status_code == 201:
        data = response.json()
        console.print(
            f"[green]Price set:[/green]"
            f" {data['target_usd_per_million_cu']} USD/1M CU"
            f" (chain={data['chain']},"
            f" region={_fmt_region(data.get('region'))},"
            f" archive={_fmt_archive(data.get('archive'))},"
            f" epoch {data['effective_from_epoch']})"
        )
    elif response.status_code == 400:
        detail = response.json().get("detail", "Invalid request")
        console.print(f"[red]Error:[/red] {detail}")
        raise typer.Exit(1)
    elif response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@price_app.command("show")
def price_show() -> None:
    """Show all pricing rules for your miner."""
    config = load_config()

    with RegistryClient(config) as client:
        response = client.get("/pricing/rules")

    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    rules = response.json().get("rules", [])
    if not rules:
        console.print("[dim]No pricing rules set[/dim]")
        console.print("[dim]Use 'bm miner price set --price <price>' to set one[/dim]")
        return

    table = Table(title="Pricing Rules")
    table.add_column("Chain")
    table.add_column("Region")
    table.add_column("Archive")
    table.add_column("Price (USD/1M CU)")
    table.add_column("Epoch")

    for r in rules:
        table.add_row(
            r["chain"],
            _fmt_region(r.get("region")),
            _fmt_archive(r.get("archive")),
            r["target_usd_per_million_cu"],
            str(r["effective_from_epoch"]),
        )

    console.print(table)


@price_app.command("delete")
def price_delete(
    chain: str = typer.Option(..., "--chain", "-c", help="Chain identifier"),
    region: Optional[str] = typer.Option(None, "--region", "-r", help="Region filter"),
    archive: Optional[bool] = typer.Option(
        None, "--archive/--no-archive", help="Archive filter"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a pricing rule by dimension filters."""
    if not force:
        confirm = typer.confirm(
            f"Delete pricing rule for chain={chain},"
            f" region={_fmt_region(region)}, archive={_fmt_archive(archive)}?"
        )
        if not confirm:
            console.print("[dim]Cancelled[/dim]")
            return

    config = load_config()
    params: dict = {"chain": chain}
    if region is not None:
        params["region"] = region
    if archive is not None:
        params["archive"] = str(archive).lower()

    with RegistryClient(config) as client:
        response = client.delete("/pricing/rules", params=params)

    if response.status_code == 204:
        console.print("[green]Pricing rule deleted[/green]")
    elif response.status_code == 404:
        console.print("[yellow]No matching pricing rule found[/yellow]")
        raise typer.Exit(1)
    elif response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


# ── Price Simulation ──────────────────────────────────────────────

# Scoring formula constants (must match gateway defaults).
# TODO: fetch live params from registry (e.g. GET /scoring/params)
# so simulation is accurate when gateway overrides these via env vars.
_SCORING_BETA = 1.0
_SCORING_P_MAX = 3.0
_SCORING_SR_A = 2.0
_SCORING_REL_W = 1.5
_SCORING_LATENCY_ALPHA = 1.0


def _price_factor(cohort_median: float, bid: float) -> float:
    """Compute price factor: clamp((median/bid)^beta, p_max)."""
    if bid <= 0:
        return 0.0
    if cohort_median <= 0:
        return 1.0
    return min((cohort_median / bid) ** _SCORING_BETA, _SCORING_P_MAX)


def _routing_score_from_components(
    sr: float, rel: float, lat: float, pf: float
) -> float:
    """Compute routing score from individual component scores."""
    return sr**_SCORING_SR_A * rel**_SCORING_REL_W * lat**_SCORING_LATENCY_ALPHA * pf


def _fmt_delta(current: float, simulated: float) -> str:
    """Format a before -> after with delta percentage."""
    if current == 0:
        return f"{current:.4f} \u2192 {simulated:.4f}"
    delta_pct = (simulated - current) / current * 100
    sign = "+" if delta_pct >= 0 else ""
    color = "green" if delta_pct >= 0 else "red"
    return (
        f"{current:.4f} \u2192 {simulated:.4f}"
        f"  [{color}]({sign}{delta_pct:.1f}%)[/{color}]"
    )


@price_app.command("simulate")
def price_simulate(
    price: float = typer.Argument(..., help="Simulated USD per 1M compute units"),
    archive: bool = typer.Option(
        False, "--archive", "-a", help="Simulate archive price"
    ),
) -> None:
    """Simulate the impact of a price change on your routing score.

    Fetches the current leaderboard, recalculates your score with the
    simulated price, and shows the projected traffic share change.

    Note: uses default scoring parameters. Results are approximate if
    the gateway has overridden scoring constants via environment.
    """
    config = load_config()
    own_hotkey = _get_own_hotkey(config)
    if not own_hotkey:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)

    data = _fetch_leaderboard(config)
    miners = data.get("miners", [])

    my_miner = None
    for m in miners:
        if m["hotkey"] == own_hotkey:
            my_miner = m
            break

    if not my_miner:
        console.print(
            "[yellow]Your miner has no routing scores yet.[/yellow]\n"
            "[dim]The gateway may not have routed traffic to your"
            " nodes yet.[/dim]"
        )
        raise typer.Exit(1)

    mode = "archive" if archive else "lite"
    simulated_bid = price / 1_000_000
    score_key = "routing_score_archive" if archive else "routing_score"
    pf_key = "price_factor_archive" if archive else "price_factor"
    bid_key = "bid_archive" if archive else "bid"
    median_key = "cohort_median_archive" if archive else "cohort_median"

    # Compute current totals across all miners
    current_total = 0.0
    current_my_score = 0.0
    for m in miners:
        miner_score = sum((n.get(score_key) or 0.0) for n in m.get("nodes", []))
        current_total += miner_score
        if m["hotkey"] == own_hotkey:
            current_my_score = miner_score

    current_share = (
        (current_my_score / current_total * 100.0) if current_total > 0 else 0.0
    )

    # Simulate new scores for my nodes
    console.print(
        f"\n[bold]Price Simulation ({mode})[/bold]"
        f"  \u2014  simulated bid: ${price:.6f}/1M CU\n"
    )

    simulated_my_score = 0.0
    node_results = []

    for node in my_miner.get("nodes", []):
        sr = node.get("success_rate") or 0.0
        rel = node.get("reliability") or 0.0
        lat = node.get("latency_score") or 0.0
        current_pf = node.get(pf_key) or 0.0
        current_bid = node.get(bid_key) or 0.0
        median = node.get(median_key) or 0.0
        current_node_score = node.get(score_key) or 0.0

        new_pf = _price_factor(median, simulated_bid)
        new_node_score = _routing_score_from_components(sr, rel, lat, new_pf)
        simulated_my_score += new_node_score

        alias = node.get("alias") or node["node_id"][:8]
        node_results.append(
            {
                "alias": alias,
                "current_score": current_node_score,
                "new_score": new_node_score,
                "current_pf": current_pf,
                "new_pf": new_pf,
                "current_bid": current_bid,
                "median": median,
                "latency": lat,
                "reliability": rel,
                "success_rate": sr,
            }
        )

    # Recompute total with simulated scores
    simulated_total = current_total - current_my_score + simulated_my_score
    simulated_share = (
        (simulated_my_score / simulated_total * 100.0) if simulated_total > 0 else 0.0
    )

    # Show per-node results
    for nr in node_results:
        console.print(f"  [bold]{nr['alias']}[/bold]")
        console.print(
            f"    Price factor:   {_fmt_delta(nr['current_pf'], nr['new_pf'])}"
            f"    (bid: ${nr['current_bid'] * 1_000_000:.4f}"
            f" \u2192 ${price:.4f}, median: ${nr['median'] * 1_000_000:.4f})"
        )
        console.print(
            f"    Routing score:  {_fmt_delta(nr['current_score'], nr['new_score'])}"
        )

        # Show non-price components (unchanged)
        console.print(
            f"    [dim]Latency: {nr['latency']:.3f}"
            f"  Reliability: {nr['reliability']:.3f}"
            f"  Success: {nr['success_rate']:.3f}  (unchanged)[/dim]"
        )
        console.print()

    # Show aggregate summary
    console.print("[bold]Summary[/bold]")
    console.print(
        f"  Routing score:  {_fmt_delta(current_my_score, simulated_my_score)}"
    )
    console.print(f"  Traffic share:  {_fmt_delta(current_share, simulated_share)}")
    console.print()
    console.print(
        "[dim]Results are approximate (uses default scoring parameters).[/dim]"
    )
