"""Meridian package root."""

__all__ = ["__version__"]

__version__ = "0.2.2"
