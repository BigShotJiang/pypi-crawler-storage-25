# Changelog

## 0.2.2

- Added `RuleNameOutputMode.CLINICAL` and a public `format_rule_name()` helper for package-owned display labeling.
- Updated all rule-bearing serializers to emit canonical machine identifiers in `rule` plus display-oriented labels in `rule_label`.
- Added `serialize_series_multirule_report()` as a separate flattened reporting serializer, including grouped-window semantics and deterministic ordering.
- Preserved structural serializer behavior while keeping map keys and grouping identifiers canonical across label modes.
- Expanded tests and documentation for naming-mode invariants, reporting payload contracts, and grouped/non-grouped reporting behavior.

## 0.2.1

- Added configurable historical scope selection for `evaluate_multirule_sequence()` and `scan_multirule_series()`, with conservative defaults (`within_run` + `within_material`) and explicit opt-in for `across_material`.
- Added retrospective emit modes (`all_triggers`, `first_trigger_per_rule`, `first_trigger_per_rule_per_scope`, `all_triggers_grouped_by_window`) with grouped window payload support.
- Added serializer rule-name output modes (`canonical` and `compact`) for compatibility-oriented integration output without changing canonical internal rule names.
- Expanded historical tests and documentation for scope semantics, emit policies, and serialization options.

## 0.2.0

- Added historical QC engine support with `QCSeries`, event-by-event preset evaluation, and retrospective series scanning.
- Added raw-value observation builders, analyte-grouped row/dataframe series adapters, and stable JSON serializers.
- Added richer rule metadata and result payloads including severity, explicit evaluation status, triggering windows, and structured triggering observations.
- Expanded documentation and reference-style tests for historical analysis, multi-material runs, insufficient-data handling, and serialization.

## 0.1.0

- Initial package scaffold for `westgard-python`.
- Added typed models, primitive rule evaluators, named multirule presets, sigma mappings, and planning helpers.
- Added optional pandas adapter, documentation scaffold, tests, and CI/release workflows.
