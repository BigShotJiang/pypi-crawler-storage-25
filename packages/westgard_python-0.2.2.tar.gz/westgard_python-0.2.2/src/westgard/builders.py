"""Builders for observations and historical QC series."""

from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Iterable, Mapping

from .models import ControlObservation, ObservationRow, QCEvent, QCSeries, RunIdentifier

REQUIRED_ROW_KEYS = {"analyte", "material", "run_id", "sequence"}


def observation_from_value(
    *,
    analyte: str,
    material: str,
    run_id: str,
    sequence: int,
    value: float,
    mean: float,
    standard_deviation: float,
    metadata: Mapping[str, str] | None = None,
) -> ControlObservation:
    """Build a typed observation from a raw QC measurement."""

    if standard_deviation <= 0:
        raise ValueError("standard_deviation must be positive.")

    z_score = (value - mean) / standard_deviation
    return ControlObservation(
        analyte=analyte,
        material=material,
        run_id=RunIdentifier(run_id),
        sequence=sequence,
        z_score=z_score,
        value=value,
        mean=mean,
        standard_deviation=standard_deviation,
        metadata=metadata or {},
    )


def series_from_rows(rows: Iterable[ObservationRow | Mapping[str, object]]) -> dict[str, QCSeries]:
    """Build one or more analyte-specific QC series from row-shaped inputs."""

    observations_by_analyte: dict[str, list[ControlObservation]] = defaultdict(list)
    for row in rows:
        observation = _observation_from_row(_coerce_observation_row(row))
        observations_by_analyte[observation.analyte].append(observation)

    return {
        analyte: _series_from_observations(observations)
        for analyte, observations in observations_by_analyte.items()
    }


def _coerce_observation_row(row: ObservationRow | Mapping[str, object]) -> ObservationRow:
    if isinstance(row, ObservationRow):
        return row
    if not isinstance(row, Mapping):
        raise TypeError("rows must contain ObservationRow instances or mapping-like records.")

    missing = REQUIRED_ROW_KEYS.difference(row)
    if missing:
        missing_csv = ", ".join(sorted(missing))
        raise ValueError(f"row is missing required keys: {missing_csv}.")

    metadata = row.get("metadata", {})
    if metadata is None:
        normalized_metadata: Mapping[str, str] = {}
    elif isinstance(metadata, Mapping):
        normalized_metadata = {str(key): str(value) for key, value in metadata.items()}
    else:
        raise TypeError("row metadata must be mapping-like when provided.")

    return ObservationRow(
        analyte=str(row["analyte"]),
        material=str(row["material"]),
        run_id=str(row["run_id"]),
        sequence=_required_int(row["sequence"]),
        z_score=_optional_float(row.get("z_score")),
        value=_optional_float(row.get("value")),
        mean=_optional_float(row.get("mean")),
        standard_deviation=_optional_float(row.get("standard_deviation")),
        metadata=normalized_metadata,
    )


def _optional_float(value: object) -> float | None:
    if value is None:
        return None
    if not isinstance(value, (int, float, str, bytes, bytearray)):
        raise TypeError("numeric row values must be int, float, str, bytes, or bytearray.")
    numeric_value = float(value)
    if math.isnan(numeric_value):
        return None
    return numeric_value


def _required_int(value: object) -> int:
    if isinstance(value, (int, float, str, bytes, bytearray)):
        return int(value)
    raise TypeError("row sequence must be int, float, str, bytes, or bytearray.")


def _observation_from_row(row: ObservationRow) -> ControlObservation:
    has_raw_triplet = (
        row.value is not None and row.mean is not None and row.standard_deviation is not None
    )
    if row.z_score is None:
        if not has_raw_triplet:
            raise ValueError(
                "ObservationRow requires either z_score or value/mean/standard_deviation."
            )
        assert row.value is not None
        assert row.mean is not None
        assert row.standard_deviation is not None
        return observation_from_value(
            analyte=row.analyte,
            material=row.material,
            run_id=row.run_id,
            sequence=row.sequence,
            value=row.value,
            mean=row.mean,
            standard_deviation=row.standard_deviation,
            metadata=row.metadata,
        )

    return ControlObservation(
        analyte=row.analyte,
        material=row.material,
        run_id=RunIdentifier(row.run_id),
        sequence=row.sequence,
        z_score=row.z_score,
        value=row.value,
        mean=row.mean,
        standard_deviation=row.standard_deviation,
        metadata=row.metadata,
    )


def _series_from_observations(observations: list[ControlObservation]) -> QCSeries:
    if not observations:
        raise ValueError("QCSeries requires at least one observation.")

    observations_by_run: dict[RunIdentifier, list[ControlObservation]] = defaultdict(list)
    event_sort_keys: dict[RunIdentifier, tuple[int, int]] = {}

    for observation in sorted(
        observations,
        key=lambda candidate: (candidate.sequence, candidate.run_id.value, candidate.material),
    ):
        observations_by_run[observation.run_id].append(observation)
        run_sort_key = event_sort_keys.get(observation.run_id)
        current_key = (observation.sequence, len(observations_by_run[observation.run_id]))
        if run_sort_key is None or current_key < run_sort_key:
            event_sort_keys[observation.run_id] = current_key

    ordered_run_ids = tuple(
        run_id for run_id, _ in sorted(event_sort_keys.items(), key=lambda item: item[1])
    )
    events = tuple(
        QCEvent(
            run_id=run_id,
            observations=tuple(
                sorted(
                    observations_by_run[run_id],
                    key=lambda candidate: (candidate.sequence, candidate.material),
                )
            ),
        )
        for run_id in ordered_run_ids
    )
    return QCSeries(events=events)
