"""Historical multirule evaluation helpers."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Collection
from dataclasses import dataclass, replace

from .engine import _evaluate_multirule_components
from .models import (
    ControlObservation,
    EvaluationScope,
    EventMultiruleResult,
    HistoricalEmitMode,
    HistoricalRuleViolation,
    HistoricalViolationWindow,
    InterpretationMode,
    MultiruleContext,
    MultiruleVariant,
    QCSeries,
    RuleName,
    RunIdentifier,
    SeriesMultiruleResult,
)

_DEFAULT_HISTORICAL_SCOPES = frozenset(
    {
        EvaluationScope.WITHIN_RUN,
        EvaluationScope.WITHIN_MATERIAL,
    }
)
_ALLOWED_HISTORICAL_SCOPES = frozenset(
    {
        EvaluationScope.WITHIN_RUN,
        EvaluationScope.WITHIN_MATERIAL,
        EvaluationScope.ACROSS_MATERIAL,
    }
)


@dataclass
class _WindowBuilder:
    start_sequence: int
    end_sequence: int
    start_event_index: int
    end_event_index: int
    event_indexes: list[int]
    event_run_ids: list[RunIdentifier]
    violations: list[HistoricalRuleViolation]
    triggering_observations: list[ControlObservation]


def evaluate_multirule_sequence(
    *,
    series: QCSeries,
    preset: MultiruleVariant,
    interpretation_mode: InterpretationMode = InterpretationMode.MODERN,
    enabled_scopes: Collection[EvaluationScope] | None = None,
) -> tuple[EventMultiruleResult, ...]:
    """Evaluate a multirule preset event-by-event across a chronological series."""

    effective_scopes = _normalize_historical_scopes(enabled_scopes)
    include_across_material = EvaluationScope.ACROSS_MATERIAL in effective_scopes
    event_results: list[EventMultiruleResult] = []
    material_streams: dict[str, list[ControlObservation]] = defaultdict(list)
    across_material_stream: list[ControlObservation] = []

    for event_index, event in enumerate(series.events, start=1):
        current_run = tuple(
            sorted(event.observations, key=lambda observation: observation.sequence)
        )
        for observation in current_run:
            material_streams[observation.material].append(observation)
            if include_across_material:
                across_material_stream.append(observation)

        context = MultiruleContext(
            current_run=current_run,
            material_streams={
                material: tuple(stream) for material, stream in material_streams.items()
            },
            across_material_stream=tuple(across_material_stream) if include_across_material else (),
        )
        evaluations, violations, warning_gate, accepted, reason = _evaluate_multirule_components(
            context=context,
            preset=preset,
            interpretation_mode=interpretation_mode,
            include_skipped_when_classic_gate_closed=True,
            enabled_scopes=effective_scopes,
        )
        event_results.append(
            EventMultiruleResult(
                preset=preset,
                interpretation_mode=interpretation_mode,
                event_index=event_index,
                event=event,
                accepted=accepted,
                evaluations=evaluations,
                violations=violations,
                warning_gate=warning_gate,
                reason=reason,
            )
        )

    return tuple(event_results)


def scan_multirule_series(
    *,
    series: QCSeries,
    preset: MultiruleVariant,
    interpretation_mode: InterpretationMode = InterpretationMode.MODERN,
    enabled_scopes: Collection[EvaluationScope] | None = None,
    emit: HistoricalEmitMode = HistoricalEmitMode.ALL_TRIGGERS,
) -> SeriesMultiruleResult:
    """Scan a full historical series and return all multirule triggers."""

    effective_scopes = _normalize_historical_scopes(enabled_scopes)
    event_results = evaluate_multirule_sequence(
        series=series,
        preset=preset,
        interpretation_mode=interpretation_mode,
        enabled_scopes=effective_scopes,
    )
    historical_violations: list[HistoricalRuleViolation] = []
    first_violations_by_rule: dict[RuleName, HistoricalRuleViolation] = {}

    for event_result in event_results:
        for violation in event_result.violations:
            historical_violation = HistoricalRuleViolation(
                preset=preset,
                interpretation_mode=interpretation_mode,
                event_index=event_result.event_index,
                event_run_id=event_result.event.run_id,
                violation=violation,
            )
            historical_violations.append(historical_violation)
            first_violations_by_rule.setdefault(violation.rule, historical_violation)

    selected_violations, violation_windows = _select_historical_violations(
        tuple(historical_violations), emit
    )
    accepted = not historical_violations
    if accepted:
        reason = "No configured rule violations were triggered anywhere in the series."
    elif emit == HistoricalEmitMode.ALL_TRIGGERS_GROUPED_BY_WINDOW:
        reason = (
            f"Triggered {len(violation_windows)} violation window(s) from "
            f"{len(historical_violations)} rule violation(s) across {len(event_results)} event(s)."
        )
    else:
        reason = (
            f"Triggered {len(selected_violations)} emitted violation(s) from "
            f"{len(historical_violations)} total violation(s) across {len(event_results)} event(s)."
        )

    return SeriesMultiruleResult(
        preset=preset,
        interpretation_mode=interpretation_mode,
        series=series,
        event_results=event_results,
        violations=selected_violations,
        enabled_scopes=tuple(sorted(effective_scopes, key=lambda scope: scope.value)),
        emit_mode=emit,
        all_violations=tuple(historical_violations),
        violation_windows=violation_windows,
        first_violations_by_rule=first_violations_by_rule,
        accepted=accepted,
        reason=reason,
    )


def _normalize_historical_scopes(
    enabled_scopes: Collection[EvaluationScope] | None,
) -> frozenset[EvaluationScope]:
    if enabled_scopes is None:
        return _DEFAULT_HISTORICAL_SCOPES

    normalized = frozenset(enabled_scopes)
    if not normalized:
        raise ValueError("enabled_scopes must not be empty.")

    unsupported = set(normalized).difference(_ALLOWED_HISTORICAL_SCOPES)
    if unsupported:
        rendered = ", ".join(sorted(scope.value for scope in unsupported))
        raise ValueError(
            "Historical APIs only support within_run, within_material, and across_material; "
            f"received unsupported scopes: {rendered}."
        )
    return normalized


def _select_historical_violations(
    violations: tuple[HistoricalRuleViolation, ...],
    emit: HistoricalEmitMode,
) -> tuple[tuple[HistoricalRuleViolation, ...], tuple[HistoricalViolationWindow, ...]]:
    if emit == HistoricalEmitMode.ALL_TRIGGERS:
        return violations, ()

    if emit == HistoricalEmitMode.FIRST_TRIGGER_PER_RULE:
        first_by_rule: dict[RuleName, HistoricalRuleViolation] = {}
        for violation in violations:
            first_by_rule.setdefault(violation.violation.rule, violation)
        return tuple(first_by_rule.values()), ()

    if emit == HistoricalEmitMode.FIRST_TRIGGER_PER_RULE_PER_SCOPE:
        first_by_pair: dict[tuple[RuleName, EvaluationScope], HistoricalRuleViolation] = {}
        for violation in violations:
            key = (violation.violation.rule, violation.violation.scope)
            first_by_pair.setdefault(key, violation)
        return tuple(first_by_pair.values()), ()

    if emit == HistoricalEmitMode.ALL_TRIGGERS_GROUPED_BY_WINDOW:
        return _group_historical_violations(violations)

    raise ValueError(f"Unsupported HistoricalEmitMode value: {emit!r}.")


def _group_historical_violations(
    violations: tuple[HistoricalRuleViolation, ...],
) -> tuple[tuple[HistoricalRuleViolation, ...], tuple[HistoricalViolationWindow, ...]]:
    grouped_state: dict[tuple[RuleName, EvaluationScope, str], list[_WindowBuilder]] = defaultdict(
        list
    )

    for violation in violations:
        payload = violation.violation
        if payload.start_sequence is None or payload.end_sequence is None:
            continue

        key = (payload.rule, payload.scope, payload.stream_name)
        groups = grouped_state[key]
        if groups and groups[-1].end_sequence + 1 >= payload.start_sequence:
            group = groups[-1]
            group.end_sequence = max(group.end_sequence, payload.end_sequence)
            group.end_event_index = max(group.end_event_index, violation.event_index)
            if violation.event_index not in group.event_indexes:
                group.event_indexes.append(violation.event_index)
            if violation.event_run_id not in group.event_run_ids:
                group.event_run_ids.append(violation.event_run_id)
            group.violations.append(violation)
            for observation in payload.triggering_observations:
                if observation not in group.triggering_observations:
                    group.triggering_observations.append(observation)
            continue

        groups.append(
            _WindowBuilder(
                start_sequence=payload.start_sequence,
                end_sequence=payload.end_sequence,
                start_event_index=violation.event_index,
                end_event_index=violation.event_index,
                event_indexes=[violation.event_index],
                event_run_ids=[violation.event_run_id],
                violations=[violation],
                triggering_observations=list(payload.triggering_observations),
            )
        )

    selected: list[HistoricalRuleViolation] = []
    windows: list[HistoricalViolationWindow] = []
    for (rule, scope, stream_name), groups in sorted(
        grouped_state.items(), key=lambda item: (item[0][0].value, item[0][1].value, item[0][2])
    ):
        for index, group in enumerate(groups, start=1):
            window_id = f"{rule.value}:{scope.value}:{stream_name}:{index}"
            representative = replace(group.violations[0], window_id=window_id)
            selected.append(representative)
            windows.append(
                HistoricalViolationWindow(
                    window_id=window_id,
                    rule=rule,
                    scope=scope,
                    severity=representative.violation.severity,
                    start_sequence=group.start_sequence,
                    end_sequence=group.end_sequence,
                    start_event_index=group.start_event_index,
                    end_event_index=group.end_event_index,
                    event_indexes=tuple(group.event_indexes),
                    event_run_ids=tuple(group.event_run_ids),
                    triggering_observations=tuple(group.triggering_observations),
                )
            )
    return tuple(selected), tuple(windows)
