"""Primitive rule definitions and evaluators."""

from __future__ import annotations

from dataclasses import dataclass

from .models import (
    ControlObservation,
    EvaluationResult,
    EvaluationScope,
    RuleEvaluationStatus,
    RuleName,
    RuleSeverity,
    RuleTaxonomy,
)

STRICT_LIMIT_NOTE = "Control-limit triggers use strict inequality; boundary values do not violate."


@dataclass(frozen=True)
class RuleDefinition:
    """Static metadata for one rule."""

    name: RuleName
    taxonomy: RuleTaxonomy
    minimum_observations: int
    default_scope: EvaluationScope
    intended_error: str
    description: str
    severity: RuleSeverity = RuleSeverity.PRESET_DEPENDENT


RULE_DEFINITIONS: dict[RuleName, RuleDefinition] = {
    RuleName.ONE_2S: RuleDefinition(
        RuleName.ONE_2S,
        RuleTaxonomy.ADJACENT_NONCORE_RULE,
        1,
        EvaluationScope.WITHIN_RUN,
        "warning gate / historical compatibility",
        "One observation exceeds +/-2 SD.",
        RuleSeverity.PRESET_DEPENDENT,
    ),
    RuleName.ONE_3S: RuleDefinition(
        RuleName.ONE_3S,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        1,
        EvaluationScope.WITHIN_RUN,
        "random error or large shift",
        "One observation exceeds +/-3 SD.",
        RuleSeverity.REJECTION,
    ),
    RuleName.TWO_2S: RuleDefinition(
        RuleName.TWO_2S,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        2,
        EvaluationScope.WITHIN_MATERIAL,
        "systematic error",
        "Two consecutive observations exceed the same +/-2 SD limit.",
        RuleSeverity.REJECTION,
    ),
    RuleName.R_4S: RuleDefinition(
        RuleName.R_4S,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        2,
        EvaluationScope.WITHIN_RUN,
        "random error",
        "Same-run pair spans more than 4 SD by having one > +2 SD and one < -2 SD.",
        RuleSeverity.REJECTION,
    ),
    RuleName.FOUR_1S: RuleDefinition(
        RuleName.FOUR_1S,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        4,
        EvaluationScope.WITHIN_MATERIAL,
        "systematic error",
        "Four consecutive observations exceed the same +/-1 SD limit.",
        RuleSeverity.REJECTION,
    ),
    RuleName.EIGHT_X: RuleDefinition(
        RuleName.EIGHT_X,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        8,
        EvaluationScope.WITHIN_MATERIAL,
        "persistent bias",
        "Eight consecutive observations lie on the same side of the mean.",
        RuleSeverity.REJECTION,
    ),
    RuleName.TEN_X: RuleDefinition(
        RuleName.TEN_X,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        10,
        EvaluationScope.WITHIN_MATERIAL,
        "persistent bias / long drift",
        "Ten consecutive observations lie on the same side of the mean.",
        RuleSeverity.REJECTION,
    ),
    RuleName.TWELVE_X: RuleDefinition(
        RuleName.TWELVE_X,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        12,
        EvaluationScope.WITHIN_MATERIAL,
        "persistent bias / long drift",
        "Twelve consecutive observations lie on the same side of the mean.",
        RuleSeverity.REJECTION,
    ),
    RuleName.TWO_OF_THREE_2S: RuleDefinition(
        RuleName.TWO_OF_THREE_2S,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        3,
        EvaluationScope.WITHIN_MATERIAL,
        "systematic error",
        "Two of the last three observations exceed the same +/-2 SD limit.",
        RuleSeverity.REJECTION,
    ),
    RuleName.THREE_1S: RuleDefinition(
        RuleName.THREE_1S,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        3,
        EvaluationScope.WITHIN_MATERIAL,
        "systematic error",
        "Three consecutive observations exceed the same +/-1 SD limit.",
        RuleSeverity.REJECTION,
    ),
    RuleName.SIX_X: RuleDefinition(
        RuleName.SIX_X,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        6,
        EvaluationScope.WITHIN_MATERIAL,
        "persistent bias",
        "Six consecutive observations lie on the same side of the mean.",
        RuleSeverity.REJECTION,
    ),
    RuleName.NINE_X: RuleDefinition(
        RuleName.NINE_X,
        RuleTaxonomy.CORE_WESTGARD_RULE,
        9,
        EvaluationScope.WITHIN_MATERIAL,
        "persistent bias",
        "Nine consecutive observations lie on the same side of the mean.",
        RuleSeverity.REJECTION,
    ),
    RuleName.SEVEN_T: RuleDefinition(
        RuleName.SEVEN_T,
        RuleTaxonomy.ADJACENT_NONCORE_RULE,
        7,
        EvaluationScope.WITHIN_MATERIAL,
        "trend",
        "Seven consecutive observations trend strictly upward or downward.",
        RuleSeverity.REJECTION,
    ),
}


def get_rule_definition(rule: RuleName) -> RuleDefinition:
    """Return static metadata for a rule."""

    return RULE_DEFINITIONS[rule]


def evaluate_rule(
    rule: RuleName,
    observations: tuple[ControlObservation, ...],
    *,
    scope: EvaluationScope,
    stream_name: str,
) -> EvaluationResult:
    """Evaluate one rule against one explicit observation stream."""

    definition = get_rule_definition(rule)
    ordered = tuple(sorted(observations, key=lambda observation: observation.sequence))
    if len(ordered) < definition.minimum_observations:
        return _result(
            rule=rule,
            scope=scope,
            stream_name=stream_name,
            violated=False,
            enough_data=False,
            required_observations=definition.minimum_observations,
            considered_observations=ordered,
            triggering_observations=(),
            reason=(
                f"{rule.value} requires {definition.minimum_observations} observations; "
                f"received {len(ordered)}."
            ),
            status=RuleEvaluationStatus.INSUFFICIENT_DATA,
        )

    if rule in {RuleName.ONE_2S, RuleName.ONE_3S}:
        return _evaluate_single_limit_rule(rule, ordered, scope, stream_name)
    if rule == RuleName.R_4S:
        return _evaluate_r_4s(ordered, scope, stream_name)
    if rule == RuleName.TWO_2S:
        return _evaluate_same_side_limit_rule(rule, ordered, scope, stream_name, count=2, limit=2.0)
    if rule == RuleName.FOUR_1S:
        return _evaluate_same_side_limit_rule(rule, ordered, scope, stream_name, count=4, limit=1.0)
    if rule == RuleName.TWO_OF_THREE_2S:
        return _evaluate_two_of_three_2s(ordered, scope, stream_name)
    if rule == RuleName.THREE_1S:
        return _evaluate_same_side_limit_rule(rule, ordered, scope, stream_name, count=3, limit=1.0)
    if rule == RuleName.EIGHT_X:
        return _evaluate_same_side_mean_rule(rule, ordered, scope, stream_name, count=8)
    if rule == RuleName.TEN_X:
        return _evaluate_same_side_mean_rule(rule, ordered, scope, stream_name, count=10)
    if rule == RuleName.TWELVE_X:
        return _evaluate_same_side_mean_rule(rule, ordered, scope, stream_name, count=12)
    if rule == RuleName.SIX_X:
        return _evaluate_same_side_mean_rule(rule, ordered, scope, stream_name, count=6)
    if rule == RuleName.NINE_X:
        return _evaluate_same_side_mean_rule(rule, ordered, scope, stream_name, count=9)
    if rule == RuleName.SEVEN_T:
        return _evaluate_trend_rule(ordered, scope, stream_name)
    raise ValueError(f"Unsupported rule {rule.value!r}.")


def make_skipped_evaluation(
    rule: RuleName,
    *,
    scope: EvaluationScope,
    stream_name: str,
    available_observations: tuple[ControlObservation, ...],
    reason: str,
) -> EvaluationResult:
    """Build an explicit skipped rule result."""

    definition = get_rule_definition(rule)
    return _result(
        rule=rule,
        scope=scope,
        stream_name=stream_name,
        violated=False,
        enough_data=len(available_observations) >= definition.minimum_observations,
        required_observations=definition.minimum_observations,
        considered_observations=available_observations,
        triggering_observations=(),
        reason=reason,
        status=RuleEvaluationStatus.SKIPPED_BY_WARNING_GATE,
    )


def _result(
    *,
    rule: RuleName,
    scope: EvaluationScope,
    stream_name: str,
    violated: bool,
    enough_data: bool,
    required_observations: int,
    considered_observations: tuple[ControlObservation, ...],
    triggering_observations: tuple[ControlObservation, ...],
    reason: str,
    status: RuleEvaluationStatus | None = None,
) -> EvaluationResult:
    definition = get_rule_definition(rule)
    resolved_status = status
    if resolved_status is None:
        if violated:
            resolved_status = RuleEvaluationStatus.VIOLATED
        elif enough_data:
            resolved_status = RuleEvaluationStatus.NOT_VIOLATED
        else:
            resolved_status = RuleEvaluationStatus.INSUFFICIENT_DATA

    return EvaluationResult(
        rule=rule,
        taxonomy=definition.taxonomy,
        scope=scope,
        stream_name=stream_name,
        violated=violated,
        enough_data=enough_data,
        required_observations=required_observations,
        considered_observations=considered_observations,
        triggering_observations=triggering_observations,
        reason=reason,
        status=resolved_status,
        severity=definition.severity,
    )


def _evaluate_single_limit_rule(
    rule: RuleName,
    observations: tuple[ControlObservation, ...],
    scope: EvaluationScope,
    stream_name: str,
) -> EvaluationResult:
    limit = 2.0 if rule == RuleName.ONE_2S else 3.0
    triggering = tuple(
        observation
        for observation in observations
        if observation.z_score > limit or observation.z_score < -limit
    )
    violated = bool(triggering)
    if violated:
        triggered_sequences = ", ".join(
            str(observation.sequence) for observation in triggering
        )
        reason = (
            f"{rule.value} violated in {stream_name}: "
            f"{triggered_sequences} exceeded +/-{limit:g} SD."
        )
    else:
        reason = f"{rule.value} not violated in {stream_name}. {STRICT_LIMIT_NOTE}"
    return _result(
        rule=rule,
        scope=scope,
        stream_name=stream_name,
        violated=violated,
        enough_data=True,
        required_observations=1,
        considered_observations=observations,
        triggering_observations=triggering,
        reason=reason,
    )


def _evaluate_r_4s(
    observations: tuple[ControlObservation, ...],
    scope: EvaluationScope,
    stream_name: str,
) -> EvaluationResult:
    if scope != EvaluationScope.WITHIN_RUN:
        raise ValueError("R_4s must be evaluated with scope=within_run.")
    high = [observation for observation in observations if observation.z_score > 2.0]
    low = [observation for observation in observations if observation.z_score < -2.0]
    violated = bool(high and low)
    triggering: tuple[ControlObservation, ...] = ()
    if violated:
        max_high = max(high, key=lambda observation: observation.z_score)
        min_low = min(low, key=lambda observation: observation.z_score)
        triggering = (max_high, min_low)
    reason = (
        f"R_4s violated in {stream_name}: same-run observations span opposite sides beyond +/-2 SD."
        if violated
        else f"R_4s not violated in {stream_name}. {STRICT_LIMIT_NOTE}"
    )
    return _result(
        rule=RuleName.R_4S,
        scope=scope,
        stream_name=stream_name,
        violated=violated,
        enough_data=True,
        required_observations=2,
        considered_observations=observations,
        triggering_observations=triggering,
        reason=reason,
    )


def _evaluate_same_side_limit_rule(
    rule: RuleName,
    observations: tuple[ControlObservation, ...],
    scope: EvaluationScope,
    stream_name: str,
    *,
    count: int,
    limit: float,
) -> EvaluationResult:
    window = observations[-count:]
    positives = all(observation.z_score > limit for observation in window)
    negatives = all(observation.z_score < -limit for observation in window)
    violated = positives or negatives
    direction = "positive" if positives else "negative" if negatives else "none"
    reason = (
        f"{rule.value} violated in {stream_name}: last {count} observations all exceeded the "
        f"same {direction} {limit:g} SD limit."
        if violated
        else f"{rule.value} not violated in {stream_name}. {STRICT_LIMIT_NOTE}"
    )
    return _result(
        rule=rule,
        scope=scope,
        stream_name=stream_name,
        violated=violated,
        enough_data=True,
        required_observations=count,
        considered_observations=window,
        triggering_observations=window if violated else (),
        reason=reason,
    )


def _evaluate_same_side_mean_rule(
    rule: RuleName,
    observations: tuple[ControlObservation, ...],
    scope: EvaluationScope,
    stream_name: str,
    *,
    count: int,
) -> EvaluationResult:
    window = observations[-count:]
    positives = all(observation.z_score > 0.0 for observation in window)
    negatives = all(observation.z_score < 0.0 for observation in window)
    violated = positives or negatives
    reason = (
        f"{rule.value} violated in {stream_name}: "
        f"last {count} observations were all on one side of the mean."
        if violated
        else f"{rule.value} not violated in {stream_name}; values on the mean break the streak."
    )
    return _result(
        rule=rule,
        scope=scope,
        stream_name=stream_name,
        violated=violated,
        enough_data=True,
        required_observations=count,
        considered_observations=window,
        triggering_observations=window if violated else (),
        reason=reason,
    )


def _evaluate_two_of_three_2s(
    observations: tuple[ControlObservation, ...],
    scope: EvaluationScope,
    stream_name: str,
) -> EvaluationResult:
    window = observations[-3:]
    positive_hits = tuple(observation for observation in window if observation.z_score > 2.0)
    negative_hits = tuple(observation for observation in window if observation.z_score < -2.0)
    if len(positive_hits) >= 2:
        violated = True
        triggering = positive_hits[:2]
        reason = (
            f"2of3_2s violated in {stream_name}: "
            "at least two of the last three observations exceeded +2 SD."
        )
    elif len(negative_hits) >= 2:
        violated = True
        triggering = negative_hits[:2]
        reason = (
            f"2of3_2s violated in {stream_name}: "
            "at least two of the last three observations exceeded -2 SD."
        )
    else:
        violated = False
        triggering = ()
        reason = f"2of3_2s not violated in {stream_name}. {STRICT_LIMIT_NOTE}"
    return _result(
        rule=RuleName.TWO_OF_THREE_2S,
        scope=scope,
        stream_name=stream_name,
        violated=violated,
        enough_data=True,
        required_observations=3,
        considered_observations=window,
        triggering_observations=triggering,
        reason=reason,
    )


def _evaluate_trend_rule(
    observations: tuple[ControlObservation, ...],
    scope: EvaluationScope,
    stream_name: str,
) -> EvaluationResult:
    window = observations[-7:]
    increases = all(
        left.z_score < right.z_score for left, right in zip(window, window[1:], strict=False)
    )
    decreases = all(
        left.z_score > right.z_score for left, right in zip(window, window[1:], strict=False)
    )
    violated = increases or decreases
    reason = (
        f"7_T violated in {stream_name}: last seven observations formed a strict monotonic trend."
        if violated
        else (
            f"7_T not violated in {stream_name}; "
            "equal or direction-changing values break the trend."
        )
    )
    return _result(
        rule=RuleName.SEVEN_T,
        scope=scope,
        stream_name=stream_name,
        violated=violated,
        enough_data=True,
        required_observations=7,
        considered_observations=window,
        triggering_observations=window if violated else (),
        reason=reason,
    )
