"""Typed public models for Westgard QC evaluation."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from enum import Enum


class EvaluationScope(str, Enum):
    """Canonical scope labels from the master reference."""

    WITHIN_RUN = "within_run"
    ACROSS_RUN = "across_run"
    ACROSS_MATERIAL = "across_material"
    WITHIN_MATERIAL = "within_material"


class InterpretationMode(str, Enum):
    """How the multirule engine interprets warning-gate behavior."""

    CLASSIC = "classic"
    MODERN = "modern"


class RuleTaxonomy(str, Enum):
    """Package taxonomy for documented rules."""

    CORE_WESTGARD_RULE = "core_westgard_rule"
    ADJACENT_NONCORE_RULE = "adjacent_noncore_rule"


class RuleSeverity(str, Enum):
    """Operational severity classification for a rule or evaluation."""

    WARNING = "warning"
    REJECTION = "rejection"
    PRESET_DEPENDENT = "preset_dependent"


class RuleEvaluationStatus(str, Enum):
    """Machine-friendly status for one evaluated or skipped rule."""

    VIOLATED = "violated"
    NOT_VIOLATED = "not_violated"
    INSUFFICIENT_DATA = "insufficient_data"
    SKIPPED_BY_WARNING_GATE = "skipped_by_warning_gate"


class HistoricalEmitMode(str, Enum):
    """How retrospective scans emit historical violations."""

    ALL_TRIGGERS = "all_triggers"
    FIRST_TRIGGER_PER_RULE = "first_trigger_per_rule"
    FIRST_TRIGGER_PER_RULE_PER_SCOPE = "first_trigger_per_rule_per_scope"
    ALL_TRIGGERS_GROUPED_BY_WINDOW = "all_triggers_grouped_by_window"


class RuleNameOutputMode(str, Enum):
    """Rule-name formatting mode for serializers."""

    CANONICAL = "canonical"
    COMPACT = "compact"
    CLINICAL = "clinical"


class RuleName(str, Enum):
    """Canonical package rule names."""

    ONE_2S = "1_2s"
    ONE_3S = "1_3s"
    TWO_2S = "2_2s"
    R_4S = "R_4s"
    FOUR_1S = "4_1s"
    EIGHT_X = "8_x"
    TEN_X = "10_x"
    TWELVE_X = "12_x"
    TWO_OF_THREE_2S = "2of3_2s"
    THREE_1S = "3_1s"
    SIX_X = "6_x"
    NINE_X = "9_x"
    SEVEN_T = "7_T"


class MultiruleVariant(str, Enum):
    """Named Westgard multirule families."""

    CLASSIC_2_CONTROL = "classic_2_control"
    MODERN_2_CONTROL = "modern_2_control"
    MODERN_2_CONTROL_LEGACY_10X = "modern_2_control_legacy_10x"
    CLASSIC_3_CONTROL = "classic_3_control"
    MODERN_3_CONTROL = "modern_3_control"


class PlanningMode(str, Enum):
    """Operational planning mode."""

    STARTUP = "startup"
    MONITOR = "monitor"


@dataclass(frozen=True, order=True)
class RunIdentifier:
    """Explicit run identifier. Timestamps alone are not accepted as run boundaries."""

    value: str

    def __post_init__(self) -> None:
        if not self.value:
            raise ValueError("RunIdentifier.value must be a non-empty string.")

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, order=True)
class ControlObservation:
    """A single QC observation for one analyte and one control material."""

    analyte: str
    material: str
    run_id: RunIdentifier
    sequence: int
    z_score: float
    value: float | None = None
    mean: float | None = None
    standard_deviation: float | None = None
    metadata: Mapping[str, str] = field(default_factory=dict, compare=False)

    def __post_init__(self) -> None:
        if not self.analyte:
            raise ValueError("analyte must be provided.")
        if not self.material:
            raise ValueError("material must be provided.")
        if self.sequence < 0:
            raise ValueError("sequence must be >= 0.")
        if self.standard_deviation is not None and self.standard_deviation <= 0:
            raise ValueError("standard_deviation must be positive when provided.")


@dataclass(frozen=True)
class ObservationRow:
    """Typed row input for historical builders and tabular adapters."""

    analyte: str
    material: str
    run_id: str
    sequence: int
    z_score: float | None = None
    value: float | None = None
    mean: float | None = None
    standard_deviation: float | None = None
    metadata: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.analyte:
            raise ValueError("ObservationRow.analyte must be provided.")
        if not self.material:
            raise ValueError("ObservationRow.material must be provided.")
        if not self.run_id:
            raise ValueError("ObservationRow.run_id must be provided.")
        if self.sequence < 0:
            raise ValueError("ObservationRow.sequence must be >= 0.")
        if self.standard_deviation is not None and self.standard_deviation <= 0:
            raise ValueError("ObservationRow.standard_deviation must be positive when provided.")
        has_raw_triplet = (
            self.value is not None
            and self.mean is not None
            and self.standard_deviation is not None
        )
        if self.z_score is None and not has_raw_triplet:
            raise ValueError(
                "ObservationRow requires either z_score or value/mean/standard_deviation."
            )


@dataclass(frozen=True)
class QCEvent:
    """One QC event and its control observations."""

    run_id: RunIdentifier
    observations: tuple[ControlObservation, ...]

    def __post_init__(self) -> None:
        if not self.observations:
            raise ValueError("QCEvent must contain at least one observation.")
        if any(observation.run_id != self.run_id for observation in self.observations):
            raise ValueError("All QCEvent observations must share the event run identifier.")


@dataclass(frozen=True)
class QCSeries:
    """Chronological single-analyte QC history with derived event and stream views."""

    events: tuple[QCEvent, ...]
    analyte: str = field(init=False)
    observations: tuple[ControlObservation, ...] = field(init=False, repr=False)
    material_streams: Mapping[str, tuple[ControlObservation, ...]] = field(init=False, repr=False)
    across_material_stream: tuple[ControlObservation, ...] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not self.events:
            raise ValueError("QCSeries must contain at least one event.")

        ordered_events = tuple(
            sorted(
                self.events,
                key=lambda event: min(observation.sequence for observation in event.observations),
            )
        )
        if ordered_events != self.events:
            raise ValueError("QCSeries.events must be ordered chronologically by sequence.")

        run_ids: set[RunIdentifier] = set()
        all_observations: list[ControlObservation] = []
        material_streams: dict[str, list[ControlObservation]] = defaultdict(list)
        analyte: str | None = None
        last_sequence: int | None = None

        for event in ordered_events:
            if event.run_id in run_ids:
                raise ValueError("QCSeries events must have unique run identifiers.")
            run_ids.add(event.run_id)

            event_materials: set[str] = set()
            ordered_observations = tuple(
                sorted(event.observations, key=lambda observation: observation.sequence)
            )
            for observation in ordered_observations:
                if analyte is None:
                    analyte = observation.analyte
                elif observation.analyte != analyte:
                    raise ValueError("QCSeries observations must all share one analyte.")

                if observation.material in event_materials:
                    raise ValueError(
                        "QCSeries allows at most one observation per material within a run."
                    )
                event_materials.add(observation.material)

                if last_sequence is not None and observation.sequence < last_sequence:
                    raise ValueError(
                        "QCSeries observations must be globally ordered by nondecreasing sequence."
                    )
                last_sequence = observation.sequence

                all_observations.append(observation)
                material_streams[observation.material].append(observation)

        object.__setattr__(self, "analyte", analyte or "")
        object.__setattr__(self, "observations", tuple(all_observations))
        object.__setattr__(
            self,
            "material_streams",
            {material: tuple(stream) for material, stream in material_streams.items()},
        )
        object.__setattr__(self, "across_material_stream", tuple(all_observations))


@dataclass(frozen=True)
class RuleViolation:
    """Structured description of a rule violation."""

    rule: RuleName
    scope: EvaluationScope
    stream_name: str
    message: str
    observation_sequences: tuple[int, ...]
    observation_materials: tuple[str, ...]
    severity: RuleSeverity = RuleSeverity.PRESET_DEPENDENT
    start_sequence: int | None = None
    end_sequence: int | None = None
    triggering_observations: tuple[ControlObservation, ...] = ()

    def __post_init__(self) -> None:
        if self.triggering_observations and (
            self.start_sequence is None or self.end_sequence is None
        ):
            sequences = tuple(observation.sequence for observation in self.triggering_observations)
            object.__setattr__(self, "start_sequence", min(sequences))
            object.__setattr__(self, "end_sequence", max(sequences))


@dataclass(frozen=True)
class EvaluationResult:
    """Result of evaluating one rule against one explicit stream."""

    rule: RuleName
    taxonomy: RuleTaxonomy
    scope: EvaluationScope
    stream_name: str
    violated: bool
    enough_data: bool
    required_observations: int
    considered_observations: tuple[ControlObservation, ...]
    triggering_observations: tuple[ControlObservation, ...]
    reason: str
    status: RuleEvaluationStatus = RuleEvaluationStatus.NOT_VIOLATED
    severity: RuleSeverity = RuleSeverity.PRESET_DEPENDENT

    def __post_init__(self) -> None:
        if self.status == RuleEvaluationStatus.NOT_VIOLATED:
            if self.violated:
                object.__setattr__(self, "status", RuleEvaluationStatus.VIOLATED)
            elif not self.enough_data:
                object.__setattr__(self, "status", RuleEvaluationStatus.INSUFFICIENT_DATA)

    def to_violation(self) -> RuleViolation | None:
        """Convert a violating result into a violation record."""
        if not self.violated:
            return None
        sequences = tuple(observation.sequence for observation in self.triggering_observations)
        return RuleViolation(
            rule=self.rule,
            scope=self.scope,
            stream_name=self.stream_name,
            message=self.reason,
            observation_sequences=sequences,
            observation_materials=tuple(
                observation.material for observation in self.triggering_observations
            ),
            severity=self.severity,
            start_sequence=min(sequences) if sequences else None,
            end_sequence=max(sequences) if sequences else None,
            triggering_observations=self.triggering_observations,
        )


@dataclass(frozen=True)
class MultiruleResult:
    """Composite result for a named multirule preset."""

    preset: MultiruleVariant
    interpretation_mode: InterpretationMode
    accepted: bool
    evaluations: tuple[EvaluationResult, ...]
    violations: tuple[RuleViolation, ...]
    warning_gate: EvaluationResult | None
    reason: str


@dataclass(frozen=True)
class EventMultiruleResult:
    """Composite result for one event evaluated with history available to that event."""

    preset: MultiruleVariant
    interpretation_mode: InterpretationMode
    event_index: int
    event: QCEvent
    accepted: bool
    evaluations: tuple[EvaluationResult, ...]
    violations: tuple[RuleViolation, ...]
    warning_gate: EvaluationResult | None
    reason: str


@dataclass(frozen=True)
class HistoricalRuleViolation:
    """One rule trigger located during a chronological retrospective scan."""

    preset: MultiruleVariant
    interpretation_mode: InterpretationMode
    event_index: int
    event_run_id: RunIdentifier
    violation: RuleViolation
    window_id: str | None = None


@dataclass(frozen=True)
class HistoricalViolationWindow:
    """Grouped historical violation window for reporting/charting consumers."""

    window_id: str
    rule: RuleName
    scope: EvaluationScope
    severity: RuleSeverity
    start_sequence: int
    end_sequence: int
    start_event_index: int
    end_event_index: int
    event_indexes: tuple[int, ...]
    event_run_ids: tuple[RunIdentifier, ...]
    triggering_observations: tuple[ControlObservation, ...]


@dataclass(frozen=True)
class SeriesMultiruleResult:
    """Retrospective result across a full chronological QC series."""

    preset: MultiruleVariant
    interpretation_mode: InterpretationMode
    series: QCSeries
    event_results: tuple[EventMultiruleResult, ...]
    violations: tuple[HistoricalRuleViolation, ...]
    first_violations_by_rule: Mapping[RuleName, HistoricalRuleViolation]
    accepted: bool
    reason: str
    enabled_scopes: tuple[EvaluationScope, ...] = (
        EvaluationScope.WITHIN_RUN,
        EvaluationScope.WITHIN_MATERIAL,
    )
    emit_mode: HistoricalEmitMode = HistoricalEmitMode.ALL_TRIGGERS
    all_violations: tuple[HistoricalRuleViolation, ...] = ()
    violation_windows: tuple[HistoricalViolationWindow, ...] = ()


@dataclass(frozen=True)
class SigmaMetrics:
    """Inputs and derived sigma metric."""

    total_allowable_error: float
    bias: float
    coefficient_of_variation: float
    sigma: float
    analyte: str | None = None
    level: str | None = None


@dataclass(frozen=True)
class SigmaRuleMapping:
    """Reference-backed mapping from sigma band to control design."""

    sigma_band: str
    control_levels: int
    recommended_rules: tuple[RuleName, ...]
    control_measurements_per_event: int
    max_runs_between_qc_events: int
    note: str


@dataclass(frozen=True)
class PlanningRecommendation:
    """Textual but structured planning recommendation constrained to the reference doc."""

    mode: PlanningMode
    sigma_metrics: SigmaMetrics
    sigma_mapping: SigmaRuleMapping
    residual_risk_target: float
    qc_event_note: str
    run_size_note: str
    out_of_control_recovery: tuple[str, ...]
    rationale: tuple[str, ...]


@dataclass(frozen=True)
class MultiruleContext:
    """Explicit streams required for multirule evaluation."""

    current_run: tuple[ControlObservation, ...]
    material_streams: Mapping[str, tuple[ControlObservation, ...]]
    across_material_stream: tuple[ControlObservation, ...] = ()

    def __post_init__(self) -> None:
        if not self.current_run:
            raise ValueError("current_run must contain at least one observation.")
        run_ids = {observation.run_id for observation in self.current_run}
        if len(run_ids) != 1:
            raise ValueError("current_run observations must belong to one explicit run.")
        if not self.material_streams:
            raise ValueError("material_streams must not be empty.")
        for stream_name, observations in self.material_streams.items():
            if not observations:
                raise ValueError(f"material stream {stream_name!r} must not be empty.")


def flatten_events(events: Iterable[QCEvent]) -> tuple[ControlObservation, ...]:
    """Return a globally ordered observation tuple from one or more events."""

    return tuple(
        observation
        for event in events
        for observation in sorted(event.observations, key=lambda candidate: candidate.sequence)
    )
