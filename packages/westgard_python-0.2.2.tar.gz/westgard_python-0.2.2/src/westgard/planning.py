"""Reference-backed planning helpers."""

from __future__ import annotations

from .models import PlanningMode, PlanningRecommendation, SigmaMetrics
from .sigma import recommend_sigma_rules


def plan_qc_strategy(
    *,
    sigma_metrics: SigmaMetrics,
    control_levels: int,
    mode: PlanningMode = PlanningMode.MONITOR,
    residual_risk_target: float = 1.0,
) -> PlanningRecommendation:
    """Return a deterministic planning recommendation constrained to the reference doc."""
    if residual_risk_target <= 0:
        raise ValueError("residual_risk_target must be positive.")
    mapping = recommend_sigma_rules(sigma=sigma_metrics.sigma, control_levels=control_levels)
    if mode == PlanningMode.STARTUP:
        qc_event_note = (
            "Startup mode should schedule QC events more aggressively after "
            "calibration, maintenance, troubleshooting, or major reagent changes."
        )
        run_size_note = (
            "Prefer smaller run sizes than routine monitor mode and confirm "
            "final QC frequency with patient-risk analysis before release."
        )
    else:
        qc_event_note = (
            "Monitor mode favors lower false rejection during stable routine "
            "operation while preserving documented sigma-linked error detection."
        )
        run_size_note = (
            "Use the sigma mapping as the rule-selection layer, then determine "
            "run size or QC frequency with a risk-based workflow rather than "
            "fixed folklore intervals."
        )
    recovery = (
        "Stop using repeat-until-pass as the recovery strategy.",
        "Document corrective action for the out-of-control condition.",
        "Review potentially affected patient results before release or amendment.",
    )
    rationale = (
        "Planning is reference-backed and intentionally conservative.",
        "The package does not invent unsupported run-size optimization formulas.",
        (
            f"Residual risk target is recorded as {residual_risk_target:g} and "
            "remains laboratory-specific."
        ),
    )
    return PlanningRecommendation(
        mode=mode,
        sigma_metrics=sigma_metrics,
        sigma_mapping=mapping,
        residual_risk_target=residual_risk_target,
        qc_event_note=qc_event_note,
        run_size_note=run_size_note,
        out_of_control_recovery=recovery,
        rationale=rationale,
    )
