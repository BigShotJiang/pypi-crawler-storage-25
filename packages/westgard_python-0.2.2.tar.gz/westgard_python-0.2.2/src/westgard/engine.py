"""Multirule evaluation engine."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import replace

from .models import (
    ControlObservation,
    EvaluationResult,
    EvaluationScope,
    InterpretationMode,
    MultiruleContext,
    MultiruleResult,
    MultiruleVariant,
    RuleName,
    RuleSeverity,
    RuleViolation,
)
from .presets import get_preset_definition
from .rules import evaluate_rule, make_skipped_evaluation

_DEFAULT_EVALUATION_SCOPES = frozenset(
    {
        EvaluationScope.WITHIN_RUN,
        EvaluationScope.WITHIN_MATERIAL,
        EvaluationScope.ACROSS_MATERIAL,
    }
)


def evaluate_multirule(
    *,
    context: MultiruleContext,
    preset: MultiruleVariant,
    interpretation_mode: InterpretationMode = InterpretationMode.MODERN,
) -> MultiruleResult:
    """Evaluate a named multirule preset against explicit streams."""

    evaluations, violations, warning_gate, accepted, reason = _evaluate_multirule_components(
        context=context,
        preset=preset,
        interpretation_mode=interpretation_mode,
        include_skipped_when_classic_gate_closed=False,
        enabled_scopes=_DEFAULT_EVALUATION_SCOPES,
    )
    return MultiruleResult(
        preset=preset,
        interpretation_mode=interpretation_mode,
        accepted=accepted,
        evaluations=evaluations,
        violations=violations,
        warning_gate=warning_gate,
        reason=reason,
    )


def _evaluate_multirule_components(
    *,
    context: MultiruleContext,
    preset: MultiruleVariant,
    interpretation_mode: InterpretationMode,
    include_skipped_when_classic_gate_closed: bool,
    enabled_scopes: frozenset[EvaluationScope] | None = None,
) -> tuple[
    tuple[EvaluationResult, ...],
    tuple[RuleViolation, ...],
    EvaluationResult | None,
    bool,
    str,
]:
    effective_scopes = enabled_scopes or _DEFAULT_EVALUATION_SCOPES
    include_within_run = EvaluationScope.WITHIN_RUN in effective_scopes
    preset_definition = get_preset_definition(preset)
    current_run = tuple(sorted(context.current_run, key=lambda observation: observation.sequence))
    current_run_stream_name = f"current_run:{current_run[0].run_id}"

    warning_gate: EvaluationResult | None = None
    evaluations: list[EvaluationResult] = []

    if interpretation_mode == InterpretationMode.CLASSIC and include_within_run:
        warning_gate = replace(
            evaluate_rule(
                RuleName.ONE_2S,
                current_run,
                scope=EvaluationScope.WITHIN_RUN,
                stream_name=current_run_stream_name,
            ),
            severity=RuleSeverity.WARNING,
        )
        evaluations.append(warning_gate)
        if not warning_gate.violated:
            if include_skipped_when_classic_gate_closed:
                if include_within_run:
                    evaluations.extend(
                        _skipped_current_run_rules(
                            current_run,
                            current_run_stream_name,
                            preset_definition.current_run_rules,
                        )
                    )
                evaluations.extend(
                    _skipped_history_rules(
                        context,
                        preset_definition.history_rules,
                        enabled_scopes=effective_scopes,
                    )
                )
            return (
                tuple(evaluations),
                (),
                warning_gate,
                True,
                (
                    "Classic mode accepted the run because no current-run "
                    "1_2s warning gate was triggered."
                ),
            )

    if include_within_run:
        evaluations.extend(
            _evaluate_current_run_rules(
                current_run, current_run_stream_name, preset_definition.current_run_rules
            )
        )
    evaluations.extend(
        _evaluate_history_rules(
            context,
            preset_definition.history_rules,
            enabled_scopes=effective_scopes,
        )
    )

    violations = tuple(
        violation
        for evaluation in evaluations
        for violation in [evaluation.to_violation()]
        if violation is not None
    )
    accepted = not violations
    reason = (
        "No configured rule violations were triggered."
        if accepted
        else f"Triggered {len(violations)} rule violation(s) for preset {preset.value}."
    )
    return tuple(evaluations), violations, warning_gate, accepted, reason


def _evaluate_current_run_rules(
    current_run: tuple[ControlObservation, ...],
    stream_name: str,
    rules: Iterable[RuleName],
) -> list[EvaluationResult]:
    evaluations: list[EvaluationResult] = []
    for rule in rules:
        evaluations.append(
            evaluate_rule(
                rule,
                current_run,
                scope=EvaluationScope.WITHIN_RUN,
                stream_name=stream_name,
            )
        )
    return evaluations


def _evaluate_history_rules(
    context: MultiruleContext,
    rules: Iterable[RuleName],
    *,
    enabled_scopes: frozenset[EvaluationScope],
) -> list[EvaluationResult]:
    evaluations: list[EvaluationResult] = []
    include_within_material = EvaluationScope.WITHIN_MATERIAL in enabled_scopes
    include_across_material = EvaluationScope.ACROSS_MATERIAL in enabled_scopes
    for rule in rules:
        if include_within_material:
            for material_name, stream in context.material_streams.items():
                evaluations.append(
                    evaluate_rule(
                        rule,
                        tuple(sorted(stream, key=lambda observation: observation.sequence)),
                        scope=EvaluationScope.WITHIN_MATERIAL,
                        stream_name=f"material:{material_name}",
                    )
                )
        if include_across_material and context.across_material_stream:
            evaluations.append(
                evaluate_rule(
                    rule,
                    tuple(
                        sorted(
                            context.across_material_stream,
                            key=lambda observation: observation.sequence,
                        )
                    ),
                    scope=EvaluationScope.ACROSS_MATERIAL,
                    stream_name="across_material",
                )
            )
    return evaluations


def _skipped_current_run_rules(
    current_run: tuple[ControlObservation, ...],
    stream_name: str,
    rules: Iterable[RuleName],
) -> list[EvaluationResult]:
    return [
        make_skipped_evaluation(
            rule,
            scope=EvaluationScope.WITHIN_RUN,
            stream_name=stream_name,
            available_observations=current_run,
            reason=f"{rule.value} skipped because the classic 1_2s warning gate did not trigger.",
        )
        for rule in rules
    ]


def _skipped_history_rules(
    context: MultiruleContext,
    rules: Iterable[RuleName],
    *,
    enabled_scopes: frozenset[EvaluationScope],
) -> list[EvaluationResult]:
    evaluations: list[EvaluationResult] = []
    include_within_material = EvaluationScope.WITHIN_MATERIAL in enabled_scopes
    include_across_material = EvaluationScope.ACROSS_MATERIAL in enabled_scopes
    for rule in rules:
        if include_within_material:
            for material_name, stream in context.material_streams.items():
                evaluations.append(
                    make_skipped_evaluation(
                        rule,
                        scope=EvaluationScope.WITHIN_MATERIAL,
                        stream_name=f"material:{material_name}",
                        available_observations=tuple(
                            sorted(stream, key=lambda observation: observation.sequence)
                        ),
                        reason=(
                            f"{rule.value} skipped because the classic 1_2s warning gate "
                            "did not trigger."
                        ),
                    )
                )
        if include_across_material and context.across_material_stream:
            evaluations.append(
                make_skipped_evaluation(
                    rule,
                    scope=EvaluationScope.ACROSS_MATERIAL,
                    stream_name="across_material",
                    available_observations=tuple(
                        sorted(
                            context.across_material_stream,
                            key=lambda observation: observation.sequence,
                        )
                    ),
                    reason=(
                        f"{rule.value} skipped because the classic 1_2s warning gate "
                        "did not trigger."
                    ),
                )
            )
    return evaluations
