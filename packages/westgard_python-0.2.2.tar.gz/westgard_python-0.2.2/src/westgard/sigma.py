"""Sigma metric calculation and rule mappings."""

from __future__ import annotations

from .models import RuleName, SigmaMetrics, SigmaRuleMapping


def calculate_sigma_metrics(
    *,
    total_allowable_error: float,
    bias: float,
    coefficient_of_variation: float,
    analyte: str | None = None,
    level: str | None = None,
) -> SigmaMetrics:
    """Calculate sigma as (TEa - |bias|) / CV."""
    if total_allowable_error <= 0:
        raise ValueError("total_allowable_error must be positive.")
    if coefficient_of_variation <= 0:
        raise ValueError("coefficient_of_variation must be positive.")
    sigma = (total_allowable_error - abs(bias)) / coefficient_of_variation
    return SigmaMetrics(
        total_allowable_error=total_allowable_error,
        bias=bias,
        coefficient_of_variation=coefficient_of_variation,
        sigma=sigma,
        analyte=analyte,
        level=level,
    )


def recommend_sigma_rules(*, sigma: float, control_levels: int) -> SigmaRuleMapping:
    """Return the reference-backed sigma mapping for 2-level or 3-level designs."""
    if control_levels not in {2, 3}:
        raise ValueError("control_levels must be 2 or 3.")
    if control_levels == 2:
        if sigma >= 6:
            return SigmaRuleMapping(
                ">= 6",
                2,
                (RuleName.ONE_3S,),
                2,
                1,
                "High-quality method; simple 1_3s design is generally adequate.",
            )
        if sigma >= 5:
            return SigmaRuleMapping(
                "5 to <6",
                2,
                (RuleName.ONE_3S, RuleName.TWO_2S, RuleName.R_4S),
                2,
                1,
                "Use a 2-control multirule with same-event random-error coverage.",
            )
        if sigma >= 4:
            return SigmaRuleMapping(
                "4 to <5",
                2,
                (RuleName.ONE_3S, RuleName.TWO_2S, RuleName.R_4S, RuleName.FOUR_1S),
                4,
                1,
                "Prefer N=4, R=1; an N=2, R=2 schedule is a documented alternative.",
            )
        return SigmaRuleMapping(
            "< 4",
            2,
            (RuleName.ONE_3S, RuleName.TWO_2S, RuleName.R_4S, RuleName.FOUR_1S, RuleName.EIGHT_X),
            4,
            2,
            "Lower-sigma methods require more aggressive QC event design or more frequent QC.",
        )

    if sigma >= 6:
        return SigmaRuleMapping(
            ">= 6", 3, (RuleName.ONE_3S,), 3, 1, "High-quality 3-level design can use 1_3s alone."
        )
    if sigma >= 5:
        return SigmaRuleMapping(
            "5 to <6",
            3,
            (RuleName.ONE_3S, RuleName.TWO_OF_THREE_2S, RuleName.R_4S),
            3,
            1,
            "Use the standard 3-level multirule family.",
        )
    if sigma >= 4:
        return SigmaRuleMapping(
            "4 to <5",
            3,
            (RuleName.ONE_3S, RuleName.TWO_OF_THREE_2S, RuleName.R_4S, RuleName.THREE_1S),
            3,
            1,
            "Add 3_1s for stronger systematic-error detection.",
        )
    return SigmaRuleMapping(
        "< 4",
        3,
        (
            RuleName.ONE_3S,
            RuleName.TWO_OF_THREE_2S,
            RuleName.R_4S,
            RuleName.THREE_1S,
            RuleName.SIX_X,
        ),
        6,
        1,
        "Consider N=6, R=1 or N=3, R=2; 9_x is a documented alternative for N=3, R=3.",
    )
