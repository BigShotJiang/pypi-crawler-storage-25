"""Optional adapters."""

from .pandas import dataframe_to_context, dataframe_to_series

__all__ = ["dataframe_to_context", "dataframe_to_series"]
