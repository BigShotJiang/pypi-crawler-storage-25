"""Optional pandas adapters for Westgard typed models."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from ..builders import series_from_rows
from ..models import ControlObservation, MultiruleContext, QCSeries, RunIdentifier

try:
    import pandas as pd
except ImportError:  # pragma: no cover - exercised through import guard tests
    pd = None


CONTEXT_REQUIRED_COLUMNS = {"analyte", "material", "run_id", "sequence", "z_score"}
SERIES_REQUIRED_COLUMNS = {"analyte", "material", "run_id", "sequence"}


def dataframe_to_context(
    frame: Any,
    *,
    current_run_id: str,
    across_material: bool = False,
) -> MultiruleContext:
    """Build a multirule context from a pandas DataFrame."""

    _require_pandas_dataframe(frame)
    missing = CONTEXT_REQUIRED_COLUMNS.difference(frame.columns)
    if missing:
        missing_csv = ", ".join(sorted(missing))
        raise ValueError(f"frame is missing required columns: {missing_csv}.")

    material_streams: dict[str, list[ControlObservation]] = defaultdict(list)
    current_run: list[ControlObservation] = []
    across_stream: list[ControlObservation] = []
    for row in frame.sort_values("sequence").itertuples(index=False):
        observation = ControlObservation(
            analyte=str(row.analyte),
            material=str(row.material),
            run_id=RunIdentifier(str(row.run_id)),
            sequence=int(row.sequence),
            z_score=float(row.z_score),
            value=float(row.value) if hasattr(row, "value") and row.value is not None else None,
            mean=float(row.mean) if hasattr(row, "mean") and row.mean is not None else None,
            standard_deviation=(
                float(row.standard_deviation)
                if hasattr(row, "standard_deviation") and row.standard_deviation is not None
                else None
            ),
        )
        material_streams[observation.material].append(observation)
        if str(row.run_id) == current_run_id:
            current_run.append(observation)
        if across_material:
            across_stream.append(observation)

    if not current_run:
        raise ValueError(f"No observations were found for current_run_id={current_run_id!r}.")

    return MultiruleContext(
        current_run=tuple(current_run),
        material_streams={key: tuple(value) for key, value in material_streams.items()},
        across_material_stream=tuple(across_stream),
    )


def dataframe_to_series(frame: Any) -> dict[str, QCSeries]:
    """Build analyte-grouped QC series from a pandas DataFrame."""

    _require_pandas_dataframe(frame)
    missing = SERIES_REQUIRED_COLUMNS.difference(frame.columns)
    if missing:
        missing_csv = ", ".join(sorted(missing))
        raise ValueError(f"frame is missing required columns: {missing_csv}.")
    return series_from_rows(frame.to_dict(orient="records"))


def _require_pandas_dataframe(frame: Any) -> None:
    if pd is None:
        raise ImportError(
            "pandas is required for this adapter. Install westgard-python[pandas]."
        )
    if not isinstance(frame, pd.DataFrame):
        raise TypeError("frame must be a pandas.DataFrame.")
