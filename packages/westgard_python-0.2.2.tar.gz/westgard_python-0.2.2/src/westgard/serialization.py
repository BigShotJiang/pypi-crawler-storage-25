"""Stable JSON-friendly serializers for Westgard result models."""

from __future__ import annotations

from .models import (
    ControlObservation,
    EvaluationResult,
    EventMultiruleResult,
    HistoricalEmitMode,
    HistoricalRuleViolation,
    HistoricalViolationWindow,
    MultiruleResult,
    RuleName,
    RuleNameOutputMode,
    RuleViolation,
    SeriesMultiruleResult,
)

_CLINICAL_RULE_LABELS: dict[RuleName, str] = {
    RuleName.EIGHT_X: "8x",
    RuleName.TEN_X: "10x",
    RuleName.TWELVE_X: "12x",
    RuleName.SIX_X: "6x",
    RuleName.NINE_X: "9x",
    RuleName.SEVEN_T: "7T",
}


def format_rule_name(
    rule: RuleName,
    mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> str:
    """Return a formatted rule label for display-oriented consumers."""

    if mode == RuleNameOutputMode.CANONICAL:
        return rule.value
    if mode == RuleNameOutputMode.COMPACT:
        return rule.value.replace("_", "")
    if mode == RuleNameOutputMode.CLINICAL:
        return _CLINICAL_RULE_LABELS.get(rule, rule.value)
    raise ValueError(f"Unsupported RuleNameOutputMode value: {mode!r}.")


def serialize_multirule_result(
    result: MultiruleResult,
    *,
    rule_name_mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> dict[str, object]:
    """Serialize a current-run multirule result."""

    return {
        "preset": result.preset.value,
        "interpretation_mode": result.interpretation_mode.value,
        "accepted": result.accepted,
        "reason": result.reason,
        "warning_gate": serialize_evaluation_result(
            result.warning_gate,
            rule_name_mode=rule_name_mode,
        )
        if result.warning_gate is not None
        else None,
        "evaluations": [
            serialize_evaluation_result(evaluation, rule_name_mode=rule_name_mode)
            for evaluation in result.evaluations
        ],
        "violations": [
            serialize_rule_violation(violation, rule_name_mode=rule_name_mode)
            for violation in result.violations
        ],
    }


def serialize_event_multirule_result(
    result: EventMultiruleResult,
    *,
    rule_name_mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> dict[str, object]:
    """Serialize one historical event result."""

    return {
        "preset": result.preset.value,
        "interpretation_mode": result.interpretation_mode.value,
        "event_index": result.event_index,
        "event_run_id": result.event.run_id.value,
        "accepted": result.accepted,
        "reason": result.reason,
        "warning_gate": serialize_evaluation_result(
            result.warning_gate,
            rule_name_mode=rule_name_mode,
        )
        if result.warning_gate is not None
        else None,
        "evaluations": [
            serialize_evaluation_result(evaluation, rule_name_mode=rule_name_mode)
            for evaluation in result.evaluations
        ],
        "violations": [
            serialize_rule_violation(violation, rule_name_mode=rule_name_mode)
            for violation in result.violations
        ],
    }


def serialize_series_multirule_result(
    result: SeriesMultiruleResult,
    *,
    rule_name_mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> dict[str, object]:
    """Serialize a full retrospective multirule result."""

    return {
        "preset": result.preset.value,
        "interpretation_mode": result.interpretation_mode.value,
        "analyte": result.series.analyte,
        "accepted": result.accepted,
        "reason": result.reason,
        "enabled_scopes": [scope.value for scope in result.enabled_scopes],
        "emit_mode": result.emit_mode.value,
        "event_results": [
            serialize_event_multirule_result(event_result, rule_name_mode=rule_name_mode)
            for event_result in result.event_results
        ],
        "all_violations": [
            serialize_historical_rule_violation(violation, rule_name_mode=rule_name_mode)
            for violation in result.all_violations
        ],
        "violations": [
            serialize_historical_rule_violation(violation, rule_name_mode=rule_name_mode)
            for violation in result.violations
        ],
        "violation_windows": [
            serialize_historical_violation_window(window, rule_name_mode=rule_name_mode)
            for window in result.violation_windows
        ],
        "first_violations_by_rule": {
            rule.value: serialize_historical_rule_violation(
                violation, rule_name_mode=rule_name_mode
            )
            for rule, violation in result.first_violations_by_rule.items()
        },
    }


def serialize_evaluation_result(
    result: EvaluationResult | None,
    *,
    rule_name_mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> dict[str, object] | None:
    """Serialize one rule evaluation result."""

    if result is None:
        return None
    rule_label = format_rule_name(result.rule, rule_name_mode)
    return {
        "rule": result.rule.value,
        "rule_label": rule_label,
        "taxonomy": result.taxonomy.value,
        "scope": result.scope.value,
        "stream_name": result.stream_name,
        "violated": result.violated,
        "enough_data": result.enough_data,
        "required_observations": result.required_observations,
        "status": result.status.value,
        "severity": result.severity.value,
        "reason": result.reason,
        "considered_observations": [
            serialize_control_observation(observation)
            for observation in result.considered_observations
        ],
        "triggering_observations": [
            serialize_control_observation(observation)
            for observation in result.triggering_observations
        ],
    }


def serialize_rule_violation(
    violation: RuleViolation,
    *,
    rule_name_mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> dict[str, object]:
    """Serialize one current-run or per-event violation payload."""

    rule_label = format_rule_name(violation.rule, rule_name_mode)
    return {
        "rule": violation.rule.value,
        "rule_label": rule_label,
        "scope": violation.scope.value,
        "stream_name": violation.stream_name,
        "message": violation.message,
        "severity": violation.severity.value,
        "observation_sequences": list(violation.observation_sequences),
        "observation_materials": list(violation.observation_materials),
        "start_sequence": violation.start_sequence,
        "end_sequence": violation.end_sequence,
        "triggering_observations": [
            serialize_control_observation(observation)
            for observation in violation.triggering_observations
        ],
    }


def serialize_historical_rule_violation(
    violation: HistoricalRuleViolation,
    *,
    rule_name_mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> dict[str, object]:
    """Serialize one retrospective violation location."""

    return {
        "preset": violation.preset.value,
        "interpretation_mode": violation.interpretation_mode.value,
        "event_index": violation.event_index,
        "event_run_id": violation.event_run_id.value,
        "window_id": violation.window_id,
        "violation": serialize_rule_violation(violation.violation, rule_name_mode=rule_name_mode),
    }


def serialize_control_observation(observation: ControlObservation) -> dict[str, object]:
    """Serialize one typed observation."""

    return {
        "analyte": observation.analyte,
        "material": observation.material,
        "run_id": observation.run_id.value,
        "sequence": observation.sequence,
        "z_score": observation.z_score,
        "value": observation.value,
        "mean": observation.mean,
        "standard_deviation": observation.standard_deviation,
        "metadata": dict(observation.metadata),
    }


def serialize_historical_violation_window(
    window: HistoricalViolationWindow,
    *,
    rule_name_mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> dict[str, object]:
    """Serialize one grouped historical violation window."""

    rule_label = format_rule_name(window.rule, rule_name_mode)
    return {
        "window_id": window.window_id,
        "rule": window.rule.value,
        "rule_label": rule_label,
        "scope": window.scope.value,
        "severity": window.severity.value,
        "start_sequence": window.start_sequence,
        "end_sequence": window.end_sequence,
        "start_event_index": window.start_event_index,
        "end_event_index": window.end_event_index,
        "event_indexes": list(window.event_indexes),
        "event_run_ids": [run_id.value for run_id in window.event_run_ids],
        "triggering_observations": [
            serialize_control_observation(observation)
            for observation in window.triggering_observations
        ],
    }


def serialize_series_multirule_report(
    result: SeriesMultiruleResult,
    *,
    rule_name_mode: RuleNameOutputMode = RuleNameOutputMode.CANONICAL,
) -> dict[str, object]:
    """Serialize retrospective results into flattened reporting records.

    The `summary` field is human-readable only and not a machine-parsing contract.
    """

    if result.emit_mode == HistoricalEmitMode.ALL_TRIGGERS_GROUPED_BY_WINDOW:
        records = _serialize_grouped_reporting_records(result, rule_name_mode)
    else:
        records = _serialize_violation_reporting_records(result, rule_name_mode)

    return {
        "preset": result.preset.value,
        "interpretation_mode": result.interpretation_mode.value,
        "analyte": result.series.analyte,
        "accepted": result.accepted,
        "reason": result.reason,
        "enabled_scopes": [scope.value for scope in result.enabled_scopes],
        "emit_mode": result.emit_mode.value,
        "records": records,
    }


def _serialize_violation_reporting_records(
    result: SeriesMultiruleResult,
    mode: RuleNameOutputMode,
) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for historical_violation in sorted(result.violations, key=_historical_violation_sort_key):
        violation = historical_violation.violation
        rule_label = format_rule_name(violation.rule, mode)
        record: dict[str, object] = {
            "rule": violation.rule.value,
            "rule_label": rule_label,
            "scope": violation.scope.value,
            "severity": violation.severity.value,
            "start_sequence": violation.start_sequence,
            "end_sequence": violation.end_sequence,
            "triggering_observations": [
                serialize_control_observation(observation)
                for observation in violation.triggering_observations
            ],
            "event_index": historical_violation.event_index,
            "event_run_id": historical_violation.event_run_id.value,
            "window_id": historical_violation.window_id,
            "summary": _render_summary_from_canonical(
                rule=violation.rule,
                rule_label=rule_label,
                scope=violation.scope.value,
                severity=violation.severity.value,
                start_sequence=violation.start_sequence,
                end_sequence=violation.end_sequence,
                event_text=(
                    f"event {historical_violation.event_index} "
                    f"({historical_violation.event_run_id.value})"
                ),
            ),
        }
        records.append(record)
    return records


def _serialize_grouped_reporting_records(
    result: SeriesMultiruleResult,
    mode: RuleNameOutputMode,
) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for window in sorted(result.violation_windows, key=_historical_window_sort_key):
        rule_label = format_rule_name(window.rule, mode)
        start_event_run_id = window.event_run_ids[0].value if window.event_run_ids else None
        end_event_run_id = window.event_run_ids[-1].value if window.event_run_ids else None
        record: dict[str, object] = {
            "rule": window.rule.value,
            "rule_label": rule_label,
            "scope": window.scope.value,
            "severity": window.severity.value,
            "start_sequence": window.start_sequence,
            "end_sequence": window.end_sequence,
            "triggering_observations": [
                serialize_control_observation(observation)
                for observation in window.triggering_observations
            ],
            "window_id": window.window_id,
            "start_event_index": window.start_event_index,
            "start_event_run_id": start_event_run_id,
            "end_event_index": window.end_event_index,
            "end_event_run_id": end_event_run_id,
            "summary": _render_summary_from_canonical(
                rule=window.rule,
                rule_label=rule_label,
                scope=window.scope.value,
                severity=window.severity.value,
                start_sequence=window.start_sequence,
                end_sequence=window.end_sequence,
                event_text=(
                    f"events {window.start_event_index} ({start_event_run_id}) "
                    f"to {window.end_event_index} ({end_event_run_id})"
                ),
            ),
        }
        records.append(record)
    return records


def _historical_violation_sort_key(
    violation: HistoricalRuleViolation,
) -> tuple[int, int, int, str, str, str]:
    payload = violation.violation
    return (
        violation.event_index,
        _sortable_sequence(payload.start_sequence),
        _sortable_sequence(payload.end_sequence),
        payload.rule.value,
        payload.scope.value,
        violation.event_run_id.value,
    )


def _historical_window_sort_key(
    window: HistoricalViolationWindow,
) -> tuple[int, int, int, str, str, str]:
    return (
        window.start_event_index,
        _sortable_sequence(window.start_sequence),
        _sortable_sequence(window.end_sequence),
        window.rule.value,
        window.scope.value,
        window.window_id,
    )


def _sortable_sequence(sequence: int | None) -> int:
    return sequence if sequence is not None else 10**12


def _render_summary_from_canonical(
    *,
    rule: RuleName,
    rule_label: str,
    scope: str,
    severity: str,
    start_sequence: int | None,
    end_sequence: int | None,
    event_text: str,
) -> str:
    sequence_text = _sequence_text(start_sequence, end_sequence)
    canonical = (
        f"Rule {rule.value} ({scope}, {severity}) triggered for sequences "
        f"{sequence_text} in {event_text}."
    )
    return canonical.replace(rule.value, rule_label, 1)


def _sequence_text(start_sequence: int | None, end_sequence: int | None) -> str:
    if start_sequence is None and end_sequence is None:
        return "unknown"
    if start_sequence is None:
        return f"unknown to {end_sequence}"
    if end_sequence is None:
        return f"{start_sequence} to unknown"
    if start_sequence == end_sequence:
        return str(start_sequence)
    return f"{start_sequence} to {end_sequence}"
