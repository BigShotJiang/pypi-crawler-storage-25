"""Named multirule preset metadata."""

from __future__ import annotations

from dataclasses import dataclass

from .models import MultiruleVariant, RuleName


@dataclass(frozen=True)
class PresetDefinition:
    """Named rule bundle with descriptive metadata."""

    name: MultiruleVariant
    control_levels: int
    current_run_rules: tuple[RuleName, ...]
    history_rules: tuple[RuleName, ...]
    classic_warning_gate: bool
    note: str


PRESET_DEFINITIONS: dict[MultiruleVariant, PresetDefinition] = {
    MultiruleVariant.CLASSIC_2_CONTROL: PresetDefinition(
        name=MultiruleVariant.CLASSIC_2_CONTROL,
        control_levels=2,
        current_run_rules=(RuleName.ONE_3S, RuleName.R_4S),
        history_rules=(RuleName.TWO_2S, RuleName.FOUR_1S, RuleName.TEN_X),
        classic_warning_gate=True,
        note="Historical classic 2-control set with 1_2s warning gate and 10_x mean rule.",
    ),
    MultiruleVariant.MODERN_2_CONTROL: PresetDefinition(
        name=MultiruleVariant.MODERN_2_CONTROL,
        control_levels=2,
        current_run_rules=(RuleName.ONE_3S, RuleName.R_4S),
        history_rules=(RuleName.TWO_2S, RuleName.FOUR_1S, RuleName.EIGHT_X),
        classic_warning_gate=False,
        note="Modern computerized 2-control set centered on 8_x.",
    ),
    MultiruleVariant.MODERN_2_CONTROL_LEGACY_10X: PresetDefinition(
        name=MultiruleVariant.MODERN_2_CONTROL_LEGACY_10X,
        control_levels=2,
        current_run_rules=(RuleName.ONE_3S, RuleName.R_4S),
        history_rules=(RuleName.TWO_2S, RuleName.FOUR_1S, RuleName.TEN_X),
        classic_warning_gate=False,
        note="Modern no-warning variant that preserves historical 10_x behavior.",
    ),
    MultiruleVariant.CLASSIC_3_CONTROL: PresetDefinition(
        name=MultiruleVariant.CLASSIC_3_CONTROL,
        control_levels=3,
        current_run_rules=(RuleName.ONE_3S, RuleName.R_4S),
        history_rules=(RuleName.TWO_OF_THREE_2S, RuleName.THREE_1S, RuleName.SIX_X),
        classic_warning_gate=True,
        note="Historical 3-control variant with 1_2s warning gate.",
    ),
    MultiruleVariant.MODERN_3_CONTROL: PresetDefinition(
        name=MultiruleVariant.MODERN_3_CONTROL,
        control_levels=3,
        current_run_rules=(RuleName.ONE_3S, RuleName.R_4S),
        history_rules=(RuleName.TWO_OF_THREE_2S, RuleName.THREE_1S, RuleName.SIX_X),
        classic_warning_gate=False,
        note="Modern computerized 3-control variant centered on 6_x.",
    ),
}


def get_preset_definition(preset: MultiruleVariant) -> PresetDefinition:
    """Return metadata for a named preset."""
    return PRESET_DEFINITIONS[preset]
