
from setuptools import setup, find_packages

setup(
    name="dllpro",
    version="1.0.2",
    packages=find_packages(),
    install_requires=["nuitka"],
    entry_points={
        'console_scripts': [
            'dllpro=dllpro.main:cli',
        ],
    },
    author="Hamza",
    description="Python to DLL converter with Nuitka backend",
    long_description="A tool to convert Python scripts to DLLs using Nuitka.",
    long_description_content_type="text/plain",
    python_requires='>=3.6',
)
