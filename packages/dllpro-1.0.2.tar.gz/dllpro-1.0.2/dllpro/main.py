
import subprocess
import sys
import argparse
import os

def decode(main, output="output.dll", standalone=True, pips=None):
    print(f"[dllpro] {main} dosyasi {output} olarak derleniyor...")
    
    # Nuitka komutunu olusturma - DOGRU SIRALAMA
    cmd = [
        sys.executable, "-m", "nuitka",
        "--module",
        f"--output-filename={output}",
        "--assume-yes-for-downloads", # Indirme sorarsa evet de
    ]
    
    if standalone:
        cmd.append("--standalone")
    
    if pips:
        # Pips string olarak gelirse (CLI), listeye cevir
        if isinstance(pips, str):
            pips = [p.strip() for p in pips.split(",")]
            
        for lib in pips:
            cmd.extend(["--include-package", str(lib)])
            
    # Asil derlenecek dosya her zaman en sonda olmali!
    cmd.append(main)
    
    try:
        subprocess.run(cmd, check=True)
        print(f"\n[BASARILI] {output} olusturuldu.")
    except Exception as e:
        print(f"Hata olustu: {e}")

def cli():
    parser = argparse.ArgumentParser(description="dllpro: Python dosyalarini DLL'e donustur.")
    parser.add_argument("main", help="Giris python dosyasi")
    parser.add_argument("-o", "--output", default="output.dll", help="Cikis DLL adi")
    parser.add_argument("--standalone", action="store_true", help="Bagimsizlik modunu acar")
    parser.add_argument("--pips", help="Dahil edilecek paketler (virgulle ayir)")
    
    args = parser.parse_args()
    decode(args.main, args.output, args.standalone, args.pips)
