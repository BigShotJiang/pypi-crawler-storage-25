from __future__ import annotations

from pathlib import Path

from proofctl.checkers.terragrunt import TerragruntChecker
from proofctl.models import Severity

_P = Path("terragrunt.hcl")
_checker = TerragruntChecker()


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ══════════════════════════════════════════════════════════════════════════════
# TG-001 — var.* / path.module outside heredocs
# ══════════════════════════════════════════════════════════════════════════════


def test_tg001_var_ref_flagged():
    src = 'locals {\n  region = var.region\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TG-001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_tg001_path_module_flagged():
    src = 'locals {\n  base = path.module\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TG-001")
    assert len(f) == 1


def test_tg001_inside_heredoc_not_flagged():
    """var.* inside a heredoc (generate contents) is valid Terraform template code."""
    src = """
generate "provider" {
  path      = "provider.tf"
  if_exists = "overwrite"
  contents = <<EOF
provider "aws" {
  region = var.region
}
EOF
}
"""
    assert "PROOFCTL-TG-001" not in _ids(_checker.check(_P, src))


def test_tg001_comment_not_flagged():
    src = '# var.region is set by terragrunt\nlocals {\n  x = 1\n}\n'
    assert "PROOFCTL-TG-001" not in _ids(_checker.check(_P, src))


def test_tg001_local_ref_clean():
    src = 'locals {\n  region = local.aws_region\n}\n'
    assert "PROOFCTL-TG-001" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TG-002 — dependency without mock_outputs
# ══════════════════════════════════════════════════════════════════════════════


def test_tg002_missing_mock_outputs():
    src = """
dependency "vpc" {
  config_path = "../vpc"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TG-002")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_tg002_with_mock_outputs_clean():
    src = """
dependency "vpc" {
  config_path = "../vpc"
  mock_outputs = {
    vpc_id = "vpc-fake"
  }
}
"""
    assert "PROOFCTL-TG-002" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TG-003 — invalid if_exists
# ══════════════════════════════════════════════════════════════════════════════


def test_tg003_invalid_if_exists():
    src = """
generate "backend" {
  path      = "backend.tf"
  if_exists = "replace"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TG-003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "replace" in f[0].message


def test_tg003_valid_if_exists_clean():
    for valid in ("overwrite", "overwrite_terragrunt", "skip", "error"):
        src = f'generate "backend" {{\n  path = "b.tf"\n  if_exists = "{valid}"\n}}\n'
        assert "PROOFCTL-TG-003" not in _ids(_checker.check(_P, src)), f"false positive for if_exists={valid}"


# ══════════════════════════════════════════════════════════════════════════════
# TG-004 — remote_state without encrypt
# ══════════════════════════════════════════════════════════════════════════════


def test_tg004_gcs_no_encrypt():
    src = """
remote_state {
  backend = "gcs"
  config = {
    bucket = "my-tfstate"
    prefix = "dev"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TG-004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_tg004_s3_no_encrypt():
    src = """
remote_state {
  backend = "s3"
  config = {
    bucket = "my-tfstate"
    key    = "dev/terraform.tfstate"
    region = "us-east-1"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TG-004")
    assert len(f) == 1


def test_tg004_gcs_with_encrypt_clean():
    src = """
remote_state {
  backend = "gcs"
  config = {
    bucket  = "my-tfstate"
    encrypt = true
  }
}
"""
    assert "PROOFCTL-TG-004" not in _ids(_checker.check(_P, src))


def test_tg004_local_backend_not_flagged():
    src = """
remote_state {
  backend = "local"
  config = {
    path = "terraform.tfstate"
  }
}
"""
    assert "PROOFCTL-TG-004" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TG-005 — conflicting remote_state + generate "backend"
# ══════════════════════════════════════════════════════════════════════════════


def test_tg005_conflict():
    src = """
remote_state {
  backend = "gcs"
  config  = { bucket = "x", encrypt = true }
}

generate "backend" {
  path      = "backend.tf"
  if_exists = "overwrite"
  contents  = ""
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TG-005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_tg005_only_remote_state_clean():
    src = """
remote_state {
  backend = "gcs"
  config  = { bucket = "x", encrypt = true }
}
"""
    assert "PROOFCTL-TG-005" not in _ids(_checker.check(_P, src))


def test_tg005_only_generate_clean():
    src = """
generate "backend" {
  path      = "backend.tf"
  if_exists = "overwrite"
  contents  = ""
}
"""
    assert "PROOFCTL-TG-005" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TG-006 — mock_outputs without allowed commands
# ══════════════════════════════════════════════════════════════════════════════


def test_tg006_mock_outputs_no_commands():
    src = """
dependency "vpc" {
  config_path = "../vpc"
  mock_outputs = {
    vpc_id = "vpc-fake"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TG-006")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_tg006_with_allowed_commands_clean():
    src = """
dependency "vpc" {
  config_path = "../vpc"
  mock_outputs = {
    vpc_id = "vpc-fake"
  }
  mock_outputs_allowed_terraform_commands = ["validate", "plan"]
}
"""
    assert "PROOFCTL-TG-006" not in _ids(_checker.check(_P, src))


def test_tg006_no_mock_outputs_no_flag():
    """TG-006 only fires when mock_outputs IS present but commands are absent."""
    src = """
dependency "vpc" {
  config_path = "../vpc"
}
"""
    assert "PROOFCTL-TG-006" not in _ids(_checker.check(_P, src))
