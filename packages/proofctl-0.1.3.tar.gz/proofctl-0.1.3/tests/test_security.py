from __future__ import annotations

import ast
from pathlib import Path

import pytest

from proofctl.checkers.security import SecurityChecker
from proofctl.models import Severity

_P = Path("module.py")
_checker = SecurityChecker()


def _parse(src: str) -> ast.Module:
    return ast.parse(src)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


def _check(src: str):
    tree = _parse(src)
    return _checker.check(_P, src, tree)


# ══════════════════════════════════════════════════════════════════════════════
# S-001 — SQL injection via string formatting
# ══════════════════════════════════════════════════════════════════════════════


def test_s001_fstring_in_execute():
    src = """
cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")
"""
    f = _find(_check(src), "PROOFCTL-S-001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s001_format_in_execute():
    src = """
cursor.execute("SELECT * FROM users WHERE name = '{}'".format(name))
"""
    f = _find(_check(src), "PROOFCTL-S-001")
    assert len(f) == 1


def test_s001_percent_in_execute():
    src = """
cursor.execute("DELETE FROM sessions WHERE token = '%s'" % token)
"""
    f = _find(_check(src), "PROOFCTL-S-001")
    assert len(f) == 1


def test_s001_concat_in_execute():
    src = """
cursor.execute("UPDATE users SET name = '" + name + "' WHERE id = 1")
"""
    f = _find(_check(src), "PROOFCTL-S-001")
    assert len(f) == 1


def test_s001_parameterised_clean():
    src = """
cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
"""
    assert "PROOFCTL-S-001" not in _ids(_check(src))


def test_s001_literal_query_clean():
    src = """
cursor.execute("SELECT 1")
"""
    assert "PROOFCTL-S-001" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-002 — Command injection
# ══════════════════════════════════════════════════════════════════════════════


def test_s002_subprocess_run_shell_fstring():
    src = """
import subprocess
subprocess.run(f"ls {user_dir}", shell=True)
"""
    f = _find(_check(src), "PROOFCTL-S-002")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s002_subprocess_call_variable():
    src = """
import subprocess
subprocess.call(cmd, shell=True)
"""
    f = _find(_check(src), "PROOFCTL-S-002")
    assert len(f) == 1


def test_s002_os_system_variable():
    src = """
import os
os.system(user_command)
"""
    f = _find(_check(src), "PROOFCTL-S-002")
    assert len(f) == 1


def test_s002_list_form_no_shell_clean():
    src = """
import subprocess
subprocess.run(["ls", user_dir])
"""
    assert "PROOFCTL-S-002" not in _ids(_check(src))


def test_s002_shell_true_literal_clean():
    src = """
import subprocess
subprocess.run("ls -la /tmp", shell=True)
"""
    assert "PROOFCTL-S-002" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-003 — Unsafe deserialization
# ══════════════════════════════════════════════════════════════════════════════


def test_s003_pickle_loads():
    src = """
import pickle
obj = pickle.loads(data)
"""
    f = _find(_check(src), "PROOFCTL-S-003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s003_pickle_load():
    src = """
import pickle
with open("data.pkl", "rb") as fh:
    obj = pickle.load(fh)
"""
    f = _find(_check(src), "PROOFCTL-S-003")
    assert len(f) == 1


def test_s003_yaml_load_no_loader():
    src = """
import yaml
config = yaml.load(data)
"""
    f = _find(_check(src), "PROOFCTL-S-003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s003_yaml_load_with_safe_loader_clean():
    src = """
import yaml
config = yaml.load(data, Loader=yaml.SafeLoader)
"""
    assert "PROOFCTL-S-003" not in _ids(_check(src))


def test_s003_yaml_safe_load_clean():
    src = """
import yaml
config = yaml.safe_load(data)
"""
    assert "PROOFCTL-S-003" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-004 — Weak cryptographic primitive
# ══════════════════════════════════════════════════════════════════════════════


def test_s004_hashlib_md5():
    src = """
import hashlib
digest = hashlib.md5(data).hexdigest()
"""
    f = _find(_check(src), "PROOFCTL-S-004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s004_hashlib_sha1():
    src = """
import hashlib
h = hashlib.sha1(data)
"""
    f = _find(_check(src), "PROOFCTL-S-004")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s004_random_for_token():
    src = """
import random, string
token = ''.join(random.choice(string.ascii_letters) for _ in range(32))
"""
    f = _find(_check(src), "PROOFCTL-S-004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "token" in f[0].message


def test_s004_random_for_password():
    src = """
import random
password = random.randint(100000, 999999)
"""
    f = _find(_check(src), "PROOFCTL-S-004")
    assert len(f) == 1


def test_s004_hashlib_sha256_clean():
    src = """
import hashlib
digest = hashlib.sha256(data).hexdigest()
"""
    assert "PROOFCTL-S-004" not in _ids(_check(src))


def test_s004_secrets_module_clean():
    src = """
import secrets
token = secrets.token_urlsafe(32)
"""
    assert "PROOFCTL-S-004" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-005 — eval / exec on non-literal
# ══════════════════════════════════════════════════════════════════════════════


def test_s005_eval_variable():
    src = """
result = eval(user_input)
"""
    f = _find(_check(src), "PROOFCTL-S-005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s005_exec_fstring():
    src = """
exec(f"x = {value}")
"""
    f = _find(_check(src), "PROOFCTL-S-005")
    assert len(f) == 1


def test_s005_eval_literal_flagged():
    # eval() on a literal string is still dangerous (executes arbitrary code)
    src = """
result = eval("1 + 2")
"""
    f = _find(_check(src), "PROOFCTL-S-005")
    assert len(f) == 1


# ══════════════════════════════════════════════════════════════════════════════
# S-006 — Missing HTTP timeout
# ══════════════════════════════════════════════════════════════════════════════


def test_s006_requests_get_no_timeout():
    src = """
import requests
resp = requests.get(url)
"""
    f = _find(_check(src), "PROOFCTL-S-006")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s006_requests_post_no_timeout():
    src = """
import requests
resp = requests.post(url, json=payload)
"""
    f = _find(_check(src), "PROOFCTL-S-006")
    assert len(f) == 1


def test_s006_requests_with_timeout_clean():
    src = """
import requests
resp = requests.get(url, timeout=30)
"""
    assert "PROOFCTL-S-006" not in _ids(_check(src))


def test_s006_httpx_no_timeout():
    src = """
import httpx
resp = httpx.post(url, json=data)
"""
    f = _find(_check(src), "PROOFCTL-S-006")
    assert len(f) == 1


def test_s006_httpx_with_timeout_clean():
    src = """
import httpx
resp = httpx.get(url, timeout=10.0)
"""
    assert "PROOFCTL-S-006" not in _ids(_check(src))
