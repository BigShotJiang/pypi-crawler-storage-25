"""Tests for extended Terraform rules:
  - TF-AZ-001..012  Azure rules
  - TF-G026..031    GCP extended rules
  - TF-A011..014    AWS extended rules
  - TF-T014..015    General Terraform extended rules
"""
from __future__ import annotations

from pathlib import Path

import pytest

from proofctl.checkers.terraform import TerraformChecker
from proofctl.models import Severity

_P = Path("test.tf")
_checker = TerraformChecker()


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-001 — Storage account public blob access
# ══════════════════════════════════════════════════════════════════════════════


def test_az001_public_blob_access_true():
    src = """
resource "azurerm_storage_account" "bad" {
  name                     = "badsa"
  allow_blob_public_access = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "bad" in f[0].message


def test_az001_public_blob_access_false_clean():
    src = """
resource "azurerm_storage_account" "ok" {
  name                     = "goodsa"
  allow_blob_public_access = false
}
"""
    assert "PROOFCTL-TF-AZ001" not in _ids(_checker.check(_P, src))


def test_az001_absent_not_flagged():
    # Absent means provider default — per spec, only flag explicit true
    src = """
resource "azurerm_storage_account" "neutral" {
  name = "neutralsa"
}
"""
    assert "PROOFCTL-TF-AZ001" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-002 — Storage account missing network_rules default_action = Deny
# ══════════════════════════════════════════════════════════════════════════════


def test_az002_no_network_rules():
    src = """
resource "azurerm_storage_account" "bad" {
  name = "mysa"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ002")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_az002_network_rules_allow_not_deny():
    src = """
resource "azurerm_storage_account" "bad" {
  name = "mysa"
  network_rules {
    default_action = "Allow"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ002")
    assert len(f) == 1


def test_az002_network_rules_deny_clean():
    src = """
resource "azurerm_storage_account" "ok" {
  name = "mysa"
  network_rules {
    default_action = "Deny"
    ip_rules       = ["1.2.3.4"]
  }
}
"""
    assert "PROOFCTL-TF-AZ002" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-003 — SQL Server public network access
# ══════════════════════════════════════════════════════════════════════════════


def test_az003_mssql_public_access_true():
    src = """
resource "azurerm_mssql_server" "bad" {
  name                          = "mysql"
  public_network_access_enabled = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az003_sql_server_public_access_true():
    src = """
resource "azurerm_sql_server" "bad" {
  name                          = "mysql"
  public_network_access_enabled = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ003")
    assert len(f) == 1


def test_az003_mssql_public_access_false_clean():
    src = """
resource "azurerm_mssql_server" "ok" {
  name                          = "mysql"
  public_network_access_enabled = false
}
"""
    assert "PROOFCTL-TF-AZ003" not in _ids(_checker.check(_P, src))


def test_az003_absent_not_flagged():
    # Absent — don't over-flag
    src = """
resource "azurerm_mssql_server" "neutral" {
  name = "mysql"
}
"""
    assert "PROOFCTL-TF-AZ003" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-004 — PostgreSQL/MySQL SSL enforcement disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_az004_postgresql_ssl_disabled():
    src = """
resource "azurerm_postgresql_server" "bad" {
  name                   = "pg"
  ssl_enforcement_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "azurerm_postgresql_server" in f[0].message


def test_az004_mysql_ssl_disabled():
    src = """
resource "azurerm_mysql_server" "bad" {
  name                   = "mysql"
  ssl_enforcement_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ004")
    assert len(f) == 1


def test_az004_postgresql_ssl_enabled_clean():
    src = """
resource "azurerm_postgresql_server" "ok" {
  name                   = "pg"
  ssl_enforcement_enabled = true
}
"""
    assert "PROOFCTL-TF-AZ004" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-005 — AKS API server IP restrictions absent
# ══════════════════════════════════════════════════════════════════════════════


def test_az005_aks_no_ip_ranges():
    src = """
resource "azurerm_kubernetes_cluster" "bad" {
  name = "mycluster"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az005_aks_null_ip_ranges():
    src = """
resource "azurerm_kubernetes_cluster" "bad" {
  name                            = "mycluster"
  api_server_authorized_ip_ranges = null
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ005")
    assert len(f) == 1


def test_az005_aks_empty_list():
    src = """
resource "azurerm_kubernetes_cluster" "bad" {
  name                            = "mycluster"
  api_server_authorized_ip_ranges = []
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ005")
    assert len(f) == 1


def test_az005_aks_ip_ranges_set_clean():
    src = """
resource "azurerm_kubernetes_cluster" "ok" {
  name                            = "mycluster"
  api_server_authorized_ip_ranges = ["10.0.0.0/8"]
}
"""
    assert "PROOFCTL-TF-AZ005" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-006 — AKS RBAC disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_az006_rbac_disabled():
    src = """
resource "azurerm_kubernetes_cluster" "bad" {
  name                            = "mycluster"
  role_based_access_control_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ006")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az006_rbac_enabled_clean():
    src = """
resource "azurerm_kubernetes_cluster" "ok" {
  name                            = "mycluster"
  role_based_access_control_enabled = true
  api_server_authorized_ip_ranges   = ["10.0.0.0/8"]
}
"""
    assert "PROOFCTL-TF-AZ006" not in _ids(_checker.check(_P, src))


def test_az006_rbac_absent_not_flagged():
    # Absent means provider default (true in newer versions) — don't over-flag
    src = """
resource "azurerm_kubernetes_cluster" "neutral" {
  name                            = "mycluster"
  api_server_authorized_ip_ranges = ["10.0.0.0/8"]
}
"""
    assert "PROOFCTL-TF-AZ006" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-007 — Key Vault purge protection disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_az007_purge_protection_absent():
    src = """
resource "azurerm_key_vault" "bad" {
  name     = "mykv"
  sku_name = "standard"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az007_purge_protection_false():
    src = """
resource "azurerm_key_vault" "bad" {
  name                    = "mykv"
  purge_protection_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ007")
    assert len(f) == 1


def test_az007_purge_protection_true_clean():
    src = """
resource "azurerm_key_vault" "ok" {
  name                          = "mykv"
  purge_protection_enabled      = true
  soft_delete_retention_days    = 30
}
"""
    assert "PROOFCTL-TF-AZ007" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-008 — Key Vault key missing expiration_date
# ══════════════════════════════════════════════════════════════════════════════


def test_az008_key_no_expiration():
    src = """
resource "azurerm_key_vault_key" "bad" {
  name         = "mykey"
  key_vault_id = azurerm_key_vault.kv.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts     = ["decrypt", "encrypt"]
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ008")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_az008_key_with_expiration_clean():
    src = """
resource "azurerm_key_vault_key" "ok" {
  name            = "mykey"
  key_vault_id    = azurerm_key_vault.kv.id
  key_type        = "RSA"
  key_size        = 2048
  key_opts        = ["decrypt", "encrypt"]
  expiration_date = "2026-12-31T00:00:00Z"
}
"""
    assert "PROOFCTL-TF-AZ008" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-009 — Monitor log profile retention < 90 days
# ══════════════════════════════════════════════════════════════════════════════


def test_az009_log_profile_retention_30_days():
    src = """
resource "azurerm_monitor_log_profile" "bad" {
  name = "myprofile"
  retention_policy {
    enabled = true
    days    = 30
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ009")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING
    assert "30" in f[0].message


def test_az009_log_profile_retention_0_days():
    src = """
resource "azurerm_monitor_log_profile" "bad" {
  name = "myprofile"
  retention_policy {
    enabled = true
    days    = 0
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ009")
    assert len(f) == 1


def test_az009_log_profile_retention_365_days_clean():
    src = """
resource "azurerm_monitor_log_profile" "ok" {
  name = "myprofile"
  retention_policy {
    enabled = true
    days    = 365
  }
}
"""
    assert "PROOFCTL-TF-AZ009" not in _ids(_checker.check(_P, src))


def test_az009_log_profile_retention_90_days_clean():
    src = """
resource "azurerm_monitor_log_profile" "ok" {
  name = "myprofile"
  retention_policy {
    enabled = true
    days    = 90
  }
}
"""
    assert "PROOFCTL-TF-AZ009" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-010 — Overly broad Azure role assignment / wildcard role definition
# ══════════════════════════════════════════════════════════════════════════════


def test_az010_owner_at_subscription_scope():
    src = """
resource "azurerm_role_assignment" "bad" {
  scope                = "/subscriptions/00000000-0000-0000-0000-000000000000"
  role_definition_name = "Owner"
  principal_id         = "some-principal-id"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ010")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_az010_contributor_at_subscription_scope():
    src = """
resource "azurerm_role_assignment" "bad" {
  scope                = "/subscriptions/00000000-0000-0000-0000-000000000000"
  role_definition_name = "Contributor"
  principal_id         = "some-principal-id"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ010")
    assert len(f) == 1


def test_az010_owner_at_resource_group_clean():
    src = """
resource "azurerm_role_assignment" "ok" {
  scope                = "/subscriptions/00000000/resourceGroups/my-rg"
  role_definition_name = "Owner"
  principal_id         = "some-principal-id"
}
"""
    assert "PROOFCTL-TF-AZ010" not in _ids(_checker.check(_P, src))


def test_az010_reader_at_subscription_clean():
    src = """
resource "azurerm_role_assignment" "ok" {
  scope                = "/subscriptions/00000000-0000-0000-0000-000000000000"
  role_definition_name = "Reader"
  principal_id         = "some-principal-id"
}
"""
    assert "PROOFCTL-TF-AZ010" not in _ids(_checker.check(_P, src))


def test_az010_role_definition_wildcard_actions():
    src = """
resource "azurerm_role_definition" "bad" {
  name  = "super-admin"
  scope = "/subscriptions/00000000"
  permissions {
    actions = ["*"]
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ010")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az010_role_definition_scoped_actions_clean():
    src = """
resource "azurerm_role_definition" "ok" {
  name  = "limited"
  scope = "/subscriptions/00000000"
  permissions {
    actions = ["Microsoft.Storage/storageAccounts/read"]
  }
}
"""
    assert "PROOFCTL-TF-AZ010" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-011 — App Service allows HTTP
# ══════════════════════════════════════════════════════════════════════════════


def test_az011_app_service_https_only_absent():
    src = """
resource "azurerm_app_service" "bad" {
  name                = "myapp"
  resource_group_name = "rg"
  app_service_plan_id = "plan-id"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ011")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az011_linux_web_app_https_false():
    src = """
resource "azurerm_linux_web_app" "bad" {
  name                = "myapp"
  https_only          = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ011")
    assert len(f) == 1


def test_az011_windows_web_app_https_false():
    src = """
resource "azurerm_windows_web_app" "bad" {
  name                = "myapp"
  https_only          = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ011")
    assert len(f) == 1


def test_az011_https_only_true_clean():
    src = """
resource "azurerm_linux_web_app" "ok" {
  name       = "myapp"
  https_only = true
}
"""
    assert "PROOFCTL-TF-AZ011" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-012 — VM missing encryption at host
# ══════════════════════════════════════════════════════════════════════════════


def test_az012_linux_vm_no_encryption_at_host():
    src = """
resource "azurerm_linux_virtual_machine" "bad" {
  name           = "myvm"
  admin_username = "admin"
  size           = "Standard_D2s_v3"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ012")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_az012_windows_vm_encryption_false():
    src = """
resource "azurerm_windows_virtual_machine" "bad" {
  name                      = "myvm"
  encryption_at_host_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ012")
    assert len(f) == 1


def test_az012_linux_vm_encryption_enabled_clean():
    src = """
resource "azurerm_linux_virtual_machine" "ok" {
  name                      = "myvm"
  admin_username            = "admin"
  encryption_at_host_enabled = true
}
"""
    assert "PROOFCTL-TF-AZ012" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G026 — IAM binding with allUsers / allAuthenticatedUsers
# ══════════════════════════════════════════════════════════════════════════════


def test_g026_all_users_member():
    src = """
resource "google_project_iam_member" "bad" {
  project = "my-project"
  role    = "roles/storage.objectViewer"
  member  = "allUsers"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G026")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g026_all_authenticated_users():
    src = """
resource "google_project_iam_binding" "bad" {
  project = "my-project"
  role    = "roles/viewer"
  members = ["allAuthenticatedUsers"]
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G026")
    assert len(f) == 1


def test_g026_specific_member_clean():
    src = """
resource "google_project_iam_member" "ok" {
  project = "my-project"
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:sa@project.iam.gserviceaccount.com"
}
"""
    assert "PROOFCTL-TF-G026" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G027 — Cloud Function with ALLOW_ALL ingress
# ══════════════════════════════════════════════════════════════════════════════


def test_g027_cloud_function_allow_all():
    src = """
resource "google_cloudfunctions_function" "bad" {
  name             = "my-func"
  ingress_settings = "ALLOW_ALL"
  runtime          = "python39"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G027")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g027_cloud_function_internal_only_clean():
    src = """
resource "google_cloudfunctions_function" "ok" {
  name             = "my-func"
  ingress_settings = "ALLOW_INTERNAL_ONLY"
  runtime          = "python39"
}
"""
    assert "PROOFCTL-TF-G027" not in _ids(_checker.check(_P, src))


def test_g027_cloud_function_no_ingress_setting_clean():
    # Absent = provider default (ALLOW_ALL is explicit, absence is not flagged)
    src = """
resource "google_cloudfunctions_function" "neutral" {
  name    = "my-func"
  runtime = "python39"
}
"""
    assert "PROOFCTL-TF-G027" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G028 — Cloud Run IAM with allUsers
# ══════════════════════════════════════════════════════════════════════════════


def test_g028_cloud_run_all_users_member():
    src = """
resource "google_cloud_run_service_iam_member" "bad" {
  service  = "my-service"
  location = "us-central1"
  role     = "roles/run.invoker"
  member   = "allUsers"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G028")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g028_cloud_run_all_users_binding():
    src = """
resource "google_cloud_run_service_iam_binding" "bad" {
  service  = "my-service"
  location = "us-central1"
  role     = "roles/run.invoker"
  members  = ["allUsers"]
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G028")
    assert len(f) == 1


def test_g028_cloud_run_specific_member_clean():
    src = """
resource "google_cloud_run_service_iam_member" "ok" {
  service  = "my-service"
  location = "us-central1"
  role     = "roles/run.invoker"
  member   = "serviceAccount:sa@project.iam.gserviceaccount.com"
}
"""
    assert "PROOFCTL-TF-G028" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G029 — Subnetwork missing VPC Flow Logs
# ══════════════════════════════════════════════════════════════════════════════


def test_g029_subnetwork_no_log_config():
    src = """
resource "google_compute_subnetwork" "bad" {
  name          = "my-subnet"
  ip_cidr_range = "10.0.0.0/24"
  region        = "us-central1"
  network       = "default"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G029")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g029_subnetwork_with_log_config_clean():
    src = """
resource "google_compute_subnetwork" "ok" {
  name          = "my-subnet"
  ip_cidr_range = "10.0.0.0/24"
  region        = "us-central1"
  network       = "default"
  log_config {
    aggregation_interval = "INTERVAL_5_SEC"
    flow_sampling        = 0.5
    metadata             = "INCLUDE_ALL_METADATA"
  }
}
"""
    assert "PROOFCTL-TF-G029" not in _ids(_checker.check(_P, src))


def test_g029_proxy_subnet_not_flagged():
    src = """
resource "google_compute_subnetwork" "proxy" {
  name          = "proxy-subnet"
  ip_cidr_range = "10.0.1.0/24"
  purpose       = "INTERNAL_HTTPS_LOAD_BALANCER"
  network       = "default"
}
"""
    assert "PROOFCTL-TF-G029" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G030 — BigQuery dataset with public access
# ══════════════════════════════════════════════════════════════════════════════


def test_g030_bigquery_all_authenticated_users():
    src = """
resource "google_bigquery_dataset" "bad" {
  dataset_id = "my_dataset"
  access {
    role          = "READER"
    special_group = "allAuthenticatedUsers"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G030")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g030_bigquery_all_users():
    src = """
resource "google_bigquery_dataset" "bad" {
  dataset_id = "my_dataset"
  access {
    role          = "READER"
    special_group = "allUsers"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G030")
    assert len(f) == 1


def test_g030_bigquery_specific_user_clean():
    src = """
resource "google_bigquery_dataset" "ok" {
  dataset_id = "my_dataset"
  access {
    role          = "READER"
    user_by_email = "analyst@example.com"
  }
}
"""
    assert "PROOFCTL-TF-G030" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G031 — Pub/Sub topic without CMEK
# ══════════════════════════════════════════════════════════════════════════════


def test_g031_pubsub_no_kms():
    src = """
resource "google_pubsub_topic" "bad" {
  name = "my-topic"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G031")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g031_pubsub_with_kms_clean():
    src = """
resource "google_pubsub_topic" "ok" {
  name         = "my-topic"
  kms_key_name = "projects/my-project/locations/us/keyRings/my-ring/cryptoKeys/my-key"
}
"""
    assert "PROOFCTL-TF-G031" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A011 — No aws_cloudtrail resource
# ══════════════════════════════════════════════════════════════════════════════


def test_a011_no_cloudtrail_with_aws_resources():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A011")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_a011_with_cloudtrail_clean():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}

resource "aws_cloudtrail" "main" {
  name                          = "main"
  s3_bucket_name                = "my-bucket"
  is_multi_region_trail         = true
  enable_log_file_validation    = true
}
"""
    assert "PROOFCTL-TF-A011" not in _ids(_checker.check(_P, src))


def test_a011_no_aws_resources_no_flag():
    # No aws_* resources at all — don't fire
    src = """
resource "google_compute_instance" "vm" {
  name = "my-vm"
}
"""
    assert "PROOFCTL-TF-A011" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A012 — aws_vpc without aws_flow_log
# ══════════════════════════════════════════════════════════════════════════════


def test_a012_vpc_no_flow_log():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A012")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_a012_vpc_with_flow_log_clean():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}

resource "aws_flow_log" "main" {
  iam_role_arn    = aws_iam_role.flow_log.arn
  log_destination = aws_cloudwatch_log_group.flow_log.arn
  traffic_type    = "ALL"
  vpc_id          = aws_vpc.main.id
}
"""
    assert "PROOFCTL-TF-A012" not in _ids(_checker.check(_P, src))


def test_a012_no_vpc_no_flag():
    src = """
resource "aws_s3_bucket" "data" {
  bucket = "my-data"
}
"""
    assert "PROOFCTL-TF-A012" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A013 — ECR repository mutable tags / scan_on_push disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_a013_ecr_mutable_tags():
    src = """
resource "aws_ecr_repository" "bad" {
  name                 = "my-repo"
  image_tag_mutability = "MUTABLE"
  image_scanning_configuration {
    scan_on_push = true
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A013")
    assert any("mutable" in fi.message.lower() for fi in f)


def test_a013_ecr_scan_disabled():
    src = """
resource "aws_ecr_repository" "bad" {
  name                 = "my-repo"
  image_tag_mutability = "IMMUTABLE"
  image_scanning_configuration {
    scan_on_push = false
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A013")
    assert any("scan_on_push" in fi.message for fi in f)


def test_a013_ecr_immutable_with_scan_clean():
    src = """
resource "aws_ecr_repository" "ok" {
  name                 = "my-repo"
  image_tag_mutability = "IMMUTABLE"
  image_scanning_configuration {
    scan_on_push = true
  }
}
"""
    # Should not flag mutability; may still flag scan_on_push due to scan_on_push = true being present
    mutable_findings = [
        fi for fi in _find(_checker.check(_P, src), "PROOFCTL-TF-A013")
        if "mutable" in fi.message.lower()
    ]
    assert len(mutable_findings) == 0


# ══════════════════════════════════════════════════════════════════════════════
# TF-A014 — Lambda hardcoded secret in env vars
# ══════════════════════════════════════════════════════════════════════════════


def test_a014_lambda_hardcoded_secret():
    src = """
resource "aws_lambda_function" "bad" {
  function_name = "my-func"
  handler       = "index.handler"
  runtime       = "python3.9"
  role          = aws_iam_role.lambda_role.arn
  environment {
    variables = {
      API_KEY = "hardcoded_secret_value_here"
    }
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A014")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a014_lambda_secret_manager_ref_clean():
    src = """
resource "aws_lambda_function" "ok" {
  function_name = "my-func"
  handler       = "index.handler"
  runtime       = "python3.9"
  role          = aws_iam_role.lambda_role.arn
  environment {
    variables = {
      API_KEY = data.aws_secretsmanager_secret_version.key.secret_string
    }
  }
}
"""
    assert "PROOFCTL-TF-A014" not in _ids(_checker.check(_P, src))


def test_a014_lambda_no_environment_clean():
    src = """
resource "aws_lambda_function" "ok" {
  function_name = "my-func"
  handler       = "index.handler"
  runtime       = "python3.9"
  role          = aws_iam_role.lambda_role.arn
}
"""
    assert "PROOFCTL-TF-A014" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-T014 — No terraform required_version constraint
# ══════════════════════════════════════════════════════════════════════════════


def test_t014_no_required_version_with_resources():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T014")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_t014_with_required_version_clean():
    src = """
terraform {
  required_version = ">= 1.5"
}

resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}
"""
    assert "PROOFCTL-TF-T014" not in _ids(_checker.check(_P, src))


def test_t014_no_resources_no_flag():
    # No resource or module blocks — don't fire
    src = """
variable "region" {
  description = "AWS region"
  type        = string
}
"""
    assert "PROOFCTL-TF-T014" not in _ids(_checker.check(_P, src))


def test_t014_with_module_fires():
    src = """
module "vpc" {
  source = "./vpc"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T014")
    assert len(f) == 1


# ══════════════════════════════════════════════════════════════════════════════
# TF-T015 — Sensitive output without sensitive = true
# ══════════════════════════════════════════════════════════════════════════════


def test_t015_password_output_not_sensitive():
    src = """
output "db_password" {
  value = aws_db_instance.main.password
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T015")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_t015_secret_output_not_sensitive():
    src = """
output "api_secret" {
  value = data.aws_secretsmanager_secret_version.app.secret_string
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T015")
    assert len(f) == 1


def test_t015_token_output_sensitive_true_clean():
    src = """
output "auth_token" {
  value     = aws_cognito_user_pool_client.app.client_secret
  sensitive = true
}
"""
    assert "PROOFCTL-TF-T015" not in _ids(_checker.check(_P, src))


def test_t015_non_sensitive_output_name_clean():
    src = """
output "vpc_id" {
  value = aws_vpc.main.id
}
"""
    assert "PROOFCTL-TF-T015" not in _ids(_checker.check(_P, src))


def test_t015_key_output_not_sensitive():
    src = """
output "encryption_key" {
  value = aws_kms_key.main.arn
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T015")
    assert len(f) == 1
