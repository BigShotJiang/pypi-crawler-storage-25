"""Tests for proofctl config loading."""
from __future__ import annotations

from pathlib import Path

import pytest

from proofctl.config import ProofctlConfig, load_config
from proofctl.models import Severity


# ── defaults ──────────────────────────────────────────────────────────────────

def test_load_config_no_file_returns_defaults(tmp_path):
    cfg = load_config(tmp_path)
    assert isinstance(cfg, ProofctlConfig)
    assert "**/.venv/**" in cfg.exclude_paths
    assert cfg.disable == []
    assert cfg.severity_overrides == {}
    assert cfg.any_threshold == 3


def test_load_config_empty_file_returns_defaults(tmp_path):
    (tmp_path / ".proofctl.yaml").write_text("")
    cfg = load_config(tmp_path)
    assert cfg.any_threshold == 3


# ── overrides ─────────────────────────────────────────────────────────────────

def test_load_config_disable_rule(tmp_path):
    (tmp_path / ".proofctl.yaml").write_text("disable:\n  - PROOFCTL-P-001\n")
    cfg = load_config(tmp_path)
    assert cfg.is_disabled("PROOFCTL-P-001")
    assert not cfg.is_disabled("PROOFCTL-P-002")


def test_load_config_severity_override(tmp_path):
    yaml = "severity_overrides:\n  PROOFCTL-P-001: ERROR\n"
    (tmp_path / ".proofctl.yaml").write_text(yaml)
    cfg = load_config(tmp_path)
    assert cfg.effective_severity("PROOFCTL-P-001", Severity.WARNING) == Severity.ERROR


def test_load_config_severity_override_invalid_raises(tmp_path):
    yaml = "severity_overrides:\n  PROOFCTL-P-001: BOGUS\n"
    (tmp_path / ".proofctl.yaml").write_text(yaml)
    cfg = load_config(tmp_path)
    with pytest.raises(ValueError, match="Invalid severity"):
        cfg.effective_severity("PROOFCTL-P-001", Severity.WARNING)


def test_load_config_exclude_paths_override(tmp_path):
    (tmp_path / ".proofctl.yaml").write_text("exclude_paths:\n  - '**/generated/**'\n")
    cfg = load_config(tmp_path)
    assert "**/generated/**" in cfg.exclude_paths


# ── rule-level config ─────────────────────────────────────────────────────────

def test_load_config_p002_any_threshold(tmp_path):
    yaml = "rules:\n  PROOFCTL-Q-003:\n    any_threshold: 5\n"
    (tmp_path / ".proofctl.yaml").write_text(yaml)
    cfg = load_config(tmp_path)
    assert cfg.any_threshold == 5


def test_load_config_p002_todo_allowed(tmp_path):
    yaml = "rules:\n  PROOFCTL-P-002:\n    allowed_formats:\n      - 'TODO\\(#\\d+\\)'\n"
    (tmp_path / ".proofctl.yaml").write_text(yaml)
    cfg = load_config(tmp_path)
    assert len(cfg.todo_allowed_formats) == 1


# ── is_disabled ───────────────────────────────────────────────────────────────

def test_is_disabled_true():
    cfg = ProofctlConfig(disable=["PROOFCTL-S-001"])
    assert cfg.is_disabled("PROOFCTL-S-001")


def test_is_disabled_false():
    cfg = ProofctlConfig(disable=["PROOFCTL-S-001"])
    assert not cfg.is_disabled("PROOFCTL-S-002")


def test_is_disabled_empty():
    cfg = ProofctlConfig()
    assert not cfg.is_disabled("ANYTHING")


# ── effective_severity ────────────────────────────────────────────────────────

def test_effective_severity_no_override_returns_default():
    cfg = ProofctlConfig()
    assert cfg.effective_severity("PROOFCTL-P-001", Severity.WARNING) == Severity.WARNING


def test_effective_severity_override_applied():
    cfg = ProofctlConfig(severity_overrides={"PROOFCTL-P-001": "ERROR"})
    assert cfg.effective_severity("PROOFCTL-P-001", Severity.WARNING) == Severity.ERROR
