"""Integration tests — run_check() against real temporary directories."""
from __future__ import annotations

from pathlib import Path

import pytest

from proofctl.config import ProofctlConfig
from proofctl.engine import run_check
from proofctl.models import Severity


def _cfg(**kwargs) -> ProofctlConfig:
    cfg = ProofctlConfig()
    for k, v in kwargs.items():
        setattr(cfg, k, v)
    return cfg


# ── file discovery ────────────────────────────────────────────────────────────

def test_engine_discovers_python_files(tmp_path):
    """run_check should pick up .py files in subdirectories."""
    sub = tmp_path / "src"
    sub.mkdir()
    (sub / "app.py").write_text("x = 1\n")
    findings = run_check(tmp_path, _cfg())
    # No findings expected for clean code, but the file must be scanned (no crash)
    assert isinstance(findings, list)


def test_engine_returns_findings_for_flagged_code(tmp_path):
    """Security checker should surface an S-005 finding for eval()."""
    (tmp_path / "bad.py").write_text(
        "import os\nresult = eval(user_input)\n"
    )
    findings = run_check(tmp_path, _cfg(), families=["S"])
    rule_ids = [f.rule_id for f in findings]
    assert "PROOFCTL-S-005" in rule_ids


def test_engine_excludes_configured_paths(tmp_path):
    """Files matching exclude_paths must not generate findings."""
    venv = tmp_path / ".venv" / "lib" / "app.py"
    venv.parent.mkdir(parents=True)
    venv.write_text("result = eval(user_input)\n")
    findings = run_check(tmp_path, _cfg(), families=["S"])
    assert all("venv" not in f.file for f in findings)


def test_engine_respects_disabled_rules(tmp_path):
    """Rules in config.disable must produce zero findings."""
    (tmp_path / "code.py").write_text(
        "import os\nresult = eval(user_input)\n"
    )
    cfg = _cfg(disable=["PROOFCTL-S-005"])
    findings = run_check(tmp_path, cfg, families=["S"])
    assert all(f.rule_id != "PROOFCTL-S-005" for f in findings)


# ── inline suppression end-to-end ─────────────────────────────────────────────

def test_engine_inline_suppress_prevents_finding(tmp_path):
    """A # proofctl: ignore[RULE] comment on the same line suppresses the finding."""
    src = 'result = eval(user_input)  # proofctl: ignore[PROOFCTL-S-005]\n'
    (tmp_path / "code.py").write_text(src)
    findings = run_check(tmp_path, _cfg(), families=["S"])
    assert all(f.rule_id != "PROOFCTL-S-005" for f in findings)


def test_engine_inline_suppress_other_rule_doesnt_suppress(tmp_path):
    """A suppress comment for a different rule must not suppress the actual finding."""
    src = 'result = eval(user_input)  # proofctl: ignore[PROOFCTL-P-001]\n'
    (tmp_path / "code.py").write_text(src)
    findings = run_check(tmp_path, _cfg(), families=["S"])
    s005 = [f for f in findings if f.rule_id == "PROOFCTL-S-005"]
    assert len(s005) == 1


# ── deduplication ─────────────────────────────────────────────────────────────

def test_engine_deduplicates_findings(tmp_path):
    """The same (file, line, col, rule_id) must appear only once."""
    src = "import os\nresult = eval(user_input)\n"
    (tmp_path / "code.py").write_text(src)
    findings = run_check(tmp_path, _cfg(), families=["S"])
    keys = [f.dedup_key() for f in findings]
    assert len(keys) == len(set(keys))
