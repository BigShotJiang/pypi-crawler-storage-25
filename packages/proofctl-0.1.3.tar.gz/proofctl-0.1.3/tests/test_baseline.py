from __future__ import annotations

import json
import tempfile
from pathlib import Path

from proofctl.baseline import (
    filter_new_findings,
    load_baseline,
    save_baseline,
)
from proofctl.models import Finding, Severity


def _f(rule_id: str, file: str = "foo.py", msg: str = "test msg", line: int = 1) -> Finding:
    return Finding(
        file=file, line=line, col=0,
        rule_id=rule_id, rule_name="Test",
        severity=Severity.ERROR, message=msg,
    )


# ── save / load ───────────────────────────────────────────────────────────────

def test_save_creates_file():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        findings = [_f("PROOFCTL-P-001")]
        out = save_baseline(findings, root)
        assert out.exists()


def test_save_load_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        findings = [_f("PROOFCTL-P-001", msg="'foo' body is pass")]
        save_baseline(findings, root)
        loaded = load_baseline(root)
        assert loaded is not None
        assert len(loaded) == 1
        assert loaded[0]["rule_id"] == "PROOFCTL-P-001"
        assert loaded[0]["message"] == "'foo' body is pass"


def test_load_returns_none_when_no_file():
    with tempfile.TemporaryDirectory() as td:
        assert load_baseline(Path(td)) is None


def test_load_returns_none_on_corrupt_file():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        (root / ".proofctl-baseline.json").write_text("not json")
        assert load_baseline(root) is None


def test_save_count_field():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        save_baseline([_f("PROOFCTL-P-001"), _f("PROOFCTL-L-001")], root)
        data = json.loads((root / ".proofctl-baseline.json").read_text())
        assert data["count"] == 2


# ── filter_new_findings ───────────────────────────────────────────────────────

def test_all_in_baseline_suppressed():
    f = _f("PROOFCTL-P-001", msg="'foo' body is pass")
    baseline = [{"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"}]
    assert filter_new_findings([f], baseline) == []


def test_new_finding_not_suppressed():
    f = _f("PROOFCTL-P-001", msg="'bar' body is pass")
    baseline = [{"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"}]
    assert filter_new_findings([f], baseline) == [f]


def test_different_rule_not_suppressed():
    f = _f("PROOFCTL-L-001", msg="'foo' body is pass")
    baseline = [{"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"}]
    assert filter_new_findings([f], baseline) == [f]


def test_different_file_not_suppressed():
    f = _f("PROOFCTL-P-001", file="bar.py", msg="'foo' body is pass")
    baseline = [{"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"}]
    assert filter_new_findings([f], baseline) == [f]


def test_line_shift_suppressed():
    # Same bug moved from line 10 to line 42 — message unchanged → still suppressed.
    f = _f("PROOFCTL-P-001", msg="'foo' body is pass", line=42)
    baseline = [{"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"}]
    assert filter_new_findings([f], baseline) == []


def test_empty_baseline_suppresses_nothing():
    f = _f("PROOFCTL-P-001")
    assert filter_new_findings([f], []) == [f]


def test_multiset_exact_count_suppressed():
    # Two identical findings in baseline suppress exactly two in new run.
    f1 = _f("PROOFCTL-P-001", msg="'foo' body is pass")
    f2 = _f("PROOFCTL-P-001", msg="'foo' body is pass")
    baseline = [
        {"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"},
        {"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"},
    ]
    assert filter_new_findings([f1, f2], baseline) == []


def test_multiset_one_extra_reported():
    # Three identical in new run, two in baseline → one new.
    f = _f("PROOFCTL-P-001", msg="'foo' body is pass")
    baseline = [
        {"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"},
        {"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "'foo' body is pass"},
    ]
    result = filter_new_findings([f, f, f], baseline)
    assert len(result) == 1


def test_mixed_findings():
    f_old = _f("PROOFCTL-P-001", msg="old")
    f_new = _f("PROOFCTL-Q-001", msg="new")
    baseline = [{"rule_id": "PROOFCTL-P-001", "file": "foo.py", "message": "old"}]
    result = filter_new_findings([f_old, f_new], baseline)
    assert result == [f_new]
