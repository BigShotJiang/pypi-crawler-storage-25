from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import Finding

_BASELINE_FILE = ".proofctl-baseline.json"


def _fingerprint(f: Finding) -> tuple[str, str, str]:
    # Stable across line-number shifts: same bug at a new line still matches.
    return (f.rule_id, f.file, f.message)


def save_baseline(findings: list[Finding], root: Path) -> Path:
    baseline_path = root / _BASELINE_FILE
    data = {
        "created": datetime.now(timezone.utc).isoformat(),
        "proofctl_version": "0.1.0",
        "count": len(findings),
        "findings": [
            {"rule_id": f.rule_id, "file": f.file, "message": f.message}
            for f in findings
        ],
    }
    baseline_path.write_text(json.dumps(data, indent=2))
    return baseline_path


def load_baseline(root: Path) -> list[dict] | None:
    baseline_path = root / _BASELINE_FILE
    if not baseline_path.exists():
        return None
    try:
        data = json.loads(baseline_path.read_text())
        return data.get("findings", [])
    except (json.JSONDecodeError, KeyError):
        return None


def filter_new_findings(findings: list[Finding], baseline: list[dict]) -> list[Finding]:
    """Return only findings not accounted for in the baseline.

    Uses a multiset so N identical baseline entries suppress exactly N occurrences
    in the new run — handles repeated findings correctly.
    """
    baseline_counts: Counter[tuple] = Counter(
        (b["rule_id"], b["file"], b["message"]) for b in baseline
    )
    result = []
    seen: Counter[tuple] = Counter()
    for f in findings:
        key = _fingerprint(f)
        if seen[key] < baseline_counts[key]:
            seen[key] += 1
        else:
            result.append(f)
    return result
