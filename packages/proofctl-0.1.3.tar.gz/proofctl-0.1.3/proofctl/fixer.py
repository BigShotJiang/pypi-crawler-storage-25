from __future__ import annotations

import ast
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import Finding

from .checkers.quality import _is_mutable_default


def apply_fixes(findings: list[Finding], root: Path) -> int:
    """Apply auto-fixes for fixable findings in-place. Returns number of findings fixed."""
    fixable = [f for f in findings if f.fixable and f.rule_id == "PROOFCTL-Q-001"]
    if not fixable:
        return 0

    # Group by file so we parse + write each file once.
    by_file: dict[str, list[Finding]] = {}
    for f in fixable:
        by_file.setdefault(f.file, []).append(f)

    fixed = 0
    for rel_path in by_file:
        abs_path = (root / rel_path) if not Path(rel_path).is_absolute() else Path(rel_path)
        try:
            source = abs_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(abs_path))
        except (OSError, SyntaxError):
            continue

        new_source = _fix_mutable_defaults(source, tree)
        if new_source != source:
            abs_path.write_text(new_source, encoding="utf-8")
            fixed += len(by_file[rel_path])

    return fixed


# ── internal helpers ──────────────────────────────────────────────────────────

def _is_docstring(stmt: ast.stmt) -> bool:
    return (
        isinstance(stmt, ast.Expr)
        and isinstance(stmt.value, ast.Constant)
        and isinstance(stmt.value.value, str)
    )


def _fix_mutable_defaults(source: str, tree: ast.Module) -> str:
    """Rewrite source so every mutable default becomes None + a sentinel guard.

    Processing order guarantees correctness:
    - We collect all orig_src values from the *original* source string before
      modifying anything (ast.get_source_segment always reads original source).
    - Within each file we work bottom-up by function start line so any line
      insertions for lower functions don't shift the positions of higher ones.
    - Within each function we replace defaults right-to-left so earlier
      replacements don't shift later column offsets on the same line.
    """
    lines = source.splitlines(keepends=True)

    # Collect (func_node, [(arg_name, default_node, orig_src), ...])
    func_fixes: list[tuple[ast.FunctionDef | ast.AsyncFunctionDef, list]] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        fixes_for_func: list[tuple[str, ast.expr, str]] = []
        args = node.args

        # Positional defaults align to the LAST N positional args
        offset = len(args.args) - len(args.defaults)
        for i, default in enumerate(args.defaults):
            if _is_mutable_default(default):
                arg_name = args.args[offset + i].arg
                orig_src = ast.get_source_segment(source, default)
                if orig_src:
                    fixes_for_func.append((arg_name, default, orig_src))

        # Keyword-only defaults
        for arg, default in zip(args.kwonlyargs, args.kw_defaults):
            if default is not None and _is_mutable_default(default):
                orig_src = ast.get_source_segment(source, default)
                if orig_src:
                    fixes_for_func.append((arg.arg, default, orig_src))

        if fixes_for_func:
            func_fixes.append((node, fixes_for_func))

    if not func_fixes:
        return source

    # Bottom-up by function start line
    func_fixes.sort(key=lambda x: x[0].lineno, reverse=True)

    for func_node, fixes_list in func_fixes:
        # --- Step 1: replace each default with None, right-to-left ---
        fixes_list.sort(key=lambda x: (x[1].lineno, x[1].col_offset), reverse=True)

        for _arg_name, default_node, _orig in fixes_list:
            dl = default_node.lineno - 1
            dc = default_node.col_offset
            del_ = default_node.end_lineno - 1
            dec = default_node.end_col_offset

            if dl == del_:
                line = lines[dl]
                lines[dl] = line[:dc] + "None" + line[dec:]
            # Multi-line default literals are so rare we skip them silently.

        # --- Step 2: insert sentinel guards ---
        body = func_node.body
        first_stmt = body[0]

        if _is_docstring(first_stmt):
            # Insert after the closing quote of the docstring.
            insert_at = first_stmt.end_lineno  # 0-based: this is already the next index
        else:
            insert_at = first_stmt.lineno - 1  # 0-based: before first statement

        # Detect indentation from the first body line.
        body_line = lines[first_stmt.lineno - 1]
        indent_str = body_line[: len(body_line) - len(body_line.lstrip())]

        # Emit sentinels in declaration order (left-to-right) for readability.
        fixes_list.sort(key=lambda x: (x[1].lineno, x[1].col_offset))
        sentinel_lines: list[str] = []
        for arg_name, _default_node, orig_src in fixes_list:
            sentinel_lines.append(f"{indent_str}if {arg_name} is None:\n")
            sentinel_lines.append(f"{indent_str}    {arg_name} = {orig_src}\n")

        for i, sl in enumerate(sentinel_lines):
            lines.insert(insert_at + i, sl)

    return "".join(lines)
