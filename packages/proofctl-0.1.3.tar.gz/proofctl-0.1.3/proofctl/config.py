from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .models import Severity

_DEFAULTS = {
    "exclude_paths": [
        "**/.venv/**",
        "**/venv/**",
        "**/node_modules/**",
        "**/.git/**",
        "**/__pycache__/**",
        "**/*.egg-info/**",
        "**/dist/**",
        "**/build/**",
        "**/.terragrunt-cache/**",
        "**/.terraform/**",
    ],
    "disable": [],
    "severity_overrides": {},
}


@dataclass
class ProofctlConfig:
    exclude_paths: list[str] = field(default_factory=lambda: list(_DEFAULTS["exclude_paths"]))
    disable: list[str] = field(default_factory=list)
    severity_overrides: dict[str, str] = field(default_factory=dict)
    # PROOFCTL-P-002
    todo_allowed_formats: list[str] = field(default_factory=list)
    todo_exclude_paths: list[str] = field(default_factory=lambda: ["tests/", "migrations/", "scripts/"])
    # PROOFCTL-Q-003
    any_threshold: int = 3
    # PROOFCTL-V-002
    similarity_threshold: float = 0.80
    similarity_min_lines: int = 30
    # PROOFCTL-I-001
    pypi_extra_indexes: list[str] = field(default_factory=list)
    local_namespaces: list[str] = field(default_factory=list)
    # PROOFCTL-I-002
    i002_extra_high_risk: list[str] = field(default_factory=list)
    # PROOFCTL-TF-T013
    tf_required_labels: list[str] = field(default_factory=list)

    def is_disabled(self, rule_id: str) -> bool:
        return rule_id in self.disable

    def effective_severity(self, rule_id: str, default: Severity) -> Severity:
        raw = self.severity_overrides.get(rule_id)
        if raw:
            return Severity.from_str(raw)
        return default

    def todo_is_allowed(self, comment_text: str) -> bool:
        if not self.todo_allowed_formats:
            return False
        return any(re.search(pat, comment_text) for pat in self.todo_allowed_formats)


def load_config(root: Path) -> ProofctlConfig:
    cfg_file = root / ".proofctl.yaml"
    if not cfg_file.exists():
        return ProofctlConfig()

    with cfg_file.open() as f:
        raw = yaml.safe_load(f) or {}

    rules = raw.get("rules", {})
    p002 = rules.get("PROOFCTL-P-002", {})
    q003 = rules.get("PROOFCTL-Q-003", {})
    v002 = rules.get("PROOFCTL-V-002", {})
    i001 = rules.get("PROOFCTL-I-001", {})

    return ProofctlConfig(
        exclude_paths=raw.get("exclude_paths", _DEFAULTS["exclude_paths"]),
        disable=raw.get("disable", []),
        severity_overrides=raw.get("severity_overrides", {}),
        todo_allowed_formats=p002.get("allowed_formats", []),
        todo_exclude_paths=p002.get("exclude_paths", ["tests/", "migrations/", "scripts/"]),
        any_threshold=q003.get("any_threshold", 3),
        similarity_threshold=v002.get("similarity_threshold", 0.80),
        similarity_min_lines=v002.get("min_file_lines", 30),
        pypi_extra_indexes=i001.get("extra_indexes", []),
        local_namespaces=i001.get("local_namespaces", []),
        i002_extra_high_risk=rules.get("PROOFCTL-I-002", {}).get("extra_high_risk", []),
        tf_required_labels=rules.get("PROOFCTL-TF-T013", {}).get("required_labels", []),
    )
