from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import List, Optional

import typer

from .config import load_config
from .engine import run_check

app = typer.Typer(
    name="proofctl",
    help="Detects AI-generated slop: hallucinated imports, phantom methods, placeholder code, cross-language leakage, and variant file debris.",
    add_completion=False,
    no_args_is_help=True,
)


class OutputFormat(str, Enum):
    terminal = "terminal"
    json = "json"
    html = "html"


class SeverityLevel(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


def _run_check_for_root(
    path: Path,
    config,
    changed_only: bool,
    families: Optional[str],
    min_severity: Optional[SeverityLevel],
    no_pypi: bool,
):
    root = path.resolve()
    if no_pypi:
        config.local_namespaces = ["*"]
    fam_list = [f.strip().upper() for f in families.split(",")] if families else None
    scan_root = root if root.is_dir() else root.parent
    findings = run_check(
        root=scan_root,
        config=config,
        changed_only=changed_only,
        families=fam_list,
        min_severity=min_severity.value if min_severity else None,
    )
    if root.is_file():
        rel = str(root.relative_to(root.parent))
        findings = [f for f in findings if f.file == rel]
    return scan_root, findings


@app.command()
def check(
    path: Path = typer.Argument(Path("."), help="Path to scan (file or directory)"),
    format: OutputFormat = typer.Option(OutputFormat.terminal, "--format", "-f"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Write report to file"),
    changed_only: bool = typer.Option(
        False, "--changed-only", help="Only scan files changed vs git HEAD / main"
    ),
    families: Optional[str] = typer.Option(
        None,
        "--families",
        help=(
            "Comma-separated rule families to run: P (placeholders), L (leakage), "
            "Q (quality), I (imports), M (methods), V (variants). Default: all."
        ),
    ),
    min_severity: Optional[SeverityLevel] = typer.Option(
        None,
        "--min-severity",
        help="Only report findings at this severity or above.",
    ),
    fail_on: Optional[SeverityLevel] = typer.Option(
        None,
        "--fail-on",
        help="Exit non-zero only if findings at this severity or above exist. Default: WARNING.",
    ),
    no_pypi: bool = typer.Option(
        False,
        "--no-pypi",
        help="Skip PyPI lookups for import hallucination checks (faster, offline).",
    ),
    new_only: bool = typer.Option(
        False,
        "--new-only",
        help="Only report findings not present in .proofctl-baseline.json.",
    ),
    fix: bool = typer.Option(
        False,
        "--fix",
        help="Auto-fix fixable findings (currently: Q-001 mutable default arguments).",
    ),
) -> None:
    root_path = path.resolve()
    if not root_path.exists():
        typer.echo(f"Error: path '{root_path}' does not exist", err=True)
        raise typer.Exit(1)

    config = load_config(root_path if root_path.is_dir() else root_path.parent)
    scan_root, findings = _run_check_for_root(
        root_path, config, changed_only, families, min_severity, no_pypi
    )

    if fix:
        from .fixer import apply_fixes
        n = apply_fixes(findings, scan_root)
        if n:
            typer.echo(f"Fixed {n} finding(s) — re-scanning…", err=True)
            _, findings = _run_check_for_root(
                root_path, config, changed_only, families, min_severity, no_pypi
            )
        else:
            typer.echo("No auto-fixable findings.", err=True)

    if new_only:
        from .baseline import load_baseline, filter_new_findings
        baseline = load_baseline(scan_root)
        if baseline is None:
            typer.echo(
                "No baseline found. Run `proofctl baseline` first.", err=True
            )
        else:
            before = len(findings)
            findings = filter_new_findings(findings, baseline)
            suppressed = before - len(findings)
            if suppressed:
                typer.echo(
                    f"[baseline] {suppressed} existing finding(s) suppressed.", err=True
                )

    if format == OutputFormat.terminal:
        from .reporters.terminal import TerminalReporter
        reporter = TerminalReporter()
    elif format == OutputFormat.json:
        from .reporters.json_reporter import JsonReporter
        reporter = JsonReporter()
    else:
        from .reporters.html_reporter import HtmlReporter
        reporter = HtmlReporter()

    content = reporter.render(findings)

    if output:
        try:
            output.write_text(content, encoding="utf-8")
        except OSError as e:
            typer.echo(f"Error: cannot write {output}: {e}", err=True)
            raise typer.Exit(1)
        typer.echo(f"Report written to {output}")
    elif format != OutputFormat.terminal:
        typer.echo(content)

    if not findings:
        raise typer.Exit(0)

    from .models import Severity
    threshold_str = fail_on.value if fail_on else "WARNING"
    threshold = Severity.from_str(threshold_str)
    max_sev = max(f.severity for f in findings)

    if max_sev >= threshold:
        raise typer.Exit(2)
    raise typer.Exit(1)


@app.command()
def baseline(
    path: Path = typer.Argument(Path("."), help="Root of the project to snapshot"),
    no_pypi: bool = typer.Option(False, "--no-pypi"),
) -> None:
    """Snapshot current findings into .proofctl-baseline.json.

    Subsequent `proofctl check --new-only` calls will suppress these findings
    and report only new ones introduced since the snapshot.
    """
    root_path = path.resolve()
    if not root_path.exists():
        typer.echo(f"Error: path '{root_path}' does not exist", err=True)
        raise typer.Exit(1)

    config = load_config(root_path if root_path.is_dir() else root_path.parent)
    scan_root, findings = _run_check_for_root(
        root_path, config, False, None, None, no_pypi
    )

    from .baseline import save_baseline
    out = save_baseline(findings, scan_root)
    typer.echo(f"Baseline saved: {out} ({len(findings)} finding(s))")


@app.command()
def rules() -> None:
    """List all rules with their IDs, names, and severity."""
    from rich.console import Console
    from rich.table import Table
    from rich import box

    con = Console()
    table = Table(box=box.SIMPLE_HEAD, show_edge=False, header_style="dim")
    table.add_column("Rule ID", no_wrap=True, min_width=18)
    table.add_column("Name", min_width=32)
    table.add_column("Sev", min_width=8)
    table.add_column("Family")

    _RULES = [
        ("PROOFCTL-P-001", "Unimplemented function body",     "ERROR",   "Placeholder"),
        ("PROOFCTL-P-002", "TODO sentinel in production code","WARNING",  "Placeholder"),
        ("PROOFCTL-P-003", "Commented-out code block",        "INFO",    "Placeholder"),
        ("PROOFCTL-L-001", "JavaScript idiom in Python",      "ERROR",   "Leakage"),
        ("PROOFCTL-L-002", "Java idiom in Python",            "WARNING", "Leakage"),
        ("PROOFCTL-L-003", "Go idiom in Python",              "WARNING", "Leakage"),
        ("PROOFCTL-Q-001", "Mutable default argument",        "ERROR",   "Quality"),
        ("PROOFCTL-Q-002", "Broad exception handler",         "ERROR",   "Quality"),
        ("PROOFCTL-Q-003", "Excessive Any / type: ignore",    "WARNING", "Quality"),
        ("PROOFCTL-Q-004", "Single-implementation abstraction","INFO",   "Quality"),
        ("PROOFCTL-I-001", "Hallucinated import",             "ERROR",   "Import"),
        ("PROOFCTL-I-002", "High-risk dependency name",       "ERROR",   "Import"),
        ("PROOFCTL-M-001", "Phantom method call (mypy)",      "ERROR",   "Method"),
        ("PROOFCTL-V-001", "Variant file debris",             "WARNING", "Variant"),
        ("PROOFCTL-V-002", "Near-duplicate file",             "INFO",    "Variant"),
    ]

    sev_style = {"ERROR": "red", "WARNING": "yellow", "INFO": "dim"}
    for rule_id, name, sev, family in _RULES:
        table.add_row(
            rule_id,
            name,
            f"[{sev_style[sev]}]{sev}[/{sev_style[sev]}]",
            family,
        )

    con.print()
    con.print(table)
    con.print()


@app.command(hidden=True)
def version() -> None:
    """Print version."""
    typer.echo("proofctl 0.1.0")
