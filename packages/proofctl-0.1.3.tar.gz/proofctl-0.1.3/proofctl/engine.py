from __future__ import annotations

import ast
import dataclasses
import fnmatch
import re
import subprocess
from pathlib import Path

import rich.console

from .config import ProofctlConfig
from .models import Finding
from .checkers.placeholders import PlaceholderChecker
from .checkers.leakage import LeakageChecker
from .checkers.quality import QualityChecker, AbstractionChecker
from .checkers.imports import ImportChecker, MethodChecker, DependencyChecker
from .checkers.variants import VariantChecker
from .checkers.security import SecurityChecker
from .checkers.llm_integration import LLMChecker
from .checkers.terraform import TerraformChecker, TerraformDirChecker
from .checkers.terragrunt import TerragruntChecker
from .checkers.dockerfile import DockerfileRulesChecker
from .checkers.yaml_checker import YamlRulesChecker

console = rich.console.Console(stderr=True)

_SUPPRESS_RE = re.compile(r"#\s*proofctl:\s*ignore\[([^\]]*)\]")


def _load_suppressions(source: str) -> dict[int, set[str]]:
    """Returns {1-based lineno: {rule_id, ...}} for every `# proofctl: ignore[...]` comment."""
    result: dict[int, set[str]] = {}
    for lineno, line in enumerate(source.splitlines(), start=1):
        m = _SUPPRESS_RE.search(line)
        if m:
            rule_ids = {r.strip() for r in m.group(1).split(",") if r.strip()}
            if rule_ids:
                result[lineno] = rule_ids
    return result


def _is_suppressed(
    f: "Finding",
    suppressions: dict[str, dict[int, set[str]]],
) -> bool:
    if f.line is None:
        return False
    file_supps = suppressions.get(f.file)
    if not file_supps:
        return False
    return f.rule_id in file_supps.get(f.line, set())


def _is_excluded(path: Path, root: Path, patterns: list[str]) -> bool:
    rel = str(path.relative_to(root))
    for pat in patterns:
        if fnmatch.fnmatch(rel, pat):
            return True
        stripped = pat.lstrip("*/")
        if stripped and fnmatch.fnmatch(rel, stripped):
            return True
    return False


def _changed_files(root: Path) -> list[Path]:
    result = subprocess.run(
        ["git", "diff", "--name-only", "HEAD"],
        capture_output=True, text=True, cwd=root,
    )
    if result.returncode != 0:
        for base in ("main", "master", "origin/main", "origin/master"):
            result = subprocess.run(
                ["git", "diff", "--name-only", base],
                capture_output=True, text=True, cwd=root,
            )
            if result.returncode == 0:
                break
    files = [root / f.strip() for f in result.stdout.splitlines() if f.strip()]
    return [f for f in files if f.exists() and f.suffix == ".py"]


def _build_file_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []

    def _include(family: str) -> bool:
        return families is None or family in families

    if _include("P"):
        checkers.append(PlaceholderChecker(
            todo_allowed_formats=config.todo_allowed_formats,
            todo_exclude_paths=config.todo_exclude_paths,
        ))
    if _include("L"):
        checkers.append(LeakageChecker())
    if _include("Q"):
        checkers.append(QualityChecker(any_threshold=config.any_threshold))
    if _include("I"):
        checkers.append(ImportChecker(
            local_namespaces=config.local_namespaces,
            extra_indexes=config.pypi_extra_indexes,
        ))
    if _include("S"):
        checkers.append(SecurityChecker())
    if _include("LLM"):
        checkers.append(LLMChecker())
    return checkers


def _build_dir_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []

    def _include(family: str) -> bool:
        return families is None or family in families

    if _include("V"):
        checkers.append(VariantChecker(
            similarity_threshold=config.similarity_threshold,
            min_lines=config.similarity_min_lines,
        ))
    if _include("Q"):
        checkers.append(AbstractionChecker())
    if _include("I"):
        checkers.append(DependencyChecker(
            extra_high_risk=config.i002_extra_high_risk,
        ))
    if _include("M"):
        checkers.append(MethodChecker())

    return checkers


def _build_hcl_file_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []

    def _include(family: str) -> bool:
        return families is None or family in families

    if _include("TF"):
        checkers.append(TerraformChecker(required_labels=config.tf_required_labels))
    if _include("TG"):
        checkers.append(TerragruntChecker())

    return checkers


def _build_hcl_dir_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []

    def _include(family: str) -> bool:
        return families is None or family in families

    if _include("TF"):
        checkers.append(TerraformDirChecker())

    return checkers


def _build_dockerfile_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []
    if families is None or "DF" in families:
        checkers.append(DockerfileRulesChecker())
    return checkers


def _build_yaml_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []
    if families is None or "YAML" in families:
        checkers.append(YamlRulesChecker())
    return checkers


_DOCKERFILE_RE = re.compile(r"^Dockerfile(\..*)?$")


def run_check(
    root: Path,
    config: ProofctlConfig,
    changed_only: bool = False,
    families: list[str] | None = None,
    min_severity: str | None = None,
) -> list[Finding]:
    fam_set = {f.upper() for f in families} if families else None

    _HCL_EXTS = (".tf", ".tfvars", ".hcl")
    _YAML_EXTS = (".yml", ".yaml")

    if changed_only:
        py_files = _changed_files(root)
        console.print(f"[dim]--changed-only: {len(py_files)} Python file(s) in scope[/dim]")
        _changed = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"],
            capture_output=True, text=True, cwd=root,
        ).stdout.splitlines()
        hcl_files = [
            p for f in _changed
            if (p := root / f.strip()).is_file() and p.suffix in _HCL_EXTS
            and not _is_excluded(p, root, config.exclude_paths)
        ]
        dockerfile_files = [
            p for f in _changed
            if (p := root / f.strip()).is_file()
            and _DOCKERFILE_RE.match(p.name)
            and not _is_excluded(p, root, config.exclude_paths)
        ]
        yaml_files = [
            p for f in _changed
            if (p := root / f.strip()).is_file() and p.suffix in _YAML_EXTS
            and not _is_excluded(p, root, config.exclude_paths)
        ]
    else:
        py_files = [
            p for p in root.rglob("*.py")
            if p.is_file() and not _is_excluded(p, root, config.exclude_paths)
        ]
        hcl_files = [
            p for p in root.rglob("*")
            if p.is_file() and p.suffix in _HCL_EXTS
            and not _is_excluded(p, root, config.exclude_paths)
        ]
        dockerfile_files = [
            p for p in root.rglob("*")
            if p.is_file() and _DOCKERFILE_RE.match(p.name)
            and not _is_excluded(p, root, config.exclude_paths)
        ]
        yaml_files = [
            p for p in root.rglob("*")
            if p.is_file() and p.suffix in _YAML_EXTS
            and not _is_excluded(p, root, config.exclude_paths)
        ]

    file_checkers = _build_file_checkers(config, fam_set)
    dir_checkers = _build_dir_checkers(config, fam_set)
    hcl_file_checkers = _build_hcl_file_checkers(config, fam_set)
    hcl_dir_checkers = _build_hcl_dir_checkers(config, fam_set)
    dockerfile_checkers = _build_dockerfile_checkers(config, fam_set)
    yaml_checkers = _build_yaml_checkers(config, fam_set)

    findings: list[Finding] = []
    seen: set[tuple] = set()
    # Map of relative-path → {lineno → {rule_ids}} for inline suppression comments.
    suppressions: dict[str, dict[int, set[str]]] = {}

    for path in py_files:
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        # Build suppression map keyed by the relative path findings will use.
        supps = _load_suppressions(source)
        if supps:
            try:
                rel = str(path.relative_to(root))
            except ValueError:
                rel = str(path)
            suppressions[rel] = supps

        try:
            tree: ast.Module | None = ast.parse(source, filename=str(path))
        except SyntaxError:
            tree = None

        for checker in file_checkers:
            try:
                raw = checker.check(path, source, tree)
            except Exception as exc:
                console.print(f"[dim]checker error ({type(checker).__name__} on {path.name}): {exc}[/dim]")
                continue
            for f in raw:
                f = _normalise(f, root, config)
                if f is None:
                    continue
                if _is_suppressed(f, suppressions):
                    continue
                key = f.dedup_key()
                if key not in seen:
                    seen.add(key)
                    findings.append(f)

    for checker in dir_checkers:
        try:
            raw = checker.check(root, py_files)
        except Exception as exc:
            console.print(f"[dim]directory checker error ({type(checker).__name__}): {exc}[/dim]")
            continue
        for f in raw:
            f = _normalise(f, root, config)
            if f is None:
                continue
            key = f.dedup_key()
            if key not in seen:
                seen.add(key)
                findings.append(f)

    # ── HCL (Terraform / Terragrunt) ─────────────────────────────────────────
    for path in hcl_files:
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for checker in hcl_file_checkers:
            if checker.extensions and path.suffix not in checker.extensions:
                continue
            try:
                raw = checker.check(path, source)
            except Exception as exc:
                console.print(
                    f"[dim]HCL checker error ({type(checker).__name__} on {path.name}): {exc}[/dim]"
                )
                continue
            for f in raw:
                f = _normalise(f, root, config)
                if f is None:
                    continue
                key = f.dedup_key()
                if key not in seen:
                    seen.add(key)
                    findings.append(f)

    for checker in hcl_dir_checkers:
        try:
            raw = checker.check(root, hcl_files)
        except Exception as exc:
            console.print(f"[dim]HCL directory checker error ({type(checker).__name__}): {exc}[/dim]")
            continue
        for f in raw:
            f = _normalise(f, root, config)
            if f is None:
                continue
            key = f.dedup_key()
            if key not in seen:
                seen.add(key)
                findings.append(f)

    # ── Dockerfile ────────────────────────────────────────────────────────────
    for path in dockerfile_files:
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for checker in dockerfile_checkers:
            try:
                raw = checker.check(path, source)
            except Exception as exc:
                console.print(
                    f"[dim]Dockerfile checker error ({type(checker).__name__} on {path.name}): {exc}[/dim]"
                )
                continue
            for f in raw:
                f = _normalise(f, root, config)
                if f is None:
                    continue
                key = f.dedup_key()
                if key not in seen:
                    seen.add(key)
                    findings.append(f)

    # ── YAML ──────────────────────────────────────────────────────────────────
    for path in yaml_files:
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for checker in yaml_checkers:
            try:
                raw = checker.check(path, source)
            except Exception as exc:
                console.print(
                    f"[dim]YAML checker error ({type(checker).__name__} on {path.name}): {exc}[/dim]"
                )
                continue
            for f in raw:
                f = _normalise(f, root, config)
                if f is None:
                    continue
                key = f.dedup_key()
                if key not in seen:
                    seen.add(key)
                    findings.append(f)

    if min_severity:
        from .models import Severity
        floor = Severity.from_str(min_severity)
        findings = [f for f in findings if f.severity >= floor]

    return sorted(findings, key=lambda x: (-x.severity, x.file, x.line or 0))


def _normalise(f: Finding, root: Path, config: ProofctlConfig) -> Finding | None:
    if config.is_disabled(f.rule_id):
        return None
    # Relative path
    try:
        rel = str(Path(f.file).relative_to(root))
        f = dataclasses.replace(f, file=rel)
    except ValueError:
        pass
    # Severity override
    sev = config.effective_severity(f.rule_id, f.severity)
    if sev != f.severity:
        f = dataclasses.replace(f, severity=sev)
    return f
