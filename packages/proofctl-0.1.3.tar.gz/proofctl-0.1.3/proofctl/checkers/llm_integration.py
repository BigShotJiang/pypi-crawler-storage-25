"""LLM integration checker — rules PROOFCTL-LLM-*

Targets code that *uses* LLM APIs (OpenAI, Anthropic, LiteLLM, LangChain,
Google GenAI). These are the patterns AI assistants generate when asked to
"add AI features" without security or cost guardrails.

LLM-001  Prompt injection — user/external input interpolated into message content
LLM-002  Missing max_tokens — unbounded completion cost / runaway responses
LLM-003  LLM call inside a loop — unbounded cost; should batch or rate-limit
LLM-004  PII variable names passed to LLM API — potential data exposure
LLM-005  Unbounded agentic loop — while True: with LLM call and no iteration cap
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker

# ── LLM API detection ─────────────────────────────────────────────────────────

_LLM_MODEL_PREFIXES = (
    "gpt-", "gpt4", "o1-", "o3-", "o4-",
    "claude-", "claude2", "claude3",
    "text-davinci", "text-embedding",
    "llama", "llama2", "llama3",
    "gemini", "palm",
    "mistral", "mixtral",
    "command", "command-r",
    "falcon", "wizard",
)

_LLM_COMPLETION_ATTRS = frozenset({
    "create", "acreate",            # OpenAI / Anthropic .create()
    "completion", "acompletion",    # LiteLLM
    "generate_content",             # Google GenAI
    "generate_content_async",
    "invoke", "ainvoke",            # LangChain
    "predict", "apredict",
    "run", "arun",
})

_PII_VAR_RE = re.compile(
    r"\b(?:email|phone|mobile|ssn|social_security|passport|national_id|"
    r"credit_card|card_number|dob|date_of_birth|full_name|first_name|"
    r"last_name|surname|ip_address|mac_address|user_address|postcode|"
    r"zip_code|bank_account|iban|salary|health_record|medical_record)\b",
    re.IGNORECASE,
)

_MAX_TOKEN_KWARGS = frozenset({"max_tokens", "max_completion_tokens", "max_new_tokens", "max_output_tokens"})


def _is_llm_call(node: ast.Call) -> bool:
    """Heuristic: is this call an LLM completion/generation API?"""
    # Keyed by model= value matching a known LLM prefix
    for kw in node.keywords:
        if kw.arg == "model" and isinstance(kw.value, ast.Constant):
            model = str(kw.value.value).lower()
            if any(model.startswith(p) for p in _LLM_MODEL_PREFIXES):
                return True

    # .create() on something that looks like completions/messages/chat
    if isinstance(node.func, ast.Attribute) and node.func.attr in ("create", "acreate"):
        val = node.func.value
        if isinstance(val, ast.Attribute) and val.attr in (
            "completions", "messages", "chat", "text",
        ):
            return True
        # Has messages= kwarg (chat interface)
        if any(kw.arg == "messages" for kw in node.keywords):
            return True

    # litellm.completion() / litellm.acompletion()
    if isinstance(node.func, ast.Attribute):
        if (
            isinstance(node.func.value, ast.Name)
            and node.func.value.id in ("litellm",)
            and node.func.attr in ("completion", "acompletion", "text_completion")
        ):
            return True

    # Direct call: completion(model=..., messages=...)
    if isinstance(node.func, ast.Name) and node.func.id in ("completion", "acompletion"):
        if any(kw.arg in ("messages", "model") for kw in node.keywords):
            return True

    return False


def _collect_llm_calls(tree: ast.Module) -> list[ast.Call]:
    """Return all LLM API call nodes in the file."""
    calls = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and _is_llm_call(node):
            calls.append(node)
    return calls


def _extract_names_from_expr(node: ast.expr) -> list[str]:
    """Collect all Name.id strings referenced in an expression."""
    return [n.id for n in ast.walk(node) if isinstance(n, ast.Name)]


def _is_interpolated_content(node: ast.expr) -> bool:
    """True if node is an f-string or concat that could inject user input."""
    if isinstance(node, ast.JoinedStr):
        return any(not isinstance(v, ast.Constant) for v in node.values)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return True
    if isinstance(node, ast.Call):
        if isinstance(node.func, ast.Attribute) and node.func.attr == "format":
            return True
    return False


# ── Visitors ──────────────────────────────────────────────────────────────────

class _LLM001Visitor(ast.NodeVisitor):
    """Prompt injection: user/external input interpolated into message content."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        if not _is_llm_call(node):
            self.generic_visit(node)
            return

        # Look for messages= kwarg
        for kw in node.keywords:
            if kw.arg != "messages":
                continue
            self._check_messages_arg(kw.value, node.lineno)
        self.generic_visit(node)

    def _check_messages_arg(self, messages_node: ast.expr, call_line: int) -> None:
        """Walk the messages list/variable looking for interpolated content values."""
        # Only inspect inline list literals; variable references can't be analysed statically
        if not isinstance(messages_node, ast.List):
            return
        for elt in messages_node.elts:
            if not isinstance(elt, ast.Dict):
                continue
            for key, val in zip(elt.keys, elt.values):
                if not (isinstance(key, ast.Constant) and key.value == "content"):
                    continue
                if _is_interpolated_content(val):
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=getattr(val, "lineno", call_line),
                        col=getattr(val, "col_offset", None),
                        rule_id="PROOFCTL-LLM-001",
                        rule_name="Prompt injection risk",
                        severity=Severity.ERROR,
                        message=(
                            "LLM message content is built with string interpolation — "
                            "user input can hijack the prompt"
                        ),
                        hint=(
                            "Sanitise user input before embedding in prompts, or use a "
                            "dedicated input slot that the model treats as data, not instructions."
                        ),
                        authority="OWASP LLM Top 10 – LLM01:2025 Prompt Injection",
                    ))


class _LLM002Visitor(ast.NodeVisitor):
    """Missing max_tokens on LLM call — unbounded output and cost."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        if _is_llm_call(node):
            if not any(kw.arg in _MAX_TOKEN_KWARGS for kw in node.keywords):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-LLM-002",
                    rule_name="LLM call missing max_tokens",
                    severity=Severity.WARNING,
                    message="LLM API call has no max_tokens — response length and cost are unbounded",
                    hint="Add max_tokens=N to cap output length and prevent runaway API spend.",
                    authority="OWASP LLM Top 10 – LLM10:2025 Unbounded Consumption",
                ))
        self.generic_visit(node)


class _LLM003Visitor(ast.NodeVisitor):
    """LLM call inside a for/while loop — each iteration incurs API cost."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []
        self._loop_depth = 0

    def visit_For(self, node: ast.For) -> None:
        self._loop_depth += 1
        self.generic_visit(node)
        self._loop_depth -= 1

    def visit_AsyncFor(self, node: ast.AsyncFor) -> None:
        self._loop_depth += 1
        self.generic_visit(node)
        self._loop_depth -= 1

    def visit_While(self, node: ast.While) -> None:
        self._loop_depth += 1
        self.generic_visit(node)
        self._loop_depth -= 1

    def visit_Call(self, node: ast.Call) -> None:
        if self._loop_depth > 0 and _is_llm_call(node):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-LLM-003",
                rule_name="LLM call inside loop",
                severity=Severity.WARNING,
                message="LLM API call is inside a loop — each iteration makes a separate billed request",
                hint=(
                    "Batch inputs and use a single API call where possible. "
                    "If iterating is required, add rate limiting and a cost budget check."
                ),
                authority="OWASP LLM Top 10 – LLM10:2025 Unbounded Consumption",
            ))
        self.generic_visit(node)


class _LLM004Visitor(ast.NodeVisitor):
    """PII variable names referenced inside LLM message content."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        if not _is_llm_call(node):
            self.generic_visit(node)
            return

        for kw in node.keywords:
            if kw.arg != "messages":
                continue
            if not isinstance(kw.value, ast.List):
                continue
            for elt in kw.value.elts:
                if not isinstance(elt, ast.Dict):
                    continue
                for key, val in zip(elt.keys, elt.values):
                    if not (isinstance(key, ast.Constant) and key.value == "content"):
                        continue
                    # Check variable names referenced in the content expression
                    for name_node in ast.walk(val):
                        if not isinstance(name_node, ast.Name):
                            continue
                        if _PII_VAR_RE.search(name_node.id):
                            self.findings.append(Finding(
                                file=str(self.path),
                                line=getattr(name_node, "lineno", node.lineno),
                                col=getattr(name_node, "col_offset", None),
                                rule_id="PROOFCTL-LLM-004",
                                rule_name="PII variable in LLM prompt",
                                severity=Severity.WARNING,
                                message=(
                                    f'Variable "{name_node.id}" looks like PII and is '
                                    "being included in an LLM prompt"
                                ),
                                hint=(
                                    "Redact or pseudonymise PII before sending to external LLM APIs. "
                                    "Check your data processing agreement with the provider."
                                ),
                                authority="GDPR Art. 25 – Data minimisation / OWASP LLM02:2025",
                            ))
                            break  # one finding per content block
        self.generic_visit(node)


class _LLM005Visitor(ast.NodeVisitor):
    """Unbounded agentic loop: while True: containing an LLM call with no iter cap."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_While(self, node: ast.While) -> None:
        # while True: pattern
        if not (isinstance(node.test, ast.Constant) and node.test.value is True):
            self.generic_visit(node)
            return

        # Check if body contains an LLM call
        has_llm = any(
            isinstance(n, ast.Call) and _is_llm_call(n)
            for n in ast.walk(ast.Module(body=node.body, type_ignores=[]))
        )
        if not has_llm:
            self.generic_visit(node)
            return

        # Check if there's a counter-based break guard
        # Look for: if <name> >= <N>: break  or  if count > N: ...
        has_iter_guard = self._has_iteration_guard(node.body)
        if not has_iter_guard:
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-LLM-005",
                rule_name="Unbounded agentic loop",
                severity=Severity.ERROR,
                message=(
                    "while True: loop contains an LLM call with no iteration cap — "
                    "runaway cost and potential infinite loop"
                ),
                hint=(
                    "Add a maximum iteration counter: "
                    "for step in range(max_steps): ... "
                    "or guard with: if steps >= MAX_STEPS: break"
                ),
                authority="OWASP LLM Top 10 – LLM10:2025 Unbounded Consumption",
            ))
        self.generic_visit(node)

    @staticmethod
    def _has_iteration_guard(body: list[ast.stmt]) -> bool:
        """True if there's an if <counter> >= <literal>: break somewhere in body."""
        for stmt in ast.walk(ast.Module(body=body, type_ignores=[])):
            if not isinstance(stmt, ast.If):
                continue
            test = stmt.test
            # if <name> >= N: break  or  if <name> > N: break
            if isinstance(test, ast.Compare) and isinstance(test.left, ast.Name):
                ops = test.ops
                if any(isinstance(op, (ast.GtE, ast.Gt, ast.Eq)) for op in ops):
                    if any(isinstance(s, ast.Break) for s in ast.walk(
                        ast.Module(body=stmt.body, type_ignores=[])
                    )):
                        return True
        return False


# ── Checker ───────────────────────────────────────────────────────────────────

class LLMChecker(FileChecker):
    """PROOFCTL-LLM-* — guardrails for code that integrates LLM APIs."""

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        if tree is None:
            return []

        out: list[Finding] = []
        for Visitor in (
            _LLM001Visitor,
            _LLM002Visitor,
            _LLM003Visitor,
            _LLM004Visitor,
            _LLM005Visitor,
        ):
            v = Visitor(path)
            v.visit(tree)
            out.extend(v.findings)
        return out
