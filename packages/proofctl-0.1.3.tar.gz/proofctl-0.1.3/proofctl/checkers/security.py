"""Security checker — rules PROOFCTL-S-*

AI models introduce these vulnerabilities at high rates (Veracode 2024: 2.7× higher
density than human-written code). All rules are AST-based for precision.

S-001  SQL injection — string interpolation/concatenation in .execute() calls
S-002  Command injection — subprocess/os.system with shell=True + variable arg
S-003  Unsafe deserialization — pickle.loads(), yaml.load() without SafeLoader
S-004  Weak cryptographic primitive — MD5, SHA1, or random module for secrets
S-005  eval() / exec() on non-literal input (arbitrary code execution)
S-006  Missing timeout on outbound HTTP requests (requests / httpx)
S-007  JWT algorithm confusion / signature bypass
S-008  Path traversal via user-supplied path to open()
S-009  Insecure UUID for security-sensitive values
S-010  Secret value leaked into logs
S-011  Insecure cipher mode via cryptography.hazmat
S-012  Regex injection (ReDoS)
S-013  Open redirect
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker

# ── constants ─────────────────────────────────────────────────────────────────

_SQL_EXECUTE_ATTRS = frozenset({
    "execute", "executemany", "executescript", "mogrify",
    "raw", "rawquery", "query",
})

_SUBPROCESS_FUNCS = frozenset({
    "call", "run", "Popen", "check_call", "check_output",
    "getoutput", "getstatusoutput",
})

_HTTP_METHODS = frozenset({
    "get", "post", "put", "patch", "delete", "head", "options", "request",
})

_HTTP_CLIENTS = frozenset({"requests", "httpx"})

# Variable/function names that suggest security-sensitive context
_SEC_NAME_RE = re.compile(
    r"\b(?:token|secret|key|password|passwd|pwd|nonce|salt|otp|pin|"
    r"credential|auth_code|api_key|access_key|session_id|csrf)\b",
    re.IGNORECASE,
)


# ── AST helpers ───────────────────────────────────────────────────────────────

def _is_literal(node: ast.expr) -> bool:
    return isinstance(node, ast.Constant)


def _is_interpolated(node: ast.expr) -> bool:
    """True if node is an f-string, .format() call, % operator, or + concat."""
    if isinstance(node, ast.JoinedStr):
        return any(not isinstance(v, ast.Constant) for v in node.values)
    if isinstance(node, ast.Call):
        if isinstance(node.func, ast.Attribute) and node.func.attr == "format":
            return True
    if isinstance(node, ast.BinOp):
        if isinstance(node.op, ast.Mod):
            return True
        if isinstance(node.op, ast.Add):
            return not (_is_literal(node.left) and _is_literal(node.right))
    return False


def _kwarg_is_true(call: ast.Call, name: str) -> bool:
    for kw in call.keywords:
        if kw.arg == name:
            return isinstance(kw.value, ast.Constant) and kw.value.value is True
    return False


def _has_kwarg(call: ast.Call, *names: str) -> bool:
    kw_names = {kw.arg for kw in call.keywords}
    return bool(kw_names & set(names))


def _attr_chain(node: ast.expr) -> list[str]:
    """['requests', 'get'] from requests.get(...)"""
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    return list(reversed(parts))


def _call_attr(call: ast.Call) -> str | None:
    """Return last attribute name of the call, e.g. 'execute'."""
    if isinstance(call.func, ast.Attribute):
        return call.func.attr
    if isinstance(call.func, ast.Name):
        return call.func.id
    return None


# ── Visitors ──────────────────────────────────────────────────────────────────

class _S001Visitor(ast.NodeVisitor):
    """SQL injection via string interpolation in .execute() calls."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        if _call_attr(node) in _SQL_EXECUTE_ATTRS and node.args:
            arg = node.args[0]
            if _is_interpolated(arg):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-001",
                    rule_name="SQL injection via string formatting",
                    severity=Severity.ERROR,
                    message=(
                        f"String interpolation in .{_call_attr(node)}() "
                        "call — SQL injection risk"
                    ),
                    hint="Use parameterised queries: cursor.execute(sql, (value,))",
                    authority="OWASP A03:2021 – Injection / CWE-89",
                ))
        self.generic_visit(node)


class _S002Visitor(ast.NodeVisitor):
    """Command injection: subprocess with shell=True + non-literal command."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        is_subprocess = (
            len(chain) == 2
            and chain[0] == "subprocess"
            and chain[1] in _SUBPROCESS_FUNCS
        )
        is_os_system = chain == ["os", "system"] or chain == ["os", "popen"]

        if is_subprocess and _kwarg_is_true(node, "shell"):
            cmd = node.args[0] if node.args else None
            if cmd is not None and not _is_literal(cmd):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-002",
                    rule_name="Command injection via shell=True",
                    severity=Severity.ERROR,
                    message=(
                        f"subprocess.{chain[1]}(..., shell=True) with a "
                        "non-literal command — shell injection risk"
                    ),
                    hint=(
                        "Pass a list of arguments without shell=True: "
                        "subprocess.run(['cmd', arg1, arg2])"
                    ),
                    authority="CWE-78 – OS Command Injection",
                ))

        if is_os_system and node.args and not _is_literal(node.args[0]):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-002",
                rule_name="Command injection via os.system",
                severity=Severity.ERROR,
                message=(
                    f"os.{chain[1]}() with a non-literal command — "
                    "shell injection risk"
                ),
                hint="Use subprocess.run(['cmd', arg]) with a list argument.",
                authority="CWE-78 – OS Command Injection",
            ))
        self.generic_visit(node)


class _S003Visitor(ast.NodeVisitor):
    """Unsafe deserialization: pickle.loads / yaml.load without SafeLoader."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)

        # pickle.loads / pickle.load / marshal.loads
        if len(chain) == 2 and chain[0] in ("pickle", "marshal", "_pickle") and chain[1] in ("loads", "load"):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-003",
                rule_name="Unsafe deserialization",
                severity=Severity.ERROR,
                message=(
                    f"{'.'.join(chain)}() deserialises arbitrary Python objects "
                    "— remote code execution if input is untrusted"
                ),
                hint="Use json.loads() or msgpack. Never deserialise untrusted pickle data.",
                authority="OWASP A08:2021 – Software and Data Integrity / CWE-502",
            ))

        # yaml.load() without Loader=SafeLoader
        if len(chain) == 2 and chain[0] == "yaml" and chain[1] == "load":
            safe_loader_names = {"SafeLoader", "CSafeLoader", "BaseLoader"}
            has_safe_loader = any(
                kw.arg == "Loader"
                and isinstance(kw.value, ast.Attribute)
                and kw.value.attr in safe_loader_names
                or kw.arg == "Loader"
                and isinstance(kw.value, ast.Name)
                and kw.value.id in safe_loader_names
                for kw in node.keywords
            )
            if not has_safe_loader:
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-003",
                    rule_name="Unsafe YAML deserialization",
                    severity=Severity.ERROR,
                    message="yaml.load() without Loader=yaml.SafeLoader can execute arbitrary Python",
                    hint="Use yaml.safe_load(data) or yaml.load(data, Loader=yaml.SafeLoader).",
                    authority="CWE-502 – Deserialization of Untrusted Data",
                ))

        self.generic_visit(node)


class _S004Visitor(ast.NodeVisitor):
    """Weak crypto: MD5/SHA1 via hashlib; random module for security-sensitive values."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []
        # Accumulate (assign_target_name, Call_node) pairs for random context check
        self._pending_random: list[tuple[str | None, ast.Call]] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)

        # hashlib.md5() / hashlib.sha1() / hashlib.new("md5")
        if len(chain) == 2 and chain[0] == "hashlib":
            if chain[1] == "md5":
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-004",
                    rule_name="Weak hash algorithm: MD5",
                    severity=Severity.ERROR,
                    message="hashlib.md5() is cryptographically broken",
                    hint="Use hashlib.sha256() or hashlib.sha3_256() for integrity; use bcrypt/argon2 for passwords.",
                    authority="NIST SP 800-131A / CWE-327",
                ))
            elif chain[1] == "sha1":
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-004",
                    rule_name="Weak hash algorithm: SHA-1",
                    severity=Severity.WARNING,
                    message="hashlib.sha1() is deprecated for security use",
                    hint="Upgrade to SHA-256 or SHA-3. SHA-1 is collision-vulnerable (SHAttered attack).",
                    authority="NIST SP 800-131A / CWE-327",
                ))
            elif chain[1] == "new" and node.args:
                algo = node.args[0]
                if isinstance(algo, ast.Constant) and str(algo.value).lower() in ("md5", "sha1", "sha-1"):
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=node.lineno,
                        col=node.col_offset,
                        rule_id="PROOFCTL-S-004",
                        rule_name=f"Weak hash algorithm: {algo.value}",
                        severity=Severity.ERROR,
                        message=f'hashlib.new("{algo.value}") uses a weak algorithm',
                        hint="Use hashlib.new('sha256') or stronger.",
                        authority="CWE-327",
                    ))

        # random.choice/randint/random()/randbytes/token_* — flag for security-sensitive names
        _RANDOM_FUNCS = frozenset({"choice", "randint", "random", "randbytes", "sample", "randrange", "shuffle"})
        if len(chain) == 2 and chain[0] == "random" and chain[1] in _RANDOM_FUNCS:
            self._pending_random.append((None, node))

        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        # Check if a random.* call is being assigned to a security-sensitive name
        self.generic_visit(node)
        # Walk the value to find pending random calls
        for t in node.targets:
            target_name = t.id if isinstance(t, ast.Name) else ""
            if _SEC_NAME_RE.search(target_name):
                for val_node in ast.walk(node.value):
                    if isinstance(val_node, ast.Call):
                        chain = _attr_chain(val_node.func)
                        _RANDOM_FUNCS = frozenset({"choice", "randint", "random", "randbytes", "sample", "randrange"})
                        if len(chain) == 2 and chain[0] == "random" and chain[1] in _RANDOM_FUNCS:
                            self.findings.append(Finding(
                                file=str(self.path),
                                line=val_node.lineno,
                                col=val_node.col_offset,
                                rule_id="PROOFCTL-S-004",
                                rule_name="Insecure random for security value",
                                severity=Severity.ERROR,
                                message=(
                                    f"random.{chain[1]}() used to generate "
                                    f'"{target_name}" — not cryptographically secure'
                                ),
                                hint="Use the secrets module: secrets.token_hex(), secrets.token_urlsafe().",
                                authority="CWE-338 – Use of Cryptographically Weak PRNG",
                            ))


class _S005Visitor(ast.NodeVisitor):
    """eval() / exec() on non-literal input."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        name = node.func.id if isinstance(node.func, ast.Name) else None
        if name in ("eval", "exec", "compile") and node.args:
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-005",
                rule_name="Code execution from dynamic input",
                severity=Severity.ERROR,
                message=f"{name}() executes arbitrary code — avoid entirely",
                hint="Avoid eval/exec entirely. Use ast.literal_eval() for safe data parsing.",
                authority="CWE-94 – Code Injection / OWASP A03:2021",
            ))
        self.generic_visit(node)


class _S006Visitor(ast.NodeVisitor):
    """Missing timeout on requests / httpx HTTP calls."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        if (
            len(chain) == 2
            and chain[0] in _HTTP_CLIENTS
            and chain[1] in _HTTP_METHODS
            and not _has_kwarg(node, "timeout")
        ):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-006",
                rule_name="HTTP request without timeout",
                severity=Severity.WARNING,
                message=(
                    f"{chain[0]}.{chain[1]}() has no timeout — hangs "
                    "forever if the remote server stalls"
                ),
                hint="Add timeout=: requests.get(url, timeout=30)",
                authority="Release It! – Stability Patterns / CWE-400",
            ))
        self.generic_visit(node)


class _S007Visitor(ast.NodeVisitor):
    """JWT algorithm confusion / signature bypass."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        # Match jwt.decode(...) or jose.jwt.decode(...)
        is_jwt_decode = (
            (len(chain) == 2 and chain[0] == "jwt" and chain[1] == "decode")
            or (len(chain) == 3 and chain[0] == "jose" and chain[1] == "jwt" and chain[2] == "decode")
            or (len(chain) == 1 and chain[0] == "decode")  # from jwt import decode
        )
        if is_jwt_decode:
            for kw in node.keywords:
                # Check options={"verify_signature": False} or {"verify_exp": False}
                if kw.arg == "options" and isinstance(kw.value, ast.Dict):
                    for k, v in zip(kw.value.keys, kw.value.values):
                        if (
                            isinstance(k, ast.Constant)
                            and k.value in ("verify_signature", "verify_exp")
                            and isinstance(v, ast.Constant)
                            and v.value is False
                        ):
                            detail = f'options={{"{k.value}": False}}'
                            self.findings.append(Finding(
                                file=str(self.path),
                                line=node.lineno,
                                col=node.col_offset,
                                rule_id="PROOFCTL-S-007",
                                rule_name="JWT signature verification bypass",
                                severity=Severity.ERROR,
                                message=f"jwt.decode() with {detail} — signature verification bypassed",
                                hint="Never disable JWT signature verification. Use algorithms=['HS256'] with a verified secret.",
                                authority="OWASP A02:2021 – Cryptographic Failures / CWE-347",
                            ))
                # Check algorithms=[..., "none", ...]
                if kw.arg == "algorithms" and isinstance(kw.value, ast.List):
                    has_none = any(
                        isinstance(elt, ast.Constant) and str(elt.value).lower() == "none"
                        for elt in kw.value.elts
                    )
                    if has_none:
                        detail = 'algorithms=[..., "none", ...]'
                        self.findings.append(Finding(
                            file=str(self.path),
                            line=node.lineno,
                            col=node.col_offset,
                            rule_id="PROOFCTL-S-007",
                            rule_name="JWT signature verification bypass",
                            severity=Severity.ERROR,
                            message=f"jwt.decode() with {detail} — signature verification bypassed",
                            hint="Never disable JWT signature verification. Use algorithms=['HS256'] with a verified secret.",
                            authority="OWASP A02:2021 – Cryptographic Failures / CWE-347",
                        ))
        self.generic_visit(node)


class _S008Visitor(ast.NodeVisitor):
    """Path traversal via user-supplied path to open()."""

    _REQUEST_ATTRS = frozenset({"args", "form", "json", "GET", "POST", "data"})
    _REQUEST_GET_ATTRS = frozenset({"args", "form", "GET", "POST"})

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _is_request_tainted(self, node: ast.expr) -> bool:
        """Return True if node looks like user-controlled request data."""
        # request.args.get("file") / request.form.get("file") etc.
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "get":
                obj = node.func.value
                if (
                    isinstance(obj, ast.Attribute)
                    and obj.attr in self._REQUEST_GET_ATTRS
                    and isinstance(obj.value, ast.Name)
                    and obj.value.id == "request"
                ):
                    return True
        # request.args["filename"] / request.form["filename"] etc.
        if isinstance(node, ast.Subscript):
            obj = node.value
            if (
                isinstance(obj, ast.Attribute)
                and obj.attr in self._REQUEST_ATTRS
                and isinstance(obj.value, ast.Name)
                and obj.value.id == "request"
            ):
                return True
        return False

    def _is_path_param(self, node: ast.expr) -> bool:
        """Return True if node is a bare Name matching common path parameter names."""
        _PATH_NAMES = re.compile(r"\b(?:path|filename|file_path|filepath)\b", re.IGNORECASE)
        if isinstance(node, ast.Name) and _PATH_NAMES.search(node.id):
            return True
        return False

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        if chain == ["open"] or (len(chain) == 1 and chain[0] == "open"):
            if node.args:
                arg0 = node.args[0]
                if self._is_request_tainted(arg0):
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=node.lineno,
                        col=node.col_offset,
                        rule_id="PROOFCTL-S-008",
                        rule_name="Path traversal via request data",
                        severity=Severity.ERROR,
                        message="open() called with a path from request data — path traversal risk",
                        hint=(
                            "Validate and sanitise file paths: use os.path.basename(), "
                            "pathlib.Path(...).resolve(), or restrict to an allowed directory."
                        ),
                        authority="OWASP A01:2021 – Broken Access Control / CWE-22",
                    ))
                elif self._is_path_param(arg0):
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=node.lineno,
                        col=node.col_offset,
                        rule_id="PROOFCTL-S-008",
                        rule_name="Path traversal via path parameter",
                        severity=Severity.ERROR,
                        message="open() called with a path from request data — path traversal risk",
                        hint=(
                            "Validate and sanitise file paths: use os.path.basename(), "
                            "pathlib.Path(...).resolve(), or restrict to an allowed directory."
                        ),
                        authority="OWASP A01:2021 – Broken Access Control / CWE-22",
                    ))
        self.generic_visit(node)


class _S009Visitor(ast.NodeVisitor):
    """Insecure UUID for security-sensitive values."""

    _INSECURE_UUID_FUNCS = frozenset({"uuid1", "uuid3"})

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _flag(self, node: ast.Call, func_name: str, target_name: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-S-009",
            rule_name="Insecure UUID for security-sensitive value",
            severity=Severity.ERROR,
            message=(
                f"uuid.{func_name}() used for '{target_name}' — "
                "uuid1 is time-based (guessable), uuid3 is MD5-based"
            ),
            hint="Use uuid.uuid4() or secrets.token_hex() for security-sensitive identifiers.",
            authority="CWE-338 – Use of Cryptographically Weak PRNG",
        ))

    def visit_Assign(self, node: ast.Assign) -> None:
        for t in node.targets:
            target_name = t.id if isinstance(t, ast.Name) else ""
            if not _SEC_NAME_RE.search(target_name):
                continue
            for val_node in ast.walk(node.value):
                if not isinstance(val_node, ast.Call):
                    continue
                chain = _attr_chain(val_node.func)
                # uuid.uuid1() / uuid.uuid3(...)
                if len(chain) == 2 and chain[0] == "uuid" and chain[1] in self._INSECURE_UUID_FUNCS:
                    self._flag(val_node, chain[1], target_name)
                # from uuid import uuid1 — bare call
                elif len(chain) == 1 and chain[0] in self._INSECURE_UUID_FUNCS:
                    self._flag(val_node, chain[0], target_name)
        self.generic_visit(node)


class _S010Visitor(ast.NodeVisitor):
    """Secret value leaked into logs."""

    _LOG_ATTRS = frozenset({
        "debug", "info", "warning", "warn", "error", "critical", "exception", "log",
    })
    # Looser pattern for env var names like SECRET_KEY, API_TOKEN (no \b needed)
    _ENV_VAR_SECRET_RE = re.compile(
        r"(?i)(password|passwd|secret|token|credential|private|api.key|auth.token|access.key)",
    )

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _flag(self, node: ast.Call, name: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-S-010",
            rule_name="Secret leaked into log",
            severity=Severity.WARNING,
            message=f"Logging call may expose secret '{name}' — visible in log aggregators and monitoring",
            hint="Never log credential values. Log only non-sensitive metadata.",
            authority="OWASP A09:2021 – Security Logging and Monitoring Failures / CWE-532",
        ))

    def _is_logging_call(self, node: ast.Call) -> bool:
        chain = _attr_chain(node.func)
        if not chain:
            return False
        return chain[-1] in self._LOG_ATTRS

    def _fstring_has_secret(self, node: ast.JoinedStr) -> str | None:
        """Return the first secret name found inside the f-string, or None."""
        for value in ast.walk(node):
            if isinstance(value, ast.Name) and _SEC_NAME_RE.search(value.id):
                return value.id
            if isinstance(value, ast.Attribute) and _SEC_NAME_RE.search(value.attr):
                return value.attr
        return None

    def _is_os_environ(self, node: ast.expr) -> bool:
        chain = _attr_chain(node)
        return chain == ["os", "environ"]

    def _is_os_getenv_secret(self, node: ast.expr) -> str | None:
        """Return key name if node is os.getenv('SECRET_*') with a secret key."""
        if not isinstance(node, ast.Call):
            return None
        chain = _attr_chain(node.func)
        if chain not in (["os", "getenv"], ["os", "environ", "get"]):
            return None
        if node.args and isinstance(node.args[0], ast.Constant):
            key = str(node.args[0].value)
            if _SEC_NAME_RE.search(key) or self._ENV_VAR_SECRET_RE.search(key):
                return key
        return None

    def visit_Call(self, node: ast.Call) -> None:
        if not self._is_logging_call(node):
            self.generic_visit(node)
            return

        all_args = list(node.args) + [kw.value for kw in node.keywords if kw.arg is None]

        for arg in all_args:
            # f-string containing a secret variable
            if isinstance(arg, ast.JoinedStr):
                name = self._fstring_has_secret(arg)
                if name:
                    self._flag(node, name)
                    break
            # os.environ passed directly
            if self._is_os_environ(arg):
                self._flag(node, "os.environ")
                break
            # os.getenv("SECRET_KEY") or os.environ.get("SECRET_KEY")
            key = self._is_os_getenv_secret(arg)
            if key:
                self._flag(node, key)
                break
            # bare Name or Attribute matching a secret name
            if isinstance(arg, ast.Name) and _SEC_NAME_RE.search(arg.id):
                self._flag(node, arg.id)
                break
            if isinstance(arg, ast.Attribute) and _SEC_NAME_RE.search(arg.attr):
                self._flag(node, arg.attr)
                break

        self.generic_visit(node)


class _S011Visitor(ast.NodeVisitor):
    """Insecure cipher mode via cryptography.hazmat."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        if not chain:
            self.generic_visit(node)
            return
        last = chain[-1]

        if last == "ECB":
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-011",
                rule_name="Insecure cipher mode: ECB",
                severity=Severity.ERROR,
                message="ECB mode is deterministic — identical plaintext blocks produce identical ciphertext",
                hint="Use AES-256-GCM: from cryptography.hazmat.primitives.ciphers.aead import AESGCM",
                authority="NIST SP 800-131A / CWE-327",
            ))
        elif last == "ARC4":
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-011",
                rule_name="Insecure cipher: RC4 (ARC4)",
                severity=Severity.ERROR,
                message="RC4 (ARC4) is broken — do not use for any security purpose",
                hint="Use AES-256-GCM: from cryptography.hazmat.primitives.ciphers.aead import AESGCM",
                authority="NIST SP 800-131A / CWE-327",
            ))
        elif last in ("TripleDES", "3DES"):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-011",
                rule_name="Deprecated cipher: 3DES/TripleDES",
                severity=Severity.WARNING,
                message="3DES/TripleDES is deprecated (NIST 2023)",
                hint="Use AES-256-GCM: from cryptography.hazmat.primitives.ciphers.aead import AESGCM",
                authority="NIST SP 800-131A / CWE-327",
            ))

        self.generic_visit(node)


class _S012Visitor(ast.NodeVisitor):
    """Regex injection / ReDoS — non-literal pattern passed to re functions."""

    _RE_FUNCS = frozenset({"compile", "match", "search", "fullmatch", "findall", "sub", "subn"})

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        if len(chain) == 2 and chain[0] == "re" and chain[1] in self._RE_FUNCS:
            if node.args and not isinstance(node.args[0], ast.Constant):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-012",
                    rule_name="Regex injection / ReDoS",
                    severity=Severity.WARNING,
                    message=(
                        f"re.{chain[1]}() called with a non-literal pattern — "
                        "regex injection / ReDoS risk if pattern is user-supplied"
                    ),
                    hint="Validate or sanitise user-supplied regex patterns. Consider re.escape() for literal matching.",
                    authority="CWE-1333 – Inefficient Regular Expression Complexity",
                ))
        self.generic_visit(node)


class _S013Visitor(ast.NodeVisitor):
    """Open redirect via unvalidated URL from user input."""

    _REDIRECT_FUNCS = frozenset({"redirect", "HttpResponseRedirect"})
    _REQUEST_GET_ATTRS = frozenset({"args", "form", "GET", "POST"})
    _UNSAFE_NAMES = re.compile(
        r"(?i)\b(next|redirect_url|return_url|next_url|callback_url)\b"
    )

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _is_request_url(self, node: ast.expr) -> bool:
        """True if node is request.args.get(...), request.GET.get(...) etc."""
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "get":
                obj = node.func.value
                if (
                    isinstance(obj, ast.Attribute)
                    and obj.attr in self._REQUEST_GET_ATTRS
                    and isinstance(obj.value, ast.Name)
                    and obj.value.id == "request"
                ):
                    return True
        return False

    def _is_unsafe_name(self, node: ast.expr) -> bool:
        return isinstance(node, ast.Name) and bool(self._UNSAFE_NAMES.search(node.id))

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        func_name = chain[-1] if chain else None
        if func_name in self._REDIRECT_FUNCS and node.args:
            arg0 = node.args[0]
            if self._is_request_url(arg0) or self._is_unsafe_name(arg0):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-013",
                    rule_name="Open redirect",
                    severity=Severity.WARNING,
                    message="redirect() called with an unvalidated URL from user input — open redirect risk",
                    hint="Validate redirect URLs against an allowlist of trusted domains before redirecting.",
                    authority="OWASP A01:2021 – Broken Access Control / CWE-601",
                ))
        self.generic_visit(node)


# ── Checker ───────────────────────────────────────────────────────────────────

class SecurityChecker(FileChecker):
    """PROOFCTL-S-* — security vulnerabilities AI models introduce at high rates."""

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        if tree is None:
            return []

        out: list[Finding] = []
        for Visitor in (
            _S001Visitor,
            _S002Visitor,
            _S003Visitor,
            _S004Visitor,
            _S005Visitor,
            _S006Visitor,
            _S007Visitor,
            _S008Visitor,
            _S009Visitor,
            _S010Visitor,
            _S011Visitor,
            _S012Visitor,
            _S013Visitor,
        ):
            v = Visitor(path)
            v.visit(tree)
            out.extend(v.findings)
        return out
