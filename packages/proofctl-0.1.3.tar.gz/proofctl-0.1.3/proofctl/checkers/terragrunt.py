"""Terragrunt checker — rules PROOFCTL-TG-*

Runs on *.hcl files (terragrunt.hcl, common.hcl, etc.).

Rule groups
-----------
TG-001  var.* / path.module in terragrunt.hcl (valid Terraform, broken in Terragrunt)
TG-002  dependency block without mock_outputs (breaks plan in CI)
TG-003  Invalid if_exists value in generate block
TG-004  remote_state backend config missing encrypt = true
TG-005  Conflicting remote_state + generate "backend" in same file
TG-006  mock_outputs present but mock_outputs_allowed_terraform_commands absent
"""
from __future__ import annotations

import re
from pathlib import Path

from ..models import Finding, Severity
from .base import HclFileChecker
from .hcl_utils import HclBlock, parse_blocks

_VALID_IF_EXISTS = frozenset({"overwrite", "overwrite_terragrunt", "skip", "error"})


class TerragruntChecker(HclFileChecker):
    extensions = (".hcl",)

    def check(self, path: Path, source: str) -> list[Finding]:
        blocks = parse_blocks(source)
        lines = source.splitlines()
        out: list[Finding] = []

        out += self._tg001(path, lines)
        out += self._tg002(path, blocks)
        out += self._tg003(path, blocks)
        out += self._tg004(path, blocks)
        out += self._tg005(path, blocks)
        out += self._tg006(path, blocks)

        return out

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _f(
        path: Path,
        line: int | None,
        rule_id: str,
        rule_name: str,
        severity: Severity,
        message: str,
        hint: str = "",
    ) -> Finding:
        return Finding(
            file=str(path), line=line, col=None,
            rule_id=rule_id, rule_name=rule_name,
            severity=severity, message=message, hint=hint,
        )

    # ════════════════════════════════════════════════════════════════════════
    # TG-001 — var.* / path.module in terragrunt.hcl
    # ════════════════════════════════════════════════════════════════════════

    def _tg001(self, path: Path, lines: list[str]) -> list[Finding]:
        """TG-001 — Terraform-only expressions used in Terragrunt HCL (outside heredocs)."""
        pat = re.compile(r'\b(var\.[a-zA-Z_]\w*|path\.module)\b')
        heredoc_re = re.compile(r'<<[-~]?(\w+)\s*$')
        out = []
        heredoc_end: str | None = None

        for i, line in enumerate(lines, start=1):
            stripped = line.strip()

            # Track heredoc boundaries — content inside heredocs is Terraform template code
            if heredoc_end:
                if stripped == heredoc_end or stripped.rstrip("-~") == heredoc_end:
                    heredoc_end = None
                continue
            hm = heredoc_re.search(line)
            if hm:
                heredoc_end = hm.group(1)
                continue

            if stripped.startswith("#"):
                continue
            m = pat.search(line)
            if m:
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TG-001", "Terraform expression in Terragrunt file",
                    Severity.ERROR,
                    f'"{m.group(1)}" is a Terraform expression — silently broken in Terragrunt HCL',
                    hint="Use local.X, dependency.X, include.X.locals.X, or get_env() instead of var.* / path.module.",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # TG-002 — dependency block without mock_outputs
    # ════════════════════════════════════════════════════════════════════════

    def _tg002(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """TG-002 — dependency block missing mock_outputs → plan breaks in CI."""
        out = []
        for b in blocks:
            if b.kind != "dependency":
                continue
            has_mock = b.has_attr("mock_outputs") or b.has_nested("mock_outputs")
            if not has_mock:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TG-002", "Dependency missing mock_outputs",
                    Severity.ERROR,
                    f'dependency "{b.label1}" has no mock_outputs block — terragrunt plan will fail in CI',
                    hint="Add mock_outputs {} with representative values for each output used by this module.",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # TG-003 — Invalid if_exists in generate block
    # ════════════════════════════════════════════════════════════════════════

    def _tg003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """TG-003 — generate block with invalid if_exists value."""
        out = []
        for b in blocks:
            if b.kind != "generate":
                continue
            val = b.attr_value("if_exists")
            if val is None:
                continue
            val_clean = val.strip('"')
            if val_clean not in _VALID_IF_EXISTS:
                out.append(self._f(
                    path, b.attr_line("if_exists") or b.start_line,
                    "PROOFCTL-TG-003", "Invalid generate if_exists value",
                    Severity.ERROR,
                    f'generate "{b.label1}" has if_exists = "{val_clean}" — not a valid Terragrunt value',
                    hint=f'Valid values: {", ".join(sorted(_VALID_IF_EXISTS))}',
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # TG-004 — remote_state backend missing encrypt = true
    # ════════════════════════════════════════════════════════════════════════

    def _tg004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """TG-004 — remote_state block without encrypt = true in its config."""
        out = []
        for b in blocks:
            if b.kind != "remote_state":
                continue
            backend = (b.attr_value("backend") or "").strip('"')
            if backend not in ("s3", "gcs"):
                continue
            if not b.contains(r'encrypt\s*=\s*true'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TG-004", "remote_state backend not encrypted",
                    Severity.ERROR,
                    f'remote_state uses "{backend}" backend without encrypt = true',
                    hint='Add encrypt = true inside the config block to encrypt Terraform state at rest.',
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # TG-005 — Conflicting remote_state + generate "backend"
    # ════════════════════════════════════════════════════════════════════════

    def _tg005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """TG-005 — Both remote_state and generate "backend" present in the same file."""
        has_remote_state = any(b.kind == "remote_state" for b in blocks)
        generate_backend = next(
            (b for b in blocks if b.kind == "generate" and b.label1 == "backend"), None
        )
        if has_remote_state and generate_backend:
            return [self._f(
                path, generate_backend.start_line,
                "PROOFCTL-TG-005", "Conflicting backend configuration",
                Severity.ERROR,
                'Both remote_state and generate "backend" present — backend config will be written twice',
                hint='Use remote_state OR generate "backend", not both.',
            )]
        return []

    # ════════════════════════════════════════════════════════════════════════
    # TG-006 — mock_outputs without mock_outputs_allowed_terraform_commands
    # ════════════════════════════════════════════════════════════════════════

    def _tg006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """TG-006 — mock_outputs present but mock_outputs_allowed_terraform_commands absent."""
        out = []
        for b in blocks:
            if b.kind != "dependency":
                continue
            has_mock = b.has_attr("mock_outputs") or b.has_nested("mock_outputs")
            has_commands = b.has_attr("mock_outputs_allowed_terraform_commands")
            if has_mock and not has_commands:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TG-006", "mock_outputs without allowed commands",
                    Severity.WARNING,
                    f'dependency "{b.label1}" has mock_outputs but no mock_outputs_allowed_terraform_commands',
                    hint='Add mock_outputs_allowed_terraform_commands = ["validate", "plan"].',
                ))
        return out
