"""Terraform / HCL checker — rules PROOFCTL-TF-* and PROOFCTL-TF-G* / PROOFCTL-TF-A*.

Rule groups
-----------
T-xxx  General Terraform antipatterns (AI slop)
G-xxx  GCP-specific security misconfigurations
A-xxx  AWS-specific security misconfigurations
M-xxx  Terraform mechanics / silent failure patterns
V-xxx  Lifecycle antipatterns
"""
from __future__ import annotations

import re
from pathlib import Path

from ..models import Finding, Severity
from .base import HclFileChecker, HclDirChecker
from .hcl_utils import HclBlock, parse_blocks

# ── Shared constants ──────────────────────────────────────────────────────────

_PROD_RE = re.compile(r'prod(?:uction)?', re.IGNORECASE)

_STATEFUL_RESOURCES = frozenset({
    # AWS
    "aws_db_instance", "aws_rds_cluster", "aws_rds_cluster_instance",
    "aws_s3_bucket", "aws_dynamodb_table", "aws_elasticsearch_domain",
    "aws_opensearch_domain", "aws_elasticache_cluster", "aws_elasticache_replication_group",
    # GCP
    "google_sql_database_instance", "google_storage_bucket",
    "google_container_cluster", "google_spanner_instance",
    "google_bigtable_instance", "google_filestore_instance",
    "google_kms_crypto_key",
})

_FIREWALL_RESOURCES = frozenset({
    "aws_security_group", "aws_security_group_rule",
    "aws_network_acl", "aws_network_acl_rule",
    "google_compute_firewall",
})

# Ports that should never accept 0.0.0.0/0
_SENSITIVE_PORTS = frozenset({22, 23, 25, 3306, 3389, 5432, 5439, 6379, 27017})

_SECRET_ATTR_PAT = re.compile(
    r'^\s*(?:password|secret|private_key|api_key|access_key|secret_key|'
    r'auth_token|token|service_account_key|credentials|passphrase|'
    r'client_secret|encryption_key|private_key_pem|certificate_body)\s*=\s*'
    r'"([^"$\{][^"]{5,})"',   # ≥6 chars, not starting with ${ (not a reference)
    re.IGNORECASE,
)

_BROAD_GCP_ROLES = frozenset({
    "roles/owner",
    "roles/editor",
    "roles/iam.securityAdmin",
    "roles/resourcemanager.projectIamAdmin",
    "roles/iam.serviceAccountAdmin",
})

_GCP_IAM_RESOURCES = frozenset({
    "google_project_iam_binding",
    "google_project_iam_member",
    "google_folder_iam_binding",
    "google_folder_iam_member",
    "google_organization_iam_binding",
    "google_organization_iam_member",
})

_GIT_SHA_RE = re.compile(r'^[0-9a-f]{40}$')
_SEMVER_TAG_RE = re.compile(r'^v?\d+\.\d+')

# ── Terraform file checker ────────────────────────────────────────────────────


class TerraformChecker(HclFileChecker):
    extensions = (".tf", ".tfvars")

    def __init__(self, required_labels: list[str] | None = None) -> None:
        self._required_labels = required_labels or []

    def check(self, path: Path, source: str) -> list[Finding]:
        if path.suffix == ".tfvars":
            return self._scan_secrets_only(path, source.splitlines())

        blocks = parse_blocks(source)
        lines = source.splitlines()
        out: list[Finding] = []

        # Group T — general Terraform
        out += self._t001(path, blocks)
        out += self._t002(path, lines)
        out += self._t003(path, blocks)
        out += self._t004(path, blocks, lines)
        out += self._t005(path, lines)
        out += self._t006(path, lines)
        out += self._t009(path, blocks)
        out += self._t012(path, blocks)
        if self._required_labels:
            out += self._t013(path, blocks)

        # Group M — mechanics
        out += self._m002(path, lines)
        out += self._m003(path, lines)
        out += self._m004(path, blocks)
        out += self._m005(path, blocks)
        out += self._m006(path, blocks)
        out += self._m007(path, blocks)

        # Group V — lifecycle
        out += self._v001(path, blocks)
        out += self._v003(path, blocks)
        out += self._v004(path, blocks)

        # Group G — GCP
        out += self._g001(path, blocks)
        out += self._g002(path, blocks)
        out += self._g003(path, blocks)
        out += self._g004(path, blocks)
        out += self._g005(path, blocks)
        out += self._g006(path, blocks)
        out += self._g007(path, blocks)
        out += self._g008(path, blocks)
        out += self._g009(path, blocks)
        out += self._g010(path, blocks)
        out += self._g011(path, blocks)
        out += self._g012(path, blocks)
        out += self._g013(path, blocks)
        out += self._g014(path, blocks)
        out += self._g015(path, blocks)
        out += self._g016(path, blocks)
        out += self._g017(path, blocks)
        out += self._g018(path, blocks)
        out += self._g019(path, blocks)
        out += self._g020(path, blocks)
        out += self._g021(path, blocks)
        out += self._g023(path, blocks)
        out += self._g024(path, blocks)
        out += self._g025(path, blocks)

        # Group A — AWS
        out += self._a001(path, blocks)
        out += self._a003(path, blocks)
        out += self._a004(path, blocks)
        out += self._a005(path, blocks)
        out += self._a006(path, blocks)
        out += self._a007(path, blocks)
        out += self._a008(path, blocks)
        out += self._a009(path, blocks)
        out += self._a010(path, blocks)
        out += self._a011(path, blocks)
        out += self._a012(path, blocks)
        out += self._a013(path, blocks)
        out += self._a014(path, blocks)

        # Group G — GCP (extended)
        out += self._g026(path, blocks)
        out += self._g027(path, blocks)
        out += self._g028(path, blocks)
        out += self._g029(path, blocks)
        out += self._g030(path, blocks)
        out += self._g031(path, blocks)

        # Group AZ — Azure
        out += self._az001(path, blocks)
        out += self._az002(path, blocks)
        out += self._az003(path, blocks)
        out += self._az004(path, blocks)
        out += self._az005(path, blocks)
        out += self._az006(path, blocks)
        out += self._az007(path, blocks)
        out += self._az008(path, blocks)
        out += self._az009(path, blocks)
        out += self._az010(path, blocks)
        out += self._az011(path, blocks)
        out += self._az012(path, blocks)

        # Group T — General (extended)
        out += self._t014(path, blocks)
        out += self._t015(path, blocks)

        return out

    # ── helpers ───────────────────────────────────────────────────────────────

    def _f(
        self,
        path: Path,
        line: int | None,
        rule_id: str,
        rule_name: str,
        severity: Severity,
        message: str,
        hint: str = "",
        authority: str = "",
    ) -> Finding:
        return Finding(
            file=str(path), line=line, col=None,
            rule_id=rule_id, rule_name=rule_name,
            severity=severity, message=message,
            hint=hint, authority=authority,
        )

    def _scan_secrets_only(self, path: Path, lines: list[str]) -> list[Finding]:
        return self._t005(path, lines)

    @staticmethod
    def _has_lifecycle_attr(block: HclBlock, attr: str) -> bool:
        """True if the block contains lifecycle { <attr> = true }."""
        lc_re = re.compile(r'lifecycle\s*\{')
        attr_re = re.compile(rf'{re.escape(attr)}\s*=\s*true')
        in_lifecycle = False
        depth = 0
        for line in block.raw_lines:
            if not in_lifecycle and lc_re.search(line):
                in_lifecycle = True
                depth = 1
                if attr_re.search(line):
                    return True
                continue
            if in_lifecycle:
                depth += line.count('{') - line.count('}')
                if attr_re.search(line):
                    return True
                if depth <= 0:
                    in_lifecycle = False
        return False

    # ════════════════════════════════════════════════════════════════════════
    # Group T — General Terraform
    # ════════════════════════════════════════════════════════════════════════

    def _t001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-001 — Empty resource block."""
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            inner = b.raw_lines[1:-1] if len(b.raw_lines) > 2 else []
            content = [l for l in inner if l.strip() and not l.strip().startswith("#")]
            if not content:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-T001", "Empty resource block",
                    Severity.ERROR,
                    f'resource "{b.label1}" "{b.label2}" has no attributes',
                    hint="Configure the resource — an empty block silently creates it with provider defaults.",
                ))
        return out

    def _t002(self, path: Path, lines: list[str]) -> list[Finding]:
        """T-002 — Useless string interpolation: "${var.x}" → var.x (simple refs only)."""
        # Only flag pure attribute/variable paths — not expressions with operators/function calls.
        # Pattern: "= "${word.word[optional_index]…}"" with no operators inside.
        pat = re.compile(r'=\s*"\$\{([\w]+(?:\.[\w]+)+(?:\[[\w."]+\])?)\}"')
        out = []
        for i, line in enumerate(lines, start=1):
            if line.strip().startswith("#"):
                continue
            m = pat.search(line)
            if m:
                expr = m.group(1)
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TF-T002", "Unnecessary string interpolation",
                    Severity.WARNING,
                    f'Wrap unnecessary: "${{{expr}}}" → {expr}',
                    hint=f'Use direct reference: = {expr} instead of = "${{{expr}}}".',
                ))
        return out

    def _t003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-003 — required_providers block missing version constraints."""
        out = []
        for b in blocks:
            if b.kind != "terraform":
                continue
            rp_re = re.compile(r'required_providers\s*\{')
            in_rp = False
            depth = 0
            rp_start = None
            rp_lines: list[str] = []
            for i, line in enumerate(b.raw_lines):
                if not in_rp and rp_re.search(line):
                    in_rp = True
                    depth = 1
                    rp_start = b.start_line + i
                    rp_lines = [line]
                    continue
                if in_rp:
                    rp_lines.append(line)
                    depth += line.count('{') - line.count('}')
                    if depth <= 0:
                        break
            if not rp_lines:
                continue
            # Check each provider object within required_providers
            prov_obj_re = re.compile(r'^\s*\w+\s*=\s*\{')
            version_re = re.compile(r'version\s*=')
            # Walk rp_lines and find provider blocks, check each for version
            j = 0
            while j < len(rp_lines):
                if prov_obj_re.match(rp_lines[j]):
                    # find end of this provider object
                    pdepth = 1
                    pname = rp_lines[j].split('=')[0].strip()
                    has_ver = False
                    k = j + 1
                    while k < len(rp_lines) and pdepth > 0:
                        pdepth += rp_lines[k].count('{') - rp_lines[k].count('}')
                        if version_re.search(rp_lines[k]):
                            has_ver = True
                        k += 1
                    if not has_ver:
                        out.append(self._f(
                            path, rp_start + j if rp_start else b.start_line,
                            "PROOFCTL-TF-T003", "Missing provider version constraint",
                            Severity.ERROR,
                            f'Provider "{pname}" in required_providers has no version pin',
                            hint='Add version = "~> 5.0" to prevent silent provider upgrades.',
                        ))
                    j = k
                else:
                    j += 1
        return out

    def _t004(self, path: Path, blocks: list[HclBlock], lines: list[str]) -> list[Finding]:
        """T-004 — Open ingress on sensitive ports (0.0.0.0/0)."""
        out = []
        any_cidr = re.compile(r'(?:cidr_blocks|cidr_ranges|source_ranges)\s*=\s*\[.*"0\.0\.0\.0/0"')
        port_re = re.compile(r'(?:from_port|to_port|port)\s*=\s*(\d+)')
        all_traffic_re = re.compile(r'(?:protocol|ip_protocol)\s*=\s*"-1"|all\s*=\s*true')

        for b in blocks:
            if b.kind != "resource" or b.label1 not in _FIREWALL_RESOURCES:
                continue
            if not b.contains(r'0\.0\.0\.0/0'):
                continue
            # Check if sensitive ports are involved
            ports: set[int] = set()
            for line in b.raw_lines:
                pm = port_re.search(line)
                if pm:
                    try:
                        ports.add(int(pm.group(1)))
                    except ValueError:
                        pass

            if all_traffic_re.search('\n'.join(b.raw_lines)):
                # -1 or all traffic — always sensitive
                flagged_ports = "all traffic"
            elif ports & _SENSITIVE_PORTS:
                flagged_ports = ', '.join(str(p) for p in sorted(ports & _SENSITIVE_PORTS))
            else:
                continue

            cidr_line = b.any_line_matches(r'0\.0\.0\.0/0')
            out.append(self._f(
                path, cidr_line or b.start_line,
                "PROOFCTL-TF-T004", "Open ingress to the world",
                Severity.ERROR,
                f'resource "{b.label1}" "{b.label2}" allows 0.0.0.0/0 on {flagged_ports}',
                hint="Restrict to known CIDR ranges. Never allow all ingress from the internet.",
                authority="CIS Benchmark / NIST SP 800-190",
            ))
        return out

    def _t005(self, path: Path, lines: list[str]) -> list[Finding]:
        """T-005 — Hardcoded secret literal in attribute value."""
        out = []
        for i, line in enumerate(lines, start=1):
            if line.strip().startswith("#"):
                continue
            m = _SECRET_ATTR_PAT.match(line)
            if m:
                attr = line.strip().split('=')[0].strip()
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TF-T005", "Hardcoded secret value",
                    Severity.ERROR,
                    f'"{attr}" appears to contain a literal secret value',
                    hint="Use var.* references or a secrets manager. Never commit credentials.",
                    authority="OWASP A02:2021 Cryptographic Failures",
                ))
        return out

    def _t006(self, path: Path, lines: list[str]) -> list[Finding]:
        """T-006 — IAM wildcard in actions or resources."""
        # Match: actions = ["*"] or resources = ["*"] (with possible extra items)
        pat = re.compile(r'(?:actions|not_actions|resources|not_resources)\s*=\s*\[[^\]]*"\*"')
        out = []
        for i, line in enumerate(lines, start=1):
            if line.strip().startswith("#"):
                continue
            if pat.search(line):
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TF-T006", "IAM wildcard permission",
                    Severity.ERROR,
                    'Wildcard "*" in IAM actions or resources grants overly broad permissions',
                    hint="Enumerate only the specific actions/resources actually needed.",
                    authority="CIS AWS Benchmark 1.16 / AWS IAM least-privilege",
                ))
        return out

    def _t009(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-009 — variable / output block missing description."""
        out = []
        for b in blocks:
            if b.kind not in ("variable", "output"):
                continue
            if not b.has_attr("description"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-T009", "Missing description",
                    Severity.WARNING,
                    f'{b.kind} "{b.label1}" has no description',
                    hint='Add description = "…" to document the variable\'s purpose.',
                ))
        return out

    def _t012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-012 — Deep local module path (≥3 levels of ../)."""
        out = []
        for b in blocks:
            if b.kind != "module":
                continue
            src = (b.attr_value("source") or "").strip('"')
            if src.startswith("git::") or src.startswith("registry.terraform.io"):
                continue
            depth = src.count("../")
            if depth >= 3:
                out.append(self._f(
                    path, b.attr_line("source") or b.start_line,
                    "PROOFCTL-TF-T012", "Deep relative module path",
                    Severity.WARNING,
                    f'Module "{b.label1}" source has {depth} levels of "../" — brittle coupling',
                    hint="Publish the module to a registry or use an absolute git source.",
                ))
        return out

    def _t013(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-013 — Resource missing required labels/tags."""
        out = []
        required = set(self._required_labels)
        for b in blocks:
            if b.kind != "resource":
                continue
            # Look for a tags or labels block/attribute
            tags_src = '\n'.join(b.raw_lines)
            for label in required:
                if not re.search(rf'"{re.escape(label)}"', tags_src):
                    out.append(self._f(
                        path, b.start_line,
                        "PROOFCTL-TF-T013", "Missing required label",
                        Severity.WARNING,
                        f'resource "{b.label1}" "{b.label2}" missing required label/tag "{label}"',
                        hint=f'Add "{label}" to the tags/labels block.',
                    ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group M — Terraform mechanics
    # ════════════════════════════════════════════════════════════════════════

    def _m002(self, path: Path, lines: list[str]) -> list[Finding]:
        """M-002 — ignore_changes = all silences all drift."""
        pat = re.compile(r'ignore_changes\s*=\s*all\b')
        out = []
        for i, line in enumerate(lines, start=1):
            if not line.strip().startswith("#") and pat.search(line):
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TF-M002", "ignore_changes = all",
                    Severity.WARNING,
                    'ignore_changes = all suppresses ALL configuration drift forever',
                    hint='List only the specific attributes to ignore, e.g. ignore_changes = [tags].',
                ))
        return out

    def _m003(self, path: Path, lines: list[str]) -> list[Finding]:
        """M-003 — provisioner remote-exec / local-exec breaks idempotency."""
        pat = re.compile(r'provisioner\s+"(remote-exec|local-exec)"')
        out = []
        for i, line in enumerate(lines, start=1):
            if not line.strip().startswith("#"):
                m = pat.search(line)
                if m:
                    out.append(self._f(
                        path, i,
                        "PROOFCTL-TF-M003", "Imperative provisioner",
                        Severity.WARNING,
                        f'provisioner "{m.group(1)}" is not idempotent and complicates drift detection',
                        hint="Use a configuration-management tool (Ansible, cloud-init, Packer) instead.",
                    ))
        return out

    def _m004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """M-004 — null_resource is deprecated; prefer terraform_data (TF ≥ 1.4)."""
        out = []
        for b in blocks:
            if b.kind == "resource" and b.label1 == "null_resource":
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-M004", "Deprecated null_resource",
                    Severity.INFO,
                    'null_resource is deprecated since Terraform 1.4',
                    hint="Replace with terraform_data which has the same semantics.",
                ))
        return out

    def _m005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """M-005 — terraform_remote_state creates tight workspace coupling."""
        out = []
        for b in blocks:
            if b.kind == "data" and b.label1 == "terraform_remote_state":
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-M005", "terraform_remote_state coupling",
                    Severity.WARNING,
                    f'data "terraform_remote_state" "{b.label2}" tightly couples workspaces',
                    hint="Use outputs published via a service catalog or SSM parameters instead.",
                ))
        return out

    def _m006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """M-006 — depends_on on a module forces full replacement on any change."""
        out = []
        for b in blocks:
            if b.kind == "module" and b.has_attr("depends_on"):
                out.append(self._f(
                    path, b.attr_line("depends_on") or b.start_line,
                    "PROOFCTL-TF-M006", "depends_on on module",
                    Severity.WARNING,
                    f'module "{b.label1}" uses depends_on — triggers full module replacement on any dependency change',
                    hint="Prefer passing values explicitly via module inputs to create fine-grained dependency edges.",
                ))
        return out

    def _m007(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """M-007 — Data source with no filter (returns all resources of the type)."""
        _filter_attrs = frozenset({
            "filter", "tags", "id", "name", "vpc_id", "cluster_name",
            "project", "region", "zone", "location", "function_name",
            "bucket", "cluster_identifier", "db_instance_identifier",
            "instance_id", "key_id", "secret_id", "policy_arn",
        })
        # Data sources that are inherently singleton or template-only (never need filters)
        _singleton_sources = frozenset({
            "terraform_remote_state", "http", "archive_file", "local_file",
            "aws_caller_identity", "aws_region", "aws_availability_zones",
            "aws_partition", "aws_billing_service_account", "aws_arn",
            "aws_iam_policy_document", "aws_iam_session_context",
            "google_client_config", "google_client_openid_userinfo",
            "google_project", "google_billing_account",
            "external", "template_file",
        })
        out = []
        for b in blocks:
            if b.kind != "data":
                continue
            if b.label1 in _singleton_sources:
                continue
            inner = '\n'.join(b.raw_lines[1:-1])
            has_filter = any(
                re.search(rf'\b{re.escape(a)}\b', inner)
                for a in _filter_attrs
            )
            if not has_filter:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-M007", "Unfiltered data source",
                    Severity.WARNING,
                    f'data "{b.label1}" "{b.label2}" has no filter — may match unintended resources',
                    hint="Add a filter, id, name, or tags block to scope the data source.",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group V — Lifecycle antipatterns
    # ════════════════════════════════════════════════════════════════════════

    def _v001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """V-001 — force_destroy / deletion_protection=false on prod-named resource."""
        out = []
        dangerous = re.compile(
            r'(?:force_destroy\s*=\s*true|deletion_protection\s*=\s*false)', re.IGNORECASE
        )
        for b in blocks:
            if b.kind != "resource":
                continue
            if not _PROD_RE.search(b.label2):
                continue
            lineno = b.any_line_matches(r'force_destroy\s*=\s*true|deletion_protection\s*=\s*false')
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-V001", "force_destroy on prod resource",
                    Severity.ERROR,
                    f'resource "{b.label1}" "{b.label2}" disables deletion protection on a production resource',
                    hint="Remove force_destroy / set deletion_protection = true for prod resources.",
                ))
        return out

    def _v003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """V-003 — Stateful resource without prevent_destroy in lifecycle."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _STATEFUL_RESOURCES:
                continue
            if not self._has_lifecycle_attr(b, "prevent_destroy"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-V003", "Missing prevent_destroy",
                    Severity.WARNING,
                    f'resource "{b.label1}" "{b.label2}" has no lifecycle {{ prevent_destroy = true }}',
                    hint="Add lifecycle { prevent_destroy = true } to guard stateful resources against accidental deletion.",
                ))
        return out

    def _v004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """V-004 — Module source is git:: with no ref, or a mutable (non-SHA/non-semver) ref."""
        out = []
        for b in blocks:
            if b.kind != "module":
                continue
            src = (b.attr_value("source") or "").strip('"')
            if not src.startswith("git::"):
                continue
            if "?ref=" not in src:
                out.append(self._f(
                    path, b.attr_line("source") or b.start_line,
                    "PROOFCTL-TF-V004", "Module git source with no version pin",
                    Severity.ERROR,
                    f'module "{b.label1}" source lacks ?ref= — always pulls HEAD',
                    hint='Pin to a commit SHA or semver tag: source = "git::https://…?ref=v1.2.3"',
                ))
            else:
                # Extract the ref value (stop at / & or end)
                ref_part = src.split("?ref=", 1)[1]
                ref = re.split(r'[/&?]', ref_part)[0]
                if _GIT_SHA_RE.match(ref) or _SEMVER_TAG_RE.match(ref):
                    continue  # immutable SHA or semver tag — clean
                out.append(self._f(
                    path, b.attr_line("source") or b.start_line,
                    "PROOFCTL-TF-V004", "Module git source with mutable ref",
                    Severity.WARNING,
                    f'module "{b.label1}" source ref="{ref}" is a mutable branch/tag — use a commit SHA',
                    hint='Pin to a full 40-char commit SHA for a truly immutable reference.',
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group G — GCP specific
    # ════════════════════════════════════════════════════════════════════════

    def _g001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-001 — Compute instance serial port enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            lineno = b.any_line_matches(r'"enable-serial-port"\s*=\s*"true"', re.IGNORECASE)
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-G001", "Serial port enabled on compute instance",
                    Severity.ERROR,
                    f'"enable-serial-port" = "true" on instance "{b.label2}"',
                    hint='Remove or set "enable-serial-port" = "false". Serial port access bypasses SSH controls.',
                    authority="CIS GCP Benchmark 4.5",
                ))
        return out

    def _g002(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-002 — OS Login explicitly disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            lineno = b.any_line_matches(r'"enable-oslogin"\s*=\s*"(?:FALSE|false|0)"')
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-G002", "OS Login disabled on compute instance",
                    Severity.WARNING,
                    f'OS Login explicitly disabled on instance "{b.label2}"',
                    hint='Set "enable-oslogin" = "TRUE" or remove the key to inherit the project default.',
                    authority="CIS GCP Benchmark 4.4",
                ))
        return out

    def _g003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-003 — Shielded VM not enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            # Flag if shielded_instance_config block is absent OR secure_boot = false
            if not b.has_nested("shielded_instance_config"):
                if not b.contains(r'shielded_instance_config'):
                    out.append(self._f(
                        path, b.start_line,
                        "PROOFCTL-TF-G003", "Shielded VM not configured",
                        Severity.WARNING,
                        f'Instance "{b.label2}" has no shielded_instance_config block',
                        hint='Add shielded_instance_config { enable_secure_boot = true enable_vtpm = true enable_integrity_monitoring = true }',
                        authority="CIS GCP Benchmark 4.8",
                    ))
            else:
                lineno = b.any_line_matches(r'enable_secure_boot\s*=\s*false')
                if lineno:
                    out.append(self._f(
                        path, lineno,
                        "PROOFCTL-TF-G003", "Shielded VM secure boot disabled",
                        Severity.WARNING,
                        f'Instance "{b.label2}" has enable_secure_boot = false',
                        hint="Enable secure boot to prevent boot-time rootkits.",
                        authority="CIS GCP Benchmark 4.8",
                    ))
        return out

    def _g004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-004 — Default service account with cloud-platform scope."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            # Detect: service_account block with empty email + cloud-platform scope
            if b.contains(r'service_account') and b.contains(r'cloud-platform'):
                # Check email is empty or uses the default SA pattern
                if b.contains(r'email\s*=\s*(?:""|compute@developer)') or not b.contains(r'email\s*='):
                    out.append(self._f(
                        path, b.any_line_matches(r'cloud-platform') or b.start_line,
                        "PROOFCTL-TF-G004", "Default SA with cloud-platform scope",
                        Severity.ERROR,
                        f'Instance "{b.label2}" uses the default service account with cloud-platform scope',
                        hint="Create a dedicated SA with only required roles and use granular scopes.",
                        authority="CIS GCP Benchmark 4.1",
                    ))
        return out

    def _g005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-005 — SSH public keys in instance metadata."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in (
                "google_compute_instance", "google_compute_project_metadata",
                "google_compute_project_metadata_item",
            ):
                continue
            lineno = b.any_line_matches(r'"ssh-keys"\s*=')
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-G005", "SSH keys in instance metadata",
                    Severity.ERROR,
                    f'SSH keys stored in metadata on "{b.label2}"',
                    hint="Use OS Login (enable-oslogin = TRUE) for centralized SSH key management via IAM.",
                    authority="CIS GCP Benchmark 4.3",
                ))
        return out

    def _g006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-006 — Cloud SQL instance with public IP enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            if b.contains(r'ipv4_enabled\s*=\s*true'):
                out.append(self._f(
                    path, b.any_line_matches(r'ipv4_enabled\s*=\s*true') or b.start_line,
                    "PROOFCTL-TF-G006", "Cloud SQL public IP enabled",
                    Severity.ERROR,
                    f'SQL instance "{b.label2}" has ipv4_enabled = true (public IP)',
                    hint="Set ipv4_enabled = false and use private_network or Cloud SQL Auth Proxy.",
                    authority="CIS GCP Benchmark 6.2",
                ))
        return out

    def _g007(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-007 — AI hallucination: 'deletion_protection_enabled' is an API field, not a TF attribute."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            lineno = b.attr_line("deletion_protection_enabled")
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-G007", "Hallucinated SQL attribute",
                    Severity.ERROR,
                    '"deletion_protection_enabled" is the GCP API field name — silently ignored by Terraform',
                    hint='Use "deletion_protection = true" (Terraform attribute) instead.',
                    authority="Terraform google_sql_database_instance docs",
                ))
        return out

    def _g008(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-008 — Cloud SQL automated backups disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            if b.contains(r'backup_configuration') and b.contains(r'enabled\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'enabled\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G008", "Cloud SQL backups disabled",
                    Severity.WARNING,
                    f'SQL instance "{b.label2}" has backup_configuration.enabled = false',
                    hint="Enable automated backups: backup_configuration { enabled = true }",
                    authority="CIS GCP Benchmark 6.7",
                ))
        return out

    def _g009(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-009 — Cloud SQL SSL not required."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            if b.contains(r'require_ssl\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'require_ssl\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G009", "Cloud SQL SSL not required",
                    Severity.ERROR,
                    f'SQL instance "{b.label2}" has require_ssl = false',
                    hint="Set require_ssl = true to enforce TLS for all client connections.",
                    authority="CIS GCP Benchmark 6.4",
                ))
        return out

    def _g010(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-010 — GKE cluster not configured as private."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            # Flag if private_cluster_config is missing or enable_private_nodes=false
            if b.contains(r'enable_private_nodes\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'enable_private_nodes\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G010", "GKE cluster not private",
                    Severity.ERROR,
                    f'Cluster "{b.label2}" has enable_private_nodes = false',
                    hint="Enable private nodes to prevent direct internet access to cluster nodes.",
                    authority="CIS GKE Benchmark 6.6.1",
                ))
            elif not b.contains(r'private_cluster_config'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G010", "GKE cluster not private",
                    Severity.WARNING,
                    f'Cluster "{b.label2}" has no private_cluster_config block',
                    hint="Add private_cluster_config { enable_private_nodes = true enable_private_endpoint = false master_ipv4_cidr_block = … }",
                    authority="CIS GKE Benchmark 6.6.1",
                ))
        return out

    def _g011(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-011 — Workload identity at cluster level but missing from node pool metadata config."""
        cluster_has_wi = any(
            b.kind == "resource"
            and b.label1 == "google_container_cluster"
            and b.contains(r'workload_identity_config')
            for b in blocks
        )
        if not cluster_has_wi:
            return []
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_node_pool":
                continue
            has_gke_metadata = (
                b.contains(r'workload_metadata_config')
                and b.contains(r'GKE_METADATA')
            )
            if not has_gke_metadata:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G011", "Workload identity node pool gap",
                    Severity.ERROR,
                    f'Node pool "{b.label2}" missing workload_metadata_config while cluster has workload_identity_config',
                    hint='Add to node_config: workload_metadata_config { mode = "GKE_METADATA" }',
                    authority="GKE Workload Identity docs / CIS GKE Benchmark 6.2.2",
                ))
        return out

    def _g012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-012 — Legacy ABAC enabled on GKE cluster."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            if b.contains(r'enable_legacy_abac\s*=\s*true'):
                out.append(self._f(
                    path, b.any_line_matches(r'enable_legacy_abac\s*=\s*true') or b.start_line,
                    "PROOFCTL-TF-G012", "Legacy ABAC enabled",
                    Severity.ERROR,
                    f'Cluster "{b.label2}" has enable_legacy_abac = true',
                    hint="Remove enable_legacy_abac (defaults to false). Use RBAC instead.",
                    authority="CIS GKE Benchmark 6.8.4",
                ))
        return out

    def _g013(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-013 — Network policy disabled on GKE cluster."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            if b.contains(r'network_policy') and b.contains(r'enabled\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'enabled\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G013", "GKE network policy disabled",
                    Severity.WARNING,
                    f'Cluster "{b.label2}" has network_policy.enabled = false',
                    hint="Enable network policy to restrict pod-to-pod traffic: network_policy { enabled = true }",
                    authority="CIS GKE Benchmark 6.6.7",
                ))
        return out

    def _g014(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-014 — GKE cluster without master authorized networks."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            if not b.contains(r'master_authorized_networks_config'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G014", "No master authorized networks",
                    Severity.WARNING,
                    f'Cluster "{b.label2}" has no master_authorized_networks_config',
                    hint="Restrict API server access: master_authorized_networks_config { cidr_blocks { cidr_block = … } }",
                    authority="CIS GKE Benchmark 6.6.2",
                ))
        return out

    def _g015(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-015 — Binary authorization not enforced on GKE cluster."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            if b.contains(r'binary_authorization'):
                if b.contains(r'evaluation_mode\s*=\s*"DISABLED"') or not b.contains(r'PROJECT_SINGLETON_POLICY_ENFORCE'):
                    out.append(self._f(
                        path, b.any_line_matches(r'binary_authorization') or b.start_line,
                        "PROOFCTL-TF-G015", "Binary authorization not enforced",
                        Severity.WARNING,
                        f'Cluster "{b.label2}" binary_authorization is not set to PROJECT_SINGLETON_POLICY_ENFORCE',
                        hint='Set evaluation_mode = "PROJECT_SINGLETON_POLICY_ENFORCE".',
                        authority="CIS GKE Benchmark 6.10.2",
                    ))
        return out

    def _g016(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-016 — GKE logging or monitoring disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            for attr in ("logging_service", "monitoring_service"):
                if b.contains(rf'{attr}\s*=\s*"none"'):
                    out.append(self._f(
                        path, b.any_line_matches(rf'{attr}\s*=\s*"none"') or b.start_line,
                        "PROOFCTL-TF-G016", "GKE logging/monitoring disabled",
                        Severity.ERROR,
                        f'Cluster "{b.label2}" has {attr} = "none"',
                        hint=f'Remove {attr} or set to "logging.googleapis.com/kubernetes".',
                        authority="CIS GKE Benchmark 6.7.1",
                    ))
        return out

    def _g017(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-017 — GCS bucket public access prevention not enforced."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_storage_bucket":
                continue
            val = b.attr_value("public_access_prevention")
            if val is None or val.strip('"') != "enforced":
                out.append(self._f(
                    path, b.attr_line("public_access_prevention") or b.start_line,
                    "PROOFCTL-TF-G017", "GCS public access not prevented",
                    Severity.ERROR,
                    f'Bucket "{b.label2}" public_access_prevention is not "enforced"',
                    hint='Set public_access_prevention = "enforced".',
                    authority="CIS GCP Benchmark 5.1",
                ))
        return out

    def _g018(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-018 — GCS uniform bucket-level access disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_storage_bucket":
                continue
            if b.contains(r'uniform_bucket_level_access\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'uniform_bucket_level_access\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G018", "Uniform bucket-level access disabled",
                    Severity.WARNING,
                    f'Bucket "{b.label2}" has uniform_bucket_level_access = false',
                    hint="Enable uniform ACLs to avoid object-level permission surprises.",
                    authority="CIS GCP Benchmark 5.2",
                ))
        return out

    def _g019(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-019 — GCS bucket versioning disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_storage_bucket":
                continue
            if b.contains(r'versioning') and b.contains(r'enabled\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'enabled\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G019", "GCS versioning disabled",
                    Severity.WARNING,
                    f'Bucket "{b.label2}" has versioning.enabled = false',
                    hint="Enable versioning: versioning { enabled = true }",
                ))
        return out

    def _g020(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-020 — google_service_account_key resource (key stored in TF state)."""
        out = []
        for b in blocks:
            if b.kind == "resource" and b.label1 == "google_service_account_key":
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G020", "Service account key resource",
                    Severity.ERROR,
                    f'google_service_account_key "{b.label2}" stores a private key in Terraform state',
                    hint="Use Workload Identity instead of long-lived SA keys. If a key is essential, manage it outside Terraform.",
                    authority="CIS GCP Benchmark 1.4",
                ))
        return out

    def _g021(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-021 — Broad GCP project IAM role (owner/editor)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _GCP_IAM_RESOURCES:
                continue
            role = (b.attr_value("role") or "").strip('"')
            if role in _BROAD_GCP_ROLES:
                out.append(self._f(
                    path, b.attr_line("role") or b.start_line,
                    "PROOFCTL-TF-G021", "Overly broad GCP IAM role",
                    Severity.ERROR,
                    f'"{b.label1}" grants "{role}" — violates least privilege',
                    hint="Use a predefined role scoped to the specific service (e.g. roles/storage.objectCreator).",
                    authority="CIS GCP Benchmark 1.2",
                ))
        return out

    def _g023(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-023 — KMS key rotation not configured or > 90 days."""
        out = []
        _90_days_sec = 90 * 24 * 3600
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_kms_crypto_key":
                continue
            rp = (b.attr_value("rotation_period") or "").strip('"') or None
            if rp is None:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G023", "KMS key rotation not set",
                    Severity.WARNING,
                    f'KMS key "{b.label2}" has no rotation_period',
                    hint='Set rotation_period = "7776000s" (90 days) or less.',
                    authority="CIS GCP Benchmark 1.10",
                ))
            else:
                sec_m = re.match(r'(\d+)s', rp.strip())
                if sec_m and int(sec_m.group(1)) > _90_days_sec:
                    out.append(self._f(
                        path, b.attr_line("rotation_period") or b.start_line,
                        "PROOFCTL-TF-G023", "KMS key rotation too infrequent",
                        Severity.WARNING,
                        f'KMS key "{b.label2}" rotation_period exceeds 90 days',
                        hint='Set rotation_period = "7776000s" (90 days) or less.',
                        authority="CIS GCP Benchmark 1.10",
                    ))
        return out

    def _g024(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-024 — KMS key missing prevent_destroy."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_kms_crypto_key":
                continue
            if not self._has_lifecycle_attr(b, "prevent_destroy"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G024", "KMS key missing prevent_destroy",
                    Severity.WARNING,
                    f'KMS key "{b.label2}" has no lifecycle {{ prevent_destroy = true }}',
                    hint="Destroying a KMS key is irreversible — add prevent_destroy.",
                ))
        return out

    def _g025(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-025 — KMS key destroy_scheduled_duration absent (GCP default = 24h) or < 7 days."""
        _7_days_sec = 7 * 24 * 3600
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_kms_crypto_key":
                continue
            val = (b.attr_value("destroy_scheduled_duration") or "").strip('"') or None
            if val is None:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G025", "KMS key destroy window not set",
                    Severity.WARNING,
                    f'KMS key "{b.label2}" has no destroy_scheduled_duration — GCP defaults to 24h',
                    hint='Set destroy_scheduled_duration = "604800s" (7 days) or more.',
                ))
            else:
                sec_m = re.match(r'(\d+)s', val.strip())
                if sec_m and int(sec_m.group(1)) < _7_days_sec:
                    out.append(self._f(
                        path, b.attr_line("destroy_scheduled_duration") or b.start_line,
                        "PROOFCTL-TF-G025", "KMS key destroy window too short",
                        Severity.WARNING,
                        f'KMS key "{b.label2}" destroy_scheduled_duration is less than 7 days',
                        hint='Set destroy_scheduled_duration = "604800s" (7 days) or more.',
                    ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group G — GCP (extended rules TF-G026–TF-G031)
    # ════════════════════════════════════════════════════════════════════════

    def _g026(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-026 — IAM binding grants allUsers or allAuthenticatedUsers."""
        _public_members = frozenset({"allUsers", "allAuthenticatedUsers"})
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in (
                "google_project_iam_member", "google_project_iam_binding",
            ):
                continue
            # Check `member` or `members` attribute
            val = b.attr_value("member") or b.attr_value("members") or ""
            for pm in _public_members:
                if pm in val:
                    out.append(self._f(
                        path, b.attr_line("member") or b.attr_line("members") or b.start_line,
                        "PROOFCTL-TF-G026", "IAM binding grants public access",
                        Severity.ERROR,
                        f"IAM binding '{b.label2}' grants access to allUsers/allAuthenticatedUsers — public access to GCP resource",
                        hint="Remove allUsers/allAuthenticatedUsers. Grant access to specific service accounts or groups.",
                        authority="CIS GCP Benchmark 1.15",
                    ))
                    break
        return out

    def _g027(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-027 — Cloud Function with ALLOW_ALL ingress."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_cloudfunctions_function":
                continue
            val = (b.attr_value("ingress_settings") or "").strip('"')
            if val == "ALLOW_ALL":
                out.append(self._f(
                    path, b.attr_line("ingress_settings") or b.start_line,
                    "PROOFCTL-TF-G027", "Cloud Function accepts all ingress",
                    Severity.WARNING,
                    f"Cloud Function '{b.label2}' accepts requests from all sources (ingress_settings = ALLOW_ALL)",
                    hint='Set ingress_settings = "ALLOW_INTERNAL_ONLY" or "ALLOW_INTERNAL_AND_GCLB" unless function must be public.',
                    authority="GCP Security Best Practices – Cloud Functions",
                ))
        return out

    def _g028(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-028 — Cloud Run IAM binding with allUsers."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in (
                "google_cloud_run_service_iam_member",
                "google_cloud_run_service_iam_binding",
            ):
                continue
            val = b.attr_value("member") or b.attr_value("members") or ""
            if "allUsers" in val:
                out.append(self._f(
                    path, b.attr_line("member") or b.attr_line("members") or b.start_line,
                    "PROOFCTL-TF-G028", "Cloud Run service publicly accessible",
                    Severity.WARNING,
                    f"Cloud Run service '{b.label2}' is publicly accessible (allUsers) — unauthenticated invocation allowed",
                    hint="Remove allUsers IAM binding. Use IAM auth or a load balancer with Cloud Armor.",
                    authority="GCP Security Best Practices – Cloud Run authentication",
                ))
        return out

    def _g029(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-029 — Subnetwork without VPC Flow Logs (log_config block absent)."""
        _skip_purposes = frozenset({
            "INTERNAL_HTTPS_LOAD_BALANCER", "REGIONAL_MANAGED_PROXY",
            "GLOBAL_MANAGED_PROXY", "PRIVATE_SERVICE_CONNECT",
        })
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_subnetwork":
                continue
            # Skip proxy/load-balancer subnets
            purpose = (b.attr_value("purpose") or "").strip('"').upper()
            if purpose in _skip_purposes:
                continue
            if not b.contains(r'log_config'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G029", "Subnetwork missing VPC Flow Logs",
                    Severity.WARNING,
                    f"Subnetwork '{b.label2}' has no VPC Flow Logs — network traffic is not logged",
                    hint='Add log_config { aggregation_interval = "INTERVAL_5_SEC" flow_sampling = 0.5 metadata = "INCLUDE_ALL_METADATA" }',
                    authority="CIS GCP Benchmark 3.8",
                ))
        return out

    def _g030(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-030 — BigQuery dataset with public access."""
        _public_pat = re.compile(
            r'special_group\s*=\s*"(?:allAuthenticatedUsers|allUsers)"'
        )
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_bigquery_dataset":
                continue
            body = "\n".join(b.raw_lines)
            m = _public_pat.search(body)
            if m:
                lineno = b.any_line_matches(
                    r'special_group\s*=\s*"(?:allAuthenticatedUsers|allUsers)"'
                )
                out.append(self._f(
                    path, lineno or b.start_line,
                    "PROOFCTL-TF-G030", "BigQuery dataset grants public access",
                    Severity.ERROR,
                    f"BigQuery dataset '{b.label2}' grants access to allAuthenticatedUsers — data is publicly readable",
                    hint="Remove allAuthenticatedUsers from dataset access. Grant specific users or service accounts.",
                    authority="CIS GCP Benchmark 7.1",
                ))
        return out

    def _g031(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-031 — Pub/Sub topic without CMEK."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_pubsub_topic":
                continue
            if not b.has_attr("kms_key_name"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G031", "Pub/Sub topic without CMEK",
                    Severity.WARNING,
                    f"Pub/Sub topic '{b.label2}' uses Google-managed encryption — no CMEK configured",
                    hint="Set kms_key_name to a Cloud KMS key for customer-managed encryption.",
                    authority="GCP Security Best Practices – Pub/Sub CMEK",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group A — AWS specific
    # ════════════════════════════════════════════════════════════════════════

    def _a001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-001 — EC2 IMDSv2 not enforced."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("aws_instance", "aws_launch_template"):
                continue
            if b.contains(r'metadata_options'):
                if b.contains(r'http_tokens\s*=\s*"optional"'):
                    out.append(self._f(
                        path, b.any_line_matches(r'http_tokens\s*=\s*"optional"') or b.start_line,
                        "PROOFCTL-TF-A001", "IMDSv2 not required",
                        Severity.ERROR,
                        f'"{b.label2}" has http_tokens = "optional" — IMDSv1 still accessible',
                        hint='Set http_tokens = "required" to enforce IMDSv2 and block SSRF-based credential theft.',
                        authority="AWS Security Best Practices / CIS AWS Benchmark 5.6",
                    ))
            else:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A001", "IMDSv2 not required",
                    Severity.WARNING,
                    f'"{b.label2}" has no metadata_options block — IMDSv1 defaults to enabled',
                    hint='Add metadata_options { http_tokens = "required" http_endpoint = "enabled" }',
                    authority="AWS Security Best Practices / CIS AWS Benchmark 5.6",
                ))
        return out

    def _a003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-003 — RDS skip_final_snapshot = true or deletion_protection = false."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("aws_db_instance", "aws_rds_cluster"):
                continue
            if b.contains(r'skip_final_snapshot\s*=\s*true'):
                out.append(self._f(
                    path, b.any_line_matches(r'skip_final_snapshot\s*=\s*true') or b.start_line,
                    "PROOFCTL-TF-A003", "RDS skip_final_snapshot enabled",
                    Severity.ERROR,
                    f'RDS "{b.label2}" will skip final snapshot on deletion',
                    hint="Set skip_final_snapshot = false and final_snapshot_identifier.",
                    authority="CIS AWS Benchmark 2.3",
                ))
            if b.contains(r'deletion_protection\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'deletion_protection\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-A003", "RDS deletion protection disabled",
                    Severity.ERROR,
                    f'RDS "{b.label2}" has deletion_protection = false',
                    hint="Set deletion_protection = true to prevent accidental deletion.",
                ))
        return out

    def _a004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-004 — RDS backup retention = 0."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("aws_db_instance", "aws_rds_cluster"):
                continue
            if b.contains(r'backup_retention_period\s*=\s*0\b'):
                out.append(self._f(
                    path, b.any_line_matches(r'backup_retention_period\s*=\s*0') or b.start_line,
                    "PROOFCTL-TF-A004", "RDS backup retention disabled",
                    Severity.ERROR,
                    f'RDS "{b.label2}" has backup_retention_period = 0 (backups disabled)',
                    hint="Set backup_retention_period ≥ 7 for point-in-time recovery.",
                    authority="CIS AWS Benchmark 2.3",
                ))
        return out

    def _a005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-005 — EKS endpoint publicly accessible without CIDR restriction."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_eks_cluster":
                continue
            if b.contains(r'endpoint_public_access\s*=\s*true'):
                if not b.contains(r'public_access_cidrs'):
                    out.append(self._f(
                        path, b.any_line_matches(r'endpoint_public_access\s*=\s*true') or b.start_line,
                        "PROOFCTL-TF-A005", "EKS endpoint public without CIDR restriction",
                        Severity.WARNING,
                        f'EKS cluster "{b.label2}" has public endpoint without public_access_cidrs',
                        hint='Add public_access_cidrs = ["<your-office-cidr>"] or set endpoint_public_access = false.',
                        authority="CIS EKS Benchmark 2.1.1",
                    ))
        return out

    def _a006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-006 — EKS secrets not encrypted with KMS."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_eks_cluster":
                continue
            if not (b.contains(r'encryption_config') and b.contains(r'"secrets"')):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A006", "EKS secrets not encrypted",
                    Severity.ERROR,
                    f'EKS cluster "{b.label2}" has no secrets encryption_config',
                    hint='Add encryption_config { resources = ["secrets"] provider { key_arn = … } }',
                    authority="CIS EKS Benchmark 2.1.2",
                ))
        return out

    def _a007(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-007 — EBS volume or EC2 root volume not encrypted."""
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            if b.label1 == "aws_ebs_volume":
                if not b.contains(r'encrypted\s*=\s*true'):
                    out.append(self._f(
                        path, b.start_line,
                        "PROOFCTL-TF-A007", "EBS volume not encrypted",
                        Severity.ERROR,
                        f'EBS volume "{b.label2}" is missing encrypted = true',
                        hint="Add encrypted = true and optionally kms_key_id.",
                        authority="CIS AWS Benchmark 2.2.1",
                    ))
            elif b.label1 == "aws_instance":
                # Check root_block_device for encrypted
                if b.contains(r'root_block_device') and not b.contains(r'encrypted\s*=\s*true'):
                    out.append(self._f(
                        path, b.any_line_matches(r'root_block_device') or b.start_line,
                        "PROOFCTL-TF-A007", "EC2 root volume not encrypted",
                        Severity.WARNING,
                        f'EC2 instance "{b.label2}" root_block_device missing encrypted = true',
                        hint="Add encrypted = true to root_block_device.",
                    ))
        return out

    def _a008(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-008 — Lambda function with plaintext secret in environment variables."""
        secret_key_re = re.compile(
            r'"(?:SECRET|PASSWORD|TOKEN|KEY|CREDENTIAL|API_KEY|AUTH)[^"]*"\s*=\s*"[^"$\{][^"]{3,}"',
            re.IGNORECASE,
        )
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_lambda_function":
                continue
            if b.contains(r'environment') and b.contains(r'variables'):
                for i, line in enumerate(b.raw_lines):
                    if secret_key_re.search(line):
                        out.append(self._f(
                            path, b.start_line + i,
                            "PROOFCTL-TF-A008", "Lambda plaintext secret in env var",
                            Severity.ERROR,
                            f'Lambda "{b.label2}" environment variable appears to contain a literal secret',
                            hint="Use AWS Secrets Manager or SSM Parameter Store and retrieve at runtime.",
                            authority="OWASP A02:2021 Cryptographic Failures",
                        ))
                        break
        return out

    def _a009(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-009 — ElastiCache transit encryption disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in (
                "aws_elasticache_replication_group", "aws_elasticache_cluster"
            ):
                continue
            if b.contains(r'transit_encryption_enabled\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'transit_encryption_enabled\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-A009", "ElastiCache transit encryption disabled",
                    Severity.ERROR,
                    f'ElastiCache "{b.label2}" has transit_encryption_enabled = false',
                    hint="Set transit_encryption_enabled = true to encrypt data in transit.",
                    authority="CIS AWS Benchmark 3.7",
                ))
        return out

    def _a010(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-010 — CloudTrail not integrated with CloudWatch Logs."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_cloudtrail":
                continue
            if not b.has_attr("cloud_watch_logs_group_arn"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A010", "CloudTrail missing CloudWatch integration",
                    Severity.WARNING,
                    f'CloudTrail "{b.label2}" has no cloud_watch_logs_group_arn',
                    hint="Add cloud_watch_logs_group_arn and cloud_watch_logs_role_arn for real-time alerting.",
                    authority="CIS AWS Benchmark 3.2",
                ))
        return out

    def _a011(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-011 — No aws_cloudtrail resource found anywhere in scanned blocks."""
        has_aws = any(
            b.kind == "resource" and b.label1.startswith("aws_")
            for b in blocks
        )
        if not has_aws:
            return []
        has_trail = any(
            b.kind == "resource" and b.label1.startswith("aws_cloudtrail")
            for b in blocks
        )
        if not has_trail:
            return [self._f(
                path, None,
                "PROOFCTL-TF-A011", "No CloudTrail resource",
                Severity.WARNING,
                "No aws_cloudtrail resource found — API activity is not being audited",
                hint="Add an aws_cloudtrail resource with multi_region_trail = true and log validation enabled.",
                authority="CIS AWS Benchmark 3.1",
            )]
        return []

    def _a012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-012 — aws_vpc present but no aws_flow_log resource."""
        has_vpc = any(
            b.kind == "resource" and b.label1 == "aws_vpc"
            for b in blocks
        )
        if not has_vpc:
            return []
        has_flow_log = any(
            b.kind == "resource" and b.label1 == "aws_flow_log"
            for b in blocks
        )
        if not has_flow_log:
            return [self._f(
                path, None,
                "PROOFCTL-TF-A012", "VPC missing flow logs",
                Severity.WARNING,
                "aws_vpc found but no aws_flow_log resource — VPC network traffic is not logged",
                hint="Add aws_flow_log with traffic_type = ALL pointing at your VPC.",
                authority="CIS AWS Benchmark 2.9",
            )]
        return []

    def _a013(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-013 — ECR repository with mutable tags or scan_on_push disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_ecr_repository":
                continue
            mutability = (b.attr_value("image_tag_mutability") or "").strip('"')
            if mutability == "MUTABLE":
                out.append(self._f(
                    path, b.attr_line("image_tag_mutability") or b.start_line,
                    "PROOFCTL-TF-A013", "ECR mutable image tags",
                    Severity.WARNING,
                    f"ECR repository '{b.label2}' has mutable image tags — supply chain tampering possible",
                    hint='Set image_tag_mutability = "IMMUTABLE"',
                    authority="CIS AWS Benchmark – ECR",
                ))
            # Check scan_on_push — look for explicit false or absence in body
            has_scan_block = b.contains(r'image_scanning_configuration')
            scan_disabled = b.contains(r'scan_on_push\s*=\s*false')
            if scan_disabled or not has_scan_block:
                out.append(self._f(
                    path, b.any_line_matches(r'scan_on_push\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-A013", "ECR scan_on_push disabled",
                    Severity.WARNING,
                    f"ECR repository '{b.label2}' has scan_on_push disabled — vulnerabilities not detected on push",
                    hint='Add image_scanning_configuration { scan_on_push = true }',
                    authority="CIS AWS Benchmark – ECR",
                ))
        return out

    def _a014(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-014 — Lambda function with hardcoded secret in environment variables."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_lambda_function":
                continue
            if not (b.contains(r'environment') and b.contains(r'variables')):
                continue
            # Scan lines inside the block for secret key patterns
            in_env = False
            env_depth = 0
            for i, line in enumerate(b.raw_lines):
                if not in_env and re.search(r'\benvironment\s*\{', line):
                    in_env = True
                    env_depth = 1
                    continue
                if in_env:
                    env_depth += line.count('{') - line.count('}')
                    if _SECRET_ATTR_PAT.match(line):
                        out.append(self._f(
                            path, b.start_line + i,
                            "PROOFCTL-TF-A014", "Lambda hardcoded secret in env var",
                            Severity.ERROR,
                            f"Lambda function '{b.label2}' has a hardcoded secret in environment variables",
                            hint="Store secrets in AWS Secrets Manager or SSM Parameter Store and retrieve at runtime.",
                            authority="OWASP A02:2021 – Cryptographic Failures / CWE-312",
                        ))
                        break
                    if env_depth <= 0:
                        in_env = False
        return out

    # ════════════════════════════════════════════════════════════════════════
    # ── Azure rules (TF-AZ-*) ────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════

    def _az001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-001 — Storage account allows public blob access."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_storage_account":
                continue
            val = b.attr_value("allow_blob_public_access")
            if val is not None and val.strip('"') == "true":
                out.append(self._f(
                    path, b.attr_line("allow_blob_public_access") or b.start_line,
                    "PROOFCTL-TF-AZ001", "Storage account allows public blob access",
                    Severity.ERROR,
                    f"Storage account '{b.label2}' allows public blob access — data exposure risk",
                    hint="Set allow_blob_public_access = false",
                    authority="CIS Azure Benchmark 3.5",
                ))
        return out

    def _az002(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-002 — Storage account missing network_rules with default_action = Deny."""
        _deny_pat = re.compile(r'default_action\s*=\s*"Deny"')
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_storage_account":
                continue
            body = "\n".join(b.raw_lines)
            has_network_rules = bool(re.search(r'network_rules\s*\{', body))
            has_deny = bool(_deny_pat.search(body))
            if not has_network_rules or not has_deny:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-AZ002", "Storage account network rules not restrictive",
                    Severity.WARNING,
                    f'Storage account \'{b.label2}\' has no network_rules default_action = Deny — accessible from all networks',
                    hint='Add network_rules { default_action = "Deny" ip_rules = [...] }',
                    authority="CIS Azure Benchmark 3.7",
                ))
        return out

    def _az003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-003 — SQL Server with public network access enabled."""
        _sql_types = frozenset({"azurerm_mssql_server", "azurerm_sql_server"})
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _sql_types:
                continue
            val = b.attr_value("public_network_access_enabled")
            if val is not None and val.strip('"') == "true":
                out.append(self._f(
                    path, b.attr_line("public_network_access_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ003", "SQL Server public network access enabled",
                    Severity.ERROR,
                    f"SQL Server '{b.label2}' has public network access enabled",
                    hint="Set public_network_access_enabled = false and use private endpoint.",
                    authority="CIS Azure Benchmark 4.3",
                ))
        return out

    def _az004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-004 — PostgreSQL or MySQL server with SSL enforcement disabled."""
        _db_types = frozenset({"azurerm_postgresql_server", "azurerm_mysql_server"})
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _db_types:
                continue
            val = b.attr_value("ssl_enforcement_enabled")
            if val is not None and val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("ssl_enforcement_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ004", "Database SSL enforcement disabled",
                    Severity.ERROR,
                    f"{b.label1} '{b.label2}' has SSL enforcement disabled — connections are unencrypted",
                    hint="Set ssl_enforcement_enabled = true",
                    authority="CIS Azure Benchmark 4.3.1",
                ))
        return out

    def _az005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-005 — AKS cluster missing API server authorized IP ranges."""
        _empty_vals = frozenset({"null", "[]", ""})
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_kubernetes_cluster":
                continue
            val = b.attr_value("api_server_authorized_ip_ranges")
            if val is None or val.strip('"').strip() in _empty_vals:
                out.append(self._f(
                    path, b.attr_line("api_server_authorized_ip_ranges") or b.start_line,
                    "PROOFCTL-TF-AZ005", "AKS API server has no IP restrictions",
                    Severity.ERROR,
                    f"AKS cluster '{b.label2}' has no API server IP restrictions — control plane is internet-accessible",
                    hint="Set api_server_authorized_ip_ranges to your trusted CIDR ranges.",
                    authority="CIS Azure Benchmark 8.3",
                ))
        return out

    def _az006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-006 — AKS cluster with RBAC disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_kubernetes_cluster":
                continue
            val = b.attr_value("role_based_access_control_enabled")
            if val is not None and val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("role_based_access_control_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ006", "AKS RBAC disabled",
                    Severity.ERROR,
                    f"AKS cluster '{b.label2}' has RBAC disabled — no access control on cluster resources",
                    hint="Set role_based_access_control_enabled = true (default in newer provider versions)",
                    authority="CIS Azure Benchmark 8.5",
                ))
        return out

    def _az007(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-007 — Key Vault without purge protection enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_key_vault":
                continue
            val = b.attr_value("purge_protection_enabled")
            # Flag if absent or explicitly false
            if val is None or val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("purge_protection_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ007", "Key Vault purge protection disabled",
                    Severity.ERROR,
                    f"Key Vault '{b.label2}' has purge protection disabled — secrets can be permanently deleted immediately",
                    hint="Set purge_protection_enabled = true and soft_delete_retention_days >= 7",
                    authority="CIS Azure Benchmark 8.6",
                ))
        return out

    def _az008(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-008 — Key Vault key missing expiration_date."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_key_vault_key":
                continue
            if not b.has_attr("expiration_date"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-AZ008", "Key Vault key has no expiration date",
                    Severity.WARNING,
                    f"Key Vault key '{b.label2}' has no expiration date — key never rotates automatically",
                    hint="Set expiration_date to enforce key rotation policy.",
                    authority="CIS Azure Benchmark 8.3 – Key rotation",
                ))
        return out

    def _az009(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-009 — Monitor log profile retains logs for less than 90 days."""
        _days_pat = re.compile(r'days\s*=\s*(\d+)')
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_monitor_log_profile":
                continue
            body = "\n".join(b.raw_lines)
            m = _days_pat.search(body)
            if m:
                days = int(m.group(1))
                if days < 90:
                    lineno = b.any_line_matches(r'days\s*=\s*\d+')
                    out.append(self._f(
                        path, lineno or b.start_line,
                        "PROOFCTL-TF-AZ009", "Log profile retention too short",
                        Severity.WARNING,
                        f"Log profile '{b.label2}' retains logs for only {days} days — minimum 90 days recommended",
                        hint="Set retention_policy { enabled = true days = 365 }",
                        authority="CIS Azure Benchmark 5.1.2",
                    ))
        return out

    def _az010(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-010 — Overly broad Azure role assignment or wildcard role definition."""
        _broad_roles = frozenset({"Owner", "Contributor", "User Access Administrator"})
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            if b.label1 == "azurerm_role_assignment":
                role = (b.attr_value("role_definition_name") or "").strip('"')
                scope = (b.attr_value("scope") or "").strip('"')
                # Subscription scope: contains /subscriptions/ but not /resourceGroups/
                is_sub_scope = (
                    "/subscriptions/" in scope
                    and "/resourceGroups/" not in scope
                    and "/resourcegroups/" not in scope.lower()
                )
                if role in _broad_roles and is_sub_scope:
                    out.append(self._f(
                        path, b.attr_line("role_definition_name") or b.start_line,
                        "PROOFCTL-TF-AZ010", "Overly broad Azure role assignment",
                        Severity.WARNING,
                        f"Role '{b.label2}' grants '{role}' at subscription scope — overly broad permissions",
                        hint="Scope role assignments to resource groups or individual resources.",
                        authority="CIS Azure Benchmark 1.23 – Limit role assignments",
                    ))
            elif b.label1 == "azurerm_role_definition":
                # Flag if actions contains "*"
                if b.contains(r'"[*]"') or b.contains(r'\[\s*"\*"\s*\]') or b.contains(r'actions\s*=\s*\[[^\]]*"\*"'):
                    out.append(self._f(
                        path, b.any_line_matches(r'actions\s*=') or b.start_line,
                        "PROOFCTL-TF-AZ010", "Azure role definition with wildcard actions",
                        Severity.ERROR,
                        f"Role definition '{b.label2}' uses wildcard '*' in actions — grants all permissions",
                        hint="Enumerate only the specific actions required instead of using '*'.",
                        authority="CIS Azure Benchmark 1.23 – Limit role assignments",
                    ))
        return out

    def _az011(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-011 — App Service allows HTTP (https_only not set to true)."""
        _app_types = frozenset({
            "azurerm_app_service",
            "azurerm_linux_web_app",
            "azurerm_windows_web_app",
        })
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _app_types:
                continue
            val = b.attr_value("https_only")
            # Flag if absent (default false in older versions) or explicitly false
            if val is None or val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("https_only") or b.start_line,
                    "PROOFCTL-TF-AZ011", "App Service allows HTTP",
                    Severity.ERROR,
                    f"App Service '{b.label2}' allows HTTP — traffic is unencrypted",
                    hint="Set https_only = true",
                    authority="CIS Azure Benchmark 9.2",
                ))
        return out

    def _az012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-012 — VM without encryption at host enabled."""
        _vm_types = frozenset({
            "azurerm_linux_virtual_machine",
            "azurerm_windows_virtual_machine",
        })
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _vm_types:
                continue
            val = b.attr_value("encryption_at_host_enabled")
            if val is None or val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("encryption_at_host_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ012", "VM missing encryption at host",
                    Severity.WARNING,
                    f"VM '{b.label2}' does not enforce encryption at host — host disk data may be unencrypted",
                    hint="Set encryption_at_host_enabled = true (requires subscription feature registration)",
                    authority="CIS Azure Benchmark 7.7",
                ))
        return out

    def _t014(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-014 — No terraform { required_version } constraint found."""
        # Only fire if there are resource or module blocks present
        has_resources = any(b.kind in ("resource", "module") for b in blocks)
        if not has_resources:
            return []
        for b in blocks:
            if b.kind == "terraform" and b.has_attr("required_version"):
                return []
        return [self._f(
            path, None,
            "PROOFCTL-TF-T014", "Missing required_version constraint",
            Severity.WARNING,
            "No terraform { required_version } constraint found — Terraform version drift risk",
            hint='Add terraform { required_version = ">= 1.5" } to pin the minimum Terraform version.',
            authority="Terraform Best Practices – Version pinning",
        )]

    def _t015(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-015 — Output with sensitive-looking name but sensitive = true not set."""
        _sensitive_name_pat = re.compile(
            r'(?:password|secret|token|key|credential)',
            re.IGNORECASE,
        )
        out = []
        for b in blocks:
            if b.kind != "output":
                continue
            if not _sensitive_name_pat.search(b.label1):
                continue
            val = b.attr_value("sensitive")
            if val is None or val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("sensitive") or b.start_line,
                    "PROOFCTL-TF-T015", "Sensitive output missing sensitive = true",
                    Severity.WARNING,
                    f"Output '{b.label1}' appears to contain sensitive data but sensitive = true is not set — value appears in plan output and state",
                    hint="Add sensitive = true to the output block.",
                    authority="Terraform Security – Sensitive Outputs",
                ))
        return out


# ── Directory-level checker (cross-file rules) ───────────────────────────────


class TerraformDirChecker(HclDirChecker):
    """Cross-file Terraform checks: M-001 SG mixing, A-002 S3 public access block."""

    def check(self, root: Path, hcl_files: list[Path]) -> list[Finding]:
        tf_files = [f for f in hcl_files if f.suffix == ".tf"]
        out: list[Finding] = []
        out += self._m001(tf_files)
        out += self._a002(tf_files)
        return out

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _f(
        path: Path,
        line: int | None,
        rule_id: str,
        rule_name: str,
        severity: Severity,
        message: str,
        hint: str = "",
    ) -> Finding:
        return Finding(
            file=str(path), line=line, col=None,
            rule_id=rule_id, rule_name=rule_name,
            severity=severity, message=message, hint=hint,
        )

    def _m001(self, tf_files: list[Path]) -> list[Finding]:
        """M-001 — aws_security_group with inline rules AND standalone aws_security_group_rule."""
        # Collect SG names that have inline ingress/egress, per directory.
        from collections import defaultdict
        sg_with_inline: dict[Path, dict[str, int]] = defaultdict(dict)  # dir → {sg_id: line}
        sg_rule_refs: dict[Path, list[tuple[str, int, Path]]] = defaultdict(list)  # dir → [(sg_id, line, file)]

        for path in tf_files:
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            blocks = parse_blocks(source)
            d = path.parent
            for b in blocks:
                if b.kind == "resource" and b.label1 == "aws_security_group":
                    if b.contains(r'\b(?:ingress|egress)\s*\{'):
                        sg_with_inline[d][b.label2] = b.start_line
                elif b.kind == "resource" and b.label1 == "aws_security_group_rule":
                    sg_id_val = b.attr_value("security_group_id") or ""
                    # e.g. security_group_id = aws_security_group.web.id
                    ref_m = re.search(r'aws_security_group\.(\w+)\.id', sg_id_val)
                    if ref_m:
                        sg_rule_refs[d].append((ref_m.group(1), b.start_line, path))

        out: list[Finding] = []
        for d, sg_map in sg_with_inline.items():
            for sg_name, sg_ref_line, ref_path in sg_rule_refs.get(d, []):
                if sg_name in sg_map:
                    out.append(self._f(
                        ref_path, sg_ref_line,
                        "PROOFCTL-TF-M001", "Security group rule mixing",
                        Severity.ERROR,
                        f'aws_security_group_rule references "{sg_name}" which already has inline ingress/egress — causes permanent plan diff',
                        hint="Use EITHER inline ingress/egress blocks OR standalone aws_security_group_rule resources, not both.",
                    ))
        return out

    def _a002(self, tf_files: list[Path]) -> list[Finding]:
        """A-002 — S3 bucket without companion aws_s3_bucket_public_access_block."""
        from collections import defaultdict
        buckets: dict[Path, dict[str, tuple[int, Path]]] = defaultdict(dict)  # dir → {name: (line, path)}
        pab_refs: dict[Path, set[str]] = defaultdict(set)   # dir → {bucket_id}

        for path in tf_files:
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            blocks = parse_blocks(source)
            d = path.parent
            for b in blocks:
                if b.kind == "resource" and b.label1 == "aws_s3_bucket":
                    buckets[d][b.label2] = (b.start_line, path)
                elif b.kind == "resource" and b.label1 == "aws_s3_bucket_public_access_block":
                    bucket_val = b.attr_value("bucket") or ""
                    ref_m = re.search(r'aws_s3_bucket\.(\w+)\.', bucket_val)
                    if ref_m:
                        pab_refs[d].add(ref_m.group(1))

        out: list[Finding] = []
        for d, bkt_map in buckets.items():
            covered = pab_refs.get(d, set())
            for bkt_name, (lineno, bkt_path) in bkt_map.items():
                if bkt_name not in covered:
                    out.append(self._f(
                        bkt_path, lineno,
                        "PROOFCTL-TF-A002", "S3 bucket missing public access block",
                        Severity.ERROR,
                        f'aws_s3_bucket "{bkt_name}" has no companion aws_s3_bucket_public_access_block',
                        hint="Add aws_s3_bucket_public_access_block with all four settings = true.",
                    ))
        return out
