from __future__ import annotations

import ast
import re
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker

# Regex patterns for constructs that cause SyntaxError in Python
# (applied before / instead of AST parsing)
_PRE_PARSE_PATTERNS: list[tuple[str, re.Pattern, str, str, str]] = [
    # (sub_rule, pattern, message, hint, authority)
    (
        "PROOFCTL-L-001",
        re.compile(r"\btypeof\s+\w+"),
        "JS `typeof` operator in Python",
        "Use isinstance(x, type) instead.",
        "L-001f",
    ),
    (
        "PROOFCTL-L-001",
        re.compile(r"===|!=="),
        "JS strict equality operator (===) in Python",
        "Use == or != (Python has no type coercion to avoid).",
        "L-001g",
    ),
    (
        "PROOFCTL-L-001",
        re.compile(r"(?<![=<>!])\b\w+\s*=>\s*\w"),
        "JS arrow function syntax in Python",
        "Use lambda x: x + 1 or a def.",
        "L-001h",
    ),
    (
        "PROOFCTL-L-001",
        re.compile(r"^\s*(var|let|const)\s+\w+\s*=", re.MULTILINE),
        "JS variable declaration keyword in Python",
        "Remove var/let/const — Python variables need no declaration keyword.",
        "L-001i",
    ),
]

# AST-based: method/attribute names that indicate wrong-language idiom
_JS_ATTR_NAMES = {
    "push": ("Use list.append(x) instead of .push(x).", "PROOFCTL-L-001"),
    "length": ("Use len(x) instead of .length.", "PROOFCTL-L-001"),
}
_JS_CALL_NAMES = {
    "console": {"log", "warn", "error", "info", "debug"},
}
_JS_IDENTIFIERS = {"null", "undefined"}

_JAVA_CALL_ATTRS = {
    "equals": ("Use == or is for equality in Python.", "PROOFCTL-L-002"),
    "toString": ("Use str(x) instead of .toString().", "PROOFCTL-L-002"),
    "size": ("Use len(x) instead of .size().", "PROOFCTL-L-002"),
}
_JAVA_SYSTEM_CHAIN = ("System", "out", {"println", "print", "printf"})

_GO_IDENTIFIERS = {"nil"}
_GO_FMT_CALLS = {"Println", "Printf", "Fprintf", "Sprintf", "Errorf", "Print"}


class _LeakageVisitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _find(self, node: ast.AST, rule_id: str, rule_name: str, msg: str, hint: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=getattr(node, "lineno", None),
            col=getattr(node, "col_offset", None),
            rule_id=rule_id,
            rule_name=rule_name,
            severity=Severity.ERROR,
            message=msg,
            hint=hint,
            authority="Cross-language leakage — AI conflated Python with another language",
        ))

    def visit_Name(self, node: ast.Name) -> None:
        if node.id in _JS_IDENTIFIERS:
            self._find(
                node, "PROOFCTL-L-001", "JS identifier in Python",
                f"'{node.id}' is not a Python keyword — did you mean None?",
                f"Replace `{node.id}` with None.",
            )
        elif node.id in _GO_IDENTIFIERS:
            self._find(
                node, "PROOFCTL-L-003", "Go identifier in Python",
                f"'{node.id}' is not a Python keyword — did you mean None?",
                "Replace `nil` with None.",
            )
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        attr = node.attr

        # JS: .push(), .length
        if attr in _JS_ATTR_NAMES:
            hint, rule_id = _JS_ATTR_NAMES[attr]
            self._find(
                node, rule_id, f"JS attribute '.{attr}' in Python",
                f"'.{attr}' is a JavaScript idiom.",
                hint,
            )

        # JS: console.log / console.warn etc.
        elif (attr in _JS_CALL_NAMES.get(
                getattr(node.value, "id", ""), set())):
            self._find(
                node, "PROOFCTL-L-001", "JS console call in Python",
                f"console.{attr}() is JavaScript — use print() or logging.",
                "Replace with print() or import logging.",
            )

        # Java: .equals(), .toString(), .size()
        elif attr in _JAVA_CALL_ATTRS:
            hint, rule_id = _JAVA_CALL_ATTRS[attr]
            self._find(
                node, rule_id, f"Java method '.{attr}()' in Python",
                f"'.{attr}()' is a Java idiom.",
                hint,
            )

        # Java: System.out.println
        elif (isinstance(node.value, ast.Attribute)
              and attr in _JAVA_SYSTEM_CHAIN[2]
              and node.value.attr == _JAVA_SYSTEM_CHAIN[1]
              and isinstance(node.value.value, ast.Name)
              and node.value.value.id == _JAVA_SYSTEM_CHAIN[0]):
            self._find(
                node, "PROOFCTL-L-002", "Java System.out in Python",
                "System.out.println() is Java — use print() or logging.",
                "Replace with print() or import logging.",
            )

        # Go: fmt.Println etc.
        elif (attr in _GO_FMT_CALLS
              and isinstance(node.value, ast.Name)
              and node.value.id == "fmt"):
            self._find(
                node, "PROOFCTL-L-003", "Go fmt call in Python",
                f"fmt.{attr}() is Go — use print() or logging.",
                "Replace with print() or import logging.",
            )

        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        """PROOFCTL-L-002d: Java-style getter/setter pairs."""
        method_names = {
            n.name for n in ast.walk(node)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        java_getter_setters = {
            name for name in method_names
            if (name.startswith("get") or name.startswith("set"))
            and len(name) > 3
            and name[3].isupper()
        }
        # Flag the class once if it has 2+ getter/setter pairs with no @property
        has_property = any(
            "property" in {
                d.id if isinstance(d, ast.Name) else ""
                for d in n.decorator_list
            }
            for n in ast.walk(node)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        )
        if len(java_getter_setters) >= 2 and not has_property:
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-L-002",
                rule_name="Java getter/setter pattern in Python",
                severity=Severity.WARNING,
                message=(
                    f"Class '{node.name}' uses Java-style getter/setter methods "
                    f"({', '.join(sorted(java_getter_setters)[:4])})"
                ),
                hint="Use @property instead of explicit getX/setX methods.",
                authority="Effective Python Item 44 – Use @property",
            ))
        self.generic_visit(node)


class LeakageChecker(FileChecker):
    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        findings: list[Finding] = []
        if tree is None:
            # File has a SyntaxError — pre-parse regex scan is safe because any
            # match on these patterns represents real cross-language leakage, not
            # content inside a string literal.
            findings.extend(self._pre_parse_scan(path, source))
        else:
            # File parses as valid Python.  All pre-parse patterns (const, ===,
            # typeof, arrow functions) are SyntaxErrors in Python — if they match
            # they MUST be inside a string literal, not live code.  Skip to avoid
            # false positives on files that embed other languages as strings
            # (e.g. HTML reporters, template generators).
            v = _LeakageVisitor(path)
            v.visit(tree)
            findings.extend(v.findings)
        return findings

    def _pre_parse_scan(self, path: Path, source: str) -> list[Finding]:
        """Regex scan for patterns that cause SyntaxError in Python."""
        findings = []
        for rule_id, pattern, msg, hint, _ in _PRE_PARSE_PATTERNS:
            for m in pattern.finditer(source):
                lineno = source.count("\n", 0, m.start()) + 1
                col = m.start() - source.rfind("\n", 0, m.start()) - 1
                findings.append(Finding(
                    file=str(path),
                    line=lineno,
                    col=col,
                    rule_id=rule_id,
                    rule_name="Cross-language syntax leakage",
                    severity=Severity.ERROR,
                    message=msg,
                    hint=hint,
                    authority="Cross-language leakage — AI conflated Python with another language",
                ))
        return findings
