from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Iterator

from ..models import Finding, Severity
from .base import FileChecker, DirectoryChecker

_MUTABLE_TYPES = frozenset({"list", "dict", "set", "defaultdict", "OrderedDict", "Counter"})
_ANY_IGNORE_RE = re.compile(r"#\s*type:\s*ignore(?!\s*\[)(?!\s*#)")
_TEST_PATH_COMPONENTS = frozenset({"tests", "test"})
_TEST_FILE_RE = re.compile(r"^(test_.+|.+_test)\.py$")


def _is_test_file(path: Path) -> bool:
    return (
        any(p in _TEST_PATH_COMPONENTS for p in path.parts)
        or bool(_TEST_FILE_RE.match(path.name))
    )


def _is_mutable_default(node: ast.expr) -> bool:
    if isinstance(node, (ast.List, ast.Dict, ast.Set)):
        return True
    if isinstance(node, ast.Call):
        func = node.func
        name = func.id if isinstance(func, ast.Name) else (
            func.attr if isinstance(func, ast.Attribute) else None
        )
        if name in _MUTABLE_TYPES:
            return True
    return False


class _Q001Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        args = node.args
        # defaults align to the LAST N positional args; kw_defaults align to kwargs
        defaults = args.defaults
        kwdefaults = [d for d in (args.kw_defaults or []) if d is not None]

        all_defaults = list(defaults) + list(kwdefaults)
        for default in all_defaults:
            if _is_mutable_default(default):
                type_name = (
                    type(default).__name__
                    if isinstance(default, (ast.List, ast.Dict, ast.Set))
                    else (default.func.id if isinstance(default.func, ast.Name) else "mutable")
                )
                self.findings.append(Finding(
                    file=str(self.path),
                    line=default.lineno,
                    col=default.col_offset,
                    rule_id="PROOFCTL-Q-001",
                    rule_name="Mutable default argument",
                    severity=Severity.ERROR,
                    message=(
                        f"'{node.name}' has a mutable {type_name} default argument — "
                        "shared across all calls"
                    ),
                    hint="Use None as default and initialize inside the function body.",
                    authority="Python Gotchas – Mutable Default Arguments",
                    fixable=True,
                ))


class _Q002Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        bare = node.type is None
        broad = (
            node.type is not None
            and isinstance(node.type, ast.Name)
            and node.type.id in ("Exception", "BaseException")
        )
        if not (bare or broad):
            self.generic_visit(node)
            return

        # Check if body is just pass / just a log call
        body = node.body
        is_suppressed = (
            len(body) == 1
            and isinstance(body[0], ast.Pass)
        )
        is_log_only = (
            len(body) == 1
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Call)
        )
        # Re-raise is fine
        has_raise = any(isinstance(s, ast.Raise) for s in ast.walk(ast.Module(body=body, type_ignores=[])))

        if has_raise:
            self.generic_visit(node)
            return

        if bare:
            rule_id = "PROOFCTL-Q-002"
            sev = Severity.ERROR
            msg = "Bare except: catches KeyboardInterrupt, SystemExit, and all exceptions silently"
            hint = "Catch specific exceptions: except (ValueError, KeyError) as e:"
        elif is_suppressed or is_log_only:
            rule_id = "PROOFCTL-Q-002"
            sev = Severity.WARNING
            msg = "Broad except Exception with no re-raise swallows all errors"
            hint = "Catch specific exceptions or re-raise: except Exception as e: ... raise"
        else:
            self.generic_visit(node)
            return

        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id=rule_id,
            rule_name="Broad exception handler",
            severity=sev,
            message=msg,
            hint=hint,
            authority="OWASP A10:2025 – Mishandling of Exceptional Conditions",
        ))
        self.generic_visit(node)


class _Q003Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.any_uses: list[ast.AST] = []

    def visit_Name(self, node: ast.Name) -> None:
        if node.id == "Any":
            self.any_uses.append(node)
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr == "Any":
            self.any_uses.append(node)
        self.generic_visit(node)


class _AbstractClassInfo:
    def __init__(self, node: ast.ClassDef, file: str):
        self.node = node
        self.file = file
        self.name = node.name
        self.bases: set[str] = set()
        for base in node.bases:
            if isinstance(base, ast.Name):
                self.bases.add(base.id)
            elif isinstance(base, ast.Attribute):
                self.bases.add(base.attr)
        self.has_abstract_method = any(
            "abstractmethod" in {
                d.id if isinstance(d, ast.Name) else
                d.attr if isinstance(d, ast.Attribute) else ""
                for d in n.decorator_list
            }
            for n in ast.walk(node)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        )
        self.is_abc = (
            "ABC" in self.bases
            or "Protocol" in self.bases
            or self.has_abstract_method
        )


# ── Q-005: cyclomatic complexity ──────────────────────────────────────────────

def _walk_no_nested(node: ast.AST) -> Iterator[ast.AST]:
    """Yield all descendant nodes, not descending into nested function/class defs."""
    yield node
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue  # nested scope — counted separately
        yield from _walk_no_nested(child)


def _cyclomatic_complexity(func: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    complexity = 1
    for node in _walk_no_nested(func):
        if node is func:
            continue
        if isinstance(node, (ast.If, ast.While, ast.For, ast.AsyncFor)):
            complexity += 1
        elif isinstance(node, ast.ExceptHandler):
            complexity += 1
        elif isinstance(node, ast.BoolOp):
            complexity += len(node.values) - 1
        elif isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            complexity += 1
    return complexity


class _Q005Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_threshold: int, error_threshold: int):
        self.path = path
        self.warn = warn_threshold
        self.error = error_threshold
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        cc = _cyclomatic_complexity(node)
        if cc > self.warn:
            sev = Severity.ERROR if cc > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-005",
                rule_name="High cyclomatic complexity",
                severity=sev,
                message=f"'{node.name}' has cyclomatic complexity {cc} (threshold: {self.warn})",
                hint=(
                    "Break the function into smaller, single-purpose functions. "
                    "Each branch is a candidate for extraction."
                ),
                authority="Clean Code Ch. 3 – Functions / McCabe 1976",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-006: function too long ──────────────────────────────────────────────────

class _Q006Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_lines: int, error_lines: int):
        self.path = path
        self.warn = warn_lines
        self.error = error_lines
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if node.end_lineno is None:
            return
        length = node.end_lineno - node.lineno
        if length > self.warn:
            sev = Severity.ERROR if length > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-006",
                rule_name="Function too long",
                severity=sev,
                message=f"'{node.name}' is {length} lines long (threshold: {self.warn})",
                hint="Extract logical sub-steps into well-named helper functions.",
                authority="Clean Code Ch. 3 – Functions should be small",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-007: too many function parameters ──────────────────────────────────────

class _Q007Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_params: int, error_params: int):
        self.path = path
        self.warn = warn_params
        self.error = error_params
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        args = node.args
        params = list(args.posonlyargs) + list(args.args)
        # Remove self / cls for methods
        if params and params[0].arg in ("self", "cls"):
            params = params[1:]
        count = len(params)
        if count > self.warn:
            sev = Severity.ERROR if count > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-007",
                rule_name="Too many function parameters",
                severity=sev,
                message=f"'{node.name}' has {count} parameters (threshold: {self.warn})",
                hint=(
                    "Group related parameters into a dataclass or config object. "
                    "Clean Code: ideal is 0–2 args; >3 needs justification."
                ),
                authority="Clean Code Ch. 3 – Function Arguments",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-008: boolean flag argument ─────────────────────────────────────────────

class _Q008Visitor(ast.NodeVisitor):
    """Flag True/False passed as a *positional* argument — indicates a function does two things."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        # Skip common false positives: bool(), int(), str(), print(), assert*
        _SKIP = frozenset({"bool", "int", "str", "float", "print", "append", "assertEqual", "assertTrue", "assertFalse"})
        func_name = (
            node.func.id if isinstance(node.func, ast.Name)
            else node.func.attr if isinstance(node.func, ast.Attribute)
            else None
        )
        if func_name in _SKIP or (func_name and func_name.startswith("assert")):
            self.generic_visit(node)
            return

        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, bool):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=arg.lineno,
                    col=arg.col_offset,
                    rule_id="PROOFCTL-Q-008",
                    rule_name="Boolean flag argument",
                    severity=Severity.WARNING,
                    message=(
                        f"Boolean literal passed as positional argument to "
                        f"'{func_name or 'function'}' — signals the function does two things"
                    ),
                    hint=(
                        "Split into two clearly named functions, or use a keyword argument: "
                        "func(reverse=True)."
                    ),
                    authority="Clean Code Ch. 3 – Flag Arguments",
                ))
                break  # one finding per call site
        self.generic_visit(node)


# ── Q-009: print() in production code ────────────────────────────────────────

class _Q009Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        if isinstance(node.func, ast.Name) and node.func.id == "print":
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-009",
                rule_name="print() in production code",
                severity=Severity.INFO,
                message="print() used in production code — output goes to stdout unstructured",
                hint="Use logging.info() / logging.debug() so output is structured and level-filtered.",
                authority="12-Factor App XI – Logs / Google SRE Book",
            ))
        self.generic_visit(node)


# ── Main checker ──────────────────────────────────────────────────────────────

class QualityChecker(FileChecker):
    def __init__(
        self,
        any_threshold: int = 3,
        complexity_warn: int = 10,
        complexity_error: int = 20,
        func_len_warn: int = 50,
        func_len_error: int = 100,
        param_warn: int = 5,
        param_error: int = 7,
    ) -> None:
        self._any_threshold = any_threshold
        self._complexity_warn = complexity_warn
        self._complexity_error = complexity_error
        self._func_len_warn = func_len_warn
        self._func_len_error = func_len_error
        self._param_warn = param_warn
        self._param_error = param_error

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        findings: list[Finding] = []
        if tree is not None:
            v1 = _Q001Visitor(path)
            v1.visit(tree)
            findings.extend(v1.findings)

            v2 = _Q002Visitor(path)
            v2.visit(tree)
            findings.extend(v2.findings)

            findings.extend(self._q003_ast(path, tree))

            v5 = _Q005Visitor(path, self._complexity_warn, self._complexity_error)
            v5.visit(tree)
            findings.extend(v5.findings)

            v6 = _Q006Visitor(path, self._func_len_warn, self._func_len_error)
            v6.visit(tree)
            findings.extend(v6.findings)

            v7 = _Q007Visitor(path, self._param_warn, self._param_error)
            v7.visit(tree)
            findings.extend(v7.findings)

            v8 = _Q008Visitor(path)
            v8.visit(tree)
            findings.extend(v8.findings)

            if not _is_test_file(path):
                v9 = _Q009Visitor(path)
                v9.visit(tree)
                findings.extend(v9.findings)

        findings.extend(self._q003_type_ignore(path, source))
        return findings

    def _q003_ast(self, path: Path, tree: ast.Module) -> list[Finding]:
        v = _Q003Visitor(path)
        v.visit(tree)
        count = len(v.any_uses)
        if count > self._any_threshold:
            first = v.any_uses[0]
            return [Finding(
                file=str(path),
                line=getattr(first, "lineno", None),
                col=getattr(first, "col_offset", None),
                rule_id="PROOFCTL-Q-003",
                rule_name="Excessive Any type usage",
                severity=Severity.INFO,
                message=f"File uses Any {count} times (threshold: {self._any_threshold})",
                hint="Replace Any with specific types to maintain type safety.",
                authority="Effective Python Item 90 – Consider Static Analysis",
            )]
        return []

    def _q003_type_ignore(self, path: Path, source: str) -> list[Finding]:
        findings = []
        for lineno, line in enumerate(source.splitlines(), start=1):
            m = _ANY_IGNORE_RE.search(line)
            if m:
                findings.append(Finding(
                    file=str(path),
                    line=lineno,
                    col=m.start(),
                    rule_id="PROOFCTL-Q-003",
                    rule_name="Unexplained type: ignore",
                    severity=Severity.WARNING,
                    message="# type: ignore without a reason or error code",
                    hint="Add an error code: # type: ignore[import-untyped]",
                    authority="mypy docs – type: ignore comments",
                ))
        return findings


class AbstractionChecker(DirectoryChecker):
    """PROOFCTL-Q-004: Abstract classes with only one concrete implementation."""

    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        abstract_classes: dict[str, _AbstractClassInfo] = {}
        all_classes: dict[str, list[str]] = {}  # class_name -> list of base names

        for path in py_files:
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(source)
            except (OSError, SyntaxError):
                continue

            for node in ast.walk(tree):
                if not isinstance(node, ast.ClassDef):
                    continue
                info = _AbstractClassInfo(node, str(path))
                if info.is_abc:
                    abstract_classes[info.name] = info
                else:
                    base_names = list(info.bases)
                    all_classes[info.name] = base_names

        findings = []
        for abc_name, abc_info in abstract_classes.items():
            if "Protocol" in abc_info.bases:
                continue
            implementors = [
                name for name, bases in all_classes.items()
                if abc_name in bases
            ]
            if len(implementors) == 1:
                findings.append(Finding(
                    file=abc_info.file,
                    line=abc_info.node.lineno,
                    col=abc_info.node.col_offset,
                    rule_id="PROOFCTL-Q-004",
                    rule_name="Single-implementation abstraction",
                    severity=Severity.INFO,
                    message=(
                        f"Abstract class '{abc_name}' has exactly one concrete "
                        f"implementation ('{implementors[0]}')"
                    ),
                    hint=(
                        "If no second implementation is planned, simplify to a "
                        "concrete class. YAGNI."
                    ),
                    authority="A Philosophy of Software Design – Deep Modules",
                ))
        return findings
