from __future__ import annotations

import ast
import re
import tokenize
import io
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker

_TODO_RE = re.compile(r"(?i)\b(TODO|FIXME|HACK|XXX|TEMP|PLACEHOLDER|REMOVEME)\b")

_SKIP_NAMES = frozenset({
    "__init__", "__init_subclass__", "__class_getitem__",
    "__set_name__", "setUp", "tearDown", "setUpClass", "tearDownClass",
})


def _annotation_excludes_none(returns: ast.expr | None) -> bool:
    """True only when the annotation is a concrete type that cannot be None.

    We use the conservative direction: if there is any ambiguity (no annotation,
    Optional, X | None, Union[X, None]) we return False so we don't flag.
    """
    if returns is None:
        return False  # no annotation — can't be sure
    # -> None  (explicit None return type)
    if isinstance(returns, ast.Constant) and returns.value is None:
        return False
    if isinstance(returns, ast.Name) and returns.id == "None":
        return False
    # -> Optional[X]
    if isinstance(returns, ast.Subscript) and isinstance(returns.value, ast.Name):
        if returns.value.id in ("Optional", "Union"):
            return False
    # -> X | None  or  None | X  (Python 3.10+ union syntax)
    if isinstance(returns, ast.BinOp) and isinstance(returns.op, ast.BitOr):
        for operand in (returns.left, returns.right):
            if isinstance(operand, ast.Constant) and operand.value is None:
                return False
            if isinstance(operand, ast.Name) and operand.id == "None":
                return False
    # -> Any  (Any is a supertype that includes None — don't flag)
    if isinstance(returns, ast.Name) and returns.id == "Any":
        return False
    if isinstance(returns, ast.Attribute) and returns.attr == "Any":
        return False
    return True


def _decorator_names(func: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
    names = set()
    for d in func.decorator_list:
        if isinstance(d, ast.Name):
            names.add(d.id)
        elif isinstance(d, ast.Attribute):
            names.add(d.attr)
    return names


def _is_docstring_stmt(stmt: ast.stmt) -> bool:
    return (
        isinstance(stmt, ast.Expr)
        and isinstance(stmt.value, ast.Constant)
        and isinstance(stmt.value.value, str)
    )


def _is_protocol_class(node: ast.ClassDef) -> bool:
    for base in node.bases:
        if isinstance(base, ast.Name) and base.id == "Protocol":
            return True
        if isinstance(base, ast.Attribute) and base.attr == "Protocol":
            return True
    return False


def _classify_body(stmts: list[ast.stmt]) -> tuple[str, Severity] | None:
    non_ds = [s for s in stmts if not _is_docstring_stmt(s)]

    if not non_ds and stmts:
        return ("docstring-only", Severity.WARNING)

    if len(non_ds) == 1:
        s = non_ds[0]
        if isinstance(s, ast.Pass):
            return ("pass", Severity.ERROR)
        if isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant) and s.value.value is ...:
            return ("ellipsis", Severity.ERROR)
        if isinstance(s, ast.Raise) and s.exc is not None:
            exc = s.exc
            if isinstance(exc, ast.Name) and exc.id == "NotImplementedError":
                return ("raise NotImplementedError", Severity.ERROR)
            if (isinstance(exc, ast.Call)
                    and isinstance(exc.func, ast.Name)
                    and exc.func.id == "NotImplementedError"):
                return ("raise NotImplementedError", Severity.ERROR)
        if (isinstance(s, ast.Return)
                and (s.value is None
                     or (isinstance(s.value, ast.Constant) and s.value.value is None))):
            return ("return None", Severity.WARNING)

    return None


class _P001Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []
        self._protocol_stack: list[bool] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._protocol_stack.append(_is_protocol_class(node))
        self.generic_visit(node)
        self._protocol_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def _in_protocol(self) -> bool:
        return bool(self._protocol_stack) and self._protocol_stack[-1]

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if self._in_protocol():
            return
        if node.name in _SKIP_NAMES:
            return
        dec_names = _decorator_names(node)
        if dec_names & {"abstractmethod", "overload"}:
            return

        result = _classify_body(node.body)
        if result is None:
            return

        body_desc, sev = result

        # "return None" is only suspicious when the annotation explicitly
        # promises a concrete non-None type.  Without an annotation, or when
        # the signature already declares None / Optional, it's not a bug.
        if body_desc == "return None" and not _annotation_excludes_none(node.returns):
            return

        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-P-001",
            rule_name="Unimplemented function body",
            severity=sev,
            message=f"'{node.name}' body is {body_desc}",
            hint="Implement or mark @abstractmethod / Protocol if intentionally abstract.",
            authority="Clean Code Ch. 3 – Functions",
        ))


class PlaceholderChecker(FileChecker):
    def __init__(self, todo_allowed_formats: list[str] | None = None,
                 todo_exclude_paths: list[str] | None = None) -> None:
        self._todo_allowed = todo_allowed_formats or []
        self._todo_exclude = todo_exclude_paths or ["tests/", "migrations/", "scripts/"]

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        findings: list[Finding] = []
        if tree is not None:
            findings.extend(self._p001(path, tree))
        findings.extend(self._p002(path, source))
        findings.extend(self._p003(path, source))
        return findings

    def _p001(self, path: Path, tree: ast.Module) -> list[Finding]:
        v = _P001Visitor(path)
        v.visit(tree)
        return v.findings

    def _p002(self, path: Path, source: str) -> list[Finding]:
        parts = path.parts
        if any(ex.rstrip("/\\") in parts for ex in self._todo_exclude):
            return []

        findings = []
        for lineno, line in enumerate(source.splitlines(), start=1):
            # Only scan comment portions (after #)
            comment_start = line.find("#")
            if comment_start == -1:
                continue
            comment = line[comment_start:]
            m = _TODO_RE.search(comment)
            if not m:
                continue
            if self._todo_allowed and any(
                re.search(pat, comment) for pat in self._todo_allowed
            ):
                continue
            findings.append(Finding(
                file=str(path),
                line=lineno,
                col=comment_start,
                rule_id="PROOFCTL-P-002",
                rule_name="TODO sentinel in production code",
                severity=Severity.WARNING,
                message=f"Untracked {m.group(1).upper()} comment: {comment.strip()[:80]}",
                hint="Replace with a tracked issue reference (e.g. TODO(#123)) or implement.",
                authority="The Pragmatic Programmer – No Broken Windows",
            ))
        return findings

    def _p003(self, path: Path, source: str) -> list[Finding]:
        """Find contiguous comment blocks that parse as valid Python (commented-out code)."""
        lines = source.splitlines()
        findings = []
        i = 0
        while i < len(lines):
            run_start = i
            run = []
            while i < len(lines) and lines[i].lstrip().startswith("#"):
                # Remove the leading `#` (and one optional space) while
                # preserving internal indentation for block structure.
                content = lines[i].lstrip()
                if content.startswith("# "):
                    content = content[2:]
                else:
                    content = content[1:]
                run.append(content)
                i += 1
            if len(run) >= 3:
                block = "\n".join(run)
                is_code = False
                try:
                    ast.parse(block)
                    is_code = True
                except SyntaxError:
                    # Try as a function body — handles return, yield, etc.
                    indented = "\n".join("    " + line for line in run)
                    try:
                        ast.parse(f"def _():\n{indented}")
                        is_code = True
                    except SyntaxError:
                        pass

                if is_code:
                    findings.append(Finding(
                        file=str(path),
                        line=run_start + 1,
                        col=0,
                        rule_id="PROOFCTL-P-003",
                        rule_name="Commented-out code block",
                        severity=Severity.INFO,
                        message=f"{len(run)}-line commented-out code block",
                        hint="Delete dead code — git history preserves it.",
                        authority="Clean Code Ch. 4 – Comments",
                    ))
            else:
                i += 1
        return findings
