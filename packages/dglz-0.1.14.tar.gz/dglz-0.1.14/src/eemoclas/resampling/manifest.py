"""Manifest helpers for resampled datasets."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def validate_manifest(manifest_path: str, expected_columns: list[str]) -> bool:
    """Validate that a manifest CSV contains the expected columns.

    Parameters
    ----------
    manifest_path : str
        Path to ``manifest.csv``.
    expected_columns : list[str]
        Column names that must be present.

    Returns
    -------
    bool
        ``True`` if all expected columns are present; ``False`` otherwise.
    """
    path = Path(manifest_path)
    if not path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    df = pd.read_csv(path)
    missing = set(expected_columns) - set(df.columns)
    if missing:
        return False
    return True


# ---------------------------------------------------------------------------
# Row builders
# ---------------------------------------------------------------------------


def build_subject_state_manifest_row(
    sample_id: str,
    sample_path: str,
    subject_id: str,
    group_label: int,
    num_trials: int,
    c_eff: int,
    length: int,
    seed: int,
    source_segments: str,
    trial_segment_ids: str,
    trial_emotion_labels: str,
    raw_sample_path: str = "",
) -> dict:
    """Build one row for the Classifier 1 (subject-state) manifest.

    Parameters
    ----------
    sample_id : str
        Unique sample identifier.
    sample_path : str
        Path to the ``.pt`` file.
    subject_id : str
        Subject identifier.
    group_label : int
        0 = normal, 1 = depression.
    num_trials : int
        Number of trials (typically 8).
    c_eff : int
        Effective channel count after channel selection.
    length : int
        Temporal length of each trial in samples.
    seed : int
        Random seed used for this sample.
    source_segments : str
        JSON-encoded list of source segment identifiers.
    trial_segment_ids : str
        JSON-encoded list of trial segment IDs.
    trial_emotion_labels : str
        JSON-encoded list of per-trial emotion labels.
    raw_sample_path : str
        Path to the raw (unprocessed) ``.pt`` file, or empty string.

    Returns
    -------
    dict
        A single manifest row.
    """
    return {
        "sample_id": sample_id,
        "sample_path": sample_path,
        "subject_id": subject_id,
        "group_label": group_label,
        "num_trials": num_trials,
        "c_eff": c_eff,
        "length": length,
        "seed": seed,
        "source_segments": source_segments,
        "trial_segment_ids": trial_segment_ids,
        "trial_emotion_labels": trial_emotion_labels,
        "raw_sample_path": raw_sample_path,
    }


def build_emotion_manifest_row(
    sample_id: str,
    sample_path: str,
    subject_id: str,
    group_label: int,
    emotion_label: int,
    segment_id: str,
    center_seconds: float,
    start_sample: int,
    end_sample: int,
    c_eff: int,
    length: int,
    seed: int,
    raw_sample_path: str = "",
) -> dict:
    """Build one row for the Classifier 2 / 3 (emotion) manifest.

    Parameters
    ----------
    sample_id : str
        Unique sample identifier.
    sample_path : str
        Path to the ``.pt`` file.
    subject_id : str
        Subject identifier.
    group_label : int
        0 = normal, 1 = depression.
    emotion_label : int
        0 = neutral, 1 = positive.
    segment_id : str
        Identifier of the source segment.
    center_seconds : float
        Window centre in seconds.
    start_sample : int
        Start sample index.
    end_sample : int
        End sample index.
    c_eff : int
        Effective channel count after channel selection.
    length : int
        Temporal length in samples.
    seed : int
        Random seed used.
    raw_sample_path : str
        Path to the raw (unprocessed) ``.pt`` file, or empty string.

    Returns
    -------
    dict
        A single manifest row.
    """
    return {
        "sample_id": sample_id,
        "sample_path": sample_path,
        "subject_id": subject_id,
        "group_label": group_label,
        "emotion_label": emotion_label,
        "segment_id": segment_id,
        "center_seconds": center_seconds,
        "start_sample": start_sample,
        "end_sample": end_sample,
        "c_eff": c_eff,
        "length": length,
        "seed": seed,
        "raw_sample_path": raw_sample_path,
    }
