# dglzvr Agent Memory

## 核心目标

- Stage 1: subject_state → acc ≥ 95%, AUC ≥ 97%
- Stage 2: emotion classifiers → 同上
- 指标优先级: accuracy > AUC > macro_f1 (USER MANDATED)

## 当前最佳指标

- Stage 1: 尚未训练
- Stage 2: 尚未训练

## 核心发现

- 无（尚未开始实验）

## 未测试方向

- 所有方向均未测试

## 已确认死胡同

- 无

## 注意事项

- K-fold mean 不可直接与 holdout 单值对比
- 12GB GPU 限制 → 不可并行训练
- accuracy 为首要优化目标
