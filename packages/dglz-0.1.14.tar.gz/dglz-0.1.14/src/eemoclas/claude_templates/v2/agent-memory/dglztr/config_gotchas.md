# Config Gotchas (V2 Dual)

1. **--mode v2 必须传递**: 所有 skill 调用需要 `--mode v2` 参数。
2. **dual 模型需要 load_raw: true**: 配置文件中 `load_raw` 必须为 `true`，否则 dual 模型退化为单路。
3. **TSV target 名称**: V2 的 target 是 `dual_subject_state`、`dual_normal_emotion`、`dual_depression_emotion`，不是 `subject_state` 等。
4. **三阶段完全独立**: 无门控依赖，用户可选任意阶段开始训练。
5. **Fusion 参数在 model 层级**: `fusion_heads`、`fusion_layers`、`fusion_dropout` 在 `model_conf` 中配置。
6. **每个 stage 只生成 1 个配置**: 不再有 `-normal`/`-depression` 后缀。
7. **active_state.json 维护**: agent-state 脚本自动处理。
8. **experiment.name 必须唯一**: configs_creator 自动注入，configs_runner 也传 `--experiment-name`。
9. **--models 必须传递**: 不传则训练所有模型，超出 GPU 限制。
10. **TSV 列 JSON 是内部键**: `train_conf` 内容如 `{"learning_rate":0.0003}`。
11. **early_stopping_patience**: 配置字段在 training 层级，默认值 15。
12. **state 路径**: V2 所有 state 文件在 `.agent/v2/` 下。
