# Training Strategy (V2 Dual)

## Stage 1: dual_subject_state

**目标**: acc >= 95%, AUC >= 97%

**架构**: Trial-level 融合 (8 Raw + 8 PP 试次嵌入交错排列 16 tokens → Fusion Transformer)
融合 Transformer 同时完成跨模态交互和被试级别编码。

**调参维度**:
- learning_rate: [1e-4, 1e-3]
- weight_decay: [0.01, 0.1]
- optimizer: adam, adamw
- epochs: 50-200 (with early stopping, patience 15)
- scheduler: cosine, reduce_on_plateau
- fusion_heads: [2, 4, 8]
- fusion_dropout: [0.1, 0.3, 0.5]
- fusion_layers: [1, 2, 3]
- load_raw: true (dual model requires raw data)

**策略**: 先宽后窄 — 前几批搜索大范围 learning_rate 和 fusion 参数，后续微调

## Stage 2: dual_normal_emotion

**目标**: acc >= 95%, AUC >= 97%

**架构**: Late 融合 (Raw 试次特征 + PP 试次特征 → stack [2, D] → Fusion Transformer)
无 subject_transformer，直接使用 Fusion Transformer 融合两路特征后分类。

**调参维度**: 同 Stage 1

## Stage 3: dual_depression_emotion

**目标**: acc >= 95%, AUC >= 97%

**架构**: Late 融合 (同 dual_normal_emotion，分类头 dropout 略高以缓解过拟合)

**调参维度**: 同 Stage 1，注意：
- 分类头 dropout 可调更高（0.5-0.7）
- 数据量可能更少，更易过拟合
- 建议更高的 fusion_dropout
