# dglztr V2 Dual Agent Memory

## Key Parameters
- [training_strategy](training_strategy.md) — V2 dual model tuning ranges and strategies
- [config_gotchas](config_gotchas.md) — V2 dual config pitfalls and tips
