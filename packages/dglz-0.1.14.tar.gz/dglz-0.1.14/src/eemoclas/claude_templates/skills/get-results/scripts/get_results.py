#!/usr/bin/env python3
"""get_results.py - Extract structured metrics from DGLZ experiment outputs.

Usage:
    python .claude/skills/get-results/scripts/get_results.py \
        --experiments-dir experiments --exp-names b1-subj,b1-subj-kfold

Reads training_state.yaml, metrics CSV, and optional kfold_summary.yaml
from each experiment directory. Outputs structured JSON.
"""
import argparse
import csv
import json
import os
import sys
from pathlib import Path

import yaml


def extract_best_from_csv(csv_path: str) -> dict:
    """Extract best epoch metrics from metrics_history.csv.

    Best is determined by val_accuracy (highest).
    """
    if not os.path.isfile(csv_path):
        return {}

    rows = []
    with open(csv_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)

    if not rows:
        return {}

    # Find best row by val_accuracy
    best_row = max(rows, key=lambda r: float(r.get("val_accuracy", 0)))

    metrics = {}
    for key in ["val_accuracy", "val_auc", "val_macro_f1",
                "val_loss", "train_loss", "train_accuracy"]:
        val = best_row.get(key)
        if val is not None:
            try:
                metrics[key] = float(val)
            except (ValueError, TypeError):
                pass

    return {
        "best_metrics": metrics,
        "best_epoch": int(best_row.get("epoch", 0)),
        "total_epochs": len(rows),
    }


def detect_split_method(exp_dir: str, model_name: str) -> tuple[str, int | None]:
    """Detect holdout vs k-fold from kfold_summary.yaml existence."""
    kfold_path = os.path.join(exp_dir, "checkpoints", model_name, "kfold_summary.yaml")
    if os.path.isfile(kfold_path):
        with open(kfold_path, encoding="utf-8") as f:
            summary = yaml.safe_load(f) or {}
        return summary.get("method", "StratifiedGroupKFold"), summary.get("n_splits")
    return "holdout", None


def extract_kfold_metrics(exp_dir: str, model_name: str) -> dict | None:
    """Extract k-fold aggregated metrics from kfold_summary.yaml."""
    kfold_path = os.path.join(exp_dir, "checkpoints", model_name, "kfold_summary.yaml")
    if not os.path.isfile(kfold_path):
        return None

    with open(kfold_path, encoding="utf-8") as f:
        summary = yaml.safe_load(f) or {}

    aggregated = summary.get("aggregated", {})
    folds = summary.get("folds", {})

    # Find best fold by val_accuracy
    best_fold_idx = 0
    best_ba = 0.0
    best_fold_metrics = {}
    for fold_key, fold_data in folds.items():
        ba = fold_data.get("best_metrics", {}).get("val_accuracy", 0)
        if ba > best_ba:
            best_ba = ba
            best_fold_metrics = fold_data.get("best_metrics", {})
            idx_str = fold_key.replace("fold_", "")
            best_fold_idx = int(idx_str) if idx_str.isdigit() else 0

    return {
        "aggregated_metrics": aggregated,
        "best_fold_idx": best_fold_idx,
        "best_fold_metrics": best_fold_metrics,
    }


def extract_results(experiments_dir: str, exp_names: list[str]) -> list[dict]:
    """Extract results for specified experiments.

    Returns list of result dicts.
    """
    results = []
    for exp_name in exp_names:
        exp_dir = os.path.join(experiments_dir, exp_name)
        if not os.path.isdir(exp_dir):
            results.append({"exp_name": exp_name, "status": "not_found"})
            continue

        # Read training_state.yaml to get model names
        state_path = os.path.join(exp_dir, "training_state.yaml")
        if not os.path.isfile(state_path):
            results.append({"exp_name": exp_name, "status": "no_state"})
            continue

        with open(state_path, encoding="utf-8") as f:
            state = yaml.safe_load(f) or {}

        models = state.get("models", {})
        for model_name, model_state in models.items():
            model_status = model_state.get("status", "unknown")

            # Read metrics CSV
            csv_path = os.path.join(exp_dir, "metrics", f"{model_name}_history.csv")
            csv_metrics = extract_best_from_csv(csv_path)

            # Detect split method
            split_method, n_splits = detect_split_method(exp_dir, model_name)

            result = {
                "exp_name": exp_name,
                "model": model_name,
                "split_method": split_method,
                "status": model_status,
                **csv_metrics,
            }

            if n_splits is not None:
                result["n_splits"] = n_splits
                kfold = extract_kfold_metrics(exp_dir, model_name)
                if kfold:
                    result.update(kfold)

            results.append(result)

    return results


def main():
    parser = argparse.ArgumentParser(description="Extract DGLZ experiment results")
    parser.add_argument("--experiments-dir", default="experiments", help="Experiments root directory")
    parser.add_argument("--exp-names", required=True, help="Comma-separated experiment names")
    parser.add_argument("--stage", default=None, help="Current stage for best-experiment selection")
    parser.add_argument("--mode", default="v1", choices=["v1", "v2"], help="Agent mode (default: v1)")
    args = parser.parse_args()

    exp_names = [n.strip() for n in args.exp_names.split(",") if n.strip()]
    results = extract_results(args.experiments_dir, exp_names)

    # Auto-identify best experiment by val_accuracy
    valid = [r for r in results if r.get("best_metrics")]
    best = None
    if valid:
        best = max(valid, key=lambda r: r["best_metrics"].get("val_accuracy", 0))
        best_name = best["exp_name"]
    else:
        best_name = None

    output = {
        "experiments": results,
        "best_experiment": best_name,
        "stage": args.stage,
    }
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
