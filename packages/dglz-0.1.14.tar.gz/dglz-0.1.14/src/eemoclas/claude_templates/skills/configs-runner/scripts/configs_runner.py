#!/usr/bin/env python3
"""configs_runner.py - Batch run DGLZ training experiments sequentially.

Usage:
    python .claude/skills/configs-runner/scripts/configs_runner.py \
        --file .agent/dglztr/exp_conf_tsv/batch1.txt

Reads a batch TXT file (one line per experiment: config_path,exp_name).
Executes `eemo train` sequentially with --models and --experiment-name flags.
"""
import argparse
import json
import os
import subprocess
import sys
import time


def build_command(config_path: str, exp_name: str, target_model: str) -> list[str]:
    """Build the eemo train command."""
    return [
        "conda", "run", "-n", "dglz", "eemo", "train",
        "--config", config_path,
        "--models", target_model,
        "--experiment-name", exp_name,
    ]


def run_single_experiment(
    config_path: str,
    exp_name: str,
    target_model: str,
    timeout: int = 259200,
) -> dict:
    """Run a single training experiment.

    Returns dict with keys: name, status, time_seconds, error_preview.
    """
    cmd = build_command(config_path, exp_name, target_model)
    start = time.time()
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
        elapsed = time.time() - start
        if result.returncode != 0:
            output = (result.stdout + result.stderr)[-1000:]
            return {
                "name": exp_name,
                "status": "failed",
                "time_seconds": round(elapsed, 1),
                "error_preview": output,
            }
        return {
            "name": exp_name,
            "status": "success",
            "time_seconds": round(elapsed, 1),
        }
    except subprocess.TimeoutExpired:
        elapsed = time.time() - start
        return {
            "name": exp_name,
            "status": "timeout",
            "time_seconds": round(elapsed, 1),
            "error_preview": f"TIMEOUT after {timeout}s",
        }
    except Exception as e:
        elapsed = time.time() - start
        return {
            "name": exp_name,
            "status": "failed",
            "time_seconds": round(elapsed, 1),
            "error_preview": str(e),
        }


def read_batch_file(path: str) -> list[tuple[str, str]]:
    """Read batch TXT file. Returns list of (config_path, exp_name)."""
    experiments = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(",", 1)
            if len(parts) == 2:
                experiments.append((parts[0].strip(), parts[1].strip()))
    return experiments


def main():
    parser = argparse.ArgumentParser(description="Batch run DGLZ training experiments")
    parser.add_argument("--file", required=True, help="Batch TXT file path")
    parser.add_argument("--timeout", type=int, default=259200, help="Timeout per experiment in seconds (default: 259200 = 3 days)")
    parser.add_argument("--model", default=None, help="Target model override (default: auto-detect)")
    parser.add_argument("--mode", default="v1", choices=["v1", "v2"], help="Agent mode (default: v1)")
    parser.add_argument("--stage", default=None, help="Training stage (required for v2 mode)")
    parser.add_argument("--max", type=int, default=3, help="Max experiments to run (default: 3)")
    parser.add_argument("--verbose", action="store_true", help="Print progress")
    args = parser.parse_args()

    if not os.path.isfile(args.file):
        print(json.dumps({"error": f"File not found: {args.file}"}))
        sys.exit(1)

    experiments = read_batch_file(args.file)
    if not experiments:
        print(json.dumps({"error": "No experiments found in batch file"}))
        sys.exit(1)

    # Limit to max
    experiments = experiments[: args.max]

    print(f"Running {len(experiments)} experiments (timeout={args.timeout}s)...")

    results = []
    start_time = time.time()

    for config_path, exp_name in experiments:
        # Auto-detect target model from config name if not specified
        target_model = args.model
        if not target_model:
            if args.mode == "v2":
                stage_model_map = {
                    "stage1": "dual_subject_state",
                    "stage2": "dual_normal_emotion",
                    "stage3": "dual_depression_emotion",
                }
                target_model = stage_model_map.get(args.stage or "stage1", "dual_subject_state")
            else:
                if "-normal" in exp_name:
                    target_model = "normal_emotion"
                elif "-depression" in exp_name:
                    target_model = "depression_emotion"
                else:
                    target_model = "subject_state"

        if args.verbose:
            print(f"  Running: {exp_name} (model={target_model})")

        result = run_single_experiment(config_path, exp_name, target_model, timeout=args.timeout)
        results.append(result)

        if args.verbose:
            print(f"  {exp_name}: {result['status']} ({result['time_seconds']:.1f}s)")

    total_time = time.time() - start_time
    successful = sum(1 for r in results if r["status"] == "success")
    failed = len(results) - successful

    output = {
        "total": len(experiments),
        "successful": successful,
        "failed": failed,
        "total_time_seconds": round(total_time, 1),
        "experiments": results,
    }
    print(json.dumps(output, indent=2, ensure_ascii=False))

    if failed == len(experiments):
        sys.exit(1)


if __name__ == "__main__":
    main()
