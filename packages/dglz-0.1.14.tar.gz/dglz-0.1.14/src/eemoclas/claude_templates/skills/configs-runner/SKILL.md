---
name: configs-runner
description: |
  Sequential batch execution of DGLZ training experiments.
  Reads batch TXT file, runs eemo train for each config with --models and --experiment-name.
  Max 3 configs per run, 3-day timeout per config. Supports V1/V2 modes.
allowed-tools:
  - bash
metadata:
  language: zh-CN
  entrypoint: scripts/configs_runner.py
  outputs: "JSON execution statistics to stdout"
---

# Configs Runner Skill

## When to Use

When dglztr needs to execute training experiments (Step 3 of workflow).

## Usage

```bash
python .claude/skills/configs-runner/scripts/configs_runner.py \
    --mode v1 --file .agent/v1/dglztr/exp_conf_tsv/batch1.txt --verbose
```

## Key Flags

- `--file`: Batch TXT file (required)
- `--timeout`: Seconds per experiment (default: 259200 = 3 days)
- `--model`: Target model override (default: auto-detect)
- `--mode`: Agent mode: v1 or v2 (default: v1)
- `--stage`: Training stage (required for v2 mode)
- `--max`: Max experiments (default: 3)
- `--verbose`: Print progress

## Auto-Detection

If `--model` is not specified:
- V1 mode (default):
  - exp_name contains `-normal` → normal_emotion
  - exp_name contains `-depression` → depression_emotion
  - Otherwise → subject_state
- V2 mode:
  - stage1 → dual_subject_state
  - stage2 → dual_normal_emotion
  - stage3 → dual_depression_emotion
