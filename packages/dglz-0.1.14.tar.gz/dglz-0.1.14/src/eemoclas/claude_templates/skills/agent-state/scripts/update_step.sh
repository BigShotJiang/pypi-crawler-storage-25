#!/usr/bin/env bash
# update_step.sh - Update current workflow step.
# Usage: bash .claude/skills/agent-state/scripts/update_step.sh --mode v1|v2 <step> [status]
# Steps: plan, config, train, review, archive
set -euo pipefail

MODE="v1"
STEP=""
STATUS="running"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode) MODE="${2:?--mode requires a value}"; shift 2 ;;
        plan|config|train|review|archive)
            STEP="$1"; shift
            if [[ $# -gt 0 && "$1" != "--mode" && ! "$1" =~ ^(plan|config|train|review|archive)$ ]]; then
                STATUS="$1"; shift
            fi
            ;;
        *) echo "Unknown argument: $1" >&2; exit 1 ;;
    esac
done

if [[ -z "$STEP" ]]; then
    echo "Usage: update_step.sh --mode v1|v2 <step> [status]" >&2
    exit 1
fi

if [[ "$MODE" != "v1" && "$MODE" != "v2" ]]; then
    echo "ERROR: mode must be 'v1' or 'v2', got: $MODE" >&2
    exit 1
fi

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
AGENT_DIR="$ROOT/.agent"
STATE_FILE="$AGENT_DIR/$MODE/dglztr/current_batch.json"

if [ ! -f "$STATE_FILE" ]; then
    echo "ERROR: current_batch.json not found at $STATE_FILE" >&2
    exit 1
fi

# Update current_batch.json
python3 -c "
import json
with open('$STATE_FILE') as f:
    data = json.load(f)
data['step'] = '$STEP'
data['status'] = '$STATUS'
with open('$STATE_FILE', 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
print(f'Updated step to: $STEP (status: $STATUS)')
"

# Update active_state.json
python3 -c "
import json
from datetime import datetime
state_file = '$AGENT_DIR/active_state.json'
try:
    with open(state_file) as f:
        state = json.load(f)
except: state = {}
state['step'] = '$STEP'
state['updated_at'] = datetime.now().isoformat(timespec='seconds')
with open(state_file, 'w') as f:
    json.dump(state, f, indent=2, ensure_ascii=False)
"
