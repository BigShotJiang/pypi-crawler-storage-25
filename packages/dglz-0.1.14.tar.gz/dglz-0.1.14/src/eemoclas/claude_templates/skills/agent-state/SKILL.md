---
name: agent-state
description: |
  Manage DGLZ training agent state files and directory structure.
  Initialize .agent/ directories, create new batches, update workflow steps,
  and save review reports. Supports v1/v2 modes.
allowed-tools:
  - bash
metadata:
  language: zh-CN
  entrypoint: scripts/
---

# Agent State Skill

## When to Use

- Before starting any agent workflow (initialize state)
- When creating a new training batch
- When updating the current workflow step
- When saving a dglzvr analysis report

## Mode Parameter

All scripts accept `--mode v1` or `--mode v2` (default: v1):
- v1: State files stored in `.agent/v1/`
- v2: State files stored in `.agent/v2/`

## Scripts

### init_state.sh
```bash
bash .claude/skills/agent-state/scripts/init_state.sh --mode v2
```
Initializes `.agent/{mode}/` directory structure and `.agent/active_state.json`. Idempotent.

### new_batch.sh
```bash
bash .claude/skills/agent-state/scripts/new_batch.sh --mode v2 --batch 1 --stage stage1
```
Creates a new `current_batch.json` in `.agent/{mode}/dglztr/`. Updates `active_state.json`.
- V1 stages: `stage1`, `stage2`
- V2 stages: `stage1`, `stage2`, `stage3`

### update_step.sh
```bash
bash .claude/skills/agent-state/scripts/update_step.sh --mode v2 train
```
Updates current workflow step. Valid steps: `plan`, `config`, `train`, `review`, `archive`.

### save_review.sh
```bash
bash .claude/skills/agent-state/scripts/save_review.sh --mode v2 1 review.md
```
Copies review report to `.agent/{mode}/dglzvr/reviews/batch{N}_review.md`.
