#!/usr/bin/env bash
# new_batch.sh - Create a new training batch.
# Usage: bash .claude/skills/agent-state/scripts/new_batch.sh --mode v1|v2 --batch N --stage stage1|stage2|stage3 [--model MODEL]
set -euo pipefail

MODE="v1"
BATCH_NUM=""
STAGE=""
MODEL=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode) MODE="${2:?--mode requires a value}"; shift 2 ;;
        --batch) BATCH_NUM="${2:?--batch requires a value}"; shift 2 ;;
        --stage) STAGE="${2:?--stage requires a value}"; shift 2 ;;
        --model) MODEL="${2:?--model requires a value}"; shift 2 ;;
        *) echo "Unknown argument: $1" >&2; exit 1 ;;
    esac
done

if [[ -z "$BATCH_NUM" ]]; then echo "ERROR: --batch is required" >&2; exit 1; fi
if [[ -z "$STAGE" ]]; then echo "ERROR: --stage is required" >&2; exit 1; fi

# Validate mode
if [[ "$MODE" != "v1" && "$MODE" != "v2" ]]; then
    echo "ERROR: mode must be 'v1' or 'v2', got: $MODE" >&2
    exit 1
fi

# Validate batch number
if ! [[ "$BATCH_NUM" =~ ^[0-9]+$ ]] || [ "$BATCH_NUM" -lt 1 ]; then
    echo "ERROR: batch_number must be a positive integer, got: $BATCH_NUM" >&2
    exit 1
fi

# Validate stage per mode
if [[ "$MODE" == "v1" ]]; then
    if [[ "$STAGE" != "stage1" && "$STAGE" != "stage2" ]]; then
        echo "ERROR: V1 stage must be 'stage1' or 'stage2', got: $STAGE" >&2
        exit 1
    fi
else
    if [[ "$STAGE" != "stage1" && "$STAGE" != "stage2" && "$STAGE" != "stage3" ]]; then
        echo "ERROR: V2 stage must be 'stage1', 'stage2', or 'stage3', got: $STAGE" >&2
        exit 1
    fi
fi

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
AGENT_DIR="$ROOT/.agent"
MODE_DIR="$AGENT_DIR/$MODE"

# Determine default model from mode+stage
if [ -z "$MODEL" ]; then
    if [[ "$MODE" == "v1" ]]; then
        if [ "$STAGE" = "stage1" ]; then
            MODEL="subject_state"
        else
            MODEL="normal_emotion,depression_emotion"
        fi
    else
        case "$STAGE" in
            stage1) MODEL="dual_subject_state" ;;
            stage2) MODEL="dual_normal_emotion" ;;
            stage3) MODEL="dual_depression_emotion" ;;
        esac
    fi
fi

# Ensure mode directory exists
mkdir -p "$MODE_DIR/dglztr"

# Read previous current_batch for stage_completion if exists
STAGE_COMPLETION_JSON="{}"
if [ -f "$MODE_DIR/dglztr/current_batch.json" ]; then
    STAGE_COMPLETION_JSON=$(python3 -c "
import json
try:
    with open('$MODE_DIR/dglztr/current_batch.json') as f:
        data = json.load(f)
    print(json.dumps(data.get('stage_completion', {})))
except: print('{}')
" 2>/dev/null || echo '{}')
fi

# Write new current_batch.json
cat > "$MODE_DIR/dglztr/current_batch.json" << ENDJSON
{
  "batch": $BATCH_NUM,
  "stage": "$STAGE",
  "target_models": "$MODEL",
  "stage_target": {
    "acc": 0.95,
    "auc": 0.97
  },
  "stage_completion": $STAGE_COMPLETION_JSON,
  "current_best": {
    "acc": 0.0,
    "auc": 0.0,
    "exp_name": null
  },
  "experiments": {
    "total": 0,
    "completed": [],
    "pending": []
  },
  "step": "plan",
  "round": 1,
  "status": "planning"
}
ENDJSON

# Update active_state.json
python3 -c "
import json
from datetime import datetime
state_file = '$AGENT_DIR/active_state.json'
try:
    with open(state_file) as f:
        state = json.load(f)
except: state = {}
state.update({
    'mode': '$MODE',
    'stage': '$STAGE',
    'batch': $BATCH_NUM,
    'step': 'plan',
    'model': '$MODEL'.split(',')[0],
    'updated_at': datetime.now().isoformat(timespec='seconds'),
})
if 'started_at' not in state:
    state['started_at'] = state['updated_at']
with open(state_file, 'w') as f:
    json.dump(state, f, indent=2, ensure_ascii=False)
"

echo "Created batch $BATCH_NUM (mode=$MODE, stage=$STAGE, model=$MODEL)"
cat "$MODE_DIR/dglztr/current_batch.json"
