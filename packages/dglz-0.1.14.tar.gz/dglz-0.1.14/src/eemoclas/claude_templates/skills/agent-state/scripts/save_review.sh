#!/usr/bin/env bash
# save_review.sh - Save dglzvr analysis report.
# Usage: bash .claude/skills/agent-state/scripts/save_review.sh --mode v1|v2 <batch_number> <report_file>
set -euo pipefail

MODE="v1"
BATCH_NUM=""
REPORT_FILE=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode) MODE="${2:?--mode requires a value}"; shift 2 ;;
        *)
            if [[ -z "$BATCH_NUM" ]]; then
                BATCH_NUM="$1"; shift
            elif [[ -z "$REPORT_FILE" ]]; then
                REPORT_FILE="$1"; shift
            else
                shift
            fi
            ;;
    esac
done

if [[ -z "$BATCH_NUM" || -z "$REPORT_FILE" ]]; then
    echo "Usage: save_review.sh --mode v1|v2 <batch_number> <report_file>" >&2
    exit 1
fi

if [[ "$MODE" != "v1" && "$MODE" != "v2" ]]; then
    echo "ERROR: mode must be 'v1' or 'v2', got: $MODE" >&2
    exit 1
fi

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
REVIEWS_DIR="$ROOT/.agent/$MODE/dglzvr/reviews"

mkdir -p "$REVIEWS_DIR"

if [ ! -f "$REPORT_FILE" ]; then
    echo "ERROR: Report file not found: $REPORT_FILE" >&2
    exit 1
fi

DEST="$REVIEWS_DIR/batch${BATCH_NUM}_review.md"
cp "$REPORT_FILE" "$DEST"
echo "Review saved to: $DEST"
