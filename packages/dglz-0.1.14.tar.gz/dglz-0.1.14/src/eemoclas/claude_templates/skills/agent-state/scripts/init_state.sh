#!/usr/bin/env bash
# init_state.sh - Initialize .agent/ directory structure for DGLZ training agents.
# Usage: bash .claude/skills/agent-state/scripts/init_state.sh [--mode v1|v2]
set -euo pipefail

MODE="v1"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode) MODE="${2:?--mode requires a value}"; shift 2 ;;
        *) echo "Unknown argument: $1" >&2; exit 1 ;;
    esac
done

if [[ "$MODE" != "v1" && "$MODE" != "v2" ]]; then
    echo "ERROR: mode must be 'v1' or 'v2', got: $MODE" >&2
    exit 1
fi

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
AGENT_DIR="$ROOT/.agent"
MODE_DIR="$AGENT_DIR/$MODE"

echo "Initializing agent state at: $AGENT_DIR (mode=$MODE)"

# Create mode-specific directory structure (idempotent)
mkdir -p "$MODE_DIR/dglztr/exp_conf_tsv"
mkdir -p "$MODE_DIR/dglztr/failed/configs"
mkdir -p "$MODE_DIR/dglztr/failed/training"
mkdir -p "$MODE_DIR/dglzvr/reviews"

# Initialize history_batch.json if missing
if [ ! -f "$MODE_DIR/dglztr/history_batch.json" ]; then
    echo '[]' > "$MODE_DIR/dglztr/history_batch.json"
    echo "Created history_batch.json"
else
    echo "history_batch.json already exists, skipping"
fi

# Initialize current_batch.json if missing
if [ ! -f "$MODE_DIR/dglztr/current_batch.json" ]; then
    echo '{}' > "$MODE_DIR/dglztr/current_batch.json"
    echo "Created current_batch.json"
else
    echo "current_batch.json already exists, skipping"
fi

# Initialize active_state.json if missing
if [ ! -f "$AGENT_DIR/active_state.json" ]; then
    TIMESTAMP=$(python3 -c "from datetime import datetime; print(datetime.now().isoformat(timespec='seconds'))")
    cat > "$AGENT_DIR/active_state.json" << ENDJSON
{
  "mode": "$MODE",
  "stage": null,
  "batch": null,
  "step": null,
  "model": null,
  "started_at": "$TIMESTAMP",
  "updated_at": "$TIMESTAMP"
}
ENDJSON
    echo "Created active_state.json"
else
    echo "active_state.json already exists, skipping"
fi

echo "Agent state initialized (mode=$MODE)."
