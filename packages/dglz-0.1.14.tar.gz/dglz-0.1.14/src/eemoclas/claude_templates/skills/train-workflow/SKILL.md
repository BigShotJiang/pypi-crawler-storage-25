---
name: train-workflow
description: |
  Master workflow specification for dglztr agent.
  Defines the 5-step training cycle (Plan→Config→Train→Review→Archive),
  stage targets, metrics priority, error handling, and k-fold rules.
  Supports V1 (2-stage) and V2 (3-stage dual) modes.
allowed-tools:
  - bash
  - Agent
metadata:
  language: zh-CN
---

# DGLZ Training Workflow

## Mode Selection

This workflow supports two modes, selected via `--mode` parameter:

### V1 Mode (2-Stage Single-Branch)

| Stage | Model | Target acc | Target AUC |
|-------|-------|-----------|------------|
| Stage 1 | subject_state | >= 95% | >= 97% |
| Stage 2 | normal_emotion + depression_emotion | >= 95% | >= 97% |

- Stage 2 requires Stage 1 completion (gate control)
- Stage 2 generates 2 configs per TSV row (-normal/-deprecation suffix)
- State path: `.agent/v1/`

### V2 Mode (3-Stage Dual-Branch)

| Stage | Model | Target acc | Target AUC |
|-------|-------|-----------|------------|
| Stage 1 | dual_subject_state | >= 95% | >= 97% |
| Stage 2 | dual_normal_emotion | >= 95% | >= 97% |
| Stage 3 | dual_depression_emotion | >= 95% | >= 97% |

- All stages are fully independent (no gate control)
- Each stage generates 1 config per TSV row (no suffix)
- State path: `.agent/v2/`

**Metrics Priority**: accuracy > AUC > macro_f1 (USER MANDATED)

## 5-Step Training Cycle

### Step 1: Plan (User Interaction)

1. User specifies mode and stage
2. Read dglzvr analysis report from previous round (if any)
3. Create TSV experiment plan (max 3 configs)
4. **Wait for user confirmation**

TSV format (6 columns):
```
exp_name	task_conf	model_conf	train_conf	split_conf	aug_conf
```

### Step 2: Config (Automatic)

1. Call configs-creator skill:
   ```bash
   python .claude/skills/configs-creator/scripts/configs_creator.py \
       --base configs/base/train_full.yaml \
       --input .agent/{mode}/dglztr/exp_conf_tsv/batch{N}.tsv \
       --name batch{N} --stage {stage} --mode {mode} --output configs/
   ```
2. Failed configs → `.agent/{mode}/dglztr/failed/configs/`
3. Generate batch TXT file

### Step 3: Train (Automatic)

1. Call configs-runner skill:
   ```bash
   python .claude/skills/configs-runner/scripts/configs_runner.py \
       --mode {mode} --stage {stage} \
       --file .agent/{mode}/dglztr/exp_conf_tsv/batch{N}.txt --verbose
   ```
2. Timeout: **259200ms** (3 days)
3. Sequential execution, max 3 configs
4. Skip failed, continue to next

### Step 4: Review (Automatic)

1. Call exp-review skill
2. Extract metrics:
   ```bash
   python .claude/skills/get-results/scripts/get_results.py \
       --experiments-dir experiments \
       --exp-names {names} --stage {stage} --mode {mode}
   ```
3. Call dglzvr sub-agent for deep analysis
4. dglztr critical review
5. Save report: `.agent/{mode}/dglzvr/reviews/batch{N}_review.md`

**K-fold rules**: Holdout uses single values; k-fold uses mean +/- std; never compare directly.

### Step 5: Archive (Automatic)

1. Call move-exp skill:
   ```bash
   python .claude/skills/move-exp/scripts/move_exp.py \
       --mode {mode} --batch {N} --stage {stage} --exp-names {names}
   ```
2. Dry-run first, then actual archive
3. Update `history_batch.json`
4. Update `current_batch.json`
5. If targets not met → back to Step 1
6. If targets met → report to user

## Constraints

- GPU 12GB → sequential training only
- Max 3 configs per batch
- Timeout 259200s (3 days)
- `history_batch.json` is append-only
- K-fold and holdout tracked separately
- All skill calls must include `--mode {mode}`
