#!/usr/bin/env python3
"""move_exp.py - Archive completed experiments and populate history.

Usage:
    python .claude/skills/move-exp/scripts/move_exp.py \
        --batch 1 --stage stage1 --exp-names b1-subj,b1-subj-kfold

For each experiment:
1. Extracts metrics from training_state.yaml + metrics CSV + kfold_summary.yaml
2. Appends record to history_batch.json
3. Moves experiment dir to experiments/_Done/batch{N}/
4. Moves config to configs/_Done/batch{N}/
"""
import argparse
import csv
import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

import yaml


def _extract_best_metrics(csv_path: str) -> dict:
    """Extract best metrics from CSV (highest val_accuracy)."""
    if not os.path.isfile(csv_path):
        return {}
    rows = []
    with open(csv_path, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            rows.append(row)
    if not rows:
        return {}
    best = max(rows, key=lambda r: float(r.get("val_accuracy", 0)))
    metrics = {}
    for k in ["val_accuracy", "val_auc", "val_macro_f1", "val_loss"]:
        v = best.get(k)
        if v is not None:
            try:
                metrics[k] = float(v)
            except (ValueError, TypeError):
                pass
    return {"best_metrics": metrics, "best_epoch": int(best.get("epoch", 0)), "total_epochs": len(rows)}


def _detect_split(exp_dir: str, model: str) -> tuple[str, int | None]:
    """Detect split method from kfold_summary.yaml."""
    kf = os.path.join(exp_dir, "checkpoints", model, "kfold_summary.yaml")
    if os.path.isfile(kf):
        with open(kf, encoding="utf-8") as f:
            s = yaml.safe_load(f) or {}
        return s.get("method", "StratifiedGroupKFold"), s.get("n_splits")
    return "holdout", None


def _extract_kfold(exp_dir: str, model: str) -> dict | None:
    """Extract k-fold aggregated metrics."""
    kf = os.path.join(exp_dir, "checkpoints", model, "kfold_summary.yaml")
    if not os.path.isfile(kf):
        return None
    with open(kf, encoding="utf-8") as f:
        s = yaml.safe_load(f) or {}
    folds = s.get("folds", {})
    best_idx = 0
    best_ba = 0.0
    best_metrics = {}
    for fk, fd in folds.items():
        ba = fd.get("best_metrics", {}).get("val_accuracy", 0)
        if ba > best_ba:
            best_ba = ba
            best_metrics = fd.get("best_metrics", {})
            idx = fk.replace("fold_", "")
            best_idx = int(idx) if idx.isdigit() else 0
    return {"aggregated": s.get("aggregated", {}), "best_fold_idx": best_idx, "best_fold_metrics": best_metrics}


def _build_history_record(exp_dir: str, exp_name: str, batch: int, stage: str, config_path: str | None) -> dict | None:
    """Build a history_batch.json record from experiment outputs."""
    state_path = os.path.join(exp_dir, "training_state.yaml")
    if not os.path.isfile(state_path):
        return None
    with open(state_path, encoding="utf-8") as f:
        state = yaml.safe_load(f) or {}
    models = state.get("models", {})
    if not models:
        return None

    # Use first model
    model_name, model_state = next(iter(models.items()))

    # Extract CSV metrics
    csv_path = os.path.join(exp_dir, "metrics", f"{model_name}_history.csv")
    csv_data = _extract_best_metrics(csv_path)

    # Detect split
    split_method, n_splits = _detect_split(exp_dir, model_name)

    # Load config snapshot
    config_snapshot = {}
    if config_path and os.path.isfile(config_path):
        with open(config_path, encoding="utf-8") as f:
            full_config = yaml.safe_load(f) or {}
        model_cfg = full_config.get("models", {}).get(model_name, {})
        config_snapshot = model_cfg.get("training", {})

    record = {
        "batch": batch,
        "exp_name": exp_name,
        "stage": stage,
        "model": model_name,
        "split_method": split_method,
        "config": config_snapshot,
        "metrics": csv_data.get("best_metrics", {}),
        "best_epoch": csv_data.get("best_epoch", 0),
        "epochs_trained": csv_data.get("total_epochs", 0),
        "trained_at": datetime.now().isoformat(timespec="seconds"),
        "status": model_state.get("status", "unknown"),
    }

    if n_splits is not None:
        record["n_splits"] = n_splits
        kfold = _extract_kfold(exp_dir, model_name)
        if kfold:
            record["metrics"] = {
                "aggregated": kfold["aggregated"],
                "best_fold_idx": kfold["best_fold_idx"],
                "best_fold_metrics": kfold["best_fold_metrics"],
            }

    return record


def archive_experiments(
    experiments_dir: str,
    configs_dir: str,
    exp_names: list[str],
    batch_num: int,
    stage: str,
    agent_dir: str,
    dry_run: bool = False,
) -> dict:
    """Archive experiments and populate history."""
    done_exp = os.path.join(experiments_dir, "_Done", f"batch{batch_num}")
    done_cfg = os.path.join(configs_dir, "_Done", f"batch{batch_num}")
    history_path = os.path.join(agent_dir, "dglztr", "history_batch.json")

    archived = 0
    failed = []
    history_records = []

    for exp_name in exp_names:
        exp_dir = os.path.join(experiments_dir, exp_name)
        config_file = os.path.join(configs_dir, f"{exp_name}.yaml")

        if not os.path.isdir(exp_dir):
            failed.append({"name": exp_name, "reason": "experiment dir not found"})
            continue

        # Build history record
        record = _build_history_record(exp_dir, exp_name, batch_num, stage, config_file)
        if record:
            history_records.append(record)

        if not dry_run:
            # Move experiment
            dest_exp = os.path.join(done_exp, exp_name)
            os.makedirs(done_exp, exist_ok=True)
            shutil.move(exp_dir, dest_exp)

            # Move config
            if os.path.isfile(config_file):
                os.makedirs(done_cfg, exist_ok=True)
                shutil.move(config_file, os.path.join(done_cfg, f"{exp_name}.yaml"))

        archived += 1

    # Append to history
    if history_records and not dry_run:
        os.makedirs(os.path.dirname(history_path), exist_ok=True)
        existing = []
        if os.path.isfile(history_path):
            with open(history_path, encoding="utf-8") as f:
                existing = json.load(f)
        existing.extend(history_records)
        with open(history_path, "w", encoding="utf-8") as f:
            json.dump(existing, f, indent=2, ensure_ascii=False)

    return {
        "batch": batch_num,
        "archived": archived,
        "failed": len(failed),
        "failed_list": failed,
        "history_records_added": len(history_records),
        "dry_run": dry_run,
    }


def main():
    parser = argparse.ArgumentParser(description="Archive DGLZ experiments")
    parser.add_argument("--batch", required=True, type=int, help="Batch number")
    parser.add_argument("--stage", required=True, help="Stage name")
    parser.add_argument("--exp-names", required=True, help="Comma-separated experiment names")
    parser.add_argument("--experiments-dir", default="experiments", help="Experiments root")
    parser.add_argument("--configs-dir", default="configs", help="Configs root")
    parser.add_argument("--agent-dir", default=".agent", help="Agent state dir")
    parser.add_argument("--dry-run", action="store_true", help="Preview without moving files")
    parser.add_argument("--mode", default="v1", choices=["v1", "v2"], help="Agent mode (default: v1)")
    args = parser.parse_args()

    mode_agent_dir = os.path.join(args.agent_dir, args.mode)
    exp_names = [n.strip() for n in args.exp_names.split(",") if n.strip()]
    result = archive_experiments(
        args.experiments_dir, args.configs_dir, exp_names,
        args.batch, args.stage, mode_agent_dir, args.dry_run,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
