#!/usr/bin/env python3
"""configs_creator.py - Batch create DGLZ experiment configuration files.

Usage:
    python .claude/skills/configs-creator/scripts/configs_creator.py \
        --base configs/base/train_full.yaml --input experiments.tsv \
        --name batch1 --stage stage1 --output configs/

TSV columns (6, tab-separated):
    exp_name | task_conf | model_conf | train_conf | split_conf | aug_conf

Each *_conf column is a JSON string whose content deep-merges into
models.{target_model}.{section} where section matches the column prefix.
Empty columns use {}.
"""
import argparse
import csv
import json
import os
import sys
from copy import deepcopy

import yaml


# Column name -> config section name mapping
COLUMN_SECTION_MAP = {
    "task_conf": "task",
    "model_conf": "model",
    "train_conf": "training",
    "split_conf": "splitting",
    "aug_conf": "augmentation",
}

# Mode -> Stage -> target models
STAGE_MODELS = {
    "v1": {
        "stage1": ["subject_state"],
        "stage2": ["normal_emotion", "depression_emotion"],
    },
    "v2": {
        "stage1": ["dual_subject_state"],
        "stage2": ["dual_normal_emotion"],
        "stage3": ["dual_depression_emotion"],
    },
}


def deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base (returns new dict).

    Rules:
    - Scalar values: override replaces base
    - Dict values: recursive merge
    - List values: override replaces base (no merge)
    - None/empty values in override: keep base
    """
    result = deepcopy(base)
    for key, value in override.items():
        if value is None:
            continue
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


def generate_config(
    base_config: dict,
    exp_name: str,
    target_model: str,
    overrides: dict[str, dict],
) -> dict:
    """Generate a single experiment config by deep-merging overrides.

    Parameters
    ----------
    base_config : dict
        The full base config (loaded from train_full.yaml).
    exp_name : str
        Experiment name, injected as experiment.name.
    target_model : str
        Target model name (e.g. "subject_state").
    overrides : dict
        Column -> JSON override mapping.

    Returns
    -------
    dict
        Merged config with experiment.name set.
    """
    config = deepcopy(base_config)

    # Inject experiment name
    if "experiment" not in config:
        config["experiment"] = {}
    config["experiment"]["name"] = exp_name

    # Apply overrides to target model section
    model_section = config.get("models", {}).get(target_model, {})
    for col_name, section_name in COLUMN_SECTION_MAP.items():
        override = overrides.get(col_name, {})
        if not override:
            continue
        section = model_section.get(section_name, {})
        model_section[section_name] = deep_merge(section, override)

    # Write back
    if "models" not in config:
        config["models"] = {}
    config["models"][target_model] = model_section

    return config


def process_tsv(
    base_config: dict,
    tsv_path: str,
    stage: str,
    output_dir: str,
    agent_dir: str | None,
    batch_name: str,
    mode: str = "v1",
) -> dict:
    """Process TSV file and generate experiment configs.

    Returns
    -------
    dict
        Result summary with keys: batch, total, successful, failed,
        success_list, failed_list, batch_file.
    """
    mode_models = STAGE_MODELS.get(mode)
    if not mode_models:
        return {"error": f"Invalid mode: {mode}. Must be 'v1' or 'v2'."}
    target_models = mode_models.get(stage)
    if not target_models:
        stages = ", ".join(mode_models.keys())
        return {"error": f"Invalid stage for {mode}: {stage}. Must be one of: {stages}"}

    with open(tsv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        rows = list(reader)

    # Validate required columns
    required = {"exp_name", "task_conf", "model_conf", "train_conf", "split_conf", "aug_conf"}
    if rows:
        missing = required - set(rows[0].keys())
        if missing:
            return {"error": f"TSV missing columns: {missing}"}

    os.makedirs(output_dir, exist_ok=True)

    successful = []
    failed = []

    for row in rows:
        exp_name = row.get("exp_name", "").strip()
        if not exp_name:
            failed.append({"name": "unknown", "errors": ["empty exp_name"]})
            continue

        # Parse JSON from each *_conf column
        overrides = {}
        errors = []
        for col in COLUMN_SECTION_MAP:
            raw = row.get(col, "{}").strip() or "{}"
            try:
                parsed = json.loads(raw)
                if not isinstance(parsed, dict):
                    errors.append(f"{col}: must be a JSON object, got {type(parsed).__name__}")
                    continue
                overrides[col] = parsed
            except json.JSONDecodeError as e:
                errors.append(f"{col}: invalid JSON - {e}")
                overrides[col] = {}

        if errors:
            failed.append({"name": exp_name, "errors": errors})
            _save_failed(agent_dir, exp_name, row, errors, mode=mode)
            continue

        # Generate config(s) — one per target model
        for model_name in target_models:
            if len(target_models) > 1:
                suffix = "-normal" if model_name == "normal_emotion" else "-depression"
                config_name = f"{exp_name}{suffix}"
            else:
                config_name = exp_name

            try:
                config = generate_config(base_config, config_name, model_name, overrides)
                config_path = os.path.join(output_dir, f"{config_name}.yaml")
                with open(config_path, "w", encoding="utf-8") as f:
                    yaml.dump(config, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
                successful.append((config_name, config_path))
            except Exception as e:
                failed.append({"name": config_name, "errors": [str(e)]})
                _save_failed(agent_dir, config_name, row, [str(e)], mode=mode)

    # Write batch TXT file
    batch_file = None
    if agent_dir and successful:
        mode_agent_dir = os.path.join(agent_dir, mode)
        tsv_dir = os.path.join(mode_agent_dir, "dglztr", "exp_conf_tsv")
        os.makedirs(tsv_dir, exist_ok=True)
        batch_file = os.path.join(tsv_dir, f"{batch_name}.txt")
        with open(batch_file, "w", encoding="utf-8") as f:
            for name, path in successful:
                f.write(f"{path},{name}\n")

    return {
        "batch": batch_name,
        "stage": stage,
        "total": len(rows),
        "successful": len(successful),
        "failed": len(failed),
        "success_list": [name for name, _ in successful],
        "failed_list": failed,
        "batch_file": batch_file,
    }


def _save_failed(agent_dir, exp_name, row, errors, mode="v1"):
    """Save failed experiment details."""
    if not agent_dir:
        return
    fail_dir = os.path.join(agent_dir, mode, "dglztr", "failed", "configs")
    os.makedirs(fail_dir, exist_ok=True)
    fail_path = os.path.join(fail_dir, f"{exp_name}.json")
    with open(fail_path, "w", encoding="utf-8") as f:
        json.dump({"row": row, "errors": errors}, f, indent=2, ensure_ascii=False)


def main():
    parser = argparse.ArgumentParser(description="Batch create DGLZ experiment configs")
    parser.add_argument("--base", required=True, help="Path to base config YAML (train_full.yaml)")
    parser.add_argument("--input", required=True, help="TSV file path")
    parser.add_argument("--name", required=True, help="Batch name (e.g. batch1)")
    parser.add_argument("--mode", default="v1", choices=["v1", "v2"], help="Agent mode (default: v1)")
    parser.add_argument("--stage", required=True, help="Training stage")
    parser.add_argument("--output", default="configs", help="Output directory (default: configs)")
    parser.add_argument("--agent-dir", default=".agent", help="Agent state directory (default: .agent)")
    args = parser.parse_args()

    if not os.path.isfile(args.base):
        print(json.dumps({"error": f"Base config not found: {args.base}"}))
        sys.exit(1)
    if not os.path.isfile(args.input):
        print(json.dumps({"error": f"TSV file not found: {args.input}"}))
        sys.exit(1)

    with open(args.base, encoding="utf-8") as f:
        base_config = yaml.safe_load(f) or {}

    result = process_tsv(base_config, args.input, args.stage, args.output, args.agent_dir, args.name, mode=args.mode)
    print(json.dumps(result, indent=2, ensure_ascii=False))

    if result.get("error") or result.get("failed", 0) == result.get("total", 0):
        sys.exit(1)


if __name__ == "__main__":
    main()
