"""Compute 35 per-channel statistical features for EEG signals.

Features span five categories: band power (16), FFT direct (3),
time-domain statistics (8), Hjorth parameters (3), and spectral
shape descriptors (5).
"""

from __future__ import annotations

import numpy as np
from scipy.signal import welch
from scipy.stats import kurtosis, skew

# ---------------------------------------------------------------------------
# Feature name registry
# ---------------------------------------------------------------------------

# Band power (16 features, indices 0-15)
_BAND_POWER_NAMES: list[str] = [
    "band_power_delta",
    "band_power_theta",
    "band_power_alpha",
    "band_power_beta",
    "band_power_gamma",
    "band_ratio_theta_alpha",
    "band_ratio_alpha_beta",
    "band_ratio_delta_alpha",
    "band_ratio_theta_beta",
    "band_ratio_gamma_alpha",
    "total_power",
    "relative_delta",
    "relative_theta",
    "relative_alpha",
    "relative_beta",
    "relative_gamma",
]

# FFT direct (3 features, indices 16-18)
_FFT_DIRECT_NAMES: list[str] = [
    "peak_frequency",
    "median_frequency",
    "fft_max_power",
]

# Time-domain (8 features, indices 19-26)
_TIME_DOMAIN_NAMES: list[str] = [
    "mean",
    "std",
    "skewness",
    "kurtosis",
    "max_val",
    "min_val",
    "range_val",
    "rms",
]

# Hjorth (3 features, indices 27-29)
_HJORTH_NAMES: list[str] = [
    "hjorth_activity",
    "hjorth_mobility",
    "hjorth_complexity",
]

# Spectral shape (5 features, indices 30-34)
_SPECTRAL_SHAPE_NAMES: list[str] = [
    "spectral_entropy",
    "spectral_centroid",
    "spectral_bandwidth",
    "spectral_flatness",
    "spectral_rolloff",
]

FEATURE_NAMES: list[str] = (
    _BAND_POWER_NAMES
    + _FFT_DIRECT_NAMES
    + _TIME_DOMAIN_NAMES
    + _HJORTH_NAMES
    + _SPECTRAL_SHAPE_NAMES
)
"""Ordered list of all 35 feature name strings."""

FEATURE_INDEX: dict[str, int] = {name: i for i, name in enumerate(FEATURE_NAMES)}
"""Mapping from feature name to its column index."""

N_FEATURES: int = len(FEATURE_NAMES)
"""Total number of features per channel (35)."""

# Indices of power-related features that should be log-transformed
POWER_FEATURE_INDICES: set[int] = {0, 1, 2, 3, 4, 10, 16, 17, 18}
"""Global indices of power features that need log-transform."""

_EPS: float = 1e-12
"""Small constant to avoid division by zero."""

# Standard EEG frequency band edges (Hz)
_BAND_EDGES: dict[str, tuple[float, float]] = {
    "delta": (0.5, 4.0),
    "theta": (4.0, 8.0),
    "alpha": (8.0, 13.0),
    "beta": (13.0, 30.0),
    "gamma": (30.0, 45.0),
}


# ---------------------------------------------------------------------------
# Internal feature computation helpers
# ---------------------------------------------------------------------------

def _band_powers(
    freqs: np.ndarray,
    psd: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute the 16 band-power features.

    Returns a tuple ``(powers_5, ratios_5, extras_6)`` where
    ``powers_5`` = [delta, theta, alpha, beta, gamma],
    ``ratios_5`` = [theta/alpha, alpha/beta, delta/alpha, theta/beta, gamma/alpha],
    ``extras_6`` = [total_power, rel_delta, rel_theta, rel_alpha, rel_beta, rel_gamma].
    """
    powers = np.empty(5, dtype=np.float64)
    band_names = ["delta", "theta", "alpha", "beta", "gamma"]
    for i, bname in enumerate(band_names):
        lo, hi = _BAND_EDGES[bname]
        mask = (freqs >= lo) & (freqs <= hi)
        powers[i] = np.sum(psd[mask])

    total = np.sum(psd) + _EPS

    # Ratios
    p = powers
    ratios = np.array(
        [
            p[1] / (p[2] + _EPS),   # theta / alpha
            p[2] / (p[3] + _EPS),   # alpha / beta
            p[0] / (p[2] + _EPS),   # delta / alpha
            p[1] / (p[3] + _EPS),   # theta / beta
            p[4] / (p[2] + _EPS),   # gamma / alpha
        ],
        dtype=np.float64,
    )

    # Total power and relative powers
    total_power = np.sum(powers)
    relative = powers / (total_power + _EPS)

    extras = np.empty(6, dtype=np.float64)
    extras[0] = total_power
    extras[1:6] = relative

    return powers, ratios, extras


def _fft_direct(
    freqs: np.ndarray,
    psd: np.ndarray,
) -> np.ndarray:
    """Compute peak_frequency, median_frequency, fft_max_power."""
    peak_freq = freqs[np.argmax(psd)]
    cum = np.cumsum(psd)
    median_idx = np.searchsorted(cum, cum[-1] / 2.0)
    median_idx = min(median_idx, len(freqs) - 1)
    median_freq = freqs[median_idx]
    fft_max_power = np.max(psd)
    return np.array([peak_freq, median_freq, fft_max_power], dtype=np.float64)


def _time_domain(signal: np.ndarray) -> np.ndarray:
    """Compute 8 time-domain statistics."""
    m = np.mean(signal)
    s = np.std(signal)
    sk = float(skew(signal)) if s > _EPS else 0.0
    ku = float(kurtosis(signal)) if s > _EPS else 0.0
    mx = np.max(signal)
    mn = np.min(signal)
    rng = mx - mn
    rms = np.sqrt(np.mean(signal ** 2))
    return np.array([m, s, sk, ku, mx, mn, rng, rms], dtype=np.float64)


def _hjorth(signal: np.ndarray) -> np.ndarray:
    """Compute Hjorth activity, mobility, complexity."""
    activity = np.var(signal)
    diff1 = np.diff(signal)
    var_d1 = np.var(diff1) + _EPS
    mobility = np.sqrt(var_d1 / (activity + _EPS))
    diff2 = np.diff(diff1)
    var_d2 = np.var(diff2) + _EPS
    mobility_d1 = np.sqrt(var_d2 / var_d1)
    complexity = mobility_d1 / (mobility + _EPS)
    return np.array([activity, mobility, complexity], dtype=np.float64)


def _spectral_shape(
    freqs: np.ndarray,
    psd: np.ndarray,
) -> np.ndarray:
    """Compute 5 spectral shape descriptors."""
    psd_sum = np.sum(psd) + _EPS

    # Spectral entropy
    p = psd / psd_sum
    # Avoid log(0)
    p_safe = np.where(p > 0, p, 1.0)
    spectral_entropy = -np.sum(p * np.log(p_safe))

    # Spectral centroid
    centroid = np.sum(freqs * psd) / psd_sum

    # Spectral bandwidth
    spectral_bandwidth = np.sqrt(
        np.sum(((freqs - centroid) ** 2) * psd) / psd_sum
    )

    # Spectral flatness = exp(mean(log(psd))) / mean(psd)
    log_psd = np.log(psd + _EPS)
    spectral_flatness = np.exp(np.mean(log_psd)) / (np.mean(psd) + _EPS)

    # Spectral rolloff: frequency where cumsum >= 0.85 * total
    cum = np.cumsum(psd)
    rolloff_idx = np.searchsorted(cum, 0.85 * cum[-1])
    rolloff_idx = min(rolloff_idx, len(freqs) - 1)
    spectral_rolloff = freqs[rolloff_idx]

    return np.array(
        [spectral_entropy, centroid, spectral_bandwidth, spectral_flatness, spectral_rolloff],
        dtype=np.float64,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compute_channel_stats(
    channel_signal: np.ndarray,
    fs: int = 250,
) -> np.ndarray:
    """Compute all 35 statistical features for a single EEG channel.

    Parameters
    ----------
    channel_signal : np.ndarray
        1-D array of shape ``(T,)`` representing one channel's time-series.
    fs : int
        Sampling frequency in Hz (default 250).

    Returns
    -------
    np.ndarray
        Float32 array of shape ``(35,)`` with one feature per entry.
    """
    if channel_signal.ndim != 1:
        raise ValueError(
            f"channel_signal must be 1-D, got shape {channel_signal.shape}"
        )

    signal = channel_signal.astype(np.float64)

    # PSD via Welch
    nperseg = min(256, len(signal))
    freqs, psd = welch(signal, fs=fs, nperseg=nperseg)

    # Band power (16)
    powers, ratios, extras = _band_powers(freqs, psd)
    band_block = np.concatenate([powers, ratios, extras])  # 16

    # FFT direct (3)
    fft_block = _fft_direct(freqs, psd)  # 3

    # Time-domain (8)
    time_block = _time_domain(signal)  # 8

    # Hjorth (3)
    hjorth_block = _hjorth(signal)  # 3

    # Spectral shape (5)
    spectral_block = _spectral_shape(freqs, psd)  # 5

    features = np.concatenate(
        [band_block, fft_block, time_block, hjorth_block, spectral_block]
    )
    return features.astype(np.float32)


def compute_trial_stats(
    trial: np.ndarray,
    fs: int = 250,
) -> np.ndarray:
    """Compute 35 features per channel for a multi-channel trial.

    Parameters
    ----------
    trial : np.ndarray
        2-D array of shape ``(C, T)`` where *C* is the number of channels
        and *T* is the number of time samples.
    fs : int
        Sampling frequency in Hz (default 250).

    Returns
    -------
    np.ndarray
        Float32 array of shape ``(C, 35)``.
    """
    if trial.ndim != 2:
        raise ValueError(
            f"trial must be 2-D with shape (C, T), got shape {trial.shape}"
        )

    n_channels = trial.shape[0]
    result = np.empty((n_channels, N_FEATURES), dtype=np.float32)
    for ch in range(n_channels):
        result[ch] = compute_channel_stats(trial[ch], fs=fs)
    return result


def select_features(
    stats,  # np.ndarray or torch.Tensor, shape (..., 35)
    feature_names: list[str],
):
    """Select a feature subset by name.

    Works with both NumPy arrays and PyTorch tensors.

    Parameters
    ----------
    stats : np.ndarray | torch.Tensor
        Feature array whose last dimension is 35.  May be ``(35,)``,
        ``(C, 35)``, or higher-dimensional.
    feature_names : list[str]
        Names of features to select (order is preserved).

    Returns
    -------
    np.ndarray | torch.Tensor
        Same type as *stats*, with the last dimension equal to
        ``len(feature_names)``.
    """
    indices = [FEATURE_INDEX[name] for name in feature_names]

    # Detect torch without a hard import
    typename = type(stats).__module__
    if typename.startswith("torch"):
        return stats[..., indices]

    return stats[..., indices]
