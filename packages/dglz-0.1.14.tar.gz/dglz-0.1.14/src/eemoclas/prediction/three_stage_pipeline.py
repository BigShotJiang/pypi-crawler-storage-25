import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from pathlib import Path

from .postprocessing import apply_4_4_constraint, apply_threshold


class ThreeStagePredictor:
    """
    Three-stage inference pipeline:
    1. subject_state_classifier -> group_pred (normal=0 / depression=1)
    2. Hard route to normal_emotion_classifier or depression_emotion_classifier
    3. 4:4 top-k postprocessing
    """

    def __init__(
        self,
        subject_state_model: nn.Module,
        normal_emotion_model: nn.Module,
        depression_emotion_model: nn.Module,
        device: torch.device,
        config: dict,
    ):
        self.subject_state_model = subject_state_model
        self.normal_emotion_model = normal_emotion_model
        self.depression_emotion_model = depression_emotion_model
        self.device = device
        self.config = config

    def predict_subject(
        self,
        trials_x: torch.Tensor,      # [8, C_eff, 2500] - preprocessed trials
        token_meta: list[dict],
        user_id: str,
        raw_trials: torch.Tensor | None = None,  # [8, 30, 2500] - raw trials for dual-branch
    ) -> tuple[pd.DataFrame, dict]:
        """
        Full three-stage prediction for one test subject.

        Steps:
        1. subject_state_model(trials_x.unsqueeze(0), token_meta) -> group_logits [1, 2]
        2. group_pred = argmax(group_logits)
        3. If group_pred == 0: emotion_model = normal_emotion_model
           If group_pred == 1: emotion_model = depression_emotion_model
        4. For each trial: emotion_model(trial_x, token_meta) -> emotion_logits [1, 2]
        5. Get positive probabilities for all 8 trials
        6. Apply 4:4 constraint: top 4 by positive prob get label 1
        7. Return DataFrame with user_id, trial_id (1-8), Emotion_label

        Also returns routing info: user_id, group_pred, group_prob_normal,
        group_prob_depression, routed_model
        """

        self.subject_state_model.eval()
        self.normal_emotion_model.eval()
        self.depression_emotion_model.eval()

        all_results = []

        with torch.no_grad():
            # Step 1: Subject state prediction
            subject_input = trials_x.unsqueeze(0).to(self.device)  # [1, 8, C_eff, 2500]
            raw_subject_input = raw_trials.unsqueeze(0).to(self.device) if raw_trials is not None else None
            group_logits = self.subject_state_model(subject_input, token_meta=token_meta, x_raw=raw_subject_input)
            group_probs = torch.softmax(group_logits, dim=-1)
            group_pred = int(torch.argmax(group_logits, dim=-1).item())

            # Step 2: Route to emotion model
            if group_pred == 0:
                emotion_model = self.normal_emotion_model
                routed_model = "normal_emotion"
            else:
                emotion_model = self.depression_emotion_model
                routed_model = "depression_emotion"

            # Step 3: Per-trial emotion prediction
            pos_probs = []
            for i in range(8):
                trial_input = trials_x[i].unsqueeze(0).to(self.device)  # [1, C_eff, 2500]
                raw_trial_input = raw_trials[i].unsqueeze(0).to(self.device) if raw_trials is not None else None
                emotion_logits = emotion_model(trial_input, token_meta=token_meta, x_raw=raw_trial_input)
                emotion_probs = torch.softmax(emotion_logits, dim=-1)
                pos_probs.append(emotion_probs[0, 1].item())

            # Step 4: Post-processing
            pos_probs_tensor = torch.tensor(pos_probs)
            inference_cfg = self.config.get("inference", {})
            use_4_4 = inference_cfg.get("use_4_4_constraint", True)

            if use_4_4:
                labels = apply_4_4_constraint(pos_probs_tensor)
            else:
                threshold = inference_cfg.get("prediction_threshold", 0.6)
                labels = apply_threshold(pos_probs_tensor, threshold=threshold)

            # Step 5: Build results
            for i in range(8):
                all_results.append({
                    "user_id": user_id,
                    "trial_id": i + 1,
                    "Emotion_label": int(labels[i].item()),
                })

            # Routing info
            routing_info = {
                "user_id": user_id,
                "group_pred": group_pred,
                "group_prob_normal": float(group_probs[0, 0].item()),
                "group_prob_depression": float(group_probs[0, 1].item()),
                "routed_model": routed_model,
            }

        return pd.DataFrame(all_results), routing_info

    def predict_all_subjects(
        self,
        test_subjects: list[dict],  # [{"user_id": str, "trials_x": Tensor, "token_meta": list[dict]}]
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Run three-stage prediction for all test subjects.
        Returns: (submission_df, routing_df)
        """
        all_submissions = []
        all_routing = []

        for subject_data in test_subjects:
            sub_df, routing_info = self.predict_subject(
                trials_x=subject_data["trials_x"],
                token_meta=subject_data["token_meta"],
                user_id=subject_data["user_id"],
                raw_trials=subject_data.get("raw_trials"),
            )
            all_submissions.append(sub_df)
            all_routing.append(routing_info)

        submission_df = pd.concat(all_submissions, ignore_index=True)
        routing_df = pd.DataFrame(all_routing)

        return submission_df, routing_df
