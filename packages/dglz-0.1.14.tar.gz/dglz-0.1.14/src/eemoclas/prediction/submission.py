import pandas as pd
from pathlib import Path


def save_submission(df: pd.DataFrame, output_path: str) -> None:
    """
    Save submission DataFrame to both .xlsx and .csv.

    df must have columns: user_id, trial_id, Emotion_label
    ONLY these three columns in the xlsx output.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Validate columns
    required = {"user_id", "trial_id", "Emotion_label"}
    if not required.issubset(set(df.columns)):
        raise ValueError(f"Submission must have columns: {required}, got: {set(df.columns)}")

    # Save xlsx
    xlsx_path = output_path.with_suffix(".xlsx")
    df[["user_id", "trial_id", "Emotion_label"]].to_excel(str(xlsx_path), index=False)

    # Save csv
    csv_path = output_path.with_suffix(".csv")
    df[["user_id", "trial_id", "Emotion_label"]].to_csv(str(csv_path), index=False)


def validate_submission(df: pd.DataFrame, check_4_4: bool = True) -> bool:
    """Validate submission format.

    Args:
        df: submission DataFrame
        check_4_4: if True, enforce exactly 4 positive labels per subject
    """
    required = {"user_id", "trial_id", "Emotion_label"}
    if not required.issubset(set(df.columns)):
        return False

    # Check each subject has exactly 8 trials
    for user_id, group in df.groupby("user_id"):
        if len(group) != 8:
            return False
        if check_4_4 and group["Emotion_label"].sum() != 4:
            return False

    return True
