"""``eemo update`` -- check PyPI and upgrade DGLZ.

Flow:
1. Query PyPI for latest version (3s timeout)
2. If already latest -> green message + exit
3. Platform branch:
   - Windows: generate detached .bat script (wait 3s for file lock release),
     launch via Popen(DETACHED_PROCESS), then exit CLI
   - Linux/macOS: synchronous pip install with 3-attempt fallback
4. On success (Linux/macOS) -> generate UPDATE.md + Rich panels + log to ~/.dglz/update.log
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import typer

from eemoclas.__version__ import __version__
from eemoclas.cli.update_log import (
    filter_updates,
    load_update_log,
    render_rich_changelog,
    render_rich_migration,
    render_update_md,
)
from eemoclas.cli.utils import console
from eemoclas.cli.version_check import check_for_update, log_update

logger = logging.getLogger(__name__)

app = typer.Typer(help="更新 DGLZ 到最新版本")


def _run_pip_install(args: list[str], timeout: int = 120) -> subprocess.CompletedProcess:
    """Run pip install with the given arguments."""
    return subprocess.run(
        [sys.executable, "-m", "pip", "install"] + args,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _is_windows() -> bool:
    """Return True if running on Windows."""
    return sys.platform == "win32"


def _generate_bat_script(latest: str, python_exe: str, log_dir: str) -> str:
    """Generate a Windows .bat script that waits and runs pip install.

    The script:
    1. Waits 3 seconds for the CLI process to exit (release file lock)
    2. Runs pip install exact version, falls back to --upgrade on failure
    3. Writes result to update.log
    4. Self-deletes
    """
    return f"""@echo off
timeout /t 3 /nobreak >nul

if not exist "{log_dir}" mkdir "{log_dir}"

echo [%date% %time%] ATTEMPTING ^| {latest} >> "{log_dir}\\update.log"

"{python_exe}" -m pip install --no-cache-dir DGLZ=={latest}
if %errorlevel% equ 0 (
    echo [%date% %time%] SUCCESS ^| {latest} >> "{log_dir}\\update.log"
    goto :self_delete
)

echo [%date% %time%] RETRY ^| fallback --upgrade >> "{log_dir}\\update.log"
"{python_exe}" -m pip install --no-cache-dir --upgrade DGLZ
if %errorlevel% equ 0 (
    echo [%date% %time%] SUCCESS ^| {latest} >> "{log_dir}\\update.log"
    goto :self_delete
)

echo [%date% %time%] RETRY ^| second --upgrade >> "{log_dir}\\update.log"
"{python_exe}" -m pip install --no-cache-dir --upgrade DGLZ
if %errorlevel% equ 0 (
    echo [%date% %time%] SUCCESS ^| {latest} >> "{log_dir}\\update.log"
    goto :self_delete
)

echo [%date% %time%] FAILED ^| {latest} >> "{log_dir}\\update.log"

:self_delete
del /f "%~f0"
exit
"""


def _windows_detached_update(latest: str, console_obj) -> None:
    """Generate a detached .bat script to update DGLZ on Windows.

    The .bat script waits 3 seconds for the CLI to exit (releasing the
    file lock on eemo.exe), then runs pip install.  Results are written
    to ``~/.dglz/update.log``.
    """
    from eemoclas.cli.utils import print_cli_warning

    python_exe = sys.executable
    log_dir = str(Path.home() / ".dglz")

    try:
        script_content = _generate_bat_script(latest, python_exe, log_dir)
    except Exception as exc:
        print_cli_warning(f"无法生成更新脚本: {exc}")
        console_obj.print("  [bold]请手动运行:[/bold] pip install DGLZ --upgrade")
        log_update("FAILED", f"bat generation error: {exc}")
        raise typer.Exit(code=1)

    # Write .bat to temp directory
    bat_path = os.path.join(tempfile.gettempdir(), "_dglz_update.bat")
    try:
        with open(bat_path, "w", encoding="utf-8") as f:
            f.write(script_content)
    except Exception as exc:
        print_cli_warning(f"无法写入更新脚本: {exc}")
        console_obj.print("  [bold]请手动运行:[/bold] pip install DGLZ --upgrade")
        log_update("FAILED", f"bat write error: {exc}")
        raise typer.Exit(code=1)

    # Launch detached process
    try:
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        DETACHED_PROCESS = 0x00000008
        subprocess.Popen(
            ["cmd", "/c", bat_path],
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
        )
    except Exception as exc:
        print_cli_warning(f"无法启动更新进程: {exc}")
        console_obj.print("  [bold]请手动运行:[/bold] pip install DGLZ --upgrade")
        log_update("FAILED", f"popen error: {exc}")
        raise typer.Exit(code=1)

    print_cli_warning(
        "Windows 下无法直接替换正在运行的 eemo.exe。\n"
        f"  将在后台启动更新脚本，请等待更新完成后重新运行 eemo。"
    )
    console_obj.print(
        f"  更新完成后，日志将写入: {os.path.join(log_dir, 'update.log')}"
    )
    console_obj.print()
    log_update("DETACHED", f"{__version__} -> {latest} (Windows bat)")
    raise typer.Exit(code=0)


@app.callback(invoke_without_command=True)
def update() -> None:
    """检查并更新 DGLZ 到最新版本，显示更新日志。"""
    from rich.panel import Panel
    from rich.text import Text

    # --- Step 1: Check PyPI ---
    console.print()
    latest, has_update = check_for_update()

    if latest is None:
        from eemoclas.cli.utils import print_cli_error
        print_cli_error("无法连接 PyPI 检查更新。请检查网络连接。")
        log_update("FAILED", f"{__version__} -> ? (PyPI unreachable)")
        raise typer.Exit(code=1)

    if not has_update:
        from eemoclas.cli.utils import print_cli_success
        print_cli_success(f"DGLZ 已是最新版本 V{__version__}")
        console.print()
        log_update("ALREADY_LATEST", f"{__version__}")
        raise typer.Exit(code=0)

    # --- Step 2: Show version info panel ---
    try:
        all_rows = load_update_log()
    except Exception:
        all_rows = []

    filtered = filter_updates(all_rows, __version__, latest)
    n_versions = len({r["version"] for r in filtered}) if filtered else 0

    info_text = Text.from_markup(
        f"当前版本:  V{__version__}\n"
        f"最新版本:  V{latest}\n"
        f"版本差距:  {n_versions} 个版本\n\n"
        f"即将更新: V{__version__} \u2192 V{latest}"
    )
    console.print(Panel(info_text, title="DGLZ 版本更新", border_style="blue", expand=False))

    # --- Step 3: Platform branch ---
    if _is_windows():
        _windows_detached_update(latest, console)
        return  # unreachable, _windows_detached_update raises typer.Exit

    # --- Step 3a: Linux/macOS - synchronous pip install with 3-attempt fallback ---
    console.print()
    with console.status("[bold cyan]正在更新 DGLZ...[/bold cyan]"):
        try:
            result = _run_pip_install(
                ["--no-cache-dir", f"DGLZ=={latest}"],
            )

            if result.returncode != 0:
                logger.info("Exact version install failed, falling back to --upgrade: %s", result.stderr.strip())
                result = _run_pip_install(
                    ["--no-cache-dir", "--upgrade", "DGLZ"],
                )

                if result.returncode != 0:
                    logger.info("First --upgrade failed, retrying: %s", result.stderr.strip())
                    result = _run_pip_install(
                        ["--no-cache-dir", "--upgrade", "DGLZ"],
                    )

        except subprocess.TimeoutExpired:
            from eemoclas.cli.utils import print_cli_error
            print_cli_error("更新超时（120s）。")
            console.print("  [bold]请手动运行:[/bold] pip install DGLZ --upgrade")
            log_update("FAILED", f"timeout, {__version__} -> {latest}")
            raise typer.Exit(code=1)

    if result.returncode != 0:
        from eemoclas.cli.utils import print_cli_error
        print_cli_error(f"更新失败: {result.stderr.strip()}")
        console.print("  [bold]请手动运行:[/bold] pip install DGLZ --upgrade")
        log_update("FAILED", f"{__version__} -> {latest}, stderr: {result.stderr.strip()[:200]}")
        raise typer.Exit(code=1)

    # --- Step 4: Success panel ---
    success_text = Text.from_markup(
        f"V{__version__} \u2192 V{latest}"
    )
    console.print(Panel(
        success_text,
        title="[bold green]\u2714 更新成功[/bold green]",
        border_style="green",
        expand=False,
    ))
    log_update("SUCCESS", f"{__version__} -> {latest}")

    # --- Step 5: Generate UPDATE.md ---
    update_md_path: str | None = None
    try:
        md_content = render_update_md(filtered, __version__, latest)
        update_md_path = os.path.join(os.getcwd(), "UPDATE.md")
        with open(update_md_path, "w", encoding="utf-8") as f:
            f.write(md_content)
    except Exception as exc:
        logger.warning("Failed to generate UPDATE.md: %s", exc)

    # --- Step 6: Show changelog + migration panels ---
    if filtered:
        console.print()
        render_rich_changelog(filtered, console)

        console.print()
        render_rich_migration(filtered, console)

    # --- Step 7: Show UPDATE.md path ---
    if update_md_path:
        abs_path = os.path.abspath(update_md_path)
        console.print()
        console.print(f"  [bold]更新日志已保存至:[/bold] {abs_path}")

    console.print()
