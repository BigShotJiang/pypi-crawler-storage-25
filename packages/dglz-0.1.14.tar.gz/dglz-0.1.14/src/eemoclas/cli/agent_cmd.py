"""``eemo agent`` -- manage DGLZ training agents.

Provides ``claude`` subcommand to deploy Claude Code agent templates
(agents, skills, memory files, settings) to a target project directory.
"""

from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path

import typer

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
)

app = typer.Typer(help="训练智能体管理")


def _get_template_dir() -> Path:
    """Resolve the bundled claude_templates directory."""
    try:
        import importlib.resources as ir
        # Python >= 3.9: files() returns Traversable
        ref = ir.files("eemoclas").joinpath("claude_templates")
        if ref.is_dir():
            return Path(str(ref))
    except Exception:
        pass
    # Fallback: relative to this file's package
    fallback = Path(__file__).resolve().parent.parent / "claude_templates"
    if fallback.is_dir():
        return fallback
    raise FileNotFoundError(
        "claude_templates directory not found in eemoclas package. "
        "Ensure the package is installed correctly."
    )


def _copy_tree(src: Path, dst: Path, base: Path | None = None) -> list[str]:
    """Recursively copy src to dst. Returns list of created/updated files.

    Parameters
    ----------
    src:
        Source file or directory.
    dst:
        Destination file or directory.
    base:
        The root target directory (``.claude/``) used for computing relative
        paths in the returned list.  Automatically captured on the first call.
    """
    created = []
    if base is None:
        # On first call dst is the top-level item inside .claude (e.g. .claude/agents)
        base = dst.parent
    if src.is_dir():
        dst.mkdir(parents=True, exist_ok=True)
        for item in sorted(src.iterdir()):
            sub_dst = dst / item.name
            created.extend(_copy_tree(item, sub_dst, base=base))
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(src), str(dst))
        created.append(str(dst.relative_to(base)))
    return created


def _migrate_legacy_state(project_root: Path) -> None:
    """Migrate legacy .agent/ state to .agent/v1/ structure.

    Only runs if legacy state exists and v1/ doesn't.
    """
    agent_dir = project_root / ".agent"
    legacy_dglztr = agent_dir / "dglztr"
    v1_dglztr = agent_dir / "v1" / "dglztr"

    if not legacy_dglztr.is_dir() or v1_dglztr.is_dir():
        return

    console.print("  [yellow]检测到旧版 agent state，正在迁移到 .agent/v1/...[/yellow]")

    v1_dir = agent_dir / "v1"
    v1_dir.mkdir(parents=True, exist_ok=True)

    # Move dglztr/ → v1/dglztr/
    shutil.move(str(legacy_dglztr), str(v1_dir / "dglztr"))
    console.print("    移动 .agent/dglztr/ → .agent/v1/dglztr/")

    # Move dglzvr/ → v1/dglzvr/ if exists
    legacy_dglzvr = agent_dir / "dglzvr"
    if legacy_dglzvr.is_dir():
        shutil.move(str(legacy_dglzvr), str(v1_dir / "dglzvr"))
        console.print("    移动 .agent/dglzvr/ → .agent/v1/dglzvr/")

    # Create active_state.json
    import json
    from datetime import datetime
    active_state = {
        "mode": "v1",
        "stage": None,
        "batch": None,
        "step": None,
        "model": None,
        "started_at": datetime.now().isoformat(timespec="seconds"),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    active_path = agent_dir / "active_state.json"
    with open(active_path, "w", encoding="utf-8") as f:
        json.dump(active_state, f, indent=2, ensure_ascii=False)
    console.print("    创建 .agent/active_state.json")

    console.print("  [green]迁移完成[/green]")
    console.print()


@app.command()
def claude(
    path: str = typer.Option(
        ".claude/", "--path", "-p",
        help="目标 .claude 目录路径（默认: .claude/）",
    ),
    mode: str = typer.Option(
        "v1", "--mode", "-m",
        help="Agent 模式: v1（两阶段单路）或 v2（三阶段双路）",
    ),
) -> None:
    """部署 Claude Code 训练智能体模板文件。

    将 dglztr/dglzvr agent 定义、skill 脚本、记忆模板和配置文件
    复制到指定的 .claude/ 目录。

    使用 --mode v1 部署两阶段单路训练 agent。
    使用 --mode v2 部署三阶段双路训练 agent。
    """
    if mode not in ("v1", "v2"):
        print_cli_error(f"无效的 mode: {mode}，必须是 v1 或 v2")
        raise typer.Exit(code=1)

    print_cli_header(f"DGLZ 训练智能体部署 (mode={mode})")

    target = Path(path).resolve()
    if target.exists() and not target.is_dir():
        print_cli_error(f"目标路径已存在但不是目录: {target}")
        raise typer.Exit(code=1)

    # Get template source
    try:
        template_dir = _get_template_dir()
    except FileNotFoundError as exc:
        print_cli_error(str(exc))
        raise typer.Exit(code=1)

    console.print(f"  模板源: [cyan]{template_dir}[/cyan]")
    console.print(f"  目标路径: [cyan]{target}[/cyan]")
    console.print(f"  模式: [cyan]{mode}[/cyan]")
    console.print()

    # 1. Migrate legacy state if needed (before deployment)
    _migrate_legacy_state(target.parent)

    total_files = 0

    # 2. Copy shared skills (always)
    skills_src = template_dir / "skills"
    if skills_src.is_dir():
        dst = target / "skills"
        files = _copy_tree(skills_src, dst)
        total_files += len(files)
        console.print(f"  [green]skills/[/green] ({len(files)} 个文件)")

    # 3. Copy mode-specific agents
    agents_src = template_dir / mode / "agents"
    if agents_src.is_dir():
        dst = target / "agents"
        files = _copy_tree(agents_src, dst)
        total_files += len(files)
        console.print(f"  [green]agents/[/green] ({len(files)} 个文件, mode={mode})")
    else:
        print_cli_error(f"Agent 模板未找到: {agents_src}")
        raise typer.Exit(code=1)

    # 4. Copy mode-specific agent-memory
    memory_src = template_dir / mode / "agent-memory"
    if memory_src.is_dir():
        dst = target / "agent-memory"
        files = _copy_tree(memory_src, dst)
        total_files += len(files)
        console.print(f"  [green]agent-memory/[/green] ({len(files)} 个文件, mode={mode})")

    # 5. Copy settings.local.json if exists
    settings_src = template_dir / "settings.local.json"
    if settings_src.is_file():
        dst = target / "settings.local.json"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(settings_src), str(dst))
        total_files += 1
        console.print(f"  [green]settings.local.json[/green]")

    # 6. Make shell scripts executable
    scripts_dir = target / "skills" / "agent-state" / "scripts"
    if scripts_dir.is_dir():
        for sh in scripts_dir.glob("*.sh"):
            sh.chmod(sh.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    print_cli_success(f"部署完成: {total_files} 个文件已复制到 {target} (mode={mode})")
    console.print()
    console.print("  后续步骤:")
    console.print(f"  1. 在目标项目目录运行: [cyan]bash .claude/skills/agent-state/scripts/init_state.sh --mode {mode}[/cyan]")
    console.print("  2. 启动 Claude Code 并使用 dglztr agent 开始训练")
    console.print()
