"""PyPI version checking with local 10-minute cache.

Uses ``urllib.request`` (stdlib) to query the PyPI JSON API.
Cache stored at ``~/.dglz/version_cache.json``.
"""

from __future__ import annotations

import json
import logging
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from packaging.version import Version

from eemoclas.__version__ import __version__

if TYPE_CHECKING:
    from rich.console import Console

logger = logging.getLogger(__name__)

_PYPPI_JSON_URL = "https://pypi.org/pypi/DGLZ/json"
_CACHE_TTL_MINUTES = 10
_REQUEST_TIMEOUT = 3  # seconds
_DGLZ_DIR = Path.home() / ".dglz"


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _cache_dir() -> Path:
    """Return the path to the DGLZ state directory."""
    return _DGLZ_DIR


def _cache_path() -> Path:
    """Return the path to the version cache file."""
    return _cache_dir() / "version_cache.json"


def get_cached_latest() -> Optional[str]:
    """Read the cached latest version.

    Returns ``None`` if cache is missing or older than 10 minutes.
    """
    path = _cache_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        last_check = datetime.fromisoformat(data["last_check"])
        if datetime.now() - last_check > timedelta(minutes=_CACHE_TTL_MINUTES):
            return None
        return data["latest_version"]
    except (KeyError, ValueError, json.JSONDecodeError):
        return None


def save_cache(latest_version: str) -> None:
    """Write the latest version and current timestamp to cache."""
    path = _cache_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "last_check": datetime.now().isoformat(),
        "latest_version": latest_version,
    }
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


def log_update(action: str, detail: str = "") -> None:
    """Append a structured entry to ``~/.dglz/update.log``.

    Format: ``[YYYY-MM-DD HH:MM:SS] ACTION | detail``
    Actions: ALREADY_LATEST, SUCCESS, FAILED, DETACHED
    """
    log_path = _cache_dir() / "update.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {action}"
    if detail:
        line += f" | {detail}"
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _detect_path() -> Path:
    """Return the path to the update detection audit file."""
    return _cache_dir() / "update_detect.json"


def save_detect_record(
    current_version: str,
    latest_version: Optional[str],
    has_update: bool,
    status: str,
) -> None:
    """Write a detection audit record to ``~/.dglz/update_detect.json``."""
    path = _detect_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "last_detect": datetime.now().isoformat(),
        "current_version": current_version,
        "latest_version": latest_version,
        "has_update": has_update,
        "status": status,  # "success" | "network_error" | "cache_hit"
    }
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# PyPI check
# ---------------------------------------------------------------------------

def check_for_update() -> tuple[Optional[str], bool]:
    """Query PyPI for the latest DGLZ version.

    Returns ``(latest_version, has_update)``.
    On network error returns ``(None, False)``.
    """
    try:
        req = urllib.request.Request(
            _PYPPI_JSON_URL, headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=_REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        latest = data["info"]["version"]
        has_update = Version(latest) > Version(__version__)
        if has_update:
            save_cache(latest)
        return latest, has_update
    except Exception as exc:
        logger.debug("PyPI version check failed: %s", exc)
        return None, False


# ---------------------------------------------------------------------------
# Auto-notify helper (called from main.py callback)
# ---------------------------------------------------------------------------

def notify_if_update_available(console: Console) -> None:
    """Print a yellow update notification if a newer version exists.

    Safe to call from ``main.py`` callback -- errors are silently ignored.
    """
    try:
        cached = get_cached_latest()
        if cached is not None:
            has_update = Version(cached) > Version(__version__)
            save_detect_record(__version__, cached, has_update, "cache_hit")
            if has_update:
                console.print(
                    f"[bold yellow]\u26a0 DGLZ 有新版本 V{cached} 可用"
                    f"（当前: V{__version__}）。运行 eemo update 更新。[/bold yellow]"
                )
            return

        # Cache miss or expired -- check PyPI
        latest, has_update = check_for_update()
        if latest is not None:
            save_detect_record(__version__, latest, has_update, "success")
            if has_update:
                console.print(
                    f"[bold yellow]\u26a0 DGLZ 有新版本 V{latest} 可用"
                    f"（当前: V{__version__}）。运行 eemo update 更新。[/bold yellow]"
                )
        else:
            save_detect_record(__version__, None, False, "network_error")
    except Exception:
        try:
            save_detect_record(__version__, None, False, "exception")
        except Exception:
            pass  # Never break normal CLI usage
