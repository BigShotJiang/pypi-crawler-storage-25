"""``eemo infer-three-stage`` -- three-stage inference pipeline.

Runs the full three-stage inference:
1. Subject state classification (normal / depression)
2. Hard-route to the corresponding emotion classifier
3. 4:4 top-k post-processing constraint

Outputs ``submission.xlsx`` and ``routing_summary.csv``.
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import torch

import typer

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
    print_cli_warning,
)

app = typer.Typer(help="三阶段推理流水线")


@app.callback(invoke_without_command=True)
def infer_three_stage(
    config: str = typer.Option(
        "configs/infer_three_stage.yaml", "--config",
        help="三阶段推理配置 YAML 文件路径",
    ),
    subject_state_model: str = typer.Option(
        None, "--subject-state-model",
        help="被试状态分类器检查点路径（覆盖配置文件）",
    ),
    normal_emotion_model: str = typer.Option(
        None, "--normal-emotion-model",
        help="正常人情绪分类器检查点路径（覆盖配置文件）",
    ),
    depression_emotion_model: str = typer.Option(
        None, "--depression-emotion-model",
        help="抑郁症患者情绪分类器检查点路径（覆盖配置文件）",
    ),
    test_dir: str = typer.Option(
        None, "--test-dir",
        help="测试数据目录（覆盖配置文件）",
    ),
    output: str = typer.Option(
        "outputs/submission", "--output",
        help="输出路径（不含扩展名）",
    ),
    verbose: bool = typer.Option(False, "--verbose", help="启用详细输出模式"),
    dual_branch: bool = typer.Option(False, "--dual-branch", help="使用双路模型进行推理"),
) -> None:
    """运行完整三阶段推理: 被试状态 → 情绪分类 → 4:4 排序约束。"""
    print_cli_header("三阶段推理")

    # --- Load config ---
    if not os.path.isfile(config):
        print_cli_error(f"配置文件未找到: {config}")
        raise typer.Exit(code=1)

    from eemoclas.utils.config import load_config, resolve_c_eff
    cfg = load_config(config)

    # Override paths from CLI flags if provided
    models_cfg = cfg.get("models", {})
    ss_path = subject_state_model or models_cfg.get("subject_state", {}).get("checkpoint")
    ne_path = normal_emotion_model or models_cfg.get("normal_emotion", {}).get("checkpoint")
    de_path = depression_emotion_model or models_cfg.get("depression_emotion", {}).get("checkpoint")
    test_data_dir = test_dir or cfg.get("test_data", {}).get("test_dir", "data/raw/test")

    # Validate checkpoint paths
    for label, path in [
        ("subject_state_model", ss_path),
        ("normal_emotion_model", ne_path),
        ("depression_emotion_model", de_path),
    ]:
        if path is None or not os.path.isfile(path):
            print_cli_error(f"检查点未找到 ({label}): {path}")
            raise typer.Exit(code=1)

    if verbose:
        console.print(f"  被试状态模型:  [cyan]{ss_path}[/cyan]")
        console.print(f"  正常人情绪模型: [cyan]{ne_path}[/cyan]")
        console.print(f"  抑郁症情绪模型: [cyan]{de_path}[/cyan]")
        console.print(f"  测试数据目录: [cyan]{test_data_dir}[/cyan]")

    # --- Device ---
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    console.print(f"  设备: [cyan]{device}[/cyan]")

    # --- Load models ---
    from eemoclas.model.model_factory import create_model
    from eemoclas.training.checkpoint import load_checkpoint

    c_eff = resolve_c_eff(cfg)

    # Also check config file for dual_branch setting
    if not dual_branch:
        dual_branch = cfg.get("inference", {}).get("dual_branch", False)

    _prefix = "dual_" if dual_branch else ""

    def _load_model(model_name: str, ckpt_path: str):
        """Create model from checkpoint's config snapshot and load weights."""
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
        snap = ckpt.get("config_snapshot", {})
        model_cfg = snap.get("model", cfg)
        model = create_model(model_name, model_cfg)
        model.load_state_dict(ckpt["model_state_dict"])
        return model.to(device).eval()

    ss_model = _load_model(f"{_prefix}subject_state", ss_path)
    ne_model = _load_model(f"{_prefix}normal_emotion", ne_path)
    de_model = _load_model(f"{_prefix}depression_emotion", de_path)

    if verbose:
        print_cli_success("三个模型全部加载成功")

    # --- Build three-stage predictor ---
    from eemoclas.prediction.three_stage_pipeline import ThreeStagePredictor

    predictor = ThreeStagePredictor(
        subject_state_model=ss_model,
        normal_emotion_model=ne_model,
        depression_emotion_model=de_model,
        device=device,
        config=cfg,
    )

    # --- Scan test .mat files ---
    from eemoclas.data.eeg_io import load_test_mat
    from eemoclas.data.eeg_splitter import split_test_trials
    from eemoclas.data.preprocessing import channel_select, z_score, clip_signal

    test_files = sorted(
        [f for f in os.listdir(test_data_dir) if f.lower().endswith(".mat")]
    )
    if not test_files:
        print_cli_error(f"未找到 .mat 文件: {test_data_dir}")
        raise typer.Exit(code=1)

    console.print(f"  发现 [cyan]{len(test_files)}[/cyan] 名测试被试")

    # Load config_snapshot to get channel/band config
    preprocess_cfg = cfg.get("preprocess", cfg.get("preprocessing", {}))
    fallback_cfg = preprocess_cfg.get("fallback_config_snapshot", {})
    channel_set = "standard"

    # Try loading channel config from snapshot
    snap_path = (
        fallback_cfg.get("subject_state")
        or cfg.get("test_data", {}).get("config_snapshot")
    )
    if snap_path and os.path.isfile(snap_path):
        from eemoclas.utils.config import load_config as _load
        snap_cfg = _load(snap_path)
        channel_set = snap_cfg.get("channels", {}).get("selected", "standard")
        if channel_set == "all":
            channel_set = "standard"

    # --- Process each test subject ---
    test_subjects: list[dict] = []

    for mat_file in test_files:
        user_id = os.path.splitext(mat_file)[0]
        mat_path = os.path.join(test_data_dir, mat_file)

        if verbose:
            console.print(f"  处理 [cyan]{user_id}[/cyan] ...")

        # Load .mat
        eeg = load_test_mat(mat_path)  # (30, T)

        # Split into 8 trials
        trials = split_test_trials(eeg)  # list of (30, 2500)

        # Save raw trials before preprocessing (dual-branch)
        if dual_branch:
            raw_trials = torch.stack([
                torch.from_numpy(t.copy()).float() for t in trials
            ])  # [8, 30, 2500]

        # Preprocess each trial: channel select + bandpass -> z-score -> clip
        processed_trials: list[torch.FloatTensor] = []
        token_meta: list[dict] = []

        for trial_eeg in trials:
            processed, trial_meta = channel_select(
                trial_eeg, channel_set=channel_set, return_meta=True,
            )
            processed = z_score(processed)
            processed = clip_signal(processed)

            processed_trials.append(torch.from_numpy(processed).float())
            if not token_meta:
                token_meta = trial_meta

        # Stack trials: [8, C_eff, 2500]
        trials_x = torch.stack(processed_trials, dim=0)

        subject_entry = {
            "user_id": user_id,
            "trials_x": trials_x,
            "token_meta": token_meta,
        }
        if dual_branch:
            subject_entry["raw_trials"] = raw_trials
        test_subjects.append(subject_entry)

    # --- Run three-stage prediction ---
    if verbose:
        console.print("\n  [bold]正在运行三阶段推理 ...[/bold]")

    submission_df, routing_df = predictor.predict_all_subjects(test_subjects)

    # --- Save results ---
    from eemoclas.prediction.submission import save_submission, validate_submission

    save_submission(submission_df, output)

    # Save routing summary
    routing_path = Path(output).parent / "routing_summary.csv"
    routing_path.parent.mkdir(parents=True, exist_ok=True)
    routing_df.to_csv(str(routing_path), index=False)

    # Validate
    use_4_4 = cfg.get("inference", {}).get("use_4_4_constraint", True)
    is_valid = validate_submission(submission_df, check_4_4=use_4_4)

    print_cli_success(f"提交文件已保存至 {output}.xlsx 和 {output}.csv")
    print_cli_success(f"路由汇总已保存至 {routing_path}")

    if is_valid:
        print_cli_success("提交格式校验通过")
    else:
        print_cli_warning("提交格式校验失败（请检查输出）")

    if verbose:
        console.print(f"  总被试数: [cyan]{len(test_subjects)}[/cyan]")
        console.print(f"  总行数: [cyan]{len(submission_df)}[/cyan]")

    console.print()
