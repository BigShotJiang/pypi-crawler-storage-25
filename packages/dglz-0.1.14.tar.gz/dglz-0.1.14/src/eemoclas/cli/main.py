"""Main CLI entry point for the DGLZ toolkit.

Registered as ``eemo`` via the ``[project.scripts]`` section in
``pyproject.toml``::

    eemo = "eemoclas.cli.main:main"
"""

from __future__ import annotations

import typer

from eemoclas.__version__ import __version__

app = typer.Typer(
    name="eemo",
    help="DGLZ: 脑电情绪识别命令行工具",
    add_completion=False,
)

# Import and register sub-commands
from eemoclas.cli.prepare_cmd import app as prepare_app
from eemoclas.cli.resample_cmd import app as resample_app
from eemoclas.cli.train_cmd import app as train_app
from eemoclas.cli.pred_cmd import app as pred_app
from eemoclas.cli.infer_three_stage_cmd import app as infer_app
from eemoclas.cli.get_cmd import app as get_app
from eemoclas.cli.version_cmd import register as register_version
from eemoclas.cli.config_cmd import app as config_app
from eemoclas.cli.exp_train_cmd import app as exp_train_app
from eemoclas.cli.exp_pred_cmd import app as exp_pred_app
from eemoclas.cli.ckpt_cmd import app as ckpt_app
from eemoclas.cli.doctor_cmd import app as doctor_app
from eemoclas.cli.helpme_cmd import app as helpme_app
from eemoclas.cli.agent_cmd import app as agent_app
from eemoclas.cli.update_cmd import app as update_app

app.add_typer(prepare_app, name="prepare")
app.add_typer(resample_app, name="resample")
app.add_typer(train_app, name="train")
app.add_typer(pred_app, name="pred")
app.add_typer(infer_app, name="infer-three-stage")
app.add_typer(get_app, name="get")
register_version(app)
app.add_typer(config_app, name="config")
app.add_typer(exp_train_app, name="exp-train")
app.add_typer(exp_pred_app, name="exp-pred")
app.add_typer(ckpt_app, name="ckpt")
app.add_typer(doctor_app, name="doctor")
app.add_typer(helpme_app, name="helpme")
app.add_typer(agent_app, name="agent")
app.add_typer(update_app, name="update")


def main() -> None:
    """Entry point for the ``eemo`` console script.

    Runs the Typer app, then checks for available updates (non-blocking).
    Catches SystemExit from Typer and KeyboardInterrupt from Ctrl+C
    so the update notification always runs and resources are cleaned up.
    """
    exit_code = 0
    try:
        app()
    except SystemExit as e:
        exit_code = e.code if isinstance(e.code, int) else (e.code or 0)
    except KeyboardInterrupt:
        from eemoclas.cli.utils import console
        console.print("\n[yellow]操作已取消[/yellow]")
        exit_code = 130  # 128 + SIGINT(2)
    # Post-command update notification (never breaks normal usage)
    try:
        from eemoclas.cli.version_check import notify_if_update_available
        from eemoclas.cli.utils import console
        notify_if_update_available(console)
    except Exception:
        pass
    if exit_code:
        raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
