"""Shared metrics computation for EEG emotion recognition.

Provides ``compute_metrics`` which returns a dictionary of standard
classification metrics using scikit-learn backends.

All returned float values are rounded to 4 decimal places.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    roc_auc_score,
)


def compute_metrics(
    y_true: np.ndarray | list[int],
    y_pred: np.ndarray | list[int],
    y_prob: np.ndarray | None = None,
) -> dict[str, float]:
    """Compute standard classification metrics.

    Parameters
    ----------
    y_true:
        Ground-truth labels (1-D).
    y_pred:
        Predicted class labels (1-D).
    y_prob:
        Optional predicted probabilities with shape ``(n_samples,
        n_classes)`` or ``(n_samples,)`` for binary classification.
        When provided, ``roc_auc`` is included in the result.

    Returns
    -------
    dict[str, float]
        Dictionary with keys:

        * ``accuracy``          -- standard accuracy
        * ``macro_f1``          -- macro-averaged F1 score
        * ``roc_auc``           -- one-vs-rest ROC AUC (only if *y_prob*
          is given)
    """
    y_true_arr = np.asarray(y_true)
    y_pred_arr = np.asarray(y_pred)

    metrics: dict[str, float] = {
        "accuracy": round(float(accuracy_score(y_true_arr, y_pred_arr)), 4),
        "macro_f1": round(float(f1_score(y_true_arr, y_pred_arr, average="macro", zero_division=0)), 4),
    }

    if y_prob is not None:
        y_prob_arr = np.asarray(y_prob)
        # Determine multi_class strategy
        n_classes = len(np.unique(y_true_arr))
        if n_classes <= 2:
            # Binary: use shape (n_samples,)
            if y_prob_arr.ndim == 2:
                y_prob_arr = y_prob_arr[:, 1]
            auc = roc_auc_score(y_true_arr, y_prob_arr)
        else:
            auc = roc_auc_score(y_true_arr, y_prob_arr, multi_class="ovr", average="macro")
        metrics["roc_auc"] = round(float(auc), 4)

    return metrics
