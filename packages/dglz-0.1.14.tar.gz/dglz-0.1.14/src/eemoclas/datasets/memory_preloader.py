"""Backward-compatible import shim.

The old :class:`MemoryPreloader` has been superseded by
:class:`CompressedPreloader` and :class:`PreloadedDataset` in
:mod:`eemoclas.datasets.preloaded_dataset`.  Import from there instead.
"""

from eemoclas.datasets.preloaded_dataset import (  # noqa: F401
    CompressedPreloader,
    PreloadedDataset,
    PreloadingTrainLoader,
)

__all__ = ["CompressedPreloader", "PreloadedDataset", "PreloadingTrainLoader"]
