"""Dataset for Classifier 1 (subject-state detection)."""

from __future__ import annotations

from .resampled_dataset import ResampledTensorDataset

_SUBJECT_STATE_EXTRA_FIELDS = ("trial_segment_ids", "trial_emotion_labels", "group_label")


class SubjectStateDataset(ResampledTensorDataset):
    """Dataset for the **subject-state** classifier.

    Each sample must contain the base fields inherited from
    :class:`ResampledTensorDataset` **plus** the following extra keys:

    * ``trial_segment_ids``    -- segment identifiers for the trial
    * ``trial_emotion_labels`` -- emotion labels for each trial segment
    * ``group_label``          -- scalar group / state label

    The tensor ``x`` is expected to have shape ``[8, C_eff, 2500]`` and
    ``token_meta`` must have length equal to ``C_eff`` (i.e.
    ``x.shape[1]``).
    """

    def __init__(self, manifest_file: str, *, load_raw: bool = False) -> None:
        super().__init__(manifest_file, load_raw=load_raw)

    def _validate_sample(self, sample: dict) -> None:
        super()._validate_sample(sample)

        # Extra required fields
        for field in _SUBJECT_STATE_EXTRA_FIELDS:
            if field not in sample:
                raise ValueError(
                    f"Subject-state sample missing required field: {field!r}. "
                    f"Present keys: {sorted(sample.keys())}"
                )

        # token_meta length must match C_eff (x.shape[1])
        x = sample["x"]
        token_meta = sample["token_meta"]
        c_eff = x.shape[1]
        if len(token_meta) != c_eff:
            raise ValueError(
                f"token_meta length ({len(token_meta)}) does not match "
                f"C_eff from x.shape[1] ({c_eff})"
            )
