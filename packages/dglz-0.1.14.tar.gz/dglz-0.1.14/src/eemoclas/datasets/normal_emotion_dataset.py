"""Dataset for Classifier 2 (normal-emotion recognition)."""

from __future__ import annotations

from .resampled_dataset import ResampledTensorDataset

_EMOTION_EXTRA_FIELDS = ("emotion_label", "segment_id")


class NormalEmotionDataset(ResampledTensorDataset):
    """Dataset for the **normal-emotion** classifier.

    Each sample must contain the base fields inherited from
    :class:`ResampledTensorDataset` **plus** the following extra keys:

    * ``emotion_label`` -- scalar emotion label
    * ``segment_id``    -- segment identifier

    The tensor ``x`` is expected to have shape ``[C_eff, 2500]`` and
    ``token_meta`` must have length equal to ``C_eff`` (i.e.
    ``x.shape[0]``).
    """

    def __init__(self, manifest_file: str, *, load_raw: bool = False) -> None:
        super().__init__(manifest_file, load_raw=load_raw)

    def _validate_sample(self, sample: dict) -> None:
        super()._validate_sample(sample)

        # Extra required fields
        for field in _EMOTION_EXTRA_FIELDS:
            if field not in sample:
                raise ValueError(
                    f"Emotion sample missing required field: {field!r}. "
                    f"Present keys: {sorted(sample.keys())}"
                )

        # token_meta length must match C_eff (x.shape[0])
        x = sample["x"]
        token_meta = sample["token_meta"]
        c_eff = x.shape[0]
        if len(token_meta) != c_eff:
            raise ValueError(
                f"token_meta length ({len(token_meta)}) does not match "
                f"C_eff from x.shape[0] ({c_eff})"
            )
