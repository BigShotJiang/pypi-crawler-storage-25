"""Protocol definition for DGLZ models."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import torch


@runtime_checkable
class BaseModelProtocol(Protocol):
    """Minimal interface that every DGLZ model must implement."""

    def forward(
        self,
        x: torch.Tensor,
        token_meta: list[dict] | None = None,
        x_raw: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Forward pass returning logit tensor."""
        ...
