"""Classifier 2: normal-group emotion recognition."""

from __future__ import annotations

import torch
import torch.nn as nn

from eemoclas.model.trial_cnn_transformer import TrialCNNTransformer
from eemoclas.model.classification_head import ClassificationHead


class NormalEmotionCNNTransformer(nn.Module):
    """
    Binary emotion classifier for the **normal** subject group.

    Architecture
    ------------
    ``TrialCNNTransformer -> ClassificationHead``

    Input:  ``[B, C_eff, 2500]``
    Output: ``[B, 2]``
    """

    def __init__(self, config: dict) -> None:
        super().__init__()

        trial_cfg = config.get("trial_encoder", {})
        head_cfg = config.get("classification_head", {})

        self.trial_encoder = TrialCNNTransformer(
            input_channels=trial_cfg.get("input_channels", 30),
            input_length=trial_cfg.get("input_length", 2500),
            projection_dim=trial_cfg.get("projection_dim", 128),
            cnn_channels=trial_cfg.get("cnn_channels", [16, 32, 64]),
            kernel_sizes=trial_cfg.get("kernel_sizes", [15, 9, 5]),
            strides=trial_cfg.get("strides", [2, 2, 2]),
            cnn_dropout=trial_cfg.get("cnn_dropout", 0.1),
            transformer_num_layers=trial_cfg.get("transformer_num_layers", 2),
            transformer_num_heads=trial_cfg.get("transformer_num_heads", 4),
            transformer_dim_feedforward=trial_cfg.get("transformer_dim_feedforward", 256),
            transformer_dropout=trial_cfg.get("transformer_dropout", 0.1),
            use_cls_token=trial_cfg.get("use_cls_token", True),
            pooling=trial_cfg.get("pooling", "cls"),
            use_channel_embedding=trial_cfg.get("use_channel_embedding", True),
            use_band_embedding=trial_cfg.get("use_band_embedding", True),
            channel_names=trial_cfg.get("channel_names", None),
            band_names=trial_cfg.get("band_names", None),
        )

        embedding_dim = trial_cfg.get("projection_dim", 128)

        self.classification_head = ClassificationHead(
            input_dim=head_cfg.get("input_dim", embedding_dim),
            num_classes=head_cfg.get("num_classes", 2),
            hidden_dims=head_cfg.get("hidden_dims", [128]),
            dropout=head_cfg.get("dropout", 0.3),
        )

    def forward(
        self,
        x: torch.Tensor,
        token_meta: list[dict] | None = None,
        x_raw: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Args:
            x: ``[B, C_eff, 2500]``
            token_meta: list of dicts describing each token's channel / band.

        Returns:
            logits ``[B, 2]``
        """
        h = self.trial_encoder(x, token_meta=token_meta)  # [B, D]
        logits = self.classification_head(h)               # [B, 2]
        return logits
