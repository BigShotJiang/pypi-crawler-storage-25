"""Tests for the YAML configuration loader (config/loader.py).

Apache-2.0  --  SuShuHeng
"""

import os
import tempfile

import pytest
import yaml

from eemoclas.config.dataclasses import (
    AugmentationConfig,
    BandConfig,
    ChannelDropoutConfig,
    ChannelsConfig,
    ClassificationHeadConfig,
    Config,
    DataConfig,
    ExperimentConfig,
    GaussianNoiseConfig,
    InferenceConfig,
    InferenceModelConfig,
    LoggingConfig,
    MetricConfig,
    ModelConfig,
    ModelGroupConfig,
    OptimizerConfig,
    ProjectConfig,
    ResampleConfig,
    SamplingConfig,
    SchedulerConfig,
    SeedingConfig,
    SignalConfig,
    SplittingConfig,
    SubjectTransformerConfig,
    TaskConfig,
    TimeMaskConfig,
    TokenEmbeddingConfig,
    TrainingConfig,
    TransformerConfig,
    TrialEncoderConfig,
    ZscoreConfig,
)
from eemoclas.config.loader import (
    _build_band,
    _build_model,
    _build_seeding,
    _build_training,
    detect_config_format,
    load_config,
    load_yaml,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


# ---------------------------------------------------------------------------
# Legacy-format YAML fixtures
# ---------------------------------------------------------------------------

LEGACY_TRAIN_YAML = """
project:
  repo_name: "DGLZ"
  package_name: "eemoclas"
  cli_name: "eemo"
  experiment_family: "test_exp"

task:
  name: "subject_state"
  dataset_class: "SubjectStateDataset"
  num_classes: 2
  label_names: ["normal", "depression"]

data:
  manifest_file: "data/manifest.csv"
  config_snapshot: "data/config_snapshot.yaml"

signal:
  fs: 250
  train_segment_points: 12500
  window_points: 2500
  clip_std: 5.0
  zscore:
    enabled: true
    eps: 1.0e-6

channels:
  mode: "by_name"
  selected: "all"

band_definitions:
  delta: [1, 4]
  theta: [4, 7]
  alpha: [8, 13]
  beta: [13, 30]
  low_gamma: [30, 45]
  broadband: [1, 45]

channel_band_config:
  default_bands: ["broadband"]
  per_channel: {}

model:
  class_name: "SubjectStateCNNTransformer"
  input_num_trials: 8
  input_length: 2500
  num_classes: 2
  trial_encoder:
    projection_dim: 128
    cnn_channels: [16, 32, 64]
    kernel_sizes: [15, 9, 5]
    strides: [2, 2, 2]
    cnn_dropout: 0.1
    pooling: "cls"
    token_embedding:
      use_channel_embedding: true
      use_band_embedding: true
      use_cls_token: true
      embedding_dim: 128
    transformer:
      num_layers: 2
      num_heads: 4
      dim_feedforward: 256
      dropout: 0.1
      activation: "gelu"
      norm_first: true
      batch_first: true
  subject_transformer:
    use_cls_token: true
    use_trial_position_embedding: true
    embedding_dim: 128
    num_layers: 2
    num_heads: 4
    dim_feedforward: 256
    dropout: 0.1
    activation: "gelu"
    norm_first: true
    batch_first: true
  classification_head:
    hidden_dims: [128]
    dropout: 0.3

training:
  epochs: 100
  batch_size: 16
  optimizer: "adamw"
  lr: 1.0e-3
  weight_decay: 1.0e-4
  scheduler: "cosine"
  loss: "cross_entropy"
  early_stopping_patience: 15
  checkpoint_metric: "val_accuracy"
  save_latest: true
  save_best: true

augmentation:
  enabled: false
  gaussian_noise:
    enabled: false
  time_mask:
    enabled: false
  channel_dropout:
    enabled: false

splitting:
  method: "StratifiedGroupKFold"
  n_splits: 5
  group_key: "subject_id"
  stratify_key: "group_label"
  seed: 42

seeding:
  random_seed: 42
  split_seed: 42
  init_seed:
    subject_state: 42

metrics:
  primary: "accuracy"
  report:
    - accuracy
    - accuracy
    - macro_f1
    - roc_auc
"""


# ---------------------------------------------------------------------------
# Unified-format YAML fixtures
# ---------------------------------------------------------------------------

UNIFIED_YAML = """
project:
  repo_name: "DGLZ"
  package_name: "eemoclas"
  cli_name: "eemo"
  experiment_family: "eeg_three_stage_cnn_transformer"

inference:
  routing: "hard"
  use_4_4_constraint: true
  positive_label: "1"
  neutral_label: "0"
  output_format: "xlsx"
  models:
    subject_state:
      checkpoint: "checkpoints/subject_state/best_model.ckpt"
      config: "configs/train_subject_state.yaml"
    normal_emotion:
      checkpoint: "checkpoints/normal_emotion/best_model.ckpt"
      config: "configs/train_normal_emotion.yaml"

signal:
  fs: 250
  window_points: 2500
  zscore:
    enabled: true
    eps: 1.0e-6

channels:
  mode: "by_name"
  selected: "all"

metrics:
  primary: "accuracy"
  report:
    - accuracy
    - accuracy
"""


# ---------------------------------------------------------------------------
# Tests for detect_config_format
# ---------------------------------------------------------------------------

class TestDetectConfigFormat:
    """Tests for detect_config_format()."""

    def test_unified_has_models_dict(self):
        data = {"models": {"model_a": {"class_name": "Foo"}}, "training": {"epochs": 10}}
        assert detect_config_format(data) == "unified"

    def test_unified_empty_models_dict(self):
        data = {"models": {}}
        assert detect_config_format(data) == "unified"

    def test_legacy_has_training(self):
        data = {"training": {"epochs": 10}, "model": {"class_name": "Bar"}}
        assert detect_config_format(data) == "legacy"

    def test_legacy_minimal(self):
        data = {"signal": {"fs": 250}}
        assert detect_config_format(data) == "legacy"

    def test_models_is_string_not_unified(self):
        """If models is a string (unlikely but defensive), it is legacy."""
        data = {"models": "not a dict"}
        assert detect_config_format(data) == "legacy"

    def test_models_is_list_not_unified(self):
        data = {"models": [1, 2, 3]}
        assert detect_config_format(data) == "legacy"

    def test_empty_dict_is_legacy(self):
        assert detect_config_format({}) == "legacy"


# ---------------------------------------------------------------------------
# Tests for load_yaml
# ---------------------------------------------------------------------------

class TestLoadYaml:
    """Tests for load_yaml()."""

    def test_simple_load(self, tmp_dir):
        path = os.path.join(tmp_dir, "test.yaml")
        with open(path, "w") as f:
            yaml.dump({"key": "value", "nested": {"a": 1}}, f)
        result = load_yaml(path)
        assert result["key"] == "value"
        assert result["nested"]["a"] == 1

    def test_include_directive(self, tmp_dir):
        base_path = os.path.join(tmp_dir, "base.yaml")
        with open(base_path, "w") as f:
            yaml.dump({"base_key": "base_value", "shared": "from_base"}, f)

        main_path = os.path.join(tmp_dir, "main.yaml")
        with open(main_path, "w") as f:
            yaml.dump({"include": "base.yaml", "main_key": "main_value", "shared": "from_main"}, f)

        result = load_yaml(main_path)
        assert result["base_key"] == "base_value"
        assert result["main_key"] == "main_value"
        # main overrides base
        assert result["shared"] == "from_main"

    def test_include_list(self, tmp_dir):
        a_path = os.path.join(tmp_dir, "a.yaml")
        with open(a_path, "w") as f:
            yaml.dump({"a_key": "a_val"}, f)

        b_path = os.path.join(tmp_dir, "b.yaml")
        with open(b_path, "w") as f:
            yaml.dump({"b_key": "b_val"}, f)

        main_path = os.path.join(tmp_dir, "main.yaml")
        with open(main_path, "w") as f:
            yaml.dump({"include": ["a.yaml", "b.yaml"], "main_key": 1}, f)

        result = load_yaml(main_path)
        assert result["a_key"] == "a_val"
        assert result["b_key"] == "b_val"
        assert result["main_key"] == 1

    def test_circular_include_raises(self, tmp_dir):
        path_a = os.path.join(tmp_dir, "a.yaml")
        path_b = os.path.join(tmp_dir, "b.yaml")

        with open(path_a, "w") as f:
            yaml.dump({"include": "b.yaml"}, f)
        with open(path_b, "w") as f:
            yaml.dump({"include": "a.yaml"}, f)

        with pytest.raises(ValueError, match="Circular include"):
            load_yaml(path_a)

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError, match="Config file not found"):
            load_yaml("/nonexistent/path/config.yaml")

    def test_empty_yaml_returns_empty_dict(self, tmp_dir):
        path = os.path.join(tmp_dir, "empty.yaml")
        with open(path, "w") as f:
            f.write("")
        result = load_yaml(path)
        assert result == {}

    def test_include_removed_from_result(self, tmp_dir):
        base_path = os.path.join(tmp_dir, "base.yaml")
        with open(base_path, "w") as f:
            yaml.dump({"x": 1}, f)

        main_path = os.path.join(tmp_dir, "main.yaml")
        with open(main_path, "w") as f:
            yaml.dump({"include": "base.yaml", "y": 2}, f)

        result = load_yaml(main_path)
        assert "include" not in result
        assert result["x"] == 1
        assert result["y"] == 2


# ---------------------------------------------------------------------------
# Tests for load_config with legacy format
# ---------------------------------------------------------------------------

class TestLoadConfigLegacy:
    """Tests for load_config() with legacy-format YAML files."""

    def _write_legacy_yaml(self, tmp_dir: str, content: str = LEGACY_TRAIN_YAML) -> str:
        path = os.path.join(tmp_dir, "legacy_config.yaml")
        with open(path, "w") as f:
            f.write(content)
        return path

    def test_returns_config_instance(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        assert isinstance(cfg, Config)

    def test_project_section(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        assert isinstance(cfg.project, ProjectConfig)
        assert cfg.project.repo_name == "DGLZ"
        assert cfg.project.package_name == "eemoclas"
        assert cfg.project.cli_name == "eemo"
        assert cfg.project.experiment_family == "test_exp"

    def test_signal_section(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        assert isinstance(cfg.signal, SignalConfig)
        assert cfg.signal.fs == 250
        assert cfg.signal.window_points == 2500
        assert isinstance(cfg.signal.zscore, ZscoreConfig)
        assert cfg.signal.zscore.enabled is True
        assert cfg.signal.zscore.eps == 1e-6

    def test_channels_section(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        assert isinstance(cfg.channels, ChannelsConfig)
        assert cfg.channels.mode == "by_name"
        assert cfg.channels.selected == "all"

    def test_band_section(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        assert isinstance(cfg.band, BandConfig)
        assert "delta" in cfg.band.band_definitions
        assert "broadband" in cfg.band.band_definitions
        assert cfg.band.default_bands == ["broadband"]
        assert cfg.band.per_channel == {}

    def test_models_wrapped_as_single_entry(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        # Legacy config should have exactly one model entry
        assert len(cfg.models) == 1
        assert "subject_state" in cfg.models

    def test_model_group_has_task(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        mg = cfg.models["subject_state"]
        assert isinstance(mg, ModelGroupConfig)
        assert isinstance(mg.task, TaskConfig)
        assert mg.task.name == "subject_state"
        assert mg.task.dataset_class == "SubjectStateDataset"
        assert mg.task.num_classes == 2
        assert mg.task.label_names == ["normal", "depression"]

    def test_model_group_has_model(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        mc = cfg.models["subject_state"].model
        assert isinstance(mc, ModelConfig)
        assert mc.class_name == "SubjectStateCNNTransformer"
        assert mc.input_num_trials == 8
        assert mc.num_classes == 2
        assert isinstance(mc.trial_encoder, TrialEncoderConfig)
        assert mc.trial_encoder.projection_dim == 128
        assert mc.trial_encoder.cnn_channels == [16, 32, 64]
        assert isinstance(mc.trial_encoder.token_embedding, TokenEmbeddingConfig)
        assert mc.trial_encoder.token_embedding.embedding_dim == 128
        assert isinstance(mc.trial_encoder.transformer, TransformerConfig)
        assert mc.trial_encoder.transformer.num_layers == 2
        assert isinstance(mc.subject_transformer, SubjectTransformerConfig)
        assert mc.subject_transformer.embedding_dim == 128
        assert isinstance(mc.classification_head, ClassificationHeadConfig)
        assert mc.classification_head.dropout == 0.3

    def test_model_group_has_training(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        tc = cfg.models["subject_state"].training
        assert isinstance(tc, TrainingConfig)
        assert tc.epochs == 100
        assert tc.batch_size == 16
        assert tc.loss == "cross_entropy"
        # optimizer was a string "adamw" in the YAML
        assert isinstance(tc.optimizer, OptimizerConfig)
        assert tc.optimizer.type == "adamw"
        assert tc.optimizer.lr == 1e-3
        # scheduler was a string "cosine"
        assert isinstance(tc.scheduler, SchedulerConfig)
        assert tc.scheduler.type == "cosine"

    def test_model_group_has_augmentation(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        aug = cfg.models["subject_state"].augmentation
        assert isinstance(aug, AugmentationConfig)
        assert aug.enabled is False
        assert isinstance(aug.gaussian_noise, GaussianNoiseConfig)
        assert isinstance(aug.time_mask, TimeMaskConfig)
        assert isinstance(aug.channel_dropout, ChannelDropoutConfig)

    def test_model_group_has_splitting(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        sp = cfg.models["subject_state"].splitting
        assert isinstance(sp, SplittingConfig)
        assert sp.method == "StratifiedGroupKFold"
        assert sp.n_splits == 5

    def test_model_group_has_seeding(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        sd = cfg.models["subject_state"].seeding
        assert isinstance(sd, SeedingConfig)
        assert sd.random_seed == 42
        assert sd.split_seed == 42
        # init_seed was a dict {subject_state: 42}, should be extracted to int
        assert sd.init_seed == 42

    def test_metrics_section(self, tmp_dir):
        path = self._write_legacy_yaml(tmp_dir)
        cfg = load_config(path)
        assert isinstance(cfg.metrics, MetricConfig)
        assert cfg.metrics.primary == "accuracy"
        assert "accuracy" in cfg.metrics.report
        assert "accuracy" in cfg.metrics.report


# ---------------------------------------------------------------------------
# Tests for load_config with unified format
# ---------------------------------------------------------------------------

class TestLoadConfigUnified:
    """Tests for load_config() with unified-format YAML files."""

    def _write_unified_yaml(self, tmp_dir: str, content: str = UNIFIED_YAML) -> str:
        path = os.path.join(tmp_dir, "unified_config.yaml")
        with open(path, "w") as f:
            f.write(content)
        return path

    def test_returns_config_instance(self, tmp_dir):
        path = self._write_unified_yaml(tmp_dir)
        cfg = load_config(path)
        assert isinstance(cfg, Config)

    def test_inference_section(self, tmp_dir):
        path = self._write_unified_yaml(tmp_dir)
        cfg = load_config(path)
        assert isinstance(cfg.inference, InferenceConfig)
        assert cfg.inference.routing == "hard"
        assert cfg.inference.use_4_4_constraint is True
        assert len(cfg.inference.models) == 2
        assert "subject_state" in cfg.inference.models
        assert isinstance(cfg.inference.models["subject_state"], InferenceModelConfig)
        assert cfg.inference.models["subject_state"].checkpoint == "checkpoints/subject_state/best_model.ckpt"

    def test_signal_and_channels_shared(self, tmp_dir):
        path = self._write_unified_yaml(tmp_dir)
        cfg = load_config(path)
        assert cfg.signal.fs == 250
        assert cfg.channels.selected == "all"

    def test_models_empty_for_inference_only(self, tmp_dir):
        """Inference configs have an empty models dict (no training model groups)."""
        path = self._write_unified_yaml(tmp_dir)
        cfg = load_config(path)
        # The unified YAML above has models key with inference entries
        # but no model group entries (task/model/training sections)
        # So _build_models creates ModelGroupConfig with defaults for each entry
        assert isinstance(cfg.models, dict)


# ---------------------------------------------------------------------------
# Tests for builder helpers
# ---------------------------------------------------------------------------

class TestBuildBand:
    """Tests for _build_band()."""

    def test_with_band_definitions(self):
        band_defs = {"alpha": [8, 13], "beta": [13, 30]}
        cb_cfg = {"default_bands": ["alpha", "beta"], "per_channel": {}}
        result = _build_band(band_defs, cb_cfg)
        assert isinstance(result, BandConfig)
        assert result.band_definitions == {"alpha": [8, 13], "beta": [13, 30]}
        assert result.default_bands == ["alpha", "beta"]
        assert result.per_channel == {}

    def test_with_per_channel(self):
        band_defs = {"alpha": [8, 13]}
        cb_cfg = {
            "default_bands": ["alpha"],
            "per_channel": {"FP1": ["alpha"]},
        }
        result = _build_band(band_defs, cb_cfg)
        assert result.per_channel == {"FP1": ["alpha"]}

    def test_empty_uses_defaults(self):
        result = _build_band({}, {})
        assert isinstance(result, BandConfig)
        assert result.default_bands == []
        assert result.per_channel == {}


class TestBuildTraining:
    """Tests for _build_training()."""

    def test_optimizer_as_string(self):
        data = {"epochs": 50, "optimizer": "adamw", "lr": 0.01, "scheduler": "cosine"}
        result = _build_training(data)
        assert isinstance(result, TrainingConfig)
        assert isinstance(result.optimizer, OptimizerConfig)
        assert result.optimizer.type == "adamw"
        assert result.optimizer.lr == 0.01
        assert isinstance(result.scheduler, SchedulerConfig)
        assert result.scheduler.type == "cosine"

    def test_optimizer_as_dict(self):
        data = {
            "epochs": 50,
            "optimizer": {"type": "sgd", "lr": 0.1, "momentum": 0.95},
            "scheduler": {"type": "step", "step_size": 10},
        }
        result = _build_training(data)
        assert isinstance(result.optimizer, OptimizerConfig)
        assert result.optimizer.type == "sgd"
        assert result.optimizer.lr == 0.1
        assert result.optimizer.momentum == 0.95
        assert isinstance(result.scheduler, SchedulerConfig)
        assert result.scheduler.type == "step"
        assert result.scheduler.step_size == 10

    def test_defaults(self):
        result = _build_training({})
        assert isinstance(result, TrainingConfig)
        assert isinstance(result.optimizer, OptimizerConfig)
        assert isinstance(result.scheduler, SchedulerConfig)


class TestBuildSeeding:
    """Tests for _build_seeding()."""

    def test_init_seed_dict(self):
        data = {"random_seed": 42, "split_seed": 42, "init_seed": {"subject_state": 42}}
        result = _build_seeding(data)
        assert isinstance(result, SeedingConfig)
        assert result.init_seed == 42

    def test_init_seed_int(self):
        data = {"random_seed": 42, "split_seed": 42, "init_seed": 99}
        result = _build_seeding(data)
        assert result.init_seed == 99

    def test_init_seed_dict_multiple_entries(self):
        data = {"init_seed": {"a": 10, "b": 20}}
        result = _build_seeding(data)
        # Takes first value
        assert result.init_seed == 10

    def test_init_seed_empty_dict(self):
        data = {"init_seed": {}}
        result = _build_seeding(data)
        assert result.init_seed == 42  # fallback default

    def test_defaults(self):
        result = _build_seeding({})
        assert result.random_seed == 42
        assert result.split_seed == 42
        assert result.init_seed == 42


class TestBuildModel:
    """Tests for _build_model()."""

    def test_with_nested_trial_encoder(self):
        data = {
            "class_name": "TestModel",
            "num_classes": 3,
            "trial_encoder": {
                "projection_dim": 64,
                "cnn_channels": [8, 16],
                "kernel_sizes": [5, 3],
                "strides": [1, 1],
                "token_embedding": {"embedding_dim": 64},
                "transformer": {"num_layers": 4},
            },
            "classification_head": {"hidden_dims": [256], "dropout": 0.5},
        }
        result = _build_model(data)
        assert isinstance(result, ModelConfig)
        assert result.class_name == "TestModel"
        assert result.num_classes == 3
        assert isinstance(result.trial_encoder, TrialEncoderConfig)
        assert result.trial_encoder.projection_dim == 64
        assert isinstance(result.trial_encoder.token_embedding, TokenEmbeddingConfig)
        assert result.trial_encoder.token_embedding.embedding_dim == 64
        assert isinstance(result.trial_encoder.transformer, TransformerConfig)
        assert result.trial_encoder.transformer.num_layers == 4
        assert isinstance(result.classification_head, ClassificationHeadConfig)
        assert result.classification_head.hidden_dims == [256]
        assert result.classification_head.dropout == 0.5

    def test_with_subject_transformer(self):
        data = {
            "class_name": "SubModel",
            "subject_transformer": {
                "embedding_dim": 256,
                "num_layers": 3,
            },
        }
        result = _build_model(data)
        assert isinstance(result.subject_transformer, SubjectTransformerConfig)
        assert result.subject_transformer.embedding_dim == 256
        assert result.subject_transformer.num_layers == 3

    def test_without_subject_transformer(self):
        data = {"class_name": "SimpleModel"}
        result = _build_model(data)
        assert result.subject_transformer is None

    def test_unknown_keys_ignored(self):
        data = {"class_name": "X", "unknown_key": "should_be_ignored"}
        result = _build_model(data)
        assert result.class_name == "X"
        assert not hasattr(result, "unknown_key")


# ---------------------------------------------------------------------------
# Tests for load_config end-to-end with real config files
# ---------------------------------------------------------------------------

class TestLoadConfigRealFiles:
    """Tests loading actual config files from the repository."""

    @pytest.mark.skipif(
        not os.path.isfile("configs/train_subject_state.yaml"),
        reason="Config file not available",
    )
    def test_load_legacy_train_config(self):
        cfg = load_config("configs/train_subject_state.yaml")
        assert isinstance(cfg, Config)
        assert cfg.project.repo_name == "DGLZ"
        assert len(cfg.models) == 1
        assert "subject_state" in cfg.models
        mc = cfg.models["subject_state"].model
        assert mc.class_name == "SubjectStateCNNTransformer"
        assert isinstance(mc.subject_transformer, SubjectTransformerConfig)

    @pytest.mark.skipif(
        not os.path.isfile("configs/train_normal_emotion.yaml"),
        reason="Config file not available",
    )
    def test_load_legacy_emotion_config(self):
        cfg = load_config("configs/train_normal_emotion.yaml")
        assert isinstance(cfg, Config)
        assert "normal_emotion" in cfg.models
        mc = cfg.models["normal_emotion"].model
        assert mc.class_name == "NormalEmotionCNNTransformer"
        # No subject_transformer in emotion models
        assert mc.subject_transformer is None

    @pytest.mark.skipif(
        not os.path.isfile("configs/infer_three_stage.yaml"),
        reason="Config file not available",
    )
    def test_load_unified_inference_config(self):
        cfg = load_config("configs/infer_three_stage.yaml")
        assert isinstance(cfg, Config)
        assert isinstance(cfg.inference, InferenceConfig)
        assert len(cfg.inference.models) == 3
        assert "subject_state" in cfg.inference.models
        assert "normal_emotion" in cfg.inference.models
        assert "depression_emotion" in cfg.inference.models


# ---------------------------------------------------------------------------
# Tests for config_snapshot roundtrip via loader
# ---------------------------------------------------------------------------

class TestConfigSnapshotRoundtrip:
    """Verify that a loaded config can produce a valid snapshot."""

    def test_legacy_snapshot(self, tmp_dir):
        path = os.path.join(tmp_dir, "legacy.yaml")
        with open(path, "w") as f:
            f.write(LEGACY_TRAIN_YAML)
        cfg = load_config(path)
        snap = cfg.config_snapshot()
        assert isinstance(snap, dict)
        assert snap["project"]["repo_name"] == "DGLZ"
        assert "subject_state" in snap["models"]
        assert snap["models"]["subject_state"]["model"]["class_name"] == "SubjectStateCNNTransformer"
        # Verify no dataclass objects remain
        def _check(obj):
            if isinstance(obj, dict):
                for v in obj.values():
                    _check(v)
            elif isinstance(obj, list):
                for v in obj:
                    _check(v)
            else:
                assert not hasattr(obj, "__dataclass_fields__")
        _check(snap)

    def test_model_names_after_legacy_load(self, tmp_dir):
        path = os.path.join(tmp_dir, "legacy.yaml")
        with open(path, "w") as f:
            f.write(LEGACY_TRAIN_YAML)
        cfg = load_config(path)
        assert cfg.model_names() == ["subject_state"]
