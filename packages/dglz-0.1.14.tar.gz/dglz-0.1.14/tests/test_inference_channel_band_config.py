"""Test inference channel-band config loading."""

import os
import tempfile

import pytest
import yaml


class TestInferenceChannelBandConfig:
    """Tests for inference channel-band configuration."""

    def test_inference_loads_channel_band_config_from_fallback(self):
        """Test loading channel-band config from fallback config_snapshot path."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            # Create a mock config_snapshot.yaml
            snapshot = {
                "channels": {"mode": "by_name", "selected": "all"},
                "band_definitions": {"broadband": [1, 45]},
                "channel_band_config": {
                    "default_bands": ["broadband"],
                    "per_channel": {},
                },
            }
            snapshot_path = os.path.join(tmp_dir, "config_snapshot.yaml")
            with open(snapshot_path, "w") as f:
                yaml.dump(snapshot, f)

            # Verify the snapshot can be loaded
            from eemoclas.utils.config import resolve_c_eff
            loaded = yaml.safe_load(open(snapshot_path))
            c_eff = resolve_c_eff(loaded)

            assert c_eff == 30

    def test_infer_three_stage_yaml_has_required_fields(self):
        """Test that infer_three_stage.yaml has preprocess section."""
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "configs", "infer_three_stage.yaml",
        )
        if not os.path.exists(config_path):
            pytest.skip("infer_three_stage.yaml not found")

        with open(config_path) as f:
            config = yaml.safe_load(f)

        assert "preprocess" in config
        assert "channel_band_config_source" in config["preprocess"]
        assert "fallback_config_snapshot" in config["preprocess"]

    def test_infer_three_stage_fallback_paths(self):
        """Test that fallback_config_snapshot has all three model entries."""
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "configs", "infer_three_stage.yaml",
        )
        if not os.path.exists(config_path):
            pytest.skip("infer_three_stage.yaml not found")

        with open(config_path) as f:
            config = yaml.safe_load(f)

        fallback = config["preprocess"]["fallback_config_snapshot"]
        assert "subject_state" in fallback
        assert "normal_emotion" in fallback
        assert "depression_emotion" in fallback

    def test_inference_config_has_routing_info(self):
        """Test that infer config has routing and constraint settings."""
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "configs", "infer_three_stage.yaml",
        )
        if not os.path.exists(config_path):
            pytest.skip("infer_three_stage.yaml not found")

        with open(config_path) as f:
            config = yaml.safe_load(f)

        assert config["inference"]["routing"] == "hard"
        assert isinstance(config["inference"]["use_4_4_constraint"], bool)
