"""Tests for MultiModelTrainer orchestrator.

Apache-2.0  --  SuShuHeng
"""

from pathlib import Path

import pytest
import yaml

from eemoclas.config.dataclasses import (
    Config,
    DataConfig,
    ExperimentConfig,
    FlatTrialEncoderConfig,
    ModelGroupConfig,
    ModelConfig,
    TaskConfig,
    TrainingConfig,
    TrialEncoderConfig,
)
from eemoclas.training.experiment import ExperimentManager
from eemoclas.training.orchestrator import MultiModelTrainer


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------

def _make_config(tmp_path: Path, model_names: list[str] | None = None) -> Config:
    """Build a minimal Config with models and experiment rooted at *tmp_path*."""
    models: dict[str, ModelGroupConfig] = {}
    for name in model_names or []:
        models[name] = ModelGroupConfig(
            task=TaskConfig(name=name),
            model=ModelConfig(class_name="DummyModel"),
            training=TrainingConfig(epochs=1),
        )
    return Config(
        experiment=ExperimentConfig(
            name="test_exp",
            save_dir=str(tmp_path),
        ),
        models=models,
    )


# ---------------------------------------------------------------------------
# Init tests
# ---------------------------------------------------------------------------

class TestMultiModelTrainer:
    """Tests for MultiModelTrainer."""

    def test_init_sequential(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=["model_a", "model_b"])
        trainer = MultiModelTrainer(cfg, ["model_a", "model_b"], mode="sequential")
        assert trainer.model_names == ["model_a", "model_b"]
        assert trainer.mode == "sequential"
        assert trainer.results == {}

    def test_init_mixed(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=["seq_model", "par_model"])
        trainer = MultiModelTrainer(
            cfg,
            ["seq_model", "par_model"],
            mode="mixed",
            parallel_models=["par_model"],
        )
        assert trainer.mode == "mixed"
        assert trainer.parallel_models == ["par_model"]

    def test_init_invalid_mode(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=[])
        with pytest.raises(ValueError, match="Invalid mode"):
            MultiModelTrainer(cfg, [], mode="bogus")

    def test_experiment_dirs_created(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=["m1"])
        trainer = MultiModelTrainer(cfg, ["m1"])
        exp_dir = Path(cfg.experiment.experiment_dir)
        assert exp_dir.is_dir()
        assert (exp_dir / "checkpoints").is_dir()
        assert (exp_dir / "logs").is_dir()
        assert (exp_dir / "metrics").is_dir()
        assert (exp_dir / "results").is_dir()

    def test_run_sequential_creates_state(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=[])
        trainer = MultiModelTrainer(cfg, [], mode="sequential")
        result = trainer.run()
        assert result == {}
        state_path = Path(cfg.experiment.experiment_dir) / "training_state.yaml"
        assert state_path.exists()
        state = yaml.safe_load(state_path.read_text(encoding="utf-8"))
        assert "models" in state
        assert state["models"] == {}

    def test_config_snapshot_saved(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=[])
        trainer = MultiModelTrainer(cfg, [], mode="sequential")
        trainer.run()
        snapshot_path = Path(cfg.experiment.experiment_dir) / "config.yaml"
        assert snapshot_path.exists()
        snapshot = yaml.safe_load(snapshot_path.read_text(encoding="utf-8"))
        assert "experiment" in snapshot
        assert snapshot["experiment"]["name"] == "test_exp"

    def test_run_sequential_with_models(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=["alpha", "beta"])
        trainer = MultiModelTrainer(cfg, ["alpha", "beta"], mode="sequential")

        # Monkey-patch _train_single to avoid needing real manifests
        call_log: list[str] = []

        def _mock_train(model_name: str) -> dict:
            call_log.append(model_name)
            return {
                "epochs_trained": 5,
                "best_epoch": 3,
                "best_metrics": {"val_accuracy": 0.85},
                "total_time_seconds": 10.0,
                "early_stopped": False,
            }

        trainer._train_single = _mock_train
        result = trainer.run()

        assert call_log == ["alpha", "beta"]
        assert result["alpha"]["epochs_trained"] == 5
        assert result["alpha"]["early_stopped"] is False

        # Check training_state.yaml
        state_path = Path(cfg.experiment.experiment_dir) / "training_state.yaml"
        state = yaml.safe_load(state_path.read_text(encoding="utf-8"))
        assert state["models"]["alpha"]["status"] == "completed"
        assert state["models"]["beta"]["status"] == "completed"

    def test_run_sequential_model_dirs(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=["model_x"])
        trainer = MultiModelTrainer(cfg, ["model_x"], mode="sequential")

        # Mock _train_single but call _build_raw_dict to create checkpoint dir
        def _mock_train(model_name: str) -> dict:
            mc = cfg.get_model_config(model_name)
            trainer._build_raw_dict(model_name, mc)
            return {
                "epochs_trained": 0, "best_epoch": 0,
                "best_metrics": {}, "total_time_seconds": 0,
                "early_stopped": False,
            }

        trainer._train_single = _mock_train
        trainer.run()

        checkpoint_dir = Path(cfg.experiment.checkpoint_dir) / "model_x"
        assert checkpoint_dir.is_dir()

    def test_run_mixed_splits_models(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=["seq_m", "par_m"])
        trainer = MultiModelTrainer(
            cfg,
            ["seq_m", "par_m"],
            mode="mixed",
            parallel_models=["par_m"],
        )
        # Only test sequential portion with a mock for parallel to avoid
        # subprocess complexity in tests
        # Instead, verify that the orchestrator correctly separates models
        seq = [m for m in trainer.model_names if m not in trainer.parallel_models]
        par = [m for m in trainer.model_names if m in trainer.parallel_models]
        assert seq == ["seq_m"]
        assert par == ["par_m"]

    def test_train_single_result_shape(self, tmp_path: Path):
        """Verify _train_single returns the expected dict shape via mock."""
        cfg = _make_config(tmp_path, model_names=["solo"])
        trainer = MultiModelTrainer(cfg, ["solo"], mode="sequential")

        expected = {
            "epochs_trained": 2,
            "best_epoch": 1,
            "best_metrics": {},
            "total_time_seconds": 1.0,
            "early_stopped": False,
        }

        def _mock_train(model_name: str) -> dict:
            return expected

        trainer._train_single = _mock_train
        result = trainer._train_single("solo")
        assert result == expected

    def test_build_raw_dict_contains_keys(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=["mdl"])
        trainer = MultiModelTrainer(cfg, ["mdl"], mode="sequential")
        mc = cfg.models["mdl"]
        raw = trainer._build_raw_dict("mdl", mc)
        assert "task" in raw
        assert "model" in raw
        assert "training" in raw
        assert "augmentation" in raw
        assert "splitting" in raw
        assert "seeding" in raw
        assert "checkpoint_dir" in raw
        assert "log_dir" in raw
        assert raw["task"]["name"] == "mdl"

    def test_custom_experiment_manager(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=[])
        custom_mgr = ExperimentManager(
            ExperimentConfig(name="custom", save_dir=str(tmp_path))
        )
        trainer = MultiModelTrainer(
            cfg, [], mode="sequential", experiment_mgr=custom_mgr
        )
        assert trainer.experiment_mgr is custom_mgr

    def test_run_sequential_failure_marks_failed(self, tmp_path: Path):
        cfg = _make_config(tmp_path, model_names=["bad_model"])
        trainer = MultiModelTrainer(cfg, ["bad_model"], mode="sequential")

        # Monkey-patch _train_single to raise
        def _failing_train(model_name: str) -> dict:
            raise RuntimeError("training exploded")

        trainer._train_single = _failing_train

        with pytest.raises(RuntimeError, match="training exploded"):
            trainer.run()

        state_path = Path(cfg.experiment.experiment_dir) / "training_state.yaml"
        state = yaml.safe_load(state_path.read_text(encoding="utf-8"))
        assert state["models"]["bad_model"]["status"] == "failed"


# ---------------------------------------------------------------------------
# C_eff auto-resolution tests
# ---------------------------------------------------------------------------

class TestCEffResolution:
    """Tests for automatic C_eff resolution from config snapshots."""

    def _make_snapshot(self, tmp_path: Path, c_eff: int = 60) -> str:
        """Create a minimal resampling config snapshot with the given C_eff.

        With 30 channels and default_bands ["delta", "theta"], C_eff = 60.
        """
        snap_dir = tmp_path / "snapshot"
        snap_dir.mkdir(parents=True, exist_ok=True)
        snap_path = snap_dir / "config_snapshot.yaml"
        snap_path.write_text(
            yaml.dump(
                {
                    "band_definitions": {
                        "delta": [1, 4],
                        "theta": [4, 8],
                    },
                    "channels": {"mode": "by_name", "selected": "all"},
                    "channel_band_config": {
                        "default_bands": ["delta", "theta"],
                        "per_channel": {},
                    },
                },
                default_flow_style=False,
            ),
            encoding="utf-8",
        )
        return str(snap_path)

    def test_resolve_c_eff_from_snapshot(self, tmp_path: Path):
        """_resolve_c_eff_from_snapshot returns correct C_eff."""
        snap_path = self._make_snapshot(tmp_path, c_eff=60)
        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            data=DataConfig(config_snapshots={"subject_state": snap_path}),
        )
        trainer = MultiModelTrainer(cfg, ["subject_state"])
        c_eff = trainer._resolve_c_eff_from_snapshot("subject_state")
        assert c_eff == 60  # 30 channels × 2 bands

    def test_resolve_c_eff_dual_model_strips_prefix(self, tmp_path: Path):
        """Dual models look up snapshot by stripped name."""
        snap_path = self._make_snapshot(tmp_path)
        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            data=DataConfig(
                config_snapshots={"normal_emotion": snap_path},
            ),
        )
        trainer = MultiModelTrainer(cfg, ["dual_normal_emotion"])
        c_eff = trainer._resolve_c_eff_from_snapshot("dual_normal_emotion")
        assert c_eff == 60

    def test_resolve_c_eff_missing_snapshot_returns_none(self, tmp_path: Path):
        """Returns None when no snapshot path exists."""
        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            data=DataConfig(config_snapshots={}),
        )
        trainer = MultiModelTrainer(cfg, ["subject_state"])
        assert trainer._resolve_c_eff_from_snapshot("subject_state") is None

    def test_resolve_c_eff_bad_snapshot_returns_none(self, tmp_path: Path):
        """Returns None when snapshot file doesn't exist on disk."""
        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            data=DataConfig(
                config_snapshots={"subject_state": "/nonexistent/path.yaml"},
            ),
        )
        trainer = MultiModelTrainer(cfg, ["subject_state"])
        assert trainer._resolve_c_eff_from_snapshot("subject_state") is None

    def test_c_eff_injected_into_v1_trial_encoder(self, tmp_path: Path):
        """V1 single-branch model gets input_channels in trial_encoder."""
        snap_path = self._make_snapshot(tmp_path, c_eff=60)
        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            data=DataConfig(config_snapshots={"subject_state": snap_path}),
            models={
                "subject_state": ModelGroupConfig(
                    task=TaskConfig(name="subject_state"),
                    model=ModelConfig(
                        trial_encoder=TrialEncoderConfig(),
                    ),
                    training=TrainingConfig(epochs=1),
                ),
            },
        )
        trainer = MultiModelTrainer(cfg, ["subject_state"], verbose=False)
        mc = cfg.models["subject_state"]
        raw = trainer._build_raw_dict("subject_state", mc)

        # Before: trial_encoder has no input_channels (not a TrialEncoderConfig field)
        assert "input_channels" not in raw["model"]["trial_encoder"]

        # Inject
        c_eff = trainer._resolve_c_eff_from_snapshot("subject_state")
        assert c_eff == 60
        model_section = raw.setdefault("model", {})
        te_cfg = model_section.setdefault("trial_encoder", {})
        te_cfg["input_channels"] = c_eff

        assert raw["model"]["trial_encoder"]["input_channels"] == 60

    def test_c_eff_injected_into_v2_pp_only(self, tmp_path: Path):
        """V2 dual-branch model: C_eff goes to pp_trial_encoder, not raw."""
        snap_path = self._make_snapshot(tmp_path, c_eff=60)
        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            data=DataConfig(config_snapshots={"normal_emotion": snap_path}),
            models={
                "dual_normal_emotion": ModelGroupConfig(
                    task=TaskConfig(name="dual_normal_emotion"),
                    model=ModelConfig(
                        raw_trial_encoder=FlatTrialEncoderConfig(input_channels=30),
                        pp_trial_encoder=FlatTrialEncoderConfig(input_channels=30),
                    ),
                    training=TrainingConfig(epochs=1),
                ),
            },
        )
        trainer = MultiModelTrainer(cfg, ["dual_normal_emotion"], verbose=False)
        mc = cfg.models["dual_normal_emotion"]
        raw = trainer._build_raw_dict("dual_normal_emotion", mc)

        # Inject (simulating what _train_one_fold does)
        c_eff = trainer._resolve_c_eff_from_snapshot("dual_normal_emotion")
        assert c_eff == 60
        model_section = raw.setdefault("model", {})
        pp_cfg = model_section.setdefault("pp_trial_encoder", {})
        pp_cfg["input_channels"] = c_eff

        # PP branch gets C_eff
        assert raw["model"]["pp_trial_encoder"]["input_channels"] == 60
        # Raw branch stays at 30
        assert raw["model"]["raw_trial_encoder"]["input_channels"] == 30

    def test_c_eff_defaults_when_no_snapshot(self, tmp_path: Path):
        """Without a snapshot, input_channels stays at YAML/default value."""
        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            data=DataConfig(config_snapshots={}),
            models={
                "dual_normal_emotion": ModelGroupConfig(
                    task=TaskConfig(name="dual_normal_emotion"),
                    model=ModelConfig(
                        pp_trial_encoder=FlatTrialEncoderConfig(input_channels=30),
                    ),
                    training=TrainingConfig(epochs=1),
                ),
            },
        )
        trainer = MultiModelTrainer(cfg, ["dual_normal_emotion"], verbose=False)
        c_eff = trainer._resolve_c_eff_from_snapshot("dual_normal_emotion")
        assert c_eff is None  # No snapshot → no injection
