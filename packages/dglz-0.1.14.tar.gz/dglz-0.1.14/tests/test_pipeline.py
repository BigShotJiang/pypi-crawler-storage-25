"""Test three-stage inference pipeline."""

import pytest
import torch

from eemoclas.prediction.three_stage_pipeline import ThreeStagePredictor


# ---------------------------------------------------------------------------
# Use tiny dimensions to keep memory usage low in tests.
# The pipeline code expects shape [8, C_eff, 2500] for subject input and
# [C_eff, 2500] for emotion input, but internally it just does softmax
# and argmax -- the actual values don't matter for shape/format tests.
# We use C_eff=2 and length=50 (instead of 2500) to reduce memory.
# ---------------------------------------------------------------------------

TRIAL_LENGTH = 50  # Use small length for tests
C_EFF = 2


class _MockSubjectModel(torch.nn.Module):
    """Mock subject-state model: [B, 8, C_eff, L] -> [B, 2]."""

    def __init__(self):
        super().__init__()
        self.fc = torch.nn.Linear(C_EFF * TRIAL_LENGTH * 8, 2)

    def forward(self, x, token_meta=None, x_raw=None):
        return self.fc(x.flatten(1))


class _MockEmotionModel(torch.nn.Module):
    """Mock emotion model: [B, C_eff, L] -> [B, 2]."""

    def __init__(self):
        super().__init__()
        self.fc = torch.nn.Linear(C_EFF * TRIAL_LENGTH, 2)

    def forward(self, x, token_meta=None, x_raw=None):
        return self.fc(x.flatten(1))


class TestThreeStagePipeline:
    """Tests for the three-stage inference pipeline."""

    def test_pipeline_predict_subject_output_format(self):
        """Test that predict_subject returns DataFrame and routing dict."""
        device = torch.device("cpu")

        predictor = ThreeStagePredictor(
            subject_state_model=_MockSubjectModel(),
            normal_emotion_model=_MockEmotionModel(),
            depression_emotion_model=_MockEmotionModel(),
            device=device,
            config={},
        )

        trials_x = torch.randn(8, C_EFF, TRIAL_LENGTH)
        token_meta = [{"source_channel": "FP1", "band_name": "alpha"}] * C_EFF

        result_df, routing_info = predictor.predict_subject(
            trials_x=trials_x,
            token_meta=token_meta,
            user_id="test_sub_001",
        )

        # Check DataFrame format
        assert set(result_df.columns) == {"user_id", "trial_id", "Emotion_label"}
        assert len(result_df) == 8
        assert result_df["user_id"].unique().tolist() == ["test_sub_001"]
        assert list(result_df["trial_id"]) == list(range(1, 9))

        # Check routing info
        assert routing_info["user_id"] == "test_sub_001"
        assert "group_pred" in routing_info
        assert routing_info["group_pred"] in [0, 1]

    def test_pipeline_4_4_constraint_applied(self):
        """Test that exactly 4 positive labels per subject."""
        device = torch.device("cpu")

        predictor = ThreeStagePredictor(
            subject_state_model=_MockSubjectModel(),
            normal_emotion_model=_MockEmotionModel(),
            depression_emotion_model=_MockEmotionModel(),
            device=device,
            config={},
        )

        trials_x = torch.randn(8, C_EFF, TRIAL_LENGTH)
        token_meta = [{"source_channel": "FP1", "band_name": "alpha"}] * C_EFF

        result_df, _ = predictor.predict_subject(
            trials_x=trials_x,
            token_meta=token_meta,
            user_id="test_sub",
        )

        # Exactly 4 positive labels
        assert result_df["Emotion_label"].sum() == 4

    def test_pipeline_predict_all_subjects(self):
        """Test predict_all_subjects with multiple subjects."""
        device = torch.device("cpu")

        predictor = ThreeStagePredictor(
            subject_state_model=_MockSubjectModel(),
            normal_emotion_model=_MockEmotionModel(),
            depression_emotion_model=_MockEmotionModel(),
            device=device,
            config={},
        )

        test_subjects = [
            {
                "user_id": f"sub_{i:03d}",
                "trials_x": torch.randn(8, C_EFF, TRIAL_LENGTH),
                "token_meta": [{"source_channel": "FP1", "band_name": "alpha"}] * C_EFF,
            }
            for i in range(3)
        ]

        submission_df, routing_df = predictor.predict_all_subjects(test_subjects)

        assert len(submission_df) == 3 * 8
        assert len(routing_df) == 3
        assert set(submission_df.columns) == {"user_id", "trial_id", "Emotion_label"}
        # Each subject should have exactly 4 positive labels
        for _, group in submission_df.groupby("user_id"):
            assert group["Emotion_label"].sum() == 4

    def test_pipeline_routing_info_keys(self):
        """Test that routing info has all expected keys."""
        device = torch.device("cpu")

        predictor = ThreeStagePredictor(
            subject_state_model=_MockSubjectModel(),
            normal_emotion_model=_MockEmotionModel(),
            depression_emotion_model=_MockEmotionModel(),
            device=device,
            config={},
        )

        trials_x = torch.randn(8, C_EFF, TRIAL_LENGTH)
        token_meta = [{"source_channel": "FP1", "band_name": "alpha"}] * C_EFF

        _, routing_info = predictor.predict_subject(
            trials_x=trials_x,
            token_meta=token_meta,
            user_id="test_sub",
        )

        expected_keys = {
            "user_id", "group_pred",
            "group_prob_normal", "group_prob_depression",
            "routed_model",
        }
        assert expected_keys.issubset(set(routing_info.keys()))
        assert routing_info["routed_model"] in {"normal_emotion", "depression_emotion"}
