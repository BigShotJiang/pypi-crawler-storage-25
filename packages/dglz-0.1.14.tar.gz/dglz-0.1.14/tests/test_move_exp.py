# tests/test_move_exp.py
"""Tests for move_exp.py."""
import json
import os
from pathlib import Path

import pytest
import yaml


def _create_experiment(tmp_path: Path, exp_name: str, model: str) -> Path:
    """Create a mock experiment directory with all expected files."""
    exp_dir = tmp_path / "experiments" / exp_name
    exp_dir.mkdir(parents=True)

    # config.yaml
    (exp_dir / "config.yaml").write_text(yaml.dump({"experiment": {"name": exp_name}}))

    # training_state.yaml
    state = {"models": {model: {"status": "completed", "best_epoch": 3}}}
    (exp_dir / "training_state.yaml").write_text(yaml.dump(state))

    # metrics/{model}_history.csv
    metrics_dir = exp_dir / "metrics"
    metrics_dir.mkdir()
    (metrics_dir / f"{model}_history.csv").write_text(
        "epoch,val_accuracy,val_auc\n1,0.80,0.85\n2,0.85,0.90\n3,0.89,0.93\n"
    )

    # checkpoints/{model}/best_model.ckpt
    ckpt_dir = exp_dir / "checkpoints" / model
    ckpt_dir.mkdir(parents=True)
    (ckpt_dir / "best_model.ckpt").write_text("mock")

    return exp_dir


class TestMoveExp:
    def test_archive_experiment(self, tmp_path):
        _create_experiment(tmp_path, "b1-subj", "subject_state")

        # Create config file
        configs_dir = tmp_path / "configs"
        configs_dir.mkdir()
        (configs_dir / "b1-subj.yaml").write_text("test: true")

        # Create history file
        history_file = tmp_path / ".agent" / "dglztr" / "history_batch.json"
        history_file.parent.mkdir(parents=True)
        history_file.write_text("[]")

        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("me", "src/eemoclas/claude_templates/skills/move-exp/scripts/move_exp.py")
        mod = module_from_spec(spec)
        spec.loader.exec_module(mod)

        result = mod.archive_experiments(
            experiments_dir=str(tmp_path / "experiments"),
            configs_dir=str(configs_dir),
            exp_names=["b1-subj"],
            batch_num=1,
            stage="stage1",
            agent_dir=str(tmp_path / ".agent"),
        )

        assert result["archived"] == 1
        assert (tmp_path / "experiments" / "_Done" / "batch1" / "b1-subj").exists()
        assert (tmp_path / "configs" / "_Done" / "batch1" / "b1-subj.yaml").exists()
        assert not (tmp_path / "experiments" / "b1-subj").exists()

        # Verify history populated
        history = json.loads(history_file.read_text())
        assert len(history) == 1
        assert history[0]["exp_name"] == "b1-subj"
        assert history[0]["metrics"]["val_accuracy"] == 0.89

    def test_dry_run(self, tmp_path):
        _create_experiment(tmp_path, "b1-subj", "subject_state")
        configs_dir = tmp_path / "configs"
        configs_dir.mkdir()
        (configs_dir / "b1-subj.yaml").write_text("test: true")

        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("me", "src/eemoclas/claude_templates/skills/move-exp/scripts/move_exp.py")
        mod = module_from_spec(spec)
        spec.loader.exec_module(mod)

        result = mod.archive_experiments(
            experiments_dir=str(tmp_path / "experiments"),
            configs_dir=str(configs_dir),
            exp_names=["b1-subj"],
            batch_num=1,
            stage="stage1",
            agent_dir=str(tmp_path / ".agent"),
            dry_run=True,
        )

        assert result["archived"] == 1
        # Original should still exist in dry-run mode
        assert (tmp_path / "experiments" / "b1-subj").exists()
