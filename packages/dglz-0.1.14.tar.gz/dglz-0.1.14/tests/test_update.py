"""Tests for eemo update: update_log and version_check modules."""

from __future__ import annotations

import csv
import io
import json
import os
import sys
import textwrap
from datetime import datetime
from unittest import mock

import pytest


# ---------------------------------------------------------------------------
# Fixtures: sample CSV data
# ---------------------------------------------------------------------------

SAMPLE_CSV = textwrap.dedent("""\
    version,date,type,title,description,migration_steps
    0.1.12,2026-05-08,feature,eemo update 命令,新增 eemo update 命令,无需额外操作
    0.1.12,2026-05-08,feature,版本自动检测,每次执行 eemo 时自动检测,无需额外操作
    0.1.11.post9,2026-05-08,feature,动态流式内存预加载,自动感知内存变化,无需额外操作
    0.1.11.post8,2026-05-08,fix,预加载面板修复,修复 holdout 模式,无需额外操作
    0.1.11.post7,2026-05-08,fix,预加载面板缺失,修复 BUG,无需额外操作
    0.1.11.post6,2026-05-08,change,移除 balanced_accuracy,统一使用 accuracy,检查脚本引用
    0.1.10,2026-05-08,feature,Focal Loss,新增损失函数,无需额外操作
""")


class TestLoadUpdateLog:
    """Tests for load_update_log()."""

    def test_loads_all_rows(self, tmp_path):
        from eemoclas.cli.update_log import load_update_log

        csv_path = tmp_path / "update_log.csv"
        csv_path.write_text(SAMPLE_CSV, encoding="utf-8")

        with mock.patch("eemoclas.cli.update_log._csv_path", return_value=str(csv_path)):
            rows = load_update_log()

        assert len(rows) == 7
        assert rows[0]["version"] == "0.1.12"
        assert rows[-1]["version"] == "0.1.10"

    def test_each_row_has_required_keys(self, tmp_path):
        from eemoclas.cli.update_log import load_update_log

        csv_path = tmp_path / "update_log.csv"
        csv_path.write_text(SAMPLE_CSV, encoding="utf-8")

        with mock.patch("eemoclas.cli.update_log._csv_path", return_value=str(csv_path)):
            rows = load_update_log()

        required = {"version", "date", "type", "title", "description", "migration_steps"}
        for row in rows:
            assert required.issubset(row.keys())


class TestFilterUpdates:
    """Tests for filter_updates()."""

    def test_filters_between_versions(self):
        from eemoclas.cli.update_log import filter_updates

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        result = filter_updates(rows, "0.1.11.post7", "0.1.12")

        versions = {r["version"] for r in result}
        # Should include everything AFTER 0.1.11.post7 up to 0.1.12
        assert "0.1.12" in versions
        assert "0.1.11.post9" in versions
        assert "0.1.11.post8" in versions
        # Should NOT include 0.1.11.post7 (exclusive lower bound) or 0.1.10
        assert "0.1.11.post7" not in versions
        assert "0.1.10" not in versions

    def test_empty_range_when_already_latest(self):
        from eemoclas.cli.update_log import filter_updates

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        result = filter_updates(rows, "0.1.12", "0.1.12")
        assert len(result) == 0

    def test_single_version_jump(self):
        from eemoclas.cli.update_log import filter_updates

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        result = filter_updates(rows, "0.1.11.post8", "0.1.11.post9")

        versions = {r["version"] for r in result}
        assert versions == {"0.1.11.post9"}


class TestRenderUpdateMd:
    """Tests for render_update_md()."""

    def test_generates_markdown(self):
        from eemoclas.cli.update_log import filter_updates, render_update_md

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        filtered = filter_updates(rows, "0.1.11.post8", "0.1.11.post9")
        md = render_update_md(filtered, "0.1.11.post8", "0.1.11.post9")

        assert "# DGLZ 更新日志" in md
        assert "V0.1.11.post8" in md
        assert "V0.1.11.post9" in md
        assert "迁移步骤" in md

    def test_changelog_shows_new_to_old(self):
        from eemoclas.cli.update_log import filter_updates, render_update_md

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        filtered = filter_updates(rows, "0.1.11.post7", "0.1.12")
        md = render_update_md(filtered, "0.1.11.post7", "0.1.12")

        # Changelog section: versions appear new-to-old
        pos_0112 = md.index("V0.1.12")
        pos_post9 = md.index("V0.1.11.post9")
        pos_post8 = md.index("V0.1.11.post8")
        assert pos_0112 < pos_post9 < pos_post8

    def test_migration_shows_old_to_new(self):
        from eemoclas.cli.update_log import filter_updates, render_update_md

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        filtered = filter_updates(rows, "0.1.11.post7", "0.1.12")
        md = render_update_md(filtered, "0.1.11.post7", "0.1.12")

        # Migration section: find "迁移步骤" then check order is old-to-new
        migration_start = md.index("迁移步骤")
        pos_post8_m = md.index("V0.1.11.post8", migration_start)
        pos_post9_m = md.index("V0.1.11.post9", migration_start)
        pos_0112_m = md.index("V0.1.12", migration_start)
        assert pos_post8_m < pos_post9_m < pos_0112_m


# ---------------------------------------------------------------------------
# version_check tests
# ---------------------------------------------------------------------------


class TestVersionCache:
    """Tests for _cache_path, get_cached_latest, save_cache."""

    def test_save_and_load_cache(self, tmp_path):
        from eemoclas.cli.version_check import get_cached_latest, save_cache

        cache_file = tmp_path / "version_cache.json"
        with mock.patch("eemoclas.cli.version_check._cache_path", return_value=cache_file), \
             mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            save_cache("0.1.13")
            result = get_cached_latest()

        assert result == "0.1.13"

    def test_cache_returns_none_when_missing(self, tmp_path):
        from eemoclas.cli.version_check import get_cached_latest

        cache_file = tmp_path / "version_cache.json"
        with mock.patch("eemoclas.cli.version_check._cache_path", return_value=cache_file):
            result = get_cached_latest()

        assert result is None

    def test_cache_returns_none_when_expired(self, tmp_path):
        from eemoclas.cli.version_check import get_cached_latest

        cache_file = tmp_path / "version_cache.json"
        with mock.patch("eemoclas.cli.version_check._cache_path", return_value=cache_file):
            # Save with old timestamp
            cache_file.write_text(json.dumps({
                "last_check": "2020-01-01T00:00:00",
                "latest_version": "0.1.12",
            }))
            result = get_cached_latest()

        assert result is None


class TestCheckForUpdate:
    """Tests for check_for_update()."""

    def test_returns_latest_when_update_available(self):
        from eemoclas.cli.version_check import check_for_update

        # Mock PyPI response — must be newer than current __version__
        pypi_response = json.dumps({"info": {"version": "0.1.15"}}).encode()

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            latest, has_update = check_for_update()

        assert latest == "0.1.15"
        assert has_update is True

    def test_returns_false_when_already_latest(self):
        from eemoclas.cli.version_check import check_for_update

        pypi_response = json.dumps({"info": {"version": "0.1.13"}}).encode()

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            latest, has_update = check_for_update()

        assert has_update is False

    def test_returns_none_on_network_error(self):
        from eemoclas.cli.version_check import check_for_update

        with mock.patch("urllib.request.urlopen", side_effect=Exception("timeout")):
            latest, has_update = check_for_update()

        assert latest is None
        assert has_update is False


# ---------------------------------------------------------------------------
# update_cmd tests
# ---------------------------------------------------------------------------


class TestUpdateCommand:
    """Tests for the update CLI command."""

    def test_already_latest(self):
        """When already at latest version, command prints success and exits."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.13"}}).encode()

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "已是最新版本" in result.output

    def test_update_available_runs_pip(self):
        """When update available, command runs pip and generates output."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.15"}}).encode()

        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result), \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            # Mock load_update_log to return sample data
            sample_rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
            with mock.patch("eemoclas.cli.update_cmd.load_update_log", return_value=sample_rows):
                result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "更新成功" in result.output

    def test_windows_uses_detached_script(self):
        """On Windows, update spawns a detached .bat instead of pip directly."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.15"}}).encode()

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=True), \
             mock.patch("eemoclas.cli.update_cmd._windows_detached_update") as mock_win, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        mock_win.assert_called_once_with("0.1.15", mock.ANY)

    def test_unix_pip_failure_shows_manual_command(self):
        """On Unix, if pip fails, show manual recovery instructions."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.15"}}).encode()

        fail_result = mock.MagicMock(returncode=1, stderr="ERROR: something went wrong")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=fail_result), \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 1
        assert "更新失败" in result.output

    def test_network_error_shows_error(self):
        """When PyPI unreachable, command shows error message."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("urllib.request.urlopen", side_effect=Exception("timeout")), \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            result = runner.invoke(app, [])

        assert result.exit_code == 1
        assert "无法连接 PyPI" in result.output


class TestUpdateLog:
    """Tests for log_update()."""

    def test_appends_log_entry(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("SUCCESS", "0.1.11.post9 -> 0.1.12")

        log_path = tmp_path / "update.log"
        assert log_path.exists()
        content = log_path.read_text(encoding="utf-8")
        assert "SUCCESS | 0.1.11.post9 -> 0.1.12" in content

    def test_log_is_append_mode(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("SUCCESS", "0.1.11.post9 -> 0.1.12")
            log_update("SUCCESS", "0.1.12 -> 0.1.13")

        log_path = tmp_path / "update.log"
        lines = log_path.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) == 2


class TestLogUpdate:
    """Tests for log_update() structured format."""

    def test_log_update_with_action_and_detail(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("SUCCESS", "0.1.12 -> 0.1.13")

        log_path = tmp_path / "update.log"
        content = log_path.read_text(encoding="utf-8")
        assert "SUCCESS | 0.1.12 -> 0.1.13" in content

    def test_log_update_action_only(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("ALREADY_LATEST", "0.1.13")

        log_path = tmp_path / "update.log"
        content = log_path.read_text(encoding="utf-8")
        assert "ALREADY_LATEST | 0.1.13" in content

    def test_log_update_append_mode(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("SUCCESS", "0.1.12 -> 0.1.13")
            log_update("ALREADY_LATEST", "0.1.13")

        log_path = tmp_path / "update.log"
        lines = log_path.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) == 2
        assert "SUCCESS" in lines[0]
        assert "ALREADY_LATEST" in lines[1]

    def test_log_update_has_timestamp(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("FAILED", "timeout")

        log_path = tmp_path / "update.log"
        content = log_path.read_text(encoding="utf-8")
        import re
        assert re.match(r"\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\] FAILED", content)


class TestDetectRecord:
    """Tests for save_detect_record()."""

    def test_save_detect_record_success(self, tmp_path):
        from eemoclas.cli.version_check import save_detect_record

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            save_detect_record("0.1.12", "0.1.13", True, "success")

        detect_path = tmp_path / "update_detect.json"
        assert detect_path.exists()
        data = json.loads(detect_path.read_text(encoding="utf-8"))
        assert data["current_version"] == "0.1.12"
        assert data["latest_version"] == "0.1.13"
        assert data["has_update"] is True
        assert data["status"] == "success"

    def test_save_detect_record_network_error(self, tmp_path):
        from eemoclas.cli.version_check import save_detect_record

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            save_detect_record("0.1.12", None, False, "network_error")

        detect_path = tmp_path / "update_detect.json"
        data = json.loads(detect_path.read_text(encoding="utf-8"))
        assert data["latest_version"] is None
        assert data["has_update"] is False
        assert data["status"] == "network_error"

    def test_detect_record_has_timestamp(self, tmp_path):
        from eemoclas.cli.version_check import save_detect_record

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            save_detect_record("0.1.12", "0.1.12", False, "cache_hit")

        detect_path = tmp_path / "update_detect.json"
        data = json.loads(detect_path.read_text(encoding="utf-8"))
        assert "last_detect" in data
        datetime.fromisoformat(data["last_detect"])


class TestPlatformCheck:
    """Test _is_windows helper."""

    def test_is_windows_on_win32(self):
        from eemoclas.cli.update_cmd import _is_windows

        with mock.patch.object(sys, "platform", "win32"):
            assert _is_windows() is True

    def test_is_windows_on_linux(self):
        from eemoclas.cli.update_cmd import _is_windows

        with mock.patch.object(sys, "platform", "linux"):
            assert _is_windows() is False

    def test_is_windows_on_darwin(self):
        from eemoclas.cli.update_cmd import _is_windows

        with mock.patch.object(sys, "platform", "darwin"):
            assert _is_windows() is False


class TestBatScriptGeneration:
    """Test _generate_bat_script output."""

    def test_bat_contains_timeout_wait(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="0.1.15",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "timeout /t 3 /nobreak >nul" in script

    def test_bat_contains_exact_version_install(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="0.1.15",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "--no-cache-dir DGLZ==0.1.15" in script

    def test_bat_contains_fallback_upgrade(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="0.1.15",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "--no-cache-dir --upgrade DGLZ" in script
        assert script.count("--upgrade DGLZ") == 2

    def test_bat_contains_log_write(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="0.1.15",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "update.log" in script
        assert "SUCCESS" in script
        assert "FAILED" in script

    def test_bat_contains_self_delete(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="0.1.15",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert 'del /f "%~f0"' in script

    def test_bat_creates_log_dir(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="0.1.15",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "if not exist" in script
        assert "mkdir" in script


class TestLinuxRetry:
    """Tests for 3-attempt pip install fallback on Linux/macOS."""

    def test_first_attempt_succeeds(self):
        """Exact version install succeeds on first try."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.15"}}).encode()

        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result) as mock_pip, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "更新成功" in result.output
        assert mock_pip.call_count == 1
        mock_pip.assert_called_with(["--no-cache-dir", "DGLZ==0.1.15"])

    def test_fallback_on_exact_version_failure(self):
        """Exact version fails, falls back to --upgrade."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.15"}}).encode()

        fail_result = mock.MagicMock(returncode=1, stderr="not found")
        success_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", side_effect=[fail_result, success_result]) as mock_pip, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "更新成功" in result.output
        assert mock_pip.call_count == 2
        mock_pip.assert_any_call(["--no-cache-dir", "DGLZ==0.1.15"])
        mock_pip.assert_any_call(["--no-cache-dir", "--upgrade", "DGLZ"])

    def test_all_three_attempts_fail(self):
        """All 3 attempts fail -> show error."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.15"}}).encode()

        fail_result = mock.MagicMock(returncode=1, stderr="ERROR: something went wrong")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=fail_result) as mock_pip, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 1
        assert "更新失败" in result.output
        assert mock_pip.call_count == 3
