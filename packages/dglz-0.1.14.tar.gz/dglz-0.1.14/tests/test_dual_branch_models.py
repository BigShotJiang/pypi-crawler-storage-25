"""Tests for dual-branch model architecture."""

import pytest
import torch

from eemoclas.model.dual_branch_emotion import DualBranchEmotionCNNTransformer
from eemoclas.model.dual_branch_subject_state import DualBranchSubjectStateCNNTransformer


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_emotion_config(**overrides):
    """Create a minimal config for DualBranchEmotionCNNTransformer."""
    cfg = {
        "raw_trial_encoder": {
            "input_channels": 30,
            "input_length": 2500,
            "projection_dim": 64,
            "cnn_channels": [16, 32],
            "kernel_sizes": [7, 5],
            "strides": [2, 2],
            "cnn_dropout": 0.1,
            "use_channel_embedding": True,
            "use_band_embedding": False,
            "use_cls_token": True,
            "pooling": "cls",
        },
        "pp_trial_encoder": {
            "input_channels": 30,
            "input_length": 2500,
            "projection_dim": 64,
            "cnn_channels": [16, 32],
            "kernel_sizes": [7, 5],
            "strides": [2, 2],
            "cnn_dropout": 0.1,
            "use_channel_embedding": True,
            "use_band_embedding": True,
            "use_cls_token": True,
            "pooling": "cls",
        },
        "fusion_transformer": {
            "d_model": 64,
            "num_layers": 1,
            "num_heads": 2,
            "dim_feedforward": 128,
            "dropout": 0.1,
        },
        "classification_head": {
            "input_dim": 64,
            "num_classes": 2,
            "hidden_dims": [64],
            "dropout": 0.3,
        },
    }
    for k, v in overrides.items():
        cfg[k] = v
    return cfg


def _make_pp_token_meta(n_channels=30):
    """Synthetic token_meta for PP branch (30 channels with bands)."""
    bands = ["alpha", "beta"]
    meta = []
    for ch in ["FP1", "FP2", "F7", "F3", "FZ", "F4", "F8", "FC5",
               "FC1", "FC2", "FC6", "T7", "C3", "CZ", "C4", "T8",
               "TP9", "CP5", "CP1", "CP2", "CP6", "TP10", "P7",
               "P3", "PZ", "P4", "P8", "PO9", "O1", "O2"][:n_channels]:
        for band in bands:
            meta.append({"source_channel": ch, "band_name": band})
    return meta


# ---------------------------------------------------------------------------
# DualBranchEmotionCNNTransformer Tests
# ---------------------------------------------------------------------------

class TestDualBranchEmotionModel:

    def test_forward_output_shape(self):
        """Forward pass produces [B, 2] logits."""
        config = _make_emotion_config()
        model = DualBranchEmotionCNNTransformer(config)
        B = 4
        x = torch.randn(B, 60, 2500)   # C_eff=60 (30ch * 2 bands)
        x_raw = torch.randn(B, 30, 2500)
        token_meta = _make_pp_token_meta(30)  # 60 entries

        out = model(x, token_meta=token_meta, x_raw=x_raw)
        assert out.shape == (B, 2)

    def test_forward_gradients_flow(self):
        """Gradients flow through both branches."""
        config = _make_emotion_config()
        model = DualBranchEmotionCNNTransformer(config)
        x = torch.randn(2, 60, 2500)
        x_raw = torch.randn(2, 30, 2500)
        token_meta = _make_pp_token_meta(30)

        out = model(x, token_meta=token_meta, x_raw=x_raw)
        loss = out.sum()
        loss.backward()

        for name, p in model.named_parameters():
            if p.grad is None:
                pytest.fail(f"No gradient for {name}")

    def test_x_raw_none_raises(self):
        """Dual-branch model requires x_raw."""
        config = _make_emotion_config()
        model = DualBranchEmotionCNNTransformer(config)
        x = torch.randn(2, 60, 2500)
        token_meta = _make_pp_token_meta(30)

        with pytest.raises(ValueError, match="x_raw"):
            model(x, token_meta=token_meta, x_raw=None)


def _make_subject_state_config(**overrides):
    """Create a minimal config for DualBranchSubjectStateCNNTransformer."""
    cfg = {
        "raw_trial_encoder": {
            "input_channels": 30,
            "input_length": 2500,
            "projection_dim": 64,
            "cnn_channels": [16, 32],
            "kernel_sizes": [7, 5],
            "strides": [2, 2],
            "cnn_dropout": 0.1,
            "use_channel_embedding": True,
            "use_band_embedding": False,
            "use_cls_token": True,
            "pooling": "cls",
        },
        "pp_trial_encoder": {
            "input_channels": 30,
            "input_length": 2500,
            "projection_dim": 64,
            "cnn_channels": [16, 32],
            "kernel_sizes": [7, 5],
            "strides": [2, 2],
            "cnn_dropout": 0.1,
            "use_channel_embedding": True,
            "use_band_embedding": True,
            "use_cls_token": True,
            "pooling": "cls",
        },
        "fusion_transformer": {
            "d_model": 64,
            "num_layers": 1,
            "num_heads": 2,
            "dim_feedforward": 128,
            "dropout": 0.1,
        },
        "classification_head": {
            "input_dim": 64,
            "num_classes": 2,
            "hidden_dims": [64],
            "dropout": 0.3,
        },
        "num_trials": 8,
    }
    for k, v in overrides.items():
        cfg[k] = v
    return cfg


# ---------------------------------------------------------------------------
# DualBranchSubjectStateCNNTransformer Tests
# ---------------------------------------------------------------------------

class TestDualBranchSubjectStateModel:

    def test_forward_output_shape(self):
        """Forward pass produces [B, 2] logits with [B, 8, *, 2500] input."""
        config = _make_subject_state_config()
        model = DualBranchSubjectStateCNNTransformer(config)
        B = 2
        x = torch.randn(B, 8, 60, 2500)      # PP: [B, 8, C_eff, 2500]
        x_raw = torch.randn(B, 8, 30, 2500)   # Raw: [B, 8, 30, 2500]
        token_meta = _make_pp_token_meta(30)

        out = model(x, token_meta=token_meta, x_raw=x_raw)
        assert out.shape == (B, 2)

    def test_forward_gradients_flow(self):
        """Gradients flow through both branches."""
        config = _make_subject_state_config()
        model = DualBranchSubjectStateCNNTransformer(config)
        x = torch.randn(1, 8, 60, 2500)
        x_raw = torch.randn(1, 8, 30, 2500)
        token_meta = _make_pp_token_meta(30)

        out = model(x, token_meta=token_meta, x_raw=x_raw)
        loss = out.sum()
        loss.backward()

        for name, p in model.named_parameters():
            if p.grad is None:
                pytest.fail(f"No gradient for {name}")

    def test_x_raw_none_raises(self):
        """Dual-branch model requires x_raw."""
        config = _make_subject_state_config()
        model = DualBranchSubjectStateCNNTransformer(config)
        x = torch.randn(1, 8, 60, 2500)
        token_meta = _make_pp_token_meta(30)

        with pytest.raises(ValueError, match="x_raw"):
            model(x, token_meta=token_meta, x_raw=None)
