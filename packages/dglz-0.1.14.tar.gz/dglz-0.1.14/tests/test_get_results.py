# tests/test_get_results.py
"""Tests for get_results.py."""
import json
import os
from pathlib import Path

import pytest
import yaml


def _create_experiment(tmp_path: Path, exp_name: str, model: str,
                       metrics_csv: str, state: dict,
                       kfold_summary: dict | None = None) -> Path:
    """Create a mock experiment directory."""
    exp_dir = tmp_path / "experiments" / exp_name
    exp_dir.mkdir(parents=True)

    # training_state.yaml
    state_path = exp_dir / "training_state.yaml"
    state_path.write_text(yaml.dump(state, allow_unicode=True, default_flow_style=False))

    # metrics/{model}_history.csv
    metrics_dir = exp_dir / "metrics"
    metrics_dir.mkdir()
    (metrics_dir / f"{model}_history.csv").write_text(metrics_csv)

    # kfold_summary.yaml (optional)
    if kfold_summary:
        ckpt_dir = exp_dir / "checkpoints" / model
        ckpt_dir.mkdir(parents=True)
        (ckpt_dir / "kfold_summary.yaml").write_text(
            yaml.dump(kfold_summary, allow_unicode=True, default_flow_style=False)
        )

    return exp_dir


HOLDOUT_CSV = "epoch,train_loss,train_accuracy,val_loss,val_accuracy,val_macro_f1,val_auc,lr,time_s\n1,1.5,0.6,1.2,0.65,0.63,0.70,0.0001,10.0\n2,1.0,0.75,0.9,0.80,0.78,0.85,0.0001,10.5\n3,0.8,0.82,0.7,0.85,0.83,0.90,0.0001,11.0\n"

HOLDOUT_STATE = {
    "models": {
        "subject_state": {"status": "completed", "best_epoch": 3}
    }
}


class TestExtractMetrics:
    def test_holdout_experiment(self, tmp_path):
        _create_experiment(tmp_path, "b1-subj", "subject_state", HOLDOUT_CSV, HOLDOUT_STATE)
        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("gr", "src/eemoclas/claude_templates/skills/get-results/scripts/get_results.py")
        mod = module_from_spec(spec)
        spec.loader.exec_module(mod)

        results = mod.extract_results(str(tmp_path / "experiments"), ["b1-subj"])
        assert len(results) == 1
        r = results[0]
        assert r["exp_name"] == "b1-subj"
        assert r["split_method"] == "holdout"
        assert r["best_metrics"]["val_accuracy"] == 0.85
        assert r["best_metrics"]["val_auc"] == 0.90
        assert r["best_epoch"] == 3

    def test_kfold_experiment(self, tmp_path):
        kfold_summary = {
            "method": "StratifiedGroupKFold",
            "n_splits": 3,
            "folds": {
                "fold_0": {"best_metrics": {"val_accuracy": 0.88, "val_auc": 0.92}},
                "fold_1": {"best_metrics": {"val_accuracy": 0.91, "val_auc": 0.95}},
                "fold_2": {"best_metrics": {"val_accuracy": 0.87, "val_auc": 0.91}},
            },
            "aggregated": {
                "val_accuracy": {"mean": 0.887, "std": 0.017, "values": [0.88, 0.91, 0.87]},
                "val_auc": {"mean": 0.927, "std": 0.017, "values": [0.92, 0.95, 0.91]},
            },
        }
        _create_experiment(
            tmp_path, "b1-subj-kfold", "subject_state", HOLDOUT_CSV, HOLDOUT_STATE,
            kfold_summary=kfold_summary,
        )
        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("gr", "src/eemoclas/claude_templates/skills/get-results/scripts/get_results.py")
        mod = module_from_spec(spec)
        spec.loader.exec_module(mod)

        results = mod.extract_results(str(tmp_path / "experiments"), ["b1-subj-kfold"])
        assert len(results) == 1
        r = results[0]
        assert r["split_method"] == "StratifiedGroupKFold"
        assert r["aggregated_metrics"]["val_accuracy"]["mean"] == 0.887
        assert r["best_fold_idx"] == 1  # fold_1 has highest balanced_accuracy
