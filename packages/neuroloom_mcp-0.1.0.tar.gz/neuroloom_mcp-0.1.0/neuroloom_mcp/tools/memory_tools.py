"""
Memory tools for the Neuroloom MCP server.

Implements eight memory-related MCP tools that delegate to the Neuroloom
REST API via NeuroloomAPIClient. Each tool returns a dict that the server
serialises to JSON for the MCP client.

Tools:
    memory_search        — combined keyword + semantic search
    memory_get_detail    — full memory with relationship graph
    memory_get_timeline  — recent memories ordered by time
    memory_get_index     — lightweight title-only overview
    memory_get_related   — semantically similar memories
    memory_by_file       — memories linked to a specific file path
    memory_store         — persist a pre-structured memory directly
    memory_rate          — record usefulness feedback for a memory
    memory_explore       — topic-scoped subgraph (nodes + edges)

Token passthrough (HTTP mode):
    In HTTP transport mode the ``call_tool`` handler injects ``_request_token``
    into the arguments dict. Each tool accepts this as an optional kwarg and
    passes it to ``NeuroloomAPIClient(token=token)`` so downstream API calls
    carry the per-client bearer token rather than a server-level credential.
    In stdio mode ``_request_token`` is absent and NeuroloomAPIClient falls back
    to ``settings.memories_api_token``.
"""

import logging
from typing import Any, Optional

from neuroloom_mcp.client import APIError, NeuroloomAPIClient
from neuroloom_mcp.config import get_settings

logger = logging.getLogger(__name__)


async def memory_search(
    query: str,
    workspace_id: Optional[str] = None,
    memory_types: Optional[list[str]] = None,
    tags: Optional[list[str]] = None,
    files: Optional[list[str]] = None,
    tag_prefixes: Optional[list[str]] = None,
    min_importance: Optional[float] = None,
    min_confidence: Optional[float] = None,
    limit: int = 5,
    max_tokens: Optional[int] = None,
    search_profile: str = "default",
    min_score: float = 0.15,
    compact: bool = True,
    max_narrative_chars: Optional[int] = 500,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Search the Neuroloom knowledge graph with semantic and keyword matching.

    Combines keyword frequency scoring with pgvector semantic similarity to
    surface the most relevant memories. By default (compact=True), each result
    is a lightweight flat dict containing only: ``memory_id``, ``title``,
    ``memory_type``, ``score``, ``snippet``, ``tags``, ``source_files``, and
    ``rerank_score``. The full narrative and relationship graph are NOT included.
    Results are flat — there is no nested ``memory`` key.

    To retrieve the full narrative and relationship graph for a candidate, call
    ``memory_get_detail`` with the ``memory_id``. Do this for the 1–3 most
    relevant results rather than every result in the list.

    Args:
        query: Natural language search query.
        workspace_id: Target workspace (uses MEMORIES_WORKSPACE_ID if omitted).
        memory_types: Filter by memory type (e.g. ["decision", "pattern"]).
        tags: Filter by exact tags.
        files: Filter to memories linked to these file paths.
        tag_prefixes: Filter to memories whose tags start with any of these
            prefixes (e.g. ["lang:", "feat:"] matches "lang:python", "feat:auth").
        min_importance: Minimum importance score (0.0–1.0).
        min_confidence: Minimum confidence score (0.0–1.0).
        limit: Maximum number of results (default 5). Raise to 10–20 for broad
            surveys or file-scoped queries.
        max_tokens: Token budget for results. When set, results are truncated to
            stay within this token count.
        max_narrative_chars: When set, truncates each result's ``snippet`` field
            to this many characters (appending "...") before returning. Defaults
            to 500, keeping results token-light. Set to None to receive full
            snippets. Use ``memory_get_detail`` for the complete narrative once
            you've identified the relevant memory.
        search_profile: Search profile controlling retrieval strategy. Supported
            values: default, exact, exploration, recency, file-scoped.
        min_score: Minimum cross-encoder relevance score to include in results
            (default 0.15). Applied only to reranked results — non-reranked
            results always pass through. Relevant pairs typically score 0.22–0.29;
            noise scores 0.01–0.07.
        compact: When True (default), returns lightweight summaries. Set False
            to receive full memory objects (needed for batch processing).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``count``, ``query``, ``filters``, and ``results`` list. In
        compact mode, each result is a flat dict with ``memory_id``, ``title``,
        ``memory_type``, ``score``, ``snippet`` (falls back to first 200 chars
        of narrative when no FTS snippet is available), ``tags``,
        ``source_files``, and ``rerank_score``.
    """
    settings = get_settings()
    # In HTTP mode workspace is resolved per-client from their token server-side;
    # only fall back to settings.workspace_id in stdio mode (where it is set).
    ws_id = workspace_id or (settings.workspace_id if not _request_token else None)

    if not ws_id and not _request_token:
        return {
            "error": "No workspace_id provided and MEMORIES_WORKSPACE_ID is not configured.",
        }

    effective_limit = min(limit, settings.max_search_limit)

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            result = await client.search_memories(
                query=query,
                workspace_id=ws_id,
                memory_types=memory_types,
                tags=tags,
                files=files,
                tag_prefixes=tag_prefixes,
                min_importance=min_importance,
                min_confidence=min_confidence,
                limit=effective_limit,
                max_tokens=max_tokens,
                search_profile=search_profile,
                compact=compact,
                min_score=min_score,
            )

            # Non-critical: record retrieval for importance scoring.
            # Compact mode returns flat dicts (memory_id at top level);
            # non-compact returns nested dicts (memory_id under "memory" key).
            for item in result.get("results", []):
                memory_id = item.get("memory_id") or item.get("memory", {}).get("memory_id")
                if memory_id:
                    try:
                        await client.record_memory_retrieval(memory_id)
                    except Exception:
                        pass

            # Truncate snippets to keep agent context windows lean.
            # Think of this like a library card catalog: the snippet is the
            # card's blurb — just enough to decide whether to pull the full
            # book (memory_get_detail). max_narrative_chars is how long that
            # blurb is allowed to be.
            if max_narrative_chars is not None:
                for item in result.get("results", []):
                    snippet = item.get("snippet", "")
                    if len(snippet) > max_narrative_chars:
                        item["snippet"] = snippet[:max_narrative_chars] + "..."

            return result  # type: ignore[return-value]

    except APIError as e:
        logger.error("memory_search failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def memory_get_detail(
    memory_id: str,
    include_related: bool = True,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Full detail counterpart to memory_search.

    Returns the complete memory record including narrative, tags, concepts,
    source files, importance/confidence scores, and relationship edges (both
    outgoing and incoming). Use ``memory_search`` to surface candidates, then
    call this tool for the 1–3 most relevant results to retrieve the full
    payload. Optionally appends semantically similar memories.

    Args:
        memory_id: The ``memory_id`` string (e.g. ``mem-abc123``).
        include_related: When True, appends up to 5 related memories (default True).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Full memory detail dict, with an optional ``related_memories`` key.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            result = await client.get_memory_detail(memory_id)

            # Non-critical: record access for importance scoring
            try:
                await client.record_memory_access(memory_id)
            except Exception:
                pass

            if include_related:
                try:
                    related = await client.get_related_memories(memory_id, limit=5)
                    result["related_memories"] = related
                except Exception:
                    result["related_memories"] = []

            return result  # type: ignore[return-value]

    except APIError as e:
        logger.error("memory_get_detail failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def memory_get_timeline(
    workspace_id: Optional[str] = None,
    days: int = 7,
    limit: int = 30,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Get recent memories for a workspace, ordered by creation time descending.

    Provides a chronological view of the knowledge graph — useful for
    understanding what was captured during a recent work period.

    Args:
        workspace_id: Target workspace (uses MEMORIES_WORKSPACE_ID if omitted).
        days: How many days back to look (default 7). Applied client-side as
              the ``GET /memories/`` endpoint does not filter by date.
        limit: Maximum number of memories to return (default 30).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``count`` and ``memories`` list ordered newest-first.
    """
    settings = get_settings()
    ws_id = workspace_id or (settings.workspace_id if not _request_token else None)

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            # The Neuroloom API list endpoint orders by importance desc / created desc.
            # We request the full page and let the caller interpret recency.
            memories = await client.list_memories(limit=limit)

        from datetime import datetime, timezone, timedelta

        cutoff = datetime.now(timezone.utc) - timedelta(days=days)

        filtered: list[dict[str, Any]] = []
        for mem in memories:
            created_raw = mem.get("created_at")
            if created_raw:
                try:
                    created = datetime.fromisoformat(created_raw.replace("Z", "+00:00"))
                    if created >= cutoff:
                        filtered.append(mem)
                except ValueError:
                    filtered.append(mem)  # include if date unparseable
            else:
                filtered.append(mem)

        return {
            "count": len(filtered),
            "days": days,
            "workspace_id": ws_id,
            "memories": filtered,
        }

    except APIError as e:
        logger.error("memory_get_timeline failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def memory_get_index(
    workspace_id: Optional[str] = None,
    limit: int = 50,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Return a lightweight index of all memories (titles and types only).

    The most token-efficient way to survey the knowledge graph before
    deciding which memories to retrieve in full. Use ``memory_get_detail``
    to follow up on specific IDs returned here.

    Args:
        workspace_id: Target workspace (uses MEMORIES_WORKSPACE_ID if omitted).
        limit: Maximum number of entries to return (default 50).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``count`` and ``memories`` list (memory_id, title, memory_type,
        importance_score, created_at only).
    """
    settings = get_settings()
    ws_id = workspace_id or (settings.workspace_id if not _request_token else None)

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            memories = await client.list_memories(limit=limit)

        # Return a trimmed projection to keep token usage low
        index = [
            {
                "memory_id": m.get("memory_id"),
                "title": m.get("title"),
                "memory_type": m.get("memory_type"),
                "importance_score": m.get("importance_score"),
                "created_at": m.get("created_at"),
            }
            for m in memories
        ]

        return {
            "count": len(index),
            "workspace_id": ws_id,
            "memories": index,
        }

    except APIError as e:
        logger.error("memory_get_index failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def memory_get_related(
    memory_id: str,
    limit: int = 10,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Find memories semantically similar to a given memory.

    Uses pgvector cosine similarity on stored embeddings. Requires the
    source memory to have a generated embedding; returns an empty list
    if the embedding is not yet available.

    Args:
        memory_id: The ``memory_id`` of the source memory.
        limit: Maximum number of related memories (default 10).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``memory_id``, ``count``, and ``related`` list of SearchResult objects.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            related = await client.get_related_memories(memory_id, limit=limit)

        return {
            "memory_id": memory_id,
            "count": len(related) if isinstance(related, list) else 0,
            "related": related,
        }

    except APIError as e:
        logger.error("memory_get_related failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def memory_by_file(
    file_path: str,
    workspace_id: Optional[str] = None,
    limit: int = 10,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Find memories that reference a specific file path.

    Delegates to the search endpoint with the ``files`` filter applied.
    Useful when opening a file to surface past decisions and context
    captured while working on it.

    Args:
        file_path: File path to search for (partial matches are supported).
        workspace_id: Target workspace (uses MEMORIES_WORKSPACE_ID if omitted).
        limit: Maximum number of results (default 10).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``file_path``, ``count``, and ``results`` list.
    """
    settings = get_settings()
    ws_id = workspace_id or (settings.workspace_id if not _request_token else None)

    if not ws_id and not _request_token:
        return {
            "error": "No workspace_id provided and MEMORIES_WORKSPACE_ID is not configured.",
        }

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            result = await client.search_memories(
                query=file_path,
                workspace_id=ws_id,
                files=[file_path],
                limit=limit,
            )

            # Non-critical: record retrieval for importance scoring.
            # Defensive dual-key lookup: compact mode returns flat dicts
            # (memory_id at top level); non-compact nests under "memory" key.
            for item in result.get("results", []):
                memory_id = item.get("memory_id") or item.get("memory", {}).get("memory_id")
                if memory_id:
                    try:
                        await client.record_memory_retrieval(memory_id)
                    except Exception:
                        pass

        return {
            "file_path": file_path,
            "count": result.get("count", 0),
            "results": result.get("results", []),
        }

    except APIError as e:
        logger.error("memory_by_file failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def memory_store(
    title: str,
    memory_type: str,
    content: str,
    workspace_id: Optional[str] = None,
    concepts: Optional[list[str]] = None,
    tags: Optional[list[str]] = None,
    files: Optional[list[str]] = None,
    context_files: Optional[list[str]] = None,
    importance: float = 0.7,
    confidence: float = 0.8,
    summary: Optional[str] = None,
    sync_embedding: bool = False,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Persist a pre-structured memory directly to the Neuroloom knowledge graph.

    Bypasses the observation pipeline. Use this when you have already
    synthesised a well-formed insight and want to persist it immediately,
    without waiting for async LLM extraction.

    After storing, the API enqueues embedding generation and relationship
    discovery in the background.

    For code-related memories (decision, pattern, bug_fix, architecture,
    implementation), always include relevant file paths in the ``files``
    parameter. This enables code graph linking — memories with file paths
    can be surfaced when navigating the structural code graph.

    Parameter mapping (MCP tool → API field):
        summary     → prepended to narrative as "Summary: {summary}\\n\\n{content}"
        content     → narrative (after optional summary prepend)
        files       → source_files
        importance  → importance_score
        confidence  → confidence_score

    Args:
        title: Memory title (required).
        memory_type: Category — e.g. pattern, decision, architecture, insight.
        content: The primary memory narrative (required).
        workspace_id: Target workspace (uses MEMORIES_WORKSPACE_ID if omitted).
        concepts: Key concept labels (used for relationship discovery).
        tags: Freeform tags for filtering.
        files: Source file paths involved.
        context_files: Additional file paths from the current editing context.
            Merged into ``files`` with deduplication. Use this to pass the files
            you are currently working with, even if they aren't the primary
            subject of the memory.
        importance: Importance score 0.0–1.0 (default 0.7).
        confidence: Confidence score 0.0–1.0 (default 0.8).
        summary: Optional short summary. When provided, prepended to content as
            "Summary: {summary}\\n\\n{content}" before storing as narrative.
        sync_embedding: When True, generate the embedding inline before
            returning instead of deferring to the background worker.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Created MemoryResponse dict on success, or error dict on failure.
    """
    settings = get_settings()
    ws_id = workspace_id or (settings.workspace_id if not _request_token else None)

    if not ws_id and not _request_token:
        return {
            "error": "No workspace_id provided and MEMORIES_WORKSPACE_ID is not configured.",
        }

    # workspace_id is required by store_memory; resolve it from the token if needed.
    # In HTTP mode without an explicit workspace_id, pass an empty string and let
    # the API resolve the client's default workspace from the bearer token.
    effective_ws_id: str = ws_id or ""

    narrative = f"Summary: {summary}\n\n{content}" if summary else content

    # Merge context_files into files list, deduplicating
    all_files: list[str] = list(files or [])
    if context_files:
        existing = set(all_files)
        for cf in context_files:
            if cf not in existing:
                all_files.append(cf)
                existing.add(cf)

    # Normalize paths: strip absolute prefixes to workspace-relative
    normalized_files: list[str] = []
    for fp in all_files:
        # Strip common absolute prefixes
        for prefix in ("/Users/", "/home/", "/tmp/"):
            if fp.startswith(prefix):
                # Find the project root marker and take everything after
                parts = fp.split("/")
                # Heuristic: skip until we find a known project dir pattern
                for i, part in enumerate(parts):
                    if part in ("src", "api", "mcp", "web", "packages", "lib"):
                        fp = "/".join(parts[i:])
                        break
                break
        # Remove leading slashes
        fp = fp.lstrip("/")
        if fp:
            normalized_files.append(fp)

    # Warn if no source files for code-related memory types
    _CODE_MEMORY_TYPES = {"decision", "pattern", "bug_fix", "architecture", "implementation"}
    if not normalized_files and memory_type in _CODE_MEMORY_TYPES:
        logger.warning(
            "memory_store: no source files for code-related memory type '%s' (title: '%s'). "
            "Include file paths in 'files' or 'context_files' for better code graph linking.",
            memory_type,
            title,
        )

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            result = await client.store_memory(
                workspace_id=effective_ws_id,
                title=title,
                memory_type=memory_type,
                content=narrative,
                concepts=concepts,
                tags=tags,
                files=normalized_files or None,
                importance=importance,
                confidence=confidence,
                sync_embedding=sync_embedding,
            )
        return result  # type: ignore[return-value]

    except APIError as e:
        logger.error("memory_store failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def memory_rate(
    memory_id: str,
    useful: bool,
    context: Optional[str] = None,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Rate a memory's usefulness after retrieval or use.

    Call this tool after using (or deciding not to use) a retrieved memory to
    provide explicit feedback that improves future importance scoring. Positive
    ratings increase the memory's importance; negative ratings decrease it.

    Args:
        memory_id: The memory_id string (e.g. 'mem-abc123').
        useful: True if the memory was helpful in context, False otherwise.
        context: Optional explanation of why the memory was or was not useful.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with status/memory_id/useful on success, or error dict on failure.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            await client.rate_memory(
                memory_id=memory_id,
                useful=useful,
                context=context,
            )
        return {
            "status": "recorded",
            "memory_id": memory_id,
            "useful": useful,
        }
    except Exception as e:
        logger.error("memory_rate failed for %s: %s", memory_id, e)
        return {"error": str(e), "memory_id": memory_id}


async def memory_explore(
    query: str,
    max_nodes: int = 50,
    relationship_types: Optional[list[str]] = None,
    min_edge_confidence: Optional[float] = None,
    workspace_id: Optional[str] = None,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Explore the connected neighborhood of memories about a topic.

    Use this when you need to understand HOW memories relate to each other —
    the edges matter, not just the nodes. Returns a subgraph (nodes + edges)
    centered on the most relevant memories.

    Use memory_search for flat ranked results; use memory_explore when you
    need the relationship graph.

    Args:
        query: Natural language topic query.
        max_nodes: Maximum nodes in result (default 50, max 200).
        relationship_types: Filter edges to these types only.
        min_edge_confidence: Minimum edge confidence for expansion (0.0–1.0).
        workspace_id: Target workspace (uses MEMORIES_WORKSPACE_ID if omitted).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with memories (trimmed), relationships, and metadata.
    """
    settings = get_settings()
    ws_id = workspace_id or (settings.workspace_id if not _request_token else None)

    if not ws_id and not _request_token:
        return {
            "error": "No workspace_id provided and MEMORIES_WORKSPACE_ID is not configured.",
        }

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            result = await client.explore_memories(
                query=query,
                max_nodes=max_nodes,
                relationship_types=relationship_types,
                min_edge_confidence=min_edge_confidence,
                workspace_id=ws_id,
            )

            # Trim memories for token efficiency (same pattern as memory_get_index)
            trimmed_memories = []
            for mem in result.get("memories", []):
                trimmed_memories.append({
                    "id": mem.get("id"),
                    "memory_id": mem.get("memory_id"),
                    "title": mem.get("title"),
                    "memory_type": mem.get("memory_type"),
                    "importance_score": mem.get("importance_score"),
                    "tags": mem.get("tags", []),
                    "narrative_preview": (mem.get("narrative") or "")[:200],
                })

            trimmed_relationships = []
            for rel in result.get("relationships", []):
                trimmed_relationships.append({
                    "source_memory_id": rel.get("source_memory_id"),
                    "target_memory_id": rel.get("target_memory_id"),
                    "relationship_type": rel.get("relationship_type"),
                    "confidence": rel.get("confidence"),
                })

            return {
                "memories": trimmed_memories,
                "relationships": trimmed_relationships,
                "metadata": result.get("metadata", {}),
            }
    except APIError as exc:
        logger.error("memory_explore failed: %s", exc)
        return {"error": exc.message, "status_code": exc.status_code}
