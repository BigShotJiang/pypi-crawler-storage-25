"""
Session tools for the Neuroloom MCP server.

Implements three session-lifecycle MCP tools that interact with the
Neuroloom REST API session endpoints.

Tools:
    session_start       — register a new session and retrieve initial context
    session_end         — close an active session (triggers async summary job)
    session_get_context — retrieve high-importance memories for context injection

Token passthrough (HTTP mode):
    In HTTP transport mode the ``call_tool`` handler injects ``_request_token``
    into the arguments dict. Each tool accepts this as an optional kwarg and
    passes it to ``NeuroloomAPIClient(token=token)`` so downstream API calls
    carry the per-client bearer token rather than a server-level credential.
    In stdio mode ``_request_token`` is absent and NeuroloomAPIClient falls back
    to ``settings.memories_api_token``.
"""

import logging
import os
import uuid
from typing import Any, Optional

from neuroloom_mcp.client import APIError, NeuroloomAPIClient
from neuroloom_mcp.config import get_settings

logger = logging.getLogger(__name__)


async def session_start(
    workspace_id: Optional[str] = None,
    project_path: Optional[str] = None,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Start a new Neuroloom session and retrieve initial memory context.

    Call this at the beginning of a work session to register it with the
    Neuroloom knowledge graph. On success the server returns a session ID
    and injects relevant memories from past sessions.

    A unique session_id is generated automatically (UUID4). The project
    path defaults to the current working directory.

    Args:
        workspace_id: Target workspace (uses MEMORIES_WORKSPACE_ID if omitted).
        project_path: Working directory for this session (auto-detected if omitted).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``session`` data, ``context`` memories, and a ``message`` string.
    """
    settings = get_settings()
    # In HTTP mode workspace is resolved per-client server-side; only use
    # settings.workspace_id in stdio mode.
    ws_id = workspace_id or (settings.workspace_id if not _request_token else None)

    if not ws_id and not _request_token:
        return {
            "error": "No workspace_id provided and MEMORIES_WORKSPACE_ID is not configured.",
        }

    resolved_path = project_path or os.getcwd()
    session_id = str(uuid.uuid4())

    # Best-effort: detect git branch from the project path
    branch_name = _detect_git_branch(resolved_path)
    project_name = os.path.basename(resolved_path.rstrip("/"))

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            session = await client.start_session(
                session_id=session_id,
                project_name=project_name,
                branch_name=branch_name,
                metadata={"project_path": resolved_path},
            )

            returned_session_id = session.get("session_id", session_id)

            # Fetch initial context for injection (non-critical)
            context: dict[str, Any] = {}
            try:
                context = await client.get_session_context(
                    session_id=returned_session_id,
                    max_memories=settings.max_context_memories,
                )
            except Exception as ctx_err:
                logger.warning("Failed to fetch initial session context: %s", ctx_err)

            return {
                "session": session,
                "context": context,
                "message": f"Session started: {returned_session_id}",
            }

    except APIError as e:
        logger.error("session_start failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def session_end(
    session_id: str,
    summary: Optional[str] = None,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """End an active Neuroloom session.

    Marks the session as inactive and enqueues an async batch extraction job
    that processes any observations captured during the session into structured
    memories.

    Args:
        session_id: The session ID returned by ``session_start`` (required).
        summary: Optional human-written summary of the session's outcomes.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with the updated ``session`` record and a ``message`` string.
    """
    if not session_id:
        return {
            "error": "session_id is required to end a session.",
            "hint": "Pass the session_id returned by session_start.",
        }

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            session = await client.end_session(
                session_id=session_id,
                summary=summary or "",
            )

        return {
            "session": session,
            "message": f"Session ended: {session_id}",
        }

    except APIError as e:
        logger.error("session_end failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def session_get_context(
    session_id: str,
    max_memories: Optional[int] = None,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Retrieve relevant memory context for an active session.

    Returns recent high-importance memories from the workspace, formatted
    for direct injection into the Claude Code context window. Use after
    ``session_start`` to refresh context mid-session.

    Args:
        session_id: The active session ID (required).
        max_memories: Maximum memories to return (default from MEMORIES_API config).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``session`` summary and ``context`` payload including memories.
    """
    if not session_id:
        return {
            "error": "session_id is required.",
            "hint": "Pass the session_id returned by session_start.",
        }

    settings = get_settings()
    max_mem = max_memories if max_memories is not None else settings.max_context_memories

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            context = await client.get_session_context(
                session_id=session_id,
                max_memories=max_mem,
            )

            # Non-critical: record retrieval for importance scoring
            memories = context.get("context", {}).get("memories", [])
            for mem in memories:
                memory_id = mem.get("memory_id")
                if memory_id:
                    try:
                        await client.record_memory_retrieval(memory_id)
                    except Exception:
                        pass

        return context  # type: ignore[return-value]

    except APIError as e:
        logger.error("session_get_context failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


def _detect_git_branch(path: str) -> str:
    """Best-effort detection of the current git branch for the given path.

    Returns an empty string if git is unavailable or the path is not a repo.
    """
    import subprocess

    try:
        result = subprocess.run(
            ["git", "-C", path, "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return ""
