"""
Code graph tools for the Neuroloom MCP server.

Implements six code graph MCP tools that delegate to the Neuroloom REST API
via NeuroloomAPIClient. Each tool returns a dict that the server serialises
to JSON for the MCP client.

Tools:
    code_search    — search symbols by name, file, type
    code_navigate  — 1-hop adjacency (callers + callees)
    code_callers   — incoming edges only
    code_callees   — outgoing edges only
    code_context   — recursive traversal + bridge memories
    code_sync      — parse local files and sync to server

Token passthrough (HTTP mode):
    Same pattern as memory_tools.py — each tool accepts ``_request_token``
    and passes it to ``NeuroloomAPIClient(token=token)``.
"""

import logging
from pathlib import Path
from typing import Any, Optional

from neuroloom_mcp.client import APIError, NeuroloomAPIClient

logger = logging.getLogger(__name__)


async def code_search(
    q: Optional[str] = None,
    file_pattern: Optional[str] = None,
    symbol_type: Optional[str] = None,
    limit: int = 50,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Find functions, classes, or modules by name or file pattern.

    Use this to resolve a function name to its symbol_id before calling
    code_callers, code_callees, or code_context.

    Args:
        q: Name substring filter (case-insensitive). Example: "createUser".
        file_pattern: File path glob pattern. Example: "src/services/*.ts".
        symbol_type: Filter by type: "function", "class", or "module".
        limit: Maximum results (default 50).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``symbols`` list and ``total`` count.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.search_symbols(
                q=q,
                file_pattern=file_pattern,
                symbol_type=symbol_type,
                limit=limit,
            )
    except APIError as e:
        logger.error("code_search failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def code_navigate(
    symbol_id: str,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """See what calls a function and what it calls (1-hop graph topology).

    Use for graph topology only (callers/callees). For linked memories
    alongside the call chain, use code_context instead.

    Requires a symbol_id. Use code_search first to resolve a function
    name to its symbol_id.

    Args:
        symbol_id: UUID of the code symbol.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``symbol``, ``callers``, and ``callees`` lists.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.get_symbol_neighbors(symbol_id)
    except APIError as e:
        logger.error("code_navigate failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def code_callers(
    symbol_id: str,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Get all functions/methods that call this symbol (incoming edges).

    Requires a symbol_id. Use code_search first to resolve a function
    name to its symbol_id.

    Args:
        symbol_id: UUID of the code symbol.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``symbol`` and ``callers`` list.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.get_symbol_callers(symbol_id)
    except APIError as e:
        logger.error("code_callers failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def code_callees(
    symbol_id: str,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Get all functions/methods that this symbol calls (outgoing edges).

    Requires a symbol_id. Use code_search first to resolve a function
    name to its symbol_id.

    Args:
        symbol_id: UUID of the code symbol.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``symbol`` and ``callees`` list.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.get_symbol_callees(symbol_id)
    except APIError as e:
        logger.error("code_callees failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def code_context(
    symbol_id: Optional[str] = None,
    symbol_name: Optional[str] = None,
    file_path: Optional[str] = None,
    max_depth: int = 5,
    max_results: int = 20,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Given a symbol, traverse its call chain and return all linked memories.

    Use this when you need code structure + memory context together. This is
    the most powerful code graph tool — it answers "what do we know about this
    function and everything it touches?"

    Provide either ``symbol_id`` (from code_search) or ``symbol_name`` +
    optional ``file_path`` for name-based lookup.

    When the response includes ``graph_empty: true``, no symbols are indexed.
    Run code_sync on your project files first.

    Args:
        symbol_id: UUID of the code symbol (use code_search to find it).
        symbol_name: Function/class name for name-based lookup.
        file_path: File path to disambiguate when multiple symbols share a name.
        max_depth: Maximum call chain depth (1-10, default 5).
        max_results: Maximum symbols in response (default 20).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with ``symbols`` (each with nested ``memories``), ``total_symbols``,
        ``total_memories``, ``truncated``, and ``graph_empty`` fields.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.get_code_context(
                symbol_id=symbol_id,
                symbol_name=symbol_name,
                file_path=file_path,
                max_depth=max_depth,
                max_results=max_results,
            )
    except APIError as e:
        logger.error("code_context failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def code_sync(
    paths: list[str],
    workspace_root: Optional[str] = None,
    commit_sha: Optional[str] = None,
    deleted_files: Optional[list[str]] = None,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Parse local source files and sync structural metadata to Neuroloom.

    Parses TypeScript (.ts, .tsx) and Python (.py) files using Tree-sitter,
    extracts symbols (functions, classes, modules) and edges (calls, imports),
    then sends the structural metadata to the server. No source code is
    transmitted — only names, types, line ranges, and relationships.

    Run this after significant code changes to keep the code graph current.

    Args:
        paths: List of file or directory paths to parse. Directories are
            walked recursively for supported file types.
        workspace_root: Root directory for computing relative paths. Defaults
            to the common parent of all paths.
        commit_sha: Current git HEAD SHA (for sync state tracking).
        deleted_files: Workspace-relative paths of files that were deleted.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict with sync results (symbols_upserted, edges_upserted, etc.).
    """
    try:
        from codeweaver import discover_files, parse_files
    except ImportError:
        return {
            "error": (
                "neuroloom-codeweaver is required for code_sync but not installed. "
                "Install with: pip install neuroloom-codeweaver"
            )
        }

    # Resolve paths
    resolved_paths: list[Path] = []
    for p in paths:
        path = Path(p).expanduser().resolve()
        if path.is_dir():
            resolved_paths.extend(discover_files(path))
        elif path.is_file():
            resolved_paths.append(path)
        else:
            logger.warning("code_sync: skipping non-existent path: %s", p)

    if not resolved_paths:
        return {"error": "No parseable files found in the provided paths."}

    # Determine workspace root
    if workspace_root:
        root = Path(workspace_root).expanduser().resolve()
    else:
        # Use common parent of all resolved paths
        parents = [p.parent for p in resolved_paths]
        root = parents[0]
        for parent in parents[1:]:
            while root not in parent.parents and root != parent:
                root = root.parent

    # Parse files
    try:
        payload = parse_files(resolved_paths, root)
    except Exception as exc:
        logger.exception("code_sync: parsing failed")
        return {"error": f"Parsing failed: {exc}"}

    payload["deleted_files"] = deleted_files or []
    if commit_sha:
        payload["commit_sha"] = commit_sha

    # Send to server
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.sync_code_graph(
                symbols=payload["symbols"],
                edges=payload["edges"],
                deleted_files=payload["deleted_files"],
                commit_sha=payload.get("commit_sha"),
            )
    except APIError as e:
        logger.error("code_sync API call failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}
