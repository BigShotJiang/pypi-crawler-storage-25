"""
Document ingestion and SDLC tools for the Neuroloom MCP server.

Implements ten MCP tools that delegate to the Neuroloom REST API via
NeuroloomAPIClient:

    document_ingest                       — ingest a single document into the workspace
    document_ingest_batch                 — batch ingest up to 50 documents
    document_ingest_file                  — read a local file and ingest it (stdio only)
    document_ingest_files_batch           — read multiple local files and batch ingest (stdio only)
    document_ingest_batch_from_file       — read a JSON file and batch ingest documents (stdio only)
    document_ingest_batch_get_upload_url  — get a presigned upload URL for document batch ingestion (HTTP only)
    sdlc_get_version                      — retrieve the latest cc-sdlc version from the proxy
    sdlc_seed                             — seed a workspace with SDLC knowledge entries
    sdlc_seed_from_file                   — read a JSON file and seed workspace entries (stdio only)
    sdlc_seed_get_upload_url              — get a presigned upload URL for bulk seeding (HTTP only)

Token passthrough (HTTP mode):
    In HTTP transport mode the ``call_tool`` handler injects ``_request_token``
    into the arguments dict. Each tool accepts this as an optional kwarg and
    passes it to ``NeuroloomAPIClient(token=token)`` so downstream API calls
    carry the per-client bearer token rather than a server-level credential.
    In stdio mode ``_request_token`` is absent and NeuroloomAPIClient falls back
    to ``settings.memories_api_token``.

File-path tools (stdio only):
    ``document_ingest_file``, ``document_ingest_files_batch``, and
    ``sdlc_seed_from_file`` read files directly from the local filesystem
    and forward their content to the existing API endpoints, bypassing MCP
    transport token limits. These tools are disabled in HTTP transport mode
    because the server process does not have access to client-side filesystems.
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Optional

from neuroloom_mcp.client import APIError, NeuroloomAPIClient
from neuroloom_mcp.config import get_settings

logger = logging.getLogger(__name__)


async def document_ingest(
    title: str,
    content: str,
    source_type: str,
    source_path: Optional[str] = None,
    tags: Optional[list[str]] = None,
    format: Optional[str] = None,
    memory_type: Optional[str] = None,
    knowledge_id: Optional[str] = None,
    version: Optional[str] = None,
    importance: Optional[float] = None,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Ingest a single document into the workspace knowledge graph.

    The server computes ``content_hash`` — do not pass it as a parameter.
    If a document with the same hash already exists it will be deduplicated
    server-side rather than stored again.

    Args:
        title: Document title (required).
        content: Full document text content (required).
        source_type: Origin category, e.g. ``"file"``, ``"url"``, ``"clipboard"``
            (required).
        source_path: Optional path or URL the document was sourced from.
        tags: Optional list of freeform tags for filtering.
        format: Optional document format hint, e.g. ``"markdown"``, ``"rst"``,
            ``"text"``.
        memory_type: Optional memory type to associate with the ingested document.
        knowledge_id: Optional knowledge base ID to associate the document with.
        version: Optional version string (e.g. a semver or git SHA).
        importance: Optional importance score in [0.0, 1.0].
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        DocumentResponse dict on success, or error dict on failure.
    """
    data: dict[str, Any] = {
        "title": title,
        "content": content,
        "source_type": source_type,
    }
    if source_path is not None:
        data["source_path"] = source_path
    if tags is not None:
        data["tags"] = tags
    if format is not None:
        data["format"] = format
    if memory_type is not None:
        data["memory_type"] = memory_type
    if knowledge_id is not None:
        data["knowledge_id"] = knowledge_id
    if version is not None:
        data["version"] = version
    if importance is not None:
        data["importance"] = importance

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.ingest_document(data)
    except APIError as e:
        logger.error("document_ingest failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def document_ingest_batch(
    documents: list[dict[str, Any]],
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Batch ingest up to 50 documents into the workspace knowledge graph.

    Each document in the list must contain at minimum ``title``, ``content``,
    and ``source_type``. All other fields from ``document_ingest`` are supported
    per-document.

    Args:
        documents: List of document dicts (max 50). Each dict requires
            ``title``, ``content``, and ``source_type``.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        BatchIngestResponse dict with counts and any per-document errors,
        or error dict on failure.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.ingest_documents_batch(documents)
    except APIError as e:
        logger.error("document_ingest_batch failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def document_ingest_file(
    path: str,
    title: Optional[str] = None,
    source_type: str = "file",
    source_path: Optional[str] = None,
    tags: Optional[list[str]] = None,
    format: Optional[str] = None,
    memory_type: Optional[str] = None,
    knowledge_id: Optional[str] = None,
    version: Optional[str] = None,
    importance: Optional[float] = None,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Read a local file and ingest it into the workspace knowledge graph.

    Reads the file at ``path`` from the local filesystem and forwards its
    content to the document ingestion API. This tool bypasses MCP transport
    token limits by reading the file server-side rather than passing content
    through the MCP protocol.

    This tool is only available in stdio transport mode. In HTTP mode the
    server process does not have access to client-side filesystems.

    Args:
        path: Absolute or relative path to the file to ingest.
        title: Document title. Defaults to the file stem (filename without
            extension) if not provided.
        source_type: Origin category. Defaults to ``"file"``.
        source_path: Path or URL to record as the document source. Defaults to
            the resolved absolute path of ``path``.
        tags: Optional list of freeform tags for filtering.
        format: Optional document format hint, e.g. ``"markdown"``, ``"rst"``,
            ``"text"``.
        memory_type: Optional memory type to associate with the ingested document.
        knowledge_id: Optional knowledge base ID to associate the document with.
        version: Optional version string (e.g. a semver or git SHA).
        importance: Optional importance score in [0.0, 1.0].
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        DocumentResponse dict on success, or error dict on failure.
    """
    # Stdio guard — file-path tools are meaningless in HTTP mode because the
    # server process cannot access the client's filesystem.
    if get_settings().mcp_transport == "http":
        return {
            "error": "File-path tools are only available in stdio transport mode",
            "status_code": 403,
        }

    # Default title to the file stem before we resolve the path, so we use
    # the name the caller supplied rather than a fully-qualified basename.
    if title is None:
        title = Path(path).stem

    # Resolve once; reuse for both validation and source_path default.
    path_obj = Path(path).resolve()

    if source_path is None:
        source_path = str(path_obj)

    # Path validation — sync calls are acceptable here because this tool is
    # stdio-only and therefore runs in the local process.
    if not path_obj.exists():
        return {
            "error": f"File not found: {path}",
            "path": path,
            "status_code": 422,
        }
    if not path_obj.is_file():
        return {
            "error": f"Path is not a regular file: {path}",
            "path": path,
            "status_code": 422,
        }

    # Read file content off the event loop to avoid blocking.
    try:
        content = await asyncio.to_thread(path_obj.read_text, encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        logger.error("document_ingest_file read error for %s: %s", path, exc)
        return {
            "error": str(exc),
            "path": path,
            "status_code": 422,
        }

    data: dict[str, Any] = {
        "title": title,
        "content": content,
        "source_type": source_type,
        "source_path": source_path,
    }
    if tags is not None:
        data["tags"] = tags
    if format is not None:
        data["format"] = format
    if memory_type is not None:
        data["memory_type"] = memory_type
    if knowledge_id is not None:
        data["knowledge_id"] = knowledge_id
    if version is not None:
        data["version"] = version
    if importance is not None:
        data["importance"] = importance

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.ingest_document(data)
    except APIError as e:
        logger.error("document_ingest_file failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def document_ingest_files_batch(
    documents: list[dict[str, Any]],
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Read multiple local files and batch ingest them into the workspace.

    Each entry in ``documents`` must contain a ``path`` key pointing to a local
    file. The tool reads all files concurrently, then forwards their content to
    the batch ingestion API in a single request.

    This tool is only available in stdio transport mode. In HTTP mode the
    server process does not have access to client-side filesystems.

    Per-document optional fields (same as ``document_ingest``):
        - ``title``: defaults to the file stem if absent.
        - ``source_type``: defaults to ``"file"`` if absent.
        - ``source_path``: defaults to the resolved absolute path if absent.
        - ``tags``, ``format``, ``memory_type``, ``knowledge_id``, ``version``,
          ``importance``: forwarded as-is when present.

    Args:
        documents: List of dicts (max 50). Each dict must contain ``path``.
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        BatchIngestResponse dict on success. If some files failed validation or
        reading, the response includes a ``"file_errors"`` key with per-file
        error details alongside the API response for the files that succeeded.
        If all files fail, returns an error dict with ``"file_errors"`` and no
        API call is made.
    """
    # Stdio guard.
    if get_settings().mcp_transport == "http":
        return {
            "error": "File-path tools are only available in stdio transport mode",
            "status_code": 403,
        }

    # Batch count guard.
    if len(documents) > 50:
        return {
            "error": "Batch size exceeds maximum of 50 documents",
            "status_code": 422,
        }

    # --- Phase 1: validate all paths before reading any files ---------------

    errors: list[dict[str, Any]] = []
    valid_paths: list[Path] = []
    valid_docs: list[dict[str, Any]] = []

    for doc in documents:
        raw_path = doc.get("path")
        if not raw_path:
            errors.append(
                {
                    "error": "Document entry is missing required 'path' key",
                    "path": None,
                    "status_code": 422,
                }
            )
            continue

        path_obj = Path(str(raw_path)).resolve()

        if not path_obj.exists():
            errors.append(
                {
                    "error": f"File not found: {raw_path}",
                    "path": str(raw_path),
                    "status_code": 422,
                }
            )
            continue

        if not path_obj.is_file():
            errors.append(
                {
                    "error": f"Path is not a regular file: {raw_path}",
                    "path": str(raw_path),
                    "status_code": 422,
                }
            )
            continue

        valid_paths.append(path_obj)
        valid_docs.append(doc)

    # --- Phase 2: cumulative size guard -------------------------------------

    if valid_paths:
        total_bytes = sum(p.stat().st_size for p in valid_paths)
        max_bytes = 50 * 1024 * 1024  # 50 MB
        if total_bytes > max_bytes:
            return {
                "error": "Total file size exceeds 50 MB limit",
                "total_bytes": total_bytes,
                "status_code": 422,
            }

    # --- Phase 3: concurrent reads ------------------------------------------

    if not valid_paths:
        return {
            "error": "All files failed validation or reading",
            "file_errors": errors,
            "status_code": 422,
        }

    read_results: list[Any] = list(
        await asyncio.gather(
            *[asyncio.to_thread(p.read_text, encoding="utf-8") for p in valid_paths],
            return_exceptions=True,
        )
    )

    # --- Phase 4: build batch payload from successful reads -----------------

    batch_docs: list[dict[str, Any]] = []

    for i, result in enumerate(read_results):
        doc = valid_docs[i]
        raw_path = str(doc["path"])
        path_obj = valid_paths[i]

        if isinstance(result, BaseException):
            if isinstance(result, (OSError, UnicodeDecodeError)):
                errors.append(
                    {
                        "error": str(result),
                        "path": raw_path,
                        "status_code": 422,
                    }
                )
            else:
                errors.append(
                    {
                        "error": f"Unexpected error reading file: {result}",
                        "path": raw_path,
                        "status_code": 500,
                    }
                )
            continue

        # result is a str — build the document dict for the API.
        title: str = str(doc["title"]) if "title" in doc else Path(raw_path).stem
        source_type: str = str(doc.get("source_type", "file"))
        source_path_val: str = str(doc["source_path"]) if "source_path" in doc else str(path_obj)

        api_doc: dict[str, Any] = {
            "title": title,
            "content": result,
            "source_type": source_type,
            "source_path": source_path_val,
        }

        for optional_key in (
            "tags",
            "format",
            "memory_type",
            "knowledge_id",
            "version",
            "importance",
        ):
            if optional_key in doc and doc[optional_key] is not None:
                api_doc[optional_key] = doc[optional_key]

        batch_docs.append(api_doc)

    # --- Phase 5: delegate to API -------------------------------------------

    if not batch_docs:
        return {
            "error": "All files failed validation or reading",
            "file_errors": errors,
            "status_code": 422,
        }

    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            api_response: dict[str, Any] = await client.ingest_documents_batch(batch_docs)
    except APIError as e:
        logger.error("document_ingest_files_batch API call failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}

    if errors:
        api_response["file_errors"] = errors

    return api_response


async def sdlc_seed(
    entries: list[dict[str, Any]],
    version: str,
    skip_deprecation: bool = False,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Seed a workspace with SDLC knowledge entries.

    Calls POST /sdlc/seed, which triggers server-side sentinel creation,
    knowledge_id-based deduplication, and structured MemoryEntry processing.
    Use this instead of document_ingest_batch for SDLC knowledge ingestion —
    it handles the sentinel lifecycle, prevents duplicates, and processes
    entries as structured MemoryEntry objects rather than generic documents.

    Args:
        entries: List of entry dicts. Each must contain title, content, tags,
            and knowledge_id at minimum. See SeedMemoryEntryRequest for all
            supported fields.
        version: Seed version string, e.g. a cc-sdlc release tag.
        skip_deprecation: When True, skip the deprecation step that tags
            entries missing from this batch as sdlc:deprecated. Use this
            when sending entries in multiple chunks — only the final chunk
            should set this to False (the default).
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        SeedResult dict with created/updated/unchanged/deprecated counts,
        or error dict on failure.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.seed(entries=entries, version=version, skip_deprecation=skip_deprecation)
    except APIError as e:
        logger.error("sdlc_seed failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def sdlc_seed_from_file(
    path: str,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Read a JSON file from disk and seed the workspace with its entries.

    Reads a JSON file at ``path`` from the local filesystem and delegates to
    POST /sdlc/seed, bypassing MCP transport size limits that would otherwise
    prevent large seed payloads (e.g. 236 entries / 518 KB) from being passed
    inline via ``sdlc_seed``.

    The file must contain a JSON object with at minimum:
      - ``"entries"``: a list of seed entry dicts (max 500)
      - ``"version"``: a non-empty string (e.g. a cc-sdlc release tag)

    It may optionally contain:
      - ``"skip_deprecation"``: boolean (default false). Set to true for
        intermediate chunks in a multi-file seed — only the final chunk
        should leave this false so stale entries are deprecated.

    This tool is only available in stdio transport mode. In HTTP mode, use
    ``sdlc_seed_get_upload_url`` instead.

    Args:
        path: Absolute or relative path to a UTF-8 encoded JSON file containing
            the seed payload (``{"version": "...", "entries": [...]}`).
        _request_token: Per-request bearer token injected by call_tool in HTTP
            mode. Passed through to NeuroloomAPIClient for downstream auth.

    Returns:
        SeedResult dict with created/updated/unchanged/deprecated counts on
        success, or an error dict with ``"error"`` and ``"status_code"`` on
        failure. Path-related errors also include ``"path"``.
    """
    # 1. Stdio guard — file-path tools are meaningless in HTTP mode.
    if get_settings().mcp_transport == "http":
        return {
            "error": (
                "File-path tools are only available in stdio transport mode. "
                "In HTTP mode, use sdlc_seed_get_upload_url to seed directly via the REST API."
            ),
            "status_code": 403,
        }

    # 2. Path validation.
    path_obj = Path(path).resolve()
    if not path_obj.exists():
        return {"error": f"File not found: {path}", "path": path, "status_code": 422}
    if not path_obj.is_file():
        return {"error": f"Path is not a regular file: {path}", "path": path, "status_code": 422}

    # 3. Size guard — check before reading content.
    max_bytes = 100 * 1024 * 1024  # 100 MB
    if path_obj.stat().st_size > max_bytes:
        return {"error": "File exceeds 100 MB size limit", "path": path, "status_code": 422}

    # 4. File read — off the event loop to avoid blocking.
    try:
        content = await asyncio.to_thread(path_obj.read_text, encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        logger.error("sdlc_seed_from_file read error for %s: %s", path, exc)
        return {"error": f"Failed to read file: {path}", "path": path, "status_code": 422}

    # 5. JSON parse.
    try:
        data: Any = json.loads(content)
    except json.JSONDecodeError as exc:
        return {"error": f"Invalid JSON: {exc}", "path": path, "status_code": 422}

    # 6. Dict-type guard.
    if not isinstance(data, dict):
        return {
            "error": "File must contain a JSON object at the top level",
            "path": path,
            "status_code": 422,
        }

    # 7. Structure validation.
    if not isinstance(data.get("entries"), list):
        return {"error": "File must contain an 'entries' key with a list value", "path": path, "status_code": 422}
    if not isinstance(data.get("version"), str):
        return {"error": "File must contain a 'version' key with a non-empty string value", "path": path, "status_code": 422}
    if not data["version"]:
        return {"error": "File must contain a non-empty 'version' string", "path": path, "status_code": 422}

    # 8. Entry-count ceiling.
    entries: list[Any] = data["entries"]
    if len(entries) > 10_000:
        return {
            "error": f"File contains {len(entries)} entries, which exceeds the 10,000-entry limit",
            "path": path,
            "status_code": 422,
        }

    # 9. Optional skip_deprecation flag — supports multi-chunk seeding workflows.
    skip_deprecation: bool = bool(data.get("skip_deprecation", False))

    # 10. Delegate to the API.
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.seed(entries=entries, version=data["version"], skip_deprecation=skip_deprecation)
    except APIError as e:
        logger.error("sdlc_seed_from_file failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


_SHELL_METACHAR_SET = frozenset('"$`;&|\\' + "\n")


async def sdlc_seed_get_upload_url(
    path: str,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Get a presigned upload URL for bulk seeding (HTTP transport mode only).

    Requests a short-lived upload URL from POST /sdlc/upload-url and returns
    a ready-to-run ``curl`` command that the calling agent should execute via
    Bash as a separate step.  This tool does **not** execute the upload — it
    only prepares and returns the command.

    This tool is only available in HTTP transport mode.  In stdio mode, use
    ``sdlc_seed_from_file`` instead.

    The seed file at ``path`` must be a JSON object with:
      - ``"entries"``: list of seed entry dicts
      - ``"version"``: non-empty string (e.g. a cc-sdlc release tag)
      - ``"skip_deprecation"`` (optional): boolean, default false

    Note: ``version`` and ``skip_deprecation`` are read from the seed file
    itself, not passed as tool parameters.

    Args:
        path: Absolute path to the local JSON seed file to upload.  Must not
            contain shell metacharacters.
        _request_token: Per-request bearer token injected by call_tool in HTTP
            mode. Passed through to NeuroloomAPIClient for downstream auth.

    Returns:
        Dict with ``upload_url``, ``expires_in_seconds``, ``curl_command``,
        and ``instructions`` on success, or an error dict on failure.
    """
    # 1. Path validation — reject empty, leading-whitespace, or shell metacharacters.
    if not path or path != path.lstrip() or any(c in _SHELL_METACHAR_SET for c in path):
        return {
            "error": "Invalid path: path contains shell metacharacters or is malformed.",
            "status_code": 422,
        }

    # 2. HTTP-mode only guard.
    if get_settings().mcp_transport != "http":
        return {
            "error": (
                "sdlc_seed_get_upload_url is only available in HTTP transport mode. "
                "In stdio mode, use sdlc_seed_from_file instead."
            ),
            "status_code": 403,
        }

    # 3. Request the upload URL from the API.
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            response = await client.request_upload_url()
    except APIError as e:
        logger.error("sdlc_seed_get_upload_url API call failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}

    # 4. Build the curl command.
    upload_url = response["upload_url"]
    curl_command = (
        f'curl -s -X POST "{upload_url}" '
        f'-H "Content-Type: application/json" '
        f'-d @"{path}"'
    )

    # 5. Return everything the agent needs to proceed.
    return {
        "upload_url": upload_url,
        "expires_in_seconds": response["expires_in_seconds"],
        "curl_command": curl_command,
        "instructions": (
            "Run the curl_command via Bash to upload the seed file. "
            "The URL expires in 5 minutes. "
            f"Seed file: {path}. "
            "The curl response body is JSON with keys: created, updated, unchanged, deprecated. "
            "If curl exits non-zero or the response contains a 'detail' or 'error' key, the upload failed."
        ),
    }


async def document_ingest_batch_from_file(
    path: str,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Read a JSON file from disk and batch ingest its documents into the workspace.

    Reads a JSON file at ``path`` from the local filesystem and delegates to
    POST /documents/batch, bypassing MCP transport size limits that would
    otherwise prevent large document batches from being passed inline via
    ``document_ingest_batch``.

    The file must contain a **flat JSON array** of document objects (not a
    wrapped object like ``{"entries": [...]}``) — for example::

        [
          {"title": "...", "content": "...", "source_type": "file"},
          ...
        ]

    Each document must include ``title``, ``content``, and ``source_type`` at
    minimum. All optional fields supported by ``document_ingest`` are allowed
    per document. Maximum 50 documents per file.

    This tool is only available in stdio transport mode.  In HTTP mode, the
    server process does not have access to client-side filesystems — use
    ``document_ingest_batch_get_upload_url`` instead.

    Args:
        path: Absolute path to a UTF-8 encoded JSON file containing a flat
            array of document objects.
        _request_token: Per-request bearer token injected by call_tool in HTTP
            mode. Passed through to NeuroloomAPIClient for downstream auth.

    Returns:
        BatchIngestResult dict with summary and per-document results on
        success, or an error dict with ``"error"`` and ``"status_code"`` on
        failure.  Path-related errors also include ``"path"``.
    """
    # 1. Stdio guard — file-path tools are meaningless in HTTP mode.
    if get_settings().mcp_transport == "http":
        return {
            "error": (
                "File-path tools are only available in stdio transport mode. "
                "In HTTP mode, use document_ingest_batch_get_upload_url to ingest documents "
                "directly via the REST API."
            ),
            "status_code": 403,
        }

    # 2. Path validation.
    path_obj = Path(path).resolve()
    if not path_obj.exists():
        return {"error": f"File not found: {path}", "path": path, "status_code": 422}
    if not path_obj.is_file():
        return {"error": f"Path is not a regular file: {path}", "path": path, "status_code": 422}

    # 3. Size guard — check before reading content.
    max_bytes = 10 * 1024 * 1024  # 10 MiB
    if path_obj.stat().st_size > max_bytes:
        return {"error": "File exceeds 10 MiB size limit", "path": path, "status_code": 422}

    # 4. File read — off the event loop to avoid blocking.
    try:
        content = await asyncio.to_thread(path_obj.read_text, encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        logger.error("document_ingest_batch_from_file read error for %s: %s", path, exc)
        return {"error": f"Failed to read file: {path}", "path": path, "status_code": 422}

    # 5. JSON parse.
    try:
        data: Any = json.loads(content)
    except json.JSONDecodeError as exc:
        return {"error": f"Invalid JSON: {exc}", "path": path, "status_code": 422}

    # 6. Top-level must be a list (not dict).
    if not isinstance(data, list):
        return {
            "error": "File must contain a flat JSON array at the top level (not a dict)",
            "path": path,
            "status_code": 422,
        }

    # 7. Empty check.
    if len(data) == 0:
        return {
            "error": "File contains an empty array — at least 1 document is required",
            "path": path,
            "status_code": 422,
        }

    # 8. Max 50 items.
    if len(data) > 50:
        return {
            "error": f"File contains {len(data)} documents, which exceeds the 50-document limit",
            "path": path,
            "status_code": 422,
        }

    # 9. Delegate to the API — client wraps into {"documents": [...]} internally.
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.ingest_documents_batch(data)
    except APIError as e:
        logger.error("document_ingest_batch_from_file failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}


async def document_ingest_batch_get_upload_url(
    path: str,
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Get a presigned upload URL for batch document ingestion (HTTP transport mode only).

    Requests a short-lived upload URL from POST /documents/upload-url and
    returns a ready-to-run ``curl`` command that the calling agent should
    execute via Bash as a separate step.  This tool does **not** execute the
    upload — it only prepares and returns the command.

    This tool is only available in HTTP transport mode.  In stdio mode, use
    ``document_ingest_batch_from_file`` instead.

    The file at ``path`` must contain a JSON object with a ``"documents"`` key
    wrapping an array of 1–50 document objects — for example::

        {"documents": [
          {"title": "...", "content": "...", "source_type": "file"},
          ...
        ]}

    This differs from ``document_ingest_batch_from_file`` (which accepts a flat
    array) because curl sends the file contents directly to the API endpoint,
    which expects a ``DocumentIngestBatchRequest`` body.

    Note: this tool does not read or validate the file — it only fetches the
    upload URL and returns the curl command.

    Args:
        path: Absolute path to the local JSON document batch file to upload.
            Must not contain shell metacharacters.
        _request_token: Per-request bearer token injected by call_tool in HTTP
            mode. Passed through to NeuroloomAPIClient for downstream auth.

    Returns:
        Dict with ``upload_url``, ``expires_in_seconds``, ``curl_command``,
        and ``instructions`` on success, or an error dict on failure.
    """
    # 1. Path validation — reject empty, leading-whitespace, or shell metacharacters.
    if not path or path != path.lstrip() or any(c in _SHELL_METACHAR_SET for c in path):
        return {
            "error": "Invalid path: path contains shell metacharacters or is malformed.",
            "status_code": 422,
        }

    # 2. HTTP-mode only guard.
    if get_settings().mcp_transport != "http":
        return {
            "error": (
                "document_ingest_batch_get_upload_url is only available in HTTP transport mode. "
                "In stdio mode, use document_ingest_batch_from_file instead."
            ),
            "status_code": 403,
        }

    # 3. Request the upload URL from the API.
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            response = await client.request_document_upload_url()
    except APIError as e:
        logger.error("document_ingest_batch_get_upload_url API call failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}

    # 4. Build the curl command.
    upload_url = response["upload_url"]
    curl_command = (
        f'curl -s -X POST "{upload_url}" '
        f'-H "Content-Type: application/json" '
        f'-d @"{path}"'
    )

    # 5. Return everything the agent needs to proceed.
    return {
        "upload_url": upload_url,
        "expires_in_seconds": response["expires_in_seconds"],
        "curl_command": curl_command,
        "instructions": (
            "Run the curl_command via Bash to upload the document batch file. "
            "The URL expires in 5 minutes. "
            f"Document batch file: {path}. "
            'The file must contain a JSON object: {"documents": [...]} with 1-50 document objects. '
            "This differs from document_ingest_batch_from_file which accepts a flat array — "
            "the HTTP upload sends the file directly to the API which expects the wrapped format. "
            "The curl response body is JSON with keys: summary and results. "
            "If curl exits non-zero or the response contains a 'detail' or 'error' key, the upload failed."
        ),
    }


async def sdlc_get_version(
    _request_token: Optional[str] = None,
) -> dict[str, Any]:
    """Get the latest cc-sdlc version from the Neuroloom version proxy.

    Queries the API's SDLC version endpoint, which proxies the upstream
    cc-sdlc release version so MCP clients can check for updates without
    direct GitHub access.

    Args:
        _request_token: Per-request bearer token injected by call_tool in HTTP mode.

    Returns:
        Dict containing the latest version string, or error dict on failure.
    """
    try:
        async with NeuroloomAPIClient(token=_request_token) as client:
            return await client.get_cc_sdlc_version()
    except APIError as e:
        logger.error("sdlc_get_version failed: %s", e)
        return {"error": e.message, "status_code": e.status_code}
