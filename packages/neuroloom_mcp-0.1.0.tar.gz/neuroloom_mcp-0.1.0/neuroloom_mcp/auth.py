"""
API key authentication middleware for the Neuroloom MCP HTTP server.

``APIKeyAuthMiddleware`` gates all incoming HTTP requests. It:

1. Bypasses all non-``/mcp`` paths — only the MCP protocol endpoint
   requires authentication. Discovery probes (``/.well-known/…``), health
   checks (``/health``), and unregistered paths all pass through to
   Starlette's router without auth processing.
2. Parses ``Authorization: Bearer <key>`` from the request headers.
3. Validates the token against the Neuroloom API by forwarding it as
   ``Authorization: Token <key>`` to ``GET /api/v1/workspaces/``.
4. Caches successful validations (SHA-256 hash → True) in a bounded TTL
   cache to avoid redundant upstream calls on every request.
5. On success, stores the raw token in both the ASGI scope state and the
   per-request ``_request_api_token`` ContextVar so tool handlers can use it.
6. Returns a structured JSON error body on 401 and 503 failures with the
   appropriate security headers.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from typing import Optional

import httpx
from cachetools import TTLCache  # type: ignore[import-untyped]
from starlette.types import ASGIApp, Receive, Scope, Send

from neuroloom_mcp.config import _request_api_token, get_settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Error response bodies
# ---------------------------------------------------------------------------

_401_BODY: dict[str, str] = {
    "error": "authentication_failed",
    "message": "Invalid API key. Get one at https://app.neuroloom.dev/settings/api-keys.",
}

_503_BODY: dict[str, str] = {
    "error": "upstream_unavailable",
    "message": "Authentication service temporarily unavailable. Retry your request. If this persists, check https://mcp.neuroloom.dev/health.",
}

# Security headers attached to all 401/503 responses.
_ERROR_HEADERS: dict[str, str] = {
    # Rate limiting deferred: Railway's built-in DDoS mitigation handles
    # brute-force key enumeration. Revisit if abuse patterns are observed
    # post-launch.
    "WWW-Authenticate": 'Bearer realm="neuroloom-mcp"',
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
}


# ---------------------------------------------------------------------------
# ASGI JSON response helper
# ---------------------------------------------------------------------------


async def _send_json_response(
    send: Send,
    status_code: int,
    body: dict[str, str],
    headers: Optional[dict[str, str]] = None,
) -> None:
    """Send a JSON HTTP response at the raw ASGI level.

    Middleware operates below the Starlette request/response layer, so we
    must construct the ASGI events manually instead of using ``JSONResponse``.
    """
    payload = json.dumps(body).encode()
    response_headers: list[tuple[bytes, bytes]] = [
        (b"content-type", b"application/json"),
        (b"content-length", str(len(payload)).encode()),
    ]
    if headers:
        for key, value in headers.items():
            response_headers.append((key.encode(), value.encode()))

    await send(
        {
            "type": "http.response.start",
            "status": status_code,
            "headers": response_headers,
        }
    )
    await send({"type": "http.response.body", "body": payload})


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------


class APIKeyAuthMiddleware:
    """Starlette-compatible ASGI middleware that authenticates Bearer tokens.

    Token validation is performed by forwarding the token to the Neuroloom
    API (``GET /api/v1/workspaces/``) as ``Authorization: Token <key>``.
    A 200 response confirms validity; 401/403 from upstream means the key
    is invalid or revoked; any other result (5xx, timeout, network error)
    is treated as a temporary upstream failure and returns 503 to the client.

    Successful validations are cached by SHA-256 hash of the raw token.
    Failed attempts are never cached so that key revocation takes effect
    within one request cycle.

    Multi-worker isolation: asyncio.Lock is per-process. Each uvicorn worker
    has its own TTLCache and lock. A revoked token may remain valid in each
    worker's cache for up to 60s after revocation. The 60s TTL is the
    accepted window. No cross-worker invalidation is performed.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        # Bounded TTL cache: prevents OOM from unbounded token accumulation.
        # maxsize=10_000 caps memory at ~10k concurrent distinct token hashes.
        # ttl=60 (seconds) caps the revocation detection window.
        self._cache: TTLCache[str, bool] = TTLCache(maxsize=10_000, ttl=60)
        # asyncio.Lock guards reads and writes to the cache. It is never held
        # across the upstream HTTP I/O call — see _validate_token() for the
        # read-release-validate-reacquire-write pattern.
        self._cache_lock = asyncio.Lock()

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Process an incoming ASGI request.

        Only /mcp requires authentication. All other paths are passed
        through to Starlette's router without auth processing. This is intentional:

        - /.well-known/oauth-protected-resource — OAuth discovery probe (RFC 9728).
          Must return 200 JSON, not 401. A 401 here triggers the MCP client OAuth
          flow, which cannot succeed because we have no authorization server.
        - /health — Railway health check and uptime monitoring. Must be reachable
          without credentials so Railway can verify the service is running.
        - All other unregistered paths — JSON 404 from the exception handler.
          Must not return 401 + WWW-Authenticate, which would trigger OAuth flow
          in clients that probe arbitrary paths during discovery.

        By only gating /mcp, discovery probes and health checks pass through to
        routing cleanly. Starlette's router (or the 404 handler) handles them.
        """
        # Only authenticate the MCP protocol endpoint. Everything else
        # (health checks, discovery probes, unregistered paths) passes
        # through to routing — Starlette returns 404 for unmatched routes.
        # Exact match — uvicorn normalizes the path (strips double slashes,
        # decodes percent-encoding) before setting scope["path"]. If deployed
        # behind a proxy that rewrites paths, re-verify this assumption.
        if scope["type"] != "http" or scope["path"] != "/mcp":
            await self.app(scope, receive, send)
            return

        # --- Parse Authorization header -----------------------------------
        raw_headers: list[tuple[bytes, bytes]] = scope.get("headers", [])
        headers_map = dict(raw_headers)
        auth_bytes = headers_map.get(b"authorization", b"")
        # Decode using latin-1 (the HTTP/1.1 header encoding) rather than
        # utf-8 to avoid decode errors on malformed header bytes.
        auth_header = auth_bytes.decode("latin-1")

        parts = auth_header.split(" ", 1)
        if len(parts) != 2 or parts[0].lower() != "bearer":  # noqa: S105
            logger.warning("Rejected request: missing or malformed Authorization header")
            await _send_json_response(send, 401, _401_BODY, _ERROR_HEADERS)
            return

        token = parts[1].strip()
        if not token:
            logger.warning("Rejected request: empty Bearer token")
            await _send_json_response(send, 401, _401_BODY, _ERROR_HEADERS)
            return

        # --- Validate token -----------------------------------------------
        valid, upstream_error = await self._validate_token(token)

        if upstream_error:
            await _send_json_response(send, 503, _503_BODY, _ERROR_HEADERS)
            return

        if not valid:
            await _send_json_response(send, 401, _401_BODY, _ERROR_HEADERS)
            return

        # --- Token accepted: store for downstream tool handlers -----------
        # Starlette Request.state reads from scope["state"]; initialise if absent.
        if "state" not in scope:
            scope["state"] = {}
        scope["state"]["api_token"] = token

        # ContextVar path: tool handlers retrieve the token via get_request_token()
        # without coupling to the ASGI scope or Starlette's Request object.
        reset_token = _request_api_token.set(token)
        try:
            await self.app(scope, receive, send)
        finally:
            _request_api_token.reset(reset_token)

    async def _validate_token(self, token: str) -> tuple[bool, bool]:
        """Validate ``token`` against the upstream Neuroloom API.

        Returns ``(valid, upstream_error)``:
        - ``(True, False)``  — token is valid (cache hit or confirmed by upstream).
        - ``(False, False)`` — token is invalid (upstream returned 401/403).
        - ``(False, True)``  — upstream could not be reached; caller should 503.

        Cache read/write lock discipline (critical for correct async behaviour):
        - Acquire lock → read cache → release lock.
        - Perform upstream HTTP call WITHOUT holding the lock.
        - Acquire lock → write result → release lock.
        Holding the lock across the I/O call would serialise all concurrent
        requests through a single lock, eliminating concurrency.
        """
        token_hash = hashlib.sha256(token.encode()).hexdigest()

        # --- Cache read (lock held for read only) -------------------------
        async with self._cache_lock:
            cached = self._cache.get(token_hash)

        if cached is True:
            logger.debug("Auth cache hit for token hash %s", token_hash[:8])
            return True, False

        # --- Upstream validation (lock NOT held) --------------------------
        settings = get_settings()
        api_url = settings.memories_api_url.rstrip("/")
        validation_url = f"{api_url}/api/v1/workspaces/"

        try:
            async with httpx.AsyncClient(timeout=3.0) as client:
                response = await client.get(
                    validation_url,
                    headers={"Authorization": f"Token {token}"},
                )
        except (httpx.TimeoutException, httpx.ConnectError, httpx.RequestError):
            logger.error(
                "Upstream auth validation failed (network/timeout) for token hash %s",
                token_hash[:8],
            )
            return False, True
        except Exception:
            logger.exception(
                "Unexpected error during auth validation for token hash %s",
                token_hash[:8],
            )
            return False, True

        if response.status_code == 200:
            # --- Cache write (lock held for write only) -------------------
            async with self._cache_lock:
                self._cache[token_hash] = True
            logger.info("Auth success for token hash %s", token_hash[:8])
            return True, False

        if response.status_code in (401, 403):
            # Do NOT cache failed validations — revoked keys must fail immediately
            # on their next attempt without waiting for a cache TTL to expire.
            logger.warning(
                "Auth failed for token hash %s (upstream %s)",
                token_hash[:8],
                response.status_code,
            )
            return False, False

        # Any other upstream status (5xx, unexpected 4xx, etc.) is treated as
        # a transient upstream failure rather than an invalid token.
        logger.error(
            "Upstream auth returned unexpected status %s for token hash %s",
            response.status_code,
            token_hash[:8],
        )
        return False, True
