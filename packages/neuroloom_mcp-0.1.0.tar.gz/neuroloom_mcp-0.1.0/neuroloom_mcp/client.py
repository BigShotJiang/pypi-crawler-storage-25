"""
HTTP client for the Neuroloom API.

Async wrapper around httpx.AsyncClient with auth header injection,
timeout configuration, and structured error handling.
"""

import logging
from typing import Any, Optional

import httpx

from neuroloom_mcp.config import get_settings

logger = logging.getLogger(__name__)


class APIError(Exception):
    """Raised when the Neuroloom API returns an error response or is unreachable."""

    def __init__(self, status_code: int, message: str, details: Any = None) -> None:
        self.status_code = status_code
        self.message = message
        self.details = details
        super().__init__(f"API Error {status_code}: {message}")


class NeuroloomAPIClient:
    """Async HTTP client for the Neuroloom REST API.

    Usage (async context manager):

        async with NeuroloomAPIClient() as client:
            result = await client.search_memories(query="auth patterns")

    All requests carry an ``Authorization: Token <key>`` header derived from
    the ``MEMORIES_API_TOKEN`` environment variable, unless overridden on init.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        settings = get_settings()
        self.base_url = (base_url or settings.memories_api_url).rstrip("/") + "/api/v1"
        # In http mode settings.memories_api_token is None; the per-request token
        # passed explicitly by tool handlers takes precedence. If both are absent
        # (e.g. startup reachability check in http mode), _build_headers() skips
        # the Authorization header via the `if self.token:` guard below.
        self.token: Optional[str] = token or settings.memories_api_token
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "NeuroloomAPIClient":
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._build_headers(),
            timeout=self.timeout,
        )
        return self

    async def __aexit__(
        self,
        exc_type: Any,
        exc_val: Any,
        exc_tb: Any,
    ) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def _build_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Token {self.token}"
        return headers

    async def _request(
        self,
        method: str,
        path: str,
        data: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Execute an HTTP request and return the parsed JSON body.

        Args:
            method: HTTP method (GET, POST, PATCH, DELETE).
            path: URL path relative to the base URL (must start with /).
            data: Request body serialised as JSON (for POST/PATCH).
            params: Query string parameters.

        Returns:
            Parsed JSON response, or ``None`` for 204 No Content.

        Raises:
            APIError: On any HTTP 4xx/5xx response, timeout, or connection failure.
        """
        if self._client is None:
            raise RuntimeError("NeuroloomAPIClient must be used as an async context manager.")

        try:
            response = await self._client.request(
                method=method,
                url=path,
                json=data,
                params=params,
            )

            if response.status_code >= 400:
                try:
                    error_body: Any = response.json()
                except Exception:
                    error_body = response.text

                raise APIError(
                    status_code=response.status_code,
                    message=str(error_body),
                    details=error_body,
                )

            if response.status_code == 204:
                return None

            return response.json()

        except httpx.TimeoutException:
            raise APIError(408, "Request timed out")
        except httpx.ConnectError:
            raise APIError(503, f"API unreachable at {self.base_url}")

    # -------------------------------------------------------------------------
    # Workspace operations
    # -------------------------------------------------------------------------

    async def list_workspaces(self) -> list[dict[str, Any]]:
        """List all workspaces accessible by the current API key."""
        return await self._request("GET", "/workspaces/")  # type: ignore[return-value]

    async def get_workspace(self, workspace_id: str) -> dict[str, Any]:
        """Fetch a single workspace by ID."""
        return await self._request("GET", f"/workspaces/{workspace_id}/")  # type: ignore[return-value]

    # -------------------------------------------------------------------------
    # Memory operations
    # -------------------------------------------------------------------------

    async def search_memories(
        self,
        query: str,
        workspace_id: Optional[str] = None,
        memory_types: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
        files: Optional[list[str]] = None,
        tag_prefixes: list[str] | None = None,
        min_importance: Optional[float] = None,
        min_confidence: Optional[float] = None,
        use_semantic: bool = True,
        limit: int = 20,
        offset: int = 0,
        max_tokens: Optional[int] = None,
        search_profile: str = "default",
        compact: bool = False,
        include_aggregations: bool = True,
        min_score: float | None = None,
    ) -> dict[str, Any]:
        """POST /memories/search — combined keyword + semantic search.

        Pass ``compact=True`` to receive a lightweight response shape
        (``MemorySearchCompactResponse``) suitable for token-constrained
        consumers. Aggregations are omitted when compact mode is active.

        Pass ``include_aggregations=False`` to skip aggregation computation on
        the standard (non-compact) response.

        Pass ``min_score`` (0–1) to filter out results below a relevance
        threshold before the response is returned.
        """
        body: dict[str, Any] = {
            "query": query,
            "use_semantic": use_semantic,
            "limit": limit,
            "offset": offset,
            "search_profile": search_profile,
            # Boolean False is meaningful — always forward these to the API.
            "compact": compact,
            "include_aggregations": include_aggregations,
        }
        if workspace_id:
            body["workspace_id"] = workspace_id
        if memory_types:
            body["memory_types"] = memory_types
        if tags:
            body["tags"] = tags
        if files:
            body["files"] = files
        if tag_prefixes:
            body["tag_prefixes"] = tag_prefixes
        if min_importance is not None:
            body["min_importance"] = min_importance
        if min_confidence is not None:
            body["min_confidence"] = min_confidence
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if min_score is not None:
            body["min_score"] = min_score

        return await self._request("POST", "/memories/search", data=body)  # type: ignore[return-value]

    async def list_memories(
        self,
        memory_type: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /memories/ — list memories ordered by importance descending."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if memory_type:
            params["memory_type"] = memory_type
        return await self._request("GET", "/memories/", params=params)  # type: ignore[return-value]

    async def get_memory_detail(self, memory_id: str) -> dict[str, Any]:
        """GET /memories/{memory_id}/ — full memory with relationship graph."""
        return await self._request("GET", f"/memories/{memory_id}")  # type: ignore[return-value]

    async def get_related_memories(
        self,
        memory_id: str,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """GET /memories/{memory_id}/related — semantically similar memories."""
        params: dict[str, Any] = {"limit": limit}
        return await self._request(  # type: ignore[return-value]
            "GET", f"/memories/{memory_id}/related", params=params
        )

    async def store_memory(
        self,
        workspace_id: str,
        title: str,
        memory_type: str,
        content: str,
        concepts: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
        files: Optional[list[str]] = None,
        importance: float = 0.7,
        confidence: float = 0.8,
        sync_embedding: bool = False,
    ) -> dict[str, Any]:
        """POST /memories/store — persist a pre-structured memory directly."""
        body: dict[str, Any] = {
            "title": title,
            "memory_type": memory_type,
            "narrative": content,  # tool param 'content' → API field 'narrative'
            "importance_score": importance,
            "confidence_score": confidence,
            "sync_embedding": sync_embedding,
        }
        if concepts is not None:
            body["concepts"] = concepts
        if tags is not None:
            body["tags"] = tags
        if files is not None:
            body["source_files"] = files  # tool param 'files' → API field 'source_files'

        return await self._request("POST", "/memories/store", data=body)  # type: ignore[return-value]

    async def record_memory_access(self, memory_id: str) -> dict[str, Any]:
        """POST /memories/{memory_id}/access — record a direct memory read."""
        return await self._request("POST", f"/memories/{memory_id}/access")  # type: ignore[return-value]

    async def record_memory_retrieval(self, memory_id: str) -> dict[str, Any]:
        """POST /memories/{memory_id}/retrieval — record memory appearing in search."""
        return await self._request("POST", f"/memories/{memory_id}/retrieval")  # type: ignore[return-value]

    async def rate_memory(
        self,
        memory_id: str,
        useful: bool,
        context: str | None = None,
    ) -> dict[str, Any]:
        """POST /memories/{memory_id}/feedback — record usefulness feedback."""
        body: dict[str, Any] = {"useful": useful}
        if context is not None:
            body["context"] = context
        return await self._request("POST", f"/memories/{memory_id}/feedback", data=body)  # type: ignore[return-value]

    async def explore_memories(
        self,
        query: str,
        max_nodes: int = 50,
        relationship_types: list[str] | None = None,
        min_edge_confidence: float | None = None,
        workspace_id: str | None = None,
    ) -> dict[str, Any]:
        """POST /memories/explore — topic-scoped subgraph retrieval."""
        body: dict[str, Any] = {"query": query, "max_nodes": max_nodes}
        if relationship_types:
            body["relationship_types"] = relationship_types
        if min_edge_confidence is not None:
            body["min_edge_confidence"] = min_edge_confidence
        if workspace_id is not None:
            body["workspace_id"] = workspace_id
        return await self._request("POST", "/memories/explore", data=body)  # type: ignore[return-value]

    # -------------------------------------------------------------------------
    # Document ingestion operations
    # -------------------------------------------------------------------------

    async def ingest_document(self, data: dict[str, Any]) -> dict[str, Any]:
        """POST /documents/ingest — ingest a single document into the workspace."""
        return await self._request("POST", "/documents/ingest", data=data)  # type: ignore[return-value]

    async def ingest_documents_batch(self, documents: list[dict[str, Any]]) -> dict[str, Any]:
        """POST /documents/ingest/batch — batch ingest up to 50 documents."""
        return await self._request(  # type: ignore[return-value]
            "POST", "/documents/ingest/batch", data={"documents": documents}
        )

    # -------------------------------------------------------------------------
    # SDLC operations
    # -------------------------------------------------------------------------

    async def get_cc_sdlc_version(self) -> dict[str, Any]:
        """GET /sdlc/cc-sdlc-version — retrieve the latest cc-sdlc version."""
        return await self._request("GET", "/sdlc/cc-sdlc-version")  # type: ignore[return-value]

    async def seed(
        self,
        entries: list[dict[str, Any]],
        version: str,
        skip_deprecation: bool = False,
    ) -> dict[str, Any]:
        """POST /sdlc/seed — seed a workspace with SDLC knowledge entries."""
        return await self._request(  # type: ignore[return-value]
            "POST",
            "/sdlc/seed",
            data={
                "entries": entries,
                "version": version,
                "skip_deprecation": skip_deprecation,
            },
        )

    async def request_upload_url(self) -> dict[str, Any]:
        """POST /sdlc/upload-url — get a presigned upload URL for bulk seeding."""
        return await self._request("POST", "/sdlc/upload-url")  # type: ignore[return-value]

    async def request_document_upload_url(self) -> dict[str, Any]:
        """POST /documents/upload-url — get a presigned upload URL for document batch ingestion."""
        return await self._request("POST", "/documents/upload-url")  # type: ignore[return-value]

    # -------------------------------------------------------------------------
    # Code graph operations
    # -------------------------------------------------------------------------

    async def search_symbols(
        self,
        q: str | None = None,
        file_pattern: str | None = None,
        symbol_type: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """GET /code-graph/symbols/search — search code symbols."""
        params: dict[str, Any] = {"limit": limit}
        if q is not None:
            params["q"] = q
        if file_pattern is not None:
            params["file_pattern"] = file_pattern
        if symbol_type is not None:
            params["symbol_type"] = symbol_type
        return await self._request("GET", "/code-graph/symbols/search", params=params)  # type: ignore[return-value]

    async def get_symbol_neighbors(self, symbol_id: str) -> dict[str, Any]:
        """GET /code-graph/symbols/{id}/neighbors — 1-hop adjacency."""
        return await self._request("GET", f"/code-graph/symbols/{symbol_id}/neighbors")  # type: ignore[return-value]

    async def get_symbol_callers(self, symbol_id: str) -> dict[str, Any]:
        """GET /code-graph/symbols/{id}/callers — incoming edges."""
        return await self._request("GET", f"/code-graph/symbols/{symbol_id}/callers")  # type: ignore[return-value]

    async def get_symbol_callees(self, symbol_id: str) -> dict[str, Any]:
        """GET /code-graph/symbols/{id}/callees — outgoing edges."""
        return await self._request("GET", f"/code-graph/symbols/{symbol_id}/callees")  # type: ignore[return-value]

    async def get_code_context(
        self,
        symbol_id: str | None = None,
        symbol_name: str | None = None,
        file_path: str | None = None,
        max_depth: int = 5,
        max_results: int = 20,
        max_narrative_chars: int = 500,
    ) -> dict[str, Any]:
        """POST /code-graph/context — traversal + bridge memories."""
        body: dict[str, Any] = {
            "max_depth": max_depth,
            "max_results": max_results,
            "max_narrative_chars": max_narrative_chars,
        }
        if symbol_id is not None:
            body["symbol_id"] = symbol_id
        if symbol_name is not None:
            body["symbol_name"] = symbol_name
        if file_path is not None:
            body["file_path"] = file_path
        return await self._request("POST", "/code-graph/context", data=body)  # type: ignore[return-value]

    async def sync_code_graph(
        self,
        symbols: list[dict[str, Any]],
        edges: list[dict[str, Any]],
        deleted_files: list[str] | None = None,
        commit_sha: str | None = None,
    ) -> dict[str, Any]:
        """POST /code-graph/sync — sync client-parsed code graph."""
        body: dict[str, Any] = {
            "symbols": symbols,
            "edges": edges,
            "deleted_files": deleted_files or [],
        }
        if commit_sha is not None:
            body["commit_sha"] = commit_sha
        return await self._request("POST", "/code-graph/sync", data=body)  # type: ignore[return-value]

    async def get_sync_state(self) -> dict[str, Any]:
        """GET /code-graph/sync-state — last-synced commit SHA."""
        return await self._request("GET", "/code-graph/sync-state")  # type: ignore[return-value]

    # -------------------------------------------------------------------------
    # Session operations
    # -------------------------------------------------------------------------

    async def start_session(
        self,
        session_id: str,
        project_name: str = "",
        branch_name: str = "",
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """POST /sessions/start — start a new session."""
        body: dict[str, Any] = {
            "session_id": session_id,
            "project_name": project_name,
            "branch_name": branch_name,
            "metadata": metadata or {},
        }
        return await self._request("POST", "/sessions/start", data=body)  # type: ignore[return-value]

    async def end_session(
        self,
        session_id: str,
        summary: str = "",
    ) -> dict[str, Any]:
        """POST /sessions/{session_id}/end — end an active session."""
        body: dict[str, Any] = {}
        if summary:
            body["summary"] = summary
        return await self._request("POST", f"/sessions/{session_id}/end", data=body)  # type: ignore[return-value]

    async def get_session(self, session_id: str) -> dict[str, Any]:
        """GET /sessions/{session_id} — fetch session by ID."""
        return await self._request("GET", f"/sessions/{session_id}")  # type: ignore[return-value]

    async def get_session_context(
        self,
        session_id: str,
        max_memories: int = 10,
    ) -> dict[str, Any]:
        """GET /sessions/{session_id}/context — context for injection."""
        params: dict[str, Any] = {"max_memories": max_memories}
        return await self._request(  # type: ignore[return-value]
            "GET", f"/sessions/{session_id}/context", params=params
        )
