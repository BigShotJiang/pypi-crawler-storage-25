"""
Neuroloom MCP Server.

Entry point for the MCP server that exposes 28 Neuroloom knowledge graph
tools to Claude Code via the Model Context Protocol.

Transport modes:
    stdio   — Default. Local subprocess mode, used for direct Claude Code
              integration. Selected by MCP_TRANSPORT=stdio (or absent).
    http    — Hosted mode. Starlette ASGI app served by uvicorn, suitable for
              Railway deployment. Selected by MCP_TRANSPORT=http.

Tools exposed:
    memory_search        — combined keyword + semantic search
    memory_get_detail    — full memory with relationship graph
    memory_get_timeline  — recent memories ordered by time
    memory_get_index     — lightweight title-only overview
    memory_get_related   — semantically similar memories
    memory_by_file       — memories linked to a specific file path
    memory_store         — persist a pre-structured memory directly
    memory_rate          — record usefulness feedback for a memory
    memory_explore       — topic-scoped subgraph (nodes + edges)
    session_start        — register a new session and inject initial context
    session_end          — close a session (triggers async extraction)
    session_get_context  — retrieve high-importance context for the session
    document_ingest      — ingest a single document into the knowledge graph
    document_ingest_batch — ingest multiple documents in a single request
    document_ingest_file        — read a local file and ingest it (stdio only)
    document_ingest_files_batch — read multiple local files and batch ingest (stdio only)
    document_ingest_batch_from_file  — read a JSON file and batch ingest documents (stdio only)
    document_ingest_batch_get_upload_url — get a presigned upload URL for document batch ingestion (HTTP only)
    sdlc_get_version     — retrieve SDLC framework version metadata
    sdlc_seed             — seed a workspace with SDLC knowledge entries
    sdlc_seed_from_file  — read a JSON file and seed workspace entries (stdio only)
    sdlc_seed_get_upload_url — get a presigned upload URL and curl command for HTTP-mode bulk seeding
"""

import argparse
import asyncio
import contextlib
import inspect
import json
import logging
import shutil
import sys
from collections.abc import AsyncIterator
from importlib.resources import as_file, files
from pathlib import Path
from typing import Any, Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool, ToolAnnotations
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse

from neuroloom_mcp import __version__
from neuroloom_mcp.client import APIError, NeuroloomAPIClient
from neuroloom_mcp.config import get_request_token, get_settings
from neuroloom_mcp.tools import (
    code_callers,
    code_callees,
    code_context,
    code_navigate,
    code_search,
    code_sync,
    document_ingest,
    document_ingest_batch,
    document_ingest_batch_from_file,
    document_ingest_batch_get_upload_url,
    document_ingest_file,
    document_ingest_files_batch,
    memory_by_file,
    memory_explore,
    memory_get_detail,
    memory_get_index,
    memory_get_related,
    memory_get_timeline,
    memory_rate,
    memory_search,
    memory_store,
    sdlc_get_version,
    sdlc_seed,
    sdlc_seed_from_file,
    sdlc_seed_get_upload_url,
    session_end,
    session_get_context,
    session_start,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# MCP server instance
# ---------------------------------------------------------------------------

server: Server = Server(
    "neuroloom-mcp",
    instructions=(
        "Neuroloom is this project’s canonical knowledge system."
        " It stores architecture decisions, design rationale,"
        " conventions, past bugs, tribal knowledge, and session"
        " context that source code alone does not capture.\n\n"
        "WHEN TO USE (check Neuroloom BEFORE exploring code):\n"
        "- User asks ‘how does X work?’, ‘why did we choose Y?’,"
        " ‘what’s our pattern for Z?’ -> memory_search\n"
        "- You’re about to Grep/Glob/Read to understand a subsystem"
        " -> memory_search first, code second\n"
        "- Starting a new session or conversation -> session_start"
        " to load prior context\n"
        "- About to modify a file -> memory_by_file to check for"
        " known gotchas and prior decisions\n"
        "- Dispatching a subagent -> memory_search for relevant"
        " context to include in the dispatch prompt\n"
        "- Solved a non-obvious problem or made a design decision"
        " -> memory_store to capture it\n\n"
        "WHEN NOT TO USE:\n"
        "- General programming concepts -> your training data\n"
        "- External library APIs -> Context7 or web search\n"
        "- Simple file reads where you already know the path\n\n"
        "Code shows WHAT was built. Neuroloom explains WHY."
    ),
)

# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

TOOLS: list[Tool] = [
    Tool(
        name="memory_search",
        title="Search Project Knowledge",
        description=(
            "Ask this project's knowledge graph before searching code or guessing. "
            "Use whenever you need to know why something was built a certain way, what "
            "decisions were made, how a subsystem works, what patterns to follow, or what "
            "was tried before. This is the fastest path to project-specific answers — "
            "architecture, conventions, past bugs, design rationale, and tribal knowledge "
            "that isn't in the code.\n\n"
            "Reach for this FIRST when asked about: how does X work, why is X done this way, "
            "what's our approach to X, has anyone tried X, what do we know about X.\n\n"
            "Supports natural language queries. Filter by memory type (decision, pattern, "
            "architecture, insight), tags, file paths, or importance threshold.\n\n"
            "Example: memory_search(query='why did we choose HNSW over IVFFlat')"
        ),
        annotations=ToolAnnotations(
            title="Search Project Knowledge",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "What you want to know — ask in natural language, e.g. 'why do we use HNSW', 'auth middleware decisions', 'known issues with the search endpoint'.",
                },
                "workspace_id": {
                    "type": "string",
                    "description": "Target workspace ID (optional — uses default from env).",
                },
                "memory_types": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by memory types: decision, pattern, architecture, insight, etc.",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by tags.",
                },
                "files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter to memories referencing these file paths.",
                },
                "min_importance": {
                    "type": "number",
                    "description": "Minimum importance score (0.0–1.0).",
                },
                "min_confidence": {
                    "type": "number",
                    "description": "Minimum confidence score (0.0–1.0).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results to return (default 5, max 100). Keep at 5 for focused lookups; raise to 10–20 for broad surveys.",
                    "default": 5,
                },
                "max_narrative_chars": {
                    "type": "integer",
                    "description": "Truncate each result's snippet to this many characters (default 500). Keeps results token-light — call memory_get_detail for the full narrative once you've identified what's relevant. Set higher for richer previews.",
                    "default": 500,
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="memory_get_detail",
        title="Get Memory Detail",
        description=(
            "Read the full story behind a memory — the complete narrative, related concepts, "
            "source files, and its connections to other memories. Use after memory_search "
            "surfaces something relevant and you need the full context, not just the summary. "
            "Also shows which other memories are connected, so you can follow the thread.\n\n"
            "Example: memory_get_detail(memory_id='mem-abc123')"
        ),
        annotations=ToolAnnotations(
            title="Get Memory Detail",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": "string",
                    "description": "The memory_id string (e.g. 'mem-abc123').",
                },
                "include_related": {
                    "type": "boolean",
                    "description": "Append up to 5 semantically related memories (default true).",
                    "default": True,
                },
            },
            "required": ["memory_id"],
        },
    ),
    Tool(
        name="memory_get_timeline",
        title="Recent Knowledge Timeline",
        description=(
            "See what the team learned recently — decisions made, patterns discovered, "
            "and insights captured over the last N days, newest first. Use when catching "
            "up on recent work, starting a new session, or wondering 'what changed lately?'\n\n"
            "Example: memory_get_timeline(days=7)"
        ),
        annotations=ToolAnnotations(
            title="Recent Knowledge Timeline",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Target workspace ID (optional — uses default from env).",
                },
                "days": {
                    "type": "integer",
                    "description": "How many days back to include (default 7).",
                    "default": 7,
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of memories (default 30).",
                    "default": 30,
                },
            },
        },
    ),
    Tool(
        name="memory_get_index",
        title="Browse Knowledge Index",
        description=(
            "Get a quick table of contents of everything the project knows — just titles "
            "and types, no full content. The cheapest way to see what knowledge exists "
            "before deciding what to read in detail. Use when you want to browse rather "
            "than search, or to check if a topic has been captured at all.\n\n"
            "Example: memory_get_index(limit=50)"
        ),
        annotations=ToolAnnotations(
            title="Browse Knowledge Index",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Target workspace ID (optional — uses default from env).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum entries to return (default 50).",
                    "default": 50,
                },
            },
        },
    ),
    Tool(
        name="memory_get_related",
        title="Find Related Memories",
        description=(
            "Follow the thread — find memories that are conceptually connected to one "
            "you already have. Use when a memory mentions a decision and you want to "
            "see what else was considered, or when exploring how ideas link together "
            "across the knowledge graph.\n\n"
            "Example: memory_get_related(memory_id='mem-abc123', limit=10)"
        ),
        annotations=ToolAnnotations(
            title="Find Related Memories",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": "string",
                    "description": "The memory_id of the source memory.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum related memories to return (default 10).",
                    "default": 10,
                },
            },
            "required": ["memory_id"],
        },
    ),
    Tool(
        name="memory_by_file",
        title="Get File Context",
        description=(
            "Before modifying a file, check what the project remembers about it — past "
            "decisions, known gotchas, patterns, and context captured by previous sessions. "
            "Use whenever you're about to edit a file and want to avoid repeating mistakes "
            "or contradicting prior decisions.\n\n"
            "Example: memory_by_file(file_path='src/auth/dependencies.py')"
        ),
        annotations=ToolAnnotations(
            title="Get File Context",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "File path to search for (partial matches supported).",
                },
                "workspace_id": {
                    "type": "string",
                    "description": "Target workspace ID (optional — uses default from env).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results to return (default 10). Raise to 20 for files with heavy history.",
                    "default": 10,
                },
            },
            "required": ["file_path"],
        },
    ),
    Tool(
        name="memory_store",
        title="Store a Memory",
        description=(
            "Capture an insight, decision, or lesson learned so future sessions can benefit. "
            "Use when you've just solved a non-obvious problem, made a design decision with "
            "important rationale, discovered a pattern worth following, or learned something "
            "that would save time next time. The memory is stored immediately; pass "
            "sync_embedding=true to make it searchable before returning, otherwise embedding "
            "generation and relationship discovery run in the background.\n\n"
            "Example: memory_store(title='Always use selectinload for relationships', "
            "memory_type='pattern', content='SQLAlchemy lazy=raise requires explicit ...')"
        ),
        annotations=ToolAnnotations(
            title="Store a Memory",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=False,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Memory title.",
                },
                "memory_type": {
                    "type": "string",
                    "description": "Category: pattern, decision, architecture, insight, etc.",
                },
                "content": {
                    "type": "string",
                    "description": "The primary memory narrative.",
                },
                "workspace_id": {
                    "type": "string",
                    "description": "Target workspace ID (optional — uses default from env).",
                },
                "summary": {
                    "type": "string",
                    "description": "Short one-line summary (optional).",
                },
                "concepts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Key concept labels for relationship discovery.",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Freeform tags for filtering.",
                },
                "files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Source file paths that are the primary subject of this memory. "
                        "For code-related types (decision, pattern, bug_fix, architecture, "
                        "implementation), include file paths to enable code graph linking."
                    ),
                },
                "context_files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Additional file paths from your current editing context. "
                        "Merged into 'files' with deduplication. Pass the files you "
                        "have open or recently edited, even if they aren't the primary "
                        "subject of this memory — this improves code graph linking."
                    ),
                },
                "importance": {
                    "type": "number",
                    "description": "Importance score 0.0–1.0 (default 0.7).",
                },
                "confidence": {
                    "type": "number",
                    "description": "Confidence score 0.0–1.0 (default 0.8).",
                },
                "sync_embedding": {
                    "type": "boolean",
                    "description": (
                        "When true, generate the embedding inline before "
                        "returning instead of deferring to the background "
                        "worker. Use when you need the memory to be "
                        "searchable immediately."
                    ),
                },
            },
            "required": ["title", "memory_type", "content"],
        },
    ),
    Tool(
        name="memory_rate",
        title="Rate Memory Usefulness",
        description=(
            "Tell the knowledge graph whether a memory was actually useful — this trains "
            "it to surface better results over time. Rate positively when a memory saved "
            "you time or prevented a mistake. Rate negatively when it was outdated, wrong, "
            "or irrelevant. The system adjusts importance scores based on this feedback.\n\n"
            "Example: memory_rate(memory_id='mem-abc123', useful=true, "
            "context='Helped resolve the auth middleware issue')"
        ),
        annotations=ToolAnnotations(
            title="Rate Memory Usefulness",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": "string",
                    "description": "The memory_id string (e.g. 'mem-abc123').",
                },
                "useful": {
                    "type": "boolean",
                    "description": "True if the memory was helpful, False otherwise.",
                },
                "context": {
                    "type": "string",
                    "description": "Optional explanation of why the memory was or was not useful.",
                },
            },
            "required": ["memory_id", "useful"],
        },
    ),
    Tool(
        name="memory_explore",
        title="Explore Memory Neighborhood",
        description=(
            "Explore a topic area in the knowledge graph. Returns related memories "
            "AND the relationship edges between them — not just a flat list.\n\n"
            "Use memory_explore when asked about a topic area or subsystem:\n"
            "- 'How does our authentication work?'\n"
            "- 'Tell me about our integrations'\n"
            "- 'What's the full picture on search?'\n\n"
            "Use memory_search for specific lookups:\n"
            "- 'What's our pattern for X?'\n"
            "- 'Why did we choose Y?'\n\n"
            "When in doubt, use memory_explore — more context is always "
            "better than less.\n\n"
            "Example: memory_explore(query='authentication architecture')"
        ),
        annotations=ToolAnnotations(
            title="Explore Memory Neighborhood",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=False,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural language topic query — what neighborhood to explore.",
                },
                "max_nodes": {
                    "type": "integer",
                    "description": "Maximum nodes in result (default 50, max 200).",
                },
                "relationship_types": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter edges to these relationship types only.",
                },
                "min_edge_confidence": {
                    "type": "number",
                    "description": "Minimum edge confidence for expansion (0.0–1.0).",
                },
                "workspace_id": {
                    "type": "string",
                    "description": "Target workspace ID (optional — uses default from env).",
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="session_start",
        title="Start Session",
        description=(
            "Begin a work session — registers it with the knowledge graph and immediately "
            "returns the most relevant memories from past sessions as context. Call this "
            "at the start of any conversation to pick up where previous sessions left off "
            "and avoid re-discovering things the project already knows.\n\n"
            "Example: session_start()"
        ),
        annotations=ToolAnnotations(
            title="Start Session",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=False,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Target workspace ID (optional — uses default from env).",
                },
                "project_path": {
                    "type": "string",
                    "description": "Working directory for this session (auto-detected if omitted).",
                },
            },
        },
    ),
    Tool(
        name="session_end",
        title="End Session",
        description=(
            "Wrap up the current work session — triggers extraction of any observations "
            "into structured memories so they're available for future sessions. Include "
            "a summary of what was accomplished so the knowledge graph captures the outcome.\n\n"
            "Example: session_end(session_id='...', summary='Implemented auth flow')"
        ),
        annotations=ToolAnnotations(
            title="End Session",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Session ID returned by session_start (required).",
                },
                "summary": {
                    "type": "string",
                    "description": "Optional human-written summary of the session's outcomes.",
                },
            },
            "required": ["session_id"],
        },
    ),
    Tool(
        name="session_get_context",
        title="Refresh Session Context",
        description=(
            "Refresh your working memory mid-session — pulls the highest-importance "
            "memories relevant to the current workspace. Use when the conversation has "
            "shifted topics and you need updated context, or when you suspect there's "
            "knowledge you haven't loaded yet.\n\n"
            "Example: session_get_context(session_id='...', max_memories=10)"
        ),
        annotations=ToolAnnotations(
            title="Refresh Session Context",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Active session ID (required).",
                },
                "max_memories": {
                    "type": "integer",
                    "description": "Maximum memories to return (default 10).",
                    "default": 10,
                },
            },
            "required": ["session_id"],
        },
    ),
    Tool(
        name="document_ingest",
        title="Ingest Document",
        description=(
            "Feed a document into the knowledge graph so its content becomes searchable "
            "and linkable to other memories. Use when you have a design doc, spec, "
            "reference, or any text that should be part of the project's persistent "
            "knowledge. Duplicates are detected automatically via content hashing.\n\n"
            "Example: document_ingest(title='Auth design', content='...', source_type='file')"
        ),
        annotations=ToolAnnotations(
            title="Ingest Document",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Document title.",
                },
                "content": {
                    "type": "string",
                    "description": "Full document text content.",
                },
                "source_type": {
                    "type": "string",
                    "description": "Origin category, e.g. 'file', 'url', 'clipboard'.",
                },
                "source_path": {
                    "type": "string",
                    "description": "Optional path or URL the document was sourced from.",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional freeform tags for filtering.",
                },
                "format": {
                    "type": "string",
                    "description": "Optional document format hint, e.g. 'markdown', 'rst', 'text'.",
                },
                "memory_type": {
                    "type": "string",
                    "description": "Optional memory type to associate with the document.",
                },
                "knowledge_id": {
                    "type": "string",
                    "description": "Optional knowledge base ID to associate the document with.",
                },
                "version": {
                    "type": "string",
                    "description": "Optional version string, e.g. a semver or git SHA.",
                },
                "importance": {
                    "type": "number",
                    "description": "Optional importance score in [0.0, 1.0].",
                },
            },
            "required": ["title", "content", "source_type"],
        },
    ),
    Tool(
        name="document_ingest_batch",
        title="Batch Ingest Documents",
        description=(
            "Feed multiple documents into the knowledge graph in one call (up to 50). "
            "Use when importing a collection of docs, specs, or references at once. "
            "Each document needs title, content, and source_type at minimum.\n\n"
            "Example: document_ingest_batch(documents=[{'title': '...', 'content': '...', "
            "'source_type': 'file'}])"
        ),
        annotations=ToolAnnotations(
            title="Batch Ingest Documents",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "documents": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string"},
                            "content": {"type": "string"},
                            "source_type": {"type": "string"},
                            "source_path": {"type": "string"},
                            "tags": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "format": {"type": "string"},
                            "memory_type": {"type": "string"},
                            "knowledge_id": {"type": "string"},
                            "version": {"type": "string"},
                            "importance": {"type": "number"},
                        },
                        "required": ["title", "content", "source_type"],
                    },
                    "description": "List of documents to ingest (max 50).",
                    "maxItems": 50,
                },
            },
            "required": ["documents"],
        },
    ),
    Tool(
        name="document_ingest_file",
        title="Ingest File from Disk",
        description=(
            "Ingest a file directly from disk into the knowledge graph — use instead of "
            "document_ingest when the file is too large to pass as an argument. The server "
            "reads it locally, so content never hits transport limits.\n\n"
            "stdio mode only (not available in HTTP mode).\n\n"
            "Example: document_ingest_file(path='/Users/dev/project/docs/design.md')"
        ),
        annotations=ToolAnnotations(
            title="Ingest File from Disk",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file to ingest.",
                },
                "title": {
                    "type": "string",
                    "description": "Document title. Defaults to the filename without extension.",
                },
                "source_type": {
                    "type": "string",
                    "description": "Origin category, e.g. 'file', 'url', 'clipboard'.",
                    "default": "file",
                },
                "source_path": {
                    "type": "string",
                    "description": "Optional path or URL to record as the document source. Defaults to the resolved absolute path.",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional freeform tags for filtering.",
                },
                "format": {
                    "type": "string",
                    "description": "Optional document format hint, e.g. 'markdown', 'rst', 'text'.",
                },
                "memory_type": {
                    "type": "string",
                    "description": "Optional memory type to associate with the document.",
                },
                "knowledge_id": {
                    "type": "string",
                    "description": "Optional knowledge base ID to associate the document with.",
                },
                "version": {
                    "type": "string",
                    "description": "Optional version string, e.g. a semver or git SHA.",
                },
                "importance": {
                    "type": "number",
                    "description": "Optional importance score in [0.0, 1.0].",
                },
            },
            "required": ["path"],
        },
    ),
    Tool(
        name="document_ingest_files_batch",
        title="Batch Ingest Files from Disk",
        description=(
            "Ingest multiple files from disk in one call (up to 50) — reads all files "
            "concurrently server-side. Use instead of document_ingest_batch when files "
            "are too large to pass as arguments.\n\n"
            "stdio mode only (not available in HTTP mode).\n\n"
            "Example: document_ingest_files_batch(documents=[{'path': '/Users/dev/project/docs/design.md'}, "
            "{'path': '/Users/dev/project/docs/api.md', 'title': 'API Reference'}])"
        ),
        annotations=ToolAnnotations(
            title="Batch Ingest Files from Disk",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "documents": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {
                                "type": "string",
                                "description": "Absolute or relative path to the file.",
                            },
                            "title": {
                                "type": "string",
                                "description": "Document title. Defaults to the filename without extension.",
                            },
                            "source_type": {
                                "type": "string",
                                "description": "Origin category. Defaults to 'file'.",
                                "default": "file",
                            },
                            "source_path": {
                                "type": "string",
                                "description": "Optional path or URL to record as the document source.",
                            },
                            "tags": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Optional freeform tags for filtering.",
                            },
                            "format": {
                                "type": "string",
                                "description": "Optional document format hint.",
                            },
                            "memory_type": {
                                "type": "string",
                                "description": "Optional memory type.",
                            },
                            "knowledge_id": {
                                "type": "string",
                                "description": "Optional knowledge base ID.",
                            },
                            "version": {
                                "type": "string",
                                "description": "Optional version string.",
                            },
                            "importance": {
                                "type": "number",
                                "description": "Optional importance score in [0.0, 1.0].",
                            },
                        },
                        "required": ["path"],
                    },
                    "description": "List of file documents to ingest (max 50).",
                    "minItems": 1,
                    "maxItems": 50,
                },
            },
            "required": ["documents"],
        },
    ),
    Tool(
        name="document_ingest_batch_from_file",
        title="Batch Ingest from JSON File",
        description=(
            "Ingest a batch of documents from a JSON file on disk — use when the document "
            "list is too large to pass inline. The file must be a flat JSON array of "
            "document objects (max 50, max 10 MB).\n\n"
            "stdio mode only — in HTTP mode use document_ingest_batch_get_upload_url.\n\n"
            "Example: document_ingest_batch_from_file(path='/tmp/documents.json')"
        ),
        annotations=ToolAnnotations(
            title="Batch Ingest from JSON File",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute path to a JSON file containing a flat array of document objects.",
                },
            },
            "required": ["path"],
        },
    ),
    Tool(
        name="document_ingest_batch_get_upload_url",
        title="Get Document Upload URL (HTTP)",
        description=(
            "HTTP mode only — get a presigned upload URL for batch document ingestion. "
            "Returns a curl command you must run via Bash to complete the upload.\n\n"
            "Workflow: prepare a JSON file with {\"documents\": [{...}, ...]}, call this "
            "tool, then run the returned curl_command. URL expires in 5 minutes.\n\n"
            "In stdio mode use document_ingest_batch_from_file instead.\n\n"
            "Example: document_ingest_batch_get_upload_url(path='/tmp/documents.json')"
        ),
        annotations=ToolAnnotations(
            title="Get Document Upload URL (HTTP)",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": 'Absolute path to a JSON file containing {"documents": [...]} with 1-50 document objects.',
                },
            },
            "required": ["path"],
        },
    ),
    Tool(
        name="sdlc_get_version",
        title="Check SDLC Version",
        description=(
            "Check if the SDLC framework is up to date — returns the latest cc-sdlc "
            "version from the upstream proxy. Use before migrations or when the user "
            "asks about SDLC version status.\n\n"
            "Example: sdlc_get_version()"
        ),
        annotations=ToolAnnotations(
            title="Check SDLC Version",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="sdlc_seed",
        title="Seed SDLC Knowledge",
        description=(
            "Load SDLC process knowledge into the workspace — use instead of "
            "document_ingest_batch for SDLC entries because it handles deduplication, "
            "versioning, and deprecation lifecycle automatically.\n\n"
            "For large entry sets (200+): use sdlc_seed_from_file (stdio) or "
            "sdlc_seed_get_upload_url (HTTP) instead.\n\n"
            "Example: sdlc_seed(entries=[{'title': '...', 'content': '...', "
            "'tags': ['sdlc:knowledge'], 'knowledge_id': 'arch:patterns'}], "
            "version='1.5.0')"
        ),
        annotations=ToolAnnotations(
            title="Seed SDLC Knowledge",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "entries": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string"},
                            "content": {"type": "string"},
                            "tags": {"type": "array", "items": {"type": "string"}},
                            "knowledge_id": {"type": "string"},
                            "importance": {"type": "number"},
                            "confidence": {"type": "number"},
                            "concepts": {"type": "array", "items": {"type": "string"}},
                            "source_path": {
                                "type": "string",
                                "description": "Local file path the entry was sourced from.",
                            },
                        },
                        "required": ["title", "content", "tags", "knowledge_id"],
                    },
                    "description": "List of SDLC knowledge entries to seed.",
                    "minItems": 1,
                    "maxItems": 500,
                },
                "version": {
                    "type": "string",
                    "description": "Seed version string, e.g. a cc-sdlc release tag.",
                },
                "skip_deprecation": {
                    "type": "boolean",
                    "default": False,
                    "description": (
                        "When true, skip the deprecation step that tags entries "
                        "missing from this batch as sdlc:deprecated. Use when "
                        "sending entries in multiple chunks — only the final "
                        "chunk should set this to false."
                    ),
                },
            },
            "required": ["entries", "version"],
        },
    ),
    Tool(
        name="sdlc_seed_from_file",
        title="Seed SDLC from File",
        description=(
            "Seed SDLC knowledge from a JSON file on disk — use when the entry set is "
            "too large to pass inline. File must contain {\"entries\": [...], \"version\": \"...\"}. "
            "Max 100 MB, 10,000 entries.\n\n"
            "stdio mode only — in HTTP mode use sdlc_seed_get_upload_url.\n\n"
            "Example: sdlc_seed_from_file(path='/tmp/seed.json')"
        ),
        annotations=ToolAnnotations(
            title="Seed SDLC from File",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": (
                        "Absolute or relative path to a JSON file containing "
                        '{"entries": [...], "version": "..."}.'
                    ),
                },
            },
            "required": ["path"],
        },
    ),
    Tool(
        name="sdlc_seed_get_upload_url",
        title="Get SDLC Seed Upload URL (HTTP)",
        description=(
            "HTTP mode only — get a presigned upload URL for SDLC knowledge seeding. "
            "Returns a curl command you must run via Bash to complete the upload. "
            "URL expires in 5 minutes.\n\n"
            "In stdio mode use sdlc_seed_from_file instead.\n\n"
            "Example: sdlc_seed_get_upload_url(path='/tmp/seed.json')"
        ),
        annotations=ToolAnnotations(
            title="Get SDLC Seed Upload URL (HTTP)",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the seed JSON file on the agent's local filesystem.",
                },
            },
            "required": ["path"],
        },
    ),
    # -----------------------------------------------------------------
    # Code graph tools
    # -----------------------------------------------------------------
    Tool(
        name="code_search",
        title="Search Code Symbols",
        description=(
            "Find functions, classes, or modules by name or file pattern. "
            "Use this to resolve a function name to its symbol_id before calling "
            "code_callers, code_callees, or code_context.\n\n"
            "Example: code_search(q='createUser') -> returns symbol_id for code_context"
        ),
        annotations=ToolAnnotations(
            title="Search Code Symbols",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "q": {
                    "type": "string",
                    "description": "Name substring filter (case-insensitive).",
                },
                "file_pattern": {
                    "type": "string",
                    "description": "File path glob pattern (e.g. 'src/services/*.ts').",
                },
                "symbol_type": {
                    "type": "string",
                    "description": "Filter by type: 'function', 'class', or 'module'.",
                    "enum": ["function", "class", "module"],
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results (default 50).",
                    "default": 50,
                },
            },
        },
    ),
    Tool(
        name="code_navigate",
        title="Navigate Code Graph",
        description=(
            "See what calls a function and what it calls (1-hop graph view). "
            "Use for graph topology only (callers/callees). For linked memories "
            "alongside the call chain, use code_context instead.\n\n"
            "Requires a symbol_id. Use code_search first to resolve a function "
            "name to its symbol_id."
        ),
        annotations=ToolAnnotations(
            title="Navigate Code Graph",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "symbol_id": {
                    "type": "string",
                    "description": "UUID of the code symbol.",
                },
            },
            "required": ["symbol_id"],
        },
    ),
    Tool(
        name="code_callers",
        title="Get Symbol Callers",
        description=(
            "Get all functions/methods that call this symbol (incoming edges only). "
            "Requires a symbol_id. Use code_search first to resolve a function "
            "name to its symbol_id."
        ),
        annotations=ToolAnnotations(
            title="Get Symbol Callers",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "symbol_id": {
                    "type": "string",
                    "description": "UUID of the code symbol.",
                },
            },
            "required": ["symbol_id"],
        },
    ),
    Tool(
        name="code_callees",
        title="Get Symbol Callees",
        description=(
            "Get all functions/methods that this symbol calls (outgoing edges only). "
            "Requires a symbol_id. Use code_search first to resolve a function "
            "name to its symbol_id."
        ),
        annotations=ToolAnnotations(
            title="Get Symbol Callees",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "symbol_id": {
                    "type": "string",
                    "description": "UUID of the code symbol.",
                },
            },
            "required": ["symbol_id"],
        },
    ),
    Tool(
        name="code_context",
        title="Get Code Context with Memories",
        description=(
            "Given a symbol, traverse its call chain and return all linked memories. "
            "Use this when you need code structure + memory context together — it answers "
            "'what do we know about this function and everything it touches?'\n\n"
            "Provide either symbol_id (from code_search) or symbol_name + optional "
            "file_path for name-based lookup.\n\n"
            "When the response includes graph_empty: true, no symbols are indexed. "
            "Run code_sync on your project files first."
        ),
        annotations=ToolAnnotations(
            title="Get Code Context with Memories",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "symbol_id": {
                    "type": "string",
                    "description": "UUID of the code symbol (from code_search).",
                },
                "symbol_name": {
                    "type": "string",
                    "description": "Function/class name for name-based lookup.",
                },
                "file_path": {
                    "type": "string",
                    "description": "File path to disambiguate when multiple symbols share a name.",
                },
                "max_depth": {
                    "type": "integer",
                    "description": "Maximum call chain depth (1-10, default 5).",
                    "default": 5,
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum symbols in response (default 20).",
                    "default": 20,
                },
            },
        },
    ),
    Tool(
        name="code_sync",
        title="Sync Code Graph",
        description=(
            "Parse local source files and sync structural metadata to Neuroloom. "
            "Extracts functions, classes, and call relationships from TypeScript and "
            "Python files using Tree-sitter. No source code is transmitted — only "
            "structural metadata (names, types, line ranges, edges).\n\n"
            "Run this after significant code changes to keep the code graph current.\n\n"
            "Requires the codegraph optional dependency: cd mcp && uv sync --extra codegraph"
        ),
        annotations=ToolAnnotations(
            title="Sync Code Graph",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File or directory paths to parse. Directories are walked recursively.",
                },
                "workspace_root": {
                    "type": "string",
                    "description": "Root directory for relative path computation.",
                },
                "commit_sha": {
                    "type": "string",
                    "description": "Current git HEAD SHA for sync state tracking.",
                },
                "deleted_files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Workspace-relative paths of deleted files to remove from the graph.",
                },
            },
            "required": ["paths"],
        },
    ),
]

# ---------------------------------------------------------------------------
# Anthropic-specific _meta annotations for Claude Code tool discovery.
#
# Claude Code reads these from tool._meta (the "_meta" alias of Tool.meta):
#   - "anthropic/alwaysLoad": True   -> tool is never deferred by ToolSearch
#   - "anthropic/searchHint": str    -> 3-10 word phrase for ToolSearch scoring
#
# Tool.meta uses Field(alias="_meta") with populate_by_name disabled, so we
# must set the attribute post-construction.
# ---------------------------------------------------------------------------

_TOOL_META: dict[str, dict[str, object]] = {
    # --- Tier 1: always loaded (bypass deferral) ---
    "memory_search": {
        "anthropic/alwaysLoad": True,
        "anthropic/searchHint": "search project knowledge architecture decisions conventions",
    },
    "memory_explore": {
        "anthropic/alwaysLoad": True,
        "anthropic/searchHint": "explore topic area how does work tell me about subsystem architecture integrations",
    },
    "session_start": {
        "anthropic/searchHint": "start begin session register conversation context",
    },
    "memory_by_file": {
        "anthropic/searchHint": "file context memories decisions gotchas before editing",
    },
    # --- Tier 2: context & navigation ---
    "memory_get_detail": {
        "anthropic/searchHint": "get full memory detail narrative relationships",
    },
    "memory_get_timeline": {
        "anthropic/searchHint": "recent memories timeline what changed lately",
    },
    "memory_get_index": {
        "anthropic/searchHint": "browse list all memories index table of contents",
    },
    "memory_get_related": {
        "anthropic/searchHint": "find related similar connected memories graph",
    },
    "session_get_context": {
        "anthropic/searchHint": "refresh reload session context working memory",
    },
    # --- Tier 3: mutation & persistence ---
    "memory_store": {
        "anthropic/searchHint": "store save remember capture insight decision pattern",
    },
    "memory_rate": {
        "anthropic/searchHint": "rate feedback useful memory quality scoring",
    },
    "session_end": {
        "anthropic/searchHint": "end close finish session wrap up save",
    },
    # --- Tier 4: document ingestion ---
    "document_ingest": {
        "anthropic/searchHint": "ingest import document spec design doc knowledge",
    },
    "document_ingest_batch": {
        "anthropic/searchHint": "batch ingest multiple documents bulk import",
    },
    "document_ingest_file": {
        "anthropic/searchHint": "ingest file from disk local filesystem",
    },
    "document_ingest_files_batch": {
        "anthropic/searchHint": "batch ingest multiple files from disk",
    },
    "document_ingest_batch_from_file": {
        "anthropic/searchHint": "batch ingest documents from JSON file",
    },
    "document_ingest_batch_get_upload_url": {
        "anthropic/searchHint": "upload URL presigned batch documents HTTP",
    },
    # --- Tier 5: SDLC ---
    "sdlc_get_version": {
        "anthropic/searchHint": "SDLC version check update migration",
    },
    "sdlc_seed": {
        "anthropic/searchHint": "seed SDLC knowledge process entries workspace",
    },
    "sdlc_seed_from_file": {
        "anthropic/searchHint": "seed SDLC knowledge from JSON file",
    },
    "sdlc_seed_get_upload_url": {
        "anthropic/searchHint": "upload URL presigned SDLC seed HTTP",
    },
    # --- Code graph tools ---
    "code_search": {
        "anthropic/searchHint": "find function class symbol name file code graph",
    },
    "code_navigate": {
        "anthropic/searchHint": "code graph callers callees neighbors navigate",
    },
    "code_callers": {
        "anthropic/searchHint": "who calls this function incoming edges",
    },
    "code_callees": {
        "anthropic/searchHint": "what does this function call outgoing edges",
    },
    "code_context": {
        "anthropic/searchHint": "code context memories call chain traversal",
    },
    "code_sync": {
        "anthropic/searchHint": "sync parse tree-sitter code graph index files",
    },
}

for _tool in TOOLS:
    if _tool.name in _TOOL_META:
        _tool.meta = _TOOL_META[_tool.name]

# ---------------------------------------------------------------------------
# MCP request handlers
# ---------------------------------------------------------------------------

_TOOL_DISPATCH: dict[str, Any] = {
    "memory_search": memory_search,
    "memory_get_detail": memory_get_detail,
    "memory_get_timeline": memory_get_timeline,
    "memory_get_index": memory_get_index,
    "memory_get_related": memory_get_related,
    "memory_by_file": memory_by_file,
    "memory_store": memory_store,
    "memory_rate": memory_rate,
    "memory_explore": memory_explore,
    "session_start": session_start,
    "session_end": session_end,
    "session_get_context": session_get_context,
    "document_ingest": document_ingest,
    "document_ingest_batch": document_ingest_batch,
    "document_ingest_file": document_ingest_file,
    "document_ingest_files_batch": document_ingest_files_batch,
    "document_ingest_batch_from_file": document_ingest_batch_from_file,
    "document_ingest_batch_get_upload_url": document_ingest_batch_get_upload_url,
    "sdlc_get_version": sdlc_get_version,
    "sdlc_seed": sdlc_seed,
    "sdlc_seed_from_file": sdlc_seed_from_file,
    "sdlc_seed_get_upload_url": sdlc_seed_get_upload_url,
    "code_search": code_search,
    "code_navigate": code_navigate,
    "code_callers": code_callers,
    "code_callees": code_callees,
    "code_context": code_context,
    "code_sync": code_sync,
}


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Return the list of available Neuroloom tools."""
    return TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Dispatch an incoming tool call to the appropriate handler.

    In HTTP transport mode, retrieves the per-request bearer token from the
    request context and injects it into ``arguments`` so tool handlers pass
    it to NeuroloomAPIClient. In stdio mode the token is None and tool
    handlers fall back to ``settings.memories_api_token``.
    """
    # ---------------------------------------------------------------------------
    # Token passthrough for HTTP mode
    #
    # The auth middleware (auth.py, Phase 2) stores the validated bearer token in
    # request.state.api_token. The MCP SDK propagates the Starlette Request into
    # RequestContext.request via the same ASGI scope dict. We retrieve it here and
    # inject it into arguments so tool handlers create NeuroloomAPIClient(token=token).
    #
    # server.request_context.request is typed as RequestT | None. We guard against
    # None (occurs in stdio mode or before middleware sets state).
    # ---------------------------------------------------------------------------
    token: Optional[str] = get_request_token()  # ContextVar path (set by middleware)

    # Inject the token so tool handlers can pass it to NeuroloomAPIClient.
    # Tools that accept a `token` keyword argument will use it; others ignore it.
    # We set it in arguments here rather than modifying each tool signature so
    # the tool dispatch remains generic.
    if token:
        arguments = {**arguments, "_request_token": token}

    handler = _TOOL_DISPATCH.get(name)

    if handler is None:
        result: dict[str, Any] = {"error": f"Unknown tool: {name}"}
    else:
        # Filter arguments to only the parameters the handler accepts.
        # LLMs may inject extra keys (e.g. "summary") that the tool function
        # does not declare. Passing them causes a TypeError; strip them here
        # and log a warning so unexpected keys are visible but not fatal.
        sig = inspect.signature(handler)
        has_var_keyword = any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
        )
        if not has_var_keyword:
            accepted = set(sig.parameters.keys())
            stripped = {k: v for k, v in arguments.items() if k not in accepted}
            if stripped:
                logger.warning(
                    "Tool %s: stripping unexpected argument(s) from client: %s",
                    name,
                    sorted(stripped.keys()),
                )
            arguments = {k: v for k, v in arguments.items() if k in accepted}

        try:
            result = await handler(**arguments)
        except Exception as exc:
            logger.exception("Tool %s raised an unexpected error: %s", name, exc)
            settings = get_settings()
            if settings.mcp_transport == "http":
                result = {"error": "Internal server error"}
            else:
                result = {"error": str(exc)}

    return [
        TextContent(
            type="text",
            text=json.dumps(result, indent=2, default=str),
        )
    ]


# ---------------------------------------------------------------------------
# RFC 9728 protected resource metadata handler
# ---------------------------------------------------------------------------


async def oauth_protected_resource_handler(request: Request) -> JSONResponse:
    """RFC 9728 protected resource metadata.

    Signals to OAuth-aware MCP clients that this server accepts Bearer tokens
    directly (no OAuth authorization server is involved). The empty
    authorization_servers list tells clients there is no OAuth flow to initiate.

    The resource field is the MCP server's own public URL — not the Neuroloom
    API URL. The Neuroloom API is a resource server, not an OAuth authorization
    server, and must not appear in authorization_servers.
    """
    settings = get_settings()
    return JSONResponse(
        {
            "resource": settings.memories_mcp_public_url,
            "authorization_servers": [],
            "bearer_methods_supported": ["header"],
        }
    )


# ---------------------------------------------------------------------------
# JSON 404 handler
# ---------------------------------------------------------------------------


async def json_404_handler(request: Request, exc: Exception) -> JSONResponse:
    """Return a JSON 404 response for any unmatched path.

    Replaces Starlette's default HTML 404 page. Registered via
    exception_handlers={404: json_404_handler} on the Starlette app so that
    any path reaching routing without matching a registered route returns
    application/json instead of text/html. This prevents MCP client JSON
    parsers from crashing on discovery probes that hit unregistered paths.
    """
    return JSONResponse({"error": "not_found", "path": request.url.path}, status_code=404)


# ---------------------------------------------------------------------------
# Health check handler
# ---------------------------------------------------------------------------


async def health_handler(request: Request) -> JSONResponse:
    """Return server health status.

    This endpoint is unauthenticated — the auth middleware (Phase 2) must
    bypass requests to /health. It is used by Railway as the health check
    path and can be polled externally to confirm the server is running.
    """
    return JSONResponse({"status": "ok", "version": __version__})


# ---------------------------------------------------------------------------
# HTTP app factory
# ---------------------------------------------------------------------------


def create_http_app() -> Starlette:
    """Create and return the Starlette ASGI application for HTTP transport mode.

    This function is the uvicorn ``--factory`` entry point:

        uvicorn neuroloom_mcp.server:create_http_app --factory

    The function instantiates a ``StreamableHTTPSessionManager`` with
    ``stateless=True`` — each MCP client request gets a fresh transport with
    no session-affinity requirement. This is the deliberate design for Railway's
    single-instance deployment model; if horizontal scaling is needed later, the
    stateless mode means no sticky-session configuration is required.

    Routes:
        /mcp     — MCP protocol endpoint (POST, handled by StreamableHTTPSessionManager)
        /health  — Unauthenticated health check (GET)
    """
    from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
    from starlette.middleware import Middleware
    from starlette.routing import Route
    from starlette.types import Receive, Scope, Send

    from neuroloom_mcp.auth import APIKeyAuthMiddleware

    # stateless=True: fresh transport per request, no session tracking.
    # Correct for Railway single-instance; eliminates session-affinity requirements.
    session_manager = StreamableHTTPSessionManager(app=server, stateless=True)

    # Starlette's Route inspects the endpoint to decide how to call it:
    # - Functions/methods (inspect.ismethod → True): wrapped with
    #   request_response(), called as f(request) → Response.
    # - Class instances with __call__: treated as ASGI apps, called as
    #   app(scope, receive, send).
    # session_manager.handle_request is a bound method but expects ASGI
    # (scope, receive, send) — not a Request object. Wrapping it in a
    # class instance ensures Starlette dispatches it correctly.
    #
    # A plain async def is a function object — inspect.isfunction returns True,
    # so Starlette wraps it with request_response() and calls it as
    # f(request) -> Response instead of f(scope, receive, send). A class
    # instance with __call__ bypasses those checks and is called directly as
    # an ASGI app.
    class _McpAsgiEndpoint:
        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
            await session_manager.handle_request(scope, receive, send)

    mcp_endpoint = _McpAsgiEndpoint()

    @contextlib.asynccontextmanager
    async def lifespan(app: Starlette) -> AsyncIterator[None]:
        """Manage session manager lifecycle and run startup validation."""
        await _validate_startup_http()
        async with session_manager.run():
            logger.info("neuroloom-mcp v%s HTTP server ready", __version__)
            yield

    return Starlette(
        routes=[
            # Discovery and health routes come BEFORE /mcp so they are matched
            # first. /.well-known/oauth-protected-resource must be reachable
            # without authentication — see APIKeyAuthMiddleware.__call__ for
            # the bypass rationale.
            Route(
                "/.well-known/oauth-protected-resource",
                endpoint=oauth_protected_resource_handler,
                methods=["GET"],
            ),
            Route("/health", endpoint=health_handler, methods=["GET"]),
            # Route (not Mount) — exact-path match with no trailing-slash
            # redirect. Mount("/mcp") issues a 307 redirect to /mcp/ which
            # strips the Authorization header per RFC 7231, causing 401.
            # Endpoint is a class instance (not a bound method) so Starlette
            # treats it as an ASGI app and calls it with (scope, receive, send).
            Route("/mcp", endpoint=mcp_endpoint),
        ],
        lifespan=lifespan,
        middleware=[Middleware(APIKeyAuthMiddleware)],
        exception_handlers={404: json_404_handler},
    )


# ---------------------------------------------------------------------------
# Startup validation
# ---------------------------------------------------------------------------


async def _validate_startup() -> None:
    """Verify API connectivity and token validity before accepting stdio requests.

    Exits with code 1 on authentication failure, missing workspace, or
    an unreachable API so that misconfigured servers fail fast with a
    helpful error message rather than silently returning errors on every call.
    """
    settings = get_settings()

    try:
        async with NeuroloomAPIClient() as client:
            await client.list_workspaces()

            if settings.workspace_id:
                await client.get_workspace(settings.workspace_id)

    except APIError as e:
        if e.status_code == 401:
            logger.error("Authentication failed: invalid MEMORIES_API_TOKEN")
            logger.error("Generate a new API key at https://app.neuroloom.dev/settings/api-keys")
        elif e.status_code == 404:
            logger.error("Workspace not found: %s", settings.workspace_id)
            logger.error("Check MEMORIES_WORKSPACE_ID in your configuration.")
        elif e.status_code in (503, 408):
            logger.error("Cannot reach API at %s", settings.memories_api_url)
            logger.error("Check MEMORIES_API_URL and network connectivity.")
        else:
            logger.error("API error during startup validation: %s", e)
        sys.exit(1)


async def _validate_startup_http() -> None:
    """Verify API reachability for HTTP transport mode startup.

    In HTTP mode per-client tokens handle authentication — no server-level
    MEMORIES_API_TOKEN is needed. This check only confirms the upstream API
    is reachable; it does not attempt authenticated calls.

    Exits with code 1 if the API cannot be reached, so misconfigured servers
    fail fast during Railway deployment rather than silently returning 503s.
    """
    settings = get_settings()

    try:
        # Use NeuroloomAPIClient with no token — _build_headers() skips the
        # Authorization header when token is None/empty, making this an
        # unauthenticated reachability probe.
        async with NeuroloomAPIClient(token=None) as client:
            # Attempt to reach a lightweight endpoint; a 401 is fine here —
            # it confirms the API is up and responding. Only connection errors
            # and 5xx/timeout responses indicate an unreachable API.
            try:
                await client.list_workspaces()
            except APIError as e:
                if e.status_code in (401, 403):
                    # API responded — it's reachable. Auth is per-client in HTTP mode.
                    logger.info(
                        "API reachable at %s (auth probe returned %s — expected in HTTP mode)",
                        settings.memories_api_url,
                        e.status_code,
                    )
                    return
                elif e.status_code in (503, 408):
                    raise
                else:
                    # Other API errors (4xx) still mean the API is responding.
                    logger.info(
                        "API reachable at %s (probe returned %s)",
                        settings.memories_api_url,
                        e.status_code,
                    )
                    return

        logger.info("API reachable at %s", settings.memories_api_url)

    except APIError as e:
        if e.status_code in (503, 408):
            logger.error("Cannot reach API at %s", settings.memories_api_url)
            logger.error("Check MEMORIES_API_URL and network connectivity.")
            sys.exit(1)
    except Exception as exc:
        logger.error(
            "Unexpected error during HTTP startup validation: %s",
            exc,
            exc_info=True,
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Validation CLI command
# ---------------------------------------------------------------------------


async def _run_validation() -> bool:
    """Run a human-readable configuration and connectivity check.

    This command is intended for stdio mode only. In HTTP mode, per-client
    tokens are used; the validate command does not apply.
    """
    from pydantic import ValidationError

    print("\n" + "=" * 60)
    print("  Neuroloom MCP Configuration Validator")
    print("=" * 60 + "\n")

    all_passed = True

    print("1. Checking environment variables...")
    try:
        settings = get_settings()

        # Guard: validate subcommand is stdio-only.
        if settings.mcp_transport == "http":
            print("   INFO  MCP_TRANSPORT=http detected.")
            print("         The 'validate' command is for stdio mode only.")
            print("         In HTTP mode, each MCP client provides their own API key.")
            print("         Use: curl https://<host>/health to check server reachability.")
            return False

        print(f"   OK  MEMORIES_API_URL: {settings.memories_api_url}")
        api_token = settings.memories_api_token or ""
        token_preview = f"{'*' * 8}...{api_token[-4:]}" if len(api_token) > 4 else "****"
        print(f"   OK  MEMORIES_API_TOKEN: {token_preview}")
        print(f"   OK  MEMORIES_WORKSPACE_ID: {settings.memories_workspace_id}")
    except (ValidationError, ValueError) as exc:
        print(f"   FAIL  Configuration error: {exc}")
        return False

    print("\n2. Testing API connectivity...")
    try:
        async with NeuroloomAPIClient() as client:
            try:
                workspaces = await client.list_workspaces()
                settings = get_settings()
                print(f"   OK  API reachable at {settings.memories_api_url}")
                print(f"   OK  Token valid ({len(workspaces)} workspace(s) accessible)")
            except APIError as e:
                if e.status_code == 401:
                    print("   FAIL  Authentication failed: invalid MEMORIES_API_TOKEN")
                elif e.status_code in (503, 408):
                    print(f"   FAIL  Cannot reach API: {e.message}")
                else:
                    print(f"   FAIL  API error: {e.message}")
                all_passed = False
                return all_passed

            settings = get_settings()
            if all_passed and settings.workspace_id:
                print("\n3. Validating workspace...")
                try:
                    workspace = await client.get_workspace(settings.workspace_id)
                    print(f"   OK  Workspace found: {workspace.get('name', 'Unknown')}")
                    print(f"   OK  Workspace slug: {workspace.get('slug', 'Unknown')}")
                except APIError as e:
                    if e.status_code == 404:
                        print(f"   FAIL  Workspace not found: {settings.workspace_id}")
                        print("         Check MEMORIES_WORKSPACE_ID in your configuration.")
                    else:
                        print(f"   FAIL  Error checking workspace: {e.message}")
                    all_passed = False

    except Exception as exc:
        print(f"   FAIL  Unexpected error: {exc}")
        all_passed = False

    print("\n" + "=" * 60)
    if all_passed:
        print("  All validations passed — MCP server is ready to connect.")
    else:
        print("  Validation failed. Fix the issues above before connecting.")
    print("=" * 60 + "\n")

    return all_passed


# ---------------------------------------------------------------------------
# Server runner
# ---------------------------------------------------------------------------


async def _serve() -> None:
    """Start the MCP server on stdio."""
    settings = get_settings()

    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s  %(name)s  %(levelname)s  %(message)s",
    )

    logger.info("Starting neuroloom-mcp v%s", __version__)

    await _validate_startup()
    logger.info("API connection validated — server starting")

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


# ---------------------------------------------------------------------------
# Plugin installer
# ---------------------------------------------------------------------------


def _install_plugin(args: argparse.Namespace) -> None:
    """Install the Neuroloom plugin into Claude Code's plugin directory."""
    if sys.platform == "win32":
        raise SystemExit(
            "Windows is not supported. The Neuroloom plugin requires a Unix environment."
        )

    target_dir = (
        Path(args.plugin_dir)
        if args.plugin_dir
        else Path.home() / ".claude" / "plugins" / "neuroloom"
    )

    if target_dir.exists() and not args.force:
        print(f"Plugin already installed at {target_dir}. Run with --force to overwrite.", file=sys.stderr)
        return

    try:
        overwrite = target_dir.exists()
        if overwrite:
            shutil.rmtree(target_dir)

        with as_file(files("neuroloom_mcp").joinpath("plugin")) as src_path:
            if args.link:
                target_dir.parent.mkdir(parents=True, exist_ok=True)
                target_dir.symlink_to(src_path.resolve())
                print(f"Neuroloom plugin linked at {target_dir} -> {src_path.resolve()}", file=sys.stderr)
                print(
                    "Restart Claude Code to activate. Note: if you delete the virtual"
                    " environment, re-run install-plugin.",
                    file=sys.stderr,
                )
            else:
                target_dir.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(src_path, target_dir)
                # Restore executable bits on shell scripts (wheels don't preserve Unix permissions)
                for sh_file in target_dir.rglob("*.sh"):
                    sh_file.chmod(sh_file.stat().st_mode | 0o111)
                if overwrite:
                    print(f"Replaced existing plugin at {target_dir}", file=sys.stderr)
                else:
                    print(f"Neuroloom plugin installed at {target_dir}", file=sys.stderr)
                print("Restart Claude Code to activate.", file=sys.stderr)

        # Write version marker for upgrade detection (copy mode only)
        if not args.link:
            version_file = target_dir / ".version"
            version_file.write_text(__version__)

    except OSError as exc:
        print(
            f"Could not write to {target_dir}: {exc}."
            " Try running with --plugin-dir to choose a writable location.",
            file=sys.stderr,
        )
        raise SystemExit(1) from None

    # Non-blocking API key reminder (printed after every successful install path)
    print(
        "Set your API key with: /plugins configure neuroloom",
        file=sys.stderr,
    )


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point registered as ``neuroloom-mcp`` in pyproject.toml."""
    parser = argparse.ArgumentParser(
        description="Neuroloom MCP Server — knowledge graph tools for Claude Code"
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"neuroloom-mcp {__version__}",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default=None,
        help=(
            "Transport mode: 'stdio' (default, local subprocess) or 'http' (hosted ASGI). "
            "Overridden by MCP_TRANSPORT environment variable."
        ),
    )

    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("serve", help="Start the MCP server (default)")
    subparsers.add_parser(
        "validate",
        help="Validate configuration and API connectivity without starting the server (stdio mode only)",
    )
    install_parser = subparsers.add_parser(
        "install-plugin", help="Install Neuroloom plugin into Claude Code"
    )
    install_parser.add_argument(
        "--force", action="store_true", help="Overwrite existing installation"
    )
    install_parser.add_argument(
        "--link",
        action="store_true",
        help="Symlink instead of copy (for development)",
    )
    install_parser.add_argument(
        "--plugin-dir",
        type=str,
        default=None,
        help="Override target directory (for testing)",
    )

    args = parser.parse_args()

    # Resolve transport: env var takes precedence over CLI flag, CLI flag over
    # the Settings default. We read settings first to get the env-configured value.
    settings = get_settings()
    transport = settings.mcp_transport  # from MCP_TRANSPORT env var or default "stdio"
    if args.transport is not None:
        # CLI flag was explicitly provided — honour it, but env var still wins.
        # Re-read settings if the CLI flag differs so lru_cache is not stale.
        # In practice the env var is the Railway mechanism; CLI flag is for local testing.
        transport = args.transport

    if args.command == "install-plugin":
        _install_plugin(args)
        return

    # Nudge if the Claude Code plugin is not installed — non-blocking, server starts regardless.
    # Print to stderr so this never contaminates the stdio MCP protocol channel on stdout.
    # Gated to serve/validate so install-plugin users don't see "not installed" right before installing.
    plugin_dir = Path.home() / ".claude" / "plugins" / "neuroloom"
    if not plugin_dir.exists():
        print(
            "# Neuroloom plugin not installed. Run: neuroloom-mcp install-plugin",
            file=sys.stderr,
        )

    if args.command == "validate":
        success = asyncio.run(_run_validation())
        sys.exit(0 if success else 1)
    elif transport == "http":
        import uvicorn

        logging.basicConfig(
            level=getattr(logging, settings.log_level.upper(), logging.INFO),
            format="%(asctime)s  %(name)s  %(levelname)s  %(message)s",
        )
        logger.info(
            "Starting neuroloom-mcp v%s in HTTP mode on %s:%s",
            __version__,
            settings.mcp_host,
            settings.mcp_port,
        )
        # uvicorn.run() is synchronous and manages its own event loop internally.
        # Do NOT wrap in asyncio.run().
        uvicorn.run(
            "neuroloom_mcp.server:create_http_app",
            factory=True,
            host=settings.mcp_host,
            port=settings.mcp_port,
            log_level=settings.log_level.lower(),
        )
    else:
        # Default: stdio
        asyncio.run(_serve())


if __name__ == "__main__":
    main()
