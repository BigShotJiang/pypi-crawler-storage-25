"""
Configuration for the Neuroloom MCP Server.

Uses pydantic-settings for environment variable management.

Environment Variables:
    MEMORIES_API_URL: Base URL for the Neuroloom API
    MEMORIES_API_TOKEN: Authentication token (API key) for the Neuroloom API
    MEMORIES_WORKSPACE_ID: Default workspace ID for memory operations
    MEMORIES_MCP_PUBLIC_URL: Public URL of this MCP server (HTTP mode only)
    MCP_TRANSPORT: Transport mode — "stdio" (default) or "http"
    MCP_HOST: Host to bind when MCP_TRANSPORT=http (default "0.0.0.0")
    MCP_PORT: Port to listen on when MCP_TRANSPORT=http (default 8000)
"""

import warnings
from contextvars import ContextVar
from functools import lru_cache
from typing import Optional

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# ---------------------------------------------------------------------------
# Per-request token ContextVar
#
# In HTTP transport mode the auth middleware (auth.py) stores the validated
# bearer token here before dispatching the request. Tool handlers read it via
# get_request_token() to pass a per-request credential to NeuroloomAPIClient
# instead of reading the server-level MEMORIES_API_TOKEN setting.
#
# In stdio mode this ContextVar is never written and get_request_token()
# returns None, so NeuroloomAPIClient falls back to settings.memories_api_token.
# ---------------------------------------------------------------------------

_request_api_token: ContextVar[Optional[str]] = ContextVar("_request_api_token", default=None)


def get_request_token() -> Optional[str]:
    """Return the per-request bearer token set by the auth middleware.

    Returns None in stdio mode (no middleware) or when called outside a
    request context. Tools should pass this to NeuroloomAPIClient(token=...).
    """
    return _request_api_token.get()


class Settings(BaseSettings):
    """Neuroloom MCP Server configuration.

    All settings are read directly from environment variables with no prefix.

    Example .env (stdio mode):
        MEMORIES_API_URL=https://api.neuroloom.dev
        MEMORIES_API_TOKEN=your_api_key_here
        MEMORIES_WORKSPACE_ID=982b8330-a152-4726-8de0-2255e99d91c7

    Example .env (http mode):
        MEMORIES_API_URL=https://api.neuroloom.dev
        MCP_TRANSPORT=http
        MCP_HOST=0.0.0.0
        MCP_PORT=8000
        # MEMORIES_API_TOKEN and MEMORIES_WORKSPACE_ID are NOT required in
        # http mode — each MCP client supplies their own bearer token.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Transport Configuration
    mcp_transport: str = Field(
        default="stdio",
        description='Transport mode: "stdio" (default, local) or "http" (hosted)',
    )
    mcp_host: str = Field(
        default="0.0.0.0",
        description="Host to bind in HTTP mode",
    )
    mcp_port: int = Field(
        default=8000,
        description="Port to listen on in HTTP mode",
    )

    # API Configuration
    memories_api_url: str = Field(
        default="https://api.neuroloom.dev",
        description="Base URL for the Neuroloom API",
    )
    memories_api_token: Optional[str] = Field(
        default=None,
        description=(
            "Authentication token (API key) for the Neuroloom API. "
            "Required in stdio mode. Not required in http mode — each MCP client "
            "provides their own bearer token."
        ),
    )
    memories_mcp_public_url: Optional[str] = Field(
        default=None,
        description=(
            "Public URL of this MCP server (e.g. https://mcp.neuroloom.dev/mcp). "
            "Required in HTTP mode — used as the RFC 9728 'resource' field in "
            "/.well-known/oauth-protected-resource responses. "
            "Not required in stdio mode."
        ),
    )

    # Workspace Configuration
    memories_workspace_id: Optional[str] = Field(
        default=None,
        description=(
            "Default workspace ID for memory operations. "
            "Required in stdio mode. Not required in http mode — workspace is "
            "resolved per-client from their API token."
        ),
    )

    @property
    def workspace_id(self) -> Optional[str]:
        """Convenience accessor for the workspace ID."""
        return self.memories_workspace_id

    @model_validator(mode="after")
    def validate_required_config(self) -> "Settings":
        """Validate that required configuration is present.

        In http mode, MEMORIES_API_TOKEN and MEMORIES_WORKSPACE_ID are optional
        because each MCP client authenticates with their own bearer token.

        In stdio mode, both fields are required for the server to function.

        Raises:
            ValueError: If required configuration is missing in stdio mode.
        """
        if self.mcp_transport == "http":
            # HTTP mode: per-client tokens handle auth; server-level token not needed.
            if not self.memories_mcp_public_url:
                raise ValueError(
                    "MEMORIES_MCP_PUBLIC_URL is required in HTTP mode. "
                    "Set it to the public URL of this MCP server "
                    "(e.g. MEMORIES_MCP_PUBLIC_URL=https://mcp.neuroloom.dev/mcp)."
                )
            if not self.memories_mcp_public_url.startswith("https://"):
                warnings.warn(
                    "MEMORIES_MCP_PUBLIC_URL does not start with https:// — "
                    "RFC 9728 requires HTTPS for protected resource metadata.",
                    stacklevel=2,
                )
            return self

        # stdio mode: require token and workspace ID.
        errors: list[str] = []

        if not self.memories_api_token:
            errors.append(
                "MEMORIES_API_TOKEN is required. "
                "Generate one from the Neuroloom dashboard under Settings > API Keys."
            )

        if not self.memories_workspace_id:
            errors.append(
                "MEMORIES_WORKSPACE_ID is required. "
                "Find your workspace ID in the Neuroloom dashboard under Settings > Workspaces."
            )

        if errors:
            raise ValueError(
                "Neuroloom MCP configuration errors:\n" + "\n".join(f"  - {e}" for e in errors)
            )

        return self

    # Search Defaults
    default_search_limit: int = Field(
        default=10,
        description="Default number of search results",
    )
    max_search_limit: int = Field(
        default=100,
        description="Maximum number of search results",
    )

    # Context Injection
    max_context_memories: int = Field(
        default=10,
        description="Maximum memories to inject on session start",
    )

    # Logging
    log_level: str = Field(
        default="INFO",
        description="Logging level",
    )


@lru_cache
def get_settings() -> Settings:
    """Return a cached Settings instance."""
    return Settings()
