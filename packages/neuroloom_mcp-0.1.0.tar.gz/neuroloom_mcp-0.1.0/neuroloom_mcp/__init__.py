"""neuroloom_mcp — MCP server package for the Neuroloom knowledge graph API."""

__version__ = "0.1.0"
