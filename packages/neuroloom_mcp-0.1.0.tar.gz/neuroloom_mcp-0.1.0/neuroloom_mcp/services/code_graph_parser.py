"""
Backwards-compatibility re-export.

The parser implementation has moved to the `codeweaver` package.
Import from `codeweaver` directly in new code:

    from codeweaver import parse_files, discover_files
"""

from codeweaver import discover_files, parse_files

__all__ = ["discover_files", "parse_files"]
