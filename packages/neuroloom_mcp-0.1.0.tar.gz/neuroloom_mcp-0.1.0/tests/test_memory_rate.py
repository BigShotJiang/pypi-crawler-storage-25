"""
Tests for the memory_rate MCP tool function.

All HTTP calls are mocked at the NeuroloomAPIClient level. No real API is called.

Coverage:
  - memory_rate success (useful=true) returns {"status": "recorded", ...}
  - memory_rate success with optional context parameter
  - memory_rate when the API raises APIError returns error dict, no exception raised
  - memory_rate when connection error occurs returns error dict, no exception raised
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from neuroloom_mcp.client import APIError
from neuroloom_mcp.tools.memory_tools import memory_rate


# ---------------------------------------------------------------------------
# Helper — duplicated from test_memory_tools.py to avoid cross-file import
# ---------------------------------------------------------------------------


def _make_client_mock(**method_returns):
    """Build a mock NeuroloomAPIClient async context manager.

    ``method_returns`` maps method names to return values or exceptions.
    Exceptions are configured as side_effect so the mock raises them.
    """
    mock = AsyncMock()
    for name, value in method_returns.items():
        if isinstance(value, Exception):
            getattr(mock, name).side_effect = value
        else:
            getattr(mock, name).return_value = value

    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=mock)
    ctx.__aexit__ = AsyncMock(return_value=False)
    return ctx, mock


# ---------------------------------------------------------------------------
# memory_rate — success paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_rate_useful_true_returns_recorded_status() -> None:
    """memory_rate with useful=True returns status='recorded' and echoes memory_id."""
    ctx, mock = _make_client_mock(rate_memory={"ok": True})

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_rate(memory_id="mem-abc123", useful=True)

    assert result["status"] == "recorded"
    assert result["memory_id"] == "mem-abc123"
    assert result["useful"] is True


@pytest.mark.asyncio
async def test_memory_rate_useful_false_returns_recorded_status() -> None:
    """memory_rate with useful=False returns status='recorded' and echoes useful=False."""
    ctx, mock = _make_client_mock(rate_memory={"ok": True})

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_rate(memory_id="mem-xyz789", useful=False)

    assert result["status"] == "recorded"
    assert result["memory_id"] == "mem-xyz789"
    assert result["useful"] is False


@pytest.mark.asyncio
async def test_memory_rate_with_context_passes_context_to_client() -> None:
    """memory_rate with context= calls client.rate_memory with the context argument."""
    ctx, mock = _make_client_mock(rate_memory={"ok": True})

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_rate(
            memory_id="mem-ctx001",
            useful=True,
            context="This pattern was directly applicable.",
        )

    assert result["status"] == "recorded"
    mock.rate_memory.assert_awaited_once_with(
        memory_id="mem-ctx001",
        useful=True,
        context="This pattern was directly applicable.",
    )


@pytest.mark.asyncio
async def test_memory_rate_without_context_calls_client_with_none() -> None:
    """memory_rate without context= passes context=None to client.rate_memory."""
    ctx, mock = _make_client_mock(rate_memory={"ok": True})

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_rate(memory_id="mem-noctx", useful=True)

    assert result["status"] == "recorded"
    mock.rate_memory.assert_awaited_once_with(
        memory_id="mem-noctx",
        useful=True,
        context=None,
    )


# ---------------------------------------------------------------------------
# memory_rate — error paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_rate_api_error_returns_error_dict_no_exception() -> None:
    """memory_rate returns an error dict when the API raises APIError; does not raise."""
    ctx, _ = _make_client_mock(rate_memory=APIError(404, "Memory not found"))

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_rate(memory_id="mem-missing", useful=True)

    assert "error" in result
    assert result["memory_id"] == "mem-missing"
    # Must not contain 'status' key (that would indicate success)
    assert result.get("status") != "recorded"


@pytest.mark.asyncio
async def test_memory_rate_api_error_500_returns_error_dict() -> None:
    """memory_rate returns error dict on 500 APIError."""
    ctx, _ = _make_client_mock(rate_memory=APIError(500, "Internal server error"))

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_rate(memory_id="mem-err500", useful=False)

    assert "error" in result
    assert result["memory_id"] == "mem-err500"


@pytest.mark.asyncio
async def test_memory_rate_connection_error_returns_error_dict_no_exception() -> None:
    """memory_rate returns error dict when a network ConnectionError occurs; does not raise."""
    ctx, _ = _make_client_mock(
        rate_memory=ConnectionError("Failed to connect to Neuroloom API")
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_rate(memory_id="mem-offline", useful=True)

    assert "error" in result
    assert result["memory_id"] == "mem-offline"


@pytest.mark.asyncio
async def test_memory_rate_timeout_error_returns_error_dict() -> None:
    """memory_rate returns error dict on TimeoutError; does not raise."""
    import asyncio

    ctx, _ = _make_client_mock(rate_memory=asyncio.TimeoutError())

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_rate(memory_id="mem-timeout", useful=True)

    assert "error" in result
    assert result["memory_id"] == "mem-timeout"
