"""
Integration tests for the real ``create_http_app()`` factory.

Purpose
-------
The existing test suite in ``test_auth.py`` tests the auth middleware against a
hand-built Starlette app (``_build_test_app()``). That design intentionally
avoids ``create_http_app()`` because the lifespan calls ``_validate_startup_http()``
which makes a real network call.

The cost of that isolation: two production bugs shipped undetected because the
stub app masked real wiring issues in the factory:

1. **405 on POST /mcp** — Starlette's ``Route`` defaults bound methods to
   GET-only via ``inspect.ismethod()``. The stub handler was a plain function,
   so the method restriction was invisible.
2. **500 TypeError on POST /mcp** — Starlette wraps bound methods with
   ``request_response()``, calling them as ``f(request)`` instead of
   ``f(scope, receive, send)``. The stub didn't expose this wiring mismatch.

These tests MUST use the real ``create_http_app()`` output to catch any future
mismatches between the factory and test fixture assumptions.

Section 1: App factory route wiring tests
    Uses ``starlette.testclient.TestClient`` (sync-over-async) against the real
    app. ``_validate_startup_http`` is mocked with ``unittest.mock.patch`` to
    avoid the network call. The patch must be active during both ``create_http_app()``
    and ``TestClient.__enter__()`` because the lifespan closure resolves
    ``_validate_startup_http`` by name from the module namespace when it runs.

Section 2: MCP protocol client tests (emulating Claude Code)
    Uses ``httpx.AsyncClient`` with ``ASGITransport`` to run the real app
    in-process, then connects the MCP SDK's ``streamable_http_client`` via an
    ``httpx.AsyncClient`` with the ASGI transport injected. These tests verify
    the MCP initialize handshake works end-to-end without a real server socket
    or real Neuroloom API.

Mock policy
-----------
- ``_validate_startup_http`` — always mocked: it's a network call to the
  Neuroloom API which is external and unavailable in CI.
- ``APIKeyAuthMiddleware._validate_token`` — mocked where needed to control
  auth outcomes without a real upstream API.
- Nothing else is mocked. The real Starlette routing, real ``_McpAsgiEndpoint``
  ASGI dispatch, and real ``StreamableHTTPSessionManager`` all execute normally.

Critical fixture patterns
-------------------------
Section 1 — The ``_validate_startup_http`` patch must remain active from app
creation through ``TestClient.__enter__()`` lifespan execution. Exiting the
patch context before the client enters causes ``sys.exit(1)`` in the lifespan.

Section 2 — The lifespan uses ``anyio.create_task_group()`` internally, which
is task-local: it must be entered AND exited in the same asyncio Task. When
pytest-asyncio yields control between fixture setup and teardown, the cancel
scope can end up in a different task, causing:
    RuntimeError: Attempted to exit cancel scope in a different task than it
    was entered in

The fix: run the lifespan in a dedicated background ``asyncio.Task`` via
``asyncio.create_task()``. The fixture coordinates with the task using
``asyncio.Event``: one event signals "lifespan is ready", another signals
"test is done, begin shutdown". This keeps the cancel scope entirely within
the background task's execution context.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from unittest.mock import AsyncMock, patch

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client
from mcp.types import Implementation
from starlette.applications import Starlette
from starlette.testclient import TestClient


# ---------------------------------------------------------------------------
# Helpers: mock factories
# ---------------------------------------------------------------------------


def _make_valid_token_mock() -> AsyncMock:
    """Return a mock for ``APIKeyAuthMiddleware._validate_token`` that always
    reports a valid token.

    Signature matches the real method: returns ``(valid: bool, upstream_error: bool)``.
    """
    return AsyncMock(return_value=(True, False))


def _make_invalid_token_mock() -> AsyncMock:
    """Return a mock that always reports an invalid token (401 path)."""
    return AsyncMock(return_value=(False, False))


# ---------------------------------------------------------------------------
# Section 1: App factory route wiring tests
# ---------------------------------------------------------------------------


class TestAppFactoryRoutingWiring:
    """Verify that create_http_app() produces a correctly-wired ASGI app.

    These are regression tests for the D15 post-ship bugs. Each test uses
    the REAL factory output; none use hand-built stub apps.

    Fixture pattern: each test creates its own TestClient inside the
    ``_validate_startup_http`` patch context. The patch must remain active
    through ``TestClient.__enter__`` because the lifespan closure calls
    ``_validate_startup_http`` by name at lifespan startup time, not at
    ``create_http_app()`` call time.

    Auth strategy: POST /mcp requests without a token get 401 from the auth
    middleware — that proves routing worked (the request reached the middleware).
    Tests that need to see the MCP layer mock ``_validate_token`` to return
    success.
    """

    def test_post_mcp_does_not_return_405(self) -> None:
        """POST /mcp must NOT return 405 Method Not Allowed.

        D15 bug 1: Starlette's Route defaults bound methods to GET-only via
        ``inspect.ismethod()``. The fix wraps ``session_manager.handle_request``
        in a class instance (``_McpAsgiEndpoint``) so Starlette treats it as an
        ASGI app, not a bound method. This test will catch any regression to the
        bound-method approach.

        Without a token, the middleware returns 401. 401 proves the request
        reached the auth middleware without being rejected at the routing layer.
        The absence of 405 proves Route accepted POST.
        """
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            with TestClient(app, raise_server_exceptions=False) as client:
                response = client.post(
                    "/mcp",
                    json={"jsonrpc": "2.0", "method": "initialize", "id": 1},
                )

        assert response.status_code != 405, (
            "POST /mcp returned 405 Method Not Allowed. "
            "This is the D15 regression: Route accepted the bound method "
            "signature and restricted it to GET only. "
            "Ensure _McpAsgiEndpoint wraps handle_request."
        )

    def test_post_mcp_does_not_return_500_type_error(self) -> None:
        """POST /mcp must NOT return 500 due to a TypeError from wrong call convention.

        D15 bug 2: Starlette's ``request_response()`` wraps the endpoint and
        calls it as ``f(request)``, but ``handle_request`` expects ASGI
        ``(scope, receive, send)``. This causes:
            TypeError: handle_request() missing 2 required positional arguments:
            'receive' and 'send'
        The fix is ``_McpAsgiEndpoint``.

        ``raise_server_exceptions=False`` captures the 500 status rather than
        re-raising the TypeError in the test process.
        """
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            with TestClient(app, raise_server_exceptions=False) as client:
                response = client.post(
                    "/mcp",
                    json={"jsonrpc": "2.0", "method": "initialize", "id": 1},
                )

        assert response.status_code != 500, (
            f"POST /mcp returned 500. Response body: {response.text!r}. "
            "This may be the D15 TypeError regression: handle_request() called "
            "as f(request) instead of f(scope, receive, send). "
            "Ensure _McpAsgiEndpoint.__call__ is the Route endpoint."
        )

    def test_post_mcp_without_token_returns_401_not_405_or_500(self) -> None:
        """POST /mcp without Authorization must return 401, not 405 or 500.

        This verifies the full middleware + routing path: the request reaches
        ``APIKeyAuthMiddleware`` (which returns 401 for a missing token) without
        being rejected at the routing layer (405) or crashing the ASGI wiring (500).

        401 proves: routing accepted POST, middleware ran, auth rejected.
        """
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            with TestClient(app, raise_server_exceptions=False) as client:
                response = client.post(
                    "/mcp",
                    json={"jsonrpc": "2.0", "method": "initialize", "id": 1},
                )

        assert response.status_code == 401, (
            f"Expected 401 (missing Bearer token) but got {response.status_code}. "
            f"Body: {response.text!r}"
        )
        body = response.json()
        assert body["error"] == "authentication_failed"

    def test_get_oauth_protected_resource_returns_200(self) -> None:
        """GET /.well-known/oauth-protected-resource must return 200 JSON.

        RFC 9728 metadata endpoint. Must be reachable without auth (the
        middleware bypasses all non-/mcp paths). Used by MCP clients during
        OAuth discovery; a 401 here triggers the OAuth flow which cannot
        succeed because we have no authorization server.
        """
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            # No context manager: lifespan is not needed for these route tests.
            client = TestClient(app, raise_server_exceptions=False)
            response = client.get("/.well-known/oauth-protected-resource")

        assert response.status_code == 200
        assert response.headers.get("content-type", "").startswith("application/json")

    def test_get_oauth_protected_resource_has_correct_fields(self) -> None:
        """/.well-known/oauth-protected-resource must contain RFC 9728 required fields."""
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            client = TestClient(app, raise_server_exceptions=False)
            response = client.get("/.well-known/oauth-protected-resource")

        assert response.status_code == 200
        body = response.json()

        assert "resource" in body, "Missing 'resource' field (required by RFC 9728)"
        assert body["resource"] == "https://mcp.test.local/mcp"
        assert body["authorization_servers"] == [], (
            "authorization_servers must be [] to signal direct Bearer token auth. "
            "A non-empty list tells clients to initiate OAuth, which cannot succeed."
        )
        assert body["bearer_methods_supported"] == ["header"]

    def test_get_health_returns_200(self) -> None:
        """GET /health must return 200 JSON with status ok.

        Health endpoint is unauthenticated (middleware bypasses non-/mcp paths).
        Used by Railway as the deployment health check.
        """
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            client = TestClient(app, raise_server_exceptions=False)
            response = client.get("/health")

        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "ok"
        assert "version" in body

    def test_unknown_path_returns_404_json_not_html(self) -> None:
        """GET on an unregistered path must return 404 JSON, not 404 HTML.

        Starlette's default 404 handler returns HTML. The ``json_404_handler``
        exception handler replaces it with ``application/json``. MCP clients that
        probe arbitrary paths during discovery must receive JSON so their parsers
        don't crash on an HTML error page.
        """
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            client = TestClient(app, raise_server_exceptions=False)
            response = client.get("/some/totally/unknown/path")

        assert response.status_code == 404
        content_type = response.headers.get("content-type", "")
        assert content_type.startswith("application/json"), (
            f"Expected application/json but got {content_type!r}. "
            "json_404_handler must be registered as exception_handlers[404]."
        )
        body = response.json()
        assert body["error"] == "not_found"
        assert "path" in body

    def test_discovery_route_matched_before_mcp_endpoint(self) -> None:
        """/.well-known/oauth-protected-resource must be matched by its own route.

        Route ordering in ``create_http_app()``: discovery routes are registered
        before ``/mcp``. This test verifies the well-known path is NOT swallowed by
        the ``/mcp`` ASGI endpoint handler, which would return a protocol error or
        fall through to 404 for an unrecognised path.

        A 200 response with RFC 9728 body proves the discovery route ran, not
        the MCP session manager.
        """
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            client = TestClient(app, raise_server_exceptions=False)
            response = client.get("/.well-known/oauth-protected-resource")

        assert response.status_code == 200
        body = response.json()
        # RFC 9728-specific fields prove our handler ran, not the MCP session manager
        assert "authorization_servers" in body
        assert "bearer_methods_supported" in body

    def test_post_mcp_with_valid_token_does_not_return_405_or_500(self) -> None:
        """POST /mcp with a token that passes auth must not return 405 or 500.

        Mocks ``_validate_token`` to return ``(True, False)`` so the auth
        middleware forwards the request to the MCP session manager. The session
        manager may return a protocol error (e.g. 406 for missing
        ``Accept: text/event-stream``), but 405 and 500 prove wiring breakage,
        not protocol errors.
        """
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            from neuroloom_mcp.server import create_http_app

            app = create_http_app()
            with patch(
                "neuroloom_mcp.auth.APIKeyAuthMiddleware._validate_token",
                new=_make_valid_token_mock(),
            ):
                with TestClient(app, raise_server_exceptions=False) as client:
                    response = client.post(
                        "/mcp",
                        json={"jsonrpc": "2.0", "method": "initialize", "id": 1},
                        headers={
                            "Authorization": "Bearer valid-looking-token",
                            "Accept": "application/json, text/event-stream",
                        },
                    )

        assert response.status_code not in (405, 500), (
            f"POST /mcp returned {response.status_code} even with a mocked-valid token. "
            f"Body: {response.text!r}. "
            "405 = routing rejected POST. 500 = ASGI wiring error (TypeError regression)."
        )


# ---------------------------------------------------------------------------
# Section 2: MCP protocol client tests (emulating Claude Code)
# ---------------------------------------------------------------------------


@pytest.fixture()
async def real_app_running() -> AsyncIterator[Starlette]:
    """Async fixture: yield the real ASGI app with its lifespan running.

    The lifespan uses ``anyio.create_task_group()`` (via ``session_manager.run()``),
    which is task-local: entering and exiting must happen in the same asyncio Task.
    If we run the lifespan directly inside the fixture coroutine (using
    ``async with app.router.lifespan_context``), pytest-asyncio's teardown resumes
    in a different task context, causing:
        RuntimeError: Attempted to exit cancel scope in a different task than it
        was entered in

    Fix: spawn a dedicated background task that owns the lifespan from entry
    to exit. Two ``asyncio.Event`` objects coordinate:
    - ``_ready``: set by the background task once ``session_manager.run()`` has
      started and is ready to handle requests.
    - ``_shutdown``: set by the fixture teardown to signal the background task
      to exit cleanly.

    The ``_validate_startup_http`` patch must remain active inside the background
    task (where the lifespan actually runs), not just in the fixture coroutine.
    """
    with patch(
        "neuroloom_mcp.server._validate_startup_http",
        new=AsyncMock(return_value=None),
    ):
        from neuroloom_mcp.server import create_http_app

        app = create_http_app()

    _ready: asyncio.Event = asyncio.Event()
    _shutdown: asyncio.Event = asyncio.Event()

    async def _run_lifespan() -> None:
        """Background task: run lifespan start-to-finish in one task context."""
        with patch(
            "neuroloom_mcp.server._validate_startup_http",
            new=AsyncMock(return_value=None),
        ):
            async with app.router.lifespan_context(app):
                _ready.set()
                await _shutdown.wait()

    lifespan_task: asyncio.Task[None] = asyncio.create_task(_run_lifespan())
    await _ready.wait()

    try:
        yield app
    finally:
        _shutdown.set()
        await lifespan_task


class TestMcpProtocolClient:
    """Emulate what Claude Code does when connecting to the MCP server.

    These tests use the MCP SDK's ``streamable_http_client`` with an
    ``httpx.AsyncClient`` backed by ``ASGITransport``. No real TCP socket or
    uvicorn process is involved — all HTTP traffic runs in-process against the
    real Starlette app.

    Why in-process rather than a real server?
    - Deterministic: no port conflicts, no timing races, no bind errors in CI.
    - Fast: no TCP handshake overhead.
    - Correct: still exercises the real Starlette routing + ASGI wiring.
    """

    async def test_oauth_discovery_flow_get_metadata(
        self, real_app_running: Starlette
    ) -> None:
        """Step 1 of Claude Code connection flow: GET /.well-known/oauth-protected-resource.

        Claude Code sends this probe before attempting any MCP call. It expects:
        - 200 status
        - ``authorization_servers: []`` (signals no OAuth flow needed)
        - ``bearer_methods_supported: ["header"]`` (signals header-based auth)

        Uses httpx directly (not the MCP client) because this is a plain
        HTTP discovery probe, not an MCP protocol call.
        """
        from httpx._transports.asgi import ASGITransport

        async with httpx.AsyncClient(
            transport=ASGITransport(app=real_app_running),
            base_url="http://testserver",
        ) as client:
            response = await client.get("/.well-known/oauth-protected-resource")

        assert response.status_code == 200
        body = response.json()
        assert body["authorization_servers"] == [], (
            "authorization_servers must be [] — non-empty triggers OAuth flow "
            "which cannot succeed because we have no authorization server."
        )
        assert body["bearer_methods_supported"] == ["header"]
        assert "resource" in body

    async def test_auth_rejection_without_token_returns_401_json(
        self, real_app_running: Starlette
    ) -> None:
        """POST /mcp without Authorization must return 401 JSON (not HTML, not crash).

        Verifies the auth middleware handles the no-token case cleanly against
        the real factory app. The response must be JSON because MCP clients
        parse the body.
        """
        from httpx._transports.asgi import ASGITransport

        async with httpx.AsyncClient(
            transport=ASGITransport(app=real_app_running),
            base_url="http://testserver",
        ) as client:
            response = await client.post(
                "/mcp",
                json={"jsonrpc": "2.0", "method": "initialize", "id": 1},
            )

        assert response.status_code == 401
        content_type = response.headers.get("content-type", "")
        assert content_type.startswith("application/json"), (
            f"401 body must be JSON but got content-type: {content_type!r}. "
            "MCP clients will fail to parse an HTML error page."
        )
        body = response.json()
        assert body["error"] == "authentication_failed"

    async def test_auth_rejection_with_bad_token_returns_401_json(
        self, real_app_running: Starlette
    ) -> None:
        """POST /mcp with an invalid Bearer token must return 401 JSON.

        Mocks ``_validate_token`` to return ``(False, False)`` — token invalid,
        no upstream error — which produces a clean 401. This verifies the
        invalid-token path works against the real factory app without needing
        a real API call.
        """
        from httpx._transports.asgi import ASGITransport

        with patch(
            "neuroloom_mcp.auth.APIKeyAuthMiddleware._validate_token",
            new=_make_invalid_token_mock(),
        ):
            async with httpx.AsyncClient(
                transport=ASGITransport(app=real_app_running),
                base_url="http://testserver",
            ) as client:
                response = await client.post(
                    "/mcp",
                    json={"jsonrpc": "2.0", "method": "initialize", "id": 1},
                    headers={"Authorization": "Bearer bad-token-xyz"},
                )

        assert response.status_code == 401
        body = response.json()
        assert body["error"] == "authentication_failed"

    async def test_mcp_initialize_handshake(
        self, real_app_running: Starlette
    ) -> None:
        """Full MCP initialize handshake via the real app, emulating Claude Code.

        Uses ``streamable_http_client`` with an in-process transport. Mocks
        ``_validate_token`` to return success so the middleware forwards the
        request to ``StreamableHTTPSessionManager``.

        The MCP ``initialize`` call establishes the session and returns server
        capabilities. A successful result proves:
        1. The real app routes POST /mcp to the session manager (not 405/500).
        2. The session manager handles the MCP protocol envelope correctly.
        3. The server reports its name and capabilities.
        """
        from httpx._transports.asgi import ASGITransport

        valid_token = "test-bearer-token-for-initialize"

        with patch(
            "neuroloom_mcp.auth.APIKeyAuthMiddleware._validate_token",
            new=_make_valid_token_mock(),
        ):
            http_client = httpx.AsyncClient(
                transport=ASGITransport(app=real_app_running),
                base_url="http://testserver",
                headers={"Authorization": f"Bearer {valid_token}"},
                timeout=httpx.Timeout(10.0),
                follow_redirects=True,
            )

            async with http_client:
                async with streamable_http_client(
                    "http://testserver/mcp",
                    http_client=http_client,
                    terminate_on_close=False,
                ) as (read_stream, write_stream, _get_session_id):
                    async with ClientSession(
                        read_stream,
                        write_stream,
                        client_info=Implementation(
                            name="test-client",
                            version="0.0.1",
                        ),
                    ) as session:
                        result = await session.initialize()

        # serverInfo uses camelCase per the MCP JSON-RPC spec (Pydantic model field)
        assert result.serverInfo.name == "neuroloom-mcp"
        assert result.capabilities is not None

    async def test_mcp_list_tools_returns_expected_tools(
        self, real_app_running: Starlette
    ) -> None:
        """After initialize, list_tools must return the 10 Neuroloom tools.

        Verifies the tool registry is correctly wired through the full MCP
        protocol stack, not just in the unit tests for the tool definitions.
        """
        from httpx._transports.asgi import ASGITransport

        valid_token = "test-bearer-token-for-list-tools"

        with patch(
            "neuroloom_mcp.auth.APIKeyAuthMiddleware._validate_token",
            new=_make_valid_token_mock(),
        ):
            http_client = httpx.AsyncClient(
                transport=ASGITransport(app=real_app_running),
                base_url="http://testserver",
                headers={"Authorization": f"Bearer {valid_token}"},
                timeout=httpx.Timeout(10.0),
                follow_redirects=True,
            )

            async with http_client:
                async with streamable_http_client(
                    "http://testserver/mcp",
                    http_client=http_client,
                    terminate_on_close=False,
                ) as (read_stream, write_stream, _):
                    async with ClientSession(
                        read_stream,
                        write_stream,
                        client_info=Implementation(
                            name="test-client",
                            version="0.0.1",
                        ),
                    ) as session:
                        await session.initialize()
                        tools_result = await session.list_tools()

        tool_names = {tool.name for tool in tools_result.tools}
        expected_tools = {
            "memory_search",
            "memory_get_detail",
            "memory_get_timeline",
            "memory_get_index",
            "memory_get_related",
            "memory_by_file",
            "memory_store",
            "session_start",
            "session_end",
            "session_get_context",
        }
        assert tool_names == expected_tools, (
            f"Tool registry mismatch. "
            f"Missing: {expected_tools - tool_names}. "
            f"Extra: {tool_names - expected_tools}."
        )
