"""
Tests for sdlc_seed_from_file in neuroloom_mcp.tools.document_tools.

Guard chain under test (9 steps):
  1. Stdio guard — returns 403 when transport is "http"
  2. Path validation — returns 422 for nonexistent / non-file paths
  3. Size guard — returns 422 when file exceeds 100 MB
  4. File read — returns 422 on OSError / UnicodeDecodeError
  5. JSON parse — returns 422 on invalid JSON
  6. Dict-type guard — returns 422 when root value is not an object
  7. Structure validation — returns 422 for missing/bad entries or version
  8. Entry-count ceiling — returns 422 when entries list exceeds 10,000
  9. Delegation — calls client.seed with correct args on success

Each test exercises exactly one guard.  Happy-path tests verify delegation
and token passthrough.
"""

from __future__ import annotations

import asyncio
import json
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from neuroloom_mcp.client import APIError
from neuroloom_mcp.tools.document_tools import sdlc_seed_from_file


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SAMPLE_SEED_RESPONSE = {
    "created": 3,
    "updated": 1,
    "unchanged": 0,
    "deprecated": 0,
}

VALID_PAYLOAD = {
    "version": "v2026-03-28",
    "entries": [
        {"title": "Test entry", "content": "Some guidance.", "knowledge_id": "test:entry"}
    ],
}


def _make_client_mock(**method_returns: object) -> tuple[MagicMock, AsyncMock]:
    """Build a mock NeuroloomAPIClient async context manager."""
    mock = AsyncMock()
    for name, value in method_returns.items():
        if isinstance(value, Exception):
            getattr(mock, name).side_effect = value
        else:
            getattr(mock, name).return_value = value

    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=mock)
    ctx.__aexit__ = AsyncMock(return_value=False)
    return ctx, mock


def _write_tmp(payload: object) -> Path:
    """Write a JSON payload to a named temporary file and return its Path."""
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    )
    json.dump(payload, tmp)
    tmp.close()
    return Path(tmp.name)


# ---------------------------------------------------------------------------
# Guard 1 — stdio transport guard
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_stdio_guard_blocks_http_transport() -> None:
    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "http"
        result = await sdlc_seed_from_file(path="/any/path.json")

    assert result["status_code"] == 403
    assert "stdio" in result["error"].lower() or "http mode" in result["error"].lower()


@pytest.mark.asyncio
async def test_stdio_guard_does_not_read_file_on_http_transport(
    tmp_path: Path,
) -> None:
    """File I/O must not occur before the transport guard fires."""
    # Non-existent path — if the guard fires first, we never reach path validation.
    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "http"
        result = await sdlc_seed_from_file(path="/does/not/exist.json")

    assert result["status_code"] == 403
    # If path validation had run first, the error would mention "not found".
    assert "not found" not in result["error"].lower()


# ---------------------------------------------------------------------------
# Guard 2 — path validation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_nonexistent_file_returns_422() -> None:
    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path="/does/not/exist.json")

    assert result["status_code"] == 422
    assert "not found" in result["error"].lower()
    assert result["path"] == "/does/not/exist.json"


@pytest.mark.asyncio
async def test_directory_path_returns_422(tmp_path: Path) -> None:
    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(tmp_path))

    assert result["status_code"] == 422
    assert "not a regular file" in result["error"].lower()
    assert result["path"] == str(tmp_path)


# ---------------------------------------------------------------------------
# Guard 3 — size guard
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_oversized_file_returns_422(tmp_path: Path) -> None:
    f = tmp_path / "big.json"
    f.write_text("{}", encoding="utf-8")

    one_hundred_mb_plus_one = 100 * 1024 * 1024 + 1

    # We need to keep the real stat() for is_file() (which reads st_mode)
    # but fake the st_size that the size guard reads.  Do this by wrapping
    # the real stat result and overriding only st_size.
    import stat as _stat_module

    real_stat = f.stat()

    class _FakeStat:
        st_size = one_hundred_mb_plus_one
        st_mode = real_stat.st_mode  # preserve S_ISREG so is_file() still works

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch("pathlib.Path.stat", return_value=_FakeStat()),
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "100 mb" in result["error"].lower()
    assert result["path"] == str(f)


# ---------------------------------------------------------------------------
# Guard 4 — file read error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_file_read_oserror_returns_422(tmp_path: Path) -> None:
    f = tmp_path / "unreadable.json"
    f.write_text("{}", encoding="utf-8")

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch("asyncio.to_thread", side_effect=OSError("Permission denied")),
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "failed to read file" in result["error"].lower()
    # The raw OS error must not leak — only the sanitised message.
    assert "permission denied" not in result["error"].lower()
    assert result["path"] == str(f)


@pytest.mark.asyncio
async def test_file_read_unicode_error_returns_422(tmp_path: Path) -> None:
    f = tmp_path / "binary.json"
    f.write_bytes(b"\xff\xfe invalid utf-8")

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "failed to read file" in result["error"].lower()


# ---------------------------------------------------------------------------
# Guard 5 — JSON parse
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_invalid_json_returns_422(tmp_path: Path) -> None:
    f = tmp_path / "bad.json"
    f.write_text("this is { not valid json", encoding="utf-8")

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "invalid json" in result["error"].lower()
    assert result["path"] == str(f)


# ---------------------------------------------------------------------------
# Guard 6 — dict-type guard
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_json_array_returns_422(tmp_path: Path) -> None:
    f = tmp_path / "array.json"
    f.write_text("[1, 2, 3]", encoding="utf-8")

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "json object" in result["error"].lower()
    assert result["path"] == str(f)


@pytest.mark.asyncio
async def test_json_string_returns_422(tmp_path: Path) -> None:
    f = tmp_path / "string.json"
    f.write_text('"just a string"', encoding="utf-8")

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "json object" in result["error"].lower()


# ---------------------------------------------------------------------------
# Guard 7 — structure validation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_missing_entries_key_returns_422(tmp_path: Path) -> None:
    f = _write_tmp({"version": "v1"})

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "entries" in result["error"].lower()


@pytest.mark.asyncio
async def test_entries_not_a_list_returns_422(tmp_path: Path) -> None:
    f = _write_tmp({"version": "v1", "entries": "not_a_list"})

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "entries" in result["error"].lower()


@pytest.mark.asyncio
async def test_missing_version_key_returns_422(tmp_path: Path) -> None:
    f = _write_tmp({"entries": []})

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "version" in result["error"].lower()


@pytest.mark.asyncio
async def test_empty_version_string_returns_422(tmp_path: Path) -> None:
    f = _write_tmp({"entries": [], "version": ""})

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "version" in result["error"].lower()


@pytest.mark.asyncio
async def test_version_not_a_string_returns_422(tmp_path: Path) -> None:
    f = _write_tmp({"entries": [], "version": 42})

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "version" in result["error"].lower()


# ---------------------------------------------------------------------------
# Guard 8 — entry-count ceiling
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_entry_count_exceeds_10000_returns_422(tmp_path: Path) -> None:
    payload = {"version": "v1", "entries": [{}] * 10_001}
    f = _write_tmp(payload)

    with patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings:
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result["status_code"] == 422
    assert "10,000" in result["error"] or "10000" in result["error"]
    assert result["path"] == str(f)


@pytest.mark.asyncio
async def test_entry_count_exactly_10000_passes_ceiling_guard(tmp_path: Path) -> None:
    """10,000 entries is the limit — exactly at the boundary must succeed the guard."""
    payload = {"version": "v1", "entries": [{}] * 10_000}
    f = _write_tmp(payload)

    ctx, mock = _make_client_mock(seed=SAMPLE_SEED_RESPONSE)

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx),
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    # Should have reached the delegation step (no 422 from ceiling guard).
    assert result != {"status_code": 422}
    mock.seed.assert_awaited_once()


# ---------------------------------------------------------------------------
# Guard 9 / happy path — delegation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_happy_path_delegates_to_client() -> None:
    f = _write_tmp(VALID_PAYLOAD)
    ctx, mock = _make_client_mock(seed=SAMPLE_SEED_RESPONSE)

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx),
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert result == SAMPLE_SEED_RESPONSE
    mock.seed.assert_awaited_once()


@pytest.mark.asyncio
async def test_happy_path_passes_correct_entries_and_version() -> None:
    f = _write_tmp(VALID_PAYLOAD)
    ctx, mock = _make_client_mock(seed=SAMPLE_SEED_RESPONSE)

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx),
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        await sdlc_seed_from_file(path=str(f))

    call_kwargs = mock.seed.call_args[1]
    assert call_kwargs["entries"] == VALID_PAYLOAD["entries"]
    assert call_kwargs["version"] == VALID_PAYLOAD["version"]


@pytest.mark.asyncio
async def test_happy_path_skip_deprecation_defaults_false() -> None:
    """skip_deprecation must default to False when absent from the file."""
    payload = {k: v for k, v in VALID_PAYLOAD.items()}  # no skip_deprecation key
    f = _write_tmp(payload)
    ctx, mock = _make_client_mock(seed=SAMPLE_SEED_RESPONSE)

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx),
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        await sdlc_seed_from_file(path=str(f))

    call_kwargs = mock.seed.call_args[1]
    assert call_kwargs["skip_deprecation"] is False


@pytest.mark.asyncio
async def test_happy_path_skip_deprecation_true_when_set() -> None:
    payload = {**VALID_PAYLOAD, "skip_deprecation": True}
    f = _write_tmp(payload)
    ctx, mock = _make_client_mock(seed=SAMPLE_SEED_RESPONSE)

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx),
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        await sdlc_seed_from_file(path=str(f))

    call_kwargs = mock.seed.call_args[1]
    assert call_kwargs["skip_deprecation"] is True


@pytest.mark.asyncio
async def test_request_token_passthrough() -> None:
    f = _write_tmp(VALID_PAYLOAD)
    ctx, _ = _make_client_mock(seed=SAMPLE_SEED_RESPONSE)

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch(
            "neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx
        ) as MockClient,
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        await sdlc_seed_from_file(path=str(f), _request_token="bearer-test-xyz")

    MockClient.assert_called_once_with(token="bearer-test-xyz")


@pytest.mark.asyncio
async def test_api_error_wrapped_in_error_dict() -> None:
    f = _write_tmp(VALID_PAYLOAD)
    ctx, _ = _make_client_mock(seed=APIError(500, "Internal server error"))

    with (
        patch("neuroloom_mcp.tools.document_tools.get_settings") as mock_settings,
        patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx),
    ):
        mock_settings.return_value.mcp_transport = "stdio"
        result = await sdlc_seed_from_file(path=str(f))

    assert "error" in result
    assert result["status_code"] == 500
