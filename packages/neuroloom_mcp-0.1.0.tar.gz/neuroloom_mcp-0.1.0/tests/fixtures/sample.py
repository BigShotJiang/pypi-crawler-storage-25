from typing import Optional
from .database import DatabaseClient
from .validation import validate_input


class UserService:
    def __init__(self, db: DatabaseClient):
        self.db = db

    def create_user(self, name: str, email: str) -> dict:
        validate_input(name, email)
        user = self.db.insert({"name": name, "email": email})
        return format_user(user)

    def get_user(self, user_id: str) -> Optional[dict]:
        return self.db.find_by_id(user_id)


def format_user(raw: dict) -> dict:
    return {"id": raw["id"], "name": raw["name"], "email": raw["email"]}


def process_users(users: list[dict]) -> list[dict]:
    return [format_user(u) for u in users]
