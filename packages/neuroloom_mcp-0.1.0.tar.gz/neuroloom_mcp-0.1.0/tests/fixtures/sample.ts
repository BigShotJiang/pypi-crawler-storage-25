import { validateInput } from "./validation";
import { DatabaseClient } from "./db";

export class UserService {
  private db: DatabaseClient;

  constructor(db: DatabaseClient) {
    this.db = db;
  }

  async createUser(name: string, email: string): Promise<User> {
    validateInput(name, email);
    const user = await this.db.insert({ name, email });
    return formatUser(user);
  }

  async getUser(id: string): Promise<User> {
    return this.db.findById(id);
  }
}

function formatUser(raw: any): User {
  return { id: raw.id, name: raw.name, email: raw.email };
}

const processUsers = (users: User[]) => {
  return users.map(formatUser);
};

interface User {
  id: string;
  name: string;
  email: string;
}
