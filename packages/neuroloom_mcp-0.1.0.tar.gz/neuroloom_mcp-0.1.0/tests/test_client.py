"""
Tests for NeuroloomAPIClient — HTTP method, path, headers, and error handling.
"""

import json
import pytest
import httpx

from unittest.mock import AsyncMock, patch, MagicMock

from neuroloom_mcp.client import APIError, NeuroloomAPIClient
from tests.conftest import (
    SAMPLE_MEMORY,
    SAMPLE_SEARCH_RESPONSE,
    SAMPLE_SESSION,
    make_error_response,
    make_response,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_transport(response: httpx.Response) -> httpx.MockTransport:
    """Return an httpx.MockTransport that always returns ``response``."""
    return httpx.MockTransport(lambda request: response)


# ---------------------------------------------------------------------------
# Auth header
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_auth_header_is_bearer():
    """Client attaches Authorization: Bearer <token> to every request."""
    sent_headers: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        sent_headers.update(dict(request.headers))
        return make_response([])

    transport = httpx.MockTransport(handler)
    client = NeuroloomAPIClient(
        base_url="http://test-api.local",
        token="my-secret-token",
    )
    client._client = httpx.AsyncClient(
        base_url="http://test-api.local",
        headers=client._build_headers(),
        transport=transport,
    )
    await client._request("GET", "/workspaces/")
    await client._client.aclose()

    assert sent_headers.get("authorization") == "Token my-secret-token"


# ---------------------------------------------------------------------------
# search_memories
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_memories_correct_path_and_method():
    """search_memories sends POST to /memories/search."""
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["path"] = str(request.url.path)
        captured["body"] = json.loads(request.content)
        return make_response(SAMPLE_SEARCH_RESPONSE)

    transport = httpx.MockTransport(handler)
    client = NeuroloomAPIClient(base_url="http://test-api.local", token="tok")
    client._client = httpx.AsyncClient(
        base_url="http://test-api.local",
        headers=client._build_headers(),
        transport=transport,
    )

    result = await client.search_memories(
        query="test query",
        workspace_id="ws-abc",
        memory_types=["pattern"],
        limit=10,
    )
    await client._client.aclose()

    assert captured["method"] == "POST"
    assert captured["path"] == "/memories/search"
    assert captured["body"]["query"] == "test query"
    assert captured["body"]["workspace_id"] == "ws-abc"
    assert captured["body"]["memory_types"] == ["pattern"]
    assert captured["body"]["limit"] == 10
    assert result == SAMPLE_SEARCH_RESPONSE


# ---------------------------------------------------------------------------
# store_memory field mapping
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_memory_maps_content_to_narrative():
    """store_memory maps the 'content' param to 'narrative' and 'files' to 'source_files'."""
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return make_response(SAMPLE_MEMORY, status_code=201)

    transport = httpx.MockTransport(handler)
    client = NeuroloomAPIClient(base_url="http://test-api.local", token="tok")
    client._client = httpx.AsyncClient(
        base_url="http://test-api.local",
        headers=client._build_headers(),
        transport=transport,
    )

    await client.store_memory(
        workspace_id="ws-abc",
        title="Test memory",
        memory_type="pattern",
        content="This is the narrative text.",
        files=["src/models.py"],
        importance=0.9,
        confidence=0.8,
    )
    await client._client.aclose()

    body = captured["body"]
    assert body["narrative"] == "This is the narrative text."
    assert body["source_files"] == ["src/models.py"]
    assert body["importance_score"] == 0.9
    assert "content" not in body


# ---------------------------------------------------------------------------
# HTTP error handling
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_http_4xx_raises_api_error():
    """4xx responses are converted to APIError with correct status code."""
    transport = _make_transport(make_error_response(404, "Not found"))
    client = NeuroloomAPIClient(base_url="http://test-api.local", token="tok")
    client._client = httpx.AsyncClient(
        base_url="http://test-api.local",
        headers=client._build_headers(),
        transport=transport,
    )

    with pytest.raises(APIError) as exc_info:
        await client.get_memory_detail("mem-missing")
    await client._client.aclose()

    assert exc_info.value.status_code == 404


@pytest.mark.asyncio
async def test_http_401_raises_api_error():
    """401 responses raise APIError with status_code 401."""
    transport = _make_transport(make_error_response(401, "Unauthorized"))
    client = NeuroloomAPIClient(base_url="http://test-api.local", token="bad-tok")
    client._client = httpx.AsyncClient(
        base_url="http://test-api.local",
        headers=client._build_headers(),
        transport=transport,
    )

    with pytest.raises(APIError) as exc_info:
        await client.list_workspaces()
    await client._client.aclose()

    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_connect_error_raises_api_error_503():
    """ConnectError is translated to APIError with status 503."""

    def failing_handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("Connection refused")

    transport = httpx.MockTransport(failing_handler)
    client = NeuroloomAPIClient(base_url="http://nowhere.local", token="tok")
    client._client = httpx.AsyncClient(
        base_url="http://nowhere.local",
        headers=client._build_headers(),
        transport=transport,
    )

    with pytest.raises(APIError) as exc_info:
        await client.list_workspaces()
    await client._client.aclose()

    assert exc_info.value.status_code == 503


@pytest.mark.asyncio
async def test_timeout_raises_api_error_408():
    """TimeoutException is translated to APIError with status 408."""

    def timeout_handler(request: httpx.Request) -> httpx.Response:
        raise httpx.TimeoutException("Timed out", request=request)

    transport = httpx.MockTransport(timeout_handler)
    client = NeuroloomAPIClient(base_url="http://slow.local", token="tok")
    client._client = httpx.AsyncClient(
        base_url="http://slow.local",
        headers=client._build_headers(),
        transport=transport,
    )

    with pytest.raises(APIError) as exc_info:
        await client.list_workspaces()
    await client._client.aclose()

    assert exc_info.value.status_code == 408


@pytest.mark.asyncio
async def test_204_returns_none():
    """204 No Content responses return None (not a JSON parse error)."""
    transport = _make_transport(httpx.Response(204, content=b""))
    client = NeuroloomAPIClient(base_url="http://test-api.local", token="tok")
    client._client = httpx.AsyncClient(
        base_url="http://test-api.local",
        headers=client._build_headers(),
        transport=transport,
    )

    result = await client._request("DELETE", "/memories/mem-abc")
    await client._client.aclose()

    assert result is None


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_context_manager_opens_and_closes_client():
    """Using NeuroloomAPIClient as an async context manager creates and closes the client."""
    transport = _make_transport(make_response([]))
    client = NeuroloomAPIClient(base_url="http://test-api.local", token="tok")

    assert client._client is None

    async with client:
        assert client._client is not None

    assert client._client is None
