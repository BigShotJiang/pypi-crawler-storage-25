"""
Integration tests for APIKeyAuthMiddleware.

Strategy
--------
We test the REAL middleware against the REAL Starlette app. The only thing
mocked is the upstream httpx call that validates tokens against the Neuroloom
API — that is an external I/O boundary we genuinely cannot control in tests.

Two app fixtures are provided:

1. ``app_with_auth`` — builds a minimal Starlette app with only the routes the
   real server exposes (/mcp stub, /health) plus APIKeyAuthMiddleware. The
   lifespan from ``create_http_app()`` is deliberately NOT used here to avoid
   the startup network call to the Neuroloom API.

2. ``client`` — an httpx.TestClient wrapping the app. Synchronous because
   TestClient is sync-over-async internally and works fine with asyncio_mode=auto.

Bug Regression
--------------
Tests in ``TestOAuthDiscoveryPaths`` are written to FAIL against the current
code (regression-first). They are the precise reproduction of the OAuth
discovery auth issue described in the bug report:

    Claude Code MCP client hits /.well-known/oauth-authorization-server and
    /.well-known/oauth-protected-resource. APIKeyAuthMiddleware intercepts
    these requests before routing, returns 401 with WWW-Authenticate header.
    Client sees WWW-Authenticate + 401 and enters the OAuth flow.

Once the middleware is fixed to pass /.well-known/* through, these tests turn
GREEN without modification.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from typing import Any, AsyncIterator
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route
from starlette.testclient import TestClient

from neuroloom_mcp.auth import APIKeyAuthMiddleware, _ERROR_HEADERS, _401_BODY, _503_BODY
from neuroloom_mcp.server import oauth_protected_resource_handler, json_404_handler


# ---------------------------------------------------------------------------
# Helpers: upstream mock factories
# ---------------------------------------------------------------------------


def _make_upstream_response(status_code: int) -> httpx.Response:
    """Build a minimal httpx.Response for mocking the upstream auth call."""
    content = json.dumps({"detail": "ok" if status_code == 200 else "forbidden"}).encode()
    return httpx.Response(
        status_code=status_code,
        headers={"Content-Type": "application/json"},
        content=content,
    )


@contextmanager
def _mock_upstream(
    response: httpx.Response | None = None,
    side_effect: Exception | type[Exception] | Callable[..., Any] | None = None,
) -> Iterator[AsyncMock]:
    """Context manager that patches the httpx.AsyncClient used by the auth middleware.

    Yields the mock AsyncClient instance. The yielded mock CAN be used for
    call count inspection or argument assertions, but callers are not required
    to use it.

    Args:
        response: The httpx.Response the mock GET call should return.
                  Mutually exclusive with ``side_effect``.
        side_effect: An exception or callable to use as the ``side_effect`` on
                     the mock GET call. Used for network-error tests and for
                     call-tracking closures in caching tests.
    """
    if response is not None and side_effect is not None:
        raise ValueError("Provide response or side_effect, not both")
    with patch("neuroloom_mcp.auth.httpx.AsyncClient") as mock_cls:
        mock_instance = AsyncMock()
        if side_effect is not None:
            mock_instance.get = AsyncMock(side_effect=side_effect)
        else:
            mock_instance.get = AsyncMock(return_value=response)
        mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
        mock_instance.__aexit__ = AsyncMock(return_value=None)
        mock_cls.return_value = mock_instance
        yield mock_instance


# ---------------------------------------------------------------------------
# App factory: minimal Starlette app with APIKeyAuthMiddleware
#
# We do NOT use create_http_app() because its lifespan calls
# _validate_startup_http() which makes real network calls. Instead we build
# the same route + middleware stack manually.
#
# The /mcp stub returns 200 JSON so we can verify "valid token passes through".
# In production /mcp is handled by StreamableHTTPSessionManager but for auth
# tests we only need to know the middleware allowed the request through.
# ---------------------------------------------------------------------------


async def _mcp_stub_handler(request: Request) -> JSONResponse:
    """Minimal stand-in for the real /mcp MCP endpoint."""
    return JSONResponse({"status": "mcp_ok"})


async def _mcp_state_handler(request: Request) -> JSONResponse:
    """Stand-in for /mcp that echoes back the api_token stored in request.state.

    Used by tests that verify the middleware writes the token into scope["state"].
    """
    token = getattr(request.state, "api_token", None)
    return JSONResponse({"api_token": token})


async def _health_handler(request: Request) -> JSONResponse:
    """Mirror of the real health_handler."""
    return JSONResponse({"status": "ok"})


def _build_test_app(include_metadata: bool = False) -> Starlette:
    """Build the minimal app used across integration tests.

    Args:
        include_metadata: When True, registers the RFC 9728
            ``/.well-known/oauth-protected-resource`` route and the JSON 404
            exception handler. When False (the default) only ``/mcp`` and
            ``/health`` are registered.
    """
    routes = []
    if include_metadata:
        routes.append(
            Route(
                "/.well-known/oauth-protected-resource",
                endpoint=oauth_protected_resource_handler,
                methods=["GET"],
            )
        )
    routes += [
        Route("/mcp", endpoint=_mcp_stub_handler, methods=["POST"]),
        Route("/health", endpoint=_health_handler, methods=["GET"]),
    ]

    kwargs: dict[str, object] = {
        "routes": routes,
        "middleware": [Middleware(APIKeyAuthMiddleware)],
    }
    if include_metadata:
        kwargs["exception_handlers"] = {404: json_404_handler}

    return Starlette(**kwargs)  # type: ignore[arg-type]


def _build_test_app_with_state_handler() -> Starlette:
    """Build the test app whose /mcp handler echoes back request.state.api_token.

    Used exclusively by tests that verify the middleware writes the token into
    scope["state"] so that Starlette's Request.state can access it downstream.
    """
    return Starlette(
        routes=[
            Route("/mcp", endpoint=_mcp_state_handler, methods=["POST"]),
            Route("/health", endpoint=_health_handler, methods=["GET"]),
        ],
        middleware=[Middleware(APIKeyAuthMiddleware)],
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def app() -> Starlette:
    """Return a fresh Starlette app instance per test."""
    return _build_test_app()


@pytest.fixture()
def client(app: Starlette) -> TestClient:
    """Synchronous TestClient wrapping the ASGI app.

    raise_server_exceptions=False lets us inspect 5xx responses rather than
    having them re-raised as Python exceptions in the test process.
    """
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture()
def app_with_metadata() -> Starlette:
    """Fresh app instance with the RFC 9728 metadata route and JSON 404 handler."""
    return _build_test_app(include_metadata=True)


@pytest.fixture()
def client_with_metadata(app_with_metadata: Starlette) -> TestClient:
    return TestClient(app_with_metadata, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Section 1: Non-MCP paths bypass auth — regression tests
#
# The middleware only authenticates POST /mcp. All other paths pass through
# to Starlette's router, which returns 404 for unregistered routes. This
# prevents MCP clients from mistaking a 401 for "this server requires OAuth".
# ---------------------------------------------------------------------------


class TestNonMcpPathsBypassAuth:
    """Verify that paths other than /mcp are not gated by auth middleware.

    MCP clients probe GET /, /.well-known/*, POST /register, and other paths
    during OAuth discovery. If any return 401 + WWW-Authenticate, clients
    enter an OAuth flow instead of using the static Bearer token. The
    middleware's positive-match approach (only gate /mcp) ensures all
    probes get 404 from routing, not 401 from auth.
    """

    def test_oauth_authorization_server_returns_404(
        self, client: TestClient
    ) -> None:
        """GET /.well-known/oauth-authorization-server must return 404."""
        response = client.get("/.well-known/oauth-authorization-server")

        assert response.status_code == 404
        assert "www-authenticate" not in response.headers

    def test_oauth_protected_resource_scoped_returns_404(
        self, client: TestClient
    ) -> None:
        """GET /.well-known/oauth-protected-resource/mcp must return 404."""
        response = client.get("/.well-known/oauth-protected-resource/mcp")
        assert response.status_code == 404

    def test_openid_configuration_returns_404(self, client: TestClient) -> None:
        """GET /.well-known/openid-configuration must return 404."""
        response = client.get("/.well-known/openid-configuration")
        assert response.status_code == 404

    def test_openid_configuration_scoped_returns_404(self, client: TestClient) -> None:
        """GET /.well-known/openid-configuration/mcp must return 404."""
        response = client.get("/.well-known/openid-configuration/mcp")
        assert response.status_code == 404

    def test_register_endpoint_returns_404_without_token(
        self, client: TestClient
    ) -> None:
        """POST /register without auth must return 404 (not 401).

        /register is an OAuth client registration probe. The middleware only
        gates /mcp, so this passes through to routing → 404.
        """
        response = client.post("/register", json={})
        assert response.status_code == 404
        assert "www-authenticate" not in response.headers

    def test_mcp_nested_well_known_returns_404(
        self, client: TestClient
    ) -> None:
        """GET /mcp/.well-known/openid-configuration must return 404.

        This path doesn't match /mcp exactly (it has a subpath), so the
        middleware passes it through to routing → 404.
        """
        response = client.get("/mcp/.well-known/openid-configuration")
        assert response.status_code == 404
        assert "www-authenticate" not in response.headers

    def test_root_path_returns_404_not_401(self, client: TestClient) -> None:
        """GET / must return 404 (not 401).

        MCP clients probe the root path during discovery. A 401 here triggers
        the OAuth flow. The middleware only gates /mcp, so / passes through
        to routing → 404.
        """
        response = client.get("/")
        assert response.status_code == 404
        assert "www-authenticate" not in response.headers

    def test_no_discovery_path_has_www_authenticate_header(
        self, client: TestClient
    ) -> None:
        """No non-/mcp path should return WWW-Authenticate.

        The presence of WWW-Authenticate on any discovery probe is what
        triggers MCP clients to enter the OAuth flow.
        """
        probes = [
            ("GET", "/.well-known/oauth-authorization-server"),
            ("GET", "/.well-known/openid-configuration"),
            ("GET", "/"),
            ("POST", "/register"),
        ]
        for method, path in probes:
            response = getattr(client, method.lower())(path)
            assert "www-authenticate" not in response.headers, (
                f"{method} {path} returned WWW-Authenticate header — "
                "this will trigger OAuth flow in MCP clients."
            )

    @pytest.mark.parametrize("path", ["/MCP", "//mcp"])
    def test_non_exact_mcp_paths_return_404_not_401(
        self, client: TestClient, path: str
    ) -> None:
        """Paths that look like /mcp but don't match exactly must return 404.

        The middleware gates only scope["path"] == "/mcp" exactly. Variants
        such as "/MCP" (wrong case) and "//mcp" (double slash) do not match
        and pass through to routing → 404. A 401 here would incorrectly gate
        non-MCP requests.

        Note: "/mcp/" (trailing slash) is NOT tested here because httpx (used
        by Starlette's TestClient) normalizes "/mcp/" to "/mcp" before the
        request reaches the ASGI stack. The middleware therefore sees
        scope["path"] == "/mcp" and correctly gates that request with 401.
        """
        response = client.post(path, json={})
        assert response.status_code == 404, (
            f"Expected 404 for {path!r} but got {response.status_code}. "
            "This path must not be gated by auth middleware."
        )
        assert "www-authenticate" not in response.headers

    def test_mcp_trailing_slash_is_normalized_and_gated_by_auth(
        self, client: TestClient
    ) -> None:
        """POST /mcp/ without a token must return 401.

        httpx normalizes /mcp/ → /mcp before the request reaches the ASGI
        stack, so the middleware sees scope["path"] == "/mcp" and gates the
        request. This means a trailing slash does NOT bypass auth.
        """
        response = client.post("/mcp/", json={})
        assert response.status_code == 401
        assert "www-authenticate" in response.headers

    def test_mcp_with_query_string_is_gated_by_auth(
        self, client: TestClient
    ) -> None:
        """POST /mcp?foo=bar without a token must return 401.

        scope["path"] excludes query strings, so /mcp?foo=bar has path "/mcp"
        and is correctly caught by the middleware's exact-path check. A missing
        or invalid token must still return 401.
        """
        response = client.post("/mcp?foo=bar", json={})
        assert response.status_code == 401
        assert "www-authenticate" in response.headers


# ---------------------------------------------------------------------------
# Section 2: RFC 9728 protected resource metadata endpoint
# ---------------------------------------------------------------------------


class TestOAuthProtectedResource:
    """Tests for the /.well-known/oauth-protected-resource endpoint.

    Uses ``client_with_metadata`` which is built on ``_build_test_app(include_metadata=True)``
    — the only app variant that registers the RFC 9728 route and the JSON 404 handler.
    """

    @pytest.fixture(autouse=True)
    def _clear_settings_cache(self) -> Iterator[None]:
        """Clear the get_settings LRU cache before and after each test.

        ``get_settings`` is decorated with ``@lru_cache`` / ``cache``. Tests
        that call ``monkeypatch.setenv`` must clear the cache so the new env
        vars are picked up, and must clear it again on teardown so the patched
        values don't leak into subsequent tests.
        """
        from neuroloom_mcp import config
        config.get_settings.cache_clear()
        yield
        config.get_settings.cache_clear()

    def test_oauth_protected_resource_returns_200(
        self, client_with_metadata: TestClient
    ) -> None:
        """GET /.well-known/oauth-protected-resource must return 200 with RFC 9728 metadata."""
        response = client_with_metadata.get("/.well-known/oauth-protected-resource")
        assert response.status_code == 200

    def test_oauth_protected_resource_metadata(
        self, client_with_metadata: TestClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """GET /.well-known/oauth-protected-resource returns RFC 9728 metadata."""
        monkeypatch.setenv("MEMORIES_MCP_PUBLIC_URL", "https://mcp.test.local/mcp")
        monkeypatch.setenv("MCP_TRANSPORT", "http")

        from neuroloom_mcp import config
        # A second cache_clear() is required here even though _clear_settings_cache
        # already clears it. The autouse fixture clears the cache before monkeypatch
        # runs (during fixture setup), but monkeypatch.setenv() happens after fixture
        # setup. The new env vars are therefore not visible to the cached Settings
        # object. This call evicts that stale entry so the next get_settings() call
        # picks up the patched environment.
        config.get_settings.cache_clear()

        response = client_with_metadata.get("/.well-known/oauth-protected-resource")

        assert response.status_code == 200
        assert response.headers.get("content-type", "").startswith("application/json")

        body = response.json()
        assert body["resource"] == "https://mcp.test.local/mcp"
        assert body["authorization_servers"] == []
        assert body["bearer_methods_supported"] == ["header"]

    def test_unmatched_path_returns_json_404(
        self, client_with_metadata: TestClient
    ) -> None:
        """Unmatched paths must return 404 JSON, not 404 HTML."""
        response = client_with_metadata.get("/some/unknown/path")

        assert response.status_code == 404
        assert response.headers.get("content-type", "").startswith("application/json")
        body = response.json()
        assert body["error"] == "not_found"
        assert "path" in body


# ---------------------------------------------------------------------------
# Section 3: Auth middleware correctness for real paths
# ---------------------------------------------------------------------------


class TestAuthMiddlewareRealPaths:
    """Test that the middleware correctly gates /mcp and exempts /health."""

    def test_health_without_token_returns_200(self, client: TestClient) -> None:
        """/health must bypass auth entirely — no Bearer token required."""
        response = client.get("/health")

        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "ok"

    def test_mcp_without_token_returns_401(self, client: TestClient) -> None:
        """POST /mcp without an Authorization header must return 401."""
        response = client.post("/mcp", json={})

        assert response.status_code == 401

    def test_mcp_without_token_returns_correct_body(self, client: TestClient) -> None:
        """401 body must match the expected error structure."""
        response = client.post("/mcp", json={})

        assert response.status_code == 401
        body = response.json()
        assert body["error"] == "authentication_failed"
        assert "message" in body
        assert isinstance(body["message"], str)
        assert len(body["message"]) > 0

    def test_mcp_with_malformed_auth_scheme_returns_401(
        self, client: TestClient
    ) -> None:
        """Authorization header with wrong scheme (Token instead of Bearer) must return 401."""
        response = client.post(
            "/mcp",
            json={},
            headers={"Authorization": "Token some-valid-looking-key"},
        )

        assert response.status_code == 401

    def test_mcp_with_empty_bearer_token_returns_401(self, client: TestClient) -> None:
        """'Authorization: Bearer ' (empty token after scheme) must return 401."""
        response = client.post(
            "/mcp",
            json={},
            headers={"Authorization": "Bearer "},
        )

        assert response.status_code == 401

    def test_mcp_with_invalid_token_returns_401(self, client: TestClient) -> None:
        """POST /mcp with a token that fails upstream validation must return 401.

        The upstream mock returns 403 to simulate a revoked/invalid key.
        """
        with _mock_upstream(response=_make_upstream_response(403)):
            response = client.post(
                "/mcp",
                json={},
                headers={"Authorization": "Bearer invalid-key-abc123"},
            )

        assert response.status_code == 401
        body = response.json()
        assert body["error"] == "authentication_failed"

    def test_mcp_with_valid_token_passes_through_to_handler(
        self, client: TestClient
    ) -> None:
        """POST /mcp with a token that passes upstream validation must reach the handler.

        The upstream mock returns 200 to simulate a valid key.
        The stub handler returns {"status": "mcp_ok"} — we verify we get that back.
        """
        with _mock_upstream(response=_make_upstream_response(200)):
            response = client.post(
                "/mcp",
                json={},
                headers={"Authorization": "Bearer valid-key-xyz789"},
            )

        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "mcp_ok"

    def test_mcp_upstream_unavailable_returns_503(self, client: TestClient) -> None:
        """POST /mcp when the upstream API is unreachable must return 503."""
        with _mock_upstream(side_effect=httpx.ConnectError("Connection refused")):
            response = client.post(
                "/mcp",
                json={},
                headers={"Authorization": "Bearer some-token"},
            )

        assert response.status_code == 503

    def test_mcp_upstream_unavailable_returns_correct_body(
        self, client: TestClient
    ) -> None:
        """503 body must match the expected upstream_unavailable structure."""
        with _mock_upstream(side_effect=httpx.TimeoutException("Request timeout")):
            response = client.post(
                "/mcp",
                json={},
                headers={"Authorization": "Bearer some-token"},
            )

        assert response.status_code == 503
        body = response.json()
        assert body["error"] == "upstream_unavailable"
        assert "message" in body

    def test_mcp_upstream_5xx_returns_503(self, client: TestClient) -> None:
        """POST /mcp when the upstream returns HTTP 500 must return 503.

        A non-200/401/403 upstream response is treated as a transient upstream
        failure. The middleware returns 503 rather than 401 so the client can
        distinguish a temporary outage from an invalid token.
        """
        with _mock_upstream(response=_make_upstream_response(500)):
            response = client.post(
                "/mcp",
                json={},
                headers={"Authorization": "Bearer some-token"},
            )

        assert response.status_code == 503
        body = response.json()
        assert body["error"] == "upstream_unavailable"

    def test_mcp_valid_token_stored_in_request_state(self) -> None:
        """POST /mcp with a valid token must store the token in request.state.api_token.

        The middleware calls ``scope["state"]["api_token"] = token`` on success
        so downstream handlers can read the raw token via ``request.state.api_token``
        (Starlette's Request.state reads from scope["state"]).
        """
        state_app = _build_test_app_with_state_handler()
        token_value = "test-token-state-check"

        with _mock_upstream(response=_make_upstream_response(200)):
            with TestClient(state_app, raise_server_exceptions=False) as c:
                response = c.post(
                    "/mcp",
                    json={},
                    headers={"Authorization": f"Bearer {token_value}"},
                )

        assert response.status_code == 200
        body = response.json()
        assert body["api_token"] == token_value, (
            "Middleware must store the raw Bearer token in scope['state']['api_token'] "
            "so downstream handlers can access it via request.state.api_token."
        )


# ---------------------------------------------------------------------------
# Section 4: Security headers on error responses
# ---------------------------------------------------------------------------


class TestSecurityHeaders:
    """Verify that error responses include the required security headers."""

    def test_401_response_has_www_authenticate_header(
        self, client: TestClient
    ) -> None:
        """401 on /mcp must include WWW-Authenticate header."""
        response = client.post("/mcp", json={})

        assert response.status_code == 401
        assert "www-authenticate" in response.headers

    def test_401_response_has_cache_control_no_store(
        self, client: TestClient
    ) -> None:
        """401 on /mcp must include Cache-Control: no-store to prevent caching of auth errors."""
        response = client.post("/mcp", json={})

        assert response.status_code == 401
        assert response.headers.get("cache-control") == "no-store"

    def test_401_response_has_x_content_type_options(
        self, client: TestClient
    ) -> None:
        """401 on /mcp must include X-Content-Type-Options: nosniff."""
        response = client.post("/mcp", json={})

        assert response.status_code == 401
        assert response.headers.get("x-content-type-options") == "nosniff"

    def test_503_response_has_cache_control_no_store(
        self, client: TestClient
    ) -> None:
        """503 responses must also carry Cache-Control: no-store."""
        with _mock_upstream(side_effect=httpx.ConnectError("Connection refused")):
            response = client.post(
                "/mcp",
                json={},
                headers={"Authorization": "Bearer some-token"},
            )

        assert response.status_code == 503
        assert response.headers.get("cache-control") == "no-store"

    def test_503_response_has_x_content_type_options(
        self, client: TestClient
    ) -> None:
        """503 responses must carry X-Content-Type-Options: nosniff."""
        with _mock_upstream(side_effect=httpx.ConnectError("Connection refused")):
            response = client.post(
                "/mcp",
                json={},
                headers={"Authorization": "Bearer some-token"},
            )

        assert response.status_code == 503
        assert response.headers.get("x-content-type-options") == "nosniff"

    def test_200_response_does_not_have_www_authenticate_header(
        self, client: TestClient
    ) -> None:
        """/health success response must not include WWW-Authenticate."""
        response = client.get("/health")

        assert response.status_code == 200
        assert "www-authenticate" not in response.headers


# ---------------------------------------------------------------------------
# Section 5: Token caching behavior
# ---------------------------------------------------------------------------


class TestTokenCaching:
    """Verify TTLCache behavior: valid tokens are cached, invalid tokens are not."""

    def test_second_request_with_same_valid_token_does_not_call_upstream_twice(
        self, app: Starlette
    ) -> None:
        """The second request with the same valid token must use the cache (one upstream call).

        The auth middleware caches successful validations by token hash. A second
        request with the same token should hit the cache, making only ONE upstream
        HTTP call total for two requests.
        """
        mock_response = _make_upstream_response(200)
        call_count = 0

        async def _track_calls(*args: object, **kwargs: object) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            return mock_response

        with _mock_upstream(side_effect=_track_calls):
            with TestClient(app, raise_server_exceptions=False) as c:
                # First request — should hit upstream
                r1 = c.post(
                    "/mcp",
                    json={},
                    headers={"Authorization": "Bearer cached-token-abc"},
                )
                # Second request with same token — should hit cache, not upstream
                r2 = c.post(
                    "/mcp",
                    json={},
                    headers={"Authorization": "Bearer cached-token-abc"},
                )

        assert r1.status_code == 200
        assert r2.status_code == 200
        assert call_count == 1, (
            f"Expected 1 upstream call (second request uses cache) but got {call_count}. "
            "The TTLCache is not caching successful token validations."
        )

    def test_failed_token_validation_is_not_cached(self, app: Starlette) -> None:
        """Failed validations must NOT be cached — each attempt hits upstream.

        Token revocation must take effect immediately. If invalid tokens were
        cached, a revoked token could continue to authenticate within the TTL
        window. The middleware explicitly never caches failed validations.
        """
        mock_response = _make_upstream_response(403)
        call_count = 0

        async def _track_calls(*args: object, **kwargs: object) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            return mock_response

        with _mock_upstream(side_effect=_track_calls):
            with TestClient(app, raise_server_exceptions=False) as c:
                # First request — upstream says 403
                r1 = c.post(
                    "/mcp",
                    json={},
                    headers={"Authorization": "Bearer revoked-token-xyz"},
                )
                # Second request with the same revoked token — must hit upstream again
                r2 = c.post(
                    "/mcp",
                    json={},
                    headers={"Authorization": "Bearer revoked-token-xyz"},
                )

        assert r1.status_code == 401
        assert r2.status_code == 401
        assert call_count == 2, (
            f"Expected 2 upstream calls (failed validations not cached) but got {call_count}. "
            "The middleware must not cache failed token validations — revoked keys "
            "must be re-checked on every request."
        )

    def test_different_tokens_each_hit_upstream(self, app: Starlette) -> None:
        """Two distinct tokens must each make their own upstream call."""
        call_count = 0
        tokens_seen: list[str] = []

        async def _track_calls(
            url: str, headers: dict[str, str], **kwargs: object
        ) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            tokens_seen.append(headers.get("Authorization", ""))
            return _make_upstream_response(200)

        with _mock_upstream(side_effect=_track_calls):
            with TestClient(app, raise_server_exceptions=False) as c:
                r1 = c.post(
                    "/mcp",
                    json={},
                    headers={"Authorization": "Bearer token-alpha"},
                )
                r2 = c.post(
                    "/mcp",
                    json={},
                    headers={"Authorization": "Bearer token-beta"},
                )

        assert r1.status_code == 200
        assert r2.status_code == 200
        assert call_count == 2, (
            f"Expected 2 upstream calls for 2 distinct tokens but got {call_count}."
        )
        # Upstream receives Token-style header, not Bearer
        assert any("Token token-alpha" in t for t in tokens_seen)
        assert any("Token token-beta" in t for t in tokens_seen)


# ---------------------------------------------------------------------------
# Section 6: Mount vs Route redirect regression
#
# Starlette's Mount("/mcp") issues a 307 redirect for POST /mcp because
# Mount expects a trailing slash to distinguish prefix-mount from exact-match.
# Route("/mcp") matches exactly without redirecting.
#
# This class documents WHY the production server uses Route, not Mount.
# ---------------------------------------------------------------------------


def _build_mount_app() -> Starlette:
    """Build a test app that uses Mount instead of Route for /mcp.

    This deliberately mirrors the WRONG configuration to prove that Mount
    causes 307 redirects on ``POST /mcp`` requests.
    """
    return Starlette(
        routes=[
            Mount("/mcp", app=_mcp_stub_handler),
            Route("/health", endpoint=_health_handler, methods=["GET"]),
        ],
        middleware=[Middleware(APIKeyAuthMiddleware)],
    )


class TestMountRedirectRegression:
    """Document the Mount-vs-Route routing behavior for POST /mcp.

    Starlette's ``Mount("/mcp")`` interprets ``POST /mcp`` as a request to a
    prefix-mounted sub-application whose root path is ``/mcp``. Starlette
    issues a 307 redirect to ``/mcp/`` (with trailing slash) because Mount
    treats the prefix as a directory. MCP clients following the redirect
    re-send as ``GET /mcp/``, breaking the protocol.

    ``Route("/mcp", methods=["POST"])`` matches the exact path without any
    redirect, which is the correct behavior.

    These tests exist so that anyone tempted to switch from Route to Mount
    can see the observable regression immediately.
    """

    def test_mount_causes_307_redirect_on_post_mcp(self) -> None:
        """POST /mcp on a Mount-based app must return 307 (redirect to /mcp/).

        This is the buggy behavior that Route avoids. The test uses
        ``allow_redirects=False`` so the TestClient captures the redirect
        response instead of automatically following it.
        """
        mount_app = _build_mount_app()

        # allow_redirects=False captures the redirect without following it.
        with TestClient(
            mount_app, raise_server_exceptions=False
        ) as c:
            # We send a valid-looking Bearer token so the middleware passes
            # the request through to routing. Without auth the middleware
            # returns 401 before Starlette can redirect.
            with _mock_upstream(response=_make_upstream_response(200)):
                response = c.post(
                    "/mcp",
                    json={},
                    headers={"Authorization": "Bearer valid-token-xyz"},
                    follow_redirects=False,
                )

        assert response.status_code == 307, (
            f"Expected 307 (Mount redirect) but got {response.status_code}. "
            "Starlette Mount(\"/mcp\") must redirect POST /mcp to /mcp/ — "
            "this is the regression that Route avoids."
        )
        assert response.headers.get("location", "").endswith("/mcp/"), (
            "307 redirect must point to /mcp/ (with trailing slash). "
            f"Got Location: {response.headers.get('location')!r}"
        )

    def test_route_does_not_redirect_post_mcp(self, client: TestClient) -> None:
        """POST /mcp on a Route-based app must return 200 (no redirect).

        This confirms the correct behavior of the production configuration.
        Route(\"/mcp\") matches the exact path; no 307 is issued.
        """
        with _mock_upstream(response=_make_upstream_response(200)):
            response = client.post(
                "/mcp",
                json={},
                headers={"Authorization": "Bearer valid-token-xyz"},
            )

        assert response.status_code == 200, (
            f"Expected 200 (Route matches exactly, no redirect) "
            f"but got {response.status_code}. "
            "Route(\"/mcp\") must not issue a 307 redirect."
        )
        body = response.json()
        assert body["status"] == "mcp_ok"
