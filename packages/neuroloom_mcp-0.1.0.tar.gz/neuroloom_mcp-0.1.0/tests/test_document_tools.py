"""
Tests for document tool functions in neuroloom_mcp.tools.document_tools.

All HTTP calls are mocked at the NeuroloomAPIClient level to verify:
  - Correct delegation to client methods
  - Request body construction (required + optional fields)
  - Response passthrough
  - APIError wrapping into error dicts
  - _request_token passthrough to NeuroloomAPIClient
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from neuroloom_mcp.client import APIError
from neuroloom_mcp.tools.document_tools import (
    document_ingest,
    document_ingest_batch,
    sdlc_get_version,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SAMPLE_DOCUMENT_RESPONSE = {
    "document_id": "doc-deadbeef",
    "title": "Auth design patterns",
    "source_type": "file",
    "status": "queued",
    "content_hash": "sha256-abc123",
}

SAMPLE_BATCH_RESPONSE = {
    "ingested": 2,
    "skipped": 0,
    "errors": [],
    "document_ids": ["doc-aaa", "doc-bbb"],
}

SAMPLE_VERSION_RESPONSE = {
    "version": "c23340a",
    "tag": "v2.1.0",
}


def _make_client_mock(**method_returns):
    """Build a mock NeuroloomAPIClient async context manager."""
    mock = AsyncMock()
    for name, value in method_returns.items():
        if isinstance(value, Exception):
            getattr(mock, name).side_effect = value
        else:
            getattr(mock, name).return_value = value

    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=mock)
    ctx.__aexit__ = AsyncMock(return_value=False)
    return ctx, mock


# ---------------------------------------------------------------------------
# document_ingest
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_document_ingest_delegates_to_client() -> None:
    ctx, mock = _make_client_mock(ingest_document=SAMPLE_DOCUMENT_RESPONSE)
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        result = await document_ingest(
            title="Auth design patterns",
            content="Use token-based auth.",
            source_type="file",
        )
    assert result == SAMPLE_DOCUMENT_RESPONSE
    mock.ingest_document.assert_awaited_once()


@pytest.mark.asyncio
async def test_document_ingest_builds_required_fields() -> None:
    ctx, mock = _make_client_mock(ingest_document=SAMPLE_DOCUMENT_RESPONSE)
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        await document_ingest(
            title="My doc",
            content="Some content.",
            source_type="url",
        )
    body = mock.ingest_document.call_args[0][0]
    assert body["title"] == "My doc"
    assert body["content"] == "Some content."
    assert body["source_type"] == "url"
    # content_hash must NOT be in the body
    assert "content_hash" not in body


@pytest.mark.asyncio
async def test_document_ingest_includes_optional_fields_when_provided() -> None:
    ctx, mock = _make_client_mock(ingest_document=SAMPLE_DOCUMENT_RESPONSE)
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        await document_ingest(
            title="Doc",
            content="Content.",
            source_type="file",
            source_path="/tmp/doc.md",
            tags=["sdlc"],
            format="markdown",
            memory_type="pattern",
            knowledge_id="kb-123",
            version="v1.0.0",
            importance=0.8,
        )
    body = mock.ingest_document.call_args[0][0]
    assert body["source_path"] == "/tmp/doc.md"
    assert body["tags"] == ["sdlc"]
    assert body["format"] == "markdown"
    assert body["memory_type"] == "pattern"
    assert body["knowledge_id"] == "kb-123"
    assert body["version"] == "v1.0.0"
    assert body["importance"] == 0.8


@pytest.mark.asyncio
async def test_document_ingest_omits_optional_fields_when_none() -> None:
    ctx, mock = _make_client_mock(ingest_document=SAMPLE_DOCUMENT_RESPONSE)
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        await document_ingest(title="Doc", content="Content.", source_type="file")
    body = mock.ingest_document.call_args[0][0]
    for field in ("source_path", "tags", "format", "memory_type", "knowledge_id", "version", "importance"):
        assert field not in body, f"Unexpected field in body: {field}"


@pytest.mark.asyncio
async def test_document_ingest_passes_request_token() -> None:
    ctx, mock = _make_client_mock(ingest_document=SAMPLE_DOCUMENT_RESPONSE)
    with patch(
        "neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx
    ) as MockClient:
        await document_ingest(
            title="Doc",
            content="Content.",
            source_type="file",
            _request_token="bearer-xyz",
        )
    MockClient.assert_called_once_with(token="bearer-xyz")


@pytest.mark.asyncio
async def test_document_ingest_returns_error_on_api_error() -> None:
    ctx, _ = _make_client_mock(
        ingest_document=APIError(422, "Validation failed")
    )
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        result = await document_ingest(title="Doc", content="Content.", source_type="file")
    assert "error" in result
    assert result["status_code"] == 422


# ---------------------------------------------------------------------------
# document_ingest_batch
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_document_ingest_batch_delegates_to_client() -> None:
    docs = [
        {"title": "Doc A", "content": "Content A.", "source_type": "file"},
        {"title": "Doc B", "content": "Content B.", "source_type": "file"},
    ]
    ctx, mock = _make_client_mock(ingest_documents_batch=SAMPLE_BATCH_RESPONSE)
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        result = await document_ingest_batch(documents=docs)
    assert result == SAMPLE_BATCH_RESPONSE
    mock.ingest_documents_batch.assert_awaited_once_with(docs)


@pytest.mark.asyncio
async def test_document_ingest_batch_passes_request_token() -> None:
    ctx, _ = _make_client_mock(ingest_documents_batch=SAMPLE_BATCH_RESPONSE)
    with patch(
        "neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx
    ) as MockClient:
        await document_ingest_batch(documents=[], _request_token="tok-abc")
    MockClient.assert_called_once_with(token="tok-abc")


@pytest.mark.asyncio
async def test_document_ingest_batch_returns_error_on_api_error() -> None:
    ctx, _ = _make_client_mock(
        ingest_documents_batch=APIError(400, "Too many documents")
    )
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        result = await document_ingest_batch(documents=[])
    assert "error" in result
    assert result["status_code"] == 400


# ---------------------------------------------------------------------------
# sdlc_get_version
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_sdlc_get_version_delegates_to_client() -> None:
    ctx, mock = _make_client_mock(get_cc_sdlc_version=SAMPLE_VERSION_RESPONSE)
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        result = await sdlc_get_version()
    assert result == SAMPLE_VERSION_RESPONSE
    mock.get_cc_sdlc_version.assert_awaited_once()


@pytest.mark.asyncio
async def test_sdlc_get_version_passes_request_token() -> None:
    ctx, _ = _make_client_mock(get_cc_sdlc_version=SAMPLE_VERSION_RESPONSE)
    with patch(
        "neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx
    ) as MockClient:
        await sdlc_get_version(_request_token="tok-xyz")
    MockClient.assert_called_once_with(token="tok-xyz")


@pytest.mark.asyncio
async def test_sdlc_get_version_returns_error_on_api_error() -> None:
    ctx, _ = _make_client_mock(
        get_cc_sdlc_version=APIError(503, "Upstream unavailable")
    )
    with patch("neuroloom_mcp.tools.document_tools.NeuroloomAPIClient", return_value=ctx):
        result = await sdlc_get_version()
    assert "error" in result
    assert result["status_code"] == 503
