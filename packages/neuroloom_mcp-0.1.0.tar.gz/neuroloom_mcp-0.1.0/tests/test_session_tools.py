"""
Tests for session tool functions in neuroloom_mcp.tools.session_tools.

All HTTP calls are mocked at the NeuroloomAPIClient level to verify:
  - Correct delegation to client methods
  - Request body construction
  - Error response handling
  - Edge cases (missing session_id, no workspace configured)
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from neuroloom_mcp.client import APIError
from neuroloom_mcp.tools.session_tools import (
    session_end,
    session_get_context,
    session_start,
)
from tests.conftest import SAMPLE_CONTEXT, SAMPLE_SESSION


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_client_mock(**method_returns):
    mock = AsyncMock()
    for name, value in method_returns.items():
        if isinstance(value, Exception):
            getattr(mock, name).side_effect = value
        else:
            getattr(mock, name).return_value = value

    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=mock)
    ctx.__aexit__ = AsyncMock(return_value=False)
    return ctx, mock


# ---------------------------------------------------------------------------
# session_start
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_session_start_calls_start_and_get_context():
    """session_start calls client.start_session and fetches initial context."""
    ctx, mock = _make_client_mock(
        start_session=SAMPLE_SESSION,
        get_session_context=SAMPLE_CONTEXT,
    )

    with (
        patch("neuroloom_mcp.tools.session_tools.NeuroloomAPIClient", return_value=ctx),
        patch("neuroloom_mcp.tools.session_tools._detect_git_branch", return_value="main"),
        patch("neuroloom_mcp.tools.session_tools.uuid.uuid4", return_value=MagicMock(
            __str__=lambda self: "test-uuid-001"
        )),
    ):
        result = await session_start(project_path="/tmp/project")

    mock.start_session.assert_awaited_once()
    call_kwargs = mock.start_session.call_args.kwargs
    assert call_kwargs["session_id"] == "test-uuid-001"
    assert call_kwargs["branch_name"] == "main"
    assert call_kwargs["project_name"] == "project"

    mock.get_session_context.assert_awaited_once()
    assert "session" in result
    assert "context" in result
    assert "message" in result


@pytest.mark.asyncio
async def test_session_start_context_fetch_failure_does_not_raise():
    """session_start succeeds even when get_session_context raises."""
    ctx, mock = _make_client_mock(
        start_session=SAMPLE_SESSION,
        get_session_context=Exception("Context error"),
    )

    with (
        patch("neuroloom_mcp.tools.session_tools.NeuroloomAPIClient", return_value=ctx),
        patch("neuroloom_mcp.tools.session_tools._detect_git_branch", return_value=""),
    ):
        result = await session_start()

    assert "error" not in result
    assert result["context"] == {}


@pytest.mark.asyncio
async def test_session_start_api_error():
    """session_start returns error dict on APIError."""
    ctx, _ = _make_client_mock(
        start_session=APIError(503, "API unreachable")
    )

    with patch("neuroloom_mcp.tools.session_tools.NeuroloomAPIClient", return_value=ctx):
        result = await session_start()

    assert "error" in result
    assert result.get("status_code") == 503


# ---------------------------------------------------------------------------
# session_end
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_session_end_calls_client_with_session_id():
    """session_end passes session_id and summary to client.end_session."""
    ended_session = {**SAMPLE_SESSION, "is_active": False, "summary": "Done."}
    ctx, mock = _make_client_mock(end_session=ended_session)

    with patch("neuroloom_mcp.tools.session_tools.NeuroloomAPIClient", return_value=ctx):
        result = await session_end(session_id="sess-test-123", summary="Done.")

    mock.end_session.assert_awaited_once_with(
        session_id="sess-test-123", summary="Done."
    )
    assert result["session"]["is_active"] is False
    assert "message" in result


@pytest.mark.asyncio
async def test_session_end_missing_session_id_returns_error():
    """session_end returns an error dict when session_id is not provided."""
    result = await session_end(session_id="")

    assert "error" in result


@pytest.mark.asyncio
async def test_session_end_api_error():
    """session_end returns error dict on APIError."""
    ctx, _ = _make_client_mock(end_session=APIError(404, "Session not found"))

    with patch("neuroloom_mcp.tools.session_tools.NeuroloomAPIClient", return_value=ctx):
        result = await session_end(session_id="sess-missing")

    assert "error" in result
    assert result.get("status_code") == 404


# ---------------------------------------------------------------------------
# session_get_context
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_session_get_context_returns_full_context():
    """session_get_context returns the full context payload from the API."""
    ctx, mock = _make_client_mock(
        get_session_context=SAMPLE_CONTEXT,
        record_memory_retrieval={"ok": True},
    )

    with patch("neuroloom_mcp.tools.session_tools.NeuroloomAPIClient", return_value=ctx):
        result = await session_get_context(
            session_id="sess-test-123", max_memories=5
        )

    mock.get_session_context.assert_awaited_once_with(
        session_id="sess-test-123", max_memories=5
    )
    assert result == SAMPLE_CONTEXT


@pytest.mark.asyncio
async def test_session_get_context_missing_session_id_returns_error():
    """session_get_context returns an error dict when session_id is empty."""
    result = await session_get_context(session_id="")

    assert "error" in result


@pytest.mark.asyncio
async def test_session_get_context_api_error():
    """session_get_context returns error dict on APIError."""
    ctx, _ = _make_client_mock(
        get_session_context=APIError(404, "Session not found")
    )

    with patch("neuroloom_mcp.tools.session_tools.NeuroloomAPIClient", return_value=ctx):
        result = await session_get_context(session_id="sess-missing")

    assert "error" in result
    assert result.get("status_code") == 404


@pytest.mark.asyncio
async def test_session_get_context_records_retrieval_for_memories():
    """session_get_context calls record_memory_retrieval for each memory in context."""
    ctx, mock = _make_client_mock(
        get_session_context=SAMPLE_CONTEXT,
        record_memory_retrieval={"ok": True},
    )

    with patch("neuroloom_mcp.tools.session_tools.NeuroloomAPIClient", return_value=ctx):
        await session_get_context(session_id="sess-test-123")

    # SAMPLE_CONTEXT has one memory (SAMPLE_MEMORY with memory_id "mem-deadbeef")
    mock.record_memory_retrieval.assert_awaited_once_with("mem-deadbeef")
