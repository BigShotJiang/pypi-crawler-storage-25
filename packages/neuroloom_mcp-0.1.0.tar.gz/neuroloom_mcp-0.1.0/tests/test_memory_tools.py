"""
Tests for memory tool functions in neuroloom_mcp.tools.memory_tools.

All HTTP calls are mocked at the NeuroloomAPIClient level to verify:
  - Correct HTTP method and path delegation
  - Request body construction
  - Response passthrough
  - Error response handling
  - Connection error handling
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from neuroloom_mcp.client import APIError
from neuroloom_mcp.tools.memory_tools import (
    memory_by_file,
    memory_get_detail,
    memory_get_index,
    memory_get_related,
    memory_get_timeline,
    memory_search,
    memory_store,
)
from tests.conftest import SAMPLE_MEMORY, SAMPLE_SEARCH_RESPONSE


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_client_mock(**method_returns):
    """Build a mock NeuroloomAPIClient context manager.

    ``method_returns`` maps method names to their return values (or exceptions).
    """
    mock = AsyncMock()
    for name, value in method_returns.items():
        if isinstance(value, Exception):
            getattr(mock, name).side_effect = value
        else:
            getattr(mock, name).return_value = value

    # Make it work as an async context manager
    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=mock)
    ctx.__aexit__ = AsyncMock(return_value=False)
    return ctx, mock


# ---------------------------------------------------------------------------
# memory_search
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_search_delegates_to_client():
    """memory_search calls client.search_memories with the correct arguments."""
    ctx, mock = _make_client_mock(
        search_memories=SAMPLE_SEARCH_RESPONSE,
        record_memory_retrieval={"ok": True},
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_search(
            query="auth patterns",
            memory_types=["decision"],
            limit=5,
        )

    mock.search_memories.assert_awaited_once()
    call_kwargs = mock.search_memories.call_args.kwargs
    assert call_kwargs["query"] == "auth patterns"
    assert call_kwargs["memory_types"] == ["decision"]
    assert call_kwargs["limit"] == 5
    assert result == SAMPLE_SEARCH_RESPONSE


@pytest.mark.asyncio
async def test_memory_search_returns_error_on_api_failure():
    """memory_search returns an error dict when the API raises APIError."""
    ctx, _ = _make_client_mock(
        search_memories=APIError(500, "Internal server error"),
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_search(query="test")

    assert "error" in result
    assert result.get("status_code") == 500


@pytest.mark.asyncio
async def test_memory_search_missing_workspace_returns_error():
    """memory_search returns an error dict when workspace_id is not configured."""
    mock_settings = MagicMock()
    mock_settings.workspace_id = None
    mock_settings.max_search_limit = 100

    with patch("neuroloom_mcp.tools.memory_tools.get_settings", return_value=mock_settings):
        result = await memory_search(query="test")

    assert "error" in result


# ---------------------------------------------------------------------------
# memory_get_detail
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_get_detail_returns_full_record_with_related():
    """memory_get_detail appends related_memories when include_related=True."""
    related_list = [SAMPLE_MEMORY]
    ctx, mock = _make_client_mock(
        get_memory_detail=dict(SAMPLE_MEMORY),
        record_memory_access={"ok": True},
        get_related_memories=related_list,
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_detail(memory_id="mem-deadbeef", include_related=True)

    mock.get_memory_detail.assert_awaited_once_with("mem-deadbeef")
    assert result["related_memories"] == related_list


@pytest.mark.asyncio
async def test_memory_get_detail_skips_related_when_false():
    """memory_get_detail does not call get_related_memories when include_related=False."""
    ctx, mock = _make_client_mock(
        get_memory_detail=dict(SAMPLE_MEMORY),
        record_memory_access={"ok": True},
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_detail(memory_id="mem-deadbeef", include_related=False)

    mock.get_related_memories.assert_not_awaited()
    assert "related_memories" not in result


@pytest.mark.asyncio
async def test_memory_get_detail_error_handling():
    """memory_get_detail returns error dict on APIError."""
    ctx, _ = _make_client_mock(
        get_memory_detail=APIError(404, "Memory not found"),
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_detail(memory_id="mem-missing")

    assert "error" in result
    assert result.get("status_code") == 404


# ---------------------------------------------------------------------------
# memory_get_timeline
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_get_timeline_filters_by_days():
    """memory_get_timeline returns memories within the requested day window."""
    from datetime import datetime, timezone, timedelta

    recent = dict(SAMPLE_MEMORY)
    recent["created_at"] = datetime.now(timezone.utc).isoformat()

    old = dict(SAMPLE_MEMORY)
    old["memory_id"] = "mem-old"
    old["created_at"] = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()

    ctx, _ = _make_client_mock(list_memories=[recent, old])

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_timeline(days=7, limit=50)

    assert result["count"] == 1
    assert result["memories"][0]["memory_id"] == SAMPLE_MEMORY["memory_id"]


@pytest.mark.asyncio
async def test_memory_get_timeline_api_error():
    """memory_get_timeline returns error dict on APIError."""
    ctx, _ = _make_client_mock(list_memories=APIError(503, "API unreachable"))

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_timeline()

    assert "error" in result


# ---------------------------------------------------------------------------
# memory_get_index
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_get_index_returns_trimmed_projection():
    """memory_get_index returns only the lightweight fields (no narrative)."""
    ctx, _ = _make_client_mock(list_memories=[SAMPLE_MEMORY])

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_index(limit=10)

    assert result["count"] == 1
    entry = result["memories"][0]
    assert "memory_id" in entry
    assert "title" in entry
    assert "memory_type" in entry
    # Narrative must not be included in the index projection
    assert "narrative" not in entry


@pytest.mark.asyncio
async def test_memory_get_index_api_error():
    """memory_get_index returns error dict on APIError."""
    ctx, _ = _make_client_mock(list_memories=APIError(500, "Server error"))

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_index()

    assert "error" in result


# ---------------------------------------------------------------------------
# memory_get_related
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_get_related_wraps_list_in_envelope():
    """memory_get_related wraps the raw list in a {memory_id, count, related} envelope."""
    related_list = [SAMPLE_MEMORY]
    ctx, mock = _make_client_mock(get_related_memories=related_list)

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_related(memory_id="mem-deadbeef", limit=5)

    mock.get_related_memories.assert_awaited_once_with("mem-deadbeef", limit=5)
    assert result["memory_id"] == "mem-deadbeef"
    assert result["count"] == 1
    assert result["related"] == related_list


@pytest.mark.asyncio
async def test_memory_get_related_api_error():
    """memory_get_related returns error dict on APIError."""
    ctx, _ = _make_client_mock(
        get_related_memories=APIError(404, "Memory not found")
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_get_related(memory_id="mem-missing")

    assert "error" in result


# ---------------------------------------------------------------------------
# memory_by_file
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_by_file_passes_file_filter_to_search():
    """memory_by_file calls search_memories with the files filter set."""
    ctx, mock = _make_client_mock(
        search_memories=SAMPLE_SEARCH_RESPONSE,
        record_memory_retrieval={"ok": True},
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_by_file(file_path="src/models.py", limit=15)

    call_kwargs = mock.search_memories.call_args.kwargs
    assert call_kwargs["files"] == ["src/models.py"]
    assert call_kwargs["limit"] == 15

    assert result["file_path"] == "src/models.py"
    assert result["count"] == SAMPLE_SEARCH_RESPONSE["count"]


@pytest.mark.asyncio
async def test_memory_by_file_api_error():
    """memory_by_file returns error dict on APIError."""
    ctx, _ = _make_client_mock(
        search_memories=APIError(503, "API unreachable")
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_by_file(file_path="any/file.py")

    assert "error" in result


# ---------------------------------------------------------------------------
# memory_store
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_store_delegates_all_params():
    """memory_store passes all parameters to client.store_memory."""
    ctx, mock = _make_client_mock(store_memory=SAMPLE_MEMORY)

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_store(
            title="Test pattern",
            memory_type="pattern",
            content="The narrative text.",
            tags=["testing"],
            files=["tests/test_models.py"],
            importance=0.6,
            confidence=0.7,
        )

    call_kwargs = mock.store_memory.call_args.kwargs
    assert call_kwargs["title"] == "Test pattern"
    assert call_kwargs["memory_type"] == "pattern"
    assert call_kwargs["content"] == "The narrative text."
    assert call_kwargs["tags"] == ["testing"]
    assert call_kwargs["files"] == ["tests/test_models.py"]
    assert call_kwargs["importance"] == 0.6
    assert call_kwargs["confidence"] == 0.7
    assert result == SAMPLE_MEMORY


@pytest.mark.asyncio
async def test_memory_store_api_error():
    """memory_store returns error dict on APIError."""
    ctx, _ = _make_client_mock(
        store_memory=APIError(422, "Validation error")
    )

    with patch("neuroloom_mcp.tools.memory_tools.NeuroloomAPIClient", return_value=ctx):
        result = await memory_store(
            title="t", memory_type="pattern", content="c"
        )

    assert "error" in result
    assert result.get("status_code") == 422
