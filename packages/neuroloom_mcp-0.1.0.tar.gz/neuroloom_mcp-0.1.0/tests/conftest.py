"""
Shared fixtures for the neuroloom_mcp test suite.

All tests that call tool functions do so with mocked HTTP transport so no
real Neuroloom API is required. The ``mock_client`` fixture patches
NeuroloomAPIClient at the point it is imported by the tool modules.
"""

import json
import pytest
import httpx

from unittest.mock import AsyncMock, MagicMock, patch


# ---------------------------------------------------------------------------
# Settings override — prevent validation errors for missing env vars
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def override_settings(monkeypatch):
    """Inject minimal valid settings for every test."""
    monkeypatch.setenv("MEMORIES_API_URL", "http://test-api.local")
    monkeypatch.setenv("MEMORIES_API_TOKEN", "test-token-abc123")
    monkeypatch.setenv("MEMORIES_WORKSPACE_ID", "ws-00000000-0000-0000-0000-000000000000")
    monkeypatch.setenv("MEMORIES_MCP_PUBLIC_URL", "https://mcp.test.local/mcp")  # NEW

    # Bust the lru_cache so our env vars are picked up
    from neuroloom_mcp import config
    config.get_settings.cache_clear()
    yield
    config.get_settings.cache_clear()


# ---------------------------------------------------------------------------
# Shared sample payloads
# ---------------------------------------------------------------------------


SAMPLE_MEMORY = {
    "memory_id": "mem-deadbeef",
    "title": "Use selectinload for FK joins",
    "memory_type": "pattern",
    "narrative": "Always use selectinload() for ForeignKey relationships.",
    "tags": ["sqlalchemy", "orm"],
    "concepts": ["N+1", "query optimisation"],
    "source_files": ["api/models.py"],
    "importance_score": 0.8,
    "confidence_score": 0.9,
    "created_at": "2026-01-15T10:00:00+00:00",
    "access_count": 2,
    "retrieval_count": 5,
}

SAMPLE_SEARCH_RESPONSE = {
    "count": 1,
    "query": "sqlalchemy join",
    "filters": {"workspace_id": "ws-00000000-0000-0000-0000-000000000000"},
    "results": [
        {
            "memory": SAMPLE_MEMORY,
            "score": 0.87,
            "match_type": "semantic",
        }
    ],
}

SAMPLE_SESSION = {
    "session_id": "sess-test-123",
    "workspace_id": "ws-00000000-0000-0000-0000-000000000000",
    "project_name": "neuroloom",
    "branch_name": "main",
    "is_active": True,
    "started_at": "2026-03-21T09:00:00+00:00",
    "ended_at": None,
    "summary": None,
    "metadata": {},
}

SAMPLE_CONTEXT = {
    "session": SAMPLE_SESSION,
    "context": {
        "memories": [SAMPLE_MEMORY],
        "recent_sessions": [],
    },
}


# ---------------------------------------------------------------------------
# Mock HTTP response builder
# ---------------------------------------------------------------------------


def make_response(payload, status_code: int = 200) -> httpx.Response:
    """Build a mock httpx.Response with a JSON body."""
    content = json.dumps(payload).encode()
    return httpx.Response(
        status_code=status_code,
        headers={"Content-Type": "application/json"},
        content=content,
    )


def make_error_response(status_code: int, detail: str) -> httpx.Response:
    content = json.dumps({"detail": detail}).encode()
    return httpx.Response(
        status_code=status_code,
        headers={"Content-Type": "application/json"},
        content=content,
    )
