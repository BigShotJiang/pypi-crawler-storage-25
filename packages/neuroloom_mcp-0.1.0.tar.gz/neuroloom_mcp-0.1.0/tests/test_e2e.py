"""
MCP E2E tests against a live Neuroloom API.

These tests exercise the full tool-call path:
    MCP tool function → NeuroloomAPIClient → real HTTP → real API → real DB

Skip conditions:
    Tests are skipped when NEUROLOOM_E2E_API_URL and NEUROLOOM_E2E_API_TOKEN
    environment variables are not set, or when the API is not reachable.

    To run against the local Docker stack:
        export NEUROLOOM_E2E_API_URL=http://localhost:8000
        export NEUROLOOM_E2E_API_TOKEN=<raw key from workspace setup>
        export NEUROLOOM_E2E_WORKSPACE_ID=<workspace uuid>
        pytest mcp/tests/test_e2e.py -v

    In CI the variables are injected from secrets. If they are absent, the
    tests are skipped (not failed) to avoid blocking the unit test pipeline.

Test isolation:
    Each test creates its own session/memory and tears down after itself via
    fixture cleanup. The live API's TRUNCATE-based isolation does NOT apply
    here — tests must manage their own data.

Tool call ordering:
    session_start → memory_store → memory_search → memory_get_detail → session_end

    This mirrors a real Claude Code session lifecycle and validates that the
    full path from MCP tool to persisted knowledge graph works end-to-end.
"""

from __future__ import annotations

import os
from typing import Any

import httpx
import pytest

# ---------------------------------------------------------------------------
# Skip condition: environment variables must be present and API reachable
# ---------------------------------------------------------------------------

_E2E_API_URL = os.environ.get("NEUROLOOM_E2E_API_URL", "")
_E2E_API_TOKEN = os.environ.get("NEUROLOOM_E2E_API_TOKEN", "")
_E2E_WORKSPACE_ID = os.environ.get("NEUROLOOM_E2E_WORKSPACE_ID", "")

_E2E_CONFIGURED = bool(_E2E_API_URL and _E2E_API_TOKEN and _E2E_WORKSPACE_ID)

# Reason string shown when tests are skipped
_SKIP_REASON = (
    "E2E tests require NEUROLOOM_E2E_API_URL, NEUROLOOM_E2E_API_TOKEN, and "
    "NEUROLOOM_E2E_WORKSPACE_ID environment variables."
)


def _api_reachable() -> bool:
    """Return True if the E2E API URL responds to /health."""
    if not _E2E_CONFIGURED:
        return False
    try:
        response = httpx.get(f"{_E2E_API_URL}/health", timeout=5.0)
        return response.status_code == 200
    except Exception:
        return False


_skip_e2e = pytest.mark.skipif(
    not _E2E_CONFIGURED or not _api_reachable(),
    reason=_SKIP_REASON,
)


# ---------------------------------------------------------------------------
# Settings override for E2E tests
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def e2e_settings(monkeypatch):
    """
    Override MCP settings to point at the live E2E API.

    This replaces the unit-test settings injected by the shared conftest so
    that tool functions talk to the real API rather than the mock.
    """
    if not _E2E_CONFIGURED:
        return  # no-op when not configured

    monkeypatch.setenv("MEMORIES_API_URL", _E2E_API_URL)
    monkeypatch.setenv("MEMORIES_API_TOKEN", _E2E_API_TOKEN)
    monkeypatch.setenv("MEMORIES_WORKSPACE_ID", _E2E_WORKSPACE_ID)

    from neuroloom_mcp import config
    config.get_settings.cache_clear()
    yield
    config.get_settings.cache_clear()


# ---------------------------------------------------------------------------
# E2E tests
# ---------------------------------------------------------------------------


@_skip_e2e
class TestMCPSessionLifecycle:
    """E2E tests for session_start and session_end tools."""

    async def test_session_start_returns_session_and_context(self) -> None:
        """session_start must return a session dict and a context dict."""
        from neuroloom_mcp.tools.session_tools import session_start

        result = await session_start(
            workspace_id=_E2E_WORKSPACE_ID,
            project_path="/tmp/e2e-test",
        )

        assert "error" not in result, f"session_start failed: {result.get('error')}"
        assert "session" in result
        assert "context" in result
        assert "message" in result

        session = result["session"]
        assert "session_id" in session
        assert session.get("is_active") is True

    async def test_session_end_marks_session_inactive(self) -> None:
        """
        Start a session and immediately end it. The ended session must have
        is_active=False and ended_at set.
        """
        from neuroloom_mcp.tools.session_tools import session_start, session_end

        # Start
        start_result = await session_start(
            workspace_id=_E2E_WORKSPACE_ID,
            project_path="/tmp/e2e-test",
        )
        assert "error" not in start_result
        session_id = start_result["session"]["session_id"]

        # End
        end_result = await session_end(
            session_id=session_id,
            summary="E2E test session completed.",
        )
        assert "error" not in end_result, f"session_end failed: {end_result.get('error')}"
        assert "session" in end_result
        ended_session = end_result["session"]
        assert ended_session.get("is_active") is False
        assert ended_session.get("ended_at") is not None


@_skip_e2e
class TestMCPMemoryTools:
    """E2E tests for memory_store, memory_search, and memory_get_detail."""

    @pytest.fixture(autouse=True)
    async def _session_lifecycle(self):
        """
        Start a session before each test, store the session_id, and end it
        after the test completes. This mirrors real Claude Code usage.
        """
        from neuroloom_mcp.tools.session_tools import session_start, session_end

        start_result = await session_start(
            workspace_id=_E2E_WORKSPACE_ID,
            project_path="/tmp/e2e-memory-test",
        )
        if "error" in start_result:
            pytest.skip(f"Could not start session: {start_result['error']}")

        self._session_id: str = start_result["session"]["session_id"]
        self._stored_memory_id: str | None = None

        yield

        # Teardown: end the session (best-effort)
        try:
            await session_end(session_id=self._session_id)
        except Exception:
            pass  # teardown failure should not mask test failure

    async def test_memory_store_returns_created_memory(self) -> None:
        """memory_store must return a MemoryResponse dict with memory_id."""
        from neuroloom_mcp.tools.memory_tools import memory_store

        result = await memory_store(
            title="E2E test: async SQLAlchemy pattern",
            memory_type="pattern",
            content=(
                "Always use selectinload() for FK relationships in async SQLAlchemy. "
                "The lazy='raise' default prevents accidental N+1 queries."
            ),
            workspace_id=_E2E_WORKSPACE_ID,
            tags=["sqlalchemy", "e2e-test"],
            importance=0.7,
            confidence=0.9,
        )

        assert "error" not in result, f"memory_store failed: {result.get('error')}"
        assert "memory_id" in result
        assert result["memory_id"].startswith("mem-")
        assert result["title"] == "E2E test: async SQLAlchemy pattern"

        # Store for cleanup in subsequent tests
        self._stored_memory_id = result["memory_id"]

    async def test_memory_search_finds_stored_memory(self) -> None:
        """
        After storing a memory, a keyword search for its content must return
        it in the results (use_semantic=False to avoid embedding dependency).
        """
        from neuroloom_mcp.tools.memory_tools import memory_store, memory_search

        # Store a distinctive memory
        store_result = await memory_store(
            title="E2E search test: pgvector HNSW configuration",
            memory_type="configuration",
            content="HNSW index parameters: m=16, ef_construction=64.",
            workspace_id=_E2E_WORKSPACE_ID,
            tags=["pgvector", "e2e-test"],
        )
        assert "error" not in store_result
        stored_id = store_result["memory_id"]

        # Search using a keyword that should match
        search_result = await memory_search(
            query="HNSW ef_construction",
            workspace_id=_E2E_WORKSPACE_ID,
            limit=20,
        )

        assert "error" not in search_result
        assert "results" in search_result

        memory_ids = [
            r.get("memory", {}).get("memory_id")
            for r in search_result["results"]
        ]
        assert stored_id in memory_ids, (
            f"Stored memory {stored_id} not found in search results. "
            f"Got: {memory_ids[:5]}"
        )

    async def test_memory_get_detail_returns_full_memory(self) -> None:
        """memory_get_detail must return the full memory with relationship fields."""
        from neuroloom_mcp.tools.memory_tools import memory_store, memory_get_detail

        # Store a memory
        store_result = await memory_store(
            title="E2E detail test: IDOR prevention pattern",
            memory_type="pattern",
            content="All DB queries must include workspace_id filter for tenant isolation.",
            workspace_id=_E2E_WORKSPACE_ID,
            tags=["security", "e2e-test"],
        )
        assert "error" not in store_result
        memory_id = store_result["memory_id"]

        # Get full detail
        detail_result = await memory_get_detail(
            memory_id=memory_id,
            include_related=False,  # no embedding yet — avoid related query
        )

        assert "error" not in detail_result, (
            f"memory_get_detail failed: {detail_result.get('error')}"
        )
        assert detail_result.get("memory_id") == memory_id
        assert "outgoing_relationships" in detail_result
        assert "incoming_relationships" in detail_result
        assert isinstance(detail_result["outgoing_relationships"], list)

    async def test_session_get_context_returns_session_and_memories(self) -> None:
        """session_get_context must return a context payload with session info."""
        from neuroloom_mcp.tools.session_tools import session_get_context

        result = await session_get_context(
            session_id=self._session_id,
            max_memories=5,
        )

        assert "error" not in result, (
            f"session_get_context failed: {result.get('error')}"
        )
        assert "session" in result or "context" in result


@_skip_e2e
class TestMCPErrorHandling:
    """E2E tests for error path handling in MCP tools."""

    async def test_memory_get_detail_unknown_id_returns_error_dict(self) -> None:
        """
        Requesting a non-existent memory must return an error dict (not raise),
        with a meaningful error message and status_code 404.
        """
        from neuroloom_mcp.tools.memory_tools import memory_get_detail

        result = await memory_get_detail(
            memory_id="mem-does-not-exist-at-all",
            include_related=False,
        )

        assert "error" in result
        assert result.get("status_code") == 404

    async def test_session_end_unknown_session_returns_error_dict(self) -> None:
        """Ending a non-existent session must return an error dict."""
        from neuroloom_mcp.tools.session_tools import session_end

        result = await session_end(session_id="sess-does-not-exist")

        assert "error" in result

    async def test_memory_search_missing_workspace_id_returns_error_dict(self) -> None:
        """
        Calling memory_search without a workspace_id when
        MEMORIES_WORKSPACE_ID is not set must return an error dict.
        """
        from neuroloom_mcp.tools.memory_tools import memory_search

        # Temporarily clear workspace_id from settings
        import importlib
        from neuroloom_mcp import config as mcp_config

        original_ws_id = _E2E_WORKSPACE_ID

        try:
            # Override settings to simulate missing workspace_id
            import os
            os.environ.pop("MEMORIES_WORKSPACE_ID", None)
            mcp_config.get_settings.cache_clear()

            result = await memory_search(
                query="test",
                workspace_id=None,  # explicitly no workspace
            )
            assert "error" in result
        finally:
            os.environ["MEMORIES_WORKSPACE_ID"] = original_ws_id
            mcp_config.get_settings.cache_clear()
