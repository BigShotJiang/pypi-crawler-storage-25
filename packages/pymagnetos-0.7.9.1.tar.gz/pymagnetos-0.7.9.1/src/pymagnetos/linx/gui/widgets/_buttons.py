"""The grid with main action buttons."""

from PyQt6 import QtWidgets
from PyQt6.QtCore import pyqtSignal


class ButtonsWidget(QtWidgets.QWidget):
    sig_load = pyqtSignal()
    sig_find_f0 = pyqtSignal()
    sig_auto_phase = pyqtSignal()
    sig_export_csv = pyqtSignal()
    sig_save_nexus = pyqtSignal()

    def __init__(self) -> None:
        super().__init__()

        # Create buttons
        self.button_load = QtWidgets.QPushButton("Load data", self)
        self.button_find_f0 = QtWidgets.QPushButton("Find f0", self)
        self.button_auto_phase = QtWidgets.QPushButton("Auto-phase", self)
        self.button_export_csv = QtWidgets.QPushButton("Export as CSV", self)
        self.button_save_nexus = QtWidgets.QPushButton("Save as NeXus", self)

        export_options_widget = self.create_export_options()

        self.disable_buttons()

        self.connect_buttons()

        grid = QtWidgets.QGridLayout()
        grid.addWidget(self.button_load, 0, 0, 1, 2)
        grid.addWidget(self.button_find_f0, 1, 0, 1, 1)
        grid.addWidget(self.button_auto_phase, 1, 1, 1, 1)
        grid.addWidget(self.button_export_csv, 2, 0, 1, 1)
        grid.addWidget(self.button_save_nexus, 2, 1, 1, 1)
        grid.addLayout(export_options_widget, 3, 0, 1, 2)

        self.setLayout(grid)

    @property
    def downsample_factor(self) -> int:
        return self.spinbox_downsample.value()

    @property
    def downsample_averaging(self) -> bool:
        return self.checkbox_downsample.isChecked()

    def create_export_options(self) -> QtWidgets.QHBoxLayout:
        """Create the layout with export options."""
        downsample_label = QtWidgets.QLabel("Downsampling x")
        self.spinbox_downsample = QtWidgets.QSpinBox()

        downsample_widget = QtWidgets.QWidget(self)
        downsample_grid = QtWidgets.QHBoxLayout()
        downsample_grid.addWidget(downsample_label)
        downsample_grid.addWidget(self.spinbox_downsample)
        downsample_widget.setLayout(downsample_grid)

        self.checkbox_downsample = QtWidgets.QCheckBox("Averaging")

        grid = QtWidgets.QHBoxLayout()
        grid.addWidget(downsample_widget)
        grid.addWidget(self.checkbox_downsample)

        return grid

    def connect_buttons(self) -> None:
        self.button_load.clicked.connect(self.sig_load.emit)
        self.button_find_f0.clicked.connect(self.sig_find_f0.emit)
        self.button_auto_phase.clicked.connect(self.sig_auto_phase)
        self.button_export_csv.clicked.connect(self.sig_export_csv.emit)
        self.button_save_nexus.clicked.connect(self.sig_save_nexus.emit)

    def disable_buttons(self) -> None:
        self.button_load.setEnabled(False)
        self.button_find_f0.setEnabled(False)
        self.button_auto_phase.setEnabled(False)
        self.button_export_csv.setEnabled(False)
        self.button_save_nexus.setEnabled(False)

    def enable_buttons(self) -> None:
        self.button_load.setEnabled(False)
        self.button_find_f0.setEnabled(True)
        self.button_auto_phase.setEnabled(True)
        self.button_export_csv.setEnabled(True)
        self.button_save_nexus.setEnabled(True)
