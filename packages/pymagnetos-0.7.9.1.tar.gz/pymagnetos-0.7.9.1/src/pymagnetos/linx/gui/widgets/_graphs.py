"""The graph area widget for Linx."""

import pyqtgraph as pg
from PyQt6 import QtCore, QtWidgets

from pymagnetos.core.gui.widgets import BaseGraphsWidget


class GraphsWidget(BaseGraphsWidget):
    """The graphs area with all the plots."""

    def __init__(self) -> None:
        super().__init__()

        # Create empty canvases in tabs
        field_tab = self.create_field_plot()
        signal_tab = self.create_signal_plot()
        res_time_tab = self.create_sigtime_plot()
        res_field_tab = self.create_sigfield_plot()

        self.init_coordinates_on_hover()
        self.disable_autoSI_prefix()

        # Create a main splitter for rows (vertical)
        main_splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Vertical)

        # Create a top splitter for the first row (horizontal)
        top_splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
        top_splitter.addWidget(field_tab)
        top_splitter.addWidget(signal_tab)
        top_splitter.setStretchFactor(0, 1)  # field_tab stretch factor
        # frame_tab spans 3 columns
        top_splitter.setStretchFactor(1, 3)

        # Create a bottom splitter for the second row (horizontal)
        bottom_splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
        bottom_splitter.addWidget(res_time_tab)
        bottom_splitter.addWidget(res_field_tab)
        # res_time_tab spans 2 columns
        bottom_splitter.setStretchFactor(0, 2)
        # res_field_tab spans 2 columns
        bottom_splitter.setStretchFactor(1, 2)

        # Add the top and bottom splitters to the main splitter
        main_splitter.addWidget(top_splitter)
        main_splitter.addWidget(bottom_splitter)
        main_splitter.setStretchFactor(0, 1)  # top row stretch factor
        main_splitter.setStretchFactor(1, 1)  # bottom row stretch factor

        # Set the main splitter as the central widget
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(main_splitter)
        self.setLayout(layout)

    def create_field_plot(self) -> QtWidgets.QTabWidget:
        tab = QtWidgets.QTabWidget(self)

        # magnetic field (integrated)
        self.field = pg.PlotWidget(title="Magnetic field")
        self.field.setLabel("bottom", "time (s)")
        self.field.setLabel("top", "frame (#) - field not aligned")
        self.field.setLabel("left", "field (T)")
        self.field.showGrid(y=True)
        self._plots_list.add(self.field)

        # pickup coil voltage (measured)
        self.dfield = pg.PlotWidget(title="Pickup")
        self.dfield.setLabel("bottom", "time (s)")
        self.dfield.setLabel("top", "frame (#)")
        self.dfield.setLabel("left", "pickup (V)")
        self.dfield.showGrid(y=True)
        self._plots_list.add(self.dfield)

        tab.addTab(self.field, "B(t)")
        tab.addTab(self.dfield, "Pickup")

        return tab

    def create_signal_plot(self) -> QtWidgets.QTabWidget:
        tab = QtWidgets.QTabWidget(self)

        # Raw signal
        self.raw_signal = pg.PlotWidget(title="Raw signal")
        self.raw_signal.setLabel("bottom", "time (s)")
        self.raw_signal.setLabel("left", "signal (V)")
        self.raw_signal.showGrid(y=True)
        self._plots_list.add(self.raw_signal)

        # Reference signal
        self.reference = pg.PlotWidget(title="Reference signal")
        self.reference.setLabel("bottom", "time (s)")
        self.reference.setLabel("left", "signal (V)")
        self.reference.showGrid(y=True)
        self._plots_list.add(self.reference)

        tab.addTab(self.raw_signal, "Raw signal")
        tab.addTab(self.reference, "Reference signal")

        return tab

    def create_sigtime_plot(self) -> QtWidgets.QTabWidget:
        tab = QtWidgets.QTabWidget(self)

        # vs time
        self.res_time = pg.PlotWidget(title="Resistance (t)")
        self.res_time.setLabel("bottom", "time (s)")
        self.res_time.setLabel("left", "resistance (ohm)")
        self.res_time.showGrid(y=True)
        self._plots_list.add(self.res_time)

        tab.addTab(self.res_time, "Resistance (t)")

        return tab

    def create_sigfield_plot(self) -> QtWidgets.QTabWidget:
        tab = QtWidgets.QTabWidget(self)

        # vs field
        self.res_field = pg.PlotWidget(title="Resistance (B)")
        self.res_field.setLabel("bottom", "field (T)")
        self.res_field.setLabel("left", "resistance (ohm)")
        self.res_field.showGrid(y=True)
        self.res_field.getPlotItem().addLegend()
        self._plots_list.add(self.res_field)

        tab.addTab(self.res_field, "Resistance (B)")

        return tab

    def init_plot_style(self) -> None:
        """Set up PyQtGraph line styles."""
        w0 = 1
        w1 = 1
        self.pen_field = pg.mkPen("#c7c7c7", width=w0)
        self.pen_raw_signal = pg.mkPen("#f9efce", width=w0)
        self.pen_reference = pg.mkPen("#E3F988", width=w0)
        self.pen_in_phase_bdown = pg.mkPen("#00bfff", width=w1)
        self.pen_in_phase_bup = pg.mkPen("#4169e1", width=w1)
        self.pen_out_phase_bdown = pg.mkPen("#ff7f50", width=w1)
        self.pen_out_phase_bup = pg.mkPen("#ff4500", width=w1)

    def enable_rois(self) -> None:
        """Required by core."""
        return
        
    def disable_rois(self) -> None:
        """Required by core."""