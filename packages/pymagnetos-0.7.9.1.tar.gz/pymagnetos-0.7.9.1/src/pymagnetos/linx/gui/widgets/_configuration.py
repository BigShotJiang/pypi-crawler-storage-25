"""The Configuration section of the GUI."""

import numpy as np
from PyQt6.QtCore import pyqtSlot
from pyqtgraph.parametertree import Parameter

from pymagnetos.core.gui.widgets import BaseConfigurationWidget

from ._param_content import ParamContent


class ConfigurationWidget(BaseConfigurationWidget):
    """Configuration Parameter Tree for digital lock-in."""

    def __init__(self, param_content: type[ParamContent]) -> None:
        super().__init__(param_content)

        self.add_extra_parameters()

    def add_extra_parameters(self) -> None:
        """Add extra parameters used only in the GUI."""
        # Show low-pass filter time constant in seconds
        self.filter_tc = Parameter.create(
            name="filter_tc",
            type="float",
            value=self.fc_to_tc(self.settings_parameters["filter_fc"]),
            title="Filter : time constant",
            readonly=True,
            suffix="s",
            siPrefix=True,
        )
        self.host_parameters.addChild(self.filter_tc)

        # Connect filter cut-off frequency change
        self.settings_parameters.child("filter_fc").sigValueChanged.connect(
            self.update_tc
        )

    @pyqtSlot()
    def update_tc(self) -> None:
        """Set low-pass filter time constant when cut-off frequency is changed."""
        self.filter_tc.setValue(self.fc_to_tc(self.settings_parameters["filter_fc"]))

    @staticmethod
    def fc_to_tc(fc: float) -> float:
        """Convert a filter cut-off frequency to its time constant."""
        return 1 / (2 * np.pi * fc)
