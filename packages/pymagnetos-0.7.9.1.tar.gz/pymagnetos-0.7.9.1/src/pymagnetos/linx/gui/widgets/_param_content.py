"""Parameters for the Linx app."""

import numpy as np

from pymagnetos.core.gui.widgets import BaseParamContent


class ParamContent(BaseParamContent):
    PARAMS_TO_PARSE = []
    children_parameters = [
        dict(
            name="pickup_surface",
            type="float",
            limits=[0, np.inf],
            value=None,
            suffix="m²",
            siPrefix=False,
            readonly=True,
            title="Pickup surface",
        ),
        dict(
            name="pickup_samplerate",
            type="float",
            limits=[0, np.inf],
            value=500e3,
            step=1e3,
            suffix="Hz",
            siPrefix=True,
            readonly=True,
            title="Pickup sample rate",
        ),
        dict(
            name="current",
            type="float",
            limits=[0, np.inf],
            value=1,
            step=1,
            suffix="A",
            siPrefix=True,
            readonly=True,
            title="Pickup sample rate",
        ),
        dict(
            name="gain",
            type="float",
            limits=[0, np.inf],
            value=250e3,
            step=1e3,
            siPrefix=False,
            readonly=True,
            title="Ampli. gain",
        ),
        dict(
            name="gain_rms",
            type="bool",
            value=False,
            readonly=True,
            title="Ampli. gain RMS",
        ),
    ]

    children_settings = [
        dict(
            name="ref_name",
            type="list",
            limits=[],
            value="",
            title="Ref. name",
        ),
        dict(
            name="signal_name",
            type="list",
            limits=[],
            value="",
            title="Signal name",
        ),
        dict(
            name="time_offset",
            type="float",
            limits=[-np.inf, np.inf],
            value=0e-6,
            step=0.5e-6,
            suffix="s",
            siPrefix=True,
            title="Signal/Pickup time offset",
        ),
        dict(
            name="f0",
            type="float",
            limits=[0, np.inf],
            step=1e2,
            value=1e4,
            suffix="Hz",
            siPrefix=True,
            title="Demodulation rate"
        ),
        dict(
            name="phase_fit_ncycles",
            type="int",
            limits=[1, np.inf],
            step=1,
            value=10,
            title="Fit phase : number of periods",
        ),
        dict(
            name="filter_order",
            type="int",
            limits=[1, np.inf],
            step=1,
            value=2,
            title="Filter : order",
        ),
        dict(
            name="filter_fc",
            type="float",
            limits=[0, np.inf],
            step=1,
            value=1e3,
            suffix="Hz",
            siPrefix=True,
            title="Filter : cut-off frequency",
        ),
        dict(
            name="phase_offset",
            type="float",
            limits=[-np.inf, np.inf],
            step=1e-3,
            value=0,
            suffix="rad",
            siPrefix=False,
            title="Ref. phase offset"
        ),
        dict(
            name="auto_phase_method",
            type="list",
            value="at peak field",
            limits=["at peak field", "minimum oop"],
            title="Auto-phase method",
        ),
    ]
