"""Worker that connects to an LinxProcessor object."""

from pathlib import Path

from PyQt6.QtCore import pyqtSignal as Signal
from PyQt6.QtCore import pyqtSlot as Slot

from pymagnetos.core.gui import BaseWorker
from pymagnetos.linx import LinxProcessor


class Worker(BaseWorker):
    """
    Wrapper around the LinxProcessor class.

    It exposes the LinxProcessor methods as slots and emits a signal when the task is
    finished.

    Additional signals
    ------------------
    sig_export_csv_finished : emits when the results are saved as CSV.
    """

    _type_processor: type[LinxProcessor] = LinxProcessor
    proc: LinxProcessor

    sig_export_csv_finished = Signal()

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

        # Setup methods arguments
        self._after_load_analysis = True

    @Slot()
    def auto_phase(self) -> None:
        """Find the phase offset that maximizes the in-phase signal."""
        self.proc.find_phase_offset()
        self.run_analysis()

    @Slot(str, int, bool)
    def export_csv(self, fname: str | Path, downsample: int, average: bool) -> None:
        """Export demodulated signal as CSV."""
        self.proc.export_csv(fname, downsample=downsample, average=average)
        self.sig_export_csv_finished.emit()

    def batch_process(
        self,
        args: tuple,
    ) -> None:
        """Batch-process several datasets."""
        self.proc.batch_process(
            *args,
            batch_progress_emitter=self.sig_batch_progress,
        )

        # Emit signals
        self.sig_load_data_finished.emit()
        self.sig_analysis_finished.emit()
        self.sig_batch_finished.emit()