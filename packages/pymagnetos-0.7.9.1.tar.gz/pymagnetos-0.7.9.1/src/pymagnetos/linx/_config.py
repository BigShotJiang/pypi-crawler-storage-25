"""Config class for the LinxProcessor object."""

from pathlib import Path
from typing import Any

from ..core import BaseConfig
from .config_models import LinxConfigurationModel

CONFIG_DEFAULT = Path(__file__).parent / "assets" / "config_default.toml"


class LinxConfig(BaseConfig):
    def __init__(
        self,
        user_file: str | Path | None = None,
        default_file: str | Path | None = None,
        **overrides: Any,
    ) -> None:
        if not default_file:
            default_file = CONFIG_DEFAULT

        super().__init__(LinxConfigurationModel, user_file, default_file, **overrides)

    def load(self, merge_measurement_dict: bool = True) -> None:
        """Load."""
        super().load(merge_measurement_dict=merge_measurement_dict)

    @classmethod
    def loads(cls, json_data: str | bytes, **kwargs) -> "LinxConfig":
        return super()._loads(LinxConfigurationModel, json_data, **kwargs)
