"""
The linx subpackage, a library for digital lock-in.

Provides
--------
- `LinxConfig` : The `Config` object specific to digital lock-in.
- `LinxProcessor` : the `Processor` object specific digital lock-in.
- `config_models` : the `pydantic` models to define the configuration requirements.
- `gui` : a graphical application. It needs to be imported explicitely.
"""

from . import config_models
from ._config import LinxConfig
from ._linxprocessor import LinxProcessor

__all__ = ["LinxConfig", "LinxProcessor", "config_models"]
