"""Pydantic models for the LinxProcessor Config."""

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

from ..core import config_models


class Parameters(config_models.Parameters):
    """Parameters section, things related to the experiment itself."""

    samplerate: float
    current: float
    gain: float
    gain_rms: bool


class Settings(BaseModel):
    """Settings section, things related to the analysis."""

    ref_name: str
    signal_name: str

    detrend_loc: Literal["end", "start", "start+end", "indices"]
    detrend_prct: float
    time_offset: float

    phase_fit_ncycles: int
    filter_order: int
    filter_fc: float
    filter_edge: Literal["pad", "gust"]
    filter_padding_type: Literal["even", "odd", "constant"]
    filter_padding_length: int
    filter_ir_length: int
    
    filter_passband_mult: float
    filter_stopband_mult: float
    filter_passband_att: float
    filter_stopband_att_mult: float
    
    f0: float
    phase_offset: float
    auto_phase_method: Literal["at peak field", "minimum oop"]


class LinxConfigurationModel(BaseModel):
    """A Model specialized for digital lock-in."""

    expid: str
    data_directory: Path

    filenames: dict[str, str | Path] = dict()

    files: dict[str, config_models.File]

    measurements: dict[str, int]

    parameters: Parameters
    settings: Settings

    nx: dict[str, dict[str, Any]]
    nexus: config_models.Nexus

    model_config = ConfigDict(validate_assignment=True)
