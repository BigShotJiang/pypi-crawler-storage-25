"""Worker that connects to an TDOProcessor object."""

from pathlib import Path

from PyQt6.QtCore import pyqtSignal as Signal
from PyQt6.QtCore import pyqtSlot as Slot

from pymagnetos.core.gui import BaseWorker
from pymagnetos.pytdo import TDOProcessor


class Worker(BaseWorker):
    """
    Wrapper around the TDOProcessor class.

    It exposes the EchoProcessor methods as slots and emits a signal when the task is
    finished.

    Additional signals
    ------------------
    sig_crop_finished : emits when the signal is time-cropped.
    sig_offset_finished : emits when the pickup/signal offset is applied.
    sig_tdocsv_finished : emits when the TDO signal is saved as CSV.
    sig_rescsv_finished : emits when the analysis is saved as CSV.
    sig_load_csv_finished : emits when a CSV file is loaded.
    """

    _type_processor: type[TDOProcessor] = TDOProcessor
    proc: TDOProcessor

    sig_crop_finished = Signal()
    sig_offset_finished = Signal()
    sig_tdocsv_finished = Signal()
    sig_rescsv_finished = Signal()
    sig_load_csv_finished = Signal()

    @Slot()
    def crop_signal(self):
        """Crop signal."""
        self.proc.crop_signal(force=True)
        self.sig_crop_finished.emit()

    @Slot()
    def time_offset(self):
        """Apply time offset on experiment time vector."""
        self.proc.apply_time_offset()
        self.sig_offset_finished.emit()

    @Slot(str)
    def save_tdo_csv(self, fname: str | Path):
        """Save TDO signal as CSV."""
        self.proc.export_tdo_csv(filename=fname)
        self.sig_tdocsv_finished.emit()

    @Slot(str)
    def save_results_csv(self, fname: str | Path):
        """Save results as CSV."""
        self.proc.export_results_csv(filename_prefix=fname)
        self.sig_rescsv_finished.emit()

    @Slot(str)
    def load_csv_file(self, fname: str):
        """Save data as CSV file."""
        self.proc.load_csv(fname)
        self.sig_load_csv_finished.emit()
