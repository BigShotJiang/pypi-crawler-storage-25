"""The Configuration section of the GUI."""

from PyQt6.QtCore import pyqtSignal, pyqtSlot
from pyqtgraph.parametertree import Parameter

from pymagnetos.core.gui.widgets import BaseConfigurationWidget

from ._param_content import ParamContent


class ConfigurationWidget(BaseConfigurationWidget):
    """
    Configuration Parameter Tree for TDO experiments.

    Signals
    -------
    sig_syncroi_changed : emitted when the "Sync ROI" checkbox is changed.
    """

    sig_syncroi_changed = pyqtSignal()

    def __init__(self, param_content: type[ParamContent]):
        super().__init__(param_content)

        self._freq2time = 1.0

        self.add_extra_parameters()

    def add_extra_parameters(self):
        """Add extra parameters used only in the GUI."""
        # Sync ROIs parameter
        self.syncroi_parameter = Parameter.create(
            name="syncroi",
            type="bool",
            value=False,
            title="Sync. fit and FFT field-window",
        )
        self.host_parameters.addChild(self.syncroi_parameter)
        self.syncroi_parameter.sigValueChanged.connect(self.sig_syncroi_changed.emit)

        # Show nperseg parameter in µs
        nperseg = Parameter.create(
            name="spectro_time_window",
            type="float",
            readonly=True,
            value=1024 / 100e6,
            suffix="s",
            siPrefix=True,
            title="Spectro: time window (n/persegment)",
        )
        self.host_parameters.addChild(nperseg)
        self.settings_parameters.child("spectro_nperseg").sigValueChanged.connect(
            self.update_spectro_time_window
        )

    @pyqtSlot()
    def update_spectro_time_window(self):
        """Update the spectro. nperseg setting expressed in time."""
        self.host_parameters["spectro_time_window"] = (
            self.settings_parameters["spectro_nperseg"] / self._freq2time
        )
