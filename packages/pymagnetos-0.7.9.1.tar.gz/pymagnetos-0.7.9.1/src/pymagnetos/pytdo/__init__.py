"""
The `pytdo` subpackage, a library for TDO experiments.

Provides
--------
- `TDOConfig` : The `Config` object specific to TDO experiments.
- `TDOProcessor` : the `Processor` object specific to TDO experiments.
- `config_models` : the `pydantic` models to define the configuration requirements.
- `gui` : a graphical application. It needs to be imported explicitely.
"""

from . import config_models
from ._config import TDOConfig
from ._tdoprocessor import TDOProcessor

__all__ = ["TDOConfig", "TDOProcessor", "config_models"]
