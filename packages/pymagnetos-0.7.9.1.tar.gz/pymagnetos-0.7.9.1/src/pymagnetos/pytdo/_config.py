"""Config class for the TDOProcessor object."""

from pathlib import Path
from typing import Any

from ..core import BaseConfig
from .config_models import TDOConfigurationModel

CONFIG_DEFAULT = Path(__file__).parent / "assets" / "config_default.toml"


class TDOConfig(BaseConfig):
    def __init__(
        self,
        user_file: str | Path | None = None,
        default_file: str | Path | None = None,
        **overrides: Any,
    ) -> None:
        if not default_file:
            default_file = CONFIG_DEFAULT

        super().__init__(TDOConfigurationModel, user_file, default_file, **overrides)

    @classmethod
    def loads(cls, json_data: str | bytes, **kwargs) -> "TDOConfig":
        return super()._loads(TDOConfigurationModel, json_data, **kwargs)
