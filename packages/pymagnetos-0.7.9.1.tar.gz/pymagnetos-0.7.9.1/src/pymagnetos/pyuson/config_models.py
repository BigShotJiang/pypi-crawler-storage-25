"""Pydantic models for the EchoProcessor Config."""

from collections.abc import Sequence
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

from ..core import config_models


class Parameters(config_models.Parameters):
    """Parameters section, things related to the experiment itself."""

    pickup_samplerate: float
    sample_length: float
    sample_speed: float
    detection_mode: str
    logamp_slope: float
    rf_offset: float = 0.0
    discard_first_frames: int


class Settings(BaseModel):
    """Settings section, things related to the analysis."""

    echo_index: int
    frame_indices: Sequence[int]
    rolling_mean_wlen: int
    rolling_mean_subsample: bool
    range_baseline: Sequence[float]
    average_strategy: Literal["after", "before"]
    analysis_window: Sequence[float]
    max_phase_jump: float


class Demodulation(BaseModel):
    """Demodulation section, things related to the digital demodulation process."""

    findsig_nframes: int
    findsig_nstd: float
    findsig_extend: float
    chunksize: int
    decimate_factor: int
    filter_order: int
    filter_fc: float

    f0: float = 0
    auto_find_f0: bool = False
    fft_nframes: int
    detrend: bool


class EchoConfigurationModel(BaseModel):
    """A Model specialized for ultrasound echoes experiment."""

    expid: str
    data_directory: Path

    filenames: dict[str, str | Path] = dict()

    files: dict[str, config_models.File]

    measurements: dict[str, int]

    parameters: Parameters
    settings: Settings

    metadata: config_models.Metadata

    nx: dict[str, dict[str, Any]]
    nexus: config_models.Nexus

    demodulation: Demodulation | None = None

    model_config = ConfigDict(validate_assignment=True)
