"""A widget for batch-processing."""

from PyQt6 import QtWidgets
from PyQt6.QtCore import pyqtSignal

from pymagnetos.core.gui.widgets import BaseBatchProcessingWidget


class BatchProcessingWidget(BaseBatchProcessingWidget):
    """
    A batch processing widget.

    Signals
    -------
    sig_echo_index_changed : emits when the echo index changed.
    """

    sig_echo_index_changed = pyqtSignal()

    def __init__(self) -> None:
        super().__init__()
        self.add_rolling_average_checkbox()

    @property
    def echo_index(self) -> int:
        return self.spinbox_echo_index.value()

    @echo_index.setter
    def echo_index(self, value: int):
        self.spinbox_echo_index.setValue(value)

    def init_edits_widgets(self) -> QtWidgets.QWidget:
        edits_widget = super().init_edits_widgets()

        # Add the echo index spin box
        echo_index_label = QtWidgets.QLabel("Echo index", self)
        self.spinbox_echo_index = QtWidgets.QSpinBox()
        self.spinbox_echo_index.setValue(1)
        self.spinbox_echo_index.valueChanged.connect(self.sig_echo_index_changed)

        grid = QtWidgets.QHBoxLayout()
        grid.addWidget(edits_widget)
        grid.addWidget(echo_index_label)
        grid.addWidget(self.spinbox_echo_index)

        edits_widget_new = QtWidgets.QWidget(self)
        edits_widget_new.setLayout(grid)

        return edits_widget_new

    def add_rolling_average_checkbox(self):
        """Add a "Rolling average checkbox below the buttons."""
        self.checkbox_rolling_average = QtWidgets.QCheckBox("Rolling average", self)
        self.buttons_grid.addWidget(self.checkbox_rolling_average, 1, 3)
        self.wbuttons.setLayout(self.buttons_grid)

    def add_findf0_checkbox(self) -> None:
        """Add a "Find f0" checkbox below the buttons."""
        if hasattr(self, "checkbox_find_f0") and isinstance(
            self.checkbox_find_f0, QtWidgets.QCheckBox
        ):
            # Checkbox already exists
            return
        self.checkbox_find_f0 = QtWidgets.QCheckBox("Find f0", self)
        self.buttons_grid.addWidget(self.checkbox_find_f0, 1, 4)
        self.wbuttons.setLayout(self.buttons_grid)
