"""Command line interface to run the various apps."""

import importlib.metadata
from typing import Annotated

import typer

VERSION = importlib.metadata.version("pymagnetos")


app = typer.Typer()


@app.command()
def pyuson():
    """Run the app for ultrasound experiments."""
    from pymagnetos.pyuson import gui

    gui.run()


@app.command()
def pytdo():
    """Run the app for TDO experiments."""
    from pymagnetos.pytdo import gui

    gui.run()


@app.command()
def linx():
    """Run the app for digital lock-in."""
    from pymagnetos.linx import gui

    gui.run()


def version_callback(value: bool):
    """Print version."""
    if value:
        print(f"pymagnetos version {VERSION}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version", callback=version_callback, help="Show version number and exit."
        ),
    ] = None,
):
    """Handle global options."""
    pass


if __name__ == "__main__":
    app()
