"""Run the CLI when running as module."""

if __name__ == "__main__":
    from . import cli
    cli.main()