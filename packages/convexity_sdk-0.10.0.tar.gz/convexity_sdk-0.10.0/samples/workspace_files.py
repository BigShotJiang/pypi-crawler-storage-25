"""
Convexity SDK - Workspace File Management

This sample demonstrates how to:
- List files and folders in a project workspace
- Create folders
- Upload files (from path and from bytes)
- Search for files by name
- Get file metadata
- Download files via pre-signed URLs
- Move/rename files
- Delete files

Prerequisites:
- A valid API key with WRITE or ADMIN permission
- An existing organization and project.
  Run `create_org_and_project.py` first if they don't exist.
- Workspace S3 storage configured on the server side.
"""

import sys

from convexity_sdk import ConvexityClient

ORG_SLUG = "convexity-sdk-samples"
PROJECT_SLUG = "griffin-it"

# ── Initialise SDK client ───────────────────────────────────────────────
client = ConvexityClient()

# ── Step 1: Resolve project ID ──────────────────────────────────────────
org = client.organizations.get_by_slug(ORG_SLUG)
if org is None or not hasattr(org, "id"):
    print(f'ERROR: Organization "{ORG_SLUG}" not found.', file=sys.stderr)
    raise SystemExit(1)

project = client.projects.get_by_slug(org.id, PROJECT_SLUG)
if project is None or not hasattr(project, "id"):
    print(f'ERROR: Project "{PROJECT_SLUG}" not found.', file=sys.stderr)
    raise SystemExit(1)

project_id: str = project.id
print(f"Using project: {project.name} ({project_id})\n")

# ── Step 2: Create folders ──────────────────────────────────────────────
print("── Creating folders ──")
reports_folder = client.workspace.create_folder(project_id, "reports")
print(f"  Created: {reports_folder.name} (key={reports_folder.key})")

data_folder = client.workspace.create_folder(project_id, "data/raw")
print(f"  Created: {data_folder.name} (key={data_folder.key})")

# ── Step 3: List root workspace ─────────────────────────────────────────
print("\n── Listing root workspace ──")
root_items = client.workspace.list(project_id)
print(f"  Total items: {root_items.total_count}")
for item in root_items.items:
    kind = "DIR " if item.is_folder else "FILE"
    print(f"  [{kind}] {item.name}")

# ── Step 4: Upload files ────────────────────────────────────────────────
print("\n── Uploading files ──")

# Upload from raw bytes
csv_content = b"id,name,value\n1,alpha,100\n2,beta,200\n3,gamma,300\n"
upload_result = client.workspace.upload(
    project_id,
    csv_content,
    path="data/raw",
    file_name="sample.csv",
    mime_type="text/csv",
)
print(f"  Uploaded: {upload_result.key} ({upload_result.size} bytes)")

# Upload another file
readme_content = b"# Project Reports\n\nThis folder contains generated reports.\n"
upload_result2 = client.workspace.upload(
    project_id,
    readme_content,
    path="reports",
    file_name="README.md",
    mime_type="text/markdown",
)
print(f"  Uploaded: {upload_result2.key} ({upload_result2.size} bytes)")

# ── Step 5: List a subfolder ────────────────────────────────────────────
print("\n── Listing data/raw/ ──")
data_items = client.workspace.list(project_id, path="data/raw")
print(f"  Total items: {data_items.total_count}")
for item in data_items.items:
    print(f"  {item.name}  ({item.size} bytes, type={item.content_type})")

# ── Step 6: Search for files ────────────────────────────────────────────
print("\n── Searching for 'sample' ──")
search_results = client.workspace.search(project_id, "sample")
print(f"  Found {search_results.total_count} result(s)")
for item in search_results.items:
    print(f"  {item.key}")

# ── Step 7: Get file info ───────────────────────────────────────────────
print("\n── Getting file info ──")
info = client.workspace.get_info(project_id, "data/raw/sample.csv")
if info:
    print(f"  Name: {info.name}")
    print(f"  Size: {info.size} bytes")
    print(f"  Content-Type: {info.content_type}")
    print(f"  Last Modified: {info.last_modified}")

# ── Step 8: Get download URL ────────────────────────────────────────────
print("\n── Getting download URL ──")
download = client.workspace.download_url(project_id, "data/raw/sample.csv", expires_in=600)
print(f"  URL (expires in {download.expires_in}s): {download.url[:80]}...")

# ── Step 9: Move / rename a file ────────────────────────────────────────
print("\n── Moving file ──")
moved = client.workspace.move(
    project_id,
    source_path="data/raw/sample.csv",
    destination_path="data/raw/dataset.csv",
)
print(f"  Moved to: {moved.key}")

# ── Step 10: Delete files ───────────────────────────────────────────────
print("\n── Cleaning up ──")
client.workspace.delete(project_id, "data/raw/dataset.csv")
print("  Deleted data/raw/dataset.csv")

client.workspace.delete(project_id, "reports/README.md")
print("  Deleted reports/README.md")

client.workspace.delete(project_id, "reports")
print("  Deleted reports/")

client.workspace.delete(project_id, "data")
print("  Deleted data/")

print("\nDone! Workspace sample completed successfully.")
