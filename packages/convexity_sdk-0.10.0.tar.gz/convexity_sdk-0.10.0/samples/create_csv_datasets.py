"""Convexity SDK - Create CSV Datasets

This sample demonstrates how to:
- Upload a dummy CSV file to the project workspace
- Create a CSV dataset from the uploaded file
- Refresh the CSV dataset and inspect its columns
- Query the CSV dataset from the DuckLake warehouse using DuckDB

Prerequisites:
- A valid API key with WRITE or ADMIN permission
- The "Convexity SDK samples" org and "griffin it" project must exist.
  Run `create_org_and_project.py` first if they don't.
- ``duckdb`` Python package installed for the DuckLake query step:
    pip install duckdb   # or:  uv pip install duckdb
"""

import sys
import time

from convexity_api_client.models.csv_dataset_config import CsvDatasetConfig
from convexity_api_client.models.dataset_config import DatasetConfig
from convexity_api_client.models.dataset_type import DatasetType
from convexity_api_client.models.refresh_dataset_payload import RefreshDatasetPayload
from convexity_api_client.models.refresh_mode import RefreshMode
from convexity_api_client.models.worker_task_status import WorkerTaskStatus
import duckdb

from convexity_sdk import ConvexityClient

ORG_SLUG = "convexity-sdk-samples"
PROJECT_SLUG = "griffin-it"
POLL_INTERVAL = 5  # seconds between refresh status polls

# ── Initialise SDK client ───────────────────────────────────────────────
client = ConvexityClient()

# ── Step 1: Verify organization exists ──────────────────────────────────
org = client.organizations.get_by_slug(ORG_SLUG)
if org is None or not hasattr(org, "id"):
    print(
        f'ERROR: Organization "{ORG_SLUG}" not found.\nPlease run create_org_and_project.py first.',
        file=sys.stderr,
    )
    raise SystemExit(1)
print(f"Found organization: {org.name} (id={org.id})")

# ── Step 2: Verify project exists ──────────────────────────────────────
project = client.projects.get_by_slug(org.id, PROJECT_SLUG)
if project is None or not hasattr(project, "id"):
    print(
        f'ERROR: Project "{PROJECT_SLUG}" not found in org "{ORG_SLUG}".\nPlease run create_org_and_project.py first.',
        file=sys.stderr,
    )
    raise SystemExit(1)
print(f"Found project: {project.name} (id={project.id})")


# ── Helper: refresh and wait ────────────────────────────────────────────
def refresh_and_wait(dataset):
    """Trigger an async refresh and poll until it completes or fails."""
    try:
        resp = client.datasets.refresh(dataset.id)
    except ValueError as exc:
        print(
            f"  ERROR: Failed to trigger refresh for '{dataset.name}' – {exc}",
            file=sys.stderr,
        )
        return

    print(f"  Refresh started (task_id={resp.id}) …", end="", flush=True)
    while True:
        time.sleep(POLL_INTERVAL)
        try:
            state = client.datasets.get_refresh_status(dataset.id, resp.id)
        except ValueError:
            print(" error polling status")
            return

        # print current status from payload
        payload = state.payload
        if not isinstance(payload, RefreshDatasetPayload):
            raise ValueError(f"Expected payload of type RefreshDatasetPayload, got {type(payload)}")
        print(f" {payload.progress_message}", end="", flush=True)
        if state.status == WorkerTaskStatus.COMPLETED:
            print(f" COMPLETED ({payload.row_count} rows)")
            return
        if state.status == WorkerTaskStatus.FAILED:
            error_msg = getattr(state, "error", "unknown error")
            print(f" FAILED — {error_msg}")
            return
        print(".", end="", flush=True)


# ── Step 3: Upload a dummy CSV to the project workspace ─────────────────
CSV_CONTENT = b"""product_id,product_name,category,unit_price,units_sold,revenue
P001,Widget Alpha,Electronics,29.99,150,4498.50
P002,Widget Beta,Electronics,49.99,85,4249.15
P003,Gadget Gamma,Accessories,9.99,500,4995.00
P004,Gizmo Delta,Hardware,74.50,60,4470.00
P005,Doohickey Epsilon,Accessories,4.99,1200,5988.00
P006,Thingamajig Zeta,Electronics,19.99,220,4397.80
P007,Whatchamacallit Eta,Hardware,129.00,30,3870.00
P008,Contraption Theta,Accessories,14.99,350,5246.50
P009,Apparatus Iota,Hardware,89.99,45,4049.55
P010,Mechanism Kappa,Electronics,39.99,110,4398.90
"""

CSV_WORKSPACE_PATH = "data/sample_products.csv"

print(f"\nUploading dummy CSV to workspace path: {CSV_WORKSPACE_PATH}")
upload_result = client.workspace.upload(
    project.id,
    CSV_CONTENT,
    path="data",
    file_name="sample_products.csv",
    mime_type="text/csv",
)
print(f"  Uploaded: {upload_result.key} ({upload_result.size} bytes)")

# ── Step 4: Create a CSV dataset from the uploaded file ─────────────────
print("\nCreating CSV dataset …")
csv_dataset = client.datasets.create(
    project_id=project.id,
    name="sample_products",
    description="Dummy product catalogue uploaded as CSV",
    type_=DatasetType.CSV,
    config=DatasetConfig(
        csv=CsvDatasetConfig(
            file_path=CSV_WORKSPACE_PATH,
            delimiter=",",
            has_header=True,
            quote_char='"',
        ),
    ),
    refresh_mode=RefreshMode.MANUAL,
)
print(f"  Created: {csv_dataset.name} (id={csv_dataset.id}, type={csv_dataset.type_})")

# ── Step 5: Refresh the CSV dataset ─────────────────────────────────────
print("\nRefreshing CSV dataset …")
refresh_and_wait(csv_dataset)

# ── Step 6: Inspect columns after refresh ───────────────────────────────
print("\nInspecting CSV dataset columns …")
refreshed_ds = client.datasets.get(csv_dataset.id)
if refreshed_ds is None:
    print("  ERROR: Could not retrieve dataset after refresh.", file=sys.stderr)
else:
    schema = getattr(refreshed_ds, "schema", None)
    if schema:
        print(f"  Dataset '{refreshed_ds.name}' has {len(schema)} columns:")
        for col in schema:
            col_type = getattr(col, "type_", getattr(col, "type", "unknown"))
            print(f"    - {col.name:.<30} {col_type}")
    else:
        print("  No schema available yet (schema is populated after a successful refresh).")

# ── Step 7: Query the CSV dataset from DuckLake ────────────────────────
print("\nQuerying CSV dataset via DuckLake …")

dl_resp = client.datalake.get_info(project_id=project.id)
if dl_resp is None or not dl_resp.available or dl_resp.connection is None:
    msg = getattr(dl_resp, "message", None) or "Datalake not available for this project."
    print(f"  SKIP: {msg}")
else:
    conn_info = dl_resp.connection
    db = duckdb.connect()

    # Install and load required extensions
    db.execute("INSTALL httpfs; LOAD httpfs;")
    db.execute("INSTALL ducklake; LOAD ducklake;")

    # Create S3 secret for DuckDB to access datalake storage
    endpoint = (conn_info.s_3_endpoint or "").replace("https://", "").replace("http://", "")
    secret_sql = f"""CREATE SECRET convexity_s3 (
        TYPE S3,
        KEY_ID '{conn_info.s_3_access_key_id}',
        SECRET '{conn_info.s_3_secret_access_key}',
        ENDPOINT '{endpoint}',
        USE_SSL true,
        URL_STYLE 'path',
        REGION '{conn_info.s_3_region or "auto"}'
    );"""
    db.execute(secret_sql)

    ducklake_name = conn_info.ducklake_name or "datalake"
    attach_sql = f"ATTACH 'ducklake:{conn_info.catalog_path}' AS {ducklake_name} (DATA_PATH '{conn_info.data_path}', READ_ONLY);"
    db.execute(attach_sql)
    db.execute(f"USE {ducklake_name};")
    print(f"  Attached DuckLake as '{ducklake_name}'")

    # DuckLake table names are derived from the dataset ID:
    #   ds_<uuid_with_underscores>
    table_name = f"ds_{csv_dataset.id.replace('-', '_')}"

    # Query 1: Preview the CSV-backed table
    preview_sql = f"SELECT * FROM {ducklake_name}.{table_name} LIMIT 5;"
    print(f"\n  Query: {preview_sql}")
    result = db.execute(preview_sql)
    columns = [desc[0] for desc in result.description]
    rows = result.fetchall()

    header = " | ".join(f"{c:>20}" for c in columns)
    print(f"  {header}")
    print(f"  {'-' * len(header)}")
    for row in rows:
        formatted = " | ".join(f"{str(v):>20}" for v in row)
        print(f"  {formatted}")
    print(f"  ({len(rows)} rows)")

    # Query 2: Aggregate revenue by category
    agg_sql = f"""
    SELECT
        category,
        COUNT(*) AS product_count,
        ROUND(SUM(revenue), 2) AS total_revenue,
        ROUND(AVG(unit_price), 2) AS avg_price
    FROM {ducklake_name}.{table_name}
    GROUP BY category
    ORDER BY total_revenue DESC;
    """
    print(f"\n  Query: {agg_sql.strip()}")
    result = db.execute(agg_sql)
    columns = [desc[0] for desc in result.description]
    rows = result.fetchall()

    header = " | ".join(f"{c:>20}" for c in columns)
    print(f"  {header}")
    print(f"  {'-' * len(header)}")
    for row in rows:
        formatted = " | ".join(f"{str(v):>20}" for v in row)
        print(f"  {formatted}")
    print(f"  ({len(rows)} rows)")

    db.close()

print("\nDone!")
client.close()
