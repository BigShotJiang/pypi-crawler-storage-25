"""Workspace resource client – S3-backed file/folder management."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import BinaryIO

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    create_workspace_folder_v1_workspace_folders_post as _create_folder,
)
from convexity_api_client.api.v1 import (
    delete_workspace_item_v1_workspace_files_delete as _delete,
)
from convexity_api_client.api.v1 import (
    download_workspace_file_v1_workspace_files_download_get as _download,
)
from convexity_api_client.api.v1 import (
    get_workspace_item_info_v1_workspace_files_info_get as _get_info,
)
from convexity_api_client.api.v1 import (
    list_workspace_items_v1_workspace_files_get as _list_items,
)
from convexity_api_client.api.v1 import (
    move_workspace_item_v1_workspace_files_move_post as _move,
)
from convexity_api_client.api.v1 import (
    search_workspace_v1_workspace_search_get as _search,
)
from convexity_api_client.api.v1 import (
    upload_workspace_file_v1_workspace_files_post as _upload,
)
from convexity_api_client.models.body_upload_workspace_file_v1_workspace_files_post import (
    BodyUploadWorkspaceFileV1WorkspaceFilesPost,
)
from convexity_api_client.models.create_folder_request import CreateFolderRequest
from convexity_api_client.models.workspace_download_response import WorkspaceDownloadResponse
from convexity_api_client.models.workspace_item import WorkspaceItem
from convexity_api_client.models.workspace_list_response import WorkspaceListResponse
from convexity_api_client.models.workspace_move_request import WorkspaceMoveRequest
from convexity_api_client.models.workspace_search_response import WorkspaceSearchResponse
from convexity_api_client.models.workspace_upload_response import WorkspaceUploadResponse
from convexity_api_client.types import UNSET, File


class Workspace:
    """Synchronous sub-client for workspace file/folder operations.

    Every method requires a ``project_id`` that scopes operations to the
    project's workspace directory inside the backing S3 bucket.
    """

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    # -- listing / querying ---------------------------------------------------

    def list(
        self,
        project_id: str,
        *,
        path: str = "",
        limit: int = 1000,
    ) -> WorkspaceListResponse:
        """List files and folders at *path* inside the project workspace.

        Parameters
        ----------
        project_id:
            The project that owns the workspace.
        path:
            Relative folder path to list. Defaults to the root (``""``).
        limit:
            Maximum number of items to return. Defaults to ``1000``.
        """
        result = _list_items.sync(
            client=self._client,
            project_id=project_id,
            path=path if path else UNSET,
            limit=limit if limit != 1000 else UNSET,
        )
        if result is None or not isinstance(result, WorkspaceListResponse):
            return WorkspaceListResponse(items=[], path=path, total_count=0)
        return result

    def search(
        self,
        project_id: str,
        query: str,
        *,
        path: str = "",
        limit: int = 200,
    ) -> WorkspaceSearchResponse:
        """Search for files matching *query* inside the project workspace.

        Parameters
        ----------
        project_id:
            The project that owns the workspace.
        query:
            Substring to match against object keys.
        path:
            Optional folder prefix to restrict the search.
        limit:
            Maximum number of results. Defaults to ``200``.
        """
        result = _search.sync(
            client=self._client,
            project_id=project_id,
            q=query,
            path=path if path else UNSET,
            limit=limit if limit != 200 else UNSET,
        )
        if result is None or not isinstance(result, WorkspaceSearchResponse):
            return WorkspaceSearchResponse(items=[], query=query, total_count=0)
        return result

    def get_info(self, project_id: str, path: str) -> WorkspaceItem | None:
        """Get metadata for a single workspace item.

        Returns ``None`` when the item does not exist.
        """
        result = _get_info.sync(
            client=self._client,
            project_id=project_id,
            path=path,
        )
        if isinstance(result, WorkspaceItem):
            return result
        return None

    # -- upload / download ----------------------------------------------------

    def upload(
        self,
        project_id: str,
        file: str | Path | BinaryIO | bytes,
        *,
        path: str = "",
        file_name: str | None = None,
        mime_type: str | None = None,
    ) -> WorkspaceUploadResponse:
        """Upload a file to the project workspace.

        Parameters
        ----------
        project_id:
            The project that owns the workspace.
        file:
            The file to upload.  Accepts a local file-system path (``str``
            or ``Path``), raw ``bytes``, or any readable binary stream.
        path:
            Destination folder path inside the workspace (default: root).
        file_name:
            Optional file name override.  When *file* is a path the name
            is inferred automatically.
        mime_type:
            Optional MIME type.  Inferred when omitted.
        """
        if isinstance(file, (str, Path)):
            file_path = Path(file)
            payload: BinaryIO = open(file_path, "rb")  # noqa: SIM115
            file_name = file_name or file_path.name
        elif isinstance(file, bytes):
            payload = BytesIO(file)
        else:
            payload = file

        body = BodyUploadWorkspaceFileV1WorkspaceFilesPost(
            file=File(payload=payload, file_name=file_name, mime_type=mime_type),
        )
        result = _upload.sync(
            client=self._client,
            project_id=project_id,
            body=body,
            path=path if path else UNSET,
        )
        if not isinstance(result, WorkspaceUploadResponse):
            raise ValueError(f"Unexpected response when uploading file: {result}")
        return result

    def download_url(
        self,
        project_id: str,
        path: str,
        *,
        expires_in: int = 3600,
    ) -> WorkspaceDownloadResponse:
        """Get a pre-signed download URL for a workspace file.

        Parameters
        ----------
        project_id:
            The project that owns the workspace.
        path:
            Path to the file inside the workspace.
        expires_in:
            URL expiry time in seconds. Defaults to ``3600`` (1 hour).
        """
        result = _download.sync(
            client=self._client,
            project_id=project_id,
            path=path,
            expires_in=expires_in if expires_in != 3600 else UNSET,
        )
        if not isinstance(result, WorkspaceDownloadResponse):
            raise ValueError(f"Unexpected response when requesting download URL: {result}")
        return result

    # -- mutations ------------------------------------------------------------

    def create_folder(self, project_id: str, path: str) -> WorkspaceItem:
        """Create a folder (empty prefix) in the project workspace.

        Parameters
        ----------
        project_id:
            The project that owns the workspace.
        path:
            The folder path to create (e.g. ``"reports/2024"``).
        """
        body = CreateFolderRequest(path=path)
        result = _create_folder.sync(
            client=self._client,
            project_id=project_id,
            body=body,
        )
        if not isinstance(result, WorkspaceItem):
            raise ValueError(f"Unexpected response when creating folder: {result}")
        return result

    def move(
        self,
        project_id: str,
        source_path: str,
        destination_path: str,
    ) -> WorkspaceItem:
        """Move or rename a workspace item.

        Parameters
        ----------
        project_id:
            The project that owns the workspace.
        source_path:
            Current path of the item.
        destination_path:
            Desired new path.
        """
        body = WorkspaceMoveRequest(
            source_path=source_path,
            destination_path=destination_path,
        )
        result = _move.sync(
            client=self._client,
            project_id=project_id,
            body=body,
        )
        if not isinstance(result, WorkspaceItem):
            raise ValueError(f"Unexpected response when moving item: {result}")
        return result

    def delete(self, project_id: str, path: str) -> None:
        """Delete a file or folder from the project workspace.

        Parameters
        ----------
        project_id:
            The project that owns the workspace.
        path:
            Path to the item to delete.
        """
        _delete.sync(
            client=self._client,
            project_id=project_id,
            path=path,
        )
