#ifndef ATOM_PROD_AXIS_ONE_H
#define ATOM_PROD_AXIS_ONE_H

#include "common.h"
#include "non_elementwise_full_dom.h"

static PyObject *py_make_prod_axis_one(PyObject *self, PyObject *args)
{
    (void) self;
    PyObject *child_capsule;
    if (!PyArg_ParseTuple(args, "O", &child_capsule))
    {
        return NULL;
    }
    expr *child = (expr *) PyCapsule_GetPointer(child_capsule, EXPR_CAPSULE_NAME);
    if (!child)
    {
        PyErr_SetString(PyExc_ValueError, "invalid child capsule");
        return NULL;
    }

    expr *node = new_prod_axis_one(child);
    if (!node)
    {
        PyErr_SetString(PyExc_RuntimeError, "failed to create prod_axis_one node");
        return NULL;
    }
    expr_retain(node); /* Capsule owns a reference */
    return PyCapsule_New(node, EXPR_CAPSULE_NAME, expr_capsule_destructor);
}

#endif /* ATOM_PROD_AXIS_ONE_H */
