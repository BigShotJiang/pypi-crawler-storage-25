// SPDX-License-Identifier: Apache-2.0

#ifndef ATOM_QUAD_OVER_LIN_H
#define ATOM_QUAD_OVER_LIN_H

#include "bivariate_restricted_dom.h"
#include "common.h"

/* quad_over_lin: y = sum(x^2) / z where x is left, z is right (scalar) */
static PyObject *py_make_quad_over_lin(PyObject *self, PyObject *args)
{
    (void) self;
    PyObject *left_capsule, *right_capsule;
    if (!PyArg_ParseTuple(args, "OO", &left_capsule, &right_capsule))
    {
        return NULL;
    }
    expr *left = (expr *) PyCapsule_GetPointer(left_capsule, EXPR_CAPSULE_NAME);
    expr *right = (expr *) PyCapsule_GetPointer(right_capsule, EXPR_CAPSULE_NAME);
    if (!left || !right)
    {
        PyErr_SetString(PyExc_ValueError, "invalid child capsule");
        return NULL;
    }

    expr *node = new_quad_over_lin(left, right);
    if (!node)
    {
        PyErr_SetString(PyExc_RuntimeError, "failed to create quad_over_lin node");
        return NULL;
    }
    expr_retain(node); /* Capsule owns a reference */
    return PyCapsule_New(node, EXPR_CAPSULE_NAME, expr_capsule_destructor);
}

#endif /* ATOM_QUAD_OVER_LIN_H */
