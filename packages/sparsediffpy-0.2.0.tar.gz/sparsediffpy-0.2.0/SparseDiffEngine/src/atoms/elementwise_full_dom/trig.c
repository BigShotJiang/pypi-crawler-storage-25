#include "atoms/elementwise_full_dom.h"
#include <math.h>

/* ----------------------- sin ----------------------- */
static void sin_forward(expr *node, const double *u)
{
    node->left->forward(node->left, u);
    for (int i = 0; i < node->size; i++)
    {
        node->value[i] = sin(node->left->value[i]);
    }
}

static void sin_local_jacobian(expr *node, double *vals)
{
    double *x = node->left->value;
    for (int j = 0; j < node->size; j++)
    {
        vals[j] = cos(x[j]);
    }
}

static void sin_local_wsum_hess(expr *node, double *out, const double *w)
{
    for (int j = 0; j < node->size; j++)
    {
        out[j] = -w[j] * node->value[j];
    }
}

expr *new_sin(expr *child)
{
    expr *node = new_elementwise(child);
    node->forward = sin_forward;
    node->local_jacobian = sin_local_jacobian;
    node->local_wsum_hess = sin_local_wsum_hess;
    return node;
}

/* ----------------------- cos ----------------------- */
static void cos_forward(expr *node, const double *u)
{
    node->left->forward(node->left, u);
    for (int i = 0; i < node->size; i++)
    {
        node->value[i] = cos(node->left->value[i]);
    }
}

static void cos_local_jacobian(expr *node, double *vals)
{
    double *x = node->left->value;
    for (int j = 0; j < node->size; j++)
    {
        vals[j] = -sin(x[j]);
    }
}

static void cos_local_wsum_hess(expr *node, double *out, const double *w)
{
    for (int j = 0; j < node->size; j++)
    {
        out[j] = -w[j] * node->value[j];
    }
}

expr *new_cos(expr *child)
{
    expr *node = new_elementwise(child);
    node->forward = cos_forward;
    node->local_jacobian = cos_local_jacobian;
    node->local_wsum_hess = cos_local_wsum_hess;
    return node;
}
