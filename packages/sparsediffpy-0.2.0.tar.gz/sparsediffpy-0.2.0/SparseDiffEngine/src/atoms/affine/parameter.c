/*
 * Copyright 2026 Daniel Cederberg and William Zhang
 *
 * This file is part of the DNLP-differentiation-engine project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "atoms/affine.h"
#include "subexpr.h"
#include "utils/tracked_alloc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void forward(expr *node, const double *u)
{
    /* Parameters/constants don't depend on u; values are already set */
    (void) node;
    (void) u;
}

static void jacobian_init_impl(expr *node)
{
    /* Zero jacobian: size x n_vars with 0 nonzeros. */
    node->jacobian = new_csr_matrix(node->size, node->n_vars, 0);
}

static void eval_jacobian(expr *node)
{
    (void) node;
}

static void wsum_hess_init_impl(expr *node)
{
    /* Zero Hessian: n_vars x n_vars with 0 nonzeros. */
    node->wsum_hess = new_csr_matrix(node->n_vars, node->n_vars, 0);
}

static void eval_wsum_hess(expr *node, const double *w)
{
    (void) node;
    (void) w;
}

static bool is_affine(const expr *node)
{
    (void) node;
    return true;
}

expr *new_parameter(int d1, int d2, int param_id, int n_vars, const double *values)
{
    parameter_expr *pnode = (parameter_expr *) SP_CALLOC(1, sizeof(parameter_expr));
    expr *node = &pnode->base;
    init_expr(node, d1, d2, n_vars, forward, jacobian_init_impl, eval_jacobian,
              is_affine, wsum_hess_init_impl, eval_wsum_hess, NULL);

    // TODO we should assert that the values array has the correct size.
    pnode->param_id = param_id;

    if (values == NULL)
    {
        fprintf(stderr, "Parameter values should always be set, this is a bug and"
                        " should be reported\n");
        exit(1);
    }
    memcpy(node->value, values, node->size * sizeof(double));
    return node;
}
