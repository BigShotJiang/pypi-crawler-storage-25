from datetime import datetime
from typing import Optional

from corescope.internal import BaseModel, Field
from corescope.models.adverts import Advert
from corescope.models.packets import Packet


class Node(BaseModel):
    advert_count: Optional[int] = Field(alias="advert_count", default=None)
    battery_mv: Optional[int] = Field(alias="battery_mv", default=None)
    first_seen: Optional[datetime] = Field(alias="first_seen", default=None)
    hash_size: Optional[int] = Field(alias="hash_size", default=None)
    hash_size_inconsistent: Optional[int] = Field(alias="hash_size_inconsistent", default=None)
    last_heard: Optional[datetime] = Field(alias="last_heard", default=None)
    last_seen: Optional[datetime] = Field(alias="last_seen", default=None)
    latitude: Optional[float] = Field(alias="lat", default=None)
    longitude: Optional[float] = Field(alias="lon", default=None)
    multi_byte_evidence: Optional[str] = Field(alias="multi_byte_evidence", default=None)
    multi_byte_max_hash_size: Optional[int] = Field(alias="multi_byte_max_hash_size", default=None)
    multi_byte_status: Optional[str] = Field(alias="multi_byte_status", default=None)
    name: str = Field(alias="name")
    public_key: str = Field(alias="public_key")
    role: str = Field(alias="role")
    temperature_c: Optional[float] = Field(alias="temperature_c", default=None)


class NodeHealthObserver(BaseModel):
    average_rssi: float = Field(alias="avgRssi")
    average_snr: float = Field(alias="avgSnr")
    observer_id: str = Field(alias="observer_id")
    observer_name: str = Field(alias="observer_name")
    packet_count: int = Field(alias="packetCount")


class NodeHealthStats(BaseModel):
    average_hops: Optional[int] = Field(alias="avgHops", default=None)
    average_snr: float = Field(alias="avgSnr")
    last_heard: Optional[datetime] = Field(alias="lastHeard", default=None)
    packets_today: int = Field(alias="packetsToday")
    total_observations: int = Field(alias="totalObservations")
    total_packets: int = Field(alias="totalPackets")
    total_transmissions: int = Field(alias="totalTransmissions")


class BulkNodeHealthEntry(BaseModel):
    latitude: Optional[float] = Field(alias="lat", default=None)
    longitude: Optional[float] = Field(alias="lon", default=None)
    name: str = Field(alias="name")
    observers: list[NodeHealthObserver] = Field(alias="observers", default=[])
    public_key: str = Field(alias="public_key")
    role: str = Field(alias="role")
    stats: NodeHealthStats = Field(alias="stats")


class NodeSummary(BaseModel):
    node: Node = Field(alias="node")
    recent_adverts: list[Advert] = Field(alias="recentAdverts")


class NodeHealthSummary(BaseModel):
    node: Node = Field(alias="node")
    observers: list[NodeHealthObserver] = Field(alias="observers", default=[])
    stats: NodeHealthStats = Field(alias="stats")
    recent_packets: list[Packet] = Field(alias="recentPackets", default=[])
