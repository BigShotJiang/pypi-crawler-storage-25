from typing import Optional
from datetime import datetime

from corescope.internal import BaseModel, Field

class Packet(BaseModel):
    parsed_path: Optional[list[str]] = Field(alias='_parsedPath', default=[])
    decoded_json: str = Field(alias='decoded_json')
    direction: str = Field(alias='direction')
    first_seen: datetime = Field(alias='first_seen')
    hash: str = Field(alias='hash')
    id: int = Field(alias='id')
    observation_count: int = Field(alias='observation_count')
    observer_id: str = Field(alias='observer_id')
    observer_name: str = Field(alias='observer_name')
    path_json: str = Field(alias='path_json')
    payload_type: int = Field(alias='payload_type')
    raw_hex: str = Field(alias='raw_hex')
    resolved_path: Optional[list[str | None]] = Field(alias='resolved_path', default=[])
    route_type: int = Field(alias='route_type')
    rssi: int = Field(alias='rssi')
    snr: float = Field(alias='snr')
    timestamp: datetime = Field(alias='timestamp')


class PacketsSummary(BaseModel):
    packets: list[Packet] = Field(alias='packets')
    total: int = Field(alias='total')
