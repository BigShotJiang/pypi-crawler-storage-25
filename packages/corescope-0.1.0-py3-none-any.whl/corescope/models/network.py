from corescope.internal import BaseModel, Field


class RoleCounts(BaseModel):
    companion: int = Field(alias="companion")
    repeater: int = Field(alias="repeater")
    room: int = Field(alias="room")
    sensor: int = Field(alias="sensor")


class NetworkNodesStatus(BaseModel):
    active: int = Field(alias="active")
    degraded: int = Field(alias="degraded")
    role_counts: RoleCounts = Field(alias="roleCounts")
    silent: int = Field(alias="silent")
    total: int = Field(alias="total")
