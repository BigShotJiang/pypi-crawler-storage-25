import corescope.models as models
from corescope.client import CoreScopeClient

__version__ = "0.1.0"
