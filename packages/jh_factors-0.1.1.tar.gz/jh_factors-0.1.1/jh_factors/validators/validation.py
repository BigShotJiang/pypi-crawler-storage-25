"""
因子有效性验证模块

提供两种验证方法:
1. 截距项验证 (Intercept Validation): OLS回归检验因子收益是否显著
2. Fama-MacBeth两步验证 (Fama-MacBeth Two-Step): 横截面回归检验因子风险溢价是否显著

设计原则:
- 依赖抽象接口，不依赖具体数据源
- 截距项验证接受已计算的因子收益率 DataFrame
- Fama-MacBeth验证接受股票收益率和因子暴露数据
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, List, Dict
import pandas as pd
import numpy as np
import statsmodels.api as sm

# ============================================================================
# Data Classes for Validation Results
# ============================================================================


@dataclass
class FactorTestResult:
    """单个因子检验结果"""
    factor: str
    coefficient: float
    std_error: float
    t_statistic: float
    p_value: float
    significant: bool  # p < 0.05


@dataclass
class InterceptValidationResult:
    """
    截距项验证结果

    对因子收益率序列进行单样本t检验（或对每个因子进行截距回归）
    检验每个因子的均值是否显著不为零
    """
    results: Dict[str, FactorTestResult] = field(default_factory=dict)
    summary: str = ""

    def is_all_significant(self) -> bool:
        """所有因子都显著"""
        return all(r.significant for r in self.results.values())

    def to_dataframe(self) -> pd.DataFrame:
        """转换为DataFrame便于查看"""
        rows = []
        for factor, res in self.results.items():
            rows.append({
                'factor': factor,
                'coefficient': res.coefficient,
                'std_error': res.std_error,
                't_statistic': res.t_statistic,
                'p_value': res.p_value,
                'significant_5pct': res.significant,
            })
        return pd.DataFrame(rows).set_index('factor')


@dataclass
class FMFactorTestResult:
    """Fama-MacBeth单个因子检验结果"""
    factor: str
    # Step 1: lambda_t across months
    lambdas: pd.Series  # monthly factor prices (from cross-sectional reg)
    # Step 2: time-series test
    mean_lambda: float
    std_lambda: float
    t_statistic: float
    p_value: float
    significant: bool


@dataclass
class FamaMacBethValidationResult:
    """
    Fama-MacBeth两步法验证结果

    Step 1: 每月横截面回归 R_i = λ'β + ε 得到 λ_t
    Step 2: λ_t 对时间序列回归，检验 λ 是否显著
    """
    results: Dict[str, FMFactorTestResult] = field(default_factory=dict)
    n_periods: int = 0
    n_stocks: int = 0
    summary: str = ""

    def is_all_significant(self) -> bool:
        """所有因子都显著"""
        return all(r.significant for r in self.results.values())

    def to_dataframe(self) -> pd.DataFrame:
        """转换为DataFrame便于查看"""
        rows = []
        for factor, res in self.results.items():
            rows.append({
                'factor': factor,
                'mean_lambda': res.mean_lambda,
                'std_lambda': res.std_lambda,
                't_statistic': res.t_statistic,
                'p_value': res.p_value,
                'significant_5pct': res.significant,
                'n_periods': len(res.lambdas),
            })
        return pd.DataFrame(rows).set_index('factor')


# ============================================================================
# Intercept Validation (截距项验证)
# ============================================================================


def validate_factor_intercept(
    factor_returns: pd.DataFrame,
    alpha: float = 0.05
) -> InterceptValidationResult:
    """
    截距项验证：对因子收益率进行截距回归（单样本t检验）

    原理：对因子收益率序列做均值为零的单样本t检验
    H0: 因子收益率均值 = 0
    若拒绝H0，说明因子提供了显著的风险溢价

    也可以理解为对因子收益率对截距项做OLS回归：
    R_t = α + ε,  检验 α 是否显著不为零

    Args:
        factor_returns: 因子收益率 DataFrame
            - index: 日期 (datetime)
            - columns: 因子名称 (如 ['mkt', 'smb', 'hml'])
            - 例如 calculate_factor_returns 的返回值
        alpha: 显著性水平，默认 0.05

    Returns:
        InterceptValidationResult，包含每个因子的检验结果

    Example:
        >>> ff3 = calculate_factor_returns('ff3', period='monthly')
        >>> result = validate_factor_intercept(ff3)
        >>> print(result.to_dataframe())
        >>> print(result.is_all_significant())
    """
    try:
        from scipy import stats
    except ImportError:
        raise ImportError("需要安装 scipy: pip install scipy")

    results: Dict[str, FactorTestResult] = {}

    for factor in factor_returns.columns:
        series = factor_returns[factor].dropna()

        if len(series) < 3:
            results[factor] = FactorTestResult(
                factor=factor,
                coefficient=np.nan,
                std_error=np.nan,
                t_statistic=np.nan,
                p_value=np.nan,
                significant=False,
            )
            continue

        # 单样本 t 检验: 检验均值是否显著不为零
        mean = series.mean()
        std = series.std(ddof=1)
        n = len(series)
        se = std / np.sqrt(n)
        t_stat = mean / se if se > 0 else 0.0
        p_value = 2 * (1 - stats.t.cdf(abs(t_stat), df=n - 1))

        results[factor] = FactorTestResult(
            factor=factor,
            coefficient=mean,
            std_error=se,
            t_statistic=t_stat,
            p_value=p_value,
            significant=p_value < alpha,
        )

    # 生成 summary
    sig_count = sum(1 for r in results.values() if r.significant)
    total = len(results)
    summary = (
        f"截距项验证结果: {sig_count}/{total} 个因子显著 (α={alpha})\n"
        f"  显著因子: {[f for f, r in results.items() if r.significant]}\n"
        f"  不显著因子: {[f for f, r in results.items() if not r.significant]}"
    )

    return InterceptValidationResult(results=results, summary=summary)


# ============================================================================
# Fama-MacBeth Two-Step Validation (Machtheod步验证)
# ============================================================================


class FamaMacBethValidator:
    """
    Fama-MacBeth两步法因子有效性验证器

    Step 1: 每月横截面回归
        使用滚动窗口估计每只股票的 beta（用过去 lookback 期）
        然后对每月 t，进行横截面回归：
        R_i,t = λ_1,t * β_1,i + λ_2,t * β_2,i + ... + ε_i,t
        得到每月的因子价格向量 λ_t

    Step 2: 对 λ_t 在时间序列上检验是否显著
        λ_j = γ_0j + u_j
        检验 γ_0j 是否显著不为零

    Attributes:
        alpha: 显著性水平
        min_periods: 最小期数（少于该值不进行检验）
        lookback: 估计beta用的历史期数（默认: monthly=36, daily=252）
        period: 'monthly' 或 'daily'，用于自动推断lookback默认值
    """

    def __init__(
        self,
        alpha: float = 0.05,
        min_periods: int = 12,
        lookback: Optional[int] = None,
        period: str = "monthly"
    ):
        self.alpha = alpha
        self.min_periods = min_periods
        if lookback is None:
            lookback = 36 if period == "monthly" else 252
        self.lookback = lookback

    def validate(
        self,
        stock_returns: pd.DataFrame,
        factor_returns: pd.DataFrame,
        factor_names: Optional[List[str]] = None
    ) -> FamaMacBethValidationResult:
        """
        执行Fama-MacBeth两步法验证

        内部自动用滚动窗口估计个股beta，然后做横截面回归。

        Args:
            stock_returns: 股票收益率
                - 必须包含列: ['symbol', 'date', 'return']
                - 通过 get_stock_returns() 获取
            factor_returns: 因子收益率
                - index: 日期 (datetime)
                - columns: 因子名称 (如 ['mkt', 'smb', 'hml'])
                - 通过 calculate_factor_returns 获取
            factor_names: 因子名称列表
                - 若为None，自动从 factor_returns.columns 获取

        Returns:
            FamaMacBethValidationResult，包含每个因子的检验结果

        Example:
            >>> stock_ret = get_stock_returns(...)
            >>> ff3 = calculate_factor_returns('ff3', period='monthly')
            >>> validator = FamaMacBethValidator(period='monthly')  # lookback=36
            >>> result = validator.validate(stock_ret, ff3)
            >>> print(result.to_dataframe())
        """
        # 确定因子名称
        if factor_names is None:
            factor_names = list(factor_returns.columns)

        # 数据准备
        stock_returns = stock_returns.copy()
        stock_returns['date'] = pd.to_datetime(stock_returns['date'])
        factor_returns = factor_returns.copy()
        if isinstance(factor_returns.index, pd.DatetimeIndex):
            factor_returns.index = pd.to_datetime(factor_returns.index)

        # 每月估计个股beta（滚动窗口）
        beta_df = self._estimate_rolling_betas(
            stock_returns, factor_returns, factor_names
        )

        # 合并用于截面回归
        merged = stock_returns[['symbol', 'date', 'return']].merge(
            beta_df[['symbol', 'date'] + factor_names],
            on=['symbol', 'date'],
            how='inner'
        )

        if merged.empty:
            raise ValueError("股票收益率和beta数据无法匹配")

        n_stocks = merged['symbol'].nunique()
        n_periods = merged['date'].nunique()

        if n_periods < self.min_periods:
            raise ValueError(
                f"时间 period 数量 ({n_periods}) 少于最小要求 ({self.min_periods})"
            )

        # Step 1: 每月横截面回归，得到 lambda_t
        lambda_by_period = self._step1_cross_sectional(merged, factor_names)

        # Step 2: lambda_t 时间序列检验
        results = self._step2_timeseries_test(lambda_by_period, factor_names)

        summary = (
            f"Fama-MacBeth两步法结果: {sum(1 for r in results.values() if r.significant)}/{len(results)} "
            f"个因子显著 (α={self.alpha})\n"
            f"  样本: {n_stocks} 只股票, {n_periods} 期, lookback={self.lookback}期\n"
            f"  显著因子: {[f for f, r in results.items() if r.significant]}\n"
            f"  不显著因子: {[f for f, r in results.items() if not r.significant]}"
        )

        return FamaMacBethValidationResult(
            results=results,
            n_periods=n_periods,
            n_stocks=n_stocks,
            summary=summary,
        )

    def _estimate_rolling_betas(
        self,
        stock_returns: pd.DataFrame,
        factor_returns: pd.DataFrame,
        factor_names: List[str]
    ) -> pd.DataFrame:
        """
        使用滚动窗口估计每只股票的beta

        对每个股票、每个日期，估计过去 lookback 期的beta

        Returns:
            DataFrame with [symbol, date, beta1, beta2, ...]
        """
        import statsmodels.api as sm

        all_betas: List[Dict] = []
        lookback = self.lookback

        # 获取所有股票和日期
        symbols = stock_returns['symbol'].unique()

        for symbol in symbols:
            stock_df = stock_returns[stock_returns['symbol'] == symbol].copy()
            stock_df = stock_df.sort_values('date').reset_index(drop=True)
            dates = stock_df['date'].tolist()

            for i, dt in enumerate(dates):
                # 固定窗口: 取过去 lookback 期
                window_start_idx = max(0, i - lookback + 1)
                window = stock_df.iloc[window_start_idx:i + 1]

                if len(window) < 6:
                    continue

                window_dates = window['date'].tolist()
                window_factors = factor_returns[
                    factor_returns.index.isin(window_dates)
                ]
                window_stock = window.set_index('date').sort_index()

                if len(window_factors) < 6:
                    continue

                common_dates = window_factors.index.intersection(window_stock.index)
                if len(common_dates) < 6:
                    continue

                X = window_factors.loc[common_dates, factor_names].values
                y = window_stock.loc[common_dates, 'return'].values

                # OLS回归估计beta（使用statsmodels）
                try:
                    Xc = sm.add_constant(X, has_constant='add')
                    betas = sm.OLS(y, Xc).fit().params[1:]
                except Exception:
                    betas = [np.nan] * len(factor_names)

                row = {'symbol': symbol, 'date': dt}
                for i_f, f in enumerate(factor_names):
                    row[f] = betas[i_f] if not np.any(np.isnan(betas)) else np.nan
                all_betas.append(row)

        return pd.DataFrame(all_betas)

    def _step1_cross_sectional(
        self,
        data: pd.DataFrame,
        factor_names: List[str]
    ) -> Dict[str, pd.Series]:
        """
        Step 1: 每月横截面回归

        对每个月，运行：
        R_i = λ_1 * β_1,i + λ_2 * β_2,i + ... + ε_i

        使用OLS计算lambda

        Returns:
            Dict[因子名 -> pd.Series(每月lambda)]
        """


        lambda_series: Dict[str, List[float]] = {f: [] for f in factor_names}
        period_list: List[pd.Timestamp] = []

        for date, group in data.groupby('date'):
            period_list.append(pd.Timestamp(date))

            y = group['return'].values
            X = group[factor_names].values

            # 跳过数据不足的情况
            if len(y) < len(factor_names) + 2:
                for f in factor_names:
                    lambda_series[f].append(np.nan)
                continue

            try:
                X_with_const = sm.add_constant(X, has_constant='add')
                fitted = sm.OLS(y, X_with_const).fit()
                for i, f in enumerate(factor_names):
                    lambda_series[f].append(fitted.params[i + 1])
            except Exception:
                for f in factor_names:
                    lambda_series[f].append(np.nan)

        # 转换为 Series，index 为日期
        result: Dict[str, pd.Series] = {}
        for f in factor_names:
            result[f] = pd.Series(
                lambda_series[f],
                index=period_list
            ).sort_index()

        return result

    def _step2_timeseries_test(
        self,
        lambda_by_period: Dict[str, pd.Series],
        factor_names: List[str]
    ) -> Dict[str, FMFactorTestResult]:
        """
        Step 2: λ_t 时间序列检验

        对每个因子 j:
        λ_j,t = γ_0j + u_j
        检验 γ_0j 是否显著不为零（双侧 t 检验）

        Returns:
            Dict[因子名 -> FMFactorTestResult]
        """
        try:
            from scipy import stats
        except ImportError:
            raise ImportError("需要安装 scipy: pip install scipy")

        results: Dict[str, FMFactorTestResult] = {}

        for factor in factor_names:
            lambdas = lambda_by_period[factor].dropna()

            if len(lambdas) < 3:
                results[factor] = FMFactorTestResult(
                    factor=factor,
                    lambdas=lambdas,
                    mean_lambda=np.nan,
                    std_lambda=np.nan,
                    t_statistic=np.nan,
                    p_value=np.nan,
                    significant=False,
                )
                continue

            mean_lambda = lambdas.mean()
            std_lambda = lambdas.std(ddof=1)
            n = len(lambdas)
            se = std_lambda / np.sqrt(n) if n > 0 else np.nan
            t_stat = mean_lambda / se if se > 0 and not np.isnan(se) else 0.0
            p_value = 2 * (1 - stats.t.cdf(abs(t_stat), df=n - 1))

            results[factor] = FMFactorTestResult(
                factor=factor,
                lambdas=lambdas,
                mean_lambda=mean_lambda,
                std_lambda=std_lambda,
                t_statistic=t_stat,
                p_value=p_value,
                significant=p_value < self.alpha,
            )

        return results


# ============================================================================
# Convenience function
# ============================================================================


def validate_factor(
    factor_returns: pd.DataFrame,
    stock_returns: Optional[pd.DataFrame] = None,
    factor_exposures: Optional[pd.DataFrame] = None,
    method: str = "intercept",
    alpha: float = 0.05
) -> InterceptValidationResult | FamaMacBethValidationResult:
    """
    因子有效性验证的便捷入口

    Args:
        factor_returns: 因子收益率 DataFrame
        stock_returns: 股票收益率（FM验证需要）
        factor_exposures: 因子暴露（FM验证需要）
        method: 'intercept' 或 'fama_macbeth'
        alpha: 显著性水平

    Returns:
        InterceptValidationResult 或 FamaMacBethValidationResult
    """
    if method == "intercept":
        return validate_factor_intercept(factor_returns, alpha)
    elif method == "fama_macbeth":
        validator = FamaMacBethValidator(alpha=alpha)
        return validator.validate(stock_returns, factor_returns)
    else:
        raise ValueError(f"Unknown method: {method}")
