"""
Stock Factor Exposure Calculator

Calculates individual stock factor exposures (factor betas)
using regression against factor returns.

This is separate from factor return calculation - it computes
how much each stock is exposed to each factor.

设计：暴露计算接受预计算的数据，不直接依赖数据源
"""
from typing import Optional, List, Dict
import pandas as pd
import numpy as np
import statsmodels.api as sm
from joblib import Parallel, delayed
from ..config import DEFAULT_MIN_OBSERVATIONS, DEFAULT_N_JOBS


class StockExposureCalculator:
    """
    Calculator for stock factor exposures (betas).

    Uses OLS regression to estimate factor loadings:
    R_stock = alpha + beta1*F1 + beta2*F2 + ... + epsilon

    暴露计算接受预计算的数据，不直接依赖数据源
    """

    def __init__(
        self,
        min_observations: int = DEFAULT_MIN_OBSERVATIONS,
        n_jobs: int = DEFAULT_N_JOBS
    ):
        """
        Initialize the exposure calculator.

        Args:
            min_observations: Minimum observations required for regression
            n_jobs: Number of parallel jobs
        """
        self.min_observations = min_observations
        self.n_jobs = n_jobs

    def calculate_single_stock_exposure(
        self,
        stock_returns: pd.Series,
        factor_returns: pd.DataFrame
    ) -> Dict[str, float]:
        """
        Calculate exposure for a single stock (pooled OLS, all periods).

        Args:
            stock_returns: Series of stock returns (indexed by date)
            factor_returns: DataFrame of factor returns (indexed by date)

        Returns:
            Dictionary of factor exposures {factor_name: beta}
        """
        # Align dates
        common_index = stock_returns.index.intersection(factor_returns.index)

        if len(common_index) < self.min_observations:
            return {factor: np.nan for factor in factor_returns.columns}

        stock_ret = stock_returns.loc[common_index]
        fact_ret = factor_returns.loc[common_index]

        # Remove any NaN values
        valid_mask = ~(stock_ret.isna() | fact_ret.isna().any(axis=1))
        stock_ret = stock_ret[valid_mask]
        fact_ret = fact_ret[valid_mask]

        if len(stock_ret) < self.min_observations:
            return {factor: np.nan for factor in factor_returns.columns}

        # Run OLS regression using statsmodels
        X = sm.add_constant(fact_ret.values)
        y = stock_ret.values

        try:
            model = sm.OLS(y, X).fit()
            coefficients = model.params[1:]  # Skip the constant term
            intercept = model.params[0]
        except:
            return {factor: np.nan for factor in factor_returns.columns}

        # Extract coefficients
        exposures = {}
        for i, factor in enumerate(factor_returns.columns):
            exposures[factor] = coefficients[i]

        # Add alpha
        exposures['alpha'] = intercept

        return exposures

    def calculate_rolling_exposures(
        self,
        stock_returns: pd.DataFrame,
        factor_returns: pd.DataFrame,
        lookback_months: int = 24,
        symbols: Optional[List[str]] = None,
        verbose: bool = True
    ) -> pd.DataFrame:
        """
        计算滚动因子暴露（每个股票每个日期一行）

        对每个股票、每个月末，用过去 lookback_months 期（交易日/月）的数据估计 beta

        Args:
            stock_returns: DataFrame with [symbol, date, return]
            factor_returns: DataFrame with factor returns (indexed by date)
            lookback_months: 估计beta用的历史期数（默认24期，月度=24月，日度=24个交易日）
            symbols: 股票列表
            verbose: Whether to print progress

        Returns:
            DataFrame with [symbol, date, factor1, factor2, ..., alpha]
        """
        if stock_returns is None or stock_returns.empty:
            raise ValueError("需要提供 stock_returns 数据")

        if symbols is None:
            symbols = stock_returns['symbol'].unique().tolist()

        stock_returns = stock_returns.copy()
        stock_returns['date'] = pd.to_datetime(stock_returns['date'])
        factor_returns = factor_returns.copy()
        if isinstance(factor_returns.index, pd.DatetimeIndex):
            factor_returns.index = pd.to_datetime(factor_returns.index)

        factor_cols = [c for c in factor_returns.columns if c != 'date']
        all_betas: List[Dict] = []
        lookback = lookback_months  # 期数

        if verbose:
            print(f"Calculating rolling betas for {len(symbols)} stocks, lookback={lookback} periods...")

        for symbol in symbols:
            stock_df = stock_returns[stock_returns['symbol'] == symbol].copy()
            stock_df = stock_df.sort_values('date').reset_index(drop=True)
            dates = stock_df['date'].tolist()

            for i, dt in enumerate(dates):
                # 固定窗口: 取过去 lookback 期
                window_start_idx = max(0, i - lookback + 1)
                window = stock_df.iloc[window_start_idx:i + 1]

                if len(window) < self.min_observations:
                    continue

                window_dates = window['date'].tolist()
                window_factors = factor_returns[factor_returns.index.isin(window_dates)]
                window_stock = window.set_index('date').sort_index()

                if len(window_factors) < self.min_observations:
                    continue

                common = window_factors.index.intersection(window_stock.index)
                if len(common) < self.min_observations:
                    continue

                X = window_factors.loc[common, factor_cols].values
                y = window_stock.loc[common, 'return'].values

                # Remove NaN
                valid = ~(np.isnan(X).any(axis=1) | np.isnan(y))
                X, y = X[valid], y[valid]

                if len(X) < self.min_observations:
                    continue

                try:
                    X_with_const = sm.add_constant(X)
                    model = sm.OLS(y, X_with_const).fit()
                    coefs = model.params[1:]
                    intercept = model.params[0]

                    row = {'symbol': symbol, 'date': dt, 'alpha': intercept}
                    for i_f, f in enumerate(factor_cols):
                        row[f] = coefs[i_f]
                    all_betas.append(row)
                except Exception:
                    continue

        if not all_betas:
            return pd.DataFrame()

        return pd.DataFrame(all_betas)

    def calculate_all_exposures(
        self,
        stock_returns: pd.DataFrame,
        factor_returns: pd.DataFrame,
        symbols: Optional[List[str]] = None,
        verbose: bool = True,
        rolling: bool = True,
        lookback_months: int = 24
    ) -> pd.DataFrame:
        """
        Calculate factor exposures for all stocks.

        Args:
            stock_returns: DataFrame with [symbol, date, return]
            factor_returns: DataFrame with factor returns
            symbols: Optional list of symbols
            verbose: Whether to print progress
            rolling: True=每个日期返回一行（扩展窗口beta），False=每个股票一行（pooled beta）
            lookback_months: 滚动窗口月数（仅rolling=True时生效）

        Returns:
            DataFrame with columns [symbol, date, factor1, factor2, ..., alpha]
            - rolling=True: 每个股票每个日期一行
            - rolling=False: 每个股票一行（最后一个日期的结果）
        """
        if stock_returns is None or stock_returns.empty:
            raise ValueError("需要提供 stock_returns 数据")

        if symbols is None:
            symbols = stock_returns['symbol'].unique().tolist()

        # Ensure date alignment
        stock_returns = stock_returns.copy()
        stock_returns['date'] = pd.to_datetime(stock_returns['date'])
        factor_returns = factor_returns.copy()
        if isinstance(factor_returns.index, pd.DatetimeIndex):
            factor_returns.index = pd.to_datetime(factor_returns.index)

        if rolling:
            # 滚动beta: 每个股票每个日期一行
            return self.calculate_rolling_exposures(
                stock_returns, factor_returns,
                lookback_months=lookback_months,
                symbols=symbols, verbose=verbose
            )

        # Pooledbeta: 每个股票一行
        if verbose:
            print(f"Calculating factor exposures for {len(symbols)} stocks...")

        factor_cols = [c for c in factor_returns.columns if c != 'date']
        factor_ret_matrix = factor_returns[factor_cols]

        results = Parallel(n_jobs=self.n_jobs, verbose=verbose)(
            delayed(self._calculate_for_symbol)(
                symbol, stock_returns, factor_ret_matrix,
                lookback=lookback_months if rolling else None
            )
            for symbol in symbols
        )

        exposures = []
        for result in results:
            if result is not None:
                if rolling:
                    exposures.extend(result)
                else:
                    exposures.append(result)

        if not exposures:
            return pd.DataFrame()

        return pd.DataFrame(exposures)

    def _calculate_for_symbol(
        self,
        symbol: str,
        stock_returns: pd.DataFrame,
        factor_returns: pd.DataFrame,
        lookback: Optional[int] = None
    ) -> Optional[List[Dict]]:
        """
        Calculate exposures for one symbol across all dates.

        Args:
            lookback: If set, use fixed lookback window (last N periods).
                      If None, use expanding window (all history up to date).
        """
        stock_data = stock_returns[stock_returns['symbol'] == symbol].copy()

        if len(stock_data) < self.min_observations:
            return None

        stock_data = stock_data.sort_values('date').reset_index(drop=True)
        dates = stock_data['date'].tolist()
        factor_cols = [c for c in factor_returns.columns if c != 'date']
        results: List[Dict] = []

        for i, dt in enumerate(dates):
            if lookback is not None:
                # Fixed lookback window (last N periods)
                window_start_idx = max(0, i - lookback + 1)
                hist = stock_data.iloc[window_start_idx:i + 1].copy()
            else:
                # Expanding window (all history up to date)
                hist = stock_data.iloc[:i + 1].copy()

            if len(hist) < self.min_observations:
                continue

            hist_indexed = hist.set_index('date').sort_index()
            exposure = self.calculate_single_stock_exposure(
                hist_indexed['return'], factor_returns
            )
            if exposure and not np.isnan(list(exposure.values())[0]):
                row = {'symbol': symbol, 'date': dt}
                row.update(exposure)
                results.append(row)

        return results if results else None


def calculate_stock_exposures(
    stock_returns: pd.DataFrame,
    factor_returns: pd.DataFrame,
    period: str = "monthly",
    lookback: Optional[int] = None,
    rolling: bool = True,
    min_observations: int = DEFAULT_MIN_OBSERVATIONS,
    n_jobs: int = DEFAULT_N_JOBS,

) -> pd.DataFrame:
    """
    Convenience function to calculate stock factor exposures.

    Args:
        stock_returns: DataFrame with [symbol, date, return]
        factor_returns: DataFrame with factor returns
        min_observations: Minimum observations for regression
        n_jobs: Number of parallel jobs
        rolling: True=每个日期返回一行（滚动窗口beta），False=每个股票一行（pooled beta）
        lookback: 滚动窗口期数，若为None则自动推断
        period: 'monthly' 或 'daily'，用于自动推断lookback默认值
            - monthly: 默认36期
            - daily: 默认252期

    Returns:
        DataFrame with [symbol, date, factor1, factor2, ..., alpha]
        - rolling=True: 每个股票每个日期一行
        - rolling=False: 每个股票一行
    """
    if lookback is None:
        lookback = 36 if period == "monthly" else 252

    calculator = StockExposureCalculator(
        min_observations=min_observations,
        n_jobs=n_jobs
    )

    return calculator.calculate_all_exposures(
        stock_returns, factor_returns, rolling=rolling, lookback_months=lookback
    )
