"""
Configuration and Enums for Factor Calculation Framework

Defines factor model types, calculation methods, and time periods.
"""
import os
from enum import Enum
from typing import List, Dict, Optional


class FactorType(Enum):
    """
    Factor model types supported by the framework.

    Each factor type represents a different multi-factor model:
    - FF3: Fama-French Three Factor Model (MKT, SMB, HML)
    - FF5: Fama-French Five Factor Model (MKT, SMB, HML, RMW, CMA)
    - CARHART: Carhart Four Factor Model (MKT, SMB, HML, UMD)
    - NOVY_MARX: Novy-Marx Four Factor Model (MKT, SMB, RMW, CMA)
    - HOU_XUE_ZHANG: Hou-Xue-Zhang Four Factor Model (MKT, ME, IA, ROE)
    - DHS: Daniel-Hirshleifer-Sun Three Factor Model (MKT, SMB, IDIO_VOL)
    """
    FF3 = "ff3"
    FF5 = "ff5"
    CARHART = "carhart"
    NOVY_MARX = "novy_marx"
    HOU_XUE_ZHANG = "hou_xue_zhang"
    DHS = "dhs"
    CAPM = "capm"

    @classmethod
    def list_all(cls) -> List['FactorType']:
        """List all available factor types."""
        return list(cls)

    @classmethod
    def from_value(cls, value: str) -> 'FactorType':
        """Get factor type from string value."""
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"Unknown factor type: {value}")


class CalculationMethod(Enum):
    """
    Factor calculation method.

    - CLASSIC: Classic algorithm (replicates academic papers)
      - Uses value-weighted portfolios
      - Independent sorting with 2x3 or 3x3 breakpoints
      - More rigorous statistical methodology
    - SIMPLE: Simplified algorithm (default)
      - Uses equal-weighted portfolios
      - Simple median-based sorting
      - Faster computation, suitable for daily updates
    """
    CLASSIC = "classic"
    SIMPLE = "simple"

    @classmethod
    def list_all(cls) -> List['CalculationMethod']:
        """List all available calculation methods."""
        return list(cls)


class TimePeriod(Enum):
    """
    Time granularity for factor calculation.

    - MONTHLY: Monthly frequency (default)
    - DAILY: Daily frequency
    """
    MONTHLY = "monthly"
    DAILY = "daily"

    @classmethod
    def list_all(cls) -> List['TimePeriod']:
        """List all available time periods."""
        return list(cls)


# Factor model configuration
# Each factor model defines:
# - name: Display name
# - factors: List of factor names
# - sorting_dims: Dimensions for portfolio sorting
# - portfolio_count: Number of portfolios
# - required_data: Required data fields for this factor
FACTOR_CONFIGS: Dict[FactorType, Dict] = {
    FactorType.FF3: {
        "name": "Fama-French三因子模型",
        "factors": ["mkt", "smb", "hml"],
        "sorting_dims": ["size", "value"],  # Size and Value
        "required_data": ["mkt_cap", "bm"],
    },
    FactorType.FF5: {
        "name": "Fama-French五因子模型",
        "factors": ["mkt", "smb", "hml", "rmw", "cma"],
        "sorting_dims": ["size", "value", "profitability", "investment"],
        "required_data": ["mkt_cap", "bm", "roe", "investment"],
    },
    FactorType.CARHART: {
        "name": "Carhart四因子模型",
        "factors": ["mkt", "smb", "hml", "umd"],
        "sorting_dims": ["size", "momentum"],
        "required_data": ["mkt_cap", "bm", "momentum"],
    },
    FactorType.NOVY_MARX: {
        "name": "Novy-Marx四因子模型",
        "factors": ["mkt", "smb", "rmw", "cma"],
        "sorting_dims": ["size", "profitability"],
        "required_data": ["mkt_cap", "roe"],
    },
    FactorType.HOU_XUE_ZHANG: {
        "name": "Hou-Xue-Zhang四因子模型",
        "factors": ["mkt", "me", "ia", "roe"],
        "sorting_dims": ["size", "investment"],
        "required_data": ["mkt_cap", "investment", "roe"],
    },
    FactorType.DHS: {
        "name": "Daniel-Hirshleifer-Sun三因子模型",
        "factors": ["mkt", "smb", "idio_vol"],
        "sorting_dims": ["size", "idio_vol"],
        "required_data": ["mkt_cap", "idio_vol"],
    },
    FactorType.CAPM: {
        "name": "CAPM单因子模型",
        "factors": ["mkt"],
        "sorting_dims": [],
        "required_data": [],
    },

}


# Default calculation parameters
DEFAULT_MIN_STOCKS = 30  # Minimum stocks required for factor calculation
DEFAULT_MIN_OBSERVATIONS = 24  # Minimum observations for beta calculation
DEFAULT_CHUNK_SIZE = 50  # Chunk size for batch processing
DEFAULT_N_JOBS = min(os.cpu_count() or 1, 4)

# Classic algorithm configuration
# Each factor model defines CLASSIC-specific parameters:
# - breakpoints: Percentile cutoffs for sorting (e.g., [0.3, 0.7] means 30th and 70th percentiles)
# - n_groups: Number of groups per dimension (3 for most models)
# - weighting: Portfolio weighting method ("value" for CLASSIC, "equal" for SIMPLE)
# - factor_definition: How each factor is computed from portfolio returns
CLASSIC_CONFIGS: Dict[FactorType, Dict] = {
    FactorType.FF3: {
        # Fama-French (1993): 2x3 sort on size and book-to-market
        # 50% size breakpoint; 30%/70% BM breakpoints
        "breakpoints": {"size": [0.5], "bm": [0.3, 0.7]},
        "n_groups": 3,  # low, medium, high
        "weighting": "value",
        "factor_definition": {
            "smb": {
                "type": "size Spread",
                "description": "Small minus Big - return spread between small and big size portfolios",
            },
            "hml": {
                "type": "value Spread",
                "description": "High minus Low - return spread between value and growth portfolios",
            },
        },
    },
    FactorType.FF5: {
        # Fama-French (2015): 2x3x3x3 sort on size, BM, OP, INV
        # 50% size breakpoint; 30%/70% for BM, OP, INV
        "breakpoints": {"size": [0.5], "bm": [0.3, 0.7], "roe": [0.3, 0.7], "investment": [0.3, 0.7]},
        "n_groups": 3,
        "weighting": "value",
        "factor_definition": {
            "smb": {
                "type": "size Spread",
            },
            "hml": {
                "type": "value Spread",
            },
            "rmw": {
                "type": "profitability Spread",
                "description": "Robust minus Weak profitability",
            },
            "cma": {
                "type": "investment Spread",
                "description": "Conservative minus Aggressive investment",
            },
        },
    },
    FactorType.CARHART: {
        # Carhart (1997): 2x3 sort on size and momentum
        # 50% size breakpoint; 30%/70% momentum breakpoints
        "breakpoints": {"size": [0.5], "momentum": [0.3, 0.7]},
        "n_groups": 3,
        "weighting": "value",
        "factor_definition": {
            "smb": {
                "type": "size Spread",
            },
            "hml": {
                "type": "value Spread",
            },
            "umd": {
                "type": "momentum Spread",
                "description": "Up minus Down - winner minus loser momentum",
            },
        },
    },
    FactorType.NOVY_MARX: {
        # Novy-Marx (2013): 2x3 sort on size and profitability
        "breakpoints": {"size": [0.5], "roe": [0.3, 0.7]},
        "n_groups": 3,
        "weighting": "value",
        "factor_definition": {
            "smb": {
                "type": "size Spread",
            },
            "rmw": {
                "type": "profitability Spread",
            },
            "cma": {
                "type": "investment Spread",
            },
        },
    },
    FactorType.HOU_XUE_ZHANG: {
        # Hou-Xue-Zhang (2014): 2x3 sort on size and investment (or asset growth)
        "breakpoints": {"size": [0.5], "investment": [0.3, 0.7]},
        "n_groups": 3,
        "weighting": "value",
        "factor_definition": {
            "me": {
                "type": "size Spread",
                "description": "Size factor (ME = market equity)",
            },
            "ia": {
                "type": "investment Spread",
                "description": "Investment factor (IA = investment growth)",
            },
            "roe": {
                "type": "profitability Spread",
            },
        },
    },
    FactorType.DHS: {
        # Daniel-Hirshleifer-Sun (2023): 2x3 sort on size and idio_vol
        "breakpoints": {"size": [0.5], "idio_vol": [0.3, 0.7]},
        "n_groups": 3,
        "weighting": "value",
        "factor_definition": {
            "smb": {
                "type": "size Spread",
            },
            "idio_vol": {
                "type": "idiosyncratic Vol Spread",
                "description": "High idio vol minus Low idio vol",
            },
        },
    },
}


