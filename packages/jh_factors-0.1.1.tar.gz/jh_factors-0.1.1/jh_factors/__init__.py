"""
Jiuhuang Factor Calculation Framework

A factor calculation framework for computing factor returns and stock factor exposures.

设计：每个因子类型对应一个数据准备类 (FactorReturnData子类)

支持的因子模型:
- FF3: Fama-French三因子 (MKT, SMB, HML)
- FF5: Fama-French五因子 (MKT, SMB, HML, RMW, CMA)
- CARHART: Carhart四因子 (MKT, SMB, HML, UMD)
- NOVY_MARX: Novy-Marx四因子 (MKT, SMB, RMW, CMA)
- HOU_XUE_ZHANG: Hou-Xue-Zhang四因子 (MKT, ME, IA, ROE)
- STAMBAUGH_YUAN: Stambaugh-Yuan四因子 (MKT, SMB, MG, PS)
- DHS: Daniel-Hirshleifer-Sun三因子 (MKT, SMB, IDIO_VOL)
- BETAPLUS: BetaPlus四因子 (MKT, SMB, HM, MSM)

Usage:
    # 计算FF3
    from jh_factors import calculate_factor_returns
    ff3 = calculate_factor_returns('ff3', start_date='2020-01-01', end_date='2024-12-31')

    # 计算所有因子
    all_factors = calculate_factor_returns('all')
"""

__version__ = "0.4.0"

# 导出配置
from .config import FactorType, CalculationMethod, TimePeriod

# 导出数据准备类
from .data import (
    FactorReturnData,
    FF3Data,
    FF5Data,
    CARHARTData,
    NOVY_MARXData,
    HOU_XUE_ZHANGData,
    DHSData,
    get_factor_data_class,
)

# 导出因子计算
from .factors import GeneralFactorCalculator
from .main import calculate_factor_returns

# 导出暴露计算
from .exposure import StockExposureCalculator, calculate_stock_exposures

# 导出主入口
from .main import FactorEngine, calculate_exposures

# 导出因子验证
from .validators import (
    validate_factor_intercept,
    validate_factor,
    FamaMacBethValidator,
    InterceptValidationResult,
    FamaMacBethValidationResult,
)

__all__ = [
    # 配置
    "FactorType",
    "CalculationMethod",
    "TimePeriod",
    # 数据准备类
    "FactorReturnData",
    "FF3Data",
    "FF5Data",
    "CARHARTData",
    "NOVY_MARXData",
    "HOU_XUE_ZHANGData",
    "DHSData",
    "CAPMData",
    "get_factor_data_class",
    # 因子计算
    "GeneralFactorCalculator",
    "calculate_factor_returns",
    # 暴露计算
    "StockExposureCalculator",
    "calculate_stock_exposures",
    # 主入口
    "FactorEngine",
    "calculate_exposures",
    # 因子验证
    "validate_factor_intercept",
    "validate_factor",
    "FamaMacBethValidator",
    "InterceptValidationResult",
    "FamaMacBethValidationResult",
]
