"""
通用因子计算器

支持所有因子模型的计算：
- FF3: Fama-French三因子
- FF5: Fama-French五因子
- CARHART: Carhart四因子
- NOVY_MARX: Novy-Marx四因子
- HOU_XUE_ZHANG: Hou-Xue-Zhang四因子
- DHS: Daniel-Hirshleifer-Sun三因子

"""
import os
from typing import Optional, Dict, List, Tuple
import pandas as pd
import numpy as np
from joblib import Parallel, delayed
from ..config import FactorType, CalculationMethod, TimePeriod, FACTOR_CONFIGS, CLASSIC_CONFIGS,DEFAULT_N_JOBS




def _calc_single_date_sorting(
    date,
    group: pd.DataFrame,
    sort_vars: List[str],
    factor_def: Dict[str, tuple],
    rf_lookup: Optional[Dict],
    min_stocks: int
) -> Optional[Dict]:
    """
    并行计算的helper函数：计算单个日期的因子收益（排序法）

    Args:
        date: 日期
        group: 该日期的数据
        sort_vars: 排序变量
        factor_def: 因子定义
        rf_lookup: 无风险利率查询
        min_stocks: 最小股票数

    Returns:
        单日因子收益字典，如果数据不足则返回None
    """
    if len(group) < min_stocks:
        return None

    group = group.copy()

    for var in sort_vars:
        if var in group.columns and group[var].notna().sum() >= 10:
            median = group[var].median()
            group[f'{var}_group'] = group[var].apply(
                lambda x: 'low' if pd.isna(x) or x <= median else 'high'
            )
        else:
            group[f'{var}_group'] = 'all'

    row = {'date': pd.to_datetime(date)}

    # 计算市场收益率并减去无风险利率得到超额收益
    market_return = group['return'].mean()
    if rf_lookup is not None:
        date_key = pd.to_datetime(date)
        rf = rf_lookup.get(date_key, 0.0)
        market_return = market_return - rf
    row['mkt'] = market_return

    for factor_name, (high_group, low_group) in factor_def.items():
        if factor_name == 'mkt':
            continue

        if high_group is None:
            continue

        sort_var = None
        for var in sort_vars:
            if var in ['mkt_cap', 'bm', 'roe', 'investment', 'momentum', 'idio_vol']:
                sort_var = var
                break

        if sort_var is None:
            continue

        high_key = f'{sort_var}_group'
        if high_key not in group.columns:
            continue

        try:
            high_ret = group[group[high_key] == high_group]['return'].mean()
            low_ret = group[group[high_key] == low_group]['return'].mean()

            if pd.notna(high_ret) and pd.notna(low_ret):
                row[factor_name] = high_ret - low_ret
            else:
                row[factor_name] = np.nan
        except Exception:
            row[factor_name] = np.nan

    return row


def _module_value_weighted_return(
    group: pd.DataFrame,
    return_col: str = 'return',
    weight_col: str = 'mkt_cap'
) -> float:
    """模块级市值加权收益率计算"""
    valid = group[[return_col, weight_col]].notna().all(axis=1)
    if valid.sum() == 0:
        return np.nan
    w = group.loc[valid, weight_col]
    r = group.loc[valid, return_col]
    w = w.clip(lower=0)
    if w.sum() == 0:
        return r.mean()
    return (r * w).sum() / w.sum()


def _module_assign_groups(
    series: pd.Series,
    breakpoints: List[float]
) -> pd.Series:
    """模块级分组函数"""
    bounds = [series.quantile(p) for p in breakpoints]
    labels = []
    for val in series:
        if pd.isna(val):
            labels.append('low')
        else:
            assigned = False
            for i, bound in enumerate(bounds):
                if val <= bound:
                    labels.append('low' if i == 0 else ['medium', 'high'][i-1])
                    assigned = True
                    break
            if not assigned:
                labels.append('high')
    return pd.Series(labels, index=series.index)


def _calc_single_date_classic(
    date,
    group: pd.DataFrame,
    factor_type: FactorType,
    classic_config: Dict,
    sorting_dims: List[str],
    min_stocks: int,
    rf_lookup: Optional[Dict]
) -> Optional[Dict]:
    """并行计算的helper函数：计算单个日期的因子收益（CLASSIC法）"""
    if len(group) < min_stocks:
        return None

    group = group.copy()
    breakpoints = classic_config.get("breakpoints", {})
    weighting = classic_config.get("weighting", "value")

    group_labels = {}
    for var in sorting_dims:
        if var in group.columns and group[var].notna().sum() >= 10:
            bps = breakpoints.get(var, [0.5])
            group_labels[var] = _module_assign_groups(group[var], bps)
        else:
            group_labels[var] = pd.Series(['all'] * len(group), index=group.index)

    if len(sorting_dims) == 1:
        group['portfolio'] = group_labels[sorting_dims[0]]
    else:
        for var in sorting_dims:
            group[f'{var}_g'] = group_labels[var]
        portfolio_labels = group[[f'{var}_g' for var in sorting_dims]].apply(
            lambda x: tuple(x.values), axis=1
        )
        group['portfolio'] = portfolio_labels

    if weighting == "value":
        market_return = _module_value_weighted_return(group)
    else:
        market_return = group['return'].mean()

    if rf_lookup is not None:
        date_key = pd.to_datetime(date)
        rf = rf_lookup.get(date_key, 0.0)
        market_return = market_return - rf

    row = {'date': pd.to_datetime(date), 'mkt': market_return}

    if factor_type == FactorType.FF3:
        row.update(_calc_ff3_classic_module(group, classic_config))
    elif factor_type == FactorType.FF5:
        row.update(_calc_ff5_classic_module(group, classic_config))
    elif factor_type == FactorType.CARHART:
        row.update(_calc_carhart_classic_module(group, classic_config))
    elif factor_type == FactorType.NOVY_MARX:
        row.update(_calc_novymarx_classic_module(group, classic_config))
    elif factor_type == FactorType.HOU_XUE_ZHANG:
        row.update(_calc_hxz_classic_module(group, classic_config))
    elif factor_type == FactorType.DHS:
        row.update(_calc_dhs_classic_module(group, classic_config))

    return row


def _calc_ff3_classic_module(group: pd.DataFrame, classic_config: Dict) -> Dict[str, float]:
    """FF3 CLASSIC模块级计算"""
    size_var = 'mkt_cap'
    value_var = 'bm'
    group = group.copy()
    group['size_g'] = group[size_var].apply(
        lambda x: 'small' if pd.isna(x) or x <= group[size_var].median() else 'big'
    )
    bps = classic_config.get("breakpoints", {}).get(value_var, [0.3, 0.7])
    group['value_g'] = _module_assign_groups(group[value_var], bps)

    portfolios = group.groupby(['size_g', 'value_g'])
    small_returns = []
    big_returns = []
    for (size, value), sub in portfolios:
        ret = _module_value_weighted_return(sub)
        if size == 'small':
            small_returns.append(ret)
        else:
            big_returns.append(ret)
    smb = np.mean(small_returns) - np.mean(big_returns) if small_returns and big_returns else np.nan

    high_returns = []
    low_returns = []
    for (size, value), sub in portfolios:
        ret = _module_value_weighted_return(sub)
        if value == 'high':
            high_returns.append(ret)
        elif value == 'low':
            low_returns.append(ret)
    hml = np.mean(high_returns) - np.mean(low_returns) if high_returns and low_returns else np.nan

    return {'smb': smb, 'hml': hml}


def _calc_ff5_classic_module(group: pd.DataFrame, classic_config: Dict) -> Dict[str, float]:
    """FF5 CLASSIC模块级计算"""
    bps = classic_config.get("breakpoints", {})
    size_var = 'mkt_cap'
    size_bps = bps.get(size_var, [0.5])
    group = group.copy()
    group['size_g'] = _module_assign_groups(group[size_var], size_bps)

    for var, var_bps in [('bm', bps.get('bm', [0.3, 0.7])),
                         ('roe', bps.get('roe', [0.3, 0.7])),
                         ('investment', bps.get('investment', [0.3, 0.7]))]:
        if var in group.columns:
            group[f'{var}_g'] = _module_assign_groups(group[var], var_bps)

    portfolios = group.groupby(['size_g', 'bm_g', 'roe_g', 'investment_g'])
    port_returns = {}
    for combo, sub in portfolios:
        port_returns[combo] = _module_value_weighted_return(sub)

    small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
    big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
    smb = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

    high_rets = [v for k, v in port_returns.items() if k[1] == 'high']
    low_rets = [v for k, v in port_returns.items() if k[1] == 'low']
    hml = np.nanmean(high_rets) - np.nanmean(low_rets) if high_rets and low_rets else np.nan

    robust_rets = [v for k, v in port_returns.items() if k[2] == 'high']
    weak_rets = [v for k, v in port_returns.items() if k[2] == 'low']
    rmw = np.nanmean(robust_rets) - np.nanmean(weak_rets) if robust_rets and weak_rets else np.nan

    conservative_rets = [v for k, v in port_returns.items() if k[3] == 'low']
    aggressive_rets = [v for k, v in port_returns.items() if k[3] == 'high']
    cma = np.nanmean(conservative_rets) - np.nanmean(aggressive_rets) if conservative_rets and aggressive_rets else np.nan

    return {'smb': smb, 'hml': hml, 'rmw': rmw, 'cma': cma}


def _calc_carhart_classic_module(group: pd.DataFrame, classic_config: Dict) -> Dict[str, float]:
    """CARHART CLASSIC模块级计算"""
    bps = classic_config.get("breakpoints", {})
    size_var = 'mkt_cap'
    size_bps = bps.get(size_var, [0.5])
    group = group.copy()
    group['size_g'] = _module_assign_groups(group[size_var], size_bps)

    for var, var_bps in [('bm', bps.get('bm', [0.3, 0.7])),
                         ('momentum', bps.get('momentum', [0.3, 0.7]))]:
        if var in group.columns:
            group[f'{var}_g'] = _module_assign_groups(group[var], var_bps)

    portfolios = group.groupby(['size_g', 'bm_g', 'momentum_g'])
    port_returns = {}
    for combo, sub in portfolios:
        port_returns[combo] = _module_value_weighted_return(sub)

    small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
    big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
    smb = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

    high_rets = [v for k, v in port_returns.items() if k[1] == 'high']
    low_rets = [v for k, v in port_returns.items() if k[1] == 'low']
    hml = np.nanmean(high_rets) - np.nanmean(low_rets) if high_rets and low_rets else np.nan

    up_rets = [v for k, v in port_returns.items() if k[2] == 'high']
    down_rets = [v for k, v in port_returns.items() if k[2] == 'low']
    umd = np.nanmean(up_rets) - np.nanmean(down_rets) if up_rets and down_rets else np.nan

    return {'smb': smb, 'hml': hml, 'umd': umd}


def _calc_novymarx_classic_module(group: pd.DataFrame, classic_config: Dict) -> Dict[str, float]:
    """NOVY_MARX CLASSIC模块级计算"""
    bps = classic_config.get("breakpoints", {})
    size_var = 'mkt_cap'
    size_bps = bps.get(size_var, [0.5])
    group = group.copy()
    group['size_g'] = _module_assign_groups(group[size_var], size_bps)

    for var, var_bps in [('roe', bps.get('roe', [0.3, 0.7])),
                         ('investment', bps.get('investment', [0.3, 0.7]))]:
        if var in group.columns:
            group[f'{var}_g'] = _module_assign_groups(group[var], var_bps)

    portfolios = group.groupby(['size_g', 'roe_g', 'investment_g'])
    port_returns = {}
    for combo, sub in portfolios:
        port_returns[combo] = _module_value_weighted_return(sub)

    small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
    big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
    smb = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

    robust_rets = [v for k, v in port_returns.items() if k[1] == 'high']
    weak_rets = [v for k, v in port_returns.items() if k[1] == 'low']
    rmw = np.nanmean(robust_rets) - np.nanmean(weak_rets) if robust_rets and weak_rets else np.nan

    conservative_rets = [v for k, v in port_returns.items() if k[2] == 'low']
    aggressive_rets = [v for k, v in port_returns.items() if k[2] == 'high']
    cma = np.nanmean(conservative_rets) - np.nanmean(aggressive_rets) if conservative_rets and aggressive_rets else np.nan

    return {'smb': smb, 'rmw': rmw, 'cma': cma}


def _calc_hxz_classic_module(group: pd.DataFrame, classic_config: Dict) -> Dict[str, float]:
    """HOU_XUE_ZHANG CLASSIC模块级计算"""
    bps = classic_config.get("breakpoints", {})
    size_var = 'mkt_cap'
    size_bps = bps.get(size_var, [0.5])
    group = group.copy()
    group['size_g'] = _module_assign_groups(group[size_var], size_bps)

    for var, var_bps in [('investment', bps.get('investment', [0.3, 0.7])),
                         ('roe', bps.get('roe', [0.3, 0.7]))]:
        if var in group.columns:
            group[f'{var}_g'] = _module_assign_groups(group[var], var_bps)

    portfolios = group.groupby(['size_g', 'investment_g', 'roe_g'])
    port_returns = {}
    for combo, sub in portfolios:
        port_returns[combo] = _module_value_weighted_return(sub)

    small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
    big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
    me = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

    conservative_rets = [v for k, v in port_returns.items() if k[1] == 'low']
    aggressive_rets = [v for k, v in port_returns.items() if k[1] == 'high']
    ia = np.nanmean(conservative_rets) - np.nanmean(aggressive_rets) if conservative_rets and aggressive_rets else np.nan

    high_rets = [v for k, v in port_returns.items() if k[2] == 'high']
    low_rets = [v for k, v in port_returns.items() if k[2] == 'low']
    roe_factor = np.nanmean(high_rets) - np.nanmean(low_rets) if high_rets and low_rets else np.nan

    return {'me': me, 'ia': ia, 'roe': roe_factor}


def _calc_dhs_classic_module(group: pd.DataFrame, classic_config: Dict) -> Dict[str, float]:
    """DHS CLASSIC模块级计算"""
    bps = classic_config.get("breakpoints", {})
    size_var = 'mkt_cap'
    size_bps = bps.get(size_var, [0.5])
    group = group.copy()
    group['size_g'] = _module_assign_groups(group[size_var], size_bps)

    idio_var = 'idio_vol'
    idio_bps = bps.get(idio_var, [0.3, 0.7])
    if idio_var in group.columns:
        group['idio_vol_g'] = _module_assign_groups(group[idio_var], idio_bps)

    portfolios = group.groupby(['size_g', 'idio_vol_g'])
    port_returns = {}
    for combo, sub in portfolios:
        port_returns[combo] = _module_value_weighted_return(sub)

    small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
    big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
    smb = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

    high_rets = [v for k, v in port_returns.items() if k[1] == 'high']
    low_rets = [v for k, v in port_returns.items() if k[1] == 'low']
    idio_vol_factor = np.nanmean(high_rets) - np.nanmean(low_rets) if high_rets and low_rets else np.nan

    return {'smb': smb, 'idio_vol': idio_vol_factor}


class GeneralFactorCalculator:
    """
    通用因子计算器

    支持通过配置计算所有类型的因子。
    """

    def __init__(
        self,
        factor_type: FactorType,
        method: CalculationMethod = CalculationMethod.SIMPLE,
        period: TimePeriod = TimePeriod.MONTHLY,
        min_stocks: int = 20,
        n_jobs: Optional[int] = None
    ):
        """
        初始化因子计算器

        Args:
            factor_type: 因子类型
            method: 计算方法
            period: 时间周期
            min_stocks: 最小股票数
            n_jobs: 并行任务数，默认为CPU核心数（最多4个）
        """
        self.factor_type = factor_type
        self.method = method
        self.period = period
        self.min_stocks = min_stocks
        self.n_jobs = n_jobs if n_jobs is not None else DEFAULT_N_JOBS

        self.config = FACTOR_CONFIGS[factor_type]
        self.factor_names = self.config["factors"]
        self.sorting_dims = self.config["sorting_dims"]
        self.required_data = self.config["required_data"]

        # CLASSIC配置（如果使用CLASSIC方法）
        self.classic_config = CLASSIC_CONFIGS.get(factor_type, {})

    def calculate(
        self,
        stock_returns: pd.DataFrame,
        market_cap: pd.DataFrame,
        fundamentals: Optional[Dict[str, pd.DataFrame]] = None,
        risk_free_rate: Optional[pd.DataFrame] = None,
        **kwargs
    ) -> pd.DataFrame:
        """
        计算因子收益率

        Args:
            stock_returns: 股票收益率
            market_cap: 市值数据（CAPM时为市场超额收益率数据）
            fundamentals: 基本面数据字典 {field_name: DataFrame}
            risk_free_rate: 无风险利率数据，包含 date, rf 列（年化百分比）

        Returns:
            因子收益率DataFrame
        """
        if self.factor_type == FactorType.CAPM:
            # CAPM: market_cap 实际上是 market_return (mkt_excess)
            market_return = market_cap
            return self._calculate_capm_factor(market_return)
        return self._calculate_from_data(stock_returns, market_cap, fundamentals, risk_free_rate)

    def _calculate_from_data(
        self,
        stock_returns: pd.DataFrame,
        market_cap: pd.DataFrame,
        fundamentals: Optional[Dict[str, pd.DataFrame]] = None,
        risk_free_rate: Optional[pd.DataFrame] = None
    ) -> pd.DataFrame:
        """使用传入的数据计算因子"""
        if stock_returns is None or stock_returns.empty:
            raise ValueError("stock_returns 不能为空")
        if market_cap is None or market_cap.empty:
            raise ValueError("market_cap 不能为空")

        df = stock_returns.merge(
            market_cap[['symbol', 'date', 'mkt_cap']],
            on=['symbol', 'date'],
            how='inner'
        )

        # 处理无风险利率数据
        rf_lookup = None
        if risk_free_rate is not None and not risk_free_rate.empty:
            rf_lookup = self._prepare_risk_free_rate(risk_free_rate)

        if fundamentals:
            for field_name, field_data in fundamentals.items():
                if field_data is not None and not field_data.empty:
                    # 跳过没有symbol列的字段（如shibor是日期->利率映射，不是股票级别数据）
                    if 'symbol' not in field_data.columns:
                        continue
                    # 使用最近可用原则：ann_date <= 股价日期，end_date最大，且不超过6个月
                    field_data = self._get_latest_available_financial(
                        field_data, df[['symbol', 'date']], field_name
                    )
                    if not field_data.empty:
                        df = df.merge(
                            field_data[['symbol', 'date', field_name]],
                            on=['symbol', 'date'],
                            how='left'
                        )

        df = df[
            (df['return'].notna()) &
            (df['mkt_cap'].notna()) &
            (df['return'] > -1) &
            (df['return'] < 10)
        ]

        if len(df) < self.min_stocks:
            raise ValueError(f"Insufficient data: {len(df)} < {self.min_stocks}")

        # 根据计算方法选择算法
        if self.method == CalculationMethod.CLASSIC:
            return self._calculate_classic(df, rf_lookup)

        # SIMPLE方法
        if self.factor_type == FactorType.FF3:
            return self._calculate_ff3(df, rf_lookup)
        elif self.factor_type == FactorType.FF5:
            return self._calculate_ff5(df, rf_lookup)
        elif self.factor_type == FactorType.CARHART:
            return self._calculate_carhart(df, rf_lookup)
        elif self.factor_type == FactorType.NOVY_MARX:
            return self._calculate_novymarx(df, rf_lookup)
        elif self.factor_type == FactorType.HOU_XUE_ZHANG:
            return self._calculate_hxz(df, rf_lookup)
        elif self.factor_type == FactorType.DHS:
            return self._calculate_dhs(df, rf_lookup)
        else:
            raise NotImplementedError(f"因子类型 {self.factor_type} 未实现")

    def _prepare_risk_free_rate(
        self,
        shibor_data: pd.DataFrame
    ) -> Optional[Dict]:
        """
        准备无风险利率查询字典

        根据当前period将SHIBOR转换为日度或月度无风险利率

        Args:
            shibor_data: SHIBOR数据，包含 date, on_rate, m1_rate 等列

        Returns:
            无风险利率查询字典 {date: rf}，rf为小数形式（如0.03表示3%）
        """
        if shibor_data is None or shibor_data.empty:
            return None

        shibor_data = shibor_data.copy()

        if self.period == TimePeriod.MONTHLY:
            # 月度：使用1个月期SHIBOR，转换为月度利率
            shibor_data['year_month'] = shibor_data['date'].dt.to_period('M')
            shibor_monthly = shibor_data.groupby('year_month').agg({
                'm1_rate': 'last',
                'date': 'last'
            }).reset_index()
            shibor_monthly['rf'] = shibor_monthly['m1_rate'] / 100 / 12
            return dict(zip(pd.to_datetime(shibor_monthly['date']), shibor_monthly['rf']))
        else:
            # 日度：使用隔夜SHIBOR，转换为日度利率
            shibor_data['rf'] = shibor_data['on_rate'] / 100 / 360
            return dict(zip(pd.to_datetime(shibor_data['date']), shibor_data['rf']))

    def _get_latest_available_financial(
        self,
        financial_data: pd.DataFrame,
        stock_dates: pd.DataFrame,
        field_name: str
    ) -> pd.DataFrame:
        """
        获取最近可用的财务数据

        对于每个股票+日期组合，找到所有end_date <= 该日期的财务记录，
        选择end_date最大的（最近的），且end_date距离股价日期不超过6个月。

        注意：
        - 当前实现只按end_date过滤，不按ann_date(公告日期)过滤
        - 如果需要更严格的前视偏差控制，可以在ann_date列可用时添加 ann_date <= stock_date 条件
        - ann_date字段保留在financial_data中供后续使用

        Args:
            financial_data: 财务数据，包含symbol, date, ann_date, field_name列
            stock_dates: 股票日期组合，包含symbol和date列
            field_name: 财务字段名

        Returns:
            处理后的财务数据
        """
        if financial_data.empty:
            return financial_data

        # 确保日期列是datetime类型
        financial_data = financial_data.copy()
        financial_data['date'] = pd.to_datetime(financial_data['date'])

        stock_dates = stock_dates.copy()
        stock_dates['date'] = pd.to_datetime(stock_dates['date'])

        # 对于每个股票+日期，找到最近可用的财务数据
        results = []

        for _, row in stock_dates.iterrows():
            symbol = row['symbol']
            stock_date = row['date']

            # 找到所有 end_date <= stock_date 的记录（确保报告期不超越股价日期）
            avail = financial_data[
                (financial_data['symbol'] == symbol) &
                (financial_data['date'] <= stock_date)
            ]

            if avail.empty:
                continue

            # 选择end_date最大的（最近的）
            latest = avail.loc[avail['date'].idxmax()]

            # 检查是否超过6个月（如果财务数据太旧，则不使用）
            months_diff = (stock_date.year - latest['date'].year) * 12 + \
                          (stock_date.month - latest['date'].month)
            if months_diff <= 6:
                results.append({
                    'symbol': symbol,
                    'date': stock_date,
                    field_name: latest[field_name]
                })

        if not results:
            return pd.DataFrame()

        return pd.DataFrame(results)

    def _calculate_ff3(self, df: pd.DataFrame, rf_lookup: Optional[Dict]) -> pd.DataFrame:
        """计算FF3因子"""
        return self._calculate_with_sorting(
            df,
            sort_vars=['mkt_cap', 'bm'],
            factor_def={
                'mkt': ('all', None),
                'smb': ('low', 'high'),
                'hml': ('high', 'low'),
            },
            rf_lookup=rf_lookup
        )

    def _calculate_ff5(self, df: pd.DataFrame, rf_lookup: Optional[Dict]) -> pd.DataFrame:
        """计算FF5因子（简化版：单变量依次排序）"""
        return self._calculate_with_sorting(
            df,
            sort_vars=['mkt_cap', 'bm', 'roe', 'investment'],
            factor_def={
                'mkt': ('all', None),
                'smb': ('low', 'high'),
                'hml': ('high', 'low'),
                'rmw': ('high', 'low'),
                'cma': ('low', 'high'),
            },
            rf_lookup=rf_lookup
        )

    def _calculate_carhart(self, df: pd.DataFrame, rf_lookup: Optional[Dict]) -> pd.DataFrame:
        """计算Carhart四因子（简化版：单变量依次排序）"""
        return self._calculate_with_sorting(
            df,
            sort_vars=['mkt_cap', 'bm', 'momentum'],
            factor_def={
                'mkt': ('all', None),
                'smb': ('low', 'high'),
                'hml': ('high', 'low'),
                'umd': ('high', 'low'),
            },
            rf_lookup=rf_lookup
        )

    def _calculate_novymarx(self, df: pd.DataFrame, rf_lookup: Optional[Dict]) -> pd.DataFrame:
        """计算Novy-Marx四因子（简化版：单变量依次排序）"""
        return self._calculate_with_sorting(
            df,
            sort_vars=['mkt_cap', 'roe', 'investment'],
            factor_def={
                'mkt': ('all', None),
                'smb': ('low', 'high'),
                'rmw': ('high', 'low'),
                'cma': ('low', 'high'),
            },
            rf_lookup=rf_lookup
        )

    def _calculate_hxz(self, df: pd.DataFrame, rf_lookup: Optional[Dict]) -> pd.DataFrame:
        """计算Hou-Xue-Zhang四因子（简化版：单变量依次排序）"""
        return self._calculate_with_sorting(
            df,
            sort_vars=['mkt_cap', 'investment', 'roe'],
            factor_def={
                'mkt': ('all', None),
                'me': ('low', 'high'),
                'ia': ('low', 'high'),
                'roe': ('high', 'low'),
            },
            rf_lookup=rf_lookup
        )

    def _calculate_dhs(self, df: pd.DataFrame, rf_lookup: Optional[Dict]) -> pd.DataFrame:
        """计算Daniel-Hirshleifer-Sun三因子（简化版：单变量依次排序）"""
        return self._calculate_with_sorting(
            df,
            sort_vars=['mkt_cap', 'idio_vol'],
            factor_def={
                'mkt': ('all', None),
                'smb': ('low', 'high'),
                'idio_vol': ('high', 'low'),
            },
            rf_lookup=rf_lookup
        )

    def _calculate_capm_factor(self, market_return: pd.DataFrame) -> pd.DataFrame:
        """
        计算CAPM因子收益率

        CAPM模型：R_i - R_f = alpha + beta * (R_m - R_f) + epsilon
        因子收益率就是市场超额收益率 (R_m - R_f)

        Args:
            market_return: 市场超额收益率数据，包含 date, mkt_return, mkt_excess

        Returns:
            市场超额收益率序列，index为date，column为['mkt']
        """
        if market_return is None or market_return.empty:
            raise ValueError("market_return 不能为空")

        df = market_return[['date', 'mkt_excess']].copy()
        df = df.set_index('date').sort_index()
        df.columns = ['mkt']

        return df

    def _calculate_classic(
        self,
        df: pd.DataFrame,
        rf_lookup: Optional[Dict]
    ) -> pd.DataFrame:
        """
        使用CLASSIC算法计算因子收益率

        参考论文标准方法:
        - 独立排序：每个维度按指定分位数分组
        - 市值加权：组合内按市值加权
        - 多因子模型中，非市值因子的计算取决于模型类型

        Args:
            df: 合并后的数据
            rf_lookup: 无风险利率查询字典

        Returns:
            因子收益率DataFrame
        """
        dates = list(df.groupby('date'))

        # 并行计算每个日期的因子收益
        raw_results = Parallel(n_jobs=self.n_jobs, prefer="processes")(
            delayed(_calc_single_date_classic)(
                date, group, self.factor_type, self.classic_config,
                self.sorting_dims, self.min_stocks, rf_lookup
            )
            for date, group in dates
        )

        results = [r for r in raw_results if r is not None]

        if not results:
            raise ValueError("No valid factor data calculated")

        factor_df = pd.DataFrame(results)
        cols = ['date'] + [f for f in self.factor_names if f in factor_df.columns]
        factor_df = factor_df[[c for c in cols if c in factor_df.columns]]
        factor_df = factor_df.set_index('date').sort_index()

        return factor_df

    def _assign_groups(
        self,
        series: pd.Series,
        breakpoints: List[float]
    ) -> pd.Series:
        """
        根据分位数断点将数据分配到组

        Args:
            series: 要分组的数据
            breakpoints: 分位数列表，如 [0.3, 0.7] 表示按30%和70%分位数分组

        Returns:
            分组标签Series
        """
        # 计算分位数边界
        bounds = [series.quantile(p) for p in breakpoints]
        labels = []
        for val in series:
            if pd.isna(val):
                labels.append('low')  # 缺失值归入最低组
            else:
                assigned = False
                for i, bound in enumerate(bounds):
                    if val <= bound:
                        labels.append('low' if i == 0 else ['medium', 'high'][i-1])
                        assigned = True
                        break
                if not assigned:
                    labels.append('high')
        return pd.Series(labels, index=series.index)

    def _value_weighted_return(
        self,
        group: pd.DataFrame,
        return_col: str = 'return',
        weight_col: str = 'mkt_cap'
    ) -> float:
        """
        计算市值加权收益率

        Args:
            group: 股票组合数据
            return_col: 收益率列名
            weight_col: 市值列名

        Returns:
            市值加权收益率
        """
        valid = group[[return_col, weight_col]].notna().all(axis=1)
        if valid.sum() == 0:
            return np.nan

        w = group.loc[valid, weight_col]
        r = group.loc[valid, return_col]
        # 处理负市值或异常值
        w = w.clip(lower=0)
        if w.sum() == 0:
            return r.mean()
        return (r * w).sum() / w.sum()

    def _calc_ff3_classic(
        self,
        group: pd.DataFrame,
        portfolio_labels: pd.Series
    ) -> Dict[str, float]:
        """
        FF3因子CLASSIC计算

        SMB = (S/L + S/M + S/H)/3 - (B/L + B/M + B/H)/3
        HML = (S/H + B/H)/2 - (S/L + B/L)/2
        """
        factor_def = self.classic_config.get("factor_definition", {})
        size_var = 'mkt_cap'
        value_var = 'bm'

        group['size_g'] = group[size_var].apply(
            lambda x: 'small' if pd.isna(x) or x <= group[size_var].median() else 'big'
        )
        bps = self.classic_config.get("breakpoints", {}).get(value_var, [0.3, 0.7])
        group['value_g'] = self._assign_groups(group[value_var], bps)

        # 计算各组合收益率（市值加权）
        portfolios = group.groupby(['size_g', 'value_g'])

        # SMB: 小市值组合均值 - 大市值组合均值
        small_returns = []
        big_returns = []
        for (size, value), sub in portfolios:
            ret = self._value_weighted_return(sub)
            if size == 'small':
                small_returns.append(ret)
            else:
                big_returns.append(ret)

        smb = np.mean(small_returns) - np.mean(big_returns) if small_returns and big_returns else np.nan

        # HML: 高价值组合均值 - 低价值组合均值
        high_returns = []
        low_returns = []
        for (size, value), sub in portfolios:
            ret = self._value_weighted_return(sub)
            if value == 'high':
                high_returns.append(ret)
            elif value == 'low':
                low_returns.append(ret)

        hml = np.mean(high_returns) - np.mean(low_returns) if high_returns and low_returns else np.nan

        return {'smb': smb, 'hml': hml}

    def _calc_ff5_classic(
        self,
        group: pd.DataFrame,
        portfolio_labels: pd.Series
    ) -> Dict[str, float]:
        """
        FF5因子CLASSIC计算

        使用2x3x3x3独立排序:
        - size: small/big (50% breakpoint)
        - bm: low/medium/high (30%/70% breakpoints)
        - roe: low/medium/high
        - investment: low/medium/high

        SMB = 27个小型组合均值 - 27个大型组合均值
        HML = (小型+大型)高BM组合均值 - (小型+大型)低BM组合均值
        RMW = (小型+大型)高盈利组合均值 - (小型+大型)低盈利组合均值
        CMA = (小型+大型)低投资组合均值 - (小型+大型)高投资组合均值
        """
        bps = self.classic_config.get("breakpoints", {})

        size_var = 'mkt_cap'
        size_bps = bps.get(size_var, [0.5])
        group['size_g'] = self._assign_groups(group[size_var], size_bps)

        for var, var_bps in [('bm', bps.get('bm', [0.3, 0.7])),
                             ('roe', bps.get('roe', [0.3, 0.7])),
                             ('investment', bps.get('investment', [0.3, 0.7]))]:
            if var in group.columns:
                group[f'{var}_g'] = self._assign_groups(group[var], var_bps)

        # 构建8组组合
        def calc_spread(col1_low, col1_high, col2_low, col2_high):
            """计算因子利差"""
            rets = []
            for (s, b, op, inv), sub in group.groupby(['size_g', f'{col1_low}_g' if '_g' not in col1_low else f'{col1_low}_g',
                                                       f'{col2_low}_g' if '_g' not in col2_low else f'{col2_low}_g']):
                pass

            return np.nan

        # 各组合市值加权收益率
        portfolios = group.groupby(['size_g', 'bm_g', 'roe_g', 'investment_g'])
        port_returns = {}
        for combo, sub in portfolios:
            port_returns[combo] = self._value_weighted_return(sub)

        # SMB
        small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
        big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
        smb = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

        # HML (基于bm)
        high_rets = [v for k, v in port_returns.items() if k[1] == 'high']
        low_rets = [v for k, v in port_returns.items() if k[1] == 'low']
        hml = np.nanmean(high_rets) - np.nanmean(low_rets) if high_rets and low_rets else np.nan

        # RMW (基于roe)
        robust_rets = [v for k, v in port_returns.items() if k[2] == 'high']
        weak_rets = [v for k, v in port_returns.items() if k[2] == 'low']
        rmw = np.nanmean(robust_rets) - np.nanmean(weak_rets) if robust_rets and weak_rets else np.nan

        # CMA (基于investment，低投资=保守，高投资=激进)
        conservative_rets = [v for k, v in port_returns.items() if k[3] == 'low']
        aggressive_rets = [v for k, v in port_returns.items() if k[3] == 'high']
        cma = np.nanmean(conservative_rets) - np.nanmean(aggressive_rets) if conservative_rets and aggressive_rets else np.nan

        return {'smb': smb, 'hml': hml, 'rmw': rmw, 'cma': cma}

    def _calc_carhart_classic(
        self,
        group: pd.DataFrame,
        portfolio_labels: pd.Series
    ) -> Dict[str, float]:
        """
        CARHART四因子CLASSIC计算

        基于2x3排序:
        - size: small/big
        - bm: low/medium/high
        - momentum: low/medium/high

        UMD (动量因子) = 高动量组合均值 - 低动量组合均值
        """
        bps = self.classic_config.get("breakpoints", {})

        size_var = 'mkt_cap'
        size_bps = bps.get(size_var, [0.5])
        group['size_g'] = self._assign_groups(group[size_var], size_bps)

        for var, var_bps in [('bm', bps.get('bm', [0.3, 0.7])),
                             ('momentum', bps.get('momentum', [0.3, 0.7]))]:
            if var in group.columns:
                group[f'{var}_g'] = self._assign_groups(group[var], var_bps)

        # 各组合市值加权收益率
        portfolios = group.groupby(['size_g', 'bm_g', 'momentum_g'])
        port_returns = {}
        for combo, sub in portfolios:
            port_returns[combo] = self._value_weighted_return(sub)

        # SMB
        small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
        big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
        smb = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

        # HML
        high_rets = [v for k, v in port_returns.items() if k[1] == 'high']
        low_rets = [v for k, v in port_returns.items() if k[1] == 'low']
        hml = np.nanmean(high_rets) - np.nanmean(low_rets) if high_rets and low_rets else np.nan

        # UMD (动量)
        up_rets = [v for k, v in port_returns.items() if k[2] == 'high']
        down_rets = [v for k, v in port_returns.items() if k[2] == 'low']
        umd = np.nanmean(up_rets) - np.nanmean(down_rets) if up_rets and down_rets else np.nan

        return {'smb': smb, 'hml': hml, 'umd': umd}

    def _calc_novymarx_classic(
        self,
        group: pd.DataFrame,
        portfolio_labels: pd.Series
    ) -> Dict[str, float]:
        """
        Novy-Marx四因子CLASSIC计算

        基于2x3排序:
        - size: small/big
        - roe: low/medium/high

        RMW = 高盈利组合均值 - 低盈利组合均值
        CMA = 低投资组合均值 - 高投资组合均值 (Novy-Marx用 profitability 和 investment)
        """
        bps = self.classic_config.get("breakpoints", {})

        size_var = 'mkt_cap'
        size_bps = bps.get(size_var, [0.5])
        group['size_g'] = self._assign_groups(group[size_var], size_bps)

        for var, var_bps in [('roe', bps.get('roe', [0.3, 0.7])),
                             ('investment', bps.get('investment', [0.3, 0.7]))]:
            if var in group.columns:
                group[f'{var}_g'] = self._assign_groups(group[var], var_bps)

        # 各组合市值加权收益率
        portfolios = group.groupby(['size_g', 'roe_g', 'investment_g'])
        port_returns = {}
        for combo, sub in portfolios:
            port_returns[combo] = self._value_weighted_return(sub)

        # SMB
        small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
        big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
        smb = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

        # RMW (盈利因子)
        robust_rets = [v for k, v in port_returns.items() if k[1] == 'high']
        weak_rets = [v for k, v in port_returns.items() if k[1] == 'low']
        rmw = np.nanmean(robust_rets) - np.nanmean(weak_rets) if robust_rets and weak_rets else np.nan

        # CMA (投资因子)
        conservative_rets = [v for k, v in port_returns.items() if k[2] == 'low']
        aggressive_rets = [v for k, v in port_returns.items() if k[2] == 'high']
        cma = np.nanmean(conservative_rets) - np.nanmean(aggressive_rets) if conservative_rets and aggressive_rets else np.nan

        return {'smb': smb, 'rmw': rmw, 'cma': cma}

    def _calc_hxz_classic(
        self,
        group: pd.DataFrame,
        portfolio_labels: pd.Series
    ) -> Dict[str, float]:
        """
        Hou-Xue-Zhang四因子CLASSIC计算

        基于2x3排序:
        - size: small/big
        - investment: low/medium/high

        ME = size因子
        IA = 投资因子 (conservative - aggressive)
        ROE = 盈利因子
        """
        bps = self.classic_config.get("breakpoints", {})

        size_var = 'mkt_cap'
        size_bps = bps.get(size_var, [0.5])
        group['size_g'] = self._assign_groups(group[size_var], size_bps)

        for var, var_bps in [('investment', bps.get('investment', [0.3, 0.7])),
                             ('roe', bps.get('roe', [0.3, 0.7]))]:
            if var in group.columns:
                group[f'{var}_g'] = self._assign_groups(group[var], var_bps)

        # 各组合市值加权收益率
        portfolios = group.groupby(['size_g', 'investment_g', 'roe_g'])
        port_returns = {}
        for combo, sub in portfolios:
            port_returns[combo] = self._value_weighted_return(sub)

        # ME (size因子，等同SMB)
        small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
        big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
        me = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

        # IA (投资因子)
        conservative_rets = [v for k, v in port_returns.items() if k[1] == 'low']
        aggressive_rets = [v for k, v in port_returns.items() if k[1] == 'high']
        ia = np.nanmean(conservative_rets) - np.nanmean(aggressive_rets) if conservative_rets and aggressive_rets else np.nan

        # ROE (盈利因子)
        high_rets = [v for k, v in port_returns.items() if k[2] == 'high']
        low_rets = [v for k, v in port_returns.items() if k[2] == 'low']
        roe_factor = np.nanmean(high_rets) - np.nanmean(low_rets) if high_rets and low_rets else np.nan

        return {'me': me, 'ia': ia, 'roe': roe_factor}

    def _calc_dhs_classic(
        self,
        group: pd.DataFrame,
        portfolio_labels: pd.Series
    ) -> Dict[str, float]:
        """
        DHS三因子CLASSIC计算

        基于2x3排序:
        - size: small/big
        - idio_vol: low/medium/high

        IDIO_VOL = 高特质波动率组合均值 - 低特质波动率组合均值
        """
        bps = self.classic_config.get("breakpoints", {})

        size_var = 'mkt_cap'
        size_bps = bps.get(size_var, [0.5])
        group['size_g'] = self._assign_groups(group[size_var], size_bps)

        idio_var = 'idio_vol'
        idio_bps = bps.get(idio_var, [0.3, 0.7])
        if idio_var in group.columns:
            group['idio_vol_g'] = self._assign_groups(group[idio_var], idio_bps)

        # 各组合市值加权收益率
        portfolios = group.groupby(['size_g', 'idio_vol_g'])
        port_returns = {}
        for combo, sub in portfolios:
            port_returns[combo] = self._value_weighted_return(sub)

        # SMB
        small_rets = [v for k, v in port_returns.items() if k[0] == 'small']
        big_rets = [v for k, v in port_returns.items() if k[0] == 'big']
        smb = np.nanmean(small_rets) - np.nanmean(big_rets) if small_rets and big_rets else np.nan

        # IDIO_VOL
        high_rets = [v for k, v in port_returns.items() if k[1] == 'high']
        low_rets = [v for k, v in port_returns.items() if k[1] == 'low']
        idio_vol_factor = np.nanmean(high_rets) - np.nanmean(low_rets) if high_rets and low_rets else np.nan

        return {'smb': smb, 'idio_vol': idio_vol_factor}

    def _calculate_with_sorting(
        self,
        df: pd.DataFrame,
        sort_vars: List[str],
        factor_def: Dict[str, tuple],
        rf_lookup: Optional[Dict] = None
    ) -> pd.DataFrame:
        """
        使用排序法计算因子

        Args:
            df: 合并后的数据
            sort_vars: 排序变量
            factor_def: 因子定义 {因子名: (多头组, 空头组)}
            rf_lookup: 无风险利率查询字典 {date: rf}

        Returns:
            因子收益率
        """
        dates = list(df.groupby('date'))

        # 并行计算每个日期的因子收益
        raw_results = Parallel(n_jobs=self.n_jobs, prefer="processes")(
            delayed(_calc_single_date_sorting)(
                date, group, sort_vars, factor_def, rf_lookup, self.min_stocks
            )
            for date, group in dates
        )

        results = [r for r in raw_results if r is not None]

        if not results:
            raise ValueError("No valid factor data calculated")

        factor_df = pd.DataFrame(results)

        cols = ['date'] + [f for f in self.factor_names if f in factor_df.columns]
        factor_df = factor_df[[c for c in cols if c in factor_df.columns]]

        factor_df = factor_df.set_index('date').sort_index()

        return factor_df


def calculate_factor_returns(
    factor_type: FactorType,
    stock_returns: pd.DataFrame,
    market_cap: pd.DataFrame,
    fundamentals: Optional[Dict[str, pd.DataFrame]] = None,
    risk_free_rate: Optional[pd.DataFrame] = None,
    method: CalculationMethod = CalculationMethod.SIMPLE,
    period: TimePeriod = TimePeriod.MONTHLY,
) -> pd.DataFrame:
    """
    便捷函数：计算因子收益率

    Args:
        factor_type: 因子类型
        stock_returns: 股票收益率
        market_cap: 市值数据
        fundamentals: 基本面数据字典
        risk_free_rate: 无风险利率数据
        method: 计算方法
        period: 时间周期

    Returns:
        因子收益率DataFrame
    """
    calculator = GeneralFactorCalculator(
        factor_type=factor_type,
        method=method,
        period=period
    )

    return calculator.calculate(
        stock_returns=stock_returns,
        market_cap=market_cap,
        fundamentals=fundamentals,
        risk_free_rate=risk_free_rate,
    )
