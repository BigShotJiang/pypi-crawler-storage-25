"""
Data Transformation Utilities

Provides data transformation functions for factor calculations.
"""
from typing import Optional, List
import pandas as pd
import numpy as np


def daily_to_monthly(
    df: pd.DataFrame,
    price_columns: Optional[List[str]] = None,
    volume_columns: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    Convert daily data to monthly data.

    Args:
        df: Daily data DataFrame with 'date', 'symbol', 'close' columns minimum
        price_columns: Price columns to aggregate (default: ['open', 'close', 'high', 'low'])
        volume_columns: Volume columns to aggregate (default: ['volume', 'amount'])

    Returns:
        Monthly aggregated DataFrame

    Example:
        >>> daily_df = get_stock_daily(start_date='2020-01-01')
        >>> monthly_df = daily_to_monthly(daily_df)
    """
    if df.empty:
        return df.copy()

    df = df.copy()

    # Ensure date format
    df['date'] = pd.to_datetime(df['date'])

    # Default columns
    if price_columns is None:
        price_columns = ['open', 'close', 'high', 'low']
    if volume_columns is None:
        volume_columns = ['volume', 'amount']

    # Add year-month identifier
    df['year_month'] = df['date'].dt.to_period('M')

    # Define aggregation rules
    agg_rules = {}

    for col in price_columns:
        if col in df.columns:
            if col == 'open':
                agg_rules[col] = 'first'  # Month start price
            elif col == 'close':
                agg_rules[col] = 'last'  # Month end price
            elif col == 'high':
                agg_rules[col] = 'max'  # Monthly high
            elif col == 'low':
                agg_rules[col] = 'min'  # Monthly low

    for col in volume_columns:
        if col in df.columns:
            agg_rules[col] = 'sum'  # Monthly total

    # Always keep the last date of month
    agg_rules['date'] = 'last'

    # Execute groupby aggregation
    monthly_df = df.groupby(['symbol', 'year_month']).agg(agg_rules).reset_index()

    # Remove year_month, keep only date
    monthly_df = monthly_df.drop(columns=['year_month'])

    return monthly_df


def calculate_returns(
    df: pd.DataFrame,
    price_column: str = 'close',
    method: str = 'simple'
) -> pd.DataFrame:
    """
    Calculate stock returns.

    Args:
        df: DataFrame with 'symbol' and price column
        price_column: Price column name
        method: 'simple' for simple returns, 'log' for log returns

    Returns:
        DataFrame with 'return' column added
    """
    df = df.copy()
    df = df.sort_values(['symbol', 'date'])

    # Ensure price column is numeric
    df[price_column] = pd.to_numeric(df[price_column], errors='coerce')

    if method == 'simple':
        df['return'] = df.groupby('symbol')[price_column].pct_change()
    elif method == 'log':
        df['return'] = df.groupby('symbol')[price_column].transform(
            lambda x: np.log(x / x.shift(1))
        )
    else:
        raise ValueError(f"Unknown method: {method}")

    return df


def calculate_log_returns(df: pd.DataFrame, price_column: str = 'close') -> pd.DataFrame:
    """
    Calculate log returns.

    Args:
        df: DataFrame with price data
        price_column: Price column name

    Returns:
        DataFrame with 'log_return' column added
    """
    return calculate_returns(df, price_column, method='log')


def calculate_cumulative_returns(
    df: pd.DataFrame,
    return_column: str = 'return'
) -> pd.DataFrame:
    """
    Calculate cumulative returns.

    Args:
        df: DataFrame with return data
        return_column: Return column name

    Returns:
        DataFrame with cumulative returns
    """
    df = df.copy()
    df = df.sort_values(['symbol', 'date'])

    df['cumulative_return'] = df.groupby('symbol')[return_column].transform(
        lambda x: (1 + x).cumprod() - 1
    )

    return df


def resample_to_period(
    df: pd.DataFrame,
    freq: str = 'M',
    price_columns: Optional[List[str]] = None,
    agg_method: str = 'last'
) -> pd.DataFrame:
    """
    Resample data to different frequency.

    Args:
        df: DataFrame with date column
        freq: Frequency ('M' for monthly, 'W' for weekly, 'Q' for quarterly)
        price_columns: Price columns to aggregate
        agg_method: Aggregation method ('last', 'mean', 'sum')

    Returns:
        Resampled DataFrame
    """
    if df.empty:
        return df.copy()

    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df = df.set_index('date')

    if price_columns is None:
        price_columns = [col for col in df.columns if col not in ['symbol', 'year_month']]

    if agg_method == 'last':
        resampled = df[price_columns].resample(freq).last()
    elif agg_method == 'mean':
        resampled = df[price_columns].resample(freq).mean()
    elif agg_method == 'sum':
        resampled = df[price_columns].resample(freq).sum()
    else:
        raise ValueError(f"Unknown agg_method: {agg_method}")

    resampled = resampled.reset_index()

    return resampled


def align_dates(
    target_df: pd.DataFrame,
    source_df: pd.DataFrame,
    date_column: str = 'date'
) -> pd.DataFrame:
    """
    Align dates between two DataFrames.

    Args:
        target_df: DataFrame to align to
        source_df: DataFrame to get dates from
        date_column: Date column name

    Returns:
        Aligned target DataFrame
    """
    target_dates = set(pd.to_datetime(target_df[date_column]))
    source_dates = set(pd.to_datetime(source_df[date_column]))
    common_dates = target_dates.intersection(source_dates)

    return target_df[pd.to_datetime(target_df[date_column]).isin(common_dates)]


def get_month_end_dates(df: pd.DataFrame) -> pd.DataFrame:
    """
    Get month-end dates for each stock.

    Args:
        df: DataFrame with date and symbol columns

    Returns:
        DataFrame with month-end dates
    """
    if df.empty:
        return df.copy()

    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df['year_month'] = df['date'].dt.to_period('M')

    month_end = df.groupby(['symbol', 'year_month'])['date'].max().reset_index()
    month_end.columns = ['symbol', 'year_month', 'month_end_date']

    return month_end
