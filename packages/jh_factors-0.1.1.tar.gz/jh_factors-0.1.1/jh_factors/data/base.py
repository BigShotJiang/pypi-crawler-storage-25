"""
Data Module for Factor Return Calculation
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Union
import pandas as pd
import numpy as np
from ..config import FactorType, TimePeriod


def _get_market_by_code(code: str) -> str:
    """根据股票代码判断市场"""
    if code.startswith(("600", "601", "603", "688")):
        return "SH"
    elif code.startswith(("000", "002", "300", "003")):
        return "SZ"
    elif code.startswith(("430", "830", "870", "880")):
        return "BJ"
    else:
        return "SZ"


def _symbol_to_ts_code(symbol: str) -> str:
    """将6位股票代码转换为 tushare 格式"""
    market = _get_market_by_code(symbol)
    return f"{symbol}.{market}"


class FactorReturnData(ABC):
    """
    抽象数据准备基类

    每个因子类型对应一个子类，实现 prepare_data(period) 方法
    支持真实数据和Mock数据测试
    """

    factor_type: FactorType  # 子类需要设置对应的因子类型

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        use_mock: bool = False,
        n_stocks: int = 30,
        start_date: str = "2023-01-01",
        end_date: str = "2024-12-31",
        seed: int = 42
    ):
        """
        初始化数据准备器

        Args:
            api_key: API密钥（可选，从环境变量读取）
            api_url: API地址（可选）
            use_mock: 是否使用Mock数据（用于测试）
            n_stocks: Mock股票数量
            start_date: Mock数据开始日期
            end_date: Mock数据结束日期
            seed: 随机种子
        """
        from os import getenv
        from dotenv import load_dotenv

        load_dotenv()

        self.api_key = api_key or getenv("JIUHUANG_API_KEY")
        self.api_url = api_url or getenv("JIUHUANG_API_URL", "https://data.jiuhuang.xyz")
        self._client = None

        self.use_mock = use_mock
        self.n_stocks = n_stocks
        self.mock_start = start_date
        self.mock_end = end_date
        self.seed = seed

        if use_mock:
            self._init_mock_data()

    def _init_mock_data(self):
        """初始化Mock数据"""
        np.random.seed(self.seed)
        self._mock_symbols = [f"{str(i).zfill(6)}" for i in range(1, self.n_stocks + 1)]
        self._mock_dates = pd.date_range(start=self.mock_start, end=self.mock_end, freq='B').tolist()

    def _get_client(self):
        """获取jh_data客户端"""
        if self._client is None:
            from jh_data.data import JHData, DataTypes
            self._client = JHData(api_key=self.api_key, api_url=self.api_url)
            self._DataTypes = DataTypes
        return self._client

    def _to_dataframe(self, data) -> pd.DataFrame:
        """将jh_data返回的数据转换为DataFrame"""
        if data is None:
            return pd.DataFrame()
        if hasattr(data, 'columns') and hasattr(data, 'values'):
            return pd.DataFrame(data.values, columns=data.columns)
        return pd.DataFrame(data)

    @abstractmethod
    def prepare_data(
        self,
        period: Union[str, TimePeriod] = "monthly",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, pd.DataFrame]:
        """
        准备因子计算所需的数据

        Args:
            period: 时间周期 ("monthly" 或 "daily")
            start_date: 开始日期
            end_date: 结束日期
            symbols: 股票列表
            **kwargs: 额外参数

        Returns:
            Dict containing required DataFrames for factor calculation.
            每个子类返回不同的key，取决于因子所需数据
        """
        pass

    def _generate_mock_prices(
        self,
        symbols: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """生成Mock股价数据"""
        if symbols is None:
            symbols = self._mock_symbols

        if start_date:
            start = pd.to_datetime(start_date)
        else:
            start = pd.to_datetime(self.mock_start)

        if end_date:
            end = pd.to_datetime(end_date)
        else:
            end = pd.to_datetime(self.mock_end)

        dates = [d for d in self._mock_dates if start <= d <= end]
        if not dates:
            return pd.DataFrame()

        np.random.seed(self.seed)
        data = []

        for symbol in symbols:
            base_return = np.random.normal(0.0005, 0.02)
            volatility = np.random.uniform(0.015, 0.035)
            price = np.random.uniform(10, 100)

            for date in dates:
                return_day = np.random.normal(base_return, volatility)
                price = price * (1 + return_day)
                high = price * (1 + abs(np.random.normal(0, 0.01)))
                low = price * (1 - abs(np.random.normal(0, 0.01)))
                open_price = price * (1 + np.random.normal(0, 0.005))
                volume = np.random.randint(1000000, 10000000)
                amount = volume * price

                data.append({
                    'date': date,
                    'symbol': symbol,
                    'open': open_price,
                    'close': price,
                    'high': high,
                    'low': low,
                    'volume': volume,
                    'amount': amount,
                })

        return pd.DataFrame(data)

    def _generate_mock_daily_basic(
        self,
        symbols: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """生成Mock日频基础数据"""
        if symbols is None:
            symbols = self._mock_symbols

        if start_date:
            start = pd.to_datetime(start_date)
        else:
            start = pd.to_datetime(self.mock_start)

        if end_date:
            end = pd.to_datetime(end_date)
        else:
            end = pd.to_datetime(self.mock_end)

        dates = [d for d in self._mock_dates if start <= d <= end]
        if not dates:
            return pd.DataFrame()

        np.random.seed(self.seed)
        data = []

        for symbol in symbols:
            base_cap = np.random.uniform(1e9, 1e11)
            base_pe = np.random.uniform(10, 50)
            base_pb = np.random.uniform(1, 5)
            base_ps = np.random.uniform(1, 10)

            for date in dates:
                total_mv = base_cap * np.random.uniform(0.9, 1.1)
                circ_mv = total_mv * np.random.uniform(0.6, 0.9)
                close = np.random.uniform(10, 100)
                turnover_rate = np.random.uniform(0.5, 5)
                pe = base_pe * np.random.uniform(0.9, 1.1)
                pb = base_pb * np.random.uniform(0.9, 1.1)
                ps = base_ps * np.random.uniform(0.9, 1.1)
                ps_ttm = ps * np.random.uniform(0.9, 1.1)
                dv_ratio = np.random.uniform(0, 5)
                dv_ttm = dv_ratio * np.random.uniform(0.8, 1.2)
                total_share = total_mv / close * 10000
                float_share = circ_mv / close * 10000
                free_share = float_share * np.random.uniform(0.5, 0.9)
                turnover_rate_f = turnover_rate * np.random.uniform(0.8, 1.0)

                data.append({
                    'date': date,
                    'symbol': symbol,
                    'close': close,
                    'total_mv': total_mv,
                    'circ_mv': circ_mv,
                    'turnover_rate': turnover_rate,
                    'turnover_rate_f': turnover_rate_f,
                    'pe': pe,
                    'pe_ttm': pe * np.random.uniform(0.9, 1.1),
                    'pb': pb,
                    'ps': ps,
                    'ps_ttm': ps_ttm,
                    'dv_ratio': dv_ratio,
                    'dv_ttm': dv_ttm,
                    'total_share': total_share,
                    'float_share': float_share,
                    'free_share': free_share,
                })

        return pd.DataFrame(data)

    def get_price_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        获取股价数据（前复权）

        Returns:
            DataFrame with columns: [date, symbol, open, close, high, low, volume, amount]
        """
        if self.use_mock:
            return self._generate_mock_prices(symbols, start_date, end_date)

        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date
        if symbols:
            kwargs['symbol'] = ','.join(symbols)

        df = client.get_data(self._DataTypes.AK_STOCK_ZH_A_HIST_QFQ, **kwargs)
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        cols_to_keep = ['date', 'symbol', 'open', 'close', 'high', 'low', 'volume', 'amount']
        return df[[c for c in cols_to_keep if c in df.columns]].copy()

    def get_daily_basic_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        获取日频基础数据（市值、PE、PB等）

        Returns:
            DataFrame with columns including:
            - date: 交易日期
            - symbol: 股票代码
            - close: 收盘价
            - total_mv: 总市值（万元）
            - circ_mv: 流通市值（万元）
            - pe, pe_ttm, pb, ps, ps_ttm
            - turnover_rate, turnover_rate_f
            - total_share, float_share, free_share
            - bm: 账面市值比 (1/pb)
        """
        if self.use_mock:
            df = self._generate_mock_daily_basic(symbols, start_date, end_date)
            if not df.empty and 'pb' in df.columns:
                df['bm'] = 1 / df['pb']
            return df

        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date
        if symbols:
            ts_codes = ','.join([_symbol_to_ts_code(s) for s in symbols])
            kwargs['ts_code'] = ts_codes

        df = client.get_data(self._DataTypes.TS_DAILY_BASIC, **kwargs)
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'ts_code' in df.columns:
            df['symbol'] = df['ts_code'].str.extract(r'^(\d{6})')
            df = df.drop(columns=['ts_code'])

        if 'trade_date' in df.columns:
            df['date'] = pd.to_datetime(df['trade_date'])
            df = df.drop(columns=['trade_date'])

        if 'pb' in df.columns:
            df['bm'] = 1 / df['pb']

        return df

    def get_financial_data(
        self,
        data_type: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        max_ann_date: Optional[str] = None
    ) -> pd.DataFrame:
        """
        获取财务报表数据

        Args:
            data_type: 数据类型 (LRB=利润表, XJLL=现金流表, ZCFZ=资产负债表)
            start_date: 开始日期（报告期end_date的起始）
            end_date: 结束日期（报告期end_date的截止）
            symbols: 股票列表
            max_ann_date: 允许使用的最晚公告日期，用于避免前视偏差

        Returns:
            DataFrame with financial data

        Note:
            财务报表数据必须确保公告日期(ann_date)不超过交易日期，
            以避免前视偏差 - 在T日计算因子时，只能使用ann_date <= T的财务数据。
        """
        from jh_data.data import DataTypes

        type_map = {
            "LRB": DataTypes.AK_STOCK_LRB_EM,
            "XJLL": DataTypes.AK_STOCK_XJLL_EM,
            "ZCFZ": DataTypes.AK_STOCK_ZCFZ_EM,
        }

        dt = type_map.get(data_type.upper())
        if dt is None:
            raise ValueError(f"Unknown financial data type: {data_type}")

        if self.use_mock:
            return pd.DataFrame()

        client = self._get_client()
        kwargs = {}
        if symbols:
            kwargs['symbol'] = ','.join(symbols)

        # 财务报表数据量通常较小，直接获取所有数据后本地过滤
        df = client.get_data(dt, **kwargs)
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'end_date' not in df.columns:
            return pd.DataFrame()

        # 转换日期
        df['end_date'] = pd.to_datetime(df['end_date'])
        if 'ann_date' in df.columns:
            df['ann_date'] = pd.to_datetime(df['ann_date'])

        # 按报告期(end_date)范围过滤
        if start_date:
            start_dt = pd.to_datetime(start_date)
            df = df[df['end_date'] >= start_dt]
        if end_date:
            end_dt = pd.to_datetime(end_date)
            df = df[df['end_date'] <= end_dt]

        # 按公告日期过滤以避免前视偏差 - T日只能使用ann_date <= T的财务数据
        if max_ann_date:
            max_ann_dt = pd.to_datetime(max_ann_date)
            if 'ann_date' in df.columns:
                df = df[df['ann_date'] <= max_ann_dt]

        # 使用报告期作为date列
        # 注意：ann_date字段保留在数据中，方便后续根据公告日期过滤前视偏差
        # 当前实现按end_date(报告期)过滤，确保end_date <= 股价日期
        # 如果后续发现需要更严格的前视偏差控制，可以在调用处添加ann_date过滤
        df['date'] = df['end_date']

        # 保留必要的列：symbol, date, ann_date(用于后续可能的过滤)以及数值列
        cols_to_keep = ['symbol', 'date', 'ann_date']
        numeric_cols = ['ni', 'be', 'ta', 'roe', 'bm', 'momentum', 'investment', 'idio_vol']
        for col in numeric_cols:
            if col in df.columns:
                cols_to_keep.append(col)

        return df[cols_to_keep].dropna(subset=['date'])


# 具体因子数据准备类
class FF3Data(FactorReturnData):
    """FF3因子数据准备"""
    factor_type = FactorType.FF3

    def _get_shibor_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取SHIBOR数据（无风险收益率参考）"""
        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date

        df = client.get_data(
            self._DataTypes.AK_MACRO_CHINA_SHIBOR_ALL, **kwargs
        )
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        return df.sort_values('date').reset_index(drop=True)

    def prepare_data(
        self,
        period: Union[str, TimePeriod] = "monthly",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, pd.DataFrame]:
        """
        准备FF3因子所需数据

        FF3需要:
        - 股价数据 (计算收益率)
        - 市值数据 (计算SMB)
        - BM数据 (从TS_DAILY_BASIC的pb派生)

        Returns:
            Dict with keys: stock_returns, market_cap
        """
        from ..data.transform import daily_to_monthly, calculate_returns

        if isinstance(period, str):
            period = TimePeriod(period)

        prices = self.get_price_data(start_date, end_date, symbols)
        daily_basic = self.get_daily_basic_data(start_date, end_date, symbols)

        if prices.empty or daily_basic.empty:
            raise ValueError("无法获取价格或市值数据")

        prices = prices[prices['close'] > 0].copy()
        daily_basic = daily_basic[daily_basic['close'] > 0].copy()

        if period == TimePeriod.MONTHLY:
            monthly_prices = daily_to_monthly(prices)
            stock_returns = calculate_returns(monthly_prices)
        else:
            stock_returns = calculate_returns(prices)

        if period == TimePeriod.MONTHLY:
            # 月度：按月聚合市值
            daily_basic['year_month'] = daily_basic['date'].dt.to_period('M')
            market_cap = daily_basic.groupby(['symbol', 'year_month']).agg({
                'total_mv': 'last',
                'date': 'last'
            }).reset_index()
            market_cap.columns = ['symbol', 'year_month', 'mkt_cap', 'date']
            market_cap = market_cap.drop(columns=['year_month'])
        else:
            # 日度：保持每日市值
            market_cap = daily_basic[['symbol', 'date', 'total_mv']].copy()
            market_cap.columns = ['symbol', 'date', 'mkt_cap']

        bm_data = daily_basic[['symbol', 'date', 'bm']].dropna()

        # 获取SHIBOR数据（无风险收益率）
        shibor_data = self._get_shibor_data(start_date, end_date)

        return {
            'stock_returns': stock_returns,
            'market_cap': market_cap,
            'bm': bm_data,
            'shibor': shibor_data,
        }


class FF5Data(FactorReturnData):
    """FF5因子数据准备"""
    factor_type = FactorType.FF5

    def _get_shibor_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取SHIBOR数据（无风险收益率参考）"""
        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date

        df = client.get_data(
            self._DataTypes.AK_MACRO_CHINA_SHIBOR_ALL, **kwargs
        )
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        return df.sort_values('date').reset_index(drop=True)

    def prepare_data(
        self,
        period: Union[str, TimePeriod] = "monthly",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, pd.DataFrame]:
        """
        准备FF5因子所需数据

        FF5需要:
        - 股价数据 (计算收益率)
        - 市值数据 (计算SMB)
        - BM数据 (从pb派生)
        - ROE数据 (从利润表计算)
        - 投资数据 (从资产负债表计算)

        Returns:
            Dict with keys: stock_returns, market_cap, bm, roe, investment
        """
        from ..data.transform import daily_to_monthly, calculate_returns

        if isinstance(period, str):
            period = TimePeriod(period)

        prices = self.get_price_data(start_date, end_date, symbols)
        daily_basic = self.get_daily_basic_data(start_date, end_date, symbols)

        if prices.empty or daily_basic.empty:
            raise ValueError("无法获取价格或市值数据")

        prices = prices[prices['close'] > 0].copy()
        daily_basic = daily_basic[daily_basic['close'] > 0].copy()

        if period == TimePeriod.MONTHLY:
            monthly_prices = daily_to_monthly(prices)
            stock_returns = calculate_returns(monthly_prices)
        else:
            stock_returns = calculate_returns(prices)

        if period == TimePeriod.MONTHLY:
            # 月度：按月聚合市值
            daily_basic['year_month'] = daily_basic['date'].dt.to_period('M')
            market_cap = daily_basic.groupby(['symbol', 'year_month']).agg({
                'total_mv': 'last',
                'date': 'last'
            }).reset_index()
            market_cap.columns = ['symbol', 'year_month', 'mkt_cap', 'date']
            market_cap = market_cap.drop(columns=['year_month'])
        else:
            # 日度：保持每日市值
            market_cap = daily_basic[['symbol', 'date', 'total_mv']].copy()
            market_cap.columns = ['symbol', 'date', 'mkt_cap']

        bm_data = daily_basic[['symbol', 'date', 'bm']].dropna()

        roe_data = self._calculate_roe(start_date, end_date, symbols)
        investment_data = self._calculate_investment(start_date, end_date, symbols)

        # 获取SHIBOR数据（无风险收益率）
        shibor_data = self._get_shibor_data(start_date, end_date)

        return {
            'stock_returns': stock_returns,
            'market_cap': market_cap,
            'bm': bm_data,
            'roe': roe_data,
            'investment': investment_data,
            'shibor': shibor_data,
        }

    def _calculate_roe(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        从利润表计算ROE (净利润/净资产)

        使用最近可用原则：对于每只股票，每个报告期只取一条记录

        Args:
            start_date: 财务数据起始日期（报告期）
            end_date: 财务数据结束日期（报告期）
            symbols: 股票列表

        Returns:
            ROE DataFrame with symbol, date, roe columns
        """
        # 获取利润表和资产负债表数据
        lrb = self.get_financial_data("LRB", start_date, end_date, symbols)
        zcfz = self.get_financial_data("ZCFZ", start_date, end_date, symbols)

        if lrb.empty or zcfz.empty:
            return pd.DataFrame()

        # 按symbol和date(报告期end_date)聚合
        lrb_agg = lrb.groupby(['symbol', 'date']).agg({
            'ni': 'last'
        }).reset_index()

        zcfz_agg = zcfz.groupby(['symbol', 'date']).agg({
            'be': 'last'
        }).reset_index()

        roe_df = lrb_agg.merge(zcfz_agg, on=['symbol', 'date'], how='inner')
        roe_df['roe'] = roe_df['ni'] / roe_df['be']

        return roe_df[['symbol', 'date', 'roe']].dropna()

    def _calculate_investment(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        从资产负债表计算投资 (资产增长率)

        使用最近可用原则：对于每只股票，每个报告期只取一条记录

        Args:
            start_date: 财务数据起始日期（报告期）
            end_date: 财务数据结束日期（报告期）
            symbols: 股票列表

        Returns:
            Investment DataFrame with symbol, date, investment columns
        """
        zcfz = self.get_financial_data("ZCFZ", start_date, end_date, symbols)

        if zcfz.empty:
            return pd.DataFrame()

        zcfz = zcfz.sort_values(['symbol', 'date'])
        zcfz['investment'] = zcfz.groupby('symbol')['ta'].pct_change()

        return zcfz[['symbol', 'date', 'investment']].dropna()


class CARHARTData(FactorReturnData):
    """CARHART因子数据准备"""
    factor_type = FactorType.CARHART

    def _get_shibor_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取SHIBOR数据（无风险收益率参考）"""
        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date

        df = client.get_data(
            self._DataTypes.AK_MACRO_CHINA_SHIBOR_ALL, **kwargs
        )
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        return df.sort_values('date').reset_index(drop=True)

    def prepare_data(
        self,
        period: Union[str, TimePeriod] = "monthly",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, pd.DataFrame]:
        """
        准备CARHART因子所需数据

        CARHART需要:
        - 股价数据 (计算收益率和动量)
        - 市值数据
        - BM数据

        Returns:
            Dict with keys: stock_returns, market_cap, momentum
        """
        from ..data.transform import daily_to_monthly, calculate_returns

        if isinstance(period, str):
            period = TimePeriod(period)

        prices = self.get_price_data(start_date, end_date, symbols)
        daily_basic = self.get_daily_basic_data(start_date, end_date, symbols)

        if prices.empty or daily_basic.empty:
            raise ValueError("无法获取价格或市值数据")

        prices = prices[prices['close'] > 0].copy()
        daily_basic = daily_basic[daily_basic['close'] > 0].copy()

        if period == TimePeriod.MONTHLY:
            monthly_prices = daily_to_monthly(prices)
            stock_returns = calculate_returns(monthly_prices)
        else:
            stock_returns = calculate_returns(prices)

        if period == TimePeriod.MONTHLY:
            # 月度：按月聚合市值
            daily_basic['year_month'] = daily_basic['date'].dt.to_period('M')
            market_cap = daily_basic.groupby(['symbol', 'year_month']).agg({
                'total_mv': 'last',
                'date': 'last'
            }).reset_index()
            market_cap.columns = ['symbol', 'year_month', 'mkt_cap', 'date']
            market_cap = market_cap.drop(columns=['year_month'])
        else:
            # 日度：保持每日市值
            market_cap = daily_basic[['symbol', 'date', 'total_mv']].copy()
            market_cap.columns = ['symbol', 'date', 'mkt_cap']

        momentum = self._calculate_momentum(prices)

        # 获取SHIBOR数据（无风险收益率）
        shibor_data = self._get_shibor_data(start_date, end_date)

        return {
            'stock_returns': stock_returns,
            'market_cap': market_cap,
            'momentum': momentum,
            'shibor': shibor_data,
        }

    def _calculate_momentum(self, prices: pd.DataFrame) -> pd.DataFrame:
        """计算动量因子 (过去12个月收益率，不含最近一个月)"""
        prices = prices.sort_values(['symbol', 'date'])
        prices['return_12m'] = prices.groupby('symbol')['close'].pct_change(252)
        prices['return_1m'] = prices.groupby('symbol')['close'].pct_change(21)
        prices['momentum'] = prices['return_12m'] - prices['return_1m']

        prices['date'] = pd.to_datetime(prices['date'])
        return prices[['symbol', 'date', 'momentum']].dropna()


class NOVY_MARXData(FactorReturnData):
    """NOVY_MARX因子数据准备"""
    factor_type = FactorType.NOVY_MARX

    def _get_shibor_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取SHIBOR数据（无风险收益率参考）"""
        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date

        df = client.get_data(
            self._DataTypes.AK_MACRO_CHINA_SHIBOR_ALL, **kwargs
        )
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        return df.sort_values('date').reset_index(drop=True)

    def prepare_data(
        self,
        period: Union[str, TimePeriod] = "monthly",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, pd.DataFrame]:
        """
        准备NOVY_MARX因子所需数据

        Returns:
            Dict with keys: stock_returns, market_cap, roe
        """
        from ..data.transform import daily_to_monthly, calculate_returns

        if isinstance(period, str):
            period = TimePeriod(period)

        prices = self.get_price_data(start_date, end_date, symbols)
        daily_basic = self.get_daily_basic_data(start_date, end_date, symbols)

        if prices.empty or daily_basic.empty:
            raise ValueError("无法获取价格或市值数据")

        prices = prices[prices['close'] > 0].copy()
        daily_basic = daily_basic[daily_basic['close'] > 0].copy()

        if period == TimePeriod.MONTHLY:
            monthly_prices = daily_to_monthly(prices)
            stock_returns = calculate_returns(monthly_prices)
        else:
            stock_returns = calculate_returns(prices)

        if period == TimePeriod.MONTHLY:
            # 月度：按月聚合市值
            daily_basic['year_month'] = daily_basic['date'].dt.to_period('M')
            market_cap = daily_basic.groupby(['symbol', 'year_month']).agg({
                'total_mv': 'last',
                'date': 'last'
            }).reset_index()
            market_cap.columns = ['symbol', 'year_month', 'mkt_cap', 'date']
            market_cap = market_cap.drop(columns=['year_month'])
        else:
            # 日度：保持每日市值
            market_cap = daily_basic[['symbol', 'date', 'total_mv']].copy()
            market_cap.columns = ['symbol', 'date', 'mkt_cap']

        roe_data = self._calculate_roe(start_date, end_date, symbols)

        # 获取SHIBOR数据（无风险收益率）
        shibor_data = self._get_shibor_data(start_date, end_date)

        return {
            'stock_returns': stock_returns,
            'market_cap': market_cap,
            'roe': roe_data,
            'shibor': shibor_data,
        }

    def _calculate_roe(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """从利润表计算ROE"""
        lrb = self.get_financial_data("LRB", start_date, end_date, symbols)
        zcfz = self.get_financial_data("ZCFZ", start_date, end_date, symbols)

        if lrb.empty or zcfz.empty:
            return pd.DataFrame()

        lrb_agg = lrb.groupby(['symbol', 'date']).agg({
            'ni': 'last'
        }).reset_index()

        zcfz_agg = zcfz.groupby(['symbol', 'date']).agg({
            'be': 'last'
        }).reset_index()

        roe_df = lrb_agg.merge(zcfz_agg, on=['symbol', 'date'], how='inner')
        roe_df['roe'] = roe_df['ni'] / roe_df['be']

        return roe_df[['symbol', 'date', 'roe']].dropna()


class HOU_XUE_ZHANGData(FactorReturnData):
    """HOU_XUE_ZHANG因子数据准备"""
    factor_type = FactorType.HOU_XUE_ZHANG

    def _get_shibor_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取SHIBOR数据（无风险收益率参考）"""
        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date

        df = client.get_data(
            self._DataTypes.AK_MACRO_CHINA_SHIBOR_ALL, **kwargs
        )
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        return df.sort_values('date').reset_index(drop=True)

    def prepare_data(
        self,
        period: Union[str, TimePeriod] = "monthly",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, pd.DataFrame]:
        """
        准备HOU_XUE_ZHANG因子所需数据

        Returns:
            Dict with keys: stock_returns, market_cap, investment, roe
        """
        from ..data.transform import daily_to_monthly, calculate_returns

        if isinstance(period, str):
            period = TimePeriod(period)

        prices = self.get_price_data(start_date, end_date, symbols)
        daily_basic = self.get_daily_basic_data(start_date, end_date, symbols)

        if prices.empty or daily_basic.empty:
            raise ValueError("无法获取价格或市值数据")

        prices = prices[prices['close'] > 0].copy()
        daily_basic = daily_basic[daily_basic['close'] > 0].copy()

        if period == TimePeriod.MONTHLY:
            monthly_prices = daily_to_monthly(prices)
            stock_returns = calculate_returns(monthly_prices)
        else:
            stock_returns = calculate_returns(prices)

        if period == TimePeriod.MONTHLY:
            # 月度：按月聚合市值
            daily_basic['year_month'] = daily_basic['date'].dt.to_period('M')
            market_cap = daily_basic.groupby(['symbol', 'year_month']).agg({
                'total_mv': 'last',
                'date': 'last'
            }).reset_index()
            market_cap.columns = ['symbol', 'year_month', 'mkt_cap', 'date']
            market_cap = market_cap.drop(columns=['year_month'])
        else:
            # 日度：保持每日市值
            market_cap = daily_basic[['symbol', 'date', 'total_mv']].copy()
            market_cap.columns = ['symbol', 'date', 'mkt_cap']

        roe_data = self._calculate_roe(start_date, end_date, symbols)
        investment_data = self._calculate_investment(start_date, end_date, symbols)

        # 获取SHIBOR数据（无风险收益率）
        shibor_data = self._get_shibor_data(start_date, end_date)

        return {
            'stock_returns': stock_returns,
            'market_cap': market_cap,
            'investment': investment_data,
            'roe': roe_data,
            'shibor': shibor_data,
        }

    def _calculate_roe(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """从利润表计算ROE"""
        lrb = self.get_financial_data("LRB", start_date, end_date, symbols)
        zcfz = self.get_financial_data("ZCFZ", start_date, end_date, symbols)

        if lrb.empty or zcfz.empty:
            return pd.DataFrame()

        lrb_agg = lrb.groupby(['symbol', 'date']).agg({
            'ni': 'last'
        }).reset_index()

        zcfz_agg = zcfz.groupby(['symbol', 'date']).agg({
            'be': 'last'
        }).reset_index()

        roe_df = lrb_agg.merge(zcfz_agg, on=['symbol', 'date'], how='inner')
        roe_df['roe'] = roe_df['ni'] / roe_df['be']

        return roe_df[['symbol', 'date', 'roe']].dropna()

    def _calculate_investment(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """从资产负债表计算投资"""
        zcfz = self.get_financial_data("ZCFZ", start_date, end_date, symbols)

        if zcfz.empty:
            return pd.DataFrame()

        zcfz = zcfz.sort_values(['symbol', 'date'])
        zcfz['investment'] = zcfz.groupby('symbol')['ta'].pct_change()

        return zcfz[['symbol', 'date', 'investment']].dropna()



class DHSData(FactorReturnData):
    """DHS因子数据准备"""
    factor_type = FactorType.DHS

    def _get_shibor_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取SHIBOR数据（无风险收益率参考）"""
        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date

        df = client.get_data(
            self._DataTypes.AK_MACRO_CHINA_SHIBOR_ALL, **kwargs
        )
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        return df.sort_values('date').reset_index(drop=True)

    def prepare_data(
        self,
        period: Union[str, TimePeriod] = "monthly",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, pd.DataFrame]:
        """
        准备DHS因子所需数据

        Returns:
            Dict with keys: stock_returns, market_cap, idio_vol
        """
        from ..data.transform import daily_to_monthly, calculate_returns

        if isinstance(period, str):
            period = TimePeriod(period)

        prices = self.get_price_data(start_date, end_date, symbols)
        daily_basic = self.get_daily_basic_data(start_date, end_date, symbols)

        if prices.empty or daily_basic.empty:
            raise ValueError("无法获取价格或市值数据")

        prices = prices[prices['close'] > 0].copy()
        daily_basic = daily_basic[daily_basic['close'] > 0].copy()

        if period == TimePeriod.MONTHLY:
            monthly_prices = daily_to_monthly(prices)
            stock_returns = calculate_returns(monthly_prices)
        else:
            stock_returns = calculate_returns(prices)

        if period == TimePeriod.MONTHLY:
            # 月度：按月聚合市值
            daily_basic['year_month'] = daily_basic['date'].dt.to_period('M')
            market_cap = daily_basic.groupby(['symbol', 'year_month']).agg({
                'total_mv': 'last',
                'date': 'last'
            }).reset_index()
            market_cap.columns = ['symbol', 'year_month', 'mkt_cap', 'date']
            market_cap = market_cap.drop(columns=['year_month'])
        else:
            # 日度：保持每日市值
            market_cap = daily_basic[['symbol', 'date', 'total_mv']].copy()
            market_cap.columns = ['symbol', 'date', 'mkt_cap']

        idio_vol = self._calculate_idio_vol(prices)

        # 获取SHIBOR数据（无风险收益率）
        shibor_data = self._get_shibor_data(start_date, end_date)

        return {
            'stock_returns': stock_returns,
            'market_cap': market_cap,
            'idio_vol': idio_vol,
            'shibor': shibor_data,
        }

    def _calculate_idio_vol(self, prices: pd.DataFrame) -> pd.DataFrame:
        """计算特异性波动率 (简化版：基于收益率标准差)"""
        prices = prices.sort_values(['symbol', 'date'])
        prices['return_60d'] = prices.groupby('symbol')['close'].pct_change(60)
        prices['idio_vol'] = prices.groupby('symbol')['return_60d'].transform('std')

        prices['date'] = pd.to_datetime(prices['date'])
        return prices[['symbol', 'date', 'idio_vol']].dropna()


class CAPMData(FactorReturnData):
    """CAPM因子数据准备"""

    factor_type = FactorType.CAPM

    # 上证指数代码
    INDEX_SYMBOL = "000001"

    def prepare_data(
        self,
        period: Union[str, TimePeriod] = "monthly",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        symbols: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, pd.DataFrame]:
        """
        准备CAPM因子所需数据

        CAPM模型：R_i - R_f = alpha + beta * (R_m - R_f) + epsilon
        - R_i: 股票收益率
        - R_f: 无风险收益率（使用SHIBOR 1个月期）
        - R_m: 市场收益率（使用上证指数）

        Args:
            period: 时间周期 ('monthly' 或 'daily')
            start_date: 开始日期
            end_date: 结束日期
            symbols: 股票代码列表

        Returns:
            Dict with keys: stock_returns, market_return, shibor
        """
        from ..data.transform import daily_to_monthly, calculate_returns

        if isinstance(period, str):
            period = TimePeriod(period)

        # 1. 获取股票收益率
        prices = self.get_price_data(start_date, end_date, symbols)
        if prices.empty:
            raise ValueError("无法获取股票价格数据")

        prices = prices[prices['close'] > 0].copy()

        if period == TimePeriod.MONTHLY:
            monthly_prices = daily_to_monthly(prices)
            stock_returns = calculate_returns(monthly_prices)
        else:
            stock_returns = calculate_returns(prices)

        # 2. 获取上证指数数据（市场收益率）
        index_data = self._get_index_data(start_date, end_date)
        if index_data.empty:
            raise ValueError("无法获取上证指数数据")

        # 3. 获取SHIBOR数据（无风险收益率）
        shibor_data = self._get_shibor_data(start_date, end_date)

        # 4. 计算市场超额收益率
        market_return = self._calculate_market_excess_return(
            index_data, shibor_data, period
        )

        return {
            'stock_returns': stock_returns,
            'market_return': market_return,
            'shibor': shibor_data,
        }

    def _get_index_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取上证指数历史数据"""
        client = self._get_client()
        kwargs = {'symbol': self.INDEX_SYMBOL}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date

        df = client.get_data(self._DataTypes.AK_INDEX_GLOBAL_HIST_EM, **kwargs)
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        return df.sort_values('date').reset_index(drop=True)

    def _get_shibor_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """获取SHIBOR数据（无风险收益率参考）"""
        client = self._get_client()
        kwargs = {}
        if start_date:
            kwargs['start'] = start_date
        if end_date:
            kwargs['end'] = end_date

        df = client.get_data(
            self._DataTypes.AK_MACRO_CHINA_SHIBOR_ALL, **kwargs
        )
        df = self._to_dataframe(df)

        if df.empty:
            return pd.DataFrame()

        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])

        return df.sort_values('date').reset_index(drop=True)

    def _calculate_market_excess_return(
        self,
        index_data: pd.DataFrame,
        shibor_data: pd.DataFrame,
        period: TimePeriod
    ) -> pd.DataFrame:
        """
        计算市场超额收益率

        对于月度：R_mkt_monthly - R_f_monthly
        对于日度：R_mkt_daily - R_f_daily

        SHIBOR为年化百分比，转换方式：
        - 日度Rf = SHIBOR_ON / 360
        - 月度Rf = SHIBOR_1M / 12
        """
        from ..data.transform import daily_to_monthly

        if period == TimePeriod.MONTHLY:
            # 转换指数为月度
            index_monthly = daily_to_monthly(index_data)
            index_monthly = index_monthly.sort_values('date')
            index_monthly['mkt_return'] = index_monthly['close'].pct_change()

            # 月度SHIBOR：取每月最后一个值，转换为月度收益率
            shibor_monthly = shibor_data.copy()
            shibor_monthly['year_month'] = shibor_monthly['date'].dt.to_period('M')
            shibor_monthly = shibor_monthly.groupby('year_month').agg({
                'm1_rate': 'last',  # 1个月期SHIBOR
                'date': 'last'
            }).reset_index()
            shibor_monthly['rf_monthly'] = shibor_monthly['m1_rate'] / 100 / 12
            shibor_monthly['date'] = pd.to_datetime(shibor_monthly['date'])

            # 合并计算超额收益
            result = index_monthly.merge(
                shibor_monthly[['date', 'rf_monthly']],
                on='date',
                how='left'
            )
            result['mkt_excess'] = result['mkt_return'] - result['rf_monthly']
            result = result.dropna(subset=['mkt_excess'])

            return result[['date', 'mkt_return', 'mkt_excess']]

        else:  # DAILY
            index_daily = index_data.sort_values('date').copy()
            index_daily['mkt_return'] = index_daily['close'].pct_change()

            # 日度SHIBOR：使用隔夜SHIBOR，转换为日度收益率
            shibor_daily = shibor_data.copy()
            shibor_daily['rf_daily'] = shibor_daily['on_rate'] / 100 / 360

            # 合并
            result = index_daily.merge(
                shibor_daily[['date', 'rf_daily']],
                on='date',
                how='left'
            )
            result['mkt_excess'] = result['mkt_return'] - result['rf_daily']
            result = result.dropna(subset=['mkt_excess'])

            return result[['date', 'mkt_return', 'mkt_excess']]


# 数据类注册表：因子类型 -> 数据类
DATA_CLASS_REGISTRY: Dict[FactorType, type] = {
    FactorType.FF3: FF3Data,
    FactorType.FF5: FF5Data,
    FactorType.CARHART: CARHARTData,
    FactorType.NOVY_MARX: NOVY_MARXData,
    FactorType.HOU_XUE_ZHANG: HOU_XUE_ZHANGData,
    FactorType.DHS: DHSData,
    FactorType.CAPM: CAPMData,
}


def get_factor_data_class(factor_type: FactorType) -> type:
    """获取因子对应的数据准备类"""
    if factor_type not in DATA_CLASS_REGISTRY:
        raise ValueError(f"Unknown factor type: {factor_type}")
    return DATA_CLASS_REGISTRY[factor_type]


# 导出
__all__ = [
    "FactorReturnData",
    "FF3Data",
    "FF5Data",
    "CARHARTData",
    "NOVY_MARXData",
    "HOU_XUE_ZHANGData",
    "DHSData",
    "CAPMData",
    "get_factor_data_class",
    "DATA_CLASS_REGISTRY",
]
