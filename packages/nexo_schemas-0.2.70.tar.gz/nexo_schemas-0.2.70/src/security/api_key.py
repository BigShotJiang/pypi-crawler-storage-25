import re
from enum import StrEnum
from pydantic import BaseModel, Field
from typing import Annotated
from nexo.enums.environment import Environment
from nexo.types.string import ListOfStrs


class APIKeyType(StrEnum):
    PERSONAL = "pak"
    SYSTEM = "sak"
    TENANT = "tak"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


KEY_BODY_PATTERN = re.compile(r"^[A-Za-z0-9_-]{32,256}$")

# BUILD REGEX DYNAMICALLY
# This dynamically creates: ^(.+)-(local|staging|production)-(pak|sak|tak)-(.+)$
# This ensures that even if we add a new Enum value, we don't have to touch this code.
_ENV_PATTERN = "|".join(Environment.choices())
_TYPE_PATTERN = "|".join(APIKeyType.choices())
API_KEY_REGEX = re.compile(rf"^(.+)-({_ENV_PATTERN})-({_TYPE_PATTERN})-(.+)$")


class APIKey(BaseModel):
    api_key: Annotated[str, Field(..., description="API Key", max_length=255)]


def validate(api_key: str, application: str, environment: Environment):
    # Use the regex to parse the key
    match = API_KEY_REGEX.match(api_key)

    if not match:
        raise ValueError(
            "API Key must be in format <APPLICATION>-<ENVIRONMENT>-<KEY_TYPE>-<BODY>"
        )

    # Regex groups: 1=App, 2=Env, 3=Type, 4=Body
    app_name, env_str, _, key_body = match.groups()

    # 1. Ensure 'application' matches
    if app_name != application:
        raise ValueError(f"API Key must start with '{application}', got '{app_name}'")

    # 2. Validate Environment rules
    # Note: env_str is guaranteed to be a valid choice because of the Regex
    api_key_environment = Environment(env_str)

    if environment is Environment.LOCAL:
        if api_key_environment not in (Environment.LOCAL, Environment.STAGING):
            raise ValueError(
                "Only local and staging API Key can be used in local environment"
            )
    elif environment is Environment.STAGING:
        if api_key_environment is not Environment.STAGING:
            raise ValueError("Only staging API Key can be used in staging environment")
    elif environment is Environment.PRODUCTION:
        if api_key_environment is not Environment.PRODUCTION:
            raise ValueError(
                "Only production API Key can be used in production environment"
            )

    # 3. Validate key body
    # (Note: type_str is also guaranteed valid by regex, so no need to check manually)
    if not KEY_BODY_PATTERN.match(key_body):
        raise ValueError(f"Invalid API Key body format: {key_body!r}")
