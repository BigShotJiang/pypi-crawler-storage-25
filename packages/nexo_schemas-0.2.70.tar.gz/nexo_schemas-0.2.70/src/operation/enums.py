from enum import StrEnum
from typing import Annotated, Generic, Sequence, TypeVar
from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class IdSource(StrEnum):
    HEADER = "header"
    STATE = "state"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


class OperationType(StrEnum):
    RESOURCE = "resource"
    REQUEST = "request"
    SYSTEM = "system"
    WEBSOCKET = "websocket"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OperationTypeT = TypeVar("OperationTypeT", bound=OperationType)
OptOperationType = OperationType | None
OptOperationTypeT = TypeVar("OptOperationTypeT", bound=OptOperationType)


class OperationTypeMixin(BaseModel, Generic[OptOperationTypeT]):
    type: Annotated[OptOperationTypeT, Field(..., description="Operation's Type")]


ListOfOperationTypes = list[OperationType]
ListOfOperationTypesT = TypeVar("ListOfOperationTypesT", bound=ListOfOperationTypes)
OptListOfOperationTypes = ListOfOperationTypes | None
OptListOfOperationTypesT = TypeVar(
    "OptListOfOperationTypesT", bound=OptListOfOperationTypes
)


class OperationTypesMixin(BaseModel, Generic[OptListOfOperationTypesT]):
    types: Annotated[
        OptListOfOperationTypesT,
        Field(..., description="Operation's Types", min_length=1),
    ]


SeqOfOperationTypes = Sequence[OperationType]
SeqOfOperationTypesT = TypeVar("SeqOfOperationTypesT", bound=SeqOfOperationTypes)
OptSeqOfOperationTypes = SeqOfOperationTypes | None
OptSeqOfOperationTypesT = TypeVar(
    "OptSeqOfOperationTypesT", bound=OptSeqOfOperationTypes
)


class SystemOperationType(StrEnum):
    BACKGROUND_JOB = "background_job"
    CONFIGURATION_UPDATE = "configuration_update"
    CRON_JOB = "cron_job"
    DATABASE_CONNECTION = "database_connection"
    DISPOSAL = "disposal"
    HEALTH_CHECK = "health_check"
    HEARTBEAT = "heartbeat"
    METRIC_REPORT = "metric_report"
    INITIALIZATION = "initialization"
    STARTUP = "startup"
    SHUTDOWN = "shutdown"
    SYSTEM_ALERT = "system_alert"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptSystemOperationType = SystemOperationType | None


class WebSocketOperationType(StrEnum):
    CONNECT = "connect"
    DISCONNECT = "disconnect"
    ERROR = "error"
    RECEIVE = "receive"
    SEND = "send"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptWebSocketOperationType = WebSocketOperationType | None


class ResourceOperationType(StrEnum):
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


ResourceOperationTypeT = TypeVar("ResourceOperationTypeT", bound=ResourceOperationType)
OptResourceOperationType = ResourceOperationType | None


class ResourceOperationReadType(StrEnum):
    DATA = "data"
    SUMMARY = "summary"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationReadType = ResourceOperationReadType | None


class ResourceOperationUpdateType(StrEnum):
    DATA = "data"
    STATUS = "status"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationUpdateType = ResourceOperationUpdateType | None


class ResourceOperationDataUpdateType(StrEnum):
    FULL = "full"
    PARTIAL = "partial"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationDataUpdateType = ResourceOperationDataUpdateType | None


class ResourceOperationStatusUpdateType(StrEnum):
    ACTIVATE = "activate"
    DEACTIVATE = "deactivate"
    RESTORE = "restore"
    DELETE = "delete"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationStatusUpdateType = ResourceOperationStatusUpdateType | None


class Origin(StrEnum):
    SERVICE = "service"
    CLIENT = "client"
    UTILITY = "utility"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OriginT = TypeVar("OriginT", bound=Origin)
OptOrigin = Origin | None
OptOriginT = TypeVar("OptOriginT", bound=OptOrigin)


class OriginMixin(BaseModel, Generic[OptOriginT]):
    origin: Annotated[OptOriginT, Field(..., description="Operation's Origin")]


ListOfOrigins = list[Origin]
ListOfOriginsT = TypeVar("ListOfOriginsT", bound=ListOfOrigins)
OptListOfOrigins = ListOfOrigins | None
OptListOfOriginsT = TypeVar("OptListOfOriginsT", bound=OptListOfOrigins)


class OriginsMixin(BaseModel, Generic[OptListOfOriginsT]):
    origins: Annotated[
        OptListOfOriginsT, Field(..., description="Operation's Origins", min_length=1)
    ]


SeqOfOrigins = Sequence[Origin]
SeqOfOriginsT = TypeVar("SeqOfOriginsT", bound=SeqOfOrigins)
OptSeqOfOrigins = SeqOfOrigins | None
OptSeqOfOriginsT = TypeVar("OptSeqOfOriginsT", bound=OptSeqOfOrigins)


class Layer(StrEnum):
    INFRASTRUCTURE = "infrastructure"
    CONFIGURATION = "configuration"
    UTILITY = "utility"
    MIDDLEWARE = "middleware"
    CONTROLLER = "controller"
    SERVICE = "service"
    REPOSITORY = "repository"
    INTERNAL = "internal"
    OTHER = "other"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


LayerT = TypeVar("LayerT", bound=Layer)
OptLayer = Layer | None
OptLayerT = TypeVar("OptLayerT", bound=OptLayer)


class LayerMixin(BaseModel, Generic[OptLayerT]):
    layer: Annotated[OptLayerT, Field(..., description="Operation's Layer")]


ListOfLayers = list[Layer]
ListOfLayersT = TypeVar("ListOfLayersT", bound=ListOfLayers)
OptListOfLayers = ListOfLayers | None
OptListOfLayersT = TypeVar("OptListOfLayersT", bound=OptListOfLayers)


class LayersMixin(BaseModel, Generic[OptListOfLayersT]):
    layers: Annotated[
        OptListOfLayersT, Field(..., description="Operation's Layers", min_length=1)
    ]


SeqOfLayers = Sequence[Layer]
SeqOfLayersT = TypeVar("SeqOfLayersT", bound=SeqOfLayers)
OptSeqOfLayers = SeqOfLayers | None
OptSeqOfLayersT = TypeVar("OptSeqOfLayersT", bound=OptSeqOfLayers)


class Target(StrEnum):
    MONITORING = "monitoring"
    CACHE = "cache"
    CONTROLLER = "controller"
    DATABASE = "database"
    INTERNAL = "internal"
    MICROSERVICE = "microservice"
    SERVICE = "service"
    REPOSITORY = "repository"
    THIRD_PARTY = "third_party"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


TargetT = TypeVar("TargetT", bound=Target)
OptTarget = Target | None
OptTargetT = TypeVar("OptTargetT", bound=OptTarget)


class TargetMixin(BaseModel, Generic[OptTargetT]):
    target: Annotated[OptTargetT, Field(..., description="Operation's Target")]


ListOfTargets = list[Target]
ListOfTargetsT = TypeVar("ListOfTargetsT", bound=ListOfTargets)
OptListOfTargets = ListOfTargets | None
OptListOfTargetsT = TypeVar("OptListOfTargetsT", bound=OptListOfTargets)


class TargetsMixin(BaseModel, Generic[OptListOfTargetsT]):
    targets: Annotated[
        OptListOfTargetsT, Field(..., description="Operation's Targets", min_length=1)
    ]


SeqOfTargets = Sequence[Target]
SeqOfTargetsT = TypeVar("SeqOfTargetsT", bound=SeqOfTargets)
OptSeqOfTargets = SeqOfTargets | None
OptSeqOfTargetsT = TypeVar("OptSeqOfTargetsT", bound=OptSeqOfTargets)
