import os
from functools import cached_property
from google.cloud.pubsub_v1.publisher.futures import Future
from logging import Logger
from typing import Generic, Literal, overload
from nexo.logging.enums import LogLevel
from nexo.types.boolean import BoolT, OptBool
from nexo.types.dict import (
    OptStrToStrDict,
    StrToAnyDict,
    StrToStrDict,
)
from nexo.types.string import ListOfStrs, OptListOfStrs
from nexo.utils.exception import extract_details
from nexo.utils.merger import merge_dicts
from ..application import ApplicationContextMixin
from ..connection import OptConnectionContextT, ConnectionContextMixin
from ..google import ListOfPublisherHandlers
from ..error import OptAnyErrorT, ErrorMixin
from ..mixins.general import Success
from ..resource import OptResourceT, ResourceMixin
from ..response import (
    OptResponseContextT,
    ResponseContextMixin,
    OptResponseT,
    ResponseMixin,
)
from ..security.authentication import (
    OptAnyAuthentication,
    AuthenticationMixin,
)
from ..security.authorization import OptAnyAuthorization, AuthorizationMixin
from ..security.impersonation import OptImpersonation, ImpersonationMixin
from .action import (
    ActionMixin,
    ActionT,
)
from .context import ContextMixin
from .enums import OperationType, OperationTypeMixin, ListOfOperationTypes
from .mixins import Id, IsAI, Summary, TimestampMixin


class BaseOperation(
    ResponseContextMixin[OptResponseContextT],
    ResponseMixin[OptResponseT],
    ImpersonationMixin[OptImpersonation],
    AuthorizationMixin[OptAnyAuthorization],
    AuthenticationMixin[OptAnyAuthentication],
    ConnectionContextMixin[OptConnectionContextT],
    ErrorMixin[OptAnyErrorT],
    Success[BoolT],
    Summary,
    TimestampMixin,
    ResourceMixin[OptResourceT],
    ActionMixin[ActionT],
    ContextMixin,
    OperationTypeMixin[OperationType],
    IsAI,
    Id,
    ApplicationContextMixin,
    Generic[
        ActionT,
        OptResourceT,
        BoolT,
        OptAnyErrorT,
        OptConnectionContextT,
        OptResponseT,
        OptResponseContextT,
    ],
):
    @property
    def log_message(self) -> str:
        message = f"Operation {self.id} - {self.type} - "

        success_information = "success" if self.success else "failed"

        if self.response_context is not None:
            success_information += f" {self.response_context.status_code}"

        message += f"{success_information} - "

        duration: float = self.timestamp.duration
        if duration < 1:
            duration_str = f"{int(duration * 1000)}ms"
        else:
            duration_str = f"{duration:.2f}s"

        message += f"{duration_str} - "

        if self.connection_context is not None:
            message += (
                f"{self.connection_context.method} {self.connection_context.url} - "
                f"IP: {self.connection_context.ip_address} - "
            )

        if self.authentication is None:
            authentication = "No Authentication"
        else:
            if not self.authentication.user.is_authenticated:
                authentication = "Unauthenticated"
            else:
                authentication = (
                    "Authenticated | "
                    f"Organization: {self.authentication.user.organization} | "
                    f"Username: {self.authentication.user.display_name} | "
                    f"Email: {self.authentication.user.identity}"
                )

        message += f"{authentication} - "
        message += self.summary

        return message

    @property
    def labels(self) -> StrToStrDict:
        labels = {
            "environment": self.application_context.environment,
            "service_key": self.application_context.service_key,
            "instance_id": self.application_context.instance_id,
            "operation_id": str(self.id),
            "operation_type": self.type,
            "success": str(self.success),
        }

        if self.connection_context is not None:
            if self.connection_context.method is not None:
                labels["method"] = self.connection_context.method
            labels["url"] = self.connection_context.url
        if self.response_context is not None:
            labels["status_code"] = str(self.response_context.status_code)

        return labels

    def log_labels(
        self,
        *,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
    ) -> StrToStrDict:
        if override_labels is not None:
            return override_labels

        labels = self.labels
        if additional_labels is not None:
            for k, v in additional_labels.items():
                if k in labels.keys():
                    raise ValueError(
                        f"Key '{k}' already exist in labels, override the labels if necessary"
                    )
                labels[k] = v
            labels = merge_dicts(labels, additional_labels)
        return labels

    def log_extra(
        self,
        *,
        additional_extra: OptStrToStrDict = None,
        override_extra: OptStrToStrDict = None,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
    ) -> StrToAnyDict:
        labels = self.log_labels(
            additional_labels=additional_labels, override_labels=override_labels
        )

        if override_extra is not None:
            extra = override_extra
        else:
            extra = {
                "json_fields": {"operation": self.model_dump(mode="json")},
                "labels": labels,
            }
            if additional_extra is not None:
                extra = merge_dicts(extra, additional_extra)

        return extra

    def log(
        self,
        logger: Logger,
        level: LogLevel = LogLevel.INFO,
        *,
        exc_info: OptBool = None,
        additional_extra: OptStrToStrDict = None,
        override_extra: OptStrToStrDict = None,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
    ):
        try:
            message = self.log_message
            extra = self.log_extra(
                additional_extra=additional_extra,
                override_extra=override_extra,
                additional_labels=additional_labels,
                override_labels=override_labels,
            )
            logger.log(
                level,
                message,
                exc_info=exc_info,
                extra=extra,
            )
        except Exception as e:
            labels = self.log_labels(
                additional_labels=additional_labels, override_labels=override_labels
            )
            logger.error(
                f"Failed logging {self.type} Operation {self.id}",
                exc_info=True,
                extra={
                    "json_fields": {"exc_details": extract_details(e)},
                    "labels": labels,
                },
            )

    @cached_property
    def allowed_to_publish(self) -> bool:
        # 1. Read from env (comma-separated string)
        raw_value = (
            os.getenv("PUBLISHABLE_OPERATIONS", "")
            .strip()
            .removeprefix("[")
            .removesuffix("]")
            .replace(" ", "")
        )

        # 2. Parse into list of OperationType
        publishable_ops: ListOfOperationTypes = []
        if raw_value:
            for v in raw_value.split(","):
                v = v.strip().replace('"', "").lower()
                try:
                    publishable_ops.append(OperationType(v))
                except ValueError:
                    continue  # ignore invalid values

        # 3. Check if self.type is allowed
        return self.type in publishable_ops

    @overload
    def publish(
        self,
        logger: Logger,
        publishers: ListOfPublisherHandlers = [],
        *,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
        wait_for_message_ids: Literal[True],
    ) -> ListOfStrs: ...
    @overload
    def publish(
        self,
        logger: Logger,
        publishers: ListOfPublisherHandlers = [],
        *,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
        wait_for_message_ids: Literal[False] = False,
    ) -> None: ...
    def publish(
        self,
        logger: Logger,
        publishers: ListOfPublisherHandlers = [],
        *,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
        wait_for_message_ids: bool = False,
    ) -> OptListOfStrs:
        if not self.allowed_to_publish:
            return None

        labels = self.log_labels(
            additional_labels=additional_labels, override_labels=override_labels
        )
        message_ids: ListOfStrs = []
        for publisher in publishers:
            topic_path = publisher.client.topic_path(
                publisher.project_id, publisher.topic_id
            )
            try:
                future: Future = publisher.client.publish(
                    topic_path,
                    data=self.model_dump_json().encode(),
                    **self.application_context.model_dump(mode="json"),
                )

                summary = f"Successfully published {self.type} Operation {self.id} to {topic_path}"
                json_fields = {
                    "operation": self.model_dump(mode="json"),
                    "topic_path": topic_path,
                }

                if wait_for_message_ids:
                    message_id: str = future.result()
                    message_ids.append(message_id)
                    summary += f" through message {message_id}"
                    json_fields["message_id"] = message_id

                logger.debug(
                    summary,
                    extra={
                        "json_fields": json_fields,
                        "labels": labels,
                    },
                )

            except Exception as e:
                logger.error(
                    f"Failed publishing {self.type} Operation {self.id}",
                    exc_info=True,
                    extra={
                        "json_fields": {"exc_details": extract_details(e)},
                        "labels": labels,
                    },
                )
                raise

        return message_ids if wait_for_message_ids else None

    @overload
    def log_and_publish(
        self,
        logger: Logger,
        publishers: ListOfPublisherHandlers = [],
        level: LogLevel = LogLevel.INFO,
        *,
        exc_info: OptBool = None,
        additional_extra: OptStrToStrDict = None,
        override_extra: OptStrToStrDict = None,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
        wait_for_message_ids: Literal[True],
    ) -> ListOfStrs: ...
    @overload
    def log_and_publish(
        self,
        logger: Logger,
        publishers: ListOfPublisherHandlers = [],
        level: LogLevel = LogLevel.INFO,
        *,
        exc_info: OptBool = None,
        additional_extra: OptStrToStrDict = None,
        override_extra: OptStrToStrDict = None,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
        wait_for_message_ids: Literal[False] = False,
    ) -> None: ...
    def log_and_publish(
        self,
        logger: Logger,
        publishers: ListOfPublisherHandlers = [],
        level: LogLevel = LogLevel.INFO,
        *,
        exc_info: OptBool = None,
        additional_extra: OptStrToStrDict = None,
        override_extra: OptStrToStrDict = None,
        additional_labels: OptStrToStrDict = None,
        override_labels: OptStrToStrDict = None,
        wait_for_message_ids: bool = False,
    ) -> OptListOfStrs:
        self.log(
            logger,
            level,
            exc_info=exc_info,
            additional_extra=additional_extra,
            override_extra=override_extra,
            additional_labels=additional_labels,
            override_labels=override_labels,
        )
        return self.publish(
            logger,
            publishers,
            additional_labels=additional_labels,
            override_labels=override_labels,
            wait_for_message_ids=wait_for_message_ids,
        )
