from pydantic import BaseModel, Field
from typing import Annotated, Generic, Sequence, TypeVar
from ..enums import (
    ResourceOperationType,
    SystemOperationType,
    WebSocketOperationType,
)


OperationAction = ResourceOperationType | SystemOperationType | WebSocketOperationType


OperationActionT = TypeVar("OperationActionT", bound=OperationAction)
OptOperationAction = OperationAction | None
OptOperationActionT = TypeVar("OptOperationActionT", bound=OptOperationAction)


class OperationActionMixin(BaseModel, Generic[OptOperationActionT]):
    action: Annotated[OptOperationActionT, Field(..., description="Operation's Action")]


ListOfOperationActions = list[OperationAction]
ListOfOperationActionsT = TypeVar(
    "ListOfOperationActionsT", bound=ListOfOperationActions
)
OptListOfOperationActions = ListOfOperationActions | None
OptListOfOperationActionsT = TypeVar(
    "OptListOfOperationActionsT", bound=OptListOfOperationActions
)


class OperationActionsMixin(BaseModel, Generic[OptListOfOperationActionsT]):
    actions: Annotated[
        OptListOfOperationActionsT,
        Field(..., description="Operation's Actions", min_length=1),
    ]


SeqOfOperationActions = Sequence[OperationAction]
SeqOfOperationActionsT = TypeVar("SeqOfOperationActionsT", bound=SeqOfOperationActions)
OptSeqOfOperationActions = SeqOfOperationActions | None
OptSeqOfOperationActionsT = TypeVar(
    "OptSeqOfOperationActionsT", bound=OptSeqOfOperationActions
)
