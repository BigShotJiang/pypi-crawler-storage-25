from enum import StrEnum
from pydantic import BaseModel, Field
from typing import Annotated, Generic, Sequence, TypeVar
from nexo.types.string import ListOfStrs


class ErrorType(StrEnum):
    BAD_REQUEST = "client.bad_request"
    UNAUTHORIZED = "client.unauthorized"
    FORBIDDEN = "client.forbidden"
    NOT_FOUND = "client.not_found"
    CONFLICT = "client.conflict"
    METHOD_NOT_ALLOWED = "client.method_not_allowed"
    UNPROCESSABLE_ENTITY = "client.unprocessable_entity"
    TOO_MANY_REQUESTS = "client.too_many_requests"
    INTERNAL_SERVER_ERROR = "server.internal_server_error"
    NOT_IMPLEMENTED = "server.not_implemented"
    BAD_GATEWAY = "server.bad_gateway"
    SERVICE_UNAVAILABLE = "server.service_unavailable"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


ErrorTypeT = TypeVar("ErrorTypeT", bound=ErrorType)
OptErrorType = ErrorType | None
OptErrorTypeT = TypeVar("OptErrorTypeT", bound=OptErrorType)


class SimpleErrorTypeMixin(BaseModel, Generic[OptErrorTypeT]):
    type: Annotated[OptErrorTypeT, Field(..., description="Error's Type")]


class FullErrorTypeMixin(BaseModel, Generic[OptErrorTypeT]):
    error_type: Annotated[OptErrorTypeT, Field(..., description="Error's Type")]


ListOfErrorTypes = list[ErrorType]
ListOfErrorTypesT = TypeVar("ListOfErrorTypesT", bound=ListOfErrorTypes)
OptListOfErrorTypes = ListOfErrorTypes | None
OptListOfErrorTypesT = TypeVar("OptListOfErrorTypesT", bound=OptListOfErrorTypes)


class SimpleErrorTypesMixin(BaseModel, Generic[OptListOfErrorTypesT]):
    types: Annotated[
        OptListOfErrorTypesT,
        Field(..., description="Error's Types", min_length=1),
    ]


class FullErrorTypesMixin(BaseModel, Generic[OptListOfErrorTypesT]):
    error_types: Annotated[
        OptListOfErrorTypesT,
        Field(..., description="Error's Types", min_length=1),
    ]


SeqOfErrorTypes = Sequence[ErrorType]
SeqOfErrorTypesT = TypeVar("SeqOfErrorTypesT", bound=SeqOfErrorTypes)
OptSeqOfErrorTypes = SeqOfErrorTypes | None
OptSeqOfErrorTypesT = TypeVar("OptSeqOfErrorTypesT", bound=OptSeqOfErrorTypes)


class ErrorCode(StrEnum):
    BAD_REQUEST = "MAL-ERR-CLI-BDR"
    UNAUTHORIZED = "MAL-ERR-CLI-ATH"
    FORBIDDEN = "MAL-ERR-CLI-FBD"
    NOT_FOUND = "MAL-ERR-CLI-NTF"
    METHOD_NOT_ALLOWED = "MAL-ERR-CLI-MNA"
    CONFLICT = "MAL-ERR-CLI-CFL"
    UNPROCESSABLE_ENTITY = "MAL-ERR-CLI-UPE"
    TOO_MANY_REQUESTS = "MAL-ERR-CLI-TMR"
    INTERNAL_SERVER_ERROR = "MAL-ERR-SRV-ISE"
    NOT_IMPLEMENTED = "MAL-ERR-SRV-NIM"
    BAD_GATEWAY = "MAL-ERR-SRV-BDG"
    SERVICE_UNAVAILABLE = "MAL-ERR-SRV-SUN"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]
