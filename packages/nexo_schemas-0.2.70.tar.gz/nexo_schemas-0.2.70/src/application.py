import socket
from Crypto.PublicKey.RSA import RsaKey
from enum import StrEnum
from functools import cached_property
from pathlib import Path
from pydantic import BaseModel, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Annotated, ClassVar, Self, TypeVar, overload
from uuid import UUID
from nexo.enums.environment import Environment
from nexo.enums.system import SystemRole, ListOfSystemRoles
from nexo.enums.user import UserType
from nexo.types.dict import StrToAnyDict
from nexo.types.misc import BytesOrStr, OptIntOrStr
from nexo.types.string import ListOfStrs, OptStr
from .mixins.identity import DataIdentifier, EntityIdentifier
from .operation.enums import ListOfOperationTypes
from .security.api_key import validate
from .security.authentication import SystemCredentials, SystemUser, SystemAuthentication
from .security.authorization import APIKeyAuthorization
from .security.enums import Domain
from .security.token import Token


class Execution(StrEnum):
    CONTAINER = "container"
    DIRECT = "direct"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


class ApplicationContext(BaseSettings):
    model_config: ClassVar[SettingsConfigDict] = SettingsConfigDict(extra="ignore")

    instance_id: Annotated[str, Field(..., validation_alias="INSTANCE_ID")]

    @model_validator(mode="before")
    def define_default_instance_id(cls, data: StrToAnyDict):
        if "INSTANCE_ID" not in data:
            data["INSTANCE_ID"] = socket.gethostname()
        return data

    name: Annotated[str, Field(..., validation_alias="NAME")]
    environment: Annotated[Environment, Field(..., validation_alias="ENVIRONMENT")]
    service_key: Annotated[str, Field(..., validation_alias="SERVICE_KEY")]

    @classmethod
    def new(cls) -> Self:
        return cls()  # type: ignore


OptApplicationContext = ApplicationContext | None


class ApplicationContextMixin(BaseModel):
    application_context: ApplicationContext = Field(
        default_factory=ApplicationContext.new,
        description="Application's context",
    )


class ApplicationSettings(BaseSettings):
    model_config: ClassVar[SettingsConfigDict] = SettingsConfigDict(extra="ignore")

    # Instance related settings
    INSTANCE_ID: Annotated[str, Field(..., description="Instance's ID")]

    @model_validator(mode="before")
    def define_default_instance_id(cls, data: StrToAnyDict):
        if "INSTANCE_ID" not in data:
            data["INSTANCE_ID"] = socket.gethostname()
        return data

    # Application related settings
    NAME: Annotated[str, Field(..., description="Application's name")]

    # Service related settings
    ENVIRONMENT: Annotated[Environment, Field(..., description="Environment")]
    SERVICE_KEY: Annotated[str, Field(..., description="Service's key")]
    SERVICE_NAME: Annotated[str, Field(..., description="Service's name")]

    @cached_property
    def context(self) -> ApplicationContext:
        return ApplicationContext(
            instance_id=self.INSTANCE_ID,
            name=self.NAME,
            environment=self.ENVIRONMENT,
            service_key=self.SERVICE_KEY,
        )

    # Serving related settings
    EXECUTION: Annotated[
        Execution, Field(Execution.CONTAINER, description="Execution mode")
    ] = Execution.CONTAINER
    RELOAD: Annotated[bool, Field(..., description="Reload")]

    @model_validator(mode="before")
    def define_default_reload(cls, data: StrToAnyDict):
        if "RELOAD" not in data:
            environment = Environment(data["ENVIRONMENT"])
            execution = Execution(data["EXECUTION"])
            data["RELOAD"] = (
                environment is Environment.LOCAL and execution is Execution.DIRECT
            )
        return data

    HOST: Annotated[str, Field("127.0.0.1", description="Application's host")] = (
        "127.0.0.1"
    )
    PORT: Annotated[int, Field(8000, description="Application's port")] = 8000
    HOST_PORT: Annotated[int, Field(8000, description="Host's port")] = 8000

    @cached_property
    def port(self) -> int:
        if self.EXECUTION is Execution.DIRECT and self.ENVIRONMENT is Environment.LOCAL:
            return self.HOST_PORT
        else:
            return self.PORT

    DOCKER_NETWORK: Annotated[str, Field(..., description="Docker's network")]

    @model_validator(mode="before")
    def define_default_docker_network(cls, data: StrToAnyDict):
        if "DOCKER_NETWORK" not in data:
            data["DOCKER_NETWORK"] = f"{data["NAME"]}-{data["ENVIRONMENT"]}"
        return data

    CONTAINER_MEMORY: Annotated[
        OptIntOrStr,
        Field(
            None, description="Container's memory", examples=["512m", "2g", 1073741824]
        ),
    ] = None

    ROOT_PATH: Annotated[str, Field("", description="Application's root path")] = ""

    # Configuration related settings
    USE_LOCAL_CONFIG: Annotated[
        bool, Field(False, description="Whether to use locally stored config")
    ] = False
    CONFIG_PATH: Annotated[OptStr, Field(None, description="Config path")] = None

    @model_validator(mode="after")
    def validate_config_path(self) -> Self:
        if self.USE_LOCAL_CONFIG:
            if self.CONFIG_PATH is None:
                self.CONFIG_PATH = f"/etc/{self.NAME}/{self.ENVIRONMENT}/configs/{self.SERVICE_KEY}.yaml"
            config_path = Path(self.CONFIG_PATH)
            if not config_path.exists() or not config_path.is_file():
                raise ValueError(
                    f"Config path '{self.CONFIG_PATH}' either did not exist or is not a file"
                )

        return self

    # Google related settings
    GOOGLE_APPLICATION_CREDENTIALS: Annotated[
        str,
        Field(
            ...,
            description="Google application credential's file path",
        ),
    ]

    @model_validator(mode="before")
    def define_default_google_aplication_credentials(cls, data: StrToAnyDict):
        if "GOOGLE_APPLICATION_CREDENTIALS" not in data:
            credentials = f"/etc/{data["NAME"]}/{data["ENVIRONMENT"]}/credentials/google-service-account.json"
            data["GOOGLE_APPLICATION_CREDENTIALS"] = credentials
        return data

    GOOGLE_CLOUD_PROJECT: Annotated[
        str, Field(..., description="Google Cloud Project ID")
    ]

    # Client related settings
    CLIENT_ID: Annotated[UUID, Field(..., description="Client's ID")]
    CLIENT_SECRET: Annotated[UUID, Field(..., description="Client's Secret")]

    # API Key
    API_KEY: Annotated[str, Field(..., description="API Key")]

    @model_validator(mode="after")
    def validate_api_key(self) -> Self:
        validate(self.API_KEY, self.NAME, self.ENVIRONMENT)
        return self

    @cached_property
    def authorization(self) -> APIKeyAuthorization:
        return APIKeyAuthorization(credentials=self.API_KEY)

    # Principal
    P_ID: Annotated[int, Field(..., description="P's ID", ge=1)]
    P_UUID: Annotated[UUID, Field(..., description="P's UUID")]

    @property
    def token(self) -> Token:
        return Token.new(sub=self.P_UUID)

    @overload
    def generate_token_string(
        self,
        key: RsaKey,
    ) -> str: ...
    @overload
    def generate_token_string(
        self,
        key: BytesOrStr,
        *,
        password: OptStr = None,
    ) -> str: ...
    def generate_token_string(
        self,
        key: BytesOrStr | RsaKey,
        *,
        password: OptStr = None,
    ) -> str:
        return self.token.to_string(key, password=password)

    # Service Account
    SA_ID: Annotated[int, Field(..., description="SA's ID", ge=1)]
    SA_UUID: Annotated[UUID, Field(..., description="SA's UUID")]
    SA_ROLES: Annotated[
        ListOfSystemRoles,
        Field([SystemRole.ADMINISTRATOR], description="SA's Roles", min_length=1),
    ] = [SystemRole.ADMINISTRATOR]
    SA_USERNAME: Annotated[str, Field(..., description="SA's Username")]
    SA_EMAIL: Annotated[str, Field(..., description="SA's Email")]

    @cached_property
    def authentication(self) -> SystemAuthentication:
        return SystemAuthentication(
            credentials=SystemCredentials(
                principal=DataIdentifier(id=self.P_ID, uuid=self.P_UUID),
                user=EntityIdentifier[UserType](
                    id=self.SA_ID, uuid=self.SA_UUID, type=UserType.SERVICE
                ),
                domain_roles=self.SA_ROLES,
                scopes=["authenticated", Domain.SYSTEM]
                + [f"{Domain.SYSTEM}:{role.value}" for role in self.SA_ROLES],
            ),
            user=SystemUser(display_name=self.SA_USERNAME, identity=self.SA_EMAIL),
        )

    # Infra related settings
    PUBLISH_HEARTBEAT: Annotated[
        bool, Field(..., description="Whether to publish heartbeat")
    ]

    PUBLISH_RESOURCE_MEASUREMENT: Annotated[
        bool, Field(..., description="Whether to publish resource measurement")
    ]

    @model_validator(mode="before")
    def define_default_infra_publishing(cls, data: StrToAnyDict):
        environment = Environment(data["ENVIRONMENT"])
        default_allowed_environment = (Environment.STAGING, Environment.PRODUCTION)
        if "PUBLISH_HEARTBEAT" not in data:
            data["PUBLISH_HEARTBEAT"] = environment in default_allowed_environment
        if "PUBLISH_RESOURCE_MEASUREMENT" not in data:
            data["PUBLISH_RESOURCE_MEASUREMENT"] = (
                environment in default_allowed_environment
            )
        return data

    # Operation related settings
    PUBLISHABLE_OPERATIONS: Annotated[
        ListOfOperationTypes, Field([], description="Publishable operations")
    ] = []

    # Security related settings
    USE_LOCAL_KEY: Annotated[
        bool, Field(False, description="Whether to use locally stored key")
    ] = False
    PRIVATE_KEY_PASSWORD: Annotated[
        OptStr, Field(None, description="Private key's password")
    ] = None
    PRIVATE_KEY_PATH: Annotated[str, Field(..., description="Private key's path")]
    PUBLIC_KEY_PATH: Annotated[str, Field(..., description="Public key's path")]

    @model_validator(mode="before")
    def define_default_key_path(cls, data: StrToAnyDict):
        keys_folder = f"/etc/{data["NAME"]}/{data["ENVIRONMENT"]}/keys/"
        if "PRIVATE_KEY_PATH" not in data:
            data["PRIVATE_KEY_PATH"] = keys_folder + "private.pem"
        if "PUBLIC_KEY_PATH" not in data:
            data["PUBLIC_KEY_PATH"] = keys_folder + "public.pem"
        return data

    @model_validator(mode="after")
    def validate_keys_path(self) -> Self:
        if self.USE_LOCAL_KEY:
            private_key_path = Path(self.PRIVATE_KEY_PATH)
            if not private_key_path.exists() or not private_key_path.is_file():
                raise ValueError(
                    f"Private key path: '{self.PRIVATE_KEY_PATH}' either did not exist or is not a file"
                )

            public_key_path = Path(self.PUBLIC_KEY_PATH)
            if not public_key_path.exists() or not public_key_path.is_file():
                raise ValueError(
                    f"Public key path: '{self.PUBLIC_KEY_PATH}' either did not exist or is not a file"
                )

        return self


ApplicationSettingsT = TypeVar("ApplicationSettingsT", bound=ApplicationSettings)
