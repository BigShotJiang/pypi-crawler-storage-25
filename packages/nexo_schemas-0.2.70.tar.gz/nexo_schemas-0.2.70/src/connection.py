from datetime import datetime
from pydantic import BaseModel, Field, computed_field
from fastapi.requests import HTTPConnection
from typing import Annotated, Callable, Generic, TypeVar
from uuid import UUID
from nexo.enums.connection import Scheme, Header
from nexo.types.boolean import OptBool
from nexo.types.dict import OptStrToStrDict
from nexo.types.string import OptStr, OptListOfDoubleStrs
from .error.enums import ErrorCode
from .user_agent import UserAgent, OptUserAgent


class ConnectionContext(BaseModel):
    id: Annotated[UUID, Field(..., description="Connection's ID")]

    executed_at: Annotated[datetime, Field(..., description="Executed At Timestamp")]

    method: Annotated[
        OptStr, Field(None, description="HTTP method (None for WebSocket)")
    ] = None

    scheme: Annotated[Scheme, Field(..., description="Connection's scheme (http/ws)")]

    root_path: Annotated[str, Field("", description="Root path of the application")] = (
        ""
    )

    url: Annotated[str, Field(..., description="Connection URL")]

    @computed_field
    @property
    def raw_url(self) -> str:
        path = self.url.removeprefix(self.root_path)
        if not self.path_params:
            return path

        # We use a tuple for segments to avoid regex/look-behind issues
        # A path is just a series of segments separated by '/'
        # Example: '/users/123/posts/456' -> ['', 'users', '123', 'posts', '456']
        segments = path.split("/")

        # Create a mapping of value -> key for fast lookup
        # Note: If multiple params have the same value, the first one encountered wins,
        # which is usually acceptable for URL templating.
        val_to_key = {value: key for key, value in self.path_params.items()}

        new_segments = []
        for segment in segments:
            if segment in val_to_key:
                new_segments.append(f"{{{val_to_key[segment]}}}")
            else:
                new_segments.append(segment)

        return "/".join(new_segments)

    ip_address: Annotated[str, Field("unknown", description="Client's IP address")] = (
        "unknown"
    )
    is_internal: Annotated[
        OptBool, Field(None, description="True if IP is internal")
    ] = None

    headers: Annotated[
        OptListOfDoubleStrs, Field(None, description="Connection's headers")
    ] = None

    path_params: Annotated[
        OptStrToStrDict, Field(None, description="Path parameters")
    ] = None

    query_params: Annotated[OptStr, Field(None, description="Query parameters")] = None

    user_agent: Annotated[OptUserAgent, Field(None, description="User agent")] = None

    referer: Annotated[OptStr, Field(None, description="Referrer URL")] = None

    origin: Annotated[OptStr, Field(None, description="Origin header")] = None

    host: Annotated[OptStr, Field(None, description="Host header")] = None

    forwarded_proto: Annotated[
        OptStr, Field(None, description="Forwarded protocol")
    ] = None

    language: Annotated[OptStr, Field(None, description="Accepted languages")] = None

    @classmethod
    def extract_client_ip(cls, conn: HTTPConnection) -> str:
        x_forwarded_for = conn.headers.get(Header.X_FORWARDED_FOR)
        if x_forwarded_for:
            ips = [ip.strip() for ip in x_forwarded_for.split(",")]
            return ips[0]

        x_real_ip = conn.headers.get(Header.X_REAL_IP)
        if x_real_ip:
            return x_real_ip

        return conn.client.host if conn.client else "unknown"

    @classmethod
    def from_connection(cls, conn: HTTPConnection) -> "ConnectionContext":
        id = getattr(conn.state, "connection_id", None)
        if not id or not isinstance(id, UUID):
            raise RuntimeError(
                ErrorCode.INTERNAL_SERVER_ERROR,
                "Missing or invalid 'connection_id' in connection state. "
                "Ensure StateMiddleware is correctly installed in the ASGI stack.",
            )

        executed_at = getattr(conn.state, "executed_at", None)
        if not executed_at or not isinstance(executed_at, datetime):
            raise RuntimeError(
                ErrorCode.INTERNAL_SERVER_ERROR,
                "Missing or invalid 'executed_at' in connection state. "
                "Ensure StateMiddleware is correctly installed in the ASGI stack.",
            )

        root_path = str(getattr(conn.state, "root_path", ""))

        ip_address = cls.extract_client_ip(conn)

        ua_string = conn.headers.get(Header.USER_AGENT, "")
        user_agent = (
            UserAgent.from_string(user_agent_string=ua_string) if ua_string else None
        )

        return cls(
            id=id,
            executed_at=executed_at,
            method=getattr(conn, "method", None),  # WebSocket doesn’t have method
            scheme=Scheme(conn.url.scheme),
            root_path=root_path,
            url=conn.url.path,
            ip_address=ip_address,
            is_internal=(
                None
                if ip_address == "unknown"
                else (
                    ip_address.startswith("10.")
                    or ip_address.startswith("192.168.")
                    or ip_address.startswith("172.")
                    or ip_address.startswith("127.")
                )
            ),
            headers=conn.headers.items(),
            path_params=conn.path_params,
            query_params=(None if not conn.query_params else str(conn.query_params)),
            user_agent=user_agent,
            referer=conn.headers.get(Header.REFERER),
            origin=conn.headers.get(Header.ORIGIN),
            host=conn.headers.get(Header.HOST),
            forwarded_proto=conn.headers.get(Header.X_FORWARDED_PROTO),
            language=conn.headers.get(Header.ACCEPT_LANGUAGE),
        )

    @classmethod
    def as_dependency(cls) -> Callable[[HTTPConnection], "ConnectionContext"]:
        def dependency(conn: HTTPConnection) -> "ConnectionContext":
            return cls.from_connection(conn)

        return dependency


OptConnectionContext = ConnectionContext | None
OptConnectionContextT = TypeVar("OptConnectionContextT", bound=OptConnectionContext)


class ConnectionContextMixin(BaseModel, Generic[OptConnectionContextT]):
    connection_context: OptConnectionContextT = Field(
        ..., description="Connection context"
    )
