import json
import random
import threading
import time
from collections import defaultdict
from collections.abc import Callable
from functools import wraps
from typing import Any

SAMPLE_RATE = 0.01  # 1% of calls
FLUSH_INTERVAL = 10  # seconds

_lock = threading.RLock()
COUNTS: dict[str, int] = defaultdict(int)
LAST_FLUSH = time.time()

# Use a dedicated Random instance rather than the module-level shared state.
# random.random() delegates to a module-level instance whose internal state is
# shared across all threads; under heavy concurrent use the GIL prevents data
# corruption but can cause non-uniform sampling distributions.  A private
# instance avoids this without requiring per-call locking.
_rng = random.Random()


def set_seed(seed: int) -> None:
    """Seed the sampler's RNG for deterministic behaviour (e.g. in tests)."""
    _rng.seed(seed)


def should_sample() -> bool:
    return _rng.random() < SAMPLE_RATE


def trace(func: Callable[..., Any]) -> Callable[..., Any]:
    name = f"{func.__module__}.{func.__qualname__}"

    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        global LAST_FLUSH

        if should_sample():
            with _lock:
                COUNTS[name] += 1

        # periodic flush (non-blocking-ish)
        now = time.time()
        with _lock:
            if now - LAST_FLUSH > FLUSH_INTERVAL:
                try:
                    flush()
                except Exception:
                    pass
                LAST_FLUSH = now

        return func(*args, **kwargs)

    return wrapper


def flush(path: str | None = None) -> None:
    import os
    import tempfile

    if path is None:
        # Default to a project-relative path (like trace_calls.py) to avoid
        # world-writable temp-directory symlink attacks.
        path = ".runtime_calls.json"

    with _lock:
        data = dict(COUNTS)

    dir_name = os.path.dirname(os.path.abspath(path)) or "."
    with tempfile.NamedTemporaryFile(
        mode="w", dir=dir_name, delete=False, suffix=".json"
    ) as f:
        json.dump(data, f)
        temp_path = f.name

    os.replace(temp_path, path)


import atexit as _atexit

_atexit.register(flush)


def install_tracer(module: object, prefix: str | None = None) -> None:
    for name in dir(module):
        obj = getattr(module, name)

        if callable(obj) and hasattr(obj, "__module__"):
            if prefix and not obj.__module__.startswith(prefix):
                continue
            try:
                setattr(module, name, trace(obj))
            except Exception:
                pass
