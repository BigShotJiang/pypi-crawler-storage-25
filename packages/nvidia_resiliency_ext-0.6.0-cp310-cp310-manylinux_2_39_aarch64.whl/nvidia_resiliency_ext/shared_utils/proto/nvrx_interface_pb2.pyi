from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class NVRxCycleInfo(_message.Message):
    __slots__ = ("job_id", "attempt_index", "cycle_number", "cycle_start_time", "cycle_end_time", "cycle_log_file", "active_nodes", "standby_nodes", "generation", "active_ranks")
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_INDEX_FIELD_NUMBER: _ClassVar[int]
    CYCLE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    CYCLE_START_TIME_FIELD_NUMBER: _ClassVar[int]
    CYCLE_END_TIME_FIELD_NUMBER: _ClassVar[int]
    CYCLE_LOG_FILE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_NODES_FIELD_NUMBER: _ClassVar[int]
    STANDBY_NODES_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_RANKS_FIELD_NUMBER: _ClassVar[int]
    job_id: str
    attempt_index: int
    cycle_number: int
    cycle_start_time: str
    cycle_end_time: str
    cycle_log_file: str
    active_nodes: str
    standby_nodes: str
    generation: int
    active_ranks: str
    def __init__(self, job_id: _Optional[str] = ..., attempt_index: _Optional[int] = ..., cycle_number: _Optional[int] = ..., cycle_start_time: _Optional[str] = ..., cycle_end_time: _Optional[str] = ..., cycle_log_file: _Optional[str] = ..., active_nodes: _Optional[str] = ..., standby_nodes: _Optional[str] = ..., generation: _Optional[int] = ..., active_ranks: _Optional[str] = ...) -> None: ...
