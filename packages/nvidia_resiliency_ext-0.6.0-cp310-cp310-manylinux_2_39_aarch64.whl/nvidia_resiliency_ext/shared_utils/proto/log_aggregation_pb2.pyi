from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class LogChunk(_message.Message):
    __slots__ = ("node_id", "data", "file_path")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    FILE_PATH_FIELD_NUMBER: _ClassVar[int]
    node_id: str
    data: bytes
    file_path: str
    def __init__(self, node_id: _Optional[str] = ..., data: _Optional[bytes] = ..., file_path: _Optional[str] = ...) -> None: ...

class StreamResponse(_message.Message):
    __slots__ = ("status", "bytes_received")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BYTES_RECEIVED_FIELD_NUMBER: _ClassVar[int]
    status: str
    bytes_received: int
    def __init__(self, status: _Optional[str] = ..., bytes_received: _Optional[int] = ...) -> None: ...

class HealthRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HealthResponse(_message.Message):
    __slots__ = ("healthy", "connected_clients")
    HEALTHY_FIELD_NUMBER: _ClassVar[int]
    CONNECTED_CLIENTS_FIELD_NUMBER: _ClassVar[int]
    healthy: bool
    connected_clients: int
    def __init__(self, healthy: bool = ..., connected_clients: _Optional[int] = ...) -> None: ...
