# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""PyTorch Lightning helpers for fault tolerance with ``ft_launcher`` (InJob).

.. deprecated::
    This package is deprecated and will be removed in a future release.
    Importing public symbols from this package may emit :exc:`DeprecationWarning`.
"""

from ._utils import SimulatedFaultParams  # noqa: F401
from .fault_tolerance_callback import FaultToleranceCallback  # noqa: F401
from .fault_tolerance_sections_callback import FaultToleranceSectionsCallback  # noqa: F401
from .straggler_det_callback import StragglerDetectionCallback  # noqa: F401
