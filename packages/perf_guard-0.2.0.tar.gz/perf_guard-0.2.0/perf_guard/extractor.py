"""
extractor.py — 从结果目录按配置提取指标
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional, Tuple

from .config import Config, MetricConfig
from .storage import empty_snapshot


def extract_metric(result_dir: Path, mc: MetricConfig) -> Tuple[Optional[float], Optional[str]]:
    """
    Extract a single metric value from result_dir.
    Returns (value, error_str). error_str is None on success.
    """
    target = result_dir / mc.file
    if not target.exists():
        return None, f"{mc.name}: file not found: {mc.file}"

    try:
        text = target.read_text(errors="replace")
    except OSError as e:
        return None, f"{mc.name}: cannot read {mc.file}: {e}"

    m = re.search(mc.pattern, text)
    if m is None:
        return None, f"{mc.name}: pattern not matched in {mc.file}"

    try:
        value = float(m.group(1))
    except (IndexError, ValueError) as e:
        return None, f"{mc.name}: cannot convert match to float: {e}"

    return value, None


def extract_all(config: Config, result_dir: Path) -> dict:
    """
    Extract all enabled metrics from result_dir.
    Returns a snapshot dict ready for storage.
    """
    dirname = result_dir.name
    snapshot = empty_snapshot(dirname)

    for mc in config.enabled_metrics():
        value, error = extract_metric(result_dir, mc)
        if error:
            snapshot["extraction_errors"].append(error)
        else:
            snapshot["metrics"][mc.name] = {"value": value, "unit": "extracted"}

    return snapshot
