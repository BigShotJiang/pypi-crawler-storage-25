"""
comparator.py — 两个版本的指标对比逻辑
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from .config import Config


@dataclass
class MetricDiff:
    name: str
    base_value: Optional[float]
    current_value: Optional[float]
    delta_pct: Optional[float]      # None if either value missing
    is_regression: bool
    threshold_pct: float
    direction: str

    @property
    def available(self) -> bool:
        return self.base_value is not None and self.current_value is not None


@dataclass
class CompareResult:
    base_dirname: str
    current_dirname: str
    diffs: List[MetricDiff]

    @property
    def regressions(self) -> List[MetricDiff]:
        return [d for d in self.diffs if d.is_regression]

    @property
    def has_regression(self) -> bool:
        return len(self.regressions) > 0


def compare(
    config: Config,
    base_snapshot: dict,
    current_snapshot: dict,
) -> CompareResult:
    """Compute per-metric diffs between base and current snapshots."""
    base_metrics: Dict[str, float] = {
        k: v["value"] for k, v in base_snapshot.get("metrics", {}).items()
        if v.get("value") is not None
    }
    current_metrics: Dict[str, float] = {
        k: v["value"] for k, v in current_snapshot.get("metrics", {}).items()
        if v.get("value") is not None
    }

    diffs: List[MetricDiff] = []
    for mc in config.enabled_metrics():
        base_val = base_metrics.get(mc.name)
        cur_val = current_metrics.get(mc.name)

        if base_val is None or cur_val is None:
            diffs.append(MetricDiff(
                name=mc.name,
                base_value=base_val,
                current_value=cur_val,
                delta_pct=None,
                is_regression=False,
                threshold_pct=mc.threshold_pct,
                direction=mc.direction,
            ))
            continue

        if base_val == 0:
            delta_pct = 0.0
        else:
            delta_pct = (cur_val - base_val) / abs(base_val) * 100.0

        if mc.direction == "lower_is_better":
            is_regression = delta_pct > mc.threshold_pct
        else:
            is_regression = delta_pct < -mc.threshold_pct

        diffs.append(MetricDiff(
            name=mc.name,
            base_value=base_val,
            current_value=cur_val,
            delta_pct=delta_pct,
            is_regression=is_regression,
            threshold_pct=mc.threshold_pct,
            direction=mc.direction,
        ))

    return CompareResult(
        base_dirname=base_snapshot["dirname"],
        current_dirname=current_snapshot["dirname"],
        diffs=diffs,
    )
