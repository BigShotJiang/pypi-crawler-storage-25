"""
config.py — 加载和验证 perf_guard.yaml
"""
from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml


@dataclass
class MetricConfig:
    name: str
    file: str
    pattern: str
    threshold_pct: float = 5.0
    direction: str = "lower_is_better"
    enabled: bool = True

    def validate(self) -> List[str]:
        errors = []
        if not re.match(r"^[a-zA-Z0-9_]+$", self.name):
            errors.append(f"metric '{self.name}': name must be alphanumeric + underscore")
        if self.direction not in ("lower_is_better", "higher_is_better"):
            errors.append(
                f"metric '{self.name}': direction must be 'lower_is_better' or 'higher_is_better'"
            )
        try:
            re.compile(self.pattern)
        except re.error as e:
            errors.append(f"metric '{self.name}': invalid pattern: {e}")
        if self.threshold_pct <= 0:
            errors.append(f"metric '{self.name}': threshold_pct must be > 0")
        return errors


@dataclass
class Config:
    results_dir: Path
    metrics: List[MetricConfig]
    config_path: Path = field(default_factory=Path)

    @property
    def history_dir(self) -> Path:
        return self.config_path.parent / ".perf_history"

    def enabled_metrics(self) -> List[MetricConfig]:
        return [m for m in self.metrics if m.enabled]


def find_config(start: Optional[Path] = None) -> Path:
    """Walk up from start (default: cwd) looking for perf_guard.yaml."""
    current = (start or Path.cwd()).resolve()
    while True:
        candidate = current / "perf_guard.yaml"
        if candidate.exists():
            return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    return Path()


def load_config(config_path: Optional[Path] = None) -> Config:
    """Load and validate config. Exits with code 1 on error."""
    if config_path is None:
        found = find_config()
        if not found.exists():
            print(
                "Error: perf_guard.yaml not found.\n"
                "Create one in your project root. Example:\n\n"
                "  results_dir: ./results\n"
                "  metrics:\n"
                "    - name: eval_time\n"
                "      file: summary.txt\n"
                "      pattern: 'Eval time:\\s+([\\d.]+)s'\n",
                file=sys.stderr,
            )
            sys.exit(1)
        config_path = found

    try:
        raw = yaml.safe_load(config_path.read_text())
    except yaml.YAMLError as e:
        print(f"Error: perf_guard.yaml parse error: {e}", file=sys.stderr)
        sys.exit(1)

    errors: List[str] = []

    if not isinstance(raw, dict):
        print("Error: perf_guard.yaml must be a mapping.", file=sys.stderr)
        sys.exit(1)

    if "results_dir" not in raw:
        errors.append("missing required field: results_dir")
    if "metrics" not in raw or not isinstance(raw.get("metrics"), list):
        errors.append("missing required field: metrics (must be a list)")

    if errors:
        for e in errors:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    results_dir = (config_path.parent / raw["results_dir"]).resolve()

    metric_names: set = set()
    metric_configs: List[MetricConfig] = []
    for i, m in enumerate(raw["metrics"]):
        if not isinstance(m, dict):
            errors.append(f"metrics[{i}]: must be a mapping")
            continue
        for req in ("name", "file", "pattern"):
            if req not in m:
                errors.append(f"metrics[{i}]: missing required field '{req}'")
        if errors:
            continue
        mc = MetricConfig(
            name=m["name"],
            file=m["file"],
            pattern=m["pattern"],
            threshold_pct=float(m.get("threshold_pct", 5.0)),
            direction=m.get("direction", "lower_is_better"),
            enabled=bool(m.get("enabled", True)),
        )
        errs = mc.validate()
        errors.extend(errs)
        if mc.name in metric_names:
            errors.append(f"metric name '{mc.name}' is not unique")
        metric_names.add(mc.name)
        metric_configs.append(mc)

    if errors:
        for e in errors:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if not metric_configs:
        print("Error: metrics list is empty.", file=sys.stderr)
        sys.exit(1)

    return Config(
        results_dir=results_dir,
        metrics=metric_configs,
        config_path=config_path,
    )
