"""
storage.py — .perf_history/ 的读写
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional


# ── 数据结构 ──────────────────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def empty_snapshot(dirname: str) -> dict:
    return {
        "dirname": dirname,
        "recorded_at": _now_iso(),
        "tags": [],
        "metrics": {},
        "extraction_errors": [],
    }


# ── 索引操作 ──────────────────────────────────────────────────────────────────

def _index_path(history_dir: Path) -> Path:
    return history_dir / "index.json"


def load_index(history_dir: Path) -> dict:
    p = _index_path(history_dir)
    if not p.exists():
        return {"tags": {}, "latest": ""}
    return json.loads(p.read_text())


def save_index(history_dir: Path, index: dict) -> None:
    history_dir.mkdir(parents=True, exist_ok=True)
    _index_path(history_dir).write_text(json.dumps(index, indent=2))


# ── 快照操作 ──────────────────────────────────────────────────────────────────

def snapshot_path(history_dir: Path, dirname: str) -> Path:
    return history_dir / f"{dirname}.json"


def save_snapshot(history_dir: Path, snapshot: dict) -> None:
    history_dir.mkdir(parents=True, exist_ok=True)
    snapshot_path(history_dir, snapshot["dirname"]).write_text(
        json.dumps(snapshot, indent=2)
    )


def load_snapshot(history_dir: Path, dirname: str) -> Optional[dict]:
    p = snapshot_path(history_dir, dirname)
    if not p.exists():
        return None
    return json.loads(p.read_text())


def all_snapshots(history_dir: Path) -> List[dict]:
    """All snapshots sorted by recorded_at ascending (oldest first)."""
    if not history_dir.exists():
        return []
    snapshots = []
    for p in sorted(history_dir.glob("*.json")):
        if p.name == "index.json":
            continue
        try:
            snapshots.append(json.loads(p.read_text()))
        except (json.JSONDecodeError, OSError):
            pass
    snapshots.sort(key=lambda s: s.get("recorded_at", ""))
    return snapshots


# ── ref 解析 ──────────────────────────────────────────────────────────────────

# Time-based built-in refs. Each maps to a number of days before "now".
_TIME_ALIASES = {
    "yesterday":    1,
    "last_week":    7,
    "last_month":  30,
}

# Accepts forms like "7d_ago", "14d_ago", "7_days_ago", "3days_ago".
_DAYS_AGO_RE = re.compile(r"^(\d+)\s*(?:d|days?)_?ago$", re.IGNORECASE)

# Accepts forms like "latest~1", "latest~5" meaning N records before latest.
_LATEST_OFFSET_RE = re.compile(r"^latest~(\d+)$")


def _parse_iso(s: str) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def _closest_snapshot_to(history_dir: Path, target: datetime) -> Optional[str]:
    """Return dirname of snapshot whose recorded_at is closest to target."""
    best_dirname: Optional[str] = None
    best_delta: Optional[timedelta] = None
    for snap in all_snapshots(history_dir):
        ts = _parse_iso(snap.get("recorded_at", ""))
        if ts is None:
            continue
        delta = abs(ts - target)
        if best_delta is None or delta < best_delta:
            best_delta = delta
            best_dirname = snap["dirname"]
    return best_dirname


def resolve_ref(history_dir: Path, ref: str) -> Optional[str]:
    """
    Resolve a ref string to a dirname.

    Resolution order:
      1. Built-in "latest"
      2. User tags in index.json
      3. Direct dirname (snapshot file exists)
      4. Built-in time aliases: yesterday, last_week, last_month
      5. Numeric "<N>d_ago" / "<N>_days_ago" pattern
      6. "latest~N" pattern (N records before the newest)
    Returns None if not found.
    """
    index = load_index(history_dir)

    if ref == "latest":
        return index.get("latest") or None

    if ref in index.get("tags", {}):
        return index["tags"][ref]

    if snapshot_path(history_dir, ref).exists():
        return ref

    # Time alias
    days: Optional[int] = _TIME_ALIASES.get(ref)
    if days is None:
        m = _DAYS_AGO_RE.match(ref)
        if m:
            days = int(m.group(1))

    if days is not None:
        target = datetime.now(timezone.utc) - timedelta(days=days)
        return _closest_snapshot_to(history_dir, target)

    # latest~N offset
    m = _LATEST_OFFSET_RE.match(ref)
    if m:
        offset = int(m.group(1))
        snaps = all_snapshots(history_dir)
        if not snaps:
            return None
        idx = len(snaps) - 1 - offset
        if idx < 0 or idx >= len(snaps):
            return None
        return snaps[idx]["dirname"]

    return None


def available_refs(history_dir: Path) -> List[str]:
    """Return all known refs for error messages."""
    index = load_index(history_dir)
    refs = list(index.get("tags", {}).keys()) + ["latest"]
    refs += list(_TIME_ALIASES.keys())
    for s in all_snapshots(history_dir):
        refs.append(s["dirname"])
    return sorted(set(refs))


# ── record 主流程 ─────────────────────────────────────────────────────────────

def record(
    history_dir: Path,
    snapshot: dict,
    tags: List[str],
) -> None:
    """Persist snapshot and update index with tags and latest."""
    dirname = snapshot["dirname"]

    existing = load_snapshot(history_dir, dirname)
    existing_tags = set(existing.get("tags", [])) if existing else set()
    snapshot["tags"] = sorted(existing_tags | set(tags))

    save_snapshot(history_dir, snapshot)

    index = load_index(history_dir)
    index.setdefault("tags", {})
    for tag in tags:
        index["tags"][tag] = dirname
    index["latest"] = dirname
    save_index(history_dir, index)
