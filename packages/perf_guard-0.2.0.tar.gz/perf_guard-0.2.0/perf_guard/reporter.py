"""
reporter.py — 终端输出格式化
"""
from __future__ import annotations

import sys
from typing import List, Optional, Tuple

from .comparator import CompareResult, MetricDiff
from .storage import all_snapshots, load_index

_W_METRIC = 22
_W_COL    = 12
_SEP      = "─"


def _sep_line(width: int) -> str:
    return _SEP * width


def _fmt_value(v: Optional[float]) -> str:
    if v is None:
        return "N/A"
    return f"{v:.1f}"


def _fmt_delta(delta: Optional[float]) -> str:
    if delta is None:
        return "N/A"
    sign = "+" if delta >= 0 else ""
    return f"{sign}{delta:.1f}%"


def _fmt_status(diff: MetricDiff) -> str:
    if not diff.available:
        return "⚠️  N/A"
    if diff.is_regression:
        return "🔴"
    return "✅"


def _print_compare_table(result: CompareResult, base_label: str, out) -> None:
    """Print a single base-vs-current table."""
    print(
        f"\nComparing  current ({result.current_dirname})"
        f"  vs  {base_label} ({result.base_dirname})\n",
        file=out,
    )

    base_col_label = base_label.upper() if len(base_label) <= _W_COL - 1 else "BASE"
    header = (
        f"{'METRIC':<{_W_METRIC}}"
        f"{base_col_label:>{_W_COL}}"
        f"{'CURRENT':>{_W_COL}}"
        f"{'DELTA':>{_W_COL}}"
        f"{'STATUS':>{_W_COL}}"
    )
    print(header, file=out)
    print(_sep_line(_W_METRIC + _W_COL * 4 + 3), file=out)

    for diff in result.diffs:
        row = (
            f"{diff.name:<{_W_METRIC}}"
            f"{_fmt_value(diff.base_value):>{_W_COL}}"
            f"{_fmt_value(diff.current_value):>{_W_COL}}"
            f"{_fmt_delta(diff.delta_pct):>{_W_COL}}"
            f"  {_fmt_status(diff)}"
        )
        print(row, file=out)

    print("", file=out)

    regressions = result.regressions
    if not regressions:
        print("✅  No regressions detected.", file=out)
    else:
        n = len(regressions)
        print(f"🔴  {n} regression{'s' if n > 1 else ''} detected:", file=out)
        for diff in regressions:
            print(
                f"    {diff.name}: {_fmt_delta(diff.delta_pct)}"
                f" exceeds threshold ({diff.threshold_pct:.0f}%)",
                file=out,
            )
    print("", file=out)


def print_compare(result: CompareResult, out=None, base_label: str = "baseline") -> None:
    """Print a compare result against a single base."""
    out = out or sys.stdout
    _print_compare_table(result, base_label, out)


def print_compare_multi(
    results: List[Tuple[str, CompareResult]],
    out=None,
) -> None:
    """
    Print compare results for multiple baselines.
    `results` is a list of (base_label, CompareResult) tuples.
    """
    out = out or sys.stdout
    for base_label, result in results:
        _print_compare_table(result, base_label, out)


def print_list(history_dir, out=None) -> None:
    out = out or sys.stdout
    snapshots = all_snapshots(history_dir)
    index = load_index(history_dir)
    latest_dirname = index.get("latest", "")

    tag_map: dict = {}
    for tag, dirname in index.get("tags", {}).items():
        tag_map.setdefault(dirname, []).append(tag)

    W_TAG     = 16
    W_DIRNAME = 24
    W_DATE    = 20

    header = f"{'TAG':<{W_TAG}}{'DIRNAME':<{W_DIRNAME}}{'RECORDED AT':<{W_DATE}}"
    print(header, file=out)
    print(_SEP * (W_TAG + W_DIRNAME + W_DATE), file=out)

    for snap in snapshots:
        dirname = snap["dirname"]
        tags = tag_map.get(dirname, [])
        is_latest = dirname == latest_dirname

        if tags:
            tag_str = ", ".join(tags)
        elif is_latest:
            tag_str = "(latest)"
        else:
            tag_str = "(untagged)"

        latest_marker = " ← latest" if is_latest and bool(tags) else ""
        recorded = snap.get("recorded_at", "")[:16].replace("T", " ")
        print(
            f"{tag_str:<{W_TAG}}{dirname:<{W_DIRNAME}}{recorded:<{W_DATE}}{latest_marker}",
            file=out,
        )


def print_report(snapshot: dict, tag_map: dict, out=None) -> None:
    out = out or sys.stdout
    dirname = snapshot["dirname"]
    tags = tag_map.get(dirname, [])
    tag_str = f"  [{', '.join(tags)}]" if tags else ""
    recorded = snapshot.get("recorded_at", "")

    print(f"\nVersion: {dirname}{tag_str}", file=out)
    print(f"Recorded: {recorded}\n", file=out)

    W_NAME = 26
    W_VAL  = 12
    print(f"{'METRIC':<{W_NAME}}{'VALUE':>{W_VAL}}", file=out)
    print(_SEP * (W_NAME + W_VAL), file=out)

    metrics = snapshot.get("metrics", {})
    if metrics:
        for name, entry in metrics.items():
            val = entry.get("value")
            print(f"{name:<{W_NAME}}{_fmt_value(val):>{W_VAL}}", file=out)
    else:
        print("  (no metrics recorded)", file=out)

    errors = snapshot.get("extraction_errors", [])
    print("", file=out)
    if errors:
        print("Extraction errors:", file=out)
        for e in errors:
            print(f"  {e}", file=out)
    else:
        print("Extraction errors: none", file=out)
    print("", file=out)


def print_record_result(snapshot: dict, out=None) -> None:
    out = out or sys.stdout
    dirname = snapshot["dirname"]
    n_ok  = len(snapshot.get("metrics", {}))
    n_err = len(snapshot.get("extraction_errors", []))
    tags  = snapshot.get("tags", [])
    tag_str = f"\nTags: {', '.join(tags)}" if tags else ""
    print(f"Recorded  {dirname}  ({n_ok} metrics, {n_err} errors){tag_str}", file=out)

    if n_err:
        for e in snapshot["extraction_errors"]:
            print(f"  ⚠️  {e}", file=out)


# ── trend: ASCII chart ────────────────────────────────────────────────────────

_SPARK_CHARS = "▁▂▃▄▅▆▇█"


def _sparkline(values: List[Optional[float]]) -> str:
    nums = [v for v in values if v is not None]
    if not nums:
        return ""
    lo, hi = min(nums), max(nums)
    span = hi - lo if hi > lo else 1.0
    out = []
    for v in values:
        if v is None:
            out.append(" ")
        else:
            idx = int((v - lo) / span * (len(_SPARK_CHARS) - 1))
            out.append(_SPARK_CHARS[idx])
    return "".join(out)


def print_trend_ascii(
    series: List[dict],
    metric_names: List[str],
    out=None,
) -> None:
    """
    Print a simple ASCII sparkline per metric over the given series.

    `series` is a list of snapshot dicts (already filtered and sorted).
    """
    out = out or sys.stdout
    if not series:
        print("No snapshots to plot.", file=out)
        return

    labels = [s["dirname"] for s in series]
    print(f"\nTrend across {len(series)} snapshot(s):", file=out)
    print(f"  first: {labels[0]}", file=out)
    print(f"  last:  {labels[-1]}\n", file=out)

    W_NAME = 26
    W_SPARK = max(8, len(series))
    print(f"{'METRIC':<{W_NAME}}{'TREND':<{W_SPARK + 2}}  MIN → MAX  (LAST)", file=out)
    print(_SEP * (W_NAME + W_SPARK + 30), file=out)

    for name in metric_names:
        values = [
            s.get("metrics", {}).get(name, {}).get("value")
            for s in series
        ]
        nums = [v for v in values if v is not None]
        if not nums:
            print(f"{name:<{W_NAME}}(no data)", file=out)
            continue
        last = values[-1]
        spark = _sparkline(values)
        summary = f"{min(nums):.1f} → {max(nums):.1f}  ({_fmt_value(last)})"
        print(f"{name:<{W_NAME}}{spark:<{W_SPARK + 2}}  {summary}", file=out)
    print("", file=out)
