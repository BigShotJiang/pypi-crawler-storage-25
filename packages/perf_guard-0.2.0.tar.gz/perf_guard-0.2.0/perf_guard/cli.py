"""
cli.py — 命令行入口（Click）
"""
from __future__ import annotations

import stat
import sys
from pathlib import Path
from typing import List, Optional, Tuple

import click

from .comparator import compare
from .config import load_config
from .extractor import extract_all
from .reporter import (
    print_compare_multi,
    print_list,
    print_record_result,
    print_report,
    print_trend_ascii,
)
from .storage import (
    available_refs,
    load_index,
    load_snapshot,
    record,
    resolve_ref,
)
from .trend import pick_metric_names, render_html, select_series


# ── helpers ───────────────────────────────────────────────────────────────────

def _resolve_or_exit(history_dir: Path, ref: str) -> str:
    dirname = resolve_ref(history_dir, ref)
    if dirname is None:
        refs = available_refs(history_dir)
        click.echo(
            f"Error: ref '{ref}' not found.\n"
            f"Available refs: {', '.join(refs) if refs else '(none — run record first)'}",
            err=True,
        )
        sys.exit(1)
    return dirname


def _load_snapshot_or_exit(history_dir: Path, dirname: str) -> dict:
    snap = load_snapshot(history_dir, dirname)
    if snap is None:
        click.echo(f"Error: snapshot for '{dirname}' not found in {history_dir}", err=True)
        sys.exit(1)
    return snap


def _latest_result_dir(results_dir: Path) -> Optional[Path]:
    """Return the most recently modified subdirectory of results_dir."""
    if not results_dir.exists():
        return None
    subdirs = [d for d in results_dir.iterdir() if d.is_dir()]
    if not subdirs:
        return None
    return max(subdirs, key=lambda d: d.stat().st_mtime)


# ── CLI root ──────────────────────────────────────────────────────────────────

@click.group()
@click.option(
    "--config", "config_path",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="Path to perf_guard.yaml (default: auto-discover)",
)
@click.pass_context
def main(ctx: click.Context, config_path: Optional[Path]) -> None:
    """perf-guard: performance regression monitor for ML inference projects."""
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config_path


# ── record ────────────────────────────────────────────────────────────────────

@main.command(name="record")
@click.argument("result_dir", type=click.Path(path_type=Path))
@click.option("--tag", "tags", multiple=True, help="Tag name(s) for this record")
@click.pass_context
def record_cmd(ctx: click.Context, result_dir: Path, tags: Tuple[str, ...]) -> None:
    """Extract metrics from RESULT_DIR and store in .perf_history/."""
    cfg = load_config(ctx.obj.get("config_path"))

    result_dir = result_dir.resolve()
    if not result_dir.exists():
        click.echo(f"Error: result directory does not exist: {result_dir}", err=True)
        sys.exit(2)

    snapshot = extract_all(cfg, result_dir)
    record(cfg.history_dir, snapshot, list(tags))
    print_record_result(snapshot)


# ── compare ───────────────────────────────────────────────────────────────────

@main.command(name="compare")
@click.option(
    "--base", "base_refs",
    multiple=True,
    help="Base version ref(s). Can be repeated for multi-baseline compare. "
         "Supports tags, dirnames, 'latest', 'yesterday', 'last_week', "
         "'last_month', '<N>d_ago', 'latest~<N>'. Default: 'baseline'.",
)
@click.option("--current", "current_ref", default=None,
              help="Current version ref (tag or dirname). Defaults to 'latest'.")
@click.option("--latest", "use_latest", is_flag=True, default=False,
              help="Auto-detect the newest result dir, record it, then compare.")
@click.pass_context
def compare_cmd(
    ctx: click.Context,
    base_refs: Tuple[str, ...],
    current_ref: Optional[str],
    use_latest: bool,
) -> None:
    """Compare current against one or more baselines."""
    cfg = load_config(ctx.obj.get("config_path"))

    if use_latest:
        newest = _latest_result_dir(cfg.results_dir)
        if newest is None:
            click.echo(f"Error: no result directories found in {cfg.results_dir}", err=True)
            sys.exit(1)
        snapshot = extract_all(cfg, newest)
        record(cfg.history_dir, snapshot, [])

    if not base_refs:
        base_refs = ("baseline",)
    if current_ref is None:
        current_ref = "latest"

    current_dirname = _resolve_or_exit(cfg.history_dir, current_ref)
    current_snap = _load_snapshot_or_exit(cfg.history_dir, current_dirname)

    results: List[Tuple[str, object]] = []
    any_regression = False
    for base_ref in base_refs:
        base_dirname = _resolve_or_exit(cfg.history_dir, base_ref)
        base_snap = _load_snapshot_or_exit(cfg.history_dir, base_dirname)
        result = compare(cfg, base_snap, current_snap)
        results.append((base_ref, result))
        if result.has_regression:
            any_regression = True

    print_compare_multi(results)

    if any_regression:
        sys.exit(1)


# ── list ──────────────────────────────────────────────────────────────────────

@main.command(name="list")
@click.pass_context
def list_cmd(ctx: click.Context) -> None:
    """List all recorded versions."""
    cfg = load_config(ctx.obj.get("config_path"))
    print_list(cfg.history_dir)


# ── report ────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("ref")
@click.pass_context
def report(ctx: click.Context, ref: str) -> None:
    """Show detailed metrics for a single version (tag or dirname)."""
    cfg = load_config(ctx.obj.get("config_path"))
    dirname = _resolve_or_exit(cfg.history_dir, ref)
    snap = _load_snapshot_or_exit(cfg.history_dir, dirname)

    index = load_index(cfg.history_dir)
    tag_map: dict = {}
    for tag, dn in index.get("tags", {}).items():
        tag_map.setdefault(dn, []).append(tag)

    print_report(snap, tag_map)


# ── trend ─────────────────────────────────────────────────────────────────────

@main.command(name="trend")
@click.option(
    "--ref", "refs",
    multiple=True,
    help="Restrict plot to these refs (tag or dirname). Repeatable. "
         "Default: plot every recorded snapshot.",
)
@click.option(
    "--metric", "metric_names",
    multiple=True,
    help="Restrict plot to these metrics. Repeatable. Default: all metrics.",
)
@click.option(
    "--output", "-o", "output_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Write HTML chart to this path. Default: .perf_history/trend.html",
)
@click.option("--ascii", "ascii_mode", is_flag=True, default=False,
              help="Print ASCII sparklines instead of writing HTML.")
@click.pass_context
def trend_cmd(
    ctx: click.Context,
    refs: Tuple[str, ...],
    metric_names: Tuple[str, ...],
    output_path: Optional[Path],
    ascii_mode: bool,
) -> None:
    """Plot metric trends across recorded versions."""
    cfg = load_config(ctx.obj.get("config_path"))

    series = select_series(cfg.history_dir, list(refs) if refs else None)
    if not series:
        click.echo("Error: no snapshots to plot. Run `perf-guard record` first.", err=True)
        sys.exit(1)

    names = pick_metric_names(series, list(metric_names) if metric_names else None)
    if not names:
        click.echo("Error: no matching metrics found.", err=True)
        sys.exit(1)

    if ascii_mode:
        print_trend_ascii(series, names)
        return

    out = output_path or (cfg.history_dir / "trend.html")
    out = out.resolve()
    render_html(series, names, out)
    click.echo(f"Trend chart written to {out}")
    click.echo(f"Open it in a browser: file://{out}")


# ── install-hook ──────────────────────────────────────────────────────────────

@main.command(name="install-hook")
@click.pass_context
def install_hook(ctx: click.Context) -> None:
    """Install a git post-commit hook that auto-compares after each commit."""
    cwd = Path.cwd()
    git_dir: Optional[Path] = None
    current = cwd
    while True:
        candidate = current / ".git"
        if candidate.is_dir():
            git_dir = candidate
            break
        parent = current.parent
        if parent == current:
            break
        current = parent

    if git_dir is None:
        click.echo("Error: not inside a git repository.", err=True)
        sys.exit(1)

    hook_path = git_dir / "hooks" / "post-commit"
    hook_path.parent.mkdir(parents=True, exist_ok=True)

    hook_block = (
        "\n# perf-guard post-commit hook\n"
        "perf-guard record results/$(ls -t results/ | head -1) 2>/dev/null\n"
        "perf-guard compare --base baseline --current latest 2>/dev/null || true\n"
    )

    if hook_path.exists():
        existing = hook_path.read_text()
        if "perf-guard" in existing:
            click.echo("perf-guard hook already installed.")
            return
        hook_path.write_text(existing + hook_block)
    else:
        hook_path.write_text("#!/bin/bash\n" + hook_block)

    current_mode = hook_path.stat().st_mode
    hook_path.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    click.echo(f"Hook installed: {hook_path}")
