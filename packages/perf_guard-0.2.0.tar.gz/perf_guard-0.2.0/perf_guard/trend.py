"""
trend.py — 趋势数据与 HTML 图表生成
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional, Sequence

from .storage import all_snapshots, resolve_ref


def select_series(
    history_dir: Path,
    refs: Optional[Sequence[str]] = None,
) -> List[dict]:
    """
    Return a list of snapshots (sorted by recorded_at ascending).
    If `refs` is given and non-empty, keep only snapshots whose dirname matches
    any of the resolved refs.
    """
    snapshots = all_snapshots(history_dir)
    if not refs:
        return snapshots

    wanted: set = set()
    for r in refs:
        dn = resolve_ref(history_dir, r)
        if dn:
            wanted.add(dn)

    return [s for s in snapshots if s["dirname"] in wanted]


def pick_metric_names(
    snapshots: Sequence[dict],
    wanted: Optional[Sequence[str]] = None,
) -> List[str]:
    """
    Union of metric names across snapshots, optionally filtered to `wanted`.
    Preserves insertion order of first appearance.
    """
    seen: dict = {}
    for s in snapshots:
        for name in s.get("metrics", {}).keys():
            seen.setdefault(name, True)
    all_names = list(seen.keys())
    if not wanted:
        return all_names
    wanted_set = set(wanted)
    return [n for n in all_names if n in wanted_set]


# ── HTML chart ────────────────────────────────────────────────────────────────

_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>perf-guard trend</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
  <style>
    body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif; margin: 24px; color: #222; }}
    h1 {{ font-size: 20px; margin: 0 0 8px 0; }}
    p.meta {{ color: #666; margin: 0 0 20px 0; font-size: 13px; }}
    .chart-wrap {{ max-width: 1000px; margin: 24px 0; }}
    .chart-wrap h2 {{ font-size: 15px; margin: 0 0 4px 0; }}
    canvas {{ background: #fafafa; border: 1px solid #eee; border-radius: 6px; }}
  </style>
</head>
<body>
  <h1>perf-guard trend</h1>
  <p class="meta">{subtitle}</p>
  <div id="charts"></div>
  <script>
    const DATA = {payload};
    const palette = [
      "#2563eb", "#dc2626", "#059669", "#d97706",
      "#7c3aed", "#0891b2", "#db2777", "#65a30d"
    ];
    const root = document.getElementById("charts");
    DATA.metrics.forEach((metric, idx) => {{
      const wrap = document.createElement("div");
      wrap.className = "chart-wrap";
      const h2 = document.createElement("h2");
      h2.textContent = metric.name;
      wrap.appendChild(h2);
      const canvas = document.createElement("canvas");
      canvas.height = 120;
      wrap.appendChild(canvas);
      root.appendChild(wrap);
      new Chart(canvas.getContext("2d"), {{
        type: "line",
        data: {{
          labels: DATA.labels,
          datasets: [{{
            label: metric.name,
            data: metric.values,
            borderColor: palette[idx % palette.length],
            backgroundColor: palette[idx % palette.length] + "22",
            spanGaps: true,
            tension: 0.2,
            pointRadius: 3,
          }}]
        }},
        options: {{
          responsive: true,
          plugins: {{ legend: {{ display: false }} }},
          scales: {{
            x: {{ ticks: {{ autoSkip: true, maxRotation: 0 }} }},
            y: {{ beginAtZero: false }}
          }}
        }}
      }});
    }});
  </script>
</body>
</html>
"""


def render_html(
    snapshots: Sequence[dict],
    metric_names: Sequence[str],
    output_path: Path,
) -> Path:
    """
    Write a self-contained HTML file with one line chart per metric.
    Chart.js is loaded from CDN (internet required when opening the file).
    """
    labels = [s["dirname"] for s in snapshots]
    metrics_payload = []
    for name in metric_names:
        values = []
        for s in snapshots:
            entry = s.get("metrics", {}).get(name)
            values.append(entry["value"] if entry and entry.get("value") is not None else None)
        metrics_payload.append({"name": name, "values": values})

    payload = {"labels": labels, "metrics": metrics_payload}

    subtitle_parts = [f"{len(snapshots)} snapshot(s)", f"{len(metric_names)} metric(s)"]
    if snapshots:
        subtitle_parts.append(f"{snapshots[0]['dirname']} → {snapshots[-1]['dirname']}")
    subtitle = " · ".join(subtitle_parts)

    html = _HTML_TEMPLATE.format(
        subtitle=subtitle,
        payload=json.dumps(payload),
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html)
    return output_path
