# E2E Smoke Test Family

This directory contains a suite of end-to-end (E2E) smoke tests for the EZGA evolutionary pipeline. 
The tests are designed to be fast, stable, and cover various workflow variants to prevent regressions in the complex HiSE (High-throughput Integrated Structure Evolution) manager.

## Test Family Overview

1.  **`test_nio_hise_pipeline_smoke.py`**: The primary smoke test. Runs a 2-stage Ni-O evolutionary run and verifies logs and plots.
2.  **`test_nio_hise_pipeline_variants.py`**: Covers specialized workflow features:
    *   `test_nio_hise_resume_pipeline`: Verifies the ability to resume from an existing output directory.
    *   `test_nio_hise_mutation_only_pipeline`: Pipeline stability when crossover is disabled.
    *   `test_nio_hise_pipeline_filters_duplicates`: Verification of structure hashing and duplicate removal.
    *   `test_nio_hise_pipeline_with_active_constraints`: Pipeline behavior under chemical composition constraints.
3.  **`test_nio_hise_stage_transitions.py`**: Tests scaling and plotting:
    *   `test_nio_hise_three_stage_transition_pipeline`: 3-stage supercell expansion (1x1x1 -> 2x1x1 -> 2x2x1).
    *   `test_nio_hise_pipeline_generates_stage_plots`: Verification that Plotter generates valid artifacts for every stage.

## Utilities

Shared logic is located in `helpers.py`, providing:
- Synthetic dataset generation (`write_tiny_nio_dataset`)
- Configuration boilerplate (`make_smoke_cfg`)
- Standard assertions for logs and plots.

## Running the E2E Suite

To run only the E2E family:
```bash
PYTHONPATH=src pytest tests/e2e/ -v
```

To run a specific variant:
```bash
PYTHONPATH=src pytest tests/e2e/test_nio_hise_pipeline_variants.py -v
```
