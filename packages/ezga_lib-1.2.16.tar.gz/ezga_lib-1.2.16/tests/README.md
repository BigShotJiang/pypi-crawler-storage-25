# 🧪 Testing Guide

This project uses **pytest** with a structured execution environment designed to:

* isolate test side-effects (file generation, logs, artifacts)
* provide reproducible results
* centralize all test outputs
* enforce coverage requirements

---

## 🧪 Test Classification & Inventory

The test suite is highly structured and organized into different levels to ensure both speed and robustness:

| Test Type | Directory Path | Description | Test Count | CLI Runner |
| :--- | :--- | :--- | :--- | :--- |
| **Unit Tests** | `tests/unit/` | Tests individual components (selectors, variation, evaluators, sync policies) in isolation with high granularity. | **1500+** | `pytest tests/unit` |
| **Integration Tests** | `tests/integration/` | Validates multi-component communications and full pipeline flows (e.g., core GA integration with SAGE DB). | **15+** | `pytest tests/integration` |
| **Regression Tests** | `tests/regression/` | Verifies reproducibility, seed determinism, and that historical bugs remain permanently fixed. | **5+** | `pytest tests/regression` |
| **End-to-End (E2E) Tests** | `tests/e2e/` | Simulates real user runs from YAML configuration files and parses Typer CLI command dispatchers. | **54** | `tools/run_e2e_suite.py` |
| **Performance Tests** | `tests/performance/` | Tracks critical path latency (e.g., selection on 1M individuals) and appends timings to JSONL history. | **200+** | `tools/run_performance_suite.py` |
| **Smoke Tests** | `tests/smoke/` | Dedicated, ultra-fast verification files ensuring imports, configs, selectors, CLI, and QuickGA work instantly in milliseconds. | **13** | `tools/run_smoke_suite.py` |
| **Property-Based Tests** | `tests/property/`, `tests/unit/property/` | Uses randomized mathematical fuzzing via `hypothesis` to test invariant algorithmic properties. | **34** | `tools/run_property_suite.py` |

---

## 📁 Project Structure (Testing-related)

```text
project_root/
├── run_tests.py              # Main test runner
├── .test_artifacts/          # Auto-generated (all test outputs go here)
│   ├── tmp/                  # Per-test temporary directories
│   ├── coverage_html/        # Coverage HTML report
│   └── .pytest_cache/        # Pytest cache
├── src/
├── tests/
│   ├── conftest.py           # Global test configuration
│   └── ...
```

---

## ▶️ Running Tests

### Recommended (standard)

```bash
python run_tests.py
```

This will:

* run the full test suite
* isolate file generation
* collect coverage
* store all outputs under `.test_artifacts/`

---

### Alternative (manual pytest)

```bash
PYTHONDONTWRITEBYTECODE=1 pytest -v \
  --basetemp=.test_artifacts/tmp \
  --cov=src/ezga \
  --cov-report=term-missing \
  --cov-report=html:.test_artifacts/coverage_html \
  -o "cache_dir=.test_artifacts/.pytest_cache"
```

---

## 🧹 Artifact Isolation Strategy

The test environment is designed to **prevent pollution of the project root**.

### Mechanism

#### 1. Session-level isolation

At pytest startup:

```python
pytest_sessionstart → chdir(.test_artifacts/session_cwd)
```

This captures:

* files created during import
* files created during test discovery

---

#### 2. Per-test isolation

Each test runs in its own temporary directory:

```python
tmp_path/
```

This captures:

* files created via relative paths
* logs, plots, outputs, etc.

---

### Result

All generated files are redirected into:

```text
.test_artifacts/
```

instead of cluttering:

```text
project_root/
```

---

## 📊 Coverage Report

After execution, coverage is available at:

```text
.test_artifacts/coverage_html/index.html
```

### Interpretation

* **Statements (`Stmts`)**: total lines of code
* **Miss**: lines not executed
* **Branch**: conditional branches
* **Cover %**: total coverage

### Requirement

```text
Minimum required coverage: 60%
```

Example:

```text
TOTAL coverage: 61.85% ✅
```

---

## ⏱️ Performance Checks

Fast performance tests live under:

```text
tests/performance/
```

They are marked with:

```text
@pytest.mark.performance
```

Run them without coverage overhead:

```bash
python tools/run_performance_suite.py
```

Record min/mean/max timings into a JSONL history:

```bash
python tools/run_performance_suite.py --record
```

By default, recorded samples are appended to:

```text
benchmark-results/performance-history.jsonl
```

Use a custom history path when comparing branches or machines:

```bash
python tools/run_performance_suite.py --history benchmark-results/my-branch.jsonl
```

The performance suite is intended to catch large regressions in critical paths,
not to replace detailed profiling. Keep thresholds generous and workloads small
enough for regular local execution.

---

## 🔁 Property-Based Checks

Property-based tests live under:

```text
tests/property/
tests/unit/property/
```

They are marked with:

```text
@pytest.mark.property
```

Run them without coverage overhead:

```bash
python tools/run_property_suite.py
```

These tests use `hypothesis` to generate many small randomized inputs and verify
stable invariants: bounded rates, algebraic simplification identities, duplicate
group consistency, motif translation invariance, selection normalization, and
geometry/count conservation. Keep examples small and deterministic enough for
regular local execution.

---

## ❌ Test Failures

Example failure:

```text
AssertionError: '(x0) / (1.000)' != '(x0 / 1.000)'
```

### How to read this

* Expected: `(x0 / 1.000)`
* Got: `(x0) / (1.000)`

This indicates a **formatting inconsistency in string representation**, likely in:

```python
Div.__str__()
```

---

### How to fix

Locate implementation:

```bash
grep -R "class Div" src
```

Adjust formatting logic accordingly, e.g.:

```python
return f"({left} / {right})"
```

---

## ⚠️ Warnings

Typical warnings are suppressed globally:

* `ConvergenceWarning` (sklearn)
* Numba missing
* plotting warnings
* ASE future warnings

Example remaining warning:

```text
RuntimeWarning: More than 20 figures have been opened
```

### Recommendation

Ensure figures are closed:

```python
plt.close(fig)
```

---

## 🚨 Known Limitations

The isolation system **does not intercept**:

### 1. Absolute paths

```python
open("/tmp/file.txt")
```

### 2. Explicit project-root writes

```python
Path(project_root) / "output.dat"
```

### 3. External library behavior

* `~/.cache`
* `/var/tmp`
* GPU / torch temp files

---

## 🔍 Debugging File Pollution

If files still appear in the root:

```bash
grep -R "feature_dim0.dat" src tests
grep -R "open(" src tests
grep -R "Path.cwd()" src tests
```

---

## 🧪 Running a Subset of Tests

```bash
pytest tests/simple -v
```

or:

```bash
pytest tests/simple/test_symbolic_regression.py::test_xyz -v
```

---

## ⚙️ CI Recommendations

* always use `run_tests.py`
* enforce coverage threshold
* clean `.test_artifacts/` between runs
* fail fast (`--maxfail=5` already enabled)

---

## 🧠 Best Practices for Writing Tests

### ✅ Prefer

```python
from pathlib import Path

data = Path(__file__).parent / "data" / "file.json"
```

### ❌ Avoid

```python
open("tests/data/file.json")  # breaks under cwd isolation
```

---

### ✅ Write outputs relative

```python
open("output.txt", "w")
```

This ensures they go to the temp directory.

---

### ❌ Avoid hardcoded paths

```python
open("/Users/.../output.txt")
```

---

## 🧹 Cleaning Artifacts Manually

```bash
rm -rf .test_artifacts .coverage
```

---

## 📌 Summary

| Feature         | Behavior                 |
| --------------- | ------------------------ |
| Isolation       | Per-test + session-level |
| Output location | `.test_artifacts/`       |
| Coverage        | HTML + terminal          |
| Runner          | `run_tests.py`           |
| Default backend | matplotlib `Agg`         |
| Warning noise   | suppressed               |

---

## 🧭 Final Recommendation

Always use:

```bash
python run_tests.py
```

This ensures:

* reproducibility
* clean workspace
* consistent coverage
* no file pollution
