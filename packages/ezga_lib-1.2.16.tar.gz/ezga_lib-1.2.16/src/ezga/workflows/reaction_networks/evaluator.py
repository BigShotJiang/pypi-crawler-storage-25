from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from ezga.simple.graphs.individual import GraphIndividual
from ezga.simple.graphs.thermo import ThermodynamicLayer

from .network import ReactionNetworkPhenotype

if TYPE_CHECKING:
    from ezga.simple.graphs.problem import GraphOptimizationProblem


class KineticFitEvaluator:
    """
    Evaluator for Reaction Networks that fits time-series data.
    Uses the stoichiometric matrix and rate constants to simulate dynamics.
    Supports multi-objective evaluation: [Fit, Complexity, Physicality]
    """

    def __init__(
        self,
        t_data: np.ndarray,
        y_data: np.ndarray,
        y0: np.ndarray,
        species_mask: np.ndarray | None = None,
    ):
        self.t_data = t_data
        self.y_data = y_data  # (n_samples, n_species)
        self.y0 = y0
        self.species_mask = species_mask if species_mask is not None else np.ones(len(y0), dtype=bool)

    def evaluate(self, ind: GraphIndividual, problem: GraphOptimizationProblem | None = None) -> np.ndarray:
        """
        Returns a vector of 3 objectives: [MAE, Complexity, ThermoDeviation]
        """
        # 1. Fit Objective (MAE)
        mae = self.compute_mae(ind)

        # 2. Complexity Objective (Weighted Graph Size)
        complexity = 0.0
        if problem is not None:
            complexity = problem.get_complexity(ind)
        else:
            # Basic fallback
            complexity = float(len(ind.phenotype.active_edge_indices)) + float(len(ind.phenotype.active_node_indices))

        # 3. Physicality Objective (Cycle Inconsistency)
        thermo_deviation = ThermodynamicLayer.compute_cycle_inconsistency(ind)

        return np.array([mae, complexity, thermo_deviation])

    def compute_mae(self, ind: GraphIndividual) -> float:
        """Computes Mean Absolute Error against experimental data."""
        # 1. Get ReactionNetwork View
        rn = ReactionNetworkPhenotype(ind.space, ind.genotype)
        S = rn.get_stoichiometric_matrix()
        k = rn.get_rate_constants()

        # Mask y0: force inactive species to zero
        y0 = self.y0.copy()
        if ind.genotype.node_active is not None:
            y0[~ind.genotype.node_active] = 0.0

        # 2. Simple ODE Simulation
        try:
            from scipy.integrate import odeint

            def drdt(y, t, S, k):
                fluxes = np.zeros(len(k))
                for j in range(len(k)):
                    reactant_idx = np.where(S[:, j] < 0)[0]
                    if len(reactant_idx) > 0:
                        # Mass-action kinetics: rate = k[j] * [reactant]
                        fluxes[j] = k[j] * y[reactant_idx[0]]
                    else:
                        fluxes[j] = k[j]

                dy = S @ fluxes

                # Force inactive nodes to have zero change?
                # (They should already have zero fluxes if edges were pruned, but we double-enforce)
                if ind.genotype.node_active is not None:
                    dy[~ind.genotype.node_active] = 0.0

                return dy

            # Solve
            y_sim = odeint(drdt, y0, self.t_data, args=(S, k))

            # 3. Compare on observable species
            diff = self.y_data - y_sim[:, self.species_mask]
            return float(np.mean(np.abs(diff)))

        except ImportError:
            return 1e6
        except Exception:
            return 1e6
