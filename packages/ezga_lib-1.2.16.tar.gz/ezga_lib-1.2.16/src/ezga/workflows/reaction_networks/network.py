from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from ezga.simple.graphs.individual import GraphPhenotype

if TYPE_CHECKING:
    pass


class ReactionNetworkPhenotype(GraphPhenotype):
    """
    Specialized view for Reaction Networks.
    Exposes stoichiometric matrix (S) and kinetic rate vectors (k).
    """

    def get_stoichiometric_matrix(self) -> np.ndarray:
        """
        Constructs the stoichiometric matrix S (n_species x n_reactions).
        Note: In this simple layout, active edges ARE the reactions.
        """
        n_species = self.space.n_states
        n_reactions = len(self.active_edges)

        S = np.zeros((n_species, n_reactions), dtype=float)

        for j, edge_idx in enumerate(self.active_edge_indices):
            e = self.space.candidate_edges[edge_idx]

            # Reactant (source) -> Product (target)
            u = self.space.state_index[e.source]
            v = self.space.state_index[e.target]

            # Simple 1:1 stoichiometry if not specified in features
            stoich_u = e.features.get("stoich_source", -1.0)
            stoich_v = e.features.get("stoich_target", 1.0)

            S[u, j] += stoich_u
            S[v, j] += stoich_v

        return S

    def get_rate_constants(self, key: str = "rate") -> np.ndarray:
        """Extracts the kinetic rate constants for all active reactions."""
        return self.genotype.edge_parameters.get(key, np.ones(self.space.n_edges))[self.active_edge_indices]
