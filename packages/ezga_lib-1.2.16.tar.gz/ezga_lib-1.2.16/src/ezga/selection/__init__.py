from __future__ import annotations
"""
selection
=========

Sub-package for filtering and ranking structures using multi-criteria approaches such
as Pareto-based selection, penalization for composition similarity, etc.
"""
