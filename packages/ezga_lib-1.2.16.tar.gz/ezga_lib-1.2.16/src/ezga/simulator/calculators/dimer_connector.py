"""
Dimer connector calculator for EZGA.

Purpose
-------
This module implements a graph-aware dimer connector calculator compatible
with the EZGA Simulator interface.

Given one input structure, the calculator attempts to generate one or more
transition fragments:

    initial minimum -> transition state -> final minimum

The output follows the EZGA Simulator calculator convention:

    (positions, symbols, cell, energy, metadata)

Core responsibilities
---------------------
1. Relax the input structure to an initial minimum.
2. Assign a graph-stable state key to the initial minimum.
3. Run several stochastic dimer searches.
4. For each TS candidate, quench both sides along the dimer mode.
5. Identify a product/final basin.
6. Assign graph-stable state keys to the final minimum and TS.
7. Return graph-ready metadata with raw energies and barriers.

What this calculator does NOT do
--------------------------------
It does not compute:
    - grand potentials
    - pH corrections
    - electrochemical potential corrections
    - TST rates
    - Boltzmann weights
    - kinetic observables

Those should be added later in a separate postprocessing stage.

Default hashing
---------------
If no hash function or hash manager is provided, the calculator tries to use:

    Structure_Hash_Map(method="tsfr")

This should call your rotationally invariant structure-factor hash,
`_structure_factor_hash_factory_rotinv`, with its default parameters.

Expected hash interface
-----------------------
The calculator accepts either:

    hash_function(container) -> str

or a hash manager exposing:

    hash_manager.get_hash(container, force_rehash=True) -> str

or optionally:

    hash_manager.add_structure_voted(container, force_rehash=True) -> dict

The internal ASE adapter exposes the fields expected by your
Structure_Hash_Map implementation.
"""

from __future__ import annotations

import copy
import datetime
import hashlib
import json
import logging
import os
import platform
import sys
from collections.abc import Callable, Mapping, MutableMapping, Sequence
from dataclasses import asdict, dataclass
from typing import Any, Literal, Protocol, TypeAlias, runtime_checkable

import numpy as np
from ase import Atoms
from ase.constraints import FixAtoms, FixCartesian
from ase.io import write
from ase.io.trajectory import Trajectory
from ase.mep import DimerControl, MinModeAtoms, MinModeTranslate
from ase.optimize import BFGS, FIRE


# --- MACE support (optional) ---
assert_license_ok: Any = None
download_if_needed: Any = None
resolve_model_spec: Any = None

try:
    from ezga.simulator.mace_utils import (
        assert_license_ok,
        download_if_needed,
        resolve_model_spec,
    )
except Exception:  # pragma: no cover
    pass


logger = logging.getLogger(__name__)


# =============================================================================
# Type aliases
# =============================================================================

CalcResult: TypeAlias = tuple[
    np.ndarray,            # positions, shape (N, 3)
    np.ndarray,            # symbols, shape (N,)
    np.ndarray | None,     # cell, shape (3, 3), or None
    float,                 # potential energy in eV
    dict[str, Any],        # metadata
]

CalculatorReturn: TypeAlias = list[CalcResult]

OptimizerName: TypeAlias = Literal["FIRE", "BFGS"]
ConstraintLogic: TypeAlias = Literal["all", "any"]
ConstraintAction: TypeAlias = Literal["freeze", "move_only"]
DimerMaskMode: TypeAlias = Literal["displaced", "all_free"]
ReturnPolicy: TypeAlias = Literal["best_triplet", "all_triplets", "initial_if_failed"]
RankBy: TypeAlias = Literal[
    "barrier_forward_eV",
    "ts_energy_eV",
    "final_energy_eV",
    "min_barrier_from_initial_eV",
    "min_barrier_any_direction_eV",
    "delta_E_abs_eV",
]
TSValidationLevel: TypeAlias = Literal[
    "none",
    "energy_only",
    "quench_only",
    "curvature_check",
    "strict",
]
SeedPolicy: TypeAlias = Literal[
    "stochastic",
    "fixed",
    "parent_hash",
    "parent_hash_and_counter",
]
FragmentEscapeReferenceMode: TypeAlias = Literal[
    "center_of_mass",
    "median",
    "fixed_plane",
]

HashFunction: TypeAlias = Callable[[Any], str]
CalculatorFactory: TypeAlias = Callable[[], object] | object
ConstraintPredicate: TypeAlias = Callable[[int, Any], bool]


# =============================================================================
# Protocols
# =============================================================================

@runtime_checkable
class HashManagerProtocol(Protocol):
    """Protocol for EZGA-style hash managers."""

    def get_hash(self, container: Any, force_rehash: bool = True) -> str:
        """Return a structure hash for a container."""

    def add_structure_voted(
        self,
        container: Any,
        *,
        force_rehash: bool = True,
        vote_frac: float | None = None,
        min_votes: int | None = None,
    ) -> dict[str, Any]:
        """Optionally add/check a structure using ensemble voting."""


# =============================================================================
# Dataclasses
# =============================================================================

@dataclass(slots=True)
class RelaxationInfo:
    """Metadata describing a geometry relaxation."""

    optimizer: str
    target_fmax: float
    max_steps: int
    converged: bool
    exception: str | None
    final_max_force_eV_A: float
    final_energy_eV: float

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dictionary."""
        return asdict(self)


@dataclass(slots=True)
class HashIdentity:
    """
    Graph-stable identity assigned to a minimum or TS geometry.

    For minima:
        state_key = SHA256(composition_key + raw_structure_hash)

    For transition states:
        state_key = SHA256(endpoint_key_a + endpoint_key_b + raw_ts_hash)
    """

    state_key: str
    state_id: str
    hash_raw: str
    hash_method: str
    composition_key: str
    hash_report: dict[str, Any] | None = None

    # Only used for TS identities.
    ts_key: str | None = None
    endpoint_key_a: str | None = None
    endpoint_key_b: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dictionary."""
        return asdict(self)


@dataclass(slots=True)
class NetworkNodeRecord:
    """Compact record for a minimum or TS node in the kinetic network."""
    schema_version: str
    node_key: str
    node_id: str
    node_role: Literal["minimum", "transition_state"]
    composition_key: str
    hash_raw: str
    hash_method: str
    energy_eV: float
    run_id: str
    attempt_id: str | None
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class DirectedEdgeRecord:
    """Compact record for a directed transition between two minima."""
    schema_version: str
    edge_key: str
    source_key: str
    target_key: str
    ts_key: str
    barrier_eV: float
    delta_E_eV: float
    source_energy_eV: float
    target_energy_eV: float
    ts_energy_eV: float
    run_id: str
    attempt_id: str
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class DimerAttemptRecord:
    """Diagnostic record for a single dimer search attempt."""
    schema_version: str
    run_id: str
    attempt_id: str
    attempt_index: int
    status: str
    reason: str | None
    displaced_atoms: list[int]
    dimer_converged: bool | None
    ts_energy_eV: float | None
    endpoint_plus_key: str | None
    endpoint_minus_key: str | None
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# =============================================================================
# ASE -> Structure_Hash_Map adapter
# =============================================================================

class _ASEAtomPositionManagerAdapter:
    """
    Minimal AtomPositionManager adapter for Structure_Hash_Map.

    The provided Structure_Hash_Map code expects a container with:

        container.AtomPositionManager.atomPositions
        container.AtomPositionManager.latticeVectors
        container.AtomPositionManager.get_atomic_numbers()
        container.AtomPositionManager.atomCountDict
        container.AtomPositionManager.E
        container.AtomPositionManager.metadata
        container.AtomPositionManager.pbc
        container.AtomPositionManager.atomPositions_fractional
        container.AtomPositionManager.wrap()

    ASE stores lattice vectors as rows. Your hash code expects
    lattice vectors as columns in `apm.latticeVectors`, so this adapter returns:

        atoms.cell.array.T

    for periodic systems.
    """

    def __init__(self, atoms: Atoms, energy_eV: float | None = None) -> None:
        self._atoms = atoms
        self.atomPositions = np.asarray(atoms.get_positions(), dtype=float)

        if atoms.get_pbc().any():
            self.latticeVectors = np.asarray(atoms.get_cell().array, dtype=float).T
            self.pbc = tuple(bool(x) for x in atoms.get_pbc())
        else:
            self.latticeVectors = np.eye(3, dtype=float)
            self.pbc = (False, False, False)

        self.metadata: dict[str, Any] = {}
        self.E = float(energy_eV) if energy_eV is not None else self._safe_energy()
        self.atomCountDict = self._atom_count_dict()
        self.atomPositions_fractional = self._scaled_positions()
        self.kdtree = None

    def _safe_energy(self) -> float:
        try:
            return float(self._atoms.get_potential_energy())
        except Exception:
            return 0.0

    def _atom_count_dict(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for sym in self._atoms.get_chemical_symbols():
            counts[sym] = counts.get(sym, 0) + 1
        return counts

    def _scaled_positions(self) -> np.ndarray:
        if self._atoms.get_pbc().any():
            return np.asarray(self._atoms.get_scaled_positions(wrap=True), dtype=float) % 1.0
        return np.asarray(self._atoms.get_positions(), dtype=float)

    def get_atomic_numbers(self) -> np.ndarray:
        """Return atomic numbers."""
        return np.asarray(self._atoms.get_atomic_numbers(), dtype=int)

    def wrap(self) -> None:
        """Wrap periodic atoms and update cached positions."""
        if self._atoms.get_pbc().any():
            self._atoms.wrap()
            self.atomPositions = np.asarray(self._atoms.get_positions(), dtype=float)
            self.atomPositions_fractional = (
                np.asarray(self._atoms.get_scaled_positions(wrap=True), dtype=float) % 1.0
            )

    def build_kdtree(self, verbose: bool = False) -> None:
        """Build a simple Cartesian cKDTree for hash methods that need it."""
        from scipy.spatial import cKDTree

        self.kdtree = cKDTree(self.atomPositions)


class _ASEStructureContainerAdapter:
    """Container adapter exposing AtomPositionManager for Structure_Hash_Map."""

    def __init__(self, atoms: Atoms, energy_eV: float | None = None) -> None:
        self.AtomPositionManager = _ASEAtomPositionManagerAdapter(
            atoms=atoms,
            energy_eV=energy_eV,
        )


# =============================================================================
# Hashing helpers
# =============================================================================

def _load_default_hash_manager() -> Any:
    """
    Load the default EZGA structure hash manager.

    Default expected behavior:

        Structure_Hash_Map(method="tsfr")

    Update the candidate import paths below if your package layout differs.
    """

    candidate_imports = (
        "ezga.utils.structure_hash_map",
        "ezga.utils.Structure_Hash_Map",
        "ezga.core.Structure_Hash_Map",
        "ezga.core.structure_hash_map",
        "ezga.hash.Structure_Hash_Map",
    )

    last_error: Exception | None = None

    for module_name in candidate_imports:
        try:
            module = __import__(module_name, fromlist=["Structure_Hash_Map"])
            cls = getattr(module, "Structure_Hash_Map")
            return cls(method="tsfr")
        except Exception as exc:  # pragma: no cover
            last_error = exc

    raise ImportError(
        "Could not import Structure_Hash_Map. "
        "Pass `hash_function` or `hash_manager` explicitly, or update "
        "`_load_default_hash_manager()` with the correct module path."
    ) from last_error


def _composition_key_from_atoms(atoms: Atoms) -> str:
    """
    Return a deterministic absolute composition key.

    Example
    -------
    Fe4-H90-K6-Ni48-O120-V2

    Notes
    -----
    This does not reduce formulas by the greatest common divisor. For graph
    nodes, absolute composition is usually preferable.
    """

    counts: dict[str, int] = {}
    for sym in atoms.get_chemical_symbols():
        counts[sym] = counts.get(sym, 0) + 1

    if not counts:
        return "EMPTY"

    return "-".join(f"{el}{counts[el]}" for el in sorted(counts))


def _short_id_from_key(prefix: str, key: str, n: int = 20) -> str:
    """Create a short human-readable ID from a long key."""
    digest = hashlib.sha256(str(key).encode()).hexdigest()
    return f"{prefix}_{digest[:n]}"


def _compute_hash_identity(
    atoms: Atoms,
    *,
    role_prefix: str,
    hash_function: HashFunction | None,
    hash_manager: Any | None,
    register_hash: bool,
) -> HashIdentity:
    """
    Compute the graph-stable identity for a minimum-like state.

    Priority
    --------
    1. Use `hash_function(container)` if provided.
    2. Use `hash_manager.add_structure_voted(...)` if available and requested.
    3. Use `hash_manager.get_hash(...)` if available.
    4. Use callable `hash_manager(container)`.
    5. If no hash manager/function was provided, use the default:
       `Structure_Hash_Map(method="tsfr")`.

    Graph key
    ---------
    The graph state key is:

        SHA256(composition_key + raw_structure_hash)

    This keeps graph keys stable and independent of raw hash formatting.
    """

    try:
        energy_eV = float(atoms.get_potential_energy())
    except Exception:
        energy_eV = 0.0

    container = _ASEStructureContainerAdapter(atoms=atoms, energy_eV=energy_eV)
    hash_report: dict[str, Any] | None = None

    if hash_function is not None:
        raw_hash = str(hash_function(container))
        method = "user_hash_function"

    else:
        manager = hash_manager if hash_manager is not None else _load_default_hash_manager()

        if register_hash and hasattr(manager, "add_structure_voted"):
            hash_report = manager.add_structure_voted(container, force_rehash=True)
            raw_hash = str(hash_report["hash"])
            method = "hash_manager.add_structure_voted"

        elif hasattr(manager, "get_hash"):
            raw_hash = str(manager.get_hash(container, force_rehash=True))
            method = "hash_manager.get_hash"

        elif callable(manager):
            raw_hash = str(manager(container))
            method = "callable_hash_manager"

        else:
            raise TypeError(
                "hash_manager must expose get_hash(...), add_structure_voted(...), "
                "or be directly callable."
            )

    composition_key = _composition_key_from_atoms(atoms)
    payload = f"{composition_key}|{raw_hash}".encode()
    state_key = hashlib.sha256(payload).hexdigest()

    return HashIdentity(
        state_key=state_key,
        state_id=_short_id_from_key(role_prefix, state_key),
        hash_raw=raw_hash,
        hash_method=method,
        hash_report=hash_report,
        composition_key=composition_key,
    )


def _compute_ts_identity(
    ts_atoms: Atoms,
    *,
    initial_state_key: str,
    final_state_key: str,
    hash_function: HashFunction | None,
    hash_manager: Any | None,
    register_hash: bool,
) -> HashIdentity:
    """
    Compute a graph-stable transition-state identity.

    The TS identity depends on:
        - the unordered pair of endpoint minimum keys;
        - the raw hash of the TS geometry.

    Sorting endpoint keys makes the TS key direction-independent.
    """

    ts_geom = _compute_hash_identity(
        ts_atoms,
        role_prefix="tsgeom",
        hash_function=hash_function,
        hash_manager=hash_manager,
        register_hash=register_hash,
    )

    endpoint_a, endpoint_b = sorted([initial_state_key, final_state_key])
    payload = f"{endpoint_a}|{endpoint_b}|{ts_geom.hash_raw}".encode()
    ts_key = hashlib.sha256(payload).hexdigest()

    return HashIdentity(
        state_key=ts_key,
        state_id=_short_id_from_key("ts", ts_key),
        hash_raw=ts_geom.hash_raw,
        hash_method=ts_geom.hash_method,
        hash_report=ts_geom.hash_report,
        composition_key=ts_geom.composition_key,
        ts_key=ts_key,
        endpoint_key_a=endpoint_a,
        endpoint_key_b=endpoint_b,
    )


def _attach_energy_trajectory(
    optimizer: Any,
    atoms: Atoms,
    trajectory_path: str,
    interval: int = 1,
) -> Any:
    """
    Attach an ASE trajectory writer that stores positions, energy, and forces.

    This is safer for dimer runs because MinModeTranslate optimizes a
    MinModeAtoms wrapper, while we want to write the underlying ASE Atoms.
    """

    traj = Trajectory(trajectory_path, "w")

    def write_frame() -> None:
        try:
            # Force calculation so energy/forces are present in the frame.
            energy = float(atoms.get_potential_energy())
            forces = np.asarray(atoms.get_forces(), dtype=float)

            frame = atoms.copy()
            frame.calc = atoms.calc

            # Store also as info/arrays for robust reading later.
            frame.info["energy_eV"] = energy
            
            if "forces" in frame.arrays:
                frame.arrays["forces"][:] = forces
            else:
                frame.arrays["forces"] = forces

            traj.write(frame)

        except Exception as exc:
            logger.warning("Could not write dimer trajectory frame: %s", exc)

    optimizer.attach(write_frame, interval=interval)
    return traj


def _attach_energy_extxyz(
    optimizer: Any,
    atoms: Atoms,
    xyz_path: str,
    interval: int = 1,
) -> Any:
    """
    Attach an extxyz writer storing energy and forces explicitly.
    """

    # Reset file at the beginning.
    try:
        with open(xyz_path, "w"):
            pass
    except Exception:
        pass

    def write_frame() -> None:
        try:
            energy = float(atoms.get_potential_energy())
            forces = np.asarray(atoms.get_forces(), dtype=float)

            frame = atoms.copy()
            # Clear calculator to avoid collision with info/arrays in extxyz writer.
            frame.calc = None
            
            frame.info["energy_eV"] = energy
            # Standard extxyz energy key
            frame.info["energy"] = energy

            if "forces" in frame.arrays:
                frame.arrays["forces"][:] = forces
            else:
                frame.arrays["forces"] = forces

            write(xyz_path, frame, format="extxyz", append=True)

        except Exception as exc:
            logger.warning("Could not write dimer extxyz frame: %s", exc)

    optimizer.attach(write_frame, interval=interval)
    return None


# =============================================================================
# Metadata helpers
# =============================================================================

def _sanitize_metadata(value: Any) -> Any:
    """Recursively convert NumPy types and NaNs to JSON-friendly types."""
    if isinstance(value, Mapping):
        return {str(k): _sanitize_metadata(v) for k, v in value.items()}

    if isinstance(value, (list, tuple, set)):
        return [_sanitize_metadata(v) for v in value]

    if isinstance(value, np.ndarray):
        return _sanitize_metadata(value.tolist())

    if isinstance(value, (np.floating, float)):
        val = float(value)
        return val if np.isfinite(val) else None

    if isinstance(value, (np.integer, int)):
        return int(value)

    if isinstance(value, (np.bool_, bool)):
        return bool(value)

    return value


def _package_result(atoms: Atoms, metadata: Mapping[str, Any]) -> CalcResult:
    """Convert an ASE Atoms object into the EZGA calculator return format."""

    try:
        energy = float(atoms.get_potential_energy())
    except Exception:
        energy = float("nan")

    pbc = bool(atoms.get_pbc().any())
    cell = np.array(atoms.get_cell()) if pbc and atoms.get_cell().volume > 1e-12 else None

    return (
        np.asarray(atoms.get_positions(), dtype=float),
        np.asarray(atoms.get_chemical_symbols(), dtype=object),
        cell,
        energy,
        _sanitize_metadata(copy.deepcopy(dict(metadata))),
    )


# =============================================================================
# ASE construction and numerical helpers
# =============================================================================

def _clone_calculator(calculator_factory: CalculatorFactory) -> object:
    """Create a fresh ASE calculator instance."""

    if callable(calculator_factory):
        return calculator_factory()
    return copy.deepcopy(calculator_factory)


def _build_atoms(
    symbols: Sequence[str],
    positions: np.ndarray,
    cell: np.ndarray | None,
    calculator_factory: CalculatorFactory,
) -> Atoms:
    """Build an ASE Atoms object and attach a fresh calculator."""

    if cell is not None:
        cell_arr = np.asarray(cell, dtype=float)
        valid_cell = (
            cell_arr.shape == (3, 3)
            and np.isfinite(cell_arr).all()
            and abs(np.linalg.det(cell_arr)) > 1e-9
        )
    else:
        cell_arr = None
        valid_cell = False

    atoms = Atoms(
        symbols=list(symbols),
        positions=np.asarray(positions, dtype=float),
        cell=cell_arr if valid_cell else None,
        pbc=bool(valid_cell),
    )

    atoms.calc = _clone_calculator(calculator_factory)
    return atoms


def _set_fresh_calculator(atoms: Atoms, calculator_factory: CalculatorFactory) -> None:
    """Attach a fresh calculator to an existing ASE Atoms object."""

    atoms.calc = _clone_calculator(calculator_factory)


def _max_force(atoms: Atoms) -> float:
    """Return max force norm in eV/A, or NaN if unavailable."""

    try:
        forces = atoms.get_forces()
        return float(np.max(np.linalg.norm(forces, axis=1)))
    except Exception:
        return float("nan")


def _rmsd_same_order(a: Atoms, b: Atoms) -> float:
    """
    Same-order RMSD.

    This is only a local basin heuristic. Global deduplication should be handled
    by the hash manager or graph database.
    """

    if len(a) != len(b):
        return float("inf")

    ra = a.get_positions()
    rb = b.get_positions()
    return float(np.sqrt(np.mean(np.sum((ra - rb) ** 2, axis=1))))


def _normalise_mode(mode: np.ndarray, n_atoms: int) -> np.ndarray:
    """Normalize a dimer mode of shape (N, 3)."""

    mode = np.asarray(mode, dtype=float)

    if mode.shape != (n_atoms, 3):
        mode = np.reshape(mode, (n_atoms, 3))

    norm = float(np.linalg.norm(mode))

    if norm < 1.0e-14:
        raise ValueError("Cannot normalize a near-zero dimer mode.")

    return mode / norm


def _extract_dimer_mode(
    d_atoms: MinModeAtoms,
    *,
    fallback_mode: np.ndarray,
    n_atoms: int,
) -> np.ndarray:
    """
    Extract the final dimer mode.

    ASE internals may vary between versions. This function attempts several
    method/attribute names and falls back to the initial random mode if needed.
    """

    candidate: Any | None = None

    for name in ("get_eigenmode", "get_mode", "get_curvature_mode", "get_minmode"):
        if hasattr(d_atoms, name):
            try:
                candidate = getattr(d_atoms, name)()
                break
            except Exception:
                candidate = None

    if candidate is None:
        for name in ("eigenmode", "mode", "curvature_mode"):
            if hasattr(d_atoms, name):
                try:
                    candidate = getattr(d_atoms, name)
                    break
                except Exception:
                    candidate = None

    if candidate is None:
        candidate = fallback_mode

    try:
        return _normalise_mode(candidate, n_atoms=n_atoms)
    except Exception:
        return _normalise_mode(fallback_mode, n_atoms=n_atoms)


# =============================================================================
# Constraint bridge
# =============================================================================

class _ConstraintAPMAdapter:
    """Minimal adapter for EZGA-style atom-selection predicates."""

    def __init__(
        self,
        symbols: Sequence[str],
        positions: np.ndarray,
        cell: np.ndarray | None,
        atomic_constraints: np.ndarray | None = None,
    ) -> None:
        self.atomPositions = np.asarray(positions, dtype=float)
        self.atomLabelsList = np.asarray(symbols, dtype=object)
        self.latticeVectors = np.asarray(cell, dtype=float) if cell is not None else np.eye(3)
        self.atomicConstraints = (
            np.asarray(atomic_constraints, dtype=bool)
            if atomic_constraints is not None
            else None
        )
        self.atomCount = len(self.atomPositions)


class _ConstraintStructAdapter:
    """Container exposing AtomPositionManager to constraint predicates."""

    def __init__(
        self,
        symbols: Sequence[str],
        positions: np.ndarray,
        cell: np.ndarray | None,
        atomic_constraints: np.ndarray | None = None,
    ) -> None:
        self.AtomPositionManager = _ConstraintAPMAdapter(
            symbols=symbols,
            positions=positions,
            cell=cell,
            atomic_constraints=atomic_constraints,
        )


def _to_pred_list(
    preds: Sequence[ConstraintPredicate] | ConstraintPredicate | None,
) -> list[ConstraintPredicate]:
    """Normalize a callable or sequence of callables into a list."""

    if preds is None:
        return []

    if callable(preds):
        return [preds]

    try:
        return list(preds)
    except TypeError:
        return [preds]  # type: ignore[list-item]


def _evaluate_constraint(
    idx: int,
    structure: _ConstraintStructAdapter,
    predicates: Sequence[ConstraintPredicate],
    logic: ConstraintLogic = "all",
) -> bool:
    """Evaluate selection predicates for one atom."""

    if not predicates:
        return False

    if logic == "all":
        return all(pred(idx, structure) for pred in predicates)

    if logic == "any":
        return any(pred(idx, structure) for pred in predicates)

    raise ValueError("constraint logic must be 'all' or 'any'.")


def _select_indices(
    *,
    symbols: Sequence[str],
    positions: np.ndarray,
    cell: np.ndarray | None,
    fixed: np.ndarray | None,
    predicates: Sequence[ConstraintPredicate],
    logic: ConstraintLogic,
) -> np.ndarray:
    """Return atom indices selected by EZGA-style predicates."""

    adapter = _ConstraintStructAdapter(
        symbols=symbols,
        positions=positions,
        cell=cell,
        atomic_constraints=fixed,
    )

    return np.asarray(
        [
            i
            for i in range(len(symbols))
            if _evaluate_constraint(i, adapter, predicates, logic)
        ],
        dtype=int,
    )


def _normalize_components(
    components: Sequence[int | str] | None,
) -> Sequence[int] | None:
    """Normalize x/y/z or 0/1/2 component labels."""

    if components is None:
        return None

    comp_map: dict[int | str, int] = {"x": 0, "y": 1, "z": 2, 0: 0, 1: 1, 2: 2}
    out: list[int] = []

    for component in components:
        if component not in comp_map:
            raise ValueError(f"Invalid frozen component: {component!r}")
        out.append(int(comp_map[component]))

    return out


def _build_ase_constraints(
    atoms: Atoms,
    *,
    selected: np.ndarray,
    action: ConstraintAction,
    freeze_components: Sequence[int] | None,
):
    """
    Build ASE constraints from selected indices.

    action="freeze"
        Freeze selected atoms/components.

    action="move_only"
        Freeze everything except selected atoms/components.
    """

    n_atoms = len(atoms)
    selected = np.unique(selected) if selected.size > 0 else np.array([], dtype=int)

    if action == "freeze":
        target = selected
    elif action == "move_only":
        mask = np.ones(n_atoms, dtype=bool)
        mask[selected] = False
        target = np.where(mask)[0]
    else:
        raise ValueError("constraint_action must be 'freeze' or 'move_only'.")

    if len(target) == 0:
        return None

    if freeze_components is None:
        return FixAtoms(indices=list(target))

    mask_3 = [False, False, False]
    for component in freeze_components:
        mask_3[int(component)] = True

    return FixCartesian(a=list(target), mask=mask_3)


def _apply_constraints(
    *,
    atoms: Atoms,
    symbols: Sequence[str],
    positions: np.ndarray,
    cell: np.ndarray | None,
    fixed: np.ndarray | None,
    factory_constraints: Sequence[ConstraintPredicate],
    run_constraints: Sequence[ConstraintPredicate] | ConstraintPredicate | None,
    constraint_logic: ConstraintLogic,
    constraint_action: ConstraintAction,
    freeze_components_norm: Sequence[int] | None,
) -> tuple[np.ndarray, Any | None]:
    """Apply ASE constraints and return selected indices plus constraint object."""

    predicates = list(factory_constraints) + _to_pred_list(run_constraints)
    selected = np.array([], dtype=int)

    if predicates:
        selected = _select_indices(
            symbols=symbols,
            positions=positions,
            cell=cell,
            fixed=fixed,
            predicates=predicates,
            logic=constraint_logic,
        )

    elif fixed is not None and np.any(fixed):
        selected = np.where(np.asarray(fixed).flatten())[0]

    ase_constraint = _build_ase_constraints(
        atoms=atoms,
        selected=selected,
        action=constraint_action,
        freeze_components=freeze_components_norm,
    )

    if ase_constraint is not None:
        atoms.set_constraint(ase_constraint)

    return selected, ase_constraint


def _get_free_indices(
    *,
    n_atoms: int,
    selected: np.ndarray,
    constraint_action: ConstraintAction,
    has_constraints: bool,
) -> list[int]:
    """Return indices that are free for dimer displacement."""

    if not has_constraints:
        return list(range(n_atoms))

    selected_set = set(int(i) for i in selected)

    if constraint_action == "freeze":
        return [i for i in range(n_atoms) if i not in selected_set]

    if constraint_action == "move_only":
        return [int(i) for i in selected]

    raise ValueError("constraint_action must be 'freeze' or 'move_only'.")


# =============================================================================
# Randomness
# =============================================================================

def _seed_from_parts(*parts: Any) -> int:
    """Generate a deterministic 32-bit integer seed from multiple parts."""
    h = _stable_key(*parts)
    return int(h[:8], 16) & 0xFFFFFFFF


def _make_rng(
    *,
    seed: int | None,
    parent_hash: str | None,
    shared_state: MutableMapping[str, Any] | None,
    seed_policy: SeedPolicy,
) -> tuple[np.random.Generator, dict[str, Any]]:
    """
    Create an RNG and record seed metadata.

    seed_policy="stochastic"
        Uses OS entropy. Not reproducible.

    seed_policy="fixed"
        Same global seed gives same result.

    seed_policy="parent_hash"
        Same parent hash gives same result.

    seed_policy="parent_hash_and_counter"
        Same parent hash can produce different results on repeated calls while
        remaining reproducible for a fixed run order.
    """

    if seed_policy == "stochastic":
        rng = np.random.default_rng()
        return rng, {
            "seed_policy": seed_policy,
            "global_seed": seed,
            "local_seed": None,
        }

    if seed_policy == "fixed":
        rng = np.random.default_rng(seed)
        return rng, {
            "seed_policy": seed_policy,
            "global_seed": seed,
            "local_seed": seed,
        }

    if seed_policy == "parent_hash":
        payload = f"{seed}_{parent_hash}".encode()
        digest = hashlib.sha256(payload).hexdigest()[:16]
        local_seed = int(digest, 16) % (2**32)
        rng = np.random.default_rng(local_seed)

        return rng, {
            "seed_policy": seed_policy,
            "global_seed": seed,
            "local_seed": local_seed,
        }

    if seed_policy == "parent_hash_and_counter":
        if shared_state is not None:
            counter = int(shared_state.get("dimer_connector_call_counter", 0))
            shared_state["dimer_connector_call_counter"] = counter + 1
        else:
            counter = 0

        payload = f"{seed}_{parent_hash}_{counter}".encode()
        digest = hashlib.sha256(payload).hexdigest()[:16]
        local_seed = int(digest, 16) % (2**32)
        rng = np.random.default_rng(local_seed)

        return rng, {
            "seed_policy": seed_policy,
            "global_seed": seed,
            "local_seed": local_seed,
            "counter": counter,
        }

    raise ValueError(f"Unknown seed_policy: {seed_policy}")


def _stable_key(*parts: Any) -> str:
    """Generate a reproducible SHA256 key from multiple components."""
    payload = "|".join(str(p) for p in parts)
    return hashlib.sha256(payload.encode()).hexdigest()


def _get_provenance(calculator_factory: Any, device: str, dtype: str) -> dict[str, Any]:
    """Gather software and hardware provenance for reproducibility."""
    import ase

    calc_name = "unknown"
    if hasattr(calculator_factory, "__name__"):
        calc_name = calculator_factory.__name__
    elif hasattr(calculator_factory, "__class__"):
        calc_name = calculator_factory.__class__.__name__

    return {
        "code_name": "dimer_connector_hash_calculator",
        "schema_version": "ezga_dimer_connector.v1",
        "timestamp": datetime.datetime.now().isoformat(),
        "ase_version": ase.__version__,
        "numpy_version": np.__version__,
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "hostname": platform.node(),
        "pid": os.getpid(),
        "calculator_factory": calc_name,
        "device": device,
        "default_dtype": dtype,
    }


def _write_manifest_record(path: str | None, record: dict[str, Any]) -> None:
    """Append a single record to a JSONL manifest file."""
    if not path:
        return
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(_sanitize_metadata(record)) + "\n")
    except Exception as exc:
        logger.warning("Could not write manifest record to %s: %s", path, exc)


# =============================================================================
# Fragment escape helpers
# =============================================================================

def _detect_escaped_fragments(
    atoms: Atoms,
    *,
    escape_species: Sequence[str],
    escape_axis: int,
    escape_distance_A: float,
    reference_mode: FragmentEscapeReferenceMode,
    fixed_reference_value: float | None,
) -> list[int]:
    """
    Detect atoms far from the active region.

    This is a simple geometric detector. It is intentionally conservative and
    does not delete atoms by default.
    """

    symbols = atoms.get_chemical_symbols()
    positions = atoms.get_positions()

    axis = int(escape_axis)
    coord = positions[:, axis]

    if reference_mode == "center_of_mass":
        ref = float(atoms.get_center_of_mass()[axis])

    elif reference_mode == "median":
        ref = float(np.median(coord))

    elif reference_mode == "fixed_plane":
        if fixed_reference_value is None:
            raise ValueError(
                "fixed_reference_value is required for fixed_plane fragment escape reference."
            )
        ref = float(fixed_reference_value)

    else:
        raise ValueError("Invalid fragment escape reference mode.")

    desorbed: list[int] = []

    for i, symbol in enumerate(symbols):
        if symbol not in escape_species:
            continue

        if abs(float(coord[i]) - ref) >= float(escape_distance_A):
            desorbed.append(i)

    return desorbed


# =============================================================================
# Relaxation helpers
# =============================================================================

def _calculate_curvature(
    atoms: Atoms,
    mode: np.ndarray,
    eps: float = 0.005,
) -> float:
    """
    Calculate finite-difference curvature along a mode.

    curvature = (E(ts + eps*mode) + E(ts - eps*mode) - 2*E(ts)) / eps**2
    """
    e0 = float(atoms.get_potential_energy())
    pos0 = atoms.get_positions()

    # Plus side
    atoms.set_positions(pos0 + eps * mode)
    e_plus = float(atoms.get_potential_energy())

    # Minus side
    atoms.set_positions(pos0 - eps * mode)
    e_minus = float(atoms.get_potential_energy())

    # Restore
    atoms.set_positions(pos0)

    curvature = (e_plus + e_minus - 2.0 * e0) / (eps**2)
    return curvature


def _relax(
    atoms: Atoms,
    *,
    optimizer: OptimizerName,
    fmax: float,
    steps: int,
    logfile: str | None = None,
) -> RelaxationInfo:
    """Relax an ASE Atoms object and return structured metadata."""

    info = RelaxationInfo(
        optimizer=optimizer,
        target_fmax=float(fmax),
        max_steps=int(steps),
        converged=False,
        exception=None,
        final_max_force_eV_A=float("nan"),
        final_energy_eV=float("nan"),
    )

    if fmax is None or fmax <= 0 or steps <= 0:
        try:
            info.final_max_force_eV_A = _max_force(atoms)
            info.final_energy_eV = float(atoms.get_potential_energy())
            info.converged = True
        except Exception as exc:
            info.exception = str(exc)
        return info

    try:
        if optimizer.upper() == "BFGS":
            opt = BFGS(atoms, logfile=logfile, maxstep=0.2)
        else:
            opt = FIRE(atoms, logfile=logfile)

        info.converged = bool(opt.run(fmax=float(fmax), steps=int(steps)))
        info.final_max_force_eV_A = _max_force(atoms)
        info.final_energy_eV = float(atoms.get_potential_energy())

    except Exception as exc:
        info.exception = str(exc)
        logger.warning("Relaxation failed: %s", exc)

    return info


def _quench_from_ts(
    *,
    ts_atoms: Atoms,
    mode: np.ndarray,
    sign: float,
    displacement: float,
    calculator_factory: CalculatorFactory,
    optimizer: OptimizerName,
    fmax: float,
    steps: int,
    constraints: Any | None,
) -> tuple[Atoms, RelaxationInfo]:
    """Displace from TS along a mode and relax downhill."""

    image = ts_atoms.copy()
    _set_fresh_calculator(image, calculator_factory)

    if constraints is not None:
        image.set_constraint(copy.deepcopy(constraints))

    image.set_positions(
        image.get_positions() + float(sign) * float(displacement) * mode
    )

    relax_info = _relax(
        image,
        optimizer=optimizer,
        fmax=fmax,
        steps=steps,
        logfile=None,
    )

    return image, relax_info


# =============================================================================
# Validation
# =============================================================================

def _validate_fragment_escape_settings(
    *,
    detect_fragment_escape: bool,
    fragment_escape_species: Sequence[str] | None,
    fragment_escape_axis: int | None,
    fragment_escape_distance_A: float | None,
) -> None:
    """Validate fragment escape settings."""
    if not detect_fragment_escape:
        return

    if fragment_escape_species is None:
        raise ValueError(
            "`fragment_escape_species` must be explicitly provided when "
            "`detect_fragment_escape=True`."
        )

    if len(fragment_escape_species) == 0:
        raise ValueError("`fragment_escape_species` cannot be empty.")

    if fragment_escape_axis is None:
        raise ValueError(
            "`fragment_escape_axis` must be explicitly provided when "
            "`detect_fragment_escape=True`."
        )

    if int(fragment_escape_axis) not in (0, 1, 2):
        raise ValueError("`fragment_escape_axis` must be 0, 1, or 2.")

    if fragment_escape_distance_A is None:
        raise ValueError(
            "`fragment_escape_distance_A` must be explicitly provided when "
            "`detect_fragment_escape=True`."
        )

    if float(fragment_escape_distance_A) <= 0:
        raise ValueError("`fragment_escape_distance_A` must be positive.")


# =============================================================================
# Calculator factory
# =============================================================================

def dimer_connector_hash_calculator(
    calculator_factory: CalculatorFactory | None = None,
    *,
    # MACE shortcut
    calc_path: str | None = None,
    device: str = "cuda",
    default_dtype: str = "float32",
    allow_asl: bool = False,
    cache_dir: str | None = None,

    # Hashing
    hash_function: HashFunction | None = None,
    hash_manager: Any | None = None,
    register_hash: bool = False,

    # Randomness
    seed_policy: SeedPolicy = "stochastic",

    # Initial relaxation
    root_fmax: float = 0.03,
    root_steps: int = 200,
    root_optimizer: OptimizerName = "FIRE",

    # Dimer search
    num_attempts: int = 5,
    dimer_fmax: float = 0.05,
    dimer_steps: int = 250,
    atoms_to_displace: int = 1,
    displacement_range: tuple[float, float] = (-0.15, 0.15),
    dimer_mask_mode: DimerMaskMode = "displaced",
    selection_mode: Literal["random", "force"] = "random",
    adaptive_displacement: bool = False,

    # Basin search
    ts_displacement: float = 0.08,
    basin_fmax: float = 0.03,
    basin_steps: int = 300,
    basin_optimizer: OptimizerName = "FIRE",
    same_basin_rmsd: float = 0.20,

    # Optional fragment escape / desorption detection
    detect_fragment_escape: bool = False,
    fragment_escape_species: tuple[str, ...] | None = None,
    fragment_escape_axis: int | None = None,
    fragment_escape_distance_A: float | None = None,
    fragment_escape_reference_mode: FragmentEscapeReferenceMode = "center_of_mass",
    fragment_escape_fixed_reference_value: float | None = None,
    delete_escaped_fragments_from_final: bool = False,

    # Backward compatibility for desorption names
    allow_desorption: bool | None = None,
    desorb_species: tuple[str, ...] | None = None,
    desorption_axis: int | None = None,
    desorption_distance_A: float | None = None,
    desorption_reference_mode: FragmentEscapeReferenceMode | None = None,
    desorption_fixed_reference_value: float | None = None,
    delete_desorbed_from_final: bool | None = None,

    # Filters
    max_ts_energy_above_initial_eV: float | None = 5.0,
    require_product_different: bool = True,

    # Return policy
    return_policy: ReturnPolicy = "best_triplet",
    rank_by: RankBy = "barrier_forward_eV",

    # Constraints
    constraint_logic: ConstraintLogic = "all",
    constraint_action: ConstraintAction = "freeze",
    freeze_components: Sequence[int | str] | None = None,
    constraints: Sequence[ConstraintPredicate] | ConstraintPredicate | None = None,

    # IO
    write_trajectories: bool = True,
    store_dimer_mode: bool = True,
    write_manifest: bool = True,
    manifest_filename: str = "dimer_connector_manifest.jsonl",

    # Network / Validation
    ts_validation_level: TSValidationLevel = "energy_only",
    curvature_epsilon_A: float = 0.005,
    pbc: Sequence[bool] | bool | None = None,
) -> Callable[..., CalculatorReturn]:
    """
    Build a graph-aware dimer connector calculator.

    Parameters
    ----------
    calculator_factory
        ASE calculator factory or calculator object. If None, `calc_path` is
        used to build a MACE calculator.
    calc_path
        MACE model spec/path, used only when `calculator_factory is None`.
    hash_function
        Optional function `hash_function(container) -> str`.
    hash_manager
        Optional hash manager exposing `get_hash(...)` or
        `add_structure_voted(...)`.
    register_hash
        If True and the hash manager supports `add_structure_voted`, register
        structures in the hash manager during hashing.
    seed_policy
        Controls reproducibility/stochasticity of random dimer modes.
    return_policy
        "best_triplet": return initial, best TS, best final.
        "all_triplets": return initial plus all successful TS/final pairs.
        "initial_if_failed": failure returns initial only.
    rank_by
        Quantity used to select the best candidate.
    """
    # -------------------------------------------------------------------------
    # Backward compatibility mapping
    # -------------------------------------------------------------------------
    if allow_desorption is not None:
        detect_fragment_escape = allow_desorption
    if desorb_species is not None:
        fragment_escape_species = desorb_species
    if desorption_axis is not None:
        fragment_escape_axis = desorption_axis
    if desorption_distance_A is not None:
        fragment_escape_distance_A = desorption_distance_A
    if desorption_reference_mode is not None:
        fragment_escape_reference_mode = desorption_reference_mode
    if desorption_fixed_reference_value is not None:
        fragment_escape_fixed_reference_value = desorption_fixed_reference_value
    if delete_desorbed_from_final is not None:
        delete_escaped_fragments_from_final = delete_desorbed_from_final

    _validate_fragment_escape_settings(
        detect_fragment_escape=detect_fragment_escape,
        fragment_escape_species=fragment_escape_species,
        fragment_escape_axis=fragment_escape_axis,
        fragment_escape_distance_A=fragment_escape_distance_A,
    )

    # -------------------------------------------------------------------------
    # Build calculator factory
    # -------------------------------------------------------------------------
    if calculator_factory is None:
        if calc_path is None:
            raise ValueError("Provide either `calculator_factory` or `calc_path`.")

        if resolve_model_spec is None:
            raise ImportError(
                "Could not import MACE utilities. Pass `calculator_factory` "
                "directly or fix ezga.simulator.mace_utils."
            )

        name, license_tag, url_or_path = resolve_model_spec(calc_path)
        assert_license_ok(license_tag, allow_asl=allow_asl)
        model_local_path = download_if_needed(url_or_path, cache_root=cache_dir)

        from mace.calculators.mace import MACECalculator

        def _mace_factory() -> object:
            return MACECalculator(
                model_paths=model_local_path,
                device=device,
                default_dtype=default_dtype,
            )

        calculator_factory = _mace_factory

    factory_constraints = _to_pred_list(constraints)
    freeze_components_norm = _normalize_components(freeze_components)

    # Load default hash manager once per calculator instance, not per run call.
    local_hash_manager = hash_manager
    if hash_function is None and local_hash_manager is None:
        local_hash_manager = _load_default_hash_manager()

    def run(
        symbols: Sequence[str],
        positions: np.ndarray,
        cell: np.ndarray | None,
        fixed: np.ndarray | None = None,
        parent_hash: str | None = None,
        output_filename: str = "dimer_connector_hash_out.xyz",
        constraints: Sequence[ConstraintPredicate] | ConstraintPredicate | None = None,
        seed: int | None = None,
        shared_state: MutableMapping[str, Any] | None = None,
        **kwargs: Any,
    ) -> CalculatorReturn:
        """
        Run one dimer-connector exploration from one input structure.

        This signature is compatible with the EZGA Simulator.
        """

        parent_hash = parent_hash or "root"

        rng, random_meta = _make_rng(
            seed=seed,
            parent_hash=parent_hash,
            shared_state=shared_state,
            seed_policy=seed_policy,
        )

        out_dir = os.path.dirname(output_filename) or "."
        os.makedirs(out_dir, exist_ok=True)

        manifest_path = (
            os.path.join(out_dir, manifest_filename) if write_manifest else None
        )

        # ---------------------------------------------------------------------
        # Build root atoms
        # ---------------------------------------------------------------------
        try:
            root = _build_atoms(
                symbols=symbols,
                positions=positions,
                cell=cell,
                calculator_factory=calculator_factory,
            )
            if pbc is not None:
                root.set_pbc(pbc)
            elif cell is not None and np.any(np.abs(cell) > 1e-8):
                root.set_pbc(True)
        except Exception as exc:
            logger.error("Could not build ASE Atoms object: %s", exc)
            return []

        selected, ase_constraint = _apply_constraints(
            atoms=root,
            symbols=symbols,
            positions=np.asarray(positions, dtype=float),
            cell=cell,
            fixed=fixed,
            factory_constraints=factory_constraints,
            run_constraints=constraints,
            constraint_logic=constraint_logic,
            constraint_action=constraint_action,
            freeze_components_norm=freeze_components_norm,
        )

        n_atoms = len(root)

        free_indices = _get_free_indices(
            n_atoms=n_atoms,
            selected=selected,
            constraint_action=constraint_action,
            has_constraints=ase_constraint is not None,
        )

        if len(free_indices) == 0:
            logger.warning("No free atoms available for dimer search.")
            return []

        # ---------------------------------------------------------------------
        # Relax initial minimum
        # ---------------------------------------------------------------------
        root_relax_info = _relax(
            root,
            optimizer=root_optimizer,
            fmax=root_fmax,
            steps=root_steps,
            logfile=None,
        )

        initial_identity = _compute_hash_identity(
            root,
            role_prefix="min",
            hash_function=hash_function,
            hash_manager=local_hash_manager,
            register_hash=register_hash,
        )

        initial_energy = float(root.get_potential_energy())

        # ---------------------------------------------------------------------
        # Provenance and stable identifiers
        # ---------------------------------------------------------------------
        provenance = _get_provenance(calculator_factory, device, default_dtype)

        run_id = _stable_key(
            "dimer_connector",
            parent_hash,
            initial_identity.state_key,
            random_meta.get("local_seed"),
            output_filename,
        )

        parameter_dict = {
            "root_fmax": root_fmax,
            "root_steps": root_steps,
            "root_optimizer": root_optimizer,
            "num_attempts": num_attempts,
            "selection_mode": selection_mode,
            "adaptive_displacement": adaptive_displacement,
            "dimer_fmax": dimer_fmax,
            "dimer_steps": dimer_steps,
            "atoms_to_displace": atoms_to_displace,
            "displacement_range": displacement_range,
            "dimer_mask_mode": dimer_mask_mode,
            "ts_displacement": ts_displacement,
            "basin_fmax": basin_fmax,
            "basin_steps": basin_steps,
            "basin_optimizer": basin_optimizer,
            "same_basin_rmsd": same_basin_rmsd,
            "return_policy": return_policy,
            "rank_by": rank_by,
            "ts_validation_level": ts_validation_level,
            "detect_fragment_escape": detect_fragment_escape,
            "fragment_escape_species": fragment_escape_species,
        }

        run_record = {
            "record_type": "run",
            "schema_version": "ezga_dimer_connector.v1",
            "run_id": run_id,
            "parent_hash": parent_hash,
            "initial_state_key": initial_identity.state_key,
            "num_attempts": num_attempts,
            "parameters": parameter_dict,
            "provenance": provenance,
        }
        _write_manifest_record(manifest_path, run_record)

        initial_meta: dict[str, Any] = {
            "type": "initial_minimum",
            "node_role": "minimum",
            "state_kind": "minimum",
            "run_id": run_id,
            "provenance": provenance,
            **initial_identity.to_dict(),

            "parent_hash": parent_hash,
            "generated_by": "dimer_connector_hash_calculator",
            "random": random_meta,

            "graph": {
                "node_type": "minimum",
                "state_key": initial_identity.state_key,
                "state_id": initial_identity.state_id,
                "hash_raw": initial_identity.hash_raw,
                "hash_method": initial_identity.hash_method,
                "composition_key": initial_identity.composition_key,
            },

            "relaxation": root_relax_info.to_dict(),

            "constraints": {
                "constraint_logic": constraint_logic,
                "constraint_action": constraint_action,
                "freeze_components": (
                    list(freeze_components_norm)
                    if freeze_components_norm is not None
                    else None
                ),
                "selected_indices": selected.tolist(),
                "num_free_indices": len(free_indices),
                "free_indices": free_indices,
            },

            "energy_eV": initial_energy,
            "composition_key": initial_identity.composition_key,
            "max_force_eV_A": _max_force(root),
            "connector_status": "started",
        }

        # Write initial minimum to manifest
        initial_node_record = NetworkNodeRecord(
            schema_version="ezga_dimer_connector.v1",
            node_key=initial_identity.state_key,
            node_id=initial_identity.state_id,
            node_role="minimum",
            composition_key=initial_identity.composition_key,
            hash_raw=initial_identity.hash_raw,
            hash_method=initial_identity.hash_method,
            energy_eV=initial_energy,
            run_id=run_id,
            attempt_id=None,
            metadata=_sanitize_metadata(initial_meta),
        )
        _write_manifest_record(
            manifest_path, {"record_type": "minimum", **initial_node_record.to_dict()}
        )

        if n_atoms < 2:
            initial_meta["connector_status"] = "success_single_atom"
            return [_package_result(root, initial_meta)]

        # ---------------------------------------------------------------------
        # Run dimer attempts
        # ---------------------------------------------------------------------
        candidates: list[dict[str, Any]] = []
        failed_attempts: list[dict[str, Any]] = []

        current_range = list(displacement_range)

        for attempt in range(int(num_attempts)):
            attempt_id = _stable_key(run_id, "attempt", attempt)
            # Per-attempt deterministic RNG
            attempt_seed = _seed_from_parts(run_id, attempt)
            attempt_rng = np.random.default_rng(attempt_seed)

            attempt_info: dict[str, Any] = {
                "attempt": int(attempt),
                "attempt_id": attempt_id,
                "run_id": run_id,
                "status": "started",
                "exception": None,
                "seed": int(attempt_seed),
            }

            image = root.copy()
            _set_fresh_calculator(image, calculator_factory)

            if ase_constraint is not None:
                image.set_constraint(copy.deepcopy(ase_constraint))

            n_disp = min(int(atoms_to_displace), len(free_indices))

            if n_disp <= 0:
                attempt_info["status"] = "failed"
                attempt_info["reason"] = "no_atoms_to_displace"
                failed_attempts.append(attempt_info)
                _write_manifest_record(manifest_path, {"record_type": "attempt", **attempt_info})
                continue

            if selection_mode == "force":
                # Get forces from initial minima (root)
                f_norms = np.linalg.norm(root.get_forces(), axis=1)
                free_forces = f_norms[free_indices]
                # Pick top n_disp indices with highest forces among free atoms
                top_idx_in_free = np.argsort(free_forces)[-n_disp:]
                displaced_atoms = np.asarray(free_indices, dtype=int)[top_idx_in_free]
            else:
                displaced_atoms = attempt_rng.choice(
                    np.asarray(free_indices, dtype=int),
                    size=n_disp,
                    replace=False,
                )

            mode_guess = np.zeros((n_atoms, 3), dtype=float)

            for atom_idx in displaced_atoms:
                mode_guess[int(atom_idx)] = attempt_rng.uniform(
                    low=current_range[0],
                    high=current_range[1],
                    size=3,
                )

            try:
                mode_guess = _normalise_mode(mode_guess, n_atoms=n_atoms)
            except Exception as exc:
                attempt_info["status"] = "failed"
                attempt_info["reason"] = "invalid_random_mode"
                attempt_info["exception"] = str(exc)
                failed_attempts.append(attempt_info)
                continue

            if dimer_mask_mode == "all_free":
                free_set = set(int(i) for i in free_indices)
                dimer_mask = [1 if i in free_set else 0 for i in range(n_atoms)]

            elif dimer_mask_mode == "displaced":
                displaced_set = set(int(i) for i in displaced_atoms)
                dimer_mask = [1 if i in displaced_set else 0 for i in range(n_atoms)]

            else:
                raise ValueError("dimer_mask_mode must be 'displaced' or 'all_free'.")

            attempt_info.update(
                {
                    "displaced_atoms": [int(i) for i in displaced_atoms],
                    "dimer_mask_mode": dimer_mask_mode,
                    "dimer_mask": dimer_mask,
                }
            )

            try:
                d_control = DimerControl(
                    initial_eigenmode_method="displacement",
                    displacement_method="vector",
                    logfile=None,
                    mask=dimer_mask,
                )

                d_atoms = MinModeAtoms(image, d_control)
                d_atoms.displace(displacement_vector=mode_guess)

                dimer_relax = MinModeTranslate(
                    d_atoms,
                    logfile=None,
                    trajectory=None,
                )

                traj_path = None
                xyz_path = None

                traj_handles: list[Any] = []
                if write_trajectories:
                    base, _ext = os.path.splitext(output_filename)

                    traj_path = f"{base}_attempt{attempt}_dimer.traj"
                    xyz_path = f"{base}_attempt{attempt}_dimer.xyz"

                    h_traj = _attach_energy_trajectory(
                        optimizer=dimer_relax,
                        atoms=image,
                        trajectory_path=traj_path,
                        interval=1,
                    )
                    traj_handles.append(h_traj)

                    h_xyz = _attach_energy_extxyz(
                        optimizer=dimer_relax,
                        atoms=image,
                        xyz_path=xyz_path,
                        interval=1,
                    )
                    traj_handles.append(h_xyz)

                dimer_converged = bool(
                    dimer_relax.run(
                        fmax=float(dimer_fmax),
                        steps=int(dimer_steps),
                    )
                )

                ts_atoms = image.copy()
                _set_fresh_calculator(ts_atoms, calculator_factory)

                if ase_constraint is not None:
                    ts_atoms.set_constraint(copy.deepcopy(ase_constraint))

                ts_energy = float(ts_atoms.get_potential_energy())
                barrier_forward = ts_energy - initial_energy

                attempt_info.update(
                    {
                        "dimer_converged": bool(dimer_converged),
                        "ts_energy_eV": float(ts_energy),
                        "barrier_forward_guess_eV": float(barrier_forward),
                        "ts_max_force_eV_A": _max_force(ts_atoms),
                        "trajectory": traj_path,
                        "trajectory_extxyz": xyz_path,
                    }
                )

                if max_ts_energy_above_initial_eV is not None:
                    if barrier_forward > float(max_ts_energy_above_initial_eV):
                        attempt_info["status"] = "rejected"
                        attempt_info["reason"] = "ts_energy_above_initial_too_high"
                        failed_attempts.append(attempt_info)
                        continue

                mode = _extract_dimer_mode(
                    d_atoms,
                    fallback_mode=mode_guess,
                    n_atoms=n_atoms,
                )

                # -------------------------------------------------------------
                # Quench both sides of the saddle
                # -------------------------------------------------------------
                basin_plus, relax_plus = _quench_from_ts(
                    ts_atoms=ts_atoms,
                    mode=mode,
                    sign=+1.0,
                    displacement=ts_displacement,
                    calculator_factory=calculator_factory,
                    optimizer=basin_optimizer,
                    fmax=basin_fmax,
                    steps=basin_steps,
                    constraints=ase_constraint,
                )

                basin_minus, relax_minus = _quench_from_ts(
                    ts_atoms=ts_atoms,
                    mode=mode,
                    sign=-1.0,
                    displacement=ts_displacement,
                    calculator_factory=calculator_factory,
                    optimizer=basin_optimizer,
                    fmax=basin_fmax,
                    steps=basin_steps,
                    constraints=ase_constraint,
                )

                # -------------------------------------------------------------
                # Identify basins using hashes
                # -------------------------------------------------------------
                plus_identity = _compute_hash_identity(
                    basin_plus,
                    role_prefix="min",
                    hash_function=hash_function,
                    hash_manager=local_hash_manager,
                    register_hash=register_hash,
                )
                minus_identity = _compute_hash_identity(
                    basin_minus,
                    role_prefix="min",
                    hash_function=hash_function,
                    hash_manager=local_hash_manager,
                    register_hash=register_hash,
                )

                plus_is_initial = plus_identity.state_key == initial_identity.state_key
                minus_is_initial = minus_identity.state_key == initial_identity.state_key

                rmsd_plus = _rmsd_same_order(root, basin_plus)
                rmsd_minus = _rmsd_same_order(root, basin_minus)

                e_plus = float(basin_plus.get_potential_energy())
                e_minus = float(basin_minus.get_potential_energy())

                # Decision logic for final_atoms (EZGA legacy compatibility)
                if plus_is_initial and not minus_is_initial:
                    final_atoms = basin_minus
                    product_side = "-"
                    initial_side = "+"
                    final_identity = minus_identity
                elif minus_is_initial and not plus_is_initial:
                    final_atoms = basin_plus
                    product_side = "+"
                    initial_side = "-"
                    final_identity = plus_identity
                elif not plus_is_initial and not minus_is_initial:
                    if e_plus <= e_minus:
                        final_atoms = basin_plus
                        product_side = "+"
                        initial_side = "-"
                        final_identity = plus_identity
                    else:
                        final_atoms = basin_minus
                        product_side = "-"
                        initial_side = "+"
                        final_identity = minus_identity
                else:
                    # Both sides returned to initial
                    if require_product_different:
                        attempt_info["status"] = "rejected"
                        attempt_info["reason"] = "both_sides_returned_to_initial"
                        attempt_info["rmsd_plus_to_initial"] = float(rmsd_plus)
                        attempt_info["rmsd_minus_to_initial"] = float(rmsd_minus)
                        failed_attempts.append(attempt_info)
                        _write_manifest_record(manifest_path, {"record_type": "attempt", **attempt_info})
                        continue

                    # If we don't require different, pick one
                    final_atoms = basin_plus
                    product_side = "+"
                    initial_side = "-"
                    final_identity = plus_identity

                # -------------------------------------------------------------
                # Fragment escape detection
                # -------------------------------------------------------------
                escaped_indices: list[int] = []

                if detect_fragment_escape:
                    # These were validated in the factory
                    assert fragment_escape_species is not None
                    assert fragment_escape_axis is not None
                    assert fragment_escape_distance_A is not None

                    escaped_indices = _detect_escaped_fragments(
                        final_atoms,
                        escape_species=fragment_escape_species,
                        escape_axis=fragment_escape_axis,
                        escape_distance_A=fragment_escape_distance_A,
                        reference_mode=fragment_escape_reference_mode,
                        fixed_reference_value=fragment_escape_fixed_reference_value,
                    )

                fragment_escape_meta = {
                    "detect_fragment_escape": bool(detect_fragment_escape),
                    "fragment_escape_species": (
                        list(fragment_escape_species)
                        if fragment_escape_species is not None
                        else None
                    ),
                    "escaped_indices": [int(i) for i in escaped_indices],
                    "escaped_symbols": [
                        final_atoms.get_chemical_symbols()[i]
                        for i in escaped_indices
                    ],
                    "delete_escaped_fragments_from_final": bool(
                        delete_escaped_fragments_from_final
                    ),
                    "fragment_escape_axis": (
                        int(fragment_escape_axis)
                        if fragment_escape_axis is not None
                        else None
                    ),
                    "fragment_escape_distance_A": (
                        float(fragment_escape_distance_A)
                        if fragment_escape_distance_A is not None
                        else None
                    ),
                    "fragment_escape_reference_mode": fragment_escape_reference_mode,
                }

                if (
                    delete_escaped_fragments_from_final
                    and len(escaped_indices) > 0
                ):
                    keep = [
                        i
                        for i in range(len(final_atoms))
                        if i not in set(escaped_indices)
                    ]
                    final_atoms = final_atoms[keep]
                    _set_fresh_calculator(final_atoms, calculator_factory)

                final_energy = float(final_atoms.get_potential_energy())

                # -------------------------------------------------------------
                # Network layer: Validation and identity
                # -------------------------------------------------------------
                curvature: float | None = None
                if ts_validation_level in ("curvature_check", "strict"):
                    curvature = _calculate_curvature(
                        ts_atoms, mode, eps=curvature_epsilon_A
                    )

                # TS identity depends on the unordered pair of endpoints
                ts_identity = _compute_ts_identity(
                    ts_atoms,
                    initial_state_key=plus_identity.state_key,
                    final_state_key=minus_identity.state_key,
                    hash_function=hash_function,
                    hash_manager=local_hash_manager,
                    register_hash=register_hash,
                )

                # Recompute final identity if atoms were deleted
                if (
                    delete_escaped_fragments_from_final
                    and len(escaped_indices) > 0
                ):
                    final_identity = _compute_hash_identity(
                        final_atoms,
                        role_prefix="min",
                        hash_function=hash_function,
                        hash_manager=local_hash_manager,
                        register_hash=register_hash,
                    )

                barrier_forward = ts_energy - initial_energy
                barrier_backward = ts_energy - final_energy
                delta_E_final_initial = final_energy - initial_energy

                # -------------------------------------------------------------
                # Network layer: Records
                # -------------------------------------------------------------
                attempt_info["status"] = "success"
                attempt_info["dimer_converged"] = bool(dimer_converged)
                attempt_info["ts_energy_eV"] = float(ts_energy)
                attempt_info["endpoint_plus_key"] = plus_identity.state_key
                attempt_info["endpoint_minus_key"] = minus_identity.state_key

                attempt_record = DimerAttemptRecord(
                    schema_version="ezga_dimer_connector.v1",
                    run_id=run_id,
                    attempt_id=attempt_id,
                    attempt_index=int(attempt),
                    status="success",
                    reason=None,
                    displaced_atoms=[int(i) for i in displaced_atoms],
                    dimer_converged=bool(dimer_converged),
                    ts_energy_eV=float(ts_energy),
                    endpoint_plus_key=plus_identity.state_key,
                    endpoint_minus_key=minus_identity.state_key,
                    metadata=_sanitize_metadata(attempt_info),
                )
                _write_manifest_record(
                    manifest_path, {"record_type": "attempt", **attempt_record.to_dict()}
                )

                ts_connection_meta = {
                    "endpoint_plus": {
                        "state_key": plus_identity.state_key,
                        "state_id": plus_identity.state_id,
                        "energy_eV": e_plus,
                        "relaxation": relax_plus.to_dict(),
                        "rmsd_to_initial_A": float(rmsd_plus),
                        "is_initial": bool(plus_is_initial),
                    },
                    "endpoint_minus": {
                        "state_key": minus_identity.state_key,
                        "state_id": minus_identity.state_id,
                        "energy_eV": e_minus,
                        "relaxation": relax_minus.to_dict(),
                        "rmsd_to_initial_A": float(rmsd_minus),
                        "is_initial": bool(minus_is_initial),
                    },
                    "is_self_connection": plus_identity.state_key
                    == minus_identity.state_key,
                }

                # Edge plus -> minus
                edge_pm_key = _stable_key(
                    "edge", plus_identity.state_key, minus_identity.state_key, ts_identity.state_key
                )
                edge_pm = DirectedEdgeRecord(
                    schema_version="ezga_dimer_connector.v1",
                    edge_key=edge_pm_key,
                    source_key=plus_identity.state_key,
                    target_key=minus_identity.state_key,
                    ts_key=ts_identity.state_key,
                    barrier_eV=float(ts_energy - e_plus),
                    delta_E_eV=float(e_minus - e_plus),
                    source_energy_eV=e_plus,
                    target_energy_eV=e_minus,
                    ts_energy_eV=ts_energy,
                    run_id=run_id,
                    attempt_id=attempt_id,
                    metadata={},
                )
                _write_manifest_record(
                    manifest_path, {"record_type": "edge", **edge_pm.to_dict()}
                )

                # Edge minus -> plus
                edge_mp_key = _stable_key(
                    "edge", minus_identity.state_key, plus_identity.state_key, ts_identity.state_key
                )
                edge_mp = DirectedEdgeRecord(
                    schema_version="ezga_dimer_connector.v1",
                    edge_key=edge_mp_key,
                    source_key=minus_identity.state_key,
                    target_key=plus_identity.state_key,
                    ts_key=ts_identity.state_key,
                    barrier_eV=float(ts_energy - e_minus),
                    delta_E_eV=float(e_plus - e_minus),
                    source_energy_eV=e_minus,
                    target_energy_eV=e_plus,
                    ts_energy_eV=ts_energy,
                    run_id=run_id,
                    attempt_id=attempt_id,
                    metadata={},
                )
                _write_manifest_record(
                    manifest_path, {"record_type": "edge", **edge_mp.to_dict()}
                )

                candidates.append(
                    {
                        "attempt": int(attempt),
                        "attempt_id": attempt_id,
                        "status": "success",
                        "initial_atoms": root,
                        "ts_atoms": ts_atoms,
                        "final_atoms": final_atoms,
                        "mode": mode,
                        "plus_identity": plus_identity,
                        "minus_identity": minus_identity,
                        "initial_identity": initial_identity,
                        "final_identity": final_identity,
                        "ts_identity": ts_identity,
                        "initial_energy_eV": initial_energy,
                        "ts_energy_eV": ts_energy,
                        "final_energy_eV": final_energy,
                        "e_plus": e_plus,
                        "e_minus": e_minus,
                        "barrier_forward_eV": ts_energy - initial_energy,
                        "barrier_backward_eV": ts_energy - final_energy,
                        "delta_E_final_initial_eV": final_energy - initial_energy,
                        "displaced_atoms": [int(i) for i in displaced_atoms],
                        "dimer_converged": bool(dimer_converged),
                        "basin_plus_relaxation": relax_plus.to_dict(),
                        "basin_minus_relaxation": relax_minus.to_dict(),
                        "rmsd_plus_to_initial": float(rmsd_plus),
                        "rmsd_minus_to_initial": float(rmsd_minus),
                        "plus_is_initial": bool(plus_is_initial),
                        "minus_is_initial": bool(minus_is_initial),
                        "product_side": product_side,
                        "initial_side": initial_side,
                        "trajectory": traj_path,
                        "attempt_info": attempt_info,
                        "fragment_escape": fragment_escape_meta,
                        "ts_connection": ts_connection_meta,
                        "curvature": curvature,
                        "directed_edges": [edge_pm.to_dict(), edge_mp.to_dict()],
                    }
                )

                # Adaptive range update
                if adaptive_displacement:
                    if dimer_converged:
                        current_range = list(displacement_range)
                    else:
                        current_range[0] -= 0.05
                        current_range[1] += 0.05

            except Exception as exc:
                attempt_info["status"] = "failed"
                attempt_info["exception"] = str(exc)
                failed_attempts.append(attempt_info)
                _write_manifest_record(manifest_path, {"record_type": "attempt", **attempt_info})
                logger.warning("Dimer attempt %s failed: %s", attempt, exc)
                
                # Expand range on failure/exception
                if adaptive_displacement:
                    current_range[0] -= 0.05
                    current_range[1] += 0.05
                continue

            finally:
                # Stage 7: Formal resource closing
                for handle in traj_handles:
                    if hasattr(handle, "close"):
                        try:
                            handle.close()
                        except Exception:
                            pass

        # ---------------------------------------------------------------------
        # Failure case
        # ---------------------------------------------------------------------
        if not candidates:
            initial_meta["connector_status"] = "no_ts_found"
            initial_meta["num_successful_attempts"] = 0
            initial_meta["num_failed_attempts"] = len(failed_attempts)
            initial_meta["failed_attempts"] = failed_attempts
            return [_package_result(root, initial_meta)]

        # ---------------------------------------------------------------------
        # Rank candidates
        # ---------------------------------------------------------------------
        def _rank_value(candidate: dict[str, Any]) -> float:
            if rank_by == "barrier_forward_eV":
                return float(candidate["barrier_forward_eV"])

            if rank_by == "ts_energy_eV":
                return float(candidate["ts_energy_eV"])

            if rank_by == "final_energy_eV":
                return float(candidate["final_energy_eV"])

            if rank_by == "min_barrier_from_initial_eV":
                # If one side is initial, return that barrier. Else min of both.
                ts_e = float(candidate["ts_energy_eV"])
                b_plus = ts_e - float(candidate["e_plus"])
                b_minus = ts_e - float(candidate["e_minus"])

                if candidate["plus_is_initial"]:
                    return b_plus
                if candidate["minus_is_initial"]:
                    return b_minus
                return min(b_plus, b_minus)

            if rank_by == "min_barrier_any_direction_eV":
                ts_e = float(candidate["ts_energy_eV"])
                return min(ts_e - float(candidate["e_plus"]), ts_e - float(candidate["e_minus"]))

            if rank_by == "delta_E_abs_eV":
                return abs(float(candidate["delta_E_final_initial_eV"]))

            raise ValueError(f"Unknown rank_by={rank_by!r}")

        candidates = sorted(candidates, key=_rank_value)

        # ---------------------------------------------------------------------
        # Build outputs
        # ---------------------------------------------------------------------
        initial_meta["connector_status"] = "success"
        initial_meta["num_successful_attempts"] = len(candidates)
        initial_meta["num_failed_attempts"] = len(failed_attempts)
        initial_meta["failed_attempts"] = failed_attempts

        results: list[CalcResult] = [_package_result(root, initial_meta)]

        selected_candidates = candidates if return_policy == "all_triplets" else [candidates[0]]

        for rank, candidate in enumerate(selected_candidates):
            ts_atoms = candidate["ts_atoms"]
            final_atoms = candidate["final_atoms"]

            res_final_identity = candidate["final_identity"]
            res_ts_identity = candidate["ts_identity"]

            directed_edges = [
                {
                    "source": initial_identity.state_key,
                    "target": res_final_identity.state_key,
                    "ts": res_ts_identity.state_key,
                    "barrier_eV": candidate["barrier_forward_eV"],
                    "direction": "forward",
                },
                {
                    "source": res_final_identity.state_key,
                    "target": initial_identity.state_key,
                    "ts": res_ts_identity.state_key,
                    "barrier_eV": candidate["barrier_backward_eV"],
                    "direction": "backward",
                },
            ]

            final_meta: dict[str, Any] = {
                "type": "final_minimum",
                "node_role": "minimum",
                "state_kind": "minimum",
                "run_id": run_id,
                "attempt_id": candidate["attempt_id"],
                "provenance": provenance,
                **res_final_identity.to_dict(),

                "parent_hash": parent_hash,
                "generated_by": "dimer_connector_hash_calculator",
                "rank": int(rank),
                "random": random_meta,

                "graph": {
                    "node_type": "minimum",
                    "state_key": res_final_identity.state_key,
                    "state_id": res_final_identity.state_id,
                    "hash_raw": res_final_identity.hash_raw,
                    "hash_method": res_final_identity.hash_method,
                    "composition_key": res_final_identity.composition_key,
                    "connected_from_ts": res_ts_identity.state_key,
                    "connected_to_initial": initial_identity.state_key,
                },
                "connected_from_ts": res_ts_identity.state_id,
                "connected_to_initial": initial_identity.state_id,

                "energy_eV": candidate["final_energy_eV"],
                "initial_energy_eV": candidate["initial_energy_eV"],
                "delta_E_final_initial_eV": candidate["delta_E_final_initial_eV"],
                "composition_key": res_final_identity.composition_key,
                "max_force_eV_A": _max_force(final_atoms),

                "fragment_escape": candidate["fragment_escape"],

                "basin_search": {
                    "product_side": candidate["product_side"],
                    "initial_side": candidate["initial_side"],
                    "rmsd_plus_to_initial": candidate["rmsd_plus_to_initial"],
                    "rmsd_minus_to_initial": candidate["rmsd_minus_to_initial"],
                    "plus_is_initial": candidate["plus_is_initial"],
                    "minus_is_initial": candidate["minus_is_initial"],
                    "basin_plus_relaxation": candidate["basin_plus_relaxation"],
                    "basin_minus_relaxation": candidate["basin_minus_relaxation"],
                },
            }

            ts_meta: dict[str, Any] = {
                "type": "transition_state",
                "node_role": "transition_state",
                "state_kind": "saddle",
                "run_id": run_id,
                "attempt_id": candidate["attempt_id"],
                "provenance": provenance,
                **res_ts_identity.to_dict(),

                "parent_hash": parent_hash,
                "generated_by": "dimer_connector_hash_calculator",
                "rank": int(rank),
                "random": random_meta,

                "graph": {
                    "node_type": "transition_state",
                    "state_key": res_ts_identity.state_key,
                    "state_id": res_ts_identity.state_id,
                    "ts_key": res_ts_identity.ts_key,
                    "hash_raw": res_ts_identity.hash_raw,
                    "hash_method": res_ts_identity.hash_method,
                    "composition_key": res_ts_identity.composition_key,
                    "connects": {
                        "initial": initial_identity.state_key,
                        "final": res_final_identity.state_key,
                    },
                    "connects_ids": {
                        "initial": initial_identity.state_id,
                        "final": res_final_identity.state_id,
                    },
                },
                "network": {
                    "object_role": "transition_state",
                    "ts_key": res_ts_identity.state_key,
                    "ts_id": res_ts_identity.state_id,
                    "endpoint_keys": [
                        candidate["plus_identity"].state_key,
                        candidate["minus_identity"].state_key,
                    ],
                    "endpoint_ids": [
                        candidate["plus_identity"].state_id,
                        candidate["minus_identity"].state_id,
                    ],
                    "directed_edges": candidate["directed_edges"],
                },

                "connects": {
                    "initial": initial_identity.state_key,
                    "final": res_final_identity.state_key,
                },

                "connects_ids": {
                    "initial": initial_identity.state_id,
                    "final": res_final_identity.state_id,
                },

                "connected_minima_keys": [
                    initial_identity.state_key,
                    res_final_identity.state_key,
                ],

                "connected_minima_ids": [
                    initial_identity.state_id,
                    res_final_identity.state_id,
                ],

                "energy_eV": candidate["ts_energy_eV"],
                "initial_energy_eV": candidate["initial_energy_eV"],
                "final_energy_eV": candidate["final_energy_eV"],

                "barrier_forward_eV": candidate["barrier_forward_eV"],
                "barrier_backward_eV": candidate["barrier_backward_eV"],
                "delta_E_final_initial_eV": candidate["delta_E_final_initial_eV"],

                "fragment_escape": candidate["fragment_escape"],

                "dimer": {
                    "attempt": candidate["attempt"],
                    "dimer_converged": candidate["dimer_converged"],
                    "dimer_fmax": dimer_fmax,
                    "dimer_steps": dimer_steps,
                    "displaced_atoms": candidate["displaced_atoms"],
                    "dimer_mask_mode": dimer_mask_mode,
                    "trajectory": candidate["trajectory"],
                    "max_force_eV_A": _max_force(ts_atoms),
                },

                "basin_search": {
                    "ts_displacement": ts_displacement,
                    "product_side": candidate["product_side"],
                    "initial_side": candidate["initial_side"],
                    "rmsd_plus_to_initial": candidate["rmsd_plus_to_initial"],
                    "rmsd_minus_to_initial": candidate["rmsd_minus_to_initial"],
                    "plus_is_initial": candidate["plus_is_initial"],
                    "minus_is_initial": candidate["minus_is_initial"],
                    "same_basin_rmsd": same_basin_rmsd,
                    "basin_plus_relaxation": candidate["basin_plus_relaxation"],
                    "basin_minus_relaxation": candidate["basin_minus_relaxation"],
                },
            }

            if store_dimer_mode:
                ts_meta["dimer"]["mode"] = candidate["mode"]

            # Write final minimum to manifest
            final_node_record = NetworkNodeRecord(
                schema_version="ezga_dimer_connector.v1",
                node_key=res_final_identity.state_key,
                node_id=res_final_identity.state_id,
                node_role="minimum",
                composition_key=res_final_identity.composition_key,
                hash_raw=res_final_identity.hash_raw,
                hash_method=res_final_identity.hash_method,
                energy_eV=candidate["final_energy_eV"],
                run_id=run_id,
                attempt_id=candidate["attempt_id"],
                metadata=_sanitize_metadata(final_meta),
            )
            _write_manifest_record(
                manifest_path, {"record_type": "minimum", **final_node_record.to_dict()}
            )

            # Write TS to manifest
            ts_node_record = NetworkNodeRecord(
                schema_version="ezga_dimer_connector.v1",
                node_key=res_ts_identity.state_key,
                node_id=res_ts_identity.state_id,
                node_role="transition_state",
                composition_key=res_ts_identity.composition_key,
                hash_raw=res_ts_identity.hash_raw,
                hash_method=res_ts_identity.hash_method,
                energy_eV=candidate["ts_energy_eV"],
                run_id=run_id,
                attempt_id=candidate["attempt_id"],
                metadata=_sanitize_metadata(ts_meta),
            )
            _write_manifest_record(
                manifest_path,
                {"record_type": "transition_state", **ts_node_record.to_dict()},
            )

            results.append(_package_result(ts_atoms, ts_meta))
            results.append(_package_result(final_atoms, final_meta))

        return results

    return run