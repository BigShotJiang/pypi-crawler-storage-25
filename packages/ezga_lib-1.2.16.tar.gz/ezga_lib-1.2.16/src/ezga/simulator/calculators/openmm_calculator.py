"""
OpenMM Calculator for EZGA.

This module provides a high-level interface for performing molecular mechanics
calculations on protein and protein-ligand systems using OpenMM.
"""

from __future__ import annotations

import logging
from typing import Any, Optional, cast

import numpy as np
from ase import Atoms

try:
    import openmm
    import openmm.app as app
    import openmm.unit as u
    OPENMM_AVAILABLE = True
except ImportError:
    OPENMM_AVAILABLE = False

from . import register_calculator as registry_register
from .calculator_interface import register_calculator as ase_adapter

logger = logging.getLogger(__name__)


def _ase_to_openmm_topology(atoms: Atoms) -> app.Topology:
    """
    Converts an ASE Atoms object to an OpenMM Topology.
    Requires 'residuenames' and 'atomnames' in atoms.arrays for reliable forcefield matching.
    """
    topology = app.Topology()
    chain = topology.addChain()
    
    # Try to get chemical information from atoms.arrays
    res_names = atoms.arrays.get('residuenames')
    res_ids = atoms.arrays.get('residueids')
    atom_names = atoms.arrays.get('atomnames')
    
    if res_names is None:
        logger.warning("Missing atoms.arrays['residuenames']. Defaulting to 'MOL'.")
        res_names = np.array(['MOL'] * len(atoms), dtype='U3')
    
    if atom_names is None:
        logger.warning("Missing atoms.arrays['atomnames']. Using chemical symbols. This may fail template matching!")
        atom_names = atoms.symbols
    else:
        logger.info(f"Using provided atomnames: {atom_names[:5]}...")
        
    current_key = None
    current_res_obj = None
    
    om_atoms = []
    
    for i in range(len(atoms)):
        rname = str(res_names[i])
        rid = int(res_ids[i]) if res_ids is not None else 0
        key = (rname, rid)
        
        # New residue if name or id changed
        if key != current_key:
            current_key = key
            current_res_obj = topology.addResidue(rname, chain, id=str(rid))
            
        sym = atoms.symbols[i]
        aname = str(atom_names[i])
        
        try:
            element = app.Element.getBySymbol(sym)
        except Exception:
            element = None
            
        atom_obj = topology.addAtom(aname, element, current_res_obj)
        om_atoms.append(atom_obj)
        
    # Infer bonds using ASE neighbor list (Fallback if connectivity is missing)
    # TODO: In the future, look for explicit connectivity in atoms.arrays
    from ase.neighborlist import neighbor_list
    from ase.data import covalent_radii
    
    ii, jj, dd = neighbor_list('ijd', atoms, 2.0)
    for i, j, d in zip(ii, jj, dd):
        if i < j:
            thresh = 1.25 * (covalent_radii[atoms.numbers[i]] + covalent_radii[atoms.numbers[j]])
            if d < thresh:
                topology.addBond(om_atoms[i], om_atoms[j])
                
    return topology


@ase_adapter
def openmm_protein_ligand_calculator(
    atoms: Atoms,
    forcefield_files: Optional[list[str]] = None,
    platform_name: str = "Reference",  # 'Reference', 'CPU', 'CUDA', 'OpenCL'
    nonbonded_method: str = "NoCutoff",  # 'NoCutoff', 'CutoffNonPeriodic', 'PME', etc.
    nonbonded_cutoff: float = 1.0,  # nm
    constraints: Optional[str] = "HBonds",  # None, 'HBonds', 'AllBonds', 'HAngles'
    rigid_water: bool = True,
    remove_com: bool = True,
    minimize: bool = True,
    minimize_max_iterations: int = 0,
    md_steps: int = 0,
    md_timestep_fs: float = 1.0,
    temperature_k: float = 300.0,
    friction_coeff: float = 1.0,  # ps^-1
    **kwargs,
) -> Atoms:
    """
    OpenMM-based calculator for protein-ligand systems.
    """
    if not OPENMM_AVAILABLE:
        raise ImportError("OpenMM is not installed. Please install it to use this calculator.")

    # Apply topological info if provided via kwargs (passed by the adapter)
    for key in ['atomnames', 'residuenames', 'residueids']:
        if key in kwargs:
            atoms.set_array(key, np.array(kwargs[key]))

    if forcefield_files is None:
        forcefield_files = ["amber14-all.xml", "amber14/tip3pfb.xml"]

    # 1. Setup ForceField
    ff = app.ForceField(*forcefield_files)

    # 2. Convert ASE to OpenMM Topology/Positions
    topology = _ase_to_openmm_topology(atoms)
    positions = atoms.get_positions() / 10.0 * u.nanometers

    # 3. Handle System creation
    nb_method_map = {
        "NoCutoff": app.NoCutoff,
        "CutoffNonPeriodic": app.CutoffNonPeriodic,
        "CutoffPeriodic": app.CutoffPeriodic,
        "Ewald": app.Ewald,
        "PME": app.PME,
        "LJPME": app.LJPME,
    }
    if nonbonded_method not in nb_method_map:
        raise ValueError(f"Unknown nonbonded_method: {nonbonded_method}. Available: {list(nb_method_map.keys())}")
    nb_method = nb_method_map[nonbonded_method]

    # Validate PBC for periodic methods
    is_periodic = nb_method in [app.CutoffPeriodic, app.Ewald, app.PME, app.LJPME]
    if is_periodic and not atoms.pbc.all():
        raise ValueError(f"Non-bonded method '{nonbonded_method}' requires periodic boundary conditions (atoms.pbc.all() must be True).")

    constraint_map = {
        "HBonds": app.HBonds,
        "AllBonds": app.AllBonds,
        "HAngles": app.HAngles,
        None: None,
        "None": None,
    }
    if constraints not in constraint_map:
        raise ValueError(f"Unknown constraints: {constraints}. Available: {list(constraint_map.keys())}")
    constraints_val = constraint_map[constraints]

    # Periodic Boundary Conditions
    if atoms.pbc.any():
        cell = atoms.get_cell()
        # OpenMM expects a, b, c vectors as Vec3 with units
        a, b, c = cell.array / 10.0  # Angstrom to nm
        topology.setPeriodicBoxVectors((
            openmm.Vec3(*a) * u.nanometers,
            openmm.Vec3(*b) * u.nanometers,
            openmm.Vec3(*c) * u.nanometers
        ))

    system = ff.createSystem(
        topology,
        nonbondedMethod=nb_method,
        nonbondedCutoff=nonbonded_cutoff * u.nanometers,
        constraints=constraints_val,
        rigidWater=rigid_water,
        removeCMMotion=remove_com,
    )

    # 4. Handle Fixed Atoms (ASE constraints)
    ase_constraints = atoms.constraints
    fixed_indices = set()
    for c in ase_constraints:
        if hasattr(c, 'index'):
            fixed_indices.update(c.index)
        elif hasattr(c, 'get_indices'):
            fixed_indices.update(c.get_indices())

    for idx in fixed_indices:
        system.setParticleMass(int(idx), 0.0 * u.amu)

    # 5. Integrator and Simulation
    integrator = openmm.LangevinIntegrator(
        temperature_k * u.kelvin,
        friction_coeff / u.picosecond,
        md_timestep_fs * u.femtoseconds,
    )

    try:
        platform = openmm.Platform.getPlatformByName(platform_name)
    except Exception:
        logger.warning(f"Platform '{platform_name}' not available. Falling back to Reference.")
        platform = openmm.Platform.getPlatformByName("Reference")

    simulation = app.Simulation(topology, system, integrator, platform)
    simulation.context.setPositions(positions)

    # 6. Execute Logic
    if minimize:
        simulation.minimizeEnergy(maxIterations=minimize_max_iterations)

    if md_steps > 0:
        simulation.step(md_steps)

    # 7. Extract Results
    state = simulation.context.getState(getPositions=True, getEnergy=True, getForces=True)
    
    # Update positions (nm to Angstrom)
    new_positions = state.getPositions(asNumpy=True).value_in_unit(u.angstrom)
    atoms.set_positions(new_positions)

    # Update energy (kJ/mol to eV)
    # 1 kJ/mol = 0.0103642697 eV
    kj_per_mol_to_ev = 0.0103642697
    energy_kj_mol = state.getPotentialEnergy().value_in_unit(u.kilojoules_per_mole)
    energy_ev = energy_kj_mol * kj_per_mol_to_ev
    
    # Calculate forces (kJ/mol/nm to eV/Angstrom)
    # kJ/mol/nm -> eV/Angstrom factor = 0.0103642697 / 10.0 = 0.00103642697
    force_conv = kj_per_mol_to_ev / 10.0
    forces_kj_mol_nm = state.getForces(asNumpy=True).value_in_unit(u.kilojoules_per_mole / u.nanometer)
    forces_ev_ang = forces_kj_mol_nm * force_conv
    
    # Store results in ASE standard locations
    atoms.info["energy"] = energy_ev
    atoms.arrays["forces"] = forces_ev_ang
    atoms.info["forces"] = forces_ev_ang # Also in info for the adapter to return it
    
    # Extra metadata
    atoms.info["openmm_potential_energy_kj_mol"] = energy_kj_mol

    return atoms


# Self-register in the global EZGA calculator registry
registry_register("openmm", cast(Any, openmm_protein_ligand_calculator))
