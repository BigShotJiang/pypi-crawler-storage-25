import torch 
import torch_sim as ts
from torch_sim.models.mace import MaceModel
from torch.nn.utils.rnn import pad_sequence
import numpy as np
from ase import Atoms
from typing import Any, Sequence, Callable, Optional, Union, cast

from batch_nl import NeighbourList


######## Monkey patch of batched NeighbourList / MaceModel ###############
def monkeypatch(device: str = 'cuda'):

    torch.set_default_device(device)

    def new_forward(  # noqa: C901
            self, state: ts.SimState
        ) -> dict[str, torch.Tensor]:
            sim_state = (
                state
                if isinstance(state, ts.SimState)
                else ts.SimState(**state, masses=torch.ones_like(state["positions"]))
            )

            if sim_state.atomic_numbers is None and not self.atomic_numbers_in_init:
                raise ValueError("Atomic numbers must be provided in either the constructor or forward.")
            if sim_state.atomic_numbers is not None and self.atomic_numbers_in_init:
                raise ValueError("Atomic numbers cannot be provided in both the constructor and forward.")

            if sim_state.system_idx is None:
                if not hasattr(self, "system_idx"):
                    raise ValueError("System indices must be provided if not set during initialization")
                sim_state.system_idx = self.system_idx

            if (
                sim_state.atomic_numbers is not None
                and not self.atomic_numbers_in_init
                and not torch.equal(
                    sim_state.atomic_numbers,
                    getattr(self, "atomic_numbers", torch.zeros(0, device=self.device)),
                )
            ):
                self.setup_from_system_idx(sim_state.atomic_numbers, sim_state.system_idx)

            wrapped_positions = (
                ts.transforms.pbc_wrap_batched(
                    sim_state.positions,
                    sim_state.cell,
                    sim_state.system_idx,
                    sim_state.pbc,
                )
                if sim_state.pbc.any()
                else sim_state.positions
            )

            nl = NeighbourList(
                positions=wrapped_positions,
                system_idx=sim_state.system_idx,
                cells=sim_state.row_vector_cell,
                cutoff=self.r_max,
                device=self.device,
            )
            nl.load_data()
            edge_index, unit_shifts, shifts, d, mapping_system  = nl.calculate_neighbourlist(use_torch_compile=True)

            data_dict = dict(
                ptr=self.ptr,
                node_attrs=self.node_attrs,
                batch=sim_state.system_idx,
                pbc=sim_state.pbc,
                cell=sim_state.row_vector_cell,
                positions=wrapped_positions,
                edge_index=edge_index,
                unit_shifts=unit_shifts,
                shifts=shifts,
                total_charge=sim_state.charge,
                total_spin=sim_state.spin,
            )

            out = self.model(
                data_dict,
                compute_force=self.compute_forces,
                compute_stress=self.compute_stress,
            )

            results: dict[str, torch.Tensor] = {}
            energy = out["energy"]
            if energy is not None:
                results["energy"] = energy.detach()
            else:
                results["energy"] = torch.zeros(self.n_systems, device=self.device)

            if self.compute_forces:
                forces = out["forces"]
                if forces is not None:
                    results["forces"] = forces.detach()

            if self.compute_stress:
                stress = out["stress"]
                if stress is not None:
                    results["stress"] = stress.detach()

            return results


    def new__init__(self,
        positions: torch.Tensor,
        system_idx: torch.Tensor,
        cells: torch.Tensor,
        cutoff: float,
        float_dtype: torch.dtype = torch.float32,
        device: str | torch.device | None = None,
        ):
        self.positions = positions
        self.batch_cell_tensor = cells
        self.system_idx = system_idx
        sys, self.len_sys = torch.unique(self.system_idx, sorted=True, return_counts=True)
        self.num_configs = len(sys)
        if self.num_configs != cells.shape[0]:
            raise ValueError(f"number of configs and cell lists should be the same, got num_configs = {self.num_configs} and len(cell_list) = {cells.shape[0]}")
        self.float_dtype = float_dtype
        self.int_dtype = torch.int64
        self.cutoff = torch.as_tensor(cutoff, dtype=self.float_dtype)
        
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)
            
        self._tolerance = 1e-6
        self._nlist_ON2_compiled = torch.compile(self._nlist_ON2)


    def new_load_data(self):
            positions_list = torch.split(self.positions, tuple(self.len_sys)) 
            self.batch_positions_tensor = pad_sequence(
                positions_list,
                batch_first=True,
                padding_value=float("nan"),
            )
            self.batch_mask_tensor = (self.batch_positions_tensor == self.batch_positions_tensor).any(dim=-1)
            self.batch_positions_tensor = torch.nan_to_num(self.batch_positions_tensor, nan=0)


    def new_calculate_neighbourlist(self, use_torch_compile: bool = True):
        neighbourlist_fn = self._nlist_ON2_compiled if use_torch_compile else self._nlist_ON2
        (
            distance_matrix,
            criterion,
            batch_lattice_shifts_tensor,
            batch_cartesian_lattice_shifts_tensor,
        ) = neighbourlist_fn(
            self.batch_positions_tensor,
            self.batch_cell_tensor,
            self.batch_mask_tensor,
            self.cutoff,
            self._tolerance,
        )
        config_idx, lattice_shift_idx, atom_idx, neighbour_idx = torch.nonzero(criterion, as_tuple=True)
        lengths = self.batch_mask_tensor.sum(dim=-1, dtype=self.int_dtype)
        offsets = torch.cumsum(lengths, dim=0) - lengths
        r_edges = torch.stack([atom_idx + offsets[config_idx], neighbour_idx + offsets[config_idx]], dim=0)
        r_integer_lattice_shifts = batch_lattice_shifts_tensor[lattice_shift_idx]
        r_cartesian_lattice_shifts = batch_cartesian_lattice_shifts_tensor[config_idx, lattice_shift_idx]
        r_distances = distance_matrix[config_idx, lattice_shift_idx, atom_idx, neighbour_idx]
        return (r_edges, r_integer_lattice_shifts.to(dtype=self.float_dtype), r_cartesian_lattice_shifts, r_distances, config_idx)


    NeighbourList.__init__ = new__init__
    NeighbourList.load_data = new_load_data
    NeighbourList.calculate_neighbourlist = new_calculate_neighbourlist
    MaceModel.forward = new_forward


def mace_torchsim(
    mace_model_file: str,
    device: str = 'cuda',
    dtype: torch.dtype = torch.float64,
    max_force: float = 0.05,
    max_steps: int = 1000,
    fix_fn = None,
    CUDA_avail = False
    ):

    if not CUDA_avail:
        print('Applying TorchSim monkeypatch for batch optimization...')
        monkeypatch(device=device)
    
    mace = torch.load(mace_model_file, map_location=device)
    model = MaceModel(model=mace, device=device, dtype=dtype, compute_stress=False, compute_forces=True)

    def run(
        atoms: list[Atoms],
        atom_mask: Optional[torch.Tensor] = None,
        )-> list[Atoms]:
        
        state = ts.state.initialize_state(atoms,device=device,dtype=torch.float64)
        
        if atom_mask is not None:
            state.constraints = [ts.constraints.FixAtoms(atom_mask=atom_mask.to(device=device))]
        elif fix_fn is not None:
            state.constraints = [ts.constraints.FixAtoms(atom_mask= fix_fn(state.positions).to(device=device))]

        relaxed_state = ts.optimize(
                        system=state,
                        model=model,
                        convergence_fn=ts.runners.generate_force_convergence_fn(force_tol=max_force),
                        max_steps=max_steps,
                        optimizer=ts.Optimizer.fire,
                        autobatcher=False,
                        init_kwargs=None,
                        )
    
        for i, val in enumerate(relaxed_state):
            atoms[i].set_positions(val.positions.to('cpu').numpy())
            atoms[i].info['energy']=float(val.energy.to('cpu'))
            atoms[i].arrays['forces']=val.forces.to('cpu').numpy()

        return atoms
    
    return run


# =============================================================================
# EZGA Wrapper & Constraint Adapter
# =============================================================================

class _APMAdapter:
    def __init__(self, symbols, positions, cell, atomic_constraints=None):
        self.atomPositions = np.asarray(positions, float)
        self.atomLabelsList = np.asarray(symbols, dtype=object)
        _cell = np.asarray(cell, float) if cell is not None else None
        self.latticeVectors = _cell if (_cell is not None and _cell.shape == (3,3)) else np.eye(3)
        self.atomicConstraints = np.asarray(atomic_constraints, bool) if atomic_constraints is not None else None
        self.atomCount = len(self.atomPositions)

class _StructAdapter:
    def __init__(self, symbols, positions, cell, atomic_constraints=None):
        self.AtomPositionManager = _APMAdapter(symbols, positions, cell, atomic_constraints)

def _to_pred_list(preds: Optional[Union[Callable, Sequence[Callable]]]) -> list[Callable]:
    if preds is None: return []
    if callable(preds): return [preds]
    return list(preds)

def _evaluate_predicates(idx: int, structure: _StructAdapter, constraints: list[Callable], logic: str = "all") -> bool:
    if not constraints: return False
    if logic == "all": return all(c(idx, structure) for c in constraints)
    if logic == "any": return any(c(idx, structure) for c in constraints)
    return False

def mace_torch_calculator(
    model_path: str,
    device: str = "cuda",
    dtype: torch.dtype = torch.float64,
    fmax: float = 0.05,
    steps_max: int = 1000,
    # --- Constraint controls (matching ase_calculator) ---
    constraint_logic: str = "all",
    constraint_action: str = "freeze",
    constraints: Optional[Sequence[Callable]] = None,
    **kwargs
) -> Callable:
    """
    EZGA factory for MACE-TorchSim batched calculator.
    """
    cuda_avail = (device == 'cuda' and torch.cuda.is_available())
    factory_constraints = _to_pred_list(constraints)
    
    _runner = mace_torchsim(
        mace_model_file=model_path,
        device=device,
        dtype=dtype,
        max_force=fmax,
        max_steps=steps_max,
        CUDA_avail=cuda_avail
    )

    def run(
        symbols: Union[np.ndarray, list[np.ndarray]],
        positions: Union[np.ndarray, list[np.ndarray]],
        cell: Union[np.ndarray, None, list[Optional[np.ndarray]]],
        *,
        fixed: Union[np.ndarray, None, list[Optional[np.ndarray]]] = None,
        constraints: Optional[Sequence[Callable]] = None, # run-level constraints
        output_filename: Union[str, list[str]] = "MD_out.xyz",
        **run_kwargs
    ) -> Any:
        
        is_batch = isinstance(symbols, list)
        
        input_symbols = cast(list[Any], symbols if is_batch else [symbols])
        input_positions = cast(list[Any], positions if is_batch else [positions])
        input_cells = cast(list[Any], cell if is_batch else [cell])
        input_fixed = cast(list[Any], fixed if is_batch else [fixed])
        
        batch_atoms = []
        all_masks = []
        
        # Combine factory + call-level predicates
        combined_preds = factory_constraints + _to_pred_list(constraints)
        
        for i in range(len(input_symbols)):
            sym, pos, c, fix = input_symbols[i], input_positions[i], input_cells[i], input_fixed[i]
            pbc = (c is not None and np.any(c))
            batch_atoms.append(Atoms(symbols=sym, positions=pos, cell=c, pbc=pbc))
            
            # 1. Selection
            N = len(sym)
            adapter = _StructAdapter(sym, pos, c, fix)
            
            if combined_preds:
                # Get booleans for which atoms satisfy the predicates
                pred_satisfied = [
                    _evaluate_predicates(j, adapter, combined_preds, logic=constraint_logic) 
                    for j in range(N)
                ]
                
                # 2. Action (freeze selection vs freeze complement)
                if constraint_action == "freeze":
                    m = pred_satisfied
                else: # "move_only" -> freeze those that do NOT satisfy predicates
                    m = [not b for b in pred_satisfied]
                
                all_masks.append(torch.tensor(m, dtype=torch.bool, device=device))
            else:
                all_masks.append(torch.zeros(N, dtype=torch.bool, device=device))

        # 3. Concatenate masks for GPU batching
        global_mask = torch.cat(all_masks) if all_masks else None
        
        # 4. Execute GPU runner
        relaxed_atoms = _runner(batch_atoms, atom_mask=global_mask)
        
        results = []
        for at in relaxed_atoms:
            results.append((
                at.get_positions(),
                at.get_chemical_symbols(),
                at.get_cell().array if at.pbc.any() else None,
                at.info.get('energy', 0.0),
                {'forces': at.arrays.get('forces')}
            ))
            
        return results if is_batch else results[0]

    setattr(run, "is_batch", True)
    return run
