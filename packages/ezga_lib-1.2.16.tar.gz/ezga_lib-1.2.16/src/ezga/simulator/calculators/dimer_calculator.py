"""Factory module for Dimer search exploration calculators from random starting points.

This module provides a factory function to generate calculator instances that
perform random Dimer searches to find transition states (TS).
It follows the pattern of `reactivity_calculator`, returning a list of discovered structures.

Typical usage example:

    from ezga.simulator.calculators.dimer_calculator import dimer_calculator

    calc_func = dimer_calculator(
        calc_path="mpa-0-medium",
        num_attempts=5,
        dimer_fmax=0.05
    )
"""

from __future__ import annotations

import copy
import logging
import os
from collections.abc import Callable, Sequence
from typing import Any

import ase.io
import numpy as np
from ase import Atoms
from ase.constraints import FixAtoms, FixCartesian
from ase.mep import DimerControl, MinModeAtoms, MinModeTranslate
from ase.vibrations import Vibrations
import shutil
from ase.optimize import FIRE

# Shared utilities (MACE support, etc.)
from ezga.simulator.mace_utils import (
    assert_license_ok,
    download_if_needed,
    resolve_model_spec,
)

# Configure module-level logger
logger = logging.getLogger(__name__)

# Type alias for EZGA Simulator return format
CalcResult = tuple[
    np.ndarray,  # Positions
    np.ndarray,  # Symbols
    np.ndarray | None,  # Cell
    float,  # Energy
    dict[str, Any],  # Metadata
]


# =============================================================================
# Helper Functions (Constraints, etc., shared logic pattern)
# =============================================================================
def _to_pred_list(preds: Sequence[Callable] | None) -> list:
    if preds is None:
        return []
    if callable(preds):
        return [preds]
    try:
        return list(preds)
    except TypeError:
        return [preds]


class _StructAdapter:
    class _APM:
        def __init__(self, symbols, positions, cell, constraints):
            self.atomPositions = np.asarray(positions, float)
            self.atomLabelsList = np.asarray(symbols, dtype=object)
            self.latticeVectors = np.asarray(cell, float) if cell is not None else np.eye(3)
            self.atomicConstraints = constraints
            self.atomCount = len(symbols)

    def __init__(self, symbols, positions, cell, atomic_constraints=None):
        self.AtomPositionManager = self._APM(symbols, positions, cell, atomic_constraints)
        self.atomPositions = self.AtomPositionManager.atomPositions
        self.atomLabelsList = self.AtomPositionManager.atomLabelsList
        self.latticeVectors = self.AtomPositionManager.latticeVectors


def _evaluate(idx: int, structure: _StructAdapter, constraints: Sequence[Callable], logic: str = "all") -> bool:
    if not constraints:
        return False
    if logic == "all":
        return all(c(idx, structure) for c in constraints)
    if logic == "any":
        return any(c(idx, structure) for c in constraints)
    raise ValueError("logic must be 'all' or 'any'")


def _select_indices(symbols, positions, cell, fixed, constraints, logic="all") -> np.ndarray:
    N = len(symbols)
    adapter = _StructAdapter(symbols, positions, cell, fixed)
    return np.asarray([i for i in range(N) if _evaluate(i, adapter, constraints, logic)], dtype=int)


def _build_ase_constraints(
    atoms: Atoms,
    selected: np.ndarray,
    action: str,
    freeze_components: Sequence[int | str] | None,
):
    N = len(atoms)
    selected = np.unique(selected) if selected.size > 0 else np.array([], dtype=int)

    if action == "freeze":
        target = selected
    elif action == "move_only":
        mask = np.ones(N, dtype=bool)
        mask[selected] = False
        target = np.where(mask)[0]
    else:
        raise ValueError("action must be 'freeze' or 'move_only'")

    if len(target) == 0:
        return None

    if freeze_components is None:
        return FixAtoms(indices=target)
    else:
        # Resolve 'x','y','z' -> 0,1,2
        comp_map = {"x": 0, "y": 1, "z": 2, 0: 0, 1: 1, 2: 2}
        comps = [comp_map[c] if isinstance(c, str) else c for c in freeze_components]
        
        mask_3 = [False, False, False]
        for c in comps:
            mask_3[c] = True
            
        return FixCartesian(a=list(target), mask=mask_3)


def _package_result(atoms: Atoms, metadata: dict[str, Any]) -> CalcResult:
    try:
        energy = float(atoms.get_potential_energy())
    except Exception:
        energy = float("nan")
    cell = np.array(atoms.get_cell()) if atoms.pbc.any() else None
    return (
        np.array(atoms.get_positions()),
        np.array(atoms.get_chemical_symbols()),
        cell,
        energy,
        copy.deepcopy(metadata),
    )


def _build_atoms_obj(symbols, positions, cell, calc_factory):
    atoms = Atoms(symbols=symbols, positions=positions, cell=cell, pbc=(cell is not None))
    atomic_calc = calc_factory() if callable(calc_factory) else copy.deepcopy(calc_factory)
    atoms.calc = atomic_calc
    return atoms


# =============================================================================
# Dimer Calculator Factory
# =============================================================================


def dimer_calculator(
    calculator_factory: Callable[[], object] | object | None = None,
    # --- Dimer / Exploration Params ---
    num_attempts: int = 5,
    root_fmax: float = 0.02,
    dimer_fmax: float = 0.05,
    dimer_steps: int = 200,
    write_trajectories: bool = True,
    # Disorder Params
    atoms_to_displace: int = 1,  # Number of atoms to displace per attempt
    displacement_range: tuple[float, float] = (-0.15, 0.15),
    selection_mode: str = "random",  # 'random' or 'force'
    adaptive_displacement: bool = True,
    early_stop_steps: int = 0,  # if >0, stop if curvature stays positive
    # --- Constraint Params ---
    constraint_logic: str = "all",
    constraint_action: str = "freeze",
    freeze_components: Sequence[int | str] | None = None,
    constraints: Sequence[Callable] | None = None,
    # --- Verification & Refinement ---
    use_sella: bool = False,
    run_irc: bool = False,
    verify_saddle: bool = True,
    vibration_delta: float = 0.01,
    # --- MACE Arguments ---
    calc_path: str | None = None,
    device: str = "cuda",
    default_dtype: str = "float32",
    allow_asl: bool = False,
    cache_dir: str | None = None,
) -> Callable[..., list[CalcResult]]:
    """
    Builds a callable that runs random Dimer searches with advanced refinement.

    Workflow per attempt:
      1. Relax root structure (if root_fmax > 0).
      2. Select atoms (randomly or based on force/coordination).
      3. Displace (optionally adaptive based on failure/success).
      4. Run ASE Dimer (MinModeTranslate).
      5. Optionally refine with Sella for tighter TS convergence.
      6. Optionally verify with IRC-light (descent in both directions).
      7. Verify saddle character (curvature + vibrations).
    """

    # --- Handle Calculator Source ---
    if calculator_factory is None:
        if calc_path is None:
            raise ValueError("Must provide either `calculator_factory` or `calc_path`.")
        name, license_tag, url_or_path = resolve_model_spec(calc_path)
        assert_license_ok(license_tag, allow_asl=allow_asl)
        model_local_path = download_if_needed(url_or_path, cache_root=cache_dir)

        from mace.calculators.mace import MACECalculator
        
        # Instantiate once at the factory level so it persists across all calls to run()
        mace_instance = MACECalculator(model_paths=model_local_path, device=device, default_dtype=default_dtype)

        def _mace_factory():
            return mace_instance

        calculator_factory = _mace_factory

    factory_constraints = _to_pred_list(constraints)

    def run(
        symbols: Sequence[str],
        positions: np.ndarray,
        cell: np.ndarray | None,
        fixed: np.ndarray | None = None,
        parent_hash: str = "root",
        output_filename: str = "dimer_out.xyz",
        constraints: Sequence[Callable] | None = None,
        **kwargs,
    ) -> list[CalcResult]:

        discovered: list[CalcResult] = []

        # 1. Setup Root
        # Instantiate calculator once for this run to avoid reloading models (especially for MACE/GPU)
        shared_calc = calculator_factory() if callable(calculator_factory) else copy.deepcopy(calculator_factory)

        try:
            root = Atoms(symbols=symbols, positions=positions, cell=cell, pbc=(cell is not None))
            root.calc = shared_calc
        except Exception as e:
            logger.error(f"Failed to build root atoms: {e}")
            return []

        # Constraints
        comb_constraints = list(factory_constraints) + _to_pred_list(constraints)

        # Determine selection for constraints
        if comb_constraints:
            selected_idxs = _select_indices(symbols, positions, cell, fixed, comb_constraints, constraint_logic)
        elif fixed is not None and np.any(fixed):
            selected_idxs = np.where(np.asarray(fixed).flatten())[0]
        else:
            selected_idxs = np.array([], dtype=int)
        
        # Apply ASE constraints
        ase_cons = _build_ase_constraints(root, selected_idxs, constraint_action, freeze_components)
        if ase_cons:
            root.set_constraint(ase_cons)

        # Identify free (moveable) atoms for displacement
        N = len(root)
        if ase_cons:
            if constraint_action == "freeze":
                frozen_set = set(selected_idxs)
                free_indices = [i for i in range(N) if i not in frozen_set]
            else:  # move_only
                free_indices = [i for i in selected_idxs]
        else:
            free_indices = list(range(N))

        if not free_indices:
            logger.warning("No free atoms to displace for Dimer search.")
            return []

        # Relax Root
        if root_fmax > 0:
            try:
                opt = FIRE(root, logfile=None)
                opt.run(fmax=root_fmax, steps=100)
            except Exception:
                pass

        discovered.append(_package_result(root, {"type": "initial_minima", "hash": parent_hash}))

        # 2. Loop Attempts
        current_range = list(displacement_range)
        
        for i in range(num_attempts):
            image = root.copy()
            image.calc = shared_calc
            if ase_cons:
                image.set_constraint(ase_cons)

            # Selection Logic
            n_disp = min(atoms_to_displace, len(free_indices))
            if n_disp <= 0:
                continue

            if selection_mode == "force":
                f_norms = np.linalg.norm(root.get_forces(), axis=1)
                free_forces = f_norms[free_indices]
                # Pick indices with highest forces
                top_indices = np.argsort(free_forces)[-n_disp:]
                target_indices = np.array(free_indices)[top_indices]
            else:
                target_indices = np.random.choice(free_indices, size=n_disp, replace=False)

            # Displacement mask for DimerControl
            dimer_mask = [0] * N
            disp_vector = np.zeros((N, 3))
            
            for idx in target_indices:
                dimer_mask[idx] = 1
                dx = np.random.uniform(current_range[0], current_range[1])
                dy = np.random.uniform(current_range[0], current_range[1])
                dz = np.random.uniform(current_range[0], current_range[1])
                
                pos = image.get_positions()
                pos[idx] += [dx, dy, dz]
                image.set_positions(pos)
                disp_vector[idx] = [dx, dy, dz]

            # Dimer Run
            try:
                d_control = DimerControl(
                    initial_eigenmode_method="displacement",
                    displacement_method="vector",
                    logfile=None,
                    mask=dimer_mask,
                )
                d_atoms = MinModeAtoms(image, d_control)
                d_atoms.displace(displacement_vector=disp_vector)

                dimer_relax = MinModeTranslate(d_atoms, logfile=None)

                # Early Stopping Observer
                if early_stop_steps > 0:
                    class EarlyStop:
                        def __init__(self, opt, limit):
                            self.opt = opt
                            self.limit = limit
                            self.count = 0
                        def __call__(self):
                            if self.opt.atoms.get_curvature() > 0:
                                self.count += 1
                            else:
                                self.count = 0
                            if self.count >= self.limit:
                                raise RuntimeError("Early stop: Curvature positive for too long.")
                    dimer_relax.attach(EarlyStop(dimer_relax, early_stop_steps), interval=1)

                if write_trajectories:
                    base, _ = os.path.splitext(output_filename)
                    traj_file = f"{base}_dimer_{i}.xyz"
                    out_dir = os.path.dirname(traj_file)
                    if out_dir and not os.path.exists(out_dir):
                        os.makedirs(out_dir, exist_ok=True)
                    if os.path.exists(traj_file):
                        os.remove(traj_file)
                    def _xyz_observer():
                        ase.io.write(traj_file, image, append=True, format="extxyz")
                    dimer_relax.attach(_xyz_observer, interval=1)

                converged = dimer_relax.run(fmax=dimer_fmax, steps=dimer_steps)
                
                # Sella Refinement
                # Sella Refinement
                if use_sella:
                    try:
                        from sella import Sella
                        # Order 1 for TS search
                        dyn = Sella(image, order=1, logfile="-")
                        converged = dyn.run(fmax=dimer_fmax, steps=50)
                    except ImportError:
                        logger.warning("Sella requested but not installed. Skipping refinement.")

                max_f = float(np.max(np.linalg.norm(image.get_forces(), axis=1)))
                curvature = d_atoms.get_curvature()

                # --- Verification & IRC Light ---
                n_imag = 1
                irc_ok = True
                
                if verify_saddle:
                    active_indices = list(target_indices)
                    vib_name = f"vib_{parent_hash}_{i}"
                    try:
                        vib = Vibrations(image, indices=active_indices, delta=vibration_delta, name=vib_name)
                        vib.run()
                        freqs = vib.get_frequencies()
                        n_imag = sum(1 for f in freqs if abs(f.imag) > 1e-5)
                        vib.clean()
                        for f in [f"{vib_name}.json", f"{vib_name}.pckl"]:
                            if os.path.exists(f): os.remove(f)
                    except Exception as ve:
                        logger.warning(f"Vibrational analysis failed for attempt {i}: {ve}")
                        n_imag = 1 if curvature < -0.05 else 0

                    if run_irc and n_imag == 1:
                        # Simple IRC Light: descend in both directions of the mode
                        mode = d_atoms.get_eigenmode()
                        ts_pos = image.get_positions()
                        
                        def relax_dir(direction):
                            test_atoms = image.copy()
                            test_atoms.calc = shared_calc
                            test_atoms.set_positions(ts_pos + direction * 0.1)
                            opt = FIRE(test_atoms, logfile=None)
                            opt.run(fmax=dimer_fmax * 2, steps=20)
                            return test_atoms.get_potential_energy()
                        
                        e_plus = relax_dir(mode)
                        e_minus = relax_dir(-mode)
                        e_ts = image.get_potential_energy()
                        # If both directions lead to lower energy, it's a good TS candidate
                        irc_ok = (e_plus < e_ts) and (e_minus < e_ts)

                    is_valid_ts = (curvature < 0) and (n_imag == 1) and (max_f < dimer_fmax * 1.5) and irc_ok
                    
                    if not is_valid_ts:
                        logger.info(f"Dimer attempt {i} rejected: curvature={curvature:.4f}, n_imag={n_imag}, irc_ok={irc_ok}")
                        # Adaptive Displacement: Increase range on failure
                        if adaptive_displacement:
                            current_range[0] -= 0.05
                            current_range[1] += 0.05
                        continue

                # Save result
                res_meta = {
                    "type": "dimer_saddle",
                    "converged": bool(converged),
                    "fmax": max_f,
                    "parent": parent_hash,
                    "attempt": i,
                    "displaced_atoms": target_indices.tolist(),
                    "curvature": float(curvature),
                    "n_imag": int(n_imag),
                    "irc_ok": bool(irc_ok),
                }
                discovered.append(_package_result(image, res_meta))
                
                # Success! Reset range to original if adaptive
                if adaptive_displacement:
                    current_range = list(displacement_range)

            except Exception as e:
                logger.warning(f"Dimer attempt {i} failed: {e}")
                if adaptive_displacement:
                    current_range[0] -= 0.05
                    current_range[1] += 0.05
                continue

        return discovered

    return run
