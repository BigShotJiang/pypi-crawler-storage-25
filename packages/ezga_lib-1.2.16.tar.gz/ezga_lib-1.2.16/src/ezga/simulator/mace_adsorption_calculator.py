from __future__ import annotations

import os
from collections.abc import Callable, Sequence
from typing import Any

import numpy as np

from .mace_calculator import mace_calculator

# =============================================================================
# Types
# =============================================================================

CalculationResult = tuple[np.ndarray, np.ndarray, np.ndarray | None, float, dict[str, Any]]


# =============================================================================
# Utilities
# =============================================================================


def _as_bool_mask(indices_or_mask, n_atoms: int, name: str) -> np.ndarray:
    """
    Normalize ligand/MM selection to a boolean mask of shape (N,).
    Accepts:
      - boolean mask of length N
      - integer indices
      - list/tuple/np.ndarray of indices
    """
    arr = np.asarray(indices_or_mask)

    if arr.dtype == bool:
        if arr.shape != (n_atoms,):
            raise ValueError(f"{name} boolean mask must have shape ({n_atoms},)")
        return arr.copy()  # type: ignore

    mask = np.zeros(n_atoms, dtype=bool)
    idx = np.asarray(arr, dtype=int).ravel()
    oob = idx[(idx < 0) | (idx >= n_atoms)]
    if oob.size > 0:
        raise ValueError(
            f"{name} contains invalid atom indices. Max index allowed: {n_atoms - 1}. Offending indices: {oob[:10]}"
        )
    mask[idx] = True
    return mask


def _minimum_image_displacement(vecs: np.ndarray, cell: np.ndarray | None, pbc: bool) -> np.ndarray:
    """
    Apply minimum-image convention to displacement vectors.
    """
    if (not pbc) or cell is None:
        return vecs

    # Robust cell check
    c_arr = np.asarray(cell)
    if c_arr.ndim != 2 or c_arr.shape != (3, 3):
        return vecs

    if np.all(np.abs(c_arr) < 1e-8):
        return vecs

    inv_cell = np.linalg.inv(c_arr.T)
    frac = vecs @ inv_cell
    frac -= np.round(frac)
    return frac @ c_arr  # type: ignore


def _pairwise_min_distance(
    A: np.ndarray,
    B: np.ndarray,
    cell: np.ndarray | None,
    pbc: bool,
) -> np.ndarray:
    """
    For each atom in A, compute min distance to any atom in B.
    Returns shape (len(A),)
    """
    if len(B) == 0:
        return np.full(len(A), np.inf, dtype=float)

    dmins = np.empty(len(A), dtype=float)
    for i, a in enumerate(A):
        disp = B - a
        disp = _minimum_image_displacement(disp, cell, pbc)
        d2 = np.sum(disp * disp, axis=1)
        dmins[i] = np.sqrt(np.min(d2))
    return dmins


def _crop_mm_around_ligand(
    symbols: Sequence[str],
    positions: np.ndarray,
    cell: np.ndarray | None,
    ligand_mask: np.ndarray,
    mm_mask: np.ndarray,
    cutoff: float,
    pbc: bool,
    include_buffer_indices: Sequence[int] | None = None,
) -> np.ndarray:
    """
    Returns a boolean mask selecting the cropped MM atoms:
    MM atoms within `cutoff` Å of any ligand atom.

    Optional include_buffer_indices can force inclusion of some atoms.
    """
    positions = np.asarray(positions, dtype=float)

    lig_pos = positions[ligand_mask]
    mm_idx = np.where(mm_mask)[0]
    mm_pos = positions[mm_mask]

    if lig_pos.shape[0] == 0:
        raise ValueError("Ligand selection is empty")
    if mm_pos.shape[0] == 0:
        raise ValueError("Macromolecule selection is empty")

    dmins = _pairwise_min_distance(mm_pos, lig_pos, cell=cell, pbc=pbc)
    keep_mm_local = dmins <= float(cutoff)

    mm_crop_mask = np.zeros(len(symbols), dtype=bool)
    mm_crop_mask[mm_idx[keep_mm_local]] = True

    if include_buffer_indices is not None:
        extra = np.asarray(include_buffer_indices, dtype=int).ravel()
        if np.any(extra < 0) or np.any(extra >= len(symbols)):
            raise ValueError("include_buffer_indices contains invalid atom indices")
        mm_crop_mask[extra] = True

    return mm_crop_mask


def _subset_atoms(
    symbols: Sequence[str],
    positions: np.ndarray,
    cell: np.ndarray | None,
    subset_mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    """
    Build subset arrays and return:
      sub_symbols, sub_positions, sub_cell, global_indices
    """
    idx = np.where(subset_mask)[0]
    return (
        np.asarray(symbols, dtype=object)[idx],
        np.asarray(positions, dtype=float)[idx],
        None if cell is None else np.asarray(cell, dtype=float),
        idx,
    )


def _build_frozen_mask_for_complex(
    complex_global_indices: np.ndarray,
    mm_crop_global_mask: np.ndarray,
) -> np.ndarray:
    """
    In the complex subsystem:
      - MM cropped atoms are frozen
      - ligand atoms are mobile
    """
    frozen = np.zeros(len(complex_global_indices), dtype=bool)
    for i, g in enumerate(complex_global_indices):
        if mm_crop_global_mask[g]:
            frozen[i] = True
    return frozen


def _freeze_mask_to_constraint_predicates(frozen_mask: np.ndarray):
    """
    Convert a frozen mask in subsystem indexing into predicate callables
    compatible with your existing ase_calculator constraint interface.
    """
    frozen_set = set(np.where(frozen_mask)[0].tolist())

    def _pred(idx, structure):
        return idx in frozen_set

    return [_pred]


# =============================================================================
# Main calculator factory
# =============================================================================


def mace_adsorption_calculator(
    calc_path: str = "MACE_model.model",
    device: str = "cuda",
    default_dtype: str = "float64",
    enable_cueq: bool = False,
    # --- crop controls ---
    crop_cutoff: float = 3.0,
    allow_empty_crop: bool = False,
    include_buffer_indices: Sequence[int] | None = None,
    # --- shared pipeline controls ---
    nvt_steps: int | Sequence[float] | None = None,
    fmax: float | Sequence[float] | None = 0.05,
    steps_max: int = 0,
    hydrostatic_strain: bool = False,
    constant_volume: bool = True,
    optimizer: str = "FIRE",
    T: float | Sequence[float] = 300.0,
    T_ramp: bool = False,
    md_timestep_fs: float = 1.0,
    vib_correction: bool = False,
    vib_store_interval: int = 1,
    vib_min_samples: int = 200,
    remove_com_drift: bool = False,
    mass_weighted_com: bool = True,
    vacf_window: str = "hann",
    log_interval: int = 0,
    write_interval: int = 0,
    # pre-relax
    pre_relax_fmax: float | Sequence[float] | None = None,
    pre_relax_steps_max: int = 0,
    pre_relax_optimizer: str = "FIRE",
    pre_relax_constant_volume: bool = True,
    pre_relax_hydrostatic_strain: bool = False,
    pre_relax_with_constraints: bool = True,
    # vib spectrum
    vib_spectrum: bool = False,
    vib_spectrum_max_lag: int | None = None,
    vib_spectrum_cutoff_cm1: float = 3200.0,
    vib_spectrum_mode: str = "total",
    # mace model controls
    allow_asl: bool = False,
    cache_dir: str | None = None,
):
    """
    Factory that returns a run(...) function for adsorption energy evaluation
    using a cropped macromolecule and a MACE backend.

    For each pose:
        E_ads = E(complex_crop) - E(mm_crop) - E(ligand)

    Rules:
      - Crop depends on the current pose.
      - MM cropped atoms are frozen in the complex calculation.
      - MM cropped atoms are also frozen in the MM-only calculation.
      - Ligand-only calculation is done separately for the ligand pose/conformation.
    """

    # Base MACE pipeline callable from your existing implementation
    base_runner = mace_calculator(
        calc_path=calc_path,
        device=device,
        default_dtype=default_dtype,
        enable_cueq=enable_cueq,
        nvt_steps=nvt_steps,
        fmax=fmax,
        steps_max=steps_max,
        hydrostatic_strain=hydrostatic_strain,
        constant_volume=constant_volume,
        optimizer=optimizer,
        T=T,
        T_ramp=T_ramp,
        md_timestep_fs=md_timestep_fs,
        vib_correction=vib_correction,
        vib_store_interval=vib_store_interval,
        vib_min_samples=vib_min_samples,
        remove_com_drift=remove_com_drift,
        mass_weighted_com=mass_weighted_com,
        vacf_window=vacf_window,
        log_interval=log_interval,
        write_interval=write_interval,
        constraint_logic="all",
        constraint_action="freeze",
        freeze_components=None,
        constraints=None,
        pre_relax_fmax=pre_relax_fmax,
        pre_relax_steps_max=pre_relax_steps_max,
        pre_relax_optimizer=pre_relax_optimizer,
        pre_relax_constant_volume=pre_relax_constant_volume,
        pre_relax_hydrostatic_strain=pre_relax_hydrostatic_strain,
        pre_relax_with_constraints=pre_relax_with_constraints,
        vib_spectrum=vib_spectrum,
        vib_spectrum_max_lag=vib_spectrum_max_lag,
        vib_spectrum_cutoff_cm1=vib_spectrum_cutoff_cm1,
        vib_spectrum_mode=vib_spectrum_mode,
        allow_asl=allow_asl,
        cache_dir=cache_dir,
    )

    def run(
        symbols: np.ndarray | Sequence[str],
        positions: np.ndarray,
        cell: np.ndarray | None,
        *,
        ligand_indices: Sequence[int] | np.ndarray,
        mm_indices: Sequence[int] | np.ndarray | None = None,
        fixed: np.ndarray | None = None,
        sampling_temperature: float = 0.0,
        steps_max_: int = steps_max,
        output_filename: str = "adsorption_pose.xyz",
        constraints: Sequence[Callable] | None = None,
        crop_cutoff_: float | None = None,
        **kwargs,
    ) -> CalculationResult:
        try:
            return _run_safe(
                symbols=symbols,
                positions=positions,
                cell=cell,
                ligand_indices=ligand_indices,
                mm_indices=mm_indices,
                fixed=fixed,
                sampling_temperature=sampling_temperature,
                steps_max_=steps_max_,
                output_filename=output_filename,
                constraints=constraints,
                crop_cutoff_=crop_cutoff_,
                **kwargs,
            )
        except Exception as e:
            # Global fault tolerance: if anything fails, return penalty
            return np.asarray(positions), np.asarray(symbols), cell, 1.0e6, {"error": str(e)}

    def _run_safe(
        symbols,
        positions,
        cell,
        ligand_indices,
        mm_indices,
        fixed,
        sampling_temperature,
        steps_max_,
        output_filename,
        constraints,
        crop_cutoff_,
        **kwargs,
    ) -> CalculationResult:

        symbols = np.asarray(symbols, dtype=object)
        positions = np.asarray(positions, dtype=float)
        n_atoms = len(symbols)

        if positions.shape != (n_atoms, 3):
            raise ValueError("positions must have shape (N, 3)")

        if cell is not None:
            cell = np.asarray(cell, dtype=float)
            if cell.shape == (3, 3) and np.any(cell):
                pbc = True
            else:
                cell = None
                pbc = False
        else:
            pbc = False

        ligand_mask = _as_bool_mask(ligand_indices, n_atoms, "ligand_indices")

        if mm_indices is None:
            mm_mask = ~ligand_mask
        else:
            mm_mask = _as_bool_mask(mm_indices, n_atoms, "mm_indices")

        if np.any(ligand_mask & mm_mask):
            raise ValueError("Ligand and MM selections overlap")

        if np.sum(ligand_mask) == 0:
            return positions, symbols, cell, 1.0e6, {"error": "Empty ligand selection"}
        if np.sum(mm_mask) == 0:
            return positions, symbols, cell, 1.0e6, {"error": "Empty macromolecule selection"}

        cutoff = float(crop_cutoff if crop_cutoff_ is None else crop_cutoff_)

        # ---------------------------------------------------------------------
        # 1) Crop MM for this pose
        # ---------------------------------------------------------------------
        mm_crop_mask = _crop_mm_around_ligand(
            symbols=symbols,
            positions=positions,
            cell=cell,
            ligand_mask=ligand_mask,
            mm_mask=mm_mask,
            cutoff=cutoff,
            pbc=pbc,
            include_buffer_indices=include_buffer_indices,
        )

        n_mm_crop = int(np.sum(mm_crop_mask))
        if n_mm_crop == 0 and not allow_empty_crop:
            return positions, symbols, cell, 1.0e6, {"error": "Cropping produced zero MM atoms"}

        complex_mask = ligand_mask | mm_crop_mask

        # ---------------------------------------------------------------------
        # 2) Build subsystems
        # ---------------------------------------------------------------------
        complex_symbols, complex_positions, complex_cell, complex_global_idx = _subset_atoms(
            symbols, positions, cell, complex_mask
        )
        mm_symbols, mm_positions, mm_cell, mm_global_idx = _subset_atoms(symbols, positions, cell, mm_crop_mask)
        lig_symbols, lig_positions, lig_cell, lig_global_idx = _subset_atoms(symbols, positions, cell, ligand_mask)

        # ---------------------------------------------------------------------
        # 3) Freeze cropped MM in complex; freeze all MM in MM-only calculation
        # ---------------------------------------------------------------------
        complex_frozen_mask = _build_frozen_mask_for_complex(
            complex_global_indices=complex_global_idx,
            mm_crop_global_mask=mm_crop_mask,
        )
        mm_frozen_mask = np.ones(len(mm_symbols), dtype=bool)

        complex_constraints = _freeze_mask_to_constraint_predicates(complex_frozen_mask)
        mm_constraints = _freeze_mask_to_constraint_predicates(mm_frozen_mask)
        lig_constraints = None

        base = os.path.splitext(output_filename)[0]
        complex_out = f"{base}__complex.xyz"
        mm_out = f"{base}__mmcrop.xyz"
        lig_out = f"{base}__ligand.xyz"

        # ---------------------------------------------------------------------
        # 4) Evaluate complex
        # ---------------------------------------------------------------------
        c_pos, c_sym, c_cell, E_complex, meta_complex = base_runner(
            symbols=complex_symbols,
            positions=complex_positions,
            cell=complex_cell,
            fixed=None,
            sampling_temperature=sampling_temperature,
            steps_max_=steps_max_,
            output_filename=complex_out,
            constraints=complex_constraints,
            **kwargs,
        )

        # ---------------------------------------------------------------------
        # 5) Evaluate cropped MM alone (fully frozen)
        # ---------------------------------------------------------------------
        m_pos, m_sym, m_cell, E_mm, meta_mm = base_runner(
            symbols=mm_symbols,
            positions=mm_positions,
            cell=mm_cell,
            fixed=None,
            sampling_temperature=sampling_temperature,
            steps_max_=steps_max_,
            output_filename=mm_out,
            constraints=mm_constraints,
            **kwargs,
        )

        # ---------------------------------------------------------------------
        # 6) Evaluate ligand alone
        # ---------------------------------------------------------------------
        l_pos, l_sym, l_cell, E_lig, meta_lig = base_runner(
            symbols=lig_symbols,
            positions=lig_positions,
            cell=lig_cell,
            fixed=None,
            sampling_temperature=sampling_temperature,
            steps_max_=steps_max_,
            output_filename=lig_out,
            constraints=lig_constraints,
            **kwargs,
        )
        # ---------------------------------------------------------------------
        # 7) Adsorption energy
        # ---------------------------------------------------------------------
        E_ads = float(E_complex - E_mm - E_lig)

        metadata: dict[str, Any] = {
            "energy_units": "eV",
            "E_complex_eV": float(E_complex),
            "E_mm_crop_eV": float(E_mm),
            "E_ligand_eV": float(E_lig),
            "E_ads_eV": E_ads,
            "crop_cutoff_A": cutoff,
            "n_atoms_total": int(n_atoms),
            "n_atoms_ligand": int(np.sum(ligand_mask)),
            "n_atoms_mm_total": int(np.sum(mm_mask)),
            "n_atoms_mm_crop": int(np.sum(mm_crop_mask)),
            "ligand_global_indices": np.where(ligand_mask)[0],
            "mm_crop_global_indices": np.where(mm_crop_mask)[0],
            "complex_metadata": meta_complex,
            "mm_crop_metadata": meta_mm,
            "ligand_metadata": meta_lig,
        }

        # Ensure cell is None if it has no non-zero elements
        final_cell = None
        if c_cell is not None and np.any(c_cell):
            final_cell = np.asarray(c_cell, dtype=float)

        # 7) Re-map Optimized Crop Back to Full System
        # The GA simulator expects the full population-item size (symbols, positions, etc.)
        # We take the original input and update the parts that were optimized (CROPPED).
        # Frozen atoms (MM outside crop) stay at their original input positions.

        final_full_pos = positions.copy()
        crop_global_indices = np.where(complex_mask)[0]

        # Assertions for safety
        if len(c_pos) != len(crop_global_indices):
            # This should not happen if base_runner is well-behaved
            raise ValueError(f"Cropped return size {len(c_pos)} mismatch crop indices {len(crop_global_indices)}")

        final_full_pos[crop_global_indices] = c_pos
        final_full_sym = np.asarray(symbols, dtype=object)
        final_full_sym[crop_global_indices] = c_sym

        return (
            final_full_pos,
            final_full_sym,
            final_cell,
            E_ads,
            metadata,
        )

    return run
