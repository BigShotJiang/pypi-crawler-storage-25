from __future__ import annotations

import json
import math
import os
import time
from collections.abc import Callable, Sequence
from dataclasses import asdict, dataclass
from typing import Any, cast

import ase.io
import numpy as np
from ase import Atoms

_EPS = 1e-12


# =============================================================================
# Small utils
# =============================================================================


def _clip(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x


def _clip01(x: float) -> float:
    return _clip(float(x), 0.0, 1.0)


def _to_pred_list(preds: Sequence[Callable] | None) -> list:
    if preds is None:
        return []
    if callable(preds):
        return [preds]
    try:
        return list(preds)
    except TypeError:
        return [preds]


def _normalize_components(components: Sequence[int | str] | None) -> list[int] | None:
    if components is None:
        return None
    comp_map = {"x": 0, "y": 1, "z": 2}
    out: list[int] = []
    for c in components:
        if isinstance(c, str):
            c_low = c.lower()
            if c_low in comp_map:
                out.append(comp_map[c_low])
            else:
                raise ValueError(f"Invalid component string: {c}")
        else:
            out.append(int(c))
    if any(c not in (0, 1, 2) for c in out):
        raise ValueError("freeze_components must be subset of {0,1,2,'x','y','z'}")
    return out


# =============================================================================
# Persistent state (global memory across separate runs)
# =============================================================================


@dataclass
class GalileoMCState:
    """
    Persistent MC adaptation state.

    Stored on disk to preserve tuned proposal scale across independent runs.

    Notes
    -----
    - step_A: current proposal std-dev scale (Å)
    - acc_ema: exponentially smoothed acceptance rate estimate
    - n_total: total number of MC proposals seen (for diagnostics)
    """

    step_A: float = 0.15
    acc_ema: float = 0.30
    n_total: int = 0
    updated_unix: float = 0.0


class _StateStore:
    """
    Lightweight JSON-backed state store.

    Keyed by user-provided `state_key` so you can maintain multiple
    independent adaptive memories (e.g., per system / per calculator).
    """

    def __init__(self, path: str, state_key: str = "default"):
        self.path = path
        self.state_key = state_key

    def load(self) -> GalileoMCState:
        try:
            with open(self.path, encoding="utf-8") as f:
                blob = json.load(f)
            obj = blob.get(self.state_key, None)
            if not isinstance(obj, dict):
                return GalileoMCState()
            # Filter keys to only those present in the dataclass
            from dataclasses import fields

            known = {f.name for f in fields(GalileoMCState)}
            filtered = {k: v for k, v in obj.items() if k in known}
            return GalileoMCState(**filtered)
        except Exception:
            return GalileoMCState()

    def save(self, state: GalileoMCState) -> None:
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        blob: dict[str, Any] = {}
        try:
            if os.path.exists(self.path):
                with open(self.path, encoding="utf-8") as f:
                    blob = json.load(f)
            if not isinstance(blob, dict):
                blob = {}
        except Exception:
            blob = {}

        state.updated_unix = time.time()
        blob[self.state_key] = asdict(state)

        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(blob, f, indent=2, sort_keys=True)
        os.replace(tmp, self.path)


# =============================================================================
# Constraint bridge (compatible with your predicate convention)
# =============================================================================


class _APMAdapter:
    def __init__(self, symbols, positions, cell, atomic_constraints=None):
        self.atomPositions = np.asarray(positions, float)
        self.atomLabelsList = np.asarray(symbols, dtype=object)
        _cell = np.asarray(cell, float) if cell is not None else None
        if _cell is None or _cell.shape != (3, 3) or not np.isfinite(_cell).all() or abs(np.linalg.det(_cell)) < 1e-9:
            _cell = np.eye(3, dtype=float)
        self.latticeVectors = _cell
        self.atomicConstraints = np.asarray(atomic_constraints, bool) if atomic_constraints is not None else None
        self.atomCount = len(self.atomPositions)


class _StructAdapter:
    def __init__(self, symbols, positions, cell, atomic_constraints=None):
        self.AtomPositionManager = _APMAdapter(symbols, positions, cell, atomic_constraints)


def _evaluate(idx: int, structure: _StructAdapter, constraints: Sequence[Callable], logic: str = "all") -> bool:
    if not constraints:
        return False
    if logic == "all":
        return all(c(idx, structure) for c in constraints)
    if logic == "any":
        return any(c(idx, structure) for c in constraints)
    raise ValueError("constraint_logic must be 'all' or 'any'")


def _select_indices_by_constraints(
    symbols,
    positions,
    cell,
    fixed: Sequence[bool] | np.ndarray | None,
    constraints: Sequence[Callable],
    logic: str = "all",
) -> np.ndarray:
    N = len(symbols)
    adapter = _StructAdapter(symbols=symbols, positions=positions, cell=cell, atomic_constraints=fixed)
    sel = [i for i in range(N) if _evaluate(i, adapter, constraints, logic=logic)]
    return np.asarray(sel, dtype=int)


def _build_atoms(
    symbols: Sequence[str], positions: np.ndarray, cell: np.ndarray | None, calculator: object
) -> tuple[Atoms, bool]:
    if cell is not None:
        pbc = True
        cell = np.asarray(cell, float) if np.ndim(cell) == 2 else None
        if cell is None or cell.shape != (3, 3) or abs(np.linalg.det(cell)) < 1e-6:
            pbc, cell = False, None
    else:
        pbc = False

    atoms = Atoms(symbols=symbols, positions=positions, cell=cell, pbc=pbc)
    if calculator is not None:
        atoms.calc = calculator
    return atoms, pbc


def _movable_mask(N: int, selected: np.ndarray, action: str, comps: list[int] | None) -> np.ndarray:
    """
    Boolean mask (N,3) where True means "allowed to move this DOF".
    """
    mask = np.ones((N, 3), dtype=bool)

    selected = np.asarray(selected, dtype=int)
    selected = np.unique(selected)

    if action not in ("freeze", "move_only"):
        raise ValueError("constraint_action must be 'freeze' or 'move_only'")

    if selected.size == 0:
        if action == "move_only":
            mask[:, :] = False
        return mask

    if action == "freeze":
        if comps is None:
            mask[selected, :] = False
        else:
            mask[selected[:, None], np.array(comps)[None, :]] = False
    else:
        mask[:, :] = False
        if comps is None:
            mask[selected, :] = True
        else:
            mask[selected[:, None], np.array(comps)[None, :]] = True

    return mask


# =============================================================================
# Main factory
# =============================================================================


def galilean_constrained_mc(
    calculator: object = None,
    # --- GMC controls ---
    constraint_kind: str = "energy",  # "energy", "phi_fixed_composition", or "custom"
    observable_fn: Callable | None = None,
    observable_grad_fn: Callable | None = None,
    # observable_max can be a static float, or a Callable that returns a float.
    # The actual constraint is resolved at runtime per-run, preferring shared_state['ns_phi_star'] if present.
    observable_max: float | Callable[[], float] | None = None,
    eps_A: float = 0.05,
    L_traj: int = 8,
    N_traj: int = 10,
    # --- persistent adaptive proposal memory ---
    state_path: str = "gmc_state.json",
    state_key: str = "default",
    enable_adaptation: bool = False,
    warmup_trajectories: int = 0,
    # --- adaptation control (Robbins–Monro style for eps_A)
    # We adapt eps_A based on the collision (bounce) rate.
    # If the trajectory hits constraints too often, we reduce the step.
    # If it rarely hits them, we increase the step.
    target_bounce_rate: float = 0.20,
    adapt_interval: int = 5,
    adapt_gain: float = 0.05,
    eps_bounds_A: tuple[float, float] = (0.001, 1.00),
    acc_ema_alpha: float = 0.05,
    # --- IO knobs ---
    log_interval: int = 0,
    write_interval: int = 0,
    # --- constraints ---
    constraint_logic: str = "all",
    constraint_action: str = "freeze",
    freeze_components: Sequence[int | str] | None = None,
    constraints: Sequence[Callable] | None = None,
    # --- stagnant detection / early exit ---
    max_stagnant: int | None = None,
    # --- pre-optimization ---
    pre_opt_fire_steps: int = 0,
    chemical_potential: dict[str, float] | None = None,
) -> Callable[..., tuple[np.ndarray, np.ndarray, np.ndarray | None, float, dict[str, Any]]]:
    """
    True Galilean Monte Carlo sampling for exact Nested Sampling replacements.

    This uses:
    - active subspace velocities and linear propagation.
    - specular reflections at the constraint boundary based on the gradient.
    - multiple sub-steps to form constrained trajectories.
    """

    # if observable_max is None:
    #    raise ValueError("observable_max is required for Galilean MC (can be float or Callable)")
    if constraint_kind not in ("energy", "phi_fixed_composition", "custom"):
        raise ValueError(f"Unknown constraint_kind: {constraint_kind}")
    if constraint_kind == "custom" and (observable_fn is None or observable_grad_fn is None):
        raise ValueError("custom constraint requires both observable_fn and observable_grad_fn")

    freeze_components_norm = _normalize_components(freeze_components)
    factory_constraints = _to_pred_list(constraints)

    store = _StateStore(path=state_path, state_key=state_key)
    state = store.load()
    if state.n_total == 0:
        state.step_A = float(eps_A)
        # Using acc_ema to store the historical non-bounce rate (or similar)
        state.acc_ema = float(1.0 - target_bounce_rate)

    eps_lo, eps_hi = eps_bounds_A
    state.step_A = float(_clip(state.step_A, eps_lo, eps_hi))

    def run(
        symbols: np.ndarray | Sequence[str],
        positions: np.ndarray,
        cell: np.ndarray | None,
        *,
        fixed: np.ndarray | None = None,
        constraints: Sequence[Callable] | None = None,
        output_filename: str = "gmc_out.xyz",
        seed: int | None = None,
        shared_state: dict[str, Any] | None = None,
        **kwargs,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, float, dict[str, Any]]:

        rng = np.random.default_rng(seed)

        symbols_arr = np.asarray(symbols, dtype=object)
        positions_arr = np.asarray(positions, dtype=float)
        cell_arr = np.asarray(cell, dtype=float) if cell is not None else None

        atoms, pbc_flag = _build_atoms(cast(Sequence[str], symbols_arr.tolist()), positions_arr, cell_arr, calculator)

        combined_constraints = list(factory_constraints)
        combined_constraints.extend(_to_pred_list(constraints))

        adapter_cell = cell_arr if (pbc_flag and cell_arr is not None) else np.eye(3, dtype=float)
        if combined_constraints:
            selected = _select_indices_by_constraints(
                symbols_arr,
                positions_arr,
                adapter_cell,
                cast(Sequence[bool], fixed) if fixed is not None else None,
                combined_constraints,
                logic=constraint_logic,
            )
        else:
            selected = np.array([], dtype=int)

        N = len(atoms)
        movable = _movable_mask(N, selected, constraint_action, freeze_components_norm)

        # Build active subspace
        active_indices = np.flatnonzero(movable.reshape(-1))
        n_active = active_indices.size

        # Resolve chemical potential for Phi calculation
        actual_mu = chemical_potential
        if shared_state is not None and "ns_mu" in shared_state:
            actual_mu = shared_state["ns_mu"]

        from collections import Counter

        def get_val_and_grad(at: Any, only_val: bool = False) -> tuple[float, np.ndarray | None]:
            if constraint_kind in ("energy", "phi_fixed_composition"):
                v = float(at.get_potential_energy())

                # Grand Potential adjustment: Phi = E - sum(mu * N)
                if actual_mu:
                    symbols_at = at.get_chemical_symbols()
                    counts = Counter(symbols_at)
                    for species, mval in actual_mu.items():
                        v -= mval * counts.get(species, 0)

                if only_val:
                    return v, None

                f = np.asarray(at.get_forces(), float).reshape(-1)
                g = -f  # gradient of energy (mu*N term has zero grad)
            else:
                if observable_fn is None or observable_grad_fn is None:
                    raise ValueError("observable_fn and observable_grad_fn must be provided for custom constraint")
                v = float(observable_fn(at))
                if only_val:
                    return v, None
                g = np.asarray(observable_grad_fn(at), float).reshape(-1)

            return v, g[active_indices]

        # ---------------------------------------------------------------------
        # Dynamic Constraint Resolution (Observer pattern via Dependency Injection)
        # ---------------------------------------------------------------------
        obs_cap = None
        if shared_state is not None and "ns_phi_star" in shared_state:
            obs_cap = float(shared_state["ns_phi_star"])
        elif observable_max is not None:
            obs_cap = float(observable_max()) if callable(observable_max) else float(observable_max)

        # Initial value of the current structure
        v0, _ = get_val_and_grad(atoms, only_val=True)

        # If no cap is provided, or it's infinite (NS initial fill),
        # use the current structure's value as the cap.
        if obs_cap is None or np.isinf(obs_cap):
            obs_cap = v0

        if n_active == 0 or N_traj == 0 or L_traj == 0:
            E_actual = float(atoms.get_potential_energy())
            cell_obj = atoms.get_cell()
            pbc_out = bool(atoms.get_pbc().any())
            cell_out = cell_obj.array if (pbc_out and float(cell_obj.volume) > 1e-12) else None
            return (
                np.asarray(atoms.get_positions(), float),
                np.asarray(atoms.get_chemical_symbols(), object),
                np.asarray(cell_out, float) if cell_out is not None else None,
                float(E_actual),
                {
                    "gmc_note": "no movable atoms or zero trajectories",
                    "gmc_eps": float(state.step_A),
                },
            )

        out_dir = os.path.dirname(output_filename) or "."
        os.makedirs(out_dir, exist_ok=True)

        # ---------------------------------------------------------------------
        # Pre-optimization (FIRE)
        # ---------------------------------------------------------------------
        if pre_opt_fire_steps > 0:
            from ase.constraints import FixAtoms, FixCartesian
            from ase.optimize import FIRE

            c_list: list[Any] = []
            fully_fixed = []
            for i in range(N):
                atom_movable = movable[i]
                if not np.any(atom_movable):
                    fully_fixed.append(i)
                elif not np.all(atom_movable):
                    # FixCartesian mask: True means fixed
                    mask_fix = (~atom_movable).astype(bool).tolist()
                    c_list.append(FixCartesian(i, mask_fix))

            if fully_fixed:
                c_list.append(FixAtoms(indices=fully_fixed))

            if c_list:
                atoms.set_constraint(c_list)

            opt = FIRE(atoms, logfile=None)
            opt.run(fmax=0.01, steps=pre_opt_fire_steps)

            # Reset constraints, GMC handles movable atoms manually via active_indices
            atoms.set_constraint([])
            positions_arr = atoms.get_positions()

        float(atoms.get_potential_energy())
        x_start_flat = atoms.get_positions().copy().reshape(-1)
        x_active = x_start_flat[active_indices].copy()

        # Update atoms view
        def set_active_pos(x_vec: np.ndarray):
            x_flat = atoms.get_positions().reshape(-1)
            x_flat[active_indices] = x_vec
            atoms.set_positions(x_flat.reshape(-1, 3))

        eps_current = float(state.step_A)

        # Stats
        bounces = 0
        accepted_substeps = 0
        proposed_substeps = 0

        bounces_window = 0
        proposed_window = 0

        t0 = time.time()

        adapt_until = N_traj if (warmup_trajectories <= 0) else min(int(warmup_trajectories), N_traj)
        pruned_traj_count = 0

        for t in range(N_traj):
            # Sample uniform random velocity in active subspace
            v = rng.normal(size=n_active)
            v /= np.maximum(np.linalg.norm(v), 1e-15)

            x_active.copy()
            stagnant_count = 0

            for l in range(L_traj):
                proposed_substeps += 1
                proposed_window += 1

                x_trial = x_active + eps_current * v
                set_active_pos(x_trial)
                obs_trial, grad_active = get_val_and_grad(atoms)

                if obs_trial < obs_cap:
                    # Valid straight step
                    x_active = x_trial
                    accepted_substeps += 1
                else:
                    # Hard Reflection logic (Bisection to find boundary)
                    bounces += 1
                    bounces_window += 1

                    t_wall, x_wall = 0.0, x_active.copy()
                    t_hi = 1.0
                    for _ in range(3):  # Bisection iterations
                        t_mid = 0.5 * (t_wall + t_hi)
                        x_mid = x_active + t_mid * eps_current * v
                        set_active_pos(x_mid)
                        # We use simple energy check for bisection speed (avoiding full grad call)
                        v_mid, _ = get_val_and_grad(atoms, only_val=True)
                        if v_mid < obs_cap:
                            t_wall, x_wall = t_mid, x_mid.copy()
                        else:
                            t_hi = t_mid

                    # Get gradient at the boundary point
                    set_active_pos(x_wall)
                    _, grad_wall = get_val_and_grad(atoms)
                    assert grad_wall is not None
                    norm = np.linalg.norm(grad_wall)

                    if norm < 1e-12:
                        v = -v
                        stagnant_count += 1
                    else:
                        n = grad_wall / norm
                        v = v - 2.0 * np.dot(v, n) * n

                        # Complete the step after reflection
                        dist_left = (1.0 - t_wall) * eps_current
                        x_final = x_wall + dist_left * v
                        set_active_pos(x_final)
                        obs_final, _ = get_val_and_grad(atoms)

                        if obs_final < obs_cap:
                            x_active = x_final
                            accepted_substeps += 1
                            stagnant_count = 0
                        else:
                            # If second hit (rare), just stay at the wall or reverse
                            x_active = x_wall
                            v = -v
                            stagnant_count += 1

                if max_stagnant is not None and stagnant_count >= max_stagnant:
                    pruned_traj_count += 1
                    if log_interval:
                        print(f"[GMC] Early Exit: Trajectory {t} stagnant for {stagnant_count} steps.")
                    break

                if write_interval and (l + t * L_traj) % write_interval == 0:
                    try:
                        ase.io.write(output_filename, atoms, format="extxyz", append=True)
                    except Exception:
                        pass

            if log_interval and (t % log_interval == 0):
                bounce_r = bounces_window / max(proposed_window, 1)
                print(
                    f"[GMC] t={t:4d} bounces_w={bounces_window}/{proposed_window} ({(bounce_r * 100):.1f}%) eps={eps_current:.4f}Å",
                    flush=True,
                )

            # Adapt EPS based on bounce rate
            if enable_adaptation and (t + 1) % adapt_interval == 0 and (t + 1) <= adapt_until:
                # If bounce rate is too high, decrease eps. If too low, increase eps.
                bounce_r = bounces_window / max(proposed_window, 1)

                # We use a relative error to make changes more symmetric.
                # If target=0.20, bounce_r=0.0 (no bounces), ratio = -1.0
                # If target=0.20, bounce_r=0.40 (double bounces), ratio = 1.0
                # If target=0.20, bounce_r=1.00 (all bounces), ratio = 4.0
                error_ratio = (target_bounce_rate - bounce_r) / max(target_bounce_rate, 1e-6)

                # Apply the gain. Bound the exponent to prevent overflow/extreme jumps
                exponent = max(min(adapt_gain * error_ratio, 2.0), -2.0)
                eps_current *= math.exp(exponent)
                eps_current = float(_clip(eps_current, eps_lo, eps_hi))

                bounces_window = 0
                proposed_window = 0

        # Always return the final state, no track_best.
        set_active_pos(x_active)
        E_out = float(atoms.get_potential_energy())

        try:
            ase.io.write(output_filename, atoms, format="extxyz", append=True)
        except Exception:
            pass

        acc_rate = accepted_substeps / max(proposed_substeps, 1)
        state.step_A = float(eps_current)
        state.acc_ema = float((1.0 - acc_ema_alpha) * state.acc_ema + acc_ema_alpha * acc_rate)
        state.n_total = int(state.n_total + proposed_substeps)
        store.save(state)

        cell_obj = atoms.get_cell()
        pbc_out = bool(atoms.get_pbc().any())
        cell_out = cell_obj.array if (pbc_out and float(cell_obj.volume) > 1e-12) else None

        meta: dict[str, Any] = {
            "gmc_eps_final_A": float(eps_current),
            "gmc_trajectories": int(N_traj),
            "gmc_steps_per_traj": int(L_traj),
            "gmc_proposed_substeps": int(proposed_substeps),
            "gmc_accepted_substeps": int(accepted_substeps),
            "gmc_acceptance": float(acc_rate),
            "gmc_bounces": int(bounces),
            "gmc_cap": float(obs_cap),
            "gmc_state_acc_ema": float(state.acc_ema),
            "gmc_runtime_s": float(time.time() - t0),
            "gmc_seed": int(seed) if seed is not None else -1,
            "gmc_pruned_trajectories": int(pruned_traj_count),
        }

        return (
            np.asarray(atoms.get_positions(), float),
            np.asarray(atoms.get_chemical_symbols(), object),
            np.asarray(cell_out, float) if cell_out is not None else None,
            float(E_out),
            meta,
        )

    return run
