from __future__ import annotations
"""
constraints_pdb.py
------------------

PDB and PDBQT aware constraint functions for EZGA.
Allows selections based on residue name, chain, atom name, charges, and record types.
"""

import numpy as np
from typing import Any, List, Set, Optional, Callable

def info_atom_equals(key: str, value: Any) -> Callable:
    """
    Constraint: True if structure.atoms.info_atoms[key][idx] == value.
    """
    def _check(idx: int, structure: Any) -> bool:
        atoms = getattr(structure, "atoms", structure)
        info = getattr(atoms, "info_atoms", {})
        if key not in info:
            return False
        try:
            return bool(info[key][idx] == value)
        except (IndexError, KeyError):
            return False
    return _check

def info_atom_in(key: str, values: Set[Any] | List[Any]) -> Callable:
    """
    Constraint: True if structure.atoms.info_atoms[key][idx] is in values.
    """
    val_set = set(values)
    def _check(idx: int, structure: Any) -> bool:
        atoms = getattr(structure, "atoms", structure)
        info = getattr(atoms, "info_atoms", {})
        if key not in info:
            return False
        try:
            return bool(info[key][idx] in val_set)
        except (IndexError, KeyError):
            return False
    return _check

# --- Generic PDB Aliases ---

def chain_is(chain_id: str):
    return info_atom_equals("chain", chain_id)

def residue_is(res_name: str):
    return info_atom_equals("res_name", res_name)

def residue_in(res_names: List[str] | Set[str]):
    return info_atom_in("res_name", res_names)

def residue_id_is(res_id: int | str):
    return info_atom_equals("res_id", res_id)

def atom_name_is(atom_name: str):
    return info_atom_equals("atom_name", atom_name)

def atom_name_in(atom_names: List[str] | Set[str]):
    return info_atom_in("atom_name", atom_names)

def pdb_record_is(record: str):
    """'ATOM' or 'HETATM'"""
    return info_atom_equals("record", record)

# --- Chemical Class Constraints ---

HYDROPHOBIC_RESIDUES = {"ALA", "VAL", "LEU", "ILE", "MET", "PHE", "TRP", "PRO"}
POLAR_RESIDUES = {"SER", "THR", "ASN", "GLN", "TYR", "CYS"}
POSITIVE_RESIDUES = {"LYS", "ARG", "HIS", "HIP", "HIE", "HID"}
NEGATIVE_RESIDUES = {"ASP", "GLU"}
AROMATIC_RESIDUES = {"PHE", "TYR", "TRP", "HIS", "HID", "HIE", "HIP"}
BACKBONE_ATOMS = {"N", "CA", "C", "O", "OXT"}

def is_protein_atom():
    return pdb_record_is("ATOM")

def is_hetero_atom():
    return pdb_record_is("HETATM")

def sidechain_atom():
    """True if PDB record is ATOM and atom_name is not in backbone."""
    def _check(idx: int, structure: Any) -> bool:
        atoms = getattr(structure, "atoms", structure)
        info = getattr(atoms, "info_atoms", {})
        try:
            return info["record"][idx] == "ATOM" and info["atom_name"][idx] not in BACKBONE_ATOMS
        except (IndexError, KeyError):
            return False
    return _check

def hydrophobic_residue():
    return residue_in(HYDROPHOBIC_RESIDUES)

def polar_residue():
    return residue_in(POLAR_RESIDUES)

def positive_residue():
    return residue_in(POSITIVE_RESIDUES)

def negative_residue():
    return residue_in(NEGATIVE_RESIDUES)

def aromatic_residue():
    return residue_in(AROMATIC_RESIDUES)

# --- Charge and PDBQT Constraints ---

def pdbqt_type_is(type_name: str):
    return info_atom_equals("type_pdbqt", type_name)

def pdbqt_type_in(type_names: List[str] | Set[str]):
    return info_atom_in("type_pdbqt", type_names)

def partial_charge_greater_than(threshold: float):
    def _check(idx: int, structure: Any) -> bool:
        atoms = getattr(structure, "atoms", structure)
        info = getattr(atoms, "info_atoms", {})
        try:
            return float(info["partial_charge"][idx]) > threshold
        except (IndexError, KeyError, ValueError, TypeError):
            return False
    return _check

def partial_charge_less_than(threshold: float):
    def _check(idx: int, structure: Any) -> bool:
        atoms = getattr(structure, "atoms", structure)
        info = getattr(atoms, "info_atoms", {})
        try:
            return float(info["partial_charge"][idx]) < threshold
        except (IndexError, KeyError, ValueError, TypeError):
            return False
    return _check

COMMON_NON_LIGAND_HET = {"HOH", "WAT", "NA", "CL", "K", "MG", "CA", "ZN", "FE", "MN", "CU"}

def likely_ligand_atom():
    """HETATM record that is not a common solvent or ion."""
    def _check(idx: int, structure: Any) -> bool:
        atoms = getattr(structure, "atoms", structure)
        info = getattr(atoms, "info_atoms", {})
        try:
            return (
                info["record"][idx] == "HETATM"
                and info["res_name"][idx] not in COMMON_NON_LIGAND_HET
            )
        except (IndexError, KeyError):
            return False
    return _check
