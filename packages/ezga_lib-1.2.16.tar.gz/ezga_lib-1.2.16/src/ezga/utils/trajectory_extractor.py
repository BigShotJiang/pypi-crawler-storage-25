# ezga/utils/trajectory_extractor.py
# SPDX-License-Identifier: MIT
"""
Utility to extract individual replica exchange/Parallel Tempering trajectories 
(both walker-lineage and state-fixed trajectories) from generated simulation snapshots.
"""

from __future__ import annotations
import os
import json
import logging
import re
from pathlib import Path
from typing import Any, List, Dict, Optional, cast
from ase import Atoms
from ase.io import read, write

logger = logging.getLogger(__name__)


class TrajectoryExtractor:
    """
    Extracts individual trajectories from the generation XYZ snapshots written during 
    EZGA Replica Exchange / Parallel Tempering simulations.
    """

    def __init__(self, output_path: str | Path):
        """
        Initialize the extractor.

        Parameters
        ----------
        output_path : str or Path
            The base output directory of the EZGA run (containing 'generation/' and/or 'logger/').
        """
        self.output_path = Path(output_path).resolve()
        self.gen_dir = self.output_path / "generation"
        self.logger_dir = self.output_path / "logger"
        
        # Fallback to check inside a supercell stage if base does not have generation dir
        if not self.gen_dir.exists():
            # Search for subdirectories like 'supercell_*'
            stages = sorted(list(self.output_path.glob("supercell_*")))
            if stages:
                # Use the last/largest supercell stage by default
                self.output_path = stages[-1]
                self.gen_dir = self.output_path / "generation"
                self.logger_dir = self.output_path / "logger"

    def discover_generations(self) -> List[int]:
        """
        Discover all generation snapshots available on disk.

        Returns
        -------
        List[int]
            Sorted list of generation indices.
        """
        if not self.gen_dir.exists():
            return []
        
        gen_indices = []
        # Search for gen* folders or config_g*.xyz files
        for p in self.gen_dir.glob("gen*/config_g*.xyz"):
            m = re.search(r"config_g(\d+)\.xyz", p.name)
            if m:
                gen_indices.append(int(m.group(1)))
        
        if not gen_indices:
            # Fallback to directories
            for p in self.gen_dir.glob("gen*"):
                m = re.search(r"gen(\d+)", p.name)
                if m:
                    gen_indices.append(int(m.group(1)))
                    
        return sorted(list(set(gen_indices)))

    def load_replica_stats(self) -> Optional[Dict[str, Any]]:
        """
        Loads the replica exchange statistics JSON file if available.

        Returns
        -------
        dict or None
            Loaded stats dictionary or None.
        """
        stats_file = self.logger_dir / "replica_stats.json"
        if not stats_file.exists():
            return None
        try:
            with open(stats_file, "r", encoding="utf-8") as f:
                return cast(dict[str, Any], json.load(f))
        except Exception as e:
            logger.warning(f"Could not load replica stats from {stats_file}: {e}")
            return None

    def extract_walker_trajectory(self, walker_id: int, out_xyz: str | Path) -> List[Atoms]:
        """
        Extracts the trajectory of a specific walker_id across all generations.
        This represents the structural evolution of a single configuration lineage 
        as it moves across different thermodynamic conditions (temperatures/potentials).

        Parameters
        ----------
        walker_id : int
            The walker_id of the lineage to extract.
        out_xyz : str or Path
            The destination XYZ file path to write the trajectory.

        Returns
        -------
        List[Atoms]
            List of extracted Atoms frames.
        """
        generations = self.discover_generations()
        if not generations:
            raise FileNotFoundError(f"No generation snapshots found in {self.gen_dir}")

        trajectory = []
        for gen in generations:
            xyz_file = self.gen_dir / f"gen{gen}" / f"config_g{gen}.xyz"
            if not xyz_file.exists():
                # Fallback to directory structure
                xyz_files = list((self.gen_dir / f"gen{gen}").glob("*.xyz"))
                if xyz_files:
                    xyz_file = xyz_files[0]
                else:
                    continue

            try:
                frames = read(str(xyz_file), index=":")
                found = False
                for frame in frames:
                    # Check in info dictionary (standard ASE format)
                    wid = frame.info.get("walker_id")
                    if wid is None:
                        # Fallback: check index in list
                        continue
                    
                    if int(wid) == walker_id:
                        frame.info["generation"] = gen
                        trajectory.append(frame)
                        found = True
                        break
                        
                if not found:
                    logger.debug(f"Walker {walker_id} not found in generation {gen}")
            except Exception as e:
                logger.warning(f"Error reading frame from {xyz_file}: {e}")

        if trajectory:
            out_xyz = Path(out_xyz)
            out_xyz.parent.mkdir(parents=True, exist_ok=True)
            write(str(out_xyz), trajectory, format="extxyz")
            logger.info(f"Successfully extracted walker {walker_id} trajectory ({len(trajectory)} frames) to {out_xyz}")
        else:
            logger.warning(f"No frames found for walker {walker_id}")

        return trajectory

    def extract_slot_trajectory(self, slot_id: int, out_xyz: str | Path) -> List[Atoms]:
        """
        Extracts the trajectory of configurations residing in a specific thermodynamic 
        slot_id (e.g. constant temperature/potential level) across all generations.
        This represents the standard Monte Carlo sampling path under a fixed thermodynamic state.

        Parameters
        ----------
        slot_id : int
            The slot_id (thermo_slot_id) to extract.
        out_xyz : str or Path
            The destination XYZ file path to write the trajectory.

        Returns
        -------
        List[Atoms]
            List of extracted Atoms frames.
        """
        generations = self.discover_generations()
        if not generations:
            raise FileNotFoundError(f"No generation snapshots found in {self.gen_dir}")

        trajectory = []
        for gen in generations:
            xyz_file = self.gen_dir / f"gen{gen}" / f"config_g{gen}.xyz"
            if not xyz_file.exists():
                xyz_files = list((self.gen_dir / f"gen{gen}").glob("*.xyz"))
                if xyz_files:
                    xyz_file = xyz_files[0]
                else:
                    continue

            try:
                frames = read(str(xyz_file), index=":")
                found = False
                for frame in frames:
                    sid = frame.info.get("thermo_slot_id")
                    if sid is None:
                        continue
                    
                    if int(sid) == slot_id:
                        frame.info["generation"] = gen
                        trajectory.append(frame)
                        found = True
                        break
                        
                if not found:
                    logger.debug(f"Slot {slot_id} not occupied/found in generation {gen}")
            except Exception as e:
                logger.warning(f"Error reading frame from {xyz_file}: {e}")

        if trajectory:
            out_xyz = Path(out_xyz)
            out_xyz.parent.mkdir(parents=True, exist_ok=True)
            write(str(out_xyz), trajectory, format="extxyz")
            logger.info(f"Successfully extracted slot {slot_id} trajectory ({len(trajectory)} frames) to {out_xyz}")
        else:
            logger.warning(f"No frames found for slot {slot_id}")

        return trajectory
