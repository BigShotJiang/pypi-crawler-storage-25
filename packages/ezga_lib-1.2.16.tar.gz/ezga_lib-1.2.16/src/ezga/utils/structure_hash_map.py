"""
Unified structure-hash manager with user‑selectable fingerprinting method
and precision-ensemble voting to discriminate duplicates vs. true collisions.


Public API remains compatible with CanonicalHashMap / PairRDFHashMap and
previous Structure_Hash_Map usage. New (opt‑in) APIs:

add_structure_voted(container, *, force_rehash=True, vote_frac=None, min_votes=None)

Example
-------
cmap = Structure_Hash_Map(method="rdf", r_max=10.0, bin_width=0.02,
vote_frac=0.6, min_votes=5,
precision_scales=(0.5, 1.0, 2.0))
report = cmap.add_structure_voted(container)


# report = {
# "added": False, "duplicate": True, "collision": False,
# "hash": "...", "votes_agree": 5, "votes_total": 7, "comp_key": "..."
# }
"""

from __future__ import annotations

import hashlib
import math
import random
import unittest
from collections import defaultdict
from collections.abc import Callable
from functools import reduce
from math import gcd
from typing import Any, Sequence, Union, TypeVar, cast

import numpy as np
try:
    import spglib
except ImportError:
    spglib = None

try:
    from sage_lib.single_run.SingleRun import SingleRun
except ImportError:
    class SingleRun: # type: ignore[no-redef]
        pass
from scipy.spatial import KDTree, cKDTree

from ..core.interfaces import IHash, IIndividual

__all__ = ["Structure_Hash_Map"]


# ============================================================================
#  KD‑tree serialiser (shared by all methods that need it)
# ============================================================================
def _serialize_kdtree_node(node) -> str:
    """Recursive, deterministic serialisation of a SciPy KDTree node."""
    if hasattr(node, "idx"):
        return "L[" + ",".join(map(str, node.idx.tolist())) + "]"
    split_val = f"{node.split:.6f}"
    left = _serialize_kdtree_node(node.less)
    right = _serialize_kdtree_node(node.greater)
    return f"I{node.split_dim}:{split_val}({left})({right})"


def _serialize_kdtree(tree) -> str:
    if isinstance(tree, cKDTree):  # rebuild pure‑Python tree for determinism
        tree = KDTree(tree.data, leafsize=getattr(tree, "leafsize", 10))
    return _serialize_kdtree_node(tree.tree)


# ============================================================================
#  Hash‑method implementations
# ============================================================================
# Redundant empty definition removed
def _group_shells_by_r2(M: np.ndarray) -> tuple[np.ndarray, dict[int, np.ndarray], np.ndarray]:
    """
    Groups integer modes by r2 = h^2 + k^2 + l^2 (spherical shells).
    Returns:
      unique_r2: (S,) sorted unique shell radii squared
      shell_idx: dict r2 -> indices (in M) that belong to that shell
      r2_of_mode: (M,) r2 for each mode (int32)
    """
    r2 = (M[:, 0].astype(np.int64) ** 2 + M[:, 1].astype(np.int64) ** 2 + M[:, 2].astype(np.int64) ** 2).astype(
        np.int64
    )
    uniq = np.unique(r2)
    shell_idx = {int(rr): np.where(r2 == rr)[0] for rr in uniq}
    return uniq.astype(np.int64), shell_idx, r2.astype(np.int64)


# ---------------------------------------------------------------------------
#  Helper: TSF-hash
# ---------------------------------------------------------------------------
def _build_integer_modes_sphere(kmax: int) -> np.ndarray:
    """
    Build an integer reciprocal grid M ⊂ Z^3 inside a sphere of radius kmax,
    excluding the origin. The list is deterministic (lexicographic order).

    Parameters
    ----------
    kmax : int
        Radius in integer space. kmax=3 → typically ~ 100 modes.

    Returns
    -------
    np.ndarray
        Array of shape (M, 3) with integer triples (h, k, l).
    """
    rng = range(-kmax, kmax + 1)
    modes = []
    for h in rng:
        for k in rng:
            for l in rng:
                if h == 0 and k == 0 and l == 0:
                    continue
                if h * h + k * k + l * l <= kmax * kmax:
                    modes.append((h, k, l))
    M = np.asarray(modes, dtype=np.int32)
    M = M[np.lexsort((M[:, 2], M[:, 1], M[:, 0]))]
    return cast(np.ndarray, M)


def _is_nonperiodic(apm) -> bool:
    # Prefer explicit flag if your APM exposes it
    pbc = getattr(apm, "pbc", None)  # e.g. (False, False, False)
    if isinstance(pbc, (tuple, list)) and not any(pbc):
        return True
    # Fallback: missing/degenerate lattice → treat as non-periodic
    try:
        lat = np.asarray(apm.latticeVectors, float)
        if lat.shape != (3, 3):
            return True
        if not np.isfinite(lat).all():
            return True
        # det is usually safe, but let's be extremely defensive
        try:
            return bool(abs(np.linalg.det(lat)) < 1e-9)
        except (np.linalg.LinAlgError, ValueError):
            return True
    except Exception:
        return True


# ---------------------------------------------------------------------------
#  Helper: canonical primitive cell (shared)
# ---------------------------------------------------------------------------
def _canonical_cell(apm, symprec: float, debug: bool):

    if _is_nonperiodic(apm):
        # Non-PBC: stay in Cartesian; use identity lattice; do not mod 1
        cart = np.asarray(apm.atomPositions, float)  # or .get_atomPositions_cartesian()
        Z = np.asarray(apm.get_atomic_numbers(), int)
        return None, cart, Z

    # (unchanged PBC branch)
    if spglib is None:
        if debug:
            print("spglib missing; cannot standardize cell.")
        return np.asarray(apm.latticeVectors, float).T, np.asarray(apm.atomPositions_fractional, float) % 1.0, np.asarray(apm.get_atomic_numbers(), int)

    lat0 = np.asarray(apm.latticeVectors, float).T
    try:
        frac0 = np.asarray(apm.atomPositions_fractional, float) % 1.0
    except AttributeError:
        # Fallback if attribute missing (compute from cartesian)
        FinvT = np.linalg.inv(lat0.T).T
        X = np.asarray(apm.atomPositions, float)
        frac0 = (X @ FinvT) % 1.0
    Z = np.asarray(apm.get_atomic_numbers(), int)
    try:
        lat, frac, Z = spglib.standardize_cell(
            (lat0.copy(), frac0.copy(), Z.copy()),
            to_primitive=True,
            no_idealize=False,
            symprec=symprec,
        )
        frac %= 1.0
        return lat, frac, Z
    except Exception:
        if debug:
            print("spglib fallback to original cell")
        return lat0, frac0, Z


# ---------------------------------------------------------------------------
#  Fastest hash ROT INV
# ---------------------------------------------------------------------------
def _structure_factor_hash_factory_rotinv(
    *,
    # Reciprocal sampling
    kmax: int = 3,
    modes: np.ndarray | None = None,  # custom (M,3) integer modes; overrides kmax when given
    per_species: bool = True,  # channels per Z (True) or aggregated (False)
    # Quantization
    ps_grid: float = 1e-1,  # shell-averaged |S| quantization grid
    lattice_grid: float = 2e-2,  # Å (lattice quantization)
    e_grid: float = 1e-3,  # eV/atom tick (optional)
    v_grid: float = 1e-2,  # Å^3/atom tick (optional)
    include_energy: bool = True,
    include_volume: bool = True,
    # Symmetry canonicalization (optional; improves reproducibility across settings)
    use_spglib: bool = False,
    symprec: float = 1e-3,
    angle_tolerance: float = -1.0,
    # Performance / robustness
    chunk_size: int = 50000,
    debug: bool = False,
    **kwargs,
) -> Callable[[object], str]:
    """
    Rotationally-invariant TSF hash (periodic): averages |S_Z(m)| over spherical shells
    of integer modes with identical r^2 = ||m||^2. This yields exact invariance to
    rigid rotations (in the discrete integer-lattice sense), exact translation invariance,
    and permutation invariance. Non-PBC structures fall back to a centered integer multiset.

    The hash payload (before SHA-256) includes:
      - quantized lattice (int),
      - species channel IDs (if per_species),
      - quantized shell-averaged magnitudes (int),
      - meta: [N, #channels, e_tick, v_tick], all little-endian.

    Assumptions:
      container.AtomPositionManager provides:
        - atomPositions (N,3) Cartesian (Å)
        - latticeVectors (3,3) with column vectors (a,b,c)
        - get_atomic_numbers() -> (N,)
        - optional .pbc (tuple/list of 3 bools), optional .E (total energy)
    """

    TWO_PI = 2.0 * math.pi
    EPS = 1e-12

    # Build modes and shells
    if modes is None:
        M = _build_integer_modes_sphere(kmax)
    else:
        M = np.asarray(modes, dtype=np.int32)
        if M.ndim != 2 or M.shape[1] != 3 or M.shape[0] == 0:
            raise ValueError("modes must have shape (M,3) with M>0")
        M = M[np.lexsort((M[:, 2], M[:, 1], M[:, 0]))]

    unique_r2, shell_index, r2_by_mode = _group_shells_by_r2(M)
    # Exclude the shell r2 == 0 if somehow present (shouldn't with our builder)
    if unique_r2[0] == 0:
        if debug:
            print("Removing r2=0 shell (contains only (0,0,0))")
        idx = np.where(unique_r2 != 0)[0]
        unique_r2 = unique_r2[idx]

    M_T = M.T
    M_count = int(M.shape[0])
    S_count = int(unique_r2.shape[0])  # number of shells

    def qint(x: np.ndarray, grid: float) -> np.ndarray:
        return np.floor(np.asarray(x, float) / grid + 0.5).astype(np.int32, copy=False)

    def hbytes(*chunks: bytes) -> str:
        h = hashlib.sha256()
        for c in chunks:
            h.update(c)
        return h.hexdigest()

    def hash_fn(container) -> str:
        apm = container.AtomPositionManager

        # PBC detection
        is_nonpbc = _is_nonperiodic(apm)

        # Basic properties
        Z = np.asarray(apm.get_atomic_numbers(), np.int32)
        N = int(Z.shape[0])
        if N == 0:
            return hbytes(b"TSFv2_rot\0", np.array([0], dtype="<i8").tobytes())

        # Optional ticks
        try:
            E_total = float(getattr(apm, "E", 0.0))
        except Exception:
            E_total = 0.0

        if not include_energy:
            e_tick = -1
        else:
            val = (E_total / N) if N > 0 else 0.0
            if not math.isfinite(val):
                e_tick = 10**15  # Large finite integer representative of overflow
            else:
                e_tick = int(math.floor(val / e_grid + 0.5))
                # Clip to signed 64-bit range (leave headroom)
                e_tick = max(-(2**60), min(2**60, e_tick))

        # Non-PBC fallback: translation- and rotation-invariant signature
        if is_nonpbc:
            X = np.asarray(apm.atomPositions, float)
            N_tot = X.shape[0]
            if N_tot < 2:
                # Single atom or empty: use species only
                meta = np.array([N, e_tick, -1], dtype="<i8").tobytes()
                return hbytes(b"TSFv2_rot\0", np.asarray(Z, dtype="<i4").tobytes(), meta)

            # Use a fast rotationally invariant signature for clusters:
            # we use the pairwise distance spectrum per species channel.
            qint(X, lattice_grid)
            dists = []
            for i in range(C_species := len(np.unique(Z))):
                mask = Z == np.unique(Z)[i]
                Xi = X[mask]
                if Xi.shape[0] > 1:
                    d = np.linalg.norm(Xi[:, None] - Xi[None, :], axis=-1)
                    dists.append(np.sort(qint(d[np.tril_indices(Xi.shape[0], k=-1)], lattice_grid)))

            # Cross-species distances
            for i in range(C_species):
                for j in range(i + 1, C_species):
                    mask1 = Z == np.unique(Z)[i]
                    mask2 = Z == np.unique(Z)[j]
                    X1, X2 = X[mask1], X[mask2]
                    d = np.linalg.norm(X1[:, None] - X2[None, :], axis=-1)
                    dists.append(np.sort(qint(d.ravel(), lattice_grid)))

            meta = np.array([N, e_tick, -1], dtype="<i8").tobytes()
            payload = [b"TSFv2_rot\0"]
            for d in dists:
                payload.append(d.tobytes())
            payload.append(meta)
            return hbytes(*payload)

        # Periodic path: fractionals
        A_cols = np.asarray(apm.latticeVectors, float)  # columns a,b,c
        A = A_cols.T  # rows for math
        X = np.asarray(apm.atomPositions, float)
        try:
            FinvT = np.linalg.inv(A).T
            F = (X @ FinvT + EPS) % 1.0
        except np.linalg.LinAlgError:
            # Fallback for singular lattice that reached here
            F = np.zeros_like(X)

        # Optional canonicalization (sets a reproducible setting/origin)
        if use_spglib:
            try:
                import spglib

                A_s, F_s, Z_s = spglib.standardize_cell(
                    (A.copy(), F.copy(), Z.copy()),
                    to_primitive=True,
                    no_idealize=True,
                    symprec=symprec,
                    angle_tolerance=angle_tolerance,
                )
                A = np.asarray(A_s, float)
                F = (np.asarray(F_s, float) + EPS) % 1.0
                Z = np.asarray(Z_s, np.int32)
                N = int(Z.shape[0])
            except Exception as exc:
                if debug:
                    print("spglib reduction failed; using unreduced cell:", exc)

        # Species channels
        if per_species:
            species, inv = np.unique(Z, return_inverse=True)  # sorted ascending
            C = int(species.shape[0])
        else:
            species = np.array([0], dtype=np.int32)
            inv = np.zeros(N, dtype=np.int32)
            C = 1

        # Accumulate structure factors S per species and per mode
        S_re = np.zeros((C, M_count), dtype=np.float64)
        S_im = np.zeros((C, M_count), dtype=np.float64)

        for s in range(0, N, max(1, int(chunk_size))):
            e = min(N, s + chunk_size)
            Fi = F[s:e]  # (chunk, 3)
            inv_i = inv[s:e]  # (chunk,)
            phase = TWO_PI * (Fi @ M_T)  # (chunk, M)
            Ei_re = np.cos(phase)
            Ei_im = np.sin(phase)
            for m in range(M_count):
                S_re[:, m] += np.bincount(inv_i, weights=Ei_re[:, m], minlength=C)
                S_im[:, m] += np.bincount(inv_i, weights=Ei_im[:, m], minlength=C)

        # Normalize per species
        Nz = np.bincount(inv, minlength=C).astype(np.float64)
        denom = np.sqrt(np.maximum(Nz, 1.0))[:, None]
        P = np.hypot(S_re, S_im) / denom  # (C, M)

        # -------- Rotational invariance via spherical shell averaging ----------
        # For each shell (fixed r2), average magnitudes across its modes.
        # Result: (C, S) array of shell-averaged magnitudes.
        P_shell = np.zeros((C, S_count), dtype=np.float64)
        for s_idx, r2 in enumerate(unique_r2):
            idx = shell_index[int(r2)]  # indices in 0..M-1
            # mean over modes in this shell; L2-mean or simple mean both OK;
            # we use arithmetic mean (rotation-invariant under permutations).
            P_shell[:, s_idx] = P[:, idx].mean(axis=1)

        # Quantize shell-averaged magnitudes and lattice (rotationally invariant)
        Pq = qint(P_shell, ps_grid)  # (C, S) int32

        # Invariant lattice: lengths and cosines
        abc = np.linalg.norm(A, axis=1)
        An = A / np.maximum(abc[:, None], EPS)
        # alpha is angle between b and c, beta: a and c, gamma: a and b
        cos_abc = np.array(
            [
                np.dot(An[1], An[2]),  # cos(alpha)
                np.dot(An[0], An[2]),  # cos(beta)
                np.dot(An[0], An[1]),  # cos(gamma)
            ]
        )
        A_q = np.concatenate([qint(abc, lattice_grid), qint(cos_abc, 2e-3)]).astype(np.int32)

        v_tick = -1
        if include_volume:
            vpa = abs(np.linalg.det(A)) / max(N, 1)
            if not math.isfinite(vpa):
                v_tick = 10**15
            else:
                v_tick = int(math.floor(vpa / v_grid + 0.5))
                v_tick = max(-(2**60), min(2**60, v_tick))

        # Serialize deterministically:
        # [signature][quantized lattice][species IDs][shells r2][quantized shell spectrum][meta]
        meta = np.array([N, int(species.shape[0]), e_tick, v_tick], dtype="<i8").tobytes()

        return hbytes(
            b"TSFv2_rot\0",
            np.asarray(A_q, dtype="<i4").tobytes(),
            np.asarray(species, dtype="<i4").tobytes(),
            np.asarray(unique_r2, dtype="<i8").tobytes(),  # shell definition
            np.asarray(Pq, dtype="<i4").tobytes(),
            meta,
        )

    return hash_fn


# ---------------------------------------------------------------------------
#  Fastest hash
# ---------------------------------------------------------------------------
def _structure_factor_hash_factory(
    *,
    # Fourier sampling
    kmax: int = 3,
    modes: np.ndarray | None = None,  # custom (M,3) integer modes; overrides kmax when given
    per_species: bool = True,  # accumulate |S| per atomic number channel
    ps_grid: float = 1e-1,  # quantization grid for |S| magnitudes
    # Lattice / metadata quantization
    lattice_grid: float = 2e-2,  # Å
    e_grid: float = 1e-3,  # eV/atom (optional tick)
    v_grid: float = 1e-2,  # Å^3/atom (optional tick)
    include_energy: bool = True,
    include_volume: bool = True,
    # Symmetry reduction (optional; not needed for translation invariance)
    use_spglib: bool = False,
    symprec: float = 1e-3,
    angle_tolerance: float = -1.0,
    # Performance / numerical robustness
    chunk_size: int = 50000,  # number of atoms per chunk in accumulation
    debug: bool = False,
    **kwargs,
) -> Callable[[object], str]:
    """
    Factory for a fast, translation-invariant global hash based on the modulus
    of structure factors on a small set of integer reciprocal modes.

    Mathematical idea
    ------------------
    For a periodic structure with fractional coordinates F ∈ [0,1)^{N×3},
    the (unnormalized) structure factor on an integer mode m ∈ Z^3 is:
        S(m) = Σ_i exp(i 2π m·F_i).
    A rigid translation by t (fractional) sends F_i → F_i + t, hence
        S'(m) = exp(i 2π m·t) S(m),
    so the modulus |S(m)| is *exactly translation invariant*. We compute |S|
    on a small, fixed set of modes (a sphere in Z^3 of radius kmax), optionally
    per species, lightly quantize, and hash the integer tensor.

    Complexity and scaling
    ----------------------
    The computation is O(N * M) where M is the number of modes (dozens to low
    hundreds). This scales linearly in N and is robust for N >> 10^3. We process
    atoms in chunks to bound memory usage.

    Assumptions
    -----------
    The container exposes `AtomPositionManager` (APM) with:
      - `atomPositions` (Cartesian, shape (N,3), floats, current),
      - `latticeVectors` (3×3, your codebase stores as *columns* a,b,c),
      - `get_atomic_numbers()` → (N,) array-like of ints,
      - optional `.E` (total energy).
    We do not rely on cached fractional coordinates; we recompute them from the
    *current* Cartesian positions and the lattice each call.

    Parameters
    ----------
    kmax : int
        Sphere radius in integer reciprocal space (controls M).
    modes : np.ndarray, optional
        Custom integer modes (M,3). If given, kmax is ignored.
    per_species : bool
        If True, produce a channel per atomic number (more discriminative).
        If False, aggregate all atoms together (faster/shorter descriptor).
    ps_grid : float
        Quantization grid for |S| magnitudes (pre-hash integerization).
    lattice_grid : float
        Quantization grid for lattice (Å).
    e_grid, v_grid : float
        Quantization grids for energy/atom and volume/atom ticks.
    include_energy, include_volume : bool
        Whether to append E/N and V/N ticks (integerized).
    use_spglib : bool
        If True, reduce to a primitive cell (origin independent). Not required
        for translation invariance; may be desired for supercell/setting invariance.
    symprec, angle_tolerance : float
        spglib tolerances.
    chunk_size : int
        Chunk length for the per-mode accumulation loop. Increase for speed
        if RAM allows; decrease to reduce memory footprint.
    debug : bool
        Print failures or shapes when helpful.

    Returns
    -------
    Callable[[object], str]
        A function `hash_fn(container) -> hex_string` producing a SHA-256 digest.
    """
    TWO_PI = 2.0 * math.pi
    EPS = 1e-12  # small offset to avoid hitting exactly 0/1 after modulo

    # Build / validate reciprocal modes
    if modes is None:
        M = _build_integer_modes_sphere(kmax)
    else:
        M = np.asarray(modes, dtype=np.int32)
        if M.ndim != 2 or M.shape[1] != 3 or M.shape[0] == 0:
            raise ValueError("modes must have shape (M,3) with M>0")
        # Make deterministic: sort lexicographically
        M = M[np.lexsort((M[:, 2], M[:, 1], M[:, 0]))]
    M_T = M.T  # (3, M)
    M_count = int(M.shape[0])

    # Small helpers
    def qint(x: np.ndarray, grid: float) -> np.ndarray:
        """Quantize to integers with stable half-up rule: floor(x/grid + 0.5)."""
        return np.floor(np.asarray(x, float) / grid + 0.5).astype(np.int32, copy=False)

    def hbytes(*chunks: bytes) -> str:
        h = hashlib.sha256()
        for c in chunks:
            h.update(c)
        return h.hexdigest()

    def tsf_hash(container) -> str:
        apm = container.AtomPositionManager

        # 1) Detect periodicity robustly.
        # 1) Detect periodicity robustly.
        if _is_nonperiodic(apm):
            is_nonpbc = True
        else:
            is_nonpbc = False

        # 2) Basic properties
        Z = np.asarray(apm.get_atomic_numbers(), np.int32)
        N = int(Z.shape[0])
        if N == 0:
            # Empty container → hash a fixed token
            return hbytes(b"TSFv1\0", np.array([0], dtype="<i8").tobytes())

        # 3) Optional global ticks (avoids energy-driven changes by default).
        try:
            E_total = float(getattr(apm, "E", 0.0))
        except Exception:
            E_total = 0.0

        if not include_energy:
            e_tick = -1
        else:
            val = (E_total / N) if N > 0 else 0.0
            if not math.isfinite(val):
                e_tick = 10**15
            else:
                e_tick = int(math.floor(val / e_grid + 0.5))
                e_tick = max(-(2**60), min(2**60, e_tick))

        # 4) Non-PBC fallback: translation- and rotation-invariant signature
        if is_nonpbc:
            X = np.asarray(apm.atomPositions, float)
            N_tot = X.shape[0]
            if N_tot < 2:
                # Single atom or empty: use species only
                meta = np.array([N, e_tick, -1], dtype="<i8").tobytes()
                return hbytes(b"TSFv1\0", np.asarray(Z, dtype="<i4").tobytes(), meta)

            # Fast rotationally invariant signature: pairwise distance spectrum per species
            dists = []
            species_list = np.unique(Z)
            for i in range(C_species := len(species_list)):
                mask = Z == species_list[i]
                Xi = X[mask]
                if Xi.shape[0] > 1:
                    d = np.linalg.norm(Xi[:, None] - Xi[None, :], axis=-1)
                    dists.append(np.sort(qint(d[np.tril_indices(Xi.shape[0], k=-1)], lattice_grid)))

            # Cross-species distances
            for i in range(C_species):
                for j in range(i + 1, C_species):
                    mask1 = Z == species_list[i]
                    mask2 = Z == species_list[j]
                    X1, X2 = X[mask1], X[mask2]
                    d = np.linalg.norm(X1[:, None] - X2[None, :], axis=-1)
                    dists.append(np.sort(qint(d.ravel(), lattice_grid)))

            meta = np.array([N, e_tick, -1], dtype="<i8").tobytes()
            payload = [b"TSFv1\0"]
            for d in dists:
                payload.append(d.tobytes())
            payload.append(meta)
            return hbytes(*payload)

        # 5) PBC path: recompute fractionals from current Cartesian + lattice.
        A_cols = np.asarray(apm.latticeVectors, float)  # your APM stores columns a,b,c
        A = A_cols.T  # rows (a,b,c) for math
        X = np.asarray(apm.atomPositions, float)  # current Cartesian
        try:
            FinvT = np.linalg.inv(A).T
            F = (X @ FinvT + EPS) % 1.0  # fractional coords ∈ [0,1)
        except np.linalg.LinAlgError:
            # Fallback for singular lattice that reached here
            F = np.zeros_like(X)

        # Optional: primitive/setting reduction (origin-independent)
        if use_spglib:
            try:
                import spglib

                A_s, F_s, Z_s = spglib.standardize_cell(
                    (A.copy(), F.copy(), Z.copy()),
                    to_primitive=True,
                    no_idealize=True,
                    symprec=symprec,
                    angle_tolerance=angle_tolerance,
                )
                A = np.asarray(A_s, float)
                F = (np.asarray(F_s, float) + EPS) % 1.0
                Z = np.asarray(Z_s, np.int32)
                N = int(Z.shape[0])
            except Exception as exc:
                if debug:
                    print("spglib reduction failed; using unreduced cell:", exc)

        # 6) Prepare species channels (optional but recommended).
        if per_species:
            species, inv = np.unique(Z, return_inverse=True)  # species sorted ascending
            C = int(species.shape[0])
        else:
            species = np.array([0], dtype=np.int32)
            inv = np.zeros(N, dtype=np.int32)
            C = 1

        # 7) Accumulate structure factors S per species and per mode.
        #    S_re, S_im have shape (C, M); we sum in float64 for stability.
        S_re = np.zeros((C, M_count), dtype=np.float64)
        S_im = np.zeros((C, M_count), dtype=np.float64)

        # Chunked accumulation to keep memory bounded: (chunk×3) @ (3×M) = (chunk×M)
        for s in range(0, N, max(1, int(chunk_size))):
            e = min(N, s + chunk_size)
            Fi = F[s:e]  # (chunk, 3)
            inv_i = inv[s:e]  # (chunk,)
            phase = TWO_PI * (Fi @ M_T)  # (chunk, M)
            Ei_re = np.cos(phase)  # (chunk, M)
            Ei_im = np.sin(phase)  # (chunk, M)

            # Accumulate by species using bincount per mode (fast and vectorized).
            # Loop over modes only (typically ~100), not over atoms.
            for m in range(M_count):
                S_re[:, m] += np.bincount(inv_i, weights=Ei_re[:, m], minlength=C)
                S_im[:, m] += np.bincount(inv_i, weights=Ei_im[:, m], minlength=C)

        # 8) Normalize per species to keep the descriptor scale-stable with N.
        Nz = np.bincount(inv, minlength=C).astype(np.float64)  # #atoms per species
        denom = np.sqrt(np.maximum(Nz, 1.0))[:, None]  # (C, 1)
        P = np.hypot(S_re, S_im) / denom  # (C, M), translation-invariant

        # 9) Quantize magnitudes and lattice (rotationally invariant representation)
        Pq = qint(P, ps_grid)  # (C, M) int32

        # Invariant lattice representation: a, b, c, cos(alpha), cos(beta), cos(gamma)
        abc = np.linalg.norm(A, axis=1)
        An = A / np.maximum(abc[:, None], EPS)
        cos_abc = np.array(
            [
                np.dot(An[1], An[2]),  # cos(alpha)
                np.dot(An[0], An[2]),  # cos(beta)
                np.dot(An[0], An[1]),  # cos(gamma)
            ]
        )
        A_q = np.concatenate([qint(abc, lattice_grid), qint(cos_abc, 2e-3)]).astype(np.int32)

        v_tick = -1
        if include_volume:
            vpa = abs(np.linalg.det(A)) / max(N, 1)
            if not math.isfinite(vpa):
                v_tick = 10**15
            else:
                v_tick = int(math.floor(vpa / v_grid + 0.5))
                v_tick = max(-(2**60), min(2**60, v_tick))

        # Serialize deterministically:
        # [signature][quantized lattice][species IDs][quantized spectrum][meta]
        # meta = [N, #channels, e_tick, v_tick]
        meta = np.array([N, int(species.shape[0]), e_tick, v_tick], dtype="<i8").tobytes()

        return hbytes(
            b"TSFv1\0",
            np.asarray(A_q, dtype="<i4").tobytes(),
            np.asarray(species, dtype="<i4").tobytes(),
            np.asarray(Pq, dtype="<i4").tobytes(),
            meta,
        )

    return tsf_hash


# ------------------------- ROBUST (lattice+KDTree) --------------------------
def _robust_hash_factory(
    *,
    pos_grid: float = 2e-5,
    lat_grid: float = 1e-4,
    e_grid: float = 1e-3,
    v_grid: float = 1e-4,
    include_tree: bool = True,
    symprec: float = 1e-5,
    debug: bool = False,
    **kwargs,
) -> Callable[[Any], str]:
    """Returns a hashing function bound to the supplied parameters."""

    def _robust_hash(container) -> str:
        apm = container.AtomPositionManager
        Z = np.asarray(apm.get_atomic_numbers(), int)
        if len(Z) == 0:
            return hashlib.sha256(b"ROBUST_ZERO").hexdigest()

        is_nonpbc = _is_nonperiodic(apm)
        if is_nonpbc:
            # Cluster mode: centered Cartesian coords
            X = np.asarray(apm.atomPositions, float)
            Xc = X - X.mean(axis=0)
            Xq = np.round(Xc / pos_grid) * pos_grid
            order = np.lexsort((Xq[:, 2], Xq[:, 1], Xq[:, 0], Z))
            Xq = Xq[order]
            Z_sorted = Z[order]
            coord_s = ";".join(
                f"{Z_sorted[i]}:{Xq[i, 0]:.5f},{Xq[i, 1]:.5f},{Xq[i, 2]:.5f}" for i in range(len(Z_sorted))
            )
            fp = f"CLUSTER|{coord_s}"
            return hashlib.sha256(fp.encode()).hexdigest()

        apm.wrap()
        lat0 = np.asarray(apm.latticeVectors, float)
        try:
            frac0 = np.asarray(apm.atomPositions_fractional, float)
        except (AttributeError, Exception):
            try:
                FinvT = np.linalg.inv(lat0).T
                X = np.asarray(apm.atomPositions, float)
                frac0 = (X @ FinvT) % 1.0
            except np.linalg.LinAlgError:
                # Degenerate lattice but not marked as non-periodic?
                # Fallback to zeros or something stable
                frac0 = np.zeros_like(apm.atomPositions)

        # Canonical primitive cell where possible
        cell = (lat0.copy(), frac0.copy(), Z.copy())
        try:
            lat, frac, Z = spglib.standardize_cell(cell, to_primitive=True, no_idealize=False, symprec=symprec)
            frac %= 1.0
        except Exception:  # fall back to niggli then original
            try:
                spglib.niggli_reduce(cell, eps=symprec)
                lat, frac, Z = cell
                frac %= 1.0
            except Exception:
                lat, frac = lat0, frac0

        # Quantise lattice & coords
        lat_q = np.round(lat / lat_grid) * lat_grid
        frac_q = np.round(frac / pos_grid) * pos_grid

        # Sort deterministically
        order = np.lexsort((frac_q[:, 2], frac_q[:, 1], frac_q[:, 0], Z))
        Z = Z[order]
        frac_q = frac_q[order]

        # Energy/volume per atom
        try:
            epa = float(apm.E) / len(Z)
        except Exception:
            epa = 0.0
        epa_q = round(epa / e_grid) * e_grid
        vpa_q = round((abs(np.linalg.det(lat_q)) / len(Z)) / v_grid) * v_grid

        # Fingerprint string
        lat_s = ",".join(f"{x:.8f}" for x in lat_q.flatten())
        coord_s = ";".join(f"{Z[i]}:{frac_q[i, 0]:.8f},{frac_q[i, 1]:.8f},{frac_q[i, 2]:.8f}" for i in range(len(Z)))
        fp = f"{lat_s}|{coord_s}|E{epa_q:.5f}|V{vpa_q:.5f}"

        # Optional KD‑tree serialisation
        if include_tree:
            try:
                apm.kdtree = None
                apm.build_kdtree(verbose=False)
                fp += "|TREE:" + _serialize_kdtree(apm.kdtree)
            except Exception as exc:
                if debug:
                    print("KD‑tree failure:", exc)
                fp += "|TREE:ERROR"
            finally:
                apm.kdtree = None

        return hashlib.sha256(fp.encode()).hexdigest()

    return _robust_hash


# 2. RDF  ────────────────────────────────────────────────────────────────────
def _rdf_hash_factory(
    *,
    r_max: float = 10.0,
    bin_width: float = 0.02,
    density_grid: float = 1e-4,
    e_grid: float = 1e-2,
    v_grid: float = 1e-2,
    symprec: float = 1e-3,
    debug: bool = False,
    **kwargs,
) -> Callable[[Any], str]:
    # Precompute bin edges once
    edges = np.linspace(0.0, r_max, int(math.ceil(r_max / bin_width)) + 1)
    nbins = len(edges) - 1

    def _bin_index(d: float) -> int:
        """Right-closed binning; excludes exactly d == r_max."""
        idx = np.searchsorted(edges, d, side="right") - 1
        return idx if 0 <= idx < nbins else -1

    def _rdf_hash(container) -> str:
        apm = container.AtomPositionManager

        # Detect PBC early to avoid wrapping clusters
        is_nonpbc = _is_nonperiodic(apm)
        if not is_nonpbc:
            apm.wrap()

        n_total = len(apm.get_atomic_numbers())
        try:
            epa = float(apm.E) / max(n_total, 1)
        except Exception:
            epa = 0.0
        # quantize energy-per-atom
        epa_q = np.floor(epa / e_grid + 0.5) * e_grid

        # Canonicalise the cell/coords/atomic numbers
        lat, frac_or_cart, Z = _canonical_cell(apm, symprec, debug)
        Z = np.asarray(Z, dtype=int)
        N = len(Z)

        # Volume field
        if is_nonpbc or lat is None:
            v_field = "V:NA"
        else:
            vpa = abs(np.linalg.det(lat)) / max(N, 1)
            vpa_q = np.floor(vpa / v_grid + 0.5) * v_grid
            v_field = f"V{vpa_q:.5f}"

        # Trivial cases: N==0 or 1
        if N < 2:
            fp = f"SINGLE|E{epa_q:.5f}|{v_field}"
            return hashlib.sha256(fp.encode()).hexdigest()

        # Cartesian coordinates
        if is_nonpbc or lat is None:
            cart = np.asarray(frac_or_cart, float)
            # optional: center cluster for tree determinism
            cart = cart - cart.mean(axis=0)
        else:
            frac = np.asarray(frac_or_cart, float)
            cart = frac @ lat.T

        # Build RDF histograms (keyed by species pair "a-b")
        rdf: dict[str, np.ndarray] = defaultdict(lambda: np.zeros(nbins, dtype=np.float64))
        norm = 1.0 / (N * (N - 1) / 2.0)  # normalize by # unique pairs

        if is_nonpbc or lat is None:
            # Pure Euclidean neighbors (no PBC)
            from scipy.spatial import cKDTree

            tree = cKDTree(cart)
            # One-shot neighbor list for all points
            nbr_lists = tree.query_ball_tree(tree, r_max, p=2.0, eps=0.0)
            for i, nbrs in enumerate(nbr_lists):
                for j in nbrs:
                    if j <= i:
                        continue
                    d = float(np.linalg.norm(cart[i] - cart[j]))
                    b = _bin_index(d)
                    if b >= 0:
                        aZ, bZ = sorted((Z[i], Z[j]))
                        rdf[f"{aZ}-{bZ}"][b] += norm
        else:
            # Periodic neighbor discovery (assumes PBC-aware tree & distances)
            sr = SingleRun()
            apm_primitive = sr.AtomPositionManager
            apm_primitive.configure(cart, Z, lat)  # builds periodic kdtree
            tree = apm_primitive.kdtree

            # Loop over each atom i and query neighbours within r_max (Cartesian)
            for i, ri in enumerate(cart):
                nbrs = tree.query_ball_point(ri, r_max)

                for j in nbrs:
                    if j <= i:
                        continue  # ensure each unordered pair is counted once

                    d = apm_primitive.distance(cart[i], cart[j])
                    bin_idx = int(d // bin_width)
                    if bin_idx < nbins:
                        pair = tuple(sorted((Z[i], Z[j])))
                        key = f"{pair[0]}-{pair[1]}"
                        rdf[key][bin_idx] += norm
                print
        # Quantize histogram densities and assemble fingerprint
        parts = []
        for key in sorted(rdf):
            rounded = np.floor(rdf[key] / density_grid + 0.5) * density_grid
            parts.append(f"{key}:{','.join(f'{x:.6f}' for x in rounded)}")

        fp = "|".join(parts) + f"|E{epa_q:.5f}|{v_field}"

        return hashlib.sha256(fp.encode()).hexdigest()

    return _rdf_hash


def _pair_distance_hash_factory(
    *,
    quant_grid: float = 1e-3,
    include_volume: bool = True,
    include_energy: bool = True,
    v_grid: float = 1e-2,
    e_grid: float = 1e-3,
    debug: bool = False,
    **kwargs,
) -> Callable[[Any], str]:
    """
    Extremely simple, brute-force O(N^2) descriptor:
    - Compute all pairwise interatomic distances (Cartesian).
    - Quantize and sort them.
    - Hash the resulting vector.
    """
    import hashlib

    import numpy as np

    def _pairdist_hash(container) -> str:
        apm = container.AtomPositionManager
        try:
            coords = np.asarray(apm.atomPositions, float)
        except Exception:
            coords = np.asarray(apm.get_atomPositions_cartesian(), float)
        n = len(coords)
        if n < 2:
            return hashlib.sha256(b"empty").hexdigest()

        # Compute all unique pair distances
        diff = coords[:, None, :] - coords[None, :, :]
        dists = np.linalg.norm(diff, axis=-1)
        tril = dists[np.tril_indices(n, k=-1)]
        tril_q = np.floor(tril / quant_grid + 0.5) * quant_grid
        tril_q.sort()

        # Optionally add E/N and V/N ticks
        parts = [f"{x:.4f}" for x in tril_q.tolist()]
        meta = []
        if include_energy:
            E = getattr(apm, "E", 0.0) or 0.0
            meta.append(f"E{E / n / e_grid:.3f}")
        if include_volume:
            try:
                lat = np.asarray(apm.latticeVectors, float)
                V = abs(np.linalg.det(lat))
                meta.append(f"V{V / n / v_grid:.3f}")
            except Exception:
                meta.append("V:NA")

        fp = "|".join(parts + meta)
        return hashlib.sha256(fp.encode()).hexdigest()

    return _pairdist_hash


# 2b ----------------------------- SOAP placeholder ---------------------------
def _soap_hash_factory(*, debug: bool = False, **kw) -> Callable[[Any], str]:
    try:
        from dscribe.descriptors import SOAP  # noqa: F401  (optional)
    except (ModuleNotFoundError, ImportError) as exc:
        raise NotImplementedError(
            "SOAP hashing requires `dscribe` and compatible dependencies – install it or choose another method"
        ) from exc

    # … (Set up descriptor here) …
    def _soap_hash(container) -> str:  # pragma: no cover – stub
        raise NotImplementedError

    return _soap_hash


# 3. RBF (requires get_RBF) ────────────────────────────────────────────────


def _rbf_hash_factory(
    *,
    number_of_bins: int = 200,
    bin_volume_normalize: bool = False,
    number_of_atoms_normalize: bool = False,
    density_normalize: bool = False,
    e_grid: float = 1e-2,
    v_grid: float = 1e-2,
    symprec: float = 1e-3,
    debug: bool = False,
    **kwargs,
) -> Callable[[Any], str]:
    def _rbf_hash(container) -> str:
        apm = container.AtomPositionManager
        apm.wrap()
        rbf = {}
        try:
            rbf = apm.get_RBF(
                number_of_bins=number_of_bins,
                bin_volume_normalize=bin_volume_normalize,
                number_of_atoms_normalize=number_of_atoms_normalize,
                density_normalize=density_normalize,
            )
        except Exception as exc:
            if debug:
                print("RBF fail", exc)
        parts = []
        for sp1 in sorted(rbf):
            for sp2 in sorted(rbf[sp1]):
                h = np.array(rbf[sp1][sp2], float).ravel()
                hq = np.round(h / symprec) * symprec
                parts.append(f"{sp1}-{sp2}:" + ",".join(f"{x:.4f}" for x in hq))
        rbf_s = "|".join(parts)
        Z = apm.get_atomic_numbers()
        N = max(len(Z), 1)
        E = getattr(apm, "E", 0.0)
        if E is None:
            E = 0.0
        epa_q = round(float(E) / N / e_grid) * e_grid
        vpa_q = round(abs(np.linalg.det(apm.latticeVectors)) / N / v_grid) * v_grid
        fp = f"{rbf_s}|E{epa_q:.4f}|V{vpa_q:.4f}"
        return hashlib.sha256(fp.encode()).hexdigest()

    return _rbf_hash


# 4. RMSE  ──────────────────────────────────────────────────────────────────
def _rmse_hash_factory(*, symprec: float = 1e-3, debug: bool = False, **kwargs) -> Callable[[Any], str]:
    def _rmse_hash(container) -> str:
        apm = container.AtomPositionManager
        apm.wrap()
        lat, frac, Z = _canonical_cell(apm, symprec, debug)
        lat_q = np.round(lat / symprec) * symprec
        frac_q = np.round(frac / symprec) * symprec
        order = np.lexsort((frac_q[:, 2], frac_q[:, 1], frac_q[:, 0], Z))
        E = getattr(apm, "E", 0.0)
        E = E if E is not None else 0.0
        vec = np.concatenate((lat_q.flatten(), frac_q[order].flatten(), [round(float(E) / symprec) * symprec]))
        return hashlib.sha256(",".join(f"{x:.6f}" for x in vec).encode()).hexdigest()

    return _rmse_hash


# 5. BASIN (similarity clustering) ─────────────────────────────────────────
class _BasinManager:
    """Per‑composition similarity basins using vector KD‑Tree."""

    def __init__(self, symprec: float = 1e-3, tol: float = 1e-2, include_E: bool = True):
        self.symprec = symprec
        self.tol = tol
        self.include_E = include_E
        self._vecs: dict[str, list[np.ndarray]] = {}
        self._trees: dict[str, cKDTree | None] = {}
        self._hashes: dict[str, list[str]] = {}

    def _vector(self, container) -> np.ndarray:
        apm = container.AtomPositionManager
        apm.wrap()
        lat, frac, Z = _canonical_cell(apm, self.symprec, False)
        lat_q = np.round(lat / self.symprec) * self.symprec
        frac_q = np.round(frac / self.symprec) * self.symprec
        order = np.lexsort((frac_q[:, 2], frac_q[:, 1], frac_q[:, 0], Z))
        vec = np.concatenate((lat_q.flatten(), frac_q[order].flatten()))
        if self.include_E:
            vec = np.append(vec, round(float(getattr(apm, "E", 0.0)) / self.symprec) * self.symprec)
        return cast(np.ndarray, vec)

    @staticmethod
    def _hash_from_vec(vec: np.ndarray) -> str:
        return hashlib.sha256(vec.tobytes()).hexdigest()

    def add(self, comp_key: str, container) -> tuple[str, bool]:
        vec = self._vector(container)
        # first time this composition?
        if comp_key not in self._vecs:
            self._vecs[comp_key] = [vec]
            self._trees[comp_key] = cKDTree(np.vstack([vec]))
            h = self._hash_from_vec(vec)
            self._hashes[comp_key] = [h]
            return h, True
        tree = self._trees[comp_key]
        assert tree is not None
        dist, idx = tree.query(vec, k=1)
        if dist <= self.tol:
            return self._hashes[comp_key][idx], False
        # new basin
        self._vecs[comp_key].append(vec)
        self._trees[comp_key] = cKDTree(np.vstack(self._vecs[comp_key]))
        h = self._hash_from_vec(vec)
        self._hashes[comp_key].append(h)
        return h, True


# factory returns (basin_manager, function)


def _basin_factory(*, symprec: float = 1e-3, tol: float = 1e-2, debug: bool = False):
    manager = _BasinManager(symprec, tol)

    def _basin_hash(container, comp_key: str):
        h, _ = manager.add(comp_key, container)
        return h

    return manager, _basin_hash


# ============================================================================
#  Public manager class
# ============================================================================
# ------------------------- ROBUST (lattice+KDTree) --------------------------
class Structure_Hash_Map(IHash):
    """Container‑level manager with user‑selectable hashing method."""

    _FACTORIES: dict[str, Callable[..., Callable[[Any], str]]] = {
        "robust": _robust_hash_factory,
        "rdf": _rdf_hash_factory,
        "soap": _soap_hash_factory,
        "rbf": _rbf_hash_factory,
        "rmse": _rmse_hash_factory,
        "tsf": _structure_factor_hash_factory,
        "tsfr": _structure_factor_hash_factory_rotinv,
    }

    def __init__(self, method: str = "tsf", **kwargs):
        # print(f"DEBUG: Structure_Hash_Map initialized with method='{method}'")
        method = method.lower()
        if method not in self._FACTORIES:
            raise ValueError(f"Unknown hashing method '{method}'.")

        # Keep a copy of the factory kwargs for ensemble variants
        self._method = method
        self._factory_kw = dict(kwargs)

        # Voting parameters
        self._vote_frac = float(kwargs.get("vote_frac", 0.5))
        self._min_votes = int(kwargs.get("min_votes", 1))
        self._scales = kwargs.get("precision_scales", (1.0,))
        if not isinstance(self._scales, (list, tuple)):
            self._scales = (self._scales,)
            
        # Ensure 1.0 is in scales if we want it as base, but for ensemble we use what's provided
        
        # Build ensemble of hashers
        self._hashers = []
        for s in self._scales:
            kw = self._scale_params(self._factory_kw, s)
            self._hashers.append(self._FACTORIES[method](**kw))
            
        self._hash_map: dict[str, set[str]] = {}

    def _scale_params(self, kw_base: dict, scale: float) -> dict:
        kw = dict(kw_base)
        # Grid parameters to scale
        if self._method == "rdf":
            if "bin_width" in kw:
                kw["bin_width"] = kw["bin_width"] * scale
            if "density_grid" in kw:
                kw["density_grid"] = kw["density_grid"] * scale
        elif self._method == "robust":
            for k in ["pos_grid", "lat_grid", "e_grid", "v_grid"]:
                if k in kw:
                    kw[k] = kw[k] * scale
        elif self._method in ["rbf", "rmse"]:
            if "symprec" in kw:
                kw["symprec"] = kw["symprec"] * scale
        elif self._method in ["tsf", "tsfr"]:
            for k in ["ps_grid", "lattice_grid", "e_grid", "v_grid"]:
                if k in kw:
                    kw[k] = kw[k] * scale
        return kw

    def _hash_fn(self, container: Any) -> str:
        """Composite hash from all scales."""
        hashes = [hasher(container) for hasher in self._hashers]
        return "|".join(hashes)

    def vote_duplicate(
        self, 
        container: IIndividual, 
        expected_hash: str | None = None, 
        vote_frac: float | None = None, 
        min_votes: int | None = None
    ) -> tuple[bool, int, int]:
        """
        Computes hashes at multiple precision scales. Returns (is_duplicate, votes_agree, total_votes).
        """
        frac = vote_frac if vote_frac is not None else self._vote_frac
        min_v = min_votes if min_votes is not None else self._min_votes
        
        current_hashes = [hasher(container) for hasher in self._hashers]
        total = len(current_hashes)
        
        if expected_hash is None:
            # If no expected hash, we check against the map? 
            # But which one? Usually this is called when we have a hit.
            return False, 0, total
            
        # expected_hash is assumed to be composite "|".join(hashes)
        target_hashes = expected_hash.split("|")
        
        votes = 0
        for i in range(min(len(current_hashes), len(target_hashes))):
            if current_hashes[i] == target_hashes[i]:
                votes += 1
                
        is_duplicate = (votes >= min_v) and (votes / total >= frac)
        return is_duplicate, votes, total

    def add_structure_voted(
        self, 
        container: IIndividual, 
        *, 
        force_rehash: bool = True, 
        vote_frac: float | None = None, 
        min_votes: int | None = None
    ) -> dict[str, Any]:
        """
        Voted version of add_structure. Returns a report dict.
        """
        apm = container.AtomPositionManager
        comp_key = self._composition_key(apm.atomCountDict)
        hash_ = self.get_hash(container, force_rehash=force_rehash)
        
        bucket = self._hash_map.setdefault(comp_key, set())
        
        if hash_ not in bucket:
            bucket.add(hash_)
            return {
                "added": True,
                "duplicate": False,
                "collision": False,
                "hash": hash_,
                "votes_agree": 0,
                "votes_total": 0,
                "comp_key": comp_key
            }
        
        # Potential duplicate found by base hash; verify with voting
        is_dup, agree, total = self.vote_duplicate(container, expected_hash=hash_, vote_frac=vote_frac, min_votes=min_votes)
        
        if is_dup:
            return {
                "added": False,
                "duplicate": True,
                "collision": False,
                "hash": hash_,
                "votes_agree": agree,
                "votes_total": total,
                "comp_key": comp_key
            }
        else:
            # Collision detected! (Same base hash, but voting says they are different)
            # In this case, we still add it? Or mark it as collision.
            # Usually, if it's a collision, we might want to modify the hash to be unique.
            # For now, let's just report it.
            return {
                "added": False,
                "duplicate": False,
                "collision": True,
                "hash": hash_,
                "votes_agree": agree,
                "votes_total": total,
                "comp_key": comp_key
            }

    def get_hash(
        self,
        container: IIndividual,
        force_rehash: bool = True,
    ) -> str:
        """ """
        apm = container.AtomPositionManager
        # apm.metadata = getattr(apm, "metadata", {}) or {}
        # 1.  Group structures by elemental composition
        self._composition_key(apm.atomCountDict)

        # 2.  Decide whether a new hash is required
        apm_metadata = getattr(apm, "metadata", {}) or {}
        stored_hash = apm_metadata.get("hash", None)
        hash_ = self._hash_fn(container) if force_rehash or stored_hash is None else stored_hash

        # 3.  Ensure a metadata dict exists and persist the hash
        apm.metadata = apm_metadata
        apm.metadata["hash"] = hash_

        return hash_

    # -------------- public API identical to previous classes ---------------
    def add_structure(
        self,
        container: IIndividual,
        force_rehash: bool = True,
    ) -> bool:
        """
        Insert *container* into the internal hash map, optionally forcing a fresh
        hash calculation.

        Parameters
        ----------
        container : Structure
            Object whose ``AtomPositionManager`` exposes
            ``atomCountDict``, ``info_system`` and ``metadata`` attributes.
        force_rehash : bool, optional
            If *True* (default), compute a new hash even when one is already stored
            under ``info_system['hash']``.  If *False*, reuse the stored hash when
            available.

        Returns
        -------
        bool
            ``True``  – the structure was not present and has been added.
            ``False`` – an identical structure (same hash within the same
            composition bucket) already existed.
        """
        apm = container.AtomPositionManager

        # 1.  Group structures by elemental composition
        comp_key = self._composition_key(apm.atomCountDict)

        hash_ = self.get_hash(container=container, force_rehash=force_rehash)

        # 4.  Deduplicate within the composition bucket
        bucket = self._hash_map.setdefault(comp_key, set())
        if hash_ in bucket:
            return False  # already known
        bucket.add(hash_)
        return True

    def already_visited(self, container) -> bool:
        comp_key = self._composition_key(container.AtomPositionManager.atomCountDict)
        if comp_key not in self._hash_map:
            return False
        return self._hash_fn(container) in self._hash_map[comp_key]

    # ---------------------- utility helpers ---------------------------------

    @staticmethod
    def _composition_key(comp: dict) -> str:
        """
        Return a deterministic, reduced-formula key such as 'C1-H1-N1-O2'
        for any integer multiple - e.g. both {'C':2,'H':2,'N':2,'O':4}
        and {'C':6,'H':6,'N':6,'O':12} collapse onto the same key.

        • Counts **must** be non-negative integers.  If you store floats,
          cast/round them beforehand.
        • Element order is alphabetical to keep the key canonical.
        """
        if not comp:
            # Handle empty structures (e.g., during evolution steps where all atoms are removed)
            # to prevent reduce() from failing on an empty sequence.
            return "EMPTY"

        counts = [int(comp[el]) for el in comp]

        # reduce needs at least one element. gcd of a single number is itself.
        g = reduce(gcd, counts) if len(counts) > 0 else 1
        g = g or 1  # Avoid division by zero if all counts are somehow 0

        return "-".join(
            f"{el}{int(comp[el] // g)}"  # always include ‘1’
            for el in sorted(comp)
        )

    # Alias for backward compatibility
    _comp_key = _composition_key

    def get_num_structures_for_composition(self, comp: dict) -> int:
        return len(self._hash_map.get(self._composition_key(comp), ()))

    def total_compositions(self) -> int:
        return len(self._hash_map)

