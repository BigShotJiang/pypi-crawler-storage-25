from __future__ import annotations
"""
mutation.py
-----------

Implements functions that mutate structures by changing atom types, adding or removing
solvents, etc.
"""

import copy
import os
import numpy as np
import logging
from sage_lib.partition.Partition import Partition
from ezga.utils.helper_functions import validate
from ezga.utils.molecule_blacklist import FragmentFinder, build_radius_graph, build_bond_graph, build_env, CUTOFF_MAX
logger = logging.getLogger(__name__)


from typing import List, Callable, Tuple, Any, Optional, cast
from .mutation_organic import *
from .mutation_peptides import *
from .mutation_ring import *
from .mutation_docking import *

# --- Geometric Utilities for Mutation ---
from .geo_utils import _apply_pbc_displacement, _distances_to_point, random_rotation_matrix
# --- End Utilities ---


# ------------------------------------------------------------------
#  ------------             constraints                 ---------
# ------------------------------------------------------------------
def component_is_greater_than(component: int, threshold: float):
    """Returns a constraint function that checks if a component is greater than a threshold."""
    component = {'x': 0, 'y': 1, 'z': 2}[component] if isinstance(component, str) else component
    def _check(idx, structure):
        return structure.AtomPositionManager.atomPositions[idx, component] >= threshold
    return _check

def component_is_less_than(component: int, threshold: float):
    """Returns a constraint function that checks if a component is less than a threshold."""
    component = {'x': 0, 'y': 1, 'z': 2}[component] if isinstance(component, str) else component
    def _check(idx, structure):
        return structure.AtomPositionManager.atomPositions[idx, component] < threshold
    return _check

def component_is_in_range(component: int, min_val: float, max_val: float):
    """Checks if component is in [min, max]."""
    component = {'x': 0, 'y': 1, 'z': 2}[component] if isinstance(component, str) else component
    def _check(idx, structure):
        val = structure.AtomPositionManager.atomPositions[idx, component]
        return min_val <= val <= max_val
    return _check

def component_in_range(component: int, min_val: float, max_val: float):
    """Deprecated alias for component_is_in_range."""
    return component_is_in_range(component, min_val, max_val)

def distance_to_origin_is_less_than(threshold: float):
    """Checks if distance to origin is less than threshold."""
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        return np.linalg.norm(pos) < threshold
    return _check

def distance_to_origin_is_greater_than(threshold: float):
    """Checks if distance to origin is greater than threshold."""
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        return np.linalg.norm(pos) > threshold
    return _check

def distance_from_origin_less_than(threshold: float):
    """Deprecated alias for distance_to_origin_is_less_than."""
    return distance_to_origin_is_less_than(threshold)

def distance_from_origin_greater_than(threshold: float):
    """Deprecated alias for distance_to_origin_is_greater_than."""
    return distance_to_origin_is_greater_than(threshold)

def component_is_close_to_value(component: int, target: float, tolerance: float):
    """Checks if a component is within target +/- tolerance."""
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        return abs(pos[component] - target) < tolerance
    return _check

def component_close_to_value(component: int, target: float, tolerance: float):
    """Deprecated alias for component_is_close_to_value."""
    return component_is_close_to_value(component, target, tolerance)

def species_is_in(species_set: set | list):
    """Returns a constraint function that checks if an atom species is in the given set."""
    if isinstance(species_set, list):
        species_set = set(species_set)
    def _check(idx, structure):
        apm = structure.AtomPositionManager
        if hasattr(apm, "get_elements"):
            elements = apm.get_elements()
            if isinstance(elements, (list, np.ndarray, tuple)):
                return elements[idx] in species_set
        if hasattr(apm, "atomLabelsList"):
            labels = apm.atomLabelsList
            if isinstance(labels, (list, np.ndarray, tuple)):
                return labels[idx] in species_set
        return False
    return _check

def species_is(species: str):
    """Returns a constraint function that checks if an atom species matches the given label."""
    def _check(idx, structure):
        apm = structure.AtomPositionManager
        if hasattr(apm, "get_elements"):
            elements = apm.get_elements()
            if isinstance(elements, (list, np.ndarray, tuple)):
                return elements[idx] == species
        if hasattr(apm, "atomLabelsList"):
            labels = apm.atomLabelsList
            if isinstance(labels, (list, np.ndarray, tuple)):
                return labels[idx] == species
        return False
    return _check

def component_ratio_less_than(x_component: int, y_component: int, ratio: float):
    x_component = {'x':0, 'y':1, 'z':2}[x_component] if isinstance(x_component, str) else x_component
    y_component = {'x':0, 'y':1, 'z':2}[y_component] if isinstance(y_component, str) else y_component
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        if abs(pos[y_component]) < 1e-12:  # Avoid division by zero
            return False
        return (pos[x_component] / pos[y_component]) < ratio
    return _check

def component_ratio_greater_than(x_component: int, y_component: int, ratio: float):
    """
    Returns a constraint function that verifies whether the ratio of the specified
    x_component to y_component is greater than a given ratio, for an atom position.

    :param x_component: The component acting as the numerator.
    :param y_component: The component acting as the denominator.
    :param ratio: The ratio threshold.
    :return: A callable that accepts (idx, structure) and returns True or False.
    """
    x_component = {'x':0, 'y':1, 'z':2}[x_component] if isinstance(x_component, str) else x_component
    y_component = {'x':0, 'y':1, 'z':2}[y_component] if isinstance(y_component, str) else y_component
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        if abs(pos[y_component]) < 1e-12:
            return False
        return (pos[x_component] / pos[y_component]) > ratio
    return _check


def distance_to_atom_is_less_than(atom_idx_b: int, threshold: float):
    """Checks if distance between two atoms is less than threshold."""
    def _check(idx, structure):
        pos_a = structure.AtomPositionManager.atomPositions[idx]
        pos_b = structure.AtomPositionManager.atomPositions[atom_idx_b]
        dist_squared = np.sum((pos_a - pos_b)**2)
        return dist_squared < threshold**2
    return _check

def distance_to_atom_is_greater_than(atom_idx_b: int, threshold: float):
    """Checks if distance between two atoms is greater than threshold."""
    def _check(idx, structure):
        pos_a = structure.AtomPositionManager.atomPositions[idx]
        pos_b = structure.AtomPositionManager.atomPositions[atom_idx_b]
        dist_squared = np.sum((pos_a - pos_b)**2)
        return dist_squared > threshold**2
    return _check


def z_greater_than_fraction_of_lattice(fraction: float):
    """
    Returns a constraint function that checks if the z-component of an atom position
    is greater than a specified fraction of the c-lattice vector length.

    :param fraction: Fraction of the c-lattice vector (structure.AtomPositionManager.latticeVectors[2,2]).
    :return: A callable that accepts (idx, structure) and returns True or False.
    """
    def _check(idx, structure):
        c_length = structure.AtomPositionManager.latticeVectors[2, 2]
        z_pos = structure.AtomPositionManager.atomPositions[idx, 2]
        return z_pos > fraction * c_length
    return _check


def x_plus_y_less_than(threshold: float):
    """
    Returns a constraint function that checks if the sum of x- and y-components of
    an atom position is less than the given threshold.

    :param threshold: Sum threshold for x + y.
    :return: A callable that accepts (idx, structure) and returns True or False.
    """
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        return (pos[0] + pos[1]) < threshold
    return _check


def y_minus_z_greater_than(threshold: float):
    """
    Returns a constraint function that checks if the difference (y - z) for an atom
    position exceeds the specified threshold.

    :param threshold: The minimum allowed value for (y - z).
    :return: A callable that accepts (idx, structure) and returns True or False.
    """
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        return (pos[1] - pos[2]) > threshold
    return _check

def component_is_greater_than_sum(components: list, threshold: float):
    """Checks if the sum of components is greater than threshold."""
    for c_i, c in enumerate(components):
        components[c_i] = {'x':0, 'y':1, 'z':2}[c] if isinstance(c, str) else c
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        total = sum(pos[c] for c in components)
        return total > threshold
    return _check

def component_is_less_than_sum(components: list, threshold: float):
    """Checks if the sum of components is less than threshold."""
    for c_i, c in enumerate(components):
        components[c_i] = {'x':0, 'y':1, 'z':2}[c] if isinstance(c, str) else c
    def _check(idx, structure):
        pos = structure.AtomPositionManager.atomPositions[idx]
        total = sum(pos[c] for c in components)
        return total < threshold
    return _check

def position_is_movable():
    """
    Returns a constraint function that checks if the atom is NOT marked as fixed.
    Returns True if atom can move, False if it is fixed.
    """
    def _check(idx, structure):
        ac = getattr(structure.AtomPositionManager, "atomicConstraints", None)
        if ac is None:
            return True
        try:
            v = ac[idx]
        except Exception:
            return True

        if np.isscalar(v) or isinstance(v, (bool, np.bool_, int, np.integer, float, np.floating)):
            return not bool(v)

        try:
            arr = np.asarray(v)
            if arr.ndim == 0:
                return not bool(arr)
            return not bool(np.any(arr))
        except Exception:
            return not bool(v)
    return _check

def position_is_fixed():
    """
    Returns a constraint function that checks if the atom IS marked as fixed.
    Returns True if fixed, False if movable.
    """
    f = position_is_movable()
    return lambda idx, structure: not f(idx, structure)

def atom_is_added():
    """
    Returns a constraint function that checks if the atom was added (atomType == 2).
    """
    def _check(idx, structure):
        ac = getattr(structure.AtomPositionManager, "atomType", None)
        if ac is None:
            return False
        try:
            return int(ac[idx]) == 2
        except Exception:
            return False
    return _check

def atom_is_original():
    """
    Returns True if atom was NOT added.
    """
    f = atom_is_added()
    return lambda idx, structure: not f(idx, structure)


def tag_is(tag: int):
    """
    Returns a constraint function that checks if an atom tag exactly matches the given tag.
    """
    def _check(idx, structure):
        apm = structure.AtomPositionManager
        val = apm.get_types()
        if val is not None:
            try:
                return int(val[idx]) == tag
            except (IndexError, TypeError, ValueError):
                pass
        return False
    return _check

def tag_is_in(tags: list):
    """
    Returns a constraint function that checks if an atom tag is within the provided list.
    """
    if not isinstance(tags, (list, tuple, np.ndarray)):
        tags = [tags]
    tags = [int(t) for t in tags]

    def _check(idx, structure):
        apm = structure.AtomPositionManager
        val = apm.get_types()
        if val is not None:
            try:
                return int(val[idx]) in tags
            except (IndexError, TypeError, ValueError):
                pass
        return False
    return _check


# Standardize on global Partition import
# from your_code.utils import get_element_counts, ...

# ------------------------------------------------------------------
#  ------------                HELPERS                      ---------
# ------------------------------------------------------------------
# ==================== Symmetry-Projection Mutation (CI mode) ====================
# --- internal helpers (minimal, no external deps) --------------------------------
def _kabsch(P, Q):
    """Return rotation R that best aligns P->Q (both centered)."""
    C = P.T @ Q
    V, _, Wt = np.linalg.svd(C)
    d = np.sign(np.linalg.det(V @ Wt))
    D = np.diag([1.0, 1.0, d])
    return V @ D @ Wt

def _wrap_frac(frac):
    """Wrap fractional coords to the range between 0 and 1."""
    return frac - np.floor(frac)

def _cart2frac(cell, xyz):
    """xyz (N,3); cell rows are lattice vectors."""
    return np.linalg.solve(cell.T, xyz.T).T

def _frac2cart(cell, frac):
    return (cell.T @ frac.T).T

def _pairwise_sqdist(A, B):
    """Squared distances between rows of A and B (no PBC)."""
    AA = np.sum(A*A, axis=1)[:, None]
    BB = np.sum(B*B, axis=1)[None, :]
    return AA + BB - 2.0 * (A @ B.T)

def _best_perm_specieswise(X_ref, X_can, species):
    """
    Species-wise assignment: map rows of X_can onto X_ref within each species.
    Tries SciPy Hungarian; falls back to a greedy nearest-neighbor mapping.
    Returns an index array 'perm' so that X_can[perm] ~ X_ref.
    """
    perm = np.arange(len(X_ref))
    try:
        from scipy.optimize import linear_sum_assignment
        out = np.empty_like(perm)
        for sp in np.unique(species):
            I = np.where(species == sp)[0]
            C = _pairwise_sqdist(X_ref[I], X_can[I])
            r, c = linear_sum_assignment(C)
            out[I] = I[c]
        return out
    except Exception:
        # Greedy fallback per species
        out = perm.copy()
        for sp in np.unique(species):
            I = np.where(species == sp)[0]
            if len(I) <= 1:
                continue
            C = _pairwise_sqdist(X_ref[I], X_can[I])
            used = set()
            for j_local, j in enumerate(I):
                # pick nearest unused k in I
                row = C[j_local]
                candidates = [(row[k_local], I[k_local]) for k_local in range(len(I)) if I[k_local] not in used]
                k = min(candidates, key=lambda z: z[0])[1]
                used.add(k)
                out[j] = k
        return out

def _orbit_average_cart(X0, ops, species, max_ops=None):
    """
    Orbit-average in Cartesian space (no PBC).
    For each op: apply, rigidly realign to X0, species-wise permute, then average.
    """
    use_ops = ops if (max_ops is None or max_ops >= len(ops)) else ops[:max_ops]
    com = X0.mean(axis=0)
    X = X0 - com
    acc = np.zeros_like(X)
    for Rop in use_ops:
        Y = X @ Rop.T
        R = _kabsch(Y, X)
        Y_al = Y @ R.T
        perm = _best_perm_specieswise(X, Y_al, species)
        acc += Y_al[perm]
    Xsym = acc / float(len(use_ops))
    return Xsym + com

def _orbit_average_frac(cell, X0, ops, species, max_ops=None):
    """
    Orbit-average in fractional space (PBC-aware wrapping).
    """
    use_ops = ops if (max_ops is None or max_ops >= len(ops)) else ops[:max_ops]
    frac0 = _wrap_frac(_cart2frac(cell, X0))
    acc = np.zeros_like(frac0)
    for Rop in use_ops:
        # apply op in Cartesian, map to frac, wrap
        Yc = X0 @ Rop.T
        Yf = _wrap_frac(_cart2frac(cell, Yc))
        # align in Cartesian to decide permutation (more stable)
        Yc_wrapped = _frac2cart(cell, Yf)
        R = _kabsch(Yc_wrapped - Yc_wrapped.mean(0), X0 - X0.mean(0))
        Yc_al = (Yc_wrapped - Yc_wrapped.mean(0)) @ R.T + X0.mean(0)
        perm = _best_perm_specieswise(X0, Yc_al, species)
        acc += Yf[perm]
    fracsym = _wrap_frac(acc / float(len(use_ops)))
    return _frac2cart(cell, fracsym)

# ----------------- small helper: common operator sets -----------------
def random_rattle(structure, species:list=[], std:float=1, constraints:list=[], seed:int=42, verbose:bool=False, components:list=[0,1,2], rng: np.random.Generator | None = None):
    r"""
    Apply a constrained random displacement ("rattle") to selected atoms.

    This mutation perturbs the positions of a subset of atoms by adding Gaussian 
    noise only along specified Cartesian components, subject to user-provided constraints.

    **Steps**:

    1. **Build component mask**  
       Convert any string labels in ``components`` to their integer indices  
       (``0\!\to\!x``, ``1\!\to\!y``, ``2\!\to\!z``).  
       ```python
       components = [comp_map[c] if isinstance(c, str) else c for c in components]
       ```

    2. **Select target atoms**  
       Let \\(L_i\\) be the list of all atomic labels, and \\(S\\subseteq\\{1,\\dots,N\\}\\) be
       the indices matching ``species``.  If ``species`` is empty, \\(S=\\{1,\\dots,N\\}\\).  
       ```math
         S = 
         \begin{cases}
           \{\,i : L_i \in \texttt{species}\}, & |\texttt{species}|>0,\\
           \{1,\dots,N\}, & |\texttt{species}|=0.
         \end{cases}
       ```

    3. **Filter by constraints**  
       From \\(S\\), build  
       \\(F = \{\,i\in S ~|~ \texttt{validate}(i,\!structure,\!constraints)\}\\).  
       If \\(F\\) is empty, abort with ``None, None``.

    4. **Generate mask array**  
       Construct a Boolean mask \\(M\in\{0,1\}^{N\times 3}\\) where  
       \\(M_{i,c}=1\\) iff \\(i\in F\\) and \\(c\in\texttt{components}\\).  

    5. **Apply Gaussian displacement**  
       For each atom index \\(i\\) and component \\(c\\) with \\(M_{i,c}=1\\), update  
       ```math
         x_{i,c} \;\leftarrow\; x_{i,c} + \epsilon_{i,c}, 
         \quad \epsilon_{i,c}\sim \mathcal{N}(0,\sigma^2),
         \quad \sigma = \texttt{std}
       ```  
       holding other coordinates fixed.  Implementation uses  
       ``structure.AtomPositionManager.rattle(stdev=std, seed=seed, mask=mask_array)``.

    :param structure:
        Object with ``AtomPositionManager`` providing ``atomLabelsList``,
        ``atomPositions``, and a ``rattle`` method.
    :type structure: any
    :param species:
        Single label or list of labels to perturb; if empty, all atoms are considered.
    :type species: list[str]
    :param std:
        Standard deviation \\(\sigma\\) of the Gaussian noise.
    :type std: float
    :param constraints:
        List of callables ``(idx,structure)→bool``; only atoms passing **all**
        constraints are rattled.
    :type constraints: list[callable]
    :param seed:
        Pseudorandom seed for reproducibility.
    :type seed: int
    :param verbose:
        If ``True``, emit detailed diagnostic messages.
    :type verbose: bool
    :param components:
        Subset of Cartesian components (0,1,2 or 'x','y','z') along which to apply noise.
    :type components: list[int|str]
    :returns:
        A tuple ``(modified_structure, mask_array)`` where
        ``mask_array`` is the \\(N\times3\\) Boolean mask used; or
        ``(None, None)`` if no atoms qualified.
    :rtype: tuple[any, numpy.ndarray] or (None, None)
    """
    comp_map = {'x': 0, 'y': 1, 'z': 2}
    components = [comp_map[c] if isinstance(c, str) else c for c in components]
    
    labels = np.array(structure.AtomPositionManager.atomLabelsList)
    N_atoms = len(labels)

    if isinstance(species, str):
        atom_indices = np.nonzero(labels == species)[0]
    elif isinstance(species, (list, np.ndarray)):
        species_arr = np.array(species)
        if species_arr.size == 0:
            atom_indices = np.arange(N_atoms)
        else:
            atom_indices = np.nonzero(np.isin(labels, species_arr))[0]
    else:
        raise ValueError("species must be either a string or a list of strings.")
    atom_indices_filtered = [idx for idx in atom_indices if validate(idx, structure, constraints)]

    if not atom_indices_filtered:
        return None, None

    if rng is None:
        rng = np.random.default_rng(seed)
    
    atom_indices_arr = np.array(atom_indices_filtered)
    mask_array = np.zeros((N_atoms, 3), dtype=bool)
    mask_array[np.ix_(atom_indices_arr, components)] = True
    structure.AtomPositionManager.rattle(stdev=std, mask=mask_array, rng=rng)

    return structure, mask_array

def change_atom_type(structure, ID_initial, ID_final, N:int=1, constraints:list=[], verbose:bool=False, seed:int | None=None, rng: np.random.Generator | None = None):
    r"""
    Change the chemical identity of one randomly chosen atom.

    This mutation selects a single atom whose current label is in `ID_initial`,
    validates it against optional constraints, and replaces its label with `ID_final`.

    **Procedure**:

    1. **Gather candidates**  
       Let \\(L = [L_i]_{i=1}^N\\) be the list of atomic labels.  
       Define the index set  
       \\[
         C = \{\,i \mid L_i \in \texttt{ID\_initial}\}.
       \\]

    2. **Constraint filtering**  
       From \\(C\\), build  
       \\[
         F = \{\,i \in C \mid \forall\,\varphi\in\texttt{constraints}: \varphi(i,\text{structure}) = \text{True}\}.
       \\]  
       If \\(F\\) is empty, abort and return `(None, None)`.

    3. **Random selection**  
       Draw  
       \\[
         i^* \sim \text{Uniform}(F).
       \\]

    4. **Perform relabeling**  
       Encapsulate the structure in a temporary `Partition`, then call  
       `partition.handleAtomIDChange(...)` to execute  
       \\(L_{i^*}\!\leftarrow\!\texttt{ID\_final}\\)  
       exactly \\(N\\) times.

    :param structure:
        Structure object with `AtomPositionManager.atomLabelsList`.
    :type structure: any
    :param ID_initial:
        Single label or list of labels from which to choose.
    :type ID_initial: str or list[str]
    :param ID_final:
        New atomic label to assign.
    :type ID_final: str
    :param N:
        Number of identical relabel operations to perform.
    :type N: int
    :param constraints:
        List of callables `(idx, structure) -> bool`; only indices passing **all** 
        constraints are eligible.
    :type constraints: list[callable]
    :param verbose:
        If True, enables detailed logging within `handleAtomIDChange`.
    :type verbose: bool
    :param seed:
        Optional integer seed for reproducibility.
    :type seed: int
    :returns:
        A tuple `(modified_structure, selected_index)`, or `(None, None)` if no atom qualified.
    :rtype: tuple[any, int] or (None, None)
    """

    # ------------------------------------------------------------------ 1. gather
    labels = np.asarray(structure.AtomPositionManager.atomLabelsList)

    # ---- resolve ID_initial → candidate indices ---------------------------
    if isinstance(ID_initial, (int, np.integer)):
        candidate_indices = np.asarray([int(ID_initial)], dtype=int)

    elif isinstance(ID_initial, str):
        candidate_indices = np.where(labels == ID_initial)[0]

    elif isinstance(ID_initial, (list, tuple, np.ndarray)):
        arr = np.asarray(ID_initial)

        if np.issubdtype(arr.dtype, np.integer):
            candidate_indices = arr.astype(int)

        elif np.issubdtype(arr.dtype, np.str_):
            candidate_indices = np.where(np.isin(labels, arr))[0]

        else:
            raise ValueError(
                "ID_initial sequence must contain either all integers or all strings."
            )
    else:
        raise ValueError(
            "ID_initial must be an int, str, or an iterable of ints or strs."
        )


    # ------------------------------------------------------------------ 2. constrain
    atom_indices_filtered = []

    for idx in candidate_indices:
        if validate(idx, structure, constraints):
            atom_indices_filtered.append( idx )

    candidate_indices = np.asarray(atom_indices_filtered, dtype=int)

    if len(candidate_indices) == 0:
        return None, None

    # ------------------------------------------------------------------ 3. select
    if rng is not None:
        local_rng = rng
    elif seed is not None:
        local_rng = np.random.default_rng(seed)
    else:
        local_rng = np.random.default_rng()

    selected_atom_index = local_rng.choice(candidate_indices)

    # ------------------------------------------------------------------ 4. relabel
    partition = Partition()
    partition.add_container( structure )

    partition.handleAtomIDChange({
     'atom_index': {
         'search': 'exact',
         'atom_index': 'atom_index',
         'atom_ID': [selected_atom_index],
         'new_atom_ID': [ID_final],
         'N': N,
         'weights': [1],
         'seed': seed if seed is not None else 1,
         'verbose': verbose
     }
    })
    return getattr(partition, "containers", partition)[0], selected_atom_index

def remove_atom_groups(structure, species, N=1, constraints: list=[], rng: np.random.Generator | None = None):
    r"""
    Remove one or more atoms or groups from the structure.

    This function supports two modes:
    - **Single-species removal**: randomly delete one atom of label `species`.
    - **Multi-group removal**: generate new configurations via `Partition.generate_configurational_space`.

    **Single-species**:
    1. Identify indices \\(C = \{\,i \mid L_i = \texttt{species}\}\\).
    2. Filter by constraints:  
       \\(F = \{\,i\in C \mid \forall\varphi: \varphi(i,\text{structure})\}\\).
    3. Choose \\(i^*\sim\mathrm{Uniform}(F)\\) and call  
       `structure.AtomPositionManager.remove_atom(i^*)`.

    **Multi-group**:
    1. Wrap `structure` in a `Partition`.
    2. Call  
       ```python
       partition.generate_configurational_space(
           values={
               'iterations': N,
               'atom_groups': species,
               ...
           }
       )
       ```
       which returns a list of new structures with groups removed.

    :param structure:
        Structure containing `AtomPositionManager.atomLabelsList`.
    :type structure: any
    :param species:
        Label (str) or list of atom‐group identifiers to remove.
    :type species: str or list
    :param N:
        Number of removal iterations (only used in multi‐group mode).
    :type N: int
    :param constraints:
        Callables `(idx, structure)->bool` to filter candidates in single-species mode.
    :type constraints: list[callable]
    :returns:
        Modified structure after removal.
    :rtype: any
    """
    species = species[0] if isinstance(species, list) and len(species)==1 else species

    if structure.AtomPositionManager.atomCount == 1:
        return structure
        
    if isinstance(species, str):

        atom_indices = np.where(np.array(structure.AtomPositionManager.atomLabelsList) == species)[0]
        
        atom_indices_filtered = []
        for idx in atom_indices:
            if validate(idx, structure, constraints):
                atom_indices_filtered.append( idx )

        atom_indices = np.asarray(atom_indices_filtered, dtype=int)

        if len(atom_indices) > 0:
            if rng is None:
                rng = np.random.default_rng()
            structure.AtomPositionManager.remove_atom( rng.choice(atom_indices) )

    else:
        partition = Partition()
        partition.add_container( copy.deepcopy([structure]) )
        values = {
            'iterations': N,
            'repetitions': 1,
            'distribution': 'uniform',
            'fill': False,
            'atom_groups': species,
            'group_numbers': None,
        }

        partition.set_container( partition.generate_configurational_space(values=values, verbose=False) )
        structure = getattr(partition, "containers", partition)[0]
        
    return structure

def remove_fragment(species: str, constraints: list = []):
    """
    Returns a mutation operator that identifies molecules or fragments
    matching a formula/SMILES string (e.g., 'CO', 'CH4') and randomly removes one.

    :param species: Identifier for the molecule/group to remove.
    :param constraints: List of Callables `(idx, structure)->bool`. ALL atoms in the group must pass.
    :return: A callable `op(structure, rng=None)` that returns the mutated structure.
    """
    def op(structure, rng=None):
        if rng is None:
            rng = np.random.default_rng()
            
        components = FragmentFinder.find(structure, species)
        
        valid_components = []
        for comp in components:
            is_valid = True
            for idx in comp:
                if not validate(idx, structure, constraints):
                    is_valid = False
                    break
            if is_valid:
                valid_components.append(comp)
        
        if len(valid_components) > 0:
            target_comp = list(rng.choice(valid_components))
            # Sort descending to avoid index shifting during removal
            target_comp.sort(reverse=True)
            for idx in target_comp:
                structure.AtomPositionManager.remove_atom(idx)
            
        return structure
    return op

def replace_adsorbate(adsorbate: str, replacement: str, collision_tolerance: float = 2.0, constraints: list = [], preserve_orientation: bool = False, tag: int | None = None):
    """
    Returns a mutation operator that finds a molecule matching `adsorbate`, removes it,
    and places a new molecule matching `replacement` at the same anchoring site.

    :param adsorbate: Identifier for the adsorbate to remove.
    :param replacement: Identifier for the replacement adsorbate.
    :param collision_tolerance: Minimum allowed interatomic distance for the new addition.
    :param constraints: List of Callables `(idx, structure)->bool`. ALL atoms in the removed group must pass.
    :param preserve_orientation: If True, attempts to align the principal axes of the new molecule with the old one.
    :param tag: Optional integer tag to assign to the new adsorbate.
    :return: A callable `op(structure, rng=None)` that returns the mutated structure.
    """
    def op(structure, rng=None):
        if rng is None:
            rng = np.random.default_rng()
            
        components = FragmentFinder.find(structure, adsorbate)
        
        valid_components = []
        for comp in components:
            is_valid = True
            for idx in comp:
                if not validate(idx, structure, constraints):
                    is_valid = False
                    break
            if is_valid:
                valid_components.append(comp)
        
        if len(valid_components) > 0:
            target_comp = list(rng.choice(valid_components))
            
            apm = structure.AtomPositionManager
            original_count = apm.atomCount
            
            # Save original positions and calculate com_old
            pos_old = apm.atomPositions[target_comp].copy()
            com_old = np.mean(pos_old, axis=0)
            
            # Find anchoring atoms (neighbors not in the molecule)
            rg = build_radius_graph(apm, cutoff=CUTOFF_MAX)
            bg = build_bond_graph(rg)
            
            anchors = set()
            for idx in target_comp:
                s_edge = bg.bindptr[idx]
                e_edge = bg.bindptr[idx+1]
                for n in bg.bindices[s_edge:e_edge]:
                    n = int(n)
                    if n not in target_comp:
                        anchors.add(n)
            
            # Calculate shift array for when target_comp is removed
            shift_array = np.zeros(original_count, dtype=int)
            for rm_idx in sorted(target_comp):
                shift_array[rm_idx:] += 1
                
            new_anchors = []
            for a in anchors:
                new_anchors.append(a - shift_array[a])
                
            # Remove old molecule
            target_comp.sort(reverse=True)
            for idx in target_comp:
                apm.remove_atom(idx)
            
            try:
                p = Partition()
                p.add_empty()
                p[0].AtomPositionManager.build(replacement)
                labels_new = p[0].AtomPositionManager.atomLabelsList
                pos_new = p[0].AtomPositionManager.atomPositions
                
                com_new = np.mean(pos_new, axis=0)
                pos_new_centered = pos_new - com_new
                
                aligned = False
                if preserve_orientation:
                    if len(pos_old) > 1:
                        cov_old = np.cov((pos_old - com_old).T)
                        evals_old, evecs_old = np.linalg.eigh(cov_old)
                        evecs_old = evecs_old[:, evals_old.argsort()[::-1]]
                    else:
                        evecs_old = np.eye(3)
                        
                    if len(pos_new) > 1:
                        cov_new = np.cov(pos_new_centered.T)
                        evals_new, evecs_new = np.linalg.eigh(cov_new)
                        evecs_new = evecs_new[:, evals_new.argsort()[::-1]]
                    else:
                        evecs_new = np.eye(3)
                        
                    R = evecs_old @ evecs_new.T
                    if np.linalg.det(R) < 0:
                        evecs_new[:, -1] *= -1
                        R = evecs_old @ evecs_new.T
                        
                    pos_new_aligned = (R @ pos_new_centered.T).T + com_old
                    apm.add_atom(labels_new, pos_new_aligned, atomType=tag)
                    aligned = True
                    
                if not aligned:
                    # Random orientation at com_old without relying on add_species
                    from scipy.spatial.transform import Rotation
                    R = Rotation.random(random_state=rng).as_matrix()
                    pos_new_aligned = (R @ pos_new_centered.T).T + com_old
                    apm.add_atom(labels_new, pos_new_aligned, atomType=tag)
                    
            except Exception as e:
                print(f"DEBUG: Operation failed for {replacement}: {e}")
            
        return structure
    return op

def add_species(structure, species, bound:list | None =None, collision_tolerance:float=2.0, tag:int | None =None, slab:bool=False, constraints: list=[], verbose:bool=False, rng: np.random.Generator | None = None, method: str = "fibonacci", **kwargs):
    r"""
    Add adsorbates or solvent molecules to a structure.

    Two modes, determined by `bound`:

    1. **Bound‐site addition**:  
       - Compute candidate indices  
         \\(C = \{\,i: i\in\texttt{bound}\\}\cup\{\,i: L_i\in\texttt{bound}\}.\\)  
       - Filter by constraints to form \\(F\\).  
       - Assemble parameter dictionary  
         \\(\texttt{ADD_ADSOBATE}\mapsto\{\dots\}\\)  
         and call `partition.handleCLUSTER(...)`.

    2. **Solvent filling**:  
       - Use uniform placement in the unit cell, with density and tolerance settings,  
         via `{'ADD_SOLVENT': {...}}`.

    :param structure:
        Structure with `AtomPositionManager` supporting lattice and removal/insertion.
    :type structure: any
    :param species:
        Single species or list of species to add.
    :type species: list[str]
    :param bound:
        Optional list of anchor indices or labels for bound‐site addition.
    :type bound: list[int|str] or None
    :param collision_tolerance:
        Minimum allowed interatomic distance.
    :type collision_tolerance: float
    :param constraints:
        Filters applied to `bound` indices (if provided).
    :type constraints: list[callable]
    :param verbose:
        If True, passes verbose flag into cluster handlers.
    :type verbose: bool
    :returns:
        New `structure` with added species, or `None` if addition failed.
    :rtype: any or None
    """
    species = species if isinstance(species, list) else [species]

    partition = Partition()
    partition.add_container( copy.deepcopy([structure]) )

    if isinstance(bound, (list, np.ndarray)):
        # Convert elements that are int or float to integers
        atom_indices = [int(x) for x in bound if isinstance(x, (int, float))]

        # Append indices from container.AtomPositionManager.atomLabelsList where the label is present in ID_label_list
        atom_indices.extend(
            i for i, label in enumerate(structure.AtomPositionManager.atomLabelsList)
            if label in bound
        )

        atom_indices_filtered = []
        for idx in atom_indices:
            if validate(idx, structure, constraints):
                atom_indices_filtered.append( idx )

        if len(atom_indices_filtered) < 1:
            return getattr(partition, "containers", partition)[0]
            #assert len(atom_indices_filtered) > 0, "Error: atom_indices_filtered list is empty"

        values = {
            'adsorbate': species,
            'padding':1.,
            'resolution':40,
            'd':collision_tolerance*1.06,
            'ID': atom_indices_filtered,
            'collision_tolerance': collision_tolerance*0.95,
            'molecules_number':np.ones( len(species) ),
            'translation': None,
            'wrap': True,
            'max_iteration':100,
            'slab':slab,
            'seed': None,
            'rng': rng,
            'prioritize_connectivity': True,
            'verbose': verbose,
            'atom_type': tag,
            'method': method,
            **kwargs
        }
        ans = partition.handleCLUSTER(values={'ADD_ADSORBATE': values})

    else:
        values = {
            'density': None,
            'solvent': species,
            'slab': slab,
            'shape': 'cell',
            'size': None,
            'vacuum_tolerance': None,
            'collision_tolerance': collision_tolerance,
            'molecules_number': np.ones( len(species) ),
            'translation': None,
            'wrap': True,
            'max_iteration':100,
            'seed': None,
            'rng': rng,
            'verbose': verbose,
            'atom_type': tag,
            'method': method,
            **kwargs
        }

        ans = partition.handleCLUSTER(values={'ADD_SOLVENT': values})

    if ans == False:
        return None
    else:
        return getattr(partition, "containers", partition)[0]

# ------------------------------------------------------------------
#  ------------          Mutations functions              ---------
# ------------------------------------------------------------------
def swap_species(ID1: str, ID2: str, constraints: list=[], N: int=1, tag: int | None =None, swap_tags: bool=False):
    """
    Returns a mutation operator that swaps the species of two atoms.
    """
    def func(structure, rng: np.random.Generator | None = None):
        if rng is None:
            rng = np.random.default_rng()
        labels = np.asarray(structure.AtomPositionManager.atomLabelsList)
        idx1_cands = [i for i in np.where(labels == ID1)[0] if validate(i, structure, constraints)]
        idx2_cands = [i for i in np.where(labels == ID2)[0] if validate(i, structure, constraints)]

        if len(idx1_cands) > 0 and len(idx2_cands) > 0:
            idx1 = rng.choice(idx1_cands)
            idx2 = rng.choice(idx2_cands)
            
            log_q_fwd = -np.log(len(idx1_cands)) - np.log(len(idx2_cands))
            
            import copy
            child = copy.deepcopy(structure)
            child.AtomPositionManager.set_ID(atom_index=[idx1], ID=ID2)
            child.AtomPositionManager.set_ID(atom_index=[idx2], ID=ID1)

            if swap_tags:
                current_tags = child.AtomPositionManager.get_types()
                t1 = current_tags[idx1]
                t2 = current_tags[idx2]
                child.AtomPositionManager.set_atom_type(atom_index=[idx1, idx2], atom_type=[t2, t1])
            elif tag is not None:
                child.AtomPositionManager.set_atom_type(atom_index=[idx1, idx2], atom_type=[tag, tag])

            trace = {
                'mutation': 'swap',
                'ID1': ID1, 'ID2': ID2,
                'constraints': constraints
            }
            def get_log_q_rev(x_prime, trace):
                labels_prime = np.asarray(x_prime.AtomPositionManager.atomLabelsList)
                c1 = sum(1 for i in np.where(labels_prime == trace['ID1'])[0] if validate(i, x_prime, trace['constraints']))
                c2 = sum(1 for i in np.where(labels_prime == trace['ID2'])[0] if validate(i, x_prime, trace['constraints']))
                if c1 == 0 or c2 == 0:
                    return -np.inf
                return -np.log(c1) - np.log(c2)
            
            return child, log_q_fwd, trace, get_log_q_rev
        else: return None

    return func

def change_species(ID_initial: str, ID_final: str, constraints: list=[], N: int=1):
    """Mutation that changes the species of N atoms."""
    def func(structure, rng: np.random.Generator | None = None):
        child, selected_idx = change_atom_type(structure=structure, ID_initial=ID_initial, ID_final=ID_final, N=N, constraints=constraints, rng=rng)
        if child is None:
            return None
            
        labels = np.asarray(structure.AtomPositionManager.atomLabelsList)
        cand = np.where(labels == ID_initial)[0]
        N_val = sum(1 for idx in cand if validate(idx, structure, constraints))
        log_q_fwd = -np.log(N_val) if N_val > 0 else 0.0
        
        trace = {
             'mutation': 'change_ID',
             'ID_initial': ID_initial,
             'ID_final': ID_final,
             'constraints': constraints
        }
        
        def get_log_q_rev(x_prime, trace):
            labels_prime = np.asarray(x_prime.AtomPositionManager.atomLabelsList)
            cand_prime = np.where(labels_prime == trace['ID_final'])[0]
            N_val_prime = sum(1 for idx in cand_prime if validate(idx, x_prime, trace['constraints']))
            if N_val_prime == 0:
                return -np.inf
            return -np.log(N_val_prime)

        return child, log_q_fwd, trace, get_log_q_rev

    return func


def change_all_species_random(
    ID_initial_list: list[str],
    ID_final_list:   list[str],
    verbose:         bool = False
) -> Callable[[Any], Any]:
    """
    Returns a callable that, given a structure, will:
      1. Identify all atom‐indices whose label ∈ ID_initial_list.
      2. Randomly pick one such index.
      3. Randomly pick a replacement label ∈ ID_final_list (according to `weights`).
      4. Delegate to Config_builder.handleAtomIDChange to perform the change N times.
      5. Return the mutated structure (or the original if no viable atom was found).

    :param ID_initial_list: list of labels to choose from in the structure.
    :param ID_final_list:   list of candidate replacement labels.
        If None, uniform sampling is used.
    :param verbose:         passed through to handleAtomIDChange.
    """
    ID_initial_arr = np.array(ID_initial_list, ndmin=1)
    ID_final_arr   = np.array(ID_final_list,   ndmin=1)

    def func(structure: Any, rng: np.random.Generator | None = None) -> Any:
        if rng is None:
            rng = np.random.default_rng()

        atomLabelsList = structure.AtomPositionManager.atomLabelsList
        common = np.intersect1d(atomLabelsList, ID_initial_arr)

        ID_initial_pick = rng.choice(common)
        ID_final_pick = rng.choice(ID_final_arr)

        selected_atomLabels = np.where(structure.AtomPositionManager.atomLabelsList == ID_initial_pick)[0]
        structure.AtomPositionManager.set_ID(atom_index=selected_atomLabels, ID=ID_final_pick)

        return structure[0]

    return func

def remove_species(species: str, constraints: list=[], N:int=1):
    """Mutation that removes an atom of the given species."""
    def func(structure, rng: np.random.Generator | None = None):
        if rng is None:
            rng = np.random.default_rng()
        labels = np.asarray(structure.AtomPositionManager.atomLabelsList)
        target_species = species[0] if isinstance(species, list) and len(species) > 0 else species
        
        if isinstance(target_species, str):
            cands = [i for i in np.where(labels == target_species)[0] if validate(i, structure, constraints)]
        else:
            cands = []
            
        if len(cands) == 0:
            return None
            
        idx_to_remove = rng.choice(cands)
        log_q_fwd = -np.log(len(cands))
        
        V = abs(np.linalg.det(structure.AtomPositionManager.latticeVectors))
        
        import copy
        child = copy.deepcopy(structure)
        child.AtomPositionManager.remove_atom(idx_to_remove)
        
        trace = {
            'mutation': 'remove',
            'species': target_species,
            'V': V
        }
        
        def get_log_q_rev(x_prime, trace):
            return -np.log(trace['V'])
            
        return child, log_q_fwd, trace, get_log_q_rev

    return func

def add_species_mutation(species: list, bound:list | None =None, collision_tolerance:float=2.0, tag:int | None =None, constraints: list=[], slab:bool=False, method: str = "fibonacci", **kwargs):
    r"""
    Generates a mutation operator that adds an atom or molecular group of a given species.

    This operator supports both bound-site addition (targeted adsorption on active sites)
    and solvent filling. It calculates the exact forward and reverse transition probabilities 
    for grand-canonical Metropolis-Hastings detailed balance evaluation.

    Mathematical Formulation:
        The forward proposal density of inserting a particle uniformly in a volume \(V\) is:
        
        .. math::
            q(x \rightarrow x') = \frac{1}{V}

        Taking the logarithm yields the forward transition probability:
        
        .. math::
            \ln q(x \rightarrow x') = -\ln V

        The reverse proposal (the probability of removing the newly added particle from a pool 
        of \(N'\) identical species in the child structure \(x'\)) is:
        
        .. math::
            q(x' \rightarrow x) = \frac{1}{N'}

        Which yields the reverse transition probability:
        
        .. math::
            \ln q(x' \rightarrow x) = -\ln N'

        These logs are crucial for Hastings ratio correction in Grand-Canonical Monte Carlo (GCMC):
        
        .. math::
            \frac{q(x' \rightarrow x)}{q(x \rightarrow x')} = \frac{V}{N'}

    Parameters
    ----------
    species : list
        Single species or list of species symbols/formulas to add (e.g. ['O'] or ['CO']).
    bound : list[int | str], optional
        Anchor atom indices or element labels to restrict placement near specific surface atoms.
    collision_tolerance : float, default 2.0
        Minimum allowed interatomic distance (in Å) to prevent steric clash.
    tag : int, optional
        Custom numeric identifier tag to assign to the newly created atoms.
    constraints : list, default []
        Geometric and species-based validation filters applied to anchor atoms.
    slab : bool, default False
        If True, restricts placement near the surface slab boundaries.
    method : str, default "fibonacci"
        Surface mapping algorithm used to locate active sites ('marching_cubes' or 'fibonacci').
    **kwargs
        Arbitrary keyword arguments forwarded to the placement solver.

    Returns
    -------
    func : callable
        A mutation operator that takes a structure and returns:
        - child : any
            The modified structure with the added species, or None if insertion failed.
        - log_q_fwd : float
            Logarithm of the forward transition probability density.
        - trace : dict
            Metadata dictionary containing mutation type, target species, and volume.
        - get_log_q_rev : callable
            A function that takes the child structure and trace metadata, returning the logarithm 
            of the reverse transition probability density.
    """
    def func(structure, rng: np.random.Generator | None = None):
        child = add_species(structure=structure, species=species, bound=bound, collision_tolerance=collision_tolerance, tag=tag, slab=slab, constraints=constraints, rng=rng, method=method, **kwargs)
        if child is None:
            return None

        V = abs(np.linalg.det(structure.AtomPositionManager.latticeVectors))
        target_species = species[0] if isinstance(species, list) else species
        
        log_q_fwd = -np.log(V)
        
        trace = {
            'mutation': 'add',
            'species': target_species,
            'V': V
        }
        
        def get_log_q_rev(x_prime, trace):
            labels_prime = np.asarray(x_prime.AtomPositionManager.atomLabelsList)
            N_prime = len(np.where(labels_prime == trace['species'])[0])
            if N_prime == 0: return -np.inf
            return -np.log(N_prime)
            
        return child, log_q_fwd, trace, get_log_q_rev

    return func

def remove_add_species(species_add: list, species_remove: list, bound:list | None =None, collision_tolerance:float=2.0, constraints: list=[], N:int=1, slab:bool=False, method: str = "fibonacci", **kwargs):
    """Mutation that removes N atoms of one species and adds atoms of another."""
    def func(structure, rng: np.random.Generator | None = None):
        structure = remove_atom_groups(structure=structure, species=species_remove, N=N, constraints=constraints, rng=rng)
        structure = add_species(structure=structure, species=species_add, bound=bound, collision_tolerance=collision_tolerance, slab=slab, constraints=constraints, rng=rng, method=method, **kwargs)
        return structure

    return func

def add_motif_from_library(
    library_path: str,
    constraints: list | None = None,
    substrate_constraints: list | None = None,
    collision_tolerance: float = 1.8,
    match_tolerance: float = 0.5,
    min_existing_matches: int = 1,
    weights_mode: str = "score",
    max_attempts: int = 20,
    n_orientation_trials: int = 12,
    tag: int | None = None,
    copy_structure: bool = True,
):
    """
    Motif-completion mutation.

    Semantics of constraints
    ------------------------
    1. constraints: Atoms that pass these are eligible for ANCHORING and MATCHING.
    2. substrate_constraints: Custom functions to EXCLUDE atoms (ignored during analysis).
    3. atomicConstraints: (Internal) Atoms fixed in the structure are automatically EXCLUDED.

    The operator:
        1. samples a motif from a HiSE motif library,
        2. finds active atoms (not in substrate, compatible with motif species),
        3. anchors the motif on one active atom,
        4. tries random orientations,
        5. matches already-existing active atoms to motif atoms,
        6. adds only the missing atoms if the placement is collision-free.
    """
    constraints = [] if constraints is None else list(constraints)
    substrate_constraints = [] if substrate_constraints is None else list(substrate_constraints)

    motif_cache = {
        "motifs": None,
        "probs": None,
    }

    def _passes_active_constraints(atom_idx: int, structure) -> bool:
        # 1. Check internal atomicConstraints (fixed atoms)
        apm = structure.AtomPositionManager
        ac = getattr(apm, "atomicConstraints", None)
        if ac is not None:
            if isinstance(ac, (np.ndarray, list)):
                try:
                    if isinstance(ac, np.ndarray) and ac.dtype == bool:
                        if atom_idx < len(ac) and ac[atom_idx]:
                            return False
                    else:
                        if atom_idx in ac:
                            return False
                except Exception:
                    pass
            try:
                for c in ac:
                    if hasattr(c, "index") and atom_idx in c.index:
                        return False
            except Exception:
                pass
        
        # 2. Check custom substrate_constraints (to exclude)
        if substrate_constraints:
            if validate(atom_idx, structure, substrate_constraints):
                return False
        
        # 3. Check active domain constraints (to include)
        if not constraints:
            return True # Default to all mobile atoms
        return validate(atom_idx, structure, constraints)

    def _safe_weights(motifs):
        if weights_mode in (None, "uniform", "random"):
            return np.ones(len(motifs), dtype=float) / len(motifs)

        vals = []

        for m in motifs:
            if weights_mode == "delta_e":
                val = -getattr(m, "delta_e", 0.0)
            elif weights_mode == "frequency":
                val = getattr(m, "weighted_frequency", 0.0)
            elif weights_mode == "enrichment":
                val = getattr(m, "enrichment", 0.0)
            elif weights_mode == "low_count":
                val = getattr(m, "low_count", 0.0)
            elif weights_mode == "odds_ratio":
                val = getattr(m, "odds_ratio", 0.0)
            else:
                val = getattr(m, weights_mode, 0.0)

            vals.append(val)

        vals = np.asarray(vals, dtype=float)
        vals = np.nan_to_num(vals, nan=0.0, posinf=0.0, neginf=0.0)
        vals = np.clip(vals, 0.0, None)

        if np.sum(vals) <= 0:
            return np.ones(len(motifs), dtype=float) / len(motifs)

        return vals / np.sum(vals)

    def _load_motifs():
        if motif_cache["motifs"] is not None:
            return motif_cache["motifs"], motif_cache["probs"]

        from ezga.hise.motifs import MotifLibrary

        if not os.path.exists(library_path):
            logger.warning(f"[Mutation] Motif library not found at: {library_path}")
            motif_cache["motifs"] = []
            motif_cache["probs"] = np.array([])
            return motif_cache["motifs"], motif_cache["probs"]

        lib = MotifLibrary(library_path)
        motifs = lib.load()

        if not motifs:
            logger.warning(f"[Mutation] Empty motif library: {library_path}")
            motif_cache["motifs"] = []
            motif_cache["probs"] = np.array([])
            return motif_cache["motifs"], motif_cache["probs"]

        probs = _safe_weights(motifs)

        motif_cache["motifs"] = motifs
        motif_cache["probs"] = probs

        return motifs, probs

    def _find_best_completion(
        structure,
        motif,
        seed_idx: int,
        rng: np.random.Generator,
    ):
        apm = structure.AtomPositionManager

        labels_struct = np.asarray(apm.atomLabelsList)
        pos_struct = np.asarray(apm.atomPositions, dtype=float)

        motif_labels = np.asarray(motif.labels)
        motif_pos = np.asarray(motif.canonical_positions, dtype=float)

        seed_label = labels_struct[seed_idx]
        seed_pos = pos_struct[seed_idx]

        anchor_indices = np.where(motif_labels == seed_label)[0]
        if anchor_indices.size == 0:
            return None

        eligible_mask = np.array(
            [_passes_active_constraints(i, structure) for i in range(len(labels_struct))],
            dtype=bool,
        )

        best = None
        best_score = -np.inf

        for motif_anchor_idx in rng.permutation(anchor_indices):
            motif_local = motif_pos - motif_pos[motif_anchor_idx]

            for _ in range(n_orientation_trials):
                R = random_rotation_matrix(rng)
                motif_global = motif_local @ R.T + seed_pos

                matched_structure_indices = [int(seed_idx)]
                matched_motif_indices = [int(motif_anchor_idx)]
                used_structure_indices = {int(seed_idx)}

                to_add_indices = []
                match_sq_errors = []

                for motif_i, target_pos in enumerate(motif_global):
                    if motif_i == motif_anchor_idx:
                        continue

                    label = motif_labels[motif_i]

                    candidate_indices = np.where(
                        (labels_struct == label) & eligible_mask
                    )[0]

                    candidate_indices = np.array(
                        [idx for idx in candidate_indices if int(idx) not in used_structure_indices],
                        dtype=int,
                    )

                    matched = False

                    if candidate_indices.size > 0:
                        dists = _distances_to_point(
                            apm,
                            pos_struct[candidate_indices],
                            target_pos,
                        )

                        j_local = int(np.argmin(dists))
                        d_min = float(dists[j_local])

                        if d_min <= match_tolerance:
                            matched_idx = int(candidate_indices[j_local])
                            matched_structure_indices.append(matched_idx)
                            matched_motif_indices.append(int(motif_i))
                            used_structure_indices.add(matched_idx)
                            match_sq_errors.append(d_min * d_min)
                            matched = True

                    if not matched:
                        to_add_indices.append(int(motif_i))

                match_count = len(matched_structure_indices)

                if match_count < min_existing_matches:
                    continue

                # No actual mutation if the motif is already fully present.
                if len(to_add_indices) == 0:
                    continue

                add_positions = motif_global[to_add_indices]
                add_labels = [str(motif_labels[i]) for i in to_add_indices]

                # Collision against the complete structure, but ignore atoms already
                # interpreted as part of the motif.
                collision = False
                ignore = set(matched_structure_indices)

                for p in add_positions:
                    dists = _distances_to_point(apm, pos_struct, p)
                    near = np.where(dists < collision_tolerance)[0]

                    for idx in near:
                        if int(idx) not in ignore:
                            collision = True
                            break

                    if collision:
                        break

                if collision:
                    continue

                rms_match = float(np.sqrt(np.mean(match_sq_errors))) if match_sq_errors else 0.0

                # Prefer placements that reuse more existing atoms, add fewer atoms,
                # and have lower matching residual.
                placement_score = (
                    10.0 * match_count
                    - 1.0 * len(to_add_indices)
                    - 2.0 * rms_match
                )

                motif_score = float(getattr(motif, "score", 0.0))
                placement_score += 0.01 * motif_score

                if placement_score > best_score:
                    best_score = placement_score
                    best = {
                        "add_positions": add_positions,
                        "add_labels": add_labels,
                        "matched_structure_indices": matched_structure_indices,
                        "matched_motif_indices": matched_motif_indices,
                        "motif_id": getattr(motif, "id", None),
                        "motif_formula": getattr(motif, "formula", None),
                        "match_count": match_count,
                        "rms_match": rms_match,
                        "placement_score": placement_score,
                    }

        return best

    def func(structure, rng: np.random.Generator | None = None):
        if rng is None:
            rng = np.random.default_rng()

        motifs, probs = _load_motifs()

        if not motifs:
            return None

        apm = structure.AtomPositionManager
        labels_struct = np.asarray(apm.atomLabelsList)

        eligible_mask = np.array(
            [_passes_active_constraints(i, structure) for i in range(len(labels_struct))],
            dtype=bool,
        )

        if not np.any(eligible_mask):
            logger.debug("[Mutation] No active atoms passed motif constraints.")
            return None

        for _ in range(max_attempts):
            motif_idx = int(rng.choice(len(motifs), p=probs))
            motif = motifs[motif_idx]

            motif_species = np.unique(np.asarray(motif.labels))

            seed_candidates = np.where(
                eligible_mask & np.isin(labels_struct, motif_species)
            )[0]

            if seed_candidates.size == 0:
                continue

            seed_idx = int(rng.choice(seed_candidates))

            placement = _find_best_completion(
                structure=structure,
                motif=motif,
                seed_idx=seed_idx,
                rng=rng,
            )
            if placement is None:
                continue

            if len(placement["add_labels"]) == 0:
                return None

            child = copy.deepcopy(structure) if copy_structure else structure
            child.AtomPositionManager.add_atom(
                placement["add_labels"],
                placement["add_positions"],
                atomType=tag,
            )

            logger.debug(
                "[Mutation] Added motif completion: "
                f"formula={placement['motif_formula']} | "
                f"matched={placement['match_count']} | "
                f"added={len(placement['add_labels'])} | "
                f"rms_match={placement['rms_match']:.3f}"
            )

            return child

        return None

    return func

def rattle_positions(std: float, constraints: list=[], species:list=[], components:list=[0,1,2], seed:int=42 ):
    """Mutation that rattles atom positions."""
    def func(structure, rng: np.random.Generator | None = None):
        child, _ = random_rattle(structure=structure, species=species, std=std,  constraints=constraints, components=components, seed=seed, rng=rng )
        if child is None:
            return None
            
        # Rattle is a symmetric random walk, so q_fwd = q_rev exactly.
        log_q_fwd = 0.0
        trace = {'mutation': 'rattle'}
        
        def get_log_q_rev(x_prime, trace):
            return 0.0
            
        return child, log_q_fwd, trace, get_log_q_rev
    return func

def compress_cell(compress_factor: float | None = None, factor: float | None = None, constraints: list = []):
    """Mutation that compresses the lattice."""
    """
    Apply a compression/scaling factor to the cell volume.
    
    :param compress_factor: Scaling factor (e.g., 0.95 for 5% compression).
    :param factor: Alias for compress_factor.
    :param constraints: Optional list of constraints.
    """
    actual_factor = compress_factor if compress_factor is not None else factor
    if actual_factor is None:
        raise ValueError("mutation_compress: must provide 'compress_factor' or its alias 'factor'.")

    def func(structure, rng: np.random.Generator | None = None):
        structure.AtomPositionManager.compress(compress_factor=actual_factor, verbose=False)
        return structure
    return func

def shear_cell(gamma_max: float, plane: str = 'xy', verbose: bool = False):
    """Mutation that shears the lattice."""
    """
    Apply a simple shear γ in the specified coordinate plane up to ±gamma_max.

    :param gamma_max: Maximum shear magnitude.
    :param plane:     One of 'xy', 'xz', or 'yz'.
    :param verbose:   If True, print the applied shear component.
    :returns:         A function(structure) -> structure
    """
    axes_map = {
        'xy': (0, 1),
        'xz': (0, 2),
        'yz': (1, 2),
    }
    if plane not in axes_map:
        raise ValueError(f"Invalid plane '{plane}'. Choose from 'xy', 'xz', or 'yz'.")

    i, j = axes_map[plane]

    def _mutate(structure, rng: np.random.Generator | None = None):
        if rng is None:
            rng = np.random.default_rng()
        # 1) Original cell
        C = structure.AtomPositionManager.latticeVectors
        pos = structure.AtomPositionManager.atomPositions
        if C is None or pos is None:
            return structure
        C = np.array(C, dtype=float)
        pos = np.atleast_2d(np.array(pos, dtype=float))
        if C.shape != (3, 3) or pos.ndim != 2 or pos.shape[1] != 3 or pos.shape[0] == 0:
            return structure

        # 2) Random shear in the chosen plane
        gamma = rng.uniform(-gamma_max, gamma_max)
        shear = np.eye(3, dtype=float)
        shear[i, j] = gamma

        # 3) New cell and fractional coords
        C_new = shear.dot(C)
        frac = np.linalg.solve(C.T, pos.T).T

        # 4) Assign back via SAGE's configure() so that _latticeVectors_inv,
        #    _kdtree and all dependent caches are properly invalidated.
        apm = structure.AtomPositionManager
        apm.set_latticeVectors(C_new, edit_positions=False)
        apm.set_atomPositions((C_new.T.dot(frac.T)).T)

        if verbose:
            print(f"Applied shear γ_{plane} = {gamma:.3f}")

        return structure

    return _mutate

def strain_cell(max_strain: float, constraints: list = [], seed: int | None = None, verbose: bool = False):
    """Mutation that applies random strain to the lattice."""
    """
    Apply a random symmetric strain tensor (up to ±max_strain) 
    to both the lattice vectors and atomic positions.

    :param max_strain: Maximum absolute strain component (e.g. 0.02 for ±2%).
    :param constraints: List of callables (idx, structure)->bool; if non-empty,
                        the strain is only applied if all atoms pass.
    :param seed:       RNG seed for reproducibility.
    :param verbose:    If True, prints the applied strain tensor.
    :returns:          A function(structure) -> structure
    """
    def _mutate(structure, rng: np.random.Generator | None = None):
        if rng is None:
            rng = np.random.default_rng(seed)
        # 1) Optionally check constraints on every atom
        if constraints:
            N = len(structure.AtomPositionManager.atomPositions)
            ok = all(
                all(c(idx, structure) for c in constraints)
                for idx in range(N)
            )
            if not ok:
                return None

        # 2) Fetch original cell & positions
        C0 = structure.AtomPositionManager.latticeVectors
        pos = structure.AtomPositionManager.atomPositions
        if C0 is None or pos is None:
            return structure
        C0 = np.array(C0, dtype=float)
        pos = np.atleast_2d(np.array(pos, dtype=float))
        if C0.shape != (3, 3) or pos.ndim != 2 or pos.shape[1] != 3 or pos.shape[0] == 0:
            return structure

        # 3) Build a small symmetric strain tensor
        eps = rng.uniform(-max_strain, max_strain, size=(3,3))
        eps = 0.5*(eps + eps.T)

        # 4) Compute new cell and positions
        C1 = (np.eye(3) + eps).dot(C0)
        # fractional coords w.r.t. original cell
        frac = np.linalg.solve(C0.T, pos.T).T
        new_pos = (C1.T.dot(frac.T)).T

        # 5) Assign back via SAGE's configure() so that _latticeVectors_inv,
        #    _kdtree and all dependent caches are properly invalidated.
        apm = structure.AtomPositionManager
        apm.set_latticeVectors(C1, edit_positions=False)
        apm.set_atomPositions(new_pos)

        if verbose:
            print("Applied strain tensor:\n", eps)
        return structure

    return _mutate

def symmetry_project(
    ops: list,
    alpha: float = 0.5,
    tol: float = 1e-6,
    max_iter: int = 30,
    max_ops: int = 50,
    periodic: bool = False,
    apply_prob: float = 1.0,
    species_subset: list | None = None,
    index_mask: np.ndarray | None = None,   # optional: faster than species_subset if you have it
    # repulsion-related parameters
    repulsion: bool = True,
    repulsion_strength: float = 0.1,
    repulsion_min_distance: float = 1.0,
    repulsion_steps: int = 3,
):
    """
    Symmetry-projection (continuous iteration) mutation.
    - ops: list of 3x3 orthogonal matrices (rotations/reflections/inversion).
    - alpha: relaxation factor (0<alpha<=1).
    - tol: per-atom RMS movement threshold (Å) to stop the CI loop.
    - max_iter: max CI iterations.
    - max_ops: cap number of symmetry ops used per call.
    - periodic: if True, operate in fractional coords with wrapping.
    - apply_prob: probability to apply the mutation (for diversity control).
    - species_subset: list of labels to move (others kept fixed). If None, move all.
    - index_mask: boolean array (N,) to select moved atoms (overrides species_subset if given).

    Returns: function(structure) -> structure
    """
    def _mutate(structure, rng: np.random.Generator | None = None):
        if rng is None:
            rng = np.random.default_rng()

        if rng.random() > apply_prob or len(ops) == 0:
            return structure

        cell   = np.array(structure.AtomPositionManager.latticeVectors, float)
        X      = np.array(structure.AtomPositionManager.atomPositions, float)
        labels = np.array(structure.AtomPositionManager.atomLabelsList)

        # choose which atoms to move
        if index_mask is not None:
            mask = np.array(index_mask, dtype=bool)
        elif species_subset is None or len(species_subset) == 0:
            mask = np.ones(len(labels), dtype=bool)
        else:
            mask = np.isin(labels, np.array(species_subset))

        I = np.where(mask)[0]
        if I.size == 0:
            return structure

        # CI loop on the participating subset only
        Xw = X.copy()
        it = 0
        while it < max_iter:
            Xprev = Xw[I].copy()
            if periodic:
                Xsym = _orbit_average_frac(cell, Xw[I], ops, labels[I], max_ops=max_ops)
            else:
                Xsym = _orbit_average_cart(Xw[I], ops, labels[I], max_ops=max_ops)
            Xw[I] = (1.0 - alpha) * Xw[I] + alpha * Xsym
            rms = np.linalg.norm(Xw[I] - Xprev) / np.sqrt(I.size)

            # --- optional repulsion term ---
            if repulsion:
                for _ in range(repulsion_steps):
                    com = Xw.mean(axis=0)

                    # Pull atoms toward center of mass (soft confinement)
                    disp = com - Xw
                    Xw += repulsion_strength * disp

                    # Rigid-sphere repulsion (pairwise)
                    N = len(Xw)
                    for i in range(N):
                        for j in range(i+1, N):
                            rij = Xw[j] - Xw[i]
                            dist = np.linalg.norm(rij)
                            if dist < repulsion_min_distance and dist > 1e-12:
                                corr = 0.5 * (repulsion_min_distance - dist) * rij / dist
                                Xw[i] -= corr
                                Xw[j] += corr
            it += 1
            if rms < tol:
                break

        structure.AtomPositionManager.atomPositions = Xw
        return structure

    return _mutate

def compact_to_com(strength: float = 0.1, min_distance: float = 1.0, steps: int = 5, seed: int | None = None):
    """Mutation that compacts atoms toward the center of mass."""
    """
    Mutation: Compact atoms toward the center of mass (CoM), treating them as rigid spheres.
    
    Parameters
    ----------
    strength : float
        Force constant toward CoM. Larger = stronger compaction.
    min_distance : float
        Minimum allowed interatomic distance (sphere radius constraint).
    steps : int
        Number of iterative updates.
    seed : int
        RNG seed for reproducibility.
    """
    def func(structure, rng: np.random.Generator | None = None):
        if rng is None:
            rng = np.random.default_rng(seed)

        _raw_pos = structure.AtomPositionManager.atomPositions
        if _raw_pos is None:
            return structure
        pos = np.array(_raw_pos, dtype=float)
        N = len(pos)
        if N == 0:
            return structure

        # Iterative relaxation
        for _ in range(steps):
            com = pos.mean(axis=0)

            # Pull each atom toward CoM
            disp = com - pos
            pos += strength * disp

            # Enforce rigid-sphere constraint (no overlap)
            for i in range(N):
                for j in range(i+1, N):
                    rij = pos[j] - pos[i]
                    dist = np.linalg.norm(rij)
                    if dist < min_distance and dist > 1e-8:
                        # Push atoms apart equally
                        corr = 0.5 * (min_distance - dist) * rij / dist
                        pos[i] -= corr
                        pos[j] += corr

        structure.AtomPositionManager.atomPositions = pos

        return structure

    return func

# --- CONSTRAINT REGISTRY ---
CONSTRAINT_REGISTRY = {
    "z_gt": lambda threshold: component_is_greater_than(2, threshold),
    "z_lt": lambda threshold: component_is_less_than(2, threshold),
    "x_gt": lambda threshold: component_is_greater_than(0, threshold),
    "x_lt": lambda threshold: component_is_less_than(0, threshold),
    "y_gt": lambda threshold: component_is_greater_than(1, threshold),
    "y_lt": lambda threshold: component_is_less_than(1, threshold),
    "species": species_is,
    "species_in": species_is_in,
    "movable": position_is_movable,
    "fixed": position_is_fixed,
    "added": atom_is_added,
    "original": atom_is_original,
    "tag": tag_is,
    "tags": tag_is_in,
}

def get_constraint(name: str) -> Any:
    """Retrieves a constraint factory from the registry."""
    if name in CONSTRAINT_REGISTRY:
        return CONSTRAINT_REGISTRY[name]
    raise ValueError(f"Constraint '{name}' not found. Available: {list(CONSTRAINT_REGISTRY.keys())}")

# --- MUTATION REGISTRY ---
MUTATION_REGISTRY = {
    "swap": swap_species,
    "change": change_all_species_random,
    "add": add_species_mutation,
    "remove": remove_species,
    "rattle": rattle_positions,
    "compress": compress_cell,
    "shear": shear_cell,
    "strain": strain_cell,
    "symmetry": symmetry_project,
    "compact": compact_to_com,
    "add_motif": add_motif_from_library,
    "remove_add": remove_add_species,
    "replace_species": change_species,
}

def get_mutation(name: str) -> Any:
    """Retrieves a mutation operator from the registry."""
    if name in MUTATION_REGISTRY:
        return MUTATION_REGISTRY[name]
    raise ValueError(f"Mutation '{name}' not found. Available: {list(MUTATION_REGISTRY.keys())}")

# Backward Compatibility Aliases
is_movable_position = position_is_movable
is_fixed_position = position_is_fixed
is_added_atom = atom_is_added
is_not_added_atom = atom_is_original
label_is = species_is  # type: ignore
label_in = species_is_in  # type: ignore
mutation_swap = swap_species
mutation_rattle = rattle_positions
mutation_remove = remove_species
mutation_add = add_species_mutation
mutation_change_ID = change_species
mutation_compress = compress_cell
mutation_shear = shear_cell
mutation_random_strain = strain_cell
mutation_symmetry_project = symmetry_project
mutation_compact_to_com = compact_to_com
mutation_add_motif_from_library = add_motif_from_library
mutation_remove_add = remove_add_species
component_greater_than = component_is_greater_than
component_less_than = component_is_less_than
component_in_range = component_is_in_range
distance_between_atoms_less_than = distance_to_atom_is_less_than
distance_between_atoms_greater_than = distance_to_atom_is_greater_than
distance_from_origin_less_than = distance_to_origin_is_less_than
distance_from_origin_greater_than = distance_to_origin_is_greater_than
atomic_tag_is = tag_is
atomic_tag_in = tag_is_in
component_sum_greater_than = component_is_greater_than_sum
component_sum_less_than = component_is_less_than_sum
