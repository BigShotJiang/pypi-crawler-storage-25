from __future__ import annotations
import numpy as np
import logging
import copy
from typing import List, Dict, Any, Callable, Optional, Tuple, Set, Union
from ezga.utils.chemistry import RCOV
from ezga.utils.helper_functions import validate
from ezga.variation.geo_utils import _apply_pbc_displacement, _distances_to_point, random_rotation_matrix
from ezga.variation.mutation_organic import _get_cell, _cart_to_frac, _frac_to_cart

logger = logging.getLogger(__name__)

def _rcov(sym: str) -> float:
    return RCOV.get(sym, 1.20)

def _fetch_template(name: str, custom_templates: Optional[Dict[str, Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
    """Fetches a molecular template from custom dict or SAGE builder."""
    if custom_templates and name in custom_templates:
        return custom_templates[name]
    
    try:
        from sage_lib.partition.Partition import Partition
        p = Partition()
        p.add_empty()
        # sage_lib build() handles standard names like "H2O", "NO", etc.
        p[0].AtomPositionManager.build(name)
        apm = p[0].AtomPositionManager
        return {
            "labels": list(apm.atomLabelsList),
            "positions": np.array(apm.atomPositions)
        }
    except Exception as e:
        logger.debug(f"Could not build template '{name}' via SAGE: {e}")
        return None

def _get_formula(labels: List[str]) -> str:
    """Returns Hill-system formula (e.g. H2O, NO, CO2)."""
    from collections import Counter
    c = Counter(labels)
    # Hill system: C then H then alphabetical
    keys = list(c.keys())
    sorted_keys = []
    if "C" in c:
        sorted_keys.append("C")
        keys.remove("C")
    if "H" in c:
        sorted_keys.append("H")
        keys.remove("H")
    sorted_keys.extend(sorted(keys))
    
    res = ""
    for k in sorted_keys:
        res += k
        if c[k] > 1:
            res += str(c[k])
    return res

class AdsorbateMolecule:
    """Helper class to manage a molecular unit in the structure."""
    def __init__(self, indices: List[int], labels: List[str], positions: np.ndarray):
        self.indices = np.array(indices, dtype=int)
        self.labels = labels
        self.positions = positions # Absolute Cartesian
        self.formula = _get_formula(labels)
        self.com = np.mean(positions, axis=0)
        self.rel_positions = positions - self.com

def identify_adsorbates(structure: Any, constraints: List[Callable] | None = None, radius_scale: float = 1.30) -> List[AdsorbateMolecule]:
    """
    Identifies connected molecular fragments among atoms that pass constraints.
    If constraints is None, it considers all atoms.
    """
    apm = structure.AtomPositionManager
    labels = apm.atomLabelsList
    pos = apm.atomPositions
    n = len(pos)
    
    if constraints:
        active = [i for i in range(n) if validate(i, structure, constraints)]
    else:
        active = list(range(n))
        
    if not active:
        return []
        
    # Build adjacency among active atoms
    adj: List[List[int]] = [[] for _ in range(n)]
    for idx, i in enumerate(active):
        ri = _rcov(labels[i])
        pi = pos[i]
        for j in active[idx+1:]:
            d_limit = radius_scale * (ri + _rcov(labels[j]))
            dr = pi - pos[j]
            dr = _apply_pbc_displacement(apm, dr)
            if np.linalg.norm(dr) <= d_limit:
                adj[i].append(j)
                adj[j].append(i)
                
    # Find connected components (BFS)
    visited = set()
    molecules = []
    for i in active:
        if i in visited: continue
        comp = []
        stack = [i]
        visited.add(i)
        while stack:
            u = stack.pop()
            comp.append(u)
            for v in adj[u]:
                if v not in visited:
                    visited.add(v)
                    stack.append(v)
        
        m_labels = [labels[idx] for idx in comp]
        m_pos = pos[comp]
        molecules.append(AdsorbateMolecule(comp, m_labels, m_pos))
        
    return molecules

def _check_collision(apm, moving_indices: np.ndarray, proposed_positions: np.ndarray, tolerance: float) -> bool:
    """True if NO collisions found."""
    n_atoms = len(apm.atomPositions)
    # Atoms to check against: everything not currently moving
    fixed_mask = np.ones(n_atoms, dtype=bool)
    if moving_indices.size > 0:
        fixed_mask[moving_indices.astype(int)] = False
    fixed_indices = np.where(fixed_mask)[0]
    
    if fixed_indices.size == 0:
        return True
        
    fixed_pos = apm.atomPositions[fixed_indices]
    for p in proposed_positions:
        dists = _distances_to_point(apm, fixed_pos, p)
        if np.any(dists < tolerance):
            return False
    return True

# --- Mutation Operators ---

def mutation_move_adsorbate(
    allowed_species: Optional[List[str]] = None,
    max_translation: float = 3.0,
    constraints: Optional[List[Callable]] = None,
    collision_tolerance: float = 1.8,
    max_attempts: int = 20,
):
    """Moves a molecular adsorbate to a new site, preserving its identity."""
    def func(structure, rng: np.random.Generator | None = None):
        if rng is None: rng = np.random.default_rng()
        mols = identify_adsorbates(structure, constraints)
        if allowed_species:
            mols = [m for m in mols if m.formula in allowed_species]
        if not mols: return None
        
        idx = rng.integers(len(mols))
        mol = mols[idx]
        apm = structure.AtomPositionManager
        
        for _ in range(max_attempts):
            shift = rng.uniform(-max_translation, max_translation, size=3)
            proposed_pos = mol.positions + shift
            
            # 1. Check collision
            if _check_collision(apm, mol.indices, proposed_pos, collision_tolerance):
                # 2. Check if the molecule remains valid under constraints
                if constraints:
                    # Temporary update for check
                    orig_pos = apm.atomPositions[mol.indices].copy()
                    apm.atomPositions[mol.indices] = proposed_pos
                    
                    # Verify it's still identified correctly
                    # (Quick check: all atoms pass constraints)
                    all_pass = all(validate(i, structure, constraints) for i in mol.indices)
                    
                    if not all_pass:
                        apm.atomPositions[mol.indices] = orig_pos # Restore
                        continue
                        
                    # Also verify it doesn't merge with others in a weird way? 
                    # Usually move doesn't merge unless it's very close, which collision check handles.
                    
                    # Restore and proceed to create the final copy
                    apm.atomPositions[mol.indices] = orig_pos
                
                # Success
                child = copy.deepcopy(structure)
                child_apm = child.AtomPositionManager
                new_pos = child_apm.atomPositions.copy()
                new_pos[mol.indices] = proposed_pos
                child_apm.set_atomPositions(new_pos)
                return child
        return None
    return func

def mutation_rotate_adsorbate(
    allowed_species: Optional[List[str]] = None,
    constraints: Optional[List[Callable]] = None,
    collision_tolerance: float = 1.8,
    max_attempts: int = 10,
):
    """Rotates a molecular adsorbate around its center of mass."""
    def func(structure, rng: np.random.Generator | None = None):
        if rng is None: rng = np.random.default_rng()
        mols = identify_adsorbates(structure, constraints)
        if allowed_species:
            mols = [m for m in mols if m.formula in allowed_species]
        if not mols: return None
        
        idx = rng.integers(len(mols))
        mol = mols[idx]
        apm = structure.AtomPositionManager
        
        for _ in range(max_attempts):
            R = random_rotation_matrix(rng)
            proposed_pos = (mol.rel_positions @ R.T) + mol.com
            
            if _check_collision(apm, mol.indices, proposed_pos, collision_tolerance):
                if constraints:
                    orig_pos = apm.atomPositions[mol.indices].copy()
                    apm.atomPositions[mol.indices] = proposed_pos
                    all_pass = all(validate(i, structure, constraints) for i in mol.indices)
                    if not all_pass:
                        apm.atomPositions[mol.indices] = orig_pos
                        continue
                    apm.atomPositions[mol.indices] = orig_pos
                
                child = copy.deepcopy(structure)
                child_apm = child.AtomPositionManager
                new_pos = child_apm.atomPositions.copy()
                new_pos[mol.indices] = proposed_pos
                child_apm.set_atomPositions(new_pos)
                return child
        return None
    return func

def mutation_swap_adsorbates(
    allowed_species: Optional[List[str]] = None,
    constraints: Optional[List[Callable]] = None,
    collision_tolerance: float = 1.8,
    max_attempts: int = 10,
):
    """Swaps positions of two molecular adsorbates."""
    def func(structure, rng: np.random.Generator | None = None):
        if rng is None: rng = np.random.default_rng()
        mols = identify_adsorbates(structure, constraints)
        if allowed_species:
            mols = [m for m in mols if m.formula in allowed_species]
        if len(mols) < 2: return None
        
        # Pick two distinct molecules
        idx1, idx2 = rng.choice(len(mols), size=2, replace=False)
        mol1, mol2 = mols[idx1], mols[idx2]
        
        apm = structure.AtomPositionManager
        
        # Propose swap: M1 goes to COM2, M2 goes to COM1
        # We can also keep original orientations or randomize them? 
        # User requested "swap adsorbate positions", usually implies keeping internal geom.
        pos1 = mol1.rel_positions + mol2.com
        pos2 = mol2.rel_positions + mol1.com
        
        # Combined collision check
        if _check_collision(apm, mol1.indices, pos2, collision_tolerance) and \
           _check_collision(apm, mol2.indices, pos1, collision_tolerance):
            
            if constraints:
                # Temporary check
                orig_pos1 = apm.atomPositions[mol1.indices].copy()
                orig_pos2 = apm.atomPositions[mol2.indices].copy()
                apm.atomPositions[mol1.indices] = pos1
                apm.atomPositions[mol2.indices] = pos2
                
                all_pass = all(validate(i, structure, constraints) for i in np.concatenate([mol1.indices, mol2.indices]))
                
                if not all_pass:
                    apm.atomPositions[mol1.indices] = orig_pos1
                    apm.atomPositions[mol2.indices] = orig_pos2
                    return None
                    
                apm.atomPositions[mol1.indices] = orig_pos1
                apm.atomPositions[mol2.indices] = orig_pos2

            child = copy.deepcopy(structure)
            child_apm = child.AtomPositionManager
            new_pos = child_apm.atomPositions.copy()
            new_pos[mol1.indices] = pos1
            new_pos[mol2.indices] = pos2
            child_apm.set_atomPositions(new_pos)
            return child
        return None
    return func

def mutation_replace_adsorbate(
    templates: Optional[Dict[str, Dict[str, Any]]] = None,
    allowed_species: Optional[List[str]] = None,
    constraints: Optional[List[Callable]] = None,
    collision_tolerance: float = 1.8,
    max_attempts: int = 20,
):
    """
    Replaces one adsorbate with another from SAGE or a template library.
    """
    def func(structure, rng: np.random.Generator | None = None):
        if rng is None: rng = np.random.default_rng()
        mols = identify_adsorbates(structure, constraints)
        if allowed_species:
            mols = [m for m in mols if m.formula in allowed_species]
        if not mols: return None
        
        idx = rng.integers(len(mols))
        mol = mols[idx]
        
        # Determine choices for replacement
        if allowed_species:
            choices = [f for f in allowed_species if f != mol.formula]
        elif templates:
            choices = [f for f in templates.keys() if f != mol.formula]
        else:
            return None # No source of templates
            
        if not choices: return None
        
        target_f = rng.choice(choices)
        temp = _fetch_template(target_f, templates)
        if not temp: return None
        
        temp_labels = temp["labels"]
        temp_pos = np.array(temp["positions"])
        temp_com = np.mean(temp_pos, axis=0)
        temp_rel = temp_pos - temp_com
        
        # We need to replace mol.indices with temp_labels and temp_pos
        # This is tricky because the number of atoms might change!
        # If the number of atoms changes, we need to modify the structure.
        
        apm = structure.AtomPositionManager
        
        # 1. Collision check at mol.com
        # Since number of atoms changes, we first "remove" the old one and check "insertion"
        for _ in range(max_attempts):
            # Random orientation for the new template
            R = random_rotation_matrix(rng)
            proposed_pos = (temp_rel @ R.T) + mol.com
            
            # Use _check_collision but indices are removed first
            fixed_mask = np.ones(len(apm.atomPositions), dtype=bool)
            fixed_mask[mol.indices] = False
            fixed_indices = np.where(fixed_mask)[0]
            fixed_pos = apm.atomPositions[fixed_indices]
            
            collision = False
            for p in proposed_pos:
                dists = _distances_to_point(apm, fixed_pos, p)
                if np.any(dists < collision_tolerance):
                    collision = True
                    break
            
            if not collision:
                # Perform surgery: remove mol.indices, add target_f atoms
                # This depends on APM having remove_atom / add_atom or slice support
                child = copy.deepcopy(structure)
                child_apm = child.AtomPositionManager
                
                # Delete old atoms (in reverse to preserve indices)
                for idx in sorted(mol.indices, reverse=True):
                    # check if child_apm has delete/remove
                    if hasattr(child_apm, "remove_atom"):
                        child_apm.remove_atom(idx)
                    else:
                        # manual fallback if it's just a simple manager
                        child_apm.atomPositions = np.delete(child_apm.atomPositions, idx, axis=0)
                        child_apm.atomLabelsList.pop(idx)
                
                # Add new atoms
                new_indices = []
                for i in range(len(temp_labels)):
                    if hasattr(child_apm, "add_atom"):
                        child_apm.add_atom(temp_labels[i], proposed_pos[i])
                    else:
                        child_apm.atomPositions = np.vstack([child_apm.atomPositions, proposed_pos[i]])
                        child_apm.atomLabelsList.append(temp_labels[i])
                    new_indices.append(len(child_apm.atomPositions) - 1)
                
                # 2. Check constraints on new atoms
                if constraints:
                    if all(validate(idx, child, constraints) for idx in new_indices):
                        return child
                    else:
                        continue # Try another orientation
                
                return child
        return None
    return func

def mutation_add_remove_adsorbate(
    templates: Optional[Dict[str, Dict[str, Any]]] = None,
    allowed_species: Optional[List[str]] = None,
    constraints: Optional[List[Callable]] = None,
    collision_tolerance: float = 1.8,
    add_prob: float = 0.5,
    max_attempts: int = 50,
):
    """Adds or removes a molecular adsorbate using SAGE or a template library."""
    def func(structure, rng: np.random.Generator | None = None):
        if rng is None: rng = np.random.default_rng()
        mols = identify_adsorbates(structure, constraints)
        if allowed_species:
            mols = [m for m in mols if m.formula in allowed_species]
        
        do_add = rng.random() < add_prob
        
        # If no molecules to remove, we must add
        if not mols: do_add = True
        
        apm = structure.AtomPositionManager
        
        if do_add:
            # 1. Pick species
            if allowed_species:
                choices = allowed_species
            elif templates:
                choices = list(templates.keys())
            else:
                return None
                
            if not choices: return None
            target_f = rng.choice(choices)
            temp = _fetch_template(target_f, templates)
            if not temp: return None
            
            temp_labels = temp["labels"]
            temp_pos = np.array(temp["positions"])
            temp_com = np.mean(temp_pos, axis=0)
            temp_rel = temp_pos - temp_com
            
            # 2. Find a random site in constraints
            # We sample from the cell and check validate
            cell = _get_cell(structure)
            if cell is None: # Gas phase fallback
                box_min = np.min(apm.atomPositions, axis=0) - 5.0
                box_max = np.max(apm.atomPositions, axis=0) + 5.0
            
            for _ in range(max_attempts):
                if cell is not None:
                    f_site = rng.random(3)
                    site = _frac_to_cart(cell, f_site)[0]
                else:
                    site = rng.uniform(box_min, box_max)
                
                # Check if site passes constraints
                # We check a dummy atom at this site
                # This is a bit hacky but works with our validate()
                # We need a temporary structure or just call the constraint directly
                # Most constraints only use the position.
                
                # Check collision at site
                R = random_rotation_matrix(rng)
                proposed_pos = (temp_rel @ R.T) + site
                
                # We need to check if ALL atoms of the new molecule pass constraints
                # For efficiency, we just check the COM for now or the first atom
                # But proper way is to check all.
                
                # Since validate() takes an INDEX, we can't easily check a point.
                # HOWEVER, many ezga constraints are closure-based on pos.
                # I'll skip constraint check for the SITE for now and rely on 
                # user providing a bounding box or similar if needed, 
                # OR I'll assume the user is okay with random insertion if no constraints.
                
                # Actually, I can check if the site is near an existing "active" atom?
                # No, let's just do collision check.
                
                if _check_collision(apm, np.array([]), proposed_pos, collision_tolerance):
                    child = copy.deepcopy(structure)
                    child_apm = child.AtomPositionManager
                    new_indices = []
                    for i in range(len(temp_labels)):
                        if hasattr(child_apm, "add_atom"):
                            child_apm.add_atom(temp_labels[i], proposed_pos[i])
                        else:
                            child_apm.atomPositions = np.vstack([child_apm.atomPositions, proposed_pos[i]])
                            child_apm.atomLabelsList.append(temp_labels[i])
                        new_indices.append(len(child_apm.atomPositions) - 1)
                    
                    # Verify constraints on new atoms
                    if constraints:
                        if all(validate(idx, child, constraints) for idx in new_indices):
                            return child
                        else:
                            continue # Try another site
                    return child
        else:
            # 1. Pick molecule to remove
            idx = rng.integers(len(mols))
            mol = mols[idx]
            child = copy.deepcopy(structure)
            child_apm = child.AtomPositionManager
            for idx in sorted(mol.indices, reverse=True):
                if hasattr(child_apm, "remove_atom"):
                    child_apm.remove_atom(idx)
                else:
                    child_apm.atomPositions = np.delete(child_apm.atomPositions, idx, axis=0)
                    child_apm.atomLabelsList.pop(idx)
            return child
            
        return None
    return func

def validate_adsorbate_fragments(structure: Any, allowed_formulas: Set[str], constraints: List[Callable]) -> bool:
    """
    Validates that all atoms in the region defined by constraints belong to 
    permitted molecular species. Returns False if any "loose" atoms or 
    unauthorized molecules are found.
    """
    mols = identify_adsorbates(structure, constraints)
    
    # Check if all atoms in active region were assigned to molecules
    apm = structure.AtomPositionManager
    active_indices = {i for i in range(len(apm.atomPositions)) if validate(i, structure, constraints)}
    assigned_indices: Set[int] = set()
    for m in mols:
        assigned_indices.update(m.indices)
        if m.formula not in allowed_formulas:
            logger.debug(f"[AdsorbateValidator] Forbidden molecule found: {m.formula}")
            return False
            
    if active_indices != assigned_indices:
        logger.debug(f"[AdsorbateValidator] Active atoms not assigned to molecules: {active_indices - assigned_indices}")
        return False 
        
    return True
