from __future__ import annotations
"""
mutation_docking.py
-------------------

Specialized mutations for docking protein-ligand systems.
Includes collision resolution using a vdW-based hard-sphere model.
"""

import numpy as np
from typing import Optional, Tuple, List, Any
from ezga.utils.helper_functions import validate
from .geo_utils import random_rotation_matrix
from ezga.utils.constraints_pdb import (
    residue_in, POLAR_RESIDUES, POSITIVE_RESIDUES, NEGATIVE_RESIDUES,
    HYDROPHOBIC_RESIDUES, AROMATIC_RESIDUES
)

def _get_partial_charges(structure, indices) -> np.ndarray:
    """Extract partial charges from structure.atoms.info_atoms."""
    atoms = getattr(structure, "atoms", structure)
    info = getattr(atoms, "info_atoms", {})
    if "partial_charge" not in info:
        return np.zeros(len(indices))

    charges = []
    for i in indices:
        try:
            charges.append(float(info["partial_charge"][i]))
        except (IndexError, KeyError, ValueError, TypeError):
            charges.append(0.0)

    return np.asarray(charges, dtype=float)

# Simple VdW Radii for more realistic collision avoidance
# Values from standard literature (approximate)
VDW_RADII = {
    "H": 1.20, "C": 1.70, "N": 1.55, "O": 1.52, "S": 1.80, "P": 1.80, "F": 1.47, "Cl": 1.75, "Br": 1.85, "I": 1.98,
    "DEFAULT": 1.50
}

def _get_vdw_radii(symbols: List[str]) -> np.ndarray:
    return np.array([VDW_RADII.get(s.capitalize(), VDW_RADII["DEFAULT"]) for s in symbols])

def _get_ligand_receptor_data(
    structure,
    ligand_constraints: Optional[List] = None,
    receptor_constraints: Optional[List] = None,
):
    """Helper to extract common structural data for docking mutations."""
    apm = structure.AtomPositionManager
    pos = apm.atomPositions
    symbols = apm.atomLabelsList

    ligand_indices = [i for i in range(len(pos)) if validate(i, structure, ligand_constraints or [])]
    receptor_indices = [i for i in range(len(pos)) if validate(i, structure, receptor_constraints or [])]

    if not ligand_indices or not receptor_indices:
        return None

    return {
        "apm": apm,
        "pos": pos,
        "symbols": symbols,
        "ligand_indices": ligand_indices,
        "receptor_indices": receptor_indices,
        "lig_pos": pos[ligand_indices].copy(),
        "rec_pos": pos[receptor_indices].copy(),
        "lig_symbols": [symbols[i] for i in ligand_indices],
        "rec_symbols": [symbols[i] for i in receptor_indices],
        "lig_radii": _get_vdw_radii([symbols[i] for i in ligand_indices]),
        "rec_radii": _get_vdw_radii([symbols[i] for i in receptor_indices]),
        "lig_charges": _get_partial_charges(structure, ligand_indices),
        "rec_charges": _get_partial_charges(structure, receptor_indices),
    }

def resolve_ligand_collisions(
    ligand_pos: np.ndarray, 
    receptor_pos: np.ndarray, 
    ligand_radii: np.ndarray,
    receptor_radii: np.ndarray,
    min_dist_scale: float = 0.8,
    max_steps: int = 50,
    rng: np.random.Generator | None = None
) -> Tuple[np.ndarray, bool, int]:
    """
    Shifts the ligand positions as a rigid body to avoid collisions with the receptor.
    Uses a push-out algorithm with vdW-based distance checks.
    """
    if rng is None:
        rng = np.random.default_rng()
        
    pos = ligand_pos.copy()
    rec = receptor_pos
    
    # Combined radii matrix (N_lig, N_rec)
    min_dist_matrix = (ligand_radii[:, np.newaxis] + receptor_radii[np.newaxis, :]) * min_dist_scale
    min_dist_sq_matrix = min_dist_matrix**2
    
    final_num_collisions = 0
    
    for _ in range(max_steps):
        diff = pos[:, np.newaxis, :] - rec[np.newaxis, :, :] 
        dist_sq = np.sum(diff**2, axis=-1)
        
        collisions = dist_sq < min_dist_sq_matrix
        final_num_collisions = int(np.sum(collisions))
        
        if final_num_collisions == 0:
            return pos, True, 0
            
        dist = np.sqrt(dist_sq)
        
        # Handle exact overlaps
        zero_dist = dist < 1e-8
        if np.any(zero_dist):
            noise = rng.normal(scale=1e-4, size=diff.shape)
            diff = np.where(zero_dist[:, :, np.newaxis], noise, diff)
            dist = np.where(zero_dist, np.linalg.norm(noise, axis=-1), dist)
        
        push_vecs = diff / np.maximum(dist[:, :, np.newaxis], 1e-12)
        push_mags = np.maximum(min_dist_matrix - dist, 0.0)
        
        pair_pushes = push_vecs * push_mags[:, :, np.newaxis] * collisions[:, :, np.newaxis]
        shift = np.sum(pair_pushes, axis=(0, 1)) / final_num_collisions
        
        pos += 1.2 * shift
            
    return pos, False, final_num_collisions

def _simple_docking_geometry_score(
    ligand_pos: np.ndarray,
    receptor_pos: np.ndarray,
    ligand_radii: np.ndarray,
    receptor_radii: np.ndarray,
    pocket_center: np.ndarray,
    pocket_radius: float = 8.0,
    contact_dist: float = 4.0,
    min_dist_scale: float = 0.8,
    n_collisions: int = 0,
    ligand_charges: np.ndarray | None = None,
    receptor_charges: np.ndarray | None = None,
    electrostatic_weight: float = 0.2,
) -> float:
    """Simple docking score including contacts, pocket constraints and electrostatics. Lower is better."""
    diff = ligand_pos[:, np.newaxis, :] - receptor_pos[np.newaxis, :, :]
    dist = np.linalg.norm(diff, axis=-1)
    
    collision_penalty = 100.0 * n_collisions
    min_dist_matrix = (ligand_radii[:, np.newaxis] + receptor_radii[np.newaxis, :]) * min_dist_scale
    
    # Reward contacts, normalized by ligand size
    contacts = (dist > min_dist_matrix) & (dist < contact_dist)
    contact_reward = -float(np.sum(contacts)) / len(ligand_pos)
    
    # Penalize if ligand COM is too far from pocket center or outside pocket radius
    ligand_com = ligand_pos.mean(axis=0)
    pocket_distance = np.linalg.norm(ligand_com - pocket_center)
    
    outside = max(0.0, pocket_distance - pocket_radius)
    pocket_penalty = 0.2 * (pocket_distance**2) + 5.0 * (outside**2)
    
    electrostatic_score: float = 0.0
    if ligand_charges is not None and receptor_charges is not None:
        # q_i * q_j / r_ij
        qij = ligand_charges[:, np.newaxis] * receptor_charges[np.newaxis, :]
        safe_dist = np.maximum(dist, 1.5) # Soften at very short range
        electrostatic_score = float(electrostatic_weight * np.sum(qij / safe_dist))
    
    return float(collision_penalty + contact_reward + pocket_penalty + electrostatic_score)

def docking_move(
    structure, 
    ligand_constraints: Optional[List] = None,
    receptor_constraints: Optional[List] = None,
    mode: str = 'global',
    max_translation: float = 2.0,
    max_rotation_deg: float = 180.0,
    min_dist_scale: float = 0.8,
    binding_site_center: Optional[np.ndarray] = None,
    binding_site_radius: float = 10.0,
    max_resolve_steps: int = 50,
    seed: int | None = None,
    rng: np.random.Generator | None = None,
    **kwargs
):
    """General docking move: global random placement or local refinement."""
    data = _get_ligand_receptor_data(structure, ligand_constraints, receptor_constraints)
    if not data: return None, None

    if rng is None: rng = np.random.default_rng(seed)
        
    lig_pos = data["lig_pos"]
    rec_pos = data["rec_pos"]
    lig_com = lig_pos.mean(axis=0)
    
    if mode == 'global':
        if binding_site_center is not None:
            dist_to_site = np.linalg.norm(rec_pos - binding_site_center, axis=1)
            valid_targets = [data["receptor_indices"][i] for i, d in enumerate(dist_to_site) if d < binding_site_radius]
            if not valid_targets: valid_targets = data["receptor_indices"]
        else:
            valid_targets = data["receptor_indices"]
            
        target_idx = rng.choice(valid_targets)
        target_pos = data["pos"][target_idx]
        
        direction = rng.normal(size=3)
        direction /= (np.linalg.norm(direction) + 1e-8)
        
        # Use ligand size to determine placement distance
        ligand_extent = np.max(np.linalg.norm(lig_pos - lig_com, axis=1))
        placement_dist = ligand_extent * 0.5 + 3.0
        new_com = target_pos + direction * placement_dist
        
        lig_pos += (new_com - lig_com)
        R = random_rotation_matrix(rng)
        lig_pos = (lig_pos - new_com) @ R.T + new_com
    else:
        trans = rng.uniform(-max_translation, max_translation, size=3)
        lig_pos += trans
        new_lig_com = lig_pos.mean(axis=0)
        
        angle = np.radians(rng.uniform(0, max_rotation_deg))
        axis = rng.normal(size=3)
        axis /= (np.linalg.norm(axis) + 1e-8)
        
        try:
            from scipy.spatial.transform import Rotation
            R = Rotation.from_rotvec(axis * angle).as_matrix()
        except ImportError:
            R = random_rotation_matrix(rng)
        lig_pos = (lig_pos - new_lig_com) @ R.T + new_lig_com
        
    final_lig_pos, resolved, n_collisions = resolve_ligand_collisions(
        lig_pos, rec_pos, data["lig_radii"], data["rec_radii"], min_dist_scale, max_resolve_steps, rng=rng
    )
    
    new_pos = data["pos"].copy()
    new_pos[data["ligand_indices"]] = final_lig_pos
    data["apm"].set_atomPositions(new_pos)
    
    return structure, {
        "ligand_indices": data["ligand_indices"],
        "mode": mode,
        "resolved": resolved,
        "n_collisions": n_collisions
    }

def anchor_atom_move(
    structure,
    ligand_anchor_constraints: List,
    receptor_target_constraints: List,
    ligand_constraints: Optional[List] = None,
    receptor_constraints: Optional[List] = None,
    target_dist: float = 2.0,
    max_rotation_deg: float = 180.0,
    min_dist_scale: float = 0.8,
    max_resolve_steps: int = 50,
    seed: int | None = None,
    rng: np.random.Generator | None = None,
    **kwargs,
):
    """Pin a specific ligand atom near a receptor target atom."""
    data = _get_ligand_receptor_data(structure, ligand_constraints, receptor_constraints)
    if not data: return None, None

    if rng is None: rng = np.random.default_rng(seed)

    anchor_indices = [i for i in data["ligand_indices"] if validate(i, structure, ligand_anchor_constraints)]
    target_indices = [i for i in data["receptor_indices"] if validate(i, structure, receptor_target_constraints)]

    if not anchor_indices or not target_indices: return None, None

    anchor_idx = rng.choice(anchor_indices)
    target_idx = rng.choice(target_indices)
    
    # Internal index of anchor within lig_pos
    anchor_local_idx = data["ligand_indices"].index(anchor_idx)
    anchor_pos = data["lig_pos"][anchor_local_idx]
    target_pos = data["pos"][target_idx]

    lig_pos = data["lig_pos"]
    
    direction = rng.normal(size=3)
    direction /= np.linalg.norm(direction) + 1e-12
    new_anchor_pos = target_pos + direction * target_dist
    
    lig_pos += (new_anchor_pos - anchor_pos)
    
    angle = np.radians(rng.uniform(0, max_rotation_deg))
    axis = rng.normal(size=3)
    axis /= (np.linalg.norm(axis) + 1e-8)
    
    try:
        from scipy.spatial.transform import Rotation
        R = Rotation.from_rotvec(axis * angle).as_matrix()
    except ImportError:
        R = random_rotation_matrix(rng)
    lig_pos = (lig_pos - new_anchor_pos) @ R.T + new_anchor_pos

    final_lig_pos, resolved, n_collisions = resolve_ligand_collisions(
        lig_pos, data["rec_pos"], data["lig_radii"], data["rec_radii"], min_dist_scale, max_resolve_steps, rng=rng
    )

    new_pos = data["pos"].copy()
    new_pos[data["ligand_indices"]] = final_lig_pos
    data["apm"].set_atomPositions(new_pos)

    # Final distance check
    final_anchor_pos = final_lig_pos[anchor_local_idx]
    final_dist = np.linalg.norm(final_anchor_pos - target_pos)

    return structure, {
        "ligand_indices": data["ligand_indices"],
        "mutation": "anchor_atom_move",
        "anchor_idx": int(anchor_idx),
        "target_idx": int(target_idx),
        "final_anchor_target_dist": float(final_dist),
        "resolved": resolved,
        "n_collisions": n_collisions
    }

def pocket_contact_move(
    structure,
    ligand_constraints: Optional[List] = None,
    receptor_constraints: Optional[List] = None,
    pocket_center: Optional[np.ndarray] = None,
    pocket_radius: float = 8.0,
    max_translation: float = 2.0,
    min_dist_scale: float = 0.8,
    contact_dist: float = 4.0,
    n_orientation_trials: int = 16,
    max_resolve_steps: int = 50,
    seed: int | None = None,
    rng: np.random.Generator | None = None,
    **kwargs,
):
    """Guided pocket exploration with orientation scoring."""
    data = _get_ligand_receptor_data(structure, ligand_constraints, receptor_constraints)
    if not data: return None, None

    if rng is None: rng = np.random.default_rng(seed)

    lig_pos_original = data["lig_pos"]
    rec_pos_all = data["rec_pos"]
    lig_com = lig_pos_original.mean(axis=0)

    if pocket_center is None:
        pocket_center = rec_pos_all.mean(axis=0)
    else:
        pocket_center = np.asarray(pocket_center, dtype=float)

    dist_to_pocket = np.linalg.norm(rec_pos_all - pocket_center, axis=1)
    pocket_mask = dist_to_pocket <= (pocket_radius + 5.0)
    
    rec_pos = rec_pos_all[pocket_mask] if np.any(pocket_mask) else rec_pos_all
    rec_radii = data["rec_radii"][pocket_mask] if np.any(pocket_mask) else data["rec_radii"]

    direction = rng.normal(size=3)
    direction /= np.linalg.norm(direction) + 1e-12
    radius = pocket_radius * (rng.random() ** (1.0 / 3.0))
    target_com = pocket_center + radius * direction
    target_com += rng.uniform(-max_translation, max_translation, size=3)

    base_lig_pos = lig_pos_original + (target_com - lig_com)
    best_score = np.inf
    best_lig_pos = base_lig_pos.copy()

    for _ in range(n_orientation_trials):
        R = random_rotation_matrix(rng)
        trial_lig_pos = (base_lig_pos - target_com) @ R.T + target_com

        trial_lig_pos, _, n_col = resolve_ligand_collisions(
            trial_lig_pos, rec_pos, data["lig_radii"], rec_radii, min_dist_scale, max_resolve_steps, rng=rng
        )

        score = _simple_docking_geometry_score(
            trial_lig_pos, rec_pos, data["lig_radii"], rec_radii, pocket_center, pocket_radius, contact_dist, min_dist_scale, n_col,
            ligand_charges=data["lig_charges"], receptor_charges=data["rec_charges"]
        )

        if score < best_score:
            best_score = score
            best_lig_pos = trial_lig_pos

    new_pos = data["pos"].copy()
    new_pos[data["ligand_indices"]] = best_lig_pos
    data["apm"].set_atomPositions(new_pos)

    return structure, {
        "ligand_indices": data["ligand_indices"],
        "mutation": "pocket_contact_move",
        "score": float(best_score),
        "pocket_center": pocket_center.tolist()
    }

def contact_preserving_rotation(
    structure,
    ligand_constraints: Optional[List] = None,
    receptor_constraints: Optional[List] = None,
    max_rotation_deg: float = 30.0,
    min_dist_scale: float = 0.8,
    max_resolve_steps: int = 50,
    seed: int | None = None,
    rng: np.random.Generator | None = None,
    **kwargs,
):
    """Rotate around the closest non-clashing contact point."""
    data = _get_ligand_receptor_data(structure, ligand_constraints, receptor_constraints)
    if not data: return None, None

    if rng is None: rng = np.random.default_rng(seed)

    lig_pos = data["lig_pos"]
    rec_pos = data["rec_pos"]
    
    diff = lig_pos[:, np.newaxis, :] - rec_pos[np.newaxis, :, :]
    dist = np.linalg.norm(diff, axis=-1)
    
    # Try to find a valid contact (not a clash)
    min_dist_matrix = (data["lig_radii"][:, None] + data["rec_radii"][None, :]) * min_dist_scale
    valid_contacts = dist > min_dist_matrix
    
    if np.any(valid_contacts):
        masked_dist = np.where(valid_contacts, dist, np.inf)
        lig_idx_local, _ = np.unravel_index(np.argmin(masked_dist), dist.shape)
    else:
        lig_idx_local, _ = np.unravel_index(np.argmin(dist), dist.shape)
        
    anchor_pos = lig_pos[lig_idx_local]

    angle = np.radians(rng.uniform(0, max_rotation_deg))
    axis = rng.normal(size=3)
    axis /= (np.linalg.norm(axis) + 1e-8)
    
    try:
        from scipy.spatial.transform import Rotation
        R = Rotation.from_rotvec(axis * angle).as_matrix()
    except ImportError:
        R = random_rotation_matrix(rng)
    lig_pos = (lig_pos - anchor_pos) @ R.T + anchor_pos

    final_lig_pos, resolved, n_collisions = resolve_ligand_collisions(
        lig_pos, rec_pos, data["lig_radii"], data["rec_radii"], min_dist_scale, max_resolve_steps, rng=rng
    )

    new_pos = data["pos"].copy()
    new_pos[data["ligand_indices"]] = final_lig_pos
    data["apm"].set_atomPositions(new_pos)

    return structure, {
        "ligand_indices": data["ligand_indices"],
        "mutation": "contact_preserving_rotation",
        "anchor_lig_idx": int(data["ligand_indices"][lig_idx_local]),
        "resolved": resolved,
        "n_collisions": n_collisions
    }

def charge_guided_anchor_move(
    structure,
    ligand_constraints: Optional[List] = None,
    receptor_constraints: Optional[List] = None,
    ligand_charge_threshold: float = 0.2,
    receptor_charge_threshold: float = 0.2,
    target_dist: float = 2.8,
    max_rotation_deg: float = 180.0,
    min_dist_scale: float = 0.8,
    max_resolve_steps: int = 50,
    seed: int | None = None,
    rng: np.random.Generator | None = None,
    **kwargs,
):
    """Move a charged ligand atom near an oppositely charged receptor atom."""
    data = _get_ligand_receptor_data(structure, ligand_constraints, receptor_constraints)
    if not data: return None, None

    if rng is None: rng = np.random.default_rng(seed)

    lig_q = data["lig_charges"]
    rec_q = data["rec_charges"]

    candidate_pairs = []
    for i_local, q_l in enumerate(lig_q):
        if abs(q_l) < ligand_charge_threshold: continue
        for j_local, q_r in enumerate(rec_q):
            if abs(q_r) < receptor_charge_threshold: continue
            
            # Target opposite charges
            if q_l * q_r < 0.0:
                strength = abs(q_l * q_r)
                candidate_pairs.append((strength, i_local, j_local))

    if not candidate_pairs: return None, None

    # Weighted choice based on interaction strength
    weights = np.array([p[0] for p in candidate_pairs])
    weights /= weights.sum()
    
    pair_idx = rng.choice(len(candidate_pairs), p=weights)
    _, anchor_local_idx, target_local_idx = candidate_pairs[pair_idx]

    lig_pos = data["lig_pos"]
    anchor_pos = lig_pos[anchor_local_idx]
    target_pos = data["rec_pos"][target_local_idx]
    
    direction = rng.normal(size=3)
    direction /= (np.linalg.norm(direction) + 1e-12)
    new_anchor_pos = target_pos + direction * target_dist
    
    lig_pos += (new_anchor_pos - anchor_pos)
    R = random_rotation_matrix(rng)
    lig_pos = (lig_pos - new_anchor_pos) @ R.T + new_anchor_pos

    final_lig_pos, resolved, n_collisions = resolve_ligand_collisions(
        lig_pos, data["rec_pos"], data["lig_radii"], data["rec_radii"], min_dist_scale, max_resolve_steps, rng=rng
    )

    new_pos = data["pos"].copy()
    new_pos[data["ligand_indices"]] = final_lig_pos
    data["apm"].set_atomPositions(new_pos)

    return structure, {
        "mutation": "charge_guided_anchor_move",
        "ligand_anchor_idx": int(data["ligand_indices"][anchor_local_idx]),
        "receptor_target_idx": int(data["receptor_indices"][target_local_idx]),
        "ligand_charge": float(lig_q[anchor_local_idx]),
        "receptor_charge": float(rec_q[target_local_idx]),
        "resolved": resolved,
        "n_collisions": n_collisions
    }

def polar_pocket_contact_move(structure, **kwargs):
    """Pocket move favoring polar/charged residues."""
    rec_constraints = list(kwargs.get("receptor_constraints") or [])
    rec_constraints.append(residue_in(POLAR_RESIDUES | POSITIVE_RESIDUES | NEGATIVE_RESIDUES))
    kwargs["receptor_constraints"] = rec_constraints
    return pocket_contact_move(structure, **kwargs)

def hydrophobic_pocket_contact_move(structure, **kwargs):
    """Pocket move favoring hydrophobic residues."""
    rec_constraints = list(kwargs.get("receptor_constraints") or [])
    rec_constraints.append(residue_in(HYDROPHOBIC_RESIDUES | AROMATIC_RESIDUES))
    kwargs["receptor_constraints"] = rec_constraints
    return pocket_contact_move(structure, **kwargs)

def sidechain_jitter_move(
    structure,
    residue_constraints: List,
    max_displacement: float = 0.2,
    seed: int | None = None,
    rng: np.random.Generator | None = None,
    **kwargs
):
    """Randomly perturb sidechain atoms to simulate local flexibility."""
    from ezga.utils.constraints_pdb import sidechain_atom
    
    if rng is None: rng = np.random.default_rng(seed)
    
    apm = structure.AtomPositionManager
    pos = apm.atomPositions.copy()
    
    movable_indices = [
        i for i in range(len(pos)) 
        if validate(i, structure, residue_constraints) and sidechain_atom()(i, structure)
    ]
    
    if not movable_indices: return None, None
    
    displacements = rng.normal(scale=max_displacement, size=(len(movable_indices), 3))
    pos[movable_indices] += displacements
    apm.set_atomPositions(pos)
    
    return structure, {
        "mutation": "sidechain_jitter_move",
        "moved_atoms_count": len(movable_indices)
    }
