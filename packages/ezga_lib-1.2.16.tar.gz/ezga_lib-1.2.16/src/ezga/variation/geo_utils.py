from __future__ import annotations
"""
geo_utils.py
------------

Shared geometric utilities for variation operators.
"""

import numpy as np
from typing import cast

def random_rotation_matrix(rng: np.random.Generator) -> np.ndarray:
    """
    Generates a random 3x3 rotation matrix.
    Uses SciPy's Rotation.random if available, otherwise falls back to a quaternion-based implementation.
    """
    try:
        from scipy.spatial.transform import Rotation
        return cast(np.ndarray, Rotation.random(random_state=rng).as_matrix())
    except ImportError:
        # Quaternion fallback, no SciPy required.
        q = rng.normal(size=4)
        q /= (np.linalg.norm(q) + 1e-8)
        w, x, y, z = q

        return np.array([
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w),     2 * (x * z + y * w)],
            [2 * (x * y + z * w),     1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w),     2 * (y * z + x * w),     1 - 2 * (x * x + y * y)],
        ])

def _apply_pbc_displacement(apm, dr: np.ndarray) -> np.ndarray:
    """
    Applies periodic boundary conditions to a displacement vector using the AtomPositionManager.
    """
    if hasattr(apm, "apply_pbc_to_displacement"):
        try:
            return cast(np.ndarray, apm.apply_pbc_to_displacement(dr))
        except Exception:
            if dr.ndim == 2:
                return np.vstack([apm.apply_pbc_to_displacement(x) for x in dr])
            return dr
    return dr

def _distances_to_point(apm, positions: np.ndarray, point: np.ndarray) -> np.ndarray:
    """
    Calculates distances from a set of positions to a target point, accounting for PBC.
    """
    dr = positions - point
    dr = _apply_pbc_displacement(apm, dr)
    return cast(np.ndarray, np.linalg.norm(dr, axis=1))
