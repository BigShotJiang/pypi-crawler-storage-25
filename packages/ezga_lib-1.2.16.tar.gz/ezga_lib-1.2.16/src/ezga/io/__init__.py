from __future__ import annotations
"""
composition
===========

Sub-package for generating compositions and constructing new structures with desired stoichiometries.
"""
