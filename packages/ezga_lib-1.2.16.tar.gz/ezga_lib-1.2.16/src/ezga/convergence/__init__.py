from __future__ import annotations
"""
convergenve.py
=============

Sub-package for checking convergence.
"""
