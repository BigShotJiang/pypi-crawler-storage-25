from __future__ import annotations
from typing import Any

from .metropolis import MetropolisKernel


class GCMCKernel(MetropolisKernel):
    """
    Metropolis-Hastings kernel for the Grand Canonical ensemble (GCMC).
    Handles chemical potential terms in the acceptance criteria.
    """

    def __init__(self, temperature: float, mu: dict[str, float], rng=None):
        super().__init__(sampling_temperature=temperature, rng=rng)
        self.mu = mu

    def get_delta_phi_total(self, delta_phi: float, child: Any, parent: Any, **kwargs) -> float:
        """
        Includes chemical potential in the energy delta.
        """
        delta_mu_N = 0.0
        apm_child = getattr(child, "AtomPositionManager", None)
        apm_parent = getattr(parent, "AtomPositionManager", None)

        counts_child = apm_child.atomCountDict if apm_child is not None else {}
        if not counts_child and hasattr(child, "get_chemical_symbols"):
            try:
                symbols = child.get_chemical_symbols()
                counts_child = {s: symbols.count(s) for s in set(symbols)}
            except Exception:
                pass

        counts_parent = apm_parent.atomCountDict if apm_parent is not None else {}
        if not counts_parent and hasattr(parent, "get_chemical_symbols"):
            try:
                symbols = parent.get_chemical_symbols()
                counts_parent = {s: symbols.count(s) for s in set(symbols)}
            except Exception:
                pass

        for species, mu_val in self.mu.items():
            delta_n = counts_child.get(species, 0) - counts_parent.get(species, 0)
            delta_mu_N += mu_val * delta_n

        return delta_phi - delta_mu_N
