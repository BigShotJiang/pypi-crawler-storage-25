from __future__ import annotations
import logging
from typing import Any, Callable, Dict, List, Optional, Literal

from .metropolis import MetropolisKernel
from .reduced_potential import ThermodynamicState, ReducedPotential

_logger = logging.getLogger(__name__)


class ReplicaAcceptanceKernel(MetropolisKernel):
    """
    Metropolis-Hastings kernel for Replica Exchange.
    Handles slot-fixed temperature and chemical potential ladders for individual replica acceptance.
    """

    def __init__(
        self,
        T_ladder: List[float] | None = None,
        mu_ladders: Dict[str, List[float]] | None = None,
        thermodynamic_states: List[Dict[str, Any]] | None = None,
        kB: float = 8.617333262145e-5,
        mu_species: Dict[str, Literal["adsorbate", "atom"]] | None = None,
        constraints: List[Callable] | None = None,
        rng=None,
    ):
        sampling_T = T_ladder[0] if T_ladder else 300.0
        super().__init__(
            sampling_temperature=sampling_T,
            rng=rng,
        )
        self.kB = kB
        self.reduced_potential = ReducedPotential(
            kB=kB,
            mu_species=mu_species,
            constraints=constraints,
        )

        # Build thermodynamic states per slot
        self.states: List[ThermodynamicState] = []
        if thermodynamic_states:
            for s in thermodynamic_states:
                self.states.append(ThermodynamicState(temperature=s["T"], mu=s.get("mu", {})))
        else:
            lengths = []
            if T_ladder:
                lengths.append(len(T_ladder))
            if mu_ladders:
                for k, v in mu_ladders.items():
                    if v:
                        lengths.append(len(v))
            
            if not lengths:
                self.states = [ThermodynamicState(temperature=sampling_T, mu={})]
            else:
                R = max(lengths)
                
                # Strict consistency check (no silent modulo)
                if T_ladder and len(T_ladder) not in (1, R):
                    raise ValueError(f"Inconsistent T_ladder length {len(T_ladder)} (expected 1 or {R})")
                if mu_ladders:
                    for k, v in mu_ladders.items():
                        if v and len(v) not in (1, R):
                            raise ValueError(f"Inconsistent mu_ladder length for {k}: {len(v)} (expected 1 or {R})")

                # Warn once if T is not explicitly specified — the 300 K default is
                # physically wrong for reduced-unit potentials (e.g. LJ with kB=1).
                if not T_ladder:
                    _logger.warning(
                        "[ReplicaAcceptance] T_ladder not set and no thermodynamic_states provided. "
                        f"Defaulting all replica slots to T = {sampling_T}. "
                        "This is PHYSICALLY INCORRECT for reduced-unit potentials (e.g. LJ with kB=1). "
                        "Set 'T_ladder' or 'thermodynamic_states' explicitly."
                    )

                for i in range(R):
                    T = T_ladder[i if len(T_ladder) > 1 else 0] if T_ladder else sampling_T
                    mu = {}
                    if mu_ladders:
                        for k, v in mu_ladders.items():
                            if v:
                                mu[k] = v[i if len(v) > 1 else 0]
                    self.states.append(ThermodynamicState(temperature=T, mu=mu))

    def get_temperature(self, idx: int, walker_id: int, **kwargs) -> float:
        """
        Returns temperature in energy units (kB * T) for the fixed slot index.
        """
        if not self.states:
            return self.kB * self.sampling_temperature
        state = self.states[idx % len(self.states)]
        return self.kB * state.temperature

    def get_delta_phi_total(self, delta_phi: float, child: Any, parent: Any, idx: int = 0, **kwargs) -> float:
        """
        Calculates the GCMC-corrected delta phi total using the slot-fixed thermodynamic state.
        delta_phi_total = delta_E - sum(mu_s * delta_N_s)
        """
        if not self.states:
            return delta_phi
        state = self.states[idx % len(self.states)]

        # Get components for both configurations using ReducedPotential
        comp_child = self.reduced_potential.get_components(child, state)
        comp_parent = self.reduced_potential.get_components(parent, state)

        if comp_child["mu_term"] is None or comp_parent["mu_term"] is None:
            return delta_phi

        delta_mu_N = comp_child["mu_term"] - comp_parent["mu_term"]
        return float(delta_phi - delta_mu_N)
