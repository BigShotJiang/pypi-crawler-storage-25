# SPDX-License-Identifier: MIT
"""Grand-Canonical Reduced Potential Calculator for GCMC and Replica Exchange.

This module provides classes to define a thermodynamic state and compute its
corresponding dimensionless reduced potential under the Grand-Canonical ensemble.
The calculations support multi-species chemical potentials, temperature ladders,
and custom counting modes (either raw atomic counts or molecular adsorbate counts).
"""

from __future__ import annotations
import numpy as np
from typing import Any, Callable, Dict, List, Optional, Literal

from ezga.transition_kernels.base import extract_structure_energy
from ezga.variation.mutation_adsorbates import identify_adsorbates


class ThermodynamicState:
    """Represents a fixed thermodynamic state in the Grand-Canonical ensemble.

    In statistical mechanics, a grand-canonical thermodynamic state is defined by
    its temperature (T) and the chemical potentials (mu) of the species that
    can be exchanged with the reservoir.

    Attributes:
        temperature (float): The absolute temperature of the state, in Kelvin.
        mu (Dict[str, float]): A dictionary mapping species names to their
            respective chemical potentials, typically in eV.
    """

    def __init__(self, temperature: float, mu: Dict[str, float]):
        """Initializes a new ThermodynamicState instance.

        Args:
            temperature (float): The absolute temperature, in Kelvin.
            mu (Dict[str, float]): A dictionary mapping species names to their
                respective chemical potentials.
        """
        self.temperature = temperature
        self.mu = mu


class ReducedPotential:
    r"""Dimensionless reduced potential calculator for Grand-Canonical ensembles.

    This class computes the dimensionless reduced potential $u(x)$ for a given
    atomic configuration $x$ and a thermodynamic state $k$. 
    
    Thermodynamic Justification:
    ----------------------------
    In the Grand-Canonical ensemble ($\mu, V, T$), the probability of observing 
    a configuration $x$ with potential energy $E(x)$ and particle counts 
    $\{N_s(x)\}$ for species $s$ is proportional to its Boltzmann weight:
    
        P(x) \propto \exp\left( - u(x) \right)
        
    where the dimensionless reduced potential $u(x)$ is defined as:
    
        u(x) = \beta \left( E(x) - \sum_{s} \mu_s N_s(x) \right)
        
    Here:
        - \beta = 1 / (k_B * T) is the thermodynamic reciprocal temperature.
        - E(x) is the potential energy of the system.
        - \mu_s is the chemical potential of species $s$.
        - N_s(x) is the quantity/count of species $s$ in configuration $x$.
        
    These reduced potentials are crucial in Metropolis-Hastings acceptance tests 
    for Monte Carlo particle insertions/deletions and Parallel Tempering (Replica Exchange)
    swaps to ensure thermodynamic consistency and satisfy detailed balance.

    Attributes:
        kB (float): Boltzmann constant, defaults to eV/K (8.617333262145e-5).
        mu_species (Dict[str, Literal["adsorbate", "atom"]]): A dictionary mapping
            each species to its counting mode: "adsorbate" (counts molecules via
            adsorbate identification heuristics) or "atom" (counts raw atomic elements).
        constraints (List[Callable] | None): A list of spatial constraints or filter
            predicates applied when identifying molecular adsorbates on surfaces.
    """

    def __init__(
        self,
        kB: float = 8.617333262145e-5,
        mu_species: Dict[str, Literal["adsorbate", "atom"]] | None = None,
        constraints: List[Callable] | None = None,
    ):
        """Initializes a new ReducedPotential calculator.

        Args:
            kB (float): Boltzmann constant in custom energy/temperature units.
                Defaults to 8.617333262145e-5 eV/K.
            mu_species (Dict[str, Literal["adsorbate", "atom"]] | None):
                Mapping of chemical potential species to their respective counting modes.
                If not specified, defaults to "adsorbate" for all keys.
            constraints (List[Callable] | None): List of constraint callbacks used
                for spatial filtering during molecular adsorbate identification.
        """
        self.kB = kB
        self.mu_species = mu_species or {}
        self.constraints = constraints

    def get_components(self, config: Any, thermo_state: ThermodynamicState) -> Dict[str, Any]:
        r"""Computes individual components of the reduced potential.

        This method extracts the potential energy, identifies active adsorbate
        and atomic species counts, and calculates the total chemical potential
        contributions and beta factor to evaluate the final reduced potential $u(x)$.

        Args:
            config (Any): The molecular or atomic configuration (typically an ASE Atoms object).
            thermo_state (ThermodynamicState): The fixed thermodynamic state at which
                to evaluate the reduced potential.

        Returns:
            Dict[str, Any]: A dictionary containing the computed components:
                - "E" (float | None): The potential energy of the configuration.
                - "beta" (float | None): Reciprocal temperature $1 / (k_B * T)$.
                - "T" (float): Absolute temperature in Kelvin.
                - "mu_term" (float | None): Combined chemical potential term $\sum \mu_s N_s$.
                - "u" (float | None): The dimensionless reduced potential.
                - "N_<species>" (int): The count of particles of the respective species.
                - "mu_<species>_N_<species>" (float): The potential energy offset for that species.
        """
        apm = getattr(config, "AtomPositionManager", None)
        
        # 1. Extract Potential Energy (E) defensively across EZGA/ASE formats.
        E = extract_structure_energy(config)
            
        # Return empty components if energy is invalid/infinite (prevents silent propagation)
        if E is None or not np.isfinite(E):
            return {
                "E": None,
                "beta": None,
                "T": thermo_state.temperature,
                "mu_term": None,
                "u": None,
            }
            
        # 2. Temperature & Thermodynamic Beta
        T = thermo_state.temperature
        if T <= 0 or not np.isfinite(T):
            return {
                "E": E,
                "beta": None,
                "T": T,
                "mu_term": None,
                "u": None,
            }
            
        beta = 1.0 / (self.kB * T)
        
        # 3. Adsorbates Identification & Raw Atom Counts
        mol_counts = {}
        if config is not None:
            if hasattr(config, "mock_adsorbates"):
                # Fast-path for unit testing mocks
                mol_counts = config.mock_adsorbates
            elif hasattr(config, "info") and "_mol_counts_cache" in config.info:
                # Retrieve precomputed molecular composition cache
                mol_counts = config.info["_mol_counts_cache"]
            else:
                try:
                    # Run full graph-based adsorbate identification heuristics
                    mols = identify_adsorbates(config, self.constraints)
                    for m in mols:
                        mol_counts[m.formula] = mol_counts.get(m.formula, 0) + 1
                    # Cache the result to avoid redundant expensive geometry sweeps
                    if hasattr(config, "info"):
                        config.info["_mol_counts_cache"] = mol_counts
                except Exception:
                    pass
                
        atom_counts = getattr(apm, "atomCountDict", {}) if apm is not None else {}
        if not atom_counts and hasattr(config, "get_chemical_symbols"):
            try:
                symbols = config.get_chemical_symbols()
                atom_counts = {s: symbols.count(s) for s in set(symbols)}
            except Exception:
                pass
        
        # 4. Compute chemical potential terms: sum( mu_s * N_s )
        mu_term = 0.0
        details = {}
        
        for species, mu_val in thermo_state.mu.items():
            counting_mode = self.mu_species.get(species, "adsorbate")
            
            # Select appropriate particle counting mode
            if counting_mode == "adsorbate":
                n_val = mol_counts.get(species, 0)
            else:
                n_val = atom_counts.get(species, 0)
                
            term_val = mu_val * n_val
            mu_term += term_val
            
            # Log detail trackers for debug and replica exchange diagnostics
            details[f"N_{species}"] = n_val
            details[f"mu_{species}_N_{species}"] = term_val
            
        # Evaluate GCMC reduced potential: u = beta * (E - sum(mu_s * N_s))
        u = beta * (E - mu_term)
        
        res = {
            "E": E,
            "beta": beta,
            "T": T,
            "mu_term": mu_term,
            "u": u,
        }
        res.update(details)
        return res

    def __call__(self, config: Any, thermo_state: ThermodynamicState) -> float | None:
        """Evaluates and returns the dimensionless reduced potential.

        Args:
            config (Any): The molecular or atomic configuration.
            thermo_state (ThermodynamicState): The thermodynamic state.

        Returns:
            float | None: The computed reduced potential $u(x)$, or None if the
                energy/temperature parameters are invalid or infinite.
        """
        components = self.get_components(config, thermo_state)
        u = components["u"]
        return None if u is None else float(u)
