from __future__ import annotations

import math
import logging
from pathlib import Path
import numpy as np
from typing import Any, List, Dict, Tuple, Literal, cast

from .base import TransitionKernel
from .reduced_potential import ThermodynamicState, ReducedPotential


class ReplicaExchangeKernel(TransitionKernel):
    """
    Kernel for Replica Exchange (Parallel Tempering) moves.
    Supports multi-species GCMC chemical potential and temperature ladders,
    using fixed-slot thermodynamic states and traveling configurations.

    Supported Neighbor Modes (`neighbor_mode`):
    -------------------------------------------
    - "grid":     Traditional grid neighbor logic with dimensional even-odd schedule
    - "radius":   Connect thermodynamic states within a given weighted thermodynamic distance threshold `connection_radius`
    - "knn":      Connect each thermodynamic state to its k-nearest neighbors (`k_neighbors`)
    - "explicit": User-defined arbitrary exchange graph edges specified in `exchange_edges`

    Detailed Balance & Proposal Symmetry Justification:
    ---------------------------------------------------
    Unlike local transition kernels (e.g., MetropolisKernel or GCMCKernel) which
    incorporate a 'log_q_delta' term (Q-correction) to compensate for asymmetric candidate
    proposal probabilities (such as structural insertions/deletions/mutations), the
    ReplicaExchangeKernel assumes a perfectly symmetric proposal ratio:
        q(X -> X') / q(X' -> X) = 1.0  (i.e., log_q_delta = 0.0)

    This is mathematically and thermodynamically rigorous because:
      1. Neighborhood pairs (i, j) are selected via a symmetric even-odd pairing schedule,
         making the probability of attempting a swap between slots i and j symmetric.
      2. The proposed swap operation is a deterministic permutation of the complete, unmodified
         microscopic configurations (xi, xj) -> (xj, xi). No stochastic structural mutations
         are performed during the swap itself.
      3. The Jacobian of the permutation is exactly 1.0.

    Therefore, structural proposal asymmetry is identically zero, and the swap acceptance
    is determined solely by the difference in the slot-fixed reduced potentials.
    """

    def __init__(self, cfg, logger=None, ctx: Any = None, rng: np.random.Generator | None = None):
        self.cfg = cfg
        self.logger = logger or logging.getLogger(__name__)
        self.ctx = ctx
        if rng is not None:
            self._rng = rng
        elif ctx is not None and hasattr(ctx, "np_rng") and ctx.np_rng is not None:
            self._rng = ctx.np_rng
        else:
            self._rng = np.random.default_rng()
            
        self._initialized = False
        self.states: List[ThermodynamicState] = []
        self.reduced_potential: ReducedPotential | None = None
        self.swap_attempts: np.ndarray | None = None
        self.swap_accepts: np.ndarray | None = None
        self.direction_stats: Dict[str, Dict[str, int]] = {}
        self.walker_history: Dict[int, List[int]] = {}
        self.observables_history: Dict[int, List[Dict[str, Any]]] = {}
        self._cached_edges: List[Tuple[int, int]] | None = None

    def _lazy_init(self, n_replicas: int):
        if self._initialized:
            return
            
        ens = getattr(self.cfg, "ensemble", None)
        if not ens or ens.kind != "replica_exchange":
            return
            
        replica_cfg = ens.replica_exchange
        kB = getattr(replica_cfg, "kB", 8.617333262145e-5)
        mu_species = getattr(replica_cfg, "mu_species", {"CO": "adsorbate", "H": "atom"})
        thermodynamic_states = getattr(replica_cfg, "thermodynamic_states", None)
        T_ladder = getattr(replica_cfg, "T_ladder", None)
        mu_ladders = getattr(replica_cfg, "mu_ladders", None)
        mu_ladder = getattr(replica_cfg, "mu_ladder", None)
        
        # Convert mu_ladder to mu_ladders if needed
        if mu_ladders is None and mu_ladder is not None:
            primary_species = "CO"
            if getattr(ens, "gcmc", None) and ens.gcmc.chemical_potential:
                primary_species = list(ens.gcmc.chemical_potential.keys())[0]
            mu_ladders = {primary_species: mu_ladder}
            
        # Build states
        self.states = []
        if thermodynamic_states:
            if len(thermodynamic_states) != n_replicas:
                raise ValueError(
                    f"Length of explicit thermodynamic_states ({len(thermodynamic_states)}) "
                    f"does not match population size ({n_replicas})."
                )
            for s in thermodynamic_states:
                self.states.append(ThermodynamicState(temperature=s["T"], mu=s.get("mu", {})))
        else:
            lengths = []
            if T_ladder:
                lengths.append(len(T_ladder))
            if mu_ladders:
                for k, v in mu_ladders.items():
                    if v:
                        lengths.append(len(v))
                        
            if not lengths:
                sampling_T = getattr(ens.base, "sampling_temperature", 300.0)
                self.states = [ThermodynamicState(temperature=sampling_T, mu={}) for _ in range(n_replicas)]
            else:
                R = n_replicas
                # Strict consistency check (no silent modulo)
                if T_ladder and len(T_ladder) not in (1, R):
                    raise ValueError(f"Inconsistent T_ladder length {len(T_ladder)} (expected 1 or {R})")
                if mu_ladders:
                    for k, v in mu_ladders.items():
                        if v and len(v) not in (1, R):
                            raise ValueError(f"Inconsistent mu_ladder length for {k}: {len(v)} (expected 1 or {R})")

                # Warn once if T is not explicitly specified — the 300 K default is
                # physically wrong for reduced-unit potentials (e.g. LJ with kB=1).
                if not T_ladder:
                    gcmc_T = getattr(getattr(ens, "gcmc", None), "temperature", None) \
                          or getattr(getattr(ens, "nvt",  None), "temperature", None)
                    if gcmc_T is not None:
                        self.logger.warning(
                            "[ReplicaExchange] T_ladder not set. "
                            f"Defaulting all replica slots to T = {gcmc_T} "
                            "(read from ensemble.gcmc/nvt.temperature). "
                            "Set 'T_ladder' or 'thermodynamic_states' explicitly to silence this warning."
                        )
                    else:
                        self.logger.warning(
                            "[ReplicaExchange] T_ladder not set and no ensemble temperature found. "
                            "Defaulting all replica slots to T = 300.0. "
                            "This is PHYSICALLY INCORRECT for reduced-unit potentials (e.g. LJ with kB=1). "
                            "Set 'T_ladder' or 'thermodynamic_states' explicitly."
                        )
                    gcmc_T = gcmc_T or 300.0
                else:
                    gcmc_T = None  # T_ladder is set; no warning needed

                for i in range(R):
                    if T_ladder:
                        T = T_ladder[i if len(T_ladder) > 1 else 0]
                    else:
                        T = gcmc_T
                    mu = {}
                    if mu_ladders:
                        for k, v in mu_ladders.items():
                            if v:
                                mu[k] = v[i if len(v) > 1 else 0]
                    self.states.append(ThermodynamicState(temperature=T, mu=mu))
                    
        # Instantiate the shared ReducedPotential
        constraints = []
        if hasattr(self.cfg, "population") and getattr(self.cfg.population, "constraints", None):
            constraints = [c for c in self.cfg.population.constraints if callable(c)]
            
        self.reduced_potential = ReducedPotential(
            kB=kB,
            mu_species=mu_species,
            constraints=constraints,
        )
        
        # Initialize diagnostics/statistics matrices
        self.swap_attempts = np.zeros((n_replicas, n_replicas), dtype=int)
        self.swap_accepts = np.zeros((n_replicas, n_replicas), dtype=int)
        self.direction_stats = {}
        self.walker_history = {}
        self.observables_history = {i: [] for i in range(n_replicas)}
        
        self._initialized = True
        
        # Precompute and cache exchange graph edges
        self._get_exchange_edges()

    def _find_neighbors(self, dimension: str) -> List[Tuple[int, int]]:
        """
        Finds adjacent neighbor pairs in the grid along a given dimension.
        """
        pairs = []
        n = len(self.states)
        for a in range(n):
            for b in range(a + 1, n):
                s_a = self.states[a]
                s_b = self.states[b]
                
                # Check compatibility of all other dimensions
                compatible = True
                
                if dimension == "T":
                    all_species = set(s_a.mu.keys()) | set(s_b.mu.keys())
                    for sp in all_species:
                        if abs(s_a.mu.get(sp, 0.0) - s_b.mu.get(sp, 0.0)) > 1e-9:
                            compatible = False
                            break
                    if not compatible:
                        continue
                    val_a = s_a.temperature
                    val_b = s_b.temperature
                else:
                    if abs(s_a.temperature - s_b.temperature) > 1e-9:
                        continue
                    all_species = set(s_a.mu.keys()) | set(s_b.mu.keys())
                    for sp in all_species:
                        if sp != dimension:
                            if abs(s_a.mu.get(sp, 0.0) - s_b.mu.get(sp, 0.0)) > 1e-9:
                                compatible = False
                                break
                    if not compatible:
                        continue
                    val_a = s_a.mu.get(dimension, 0.0)
                    val_b = s_b.mu.get(dimension, 0.0)
                    
                if abs(val_a - val_b) < 1e-9:
                    if b != a + 1:
                        continue
                    
                min_val = min(val_a, val_b)
                max_val = max(val_a, val_b)
                
                # Check if there is any state c strictly between them in the given dimension
                is_adjacent = True
                for c in range(n):
                    if c == a or c == b:
                        continue
                    s_c = self.states[c]
                    
                    if dimension == "T":
                        c_compatible = True
                        for sp in all_species:
                            if abs(s_c.mu.get(sp, 0.0) - s_a.mu.get(sp, 0.0)) > 1e-9:
                                c_compatible = False
                                break
                        if not c_compatible:
                            continue
                        val_c = s_c.temperature
                    else:
                        if abs(s_c.temperature - s_a.temperature) > 1e-9:
                            continue
                        c_compatible = True
                        for sp in all_species:
                            if sp != dimension:
                                if abs(s_c.mu.get(sp, 0.0) - s_a.mu.get(sp, 0.0)) > 1e-9:
                                    c_compatible = False
                                    break
                        if not c_compatible:
                            continue
                        val_c = s_c.mu.get(dimension, 0.0)
                        
                    if min_val < val_c < max_val:
                        is_adjacent = False
                        break
                        
                if is_adjacent:
                    pairs.append((a, b))
        return pairs

    def _thermo_coordinates(self, state: ThermodynamicState) -> np.ndarray:
        """
        Computes general reduced thermodynamic coordinates for a state:
        [beta, beta * mu_1, beta * mu_2, ...]
        where beta = 1 / (kB * T)
        """
        reduced_potential = self.reduced_potential
        if reduced_potential is None:
            raise RuntimeError("ReplicaExchangeKernel must be initialized before computing thermodynamic coordinates.")
        beta = 1.0 / (reduced_potential.kB * state.temperature)
        coords: list[float] = [beta]
        # Dynamically determine the union of all species across all defined states
        all_species = sorted(list({sp for s in self.states for sp in s.mu.keys()}))
        for sp in all_species:
            coords.append(beta * state.mu.get(sp, 0.0))
        return np.array(coords, dtype=float)

    def _thermo_distance(self, i: int, j: int, weights: Dict[str, float] | None = None) -> float:
        """
        Calculates physical weighted Euclidean distance between thermodynamic states i and j
        using reduced coordinates: [beta, beta * mu_1, beta * mu_2, ...]
        """
        weights = weights or {}
        c_i = self._thermo_coordinates(self.states[i])
        c_j = self._thermo_coordinates(self.states[j])
        
        # Match weight elements with coordinate elements
        all_species = sorted(list({sp for s in self.states for sp in s.mu.keys()}))
        w_vec: list[float] = [weights.get("T", 1.0)]
        for sp in all_species:
            w_vec.append(weights.get(sp, 1.0))
        w_arr = np.array(w_vec, dtype=float)
        
        diff = c_i - c_j
        d2 = np.sum(w_arr * (diff ** 2))
        return math.sqrt(d2)

    def reset_exchange_graph(self):
        """
        Resets the cached exchange graph edges, allowing the graph to be recomputed
        on the next call if thermodynamic states or neighborhood parameters are dynamically modified.
        """
        self._cached_edges = None

    def _get_exchange_edges(self) -> List[Tuple[int, int]]:
        if self._cached_edges is not None:
            return self._cached_edges

        ens = getattr(self.cfg, "ensemble", None)
        if not ens or ens.kind != "replica_exchange":
            self._cached_edges = []
            return self._cached_edges

        replica_cfg = ens.replica_exchange
        mode = getattr(replica_cfg, "neighbor_mode", "grid")

        if mode == "explicit":
            explicit_edges: set[tuple[int, int]] = set()
            if getattr(replica_cfg, "exchange_edges", None) is not None:
                for edge in replica_cfg.exchange_edges:
                    if len(edge) != 2:
                        raise ValueError(f"Explicit exchange edge {edge} must contain exactly 2 slot indices.")
                    i, j = int(edge[0]), int(edge[1])
                    if i == j:
                        raise ValueError(f"Self-edge ({i}, {j}) is not allowed in exchange_edges.")
                    n_states = len(self.states)
                    if i < 0 or i >= n_states or j < 0 or j >= n_states:
                        raise ValueError(
                            f"Explicit exchange edge ({i}, {j}) is out of bounds for the "
                            f"{n_states} defined thermodynamic states."
                        )
                    explicit_edges.add((min(i, j), max(i, j)))
            self._cached_edges = sorted(list(explicit_edges))
            return self._cached_edges

        if mode == "radius":
            radius = getattr(replica_cfg, "connection_radius", 0.25)
            weights = getattr(replica_cfg, "distance_weights", {}) or {}
            radius_edges: list[tuple[int, int]] = []

            n = len(self.states)
            for i in range(n):
                for j in range(i + 1, n):
                    d = self._thermo_distance(i, j, weights)
                    if d <= radius:
                        radius_edges.append((i, j))

            self._cached_edges = radius_edges
            return self._cached_edges

        if mode == "knn":
            k = getattr(replica_cfg, "k_neighbors", 2)
            weights = getattr(replica_cfg, "distance_weights", {}) or {}
            knn_edges: set[tuple[int, int]] = set()

            n = len(self.states)
            for i in range(n):
                distances = []
                for j in range(n):
                    if i == j:
                        continue
                    distances.append((self._thermo_distance(i, j, weights), j))

                distances.sort()
                for _, j in distances[:k]:
                    knn_edges.add((min(i, j), max(i, j)))

            self._cached_edges = sorted(list(knn_edges))
            return self._cached_edges

        # fallback: old grid behavior
        grid_edges: list[tuple[int, int]] = []
        active_dimensions: list[str] = []
        T_vals = [s.temperature for s in self.states]
        if len(set(T_vals)) > 1:
            active_dimensions.append("T")
            
        all_species: set[str] = set()
        for s in self.states:
            all_species.update(s.mu.keys())
            
        for species in sorted(all_species):
            mu_vals = [s.mu.get(species, 0.0) for s in self.states]
            if len(set(mu_vals)) > 1:
                active_dimensions.append(species)

        for dim in active_dimensions:
            grid_edges.extend(self._find_neighbors(dim))
        
        self._cached_edges = sorted(set(grid_edges))
        return self._cached_edges

    def _make_matching(self, edges: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
        """
        Creates a randomized maximum matching (independent edge subset) using the kernel's own RNG.
        Ensures no slot participates in multiple concurrent swaps, satisfying detailed balance.
        """
        edges_list = list(edges)
        if hasattr(self._rng, "shuffle"):
            self._rng.shuffle(edges_list)
        else:
            import random
            random.shuffle(edges_list)

        used: set[int] = set()
        matching: list[tuple[int, int]] = []

        for i, j in edges_list:
            if i in used or j in used:
                continue
            matching.append((i, j))
            used.add(i)
            used.add(j)

        return matching

    def _attempt_swap(self, candidates_list: List[Any], i: int, j: int) -> Literal["accepted", "rejected", "skipped"]:
        xi = candidates_list[i]
        xj = candidates_list[j]

        # Compute reduced potentials
        reduced_potential = self.reduced_potential
        swap_attempts = self.swap_attempts
        swap_accepts = self.swap_accepts
        if reduced_potential is None or swap_attempts is None or swap_accepts is None:
            raise RuntimeError("ReplicaExchangeKernel must be initialized before attempting swaps.")
        u_i_xi = reduced_potential(xi, self.states[i])
        u_j_xj = reduced_potential(xj, self.states[j])
        u_i_xj = reduced_potential(xj, self.states[i])
        u_j_xi = reduced_potential(xi, self.states[j])

        # Check for missing/infinite energy. Skip if present (do not accept).
        if any(u is None or not np.isfinite(u) for u in [u_i_xi, u_j_xj, u_i_xj, u_j_xi]):
            self.logger.warning(
                f"[Exchange] Skipping swap between slot {i} and slot {j} "
                f"due to missing/infinite energy/potentials."
            )
            return "skipped"

        swap_attempts[i, j] += 1
        swap_attempts[j, i] += 1

        logA = cast(float, u_i_xi) + cast(float, u_j_xj) - cast(float, u_i_xj) - cast(float, u_j_xi)

        # Numerically safe Metropolis test
        if logA >= 0.0:
            accept = True
        else:
            r = max(float(self._rng.random()), 1e-300)
            accept = math.log(r) < logA

        if accept:
            # Swapping structures in lists
            candidates_list[i], candidates_list[j] = xj, xi

            # Update slot tracking safely using standardized method
            self._set_structure_metadata(xj, thermo_slot_id=i)
            self._set_structure_metadata(xi, thermo_slot_id=j)

            swap_accepts[i, j] += 1
            swap_accepts[j, i] += 1
            return "accepted"

        return "rejected"

    def step(self, parents: Any, candidates: list[Any], **kwargs) -> list[Any]:
        """
        Executes replica exchange swaps.
        """
        ens = getattr(self.cfg, "ensemble", None)
        if not ens or ens.kind != "replica_exchange":
            return candidates

        replica_cfg = ens.replica_exchange
        generation = self.ctx.generation if self.ctx else 0

        # Ensure candidates list is valid and walker_ids are active
        candidates_list = list(candidates) if not isinstance(candidates, list) else candidates
        self._ensure_walker_id(candidates_list)
        n_replicas = len(candidates_list)

        self._lazy_init(n_replicas)

        # Initialize/sync slot tracking info on configurations
        for idx, config in enumerate(candidates_list):
            wid = self._get_walker_id(config, default=idx)
            self._set_structure_metadata(config, walker_id=wid, thermo_slot_id=idx, generation=generation)

        # Skip swaps if not on the swap interval
        if generation % replica_cfg.exchange_every != 0:
            # Still record walker history and observables per generation!
            self._record_diagnostics(candidates_list, generation)
            self._save_statistics()
            return candidates_list

        mode = getattr(replica_cfg, "neighbor_mode", "grid")
        total_swaps = 0

        if mode == "grid":
            # Traditional grid neighbor logic with dimensional even/odd schedule
            active_dimensions: list[str] = []
            T_vals = [s.temperature for s in self.states]
            if len(set(T_vals)) > 1:
                active_dimensions.append("T")
                
            all_species: set[str] = set()
            for s in self.states:
                all_species.update(s.mu.keys())
                
            for species in sorted(all_species):
                mu_vals = [s.mu.get(species, 0.0) for s in self.states]
                if len(set(mu_vals)) > 1:
                    active_dimensions.append(species)

            for dim in active_dimensions:
                if dim not in self.direction_stats:
                    self.direction_stats[dim] = {"attempts": 0, "accepts": 0}
                dim_stats = self.direction_stats[dim]

                pairs = self._find_neighbors(dim)
                if not pairs:
                    continue

                if dim == "T":
                    unique_vals = sorted(list(set(s.temperature for s in self.states)))
                else:
                    unique_vals = sorted(list(set(s.mu.get(dim, 0.0) for s in self.states)))
                    
                val_to_idx = {v: i for i, v in enumerate(unique_vals)}
                even_pairs = []
                odd_pairs = []
                
                for a, b in pairs:
                    val_a = self.states[a].temperature if dim == "T" else self.states[a].mu.get(dim, 0.0)
                    val_b = self.states[b].temperature if dim == "T" else self.states[b].mu.get(dim, 0.0)
                    
                    idx_a = val_to_idx[val_a]
                    idx_b = val_to_idx[val_b]
                    
                    min_idx = min(idx_a, idx_b)
                    if min_idx % 2 == 0:
                        even_pairs.append((a, b))
                    else:
                        odd_pairs.append((a, b))

                offset = (generation // replica_cfg.exchange_every) % 2
                pairs_to_attempt = even_pairs if offset == 0 else odd_pairs

                for i, j in pairs_to_attempt:
                    res = self._attempt_swap(candidates_list, i, j)
                    if res != "skipped":
                        dim_stats["attempts"] += 1
                        if res == "accepted":
                            dim_stats["accepts"] += 1
                            total_swaps += 1
        else:
            # New arbitrary exchange graph mode
            if "graph" not in self.direction_stats:
                self.direction_stats["graph"] = {"attempts": 0, "accepts": 0}
            graph_stats = self.direction_stats["graph"]

            edges = self._get_exchange_edges()
            pairs_to_attempt = self._make_matching(edges)

            for i, j in pairs_to_attempt:
                res = self._attempt_swap(candidates_list, i, j)
                if res != "skipped":
                    graph_stats["attempts"] += 1
                    if res == "accepted":
                        graph_stats["accepts"] += 1
                        total_swaps += 1

        # Log swap summary generically across all active dimensions / graph keys
        total_attempts = 0
        total_accepts = 0
        for stats in self.direction_stats.values():
            total_attempts += stats.get("attempts", 0)
            total_accepts += stats.get("accepts", 0)

        exchange_rate = (total_accepts / total_attempts * 100) if total_attempts > 0 else 0.0

        self.logger.info(
            f"[Exchange Graph] Gen {generation} Swap Summary: "
            f"Accepted {total_accepts}/{total_attempts} swaps ({exchange_rate:.1f}%)"
        )

        # 4. Record walker history and slot observables
        self._record_diagnostics(candidates_list, generation)
        
        # 5. Serialize stats to file
        self._save_statistics()

        return candidates_list

    def _record_diagnostics(self, candidates_list: List[Any], generation: int):
        max_history_len = 10000
        if self.cfg and hasattr(self.cfg, "ensemble") and hasattr(self.cfg.ensemble, "replica_exchange"):
            max_history_len = getattr(self.cfg.ensemble.replica_exchange, "max_history_len", 10000)

        for idx, config in enumerate(candidates_list):
            wid = self._get_walker_id(config, default=idx)
            if wid not in self.walker_history:
                self.walker_history[wid] = []
            self.walker_history[wid].append(idx)
            if len(self.walker_history[wid]) > max_history_len:
                self.walker_history[wid].pop(0)

            state = self.states[idx]
            reduced_potential = self.reduced_potential
            if reduced_potential is None:
                raise RuntimeError("ReplicaExchangeKernel must be initialized before recording diagnostics.")
            components = reduced_potential.get_components(config, state)

            slot_obs = {
                "generation": generation,
                "walker_id": wid,
                "components": components,
            }
            self.observables_history[idx].append(slot_obs)
            if len(self.observables_history[idx]) > max_history_len:
                self.observables_history[idx].pop(0)

    def _save_statistics(self):
        output_dir = "logger"
        if self.cfg and getattr(self.cfg, "output_path", None):
            output_dir = Path(self.cfg.output_path) / "logger"
        elif self.cfg and hasattr(self.cfg, "base") and getattr(self.cfg.base, "output_path", None):
            output_dir = Path(self.cfg.base.output_path) / "logger"
        else:
            output_dir = Path("logger")
            
        output_dir.mkdir(parents=True, exist_ok=True)
        stats_file = output_dir / "replica_stats.json"
        
        n = len(self.states)
        acceptance_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                attempts = self.swap_attempts[i, j]
                if attempts > 0:
                    acceptance_matrix[i, j] = self.swap_accepts[i, j] / attempts
                    
        data = {
            "states": [
                {"T": s.temperature, "mu": s.mu} for s in self.states
            ],
            "swap_attempts": self.swap_attempts.tolist(),
            "swap_accepts": self.swap_accepts.tolist(),
            "swap_acceptance": acceptance_matrix.tolist(),
            "direction_stats": self.direction_stats,
            "walker_history": self.walker_history,
            "observables_history": self.observables_history,
        }
        
        from ezga.io.snapshot_recorder import _NpEncoder
        import json
        with stats_file.open("w", encoding="utf-8") as f:
            json.dump(data, f, cls=_NpEncoder, indent=2, sort_keys=True)

    def allows_agent_sync(self) -> bool:
        return True
