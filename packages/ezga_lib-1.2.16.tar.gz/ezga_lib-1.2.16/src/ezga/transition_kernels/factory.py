from __future__ import annotations

from typing import Any

from .composite import CompositeKernel
from .gcmc import GCMCKernel
from .gibbs_transfer import GibbsTransferKernel
from .hard_constraint import HardConstraintKernel
from .identity import IdentityKernel
from .metropolis import MetropolisKernel
from .nested_sampling import NestedSamplingKernel
from .nvt import NVTKernel
from .replica_acceptance import ReplicaAcceptanceKernel
from .replica_exchange import ReplicaExchangeKernel


def make_transition_kernel(cfg: Any, selector: Any, logger: Any, evaluator: Any = None, ctx: Any = None) -> Any:
    """
    Factory function to instantiate and compose transition kernels based on ensemble configuration.

    This function implements the selection logic for acceptance criteria and specialized 
    moves. It handles the mapping between high-level configuration (e.g., NVT, GCMC, 
    Replica Exchange) and the corresponding low-level kernel implementations.

    The factory follows a multi-stage construction process:
    1.  **Base Acceptance**: Determines the primary acceptance rule (Identity, NVT, GCMC, etc.).
    2.  **Ensemble Specialization**: Adds secondary kernels for complex ensembles (e.g., 
        Replica Swap or Gibbs Transfer moves).
    3.  **Composition**: Wraps multiple kernels into a `CompositeKernel` if necessary, 
        ensuring the engine receives a single unified interface.

    Args:
        cfg (Any): Global configuration object containing 'ensemble' specifications.
        selector (Any): The instantiated selector, providing 'sampling_temperature', 
            'selection_method', and the random number generator (RNG).
        logger (Any): Logger instance for reporting acceptance metrics and errors.
        evaluator (Any, optional): The objective evaluator, required for kernels that 
            perform energy-dependent moves (e.g., Gibbs). Defaults to None.
        ctx (Any, optional): Execution context for sharing state variables (e.g., 
            Nested Sampling's energy threshold). Defaults to None.

    Returns:
        ITransitionKernel: A single kernel or a `CompositeKernel` ready for use by 
        the Genetic Algorithm engine.
    """
    ens = getattr(cfg, "ensemble", None)
    kind = getattr(ens, "kind", "none")

    sel_method = getattr(selector, "selection_method", "trajectory")
    sampling_T = getattr(selector, "sampling_temperature", 1.0)
    rng = getattr(selector, "_rng", None)

    # 1. Base Acceptance Kernel
    kernels: list[Any] = []
    if kind == "identity" or (kind == "none" and sel_method != "trajectory"):
        kernels = [IdentityKernel()]
    elif kind == "nvt":
        T = getattr(getattr(ens, "nvt", None), "temperature", sampling_T)
        kernels = [NVTKernel(temperature=T, rng=rng)]
    elif kind == "gcmc":
        T = getattr(getattr(ens, "gcmc", None), "temperature", sampling_T)
        mu = getattr(getattr(ens, "gcmc", None), "chemical_potential", {})
        kernels = [GCMCKernel(temperature=T, mu=mu, rng=rng)]
    elif kind == "replica_exchange":
        replica_cfg = getattr(ens, "replica_exchange", None)
        T_ladder = getattr(replica_cfg, "T_ladder", [sampling_T])
        mu_ladders = getattr(replica_cfg, "mu_ladders", None)
        mu_ladder = getattr(replica_cfg, "mu_ladder", None)
        thermodynamic_states = getattr(replica_cfg, "thermodynamic_states", None)
        kB = getattr(replica_cfg, "kB", 8.617333262145e-5)
        mu_species = getattr(replica_cfg, "mu_species", None)
        
        constraints = []
        if hasattr(cfg, "population") and getattr(cfg.population, "constraints", None):
            constraints = [c for c in cfg.population.constraints if callable(c)]
            
        if mu_ladders is None and mu_ladder is not None:
            primary_species = "species"
            gcmc_cfg = getattr(ens, "gcmc", None)
            chemical_potential = getattr(gcmc_cfg, "chemical_potential", None)
            if gcmc_cfg is not None and chemical_potential:
                primary_species = list(chemical_potential.keys())[0]
            mu_ladders = {primary_species: mu_ladder}
            
        kernels = [ReplicaAcceptanceKernel(
            T_ladder=T_ladder,
            mu_ladders=mu_ladders,
            thermodynamic_states=thermodynamic_states,
            kB=kB,
            mu_species=mu_species,
            constraints=constraints,
            rng=rng,
        )]
    elif kind == "nested_sampling":
        ns_kernel = NestedSamplingKernel(cfg=cfg, logger=logger, ctx=ctx)

        # NS implicitly requires candidates to be bounded by E_worst (ns_phi_star)
        def ns_constraint(state, shared):
            val = float("inf")
            apm = getattr(state, "AtomPositionManager", None)
            if apm is not None and getattr(apm, "E", None) is not None:
                val = apm.E
            elif hasattr(state, "info") and "energy" in state.info:
                val = state.info["energy"]

            return val < shared.get("ns_phi_star", float("inf"))

        hc_kernel = HardConstraintKernel(constraint_func=ns_constraint, cfg=cfg, logger=logger, ctx=ctx, rng=rng)
        kernels = [ns_kernel, hc_kernel]
    elif kind == "hard_constraint":
        kernels = [HardConstraintKernel(cfg=cfg, logger=logger, ctx=ctx, rng=rng)]
    else:
        # Default Metropolis Acceptance (must be trajectory mode here)
        kernels = [MetropolisKernel(sampling_temperature=sampling_T, rng=rng)]

    # 2. Add ensemble moves if configured
    if ens and kind not in ("none", "identity", "nvt", "gcmc"):
        if kind == "replica_exchange":
            kernels.append(ReplicaExchangeKernel(cfg=cfg, logger=logger, ctx=ctx, rng=rng))
        elif kind == "gibbs":
            kernels.append(GibbsTransferKernel(cfg=cfg, logger=logger, evaluator=evaluator, ctx=ctx, rng=rng))

    # 3. If multiple kernels, wrap in Composite
    if len(kernels) > 1:
        return CompositeKernel(kernels=kernels)

    return kernels[0]
