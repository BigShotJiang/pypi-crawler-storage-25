from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, overload


def _as_float_or_none(value: Any) -> float | None:
    """Return a scalar energy-like value as float, or None if it is not usable."""
    if value is None:
        return None
    if isinstance(value, (str, bytes)):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        pass
    try:
        # Some EZGA paths store a single objective/free energy as a one-element
        # list/array. Multi-objective vectors are not a unique physical energy.
        if hasattr(value, "__len__"):
            if len(value) == 0:
                return None
            if len(value) > 1:
                return None
            value = value[0]
        return float(value)
    except (TypeError, ValueError, IndexError):
        return None


def extract_structure_energy(struct: Any, *, allow_calculator: bool = True) -> float | None:
    """
    Extract the best available scalar potential/free energy from an EZGA/ASE structure.

    EZGA structures may carry energy in several places depending on whether they
    have just been evaluated, serialized through ASE, or decorated with
    corrections. The order favors explicit APM energy, then metadata, then ASE
    info, and finally an attached ASE calculator.
    """
    apm = getattr(struct, "AtomPositionManager", None)

    for obj, keys in (
        (apm, ("E", "energy_pot", "E_pot", "energy", "F")),
        (struct, ("E", "energy_pot", "E_pot", "energy", "F")),
    ):
        if obj is None:
            continue
        for key in keys:
            val = _as_float_or_none(getattr(obj, key, None))
            if val is not None:
                return val

    for meta in (
        getattr(apm, "metadata", None),
        getattr(struct, "metadata", None),
        getattr(struct, "info", None),
    ):
        if not isinstance(meta, dict):
            continue
        for key in ("energy_pot", "E_pot", "energy", "E", "F"):
            if key in meta:
                val = _as_float_or_none(meta[key])
                if val is not None:
                    return val

    if allow_calculator and hasattr(struct, "get_potential_energy"):
        try:
            return _as_float_or_none(struct.get_potential_energy())
        except Exception:
            return None

    return None


class TransitionKernel(ABC):
    """
    Interface for transition kernels in the GA engine.
    A kernel defines how to move from a current state to a next state.
    """

    @abstractmethod
    def step(self, parents: Any, candidates: list[Any], **kwargs) -> list[Any]:
        """
        Applies the transition logic.
        """
        raise NotImplementedError


    @overload
    def _get_walker_id(self, s: Any, default: int) -> int: ...

    @overload
    def _get_walker_id(self, s: Any, default: None = None) -> int | None: ...

    def _get_walker_id(self, s: Any, default: int | None = None) -> int | None:
        """
        Retrieves the persistent walker_id from a structure, favoring apm.metadata.
        """
        apm = getattr(s, "AtomPositionManager", None)
        if apm is not None:
            if getattr(apm, "metadata", None) is None:
                apm.metadata = {}

            # Check apm.metadata first
            wid = apm.metadata.get("walker_id")
            if wid is not None:
                return int(wid)

            # Fallback to info but migrate to apm if found
            if hasattr(s, "info") and isinstance(s.info, dict):
                wid = s.info.get("walker_id")
                if wid is not None:
                    apm.metadata["walker_id"] = wid
                    return int(wid)

        # Structure-level info fallback
        if hasattr(s, "info") and isinstance(s.info, dict):
            wid = s.info.get("walker_id")
            if wid is not None:
                return int(wid)

        return default

    @overload
    def _get_thermo_slot_id(self, s: Any, default: int) -> int: ...

    @overload
    def _get_thermo_slot_id(self, s: Any, default: None = None) -> int | None: ...

    def _get_thermo_slot_id(self, s: Any, default: int | None = None) -> int | None:
        """
        Retrieves the thermodynamic slot ID from a structure, favoring apm.metadata.
        """
        apm = getattr(s, "AtomPositionManager", None)
        if apm is not None:
            if getattr(apm, "metadata", None) is None:
                apm.metadata = {}
            
            slot = apm.metadata.get("thermo_slot_id")
            if slot is not None:
                return int(slot)
                
            if hasattr(s, "info") and isinstance(s.info, dict):
                slot = s.info.get("thermo_slot_id")
                if slot is not None:
                    apm.metadata["thermo_slot_id"] = slot
                    return int(slot)

        if hasattr(s, "info") and isinstance(s.info, dict):
            slot = s.info.get("thermo_slot_id")
            if slot is not None:
                return int(slot)

        return default

    def _set_structure_metadata(
        self,
        struct: Any,
        walker_id: int | None = None,
        thermo_slot_id: int | None = None,
        generation: int | None = None,
    ):
        """
        Standardizes the application of tracking metadata to a structure.
        Ensures metadata is stored consistently in both:
          1. struct.info (dict) - crucial for ASE/XYZ file persistence.
          2. struct.AtomPositionManager.metadata - crucial for SAGE internal pipeline tracking.
        """
        if struct is None:
            return

        # 1. Handle struct.info dict persistence
        try:
            if not hasattr(struct, "info") or struct.info is None:
                struct.info = {}
            if isinstance(struct.info, dict):
                if walker_id is not None:
                    struct.info["walker_id"] = int(walker_id)
                if thermo_slot_id is not None:
                    struct.info["thermo_slot_id"] = int(thermo_slot_id)
                if generation is not None:
                    struct.info["generation"] = int(generation)
        except AttributeError:
            pass

        # 2. Handle AtomPositionManager metadata persistence
        apm = getattr(struct, "AtomPositionManager", None)
        if apm is not None:
            if getattr(apm, "metadata", None) is None:
                apm.metadata = {}
            if isinstance(apm.metadata, dict):
                if walker_id is not None:
                    apm.metadata["walker_id"] = int(walker_id)
                if thermo_slot_id is not None:
                    apm.metadata["thermo_slot_id"] = int(thermo_slot_id)
                if generation is not None:
                    apm.metadata["generation"] = int(generation)

    def _ensure_walker_id(self, structures: list[Any]):
        """
        Assigns a persistent walker_id and a default thermo_slot_id to structures if missing.
        """
        for idx, s in enumerate(structures):
            apm = getattr(s, "AtomPositionManager", None)
            wid = None
            
            if apm is not None:
                if getattr(apm, "metadata", None) is None:
                    apm.metadata = {}

                if "walker_id" not in apm.metadata:
                    info_wid = None
                    try:
                        if hasattr(s, "info") and isinstance(s.info, dict):
                            info_wid = s.info.get("walker_id")
                    except AttributeError:
                        pass
                    wid = info_wid if info_wid is not None else idx
                    apm.metadata["walker_id"] = wid
                else:
                    wid = apm.metadata["walker_id"]
                    
                if "thermo_slot_id" not in apm.metadata:
                    apm.metadata["thermo_slot_id"] = wid
            else:
                try:
                    if hasattr(s, "info") and isinstance(s.info, dict):
                        if "walker_id" not in s.info:
                            s.info["walker_id"] = idx
                        wid = s.info["walker_id"]
                        if "thermo_slot_id" not in s.info:
                            s.info["thermo_slot_id"] = wid
                except AttributeError:
                    pass

    def _get_phi(self, struct: Any) -> float:
        """
        Extracts the energy/objective value from a structure, favoring apm.metadata.
        """
        val = extract_structure_energy(struct)
        return float(val) if val is not None else float("inf")

    def _match_parents_and_children(self, parents: list[Any], candidates: list[Any]) -> dict:
        """
        Matches candidates to parents using walker_id, falling back to index.
        """
        children_by_walker = {}
        for idx, child in enumerate(candidates):
            wid = self._get_walker_id(child)
            # Fallback to index if no walker_id yet (first pass)
            if wid is None:
                wid = idx
            children_by_walker[wid] = child
        return children_by_walker

    def allows_agent_sync(self) -> bool:
        """
        Whether this kernel allows population-wide synchronization (agent_sync).
        Default is True. Use False for kernels that require strict Markov Chain integrity (e.g. Gibbs).
        """
        return True
