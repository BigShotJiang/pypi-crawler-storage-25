# ezga/hise/manager.py
# SPDX-License-Identifier: MIT
"""
HiSE (Hierarchical Supercell Escalation) manager.

Lift methods (hise.lift_method):
  - "tile":            Use Partition + AtomPositionManager.generate_supercell(repeat=...).
  - "best_compatible": Pick the largest previous supercell (by volume) that divides the
                       target coord-wise, then lift via Partition as above.
  - "ase":             Fallback method using ASE Atoms.repeat (no Partition required).

Both "tile" and "best_compatible" REQUIRE `sage_lib.partition.Partition`.
"""

from __future__ import annotations

import logging
import os
import sys

# Optional: Disable HDF5 file locking on macOS to prevent stale locks
if sys.platform == "darwin":
    os.environ.setdefault("HDF5_USE_FILE_LOCKING", "FALSE")

import re
from pathlib import Path
from typing import Any

import numpy as np
from sage_lib.IO.storage.hybrid import HybridStorage  # <-- REQUIRED

from ezga.core.config import GAConfig, HiSEParams
from ezga.factory import build_default_engine
from ezga.io.config_loader import _materialize_factories

from .metadata import _StageMetadata
from .motifs import MotifHarvester, MotifLibrary

logger = logging.getLogger(__name__)


def _materialize_stage_constraints_if_any(stage_cfg: GAConfig) -> None:
    """Normalize and materialize ``population.constraints`` into callables.

    This helper fixes two common situations that arise when constraints are
    provided via YAML overrides on a per-stage basis:

    1) **Single dict instead of list**
       Some YAMLs assign one factory-spec (a dict) to ``population.constraints``
       for a given stage (e.g., via an overrides array). The population expects a
       *list* of callables, so we wrap a single dict into a list.

    2) **Unmaterialized factory-specs**
       Constraints may appear as factory-specs (e.g.,
       ``{"factory": "pkg.mod:make_constraint", "args": [...], ...}``) or dotted
       references. We convert them into *live Python callables* using the same
       materializer employed by the config loader.

    If a mapping ``population.constraint_name_map`` is present (e.g., ``{"C": 0,
    "H": 1}``), we register it with ``ConstraintGenerator.set_name_mapping`` so
    any constraint that accepts *string* feature keys (like ``"C"``/``"H"``) can
    resolve them to integer indices at runtime.

    The function mutates ``stage_cfg`` in place and is safe to call multiple times.

    Args:
      stage_cfg: Stage-local :class:`GAConfig` that will be mutated in place.

    Returns:
      None

    Notes:
      - Input shapes accepted:
        * ``None`` → no-op
        * a single dict factory-spec → wrapped as a list, then materialized
        * a list/tuple of factory-specs or callables → materialized element-wise
        * already-live callables → left as-is
      - This uses ``_materialize_factories`` from the loader to keep behavior
        consistent with top-level YAML parsing.
    """
    pop = getattr(stage_cfg, "population", None)
    if pop is None:
        return

    cons = getattr(pop, "constraints", None)
    if cons is None:
        return

    # 1) Tolerate a single dict by wrapping it as a list.
    if isinstance(cons, dict):
        cons = [cons]
    elif isinstance(cons, tuple):
        cons = list(cons)

    # 2) Materialize a list of factory-specs/dotted refs into live callables.
    if isinstance(cons, list):
        try:
            pop.constraints = _materialize_factories(cons)
        except Exception as e:
            logger.warning("[HiSE] Failed to materialize population.constraints: %s", e)
            # Keep the original value so downstream code can decide how to react.
            pop.constraints = cons

    # Optional: register a name→index mapping for string feature keys ("C", "H", ...).
    cmap = getattr(pop, "constraint_name_map", None)
    if cmap:
        try:
            # Local import to avoid import-time cycles and heavy modules at import.
            from ezga.DoE.DoE import ConstraintGenerator

            ConstraintGenerator.set_name_mapping(dict(cmap))
        except Exception as e:
            logger.warning("[HiSE] Could not register constraint_name_map on ConstraintGenerator: %s", e)


def _lift_inputs(
    method: str,
    src_path: Path,
    dst_path: Path,
    ratio: tuple[int, int, int] | None,
    reseed_fraction: float,
    rng: np.random.Generator,
    cfg: GAConfig,
) -> Path | None:
    r"""
    Generate a supercell-expanded database from an existing HybridStorage directory.

    This function implements the hierarchical "lift" operation, which transitions 
    the search from a smaller unit cell to a larger supercell while preserving 
    and scaling relevant cached properties.

    Parameters
    ----------
    method : str
        The escalation method. Currently supports "tile" (standard lattice replication).
    src_path : Path
        Path to the source stage HybridStorage directory (lower-resolution).
    dst_path : Path
        Path to the destination stage HybridStorage directory (higher-resolution).
    ratio : tuple of int (nx, ny, nz), optional
        Replication factors for each lattice vector. If None, the lift is aborted.
    reseed_fraction : float
        Fraction of structures to retain. Currently used as a placeholder for 
        stochastic re-seeding strategies.
    rng : np.random.Generator
        Random state for stochastic operations during the lift.
    cfg : GAConfig
        The validated configuration object for the target stage. Essential for 
        extracting metadata scaling policies from feature and objective functions.

    Returns
    -------
    Path or None
        The absolute path to the generated database if successful; None otherwise.

    Notes
    -----
    **Intelligent Metadata Scaling**:
    To avoid redundant O(N) re-computations of structural descriptors, this function 
    inspects the `scaling_logic` attribute of registered feature/objective functions. 
    Values are transformed based on the volumetric ratio :math:`V_{ratio} = n_x \cdot n_y \cdot n_z`:
    
    *   **Linear**: :math:`f_{new} = f_{old} \cdot V_{ratio}` (e.g., total atom counts).
    *   **Invariant**: :math:`f_{new} = f_{old}` (e.g., density, normalized energy).
    *   **None**: Metadata keys without a policy are discarded to prevent stale data 
        contamination in the new system size.
    """
    if ratio is None:
        logger.warning("[HiSE] No valid ratio provided for _lift_inputs; skipping supercell generation.")
        return None

    src_path = Path(src_path).resolve()
    if not src_path.exists():
        logger.warning(f"[HiSE] Source database path does not exist: {src_path}")
        return None

    try:
        logger.info(f"[HiSE] Generating supercell database: {src_path.name} → {dst_path.name} (repeat={ratio})")
        
        # SAGE core is loaded lazily to minimize startup overhead
        from sage_lib.IO.storage.hybrid import HybridStorage
        batch_size = 500
        ratio_vol = float(np.prod(ratio))

        # --- 1. Policy Discovery ---
        # We traverse the materialized functions in the target config to build a 
        # translation map for the metadata cleanup closure.
        scaling_policies = {}
        def _collect_policies(funcs):
            if funcs is None: return
            if not isinstance(funcs, (list, tuple)): funcs = [funcs]
            for f in funcs:
                if hasattr(f, "scaling_logic"):
                    # Handle multi-dimensional features (e.g. Composition Vector)
                    if hasattr(f, "get_feature_index_map"):
                        for name in f.get_feature_index_map().keys():
                            scaling_policies[name] = f.scaling_logic
                    else:
                        # Handle simple scalar features/objectives
                        name = getattr(f, "__name__", str(f))
                        scaling_policies[name] = f.scaling_logic
        
        _collect_policies(getattr(cfg.evaluator, "features_funcs", None))
        _collect_policies(getattr(cfg.evaluator, "objectives_funcs", None))

        # --- 2. Transformation Kernel ---
        # This closure is passed to the storage layer to modify structures in-flight.
        def _cleanup_for_hise(obj):
            apm = getattr(obj, "AtomPositionManager", obj)
            meta = getattr(apm, "metadata", None)
            if not isinstance(meta, dict):
                return obj
            
            for category in ["features", "objectives"]:
                data = meta.get(category)
                if not isinstance(data, dict):
                    continue
                
                new_data = {}
                for key, value in data.items():
                    policy = scaling_policies.get(key, "none")
                    if policy == "linear":
                        new_data[key] = value * ratio_vol
                    elif policy == "invariant":
                        new_data[key] = value
                    # Note: keys with policy 'none' are implicitly dropped here
                
                meta[category] = new_data
            return obj

        # --- 3. Execution Path ---
        # OPTION A: High-performance C++ backend path (if HybridStorage supports it)
        if hasattr(HybridStorage, "generate_supercells"):
            try:
                HybridStorage.generate_supercells(
                    src_root=str(src_path),
                    dst_root=str(dst_path),
                    repeat=ratio,
                    batch_size=batch_size,
                    transform_fn=_cleanup_for_hise,
                    quiet=True
                )
                return dst_path
            except Exception as e:
                logger.warning(f"[HiSE] Optimized SAGE path failed: {e}. Falling back to manual Python loop.")

        # OPTION B: Robust Python-level fallback
        src = HybridStorage(str(src_path), access="ro")
        dst = HybridStorage(str(dst_path), access="rw")
        added = 0
        batch = []

        try:
            for oid in src.iter_ids(batch_size=batch_size):
                obj = src.get(oid)
                apm = getattr(obj, "AtomPositionManager", None)
                if apm is not None:
                    try:
                        # Physical expansion of the cell and positions
                        apm.generate_supercell(np.asarray(ratio, dtype=int))
                        # Metadata transformation
                        _cleanup_for_hise(obj)
                        batch.append(obj)
                    except Exception:
                        continue
                
                if len(batch) >= batch_size:
                    dst.add_many(batch)
                    added += len(batch)
                    batch.clear()

            if batch:
                dst.add_many(batch)
                added += len(batch)
            
            logger.info(f"[HiSE] Lift completed: {added} structures expanded with scaling-aware metadata.")
            return dst_path

        finally:
            src.close()
            dst.close()

    except Exception as e:
        logger.exception(f"[HiSE] Critical failure during supercell expansion from {src_path}: {e}")
        return None



# ---------------------------------------------------------------------
# Path & discovery helpers
# ---------------------------------------------------------------------
def _stage_dir(root: Path, sc: tuple[int, int, int], pattern: str, suffix: str = "") -> Path:
    """Return absolute stage directory path with optional suffix."""
    a, b, c = map(int, sc)
    name = pattern.format(a=a, b=b, c=c)
    if suffix:
        name += suffix
    return (root / name).resolve()


def _detect_stage_inputs(stage_root: Path, mode: str) -> list[Path]:
    """
    Return input XYZ files according to `mode` for a given stage directory.

    Supported modes:
      - "final_dataset": stage_root/config_all.xyz (preferred), fallback to stage_root/config.xyz
      - "generation":    stage_root/generation/gen*/config_g*.xyz (numeric-ordered),
                         fallback to stage_root/generation/*/config.xyz
      - "basin":         stage_root/basin/*/*/config_basin.xyz
    """
    stage_root = Path(stage_root)

    if mode == "final_dataset":
        p = stage_root / "config_all.xyz"
        if p.exists():
            return [p]
        p = stage_root / "config.xyz"
        if p.exists():
            return [p]
        return [stage_root]  # Legacy fallback: return directory itself

    if mode == "generation":
        gen_root = stage_root / "generation"
        if not gen_root.exists():
            return []

        # New naming: generation/genN/config_gN.xyz
        candidates = list(gen_root.glob("gen*/config_g*.xyz"))
        if not candidates:
            # Backward compatibility: generation/*/config.xyz
            candidates = list(gen_root.glob("*/config.xyz"))

        def _gen_index(path: Path) -> int:
            # Prefer N from filename (config_gN.xyz); fallback to dir name (genN).
            m = re.search(r"(\d+)", path.stem)
            if m:
                return int(m.group(1))
            m = re.search(r"(\d+)", path.parent.name)
            return int(m.group(1)) if m else -1

        return sorted(candidates, key=lambda p: (_gen_index(p), str(p)))

    if mode == "basin":
        basin_root = stage_root / "basin"
        if not basin_root.exists():
            return []
        # basin/<species>/<hash>/config_basin.xyz
        candidates = list(basin_root.glob("*/*/config_basin.xyz"))
        # Stable order: by species folder then hash, then filename
        return sorted(candidates, key=lambda p: (p.parents[1].name, p.parent.name, p.name))

    raise ValueError(f"Unsupported mode: {mode!r}")


def _get_stage_status(stage_root: Path) -> str | None:
    """
    Return the current status string from metadata.json, or None if not present.
    """
    meta_path = Path(stage_root) / "metadata.json"
    if not meta_path.exists():
        return None
    try:
        meta = _StageMetadata.read(stage_root)
        status = meta.get("status")
        return str(status) if status is not None else None
    except Exception as e:
        logger.warning(f"[HiSE] Could not read stage metadata at {stage_root}: {e}")
        return None


def _ratio_or_raise(next_sc: tuple[int, int, int], prev_sc: tuple[int, int, int]) -> tuple[int, int, int]:
    """Compute integer replication ratio next/prev; raise if not an exact divisor."""
    r: list[int] = []
    for n, p in zip(next_sc, prev_sc):
        if p == 0 or (n % p) != 0:
            raise ValueError(f"Target supercell {next_sc} is not an integer multiple of {prev_sc}")
        r.append(n // p)
    return (r[0], r[1], r[2])


def _best_compatible_source(
    target: tuple[int, int, int],
    candidates: list[tuple[int, int, int]],
) -> tuple[int, int, int] | None:
    """Pick volume-maximizing candidate that divides `target` coord-wise."""
    best: tuple[int, int, int] | None = None
    best_vol = -1
    ta, tb, tc = target
    for ca, cb, cc in candidates:
        if (ta % ca == 0) and (tb % cb == 0) and (tc % cc == 0):
            vol = ca * cb * cc
            if vol > best_vol:
                best = (ca, cb, cc)
                best_vol = vol
    return best


def _is_commensurate(target: tuple[int, int, int], prev: tuple[int, int, int]) -> bool:
    """Return True if each target coord is an integer multiple of prev coord."""
    ta, tb, tc = target
    pa, pb, pc = prev
    return pa != 0 and tb % pb == 0 and tc % pc == 0 and ta % pa == 0


def _compute_stage_shared_dir(base_shared: Path, out_root: Path, stage_root: Path) -> Path:
    """Make a stage-shared mailbox path (common to all agents of the stage)."""
    try:
        rel = stage_root.relative_to(out_root)
    except Exception:
        rel = Path(stage_root.name)
    return (base_shared / rel).resolve()


def harvest_motifs_for_hise_stage(stage_root: Path, cfg: GAConfig):
    """
    Analyzes the population of a completed stage and saves motifs to 'motif_library.json'.
    """
    if not cfg.hise or not cfg.hise.motifs.enabled:
        return

    logger.info(f"[HiSE] Harvesting motifs from {stage_root}")

    # 1. Load population from HybridStorage
    try:
        from sage_lib.IO.storage.hybrid import HybridStorage
        db_path = stage_root / "db"  # Default name
        if not db_path.exists():
            # Try stage_root itself if it is a directory storage
            db_path = stage_root
        
        storage = HybridStorage(db_path, access="ro")
        try:
            ids = list(storage.iter_ids())
            if not ids:
                logger.warning(f"[HiSE] No population found at {db_path}; skipping motif harvesting.")
                return

            # Phase 1: Fast energy pass (O(N))
            # Most storages in EZGA/SAGE provide a cheap way to get energy without full structure loading
            energies_list = []
            for oid in ids:
                # 1. Best case: storage provides a cheap metadata-based accessor 
                if hasattr(storage, "get_energy"):
                    energies_list.append(storage.get_energy(oid))
                else:
                    # 2. Fallback: load object and try common energy attributes/methods
                    struct = storage.get(oid)
                    # Check common names: .energy, .E, or .get_potential_energy()
                    e = getattr(struct, "energy", getattr(struct, "E", None))
                    if e is None and hasattr(struct, "get_potential_energy"):
                        try:
                            e = struct.get_potential_energy()
                        except Exception:
                            e = None
                    
                    energies_list.append(float(e) if e is not None else 0.0)
            energies_arr = np.array(energies_list)

            # Phase 2: Lazy loading for structural analysis
            def loader(i: int):
                return storage.get(ids[i])

            # 3. Setup Harvester
            m_cfg = cfg.hise.motifs
            
            # Build substrate constraints from elements if provided
            subs_cons = []
            if m_cfg.substrate_elements:
                elements = set(m_cfg.substrate_elements)
                def is_substrate(idx: int, struct: Any) -> bool:
                    apm = getattr(struct, "AtomPositionManager", None)
                    if apm is not None:
                        return apm.atomLabelsList[idx] in elements
                    return False
                subs_cons.append(is_substrate)

            harvester = MotifHarvester(
                substrate_constraints=subs_cons,
                kBT_eff=m_cfg.kBT_eff,
                energy_threshold=m_cfg.energy_threshold,
                energy_window=m_cfg.energy_window,
                min_structure_count=m_cfg.min_structure_count,
                min_weighted_frequency=m_cfg.min_weighted_frequency,
                min_atoms=m_cfg.min_atoms,
                max_atoms=m_cfg.max_atoms,
                min_fragments=m_cfg.min_fragments,
                max_fragments=m_cfg.max_fragments,
                allow_single_fragment_motifs=m_cfg.allow_single_fragment_motifs,
                bond_scale=m_cfg.fragment_connect_scale,
                include_surface_context=m_cfg.include_surface_context,
                context_scale=m_cfg.context_scale,
                context_mode=m_cfg.context_mode,
                context_bin_width=m_cfg.context_bin_width,
                # Scaling & Budget
                max_structures_to_analyze=m_cfg.scaling.max_structures_to_analyze,
                max_fragments_per_structure=m_cfg.scaling.max_fragments_per_structure,
                max_motifs_per_structure=m_cfg.scaling.max_motifs_per_structure,
                max_families=m_cfg.scaling.max_families,
                sampling_mode=m_cfg.scaling.sampling_mode,
                top_pool_factor=m_cfg.scaling.top_pool_factor,
                early_stop=m_cfg.scaling.early_stop,
                convergence_patience=m_cfg.scaling.convergence_patience,
                rank_interval=m_cfg.scaling.rank_interval,
                fingerprint_mode=m_cfg.scaling.fingerprint_mode,
                selection_seed=m_cfg.scaling.selection_seed,
                require_negative_delta_e=m_cfg.require_negative_delta_e
            )
            harvester.harvest(energies=energies_arr, loader=loader)
            logger.info(f"[HiSE] Harvested {len(harvester.families)} motif families from {len(harvester.analyzed_indices)} structures.")
            
        finally:
            storage.close()

        top_motifs = harvester.get_top_motifs()
        logger.info(f"[HiSE] Selected {len(top_motifs)} top motifs after statistical filtering.")

        if top_motifs:
            lib = MotifLibrary(str(stage_root / "motif_library.json"))
            lib.save(top_motifs)
            logger.info(f"[HiSE] Successfully saved {len(top_motifs)} top motifs to library.")
        else:
            logger.info("[HiSE] No motifs met the enrichment criteria.")

    except Exception as e:
        logger.warning(f"[HiSE] Motif harvesting failed: {e}")


# ---------------------------------------------------------------------
# Lift implementations (Partition / ASE)
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# Config utilities
# ---------------------------------------------------------------------
def _deep_set(cfg: GAConfig, dotted_key: str, value: Any) -> None:
    """Set nested value on a GAConfig using dotted-path keys."""
    obj: Any = cfg
    parts = dotted_key.split(".")
    for k in parts[:-1]:
        obj = getattr(obj, k)
    setattr(obj, parts[-1], value)


def _apply_stage_overrides(stage_cfg: GAConfig, overrides: dict[str, list[Any]] | None, idx: int) -> None:
    """Apply per-stage overrides (dot path → list of values), if present."""
    if not overrides:
        return
    for dotted_key, values in overrides.items():
        if idx < len(values):
            _deep_set(stage_cfg, dotted_key, values[idx])


def _adjust_stage_scoped_paths(stage_cfg: GAConfig, out_root: Path, stage_root: Path) -> None:
    """Set output_path and agentic.shared_dir for the given stage.

    The agentic.shared_dir becomes a *stage-shared* mailbox:
      base_shared / stage_root.relative_to(out_root)
    """
    stage_cfg.output_path = stage_root
    try:
        if stage_cfg.agentic and stage_cfg.agentic.shared_dir:
            base_shared = Path(stage_cfg.agentic.shared_dir)
            stage_shared = _compute_stage_shared_dir(base_shared, out_root, stage_root)
            stage_shared.mkdir(parents=True, exist_ok=True)
            stage_cfg.agentic.shared_dir = stage_shared
    except Exception:
        pass


# ---------------------------------------------------------------------
# Main orchestrator
# ---------------------------------------------------------------------
def run_hise(cfg: GAConfig) -> dict[tuple[int, int, int], Path]:
    """Execute a HiSE (coarse-to-fine) campaign.

    For each supercell stage:
      * Build an isolated stage directory.
      * Optionally **replace** the base input by lifting (tiling) previous results
        according to `hise.lift_method` and `hise.input_from`.
      * Apply per-stage overrides.
      * Scope agentic.shared_dir to a stage-shared mailbox directory.
      * Skip completed stages if `hise.restart=True`.
      * Run the GA.

    Lift methods:
      - "tile":            Partition lifting by generate_supercell (immediate previous).
      - "best_compatible": Partition lifting from the largest prior stage that divides target.
      - "ase":             ASE fallback (Atoms.repeat).

    Returns:
      Mapping from supercell tuple → stage directory Path.
    """
    assert cfg.hise and cfg.hise.supercells, "HiSE requires a non-empty list of supercells."
    hise: HiSEParams = cfg.hise

    supercells = [(int(a), int(b), int(c)) for a, b, c in hise.supercells]
    out_root = Path(cfg.output_path).resolve()
    out_root.mkdir(parents=True, exist_ok=True)

    seen_sc: dict[tuple[int, int, int], int] = {}
    stage_dirs: dict[Any, Path] = {}
    done_sc: list[tuple[int, int, int]] = []  # stages already completed (for best_compatible)
    rng = np.random.default_rng(73)

    for idx, sc in enumerate(supercells):
        sc_3 = (int(sc[0]), int(sc[1]), int(sc[2]))
        
        # Handle naming collisions for duplicate supercell dimensions
        count = seen_sc.get(sc_3, 0)
        seen_sc[sc_3] = count + 1
        
        suffix = ""
        if count > 0:
            # First is "", second is "_a", third is "_b", etc.
            suffix = f"_{chr(ord('a') + count - 1)}"
            
        stage_root = _stage_dir(out_root, sc_3, hise.stage_dir_pattern, suffix=suffix)
        
        # For the return dict, we use (sc_3, suffix) if collision exists to avoid overwriting keys
        key = sc_3 if count == 0 else (sc_3, suffix)
        stage_dirs[key] = stage_root
        stage_root.mkdir(parents=True, exist_ok=True)

        # Build a deep-copied stage-local config
        stage_cfg: GAConfig = cfg.model_copy(deep=True)
        _apply_stage_overrides(stage_cfg, hise.overrides, idx)
        _materialize_stage_constraints_if_any(stage_cfg)

        if "max_generations" not in (hise.overrides or {}):
            stage_cfg.max_generations = cfg.max_generations
        _adjust_stage_scoped_paths(stage_cfg, out_root, stage_root)

        # --- determine state ---
        stage_status = _get_stage_status(stage_root)

        # A — completed → skip
        # Restart/skip if the stage sentinel exists
        if hise.restart and stage_status == "completed":
            logger.info(f"[HiSE] Skipping completed stage {sc} at {stage_root}")
            done_sc.append(sc_3)
            continue

        # B — incomplete / failed → resume
        elif stage_status in ("running", "failed"):
            logger.info(f"[HiSE] Resuming incomplete stage {sc} at {stage_root}")
            # You can choose whether to reset metadata or just continue
            meta = _StageMetadata(stage_root, sc_3, stage_cfg.max_generations)
            meta.write(status="restarted")

        # C — not initialized → prepare (possibly upscale input)
        elif stage_status is None:
            logger.info(f"[HiSE] Initializing new stage {sc} at {stage_root}")

            # Escalation phase: idx > 0
            if idx > 0:
                # Note: _best_compatible_source returns the sc_3 tuple. 
                # We assume we lift from the FIRST occurrence of that sc_3 for simplicity,
                # or the caller should specify if they want to lift from a specific suffix.
                source_sc: tuple[int, int, int] | None  = _best_compatible_source(sc_3, done_sc)
                if source_sc is None:
                    logger.warning(f"[HiSE] No compatible previous stage found for target {sc}; proceeding without lifted results.")
                else:
                    src_root = _stage_dir(out_root, source_sc, hise.stage_dir_pattern)
                    try:
                        ratio = _ratio_or_raise(sc_3, source_sc)
                    except ValueError:
                        logger.warning(f"[HiSE] Source {source_sc} not commensurate with target {sc}; skipping results lift.")
                        ratio = None

                    if ratio is not None:
                        # 1. Seeding: If this is the first escalation, we also scale and include the initial DB_RO
                        # We do this first so reference IDs are at the beginning of the database.
                        if idx == 1:
                            initial_db_ro = getattr(cfg.population, "db_ro_path", None)
                            if initial_db_ro and Path(initial_db_ro).exists():
                                logger.info(f"[HiSE] Seeding stage with scaled RO data from {initial_db_ro}")
                                try:
                                    _lift_inputs(
                                        method=hise.lift_method,
                                        src_path=Path(initial_db_ro),
                                        dst_path=stage_root,
                                        ratio=sc_3, # Full ratio from 1x1x1 to current sc_3
                                        reseed_fraction=1.0,
                                        rng=rng,
                                        cfg=stage_cfg,
                                    )
                                except Exception as e:
                                    logger.warning(f"[HiSE] Seeding from RO data failed: {e}")

                        # 2. Results Lift: Scale previous stage results into the local database of the current stage
                        logger.info(f"[HiSE] Lifting previous results from {source_sc} to {sc_3}")
                        try:
                            _lift_inputs(
                                method=hise.lift_method,
                                src_path=src_root,
                                dst_path=stage_root,
                                ratio=ratio,
                                reseed_fraction=float(hise.reseed_fraction),
                                rng=rng,
                                cfg=stage_cfg,
                            )
                        except Exception as e:
                            logger.warning(f"[HiSE] Results lift from {source_sc} failed: {e}")

        # Apply stage paths
        stage_cfg.population.db_path = stage_root
        
        # Once we have escalated into the local database (idx > 0), 
        # we don't need a separate RO path because everything is merged.
        if idx > 0:
            stage_cfg.population.db_ro_path = None
            stage_cfg.population.dataset_path = None

        logger.info(f"[HiSE] Stage {idx + 1}/{len(supercells)} — SC={sc} → {stage_root}")
        engine = build_default_engine(stage_cfg)

        # Initialize metadata tracker
        meta = _StageMetadata(stage_root, sc, stage_cfg.max_generations)
        meta.write(status="running")

        try:
            _ = engine.run()

            # --- Motif Harvesting (New) ---
            harvest_motifs_for_hise_stage(stage_root, stage_cfg)

            meta.write(
                status="completed",
                generation=getattr(engine.ctx, "generation", stage_cfg.max_generations),
                converged=getattr(engine.ctx, "is_converge", None),
                elapsed_seconds=getattr(engine.ctx, "elapsed", lambda _: 0)("engine"),
            )
            done_sc.append(sc_3)

        except Exception as e:
            logger.exception(f"[HiSE] Stage {sc} failed: {e}")
            meta.write(status="failed", error=str(e))
            continue

    return stage_dirs
