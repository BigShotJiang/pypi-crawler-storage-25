# src/ezga/hise/motifs.py
# SPDX-License-Identifier: MIT
"""
Motif Extraction and Enrichment Analysis for HiSE (High-Performance).

This module implements a scalable, budget-limited motif mining engine.
It separates energy-based selection from structural analysis, enabling
efficient processing of millions of candidates via lazy loading.
"""

from __future__ import annotations
import os
import json
import logging
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Set, Union, Callable, Sequence
from collections import Counter
from pathlib import Path
from ase import Atoms
from ase.io import write as ase_write
from ase.data import covalent_radii, atomic_numbers

from ezga.utils.molecule_blacklist import build_radius_graph, build_bond_graph, CUTOFF_MAX

logger = logging.getLogger(__name__)

def formula_from_labels(labels: List[str]) -> str:
    """Produces a canonical chemical formula like H2O or CO2."""
    c = Counter(labels)
    return "".join(f"{el}{c[el] if c[el] > 1 else ''}" for el in sorted(c))

@dataclass
class MotifFamily:
    """Represents a group of geometrically and contextually similar motifs."""
    id: str
    formula: str
    labels: List[str]
    canonical_positions: np.ndarray  # (N, 3) relative to anchor

    # Counts
    raw_occurrence_count: int = 0
    structure_count: int = 0
    weighted_structure_count: float = 0.0

    # Energies
    energies_with: List[float] = field(default_factory=list)
    
    # Selection metrics
    mean_energy: float = 0.0
    min_energy: float = 1e9
    delta_e: float = 0.0
    weighted_frequency: float = 0.0
    score: float = 0.0

    # Geometric properties
    lateral_extent: float = 0.0
    height_extent: float = 0.0
    n_fragments: int = 1
    
    # Statistical Significance
    odds_ratio: float = 1.0
    log_odds_ratio: float = 0.0
    fisher_p_value: float = 1.0
    q_value: float = 1.0
    
    # Enrichment Scoring
    low_count: int = 0
    background_count: int = 0
    enrichment: float = 1.0

    # Context
    context_signature: Optional[str] = None
    
    # Structural Fingerprint (RDF)
    rdf: Optional[np.ndarray] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "formula": self.formula,
            "labels": self.labels,
            "canonical_positions": self.canonical_positions.tolist(),
            "raw_occurrence_count": self.raw_occurrence_count,
            "structure_count": self.structure_count,
            "weighted_structure_count": self.weighted_structure_count,
            "mean_energy": self.mean_energy,
            "min_energy": self.min_energy,
            "delta_e": self.delta_e,
            "weighted_frequency": self.weighted_frequency,
            "score": self.score,
            "lateral_extent": self.lateral_extent,
            "height_extent": self.height_extent,
            "n_fragments": self.n_fragments,
            "low_count": self.low_count,
            "background_count": self.background_count,
            "enrichment": self.enrichment,
            "odds_ratio": self.odds_ratio,
            "log_odds_ratio": self.log_odds_ratio,
            "fisher_p_value": self.fisher_p_value,
            "q_value": self.q_value,
            "context_signature": self.context_signature
        }

class MotifHarvester:
    """
    High-performance harvester optimized for lazy-loading from large databases.
    """
    
    def __init__(
        self,
        kBT_eff: float = 0.10,
        energy_threshold: float = 0.03,
        energy_window: Optional[float] = None,
        min_structure_count: int = 3,
        min_weighted_frequency: float = 0.01,
        min_atoms: int = 1,
        max_atoms: int = 10000,
        min_fragments: int = 1,
        max_fragments: int = 10000,
        allow_single_fragment_motifs: bool = True,
        
        # Subgraph Mining Parameters
        max_component_fragments: int = 5,
        motif_orders: Tuple[int, ...] = (1, 2, 3, 4),
        max_local_fragments: int = 5,
        max_submotifs_per_component: int = 100,
        max_subgraph_expansions_per_component: int = 20000,
        
        # Scoring & Redundancy
        size_penalty_factor: float = 0.0,
        score_energy_weight: float = 0.0,
        redundancy_penalty_strength: float = 0.5,
        redundancy_similarity_threshold: float = 0.6,
        subgraph_overlap_threshold: float = 0.75,
        distance_bin_width: float = 0.20,
        low_energy_quantile: float = 0.20,
        min_low_count: int = 3,
        min_enrichment: float = 1.2,
        bond_scale: float = 1.25,
        include_surface_context: bool = True,
        context_scale: float = 0.6,
        context_mode: str = "species_counts",
        context_bin_width: float = 0.25,
        # Scaling limits
        max_structures_to_analyze: int = 2000,
        max_fragments_per_structure: int = 200,
        max_motifs_per_structure: int = 100,
        max_families: int = 5000,
        sampling_mode: str = "uniform",
        frequency_weight_mode: str = "flat",
        top_pool_factor: int = 10,
        early_stop: bool = True,
        convergence_patience: int = 300,
        rank_interval: int = 100,
        fingerprint_mode: str = "exact",
        selection_seed: Optional[int] = None,
        require_negative_delta_e: bool = False,
        substrate_constraints: Optional[Sequence[Callable[[int, Any], bool]]] = None,
        use_pbc_for_motif_connectivity: bool = True,
        diversity_selection: bool = True,
        diversity_lateral_bin: float = 0.5,
        diversity_height_bin: float = 0.5,
        max_lateral_extent: Optional[float] = 6.0,
        max_height_extent: Optional[float] = 4.0,
        include_context_in_fingerprint: bool = False,
        forbidden_elements: Optional[List[str]] = None,
        composition_constraints: Optional[Dict[str, Tuple[int, Optional[int]]]] = None,
        motif_filter: Optional[Callable[[List[str]], bool]] = None,
        energy_metric: Optional[Callable[[int, Any, float], float]] = None,
        max_per_formula: int = 3,
        default_composition_bounds: Tuple[int, Optional[int]] = (0, 4)
    ):
        self.kBT_eff = kBT_eff
        self.energy_threshold = energy_threshold
        self.energy_window = energy_window
        self.min_structure_count = min_structure_count
        self.min_weighted_frequency = min_weighted_frequency
        self.require_negative_delta_e = require_negative_delta_e
        self.substrate_constraints = substrate_constraints or []
        self.bond_scale = bond_scale
        self.size_penalty_factor = size_penalty_factor
        self.score_energy_weight = score_energy_weight
        self.redundancy_penalty_strength = redundancy_penalty_strength
        self.redundancy_similarity_threshold = redundancy_similarity_threshold
        self.subgraph_overlap_threshold = subgraph_overlap_threshold
        self.include_context_in_fingerprint = include_context_in_fingerprint
        
        self.frequency_weight_mode = frequency_weight_mode
        if self.frequency_weight_mode not in {"flat", "boltzmann"}:
            raise ValueError("frequency_weight_mode must be 'flat' or 'boltzmann'.")
            
        self.forbidden_elements = set(forbidden_elements) if forbidden_elements else set()
        self.composition_constraints = composition_constraints or {}
        self.energy_metric = energy_metric
        self.motif_filter = motif_filter
        self.max_per_formula = max_per_formula
        self.max_subgraph_expansions_per_component = max_subgraph_expansions_per_component
        self.default_composition_bounds = default_composition_bounds
        
        # Deprecated/Legacy
        self.max_component_fragments = max_component_fragments
        self.max_local_fragments = max_local_fragments
        self.min_atoms = min_atoms
        self.max_atoms = max_atoms
        self.min_fragments = min_fragments
        self.max_fragments = max_fragments
        self.allow_single_fragment_motifs = allow_single_fragment_motifs
        self.motif_orders = motif_orders
        self.rank_interval = rank_interval
        self.min_enrichment = min_enrichment
        self.low_energy_quantile = low_energy_quantile
        self.min_low_count = min_low_count
        self.use_pbc_for_motif_connectivity = use_pbc_for_motif_connectivity
        self.diversity_selection = diversity_selection
        self.diversity_lateral_bin = diversity_lateral_bin
        self.diversity_height_bin = diversity_height_bin
        self.max_lateral_extent = max_lateral_extent
        self.max_height_extent = max_height_extent
        self.min_enrichment = min_enrichment
        
        self.include_surface_context = include_surface_context
        self.context_scale = context_scale
        self.context_mode = context_mode
        self.context_bin_width = context_bin_width
        self.distance_bin_width = distance_bin_width
        self.max_submotifs_per_component = max_submotifs_per_component
        
        # Scaling
        self.max_structures_to_analyze = max_structures_to_analyze
        self.max_fragments_per_structure = max_fragments_per_structure
        self.max_motifs_per_structure = max_motifs_per_structure
        self.max_families = max_families
        self.sampling_mode = sampling_mode
        self.top_pool_factor = top_pool_factor
        self.early_stop = early_stop
        self.convergence_patience = convergence_patience
        self.rank_interval = rank_interval
        self.fingerprint_mode = fingerprint_mode
        self.selection_seed = selection_seed
        


        if self.kBT_eff <= 0: raise ValueError("kBT_eff must be positive.")
        if self.distance_bin_width <= 0: raise ValueError("distance_bin_width must be positive.")
        if not (0.0 < self.low_energy_quantile < 1.0): raise ValueError("low_energy_quantile must be between 0 and 1.")
        if self.max_structures_to_analyze <= 0: raise ValueError("max_structures_to_analyze must be positive.")
        if self.max_fragments_per_structure <= 0: raise ValueError("max_fragments_per_structure must be positive.")
        if self.max_motifs_per_structure <= 0: raise ValueError("max_motifs_per_structure must be positive.")
        if self.max_subgraph_expansions_per_component <= 0: raise ValueError("max_subgraph_expansions_per_component must be positive.")
        if not (0.0 <= self.subgraph_overlap_threshold <= 1.0):
            raise ValueError("subgraph_overlap_threshold must be between 0 and 1.")
        
        if not self.motif_orders: raise ValueError("motif_orders must not be empty.")
        self.motif_orders = tuple(sorted(set(int(k) for k in self.motif_orders)))
        if any(k <= 0 for k in self.motif_orders): raise ValueError("All motif_orders must be positive integers.")

        if self.bond_scale <= 0: raise ValueError("bond_scale must be positive.")
        if self.max_per_formula <= 0: raise ValueError("max_per_formula must be positive.")
        
        for el, bounds in self.composition_constraints.items():
            if not isinstance(bounds, tuple) or len(bounds) != 2:
                raise ValueError(f"composition_constraints['{el}'] must be a tuple: (min_count, max_count).")
            min_c, max_c = bounds
            if min_c < 0: raise ValueError(f"composition_constraints['{el}'] has negative min_count.")
            if max_c is not None and max_c < min_c:
                raise ValueError(f"composition_constraints['{el}'] has max_count < min_count.")
        
        # Validate default bounds
        d_min, d_max = self.default_composition_bounds
        if d_min < 0: raise ValueError("default_composition_bounds has negative min_count.")
        if d_max is not None and d_max < d_min:
            raise ValueError("default_composition_bounds has max_count < min_count.")

        self.families: Dict[str, MotifFamily] = {}
        self.total_weight_analyzed: float = 0.0
        self.analyzed_indices: np.ndarray = np.array([])
        self.energies: np.ndarray = np.array([])

    def select_indices_from_energies(self, energies: np.ndarray) -> np.ndarray:
        """Budgeted selection using top-pool partitioning for efficiency."""
        n_total = len(energies)
        if n_total == 0: return np.array([], dtype=int)
        
        e_min = np.min(energies)
        valid_mask = np.ones(n_total, dtype=bool)
        if self.energy_window is not None:
            valid_mask = (energies - e_min <= self.energy_window)
        
        valid_indices = np.where(valid_mask)[0]
        if valid_indices.size == 0: return np.array([], dtype=int)
        
        if valid_indices.size <= self.max_structures_to_analyze:
            return valid_indices

        # 1. Take a "top pool" of interesting candidates (Partitioning is O(N))
        pool_size = min(valid_indices.size, self.top_pool_factor * self.max_structures_to_analyze)
        # We partition the valid_indices by their energy
        valid_energies = energies[valid_indices]
        partition_idx = np.argpartition(valid_energies, pool_size - 1)[:pool_size]
        pool_indices = valid_indices[partition_idx]
        pool_energies = energies[pool_indices]

        # 2. Sample from the pool
        rng = np.random.default_rng(self.selection_seed)
        
        if self.sampling_mode == "top_energy":
            return pool_indices[np.argsort(pool_energies)[:self.max_structures_to_analyze]]
            
        elif self.sampling_mode == "boltzmann":
            weights = np.exp(-(pool_energies - e_min) / self.kBT_eff)
            p = weights / np.sum(weights)
            return rng.choice(pool_indices, size=self.max_structures_to_analyze, replace=False, p=p)
            
        elif self.sampling_mode == "uniform":
            return rng.choice(valid_indices, size=min(valid_indices.size, self.max_structures_to_analyze), replace=False)
            
        elif self.sampling_mode == "stratified":
            n = self.max_structures_to_analyze
            sorted_pool = pool_indices[np.argsort(pool_energies)]
            n_low, n_mid = int(0.7 * n), int(0.2 * n)
            n_rand = n - n_low - n_mid
            
            low = sorted_pool[:n_low]
            mid = sorted_pool[n_low : n_low + n_mid]
            rem = sorted_pool[n_low + n_mid:]
            rand = rng.choice(rem, size=min(n_rand, len(rem)), replace=False) if rem.size > 0 else np.array([], dtype=int)
            return np.concatenate([low, mid, rand])
            
        return pool_indices[:self.max_structures_to_analyze]
    def _passes_composition_filters(self, labels: List[str]) -> bool:
        if self.motif_filter is not None and not self.motif_filter(labels): return False
        counts = Counter(labels)
        elements = set(counts)
        if elements & self.forbidden_elements: return False
        
        # Check explicit constraints
        for el, (min_count, max_count) in self.composition_constraints.items():
            n = counts.get(el, 0)
            if n < min_count: return False
            if max_count is not None and n > max_count: return False
            
        # Check default constraints for species NOT in explicit list
        for el in elements:
            if el not in self.composition_constraints:
                n = counts[el]
                min_c, max_c = self.default_composition_bounds
                if n < min_c: return False
                if max_c is not None and n > max_c: return False
                
        return True

    def get_metadata(self) -> dict:
        """Exports the harvester configuration for exact reproducibility during feature/objective evaluation."""
        return {
            "bond_scale": self.bond_scale,
            "min_atoms": self.min_atoms,
            "max_atoms": self.max_atoms,
            "distance_bin_width": getattr(self, "distance_bin_width", 0.2),
            "match_threshold": getattr(self, "redundancy_similarity_threshold", 0.7),
            "forbidden_elements": self.forbidden_elements,
            "allow_single_fragment_motifs": self.allow_single_fragment_motifs,
            "composition_constraints": getattr(self, "composition_constraints", None)
        }

    def harvest(self, energies: np.ndarray, loader: Callable[[int], Any], metric_values: Optional[np.ndarray] = None):
        """Main entry point for scalable analysis using lazy loading."""
        raw_energies = np.asarray(energies, dtype=float)
        if raw_energies.ndim != 1: raise ValueError("energies must be a one-dimensional array.")
        
        if metric_values is not None:
            self.energies = np.asarray(metric_values, dtype=float)
            if self.energies.shape != raw_energies.shape:
                raise ValueError("metric_values must have the same shape as energies.")
        elif self.energy_metric is None:
            self.energies = raw_energies
        else:
            logger.warning("[HiSE] energy_metric requires loading all structures before selection. For large databases, precompute metric_values and pass them to harvest().")
            effective_energies = []
            for i, raw_e in enumerate(raw_energies):
                struct = loader(i)
                if struct is None: effective_energies.append(np.nan); continue
                effective_energies.append(float(self.energy_metric(i, struct, raw_e)))
            self.energies = np.asarray(effective_energies, dtype=float)

        if not np.all(np.isfinite(self.energies)):
            bad = np.where(~np.isfinite(self.energies))[0][:10]
            raise ValueError(f"effective energies contain NaN or infinite values. First bad indices: {bad.tolist()}")

        # Reset state for a fresh harvest run
        self.families = {}
        self.total_weight_analyzed = 0.0
        self.analyzed_indices = self.select_indices_from_energies(self.energies)
        
        if self.analyzed_indices.size == 0:
            return
            
        # Re-calc weights for the ANALYZED subset only
        if self.frequency_weight_mode == "flat":
            weights_all = np.ones_like(self.energies, dtype=float)
        elif self.frequency_weight_mode == "boltzmann":
            e_min = np.min(self.energies)
            weights_all = np.exp(-(self.energies - e_min) / self.kBT_eff)
        else:
            raise RuntimeError("Invalid frequency_weight_mode.")
            
        self.total_weight_analyzed = float(np.sum(weights_all[self.analyzed_indices]))
        
        motif_to_struct_indices: Dict[str, Set[int]] = {}
        last_top_50: Set[str] = set()
        stable_count = 0

        # Calculate low energy cutoff for enrichment scoring
        e_cutoff = np.quantile(self.energies[self.analyzed_indices], self.low_energy_quantile)

        for count, idx in enumerate(self.analyzed_indices):
            try:
                struct = loader(idx)
                if struct is None: continue
                
                weight = weights_all[idx]
                energy = self.energies[idx]
                apm = struct.AtomPositionManager
                lat = apm.latticeVectors
                
                frags, is_excluded = self._get_fragments(struct)
                motifs = self._cluster_fragments(struct, frags, lat)
                
                seen_motifs = set()

                for m in motifs:
                    n_at = len(m["labels"])
                    logger.debug(f"[HiSE] Discovered motif candidate: {formula_from_labels(m['labels'])} ({n_at} atoms)")

                    if not (self.min_atoms <= n_at <= self.max_atoms):
                        logger.debug(f"[HiSE] Discarding motif: size {n_at} outside range [{self.min_atoms}, {self.max_atoms}]")
                        continue
                    if not (self.min_fragments <= m["n_frags"] <= self.max_fragments):
                        logger.debug(f"[HiSE] Discarding motif: fragments {m['n_frags']} outside range [{self.min_fragments}, {self.max_fragments}]")
                        continue
                    if not self._passes_composition_filters(m["labels"]):
                        logger.debug(f"[HiSE] Discarding motif: composition failed filters")
                        continue
                    
                    if m["n_frags"] == 1 and not self.allow_single_fragment_motifs:
                        logger.debug(f"[HiSE] Discarding motif: single-fragment motifs disabled")
                        continue

                    if not self._motif_positions_are_connected(m["pos"], m["labels"], scale=self.bond_scale):
                        logger.debug(f"[HiSE] Discarding motif: stored positions are disconnected")
                        continue
                        
                    lateral, height = self._motif_extents(m["pos"])
                    ctx = self._get_surface_context(apm, m["com"], lat, is_excluded) if self.include_surface_context else "None"
                    try:
                        fp, canon_pos, canon_labels = self.canonicalize(m["pos"], m["labels"])
                        logger.debug(f"[HiSE] Motif Fingerprint: {fp}")
                    except Exception as e:
                        logger.warning(f"[HiSE] Fingerprinting failed for {formula_from_labels(m['labels'])}: {e}")
                        continue

                    full_id = f"{fp}_CTX_{ctx}" if self.include_context_in_fingerprint else fp
                    
                    if full_id not in self.families:
                        if len(self.families) >= self.max_families: self._prune_families()
                        self.families[full_id] = MotifFamily(
                            id=full_id, formula=formula_from_labels(m["labels"]), labels=canon_labels,
                            canonical_positions=canon_pos, 
                            context_signature=ctx, 
                            n_fragments=m["n_frags"],
                            lateral_extent=lateral, height_extent=height
                        )
                    
                    fam = self.families[full_id]
                    fam.raw_occurrence_count += 1
                    
                    if full_id not in seen_motifs:
                        seen_motifs.add(full_id)
                        fam.structure_count += 1
                        fam.weighted_structure_count += weight
                        fam.energies_with.append(energy)
                        
                        if energy < fam.min_energy:
                            fam.min_energy = energy
                            fam.canonical_positions = canon_pos
                            fam.labels = canon_labels
                            fam.formula = formula_from_labels(canon_labels)
                            fam.lateral_extent = lateral
                            fam.height_extent = height
                            fam.n_fragments = m["n_frags"]
                            fam.context_signature = ctx
                            
                        if energy <= e_cutoff:
                            fam.low_count += 1
                        else:
                            fam.background_count += 1

                    if full_id not in motif_to_struct_indices: motif_to_struct_indices[full_id] = set()
                    motif_to_struct_indices[full_id].add(idx)

                # Periodic Ranking and Early Stopping
                if count > 0 and count % self.rank_interval == 0:
                    self._rank_families(motif_to_struct_indices)
                    if self.early_stop:
                        current_top = set(m.id for m in self.get_top_motifs(limit=50))
                        if current_top and current_top == last_top_50:
                            stable_count += self.rank_interval
                        else:
                            stable_count = 0
                            last_top_50 = current_top
                        
                        if stable_count >= self.convergence_patience:
                            logger.info(f"Motif harvesting converged at analysis step {count}.")
                            break

            except Exception as e:
                logger.warning(f"Harvester error at index {idx}: {e}")
                continue

        # Log summary of results
        n_fam = len(self.families)
        if n_fam > 0:
            logger.info(f"[HiSE] Harvest complete: Discovered {n_fam} unique motif families across {len(self.analyzed_indices)} structures.")
        else:
            logger.warning("[HiSE] Harvest complete: No motif families discovered. Check your filters (min_atoms, bond_scale) or constraints.")

        self._rank_families(motif_to_struct_indices)

    def _rank_families(self, motif_to_struct_indices: Dict[str, Set[int]]):
        """Statistics computed ONLY over analyzed structures to avoid bias."""
        if self.analyzed_indices.size == 0: return
        e_min_total = np.min(self.energies)
        analyzed_set = set(map(int, self.analyzed_indices))

        # Calculate N_low and N_bg for enrichment
        e_cutoff = np.quantile(self.energies[self.analyzed_indices], self.low_energy_quantile)
        N_low = np.sum(self.energies[self.analyzed_indices] <= e_cutoff)
        N_bg = len(self.analyzed_indices) - N_low

        for fid, fam in self.families.items():
            fam.weighted_frequency = fam.weighted_structure_count / self.total_weight_analyzed
            if not fam.energies_with: continue
            fam.mean_energy = float(np.mean(fam.energies_with))
            
            # delta_e = mean_with - mean_without (among analyzed only)
            idx_with = list(motif_to_struct_indices.get(fid, []))
            idx_without = list(analyzed_set - set(idx_with))
            
            if not idx_without:
                fam.delta_e = 0.0
            else:
                fam.delta_e = fam.mean_energy - np.mean(self.energies[idx_without])
            
            if N_low > 0 and N_bg > 0:
                alpha = 0.5
                p_low = (fam.low_count + alpha) / (N_low + 2 * alpha)
                p_bg = (fam.background_count + alpha) / (N_bg + 2 * alpha)
                fam.enrichment = p_low / p_bg
                
                # Smoothed Log-Odds Ratio
                a, b = fam.low_count, N_low - fam.low_count
                c, d = fam.background_count, N_bg - fam.background_count
                fam.log_odds_ratio = float(np.log(((a + alpha) * (d + alpha)) / ((c + alpha) * (b + alpha))))
                fam.odds_ratio = float(np.exp(fam.log_odds_ratio))
            else:
                fam.enrichment = 1.0

        # Fisher's Exact + BH-FDR
        try:
            from scipy.stats import fisher_exact
            has_scipy = True
        except Exception:
            has_scipy = False

        p_values, fids = [], []
        for fid, fam in self.families.items():
            if has_scipy and N_low > 0 and N_bg > 0:
                a, b = fam.low_count, N_low - fam.low_count
                c, d = fam.background_count, N_bg - fam.background_count
                odds, p = fisher_exact([[a, b], [c, d]], alternative="greater")
                fam.fisher_p_value = float(p)
                if np.isfinite(odds):
                    fam.odds_ratio = float(odds)
                    fam.log_odds_ratio = float(np.log(odds)) if odds > 0 else 0.0
            else:
                fam.fisher_p_value = 1.0
            p_values.append(fam.fisher_p_value)
            fids.append(fid)

        q_values = self._bh_fdr(p_values)
        for fid, q in zip(fids, q_values):
            fam = self.families[fid]
            fam.q_value = float(q)
            
            # Scoring: support * frequency * enrichment * significance * energy * size
            support_term = np.log1p(fam.low_count)
            frequency_term = np.log1p(fam.structure_count)
            enrichment_term = max(0.5, fam.enrichment)
            significance_term = np.log1p(-np.log10(max(fam.q_value, 1e-300)))
            energy_term = np.exp(-fam.delta_e * self.score_energy_weight / self.kBT_eff)
            size_penalty = np.exp(-self.size_penalty_factor * len(fam.labels))
            
            fam.score = (support_term * frequency_term * enrichment_term * significance_term * energy_term * size_penalty)

    def _bh_fdr(self, p_values: list[float]) -> np.ndarray:
        # Benjamini–Hochberg FDR correction
        p = np.asarray(p_values, dtype=float)
        n = len(p)
        if n == 0:
            return np.array([], dtype=float)

        # 1. Order p-values
        order = np.argsort(p)
        ranked_p = p[order]

        # 2. Adjusted values: p * n / rank
        ranks = np.arange(1, n + 1)
        q_steps = ranked_p * n / ranks

        # 3. Accumulated minimum from the end (enforce monotonicity)
        q_ordered = np.minimum.accumulate(q_steps[::-1])[::-1]

        # 4. Restore original order and clip [0, 1]
        q_final = np.empty(n, dtype=float)
        q_final[order] = q_ordered

        return np.clip(q_final, 0.0, 1.0)

    def _prune_families(self):
        if len(self.families) <= self.max_families: return
        items = sorted(self.families.items(), key=lambda x: x[1].structure_count, reverse=True)
        self.families = dict(items[:int(0.8 * self.max_families)])

    def _motif_extents(self, positions: np.ndarray) -> Tuple[float, float]:
        xy = positions[:, :2]
        if len(xy) <= 1: lateral = 0.0
        else:
            diff = xy[:, None, :] - xy[None, :, :]
            lateral = float(np.max(np.linalg.norm(diff, axis=2)))
        return lateral, float(np.max(positions[:, 2]) - np.min(positions[:, 2]))

    def _pbc_displacement(self, apm: Any, dr: np.ndarray) -> np.ndarray:
        if hasattr(apm, "apply_pbc_to_displacement"):
            return np.asarray(apm.apply_pbc_to_displacement(dr))
        return dr

    def _cov_radius(self, label: str, default: float = 0.8) -> float:
        z = atomic_numbers.get(label, None)
        if z is None:
            return default
        return float(covalent_radii[z])

    def _get_excluded_mask(self, structure: Any, bg: Any) -> np.ndarray:
        """
        Returns True for atoms that must NOT be included in motifs.
        Exclusion sources:
        1. Atomic constraints stored in AtomPositionManager.
        2. User-provided substrate_constraints.
        """
        apm = structure.AtomPositionManager
        constraints = getattr(apm, "atomicConstraints", None)
        is_excluded = np.zeros(bg.N, dtype=bool)

        for i in range(bg.N):
            # 1. Built-in constraints
            if constraints is not None:
                try:
                    c = constraints[i]
                    if hasattr(c, "__len__"):
                        if any(c):
                            is_excluded[i] = True
                    elif bool(c):
                        is_excluded[i] = True
                except Exception:
                    pass

            if is_excluded[i]:
                continue

            # 2. User-defined constraints
            for c_func in self.substrate_constraints:
                try:
                    if c_func(i, structure):
                        is_excluded[i] = True
                        break
                except Exception as e:
                    if not hasattr(self, "_constraint_error_shown"):
                        logger.error(f"[HiSE] Constraint evaluation failed: {e}")
                        self._constraint_error_shown = True

        return is_excluded



    def _get_fragments(self, structure: Any) -> Tuple[List[Dict[str, Any]], np.ndarray]:
        """
        Builds primitive motif units from all non-excluded atoms.
        Important design rule:
        - Excluded atoms are never part of motifs.
        - Non-excluded atoms can all be part of motifs.
        - No element is treated specially.
        """
        apm = structure.AtomPositionManager
        rg = build_radius_graph(apm, cutoff=CUTOFF_MAX)
        bg = build_bond_graph(rg)

        is_excluded = self._get_excluded_mask(structure, bg)
        n_excluded = int(np.sum(is_excluded))
        n_mobile = int(bg.N - n_excluded)

        logger.debug(
            f"[HiSE] Structure analysis: {bg.N} atoms total | "
            f"{n_excluded} excluded | {n_mobile} motif-candidate atoms"
        )

        fragments = []

        candidate_indices = np.where(~is_excluded)[0]
        # No longer filtering by composition_constraints here to allow permissive behavior.
        # Atoms will still be validated by _passes_composition_filters later.
            
        if candidate_indices.size > self.max_fragments_per_structure:
            if self.composition_constraints:
                raise ValueError(
                    f"[HiSE] {candidate_indices.size} motif-candidate atoms remain after composition filtering, "
                    f"but max_fragments_per_structure={self.max_fragments_per_structure}. "
                    "Increase max_fragments_per_structure or use stronger substrate_constraints. "
                    "Uniform subsampling would bias composition-constrained motif mining."
                )
                
            logger.warning(
                f"[HiSE] {candidate_indices.size} motif-candidate atoms found, but max_fragments_per_structure={self.max_fragments_per_structure}. "
                "Using a uniformly spaced subset. Increase this limit for full coverage."
            )
            pick = np.linspace(0, candidate_indices.size - 1, self.max_fragments_per_structure, dtype=int)
            candidate_indices = candidate_indices[pick]

        for i in candidate_indices:
            fragments.append({
                "indices": [int(i)],
                "pos": bg.rg.R[[i]].copy(),
                "labels": [bg.rg.S[i]],
                "com": bg.rg.R[i].copy(),
            })

        if fragments:
            formulas = [formula_from_labels(f["labels"]) for f in fragments]
            formulas_str = str(formulas[:8]) + ("..." if len(formulas) > 8 else "")
            logger.debug(
                f"[HiSE] Built {len(fragments)} primitive motif units. "
                f"Examples: {formulas_str}"
            )
        else:
            logger.debug("[HiSE] No motif-candidate atoms found after constraints.")

        return fragments, is_excluded

    def _fragments_are_connected(self, f1: Dict[str, Any], f2: Dict[str, Any], apm: Any, scale: float = 1.25) -> bool:
        """Checks whether two primitive fragments are chemically connected."""
        for i, p1 in enumerate(f1["pos"]):
            r1 = self._cov_radius(f1["labels"][i])
            for j, p2 in enumerate(f2["pos"]):
                r2 = self._cov_radius(f2["labels"][j])
                dr = p1 - p2
                if self.use_pbc_for_motif_connectivity:
                    dr = self._pbc_displacement(apm, dr)
                if np.linalg.norm(dr) <= scale * (r1 + r2):
                    return True
        return False

    def _cluster_fragments(self, structure: Any, fragments: List[Dict[str, Any]], lattice: np.ndarray) -> List[Dict[str, Any]]:
        if not fragments: return []
        apm = structure.AtomPositionManager
        n_frags = len(fragments)
        adj = np.zeros((n_frags, n_frags), dtype=bool)

        for i in range(n_frags):
            for j in range(i + 1, n_frags):
                if self._fragments_are_connected(fragments[i], fragments[j], apm, scale=self.bond_scale):
                    adj[i, j] = True
                    adj[j, i] = True

        components = []
        visited = set()

        for i in range(n_frags):
            if i in visited: continue
            comp = [i]
            q = [i]
            visited.add(i)
            while q:
                curr = q.pop(0)
                for n in np.where(adj[curr])[0]:
                    if n not in visited:
                        visited.add(n)
                        comp.append(n)
                        q.append(n)
            components.append(comp)

        logger.debug(f"[HiSE] Found {len(components)} connected components from {n_frags} candidate atoms.")

        motifs = []
        for comp in components:
            motifs.extend(self._extract_submotifs_from_component(comp, fragments, adj, apm))

        logger.debug(f"[HiSE] Generated {len(motifs)} raw motif candidates (pre-deduplication).")
        motifs = self._deduplicate_motifs(motifs)
        return motifs[:self.max_motifs_per_structure]

    def _motif_index_jaccard(self, a: Dict[str, Any], b: Dict[str, Any]) -> float:
        ia, ib = set(a.get("indices", [])), set(b.get("indices", []))
        if not ia and not ib: return 1.0
        if not ia or not ib: return 0.0
        return len(ia & ib) / len(ia | ib)

    def _deduplicate_motifs(self, motifs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        unique: List[Dict[str, Any]] = []
        seen = set()
        for m in motifs:
            key = tuple(m.get("fragment_ids", []))
            if not key: key = tuple(sorted(m.get("indices", [])))
            if key in seen: continue
            
            too_overlapping = False
            for u in unique:
                if self._motif_index_jaccard(m, u) >= self.subgraph_overlap_threshold:
                    too_overlapping = True
                    break
            if too_overlapping: continue
            
            seen.add(key)
            unique.append(m)
        return unique

    def _build_motif_from_cluster(
        self,
        cluster: List[int],
        fragments: List[Dict[str, Any]],
        apm: Any,
        adj: np.ndarray,
    ) -> Dict[str, Any]:
        """
        Builds a motif from primitive fragments.

        If PBC connectivity is enabled, the motif is unwrapped by walking the
        fragment-connectivity graph. This prevents valid PBC-connected motifs
        from being stored as visually disconnected pieces.
        """
        cluster = list(cluster)
        cluster_set = set(cluster)

        root = cluster[0]

        unwrapped_com: Dict[int, np.ndarray] = {
            root: fragments[root]["com"].copy()
        }

        stack = [root]

        while stack:
            i = stack.pop()

            for j in cluster:
                if j not in cluster_set:
                    continue

                if j in unwrapped_com:
                    continue

                if not adj[i, j]:
                    continue

                dr = fragments[j]["com"] - fragments[i]["com"]

                if self.use_pbc_for_motif_connectivity:
                    dr = self._pbc_displacement(apm, dr)

                unwrapped_com[j] = unwrapped_com[i] + dr
                stack.append(j)

        # Safety fallback. Should not happen if subset connectivity was checked.
        if len(unwrapped_com) != len(cluster):
            raise RuntimeError("Could not unwrap full motif cluster; cluster is not connected.")

        m_pos = []
        m_labels = []

        for idx in cluster:
            frag = fragments[idx]

            rel_pos = frag["pos"] - frag["com"]
            placed_pos = unwrapped_com[idx] + rel_pos

            m_pos.append(placed_pos)
            m_labels.extend(frag["labels"])

        m_pos_v = np.vstack(m_pos)

        return {
            "pos": m_pos_v,
            "labels": m_labels,
            "n_frags": len(cluster),
            "com": np.mean(m_pos_v, axis=0),
            "fragment_ids": sorted(cluster),
            "indices": [
                atom_idx
                for frag_idx in cluster
                for atom_idx in fragments[frag_idx].get("indices", [])
            ],
        }

    def _subset_is_connected(self, subset: Tuple[int, ...], adj: np.ndarray) -> bool:
        subset_list = list(subset)
        if len(subset_list) <= 1: return True
        subset_set = set(subset_list)
        visited = {subset_list[0]}
        stack = [subset_list[0]]
        while stack:
            i = stack.pop()
            for j in subset_list:
                if j not in visited and adj[i, j]:
                    visited.add(j)
                    stack.append(j)
        return visited == subset_set

    def _motif_positions_are_connected(self, positions: np.ndarray, labels: List[str], scale: Optional[float] = None) -> bool:
        """Final safety check: verifies that stored motif coordinates form one connected object in Cartesian space."""
        if scale is None: scale = self.bond_scale
        n = len(labels)
        if n <= 1: return True
        adj = np.zeros((n, n), dtype=bool)

        for i in range(n):
            r_i = self._cov_radius(labels[i])
            for j in range(i + 1, n):
                r_j = self._cov_radius(labels[j])
                d = np.linalg.norm(positions[i] - positions[j])
                if d <= scale * (r_i + r_j):
                    adj[i, j] = True
                    adj[j, i] = True

        visited = {0}
        stack = [0]
        while stack:
            i = stack.pop()
            for j in np.where(adj[i])[0]:
                if j not in visited:
                    visited.add(j)
                    stack.append(j)

        return len(visited) == n

    def _partial_composition_is_feasible(self, labels: List[str]) -> bool:
        """Checks whether a partially grown subgraph can still become valid."""
        counts = Counter(labels)
        elements = set(counts)
        if elements & self.forbidden_elements: return False
        # Check explicit constraints
        for el, (_, max_count) in self.composition_constraints.items():
            if max_count is not None and counts.get(el, 0) > max_count:
                return False
                
        # Check default constraints for species NOT in explicit list
        for el in elements:
            if el not in self.composition_constraints:
                _, max_c = self.default_composition_bounds
                if max_c is not None and counts[el] > max_c:
                    return False
        return True

    def _max_subgraph_atom_count(self) -> int:
        """Conservative upper bound for subgraph growth."""
        if self.composition_constraints:
            upper_sum = 0
            for _, max_count in self.composition_constraints.values():
                if max_count is None: return self.max_atoms
                upper_sum += int(max_count)
            return min(self.max_atoms, upper_sum)
        if self.motif_orders:
            return min(self.max_atoms, max(self.motif_orders))
        return self.max_atoms

    def _labels_for_fragment_subset(self, subset: Tuple[int, ...], fragments: List[Dict[str, Any]]) -> List[str]:
        labels = []
        for frag_idx in subset: labels.extend(fragments[frag_idx]["labels"])
        return labels

    def _extract_submotifs_from_component(self, comp: List[int], fragments: List[Dict[str, Any]], adj: np.ndarray, apm: Any) -> List[Dict[str, Any]]:
        """Extracts connected subgraphs using composition-guided pruning."""
        submotifs = []
        accepted_subsets = set()
        visited_subsets: Set[Tuple[int, ...]] = set()
        comp_set = set(comp)
        max_atoms_allowed = self._max_subgraph_atom_count()
        expansions = 0

        for root in comp:
            start = (int(root),)
            stack: List[Tuple[int, ...]] = [start]
            visited_subsets.add(start)

            while stack:
                subset = stack.pop()
                subset_set = set(subset)
                labels = self._labels_for_fragment_subset(subset, fragments)
                n_atoms, n_frags = len(labels), len(subset)

                if n_atoms > max_atoms_allowed or not self._partial_composition_is_feasible(labels): continue

                # Accept complete motifs satisfying final filters
                if (self.min_atoms <= n_atoms <= self.max_atoms and 
                    self.min_fragments <= n_frags <= self.max_fragments and 
                    (n_frags > 1 or self.allow_single_fragment_motifs) and 
                    self._passes_composition_filters(labels)):
                    
                    if subset not in accepted_subsets:
                        motif = self._build_motif_from_cluster(list(subset), fragments, apm, adj)
                        if self._motif_positions_are_connected(motif["pos"], motif["labels"], scale=self.bond_scale):
                            accepted_subsets.add(subset)
                            submotifs.append(motif)
                            if len(submotifs) >= self.max_submotifs_per_component: return submotifs

                if n_atoms >= max_atoms_allowed: continue

                # Frontier: all neighbors of the current connected subgraph
                frontier = set()
                for i in subset:
                    for j in np.where(adj[i])[0]:
                        j = int(j)
                        if j in comp_set and j not in subset_set: frontier.add(j)

                for j in sorted(frontier):
                    new_subset = tuple(sorted(subset + (j,)))
                    if new_subset in visited_subsets: continue
                    new_labels = self._labels_for_fragment_subset(new_subset, fragments)
                    if not self._partial_composition_is_feasible(new_labels): continue
                    visited_subsets.add(new_subset)
                    stack.append(new_subset)
                    expansions += 1
                    if expansions >= self.max_subgraph_expansions_per_component:
                        logger.warning(f"[HiSE] Reached max_subgraph_expansions_per_component. Stopping expansion for this component.")
                        return submotifs
        return submotifs

    def _get_surface_context(self, apm: Any, motif_com: np.ndarray, lattice: np.ndarray, is_excluded: np.ndarray) -> str:
        a_surf = min(np.linalg.norm(lattice[0]), np.linalg.norm(lattice[1]))
        r_context = self.context_scale * a_surf
        pos = apm.atomPositions; labels = apm.atomLabelsList
        diff = self._pbc_displacement(apm, pos - motif_com)
        dists = np.linalg.norm(diff, axis=1)
        
        # Infer context: atoms within distance that are excluded
        mask = (dists < r_context) & is_excluded
        if not np.any(mask): return "clean"
        ctx_labels = [labels[i] for i in np.where(mask)[0]]
        
        if self.context_mode == "species_counts": return formula_from_labels(ctx_labels)
        if self.context_mode == "binned_distances":
            ctx_data = sorted((l, int(d / self.context_bin_width)) for l, d in zip(ctx_labels, dists[mask]))
            return "-".join(f"{l}{b}" for l, b in ctx_data)
        return "excluded_context"

    def canonicalize(self, positions: np.ndarray, labels: List[str]) -> Tuple[str, np.ndarray, List[str]]:
        pos = np.asarray(positions, dtype=float)
        # Shift to center of mass for rotation-invariant distance calculation
        pos_com = pos - np.mean(pos, axis=0)
        
        pair_keys = []
        n = len(labels)
        for i in range(n):
            for j in range(i + 1, n):
                a, b = sorted((labels[i], labels[j]))
                d = np.linalg.norm(pos_com[i] - pos_com[j])
                d_bin = int(round(d / self.distance_bin_width))
                pair_keys.append((a, b, d_bin))
                
        # Species-pair distance bin fingerprint
        fp_pairs = "|".join(f"{a}-{b}:{d_bin}" for a, b, d_bin in sorted(pair_keys))
        fp_str = formula_from_labels(labels) + "|" + fp_pairs if pair_keys else formula_from_labels(labels) + "|mono"
        
        # Consistent canonical ordering for the MotifFamily object storage
        anchor_idx = np.argmin(pos[:, 2])
        canon_pos = np.array(positions, dtype=float) - positions[anchor_idx]
        canon_pos[:, 2] -= np.min(canon_pos[:, 2])
        
        # Lexicographical sort by species and then by distance to anchor
        zs = np.array([atomic_numbers.get(l, 0) for l in labels])
        dists = np.linalg.norm(canon_pos, axis=1)
        indices = np.lexsort((dists, -zs))
        
        return fp_str, canon_pos[indices], [labels[i] for i in indices]

    def get_top_motifs(self, limit: int = 50, auto_relax: bool = True, target_min: int = 10) -> List[MotifFamily]:
        if not self.families:
            return []

        current_w_freq = self.min_weighted_frequency
        current_enrich = self.min_enrichment
        current_low = self.min_low_count
        
        for step in range(5):
            top = []
            discard_reasons: Counter[str] = Counter()
            for fam in self.families.values():
                if fam.structure_count < self.min_structure_count: 
                    discard_reasons["structure_count"] += 1; continue
                if fam.weighted_frequency < current_w_freq: 
                    discard_reasons["weighted_frequency"] += 1; continue
                if fam.low_count < current_low: 
                    discard_reasons["low_count"] += 1; continue
                if fam.enrichment < current_enrich: 
                    discard_reasons["enrichment"] += 1; continue
                
                if self.require_negative_delta_e:
                    if fam.delta_e >= -self.energy_threshold: 
                        discard_reasons["delta_e"] += 1; continue
                
                # Apply extent filters
                if self.max_lateral_extent is not None and fam.lateral_extent > self.max_lateral_extent:
                    discard_reasons["size_extent"] += 1; continue
                if self.max_height_extent is not None and fam.height_extent > self.max_height_extent:
                    discard_reasons["size_extent"] += 1; continue
                
                top.append(fam)
                
            if not auto_relax or len(top) >= target_min or step == 4:
                if step > 0 or discard_reasons:
                    logger.debug(f"[HiSE] Final selection: {len(top)} motifs (w_freq>={current_w_freq:.4f}, enrich>={current_enrich:.2f})")
                    if step == 0:
                        logger.debug(f"[HiSE] Motif discard reasons: {dict(discard_reasons)}")
                break
            
            logger.debug(f"[HiSE] Only found {len(top)} motifs (target {target_min}). Auto-relaxing thermodynamic thresholds (Step {step+1}/5)...")
            current_w_freq *= 0.2
            current_enrich = max(0.5, current_enrich - 0.2)
            current_low = max(1, current_low - 1)
            
        final_top = sorted(top, key=lambda x: x.score, reverse=True)
        if self.diversity_selection:
            final_top = self._select_diverse_motifs(final_top, limit)
        else:
            final_top = final_top[:limit]
            
        return final_top


    def _compute_family_rdf(self, fam: MotifFamily, r_max: float = 10.0) -> np.ndarray:
        """Computes a structural RDF for a motif family to enable shape-based diversity filtering."""
        if fam.rdf is not None:
            return fam.rdf
            
        from scipy.spatial.distance import pdist
        pos = fam.canonical_positions
        if len(pos) < 2:
            fam.rdf = np.zeros(int(r_max / self.distance_bin_width))
            return fam.rdf
            
        dists = pdist(pos)
        bins = np.arange(0, r_max + self.distance_bin_width, self.distance_bin_width)
        rdf, _ = np.histogram(dists, bins=bins)
        
        # Normalize to unit vector for cosine similarity
        norm = np.linalg.norm(rdf)
        fam.rdf = rdf.astype(float) / (norm + 1e-12)
        return fam.rdf

    def _motif_similarity(self, a: MotifFamily, b: MotifFamily) -> float:
        """
        Calculates structural similarity between two motif families using RDF correlation.
        Returns a value between 0.0 (completely different) and 1.0 (structurally identical).
        """
        # 1. Composition must be similar first (heuristic)
        if a.formula != b.formula:
            return 0.0
            
        # 2. Compare structural fingerprints (RDF)
        rdf_a = self._compute_family_rdf(a)
        rdf_b = self._compute_family_rdf(b)
        
        # Cosine similarity (both are already normalized)
        return float(np.dot(rdf_a, rdf_b))

    def _select_diverse_motifs(self, motifs: List[MotifFamily], limit: int) -> List[MotifFamily]:
        selected: List[MotifFamily] = []
        remaining = list(motifs)
        formula_counts: Counter[str] = Counter()
        
        while remaining and len(selected) < limit:
            best = None
            best_adjusted_score = -np.inf
            
            for m in remaining:
                if formula_counts[m.formula] >= self.max_per_formula: continue
                
                max_sim = 0.0
                if selected:
                    max_sim = max(self._motif_similarity(m, s) for s in selected)
                
                penalty = self.redundancy_penalty_strength * max_sim if max_sim >= self.redundancy_similarity_threshold else 0.0
                adjusted_score = m.score * max(0.0, 1.0 - penalty)
                
                if adjusted_score > best_adjusted_score:
                    best_adjusted_score = adjusted_score
                    best = m
            
            if best is None: break
            selected.append(best)
            formula_counts[best.formula] += 1
            remaining.remove(best)
            
        return selected

class MotifLibrary:
    """
    Persistence layer for motif libraries. Handles JSON serialization 
    and XYZ visual trajectory export. Includes metadata to ensure reproducibility.
    """
    def __init__(self, library_path: str):
        self.library_path = library_path
        self.xyz_path = library_path.replace(".json", ".xyz")
        self.motifs: List[MotifFamily] = []
        self.metadata: dict = {}

    def save(self, motifs: List[MotifFamily], metadata: Optional[dict] = None):
        """Saves families and metadata to JSON and generates a companion XYZ for visualization."""
        self.motifs = motifs
        self.metadata = metadata or {}
        
        output_data = {
            "metadata": self.metadata,
            "motifs": [m.to_dict() for m in motifs]
        }
        
        with open(self.library_path, "w") as f:
            json.dump(output_data, f, indent=2)
        self.to_xyz()

    def load(self) -> List[MotifFamily]:
        """Loads a motif library from a JSON file into MotifFamily objects with full metadata."""
        if not os.path.exists(self.library_path):
            raise FileNotFoundError(f"Motif library JSON not found at {self.library_path}")
            
        with open(self.library_path, "r") as f:
            data = json.load(f)
            
        # Backward compatibility with older libraries that were just lists
        if isinstance(data, list):
            motifs_data = data
            self.metadata = {}
        else:
            motifs_data = data.get("motifs", [])
            self.metadata = data.get("metadata", {})
            
        self.motifs = [MotifFamily(
            id=d["id"], 
            formula=d["formula"], 
            labels=d["labels"],
            canonical_positions=np.array(d["canonical_positions"]),
                raw_occurrence_count=d.get("raw_occurrence_count", 0),
                structure_count=d.get("structure_count", 0),
                weighted_structure_count=d.get("weighted_structure_count", 0.0),
                mean_energy=d.get("mean_energy", 0.0),
                min_energy=d.get("min_energy", 1e9),
                delta_e=d.get("delta_e", 0.0),
                weighted_frequency=d.get("weighted_frequency", 0.0),
                score=d.get("score", 0.0),
                lateral_extent=d.get("lateral_extent", 0.0),
                height_extent=d.get("height_extent", 0.0),
                n_fragments=d.get("n_fragments", 1),
                context_signature=d.get("context_signature"),
                low_count=d.get("low_count", 0),
                background_count=d.get("background_count", 0),
                enrichment=d.get("enrichment", 1.0),
                odds_ratio=d.get("odds_ratio", 1.0),
                log_odds_ratio=d.get("log_odds_ratio", 0.0),
                fisher_p_value=d.get("fisher_p_value", 1.0),
                q_value=d.get("q_value", 1.0)
            ) for d in motifs_data]
        return self.motifs

    def to_xyz(self, output_path: Optional[str] = None):
        """
        Reconstructs an XYZ visual trajectory from the loaded motif families.
        
        USE CASE:
        Use this when you have a .json motif library (e.g. from a remote server) 
        but need to visualize the motifs in VESTA/OVITO/GROMACS.
        
        PARAMETERS:
        - output_path: Destination .xyz file. Defaults to library_path with .xyz extension.
        """
        out = output_path or self.xyz_path
        if not self.motifs:
            logger.warning("[MotifLibrary] No motifs loaded to export to XYZ.")
            return

        traj = []
        for m in self.motifs:
            at = Atoms(symbols=m.labels, positions=m.canonical_positions)
            # Store full metadata in the atoms info dictionary
            for k, v in m.to_dict().items():
                if k != "canonical_positions":
                    at.info[k] = v
            traj.append(at)
        
        ase_write(out, traj)
        logger.info(f"[MotifLibrary] Successfully exported {len(traj)} motifs to {out}")

def harvest_from_database(
    db_path: Union[str, Path],
    output_path: Union[str, Path],
    max_structures: int = 2000,
    min_atoms: int = 1,
    min_structure_count: int = 1,
    require_negative_delta_e: bool = False,
    energy_window: float = 0.5,
    substrate_constraints: Optional[List[Callable[[int, Any], bool]]] = None,
    target_min_motifs: int = 10,
    limit_motifs: int = 50,
    default_composition_bounds: Tuple[int, Optional[int]] = (0, 4),
    **harvester_kwargs
):
    """
    Standalone utility to mine motifs from an existing HybridStorage/SageLib database.
    
    Example:
        harvest_from_database("path/to/db", "motifs_output/")
    """
    from sage_lib.IO.storage.hybrid import HybridStorage
    from pathlib import Path

    db_path = Path(db_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    logger.info(f"Opening database at {db_path}...")
    storage = HybridStorage(db_path, access="ro")
    try:
        ids = list(storage.iter_ids())
        if not ids:
            logger.warning("No structures found in database.")
            return

        energies_list = []
        for oid in ids:
            if hasattr(storage, "get_energy"):
                energies_list.append(storage.get_energy(oid))
            else:
                struct = storage.get(oid)
                e = getattr(struct, "energy", getattr(struct, "E", None))
                if e is None and hasattr(struct, "get_potential_energy"):
                    try: e = struct.get_potential_energy()
                    except Exception: e = None
                energies_list.append(float(e) if e is not None else 0.0)
        
        energies_arr = np.array(energies_list)

        def loader(i: int):
            return storage.get(ids[i])

        harvester = MotifHarvester(
            max_structures_to_analyze=max_structures,
            min_atoms=min_atoms,
            min_structure_count=min_structure_count,
            require_negative_delta_e=require_negative_delta_e,
            energy_window=energy_window,
            substrate_constraints=substrate_constraints,
            default_composition_bounds=default_composition_bounds,
            **harvester_kwargs
        )

        logger.info(f"Harvesting motifs from {len(ids)} structures (budget={max_structures})...")
        harvester.harvest(energies=energies_arr, loader=loader)
        
    finally:
        storage.close()

    logger.info(f"Analysis complete. Total motif families discovered: {len(harvester.families)}")
    if len(harvester.families) == 0:
        logger.warning("No motif families were discovered. Check if your 'substrate_constraints' cover all atoms in the system.")
        
    top_motifs = harvester.get_top_motifs(limit=limit_motifs, target_min=target_min_motifs)
    logger.info(f"Selected {len(top_motifs)} motifs after applying filters (min_atoms={min_atoms}, delta_e_check={require_negative_delta_e}).")

    if top_motifs:
        lib = MotifLibrary(str(output_path / "motif_library.json"))
        lib.save(top_motifs, metadata=harvester.get_metadata())
        logger.info(f"Motifs saved to {output_path}")
    else:
        logger.warning("No motifs passed the filters.")

def mutation_add_motif_from_library(library_path: str, slab: bool = True, substrate_elements: Optional[List[str]] = None, surface_thickness: float = 1.0, collision_scale: float = 0.75, z_offset: float = 2.0, tag: int = 3, sample_by: str = "score", max_attempts: int = 50):
    lib = MotifLibrary(library_path); motifs = lib.load()
    if not motifs: return lambda s, rng=None: None
    
    def _safe_cov_radius(label: str, default: float = 0.8) -> float:
        z = atomic_numbers.get(label, None)
        if z is None: return default
        return float(covalent_radii[z])

    if sample_by == "delta_e":
        vals = np.array([-m.delta_e for m in motifs], dtype=float)
    else:
        vals = np.array([getattr(m, sample_by, 1.0) for m in motifs], dtype=float)

    vals = np.nan_to_num(vals, nan=0.0, posinf=0.0, neginf=0.0)
    
    # Sampling probabilities must be non-negative.
    vals = np.clip(vals, 0.0, None)
    
    if np.sum(vals) > 0:
        probs = vals / np.sum(vals)
    else:
        probs = np.ones(len(motifs)) / len(motifs)

    def func(structure, rng: np.random.Generator | None = None):
        if rng is None: rng = np.random.default_rng()
        apm = structure.AtomPositionManager; pos_fixed = apm.atomPositions; labels_fixed = apm.atomLabelsList
        subs = set(substrate_elements) if substrate_elements else set()
        for _ in range(max_attempts):
            motif = rng.choice(np.array(motifs, dtype=object), p=probs)
            if slab:
                if not subs:
                    raise ValueError(
                        "substrate_elements must be provided when slab=True. "
                        "Use slab=False for bulk-like systems."
                    )
                mask = np.array([l in subs for l in labels_fixed])
                if not np.any(mask): return None
                max_z_sub = np.max(pos_fixed[mask, 2])
                surf_idx = np.where(mask & (pos_fixed[:, 2] > max_z_sub - surface_thickness))[0]
                if surf_idx.size == 0: return None
                insert_pos = pos_fixed[rng.choice(surf_idx)] + np.array([0, 0, z_offset])
            else: insert_pos = np.dot(rng.random(3), apm.latticeVectors)
            theta = rng.uniform(0, 2*np.pi); c, s = np.cos(theta), np.sin(theta); R_z = np.array([[c,-s,0],[s,c,0],[0,0,1]])
            phi_t = rng.uniform(0, 2*np.pi); axis = np.array([np.cos(phi_t), np.sin(phi_t), 0]); alpha_t = rng.uniform(0, 15*np.pi/180)
            K = np.array([[0,-axis[2],axis[1]],[axis[2],0,-axis[0]],[-axis[1],axis[0],0]]); R_tilt = np.eye(3)+np.sin(alpha_t)*K+(1-np.cos(alpha_t))*(K@K)
            motif_pos = (motif.canonical_positions @ (R_tilt @ R_z).T) + insert_pos
            collision = False
            for i_m, p_m in enumerate(motif_pos):
                r_m = _safe_cov_radius(motif.labels[i_m])
                diff = apm.apply_pbc_to_displacement(pos_fixed - p_m) if hasattr(apm, "apply_pbc_to_displacement") else pos_fixed - p_m
                dists = np.linalg.norm(diff, axis=1)
                for i_f, dist in enumerate(dists):
                    if dist < collision_scale * (r_m + _safe_cov_radius(labels_fixed[i_f])):
                        collision = True; break
                if collision: break
            if not collision:
                import copy; child = copy.deepcopy(structure)
                child.AtomPositionManager.add_atom(motif.labels, motif_pos, atomType=tag)
                return child
        return None
    return func
