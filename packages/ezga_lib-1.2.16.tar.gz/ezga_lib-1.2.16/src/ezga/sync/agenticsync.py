"""hash_batch_sync.py
Content-addressable batch exchange backend.

This implementation fills in the missing pieces of *HashBatchSync* so it can be
used as a drop‑in component for your GA or worker processes.

Key features
------------
*   **Deterministic sharded directories** based on SHA‑256 of the buffer payload.
*   Thread‑safe public API (all mutating methods behind an *RLock*).
*   **Crash tolerant**: processed batch IDs are persisted to *seen.json*.
*   Optional pruning of old batches via *max_retained*.
*   Minimal external dependencies – only `Partition` from your own code base.

Usage example
-------------
```python
sync = HashBatchSync(shared_dir="/path/to/shared", max_buffer=2048)

sync.append(obj1)
sync.append(obj2)
...
# Flush manually if auto_publish=False
sync.flush()

# Consumer side
for batch_id, payload in sync.get_batch():
    ...
```
"""

from __future__ import annotations

import hashlib
import json
import logging
import numpy as np
import os
import pickle
import shutil
import time
import uuid
from collections.abc import Generator, Sequence, Iterator
from pathlib import Path
from threading import RLock
from typing import Any, cast

logger = logging.getLogger("EZGA_Sync")

# ---------------------------------------------------------------------------
# Adaptive Evolution Policy (DEPRECATED 5D Model)
# ---------------------------------------------------------------------------
class AdaptiveEvolutionPolicy:
    """
    Deprecated. Use ReducedAdaptiveController instead.
    """
    REGIMES = {
        "wide":         {"E": 0.80, "S": 0.25, "D": 0.75, "F": 0.10, "C": 0.50},
        "deep":         {"E": 0.35, "S": 0.65, "D": 0.35, "F": 0.25, "C": 0.35},
        "explorative":  {"E": 0.95, "S": 0.15, "D": 0.85, "F": 0.10, "C": 0.60},
        "exploitative": {"E": 0.20, "S": 0.90, "D": 0.20, "F": 0.40, "C": 0.45},
        "focused":      {"E": 0.55, "S": 0.55, "D": 0.45, "F": 0.85, "C": 0.40},
        "balanced":     {"E": 0.50, "S": 0.50, "D": 0.50, "F": 0.30, "C": 0.50},
    }

    def __init__(self, initial_strategy: str = "balanced", config: Any = None):
        self.config = config
        tokens = [s.strip().lower() for s in initial_strategy.split(',')]
        self.p = np.zeros(5) 
        keys = ["E", "S", "D", "F", "C"]
        valid_regimes = [t for t in tokens if t in self.REGIMES]
        if not valid_regimes:
            valid_regimes = ["balanced"]
        for t in valid_regimes:
            regime = self.REGIMES[t]
            self.p += np.array([regime[k] for k in keys]) / len(valid_regimes)
        self.learning_rate = getattr(config, "learning_rate", 0.1) if config else 0.1
        self.inertia = getattr(config, "inertia", 0.8) if config else 0.8
        self.repulsion_scale = 1.0

    def update_policy(self, neighbors: list[dict], metrics: dict):
        pass

    def map_to_parameters(self) -> dict:
        """Map 5D vector to physical GA parameters."""
        E, S, D, F, C = self.p
        
        def denorm(val, b):
            return b[0] + val * (b[1] - b[0])

        params = {
            "mutation_rate": denorm(E, (1.0, 5.0)),
            "sampling_temp": denorm(E, (0.2, 3.0)),
            "repulsion": denorm(D, (0.0, 5.0)),
            "comp_repulsion": denorm(D, (0.0, 3.0)),
            "crossover": denorm(E, (0.0, 0.5)),
            "fetch_every": int(round(denorm(1.0 - C, (1, 20)))),
            "max_buffer": int(round(denorm(C, (1, 20)))),
            "steepness": denorm(S, (1.0, 30.0)),
            "obj_temp": denorm(1.0 - S, (0.2, 3.0)),
        }
        
        # Use config bounds if available
        bounds = getattr(self.config, "adaptive_policy", None)
        if bounds:
            params["mutation_rate"] = denorm(E, bounds.mutation_rate_bounds)
            params["sampling_temp"] = denorm(E, bounds.sampling_temperature_bounds)
            params["repulsion"] = denorm(D, bounds.repulsion_weight_bounds)
            params["comp_repulsion"] = denorm(D, bounds.composition_repulsion_bounds)
            params["crossover"] = denorm(E, bounds.crossover_probability_bounds)
            params["fetch_every"] = int(round(denorm(1.0 - C, bounds.fetch_every_bounds)))
            params["max_buffer"] = int(round(denorm(C, bounds.max_buffer_bounds)))
        
        return params

    @property
    def vector_dict(self):
        keys = ["E", "S", "D", "F", "C"]
        return {k: float(self.p[i]) for i, k in enumerate(keys)}


# ---------------------------------------------------------------------------
# Reduced Adaptive Controller (3D Vector [X, R, M])
# ---------------------------------------------------------------------------
class ReducedAdaptiveController:
    """
    Reduced adaptive search controller.

    Maps internal convergence signals and external/social signals into a
    compact 3D adaptive control vector:

        z = [X, R, M]

    where:
        X: exploration-exploitation balance
        R: redundancy-diversity regulation
        M: migration / communication intensity

    The controller does not directly optimize the objective. It updates
    behavioral parameters of the evolutionary algorithm.
    """

    COORDINATES = ("X", "R", "M")

    def __init__(
        self,
        initial_strategy: str = "balanced",
        config: Any = None,
    ):
        self.config = config
        self.learning_rate = getattr(config, "learning_rate", 0.15) if config else 0.15
        self.inertia = getattr(config, "inertia", 0.85) if config else 0.85
        self.diffusion_scale = getattr(config, "diffusion_scale", 0.002) if config else 0.002
        self.repulsion_scale = getattr(config, "repulsion_scale", 0.85) if config else 0.85
        self.repulsion_radius = getattr(config, "repulsion_radius", 0.15) if config else 0.15
        self.z = self._initial_vector(initial_strategy)

    def _initial_vector(self, strategy: str) -> np.ndarray:
        presets: dict[str, np.ndarray] = {
            "explorative": np.array([0.85, 0.75, 0.50], dtype=float),
            "exploitative": np.array([0.20, 0.30, 0.35], dtype=float),
            "diverse": np.array([0.65, 0.90, 0.45], dtype=float),
            "isolated": np.array([0.55, 0.60, 0.10], dtype=float),
            "collaborative": np.array([0.50, 0.55, 0.85], dtype=float),
            "balanced": np.array([0.50, 0.50, 0.50], dtype=float),
        }
        tokens = [s.strip().lower() for s in strategy.split(",")]
        selected = [presets[t] for t in tokens if t in presets]
        if not selected:
            return cast(np.ndarray, presets["balanced"].copy())
        return cast(np.ndarray, np.mean(selected, axis=0))

    @property
    def vector_dict(self) -> dict[str, float]:
        return {
            "X": float(self.z[0]),
            "R": float(self.z[1]),
            "M": float(self.z[2]),
        }

    def update_policy(self, neighbors: list[dict], metrics: dict[str, float]) -> None:
        """Update z = [X, R, M] from local and external signals."""
        novelty = self._clip(metrics.get("novelty_rate", 0.0))
        duplicates = self._clip(metrics.get("duplicate_rate", 0.0))
        progress = self._clip(metrics.get("progress_rate", 0.0))
        acceptance = self._clip(metrics.get("acceptance_rate", 0.0))
        stall = max(0.0, float(metrics.get("stall_gens", 0.0)))
        exploration_without_progress = self._clip(metrics.get("exploration_without_progress", 0.0))
        premature_risk = self._clip(metrics.get("premature_convergence_risk", 0.0))
        relative_improvement = self._clip(metrics.get("relative_improvement_rate", 0.0))
        objective_volatility = max(0.0, float(metrics.get("objective_volatility", 0.0)))
        volatility = float(np.tanh(objective_volatility))

        neighbor_success = 0.0
        neighbor_diversity = 0.0
        communication_pressure = 0.0

        if neighbors:
            neighbor_success = float(np.mean([n.get("metrics", {}).get("success_rate", 0.0) for n in neighbors]))
            neighbor_diversity = float(np.mean([n.get("metrics", {}).get("diversity", 0.0) for n in neighbors]))
            communication_pressure = float(np.mean([n.get("metrics", {}).get("pressure", 0.0) for n in neighbors]))

        neighbor_success = self._clip(neighbor_success)
        neighbor_diversity = self._clip(neighbor_diversity)
        pressure_norm = float(np.tanh(communication_pressure / 5000.0))

        X, R, M = self.z.copy()
        target = self.z.copy()

        # X: exploration ↔ exploitation
        if premature_risk > 0.60:
            target[0] = 1.00
        elif premature_risk > 0.35:
            target[0] = min(1.0, X + 0.30)

        if stall > 8 and progress < 0.05:
            target[0] = min(1.0, target[0] + 0.25)
        elif stall > 4 and progress < 0.10:
            target[0] = min(1.0, target[0] + 0.10)

        if exploration_without_progress > 0.50:
            target[0] = max(0.0, target[0] - 0.25)
        elif exploration_without_progress > 0.25:
            target[0] = max(0.0, target[0] - 0.10)

        productive_progress = max(progress, relative_improvement)
        if productive_progress > 0.20 and acceptance > 0.10:
            target[0] = max(0.0, target[0] - 0.20)
        elif productive_progress > 0.05:
            target[0] = max(0.0, target[0] - 0.05)

        if volatility > 0.70:
            target[0] = min(1.0, target[0] + 0.10)

        # R: redundancy ↔ diversity
        if duplicates > 0.50:
            target[1] = min(1.0, R + 0.35)
        elif duplicates > 0.25:
            target[1] = min(1.0, R + 0.15)

        if premature_risk > 0.60:
            target[1] = 1.00
        elif premature_risk > 0.35:
            target[1] = min(1.0, target[1] + 0.25)

        if novelty > 0.50 and progress < 0.05:
            target[1] = max(0.0, target[1] - 0.10)

        if productive_progress > 0.20:
            target[1] = max(0.0, target[1] - 0.10)

        if neighbors and neighbor_diversity < 0.20:
            target[1] = min(1.0, target[1] + 0.10)

        # M: migration / communication
        if progress < 0.05 and neighbor_success > 0.20:
            target[2] = min(1.0, M + 0.30)

        if pressure_norm > 0.70:
            target[2] = max(0.0, target[2] - 0.35)
        elif pressure_norm > 0.40:
            target[2] = max(0.0, target[2] - 0.15)

        if volatility > 0.70:
            target[2] = max(0.0, target[2] - 0.15)

        if not neighbors:
            target[2] = max(0.0, target[2] - 0.05)

        if premature_risk > 0.60:
            target[2] = min(target[2], 0.30)

        # Apply social repulsion
        if neighbors and self.repulsion_scale > 0:
            repulsion_vec = np.zeros(3)
            for n in neighbors:
                n_policy = n.get("policy_vector", {})
                if not n_policy:
                    continue
                n_z = np.array([n_policy.get("X", 0.5), n_policy.get("R", 0.5), n_policy.get("M", 0.5)])
                diff = self.z - n_z
                dist = np.linalg.norm(diff)
                if 0 < dist < self.repulsion_radius:
                    force = (diff / (dist + 1e-5)) * (1.0 - dist / self.repulsion_radius)
                    repulsion_vec += force
            target += repulsion_vec * self.repulsion_scale

        target = np.clip(target, 0.0, 1.0)
        noise = np.random.normal(0.0, self.diffusion_scale, size=3)
        alpha = 1.0 - self.inertia

        self.z = np.clip(self.inertia * self.z + alpha * target + noise, 0.0, 1.0)

    def map_to_modifiers(self) -> dict[str, float]:
        """Convert z = [X, R, M] into relative parameter scaling modifiers around baseline 1.0 using symmetric exponential scaling."""
        X, R, M = self.z
        dx = X - 0.5
        dr = R - 0.5
        dm = M - 0.5

        def scale(delta: float, strength: float, lo: float = 0.25, hi: float = 4.0) -> float:
            return float(np.clip(np.exp(strength * delta), lo, hi))

        return {
            # X: exploration
            "mutation_rate_scale": scale(dx, 1.5),
            "sampling_temp_scale": scale(dx, 1.5),
            "obj_temp_scale": scale(dx, 1.2),
            "selection_size_scale": scale(dx, 1.0),

            # X inverse: exploitation pressure
            "steepness_scale": scale(-dx, 1.5),

            # usually exploration-compatible
            "crossover_scale": scale(dx, 0.8),

            # R: diversity pressure
            "repulsion_scale": scale(dr, 2.5, lo=0.25, hi=10.0),
            "comp_repulsion_scale": scale(dr, 2.5, lo=0.25, hi=10.0),
            "duplicate_penalty_scale": scale(dr, 1.5, lo=0.25, hi=5.0),

            # M: communication intensity
            "fetch_every_scale": scale(-dm, 1.2),
            "max_buffer_scale": scale(-dm, 1.2),
            "exchange_intensity_scale": scale(dm, 1.5),
        }

    @staticmethod
    def _clip(value: float) -> float:
        return float(np.clip(value, 0.0, 1.0))


# ---------------------------------------------------------------------------
# Nash-adaptive communication policy
# ---------------------------------------------------------------------------
try:
    from sage_lib.partition.Partition import Partition
except ImportError:
    class Partition:  # type: ignore[no-redef]
        """Dummy Partition class for non-structural applications."""
        def __init__(self, *args, **kwargs):
            self.containers = []
        def add_container(self, buffer):
            self.containers.extend(buffer)
        def export_files(self, *args, **kwargs):
            pass
        def read_files(self, *args, **kwargs):
            pass
        @property
        def size(self):
            return len(self.containers)

from ezga.core.interfaces import IAgent


class NashCommunicationPolicy:
    """
    Continuous, Nash-inspired communication controller for Agentic_Sync.

    ----------------------------------------------------------------------
    Overview
    ----------------------------------------------------------------------
    Each agent wants to communicate aggressively (high publication + fetch)
    because this maximises information flow. However, aggressive collective
    behaviour saturates the shared filesystem, creating contention that harms
    all workers.

    This tension is naturally described as a non-cooperative game:
        - Utility ↑ with more communication (information gain)
        - Utility ↓ with global pressure (contention)
        - Utility ↓ with imbalance between exploration (diversity) and I/O load

    Instead of computing discrete Nash equilibria, we define a *continuous,
    differentiable utility proxy* that produces a communication factor:

        c ∈ [0, 1]

    interpreted as:
        c = 1 → maximal communication
        c = 0 → minimal communication

    The policy is designed to be:
        • aggressive by default
        • stable under oscillations
        • strongly reactive to filesystem pressure
        • weakly shaped by structural diversity
        • extremely cheap to compute (O(1))

    ----------------------------------------------------------------------
    Mathematical Logic
    ----------------------------------------------------------------------
    Let:

        D = smoothed_diversity
        P = smoothed_pressure

    Define utility:

        U = w_div * D           (diversity encourages communication)
          - w_pre * P           (pressure discourages communication)
          - w_cost * |D - P|    (penalises imbalance between exploration & I/O)

    Then communication factor:

        c = sigmoid( U / scale )

    And smoothed:

        c_t = α * c + (1-α) * c_{t-1}

    ----------------------------------------------------------------------
    Translation to Agentic parameters
    ----------------------------------------------------------------------
    Using the final `c`, the policy computes:

        max_buffer = B_min + (B_max - B_min) * (1 - c)
        fetch_every = F_min + (F_max - F_min) * (1 - c)

    These are **returned** to Agentic_Sync so it can update itself.

    ----------------------------------------------------------------------
    Public API
    ----------------------------------------------------------------------
    update_metrics(diversity, pressure)
        → feeds new measurements into the smoothed state

    communication_factor()
        → returns c ∈ [0,1]

    map_to_agentic_parameters()
        → returns (max_buffer, fetch_every)

    This makes the policy fully modular and removes mapping logic from
    Agentic_Sync entirely.
    """

    # ------------------------------------------------------------------
    # Constructor
    # ------------------------------------------------------------------

    def __init__(
        self,
        *,
        smooth_alpha: float = 0.25,  # stable, low-noise smoothing
        div_weight: float = 1.0,  # diversity pushes communication ↑
        pressure_weight: float = 6.0,  # pressure pushes communication ↓
        cost_weight: float = 0.5,  # stabilizes oscillations
        scale: float = 12.0,  # soft sigmoid scale
        buffer_range: tuple[int, int] = (4, 16),
        fetch_range: tuple[int, int] = (5, 16),
    ):
        # --- smoothing ------------------------------------------------------
        self.alpha = smooth_alpha

        # --- weights --------------------------------------------------------
        self.div_w = div_weight
        self.pressure_w = pressure_weight
        self.cost_w = cost_weight

        # --- sigmoid scaling ------------------------------------------------
        self.scale = scale

        # --- mapping ranges --------------------------------------------------
        self.buffer_range = tuple(buffer_range)
        self.fetch_range = tuple(fetch_range)

        # --- internal state --------------------------------------------------
        self.s_div = 0.0
        self.s_pressure = 0.0
        self.prev_c = 1.0  # start aggressively
        self._pub_mode = "eager"
        self._fetch_mode = "eager"

        # --- evolutionary adaptation state ---
        self.stall_gens = 0
        self.novelty_rate = 0.0
        self.success_rate = 0.0
        self.duplicate_rate = 0.0
        self.acceptance_rate = 0.0
        self.progress_rate = 0.0
        self.objective_volatility = 0.0
        self.exploration_without_progress = 0.0
        self.premature_convergence_risk = 0.0
        self.improvement_magnitude_rate = 0.0
        self.relative_improvement_rate = 0.0

    # ----------------------------------------------------------------------
    def update_metrics(self, local_diversity: float, global_pressure: float):
        """
        Smooth both metrics.  The pressure is expected to be in the range
        [0..2000] in practice; we internally normalise it with tanh.
        """
        # normalise pressure to [0,1]
        P = np.tanh(global_pressure / 5000.0)

        # exponential smoothing
        self.s_div = self.alpha * local_diversity + (1 - self.alpha) * self.s_div
        self.s_pressure = self.alpha * P + (1 - self.alpha) * self.s_pressure

    # ----------------------------------------------------------------------
    def communication_factor(self) -> float:
        """
        Compute c ∈ [0,1], the Nash-like communication intensity.

            high diversity   → push c up  (share faster)
            high pressure    → push c down (slow down)
            mismatch cost    → stabilises oscillation

        This avoids discrete jumps and keeps the dynamics smooth.
        """

        # linear combination
        raw = (
            self.div_w * self.s_div
            - self.pressure_w * self.s_pressure
            - self.cost_w * abs(self.s_div - self.s_pressure)
        )

        # smooth decision function
        c = 1.0 / (1.0 + np.exp(-raw / self.scale))

        # smoothed output
        c = self.alpha * c + (1 - self.alpha) * self.prev_c
        self.prev_c = c

        return float(c)

    # ----------------------------------------------------------------------
    def map_to_agentic_parameters(self) -> tuple[int, int]:
        """
        Convert c → operational backend parameters.

        High c → small buffer, frequent fetch.
        Low c  → large buffer, delayed fetch.
        """
        c = self.communication_factor()

        # 1. Publication Hysteresis
        if c > 0.70:
            self._pub_mode = "eager"
        elif c < 0.35:
            self._pub_mode = "lazy"

        # 2. Fetch Hysteresis
        if c > 0.70:
            self._fetch_mode = "eager"
        elif c < 0.35:
            self._fetch_mode = "lazy"

        buf_min, buf_max = self.buffer_range
        fetch_min, fetch_max = self.fetch_range

        # Eager: high frequency (min values), Lazy: low frequency (max values)
        max_buffer = buf_min if self._pub_mode == "eager" else buf_max
        fetch_every = fetch_min if self._fetch_mode == "eager" else fetch_max

        return max(1, max_buffer), max(1, fetch_every)

    def update_social_context(self, neighbors: list[dict]):
        """
        Adjust weights or scales based on neighbor policies.

        This implements a simple consensus-driven adaptation:
        1. If collective pressure is high, increase local pressure sensitivity.
        2. If collective diversity is low, increase local diversity sensitivity.
        """
        if not neighbors:
            return

        # 1. Collective Pressure Adaptation
        neighbor_pressures = [n.get("metrics", {}).get("pressure", 0.0) for n in neighbors]
        avg_pressure = float(np.mean(neighbor_pressures)) if neighbor_pressures else self.s_pressure

        # If neighbors see more pressure, be more cautious
        if avg_pressure > self.s_pressure:
            self.pressure_w = min(20.0, self.pressure_w * 1.1)
        else:
            self.pressure_w = max(1.0, self.pressure_w * 0.9)

        # 2. Collective Diversity Adaptation
        neighbor_diversities = [n.get("metrics", {}).get("diversity", 0.0) for n in neighbors]
        avg_div = float(np.mean(neighbor_diversities)) if neighbor_diversities else self.s_div

        # If neighbors see less diversity, push harder to share
        if avg_div < self.s_div:
            self.div_w = min(10.0, self.div_w * 1.1)
        else:
            self.div_w = max(0.5, self.div_w * 0.9)

    def compute_evolutionary_adjustments(self, neighbors: list[dict]) -> dict:
        """
        Compute suggested changes for evolutionary components based on collective state.
        
        Returns a dict of parameter offsets or new values.
        """
        if not neighbors:
            return {}
            
        adjustments = {}
        
        # 1. Collective Stagnation -> Reheating
        avg_stall = np.mean([n.get("metrics", {}).get("stall_gens", 0) for n in neighbors])
        if avg_stall > 5:
            # Everyone is stalled! Increase exploration.
            adjustments["mutation_rate_factor"] = 1.2
            adjustments["repulsion_boost"] = 0.5
            adjustments["stall_offset_boost"] = 50.0  # Bump thermostat
            adjustments["crossover_boost"] = 0.1      # More mixing
        
        # 2. Collective Novelty Check
        avg_novelty = np.mean([n.get("metrics", {}).get("novelty_rate", 0.0) for n in neighbors])
        if avg_novelty < 0.05:
            # Low collective novelty, favor diverse candidates
            adjustments["repulsion_boost"] = adjustments.get("repulsion_boost", 0.0) + 0.3
            adjustments["mutation_rate_factor"] = adjustments.get("mutation_rate_factor", 1.0) * 1.1
            
        return adjustments


# ---------------------------------------------------------------------------
# Agentic_Sync
# ---------------------------------------------------------------------------


class Agentic_Sync(IAgent):
    """Batch‑exchange backend with *content‑addressed folders*.

    Parameters
    ----------
    shared_dir : str | Path
        Root directory on a shared filesystem where batches will be written.
    shard_width : int, default=2
        Number of leading hex digits of the digest used as sharding sub‑folder.
    max_buffer : int, default=8
        Flush automatically once this many objects have been appended.
    max_retained : int, optional
        Keep at most this many batch folders on disk (oldest are deleted).
        ``None`` disables pruning.
    persist_seen : bool, default=True
        Persist the *seen* index (``seen.json``) so a crash/restart does not
        re‑process the same batches.
    poll_interval : float, default=2.0
        Seconds between polls inside :meth:`watch` (exposed for future use).
    auto_publish : bool, default=True
        If *True*, :meth:`append` flushes automatically once ``max_buffer`` is
        reached.
    hash_name : str, default="sha256"
        Digest algorithm recognised by :pymod:`hashlib`.
    """

    _SEEN_FILE = "seen.json"
    MAX_TRANSFER_LIMIT = 200

    # ------------------------------------------------------------
    # Construction helpers
    # ------------------------------------------------------------
    def __init__(
        self,
        *,
        shared_dir: str | Path,
        shard_width: int = 2,
        max_buffer: int = 4,
        max_retained: int | None = None,
        persist_seen: bool = True,
        poll_interval: float = 2.0,
        auto_publish: bool = True,
        hash_name: str = "sha256",
        fetch_every: int = 5,
        import_limit: int | None = None,
        strategy: str = "balanced",
        adaptive: bool = True,
        id: str | None = None,
        adaptive_policy: Any = None,
        local_dir: str | Path | None = None,
        max_transfer_limit: int | None = None,
    ) -> None:
        # --- evolutionary adaptation state ---
        self.evolution_policy = ReducedAdaptiveController(
            initial_strategy=strategy, 
            config=adaptive_policy
        )
        self.id = id or str(uuid.uuid4())[:8]
        self.adaptive = adaptive
        
        # ── 0. local directory (for logs and private state) ───────────────────
        self.local_root = Path(local_dir or ".").expanduser().resolve()
        self.local_root.mkdir(parents=True, exist_ok=True)

        # ── 1. root directory (try–convert) ───────────────────────────────────
        self.root: Path | None = None
        try:
            self.root = Path(shared_dir).expanduser().resolve()
            self.root.mkdir(parents=True, exist_ok=True)
        except (TypeError, AttributeError, OSError):
            # Any failure ⇒ disable backend (is_active → False)
            self.root = None

        # ── 2. hash-algorithm resolver / aliases ──────────────────────────────
        alias = {"hash": "sha256", "sha": "sha256", "sha256": "sha256", "md5": "md5"}
        algo = alias.get(hash_name.lower().strip(), hash_name.lower().strip())

        if algo not in hashlib.algorithms_available:
            raise ValueError(
                f"Unsupported hash algorithm '{hash_name}'. "
                f"Available: {', '.join(sorted(hashlib.algorithms_available))}"
            )
        self._hash_name = hash_name

        # ── 3. misc configuration ─────────────────────────────────────────────
        self.shard_width = max(0, shard_width)
        self._max_buffer = max(1, max_buffer)
        self._max_retained = max_retained
        self.poll_interval = poll_interval
        self.auto_publish = auto_publish
        self._default_fetch_limit = import_limit
        self.max_transfer_limit = max_transfer_limit or self.MAX_TRANSFER_LIMIT

        self._fetch_counter = 0
        self._fetch_every = max(1, fetch_every)

        self._buffer: list[Any] = []
        self._lock = RLock()

        # ── 4. seen-index handling ────────────────────────────────────────────
        self._persist_seen = persist_seen
        
        # We always keep logs and seen-index in the local directory
        agent_state_dir = self.local_root / "agent_state"
        agent_state_dir.mkdir(parents=True, exist_ok=True)
        self._seen_path = agent_state_dir / self._SEEN_FILE
        
        # Initialize Logger for the agent state (Local)
        from ezga.utils.logger import WorkflowLogger
        self.logger = WorkflowLogger(output_path=str(agent_state_dir))
        self.logger.init_metadata(stage=f"Agent {self.id} tracking")
        
        # Instance-specific buffer
        self._last_metrics: dict[str, float] = {}
        self._current_generation: int = 0
        
        # State tracking for adaptive swarm
        self._comm_policy = NashCommunicationPolicy()
        
        if self.root:
            self.root.mkdir(parents=True, exist_ok=True)
            logger.info(f"[Agentic_Sync] Initialized with shared_dir: {self.root}")
        else:
            logger.warning("[Agentic_Sync] No shared_dir provided. Global exchange is DISABLED.")

        self._seen: dict[str, int] = self._load_seen() if self._seen_path else {}

        # Time‑tracking for watch()/append()
        self._last_flush = time.monotonic()

        # store metrics (population updates these)
        self._metric_diversity = 0.0
        self._metric_pressure = 0.0
        self._neighbor_states: dict[str, dict] = {}
        self._current_effective_parameters: dict[str, float] = {}

    # ------------------------------------------------------------
    # Runtime status helpers
    # ------------------------------------------------------------
    def is_active(self) -> bool:  # noqa: D401 – keep simple name
        """Return ``True`` when the backend is ready to use.

        The check is simple and fast – we confirm that the *root* directory
        exists **and** is writable.  External components can therefore call
        either :meth:`is_active` or its alias :meth:`active` as a lightweight
        guard before interacting with the instance.
        """
        return self.root is not None and self.root.is_dir() and os.access(self.root, os.W_OK)

    # Backward‑compatibility alias
    active = is_active

    # ------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------
    def append(self, obj: Any) -> bool:
        """Stage *obj* into the in‑memory buffer.

        Returns ``True`` if the call triggered an automatic flush.
        """
        with self._lock:
            if isinstance(obj, list):
                self._buffer.extend(obj)
            else:
                self._buffer.append(obj)

            auto = False
            if self.auto_publish and len(self._buffer) >= self._max_buffer:
                self.flush()
                auto = True
            return auto

    def flush(self) -> list[Any]:
        """Flush the agent buffer and return new structures."""
        with self._lock:
            if not self._buffer:
                return []

            # 1. Local Logging (Policy Tracking)
            if hasattr(self, "logger") and self.logger:
                for obj in self._buffer:
                    # ONLY log the policy state, NOT the atomic structures
                    if isinstance(obj, dict) and "policy_vector" in obj:
                        self.logger.log_agent_state(obj)
                    else:
                        # Create a clean metadata snapshot for this generation
                        z = self.evolution_policy.z
                        meta = {
                            "schema_version": 2,
                            "agent_id": self.id,
                            "generation": self._current_generation,
                            "timestamp": time.time(),
                            "policy_vector": {"X": float(z[0]), "R": float(z[1]), "M": float(z[2])},
                            "policy_modifiers": self.evolution_policy.map_to_modifiers(),
                            "effective_parameters": self._current_effective_parameters,
                            "metrics": self._last_metrics.copy() if hasattr(self, "_last_metrics") else {}
                        }
                        self.logger.log_agent_state(meta)

            # 2. Network Publication
            _ = self._publish_generation(self._buffer)
            
            flushed_objs = list(self._buffer)
            self._buffer.clear()
            self._last_flush = time.monotonic()
            return flushed_objs

    @property
    def policy_status(self) -> str:
        """Return a human-readable status of the current policy."""
        z = self.evolution_policy.z
        return f"X:{z[0]:.2f} R:{z[1]:.2f} M:{z[2]:.2f}"

    def get_batch(
        self,
        prune: bool = True,
        *,
        sleep: float | None = None,
        fetch_limit: int | None = None,
        **kwargs: Any,
    ) -> Iterator[Any]:
        """
        Yield unseen (batch_id, payload) pairs.

        Parameters
        ----------
        prune : bool, default=True
            Prune according to max_retained after each scan.
        sleep : float | None
            Optional sleep between polling iterations.
        fetch_limit : int | None
            Upper bound on the **sum of payload.size** across yielded batches
            in this call. If None, unlimited. Batches are not split.
        """

        # --- Throttle scans --------------------------------------------------
        self._fetch_counter = (self._fetch_counter + 1) % self._fetch_every

        if self._fetch_counter:
            if sleep is not None:
                time.sleep(sleep)
            return  # empty generator (no scan this turn)

        # resolve effective limit (prioritize specific requests but cap with global max_transfer_limit)
        requested_limit = fetch_limit if fetch_limit is not None else self._default_fetch_limit
        if requested_limit is None:
            eff_limit = self.max_transfer_limit
        else:
            eff_limit = min(int(requested_limit), self.max_transfer_limit)

        try:
            eff_limit = max(0, int(eff_limit))
        except (TypeError, ValueError):
            eff_limit = self.max_transfer_limit

        self._fetch_counter = 0
        # DO NOT clear _neighbor_states here to persist them across stagnated generations

        # Load global neighbor states from dedicated state files for maximum real-time fidelity
        if self.root and self.root.exists():
            for state_file in self.root.glob("agent_state_*.json"):
                try:
                    fname = state_file.name
                    if fname.startswith("agent_state_") and fname.endswith(".json"):
                        state_data = json.loads(state_file.read_text())
                        agent_id = state_data.get("agent_id")
                        if agent_id and agent_id != self.id:
                            existing = self._neighbor_states.get(agent_id, {})
                            if state_data.get("timestamp", 0) >= existing.get("timestamp", 0):
                                self._neighbor_states[agent_id] = state_data
                except Exception:
                    pass

        yielded_structs = 0
        while True:
            for batch_path in self._discover_batches():
                if eff_limit is not None and yielded_structs >= eff_limit:
                    break

                batch_id = batch_path.name

                if batch_id in self._seen:
                    continue

                # Read agent state if available (done before _seen check so states are kept updated robustly)
                state = self._read_agent_state(batch_path)
                if state and state.get("agent_id") != self.id:
                    agent_id = state.get("agent_id")
                    if agent_id:
                        # Only update if newer (prevents regressions if batches read out of order)
                        existing = self._neighbor_states.get(agent_id, {})
                        if state.get("timestamp", 0) >= existing.get("timestamp", 0):
                            self._neighbor_states[agent_id] = state

                try:
                    payload = self._read_partition(batch_path)
                except FileNotFoundError:
                    # Directory vanished between discovery and read → skip silently
                    continue
                except Exception as exc:
                    # Optional: log and continue, in case Partition raises something else
                    print("[HashBatchSync] read failed:", exc)
                    continue

                # authoritative per-batch count
                try:
                    n_in_batch = int(payload.size)
                except Exception:
                    n_in_batch = len(getattr(payload, "containers", []))

                # do NOT split a batch; stop before exceeding the cap
                # Exit outer loop if limit reached or no polling requested
                if eff_limit is not None and yielded_structs + n_in_batch > eff_limit:
                    break

                self._seen[batch_id] = int(time.time())
                self._save_seen()
                yielded_structs += n_in_batch
                yield batch_id, payload

            # --- Prune once per scan ---------------------------------------
            if prune:
                self._prune_old()

            if sleep is None:
                break
            time.sleep(sleep)

    def update_policy_metrics(self, diversity: float, pressure: float, **kwargs: Any) -> None:
        """Concrete implementation of update_policy_metrics to consume diversity, pressure, and arbitrary metrics."""
        self._metric_diversity = diversity
        self._metric_pressure = pressure
        self._last_metrics.update({
            "diversity": diversity,
            "pressure": pressure,
        })
        self._last_metrics.update(kwargs)
        self._comm_policy.update_metrics(diversity, pressure)

    def set_metrics(self, generation: int, metrics: dict[str, float]):
        """Inject current GA metrics for policy adaptation."""
        self._current_generation = generation
        self._last_metrics = metrics
        
        # Extract diversity and pressure for communication policy
        self._metric_diversity = metrics.get("diversity", 0.0)
        self._metric_pressure = metrics.get("pressure", 0.0)

    def update_behaviour(self, population: Any, ctx: Any) -> bool:
        """Main adaptive loop: extracts signals from Context and triggers policy update."""
        # 0. Extract high-fidelity metrics from ConvergenceSignals
        metrics = {}
        if ctx and hasattr(ctx, "convergence") and hasattr(ctx.convergence, "signals"):
            signals = ctx.convergence.signals
            
            metrics = {
                "stall_gens": float(getattr(ctx, "stagnation", 0)),
                "acceptance_rate": float(getattr(signals, "acceptance_rate", 0.0)),
                "progress_rate": float(getattr(signals, "progress_rate", 0.0)),
                "novelty_rate": float(getattr(signals, "novelty_rate", getattr(signals, "discovery_rate", 0.0))),
                "duplicate_rate": float(getattr(signals, "duplicate_rate", 0.0)),
                "objective_volatility": float(getattr(signals, "objective_volatility", 0.0)),
                "exploration_without_progress": float(getattr(signals, "exploration_without_progress", 0.0)),
                "premature_convergence_risk": float(getattr(signals, "premature_convergence_risk", 0.0)),
                "improvement_magnitude_rate": float(getattr(signals, "improvement_magnitude_rate", 0.0)),
                "relative_improvement_rate": float(getattr(signals, "relative_improvement_rate", 0.0)),
            }
            # Calculate composite metrics
            metrics["success_rate"] = metrics["acceptance_rate"] * metrics["progress_rate"]
            self._last_metrics = metrics.copy()

            if hasattr(ctx, "generation"):
                self._current_generation = ctx.generation

        # 1. Adapt communication policy (Nash-inspired)
        neighbor_list = list(self._neighbor_states.values())
        if neighbor_list:
            self._comm_policy.update_social_context(neighbor_list)
            
        # Update metrics for communication policy
        self._comm_policy.update_metrics(
            local_diversity=self._metric_diversity,
            global_pressure=self._metric_pressure,
        )
        
        # Apply communication decisions (Nash sets the dynamic baseline based on filesystem load)
        new_buffer, new_fetch = self._comm_policy.map_to_agentic_parameters()
        self._comm_baselines = {
            "fetch_every": new_fetch,
            "max_buffer": new_buffer,
        }
            
        # 2. Adapt evolutionary policy (XRM Controller)
        if self.adaptive and metrics:
            self.evolution_policy.update_policy(neighbor_list, metrics)
            z = self.evolution_policy.z
            logger.info("[Agentic_Sync] Policy updated. XRM vector: [X:%.2f, R:%.2f, M:%.2f]", z[0], z[1], z[2])
            targets = self.evolution_policy.map_to_modifiers()
            self._apply_evolutionary_adjustments(ctx, targets)
            
        self._write_global_agent_state()
            
        return True

    def _apply_evolutionary_adjustments(self, ctx: Any, targets: dict):
        """Apply target scaling modifiers smoothly to active GA components based on baseline values."""
        if not targets:
            return

        # 1. Lazy-initialize baseline values on first application
        if not hasattr(self, "_baselines"):
            self._baselines = {}
            if ctx and hasattr(ctx, "shared_state"):
                selector = ctx.shared_state.get("selector")
                if selector:
                    self._baselines["repulsion"] = float(getattr(selector, "repulsion_weight", 1.0))
                    self._baselines["comp_repulsion"] = float(getattr(selector, "composition_repulsion_weight", 0.0))
                    self._baselines["steepness"] = float(getattr(selector, "steepness", 10.0))
                    self._baselines["sampling_temp"] = float(getattr(selector, "sampling_temperature", 1.0))
                    self._baselines["selection_size"] = int(getattr(selector, "size", 10))
                
                variation = ctx.shared_state.get("variation")
                if variation:
                    self._baselines["mutation_rate"] = float(getattr(variation, "_initial_mutation_rate", 1.0))
                    self._baselines["crossover"] = float(getattr(variation, "_crossover_probability", 0.1))

                thermostat = ctx.shared_state.get("thermostat")
                if thermostat:
                    self._baselines["obj_temp"] = float(getattr(thermostat, "objective_temperature", 1.0))

            # Communication baselines from agent's own initial state
            self._baselines["fetch_every"] = int(getattr(self, "_fetch_every", 5))
            self._baselines["max_buffer"] = int(getattr(self, "_max_buffer", 4))

        if ctx and hasattr(ctx, "shared_state"):
            # Adapt Selector (Repulsion and Pressure)
            selector = ctx.shared_state.get("selector")
            if selector:
                if "repulsion_scale" in targets and "repulsion" in self._baselines:
                    selector.repulsion_weight = float(max(0.0, self._baselines["repulsion"] * targets["repulsion_scale"]))
                if "comp_repulsion_scale" in targets and "comp_repulsion" in self._baselines:
                    selector.composition_repulsion_weight = float(max(0.0, self._baselines["comp_repulsion"] * targets["comp_repulsion_scale"]))
                if "steepness_scale" in targets and "steepness" in self._baselines:
                    selector.steepness = float(np.clip(self._baselines["steepness"] * targets["steepness_scale"], 1.0, 100.0))
                if "sampling_temp_scale" in targets and "sampling_temp" in self._baselines:
                    selector.sampling_temperature = float(np.clip(self._baselines["sampling_temp"] * targets["sampling_temp_scale"], 0.05, 10.0))
                if "selection_size_scale" in targets and "selection_size" in self._baselines:
                    is_ensemble = ctx and getattr(ctx, "ensemble_cfg", None) is not None and getattr(ctx.ensemble_cfg, "kind", "none") != "none"
                    if not is_ensemble:
                        # Enforce selection size limit of at least 10% of original/baseline value, and at least 2 (non-negative)
                        min_size = max(2, int(round(self._baselines["selection_size"] * 0.1)))
                        selector.size = int(max(min_size, int(round(self._baselines["selection_size"] * targets["selection_size_scale"]))))
    
            # Adapt Variation (Mutation Rate and Crossover)
            variation = ctx.shared_state.get("variation")
            if variation:
                if "mutation_rate_scale" in targets and "mutation_rate" in self._baselines:
                    # Enforce lowest mutation rate is 1.0, and check for negative values
                    variation._initial_mutation_rate = float(max(1.0, self._baselines["mutation_rate"] * targets["mutation_rate_scale"]))
                if "crossover_scale" in targets and "crossover" in self._baselines:
                    variation._crossover_probability = float(np.clip(self._baselines["crossover"] * targets["crossover_scale"], 0.0, 1.0))
    
            # Adapt Thermostat (Temperature and Reheating)
            thermostat = ctx.shared_state.get("thermostat")
            if thermostat:
                 if "obj_temp_scale" in targets and "obj_temp" in self._baselines:
                      thermostat.objective_temperature = float(np.clip(self._baselines["obj_temp"] * targets["obj_temp_scale"], 0.05, 10.0))

        # Adapt Communication (XRM scales relative to the dynamic Nash filesystem baseline)
        if "fetch_every_scale" in targets:
            base_fetch = self._comm_baselines.get("fetch_every") if hasattr(self, "_comm_baselines") else self._baselines["fetch_every"]
            self._fetch_every = int(max(1, int(round(base_fetch * targets["fetch_every_scale"]))))
        if "max_buffer_scale" in targets:
            base_buffer = self._comm_baselines.get("max_buffer") if hasattr(self, "_comm_baselines") else self._baselines["max_buffer"]
            self._max_buffer = int(max(1, int(round(base_buffer * targets["max_buffer_scale"]))))

        # Populate current effective parameters dynamically from active component states
        if ctx and hasattr(ctx, "shared_state"):
            selector = ctx.shared_state.get("selector")
            variation = ctx.shared_state.get("variation")
            thermostat = ctx.shared_state.get("thermostat")
            self._current_effective_parameters = {
                "mutation_rate": float(getattr(variation, "_initial_mutation_rate", self._baselines.get("mutation_rate", 1.0)) if variation else 1.0),
                "crossover": float(getattr(variation, "_crossover_probability", self._baselines.get("crossover", 0.1)) if variation else 0.1),
                "repulsion": float(getattr(selector, "repulsion_weight", self._baselines.get("repulsion", 1.0)) if selector else 1.0),
                "comp_repulsion": float(getattr(selector, "composition_repulsion_weight", self._baselines.get("comp_repulsion", 0.0)) if selector else 0.0),
                "steepness": float(getattr(selector, "steepness", self._baselines.get("steepness", 10.0)) if selector else 10.0),
                "sampling_temp": float(getattr(selector, "sampling_temperature", self._baselines.get("sampling_temp", 1.0)) if selector else 1.0),
                "selection_size": int(getattr(selector, "size", self._baselines.get("selection_size", 10)) if selector else 10),
                "obj_temp": float(getattr(thermostat, "objective_temperature", self._baselines.get("obj_temp", 1.0)) if thermostat else 1.0),
                "fetch_every": int(self._fetch_every),
                "max_buffer": int(self._max_buffer),
            }

    # ------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------
    def _publish_generation(self, buffer: list[Any]) -> str:
        """Write *buffer* to a newly created sharded directory."""
        if self.root is None:
            raise RuntimeError("AgenticSync root is not initialized.")
            
        if len(buffer) > self.max_transfer_limit:
            buffer = buffer[:self.max_transfer_limit]
            
        digest = self._hash_object_list(buffer)
        shard = digest[: self.shard_width] if self.shard_width else ""
        final_dir = self.root / shard / digest
        tmp_dir = self.root / shard / f".tmp_{digest}_{self.id}"

        if not final_dir.exists():
            tmp_dir.mkdir(parents=True, exist_ok=True)
            part = Partition()
            part.add_container(buffer)
            part.export_files(
                file_location=str(tmp_dir),
                source="xyz",
                label="enumerate",
                verbose=False,
            )
            self._write_agent_state(tmp_dir)
            
            ready_file = tmp_dir / "_READY"
            ready_file.write_text("ok")
            
            try:
                if hasattr(tmp_dir, "replace"):
                    tmp_dir.replace(final_dir)
                else:
                    os.rename(tmp_dir, final_dir)
            except OSError:
                if tmp_dir.exists():
                    shutil.rmtree(tmp_dir, ignore_errors=True)
                    
        if digest not in self._seen:
            self._seen[digest] = int(time.time())
            self._save_seen()
        return digest


    def _discover_batches(self) -> list[Path]:
        """Return existing batch folders (oldest → newest), robust to concurrent FS changes.

        We avoid recursive globbing and guard every FS touch so directories that
        disappear mid-scan are treated as benign.
        """
        candidates: list[tuple[float, Path]] = []
        root = self.root
        if not root or not root.exists():
            return []

        with self._lock:
            # 1) list shards (or the root itself if shard_width==0)
            try:
                if self.shard_width > 0:
                    try:
                        shards = [p for p in root.iterdir() if p.is_dir()]
                    except (FileNotFoundError, PermissionError, OSError):
                        shards = []
                    w = int(self.shard_width)
                    shards = [
                        s for s in shards if len(s.name) == w and all(c in "0123456789abcdef" for c in s.name.lower())
                    ]
                else:
                    shards = [root]
            except (FileNotFoundError, PermissionError, OSError):
                shards = []

            # 2) list candidate batch dirs inside each shard
            for shard in shards:
                try:
                    entries = list(shard.iterdir())
                except (FileNotFoundError, PermissionError, OSError):
                    continue

                for batch in entries:
                    try:
                        if not batch.is_dir():
                            continue
                        name = batch.name
                        if len(name) != 64 or not all(c in "0123456789abcdef" for c in name.lower()):
                            continue
                        try:
                            mtime = batch.stat().st_mtime
                        except FileNotFoundError:
                            continue
                        candidates.append((mtime, batch))
                    except (FileNotFoundError, PermissionError, OSError):
                        continue

        candidates.sort(key=lambda t: t[0])  # oldest → newest
        return [p for _, p in candidates]

    def _read_partition(self, batch_path: Path) -> Any:
        """Load data from *batch_path* via Partition.read_files."""
        part = Partition()
        part.read_files(
            file_location=os.path.join(batch_path, "config.xyz"),
            source="xyz",
            verbose=False,
        )
        return part  # You may want to return part.containers[0] or similar

    def _write_agent_state(self, batch_dir: Path) -> None:
        """Write current agent state to the batch directory."""
        state_file = batch_dir / "agent_state.json"
        
        state_data = {
            "schema_version": 2,
            "agent_id": self.id,
            "generation": getattr(self, "_current_generation", 0),
            "timestamp": time.time(),
            "communication": {
                "c": self._comm_policy.prev_c,
                "max_buffer": self._max_buffer,
                "fetch_every": self._fetch_every,
            },
            "metrics": self._last_metrics.copy() if hasattr(self, "_last_metrics") else {},
            "policy_vector": self.evolution_policy.vector_dict,
            "policy_modifiers": self.evolution_policy.map_to_modifiers(),
            "effective_parameters": self._current_effective_parameters,
        }
        try:
            state_file.write_text(json.dumps(state_data, indent=2))
        except Exception as exc:
            print(f"[AgenticSync] Failed to write agent state: {exc}")

        # Also append to global policy history log using the state logger
        if self.logger:
            
            history_entry = {
                "schema_version": 2,
                "agent_id": self.id,
                "generation": state_data["generation"],
                "timestamp": state_data["timestamp"],
                "policy_vector": state_data["policy_vector"],
                "policy_modifiers": state_data["policy_modifiers"],
                "effective_parameters": state_data["effective_parameters"],
                "communication": state_data["communication"],
                "metrics": state_data["metrics"]
            }
            self.logger.log_agent_state(history_entry)

    def _write_global_agent_state(self) -> None:
        """Write current agent state to a global, dedicated agent state file in the shared directory."""
        if not self.root or not self.root.exists():
            return
        
        state_data = {
            "schema_version": 2,
            "agent_id": self.id,
            "generation": getattr(self, "_current_generation", 0),
            "timestamp": time.time(),
            "communication": {
                "c": self._comm_policy.prev_c,
                "max_buffer": self._max_buffer,
                "fetch_every": self._fetch_every,
            },
            "metrics": self._last_metrics.copy() if hasattr(self, "_last_metrics") else {},
            "policy_vector": self.evolution_policy.vector_dict,
            "policy_modifiers": self.evolution_policy.map_to_modifiers(),
            "effective_parameters": self._current_effective_parameters,
        }
        state_file = self.root / f"agent_state_{self.id}.json"
        
        tmp_file = self.root / f".tmp_agent_state_{self.id}.json"
        try:
            tmp_file.write_text(json.dumps(state_data, indent=2))
            tmp_file.replace(state_file)
        except Exception as exc:
            try:
                if tmp_file.exists():
                    tmp_file.unlink()
            except Exception:
                pass
            print(f"[AgenticSync] Failed to write global agent state: {exc}")

    def _read_agent_state(self, batch_path: Path) -> dict | None:
        """Read agent state from a batch directory."""
        state_file = batch_path / "agent_state.json"
        if state_file.exists():
            try:
                return cast(dict[Any, Any], json.loads(state_file.read_text()))
            except Exception:
                return None
        return None

    # ---------------- Seen‑index persistence --------------------
    def _load_seen(self) -> dict[str, int]:
        if not self._persist_seen or self._seen_path is None or not self._seen_path.exists():
            return {}
        try:
            return cast(dict[str, int], json.loads(self._seen_path.read_text()))
        except Exception:
            return {}

    def _save_seen(self) -> None:
        if not self._persist_seen or self._seen_path is None:
            return

        tmp = self._seen_path.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(self._seen, indent=2))
            tmp.replace(self._seen_path)
        except OSError as exc:
            # Log but do not crash—seen index will be retried next call.
            print("[HashBatchSync] failed to write seen.json:", exc)

    # ---------------- House‑keeping helpers ---------------------
    # ---------------- Shard‑aware pruning -----------------------
    def _prune_old(self) -> None:
        """Delete *excess* oldest batches, **max one per shard** per cycle.

        This keeps I/O balanced across shard sub‑directories and eliminates the
        possibility of wiping an entire shard in one go.
        """
        if self._max_retained is None:
            return

        all_batches = self._discover_batches()  # already sorted by mtime
        excess = len(all_batches) - self._max_retained
        if excess < 1:
            return

        to_delete: list[Path] = []
        visited_shards: set[Path] = set()
        for path in all_batches:
            shard = path.parent
            if shard in visited_shards:
                continue  # already selected one from this shard this round
            to_delete.append(path)
            visited_shards.add(shard)
            if len(to_delete) == excess:
                break

        for path in to_delete:
            try:
                shutil.rmtree(path, ignore_errors=True)
            except FileNotFoundError:
                # Already gone – benign.
                continue
            except Exception as exc:
                print("[HashBatchSync] prune failed:", exc)
                continue

            # House‑keeping after successful delete
            self._seen.pop(path.name, None)
            parent = path.parent
            if parent != self.root:
                try:
                    parent.rmdir()  # deletes only if shard is empty
                except OSError:
                    # ENOENT, ENOTEMPTY, or any other benign OS error
                    # can be ignored safely
                    pass

    def attempt_prune(
        self,
        interval: float = 60.0,  # seconds between prune attempts
        budget: int = 8,  # max batch dirs to delete per call
        min_age: float = 5.0,  # do not delete if younger than this (seconds)
    ) -> int:
        """
        Perform a **bounded, race-tolerant pruning cycle** of old batch folders.

        This method implements a *best-effort garbage collection* strategy that
        removes only the **oldest and excess** batch directories, while ensuring
        filesystem safety under concurrent readers/writers.

        Deletion is **rate-limited**, **age-guarded**, and **shard-balanced** to
        avoid deleting freshly written data or overloading any particular subdirectory.

        ---------------------------------------------------------------------------
        Parameters
        ---------------------------------------------------------------------------
        interval : float, default=60.0
            Minimum elapsed time (in seconds) between consecutive prune attempts.
            The method will return immediately (without doing any work) if called
            again before `interval` seconds have passed since the previous execution.
            This throttling protects against excessive filesystem traversal during
            rapid batch production.

        budget : int, default=8
            Maximum number of batch directories to delete in a single pruning pass.
            Even if the number of excess batches greatly exceeds this value, the
            function will remove at most `budget` folders per call.  This bounds the
            I/O cost and improves fairness under concurrent workloads.

        min_age : float, default=5.0
            Minimum age (in seconds) of a batch directory required for eligibility.
            Directories younger than this threshold are **never deleted**, to prevent
            race conditions with in-flight write operations or recently published
            generations.  The age is computed as:

                age = time.time() - path.stat().st_mtime

        ---------------------------------------------------------------------------
        Returns
        ---------------------------------------------------------------------------
        int
            The number of batch directories successfully pruned during this call.

        ---------------------------------------------------------------------------
        Algorithmic steps
        ---------------------------------------------------------------------------
        1. **Throttle by interval**
           - Skip execution if less than `interval` seconds since `_last_prune`.
           - Record the timestamp of this pruning pass (`_last_prune = now`).

        2. **Check retention limit**
           - Gather all existing batch folders via `_discover_batches()`, which
             returns a list sorted from oldest → newest (by modification time).
           - Compute `excess = len(all_batches) - self._max_retained`.
           - If `excess <= 0`, nothing is deleted.

        3. **Iterate oldest → newest**
           - Traverse `all_batches` in ascending `mtime` order.
           - Apply the following filters for each candidate batch folder `path`:
             - *Shard fairness*: delete at most one per shard per cycle.
             - *Age guard*: skip if `mtime` is younger than `min_age` seconds.
             - *Budget*: stop once `pruned >= budget`.
           - Only when **all conditions** are satisfied will the folder be deleted.

        4. **Deletion**
           - Attempt `shutil.rmtree(path, ignore_errors=True)`.
           - On success, remove the corresponding entry from `self._seen`.
           - Attempt to remove the shard directory if now empty (`shard.rmdir()`).

        5. **Race tolerance**
           - All filesystem operations are wrapped in `try/except` to absorb
             benign race conditions (e.g. another process deleting the same folder).
           - Non-fatal errors are logged to stdout but do not interrupt execution.

        ---------------------------------------------------------------------------
        Safety guarantees
        ---------------------------------------------------------------------------
        * Newly created batches are protected by the `min_age` guard.
        * The method never prunes more than one batch per shard in a single pass.
        * The number of deletions per call is bounded by `budget`.
        * It will never run more often than every `interval` seconds.
        * No pruning occurs when `self._max_retained` is `None` or not exceeded.
        * Locks (`self._lock`) prevent concurrent mutation of shared state.

        ---------------------------------------------------------------------------
        Notes
        ---------------------------------------------------------------------------
        * The `self._seen` dictionary is updated (entries removed) but not persisted
          to disk until the next `_save_seen()` call.  To keep `seen.json` in sync,
          consider invoking `_save_seen()` after pruning.
        * The selection order is deterministic with respect to modification time;
          oldest eligible batches are always deleted first.
        * The function is safe for concurrent use by multiple workers sharing the
          same `shared_dir`, though each worker will redundantly scan the filesystem.

        ---------------------------------------------------------------------------
        Example
        ---------------------------------------------------------------------------
        >>> sync = Agentic_Sync(shared_dir="~/shared_batches", max_retained=20)
        >>> pruned = sync.attempt_prune(interval=30.0, budget=4, min_age=10.0)
        >>> print(f"Removed {pruned} obsolete batch folders.")
        """
        if self._max_retained is None:
            return 0

        now = time.monotonic()
        last = getattr(self, "_last_prune", 0.0)
        if now - last < interval:
            return 0

        with self._lock:
            self._last_prune = now

            all_batches = self._discover_batches()  # already sorted oldest → newest
            excess = len(all_batches) - self._max_retained
            if excess <= 0:
                return 0

            # Bound the amount of work we attempt this round
            target = min(excess, max(1, int(budget)))

            pruned = 0
            visited_shards: set[Path] = set()

            for path in all_batches:
                if pruned >= target:
                    break

                shard = path.parent
                if shard in visited_shards:
                    continue  # only 1 per shard per cycle

                # age filter: skip very new entries to avoid touching in-flight writes
                try:
                    if (time.time() - path.stat().st_mtime) < float(min_age):
                        continue
                except FileNotFoundError:
                    continue

                # attempt deletion
                try:
                    shutil.rmtree(path, ignore_errors=True)
                except FileNotFoundError:
                    # Already gone – benign.
                    continue
                except Exception as exc:
                    print("[HashBatchSync] prune failed:", exc)
                    continue

                # housekeeping after successful delete
                self._seen.pop(path.name, None)
                visited_shards.add(shard)
                pruned += 1

                # try to remove empty shard dir; ignore failures
                if shard != self.root:
                    try:
                        shard.rmdir()
                    except OSError:
                        pass

            return pruned

    # ---------------- Static utilities --------------------------
    def _hash_object_list(self, objs: Sequence[object]) -> str:
        payload = pickle.dumps(objs, protocol=4)
        digest = hashlib.new(self._hash_name)
        digest.update(payload)
        return digest.hexdigest()
