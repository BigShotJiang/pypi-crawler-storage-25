from __future__ import annotations
from enum import Enum
from pathlib import Path
from typing import Any, Optional, Sequence, Tuple, List, Dict, Union, Callable, Literal, Annotated, cast

from pydantic import (
    BaseModel,
    Field,
    PositiveInt,
    NonNegativeInt,
    field_validator,
    model_validator,
    ConfigDict,
)

# -----------------------------------------------------------------------------
# Common Type Aliases with Constrained Bounds
# -----------------------------------------------------------------------------
Prob = Annotated[float, Field(ge=0.0, le=1.0)]
"""Type alias for floating-point values constrained to probability range [0.0, 1.0]."""

NonNegFloat = Annotated[float, Field(ge=0.0)]
"""Type alias for non-negative floating-point values (>= 0.0)."""

PosFloat = Annotated[float, Field(gt=0.0)]
"""Type alias for strictly positive floating-point values (> 0.0)."""


# -----------------------------------------------------------------------------
# Enums
# -----------------------------------------------------------------------------
class SelectionMethod(str, Enum):
    """Supported selection methods for the Genetic Algorithm population.

    Determines how parent structures are selected for reproduction and survival.
    """
    BOLTZMANN = "boltzmann"
    """Standard Boltzmann/Gibbs distribution based on structure fitness."""
    
    BOLTZMANN_BIGDATA = "boltzmann_bigdata"
    """Optimized Boltzmann selection tailored for high-throughput database sweeps."""
    
    GREEDY = "greedy"
    """Elitist selection favoring only the best-performing structures."""
    
    ROULETTE = "roulette"
    """Fitness-proportionate selection (Roulette Wheel)."""
    
    TOURNAMENT = "tournament"
    """Tournament selection among random subsets of structures."""
    
    NSGA3 = "nsga3"
    """Non-dominated Sorting Genetic Algorithm III for multi-objective optimization with reference points."""
    
    NS = "nondominated_sorted"
    """Standard NSGA-II non-dominated sorting selection."""
    
    TRAJECTORY = "trajectory"
    """Sequential ensemble trajectory-based sampling (deactivates normal GA selection)."""

    PARETO_BOLTZMANN = "pareto_boltzmann"
    """Multi-objective Pareto-distance based Boltzmann selection."""


class HashMethod(str, Enum):
    """Supported structural fingerprinting (hashing) methods.

    Used for deduplication, uniqueness checking, and diversity calculations.
    """
    RDF = "rdf"
    """Radial Distribution Function hashing."""
    
    TSF = "tsf"
    """Topological Structure Fingerprint hashing (default for crystalline phases)."""
    
    RBF = "rbf"
    """Radial Basis Function network-based hashing."""


class RepulsionMode(str, Enum):
    """Modes for computing descriptor repulsion between structures.

    Repulsion prevents local stagnation by pushing new proposals away from existing ones.
    """
    MIN = "min"
    """Repulsion based on the distance to the single nearest neighbor."""
    
    SUM = "sum"
    """Repulsion accumulated over all neighbors in the descriptor space."""


class SimulatorMode(str, Enum):
    """Execution modes for structural simulators.

    Determines what operations are performed when a calculator is applied to a structure.
    """
    SAMPLING = "sampling"
    """Single-point calculation (computes energy/forces without modifying coordinates)."""
    
    RELAXATION = "relaxation"
    """Geometry relaxation/optimization (minimizes forces and/or cell pressure)."""


class ResumeMode(str, Enum):
    """Resume strategies for restarting interrupted GA runs.

    Controls where the initial population and structural lineage are loaded from.
    """
    FOLDERS_ALL = "folders_all"
    """Scan all output directories and reconstruct full generational history."""
    
    FOLDERS = "folders"
    """Scan generational directories but do not reconstruct full historical lineage."""
    
    SNAPSHOT = "snapshot"
    """Load directly from a single consolidated database snapshot/file."""


class EnsembleKind(str, Enum):
    """Supported thermodynamic Monte Carlo and molecular dynamics ensembles.

    Used when switching BANS-GA into an ensemble sampler/Markov Chain simulation.
    """
    NONE = "none"
    """Standard Genetic Algorithm mode (default)."""
    
    GCMC = "gcmc"
    """Grand Canonical Monte Carlo (mu-V-T ensemble)."""
    
    REPLICA_EXCHANGE = "replica_exchange"
    """Parallel Tempering / Replica Exchange Monte Carlo."""
    
    GIBBS = "gibbs"
    """Gibbs Ensemble Monte Carlo for phase coexistence simulations."""
    
    NVT = "nvt"
    """Canonical ensemble sampling (constant N, V, T)."""
    
    IDENTITY = "identity"
    """Identity pass-through sampler."""
    
    NESTED_SAMPLING = "nested_sampling"
    """Bayesian Nested Sampling for partition function and density of states calculations."""
    
    HARD_CONSTRAINT = "hard_constraint"
    """Hard-constraint configuration space sampling."""


# -----------------------------------------------------------------------------
# Sub-models
# -----------------------------------------------------------------------------
class EnsembleBase(BaseModel):
    """Base thermodynamic ensemble and Markov Chain Monte Carlo (MCMC) parameters.

    Attributes:
        kind: The category of ensemble sampler to instantiate.
        walkers: Number of parallel, independent Markov chains (walkers) to simulate.
        sweeps: Total number of Monte Carlo sweeps/iterations per simulation stage.
        burn_in: Number of initial sweeps to discard during MCMC thermalization.
        thin: Save every n-th sample from the Markov Chain to reduce correlation 
            and storage footprint.
        store_trajectory: Whether to write full atomic trajectories and MCMC logs 
            to disk.
    """
    model_config = ConfigDict(extra="forbid")

    kind: EnsembleKind = EnsembleKind.NONE
    walkers: PositiveInt = 1
    sweeps: PositiveInt = 1000
    burn_in: NonNegativeInt = 0
    thin: PositiveInt = 1
    store_trajectory: bool = True


class GCMCParams(BaseModel):
    """Parameters for Grand Canonical Monte Carlo (mu-V-T) simulations.

    Attributes:
        temperature: Thermodynamic temperature in Kelvin (or eV-equivalent, 
            depending on calculator units).
        chemical_potential: Target chemical potentials (mu) mapped by chemical 
            species, e.g., {'O': -4.5, 'H': -3.2}.
        move_weights: Relative probabilities/weights for selecting displacement, 
            insertion, or deletion moves.
        max_displacement: Maximum single-step coordinate displacement in Angstroms.
        insertion_region: Geometric constraints for particle insertion trials.
        local_relax_after_accept: Perform immediate local geometry optimization 
            upon accepting a GCMC move.
    """
    model_config = ConfigDict(extra="forbid")

    temperature: PosFloat
    chemical_potential: Dict[str, float] = Field(default_factory=dict)
    move_weights: Dict[str, PosFloat] = Field(
        default_factory=lambda: {
            "displace": 1.0,
            "insert": 1.0,
            "delete": 1.0,
        }
    )
    max_displacement: PosFloat = 0.1
    insertion_region: Literal["box", "slab", "interlayer"] = "box"
    local_relax_after_accept: bool = False


class NVTParams(BaseModel):
    """Parameters for Canonical Ensemble (constant N, V, T) Monte Carlo sampling.

    Attributes:
        temperature: Thermodynamic temperature for the NVT heat bath.
    """
    model_config = ConfigDict(extra="forbid")

    temperature: PosFloat


class ReplicaExchangeParams(BaseModel):
    """Parameters for Replica Exchange / Parallel Tempering swaps.

    Attributes:
        mu_ladder: Chemical potential swap values defining the replica ladder.
        T_ladder: Temperature swap values defining the replica ladder.
        mu_ladders: Chemical potential swap values mapping species to their ladders.
        mu_species: Configurable mapping specifying if a species uses "adsorbate" or "atom" counting.
        thermodynamic_states: Explicit list of dictionary-defined thermodynamic states (T, mu) for custom/non-rectangular grids.
        kB: Boltzmann constant in appropriate energy units (defaults to eV/K: 8.617333262145e-5).
        exchange_every: Frequency (in sweeps) of attempting swaps between adjacent 
            replica levels.
        swap_pattern: Symmetric pairing algorithm for adjacent replica level exchanges.
        target_acceptance: Optimal swap acceptance target used for dynamically 
            adjusting ladders.
    """
    model_config = ConfigDict(extra="forbid")

    mu_ladder: Optional[List[float]] = None
    T_ladder: Optional[List[float]] = None
    mu_ladders: Optional[Dict[str, List[float]]] = None
    mu_species: Dict[str, Literal["adsorbate", "atom"]] = Field(
        default_factory=lambda: cast(Dict[str, Literal["adsorbate", "atom"]], {"CO": "adsorbate", "H": "atom"})
    )
    thermodynamic_states: Optional[List[Dict[str, Any]]] = None
    kB: float = 8.617333262145e-5
    exchange_every: PositiveInt = 100
    swap_pattern: Literal["even_odd"] = "even_odd"
    target_acceptance: Optional[Prob] = 0.2
    max_history_len: PositiveInt = 10000
    neighbor_mode: Literal["grid", "radius", "explicit", "knn"] = "grid"
    connection_radius: Optional[float] = 0.25
    distance_weights: Optional[Dict[str, float]] = None
    exchange_edges: Optional[List[List[int]]] = None
    k_neighbors: Optional[int] = 2


class GibbsParams(BaseModel):
    """Parameters for Gibbs Ensemble Monte Carlo (GEMC) phase equilibria.

    Attributes:
        boxes: Number of parallel coexisting phases boxes in vapor-liquid equilibrium (VLE) 
            without interfaces.
        transfer_weight: Probability weight of moving a particle from one phase box 
            to another during Gibbs steps.
        volume_weight: Probability weight of attempting a volume exchange between phase 
            boxes to equalize pressure.
        allow_volume_exchange: Whether to allow volume exchanges between boxes (must be 
            True for variable-density VLE).
        total_volume: Fixed consolidated volume constraint across all phase boxes.
        total_particles: Total absolute composition counts per species preserved globally 
            across all coexisting boxes.
        internal_weight: Probability weighting of canonical NVT displacement/rotation trials 
            within individual boxes.
    """
    model_config = ConfigDict(extra="forbid")

    boxes: PositiveInt = 2
    transfer_weight: PosFloat = 0.9
    volume_weight: PosFloat = 0.1
    allow_volume_exchange: bool = True
    total_volume: Optional[PosFloat] = None
    total_particles: Optional[Dict[str, int]] = None
    internal_weight: PosFloat = 1.0


class NestedSamplingParams(BaseModel):
    """Parameters for Bayesian Nested Sampling calculations.

    Assumes that proposal generators approximate independent samples from the constrained prior.

    Attributes:
        chemical_potential: Chemical potentials mapping for composition-flexible nested sampling.
        stochastic_shrinkage: Use stochastic/random shrinkage estimation rather than 
            deterministic expectation.
        strict_ns: Enforce strict likelihood pruning without fallback tolerances.
        T: Optional reference temperature for thermodynamic integration.
        beta: Thermodynamic beta (1/kBT) for thermal weight scaling.
        tolerance: Stopping threshold based on estimated remaining evidence fraction (dZ/Z).
        track_diagnostics: Track information-theoretic diagnostics (e.g., Shannon entropy, 
            compression rate).
        n_live: Number of active live points kept in the nested sampling pool.
        step_interval: Generational interval between nested sampling steps.
    """
    model_config = ConfigDict(extra="forbid")
    
    chemical_potential: Dict[str, float] = Field(default_factory=dict)
    stochastic_shrinkage: bool = False
    strict_ns: bool = False
    T: Optional[PosFloat] = None
    beta: Optional[PosFloat] = None
    tolerance: Optional[PosFloat] = None
    track_diagnostics: bool = True
    n_live: Optional[PositiveInt] = None
    step_interval: PositiveInt = 1


class HardConstraintParams(BaseModel):
    """Configuration for hard-constraint volume and structural boundaries."""
    model_config = ConfigDict(extra="forbid")


class EnsembleParams(BaseModel):
    """Orchestrator config wrapping all MCMC thermodynamic ensemble samplers.

    Attributes:
        kind: Target ensemble type.
        base: Core sweeps, thinning, and walker settings.
        gcmc: Parameters for Grand Canonical simulations.
        replica_exchange: Parameters for replica exchange swaps.
        gibbs: Parameters for Gibbs phase coexistence.
        nvt: Parameters for canonical ensemble MC.
        nested_sampling: Parameters for Nested Sampling evidence computations.
        hard_constraint: Parameters for hard constraints.
    """
    model_config = ConfigDict(extra="forbid")

    kind: EnsembleKind = EnsembleKind.NONE
    base: EnsembleBase = Field(default_factory=EnsembleBase)
    gcmc: Optional[GCMCParams] = None
    replica_exchange: Optional[ReplicaExchangeParams] = None
    gibbs: Optional[GibbsParams] = None
    nvt: Optional[NVTParams] = None
    nested_sampling: Optional[NestedSamplingParams] = None
    hard_constraint: Optional[HardConstraintParams] = None

    @model_validator(mode="after")
    def validate_mode(self):
        """Cross-validates ensemble configurations to catch missing subclass arguments."""
        if self.kind == EnsembleKind.GCMC:
            if self.gcmc is None:
                raise ValueError(f"Ensemble kind '{self.kind}' requires 'gcmc' parameters (at least 'temperature').")
        
        if self.kind == EnsembleKind.REPLICA_EXCHANGE:
            if self.replica_exchange is None:
                raise ValueError(f"Ensemble kind '{self.kind}' requires 'replica_exchange' parameters.")
            re = self.replica_exchange
            if re.T_ladder is None and re.mu_ladder is None and re.mu_ladders is None and re.thermodynamic_states is None:
                raise ValueError("Replica exchange requires either 'T_ladder', 'mu_ladder', 'mu_ladders', or 'thermodynamic_states' to define swaps.")

        if self.kind == EnsembleKind.GIBBS:
            if self.gibbs is None:
                self.gibbs = GibbsParams()
        
        if self.kind == EnsembleKind.NVT:
            if self.nvt is None:
                raise ValueError(f"Ensemble kind '{self.kind}' requires 'nvt' parameters (at least 'temperature').")
        
        return self


class MotifScalingParams(BaseModel):
    """Configuration for scaling motif harvesting to large databases.

    Defines capacity limits and database pruning criteria for motifs processing.

    Attributes:
        max_structures_to_analyze: Limits the sweep to the top-N structures in the 
            database to prevent O(N^2) matching costs when running graph isomorphic checks.
        max_fragments_per_structure: Max sub-graphs or local clusters per cell. Prevents 
            memory overflow in giant supercells where combinatorics is a bottleneck.
        max_motifs_per_structure: Caps harvested local motifs per candidate to avoid 
            redundant minor variations from saturating the library.
        max_families: Prunes the global motif library catalog. If exceeded, low-frequency 
            and low-score motifs are permanently evicted.
        sampling_mode: Policy: 'boltzmann' favors low-energy hosts proportionally; 
            'top_energy' targets absolute minimums; 'stratified' enforces diversity.
        top_pool_factor: Over-sampling multiplier (factor * population_size) defining the 
            pool from which energetic structures are selected for analysis.
        random_fraction: Fraction of structures sampled at random from the database to 
            capture high-energy transition state patterns.
        diversity_fraction: Fraction of structures sampled to maximize structural descriptor 
            diversity, capturing structurally rare motifs.
        early_stop: Halts database motif sweeps early if the discovery rate of new motif 
            families converges to zero.
        convergence_patience: Number of structures analyzed without discovering new motif 
            families before early stopping takes effect.
        rank_interval: Generational interval for re-ranking and indexing the motif database 
            based on energy-weighted score metrics.
        fingerprint_mode: Rigorous graph-matching fingerprint strategy (exact RDF 
            comparison vs. fast topological heuristic).
        selection_seed: RNG seed for stochastic motif database sampling.
    """
    model_config = ConfigDict(extra="forbid")

    max_structures_to_analyze: PositiveInt = 1000
    max_fragments_per_structure: PositiveInt = 400
    max_motifs_per_structure: PositiveInt = 200
    max_families: PositiveInt = 5000
    sampling_mode: Literal["boltzmann", "top_energy", "stratified"] = "boltzmann"
    top_pool_factor: PositiveInt = 10
    random_fraction: Prob = 0.10
    diversity_fraction: Prob = 0.20
    early_stop: bool = True
    convergence_patience: PositiveInt = 300
    rank_interval: PositiveInt = 100
    fingerprint_mode: Literal["exact", "fast"] = "exact"
    selection_seed: Optional[int] = None


class MotifParams(BaseModel):
    """Configuration for HiSE motif extraction, enrichment, and reintroduction.

    Controls how local chemical motifs are identified, statistically analyzed,
    and recombined to accelerate structural convergence.

    Attributes:
        enabled: Enable or disable motif harvesting and reintroduction mutation.
        substrate_elements: Chemical elements composing the static substrate (e.g. rigid 
            surface). Harvester ignores interactions purely within this set.
        mobile_elements: Chemical elements composing the active adatoms or clusters. 
            Harvester specifically tracks and extracts motifs containing these.
        min_atoms: Smallest atom count defining a valid chemical motif. Low values 
            capture simple groups; high values capture complex structures.
        max_atoms: Strict upper bound on harvested motif sizes. Large values increase 
            the cost of graph matching algorithms during reintroduction.
        min_fragments: Minimum fragment connections inside a complex multi-fragment motif.
        max_fragments: Maximum fragment connections inside a single harvested motif.
        allow_single_fragment_motifs: Allow harvesting simple, single-connected coordination 
            motifs (e.g. adatom monomers).
        motif_min_scale: Lower bound for scaling motif bond distances during harvesting checks.
        motif_max_scale: Upper bound for scaling motif bond distances during harvesting checks.
        fragment_connect_scale: Distance multiplier modifying standard covalent/ionic 
            radii for identifying bond connectivity between disparate adatom clusters.
        kBT_eff: Effective temperature in eV for Boltzmann-weighting. Controls how strongly 
            the lowest-energy hosts enrich their motifs.
        energy_window: Energy delta (in eV) above global minimum. Structures beyond this 
            are considered too unstable to harvest viable motifs from.
        energy_threshold: Absolute energy cutoff below which a host structure must lie to 
            be eligible for motif extraction.
        min_structure_count: Minimum number of independent host structures a motif family 
            must appear in to be retained in the library.
        min_weighted_frequency: Minimum Boltzmann-weighted occurrence frequency for a motif 
            to be considered elite.
        require_negative_delta_e: Only harvest motifs from structures that offer a net energy 
            improvement compared to the reference stoichiometry.
        include_surface_context: Saves surrounding substrate atomic coordinates along with 
            the motif to ensure placement in a matching chemical environment.
        context_scale: Cutoff radius multiplier for harvesting surrounding contextual 
            substrate atoms.
        context_mode: Representation scheme for context: 'species_counts' counts local 
            elements; 'binned_distances' matches spatial density via radial bins.
        context_bin_width: Bin width in Angstroms for distance-binned context matching.
        max_motifs: Maximum elite motif families stored in the active library. High values 
            increase memory and selection latency.
        save_rejected: Retain rejected motifs in a local log database for diagnostics.
        probability: GA mutation probability of invoking the motif reintroduction operator, 
            intercepting traditional atomic displacement mutations.
        sample_by: Metric: 'score' targets stable motifs; 'uniform' samples randomly; 
            'weighted_frequency' favors motifs common in low-energy hosts.
        z_offset: Minimum height clearance (in Angstroms) above substrate surface for 
            placing motifs, avoiding coordinate overlapping.
        surface_thickness: Target surface boundary width defining the placement zone for 
            reintroduced motifs.
        collision_scale: Overlap collision check multiplier. Set to < 1.0 to allow close 
            packing, relying on subsequent relaxation to resolve overlaps.
        max_attempts: Maximum stochastic trials for finding a collision-free motif 
            reintroduction placement.
        max_tilt_deg: Maximum allowable rotational tilt in degrees applied to motifs upon 
            reintroduction to simulate steps and imperfections.
        scaling: Database limits and pruning parameters for scale handling.
    """
    model_config = ConfigDict(extra="forbid")
    
    enabled: bool = False
    substrate_elements: Optional[List[str]] = None
    mobile_elements: Optional[List[str]] = None

    # Detection heuristics
    min_atoms: PositiveInt = 3
    max_atoms: PositiveInt = 25
    min_fragments: PositiveInt = 1
    max_fragments: PositiveInt = 5
    allow_single_fragment_motifs: bool = True
    motif_min_scale: NonNegFloat = 0.3
    motif_max_scale: NonNegFloat = 1.2
    fragment_connect_scale: NonNegFloat = 0.5

    # Statistics & Enrichment
    kBT_eff: PosFloat = 0.10
    energy_window: Optional[NonNegFloat] = 0.50
    energy_threshold: NonNegFloat = 0.00
    min_structure_count: PositiveInt = 1
    min_weighted_frequency: NonNegFloat = 0.00
    require_negative_delta_e: bool = False

    # Contextual analysis
    include_surface_context: bool = True
    context_scale: NonNegFloat = 0.6
    context_mode: Literal["species_counts", "binned_distances", "none"] = "species_counts"
    context_bin_width: PosFloat = 0.25

    # Library management
    max_motifs: PositiveInt = 50
    save_rejected: bool = False

    # Reintroduction mutation
    probability: Prob = 0.15
    sample_by: Literal["score", "uniform", "weighted_frequency"] = "score"
    z_offset: PosFloat = 2.0
    surface_thickness: PosFloat = 1.0
    collision_scale: PosFloat = 0.75
    max_attempts: PositiveInt = 50
    max_tilt_deg: NonNegFloat = 15.0

    # Scaling
    scaling: MotifScalingParams = Field(default_factory=MotifScalingParams)


class HiSEParams(BaseModel):
    """Hierarchical Supercell Escalation (HiSE) coarse-to-fine sequence settings.

    Manages scaling of optimization stages (e.g., cell expansions) sequentially.

    Attributes:
        supercells: Sequence of cell expansion matrices (stages), scaling sequentially 
            (e.g. 1x1x1 -> 2x1x1 -> 2x2x2).
        input_from: Source directory configuration for consecutive stage transitions.
        stage_dir_pattern: Subdirectory name per stage under GAConfig.output_path.
        restart: Resume incomplete supercell steps from checkpoints.
        overrides: Key-value overrides applied per stage (e.g. increasing population or 
            decreasing mutation rates in large supercells).
        carry: Filtering policy: 'pareto' copies only non-dominated; 'elites' carries 
            the top-N; 'all' transitions the whole population.
        reseed_fraction: Fraction of carried structures to re-introduce at the start 
            of a new stage.
        lift_method: Transformation algorithm: 'tile' replicates the coordinates along 
            the new supercell vectors.
        motifs: Stage motif database parameters.
    """
    model_config = ConfigDict(extra="forbid")

    supercells: List[Tuple[int, int, int]] = Field(
        ..., description="Sequence of supercells, e.g. [[1,1,1],[2,1,1],[2,2,1]]"
    )
    input_from: Literal["final_dataset", "latest_generation"] = Field(
        "final_dataset",
        description=(
            "Where to read previous stage input from: final_dataset (root config.xyz) "
            "or latest_generation (scan generation/*/config.xyz)."
        ),
    )
    stage_dir_pattern: str = Field(
        "supercell_{a}_{b}_{c}",
        description="Subdirectory name per stage under GAConfig.output_path.",
    )
    restart: bool = Field(
        True, description="Skip stages already complete; resume partial if possible."
    )
    overrides: Optional[Dict[str, List[Any]]] = Field(
        None,
        description=(
            "Stage-specific overrides by key path (dot-notation) → list of values per stage."
        ),
    )
    carry: Literal["pareto", "elites", "all"] = "all"
    reseed_fraction: Prob = 1.0
    lift_method: Literal["tile"] = "tile"
    motifs: MotifParams = Field(default_factory=MotifParams)

    @field_validator("supercells")
    @classmethod
    def _validate_supercells(cls, v: List[Tuple[int, int, int]]):
        """Ensures supercells contain non-empty positive scaling values."""
        if not v:
            raise ValueError("supercells must be a non-empty list")
        clean: List[Tuple[int, int, int]] = []
        for t in v:
            if len(t) != 3 or any(int(x) < 1 for x in t):
                raise ValueError(f"Invalid supercell {t!r}")
            clean.append((int(t[0]), int(t[1]), int(t[2])))
        return clean

    @model_validator(mode="after")
    def _validate_overrides_length(self):
        """Validates that stage overrides match the exact length of stages."""
        if self.overrides is None:
            return self
        n = len(self.supercells)
        for key, values in self.overrides.items():
            if not isinstance(values, list) or len(values) != n:
                raise ValueError(
                    f"overrides['{key}'] must be a list of length {n} (one per stage)"
                )
        return self


class PopulationParams(BaseModel):
    """Parameters regulating database storage and structural constraints of the population.

    Attributes:
        dataset_path: Primary path to local initial structures (e.g., 'config.xyz').
        template_path: Optional base template cell lattice for generating starting structures.
        db_path: Active relational SQLite/filesystem path for population persistence.
        db_ro_path: Read-only reference library for seeding diverse structures.
        filter_duplicates: Enables descriptor hashing to detect structurally identical 
            candidates. Prevents population collapse.
        save_duplicates: When ``filter_duplicates`` is True and a candidate is rejected as 
            a duplicate, controls whether the duplicate structure is written to the 
            ``basin/<composition>/<hash>/config_basin.xyz`` directory for post-hoc 
            analysis. Set to False to skip writing and reduce I/O for large runs.
        size_limit: Maximum storage limit for the database population.
        constraints: Dynamic validation functions (e.g. stoichiometry, volume ranges) 
            that structures must satisfy to survive.
        ef_bounds: Energy bounds (min_energy, max_energy) in eV/atom for strict filtering.
        collision_factor: Strict overlap factor (ratio of distance to sum of atomic radii). 
            Structures with closer atoms are discarded.
        blacklist: Active set of known unstable structural hashes to immediately reject.
        fetch_limit: Max structures fetched in a single database sweep.
        skip_hashing: Bypass descriptor calculation during initial database ingestion.
        skip_lineage: Disable writing parents and reproduction lineage graphs for performance.
        seed: Population initialization RNG seed.
    """
    model_config = ConfigDict(extra="forbid")

    dataset_path: Optional[Path] = None
    template_path: Optional[Path] = None
    db_path: Optional[Path] = None
    db_ro_path: Optional[Path] = None
    filter_duplicates: bool = True
    save_duplicates: bool = True
    size_limit: Optional[int] = None
    constraints: Optional[List[Union[Callable[..., bool], Dict[str, Any]]]] = None
    ef_bounds: Optional[Tuple[float, float]] = None
    collision_factor: Optional[NonNegFloat] = 0.80
    blacklist: Optional[List[str]] = None
    fetch_limit: Optional[int] = None
    skip_hashing: bool = False
    skip_lineage: bool = True
    seed: Optional[int] = None


class ThermostatParams(BaseModel):
    """Thermodynamic temperature controller (thermostat) for adjusting selection pressure.

    Attributes:
        initial_temperature: Starting temperature for Boltzmann selection pressure.
        decay_rate: Exponential cooling decay rate applied per generation. High decay 
            rates converge rapidly.
        period: Generational period for thermodynamic reheat pulses, increasing selection 
            entropy to escape deep energy wells.
        temperature_bounds: Absolute boundary constraints (min, max) for temperature 
            adjustments.
        max_stall_offset: Maximum thermal boost applied dynamically during structural 
            stagnation to allow high-energy structures to survive.
        stall_growth_rate: Growth rate of thermal boost per stalled generation.
        constant_temperature: Deactivate dynamic updates and freeze selection temperature.
    """
    model_config = ConfigDict(extra="forbid")

    initial_temperature: NonNegFloat = 1.0
    decay_rate: NonNegFloat = 0.005
    period: PositiveInt = 30
    temperature_bounds: Tuple[NonNegFloat, NonNegFloat] = (0.0, 1.1)
    max_stall_offset: NonNegFloat = 1.0
    stall_growth_rate: NonNegFloat = 0.01
    constant_temperature: bool = False

    @model_validator(mode="after")
    def _validate_temperatures(self):
        """Verifies correct temperature ranges."""
        low, high = self.temperature_bounds
        if low > high:
            raise ValueError("temperature_bounds must be (low ≤ high)")
        if not (low <= self.initial_temperature <= high):
            raise ValueError(
                "initial_temperature must lie within temperature_bounds"
            )
        return self


class EvaluatorParams(BaseModel):
    """Parameters managing physics calculations and property evaluations.

    Attributes:
        features_funcs: List of callable descriptors mapping structural features.
        objectives_funcs: List of objective functions (e.g., total energy, band gap, 
            formation energy).
        debug: Activate traceback tracking for evaluator failures.
        cache_features: Enable local caching of descriptor vectors to avoid re-calculation.
        cache_objectives: Enable local caching of objective values to avoid re-calculation.
    """
    model_config = ConfigDict(extra="forbid")

    features_funcs: Any = None
    objectives_funcs: Any = None
    debug: bool = False
    cache_features: bool = False
    cache_objectives: bool = False


class SelectionParams(BaseModel):
    """Parameters governing Boltzmann selection and multiobjective niching.

    Attributes:
        size: Total size of elite population subset carried to the next generation.
        weights: Multi-objective linear scalar weights (if not using Pareto sorting).
        repulsion_weight: Strength of the diversity-repulsion force in descriptor-space. 
            High repulsion favors highly diverse populations.
        repetition_penalty: Apply severe penalties to identical or highly redundant 
            structural descriptors.
        objective_temperature: Symmetric scaling divisor for Boltzmann selective sorting.
        repulsion_mode: Neighbor pairing mode for repulsion checks.
        composition_repulsion_weight: Niching strength applied to composition vectors. 
            Crucial for multicomponent phase diagram exploration.
        composition_decimals: Decimal rounding applied to float-based chemical features 
            when evaluating diversity.
        metric: Distance metric applied in the descriptor space for repulsion checks.
        random_seed: Selection RNG seed.
        steepness: Sigmoidal steepness parameter for Boltzmann-weighted selection. 
            Higher values make selection more competitive.
        max_count: Maximum occurrences allowed for any single species niche.
        cooling_rate: Selection cooling multiplier.
        counts: Optional initial reference counts per niche.
        normalize_objectives: Perform min-max feature scaling on raw objectives before sorting.
        sampling_temperature: Scales selection entropy. High temperatures make parent 
            selection more random.
        selection_method: Default sorting selection algorithm.
        divisions: Reference hyper-plane divisions used by NSGA-III sorting.
    """
    model_config = ConfigDict(extra="forbid")

    size: PositiveInt = 256
    weights: Optional[Sequence[float]] = None
    repulsion_weight: NonNegFloat = 1.0
    repetition_penalty: bool = True
    objective_temperature: PosFloat = 1.0
    repulsion_mode: RepulsionMode = RepulsionMode.MIN
    composition_repulsion_weight: NonNegFloat = 0.0
    composition_decimals: Annotated[int, Field(ge=0)] = 0
    metric: Literal["euclidean", "cosine", "manhattan"] = "euclidean"
    random_seed: Optional[int] = None
    steepness: PosFloat = 10.0
    max_count: PositiveInt = 50
    cooling_rate: Prob = 0.1
    counts: Optional[List[int]] = None
    normalize_objectives: bool = False
    sampling_temperature: PosFloat = 1.0
    selection_method: SelectionMethod = SelectionMethod.BOLTZMANN_BIGDATA
    divisions: PositiveInt = 12
    pareto_scaling: Optional[Union[List[float], Literal["minmax", "none"]]] = "minmax"

    @model_validator(mode="after")
    def _validate_counts(self):
        """Checks for positive structural constraints counts."""
        if self.counts is not None and any(c < 0 for c in self.counts):
            raise ValueError("counts must be non-negative integers")
        return self


class VariationParams(BaseModel):
    """Parameters managing mutation rates and crossover probability bounds.

    Attributes:
        initial_mutation_rate: Average number of mutations applied per candidate structure. 
            Higher rates introduce larger changes.
        min_mutation_rate: Strict lower floor bound for mutation adjustments.
        max_prob: Maximum allowable mutation probability constraint.
        min_prob: Minimum allowable mutation probability constraint.
        use_magnitude_scaling: Enable scaling mutation size dynamically with fitness progress.
        alpha: Smoothing rate constant for step adjustments. Determines how fast mutation 
            rates adapt based on GA progress.
        crossover_probability: Probability of invoking mating crossover recombination. 
            0.0 disables sexual reproduction.
        adaptive_max_process: Cap on concurrent variations processed.
        rng_seed: Variation RNG seed.
    """
    model_config = ConfigDict(extra="forbid")

    initial_mutation_rate: PosFloat = 1.0
    min_mutation_rate: PosFloat = 1.0
    max_prob: Prob = 0.95
    min_prob: Prob = 0.01
    use_magnitude_scaling: bool = True
    alpha: NonNegFloat = 0.01
    crossover_probability: Prob = 0.1
    adaptive_max_process: PositiveInt = 256
    rng_seed: Optional[int] = None

    @model_validator(mode="after")
    def _validate_ranges(self):
        """Cross-checks valid variation intervals."""
        if self.min_prob > self.max_prob:
            raise ValueError("min_prob must be ≤ max_prob")
        if self.min_mutation_rate > self.initial_mutation_rate:
            raise ValueError(
                "min_mutation_rate must be ≤ initial_mutation_rate"
            )
        return self


class SimulatorParams(BaseModel):
    """Configuration for simulator interface (ASE calculators, engines, seeds).

    Attributes:
        mode: Active simulator mode.
        calculator: User-provided ASE calculator class/object or pipeline.
        seed: Simulator execution seed.
    """
    model_config = ConfigDict(extra="forbid")

    mode: SimulatorMode = SimulatorMode.SAMPLING
    calculator: Optional[Any] = [ lambda x : 1 ]
    seed: Optional[int] = None


class ConvergenceParams(BaseModel):
    """Configuration for convergence checking and early termination criteria.

    Attributes:
        stall_threshold: Generations without progress before claiming convergence.
        objective_threshold: Threshold for declaring objective progress improvements.
        alpha_discovery: EMA smoothing factor for structural discovery rate. Lower 
            values are more robust to generational noise.
        alpha_progress: EMA smoothing factor for global objective progress. Lower values 
            filter noise; higher respond instantly.
        alpha_acceptance: EMA smoothing factor for candidate acceptances.
        max_cache_size: Size cap of niche history cache for uniqueness checks.
        track_features: Enable niche-based feature tracking (Mode B) in convergence monitor. 
            Essential for diversity-oriented runs.
    """
    model_config = ConfigDict(extra="forbid")

    stall_threshold: Optional[PositiveInt] = None
    objective_threshold: NonNegFloat = 1e-4
    alpha_discovery: NonNegFloat = 0.05
    alpha_progress: NonNegFloat = 0.05
    alpha_acceptance: NonNegFloat = 0.1
    max_cache_size: PositiveInt = 1_000_000
    track_features: bool = False


class AdaptiveAgentParams(BaseModel):
    """Parameters managing decentralized swarm agent policy adaptation (XRM).

    Determines dynamic limits for agent behavior shifts under stagnation.

    Attributes:
        enabled: Enable dynamic self-adaptation loops for evolutionary parameters.
        target_exploration: Swarm coordination objective for exploration. Defines the 
            target value of the X-axis parameter in XRM control space.
        target_selection_pressure: Swarm coordination objective for selective pressure.
        target_diversity_pressure: Swarm coordination objective for diversity. Defines 
            the target value of the R-axis parameter in XRM control space.
        target_focus: Target focus metric.
        target_social_coupling: Dynamic swarm Nash-coupling multiplier.
        learning_rate: Update speed of the internal agent policy controller based on local 
            and social feedback.
        inertia: Momentum factor (0 to 1) for agent policy updates. Protects the swarm 
            from chaotic oscillations.
        diffusion_scale: Scale of random Gaussian noise added to policy vectors to promote 
            discovery.
        repulsion_scale: Social repulsion force strength. Drives different agents to optimize 
            different regions of the parameter space.
        repulsion_radius: Closeness limit for triggering social repulsion forces.
        mutation_rate_bounds: Minimum and maximum mutation rate modifiers.
        sampling_temperature_bounds: Minimum and maximum selection temperature scaling bounds.
        repulsion_weight_bounds: Repulsion weight bounds.
        composition_repulsion_bounds: Composition repulsion bounds.
        crossover_probability_bounds: Crossover probability limits.
        fetch_every_bounds: Fetch interval bounds.
        max_buffer_bounds: File buffering limits.
    """
    model_config = ConfigDict(extra="forbid")
    
    enabled: bool = True

    # Policy Vector Targets (0 to 1)
    target_exploration: Prob = 0.5
    target_selection_pressure: Prob = 0.5
    target_diversity_pressure: Prob = 0.5
    target_focus: Prob = 0.3
    target_social_coupling: Prob = 0.5

    # Adaptation speed
    learning_rate: Prob = 0.15
    inertia: Prob = 0.85
    diffusion_scale: Prob = 0.002
    repulsion_scale: NonNegFloat = 0.85
    repulsion_radius: NonNegFloat = 0.15

    # Safety bounds for mapping
    mutation_rate_bounds: Tuple[PosFloat, PosFloat] = (1.0, 5.0)
    sampling_temperature_bounds: Tuple[PosFloat, PosFloat] = (0.2, 3.0)
    repulsion_weight_bounds: Tuple[NonNegFloat, NonNegFloat] = (0.0, 5.0)
    composition_repulsion_bounds: Tuple[NonNegFloat, NonNegFloat] = (0.0, 3.0)
    crossover_probability_bounds: Tuple[Prob, Prob] = (0.0, 0.5)
    fetch_every_bounds: Tuple[PositiveInt, PositiveInt] = (1, 20)
    max_buffer_bounds: Tuple[PositiveInt, PositiveInt] = (1, 20)


class AgenticParams(BaseModel):
    """Parameters managing sharded file synchronization and social agent settings.

    Attributes:
        hash_name: Digest algorithm recognized by hashlib for content addressing.
        shared_dir: Shared filesystem root directory where sharded batches are written.
        shard_width: Length of the leading hex subdirectory naming (improves FS scaling).
        persist_seen: Maintain seen.json locally to avoid duplicate processing across runs.
        poll_interval: FS scanning interval in seconds.
        max_buffer: Number of new structures accumulated before flushing a batch to disk.
        max_retained: Cap on the number of sharded batches retained (prunes oldest).
        auto_publish: Automatically flush buffer on hitting max_buffer limit.
        fetch_every: Number of generations between neighbor sweeps.
        strategy: Initial adaptive swarm strategy (e.g., balanced, wide, explorative).
        adaptive: Turn on decentralized policy self-tuning.
        adaptive_policy: Dynamic policy parameters.
        max_transfer_limit: Maximum number of structures to read per fetch cycle.
    """
    model_config = ConfigDict(extra="forbid")

    hash_name: str = "sha256"
    shared_dir: Optional[Path] = None
    shard_width: PositiveInt = 2
    persist_seen: bool = False
    poll_interval: PosFloat = 2.0
    max_buffer: PositiveInt = 4
    max_retained: Optional[PositiveInt] = None
    auto_publish: bool = True
    fetch_every: PositiveInt = 5
    strategy: str = "balanced"
    adaptive: bool = True
    adaptive_policy: AdaptiveAgentParams = Field(default_factory=AdaptiveAgentParams)
    max_transfer_limit: Optional[PositiveInt] = 2000

    @model_validator(mode="after")
    def _validate_strategy(self):
        """Ensures that strategy tokens match predefined policies."""
        import re
        allowed = {
            "balanced", "deep", "wide", "exploitation", "exploration",
            "explorative", "exploitative", "diverse", "isolated", "collaborative"
        }
        tokens = [s.strip().lower() for s in re.split(r'[,\s]+', self.strategy) if s.strip()]
        
        for t in tokens:
            if t not in allowed:
                raise ValueError(
                    f"Invalid agent strategy '{t}'. Allowed strategies: {sorted(allowed)}"
                )
        return self


class PhysicalModelCfg(BaseModel):
    """Configurations wrapping physical thermodynamic ensembles.

    Attributes:
        T_mode: Underlying thermodynamic ensemble mode.
        calculator: Core physics calculator instance.
    """
    model_config = ConfigDict(extra="forbid")

    T_mode: Literal["canonical", "grand_canonical", "microcanonical"]
    calculator: Any


# --- Per-method hash configs -------------------------------------------------
class _HashBase(BaseModel):
    """Abstract base model for structural hashing methods."""
    model_config = ConfigDict(extra="forbid")


class TSFHashCfg(_HashBase):
    """Topological Structure Fingerprint (TSF) descriptor parameters.

    Attributes:
        method: Categorical hash identifier.
        kmax: Wavevector index cutoff boundary.
        modes: Specific TSF k-space modes to extract.
        per_species: Calculate descriptor separately per chemical element.
        ps_grid: Lattice grid accuracy resolution.
        lattice_grid: Lattice distortion grid limits.
        e_grid: Energy discretization grid.
        v_grid: Volume discretization grid.
        include_energy: Combine total energy into fingerprint hash.
        include_volume: Combine cell volume into fingerprint hash.
        use_spglib: Employ spglib to find space group symmetry before hashing.
        symprec: Symmetry precision threshold for cell analysis.
        angle_tolerance: Angle tolerance constraint for spglib calculations.
        chunk_size: Data processing block sizes.
        debug: Debug logs toggle.
    """
    method: Literal["tsf"] = "tsf"
    kmax: PositiveInt = 3
    modes: Optional[List[Tuple[int, int, int]]] = None
    per_species: bool = True
    ps_grid: PosFloat = 1e-1
    lattice_grid: PosFloat = 2e-2
    e_grid: PosFloat = 1e-3
    v_grid: PosFloat = 1e-2
    include_energy: bool = True
    include_volume: bool = True
    use_spglib: bool = False
    symprec: PosFloat = 1e-3
    angle_tolerance: float = -1.0
    chunk_size: PositiveInt = 50_000
    debug: bool = False

    @field_validator("modes")
    @classmethod
    def _modes_or_none_nonempty(cls, v):
        """Protects against empty lists."""
        if v is not None and len(v) == 0:
            raise ValueError("modes must be None or a non-empty list")
        return v


class RDFHashCfg(_HashBase):
    """Radial Distribution Function (RDF) descriptor parameters.

    Attributes:
        method: Categorical hash identifier.
        r_max: Radial cutoff distance in Angstroms.
        bin_width: Discretization bin width in Angstroms.
        density_grid: Density grid bounds.
        e_grid: Energy discretization grid.
        v_grid: Volume discretization grid.
        symprec: Symmetry checking precision.
        debug: Debug logs toggle.
    """
    method: Literal["rdf"] = "rdf"
    r_max: PosFloat = 10.0
    bin_width: PosFloat = 0.02
    density_grid: PosFloat = 1e-4
    e_grid: PosFloat = 1e-2
    v_grid: PosFloat = 1e-2
    symprec: PosFloat = 1e-3
    debug: bool = False


class RBFHashCfg(_HashBase):
    """Radial Basis Function (RBF) descriptor parameters.

    Attributes:
        method: Categorical hash identifier.
        number_of_bins: Number of RBF basis bins.
        bin_volume_normalize: Normalize bins by volume elements.
        number_of_atoms_normalize: Normalize descriptors by atomic counts.
        density_normalize: Normalize descriptors by system density.
        e_grid: Energy discretization grid.
        v_grid: Volume discretization grid.
        symprec: Symmetry checking precision.
        debug: Debug logs toggle.
    """
    method: Literal["rbf"] = "rbf"
    number_of_bins: PositiveInt = 200
    bin_volume_normalize: bool = False
    number_of_atoms_normalize: bool = False
    density_normalize: bool = False
    e_grid: PosFloat = 1e-2
    v_grid: PosFloat = 1e-2
    symprec: PosFloat = 1e-3
    debug: bool = False


# -----------------------------------------------------------------------------
# Generative model (Bayesian Optimization by default)
# -----------------------------------------------------------------------------
class GenerativeParams(BaseModel):
    """Generative Bayesian Optimization (BO) and Gaussian Process surrogate proposal settings.

    Attributes:
        size: Number of candidate structures generated via BO per generation (0 to disable).
        start_gen: Generation at which the surrogate BO model becomes active.
        every: Generational frequency of running BO proposals.
        fit_frequency: Frequency of fitting/updating Gaussian Process hyper-parameters.
        candidate_multiplier: Oversampling factor for generating candidate coordinates.
        training_subsample: Cap on database samples used in training (guards against O(N3) GP costs).
        subsample_strategy: Sampling policy for GP training selection (random vs. descriptor-based diversity).
        warm_start: Use previous GP hyper-parameters as starts for optimizer fitting.
        use_ard: Activate Automatic Relevance Detection (anisotropic length scales per descriptor).
        n_restarts_optimizer: Number of restarts when maximizing acquisition functions.
        save_model: Serialize the Gaussian Process model to disk.
        save_path: Target directory for saving GP checkpoint files.
        discrete_design: Constrain surrogate proposals to integer and discrete coordinates.
        tolerance: Minimum objective difference for considering surrogate predictions valid.
        max_variation_iterations: Max structural relaxation loops allowed in generation.
        max_mutations: Max mutations attempted inside surrogate optimization loop.
        bo_kwargs: User overrides passed directly to the GPyOpt or custom BO package.
        custom: Custom generative algorithm callback function.
    """
    model_config = ConfigDict(extra="forbid")

    size: NonNegativeInt = 0
    start_gen: NonNegativeInt = 0
    every: PositiveInt = 1
    fit_frequency: PositiveInt = 1
    candidate_multiplier: PositiveInt = 10
    training_subsample: Optional[PositiveInt] = 200
    subsample_strategy: Literal["random", "diverse"] = "random"
    warm_start: bool = True
    use_ard: bool = True
    n_restarts_optimizer: NonNegativeInt = 5
    save_model: bool = False
    save_path: Optional[Path] = None
    discrete_design: bool = True
    tolerance: Union[NonNegFloat, List[float]] = 0.1
    max_variation_iterations: PositiveInt = 20
    max_mutations: PositiveInt = 200
    bo_kwargs: Optional[Dict[str, Any]] = None
    custom: Optional[Callable[..., Any]] = None

    @model_validator(mode="after")
    def _validate_logic(self):
        """Ensures logical active generators values."""
        if self.size == 0:
            return self

        if self.start_gen < 0:
            raise ValueError("start_gen must be >= 0")

        return self


HashMapConfig = Annotated[
    Union[RDFHashCfg, TSFHashCfg, RBFHashCfg],
    Field(discriminator="method"),
]
"""Discriminated union packing the parameters of active structural hash descriptors."""


# -----------------------------------------------------------------------------
# Top-level configuration
# -----------------------------------------------------------------------------
class GAConfig(BaseModel):
    """Top-level configuration for BANS-GA (validated via Pydantic v2).

    This model is intentionally strict (extra=forbid) to catch typos early, but
    remains assignment-validating to support programmatic modification during
    experiments.

    Attributes:
        initial_generation: Starting generation index (useful for resuming runs).
        max_generations: Maximum generations allowed before optimization stops.
        min_size_for_filter: Minimum size of population required to trigger duplicate filtering.
        foreigners: Number of foreign (randomly generated) structures injected per generation.
        save_logs: Save history files, workflow actions, and tracking logs.
        save_generations: Write generational XYZ files containing coordinate dumps.
        output_path: Output root directory path for logs, databases, and structural dumps.
        resume: Automatically resume runs from prior outputs in output_path.
        resume_mode: Active resume scanning mode.
        mem_hiwater_mb: High-water memory limit in Megabytes (safely aborts GA if memory usage spikes).
        population: Database and structural boundary rules.
        thermostat: Dynamic temperature controller settings.
        evaluator: Physics calculators, objectives, and feature tracking properties.
        multiobjective: Sorting and niching parameters.
        variation: Mutation limits and crossover configuration.
        mutation_funcs: List of mutation operators applied during variation steps.
        crossover_funcs: List of crossover operators applied during variation steps.
        simulator: Underlying ASE calculators and evaluation modes.
        convergence: Stagnation tracking and termination boundaries.
        hashmap: Active structural hashing fingerprint configuration.
        agentic: Swarm agent synchronization and social adaptive policies.
        ensemble: Thermodynamic Monte Carlo ensemble sampler parameters.
        hise: Hierarchical cell scaling options (HiSE).
        generative: Bayesian Optimization surrogate generator settings.
        initial_population: Direct, list-based insertion of starting structures.
        debug: Activate verbose logging and engine diagnostics.
        rng: Global system-wide random number seed.
    """
    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        populate_by_name=True,
        arbitrary_types_allowed=True,
    )

    # Global GA controls
    initial_generation: NonNegativeInt = 0
    max_generations: PositiveInt = 100
    min_size_for_filter: PositiveInt = 10
    foreigners: NonNegativeInt = 0
    save_logs: bool = True
    save_generations: bool = True
    output_path: Path = Path(".")
    resume: bool = True
    resume_mode: ResumeMode = ResumeMode.FOLDERS_ALL
    mem_hiwater_mb: Optional[PositiveInt] = None

    # Subsystems
    population: PopulationParams = Field(default_factory=PopulationParams)
    thermostat: ThermostatParams = Field(default_factory=ThermostatParams)
    evaluator: EvaluatorParams = Field(default_factory=EvaluatorParams)
    multiobjective: SelectionParams = Field(default_factory=SelectionParams)
    variation: VariationParams = Field(default_factory=VariationParams)
    mutation_funcs: List[Union[Callable[..., Any], Dict[str, Any], str, List[Any]]] = Field(default_factory=list)
    crossover_funcs: List[Union[Callable[..., Any], Dict[str, Any], str, List[Any]]] = Field(default_factory=list)
    simulator: SimulatorParams = Field(default_factory=SimulatorParams)
    convergence: ConvergenceParams = Field(default_factory=ConvergenceParams)
    hashmap: HashMapConfig = Field(default_factory=TSFHashCfg)
    agentic: AgenticParams = Field(default_factory=AgenticParams)
    ensemble: EnsembleParams = Field(default_factory=EnsembleParams)
    hise: Optional[HiSEParams] = Field(
        default=None,
        description="Hierarchical Supercell Escalation (coarse-to-fine) settings.",
    )
    generative: GenerativeParams = Field(default_factory=GenerativeParams)

    # extras “legacy”
    initial_population: Optional[List[Any]] = None
    debug: bool = False
    rng: Optional[int] = None

    @field_validator("foreigners", mode="before")
    @classmethod
    def cast_foreigners_int(cls, v):
        """Guards against string entries for foreigners limit."""
        return int(v) if v is not None else 0
    
    @model_validator(mode="after")
    def check_relationships(self):
        """Performs inter-parameter safety checks and resolves system-wide seeds."""
        m = self.multiobjective.size
        if self.min_size_for_filter < m:
            self.min_size_for_filter = m

        if self.ensemble.kind != EnsembleKind.NONE:
            # Disable standard GA behavior if running in ensemble sampling mode
            self.variation.crossover_probability = 0.0
            self.multiobjective.selection_method = SelectionMethod.TRAJECTORY
            # Disable structural filtering as ensemble samplers need pure Markov chains
            self.population.filter_duplicates = False
            self.population.collision_factor = 0.0
            
            if self.generative.size > 0:
                raise ValueError("Generative model not compatible with ensemble sampling.")

            if self.ensemble.kind == EnsembleKind.NESTED_SAMPLING:
                # Nested Sampling requires a constant temperature of 1.0
                self.thermostat.constant_temperature = True
                self.thermostat.initial_temperature = 1.0

        # Propagate global RNG seed to all subsystems if not overridden
        if self.rng is not None:
            if self.variation.rng_seed is None:
                self.variation.rng_seed = self.rng
            if self.multiobjective.random_seed is None:
                self.multiobjective.random_seed = self.rng
            if self.simulator.seed is None:
                self.simulator.seed = self.rng
            if self.population.seed is None:
                self.population.seed = self.rng

        return self
