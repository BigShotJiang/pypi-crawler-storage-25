# ezga/core/interfaces.py
"""
Interfaces and Protocols for EZGA components.

This module defines the structural types (Protocols) that various components
of the Genetic Algorithm must implement to ensure interoperability and 
type safety across the framework (ISP + DIP principles).
"""
from __future__ import annotations

from typing import Protocol, Any, Iterator, runtime_checkable, TYPE_CHECKING
import numpy as np

if TYPE_CHECKING:
    from .context import Context

@runtime_checkable
class IIndividual(Protocol):
    """Protocol for an individual structure in the population."""
    @property
    def id(self) -> str | int:
        """The unique identifier for the individual."""
        ...
    
    @property
    def AtomPositionManager(self) -> Any:
        """The manager for atomic positions and metadata."""
        ...  # Should have .metadata, .pos, .elements

@runtime_checkable
class IHash(Protocol):
    """Protocol for structure hashing and duplicate detection."""
    def add_structure(self, container: IIndividual, force_rehash: bool) -> bool:
        """Adds a structure to the visited hash set."""
        ...
    def already_visited(self, container: IIndividual) -> bool:
        """Checks if a structure has already been visited."""
        ...
    def get_hash(self, container: IIndividual, force_rehash: bool) -> str:
        """Generates a hash for the given individual."""
        ...

@runtime_checkable
class IAgent(Protocol):
    """Protocol for the Agentic (collaborative) system."""
    def active(self) -> bool:
        """Returns True if the agent system is active."""
        ...
    def append(self, obj: Any) -> bool:
        """Appends a structure to the shared agent directory."""
        ...
    def flush(self) -> list[Any]:
        """Flushes the agent buffer and returns new structures."""
        ...
    def get_batch(self, prune: bool = False, **kwargs: Any) -> Iterator[Any]:
        """Retrieves a batch of structures from the shared directory."""
        ...
    def update_behaviour(self, population: IPopulation, ctx: Context) -> bool:
        """Updates the agent's behavior based on population state."""
        ...
    def update_policy_metrics(self, diversity: float, pressure: float) -> None:
        """Updates internal policy metrics for the agent."""
        ...
    def attempt_prune(self, interval: float, budget: int, min_age: float) -> int:
        """Attempts to prune old structures from the shared storage."""
        ...

@runtime_checkable
class ILineage(Protocol):
    """Protocol for tracking structural lineage."""
    def assign_lineage(self, population: IPopulation, ctx: Context) -> None:
        """Assigns lineage metadata to new individuals."""
        ...

@runtime_checkable
class IDoE(Protocol):
    """Protocol for Design of Experiments (DoE) constraints."""
    def validate(self, features: np.ndarray) -> bool:
        """Validates if a feature vector satisfies DoE constraints."""
        ...
    def generate(self, X: np.ndarray, Y: np.ndarray, *, n_candidates: int, T: float, discrete_design: bool = False) -> np.ndarray:
        """Generates new candidate points in feature space."""
        ...
    def set_name_mapping(self, mapping: dict[str, int]) -> Any:
        """Sets the mapping between feature names and indices."""
        ...

@runtime_checkable
class IPopulation(Protocol):
    """Protocol for the Population manager."""
    def load_population(self, logger: Any = None) -> None:
        """Loads the initial population from storage."""
        ...
    def load_partitions(self, dataset_path: Any, ctx: Context) -> Any:
        """Loads partitions/structures from a dataset file."""
        ...
    def get_dataset(self, name: str) -> Any:
        """Retrieves a specific dataset by name."""
        ...
    def get_containers(self, name: str) -> list[Any] | None:
        """Retrieves a list of structure containers from a dataset."""
        ...
    def set_population(self, name: str, population: Any) -> bool:
        """Sets the population for a specific dataset."""
        ...
    def dataset_add(self, name: str, dataset: Any) -> bool:
        """Adds a new dataset to the population manager."""
        ...
    def update_main_dataset(
        self, dataset: Any, generation: int, features_prev: Any, objectives_prev: Any
    ) -> int:
        """Updates the main population dataset with new structures."""
        ...
    def size(self, name: str | None = None) -> int:
        """Returns the size of a dataset."""
        ...
    def filter(self, name: str, idx: Any) -> Any:
        """Filters a dataset based on indices."""
        ...
    def validate_candidates(
        self, individuals: list[Any], features: Any, remove: bool = False
    ) -> tuple[list[Any], list[Any]]:
        """Validates candidates against DoE and physical constraints."""
        ...
    def filter_selfcollision(
        self, individuals: list[Any], remove: bool = False
    ) -> tuple[list[Any], list[Any]]:
        """Filters structures with atomic self-collisions."""
        ...
    def filter_hash_collisions(
        self, individuals: list[Any], force_rehash: bool = True, save_basin: bool = True
    ) -> tuple[list[Any], list[Any]]:
        """Filters structures that have already been visited."""
        ...
    def agent_sync(self, dataset: Any, objectives: Any, features: Any, ctx: Any = None) -> list[Any]:
        """Synchronizes the population with external agents."""
        ...
    def export_structures(self, dataset: Any, file_path: str) -> bool:
        """Exports structures to a file."""
        ...
    
    @property
    def output_path(self) -> str:
        """The base output path for population data."""
        ...

@runtime_checkable
class IThermostat(Protocol):
    """Protocol for the selection temperature (thermostat) controller."""
    def update(self, generation: int, stall: int = 0, signals: Any = None) -> float:
        """Updates and returns the current selection temperature."""
        ...

@runtime_checkable
class ISelector(Protocol):
    """Protocol for parent selection strategies."""
    def select(self, objectives: np.ndarray, features: np.ndarray, size: int | None = None) -> np.ndarray:
        """Selects indices from a dataset based on objectives/features."""
        ...
    def set_temperature(self, temperature: float) -> bool:
        """Sets the current temperature for selection pressure."""
        ...

@runtime_checkable
class ITransitionKernel(Protocol):
    """Protocol for transition kernels (evolutionary workflows)."""
    def step(self, parents: Any, candidates: list[Any], **kwargs: Any) -> list[Any]:
        """Performs a single step of the transition kernel."""
        ...
    def allows_agent_sync(self) -> bool:
        """Returns True if the kernel allows agent synchronization."""
        ...

@runtime_checkable
class IMutation(Protocol):
    """Protocol for mutation operators."""
    def mutate(self, individual: Any, ctx: Context) -> Any:
        """Applies a mutation to a single individual."""
        ...

@runtime_checkable
class ICrossover(Protocol):
    """Protocol for crossover operators."""
    def crossover(self, parent1: Any, parent2: Any, ctx: Context) -> Any:
        """Combines two parents to create a new individual."""
        ...

@runtime_checkable
class IVariation(Protocol):
    """Protocol for the Variation manager (mutation/crossover pipeline)."""
    def apply_mutation_and_crossover(
        self, individuals: list[Any], generation: int, objectives: Any, temperature: float
    ) -> tuple[list[Any], list[Any], np.ndarray]:
        """Applies variation pipeline to a batch of individuals."""
        ...
    def guided_variation(self, parents: Any, targets: Any, temperature: float, **kwargs: Any) -> Any:
        """Applies variation guided by feature-space targets."""
        ...
    def penalization(self, individuals: list[Any], process: str) -> None:
        """Applies structural penalization (e.g., distance constraints)."""
        ...

@runtime_checkable
class IGenerative(Protocol):
    """Protocol for generative guidance models."""
    def is_active(self, generation: int) -> bool:
        """Returns True if the generative model is active for this generation."""
        ...

    def generate_targets(
        self,
        *,
        generation: int,
        features: np.ndarray,
        objectives: np.ndarray,
        temperature: float,
    ) -> np.ndarray | None:
        """Proposes feature-space targets for guided variation."""
        ...

@runtime_checkable
class IForeignerGenerator(Protocol):
    """Protocol for generating 'foreigner' (random) structures."""
    def generate(self, ctx: Context) -> list[Any]:
        """Generates a batch of new random structures."""
        ...

@runtime_checkable
class IEvaluator(Protocol):
    """Protocol for structure evaluation (features and objectives)."""
    def evaluate(self, individuals: list[Any], ctx: Context) -> list[Any]:
        """Evaluates a batch of individuals."""
        ...
    def evaluate_features_objectives(self, individuals: list[Any]) -> tuple[np.ndarray, np.ndarray]:
        """Returns feature and objective arrays for a batch of individuals."""
        ...
    def get_features(self, dataset: list[Any]) -> np.ndarray:
        """Extracts features from a list of individuals."""
        ...
    def get_objectives(self, dataset: list[Any]) -> np.ndarray:
        """Extracts objectives from a list of individuals."""
        ...
    
    cache_features: bool
    cache_objectives: bool

@runtime_checkable
class ISimulator(Protocol):
    """Protocol for physics simulations (calculators/relaxations)."""
    def validate(self, individuals: list[Any]) -> list[Any]:
        """Performs initial validation/filtering on individuals."""
        ...
    def run(self, individuals: list[Any], **kwargs: Any) -> list[Any]:
        """Runs the simulation/relaxation on a batch of individuals."""
        ...

@runtime_checkable
class IConvergence(Protocol):
    """Protocol for convergence tracking and early stopping."""
    def should_stop(self, population: IPopulation, ctx: Context) -> bool:
        """Returns True if the GA should stop based on convergence criteria."""
        ...
    def check(
        self,
        generation: int,
        objectives: Any,
        features: Any,
        accepted_structures: int,
        proposed_structures: int,
    ) -> dict[str, Any]:
        """Updates convergence state and returns a report."""
        ...
    def is_converge(self) -> bool:
        """Returns True if convergence has been reached."""
        ...
    def get_stagnation(self) -> int:
        """Returns the number of generations without improvement."""
        ...
    def improvement_found(self) -> bool:
        """Returns True if an improvement was found in the last check."""
        ...
    
    signals: Any
    _stall_threshold: float

@runtime_checkable
class ILogger(Protocol):
    """Protocol for logging messages."""
    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Logs an informational message."""
        ...
    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Logs a warning message."""
        ...
    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Logs an error message."""
        ...
    def exception(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Logs an exception with traceback."""
        ...
    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Logs a debug message."""
        ...

@runtime_checkable
class IPlotter(Protocol):
    """Protocol for generating GA analysis plots."""
    def generate_all_plots(self, logger_dir: str | None = None, output_dir: str | None = None) -> None:
        """Generates a standard set of analysis plots."""
        ...




    