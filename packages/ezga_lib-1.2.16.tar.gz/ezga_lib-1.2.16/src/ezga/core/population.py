from __future__ import annotations

import os
import time
import copy
import logging
import warnings
import numpy as np
import json  # Added for parameter logging
from typing import List, Optional, Any, Union, Callable, Dict, Tuple, cast
from pathlib import Path
from tqdm import tqdm

from sage_lib.partition.Partition import Partition

from ezga.core.interfaces import (
    IPopulation, ILineage, IHash, IAgent, IDoE, ILogger
)

from ezga.utils.lineage import LineageTracker
from ezga.utils.structure_hash_map import Structure_Hash_Map
from ezga.sync.agenticsync import Agentic_Sync
from ezga.DoE.DoE import DesignOfExperiments
from ezga.utils.molecule_blacklist import BlacklistDetector
from ezga.evaluator.objective import evaluate_objectives

class Population(IPopulation):
    """
    """
    def __init__(
        self,
        *,
        dataset_path: str | None = None,
        template_path: str | None = None,
        output_path: str | None = None,
        collision_factor: float | None = None,
        filter_duplicates: bool | None = True,
        save_duplicates: bool = True,
        size_limit: float | None = None,
        fetch_limit: int | None = None,

        db_path: str | None = None,
        db_ro_path: str | None = None,
        skip_hashing: bool = False,
        skip_lineage: bool = False,

        debug: bool = False,
        hash_map: type[IHash] = Structure_Hash_Map,
        agent: type[IAgent] = Agentic_Sync,
        lineage: type[ILineage] = LineageTracker,

        constraints: list[Any] | None = None,
        ef_bounds: tuple[float, float] | None = None,  # Pontetial units/atom bounds (typical GGAs)
        blacklist: list[str] | None = None,
        seed: int | None = None,
    ) -> None:
        """
        Initializes the Population.

        Args:
            dataset_path: Path to the initial structures file.
            template_path: Path to the template structure file.
            output_path: Directory to save output files.
            collision_factor: Factor for collision detection.
            filter_duplicates: Whether to filter duplicate structures based on hash.
            save_duplicates: If filter_duplicates is True, controls whether rejected
                duplicate structures are written to the basin directory on disk.
                Set to False to reduce I/O overhead in large-scale sampling runs.
            size_limit: Limit on the number of structures to load/keep.
            fetch_limit: Limit on the number of structures to fetch from agent.
            db_path: Path to local writable database.
            db_ro_path: Path to read-only database.
            skip_hashing: If True, skip hashing structures during loading.
            skip_lineage: If True, skip assigning lineage information.
            debug: Enable debug mode.
            hash_map: Hash map class.
            agent: Sync agent class.
            lineage: Lineage tracker class.
            constraints: Constraints for Design of Experiments.
            ef_bounds: Energy per atom formation bounds.
            blacklist: List of SMARTS patterns to blacklist.
        """
        self._dataset_path = dataset_path
        self._template_path = template_path
        self._output_path = output_path or '.'
        
        self.collision_factor = collision_factor
        self._filter_duplicates = filter_duplicates
        self._save_duplicates = save_duplicates
        self.size_limit = size_limit
        self.fetch_limit = fetch_limit
        
        self.skip_hashing = skip_hashing
        self.skip_lineage = skip_lineage

        self._db_path: str | None = None
        self.db_path = db_path

        self._db_ro_path: str | None = None
        self.db_ro_path = db_ro_path

        self.ef_bounds = ef_bounds
        self.blacklist_detector = BlacklistDetector(blacklist or [])
        self.debug = debug
        self.seed = seed
        self.logger = logging.getLogger(__name__)

        # Placeholder for Partition objects
        self._datasets = {
            'template': None,
            'dataset': None,
            'generation': None,
            'template_preload': None,
            'dataset_preload': None,
            'selected': None,
            'offspring': None,
        }

        self.hash_map = hash_map() if isinstance(hash_map, type) else hash_map
        self.agent = agent
        self.lineage = lineage() if isinstance(lineage, type) else lineage
        self.DoE = DesignOfExperiments(constraints=constraints)

    # ----------------------------------------------------------------
    # GETTERS/SETTERS
    # ----------------------------------------------------------------
    @property
    def dataset_path(self) -> str | None:
        """Gets the file path for the initial structures."""
        return self._dataset_path

    @dataset_path.setter
    def dataset_path(self, value: str | None) -> None:
        """Sets the file path for the initial structures."""
        self._dataset_path = value

    # --------------------------------------------------------------
    # Writable database path
    # --------------------------------------------------------------
    @property
    def db_path(self) -> Path:
        """Path to the writable database (as a Path object)."""
        return Path(self._db_path or ".")

    @db_path.setter
    def db_path(self, value: str | Path | None) -> None:
        """Set writable database path; create directory if needed."""
        value = Path(value or ".")
        value.mkdir(parents=True, exist_ok=True)
        self._db_path = str(value)

    # --------------------------------------------------------------
    # Read-only database path
    # --------------------------------------------------------------
    @property
    def db_ro_path(self) -> Path:
        """Path to the read-only database (as a Path object)."""
        return Path(self._db_ro_path or "db_ro")

    @db_ro_path.setter
    def db_ro_path(self, value: str | Path | None) -> None:
        """Set read-only database path; create directory if needed."""
        value = Path(value or "db_ro")
        value.mkdir(parents=True, exist_ok=True)
        self._db_ro_path = str(value)


    @property
    def template_path(self) -> str | None:
        """Gets the template file path."""
        return self._template_path

    @template_path.setter
    def template_path(self, value: str | None) -> None:
        """Sets the template file path."""
        self._template_path = value

    @property
    def output_path(self) -> str:
        """Gets the output directory path."""
        return self._output_path

    @output_path.setter
    def output_path(self, value: str) -> None:
        """Sets the output directory path."""
        self._output_path = value

    @property
    def datasets(self) -> dict[str, Any]:
        """Gets the dictionary of partition objects."""
        return self._datasets

    def get_dataset(self, name: str) -> Any:
        """Gets the dictionary of partition objects."""
        return self._datasets[name]

    def get_containers(self, name:str) -> list[Any] | None:
        """Gets the dictionary of partition objects."""
        if name in self._datasets:
            ds = self._datasets[name]
            if ds is not None:
                return list(ds.containers)

        return None

    def set_dataset(self, name: str, dataset: Any = None) -> None:
        """Gets the dictionary of dataset objects."""
        self._datasets[name] = dataset if dataset is not None else Partition()
        return self._datasets[name]

    def dataset_add(self, name:str, dataset:Any) -> bool: 
        """ """
        ds = self._datasets[name]
        if ds is not None:
            ds.add(dataset)
            return True
        return False

    def size(self, name: str | None = None) -> int:
        """
        """
        if name:
            ds_target = self._datasets.get(name)
            if ds_target is None:
                return 0
            return int(getattr(ds_target, "size", 0))
        
        ds = self._datasets.get('dataset')
        return int(getattr(ds, "size", 0)) if ds is not None else 0
 
    def filter(self, name: str, idx: Any) -> Any:
        """
        """
        ds = self.get_dataset(name)
        # Bulk materialize efficiently:
        try:
            pop = ds.materialize_by_ids(
                idx,
                dedup=True,                 # load each id once even if repeated
                sort_backend_reads=True,    # helps HDF5 locality
                independent_duplicates=True
            )
            return pop
        except Exception as e:
            if hasattr(self, "logger") and self.logger:
                self.logger.warning(f"Bulk materialization failed, falling back to one-by-one: {e}")
            
            # Robust recovery: try each ID individually
            valid_containers = []
            for i in idx:
                try:
                    subset = ds.materialize_by_ids(
                        [i],
                        dedup=True,
                        sort_backend_reads=False,
                        independent_duplicates=True
                    )
                    valid_containers.extend(getattr(subset, "containers", subset))
                except Exception as e2:
                    if hasattr(self, "logger") and self.logger:
                        self.logger.error(f"Failed to materialize individual ID {i}: {e2}")
            
            # Reconstruct as a Partition
            new_pop = Partition()
            new_pop.add(valid_containers)
            return new_pop
        #return copy.deepcopy([self.get_dataset(name).containers[i] for i in idx])

    def set_population(self, name: str, population: Any) -> bool:
        """
        """
        self.set_dataset( name, Partition() )
        self.get_dataset(name).add( population )

        return True

    # ----------------------------------------------------------------
    # LOAD
    # ----------------------------------------------------------------
    def load_population(self, logger: ILogger | logging.Logger | None = None, evaluator: Any = None) -> None:
        logger = logger or self.logger
        """
        """

        # ------------------------------------------------------------------
        # 0)  Book‑keeping: log start‑up and start a wall‑clock timer
        # ------------------------------------------------------------------
        if logger:
            logger.info("Loading dataset from files.")

        # ------------------------------------------------------------------
        # 1)  DATASET PARTITION ------------------------------------------------
        # ------------------------------------------------------------------
        # 1.1  Always create an *empty* Partition object first so that we have a
        #      valid container even if subsequent file I/O fails.  This avoids
        #      having to repeat *None* checks later on.
        if not isinstance(self.db_ro_path, (str, Path) ):
            self.db_ro_path = 'db_ro'
        if not isinstance(self.db_path, (str, Path) ):
            self.db_path = '.'

        self.set_dataset( 
            'dataset', 
            Partition(
                storage='composite', # composite # hybrid
                base_root=self.db_ro_path,
                local_root=self.db_path,
            )
        )

        # 1.2  If the caller provided a valid *path* (and not, e.g., ``None`` or
        #      an already‑opened file object), read the structure files.
        if isinstance(self.dataset_path, (str, os.PathLike)):
            
            if self.size_limit:
                self.get_dataset('dataset').read_files(
                    file_location=str(self.dataset_path),
                    verbose=True,
                    sampling='random',
                    n_samples=self.size_limit
                )
            else:
                self.get_dataset('dataset').read_files(
                    file_location=str(self.dataset_path),
                    verbose=True,
                )
            
            # If an evaluator is provided, evaluate the newly read structures
            # to pre-populate their objectives/features and save them to SAGE database.
            if evaluator is not None:
                if logger:
                    logger.info("[load] Evaluating and persisting initial population features & objectives.")
                ds = self.get_dataset('dataset')
                if len(ds) > 0:
                    evaluator.get_features(ds)
                    evaluator.get_objectives(ds)
                
        # 1.3  Merge any *pre‑loaded* containers (prepared by the caller before
        #      invoking this method) into the freshly created partition.
        if isinstance(self.get_dataset('dataset_preload'), list):
            self.dataset_add(name='dataset', dataset=self.get_dataset('dataset_preload'))

        # 1.4  Feed every single *Structure* object into the global hash map so
        #      that the rest of the code base can perform O(1) look‑ups for
        #      de‑duplication or collision tracking.
        if not self.skip_hashing and False:
            for container in tqdm(
                self.get_dataset('dataset').containers,
                desc="[load] Registering structures in hash map",
                unit="struct"
            ):
                self.hash_map.add_structure( container, force_rehash=False )

        # 1.5  If we are running in *synchronised* mode (i.e., multiple workers
        #      on different nodes), pull the current batch of structures from
        #      the synchronisation backend and add only the ones that do *not*
        #      produce a hash collision.
        agent_is_active = False
        if self.agent is not None and not isinstance(self.agent, type):
            try:
                agent_is_active = self.agent.active()
            except Exception:
                agent_is_active = False

        if agent_is_active:
            try: 
                # Use Any to avoid protocol mismatch on fetch_limit
                sync_new = list(self.agent.get_batch(prune=False, fetch_limit=self.fetch_limit))  # type: ignore
                containers_list: list[Any] = []
                for _, sub in sync_new:
                    containers_list.extend(sub.containers)
                unique_structures, not_unique_structures = self.filter_hash_collisions(individuals=containers_list, force_rehash=False)
                self.dataset_add(name='dataset', dataset=unique_structures )

                if logger:
                    logger.info(
                        "Genetic injection: %d structures added to dataset (Gen=%d).",
                        len(unique_structures),         
                        0,    
                    )
            except Exception as exc:
                if hasattr(self, "logger"):
                    self.logger.warning(
                        "[Agentic_Sync] Failed during load_population step: %s", exc, exc_info=True
                    )

        # ------------------------------------------------------------------
        # 2)  TEMPLATE PARTITION ---------------------------------------------
        # ------------------------------------------------------------------
        # 2.1  Create an empty partition exactly as was done for the dataset.
        self.set_dataset('template')
        template_ds = self._datasets.get('template')
        if isinstance(self.template_path, str) and template_ds is not None:
            template_ds.read_files(
                file_location=self.template_path,
                source='xyz',
                verbose=True
            )
        else:
            if logger:
                logger.info("No template file provided, skipping template partition.")

        if isinstance(self.get_dataset('template_preload'), list):
            self.dataset_add(name='template', dataset=self.get_dataset('template_preload'))

        # Every *Structure* gets tagged with lineage metadata so that its origin
        # can be traced throughout the workflow.  Stage‑index *0* indicates the
        # very first step; the empty list is the parent set, and the string
        # "initialization" becomes the *event* label.
        if not self.skip_lineage:
            # Cast to Any to access implementation-specific method
            getattr(self.lineage, "assign_lineage_info_par_partition", lambda *a, **kw: None)(
                self.get_dataset('dataset'),     # partition to annotate
                0,                              # stage index generation
                [],                             # parent UIDs (none at this point)
                "initialization"                # event label
            )

        logger.info(f"Partitions loaded successfully.")

    
    def export_structures(
        self,
        dataset: Any,
        file_path: str,
        sort: bool = False,
        key: int = 0,
        default_label: str = "config",
    ) -> bool:
        """
        Export structures in the given dataset.

        Parameters
        ----------
        dataset : dataset
            Partition containing the structures to export.
        file_path : str
            Either:
              • a directory (no extension) → writes to <dir>/<default_label>.xyz, or
              • a full file path with extension (e.g., *.xyz) → writes exactly there.
        sort : bool
            If True, sort by objective 'key' (ascending) and store objectives in metadata.
        key : int
            Objective column to sort by when sort=True.
        default_label : str
            Used as filename when file_path is a directory.
        """
        p = Path(file_path)

        # Determine output directory and final file path
        if p.suffix:  # looks like a file (has extension)
            out_dir   = p.parent
            out_file  = p
        else:         # looks like a directory
            out_dir   = p
            out_file  = out_dir / f"{default_label}.xyz"

        # Create all needed directories
        out_dir.mkdir(parents=True, exist_ok=True)

        # Optional sorting by objective
        if sort:
            # Fallback for objective_funcs
            obj_funcs = getattr(self, "objective_funcs", None)
            objectives = evaluate_objectives( list(dataset.containers), obj_funcs)
            for container, objective in zip(dataset.containers, objectives):
                apm = container.AtomPositionManager
                if not isinstance(getattr(apm, "metadata", None), dict):
                    apm.metadata = {}
                apm.metadata["objectives"] = list(objective)

            numeric = np.array([float(obj[key]) for obj in objectives])
            order = np.argsort(numeric, kind="mergesort")
            dataset.containers = [dataset.containers[i] for i in order]

        # Write using a full path (what your exporter expects)
        dataset.export_files(
            file_location=str(out_file),  # full path including filename + extension
            source="xyz",
            verbose=True,
        )
        return True


    def agent_sync(
        self, 
        dataset: Any,
        objectives: np.ndarray,
        features: np.ndarray,
        ctx: Any = None,
    ) -> list[Any]:
        """
        Synchronize the local population with the shared multi-agent backend.

        This method implements a fault-tolerant, scalable data-exchange mechanism 
        between workers (agents) in a distributed evolutionary search. It performs
        three tasks: (i) publish locally generated structures, (ii) retrieve unseen
        structures from other workers, and (iii) provide adaptive feedback signals
        (diversity, pressure) to the agent’s communication policy.

        Parameters
        ----------
        dataset : list
            Partition or list-like container holding the newly generated candidate 
            structures to be published to the shared synchronization backend.

        objectives : np.ndarray, shape (N, M)
            Objective matrix for the newly generated individuals. Each row represents
            an individual, and each column corresponds to an objective function to be
            minimized. This array is used to compute a lightweight aggregate measure 
            of selective pressure, which informs the agent’s adaptive communication 
            policy.

        features : np.ndarray, shape (N, F)
            Feature descriptors for the new individuals, used to compute a fast, 
            variance-based proxy for population diversity. This metric is 
            O(NF) and suitable for very large populations (millions of individuals).

        Returns
        -------
        list
            A flat list containing all newly received structure containers obtained
            from the synchronization backend. The list may be empty if no new data
            is available or if the backend is inactive.

        Notes
        -----
        • Fetching uses `get_batch(prune=False)` to avoid filesystem races during
          recursive directory scans on parallel filesystems.

        • Pruning is performed separately, rate-limited, and always wrapped in
          try/except to ensure robustness under concurrent access.

        • The method computes two adaptive metrics:
            - Diversity:    sum_k Var(features[:, k])
            - Pressure:     mean_i ||objectives[i]||

          Both metrics are designed to be mathematically meaningful yet extremely
          inexpensive to compute, allowing real-time policy updates even for 
          populations of size >10⁶.

        • The metrics are passed to `self.agent.update_policy_metrics(...)` which 
          executes the communication policy (e.g. Nash-style best response, 
          adaptive throttling, or any other decision rule implemented in the agent).
        """

        containers = list(dataset.containers)

        # 0) No agent configured
        if not getattr(self, "agent", None):
            if hasattr(self, "logger"):
                self.logger.warning("[Agentic_Sync] No agent configured; skipping sync.")
            return []

        try:
            # ============================================================
            # 1) Check agent readiness
            # ============================================================
            try:
                if not isinstance(self.agent, type) and self.agent.active():
                    pass
                else:
                    if hasattr(self, "logger"):
                        self.logger.warning("[Agentic_Sync] Agent inactive or uninstantiated; skipping sync.")
                    return []
            except Exception as exc:
                if hasattr(self, "logger"):
                    self.logger.warning("[Agentic_Sync] active() failed: %s", exc, exc_info=True)
                return []


            # ============================================================
            # 2) ADAPTIVE POLICY UPDATE  (Nash-response logic)
            # ============================================================
            try:
                # --- diversity metric (simple but robust) ---
                #    distinct total atom counts
                local_div = len(containers)

                # --- pressure metric ---
                incoming_pressure = len(containers)
                # update the internal policies of the agent

                # --- Fast diversity estimate (O(NF)) ---
                try:
                    feats = np.asarray(features, dtype=float)
                    diversity, pressure = self._calculate_sync_metrics(feats, objectives)
                except Exception:
                    diversity, pressure = 0.0, float(len(containers))

                # --- Update policy with rich metrics ---
                if not isinstance(self.agent, type):
                    cc = getattr(self, "convergence_checker", None)
                    extra_metrics = {}
                    if cc:
                        extra_metrics["stall_gens"] = cc.get_stagnation()
                        extra_metrics["novelty_rate"] = cc.discovery_rate
                        extra_metrics["success_rate"] = cc.progress_rate

                    self.agent.update_policy_metrics(
                        diversity=diversity,
                        pressure=pressure,
                        **extra_metrics
                    )
                
            except Exception as exc:
                if hasattr(self, "logger"):
                    self.logger.warning(
                        "[Agentic_Sync] policy update failed: %s",
                        exc,
                        exc_info=True
                    )
                # continue even on policy failure


            # ============================================================
            # 3) Append local candidates to shared backend
            # ============================================================
            # Try appending candidate containers
            try:
                if not isinstance(self.agent, type):
                    self.agent.append(containers)
            except Exception as exc:
                if hasattr(self, "logger"):
                    self.logger.warning(
                        "[Agentic_Sync] Failed during append step: %s", exc, exc_info=True
                    )
                # <-- do NOT return here; proceed to get_batch

            # ============================================================
            # 4) Fetch unseen batches (safe, prune disabled here)
            # ============================================================
            try:
                # Important: consume inside the try so generator exceptions are caught here
                sync_new = list(self.agent.get_batch( prune=False, fetch_limit=self.fetch_limit )) # prune=False

            except Exception as exc:
                if hasattr(self, "logger"):
                    self.logger.warning(
                        "[Agentic_Sync] Failed during get_batch step: %s", exc, exc_info=True
                    )
                return []

            # ============================================================
            # 5) Merge new structures defensively
            # ============================================================
            # Collect all containers from the new dataset
            containers_list: list[Any] = []
            for batch_id, dataset in sync_new:
                try:
                    containers_list.extend(getattr(dataset, "containers", []))
                except Exception as exc:
                    if hasattr(self, "logger"):
                        self.logger.warning(
                            "[Agentic_Sync] Failed while merging containers "
                            "from batch %s: %s", batch_id, exc, exc_info=True
                        )
                    continue

            # ============================================================
            # 6) Controlled, time-gated prune
            # ============================================================
            try:
                if not isinstance(self.agent, type):
                    pruned = self.agent.attempt_prune(interval=60.0, budget=8, min_age=5.0)
                    if pruned and hasattr(self, "logger"):
                        self.logger.debug("[Agentic_Sync] Pruned %d old batches.", pruned)
            except Exception as exc:
                if hasattr(self, "logger"):
                    self.logger.warning("[Agentic_Sync] maybe_prune() failed: %s", exc, exc_info=True)

            # ============================================================
            # 6.5) Update agent behavior based on neighbor states
            # ============================================================
            try:
                if not isinstance(self.agent, type):
                    self.agent.update_behaviour(self, ctx)
            except Exception as exc:
                if hasattr(self, "logger"):
                    self.logger.warning("[Agentic_Sync] update_behaviour() failed: %s", exc, exc_info=True)

            # ============================================================
            # 7) Return newly synchronised structures
            # ============================================================

            return containers_list

        except Exception as exc:
            # ============================================================
            # Final safeguard
            # ============================================================
            # Last-resort safeguard
            if hasattr(self, "logger"):
                self.logger.warning(
                    "[Agentic_Sync] Unexpected failure in agent_sync: %s",
                    exc,
                    exc_info=True,
                )
            return []

    def validate_candidates(self, individuals: list[Any], features: np.ndarray, remove: bool | None = None) -> tuple[list[Any], list[Any]]:
        """
        Validate candidate individuals based on their composition in feature space.

        This method computes feature descriptors for each candidate structure using the provided
        feature functions (self.features_funcs) and then validates each candidate by applying the
        design validator (self.DoE.validate). The validator returns True if the candidate's features
        satisfy the design requirements and False otherwise.

        Parameters
        ----------
        individuals : list
            A list of candidate structure objects to be validated.

        Returns
        -------
        list
            A list of candidate individuals that meet the feature space requirements.
        """

        # 2) Local bindings for speed
        validate = self.DoE.validate if self.DoE else lambda *args, **kwargs: True

        # 3) Single pass: build valid list and penalise invalid
        valid_candidates = []
        physically_invalid_candidates = []
        out_of_doe_candidates = []
        blacklist_invalid_candidates = []

        for struct, feat_val in zip(individuals, features):
            feat: np.ndarray = feat_val
            # 1) DOE‐validation check
            if not self.DoE.validate(features=feat):
                out_of_doe_candidates.append(struct)
                continue  # skip to next structure

            # 2) Physical‐sanity check
            if self.ef_bounds is not None:
                apm = struct.AtomPositionManager
                if apm.E is not None and apm.atomCount != 0:
                    ef_per_atom = apm.E / apm.atomCount
                    if not self.ef_bounds[0] <= ef_per_atom <= self.ef_bounds[1]:
                        physically_invalid_candidates.append(struct)
                        continue

            # 2) blacklist_detector check
            try:
                present, tag = self.blacklist_detector.contains(struct, remove=remove)
            except Exception as ex:
                # Fail-soft: proceed with other checks; optionally log when debug
                if True or self.debug:
                    print(f"[validate_candidates] blacklist check error: {ex}")
                present, tag = (False, None)

            if present:
                # Optionally annotate offending motif for auditability
                apm = struct.AtomPositionManager
                md = getattr(apm, "metadata", None)
                if isinstance(md, dict):
                    md["blacklist_hit"] = tag
                elif hasattr(apm, "metadata"):
                    try:
                        apm.metadata = {"blacklist_hit": tag}
                    except Exception:
                        pass
                blacklist_invalid_candidates.append(struct)
                continue

            # 4) Survives all checks
            valid_candidates.append(struct)

        # --- Export invalid groups (mirroring your existing behavior) ---

        # 3a) Export any out_of_doe invalid individuals
        if out_of_doe_candidates:
            invalid_dataset = Partition()
            invalid_dataset.add_container( out_of_doe_candidates )
            self.export_structures(
                invalid_dataset,
                f'{self.output_path}/out_of_doe.xyz'
            )

        # 3b) Export any physically invalid individuals
        if physically_invalid_candidates:
            invalid_dataset = Partition()
            invalid_dataset.add_container( physically_invalid_candidates )
            self.export_structures(
                invalid_dataset,
                f'{self.output_path}/physically_invalid.xyz'
            )

        if blacklist_invalid_candidates:
            invalid_dataset = Partition()
            invalid_dataset.add_container(blacklist_invalid_candidates)
            self.export_structures(invalid_dataset, f"{self.output_path}/blacklisted.xyz")

        return valid_candidates, out_of_doe_candidates+physically_invalid_candidates+blacklist_invalid_candidates    
    
    
    def filter_hash_collisions(self, individuals: list[Any], force_rehash: bool = True, save_basin: bool | None = None) -> tuple[list[Any], list[Any]]:
        """
        Filters out individuals that collide in the hash map (i.e., duplicates).

        Parameters
        ----------
        individuals : list
            List of candidate individuals after the physical model.
        force_rehash : bool
            If True, recompute the structural hash before comparison.
        save_basin : bool | None
            Whether to write rejected duplicate structures to the basin directory.
            When None (the default), falls back to ``self._save_duplicates`` which
            is set from the ``population.save_duplicates`` config field.
            Pass an explicit bool to override the config for a single call site.

        Returns
        -------
        unique_structures : list
            Structures that are unique (not in the hash map).
        not_unique_structures : list
            Structures that collided with an existing hash.
        """

        def _composition_key(comp: dict[str, int]) -> str:
            """
            Return a deterministic, reduced-formula key such as 'C1-H1-N1-O2'
            for any integer multiple - e.g. both {'C':2,'H':2,'N':2,'O':4}
            and {'C':6,'H':6,'N':6,'O':12} collapse onto the same key.

            • Counts **must** be non-negative integers.  If you store floats,
              cast/round them beforehand.
            • Element order is alphabetical to keep the key canonical.
            """
            counts = [int(comp[el]) for el in comp]
            g = 1 #reduce(gcd, counts) or 1                       # robust gcd
            return "-".join(
                f"{el}{int(comp[el] // g)}"                    # always include '1'
                for el in sorted(comp)
            )

        if not self._filter_duplicates:
            return individuals, []

        # Resolve save_basin: explicit argument wins; otherwise use instance default
        effective_save_basin = self._save_duplicates if save_basin is None else save_basin

        unique_structures = []
        not_unique_structures = []
        for individual in individuals:
            hash_ = self.hash_map.get_hash(individual, force_rehash=force_rehash)

            '''
            # deduplicate a batch of candidate payload-hashes in one shot
            seen = composite_store.has_hashes(batch_hashes)
            new_candidates = [cand for cand in candidates if not seen[cand.hash]]
            '''
            if not self.get_dataset('dataset').has_hash(hash_):
                unique_structures.append(individual)
                continue

            elif force_rehash and effective_save_basin:
                dataset = Partition()
                dataset.add_container(individual)
                
                comp_key = _composition_key(individual.AtomPositionManager.atomCountDict)
                self.export_structures(
                    dataset=dataset,
                    file_path=f'{self._output_path}/basin/{comp_key}/{individual.AtomPositionManager.metadata["hash"]}/config_basin.xyz',
                )

            not_unique_structures.append(individual)

        return unique_structures, not_unique_structures


    def filter_selfcollision(self, individuals: list[Any], remove: bool = False) -> tuple[list[Any], list[Any]]:
        """
        Filters out individuals that have self-collision above the collision factor threshold.

        Parameters
        ----------
        individuals : list
            List of candidate individuals to filter.

        Returns
        -------
        non_colliding : list
            Filtered list of individuals without self-collisions.
        """
        if self.collision_factor is None or self.collision_factor < 1e-6:
            return individuals, []

        # 1) Compute collision mask in one pass (C-optimized list comp)
        mask = []
        for s in individuals:
            try:
                m = s.AtomPositionManager.self_collision(factor=self.collision_factor, remove=remove)
            except Exception:
                # Treat corrupted structures as colliding (to be filtered out)
                m = True
            mask.append(m)

        # 2) Use mask to filter in C-level loops
        non_colliding = [s for s, m in zip(individuals, mask) if not m]
        colliding = [s for s, m in zip(individuals, mask) if m]

        # 3) Export invalid individuals, if any
        if colliding:
            dataset = Partition()
            dataset.add_container( colliding )
            self.export_structures(
                dataset,
                f"{self.output_path}/selfcollision.xyz"
            )

        return non_colliding, colliding


    def update_main_dataset(
        self,
        dataset: Any,
        generation: int,
        features_prev: np.ndarray,
        objectives_prev: np.ndarray,
    ) -> int:
        """
        Updates the main dataset with new structures and records the structure IDs and generations.

        Parameters
        ----------
        dataset : object
            Newly generated unique structures.
        generation : int
            Current generation index.
        """

        cap  = self.size_limit
        ds   = self.get_dataset("dataset")
        discard_structs = []

        ds_size = ds.size if hasattr(ds, "size") else len(ds)
        dataset_size = dataset.size if hasattr(dataset, "size") else len(dataset)

        if not cap is None:
            # --- Global size population control --------------------------
            needed_size = ds_size + dataset_size
            if needed_size > cap: 
                excess = int(needed_size - cap)

                old_containers   = list(ds.containers)

                # --- Rank only the *old* population --------------------------
                num_objs = objectives_prev.shape[1] if objectives_prev.ndim > 1 else 1
                if num_objs > 1:
                    # Multi-objective Pareto pruning
                    from ezga.selection.selector import Selector
                    # We pick 'cap - dataset_size' survivors from the 'old' population
                    survivor_count = int(max(0, cap - dataset_size))
                    sel = Selector(size=survivor_count, random_seed=self.seed)
                    
                    # NSGA3 uses both objectives and features for niching
                    idx_keep = sel.NSGA3(objectives_prev, features_prev, size=survivor_count)
                    
                    idx_all = np.arange(len(old_containers))
                    idx_bad = np.setdiff1d(idx_all, idx_keep)
                else:
                    # Single objective weighted sum (original behavior)
                    w       = np.ones(num_objs)
                    scores  = (objectives_prev @ w) if num_objs > 1 or objectives_prev.ndim > 1 else objectives_prev
                    idx_bad = np.argsort(scores)[-excess:]         # worst performers
                
                bad_indices: list[int] = [int(i) for i in idx_bad if i < len(old_containers)]
                
                # Build keep / discard lists
                discard_structs  = [old_containers[i] for i in bad_indices]
                keep_structs_old = [
                    c for i, c in enumerate(old_containers) if i not in bad_indices
                ]

                # Export the overflow
                if discard_structs:
                    overflow = Partition()
                    overflow.add_container(discard_structs)
                    overflow.export_files(
                        file_location=f"{self.output_path}/config_overflow.xyz",
                        source="xyz",
                        label="enumerate",
                        verbose=True,
                    )

                # Replace the dataset with survivors
                try:
                    if len(bad_indices) > 0:
                        ds.remove(bad_indices)
                except Exception:
                    # Fallback for CompositeHybridStorage which might not support remove
                    # We create a new in-memory partition for the survivors
                    self.set_dataset('dataset', Partition())
                    self.get_dataset('dataset').add(keep_structs_old)
                    ds = self.get_dataset('dataset')

        # --- 2) Insert the new generation (always survives) -------------- ###
        if dataset_size > 0:
            ds.add( list(dataset.containers) if hasattr(dataset, "containers") else list(dataset) )
        
        return len(discard_structs)

    def _calculate_sync_metrics(self, feats: np.ndarray, objectives: np.ndarray) -> tuple[float, float]:
        """
        Calculates diversity and pressure metrics for agent synchronization.
        """
        try:
            if feats is not None and feats.shape[0] > 1:
                # Sum of variances = proxy for E||X−Y||²
                diversity = float(feats.var(axis=0).sum())
            else:
                diversity = 0.0
        except Exception:
            diversity = 0.0

        try:
            objs = np.asarray(objectives, dtype=float)
            if objs.shape[0] > 0:
                # Mean magnitude of objective vectors
                pressure = float(np.linalg.norm(objs, axis=1).mean())
            else:
                pressure = 0.0
        except Exception:
            pressure = 0.0
            
        return diversity, pressure
        