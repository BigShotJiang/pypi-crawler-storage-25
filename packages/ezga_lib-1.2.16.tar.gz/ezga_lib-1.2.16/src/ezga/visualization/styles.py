from __future__ import annotations
import matplotlib.pyplot as plt


def apply_scientific_style():
    """
    Applies a clean, high-contrast style suitable for scientific publications.
    """
    try:
        plt.style.use("seaborn-v0_8-whitegrid")
    except:
        plt.style.use("whitegrid")

    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Inter", "Roboto", "Arial", "DejaVu Sans"],
            "axes.titlesize": 14,
            "axes.labelsize": 12,
            "xtick.labelsize": 10,
            "ytick.labelsize": 10,
            "legend.fontsize": 10,
            "figure.titlesize": 16,
            "figure.dpi": 200,
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.1,
            "axes.grid": True,
            "grid.alpha": 0.3,
        }
    )


# Global premium palettes
COLORS = ["#4361EE", "#3F37C9", "#4895EF", "#7209B7", "#B5179E", "#F72585"]
GRADIENTS = [
    "#4CC9FE",
    "#4361EE",
    "#3F37C9",
    "#3A0CA3",
    "#480CA8",
    "#560BAD",
    "#7209B7",
    "#B5179E",
    "#F72585",
]
