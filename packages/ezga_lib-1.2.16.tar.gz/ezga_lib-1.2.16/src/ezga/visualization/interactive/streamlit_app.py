from __future__ import annotations
import os

import streamlit as st

from ezga.visualization.api import load_evolution_history, plot_evolution_summary


def main():
    st.set_page_config(page_title="EZGA Evolution Explorer", layout="wide", page_icon="🧬")

    st.title("🧬 Evolutionary Structure Explorer Dashboard")
    st.markdown("---")

    # 1. Configuration
    st.sidebar.header("Explore Search Logs")
    log_dir = st.sidebar.text_input("Log Directory", value="logs")

    if not os.path.exists(log_dir):
        st.sidebar.error("Directory not found!")
        st.stop()

    # 2. Main Analytics
    st.header("Search Dynamics")
    try:
        col1, col2 = st.columns([3, 1])

        with col1:
            fig, _ = plot_evolution_summary(log_dir)
            st.pyplot(fig)

        with col2:
            history = load_evolution_history(log_dir)
            st.metric(
                "Final Best Fitness",
                f"{history.generations[-1].fitness_min:.3f}" if history.generations else "N/A",
            )
            st.metric(
                "Total Structures",
                f"{history.generations[-1].population_size}" if history.generations else "N/A",
            )
            st.metric("Total Generations", f"{len(history.generations)}")

    except Exception as e:
        st.error(f"Failed to generate dashboard: {e}")


if __name__ == "__main__":
    main()
