from __future__ import annotations
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt

# 2. Main High-Level Composites
from ezga.visualization.figures.dashboard import build_summary_dashboard
from ezga.visualization.plots.snapshot.distributions import plot_fitness_distribution

# 4. Atomic Diagnostic Plots (Re-exported from Plots subtree)
from ezga.visualization.plots.temporal.fitness import (
    plot_fitness_convergence,
    plot_stall_behavior,
)
from ezga.visualization.plots.temporal.operators import plot_adaptive_operators

# 3. Dedicated Preprocessing & Loading
from ezga.visualization.preprocessing.history import load_evolution_history

# 1. Base Types & Structures
from ezga.visualization.types import EvolutionHistory, GenerationData


def plot_evolution_summary(logger_dir: str | Path, output_path: str | Path | None = None) -> tuple[plt.Figure, Any]:
    """
    Main entry point for generating a professional, multi-panel diagnostic report from logs.

    Args:
        logger_dir: Directory containing generation JSON logs.
        output_path: Optional filename (e.g. 'summary.png') to save the report.

    Returns:
        (fig, axes): The generated Matplotlib figure and axis objects.
    """
    logger = logging.getLogger(__name__)
    logger.info(f"Generating evolutionary summary from {logger_dir}")

    # 1. Standardized Loading
    history = load_evolution_history(logger_dir)

    # 2. Figure Composition
    fig, axes = build_summary_dashboard(history)

    # 3. Persistence
    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, bbox_inches="tight")
        logger.info(f"Dashboard saved to: {out}")

    return fig, axes


# Re-expose all common utilities for __init__.py and Plotter module access
__all__ = [
    "EvolutionHistory",
    "GenerationData",
    "load_evolution_history",
    "build_summary_dashboard",
    "plot_evolution_summary",
    "plot_fitness_convergence",
    "plot_stall_behavior",
    "plot_adaptive_operators",
    "plot_fitness_distribution",
]
