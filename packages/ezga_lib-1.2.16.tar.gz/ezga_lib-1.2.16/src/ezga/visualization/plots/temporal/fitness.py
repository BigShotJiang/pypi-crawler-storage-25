from __future__ import annotations

import matplotlib.pyplot as plt

from ezga.visualization.styles import COLORS
from ezga.visualization.types import EvolutionHistory


def plot_fitness_convergence(history: EvolutionHistory, ax: plt.Axes | None = None) -> tuple[plt.Figure, plt.Axes]:
    """Plots min/mean fitness evolution across generations."""
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 6))
    else:
        fig_obj = ax.get_figure(); fig = fig_obj if fig_obj is not None else plt.gcf()

    gens = history.indices
    mins = history.best_fitness_series
    means = history.mean_fitness_series

    if len(gens) == 0:
        ax.text(0.5, 0.5, "No data to plot", ha="center", va="center")
        return fig, ax

    # Plot lines with premium colors
    ax.plot(gens, means, "o--", color=COLORS[0], label="Mean Fitness", alpha=0.3, markersize=3)
    ax.plot(gens, mins, "-", color=COLORS[1], linewidth=3, label="Best Fitness")
    ax.fill_between(gens, mins, means, color=COLORS[0], alpha=0.1)

    ax.set_title("Fitness Convergence", pad=15)
    ax.set_xlabel("Generation Index")
    ax.set_ylabel("Fitness (lower is better)")
    ax.legend(frameon=True, fancybox=True, shadow=True)

    return fig, ax


def plot_stall_behavior(history: EvolutionHistory, ax: plt.Axes | None = None) -> tuple[plt.Figure, plt.Axes]:
    """Visualizes stagnancy (stall counts) vs time."""
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 6))
    else:
        fig_obj = ax.get_figure(); fig = fig_obj if fig_obj is not None else plt.gcf()

    gens = history.indices
    stalls = history.stall_count_series

    if len(gens) == 0:
        return fig, ax

    # Step plot for discrete stall increments
    ax.step(gens, stalls, where="post", color=COLORS[5], alpha=0.8, lw=2, label="Stagnation Count")
    ax.set_title("Exploration Stagnancy (Stalls)", pad=15)
    ax.set_xlabel("Generation")
    ax.set_ylabel("Stall Count")
    ax.legend()

    return fig, ax
