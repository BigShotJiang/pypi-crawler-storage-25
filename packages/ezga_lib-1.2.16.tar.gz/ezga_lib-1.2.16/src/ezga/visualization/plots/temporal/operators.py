from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np

from ezga.visualization.types import EvolutionHistory


def plot_adaptive_operators(history: EvolutionHistory, ax: plt.Axes | None = None) -> tuple[plt.Figure, plt.Axes]:
    """Visualizes how mutation or crossover operator probabilities evolved."""
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 6))
    else:
        _fig = ax.get_figure()
        fig = _fig if _fig is not None else plt.gcf()

    gens = history.indices
    if len(gens) == 0:
        return fig, ax

    # Extract multidimensional rate history (N_gen, M_ops)
    rates = []
    for g in history.generations:
        rates.append(g.mutation_rates)

    if not rates or not all(rates):
        return fig, ax

    # Convert to regular array with padding
    maxlen = max(len(r) for r in rates)
    arr = np.zeros((len(rates), maxlen))
    for i, r in enumerate(rates):
        l = min(len(r), maxlen)
        arr[i, :l] = r[:l]

    # Plot series for each operator
    for j in range(maxlen):
        ax.plot(gens, arr[:, j], label=f"Op {j}", alpha=0.7, lw=2)

    ax.set_title("Adaptive Decision Dynamics (Mutation)", pad=15)
    ax.set_xlabel("Generation")
    ax.set_ylabel("Selection Probability")
    ax.legend(bbox_to_anchor=(1.05, 1), loc="upper left", frameon=False)
    ax.set_ylim(0, 1.05)

    return fig, ax
