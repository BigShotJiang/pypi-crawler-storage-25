from __future__ import annotations
from __future__ import annotations

import matplotlib.pyplot as plt
import seaborn as sns

from ezga.visualization.styles import COLORS
from ezga.visualization.types import GenerationData


def plot_fitness_distribution(gen: GenerationData, ax: plt.Axes | None = None) -> tuple[plt.Figure, plt.Axes]:
    """Plots histogram/KDE of population fitness for a single generation."""
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 6))
    else:
        fig_obj = ax.get_figure()
        fig = fig_obj if fig_obj is not None else plt.gcf()

    # Extract all first-column objectives
    if gen.objectives.size == 0:
        return fig, ax

    # First objective
    fitnesses = gen.objectives[:, 0]

    # Combined histogram and kernel density
    sns.histplot(fitnesses, kde=True, ax=ax, color=COLORS[0], lw=2, alpha=0.4, label="Distribution")

    # Annotate best and mean
    ax.axvline(gen.fitness_min, color=COLORS[5], linestyle="--", lw=2, label=f"Best: {gen.fitness_min:.3f}")
    ax.axvline(
        gen.fitness_mean,
        color=COLORS[1],
        linestyle=":",
        lw=2,
        label=f"Mean: {gen.fitness_mean:.3f}",
    )

    ax.set_title(f"Gen {gen.index}: Fitness Distribution", pad=15)
    ax.set_xlabel("Fitness (Energy/Score)")
    ax.set_ylabel("Population Frequency")
    ax.legend()

    return fig, ax
