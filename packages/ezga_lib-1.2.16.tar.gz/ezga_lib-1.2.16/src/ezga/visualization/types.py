from __future__ import annotations
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np


@dataclass
class GenerationData:
    """Standardized representation of a single generation's snapshot data."""

    index: int
    population_size: int
    objectives: np.ndarray  # (N, K)
    features: np.ndarray  # (N, F)
    fitness_mean: float
    fitness_min: float
    stall_count: int
    mutation_rates: list[float] = field(default_factory=list)
    crossover_rates: list[float] = field(default_factory=list)
    temperature: float = 1.0
    novelty: float = 0.0
    novelty_threshold: float = 0.0
    compositions: list[dict[str, float]] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class EvolutionHistory:
    """Historical aggregate of an entire evolutionary run."""

    generations: list[GenerationData] = field(default_factory=list)

    @property
    def indices(self) -> np.ndarray:
        return np.array([g.index for g in self.generations])

    @property
    def best_fitness_series(self) -> np.ndarray:
        return np.array([g.fitness_min for g in self.generations])

    @property
    def mean_fitness_series(self) -> np.ndarray:
        return np.array([g.fitness_mean for g in self.generations])

    @property
    def stall_count_series(self) -> np.ndarray:
        return np.array([g.stall_count for g in self.generations])

    @property
    def dataset_size_series(self) -> np.ndarray:
        return np.array([g.population_size for g in self.generations])

    def get_generation(self, index: int) -> GenerationData | None:
        for g in self.generations:
            if g.index == index:
                return g
        return None
