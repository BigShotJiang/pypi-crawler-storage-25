from __future__ import annotations
import json
import logging
from pathlib import Path

import numpy as np

from ezga.visualization.types import EvolutionHistory, GenerationData


def load_evolution_history(logger_dir: str | Path) -> EvolutionHistory:
    """
    Parses a directory of generation-level JSON logs into a structured EvolutionHistory object.

    This function handles:
    - Path validation
    - JSON parsing and decoding
    - Sorting by generation index
    - Mapping diverse JSON fields to standardized GenerationData
    - Handling incomplete or corrupted files gracefully
    """
    path = Path(logger_dir)
    if not path.exists() or not path.is_dir():
        raise FileNotFoundError(f"Logger directory {path} not found or inaccessible.")

    log_files = sorted(list(path.glob("*.json")))
    if not log_files:
        return EvolutionHistory()

    all_generations = []
    logger = logging.getLogger(__name__)

    for f in log_files:
        try:
            with open(f, encoding="utf-8") as json_file:
                blob = json.load(json_file)

                # Extract core fields with safe defaults
                idx = int(blob.get("generation", -1))
                if idx == -1:
                    continue

                pop = blob.get("population", [])
                objs = np.array(blob.get("objectives", []))
                feats = np.array(blob.get("features", []))

                # Composition collection
                compositions = []
                for p in pop:
                    if isinstance(p, dict) and "composition" in p:
                        compositions.append(p["composition"])

                # Calculate aggregate fitness
                if objs.size > 0:
                    # (Assume first column is main fitness if multi-objective)
                    f_main = objs[:, 0]
                    f_min = float(np.min(f_main))
                    f_mean = float(np.mean(f_main))
                else:
                    f_min = f_mean = 0.0

                gen = GenerationData(
                    index=idx,
                    population_size=int(blob.get("num_structures_in_dataset", 0)),
                    objectives=objs,
                    features=feats,
                    fitness_min=f_min,
                    fitness_mean=f_mean,
                    stall_count=int(blob.get("stall_count", 0)),
                    mutation_rates=blob.get("mutation_rate_history", []),
                    crossover_rates=blob.get("crossover_rate_history", []),
                    temperature=float(blob.get("T", 1.0)),
                    novelty=float(blob.get("novelty_history", 0.0)),
                    novelty_threshold=float(blob.get("novelty_thresh_history", 0.0)),
                    compositions=compositions,
                    raw=blob,
                )
                all_generations.append(gen)

        except json.JSONDecodeError as exc:
            # Re-raise decoder errors as expected by tests
            raise exc
        except Exception as e:
            logger.warning(f"Unexpected error parsing {f}: {e}")
            continue

    # Return sorted history
    sorted_gens = sorted(all_generations, key=lambda x: x.index)
    return EvolutionHistory(generations=sorted_gens)
