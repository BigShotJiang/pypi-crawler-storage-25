from __future__ import annotations
from typing import Any

import matplotlib.pyplot as plt

from ezga.visualization.plots.temporal.fitness import (
    plot_fitness_convergence,
    plot_stall_behavior,
)
from ezga.visualization.plots.temporal.operators import plot_adaptive_operators
from ezga.visualization.styles import apply_scientific_style
from ezga.visualization.types import EvolutionHistory


def build_summary_dashboard(history: EvolutionHistory) -> tuple[plt.Figure, Any]:
    """
    Combines core evolutionary metrics into a single, professional diagnostic panel.

    Includes:
    - Convergence (Fitness)
    - Discovery (Dataset Size)
    - Stagnancy (Stalls)
    - Adaptivity (Operator Rates)
    """
    apply_scientific_style()

    fig, axes = plt.subplot_mosaic(
        [["fitness", "fitness", "stalls"], ["operators", "operators", "operators"]],
        figsize=(16, 12),
        gridspec_kw={"height_ratios": [1, 0.8]},
    )

    fig.suptitle("Evolutionary Structure Exploration: Summary Dashboard", fontsize=18, y=1.02)

    # Fill temporal panels
    plot_fitness_convergence(history, ax=axes["fitness"])
    plot_stall_behavior(history, ax=axes["stalls"])
    plot_adaptive_operators(history, ax=axes["operators"])

    # Dataset size vs Gen (Mini-panel override on stalls or own plot?)
    # Add secondary Y for dataset size on fitness plot?
    ax_fitness = axes["fitness"]
    ax_size: Any = ax_fitness.twinx()
    ax_size.plot(
        history.indices,
        history.dataset_size_series,
        color="tab:blue",
        lw=2,
        alpha=0.5,
        linestyle="-.",
    )
    ax_size.set_ylabel("Total Discovered Structures", color="tab:blue", labelpad=15)
    ax_size.tick_params(axis="y", labelcolor="tab:blue")
    ax_size.grid(False)  # Hide dual grid for clarity

    fig.tight_layout()
    return fig, axes
