
from __future__ import annotations
import numpy as np
from typing import Any, Sequence, cast

from ..core.interfaces import (
    IThermostat,
)
from ..utils.helper_functions import (
    decay_factor,
    oscillation_factor,
)

_EPS = 1e-12


class Thermostat(IThermostat):
    """
    The Thermostat class manages and updates a "temperature" parameter
    within a genetic algorithm (GA). It supports periodic oscillations,
    exponential decay, and adaptive adjustments based on performance metrics
    or consecutive failures. It also includes functionality to clamp the
    temperature within predefined bounds.

    Attributes
    ----------
    initial_temperature : float
        Base temperature used for initialization and resets.
    current_temperature : float
        The most recently computed temperature value.
    decay_rate : float
        Rate at which the temperature decays over generations.
    period : float
        Period for oscillatory temperature adjustments.
    increase_factor : float
        Scaling factor for temperature increases when performance is below a threshold.
    decrease_factor : float
        Scaling factor for temperature decreases when performance is above a threshold.
    threshold : float
        Performance threshold controlling whether to increase or decrease the temperature.
    temperature_bounds : tuple of float
        Lower and upper limits on the temperature (inclusive).
    consecutive_failures : int
        Tracks the number of consecutive failures, used to adapt the temperature.
    reset_count : int
        Tracks how many times the thermostat has been reset.
    """

    def __init__(
        self,
        initial_temperature: float,
        decay_rate: float = 0.01,
        period: float = 40.0,
        temperature_bounds: tuple[float, float] = (0.0, 1.1),
        max_stall_offset: float = 1.0,
        stall_growth_rate=0.05,
        constant_temperature: bool = False,
    ):
        """
        Initializes the Thermostat with default parameters for decay, oscillation,
        adaptive updates, and clamping.

        Parameters
        ----------
        initial_temperature : float
            The starting temperature of the system.
        decay_rate : float, optional
            Exponential decay rate applied to temperature over generations (default=0.01).
        period : float, optional
            Period for oscillatory adjustments (default=40.0).
        cooling_rate : float, optional
            Amount to subtract from the temperature if there are no failures (default=0.01).
        failure_increment : float, optional
            Base amount to add (per failure) to the temperature if there are consecutive
            failures (default=0.05).
        temperature_bounds : Tuple[float, float], optional
            Lower and upper bounds for clamping the temperature (default=(0.0, 2.0)).
        """
        if temperature_bounds[0] > temperature_bounds[1]:
            raise ValueError("Lower bound of temperature cannot exceed upper bound.")

        self.initial_temperature = initial_temperature
        self.current_temperature = initial_temperature

        self.decay_rate = decay_rate
        self.period = period
        self.temperature_bounds = temperature_bounds

        self.consecutive_stall = 0
        self.reset_count = 0

        self.max_stall_offset = max_stall_offset
        self.stall_growth_rate = stall_growth_rate

        self.constant_temperature = constant_temperature

    def get_temperature(
        self,
    ) -> float:
        """ """
        return self.current_temperature

    def update(self, generation: int, stall: int = 0, signals=None) -> float:
        """
        Update the global exploration temperature of the evolutionary search.

        This method combines two complementary temperature control mechanisms:

        1. Deterministic scheduler
        A predefined temperature schedule based on exponential annealing
        and periodic oscillation. This ensures predictable exploration
        behaviour during the early generations of the algorithm.

        2. Adaptive thermostat
        A feedback controller driven by convergence diagnostics. It
        increases exploration when the search stagnates and decreases
        exploration when the search is progressing well.

        The final temperature is obtained by blending both components using
        a generation-dependent mixing coefficient. Early generations rely
        more strongly on the deterministic scheduler, while later generations
        become increasingly controlled by adaptive signals.

        Parameters
        ----------
        generation : int
            Current generation index of the evolutionary search.

        stall : int
            Number of consecutive generations without objective improvement.
            This value is typically provided by the convergence monitor.

        signals : optional
            ConvergenceSignals object providing real-time optimization
            diagnostics. Expected attributes include:

            - discovery_rate : float
                Smoothed rate of newly discovered structures.
            - progress_rate : float
                Smoothed rate of objective improvements.
            - stall_fraction : float
                Normalized stagnation indicator in [0, 1].

            If signals are not provided, the thermostat falls back to the
            deterministic scheduler only.

        Returns
        -------
        float
            Updated temperature value. The temperature is dimensionless and
            constrained within ``temperature_bounds``.

        Notes
        -----
        Temperature acts as a global exploration parameter:

        - High temperature → strong exploration
        - Low temperature → strong exploitation

        The temperature should typically be interpreted by other modules,
        such as mutation operators, foreigner generation, or selection
        softness.
        """

        # ------------------------------------------------------------------
        # Constant temperature mode
        # ------------------------------------------------------------------
        # In this mode the thermostat behaves as a fixed parameter and all
        # adaptive logic is bypassed.
        if self.constant_temperature:
            return self.current_temperature

        # ------------------------------------------------------------------
        # 1. Deterministic temperature scheduler
        # ------------------------------------------------------------------
        # This component reproduces the historical behaviour of the thermostat.
        # It combines exponential cooling with a periodic oscillation used to
        # trigger occasional exploration bursts.

        decay = decay_factor(
            decay_rate=self.decay_rate,
            generation=generation,
        )

        oscillation = oscillation_factor(
            period=self.period,
            generation=generation,
        )

        deterministic_temperature = decay * oscillation + self.stall_coefficient()

        # ------------------------------------------------------------------
        # 2. Adaptive temperature component
        # ------------------------------------------------------------------
        # This controller reacts to the current optimization dynamics.
        # Exploration pressure increases when:
        #
        #   - the search stagnates
        #   - few new structures are discovered
        #   - objective progress slows down

        if signals is not None:
            discovery_rate = float(getattr(signals, "discovery_rate", 0.0))
            progress_rate = float(getattr(signals, "progress_rate", 0.0))
            stall_fraction = float(getattr(signals, "stall_fraction", 0.0))

            # ------------------------------------------------------------------
            # Exploration pressure
            #
            # A normalized scalar in [0,1] indicating how strongly exploration
            # should be increased. High values correspond to stagnation.
            # ------------------------------------------------------------------

            exploration_pressure = (stall_fraction + (1.0 - progress_rate) + (1.0 - discovery_rate)) / 3.0

            # ------------------------------------------------------------------
            # Smooth the adaptive temperature using exponential filtering.
            # This avoids abrupt temperature fluctuations due to noisy signals.
            # ------------------------------------------------------------------

            smoothing = 0.1

            if not hasattr(self, "_adaptive_temperature"):
                self._adaptive_temperature = exploration_pressure

            self._adaptive_temperature = (
                1.0 - smoothing
            ) * self._adaptive_temperature + smoothing * exploration_pressure

            adaptive_temperature = self._adaptive_temperature

        else:
            adaptive_temperature = deterministic_temperature

        # ------------------------------------------------------------------
        # 3. Blend deterministic and adaptive components
        # ------------------------------------------------------------------
        # The adaptive controller gradually takes control as the search
        # progresses. This ensures stability during early generations while
        # allowing signal-driven exploration later.

        tau = 200.0  # transition timescale
        adaptive_weight = generation / (generation + tau)

        blended_temperature = (
            1.0 - adaptive_weight
        ) * deterministic_temperature + adaptive_weight * adaptive_temperature

        # ------------------------------------------------------------------
        # 4. Final temperature update
        # ------------------------------------------------------------------
        if stall > 0:
            self.consecutive_stall += 1
        else:
            self.consecutive_stall = 0

        self.current_temperature = blended_temperature
        self.clamp_temperature()

        return self.current_temperature

    actualizate_temperature = update

    def stall_coefficient(self, function: str = "") -> float:
        r"""
        Compute a bounded stall offset that oscillates with consecutive failures.

        This method produces an additive offset \\(S(c)\\) that grows from zero up to
        a maximum \\(M_{\max}\\) as the internal stall counter \\(c = \texttt{self.consecutive_stall}\\)
        increases, and then symmetrically decays, forming a triangular wave over two
        “stall‐growth” cycles.

        Let
        - \\(c\\) be the current stall count (an integer),
        - \\(\gamma = \texttt{self.stall_growth_rate}\\) be the stall growth rate,
        - \\(M_{\max} = \texttt{self.max_stall_offset}\\) be the maximum offset,
        - \\(C = \frac{2}{\gamma}\\) be the full cycle length (number of stalls for a full rise+fall),
        - \\(H = C/2\\) be the half‐cycle (rise or fall).

        Define the **phase** within the cycle as
        .. math::
           \phi = c \bmod C,\quad \phi\in[0,\,C).

        Then the stall coefficient is
        .. math::
           S(c) =
           \begin{cases}
              M_{\max}\,\dfrac{\phi}{H}, & 0 \le \phi \le H,\\[8pt]
              M_{\max}\,\Bigl(1 - \dfrac{\phi - H}{H}\Bigr), & H < \phi < 2H.
           \end{cases}

        This triangular waveform ensures that \\(0 \le S(c)\le M_{\max}\\)
        and resets after every \\(2H\\) stalls.

        :returns:
            A float stall coefficient \\(S(c)\\) bounded in \\([0,\,M_{\max}]\\).
        :rtype: float
        """

        # Use an exponential saturation function.
        full_cycle = int(2.0 / (self.stall_growth_rate + _EPS))
        phase = self.consecutive_stall % full_cycle
        half_cycle = full_cycle // 2

        if phase <= half_cycle:
            coef = self.max_stall_offset * (phase / half_cycle)
        else:
            coef = self.max_stall_offset * (1 - ((phase - half_cycle) / half_cycle))

        return coef
        # return self.max_stall_offset * (1 - np.exp(-self.stall_growth_rate * self.consecutive_stall))

    def clamp_temperature(self):
        """
        Ensures the current temperature remains within the predefined bounds.
        If it falls outside, it is clamped to the min or max limit.
        """
        lower, upper = self.temperature_bounds
        if self.current_temperature < lower:
            self.current_temperature = lower
        elif self.current_temperature > upper:
            self.current_temperature = upper

    def force_max_temperature(self) -> float:
        """
        Forces the temperature to the maximum allowed bound, useful if the GA
        is stuck and an aggressive exploration phase is needed.

        Returns
        -------
        float
            The temperature after forcing it to the upper bound.
        """
        _, upper = self.temperature_bounds
        self.current_temperature = upper
        return self.current_temperature

    def force_min_temperature(self) -> float:
        """
        Forces the temperature to the minimum allowed bound, useful if
        the system is moving too randomly and needs to be reined in.

        Returns
        -------
        float
            The temperature after forcing it to the lower bound.
        """
        lower, _ = self.temperature_bounds
        self.current_temperature = lower
        return self.current_temperature

    def reset(self):
        """
        Resets the current temperature and consecutive failure count to the
        initial conditions. Additionally, increments an internal counter that
        tracks how many resets have been performed.
        """
        self.current_temperature = self.initial_temperature
        self.consecutive_stall = 0
        self.reset_count += 1

    def simulate(
        self,
        generations: int = 1000,
        stall_sequence: Sequence[int] | None = None,
        signals_sequence: Sequence[Any] | None = None,
        reset: bool = True,
    ) -> dict[str, np.ndarray]:
        """
        Simulate the temperature evolution under specified conditions.

        Parameters
        ----------
        generations : int
            Number of generations to simulate.
        stall_sequence : Sequence[int], optional
            Sequence of stall signals (0 or 1) for each generation.
        signals_sequence : Sequence[Any], optional
            Sequence of signals objects for adaptive behavior.
        reset : bool, optional
            Whether to reset the thermostat state before starting (default=True).

        Returns
        -------
        dict[str, np.ndarray]
            Dictionary containing 'generations', 'temperatures', and 'stall_counts'.
        """
        if reset:
            self.reset()

        gens = np.arange(generations)
        temps = np.zeros(generations)
        stalls = np.zeros(generations)

        for g in gens:
            idx = int(g)
            stall = stall_sequence[idx] if stall_sequence is not None and idx < len(stall_sequence) else 0
            signals = (
                signals_sequence[idx]
                if signals_sequence is not None and idx < len(signals_sequence)
                else None
            )

            t = self.update(generation=idx, stall=int(stall), signals=signals)
            temps[g] = t
            stalls[g] = float(self.consecutive_stall)

        return {
            "generations": gens,
            "temperatures": temps,
            "stall_counts": stalls,
        }

    def evaluate_temperature_over_generations(
        self, max_generations: int = 1000
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Predicts temperature evolution. Maintains compatibility with legacy plotting tests.
        """
        res = self.simulate(generations=max_generations)
        # Compatibility with the test expecting range(1, max_generations)
        # Note: the test expects 249 items for max_generations=250
        return res["generations"][1:], res["temperatures"][1:]

    def record_temperature_evolution(
        self, generations: int, performance_metrics: list[float] | None = None
    ) -> list[float]:
        """
        Records temperature evolution. Neutral performance is assumed if metrics are None.
        """
        # If performance_metrics are provided as a list of floats, 
        # we treat them as stall indicators (1 if performance is 'bad', 0 otherwise)
        # or we could map them to a dummy signals object.
        stall_seq = None
        if performance_metrics is not None:
             # Heuristic: if metric < 0.5, count as stall
             stall_seq = [1 if m < 0.5 else 0 for m in performance_metrics]
        
        res = self.simulate(generations=generations, stall_sequence=stall_seq)
        return cast(list[float], res["temperatures"].tolist())
