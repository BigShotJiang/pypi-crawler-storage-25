from __future__ import annotations
import numpy as np
from scipy.optimize import minimize as scipy_minimize
from typing import Any, List, Tuple
from ezga.simple.grammar import OptimizableConstant, Node

class ConstantRefiner:
    """
    Memetic optimization layer for symbolic models.
    Tunes 'OptimizableConstant' values using OLS (analytical) or BFGS (numerical).
    """

    @staticmethod
    def get_optimizable_nodes(tree: Node) -> List[OptimizableConstant]:
        """Returns all OptimizableConstant nodes in the tree."""
        nodes = []
        for node in tree.get_all_nodes():
            if isinstance(node, OptimizableConstant):
                nodes.append(node)
        return nodes

    def refine(self, tree: Node, engine: Any, X: np.ndarray, y: np.ndarray, 
               method: str = "L-BFGS-B", max_iter: int = 50, tol: float = 1e-6, 
               n_restarts: int = 0, X_target: np.ndarray | None = None, y_target: np.ndarray | None = None) -> Node:
        """
        Main entry point for constant refinement with controllable intensity.
        1. Attempts Analytical OLS first (if linear).
        2. Falls back to numerical optimization with optional restarts.
        """
        opt_nodes = self.get_optimizable_nodes(tree)
        if not opt_nodes:
            return tree

        # Use target data if provided (e.g. for Weak Formulation)
        Xt = X_target if X_target is not None else X
        yt = y_target if y_target is not None else y

        # 1. Analytical OLS (microseconds, very stable)
        try:
            linear_params = self._analytical_ols(tree, engine, X, yt, opt_nodes, X_target=X_target)
            if linear_params is not None:
                self._set_params(opt_nodes, linear_params)
                return tree
        except:
            pass

        # 2. Numerical BFGS Optimization
        try:
            self._numerical_optimization(tree, engine, X, yt, opt_nodes, method, max_iter, tol, n_restarts, X_target=X_target)
        except:
            pass
            
        return tree

    def _analytical_ols(self, tree: Node, engine: Any, X: np.ndarray, y: np.ndarray, opt_nodes: List[OptimizableConstant], X_target: np.ndarray | None = None) -> np.ndarray | None:
        """
        Solves for constants using Linear Least Squares if the model allows it.
        Checks superposition: f(C1 + C2) == f(C1) + f(C2)
        """
        n_params = len(opt_nodes)
        n_samples = len(X)
        
        # If X_target is provided (e.g. a Projection Matrix), the basis matrix Phi 
        # is actually (X_target @ Evaluated_Basis)
        target_samples = len(X_target) if X_target is not None else n_samples
        Phi = np.zeros((target_samples, n_params))
        
        # Save original values
        orig_vals = [n.value for n in opt_nodes]
        
        # Build Phi by evaluating the tree for each unit-vector of parameters
        for i in range(n_params):
            self._set_params(opt_nodes, np.zeros(n_params))
            opt_nodes[i].value = 1.0
            fx = engine.evaluate(tree, X)
            if X_target is not None:
                Phi[:, i] = X_target @ fx
            else:
                Phi[:, i] = fx
            
        # Linearity check at ones vector
        self._set_params(opt_nodes, np.ones(n_params))
        f_ones = engine.evaluate(tree, X)
        if X_target is not None:
            f_ones = X_target @ f_ones
            
        Phi_ones = Phi @ np.ones(n_params)
        
        is_linear = np.allclose(f_ones, Phi_ones, rtol=1e-4, atol=1e-6)
        
        if is_linear:
            # Solve Phi * c = y
            c, _, _, _ = np.linalg.lstsq(Phi, y, rcond=None)
            return c  # type: ignore[no-any-return]
        else:
            # Restore and fail
            self._set_params(opt_nodes, np.asarray(orig_vals))
            return None

    def _numerical_optimization(self, tree: Node, engine: Any, X: np.ndarray, y: np.ndarray, opt_nodes: List[OptimizableConstant], method: str, max_iter: int, tol: float, n_restarts: int, X_target: np.ndarray | None = None):
        """Standard SciPy optimization with restarts support."""
        initial_params = [n.value for n in opt_nodes]

        def objective(params):
            self._set_params(opt_nodes, params)
            try:
                pred = engine.evaluate(tree, X)
                if X_target is not None:
                    pred = X_target @ pred
                residual = y - pred
                return np.mean(residual**2)
            except:
                return 1e18

        # Multiple restarts to find global minimum if requested
        best_res = None
        for i in range(n_restarts + 1):
            if i == 0:
                start_p = np.array(initial_params)
            else:
                # Random perturbation for restarts
                start_p = np.array(initial_params) + np.random.normal(0, 1.0, len(initial_params))
            
            res = scipy_minimize(objective, start_p, method=method, 
                                 options={"maxiter": max_iter}, tol=tol)
            
            if best_res is None or (res.success and res.fun < best_res.fun):
                best_res = res
        
        if best_res and best_res.x is not None:
            self._set_params(opt_nodes, best_res.x)

    def _set_params(self, opt_nodes: List[OptimizableConstant], values: np.ndarray):
        for node, val in zip(opt_nodes, values):
            node.value = float(val)
