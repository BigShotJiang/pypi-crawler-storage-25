from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import numpy as np

@dataclass
class ProblemDefinition:
    """High-level description of the symbolic regression task."""
    X: np.ndarray
    y: np.ndarray
    t: Optional[np.ndarray] = None
    feature_names: List[str] = field(default_factory=list)
    target_name: str = "y"
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class GlobalPreparedData:
    """Input data optimized and prepared for all backends."""
    X: np.ndarray
    y: np.ndarray
    t: Optional[np.ndarray] = None
    dy_dt: Optional[np.ndarray] = None
    d2y_dt2: Optional[np.ndarray] = None
    feature_names: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class BackendPreparedData:
    """Data structures specific to a formulation (e.g., Weak Test Matrix)."""
    matrices: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Individual:
    """A candidate solution in the symbolic search space."""
    tree: Any  # The symbolic expression tree (e.g., Node from grammar.py)
    constants: Dict[str, float] = field(default_factory=dict)
    backend_name: Optional[str] = None
    hash: Optional[str] = None
    score: Optional[Any] = None # Will be BackendScore
    validation_score: Optional[float] = None # Standard MSE (Pointwise)
    external_score: Optional[float] = None # Global score for cross-island ranking
    
    def __hash__(self):
        return hash(self.hash) if self.hash else id(self)
    
    def __eq__(self, other):
        if not isinstance(other, Individual):
            return False
        return self.hash == other.hash if self.hash and other.hash else self is other
