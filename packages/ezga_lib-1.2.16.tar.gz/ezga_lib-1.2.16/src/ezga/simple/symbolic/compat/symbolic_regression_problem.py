from __future__ import annotations
import copy
import logging
import re
from collections import OrderedDict
from typing import Any

import numpy as np
from scipy.optimize import minimize as scipy_minimize

from ezga.simple.algorithm import GA
from ezga.simple.ge import GEMapper, GEVariation, Grammar
from ezga.simple.grammar import (
    AND,
    OR,
    Abs,
    Add,
    Constant,
    Cos,
    Cube,
    Div,
    Exp,
    Gaussian,
    Interval,
    Log,
    Max,
    Min,
    Mul,
    Neg,
    OptimizableConstant,
    Ratio,
    Sin,
    SoftIf,
    Sqrt,
    Square,
    Sub,
    Threshold,
    Variable,
)
from ezga.simple.minimize import minimize
from ezga.simple.ops import SymbolicMutator, generate_random_tree
from ezga.simple.problem import ElementwiseProblem

# JAX Integration (REMOVED)
_JAX_AVAILABLE = False

# Configure logger
logger = logging.getLogger(__name__)

# Optional Dependencies for User Friendliness
try:
    import pandas as pd
except ImportError:
    pd = None # type: ignore

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None # type: ignore


class SymbolicMathMutation:
    """
    Callable Mutation Operator for Symbolic Regression.
    Expected signature: func(container) -> new_container
    """

    def __init__(
        self,
        n_features,
        problem,
        mutation_rate=0.1,
        binary_ops=None,
        unary_ops=None,
        ternary_ops=None,
        literal_types=None,
        pop_size=100,
        max_generations=100,
        guided_prob=0.3,
        rng=None,
    ):
        self.rng = rng if rng is not None else np.random.default_rng()
        self.problem = problem
        self.mutator = SymbolicMutator(n_features, mutation_rate, binary_ops, unary_ops, ternary_ops, literal_types)
        self.n_features = n_features
        self.literal_types = literal_types
        self.binary_ops = binary_ops
        self.unary_ops = unary_ops
        self.ternary_ops = ternary_ops
        self.guided_prob = guided_prob

        # Adaptive Control State
        self.pop_size = pop_size
        self.max_generations = max_generations
        self.call_count = 0
        self.approx_gen = 0

    def _semantic_prune_mutation(self, tree_obj, rng):
        """Identifies and removes subtrees with low semantic importance or high noise."""
        if tree_obj is None or tree_obj.size <= 2:
            return None

        # Efficiency sub-sampling
        if hasattr(self.problem, "X_data") and self.problem.X_data is not None:
            n_samples = min(256, len(self.problem.X_data))
            idx_rows = rng.choice(len(self.problem.X_data), n_samples, replace=False)
            X_sub = self.problem.X_data[idx_rows]
            y_sub = self.problem.y_data[idx_rows]
        else:
            return None

        candidates = []
        # Sample sites to avoid scanning massive trees entirely every time
        sites = list(range(1, tree_obj.size))
        if len(sites) > 30:
            sites = rng.choice(sites, 30, replace=False)

        for site in sites:
            sub = tree_obj.get_subtree(site)
            if sub is None or type(sub).__name__ in ["Constant", "OptimizableConstant"]:
                continue

            info = self.problem._evaluate_prune_candidate(tree_obj, site, X=X_sub, y=y_sub)
            if info is None:
                continue

            info["prune_score"] = self.problem._prune_score(info)
            if self.problem._should_prune_candidate(info):
                candidates.append(info)

        if not candidates:
            return None

        # Softmax-ish selection among top candidates
        candidates.sort(key=lambda d: d["prune_score"], reverse=True)
        top = candidates[:5]

        scores = np.array([x["prune_score"] for x in top])
        probs = np.exp(scores - np.max(scores))
        probs /= probs.sum()

        chosen = top[rng.choice(len(top), p=probs)]
        return chosen["pruned_tree"]

        return None

    def __call__(self, container):
        rng = self.rng
        import copy

        c = copy.deepcopy(container)

        # 1. Get Tree from Registry using Position ID
        apm = c.AtomPositionManager
        pos = apm.atomPositions
        if len(pos) > 0:
            tree_id = float(pos[0][0])
            tree_obj = self.problem.get_tree(tree_id)
        else:
            tree_obj = None

        if tree_obj is None:
            tree_obj = generate_random_tree(
                self.n_features,
                rng,
                binary_ops=self.binary_ops,
                unary_ops=self.unary_ops,
                ternary_ops=self.ternary_ops,
                literal_types=self.literal_types,
            )

        # 2. Mutate with semantic filtering
        self.call_count += 1
        self.approx_gen = self.call_count // self.pop_size
        progress = min(1.0, self.approx_gen / (self.max_generations + 1e-6))

        # Semantic guidance parameters
        # Sample a subset of X for efficiency
        if hasattr(self.problem, "X_data") and self.problem.X_data is not None:
            n_samples = min(256, len(self.problem.X_data))
            indices = rng.choice(len(self.problem.X_data), n_samples, replace=False)
            X_semantic = self.problem.X_data[indices]

            # Adaptive semantic threshold: start permissive, end strict.
            # Base scale from y variability.
            y_std = (
                np.std(self.problem.y_data) if hasattr(self.problem, "y_data") and len(self.problem.y_data) > 0 else 1.0
            )
            y_var = y_std**2

            # Initial phase (first 10%): Allow anything (Infinite threshold)
            # This is critical to move away from constant-only populations.
            if progress < 0.1:
                max_semantic_delta = np.inf
            else:
                # Relax initial threshold: 10.0 * var at start of phase, 0.5 * var at end.
                max_semantic_delta = y_var * (10.0 * (1.0 - progress) + 0.5 * progress)
        else:
            X_semantic = None
            max_semantic_delta = None

        parent_str = str(tree_obj)
        new_tree = None

        # 2. Semantic Pruning Mutation (Active model reduction)
        # Prob increases with progress to force model reduction later
        prune_p = 0.1
        if progress > 0.25:
            prune_p = 0.20
        if progress > 0.60:
            prune_p = 0.35

        if rng.random() < prune_p:
            pruned = self._semantic_prune_mutation(tree_obj, rng)
            if pruned and str(pruned) != parent_str:
                new_tree = pruned

        # 3. Guided Semantic Mutation (Diagnostic-based)
        # Instead of random structural changes, try to "repair" the model
        # based on residual signals (e.g., adding a sine if residuals are periodic).

        # Make guided mutation weak early and stronger later
        guided_p = self.guided_prob
        if progress < 0.15:
            guided_p = 0.05 * self.guided_prob
        elif progress > 0.6:
            guided_p = min(0.75, 1.5 * self.guided_prob)

        if rng.random() < guided_p:
            # 3. Guided Repair Path (Semantic Residuals)

            if new_tree is None:
                repairs = self.problem.get_guided_repairs(tree_obj, top_k=4)
                if repairs:
                    # Sample among top repairs
                    scores = np.array([max(1e-10, r["score"]) for r in repairs], dtype=float)
                    probs = scores / np.sum(scores)
                    idx = rng.choice(len(repairs), p=probs)
                    new_tree = repairs[idx]["tree"]

        # 4. Standard / Robust Mutation (Backup and exploration)
        if new_tree is None:
            new_tree = self.mutator.mutate(
                tree_obj,
                rng,
                generation=self.approx_gen,
                total_generations=self.max_generations,
                X_semantic=X_semantic,
                max_semantic_delta=max_semantic_delta,
            )

        # 5. If mutation produced the exact same structure as the parent (no-op),
        # force a stronger change: random subtree replacement.
        # This acts as a secondary retry if the semantic filter was too strict or the mutator was unlucky.
        for _ in range(3):
            if str(new_tree) != parent_str:
                break
            size = new_tree.size
            site = rng.integers(0, size)
            fresh = generate_random_tree(
                self.n_features,
                rng,
                max_depth=2,  # Small replacement
                binary_ops=self.binary_ops,
                unary_ops=self.unary_ops,
                ternary_ops=self.ternary_ops,
                literal_types=self.literal_types,
            )
            new_tree = new_tree.set_subtree(site, fresh)

        # 4. Register New Tree with New ID
        new_id = self.problem.get_next_id()
        self.problem.register_tree(new_id, new_tree)

        # 5. Update Container Position ID
        new_pos = np.zeros((1, 3))
        new_pos[0, 0] = int(new_id)
        apm.set_atomPositions(new_pos)

        # Invalidate Energy
        apm.E = None
        if hasattr(apm, "metadata") and "objectives" in apm.metadata:
            del apm.metadata["objectives"]

        return c


class SymbolicMathCrossover:
    """
    Callable Crossover Operator for Symbolic Regression.
    Expected signature: func(c1, c2) -> (new_c1, new_c2)
    """

    def __init__(self, problem, rng=None):
        self.problem = problem
        self.rng = rng if rng is not None else np.random.default_rng()

    def __call__(self, p1, p2):
        import copy

        import numpy as np

        # 1. Clone Containers
        c1 = copy.deepcopy(p1)
        c2 = copy.deepcopy(p2)

        # 2. Get Trees
        t1_id = float(c1.AtomPositionManager.atomPositions[0, 0])
        t2_id = float(c2.AtomPositionManager.atomPositions[0, 0])

        tree1 = self.problem.get_tree(t1_id)
        tree2 = self.problem.get_tree(t2_id)

        if tree1 is None or tree2 is None:
            return c1, c2

        # Clone actual tree objects to avoid messing with originals
        tree1 = tree1.clone()
        tree2 = tree2.clone()

        # 3. Pick random swap points
        rng = self.rng
        idx1 = rng.integers(0, tree1.size)
        idx2 = rng.integers(0, tree2.size)

        # 4. Perform Swap
        # Note: set_subtree assumes mutable replacement in the clone
        sub1 = tree1.get_subtree(idx1).clone()
        sub2 = tree2.get_subtree(idx2).clone()

        tree1 = tree1.set_subtree(idx1, sub2)
        tree2 = tree2.set_subtree(idx2, sub1)

        # 5. Register and Update
        new_id1 = int(self.problem.get_next_id())
        new_id2 = int(self.problem.get_next_id())

        self.problem.register_tree(new_id1, tree1)
        self.problem.register_tree(new_id2, tree2)

        c1.AtomPositionManager.atomPositions[0, 0] = new_id1
        c2.AtomPositionManager.atomPositions[0, 0] = new_id2

        # Invalidate Energy/Objectives
        c1.AtomPositionManager.E = None
        c2.AtomPositionManager.E = None

        return c1, c2


class SymbolicRegressionProblem(ElementwiseProblem):
    def __init__(
        self,
        X,
        y,
        n_features,
        binary_ops,
        unary_ops,
        literal_types,
        complexity_penalty=0.0,
        optimizer="BFGS",
        n_restarts=0,
        objectives=None,
        complexity_weights=None,
        residual_mode="feature_corr",
        huber_delta=1.0,
        genotype_len=100,
        ternary_ops=None,
    ):
        # Default objectives: MAE (robust error), Complexity (weighted), Residual Structure (correlation)
        self.objectives = objectives or ["mae", "complexity", "residual_structure"]
        n_obj = len(self.objectives)

        super().__init__(n_var=1, n_obj=n_obj, xl=0, xu=1e6)
        self.X_data = X
        self.y_data = y
        self.n_features = n_features
        self.binary_ops = binary_ops
        self.unary_ops = unary_ops
        self.ternary_ops = ternary_ops if ternary_ops is not None else []
        self.literal_types = literal_types
        self.base_complexity_penalty = complexity_penalty
        self.current_complexity_penalty = complexity_penalty

        self.optimizer = optimizer
        self.n_restarts = n_restarts

        # New parameters for multi-objective refinement
        self.complexity_weights = complexity_weights
        self.residual_mode = residual_mode
        self.huber_delta = huber_delta

        self.tree_registry = {}
        self.next_id = 10000

        # Performance Caches
        self.max_cache_size = 1024
        self.results_cache = OrderedDict()  # (formula, penalty) -> [objs, tree]
        self.evaluation_cache = OrderedDict()  # formula -> y_pred
        self.basis_cache = {}  # (j, type, params) -> basis_array
        # Compiled NumPy lambdas: code_str -> fn.  Compiled once per unique structure.
        self._compiled_fn_cache = {}
        # Residual cache for guided mutation: formula -> residual array.
        # Avoids re-evaluating the same tree inside decompose_residuals + get_guided_repairs.
        self._residual_cache = OrderedDict()
        # Family usage statistics for diversity balancing in guided mutation.
        # Keys match h["type"] strings; values decay each generation to avoid permanent suppression.
        self.guided_family_stats = {
            "bias": 0.0,
            "linear": 0.0,
            "square": 0.0,
            "cube": 0.0,
            "interaction": 0.0,
            "periodic": 0.0,
            "gaussian": 0.0,
            "threshold": 0.0,
            "greedy_composite": 0.0,
        }

    # (JAX-guided mutation infrastructure REMOVED)

    def register_tree(self, id_val, tree):
        self.tree_registry[int(id_val)] = tree

    def get_tree(self, id_val):
        return self.tree_registry.get(int(id_val))

    def get_next_id(self):
        self.next_id += 1
        return self.next_id

    # -----------------------------------------------------------------------
    # Performance Optimization Helpers
    # -----------------------------------------------------------------------
    def _get_basis(self, j, btype, **params):
        """Retrieves or computes a semantic basis array for feature j."""
        key = (j, btype, tuple(sorted(params.items())))
        if key in self.basis_cache:
            return self.basis_cache[key]

        xj = self._safe_flat(self.X_data[:, j])

        if btype == "linear":
            res = xj
        elif btype == "square":
            res = xj**2
        elif btype == "cube":
            res = xj**3
        elif btype == "sin":
            res = np.sin(params["k"] * xj)
        elif btype == "cos":
            res = np.cos(params["k"] * xj)
        elif btype == "gaussian":
            mu, sigma = params["mu"], params["sigma"]
            res = np.exp(-0.5 * ((xj - mu) / sigma) ** 2)
        else:
            return None

        # Optimization: also cache the norm of the basis for faster fitting
        # We store it in a nested dictionary within the basis_cache or just return it
        res_norm = np.dot(res, res) + 1e-12

        # Limit total basis nodes to prevent blowout
        if len(self.basis_cache) < 2000:
            self.basis_cache[key] = (res, res_norm)
        return res, res_norm

    def _get_feature_relevance(self, r):
        """Ranks features by absolute correlation with the current residual."""
        r_std = np.std(r)
        if r_std < 1e-12:
            return list(range(self.n_features))

        corrs = []
        for j in range(self.n_features):
            xj = self._safe_flat(self.X_data[:, j])
            if np.std(xj) < 1e-12:
                corrs.append(0.0)
                continue
            corrs.append(abs(np.corrcoef(r, xj)[0, 1]))

        return np.argsort(corrs)[::-1]

    def _prune_cache(self, cache):
        """Maintains LRU property for caches."""
        while len(cache) > self.max_cache_size:
            cache.popitem(last=False)

    def compute_error(self, y_true, y_pred, kind):
        """Computes a variety of error metrics for regression."""
        kind = kind.lower().strip()
        diff = y_true - y_pred

        if kind == "mse":
            return np.mean(diff**2)
        elif kind == "rmse":
            return np.sqrt(np.mean(diff**2))
        elif kind == "nrmse":
            rmse = np.sqrt(np.mean(diff**2))
            return rmse / (np.std(y_true) + 1e-8)
        elif kind == "mae":
            return np.mean(np.abs(diff))
        elif kind == "huber":
            delta = self.huber_delta
            abs_diff = np.abs(diff)
            return np.mean(np.where(abs_diff <= delta, 0.5 * diff**2, delta * (abs_diff - 0.5 * delta)))
        return np.mean(diff**2)  # Default to MSE

    def compute_residual_structure(self, y_true, y_pred):
        """Computes metrics assessing the predictability of residuals."""
        r = y_true - y_pred
        mode = self.residual_mode.lower().strip()

        if mode == "feature_corr":
            # Max correlation of residuals with any input feature
            corrs = []
            for j in range(self.X_data.shape[1]):
                xj = self.X_data[:, j]
                if np.std(xj) > 1e-8 and np.std(r) > 1e-8:
                    c = np.corrcoef(r, xj)[0, 1]
                    corrs.append(abs(c))
            return max(corrs) if corrs else 0.0

        elif mode == "prediction_corr":
            # Correlation of residuals with predictions (linearity check)
            if np.std(r) > 1e-8 and np.std(y_pred) > 1e-8:
                return abs(np.corrcoef(r, y_pred)[0, 1])
            return 0.0

        elif mode == "heteroscedasticity":
            # Correlation of absolute residuals with predictions (scale check)
            abs_r = np.abs(r)
            if np.std(abs_r) > 1e-8 and np.std(y_pred) > 1e-8:
                return abs(np.corrcoef(abs_r, y_pred)[0, 1])
            return 0.0

        return 0.0

    def _primary_error_value(self, objs):
        """
        Extract the main predictive loss (MSE, MAE, etc.) from objectives list.
        """
        for i, name in enumerate(self.objectives):
            if name.lower().strip() in ["mse", "rmse", "nrmse", "mae", "huber"]:
                return float(objs[i])
        return float(objs[0])

    def _safe_flat(self, x):
        return np.asarray(x).reshape(-1)

    def _relative_sse_gain(self, y_true, y_pred):
        y_true = self._safe_flat(y_true)
        y_pred = self._safe_flat(y_pred)

        sse0 = np.dot(y_true, y_true)
        if sse0 < 1e-18:
            return 0.0, 0.0

        sse1 = np.dot(y_true - y_pred, y_true - y_pred)
        gain = max(0.0, sse0 - sse1)
        return gain, gain / sse0

    def _fit_single_basis(self, residual, phi, phi_norm=None, r_sse0=None):
        """
        Fit residual ~= a * phi
        Returns coefficient and relative SSE gain.
        Performance tip: pass pre-calculated phi_norm and r_sse0.
        """
        r = self._safe_flat(residual)
        phi = self._safe_flat(phi)

        if len(r) != len(phi):
            return None

        # Avoid recalculating norm if cached
        denom = phi_norm if phi_norm is not None else (np.dot(phi, phi) + 1e-22)
        if denom < 1e-18:
            return None

        coef = np.dot(phi, r) / denom
        coef * phi

        # Optimized relative gain calculation
        # gain = sse0 - sse1
        # where sse1 = dot(r - pred, r - pred) = dot(r,r) - 2*coef*dot(phi,r) + coef^2*dot(phi,phi)
        # sse1 = sse0 - 2*coef*(coef*denom) + coef^2*denom = sse0 - coef^2*denom
        # so gain = coef^2 * denom
        gain = (coef**2) * denom

        sse0 = r_sse0 if r_sse0 is not None else (np.dot(r, r) + 1e-12)
        rel_gain = gain / sse0

        return {"coef": float(coef), "gain": float(gain), "relative_gain": float(rel_gain)}

    def _fit_two_basis(self, residual, phi1, phi2):
        """
        Fit residual ~= a*phi1 + b*phi2
        Useful for sin/cos with phase.
        """
        r = self._safe_flat(residual)
        phi1 = self._safe_flat(phi1)
        phi2 = self._safe_flat(phi2)

        if len(r) != len(phi1) or len(r) != len(phi2):
            return None
        if np.std(phi1) < 1e-12 and np.std(phi2) < 1e-12:
            return None

        Phi = np.column_stack([phi1, phi2])
        try:
            coef, *_ = np.linalg.lstsq(Phi, r, rcond=None)
            pred = Phi @ coef
            gain, rel_gain = self._relative_sse_gain(r, pred)
            return {
                "coef1": float(coef[0]),
                "coef2": float(coef[1]),
                "gain": float(gain),
                "relative_gain": float(rel_gain),
            }
        except Exception:
            return None

    def _candidate_freqs(self, x, n_grid=10):
        """
        Compact frequency grid: span-based fundamental + harmonics + common scales.
        Reduced from 36 to 10 candidates for speed; covers the most important regimes.
        """
        x = self._safe_flat(x)
        x_min, x_max = np.min(x), np.max(x)
        span = max(1e-8, x_max - x_min)
        std_x = np.std(x) + 1e-12
        f0 = 2.0 * np.pi / span  # fundamental
        freqs = np.unique(
            np.concatenate(
                [
                    f0 * np.array([0.5, 1.0, 2.0, 4.0]),  # harmonics
                    np.array([0.1, 0.5, 1.0, 2.0, 5.0]) / std_x,  # std-relative
                    np.array([1.0, 3.0]),  # common scales
                ]
            )
        )
        return sorted(freqs)

    def _fit_threshold(self, residual, xj):
        """
        Scan for a split point 't' in xj that reduces variance of residual.
        Vectorized version using cumulative sums for O(N) performance.
        Checks all potential splits efficiently.
        """
        r = self._safe_flat(residual)
        xj = self._safe_flat(xj)

        idx = np.argsort(xj)
        xj_s = xj[idx]
        r_s = r[idx]

        n = len(r_s)
        if n < 10:
            return None

        # We want to minimize (n_l * var_l + n_r * var_r)
        # equivalently maximize (sum_l^2 / n_l + sum_r^2 / n_r)

        sum_total = np.sum(r_s)
        ssq_total = np.sum(r_s**2)

        # Precompute overall variance
        var_total = (ssq_total / n) - (sum_total / n) ** 2
        if var_total < 1e-12:
            return None

        # Cumulative sums
        c_sum_l = np.cumsum(r_s)
        c_sum_r = sum_total - c_sum_l

        # Number of points in each side
        n_l = np.arange(1, n + 1)
        n_r = n - n_l

        # Valid split points (at least 5 points on each side)
        valid = (n_l >= 5) & (n_r >= 5)
        if not np.any(valid):
            return None

        # Score to maximize: (sum_l^2 / n_l) + (sum_r^2 / n_r)
        scores = (c_sum_l[valid] ** 2 / n_l[valid]) + (c_sum_r[valid] ** 2 / n_r[valid])

        best_idx_in_valid = np.argmax(scores)
        best_idx = np.where(valid)[0][best_idx_in_valid]

        # Parameters for the best split
        t = xj_s[best_idx]
        left_val = c_sum_l[best_idx] / n_l[best_idx]
        right_val = c_sum_r[best_idx] / n_r[best_idx]

        # Relative gain in explained variance
        # var_total - (n_l*var_l + n_r*var_r)/n = ( (sum_l^2/n_l + sum_r^2/n_r) - sum_total^2/n ) / n
        gain = (scores[best_idx_in_valid] - (sum_total**2 / n)) / n
        rel_gain = gain / var_total

        if rel_gain > 0.1:  # Must explain at least 10% of remaining variance
            return {
                "score": float(rel_gain),
                "t": float(t),
                "left": float(left_val),
                "right": float(right_val),
            }
        return None

    def _collect_allowed_flags(self):
        return {
            "add": Add in self.binary_ops,
            "sub": Sub in self.binary_ops,
            "mul": Mul in self.binary_ops,
            "div": Div in self.binary_ops,
            "sin": Sin in self.unary_ops,
            "cos": Cos in self.unary_ops,
            "square": Square in self.unary_ops,
            "cube": Cube in self.unary_ops,
            "gaussian": Gaussian in self.literal_types,
            "threshold": Threshold in self.literal_types,
            "interval": Interval in self.literal_types,
            "softif": SoftIf in getattr(self, "ternary_ops", []),
            "ratio": Ratio in self.literal_types,
            "opt_const": OptimizableConstant in self.literal_types,
            "const": Constant in self.literal_types,
            "var": Variable in self.literal_types,
        }

    def _make_constant(self, value):
        if OptimizableConstant in self.literal_types:
            return OptimizableConstant(float(value))
        elif Constant in self.literal_types:
            return Constant(float(value))
        return None

    def decompose_residuals(self, tree, max_components=3):
        """
        Decomposes the current residual into a set of functional hypotheses (v3).
        Uses a residual cache to avoid re-evaluating the same tree multiple times
        per guided mutation step.
        """
        try:
            formula = str(tree)
            if formula in self._residual_cache:
                curr_r = self._residual_cache[formula]
                self._residual_cache.move_to_end(formula)
            else:
                y_pred = tree.evaluate(self.X_data)
                y_true = self._safe_flat(self.y_data)
                curr_r = y_true - self._safe_flat(y_pred)
                if len(self._residual_cache) >= 512:
                    self._residual_cache.popitem(last=False)
                self._residual_cache[formula] = curr_r
            if np.std(curr_r) < 1e-12:
                return []
        except:
            return []

        flags = self._collect_allowed_flags()
        all_hypotheses = []

        history = []
        r_temp = curr_r.copy()

        # We reuse step_0_candidates to avoid re-scanning singulars later
        step_0_candidates = None

        for step in range(max_components):
            candidates = self._scan_one_step(r_temp, flags)
            if not candidates:
                break

            if step == 0:
                step_0_candidates = candidates

            # Take the best one
            best_c = candidates[0]
            if best_c["score"] < 0.02:  # Too weak
                break

            history.append(best_c)
            # Update residual for next greedy step
            pred = self._get_component_pred(best_c)
            if pred is not None:
                r_temp = r_temp - pred
            else:
                break

        # A hypothesis can be a single greedy sequence
        if history:
            all_hypotheses.append(
                {
                    "type": "greedy_composite",
                    "score": sum(h["score"] for h in history),
                    "components": history,
                }
            )

        # Also include top singular ones as fallback (REUSED from step 0)
        if step_0_candidates:
            for s in step_0_candidates[:5]:
                # Don't duplicate the one already in greedy history if it's the same
                if history and s == history[0]:
                    continue

                all_hypotheses.append({"type": "greedy_composite", "score": s["score"], "components": [s]})

        all_hypotheses.sort(key=lambda h: h["score"], reverse=True)
        return all_hypotheses[:12]

    def _scan_one_step(self, r, flags):
        """
        Scans all families for a single residual step with performance optimizations.
        Uses feature preselection, basis norm caching, and minimized SSE calculations.
        """
        r_std = np.std(r)
        if r_std < 1e-12:
            return []

        hypotheses = []
        n_feat = self.n_features

        # Precompute residual norm once for the entire pass
        r_sse0 = np.dot(r, r) + 1e-12

        # 1. Feature Preselection (Relevance Filter)
        # Top-6 is sufficient: scanning all 12 features for periodics is ~2x slower.
        relevant_indices = self._get_feature_relevance(r)
        top_k = min(n_feat, 6) if n_feat > 1 else n_feat
        top_indices = set(relevant_indices[:top_k])

        # 1) Bias (j-independent)
        if flags["add"] and (flags["opt_const"] or flags["const"]):
            mean_r = float(np.mean(r))
            # pred = mean_r (constant)
            # SSE gain for a constant is simply n * mean_r^2 if r is zero-centered?
            # No, safer to just use the logic in _fit_single_basis with a ones array or dedicated logic.
            gain = len(r) * (mean_r**2)
            rel_gain = gain / r_sse0
            if rel_gain > 1e-4:
                hypotheses.append({"type": "bias", "score": rel_gain, "params": {"value": mean_r}})

        # 2) Per-feature scans
        for j in range(self.n_features):
            xj = self._safe_flat(self.X_data[:, j])
            if np.std(xj) < 1e-12:
                continue

            # Family A: Cheap (Linear, Square, Cube) - Scan all features
            # Linear
            if flags["var"] and flags["mul"]:
                basis, b_norm = self._get_basis(j, "linear")
                fit = self._fit_single_basis(r, basis, phi_norm=b_norm, r_sse0=r_sse0)
                if fit and fit["relative_gain"] > 0.01:
                    hypotheses.append(
                        {
                            "type": "linear",
                            "feature": j,
                            "score": fit["relative_gain"],
                            "params": {"coef": fit["coef"]},
                        }
                    )

            # Square
            if flags["square"] and flags["mul"]:
                basis, b_norm = self._get_basis(j, "square")
                fit = self._fit_single_basis(r, basis, phi_norm=b_norm, r_sse0=r_sse0)
                if fit and fit["relative_gain"] > 0.05:
                    hypotheses.append(
                        {
                            "type": "square",
                            "feature": j,
                            "score": fit["relative_gain"],
                            "params": {"coef": float(fit["coef"])},
                        }
                    )

            # Cube
            if flags["cube"] and flags["mul"]:
                basis, b_norm = self._get_basis(j, "cube")
                fit = self._fit_single_basis(r, basis, phi_norm=b_norm, r_sse0=r_sse0)
                if fit and fit["relative_gain"] > 0.05:
                    hypotheses.append(
                        {
                            "type": "cube",
                            "feature": j,
                            "score": fit["relative_gain"],
                            "params": {"coef": float(fit["coef"])},
                        }
                    )

            # Family B: Expensive
            if j not in top_indices:
                continue

            # Periodic
            if flags["mul"] and (flags["sin"] or flags["cos"]):
                best_p = None
                for k in self._candidate_freqs(xj):
                    b_sin, n_sin = self._get_basis(j, "sin", k=k)
                    b_cos, n_cos = self._get_basis(j, "cos", k=k)
                    # _fit_two_basis is harder to optimize simply but we can still reuse r
                    fit = self._fit_two_basis(r, b_sin, b_cos)
                    if fit and (best_p is None or fit["relative_gain"] > best_p["score"]):
                        best_p = {
                            "type": "periodic",
                            "feature": j,
                            "score": fit["relative_gain"],
                            "params": {
                                "k": float(k),
                                "a_sin": float(fit["coef1"]),
                                "a_cos": float(fit["coef2"]),
                            },
                        }
                if best_p and best_p["score"] > 0.05:
                    hypotheses.append(best_p)

            # Gaussian
            if flags["gaussian"] and flags["mul"]:
                xj_min, xj_max = np.min(xj), np.max(xj)
                mu_grid = np.linspace(xj_min, xj_max, 10)
                sigma = (xj_max - xj_min) / 10.0
                best_g = None
                for mu in mu_grid:
                    basis, b_norm = self._get_basis(j, "gaussian", mu=mu, sigma=sigma)
                    fit = self._fit_single_basis(r, basis, phi_norm=b_norm, r_sse0=r_sse0)
                    if fit and (best_g is None or fit["relative_gain"] > best_g["score"]):
                        best_g = {
                            "type": "gaussian",
                            "feature": j,
                            "score": fit["relative_gain"],
                            "params": {
                                "mu": float(mu),
                                "sigma": float(sigma),
                                "coef": float(fit["coef"]),
                            },
                        }
                if best_g and best_g["score"] > 0.05:
                    hypotheses.append(best_g)

            # Interactions
            if flags["mul"] and self.X_data.shape[1] > 1:
                for k in relevant_indices[: min(len(relevant_indices), 6)]:
                    if j == k:
                        continue
                    xk = self.X_data[:, k]
                    basis = xj * xk
                    fit = self._fit_single_basis(r, basis, r_sse0=r_sse0)
                    if fit and fit["relative_gain"] > 0.1:
                        hypotheses.append(
                            {
                                "type": "interaction",
                                "feature": j,
                                "score": fit["relative_gain"],
                                "params": {"feature_k": int(k), "coef": float(fit["coef"])},
                            }
                        )

            # Thresholds
            if flags["threshold"] and flags["add"]:
                res_th = self._fit_threshold(r, xj)
                if res_th:
                    hypotheses.append(
                        {
                            "type": "threshold",
                            "feature": j,
                            "score": res_th["score"],
                            "params": res_th,
                        }
                    )

        # --- Post-processing ---
        # 1. Periodic gating: sin/cos only accepted if they clearly beat simpler families.
        #    Evidence test: residual must show oscillatory behavior (sign changes > threshold).
        #    Margin test: periodic score must exceed best non-periodic score by 1.25x.
        if hypotheses:
            nonperiodic = [h for h in hypotheses if h["type"] != "periodic"]
            periodic = [h for h in hypotheses if h["type"] == "periodic"]
            if periodic and nonperiodic:
                best_np_score = nonperiodic[0]["score"]
                margin = 1.25 * best_np_score
                # Oscillation evidence: number of sign changes in r relative to length
                sign_changes = np.sum(np.diff(np.sign(r)) != 0)
                oscillatory = sign_changes > 0.15 * len(r)  # >15% of samples have sign changes
                periodic = [h for h in periodic if h["score"] > margin and oscillatory]
                hypotheses = nonperiodic + periodic

        # 2. Family diversity penalty: down-weight overused families.
        for h in hypotheses:
            overuse = self.guided_family_stats.get(h["type"], 0.0)
            h["score"] *= 1.0 / (1.0 + 0.5 * overuse)

        hypotheses.sort(key=lambda h: h["score"], reverse=True)

        # --- Per-family quota: prevent any one family from flooding candidates ---
        # This limits candidate diversity before family penalty is applied.
        _quotas = {
            "bias": 1,
            "linear": 2,
            "square": 1,
            "cube": 1,
            "interaction": 1,
            "threshold": 1,
            "gaussian": 1,
            "periodic": 1,
        }
        _family_count = {}
        _filtered = []
        for h in hypotheses:
            fam = h["type"]
            cap = _quotas.get(fam, 1)
            if _family_count.get(fam, 0) < cap:
                _filtered.append(h)
                _family_count[fam] = _family_count.get(fam, 0) + 1
        hypotheses = _filtered

        # Family diversity penalty: down-weight overused families
        for h in hypotheses:
            overuse = self.guided_family_stats.get(h["type"], 0.0)
            h["score"] *= 1.0 / (1.0 + 0.5 * overuse)

        hypotheses.sort(key=lambda h: h["score"], reverse=True)
        return hypotheses

    def _get_component_pred(self, h):
        """Returns the signal predicted by a hypothesis (v4)."""
        h_type = h["type"]

        if h_type == "bias":
            return np.full(self.X_data.shape[0], h["params"]["value"])

        # Feature-dependent families
        xj = self.X_data[:, h["feature"]]

        if h_type == "linear":
            return xj * h["params"]["coef"]
        if h_type == "square":
            return (xj**2) * h["params"]["coef"]
        if h_type == "cube":
            return (xj**3) * h["params"]["coef"]
        if h_type == "periodic":
            k = h["params"]["k"]
            return h["params"]["a_sin"] * np.sin(k * xj) + h["params"]["a_cos"] * np.cos(k * xj)
        if h_type == "gaussian":
            mu, sigma, coef = h["params"]["mu"], h["params"]["sigma"], h["params"]["coef"]
            return coef * np.exp(-0.5 * ((xj - mu) / sigma) ** 2)
        if h_type == "interaction":
            xk = self.X_data[:, h["params"]["feature_k"]]
            return (xj * xk) * h["params"]["coef"]
        if h_type == "threshold":
            t = h["params"]["t"]
            return np.where(xj < t, h["params"]["left"], h["params"]["right"])
        return None

    def _instantiate_fragment(self, h):
        """
        Build fragment tree from hypothesis (can be a composite).
        """
        if h["type"] == "greedy_composite":
            frag = None
            for comp in h["components"]:
                cf = self._instantiate_fragment(comp)
                if cf is None:
                    continue
                if frag is None:
                    frag = cf
                else:
                    if Add in self.binary_ops:
                        frag = Add(frag, cf)
            return frag
        return self._instantiate_one_fragment(h)

    def _instantiate_one_fragment(self, h):
        """
        Instantiate a singular functional component (v3).
        Fixed algebraic sign correctly for negative first terms.
        """
        flags = self._collect_allowed_flags()
        h_type = h["type"]

        def wrap_sign(node, val):
            if val >= 0:
                return node
            # Use Neg if available, otherwise Sub(0, node)
            if Neg in self.unary_ops:
                return Neg(node)
            zero = self._make_constant(0.0)
            return Sub(zero, node) if zero is not None else node

        # Bias
        if h_type == "bias" and flags["add"]:
            val = h["params"]["value"]
            c = self._make_constant(abs(val))
            return wrap_sign(c, val) if c else None

        # Polynomial Families
        if h_type in ("linear", "square", "cube"):
            j = h["feature"]
            coef = h["params"]["coef"]
            c = self._make_constant(abs(coef))
            if c is None:
                return None

            base = Variable(j)
            if h_type == "square":
                base = Square(base)
            if h_type == "cube":
                base = Cube(base)

            frag = Mul(c, base) if flags["mul"] else base
            return wrap_sign(frag, coef)

        # Gaussian
        if h_type == "gaussian" and flags["gaussian"]:
            j = h["feature"]
            mu = h["params"]["mu"]
            sigma = h["params"]["sigma"]
            coef = h["params"]["coef"]
            c = self._make_constant(abs(coef))
            if c is None:
                return None

            # Note: ops.py shows Gaussian(feat, mu, sigma) as a Literal
            # But here we treat it as the basis core multiplied by a constant.
            core = Gaussian(j, mu, sigma)
            frag = Mul(c, core) if flags["mul"] else core
            return wrap_sign(frag, coef)

        # Interaction
        if h_type == "interaction" and flags["mul"]:
            j = h["feature"]
            k = h["params"]["feature_k"]
            coef = h["params"]["coef"]
            c = self._make_constant(abs(coef))
            if c is None:
                return None

            core = Mul(Variable(j), Variable(k))
            return wrap_sign(Mul(c, core), coef)

        # Periodic
        if h_type == "periodic" and flags["mul"] and (flags["sin"] or flags["cos"]):
            j = h["feature"]
            k = h["params"]["k"]
            a_sin = h["params"]["a_sin"]
            a_cos = h["params"]["a_cos"]

            k_const = self._make_constant(k)
            if not k_const:
                return None

            arg = Mul(Variable(j), k_const)
            frag = None

            if abs(a_sin) > 1e-6 and flags["sin"]:
                c_sin = self._make_constant(abs(a_sin))
                if c_sin:
                    term = wrap_sign(Mul(c_sin, Sin(arg)), a_sin)
                    frag = term

            if abs(a_cos) > 1e-6 and flags["cos"]:
                c_cos = self._make_constant(abs(a_cos))
                if c_cos:
                    term = wrap_sign(Mul(c_cos, Cos(arg)), a_cos)
                    if frag is None:
                        frag = term
                    else:
                        frag = Add(frag, term) if flags["add"] else frag
            return frag

        # Threshold / Piecewise (v4)
        if h_type == "threshold" and flags["threshold"] and SoftIf in self.ternary_ops:
            j = h["feature"]
            t = h["params"]["t"]
            l_val = h["params"]["left"]
            r_val = h["params"]["right"]

            cl = self._make_constant(l_val)
            cr = self._make_constant(r_val)
            if not cl or not cr:
                return None

            # soft_if(Threshold(j, t, 1), left_true, right_false)
            # op=1 means xj < t
            cond = Threshold(j, t, 1)
            return SoftIf(cond, cl, cr)

        return None

    def _candidate_repair_sites(self, tree, max_sites=3):
        """
        Score subtree sites by complexity/impact ratio.
        High-complexity + low-impact subtrees are best replacement candidates.
        Avoids the root (index 0) to prevent full-tree replacement via local ops.
        """
        sites = []
        n = tree.size
        if n <= 1:
            return []  # Leaf tree — no meaningful subtree to replace

        try:
            pred_full = self._safe_flat(tree.evaluate(self.X_data))
        except Exception:
            return []

        for idx in range(1, n):  # Skip root (idx=0)
            try:
                sub = tree.get_subtree(idx)
                if sub is None or sub.size < 1:
                    continue
                cx = float(self.compute_complexity(sub))

                # Estimate contribution: zero-out this subtree, measure shift
                zero_tree = tree.clone()
                zero_const = self._make_constant(0.0)
                if zero_const is None:
                    continue
                zero_tree = zero_tree.set_subtree(idx, zero_const)
                pred_zero = self._safe_flat(zero_tree.evaluate(self.X_data))
                impact = float(np.mean(np.abs(pred_full - pred_zero))) + 1e-6

                # Priority: high complexity, low impact → best candidate for replacement
                priority = cx / impact
                sites.append((idx, priority, cx))
            except Exception:
                continue

        # Sort by priority descending, take top max_sites
        sites.sort(key=lambda t: t[1], reverse=True)
        return [idx for idx, _, _ in sites[:max_sites]]

    def _compose_repair(self, tree, h, frag):
        """
        Generates multiple repair strategies: global (add/mul) + local subtree repairs.
        Local repairs target low-impact/high-complexity subtrees for focused correction.
        """
        if frag is None:
            return []
        flags = self._collect_allowed_flags()
        import copy

        repairs = []

        # --- Global repairs (whole-tree) ---
        # 1. Additive: tree + frag
        if flags["add"]:
            repairs.append((Add(copy.deepcopy(tree), copy.deepcopy(frag)), "global_add"))

        # 2. Multiplicative: tree * (1 + frag)
        if flags["mul"] and flags["add"]:
            one = self._make_constant(1.0)
            if one:
                repairs.append((Mul(copy.deepcopy(tree), Add(one, copy.deepcopy(frag))), "global_mul"))

        # --- Local repairs (subtree-targeted) ---
        # Only attempt if tree is non-trivial
        if tree.size > 2:
            sites = self._candidate_repair_sites(tree, max_sites=3)
            for site in sites:
                try:
                    sub = tree.get_subtree(site)
                    if sub is None:
                        continue

                    # 3. Local additive: replace subtree by (subtree + frag)
                    if flags["add"]:
                        t_clone = copy.deepcopy(tree)
                        sub_clone = copy.deepcopy(sub)
                        t_clone = t_clone.set_subtree(site, Add(sub_clone, copy.deepcopy(frag)))
                        repairs.append((t_clone, "local_add"))

                    # 4. Local multiplicative: replace subtree by subtree*(1+frag)
                    if flags["mul"] and flags["add"]:
                        one = self._make_constant(1.0)
                        if one:
                            t_clone = copy.deepcopy(tree)
                            sub_clone = copy.deepcopy(sub)
                            t_clone = t_clone.set_subtree(site, Mul(sub_clone, Add(one, copy.deepcopy(frag))))
                            repairs.append((t_clone, "local_mul"))

                    # 5. Replace: substitute subtree entirely with frag
                    #    Only if frag is not larger than what we replace (avoid bloat)
                    if copy.deepcopy(frag).size <= sub.size + 2:
                        t_clone = copy.deepcopy(tree)
                        t_clone = t_clone.set_subtree(site, copy.deepcopy(frag))
                        repairs.append((t_clone, "replace"))
                except Exception:
                    continue

        return repairs

    def get_guided_repairs(self, tree, top_k=6):
        """
        Guided repairs with family balancing, semantic novelty filter, and relative scoring.

        Changes vs. v4:
          - Periodic gating already applied in _scan_one_step.
          - Semantic novelty filter: skip repairs that barely change predictions.
          - Relative scoring: Δerr/err - 0.05*Δcx/cx, weighted by family overuse penalty.
          - Family stats updated + exponentially decayed after each call.
        """
        hypotheses = self.decompose_residuals(tree)
        if not hypotheses:
            return []

        try:
            old_objs = self.evaluate_tree(tree)
            old_error = self._primary_error_value(old_objs)
            old_complexity = float(self.compute_complexity(tree))
            y_true = self._safe_flat(self.y_data)
            y_scale = float(np.std(y_true)) + 1e-12

            # Parent prediction for semantic novelty check
            formula_parent = str(tree)
            if formula_parent in self.evaluation_cache:
                parent_pred = self._safe_flat(self.evaluation_cache[formula_parent])
            else:
                parent_pred = self._safe_flat(tree.evaluate(self.X_data))
        except Exception:
            return []

        # Stage 1: Cheap screening (MSE + Size + semantic novelty)
        candidates = []
        seen_formulas = {formula_parent}
        novelty_tol = 0.005 * y_scale  # <0.5% of signal std → reject

        for h in hypotheses:
            try:
                frag = self._instantiate_fragment(h)
                if frag is None:
                    continue

                for cand_tree, strategy in self._compose_repair(tree, h, frag):
                    form = str(cand_tree)
                    if form in seen_formulas:
                        continue
                    seen_formulas.add(form)

                    # Use evaluation cache if possible
                    if form in self.evaluation_cache:
                        pred = self.evaluation_cache[form]
                        self.evaluation_cache.move_to_end(form)
                    else:
                        pred = self._safe_flat(cand_tree.evaluate(self.X_data))
                        self.evaluation_cache[form] = pred
                        self._prune_cache(self.evaluation_cache)

                    # Semantic novelty filter: reject if prediction barely shifts
                    pred_shift = float(np.mean(np.abs(pred - parent_pred)))
                    if pred_shift < novelty_tol:
                        continue

                    mse = float(np.mean((y_true - pred) ** 2))
                    candidates.append(
                        {
                            "tree": cand_tree,
                            "h": h,
                            "mse": mse,
                            "size": cand_tree.size,
                            "depth": cand_tree.depth,
                            "strategy": strategy,
                            "family": h.get("type", "unknown"),
                        }
                    )
            except:
                continue

        if not candidates:
            return []

        # Stage 2: Diversified screening — top-3 by (mse, size), then fill by family diversity
        candidates.sort(key=lambda c: (c["mse"], c["size"]))
        survivors = candidates[:3]
        seen_families = {c["family"] for c in survivors}
        for c in candidates[3:]:
            if len(survivors) >= top_k:
                break
            if c["family"] not in seen_families:
                survivors.append(c)
                seen_families.add(c["family"])

        # Stage 3: Full multi-objective evaluation with relative scoring
        ranked = []
        for s in survivors:
            try:
                objs = self.evaluate_tree(s["tree"])
                new_error = self._primary_error_value(objs)
                new_complexity = float(self.compute_complexity(s["tree"]))

                delta_err = old_error - new_error
                delta_cx = new_complexity - old_complexity
                if delta_err <= 0:
                    continue

                # Relative gains (safe denominators)
                rel_err_gain = delta_err / (old_error + 1e-12)
                rel_cx_cost = delta_cx / (old_complexity + 1e-12)

                # Family overuse penalty
                family = s["family"]
                overuse = self.guided_family_stats.get(family, 0.0)
                family_penalty = 1.0 / (1.0 + 0.5 * overuse)

                score = (rel_err_gain - 0.05 * rel_cx_cost) * family_penalty

                ranked.append(
                    {
                        "tree": s["tree"],
                        "score": float(score),
                        "hypothesis": s["h"],
                        "strategy": s["strategy"],
                        "family": family,
                        "objs": objs,
                    }
                )
            except:
                continue

        ranked.sort(key=lambda d: d["score"], reverse=True)
        selected = ranked[:top_k]

        # --- Update family usage stats (with exponential decay for all families) ---
        decay = 0.95
        for k in list(self.guided_family_stats.keys()):
            self.guided_family_stats[k] *= decay
        for r in selected:
            f = r.get("family", "unknown")
            self.guided_family_stats[f] = self.guided_family_stats.get(f, 0.0) + 1.0

        return selected

    def compute_complexity(self, tree):
        """Computes weighted symbolic complexity of a tree."""
        # Refined Default Weights based on user preference and interpretability
        weights = self.complexity_weights or {
            # Literals
            "Variable": 1.0,
            "Constant": 0.7,
            "OptimizableConstant": 0.9,
            # Basic Algebra
            "Add": 1.0,
            "Sub": 1.0,
            "Mul": 1.3,
            "Div": 2.5,
            # Simple Unary
            "Neg": 0.8,
            "Abs": 1.5,
            "Square": 1.6,
            "Cube": 2.0,
            # Nonlinear / Smooth
            "Sqrt": 2.5,
            "Exp": 3.0,
            "Log": 3.0,
            # Periodic
            "Sin": 2.5,
            "Cos": 2.5,
            # Comparators / Piecewise
            "Min": 2.0,
            "Max": 2.0,
            "Threshold": 4.5,
            "Interval": 4.5,
            "SoftIf": 5.0,
            # Structured Literals
            "Gaussian": 3.5,
            "Ratio": 3.5,
            # Booleans
            "AND": 3.0,
            "OR": 3.0,
        }

        def traverse(node):
            name = node.__class__.__name__
            w = weights.get(name, 1.0)
            total = w
            for child in node.children:
                total += traverse(child)
            return total

        # Add a small depth penalty to encourage flatter trees
        return traverse(tree) + 0.5 * tree.depth

    def _tree_to_code(self, node, node_map):
        """Recursively compile a tree to a vectorized Python code string.
        node_map: {id(OptimizableConstant) -> index_in_params_array}
        Raises ValueError for unsupported nodes (caller should catch).
        """
        name = type(node).__name__
        if name == "Variable":
            return f"X[:, {node.index}]"
        if name == "OptimizableConstant":
            return f"p[{node_map[id(node)]}]"
        if name == "Constant":
            return str(float(node.value))
        if name == "Add":
            return f"({self._tree_to_code(node.left, node_map)} + {self._tree_to_code(node.right, node_map)})"
        if name == "Sub":
            return f"({self._tree_to_code(node.left, node_map)} - {self._tree_to_code(node.right, node_map)})"
        if name == "Mul":
            return f"({self._tree_to_code(node.left, node_map)} * {self._tree_to_code(node.right, node_map)})"
        if name == "Div":
            l, r = self._tree_to_code(node.left, node_map), self._tree_to_code(node.right, node_map)
            return f"({l} / np.where(np.abs({r}) < 1e-6, np.sign({r} + 1e-9) * 1e-6, {r}))"
        if name == "Sin":
            return f"np.sin({self._tree_to_code(node.child, node_map)})"
        if name == "Cos":
            return f"np.cos({self._tree_to_code(node.child, node_map)})"
        if name == "Exp":
            return f"np.exp(np.clip({self._tree_to_code(node.child, node_map)}, -10, 10))"
        if name == "Log":
            return f"np.log(np.abs({self._tree_to_code(node.child, node_map)}) + 1e-6)"
        if name == "Sqrt":
            return f"np.sqrt(np.abs({self._tree_to_code(node.child, node_map)}))"
        if name == "Square":
            return f"np.square({self._tree_to_code(node.child, node_map)})"
        if name == "Cube":
            return f"np.power({self._tree_to_code(node.child, node_map)}, 3)"
        if name == "Abs":
            return f"np.abs({self._tree_to_code(node.child, node_map)})"
        if name == "Neg":
            return f"(-{self._tree_to_code(node.child, node_map)})"
        raise ValueError(f"Unsupported node for fast compilation: {name}")

    def _get_compiled_fn(self, tree, opt_nodes):
        """
        Returns a cached compiled NumPy lambda for fast repeated evaluation.
        Key = code_str (structural hash). Compiles once per unique structure.
        Returns (fn, False) or (None, False) if compilation fails.
        """
        # Only for pure OptimizableConstant nodes (Gaussian/Threshold handled by native path)
        if not all(pn == "value" and type(n).__name__ == "OptimizableConstant" for n, pn in opt_nodes):
            return None, False

        node_map = {id(n): i for i, (n, _) in enumerate(opt_nodes)}
        try:
            code_str = self._tree_to_code(tree, node_map)
        except ValueError:
            return None, False

        # Cache lookup: compiled_fn is keyed by the structural code string
        if code_str in self._compiled_fn_cache:
            return self._compiled_fn_cache[code_str], False

        # Compile a fast NumPy vectorized lambda:
        # fn(X: ndarray, p: ndarray) -> ndarray of predictions
        try:
            X_ref = self.X_data  # captured in closure
            fn = eval(f"lambda X, p: {code_str}", {"np": np})
            # Test it once to validate
            test_p = np.array([getattr(n, pn) for n, pn in opt_nodes], dtype=np.float64)
            _ = fn(X_ref, test_p)
        except Exception:
            return None, False

        # Limit cache size
        if len(self._compiled_fn_cache) >= 4096:
            # Evict oldest 25%
            keys = list(self._compiled_fn_cache.keys())
            for k in keys[: len(keys) // 4]:
                del self._compiled_fn_cache[k]

        self._compiled_fn_cache[code_str] = fn
        return fn, False

    def _optimize_constants(self, tree, opt_nodes):
        if not opt_nodes:
            return None, None

        optimizers = self.optimizer
        if isinstance(optimizers, str):
            optimizers = [optimizers]

        def get_params():
            x = []
            for node, param_name in opt_nodes:
                val = getattr(node, param_name)
                x.append(np.log(max(1e-3, val)) if param_name == "sharpness" else val)
            return np.array(x, dtype=np.float64)

        def set_params(params):
            for i, (node, param_name) in enumerate(opt_nodes):
                val = float(params[i])
                if param_name == "sharpness":
                    val = np.exp(np.clip(val, -5, 10))
                elif isinstance(node, Gaussian) and param_name == "sigma":
                    val = max(1e-3, val)
                setattr(node, param_name, val)

        # --- Fast-path: cached compiled NumPy lambda ---
        # Compiles the tree to a vectorized expression once per unique structure.
        # On subsequent calls (same structure, different constant values), the
        # lambda is reused directly — no Python tree-walking per BFGS iteration.
        compiled_fn, _ = self._get_compiled_fn(tree, opt_nodes)
        X_data = self.X_data
        y_data = self.y_data

        if compiled_fn is not None:

            def objective(params):
                try:
                    yp = compiled_fn(X_data, params)
                    if not np.all(np.isfinite(yp)):
                        return 1e18
                    diff = y_data - yp
                    # Avoid NaN in dot product if diff contains non-finite values
                    val = float(np.dot(diff, diff)) / len(diff)
                    return val if np.isfinite(val) else 1e18
                except Exception:
                    return 1e18
        else:
            # Native fallback: tree-walk evaluation (safe for all node types)
            def objective(params):
                set_params(params)
                try:
                    yp = tree.evaluate(X_data)
                    if not np.all(np.isfinite(yp)):
                        return 1e18
                    diff = y_data - yp
                    val = float(np.dot(diff, diff)) / len(diff)
                    return val if np.isfinite(val) else 1e18
                except Exception:
                    return 1e18

        best_mse = np.inf
        best_params = None
        initial_params = get_params()
        n_params = len(initial_params)

        # ---------------------------------------------------------------
        # STAGE 1: Analytical OLS (microseconds, exact for linear cases)
        # For trees like c1*f1(X) + c2*f2(X), constants appear linearly.
        # Build basis matrix Phi[:,i] = fn(X, e_i) where e_i is unit vector.
        # Verify linearity: fn(X, ones) == Phi @ ones (superposition).
        # If linear → lstsq gives the exact optimum instantly, no BFGS needed.
        # ---------------------------------------------------------------
        ols_params = None
        if compiled_fn is not None and n_params > 0:
            try:
                Phi = np.zeros((len(X_data), n_params), dtype=np.float64)
                for i in range(n_params):
                    p_unit = np.zeros(n_params, dtype=np.float64)
                    p_unit[i] = 1.0
                    col = compiled_fn(X_data, p_unit)
                    if not np.all(np.isfinite(col)):
                        raise ValueError
                    Phi[:, i] = col

                # Linearity check: f(ones) must equal Phi @ ones
                p_ones = np.ones(n_params, dtype=np.float64)
                f_ones = compiled_fn(X_data, p_ones)
                Phi_ones = Phi @ p_ones
                if np.allclose(f_ones, Phi_ones, rtol=1e-4, atol=1e-6):
                    # Exactly linear → OLS in closed form
                    c, _, _, _ = np.linalg.lstsq(Phi, y_data, rcond=None)
                    if np.all(np.isfinite(c)):
                        ols_params = c
                        ols_mse = float(np.dot(y_data - Phi @ c, y_data - Phi @ c)) / len(y_data)
                        best_mse = ols_mse
                        best_params = ols_params
            except Exception:
                pass

        # ---------------------------------------------------------------
        # TIER B: BFGS (Standard SciPy)
        # ---------------------------------------------------------------
        if n_params > 0 and (best_params is None or best_mse > 1e-10):
            for attempt in range(self.n_restarts + 1):
                # Start from OLS result if available, otherwise from initial params
                # On subsequent attempts, add noise for global exploration
                if attempt == 0:
                    current_params = best_params.copy() if best_params is not None else initial_params.copy()
                else:
                    current_params = initial_params + np.random.default_rng(attempt).normal(0, 1.0, size=n_params)

                for opt_name in optimizers:
                    opt_name_ln = opt_name.lower().strip()
                    try:
                        if opt_name_ln in ["bfgs", "l-bfgs-b", "nelder-mead"]:
                            _opts = {"maxiter": 50}
                            if opt_name_ln == "l-bfgs-b":
                                _opts["ftol"] = 1e-9

                            res = scipy_minimize(objective, current_params, method=opt_name_ln.upper(), options=_opts)
                            current_params = res.x

                        elif opt_name_ln == "cma-es":
                            try:
                                import cma

                                res = cma.fmin2(objective, current_params, 0.5, {"maxiter": 50, "verbose": -9})
                                current_params = res[0]
                            except ImportError:
                                pass
                    except Exception:
                        pass

                current_mse = objective(current_params)
                if current_mse < best_mse:
                    best_mse = current_mse
                    best_params = current_params.copy()

                # Stop early if we reached high precision
                if best_mse < 1e-12:
                    break

        if best_params is not None:
            set_params(best_params)
        return best_params, best_mse

    def evaluate_tree(self, tree, tree_id=None):
        try:
            # 1. Formula-based result caching (fast exit)
            formula_raw = str(tree)
            penalty = getattr(self, "current_complexity_penalty", 0.0)
            formula_key = (formula_raw, float(penalty))

            if formula_key in self.results_cache:
                self.results_cache.move_to_end(formula_key)
                return self.results_cache[formula_key]

            # 2. Fast-scan for optimizable nodes WITHOUT cloning first.
            # Only clone (deepcopy) if we actually need to mutate the tree.
            def _has_opt(node):
                if isinstance(node, (OptimizableConstant, Threshold, Interval, Ratio, Gaussian)):
                    return True
                return any(_has_opt(c) for c in node.children)

            needs_opt = _has_opt(tree)

            if needs_opt:
                # Clone only when we must modify (constant optimization)
                eval_tree = tree.clone().simplify_aggressive()
            else:
                # No constants to optimize — skip expensive deepcopy entirely
                eval_tree = tree.simplify_aggressive()

            formula_simplified = str(eval_tree)

            # Check evaluation cache for the simplified formula
            y_pred = None
            if formula_simplified in self.evaluation_cache:
                y_pred = self.evaluation_cache[formula_simplified]
                self.evaluation_cache.move_to_end(formula_simplified)

            # 3. Constant Optimization (Memetic Step) — only if needed
            if needs_opt:
                opt_nodes = []

                def collect_opt_nodes(node):
                    if isinstance(node, OptimizableConstant):
                        opt_nodes.append((node, "value"))
                    elif isinstance(node, (Threshold, Interval, Ratio, Gaussian)):
                        for attr in ["val", "low", "high", "threshold", "sharpness", "mu", "sigma"]:
                            if hasattr(node, attr):
                                opt_nodes.append((node, attr))
                    for child in node.children:
                        collect_opt_nodes(child)

                collect_opt_nodes(eval_tree)

                if opt_nodes:
                    self._optimize_constants(eval_tree, opt_nodes)

                    # Lamarckian Back-propagation to genetic tree
                    orig_opt_nodes, eval_opt_objs = [], []

                    def _collect(node, dest, cls):
                        if isinstance(node, cls):
                            dest.append(node)
                        for c in node.children:
                            _collect(c, dest, cls)

                    _collect(tree, orig_opt_nodes, OptimizableConstant)
                    _collect(eval_tree, eval_opt_objs, OptimizableConstant)

                    if len(orig_opt_nodes) == len(eval_opt_objs):
                        for o, e in zip(orig_opt_nodes, eval_opt_objs):
                            o.value = e.value

                    eval_tree = eval_tree.freeze_constants().simplify_aggressive()
                    eval_tree = self._semantic_pruning(eval_tree)

                    formula_simplified = str(eval_tree)
                    y_pred = eval_tree.evaluate(self.X_data)

            if y_pred is None:
                y_pred = eval_tree.evaluate(self.X_data)

            # 4. Multi-Objective Evaluation
            objs = []
            for obj_name in self.objectives:
                obj_name_ln = obj_name.lower().strip()
                if obj_name_ln in ["mse", "rmse", "nrmse", "mae", "huber"]:
                    objs.append(self.compute_error(self.y_data, y_pred, obj_name_ln))
                elif obj_name_ln == "complexity":
                    objs.append(self.compute_complexity(eval_tree))
                elif obj_name_ln == "residual_structure":
                    objs.append(self.compute_residual_structure(self.y_data, y_pred))
                else:
                    objs.append(1.0)

            result = objs + [eval_tree]

            # 5. Store in caches with LRU pruning
            self.results_cache[formula_key] = result
            self.evaluation_cache[formula_simplified] = y_pred

            self._prune_cache(self.results_cache)
            self._prune_cache(self.evaluation_cache)

            return result
        except Exception as e:
            if getattr(self, "verbose", False):
                logger.error(f"Error evaluating tree: {e}")
            return [1e12] * len(self.objectives) + [None]

    def _evaluate_prune_candidate(self, tree, site, X=None, y=None):
        """
        Evaluates what happens if the subtree at `site` is pruned (replaced by 0.0).
        Returns semantic, error, and residual structure metrics.
        """
        if X is None:
            X = self.X_data
        if y is None:
            y = self.y_data

        try:
            y = self._safe_flat(y)
            full_pred = self._safe_flat(tree.evaluate(X))

            zero = self._make_constant(0.0)
            if zero is None:
                return None

            pruned_tree = tree.clone().set_subtree(site, zero).simplify_aggressive()
            pruned_pred = self._safe_flat(pruned_tree.evaluate(X))

            # 1. Signal contribution: how much y_pred shifts
            signal_impact = float(np.mean(np.abs(full_pred - pruned_pred)))
            rel_signal_impact = signal_impact / (np.std(full_pred) + 1e-12)

            # 2. Error contribution: finding the primary loss objective
            primary_kind = "mae"
            for name in self.objectives:
                name_ln = name.lower().strip()
                if name_ln in ["mse", "rmse", "nrmse", "mae", "huber"]:
                    primary_kind = name_ln
                    break

            err_full = float(self.compute_error(y, full_pred, primary_kind))
            err_pruned = float(self.compute_error(y, pruned_pred, primary_kind))
            delta_err = err_pruned - err_full
            rel_err = delta_err / (abs(err_full) + 1e-12)

            # 3. Residual/noise structure contribution
            noise_full = float(self.compute_residual_structure(y, full_pred))
            noise_pruned = float(self.compute_residual_structure(y, pruned_pred))
            delta_noise = noise_pruned - noise_full

            # 4. Complexity gain
            sub = tree.get_subtree(site)
            sub_cx = float(self.compute_complexity(sub)) if sub is not None else 0.0
            total_cx = float(self.compute_complexity(tree))
            rel_cx = sub_cx / (total_cx + 1e-12)

            return {
                "site": int(site),
                "pruned_tree": pruned_tree,
                "signal_impact": signal_impact,
                "rel_signal_impact": rel_signal_impact,
                "err_full": err_full,
                "err_pruned": err_pruned,
                "delta_err": delta_err,
                "rel_err": rel_err,
                "noise_full": noise_full,
                "noise_pruned": noise_pruned,
                "delta_noise": delta_noise,
                "subtree_complexity": sub_cx,
                "rel_cx": rel_cx,
            }
        except Exception:
            return None

    def _prune_score(self, info, w_signal=1.0, w_err=2.0, w_noise=0.75, w_cx=0.5):
        """High score = better candidate for pruning."""
        return (
            -w_signal * info["rel_signal_impact"]
            - w_err * max(0.0, info["rel_err"])
            - w_noise * max(0.0, info["delta_noise"])
            + w_cx * info["rel_cx"]
        )

    def _should_prune_candidate(self, info, max_rel_signal=0.015, max_rel_err=0.01, max_delta_noise=0.01):
        """Hard filters to avoid pruning valuable components."""
        return (
            info["rel_signal_impact"] <= max_rel_signal
            and info["rel_err"] <= max_rel_err
            and info["delta_noise"] <= max_delta_noise
        )

    def _semantic_pruning(self, tree, max_prunes=8):
        """Post-optimization pruning based on effective contribution of subtrees."""
        if tree.size <= 2:
            return tree

        # Use a representative subset for validation speed
        X, y = self.X_data, self.y_data
        if len(X) > 256:
            np_rng = np.random.default_rng(0) # Stable sample for pruning
            idx = np_rng.choice(len(X), 256, replace=False)
            X, y = X[idx], y[idx]

        curr_tree = tree
        for _ in range(max_prunes):
            best_p = None
            best_score = -np.inf

            # Bottom-up scan for best pruning target
            # Skip nodes that are already constants to avoid infinite loops
            for i in reversed(range(1, curr_tree.size)):
                sub = curr_tree.get_subtree(i)
                if sub is None or type(sub).__name__ in ["Constant", "OptimizableConstant"]:
                    continue

                info = self._evaluate_prune_candidate(curr_tree, i, X, y)
                if info and self._should_prune_candidate(info):
                    score = self._prune_score(info)
                    if score > best_score:
                        best_score = score
                        best_p = info

            if best_p:
                new_tree = best_p["pruned_tree"]
                if str(new_tree) == str(curr_tree):
                    break
                curr_tree = new_tree
                if curr_tree.size <= 2:
                    break
            else:
                break
        return curr_tree

    def update_penalty(self, stall_count):
        """
        Adjusts the complexity penalty based on search stagnation.
        Penalty increases by 10% per stall generation.
        """
        factor = 1.0 + 0.1 * stall_count
        self.current_complexity_penalty = self.base_complexity_penalty * factor

    def _evaluate(self, x, out, *args, **kwargs):
        try:
            tid = int(x[0])
            tree = self.get_tree(tid)
            if tree is None:
                out["F"] = [1e9, 1e9]
                return

            objs = self.evaluate_tree(tree, tree_id=tid)
            # Return full set of objectives to the engine
            out["F"] = objs[: len(self.objectives)]
        except Exception as e:
            if getattr(self, "verbose", False):
                logger.error(f"Problem evaluation fail: {e}")
            out["F"] = [1e9, 1e9]


# ---------------------------------------------------------------------------
# Grammatical Evolution Core
# ---------------------------------------------------------------------------


def build_math_grammar(n_features, binary_ops, unary_ops, ternary_ops, literal_types):
    """Builds a BNF Grammar for Mathematical Symbolic Regression"""
    g = Grammar(start_symbol="<expr>")

    # Helpers for feature mapping
    def ge_variable(f_idx):
        return Variable(f_idx % n_features)

    def ge_threshold(f_idx, val, op_idx):
        return Threshold(f_idx % n_features, val, op_idx % 2)

    def ge_interval(f_idx, low, high, sharp):
        return Interval(f_idx % n_features, low, high, sharp)

    def ge_ratio(f1_idx, f2_idx, thresh):
        return Ratio(f1_idx % n_features, f2_idx % n_features, thresh)

    def ge_gaussian(f_idx, mu, sigma):
        return Gaussian(f_idx % n_features, mu, sigma)

    # 1. Operators
    expr_rules = []
    if binary_ops:
        for op in binary_ops:
            expr_rules.append([op, "<expr>", "<expr>"])
    if unary_ops:
        for op in unary_ops:
            expr_rules.append([op, "<expr>"])
    if ternary_ops:
        for op in ternary_ops:
            # Assumes SoftIf style
            expr_rules.append([op, "<cond>", "<expr>", "<expr>"])

    # Terminals (Balanced to ensure termination)
    # Adding multiple copies to increase the probability of choosing a terminal.
    for _ in range(10):
        expr_rules.append(["<literal>"])
    g.add_rule("<expr>", expr_rules)

    # 2. Conditions (for SoftIf)
    cond_rules = []
    if literal_types:
        if Threshold in literal_types:
            cond_rules.append([ge_threshold, "__gene__", "__gene_float__", "__gene__"])
        if Interval in literal_types:
            cond_rules.append([ge_interval, "__gene__", "__gene_float__", "__gene_float__", 10.0])
    if not cond_rules:
        cond_rules.append([ge_threshold, "__gene__", 0.5, 0])

    g.add_rule("<cond>", cond_rules)

    # 3. Literals / Variables
    lit_rules = []
    lit_rules.append([ge_variable, "__gene__"])
    lit_rules.append([OptimizableConstant, "__gene_float_biased__"])

    if Ratio in literal_types:
        lit_rules.append([ge_ratio, "__gene__", "__gene__", "__gene_float__"])
    if Gaussian in literal_types:
        lit_rules.append([ge_gaussian, "__gene__", "__gene_float__", "__gene_float__"])

    g.add_rule("<literal>", lit_rules)

    return g


class SymbolicGEProblem(SymbolicRegressionProblem):
    """
    Subclass of SymbolicRegressionProblem designed for Grammatical Evolution.
    The primary difference is that 'evaluate' expects a genotype (vector of integers)
    instead of just a tree ID.
    """

    def __init__(
        self,
        X,
        y,
        n_features,
        binary_ops,
        unary_ops,
        ternary_ops,
        literal_types,
        complexity_penalty=0.0,
        genotype_len=50,
        optimizer="BFGS",
        n_restarts=0,
        objectives=None,
        complexity_weights=None,
        residual_mode="feature_corr",
        huber_delta=1.0,
    ):
        # We need n_var = genotype_len for the GA to evolve the vector
        super().__init__(
            X,
            y,
            n_features,
            binary_ops,
            unary_ops,
            literal_types,
            complexity_penalty,
            optimizer,
            n_restarts,
            objectives,
            complexity_weights,
            residual_mode,
            huber_delta,
        )
        self.n_var = genotype_len
        self.xl = np.zeros(self.n_var)
        self.xu = np.full(self.n_var, 255)

        # Setup Grammar and Mapper
        self.grammar = build_math_grammar(n_features, binary_ops, unary_ops, ternary_ops, literal_types)

        # Enhanced Mapper to support our special __tags__
        from ezga.simple.grammar import OptimizableConstant

        # We need to capture y_mean/y_std for biased constants
        ym = np.mean(y)
        ys = np.std(y) + 1e-6

        class BiasedGEMapper(GEMapper):
            def _derive(self, symbol, depth):
                if symbol == "__gene_float_biased__":
                    g = self._get_gene()
                    # Map to y_mean +/- y_std
                    val = ym + ((g % 2000) - 1000) / 1000.0 * ys
                    return OptimizableConstant(val)

                # Special handling for feature indices in parametric terminals
                # If we see a Constructor that is Threshold/Variable etc, help it map __gene__ to feat
                return super()._derive(symbol, depth)

        self.mapper = BiasedGEMapper(self.grammar, max_depth=50, max_wraps=20)
        self.mapper.n_features = n_features  # For feature wrapping in constructors

    def evaluate_tree_ge(self, tree):
        # Similar to evaluate_tree but without tree_id persistence since
        # genotypes create transient trees (or we can cache them)
        return self.evaluate_tree(tree)

    def _evaluate(self, x, out, *args, **kwargs):
        # x is the genotype (int vector)
        genotype = x.astype(int)

        # 1. Map to tree
        try:
            tree = self.mapper.map(genotype)
        except Exception as e:
            if getattr(self, "verbose", False):
                logger.error(f"GE Mapping Fail: {type(e).__name__}: {e}")
            tree = None

        if tree is None:
            out["F"] = [1e9, 1e9]
            return

        # 2. Evaluate
        try:
            objs = self.evaluate_tree(tree)
            out["F"] = objs[: len(self.objectives)]
        except Exception as e:
            if getattr(self, "verbose", False):
                logger.error(f"GE evaluation fail: {e}")
            out["F"] = [1e9, 1e9]


class SymbolicRegressor:
    # Shared Operator Presets
    # Default: Enabled automatically, safe, domain-agnostic.
    # Opt-in: Must be enabled explicitly (discontinuities, strong priors).
    _DEFAULT_OPS = {
        "binary": ["add", "sub", "mul"],
        "unary": ["neg", "exp", "square", "cube"],
        "ternary": [],
        "literal": ["variable", "constant"],
    }

    PRESETS = {
        "default": _DEFAULT_OPS,
        "basic": {
            "binary": _DEFAULT_OPS["binary"] + ["div"],
            "unary": _DEFAULT_OPS["unary"] + ["sqrt"],
            "ternary": [],
            "literal": ["variable", "constant", "optimizableconstant"],
        },
        "math": {
            "binary": _DEFAULT_OPS["binary"] + ["div"],
            "unary": _DEFAULT_OPS["unary"] + ["sin", "cos", "log", "sqrt", "abs"],
            "ternary": [],
            "literal": ["variable", "constant", "optimizableconstant"],
        },
        "physics": {
            "binary": _DEFAULT_OPS["binary"] + ["div"],
            "unary": _DEFAULT_OPS["unary"] + ["sin", "cos", "sqrt"],
            "ternary": [],
            "literal": _DEFAULT_OPS["literal"] + ["gaussian", "optimizableconstant"],
        },
        "all": {
            "binary": _DEFAULT_OPS["binary"] + ["div", "min", "max"],
            "unary": _DEFAULT_OPS["unary"] + ["sin", "cos", "log", "sqrt", "abs"],
            "ternary": ["softif"],
            "literal": _DEFAULT_OPS["literal"] + ["gaussian", "threshold", "interval", "ratio", "optimizableconstant"],
        },
    }

    def __init__(
        self,
        pop_size=100,
        pop_size_max=None,
        generations=50,
        n_features=1,
        binary_ops=None,
        unary_ops=None,
        ternary_ops=None,
        literal_types=None,
        extra_binary_ops=None,
        extra_unary_ops=None,
        extra_ternary_ops=None,
        extra_literal_types=None,
        complexity_penalty=0.001,
        crossover_probability=0.3,
        mutation_rate=1.0,
        guided_mutation_prob=0.3,  # 30% of mutations use residual diagnostics
        random_state=None,
        engine="tree",
        genotype_len=512,
        feature_names=None,
        verbose=False,
        preset=None,
        optimizer="BFGS",
        n_restarts=0,
        seed_fraction=1.0,
        save_generations=False,
        objectives=None,
        complexity_weights=None,
        residual_mode="feature_corr",
        huber_delta=1.0,
    ):

        self.pop_size = pop_size
        self.pop_size_max = pop_size_max
        self.generations = generations
        self.n_features = n_features
        self.complexity_penalty = complexity_penalty
        self.crossover_probability = crossover_probability
        self.mutation_rate = mutation_rate
        self.guided_mutation_prob = guided_mutation_prob
        self.random_state = random_state
        self.feature_names = feature_names
        self.verbose = verbose
        self.optimizer = optimizer
        self.n_restarts = n_restarts
        self.seed_fraction = seed_fraction
        self.save_generations = save_generations
        self.engine = engine

        # Multi-objective configuration
        self.objectives = objectives or ["mae", "complexity", "residual_structure"]
        self.complexity_weights = complexity_weights
        self.residual_mode = residual_mode
        self.huber_delta = huber_delta

        # Resolve Configuration
        selected_preset = self.PRESETS.get(preset, self._DEFAULT_OPS) if preset else self._DEFAULT_OPS

        # Allow overrides + extension
        def resolve_combined(provided, extra, preset_list):
            base = provided if provided is not None else preset_list
            if extra:
                base = list(base) + list(extra)
            return self._resolve_ops(base)

        self.binary_ops = resolve_combined(binary_ops, extra_binary_ops, selected_preset["binary"])
        self.unary_ops = resolve_combined(unary_ops, extra_unary_ops, selected_preset["unary"])
        self.ternary_ops = resolve_combined(ternary_ops, extra_ternary_ops, selected_preset["ternary"])
        self.literal_types = resolve_combined(literal_types, extra_literal_types, selected_preset["literal"])

        self.best_tree = None
        self.best_fitness = float("inf")
        self.engine = engine
        self.genotype_len = genotype_len

    @staticmethod
    def get_supported_operators():
        """
        Returns a dictionary of supported operators categorized by type.
        """
        return {
            "Binary (binary_ops)": {
                "add": Add,
                "sub": Sub,
                "mul": Mul,
                "div": Div,
                "min": Min,
                "max": Max,
                "and": AND,
                "or": OR,
            },
            "Unary (unary_ops)": {
                "sin": Sin,
                "cos": Cos,
                "exp": Exp,
                "log": Log,
                "sqrt": Sqrt,
                "abs": Abs,
                "square": Square,
                "cube": Cube,
                "neg": Neg,
            },
            "Ternary (ternary_ops)": {"softif": SoftIf},
            "Literals (literal_types)": {
                "variable": Variable,
                "constant": Constant,
                "optimizableconstant": OptimizableConstant,
                "threshold": Threshold,
                "interval": Interval,
                "ratio": Ratio,
                "gaussian": Gaussian,
            },
        }

    @staticmethod
    def print_available_ops():
        """
        Typing helper: Prints all available operator strings that can be used in configuration.
        """
        ops = SymbolicRegressor.get_supported_operators()
        print("--- Available Symbolic Regressor Operators ---")
        for category, op_map in ops.items():
            print(f"\n[{category}]")
            # Print keys in rows of 4
            keys = sorted(list(op_map.keys()))
            for i in range(0, len(keys), 4):
                print("  " + ", ".join(f"'{k}'" for k in keys[i : i + 4]))
        print("\n--------------------------------------------")

    def _resolve_ops(self, ops_list):
        """
        Maps a list of strings (or mixed classes) to actual Operator classes.
        Example: ['add', Sub] -> [Add, Sub]
        """
        if ops_list is None:
            return []

        # Flatten the categorized map for lookup
        full_map = {}
        for cat_map in self.get_supported_operators().values():
            full_map.update(cat_map)

        resolved = []
        for op in ops_list:
            if isinstance(op, str):
                key = op.lower().strip()
                if key in full_map:
                    resolved.append(full_map[key])
                else:
                    print(f"Warning: Unknown operator '{op}'. Ignoring.")
            else:
                # Assume it's a class
                resolved.append(op)
        return resolved

    def _get_initial_seeds(self, X, y, rng):
        """Generate heuristic initial trees to seed the population."""
        y_mean = np.mean(y)
        y_std = np.std(y) + 1e-6
        y_max = np.max(y)  # amplitude for Gaussian seeds
        y_argmax_idx = int(np.argmax(y))  # sample index of peak

        feat_stats = []
        for f in range(self.n_features):
            col = X[:, f]
            feat_stats.append(
                {
                    "min": float(np.min(col)),
                    "max": float(np.max(col)),
                    "mean": float(np.mean(col)),
                    "std": float(np.std(col)) + 1e-6,
                    "argmax": float(col[y_argmax_idx]),
                    "p25": float(np.percentile(col, 25)),
                    "p50": float(np.percentile(col, 50)),
                    "p75": float(np.percentile(col, 75)),
                }
            )

        seeds = []

        # Helper to check if ops are allowed
        has_add = Add in self.binary_ops
        has_mul = Mul in self.binary_ops
        has_square = Square in self.unary_ops
        has_sin = Sin in self.unary_ops
        has_cos = Cos in self.unary_ops
        has_gauss = Gaussian in self.literal_types
        has_ratio = Ratio in self.literal_types
        has_opt_const = OptimizableConstant in self.literal_types
        has_const = Constant in self.literal_types
        has_var = Variable in self.literal_types

        def wrap_const(val):
            if has_opt_const:
                return OptimizableConstant(val)
            if has_const:
                return Constant(val)
            return None

        # 1. Constants (Bias)
        c_mean = wrap_const(y_mean)
        if c_mean:
            seeds.append(c_mean)
        c_zero = wrap_const(0.0)
        if c_zero:
            seeds.append(c_zero)

        # 2. Linear Regressions (y ~ a*xi + b)
        # We add one true linear seed per feature with fitted coefficients
        if has_var and has_add and has_mul:
            for f in range(self.n_features):
                xi = X[:, f]
                x_mean = feat_stats[f]["mean"]
                x_var = (feat_stats[f]["std"]) ** 2
                # Ensure y is raveled to avoid broadcasting issues if y is 2D (N,1)
                cov = np.mean((xi - x_mean) * (y.ravel() - y_mean))

                a = cov / x_var
                b = y_mean - a * x_mean

                # Seed with x * a + b
                # This directly provides A*x + B structure for BFGS to refine
                if has_opt_const:
                    # Model: (x * a) + b
                    lin_tree = Add(Mul(Variable(f), OptimizableConstant(a)), OptimizableConstant(b))
                    seeds.append(lin_tree)
                    # Also just the scaled variable: x * a
                    seeds.append(Mul(Variable(f), OptimizableConstant(a)))
                elif has_const:
                    seeds.append(Add(Mul(Variable(f), Constant(a)), Constant(b)))

        # 3. Linear (Multivariate Sum)
        if self.n_features > 1 and has_add and has_mul and has_var:
            poly_sum = wrap_const(y_mean)
            if poly_sum:
                for f in range(min(self.n_features, 10)):
                    c_s = wrap_const(0.1)
                    if c_s:
                        term = Mul(c_s, Variable(f))
                        poly_sum = Add(poly_sum, term)
                seeds.append(poly_sum)

        # 4. Quadratic
        if has_square and has_mul and has_var:
            for f in range(self.n_features):
                q = Square(Variable(f))
                scale = y_std / (feat_stats[f]["std"] ** 2 + 1e-6)
                c_scale = wrap_const(scale)
                if c_scale:
                    seeds.append(Mul(c_scale, q))

        # 5. Bilinear Interactions (x_i * x_j)
        if self.n_features >= 2 and has_mul:
            for i in range(min(self.n_features, 3)):
                for j in range(i + 1, min(self.n_features, 4)):
                    seeds.append(Mul(Variable(i), Variable(j)))

        # 6. Trigonometric Seeds — conditional on data periodicity evidence
        # Only inject trig seeds if the data shows clear periodic structure.
        # This prevents trig over-representation in non-periodic problems.
        # Gate: check if FFT has a dominant frequency above noise floor.
        if (has_sin or has_cos) and has_var and has_mul:
            for f in range(min(self.n_features, 3)):  # Reduced from 5 to 3
                col = X[:, f]
                # Periodicity test: dominant FFT frequency must stand above 3× median
                try:
                    np.abs(np.fft.rfft(col - np.mean(col)))[1:]  # skip DC
                    fft_mag_y = np.abs(np.fft.rfft(y - np.mean(y)))[1:]
                    # Check if the y-signal has periodic structure via its FFT
                    len(fft_mag_y)
                    peak_y = np.max(fft_mag_y)
                    median_y = np.median(fft_mag_y) + 1e-12
                    data_is_periodic = peak_y > 3.0 * median_y
                except Exception:
                    data_is_periodic = False

                if not data_is_periodic:
                    continue  # Skip trig seeds for this feature — not evidently periodic

                # Only 2 seeds per feature: the dominant frequency + data-std-based
                std_f = feat_stats[f]["std"] + 1e-6
                try:
                    fft_freqs = np.fft.rfftfreq(len(col), d=max(std_f / len(col), 1e-9))[1:]
                    dominant_k = float(fft_freqs[np.argmax(np.abs(np.fft.rfft(col - np.mean(col)))[1:])])
                    dominant_k = max(0.01, min(dominant_k, 100.0))
                except Exception:
                    dominant_k = 1.0 / std_f

                for k_val in [dominant_k, 1.0 / std_f]:  # Only 2 freq candidates
                    k_const = wrap_const(k_val)
                    if not k_const:
                        continue
                    arg = Mul(Variable(f), k_const)
                    # Simple form + amplitude-scaled form
                    if has_sin:
                        seeds.append(Sin(arg))
                    if has_cos:
                        seeds.append(Cos(arg))
                    if has_add and has_opt_const:
                        a_c = wrap_const(y_std)
                        b_c = wrap_const(y_mean)
                        if a_c and b_c:
                            if has_sin:
                                seeds.append(Add(Mul(Sin(Mul(Variable(f), wrap_const(k_val))), a_c), b_c))

        # 7. Gaussian
        if has_gauss and has_mul and has_var:
            for f in range(min(self.n_features, 5)):
                std = feat_stats[f]["std"]
                for mu in [feat_stats[f]["argmax"], feat_stats[f]["p50"]]:
                    g = Gaussian(f, mu, std * 0.3)
                    c_amp = wrap_const(y_max)
                    if c_amp:
                        seeds.append(Mul(c_amp, g))

        # 8. Ratio
        if has_ratio and self.n_features >= 2:
            seeds.append(Ratio(0, 1, 1.0))

        if self.verbose:
            logger.info(f"Generated {len(seeds)} heuristic seeds using allowed operators.")

        return seeds

    def fit(self, X, y):
        # 0. Data Handling (Auto-detect Pandas)
        if pd is not None:
            if isinstance(X, (pd.DataFrame, pd.Series)):
                if hasattr(X, "columns") and self.feature_names is None:
                    self.feature_names = list(X.columns)
                X = X.values
            if isinstance(y, (pd.DataFrame, pd.Series)):
                y = y.values.flatten()

        # Ensure y is a flattened numpy array even if passed as numpy (N, 1)
        y = np.asanyarray(y).flatten()

        # Auto-detect n_features if inconsistent
        if X.ndim == 2:
            if X.shape[1] != self.n_features:
                if self.verbose:
                    print(f"Adjusting n_features from {self.n_features} to {X.shape[1]}")
                self.n_features = X.shape[1]
        elif X.ndim == 1:
            X = X.reshape(-1, 1)
            self.n_features = 1

        self._X_train = np.copy(X)

        # 1. Setup Problem
        if self.engine == "ge":
            problem = SymbolicGEProblem(
                X,
                y,
                self.n_features,
                self.binary_ops,
                self.unary_ops,
                self.ternary_ops,
                self.literal_types,
                self.complexity_penalty,
                genotype_len=self.genotype_len,
                optimizer=self.optimizer,
                n_restarts=self.n_restarts,
                objectives=self.objectives,
                complexity_weights=self.complexity_weights,
                residual_mode=self.residual_mode,
                huber_delta=self.huber_delta,
            )
        else:
            problem = SymbolicRegressionProblem(
                X,
                y,
                self.n_features,
                self.binary_ops,
                self.unary_ops,
                self.literal_types,
                complexity_penalty=self.complexity_penalty,
                optimizer=self.optimizer,
                n_restarts=self.n_restarts,
                objectives=self.objectives,
                complexity_weights=self.complexity_weights,
                residual_mode=self.residual_mode,
                huber_delta=self.huber_delta,
                ternary_ops=self.ternary_ops,
            )

        # 2. Setup Algorithm and Variation
        rng = np.random.default_rng(self.random_state)

        if self.engine == "ge":
            algorithm = GA(
                pop_size=self.pop_size,
                pop_size_max=self.pop_size_max,
                sampling=None,
                enable_bo=False,
                selection="nsga3",
            )
            # Fix: Ensure minimize() picks up GEVariation as the primary variation operator
            # By setting both .variation and .mutation/.crossover, we cover both minimize() patterns
            ge_var = GEVariation(genotype_len=self.genotype_len, mutation_rate=0.2, crossover_rate=0.7)
            algorithm.variation = ge_var
            algorithm.mutation = ge_var
            algorithm.crossover = ge_var
        else:
            # Tree-based: 30% Informed Seeds, 70% Ramped Half-and-Half Random
            init_ids = np.zeros((self.pop_size, 1))
            seeds = self._get_initial_seeds(X, y, rng)

            n_seeds = int(self.pop_size * self.seed_fraction)

            for i in range(self.pop_size):
                tid = i + 1
                init_ids[i, 0] = tid

                if i < n_seeds and len(seeds) > 0:
                    # Pick from seed library (cycling if seeds < n_seeds)
                    tree = copy.deepcopy(seeds[i % len(seeds)])
                else:
                    # Ramped Half-and-Half (depths 2 to 6)
                    # Calculate depth and method based on index remainder
                    pop_idx = i - n_seeds
                    self.pop_size - n_seeds

                    # Distribute depths 2..6
                    depth = 2 + (pop_idx % 5)
                    # Alternating method
                    meth = "grow" if (pop_idx // 5) % 2 == 0 else "full"

                    tree = generate_random_tree(
                        self.n_features,
                        rng,
                        max_depth=depth,
                        binary_ops=self.binary_ops,
                        unary_ops=self.unary_ops,
                        ternary_ops=self.ternary_ops,
                        literal_types=self.literal_types,
                        method=meth,
                    )
                problem.register_tree(tid, tree)

            algorithm = GA(
                pop_size=self.pop_size,
                pop_size_max=self.pop_size_max,
                sampling=init_ids,
                enable_bo=False,
                selection="nsga3",
                eliminate_duplicates=True,  # Avoid redundant trees
            )
            # Enable elitism by ensuring top-k are kept (GA usually keeps best, but we can be explicit if needed)
            # For NSGA2/3, the best front is always kept.
            algorithm.mutation = SymbolicMathMutation(
                self.n_features,
                problem=problem,
                mutation_rate=4.0,
                binary_ops=self.binary_ops,
                unary_ops=self.unary_ops,
                ternary_ops=self.ternary_ops,
                literal_types=self.literal_types,
                pop_size=self.pop_size,
                max_generations=self.generations,
                guided_prob=self.guided_mutation_prob,
                rng=rng
            )
            algorithm.crossover = SymbolicMathCrossover(problem=problem, rng=rng)

        # 4. Minimize
        res = minimize(
            problem,
            algorithm,
            termination=("n_gen", self.generations),
            mutation_rate=self.mutation_rate,
            seed=self.random_state,
            verbose=self.verbose,
            save_generations=self.save_generations,
        )

        # Extract Pareto Front Results
        self.pareto_results_ = []
        if res.pop:
            min_f = float("inf")

            # Weights for scalarized best extraction (consistent with minimize)
            # Default to MSE + Weighted Complexity for "best" model selection if not specified
            w_scalar = np.ones(len(problem.objectives))
            # If we have complexity, we might want to prioritize it for 'best' selection
            if "complexity" in problem.objectives:
                idx = problem.objectives.index("complexity")
                w_scalar[idx] = problem.current_complexity_penalty

            seen_formulas = set()

            for ind in res.pop:
                try:
                    meta = getattr(ind.AtomPositionManager, "metadata", {})
                    if "objectives" in meta:
                        objs = np.array(meta["objectives"]).flatten()

                        # Find indices for MSE and Complexity for result mapping
                        # We use MSE (or first error metric) as the primary MSE value
                        error_metrics = ["mse", "rmse", "nrmse", "mae", "huber"]
                        mse_idx = -1
                        for i, name in enumerate(problem.objectives):
                            if name in error_metrics:
                                mse_idx = i
                                break

                        complexity_idx = -1
                        if "complexity" in problem.objectives:
                            complexity_idx = problem.objectives.index("complexity")

                        mse_val = float(objs[mse_idx]) if mse_idx != -1 else float(objs[0])
                        complexity_val = float(objs[complexity_idx]) if complexity_idx != -1 else 0.0

                        # Scalarize for comparison
                        f_scalar = np.dot(objs, w_scalar[: len(objs)])
                    else:
                        e_val = ind.AtomPositionManager.E
                        if e_val is not None:
                            f_scalar = float(np.atleast_1d(e_val)[0])
                            mse_val = f_scalar
                            complexity_val = 0.0  # Unknown
                        else:
                            continue

                    # Extract Tree
                    tree = None
                    if self.engine == "ge":
                        genes = ind.AtomPositionManager.atomPositions[:, 0].astype(int)
                        try:
                            tree = problem.mapper.map(genes)
                            if tree:
                                tree = tree.simplify_aggressive()
                            else:
                                if self.verbose:
                                    logger.warning(f"GE Mapping Fail for ind {getattr(ind, 'id', 'unknown')}: Mapper returned None")
                        except Exception as mapping_err:
                            if self.verbose:
                                logger.error(f"GE Mapping Exception for ind {getattr(ind, 'id', 'unknown')}: {mapping_err}")
                            tree = None
                    else:
                        pos = ind.AtomPositionManager.atomPositions
                        if len(pos) > 0:
                            tid = pos[0][0]
                            tree = problem.get_tree(tid)
                            if tree:
                                tree = tree.simplify_aggressive()

                    if tree:
                        formula = str(tree)
                        if formula not in seen_formulas:
                            seen_formulas.add(formula)
                            self.pareto_results_.append(
                                {
                                    "tree": tree,
                                    "mse": mse_val,
                                    "complexity": complexity_val,
                                    "fitness": f_scalar,
                                }
                            )
                    elif self.verbose and self.engine == "ge":
                        # If we reached here, tree is None but it's GE engine
                        pass

                    if f_scalar is not None and f_scalar < min_f:
                        # We only update best_tree if we actually have a valid tree
                        if tree is not None:
                            min_f = f_scalar
                            self.best_tree = tree
                            self.best_fitness = min_f
                except Exception as e:
                    if self.verbose:
                        logger.warning(f"Error extracting individual: {e}")
                    continue

            # Sort Pareto front by complexity for coherent plotting
            self.pareto_results_.sort(key=lambda x: x["complexity"])

        return self

    def predict(self, X):
        if self.best_tree:
            X = np.asarray(X)
            if X.ndim == 1:
                X = X.reshape(-1, 1)
            return self.best_tree.evaluate(X)
        X = np.asarray(X)
        return np.zeros(X.shape[0])

    def predict_all(self, X):
        """
        Predicts target values for each model discovered in the Pareto front.

        Args:
            X: Input features.

        Returns:
            Dictionary mapping model expressions to their predictions.
        """
        if not hasattr(self, "pareto_results_") or not self.pareto_results_:
            return {}

        X = np.asarray(X)
        if X.ndim == 1:
            X = X.reshape(-1, 1)

        results = {}
        for res in self.pareto_results_:
            tree = res["tree"]
            formula = self._format_expression(tree)
            try:
                results[formula] = tree.evaluate(X)
            except Exception:
                results[formula] = np.zeros(X.shape[0])

        return results

    def get_models(self, X=None, y=None, n=None, sort_by="complexity"):
        """
        Returns a structured summary of models discovered in the Pareto front.

        Args:
            X: Optional input features for R^2 calculation.
            y: Optional target values for R^2 calculation.
            n: Limit results to top-N models. If None, returns all.
            sort_by: Metric to sort by ('complexity', 'error'/'mse', or 'fitness').

        Returns:
            List of dictionaries containing 'formula', 'mse', 'complexity', 'fitness',
            and 'tree'. If X/y provided, also includes 'r2'.
        """
        if not hasattr(self, "pareto_results_") or not self.pareto_results_:
            return []

        # Re-sort local copy if needed
        results = list(self.pareto_results_)
        if sort_by in ["error", "mse"]:
            results.sort(key=lambda x: x.get("mse", x.get("error", 0.0)))
        elif sort_by == "fitness":
            results.sort(key=lambda x: x.get("fitness", 0.0))
        else:  # Default by complexity
            results.sort(key=lambda x: x.get("complexity", x["tree"].size if hasattr(x["tree"], "size") else 0))

        if n is not None:
            results = results[:n]

        output = []

        # Helper for R2
        def calculate_r2(yp, yt):
            ss_res = np.sum((yt - yp) ** 2)
            ss_tot = np.sum((yt - np.mean(yt)) ** 2)
            return 1 - (ss_res / (ss_tot + 1e-12))

        for res in results:
            model_data = {
                "formula": self._format_expression(res["tree"]),
                "mse": float(res.get("mse", res.get("error", 0.0))),
                "complexity": int(res.get("complexity", res["tree"].size if hasattr(res["tree"], "size") else 0)),
                "fitness": float(res.get("fitness", 0.0)),
                "tree": res["tree"],
            }

            if X is not None and y is not None:
                try:
                    yp = res["tree"].evaluate(np.asarray(X))
                    model_data["r2"] = float(calculate_r2(yp, np.asarray(y)))
                except Exception:
                    # print(f"DEBUG: Caught exception in get_models: {e}")
                    model_data["r2"] = 0.0

            output.append(model_data)

        return output

    def _format_expression(self, tree):
        """Helper to format a tree expression with feature names."""
        if tree is None:
            return ""
        formula = str(tree)
        if self.feature_names:
            # Sort feature names by length descending to avoid partial replacement of x1 with x10
            for i in range(len(self.feature_names) - 1, -1, -1):
                raw_token = f"x{i}"
                pattern = rf"{raw_token}"
                formula = re.sub(pattern, self.feature_names[i], formula)
        return formula

    def score(self, X, y):
        y_pred = self.predict(X)
        y = np.asarray(y).flatten()
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        if ss_tot == 0:
            return 1.0 if np.allclose(y, y_pred) else -np.inf
        return 1 - (ss_res / ss_tot)

    @property
    def expression(self):
        return self._format_expression(self.best_tree) or "None"

    @property
    def simplified_expression(self):
        """Returns a simplified SymPy expression replacing trigs with tuned polynomials."""
        if self.best_tree is None:
            return "None"
        try:
            import re

            from ezga.simple.trig_substitution import (
                ezga_expr_to_sympy,
                replace_trig_by_fitted_polynomial_in_variable,
            )

            expr_sym = ezga_expr_to_sympy(str(self.best_tree))

            if not hasattr(self, "_X_train") or self._X_train is None:
                return str(expr_sym)

            simplified = replace_trig_by_fitted_polynomial_in_variable(
                expr_sym, self._X_train, max_degree=5, error_tol=0.02, verbose=False
            )

            formula = str(simplified)
            if self.feature_names:
                for i in range(len(self.feature_names) - 1, -1, -1):
                    raw_token = f"x{i}"
                    pattern = rf"{raw_token}"
                    formula = re.sub(pattern, self.feature_names[i], formula)
            return formula
        except Exception:
            # Fallback to normal expression if simplification fails
            return self.expression

    def plot_results(self, X, y, outfile=None, title="Symbolic Regression Fit"):
        """
        Simple built-in plotter for 1D symbolic regression results.
        """
        if plt is None:
            print("Matplotlib not installed. Cannot plot.")
            return

        if self.n_features != 1:
            print(f"Built-in plot only supports 1D data (features={self.n_features}). Use custom plotting.")
            return

        # Handle Pandas
        if pd is not None:
            if isinstance(X, (pd.DataFrame, pd.Series)):
                X = X.values
            if isinstance(y, (pd.DataFrame, pd.Series)):
                y = y.values.flatten()

        X = X.reshape(-1, 1)
        y_pred = self.predict(X)

        plt.figure(figsize=(10, 6))
        plt.scatter(X, y, color="black", alpha=0.5, label="Data")

        # Sort X for clean line plotting
        sort_idx = np.argsort(X[:, 0])
        plt.plot(X[sort_idx], y_pred[sort_idx], color="red", linewidth=2, label="Model Prediction")

        plt.title(f"{title}\nExpr: {self.expression}")
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.xlabel(self.feature_names[0] if self.feature_names else "x0")
        plt.ylabel("Target")

        if outfile:
            plt.savefig(outfile)
            print(f"Plot saved to {outfile}")
        else:
            plt.show()

    def plot_pareto_front(self, outfile=None):
        """
        Plots the Complexity vs MSE Pareto front for discovered models.
        """
        if plt is None:
            print("Matplotlib not installed.")
            return

        if not hasattr(self, "pareto_results_") or not self.pareto_results_:
            print("No Pareto results available. Did you run fit()?")
            return

        complexities = [x["complexity"] for x in self.pareto_results_]
        mses = [x["mse"] for x in self.pareto_results_]

        plt.figure(figsize=(8, 5))
        plt.scatter(complexities, mses, color="blue", alpha=0.6, label="Discovery Front")

        # Draw a step-like Pareto front line
        # Since they are already sorted by complexity, we just compute the running minimum of MSE
        sorted_copy = sorted(self.pareto_results_, key=lambda x: x["complexity"])
        px = []
        py = []
        curr_min_mse = float("inf")
        for res in sorted_copy:
            if res["mse"] < curr_min_mse:
                curr_min_mse = res["mse"]
                px.append(res["complexity"])
                py.append(res["mse"])

        plt.step(px, py, where="post", color="red", linestyle="--", alpha=0.8, label="Pareto Front")

        plt.yscale("log")
        plt.xlabel("Complexity (Size + 0.5*Depth)")
        plt.ylabel("MSE (Log Scale)")
        plt.title("Symbolic Regression Pareto Front")
        plt.grid(True, which="both", ls="-", alpha=0.2)
        plt.legend()

        if outfile:
            plt.savefig(outfile)
        else:
            plt.show()

    def plot_all_models(self, X, y, outfile=None, max_models=10):
        """
        Plots the top Pareto models overlaid on the data (1D only).
        """
        if plt is None:
            return
        if self.n_features != 1:
            print("plot_all_models only supports 1D data.")
            return

        if not hasattr(self, "pareto_results_") or not self.pareto_results_:
            return

        # Prepare Data
        if pd is not None:
            if isinstance(X, (pd.DataFrame, pd.Series)):
                X = X.values
            if isinstance(y, (pd.DataFrame, pd.Series)):
                y = y.values.flatten()
        X = X.reshape(-1, 1)
        sort_idx = np.argsort(X[:, 0])
        X_sorted = X[sort_idx]

        plt.figure(figsize=(10, 6))
        plt.scatter(X, y, color="black", alpha=0.3, label="Data", s=10)

        # Get the real Pareto front (dominant models)
        pareto_models = []
        curr_min_mse = float("inf")
        for res in self.pareto_results_:
            if res["mse"] < curr_min_mse:
                curr_min_mse = res["mse"]
                pareto_models.append(res)

        # Limit number of models to plot
        if len(pareto_models) > max_models:
            # Pick a subset spaced out by complexity
            indices = np.linspace(0, len(pareto_models) - 1, max_models, dtype=int)
            plot_subset = [pareto_models[i] for i in indices]
        else:
            plot_subset = pareto_models

        # Use a colormap
        cmap = plt.get_cmap("viridis")
        for i, res in enumerate(plot_subset):
            y_pred = res["tree"].evaluate(X)
            label = f"Size: {res['tree'].size:.0f}, MSE: {res['mse']:.3f}"

            # Use color based on complexity
            color = cmap(i / max(1, len(plot_subset) - 1))
            plt.plot(X_sorted, y_pred[sort_idx], color=color, alpha=0.7, linewidth=1.5, label=label)

        plt.title(f"Discovered Pareto Front Models\nBest: {self.expression}")
        plt.legend(bbox_to_anchor=(1.05, 1), loc="upper left", fontsize="small")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.grid(True, alpha=0.2)
        plt.tight_layout()

        if outfile:
            plt.savefig(outfile)
        else:
            plt.show()


class MultiTargetSymbolicRegressor:
    """
    Orchestrator for multi-output symbolic regression (R^n -> R^m).
    Fits an independent SymbolicRegressor for each target dimension.
    """

    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.regressors = []
        self.n_targets = 0

    def fit(self, X, y):
        # 0. Data Handling for Target
        if hasattr(y, "values"):  # Pandas
            y = y.values

        if y.ndim == 1:
            y = y.reshape(-1, 1)

        self.n_targets = y.shape[1]
        self.regressors = []

        for i in range(self.n_targets):
            if self.kwargs.get("verbose"):
                print(f"\n[MultiTarget] Fitting Output Dim {i + 1}/{self.n_targets}...")

            reg = SymbolicRegressor(**self.kwargs)
            reg.fit(X, y[:, i])
            self.regressors.append(reg)

        return self

    def predict(self, X):
        preds = []
        for reg in self.regressors:
            preds.append(reg.predict(X))
        return np.column_stack(preds)

    def score(self, X, y):
        if hasattr(y, "values"):
            y = y.values
        if y.ndim == 1:
            y = y.reshape(-1, 1)

        scores = []
        for i, reg in enumerate(self.regressors):
            scores.append(reg.score(X, y[:, i]))
        return np.mean(scores)

    @property
    def expressions(self):
        """Returns a list of strings representing the expressions for each output dimension."""
        return [reg.expression for reg in self.regressors]

    @property
    def simplified_expressions(self):
        """Returns a list of strings representing the simplified expressions for each output dimension."""
        return [reg.simplified_expression for reg in self.regressors]

    @property
    def best_trees(self):
        """Returns the list of best Tree objects found for each output."""
        return [reg.best_tree for reg in self.regressors]
