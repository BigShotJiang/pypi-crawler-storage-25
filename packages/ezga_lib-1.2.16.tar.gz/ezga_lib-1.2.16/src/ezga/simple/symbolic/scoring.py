from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import numpy as np

@dataclass
class BackendScore:
    """Standardized scoring result for any formulation."""
    loss: float
    penalty: float = 0.0
    complexity: float = 0.0
    diagnostics: Dict[str, Any] = field(default_factory=dict)

    @property
    def total(self) -> float:
        """The final fitness value used for internal selection."""
        return self.loss + self.penalty + self.complexity

class ExternalModelScorer:
    """Unified metric to compare models from different formulations fairly."""
    def __init__(self, global_data: Optional[Any] = None, complexity_penalty: float = 0.001):
        self.global_data = global_data
        self.complexity_penalty = complexity_penalty

    def score(self, individual: Any, engine: Any, global_data: Any) -> float:
        """
        Computes a non-backend-specific score (e.g., Hold-out MSE + Complexity).
        Used for the final ranking and the shared elite archive.
        """
        try:
            # Vectorized evaluation on the global data (X, y)
            y_pred = engine.evaluate(individual.tree, global_data.X)
            # Standard MSE
            mse = float(np.mean((global_data.y - y_pred)**2))
            
            # MDL-like complexity penalty
            complexity = float(individual.tree.size)
            
            return mse * (1.0 + self.complexity_penalty * complexity)
        except Exception:
            return 1e18
