from __future__ import annotations
import numpy as np
from typing import Any, List, Dict, Optional
from dataclasses import dataclass

@dataclass
class BayesianModelReport:
    """Posterior info for a symbolic model."""
    tree_str: str
    log_likelihood: float
    log_prior: float
    posterior: float
    complexity: float

class BayesianModelSelector:
    """
    Posterior re-ranking of candidate symbolic models.
    This class does not generate symbolic structures by itself.
    Instead, it re-weights or re-ranks candidate models from multiple 
    backends using Bayesian criteria (Bayesian Information Criterion, BIC).
    """
    def __init__(self, noise_std: float = 0.05, complexity_lambda: float = 0.5):
        self.noise_std = noise_std
        self.complexity_lambda = complexity_lambda

    def score_posterior(self, candidates: List[Any], engine: Any, global_data: Any) -> List[BayesianModelReport]:
        """
        Calculates the approximate posterior for each candidate.
        Assumes a Gaussian likelihood of the residual and a Laplacian complexity prior.
        """
        reports = []
        n_samples = len(global_data.y)
        
        for cand in candidates:
            try:
                pred = engine.evaluate(cand.tree, global_data.X)
                residual = global_data.y - pred
                mse = np.mean(residual**2)
                
                # 1. Log-Likelihood (Gaussian)
                log_L = -0.5 * n_samples * (np.log(2 * np.pi * self.noise_std**2) + mse / self.noise_std**2)
                
                # 2. Log-Prior (Exponential decay on complexity)
                complexity = cand.tree.size
                log_P = -self.complexity_lambda * complexity
                
                # 3. Posterior
                posterior = log_L + log_P
                
                reports.append(BayesianModelReport(
                    tree_str=str(cand.tree),
                    log_likelihood=log_L,
                    log_prior=log_P,
                    posterior=posterior,
                    complexity=complexity
                ))
            except Exception:
                continue
                
        # Rank by posterior
        reports.sort(key=lambda x: x.posterior, reverse=True)
        return reports
