from __future__ import annotations
import numpy as np
from typing import Any, Dict, List, Optional
from ezga.simple.grammar import Node, BinaryOperator, UnaryOperator, Constant, Variable

class ConstraintManager:
    """
    Structural constraints for symbolic search.
    Used to restrict candidate generation and/or penalize invalid models.
    """
    def __init__(self, max_depth: int = 10, max_size: int = 30, forbidden_ops: List[str] | None = None):
        self.max_depth = max_depth
        self.max_size = max_size
        self.forbidden_ops = forbidden_ops or []

    def validate(self, tree: Node) -> bool:
        """Returns True if the tree satisfies all hard constraints."""
        if tree.depth > self.max_depth:
            return False
        if tree.size > self.max_size:
            return False
        
        # Check for forbidden operators
        for node in tree.get_all_nodes():
            if node.__class__.__name__ in self.forbidden_ops:
                return False
                
        return True

    def penalty(self, tree: Node) -> float:
        """Returns a soft penalty score (higher is worse)."""
        p = 0.0
        # Example: penalize depth linearly after a threshold
        if tree.depth > self.max_depth - 2:
            p += float(tree.depth - (self.max_depth - 2)) * 0.1
            
        # Example: penalize size
        p += float(tree.size) * 0.001
        
        return p

    def check_stability(self, tree: Node, X: np.ndarray) -> bool:
        """Check if evaluating the tree on X produces NaNs or huge values."""
        try:
            y = tree.evaluate(X)
            if not np.all(np.isfinite(y)):
                return False
            if np.max(np.abs(y)) > 1e10:
                return False
            return True
        except:
            return False
