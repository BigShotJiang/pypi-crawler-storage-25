from __future__ import annotations
"""
Formulation: VariationalWeakFormulation

Mathematical idea
-----------------
The candidate symbolic expression is interpreted as a Lagrangian L(q, qdot).
Score is based on the weak-form Euler-Lagrange residual:
integral( (dL/dq - d/dt(dL/dqdot)) * eta ) dt = 0
After integration by parts:
integral( dL/dq * eta + dL/dqdot * deta ) dt = 0

Expected data
-------------
- time-series t
- state trajectory q
- first derivatives qdot (dy_dt)

Internal score
--------------
Residual of the weak Euler-Lagrange projection.

Complexity
----------
O(N) after evaluation and symbolic differentiation.

Best use cases
--------------
- conservative systems
- mechanical discovery
- noisy datasets
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData
from .weak import build_test_functions

class VariationalWeakFormulation(FormulationBackend):
    name: str = "variational_weak"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=True,
        requires_ordered_samples=True,
        requires_derivatives=True,
        supports_static_regression=False,
        supports_dynamics=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        return data.t is not None and data.dy_dt is not None

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        assert data.t is not None
        n_test = min(50, len(data.t) // 2)
        eta, deta = build_test_functions(data.t, n_test=n_test)
        return BackendPreparedData(
            matrices={"eta": eta, "deta": deta}
        )

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            # tree is L(q, qdot)
            # var_idx=0 is q, var_idx=1 is qdot
            dL_dq = engine.differentiate(tree, var_idx=0, mode="symbolic")
            dL_dqdot = engine.differentiate(tree, var_idx=1, mode="symbolic")
            
            if dL_dq is None or dL_dqdot is None:
                return BackendScore(loss=1e18) # Symbolic diff failed for this tree
            
            # Context for evaluation: [q, qdot]
            # global_data.X should contain features. 
            # In Phase 3, we assume X is the phase space context [q, qdot].
            q_context = global_data.X
            
            dL_dq_eval = engine.evaluate(dL_dq, q_context, cache=cache)
            dL_dqdot_eval = engine.evaluate(dL_dqdot, q_context, cache=cache)
            
            eta = backend_data.matrices["eta"]
            deta = backend_data.matrices["deta"]
            
            # Variational Residual: integral( dL/dq * eta + dL/dqdot * deta )
            residual = (eta @ dL_dq_eval) + (deta @ dL_dqdot_eval)
            loss = float(np.mean(residual**2))
            
            # Normalization (optional: scale by dL norms)
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
