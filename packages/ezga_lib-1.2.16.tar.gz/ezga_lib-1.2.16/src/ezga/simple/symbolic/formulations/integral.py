from __future__ import annotations
"""
Formulation: IntegralFormulation

Mathematical idea
-----------------
The dynamics are expressed cumulatively using an accumulated integral operator:
x(t_k) = x(t_0) + integral_{t_0}^{t_k} f(x(s)) ds

Expected data
-------------
- time-series t
- state trajectory y

Internal score
--------------
Residual of the accumulated model vs state change.

Complexity
----------
O(N) after evaluation.

Best use cases
--------------
- sparse time series
- moderate noise
- trend discovery
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData

class IntegralFormulation(FormulationBackend):
    name: str = "integral"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=True,
        requires_ordered_samples=True,
        supports_static_regression=False,
        supports_dynamics=True,
        supports_noise_robust_mode=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        return data.t is not None

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        assert data.t is not None
        assert data.y is not None
        dt = np.diff(data.t)
        x0 = float(data.y[0])
        dy_target = data.y - x0
        return BackendPreparedData(
            matrices={"dt": dt},
            metadata={"x0": x0, "dy_target": dy_target},
        )

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            fx = engine.evaluate(tree, global_data.X, cache=cache)
            dt = backend_data.matrices["dt"]
            dy_target = backend_data.metadata["dy_target"]
            x0 = backend_data.metadata["x0"]
            
            # Accumulated Trapezoidal integration
            f_mid = 0.5 * (fx[:-1] + fx[1:])
            steps = f_mid * dt
            dy_model = np.zeros_like(global_data.y)
            dy_model[1:] = np.cumsum(steps)
            
            residual = dy_target - dy_model
            loss = float(np.mean(residual**2))
            
            # Normalization
            dy_norm = np.mean(dy_target**2) + 1e-6
            loss /= dy_norm
            
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
