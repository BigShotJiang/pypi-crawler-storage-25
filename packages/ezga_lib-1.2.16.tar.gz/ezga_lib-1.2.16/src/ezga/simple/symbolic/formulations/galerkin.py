from __future__ import annotations
"""
Formulation: GalerkinFormulation

Mathematical idea
-----------------
The candidate symbolic equation (residual) is projected onto a finite basis 
of trial/test functions. The projection coefficients must vanish for the law to hold.

Expected data
-------------
- time-series t
- state trajectory y

Internal score
--------------
Sum of weighted squared projection coefficients.

Complexity
----------
O(MN) per evaluation, where M is basis size.

Best use cases
--------------
- orthogonal basis (Fourier, Hermite)
- spectral methods
- noise-robust dynamics
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData

class GalerkinFormulation(FormulationBackend):
    name: str = "galerkin"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=True,
        requires_ordered_samples=True,
        supports_dynamics=True,
        supports_noise_robust_mode=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        return data.t is not None

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        assert data.t is not None
        # Build an orthogonal basis (e.g., Fourier sine/cosine)
        n_basis = 10
        t_scaled = (data.t - np.min(data.t)) / (np.max(data.t) - np.min(data.t))
        basis = []
        for i in range(1, n_basis + 1):
            basis.append(np.sin(i * np.pi * t_scaled))
            basis.append(np.cos(i * np.pi * t_scaled))
            
        basis_matrix = np.stack(basis, axis=0) # (M, N)
        return BackendPreparedData(
            matrices={"basis": basis_matrix}
        )

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            # Predicted dy/dt
            fx = engine.evaluate(tree, global_data.X, cache=cache)
            
            # Simple numerical dy/dt target if dy_dt is not provided
            if global_data.dy_dt is not None:
                dy_target = global_data.dy_dt
            else:
                dy_target = np.gradient(global_data.y, global_data.t, axis=0)
                
            residual = dy_target - fx
            
            basis = backend_data.matrices["basis"]
            # Coeffs = Project residual onto basis
            coeffs = basis @ residual
            
            loss = float(np.mean(coeffs**2))
            
            # Non-Triviality Penalty: If the model predicts zero or a constant,
            # it might be a local minimum. Force some variance.
            fx_var = np.var(fx)
            if fx_var < 1e-6:
                loss += 10.0 / (fx_var + 1e-8)
                
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
