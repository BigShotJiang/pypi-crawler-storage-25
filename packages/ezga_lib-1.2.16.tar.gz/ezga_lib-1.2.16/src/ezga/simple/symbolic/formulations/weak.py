from __future__ import annotations
"""
Formulation: WeakFormulation

Mathematical idea
-----------------
The candidate symbolic model is interpreted as a dynamical law. 
Enforces the residual in a weak (integral) sense by projecting against test functions.

Expected data
-------------
- time-series t
- state trajectory y

Internal score
--------------
Residual of the projected weak-form equation.

Complexity
----------
O(MN) after candidate evaluation, where:
- N = number of time samples
- M = number of test functions

Best use cases
--------------
- noisy data
- sparse samples
- avoids numerical differentiation
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData

def build_test_functions(t: np.ndarray, n_test: int = 20, sigma: float = 0.5):
    t_min, t_max = np.min(t), np.max(t)
    centers = np.linspace(t_min, t_max, n_test + 2)[1:-1]
    T, C = np.meshgrid(t, centers)
    diff = T - C
    phi = np.exp(-0.5 * (diff / sigma)**2)
    dphi = phi * (-diff / sigma**2)
    return phi, dphi

class WeakFormulation(FormulationBackend):
    name: str = "Weak"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=True,
        requires_ordered_samples=True,
        supports_static_regression=False,
        supports_dynamics=True,
        supports_noise_robust_mode=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        return data.t is not None

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        assert data.t is not None
        assert data.y is not None
        n_test = min(50, len(data.t) // 2)
        phi, dphi = build_test_functions(data.t, n_test=n_test)
        rhs = -(dphi @ data.y)
        return BackendPreparedData(
            matrices={"phi": phi, "dphi": dphi},
            metadata={"rhs": rhs},
        )

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            fx = engine.evaluate(tree, global_data.X, cache=cache)
            phi = backend_data.matrices["phi"]
            rhs = backend_data.metadata["rhs"]
            lhs = phi @ fx
            residual = lhs - rhs
            loss = float(np.mean(residual**2))
            
            # Normalization
            rhs_norm = np.mean(rhs**2) + 1e-6
            loss /= rhs_norm
            
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        try:
            from ..refiners import ConstantRefiner
            refiner = ConstantRefiner()
            phi = backend_data.matrices["phi"]
            rhs = backend_data.metadata["rhs"]
            
            # For weak-form refinement, the target "y" is the weak-form RHS,
            # and we project the candidate evaluation through the test-function matrix (phi).
            return refiner.refine(
                tree, engine, global_data.X, rhs, 
                X_target=phi,
                **kwargs
            )
        except Exception:
            return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
