from __future__ import annotations
"""
Formulation: HamiltonianFormulation

Mathematical idea
-----------------
The candidate symbolic expression is interpreted as a Hamiltonian H(q, p).
The dynamics are matched through Hamilton's canonical equations:
dq/dt = dH/dp
dp/dt = -dH/dq

Expected data
-------------
- q, p (state variables)
- qdot, pdot (derivatives)

Internal score
--------------
Sum of squared residuals of the canonical equations.

Complexity
----------
O(N) after evaluation and symbolic differentiation.

Best use cases
--------------
- symplectic dynamics
- mechanical systems with known canonical coordinates
- energy-conserving models
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData

class HamiltonianFormulation(FormulationBackend):
    name: str = "hamiltonian"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=True,
        requires_derivatives=True,
        requires_phase_space=True,
        supports_static_regression=False,
        supports_dynamics=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        # Requires at least 2 features (q and p) and their derivatives
        return (
            data.X.shape[1] >= 2 
            and data.dy_dt is not None 
            and data.metadata.get("q_idx") is not None
            and data.metadata.get("p_idx") is not None
        )

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        return BackendPreparedData()

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            q_idx = global_data.metadata["q_idx"]
            p_idx = global_data.metadata["p_idx"]
            
            # tree is H(q, p)
            dH_dq = engine.differentiate(tree, var_idx=q_idx, mode="symbolic")
            dH_dp = engine.differentiate(tree, var_idx=p_idx, mode="symbolic")
            
            if dH_dq is None or dH_dp is None:
                return BackendScore(loss=1e18)
            
            # Evaluate gradients
            dH_dq_eval = engine.evaluate(dH_dq, global_data.X, cache=cache)
            dH_dp_eval = engine.evaluate(dH_dp, global_data.X, cache=cache)
            
            # Hamilton's equations: 
            # qdot = dH/dp
            # pdot = -dH/dq
            qdot_target = global_data.dy_dt[:, q_idx]
            pdot_target = global_data.dy_dt[:, p_idx]
            
            r1 = qdot_target - dH_dp_eval
            r2 = pdot_target + dH_dq_eval
            
            loss = float(np.mean(r1**2) + np.mean(r2**2))
            
            # Non-Triviality: Hamiltonian must have non-zero gradients to produce dynamics.
            # If dH/dq and dH/dp are near zero, it's a trivial constant solution.
            grad_signal = np.var(dH_dq_eval) + np.var(dH_dp_eval)
            if grad_signal < 1e-6:
                loss += 5.0 / (grad_signal + 1e-8)
                
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
