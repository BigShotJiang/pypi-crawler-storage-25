from __future__ import annotations
"""
Formulation: CollocationFormulation

Mathematical idea
-----------------
The candidate symbolic equation (dy/dt - f(x) = 0) is enforced at selected 
collocation nodes of a smooth interpolant of the observed state.

Expected data
-------------
- time-series t
- state trajectory y

Internal score
--------------
Residual of the equation at collocation nodes.

Complexity
----------
O(N_nodes) per evaluation.

Best use cases
--------------
- splines
- smoothed datasets
- ODE/PDE discovery
"""

import numpy as np
from typing import Any, List
from scipy.interpolate import UnivariateSpline
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData

class CollocationFormulation(FormulationBackend):
    name: str = "collocation"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=True,
        requires_ordered_samples=True,
        supports_dynamics=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        return data.t is not None and len(data.t) > 5

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        assert data.y is not None
        assert data.t is not None
        # Fit a spline to the state trajectory
        # Using y as 1D array (assuming single target for simplicity in Phase 1)
        # Handle multidimensional y if present by taking the first component
        y_vec = data.y
        if len(y_vec.shape) > 1 and y_vec.shape[1] > 1:
            y_vec = y_vec[:, 0]
            
        spline = UnivariateSpline(data.t, y_vec, s=0) # Interpolating spline
        
        # Choose collocation nodes (e.g., midpoints of segments)
        nodes = 0.5 * (data.t[:-1] + data.t[1:])
        
        # Precompute state and derivative at nodes
        y_nodes = spline(nodes)
        dy_nodes = spline.derivative()(nodes)
        
        # Build node context (X[nodes])
        # This is tricky because X is a matrix of features. 
        # For Phase 1, we assume X contains the state y that we just splined.
        # If X contains other features, we'd need to spline those too.
        # For now, we'll store the nodes and the splined y/dy.
        
        return BackendPreparedData(
            metadata={
                "nodes": nodes,
                "y_nodes": y_nodes,
                "dy_nodes": dy_nodes
            }
        )

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            nodes = backend_data.metadata["nodes"]
            y_nodes = backend_data.metadata["y_nodes"]
            dy_nodes = backend_data.metadata["dy_nodes"]
            
            # Build context for nodes. 
            # In Phase 1 simplification, we assume the model f(y) depends on y.
            # We reshape y_nodes to be the first feature.
            X_nodes = y_nodes.reshape(-1, 1)
            
            # Predict dy (f(y))
            pred = engine.evaluate(tree, X_nodes, cache=cache)
            
            if pred.shape != dy_nodes.shape:
                pred = pred.reshape(dy_nodes.shape)
                
            residual = dy_nodes - pred
            loss = float(np.mean(residual**2))
            
            # Normalization
            dy_norm = np.mean(dy_nodes**2) + 1e-6
            loss /= dy_norm
            
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
