from __future__ import annotations
"""
Formulation: StrongFormulation

Mathematical idea
-----------------
Enforces the symbolic law point-by-point. 
The candidate model y_pred = f(X) is compared directly against the target y.

Expected data
-------------
- static regression: y = f(X)
- dynamics (pointwise): dy/dt = f(X)

Internal score
--------------
Mean Squared Error (MSE) of the residual.

Complexity
----------
O(N) per evaluation, where N is the number of samples.

Best use cases
--------------
- clean datasets
- high-resolution sampling
- baseline results
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData

class StrongFormulation(FormulationBackend):
    """
    Pointwise residual formulation.
    """
    name: str = "Strong"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=False,
        supports_static_regression=True,
        supports_dynamics=True,
    )

    def is_compatible(self, global_data: GlobalPreparedData) -> bool:
        return True

    def prepare(self, global_data: GlobalPreparedData) -> BackendPreparedData:
        return BackendPreparedData()

    def score(self, tree, engine, global_data: GlobalPreparedData, 
              backend_data: BackendPreparedData, cache: Any) -> BackendScore:
        try:
            pred = engine.evaluate(tree, global_data.X, cache=cache)
            if pred.shape != global_data.y.shape:
                pred = pred.reshape(global_data.y.shape)
            
            residual = global_data.y - pred
            loss = float(np.mean(residual**2))
            
            if not np.isfinite(loss):
                loss = 1e18
                
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        try:
            from ..refiners import ConstantRefiner
            refiner = ConstantRefiner()
            return refiner.refine(tree, engine, global_data.X, global_data.y, **kwargs)
        except Exception:
            return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
