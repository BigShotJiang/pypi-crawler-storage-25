from __future__ import annotations
"""
Formulation: DiscreteFormulation

Mathematical idea
-----------------
The candidate symbolic model is interpreted as a discrete-time map:
x_{k+1} = F(x_k) or Δx_k = G(x_k)

Expected data
-------------
- ordered samples

Internal score
--------------
Residual of the one-step prediction vs next state.

Complexity
----------
O(N) after evaluation.

Best use cases
--------------
- naturally discrete observed sequences
- iterative systems
- derivative-free
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData

class DiscreteFormulation(FormulationBackend):
    name: str = "discrete"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_ordered_samples=True,
        supports_static_regression=False,
        supports_dynamics=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        if data.y is None:
            return False
        return len(data.y) > 1

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        assert data.X is not None
        assert data.y is not None
        x_curr = data.X[:-1]
        x_next = data.y[1:]
        return BackendPreparedData(
            metadata={"x_curr": x_curr, "x_next": x_next}
        )

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            x_curr = backend_data.metadata["x_curr"]
            x_next = np.asarray(backend_data.metadata["x_next"]).flatten()
            
            # Predict
            pred = engine.evaluate(tree, x_curr, cache=cache)
            pred = np.asarray(pred).flatten()
            
            if len(pred) != len(x_next):
                # Handle potential size mismatch if engine returned different sized array
                return BackendScore(loss=1e18)
                
            residual = x_next - pred
            loss = float(np.mean(residual**2))
            
            # Normalization
            next_norm = np.mean(x_next**2) + 1e-6
            loss /= next_norm
            
            return BackendScore(loss=loss)
        except Exception as e:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
