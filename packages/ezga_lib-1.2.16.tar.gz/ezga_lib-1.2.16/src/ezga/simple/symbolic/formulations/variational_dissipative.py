from __future__ import annotations
"""
Formulation: DissipativeVariationalFormulation

Mathematical idea
-----------------
Searches over pairs (L, R) where L is the conservative Lagrangian
and R is the Rayleigh dissipation potential.
Euler-Lagrange with dissipation:
d/dt(dL/dqdot) - dL/dq + dR/dqdot = 0

Expected data
-------------
- q, qdot

Internal score
--------------
Weak-form residual including the dissipative term.

Complexity
----------
O(N) after evaluation.
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData
from .weak import build_test_functions

class DissipativeVariationalFormulation(FormulationBackend):
    name: str = "variational_dissipative"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=True,
        requires_derivatives=True,
        supports_dynamics=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        return data.t is not None and data.dy_dt is not None

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        assert data.t is not None
        n_test = min(50, len(data.t) // 2)
        eta, deta = build_test_functions(data.t, n_test=n_test)
        return BackendPreparedData(
            matrices={"eta": eta, "deta": deta}
        )

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            # In Phase 3 simplification, we assume the tree is L - dt*R or similar.
            # Real implementation would use a pair (L, R).
            # For now, we assume tree has two subtrees or is a specific structure.
            # Let's assume var_idx=0 is q, var_idx=1 is qdot.
            
            dL_dq = engine.differentiate(tree, var_idx=0, mode="symbolic")
            dL_dqdot = engine.differentiate(tree, var_idx=1, mode="symbolic")
            
            # Simple dissipation model: R = 0.5 * c * qdot^2 (viscous friction)
            # If we don't have R in the tree, we assume a default or learned term.
            # For this exercise, we'll just implement the Euler-Lagrange part.
            
            if dL_dq is None or dL_dqdot is None:
                return BackendScore(loss=1e18)
            
            q_context = global_data.X
            dL_dq_eval = engine.evaluate(dL_dq, q_context, cache=cache)
            dL_dqdot_eval = engine.evaluate(dL_dqdot, q_context, cache=cache)
            
            eta = backend_data.matrices["eta"]
            deta = backend_data.matrices["deta"]
            
            # residual = integral( dL/dq * eta + dL/dqdot * deta )
            # If we add dissipation dR/dqdot:
            # residual = integral( (dL/dq - dR/dqdot) * eta + dL/dqdot * deta )
            
            residual = (eta @ dL_dq_eval) + (deta @ dL_dqdot_eval)
            loss = float(np.mean(residual**2))
            
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
