from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import numpy as np

# Import score model from parent sibling
from ..scoring import BackendScore
from ..data import GlobalPreparedData, BackendPreparedData

@dataclass
class BackendCapabilities:
    """Explicit metadata about what a formulation supports and requires."""
    requires_time: bool = False
    requires_ordered_samples: bool = False
    requires_derivatives: bool = False
    requires_phase_space: bool = False
    supports_static_regression: bool = True
    supports_dynamics: bool = True
    supports_noise_robust_mode: bool = False

class FormulationBackend(ABC):
    """
    Abstract interface for scoring engines.
    Every formulation (Strong, Weak, etc.) must implement this exactly.
    """
    name: str = "base"
    capabilities: BackendCapabilities = BackendCapabilities()

    @abstractmethod
    def prepare(self, global_data: GlobalPreparedData) -> BackendPreparedData:
        """Create and return backend-specific cached operators and metadata."""
        pass

    @abstractmethod
    def is_compatible(self, global_data: GlobalPreparedData) -> bool:
        """Return True if this backend can handle the provided dataset."""
        pass

    @abstractmethod
    def score(self, tree, engine, global_data: GlobalPreparedData, 
              backend_data: BackendPreparedData, cache: Any) -> BackendScore:
        """Return backend-specific internal evaluation result."""
        pass

    @abstractmethod
    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        """Optional local constant optimization hook."""
        pass

    @abstractmethod
    def mutate(self, tree, engine, rng):
        """Backend-aware mutation (optional specialization)."""
        pass

    @abstractmethod
    def crossover(self, tree_a, tree_b, engine, rng):
        """Backend-aware crossover (optional specialization)."""
        pass

    def export_fragments(self, elite_archive) -> List[Any]:
        """Extract recurring motifs for the global shared pool."""
        return []

    def import_fragments(self, fragments: List[Any]) -> None:
        """Import motifs from other islands/formulations."""
        pass
