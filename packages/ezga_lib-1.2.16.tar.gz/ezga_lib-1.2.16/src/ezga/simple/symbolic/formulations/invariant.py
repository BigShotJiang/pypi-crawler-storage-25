from __future__ import annotations
"""
Formulation: InvariantFormulation

Mathematical idea
-----------------
Searches for a symbolic quantity I(x) that remains constant (or nearly constant)
along observed trajectories: dI/dt = grad(I) dot dy/dt = 0.

Expected data
-------------
- time-series t
- state trajectory y

Internal score
--------------
Variance or cumulative change of the symbolic expression across the trajectory.

Complexity
----------
O(N) per evaluation.

Best use cases
--------------
- physical discovery of conservation laws
- Hamiltonian/Lagrangian first integrals
- multiple trajectories sharing an invariant
"""

import numpy as np
from typing import Any, List
from .base import FormulationBackend, BackendCapabilities, BackendScore, BackendPreparedData
from ..data import GlobalPreparedData

class InvariantFormulation(FormulationBackend):
    name: str = "Invariant"
    capabilities: BackendCapabilities = BackendCapabilities(
        requires_time=True,
        supports_static_regression=False,
        supports_dynamics=True,
    )

    def is_compatible(self, data: GlobalPreparedData) -> bool:
        return data.t is not None

    def prepare(self, data: GlobalPreparedData) -> BackendPreparedData:
        return BackendPreparedData()

    def score(self, tree, engine, global_data, backend_data, cache):
        try:
            # PHYSICAL CONSTRAINT: Invariants must depend on the state.
            # Pure constants are perfect invariants but physically useless.
            if not tree.has_variable():
                return BackendScore(loss=1e10)
                
            # Evaluate quantity along the trajectory
            I = engine.evaluate(tree, global_data.X, cache=cache)
            I = np.asarray(I).flatten()
            
            # Robust clamping to prevent numerical overflows from div-by-zero
            I = np.clip(I, -1e6, 1e6)
            
            variance_I = float(np.var(I))
            mean_sq_I = float(np.mean(I**2))
            
            # Triviality Check: Constants are mathematically perfect but useless.
            if variance_I < 1e-12:
                return BackendScore(loss=1e10)
            
            # Robust relative variation loss
            loss = variance_I / (mean_sq_I + 1e-9)
            
            # Add a penalty for constant-like behavior to push towards dynamic discovery
            if variance_I < 1e-4:
                loss += 0.1 / (variance_I + 1e-8)
                
            return BackendScore(loss=loss)
        except Exception:
            return BackendScore(loss=1e18)

    def refine_constants(self, tree, engine, global_data, backend_data, cache, **kwargs):
        return tree

    def mutate(self, tree, engine, rng):
        return tree

    def crossover(self, tree_a, tree_b, engine, rng):
        return tree_a
