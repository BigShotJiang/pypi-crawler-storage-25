from __future__ import annotations
from typing import Any, List, Set, Dict
from collections import Counter
import random

class SharedFragmentPool:
    """
    A global repository for Recurring Symbolic Motifs.
    Allows different GA islands to share successful sub-expressions.
    """
    
    def __init__(self, max_fragments: int = 100):
        self.fragments: Dict[str, Any] = {}
        self.max_fragments = max_fragments
        self.fragment_usage: Counter[str] = Counter()

    def add_fragments(self, new_fragments: List[Any], backend_source: str):
        """Adds a list of tree objects to the pool."""
        for tree in new_fragments:
            f_str = str(tree)
            if f_str not in self.fragments:
                # Store the tree object
                self.fragments[f_str] = tree.clone()
            
            self.fragment_usage[f_str] += 1
            
        self._prune()

    def sample(self, k: int = 1) -> List[Any]:
        """Returns k random fragments from the pool."""
        if not self.fragments:
            return []
        
        candidates = list(self.fragments.values())
        return random.sample(candidates, min(k, len(candidates)))

    def get_top_fragments(self, k: int = 10) -> List[Any]:
        """Returns the most frequently used fragments."""
        top_keys = [key for key, _ in self.fragment_usage.most_common(k)]
        return [self.fragments[k].clone() for k in top_keys if k in self.fragments]

    def _prune(self):
        """Maintains the size limit of the pool based on usage frequency."""
        if len(self.fragments) <= self.max_fragments:
            return

        # Keep the most used ones
        sorted_keys = [k for k, _ in self.fragment_usage.most_common()]
        keep_keys = sorted_keys[:self.max_fragments]
        
        # Rebuild fragments and usage
        self.fragments = {k: self.fragments[k] for k in keep_keys}
        new_usage = Counter()
        for k in keep_keys:
            new_usage[k] = self.fragment_usage[k]
        self.fragment_usage = new_usage
