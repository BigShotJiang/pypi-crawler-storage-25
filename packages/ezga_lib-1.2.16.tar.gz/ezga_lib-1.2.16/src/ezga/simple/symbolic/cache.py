from __future__ import annotations
from collections import OrderedDict
from typing import Any, Dict, Optional

class LRUCache(OrderedDict[Any, Any]):
    """Simple LRU cache using OrderedDict."""
    def __init__(self, limit: int = 1000):
        super().__init__()
        self.limit = limit

    def __getitem__(self, key):
        value = super().__getitem__(key)
        self.move_to_end(key)
        return value

    def __setitem__(self, key, value):
        if key in self:
            self.move_to_end(key)
        super().__setitem__(key, value)
        if len(self) > self.limit:
            self.popitem(last=False)

class CacheManager:
    """Hierarchical cache orchestrator for symbolic regression."""
    
    def __init__(self, global_limit: int = 2048, local_limit: int = 512):
        # The Global cache stores evaluations of symbolic expressions (hashed).
        # Shared across ALL backends to avoid redundant math.
        self.global_expression_cache: LRUCache = LRUCache(global_limit)
        
        # Local caches for backend-specific projections/operators (namespaced).
        self.local_caches: Dict[str, LRUCache] = {}
        self.local_limit: int = local_limit
        
    def get_global_cache(self) -> LRUCache:
        """Returns the shared expression evaluation cache."""
        return self.global_expression_cache
        
    def get_local_cache(self, backend_name: str) -> LRUCache:
        """Returns a namespaced cache for backend-specific projections."""
        if backend_name not in self.local_caches:
            self.local_caches[backend_name] = LRUCache(self.local_limit)
        return self.local_caches[backend_name]

    def clear(self):
        """Wipes all caches."""
        self.global_expression_cache.clear()
        for c in self.local_caches.values():
            c.clear()
