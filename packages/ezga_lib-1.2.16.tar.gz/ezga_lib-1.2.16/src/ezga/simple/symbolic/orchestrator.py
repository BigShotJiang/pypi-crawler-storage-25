from __future__ import annotations
from typing import Any, List, Optional, Dict
import numpy as np
import random
from ezga.simple.ops import generate_random_tree
from ezga.simple.grammar import Add, Sub, Mul, Div, Sin, Cos, OptimizableConstant, Variable

from .data import ProblemDefinition, GlobalPreparedData, BackendPreparedData, Individual
from .engine import ExpressionEngine
from .cache import CacheManager
from .scoring import ExternalModelScorer, BackendScore
from .island import FormulationIsland
from .fragments import SharedFragmentPool

class MultiFormulationRegressor:
    """
    Main Orchestrator for Symbolic Regression using multiple formulations.
    Manages several GA "islands", each specializing in a different scoring method (Strong, Weak, etc.).
    """
    
    def __init__(self, problem_def: ProblemDefinition, backends: List[Any], 
                 pop_size_per_island: int = 100, fragment_sharing_freq: int = 10,
                 memetic_freq: int = 5):
        self.problem_def = problem_def
        self.engine = ExpressionEngine()
        self.cache_manager = CacheManager()
        self.fragment_pool = SharedFragmentPool()
        self.external_scorer = ExternalModelScorer(global_data=self.problem_def)
        self.pop_size_per_island = pop_size_per_island
        self.fragment_sharing_freq = fragment_sharing_freq
        self.memetic_freq = memetic_freq
        
        # 1. Global Pre-processing
        self.global_data = self._prepare_global(problem_def)
        
        # 2. Island Initialization
        self.islands: List[FormulationIsland] = []
        for backend in backends:
            if backend.is_compatible(self.global_data):
                # Prepare backend-specific data (e.g., test matrices)
                b_data = backend.prepare(self.global_data)
                
                island = FormulationIsland(
                    backend=backend,
                    engine=self.engine,
                    global_data=self.global_data,
                    backend_data=b_data,
                    cache_manager=self.cache_manager,
                    scorer=self.external_scorer,
                    population_size=pop_size_per_island
                )
                self.islands.append(island)

    def _prepare_global(self, problem: ProblemDefinition) -> GlobalPreparedData:
        """Standardizes and scales the problem data for all backends."""
        return GlobalPreparedData(
            X=problem.X,
            y=problem.y,
            t=problem.t,
            dy_dt=problem.metadata.get("dy_dt"),
            d2y_dt2=problem.metadata.get("d2y_dt2"),
            feature_names=problem.feature_names,
            metadata=problem.metadata
        )

    def get_evaluator(self, backend_idx: int = 0):
        """Returns the backend and its prepared data for a specific formulation."""
        if not self.islands:
            return None, None, None
        island = self.islands[backend_idx % len(self.islands)]
        return island.backend, island.backend_data, island.cache

    def _generate_random_initial_trees(self) -> List[Any]:
        """Generates random trees using the standard grammar."""
        rng = np.random.default_rng()
        trees = []
        for _ in range(self.pop_size_per_island):
            tree = generate_random_tree(
                n_features=self.problem_def.X.shape[1],
                rng=rng,
                max_depth=4,
                binary_ops=[Add, Sub, Mul, Div],
                unary_ops=[Sin, Cos],
                literal_types=[Variable, OptimizableConstant]
            )
            trees.append(tree)
        return trees

    def get_best_models(self, k: int = 5) -> List[Any]:
        """Returns the top models according to the unified ExternalModelScorer."""
        all_candidates = []
        for island in self.islands:
            candidates = island.population
            all_candidates.extend(candidates)
            
        # Global ranking by external score
        all_candidates.sort(key=lambda x: x.external_score if x.external_score is not None else float('inf'))
        
        # Remove duplicates based on tree representation
        unique_results = []
        seen = set()
        for cand in all_candidates:
            f_str = str(cand.tree)
            if f_str not in seen:
                unique_results.append(cand)
                seen.add(f_str)
        
        return unique_results[:k]
