from __future__ import annotations
from typing import Any, List, Optional
import numpy as np
from .data import Individual, GlobalPreparedData, BackendPreparedData
from .scoring import BackendScore

class FormulationIsland:
    """
    A self-contained GA unit focused on a single Symbolic Regression formulation.
    Each island maintain its own population, local archive (elites), and local cache.
    """
    
    def __init__(self, backend: Any, engine: Any, global_data: GlobalPreparedData, 
                 backend_data: BackendPreparedData, cache_manager: Any, scorer: Any,
                 population_size: int = 100):
        self.backend = backend
        self.engine = engine
        self.global_data = global_data
        self.backend_data = backend_data
        self.cache = cache_manager.get_local_cache(backend.name)
        self.scorer = scorer
        self.population_size = population_size
        
        self.population: List[Individual] = []
        self.archive: List[Individual] = [] # Local Elites
        
        self.generation = 0

    def initialize(self, initial_trees: List[Any]):
        """Populates the island with initial candidate trees."""
        self.population = []
        for tree in initial_trees:
            ind = Individual(tree=tree, backend_name=self.backend.name)
            self._evaluate_individual(ind)
            self.population.append(ind)
        self._update_archive()

    def step(self):
        """Executes one GA generation (Selection, Variation, Evaluation)."""
        self.generation += 1
        
        # 1. Selection (Tournament)
        parents = self._select_parents()
        
        # 2. Variation (Crossover & Mutation)
        offspring_trees = self._generate_offspring(parents)
        
        # 3. Evaluation
        offspring = []
        for tree in offspring_trees:
            ind = Individual(tree=tree, backend_name=self.backend.name)
            self._evaluate_individual(ind)
            offspring.append(ind)
            
        # 4. Survivor Selection (Stay within population_size)
        self.population = self._select_survivors(self.population + offspring)
        self._update_archive()

    def _evaluate_individual(self, individual: Individual):
        """Computes both backend-specific score and global external score."""
        # Backend-local score (e.g., Weak Form Residual)
        score = self.backend.score(
            tree=individual.tree,
            engine=self.engine,
            global_data=self.global_data,
            backend_data=self.backend_data,
            cache=self.cache
        )
        individual.score = score
        
        # Global external score (for cross-island ranking)
        # This uses the unified scorer (e.g., Hold-out MSE)
        individual.external_score = self.scorer.score(
            individual=individual,
            engine=self.engine,
            global_data=self.global_data
        )

    def _select_parents(self, n: int = 2) -> List[Individual]:
        """Simple tournament selection."""
        if not self.population:
            return []
        rng = np.random.default_rng()
        indices = rng.choice(len(self.population), size=n*2, replace=True)
        candidates = [self.population[i] for i in indices]
        winners = []
        for i in range(0, len(candidates), 2):
            a, b = candidates[i], candidates[i+1]
            if a.score.total < b.score.total: # type: ignore[union-attr]
                winners.append(a)
            else:
                winners.append(b)
        return winners

    def _generate_offspring(self, parents: List[Individual]) -> List[Any]:
        """Applies crossover and mutation."""
        rng = np.random.default_rng()
        offspring = []
        
        for i in range(0, len(parents), 2):
            p1, p2 = parents[i], parents[i+1]
            
            # Crossover (Backend-specific if implemented, else fallback)
            child1 = self.backend.crossover(p1.tree, p2.tree, self.engine, rng)
            
            # Mutation
            mutated = self.backend.mutate(child1, self.engine, rng)
            offspring.append(mutated)
            
        return offspring

    def _select_survivors(self, candidates: List[Individual]) -> List[Individual]:
        """Elitist survivor selection."""
        candidates.sort(key=lambda x: x.score.total)  # type: ignore[union-attr]
        return candidates[:self.population_size]

    def _update_archive(self, k: int = 10):
        """Updates the local elite archive."""
        # Sort by internal backend score
        self.population.sort(key=lambda x: x.score.total)  # type: ignore[union-attr]
        self.archive = self.population[:k]

    def get_elites(self) -> List[Individual]:
        """Returns the current archive of elites."""
        return self.archive

    def inject_fragments(self, fragments: List[Any], probability: float = 0.1):
        """Injects external fragments into the mutation pool or population."""
        # TBD: Implementation details for Phase 2 fragment sharing
        pass
