from __future__ import annotations
import numpy as np
from typing import Any, Optional

class ExpressionEngine:
    """Stateless manager for symbolic trees and evaluations."""
    
    def __init__(self, cfg=None):
        self.cfg = cfg
    
    def evaluate(self, tree: Any, X: np.ndarray, cache: dict | None = None) -> np.ndarray:
        """
        Vectorized evaluation of a symbolic tree on data X.
        Uses global memoization if a cache is provided.
        """
        if cache is not None:
            expr_hash = self.get_hash(tree)
            if expr_hash in cache:
                return cache[expr_hash]  # type: ignore[no-any-return]
            
            res = tree.evaluate(X)
            cache[expr_hash] = res
            return res  # type: ignore[no-any-return]
            
        return tree.evaluate(X)  # type: ignore[no-any-return]

    def simplify(self, tree, rules="standard"):
        """Algebraic reduction and constant folding."""
        # Use existing simplification logic from Node or grammar.py
        if hasattr(tree, "simplify_aggressive"):
            return tree.simplify_aggressive()
        return tree.simplify()
        
    def get_hash(self, tree) -> str:
        """Semantic signature for evaluation memoization."""
        # Using string representation as a simple primary hash for now.
        return str(tree)

    def differentiate(self, tree, var_idx: int, mode="symbolic") -> Any:
        """
        Returns the derivative of the tree w.r.t. a variable index.
        In 'symbolic' mode, it attempts to traverse the tree and return a new symbolic tree.
        In 'numerical' mode, it returns a finite-difference wrapper (not a Node).
        """
        if mode == "symbolic":
            return self._symbolic_diff(tree, var_idx)
        else:
            # Simple numerical gradient function
            def numerical_grad(X, eps=1e-5):
                X_plus = X.copy()
                X_plus[:, var_idx] += eps
                y_plus = self.evaluate(tree, X_plus)
                y = self.evaluate(tree, X)
                return (y_plus - y) / eps
            return numerical_grad

    def _symbolic_diff(self, tree, var_idx: int) -> Any:
        """
        Symbolic differentiation logic. 
        Traverses the tree and applies chain/product rules.
        """
        # Placeholder for full implementation. 
        # For Phase 1, this can return None or a minimal subset.
        from ezga.simple.grammar import Constant, Variable, Add, Sub, Mul, Div, Sin, Cos, Exp, Log
        
        if isinstance(tree, Constant):
            return Constant(0.0)
        if isinstance(tree, Variable):
            return Constant(1.0) if tree.index == var_idx else Constant(0.0)
        
        if isinstance(tree, Add):
            return Add(self._symbolic_diff(tree.left, var_idx), self._symbolic_diff(tree.right, var_idx))
        if isinstance(tree, Sub):
            return Sub(self._symbolic_diff(tree.left, var_idx), self._symbolic_diff(tree.right, var_idx))
        
        # Mul: d(u*v) = u'v + uv'
        if isinstance(tree, Mul):
            return Add(
                Mul(self._symbolic_diff(tree.left, var_idx), tree.right),
                Mul(tree.left, self._symbolic_diff(tree.right, var_idx))
            )

        # Fallback for complex ops in Phase 1
        return None
