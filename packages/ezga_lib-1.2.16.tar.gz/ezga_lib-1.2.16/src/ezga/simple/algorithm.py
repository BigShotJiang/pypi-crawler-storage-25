from __future__ import annotations
class GA:
    """
    Configuration holder for the Genetic Algorithm.
    """

    def __init__(
        self,
        pop_size: int = 100,
        pop_size_max: int | None = None,
        sampling=None,
        selection=None,
        crossover=None,
        mutation=None,
        eliminate_duplicates: bool = False,
        n_offsprings: int | None = None,
        enable_bo: bool = False,
        bo_size: int = 30,
        warm_start: bool = True,
        use_ard: bool = True,
        n_restarts_optimizer: int = 5,
        save_model: bool = False,
        training_subsample: int = 100,
        crossover_probability: float = 0.2,
        discrete_design: bool = True,
    ):

        self.pop_size = pop_size
        self.pop_size_max = pop_size_max
        self.sampling = sampling
        self.selection = selection
        self.crossover = crossover
        self.mutation = mutation
        self.eliminate_duplicates = eliminate_duplicates
        self.n_offsprings = n_offsprings
        self.enable_bo = enable_bo
        self.bo_size = bo_size
        self.warm_start = warm_start
        self.use_ard = use_ard
        self.n_restarts_optimizer = n_restarts_optimizer
        self.save_model = save_model
        self.training_subsample = training_subsample
        self.crossover_probability = crossover_probability
        self.discrete_design = discrete_design
