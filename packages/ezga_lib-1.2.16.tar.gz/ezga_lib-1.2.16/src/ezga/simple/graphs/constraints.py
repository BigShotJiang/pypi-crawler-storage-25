from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .individual import GraphIndividual


class GraphConstraint(ABC):
    """
    Base class for structural and parametric graph constraints.
    Can be hard (invalidates solution) or soft (penalizes it).
    """

    def __init__(self, hard: bool = True, penalty_weight: float = 1.0):
        self.hard = hard
        self.penalty_weight = penalty_weight

    @abstractmethod
    def validate(self, ind: GraphIndividual) -> tuple[bool, float]:
        """Returns (is_valid, penalty_score)."""
        pass


class AcyclicConstraint(GraphConstraint):
    """Ensures the graph is a Directed Acyclic Graph (DAG)."""

    def validate(self, ind: GraphIndividual) -> tuple[bool, float]:
        # Using NetworkX for speed and reliability in cyclic detection
        import networkx as nx

        G = ind.phenotype.to_networkx()

        is_dag = nx.is_directed_acyclic_graph(G)

        if is_dag:
            return True, 0.0

        # If not DAG, calculate penalty proportional to the number of cycles found
        penalty = 100.0 if self.hard else 10.0
        return False, penalty


class ReachabilityConstraint(GraphConstraint):
    """Ensures reachability between source and target node sets."""

    def __init__(self, sources: list[str], targets: list[str], hard: bool = True):
        super().__init__(hard=hard)
        self.sources = sources
        self.targets = targets

    def validate(self, ind: GraphIndividual) -> tuple[bool, float]:
        import networkx as nx

        G = ind.phenotype.to_networkx()

        for s in self.sources:
            for t in self.targets:
                if not nx.has_path(G, s, t):
                    return False, 1.0

        return True, 0.0


class DegreeConstraint(GraphConstraint):
    """Limits the in-degree or out-degree of nodes."""

    def __init__(self, max_in: int | None = None, max_out: int | None = None, hard: bool = True):
        super().__init__(hard=hard)
        self.max_in = max_in
        self.max_out = max_out

    def validate(self, ind: GraphIndividual) -> tuple[bool, float]:
        G = ind.phenotype.to_networkx()

        if self.max_in is not None:
            for _node, d in G.in_degree():
                if d > self.max_in:
                    return False, float(d - self.max_in)

        if self.max_out is not None:
            for _node, d in G.out_degree():
                if d > self.max_out:
                    return False, float(d - self.max_out)

        return True, 0.0


class MaxEdgesConstraint(GraphConstraint):
    """Limits the total number of active edges."""

    def __init__(self, max_edges: int, hard: bool = False):
        super().__init__(hard=hard)
        self.max_edges = max_edges

    def validate(self, ind: GraphIndividual) -> tuple[bool, float]:
        n_active = len(ind.phenotype.active_edges)
        if n_active > self.max_edges:
            penalty = float(n_active - self.max_edges)
            return False, penalty
        return True, 0.0
