from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, TYPE_CHECKING
import numpy as np

if TYPE_CHECKING:
    from .individual import GraphGenotype

NodeRole = Literal["REQUIRED", "OPTIONAL", "DISABLED"]


@dataclass(frozen=True)
class GraphState:
    """Represents a node in the graph with metadata."""

    id: str
    label: str | None = None
    role: NodeRole = "REQUIRED"
    features: dict[str, Any] = field(default_factory=dict)
    tags: set[str] = field(default_factory=set)
    observable: bool = False
    parameter_schema: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class GraphEdge:
    """Represents a candidate connection between two states."""

    id: str
    source: str
    target: str
    directed: bool = True
    features: dict[str, Any] = field(default_factory=dict)
    tags: set[str] = field(default_factory=set)
    required: bool = False
    forbidden: bool = False
    default_active: bool = False
    prior_weight: float = 1.0
    parameter_schema: dict[str, Any] = field(default_factory=dict)


class GraphSearchSpace:
    """
    Defines the entire graph design domain.
    Owned stable indexing for states and candidate edges.
    """

    def __init__(
        self,
        states: list[GraphState],
        candidate_edges: list[GraphEdge],
        graph_type: str = "directed",
        allow_node_activation: bool = True,
        global_parameter_schema: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        self.states = tuple(states)
        self.candidate_edges = tuple(candidate_edges)
        self.graph_type = graph_type
        self.allow_node_activation = allow_node_activation
        self.global_parameter_schema = global_parameter_schema or {}
        self.metadata = metadata or {}

        # 1. Map IDs to indices for fast array-based access
        self.state_index = {s.id: i for i, s in enumerate(self.states)}
        self.edge_index = {e.id: i for i, e in enumerate(self.candidate_edges)}

        if len(self.state_index) != len(self.states):
            raise ValueError("Duplicate state IDs detected in search space.")
        if len(self.edge_index) != len(self.candidate_edges):
            raise ValueError("Duplicate edge IDs detected in search space.")

        # 2. Compile Edge Masks
        self.required_edge_mask = np.array([e.required for e in self.candidate_edges], dtype=bool)
        self.forbidden_edge_mask = np.array([e.forbidden for e in self.candidate_edges], dtype=bool)
        self.default_active_mask = np.array([e.default_active for e in self.candidate_edges], dtype=bool)
        self.edge_prior_weights = np.array([e.prior_weight for e in self.candidate_edges], dtype=float)

        # 3. Compile Node Masks
        if self.allow_node_activation:
            self.node_required_mask = np.array([s.role == "REQUIRED" for s in self.states], dtype=bool)
            self.node_disabled_mask = np.array([s.role == "DISABLED" for s in self.states], dtype=bool)
            self.node_optional_mask = np.array([s.role == "OPTIONAL" for s in self.states], dtype=bool)
        else:
            # Everything is effectively fixed. OPTIONAL becomes REQUIRED.
            self.node_required_mask = np.array([s.role != "DISABLED" for s in self.states], dtype=bool)
            self.node_disabled_mask = np.array([s.role == "DISABLED" for s in self.states], dtype=bool)
            self.node_optional_mask = np.zeros(len(self.states), dtype=bool)

        # 4. Parameter Layout Compilation
        self._compile_parameter_layout()

    def _compile_parameter_layout(self) -> None:
        """Compiles the structure of continuous parameters associated with edges/nodes."""
        # 1. Edge Parameters
        self.edge_param_keys: list[str] = []
        _keys_set: set[str] = set()
        for e in self.candidate_edges:
            _keys_set.update(e.parameter_schema.keys())
        self.edge_param_keys = sorted(list(_keys_set))

        self.edge_param_bounds: dict[str, np.ndarray] = {}
        self.edge_param_log_mask: dict[str, np.ndarray] = {}

        for key in self.edge_param_keys:
            bounds = []
            log_mask = []
            for e in self.candidate_edges:
                schema = e.parameter_schema.get(key, {})
                # Support both (low, high) and {"bounds": (low, high), "log_scale": bool}
                if isinstance(schema, (tuple, list)):
                    b = schema
                    ls = False
                else:
                    b = schema.get("bounds", (0.0, 1.0))
                    ls = schema.get("log_scale", False)
                bounds.append(b)
                log_mask.append(ls)
            self.edge_param_bounds[key] = np.array(bounds)
            self.edge_param_log_mask[key] = np.array(log_mask, dtype=bool)

        # 2. Node Parameters
        self.node_param_keys: list[str] = []
        _node_keys_set: set[str] = set()
        for s in self.states:
            _node_keys_set.update(s.parameter_schema.keys())
        self.node_param_keys = sorted(list(_node_keys_set))

        self.node_param_bounds: dict[str, np.ndarray] = {}
        self.node_param_log_mask: dict[str, np.ndarray] = {}

        for key in self.node_param_keys:
            bounds = []
            log_mask = []
            for s in self.states:
                schema = s.parameter_schema.get(key, {})
                if isinstance(schema, (tuple, list)):
                    b = schema
                    ls = False
                else:
                    b = schema.get("bounds", (0.0, 1.0))
                    ls = schema.get("log_scale", False)
                bounds.append(b)
                log_mask.append(ls)
            self.node_param_bounds[key] = np.array(bounds)
            self.node_param_log_mask[key] = np.array(log_mask, dtype=bool)

    def get_observable_mask(self) -> np.ndarray:
        """Returns a boolean mask of states marked as observable."""
        return np.array([s.observable for s in self.states], dtype=bool)

    def get_state(self, state_id: str) -> GraphState:
        return self.states[self.state_index[state_id]]

    def get_edge(self, edge_id: str) -> GraphEdge:
        return self.candidate_edges[self.edge_index[edge_id]]

    @property
    def n_states(self) -> int:
        return len(self.states)

    @property
    def n_edges(self) -> int:
        return len(self.candidate_edges)

    def create_random_genotype(self, mode: str = "hybrid") -> GraphGenotype:
        """Generates a random genotype within the search space bounds."""
        from .individual import GraphGenotype

        n_e = self.n_edges
        n_s = self.n_states

        # 1. Topology
        edge_active = np.random.choice([True, False], size=n_e)
        edge_active[self.required_edge_mask] = True
        edge_active[self.forbidden_edge_mask] = False

        node_active = np.ones(n_s, dtype=bool)
        if self.allow_node_activation:
            node_active = np.random.choice([True, False], size=n_s)
            node_active[self.node_required_mask] = True
            node_active[self.node_disabled_mask] = False

        # 2. Parameters
        edge_params = {}
        for key, bounds in self.edge_param_bounds.items():
            low, high = bounds[:, 0], bounds[:, 1]
            edge_params[key] = np.random.uniform(low, high)

        node_params = {}
        for key, bounds in self.node_param_bounds.items():
            low, high = bounds[:, 0], bounds[:, 1]
            node_params[key] = np.random.uniform(low, high)

        return GraphGenotype(
            edge_active=edge_active,
            node_active=node_active,
            edge_parameters=edge_params,
            node_parameters=node_params,
        )
