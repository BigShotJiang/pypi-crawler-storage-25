from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from .individual import GraphIndividual


class GraphRepairStep:
    """Base class for automated correction of individuals."""

    def repair(self, ind: GraphIndividual) -> bool:
        """Returns True if the individual was modified."""
        return False


class RequiredEdgeRepair(GraphRepairStep):
    """Enforces that all required edges are active in the genotype."""

    def repair(self, ind: GraphIndividual) -> bool:
        modified = False
        space = ind.space
        # Mask where required=True but genotype=False
        mask = space.required_edge_mask & (~ind.genotype.edge_active)
        if np.any(mask):
            ind.genotype.edge_active[mask] = True
            modified = True
            ind.invalidate_cache()
        return modified


class ForbiddenEdgeRepair(GraphRepairStep):
    """Enforces that all forbidden edges are inactive in the genotype."""

    def repair(self, ind: GraphIndividual) -> bool:
        modified = False
        space = ind.space
        # Mask where forbidden=True and genotype=True
        mask = space.forbidden_edge_mask & ind.genotype.edge_active
        if np.any(mask):
            ind.genotype.edge_active[mask] = False
            modified = True
            ind.invalidate_cache()
        return modified


class ParameterBoundsRepair(GraphRepairStep):
    """Clips continuous parameters to their defined schema bounds."""

    def repair(self, ind: GraphIndividual) -> bool:
        modified = False
        space = ind.space
        for key, vals in ind.genotype.edge_parameters.items():
            bounds = space.edge_param_bounds.get(key)
            if bounds is not None:
                # Optimized vectorized clipping
                clip_needed = (vals < bounds[:, 0]) | (vals > bounds[:, 1])
                if np.any(clip_needed):
                    ind.genotype.edge_parameters[key] = np.clip(vals, bounds[:, 0], bounds[:, 1])
                    modified = True
                    ind.invalidate_cache()
        return modified


class GraphRepairPipeline:
    """Sequential execution of repair steps."""

    def __init__(self, steps: list[GraphRepairStep]):
        self.steps = steps

    def __call__(self, ind: GraphIndividual) -> bool:
        modified = False
        for step in self.steps:
            if step.repair(ind):
                modified = True
        return modified
