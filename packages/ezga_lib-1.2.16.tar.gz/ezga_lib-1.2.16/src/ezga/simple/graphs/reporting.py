from __future__ import annotations

from .summary import DiscoverySummary


class ScientificReportGenerator:
    """
    Generates human-readable and machine-readable reports from the DiscoverySummary.
    Supports Markdown and JSON formats.
    """

    @staticmethod
    def generate_markdown(summary: DiscoverySummary, filename: str | None = None) -> str:
        """Creates a narrative Markdown report of the scientific findings."""
        lines = []
        lines.append(f"# Scientific Discovery Report: {summary.best_id[:12]}")
        lines.append("\n## 1. Summary of Best Candidate")
        lines.append(f"* **Objectives [Fit, Complexity, Physicality]**: {summary.objectives}")
        lines.append(f"* **Active Species**: {', '.join(summary.active_states)}")
        lines.append(f"* **Active Reactions**: {', '.join(summary.active_edges)}")

        lines.append("\n## 2. Structural Robustness (Ensemble Support)")
        lines.append("| Component | Support Score | Status |")
        lines.append("| :--- | :--- | :--- |")

        # Sort by support
        sorted_edges = sorted(summary.support_scores["edges"].items(), key=lambda x: x[1], reverse=True)
        for eid, score in sorted_edges:
            status = "ROBUST" if score > 0.8 else "SPECULATIVE" if score > 0.3 else "WEAK"
            lines.append(f"| {eid} | {score * 100:.1f}% | {status} |")

        lines.append("\n## 3. Parametric Sensitivity (Control Coefficients)")
        lines.append("Identifies which reactions most strongly influence model misfit.")
        lines.append("| Parameter | Elasticity (ε) | Interpretation |")
        lines.append("| :--- | :--- | :--- |")

        sorted_sens = sorted(summary.sensitivities["edges"].items(), key=lambda x: abs(x[1]), reverse=True)
        for pid, val in sorted_sens:
            interp = "High Control" if abs(val) > 0.5 else "Moderate" if abs(val) > 0.1 else "Negligible"
            lines.append(f"| {pid} | {val:.4f} | {interp} |")

        lines.append("\n## 4. Experimental Recommendations")
        lines.append("Based on ensemble disagreement, the following modifications might resolve speculative pathways:")

        # Simple heuristic: find edges with 0.4 < support < 0.6
        contested = [eid for eid, score in summary.support_scores["edges"].items() if 0.3 < score < 0.7]
        if contested:
            lines.append(f"* Target observations that can specifically confirm/refute: {', '.join(contested)}")
        else:
            lines.append("* The mechanism is structurally stable across the elite ensemble.")

        report = "\n".join(lines)
        if filename:
            with open(filename, "w") as f:
                f.write(report)
            print(f"Scientific report saved to {filename}")

        return report

    @staticmethod
    def generate_json(summary: DiscoverySummary, filename: str | None = None) -> str:
        """Exports the summary to a machine-readable JSON format."""
        data = summary.to_json()
        if filename:
            with open(filename, "w") as f:
                f.write(data)
        return data
