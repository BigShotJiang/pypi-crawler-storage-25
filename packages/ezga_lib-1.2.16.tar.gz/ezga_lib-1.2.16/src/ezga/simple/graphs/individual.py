from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:
    from .space import GraphSearchSpace


@dataclass
class GraphGenotype:
    """
    Stores the Optimization Genes for a graph solution.
    Binary masks for activity + continuous parameter arrays.
    """

    edge_active: np.ndarray  # (n_edges,) bool
    edge_parameters: dict[str, np.ndarray] = field(default_factory=dict)
    node_active: np.ndarray | None = None  # (n_nodes,) bool
    node_parameters: dict[str, np.ndarray] = field(default_factory=dict)
    global_parameters: dict[str, float] = field(default_factory=dict)

    def copy(self) -> GraphGenotype:
        return GraphGenotype(
            edge_active=self.edge_active.copy(),
            edge_parameters={k: v.copy() for k, v in self.edge_parameters.items()},
            node_active=self.node_active.copy() if self.node_active is not None else None,
            node_parameters={k: v.copy() for k, v in self.node_parameters.items()},
            global_parameters=self.global_parameters.copy(),
        )


class GraphPhenotype:
    """
    A materialized read-only view of a graph optimized solution.
    Provides utility methods to interact with standard graph libraries (NetworkX, NumPy).
    """

    def __init__(self, space: GraphSearchSpace, genotype: GraphGenotype):
        self.space = space
        self.genotype = genotype

        # 1. Deduce node activation
        if self.genotype.node_active is not None:
            self.active_node_indices = np.where(self.genotype.node_active)[0]
        else:
            self.active_node_indices = np.arange(len(self.space.states))

        self.active_states = [self.space.states[i] for i in self.active_node_indices]
        self.active_node_ids = {s.id for s in self.active_states}

        # 2. Phenotype Consistency Rule
        # Edge is active ONLY if both source and target nodes are active AND edge mask is ON.
        edge_mask = self.genotype.edge_active.copy()
        for i in range(len(edge_mask)):
            if edge_mask[i]:
                e = self.space.candidate_edges[i]
                if e.source not in self.active_node_ids or e.target not in self.active_node_ids:
                    edge_mask[i] = False

        self.active_edge_indices = np.where(edge_mask)[0]
        self.active_edges = [self.space.candidate_edges[i] for i in self.active_edge_indices]

    def _get_transformed_edge_params(self, key: str) -> np.ndarray:
        """Returns physical edge parameters, applying log-transform if configured."""
        vals = self.genotype.edge_parameters.get(key)
        if vals is None:
            return np.ones(self.space.n_edges)

        log_mask = self.space.edge_param_log_mask.get(key)
        if log_mask is not None and np.any(log_mask):
            # Apply 10**x only where log_scale is True
            transformed = vals.copy()
            transformed[log_mask] = 10 ** vals[log_mask]
            return np.asarray(transformed)
        return np.asarray(vals)

    def _get_transformed_node_params(self, key: str) -> np.ndarray:
        """Returns physical node parameters, applying log-transform if configured."""
        vals = self.genotype.node_parameters.get(key)
        if vals is None:
            return np.ones(self.space.n_states)

        log_mask = self.space.node_param_log_mask.get(key)
        if log_mask is not None and np.any(log_mask):
            transformed = vals.copy()
            transformed[log_mask] = 10 ** vals[log_mask]
            return np.asarray(transformed)
        return np.asarray(vals)

    def to_adjacency(self, sparse: bool = False, param_key: str = "weight") -> np.ndarray | Any:
        """Constructs an adjacency matrix representation."""
        n = self.space.n_states
        adj = np.zeros((n, n), dtype=float)

        # Use transformed parameters
        weights = self._get_transformed_edge_params(param_key)

        for i in self.active_edge_indices:
            e = self.space.candidate_edges[i]
            u = self.space.state_index[e.source]
            v = self.space.state_index[e.target]
            w = weights[i]

            adj[u, v] = w
            if not e.directed:
                adj[v, u] = w

        if sparse:
            try:
                from scipy import sparse as sp

                return sp.csr_matrix(adj)
            except ImportError:
                return adj
        return adj

    def to_networkx(self):
        """Converts phenotype to a NetworkX Graph object."""
        import networkx as nx

        G = nx.DiGraph() if self.space.graph_type == "directed" else nx.Graph()

        # Transform all parameters for nodes
        transformed_node_params = {k: self._get_transformed_node_params(k) for k in self.genotype.node_parameters}
        for s in self.active_states:
            idx = self.space.state_index[s.id]
            node_params = {k: v[idx] for k, v in transformed_node_params.items()}
            G.add_node(
                s.id,
                **s.features,
                label=s.label,
                role=s.role,
                observable=s.observable,
                **node_params,
            )

        # Transform all parameters for edges
        transformed_edge_params = {k: self._get_transformed_edge_params(k) for k in self.genotype.edge_parameters}
        for i in self.active_edge_indices:
            e = self.space.candidate_edges[i]
            edge_params = {k: v[i] for k, v in transformed_edge_params.items()}
            G.add_edge(e.source, e.target, id=e.id, **edge_params)

        return G

    def active_edge_list(self) -> list[tuple[str, str, dict[str, Any]]]:
        """Returns list of (source, target, params) for active edges with physical values."""
        results = []
        transformed_edge_params = {k: self._get_transformed_edge_params(k) for k in self.genotype.edge_parameters}
        for i in self.active_edge_indices:
            e = self.space.candidate_edges[i]
            params = {k: v[i] for k, v in transformed_edge_params.items()}
            results.append((e.source, e.target, params))
        return results


class GraphIndividual:
    """
    SAGE-compatible individual for graph optimization.
    Inherits logical identity from GraphGenotype.
    """

    def __init__(self, genotype: GraphGenotype, space: GraphSearchSpace):
        self.genotype = genotype
        self.space = space
        self._phenotype_cache: GraphPhenotype | None = None
        self.fitness: Any = None
        self.metadata: dict[str, Any] = {}

    @property
    def phenotype(self) -> GraphPhenotype:
        if self._phenotype_cache is None:
            self._phenotype_cache = GraphPhenotype(self.space, self.genotype)
        return self._phenotype_cache

    def invalidate_cache(self):
        self._phenotype_cache = None

    def get_topology_id(self) -> str:
        """Returns a stable string/hash identifying the current graph structure (edge mask)."""
        edge_bits = "".join(["1" if b else "0" for b in self.genotype.edge_active])
        node_bits = ""
        if self.genotype.node_active is not None:
            node_bits = ":" + "".join(["1" if b else "0" for b in self.genotype.node_active])
        return edge_bits + node_bits
