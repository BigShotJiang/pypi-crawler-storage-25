from __future__ import annotations
import os
from typing import Any

from ezga.simple.algorithm import GA
from ezga.simple.minimize import minimize

from .problem import GraphOptimizationProblem
from .reporting import ScientificReportGenerator
from .robustness import StructuralRobustnessEngine
from .sensitivity import LocalSensitivityEngine
from .summary import DiscoverySummary
from .visualization import GraphVisualizer


class DiscoveryWorkflow:
    """
    High-level orchestrator for the Scientific Model Discovery process.
    Simplifies the transition from optimization to validation and reporting.
    """

    def __init__(self, problem: GraphOptimizationProblem, evaluator: Any):
        self.problem = problem
        self.evaluator = evaluator
        self.result: Any = None
        self.summary: Any = None

    def run(self, n_gen: int = 100, pop_size: int = 100, **kwargs) -> Any:
        """
        Executes the optimization process.
        """
        # 1. Automatic Validation
        # Users might have provided y0/y_data in evaluator; we should check if possible
        y0 = getattr(self.evaluator, "y0", None)
        y_data = getattr(self.evaluator, "y_data", None)
        self.problem.validate(y0=y0, y_data=y_data)

        # 2. Setup Evaluation
        def wrapped_eval(x, out, *args, **kwargs):
            graph_id = int(x[0])
            ind = self.problem.get_graph(graph_id)
            out["F"] = self.evaluator.evaluate(ind, self.problem)

        # Use setattr to override method to satisfy Mypy
        setattr(self.problem, "_evaluate", wrapped_eval)

        # 3. Algorithm setup
        algorithm = GA(pop_size=pop_size, **kwargs)

        # 4. Minimize
        print(f"Starting Discovery Workflow ({n_gen} generations, pop={pop_size})...")
        self.result = minimize(self.problem, algorithm, termination=("n_gen", n_gen), verbose=True)

        # 5. Post-run analytical enrichment
        self._analyze_results()

        return self.result

    def _analyze_results(self):
        """Internal helper to populate the DiscoverySummary from elite results."""
        if self.result is None:
            return

        # Extract best and ensemble
        best_id = int(self.result.X[0])
        best_ind = self.problem.get_graph(best_id)

        # Elite Ensemble (Top 10%)
        # For simplicity in demo, we grab a subset of unique top solutions
        elite_ids = sorted(self.problem.graphs.keys())[:10]
        ensemble = [self.problem.graphs[eid] for eid in elite_ids]

        # Robustness
        support = StructuralRobustnessEngine.compute_ensemble_support(ensemble)

        # Sensitivity
        sensitivity = LocalSensitivityEngine.calculate_sensitivity(best_ind, self.evaluator, self.problem)

        # Summary
        self.summary = DiscoverySummary.from_analysis(best_ind, ensemble, support, sensitivity)

    def generate_outputs(self, directory: str = "."):
        """Generates all scientific artifacts (markdown, json, png)."""
        if self.summary is None:
            raise RuntimeError("Workflow must be run() before generating outputs.")

        if not os.path.exists(directory):
            os.makedirs(directory)

        # 1. Report
        report_path = os.path.join(directory, "discovery_report.md")
        ScientificReportGenerator.generate_markdown(self.summary, filename=report_path)

        # 2. JSON
        json_path = os.path.join(directory, "discovery_summary.json")
        ScientificReportGenerator.generate_json(self.summary, filename=json_path)

        # 3. Consensus Visualization
        viz_path = os.path.join(directory, "consensus_mechanism.png")
        GraphVisualizer.plot_consensus_graph(
            self.problem.space,
            self.summary.support_scores,
            filename=viz_path,
            title="Consistent Mechanistic Ensemble",
        )

        print(f"Outputs generated in directory: {directory}")
