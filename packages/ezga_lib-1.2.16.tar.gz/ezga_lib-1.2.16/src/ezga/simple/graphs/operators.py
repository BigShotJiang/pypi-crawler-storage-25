from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .individual import GraphGenotype, GraphIndividual

if TYPE_CHECKING:
    from .problem import GraphOptimizationProblem


class GraphMutator:
    """
    Mutation operator for graph structures and parameters.
    Supports mode-aware mutation (topology-only, parameters-only, or hybrid).
    """

    def __init__(
        self,
        problem: GraphOptimizationProblem,
        topology_prob: float = 0.1,
        parameter_prob: float = 0.2,
        parameter_sigma: float = 0.05,
    ):
        self.problem = problem
        self.topology_prob = topology_prob
        self.parameter_prob = parameter_prob
        self.parameter_sigma = parameter_sigma

    def __call__(self, individual: GraphIndividual) -> GraphIndividual:
        # 1. Clone to avoid side effects
        new_genotype = individual.genotype.copy()

        # 2. Topology Mutation (Edge/Node Toggling)
        if self.problem.mode in ("topology", "hybrid"):
            self._mutate_topology(new_genotype)
            self._mutate_nodes(new_genotype)

        # 3. Parameter Mutation (Continuous perturbation)
        if self.problem.mode in ("parameters", "hybrid"):
            self._mutate_parameters(new_genotype)

        # 4. Create new Individual and Register
        new_ind = self.problem.create_individual(new_genotype)
        new_id = self.problem.get_next_id()
        self.problem.register_graph(new_id, new_ind)

        return new_ind

    def _mutate_topology(self, genotype: GraphGenotype):
        """Randomly flips the activity of candidate edges, respecting fixed/required flags."""
        space = self.problem.space

        # Mask for edges allowed to change
        changeable = ~(space.required_edge_mask | space.forbidden_edge_mask)
        indices = np.where(changeable)[0]

        if len(indices) == 0:
            return

        # Multi-bit toggle based on prob
        mask = np.random.random(len(indices)) < self.topology_prob
        if np.any(mask):
            genotype.edge_active[indices[mask]] = ~genotype.edge_active[indices[mask]]

    def _mutate_nodes(self, genotype: GraphGenotype):
        """Randomly flips the activity of optional nodes."""
        space = self.problem.space
        if not space.allow_node_activation or genotype.node_active is None:
            return

        indices = np.where(space.node_optional_mask)[0]
        if len(indices) == 0:
            return

        mask = np.random.random(len(indices)) < self.topology_prob
        if np.any(mask):
            genotype.node_active[indices[mask]] = ~genotype.node_active[indices[mask]]

    def _mutate_parameters(self, genotype: GraphGenotype):
        """Adds Gaussian noise to continuous parameters of active components."""
        space = self.problem.space

        # 1. Edge Parameters
        for key, vals in genotype.edge_parameters.items():
            bounds = space.edge_param_bounds.get(key)
            if bounds is None:
                continue

            mask = np.random.random(len(vals)) < self.parameter_prob
            if np.any(mask):
                ranges = bounds[:, 1] - bounds[:, 0]
                noise = np.random.normal(0, self.parameter_sigma, size=int(np.sum(mask))) * ranges[mask]
                vals[mask] = np.clip(vals[mask] + noise, bounds[mask, 0], bounds[mask, 1])

        # 2. Node Parameters
        for key, vals in genotype.node_parameters.items():
            bounds = space.node_param_bounds.get(key)
            if bounds is None:
                continue

            mask = np.random.random(len(vals)) < self.parameter_prob
            if np.any(mask):
                ranges = bounds[:, 1] - bounds[:, 0]
                noise = np.random.normal(0, self.parameter_sigma, size=int(np.sum(mask))) * ranges[mask]
                vals[mask] = np.clip(vals[mask] + noise, bounds[mask, 0], bounds[mask, 1])


class GraphCrossover:
    """
    Crossover operator for graph structures.
    Performs mask swapping and parameter blending.
    """

    def __init__(self, problem: GraphOptimizationProblem, crossover_prob: float = 0.9):
        self.problem = problem
        self.crossover_prob = crossover_prob

    def __call__(self, p1: GraphIndividual, p2: GraphIndividual) -> tuple[GraphIndividual, GraphIndividual]:
        if np.random.random() > self.crossover_prob:
            return p1, p2

        # 1. Clone Genotypes
        g1 = p1.genotype.copy()
        g2 = p2.genotype.copy()

        # 2. Topology Crossover (Uniform Mask Swap)
        if self.problem.mode in ("topology", "hybrid"):
            # Edge swap
            swap_mask = np.random.random(len(g1.edge_active)) < 0.5
            g1.edge_active[swap_mask], g2.edge_active[swap_mask] = (
                g2.edge_active[swap_mask].copy(),
                g1.edge_active[swap_mask].copy(),
            )

            # Node swap
            if self.problem.space.allow_node_activation and g1.node_active is not None and g2.node_active is not None:
                swap_mask = np.random.random(len(g1.node_active)) < 0.5
                g1.node_active[swap_mask], g2.node_active[swap_mask] = (
                    g2.node_active[swap_mask].copy(),
                    g1.node_active[swap_mask].copy(),
                )

        # 3. Parameter Crossover (Simple Average/Blend)
        if self.problem.mode in ("parameters", "hybrid"):
            # Edge Params
            for key in g1.edge_parameters:
                v1, v2 = g1.edge_parameters[key], g2.edge_parameters[key]
                avg = (v1 + v2) / 2.0
                g1.edge_parameters[key], g2.edge_parameters[key] = avg, avg.copy()

            # Node Params
            for key in g1.node_parameters:
                v1, v2 = g1.node_parameters[key], g2.node_parameters[key]
                avg = (v1 + v2) / 2.0
                g1.node_parameters[key], g2.node_parameters[key] = avg, avg.copy()

        # 4. Create and Register
        c1, c2 = self.problem.create_individual(g1), self.problem.create_individual(g2)
        id1, id2 = self.problem.get_next_id(), self.problem.get_next_id()
        self.problem.register_graph(id1, c1)
        self.problem.register_graph(id2, c2)

        return c1, c2
