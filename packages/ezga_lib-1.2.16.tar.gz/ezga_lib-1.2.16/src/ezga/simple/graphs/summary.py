from __future__ import annotations
import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class DiscoverySummary:
    """
    Data container for all results from the Scientific Discovery Suite.
    Decouples analysis logic from communication/reporting formatting.
    """

    best_id: str
    objectives: list[float]
    active_states: list[str]
    active_edges: list[str]

    # Enrichment
    support_scores: dict[str, Any] = field(default_factory=dict)
    sensitivities: dict[str, Any] = field(default_factory=dict)

    # Metadata
    n_elite: int = 0
    computation_time: float = 0.0

    def to_json(self) -> str:
        return json.dumps(self.__dict__, indent=2)

    @classmethod
    def from_analysis(
        cls,
        best_ind: Any,
        ensemble: list[Any],
        support_scores: dict[str, Any],
        sensitivities: dict[str, Any],
    ) -> "DiscoverySummary":
        """Factory to create a summary from analysis outputs."""
        return cls(
            best_id=best_ind.get_topology_id(),
            objectives=list(best_ind.objectives) if hasattr(best_ind, "objectives") else [0.0],
            active_states=[s.id for s in best_ind.phenotype.active_states],
            active_edges=[e.id for e in best_ind.phenotype.active_edges],
            support_scores=support_scores,
            sensitivities=sensitivities,
            n_elite=len(ensemble),
        )
