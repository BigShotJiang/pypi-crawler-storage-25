from __future__ import annotations
from collections import defaultdict
from typing import Any

import numpy as np

from .hashing import GraphHasher
from .individual import GraphIndividual


class StructuralRobustnessEngine:
    """
    Analyzes the structural stability of the discovered models across an ensemble.
    Computes support scores for nodes and edges based on their inclusion in top models.
    """

    @staticmethod
    def compute_ensemble_support(
        ensemble: list[GraphIndividual], weights: np.ndarray | None = None
    ) -> dict[str, Any]:
        """
        Calculates the weighted inclusion frequency for each state and edge in the search space.

        Args:
            ensemble: List of elite individuals.
            weights: Optional probability weights for each individual. Defaults to uniform.

        Returns:
            Dictionary with 'nodes' and 'edges' support maps.
        """
        if not ensemble:
            return {"nodes": {}, "edges": {}}

        space = ensemble[0].space
        n_ind = len(ensemble)

        if weights is None:
            weights = np.ones(n_ind) / n_ind
        else:
            weights = weights / np.sum(weights)

        # 1. Node Support
        node_support = np.zeros(space.n_states)
        for i, ind in enumerate(ensemble):
            if ind.genotype.node_active is not None:
                node_support += ind.genotype.node_active * weights[i]
            else:
                node_support += weights[i]

        # 2. Edge Support
        edge_support = np.zeros(space.n_edges)
        for i, ind in enumerate(ensemble):
            edge_support += ind.genotype.edge_active * weights[i]

        # Map to human-readable IDs
        result = {
            "nodes": {space.states[j].id: node_support[j] for j in range(space.n_states)},
            "edges": {space.candidate_edges[j].id: edge_support[j] for j in range(space.n_edges)},
        }
        return result

    @staticmethod
    def group_isomorphic_families(
        ensemble: list[GraphIndividual],
    ) -> dict[str, list[GraphIndividual]]:
        """
        Groups ensemble members into families of topologically identical structures.
        Useful for identifying the most likely 'mechanistic architecture' across runs.
        """
        families = defaultdict(list)
        for ind in ensemble:
            topo_hash = GraphHasher.compute_topology_hash(ind.genotype, ind.space)
            families[topo_hash].append(ind)
        return dict(families)
