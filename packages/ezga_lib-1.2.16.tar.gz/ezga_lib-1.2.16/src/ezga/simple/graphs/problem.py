from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

import numpy as np

from ezga.simple.problem import ElementwiseProblem

from .hashing import GraphHasher
from .individual import GraphGenotype, GraphIndividual

if TYPE_CHECKING:
    from .space import GraphSearchSpace


class GraphOptimizationProblem(ElementwiseProblem):
    """
    Standard problem adapter for Graph Optimization.
    Manages a registry of active graph structures using ID-mapping.
    Fits into the EZGA 'simple' workflow by storing graph IDs in atom coordinates.
    """

    def __init__(
        self,
        space: GraphSearchSpace,
        n_obj: int = 1,
        n_constr: int = 0,
        xl: float = 0.0,
        xu: float = 1.0,
        mode: str = "hybrid",
        complexity_weights: tuple[float, float, float] = (1.0, 1.0, 0.1),
        **kwargs,
    ):
        super().__init__(n_var=1, n_obj=n_obj, n_constr=n_constr, xl=xl, xu=xu)
        self.space = space
        self.mode = mode  # "topology", "parameters", "hybrid"
        self.graphs: dict[int, GraphIndividual] = {}
        self.next_id = 7000000  # High starting ID for graph objects

        # Parsimony weights: alpha (nodes), beta (edges), gamma (params)
        self.alpha, self.beta, self.gamma = complexity_weights

        # Performance cache for results
        self.result_cache: dict[str, Any] = {}

    def validate(self, y0: np.ndarray | None = None, y_data: np.ndarray | None = None):
        """
        Performs strict validation of the problem setup against potential data.
        Raises ValueError with clear instructions if inconsistencies are found.
        """
        n_states = self.space.n_states

        # 1. Validate y0
        if y0 is not None:
            if len(y0) != n_states:
                raise ValueError(
                    f"Initial condition y0 has length {len(y0)}, but the graph search space "
                    f"defines {n_states} states ({[s.id for s in self.space.states]}). "
                    "Please ensure y0 matches the state order in the search space."
                )

        # 2. Validate y_data vs Observables
        if y_data is not None:
            obs_mask = self.get_auto_species_mask()
            n_obs = np.sum(obs_mask)
            if y_data.shape[1] != n_obs:
                obs_ids = [s.id for s in self.space.states if s.observable]
                raise ValueError(
                    f"Data y_data has {y_data.shape[1]} columns, but the graph defines "
                    f"{n_obs} observable states ({obs_ids}). "
                    "Mismatch in data dimensionality."
                )

    def get_auto_species_mask(self) -> np.ndarray:
        """Helper to generate the species_mask for the KineticFitEvaluator."""
        return self.space.get_observable_mask()

    def register_graph(self, graph_id: int, graph: GraphIndividual):
        self.graphs[int(graph_id)] = graph

    def get_graph(self, graph_id: int) -> GraphIndividual | None:
        return self.graphs.get(int(graph_id))

    def get_next_id(self) -> int:
        self.next_id += 1
        return self.next_id

    def create_individual(self, genotype: GraphGenotype) -> GraphIndividual:
        """Helper to create and register a new individual."""
        ind = GraphIndividual(genotype, self.space)
        return ind

    def get_complexity(self, ind: GraphIndividual) -> float:
        """
        Calculates weighted graph complexity:
        C = alpha * N_active_nodes + beta * N_active_edges + gamma * N_active_params
        """
        n_nodes = float(len(ind.phenotype.active_node_indices))
        n_edges = float(len(ind.phenotype.active_edge_indices))

        # Free parameters are those attached to active components
        n_params = 0.0
        n_params += n_edges * len(self.space.edge_param_keys)
        n_params += n_nodes * len(self.space.node_param_keys)

        return self.alpha * n_nodes + self.beta * n_edges + self.gamma * n_params

    def _evaluate(self, x, out, *args, **kwargs):
        """
        Standard eval entry point for ElementwiseProblem.
        """
        graph_id = int(x[0])
        ind = self.get_graph(graph_id)

        if ind is None:
            out["F"] = np.full(self.n_obj, np.inf)
            return

        sol_hash = GraphHasher.compute_solution_hash(ind.genotype, space=self.space)
        if sol_hash in self.result_cache:
            out["F"] = self.result_cache[sol_hash]
            return

        # Default evaluation returns zero objectives; users should override _evaluate
        out["F"] = np.zeros(self.n_obj)
        self.result_cache[sol_hash] = out["F"]


class GraphProblemBuilder:
    """
    Fluent API for constructing Graph Optimization problems.
    """

    def __init__(self):
        self._states = []
        self._edges = []
        self._constraints = []
        self._mode = "hybrid"
        self._n_obj = 1
        self._complexity_weights = (1.0, 1.0, 0.1)

    def add_state(
        self, state_id: str, role: str = "REQUIRED", observable: bool = False, **kwargs
    ) -> GraphProblemBuilder:
        if any(s.id == state_id for s in self._states):
            return self

        from .space import GraphState

        self._states.append(GraphState(id=state_id, role=cast(Any, role), observable=observable, **kwargs))
        return self

    def add_observable(self, state_id: str, **kwargs) -> GraphProblemBuilder:
        """Shortcut to add a required species that is also measured in data."""
        return self.add_state(state_id, role="REQUIRED", observable=True, **kwargs)

    def add_intermediate(self, state_id: str, **kwargs) -> GraphProblemBuilder:
        """Helper to add an optional intermediate species discovery point (usually hidden)."""
        return self.add_state(state_id, role="OPTIONAL", observable=False, **kwargs)

    def add_edge(self, source: str, target: str, edge_id: str | None = None, **kwargs) -> GraphProblemBuilder:
        from .space import GraphEdge

        if edge_id is None:
            edge_id = f"{source}->{target}"
        self._edges.append(GraphEdge(id=edge_id, source=source, target=target, **kwargs))
        return self

    def add_constraint(self, constraint: Any) -> GraphProblemBuilder:
        self._constraints.append(constraint)
        return self

    def set_complexity_weights(self, alpha: float, beta: float, gamma: float) -> GraphProblemBuilder:
        self._complexity_weights = (alpha, beta, gamma)
        return self

    def set_mode(self, mode: str) -> GraphProblemBuilder:
        self._mode = mode
        return self

    def set_n_obj(self, n: int) -> GraphProblemBuilder:
        self._n_obj = n
        return self

    def build(self) -> GraphOptimizationProblem:
        from .space import GraphSearchSpace

        state_ids = {s.id for s in self._states}
        for e in self._edges:
            if e.source not in state_ids:
                raise ValueError(f"Edge {e.id} references missing source state {e.source}")
            if e.target not in state_ids:
                raise ValueError(f"Edge {e.id} references missing target state {e.target}")

        # 1. Create Space
        space = GraphSearchSpace(states=self._states, candidate_edges=self._edges)

        # 2. Create Problem
        problem = GraphOptimizationProblem(
            space=space,
            n_obj=self._n_obj,
            mode=self._mode,
            complexity_weights=self._complexity_weights,
        )
        start_id = problem.next_id + 1

        # 3. Seed initial population
        for _ in range(100):
            g = space.create_random_genotype(mode=self._mode)
            ind = problem.create_individual(g)
            gid = problem.get_next_id()
            problem.register_graph(gid, ind)

        end_id = problem.next_id
        problem.xl = np.array([float(start_id)])
        problem.xu = np.array([float(end_id)])

        return problem
