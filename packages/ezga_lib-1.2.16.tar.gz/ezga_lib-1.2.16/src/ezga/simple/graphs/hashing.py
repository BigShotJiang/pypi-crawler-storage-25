from __future__ import annotations
import hashlib
from typing import TYPE_CHECKING, Any

import networkx as nx
import numpy as np

if TYPE_CHECKING:
    from .individual import GraphGenotype


class GraphHasher:
    """
    Computes deterministic hashes from Genotypes for identity management.
    Used for structural deduplication, result caching, and ensemble consensus.
    """

    @staticmethod
    def compute_topology_hash(genotype: "GraphGenotype", space: Any | None = None) -> str:
        """
        Computes a stable structural hash using the Weisfeiler-Lehman algorithm.
        This hash is invariant to node/edge indexing but respects semantic labels.
        """
        if space is None:
            # Fallback to simple bitmask hash if space (metadata) is unavailable
            hasher = hashlib.md5()
            hasher.update(genotype.edge_active.tobytes())
            if genotype.node_active is not None:
                hasher.update(genotype.node_active.tobytes())
            return hasher.hexdigest()

        # 1. Build a networkx graph of the active phenotype
        G = nx.DiGraph()

        # Add active nodes with semantic attributes
        if genotype.node_active is not None:
            for i, active in enumerate(genotype.node_active):
                if active:
                    state = space.states[i]
                    G.add_node(i, label=state.label or state.id, role=state.role)
        else:
            # All nodes are active (activation disabled)
            for i, state in enumerate(space.states):
                G.add_node(i, label=state.label or state.id, role=state.role)

        # Add active edges
        for i, active in enumerate(genotype.edge_active):
            if active:
                edge = space.candidate_edges[i]
                if edge.source in space.state_index and edge.target in space.state_index:
                    u = space.state_index[edge.source]
                    v = space.state_index[edge.target]
                    if G.has_node(u) and G.has_node(v):
                        G.add_edge(u, v)

        # 2. Compute WL Hash
        return str(nx.weisfeiler_lehman_graph_hash(G, node_attr="role", edge_attr=None))

    @staticmethod
    def compute_solution_hash(
        genotype: "GraphGenotype", space: Any | None = None, decimal_precision: int = 4
    ) -> str:
        """
        Hash based on both topology (isomorphism-aware) and rounded parameter values.
        Useful for evaluation caching and checkpointing.
        """
        topo_hash = GraphHasher.compute_topology_hash(genotype, space)

        hasher = hashlib.md5()
        hasher.update(topo_hash.encode("utf-8"))

        # 3. Parameter data (rounded for stability)
        for key in sorted(genotype.edge_parameters.keys()):
            # Only hash active edge parameters
            active_params = genotype.edge_parameters[key][genotype.edge_active]
            rounded = np.round(active_params, decimals=decimal_precision)
            hasher.update(rounded.tobytes())

        for key in sorted(genotype.node_parameters.keys()):
            if genotype.node_active is not None:
                active_params = genotype.node_parameters[key][genotype.node_active]
                rounded = np.round(active_params, decimals=decimal_precision)
                hasher.update(rounded.tobytes())
            else:
                hasher.update(np.round(genotype.node_parameters[key], decimals=decimal_precision).tobytes())

        # 4. Global parameters
        for key in sorted(genotype.global_parameters.keys()):
            val = genotype.global_parameters[key]
            hasher.update(np.round(val, decimals=decimal_precision).tobytes())

        return hasher.hexdigest()
