from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from .individual import GraphIndividual


class ThermodynamicLayer:
    """
    Utilities for enforcing physical consistency in reaction networks.
    Supports cycle-basis analysis and energy barrier validation.
    """

    @staticmethod
    def get_cycle_basis(ind: GraphIndividual) -> list[list[str]]:
        """
        Computes the fundamental cycle basis for the active graph structure.
        Uses NetworkX minimum cycle basis on the undirected version.
        """
        import networkx as nx

        G = ind.phenotype.to_networkx()
        try:
            # We treat the graph as undirected to find thermodynamic loops
            # (Hess's law applies to the state manifold)
            basis = nx.minimum_cycle_basis(G.to_undirected())
            return list(basis)
        except Exception:
            return []

    @staticmethod
    def compute_cycle_inconsistency(ind: GraphIndividual) -> float:
        """
        Sum of absolute residuals of Delta G over the fundamental cycle basis.
        Ideally zero for a thermodynamically consistent network.
        """
        basis = ThermodynamicLayer.get_cycle_basis(ind)
        if not basis:
            return 0.0

        # Delta G values are stored in edge parameters
        # We need a way to know the sign (source -> target is forward)
        g_vals = ind.genotype.edge_parameters.get("gibbs_energy")
        if g_vals is None:
            return 0.0

        total_residual = 0.0
        # Map edge IDs to their G values for fast lookup
        edge_id_to_g = {}
        for i, e in enumerate(ind.space.candidate_edges):
            edge_id_to_g[e.id] = g_vals[i]

        for cycle in basis:
            cycle_sum = 0.0
            # A cycle is a list of nodes: [n1, n2, n3]
            for i in range(len(cycle)):
                u, v = cycle[i], cycle[(i + 1) % len(cycle)]

                # Find the edge matching u -> v or v -> u
                # Forward: A -> B adds G
                # Backward: B -> A adds -G
                for e in ind.phenotype.active_edges:
                    if e.source == u and e.target == v:
                        cycle_sum += edge_id_to_g[e.id]
                        break
                    elif e.source == v and e.target == u:
                        cycle_sum -= edge_id_to_g[e.id]
                        break
                # If an edge is missing in the phenotype but part of the basis,
                # it shouldn't really happen if we only used active nodes.

            total_residual += abs(cycle_sum)

        return total_residual


class ThermoValidityConstraint:
    """
    Hard constraint logic for physical parameters.
    """

    def __init__(self, enforce_positive_ba: bool = True):
        self.enforce_positive_ba = enforce_positive_ba

    def __call__(self, ind: GraphIndividual) -> np.ndarray:
        """
        Returns a vector of constraint violations (>= 0 means violation).
        """
        violations = []

        # 1. Activation Energy Positivity (Ea >= 0)
        if self.enforce_positive_ba:
            ea_vals = ind.genotype.edge_parameters.get("activation_energy")
            if ea_vals is not None:
                # Only check active edges
                active_ea = ea_vals[ind.phenotype.active_edge_indices]
                v = np.sum(np.maximum(0.0, -active_ea))
                violations.append(v)
            else:
                violations.append(0.0)

        return np.array(violations)


class ThermoConsistencyObjective:
    """
    Soft objective for thermodynamic manifold deviation.
    """

    def __call__(self, ind: GraphIndividual) -> float:
        return ThermodynamicLayer.compute_cycle_inconsistency(ind)
