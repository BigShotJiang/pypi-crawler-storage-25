from __future__ import annotations
from typing import Any

import numpy as np

from .individual import GraphIndividual


class LocalSensitivityEngine:
    """
    Identifies 'Rate-Controlling' reactions using finite-difference sensitivity.
    Works as a black-box on any differentiable-by-perturbation simulator.
    """

    @staticmethod
    def calculate_sensitivity(
        ind: GraphIndividual, evaluator: Any, problem: Any, epsilon: float = 1e-4
    ) -> dict[str, dict[str, float]]:
        """
        Computes the relative sensitivity of the misfit with respect to parameters.

        Args:
            ind: The specific mechanism (individual) to analyze.
            evaluator: The kinetic simulator (KineticFitEvaluator).
            problem: The GraphOptimizationProblem.
            epsilon: The relative perturbation size.

        Returns:
            Dictionary mapping edge/node IDs to their sensitivity coefficients.
        """
        space = ind.space
        # Base evaluation
        base_scores = evaluator.evaluate(ind, problem)
        base_fit = base_scores[0]  # Assume index 0 is Fit (MAE)

        sensitivities: dict[str, dict[str, float]] = {"edges": {}, "nodes": {}}

        # 1. Edge Parameter Sensitivity
        for key in sorted(ind.genotype.edge_parameters.keys()):
            params = ind.genotype.edge_parameters[key]
            active_edges = np.where(ind.genotype.edge_active)[0]

            for idx in active_edges:
                eid = space.candidate_edges[idx].id
                original_val = params[idx]

                # Perturb
                delta = max(original_val * epsilon, epsilon)
                params[idx] = original_val + delta

                # Re-evaluate
                scores_p = evaluator.evaluate(ind, problem)
                fit_p = scores_p[0]

                # Reset
                params[idx] = original_val

                # Gradient (normalized)
                grad = (fit_p - base_fit) / delta
                elasticity = grad * (original_val / (base_fit + 1e-10))
                sensitivities["edges"][f"{eid}[{key}]"] = float(elasticity)

        # 2. Node Parameter Sensitivity
        for key in sorted(ind.genotype.node_parameters.keys()):
            # ... similar logic for node parameters if needed
            pass

        return sensitivities
