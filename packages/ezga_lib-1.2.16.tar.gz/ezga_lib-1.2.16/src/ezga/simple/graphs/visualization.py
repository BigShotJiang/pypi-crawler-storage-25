from __future__ import annotations

from typing import TYPE_CHECKING, Any

import networkx as nx

if TYPE_CHECKING:
    from .individual import GraphIndividual
    from .search_space import GraphSearchSpace


class GraphVisualizer:
    """Utilities for plotting graph optimization results."""

    @staticmethod
    def _get_node_styles(G: nx.Graph) -> dict[str, Any]:
        """Helper to compute colors and border styles based on node metadata."""
        colors = []
        edge_colors = []
        linewidths = []

        # Color Map for Roles
        role_colors = {"REQUIRED": "lightblue", "OPTIONAL": "orange", "DISABLED": "lightgrey"}

        for _n, data in G.nodes(data=True):
            role = data.get("role", "REQUIRED")
            obs = data.get("observable", False)

            colors.append(role_colors.get(role, "lightblue"))

            # Highlight observables with a bold red border
            if obs:
                edge_colors.append("red")
                linewidths.append(3.0)
            else:
                edge_colors.append("black")
                linewidths.append(1.0)

        return {"node_color": colors, "edgecolors": edge_colors, "linewidths": linewidths}

    @staticmethod
    def plot_individual(
        ind: GraphIndividual,
        filename: str | None = None,
        title: str | None = None,
        edge_labels: bool = True,
        node_size: int = 600,
        font_size: int = 10,
        figsize: tuple = (10, 8),
        layout: str = "spring",
    ):
        """Plots a single graph individual with role-based styling."""
        import matplotlib.pyplot as plt

        G = ind.phenotype.to_networkx()
        plt.figure(figsize=figsize)

        # 1. Choose layout
        if layout == "spring":
            pos = nx.spring_layout(G, k=0.5)
        elif layout == "circular":
            pos = nx.circular_layout(G)
        else:
            pos = nx.kamada_kawai_layout(G)

        # 2. Compute Styles
        styles = GraphVisualizer._get_node_styles(G)

        # 3. Draw nodes
        nx.draw_networkx_nodes(G, pos, node_size=node_size, **styles)
        nx.draw_networkx_labels(G, pos, font_size=font_size)

        # 4. Draw edges
        nx.draw_networkx_edges(G, pos, width=1.5, arrowstyle="->", arrowsize=20, edge_color="gray")

        # 5. Edge labels (Physical rates)
        if edge_labels:
            edge_data = nx.get_edge_attributes(G, "k")
            if not edge_data:
                edge_data = nx.get_edge_attributes(G, "rate")
            if not edge_data:
                edge_data = nx.get_edge_attributes(G, "weight")

            if edge_data:
                formatted = {k: f"{v:.2e}" if v < 0.01 or v > 100 else f"{v:.2f}" for k, v in edge_data.items()}
                nx.draw_networkx_edge_labels(G, pos, edge_labels=formatted, font_size=font_size - 2)

        plt.title(title or f"Individual (Hash: {ind.get_topology_id()[:8]})")
        plt.axis("off")

        if filename:
            plt.savefig(filename)
            plt.close()
        else:
            plt.show()

    @staticmethod
    def plot_consensus_graph(
        space: GraphSearchSpace,
        support_scores: dict[str, Any],
        filename: str | None = None,
        title: str | None = "Ensemble Consensus Mechanism",
        threshold: float = 0.1,
        node_size: int = 600,
        font_size: int = 10,
        figsize: tuple = (12, 10),
        layout: str = "spring",
    ):
        """
        Plots a consensus graph where edge properties reflect ensemble support levels.
        Only edges with support above the threshold are shown.
        """
        import matplotlib.pyplot as plt
        import networkx as nx

        G = nx.DiGraph()

        # 1. Add nodes (all required + supported optional)
        node_supports: dict[str, float] = support_scores.get("nodes", {})
        for state in space.states:
            support = node_supports.get(state.id, 1.0)
            if support >= threshold or state.role == "REQUIRED":
                G.add_node(state.id, label=state.label or state.id, role=state.role, support=support)

        # 2. Add supported edges
        edge_supports: dict[str, float] = support_scores.get("edges", {})
        for edge in space.candidate_edges:
            support = edge_supports.get(edge.id, 0.0)
            if support >= threshold:
                if G.has_node(edge.source) and G.has_node(edge.target):
                    G.add_edge(edge.source, edge.target, support=support, id=edge.id)

        # 3. Visualize
        plt.figure(figsize=figsize)

        if layout == "spring":
            pos = nx.spring_layout(G, k=0.5)
        elif layout == "circular":
            pos = nx.circular_layout(G)
        else:
            pos = nx.kamada_kawai_layout(G)

        # 3.1 Compute Styles
        styles = GraphVisualizer._get_node_styles(G)
        node_alphas = [G.nodes[n].get("support", 0.5) for n in G.nodes()]

        # Draw nodes with support-based alpha and role-based color
        nx.draw_networkx_nodes(G, pos, node_size=node_size, alpha=node_alphas, **styles)
        nx.draw_networkx_labels(G, pos, font_size=font_size)

        # 3.2 Draw edges with support-based thickness and alpha
        edges = list(G.edges())
        if edges:
            edge_weights = [G.edges[e]["support"] * 5.0 for e in edges]
            edge_alphas = [G.edges[e]["support"] for e in edges]

            for i, (u, v) in enumerate(edges):
                nx.draw_networkx_edges(
                    G,
                    pos,
                    edgelist=[(u, v)],
                    width=edge_weights[i],
                    alpha=edge_alphas[i],
                    edge_color="indigo",
                    arrowstyle="->",
                    arrowsize=20,
                )

        plt.title(title or "")
        plt.axis("off")

        if filename:
            plt.savefig(filename)
            plt.close()
            print(f"Consensus graph saved to {filename}")
        else:
            plt.show()

    @staticmethod
    def plot_convergence(history: list, filename: str | None = None):
        """TBD: Utility for plotting population/objective convergence over generations."""
        # Placeholder for future implementation
        pass

    @staticmethod
    def plot_active_matrix(ind: GraphIndividual, filename: str | None = None):
        """Plots the adjacency matrix heat map."""
        import matplotlib.pyplot as plt

        adj = ind.phenotype.to_adjacency()

        plt.figure(figsize=(6, 5))
        plt.imshow(adj, cmap="viridis")
        plt.colorbar(label="Edge Strength")
        plt.title("Adjacency Matrix")

        if filename:
            plt.savefig(filename)
            plt.close()
        else:
            plt.show()
