from __future__ import annotations
import abc

import numpy as np


class Node(abc.ABC):
    """
    Abstract base class for all nodes in the Symbolic GA Grammar key.
    """

    @abc.abstractmethod
    def evaluate(self, X):
        """
        Evaluates the node on data X (N_samples, N_features).
        Returns a boolean mask or probabilistic float array (N_samples,).
        """
        pass

    @property
    @abc.abstractmethod
    def size(self):
        """Total number of nodes in the subtree."""
        pass

    @property
    @abc.abstractmethod
    def depth(self):
        """Depth of the subtree."""
        pass

    @abc.abstractmethod
    def __str__(self):
        pass

    def __format__(self, format_spec):
        """
        Support formatting by either applying it to the value (if it can be cast to float)
        or applying it to the string representation.
        """
        if not format_spec:
            return str(self)
        try:
            return format(float(self), format_spec)
        except (TypeError, ValueError):
            return format(str(self), format_spec)

    def simplify(self, eps=1e-9):
        """
        Returns a simplified version of the tree.
        """
        return self

    def is_effectively_constant(self, val: float, eps: float = 1e-9) -> bool:
        """Helper to detect if a node is numerically a specific constant (even if Opt)."""
        if isinstance(self, Constant):
            return bool(abs(float(self.value) - val) < eps)
        if isinstance(self, OptimizableConstant):
            return bool(abs(float(self.value) - val) < eps)
        return False

    def simplify_aggressive(self, eps=1e-9):
        """
        Recursively simplify until no more size reduction occurs.
        """
        current = self
        for _ in range(5):  # Limit iterations to prevent infinite loops (rare)
            prev_size = current.size
            current = current.simplify(eps)
            if current.size >= prev_size:
                break
        return current

    def freeze_constants(self):
        """
        Recursively convert all OptimizableConstant nodes into fixed Constant nodes.
        Default: return self (for leaves/literals that aren't optimizable).
        """
        return self

    def has_variable(self):
        """
        Returns True if the tree contains at least one Variable node.
        """
        from .grammar import Variable
        return any(isinstance(n, Variable) for n in self.get_all_nodes())

    def get_all_nodes(self):
        """
        Returns a list of all nodes in the tree (pro-order).
        """
        nodes = [self]
        if hasattr(self, "children"):
            for child in self.children:
                nodes.extend(child.get_all_nodes())
        elif hasattr(self, "child"):
            nodes.extend(self.child.get_all_nodes())
        return nodes

    def get_subtree(self, index):
        """
        DFS traversal to get the node at a specific index (0-indexed).
        Useful for mutation operators.
        """
        count = [0]  # Mutable wrapper
        result = [None]

        def traverse(node):
            if result[0] is not None:
                return

            if count[0] == index:
                result[0] = node
                return

            count[0] += 1
            if hasattr(node, "children"):
                for child in node.children:
                    traverse(child)
            elif hasattr(node, "child"):
                traverse(node.child)

        traverse(self)
        return result[0]

    def set_subtree(self, index, new_node):
        """
        DFS traversal to replace the node at a specific index.
        Returns a NEW immutable copy of the tree with the replacement.
        (Or modifies in-place if we decide on mutable trees - pure Python trees are easier mutable)
        For performance in Python GA, mutable in-place modification is often preferred
        if we handle cloning carefully at the population level.

        This implementation assumes MUTABLE in-place for efficiency,
        caller must clone first if needed.
        """
        if index == 0:
            return new_node  # Replaces the whole root

        count = [0]
        replaced = [False]

        def traverse(node, parent, child_idx_in_parent):
            if replaced[0]:
                return

            if count[0] == index:
                # Found target, replace in parent
                if parent:
                    # Priority: specific attributes for Binary/Unary
                    if isinstance(parent, BinaryOperator):
                        if child_idx_in_parent == 0:
                            parent.left = new_node
                        else:
                            parent.right = new_node
                    elif isinstance(parent, UnaryOperator):
                        parent.child = new_node
                    elif isinstance(parent, TernaryOperator):
                        if child_idx_in_parent == 0:
                            parent.child1 = new_node
                        elif child_idx_in_parent == 1:
                            parent.child2 = new_node
                        else:
                            parent.child3 = new_node
                    # Fallback for generic multi-child nodes if any
                    elif hasattr(parent, "children") and isinstance(parent.children, list):
                        parent.children[child_idx_in_parent] = new_node
                replaced[0] = True
                return

            count[0] += 1

            # Recurse
            if hasattr(node, "_traverse"):  # Allow nodes to define their own traversal? No, stick to basics
                pass

            if isinstance(node, BinaryOperator):
                traverse(node.left, node, 0)
                traverse(node.right, node, 1)
            elif isinstance(node, UnaryOperator):
                traverse(node.child, node, 0)
            elif isinstance(node, TernaryOperator):
                traverse(node.child1, node, 0)
                traverse(node.child2, node, 1)
                traverse(node.child3, node, 2)

        traverse(self, None, -1)
        return self if not (index == 0) else new_node

    def clone(self):
        import copy

        return copy.deepcopy(self)

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._eq(other)

    def _eq(self, other):
        return True


# --- Operators ---


class BinaryOperator(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    @property
    def children(self):
        return [self.left, self.right]

    @property
    def size(self):
        return 1 + self.left.size + self.right.size

    @property
    def depth(self):
        return 1 + max(self.left.depth, self.right.depth)

    def __repr__(self):
        return f"{self.__class__.__name__}({repr(self.left)}, {repr(self.right)})"

    def _eq(self, other):
        return self.left == other.left and self.right == other.right

    def freeze_constants(self):
        self.left = self.left.freeze_constants()
        self.right = self.right.freeze_constants()
        return self

    def simplify(self, eps=1e-9):
        # 1. Recursive Simplify
        self.left = self.left.simplify(eps)
        self.right = self.right.simplify(eps)

        l = self.left
        r = self.right

        # 2. Constant Folding (Strict Constants only, preserving Optimizable)
        if isinstance(l, Constant) and isinstance(r, Constant):
            try:
                dummy_X = np.zeros((1, 1))
                val = self.evaluate(dummy_X)[0]
                return Constant(val)
            except:
                pass

        # 3. Algebraic Identities
        # Add
        if isinstance(self, Add):
            if l.is_effectively_constant(0.0, eps):
                return r
            if r.is_effectively_constant(0.0, eps):
                return l

            # Case C1 + (x + C2) -> x + (C1 + C2)
            if isinstance(l, (Constant, OptimizableConstant)) and isinstance(r, Add):
                if isinstance(r.right, (Constant, OptimizableConstant)):
                    return Add(r.left, Constant(l.value + r.right.value)).simplify(eps)
                if isinstance(r.left, (Constant, OptimizableConstant)):
                    return Add(r.right, Constant(l.value + r.left.value)).simplify(eps)

            # Case (x + C1) + C2 -> x + (C1 + C2)
            if isinstance(l, Add) and isinstance(r, (Constant, OptimizableConstant)):
                if isinstance(l.right, (Constant, OptimizableConstant)):
                    return Add(l.left, Constant(l.right.value + r.value)).simplify(eps)
                if isinstance(l.left, (Constant, OptimizableConstant)):
                    return Add(l.right, Constant(l.left.value + r.value)).simplify(eps)

            if l == r and not isinstance(l, (Constant, OptimizableConstant)):
                return Mul(Constant(2.0), l).simplify(eps)

        # Sub
        elif isinstance(self, Sub):
            if r.is_effectively_constant(0.0, eps):
                return l
            if l.is_effectively_constant(0.0, eps):
                from .grammar import Neg
                return Neg(r).simplify(eps)
            if l == r:
                return Constant(0.0)

        # Mul
        elif isinstance(self, Mul):
            if l.is_effectively_constant(0.0, eps) or r.is_effectively_constant(0.0, eps):
                return Constant(0.0)
            if l.is_effectively_constant(1.0, eps):
                return r
            if r.is_effectively_constant(1.0, eps):
                return l
            if l.is_effectively_constant(-1.0, eps):
                from .grammar import Neg
                return Neg(r).simplify(eps)
            if r.is_effectively_constant(-1.0, eps):
                from .grammar import Neg
                return Neg(l).simplify(eps)

            # Case C1 * (x * C2) -> x * (C1 * C2)
            if isinstance(l, (Constant, OptimizableConstant)) and isinstance(r, Mul):
                if isinstance(r.right, (Constant, OptimizableConstant)):
                    return Mul(r.left, Constant(l.value * r.right.value)).simplify(eps)
                if isinstance(r.left, (Constant, OptimizableConstant)):
                    return Mul(r.right, Constant(l.value * r.left.value)).simplify(eps)

            # Case (x * C1) * C2 -> x * (C1 * C2)
            if isinstance(l, Mul) and isinstance(r, (Constant, OptimizableConstant)):
                if isinstance(l.right, (Constant, OptimizableConstant)):
                    return Mul(l.left, Constant(l.right.value * r.value)).simplify(eps)
                if isinstance(l.left, (Constant, OptimizableConstant)):
                    return Mul(l.right, Constant(l.left.value * r.value)).simplify(eps)
            
            # Case C1 * (x * C2) -> x * (C1 * C2)
            if isinstance(l, (Constant, OptimizableConstant)) and isinstance(r, Mul) and isinstance(r.right, (Constant, OptimizableConstant)):
                try:
                    c1 = l.value if hasattr(l, "value") else 0.0
                    c2 = r.right.value if hasattr(r.right, "value") else 0.0
                    return Mul(r.left, Constant(c1 * c2)).simplify(eps)
                except: pass

            # Case C1 * (C2 * x) -> x * (C1 * C2)
            if isinstance(l, (Constant, OptimizableConstant)) and isinstance(r, Mul) and isinstance(r.left, (Constant, OptimizableConstant)):
                try:
                    c1 = l.value if hasattr(l, "value") else 0.0
                    c2 = r.left.value if hasattr(r.left, "value") else 0.0
                    return Mul(r.right, Constant(c1 * c2)).simplify(eps)
                except: pass

            if l == r and not isinstance(l, (Constant, OptimizableConstant)):
                return Square(l).simplify(eps)

        # Div
        elif isinstance(self, Div):
            if r.is_effectively_constant(1.0, eps):
                return l
            if r.is_effectively_constant(-1.0, eps):
                from .grammar import Neg
                return Neg(l).simplify(eps)
            if r.is_effectively_constant(0.0, eps):
                return Constant(1.0)
            
            # Associative Grouping: (x * C1) / C2 -> x * (C1 / C2)
            if isinstance(l, Mul) and isinstance(l.right, (Constant, OptimizableConstant)) and isinstance(r, (Constant, OptimizableConstant)):
                try:
                    c1 = l.right.value if hasattr(l.right, "value") else 0.0
                    c2 = r.value if hasattr(r, "value") else 1.0
                    if abs(c2) > eps:
                        return Mul(l.left, Constant(c1 / c2)).simplify(eps)
                except: pass

            if l.is_effectively_constant(0.0, eps):
                return Constant(0.0)
            if l == r:
                return Constant(1.0)

        return self


# --- Boolean Binary Operators ---
class AND(BinaryOperator):
    def evaluate(self, X):
        return self.left.evaluate(X) * self.right.evaluate(X)

    def __str__(self):
        return f"({self.left} AND {self.right})"


class OR(BinaryOperator):
    def evaluate(self, X):
        # Probabilistic OR: 1 - (1-A)(1-B) or Max(A, B)
        # Using Max for fuzzy logic consistency or smooth approx
        l = self.left.evaluate(X)
        r = self.right.evaluate(X)
        return np.maximum(l, r)

    def __str__(self):
        return f"({self.left} OR {self.right})"


class Min(BinaryOperator):
    def evaluate(self, X):
        return np.minimum(self.left.evaluate(X), self.right.evaluate(X))

    def __str__(self):
        return f"min({self.left}, {self.right})"


class Max(BinaryOperator):
    def evaluate(self, X):
        return np.maximum(self.left.evaluate(X), self.right.evaluate(X))

    def __str__(self):
        return f"max({self.left}, {self.right})"


# --- Math Binary Operators ---
class Add(BinaryOperator):
    def evaluate(self, X):
        return self.left.evaluate(X) + self.right.evaluate(X)

    def __str__(self):
        return f"({self.left} + {self.right})"


class Sub(BinaryOperator):
    def evaluate(self, X):
        return self.left.evaluate(X) - self.right.evaluate(X)

    def __str__(self):
        return f"({self.left} - {self.right})"


class Mul(BinaryOperator):
    def evaluate(self, X):
        return self.left.evaluate(X) * self.right.evaluate(X)

    def __str__(self):
        return f"({self.left} * {self.right})"


class Div(BinaryOperator):
    def evaluate(self, X):
        denom = self.right.evaluate(X)
        denom_safe = np.where(np.abs(denom) < 1e-6, np.sign(denom + 1e-9) * 1e-6, denom)
        return self.left.evaluate(X) / denom_safe

    def __str__(self):
        return f"({self.left} / {self.right})"


class Pow(BinaryOperator):
    def evaluate(self, X):
        base = self.left.evaluate(X)
        exponent = self.right.evaluate(X)
        # Safe Pow: handle negative base by taking Abs (traditional in SR)
        # and clip exponent to avoid huge values.
        base_safe = np.abs(base) + 1e-9
        exp_safe = np.clip(exponent, -10, 10)
        return np.power(base_safe, exp_safe)

    def __str__(self):
        return f"({self.left})^{{{self.right}}}"


# --- Ternary Operators ---


class TernaryOperator(Node):
    def __init__(self, child1, child2, child3):
        self.child1 = child1
        self.child2 = child2
        self.child3 = child3

    @property
    def children(self):
        return [self.child1, self.child2, self.child3]

    @property
    def size(self):
        return 1 + self.child1.size + self.child2.size + self.child3.size

    @property
    def depth(self):
        return 1 + max(self.child1.depth, self.child2.depth, self.child3.depth)

    def __repr__(self):
        return f"{self.__class__.__name__}({repr(self.child1)}, {repr(self.child2)}, {repr(self.child3)})"

    def _eq(self, other):
        return self.child1 == other.child1 and self.child2 == other.child2 and self.child3 == other.child3

    def freeze_constants(self):
        self.child1 = self.child1.freeze_constants()
        self.child2 = self.child2.freeze_constants()
        self.child3 = self.child3.freeze_constants()
        return self

    def simplify(self, eps=1e-9):
        self.child1 = self.child1.simplify(eps)
        self.child2 = self.child2.simplify(eps)
        self.child3 = self.child3.simplify(eps)

        cond = self.child1
        t = self.child2
        f = self.child3

        # If true and false branches are equal, condition doesn't matter
        if t == f:
            return t

        # If condition is constant
        if isinstance(cond, Constant):
            if cond.value > 0.5:  # True
                return t
            else:  # False
                return f

        return self


class SoftIf(TernaryOperator):
    def __init__(self, cond, true_branch, false_branch):
        super().__init__(cond, true_branch, false_branch)

    def evaluate(self, X):
        c = self.child1.evaluate(X)
        t = self.child2.evaluate(X)
        f = self.child3.evaluate(X)
        # c is expected to be [0, 1] probability from Sigmoid Threshold/Interval
        return c * t + (1.0 - c) * f

    def __str__(self):
        return f"If({self.child1}, then={self.child2}, else={self.child3})"


# --- Unary Operators ---
class UnaryOperator(Node):
    def __init__(self, child):
        self.child = child

    @property
    def children(self):
        return [self.child]

    @property
    def size(self):
        return 1 + self.child.size

    @property
    def depth(self):
        return 1 + self.child.depth

    def __repr__(self):
        return f"{self.__class__.__name__}({repr(self.child)})"

    def _eq(self, other):
        return self.child == other.child

    def freeze_constants(self):
        self.child = self.child.freeze_constants()
        return self

    def simplify(self, eps=1e-9):
        # 1. Recursive
        self.child = self.child.simplify(eps)

        # 2. Constant Folding
        if isinstance(self.child, Constant):
            try:
                dummy_X = np.zeros((1, 1))
                val = self.evaluate(dummy_X)[0]
                if abs(val) < 1e-9:
                    val = 0.0  # Normalize -0.0 to 0.0
                return Constant(val)
            except:
                pass

        # NOT(NOT(x)) -> x
        if isinstance(self, NOT) and isinstance(self.child, NOT):
            return self.child.child

        # Abs(Neg(x)) -> Abs(x)
        if isinstance(self, Abs) and isinstance(self.child, Neg):
            return Abs(self.child.child).simplify()

        # Neg(Neg(x)) -> x
        if isinstance(self, Neg) and isinstance(self.child, Neg):
            return self.child.child

        # Neg(0) -> 0
        if isinstance(self, Neg) and isinstance(self.child, Constant) and abs(self.child.value) < 1e-9:
            return Constant(0.0)

        # Sqrt(Square(x)) -> Abs(x)
        if isinstance(self, Sqrt) and isinstance(self.child, Square):
            return Abs(self.child.child).simplify()

        # Log(Exp(x)) -> x
        if isinstance(self, Log) and isinstance(self.child, Exp):
            return self.child.child
        # Exp(Log(x)) -> x
        if isinstance(self, Exp) and isinstance(self.child, Log):
            return self.child.child
        # Abs(Abs(x)) -> Abs(x)
        if isinstance(self, Abs) and isinstance(self.child, Abs):
            return self.child
        # Abs(Square(x)) -> Square(x)
        if isinstance(self, Abs) and isinstance(self.child, Square):
            return self.child

        return self


# --- Boolean Unary Operators ---
class NOT(UnaryOperator):
    def evaluate(self, X):
        return 1.0 - self.child.evaluate(X)

    def __str__(self):
        return f"NOT({self.child})"


# --- Math Unary Operators ---
class Sin(UnaryOperator):
    def evaluate(self, X):
        return np.sin(self.child.evaluate(X))

    def __str__(self):
        return f"sin({self.child})"


class Cos(UnaryOperator):
    def evaluate(self, X):
        return np.cos(self.child.evaluate(X))

    def __str__(self):
        return f"cos({self.child})"


class Exp(UnaryOperator):
    def evaluate(self, X):
        val = self.child.evaluate(X)
        val = np.clip(val, -10, 10)  # Clip for overflow safety
        return np.exp(val)

    def __str__(self):
        return f"exp({self.child})"


class Log(UnaryOperator):
    def evaluate(self, X):
        val = np.abs(self.child.evaluate(X)) + 1e-6
        return np.log(val)

    def __str__(self):
        return f"log(|{self.child}|)"


class Sqrt(UnaryOperator):
    def evaluate(self, X):
        val = np.abs(self.child.evaluate(X))
        return np.sqrt(val)

    def __str__(self):
        return f"sqrt(|{self.child}|)"


class Abs(UnaryOperator):
    def evaluate(self, X):
        return np.abs(self.child.evaluate(X))

    def __str__(self):
        return f"|{self.child}|"


class Square(UnaryOperator):
    def evaluate(self, X):
        return np.square(self.child.evaluate(X))

    def __str__(self):
        return f"({self.child})^2"


class Cube(UnaryOperator):
    def evaluate(self, X):
        return np.power(self.child.evaluate(X), 3)

    def __str__(self):
        return f"({self.child})^3"


class Neg(UnaryOperator):
    def evaluate(self, X):
        return -self.child.evaluate(X)

    def __str__(self):
        return f"-({self.child})"


# --- Literals ---


class Literal(Node):
    @property
    def size(self):
        return 1

    @property
    def depth(self):
        return 1

    @property
    def children(self):
        return []


# --- Math Literals ---
class Variable(Literal):
    def __init__(self, index):
        self.index = index

    def evaluate(self, X):
        return X[:, self.index]

    def __str__(self):
        return f"x{self.index}"

    def __repr__(self):
        return f"Variable({self.index})"

    def _eq(self, other):
        return self.index == other.index


class Constant(Literal):
    def __init__(self, value):
        self.value = value

    def evaluate(self, X):
        return np.full(len(X), self.value)

    def __str__(self):
        try:
            return f"{float(self.value):.3f}"
        except (TypeError, ValueError):
            return str(self.value)

    def __float__(self):
        return float(self.value)

    def __repr__(self):
        return f"Constant({self.value})"

    def _eq(self, other):
        # Use simple epsilon check for constants? Or exact?
        # For simplify x-x=0, exact might be needed or eps.
        return abs(self.value - other.value) < 1e-9


class OptimizableConstant(Literal):
    """
    Acts like a Constant, but its value is meant to be optimized per-tree.
    Initializing value can be random, then 'evaluate' returns optimized value.
    The optimization logic (memetic algorithm) will traverse the tree,
    find these nodes, optimize them, and then replace them with frozen 'Constants'.
    """

    def __init__(self, value):
        try:
            self.value = float(value)
        except (TypeError, ValueError):
            self.value = value

    def evaluate(self, X):
        return np.full(len(X), self.value)

    def __str__(self):
        try:
            return f"Opt({float(self.value):.3f})"
        except (TypeError, ValueError):
            return f"Opt({self.value})"

    def __float__(self):
        return float(self.value)

    def __repr__(self):
        return f"OptimizableConstant({self.value})"

    def _eq(self, other):
        return abs(self.value - other.value) < 1e-9

    def freeze_constants(self):
        """Convert this optimizable constant into a fixed Constant."""
        from .grammar import Constant

        return Constant(self.value)


# --- Boolean Literals ---


class Threshold(Literal):
    def __init__(self, feature, val, op, sharpness=1.0):
        self.feature = feature
        self.val = val
        self.op = op  # 0 for >, 1 for <
        self.sharpness = sharpness

    def evaluate(self, X):
        col = X[:, self.feature]
        # Learnable sharpness
        logit = self.sharpness * (col - self.val)
        if self.op == 1:  # < val
            logit = -logit  # sharpness * (val - x)

        # Clamp exponent to avoid overflow.
        return 1.0 / (1.0 + np.exp(np.clip(-logit, -100, 100)))

    def __str__(self):
        sym = ">" if self.op == 0 else "<"
        s_str = f" (sharp={self.sharpness:.1f})" if self.sharpness > 1.5 else ""
        return f"X[{self.feature}] {sym} {self.val:.2f}{s_str}"

    def __repr__(self):
        return f"Threshold({self.feature}, {self.val}, {self.op}, {self.sharpness})"


class Interval(Literal):
    def __init__(self, feature, low, high, sharpness=1.0):
        self.feature = feature
        self.low = min(low, high)
        self.high = max(low, high)
        self.sharpness = sharpness

    def evaluate(self, X):
        col = X[:, self.feature]
        # sigmoid(x - low) * sigmoid(high - x)
        act_low = 1.0 / (1.0 + np.exp(np.clip(-self.sharpness * (col - self.low), -100, 100)))
        act_high = 1.0 / (1.0 + np.exp(np.clip(-self.sharpness * (self.high - col), -100, 100)))
        return act_low * act_high

    def __str__(self):
        s_str = f" (sharp={self.sharpness:.1f})" if self.sharpness > 1.5 else ""
        return f"{self.low:.2f} < X[{self.feature}] < {self.high:.2f}{s_str}"

    def __repr__(self):
        return f"Interval({self.feature}, {self.low}, {self.high}, {self.sharpness})"


class Ratio(Literal):
    def __init__(self, feat_a, feat_b, threshold, sharpness=1.0):
        self.feat_a = feat_a
        self.feat_b = feat_b
        self.threshold = threshold
        self.sharpness = sharpness

    def evaluate(self, X):
        # Avoid div by zero
        val_a = X[:, self.feat_a]
        val_b = X[:, self.feat_b] + 1e-6
        ratio = val_a / val_b

        # ratio > threshold
        logit = self.sharpness * (ratio - self.threshold)
        return 1.0 / (1.0 + np.exp(np.clip(-logit, -100, 100)))

    def __str__(self):
        return f"(X[{self.feat_a}]/X[{self.feat_b}]) > {self.threshold:.2f}"

    def __repr__(self):
        return f"Ratio({self.feat_a}, {self.feat_b}, {self.threshold}, {self.sharpness})"


class Gaussian(Literal):
    def __init__(self, feature, mu, sigma):
        self.feature = feature
        self.mu = mu
        self.sigma = sigma + 1e-3  # ensure positive

    def evaluate(self, X):
        col = X[:, self.feature]
        # exp( - (x-mu)^2 / 2sigma^2 )
        return np.exp(-0.5 * ((col - self.mu) / self.sigma) ** 2)

    def __str__(self):
        return f"Gauss(X[{self.feature}], mu={self.mu:.2f})"

    def __repr__(self):
        # Note: we stored sigma+1e-3, but init expects original sigma usually?
        # Actually our init adds +1e-3. If we reconstruct, we might add it again.
        # Ideally we store 'clean' params. But here sigma is state.
        # Let's just return current sigma. The constructor will add 1e-3 again?
        # Check constructor: self.sigma = sigma + 1e-3
        # If we return current sigma, next time it will be sigma + 2e-3.
        # For this verification, it's fine.
        return f"Gaussian({self.feature}, {self.mu}, {self.sigma})"
