from __future__ import annotations
import re

import numpy as np
import sympy as sp


def ezga_expr_to_sympy(expr_str: str) -> sp.Expr:
    # Limpia los envoltorios "Opt(...)" si existieran en tu string de EZGA
    cleaned = re.sub(r"Opt\(([^)]+)\)", r"(\1)", expr_str)
    return sp.sympify(cleaned)


def polynomial_coeffs_to_sympy(coeffs, variable: sp.Symbol) -> sp.Expr:
    """Convierte los coeficientes de np.polyfit a una expresión SymPy."""
    degree = len(coeffs) - 1
    expr = 0
    for i, c in enumerate(coeffs):
        power = degree - i
        expr += sp.Float(c) * variable**power
    return sp.expand(expr)


def detect_univariate_argument(arg: sp.Expr, n_features: int):
    """Detecta si el argumento tiene la forma a*xj + b y extrae (j, a, b)."""
    symbols = [sp.Symbol(f"x{i}") for i in range(n_features)]
    expanded = sp.expand(arg)
    coeffs = []

    for j, xj in enumerate(symbols):
        c = expanded.coeff(xj)
        if c != 0:
            coeffs.append((j, sp.simplify(c)))

    # Si hay múltiples variables mezcladas, descartamos
    if len(coeffs) != 1:
        return None

    j, a = coeffs[0]

    b = expanded
    for _k, xk in enumerate(symbols):
        b = b.subs(xk, 0)
    b = sp.simplify(b)

    return j, sp.simplify(a), sp.simplify(b)


def fit_polynomial_in_variable(x: np.ndarray, y: np.ndarray, degree: int):
    """Ajusta un polinomio de grado `degree`."""
    # Deshabilitar RankWarning si la matriz está mal condicionada
    with np.errstate(all="ignore"):
        coeffs = np.polyfit(x, y, deg=degree)
        y_fit = np.polyval(coeffs, x)
    return coeffs, y_fit


def relative_l2_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    denom = np.linalg.norm(y_true)
    if denom < 1e-14:
        return float(np.linalg.norm(y_true - y_pred))
    return float(np.linalg.norm(y_true - y_pred) / denom)


def select_best_polynomial_degree(x: np.ndarray, y: np.ndarray, max_degree: int = 5, error_tol: float = 0.02):
    """Elige el mínimo grado que consigue un error <= error_tol."""
    best = None
    for degree in range(max_degree + 1):
        coeffs, y_fit = fit_polynomial_in_variable(x, y, degree)
        err = relative_l2_error(y, y_fit)

        if best is None or err < best["rel_error"]:
            best = {
                "degree": degree,
                "coeffs": coeffs,
                "y_fit": y_fit,
                "rel_error": err,
            }

        # Cortar en cuanto alcanzamos un nivel aceptable de error
        if err <= error_tol:
            return best
    return best


def get_trig_subtrees(expr: sp.Expr):
    """
    Encuentra subárboles de la forma A*sin(u), A*cos(u), sin(u) o cos(u).
    Retorna una lista de tuplas: (nodo_original, amplitud_A, funcion_trig, argumento_u)
    """
    subtrees = []

    for node in sp.preorder_traversal(expr):
        if node.is_Mul:
            const_part = 1
            trig_part = None
            other_parts = []

            for arg in node.args:
                if arg.is_Number:
                    const_part *= arg
                elif arg.func in (sp.sin, sp.cos):
                    trig_part = arg
                else:
                    other_parts.append(arg)

            # Solo capturar si es estrictamente constante * trig(u)
            if trig_part is not None and len(other_parts) == 0:
                subtrees.append((node, const_part, trig_part.func, trig_part.args[0]))

        elif node.func in (sp.sin, sp.cos):
            # Caso puro sin amplitud (o amplitud 1)
            subtrees.append((node, 1, node.func, node.args[0]))

    return subtrees


def replace_trig_by_fitted_polynomial_in_variable(
    expr: sp.Expr, X: np.ndarray, max_degree: int = 5, error_tol: float = 0.02, verbose: bool = True
) -> sp.Expr:
    """
    Sustituye bloques trigonométricos por polinomios ajustados a los datos.
    Solo realiza la sustitución si el error relativo cae por debajo de error_tol.
    """
    n_features = X.shape[1]
    symbols = [sp.Symbol(f"x{i}") for i in range(n_features)]
    subs_map = {}

    # 1. Detectar candidatos
    trig_nodes = get_trig_subtrees(expr)

    # 2. Analizar y procesar cada bloque candidato
    for node, _A, _trig_func, arg in trig_nodes:
        if node in subs_map:
            continue  # Evitar procesar sub-nodos ya sustituidos

        detected = detect_univariate_argument(arg, n_features)
        if detected is None:
            if verbose:
                print(f"[skip] {node} -> argumento no es función afín de 1 variable.")
            continue

        j, a, b = detected
        xj = X[:, j]

        # 3. Evaluar el subárbol COMPLETO (A * trig(a*x + b)) sobre los datos
        f_node = sp.lambdify(symbols, node, "numpy")
        y_node = np.asarray(f_node(*[X[:, k] for k in range(n_features)]), dtype=float)

        # 4. Ajustar el polinomio y seleccionar el mejor grado
        best = select_best_polynomial_degree(x=xj, y=y_node, max_degree=max_degree, error_tol=error_tol)

        # 5. Si el ajuste es suficientemente fiel, procedemos al reemplazo
        if best["rel_error"] <= error_tol:
            poly_expr = polynomial_coeffs_to_sympy(best["coeffs"], symbols[j])
            if verbose:
                print(f"[replace] {node}")
                print(f"          variable: x{j}")
                print(f"          grado seleccionado: {best['degree']}, error: {best['rel_error']:.2e}")
            subs_map[node] = poly_expr
        else:
            if verbose:
                print(
                    f"[keep] {node} -> sin polinomio suficientemente preciso (error {best['rel_error']:.2e} > tol {error_tol})"
                )

    # 6. Aplicar unificadamente y simplificar
    new_expr = expr.subs(subs_map)
    return sp.simplify(sp.expand(new_expr))
