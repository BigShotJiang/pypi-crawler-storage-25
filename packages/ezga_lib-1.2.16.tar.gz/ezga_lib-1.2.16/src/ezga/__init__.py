from __future__ import annotations
"""Public API of EZGA – Evolutionary Structure Explorer.

Import the main high-level facade here:
    >>> from ezga import QuickGA

Or the core components if you need more control:
    >>> from ezga import GAConfig, load_config, build_default_engine
"""

try:
    from importlib.metadata import version

    __version__ = version("ezga-lib")
except Exception:  # pragma: no cover
    __version__ = "1.0.5"

__all__ = [
    "__version__",
    "QuickGA",
    "GAConfig",
    "GeneticAlgorithm",
    "load_config",
    "build_default_engine",
    "MultiTargetSymbolicRegressor",
    # Sub-packages
    "variation",
    "evaluator",
    "simulator",
    "selection",
    "core",
    "utils",
    "DoE",
]


def __getattr__(name):
    # Shortcuts / Aliases
    if name == "mutations":
        import ezga.variation as variation
        return variation
    if name == "objectives":
        import ezga.evaluator as evaluator
        return evaluator
    if name == "calculators":
        import ezga.simulator as simulator
        return simulator

    # Existing core components
    if name == "QuickGA":
        from .quick_ga import QuickGA
        return QuickGA
    if name == "MultiTargetSymbolicRegressor":
        from .simple.symbolic_regression import MultiTargetSymbolicRegressor
        return MultiTargetSymbolicRegressor
    if name == "GAConfig":
        from .core.config import GAConfig
        return GAConfig
    if name == "GeneticAlgorithm":
        from .core.engine import GeneticAlgorithm
        return GeneticAlgorithm
    if name == "load_config":
        from .factory import load_config
        return load_config
    if name == "build_default_engine":
        from .factory import build_default_engine
        return build_default_engine

    # Fallback for subpackages
    try:
        import importlib
        return importlib.import_module(f".{name}", __name__)
    except ImportError:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
