from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from .core.config import GAConfig
from .core.engine import GeneticAlgorithm
from .factory import build_default_engine, load_config


class QuickGA:
    """
    A high-level facade for EZGA designed for simplicity and ease of use.

    QuickGA allows defining and running a Genetic Algorithm experiment with
    minimal boilerplate, using sensible defaults and shorthand string aliases
    for common components.
    """

    def __init__(
        self,
        composition: list[str],
        initial_structure: str | Path | None = None,
        calculator: str | Any = "lj",
        mace_model_path: str | None = None,
        max_generations: int = 50,
        output_path: str = "runs/quick_ga",
        seed: int | None = None,
        **kwargs,
    ):
        """
        Initialize a QuickGA experiment.

        Args:
            composition: List of atomic symbols (e.g., ["Ni", "O"]).
            initial_structure: Path to an initial XYZ or POSCAR file to seed the population.
            calculator: Shorthand string (e.g., "lj", "emt", "mace") or an ASE calculator instance.
            mace_model_path: Path to a MACE model file (required if calculator="mace").
            max_generations: Maximum number of generations to run.
            output_path: Directory to save results.
            seed: Random seed for reproducibility.
            **kwargs: Additional configuration parameters to override defaults.
        """
        self.composition = composition
        self.output_path = output_path

        # Determine unique species in composition for features and constraints
        unique_species = sorted(list(set(composition)))

        # Build the base config dictionary
        # Simple shorthand for MACE if a path is provided
        if calculator == "mace" and mace_model_path:
            calculator = f"mace:{mace_model_path}"

        self.cfg_dict = {
            "max_generations": max_generations,
            "output_path": output_path,
            "rng": seed,
            "foreigners": kwargs.pop("foreigners", 10),  # Default to 10 random structures per gen if empty
            "simulator": {"calculator": calculator},
            "population": {
                "filter_duplicates": True,
                "dataset_path": initial_structure,
            },
            "generative": {
                "size": kwargs.pop("foreigners", 10),  # Default to 10 random structures per gen if empty
                "start_gen": 0,
                "bo_kwargs": {
                    "bounds": np.array([[0.0, float(len(composition))] for _ in unique_species]),
                },
            },
            "mutation_funcs": kwargs.pop("mutation_funcs", ["rattle", "swap", "add", "remove"]),
            "evaluator": {
                "features_funcs": [
                    {
                        "factory": "ezga.evaluator.features:feature_composition_vector",
                        "kwargs": {"IDs": unique_species},
                    }
                ]
            },
            **kwargs,
        }

        # Ensure composition is mapped for constraints if using Grand Canonical
        # (This is a common pain point for users)
        from .DoE.constraint import ConstraintFactory

        ConstraintFactory.set_name_mapping({s: i for i, s in enumerate(unique_species)})

        # Internal state
        self._config: GAConfig | None = None
        self._engine: GeneticAlgorithm | None = None

    @property
    def config(self):
        """Lazy-loaded GAConfig."""
        if self._config is None:
            self._config = load_config(self.cfg_dict)
        return self._config

    @property
    def engine(self) -> GeneticAlgorithm:
        """Lazy-loaded GeneticAlgorithm engine."""
        if self._engine is None:
            self._engine = build_default_engine(self.config)
        return self._engine

    def run(self) -> Any:
        """
        Run the evolution.

        Returns:
            The final population or result of the evolution.
        """
        return self.engine.run()

    def __repr__(self) -> str:
        return f"<QuickGA system={self.composition} out={self.output_path}>"
