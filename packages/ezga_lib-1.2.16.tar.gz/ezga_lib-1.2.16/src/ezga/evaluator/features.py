from __future__ import annotations
import numpy as np
import logging
from pathlib import Path
from typing import Any
from scipy.spatial import ConvexHull
from scipy.spatial.distance import pdist

logger = logging.getLogger(__name__)


def evaluate_features(structures, features_funcs):
    """
    Evaluates the given list of structures using a user-supplied feature extractor function.

    Parameters
    ----------
    structures : list
        List of structures to evaluate.
    features_funcs : callable
        A function or callable that, given a list of structures,
        returns an (N, D) array of features.

    Returns
    -------
    np.ndarray
        (N, D) array of feature vectors, one row per structure.
    """
    return np.array([features_funcs(structure) for structure in structures])


# ------------------------------------------------------------
# Composition Vector Feature
# ------------------------------------------------------------
def feature_composition_vector(IDs):
    """
    Returns a function that computes the composition vector for a given structure.
    The vector contains counts for each unique atom label present in the structure.

    Returns
    -------
    callable
        A function that accepts a structure and returns a 1D numpy array with the atom counts.
    """

    def get_feature_index_map():
        return {label: idx for idx, label in enumerate(IDs)}

    def compute(dataset):

        M, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")
        
        # Build index array for requested IDs; -1 means "missing"
        idx = np.fromiter((mapping.get(lbl, -1) for lbl in IDs), dtype=int, count=len(IDs))
        valid = idx >= 0

        counts = np.zeros((M.shape[0], len(IDs)), dtype=M.dtype)
        if np.any(valid):
            counts[:, valid] = M[:, idx[valid]]

        return counts

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "linear")

    return compute


def feature_total_atoms():
    """
    For each structure, returns the total number of atoms.

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 1)
    """

    def get_feature_index_map():
        return {"N": 0}

    def compute(dataset):
        # Optimization: use get_atom_counts if available
        if hasattr(dataset, "get_atom_counts"):
            try:
                counts = dataset.get_atom_counts()
                return np.asarray(counts).reshape(-1, 1).astype(float)
            except Exception as e:
                logger.warning(f"[feature_total_atoms] Fast get_atom_counts failed: {e}. Trying bulk compositions...")

        # Second optimization: use bulk compositions
        if hasattr(dataset, "get_all_compositions"):
            try:
                M = dataset.get_all_compositions(return_species=False)
                return M.sum(axis=1).reshape(-1, 1).astype(float)
            except Exception as e:
                logger.warning(f"[feature_total_atoms] Fast get_all_compositions failed: {e}. Falling back to slow iteration...")

        # Fallback: iterative access
        n = len(dataset)
        out = np.zeros((n, 1), dtype=float)
        for i in range(n):
            try:
                entry = dataset[i]
                # Unpack assuming (positions, lattice, _, elements, ...)
                if isinstance(entry, (list, tuple)) and len(entry) >= 4:
                    out[i, 0] = float(len(entry[3]))
                elif hasattr(entry, "AtomPositionManager"):
                    out[i, 0] = float(entry.AtomPositionManager.atomCount)
            except Exception:
                out[i, 0] = 0.0
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "linear")
    return compute


def feature_unique_atom_count():
    """
    For each structure, returns the number of unique element types.

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 1)
    """

    def get_feature_index_map():
        return {"N": 0}

    def compute(dataset):
        # Optimization: use bulk compositions if available
        if hasattr(dataset, "get_all_compositions"):
            try:
                M = dataset.get_all_compositions(return_species=False)
                return (M > 0).sum(axis=1).reshape(-1, 1).astype(float)
            except Exception as e:
                logger.warning(f"[feature_unique_atom_count] Fast get_all_compositions failed: {e}. Falling back to slow iteration...")

        n = len(dataset)
        out = np.zeros((n, 1), dtype=float)
        for i in range(n):
            try:
                entry = dataset[i]
                if isinstance(entry, (list, tuple)) and len(entry) >= 4:
                    elements = entry[3]
                    out[i, 0] = float(len(np.unique(elements)))
                elif hasattr(entry, "AtomPositionManager"):
                    # Fallback to APM if available
                    apm = entry.AtomPositionManager
                    if hasattr(apm, "get_elements"):
                        out[i, 0] = float(len(np.unique(apm.get_elements())))
                    else:
                        out[i, 0] = float(len(apm.atomCountDict))
            except Exception:
                out[i, 0] = 0.0
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "invariant")
    return compute


def feature_average_interatomic_distance():
    """
    For each structure, computes the average pairwise Euclidean distance
    between atoms.

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 1)
    """

    def get_feature_index_map():
        return {"avg_d": 0}

    def compute(dataset):
        n = len(dataset)
        out = np.zeros((n, 1), dtype=float)
        for i in range(n):
            positions, *_ = dataset[i]
            if positions.shape[0] < 2:
                out[i, 0] = 0.0
            else:
                dists = pdist(positions, metric="euclidean")
                out[i, 0] = float(np.mean(dists))
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "invariant")
    return compute


def feature_radius_of_gyration():
    """
    For each structure, computes the radius of gyration (R_g),
    defined as the RMS distance from the center of mass.

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 1)
    """

    def get_feature_index_map():
        return {"Rg": 0}

    def compute(dataset):
        n = len(dataset)
        out = np.zeros((n, 1), dtype=float)
        for i in range(n):
            positions, *_ = dataset[i]
            if positions.shape[0] == 0:
                out[i, 0] = 0.0
                continue
            com = np.mean(positions, axis=0)
            rg = np.sqrt(np.mean(np.sum((positions - com) ** 2, axis=1)))
            out[i, 0] = float(rg)
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "invariant")
    return compute


def feature_center_of_mass():
    """
    For each structure, computes the geometric center of mass (simple
    average of atomic positions; no mass weighting).

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 3)
    """

    def get_feature_index_map():
        return {"com_x": 0, "com_y": 1, "com_z": 2}

    def compute(dataset):
        # Optimization: use bulk positions if available
        if hasattr(dataset, "get_all_positions"):
            try:
                pos_list = dataset.get_all_positions(coordinate_system="cartesian")
                out = np.zeros((len(pos_list), 3), dtype=float)
                for i, pos in enumerate(pos_list):
                    if pos is not None and pos.shape[0] > 0:
                        out[i, :] = np.mean(pos, axis=0)
                return out
            except Exception as e:
                logger.warning(f"[feature_center_of_mass] Fast get_all_positions failed: {e}. Falling back to slow iteration...")

        n = len(dataset)
        out = np.zeros((n, 3), dtype=float)
        for i in range(n):
            try:
                entry = dataset[i]
                if isinstance(entry, (list, tuple)):
                    positions = entry[0]
                elif hasattr(entry, "AtomPositionManager"):
                    positions = entry.AtomPositionManager.atomPositions
                else:
                    continue

                if positions.shape[0] > 0:
                    out[i, :] = np.mean(positions, axis=0)
            except Exception:
                pass
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "invariant")
    return compute


def feature_minimum_interatomic_distance():
    """
    For each structure, computes the minimum interatomic distance.

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 1)
    """

    def get_feature_index_map():
        return {"d_min": 0}

    def compute(dataset):
        n = len(dataset)
        out = np.zeros((n, 1), dtype=float)
        for i in range(n):
            positions, *_ = dataset[i]
            if positions.shape[0] < 2:
                out[i, 0] = 0.0
            else:
                dists = pdist(positions, metric="euclidean")
                out[i, 0] = float(np.min(dists))
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "invariant")
    return compute


def feature_convex_hull_volume():
    """
    For each structure, computes the volume of the convex hull of atomic
    positions. If the points are coplanar/collinear or hull construction
    fails, returns 0.

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 1)
    """

    def get_feature_index_map():
        return {"V_hull": 0}

    def compute(dataset):
        n = len(dataset)
        out = np.zeros((n, 1), dtype=float)
        for i in range(n):
            positions, *_ = dataset[i]
            if positions.shape[0] < 4:
                out[i, 0] = 0.0
                continue
            try:
                hull = ConvexHull(positions)
                out[i, 0] = float(hull.volume)
            except Exception:
                out[i, 0] = 0.0
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "linear")
    return compute


def feature_cell_volume():
    """
    For each structure, computes the volume of the simulation cell as
    |det(lattice)|, where lattice is a 3x3 matrix of lattice vectors.

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 1)
    """

    def get_feature_index_map():
        return {"V_cell": 0}

    def compute(dataset):
        # Optimization: use bulk lattice vectors if available
        if hasattr(dataset, "get_all_lattice_vectors"):
            try:
                lattices = np.asarray(dataset.get_all_lattice_vectors())
                if lattices.ndim == 3:
                    return np.abs(np.linalg.det(lattices)).reshape(-1, 1)
            except Exception as e:
                logger.warning(f"[feature_cell_volume] Fast get_all_lattice_vectors failed: {e}. Falling back to slow iteration...")

        n = len(dataset)
        out = np.zeros((n, 1), dtype=float)
        for i in range(n):
            try:
                entry = dataset[i]
                lattice = entry[1] if isinstance(entry, (list, tuple)) else entry.AtomPositionManager.latticeVectors
                vol = float(abs(np.linalg.det(lattice)))
            except Exception:
                vol = 0.0
            out[i, 0] = vol
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "linear")
    return compute


def feature_motif_info(
    library_path: str | Path | None = None,
    match_threshold: float = 0.7,
    substrate_constraints: list | None = None,
    kind: str = "unique",
    **harvester_kwargs
):
    """
    Computes motif-related features for each structure using a lightweight detection engine.
    Atom exclusion is handled automatically via the structure's atomic constraints.

    If library_path is provided, the feature will only count motifs that structurally 
    match those in the specified library (using RDF similarity).

    Kinds:
    - 'total': Total number of motifs detected (or matched). (Scaling: linear)
    - 'unique': Number of distinct motif families present. (Scaling: invariant)
    - 'coverage': Fraction of mobile atoms involved in motifs. (Scaling: invariant)

    Parameters
    ----------
    library_path : str or Path, optional
        Path to a .json MotifLibrary. If set, only motifs matching the library are counted.
    match_threshold : float, default 0.7
        RDF similarity threshold to consider a motif as a match to the library.
    substrate_constraints : list, optional
        Custom functions to exclude atoms (e.g. lambda idx, struct: ...).
    kind : str, default 'unique'
        The specific motif metric to return.
    **harvester_kwargs : dict
        Any other parameter accepted by MotifHarvester (min_atoms, bond_scale, etc.). 
        If a library is provided, its metadata will automatically populate these.
    """
    def get_feature_index_map():
        return {f"motif_{kind}": 0}

    def compute(dataset: Any) -> np.ndarray:
        from ezga.hise.motifs import MotifFamily, MotifHarvester, MotifLibrary
        
        _match_threshold = match_threshold
        _harvester_kwargs = harvester_kwargs.copy()

        # Load library if provided
        target_fams = None
        if library_path:
            lib = MotifLibrary(str(library_path))
            lib_motifs = lib.load()
            target_fams = lib_motifs
            
            if lib.metadata:
                _match_threshold = lib.metadata.get("match_threshold", _match_threshold)
                for k, v in lib.metadata.items():
                    if k != "match_threshold" and v is not None:
                        _harvester_kwargs[k] = v

        # Lightweight harvester for detection
        harvester = MotifHarvester(
            substrate_constraints=substrate_constraints,
            max_structures_to_analyze=len(dataset),
            early_stop=False,
            **_harvester_kwargs
        )
        
        n = len(dataset)
        results = np.zeros((n, 1), dtype=float)
        
        for i in range(n):
            try:
                struct = dataset[i]
                apm = getattr(struct, "AtomPositionManager", None)
                if apm is None: continue
                
                frags, is_excluded = harvester._get_fragments(struct)
                motifs = harvester._cluster_fragments(struct, frags, apm.latticeVectors)
                
                # Filter motifs by library if requested
                if target_fams:
                    matched_motifs = []
                    matched_ids = set()
                    for m in motifs:
                        # Temporary family to compute RDF
                        m_fam = MotifFamily(
                            id="tmp", formula="", labels=m["labels"], 
                            canonical_positions=m["pos"] # canonicalize inside harvester?
                        )
                        # We use canonicalize to get consistent orientation
                        _, canon_pos, canon_labels = harvester.canonicalize(m["pos"], m["labels"])
                        m_fam.canonical_positions = canon_pos
                        m_fam.labels = canon_labels
                        
                        # Check matches
                        best_sim = 0.0
                        best_id = None
                        for t in target_fams:
                            sim = harvester._motif_similarity(m_fam, t)
                            if sim > best_sim:
                                best_sim = sim
                                best_id = t.id
                        
                        if best_sim >= _match_threshold:
                            matched_motifs.append(m)
                            matched_ids.add(best_id)
                    
                    # Update active motif set for this structure
                    active_motifs = matched_motifs
                    active_count_unique = len(matched_ids)
                else:
                    active_motifs = motifs
                    # Compute unique count without library
                    unique_fams = set()
                    for m in motifs:
                        fp, _, _ = harvester.canonicalize(m["pos"], m["labels"])
                        unique_fams.add(fp)
                    active_count_unique = len(unique_fams)

                if kind == "total":
                    results[i, 0] = float(len(active_motifs))
                elif kind == "unique":
                    results[i, 0] = float(active_count_unique)
                elif kind == "coverage":
                    total_mobile = np.sum(~is_excluded)
                    if total_mobile == 0:
                        results[i, 0] = 0.0
                    else:
                        motif_atoms = set()
                        for m in active_motifs:
                            motif_atoms.update(m["indices"])
                        results[i, 0] = float(len(motif_atoms)) / total_mobile
            except Exception:
                results[i, 0] = 0.0
                
        return results

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "linear" if kind == "total" else "invariant")
    return compute


def feature_density():
    """
    For each structure, computes an approximate density defined as:
        ρ = N_atoms / V_cell

    Returns
    -------
    callable
        compute(dataset) -> shape (N_structures, 1)
    """

    def get_feature_index_map():
        return {"rho": 0}

    def compute(dataset):
        # Optimization: combine bulk atom counts and lattice vectors
        if hasattr(dataset, "get_all_lattice_vectors"):
            try:
                if hasattr(dataset, "get_atom_counts"):
                    N = np.asarray(dataset.get_atom_counts())
                elif hasattr(dataset, "get_all_compositions"):
                    M = dataset.get_all_compositions(return_species=False)
                    N = M.sum(axis=1)
                else:
                    raise AttributeError("No bulk atom count accessor")

                lattices = np.asarray(dataset.get_all_lattice_vectors())
                if lattices.ndim == 3:
                    vols = np.abs(np.linalg.det(lattices))
                    # Avoid division by zero
                    dens = np.zeros_like(vols)
                    mask = vols > 0
                    dens[mask] = N[mask] / vols[mask]
                    return dens.reshape(-1, 1)
            except Exception as e:
                logger.warning(f"[feature_density] Bulk optimization failed: {e}. Falling back to slow iteration...")

        n = len(dataset)
        out = np.zeros((n, 1), dtype=float)
        for i in range(n):
            try:
                entry = dataset[i]
                if isinstance(entry, (list, tuple)) and len(entry) >= 4:
                    lattice = entry[1]
                    elements = entry[3]
                    num_atoms = len(elements)
                elif hasattr(entry, "AtomPositionManager"):
                    lattice = entry.AtomPositionManager.latticeVectors
                    num_atoms = entry.AtomPositionManager.atomCount
                else:
                    continue

                try:
                    vol = float(abs(np.linalg.det(lattice)))
                except Exception:
                    vol = 0.0
                
                if vol <= 0.0:
                    out[i, 0] = 0.0
                else:
                    out[i, 0] = float(num_atoms) / vol
            except Exception:
                out[i, 0] = 0.0
        return out

    setattr(compute, "get_feature_index_map", get_feature_index_map)
    setattr(compute, "scaling_logic", "invariant")
    return compute


"""
provider = PartitionProvider(partition)  # your adapter

feat_funcs = [
    feature_total_atoms(),
    feature_unique_atom_count(),
    feature_average_interatomic_distance(),
    feature_cell_volume(),
    feature_density(),
]

X = evaluate_features(provider, feat_funcs)
print("Feature matrix shape:", X.shape)
"""
