from __future__ import annotations

# =============================================================================
# EZGA Objectives Facade (100% Backward Compatible)
# =============================================================================

# Base utilities and private helpers
from ezga.evaluator.objectives.base import (
    evaluate_objectives,
    naive_objectives,
    find_optimal_kmeans_k,
    _get_positions_list,
    _get_lattice_vectors_list,
    _get_normalization_factor,
    _fit_mu_from_dataset,
)

# Geometric and structural objectives
from ezga.evaluator.objectives.geometric import (
    objective_volume,
    objective_density,
    objective_average_interatomic_distance,
    objective_coordination_number,
    objective_symmetry,
    objective_amorphisation,
)

# Thermodynamic and energy objectives and private helpers
from ezga.evaluator.objectives.thermodynamic import (
    objective_energy,
    objective_formation_energy,
    objective_min_distance_to_hull,
    objective_min_distance_to_hull_multidim,
    objective_distance_to_composition_hull,
    _lower_hull_distance,
    _lower_hull_distance_ref,
)

# Similarity, novelty and motif distribution objectives
from ezga.evaluator.objectives.novelty import (
    objective_similarity,
    objective_anomality,
    objective_information_novelty,
    objective_motif_distribution,
)

# Electrochemical and Pourbaix objectives
from ezga.evaluator.objectives.electrochemical import (
    objective_min_distance_to_hull_pourbaix_diagram,
    objective_min_distance_to_electrochemicalhull,
    objective_min_distance_to_O_hull,
    objective_integral,
)

# Specific/legacy application objectives
from ezga.evaluator.objectives.specific import (
    objective_min_distance_to_electrochemicalhull_NiLDH,
    objective_min_distance_to_electrochemicalhull_CuCOH,
)
