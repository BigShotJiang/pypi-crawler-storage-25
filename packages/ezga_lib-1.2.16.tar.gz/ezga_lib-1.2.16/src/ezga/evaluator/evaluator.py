from __future__ import annotations
import logging
from collections.abc import Callable
from typing import Any

import numpy as np

from ..core.interfaces import (
    IEvaluator,
)


class Evaluator(IEvaluator):
    """
    Standard implementation of an evolutionary evaluator.

    Transforms individual or lists of functions into a high-performance,
    concatenated evaluation engine.
    """

    def __init__(
        self,
        features_funcs: Callable | list[Callable] | None = None,
        objectives_funcs: Callable | list[Callable] | None = None,
        logger: logging.Logger | None = None,
        debug: bool = False,
        cache_features: bool = False,
        cache_objectives: bool = False,
    ):
        """
        Initializes the Evaluator with feature and objective callables.

        Args:
            features_funcs: Single callable or list of callables for feature extraction.
            objectives_funcs: Single callable or list of callables for objective evaluation.
            logger: Optional logger instance for status reporting.
            debug: If True, enables verbose logging/checks.
        """
        self.logger = logger or logging.getLogger(__name__)
        self.cache_features = cache_features
        self.cache_objectives = cache_objectives

        # --- NORMALIZATION ---
        # Transform inputs into fixed-signature callables: (List[IIndividual]) -> np.ndarray (N, K)
        # We KEEP the names expected by factory.py and other modules for compatibility
        self.features_funcs = self._build_combined_callable(features_funcs, default_val=1.0)
        self.objectives_funcs = self._build_combined_callable(objectives_funcs, default_val=0.0)

    def _build_combined_callable(
        self, input_funcs: Any, default_val: float = 0.0
    ) -> Any:
        """
        Internal factory that wraps multiple functions into a single concatenated result.

        Args:
            input_funcs: The user-provided callables.
            default_val: Value used if input_funcs is None.

        Returns:
            A single callable that returns a 2D NumPy array of shape (N, TotalDimensions).
        """
        if input_funcs is None:
            # Fix: Ensure default lambda also has the index map method to satisfy factory.py
            func: Any = lambda x: np.full((len(x), 1), default_val, dtype=np.float64)
            func.get_feature_index_map = lambda: {}
            return func

        # Ensure we work with a list of functions
        funcs = input_funcs if isinstance(input_funcs, list) else [input_funcs]

        def combined_wrapper(individuals: list[Any]) -> np.ndarray:
            if not individuals:
                return np.empty((0, len(funcs)))

            results: list[np.ndarray] = []
            for func in funcs:
                res = np.atleast_2d(func(individuals))
                # If result is (N,) convert it to (N, 1)
                # If result is (1, N) (transposed), fix it
                if res.shape[0] != len(individuals) and res.shape[1] == len(individuals):
                    res = res.T
                results.append(res)

            if not results:
                return np.empty((len(individuals), 0))

            return np.concatenate(results, axis=1)

        # --- Aggregate Feature Index Maps ---
        # Many features in features.py declare their own index mapping.
        # Since we concatenate their results, we must offset their indices.
        combined_map = {}
        offset = 0
        for func in funcs:
            if hasattr(func, "get_feature_index_map"):
                sub_map = func.get_feature_index_map()
                if sub_map:
                    for key, idx in sub_map.items():
                        combined_map[key] = idx + offset
                    offset += max(sub_map.values()) + 1
            else:
                # Fallback: assume 1D feature if no map is provided
                offset += 1

        wrapper: Any = combined_wrapper
        wrapper.get_feature_index_map = lambda: combined_map
        wrapper._funcs = funcs
        return wrapper

    def evaluate(self, individuals: list[Any], ctx: Any) -> list[Any]:
        """
        Full evaluation pass: updates features and objectives for the given individuals.

        Args:
            individuals: The list of structure containers to evaluate.
            ctx: Execution context (unused in this implementation but required by protocol).

        Returns:
            The list of evaluated individuals (mutates in place).
        """
        # Typically the actual storage in individual.E or similar happens here or in get methods.
        # This is a protocol requirement.
        _ = self.get_features(individuals)
        _ = self.get_objectives(individuals)
        return individuals

    def get_features(self, dataset: Any) -> np.ndarray:
        """Computes concatenated feature matrix."""
        return self._get_cached_or_compute(dataset, "features", self.features_funcs, self.cache_features)

    def get_objectives(self, dataset: Any) -> np.ndarray:
        """Computes concatenated objective matrix."""
        return self._get_cached_or_compute(dataset, "objectives", self.objectives_funcs, self.cache_objectives)

    def _get_cached_or_compute(self, dataset: Any, metadata_key: str, compute_func: Any, use_cache: bool) -> np.ndarray:
        """
        High-performance vectorized logic for retrieving cached properties or computing them on demand.
        Aligns correctly for both local/individual and global/hull-fitted/fitted potential objectives.
        """
        if not use_cache:
            return np.asarray(compute_func(dataset))
            
        if len(dataset) == 0:
            return np.array([[]])

        # A robust helper to identify missing or Nan-ridden cache items
        def _is_missing(x) -> bool:
            if x is None:
                return True
            if isinstance(x, (float, np.floating)):
                return np.isnan(x)
            if isinstance(x, (list, tuple, np.ndarray)):
                arr = np.asarray(x)
                if arr.size == 0:
                    return True
                if arr.dtype == object:
                    return any(val is None or (isinstance(val, (float, np.floating)) and np.isnan(val)) for val in arr.ravel())
                else:
                    return np.isnan(arr).any()
            return False

        # 1. Fetch cached data using high-speed in-memory container fast-path
        # to completely avoid SQLite query and JSON decoding overhead.
        containers = getattr(dataset, "containers", dataset)
        try:
            cached_vals = [getattr(getattr(ind, "AtomPositionManager", ind), "metadata", {}).get(metadata_key) for ind in containers]
        except Exception:
            if hasattr(dataset, "get_all_metadata"):
                cached_vals = dataset.get_all_metadata(metadata_key)
            else:
                cached_vals = [getattr(getattr(ind, "AtomPositionManager", ind), "metadata", {}).get(metadata_key) for ind in dataset]
        
        # 2. Normalize to a NumPy object array for vectorized processing
        N = len(dataset)
        if isinstance(cached_vals, dict):
            # Optimized dictionary-to-array alignment (using positional indices)
            arr = np.full(N, None, dtype=object)
            indices = np.fromiter(cached_vals.keys(), dtype=int)
            mask = (indices >= 0) & (indices < N)
            arr[indices[mask]] = [cached_vals[i] for i in indices[mask]]
            cached_vals = arr
        else:
            cached_vals = np.asarray(cached_vals, dtype=object)
            if cached_vals.shape[0] != N:
                arr = np.full(N, None, dtype=object)
                arr[:cached_vals.shape[0]] = cached_vals
                cached_vals = arr
        
        # 3. Identify missing items (Vectorized custom check)
        is_missing_func = np.frompyfunc(_is_missing, 1, 1)
        mask_missing = is_missing_func(cached_vals).astype(bool)
        missing_indices = np.where(mask_missing)[0]
        if missing_indices.size == 0:
            # Performance Pass: All items were cached. Stack and return.
            res = np.stack(cached_vals).astype(float)
            return res.reshape(N, -1) if res.ndim == 1 else res
        
        # 4. Check if any function requires global context (dynamic fit, hulls, novelty/similarity)
        is_global = False
        funcs = getattr(compute_func, "_funcs", [])
        global_keywords = ["hull", "formation", "novelty", "similarity", "anomality", "fit", "regression"]
        for func in funcs:
            func_name = getattr(func, "__name__", "").lower()
            module_name = getattr(func, "__module__", "").lower()
            class_name = func.__class__.__name__.lower()
            combined_str = f"{func_name} {module_name} {class_name}"
            if any(kw in combined_str for kw in global_keywords):
                is_global = True
                break

        # 5. Load/Materialize missing structures
        if hasattr(dataset, "materialize_by_ids") and hasattr(dataset, "get_ids"):
            all_ids = dataset.get_ids()
            missing_ids = [all_ids[i] for i in missing_indices]
            missing_structs = dataset.materialize_by_ids(missing_ids, dedup=False, preserve_order=True)
        else:
            missing_structs = [dataset[int(idx)] for idx in missing_indices]

        # 6. Compute missing results
        if is_global:
            # Global objectives MUST be computed on the entire dataset to preserve
            # dynamically fitted parameters (like chemical potentials, convex hulls, etc.)
            self.logger.info("[Evaluator] Computing global objective on full dataset for consistent references.")
            all_results = np.asarray(compute_func(dataset))
            if all_results.ndim == 1:
                all_results = all_results.reshape(-1, 1)
            missing_results = all_results[missing_indices]
        else:
            # Local objectives can be safely computed on a temporary subset Partition for speed
            try:
                from sage_lib.partition.Partition import Partition
                temp_ds = Partition()
                temp_ds.add(missing_structs)
            except (ImportError, TypeError, AttributeError) as exc:
                temp_ds = missing_structs

            missing_results = np.asarray(compute_func(temp_ds))
            if missing_results.ndim == 1:
                missing_results = missing_results.reshape(-1, 1)
        
        # 7. Assemble final results using NumPy masking
        D = missing_results.shape[1]
        final_results = np.zeros((N, D), dtype=float)
        
        # Fill missing results
        final_results[mask_missing] = missing_results
        
        # Fill existing results (Vectorized Stack)
        exists_mask = ~mask_missing
        if np.any(exists_mask):
            existing_data = np.stack(cached_vals[exists_mask]).astype(float)
            if existing_data.ndim == 1:
                existing_data = existing_data.reshape(-1, 1)
            final_results[exists_mask] = existing_data
        
        # 8. Store newly computed values back to SAGE metadata efficiently
        updates = {}
        for i, idx in enumerate(missing_indices):
            container = missing_structs[i]
            apm = getattr(container, "AtomPositionManager", container)
            meta = getattr(apm, "metadata", None)
            if not isinstance(meta, dict):
                apm.metadata = {}
                meta = apm.metadata
            
            val = missing_results[i].tolist()
            meta[metadata_key] = val
            updates[int(idx)] = meta
            
        # Bulk persistence call
        if updates and hasattr(dataset, "set_metadata_bulk"):
            try:
                dataset.set_metadata_bulk(updates, use_indices=True)
            except Exception as exc:
                self.logger.warning("[Evaluator] Failed to persist metadata bulk: %s", exc)
            
        return final_results

    def evaluate_features_objectives(self, individuals: Any) -> tuple[np.ndarray, np.ndarray]:
        """Deprecated: use get_features and get_objectives instead."""
        return self.get_features(individuals), self.get_objectives(individuals)
