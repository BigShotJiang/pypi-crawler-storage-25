from __future__ import annotations
from typing import Any, Callable

import numpy as np
from scipy.spatial import ConvexHull, QhullError

from ezga.evaluator.objectives.base import _get_normalization_factor, _fit_mu_from_dataset


def objective_energy(scale: float = 1.0) -> Callable[[Any], np.ndarray]:
    r"""Compute scaled total energies from the dataset.

    Extracts absolute energy values from the dataset and scales them by the 
    specified factor:
    .. math::
       E_{scaled} = \text{scale} \cdot E_{total}

    Expected Dataset API:
      - `dataset.get_all_energies()`: Returns an array-like of shape (N,) containing energies.

    Args:
        scale: Scaling coefficient factor to apply to all energies. Defaults to 1.0.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing scaled energies.
    """
    def compute(dataset: Any) -> np.ndarray:
        y = np.asarray(dataset.get_all_energies(), dtype=float)
        y = np.nan_to_num(y, nan=0.0)
        return np.asarray(scale * y)

    setattr(compute, "scaling_logic", "linear")
    return compute


def objective_formation_energy(
    reference_potentials: dict[str, float] | None = None,
    unique_labels: list[str] | None = None,
    delta: float = 0.25,
) -> Callable[[Any], np.ndarray]:
    r"""Compute composition-normalized formation energies.

    Formation energy is calculated as:
    .. math::
       E_{form} = E_{total} - \sum_{i} n_i \cdot \mu_i
    Where $n_i$ is the count of atoms of element $i$ and $\mu_i$ is their elemental 
    chemical potential.

    If `reference_potentials` is None, chemical potentials ($\mu$) are fitted via
    weighted least squares on the input dataset, weighting stable, low-energy structures 
    more heavily:
    .. math::
       w_j = \exp\left( -\frac{E_j - E_{min}}{\delta} \right)

    Expected Dataset API:
      - `dataset.get_all_energies()`: Returns energies of shape (N,).
      - `dataset.get_all_compositions(return_species=True)`: Returns (X_all, species_order).
      - `dataset.get_species_mapping(order="stored")`: Returns dict mapping symbols to indexes.

    Args:
        reference_potentials: A dictionary mapping element symbols (e.g. {'Fe': -8.2})
            to their chemical potential values ($\mu$). If None, chemical potentials
            will be fitted dynamically using weighted least squares. Defaults to None.
        unique_labels: An ordered list of chemical species labels to include in 
            the composition vector. If None, uses all species found in the dataset. Defaults to None.
        delta: Weight decay coefficient (in eV) for weighted least squares fitting. 
            A smaller delta assigns exponentially higher weight to low-energy structures. Defaults to 0.25.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing formation energies.
    """
    def _fit_mu_weighted(X: np.ndarray, y: np.ndarray, delta: float = 0.25) -> np.ndarray:
        col_var = X.var(axis=0)
        informative = col_var > 0.0
        mu = np.zeros(X.shape[1], dtype=float)
        if not np.any(informative):
            return mu

        y_min = float(np.min(y))
        w = np.exp(-(y - y_min) / max(delta, 1e-10))
        W = np.sqrt(w)[:, None]

        Xw = X[:, informative] * W
        yw = y * np.sqrt(w)

        mu_inf, *_ = np.linalg.lstsq(Xw.astype(float), yw.astype(float), rcond=None)
        mu[informative] = mu_inf
        return mu

    def compute(dataset: Any) -> np.ndarray:
        y = np.asarray(dataset.get_all_energies(), dtype=float)
        y = np.nan_to_num(y, nan=0.0)
        N = y.shape[0]

        X_all, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")

        labels = list(unique_labels) if unique_labels is not None else list(species_order)

        idx = np.fromiter((mapping.get(lbl, -1) for lbl in labels), dtype=int, count=len(labels))
        valid = idx >= 0

        X = np.zeros((N, len(labels)), dtype=float)
        if np.any(valid):
            X[:, valid] = X_all[:, idx[valid]]

        if reference_potentials is None:
            mu_vec = _fit_mu_weighted(X, y, delta=delta)
        else:
            mu_vec = np.array([reference_potentials.get(lbl, 0.0) for lbl in labels], dtype=float)

        fE = y - X.dot(mu_vec)
        return np.asarray(fE)

    setattr(compute, "scaling_logic", "linear")
    return compute


def _lower_hull_distance(points: np.ndarray) -> np.ndarray:
    """Helper function to compute distances of points above the lower convex hull.

    Args:
        points: A NumPy array of shape (N, D + 1) where the first D columns represent
            composition fractions/variables and the last column represents energy.

    Returns:
        np.ndarray: Vector of shape (N,) containing distance values above the lower hull.
    """
    N, D = points.shape
    mask_valid = np.isfinite(points).all(axis=1)
    valid_points = points[mask_valid]
    N_valid = valid_points.shape[0]

    d_above = np.zeros(N, dtype=float)

    if N_valid < (D + 1):
        return np.asarray(d_above)

    try:
        hull = ConvexHull(valid_points)
    except QhullError:
        try:
            hull = ConvexHull(valid_points, qhull_options="QJ")
        except Exception:
            return np.asarray(d_above)
    except ValueError:
        return np.asarray(d_above)

    for eq in hull.equations:
        a_all = eq[:-1]
        c = eq[-1]
        a_E = a_all[-1]
        if a_E < 0.0:
            na = np.linalg.norm(a_all)
            if na == 0.0:
                continue
            val_pts = points[mask_valid]
            signed = (val_pts @ a_all + c) / na
            current_d = d_above[mask_valid]
            np.maximum(current_d, signed, out=current_d)
            d_above[mask_valid] = current_d

    d = d_above[mask_valid]
    d[d < 0.0] = 0.0
    d_above[mask_valid] = d
    return d_above


def objective_min_distance_to_hull(
    reference_potentials: dict[str, float] | None = None,
    variable_species: str | None = None,
    A: float | str | None = None,
    mu_range: tuple[float, float] | None = None,
    steps: int = 20,
    unique_labels: list[str] | None = None,
) -> Callable[[Any], np.ndarray]:
    r"""Compute the minimal distance above the lower convex hull for a variable species.

    For each structure in the dataset, this objective scans a range of chemical potentials
    for the specified `variable_species`, constructs the convex hull in (composition, normalized energy) 
    space, and computes the distance above the lower hull:
    .. math::
       d_{hull} = E_{form} - E_{hull}

    A distance of `0.0` indicates thermodynamic thermodynamic stability (residing exactly
    on the convex hull).

    Args:
        reference_potentials: Dict of baseline potentials {symbol: μ} for non-variable species.
            If None, baseline chemical potentials are fitted using least squares. Defaults to None.
        variable_species: Element symbol of the species whose chemical potential is varied.
        A: Normalization instruction for energy (e.g. 'atoms', 'volume', or constant).
        mu_range: Range of chemical potentials (min_μ, max_μ) to scan. Defaults to (-3.0, 1.0).
        steps: Number of potential steps to evaluate in the scanned range. Defaults to 20.
        unique_labels: Ordered list of chemical species labels to include in composition matrix.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing distance above the convex hull.
    """
    if variable_species is None:
        raise ValueError("`variable_species` must be provided.")

    if mu_range is None:
        mu_range = (-3.0, 1.0)

    def compute(dataset: Any) -> np.ndarray:
        y = np.asarray(dataset.get_all_energies(), dtype=float)
        species, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")

        labels = list(unique_labels) if unique_labels is not None else list(species_order)
        if variable_species not in labels:
            labels.append(variable_species)

        idx = np.fromiter((mapping.get(lbl, -1) for lbl in labels), dtype=int, count=len(labels))
        valid = idx >= 0

        N = species.shape[0]
        M = len(labels)
        X = np.zeros((N, M), dtype=float)
        if np.any(valid):
            X[:, valid] = species[:, idx[valid]]

        norm, use_fractions_for_fit = _get_normalization_factor(dataset, A)

        if reference_potentials is None:
            mu_base = _fit_mu_from_dataset(X, y, use_fractions=use_fractions_for_fit)
        else:
            mu_base = np.array([reference_potentials.get(lbl, 0.0) for lbl in labels], dtype=float)

        try:
            var_idx = labels.index(variable_species)
        except ValueError:
            raise ValueError(f"Variable species '{variable_species}' is not among labels {labels}.")

        denom = X.sum(axis=1, keepdims=True)
        denom[denom == 0.0] = 1.0
        comp_frac = X / denom

        mu_vals = np.linspace(mu_range[0], mu_range[1], int(steps))
        min_dist = np.full(N, np.inf, dtype=float)

        for mu_v in mu_vals:
            mu = mu_base.copy()
            mu[var_idx] = mu_v

            fE = (y - X.dot(mu)) / norm
            pts = np.hstack([comp_frac, fE.reshape(-1, 1)])
            d = _lower_hull_distance(pts)
            np.minimum(min_dist, d, out=min_dist)

        min_dist[~np.isfinite(min_dist)] = 0.0
        return min_dist

    setattr(compute, "scaling_logic", "invariant")
    return compute


def _lower_hull_distance_ref(ref_points: np.ndarray, all_points: np.ndarray) -> np.ndarray:
    """Helper function to compute distance of all_points above the lower hull defined by ref_points.

    Args:
        ref_points: NumPy array of coordinates defining the baseline convex hull.
        all_points: NumPy array of coordinates for which to compute distance.

    Returns:
        np.ndarray: Vector of shape (N,) containing distance values above the reference hull.
    """
    N_all = all_points.shape[0]
    D = all_points.shape[1]
    
    mask_ref = np.isfinite(ref_points).all(axis=1)
    valid_ref = ref_points[mask_ref]
    
    d_above = np.zeros(N_all, dtype=float)
    if valid_ref.shape[0] < (D + 1):
        return d_above

    try:
        hull = ConvexHull(valid_ref, qhull_options="QJ")
    except Exception:
        return d_above

    mask_all = np.isfinite(all_points).all(axis=1)
    val_all = all_points[mask_all]

    for eq in hull.equations:
        a_all = eq[:-1]
        c = eq[-1]
        if a_all[-1] < 0.0:
            na = np.linalg.norm(a_all)
            if na == 0.0: continue
            signed = (val_all @ a_all + c) / na
            current_d = d_above[mask_all]
            np.maximum(current_d, signed, out=current_d)
            d_above[mask_all] = current_d

    d_above[d_above < 0.0] = 0.0
    return d_above


def objective_min_distance_to_hull_multidim(
    reference_potentials: dict[str, float] | None = None,
    variable_species: list[str] | None = None,
    A: float | str | None = None,
    mu_ranges: list[tuple[float, float]] | None = None,
    steps: int = 8,
    unique_labels: list[str] | None = None,
) -> Callable[[Any], np.ndarray]:
    r"""Compute the minimal distance above the lower convex hull for multiple variable species.

    A generalized multi-dimensional version of `objective_min_distance_to_hull`.
    Varies chemical potentials across an N-dimensional grid, constructs/evaluates convex hulls,
    and returns stability scores. Employs concurrent processing and spatial proxy filtering
    for larger datasets ($N_{structs} > 500$) to maintain fast execution.

    Args:
        reference_potentials: Dict of baseline potentials {symbol: μ} for non-variable species.
        variable_species: List of elements whose chemical potentials are varied.
        A: Normalization instruction for energy (e.g. 'atoms', 'volume', or constant).
        mu_ranges: List of potential ranges (min_μ, max_μ) matching variable species length.
        steps: Number of potential steps to evaluate in each dimension grid. Defaults to 8.
        unique_labels: Ordered list of chemical species labels to include in composition matrix.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing multi-dimensional stability scores.
    """
    if not variable_species:
        raise ValueError("`variable_species` list must be provided.")

    if mu_ranges is None:
        mu_ranges = [(-3.0, 1.0)] * len(variable_species)

    if len(mu_ranges) != len(variable_species):
        raise ValueError("`mu_ranges` must match `variable_species` length.")

    def compute(dataset: Any) -> np.ndarray:
        from concurrent.futures import ThreadPoolExecutor

        y = np.asarray(dataset.get_all_energies(), dtype=float)
        species, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")

        labels = list(unique_labels) if unique_labels is not None else list(species_order)
        for s in variable_species:
            if s not in labels:
                labels.append(s)

        idx_map = np.fromiter((mapping.get(lbl, -1) for lbl in labels), dtype=int, count=len(labels))
        valid = idx_map >= 0

        N_structs = species.shape[0]
        M_dim = len(labels)
        X = np.zeros((N_structs, M_dim), dtype=float)
        if np.any(valid):
            X[:, valid] = species[:, idx_map[valid]]

        norm, use_fractions = _get_normalization_factor(dataset, A)

        if reference_potentials is None:
            mu_base = _fit_mu_from_dataset(X, y, use_fractions=use_fractions)
        else:
            mu_base = np.array([reference_potentials.get(lbl, 0.0) for lbl in labels], dtype=float)

        var_indices = [labels.index(s) for s in variable_species]

        denom = X.sum(axis=1, keepdims=True)
        denom[denom == 0.0] = 1.0
        comp_frac = X / denom

        if N_structs > 500:
            comp_rounded = np.round(comp_frac, 4)
            comp_hashes = [hash(row.tobytes()) for row in comp_rounded]
            fE_proxy = (y - X.dot(mu_base)) / norm
            unique_hashes: dict[int, tuple[float, int]] = {}
            for i, h in enumerate(comp_hashes):
                if h not in unique_hashes or fE_proxy[i] < unique_hashes[h][0]:
                    unique_hashes[h] = (fE_proxy[i], i)
            ref_indices = [idx for _, idx in unique_hashes.values()]
            ref_pts_base = comp_frac[ref_indices]
            ref_y = y[ref_indices]
            ref_X = X[ref_indices]
            ref_norm = norm[ref_indices]
        else:
            ref_pts_base = comp_frac
            ref_y = y
            ref_X = X
            ref_norm = norm

        mu_axes = [np.linspace(r[0], r[1], int(steps)) for r in mu_ranges]
        grid = np.array(np.meshgrid(*mu_axes, indexing="ij")).reshape(len(mu_axes), -1).T

        min_dist = np.full(N_structs, np.inf, dtype=float)

        def process_mu(mu_point):
            mu_curr = mu_base.copy()
            for i, val in enumerate(mu_point):
                mu_curr[var_indices[i]] = val
            fE_ref = (ref_y - ref_X.dot(mu_curr)) / ref_norm
            pts_ref = np.hstack([ref_pts_base, fE_ref.reshape(-1, 1)])
            fE_all = (y - X.dot(mu_curr)) / norm
            pts_all = np.hstack([comp_frac, fE_all.reshape(-1, 1)])
            return _lower_hull_distance_ref(pts_ref, pts_all)

        if len(grid) > 1:
            with ThreadPoolExecutor() as executor:
                results = list(executor.map(process_mu, grid))
            for d in results:
                np.minimum(min_dist, d, out=min_dist)
        else:
            d = process_mu(grid[0])
            np.minimum(min_dist, d, out=min_dist)

        min_dist[~np.isfinite(min_dist)] = 0.0
        return min_dist

    return compute


def objective_distance_to_composition_hull(
    reference_potentials: dict[str, float] | None = None,
    A: float | str | None = None,
    unique_labels: list[str] | None = None,
) -> Callable[[Any], np.ndarray]:
    r"""Compute the distance of each structure above the composition convex hull.

    Evaluates thermodynamic stability of each structure relative to all other composition 
    fractions present in the dataset. Constructs the full multidimensional convex hull
    in (compositions fractions..., formation energy) space.

    Args:
        reference_potentials: Dictionary mapping element symbols to baseline potentials.
            If None, elemental chemical potentials are fitted using least squares.
        A: Normalization instruction for energy (e.g. 'atoms', 'volume', or constant).
        unique_labels: Ordered list of chemical species labels to include in composition matrix.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing distance above the composition hull.
    """
    def _fit_mu_from_dataset_hull(X: np.ndarray, y: np.ndarray, use_fractions: bool) -> np.ndarray:
        if use_fractions:
            N_atoms = X.sum(axis=1, keepdims=True).astype(float)
            N_atoms[N_atoms == 0.0] = 1.0
            D = X / N_atoms
            y_fit = y / N_atoms.ravel()
        else:
            D = X.astype(float)
            y_fit = y.astype(float)

        col_var = D.var(axis=0)
        informative = col_var > 0.0

        mu = np.zeros(D.shape[1], dtype=float)
        if np.any(informative):
            mu_inf, *_ = np.linalg.lstsq(D[:, informative], y_fit, rcond=None)
            mu[informative] = mu_inf
        return mu

    def compute(dataset: Any) -> np.ndarray:
        y = np.asarray(dataset.get_all_energies(), dtype=float)
        species, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")

        labels = list(unique_labels) if unique_labels is not None else list(species_order)

        idx = np.fromiter((mapping.get(lbl, -1) for lbl in labels), dtype=int, count=len(labels))
        valid = idx >= 0
        M = len(labels)
        N = species.shape[0]

        X = np.zeros((N, M), dtype=float)
        if np.any(valid):
            X[:, valid] = species[:, idx[valid]]

        norm, use_fractions_for_fit = _get_normalization_factor(dataset, A)

        if reference_potentials is None:
            mu_vec = _fit_mu_from_dataset_hull(X, y, use_fractions=use_fractions_for_fit)
        else:
            mu_vec = np.array([reference_potentials.get(lbl, 0.0) for lbl in labels], dtype=float)

        fE = (y - X.dot(mu_vec)) / norm

        denom = X.sum(axis=1, keepdims=True)
        denom[denom == 0.0] = 1.0
        comp_frac = X / denom

        points = np.hstack([comp_frac, fE.reshape(-1, 1)])

        if points.shape[0] < (M + 2):
            return np.zeros(N, dtype=float)

        mask_valid = np.isfinite(points).all(axis=1)
        valid_points = points[mask_valid]
        N_valid = valid_points.shape[0]

        d_above = np.zeros(N, dtype=float)

        if N_valid < (M + 2):
            return d_above

        try:
            hull = ConvexHull(valid_points)
        except QhullError:
            try:
                hull = ConvexHull(valid_points, qhull_options="QJ")
            except Exception:
                return d_above
        except ValueError:
            return d_above

        for eq in hull.equations:
            a = eq[:-1]
            c = eq[-1]
            a_E = a[-1]
            if a_E < 0.0:
                na = np.linalg.norm(a)
                if na == 0.0:
                    continue

                val_pts = points[mask_valid]
                signed = (val_pts @ a + c) / na

                current_d = d_above[mask_valid]
                np.maximum(current_d, signed, out=current_d)
                d_above[mask_valid] = current_d

        d = d_above[mask_valid]
        d[d < 0] = 0.0
        d_above[mask_valid] = d

        return d_above

    setattr(compute, "scaling_logic", "invariant")
    return compute
