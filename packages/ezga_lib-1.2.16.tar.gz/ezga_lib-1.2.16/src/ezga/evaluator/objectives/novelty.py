from __future__ import annotations
from typing import Any, Callable
from pathlib import Path

import numpy as np
from numpy.linalg import inv

from ezga.evaluator.objectives.base import find_optimal_kmeans_k


def objective_similarity(
    r_cut: float = 4.0,
    n_max: int = 2,
    l_max: int = 2,
    sigma: float = 0.5,
    n_components: int = 3,
    compress_model: str = "pca",
    eps: float = 0.6,
    min_samples: int = 2,
    cluster_model: str = "minibatch-kmeans",
    max_clusters: int = 10,
) -> Callable[[Any], np.ndarray]:
    r"""Compute structural similarity scores using atomic cluster distributions.

    Similarity is defined as the mathematical complement of structural anomaly scores:
    .. math::
       S = \frac{1}{1 + D_{anomaly}}

    Expected Dataset API:
      - SOAP representation querying and cluster mappings.

    Args:
        r_cut: Radial cutoff distance in SOAP. Defaults to 4.0.
        n_max: Maximum number of radial basis functions in SOAP. Defaults to 2.
        l_max: Maximum degree of spherical harmonics in SOAP. Defaults to 2.
        sigma: Standard deviation of atomic gaussian densities. Defaults to 0.5.
        n_components: Target dimension for principal component analysis (PCA). Defaults to 3.
        compress_model: Dimensionality reduction technique. Defaults to "pca".
        eps: DBSCAN epsilon clustering boundary parameter. Defaults to 0.6.
        min_samples: DBSCAN minimum samples threshold. Defaults to 2.
        cluster_model: Atomic clustering backend method. Defaults to "minibatch-kmeans".
        max_clusters: Maximum number of clusters to search during silhouette checks.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing similarity scores in [0, 1].
    """
    anomaly_func = objective_anomality(
        r_cut=r_cut,
        n_max=n_max,
        l_max=l_max,
        sigma=sigma,
        n_components=n_components,
        compress_model=compress_model,
        eps=eps,
        min_samples=min_samples,
        cluster_model=cluster_model,
        max_clusters=max_clusters,
    )

    def compute_similarity(dataset: Any) -> np.ndarray:
        anomaly_scores = anomaly_func(dataset)
        similarity_scores = 1.0 / (1.0 + anomaly_scores)
        return similarity_scores

    return compute_similarity


def objective_anomality(
    r_cut: float = 4.0,
    n_max: int = 2,
    l_max: int = 2,
    sigma: float = 0.5,
    n_components: int = 3,
    compress_model: str = "pca",
    eps: float = 0.6,
    min_samples: int = 2,
    cluster_model: str = "minibatch-kmeans",
    max_clusters: int = 10,
) -> Callable[[Any], np.ndarray]:
    r"""Compute atomic anomaly scores in SOAP feature cluster space.

    Calculates anomaly scores for each structure by generating Smooth Overlap of 
    Atomic Positions (SOAP) descriptors, projecting them into a reduced PCA coordinate space, 
    clustering atomic environments, and computing the Mahalanobis distance of cluster 
    distribution vectors:
    .. math::
       D_M(x) = \sqrt{(x - \mu)^T \Sigma^{-1} (x - \mu)}

    Args:
        r_cut: Radial cutoff distance in SOAP. Defaults to 4.0.
        n_max: Maximum number of radial basis functions in SOAP. Defaults to 2.
        l_max: Maximum degree of spherical harmonics in SOAP. Defaults to 2.
        sigma: Standard deviation of atomic densities. Defaults to 0.5.
        n_components: Target dimension for principal component analysis. Defaults to 3.
        compress_model: Dimensionality reduction technique. Defaults to "pca".
        eps: Epsilon parameter for density-based clustering. Defaults to 0.6.
        min_samples: Minimum samples threshold for clustering. Defaults to 2.
        cluster_model: Atomic clustering algorithm backend. Defaults to "minibatch-kmeans".
        max_clusters: Maximum number of clusters to search. Defaults to 10.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing structural anomaly scores.
    """
    def compute(
        dataset: Any,
        n_components: int = n_components,
        r_cut: float = 5.0,
        n_max: int = 3,
        l_max: int = 3,
        sigma: float = 0.5,
        max_clusters: int = 10,
    ) -> np.ndarray:
        from scipy.spatial.distance import mahalanobis
        from scipy.stats import zscore
        from sklearn.cluster import KMeans
        from sklearn.decomposition import PCA

        n_structures = dataset.size()
        if n_structures == 0:
            return np.array([])

        if n_structures < n_components:
            return np.zeros(n_structures)

        descriptors_by_species, atom_info_by_species = dataset.get_SOAP(
            r_cut=r_cut, n_max=n_max, l_max=l_max, sigma=sigma, save=False, cache=False
        )

        if not descriptors_by_species:
            return np.zeros(n_structures)

        cluster_counts_list = []

        for species, desc_array in descriptors_by_species.items():
            if desc_array.shape[0] == 0:
                continue

            structure_indices_full = atom_info_by_species[species]

            feature_dim = desc_array.shape[1]
            if feature_dim < n_components:
                zero_matrix = np.zeros((n_structures, 1), dtype=int)
                cluster_counts_list.append(zero_matrix)
                continue

            try:
                pca = PCA(n_components=n_components)
                compressed_data = pca.fit_transform(desc_array)
            except ValueError:
                zero_matrix = np.zeros((n_structures, 1), dtype=int)
                cluster_counts_list.append(zero_matrix)
                continue

            optimal_k = find_optimal_kmeans_k(compressed_data, max_k=np.min([compressed_data.shape[0], max_clusters]))
            if optimal_k == 1:
                cluster_counts = np.zeros((n_structures, 1), dtype=int)
                for i_atom, _c_data in enumerate(compressed_data):
                    struc_idx = structure_indices_full[i_atom][0]
                    if 0 <= struc_idx < n_structures:
                        cluster_counts[struc_idx, 0] += 1
            else:
                kmeans = KMeans(n_clusters=optimal_k, random_state=42)
                atom_clusters = kmeans.fit_predict(compressed_data)

                cluster_counts = np.zeros((n_structures, optimal_k), dtype=int)
                for i_atom, cluster_label in enumerate(atom_clusters):
                    struc_idx = structure_indices_full[i_atom][0]
                    if 0 <= struc_idx < n_structures:
                        cluster_counts[struc_idx, cluster_label] += 1

            cluster_counts_list.append(cluster_counts)

        if not cluster_counts_list:
            return np.zeros(n_structures)

        combined_cluster_counts = np.hstack(cluster_counts_list)

        normalized_data = zscore(combined_cluster_counts, axis=0)
        normalized_data = np.nan_to_num(normalized_data, nan=0.0)

        mean_vector = np.mean(normalized_data, axis=0)
        cov_matrix = np.cov(normalized_data, rowvar=False)

        cov_matrix += 1e-6 * np.eye(cov_matrix.shape[0])
        cov_inv = inv(cov_matrix)

        anomaly_scores = []
        for row in normalized_data:
            try:
                dist = mahalanobis(row, mean_vector, cov_inv)
            except Exception:
                dist = np.nan
            anomaly_scores.append(dist)

        return np.array(anomaly_scores)

    return compute


def objective_information_novelty(
    r_cut: float = 4.0,
    n_max: int = 2,
    l_max: int = 2,
    sigma: float = 0.5,
    n_components: int = 3,
    compress_model: str = "pca",
    eps: float = 0.6,
    min_samples: int = 2,
    cluster_model: str = "minibatch-kmeans",
    max_clusters: int = 10,
) -> Callable[[Any], np.ndarray]:
    r"""Compute informational novelty metrics over the ensemble.

    Uses information-theoretic ensemble metrics to assess the novelty of cluster
    distributions for each structure within the structural population.

    Args:
        r_cut: Radial cutoff distance in SOAP.
        n_max: Maximum number of radial basis functions in SOAP.
        l_max: Maximum degree of spherical harmonics in SOAP.
        sigma: Standard deviation of atomic gaussian densities.
        n_components: Projection components threshold.
        compress_model: Dimensionality reduction technique.
        eps: DBSCAN boundary clustering parameter.
        min_samples: DBSCAN minimum samples threshold.
        cluster_model: Clustering algorithm backend.
        max_clusters: Maximum number of clusters to search.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing informational novelty values.
    """
    from ezga.classification.clustering import SOAPClusterAnalyzer
    from ezga.metric.information_ensemble_metrics import InformationEnsambleMetric

    def compute(
        dataset: Any,
        n_components: int = 5,
        r_cut: float = 5.0,
        n_max: int = 3,
        l_max: int = 3,
        sigma: float = 0.5,
        max_clusters: int = 10,
    ) -> np.ndarray:

        if dataset.size() <= n_components:
            return np.ones(dataset.size())

        analyzer = SOAPClusterAnalyzer()
        cluster_array = analyzer.get_cluster_counts(dataset.containers)

        IEM = InformationEnsambleMetric(
            metric="novelty",
        )

        information_novelty = IEM.compute(cluster_array)

        return np.array(information_novelty)

    return compute


def objective_motif_distribution(
    library_path: str | Path | None = None,
    match_threshold: float = 0.7,
    substrate_constraints: list | None = None,
    mode: str = "entropy",
    **harvester_kwargs
) -> Callable[[Any], np.ndarray]:
    r"""Optimize the structural distribution of local motifs.

    Evaluates structural information based on the diversity, abundance, or
    coverage of recognized structural motifs. Supports searching against a custom 
    pre-loaded `MotifLibrary` or classifying dynamic motifs discovered in the run.

    Args:
        library_path: Optional path to a JSON/PKL motif library file containing 
            reference motif families.
        match_threshold: Similarity matching threshold [0.0 - 1.0] for canonical 
            motif fingerprint matching. Defaults to 0.7.
        substrate_constraints: Structural rules or boundaries defining mobile/substrate atoms.
        mode: The scoring metric to apply to the identified motif distribution:
            - `"entropy"`: Calculates Shannon entropy of motif distribution ($-\sum p_i \ln p_i$).
            - `"richness"`: Calculates total count of unique motif families discovered.
            - `"coverage"`: Calculates ratio of atoms covered by motifs to total mobile atoms.
        **harvester_kwargs: Additional arguments passed directly to the `MotifHarvester` constructor.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing motif distribution scores.
    """
    def compute(dataset: Any) -> np.ndarray:
        from ezga.hise.motifs import MotifHarvester, MotifLibrary
        from collections import Counter
        
        _match_threshold = match_threshold
        _harvester_kwargs = harvester_kwargs.copy()

        target_fams = None
        if library_path:
            lib = MotifLibrary(str(library_path))
            lib_motifs = lib.load()
            target_fams = lib_motifs
            
            if lib.metadata:
                _match_threshold = lib.metadata.get("match_threshold", _match_threshold)
                for k, v in lib.metadata.items():
                    if k != "match_threshold" and v is not None:
                        _harvester_kwargs[k] = v

        harvester = MotifHarvester(
            substrate_constraints=substrate_constraints,
            max_structures_to_analyze=len(dataset),
            early_stop=False,
            **_harvester_kwargs
        )
        
        n = len(dataset)
        scores = np.zeros(n, dtype=float)
        
        for i in range(n):
            try:
                struct = dataset[i]
                apm = getattr(struct, "AtomPositionManager", None)
                if apm is None: continue
                
                frags, is_excluded = harvester._get_fragments(struct)
                motifs = harvester._cluster_fragments(struct, frags, apm.latticeVectors)
                
                if not motifs:
                    scores[i] = 0.0
                    continue

                from ezga.hise.motifs import MotifFamily
                active_fps = []
                matched_motifs = []
                
                for m in motifs:
                    _, canon_pos, canon_labels = harvester.canonicalize(m["pos"], m["labels"])
                    
                    if target_fams:
                        m_fam = MotifFamily(id="tmp", formula="", labels=canon_labels, canonical_positions=canon_pos)
                        best_sim = 0.0
                        best_id = None
                        for t in target_fams:
                            sim = harvester._motif_similarity(m_fam, t)
                            if sim > best_sim:
                                best_sim = sim
                                best_id = t.id
                        
                        if best_sim >= _match_threshold:
                            active_fps.append(best_id)
                            matched_motifs.append(m)
                    else:
                        fp, _, _ = harvester.canonicalize(m["pos"], m["labels"])
                        active_fps.append(fp)
                        matched_motifs.append(m)

                if not active_fps:
                    scores[i] = 0.0
                    continue

                if mode == "entropy":
                    counts = np.array(list(Counter(active_fps).values()), dtype=float)
                    probs = counts / np.sum(counts)
                    scores[i] = -np.sum(probs * np.log(probs + 1e-12))
                    
                elif mode == "richness":
                    scores[i] = float(len(set(active_fps)))
                    
                elif mode == "coverage":
                    total_mobile = np.sum(~is_excluded)
                    if total_mobile == 0:
                        scores[i] = 0.0
                    else:
                        motif_atoms = set()
                        for m in matched_motifs:
                            motif_atoms.update(m["indices"])
                        scores[i] = float(len(motif_atoms)) / total_mobile
            except Exception:
                scores[i] = 0.0
                
        return scores

    return compute
