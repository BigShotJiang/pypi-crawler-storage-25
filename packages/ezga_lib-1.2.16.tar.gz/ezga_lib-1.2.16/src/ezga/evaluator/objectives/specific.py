"""
Module for Case-Study and Paper-Specific Objective Functions.

This module houses highly specialized objective functions developed for specific scientific 
publications, materials systems, or unique experimental case studies (e.g., Ni-Fe LDH stability).

Separating these functions from the core general modules (geometric, thermodynamic, etc.)
maintains a clean and generic codebase for the wider community, while fully preserving 
backward compatibility and mathematical reproducibility for historical paper calculations.

Researchers wishing to add their own case-study specific objectives should place them here.
"""

from __future__ import annotations
from typing import Any, Callable, cast

import numpy as np


def objective_min_distance_to_electrochemicalhull_NiLDH(
    reference_potentials: dict[str, float],
    U_range: tuple[float, float] = (0.0, 1.8),
    pH: float = 13.0,
    steps: int = 100,
    unique_labels: list[str] | None = None,
) -> Callable[[Any], np.ndarray]:
    r"""Compute electrochemical hull distance tailored for Ni-Fe LDH systems.

    .. note::
       This is a specific application objective function designed for Ni-Fe LDH 
       stability modeling. For general multi-species electrochemical hulls, please 
       refer to `objective_min_distance_to_electrochemicalhull`.

    Implements a computationally efficient electrochemical hull distance solver for 
    Nickel-Iron Layered Double Hydroxides (Ni-Fe LDH). Explicitly couples hydrogen and 
    oxygen chemical potentials to the applied potential (U) and pH using the 
    Computational Hydrogen Electrode (CHE) model:
    .. math::
       \mu_H(U) = \frac{1}{2}\mu_{H_2} - eU + k_B T \ln(10) \cdot \text{pH}
    .. math::
       \mu_O(U) = \mu_{H_2O} - 2\mu_H(U)

    Args:
        reference_potentials: Reference potentials mapping for elemental and gaseous phases
            (e.g., must include 'H2' and 'H2O' references).
        U_range: Range of applied potential (U_min, U_max) in volts. Defaults to (0.0, 1.8).
        pH: The operating pH value of the electrochemical cell. Defaults to 13.0 (alkaline).
        steps: Number of potential steps to evaluate in the scanned range. Defaults to 100.
        unique_labels: Ordered list of chemical species labels to include.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing Ni-Fe LDH stability scores.
    """
    from scipy.constants import Boltzmann, elementary_charge

    kT = Boltzmann * 298.15 / elementary_charge

    mu_H2 = reference_potentials.get("H2", -7.01)
    mu_H2O = reference_potentials.get("H2O", -14.2)

    def mu_H(U: float | np.ndarray) -> np.ndarray:
        return np.asarray(0.5 * mu_H2 - U + kT * np.log(10) * pH)

    def mu_O(U: float | np.ndarray) -> np.ndarray:
        return np.asarray(mu_H2O - 2 * mu_H(U))

    U_values = np.linspace(*U_range, steps)

    if unique_labels is None:
        unique_labels = list(reference_potentials.keys())

    unique_labels_dict = {u: i for i, u in enumerate(unique_labels)}
    M = len(unique_labels)

    def compute(dataset: Any) -> np.ndarray:
        y = dataset.get_all_energies()

        species, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")

        idx = np.fromiter((mapping.get(lbl, -1) for lbl in unique_labels), dtype=int, count=M)
        valid = idx >= 0

        X = np.zeros((species.shape[0], M), dtype=float)
        if np.any(valid):
            X[:, valid] = species[:, idx[valid]]

        base_mu = np.array([reference_potentials.get(lbl, 0.0) for lbl in unique_labels])

        base_mu[unique_labels_dict.get("H", -1)] = 0.0
        base_mu[unique_labels_dict.get("O", -1)] = 0.0

        fE_ref = y - X.dot(base_mu)

        nH = X[:, unique_labels_dict.get("H", 0)]
        nO = X[:, unique_labels_dict.get("O", 0)]

        muH_values = mu_H(U_values)
        muO_values = mu_O(U_values)

        fE_array = fE_ref[:, None] - nH[:, None] * muH_values[None, :] - nO[:, None] * muO_values[None, :]

        fE_hull = fE_array.min(axis=0, keepdims=True)
        min_distances = (fE_array - fE_hull).min(axis=1)

        return np.asarray(min_distances)

    setattr(compute, "scaling_logic", "linear")
    return compute


def objective_min_distance_to_electrochemicalhull_CuCOH(
    reference_potentials: dict[str, float],
    H_range: tuple[float, float],
    CO_range: tuple[float, float],
    spacing: float,
) -> Callable[[Any], np.ndarray]:
    r"""Compute electrochemical hull distance across a 2D mu_H and mu_CO grid for Cu-CO-H systems.

    .. note::
       This is a specific application objective function designed for Cu-CO-H catalyst
       surfaces (e.g. Copper with Carbon Monoxide and Hydrogen adsorbates). For general
       stability hulls, see `objective_min_distance_to_electrochemicalhull`.

    Implements a 2D chemical potential grid scan ($\mu_H$ and $\mu_{CO}$) to compute
    adsorbate formation energy:
    .. math::
       E_{form} = E_{total} - N_{Cu}\mu_{Cu} - N_H\mu_H - N_O\mu_O - N_C\mu_C
    Coupled to gaseous species references:
    .. math::
       \mu_C = \mu_{CO} - \mu_O
    .. math::
       \mu_O = \mu_{H_2O} - 2\mu_H

    Which mathematically reorganizes composition vectors:
    .. math::
       X_O \leftarrow X_O - X_C
    .. math::
       X_H \leftarrow X_H - 2X_O

    Args:
        reference_potentials: Baseline chemical potentials dictionary. Must include 
            values for 'H', 'CO', 'H2O', and 'Cu'.
        H_range: Chemical potential boundary scan (min_μH, max_μH) for Hydrogen.
        CO_range: Chemical potential boundary scan (min_μCO, max_μCO) for Carbon Monoxide.
        spacing: Sampling interval spacing step in eV.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing electrochemical hull distances.
    """
    def get_grid(x_range, y_range, spacing):
        x = np.arange(x_range[0], x_range[1] + spacing/2, spacing)
        y = np.arange(y_range[0], y_range[1] + spacing/2, spacing)
        return np.meshgrid(x, y)

    H_values, CO_values = get_grid(H_range, CO_range, spacing)

    missing = [k for k in ['H', 'CO', 'H2O', 'Cu'] if k not in reference_potentials]
    if missing:
        raise ValueError(f"reference potentials for {missing} is missing!")

    unique_labels = {'H', 'C', 'O', 'Cu'}
    unique_labels_dict = {u: i for i, u in enumerate(unique_labels)}

    def compute(dataset: Any) -> np.ndarray:
        y = dataset.get_all_energies()
        species, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")
        idx = np.fromiter((mapping.get(lbl, -1) for lbl in unique_labels), dtype=int, count=len(unique_labels))
        valid = (idx >= 0)
        X = np.zeros((species.shape[0], len(unique_labels)), dtype=species.dtype)
        if np.any(valid):
            X[:, valid] = species[:, idx[valid]]

        X[:, unique_labels_dict['O']] -= X[:, unique_labels_dict['C']]
        X[:, unique_labels_dict['H']] -= 2 * X[:, unique_labels_dict['O']]

        base_mu = np.array([reference_potentials.get(lbl, 0.0) for lbl in unique_labels])
        base_mu[unique_labels_dict['O']] = reference_potentials.get('H2O', 0.0)
        base_mu[unique_labels_dict['C']] = reference_potentials.get('CO', 0.0)

        fE_ref = y - X.dot(base_mu)
        nH = X[:, unique_labels_dict['H']]
        nC = X[:, unique_labels_dict['C']]

        fE_array = fE_ref[:, None, None] - nH[:, None, None]*H_values[None, :] - nC[:, None, None]*CO_values[None, :]

        front = np.min(fE_array, axis=0)
        distance_to_front = fE_array - front[None, :]

        return cast(np.ndarray, distance_to_front.min(axis=(1, 2)))

    setattr(compute, "scaling_logic", "linear")
    return compute
