from __future__ import annotations
import warnings
from typing import Any, Callable, Optional, List, Dict, Tuple, cast

import numpy as np
from numpy.linalg import inv

try:
    from sklearn.exceptions import ConvergenceWarning
    warnings.filterwarnings("ignore", category=ConvergenceWarning)
except ImportError:
    ConvergenceWarning = Any


def evaluate_objectives(structures: list[Any], objectives_funcs: Any) -> np.ndarray:
    r"""
    Compute multi-objective scores for a set of structures.

    This function applies one or more user-supplied objective functions to an
    array of structures and returns an (N, K) array of objective values,
    where N is the number of structures and K is the number of objectives.

    **Procedure**:

    1. **Single callable**
       If `objectives_funcs` is a single callable
       .. math::
          f: \{\text{structures}\} \;\to\; \mathbb{R}^{N \times K},
       then invoke
       ```python
         results = objectives_funcs(structures)
       ```
       and return it as a NumPy array.

    2. **List of K callables**
       If `objectives_funcs = [f_1, f_2, \dots, f_K]`, each with signature
       \\(f_k: \{\text{structures}\} \to \mathbb{R}^N\\), then compute
       .. math::
          \mathbf{o}_k = f_k(\text{structures}), \quad k=1,\dots,K,
       stack them column-wise
       .. math::
          O = [\,\mathbf{o}_1,\dots,\mathbf{o}_K\,] \in \mathbb{R}^{N\times K}.
       This is implemented as:
       ```python
       np.array([ func(structures) for func in objectives_funcs ]).T
       ```

    3. **Return shape**
       Always returns a NumPy array of shape \\((N,K)\\), suitable for downstream
       selection and analysis routines.

    :param structures:
        List of N structure objects. Each object is passed to the objective functions.
    :type structures: list[Any]
    :param objectives_funcs:
        Either a single callable returning an (N,K) array, or a list of K callables
        each returning an (N,) array of values.
    :type objectives_funcs: callable or list[callable]
    :returns:
        NumPy array of shape (N, K) containing objective values.
    :rtype: numpy.ndarray

    :raises ValueError:
        If `objectives_funcs` is a list but the returned shapes do not align, or
        if the inputs are not callable.
    """
    if isinstance(objectives_funcs, list):
        return cast(np.ndarray, np.array([func(structures) for func in objectives_funcs]).T)
    else:
        return np.asarray([objectives_funcs(structures)])


def _get_positions_list(dataset: Any, coordinate_system: str = "cartesian") -> list[np.ndarray]:
    """Retrieve atomic positions for all structures from the dataset with safe fallbacks.

    Extracts coordinates from the dataset using the bulk `get_all_positions()` method,
    or falls back to iterating over individual structure instances and their
    associated `AtomPositionManager` configurations.

    Args:
        dataset: The dataset or list of structures to extract coordinates from.
        coordinate_system: The coordinate representation to use (e.g., 'cartesian'
            or 'fractional'). Defaults to "cartesian".

    Returns:
        list[np.ndarray]: A list of length N containing NumPy arrays of shape (n_i, 3) 
            representing the coordinate matrix for each structure.

    Raises:
        ValueError: If the dataset does not provide a coordinate extraction API 
            and is not iterable.
    """
    if hasattr(dataset, "get_all_positions"):
        try:
            return cast(list[np.ndarray], dataset.get_all_positions(coordinate_system=coordinate_system))
        except TypeError:
            return cast(list[np.ndarray], dataset.get_all_positions())

    structs: list[Any] | None = None
    try:
        structs = list(dataset)
    except TypeError:
        structs = getattr(dataset, "structures", None)
    if structs is None:
        raise ValueError("Dataset does not provide positions API nor is iterable over structures.")

    pos_list = []
    for s in structs:
        apm = getattr(s, "AtomPositionManager", s)
        P = getattr(apm, "atomPositions", None)
        pos_list.append(np.asarray(P, dtype=float) if P is not None else np.zeros((0, 3), dtype=float))
    return pos_list


def _get_lattice_vectors_list(dataset: Any) -> list[np.ndarray]:
    """Retrieve lattice vector matrices for all structures with identity matrix fallbacks.

    First attempts to leverage high-performance dataset-level batch calls (`get_all_lattice_vectors`).
    If not available, falls back to iterating through structures to fetch `latticeVectors` 
    from their `AtomPositionManager`. If no lattice is defined, it defaults to a standard 
    3x3 identity matrix (representing an isolated/non-periodic boundaries system).

    Args:
        dataset: The dataset or structural container instance to query.

    Returns:
        list[np.ndarray]: A list of length N containing 3x3 matrices representing 
            the lattice vectors of each individual structure.

    Raises:
        ValueError: If lattice vectors cannot be retrieved and the dataset's size 
            cannot be inferred.
    """
    if hasattr(dataset, "get_all_lattice_vectors"):
        try:
            return cast(list[np.ndarray], dataset.get_all_lattice_vectors())
        except Exception:
            pass

    structs: list[Any] | None = None
    try:
        structs = list(dataset)
    except TypeError:
        structs = getattr(dataset, "structures", None)
    if structs is None:
        try:
            N = len(dataset.get_all_energies())
        except Exception:
            raise ValueError("Cannot access lattice vectors from dataset.")
        return [np.eye(3) for _ in range(N)]

    mats = []
    for s in structs:
        apm = getattr(s, "AtomPositionManager", s)
        L = getattr(apm, "latticeVectors", None)
        if L is None:
            mats.append(np.eye(3))
        else:
            mats.append(np.asarray(L, dtype=float))
    return mats


def _get_normalization_factor(dataset: Any, A: Any) -> tuple[np.ndarray, bool]:
    """Calculate the normalization factor vector for chemical/formation energy objectives.

    Normalizes absolute thermodynamic values to standard quantities like:
      - Energy per atom
      - Energy per unit volume
      - Energy per surface area
      - Constant user-specified scale factor

    Args:
        dataset: The dataset instance from which structural information is read.
        A: The normalization instruction:
            - None or "atoms": Norm is the total atom count per structure.
            - "volume": Norm is the cell volume (determinant of lattice vectors).
            - "area": Norm is the surface area (cross product of first two lattice vectors).
            - numeric (int, float): Norm is a constant scale factor applied to all structures.

    Returns:
        tuple[np.ndarray, bool]: A tuple containing:
            - norm (np.ndarray): Array of shape (N,) containing normalization factors.
            - use_fractions (bool): True if compositions are normalized by atomic count fraction.
    """
    if A is None or (isinstance(A, str) and A.lower() == "atoms"):
        X, _ = dataset.get_all_compositions(return_species=True)
        norm = X.sum(axis=1).astype(float)
        norm[norm == 0.0] = 1.0
        return norm, True

    if isinstance(A, str):
        mode = A.lower()
        if mode == "volume":
            if hasattr(dataset, "get_all_volumes"):
                return np.asarray(dataset.get_all_volumes(), dtype=float), False
            lattices = dataset.get_all_lattice_vectors()
            vols = np.array([abs(np.linalg.det(L)) for L in lattices])
            vols[vols == 0.0] = 1.0
            return vols, False

        if mode == "area":
            if hasattr(dataset, "get_all_areas"):
                return np.asarray(dataset.get_all_areas(), dtype=float), False
            lattices = dataset.get_all_lattice_vectors()
            areas = np.array([np.linalg.norm(np.cross(L[0], L[1])) for L in lattices])
            areas[areas == 0.0] = 1.0
            return areas, False

    if isinstance(A, (int, float)):
        N = len(dataset.get_all_energies())
        return np.full(N, float(A), dtype=float), False

    N = len(dataset.get_all_energies())
    return np.ones(N, dtype=float), False


def _fit_mu_from_dataset(X: np.ndarray, y: np.ndarray, use_fractions: bool) -> np.ndarray:
    """Estimate elemental chemical potentials (μ) via linear least squares.

    Solves the overdetermined linear system:
        D · μ ≈ y
    Where D represents composition (absolute counts or atomic fractions) and y
    represents the energy array. Employs singular value decomposition (SVD) and handles 
    zero-variance columns defensively to prevent numerical instabilities.

    Args:
        X (np.ndarray): Composition matrix of shape (N, M), where N is the number of 
            structures and M is the number of species.
        y (np.ndarray): Energies array of shape (N,).
        use_fractions (bool): If True, normalizes each composition row by its total atom
            count (converting counts to atomic fractions) prior to solving the least squares fit.

    Returns:
        np.ndarray: Vector of shape (M,) containing the estimated chemical potential (μ) 
            for each element/species.
    """
    if use_fractions:
        N_atoms = X.sum(axis=1, keepdims=True).astype(float)
        N_atoms[N_atoms == 0.0] = 1.0
        D = X / N_atoms
        y_fit = y / N_atoms.ravel()
    else:
        D = X.astype(float)
        y_fit = y.astype(float)

    col_var = D.var(axis=0)
    informative = col_var > 0.0

    mu = np.zeros(D.shape[1], dtype=float)
    if np.any(informative):
        mu_inf, *_ = np.linalg.lstsq(D[:, informative], y_fit, rcond=None)
        mu[informative] = mu_inf
    return mu


def naive_objectives(dataset: Any, objective_funcs: list[Callable[[Any], np.ndarray]]) -> np.ndarray:
    """Evaluate a set of separate objective callables on a dataset, returning stacked values.

    Applies each function sequentially and constructs an (N, K) column-wise matrix.
    Includes robust broadcasting for scalar results, zero padding for mismatched shapes, 
    and silent exception handling (leaving a column of zeros if an objective fails).

    Args:
        dataset: The dataset instance containing the structures to evaluate.
        objective_funcs: List of K callable functions. Each callable must accept 
            the dataset and return an array of values of shape (N,).

    Returns:
        np.ndarray: Array of shape (N, K) containing evaluated objective values.
    """
    try:
        N = len(dataset.get_all_energies())
    except Exception:
        X_all, _ = dataset.get_all_compositions(return_species=True)
        N = X_all.shape[0]

    K = len(objective_funcs)
    out = np.zeros((N, K), dtype=float)

    for j, f in enumerate(objective_funcs):
        try:
            col = f(dataset)
            col = np.asarray(col, dtype=float).reshape(-1)
            if col.shape[0] != N:
                if col.size == 1:
                    out[:, j] = col.item()
                else:
                    m = min(N, col.shape[0])
                    out[:m, j] = col[:m]
            else:
                out[:, j] = col
        except Exception:
            pass
    return np.asarray(out)


def find_optimal_kmeans_k(data: np.ndarray, max_k: int = 10, random_state: int = 42) -> int:
    """Determine the optimal number of clusters using average Silhouette analysis.

    Scans the number of clusters `k` in range `[2, max_k]`, constructs KMeans models,
    and returns the `k` that maximizes the silhouette coefficient.
    If the number of samples is insufficient (< 2), defaults to 1.

    Args:
        data (np.ndarray): Feature matrix of shape (n_samples, n_features) to cluster.
        max_k (int): Upper bound of the cluster scanning search space. Defaults to 10.
        random_state (int): Seed to initialize the KMeans centroid generator. Defaults to 42.

    Returns:
        int: The optimal number of clusters k.
    """
    try:
        from sklearn.cluster import KMeans
        from sklearn.metrics import silhouette_score
    except ImportError:
        return 1

    data = np.asarray(data)
    if data.ndim == 1:
        data = data.reshape(-1, 1)

    n_samples = data.shape[0]
    if n_samples < 2:
        return 1

    best_k = 2
    best_silhouette = -1

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=ConvergenceWarning)
        for k in range(2, max_k + 1):
            if k >= n_samples:
                break
            try:
                kmeans = KMeans(n_clusters=k, random_state=random_state, n_init="auto")
                labels = kmeans.fit_predict(data)
                if len(set(labels)) < 2:
                    continue
                score = silhouette_score(data, labels)
                if score > best_silhouette:
                    best_silhouette = score
                    best_k = k
            except Exception:
                continue
    return best_k
