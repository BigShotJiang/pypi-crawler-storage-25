from __future__ import annotations
from typing import Any, Callable

import numpy as np

from ezga.evaluator.objectives.base import _get_positions_list, _get_lattice_vectors_list


def objective_volume() -> Callable[[Any], np.ndarray]:
    r"""Compute the cell volume of each atomic structure from its lattice vectors.

    For each structure in the dataset, the volume of the unit cell is calculated
    as the absolute determinant of the 3x3 lattice vector matrix:
    .. math::
       V = \left| \det(\mathbf{L}) \right|

    If a structure lacks defined lattice vectors, its volume defaults to `0.0`.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing the volume of each structure.
    """
    def compute(dataset: Any) -> np.ndarray:
        mats = _get_lattice_vectors_list(dataset)
        vols = []
        for L in mats:
            try:
                vols.append(abs(np.linalg.det(np.asarray(L, dtype=float))))
            except Exception:
                vols.append(0.0)
        return np.asarray(vols, dtype=float)

    setattr(compute, "scaling_logic", "linear")
    return compute


def objective_density(atomic_weights: dict[str, float] | None = None) -> Callable[[Any], np.ndarray]:
    r"""Compute the mass density of each atomic structure.

    Calculates the mass density per unit cell volume for each structure in the dataset:
    .. math::
       \rho = \frac{\sum_{i} n_i \cdot w_i}{V}
    Where $n_i$ represents the count of atoms of species $i$, $w_i$ is their atomic weight, 
    and $V$ is the cell volume.

    Args:
        atomic_weights: A dictionary mapping species symbols (e.g., 'Fe', 'O') 
            to their atomic mass/weights. If None, all species are assumed to have
            a weight of `1.0` (calculating atom number density). Defaults to None.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing the mass density of each structure.
    """
    def compute(dataset: Any) -> np.ndarray:
        X_all, species_order = dataset.get_all_compositions(return_species=True)
        N = X_all.shape[0]
        if atomic_weights is None:
            w = np.ones(len(species_order), dtype=float)
        else:
            w = np.array([atomic_weights.get(lbl, 1.0) for lbl in species_order], dtype=float)

        total_mass = X_all.dot(w)

        mats = _get_lattice_vectors_list(dataset)
        vols = np.empty(N, dtype=float)
        for i, L in enumerate(mats):
            try:
                vols[i] = abs(np.linalg.det(np.asarray(L, dtype=float)))
            except Exception:
                vols[i] = 1.0

        with np.errstate(divide="ignore", invalid="ignore"):
            dens = np.where(vols > 0, total_mass / vols, 0.0)
        dens = np.nan_to_num(dens, nan=0.0, posinf=0.0, neginf=0.0)
        return np.asarray(dens)

    setattr(compute, "scaling_logic", "invariant")
    return compute


def objective_average_interatomic_distance(coordinate_system: str = "cartesian") -> Callable[[Any], np.ndarray]:
    r"""Compute the average pairwise interatomic distance for each structure.

    Calculates the arithmetic mean of all unique pairwise Euclidean distances between
    atoms inside each structure:
    .. math::
       \bar{d} = \frac{2}{N_{atoms}(N_{atoms} - 1)} \sum_{i < j} d(x_i, x_j)

    Args:
        coordinate_system: The coordinate representation to fetch positions from
            (e.g., 'cartesian' or 'fractional'). Defaults to "cartesian".

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing the mean interatomic distance.
    """
    from scipy.spatial.distance import pdist

    def compute(dataset: Any) -> np.ndarray:
        pos_list = _get_positions_list(dataset, coordinate_system=coordinate_system)
        out = []
        for P in pos_list:
            P = np.asarray(P, dtype=float)
            if P.ndim != 2 or P.shape[0] < 2:
                out.append(0.0)
                continue
            try:
                d = pdist(P)
                out.append(float(np.mean(d))) if d.size else out.append(0.0)
            except Exception:
                out.append(0.0)
        return np.asarray(out, dtype=float)

    setattr(compute, "scaling_logic", "size_dependent")
    return compute


def objective_coordination_number(cutoff: float = 3.0, coordinate_system: str = "cartesian") -> Callable[[Any], np.ndarray]:
    r"""Compute the average coordination number (CN) for each structure.

    The coordination number of each individual atom is defined as the number of neighbors
    within the specified Euclidean radial cutoff distance. The structural coordination
    number is the mean coordination number across all atoms in the structure:
    .. math::
       \text{CN} = \frac{1}{N_{atoms}} \sum_{i} \sum_{j \neq i} \mathbb{I}\left( d(x_i, x_j) < r_{cutoff} \right)

    Args:
        cutoff: Radial cutoff distance in Angstroms. Defaults to 3.0.
        coordinate_system: The coordinate representation to fetch positions from.
            Defaults to "cartesian".

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing the average coordination number.
    """
    from scipy.spatial.distance import pdist, squareform

    def compute(dataset: Any) -> np.ndarray:
        pos_list = _get_positions_list(dataset, coordinate_system=coordinate_system)
        out = []
        for P in pos_list:
            P = np.asarray(P, dtype=float)
            n = P.shape[0] if P.ndim == 2 else 0
            if n <= 1:
                out.append(0.0)
                continue
            try:
                D = squareform(pdist(P))
                np.fill_diagonal(D, np.inf)
                cn = np.sum(D < float(cutoff), axis=1)
                out.append(float(np.mean(cn)))
            except Exception:
                out.append(0.0)
        return np.asarray(out, dtype=float)

    setattr(compute, "scaling_logic", "invariant")
    return compute


def objective_symmetry(
    coordinate_system: str = "cartesian",
    use_mass_weights: bool = False,
    normalize_by_mean: bool = False,
) -> Callable[[Any], np.ndarray]:
    r"""Compute a structural symmetry dispersion score.

    This objective evaluates structural symmetry based on the standard deviation of
    atomic radial distances from the center of mass (or geometric centroid):
    .. math::
       \sigma_R = \sqrt{\frac{1}{N_{atoms}} \sum_{i} (d(x_i, c) - \bar{d})^2 }
    Where $c$ is the centroid or center of mass and $\bar{d}$ is the average radial distance. 
    A lower standard deviation indicates a more isotropic, spherical, and symmetric atom 
    distribution.

    Args:
        coordinate_system: The coordinate representation to fetch positions from.
            Defaults to "cartesian".
        use_mass_weights: If True, calculates the true center of mass using atomic
            masses rather than the geometric centroid. Defaults to False.
        normalize_by_mean: If True, normalizes the radial standard deviation by the mean 
            radial distance (coefficient of variation $\sigma_R / \bar{d}$). Defaults to False.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing the symmetry score.
    """
    def _center(points: np.ndarray, masses: np.ndarray | None) -> np.ndarray:
        if points.size == 0:
            return np.zeros(3, dtype=float)
        if masses is not None and use_mass_weights:
            m = np.asarray(masses, dtype=float).reshape(-1, 1)
            m[m <= 0] = 0.0
            denom = m.sum()
            if denom > 0:
                return np.asarray((points * m).sum(axis=0) / denom)
        return np.asarray(points.mean(axis=0))

    def _score_from_positions(points: np.ndarray | None, masses: np.ndarray | None) -> float:
        if points is None or points.ndim != 2 or points.shape[0] == 0:
            return 0.0
        c = _center(points, masses)
        d = np.linalg.norm(points - c, axis=1)
        if d.size == 0:
            return 0.0
        sd = float(np.std(d))
        if normalize_by_mean:
            mu = float(np.mean(d))
            return sd / mu if mu > 0 else 0.0
        return sd

    def _try_dataset_positions(dataset: Any) -> tuple[list[np.ndarray] | None, list[np.ndarray] | None]:
        positions_list = None
        masses_list = None
        if hasattr(dataset, "get_all_positions"):
            try:
                positions_list = dataset.get_all_positions(coordinate_system=coordinate_system)
            except TypeError:
                positions_list = dataset.get_all_positions()
        if hasattr(dataset, "get_all_masses"):
            try:
                masses_list = dataset.get_all_masses()
            except Exception:
                masses_list = None
        return positions_list, masses_list

    def compute(dataset: Any) -> np.ndarray:
        positions_list, masses_list = _try_dataset_positions(dataset)
        scores = []
        if positions_list is not None:
            for i, P in enumerate(positions_list):
                masses = None
                if use_mass_weights and masses_list is not None and i < len(masses_list):
                    masses = masses_list[i]
                    if masses is not None and len(masses) != len(P):
                        masses = None
                scores.append(_score_from_positions(np.asarray(P, dtype=float), masses))
            return np.asarray(scores, dtype=float)

        structs: list[Any] | None = None
        try:
            structs = list(dataset)
        except TypeError:
            structs = getattr(dataset, "structures", None)
            if structs is None:
                raise ValueError("Dataset does not provide positions API nor is iterable over structures.")

        for s in structs:
            apm = getattr(s, "AtomPositionManager", s)
            P_raw = getattr(apm, "atomPositions", None)
            P_struct: np.ndarray | None = np.asarray(P_raw, dtype=float) if P_raw is not None else None
            masses = None
            if use_mass_weights:
                masses = getattr(getattr(s, "AtomPositionManager", s), "atomMasses", None)
            masses = np.asarray(masses, dtype=float) if masses is not None else None
            if masses is not None and P_struct is not None and len(masses) != len(P_struct):
                masses = None
            scores.append(_score_from_positions(P_struct, masses))
        return np.asarray(scores, dtype=float)

    setattr(compute, "scaling_logic", "invariant" if normalize_by_mean else "linear_length")
    return compute


def objective_amorphisation(
) -> Callable[[Any], np.ndarray]:
    """
    Computes structural amorphisation scores using the Earth Mover's Distance (EMD) 
    between the radial distribution function (RDF) of candidate structures and an 
    analytical random baseline distribution.

    Robustness Design Advantages over Legacy Implementation:
    1. Polymorphic Distance Extraction: Natively handles varying API signatures across 
       real SAGE models (methods vs callable descriptors) and test mock structures 
       (ASE .atoms vs .AtomPositionManager attributes) preventing AttributeError/TypeError.
    2. Dimensionality & Boundary Protection: Restricts self-interaction filters with 
       defensive NoneType, empty matrix, and zero-atom checks, preventing out-of-bounds 
       index or empty slicing exceptions.
    3. Mathematical Continuity: Safeguards normalization factors against pathological or 
       un-relaxed structures (e.g. N=0 atoms) preventing float division-by-zero (NaN/Inf).
    """
    from itertools import product
    from ase.data import vdw_radii, atomic_numbers
    import numpy as np
    
    def _generate_random_distance_distribution(n_samples: int = 100) -> np.ndarray:
        """
        Analytical solution to the probability distribution of distances between random points in a unit cell, filtered to remove self-interaction distances. This is used as a baseline for the RDF comparison in the amorphisation objective. 

        Found in Markus Deserno notes 'How to calculate a three-dimensional g(r) under periodic boundary conditions' found here: https://www.cmu.edu/biolphys/deserno/random_acts_of_knowledge.html

        the distribution is split into three regimes: 
            1. distances less than 0.5, where the distribution is proportional to the surface area of a sphere
            2. distances between 0.5 and sqrt(2)/2, where the sphere sourface area is truncated by the unit cell faces 
            3. distances between sqrt(2)/2 and sqrt(3)/2, where the sphere sourface area is truncated by the unit cell edges
        
        Parameters        
        ----------
        n_samples : int
            Number of distance samples to generate between 0 and sqrt(3)/2 (the maximum distance in a unit cell).
        Returns
        -------
        np.ndarray
            An array of shape (n_samples,) containing the probability distribution of distances between random points in a unit cell.
        """
        
        def sphere_surface_area(r):
            return 4 * np.pi * r**2

        def sphere_surface_area_face_clipping(r):
            return 2 * np.pi * r * (3-4*r)

        def sphere_surface_area_edge_clipping(r):
            f1=np.arctan(np.sqrt(4*r**2 - 2))
            f2=8*r *np.arctan((2*r*(4*r**2 -3)/(np.sqrt(4*r**2 -2)*(4*r**2 +1))))
            return 2*r*(3*np.pi - 12*f1 + f2)

        point_array=np.zeros(n_samples)
        for i, r in enumerate(np.linspace(0, np.sqrt(3)/2, n_samples)):
            if r > 0 and r < 0.5:
                point_array[i] = sphere_surface_area(r)
            elif r >= 0.5 and r < np.sqrt(2)/2:
                point_array[i] = sphere_surface_area_face_clipping(r)
            elif r >= np.sqrt(2)/2 and r < np.sqrt(3)/2:
                point_array[i] = sphere_surface_area_edge_clipping(r)

        normalized_point_array = point_array 

        return normalized_point_array
       
    def _filter_self_interaction_distances(
        distances: np.ndarray,
        unit_cell_array: np.ndarray,
        self_atom_tolerance: float = 1E-5,
    ) -> np.ndarray:
        """
        Filter distances based on a minimum and maximum distance.

        Args:
            distances (np.ndarray): The array of distances to filter.
            min_distance (float): The minimum distance to include.
            max_distance (float): The maximum distance to include.
            unit_cell_array (np.ndarray): The array representing the unit cell vectors.
            self_atom_tolerance (float): Tolerance for identifying self-atom distances.
        Returns:
            np.ndarray: The filtered array of distances.
        """
        if distances is None or not isinstance(distances, np.ndarray) or distances.size == 0:
            return np.array([], dtype=float)
        # remove distances that are self-atom distances
        forbidden_distance_list = []
        for i in range(-1, 2):
            for j in range(-1, 2):
                for k in range(-1, 2):
                    shift = np.array([i, j, k]) @ unit_cell_array
                    forbidden_distance_list.append(np.linalg.norm(shift))

        
        for self_atom_distance in forbidden_distance_list:
            distances = distances[
                ((distances < self_atom_distance - self_atom_tolerance) | (distances > self_atom_distance + self_atom_tolerance))
            ]

        return distances

    
    def _rdf(distances, bins=100, r_min=0.0, r_max=20.0):
        """
        Compute the radial distribution function (RDF) from a set of distances.
        Parameters
        ----------
        distances : np.ndarray
            Array of distances between atoms.
        bins : int
            Number of bins to use for the histogram.
        r_min : float
            Minimum distance to consider for the RDF.
        r_max : float
            Maximum distance to consider for the RDF.
        Returns
        -------
        r : np.ndarray
            The midpoints of the distance bins.
        rdf_hist : np.ndarray
            The histogram counts for each distance bin, representing the RDF.
        """
        rdf_hist, edges = np.histogram(
            distances, bins=bins, density=False, range=(r_min, r_max)
        )
        r = 0.5 * (edges[1:] + edges[:-1])
        return r, rdf_hist


    def _max_pbc_distance(cell: np.ndarray) -> float:
        """
        Compute the maximum possible minimum-image distance in a 3D periodic cell.

        Under the minimum image convention, the fractional displacement between any
        two points lies in [-0.5, 0.5)^3. The Cartesian distance ||s @ cell|| is a
        convex function of s, so its maximum over the hypercube [-0.5, 0.5]^3 is
        attained at one of the 8 corners. We evaluate all 8 and return the largest norm.

        Works exactly for all cell geometries: cubic, orthorhombic, and triclinic.

        Parameters
        ----------
        cell : np.ndarray, shape (3, 3)
            Lattice matrix where rows are the lattice vectors:
            cell[0] = a, cell[1] = b, cell[2] = c.

        Returns
        -------
        float
            Maximum Euclidean distance under the minimum image convention.
        """
        cell = np.asarray(cell, dtype=float)
        corners = np.array(list(product([-0.5, 0.5], repeat=3)), dtype=float)
        cartesian = corners @ cell
        return float(np.max(np.linalg.norm(cartesian, axis=1)))
    
    def _earth_mover_distance(rdf1: np.ndarray, rdf2: np.ndarray) -> float:
        """
        Compute the Earth Mover's Distance (EMD) between two radial distribution functions (RDFs).

        Parameters:
            rdf1 (np.ndarray): The first RDF histogram (not normalized).
            rdf2 (np.ndarray): The second RDF histogram (not normalized).

        Returns:
            float: The Earth Mover's Distance between the two RDFs.
        """

        # Compute the cumulative distribution functions (CDFs)
        cdf1 = np.cumsum(rdf1)
        cdf2 = np.cumsum(rdf2)

        # Compute the EMD as the area between the two CDFs
        emd = np.sum(np.abs(cdf1 - cdf2))

        return emd   

    # Pre computation of random baseline from analytical solution
    
    bins: int = 1000 # number of bins for RDF calculation
    rdf_baseline_pre = _generate_random_distance_distribution(bins)   


    def compute(dataset: Any) -> np.ndarray:
        # Compute amorphousness scores based on the difference between the RDF of each structure and the scaled random baseline RDF
        amorphousness_scores = np.zeros(len(dataset), dtype=float)
    
        lattice_vectors=_get_lattice_vectors_list(dataset)
        species_count, species_list = dataset.get_all_compositions(return_species=True)
        atom_counts = np.sum(species_count, axis=1)
        exclusion_radius=float(max([vdw_radii[atomic_numbers[s]] * 2 for s in species_list]))
    
        for i, structure in enumerate(dataset):
            max_distance_pbc=_max_pbc_distance(lattice_vectors[i])
            
            # Safe distance matrix retrieval supporting both SAGE models and mocks
            apm = getattr(structure, "AtomPositionManager", structure)
            if hasattr(apm, "distance_matrix"):
                dm = apm.distance_matrix
                distances = dm().flatten() if callable(dm) else np.asarray(dm).flatten()
            elif hasattr(structure, "atoms") and hasattr(structure.atoms, "distance_matrix"):
                dm = structure.atoms.distance_matrix
                distances = dm().flatten() if callable(dm) else np.asarray(dm).flatten()
            else:
                distances = structure.AtomPositionManager.distance_matrix.flatten()

            filtered_distance = _filter_self_interaction_distances(
                distances=distances,
                unit_cell_array=lattice_vectors[i],
                self_atom_tolerance=1E-5,
            )
            rd, rdf_distances = _rdf(
                filtered_distance,
                r_min=0,
                r_max=max_distance_pbc,
                bins=bins,
            )

            # exclude local ordering
            bucket_exlusions = rd < exclusion_radius
            rd = rd[~bucket_exlusions]
            rdf_distances = rdf_distances[~bucket_exlusions]
            rdf_baseline = rdf_baseline_pre[~bucket_exlusions]

            # normalize the RDFs so that the area under the curve is 1 for both the real and random structures, to make them comparable
            rdf_distances = rdf_distances / rdf_baseline.sum()
            rdf_baseline = rdf_baseline / rdf_baseline.sum()
            
            denom = int(atom_counts[i]) if atom_counts[i] > 0 else 1
            amorphousness_scores[i] = _earth_mover_distance(rdf_distances, rdf_baseline) / denom

        return amorphousness_scores
        
    return compute

