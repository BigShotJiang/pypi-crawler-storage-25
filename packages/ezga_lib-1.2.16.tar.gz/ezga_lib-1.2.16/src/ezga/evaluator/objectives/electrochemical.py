from __future__ import annotations
from typing import Any, Callable

import numpy as np


def objective_min_distance_to_hull_pourbaix_diagram(pd: Any, references_species: list[Any]) -> Callable[[Any], np.ndarray]:
    r"""Compute structural stability distance using a formal Pourbaix diagram.

    Collects energetic and compositional candidates from the GA population, inserts
    them into a thermodynamic `PourbaixDiagram` instance, and calculates their 
    distance to the computed Pourbaix multi-species convex hull.

    Expected Dataset API:
      - Iterating dataset returns structures.
      - Each structure has `structure.AtomPositionManager.atomCountDict` and `structure.AtomPositionManager.E`.

    Args:
        pd: A Pourbaix diagram builder instance (e.g. from `ezga.utils.pourbaix_diagram`).
        references_species: A list of baseline/reference chemical species to include 
            in the background hull calculation.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing Pourbaix diagram hull distances.
    """
    from collections import defaultdict
    from ezga.utils.pourbaix_diagram import Species

    def objective(dataset: Any) -> np.ndarray:
        pd._candidate_species = {}
        pd._name_counts = defaultdict(int)

        for structure in dataset:
            name = "".join([f"{item}{key}" for item, key in structure.AtomPositionManager.atomCountDict.items()])
            pd.add_candidate_species(Species(name, G=structure.AtomPositionManager.E))

        distances = pd.distance_convex_hull(reference_species=references_species, baseline_specie=None)
        return np.asarray(distances)

    return objective


def objective_min_distance_to_electrochemicalhull(
    reference_potentials: dict[str, float],
    H_range: tuple[float, float] = (-1.0, 0.5),
    steps: int = 100,
    unique_labels: list[str] | None = None,
) -> Callable[[Any], np.ndarray]:
    r"""Compute the minimal distance to the electrochemical convex hull.

    Scans a range of hydrogen chemical potentials ($\mu_H$) representing an applied
    electrochemical potential (U) to compute distance above the electrochemical
    stability hull:
    .. math::
       E_{electro} = E_{total} - \sum \mu_{base} \cdot N_{base} - \mu_O \cdot N_O - \mu_H \cdot N_H
    Where the chemical potential of oxygen is coupled to water stability:
    .. math::
       \mu_O = \mu_{H2O} - 2\mu_H

    Args:
        reference_potentials: Dict mapping background element symbols (e.g. 'Fe', 'H2O')
            to their reference potentials.
        H_range: Range of hydrogen potentials (min_μH, max_μH) to scan. Defaults to (-1.0, 0.5).
        steps: Number of potential steps to evaluate in the scanned range. Defaults to 100.
        unique_labels: Ordered list of chemical species labels to include.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing electrochemical hull distances.
    """
    if unique_labels is None:
        labels = list({lbl for lbl in reference_potentials.keys()}.union({"O", "H"}) - {"H2O"})
    else:
        labels = unique_labels
    unique_labels_dict = {u: i for i, u in enumerate(labels)}

    def compute(dataset: Any) -> np.ndarray:
        y = dataset.get_all_energies()

        species, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")
        idx = np.fromiter((mapping.get(lbl, -1) for lbl in labels), dtype=int, count=len(labels))
        valid = idx >= 0
        X = np.zeros((species.shape[0], len(labels)), dtype=species.dtype)
        if np.any(valid):
            X[:, valid] = species[:, idx[valid]]

        X[:, unique_labels_dict["H"]] -= 2 * X[:, unique_labels_dict["O"]]

        base_mu = np.array([reference_potentials.get(lbl, 0.0) for lbl in labels])
        base_mu[unique_labels_dict["O"]] = reference_potentials.get("H2O", 0.0)

        fE_ref = y - X.dot(base_mu)
        nH = X[:, unique_labels_dict["H"]]

        H_values = np.linspace(H_range[0], H_range[1], steps)

        fE_array = fE_ref[:, None] - nH[:, None] * H_values[None, :]
        fE_hull = fE_array.min(axis=0, keepdims=True)
        min_distances = (fE_array - fE_hull).min(axis=1)

        return np.asarray(min_distances)

    setattr(compute, "scaling_logic", "linear")
    return compute


def objective_min_distance_to_O_hull(
    reference_potentials: dict[str, float],
    H_range: tuple[float, float] = (-1.0, 0.5),
    steps: int = 100,
    unique_labels: list[str] | None = None,
) -> Callable[[Any], np.ndarray]:
    r"""Compute minimal distance to the oxygen-variable electrochemical convex hull.

    Varies oxygen chemical potential ($\mu_O$) across a potential range to calculate 
    distance above the oxygen-variable stability hull.

    Args:
        reference_potentials: Dict mapping background element symbols to reference potentials.
        H_range: Range of oxygen chemical potentials to scan. Defaults to (-1.0, 0.5).
        steps: Number of potential steps to evaluate in the scanned range. Defaults to 100.
        unique_labels: Ordered list of chemical species labels to include.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing O-hull distances.
    """
    labels = list(reference_potentials.keys())
    unique_labels_dict = {u: i for i, u in enumerate(labels)}

    def compute(dataset: Any) -> np.ndarray:
        y = dataset.get_all_energies()

        species, species_order = dataset.get_all_compositions(return_species=True)
        mapping = dataset.get_species_mapping(order="stored")
        idx = np.fromiter((mapping.get(lbl, -1) for lbl in labels), dtype=int, count=len(labels))
        valid = idx >= 0
        X = np.zeros((species.shape[0], len(labels)), dtype=species.dtype)
        if np.any(valid):
            X[:, valid] = species[:, idx[valid]]

        base_mu = np.array([reference_potentials.get(lbl, 0.0) for lbl in labels])

        fE_ref = y - X.dot(base_mu)
        nO = X[:, unique_labels_dict["O"]]

        mu_values = np.linspace(H_range[0], H_range[1], steps)

        fE_array = fE_ref[:, None] - nO[:, None] * mu_values[None, :]
        fE_hull = fE_array.min(axis=0, keepdims=True)
        min_distances = (fE_array - fE_hull).min(axis=1)

        return np.asarray(min_distances)

    return compute


def objective_integral() -> Callable[[Any], np.ndarray]:
    r"""Maximize the 'integral' metadata value of structures.

    This objective extracts the 'integral' value from the metadata dictionary
    of each structure. The GA maximizes this metric by returning the negated,
    nan-to-zero cleaned array.

    Expected Dataset API:
      - `dataset.get_all_metadata("integral")`: Returns a list of metadata values.

    Returns:
        Callable[[Any], np.ndarray]: A function that accepts a dataset and returns
            a NumPy array of shape (N,) containing negated integral values.
    """
    def compute(dataset: Any) -> np.ndarray:
        vals = dataset.get_all_metadata("integral")
        clean = np.array([0.0 if v is None else v for v in vals], dtype=float)
        res = -np.nan_to_num(clean, nan=0.0)
        return np.asarray(res)

    setattr(compute, "scaling_logic", "linear")
    return compute
