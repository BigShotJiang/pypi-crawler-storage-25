from __future__ import annotations
# SPDX-License-Identifier: MIT

"""Factory helpers to build a fully wired GeneticAlgorithm from config.

This module centralizes two user-facing primitives:

* :func:`load_config` — convert user configuration (YAML path or dict) into a
  validated :class:`GAConfig`. When a path is provided, it delegates to the
  YAML loader under :mod:`ezga.io.config_loader` so you reuse the same parsing,
  validation, and dotted-path resolution logic across CLI and notebooks.

* :func:`build_default_engine` — instantiate all concrete components (population,
  thermostat, evaluator, selector, variation, simulator, convergence, logger,
  plotter), wire them together, and return a ready-to-run
  :class:`~ezga.core.engine.GeneticAlgorithm`.

Design goals:
  - Keep the engine constructor free of wiring/DI concerns.
  - Provide explicit dependency-injection points (overrides) for testing or
"""

import warnings
import numpy as np
from pathlib import Path
from typing import Any, Union

from ezga.convergence.convergence import Convergence
from ezga.core.config import GAConfig
from ezga.core.context import Context
from ezga.core.engine import GeneticAlgorithm
from ezga.core.interfaces import (
    IAgent,
    IConvergence,
    IEvaluator,
    IGenerative,
    IHash,
    ILineage,
    ILogger,
    IPlotter,
    IPopulation,
    ISelector,
    ISimulator,
    IThermostat,
    ITransitionKernel,
    IVariation,
)
from ezga.core.population import Population
from ezga.evaluator.evaluator import Evaluator
from ezga.generative.models.bo_generative import BOGenerative

# YAML path loading & dotted-path resolution are delegated here
from ezga.io.config_loader import load_config_yaml, postprocess_config
from ezga.selection.selector import Selector
from ezga.simulator.simulator import Simulator
from ezga.sync.agenticsync import Agentic_Sync
from ezga.transition_kernels.factory import make_transition_kernel

# --- Import your real implementations here ---
from ezga.thermostat.thermostat import Thermostat
from ezga.utils.lineage import LineageTracker
from ezga.utils.logger import WorkflowLogger
from ezga.utils.structure_hash_map import Structure_Hash_Map
from ezga.variation.variation import Variation_Operator
from ezga.visualization.plotter import Plotter

ConfigInput = Union[str, Path, dict[str, Any]]
__all__ = ["load_config", "build_default_engine"]

# --- Shorthand Registry ---
SHORTHAND_REGISTRY = {
    "calculators": {
        "lj": "ezga.factory:_make_lj_runner",
        "emt": "ezga.factory:_make_emt_runner",
        "zero": "ezga.simulator.calculators.constant_zero:null_calculator",
        "mace": "ezga.simulator.mace_calculator:mace_calculator",
    },
    "mutations": {
        "rattle": "ezga.variation.mutation:mutation_rattle",
        "swap": "ezga.variation.mutation:mutation_swap",
        "add": "ezga.variation.mutation:mutation_add",
        "remove": "ezga.variation.mutation:mutation_remove",
        "strain": "ezga.variation.mutation:mutation_random_strain",
    },
    "crossovers": {
        "voronoi": "ezga.variation.crossover:crossover_voronoi_bisector_surface",
    },
}


def _resolve_shorthands(cfg: dict[str, Any]) -> dict[str, Any]:
    """Replaces shorthand strings in the config with full factory paths."""
    # 1. Simulator Calculator
    if "simulator" in cfg and "calculator" in cfg["simulator"]:
        calc = cfg["simulator"]["calculator"]
        if isinstance(calc, str):
            # A) Colon syntax for calculators with arguments (e.g. "mace:path/to/model")
            if ":" in calc:
                name, arg = calc.split(":", 1)
                if name.lower() == "mace":
                    cfg["simulator"]["calculator"] = {
                        "factory": "ezga.simulator.mace_calculator:mace_calculator",
                        "kwargs": {"calc_path": arg},
                    }
            # B) Standard shorthand
            elif calc.lower() in SHORTHAND_REGISTRY["calculators"]:
                cfg["simulator"]["calculator"] = SHORTHAND_REGISTRY["calculators"][calc.lower()]

    # 2. Mutation Functions
    if "mutation_funcs" in cfg and isinstance(cfg["mutation_funcs"], list):
        new_muts = []
        for m in cfg["mutation_funcs"]:
            if isinstance(m, str) and m.lower() in SHORTHAND_REGISTRY["mutations"]:
                new_muts.append(SHORTHAND_REGISTRY["mutations"][m.lower()])
            else:
                new_muts.append(m)
        cfg["mutation_funcs"] = new_muts

    # 3. Crossover Functions
    if "crossover_funcs" in cfg and isinstance(cfg["crossover_funcs"], list):
        new_cos = []
        for c in cfg["crossover_funcs"]:
            if isinstance(c, str) and c.lower() in SHORTHAND_REGISTRY["crossovers"]:
                new_cos.append(SHORTHAND_REGISTRY["crossovers"][c.lower()])
            else:
                new_cos.append(c)
        cfg["crossover_funcs"] = new_cos

    return cfg


def _make_lj_runner(**kwargs: Any) -> Any:
    """Shorthand helper for LJ runner."""
    from ezga.simulator.ase_calculator import ase_calculator
    from ezga.simulator.calculators.LJ import LJMixer

    return ase_calculator(calculator=LJMixer(), **kwargs)


def _make_emt_runner(**kwargs: Any) -> Any:
    """Shorthand helper for EMT runner."""
    from ase.calculators.emt import EMT

    from ezga.simulator.ase_calculator import ase_calculator

    return ase_calculator(calculator=EMT(), **kwargs)  # type: ignore


from ezga.core.strategies import apply_strategy


def load_config(source: ConfigInput) -> GAConfig:
    """Create a validated :class:`GAConfig` from YAML path or Python dict.

    If ``source`` is a string/Path, it is interpreted as a YAML file and parsed
    via :func:`ezga.io.config_loader.load_config_yaml` (which also resolves
    dotted callable references). If ``source`` is a dict, it is validated
    directly using Pydantic.

    Args:
      source: YAML file path or a Python dict matching the GAConfig schema.

    Returns:
      A validated :class:`GAConfig` instance.

    Raises:
      SystemExit: If the YAML fails validation (the loader prints a friendly
        error message and exits).
      TypeError: If ``source`` is neither a path-like nor a dict.
    """
    if isinstance(source, (str, Path)):
        # 1) Load raw object (config_loader returns a GAConfig OBJECT, which is tricky)
        # Actually config_loader.load_config_yaml returns a GAConfig instance directly.
        # We need to intersect this if we want to modify it *before* validation?
        # Aah, load_config_yaml validates immediately.

        # Strategy: To support modification, we might need to intercept the raw dict
        # from the file before it becomes a GAConfig, OR we modify the GAConfig object.
        # Since GAConfig allows assignment validation, let's modify the object OR
        # assume source is dict for the dynamic use case.

        # For now, let's assume 'source' as dict is the primary entry point for dynamic experiments
        # like the HiSE example. The file loader likely needs a separate hook if we want CLI args to overrides file.
        # But 'load_config_yaml' does everything.

        # Let's handle the simple case first: modify the object returned by load_config_yaml.
        cfg = load_config_yaml(source)
        # We can implement apply_strategy to work on GAConfig objects too?
        # Or just convert to dict, modify, re-validate?
        # Let's stick to the dict path which is what we use in the example.
        return cfg

    if isinstance(source, dict):
        # 0) Shorthands
        source = _resolve_shorthands(source)
        # 1) Apply Agent Strategy Heuristics (Robust & General)
        source = apply_strategy(source)
        cfg = GAConfig.model_validate(source)
        return postprocess_config(cfg)

    raise TypeError(f"Expected str, Path, or dict, got {type(source)}")


def _make_component(value: Any, cls: type[Any], **kwargs: Any) -> Any:
    """ """
    import inspect

    # Already an instance
    if isinstance(value, cls):
        return value
    # Determine which class to instantiate
    if value is None:
        Klass = cls
    elif inspect.isclass(value):
        Klass = value
    else:
        raise TypeError(f"Override must be a {cls.__name__} subclass or instance, got {type(value)}")
    return Klass(**kwargs)


def build_default_engine(
    cfg: GAConfig,
    *,
    # ---------- Dependency Injection Overrides ---------- #
    lineage: type[ILineage] = LineageTracker,
    hash_map: type[IHash] = Structure_Hash_Map,
    agent: type[IAgent] = Agentic_Sync,
    population: type[IPopulation] | IPopulation | None = Population,
    thermostat: type[IThermostat] = Thermostat,
    evaluator: type[IEvaluator] = Evaluator,
    selector: type[ISelector] = Selector,
    variation: type[IVariation] = Variation_Operator,
    simulator: type[ISimulator] = Simulator,
    convergence: type[IConvergence] = Convergence,
    logger: type[ILogger] = WorkflowLogger,
    plotter: type[IPlotter] = Plotter,
    transition: type[ITransitionKernel] | ITransitionKernel | None = None,
    # ---------------------------------------------------- #
    ctx: Context | None = None,
) -> GeneticAlgorithm:
    """
    Constructs a fully-wired GeneticAlgorithm instance from a GAConfig.
    
    This factory implements a phased Dependency Injection (DI) pattern:
    1. Shared State: Initializes the global Context and RNG.
    2. Infrastructure: Sets up identity tracking (Hashing, Lineage).
    3. Population: Assembles the structural container with its Agentic interface.
    4. Science Core: Links physical evaluators and simulators.
    5. Search Logic: Configures genetic operators and selection kernels.
    6. Diagnostics: Wires convergence monitors and diagnostic plotters.
    """
    
    # --- PHASE 0: Environment & Shared State ---
    # We initialize the Context early as it acts as the "nervous system" 
    # through which components share state and random seeds.
    rng_seed = cfg.rng
    ctx_inst = ctx or Context(rng_seed=rng_seed, foreigners=cfg.foreigners)
    ctx_inst.ensemble_cfg = cfg.ensemble

    # --- PHASE 1: Structural Integrity Infrastructure ---
    # These services handle how structures are identified and traced over time.
    lineage_inst = lineage()
    hash_map_inst = _make_component(hash_map, Structure_Hash_Map, **cfg.hashmap.model_dump())

    # --- PHASE 2: Agentic Layer ---
    # The Agent manages communication with the swarm/external world.
    agent_inst = _make_component(
        agent, 
        Agentic_Sync, 
        local_dir=cfg.output_path,
        **cfg.agentic.model_dump()
    )

    # --- PHASE 3: Population Assembly ---
    # We wire the identity services and the agent into the population container.
    population_inst: IPopulation = _make_component(
        population,
        Population,
        debug=cfg.debug,
        output_path=cfg.output_path,
        hash_map=hash_map_inst,
        agent=agent_inst,
        lineage=lineage_inst,
        **cfg.population.model_dump(),
    )

    # --- PHASE 4: Scientific Core Services ---
    # Physical property evaluation, thermostats, and DoE wiring.
    thermostat_inst = _make_component(thermostat, Thermostat, **cfg.thermostat.model_dump())
    ctx_inst.shared_state["thermostat"] = thermostat_inst
    
    evaluator_inst = _make_component(evaluator, Evaluator, **cfg.evaluator.model_dump())
    
    # Wire the feature name mapping to the DoE module (Design of Experiments).
    # This allows the population to correctly label metrics derived from the evaluator.
    if hasattr(evaluator_inst, "features_funcs"):
        try:
            doe = getattr(population_inst, "DoE", None)
            if doe is not None and hasattr(doe, "set_name_mapping"):
                doe.set_name_mapping(evaluator_inst.features_funcs.get_feature_index_map())
        except Exception as e:
            warnings.warn(f"[Factory] Could not wire DoE name mapping: {e}", stacklevel=2)

    # Simulator setup (Physical relaxation/MD kernel)
    sim_kwargs = cfg.simulator.model_dump(exclude={"calculator"}, exclude_none=True)
    simulator_inst = _make_component(
        simulator,
        Simulator,
        **sim_kwargs,
        calculator=cfg.simulator.calculator,
        ctx=ctx_inst,
    )

    # --- PHASE 5: Optimization & Search Logic ---
    # Multi-objective selection and Variation (Mutation/Crossover).
    selector_inst = _make_component(selector, Selector, rng=ctx_inst.rng, **cfg.multiobjective.model_dump())
    ctx_inst.shared_state["selector"] = selector_inst

    # Flatten mutation presets into a linear execution list.
    flat_mutations = []
    for m in cfg.mutation_funcs:
        if isinstance(m, list): flat_mutations.extend(m)
        else: flat_mutations.append(m)

    crossover_funcs = list(cfg.crossover_funcs) if cfg.crossover_funcs else []
    
    # Initialize the Workflow Logger (needed for some advanced crossover operations)
    logger_inst: ILogger = _make_component(logger, WorkflowLogger, output_path=cfg.output_path)

    # Handle Social/Ensemble exchange (e.g., Gibbs Exchange)
    ens = getattr(cfg, "ensemble", None)
    if ens and getattr(ens, "kind", "none") == "gibbs":
        from ezga.variation.exchange import make_gibbs_exchange_crossover
        gibbs_co = make_gibbs_exchange_crossover(ens.gibbs, logger_inst, rng=ctx_inst.rng)
        crossover_funcs.append(gibbs_co)

    # Assemble the Variation Operator
    variation_inst = _make_component(
        variation,
        Variation_Operator,
        lineage=lineage_inst,
        mutation_funcs=flat_mutations,
        crossover_funcs=crossover_funcs,
        feature_func=getattr(evaluator_inst, "features_funcs", None),
        ctx=ctx_inst,
        **cfg.variation.model_dump(),
    )
    ctx_inst.shared_state["variation"] = variation_inst

    # --- PHASE 6: Search Dynamics & Monitoring ---
    # Convergence tracking and visualization services.
    convergence_inst = _make_component(convergence, Convergence, **cfg.convergence.model_dump())
    
    # CRITICAL: Link convergence engine back to context and population for agentic observability.
    ctx_inst.convergence = convergence_inst
    ctx_inst.convergence_checker = convergence_inst
    setattr(population_inst, "convergence_checker", convergence_inst)

    # Instantiation of the Diagnostic Plotter.
    plotter_inst: IPlotter
    if isinstance(plotter, type):
        plotter_inst = plotter(logger_dir=cfg.output_path, output_dir=cfg.output_path) # type: ignore
    else:
        plotter_inst = plotter

    # --- PHASE 7: Advanced Search Orchestration ---
    # Bayesian Optimization (BO) and Transition Kernels.
    generative_inst: IGenerative | None = None
    if cfg.generative.size > 0:
        if cfg.generative.custom is not None:
            generative_inst = cfg.generative.custom # type: ignore
        else:
            gen_kwargs = cfg.generative.model_dump()
            gen_kwargs.pop("custom", None)
            generative_inst = _make_component(BOGenerative, BOGenerative, **gen_kwargs)

    # Transition Kernel (Manages the flow between generations)
    transition_inst: ITransitionKernel | None
    if transition is None:
        transition_inst = make_transition_kernel(cfg, selector_inst, logger_inst, evaluator_inst, ctx_inst)
    elif isinstance(transition, type):
        transition_inst = transition(
            cfg=cfg, 
            selector=selector_inst, 
            logger=logger_inst, 
            evaluator=evaluator_inst, 
            ctx=ctx_inst
        ) # type: ignore
    else:
        transition_inst = transition

    # --- FINAL ASSEMBLY ---
    # Package all components into the main GeneticAlgorithm engine.
    engine = GeneticAlgorithm(
        population=population_inst,
        thermostat=thermostat_inst,
        evaluator=evaluator_inst,
        selector=selector_inst,
        simulator=simulator_inst,
        variation=variation_inst,
        transition=transition_inst,
        generative=generative_inst,
        convergence=convergence_inst,
        logger=logger_inst,
        plotter=plotter_inst,
        cfg=cfg,
        ctx=ctx_inst,
    )

    # ------------------------------------------------------------------ #
    #  Sanity warnings: let the user know if they forgot to configure      #
    #  objectives or features.  The engine will still run — it will just   #
    #  use dummy constants — but selection and adaptation won't do much.   #
    # ------------------------------------------------------------------ #
    def _is_empty(v) -> bool:
        if v is None: return True
        if hasattr(v, "__len__") and len(v) == 0: return True
        return False

    _no_features  = _is_empty(cfg.evaluator.features_funcs)
    _no_objectives = _is_empty(cfg.evaluator.objectives_funcs)
    _no_mutation   = _is_empty(cfg.mutation_funcs)
    _no_crossover  = _is_empty(cfg.crossover_funcs)

    # 1. Blind/Zen mode warnings
    if _no_features and _no_objectives:
        warnings.warn(
            "\n[EZGA] 🚩 CRITICAL SILLINESS DETECTED: You built a GeneticAlgorithm with NO features AND no objectives!\n"
            "  → The engine is essentially blind, deaf, and mute.\n"
            "  → Selection will be purely random, and the adaptive thermostat will just stare at you.\n"
            "  (I'm assuming you know what you're doing, but wow, you're living on the edge! 🤷 🏎️💨)",
            UserWarning, stacklevel=2
        )
    elif _no_features:
        warnings.warn(
            "\n[EZGA] ⚠️  No feature functions configured.\n"
            "  → Diversity repulsion and novelty metrics will be constant zeros.\n"
            "  → Hope you didn't want a diverse population! (Or you're planning to inject them later? 💉)",
            UserWarning, stacklevel=2
        )
    elif _no_objectives:
        warnings.warn(
            "\n[EZGA] ⚠️  No objective functions configured.\n"
            "  → Selection will be completely random (all candidates look the same to me).\n"
            "  → This is basically a 'Random Walk' GA. Very Zen, much exploration. 🧘",
            UserWarning, stacklevel=2
        )

    # 2. Variation-less (Cloning) mode
    if _no_mutation and _no_crossover:
        warnings.warn(
            "\n[EZGA] 🛸 CLONE ARMY DETECTED: No mutation OR crossover functions configured.\n"
            "  → You're running an extremely expensive copy-paste machine.\n"
            "  → Unless you're injecting structures from another agent, your population will never change.\n"
            "  → (Did you forget to add at least one mutation? 🤖)",
            UserWarning, stacklevel=2
        )

    # 3. Infinite Stall (Patience test)
    if cfg.convergence.stall_threshold is not None and not np.isfinite(cfg.convergence.stall_threshold):
        warnings.warn(
            "\n[EZGA] ⏳ ETERNAL PATIENCE MODE: Infinite stall threshold detected.\n"
            "  → The Genetic Algorithm will NEVER stop on its own based on stagnation.\n"
            "  → Hope you have a lot of compute credits or a very patient cat to watch the logs. 🐈‍⬛",
            UserWarning, stacklevel=2
        )

    # 4. Extreme Mutation (Chaos mode)
    if any(getattr(m, "rate", 0) > 4.5 for m in flat_mutations):
        warnings.warn(
            "\n[EZGA] 🔥 CHAOS MODE: Extremely high mutation rate detected (> 4.5).\n"
            "  → You aren't 'evolving' structures; you're essentially vaporizing them.\n"
            "  → Expect very low acceptance rates and high energy volatility in your reports. 🌋",
            UserWarning, stacklevel=2
        )

    # 5. Population Bottleneck
    if cfg.multiobjective.size < 10:
        warnings.warn(
            "\n[EZGA] 🤏 TINY SQUAD: Population size is less than 10.\n"
            "  → Your genetic diversity will be thinner than a piece of paper.\n"
            "  → Premature convergence is almost a certainty. Consider a larger swarm! 📉",
            UserWarning, stacklevel=2
        )

    # 6. Lonely Agent Mode
    if not cfg.output_path or str(cfg.output_path) == ".":
         warnings.warn(
            "\n[EZGA] 🏝️  LONELY AGENT: No meaningful shared directory configured.\n"
            "  → In the swarm, no one can hear you scream (or exchange structures).\n"
            "  → You are essentially running a solo GA. Global exchange is DISABLED. 🔕",
            UserWarning, stacklevel=2
        )

    # 7. Genetic Incest (Crossover without Mutation)
    if _no_mutation and not _no_crossover:
        warnings.warn(
            "\n[EZGA] 🧬 GENETIC INCEST: Crossover enabled, but NO mutation found.\n"
            "  → You're just reshuffling the same genes over and over.\n"
            "  → It's like a family reunion that never ends; eventually, you'll run out of new ideas. 👵",
            UserWarning, stacklevel=2
        )

    # 8. Stubborn Agent (Low Learning Rate)
    if getattr(cfg.agentic, "learning_rate", 0.1) < 0.01:
        warnings.warn(
            "\n[EZGA] 🐴 STUBBORN AGENT: Extremely low learning rate detected.\n"
            "  → Your agent is as stubborn as a mule. It will take ages to adapt\n"
            "  to any changes in the optimization landscape. 🐢",
            UserWarning, stacklevel=2
        )

    # 9. Buffer-Population Mismatch
    if cfg.agentic.max_buffer > cfg.multiobjective.size:
        warnings.warn(
            "\n[EZGA] 🧻 BUFFER OVERFLOW RISK: Sync buffer is larger than the population.\n"
            "  → You are waiting to fill a buffer that is bigger than your entire world.\n"
            "  → Auto-flushing might take forever. Consider lowering 'max_buffer'. 🚽",
            UserWarning, stacklevel=2
        )

    # 10. High Transfer Limit Risk
    limit = getattr(cfg.agentic, "max_transfer_limit", 0)
    if limit is not None and limit > 10000:
        warnings.warn(
            "\n[EZGA] 🚀 I/O OVERDRIVE: Max transfer limit is set very high (> 10000).\n"
            "  → Moving thousands of structures per generation will melt your filesystem.\n"
            "  → Expect significant latency during synchronization steps. 🌪️",
            UserWarning, stacklevel=2
        )

    return engine
