# EZGA — Evolutionary Structure Exploration Framework

[![ChemRxiv](https://img.shields.io/badge/ChemRxiv-Preprint-blue)](https://chemrxiv.org/doi/full/10.26434/chemrxiv.15000180/v1)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/release/python-3100/)
[![Tests Passing](https://img.shields.io/badge/tests-passing-brightgreen.svg)](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA)
[![Coverage](https://img.shields.io/badge/coverage-72%25-green.svg)](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA)

![image](docs/04f91868-f406-4511-807d-72b66781eca5.png)

![image](docs/wiki/abstract.png)

## Overview

EZGA is a modular, scalable, and chemically aware evolutionary framework for exploring and optimizing atomistic structures. It follows the **GitLab Enterprise Documentation Style**, emphasizing clarity, task‑orientation, operational guidance, and maintainability. This page serves as the primary landing document for new users and contributors.

EZGA enables configuration‑first evolutionary searches across molecular, cluster, crystalline, and surface systems. The engine integrates interchangeable components—initialization, features, objectives, selection, variation, convergence, and simulation—built around reproducible workflows and deterministic archival.

---

## 📄 Reference & Citation

The methodology and design principles of EZGA are described in:

**Juan Manuel Lombardi et al.**  
*EZGA: An Evolutionary Structure Exploration Framework*  
ChemRxiv (2025)

https://chemrxiv.org/doi/full/10.26434/chemrxiv.15000180/v1

### BibTeX

```bibtex
@article{lombardi2025ezga,
  title   = {EZGA: An Evolutionary Structure Exploration Framework},
  author  = {Lombardi, Juan Manuel and Riccius, Felix and Paré, Charles W. P., Hendrik H. Heenen, and Reuter, Karsten and Scheurer, Christoph},
  journal = {ChemRxiv},
  year    = {2025},
  doi     = {10.26434/chemrxiv.15000180}
}
```

---

## Key capabilities

* **Configuration‑driven GA engine** for molecules and periodic crystals.
* **Advanced Bayesian Optimization**: Integrated BO with efficient warm-starting, model persistence, ARD kernels for anisotropic features, and visualization utilities.
* **Composable modules**: initialization, constraints, features, objectives, selection, variation, simulator, convergence.
* **Robust execution**: deterministic seeds, deduplication, integrity checks, scalable parallelism.
* **Physical‑model integration** with ASE/MACE or any Python‑callable evaluator.
* **Hierarchical Supercell Escalation (HiSE)** for periodic systems.
* **Task‑oriented workflows**: copy → modify → run.

---

## Why use EZGA

* Explore large compositional/structural spaces efficiently.
* Apply human‑readable constraints (e.g., `greater_than("Cu", 1)`).
* Start with datasets or DoE space‑filling seeds; escalate to larger supercells.
* Increase robustness using integrity checks that avoid unphysical trial structures.
* Scale seamlessly from a laptop to multi‑GPU clusters.

---

## Get started fast

### 1. Install (Python ≥ 3.10)

```bash
pip install ezga_lib
```

Optional GPU/ML potential dependencies (MACE/ASE, CUDA/ROCm) depend on your environment.
See **Simulator** in the Wiki.

### 2. Smoke test

```python
import ezga
print(getattr(ezga, "__version__", "unknown"))
```

### 3. Run your first job

Follow the minimal runnable script in **Quickstart**.

**Tip:** In GitLab Wiki, section anchors work like: `./Constraints#greater-than`.

---

## Documentation

Full documentation is available in the project's **[GitLab Wiki](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/-/wikis/home)**:  

* **[Home](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/-/wikis/home)**
* **[Installation](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/-/wikis/Installation)**
* **[Quickstart](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/-/wikis/Quickstart)**
* **[Recipes](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/-/wikis/Recipes)**
* **[Configuration (GAConfig)](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/-/wikis/Configuration)**

---

## Repository structure

```
src/ezga/
    core/                   # GA engine configuration & parameters
    simple/                 # Simplified API (minimize, GA class)
    generative/             # Generative models (Bayesian Optimization)
    selection/              # Parent selectors
    variation/              # Mutation & crossover operators
    hise/                   # Supercell escalation
    thermostat/             # Exploration–exploitation control
    DoE/                    # Design-of-Experiments initializer
    convergence/            # Termination logic
    simulator/              # MD, relaxations, MLIPs
    evaluator/              # Feature & objective metrics
    visualization/          # Plotting & analysis tools
    sync/                   # Island-model mailbox
    io/                     # State persistence (SQL/HDF5)
    cli/                    # Command-line interface
    utils/                  # Helper utilities (including bo_plotter)

docs/                       # Sphinx documentation
tests/                      # Regression tests
dist/                       # Build artifacts
examples/                   # Example workflows

```

---

## Usage

### YAML workflow

```bash
ezga run config.yaml
```

### Python API

```python
from ezga import Agent, load_config
config = load_config("config.yaml")
agent = Agent(config)
agent.run()
```

---

## Bayesian Optimization & Generative AI

EZGA includes a powerful, configuration-driven Bayesian Optimization (BO) module designed to accelerate discovery in expensive search spaces.

### Key Features
*   **Automatic Relevance Determination (ARD)**: Automatically upgrades to an anisotropic Matern kernel for multi-dimensional problems, learning independent length scales for each feature (`use_ard=True`).
*   **Robust Fitting**: Improved kernel bounds prevent model collapse and ensure meaningful uncertainty estimates.
*   **Model Persistence**: Save trained GP models for offline analysis or warm-starting future runs (`save_model=True`).
*   **Subsampling Control**: Efficiently handle large datasets by subsampling training data (`training_subsample=200`).
*   **Visualization**: Built-in utilities to plot 2D surrogate models and diagnostics (`ezga.utils.bo_plotter`).

### Example Usage

```python
from ezga.simple.algorithm import GA

# Configure GA with advanced BO settings
algorithm = GA(
    pop_size=100,
    enable_bo=True,
    warm_start=True,          # Reuse previous solution for faster fitting
    use_ard=True,             # Enable anisotropic kernel
    save_model=True,          # Save GP models to disk
    training_subsample=500    # Limit training data for speed
)
```

---

## Benchmarks

EZGA is validated on:

* Molecular conformational exploration (alanine dipeptide).
* Lennard–Jones cluster global search.
* Binary‑oxide convex‑hull reconstruction.
* Autonomous CuO/Cu₂O grand‑canonical phase diagram.

---

## Issues & Support

We use the GitLab issue tracker for bug reports, feature requests, and questions.

* 🐞 **[Report a bug](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/issues/new?issue_type=bug)**
* ✨ **[Request a feature](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/issues/new?issue_type=bug/issues/new?issue_type=feature)**
* ❓ **[Ask a question](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/issues/new?issue_type=bug/issues/new)**
* 📝 **[Improve documentation](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/issues/new?issue_type=bug/issues/new)**

Issue templates are available here:
**[Issue templates](https://gitlab.mpcdf.mpg.de/fhi-theory/EZGA/-/issues/templates)**

---

## Authors

* Juan Manuel Lombardi
* Felix Riccius
* Charles W. P. Paré
* Hendrik Hennen 
* Karsten Reuter
* Christoph Scheurer

