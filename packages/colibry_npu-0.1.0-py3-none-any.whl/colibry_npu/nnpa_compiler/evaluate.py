# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2026 Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import os, json

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
import argparse
import numpy as np
import tensorflow as tf

from keras import backend as K
from tensorflow.keras.models import Model, Sequential, load_model

import colibry_npu.nnpa_compiler.nn_train_utils as nn_train_utils
from colibry_npu.nnpa_compiler.nn_train_utils import DataGenWrapper

RANDOM_SEED = 1


if __name__ == "__main__":
    ## Command line arguments
    ##############################
    parser = argparse.ArgumentParser(description="Execute a Neural Network")
    parser.add_argument(
        "config", type=str, help="path to a config.json containing required information"
    )
    parser.add_argument(
        "-ndump", type=int, help="Run NDUMP inferences and generate model outputs file"
    )
    parser.add_argument(
        "-dbg", type=int, help="Run only first inference and print output of layer DBG"
    )
    parser.add_argument(
        "--rand", action="store_true", help="Use random data instead of dataset inputs"
    )
    parser.add_argument("--qat", action="store_true", help="Evaluate the QAT model version")

    args = parser.parse_args()

    with open(args.config, "r") as f:
        config = json.load(f)

    modelRootPath = "." if args.config.rfind("/") <= 0 else args.config[: args.config.rfind("/")]
    try:
        if args.qat:
            modelPath = modelRootPath + "/output/" + config["QAT_MODEL_NAME"]
        else:
            modelPath = modelRootPath + "/output/" + config["OUTPUT_MODEL_NAME"]
        model = load_model(modelPath)
    except:
        print("Error: unable to open " + modelPath)
        exit(1)

    test_x_paths, test_y = nn_train_utils.read_test_dataset(config["DATASET_PATH"])

    if len(model.layers[0].input_shape) == 1:
        input_shape = model.layers[0].input_shape[0][1:]
    else:
        input_shape = model.layers[0].input_shape[1:]

    dataset_itype = config["INPUT_TYPE"]

    if args.rand:
        ## Do not read dataset but generate random data with same seed as reference
        np.random.seed(RANDOM_SEED)
        dataset_itype = "random"
        datagen = DataGenWrapper(
            test_x_paths,
            None,
            x_type=dataset_itype,
            input_shape=input_shape,
            output_shape=np.shape(test_y)[1:],
            input_scaling=config["INPUT_SCALING"],
            batch_size=config["BATCH_SIZE"],
            standardize=False,
            augmentation=False,
            shuffle=False,
        )
    else:
        datagen = DataGenWrapper(
            test_x_paths,
            test_y,
            x_type=dataset_itype,
            input_shape=input_shape,
            input_scaling=config["INPUT_SCALING"],
            batch_size=config["BATCH_SIZE"],
            standardize=config["STD_INPUTS"],
            augmentation=False,
            shuffle=False,
        )

    if args.dbg is not None:
        test_x, test_y = datagen.get_samples(1)
        get_layer_output = K.function([model.layers[0].input], [model.layers[args.dbg].output])
        x = test_x[0]
        # print(x)
        x = x[None, ...]
        layer_output = get_layer_output(x)[0]
        print(layer_output)

    elif args.ndump is not None:
        test_x, test_y = datagen.get_samples(n=args.ndump)

        nn_train_utils.write_tf_reference(
            model,
            test_x,
            args.ndump,
            dataset_itype,
            RANDOM_SEED,
            modelRootPath + "/output/tf_check_data.txt",
        )

    else:
        test_x, test_y = datagen.get_samples()
        print("Evaluating model on %d samples..." % len(test_x))
        scores = model.evaluate(test_x, test_y, batch_size=config["BATCH_SIZE"], verbose=1)
