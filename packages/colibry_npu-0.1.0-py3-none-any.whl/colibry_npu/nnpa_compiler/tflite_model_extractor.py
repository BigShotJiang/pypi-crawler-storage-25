# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2026 Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import tflite
import logging
import numpy as np


NWORD_BUFFER = 1024
N_MIPE = 8
MIPE_PAR = 2

builtin_operator_map = {
    v: k for k, v in tflite.BuiltinOperator.__dict__.items() if not k.startswith("_")
}

tensor_type_map = {
    tflite.TensorType.INT8: np.int8,
    tflite.TensorType.UINT8: np.uint8,
    tflite.TensorType.INT16: np.int16,
    tflite.TensorType.INT32: np.int32,
    tflite.TensorType.INT64: np.int64,
    tflite.TensorType.FLOAT16: np.float16,
    tflite.TensorType.FLOAT32: np.float32,
    tflite.TensorType.FLOAT64: np.float64,
    tflite.TensorType.COMPLEX64: np.complex64,
}

padding_type_map = {v: k for k, v in tflite.Padding.__dict__.items() if not k.startswith("_")}
activation_type_map = {
    v: k for k, v in tflite.ActivationFunctionType.__dict__.items() if not k.startswith("_")
}

ACTIVATIONS_TYPES = {
    "RELU": "relu",
    "RELU6": "relu",
    "SOFTMAX": "softmax",
    "LINEAR": "linear",
    "NONE": "linear",
}

PADDING_TYPES = {"SAME": "same", "VALID": "valid"}


class TFLiteModelExtractor:
    def __init__(
        self,
        model_path,
        quantNumbits,
        biasNumbits,
        scalingNumbits,
        scalingExpMax,
        inputMinMax=[0, 1],
    ):
        self.model_path = model_path
        self.model = self.load_model()
        self.quantNumbits = quantNumbits
        self.biasNumbits = biasNumbits
        self.scalingNumbits = scalingNumbits
        self.scalingExpMax = scalingExpMax
        self.inputMinMax = inputMinMax
        self.allLayersParam = []

    def load_model(self):
        try:
            with open(self.model_path, "rb") as f:
                buf = f.read()
                return tflite.Model.GetRootAsModel(buf, 0)
        except Exception as e:
            logging.error(f"Failed to load model: {e}")
            exit(1)

    def is_quantized_model(self):
        for sg_index in range(self.model.SubgraphsLength()):
            subgraph = self.model.Subgraphs(sg_index)
            for op_index in range(subgraph.OperatorsLength()):
                operator = subgraph.Operators(op_index)
                op_code = self.model.OperatorCodes(operator.OpcodeIndex())
                layer_type_name = self.get_layer_type_name(op_code)
                if layer_type_name == "QUANTIZE":
                    return True
                else:
                    first_input_tensors = subgraph.Tensors(operator.Inputs(0))
                    quant = first_input_tensors.Quantization()
                    if quant:
                        if quant.ScaleLength() > 0 and quant.ZeroPointLength() > 0:
                            return True
        return False

    def get_layer_idx_by_name(self, layer_refname):
        if layer_refname == "prev":
            return -1
        else:
            for k in range(len(self.allLayersParam)):
                if self.allLayersParam[k]["refname"] == layer_refname:
                    return k
        return None

    def check_model_compatibility(self):
        compat = True
        for sg_index in range(self.model.SubgraphsLength()):
            subgraph = self.model.Subgraphs(sg_index)
            for op_index in range(subgraph.OperatorsLength()):
                operator = subgraph.Operators(op_index)
                op_code = self.model.OperatorCodes(operator.OpcodeIndex())
                layer_type_name = self.get_layer_type_name(op_code)
                if layer_type_name not in [
                    "QUANTIZE",
                    "DEQUANTIZE",
                    "CONV_2D",
                    "DEPTHWISE_CONV_2D",
                    "FULLY_CONNECTED",
                    "MAX_POOL_2D",
                    "AVERAGE_POOL_2D",
                    "MEAN",
                    "ADD",
                    "SOFTMAX",
                    "RESHAPE",
                ]:
                    compat = False
                    logging.error("The layer %s is unsupported", layer_type_name)
                    exit(1)
        return compat

    def get_layer_type_name(self, op_code):
        return builtin_operator_map.get(op_code.BuiltinCode(), "UNKNOWN_OPERATOR")

    def value(self, tensor):
        buffer_index = tensor.Buffer()
        buffer = self.model.Buffers(buffer_index)
        tflite_type_code = tensor.Type()

        if tflite_type_code not in tensor_type_map:
            raise NotImplementedError(f"Tensor type {tflite_type_code} not supported.")

        tensor_dtype = tensor_type_map[tflite_type_code]
        tensor_shape = [tensor.Shape(i) for i in range(tensor.ShapeLength())]
        buffer_data = buffer.DataAsNumpy()

        if buffer_data is None or len(buffer_data) == 0:
            return None

        np_buffer = np.frombuffer(buffer_data, dtype=tensor_dtype)
        np_buffer = np.reshape(np_buffer, tensor_shape)
        return np_buffer

    def scale_zero_to_minmax(self, scales, zero_points, tensor_dtype):
        iinfo = np.iinfo(tensor_dtype)
        qmin = iinfo.min
        qmax = iinfo.max
        if scales.size == 1:
            scale = scales[0]
            zero_point = zero_points[0]
            min_val = scale * (qmin - zero_point)
            max_val = scale * (qmax - zero_point)
            return min_val, max_val
        else:
            min_vals = scales * (qmin - zero_points)
            max_vals = scales * (qmax - zero_points)
            min_val = min_vals.min()
            max_val = max_vals.max()
            return min_val, max_val

    def min_max_tensor(self, tensor):
        quant = tensor.Quantization()
        scales = quant.ScaleAsNumpy()
        zero_points = quant.ZeroPointAsNumpy()

        if scales.size == 0 or zero_points.size == 0:
            raise ValueError(
                f"Quantization parameters are missing for tensor '{tensor.Name().decode('utf-8')}'."
            )

        tflite_type_code = tensor.Type()

        if tflite_type_code not in tensor_type_map:
            raise NotImplementedError(f"Tensor type {tflite_type_code} not supported.")

        tensor_dtype = tensor_type_map[tflite_type_code]

        if quant.MinLength() == 0 or quant.MaxLength() == 0:
            min_val, max_val = self.scale_zero_to_minmax(scales, zero_points, tensor_dtype)
            return [min_val, max_val]
        else:
            min_vals = quant.MinAsNumpy()
            max_vals = quant.MaxAsNumpy()
            if min_vals.size == 1 and max_vals.size == 1:
                return [min_vals[0], max_vals[0]]
            else:
                min_val = min_vals.min()
                max_val = max_vals.max()
                return [min_val, max_val]

    def min_max_to_scale(self, minval, maxval, tensor):
        tflite_type_code = tensor.Type()
        if tflite_type_code not in tensor_type_map:
            raise NotImplementedError(f"Tensor type {tflite_type_code} not supported.")
        tensor_dtype = tensor_type_map[tflite_type_code]
        iinfo = np.iinfo(tensor_dtype)
        qmin = iinfo.min
        qmax = iinfo.max
        scale = (maxval - minval) / (qmax - qmin)
        zero = qmin - (minval / scale)
        return [scale, zero]

    def dequantize(self, tensor):
        quant = tensor.Quantization()
        scales = quant.ScaleAsNumpy()
        zero_points = quant.ZeroPointAsNumpy()
        quantized_dimension = quant.QuantizedDimension()
        arr = self.value(tensor)

        if arr is None:
            return None

        bshape = [
            arr.shape[quantized_dimension] if quantized_dimension == idx else 1
            for idx in range(arr.ndim)
        ]
        if scales.size != 1:
            scales = scales.reshape(bshape)
        if zero_points.size != 1:
            zero_points = zero_points.reshape(bshape)
        return (arr - zero_points) * scales

    def minmax_to_scale(self, minVal, maxVal, nLevels):
        scaling = (maxVal - minVal) / nLevels
        zero = -minVal / scaling
        return scaling, zero

    def convert_to_int(self, floatBiases, floatWeights, weightsMinMax, dataInMinMax, dataOutMinMax):
        nLevels = int((2**self.quantNumbits) - 1)

        scalingI, zeroI = self.minmax_to_scale(dataInMinMax[0], dataInMinMax[1], nLevels)
        scalingO, zeroO = self.minmax_to_scale(dataOutMinMax[0], dataOutMinMax[1], nLevels)
        scalingW, zeroW = self.minmax_to_scale(weightsMinMax[0], weightsMinMax[1], nLevels)
        zeroWint = int(np.round(zeroW))  # Weights zero is necessarily an integer

        mValue = scalingI * scalingW / scalingO

        # Compute scaling factor
        scalingExponent = self.scalingExpMax
        for exp_val in range(self.scalingExpMax + 1):
            if mValue < 2**exp_val:
                scalingExponent = exp_val
                break

        if mValue >= 2**scalingExponent:
            logging.warning(
                "Scaling factor is too high for given hardware parameters (%g)" % mValue
            )
            scalingExponent = self.scalingExpMax
            scalingFactor = 2**self.scalingNumbits - 1
        else:
            scalingFactor = int(np.round(mValue * (2 ** (self.scalingNumbits - scalingExponent))))

        # Convert weights to integers
        uint8Weights = np.zeros(np.shape(floatWeights), dtype="uint8")
        for index, w in np.ndenumerate(floatWeights):
            uint8Weights[index] = min(
                max(int(np.round(w / scalingW + zeroW)), 0), (2**self.quantNumbits) - 1
            )

        # Convert biases to integers
        kernelDim = len(uint8Weights.shape)
        intWeights = np.array(uint8Weights, dtype="int") - zeroWint
        weightSums = np.sum(
            intWeights, axis=tuple(range(kernelDim - 1)), dtype="int"
        )  # Sum of signed weights per filter

        intBiases = np.zeros(np.shape(floatBiases), dtype="int")
        for index, wb in np.ndenumerate(floatBiases):
            biasNew = zeroO / mValue + wb / (scalingI * scalingW) - zeroI * weightSums[index]
            # Saturation check
            if biasNew < -(2 ** (self.biasNumbits - 1)) + 1:
                biasNew = -(2 ** (self.biasNumbits - 1)) + 1
                logging.warning("Bias value low saturation")
            elif biasNew > (2 ** (self.biasNumbits - 1)) - 1:
                biasNew = (2 ** (self.biasNumbits - 1)) - 1
                logging.warning("Bias value high saturation")

            intBiases[index] = int(np.round(biasNew))

        return (
            intBiases,
            uint8Weights,
            scalingFactor,
            scalingExponent,
            zeroWint,
            int(np.round(zeroO)),
        )

    def compute_add_params(self, dataIn1MinMax, dataIn2MinMax, dataOutMinMax):
        nLevels = int((2**self.quantNumbits) - 1)

        scalingI1, zeroI1 = self.minmax_to_scale(dataIn1MinMax[0], dataIn1MinMax[1], nLevels)
        scalingI2, zeroI2 = self.minmax_to_scale(dataIn2MinMax[0], dataIn2MinMax[1], nLevels)
        scalingO, zeroO = self.minmax_to_scale(dataOutMinMax[0], dataOutMinMax[1], nLevels)

        isIn1Larger = scalingI2 >= scalingI1

        # Compute weight applied to the larger input (smaller scaling)
        weightInLarger = int(
            np.round(min(scalingI1, scalingI2) / max(scalingI1, scalingI2) * nLevels)
        )
        weightIn1 = weightInLarger if isIn1Larger else nLevels
        weightIn2 = nLevels if isIn1Larger else weightInLarger

        # Compute float SF
        mValue = max(scalingI1, scalingI2) / scalingO / nLevels

        # Compute int SF
        scalingExponent = self.scalingExpMax
        for exp_val in range(self.scalingExpMax + 1):
            if mValue < 2**exp_val:
                scalingExponent = exp_val
                break

        if mValue >= 2**scalingExponent:
            logging.warning(
                "Scaling factor is too high for given hardware parameters (%g)" % mValue
            )
            scalingExponent = self.scalingExpMax
            scalingFactor = 2**self.scalingNumbits - 1
        else:
            scalingFactor = int(np.round(mValue * (2 ** (self.scalingNumbits - scalingExponent))))

        # Compute bias
        bias = (zeroO - (scalingI1 * zeroI1 + scalingI2 * zeroI2) / scalingO) / mValue
        intBias = int(np.round(bias))

        if intBias >= 2 ** (self.biasNumbits - 1) or intBias <= -(2 ** (self.biasNumbits - 1)):
            logging.warning("Integer bias cannot fit into the expected number of bits")

        return intBias, weightIn1, weightIn2, scalingFactor, scalingExponent, int(np.round(zeroO))

    def left_first_dfs_topological_sort_tflite(self, subgraph):
        visited = set()
        sorted_ops = []

        tensor_to_producer = {}
        operators = [subgraph.Operators(i) for i in range(subgraph.OperatorsLength())]
        for op in operators:
            for i in range(op.OutputsLength()):
                tensor_to_producer[op.Outputs(i)] = op

        op_name = lambda op: id(op)
        adjacency_list = {op_name(op): [] for op in operators}
        op_inputs = {
            op_name(op): [op.Inputs(i) for i in range(op.InputsLength())] for op in operators
        }
        op_dict = {op_name(op): op for op in operators}

        for consumer_op in operators:
            for i in range(consumer_op.InputsLength()):
                input_tensor = consumer_op.Inputs(i)
                producer_op = tensor_to_producer.get(input_tensor)
                if producer_op:
                    adjacency_list[op_name(producer_op)].append(op_name(consumer_op))

        def dfs(op_id):
            if op_id in visited:
                return
            visited.add(op_id)

            children = adjacency_list.get(op_id, [])
            children.sort(key=lambda x: op_inputs[x])

            for child_id in children:
                dfs(child_id)

            sorted_ops.append(op_dict[op_id])

        graph_inputs = set(subgraph.Inputs(i) for i in range(subgraph.InputsLength()))
        initializer_tensors = set(
            subgraph.Tensors(i).Buffer()
            for i in range(subgraph.TensorsLength())
            if subgraph.Tensors(i).Buffer() > 0
        )

        def is_entry_op(op):
            for i in range(op.InputsLength()):
                input_tensor = op.Inputs(i)
                if input_tensor not in graph_inputs and input_tensor not in tensor_to_producer:
                    return False
            return True

        entry_ops = [op for op in operators if is_entry_op(op)]
        if not entry_ops:
            raise ValueError("No entry operators found — the graph might be malformed.")

        for entry_op in entry_ops:
            dfs(op_name(entry_op))

        sorted_ops.reverse()
        return sorted_ops

    def extract(self):

        if not self.is_quantized_model():
            self.quantNumbits = 32
            logging.error("Tflite model in float mode not supported ! Please Apply PTQ before !")
            exit(1)

        if not self.check_model_compatibility():
            logging.error("Input model parameters cannot be extracted due to incompatibilities!")
            exit(1)

        for sg_index in range(self.model.SubgraphsLength()):
            subgraph = self.model.Subgraphs(sg_index)
            self.process_subgraph(subgraph)
        return self.allLayersParam

    def process_subgraph(self, subgraph):
        maxNwordData = 0
        prevLayerNwordData = 0
        NWEIGHT_BIAS = 3
        LAYER_EXTRA_CYCLES = 8
        NN_EXTRA_CYCLES = 6
        biasRCycle = int(np.ceil(NWEIGHT_BIAS / MIPE_PAR))
        self.layerCycles = 0
        first_layer_op = subgraph.Operators(0)
        first_layer_input_tensor = subgraph.Tensors(first_layer_op.Inputs(0))
        inputDepth = first_layer_input_tensor.Shape(3)
        inputHeight = first_layer_input_tensor.Shape(1)
        inputWidth = first_layer_input_tensor.Shape(2)
        npack = int(np.floor(N_MIPE / inputDepth)) if inputDepth < N_MIPE else 1
        prevLayerNwordData = (
            np.ceil(inputDepth / N_MIPE) * inputHeight * np.ceil(inputWidth / MIPE_PAR)
        )
        prevLayerNwordData = int(np.ceil(prevLayerNwordData / npack))
        self.inputMinMax = self.min_max_tensor(first_layer_input_tensor)
        dataInMinMax = self.inputMinMax.copy()
        dataOutMinMax = self.inputMinMax.copy()
        flattenedOutput = 0
        operators = [subgraph.Operators(i) for i in range(subgraph.OperatorsLength())]

        def get_first_output_identifier(operator):
            return operator.Outputs(0)

        sorted_operators = self.left_first_dfs_topological_sort_tflite(subgraph)
        for op_index in range(len(sorted_operators)):
            operator = sorted_operators[op_index]
            op_code = self.model.OperatorCodes(operator.OpcodeIndex())
            layer_type_name = self.get_layer_type_name(op_code)

            logging.info(f"Found layer {op_index + 1}: {layer_type_name}")

            layerParam = {}
            if layer_type_name == "CONV_2D":
                layerParam["type"] = "conv"
                opt = tflite.Conv2DOptions()
                opt.Init(operator.BuiltinOptions().Bytes, operator.BuiltinOptions().Pos)
                padding_name = padding_type_map.get(opt.Padding(), "UNKNOWN_PADDING")
                activation_name = activation_type_map.get(opt.FusedActivationFunction(), "NONE")
                layerParam["activation"] = ACTIVATIONS_TYPES.get(activation_name, "linear")
                input_tensors = [
                    subgraph.Tensors(operator.Inputs(i)) for i in range(operator.InputsLength())
                ]
                output_tensors = [
                    subgraph.Tensors(operator.Outputs(i)) for i in range(operator.OutputsLength())
                ]
                layerParam["ifmap_width"] = input_tensors[0].Shape(2)
                layerParam["ifmap_height"] = input_tensors[0].Shape(1)
                layerParam["ifmap_depth"] = input_tensors[0].Shape(3)
                layerParam["ofmap_width"] = output_tensors[0].Shape(2)
                layerParam["ofmap_height"] = output_tensors[0].Shape(1)
                layerParam["ofmap_depth"] = output_tensors[0].Shape(3)
                layerParam["kernel_size_x"] = input_tensors[1].Shape(2)
                layerParam["kernel_size_y"] = input_tensors[1].Shape(1)
                layerParam["stride_x"] = opt.StrideW()
                layerParam["stride_y"] = opt.StrideH()
                layerParam["dilation_x"] = opt.DilationWFactor()
                layerParam["dilation_y"] = opt.DilationHFactor()
                layerParam["padding"] = PADDING_TYPES.get(padding_name)
                layerParam["refname"] = output_tensors[0].Name()
                if len(self.allLayersParam) == 0:
                    layerParam["ifmap_source"] = "prev"
                else:
                    layerParam["ifmap_source"] = input_tensors[0].Name()

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layerParam["ifmap_source"])
                    layerParam["ifmap_source_idx"] = ifmap_layer_idx
                    dataInMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layerParam["ifmap_source_idx"] = -1

                dataOutMinMax = self.min_max_tensor(output_tensors[0])
                floatBiases = self.dequantize(input_tensors[2])
                floatWeights = self.dequantize(input_tensors[1])
                if floatWeights is None or floatBiases is None:
                    logging.error("Failed to dequantize weights or biases.")
                    exit(1)
                floatWeights = np.transpose(floatWeights, (1, 2, 3, 0))
                weightsMinMax = [floatWeights.min(), floatWeights.max()]
                (
                    layerParam["biases"],
                    layerParam["weights"],
                    layerParam["scaling_factor"],
                    layerParam["scaling_exponent"],
                    layerParam["weights_zero"],
                    layerParam["ofmap_zero"],
                ) = self.convert_to_int(
                    floatBiases, floatWeights, weightsMinMax, dataInMinMax, dataOutMinMax
                )
                layerParam["dataout_min"] = dataOutMinMax[0]
                layerParam["dataout_max"] = dataOutMinMax[1]
                curr_fmap_zero = layerParam["ofmap_zero"]
                self.allLayersParam.append(layerParam)
                npack = (
                    int(np.floor(N_MIPE / output_tensors[0].Shape(3)))
                    if output_tensors[0].Shape(3) < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(output_tensors[0].Shape(3) / N_MIPE)
                    * output_tensors[0].Shape(1)
                    * np.ceil(output_tensors[0].Shape(2) / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))
                nWordNeed = int(
                    prevLayerNwordData
                    + np.ceil(output_tensors[0].Shape(3) / N_MIPE)
                    * np.ceil(layerParam["kernel_size_y"] / 2)
                    * np.ceil(output_tensors[0].Shape(2) / MIPE_PAR)
                    + 1
                )
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                if layerParam["ifmap_depth"] <= 1:
                    cycle_per_kernel = int(
                        np.ceil(
                            layerParam["kernel_size_x"] * layerParam["kernel_size_y"] / MIPE_PAR
                        )
                    )
                    self.layerCycles += int(
                        (biasRCycle * np.ceil(layerParam["ofmap_depth"] / N_MIPE))
                        + (
                            cycle_per_kernel
                            * layerParam["ofmap_width"]
                            * layerParam["ofmap_height"]
                            * np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                        )
                    )
                else:
                    self.layerCycles += int(
                        (biasRCycle * np.ceil(layerParam["ofmap_depth"] / N_MIPE))
                        + (
                            np.ceil(layerParam["ifmap_depth"] / MIPE_PAR)
                            * layerParam["kernel_size_x"]
                            * layerParam["kernel_size_y"]
                            * layerParam["ofmap_width"]
                            * layerParam["ofmap_height"]
                            * np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                        )
                    )

                prevLayerNwordData = layerNwordData

            elif layer_type_name == "DEPTHWISE_CONV_2D":
                layerParam["type"] = "conv_dw"
                opt = tflite.DepthwiseConv2DOptions()
                opt.Init(operator.BuiltinOptions().Bytes, operator.BuiltinOptions().Pos)
                padding_name = padding_type_map.get(opt.Padding(), "UNKNOWN_PADDING")
                activation_name = activation_type_map.get(opt.FusedActivationFunction(), "NONE")
                layerParam["activation"] = ACTIVATIONS_TYPES.get(activation_name, "linear")
                input_tensors = [
                    subgraph.Tensors(operator.Inputs(i)) for i in range(operator.InputsLength())
                ]
                output_tensors = [
                    subgraph.Tensors(operator.Outputs(i)) for i in range(operator.OutputsLength())
                ]
                layerParam["ifmap_width"] = input_tensors[0].Shape(2)
                layerParam["ifmap_height"] = input_tensors[0].Shape(1)
                layerParam["ifmap_depth"] = input_tensors[0].Shape(3)
                layerParam["ofmap_width"] = output_tensors[0].Shape(2)
                layerParam["ofmap_height"] = output_tensors[0].Shape(1)
                layerParam["ofmap_depth"] = output_tensors[0].Shape(3)
                layerParam["kernel_size_x"] = input_tensors[1].Shape(2)
                layerParam["kernel_size_y"] = input_tensors[1].Shape(1)
                layerParam["stride_x"] = opt.StrideW()
                layerParam["stride_y"] = opt.StrideH()
                layerParam["dilation_x"] = opt.DilationWFactor()
                layerParam["dilation_y"] = opt.DilationHFactor()
                layerParam["padding"] = PADDING_TYPES.get(padding_name)
                layerParam["refname"] = output_tensors[0].Name()
                if len(self.allLayersParam) == 0:
                    layerParam["ifmap_source"] = "prev"
                else:
                    layerParam["ifmap_source"] = input_tensors[0].Name()

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layerParam["ifmap_source"])
                    layerParam["ifmap_source_idx"] = ifmap_layer_idx
                    dataInMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layerParam["ifmap_source_idx"] = -1
                dataOutMinMax = self.min_max_tensor(output_tensors[0])
                floatBiases = self.dequantize(input_tensors[2])
                floatWeights = self.dequantize(input_tensors[1])
                if floatWeights is None or floatBiases is None:
                    logging.error("Failed to dequantize weights or biases.")
                    exit(1)
                floatWeights = np.transpose(floatWeights, (1, 2, 0, 3))  # Adjusted shape
                weightsMinMax = [floatWeights.min(), floatWeights.max()]
                (
                    layerParam["biases"],
                    layerParam["weights"],
                    layerParam["scaling_factor"],
                    layerParam["scaling_exponent"],
                    layerParam["weights_zero"],
                    layerParam["ofmap_zero"],
                ) = self.convert_to_int(
                    floatBiases, floatWeights, weightsMinMax, dataInMinMax, dataOutMinMax
                )
                layerParam["dataout_min"] = dataOutMinMax[0]
                layerParam["dataout_max"] = dataOutMinMax[1]

                curr_fmap_zero = layerParam["ofmap_zero"]
                npack = (
                    int(np.floor(N_MIPE / output_tensors[0].Shape(3)))
                    if output_tensors[0].Shape(3) < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(output_tensors[0].Shape(3) / N_MIPE)
                    * output_tensors[0].Shape(1)
                    * np.ceil(output_tensors[0].Shape(2) / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))
                nWordNeed = int(
                    prevLayerNwordData
                    + np.ceil(layerParam["kernel_size_y"] / 2)
                    * np.ceil(output_tensors[0].Shape(2) / MIPE_PAR)
                    + 1
                )
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                cycle_per_kernel = int(
                    np.ceil(layerParam["kernel_size_x"] * layerParam["kernel_size_y"] / MIPE_PAR)
                )
                self.layerCycles += int(
                    (biasRCycle * np.ceil(layerParam["ofmap_depth"] / N_MIPE))
                    + (
                        cycle_per_kernel
                        * layerParam["ofmap_width"]
                        * layerParam["ofmap_height"]
                        * np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                    )
                )

                self.allLayersParam.append(layerParam)
                prevLayerNwordData = layerNwordData

            elif layer_type_name == "FULLY_CONNECTED":
                flattenedOutput = 1
                layerParam["type"] = "dense"
                opt = tflite.FullyConnectedOptions()
                opt.Init(operator.BuiltinOptions().Bytes, operator.BuiltinOptions().Pos)
                activation_name = activation_type_map.get(opt.FusedActivationFunction(), "NONE")
                layerParam["activation"] = ACTIVATIONS_TYPES.get(activation_name, "linear")
                input_tensors = [
                    subgraph.Tensors(operator.Inputs(i)) for i in range(operator.InputsLength())
                ]
                output_tensors = [
                    subgraph.Tensors(operator.Outputs(i)) for i in range(operator.OutputsLength())
                ]
                layerParam["ofmap_width"] = 1
                layerParam["ofmap_height"] = 1
                layerParam["ofmap_depth"] = output_tensors[0].Shape(1)
                layerParam["ifmap_width"] = 1
                layerParam["ifmap_height"] = 1
                layerParam["ifmap_depth"] = input_tensors[0].Shape(1)
                layerParam["refname"] = output_tensors[0].Name()
                if len(self.allLayersParam) == 0:
                    layerParam["ifmap_source"] = "prev"
                else:
                    layerParam["ifmap_source"] = input_tensors[0].Name()
                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layerParam["ifmap_source"])
                    layerParam["ifmap_source_idx"] = ifmap_layer_idx
                    dataInMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layerParam["ifmap_source_idx"] = -1
                dataOutMinMax = self.min_max_tensor(output_tensors[0])
                floatBiases = self.dequantize(input_tensors[2])
                floatWeights = self.dequantize(input_tensors[1])
                if floatWeights is None or floatBiases is None:
                    logging.error("Failed to dequantize weights or biases.")
                    exit(1)
                floatWeights = np.transpose(floatWeights, (1, 0))  # Adjusted shape
                weightsMinMax = [floatWeights.min(), floatWeights.max()]
                (
                    layerParam["biases"],
                    layerParam["weights"],
                    layerParam["scaling_factor"],
                    layerParam["scaling_exponent"],
                    layerParam["weights_zero"],
                    layerParam["ofmap_zero"],
                ) = self.convert_to_int(
                    floatBiases, floatWeights, weightsMinMax, dataInMinMax, dataOutMinMax
                )
                layerParam["dataout_min"] = dataOutMinMax[0]
                layerParam["dataout_max"] = dataOutMinMax[1]

                curr_fmap_zero = layerParam["ofmap_zero"]
                layerNwordData = int(np.ceil(layerParam["ofmap_depth"] / (N_MIPE * MIPE_PAR)))
                nWordNeed = prevLayerNwordData + layerNwordData
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                self.layerCycles += int(
                    np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                    * (
                        biasRCycle
                        + layerParam["ifmap_width"]
                        * layerParam["ifmap_height"]
                        * np.ceil(layerParam["ifmap_depth"] / MIPE_PAR)
                    )
                )
                self.allLayersParam.append(layerParam)
                prevLayerNwordData = layerNwordData

            elif layer_type_name in ["MAX_POOL_2D", "AVERAGE_POOL_2D", "MEAN"]:
                input_tensors = [
                    subgraph.Tensors(operator.Inputs(i)) for i in range(operator.InputsLength())
                ]
                output_tensors = [
                    subgraph.Tensors(operator.Outputs(i)) for i in range(operator.OutputsLength())
                ]
                if (
                    layer_type_name == "MEAN"
                    and input_tensors[0].Shape(1) == input_tensors[0].Shape(2) == 1
                ):
                    self.allLayersParam[-1]["refname"] = output_tensors[0].Name()
                    continue
                if layer_type_name == "MAX_POOL_2D":
                    layerParam["type"] = "max_pool"
                else:
                    layerParam["type"] = "avg_pool"
                layerParam["ifmap_width"] = input_tensors[0].Shape(2)
                layerParam["ifmap_height"] = input_tensors[0].Shape(1)
                layerParam["ifmap_depth"] = input_tensors[0].Shape(3)
                layerParam["refname"] = output_tensors[0].Name()
                if layer_type_name == "MEAN":
                    layerParam["ofmap_width"] = 1
                    layerParam["ofmap_height"] = 1
                    layerParam["ofmap_depth"] = input_tensors[0].Shape(3)
                    layerParam["pool_size_x"] = input_tensors[0].Shape(2)
                    layerParam["pool_size_y"] = input_tensors[0].Shape(1)
                    layerParam["stride_x"] = 1
                    layerParam["stride_y"] = 1
                    layerParam["padding"] = "valid"
                else:
                    layerParam["ofmap_width"] = output_tensors[0].Shape(2)
                    layerParam["ofmap_height"] = output_tensors[0].Shape(1)
                    layerParam["ofmap_depth"] = output_tensors[0].Shape(3)
                    opt = tflite.Pool2DOptions()
                    opt.Init(operator.BuiltinOptions().Bytes, operator.BuiltinOptions().Pos)
                    padding_name = padding_type_map.get(opt.Padding(), "UNKNOWN_PADDING")
                    layerParam["pool_size_x"] = opt.FilterWidth()
                    layerParam["pool_size_y"] = opt.FilterHeight()
                    layerParam["stride_x"] = opt.StrideW()
                    layerParam["stride_y"] = opt.StrideH()
                    layerParam["padding"] = PADDING_TYPES.get(padding_name)
                layerParam["activation"] = "linear"
                if len(self.allLayersParam) == 0:
                    layerParam["ifmap_source"] = "prev"
                else:
                    layerParam["ifmap_source"] = input_tensors[0].Name()

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layerParam["ifmap_source"])
                    layerParam["ifmap_source_idx"] = ifmap_layer_idx
                    dataOutMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layerParam["ifmap_source_idx"] = -1

                layerParam["scaling_factor"] = int(
                    (2**self.scalingNumbits)
                    / (layerParam["pool_size_x"] * layerParam["pool_size_y"])
                )
                layerParam["scaling_exponent"] = 0
                layerParam["dataout_min"] = dataOutMinMax[0]
                layerParam["dataout_max"] = dataOutMinMax[1]
                npack = (
                    int(np.floor(N_MIPE / layerParam["ofmap_depth"]))
                    if layerParam["ofmap_depth"] < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                    * layerParam["ofmap_height"]
                    * np.ceil(layerParam["ofmap_width"] / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))

                nWordNeed = int(
                    prevLayerNwordData
                    + np.ceil(layerParam["pool_size_y"] / 2)
                    * np.ceil(layerParam["ofmap_width"] / MIPE_PAR)
                    + 1
                )
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                cycle_per_kernel = int(
                    np.ceil(layerParam["pool_size_y"] * layerParam["pool_size_y"] / MIPE_PAR)
                )
                self.layerCycles += int(
                    cycle_per_kernel
                    * layerParam["ofmap_width"]
                    * layerParam["ofmap_height"]
                    * np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                )

                self.allLayersParam.append(layerParam)
                prevLayerNwordData = layerNwordData

            elif layer_type_name == "ADD":
                opt = tflite.AddOptions()
                opt.Init(operator.BuiltinOptions().Bytes, operator.BuiltinOptions().Pos)
                activation_name = activation_type_map.get(opt.FusedActivationFunction(), "NONE")
                layerParam["activation"] = ACTIVATIONS_TYPES.get(activation_name, "linear")
                input_tensors = [
                    subgraph.Tensors(operator.Inputs(i)) for i in range(operator.InputsLength())
                ]
                output_tensors = [
                    subgraph.Tensors(operator.Outputs(i)) for i in range(operator.OutputsLength())
                ]
                if len(input_tensors) != 2:
                    logging.error("'Add' layer shall take only 2 input nodes.")
                    exit(1)
                else:
                    inbound_layer1_refname = input_tensors[0].Name()
                    inbound_layer2_refname = input_tensors[1].Name()
                if (
                    self.allLayersParam[-1]["refname"] != inbound_layer1_refname
                    and self.allLayersParam[-1]["refname"] != inbound_layer2_refname
                ):
                    logging.error("One input of 'Add' layer must be the previous layer.")
                    exit(1)

                layerParam["type"] = "add"

                if self.allLayersParam[-1]["refname"] != inbound_layer1_refname:
                    layerParam["in_refname"] = inbound_layer1_refname
                else:
                    layerParam["in_refname"] = inbound_layer2_refname

                layerParam["ifmap_width"] = input_tensors[0].Shape(2)
                layerParam["ifmap_height"] = input_tensors[0].Shape(1)
                layerParam["ifmap_depth"] = input_tensors[0].Shape(3)
                layerParam["ofmap_width"] = output_tensors[0].Shape(2)
                layerParam["ofmap_height"] = output_tensors[0].Shape(1)
                layerParam["ofmap_depth"] = output_tensors[0].Shape(3)
                layerParam["refname"] = output_tensors[0].Name()
                layerParam["ifmap_source"] = "prev"
                layerParam["ifmap_source_idx"] = -1
                dataOutMinMax = self.min_max_tensor(output_tensors[0])
                layerParam["dataout_min"] = dataOutMinMax[0]
                layerParam["dataout_max"] = dataOutMinMax[1]
                in_layer1_minmax = [
                    self.allLayersParam[-1]["dataout_min"],
                    self.allLayersParam[-1]["dataout_max"],
                ]
                in_layer2_minmax = [None, None]
                for ll in self.allLayersParam:
                    if ll["refname"] == layerParam["in_refname"]:
                        in_layer2_minmax = [ll["dataout_min"], ll["dataout_max"]]
                        break
                if in_layer2_minmax == [None, None]:
                    logging.error("Unable to retrive skip layer parameters!")
                    exit(1)

                (
                    layerParam["bias"],
                    layerParam["weight1"],  # Weight to input 1 (previous layer)
                    layerParam["weight2"],  # Weight to input 2 (skipped layer)
                    layerParam["scaling_factor"],
                    layerParam["scaling_exponent"],
                    layerParam["ofmap_zero"],
                ) = self.compute_add_params(in_layer1_minmax, in_layer2_minmax, dataOutMinMax)
                curr_fmap_zero = layerParam["ofmap_zero"]
                npack = (
                    int(np.floor(N_MIPE / layerParam["ofmap_depth"]))
                    if layerParam["ofmap_depth"] < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                    * layerParam["ofmap_height"]
                    * np.ceil(layerParam["ofmap_width"] / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))
                nWordNeed = int(prevLayerNwordData * 2 + layerNwordData)
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                outH, outW, outC = (
                    layerParam["ofmap_height"],
                    layerParam["ofmap_width"],
                    layerParam["ofmap_depth"],
                )
                nDepthOutGrp = int(np.ceil(outC / N_MIPE))
                self.layerCycles += int(outH * outW * nDepthOutGrp)
                self.allLayersParam.append(layerParam)
                prevLayerNwordData = layerNwordData

            elif layer_type_name == "SOFTMAX":
                if self.allLayersParam:
                    self.allLayersParam[-1]["activation"] = "softmax"
                    self.allLayersParam[-1]["refname"] = layer_type_name
                else:
                    logging.error("No previous layer to apply softmax activation.")
                output_tensors = [
                    subgraph.Tensors(operator.Outputs(i)) for i in range(operator.OutputsLength())
                ]
                dataOutMinMax = self.min_max_tensor(output_tensors[0])
            elif layer_type_name == "RESHAPE":
                if len(self.allLayersParam) > 0:
                    self.allLayersParam[-1]["refname"] = subgraph.Tensors(
                        operator.Outputs(0)
                    ).Name()
            self.layerCycles += LAYER_EXTRA_CYCLES
        if self.allLayersParam:
            self.allLayersParam[0]["flattenedOutput"] = flattenedOutput
            self.allLayersParam[0]["quantNumbits"] = self.quantNumbits
            self.allLayersParam[0]["biasNumbits"] = self.biasNumbits
            self.allLayersParam[0]["scalingNumbits"] = self.scalingNumbits
            self.allLayersParam[0]["scalingExpMax"] = self.scalingExpMax
            final_operator = subgraph.Operators(subgraph.OperatorsLength() - 1)
            final_op_code = self.model.OperatorCodes(final_operator.OpcodeIndex())
            final_layer_type_name = self.get_layer_type_name(final_op_code)
            if layer_type_name == "DEQUANTIZE":
                final_output_tensors = [
                    subgraph.Tensors(final_operator.Inputs(i))
                    for i in range(final_operator.InputsLength())
                ]
                dataOutMinMax = self.min_max_tensor(final_output_tensors[0])
            else:
                final_output_tensors = [
                    subgraph.Tensors(final_operator.Outputs(i))
                    for i in range(final_operator.OutputsLength())
                ]
                dataOutMinMax = self.min_max_tensor(final_output_tensors[0])
            (
                self.allLayersParam[0]["outputScalingFloat"],
                self.allLayersParam[0]["outputZeroFloat"],
            ) = self.min_max_to_scale(dataOutMinMax[0], dataOutMinMax[1], final_output_tensors[0])

            self.allLayersParam[0]["inputMin"] = self.inputMinMax[0]
            self.allLayersParam[0]["inputMax"] = self.inputMinMax[1]
            nnInputDataZero = self.minmax_to_scale(
                self.inputMinMax[0], self.inputMinMax[1], int((2**self.quantNumbits) - 1)
            )[1]
            self.allLayersParam[0]["nnInputDataZero"] = int(np.round(nnInputDataZero))
            # Final check on activations
            for i in range(len(self.allLayersParam) - 1):
                if "activation" in self.allLayersParam[i]:
                    activationName = self.allLayersParam[i]["activation"]
                    if activationName not in ["linear", "relu"]:
                        logging.error(
                            f"Activation '{activationName}' is not supported except for the last layer."
                        )
                        exit(1)
        self.nnMembuffData = int(np.ceil(maxNwordData / NWORD_BUFFER))
        self.layerCycles += NN_EXTRA_CYCLES


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    # model_path = "../NN_VWW/output/trained_model_second.tflite"
    # model_path = "../NN_KWS_TINYML/output/trained_model_all.tflite"
    model_path = (
        "../NN_ANOMALY_DETECTION_TINYML/output/model/model_ToyCar_quant_fullint_micro_intio.tflite"
    )
    # model_path = "../NN_SMALL_MODEL/output/trained_model_bis.tflite"
    # model_path = "../NN_KWS_TINYML/output/trained_model_valid.tflite"
    # model_path = "../NN_BLAZE_FASHION/output/trained_model.tflite"
    # model_path = "../NN_KWS_TINYML/output/trained_model.tflite"
    NBIT_DATA = 8
    NBIT_BIAS = 24
    NBIT_SCALING = 16
    SCALING_EXP_MAX = 3
    parser = TFLiteModelExtractor(
        model_path,
        quantNumbits=NBIT_DATA,
        biasNumbits=NBIT_BIAS,
        scalingNumbits=NBIT_SCALING,
        scalingExpMax=SCALING_EXP_MAX,
    )
    tflite_layers = parser.extract()
    print(tflite_layers)
