# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2026 Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import logging

import numpy as np
import tensorflow as tf


### Class TFmodelExtractor
### Allows to extract information from a trained TF model
### Model can be quantized (QAT result) or not
### If quantized, weights are converted to integers
#########################################################
class TFmodelExtractor:
    def __init__(
        self,
        tfModel,
        quantNumbits,
        biasNumbits,
        scalingNumbits,
        scalingExpMax,
        bnEpsilon=0.001,
        inputMinMax=[0, 1],
    ):
        self.tfModel = tfModel
        self.quantNumbits = quantNumbits
        self.biasNumbits = biasNumbits
        self.scalingNumbits = scalingNumbits
        self.scalingExpMax = scalingExpMax
        self.inputMinMax = inputMinMax
        self.allLayersParam = []
        self.bnEpsilon = bnEpsilon  # Must be equal to the value use during training

    def show(self):
        print(self.tfModel)

    def minmax_to_scale(self, minVal, maxVal, nLevels):
        scaling = (maxVal - minVal) / nLevels
        zero = -minVal / scaling
        return scaling, zero

    def is_quantized_model(self):
        for idx in range(len(self.tfModel.layers)):
            if self.tfModel.layers[idx].__class__.__name__.startswith("QuantizeWrapper"):
                return True
        return False

    def get_layer_idx_by_name(self, layer_refname):
        if layer_refname == "prev":
            return -1
        else:
            for k in range(len(self.allLayersParam)):
                if self.allLayersParam[k]["refname"] == layer_refname:
                    return k
        return None

    def check_model_compatibility(self):
        layerTypes = []
        quantizedModel = False
        compatError = False

        for idx in range(len(self.sorted_layers)):
            if self.sorted_layers[idx].__class__.__name__.startswith("QuantizeWrapper"):
                quantizedModel = True
                layerTypes.append(self.sorted_layers[idx].layer.__class__.__name__)
            else:
                layerTypes.append(self.sorted_layers[idx].__class__.__name__)

        if quantizedModel:
            # Check layers are correctly quantized
            for idx in range(len(self.sorted_layers)):
                if self.sorted_layers[idx].__class__.__name__ in [
                    "Activation",
                    "Dense",
                    "Conv2D",
                    "DepthwiseConv2D",
                    "Add",
                ]:
                    logging.error(
                        "With a quantized model, '%s' layer shall be quantized!",
                        self.sorted_layers[idx].__class__.__name__,
                    )
                    compatError = True

            # Check batch normalization can be folded
            # for idx in range(len(self.tfModel.layers)):
            for idx in range(len(self.sorted_layers)):
                if layerTypes[idx] == "BatchNormalization" and self.sorted_layers[
                    idx
                ].__class__.__name__.startswith("QuantizeWrapper"):
                    logging.error(
                        "'BatchNormalization' layers shall not be quantized!", layerTypes[idx]
                    )
                    compatError = True

                if layerTypes[idx] == "BatchNormalization":
                    if idx == 0:
                        logging.error("'BatchNormalization' as first layer is not supported!")
                        compatError = True
                    elif idx == len(layerTypes) - 1 or (
                        not layerTypes[idx + 1] == "Activation"
                        and not layerTypes[idx + 1] == "ReLU"
                    ):
                        logging.error(
                            "A 'BatchNormalization' layer shall always be followed by an activation!"
                        )
                        compatError = True
                    elif not layerTypes[idx - 1] in ["Dense", "Conv2D", "DepthwiseConv2D"]:
                        logging.error(
                            "A 'BatchNormalization' layer shall be placed right after a Conv or Dense layer!"
                        )
                        compatError = True
                    elif (
                        self.sorted_layers[idx - 1].layer.get_config()["activation"]["config"][
                            "activation"
                        ]
                        != "linear"
                    ):
                        logging.error(
                            "The layer preceding a 'BatchNormalization' shall have a linear (no) activation!"
                        )
                        compatError = True

        return compatError

    def check_layer_params(self, layerType, layerConfig):
        if layerType == "MaxPooling2D" or layerType == "AveragePooling2D":
            if (
                layerConfig["pool_size"][0] < layerConfig["strides"][0]
                or layerConfig["pool_size"][1] < layerConfig["strides"][1]
            ):
                logging.error(
                    "Pool size in a dimension cannot be smaller than corresponding stride!"
                )
                exit(1)

    def batchnorm_fusing(self, weights, biases, currLayerIndex):
        # Check conditions for fusing
        if currLayerIndex < len(self.sorted_layers) - 2:
            # l_next1 = self.tfModel.layers[currLayerIndex + 1]
            l_next1 = self.sorted_layers[currLayerIndex + 1]
            if l_next1.__class__.__name__.startswith("Quantize"):
                l_next1 = l_next1.layer
            # l_next2 = self.tfModel.layers[currLayerIndex + 2]
            # if l_next2.__class__.__name__.startswith("Quantize"):
            #     l_next2Type = l_next2.layer.__class__.__name__
            # else:
            #     l_next2Type = l_next2.__class__.__name__

            # if not (l_next1.__class__.__name__ == "BatchNormalization" and l_next2Type == "Activation"):
            if not l_next1.__class__.__name__ == "BatchNormalization":
                return False
        else:
            return False
        # Assumption: the normalization is done per output axis, assumed to be the last dimension of weights
        if l_next1.beta is None:
            beta = np.zeros(weights.shape[-1])
        else:
            beta = l_next1.beta.numpy()

        if l_next1.gamma is None:
            gamma = np.ones(weights.shape[-1])
        else:
            gamma = l_next1.gamma.numpy()

        bmean = l_next1.moving_mean.numpy()
        bvar = l_next1.moving_variance.numpy()

        if weights.shape[-1] != len(bmean):
            logging.error("'BatchNormalization' layer with incompatible parameters found!")
            exit(1)

        for f in range(weights.shape[-1]):
            weightsSlice = weights[..., f]
            for i in range(len(weightsSlice)):
                weightsSlice[i] = weightsSlice[i] * gamma[f] / np.sqrt(bvar[f] + self.bnEpsilon)

        for f in range(weights.shape[-1]):
            biases[f] = (biases[f] - bmean[f]) * gamma[f] / np.sqrt(
                bvar[f] + self.bnEpsilon
            ) + beta[f]

        return True

    def convert_to_int(self, floatBiases, floatWeights, weightsMinMax, dataInMinMax, dataOutMinMax):
        if dataInMinMax[0] == None or dataInMinMax[1] == None:
            logging.error(
                "Initial QuantizeLayer not found. inputMinMax parameter shall be provided!"
            )
            exit(1)

        nLevels = int((2**self.quantNumbits) - 1)

        scalingI, zeroI = self.minmax_to_scale(dataInMinMax[0], dataInMinMax[1], nLevels)
        scalingO, zeroO = self.minmax_to_scale(dataOutMinMax[0], dataOutMinMax[1], nLevels)
        scalingW, zeroW = self.minmax_to_scale(weightsMinMax[0], weightsMinMax[1], nLevels)
        zeroWint = int(np.round(zeroW))  # Weights zero is necessarily an integer

        mValue = scalingI * scalingW / scalingO

        # Compute scaling factor
        scalingExponent = self.scalingExpMax
        for exp_val in range(self.scalingExpMax + 1):
            if mValue < 2**exp_val:
                scalingExponent = exp_val
                break

        # Emulate an exponent != 0
        # if np.random.rand() < 0.4:
        #    scalingExponent = np.random.randint(1,4)

        if mValue >= 2**scalingExponent:
            logging.warning(
                "Scaling factor is too high for given hardware parameters (%g)" % mValue
            )
            scalingExponent = self.scalingExpMax
            scalingFactor = 2**self.scalingNumbits - 1
        else:
            scalingFactor = int(np.round(mValue * (2 ** (self.scalingNumbits - scalingExponent))))

        # Convert weights to integers
        uint8Weights = np.zeros(np.shape(floatWeights), dtype="uint8")
        for index, w in np.ndenumerate(floatWeights):
            uint8Weights[index] = min(
                max(int(np.round(w / scalingW + zeroW)), 0), (2**self.quantNumbits) - 1
            )

        # Convert biases to integers
        kernelDim = len(uint8Weights.shape)
        intWeights = np.array(uint8Weights, dtype="int") - zeroWint
        weightSums = np.sum(
            intWeights, axis=tuple(range(kernelDim - 1)), dtype="int"
        )  # Sum of signed weights per filter

        intBiases = np.zeros(np.shape(floatBiases), dtype="int")
        for index, wb in np.ndenumerate(floatBiases):
            biasNew = zeroO / mValue + wb / (scalingI * scalingW) - zeroI * weightSums[index]
            # Saturation check
            if biasNew < -(2 ** (self.biasNumbits - 1)) + 1:
                biasNew = -(2 ** (self.biasNumbits - 1)) + 1
                logging.warning("Bias value low saturation")
            elif biasNew > (2 ** (self.biasNumbits - 1)) - 1:
                biasNew = (2 ** (self.biasNumbits - 1)) - 1
                logging.warning("Bias value high saturation")

            intBiases[index] = int(np.round(biasNew))

        # print(" ")
        # print("Input  scaling | zero:", scalingI, "|", zeroI)
        # print("Output scaling | zero:", scalingO, "|", zeroO)
        # print("Weight scaling | zero:", scalingW, "|", zeroW)
        # print(intBiases)

        return (
            intBiases,
            uint8Weights,
            scalingFactor,
            scalingExponent,
            zeroWint,
            int(np.round(zeroO)),
        )

    def compute_add_params(self, dataIn1MinMax, dataIn2MinMax, dataOutMinMax):
        nLevels = int((2**self.quantNumbits) - 1)

        scalingI1, zeroI1 = self.minmax_to_scale(dataIn1MinMax[0], dataIn1MinMax[1], nLevels)
        scalingI2, zeroI2 = self.minmax_to_scale(dataIn2MinMax[0], dataIn2MinMax[1], nLevels)
        scalingO, zeroO = self.minmax_to_scale(dataOutMinMax[0], dataOutMinMax[1], nLevels)

        isIn1Larger = scalingI2 >= scalingI1

        # Compute weight applied to the larger input (smaller scaling)
        weightInLarger = int(
            np.round(min(scalingI1, scalingI2) / max(scalingI1, scalingI2) * nLevels)
        )
        weightIn1 = weightInLarger if isIn1Larger else nLevels
        weightIn2 = nLevels if isIn1Larger else weightInLarger

        # Compute float SF
        mValue = max(scalingI1, scalingI2) / scalingO / nLevels

        # Compute int SF
        scalingExponent = self.scalingExpMax
        for exp_val in range(self.scalingExpMax + 1):
            if mValue < 2**exp_val:
                scalingExponent = exp_val
                break

        if mValue >= 2**scalingExponent:
            logging.warning(
                "Scaling factor is too high for given hardware parameters (%g)" % mValue
            )
            scalingExponent = self.scalingExpMax
            scalingFactor = 2**self.scalingNumbits - 1
        else:
            scalingFactor = int(np.round(mValue * (2 ** (self.scalingNumbits - scalingExponent))))

        # Compute bias
        bias = (zeroO - (scalingI1 * zeroI1 + scalingI2 * zeroI2) / scalingO) / mValue
        intBias = int(np.round(bias))

        if intBias >= 2 ** (self.biasNumbits - 1) or intBias <= -(2 ** (self.biasNumbits - 1)):
            logging.warning("Integer bias cannot fit into the expected number of bits")

        return intBias, weightIn1, weightIn2, scalingFactor, scalingExponent, int(np.round(zeroO))

    def topological_sort_tf_layers(self, model):
        from collections import defaultdict

        visited = set()
        sorted_layers = []
        layer_dict = {layer.name: layer for layer in model.layers}
        reverse_adj = defaultdict(list)
        forward_adj = defaultdict(list)

        # Build graph connections
        for layer in model.layers:
            for node in layer._inbound_nodes:
                inbound_layers = node.inbound_layers
                if not inbound_layers:
                    continue
                if not isinstance(inbound_layers, list):
                    inbound_layers = [inbound_layers]
                for in_layer in inbound_layers:
                    if in_layer:
                        reverse_adj[layer.name].append(in_layer.name)
                        forward_adj[in_layer.name].append(layer.name)

        # Compute depth
        depth_cache = {}

        def compute_reverse_depth(layer_name):
            if layer_name in depth_cache:
                return depth_cache[layer_name]
            children = forward_adj.get(layer_name, [])
            if not children:
                depth_cache[layer_name] = 1
            else:
                depth_cache[layer_name] = 1 + max(compute_reverse_depth(c) for c in children)
            return depth_cache[layer_name]

        for layer in model.layers:
            compute_reverse_depth(layer.name)

        output_layers = [layer.name for layer in model.layers if not forward_adj[layer.name]]

        def dfs(layer_name):
            if layer_name in visited:
                return
            visited.add(layer_name)

            parents = reverse_adj.get(layer_name, [])
            # Sort (deeper first)
            sorted_parents = sorted(parents, key=lambda l: -depth_cache[l])
            for parent in sorted_parents:
                dfs(parent)

            sorted_layers.append(layer_dict[layer_name])

        for out_layer in output_layers:
            dfs(out_layer)

        return sorted_layers

    def extract(self):
        NWORD_BUFFER = 1024
        N_MIPE = 8
        MIPE_PAR = 2
        NWEIGHT_BIAS = 3
        LAYER_EXTRA_CYCLES = 8
        NN_EXTRA_CYCLES = 6
        biasRCycle = int(np.ceil(NWEIGHT_BIAS / MIPE_PAR))
        maxNwordData = 0
        prevLayerNwordData = 0
        if not self.is_quantized_model():
            self.quantNumbits = 32

        self.tfModel.summary()
        self.allLayersParam = []
        self.layerCycles = 0
        flattenedOutput = 0
        validLayerFound = False
        curr_fmap_zero = 0
        self.sorted_layers = self.tfModel.layers
        if isinstance(self.tfModel, tf.keras.Sequential):
            self.sorted_layers = self.tfModel.layers
        else:
            self.sorted_layers = self.topological_sort_tf_layers(self.tfModel)

        if self.check_model_compatibility():
            logging.error("Input model parameters cannot be extracted due to incompatibilities!")
            exit(1)

        # if self.tfModel.layers[0].__class__.__name__ == "InputLayer":
        if self.sorted_layers[0].__class__.__name__ == "InputLayer":
            idx = 1
        else:
            idx = 0

        # Check if a QuantizeLayer is present a the network start
        # if self.tfModel.layers[idx].__class__.__name__.startswith("QuantizeLayer"):
        if self.sorted_layers[idx].__class__.__name__.startswith("QuantizeLayer"):
            for weightPart in self.sorted_layers[idx].weights:
                if "quantize_layer_min:" in weightPart.name:
                    inputMin = weightPart.read_value().numpy()
                elif "quantize_layer_max:" in weightPart.name:
                    inputMax = weightPart.read_value().numpy()
            self.inputMinMax = [inputMin, inputMax]
            logging.info(
                "Found input data range information. (Min, Max) = (%g, %g)"
                % tuple(self.inputMinMax)
            )

        dataInMinMax = self.inputMinMax
        dataOutMinMax = self.inputMinMax
        # while idx < len(self.tfModel.layers):
        while idx < len(self.sorted_layers):
            bnLayerFused = False
            skipLayer = False
            activation_next = False
            # l = self.tfModel.layers[idx]
            l = self.sorted_layers[idx]
            layerParam = {}

            # Extract config
            #
            if l.__class__.__name__.startswith("QuantizeWrapper"):
                layerType = l.layer.__class__.__name__
                quantizedLayer = True
                lConfig = l.layer.get_config()
            else:
                layerType = l.__class__.__name__
                quantizedLayer = False
                lConfig = l.get_config()

            lName = l.get_config()["name"]  # Layer name (with quant_* for quantized layers)

            # Extract layer input dimensions
            #
            if layerType == "Add":
                inputWidth = l.input_shape[0][2]
                inputHeight = l.input_shape[0][1]
                inputDepth = l.input_shape[0][3]
            elif len(l.input_shape) < 3:
                inputWidth = 1
                inputHeight = 1
                inputDepth = l.input_shape[1]
            elif len(l.input_shape) < 4:
                logging.error("Model input shape is not supported!")
                exit(1)
            else:
                inputWidth = l.input_shape[2]
                inputHeight = l.input_shape[1]
                inputDepth = l.input_shape[3]

            if idx == 0:
                npack = int(np.floor(N_MIPE / inputDepth)) if inputDepth < N_MIPE else 1
                prevLayerNwordData = (
                    np.ceil(inputDepth / N_MIPE) * inputHeight * np.ceil(inputWidth / MIPE_PAR)
                )
                prevLayerNwordData = int(np.ceil(prevLayerNwordData / npack))
            self.check_layer_params(layerType, lConfig)

            if quantizedLayer:
                logging.info(
                    ("Found layer %3d  |  %s" % (idx, l.name)).ljust(60) + "|  'Quantized'"
                )
            else:
                logging.info(
                    ("Found layer %3d  |  %s" % (idx, l.name)).ljust(60) + "|  'Not quantized'"
                )
            ################################################################################################
            if layerType == "BatchNormalization":
                # logging.error("A 'BatchNormalization' has not been merged into the output model!")
                # print("*** Requirement to allow merge is a Conv or Dense, followed by BN and Activation")
                # print("*** The last activation layer is needed to get TF metrics and can be 'Linear'")
                # exit(1)
                skipLayer = True

            ################################################################################################
            elif layerType == "Identity" and (
                lName.startswith("xten") or lName.startswith("quant_xten")
            ):
                # This layer is used as an XTEN layer for the NNPA
                layerParam["type"] = "xten"
                layerParam["subtype"] = 0  ## A number identifiying the extended layer subtype

                layerParam["ifmap_width"] = inputWidth
                layerParam["ifmap_height"] = inputHeight
                layerParam["ifmap_depth"] = inputDepth
                if len(l.output_shape) < 3:
                    layerParam["ofmap_width"] = 1
                    layerParam["ofmap_height"] = 1
                    layerParam["ofmap_depth"] = l.output_shape[1]
                else:
                    layerParam["ofmap_width"] = l.output_shape[2]
                    layerParam["ofmap_height"] = l.output_shape[1]
                    layerParam["ofmap_depth"] = l.output_shape[3]

                layerParam["same_ofmap"] = (
                    0  # Set to 1 if no ofmap is created (ifmap is overwritten)
                )
                layerParam["ofmap_zero"] = curr_fmap_zero
                layerParam["activation"] = "linear"
                layerParam["refname"] = lName
                # Find the ifmap source of the layer
                if len(self.allLayersParam) == 0:
                    layerParam["ifmap_source"] = "prev"
                else:
                    layerParam["ifmap_source"] = l.inbound_nodes[0].inbound_layers.name

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layerParam["ifmap_source"])
                    layerParam["ifmap_source_idx"] = ifmap_layer_idx
                    dataOutMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layerParam["ifmap_source_idx"] = -1

                layerParam["dataout_min"] = dataOutMinMax[0]  # Setting Min/Max from previous layer
                layerParam["dataout_max"] = dataOutMinMax[1]  # Setting Min/Max from previous layer

                layerParam["biases"] = []
                layerParam["weights"] = [x for x in range(0, 100)]  # For testing purposes
                layerNwordData = 0

            ################################################################################################
            elif layerType == "Activation":
                # If current layer is only an activation, integrate it to previous layer
                #
                if not validLayerFound:
                    logging.error("First layer shall not be an 'Activation'!")
                    exit(1)
                elif (
                    "activation" in self.allLayersParam[-1]
                    and self.allLayersParam[-1]["activation"] != "linear"
                ):
                    logging.error("An 'Activation' cannot be followed by another 'Activation'!")
                    exit(1)
                else:
                    self.allLayersParam[-1]["activation"] = lConfig["activation"]
                    self.allLayersParam[-1]["refname"] = (
                        l.name
                    )  # Give the reference to the head of this group

                if quantizedLayer:
                    dataOutMinMax = self.sorted_layers[idx].get_weights()[1:]
                    self.allLayersParam[-1]["dataout_min"] = dataOutMinMax[0]
                    self.allLayersParam[-1]["dataout_max"] = dataOutMinMax[1]

                skipLayer = True

            ################################################################################################

            elif layerType == "ReLU":
                # If current layer is only an activation, integrate it to previous layer
                #
                if not validLayerFound:
                    logging.error("First layer shall not be an 'Activation'!")
                    exit(1)
                elif (
                    "activation" in self.allLayersParam[-1]
                    and self.allLayersParam[-1]["activation"] != "linear"
                ):
                    logging.error("An 'Activation' cannot be followed by another 'Activation'!")
                    exit(1)
                else:
                    self.allLayersParam[-1]["activation"] = "relu"
                    self.allLayersParam[-1]["refname"] = (
                        l.name
                    )  # Give the reference to the head of this group

                if quantizedLayer:
                    dataOutMinMax = self.sorted_layers[idx].get_weights()[1:]
                    self.allLayersParam[-1]["dataout_min"] = dataOutMinMax[0]
                    self.allLayersParam[-1]["dataout_max"] = dataOutMinMax[1]

                skipLayer = True

            ################################################################################################
            elif layerType == "Dense":
                validLayerFound = True
                flattenedOutput = 1
                layerParam["type"] = "dense"

                if quantizedLayer:
                    if type(lConfig["activation"]) == str:
                        layerParam["activation"] = lConfig["activation"]
                        logging.error("Activation outside Dense or Conv layers!")
                        exit(1)
                    else:
                        layerParam["activation"] = lConfig["activation"]["config"]["activation"]
                else:
                    layerParam["activation"] = lConfig["activation"]

                layerParam["ofmap_width"] = 1
                layerParam["ofmap_height"] = 1
                layerParam["ofmap_depth"] = lConfig["units"]
                layerParam["ifmap_width"] = inputWidth
                layerParam["ifmap_height"] = inputHeight
                layerParam["ifmap_depth"] = inputDepth
                layerParam["refname"] = lName

                # Find the ifmap source of the layer
                if len(self.allLayersParam) == 0:
                    layerParam["ifmap_source"] = "prev"
                else:
                    layerParam["ifmap_source"] = l.inbound_nodes[0].inbound_layers.name

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layerParam["ifmap_source"])
                    layerParam["ifmap_source_idx"] = ifmap_layer_idx
                    dataInMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layerParam["ifmap_source_idx"] = -1

                # Add weights
                #
                floatBiases = np.zeros(layerParam["ofmap_depth"])
                weightsMinMax = [None, None]
                dataOutMinMax = [None, None]
                for weightPart in l.weights:
                    if "kernel:" in weightPart.name:
                        floatWeights = weightPart.read_value().numpy()
                    elif "bias:" in weightPart.name:
                        floatBiases = weightPart.read_value().numpy()
                    elif "kernel_min:" in weightPart.name:
                        weightsMinMax[0] = weightPart.read_value().numpy()
                    elif "kernel_max:" in weightPart.name:
                        weightsMinMax[1] = weightPart.read_value().numpy()
                    elif "_activation_min:" in weightPart.name:
                        dataOutMinMax[0] = weightPart.read_value().numpy()
                    elif "_activation_max:" in weightPart.name:
                        dataOutMinMax[1] = weightPart.read_value().numpy()

                # Check quantization parameters are correctly retrieved
                #
                if quantizedLayer and (
                    weightsMinMax[0] == None
                    or weightsMinMax[1] == None
                    or dataOutMinMax[0] == None
                    or dataOutMinMax[1] == None
                ):
                    logging.error(
                        "Quantization metrics not found in the TF model, layer %s!",
                        layerParam["refname"],
                    )
                    exit(1)

                # Batch normalization fusing if possible
                #
                if self.batchnorm_fusing(floatWeights, floatBiases, idx):
                    logging.info("Fusing 'BatchNormalization' layer with previous layer")
                    bnLayerFused = True
                    l_next1 = self.sorted_layers[idx + 1]
                    l_next2 = self.sorted_layers[idx + 2]
                    if l_next2.__class__.__name__.startswith("Quantize"):
                        l_next2Type = l_next2.layer.__class__.__name__
                    else:
                        l_next2Type = l_next2.__class__.__name__
                    weightsMinMax = [np.amin(floatWeights), np.amax(floatWeights)]
                    layerParam["refname"] = l_next1.get_config()["name"]
                    if l_next2Type in ["Activation", "ReLU"]:
                        activation_next = True
                        # dataOutMinMax taken from next activation layer
                        if quantizedLayer:
                            dataOutMinMax = l_next2.get_weights()[1:]
                        # Activation fusing
                        if l_next2Type == "Activation":
                            if l_next2.__class__.__name__.startswith("QuantizeWrapper"):
                                layerParam["activation"] = l_next2.layer.get_config()["activation"]
                            else:
                                layerParam["activation"] = l_next2.get_config()["activation"]
                        else:
                            layerParam["activation"] = "relu"

                        layerParam["refname"] = l_next2.get_config()["name"]

                # Convert weights to integer
                #
                if quantizedLayer:
                    (
                        layerParam["biases"],
                        layerParam["weights"],
                        layerParam["scaling_factor"],
                        layerParam["scaling_exponent"],
                        layerParam["weights_zero"],
                        layerParam["ofmap_zero"],
                    ) = self.convert_to_int(
                        floatBiases, floatWeights, weightsMinMax, dataInMinMax, dataOutMinMax
                    )
                    nOutputs = lConfig["units"]
                else:
                    layerParam["biases"] = floatBiases
                    layerParam["weights"] = floatWeights
                    layerParam["scaling_factor"] = 0
                    layerParam["scaling_exponent"] = 0
                    layerParam["weights_zero"] = 0
                    layerParam["ofmap_zero"] = 0
                    nOutputs = l.units

                layerParam["dataout_min"] = dataOutMinMax[0]
                layerParam["dataout_max"] = dataOutMinMax[1]
                curr_fmap_zero = layerParam["ofmap_zero"]

                layerNwordData = int(np.ceil(nOutputs / (N_MIPE * MIPE_PAR)))
                nWordNeed = prevLayerNwordData + layerNwordData
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                self.layerCycles += int(
                    np.ceil(nOutputs / N_MIPE)
                    * (
                        biasRCycle
                        + layerParam["ifmap_width"]
                        * layerParam["ifmap_height"]
                        * np.ceil(layerParam["ifmap_depth"] / MIPE_PAR)
                    )
                )

            ################################################################################################
            elif layerType == "Conv2D" or layerType == "DepthwiseConv2D":
                validLayerFound = True

                if layerType == "Conv2D":
                    layerParam["type"] = "conv"
                else:
                    layerParam["type"] = "conv_dw"

                if quantizedLayer:
                    if type(lConfig["activation"]) == str:
                        layerParam["activation"] = lConfig["activation"]
                        logging.error("Activation outside Dense or Conv layers!")
                        exit(1)
                    else:
                        layerParam["activation"] = lConfig["activation"]["config"]["activation"]
                else:
                    layerParam["activation"] = lConfig["activation"]

                if lConfig["dilation_rate"] != (1, 1):
                    logging.error("'Dilation' > 1 is not supported!")
                    exit(1)

                if lConfig["padding"] != "same" and lConfig["padding"] != "valid":
                    logging.error("Unknown padding type (%s)!" % lConfig["padding"])
                    exit(1)

                layerParam["ifmap_width"] = inputWidth
                layerParam["ifmap_height"] = inputHeight
                layerParam["ifmap_depth"] = inputDepth
                layerParam["ofmap_width"] = l.output_shape[2]
                layerParam["ofmap_height"] = l.output_shape[1]
                layerParam["ofmap_depth"] = l.output_shape[3]
                layerParam["kernel_size_x"] = lConfig["kernel_size"][1]
                layerParam["kernel_size_y"] = lConfig["kernel_size"][0]
                layerParam["stride_x"] = lConfig["strides"][1]
                layerParam["stride_y"] = lConfig["strides"][0]
                layerParam["dilation_x"] = lConfig["dilation_rate"][1]
                layerParam["dilation_y"] = lConfig["dilation_rate"][0]
                layerParam["padding"] = lConfig["padding"]
                layerParam["refname"] = lName

                # Find the ifmap source of the layer
                if len(self.allLayersParam) == 0:
                    layerParam["ifmap_source"] = "prev"
                else:
                    layerParam["ifmap_source"] = l.inbound_nodes[0].inbound_layers.name

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layerParam["ifmap_source"])
                    layerParam["ifmap_source_idx"] = ifmap_layer_idx
                    dataInMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layerParam["ifmap_source_idx"] = -1

                # Add weights
                #
                floatBiases = np.zeros(layerParam["ofmap_depth"])
                weightsMinMax = [None, None]
                dataOutMinMax = [None, None]
                for weightPart in l.weights:
                    if "kernel:" in weightPart.name:
                        floatWeights = weightPart.read_value().numpy()
                    elif "bias:" in weightPart.name:
                        floatBiases = weightPart.read_value().numpy()
                    elif "kernel_min:" in weightPart.name:
                        weightsMinMax[0] = weightPart.read_value().numpy()
                    elif "kernel_max:" in weightPart.name:
                        weightsMinMax[1] = weightPart.read_value().numpy()
                    elif "_activation_min:" in weightPart.name:
                        dataOutMinMax[0] = weightPart.read_value().numpy()
                    elif "_activation_max:" in weightPart.name:
                        dataOutMinMax[1] = weightPart.read_value().numpy()

                # Check quantization parameters are correctly retrieved
                #
                if quantizedLayer and (
                    weightsMinMax[0] == None
                    or weightsMinMax[1] == None
                    or dataOutMinMax[0] == None
                    or dataOutMinMax[1] == None
                ):
                    logging.error(
                        "Quantization metrics not found in the TF model, layer %s!",
                        layerParam["refname"],
                    )
                    exit(1)

                if layerType == "DepthwiseConv2D":
                    # Output depth position can be different for depthwise conv. with TF
                    floatWeights = np.reshape(
                        floatWeights,
                        (
                            floatWeights.shape[0],
                            floatWeights.shape[1],
                            1,
                            layerParam["ifmap_depth"],
                        ),
                    )

                # Batch normalization fusing if possible
                #
                if self.batchnorm_fusing(floatWeights, floatBiases, idx):
                    logging.info("Fusing 'BatchNormalization' layer with previous layer")
                    bnLayerFused = True
                    l_next1 = self.sorted_layers[idx + 1]
                    l_next2 = self.sorted_layers[idx + 2]
                    if l_next2.__class__.__name__.startswith("Quantize"):
                        l_next2Type = l_next2.layer.__class__.__name__
                    else:
                        l_next2Type = l_next2.__class__.__name__
                    weightsMinMax = [np.amin(floatWeights), np.amax(floatWeights)]
                    layerParam["refname"] = l_next1.get_config()["name"]
                    if l_next2Type in ["Activation", "ReLU"]:
                        activation_next = True
                        # dataOutMinMax taken from next activation layer
                        if quantizedLayer:
                            dataOutMinMax = l_next2.get_weights()[1:]
                        # Activation fusing
                        if l_next2Type == "Activation":
                            if l_next2.__class__.__name__.startswith("QuantizeWrapper"):
                                layerParam["activation"] = l_next2.layer.get_config()["activation"]
                            else:
                                layerParam["activation"] = l_next2.get_config()["activation"]
                        else:
                            layerParam["activation"] = "relu"
                        layerParam["refname"] = l_next2.get_config()["name"]

                # Convert weights to integer
                #
                if quantizedLayer:
                    (
                        layerParam["biases"],
                        layerParam["weights"],
                        layerParam["scaling_factor"],
                        layerParam["scaling_exponent"],
                        layerParam["weights_zero"],
                        layerParam["ofmap_zero"],
                    ) = self.convert_to_int(
                        floatBiases, floatWeights, weightsMinMax, dataInMinMax, dataOutMinMax
                    )
                else:
                    layerParam["biases"] = floatBiases
                    layerParam["weights"] = floatWeights
                    layerParam["scaling_factor"] = 0
                    layerParam["scaling_exponent"] = 0
                    layerParam["weights_zero"] = 0
                    layerParam["ofmap_zero"] = 0

                layerParam["dataout_min"] = dataOutMinMax[0]
                layerParam["dataout_max"] = dataOutMinMax[1]
                curr_fmap_zero = layerParam["ofmap_zero"]

                if layerType == "Conv2D":
                    npack = (
                        int(np.floor(N_MIPE / l.output_shape[3]))
                        if l.output_shape[3] < N_MIPE
                        else 1
                    )
                    layerNwordData = (
                        np.ceil(l.output_shape[3] / N_MIPE)
                        * l.output_shape[1]
                        * np.ceil(l.output_shape[2] / MIPE_PAR)
                    )
                    layerNwordData = int(np.ceil(layerNwordData / npack))
                    nWordNeed = int(
                        prevLayerNwordData
                        + np.ceil(l.output_shape[3] / N_MIPE)
                        * np.ceil(layerParam["kernel_size_y"] / 2)
                        * np.ceil(l.output_shape[2] / MIPE_PAR)
                        + 1
                    )
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData

                    if layerParam["ifmap_depth"] <= 1:
                        cycle_per_kernel = int(
                            np.ceil(
                                layerParam["kernel_size_x"] * layerParam["kernel_size_y"] / MIPE_PAR
                            )
                        )
                        self.layerCycles += int(
                            (biasRCycle * np.ceil(l.output_shape[3] / N_MIPE))
                            + (
                                cycle_per_kernel
                                * l.output_shape[1]
                                * l.output_shape[2]
                                * np.ceil(l.output_shape[3] / N_MIPE)
                            )
                        )
                    else:
                        self.layerCycles += int(
                            (biasRCycle * np.ceil(l.output_shape[3] / N_MIPE))
                            + (
                                np.ceil(inputDepth / MIPE_PAR)
                                * layerParam["kernel_size_x"]
                                * layerParam["kernel_size_y"]
                                * l.output_shape[1]
                                * l.output_shape[2]
                                * np.ceil(l.output_shape[3] / N_MIPE)
                            )
                        )

                else:
                    npack = (
                        int(np.floor(N_MIPE / l.output_shape[3]))
                        if l.output_shape[3] < N_MIPE
                        else 1
                    )
                    layerNwordData = (
                        np.ceil(l.output_shape[3] / N_MIPE)
                        * l.output_shape[1]
                        * np.ceil(l.output_shape[2] / MIPE_PAR)
                    )
                    layerNwordData = int(np.ceil(layerNwordData / npack))
                    nWordNeed = int(
                        prevLayerNwordData
                        + np.ceil(layerParam["kernel_size_y"] / 2)
                        * np.ceil(l.output_shape[2] / MIPE_PAR)
                        + 1
                    )
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData

                    cycle_per_kernel = int(
                        np.ceil(
                            layerParam["kernel_size_x"] * layerParam["kernel_size_y"] / MIPE_PAR
                        )
                    )
                    self.layerCycles += int(
                        (biasRCycle * np.ceil(l.output_shape[3] / N_MIPE))
                        + (
                            cycle_per_kernel
                            * l.output_shape[1]
                            * l.output_shape[2]
                            * np.ceil(l.output_shape[3] / N_MIPE)
                        )
                    )

            ################################################################################################
            elif layerType in ["MaxPooling2D", "AveragePooling2D", "GlobalAveragePooling2D"]:
                if (layerType == "GlobalAveragePooling2D" and inputWidth == inputHeight == 1) or (
                    layerType in ["MaxPooling2D", "AveragePooling2D"]
                    and lConfig["pool_size"][1] == lConfig["pool_size"][0] == 1
                ):
                    skipLayer = True
                    if len(self.allLayersParam):
                        self.allLayersParam[-1]["refname"] = l.name
                else:
                    validLayerFound = True

                    if layerType == "MaxPooling2D":
                        layerParam["type"] = "max_pool"
                    else:
                        layerParam["type"] = "avg_pool"
                    layerParam["ifmap_width"] = inputWidth
                    layerParam["ifmap_height"] = inputHeight
                    layerParam["ifmap_depth"] = inputDepth
                    layerParam["refname"] = lName
                    if layerType == "GlobalAveragePooling2D":
                        layerParam["ofmap_width"] = 1
                        layerParam["ofmap_height"] = 1
                        layerParam["ofmap_depth"] = inputDepth
                        layerParam["pool_size_x"] = inputWidth
                        layerParam["pool_size_y"] = inputHeight
                        layerParam["stride_x"] = 1
                        layerParam["stride_y"] = 1
                        layerParam["padding"] = "valid"
                    else:
                        layerParam["ofmap_width"] = l.output_shape[2]
                        layerParam["ofmap_height"] = l.output_shape[1]
                        layerParam["ofmap_depth"] = l.output_shape[3]
                        layerParam["pool_size_x"] = lConfig["pool_size"][1]
                        layerParam["pool_size_y"] = lConfig["pool_size"][0]
                        layerParam["stride_x"] = lConfig["strides"][1]
                        layerParam["stride_y"] = lConfig["strides"][0]
                        layerParam["padding"] = lConfig["padding"]
                    layerParam["activation"] = "linear"
                    # Find the ifmap source of the layer
                    if len(self.allLayersParam) == 0:
                        layerParam["ifmap_source"] = "prev"
                    else:
                        layerParam["ifmap_source"] = l.inbound_nodes[0].inbound_layers.name

                    if len(self.allLayersParam) > 0:
                        ifmap_layer_idx = self.get_layer_idx_by_name(layerParam["ifmap_source"])
                        layerParam["ifmap_source_idx"] = ifmap_layer_idx
                        dataOutMinMax = [
                            self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                            self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                        ]
                    else:
                        layerParam["ifmap_source_idx"] = -1

                    # Scaling factor is used in case of average pooling to divide by the number of values
                    layerParam["scaling_factor"] = int(
                        (2**self.scalingNumbits)
                        / (layerParam["pool_size_x"] * layerParam["pool_size_y"])
                    )
                    layerParam["scaling_exponent"] = 0

                    layerParam["dataout_min"] = dataOutMinMax[0]
                    layerParam["dataout_max"] = dataOutMinMax[1]
                    if layerType == "AveragePooling2D" and layerParam["padding"] != "valid":
                        logging.warning(
                            "Only 'valid' padding is fully supported with AveragePooling2D layer"
                        )

                    npack = (
                        int(np.floor(N_MIPE / layerParam["ofmap_depth"]))
                        if layerParam["ofmap_depth"] < N_MIPE
                        else 1
                    )
                    layerNwordData = (
                        np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                        * layerParam["ofmap_height"]
                        * np.ceil(layerParam["ofmap_width"] / MIPE_PAR)
                    )
                    layerNwordData = int(np.ceil(layerNwordData / npack))

                    nWordNeed = int(
                        prevLayerNwordData
                        + np.ceil(layerParam["pool_size_y"] / 2)
                        * np.ceil(layerParam["ofmap_width"] / MIPE_PAR)
                        + 1
                    )
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData

                    cycle_per_kernel = int(
                        np.ceil(layerParam["pool_size_y"] * layerParam["pool_size_y"] / MIPE_PAR)
                    )
                    self.layerCycles += int(
                        cycle_per_kernel
                        * layerParam["ofmap_width"]
                        * layerParam["ofmap_height"]
                        * np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                    )

            elif layerType == "Add":
                inbound_layer_list = l.inbound_nodes[0].inbound_layers
                if len(inbound_layer_list) != 2:
                    logging.error("'Add' layer shall take only 2 input nodes.")
                    exit(1)
                else:
                    inbound_layer1_refname = inbound_layer_list[0].name
                    inbound_layer2_refname = inbound_layer_list[1].name

                # Assuming that one of the input ifmaps comes from the previous layer
                if (
                    self.allLayersParam[-1]["refname"] != inbound_layer1_refname
                    and self.allLayersParam[-1]["refname"] != inbound_layer2_refname
                ):
                    logging.error("One input of 'Add' layer must be the previous layer.")
                    exit(1)

                layerParam["type"] = "add"
                if self.allLayersParam[-1]["refname"] != inbound_layer1_refname:
                    layerParam["in_refname"] = inbound_layer1_refname
                else:
                    layerParam["in_refname"] = inbound_layer2_refname

                layerParam["ifmap_width"] = inputWidth
                layerParam["ifmap_height"] = inputHeight
                layerParam["ifmap_depth"] = inputDepth
                layerParam["ofmap_width"] = l.output_shape[2]
                layerParam["ofmap_height"] = l.output_shape[1]
                layerParam["ofmap_depth"] = l.output_shape[3]
                layerParam["refname"] = lName
                layerParam["activation"] = "linear"

                layerParam["ifmap_source"] = "prev"
                layerParam["ifmap_source_idx"] = -1

                dataOutMinMax = [None, None]
                l_next = self.sorted_layers[idx + 1]

                for weightPart in l.weights:
                    if "output_min:" in weightPart.name:
                        dataOutMinMax[0] = weightPart.read_value().numpy()
                    elif "output_max:" in weightPart.name:
                        dataOutMinMax[1] = weightPart.read_value().numpy()
                # If the next layer is an Activation, TF puts the quantization information in it
                l_next = self.sorted_layers[idx + 1]
                if l_next.__class__.__name__.startswith("Quantize"):
                    l_nextType = l_next.layer.__class__.__name__
                else:
                    l_nextType = l_next.__class__.__name__

                if l_nextType == "Activation" or l_nextType == "ReLU":
                    for weightPart in l_next.weights:
                        if "output_min:" in weightPart.name:
                            dataOutMinMax[0] = weightPart.read_value().numpy()
                        elif "output_max:" in weightPart.name:
                            dataOutMinMax[1] = weightPart.read_value().numpy()

                layerParam["dataout_min"] = dataOutMinMax[0]
                layerParam["dataout_max"] = dataOutMinMax[1]

                # Add quantization: computes layer parameters
                #
                if quantizedLayer:
                    if dataOutMinMax[0] == None or dataOutMinMax[1] == None:
                        logging.error(
                            "Quantization metrics not found in the TF model, layer %s!",
                            layerParam["refname"],
                        )
                        exit(1)

                    # Get input layers min/max
                    in_layer1_minmax = [
                        self.allLayersParam[-1]["dataout_min"],
                        self.allLayersParam[-1]["dataout_max"],
                    ]
                    in_layer2_minmax = [None, None]
                    for ll in self.allLayersParam:
                        if ll["refname"] == layerParam["in_refname"]:
                            in_layer2_minmax = [ll["dataout_min"], ll["dataout_max"]]
                            break
                    if in_layer2_minmax == [None, None]:
                        logging.error("Unable to retrive skip layer parameters!")
                        exit(1)

                    (
                        layerParam["bias"],
                        layerParam["weight1"],  # Weight to input 1 (previous layer)
                        layerParam["weight2"],  # Weight to input 2 (skipped layer)
                        layerParam["scaling_factor"],
                        layerParam["scaling_exponent"],
                        layerParam["ofmap_zero"],
                    ) = self.compute_add_params(in_layer1_minmax, in_layer2_minmax, dataOutMinMax)
                else:
                    layerParam["bias"] = 0
                    layerParam["weight1"] = 0
                    layerParam["weight2"] = 0
                    layerParam["scaling_factor"] = 0
                    layerParam["scaling_exponent"] = 0
                    layerParam["ofmap_zero"] = 0

                curr_fmap_zero = layerParam["ofmap_zero"]

                npack = (
                    int(np.floor(N_MIPE / layerParam["ofmap_depth"]))
                    if layerParam["ofmap_depth"] < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(layerParam["ofmap_depth"] / N_MIPE)
                    * layerParam["ofmap_height"]
                    * np.ceil(layerParam["ofmap_width"] / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))
                nWordNeed = int(prevLayerNwordData * 2 + layerNwordData)
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                outH, outW, outC = l.output_shape[1], l.output_shape[2], l.output_shape[3]
                nDepthOutGrp = int(np.ceil(outC / N_MIPE))
                self.layerCycles += int(outH * outW * nDepthOutGrp)

            ################################################################################################
            else:
                logging.info("Removing '%s' layer in final model" % lName)
                if len(self.allLayersParam) > 0:
                    self.allLayersParam[-1]["refname"] = (
                        lName  # Give the reference to the head of this group
                    )
                skipLayer = True
                self.layerCycles += LAYER_EXTRA_CYCLES

            idx += 1
            self.layerCycles += LAYER_EXTRA_CYCLES
            if not skipLayer:
                prevLayerNwordData = layerNwordData
                self.allLayersParam += [layerParam]
                if bnLayerFused and activation_next:
                    idx += 2  # Skip next batch normalization and activation layers

        # Adding extra information to layer 0
        self.allLayersParam[0]["flattenedOutput"] = flattenedOutput
        self.allLayersParam[0]["quantNumbits"] = self.quantNumbits
        self.allLayersParam[0]["biasNumbits"] = self.biasNumbits
        self.allLayersParam[0]["scalingNumbits"] = self.scalingNumbits
        self.allLayersParam[0]["scalingExpMax"] = self.scalingExpMax
        if dataOutMinMax[0] == None or dataOutMinMax[1] == None:
            dataOutMinMax = [0, 1]
        self.allLayersParam[0]["outputScalingFloat"], self.allLayersParam[0]["outputZeroFloat"] = (
            self.minmax_to_scale(
                dataOutMinMax[0], dataOutMinMax[1], int((2**self.quantNumbits) - 1)
            )
        )
        self.allLayersParam[0]["inputMin"] = self.inputMinMax[0]
        self.allLayersParam[0]["inputMax"] = self.inputMinMax[1]

        if self.is_quantized_model():
            _, nnInputDataZero = self.minmax_to_scale(
                self.inputMinMax[0], self.inputMinMax[1], int((2**self.quantNumbits) - 1)
            )
            self.allLayersParam[0]["nnInputDataZero"] = int(np.round(nnInputDataZero))
        else:
            self.allLayersParam[0]["nnInputDataZero"] = 0

        ## Final check on activations
        for i in range(len(self.allLayersParam) - 1):
            if "activation" in self.allLayersParam[i]:
                activationName = self.allLayersParam[i]["activation"]
                if activationName not in ["linear", "relu"]:
                    logging.error(
                        "Activation '%s' is not supported except for last layer" % activationName
                    )
                    exit(1)
        nnMembuffData = int(np.ceil(maxNwordData / NWORD_BUFFER))
        self.layerCycles += NN_EXTRA_CYCLES
        return self.allLayersParam
