# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2026 Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import argparse
import numpy as np
import onnxruntime
import onnx
import time
from PIL import Image
from onnxruntime.quantization import QuantFormat, QuantType, quantize_static, CalibrationDataReader
import os


def benchmark(model_path):
    session = onnxruntime.InferenceSession(model_path)
    input_name = session.get_inputs()[0].name

    total = 0.0
    runs = 10
    # input_data = np.zeros((1, 28, 28, 1), np.float32)
    input_data = np.zeros((1, 96, 96, 3), np.float32)
    # Warming up
    _ = session.run([], {input_name: input_data})
    for i in range(runs):
        start = time.perf_counter()
        _ = session.run([], {input_name: input_data})
        end = (time.perf_counter() - start) * 1000
        total += end
        print(f"{end:.2f}ms")
    total /= runs
    print(f"Avg: {total:.2f}ms")


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_model", required=True, help="input model")
    parser.add_argument("--output_model", required=True, help="output model")
    parser.add_argument("--calibrate_dataset", default="./test_images", help="calibration data set")
    parser.add_argument(
        "--quant_format",
        # default=QuantFormat.QOperator,
        default=QuantFormat.QDQ,
        type=QuantFormat.from_string,
        choices=list(QuantFormat),
    )
    parser.add_argument("--per_channel", default=True, type=bool)
    args = parser.parse_args()
    return args


def representative_dataset_gen():
    dataset_dir = os.path.join(BASE_DIR, "person")
    for idx, image_file in enumerate(os.listdir(dataset_dir)):
        # 10 representative images should be enough for calibration.
        if idx > 10:
            return
        full_path = os.path.join(dataset_dir, image_file)
        if os.path.isfile(full_path):
            img = tf.keras.preprocessing.image.load_img(full_path, color_mode="rgb").resize(
                (96, 96)
            )
            arr = tf.keras.preprocessing.image.img_to_array(img)
            # Scale input to [0, 1.0] like in training.
            yield [arr.reshape(1, 96, 96, 3) / 255.0]


def _preprocess_images(images_folder: str, height: int, width: int, size_limit=0):
    dataset_dir = os.path.join(images_folder, "train")
    images_data = []
    folder_dir = os.path.join(dataset_dir, "person")
    for idx, image_file in enumerate(os.listdir(folder_dir)):
        if idx > 10:
            break

        full_path = os.path.join(folder_dir, image_file)
        if os.path.isfile(full_path):
            img = Image.open(full_path).convert("RGB").resize((width, height))
            input_data = np.float32(img)
            input_data /= 255
            input_data = np.expand_dims(input_data, axis=0)
            images_data.append(input_data)
    print(images_data[0].shape)
    return images_data


# def _preprocess_images(images_folder: str, height: int, width: int, size_limit=0):
#     """
#     Loads a batch of images and preprocess them
#     parameter images_folder: path to folder storing images
#     parameter height: image height in pixels
#     parameter width: image width in pixels
#     parameter size_limit: number of images to load. Default is 0 which means all images are picked.
#     return: list of matrices characterizing multiple images
#     """
#     dataset_dir = os.path.join(images_folder, "train")
#     images_per_class = 10  # Define the number of images per class
#     images_taken = {}  # Dictionary to keep track of images per class
#     images_data = []
#     for dir in os.listdir(dataset_dir):
#         folder_dir = os.path.join(dataset_dir, dir)
#         images_taken[dir] = 0  # Initialize the counter for each class

#         for image_file in os.listdir(folder_dir):
#             # Stop if we've taken the required number of images for this class
#             if images_taken[dir] >= images_per_class:
#                 break

#             full_path = os.path.join(folder_dir, image_file)
#             #print("img_file:", full_path)

#             if os.path.isfile(full_path):
#                 img = Image.open(full_path).convert('L').resize((width, height))
#                 input_data = np.float32(img)
#                 input_data /= 255
#                 input_data = np.expand_dims(input_data, axis=-1)  # Add channel dimension (C x H x W)
#                 input_data = np.expand_dims(input_data, axis=0)
#                 images_data.append(input_data)
#                 images_taken[dir] += 1
#     print(images_data[0].shape)
#     return images_data


class DataReader(CalibrationDataReader):
    def __init__(self, calibration_image_folder: str, model_path: str):
        self.enum_data = None

        # Use inference session to get input shape.
        session = onnxruntime.InferenceSession(model_path, None)
        print(session.get_inputs()[0].shape)
        (_, height, width, _) = session.get_inputs()[0].shape

        # Convert image to input data
        self.nhwc_data_list = _preprocess_images(
            calibration_image_folder, height, width, size_limit=0
        )
        self.input_name = session.get_inputs()[0].name
        self.datasize = len(self.nhwc_data_list)

    def get_next(self):
        if self.enum_data is None:
            self.enum_data = iter(
                [{self.input_name: nhwc_data} for nhwc_data in self.nhwc_data_list]
            )
        return next(self.enum_data, None)

    def rewind(self):
        self.enum_data = None


def main():
    args = get_args()
    input_model_path = args.input_model
    output_model_path = args.output_model
    calibration_dataset_path = args.calibrate_dataset
    dr = DataReader(calibration_dataset_path, input_model_path)

    # Turn off model optimization during quantization
    quantize_static(
        input_model_path,
        output_model_path,
        dr,
        quant_format=args.quant_format,
        per_channel=args.per_channel,
        activation_type=QuantType.QUInt8,  # Asymmetric uint8 for activations
        weight_type=QuantType.QInt8,  # Symmetric int8 for weights
    )

    print("Calibrated and quantized model saved.")

    print("benchmarking fp32 model...")
    benchmark(input_model_path)

    print("benchmarking int8 model...")
    benchmark(output_model_path)


if __name__ == "__main__":
    # Before running the quantization run as explained in https://onnxruntime.ai/docs/performance/model-optimizations/quantization.html
    # python -m onnxruntime.quantization.preprocess --input ./NN_BLAZE_FASHION/output/trained_model.onnx --output  ./NN_BLAZE_FASHION/output/trained_model_infer.onnx
    # python3 quantize_onnx.py --input_model ../NN_BLAZE_FASHION/output/trained_model_infer.onnx --output_model ../NN_BLAZE_FASHION/output/trained_model_qdq.onnx --calibrate_dataset /nfs/work/board/DATASETS/FASHION-MNIST/
    main()
