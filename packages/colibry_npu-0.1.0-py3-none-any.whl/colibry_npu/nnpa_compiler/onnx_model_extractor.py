# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2026 Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import onnx
import onnx.numpy_helper
import numpy as np
import logging
import math
from collections import deque

ACTIVATION_TYPES = {
    "Relu": "relu",
    "Softmax": "softmax",
    "Identity": "linear",
}

PADDING_TYPES = {
    "SAME_UPPER": "same",
    "VALID": "valid",
}

NWORD_BUFFER = 1024
N_MIPE = 8
MIPE_PAR = 2


class ONNXModelExtractor:
    def __init__(
        self,
        model_path,
        quantNumbits,
        biasNumbits,
        scalingNumbits,
        scalingExpMax,
        inputMinMax=[0, 1],
    ):
        self.model_path = model_path
        self.model = self.load_model()
        self.quantNumbits = quantNumbits
        self.biasNumbits = biasNumbits
        self.scalingNumbits = scalingNumbits
        self.scalingExpMax = scalingExpMax
        self.inputMinMax = inputMinMax
        self.allLayersParam = []

    def load_model(self):
        try:
            model = onnx.load(self.model_path)
            inferred_model = onnx.shape_inference.infer_shapes(model)
            return inferred_model
        except Exception as e:
            logging.error(f"Failed to load model: {e}")
            exit(1)

    def is_quantized_model(self):
        graph = self.model.graph
        for node in graph.node:
            if node.op_type == "QuantizeLinear":
                return True
        return False

    def get_layer_idx_by_name(self, layer_refname):
        if layer_refname == "prev":
            return -1
        for k in range(len(self.allLayersParam)):
            if self.allLayersParam[k]["refname"] == layer_refname:
                return k
        return None

    def get_layer_type_name(self, node):
        return node.op_type

    def get_tensor_data(self, tensor_name, graph):
        for initializer in graph.initializer:
            if initializer.name == tensor_name:
                return onnx.numpy_helper.to_array(initializer)
        return None

    def check_model_compatibility(self, graph):
        compatError = True
        for node in graph.node:
            layer_type_name = self.get_layer_type_name(node)
            if layer_type_name == "BatchNormalization":
                compatError = False
                logging.error(
                    "The layer BatchNormalization layer should be fused ! Please use onnxsim to simplify the model"
                )
                exit(1)
            elif layer_type_name not in [
                "QuantizeLinear",
                "DequantizeLinear",
                "QLinearConv",
                "Conv",
                "Relu",
                "QLinearGlobalAveragePool",
                "QLinearAveragePool",
                "MaxPool",
                "AveragePool",
                "GlobalAveragePool",
                "Sigmoid",
                "QLinearSigmoid",
                "Softmax",
                "QLinearSoftmax",
                "MatMul",
                "Gemm",
                "QGemm",
                "Add",
                "QLinearAdd",
                "Reshape",
                "Squeeze",
                "Clip",
                "Transpose",
                "Flatten",
            ]:
                compatError = False
                logging.error("The layer %s is unsupported", layer_type_name)
                exit(1)
        return compatError

    def get_tensor_shape(self, tensor_name, graph):
        """
        Retrieves the shape of a tensor from the ONNX graph.
        """
        # Check in value_info
        for value_info in graph.value_info:
            if value_info.name == tensor_name:
                return self.extract_shape_from_value_info(value_info)

        # Check in graph inputs
        for value_info in graph.input:
            if value_info.name == tensor_name:
                return self.extract_shape_from_value_info(value_info)

        # Check in graph outputs
        for value_info in graph.output:
            if value_info.name == tensor_name:
                return self.extract_shape_from_value_info(value_info)

        # If shape is not found, return None
        return None

    def extract_shape_from_value_info(self, value_info):
        """
        Extracts shape information from a ValueInfoProto object.
        """
        tensor_type = value_info.type.tensor_type
        if not tensor_type.HasField("shape"):
            return None
        shape = []
        for dim in tensor_type.shape.dim:
            if dim.HasField("dim_value"):  # Known dimension
                shape.append(dim.dim_value)
            else:  # Unknown dimension
                shape.append(None)  # Use None for dynamic dimensions
        return shape

    def compute_conv_output_shape(self, input_shape, weight_shape, stride, padding, dilation):
        C_in, H_in, W_in = input_shape
        C_out, _, K_h, K_w = weight_shape
        S_h, S_w = stride
        P_top, P_left, P_bottom, P_right = padding
        D_h, D_w = dilation

        # Formule de calcul de la sortie
        H_out = (H_in + P_top + P_bottom - D_h * (K_h - 1) - 1) // S_h + 1
        W_out = (W_in + P_left + P_right - D_w * (K_w - 1) - 1) // S_w + 1
        return [C_out, W_out, H_out]

    def compute_pooling_output_shape(self, input_shape, kernel_size, stride, pads, dilation=(1, 1)):
        _, H_in, W_in = input_shape
        K_h, K_w = kernel_size
        S_h, S_w = stride
        P_top, P_left, P_bottom, P_right = pads
        D_h, D_w = dilation
        H_out = math.floor((H_in + P_top + P_bottom - (D_h * (K_h - 1) + 1)) / S_h) + 1
        W_out = math.floor((W_in + P_left + P_right - (D_w * (K_w - 1) + 1)) / S_w) + 1

        return [max(W_out, 1), max(H_out, 1)]

    def interpret_padding(self, pads):
        if all(p == 0 for p in pads):
            return "valid"
        else:
            return "same"

    def minmax_to_scale(self, minVal, maxVal, nLevels):
        scaling = (maxVal - minVal) / nLevels
        zero = -minVal / scaling
        return scaling, zero

    def scale_zero_to_minmax(self, scales, zero_points, tensor_dtype=np.uint8):
        iinfo = np.iinfo(tensor_dtype)
        qmin = iinfo.min
        qmax = iinfo.max
        if scales.size == 1:
            scale = scales
            zero_point = zero_points
            min_val = scale * (qmin - zero_point)
            max_val = scale * (qmax - zero_point)
            return [min_val, max_val]
        else:
            min_vals = scales * (qmin - zero_points)
            max_vals = scales * (qmax - zero_points)
            min_val = min_vals.min()
            max_val = max_vals.max()
            return [min_val, max_val]

    def convert_to_int(self, floatBiases, floatWeights, weightsMinMax, dataInMinMax, dataOutMinMax):
        nLevels = int((2**self.quantNumbits) - 1)

        scalingI, zeroI = self.minmax_to_scale(dataInMinMax[0], dataInMinMax[1], nLevels)
        scalingO, zeroO = self.minmax_to_scale(dataOutMinMax[0], dataOutMinMax[1], nLevels)
        scalingW, zeroW = self.minmax_to_scale(weightsMinMax[0], weightsMinMax[1], nLevels)
        zeroWint = int(np.round(zeroW))  # Weights zero is necessarily an integer

        mValue = scalingI * scalingW / scalingO

        # Compute scaling factor
        scalingExponent = self.scalingExpMax
        for exp_val in range(self.scalingExpMax + 1):
            if mValue < 2**exp_val:
                scalingExponent = exp_val
                break

        # Emulate an exponent != 0
        # if np.random.rand() < 0.4:
        #    scalingExponent = np.random.randint(1,4)

        if mValue >= 2**scalingExponent:
            logging.warning(
                "Scaling factor is too high for given hardware parameters (%g)" % mValue
            )
            scalingExponent = self.scalingExpMax
            scalingFactor = 2**self.scalingNumbits - 1
        else:
            scalingFactor = int(np.round(mValue * (2 ** (self.scalingNumbits - scalingExponent))))

        # Convert weights to integers
        uint8Weights = np.zeros(np.shape(floatWeights), dtype="uint8")
        for index, w in np.ndenumerate(floatWeights):
            uint8Weights[index] = min(
                max(int(np.round(w / scalingW + zeroW)), 0), (2**self.quantNumbits) - 1
            )

        # Convert biases to integers
        kernelDim = len(uint8Weights.shape)
        intWeights = np.array(uint8Weights, dtype="int") - zeroWint
        weightSums = np.sum(
            intWeights, axis=tuple(range(kernelDim - 1)), dtype="int"
        )  # Sum of signed weights per filter

        intBiases = np.zeros(np.shape(floatBiases), dtype="int")
        for index, wb in np.ndenumerate(floatBiases):
            biasNew = zeroO / mValue + wb / (scalingI * scalingW) - zeroI * weightSums[index]
            # Saturation check
            if biasNew < -(2 ** (self.biasNumbits - 1)) + 1:
                biasNew = -(2 ** (self.biasNumbits - 1)) + 1
                logging.warning("Bias value low saturation")
            elif biasNew > (2 ** (self.biasNumbits - 1)) - 1:
                biasNew = (2 ** (self.biasNumbits - 1)) - 1
                logging.warning("Bias value high saturation")

            intBiases[index] = int(np.round(biasNew))

        return (
            intBiases,
            uint8Weights,
            scalingFactor,
            scalingExponent,
            zeroWint,
            int(np.round(zeroO)),
        )

    def compute_add_params(self, dataIn1MinMax, dataIn2MinMax, dataOutMinMax):
        nLevels = int((2**self.quantNumbits) - 1)

        scalingI1, zeroI1 = self.minmax_to_scale(dataIn1MinMax[0], dataIn1MinMax[1], nLevels)
        scalingI2, zeroI2 = self.minmax_to_scale(dataIn2MinMax[0], dataIn2MinMax[1], nLevels)
        scalingO, zeroO = self.minmax_to_scale(dataOutMinMax[0], dataOutMinMax[1], nLevels)

        isIn1Larger = scalingI2 >= scalingI1

        # Compute weight applied to the larger input (smaller scaling)
        weightInLarger = int(
            np.round(min(scalingI1, scalingI2) / max(scalingI1, scalingI2) * nLevels)
        )
        weightIn1 = weightInLarger if isIn1Larger else nLevels
        weightIn2 = nLevels if isIn1Larger else weightInLarger

        # Compute float SF
        mValue = max(scalingI1, scalingI2) / scalingO / nLevels

        # Compute int SF
        scalingExponent = self.scalingExpMax
        for exp_val in range(self.scalingExpMax + 1):
            if mValue < 2**exp_val:
                scalingExponent = exp_val
                break

        if mValue >= 2**scalingExponent:
            logging.warning(
                "Scaling factor is too high for given hardware parameters (%g)" % mValue
            )
            scalingExponent = self.scalingExpMax
            scalingFactor = 2**self.scalingNumbits - 1
        else:
            scalingFactor = int(np.round(mValue * (2 ** (self.scalingNumbits - scalingExponent))))

        # Compute bias
        bias = (zeroO - (scalingI1 * zeroI1 + scalingI2 * zeroI2) / scalingO) / mValue
        intBias = int(np.round(bias))

        if intBias >= 2 ** (self.biasNumbits - 1) or intBias <= -(2 ** (self.biasNumbits - 1)):
            logging.warning("Integer bias cannot fit into the expected number of bits")

        return intBias, weightIn1, weightIn2, scalingFactor, scalingExponent, int(np.round(zeroO))

    def dequantize(self, tensor, scales, zero_points):
        if np.isscalar(scales) and np.isscalar(zero_points):
            return (tensor - zero_points) * scales
        if tensor.ndim == 4:
            scales = scales.reshape(-1, 1, 1, 1)
            zero_points = zero_points.reshape(-1, 1, 1, 1)
        elif tensor.ndim == 2:
            scales = scales.reshape(-1, 1)
            zero_points = zero_points.reshape(-1, 1)
        else:
            raise ValueError("Unsupported tensor shape for per-channel quantization.")

        return (tensor - zero_points) * scales

    def resolve_quantized_tensor(self, tensor_name, graph):
        """
        Resolve the actual tensor name by tracing through quantized or dequantized nodes.
        """
        for n in graph.node:
            if tensor_name in n.output:
                if n.op_type == "DequantizeLinear":
                    return (
                        self.get_tensor_data(n.input[0], graph),
                        self.get_tensor_data(n.input[1], graph),
                        self.get_tensor_data(n.input[2], graph),
                    )

    def left_first_dfs_topo_sort_skip_qdq(self, graph):
        visited = set()
        sorted_nodes = []

        qdq_ops = {"QuantizeLinear", "DequantizeLinear", "Cast"}

        adjacency_list = {node.name: [] for node in graph.node}
        node_inputs = {node.name: list(node.input) for node in graph.node}
        node_dict = {node.name: node for node in graph.node}
        output_to_node = {output: node for node in graph.node for output in node.output}

        for node in graph.node:
            for input_name in node.input:
                if input_name in output_to_node:
                    parent = output_to_node[input_name]
                    adjacency_list[parent.name].append(node.name)

        def dfs(node_name):
            if node_name in visited:
                return
            visited.add(node_name)

            children = adjacency_list.get(node_name, [])
            children.sort(key=lambda x: node_inputs[x])

            for child_name in children:
                dfs(child_name)

            for inp in node_inputs.get(node_name, []):
                if inp in output_to_node:
                    qdq_node = output_to_node[inp]
                    if qdq_node.op_type in qdq_ops and qdq_node.name not in visited:
                        visited.add(qdq_node.name)
                        sorted_nodes.append(node_dict[qdq_node.name])

            sorted_nodes.append(node_dict[node_name])

        graph_inputs = {inp.name for inp in graph.input}
        initializer_names = {init.name for init in graph.initializer}

        entry_nodes = [
            node.name
            for node in graph.node
            if node.op_type not in qdq_ops
            and all(
                inp in graph_inputs
                or inp in initializer_names
                or (inp in output_to_node and output_to_node[inp].op_type in qdq_ops)
                for inp in node.input
            )
        ]

        qdq_entry_nodes = [
            node.name
            for node in graph.node
            if node.op_type in qdq_ops
            and all(inp in graph_inputs or inp in initializer_names for inp in node.input)
        ]

        entry_nodes += qdq_entry_nodes

        if not entry_nodes:
            raise ValueError("No entry nodes found! Check if model nodes have proper inputs.")

        for entry in entry_nodes:
            dfs(entry)

        sorted_nodes.reverse()
        return sorted_nodes

    def extract(self):
        maxNwordData = 0
        prevLayerNwordData = 0
        NWEIGHT_BIAS = 3
        LAYER_EXTRA_CYCLES = 8
        NN_EXTRA_CYCLES = 6
        biasRCycle = int(np.ceil(NWEIGHT_BIAS / MIPE_PAR))
        self.layerCycles = 0
        graph = self.model.graph
        self.check_model_compatibility(graph)
        self.inputMinMax = [0, 1]
        if not self.is_quantized_model():
            self.quantNumbits = 32
        i = 0
        flattenedOutput = 0
        dataInMinMax = self.inputMinMax
        dataOutMinMax = self.inputMinMax
        sorted_nodes = self.left_first_dfs_topo_sort_skip_qdq(graph)
        while i < len(sorted_nodes):
            node = sorted_nodes[i]
            layer_type_name = self.get_layer_type_name(node)
            logging.info(f"Found layer: {layer_type_name}")

            if layer_type_name == "QuantizeLinear":
                scale = self.get_tensor_data(node.input[1], graph)
                zero_point = self.get_tensor_data(node.input[2], graph)
                dataInMinMax = self.scale_zero_to_minmax(scale, zero_point)
                dataOutMinMax = self.scale_zero_to_minmax(scale, zero_point)
                if i + 1 < len(sorted_nodes) and self.get_layer_type_name(sorted_nodes[i + 1]) in [
                    "QLinearConv",
                    "QGemm",
                ]:
                    self.inputMinMax = self.scale_zero_to_minmax(scale, zero_point)

            elif layer_type_name == "QLinearConv":
                logging.info(f"Found layer: {node.output[0]}")
                layer_param = {}
                input_tensor_name = node.input[0]
                output_tensor_name = node.output[0]
                weight_tensor_name = node.input[3]
                bias_tensor_name = None
                if len(node.input) > 8:
                    bias_tensor_name = node.input[8]
                scale_input = self.get_tensor_data(node.input[1], graph)
                zero_point_input = self.get_tensor_data(node.input[2], graph)
                scale_output = self.get_tensor_data(node.input[6], graph)
                zero_point_output = self.get_tensor_data(node.input[7], graph)
                dataOutMinMax = self.scale_zero_to_minmax(scale_output, zero_point_output)
                input_shape = self.get_tensor_shape(input_tensor_name, graph)
                output_shape = self.get_tensor_shape(output_tensor_name, graph)
                # Extract weights and biases
                weights = self.get_tensor_data(weight_tensor_name, graph)
                weights_scale = self.get_tensor_data(node.input[4], graph)
                weights_zero_point = self.get_tensor_data(node.input[5], graph)
                float_weights = self.dequantize(weights, weights_scale, weights_zero_point)
                float_weights = float_weights.transpose(2, 3, 1, 0)
                weightsMinMax = [float_weights.min(), float_weights.max()]
                float_biases = np.zeros(weights_scale.shape)
                if bias_tensor_name:
                    biases = self.get_tensor_data(bias_tensor_name, graph)
                    biases_scale = scale_input * weights_scale
                    biases_zero_point = 0
                    float_biases = biases * biases_scale

                attr = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
                layer_param = {"type": "conv" if attr["group"] == 1 else "conv_dw"}
                layer_param["activation"] = "relu" if "Relu" in output_tensor_name else "linear"
                if input_shape is None:
                    prev_layer = self.allLayersParam[self.get_layer_idx_by_name(input_tensor_name)]
                    layer_param["ifmap_width"] = prev_layer["ofmap_width"]
                    layer_param["ifmap_height"] = prev_layer["ofmap_height"]
                    layer_param["ifmap_depth"] = prev_layer["ofmap_depth"]
                    input_shape = [
                        layer_param["ifmap_depth"],
                        layer_param["ifmap_height"],
                        layer_param["ifmap_width"],
                    ]
                    weight_shape = weights.shape
                    stride = attr["strides"]
                    if "pads" in attr:
                        padding = attr["pads"]
                    else:
                        padding = [0, 0, 0, 0]
                    dilation = attr["dilations"]
                    _, layer_param["ofmap_width"], layer_param["ofmap_height"] = (
                        self.compute_conv_output_shape(
                            input_shape, weight_shape, stride, padding, dilation
                        )
                    )
                    layer_param["ofmap_depth"] = float_biases.shape[0]
                    layer_param["ofmap_depth"] = float_biases.shape[0]

                else:
                    layer_param["ifmap_width"] = input_shape[3]
                    layer_param["ifmap_height"] = input_shape[2]
                    layer_param["ifmap_depth"] = input_shape[1]
                    layer_param["ofmap_width"] = output_shape[3]
                    layer_param["ofmap_height"] = output_shape[2]
                    layer_param["ofmap_depth"] = output_shape[1]
                layer_param["kernel_size_x"] = attr["kernel_shape"][0]
                layer_param["kernel_size_y"] = attr["kernel_shape"][1]
                layer_param["stride_x"] = attr["strides"][0]
                layer_param["stride_y"] = attr["strides"][1]
                layer_param["dilation_x"] = attr["dilations"][0]
                layer_param["dilation_y"] = attr["dilations"][1]
                layer_param["padding"] = "same"
                layer_param["refname"] = output_tensor_name
                if len(self.allLayersParam) == 0:
                    layer_param["ifmap_source"] = "prev"
                else:
                    layer_param["ifmap_source"] = input_tensor_name

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                    layer_param["ifmap_source_idx"] = ifmap_layer_idx
                    dataInMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layer_param["ifmap_source_idx"] = -1

                (
                    layer_param["biases"],
                    layer_param["weights"],
                    layer_param["scaling_factor"],
                    layer_param["scaling_exponent"],
                    layer_param["weights_zero"],
                    layer_param["ofmap_zero"],
                ) = self.convert_to_int(
                    float_biases, float_weights, weightsMinMax, dataInMinMax, dataOutMinMax
                )

                layer_param["dataout_min"] = dataOutMinMax[0]
                layer_param["dataout_max"] = dataOutMinMax[1]
                curr_fmap_zero = layer_param["ofmap_zero"]
                if layer_param["type"] == "conv":
                    npack = (
                        int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                        if layer_param["ofmap_depth"] < N_MIPE
                        else 1
                    )
                    layerNwordData = (
                        np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * layer_param["ofmap_height"]
                        * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                    )
                    layerNwordData = int(np.ceil(layerNwordData / npack))
                    nWordNeed = int(
                        prevLayerNwordData
                        + np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * np.ceil(layer_param["kernel_size_y"] / 2)
                        * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                        + 1
                    )
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData

                    if layer_param["ifmap_depth"] <= 1:
                        cycle_per_kernel = int(
                            np.ceil(
                                layer_param["kernel_size_x"]
                                * layer_param["kernel_size_y"]
                                / MIPE_PAR
                            )
                        )
                        self.layerCycles += int(
                            (biasRCycle * np.ceil(layer_param["ofmap_depth"] / N_MIPE))
                            + (
                                cycle_per_kernel
                                * layer_param["ofmap_width"]
                                * layer_param["ofmap_height"]
                                * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                            )
                        )
                    else:
                        self.layerCycles += int(
                            (biasRCycle * np.ceil(layer_param["ofmap_depth"] / N_MIPE))
                            + (
                                np.ceil(layer_param["ifmap_depth"] / MIPE_PAR)
                                * layer_param["kernel_size_x"]
                                * layer_param["kernel_size_y"]
                                * layer_param["ofmap_width"]
                                * layer_param["ofmap_height"]
                                * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                            )
                        )
                else:
                    npack = (
                        int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                        if layer_param["ofmap_depth"] < N_MIPE
                        else 1
                    )
                    layerNwordData = (
                        np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * layer_param["ofmap_height"]
                        * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                    )
                    layerNwordData = int(np.ceil(layerNwordData / npack))
                    nWordNeed = int(
                        prevLayerNwordData
                        + np.ceil(layer_param["kernel_size_y"] / 2)
                        * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                        + 1
                    )
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                    cycle_per_kernel = int(
                        np.ceil(
                            layer_param["kernel_size_x"] * layer_param["kernel_size_y"] / MIPE_PAR
                        )
                    )
                    self.layerCycles += int(
                        (biasRCycle * np.ceil(layer_param["ofmap_depth"] / N_MIPE))
                        + (
                            cycle_per_kernel
                            * layer_param["ofmap_width"]
                            * layer_param["ofmap_height"]
                            * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        )
                    )

                prevLayerNwordData = layerNwordData
                self.allLayersParam.append(layer_param)

            elif layer_type_name == "Conv":
                if not self.is_quantized_model():
                    layer_param = {}
                    input_tensor_name = node.input[0]
                    output_tensor_name = node.output[0]
                    weight_tensor_name = node.input[1]
                    bias_tensor_name = node.input[2] if len(node.input) > 2 else None

                    input_shape = self.get_tensor_shape(input_tensor_name, graph)
                    output_shape = self.get_tensor_shape(output_tensor_name, graph)

                    # Extract weights and biases
                    weights = self.get_tensor_data(weight_tensor_name, graph)
                    weights = weights.transpose(2, 3, 1, 0)
                    biases = (
                        self.get_tensor_data(bias_tensor_name, graph)
                        if bias_tensor_name
                        else np.zeros(output_shape[1])
                    )

                    # Extract attributes
                    attr = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
                    layer_param = {"type": "conv" if attr["group"] == 1 else "conv_dw"}
                    layer_param["activation"] = "linear"
                    layer_param["ifmap_width"] = input_shape[3]
                    layer_param["ifmap_height"] = input_shape[2]
                    layer_param["ifmap_depth"] = input_shape[1]
                    layer_param["ofmap_width"] = output_shape[3]
                    layer_param["ofmap_height"] = output_shape[2]
                    layer_param["ofmap_depth"] = output_shape[1]
                    layer_param["kernel_size_x"] = attr["kernel_shape"][1]
                    layer_param["kernel_size_y"] = attr["kernel_shape"][0]
                    layer_param["stride_x"] = attr["strides"][1]
                    layer_param["stride_y"] = attr["strides"][0]
                    layer_param["dilation_x"] = attr["dilations"][1]
                    layer_param["dilation_y"] = attr["dilations"][0]
                    if "pads" in attr:
                        layer_param["padding"] = self.interpret_padding(attr["pads"])
                    else:
                        layer_param["padding"] = "valid"
                    layer_param["refname"] = output_tensor_name
                    if len(self.allLayersParam) == 0:
                        layer_param["ifmap_source"] = "prev"
                    else:
                        layer_param["ifmap_source"] = input_tensor_name

                    if len(self.allLayersParam) > 0:
                        ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                        layer_param["ifmap_source_idx"] = ifmap_layer_idx
                        dataInMinMax = [
                            self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                            self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                        ]
                    else:
                        layer_param["ifmap_source_idx"] = -1
                    layer_param["biases"] = biases
                    layer_param["weights"] = weights
                    layer_param["scaling_factor"] = 0
                    layer_param["scaling_exponent"] = 0
                    layer_param["weights_zero"] = 0
                    layer_param["ofmap_zero"] = 0
                else:
                    logging.info(f"Found layer: {node.output[0]}")
                    layer_param = {}
                    input_tensor_name = node.input[0]
                    output_tensor_name = node.output[0]
                    input_shape = self.get_tensor_shape(input_tensor_name, graph)
                    output_shape = self.get_tensor_shape(output_tensor_name, graph)
                    weight_tensor_name = node.input[1]
                    bias_tensor_name = node.input[2] if len(node.input) > 2 else None
                    weights, weights_scales, weights_zero_point = self.resolve_quantized_tensor(
                        weight_tensor_name, graph
                    )

                    if bias_tensor_name:
                        biases, biases_scales, biases_zero_point = self.resolve_quantized_tensor(
                            bias_tensor_name, graph
                        )
                    else:
                        biases = np.zeros(output_shape[1])
                        biases_scales = 0

                    input_tensor_node = next(
                        (n for n in reversed(sorted_nodes[:i]) if n.op_type == "QuantizeLinear")
                    )

                    # Retrieve the scale and zero point from the QuantizeLinear node
                    input_scale = self.get_tensor_data(input_tensor_node.input[1], graph)
                    input_zero_point = self.get_tensor_data(input_tensor_node.input[2], graph)
                    dataInMinMax = self.scale_zero_to_minmax(input_scale, input_zero_point)
                    if self.allLayersParam == []:
                        self.inputMinMax = dataInMinMax

                    output_tensor_node = next(
                        n for n in sorted_nodes[i + 1 :] if n.op_type == "QuantizeLinear"
                    )

                    # Retrieve the scale and zero point from the QuantizeLinear node
                    output_scale = self.get_tensor_data(output_tensor_node.input[1], graph)
                    output_zero_point = self.get_tensor_data(output_tensor_node.input[2], graph)
                    dataOutMinMax = self.scale_zero_to_minmax(output_scale, output_zero_point)

                    float_weights = self.dequantize(weights, weights_scales, weights_zero_point)
                    float_weights = float_weights.transpose(2, 3, 1, 0)
                    weightsMinMax = [float_weights.min(), float_weights.max()]

                    float_biases = biases * biases_scales

                    # Extract attributes
                    attr = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
                    layer_param = {"type": "conv" if attr["group"] == 1 else "conv_dw"}
                    layer_param["activation"] = "relu" if "Relu" in output_tensor_name else "linear"
                    layer_param["ifmap_width"] = input_shape[3]
                    layer_param["ifmap_height"] = input_shape[2]
                    layer_param["ifmap_depth"] = input_shape[1]
                    layer_param["ofmap_width"] = output_shape[3]
                    layer_param["ofmap_height"] = output_shape[2]
                    layer_param["ofmap_depth"] = output_shape[1]
                    layer_param["kernel_size_x"] = attr["kernel_shape"][1]
                    layer_param["kernel_size_y"] = attr["kernel_shape"][0]
                    layer_param["stride_x"] = attr["strides"][1]
                    layer_param["stride_y"] = attr["strides"][0]
                    layer_param["dilation_x"] = attr["dilations"][1]
                    layer_param["dilation_y"] = attr["dilations"][0]
                    layer_param["padding"] = "same"
                    layer_param["refname"] = output_tensor_name
                    if len(self.allLayersParam) == 0:
                        layer_param["ifmap_source"] = "prev"
                    else:
                        layer_param["ifmap_source"] = input_tensor_name.replace(
                            "_DequantizeLinear_Output", ""
                        )

                    if len(self.allLayersParam) > 0:
                        ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                        layer_param["ifmap_source_idx"] = ifmap_layer_idx
                        dataInMinMax = [
                            self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                            self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                        ]
                    else:
                        layer_param["ifmap_source_idx"] = -1
                    (
                        layer_param["biases"],
                        layer_param["weights"],
                        layer_param["scaling_factor"],
                        layer_param["scaling_exponent"],
                        layer_param["weights_zero"],
                        layer_param["ofmap_zero"],
                    ) = self.convert_to_int(
                        float_biases, float_weights, weightsMinMax, dataInMinMax, dataOutMinMax
                    )

                layer_param["dataout_min"] = dataOutMinMax[0]
                layer_param["dataout_max"] = dataOutMinMax[1]
                curr_fmap_zero = layer_param["ofmap_zero"]
                if layer_param["type"] == "conv":
                    npack = (
                        int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                        if layer_param["ofmap_depth"] < N_MIPE
                        else 1
                    )
                    layerNwordData = (
                        np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * layer_param["ofmap_height"]
                        * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                    )
                    layerNwordData = int(np.ceil(layerNwordData / npack))
                    nWordNeed = int(
                        prevLayerNwordData
                        + np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * np.ceil(layer_param["kernel_size_y"] / 2)
                        * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                        + 1
                    )
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                    if layer_param["ifmap_depth"] <= 1:
                        cycle_per_kernel = int(
                            np.ceil(
                                layer_param["kernel_size_x"]
                                * layer_param["kernel_size_y"]
                                / MIPE_PAR
                            )
                        )
                        self.layerCycles += int(
                            (biasRCycle * np.ceil(layer_param["ofmap_depth"] / N_MIPE))
                            + (
                                cycle_per_kernel
                                * layer_param["ofmap_width"]
                                * layer_param["ofmap_height"]
                                * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                            )
                        )
                    else:
                        self.layerCycles += int(
                            (biasRCycle * np.ceil(layer_param["ofmap_depth"] / N_MIPE))
                            + (
                                np.ceil(layer_param["ifmap_depth"] / MIPE_PAR)
                                * layer_param["kernel_size_x"]
                                * layer_param["kernel_size_y"]
                                * layer_param["ofmap_width"]
                                * layer_param["ofmap_height"]
                                * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                            )
                        )
                else:
                    npack = (
                        int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                        if layer_param["ofmap_depth"] < N_MIPE
                        else 1
                    )
                    layerNwordData = (
                        np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * layer_param["ofmap_height"]
                        * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                    )
                    layerNwordData = int(np.ceil(layerNwordData / npack))
                    nWordNeed = int(
                        prevLayerNwordData
                        + np.ceil(layer_param["kernel_size_y"] / 2)
                        * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                        + 1
                    )
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                    cycle_per_kernel = int(
                        np.ceil(
                            layer_param["kernel_size_x"] * layer_param["kernel_size_y"] / MIPE_PAR
                        )
                    )
                    self.layerCycles += int(
                        (biasRCycle * np.ceil(layer_param["ofmap_depth"] / N_MIPE))
                        + (
                            cycle_per_kernel
                            * layer_param["ofmap_width"]
                            * layer_param["ofmap_height"]
                            * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        )
                    )
                prevLayerNwordData = layerNwordData
                self.allLayersParam.append(layer_param)

            elif layer_type_name == "Relu":
                activation_type = "relu"
                if self.allLayersParam:
                    self.allLayersParam[-1]["activation"] = activation_type
                    self.allLayersParam[-1]["refname"] = node.output[0]
                else:
                    logging.error("No previous layer to apply activation.")
            elif layer_type_name == "QLinearGlobalAveragePool":
                layer_param = {"type": "avg_pool"}
                # Extract attributes
                input_tensor_name = node.input[0]
                output_tensor_name = node.output[0]
                attr = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
                input_shape = self.get_tensor_shape(input_tensor_name, graph)
                output_shape = self.get_tensor_shape(output_tensor_name, graph)
                if input_shape is not None and input_shape[2] == input_shape[3] == 1:
                    self.allLayersParam[-1]["refname"] = output_tensor_name
                    i += 1
                    continue
                if input_shape is None:
                    if "add" in input_tensor_name:
                        add_layer = next(
                            (n for n in reversed(self.allLayersParam) if n["type"] == "add")
                        )
                        if add_layer["ofmap_height"] == add_layer["ofmap_height"] == 1:
                            self.allLayersParam[-1]["refname"] = output_tensor_name
                            i += 1
                            continue
                        layer_param["ifmap_width"] = add_layer["ofmap_width"]
                        layer_param["ifmap_height"] = add_layer["ofmap_height"]
                        layer_param["ifmap_depth"] = add_layer["ofmap_depth"]
                        layer_param["ofmap_width"] = 1
                        layer_param["ofmap_height"] = 1
                        layer_param["ofmap_depth"] = add_layer["ofmap_depth"]
                        layer_param["pool_size_x"] = add_layer["ifmap_width"]
                        layer_param["pool_size_y"] = add_layer["ifmap_height"]
                    else:
                        prev_layer = self.allLayersParam[-1]
                        if prev_layer["ofmap_height"] == prev_layer["ofmap_height"] == 1:
                            self.allLayersParam[-1]["refname"] = output_tensor_name
                            i += 1
                            continue
                        layer_param["ifmap_width"] = prev_layer["ofmap_width"]
                        layer_param["ifmap_height"] = prev_layer["ofmap_height"]
                        layer_param["ifmap_depth"] = prev_layer["ofmap_depth"]
                        layer_param["ofmap_width"] = 1
                        layer_param["ofmap_height"] = 1
                        layer_param["ofmap_depth"] = prev_layer["ofmap_depth"]
                        layer_param["pool_size_x"] = prev_layer["ifmap_width"]
                        layer_param["pool_size_y"] = prev_layer["ifmap_height"]
                else:
                    layer_param["ifmap_width"] = input_shape[3]
                    layer_param["ifmap_height"] = input_shape[2]
                    layer_param["ifmap_depth"] = input_shape[1]
                    layer_param["ofmap_width"] = 1
                    layer_param["ofmap_height"] = 1
                    layer_param["ofmap_depth"] = input_shape[1]
                    layer_param["pool_size_x"] = input_shape[3]
                    layer_param["pool_size_y"] = input_shape[2]
                layer_param["stride_x"] = 1
                layer_param["stride_y"] = 1
                layer_param["padding"] = "valid"
                layer_param["activation"] = "linear"
                layer_param["refname"] = output_tensor_name
                if len(self.allLayersParam) == 0:
                    layer_param["ifmap_source"] = "prev"
                else:
                    layer_param["ifmap_source"] = input_tensor_name

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                    layer_param["ifmap_source_idx"] = ifmap_layer_idx
                    dataOutMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layer_param["ifmap_source_idx"] = -1
                layer_param["scaling_factor"] = int(
                    (2**self.scalingNumbits)
                    / (layer_param["pool_size_x"] * layer_param["pool_size_y"])
                )
                layer_param["scaling_exponent"] = 0
                layer_param["dataout_min"] = dataOutMinMax[0]
                layer_param["dataout_max"] = dataOutMinMax[1]

                npack = (
                    int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                    if layer_param["ofmap_depth"] < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                    * layer_param["ofmap_height"]
                    * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))

                nWordNeed = int(
                    prevLayerNwordData
                    + np.ceil(layer_param["pool_size_y"] / 2)
                    * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                    + 1
                )
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                prevLayerNwordData = layerNwordData

                cycle_per_kernel = int(
                    np.ceil(layer_param["pool_size_y"] * layer_param["pool_size_y"] / MIPE_PAR)
                )
                self.layerCycles += int(
                    cycle_per_kernel
                    * layer_param["ofmap_width"]
                    * layer_param["ofmap_height"]
                    * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                )

                self.allLayersParam.append(layer_param)

            elif layer_type_name == "QLinearAveragePool":
                layer_param = {"type": "avg_pool"}
                # Extract attributes
                input_tensor_name = node.input[0]
                output_tensor_name = node.output[0]
                attr = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
                input_shape = self.get_tensor_shape(input_tensor_name, graph)
                output_shape = self.get_tensor_shape(output_tensor_name, graph)
                if input_shape is None:
                    if "add" in input_tensor_name:
                        add_layer = next(
                            (n for n in reversed(self.allLayersParam) if n["type"] == "add")
                        )
                        layer_param["ifmap_width"] = add_layer["ofmap_width"]
                        layer_param["ifmap_height"] = add_layer["ofmap_height"]
                        layer_param["ifmap_depth"] = add_layer["ofmap_depth"]
                        layer_param["ofmap_depth"] = add_layer["ofmap_depth"]
                        input_shape = [
                            layer_param["ifmap_depth"],
                            layer_param["ifmap_height"],
                            layer_param["ifmap_width"],
                        ]
                        kernel_size = attr["kernel_shape"]
                        pads = attr["pads"] if "pads" in attr else [0, 0, 0, 0]
                        stride = attr["strides"]
                        layer_param["ofmap_height"], layer_param["ofmap_width"] = (
                            self.compute_pooling_output_shape(
                                input_shape, kernel_size, stride, pads
                            )
                        )
                    else:
                        prev_layer = self.allLayersParam[-1]
                        layer_param["ifmap_width"] = prev_layer["ofmap_width"]
                        layer_param["ifmap_height"] = prev_layer["ofmap_height"]
                        layer_param["ifmap_depth"] = prev_layer["ofmap_depth"]
                        layer_param["ofmap_depth"] = prev_layer["ofmap_depth"]
                        input_shape = [
                            layer_param["ifmap_depth"],
                            layer_param["ifmap_height"],
                            layer_param["ifmap_width"],
                        ]
                        kernel_size = attr["kernel_shape"]
                        pads = attr["pads"] if "pads" in attr else [0, 0, 0, 0]
                        stride = attr["strides"]
                        layer_param["ofmap_height"], layer_param["ofmap_width"] = (
                            self.compute_pooling_output_shape(
                                input_shape, kernel_size, stride, pads
                            )
                        )
                else:
                    layer_param["ifmap_width"] = input_shape[3]
                    layer_param["ifmap_height"] = input_shape[2]
                    layer_param["ifmap_depth"] = input_shape[1]
                    layer_param["ofmap_depth"] = layer_param["ifmap_depth"]
                    if output_shape is None:
                        input_shape = [
                            layer_param["ifmap_depth"],
                            layer_param["ifmap_height"],
                            layer_param["ifmap_width"],
                        ]
                        kernel_size = attr["kernel_shape"]
                        pads = attr["pads"] if "pads" in attr else [0, 0, 0, 0]
                        stride = attr["strides"]
                        layer_param["ofmap_height"], layer_param["ofmap_width"] = (
                            self.compute_pooling_output_shape(
                                input_shape, kernel_size, stride, pads
                            )
                        )
                    else:
                        layer_param["ofmap_width"] = output_shape[3]
                        layer_param["ofmap_height"] = output_shape[2]
                        layer_param["ofmap_depth"] = output_shape[1]

                layer_param["pool_size_x"] = attr["kernel_shape"][1]
                layer_param["pool_size_y"] = attr["kernel_shape"][0]
                layer_param["stride_x"] = attr["strides"][1]
                layer_param["stride_y"] = attr["strides"][0]
                if "pads" in attr:
                    layer_param["padding"] = self.interpret_padding(attr["pads"])
                else:
                    layer_param["padding"] = "valid"
                layer_param["activation"] = "linear"
                layer_param["refname"] = output_tensor_name
                if len(self.allLayersParam) == 0:
                    layer_param["ifmap_source"] = "prev"
                else:
                    layer_param["ifmap_source"] = input_tensor_name

                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                    layer_param["ifmap_source_idx"] = ifmap_layer_idx
                    dataOutMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layer_param["ifmap_source_idx"] = -1
                layer_param["scaling_factor"] = int(
                    (2**self.scalingNumbits)
                    / (layer_param["pool_size_x"] * layer_param["pool_size_y"])
                )
                layer_param["scaling_exponent"] = 0
                layer_param["dataout_min"] = dataOutMinMax[0]
                layer_param["dataout_max"] = dataOutMinMax[1]
                layer_param["activation"] = "linear"
                npack = (
                    int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                    if layer_param["ofmap_depth"] < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                    * layer_param["ofmap_height"]
                    * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))

                nWordNeed = int(
                    prevLayerNwordData
                    + np.ceil(layer_param["pool_size_y"] / 2)
                    * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                    + 1
                )
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                cycle_per_kernel = int(
                    np.ceil(layer_param["pool_size_y"] * layer_param["pool_size_y"] / MIPE_PAR)
                )
                self.layerCycles += int(
                    cycle_per_kernel
                    * layer_param["ofmap_width"]
                    * layer_param["ofmap_height"]
                    * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                )
                prevLayerNwordData = layerNwordData
                self.allLayersParam.append(layer_param)

            elif layer_type_name in ["MaxPool", "AveragePool", "GlobalAveragePool"]:
                # Extract attributes
                input_tensor_name = node.input[0]
                output_tensor_name = node.output[0]
                attr = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
                input_shape = self.get_tensor_shape(input_tensor_name, graph)
                output_shape = self.get_tensor_shape(output_tensor_name, graph)
                if layer_type_name == "GlobalAveragePool" and input_shape[2] == input_shape[3] == 1:
                    self.allLayersParam[-1]["refname"] = output_tensor_name
                    i += 1
                    continue
                else:
                    if layer_type_name == "MaxPool":
                        layer_param = {"type": "max_pool"}
                    else:
                        layer_param = {"type": "avg_pool"}
                    layer_param["refname"] = output_tensor_name
                    if layer_type_name == "GlobalAveragePool":
                        layer_param["ifmap_width"] = input_shape[3]
                        layer_param["ifmap_height"] = input_shape[2]
                        layer_param["ifmap_depth"] = input_shape[1]
                        layer_param["ofmap_width"] = 1
                        layer_param["ofmap_height"] = 1
                        layer_param["ofmap_depth"] = input_shape[1]
                        layer_param["pool_size_x"] = input_shape[3]
                        layer_param["pool_size_y"] = input_shape[2]
                        layer_param["stride_x"] = 1
                        layer_param["stride_y"] = 1
                        layer_param["padding"] = "valid"
                    else:
                        if input_shape is None:
                            layer_param["ifmap_source"] = input_tensor_name.replace(
                                "_DequantizeLinear_Output", ""
                            )
                            ifmap_layer_idx = self.get_layer_idx_by_name(
                                layer_param["ifmap_source"]
                            )
                            prev_layer = self.allLayersParam[ifmap_layer_idx]
                            layer_param["ifmap_width"] = prev_layer["ofmap_width"]
                            layer_param["ifmap_height"] = prev_layer["ofmap_height"]
                            layer_param["ifmap_depth"] = prev_layer["ofmap_depth"]
                            layer_param["ofmap_depth"] = prev_layer["ofmap_depth"]
                            input_shape = [
                                layer_param["ifmap_depth"],
                                layer_param["ifmap_height"],
                                layer_param["ifmap_width"],
                            ]
                            kernel_size = attr["kernel_shape"]
                            pads = attr["pads"] if "pads" in attr else [0, 0, 0, 0]
                            stride = attr["strides"]
                            layer_param["ofmap_height"], layer_param["ofmap_width"] = (
                                self.compute_pooling_output_shape(
                                    input_shape, kernel_size, stride, pads
                                )
                            )
                        else:
                            layer_param["ifmap_width"] = input_shape[3]
                            layer_param["ifmap_height"] = input_shape[2]
                            layer_param["ifmap_depth"] = input_shape[1]
                            layer_param["ofmap_width"] = output_shape[3]
                            layer_param["ofmap_height"] = output_shape[2]
                            layer_param["ofmap_depth"] = output_shape[1]
                        layer_param["pool_size_x"] = attr["kernel_shape"][1]
                        layer_param["pool_size_y"] = attr["kernel_shape"][0]
                        layer_param["stride_x"] = attr["strides"][1]
                        layer_param["stride_y"] = attr["strides"][0]
                        if "pads" in attr:
                            layer_param["padding"] = self.interpret_padding(attr["pads"])
                        else:
                            layer_param["padding"] = "valid"

                    layer_param["activation"] = "linear"
                    if len(self.allLayersParam) == 0:
                        layer_param["ifmap_source"] = "prev"
                    else:
                        layer_param["ifmap_source"] = input_tensor_name.replace(
                            "_DequantizeLinear_Output", ""
                        )

                    if len(self.allLayersParam) > 0:
                        ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                        layer_param["ifmap_source_idx"] = ifmap_layer_idx
                        dataOutMinMax = [
                            self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                            self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                        ]
                    else:
                        layer_param["ifmap_source_idx"] = -1

                layer_param["scaling_factor"] = int(
                    (2**self.scalingNumbits)
                    / (layer_param["pool_size_x"] * layer_param["pool_size_y"])
                )
                layer_param["scaling_exponent"] = 0

                layer_param["dataout_min"] = dataOutMinMax[0]
                layer_param["dataout_max"] = dataOutMinMax[1]
                npack = (
                    int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                    if layer_param["ofmap_depth"] < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                    * layer_param["ofmap_height"]
                    * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))

                nWordNeed = int(
                    prevLayerNwordData
                    + np.ceil(layer_param["pool_size_y"] / 2)
                    * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                    + 1
                )
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                cycle_per_kernel = int(
                    np.ceil(layer_param["pool_size_y"] * layer_param["pool_size_y"] / MIPE_PAR)
                )
                self.layerCycles += int(
                    cycle_per_kernel
                    * layer_param["ofmap_width"]
                    * layer_param["ofmap_height"]
                    * np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                )
                self.allLayersParam.append(layer_param)
                prevLayerNwordData = layerNwordData
            elif layer_type_name == "Softmax":
                activation_type = "softmax"
                if self.allLayersParam:
                    self.allLayersParam[-1]["activation"] = activation_type
                    self.allLayersParam[-1]["refname"] = node.output[0]
                    if self.is_quantized_model():
                        output_tensor_node = next(
                            n for n in sorted_nodes[i + 1 :] if n.op_type == "QuantizeLinear"
                        )
                        output_scale = self.get_tensor_data(output_tensor_node.input[1], graph)
                        output_zero_point = self.get_tensor_data(output_tensor_node.input[2], graph)
                        dataOutMinMax = self.scale_zero_to_minmax(output_scale, output_zero_point)
                else:
                    logging.error("No previous layer to apply activation.")
            elif layer_type_name == "Sigmoid":
                activation_type = "sigmoid"
                if self.allLayersParam:
                    self.allLayersParam[-1]["activation"] = activation_type
                    self.allLayersParam[-1]["refname"] = node.output[0]
                    if self.is_quantized_model():
                        output_tensor_node = next(
                            n for n in sorted_nodes[i + 1 :] if n.op_type == "QuantizeLinear"
                        )
                        output_scale = self.get_tensor_data(output_tensor_node.input[1], graph)
                        output_zero_point = self.get_tensor_data(output_tensor_node.input[2], graph)
                        dataOutMinMax = self.scale_zero_to_minmax(output_scale, output_zero_point)
                else:
                    logging.error("No previous layer to apply activation.")
            elif layer_type_name == "QLinearSigmoid":
                activation_type = "sigmoid"
                if self.allLayersParam:
                    self.allLayersParam[-1]["activation"] = activation_type
                    self.allLayersParam[-1]["refname"] = node.output[0]
                    output_scale = self.get_tensor_data(node.input[-2], graph)
                    output_zero_point = self.get_tensor_data(node.input[-1], graph)
                    dataOutMinMax = self.scale_zero_to_minmax(output_scale, output_zero_point)

                else:
                    logging.error("No previous layer to apply activation.")
            elif layer_type_name == "QLinearSoftmax":
                activation_type = "softmax"
                if self.allLayersParam:
                    self.allLayersParam[-1]["activation"] = activation_type
                    self.allLayersParam[-1]["refname"] = node.output[0]
                    output_scale = self.get_tensor_data(node.input[-2], graph)
                    output_zero_point = self.get_tensor_data(node.input[-1], graph)
                    dataOutMinMax = self.scale_zero_to_minmax(output_scale, output_zero_point)

                else:
                    logging.error("No previous layer to apply activation.")
            elif layer_type_name == "MatMul":
                if (
                    i + 1 < len(sorted_nodes)
                    and self.get_layer_type_name(sorted_nodes[i + 1]) == "Add"
                ):
                    flattenedOutput = 1
                    matmul_node = sorted_nodes[i]
                    add_node = sorted_nodes[i + 1]
                    layer_param = {"type": "dense"}
                    layer_param["activation"] = "linear"
                    weight_tensor_name = matmul_node.input[1]
                    bias_tensor_name = add_node.input[1]
                    input_tensor_name = matmul_node.input[0]
                    output_tensor_name = add_node.output[0]
                    input_shape = self.get_tensor_shape(input_tensor_name, graph)
                    output_shape = self.get_tensor_shape(output_tensor_name, graph)
                    # Extract weights and biases
                    weights = self.get_tensor_data(weight_tensor_name, graph)
                    biases = self.get_tensor_data(bias_tensor_name, graph)
                    layer_param["ofmap_width"] = 1
                    layer_param["ofmap_height"] = 1
                    layer_param["ofmap_depth"] = output_shape[1]
                    layer_param["ifmap_width"] = 1
                    layer_param["ifmap_height"] = 1
                    layer_param["ifmap_depth"] = input_shape[1]
                    layer_param["refname"] = output_tensor_name
                    if len(self.allLayersParam) == 0:
                        layer_param["ifmap_source"] = "prev"
                    else:
                        layer_param["ifmap_source"] = input_tensor_name
                    if len(self.allLayersParam) > 0:
                        ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                        layer_param["ifmap_source_idx"] = ifmap_layer_idx
                        dataInMinMax = [
                            self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                            self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                        ]
                    else:
                        layer_param["ifmap_source_idx"] = -1
                    layer_param["biases"] = biases
                    layer_param["weights"] = weights
                    layer_param["activation"] = "linear"
                    layer_param["scaling_factor"] = 0
                    layer_param["scaling_exponent"] = 0
                    layer_param["weights_zero"] = 0
                    layer_param["ofmap_zero"] = 0
                    layer_param["dataout_min"] = dataOutMinMax[0]
                    layer_param["dataout_max"] = dataOutMinMax[1]
                    curr_fmap_zero = layer_param["ofmap_zero"]
                    layerNwordData = int(np.ceil(layer_param["ofmap_depth"] / (N_MIPE * MIPE_PAR)))
                    nWordNeed = prevLayerNwordData + layerNwordData
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                    self.layerCycles += int(
                        np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * (
                            biasRCycle
                            + layer_param["ifmap_width"]
                            * layer_param["ifmap_height"]
                            * np.ceil(layer_param["ifmap_depth"] / MIPE_PAR)
                        )
                    )
                    prevLayerNwordData = layerNwordData
                    self.allLayersParam.append(layer_param)
                    i += 1  # Skip the Add node as it's handled here

            elif layer_type_name == "Gemm":
                if self.is_quantized_model():
                    flattenedOutput = 1

                    input_tensor_name = node.input[0]
                    output_tensor_name = node.output[0]
                    weight_tensor_name = node.input[1]
                    bias_tensor_name = node.input[2] if len(node.input) > 2 else None
                    weights, weights_scales, weights_zero_point = self.resolve_quantized_tensor(
                        weight_tensor_name, graph
                    )

                    if bias_tensor_name:
                        biases, biases_scales, biases_zero_point = self.resolve_quantized_tensor(
                            bias_tensor_name, graph
                        )

                    input_shape = self.get_tensor_shape(input_tensor_name, graph)
                    output_shape = self.get_tensor_shape(output_tensor_name, graph)

                    input_tensor_node = next(
                        (n for n in reversed(sorted_nodes[:i]) if n.op_type == "QuantizeLinear")
                    )

                    # Retrieve the scale and zero point from the QuantizeLinear node
                    input_scale = self.get_tensor_data(input_tensor_node.input[1], graph)
                    input_zero_point = self.get_tensor_data(input_tensor_node.input[2], graph)
                    if len(self.allLayersParam) and self.allLayersParam[-1]["type"] == "avg_pool":
                        dataInMinMax = [
                            self.allLayersParam[-1]["dataout_min"],
                            self.allLayersParam[-1]["dataout_max"],
                        ]
                    else:
                        dataInMinMax = self.scale_zero_to_minmax(input_scale, input_zero_point)
                    output_tensor_node = next(
                        n for n in sorted_nodes[i + 1 :] if n.op_type == "QuantizeLinear"
                    )

                    # Retrieve the scale and zero point from the QuantizeLinear node
                    output_scale = self.get_tensor_data(output_tensor_node.input[1], graph)
                    output_zero_point = self.get_tensor_data(output_tensor_node.input[2], graph)
                    dataOutMinMax = self.scale_zero_to_minmax(output_scale, output_zero_point)

                    # Extract weights and biases
                    if "Flatten" not in input_tensor_name:
                        weights = weights.T
                    float_weights = self.dequantize(weights, weights_scales, weights_zero_point)
                    float_weights = float_weights.T
                    float_biases = biases * biases_scales
                    abs_max_weights = np.max(np.abs(float_weights))
                    per_tensor_weights_scale = abs_max_weights / 127.0
                    per_tensor_bias_scale = per_tensor_weights_scale * input_scale
                    new_weights = float_weights / per_tensor_weights_scale
                    new_weights = np.round(new_weights).astype(np.int8)
                    new_biases = float_biases / per_tensor_bias_scale
                    new_biases = np.round(new_biases).astype(np.int32)
                    new_float_weights = new_weights * per_tensor_weights_scale
                    weightsMinMax = [new_float_weights.min(), new_float_weights.max()]
                    new_float_biases = new_biases * per_tensor_bias_scale

                    layer_param = {"type": "dense"}
                    layer_param["activation"] = "linear"
                    layer_param["ofmap_width"] = 1
                    layer_param["ofmap_height"] = 1
                    layer_param["ofmap_depth"] = weights.shape[0]
                    layer_param["ifmap_width"] = 1
                    layer_param["ifmap_height"] = 1
                    layer_param["ifmap_depth"] = weights.shape[1]
                    layer_param["refname"] = output_tensor_name

                    if len(self.allLayersParam) == 0:
                        layer_param["ifmap_source"] = "prev"
                    else:
                        layer_param["ifmap_source"] = input_tensor_name.replace(
                            "_DequantizeLinear_Output", ""
                        )

                    if len(self.allLayersParam) > 0:
                        ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                        layer_param["ifmap_source_idx"] = ifmap_layer_idx
                        dataInMinMax = [
                            self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                            self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                        ]
                    else:
                        layer_param["ifmap_source_idx"] = -1

                    (
                        layer_param["biases"],
                        layer_param["weights"],
                        layer_param["scaling_factor"],
                        layer_param["scaling_exponent"],
                        layer_param["weights_zero"],
                        layer_param["ofmap_zero"],
                    ) = self.convert_to_int(
                        new_float_biases,
                        new_float_weights,
                        weightsMinMax,
                        dataInMinMax,
                        dataOutMinMax,
                    )

                    layer_param["dataout_min"] = dataOutMinMax[0]
                    layer_param["dataout_max"] = dataOutMinMax[1]
                    layerNwordData = int(np.ceil(layer_param["ofmap_depth"] / (N_MIPE * MIPE_PAR)))
                    nWordNeed = prevLayerNwordData + layerNwordData
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                    self.layerCycles += int(
                        np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * (
                            biasRCycle
                            + layer_param["ifmap_width"]
                            * layer_param["ifmap_height"]
                            * np.ceil(layer_param["ifmap_depth"] / MIPE_PAR)
                        )
                    )
                    prevLayerNwordData = layerNwordData
                    self.allLayersParam.append(layer_param)

                else:
                    flattenedOutput = 1
                    input_tensor_name = node.input[0]
                    output_tensor_name = node.output[0]
                    weight_tensor_name = node.input[1]
                    bias_tensor_name = node.input[2] if len(node.input) > 2 else None
                    input_shape = self.get_tensor_shape(input_tensor_name, graph)
                    output_shape = self.get_tensor_shape(output_tensor_name, graph)

                    weights = self.get_tensor_data(weight_tensor_name, graph)
                    weights = weights.T
                    biases = self.get_tensor_data(bias_tensor_name, graph)
                    layer_param = {"type": "dense"}
                    layer_param["activation"] = "linear"
                    layer_param["ofmap_width"] = 1
                    layer_param["ofmap_height"] = 1
                    layer_param["ofmap_depth"] = weights.shape[1]
                    layer_param["ifmap_width"] = 1
                    layer_param["ifmap_height"] = 1
                    layer_param["ifmap_depth"] = weights.shape[0]
                    layer_param["refname"] = output_tensor_name
                    if len(self.allLayersParam) == 0:
                        layer_param["ifmap_source"] = "prev"
                    else:
                        layer_param["ifmap_source"] = input_tensor_name
                    if len(self.allLayersParam) > 0:
                        ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                        layer_param["ifmap_source_idx"] = ifmap_layer_idx
                        dataInMinMax = [
                            self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                            self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                        ]
                    else:
                        layer_param["ifmap_source_idx"] = -1
                    layer_param["biases"] = biases
                    layer_param["weights"] = weights
                    layer_param["activation"] = "linear"
                    layer_param["scaling_factor"] = 0
                    layer_param["scaling_exponent"] = 0
                    layer_param["weights_zero"] = 0
                    layer_param["ofmap_zero"] = 0
                    layer_param["dataout_min"] = dataOutMinMax[0]
                    layer_param["dataout_max"] = dataOutMinMax[1]
                    curr_fmap_zero = layer_param["ofmap_zero"]
                    layerNwordData = int(np.ceil(layer_param["ofmap_depth"] / (N_MIPE * MIPE_PAR)))
                    nWordNeed = prevLayerNwordData + layerNwordData
                    maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                    self.layerCycles += int(
                        np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                        * (
                            biasRCycle
                            + layer_param["ifmap_width"]
                            * layer_param["ifmap_height"]
                            * np.ceil(layer_param["ifmap_depth"] / MIPE_PAR)
                        )
                    )
                    prevLayerNwordData = layerNwordData
                    self.allLayersParam.append(layer_param)

            elif layer_type_name == "QGemm":
                flattenedOutput = 1
                output_tensor_name = node.output[0]
                input_tensor_name = node.input[0]
                weight_tensor_name = node.input[3]
                bias_tensor_name = node.input[-3]
                scale_input = self.get_tensor_data(node.input[1], graph)
                zero_point_input = self.get_tensor_data(node.input[2], graph)
                scale_output = self.get_tensor_data(node.input[-2], graph)
                zero_point_output = self.get_tensor_data(node.input[-1], graph)
                dataOutMinMax = self.scale_zero_to_minmax(scale_output, zero_point_output)

                # Extract weights and biases
                weights = self.get_tensor_data(weight_tensor_name, graph)
                if "Flatten" not in input_tensor_name:
                    weights = weights.T
                weights_scale = self.get_tensor_data(node.input[4], graph)
                weights_zero_point = self.get_tensor_data(node.input[5], graph)
                float_weights = self.dequantize(weights, weights_scale, weights_zero_point)
                float_weights = float_weights.T
                weightsMinMax = [float_weights.min(), float_weights.max()]

                biases = self.get_tensor_data(bias_tensor_name, graph)
                biases_scale = scale_input * weights_scale
                biases_zero_point = 0
                float_biases = biases * biases_scale

                abs_max_weights = np.max(np.abs(float_weights))
                per_tensor_weights_scale = abs_max_weights / 127.0
                per_tensor_bias_scale = per_tensor_weights_scale * scale_input
                new_weights = float_weights / per_tensor_weights_scale
                new_weights = np.round(new_weights).astype(np.int8)
                new_biases = float_biases / per_tensor_bias_scale
                new_biases = np.round(new_biases).astype(np.int32)
                new_float_weights = new_weights * per_tensor_weights_scale
                weightsMinMax = [new_float_weights.min(), new_float_weights.max()]
                new_float_biases = new_biases * per_tensor_bias_scale

                layer_param = {"type": "dense"}
                layer_param["activation"] = "linear"
                layer_param["ofmap_width"] = 1
                layer_param["ofmap_height"] = 1
                layer_param["ofmap_depth"] = weights.shape[0]
                layer_param["ifmap_width"] = 1
                layer_param["ifmap_height"] = 1
                layer_param["ifmap_depth"] = weights.shape[1]
                layer_param["refname"] = output_tensor_name
                if len(self.allLayersParam) == 0:
                    layer_param["ifmap_source"] = "prev"
                else:
                    layer_param["ifmap_source"] = input_tensor_name
                if len(self.allLayersParam) > 0:
                    ifmap_layer_idx = self.get_layer_idx_by_name(layer_param["ifmap_source"])
                    layer_param["ifmap_source_idx"] = ifmap_layer_idx
                    dataInMinMax = [
                        self.allLayersParam[ifmap_layer_idx]["dataout_min"],
                        self.allLayersParam[ifmap_layer_idx]["dataout_max"],
                    ]
                else:
                    layer_param["ifmap_source_idx"] = -1
                (
                    layer_param["biases"],
                    layer_param["weights"],
                    layer_param["scaling_factor"],
                    layer_param["scaling_exponent"],
                    layer_param["weights_zero"],
                    layer_param["ofmap_zero"],
                ) = self.convert_to_int(
                    new_float_biases, new_float_weights, weightsMinMax, dataInMinMax, dataOutMinMax
                )

                layer_param["dataout_min"] = dataOutMinMax[0]
                layer_param["dataout_max"] = dataOutMinMax[1]
                curr_fmap_zero = layer_param["ofmap_zero"]
                layerNwordData = int(np.ceil(layer_param["ofmap_depth"] / (N_MIPE * MIPE_PAR)))
                nWordNeed = prevLayerNwordData + layerNwordData
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                self.layerCycles += int(
                    np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                    * (
                        biasRCycle
                        + layer_param["ifmap_width"]
                        * layer_param["ifmap_height"]
                        * np.ceil(layer_param["ifmap_depth"] / MIPE_PAR)
                    )
                )
                prevLayerNwordData = layerNwordData
                self.allLayersParam.append(layer_param)
            elif layer_type_name == "Add":
                layer_param = {"type": "add"}
                input1_tensor_name = node.input[0]
                input2_tensor_name = node.input[1]
                output_tensor_name = node.output[0]

                input_shape = self.get_tensor_shape(input1_tensor_name, graph)
                output_shape = self.get_tensor_shape(output_tensor_name, graph)
                # Extract attributes
                layer_param["activation"] = "linear"
                layer_param["ifmap_width"] = input_shape[3]
                layer_param["ifmap_height"] = input_shape[2]
                layer_param["ifmap_depth"] = input_shape[1]
                layer_param["ofmap_width"] = output_shape[3]
                layer_param["ofmap_height"] = output_shape[2]
                layer_param["ofmap_depth"] = output_shape[1]
                layer_param["refname"] = output_tensor_name

                layer_param["ifmap_source"] = "prev"
                layer_param["ifmap_source_idx"] = -1

                if not self.is_quantized_model():
                    if self.allLayersParam[-1]["refname"] != input1_tensor_name:
                        layer_param["in_refname"] = input1_tensor_name
                    else:
                        layer_param["in_refname"] = input2_tensor_name

                    layer_param["bias"] = 0
                    layer_param["weight1"] = 0
                    layer_param["weight2"] = 0
                    layer_param["scaling_factor"] = 0
                    layer_param["scaling_exponent"] = 0
                    layer_param["ofmap_zero"] = 0
                    layer_param["dataout_min"] = dataOutMinMax[0]
                    layer_param["dataout_max"] = dataOutMinMax[1]

                else:
                    output_tensor_node = next(
                        n for n in sorted_nodes[i + 1 :] if n.op_type == "QuantizeLinear"
                    )
                    output_scale = self.get_tensor_data(output_tensor_node.input[1], graph)
                    output_zero_point = self.get_tensor_data(output_tensor_node.input[2], graph)
                    dataOutMinMax = self.scale_zero_to_minmax(output_scale, output_zero_point)
                    layer_param["dataout_min"] = dataOutMinMax[0]
                    layer_param["dataout_max"] = dataOutMinMax[1]
                    input1_tensor_name = input1_tensor_name.replace("_DequantizeLinear_Output", "")
                    input2_tensor_name = input2_tensor_name.replace("_DequantizeLinear_Output", "")
                    if self.allLayersParam[-1]["refname"] != input1_tensor_name:
                        layer_param["in_refname"] = input1_tensor_name
                    else:
                        layer_param["in_refname"] = input2_tensor_name
                    in_layer1_minmax = [
                        self.allLayersParam[-1]["dataout_min"],
                        self.allLayersParam[-1]["dataout_max"],
                    ]
                    in_layer2_minmax = [None, None]
                    for ll in self.allLayersParam:
                        if ll["refname"] == layer_param["in_refname"]:
                            in_layer2_minmax = [ll["dataout_min"], ll["dataout_max"]]
                            break
                    if in_layer2_minmax == [None, None]:
                        logging.error("Unable to retrive skip layer parameters!")
                        exit(1)

                    (
                        layer_param["bias"],
                        layer_param["weight1"],  # Weight to input 1 (previous layer)
                        layer_param["weight2"],  # Weight to input 2 (skipped layer)
                        layer_param["scaling_factor"],
                        layer_param["scaling_exponent"],
                        layer_param["ofmap_zero"],
                    ) = self.compute_add_params(in_layer1_minmax, in_layer2_minmax, dataOutMinMax)

                curr_fmap_zero = layer_param["ofmap_zero"]
                npack = (
                    int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                    if layer_param["ofmap_depth"] < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                    * layer_param["ofmap_height"]
                    * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))
                nWordNeed = int(prevLayerNwordData * 2 + layerNwordData)
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                outH, outW, outC = (
                    layer_param["ofmap_height"],
                    layer_param["ofmap_width"],
                    layer_param["ofmap_depth"],
                )
                nDepthOutGrp = int(np.ceil(outC / N_MIPE))
                self.layerCycles += int(outH * outW * nDepthOutGrp)

                prevLayerNwordData = layerNwordData
                self.allLayersParam.append(layer_param)
            elif layer_type_name == "QLinearAdd":
                layer_param = {"type": "add"}
                input1_tensor_name = node.input[0]
                input2_tensor_name = node.input[3]
                output_tensor_name = node.output[0]
                input_shape = self.get_tensor_shape(input1_tensor_name, graph)
                output_shape = input_shape
                # Extract attributes
                layer_param["activation"] = "linear"
                if input_shape is None:
                    if "add" in input1_tensor_name:
                        add_layer = next(
                            (n for n in reversed(self.allLayersParam) if n["type"] == "add")
                        )
                        add_layer = self.allLayersParam[-1]
                        layer_param["ifmap_width"] = add_layer["ofmap_width"]
                        layer_param["ifmap_height"] = add_layer["ofmap_height"]
                        layer_param["ifmap_depth"] = add_layer["ofmap_depth"]
                        layer_param["ofmap_width"] = add_layer["ofmap_width"]
                        layer_param["ofmap_height"] = add_layer["ofmap_height"]
                        layer_param["ofmap_depth"] = add_layer["ofmap_depth"]
                    else:
                        prev_layer = self.allLayersParam[-1]
                        layer_param["ifmap_width"] = prev_layer["ofmap_width"]
                        layer_param["ifmap_height"] = prev_layer["ofmap_height"]
                        layer_param["ifmap_depth"] = prev_layer["ofmap_depth"]
                        layer_param["ofmap_width"] = prev_layer["ofmap_width"]
                        layer_param["ofmap_height"] = prev_layer["ofmap_height"]
                        layer_param["ofmap_depth"] = prev_layer["ofmap_depth"]
                else:
                    layer_param["ifmap_width"] = input_shape[3]
                    layer_param["ifmap_height"] = input_shape[2]
                    layer_param["ifmap_depth"] = input_shape[1]
                    layer_param["ofmap_width"] = output_shape[3]
                    layer_param["ofmap_height"] = output_shape[2]
                    layer_param["ofmap_depth"] = output_shape[1]
                layer_param["refname"] = output_tensor_name
                layer_param["ifmap_source"] = "prev"
                layer_param["ifmap_source_idx"] = -1

                scale_output = self.get_tensor_data(node.input[-2], graph)
                zero_point_output = self.get_tensor_data(node.input[-1], graph)
                dataOutMinMax = self.scale_zero_to_minmax(scale_output, zero_point_output)
                layer_param["dataout_min"] = dataOutMinMax[0]
                layer_param["dataout_max"] = dataOutMinMax[1]
                input1_tensor_name = input1_tensor_name
                input2_tensor_name = input2_tensor_name
                if self.allLayersParam[-1]["refname"] != input1_tensor_name:
                    layer_param["in_refname"] = input1_tensor_name
                else:
                    layer_param["in_refname"] = input2_tensor_name
                in_layer1_minmax = [
                    self.allLayersParam[-1]["dataout_min"],
                    self.allLayersParam[-1]["dataout_max"],
                ]
                in_layer2_minmax = [None, None]
                for ll in self.allLayersParam:
                    if ll["refname"] == layer_param["in_refname"]:
                        in_layer2_minmax = [ll["dataout_min"], ll["dataout_max"]]
                        break
                if in_layer2_minmax == [None, None]:
                    logging.error("Unable to retrive skip layer parameters!")
                    exit(1)

                (
                    layer_param["bias"],
                    layer_param["weight1"],  # Weight to input 1 (previous layer)
                    layer_param["weight2"],  # Weight to input 2 (skipped layer)
                    layer_param["scaling_factor"],
                    layer_param["scaling_exponent"],
                    layer_param["ofmap_zero"],
                ) = self.compute_add_params(in_layer1_minmax, in_layer2_minmax, dataOutMinMax)

                curr_fmap_zero = layer_param["ofmap_zero"]
                npack = (
                    int(np.floor(N_MIPE / layer_param["ofmap_depth"]))
                    if layer_param["ofmap_depth"] < N_MIPE
                    else 1
                )
                layerNwordData = (
                    np.ceil(layer_param["ofmap_depth"] / N_MIPE)
                    * layer_param["ofmap_height"]
                    * np.ceil(layer_param["ofmap_width"] / MIPE_PAR)
                )
                layerNwordData = int(np.ceil(layerNwordData / npack))
                nWordNeed = int(prevLayerNwordData * 2 + layerNwordData)
                maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
                outH, outW, outC = (
                    layer_param["ofmap_height"],
                    layer_param["ofmap_width"],
                    layer_param["ofmap_depth"],
                )
                nDepthOutGrp = int(np.ceil(outC / N_MIPE))
                self.layerCycles += int(outH * outW * nDepthOutGrp)
                prevLayerNwordData = layerNwordData
                self.allLayersParam.append(layer_param)

            elif layer_type_name in ["Reshape", "Squeeze", "Clip", "Flatten"]:
                self.layerCycles += LAYER_EXTRA_CYCLES
                if len(self.allLayersParam) > 0:
                    self.allLayersParam[-1]["refname"] = node.output[0]
                    if layer_type_name == "Flatten" and self.is_quantized_model():
                        if self.get_layer_type_name(sorted_nodes[i + 1]) == "QuantizeLinear":
                            self.allLayersParam[-1]["refname"] = sorted_nodes[i + 1].output[0]
                        if self.get_layer_type_name(sorted_nodes[i + 2]) == "DequantizeLinear":
                            self.allLayersParam[-1]["refname"] = (
                                sorted_nodes[i + 2]
                                .output[0]
                                .replace("_DequantizeLinear_Output", "")
                            )
                    if layer_type_name == "Clip":
                        self.allLayersParam[-1]["activation"] = "relu"

            i += 1
            self.layerCycles += LAYER_EXTRA_CYCLES
        self.allLayersParam[0]["flattenedOutput"] = flattenedOutput
        self.allLayersParam[0]["quantNumbits"] = self.quantNumbits
        self.allLayersParam[0]["biasNumbits"] = self.biasNumbits
        self.allLayersParam[0]["scalingNumbits"] = self.scalingNumbits
        self.allLayersParam[0]["scalingExpMax"] = self.scalingExpMax
        if self.is_quantized_model():
            final_node = sorted_nodes[-1]
            final_node_scale = self.get_tensor_data(final_node.input[-2], graph)
            final_node_zero_point = self.get_tensor_data(final_node.input[-1], graph)
            dataOutMinMax = self.scale_zero_to_minmax(final_node_scale, final_node_zero_point)
            (
                self.allLayersParam[0]["outputScalingFloat"],
                self.allLayersParam[0]["outputZeroFloat"],
            ) = self.minmax_to_scale(
                dataOutMinMax[0], dataOutMinMax[1], int((2**self.quantNumbits) - 1)
            )
            self.allLayersParam[0]["inputMin"] = self.inputMinMax[0]
            self.allLayersParam[0]["inputMax"] = self.inputMinMax[1]
            nnInputDataZero = self.minmax_to_scale(
                self.inputMinMax[0], self.inputMinMax[1], int((2**self.quantNumbits) - 1)
            )[1]
            self.allLayersParam[0]["nnInputDataZero"] = int(np.round(nnInputDataZero))
        else:
            dataOutMinMax = [0, 1]
            (
                self.allLayersParam[0]["outputScalingFloat"],
                self.allLayersParam[0]["outputZeroFloat"],
            ) = self.minmax_to_scale(
                dataOutMinMax[0], dataOutMinMax[1], int((2**self.quantNumbits) - 1)
            )
            self.allLayersParam[0]["inputMin"] = self.inputMinMax[0]
            self.allLayersParam[0]["inputMax"] = self.inputMinMax[1]
            self.allLayersParam[0]["nnInputDataZero"] = 0

        nnMembuffData = int(np.ceil(maxNwordData / NWORD_BUFFER))
        self.layerCycles += NN_EXTRA_CYCLES
        return self.allLayersParam


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    model_path = "../NN_BLAZE_FASHION/output/trained_model_qop.onnx"
    NBIT_DATA = 8
    NBIT_BIAS = 24
    NBIT_SCALING = 16
    SCALING_EXP_MAX = 3
    onnxmodel_extractor = ONNXModelExtractor(
        model_path,
        quantNumbits=NBIT_DATA,
        biasNumbits=NBIT_BIAS,
        scalingNumbits=NBIT_SCALING,
        scalingExpMax=SCALING_EXP_MAX,
    )
    onnx_layers = onnxmodel_extractor.extract()
    print(onnx_layers)
    float_mode = not onnxmodel_extractor.is_quantized_model()
    print(float_mode)
