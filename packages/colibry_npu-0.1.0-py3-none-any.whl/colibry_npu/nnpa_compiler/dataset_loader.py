# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2026 Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator


class HFDataGen(tf.keras.utils.Sequence):
    def __init__(
        self,
        hf_dataset,
        batch_size=32,
        input_shape=(96, 96, 3),
        input_scaling=255.0,
        standardize=True,
        shuffle=True,
        augmentation=True,
    ):
        self.dataset = hf_dataset
        self.batch_size = batch_size
        self.input_shape = input_shape
        self.input_scaling = input_scaling
        self.standardize = standardize
        self.shuffle = shuffle
        self.augmentation = augmentation
        self.on_epoch_end()

        self.datagen = ImageDataGenerator(rotation_range=15, horizontal_flip=True)

    def __len__(self):
        return len(self.indices) // self.batch_size

    def on_epoch_end(self):
        self.indices = list(range(len(self.dataset)))
        if self.shuffle:
            np.random.shuffle(self.indices)

    def __getitem__(self, index):
        batch_idx = self.indices[index * self.batch_size : (index + 1) * self.batch_size]
        batch = self.dataset.select(batch_idx)

        x_list = []
        y_list = []

        for item in batch:
            img_data = item.get("image", item.get("img", None))

            if img_data is None:
                raise KeyError("Dataset item does not contain 'image' or 'img' key.")
            img = img_data.resize(self.input_shape[:2])
            x = np.array(img).astype(np.float32)

            if x.ndim == 2:
                x = np.expand_dims(x, -1)
            if x.shape[-1] == 1 and self.input_shape[-1] == 3:
                x = np.repeat(x, 3, axis=-1)

            if self.standardize:
                x -= np.mean(x, keepdims=True)
                x /= np.std(x, keepdims=True) + 1e-6

            x = x / self.input_scaling

            if self.augmentation:
                x = self.datagen.random_transform(x)

            x_list.append(x)
            y_list.append(item["label"])

        return np.stack(x_list), np.array(y_list)

    def iter_samples(self, apply_augmentation=False, max_samples=None):
        count = 0
        for idx in self.indices:
            if max_samples is not None and count >= max_samples:
                break

            item = self.dataset[idx]
            img_data = item.get("image", item.get("img", None))

            if self.input_shape[-1] == 1:
                img_data = img_data.convert("L")
            elif self.input_shape[-1] == 3:
                img_data = img_data.convert("RGB")
            else:
                raise ValueError(f"Unsupported input channel configuration: {self.input_shape[-1]}")

            if img_data is None:
                raise KeyError("Dataset item does not contain 'image' or 'img' key.")
            img = img_data.resize(self.input_shape[:2])
            x = np.array(img).astype(np.float32)

            if x.ndim == 2:
                x = np.expand_dims(x, -1)
            if x.shape[-1] == 1 and self.input_shape[-1] == 3:
                x = np.repeat(x, 3, axis=-1)

            if self.standardize:
                x -= np.mean(x, keepdims=True)
                x /= np.std(x, keepdims=True) + 1e-6

            x = x / self.input_scaling

            if apply_augmentation and self.augmentation:
                x = self.datagen.random_transform(x)

            yield x, item["label"]
            count += 1
