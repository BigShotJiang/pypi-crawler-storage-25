# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2024, Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
from colibry_npu.nnpa_compiler.tf_model_extractor import TFmodelExtractor
import numpy as np
import argparse
from typing import Any
from numpy.typing import NDArray
from tensorflow.keras.models import load_model

MIPE_PAR = 2
N_MIPE = 8
NWEIGHT_BIAS = 3
NWORD_BUFFER = 1024
NWORD_PER_LAYER = 1.5
NWORD_GLOBAL = 2
LAYER_EXTRA_CYCLES = 8
NN_EXTRA_CYCLES = 6


def get_model_metrics(model_dict, verbose=False):
    layersInfo = []
    maxNwordData = 0
    biasRCycle = int(np.ceil(NWEIGHT_BIAS / MIPE_PAR))

    prevLayerNwordData = 0

    idx = 0
    while idx < len(model_dict):
        l = model_dict[idx]
        discardedLayer = False

        # Extract layer input dimensions
        #
        inputWidth = l["ifmap_width"]
        inputHeight = l["ifmap_height"]
        inputDepth = l["ifmap_depth"]

        outputWidth = l["ofmap_width"]
        outputHeight = l["ofmap_height"]
        outputDepth = l["ofmap_depth"]

        # quantizedLayer, lConfig, layerName = extract_layer_params(l)
        layerName = l["refname"]
        layerType = l["type"]

        if idx == 0:
            npack = int(np.floor(N_MIPE / inputDepth)) if inputDepth < N_MIPE else 1
            prevLayerNwordData = (
                np.ceil(inputDepth / N_MIPE) * inputHeight * np.ceil(inputWidth / MIPE_PAR)
            )
            prevLayerNwordData = int(np.ceil(prevLayerNwordData / npack))

        # Cycles counting
        #
        layerCycles = 0
        layerParams = 0
        layerData = 0
        layerMacs = 0
        layerNwordWeight = 0
        layerNwordData = 0

        # ---------------------------------------------------------------------------------------
        if layerType == "dense":
            nOutputs = outputDepth

            nInputs = inputWidth * inputHeight * inputDepth

            layerCycles = int(
                np.ceil(nOutputs / N_MIPE)
                * (biasRCycle + inputWidth * inputHeight * np.ceil(inputDepth / MIPE_PAR))
            )
            # Note: after flatten layer, read inputWidth, inputHeight and inputDepth are lost. if inputDepth % MIPE_PAR != 0 -> difference in  layerCycles
            layerParams = int((nInputs + NWEIGHT_BIAS) * nOutputs)
            layerData = nOutputs
            layerMacs = int(nOutputs * (nInputs + 1))

            nGrp = int(np.ceil(nOutputs / N_MIPE))
            lastGrp = nOutputs % N_MIPE if nOutputs % N_MIPE > 0 else N_MIPE
            ndataWordLastGrp = int(np.floor(N_MIPE / lastGrp)) * MIPE_PAR
            layerNwordWeight = (nGrp - 1) * int(np.ceil((nInputs + NWEIGHT_BIAS) / MIPE_PAR)) + int(
                np.ceil((nInputs + NWEIGHT_BIAS) / ndataWordLastGrp)
            )

            layerNwordData = int(np.ceil(nOutputs / (N_MIPE * MIPE_PAR)))

            nWordNeed = prevLayerNwordData + layerNwordData
            maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData

        # ---------------------------------------------------------------------------------------
        elif layerType == "conv":
            kernel_size = (l["kernel_size_y"], l["kernel_size_x"])
            strides = (l["stride_y"], l["stride_x"])
            dilation_rate = (l["dilation_y"], l["dilation_x"])
            padding = l["padding"]

            if dilation_rate != (1, 1):
                print("*** Error: dilation > 1 not supported")
                exit(1)

            if inputDepth <= 1:
                cycle_per_kernel = int(np.ceil(kernel_size[0] * kernel_size[1] / MIPE_PAR))
                layerCycles = int(
                    (biasRCycle * np.ceil(outputDepth / N_MIPE))
                    + (
                        cycle_per_kernel
                        * outputHeight
                        * outputWidth
                        * np.ceil(outputDepth / N_MIPE)
                    )
                )
            else:
                layerCycles = int(
                    (biasRCycle * np.ceil(outputDepth / N_MIPE))
                    + (
                        np.ceil(inputDepth / MIPE_PAR)
                        * kernel_size[0]
                        * kernel_size[1]
                        * outputHeight
                        * outputWidth
                        * np.ceil(outputDepth / N_MIPE)
                    )
                )

            layerParams = int(
                (kernel_size[0] * kernel_size[1] * inputDepth + NWEIGHT_BIAS) * outputDepth
            )

            layerData = int(outputHeight * outputWidth * outputDepth)

            layerMacs = int(
                (kernel_size[0] * kernel_size[1] * inputDepth + 1)
                * outputHeight
                * outputWidth
                * outputDepth
            )

            layerNwordWeight = int(
                np.ceil(
                    (kernel_size[0] * kernel_size[1] * inputDepth + NWEIGHT_BIAS)
                    * np.ceil(outputDepth / N_MIPE)
                    / MIPE_PAR
                )
            )

            npack = int(np.floor(N_MIPE / outputDepth)) if outputDepth < N_MIPE else 1
            layerNwordData = (
                np.ceil(outputDepth / N_MIPE) * outputHeight * np.ceil(outputWidth / MIPE_PAR)
            )
            layerNwordData = int(np.ceil(layerNwordData / npack))

            nWordNeed = int(
                prevLayerNwordData
                + np.ceil(outputDepth / N_MIPE)
                * np.ceil(kernel_size[0] / 2)
                * np.ceil(outputWidth / MIPE_PAR)
                + 1
            )
            maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData

        # ---------------------------------------------------------------------------------------
        elif layerType == "conv_dw":
            kernel_size = (l["kernel_size_y"], l["kernel_size_x"])
            strides = (l["stride_y"], l["stride_x"])
            dilation_rate = (l["dilation_y"], l["dilation_x"])
            padding = l["padding"]
            if dilation_rate != (1, 1):
                print("*** Error: dilation > 1 not supported")
                exit(1)

            cycle_per_kernel = int(np.ceil(kernel_size[0] * kernel_size[1] / MIPE_PAR))
            layerCycles = int(
                (biasRCycle * np.ceil(outputDepth / N_MIPE))
                + (cycle_per_kernel * outputHeight * outputWidth * np.ceil(outputDepth / N_MIPE))
            )

            layerParams = int((kernel_size[0] * kernel_size[1] + NWEIGHT_BIAS) * outputDepth)

            layerData = int(outputHeight * outputWidth * outputDepth)

            layerMacs = int(
                (kernel_size[0] * kernel_size[1] + 1) * outputHeight * outputWidth * outputDepth
            )

            layerNwordWeight = int(
                np.ceil(
                    (kernel_size[0] * kernel_size[1] + NWEIGHT_BIAS)
                    * np.ceil(outputDepth / N_MIPE)
                    / MIPE_PAR
                )
            )

            npack = int(np.floor(N_MIPE / outputDepth)) if outputDepth < N_MIPE else 1
            layerNwordData = (
                np.ceil(outputDepth / N_MIPE) * outputHeight * np.ceil(outputWidth / MIPE_PAR)
            )
            layerNwordData = int(np.ceil(layerNwordData / npack))

            nWordNeed = int(
                prevLayerNwordData
                + np.ceil(kernel_size[0] / 2) * np.ceil(outputWidth / MIPE_PAR)
                + 1
            )
            maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData

        # ---------------------------------------------------------------------------------------
        elif layerType == "max_pool" or layerType == "avg_pool":
            pool_size = (l["pool_size_y"], l["pool_size_x"])
            strides = (l["stride_y"], l["stride_x"])
            padding = l["padding"]

            cycle_per_kernel = int(np.ceil(pool_size[0] * pool_size[1] / MIPE_PAR))
            layerCycles = int(
                cycle_per_kernel * outputHeight * outputWidth * np.ceil(outputDepth / N_MIPE)
            )

            layerParams = 0

            layerData = int(outputHeight * outputWidth * outputDepth)

            layerMacs = int(pool_size[0] * pool_size[1] * outputHeight * outputWidth * outputDepth)

            layerNwordWeight = 0

            npack = int(np.floor(N_MIPE / outputDepth)) if outputDepth < N_MIPE else 1
            layerNwordData = (
                np.ceil(outputDepth / N_MIPE) * outputHeight * np.ceil(outputWidth / MIPE_PAR)
            )
            layerNwordData = int(np.ceil(layerNwordData / npack))

            nWordNeed = int(
                prevLayerNwordData + np.ceil(pool_size[0] / 2) * np.ceil(outputWidth / MIPE_PAR) + 1
            )
            maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
        # ---------------------------------------------------------------------------------------
        elif layerType == "add":
            outH, outW, outC = outputHeight, outputWidth, outputDepth
            # MACs: 2 multiplies per element (data1*weight1 + data2*weight2)
            layerMacs = int(2 * outH * outW * outC)

            skip_layer_name = None

            skip_layer_name = l["in_refname"]
            skipLayerNwordData = 0
            for layer_info in layersInfo:
                if layer_info[1] == skip_layer_name:
                    skipLayerNwordData = int(layer_info[7])
                    break

            layerParams = 3  # bias, weight1, weight2
            layerNwordWeight = 0

            # Data
            layerData = int(outH * outW * outC)

            nDepthOutGrp = int(np.ceil(outC / N_MIPE))
            layerCycles = int(outH * outW * nDepthOutGrp)

            npack = int(np.floor(N_MIPE / outC)) if outC < N_MIPE else 1
            layerNwordData = np.ceil(outC / N_MIPE) * outH * np.ceil(outW / MIPE_PAR)
            layerNwordData = int(np.ceil(layerNwordData / npack))

            nWordNeed = int(prevLayerNwordData + skipLayerNwordData + layerNwordData)
            maxNwordData = nWordNeed if nWordNeed > maxNwordData else maxNwordData
        # ---------------------------------------------------------------------------------------
        else:
            discardedLayer = True
            pass
        # batch normalization and activation layers assumed to be fused at inference

        if discardedLayer:
            if (
                layerType == "InputLayer"
                or layerType == "BatchNormalization"
                or layerType == "Activation"
                or layerType == "ReLU"
                or layerType == "Flatten"
            ):
                pass
            else:
                print("*** Layer (%d) '%s' unknown (discarded)" % (idx, layerType))
        else:
            prevLayerNwordData = layerNwordData
            layerCycles += LAYER_EXTRA_CYCLES  # Due to HW latency between layers

            if len(layersInfo) == 0:
                layersInfo = np.array(
                    [
                        idx,
                        layerName,
                        layerParams,
                        layerData,
                        layerCycles,
                        layerMacs,
                        layerNwordWeight,
                        layerNwordData,
                    ]
                )
            else:
                layersInfo = np.vstack(
                    (
                        layersInfo,
                        [
                            idx,
                            layerName,
                            layerParams,
                            layerData,
                            layerCycles,
                            layerMacs,
                            layerNwordWeight,
                            layerNwordData,
                        ],
                    )
                )

        idx += 1

    # Hardware metrics
    nnMembuffData = int(np.ceil(maxNwordData / NWORD_BUFFER))
    if layersInfo.ndim == 1:
        totalCycles = int(layersInfo[4]) + NN_EXTRA_CYCLES
        nnMemwordsCfg = (
            NWORD_GLOBAL
            + int(np.ceil(NWORD_PER_LAYER * len(layersInfo)))
            + np.sum(layersInfo[6].astype(int))
        )
        totalWeights = np.sum(layersInfo[2].astype(int))
        totalMacs = np.sum(layersInfo[5].astype(int))
    else:
        totalCycles = np.sum(layersInfo[:, 4].astype(int)) + NN_EXTRA_CYCLES
        nnMemwordsCfg = (
            NWORD_GLOBAL
            + int(np.ceil(NWORD_PER_LAYER * len(layersInfo)))
            + np.sum(layersInfo[:, 6].astype(int))
        )
        totalWeights = np.sum(layersInfo[:, 2].astype(int))
        totalMacs = np.sum(layersInfo[:, 5].astype(int))
    nnMembuffCfg = int(np.ceil(nnMemwordsCfg / NWORD_BUFFER))

    if verbose:
        # Display layer per layer metrics
        print("_" * 90)
        print(
            "Layer name".ljust(20)
            + "Weights #".ljust(15)
            + "Data #".ljust(20)
            + "Cycles #".ljust(20)
            + "MACs #".ljust(20)
        )
        print("=" * 90)

        for l in layersInfo:
            print(l[1].ljust(20), end="")
            print(str(l[2]).ljust(15), end="")
            print(str(l[3]).ljust(20), end="")
            print(str(l[4]).ljust(20), end="")
            print(str(l[5]).ljust(20))
            print("_" * 90)

        # Display total
        print(" " * 90)
        print("Total".ljust(20), end="")
        print(str(totalWeights).ljust(15), end="")
        print("-".ljust(20), end="")
        print(str(totalCycles).ljust(20), end="")
        print(str(totalMacs).ljust(20))
        print("_" * 90)

    return layersInfo, nnMemwordsCfg, nnMembuffCfg, totalCycles, maxNwordData, nnMembuffData


if __name__ == "__main__":
    # Parse command-line arguments
    ##############################
    parser = argparse.ArgumentParser(
        description="This script estimates the hardware resources needed to execute a given Tensoflow model."
    )

    parser.add_argument("saved_model", type=str, help="Path to a saved model (TF2 format)")
    args = parser.parse_args()

    print("Hardware resources estimation with following settings:")
    print("MIPE_PAR = " + str(MIPE_PAR))
    print("N_MIPE = " + str(N_MIPE))
    print("NWEIGHT_BIAS = " + str(NWEIGHT_BIAS))

    model = load_model(args.saved_model)
    model.summary()
    NBIT_BIAS = 24  # No. bits of biases (multiple of NBIT_WEIGHT)
    NBIT_DATA = 8
    NBIT_SCALING = 16
    SCALING_EXP_MAX = 3
    bn_epsilon = 0.001
    tfmodel_extractor = TFmodelExtractor(
        model,
        quantNumbits=NBIT_DATA,
        biasNumbits=NBIT_BIAS,
        scalingNumbits=NBIT_SCALING,
        scalingExpMax=SCALING_EXP_MAX,
        bnEpsilon=bn_epsilon,
    )

    ## In case input model is not QAT, export a float model
    float_mode = not tfmodel_extractor.is_quantized_model()
    all_layers = tfmodel_extractor.extract()

    layersInfo, nnMemwordsCfg, nnMembuffCfg, totalCycles, maxNwordData, nnMembuffData = (
        get_model_metrics(all_layers, True)
    )

    print(
        "Inference requires %d cycles, %d config buffer, %d data buffer."
        % (totalCycles, nnMembuffCfg, nnMembuffData)
    )
    print("%d config words, %d data words." % (nnMemwordsCfg, maxNwordData))
