# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2026 Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import tensorflow as tf
import tensorflow_model_optimization as tfmot
import numpy as np
from tensorflow.keras.models import Model
from tensorflow.keras.layers import *
from tensorflow.keras import activations

LastValueQuantizer = tfmot.quantization.keras.quantizers.LastValueQuantizer
MovingAverageQuantizer = tfmot.quantization.keras.quantizers.MovingAverageQuantizer
quantize_annotate_layer = tfmot.quantization.keras.quantize_annotate_layer
quantize_annotate_model = tfmot.quantization.keras.quantize_annotate_model
quantize_scope = tfmot.quantization.keras.quantize_scope
quantizers = tfmot.quantization.keras.quantizers


class WeightsQuantizer(quantizers.LastValueQuantizer):
    def __init__(self, num_bits, per_axis, symmetric, narrow_range):
        super(WeightsQuantizer, self).__init__(
            num_bits=num_bits, per_axis=per_axis, symmetric=symmetric, narrow_range=narrow_range
        )

    ## build() function needs a specific description for per-axis quantization
    def build(self, tensor_shape, name, layer):
        if self.per_axis:
            min_weight = layer.add_weight(
                name + "_min",
                shape=(tensor_shape[-1],),
                initializer=tf.keras.initializers.Constant(-6.0),
                trainable=False,
            )

            max_weight = layer.add_weight(
                name + "_max",
                shape=(tensor_shape[-1],),
                initializer=tf.keras.initializers.Constant(6.0),
                trainable=False,
            )

            return {"min_var": min_weight, "max_var": max_weight}
        else:
            return super(WeightsQuantizer, self).build(tensor_shape, name, layer)


class DenseQuantizeConfig(
    tfmot.quantization.keras.QuantizeConfig,
):
    global ACTIV_NBITS
    global WEIGHT_NBITS
    global WEIGHT_SYMMETRIC
    global WEIGHT_PER_AXIS

    def get_weights_and_quantizers(self, layer):
        ## Configuration for Dense layers weights is done here
        return [
            (
                layer.kernel,
                WeightsQuantizer(
                    num_bits=WEIGHT_NBITS,
                    symmetric=WEIGHT_SYMMETRIC,
                    narrow_range=False,
                    per_axis=WEIGHT_PER_AXIS,
                ),
            )
        ]

    def get_activations_and_quantizers(self, layer):
        ## Configuration for Dense layers activations is done here
        return [
            (
                layer.activation,
                MovingAverageQuantizer(
                    num_bits=ACTIV_NBITS, symmetric=False, narrow_range=False, per_axis=False
                ),
            )
        ]

    def set_quantize_weights(self, layer, quantize_weights):
        layer.kernel = quantize_weights[0]

    def set_quantize_activations(self, layer, quantize_activations):
        layer.activation = quantize_activations[0]

    def get_output_quantizers(self, layer):
        return []

    def get_config(self):
        return {}


class ConvQuantizeConfig(tfmot.quantization.keras.QuantizeConfig):
    global ACTIV_NBITS
    global WEIGHT_NBITS
    global WEIGHT_SYMMETRIC
    global WEIGHT_PER_AXIS

    def get_weights_and_quantizers(self, layer):
        ## Configuration for Conv layers weights is done here
        if hasattr(layer, "kernel"):
            kernel = layer.kernel
        else:
            kernel = layer.depthwise_kernel

        return [
            (
                kernel,
                WeightsQuantizer(
                    num_bits=WEIGHT_NBITS,
                    symmetric=WEIGHT_SYMMETRIC,
                    narrow_range=False,
                    per_axis=WEIGHT_PER_AXIS,
                ),
            )
        ]

    def get_activations_and_quantizers(self, layer):
        ## Configuration for Conv layers activations is done here
        return [
            (
                layer.activation,
                MovingAverageQuantizer(
                    num_bits=ACTIV_NBITS, symmetric=False, narrow_range=False, per_axis=False
                ),
            )
        ]

    def set_quantize_weights(self, layer, quantize_weights):
        layer.kernel = quantize_weights[0]

    def set_quantize_activations(self, layer, quantize_activations):
        layer.activation = quantize_activations[0]

    def get_output_quantizers(self, layer):
        return []

    def get_config(self):
        return {}


class OutputQuantizeConfig(tfmot.quantization.keras.QuantizeConfig):
    global ACTIV_NBITS
    global WEIGHT_NBITS
    global WEIGHT_SYMMETRIC
    global WEIGHT_PER_AXIS

    def get_weights_and_quantizers(self, layer):
        return []

    def get_activations_and_quantizers(self, layer):
        return []

    def set_quantize_weights(self, layer, quantize_weights):
        pass

    def set_quantize_activations(self, layer, quantize_activations):
        pass

    def get_output_quantizers(self, layer):
        # Configuration for layers outputs quantization is done here
        return [
            MovingAverageQuantizer(
                num_bits=ACTIV_NBITS, symmetric=False, narrow_range=False, per_axis=False
            )
        ]

    def get_config(self):
        return {}


class NoOpQuantizeConfig(tfmot.quantization.keras.QuantizeConfig):
    def get_weights_and_quantizers(self, layer):
        return []

    def get_activations_and_quantizers(self, layer):
        return []

    def set_quantize_weights(self, layer, quantize_weights):
        pass

    def set_quantize_activations(self, layer, quantize_activations):
        pass

    def get_output_quantizers(self, layer):
        return []

    def get_config(self):
        return {}


def layer_quantization(layer):
    ## Not annotated layers will not be quantized for training
    if isinstance(layer, tf.keras.layers.Dense):
        return tfmot.quantization.keras.quantize_annotate_layer(layer, DenseQuantizeConfig())
    elif isinstance(layer, tf.keras.layers.Conv2D) or isinstance(
        layer, tf.keras.layers.DepthwiseConv2D
    ):
        return tfmot.quantization.keras.quantize_annotate_layer(layer, ConvQuantizeConfig())
    # elif isinstance(layer, tf.keras.layers.BatchNormalization):
    #  return tfmot.quantization.keras.quantize_annotate_layer(layer, NoOpQuantizeConfig())
    elif isinstance(layer, tf.keras.layers.Activation) or isinstance(layer, tf.keras.layers.ReLU):
        return tfmot.quantization.keras.quantize_annotate_layer(layer, OutputQuantizeConfig())
    elif isinstance(layer, tf.keras.layers.Add) or isinstance(layer, tf.keras.layers.Identity):
        return tfmot.quantization.keras.quantize_annotate_layer(layer, OutputQuantizeConfig())
    elif isinstance(layer, tf.keras.layers.Flatten):
        return tfmot.quantization.keras.quantize_annotate_layer(layer, OutputQuantizeConfig())
    # else:
    #  return tfmot.quantization.keras.quantize_annotate_layer(layer, NoOpQuantizeConfig())
    return layer


def check_transformable(model):
    idx = 0
    transformable = True

    # for l in model.layers:
    # if "Add" in l.__class__.__name__:
    #   transformable = False

    # TODO: Transform the model even with Add layers or if not Sequential

    return transformable


def transform_model_sequential(model):
    x = model.input
    addedNbr = 1

    idx = 0
    while idx < len(model.layers):
        if model.layers[idx].__class__.__name__ == "InputLayer":
            idx += 1
            continue

        ## Integrate isolated activation to previous layer
        if (
            model.layers[idx].__class__.__name__ == "Activation"
            and model.layers[idx - 1].__class__.__name__ != "BatchNormalization"
            and (
                model.layers[idx - 1].__class__.__name__ == "Conv2D"
                or model.layers[idx - 1].__class__.__name__ == "DepthwiseConv2D"
                or model.layers[idx - 1].__class__.__name__ == "Dense"
            )
        ):
            model.layers[idx - 1].activation = model.layers[idx].activation
            idx += 1
            continue

        x = model.layers[idx](x)

        ## Add a linear activation (= no activation) after batch normalization layers if no activation present.
        ## This is needed for quantization statistics after BN
        if (
            model.layers[idx].__class__.__name__ == "BatchNormalization"
            and model.layers[idx + 1].__class__.__name__ != "Activation"
        ):
            x = Activation("linear", name="linear_activation_%d" % addedNbr)(x)
            addedNbr += 1

        idx += 1

    transformedModel = Model(inputs=model.inputs, outputs=x)

    ## Replace activation in last layer as a separate layer (needed for quantization)
    """
  if (transformedModel.layers[-1].__class__.__name__ != 'Activation' and
      'activation' in transformedModel.layers[-1].get_config()):
    activationName = transformedModel.layers[-1].get_config()['activation']
    if activationName != 'linear':
      transformedModel.layers[-1].activation = activations.linear
      lastActivationLayer = Activation(activationName, name="last_activation")(transformedModel.output)
      transformedModel = Model(inputs=model.inputs, outputs=lastActivationLayer)
  """
    return transformedModel


def topological_sort_tf_layers(model):
    from collections import defaultdict

    visited = set()
    sorted_layers = []
    layer_dict = {layer.name: layer for layer in model.layers}
    reverse_adj = defaultdict(list)
    forward_adj = defaultdict(list)

    # Build graph connections
    for layer in model.layers:
        for node in layer._inbound_nodes:
            inbound_layers = node.inbound_layers
            if not inbound_layers:
                continue
            if not isinstance(inbound_layers, list):
                inbound_layers = [inbound_layers]
            for in_layer in inbound_layers:
                if in_layer:
                    reverse_adj[layer.name].append(in_layer.name)
                    forward_adj[in_layer.name].append(layer.name)

    # Compute depth
    depth_cache = {}

    def compute_reverse_depth(layer_name):
        if layer_name in depth_cache:
            return depth_cache[layer_name]
        children = forward_adj.get(layer_name, [])
        if not children:
            depth_cache[layer_name] = 1
        else:
            depth_cache[layer_name] = 1 + max(compute_reverse_depth(c) for c in children)
        return depth_cache[layer_name]

    for layer in model.layers:
        compute_reverse_depth(layer.name)

    output_layers = [layer.name for layer in model.layers if not forward_adj[layer.name]]

    def dfs(layer_name):
        if layer_name in visited:
            return
        visited.add(layer_name)

        parents = reverse_adj.get(layer_name, [])
        # Sort (deeper first)
        sorted_parents = sorted(parents, key=lambda l: -depth_cache[l])
        for parent in sorted_parents:
            dfs(parent)

        sorted_layers.append(layer_dict[layer_name])

    for out_layer in output_layers:
        dfs(out_layer)

    return sorted_layers


def get_sorted_layer_index(layer, sorted_layers):
    for idx, sorted_layer in enumerate(sorted_layers):
        if layer == sorted_layer:
            return idx


def transform_model(model):
    sorted_layers = topological_sort_tf_layers(model)
    input_layer = tf.keras.Input(shape=model.input_shape[1:])
    layer_outputs = {}

    first_layer = model.layers[0]
    if isinstance(first_layer, tf.keras.layers.InputLayer):
        layer_outputs[first_layer.name] = input_layer
        start_idx = 1
    else:
        start_idx = 0

    skip_next = False

    for idx in range(start_idx, len(model.layers)):
        if skip_next:
            skip_next = False
            continue

        layer = model.layers[idx]

        if isinstance(layer.input, list):
            input_tensors = [layer_outputs[inp._keras_history.layer.name] for inp in layer.input]
        else:
            input_tensors = layer_outputs[layer.input._keras_history.layer.name]

        # Conv2D/DepthwiseConv2D + ReLU fusion
        if isinstance(layer, (tf.keras.layers.Conv2D, tf.keras.layers.DepthwiseConv2D)):
            next_idx = get_sorted_layer_index(layer, sorted_layers) + 1
            if next_idx < len(model.layers):
                next_layer = sorted_layers[next_idx]
                is_relu = isinstance(next_layer, (tf.keras.layers.ReLU))
                if is_relu:
                    config = layer.get_config()
                    config["activation"] = "relu"
                    new_conv = layer.__class__.from_config(config)
                    x = new_conv(input_tensors)

                    new_conv.set_weights(layer.get_weights())

                    layer_outputs[layer.name] = x
                    layer_outputs[next_layer.name] = x

                    skip_next = True
                    continue

        x = layer(input_tensors)

        if isinstance(layer, tf.keras.layers.BatchNormalization):
            next_idx = get_sorted_layer_index(layer, sorted_layers) + 1
            if (next_idx >= len(model.layers)) or (
                not isinstance(
                    sorted_layers[next_idx], (tf.keras.layers.Activation, tf.keras.layers.ReLU)
                )
            ):
                print("placing a new linear activation")
                x = tf.keras.layers.Activation("linear", name=f"linear_activation_bn_{idx}")(x)

        layer_outputs[layer.name] = x

    transformed_model = tf.keras.Model(inputs=input_layer, outputs=x)
    return transformed_model


# Correct structure for batch normalization: CONV-BN-ACTIVATION or DENSE-BN-ACTIVATION
def quantize(model, activ_nbits=8, weight_nbits=8, weight_symmetric=False, weight_per_axis=False):
    global ACTIV_NBITS
    global WEIGHT_NBITS
    global WEIGHT_SYMMETRIC
    global WEIGHT_PER_AXIS

    ACTIV_NBITS = activ_nbits
    WEIGHT_NBITS = weight_nbits
    WEIGHT_SYMMETRIC = weight_symmetric
    WEIGHT_PER_AXIS = weight_per_axis

    print("Quantization parameters")
    print("-----------------------")
    print("Activations nbits:", ACTIV_NBITS)
    print("Weights nbits:", WEIGHT_NBITS)
    print("Symmetrical weights:", WEIGHT_SYMMETRIC)
    print("Per-axis weights:", WEIGHT_PER_AXIS)
    print("-----------------------")

    if check_transformable(model):
        print("Model will be transformed if needed.")
        model.summary()
        transformedModel = tf.keras.models.clone_model(model)
        transformedModel.set_weights(model.get_weights())
        if isinstance(transformedModel, tf.keras.Sequential):
            transformedModel = transform_model_sequential(transformedModel)
        else:
            transformedModel = transform_model(transformedModel)
        print("transformed model summary")
        transformedModel.summary()
    else:
        transformedModel = model

    annotated_model = tf.keras.models.clone_model(
        transformedModel, clone_function=layer_quantization
    )

    with quantize_scope(
        {
            "DenseQuantizeConfig": DenseQuantizeConfig,
            "ConvQuantizeConfig": ConvQuantizeConfig,
            "OutputQuantizeConfig": OutputQuantizeConfig,
            "NoOpQuantizeConfig": NoOpQuantizeConfig,
        }
    ):
        quant_aware_model = tfmot.quantization.keras.quantize_apply(annotated_model)
        return quant_aware_model
