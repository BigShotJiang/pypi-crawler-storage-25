# SPDX-License-Identifier: LicenseRef-Asygn-BSD3-Restricted
#
# Copyright (c) 2022, Asygn SAS
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form, except as embedded into a Asygn SAS
#    integrated circuit in a product or a software update for such product, must
#    reproduce the above copyright notice, this list of conditions and the
#    following disclaimer in the documentation and/or other materials provided
#    with the distribution.
#
# 3. Neither the name of Asygn SAS nor the names of its contributors may be used
#    to endorse or promote products derived from this software without specific
#    prior written permission.
#
# 4. This software, with or without modification, must only be used with a Asygn
#    SAS integrated circuit.
#
# 5. Any software provided in binary form under this license must not be reverse
#    engineered, decompiled, modified and/or disassembled.
#
# THIS SOFTWARE IS PROVIDED BY ASYGN SAS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL ASYGN SAS OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


import os, argparse, struct, logging, math
from typing import Optional, Union
import numpy as np
import crcmod
import tensorflow as tf
from tensorflow.keras.models import load_model
import colibry_npu.__version__
from colibry_npu.nnpa_compiler.tf_model_extractor import TFmodelExtractor
from colibry_npu.nnpa_compiler.tflite_model_extractor import TFLiteModelExtractor
from colibry_npu.nnpa_compiler.onnx_model_extractor import ONNXModelExtractor
from colibry_npu.nnpa_compiler.colibry_get_metrics import get_model_metrics
from colibry_npu.nnpa_compiler.custom_logger import logger

logging.info("Colibry NPU compiler version: %s", colibry_npu.__version__.__version__)
logging.info("TensorFlow version: %s", tf.__version__)
DEBUG_LOGS = False
MAX_MODEL_SIZE = 10**6

"""
  This script allows to convert a Tensorflow model (QAT or non-QAT) to a .nnpa file used
  by the hardware and Python models. The .nnpa file contains the configuration and weights
  of the NN in the form of a bitstream.
"""

## TODO list
#  - Provide requirements for cfgMem and dataMem (n banks required for each ...)
#  - If non-QAT, perform post-training quantization (less accurate)
#  - Support other frameworks/input formats (pytorch, ONNX ... ?)


################################################################################
## IP fixed parameters
################################################################################
PY_MODEL_CONST_FILE = "SIMULATION/TESTBENCH/MODEL/nnpa_constants.py"
VLOG_CONST_FILE = "RTL/includes/nnpa_core_pkg.v"
HPP_CONST_FILE = "SIMULATION/TESTBENCH/MODEL/NNPA_CORE_CPP/nnpa_constants.hpp"

MIPE_PAR = 2  # MIPE parallelism (2: DIPE or 4: QIPE)
N_MIPE = 8  # No. MultipleInputPE (= parallelism of output depth for CONV/POOL layers)
NBIT_WEIGHT = 8  # No. bits of each weight (except biases)
NBIT_BIAS = 24  # No. bits of biases (multiple of NBIT_WEIGHT)
NBIT_DATA = 8  # No. bits of input data and activations
NBIT_MAC = 24  # No. bits of MAC accumulators
NBIT_SCALING = 16  # No. bits of scaling factor
SCALING_EXP_MAX = 3  # Maximum value for power of 2 multiplication while scaling

N_BUFF_DEFAULT = 40  # Total number of memory buffers for config and data
NWORD_BUFF_DEFAULT = 1024  # Number of words of (MIPE_PAR * N_MIPE) bytes in each buffer
MEM_READ_LATENCY = 3  # Latency in cycle from command to data at memory buffer pool output
NSTEP_SCALING = 1  # Number of steps or cycles to execute the scaling at MIPE output
MIPE_INPUT_PP = 1  # Set 1 to pipeline MIPE inputs
NWORD_WEIGHTS_CACHE = 32  # Number of memory words of the weights cache
NNPA_CRC_POLY = 0x11021  # CRC polynomial x^16 + x^12 + x^5 + 1
NNPA_CRC_INIT = 0xFFFF  # CRC initial value

## Configuration constants definition
CONV_LAYER = 1
POOL_LAYER = 2
FC_LAYER = 3
ADD_LAYER = 4
XTEN_LAYER = 5
PADDING_VALID = 0
PADDING_SAME = 1
ACTIVATION_NONE = 0
ACTIVATION_RELU = 1
ACTIVATION_SOFTMAX = 2
ACTIVATION_SIGMOID = 3
ACTIVATION_UNKNOWN = 7
POOLING_MAX = 0
POOLING_AVG = 1

## Bitwidth of nnpa model configuration
NBIT_FIELD_MODEL_ID = 16  # Shall be a multiple of 8
NBIT_FIELD_MODEL_SIZE = 20
NBIT_FIELD_FMAP_SIZE = 20
NBIT_FIELD_N_LAYER = 10
NBIT_FIELD_SCALING_DIN = 16
NBIT_FIELD_SCALING_DIN_INT = 4
NBIT_FIELD_OFFSET_DIN = 16
NBIT_FIELD_INPUT_SIZE_X = 10
NBIT_FIELD_INPUT_SIZE_Y = 10
NBIT_FIELD_INPUT_SIZE_Z = 12
NBIT_FIELD_ROW_INCR = 16
NBIT_FIELD_PACK_LVL = 3
NBIT_FIELD_W_MEMOFFSET = 16
NBIT_FIELD_SCALING_OUT = 16
NBIT_FIELD_ZERO_OUT = 16
NBIT_FIELD_LAYER_TYPE = 4
NBIT_FIELD_OUT_SIZE_X = 10
NBIT_FIELD_OUT_SIZE_Y = 10
NBIT_FIELD_OUT_SIZE_Z = 12
NBIT_FIELD_KERNEL_SIZE = 6
NBIT_FIELD_STRIDE = NBIT_FIELD_KERNEL_SIZE
NBIT_FIELD_PADDING_MODE = 1
NBIT_FIELD_PADDING = NBIT_FIELD_KERNEL_SIZE - 1
NBIT_FIELD_ACTIVATION = 2
NBIT_FIELD_LAST_ACTIVATION = 4
NBIT_FIELD_SCALING_FACTOR = NBIT_SCALING
NBIT_FIELD_POOL_TYPE = 2
NBIT_FIELD_FC_N_OUTPUT = 16
NBIT_FIELD_SCALING_EXPONENT = int(np.ceil(np.log2(SCALING_EXP_MAX)))
NBIT_FIELD_WEIGHT_INCR = 16

################################################################################
## Pre-calculated constants
################################################################################
NWEIGHT_BIAS = (NBIT_BIAS + NBIT_WEIGHT - 1) // NBIT_WEIGHT
NBIT_MEMBUFF_WORD = NBIT_DATA * N_MIPE * MIPE_PAR
NBIT_MEMBANK_WORD = NBIT_DATA * N_MIPE

NBIT_GLOBAL_CFG = (
    NBIT_FIELD_MODEL_ID
    + NBIT_FIELD_MODEL_SIZE
    + NBIT_FIELD_FMAP_SIZE * 2
    + NBIT_FIELD_N_LAYER
    + NBIT_FIELD_INPUT_SIZE_X
    + NBIT_FIELD_INPUT_SIZE_Y
    + NBIT_FIELD_INPUT_SIZE_Z
    + NBIT_FIELD_PACK_LVL
    + 1
    + NBIT_DATA
    + NBIT_FIELD_OUT_SIZE_X
    + NBIT_FIELD_OUT_SIZE_Y
    + NBIT_FIELD_OUT_SIZE_Z
    + NBIT_FIELD_PACK_LVL
    + 1
    + NBIT_FIELD_SCALING_OUT
    + NBIT_FIELD_ZERO_OUT
    + 4
    + NBIT_FIELD_SCALING_DIN
    + NBIT_FIELD_OFFSET_DIN
    + NBIT_FIELD_W_MEMOFFSET
)

NBIT_CONV_CFG = (
    NBIT_FIELD_LAYER_TYPE
    + 1
    + NBIT_FIELD_OUT_SIZE_X
    + NBIT_FIELD_OUT_SIZE_Y
    + NBIT_FIELD_OUT_SIZE_Z
    + NBIT_FIELD_KERNEL_SIZE * 2
    + NBIT_FIELD_STRIDE * 2
    + NBIT_FIELD_PADDING_MODE
    + NBIT_FIELD_PADDING * 4
    + NBIT_FIELD_ACTIVATION
    + NBIT_FIELD_SCALING_FACTOR
    + NBIT_FIELD_SCALING_EXPONENT
    + NBIT_WEIGHT
    + NBIT_DATA
    + NBIT_FIELD_ROW_INCR
    + NBIT_FIELD_PACK_LVL
    + NBIT_FIELD_FMAP_SIZE
    + 3
)

NBIT_POOL_CFG = (
    NBIT_FIELD_LAYER_TYPE
    + NBIT_FIELD_POOL_TYPE
    + NBIT_FIELD_OUT_SIZE_X
    + NBIT_FIELD_OUT_SIZE_Y
    + NBIT_FIELD_OUT_SIZE_Z
    + NBIT_FIELD_KERNEL_SIZE * 2
    + NBIT_FIELD_STRIDE * 2
    + NBIT_FIELD_PADDING_MODE
    + NBIT_FIELD_PADDING * 4
    + NBIT_FIELD_SCALING_FACTOR
    + NBIT_FIELD_ROW_INCR
    + NBIT_FIELD_PACK_LVL
    + NBIT_FIELD_FMAP_SIZE
    + 3
)

NBIT_FC_CFG = (
    NBIT_FIELD_LAYER_TYPE
    + NBIT_FIELD_FC_N_OUTPUT
    + NBIT_FIELD_ACTIVATION
    + NBIT_FIELD_SCALING_FACTOR
    + NBIT_FIELD_SCALING_EXPONENT
    + NBIT_WEIGHT
    + NBIT_DATA
    + NBIT_FIELD_INPUT_SIZE_Y
    + NBIT_FIELD_PACK_LVL
    + NBIT_FIELD_ROW_INCR
    + NBIT_FIELD_FMAP_SIZE
    + 3
)

NBIT_ADD_CFG = (
    NBIT_FIELD_LAYER_TYPE
    + NBIT_BIAS
    + NBIT_WEIGHT * 2
    + NBIT_FIELD_ROW_INCR
    + NBIT_FIELD_ACTIVATION
    + NBIT_FIELD_SCALING_FACTOR
    + NBIT_FIELD_SCALING_EXPONENT
    + NBIT_DATA
    + NBIT_FIELD_OUT_SIZE_X
    + NBIT_FIELD_OUT_SIZE_Y
    + NBIT_FIELD_OUT_SIZE_Z
    + NBIT_FIELD_PACK_LVL
    + NBIT_FIELD_FMAP_SIZE
    + 3
)

NBIT_LAYER_CFG = max(NBIT_CONV_CFG, NBIT_POOL_CFG, NBIT_FC_CFG, NBIT_ADD_CFG)
NWORD_GLOBAL_CONFIG = int(np.ceil(NBIT_GLOBAL_CFG / NBIT_MEMBUFF_WORD))
NBANKWORD_LAYER_CONFIG = int(np.ceil(NBIT_LAYER_CFG / NBIT_MEMBANK_WORD))

################################################################################
## Internal functions
################################################################################


### Compute the CRC/ID of the model
###
def calc_crc_id(nnpa_model, polynomial, init_val):
    byte_start_index = NBIT_FIELD_MODEL_ID // 8

    if len(nnpa_model) / (N_MIPE * MIPE_PAR) != len(nnpa_model) // (N_MIPE * MIPE_PAR):
        logging.warning(
            "Model size is not aligned with memory words. CRC calculation may be erroneous!"
        )
    """
    shift_reg = init_val;
    for byte_in in nnpa_model:
        for bit_in in [(byte_in >> (7-x)) & 1 for x in range(8)]:
            if (shift_reg & 0x8000) ^ (bit_in << 15) != 0:
                shift_reg = (shift_reg << 1) & 0xFFFF
                shift_reg ^= (polynomial & 0xFFFF)
            else:
                shift_reg = (shift_reg << 1) & 0xFFFF
    """
    crc_calculator = crcmod.mkCrcFun(polynomial, initCrc=init_val, xorOut=0x0000, rev=False)
    res = crc_calculator(bytearray(nnpa_model[byte_start_index:]))
    return res


### Append a field to nnpa_model
###
def add_field(nnpa_model, bit_idx, field_val, field_width):
    byte_index = bit_idx // 8
    bit_offset = bit_idx % 8
    for k in range(field_width):
        curr_bit = (field_val >> k) & 1
        nnpa_model[byte_index] |= curr_bit << bit_offset
        if bit_offset == 7:
            bit_offset = 0
            byte_index += 1
        else:
            bit_offset += 1
    return bit_idx + field_width


### Modify field to nnpa_model
###
def modify_field(nnpa_model, bit_idx, field_val, field_width):
    byte_index = bit_idx // 8
    bit_offset = bit_idx % 8
    for k in range(field_width):
        curr_bit = (field_val >> k) & 1
        nnpa_model[byte_index] &= ~int(1 << bit_offset)  # Erase bit
        nnpa_model[byte_index] |= curr_bit << bit_offset  # Set bit value
        if bit_offset == 7:
            bit_offset = 0
            byte_index += 1
        else:
            bit_offset += 1
    return bit_idx + field_width


### Check refname is used for skip connection in remaining layers
###
def check_skip_refname(curr_refname, all_layers):
    for l in all_layers:
        if l["type"] == "add" and l["in_refname"] == curr_refname:
            return 1
    return 0


### Check current ofmap is also used for another layer after the next one
###
def check_forked_layer(curr_idx, all_layers):
    for k in range(curr_idx + 2, len(all_layers)):
        if all_layers[k]["ifmap_source_idx"] == curr_idx:
            return 1
    return 0


### Get the number to be added to value so that is becomes a multiple of divisor
###
def remain_count(value, divisor):
    if value == 0:
        return divisor
    elif value % divisor == 0:
        return 0
    else:
        return divisor - (value % divisor)


### Add zero padding to reach an array length
###
def zero_pad(array, length):
    return array + [0] * (length - len(array))


### Ceil() of an integer division
###
def ceilDiv(intVal, divFactor):
    return (intVal + divFactor - 1) // divFactor


### Print a summary of imported model
###
def print_model_info(model):
    print("=" * 80)
    print(
        "Layer".ljust(16)
        + "Output size".ljust(26)
        + "Kernel size".ljust(20)
        + "Activation".ljust(20)
    )
    print("=" * 80)
    for layer in model:
        print(layer["type"].ljust(16), end="")
        print(
            (
                "(%d x %d x %d)"
                % (layer["ofmap_height"], layer["ofmap_width"], layer["ofmap_depth"])
            ).ljust(26),
            end="",
        )

        if layer["type"] == "dense":
            print("N/A".ljust(20), end="")
        elif layer["type"] == "max_pool" or layer["type"] == "avg_pool":
            print(str("(%d, %d)" % (layer["pool_size_y"], layer["pool_size_x"])).ljust(20), end="")
        elif layer["type"] == "conv" or layer["type"] == "conv_dw":
            print(
                str("(%d, %d)" % (layer["kernel_size_y"], layer["kernel_size_x"])).ljust(20), end=""
            )

        if "activation" in layer.keys():
            print(str(layer["activation"]).ljust(20))
        else:
            print("N/A".ljust(20))
    print("=" * 80)
    print("")


### DEBUG function: modify the weights for easier debugging
###
def hack_weights(cfg, random=False):
    if len(cfg["weights"].shape) == 2:
        for i in range(cfg["weights"].shape[0]):
            for j in range(cfg["weights"].shape[1]):
                cfg["weights"][i][j] = i + 1 + (j + 1) * 100
    else:
        for z in range(cfg["weights"].shape[2]):
            for y in range(cfg["weights"].shape[0]):
                for x in range(cfg["weights"].shape[1]):
                    for f in range(cfg["weights"].shape[3]):
                        cfg["weights"][y][x][z][f] = (
                            x + 1 + (y + 1) * 100 + (z + 1) * 10000 + (f + 1) * 1000000
                        )
    cfg["weights"] = cfg["weights"].astype("int")

    for i in range(cfg["biases"].shape[0]):
        cfg["biases"][i] = 0x140A00 + (i + 50) * (1 + 256 + 256**2)
    cfg["biases"] = cfg["biases"].astype("int")


### DEBUG function: show cfgmem content
###
def show_cfgmem(mem, float_mode):
    print("CFGMEM content")
    print("*" * 80)
    for i in range(len(mem) // N_MIPE):
        for j in range(N_MIPE):
            if float_mode:
                print("%.5g  " % mem[i * N_MIPE + j], end="")
            else:
                print("%08d  " % mem[i * N_MIPE + j], end="")
        if i % 2 == 0:
            print("  |  ", end="")
        else:
            print("\n", end="")


################################################################################
################################################################################
################################################################################
##    MAIN
################################################################################
################################################################################
################################################################################


def cli():
    ## Command line arguments
    #########################
    parser = argparse.ArgumentParser(
        description="Convert a TF or onnx or TFlite model and generate NNPA model file OR generate a dummy NNPA bitstream"
    )
    parser.add_argument("--gen_dummy", action="store_true", help="Generate a dummy NNPA bitstream")
    parser.add_argument("-iw", type=int, default=320)
    parser.add_argument("-ih", type=int, default=240)
    parser.add_argument("-ic", type=int, default=1)
    parser.add_argument("--flattened", action="store_true")
    parser.add_argument(
        "model", type=str, nargs="?", help="Path to a Tensorflow or onnx or TFlite model"
    )
    parser.add_argument("-ip_path", type=str, default=None, help="Path to NNPA core IP")
    parser.add_argument(
        "-nbuff",
        type=int,
        default=N_BUFF_DEFAULT,
        help="Number of memory buffers for config and data",
    )
    parser.add_argument(
        "-nwordbuff",
        type=int,
        default=NWORD_BUFF_DEFAULT,
        help="Number of words of (MIPE_PAR * N_MIPE) bytes per buffer",
    )
    parser.add_argument(
        "-sfin",
        type=int,
        default=255,
        help="Division factor applied to raw input data before training",
    )
    parser.add_argument(
        "-offin", type=int, default=0, help="Offset added to raw input data before training"
    )
    parser.add_argument(
        "-bn_epsilon",
        type=float,
        default=0.001,
        help="Epsilon parameter used for Batch Normalization layers",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show information of weights, data, cycles and Macs per layer",
    )
    args = parser.parse_args()
    if args.gen_dummy:
        generate(args.nbuff, args.nwordbuff, args.iw, args.ih, args.ic, args.flattened)
    else:
        if args.model is None:
            parser.error("Model path is required unless --gen_dummy is used")
        main(
            args.model,
            args.ip_path,
            args.nbuff,
            args.nwordbuff,
            args.sfin,
            args.offin,
            args.bn_epsilon,
            args.verbose,
        )


def generate(
    nbuff: int = N_BUFF_DEFAULT,
    nwordbuff: int = NWORD_BUFF_DEFAULT,
    iw: int = 320,
    ih: int = 240,
    ic: int = 1,
    flattened: bool = False,
):
    """
    Generate a dummy NNPA bitstream (only header valid)
    nbuff: Number of memory buffers for config and data
    nwordbuff: Number of words of (MIPE_PAR * N_MIPE) bytes per buffer
    iw: Width of input image
    ih: Height of input image
    ic: Number of channels of input image
    flattened: Flattened input
    """

    nnpa_model = np.zeros(MAX_MODEL_SIZE, dtype="uint8")

    ## Generate Global configuration (GLOBAL_CFG)
    #############################################
    bit_idx = 0
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_MODEL_ID)  # Field set afterwards
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_MODEL_SIZE)  # Field set afterwards
    if not flattened:
        input_pack_nb = max(1, int(np.floor(N_MIPE / ic)))
        nn_in_words = ceilDiv(ceilDiv(iw, MIPE_PAR) * ceilDiv(ic, N_MIPE) * ih, input_pack_nb)
    else:
        nn_in_words = ceilDiv(iw * ih * ic, N_MIPE * MIPE_PAR)
    bit_idx = add_field(nnpa_model, bit_idx, nn_in_words, NBIT_FIELD_FMAP_SIZE)
    max_data_words = 2**NBIT_FIELD_FMAP_SIZE - 1  # TODO: to be calculated from the model
    bit_idx = add_field(nnpa_model, bit_idx, max_data_words, NBIT_FIELD_FMAP_SIZE)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_N_LAYER)
    bit_idx = add_field(nnpa_model, bit_idx, iw - 1, NBIT_FIELD_INPUT_SIZE_X)
    bit_idx = add_field(nnpa_model, bit_idx, ih - 1, NBIT_FIELD_INPUT_SIZE_Y)
    bit_idx = add_field(nnpa_model, bit_idx, ic - 1, NBIT_FIELD_INPUT_SIZE_Z)
    input_pack_lvl = max(0, int(np.floor(np.log2(N_MIPE / ic))))
    bit_idx = add_field(nnpa_model, bit_idx, input_pack_lvl, NBIT_FIELD_PACK_LVL)
    bit_idx = add_field(nnpa_model, bit_idx, 1 if flattened else 0, 1)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_DATA)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_OUT_SIZE_X)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_OUT_SIZE_Y)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_OUT_SIZE_Z)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_PACK_LVL)
    bit_idx = add_field(nnpa_model, bit_idx, 0, 1)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_SCALING_OUT)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_ZERO_OUT)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_LAST_ACTIVATION)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_SCALING_DIN)
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_OFFSET_DIN)

    bit_idx = add_field(nnpa_model, bit_idx, NWORD_GLOBAL_CONFIG, NBIT_FIELD_W_MEMOFFSET)
    if bit_idx != NBIT_GLOBAL_CFG:  # Check configuration size
        logging.error("Number of bits for global configuration")
        exit(1)

    bit_idx = (
        NWORD_GLOBAL_CONFIG * NBIT_MEMBUFF_WORD
    )  # Move pointer to beginning of layers configuration

    nbytes_required = bit_idx // 8
    nwords_required = int(np.ceil(nbytes_required / (NBIT_MEMBUFF_WORD / 8)))
    nnpa_model = nnpa_model[:nbytes_required]

    ### Patching the model size field (in bytes)
    ############################################
    modify_field(nnpa_model, NBIT_FIELD_MODEL_ID, nwords_required, NBIT_FIELD_MODEL_SIZE)

    ### Patching the model ID/CRC field
    ###################################
    modelId = calc_crc_id(nnpa_model, NNPA_CRC_POLY, NNPA_CRC_INIT)
    modify_field(nnpa_model, 0, modelId, NBIT_FIELD_MODEL_ID)

    logging.info("Model ID is 0x%04X" % modelId)

    ## Write the NNPA model description
    ###################################
    fname = "./dummy_%d_%d_%d.nnpa" % (iw, ih, ic)
    try:
        f_out = open(fname, "w")
    except IOError:
        logging.error("Unable to open " + fname + " in write mode!")
        exit(1)

    logging.info("Writing file " + fname)
    nnpa_model.tofile(f_out)
    f_out.close()


def main(
    model: Union[str, list],
    ip_path: Optional[str] = None,
    nbuff: int = N_BUFF_DEFAULT,
    nwordbuff: int = NWORD_BUFF_DEFAULT,
    sfin: int = 255,
    offin: int = 0,
    bn_epsilon: float = 0.001,
    verbose: bool = False,
) -> bool:
    if DEBUG_LOGS:
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    ## Initializations
    ##################
    logging.info("Running extractor...")
    logging.info(
        "The layers supported for Colibry are: Pointwise & Depthwise Convolution , Dense , BatchNormalization, Linear/ReLU Activation, Average/Max/GlobalAverage Pooling , Add layers"
    )
    totalCycles = 0
    if isinstance(model, list):
        nnMembuffData = 0
        float_mode = True
        all_layers = model
        weights_dtype = all_layers[0]["weights"].dtype
        if np.issubdtype(weights_dtype, np.integer):
            float_mode = False

    if isinstance(model, str):
        if model.endswith(".tflite"):
            tflitemodel_extractor = TFLiteModelExtractor(
                model,
                quantNumbits=NBIT_DATA,
                biasNumbits=NBIT_BIAS,
                scalingNumbits=NBIT_SCALING,
                scalingExpMax=SCALING_EXP_MAX,
            )
            all_layers = tflitemodel_extractor.extract()
            float_mode = False
        elif model.endswith(".onnx"):
            onnxmodel_extractor = ONNXModelExtractor(
                model,
                quantNumbits=NBIT_DATA,
                biasNumbits=NBIT_BIAS,
                scalingNumbits=NBIT_SCALING,
                scalingExpMax=SCALING_EXP_MAX,
            )
            all_layers = onnxmodel_extractor.extract()
            float_mode = not onnxmodel_extractor.is_quantized_model()
        else:
            tfmodel = load_model(model)
            # tfmodel.summary()
            tfmodel_extractor = TFmodelExtractor(
                tfmodel,
                quantNumbits=NBIT_DATA,
                biasNumbits=NBIT_BIAS,
                scalingNumbits=NBIT_SCALING,
                scalingExpMax=SCALING_EXP_MAX,
                bnEpsilon=bn_epsilon,
            )

            ## In case input model is not QAT, export a float model
            float_mode = not tfmodel_extractor.is_quantized_model()
            all_layers = tfmodel_extractor.extract()
    *_, totalCycles, maxNwordData, nnMembuffData = get_model_metrics(all_layers, verbose)
    logging.info("Inference requires %d data words %d data buffer." % (maxNwordData, nnMembuffData))
    # print(all_layers)

    if float_mode:
        logging.warning(
            "Float input model detected. NNPA converted will output a 'float' version which cannot be "
            + "run on hardware target"
        )

    if DEBUG_LOGS:
        logging.info("\nExtracted layers information:")
        print_model_info(all_layers)

    ## NNPA model description: bitstream content of the cfgMem
    if float_mode:  # Export a float weights model
        nnpa_model = np.zeros(4 * MAX_MODEL_SIZE, dtype="uint8")
    else:
        nnpa_model = np.zeros(MAX_MODEL_SIZE, dtype="uint8")

    ## Do some checks
    #################
    if NBIT_MEMBANK_WORD % 8 != 0:
        logging.error("NBIT_MEMBANK_WORD shall be multiple of 8")
        raise ValueError(f"{NBIT_MEMBANK_WORD} % 8 != 0 with {NBIT_MEMBANK_WORD=}")

    if NBIT_WEIGHT != 8:
        logging.error("Currently only 8-bit weights is supported")
        raise ValueError(f"{NBIT_WEIGHT} != 8 with {NBIT_WEIGHT=}")

    ## Generate Global configuration (GLOBAL_CFG)
    #############################################
    bit_idx = 0
    n_layers = len(all_layers)
    activation_type = {
        "relu": ACTIVATION_RELU,
        "linear": ACTIVATION_NONE,
        "softmax": ACTIVATION_SOFTMAX,
        "sigmoid": ACTIVATION_SIGMOID,
    }

    hw_activation = {"relu": ACTIVATION_RELU, "linear": ACTIVATION_NONE}

    input_flattened = 1 if all_layers[0]["type"] == "dense" else 0

    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_MODEL_ID)  # Field set afterwards
    bit_idx = add_field(nnpa_model, bit_idx, 0, NBIT_FIELD_MODEL_SIZE)  # Field set afterwards
    if input_flattened == 0:
        input_pack_nb = max(1, int(np.floor(N_MIPE / all_layers[0]["ifmap_depth"])))
        nn_in_words = ceilDiv(
            ceilDiv(all_layers[0]["ifmap_width"], MIPE_PAR)
            * ceilDiv(all_layers[0]["ifmap_depth"], N_MIPE)
            * all_layers[0]["ifmap_height"],
            input_pack_nb,
        )
    else:
        nn_in_words = ceilDiv(
            all_layers[0]["ifmap_width"]
            * all_layers[0]["ifmap_depth"]
            * all_layers[0]["ifmap_height"],
            N_MIPE * MIPE_PAR,
        )
    bit_idx = add_field(nnpa_model, bit_idx, nn_in_words, NBIT_FIELD_FMAP_SIZE)
    max_data_words = 2**NBIT_FIELD_FMAP_SIZE - 1  # TODO: to be calculated from the model
    bit_idx = add_field(nnpa_model, bit_idx, max_data_words, NBIT_FIELD_FMAP_SIZE)
    bit_idx = add_field(nnpa_model, bit_idx, n_layers, NBIT_FIELD_N_LAYER)
    bit_idx = add_field(
        nnpa_model, bit_idx, all_layers[0]["ifmap_width"] - 1, NBIT_FIELD_INPUT_SIZE_X
    )
    bit_idx = add_field(
        nnpa_model, bit_idx, all_layers[0]["ifmap_height"] - 1, NBIT_FIELD_INPUT_SIZE_Y
    )
    bit_idx = add_field(
        nnpa_model, bit_idx, all_layers[0]["ifmap_depth"] - 1, NBIT_FIELD_INPUT_SIZE_Z
    )
    input_pack_lvl = max(0, int(np.floor(np.log2(N_MIPE / all_layers[0]["ifmap_depth"]))))
    bit_idx = add_field(nnpa_model, bit_idx, input_pack_lvl, NBIT_FIELD_PACK_LVL)
    bit_idx = add_field(nnpa_model, bit_idx, input_flattened, 1)
    bit_idx = add_field(nnpa_model, bit_idx, all_layers[0]["nnInputDataZero"], NBIT_DATA)
    bit_idx = add_field(
        nnpa_model, bit_idx, all_layers[-1]["ofmap_width"] - 1, NBIT_FIELD_OUT_SIZE_X
    )
    bit_idx = add_field(
        nnpa_model, bit_idx, all_layers[-1]["ofmap_height"] - 1, NBIT_FIELD_OUT_SIZE_Y
    )
    bit_idx = add_field(
        nnpa_model, bit_idx, all_layers[-1]["ofmap_depth"] - 1, NBIT_FIELD_OUT_SIZE_Z
    )
    output_pack_lvl = (
        0
        if all_layers[0]["flattenedOutput"] == 1
        else max(0, int(np.floor(np.log2(N_MIPE / all_layers[-1]["ofmap_depth"]))))
    )
    bit_idx = add_field(nnpa_model, bit_idx, output_pack_lvl, NBIT_FIELD_PACK_LVL)
    bit_idx = add_field(nnpa_model, bit_idx, all_layers[0]["flattenedOutput"], 1)
    scaling_out = int(np.round(all_layers[0]["outputScalingFloat"] * (2**NBIT_FIELD_SCALING_OUT)))
    bit_idx = add_field(nnpa_model, bit_idx, scaling_out, NBIT_FIELD_SCALING_OUT)
    zero_offset_out = int(
        np.round(all_layers[0]["outputZeroFloat"] * (2 ** (NBIT_FIELD_ZERO_OUT - 8)))
    )
    bit_idx = add_field(nnpa_model, bit_idx, zero_offset_out, NBIT_FIELD_ZERO_OUT)
    final_activation = activation_type.get(all_layers[-1]["activation"], ACTIVATION_UNKNOWN)
    if final_activation == ACTIVATION_UNKNOWN:
        logging.warning(
            "Unknown activation '%s'. TF model cannot be compared" % all_layers[-1]["activation"]
        )
    bit_idx = add_field(nnpa_model, bit_idx, final_activation, NBIT_FIELD_LAST_ACTIVATION)

    ## Calculating the scaling factor and offset to be applied to raw input data
    print("sfin:", sfin)
    print("offin:", offin)
    rawMin = int((sfin * all_layers[0]["inputMin"]) - offin)
    rawMax = int((sfin * all_layers[0]["inputMax"]) - offin)
    raw_in_offset = (
        -rawMin if rawMin <= 0 else 2**NBIT_FIELD_OFFSET_DIN - rawMin
    )  # In 2's complement
    raw_in_scaling = round(
        2 ** (NBIT_FIELD_SCALING_DIN - NBIT_FIELD_SCALING_DIN_INT)
        * (2**NBIT_DATA - 1)
        / (rawMax - rawMin)
    )
    if raw_in_scaling > 2**NBIT_FIELD_SCALING_DIN - 1:
        raw_in_scaling = 2**NBIT_FIELD_SCALING_DIN - 1
    bit_idx = add_field(nnpa_model, bit_idx, raw_in_scaling, NBIT_FIELD_SCALING_DIN)
    bit_idx = add_field(nnpa_model, bit_idx, raw_in_offset, NBIT_FIELD_OFFSET_DIN)

    weights_mem_offset = NWORD_GLOBAL_CONFIG + int(
        np.ceil(n_layers * NBANKWORD_LAYER_CONFIG / MIPE_PAR)
    )
    bit_idx = add_field(nnpa_model, bit_idx, weights_mem_offset, NBIT_FIELD_W_MEMOFFSET)

    if bit_idx != NBIT_GLOBAL_CFG:  # Check configuration size
        logging.error("Number of bits for global configuration")
        raise ValueError(f"bit_idx != NBIT_GLOBAL_CFG with {bit_idx=}, {NBIT_GLOBAL_CFG=}")

    bit_idx = (
        NWORD_GLOBAL_CONFIG * NBIT_MEMBUFF_WORD
    )  # Move pointer to beginning of layers configuration

    # print(NBIT_GLOBAL_CFG, NBIT_CONV_CFG, NBIT_POOL_CFG, NBIT_FC_CFG)
    # print(NBIT_LAYER_CFG, NWORD_GLOBAL_CONFIG, NBANKWORD_LAYER_CONFIG)

    ## Generate config for all layers
    #################################
    prev_ofmap_width = all_layers[0]["ifmap_width"]
    prev_ofmap_depth = all_layers[0]["ifmap_depth"]
    prev_type = all_layers[0]["type"]

    for layer_i, cfg in enumerate(all_layers):
        start_bit_idx = bit_idx
        if cfg["type"] == "conv" or cfg["type"] == "conv_dw":
            bit_idx = add_field(nnpa_model, bit_idx, CONV_LAYER, NBIT_FIELD_LAYER_TYPE)
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["kernel_size_x"] - 1, NBIT_FIELD_KERNEL_SIZE
            )
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["kernel_size_y"] - 1, NBIT_FIELD_KERNEL_SIZE
            )
            bit_idx = add_field(nnpa_model, bit_idx, cfg["stride_x"] - 1, NBIT_FIELD_STRIDE)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["stride_y"] - 1, NBIT_FIELD_STRIDE)
            bit_idx = add_field(
                nnpa_model, bit_idx, int(cfg["padding"] == "same"), NBIT_FIELD_PADDING_MODE
            )
            if cfg["padding"] == "valid":
                pad_x = 0
                pad_y = 0
            else:
                pad_x = max(
                    (cfg["ofmap_width"] - 1) * cfg["stride_x"]
                    - cfg["ifmap_width"]
                    + cfg["kernel_size_x"],
                    0,
                )
                pad_y = max(
                    (cfg["ofmap_height"] - 1) * cfg["stride_y"]
                    - cfg["ifmap_height"]
                    + cfg["kernel_size_y"],
                    0,
                )
            bit_idx = add_field(nnpa_model, bit_idx, pad_x // 2, NBIT_FIELD_PADDING)
            bit_idx = add_field(nnpa_model, bit_idx, (pad_x + 1) // 2, NBIT_FIELD_PADDING)
            bit_idx = add_field(nnpa_model, bit_idx, pad_y // 2, NBIT_FIELD_PADDING)
            bit_idx = add_field(nnpa_model, bit_idx, (pad_y + 1) // 2, NBIT_FIELD_PADDING)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_width"] - 1, NBIT_FIELD_OUT_SIZE_X)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_height"] - 1, NBIT_FIELD_OUT_SIZE_Y)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_depth"] - 1, NBIT_FIELD_OUT_SIZE_Z)
            bit_idx = add_field(nnpa_model, bit_idx, int(cfg["type"] == "conv_dw"), 1)
            bit_idx = add_field(
                nnpa_model,
                bit_idx,
                hw_activation.get(cfg["activation"], ACTIVATION_NONE),
                NBIT_FIELD_ACTIVATION,
            )
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["scaling_factor"], NBIT_FIELD_SCALING_FACTOR
            )
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["scaling_exponent"], NBIT_FIELD_SCALING_EXPONENT
            )
            bit_idx = add_field(nnpa_model, bit_idx, cfg["weights_zero"], NBIT_WEIGHT)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_zero"], NBIT_DATA)
            dm_row_addr_incr = int(
                math.ceil(cfg["ifmap_width"] / MIPE_PAR) * math.ceil(cfg["ifmap_depth"] / N_MIPE)
            )
            bit_idx = add_field(nnpa_model, bit_idx, dm_row_addr_incr, NBIT_FIELD_ROW_INCR)
            pack_lvl = max(0, int(np.floor(np.log2(N_MIPE / cfg["ofmap_depth"]))))
            bit_idx = add_field(nnpa_model, bit_idx, pack_lvl, NBIT_FIELD_PACK_LVL)
            lay_ofmap_size = ceilDiv(
                ceilDiv(cfg["ofmap_width"], MIPE_PAR)
                * ceilDiv(cfg["ofmap_depth"], N_MIPE)
                * cfg["ofmap_height"],
                2**pack_lvl,
            )
            bit_idx = add_field(nnpa_model, bit_idx, lay_ofmap_size, NBIT_FIELD_FMAP_SIZE)
            bit_idx = add_field(
                nnpa_model, bit_idx, check_skip_refname(cfg["refname"], all_layers), 1
            )
            bit_idx = add_field(nnpa_model, bit_idx, check_forked_layer(layer_i, all_layers), 1)
            if cfg["ifmap_source_idx"] >= 0 and cfg["ifmap_source_idx"] + 1 != layer_i:
                bit_idx = add_field(nnpa_model, bit_idx, 1, 1)  # Ifmap from forked layer
            else:
                bit_idx = add_field(nnpa_model, bit_idx, 0, 1)  # Ifmap from previous layer

            if bit_idx - start_bit_idx != NBIT_CONV_CFG:  # Check configuration size
                logging.error("Number of bits for CONV configuration")
                raise ValueError(
                    f"bit_idx - start_bit_idx != NBIT_CONV_CFG with {bit_idx=} {start_bit_idx=} {NBIT_CONV_CFG=}"
                )

        elif cfg["type"] == "max_pool" or cfg["type"] == "avg_pool":
            bit_idx = add_field(nnpa_model, bit_idx, POOL_LAYER, NBIT_FIELD_LAYER_TYPE)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["pool_size_x"] - 1, NBIT_FIELD_KERNEL_SIZE)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["pool_size_y"] - 1, NBIT_FIELD_KERNEL_SIZE)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["stride_x"] - 1, NBIT_FIELD_STRIDE)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["stride_y"] - 1, NBIT_FIELD_STRIDE)
            bit_idx = add_field(
                nnpa_model, bit_idx, int(cfg["padding"] == "same"), NBIT_FIELD_PADDING_MODE
            )
            if cfg["padding"] == "valid":
                pad_x = 0
                pad_y = 0
            else:
                pad_x = (
                    (cfg["ofmap_width"] - 1) * cfg["stride_x"]
                    - cfg["ifmap_width"]
                    + cfg["pool_size_x"]
                )
                pad_y = (
                    (cfg["ofmap_height"] - 1) * cfg["stride_y"]
                    - cfg["ifmap_height"]
                    + cfg["pool_size_y"]
                )
            bit_idx = add_field(nnpa_model, bit_idx, pad_x // 2, NBIT_FIELD_PADDING)
            bit_idx = add_field(nnpa_model, bit_idx, (pad_x + 1) // 2, NBIT_FIELD_PADDING)
            bit_idx = add_field(nnpa_model, bit_idx, pad_y // 2, NBIT_FIELD_PADDING)
            bit_idx = add_field(nnpa_model, bit_idx, (pad_y + 1) // 2, NBIT_FIELD_PADDING)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_width"] - 1, NBIT_FIELD_OUT_SIZE_X)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_height"] - 1, NBIT_FIELD_OUT_SIZE_Y)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_depth"] - 1, NBIT_FIELD_OUT_SIZE_Z)
            bit_idx = add_field(
                nnpa_model, bit_idx, int(cfg["type"] == "avg_pool"), NBIT_FIELD_POOL_TYPE
            )
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["scaling_factor"], NBIT_FIELD_SCALING_FACTOR
            )
            dm_row_addr_incr = int(
                math.ceil(cfg["ifmap_width"] / MIPE_PAR) * math.ceil(cfg["ifmap_depth"] / N_MIPE)
            )
            bit_idx = add_field(nnpa_model, bit_idx, dm_row_addr_incr, NBIT_FIELD_ROW_INCR)
            pack_lvl = max(0, int(np.floor(np.log2(N_MIPE / cfg["ofmap_depth"]))))
            bit_idx = add_field(nnpa_model, bit_idx, pack_lvl, NBIT_FIELD_PACK_LVL)
            lay_ofmap_size = ceilDiv(
                ceilDiv(cfg["ofmap_width"], MIPE_PAR)
                * ceilDiv(cfg["ofmap_depth"], N_MIPE)
                * cfg["ofmap_height"],
                2**pack_lvl,
            )
            bit_idx = add_field(nnpa_model, bit_idx, lay_ofmap_size, NBIT_FIELD_FMAP_SIZE)
            bit_idx = add_field(
                nnpa_model, bit_idx, check_skip_refname(cfg["refname"], all_layers), 1
            )
            bit_idx = add_field(nnpa_model, bit_idx, check_forked_layer(layer_i, all_layers), 1)
            if cfg["ifmap_source_idx"] >= 0 and cfg["ifmap_source_idx"] + 1 != layer_i:
                bit_idx = add_field(nnpa_model, bit_idx, 1, 1)  # Ifmap from forked layer
            else:
                bit_idx = add_field(nnpa_model, bit_idx, 0, 1)  # Ifmap from previous layer

            if bit_idx - start_bit_idx != NBIT_POOL_CFG:  # Check configuration size
                logging.error("Number of bits for POOL configuration")
                raise ValueError(
                    f"bit_idx - start_bit_idx != NBIT_POOL_CFG with {bit_idx=} {start_bit_idx=} {NBIT_POOL_CFG=}"
                )

        elif cfg["type"] == "dense":
            bit_idx = add_field(nnpa_model, bit_idx, FC_LAYER, NBIT_FIELD_LAYER_TYPE)
            n_input = cfg["ifmap_width"] * cfg["ifmap_height"] * cfg["ifmap_depth"]
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_depth"] - 1, NBIT_FIELD_FC_N_OUTPUT)
            bit_idx = add_field(
                nnpa_model,
                bit_idx,
                hw_activation.get(cfg["activation"], ACTIVATION_NONE),
                NBIT_FIELD_ACTIVATION,
            )
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["scaling_factor"], NBIT_FIELD_SCALING_FACTOR
            )
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["scaling_exponent"], NBIT_FIELD_SCALING_EXPONENT
            )
            bit_idx = add_field(nnpa_model, bit_idx, cfg["weights_zero"], NBIT_WEIGHT)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_zero"], NBIT_DATA)
            nweight_last_grp = (
                N_MIPE if cfg["ofmap_depth"] % N_MIPE == 0 else cfg["ofmap_depth"] % N_MIPE
            )
            weight_pack_lvl = int(np.floor(np.log2(N_MIPE / nweight_last_grp)))
            wm_last_grp_incr = ceilDiv(
                ceilDiv(n_input + NWEIGHT_BIAS, 2**weight_pack_lvl), MIPE_PAR
            )
            bit_idx = add_field(nnpa_model, bit_idx, wm_last_grp_incr, NBIT_FIELD_INPUT_SIZE_Y)
            bit_idx = add_field(nnpa_model, bit_idx, weight_pack_lvl, NBIT_FIELD_PACK_LVL)
            dm_row_addr_incr = int(
                math.ceil(prev_ofmap_width / MIPE_PAR) * math.ceil(prev_ofmap_depth / N_MIPE)
            )
            bit_idx = add_field(nnpa_model, bit_idx, dm_row_addr_incr, NBIT_FIELD_ROW_INCR)
            lay_ofmap_size = ceilDiv(cfg["ofmap_depth"], N_MIPE * MIPE_PAR)
            bit_idx = add_field(nnpa_model, bit_idx, lay_ofmap_size, NBIT_FIELD_FMAP_SIZE)
            bit_idx = add_field(
                nnpa_model, bit_idx, check_skip_refname(cfg["refname"], all_layers), 1
            )
            bit_idx = add_field(nnpa_model, bit_idx, check_forked_layer(layer_i, all_layers), 1)
            if cfg["ifmap_source_idx"] >= 0 and cfg["ifmap_source_idx"] + 1 != layer_i:
                bit_idx = add_field(nnpa_model, bit_idx, 1, 1)  # Ifmap from forked layer
            else:
                bit_idx = add_field(nnpa_model, bit_idx, 0, 1)  # Ifmap from previous layer

            if bit_idx - start_bit_idx != NBIT_FC_CFG:  # Check configuration size
                logging.error("Number of bits for FC configuration")
                raise ValueError(
                    f"bit_idx - start_bit_idx != NBIT_FC_CFG with {bit_idx=} {start_bit_idx=} {NBIT_FC_CFG=}"
                )

        elif cfg["type"] == "add":
            bit_idx = add_field(nnpa_model, bit_idx, ADD_LAYER, NBIT_FIELD_LAYER_TYPE)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["bias"], NBIT_BIAS)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["weight1"], NBIT_WEIGHT)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["weight2"], NBIT_WEIGHT)
            dm_row_addr_incr = int(
                math.ceil(cfg["ifmap_width"] / MIPE_PAR) * math.ceil(cfg["ifmap_depth"] / N_MIPE)
            )
            bit_idx = add_field(nnpa_model, bit_idx, dm_row_addr_incr, NBIT_FIELD_ROW_INCR)
            bit_idx = add_field(
                nnpa_model,
                bit_idx,
                hw_activation.get(cfg["activation"], ACTIVATION_NONE),
                NBIT_FIELD_ACTIVATION,
            )
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["scaling_factor"], NBIT_FIELD_SCALING_FACTOR
            )
            bit_idx = add_field(
                nnpa_model, bit_idx, cfg["scaling_exponent"], NBIT_FIELD_SCALING_EXPONENT
            )
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_zero"], NBIT_DATA)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_width"] - 1, NBIT_FIELD_OUT_SIZE_X)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_height"] - 1, NBIT_FIELD_OUT_SIZE_Y)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_depth"] - 1, NBIT_FIELD_OUT_SIZE_Z)
            pack_lvl = max(0, int(np.floor(np.log2(N_MIPE / cfg["ofmap_depth"]))))
            bit_idx = add_field(nnpa_model, bit_idx, pack_lvl, NBIT_FIELD_PACK_LVL)
            lay_ofmap_size = int(
                ceilDiv(cfg["ofmap_width"], MIPE_PAR)
                * ceilDiv(cfg["ofmap_depth"], N_MIPE)
                * cfg["ofmap_height"]
            )
            bit_idx = add_field(nnpa_model, bit_idx, lay_ofmap_size, NBIT_FIELD_FMAP_SIZE)
            bit_idx = add_field(
                nnpa_model, bit_idx, check_skip_refname(cfg["refname"], all_layers), 1
            )
            bit_idx = add_field(nnpa_model, bit_idx, check_forked_layer(layer_i, all_layers), 1)
            bit_idx = add_field(nnpa_model, bit_idx, 0, 1)  # Ifmap from previous layer

            if bit_idx - start_bit_idx != NBIT_ADD_CFG:  # Check configuration size
                logging.error("Number of bits for ADD configuration")
                raise ValueError(
                    f"bit_idx - start_bit_idx != NBIT_ADD_CFG with {bit_idx=} {start_bit_idx=} {NBIT_ADD_CFG=}"
                )
        elif cfg["type"] == "xten":
            bit_idx = add_field(nnpa_model, bit_idx, XTEN_LAYER, NBIT_FIELD_LAYER_TYPE)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["subtype"], NBIT_FIELD_LAYER_TYPE)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_width"] - 1, NBIT_FIELD_OUT_SIZE_X)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_height"] - 1, NBIT_FIELD_OUT_SIZE_Y)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_depth"] - 1, NBIT_FIELD_OUT_SIZE_Z)
            pack_lvl = max(0, int(np.floor(np.log2(N_MIPE / cfg["ofmap_depth"]))))
            bit_idx = add_field(nnpa_model, bit_idx, pack_lvl, NBIT_FIELD_PACK_LVL)
            bit_idx = add_field(nnpa_model, bit_idx, cfg["ofmap_zero"], NBIT_DATA)
            if cfg["same_ofmap"]:
                lay_ofmap_size = -1  # Special value to indicate the same fmap is reused
            else:
                lay_ofmap_size = int(
                    ceilDiv(cfg["ofmap_width"], MIPE_PAR)
                    * ceilDiv(cfg["ofmap_depth"], N_MIPE)
                    * cfg["ofmap_height"]
                )
            bit_idx = add_field(nnpa_model, bit_idx, lay_ofmap_size, NBIT_FIELD_FMAP_SIZE)
            weight_incr_words = ceilDiv(np.size(cfg["weights"]), N_MIPE * MIPE_PAR)
            bit_idx = add_field(nnpa_model, bit_idx, weight_incr_words, NBIT_FIELD_WEIGHT_INCR)
            bit_idx = add_field(
                nnpa_model, bit_idx, check_skip_refname(cfg["refname"], all_layers), 1
            )
            bit_idx = add_field(nnpa_model, bit_idx, check_forked_layer(layer_i, all_layers), 1)
            if cfg["ifmap_source_idx"] >= 0 and cfg["ifmap_source_idx"] + 1 != layer_i:
                bit_idx = add_field(nnpa_model, bit_idx, 1, 1)  # Ifmap from forked layer
            else:
                bit_idx = add_field(nnpa_model, bit_idx, 0, 1)  # Ifmap from previous layer

        else:
            logging.error("Incompatible layer type (%s)" % cfg["type"])
            raise ValueError("Incompatible layer type (%s)" % cfg["type"])

        prev_ofmap_width = cfg["ofmap_width"]
        prev_ofmap_depth = cfg["ofmap_depth"]
        prev_type = cfg["type"]
        bit_idx = start_bit_idx + NBIT_LAYER_CFG  # Move pointer to next config
        nbit_remain = NBIT_MEMBANK_WORD - (bit_idx % NBIT_MEMBANK_WORD)
        if nbit_remain < NBIT_LAYER_CFG:
            bit_idx += nbit_remain  # Jump to next cfgMem word

    ## Create the Weights part of CFGMEM
    ####################################
    weights_list = []  # Weights ordered as in CFGMEM

    for cfg in all_layers:
        if (
            cfg["type"] != "conv"
            and cfg["type"] != "conv_dw"
            and cfg["type"] != "dense"
            and cfg["type"] != "xten"
        ):
            continue  # Layer without weights

        ## DEBUG
        # hack_weights(cfg)
        # print(cfg['biases'])
        # print(cfg['weights'])

        ## Split biases into multiple weights
        if np.size(cfg["biases"]) > 0:
            biases_split = np.zeros((cfg["biases"].size, NWEIGHT_BIAS))
            for i in range(cfg["biases"].size):
                for j in range(NWEIGHT_BIAS):
                    if float_mode:
                        biases_split[i][j] = cfg["biases"][i]
                    else:
                        biases_split[i][j] = (int(cfg["biases"][i]) >> (NBIT_WEIGHT * j)) & int(
                            2**NBIT_WEIGHT - 1
                        )

        if cfg["type"] == "conv" or cfg["type"] == "conv_dw":
            n_output = cfg["weights"].shape[3]
            n_groups = ceilDiv(n_output, N_MIPE)
            for group_cnt in range(n_groups):
                group_size = min(N_MIPE, n_output - group_cnt * N_MIPE)
                ## Biases
                for in_cnt in range(NWEIGHT_BIAS):
                    for f in range(group_size):
                        weights_list.append(biases_split[f + N_MIPE * group_cnt][in_cnt])
                    weights_list += [0] * remain_count(len(weights_list), N_MIPE)
                ## Weights
                for y in range(cfg["weights"].shape[0]):
                    for x in range(cfg["weights"].shape[1]):
                        for z in range(cfg["weights"].shape[2]):
                            for f in range(group_size):
                                weights_list.append(cfg["weights"][y][x][z][f + N_MIPE * group_cnt])
                            weights_list += [0] * remain_count(len(weights_list), N_MIPE)

        elif cfg["type"] == "dense":
            n_output = cfg["weights"].shape[1]
            n_groups = ceilDiv(n_output, N_MIPE)
            for group_cnt in range(n_groups):
                memword = [[], []]
                banksel = 0
                group_size = min(N_MIPE, n_output - (group_cnt * N_MIPE))
                ngroup_per_bank = N_MIPE // group_size
                npad_per_group = (N_MIPE // ngroup_per_bank) - group_size

                for in_cnt in range(NWEIGHT_BIAS + cfg["weights"].shape[0]):
                    for out_cnt in range(group_size):
                        if in_cnt < NWEIGHT_BIAS:
                            memword[banksel].append(
                                biases_split[out_cnt + N_MIPE * group_cnt][in_cnt]
                            )
                        else:
                            memword[banksel].append(
                                cfg["weights"][in_cnt - NWEIGHT_BIAS][out_cnt + N_MIPE * group_cnt]
                            )

                    for out_cnt in range(npad_per_group):
                        memword[banksel].append(0)

                    if (
                        remain_count(len(memword[MIPE_PAR - 1]), N_MIPE) < group_size
                    ):  # Current word is full
                        for i in range(MIPE_PAR):
                            weights_list += zero_pad(memword[i], N_MIPE)
                        memword = [[], []]

                    banksel = (banksel + 1) % MIPE_PAR

                if len(memword[0]) > 0:  # End of group, write word and restart at word boundary
                    weights_list += zero_pad(memword[0], N_MIPE) + zero_pad(memword[1], N_MIPE)

        elif cfg["type"] == "xten":
            for _, w in np.ndenumerate(cfg["weights"]):
                weights_list += [w]
            weights_list += [0] * remain_count(len(weights_list), N_MIPE)

        ## New layer: restart at word boundary
        weights_list += [0] * remain_count(len(weights_list), N_MIPE * MIPE_PAR)

    if DEBUG_LOGS:
        show_cfgmem(weights_list, float_mode)

    ## Appends Weights to NNPA model description
    #############################################
    weight_byte_start = weights_mem_offset * NBIT_MEMBUFF_WORD // 8
    byte_idx = 0
    try:
        if float_mode:
            for i in range(len(weights_list)):
                for j, byte in enumerate(bytearray(struct.pack("f", weights_list[i]))):
                    byte_idx = 4 * (weight_byte_start + i) + j
                    nnpa_model[byte_idx] = byte
        else:
            for i in range(len(weights_list)):
                byte_idx = weight_byte_start + i
                nnpa_model[byte_idx] = int(weights_list[i]) & 0xFF
    except IndexError as e:
        logging.error("The NNPA model exceeds the 1 MByte limit. Exiting... \n")
        raise ValueError(e)

    ## Check model is fitting in memory
    ###################################
    nbytes_required = byte_idx + 1
    nwords_required = int(np.ceil(nbytes_required / (NBIT_MEMBUFF_WORD / 8)))
    if float_mode:  # Do as if one int8 <=> one float
        nwords_required = (nwords_required + 3) // 4
    nbuffers_required = int(np.ceil((nwords_required / nwordbuff)))

    if nbuffers_required > nbuff:
        logging.error(
            "The NNPA model configuration exceeds the number of available buffer!\n"
            + "     %d memory buffers are required to store the model." % nbuffers_required
        )
        raise ValueError(f"nbuffers_required > nbuff, with {nbuffers_required=} {nbuff=}")
    else:
        logging.info(
            "The NNPA model configuration uses %d bytes, %d words, %d buffers."
            % (nbytes_required, nwords_required, nbuffers_required)
        )
        logging.info("Inference requires %d cycles" % (totalCycles))

        if nnMembuffData + nbuffers_required <= 40:
            logging.info("The NNPA model configuation + data fits the Colibry memory constraints")
            logging.info("Start Evaluating the NNPA model on VWW Person Classification dataset")
        else:
            logging.error(
                "The NNPA model configuration + NN data exceeds the Colibry memory constraints"
            )
            raise ValueError(
                f"nnMembuffData + nbuffers_required > 40 with {nnMembuffData=} {nbuffers_required=}"
            )

    nnpa_model = nnpa_model[:nbytes_required]

    ### Patching the model size field (in bytes)
    ############################################
    modify_field(nnpa_model, NBIT_FIELD_MODEL_ID, nwords_required, NBIT_FIELD_MODEL_SIZE)

    ### Patching the model ID/CRC field
    ###################################
    modelId = calc_crc_id(nnpa_model, NNPA_CRC_POLY, NNPA_CRC_INIT)
    modify_field(nnpa_model, 0, modelId, NBIT_FIELD_MODEL_ID)

    logging.info("Model ID is 0x%04X" % modelId)

    ## Write the NNPA model description
    ###################################
    if model[-1] == "/":
        modelPath = model[:-1]
    elif isinstance(model, str):
        if model.rfind(".hdf5") > 0:
            modelPath = model[: model.rfind(".hdf5")]
        else:
            modelPath = model
    elif isinstance(model, list):
        modelPath = os.path.join(os.getcwd(), "aidge_model_bitstream")

    try:
        if float_mode:
            fname = modelPath + "_float.nnpa"
        else:
            fname = modelPath + ".nnpa"
        f_out = open(fname, "w")
    except IOError as e:
        logging.error("Unable to open " + fname + " in write mode!")
        raise e

    logging.info("Writing file " + fname)
    nnpa_model.tofile(f_out)
    f_out.close()

    if ip_path is None:
        logging.warning("Path to NNPA IP folder not specified. Files of constants not updated!")
    else:
        write_python(ip_path, nbuff, nwordbuff)
        write_verilog(ip_path, nbuff, nwordbuff)
        write_hpp(ip_path, nbuff, nwordbuff)

    return float_mode


def write_python(ip_path, nbuff, nwordbuff):
    """
    Write file of constants for Python model
    """
    try:
        fname = ip_path + "/" + PY_MODEL_CONST_FILE
        f_out = open(fname, "w")
    except IOError as e:
        logging.error("Unable to open " + fname + " in write mode!")
        raise e

    logging.info("Writing file " + fname)

    f_out.write(
        "## This file has been generated by the NNPA Compiler Tool and should not be modified manually!"
    )
    f_out.write("\n")
    f_out.write("from dataclasses import dataclass\nfrom typing import Final\n")
    f_out.write("\n")
    f_out.write("@dataclass\nclass NNPAConstants:")

    f_out.write("\n")
    f_out.write("    MIPE_PAR: Final[int] = %d\n" % MIPE_PAR)
    f_out.write("    N_MIPE: Final[int] = %d\n" % N_MIPE)
    f_out.write("    MIPE_N_PAR_MUL: Final[int] = %d\n" % (MIPE_PAR * N_MIPE))
    f_out.write("    NBIT_WEIGHT: Final[int] = %d\n" % NBIT_WEIGHT)
    f_out.write("    NBIT_BIAS: Final[int] = %d\n" % NBIT_BIAS)
    f_out.write("    NBIT_DATA: Final[int] = %d\n" % NBIT_DATA)
    f_out.write("    DATA_MASK: Final[int] = %d\n" % (2**NBIT_DATA - 1))
    f_out.write("    NBIT_MAC: Final[int] = %d\n" % NBIT_MAC)
    f_out.write("    NBIT_SCALING: Final[int] = %d\n" % NBIT_SCALING)
    f_out.write("    SCALING_EXP_MAX: Final[int] = %d\n" % SCALING_EXP_MAX)
    f_out.write("\n")
    f_out.write("    N_MEM_BUFF: Final[int] = %d\n" % nbuff)
    f_out.write("    NWORD_MEM_BUFF: Final[int] = %d\n" % nwordbuff)
    f_out.write("\n")
    f_out.write("    CONV_LAYER: Final[int] = %d\n" % CONV_LAYER)
    f_out.write("    POOL_LAYER: Final[int] = %d\n" % POOL_LAYER)
    f_out.write("    FC_LAYER: Final[int] = %d\n" % FC_LAYER)
    f_out.write("    ADD_LAYER: Final[int] = %d\n" % ADD_LAYER)
    f_out.write("    XTEN_LAYER: Final[int] = %d\n" % XTEN_LAYER)
    f_out.write("    PADDING_VALID: Final[int] = %d\n" % PADDING_VALID)
    f_out.write("    PADDING_SAME: Final[int] = %d\n" % PADDING_SAME)
    f_out.write("    POOL_TYPE_MAX: Final[int] = %d\n" % 0)
    f_out.write("    POOL_TYPE_AVG: Final[int] = %d\n" % 1)
    f_out.write("    ACTIVATION_NONE: Final[int] = %d\n" % ACTIVATION_NONE)
    f_out.write("    ACTIVATION_RELU: Final[int] = %d\n" % ACTIVATION_RELU)
    f_out.write("    ACTIVATION_SOFTMAX: Final[int] = %d\n" % ACTIVATION_SOFTMAX)
    f_out.write("    ACTIVATION_SIGMOID: Final[int] = %d\n" % ACTIVATION_SIGMOID)
    f_out.write("    ACTIVATION_UNKNOWN: Final[int] = %d\n" % ACTIVATION_UNKNOWN)
    f_out.write("\n")
    f_out.write("    NBIT_FIELD_MODEL_ID: Final[int] = %d\n" % NBIT_FIELD_MODEL_ID)
    f_out.write("    NBIT_FIELD_MODEL_SIZE: Final[int] = %d\n" % NBIT_FIELD_MODEL_SIZE)
    f_out.write("    NBIT_FIELD_FMAP_SIZE: Final[int] = %d\n" % NBIT_FIELD_FMAP_SIZE)
    f_out.write("    NBIT_FIELD_N_LAYER: Final[int] = %d\n" % NBIT_FIELD_N_LAYER)
    f_out.write("    NBIT_FIELD_SCALING_DIN: Final[int] = %d\n" % NBIT_FIELD_SCALING_DIN)
    f_out.write("    NBIT_FIELD_SCALING_DIN_INT: Final[int] = %d\n" % NBIT_FIELD_SCALING_DIN_INT)
    f_out.write("    NBIT_FIELD_OFFSET_DIN: Final[int] = %d\n" % NBIT_FIELD_OFFSET_DIN)
    f_out.write("    NBIT_FIELD_INPUT_SIZE_X: Final[int] = %d\n" % NBIT_FIELD_INPUT_SIZE_X)
    f_out.write("    NBIT_FIELD_INPUT_SIZE_Y: Final[int] = %d\n" % NBIT_FIELD_INPUT_SIZE_Y)
    f_out.write("    NBIT_FIELD_INPUT_SIZE_Z: Final[int] = %d\n" % NBIT_FIELD_INPUT_SIZE_Z)
    f_out.write("    NBIT_FIELD_ROW_INCR: Final[int] = %d\n" % NBIT_FIELD_ROW_INCR)
    f_out.write("    NBIT_FIELD_PACK_LVL: Final[int] = %d\n" % NBIT_FIELD_PACK_LVL)
    f_out.write("    NBIT_FIELD_W_MEMOFFSET: Final[int] = %d\n" % NBIT_FIELD_W_MEMOFFSET)
    f_out.write("    NBIT_FIELD_SCALING_OUT: Final[int] = %d\n" % NBIT_FIELD_SCALING_OUT)
    f_out.write("    NBIT_FIELD_ZERO_OUT: Final[int] = %d\n" % NBIT_FIELD_ZERO_OUT)
    f_out.write("    NBIT_FIELD_LAYER_TYPE: Final[int] = %d\n" % NBIT_FIELD_LAYER_TYPE)
    f_out.write("    NBIT_FIELD_OUT_SIZE_X: Final[int] = %d\n" % NBIT_FIELD_OUT_SIZE_X)
    f_out.write("    NBIT_FIELD_OUT_SIZE_Y: Final[int] = %d\n" % NBIT_FIELD_OUT_SIZE_Y)
    f_out.write("    NBIT_FIELD_OUT_SIZE_Z: Final[int] = %d\n" % NBIT_FIELD_OUT_SIZE_Z)
    f_out.write("    NBIT_FIELD_KERNEL_SIZE: Final[int] = %d\n" % NBIT_FIELD_KERNEL_SIZE)
    f_out.write("    NBIT_FIELD_STRIDE: Final[int] = %d\n" % NBIT_FIELD_STRIDE)
    f_out.write("    NBIT_FIELD_PADDING_MODE: Final[int] = %d\n" % NBIT_FIELD_PADDING_MODE)
    f_out.write("    NBIT_FIELD_PADDING: Final[int] = %d\n" % NBIT_FIELD_PADDING)
    f_out.write("    NBIT_FIELD_ACTIVATION: Final[int] = %d\n" % NBIT_FIELD_ACTIVATION)
    f_out.write("    NBIT_FIELD_LAST_ACTIVATION: Final[int] = %d\n" % NBIT_FIELD_LAST_ACTIVATION)
    f_out.write("    NBIT_FIELD_SCALING_FACTOR: Final[int] = %d\n" % NBIT_FIELD_SCALING_FACTOR)
    f_out.write("    NBIT_FIELD_SCALING_EXPONENT: Final[int] = %d\n" % NBIT_FIELD_SCALING_EXPONENT)
    f_out.write("    NBIT_FIELD_POOL_TYPE: Final[int] = %d\n" % NBIT_FIELD_POOL_TYPE)
    f_out.write("    NBIT_FIELD_FC_N_OUTPUT: Final[int] = %d\n" % NBIT_FIELD_FC_N_OUTPUT)
    f_out.write("    NBIT_FIELD_WEIGHT_INCR: Final[int] = %d\n" % NBIT_FIELD_WEIGHT_INCR)
    f_out.write("\n")
    f_out.write("    NWEIGHT_BIAS: Final[int] = %d\n" % NWEIGHT_BIAS)
    f_out.write("    FC_SWAP_BANKS: Final[int] = %d\n" % (NWEIGHT_BIAS % MIPE_PAR))
    f_out.write("    NBIT_MEMBUFF_WORD: Final[int] = %d\n" % NBIT_MEMBUFF_WORD)
    f_out.write("    NBIT_MEMBANK_WORD: Final[int] = %d\n" % NBIT_MEMBANK_WORD)
    f_out.write("    NBIT_GLOBAL_CFG: Final[int] = %d\n" % NBIT_GLOBAL_CFG)
    f_out.write("    NBIT_LAYER_CFG: Final[int] = %d\n" % NBIT_LAYER_CFG)
    f_out.write("    NWORD_GLOBAL_CONFIG: Final[int] = %d\n" % NWORD_GLOBAL_CONFIG)
    f_out.write("    NBANKWORD_LAYER_CONFIG: Final[int] = %d\n" % NBANKWORD_LAYER_CONFIG)
    f_out.close()


def write_verilog(ip_path, nbuff, nwordbuff):
    """
    Write file of constants for Verilog model
    """
    try:
        fname = ip_path + "/" + VLOG_CONST_FILE
        f_out = open(fname, "w")
    except IOError as e:
        logging.error("Unable to open " + fname + " in write mode!")
        raise e

    logging.info("Writing file " + fname)

    f_out.write(
        "// This file has been generated by the NNPA Compiler Tool and should not be modified manually!"
    )

    f_out.write("\n\n")
    f_out.write("`ifndef __nnpa_core_pkg__\n")
    f_out.write("`define __nnpa_core_pkg__\n")
    f_out.write("\n")
    f_out.write("localparam MIPE_PAR = %d;\n" % MIPE_PAR)
    f_out.write("localparam N_MIPE = %d;\n" % N_MIPE)
    f_out.write("localparam MIPE_N_PAR_MUL = %d;\n" % (MIPE_PAR * N_MIPE))
    f_out.write("localparam NBIT_WEIGHT = %d;\n" % NBIT_WEIGHT)
    f_out.write("localparam NBIT_BIAS = %d;\n" % NBIT_BIAS)
    f_out.write("localparam NBIT_DATA = %d;\n" % NBIT_DATA)
    f_out.write("localparam NBIT_MAC = %d;\n" % NBIT_MAC)
    f_out.write("localparam NBIT_SCALING = %d;\n" % NBIT_SCALING)
    f_out.write("localparam SCALING_EXP_MAX = %d;\n" % SCALING_EXP_MAX)
    f_out.write("localparam NBIT_SCALING_EXP = %d;\n" % NBIT_FIELD_SCALING_EXPONENT)
    f_out.write("localparam NSTEP_SCALING = %d;\n" % NSTEP_SCALING)
    f_out.write("localparam MIPE_INPUT_PP = %d;\n" % MIPE_INPUT_PP)
    f_out.write("\n")
    f_out.write("localparam N_MEM_BUFF = %d;\n" % nbuff)
    f_out.write("localparam NWORD_MEM_BUFF = %d;\n" % nwordbuff)
    f_out.write("localparam N_MEM_BANK = MIPE_PAR;\n")
    f_out.write("localparam NBIT_MEM_ADDR = %d;\n" % int(np.ceil(np.log2(nbuff * nwordbuff))))
    f_out.write("localparam NBIT_MEM_BANKSEL = %d;\n" % int(np.ceil(np.log2(MIPE_PAR))))
    f_out.write("localparam NBIT_MEM_BANK = %d;\n" % (NBIT_DATA * N_MIPE))
    f_out.write("localparam NBIT_MEM_WORD = %d;\n" % (NBIT_DATA * N_MIPE * MIPE_PAR))
    f_out.write(
        "localparam NBIT_DATA_CNT = %d;\n"
        % (NBIT_FIELD_FMAP_SIZE + int(np.ceil(np.log2(MIPE_PAR * N_MIPE))))
    )
    f_out.write("localparam NBYTE_PER_MEM_WORD = %d;\n" % (NBIT_DATA * N_MIPE * MIPE_PAR / 8))
    f_out.write("localparam NBYTE_PER_BANK_WORD = %d;\n" % (NBIT_DATA * N_MIPE / 8))
    f_out.write("localparam MEM_READ_LATENCY = %d;\n" % MEM_READ_LATENCY)
    f_out.write("localparam MEM_WRAP_ADDR = %d;\n" % (nbuff * nwordbuff))
    f_out.write("localparam NWORD_WEIGHTS_CACHE = %d;\n" % NWORD_WEIGHTS_CACHE)
    f_out.write(
        "localparam NWORD_WEIGHTS_CACHE_LOG2 = %d;\n" % int(np.ceil(np.log2(NWORD_WEIGHTS_CACHE)))
    )
    f_out.write("localparam NNPA_CRC_POLY = 'h%X;\n" % NNPA_CRC_POLY)
    f_out.write("localparam NNPA_CRC_INIT = 16'h%X;\n" % NNPA_CRC_INIT)
    f_out.write("\n")
    f_out.write("localparam MIPE_PAR_LOG2 = %d;\n" % int(np.ceil(np.log2(MIPE_PAR))))
    f_out.write("localparam MIPE_N_PAR_MUL_LOG2 = %d;\n" % int(np.ceil(np.log2(MIPE_PAR * N_MIPE))))
    f_out.write("localparam N_MIPE_LOG2 = %d;\n" % int(np.ceil(np.log2(N_MIPE))))
    f_out.write("localparam N_MIPE_GRP = %d;\n" % int(np.ceil(N_MIPE / MIPE_PAR)))
    f_out.write("localparam N_MIPE_GRP_LOG2 = %d;\n" % int(np.ceil(np.log2(N_MIPE / MIPE_PAR))))
    f_out.write("localparam N_WEIGHT_BIAS = %d;\n" % int(np.ceil(NBIT_BIAS / NBIT_WEIGHT)))
    f_out.write("localparam NBIT_ACTIVATION = %d;\n" % NBIT_FIELD_ACTIVATION)
    f_out.write("\n")
    f_out.write("localparam CONV_LAYER = %d;\n" % CONV_LAYER)
    f_out.write("localparam POOL_LAYER = %d;\n" % POOL_LAYER)
    f_out.write("localparam FC_LAYER = %d;\n" % FC_LAYER)
    f_out.write("localparam ADD_LAYER = %d;\n" % ADD_LAYER)
    f_out.write("localparam XTEN_LAYER = %d;\n" % XTEN_LAYER)
    f_out.write("localparam PADDING_VALID = %d;\n" % PADDING_VALID)
    f_out.write("localparam PADDING_SAME = %d;\n" % PADDING_SAME)
    f_out.write("localparam POOL_TYPE_MAX = %d;\n" % 0)
    f_out.write("localparam POOL_TYPE_AVG = %d;\n" % 1)
    f_out.write("localparam ACTIVATION_NONE = %d;\n" % ACTIVATION_NONE)
    f_out.write("localparam ACTIVATION_RELU = %d;\n" % ACTIVATION_RELU)
    f_out.write("localparam ACTIVATION_SOFTMAX = %d;\n" % ACTIVATION_SOFTMAX)
    f_out.write("localparam ACTIVATION_SIGMOID = %d;\n" % ACTIVATION_SIGMOID)
    f_out.write("localparam ACTIVATION_UNKNOWN = %d;\n" % ACTIVATION_UNKNOWN)
    f_out.write("localparam MIPE_OP_MAC = %d;\n" % (0))
    f_out.write("localparam MIPE_OP_MAX_POOL = %d;\n" % (1))
    f_out.write("localparam MIPE_OP_AVG_POOL = %d;\n" % (2))
    f_out.write("localparam MIPE_OP_NOP = %d;\n" % (3))
    f_out.write("\n")
    f_out.write("localparam NBIT_FIELD_MODEL_ID = %d;\n" % NBIT_FIELD_MODEL_ID)
    f_out.write("localparam NBIT_FIELD_MODEL_SIZE = %d;\n" % NBIT_FIELD_MODEL_SIZE)
    f_out.write("localparam NBIT_FIELD_FMAP_SIZE = %d;\n" % NBIT_FIELD_FMAP_SIZE)
    f_out.write("localparam NBIT_FIELD_N_LAYER = %d;\n" % NBIT_FIELD_N_LAYER)
    f_out.write("localparam NBIT_FIELD_SCALING_DIN = %d;\n" % NBIT_FIELD_SCALING_DIN)
    f_out.write("localparam NBIT_FIELD_OFFSET_DIN = %d;\n" % NBIT_FIELD_OFFSET_DIN)
    f_out.write("localparam NBIT_FIELD_INPUT_SIZE_X = %d;\n" % NBIT_FIELD_INPUT_SIZE_X)
    f_out.write("localparam NBIT_FIELD_INPUT_SIZE_Y = %d;\n" % NBIT_FIELD_INPUT_SIZE_Y)
    f_out.write("localparam NBIT_FIELD_INPUT_SIZE_Z = %d;\n" % NBIT_FIELD_INPUT_SIZE_Z)
    f_out.write("localparam NBIT_FIELD_ROW_INCR = %d;\n" % NBIT_FIELD_ROW_INCR)
    f_out.write("localparam NBIT_FIELD_PACK_LVL = %d;\n" % NBIT_FIELD_PACK_LVL)
    f_out.write("localparam NBIT_FIELD_W_MEMOFFSET = %d;\n" % NBIT_FIELD_W_MEMOFFSET)
    f_out.write("localparam NBIT_FIELD_SCALING_OUT = %d;\n" % NBIT_FIELD_SCALING_OUT)
    f_out.write("localparam NBIT_FIELD_ZERO_OUT = %d;\n" % NBIT_FIELD_ZERO_OUT)
    f_out.write("localparam NBIT_FIELD_LAYER_TYPE = %d;\n" % NBIT_FIELD_LAYER_TYPE)
    f_out.write("localparam NBIT_FIELD_OUT_SIZE_X = %d;\n" % NBIT_FIELD_OUT_SIZE_X)
    f_out.write("localparam NBIT_FIELD_OUT_SIZE_Y = %d;\n" % NBIT_FIELD_OUT_SIZE_Y)
    f_out.write("localparam NBIT_FIELD_OUT_SIZE_Z = %d;\n" % NBIT_FIELD_OUT_SIZE_Z)
    f_out.write("localparam NBIT_FIELD_KERNEL_SIZE = %d;\n" % NBIT_FIELD_KERNEL_SIZE)
    f_out.write("localparam NBIT_FIELD_STRIDE = %d;\n" % NBIT_FIELD_STRIDE)
    f_out.write("localparam NBIT_FIELD_PADDING_MODE = %d;\n" % NBIT_FIELD_PADDING_MODE)
    f_out.write("localparam NBIT_FIELD_PADDING = %d;\n" % NBIT_FIELD_PADDING)
    f_out.write("localparam NBIT_FIELD_ACTIVATION = %d;\n" % NBIT_FIELD_ACTIVATION)
    f_out.write("localparam NBIT_FIELD_LAST_ACTIVATION = %d;\n" % NBIT_FIELD_LAST_ACTIVATION)
    f_out.write("localparam NBIT_FIELD_SCALING_FACTOR = %d;\n" % NBIT_FIELD_SCALING_FACTOR)
    f_out.write("localparam NBIT_FIELD_SCALING_EXPONENT = %d;\n" % NBIT_FIELD_SCALING_EXPONENT)
    f_out.write("localparam NBIT_FIELD_POOL_TYPE = %d;\n" % NBIT_FIELD_POOL_TYPE)
    f_out.write("localparam NBIT_FIELD_FC_N_OUTPUT = %d;\n" % NBIT_FIELD_FC_N_OUTPUT)
    f_out.write("localparam NBIT_SCALING_DIN = %d;\n" % NBIT_FIELD_SCALING_DIN)
    f_out.write("localparam NBIT_SCALING_DIN_INT = %d;\n" % NBIT_FIELD_SCALING_DIN_INT)
    f_out.write("localparam NBIT_OFFSET_DIN = %d;\n" % NBIT_FIELD_OFFSET_DIN)
    f_out.write("localparam NBIT_FIELD_WEIGHT_INCR = %d;\n" % NBIT_FIELD_WEIGHT_INCR)
    f_out.write("\n")
    f_out.write("localparam NWEIGHT_BIAS = %d;\n" % NWEIGHT_BIAS)
    f_out.write("localparam FC_SWAP_BANKS = %d;\n" % (NWEIGHT_BIAS % MIPE_PAR))
    f_out.write("localparam NBIT_GLOBAL_CFG = %d;\n" % NBIT_GLOBAL_CFG)
    f_out.write("localparam NBIT_LAYER_CFG = %d;\n" % NBIT_LAYER_CFG)
    f_out.write("localparam NWORD_GLOBAL_CONFIG = %d;\n" % NWORD_GLOBAL_CONFIG)
    f_out.write("localparam NBANKWORD_LAYER_CONFIG = %d;\n" % NBANKWORD_LAYER_CONFIG)
    f_out.write("\n")
    offset = NBIT_FIELD_MODEL_ID
    f_out.write("localparam GLOBAL_OFFSET0 = %d;\n" % offset)
    offset += NBIT_FIELD_MODEL_SIZE
    f_out.write("localparam GLOBAL_OFFSET1 = %d;\n" % offset)
    offset += NBIT_FIELD_FMAP_SIZE
    f_out.write("localparam GLOBAL_OFFSET2 = %d;\n" % offset)
    offset += NBIT_FIELD_FMAP_SIZE
    f_out.write("localparam GLOBAL_OFFSET3 = %d;\n" % offset)
    offset += NBIT_FIELD_N_LAYER
    f_out.write("localparam GLOBAL_OFFSET4 = %d;\n" % offset)
    offset += NBIT_FIELD_INPUT_SIZE_X
    f_out.write("localparam GLOBAL_OFFSET5  = %d;\n" % offset)
    offset += NBIT_FIELD_INPUT_SIZE_Y
    f_out.write("localparam GLOBAL_OFFSET6  = %d;\n" % offset)
    offset += NBIT_FIELD_INPUT_SIZE_Z
    f_out.write("localparam GLOBAL_OFFSET7 = %d;\n" % offset)
    offset += NBIT_FIELD_PACK_LVL
    f_out.write("localparam GLOBAL_OFFSET8 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam GLOBAL_OFFSET9 = %d;\n" % offset)
    offset += NBIT_DATA
    f_out.write("localparam GLOBAL_OFFSET10 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_X
    f_out.write("localparam GLOBAL_OFFSET11 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Y
    f_out.write("localparam GLOBAL_OFFSET12 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Z
    f_out.write("localparam GLOBAL_OFFSET13 = %d;\n" % offset)
    offset += NBIT_FIELD_PACK_LVL
    f_out.write("localparam GLOBAL_OFFSET14 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam GLOBAL_OFFSET15 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_OUT
    f_out.write("localparam GLOBAL_OFFSET16 = %d;\n" % offset)
    offset += NBIT_FIELD_ZERO_OUT
    f_out.write("localparam GLOBAL_OFFSET17 = %d;\n" % offset)
    offset += NBIT_FIELD_LAST_ACTIVATION
    f_out.write("localparam GLOBAL_OFFSET18 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_DIN
    f_out.write("localparam GLOBAL_OFFSET19 = %d;\n" % offset)
    offset += NBIT_FIELD_OFFSET_DIN
    f_out.write("localparam GLOBAL_OFFSET20 = %d;\n" % offset)
    offset += NBIT_FIELD_W_MEMOFFSET
    f_out.write("localparam GLOBAL_OFFSET21 = %d;\n" % offset)
    f_out.write("\n")

    offset = NBIT_FIELD_LAYER_TYPE
    f_out.write("localparam CONV_OFFSET0 = %d;\n" % offset)
    offset += NBIT_FIELD_KERNEL_SIZE
    f_out.write("localparam CONV_OFFSET1 = %d;\n" % offset)
    offset += NBIT_FIELD_KERNEL_SIZE
    f_out.write("localparam CONV_OFFSET2 = %d;\n" % offset)
    offset += NBIT_FIELD_STRIDE
    f_out.write("localparam CONV_OFFSET3 = %d;\n" % offset)
    offset += NBIT_FIELD_STRIDE
    f_out.write("localparam CONV_OFFSET4 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING_MODE
    f_out.write("localparam CONV_OFFSET5 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING
    f_out.write("localparam CONV_OFFSET6 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING
    f_out.write("localparam CONV_OFFSET7 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING
    f_out.write("localparam CONV_OFFSET8 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING
    f_out.write("localparam CONV_OFFSET9 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_X
    f_out.write("localparam CONV_OFFSET10 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Y
    f_out.write("localparam CONV_OFFSET11 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Z
    f_out.write("localparam CONV_OFFSET12 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam CONV_OFFSET13 = %d;\n" % offset)
    offset += NBIT_FIELD_ACTIVATION
    f_out.write("localparam CONV_OFFSET14 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_FACTOR
    f_out.write("localparam CONV_OFFSET15 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_EXPONENT
    f_out.write("localparam CONV_OFFSET16 = %d;\n" % offset)
    offset += NBIT_WEIGHT
    f_out.write("localparam CONV_OFFSET17 = %d;\n" % offset)
    offset += NBIT_DATA
    f_out.write("localparam CONV_OFFSET18 = %d;\n" % offset)
    offset += NBIT_FIELD_ROW_INCR
    f_out.write("localparam CONV_OFFSET19 = %d;\n" % offset)
    offset += NBIT_FIELD_PACK_LVL
    f_out.write("localparam CONV_OFFSET20 = %d;\n" % offset)
    offset += NBIT_FIELD_FMAP_SIZE
    f_out.write("localparam CONV_OFFSET21 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam CONV_OFFSET22 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam CONV_OFFSET23 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam CONV_OFFSET24 = %d;\n" % offset)
    f_out.write("\n")

    offset = NBIT_FIELD_LAYER_TYPE
    f_out.write("localparam POOL_OFFSET0 = %d;\n" % offset)
    offset += NBIT_FIELD_KERNEL_SIZE
    f_out.write("localparam POOL_OFFSET1 = %d;\n" % offset)
    offset += NBIT_FIELD_KERNEL_SIZE
    f_out.write("localparam POOL_OFFSET2 = %d;\n" % offset)
    offset += NBIT_FIELD_STRIDE
    f_out.write("localparam POOL_OFFSET3 = %d;\n" % offset)
    offset += NBIT_FIELD_STRIDE
    f_out.write("localparam POOL_OFFSET4 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING_MODE
    f_out.write("localparam POOL_OFFSET5 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING
    f_out.write("localparam POOL_OFFSET6 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING
    f_out.write("localparam POOL_OFFSET7 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING
    f_out.write("localparam POOL_OFFSET8 = %d;\n" % offset)
    offset += NBIT_FIELD_PADDING
    f_out.write("localparam POOL_OFFSET9 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_X
    f_out.write("localparam POOL_OFFSET10 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Y
    f_out.write("localparam POOL_OFFSET11 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Z
    f_out.write("localparam POOL_OFFSET12 = %d;\n" % offset)
    offset += NBIT_FIELD_POOL_TYPE
    f_out.write("localparam POOL_OFFSET13 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_FACTOR
    f_out.write("localparam POOL_OFFSET14 = %d;\n" % offset)
    offset += NBIT_FIELD_ROW_INCR
    f_out.write("localparam POOL_OFFSET15 = %d;\n" % offset)
    offset += NBIT_FIELD_PACK_LVL
    f_out.write("localparam POOL_OFFSET16 = %d;\n" % offset)
    offset += NBIT_FIELD_FMAP_SIZE
    f_out.write("localparam POOL_OFFSET17 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam POOL_OFFSET18 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam POOL_OFFSET19 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam POOL_OFFSET20 = %d;\n" % offset)
    f_out.write("\n")

    offset = NBIT_FIELD_LAYER_TYPE
    f_out.write("localparam FC_OFFSET0 = %d;\n" % offset)
    offset += NBIT_FIELD_FC_N_OUTPUT
    f_out.write("localparam FC_OFFSET1 = %d;\n" % offset)
    offset += NBIT_FIELD_ACTIVATION
    f_out.write("localparam FC_OFFSET2 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_FACTOR
    f_out.write("localparam FC_OFFSET3 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_EXPONENT
    f_out.write("localparam FC_OFFSET4 = %d;\n" % offset)
    offset += NBIT_WEIGHT
    f_out.write("localparam FC_OFFSET5 = %d;\n" % offset)
    offset += NBIT_DATA
    f_out.write("localparam FC_OFFSET6 = %d;\n" % offset)
    offset += NBIT_FIELD_INPUT_SIZE_Y
    f_out.write("localparam FC_OFFSET7 = %d;\n" % offset)
    offset += NBIT_FIELD_PACK_LVL
    f_out.write("localparam FC_OFFSET8 = %d;\n" % offset)
    offset += NBIT_FIELD_ROW_INCR
    f_out.write("localparam FC_OFFSET9 = %d;\n" % offset)
    offset += NBIT_FIELD_FMAP_SIZE
    f_out.write("localparam FC_OFFSET10 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam FC_OFFSET11 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam FC_OFFSET12 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam FC_OFFSET13 = %d;\n" % offset)
    f_out.write("\n")

    offset = NBIT_FIELD_LAYER_TYPE
    f_out.write("localparam ADD_OFFSET0 = %d;\n" % offset)
    offset += NBIT_BIAS
    f_out.write("localparam ADD_OFFSET1 = %d;\n" % offset)
    offset += NBIT_WEIGHT
    f_out.write("localparam ADD_OFFSET2 = %d;\n" % offset)
    offset += NBIT_WEIGHT
    f_out.write("localparam ADD_OFFSET3 = %d;\n" % offset)
    offset += NBIT_FIELD_ROW_INCR
    f_out.write("localparam ADD_OFFSET4 = %d;\n" % offset)
    offset += NBIT_FIELD_ACTIVATION
    f_out.write("localparam ADD_OFFSET5 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_FACTOR
    f_out.write("localparam ADD_OFFSET6 = %d;\n" % offset)
    offset += NBIT_FIELD_SCALING_EXPONENT
    f_out.write("localparam ADD_OFFSET7 = %d;\n" % offset)
    offset += NBIT_DATA
    f_out.write("localparam ADD_OFFSET8 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_X
    f_out.write("localparam ADD_OFFSET9 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Y
    f_out.write("localparam ADD_OFFSET10 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Z
    f_out.write("localparam ADD_OFFSET11 = %d;\n" % offset)
    offset += NBIT_FIELD_PACK_LVL
    f_out.write("localparam ADD_OFFSET12 = %d;\n" % offset)
    offset += NBIT_FIELD_FMAP_SIZE
    f_out.write("localparam ADD_OFFSET13 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam ADD_OFFSET14 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam ADD_OFFSET15 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam ADD_OFFSET16 = %d;\n" % offset)
    f_out.write("\n")

    offset = NBIT_FIELD_LAYER_TYPE
    f_out.write("localparam XTEN_OFFSET0 = %d;\n" % offset)
    offset += NBIT_FIELD_LAYER_TYPE
    f_out.write("localparam XTEN_OFFSET1 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_X
    f_out.write("localparam XTEN_OFFSET2 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Y
    f_out.write("localparam XTEN_OFFSET3 = %d;\n" % offset)
    offset += NBIT_FIELD_OUT_SIZE_Z
    f_out.write("localparam XTEN_OFFSET4 = %d;\n" % offset)
    offset += NBIT_FIELD_PACK_LVL
    f_out.write("localparam XTEN_OFFSET5 = %d;\n" % offset)
    offset += NBIT_DATA
    f_out.write("localparam XTEN_OFFSET6 = %d;\n" % offset)
    offset += NBIT_FIELD_FMAP_SIZE
    f_out.write("localparam XTEN_OFFSET7 = %d;\n" % offset)
    offset += NBIT_FIELD_WEIGHT_INCR
    f_out.write("localparam XTEN_OFFSET8 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam XTEN_OFFSET9 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam XTEN_OFFSET10 = %d;\n" % offset)
    offset += 1
    f_out.write("localparam XTEN_OFFSET11 = %d;\n" % offset)
    f_out.write("\n")

    f_out.write("\n`endif\n")
    f_out.close()


def write_hpp(ip_path, nbuff, nwordbuff):
    """
    Write the .hpp constants file
    """
    try:
        hpp_fname = ip_path + "/" + HPP_CONST_FILE
        f_hpp = open(hpp_fname, "w")
    except IOError as e:
        logging.error("Unable to open " + hpp_fname + " in write mode!")
        raise e

    logging.info("Writing file " + hpp_fname)

    f_hpp.write("#ifndef NNPA_CONSTANTS_H\n")
    f_hpp.write("#define NNPA_CONSTANTS_H\n\n")
    f_hpp.write("namespace NNPACONST {\n")

    f_hpp.write(f"    const int MIPE_PAR = {MIPE_PAR};\n")
    f_hpp.write(f"    const int N_MIPE = {N_MIPE};\n")
    f_hpp.write(f"    const int MIPE_N_PAR_MUL = {MIPE_PAR * N_MIPE};\n")
    f_hpp.write(f"    const int NBIT_WEIGHT = {NBIT_WEIGHT};\n")
    f_hpp.write(f"    const int NBIT_BIAS = {NBIT_BIAS};\n")
    f_hpp.write(f"    const int NBIT_DATA = {NBIT_DATA};\n")
    f_hpp.write(f"    const int DATA_MASK = {(1 << NBIT_DATA) - 1};\n")
    f_hpp.write(f"    const int NBIT_MAC = {NBIT_MAC};\n")
    f_hpp.write(f"    const int NBIT_SCALING = {NBIT_SCALING};\n")
    f_hpp.write(f"    const int SCALING_EXP_MAX = {SCALING_EXP_MAX};\n")
    f_hpp.write("\n")

    f_hpp.write(f"    const int N_MEM_BUFF = {nbuff};\n")
    f_hpp.write(f"    const int NWORD_MEM_BUFF = {nwordbuff};\n")
    f_hpp.write("\n")

    f_hpp.write(f"    const int CONV_LAYER = {CONV_LAYER};\n")
    f_hpp.write(f"    const int POOL_LAYER = {POOL_LAYER};\n")
    f_hpp.write(f"    const int FC_LAYER = {FC_LAYER};\n")
    f_hpp.write(f"    const int ADD_LAYER = {ADD_LAYER};\n")
    f_hpp.write(f"    const int XTEN_LAYER = {XTEN_LAYER};\n")
    f_hpp.write(f"    const int PADDING_VALID = {PADDING_VALID};\n")
    f_hpp.write(f"    const int PADDING_SAME = {PADDING_SAME};\n")
    f_hpp.write("    const int POOL_TYPE_MAX = 0;\n")
    f_hpp.write("    const int POOL_TYPE_AVG = 1;\n")
    f_hpp.write(f"    const int ACTIVATION_NONE = {ACTIVATION_NONE};\n")
    f_hpp.write(f"    const int ACTIVATION_RELU = {ACTIVATION_RELU};\n")
    f_hpp.write(f"    const int ACTIVATION_SOFTMAX = {ACTIVATION_SOFTMAX};\n")
    f_hpp.write(f"    const int ACTIVATION_SIGMOID = {ACTIVATION_SIGMOID};\n")
    f_hpp.write(f"    const int ACTIVATION_UNKNOWN = {ACTIVATION_UNKNOWN};\n")
    f_hpp.write("\n")

    f_hpp.write(f"    const int NBIT_FIELD_MODEL_ID = {NBIT_FIELD_MODEL_ID};\n")
    f_hpp.write(f"    const int NBIT_FIELD_MODEL_SIZE = {NBIT_FIELD_MODEL_SIZE};\n")
    f_hpp.write(f"    const int NBIT_FIELD_FMAP_SIZE = {NBIT_FIELD_FMAP_SIZE};\n")
    f_hpp.write(f"    const int NBIT_FIELD_N_LAYER = {NBIT_FIELD_N_LAYER};\n")
    f_hpp.write(f"    const int NBIT_FIELD_SCALING_DIN = {NBIT_FIELD_SCALING_DIN};\n")
    f_hpp.write(f"    const int NBIT_FIELD_SCALING_DIN_INT = {NBIT_FIELD_SCALING_DIN_INT};\n")
    f_hpp.write(f"    const int NBIT_FIELD_OFFSET_DIN = {NBIT_FIELD_OFFSET_DIN};\n")
    f_hpp.write(f"    const int NBIT_FIELD_INPUT_SIZE_X = {NBIT_FIELD_INPUT_SIZE_X};\n")
    f_hpp.write(f"    const int NBIT_FIELD_INPUT_SIZE_Y = {NBIT_FIELD_INPUT_SIZE_Y};\n")
    f_hpp.write(f"    const int NBIT_FIELD_INPUT_SIZE_Z = {NBIT_FIELD_INPUT_SIZE_Z};\n")
    f_hpp.write(f"    const int NBIT_FIELD_ROW_INCR = {NBIT_FIELD_ROW_INCR};\n")
    f_hpp.write(f"    const int NBIT_FIELD_PACK_LVL = {NBIT_FIELD_PACK_LVL};\n")
    f_hpp.write(f"    const int NBIT_FIELD_W_MEMOFFSET = {NBIT_FIELD_W_MEMOFFSET};\n")
    f_hpp.write(f"    const int NBIT_FIELD_SCALING_OUT = {NBIT_FIELD_SCALING_OUT};\n")
    f_hpp.write(f"    const int NBIT_FIELD_ZERO_OUT = {NBIT_FIELD_ZERO_OUT};\n")
    f_hpp.write(f"    const int NBIT_FIELD_LAYER_TYPE = {NBIT_FIELD_LAYER_TYPE};\n")
    f_hpp.write(f"    const int NBIT_FIELD_OUT_SIZE_X = {NBIT_FIELD_OUT_SIZE_X};\n")
    f_hpp.write(f"    const int NBIT_FIELD_OUT_SIZE_Y = {NBIT_FIELD_OUT_SIZE_Y};\n")
    f_hpp.write(f"    const int NBIT_FIELD_OUT_SIZE_Z = {NBIT_FIELD_OUT_SIZE_Z};\n")
    f_hpp.write(f"    const int NBIT_FIELD_KERNEL_SIZE = {NBIT_FIELD_KERNEL_SIZE};\n")
    f_hpp.write(f"    const int NBIT_FIELD_STRIDE = {NBIT_FIELD_STRIDE};\n")
    f_hpp.write(f"    const int NBIT_FIELD_PADDING_MODE = {NBIT_FIELD_PADDING_MODE};\n")
    f_hpp.write(f"    const int NBIT_FIELD_PADDING = {NBIT_FIELD_PADDING};\n")
    f_hpp.write(f"    const int NBIT_FIELD_ACTIVATION = {NBIT_FIELD_ACTIVATION};\n")
    f_hpp.write(f"    const int NBIT_FIELD_LAST_ACTIVATION = {NBIT_FIELD_LAST_ACTIVATION};\n")
    f_hpp.write(f"    const int NBIT_FIELD_SCALING_FACTOR = {NBIT_FIELD_SCALING_FACTOR};\n")
    f_hpp.write(f"    const int NBIT_FIELD_SCALING_EXPONENT = {NBIT_FIELD_SCALING_EXPONENT};\n")
    f_hpp.write(f"    const int NBIT_FIELD_POOL_TYPE = {NBIT_FIELD_POOL_TYPE};\n")
    f_hpp.write(f"    const int NBIT_FIELD_FC_N_OUTPUT = {NBIT_FIELD_FC_N_OUTPUT};\n")
    f_hpp.write(f"    const int NBIT_FIELD_WEIGHT_INCR = {NBIT_FIELD_WEIGHT_INCR};\n")
    f_hpp.write("\n")

    f_hpp.write(f"    const int NWEIGHT_BIAS = {NWEIGHT_BIAS};\n")
    f_hpp.write(f"    const int FC_SWAP_BANKS = {NWEIGHT_BIAS % MIPE_PAR};\n")
    f_hpp.write(f"    const int NBIT_MEMBUFF_WORD = {NBIT_DATA * N_MIPE * MIPE_PAR};\n")
    f_hpp.write(f"    const int NBIT_MEMBANK_WORD = {NBIT_DATA * N_MIPE};\n")
    f_hpp.write(f"    const int NBIT_GLOBAL_CFG = {NBIT_GLOBAL_CFG};\n")
    f_hpp.write(f"    const int NBIT_LAYER_CFG = {NBIT_LAYER_CFG};\n")
    f_hpp.write(f"    const int NWORD_GLOBAL_CONFIG = {NWORD_GLOBAL_CONFIG};\n")
    f_hpp.write(f"    const int NBANKWORD_LAYER_CONFIG = {NBANKWORD_LAYER_CONFIG};\n")

    f_hpp.write("}\n\n")
    f_hpp.write("#endif")
    f_hpp.close()


if __name__ == "__main__":
    cli()
