# Omni Video Python SDK

Python client for [Omni Video](https://omnivideo.net/) — generate video and image content with the **Gemini Omni Video** series of models from one tiny client.

[Omni Video](https://omnivideo.net/) is a hosted multimodal generation platform that wraps the Gemini Omni Video family (`seedance-2` for text/image → video, `gpt-image-2` and `nano-banana-2` for text/image → image) behind one REST API.

## Install

```bash
pip install omnivideo-sdk
```

## Get an API key

Sign in at **<https://omnivideo.net/>**, open the account page, and create a `sk-…` token. Then export it:

```bash
export OMNIVIDEO_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## Quick start

```python
from omnivideo_sdk import OmniVideo

client = OmniVideo()  # reads OMNIVIDEO_API_KEY

# One-shot: create and wait for the result
task = client.run(
    model_id="seedance-2",
    prompt="a serene zen garden at sunrise, ultra detailed",
    aspect_ratio="16:9",
)
print(task.output_url)  # video_url or image_url
```

### Lower level: create + poll yourself

```python
from omnivideo_sdk import OmniVideo, TaskStatus

client = OmniVideo(api_key="sk-...")

task = client.create_task(
    model_id="gpt-image-2",
    prompt="cyberpunk corgi, neon rim light",
    image_urls=[],
    aspect_ratio="1:1",
)
print(task.task_id)

while not task.done:
    task = client.get_task(task.task_id)

assert task.task_status == TaskStatus.SUCCESS
print(task.image_url)
```

## Supported models

| `model_id`      | Modality           | Output      |
| --------------- | ------------------ | ----------- |
| `seedance-2`    | text/image → video | `video_url` |
| `gpt-image-2`   | text/image → image | `image_url` |
| `nano-banana-2` | text/image → image | `image_url` |

See the live model list and pricing on the [Omni Video](https://omnivideo.net/) website.

## API surface

- `OmniVideo(api_key=None, base_url=..., timeout=60.0)`
- `client.create_task(model_id, prompt, image_urls=None, aspect_ratio=None, **extra) -> Task`
- `client.get_task(task_id) -> Task`
- `client.run(model_id, prompt, ..., poll_interval=3.0, max_wait=600.0) -> Task`
- `Task` fields: `task_id`, `task_status` (1=queued, 2=running, 3=success, 4=failed), `image_url`, `video_url`, `credits`, `output_url`, `done`.

Errors are raised as `OmniVideoError`.

## Links

- Website & account: <https://omnivideo.net/>
- API docs: <https://omnivideo.net/api-docs>

## License

MIT
