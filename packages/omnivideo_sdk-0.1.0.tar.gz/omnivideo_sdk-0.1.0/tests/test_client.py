import json
from unittest.mock import MagicMock

import pytest

from omnivideo_sdk import OmniVideo, OmniVideoError, TaskStatus


def _mock_session(responses):
    session = MagicMock()
    session.request.side_effect = responses
    return session


def _resp(json_body, status_code=200, ok=True):
    r = MagicMock()
    r.ok = ok
    r.status_code = status_code
    r.json.return_value = json_body
    r.text = json.dumps(json_body)
    return r


def test_create_task_returns_task_id():
    session = _mock_session(
        [_resp({"code": 200, "task_id": "abc123", "task_status": 1})]
    )
    client = OmniVideo(api_key="sk-test", session=session)
    task = client.create_task("gpt-image-2", "a cat")
    assert task.task_id == "abc123"
    assert task.task_status == TaskStatus.QUEUED


def test_missing_api_key_raises():
    with pytest.raises(OmniVideoError):
        OmniVideo(api_key=None)


def test_run_polls_until_success():
    responses = [
        _resp({"code": 200, "task_id": "t1", "task_status": 1}),
        _resp({"code": 200, "task_id": "t1", "task_status": 2}),
        _resp(
            {
                "code": 200,
                "task_id": "t1",
                "task_status": 3,
                "image_url": "https://cdn.example/x.png",
                "credits": 15,
            }
        ),
    ]
    session = _mock_session(responses)
    client = OmniVideo(api_key="sk-test", session=session)
    task = client.run("gpt-image-2", "a cat", poll_interval=0, max_wait=5)
    assert task.task_status == TaskStatus.SUCCESS
    assert task.output_url == "https://cdn.example/x.png"


def test_business_error_raised():
    session = _mock_session(
        [_resp({"code": 0, "msg": "insufficient credits"}, ok=True)]
    )
    client = OmniVideo(api_key="sk-test", session=session)
    with pytest.raises(OmniVideoError, match="insufficient credits"):
        client.create_task("gpt-image-2", "x")
