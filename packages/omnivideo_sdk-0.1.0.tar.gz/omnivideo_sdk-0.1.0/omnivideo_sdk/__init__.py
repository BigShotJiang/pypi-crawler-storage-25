"""Omni Video Python SDK — generate video and image content with the Gemini Omni Video models."""

from .client import OmniVideo, OmniVideoError, Task, TaskStatus

__all__ = ["OmniVideo", "OmniVideoError", "Task", "TaskStatus"]
__version__ = "0.1.0"
