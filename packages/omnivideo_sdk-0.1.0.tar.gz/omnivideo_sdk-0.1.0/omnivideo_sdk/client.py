from __future__ import annotations

import os
import time
from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Iterable

import requests

DEFAULT_BASE_URL = "https://omnivideo.net/api/v1"


class TaskStatus(IntEnum):
    QUEUED = 1
    RUNNING = 2
    SUCCESS = 3
    FAILED = 4


@dataclass
class Task:
    task_id: str
    task_status: TaskStatus
    image_url: str | None = None
    video_url: str | None = None
    credits: int | None = None
    raw: dict[str, Any] | None = None

    @property
    def done(self) -> bool:
        return self.task_status in (TaskStatus.SUCCESS, TaskStatus.FAILED)

    @property
    def output_url(self) -> str | None:
        return self.video_url or self.image_url


class OmniVideoError(Exception):
    def __init__(self, message: str, *, code: int | None = None, status: int | None = None):
        super().__init__(message)
        self.code = code
        self.status = status


class OmniVideo:
    """Client for the Omni Video API (https://omnivideo.net/)."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 60.0,
        session: requests.Session | None = None,
    ) -> None:
        key = api_key or os.environ.get("OMNIVIDEO_API_KEY")
        if not key:
            raise OmniVideoError(
                "Missing API key. Pass api_key=... or set OMNIVIDEO_API_KEY. "
                "Get one at https://omnivideo.net/ after signing in."
            )
        self.api_key = key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = session or requests.Session()

    def create_task(
        self,
        model_id: str,
        prompt: str,
        *,
        image_urls: Iterable[str] | None = None,
        aspect_ratio: str | None = None,
        **extra: Any,
    ) -> Task:
        """Submit a generation job. Returns a Task with `task_id` set."""
        body: dict[str, Any] = {"model_id": model_id, "prompt": prompt}
        if image_urls is not None:
            body["image_urls"] = list(image_urls)
        if aspect_ratio is not None:
            body["aspect_ratio"] = aspect_ratio
        body.update(extra)

        data = self._request("POST", "/tasks/create", json=body)
        return self._task_from_payload(data)

    def get_task(self, task_id: str) -> Task:
        """Fetch the current state of a task."""
        data = self._request("GET", f"/tasks/{task_id}")
        return self._task_from_payload(data)

    def run(
        self,
        model_id: str,
        prompt: str,
        *,
        image_urls: Iterable[str] | None = None,
        aspect_ratio: str | None = None,
        poll_interval: float = 3.0,
        max_wait: float = 600.0,
        **extra: Any,
    ) -> Task:
        """Create a task and poll until it reaches a terminal state."""
        task = self.create_task(
            model_id,
            prompt,
            image_urls=image_urls,
            aspect_ratio=aspect_ratio,
            **extra,
        )
        deadline = time.monotonic() + max_wait
        while not task.done:
            if time.monotonic() > deadline:
                raise OmniVideoError(
                    f"Task {task.task_id} did not finish within {max_wait}s",
                    code=task.task_status,
                )
            time.sleep(poll_interval)
            task = self.get_task(task.task_id)
        if task.task_status == TaskStatus.FAILED:
            raise OmniVideoError(
                f"Task {task.task_id} failed", code=TaskStatus.FAILED
            )
        return task

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = kwargs.pop("headers", {})
        headers.setdefault("Authorization", f"Bearer {self.api_key}")
        headers.setdefault("Accept", "application/json")
        response = self._session.request(
            method, url, headers=headers, timeout=self.timeout, **kwargs
        )
        if response.status_code == 401:
            raise OmniVideoError(
                "Unauthorized — check your OMNIVIDEO_API_KEY (https://omnivideo.net/).",
                status=401,
            )
        try:
            payload = response.json()
        except ValueError as exc:
            raise OmniVideoError(
                f"Invalid JSON from {url}: {response.text[:200]}", status=response.status_code
            ) from exc
        if not response.ok:
            raise OmniVideoError(
                payload.get("msg") or f"HTTP {response.status_code}",
                code=payload.get("code"),
                status=response.status_code,
            )
        if payload.get("code") not in (200, None):
            raise OmniVideoError(
                payload.get("msg") or "Business error", code=payload.get("code")
            )
        return payload

    @staticmethod
    def _task_from_payload(payload: dict[str, Any]) -> Task:
        return Task(
            task_id=payload.get("task_id", ""),
            task_status=TaskStatus(payload.get("task_status", 1)) if payload.get("task_status") else TaskStatus.QUEUED,
            image_url=payload.get("image_url"),
            video_url=payload.get("video_url"),
            credits=payload.get("credits"),
            raw=payload,
        )
