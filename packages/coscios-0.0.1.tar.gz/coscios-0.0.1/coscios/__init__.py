"""cosciOS - Reference implementation of Coordination Science."""
