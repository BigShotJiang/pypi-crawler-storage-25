## v0.13.1 (2026-05-10)

### Refactor

- Rename `lift` to `combine` across codebase and update related documentation

## v0.13.0 (2026-05-10)

### Feat

- Introduces LogicalResolver and expands lift's resolvers.
- Adds Smart Fetch tool and standardizes 'uv run' commands.

### Refactor

- Adopts NumericResolver enum in recipe examples.
- Separates numeric conflict resolvers into NumericResolver enum.
- Removes unused imports and clarifies graph connectivity recipe.
- update pivot benchmark

## v0.12.1 (2026-05-08)

### Fix

- makes `Resolver.member` instances callable.

## v0.12.0 (2026-05-08)

### Feat

- generalize tree merging with `lift` and `Resolver` enum.

### Fix

- improves filesystem recipe by correcting scan path and skipping .venv.
- expand reporting and filtering to cover all tracked keys.

### Refactor

- update telemetry aggregation to use `lift` and `Resolver.SUM`.
- `aggregation` module to `aggregations`; rename recipes and links.
- update imports to use mappingtools.typing module

## v0.11.1 (2026-04-08)

### Refactor

- update type imports to use local typing module

## v0.11.0 (2026-04-08)

### Feat

- implement merge function for deeply merging recursive tree structures
- updates

### Perf

- handle sequences in mapping assignment for improved efficiency

## v0.10.0 (2026-01-01)

### Feat

- add Lens for functional, immutable data access and transformation
- introduce `Aggregation` enum to centralize collection logic, add operators: rename and rekey, deprecate AggregationMode

### Refactor

- remove deprecated, redundant operators and their tests.
- simplify rekey by using 'aggregation' parameter for pivot function calls.
- simplify rekey to use aggregation functional primitives more cleanly.

## v0.9.0 (2025-12-15)

### Feat

- add `Dictifier` and `LazyDictifier` and factories.

### Fix

- tests

## v0.8.0 (2025-12-07)

### Feat

- **operators**: deprecate several operator functions.

## v0.7.0 (2025-12-06)

### Feat

- enhance `strictify` to support Mapping and Iterable handling in value conversion

### Fix

- reorder imports in `strictify.py` for PEP 8 compliance

## v0.6.0 (2025-10-26)

### Fix

- update type hint for atomic_operations method to use DictOperation

### Refactor

- move UTC import to compatibility module for cross-version support

## v0.5.0 (2025-08-31)

## v0.4.1 (2025-08-31)

## v0.4.0 (2025-03-25)

## v0.3.1 (2025-01-20)

## v0.3.0 (2025-01-18)

## v0.2.2 (2024-10-18)

## v0.2.1 (2024-10-18)

## v0.2.0 (2024-08-04)

## v0.1.0 (2024-07-29)

## v0.0.5 (2024-07-25)

## v0.0.4 (2024-07-24)

## v0.0.3 (2024-07-24)

## v0.0.2 (2024-07-24)

## v0.0.1 (2024-07-23)
