import itertools
from collections import defaultdict
from collections.abc import Callable, Generator, Iterable, Mapping, Sequence
from itertools import chain
from typing import Any

from mappingtools._tools import _is_strict_iterable
from mappingtools.aggregations import Aggregation
from mappingtools.resolvers import LogicalResolver, NumericResolver, Resolver, ResolverType
from mappingtools.typing import MISSING, Combine, K, Missing, T, Tree

__all__ = [
    'combine',
    'distinct',
    'flatten',
    'inverse',
    'merge',
    'pivot',
    'rekey',
    'rename',
    'reshape',
]


def combine(
        tree1: Tree[T] | Missing = MISSING,
        tree2: Tree[T] | Missing = MISSING,
        op: Combine | ResolverType = Resolver.LAST,
) -> Tree[T] | Any:
    """
    Combines two trees using a binary operator `op` that resolves conflicts at the leaf nodes.

    This is a powerful generalization of `merge`. It recursively walks two tree
    structures and applies the `op` only when it encounters a conflict at the
    leaf nodes (e.g., two scalars at the same path, or a structural mismatch).

    Args:
        tree1 (Tree[T] | Missing): The first tree structure.
        tree2 (Tree[T] | Missing): The second tree structure.
        op: A callable or a Resolver enum strategy (Resolver, LogicalResolver, NumericResolver)
            to resolve collisions. Defaults to `Resolver.LAST`.

    Returns:
        Tree[T] | Any: The combined tree structure.
    """
    if isinstance(op, (Resolver, LogicalResolver, NumericResolver)):
        op = op.value

    def _combine(t1: Any, t2: Any) -> Any:
        # 1) If one side is MISSING, the other side wins unconditionally.
        if t1 is MISSING:
            return t2
        if t2 is MISSING:
            return t1

        # 2) If both are dicts, recursively combine the op over their values.
        if isinstance(t1, dict) and isinstance(t2, dict):
            combined = dict(t1)
            for k, v in t2.items():
                val = _combine(combined.get(k, MISSING), v)
                if val is MISSING:
                    combined.pop(k, None)
                else:
                    combined[k] = val

            # Also need to clean up keys that became MISSING during dict comprehension
            # if they were already in t1 but not in t2
            return {k: v for k, v in combined.items() if v is not MISSING}

        # 3) If both are lists, recursively combine the op over their items by position.
        if isinstance(t1, list) and isinstance(t2, list):
            zipped = itertools.zip_longest(t1, t2, fillvalue=MISSING)
            return [_combine(i1, i2) for i1, i2 in zipped]

        # 4) Otherwise, the structures are in conflict. Apply the operator.
        return op(t1, t2)

    return _combine(tree1, tree2)


def distinct(key: K, *mappings: Mapping[K, Any]) -> Generator[Any, Any, None]:
    """
    Yield distinct values for the specified key across multiple mappings.

    Args:
        key (K): The key to extract distinct values from the mappings.
        *mappings (Mapping[K, Any]): Variable number of mappings to search for distinct values.

    Yields:
        Generator[K, Any, None]: A generator of distinct values extracted from the mappings.
    """
    distinct_value_type_pairs = set()
    for mapping in mappings:
        value = mapping.get(key)
        value_type_pair = (value, type(value))
        if key in mapping and value_type_pair not in distinct_value_type_pairs:
            distinct_value_type_pairs.add(value_type_pair)
            yield value


def flatten(mapping: Mapping[Any, Any], delimiter: str | None = None) -> dict[tuple | str, Any]:
    """
    Flatten a nested mapping structure into a single-level dictionary.

    Args:
        mapping (Mapping[Any, Any]): The nested mapping to flatten.
        delimiter (str | None): Uses this delimiter to join the path parts. If None then return path tuple.

    Returns:
        dict
    """
    result = {}
    path = []

    def _recurse(value: Any):
        if isinstance(value, Mapping):
            for k, v in value.items():
                # Fast path for common atomic keys (str, int)
                if isinstance(k, (str, int)):  # NOSONAR
                    path.append(k)
                    _recurse(v)
                    path.pop()
                elif _is_strict_iterable(k):
                    # k is a tuple/list/iterable, extend path
                    # We need to convert to list to know length for backtracking if it's a generator
                    # But _is_strict_iterable allows generators.
                    # If k is a generator, extending path consumes it.
                    # We can't easily know how many items were added without counting.
                    # So we convert to tuple/list first.
                    k_seq = tuple(k)
                    path.extend(k_seq)
                    _recurse(v)
                    # Backtrack
                    del path[-len(k_seq):]
                else:
                    path.append(k)
                    _recurse(v)
                    path.pop()
        else:
            result[tuple(path)] = value

    _recurse(mapping)

    if delimiter is not None:
        return {delimiter.join(map(str, k)): v for k, v in result.items()}

    return result


def inverse(mapping: Mapping[Any, set]) -> Mapping[Any, set]:
    """
    Return a new dictionary with keys and values swapped from the input mapping.

    Args:
        mapping (Mapping[Any, set]): The input mapping to invert.

    Returns:
        Mapping: A new Mapping with values as keys and keys as values.
    """
    items = chain.from_iterable(((vi, k) for vi in v) for k, v in mapping.items())
    dd = defaultdict(set)
    for k, v in items:
        dd[k].add(v)

    return dict(dd)


def merge(tree1: Tree[T] | Missing = MISSING, tree2: Tree[T] | Missing = MISSING) -> Tree[T]:
    """
    A pure function (Monoid operation) to deeply merge two recursive tree structures.
    The merging strategy resolves conflicts by overwriting existing values with new ones (right-side precedence).
    `MISSING` acts as the identity element.

    Mathematically, this operation forms a composite Monoid:
    - Last Monoid (Scalar Fallback): When resolving conflicts between simple values, the right-hand
      side (`tree2`) wins.
    - Pointwise Monoid (Dictionary Merge): If the values are dictionaries, they are merged by key,
      recursively calling `merge` on the values.
    - Zip Monoid (List Merge): If both are lists, they are zipped and merged positionally,
      substituting `MISSING` for missing indices.
    - Free Monoid (Mixed List/Scalar): If one is a list and the other is a scalar/dict,
      it concatenates (appends/prepends).

    Because it forms a Monoid, this function can be used with `functools.reduce` to collect
    an iterable of trees into a single structure.

    Args:
        tree1 (Tree[T] | Missing): The first tree structure.
        tree2 (Tree[T] | Missing): The second tree structure.

    Returns:
        Tree[T] | Missing: The deeply merged tree structure.
    """
    if isinstance(tree1, dict) and isinstance(tree2, dict):
        merged = dict(tree1)
        for k, v in tree2.items():
            merged[k] = merge(merged.get(k, MISSING), v)
        return merged
    elif isinstance(tree1, list) and isinstance(tree2, list):
        # zip longest to handle different lengths, filling missing values with MISSING
        zipped = itertools.zip_longest(tree1, tree2, fillvalue=MISSING)
        return [merge(t1, t2) for t1, t2 in zipped]
    elif isinstance(tree1, list) and not isinstance(tree2, list) and tree2 is not MISSING:
        # If tree1 is a list and tree2 is not, append tree2 to a new list
        return [*tree1, tree2]
    elif not isinstance(tree1, list) and tree1 is not MISSING and isinstance(tree2, list):
        # If tree2 is a list and tree1 is not, prepend tree1 to a new list
        return [tree1, *tree2]
    elif tree1 is MISSING:
        return tree2
    elif tree2 is MISSING:
        return tree1
    else:
        # If both are values (not dicts or lists), or one is a value and the other is a dict/list,
        # the non-MISSING value takes precedence.
        # If both are non-MISSING and different types, tree2 overwrites tree1.
        return tree2


def pivot(
        iterable: Iterable[Mapping],
        *,
        index: str,
        columns: str,
        values: str,
        aggregation: Aggregation = Aggregation.LAST,
) -> dict[Any, dict[Any, Any]]:
    """
    Reshape data (produce a "pivot" table) based on column values.

    Args:
        iterable: An iterable of mappings (e.g., list of dicts).
        index: The key to use for the row labels.
        columns: The key to use for the column labels.
        values: The key to use for the values.
        aggregation: The aggregation mode to use for values. Defaults to Aggregation.LAST.

    Returns:
        A nested dictionary: {index_value: {column_value: aggregated_value}}.
    """
    # Initialize inner collectors based on mode
    # We use a functional primitive to determine the collection type
    ctype = aggregation.collection_type
    result = defaultdict(lambda: defaultdict(ctype)) if ctype else defaultdict(dict)

    # Optimization: Bind a specialized aggregator function to the local scope
    aggregate = aggregation.aggregator

    for item in iterable:
        # Skip items that don't have the required keys
        if index not in item or columns not in item or values not in item:
            continue

        row_key = item[index]
        col_key = item[columns]
        val = item[values]

        # Pass value as a tuple because aggregator expects iterable
        aggregate(result[row_key], col_key, (val,))

    # Convert defaultdicts to regular dicts for clean output
    # This is a deep conversion
    final_result = {}
    for row_k, row_v in result.items():
        final_result[row_k] = dict(row_v)

    return final_result


def rename(
        mapping: Mapping[K, Any],
        mapper: Mapping[K, K] | Callable[[K], K],
        *,
        aggregation: Aggregation = Aggregation.LAST,
) -> dict[K, Any]:
    """
    Rename keys in a mapping based on a mapper (Mapping or Callable).

    This operator creates a new dictionary with renamed keys. If a key is not
    present in the mapper, it remains unchanged. Collisions (when multiple
    original keys map to the same new key) are handled according to the
    specified aggregation.

    Args:
        mapping: The source mapping.
        mapper: A dictionary mapping old keys to new keys, or a function that transforms keys.
        aggregation: How to handle key collisions. Defaults to Aggregation.LAST.

    Returns:
        A new dictionary with renamed keys and aggregated values.
    """

    def key_factory(k: K, _: Any) -> K:
        if isinstance(mapper, Mapping):
            return mapper.get(k, k)
        return mapper(k)

    return rekey(mapping, key_factory, aggregation=aggregation)


def rekey(
        mapping: Mapping[Any, Any],
        key_factory: Callable[[Any, Any], K],
        *,
        aggregation: Aggregation = Aggregation.LAST,
) -> dict[K, Any]:
    """
    Transform keys of a mapping based on a factory function of (key, value).

    This allows "re-indexing" a mapping where the new key depends on the content
    of the value or a combination of the old key and value. Collisions are
    handled according to the specified aggregation.

    Args:
        mapping: The source mapping.
        key_factory: A callable that takes (key, value) and returns the new key.
        aggregation: How to handle key collisions. Defaults to Aggregation.LAST.

    Returns:
        A new dictionary with keys generated by the factory and aggregated values.
    """
    ctype = aggregation.collection_type
    target = defaultdict(ctype) if ctype else {}

    aggregate = aggregation.aggregator

    for k, v in mapping.items():
        # Pass value as a tuple because aggregator expects iterable
        aggregate(target, key_factory(k, v), (v,))

    return dict(target)


def reshape(
        iterable: Iterable[Mapping],
        keys: Sequence[str | Callable[[Mapping], Any]],
        value: str | Callable[[Mapping], Any],
        aggregation: Aggregation = Aggregation.LAST,
) -> dict[Any, Any]:
    """
    Reshape a stream of mappings into a nested dictionary (tensor) of arbitrary depth.

    This is a generalization of `pivot` that supports N-dimensional nesting.

    Args:
        iterable: An iterable of mappings (records).
        keys: A sequence of keys (or callables) to use for the nesting hierarchy.
        value: The key (or callable) to use for the leaf values.
        aggregation: The aggregation mode to use for collisions at the leaf.

    Returns:
        A nested dictionary where the depth equals len(keys).
    """
    if not keys:
        return {}

    # The root of our tensor
    result = {}

    # Optimization: Bind the aggregator
    aggregate = aggregation.aggregator
    ctype = aggregation.collection_type

    # Optimization: Pre-calculate slice indices
    path_keys = keys[:-1]
    leaf_key = keys[-1]

    for item in iterable:
        # Navigate/Build the tree structure
        current = result
        for k in path_keys:
            key_val = k(item) if callable(k) else item.get(k)

            if key_val not in current:
                current[key_val] = {}

            current = current[key_val]

        leaf_val = leaf_key(item) if callable(leaf_key) else item.get(leaf_key)
        value_val = value(item) if callable(value) else item.get(value)

        # Apply aggregation at the leaf
        if ctype and leaf_val not in current:
            current[leaf_val] = ctype()

        # Pass value as a tuple because aggregator expects iterable
        aggregate(current, leaf_val, (value_val,))

    return result
