import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app
import pytest_asyncio
from unittest.mock import patch

@pytest_asyncio.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_health_check(async_client):
    response = await async_client.get("/health")
    assert response.status_code == 200

@pytest.mark.asyncio
@patch("src.main.produce_event")
async def test_ingest_event(mock_produce, async_client):
    payload = {
        "user_id": "user123",
        "session_id": "sess456",
        "event_type": "view_item",
        "product_id": "prod789",
        "url": "https://shop.com/prod789",
        "user_agent": "Mozilla/5.0"
    }
    
    response = await async_client.post("/api/v1/events", json=payload)
    assert response.status_code == 202
    assert response.json()["status"] == "accepted"
    
    # Because it's a background task, we might need a slight delay or just verify the endpoint response.
    # In a real test, we would use a TestClient that executes background tasks synchronously.