import os
import json
import logging
from confluent_kafka import Producer

logger = logging.getLogger(__name__)

# Initialize Kafka Producer
# In a real production environment, this should be a singleton managed by the app lifecycle
KAFKA_BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:29092")

producer_conf = {
    'bootstrap.servers': KAFKA_BOOTSTRAP_SERVERS,
    'client.id': 'streamcart_api_producer',
    'acks': '1' # Leader acknowledgment is enough for clickstream (balance between safety and speed)
}

try:
    producer = Producer(producer_conf)
except Exception as e:
    logger.error(f"Failed to initialize Kafka Producer: {e}")
    producer = None

def delivery_report(err, msg):
    """ Called once for each message produced to indicate delivery result. """
    if err is not None:
        logger.error(f'Message delivery failed: {err}')
    else:
        logger.debug(f'Message delivered to {msg.topic()} [{msg.partition()}]')

def produce_event(topic: str, event_data: dict):
    """Publishes an event to the Kafka topic."""
    if not producer:
        logger.warning("Kafka producer not initialized. Skipping event.")
        return
        
    try:
        # We use user_id as the routing key to ensure events for the same user 
        # go to the same partition (maintaining order).
        key = event_data.get("user_id", "anonymous").encode('utf-8')
        value = json.dumps(event_data).encode('utf-8')
        
        producer.produce(topic, key=key, value=value, callback=delivery_report)
        producer.poll(0) # Trigger delivery callbacks
    except Exception as e:
        logger.error(f"Error producing event: {e}")