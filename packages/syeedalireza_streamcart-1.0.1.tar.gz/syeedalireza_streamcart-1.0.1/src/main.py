from fastapi import FastAPI, BackgroundTasks, HTTPException
from pydantic import BaseModel
import time
import json
from src.infrastructure.kafka_producer import produce_event

app = FastAPI(
    title="StreamCart API",
    description="Real-time Clickstream Data Ingestion",
    version="1.0.0"
)

class ClickEvent(BaseModel):
    user_id: str
    session_id: str
    event_type: str  # e.g., "view_item", "add_to_cart", "checkout"
    product_id: str | None = None
    url: str
    user_agent: str

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

@app.post("/api/v1/events", status_code=202, tags=["Ingestion"])
async def ingest_event(event: ClickEvent, background_tasks: BackgroundTasks):
    """
    Ingest a clickstream event.
    The actual publishing to Kafka happens in the background to ensure low latency for the client.
    """
    event_data = event.model_dump()
    event_data["timestamp"] = int(time.time() * 1000)
    
    # Offload to background task
    background_tasks.add_task(produce_event, "clickstream_events", event_data)
    
    return {"status": "accepted"}