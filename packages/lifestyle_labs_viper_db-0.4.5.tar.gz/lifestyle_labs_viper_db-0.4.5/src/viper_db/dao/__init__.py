"""DAO singletons and initialization."""

from viper_db.client import DbClient
from viper_db.dao.alert_preferences import (
    AlertPreferencesDAO,
    alert_preferences_dao,
)
from viper_db.dao.availability_slots import (
    AvailabilitySlotsDAO,
    availability_slots_dao,
)
from viper_db.dao.bookings import BookingsDAO, bookings_dao
from viper_db.dao.conversations import ConversationsDAO, conversations_dao
from viper_db.dao.experiences import ExperiencesDAO, experiences_dao
from viper_db.dao.feedback import FeedbackDAO, feedback_dao
from viper_db.dao.messages import MessagesDAO, messages_dao
from viper_db.dao.restaurants import RestaurantsDAO, restaurants_dao
from viper_db.dao.sms_conversations import (
    SmsConversationsDAO,
    sms_conversations_dao,
)
from viper_db.dao.users import UsersDAO, users_dao

_default_client: DbClient | None = None


def init_dao(client: DbClient) -> None:
    """Set the default DbClient used by all DAO singletons."""
    global _default_client
    _default_client = client


def get_default_client() -> DbClient:
    if _default_client is None:
        raise RuntimeError("DAO layer not initialised. Call init_dao(client) at startup.")
    return _default_client


__all__ = [
    "init_dao",
    "get_default_client",
    "BookingsDAO",
    "bookings_dao",
    "AlertPreferencesDAO",
    "alert_preferences_dao",
    "AvailabilitySlotsDAO",
    "availability_slots_dao",
    "ConversationsDAO",
    "conversations_dao",
    "ExperiencesDAO",
    "experiences_dao",
    "FeedbackDAO",
    "feedback_dao",
    "MessagesDAO",
    "messages_dao",
    "RestaurantsDAO",
    "restaurants_dao",
    "SmsConversationsDAO",
    "sms_conversations_dao",
    "UsersDAO",
    "users_dao",
]
