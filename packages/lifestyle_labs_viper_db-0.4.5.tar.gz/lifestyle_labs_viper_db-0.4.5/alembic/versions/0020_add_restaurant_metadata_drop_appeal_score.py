"""add notable_dishes, phone, rating, review_count; drop appeal_score

Revision ID: 0020
Revises: 0019
Create Date: 2026-04-16
"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

revision: str = "0020"
down_revision: Union[str, None] = "0019"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.drop_column("restaurants", "appeal_score")
    op.add_column(
        "restaurants",
        sa.Column(
            "notable_dishes",
            sa.ARRAY(sa.Text),
            server_default="{}",
            nullable=True,
        ),
    )
    op.add_column(
        "restaurants",
        sa.Column("phone", sa.Text, nullable=True),
    )
    op.add_column(
        "restaurants",
        sa.Column("rating", sa.Numeric(2, 1), nullable=True),
    )
    op.add_column(
        "restaurants",
        sa.Column("review_count", sa.Integer, nullable=True),
    )


def downgrade() -> None:
    op.drop_column("restaurants", "review_count")
    op.drop_column("restaurants", "rating")
    op.drop_column("restaurants", "phone")
    op.drop_column("restaurants", "notable_dishes")
    op.add_column(
        "restaurants",
        sa.Column("appeal_score", sa.SmallInteger, nullable=True),
    )
