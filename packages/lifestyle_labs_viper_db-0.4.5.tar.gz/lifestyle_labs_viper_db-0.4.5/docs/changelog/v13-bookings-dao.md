# v13 — Bookings DAO

## Summary

New `BookingsDAO` with `create`, `get_by_user`, and `get_by_id` methods for the existing `bookings` table. Enables viper-api to persist and query bookings without raw SQL.

## Changes

### DAO: `BookingsDAO` (`dao/bookings.py`)

- `create(data)` — inserts a booking row; auto-sets `confirmed_at` when status is CONFIRMED
- `get_by_user(user_id)` — returns user's bookings ordered by `booking_date DESC, booking_time DESC`
- `get_by_id(booking_id)` — single-row lookup by PK

### Registration (`dao/__init__.py`)

- Exports `BookingsDAO` class and `bookings_dao` singleton

## Affected Paths

- `src/viper_db/dao/bookings.py` (new)
- `src/viper_db/dao/__init__.py`
