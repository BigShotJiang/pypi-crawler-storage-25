# v14 — Bookings Eager-Load DAO Method

## Summary

New `get_by_user_with_experience` method on `BookingsDAO` that eagerly loads the `experience`, `neighborhood`, and `restaurant` relationships in a single query. Fixes a `MissingGreenlet` error in viper-api's `GET /bookings/me` caused by implicit lazy-loading of nested relationships inside an async context.

## Changes

### DAO: `BookingsDAO` (`dao/bookings.py`)
- `get_by_user_with_experience(user_id)` — same query as `get_by_user` but with `selectinload` for `Booking.experience → Experience.neighborhood` and `Booking.experience → Experience.restaurant`

## Affected Paths
- `src/viper_db/dao/bookings.py`
