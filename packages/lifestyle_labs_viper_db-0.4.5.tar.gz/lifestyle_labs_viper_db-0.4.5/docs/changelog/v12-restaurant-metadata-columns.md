# v12 — Restaurant Metadata Columns

## What changed

Dropped `appeal_score` from the `restaurants` table and added four new columns sourced from the v18 CSV:

| Column | Type | Source CSV Header |
|---|---|---|
| `notable_dishes` | `text[]` | Most Notable Dishes (5 key dishes) |
| `phone` | `text` | GP_Phone |
| `rating` | `numeric(2,1)` | RATING |
| `review_count` | `integer` | Review Count |

### Migration

`0020_add_restaurant_metadata_drop_appeal_score.py` — drops `appeal_score`, adds the four columns above.

### DAO changes (`dao/experiences.py`)

- Removed `r.appeal_score` from SELECT in `discover_by_embedding`, `fallback_text_search`, `hybrid_discover`, `get_restaurant_by_name`, and `get_restaurant_cards`.
- Removed `r.appeal_score DESC NULLS LAST` from ORDER BY in `discover_by_embedding` (now `distance` only) and `fallback_text_search` (now `e.name ASC`).
- Added `r.notable_dishes`, `r.phone`, `r.rating`, `r.review_count` to SELECT in all five methods.
- Updated card builder dict in `get_restaurant_cards` to include the new fields.

### Affected paths

- `models/restaurant.py`
- `dao/experiences.py`
- `alembic/versions/0020_add_restaurant_metadata_drop_appeal_score.py`
