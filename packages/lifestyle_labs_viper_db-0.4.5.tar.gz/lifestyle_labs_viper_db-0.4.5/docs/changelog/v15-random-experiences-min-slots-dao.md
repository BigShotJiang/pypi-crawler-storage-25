# v15 — get_random_experiences_with_min_slots DAO method

## What was built

New method on `AvailabilitySlotsDAO` that returns randomly selected
experiences with a minimum number of available slots, along with full
restaurant metadata and aggregated slot data.

### Method signature

```python
async def get_random_experiences_with_min_slots(
    self,
    date: dt.date,
    party_size: int = 2,
    min_slots: int = 3,
    limit: int = 3,
    after_time: dt.time | None = None,
) -> list[dict]
```

### SQL strategy

1. **Qualifying CTE** — filters `availability_slots` joined to
   `experiences` by date, party size, `is_available`, `is_active`, and
   optional `after_time`; groups by experience, keeps those with
   `COUNT(*) >= :min_slots`, orders by `random()`, limits to `:limit`.
2. **Main query** — joins qualifying experiences to `restaurants`,
   `neighborhoods`, and a `LATERAL` subquery that aggregates matching
   slots as `json_agg(json_build_object(...))`.

### Return shape

Each dict contains: `experience_id`, `name`, `image_urls`, `address`,
`latitude`, `longitude`, `cuisine`, `url_slug`, `neighborhood`,
`rating`, `review_count`, `notable_dishes`, `availability_slots`.

Compatible with `RestaurantCardRead.model_validate()` in viper-api.

### Bugfix

`address` column referenced as `r.address` (restaurants) — corrected to
`e.address` (experiences) where the column actually lives.

## Affected paths

- `src/viper_db/dao/availability_slots.py`
