"""Shared utilities for the system_spec surface (asset inventory + snapshot kinds).

The platform's diff endpoint (`POST /systems/{id}/spec/inventory/diff`) requires
an `idempotency_key` so retries from a flaky scan can be safely re-posted. The
contract for the key shape is `sha256(system_id, recipe_id, scan_timestamp)`,
first 32 hex chars — picked once in this module so the CLI scan/upload path
and the MCP `submit_asset_inventory_diff` tool produce identical keys for the
same inputs.

`classify_inventory_diff` is the shared client-side classifier used by both the
CSV upload path and every asset-inventory recipe — they all enumerate rows
locally and need to diff against the platform's current snapshot.
"""

from __future__ import annotations

import hashlib
from typing import Any

VALID_SCAN_SOURCES: frozenset[str] = frozenset({"aws", "azure", "k8s", "iac-workspace"})

SCAN_SOURCE_TO_RECIPE_ID: dict[str, str] = {
    "aws": "asset-inventory-aws-baseline",
    "azure": "asset-inventory-azure-baseline",
    "k8s": "asset-inventory-k8s-baseline",
    "iac-workspace": "asset-inventory-iac-workspace",
}

# Fields the platform considers material when deciding if a row is "modified".
# external_id is the join key, not a comparable field. Keep this in sync with
# the CSV column list in `cli/artifacts.py` so behavior matches between paths.
_COMPARE_FIELDS: tuple[str, ...] = (
    "name",
    "asset_type",
    "environment",
    "data_classification",
    "criticality",
    "owner",
    "description",
)


def build_inventory_idempotency_key(
    system_id: str,
    recipe_id: str,
    scan_timestamp: str,
) -> str:
    """Return the first 32 hex chars of sha256(system_id|recipe_id|scan_timestamp).

    The platform deduplicates diff submissions by this key, so the same
    `(system_id, recipe_id, scan_timestamp)` triple from a retry produces the
    same key and the platform short-circuits to the original result instead of
    double-applying the diff.
    """
    payload = f"{system_id}|{recipe_id}|{scan_timestamp}".encode()
    return hashlib.sha256(payload).hexdigest()[:32]


def classify_inventory_diff(
    candidate_rows: list[dict[str, Any]],
    existing_assets: list[dict[str, Any]],
    *,
    decommission_rationale: str = "absent from latest scan",
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Split `candidate_rows` into added / modified / decommissioned vs `existing_assets`.

    - added: external_ids present in candidates but not in existing assets.
    - modified: external_ids in both, with at least one tracked field different.
    - decommissioned: external_ids in existing assets but absent from candidates,
      each row stamped with `decommission_rationale`.

    Both inputs are lists of dicts keyed by `external_id`. Rows without an
    `external_id` are skipped silently — the platform's create path will reject
    them, and surfacing the skip belongs to the caller (which already shows the
    full candidate count vs the diff size).
    """
    candidate_by_ext_id = {str(row["external_id"]): row for row in candidate_rows if row.get("external_id")}
    existing_by_ext_id = {str(asset.get("external_id")): asset for asset in existing_assets if asset.get("external_id")}

    added: list[dict[str, Any]] = []
    modified: list[dict[str, Any]] = []
    decommissioned: list[dict[str, Any]] = []

    for ext_id, row in candidate_by_ext_id.items():
        if ext_id not in existing_by_ext_id:
            added.append(row)
            continue
        existing = existing_by_ext_id[ext_id]
        if any(row.get(field) != existing.get(field) for field in _COMPARE_FIELDS if field in row):
            modified.append(row)

    for ext_id in existing_by_ext_id:
        if ext_id not in candidate_by_ext_id:
            decommissioned.append({"external_id": ext_id, "rationale": decommission_rationale})

    return added, modified, decommissioned
