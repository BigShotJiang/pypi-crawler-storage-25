"""Evidence CLI commands for Pretorin."""

from __future__ import annotations

import asyncio

import typer
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from pretorin.cli.output import is_json_mode, print_json
from pretorin.mcp.helpers import VALID_EVIDENCE_TYPES
from pretorin.utils import normalize_control_id

console = Console()

app = typer.Typer(
    name="evidence",
    help="Local evidence management and platform sync.",
    no_args_is_help=True,
)

ROMEBOT_EVIDENCE = "[#EAB536]\\[°□°][/#EAB536]"
_VALID_EVIDENCE_TYPES = VALID_EVIDENCE_TYPES
_EVIDENCE_TYPE_HELP = "Evidence type (required): " + ", ".join(sorted(_VALID_EVIDENCE_TYPES))


def _require_valid_evidence_type(evidence_type: str) -> None:
    """Exit 1 with a helpful error if the user passed an unsupported type.

    Issue #79: the CLI does NOT run the AI-drift normalizer — users get a
    clear, actionable error instead. Typer's native `Missing option` handles
    the omission case; this helper handles wrong-value cases.
    """
    if evidence_type not in _VALID_EVIDENCE_TYPES:
        rprint(
            f"[red]Invalid evidence type: {evidence_type}. "
            f"Choose one of: {', '.join(sorted(_VALID_EVIDENCE_TYPES))}[/red]"
        )
        raise typer.Exit(1)


@app.command("create")
def evidence_create(
    control_id: str = typer.Argument(..., help="Control ID (e.g., ac-02)"),
    framework_id: str = typer.Argument(..., help="Framework ID (e.g., fedramp-moderate)"),
    description: str = typer.Option(
        ...,
        "--description",
        "-d",
        help="Short human summary of what the evidence demonstrates",
    ),
    artifact_content: str = typer.Option(
        ...,
        "--artifact-content",
        "--artifact",
        help="Markdown body containing the actual evidence",
    ),
    name: str | None = typer.Option(
        None,
        "--name",
        "-n",
        help="Evidence name (defaults to description summary)",
    ),
    evidence_type: str = typer.Option(
        ...,
        "--type",
        "-t",
        help=_EVIDENCE_TYPE_HELP,
    ),
) -> None:
    """Create a local evidence file.

    Creates a markdown file in evidence/<framework>/<control>/<slug>.md
    with YAML frontmatter for tracking.

    Examples:
        pretorin evidence create ac-02 fedramp-moderate \
            -d "RBAC configuration in Kubernetes" --artifact "- Verified..." -t configuration
        pretorin evidence create sc-07 nist-800-53-r5 -d "Firewall rules" --artifact "## Evidence..." -t configuration
    """
    from pretorin.evidence.writer import EvidenceWriter, LocalEvidence
    from pretorin.workflows.markdown_quality import validate_audit_markdown

    _require_valid_evidence_type(evidence_type)
    control_id = normalize_control_id(control_id)
    evidence_name = name or description[:60]

    result = validate_audit_markdown(artifact_content, "evidence_artifact")
    if not result.is_valid:
        rprint(f"[red]Validation failed: {result.error_message()}[/red]")
        raise typer.Exit(1)

    evidence = LocalEvidence(
        control_id=control_id,
        framework_id=framework_id,
        name=evidence_name,
        description=description,
        artifact_content=artifact_content,
        evidence_type=evidence_type,
    )

    writer = EvidenceWriter()
    path = writer.write(evidence)

    if is_json_mode():
        print_json(
            {
                "path": str(path),
                "control_id": control_id,
                "framework_id": framework_id,
                "name": evidence_name,
            }
        )
        return

    rprint(
        Panel(
            f"  [bold]File:[/bold]      {path}\n"
            f"  [bold]Control:[/bold]   {control_id.upper()}\n"
            f"  [bold]Framework:[/bold] {framework_id}\n"
            f"  [bold]Type:[/bold]      {evidence_type}",
            title=f"{ROMEBOT_EVIDENCE}  Evidence Created",
            border_style="#95D7E0",
            padding=(1, 2),
        )
    )
    rprint("[dim]Edit the file to add details, then push with: pretorin evidence push[/dim]")


@app.command("list")
def evidence_list(
    framework: str | None = typer.Option(
        None,
        "--framework",
        "-f",
        help="Filter by framework ID",
    ),
) -> None:
    """List local evidence files.

    Examples:
        pretorin evidence list
        pretorin evidence list --framework fedramp-moderate
    """
    from pretorin.evidence.writer import EvidenceWriter

    writer = EvidenceWriter()
    items = writer.list_local(framework)

    if is_json_mode():
        print_json(
            [
                {
                    "control_id": e.control_id,
                    "framework_id": e.framework_id,
                    "name": e.name,
                    "evidence_type": e.evidence_type,
                    "status": e.status,
                    "platform_id": e.platform_id,
                    "path": str(e.path),
                }
                for e in items
            ]
        )
        return

    if not items:
        rprint("[dim]No local evidence found.[/dim]")
        rprint(
            '[dim]Create one with: [bold]pretorin evidence create ac-02 fedramp-moderate -d "description"[/bold][/dim]'
        )
        return

    table = Table(title="Local Evidence", show_header=True, header_style="bold")
    table.add_column("Control", style="cyan")
    table.add_column("Framework")
    table.add_column("Name")
    table.add_column("Type")
    table.add_column("Synced")

    for e in items:
        synced = "[#95D7E0]Yes[/#95D7E0]" if e.platform_id else "[dim]No[/dim]"
        table.add_row(
            e.control_id.upper(),
            e.framework_id,
            e.name[:40] + "..." if len(e.name) > 40 else e.name,
            e.evidence_type,
            synced,
        )

    console.print(table)
    rprint(f"\n[dim]Total: {len(items)} evidence item(s)[/dim]")


@app.command("push")
def evidence_push(
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be pushed without pushing"),
) -> None:
    """Push local evidence to the Pretorin platform.

    New evidence (without platform_id) is upserted on the platform.
    Already-synced evidence is skipped.

    Examples:
        pretorin evidence push --dry-run
        pretorin evidence push
    """
    asyncio.run(_push_evidence(dry_run))


async def _push_evidence(dry_run: bool) -> None:
    """Push evidence to platform."""
    from pretorin.cli.commands import require_auth
    from pretorin.client.api import PretorianClient, PretorianClientError
    from pretorin.evidence.sync import EvidenceSync

    async with PretorianClient() as client:
        require_auth(client)

        sync = EvidenceSync()

        if not is_json_mode():
            mode = "[yellow]DRY RUN[/yellow] " if dry_run else ""
            rprint(f"\n  {ROMEBOT_EVIDENCE}  {mode}Pushing evidence to platform...\n")

        try:
            result = await sync.push(client, dry_run=dry_run)
        except PretorianClientError as e:
            rprint(f"[red]Push failed: {e.message}[/red]")
            raise typer.Exit(1)

        if is_json_mode():
            print_json(
                {
                    "created": result.created,
                    "reused": result.reused,
                    "skipped": result.skipped,
                    "errors": result.errors,
                    # Deprecated: retained for compatibility.
                    "events": result.events,
                }
            )
            return

        if result.created:
            rprint("[bold]Created:[/bold]")
            for item in result.created:
                rprint(f"  [#95D7E0]+[/#95D7E0] {item}")

        if result.reused:
            rprint("\n[bold]Reused:[/bold]")
            for item in result.reused:
                rprint(f"  [#EAB536]=[/#EAB536] {item}")

        if result.skipped:
            rprint(f"\n[dim]Skipped {len(result.skipped)} already-synced item(s)[/dim]")

        if result.errors:
            rprint("\n[bold red]Errors:[/bold red]")
            for err in result.errors:
                rprint(f"  [red]![/red] {err}")

        if not result.created and not result.reused and not result.errors:
            rprint("[dim]Nothing to push — all evidence is already synced.[/dim]")


@app.command("link")
def evidence_link(
    evidence_id: str = typer.Argument(..., help="Evidence item ID"),
    control_id: str = typer.Argument(..., help="Control ID to link to (e.g., ac-02)"),
    framework_id: str | None = typer.Option(None, "--framework-id", "-f", help="Framework ID."),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID."),
) -> None:
    """Link an existing evidence item to a control.

    Examples:
        pretorin evidence link abc123 ac-02
        pretorin evidence link abc123 sc-07 --framework-id fedramp-moderate
    """
    asyncio.run(
        _link_evidence(
            evidence_id=evidence_id,
            control_id=normalize_control_id(control_id),
            framework_id=framework_id,
            system=system,
        )
    )


async def _link_evidence(
    evidence_id: str,
    control_id: str,
    framework_id: str | None,
    system: str | None,
) -> None:
    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, resolved_framework_id = await resolve_execution_context(
                client,
                system=system,
                framework=framework_id,
            )
            system_name = (await client.get_system(system_id)).name
            result = await client.link_evidence_to_control(
                evidence_id=evidence_id,
                control_id=control_id,
                system_id=system_id,
                framework_id=resolved_framework_id,
            )
        except PretorianClientError as e:
            rprint(f"[red]Link failed: {e.message}[/red]")
            raise typer.Exit(1)

        payload = {
            "system_id": system_id,
            "system_name": system_name,
            "evidence_id": evidence_id,
            "control_id": control_id,
            "framework_id": resolved_framework_id,
            "result": result,
        }
        if is_json_mode():
            print_json(payload)
            return

        rprint(
            Panel(
                f"  [bold]System:[/bold]      {system_name}\n"
                f"  [bold]Evidence ID:[/bold] {evidence_id}\n"
                f"  [bold]Control:[/bold]     {control_id.upper()}\n"
                f"  [bold]Framework:[/bold]   {resolved_framework_id}",
                title=f"{ROMEBOT_EVIDENCE}  Evidence Linked",
                border_style="#95D7E0",
                padding=(1, 2),
            )
        )


@app.command("link-cci")
def evidence_link_cci(
    evidence_id: str = typer.Argument(..., help="Evidence item ID"),
    cci_implementation_id: str = typer.Argument(..., help="CCI implementation row UUID (per-system)"),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID."),
    override_system_mismatch: bool = typer.Option(
        False, "--override-system-mismatch", help="Permit cross-system attachment (requires --override-reason)."
    ),
    override_reason: str | None = typer.Option(
        None, "--override-reason", help="Justification when overriding system-mismatch."
    ),
) -> None:
    """Link an evidence item to a per-system CCI implementation row."""
    asyncio.run(
        _link_evidence_cci(
            evidence_id=evidence_id,
            cci_implementation_id=cci_implementation_id,
            system=system,
            override_system_mismatch=override_system_mismatch,
            override_reason=override_reason,
        )
    )


async def _link_evidence_cci(
    evidence_id: str,
    cci_implementation_id: str,
    system: str | None,
    override_system_mismatch: bool,
    override_reason: str | None,
) -> None:
    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError

    if override_system_mismatch and not override_reason:
        rprint("[red]--override-reason is required when --override-system-mismatch is set.[/red]")
        raise typer.Exit(1)

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _ = await resolve_execution_context(client, system=system)
            system_name = (await client.get_system(system_id)).name
            result = await client.link_evidence_to_cci_implementation(
                evidence_id=evidence_id,
                cci_implementation_id=cci_implementation_id,
                system_id=system_id,
                override_system_mismatch=override_system_mismatch,
                override_reason=override_reason,
            )
        except PretorianClientError as e:
            rprint(f"[red]Link failed: {e.message}[/red]")
            raise typer.Exit(1)

        payload = {
            "system_id": system_id,
            "system_name": system_name,
            "evidence_id": evidence_id,
            "cci_implementation_id": cci_implementation_id,
            "result": result,
        }
        if is_json_mode():
            print_json(payload)
            return

        rprint(
            Panel(
                f"  [bold]System:[/bold]       {system_name}\n"
                f"  [bold]Evidence ID:[/bold]  {evidence_id}\n"
                f"  [bold]CCI Impl ID:[/bold]  {cci_implementation_id}",
                title=f"{ROMEBOT_EVIDENCE}  Evidence Linked → CCI Implementation",
                border_style="#95D7E0",
                padding=(1, 2),
            )
        )


@app.command("link-stig")
def evidence_link_stig(
    evidence_id: str = typer.Argument(..., help="Evidence item ID"),
    stig_rule_id: str = typer.Argument(..., help="STIG catalog rule UUID"),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID."),
    override_system_mismatch: bool = typer.Option(
        False, "--override-system-mismatch", help="Permit cross-system attachment (requires --override-reason)."
    ),
    override_reason: str | None = typer.Option(
        None, "--override-reason", help="Justification when overriding system-mismatch."
    ),
) -> None:
    """Link an evidence item to a STIG rule workflow (lazy-creates the row).

    Use this to attach remediation proof, mitigating-control documentation, or
    waiver-justification artifacts to a failing rule.
    """
    asyncio.run(
        _link_evidence_stig(
            evidence_id=evidence_id,
            stig_rule_id=stig_rule_id,
            system=system,
            override_system_mismatch=override_system_mismatch,
            override_reason=override_reason,
        )
    )


async def _link_evidence_stig(
    evidence_id: str,
    stig_rule_id: str,
    system: str | None,
    override_system_mismatch: bool,
    override_reason: str | None,
) -> None:
    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError

    if override_system_mismatch and not override_reason:
        rprint("[red]--override-reason is required when --override-system-mismatch is set.[/red]")
        raise typer.Exit(1)

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _ = await resolve_execution_context(client, system=system)
            system_name = (await client.get_system(system_id)).name
            result = await client.link_evidence_to_stig_rule_workflow(
                evidence_id=evidence_id,
                stig_rule_id=stig_rule_id,
                system_id=system_id,
                override_system_mismatch=override_system_mismatch,
                override_reason=override_reason,
            )
        except PretorianClientError as e:
            rprint(f"[red]Link failed: {e.message}[/red]")
            raise typer.Exit(1)

        payload = {
            "system_id": system_id,
            "system_name": system_name,
            "evidence_id": evidence_id,
            "stig_rule_id": stig_rule_id,
            "result": result,
        }
        if is_json_mode():
            print_json(payload)
            return

        rprint(
            Panel(
                f"  [bold]System:[/bold]       {system_name}\n"
                f"  [bold]Evidence ID:[/bold]  {evidence_id}\n"
                f"  [bold]STIG Rule:[/bold]    {stig_rule_id}",
                title=f"{ROMEBOT_EVIDENCE}  Evidence Linked → STIG Rule Workflow",
                border_style="#95D7E0",
                padding=(1, 2),
            )
        )


@app.command("search")
def evidence_search(
    control_id: str | None = typer.Option(None, "--control-id", "-c", help="Optional control ID filter."),
    framework_id: str | None = typer.Option(None, "--framework-id", "-f", help="Framework ID."),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID."),
    limit: int = typer.Option(50, "--limit", "-n", help="Max results."),
) -> None:
    """Search platform evidence items within one active system/framework scope."""
    asyncio.run(
        _search_evidence(
            control_id=control_id,
            framework_id=framework_id,
            system=system,
            limit=limit,
        )
    )


async def _search_evidence(
    control_id: str | None,
    framework_id: str | None,
    system: str | None,
    limit: int,
) -> None:
    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError

    control_filter = normalize_control_id(control_id) if control_id else None

    async with PretorianClient() as client:
        require_auth(client)

        try:
            system_id, resolved_framework_id = await resolve_execution_context(
                client,
                system=system,
                framework=framework_id,
            )
            system_name = (await client.get_system(system_id)).name
            items = await client.list_evidence(
                system_id=system_id,
                framework_id=resolved_framework_id,
                control_id=control_filter,
                limit=limit,
            )
        except PretorianClientError as e:
            rprint(f"[red]Search failed: {e.message}[/red]")
            raise typer.Exit(1)

        if is_json_mode():
            print_json(
                {
                    "scope": f"system:{system_id}/framework:{resolved_framework_id}",
                    "system_name": system_name,
                    "framework_id": resolved_framework_id,
                    "total": len(items),
                    "evidence": [item.model_dump() for item in items],
                }
            )
            return

        scope = f"[bold]{system_name}[/bold] / [bold]{resolved_framework_id}[/bold]"
        rprint(f"\n  {ROMEBOT_EVIDENCE}  Evidence Search Scope: {scope}\n")
        if not items:
            rprint("[dim]No evidence found for the current filters.[/dim]")
            return

        table = Table(title="Platform Evidence", show_header=True, header_style="bold")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Name")
        table.add_column("Type")
        table.add_column("Status")

        for item in items:
            table.add_row(item.id[:8], item.name, item.evidence_type or "-", item.status or "-")

        console.print(table)
        rprint(f"\n[dim]Total: {len(items)} evidence item(s)[/dim]")


@app.command("upsert")
def evidence_upsert(
    control_id: str = typer.Argument(..., help="Control ID (e.g., ac-02)"),
    framework_id: str = typer.Argument(..., help="Framework ID (e.g., fedramp-moderate)"),
    name: str = typer.Option(..., "--name", "-n", help="Evidence name"),
    description: str = typer.Option(
        ...,
        "--description",
        "-d",
        help="Short human summary of what the evidence demonstrates.",
    ),
    artifact_content: str = typer.Option(
        ...,
        "--artifact-content",
        "--artifact",
        help="Markdown body containing the actual evidence artifact.",
    ),
    evidence_type: str = typer.Option(..., "--type", "-t", help="Evidence type (required)."),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID."),
    code_file: str | None = typer.Option(None, "--code-file", help="Path to source file."),
    code_lines: str | None = typer.Option(None, "--code-lines", help="Line range (e.g., '10-25')."),
    code_repo: str | None = typer.Option(None, "--code-repo", help="Git repository URL."),
    code_commit: str | None = typer.Option(None, "--code-commit", help="Git commit hash."),
    coverage_start: str | None = typer.Option(
        None,
        "--coverage-start",
        help="ISO 8601 start of the period the evidence content describes (auditor sufficiency).",
    ),
    coverage_end: str | None = typer.Option(
        None,
        "--coverage-end",
        help="ISO 8601 end of the period; omit for point-in-time evidence.",
    ),
    capture_query: str | None = typer.Option(
        None,
        "--capture-query",
        help="Query / filter / command that produced the artifact (IPE reproducibility).",
    ),
    source_uri: str | None = typer.Option(
        None,
        "--source-uri",
        help="Stable source path, URL, object id, report id, or export id used for provenance.",
    ),
    source_label: str | None = typer.Option(
        None,
        "--source-label",
        help="Human-readable source title or section label for auditors.",
    ),
    source_locator: str | None = typer.Option(
        None,
        "--source-locator",
        help="Precise source locator, e.g. section id or 'lines 84-88'.",
    ),
    source_excerpt: str | None = typer.Option(
        None,
        "--source-excerpt",
        help="Short quoted excerpt or source material used to produce the evidence claim.",
    ),
    capture_method: str | None = typer.Option(
        None,
        "--capture-method",
        help="Source capture method, e.g. repository_file_read, api_export, scanner_output.",
    ),
    cadence_days: int | None = typer.Option(
        None,
        "--cadence-days",
        help=(
            "Refresh cadence in days. Evidence will require re-verification "
            "after this many days; computes expires_at server-side. "
            "Continuous compliance (issue #108)."
        ),
        min=1,
        max=365,
    ),
) -> None:
    """Find-or-create evidence and ensure system/control link."""
    _require_valid_evidence_type(evidence_type)

    asyncio.run(
        _upsert_evidence(
            control_id=normalize_control_id(control_id),
            framework_id=framework_id,
            name=name,
            description=description,
            artifact_content=artifact_content,
            evidence_type=evidence_type,
            system=system,
            code_file=code_file,
            code_lines=code_lines,
            code_repo=code_repo,
            code_commit=code_commit,
            data_coverage_start_at=coverage_start,
            data_coverage_end_at=coverage_end,
            capture_query=capture_query,
            source_uri=source_uri,
            source_label=source_label,
            source_locator=source_locator,
            source_excerpt=source_excerpt,
            capture_method=capture_method,
            refresh_cadence_days=cadence_days,
        )
    )


async def _upsert_evidence(
    control_id: str,
    framework_id: str,
    name: str,
    description: str,
    artifact_content: str,
    evidence_type: str,
    system: str | None,
    code_file: str | None = None,
    code_lines: str | None = None,
    code_repo: str | None = None,
    code_commit: str | None = None,
    data_coverage_start_at: str | None = None,
    data_coverage_end_at: str | None = None,
    capture_query: str | None = None,
    source_uri: str | None = None,
    source_label: str | None = None,
    source_locator: str | None = None,
    source_excerpt: str | None = None,
    capture_method: str | None = None,
    refresh_cadence_days: int | None = None,
) -> None:
    from pathlib import Path

    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError
    from pretorin.client.models import EvidenceCodeContext
    from pretorin.evidence.audit_metadata import (
        build_cli_metadata,
        evidence_type_to_source_type,
        source_lines_from_locator,
    )
    from pretorin.workflows.compliance_updates import upsert_evidence
    from pretorin.workflows.evidence_validation import validate_code_reference

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, resolved_framework_id = await resolve_execution_context(
                client,
                system=system,
                framework=framework_id,
            )
            system_name = (await client.get_system(system_id)).name

            # Build code context from CLI options, auto-populate from snapshot if needed.
            code_context: EvidenceCodeContext = {}
            if code_file:
                code_context["code_file_path"] = code_file
            if code_lines:
                code_context["code_line_numbers"] = code_lines
            if code_repo:
                code_context["code_repository"] = code_repo
            if code_commit:
                code_context["code_commit_hash"] = code_commit

            if code_file:
                validated = validate_code_reference(
                    code_file_path=code_file,
                    code_line_numbers=code_lines,
                    working_dir=Path.cwd(),
                )
                if validated:
                    code_context.update(validated)

            # Auto-populate repo/commit from attested snapshot if not provided.
            if not code_repo or not code_commit:
                from pretorin.attestation import extract_git_context_from_snapshot

                git_ctx = extract_git_context_from_snapshot(system_id, resolved_framework_id)
                if git_ctx:
                    if not code_repo and "code_repository" in git_ctx:
                        code_context["code_repository"] = git_ctx["code_repository"]
                    if not code_commit and "code_commit_hash" in git_ctx:
                        code_context["code_commit_hash"] = git_ctx["code_commit_hash"]

            # WS1b: stamp audit-trail metadata for this CLI manual write.
            # source_uri prefers a real file ref when --code-file was supplied;
            # falls back to a pretorin:// sentinel describing the platform context.
            resolved_source_uri = source_uri or (
                f"file://{code_context['code_file_path']}"
                if "code_file_path" in code_context
                else f"pretorin://systems/{system_id}/controls/{control_id}"
            )
            resolved_source_locator = source_locator or (f"lines {code_lines}" if code_lines else None)
            resolved_source_excerpt = (
                source_excerpt or code_context.get("code_snippet") or artifact_content or description
            )
            audit = build_cli_metadata(
                body=resolved_source_excerpt,
                source_uri=resolved_source_uri,
                source_type=evidence_type_to_source_type(evidence_type),
                source_label=source_label or code_context.get("code_file_path") or name,
                source_locator=resolved_source_locator,
                source_lines=source_lines_from_locator(resolved_source_locator),
                source_version=code_context.get("code_commit_hash"),
                source_excerpt=resolved_source_excerpt,
                capture_method=capture_method or ("repository_file_read" if code_file else "cli_manual_entry"),
            )

            result = await upsert_evidence(
                client,
                system_id=system_id,
                name=name,
                description=description,
                artifact_content=artifact_content,
                evidence_type=evidence_type,
                control_id=control_id,
                framework_id=resolved_framework_id,
                source="cli",
                dedupe=True,
                code_context=code_context or None,
                audit_metadata=audit,
                data_coverage_start_at=data_coverage_start_at,
                data_coverage_end_at=data_coverage_end_at,
                capture_query=capture_query,
                refresh_cadence_days=refresh_cadence_days,
            )
        except ValueError as e:
            rprint(f"[red]Upsert failed: {e}[/red]")
            raise typer.Exit(1)
        except PretorianClientError as e:
            rprint(f"[red]Upsert failed: {e.message}[/red]")
            raise typer.Exit(1)

        payload = result.to_dict()
        payload.update(
            {
                "system_id": system_id,
                "system_name": system_name,
                "control_id": control_id,
                "framework_id": resolved_framework_id,
            }
        )
        if is_json_mode():
            print_json(payload)
            return

        action = "Created" if result.created else "Reused"
        link_state = "linked" if result.linked else "link_pending"
        rprint(
            Panel(
                f"  [bold]Action:[/bold]    {action}\n"
                f"  [bold]Evidence ID:[/bold] {result.evidence_id}\n"
                f"  [bold]System:[/bold]    {system_name}\n"
                f"  [bold]Control:[/bold]   {control_id.upper()}\n"
                f"  [bold]Framework:[/bold] {resolved_framework_id}\n"
                f"  [bold]Link:[/bold]      {link_state}\n",
                title=f"{ROMEBOT_EVIDENCE}  Evidence Upserted",
                border_style="#95D7E0",
                padding=(1, 2),
            )
        )
        if result.link_error:
            rprint(f"[yellow]Warning: evidence link failed: {result.link_error}[/yellow]")


@app.command("mark-current")
def evidence_mark_current(
    evidence_id: str = typer.Argument(..., help="Evidence ID to re-verify."),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID."),
) -> None:
    """Re-affirm that evidence is still current (issue #108 PR B).

    Bumps ``expires_at`` by ``refresh_cadence_days``, transitions ``status``
    from ``expired`` back to ``valid`` if needed, and auto-resolves any open
    ``evidence.expiring`` / ``evidence.expired`` monitoring events. Fails
    with HTTP 400 if the evidence has no refresh cadence set.

    Example:
        pretorin evidence mark-current 0d3fe381-7d90-4734-bc8c-aff690cda4d8
    """
    asyncio.run(_mark_current(evidence_id=evidence_id, system=system))


async def _mark_current(*, evidence_id: str, system: str | None) -> None:
    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _ = await resolve_execution_context(client, system=system)
            response = await client.mark_evidence_current(system_id, evidence_id)
        except ValueError as e:
            rprint(f"[red]Mark-current failed: {e}[/red]")
            raise typer.Exit(1)
        except PretorianClientError as e:
            rprint(f"[red]Mark-current failed: {e.message}[/red]")
            raise typer.Exit(1)

        if is_json_mode():
            print_json(response)
            return

        rprint(
            Panel(
                f"  [bold]Evidence:[/bold]    {response.get('id', evidence_id)}\n"
                f"  [bold]Status:[/bold]      {response.get('status', '?')}\n"
                f"  [bold]Expires at:[/bold]  {response.get('expires_at', '—')}\n"
                f"  [bold]Cadence:[/bold]     "
                f"{response.get('refresh_cadence_days', '—')} days",
                title=f"{ROMEBOT_EVIDENCE}  Evidence Re-Verified",
                border_style="#95D7E0",
                padding=(1, 2),
            )
        )


@app.command("validate")
def evidence_validate(
    evidence_id: str = typer.Argument(..., help="Evidence ID to validate against recorded source provenance."),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID."),
    source_root: str | None = typer.Option(
        None,
        "--source-root",
        help="Root directory for relative file-backed source_uri values (defaults to current directory).",
    ),
    artifact_content: str | None = typer.Option(
        None,
        "--artifact-content",
        "--artifact",
        help=(
            "Updated Markdown artifact body to use if drift is detected; otherwise "
            "a simple excerpt artifact is generated."
        ),
    ),
    description: str | None = typer.Option(
        None,
        "--description",
        "-d",
        help="Updated short summary to use if drift is detected.",
    ),
    drift_note: str = typer.Option(
        "Validation detected source drift. Review the updated artifact before marking this control current.",
        "--drift-note",
        help="Reviewer-facing note to create when drift is detected.",
    ),
) -> None:
    """Validate evidence freshness before re-verifying or replacing its artifact.

    Reads the existing evidence's ``audit_metadata.content_hash`` and recorded
    file source context. If the fresh source-material hash is unchanged, calls
    ``mark-current``. If it changed, replaces the Markdown artifact and sends a
    drift note instead of silently marking the evidence current.
    """
    asyncio.run(
        _validate_evidence(
            evidence_id=evidence_id,
            system=system,
            source_root=source_root,
            artifact_content=artifact_content,
            description=description,
            drift_note=drift_note,
        )
    )


async def _validate_evidence(
    *,
    evidence_id: str,
    system: str | None,
    source_root: str | None,
    artifact_content: str | None,
    description: str | None,
    drift_note: str,
) -> None:
    from pathlib import Path

    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError
    from pretorin.workflows.evidence_validation import validate_evidence_source

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _ = await resolve_execution_context(client, system=system)
            result = await validate_evidence_source(
                client,
                system_id=system_id,
                evidence_id=evidence_id,
                source_root=Path(source_root) if source_root else None,
                artifact_content=artifact_content,
                description=description,
                drift_note=drift_note,
            )
        except ValueError as e:
            rprint(f"[red]Validation failed: {e}[/red]")
            raise typer.Exit(1)
        except PretorianClientError as e:
            rprint(f"[red]Validation failed: {e.message}[/red]")
            raise typer.Exit(1)

        if is_json_mode():
            print_json(result)
            return

        action = result.get("action")
        if action == "marked_current":
            title = f"{ROMEBOT_EVIDENCE}  Evidence Re-Verified"
            body = (
                f"  [bold]Evidence:[/bold]      {evidence_id}\n"
                f"  [bold]Source hash:[/bold]   {result.get('content_hash')}\n"
                "  [bold]Action:[/bold]        marked current"
            )
        else:
            title = f"{ROMEBOT_EVIDENCE}  Evidence Artifact Updated"
            body = (
                f"  [bold]Evidence:[/bold]      {evidence_id}\n"
                f"  [bold]Previous hash:[/bold] {result.get('previous_content_hash')}\n"
                f"  [bold]Fresh hash:[/bold]    {result.get('content_hash')}\n"
                "  [bold]Action:[/bold]        artifact replaced with drift note"
            )
        rprint(Panel(body, title=title, border_style="#95D7E0", padding=(1, 2)))


@app.command("upload")
def evidence_upload(
    file_path: str = typer.Argument(..., help="Path to the file to upload"),
    control_id: str = typer.Argument(..., help="Control ID to link to (e.g., ac-02)"),
    framework_id: str = typer.Argument(..., help="Framework ID (e.g., fedramp-moderate)"),
    name: str = typer.Option(..., "--name", "-n", help="Evidence name"),
    evidence_type: str = typer.Option("other", "--type", "-t", help="Evidence type"),
    description: str | None = typer.Option(None, "--description", "-d", help="Evidence description"),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID"),
) -> None:
    """Upload a file as evidence to the platform.

    Creates an evidence record with the uploaded file and links it to the
    specified control. The file's SHA-256 checksum is computed locally and
    verified server-side for integrity.

    Examples:
        pretorin evidence upload screenshot.png ac-02 fedramp-moderate --name "MFA Screenshot" --type screenshot
        pretorin evidence upload config.yaml ac-06 fedramp-moderate --name "Auth Config" --type configuration
    """
    if evidence_type not in _VALID_EVIDENCE_TYPES:
        rprint(
            f"[red]Invalid evidence type: {evidence_type}. "
            f"Choose one of: {', '.join(sorted(_VALID_EVIDENCE_TYPES))}[/red]"
        )
        raise typer.Exit(1)

    asyncio.run(
        _upload_evidence(
            file_path=file_path,
            control_id=normalize_control_id(control_id),
            framework_id=framework_id,
            name=name,
            evidence_type=evidence_type,
            description=description,
            system=system,
        )
    )


async def _upload_evidence(
    file_path: str,
    control_id: str,
    framework_id: str,
    name: str,
    evidence_type: str,
    description: str | None,
    system: str | None,
) -> None:
    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, resolved_framework_id = await resolve_execution_context(
                client,
                system=system,
                framework=framework_id,
            )
            result = await client.upload_evidence(
                system_id=system_id,
                file_path=file_path,
                name=name,
                evidence_type=evidence_type,
                description=description,
                control_id=control_id,
                framework_id=resolved_framework_id,
            )
        except PretorianClientError as e:
            rprint(f"[red]Upload failed: {e.message}[/red]")
            raise typer.Exit(1)
        except FileNotFoundError:
            rprint(f"[red]File not found: {file_path}[/red]")
            raise typer.Exit(1)

        if is_json_mode():
            print_json(result)
            return

        rprint(
            Panel(
                f"  [bold]Evidence ID:[/bold] {result.get('evidence_id', 'N/A')}\n"
                f"  [bold]File:[/bold]        {result.get('file_name', 'N/A')}\n"
                f"  [bold]Size:[/bold]        {result.get('file_size', 0)} bytes\n"
                f"  [bold]Checksum:[/bold]    {result.get('checksum', 'N/A')}\n"
                f"  [bold]Type:[/bold]        {result.get('evidence_type', 'N/A')}\n",
                title=f"{ROMEBOT_EVIDENCE}  Evidence Uploaded",
                border_style="#95D7E0",
                padding=(1, 2),
            )
        )


@app.command("delete")
def evidence_delete(
    evidence_id: str = typer.Argument(..., help="Evidence item ID"),
    system: str | None = typer.Option(None, "--system", "-s", help="System name or ID."),
    framework_id: str | None = typer.Option(None, "--framework-id", "-f", help="Framework ID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Delete an evidence item from the platform.

    Permanently removes the evidence item and its associated embeddings.
    This operation is system-scoped and requires WRITE access.

    Examples:
        pretorin evidence delete ev-abc123
        pretorin evidence delete ev-abc123 --yes
        pretorin evidence delete ev-abc123 --system "My App" --yes
    """
    if not yes:
        confirm = typer.confirm(f"Delete evidence {evidence_id}?")
        if not confirm:
            rprint("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    asyncio.run(
        _delete_evidence(
            evidence_id=evidence_id,
            system=system,
            framework_id=framework_id,
        )
    )


async def _delete_evidence(
    evidence_id: str,
    system: str | None,
    framework_id: str | None,
) -> None:
    from pretorin.cli.commands import require_auth
    from pretorin.cli.context import resolve_execution_context
    from pretorin.client.api import PretorianClient, PretorianClientError

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _resolved_framework_id = await resolve_execution_context(
                client,
                system=system,
                framework=framework_id,
            )
            await client.delete_evidence(system_id=system_id, evidence_id=evidence_id)
        except PretorianClientError as e:
            rprint(f"[red]Delete failed: {e.message}[/red]")
            raise typer.Exit(1)

        if is_json_mode():
            print_json({"evidence_id": evidence_id, "deleted": True})
            return

        rprint(f"[green]Evidence {evidence_id} deleted.[/green]")
