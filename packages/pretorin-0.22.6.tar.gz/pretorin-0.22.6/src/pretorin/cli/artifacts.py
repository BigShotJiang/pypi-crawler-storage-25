"""`pretorin scope artifacts ...` — system_spec CLI surface (issue #133).

Wraps the public `/systems/{id}/spec/*` REST endpoints (monorepo PR #859).
Mounted onto the existing `scope` Typer app so the operator surface lives at
`pretorin scope artifacts ...`.

The 5 commands map to:
- artifacts list                          → list_spec_kinds
- artifacts inventory show [--as-of T]    → get_asset_inventory
- artifacts inventory upload <csv>        → submit_inventory_diff
- artifacts inventory scan <source>       → recipe run + submit_inventory_diff
- artifacts toggle <kind> --optional ...  → toggle_spec_kind

The two write paths (`upload` and `scan`) classify candidate rows client-side
into `added` / `modified` / `decommissioned` by diffing against the current
platform inventory, then post a single diff. This is the contract documented
in the issue's pinned comment.
"""

from __future__ import annotations

import asyncio
import csv
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from pretorin.cli.commands import require_auth
from pretorin.cli.context import resolve_execution_context
from pretorin.cli.output import is_json_mode, print_json
from pretorin.client import PretorianClient
from pretorin.client.api import PretorianClientError
from pretorin.recipes.context import get_default_store
from pretorin.recipes.errors import RecipeContextAlreadyActiveError, RecipeContextError, RecipeError
from pretorin.recipes.registry import RecipeRegistry
from pretorin.recipes.runner import RecipeScriptContext, run_script
from pretorin.spec import (
    SCAN_SOURCE_TO_RECIPE_ID,
    VALID_SCAN_SOURCES,
    build_inventory_idempotency_key,
    classify_inventory_diff,
)

app = typer.Typer(
    name="artifacts",
    help="Auditor-required system_spec artifacts: asset inventory + 4 snapshot kinds.",
    no_args_is_help=True,
)

inventory_app = typer.Typer(
    name="inventory",
    help="View, upload, and scan the system's asset inventory.",
    no_args_is_help=True,
)
app.add_typer(inventory_app, name="inventory")

console = Console()

# Whitelisted CSV columns we'll forward to the platform — extra columns are
# silently dropped. external_id is the only true requirement; the platform
# validates the rest.
_CSV_FIELDS: tuple[str, ...] = (
    "external_id",
    "name",
    "asset_type",
    "environment",
    "data_classification",
    "criticality",
    "owner",
    "description",
)


# ---------------------------------------------------------------------------
# `pretorin scope artifacts list`
# ---------------------------------------------------------------------------


@app.command("list")
def artifacts_list(
    system: str | None = typer.Option(
        None,
        "--system",
        "-s",
        help="System name or ID (uses active context if not set).",
    ),
) -> None:
    """List the 5 artifact kinds with their required/toggle/attest state."""
    asyncio.run(_artifacts_list(system=system))


async def _artifacts_list(system: str | None) -> None:
    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _ = await resolve_execution_context(client, system=system, framework=None)
            payload = await client.list_spec_kinds(system_id)
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

    if is_json_mode():
        print_json(payload)
        return

    kinds = payload.get("kinds") if isinstance(payload, dict) else None
    if not isinstance(kinds, list) or not kinds:
        rprint("[dim]No artifact kinds returned.[/dim]")
        return

    table = Table(title=f"Artifact Kinds — {system_id}", show_header=True, header_style="bold")
    table.add_column("Kind", style="cyan")
    table.add_column("Required")
    table.add_column("Toggled-off")
    table.add_column("Attested-at")
    table.add_column("Notes", max_width=50)
    for kind in kinds:
        if not isinstance(kind, dict):
            continue
        required = "yes" if kind.get("effective_required") else "no"
        # Server's write schema uses `toggled_off`; tolerate legacy `optional` too.
        toggled_off = "yes" if (kind.get("toggled_off") or kind.get("optional")) else "—"
        attested_at = kind.get("attested_at") or "—"
        notes = kind.get("rationale") or ""
        table.add_row(str(kind.get("kind", "?")), required, toggled_off, str(attested_at), notes)
    console.print(table)


# ---------------------------------------------------------------------------
# `pretorin scope artifacts inventory show`
# ---------------------------------------------------------------------------


@inventory_app.command("show")
def inventory_show(
    system: str | None = typer.Option(
        None,
        "--system",
        "-s",
        help="System name or ID (uses active context if not set).",
    ),
    as_of: str | None = typer.Option(
        None,
        "--as-of",
        help="ISO-8601 timestamp for historical replay. Defaults to active rows.",
    ),
) -> None:
    """Show the current (or historical) asset inventory."""
    asyncio.run(_inventory_show(system=system, as_of=as_of))


async def _inventory_show(system: str | None, as_of: str | None) -> None:
    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _ = await resolve_execution_context(client, system=system, framework=None)
            payload = await client.get_asset_inventory(system_id, as_of=as_of)
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

    if is_json_mode():
        print_json(payload)
        return

    assets = payload.get("items") if isinstance(payload, dict) else None
    if not isinstance(assets, list) or not assets:
        rprint("[dim]Inventory is empty.[/dim]")
        return

    title = f"Asset Inventory — {system_id}" + (f" (as_of {as_of})" if as_of else "")
    table = Table(title=title, show_header=True, header_style="bold")
    table.add_column("External ID", style="cyan", no_wrap=True)
    table.add_column("Name", max_width=40)
    table.add_column("Type")
    table.add_column("Env")
    table.add_column("Criticality")
    table.add_column("Data Class.")
    for asset in assets:
        if not isinstance(asset, dict):
            continue
        table.add_row(
            str(asset.get("external_id", "?")),
            str(asset.get("name", "")),
            str(asset.get("asset_type", "")),
            str(asset.get("environment", "")),
            str(asset.get("criticality", "")),
            str(asset.get("data_classification", "")),
        )
    console.print(table)
    rprint(f"\n[dim]Total: {len(assets)} asset(s)[/dim]")


# ---------------------------------------------------------------------------
# Diff classification — shared by `upload` and `scan`
# ---------------------------------------------------------------------------


def _print_diff_preview(
    added: list[dict[str, Any]],
    modified: list[dict[str, Any]],
    decommissioned: list[dict[str, Any]],
) -> None:
    table = Table(title="Proposed inventory diff", show_header=True, header_style="bold")
    table.add_column("Outcome", style="cyan", no_wrap=True)
    table.add_column("External ID")
    table.add_column("Detail", max_width=60)
    for row in added:
        table.add_row("add", str(row.get("external_id", "?")), str(row.get("name", "")))
    for row in modified:
        table.add_row("modify", str(row.get("external_id", "?")), str(row.get("name", "")))
    for row in decommissioned:
        table.add_row("decommission", str(row.get("external_id", "?")), str(row.get("rationale", "")))
    console.print(table)
    rprint(f"[dim]Added: {len(added)} · Modified: {len(modified)} · Decommissioned: {len(decommissioned)}[/dim]")


def _print_diff_response(response: dict[str, Any]) -> None:
    """Render the diff endpoint response, calling out any not_found / error rows."""
    summary = response.get("summary") or {}
    rprint(
        "[green]Applied[/green] — "
        f"created={summary.get('created', 0)} · "
        f"modified={summary.get('modified', 0)} · "
        f"decommissioned={summary.get('decommissioned', 0)} · "
        f"unchanged={summary.get('unchanged', 0)} · "
        f"not_found={summary.get('not_found', 0)} · "
        f"errors={summary.get('errors', 0)}"
    )

    problem_outcomes = {"not_found", "error"}
    problem_items = [
        item for item in response.get("items", []) if isinstance(item, dict) and item.get("outcome") in problem_outcomes
    ]
    if not problem_items:
        return

    rprint("\n[yellow]Some rows did not apply cleanly:[/yellow]")
    for item in problem_items:
        ext = item.get("external_id", "?")
        outcome = item.get("outcome", "?")
        err = item.get("error") or ""
        rprint(f"  [yellow]·[/yellow] {ext} → {outcome}: {err}")
    rprint(
        "[dim]`not_found` on add/modify typically means the row is decommissioned — "
        "re-activate it via the platform UI rather than re-scanning.[/dim]"
    )


# ---------------------------------------------------------------------------
# `pretorin scope artifacts inventory upload <csv>`
# ---------------------------------------------------------------------------


@inventory_app.command("upload")
def inventory_upload(
    csv_path: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True, help="CSV file of asset rows"),
    system: str | None = typer.Option(
        None,
        "--system",
        "-s",
        help="System name or ID (uses active context if not set).",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the diff-preview confirmation."),
) -> None:
    """Upload an asset-inventory CSV. Parses client-side, classifies, and posts a single diff."""
    asyncio.run(_inventory_upload(csv_path=csv_path, system=system, yes=yes))


def _read_inventory_csv(csv_path: Path) -> list[dict[str, Any]]:
    """Read a whitelisted set of columns from the CSV. Errors out on a missing external_id."""
    rows: list[dict[str, Any]] = []
    with csv_path.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for line_no, raw in enumerate(reader, start=2):
            ext_id = (raw.get("external_id") or "").strip()
            if not ext_id:
                raise typer.BadParameter(f"{csv_path}:{line_no}: row is missing required `external_id` column")
            row: dict[str, Any] = {"external_id": ext_id}
            for col in _CSV_FIELDS:
                if col == "external_id":
                    continue
                val = raw.get(col)
                if val is not None and str(val).strip() != "":
                    row[col] = str(val).strip()
            rows.append(row)
    return rows


async def _inventory_upload(csv_path: Path, system: str | None, yes: bool) -> None:
    candidate_rows = _read_inventory_csv(csv_path)
    if not candidate_rows:
        rprint("[yellow]CSV is empty — nothing to upload.[/yellow]")
        raise typer.Exit(0)

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _ = await resolve_execution_context(client, system=system, framework=None)
            existing = await client.get_asset_inventory(system_id)
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

        existing_assets = existing.get("items") if isinstance(existing, dict) else []
        if not isinstance(existing_assets, list):
            existing_assets = []

        added, modified, decommissioned = classify_inventory_diff(
            candidate_rows,
            existing_assets,
            decommission_rationale="absent from uploaded CSV",
        )
        if not (added or modified or decommissioned):
            rprint("[green]Nothing to do — CSV matches the platform inventory exactly.[/green]")
            return

        recipe_id = "cli-upload-csv"
        scan_timestamp = datetime.now(timezone.utc).isoformat()
        idempotency_key = build_inventory_idempotency_key(system_id, recipe_id, scan_timestamp)

        if is_json_mode():
            # Non-interactive: skip confirmation and post immediately.
            response = await _post_diff(client, system_id, added, modified, decommissioned, idempotency_key, recipe_id)
            print_json(
                {
                    "request": {"added": added, "modified": modified, "decommissioned": decommissioned},
                    "response": response,
                }
            )
            return

        _print_diff_preview(added, modified, decommissioned)
        if not yes and not typer.confirm("\nApply this diff?", default=False):
            rprint("[dim]Aborted — nothing applied.[/dim]")
            raise typer.Exit(0)

        try:
            response = await _post_diff(client, system_id, added, modified, decommissioned, idempotency_key, recipe_id)
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

    _print_diff_response(response)


async def _post_diff(
    client: PretorianClient,
    system_id: str,
    added: list[dict[str, Any]],
    modified: list[dict[str, Any]],
    decommissioned: list[dict[str, Any]],
    idempotency_key: str,
    recipe_id: str,
    recipe_context_id: str | None = None,
) -> dict[str, Any]:
    return await client.submit_inventory_diff(
        system_id,
        idempotency_key=idempotency_key,
        recipe_id=recipe_id,
        added=added,
        modified=modified,
        decommissioned=decommissioned,
        recipe_context_id=recipe_context_id,
    )


# ---------------------------------------------------------------------------
# `pretorin scope artifacts inventory scan <source>`
# ---------------------------------------------------------------------------


@inventory_app.command("scan")
def inventory_scan(
    source: str = typer.Argument(..., help=f"One of: {', '.join(sorted(VALID_SCAN_SOURCES))}"),
    system: str | None = typer.Option(
        None,
        "--system",
        "-s",
        help="System name or ID (uses active context if not set).",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the diff-preview confirmation."),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Run the scan and print the proposed diff, but do not post it.",
    ),
) -> None:
    """Run a recipe-driven scan against `<source>` and post the resulting diff."""
    if source not in VALID_SCAN_SOURCES:
        rprint(f"[red]Unknown source {source!r}. Valid sources: {', '.join(sorted(VALID_SCAN_SOURCES))}[/red]")
        raise typer.Exit(1)
    asyncio.run(_inventory_scan(source=source, system=system, yes=yes, dry_run=dry_run))


async def _run_inventory_recipe(
    *,
    client: PretorianClient,
    recipe_id: str,
    system_id: str,
    framework_id: str | None,
    last_seen_inventory: list[dict[str, Any]],
) -> tuple[dict[str, Any], str]:
    """Open a recipe context, run produce_diff, end the context. Returns (script_result, context_id)."""
    registry = RecipeRegistry()
    entry = registry.get(recipe_id)
    if entry is None:
        raise PretorianClientError(
            f"Recipe {recipe_id!r} is not loaded. Install it under "
            "src/pretorin/recipes/_recipes/ or ~/.pretorin/recipes/."
        )

    store = get_default_store()
    try:
        active_ctx = store.start_recipe(
            recipe_id=recipe_id,
            recipe_version=entry.active.manifest.version,
            params={"system_id": system_id},
            system_id=system_id,
            framework_id=framework_id,
        )
    except RecipeContextAlreadyActiveError as exc:
        raise PretorianClientError(str(exc)) from exc

    script_ctx = RecipeScriptContext(
        system_id=system_id,
        framework_id=framework_id,
        api_client=client,
        logger=__import__("logging").getLogger(f"pretorin.cli.artifacts.scan.{recipe_id}"),
        recipe_id=recipe_id,
        recipe_version=entry.active.manifest.version,
        recipe_context_id=active_ctx.context_id,
    )
    try:
        result = await run_script(
            recipe=entry.active,
            script_name="produce_diff",
            ctx=script_ctx,
            params={"last_seen_inventory": last_seen_inventory},
        )
    except RecipeError as exc:
        store.end_recipe(active_ctx.context_id, status="fail")
        raise PretorianClientError(f"Recipe {recipe_id!r} failed: {exc}") from exc

    try:
        store.end_recipe(active_ctx.context_id, status="pass")
    except RecipeContextError:
        # End is best-effort here — the script already produced its result.
        pass

    return result, active_ctx.context_id


async def _inventory_scan(source: str, system: str | None, yes: bool, dry_run: bool) -> None:
    recipe_id = SCAN_SOURCE_TO_RECIPE_ID[source]

    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, framework_id = await resolve_execution_context(client, system=system, framework=None)
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

        try:
            existing = await client.get_asset_inventory(system_id)
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

        existing_assets = existing.get("items") if isinstance(existing, dict) else []
        if not isinstance(existing_assets, list):
            existing_assets = []

        try:
            result, recipe_context_id = await _run_inventory_recipe(
                client=client,
                recipe_id=recipe_id,
                system_id=system_id,
                framework_id=framework_id,
                last_seen_inventory=existing_assets,
            )
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

        added = list(result.get("added") or [])
        modified = list(result.get("modified") or [])
        decommissioned = list(result.get("decommissioned") or [])

        if not (added or modified or decommissioned):
            rprint(f"[green]Scan complete — no changes detected via `{source}`.[/green]")
            return

        scan_timestamp = datetime.now(timezone.utc).isoformat()
        idempotency_key = build_inventory_idempotency_key(system_id, recipe_id, scan_timestamp)

        if dry_run:
            if is_json_mode():
                print_json(
                    {
                        "source": source,
                        "recipe_id": recipe_id,
                        "request": {
                            "added": added,
                            "modified": modified,
                            "decommissioned": decommissioned,
                            "idempotency_key": idempotency_key,
                        },
                        "dry_run": True,
                    }
                )
                return
            _print_diff_preview(added, modified, decommissioned)
            rprint("[dim]Dry run — diff not posted.[/dim]")
            return

        if is_json_mode():
            response = await _post_diff(
                client,
                system_id,
                added,
                modified,
                decommissioned,
                idempotency_key,
                recipe_id,
                recipe_context_id=recipe_context_id,
            )
            print_json(
                {
                    "source": source,
                    "recipe_id": recipe_id,
                    "request": {
                        "added": added,
                        "modified": modified,
                        "decommissioned": decommissioned,
                        "idempotency_key": idempotency_key,
                    },
                    "response": response,
                }
            )
            return

        _print_diff_preview(added, modified, decommissioned)
        if not yes and not typer.confirm("\nApply this diff?", default=False):
            rprint("[dim]Aborted — nothing applied.[/dim]")
            raise typer.Exit(0)

        try:
            response = await _post_diff(
                client,
                system_id,
                added,
                modified,
                decommissioned,
                idempotency_key,
                recipe_id,
                recipe_context_id=recipe_context_id,
            )
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

    _print_diff_response(response)


# ---------------------------------------------------------------------------
# `pretorin scope artifacts toggle`
# ---------------------------------------------------------------------------


@app.command("toggle")
def artifacts_toggle(
    kind: str = typer.Argument(..., help="Artifact kind to toggle (e.g., asset_inventory, threat_model)."),
    system: str | None = typer.Option(
        None,
        "--system",
        "-s",
        help="System name or ID (uses active context if not set).",
    ),
    optional: bool = typer.Option(
        False,
        "--optional/--required",
        help="Toggle the kind off (--optional) or back on (--required).",
    ),
    rationale: str | None = typer.Option(
        None,
        "--rationale",
        "-r",
        help="Required when toggling off. Free-text justification recorded by the platform.",
    ),
) -> None:
    """Toggle an artifact kind required/optional. Rationale is required on toggle-off."""
    if optional and not rationale:
        rprint("[red]--rationale is required when toggling a kind to --optional.[/red]")
        raise typer.Exit(1)
    asyncio.run(_artifacts_toggle(kind=kind, system=system, optional=optional, rationale=rationale))


async def _artifacts_toggle(
    kind: str,
    system: str | None,
    optional: bool,
    rationale: str | None,
) -> None:
    async with PretorianClient() as client:
        require_auth(client)
        try:
            system_id, _ = await resolve_execution_context(client, system=system, framework=None)
            payload = await client.toggle_spec_kind(
                system_id,
                kind,
                optional=optional,
                rationale=rationale,
            )
        except PretorianClientError as exc:
            rprint(f"[red]{exc.message}[/red]")
            raise typer.Exit(1)

    if is_json_mode():
        print_json(payload)
        return
    state = "optional" if optional else "required"
    rprint(f"[green]Toggled[/green] kind={kind} on {system_id} to [bold]{state}[/bold]")
    if rationale:
        rprint(f"[dim]Rationale: {rationale}[/dim]")
