"""Main CLI application setup for Pretorin."""

from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import Annotated

import typer
from rich import print as rprint
from rich.console import Console

from pretorin import __version__
from pretorin.cli.agent import app as agent_app
from pretorin.cli.auth import app as auth_app
from pretorin.cli.campaign import app as campaign_app
from pretorin.cli.cci import app as cci_app
from pretorin.cli.commands import app as frameworks_app
from pretorin.cli.config import app as config_app
from pretorin.cli.context import app as context_app
from pretorin.cli.control import app as control_app
from pretorin.cli.evidence import app as evidence_app
from pretorin.cli.harness import app as harness_app
from pretorin.cli.monitoring import app as monitoring_app
from pretorin.cli.narrative import app as narrative_app
from pretorin.cli.notes import app as notes_app
from pretorin.cli.output import set_json_mode
from pretorin.cli.policy import app as policy_app
from pretorin.cli.recipe import app as recipe_app
from pretorin.cli.review import app as review_app
from pretorin.cli.risk import app as risk_app
from pretorin.cli.scope import app as scope_app
from pretorin.cli.skill import app as skill_app
from pretorin.cli.stig import app as stig_app
from pretorin.cli.vendor import app as vendor_app

console = Console()

BANNER = """
[#FF9010]╔═══════════════════════════════════════════════════════════╗[/#FF9010]
[#FF9010]║[/#FF9010]   [#EAB536] ∫[/#EAB536]                                                      [#FF9010]║[/#FF9010]
[#FF9010]║[/#FF9010]   [#EAB536]\\[°□°][/#EAB536]  [bold #FF9010]PRETORIN[/bold #FF9010]  [dim]\\[BETA][/dim]                              [#FF9010]║[/#FF9010]
[#FF9010]║[/#FF9010]         [dim]Compliance Platform CLI[/dim]                         [#FF9010]║[/#FF9010]
[#FF9010]║[/#FF9010]                                                           [#FF9010]║[/#FF9010]
[#FF9010]║[/#FF9010]         [#EAB536]Making compliance the best part of your day.[/#EAB536]   [#FF9010]║[/#FF9010]
[#FF9010]║[/#FF9010]                                                           [#FF9010]║[/#FF9010]
[#FF9010]║[/#FF9010]  [dim]Platform features require a beta code. Browse frameworks[/dim]  [#FF9010]║[/#FF9010]
[#FF9010]║[/#FF9010]  [dim]and controls freely. Sign up: https://pretorin.com[/dim]       [#FF9010]║[/#FF9010]
[#FF9010]╚═══════════════════════════════════════════════════════════╝[/#FF9010]
"""


def show_banner(check_updates: bool = True) -> None:
    """Display the branded welcome banner."""
    rprint(BANNER)
    rprint(f"  [dim]v{__version__}[/dim]\n")

    # Show update message if available
    if check_updates:
        _maybe_print_update_notice()


def _should_show_update_notice(
    *,
    json_output: bool = False,
    invoked_subcommand: str | None = None,
) -> bool:
    """Return True when passive update notices should be shown."""
    if json_output:
        return False
    if invoked_subcommand in {"update", "mcp-serve"}:
        return False
    return bool(getattr(sys.stdout, "isatty", lambda: False)())


def _maybe_print_update_notice(
    *,
    json_output: bool = False,
    invoked_subcommand: str | None = None,
) -> None:
    """Print a passive update notice when appropriate."""
    if not _should_show_update_notice(
        json_output=json_output,
        invoked_subcommand=invoked_subcommand,
    ):
        return

    from pretorin.cli.version_check import get_update_message

    update_msg = get_update_message()
    if update_msg:
        rprint(update_msg)
        rprint()


def _version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        rprint(f"[#FF9010]pretorin[/#FF9010] version {__version__}")
        _maybe_print_update_notice()
        raise typer.Exit()


app = typer.Typer(
    name="pretorin",
    help="Access compliance frameworks, control families, and control details.",
    no_args_is_help=False,
    context_settings={"help_option_names": ["-h", "--help"]},
)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON (for scripting and AI agents)"),
    _version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """CLI for the Pretorin Compliance Platform.

    Making compliance the best part of your day.
    """
    # Configure stdlib logging: default WARNING, overridable via PRETORIN_LOG_LEVEL
    log_level = os.environ.get("PRETORIN_LOG_LEVEL", "WARNING").upper()
    logging.basicConfig(
        stream=sys.stderr,
        level=getattr(logging, log_level, logging.WARNING),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    if json_output:
        set_json_mode(True)

    # Show banner and help when no subcommand is provided
    if ctx.invoked_subcommand is None:
        if json_output:
            print(json.dumps({"version": __version__}))
        else:
            show_banner()
            # Show the help text after the banner
            rprint(ctx.get_help())
        return

    _maybe_print_update_notice(
        json_output=json_output,
        invoked_subcommand=ctx.invoked_subcommand,
    )


# Add sub-command groups
app.add_typer(config_app, name="config", help="Manage configuration")
app.add_typer(campaign_app, name="campaign", help="Workflow-aligned bulk campaign runs")
app.add_typer(control_app, name="control", help="Control implementation management")
app.add_typer(context_app, name="context", help="Manage active system/framework context")
app.add_typer(frameworks_app, name="frameworks", help="Browse compliance frameworks and controls")
app.add_typer(monitoring_app, name="monitoring", help="Monitoring events and compliance tracking")
app.add_typer(evidence_app, name="evidence", help="Local evidence management and platform sync")
app.add_typer(narrative_app, name="narrative", help="Local narrative management and platform sync.")
app.add_typer(notes_app, name="notes", help="Local note management and platform sync.")
app.add_typer(policy_app, name="policy", help="Stateful org-policy questionnaire workflows")
app.add_typer(review_app, name="review", help="Review local artifacts against compliance controls")
app.add_typer(scope_app, name="scope", help="Stateful scope questionnaire workflows")
app.add_typer(agent_app, name="agent", help="Autonomous compliance agent")
app.add_typer(skill_app, name="skill", help="Install/manage the Pretorin skill for AI agents")
app.add_typer(recipe_app, name="recipe", help="List, show, scaffold, and validate Pretorin recipes")
app.add_typer(vendor_app, name="vendor", help="Vendor management and evidence linking")
app.add_typer(risk_app, name="risk", help="System-scoped risk register management")
app.add_typer(stig_app, name="stig", help="Browse STIG benchmarks, rules, and applicability")
app.add_typer(cci_app, name="cci", help="Browse CCIs and the full traceability chain")
app.add_typer(harness_app, name="harness", help="[Deprecated] AI harness wrapper")

# Add auth commands directly to root
for command in auth_app.registered_commands:
    app.registered_commands.append(command)


@app.command()
def version() -> None:
    """Show the CLI version."""
    rprint(f"[#FF9010]pretorin[/#FF9010] version {__version__}")
    _maybe_print_update_notice()


def _venv_root_from_executable(executable: str) -> Path | None:
    """Return the virtualenv root for an interpreter path, if it has one."""
    for parent in Path(executable).absolute().parents:
        if (parent / "pyvenv.cfg").is_file():
            return parent
    return None


def _detect_managed_venv_installer(executable: str) -> str | None:
    """Detect uv/pipx tool venvs from their metadata files."""
    venv_root = _venv_root_from_executable(executable)
    if venv_root is None:
        return None

    if (venv_root / "uv-receipt.toml").is_file():
        return "uv"
    if (venv_root / "pipx_metadata.json").is_file():
        return "pipx"
    return None


def _detect_installer(executable: str) -> str:
    """Return 'uv', 'pipx', or 'pip' based on the running interpreter's path.

    uv and pipx tool venvs omit pip, so prefer their metadata markers over
    brittle path guesses. The path fallback keeps older installs covered.
    """
    managed_installer = _detect_managed_venv_installer(executable)
    if managed_installer:
        return managed_installer

    parts = [p.lower() for p in Path(executable).parts]
    for i in range(len(parts) - 1):
        if parts[i] == "uv" and parts[i + 1] == "tools":
            return "uv"
        if parts[i] == "pipx" and parts[i + 1] == "venvs":
            return "pipx"
    return "pip"


def _build_upgrade_command(installer: str, target_version: str | None) -> list[str] | None:
    """Build the subprocess argv for the detected installer.

    Returns None if the installer's binary isn't on PATH so the caller can
    print a useful manual-command hint instead of erroring opaquely.
    """
    import shutil

    if installer == "uv":
        uv_bin = shutil.which("uv")
        if not uv_bin:
            return None
        if target_version:
            return [
                uv_bin,
                "tool",
                "install",
                "--force",
                "--refresh",
                f"pretorin=={target_version}",
            ]
        # `@latest` uses uv's native latest-version resolution.
        return [uv_bin, "tool", "install", "--force", "pretorin@latest"]
    if installer == "pipx":
        pipx_bin = shutil.which("pipx")
        if not pipx_bin:
            return None
        if target_version:
            return [
                pipx_bin,
                "install",
                "--force",
                f"pretorin=={target_version}",
                "--pip-args=--no-cache-dir",
            ]
        return [pipx_bin, "upgrade", "pretorin", "--pip-args=--no-cache-dir"]
    spec = f"pretorin=={target_version}" if target_version else "pretorin"
    return [sys.executable, "-m", "pip", "install", "--upgrade", "--no-cache-dir", spec]


def _manual_upgrade_hint(installer: str, target_version: str | None) -> str:
    """Human-readable manual command for the detected installer."""
    if installer == "uv":
        return (
            f"uv tool install --force --refresh pretorin=={target_version}"
            if target_version
            else "uv tool install --force pretorin@latest"
        )
    if installer == "pipx":
        return (
            f"pipx install --force pretorin=={target_version} --pip-args=--no-cache-dir"
            if target_version
            else "pipx upgrade pretorin --pip-args=--no-cache-dir"
        )
    return (
        f"pip install --no-cache-dir pretorin=={target_version}"
        if target_version
        else "pip install --upgrade --no-cache-dir pretorin"
    )


@app.command()
def update(
    version: Annotated[
        str | None,
        typer.Argument(help="Target version to install (e.g. 0.15.1). Defaults to latest."),
    ] = None,
) -> None:
    """Update Pretorin CLI to the latest version, or a specific version.

    Dispatches the detected installer's native upgrade command and propagates
    its exit code. We deliberately do NOT pre-resolve the latest version via
    the PyPI JSON API: that path was failing right after fresh publishes
    because the JSON metadata API can return a version before uv's simple
    index resolver sees it, and we'd pin to a "version that doesn't exist
    yet." Letting uv/pipx/pip resolve `@latest` themselves keeps the update
    flow to a single source of truth (the installer's own index view).
    """
    import subprocess
    import sys

    installer = _detect_installer(sys.executable)
    cmd = _build_upgrade_command(installer, version)
    if cmd is None:
        rprint(f"[#FF9010]→[/#FF9010] Detected {installer}-managed install but `{installer}` is not on PATH.")
        rprint("  Run the upgrade manually:")
        rprint(f"  [bold]{_manual_upgrade_hint(installer, version)}[/bold]")
        raise typer.Exit(1)

    label = f"to {version}" if version else "to the latest version"
    rprint(f"[#FF9010]→[/#FF9010] Upgrading pretorin {label} via {installer}...")
    rprint()
    result = subprocess.run(cmd)
    raise typer.Exit(result.returncode)


@app.command("mcp-serve")
def mcp_serve() -> None:
    """Start the MCP server (stdio transport)."""
    from pretorin.mcp.server import run_server

    run_server()


@app.command("mcp-smoke-test")
def mcp_smoke_test() -> None:
    """Smoke-test the RFC #113 cross-harness tool surface.

    Exercises check_context, list_tools, get_instructions, get_workflow
    schema bundling, and the WorkflowRoutingError -> structured payload
    path. Prints PASS/FAIL per check; exits 1 on any failure.
    """
    from pretorin.mcp.smoke import run_smoke_test

    raise typer.Exit(code=run_smoke_test())


if __name__ == "__main__":
    app()
