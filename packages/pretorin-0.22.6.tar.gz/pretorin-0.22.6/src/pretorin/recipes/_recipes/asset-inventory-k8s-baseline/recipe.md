---
id: asset-inventory-k8s-baseline
version: 0.1.0
name: "Kubernetes Asset Inventory Scan"
description: "Enumerate nodes and workload controllers (Deployment, StatefulSet, DaemonSet) from a live Kubernetes cluster and produce an asset-inventory diff against the platform's current snapshot. Use when the auditor needs a fresh K8s asset inventory and you have a working kubeconfig context."
use_when: "The system has at least one k8s_cluster connected source and the auditor needs a current asset inventory backed by live API state. You have a kubeconfig context configured and reachable from the CLI host."
produces: evidence
author: "Pretorin Core Team"
license: Apache-2.0
requires:
  sources:
    - kind: k8s_cluster
      binding_role: primary
      probe: "kubectl cluster-info"
      source_version_kind: cloud_account_scan_time
  cli:
    - { name: kubectl, probe: "kubectl version --client" }
scripts:
  produce_diff:
    path: scripts/produce_diff.py
    description: "Enumerate K8s nodes + workload controllers and return {added, modified, decommissioned} vs last_seen_inventory."
    params:
      last_seen_inventory:
        type: array
        description: "Current platform asset inventory rows; the script diffs against this list."
        default: []
---

# Kubernetes Asset Inventory Scan

Runs `kubectl get nodes,deployments,statefulsets,daemonsets -A -o json` against
the active kubeconfig context and normalizes each resource into the standard
asset row shape.

`external_id` is the resource's UID. Workload controllers are rolled up by
their canonical `{kind}/{namespace}/{name}` triple in the `name` field;
auditors typically want to know which workloads exist, not every pod replica.

v1 scope: Nodes + Deployment / StatefulSet / DaemonSet. CronJob, Job, and
plain Pods are intentionally excluded to keep the inventory at the workload
level rather than the runtime-instance level.
