"""produce_diff for asset-inventory-k8s-baseline.

Runs `kubectl get` against the active context to enumerate nodes and workload
controllers, normalizes each into the asset-row shape, and diffs against
`last_seen_inventory`. Does not write evidence directly — the CLI / MCP layer
posts the diff to the platform.
"""

from __future__ import annotations

import asyncio
import json
import shutil
from typing import Any

from pretorin.spec import classify_inventory_diff

_WORKLOAD_KINDS: tuple[str, ...] = ("Deployment", "StatefulSet", "DaemonSet")


async def _kubectl_json(args: list[str]) -> dict[str, Any] | None:
    """Run kubectl and parse its JSON output. Returns None on any failure."""
    binary = shutil.which("kubectl")
    if not binary:
        return None
    proc = await asyncio.create_subprocess_exec(
        binary,
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    if proc.returncode != 0:
        return None
    try:
        return json.loads(stdout.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None


def _row_from_node(item: dict[str, Any]) -> dict[str, Any]:
    meta = item.get("metadata") or {}
    labels = meta.get("labels") or {}
    env = (labels.get("environment") or "").lower()
    environment = env if env in {"prod", "stage", "dev", "test"} else "prod"
    return {
        "external_id": meta.get("uid") or meta.get("name") or "?",
        "name": meta.get("name") or "?",
        "asset_type": "server",
        "environment": environment,
        "criticality": "moderate",
        "data_classification": "internal",
    }


def _row_from_workload(item: dict[str, Any]) -> dict[str, Any]:
    meta = item.get("metadata") or {}
    kind = item.get("kind", "Workload")
    namespace = meta.get("namespace", "default")
    name = meta.get("name", "?")
    labels = meta.get("labels") or {}
    env = (labels.get("environment") or "").lower()
    environment = env if env in {"prod", "stage", "dev", "test"} else "prod"
    return {
        "external_id": meta.get("uid") or f"{kind}/{namespace}/{name}",
        "name": f"{kind}/{namespace}/{name}",
        "asset_type": "container_workload",
        "environment": environment,
        "criticality": "moderate",
        "data_classification": "internal",
    }


async def run(
    ctx: Any,
    *,
    last_seen_inventory: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Enumerate K8s nodes + workload controllers and produce a diff."""
    last_seen_inventory = list(last_seen_inventory or [])

    if shutil.which("kubectl") is None:
        return {
            "added": [],
            "modified": [],
            "decommissioned": [],
            "error": "kubectl not on PATH; install kubectl and `kubectl cluster-info` then retry",
        }

    candidate_rows: list[dict[str, Any]] = []

    nodes_payload = await _kubectl_json(["get", "nodes", "-o", "json"])
    if nodes_payload:
        for item in nodes_payload.get("items", []):
            candidate_rows.append(_row_from_node(item))

    for kind in _WORKLOAD_KINDS:
        kind_payload = await _kubectl_json(["get", kind.lower(), "-A", "-o", "json"])
        if not kind_payload:
            continue
        for item in kind_payload.get("items", []):
            # kubectl drops `kind` from list items; inject it before normalizing.
            item.setdefault("kind", kind)
            candidate_rows.append(_row_from_workload(item))

    added, modified, decommissioned = classify_inventory_diff(
        candidate_rows,
        last_seen_inventory,
        decommission_rationale="absent from latest kubectl scan",
    )
    return {
        "added": added,
        "modified": modified,
        "decommissioned": decommissioned,
        "scanned": len(candidate_rows),
    }
