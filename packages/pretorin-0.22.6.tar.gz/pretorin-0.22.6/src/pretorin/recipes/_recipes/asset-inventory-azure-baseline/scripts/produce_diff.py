"""produce_diff for asset-inventory-azure-baseline.

Enumerates Compute VMs in the current Azure subscription via the
`azure-mgmt-compute` SDK and produces an asset-inventory diff against
`last_seen_inventory`. Azure SQL, AKS, and Storage are v1-stubbed and tracked
in follow-up issues.
"""

from __future__ import annotations

import os
from typing import Any

from pretorin.scanners.cloud_azure import AzureCloudScanner
from pretorin.spec import classify_inventory_diff


def _row_from_vm(vm: Any) -> dict[str, Any]:
    """Normalize an azure-mgmt VirtualMachine into our asset row shape."""
    tags = getattr(vm, "tags", None) or {}
    env_tag = str(tags.get("Environment", "") or "").lower()
    environment = env_tag if env_tag in {"prod", "stage", "dev", "test"} else "prod"
    return {
        "external_id": getattr(vm, "id", None) or getattr(vm, "vm_id", None) or "?",
        "name": getattr(vm, "name", None) or tags.get("Name") or "?",
        "asset_type": "server",
        "environment": environment,
        "criticality": "moderate",
        "data_classification": "internal",
    }


async def _enumerate_vms(subscription_id: str | None) -> list[dict[str, Any]]:
    """Best-effort Azure Compute VM enumeration. Returns [] when SDK/creds unusable."""
    if not subscription_id:
        return []
    try:
        from azure.identity import DefaultAzureCredential
        from azure.mgmt.compute import ComputeManagementClient
    except ImportError:
        return []

    try:
        credential = DefaultAzureCredential()
        client = ComputeManagementClient(credential, subscription_id)
        return [_row_from_vm(vm) for vm in client.virtual_machines.list_all()]
    except Exception:
        return []


async def run(
    ctx: Any,
    *,
    last_seen_inventory: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Enumerate Azure resources and produce a diff vs last_seen_inventory."""
    last_seen_inventory = list(last_seen_inventory or [])

    scanner = AzureCloudScanner()
    info = await scanner.detect()
    if not info.available:
        return {
            "added": [],
            "modified": [],
            "decommissioned": [],
            "error": f"Azure scanner not available: {info.install_hint or 'configure Azure credentials'}",
        }

    subscription_id = os.environ.get("AZURE_SUBSCRIPTION_ID")
    candidate_rows = await _enumerate_vms(subscription_id)
    added, modified, decommissioned = classify_inventory_diff(
        candidate_rows,
        last_seen_inventory,
        decommission_rationale="absent from latest Azure scan",
    )
    return {
        "added": added,
        "modified": modified,
        "decommissioned": decommissioned,
        "scanned": len(candidate_rows),
    }
