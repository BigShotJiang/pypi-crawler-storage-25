---
id: asset-inventory-azure-baseline
version: 0.1.0
name: "Azure Asset Inventory Scan"
description: "Enumerate live Azure resources (VMs, Azure SQL servers, AKS clusters, Storage accounts) and produce an asset-inventory diff against the platform's current snapshot. Use when the auditor needs a fresh Azure asset inventory and the tenant is configured with credentials reachable from the CLI host."
use_when: "The system has at least one azure_tenant connected source and the auditor needs a current asset inventory backed by live API state. You have Azure credentials configured (az CLI logged in, AZURE_* env vars, or a managed identity)."
produces: evidence
author: "Pretorin Core Team"
license: Apache-2.0
requires:
  sources:
    - kind: azure_tenant
      binding_role: primary
      probe: "az account show"
      source_version_kind: cloud_account_scan_time
  cli:
    - { name: az, probe: "az --version" }
  env:
    - AZURE_SUBSCRIPTION_ID
scripts:
  produce_diff:
    path: scripts/produce_diff.py
    description: "Enumerate Azure resources and return {added, modified, decommissioned} vs last_seen_inventory."
    params:
      last_seen_inventory:
        type: array
        description: "Current platform asset inventory rows; the script diffs against this list."
        default: []
---

# Azure Asset Inventory Scan

Calls the Azure Resource Manager APIs (via `azure-mgmt-*` SDKs or the `az`
CLI fallback) to enumerate inventoriable resources in the subscription the
CLI host is authenticated to.

Produces the same normalized row shape as the AWS recipe — see
`asset-inventory-aws-baseline/recipe.md` for the field list.

v1 scope: Compute VMs. Azure SQL, AKS, and Storage accounts are tracked as
follow-ups.
