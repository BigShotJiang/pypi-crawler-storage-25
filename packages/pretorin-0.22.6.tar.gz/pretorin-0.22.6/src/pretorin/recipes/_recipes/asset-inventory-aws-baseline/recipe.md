---
id: asset-inventory-aws-baseline
version: 0.1.0
name: "AWS Asset Inventory Scan"
description: "Enumerate live AWS resources (EC2 instances, RDS databases, EKS clusters, S3 buckets) and produce an asset-inventory diff against the platform's current snapshot. Use when the auditor needs a fresh AWS asset inventory and the account is configured with credentials reachable from the CLI host."
use_when: "The system has at least one aws_account connected source and the auditor needs a current asset inventory backed by live API state. You have AWS credentials configured (aws CLI profile, env vars, or instance role)."
produces: evidence
author: "Pretorin Core Team"
license: Apache-2.0
requires:
  sources:
    - kind: aws_account
      binding_role: primary
      probe: "aws sts get-caller-identity"
      source_version_kind: cloud_account_scan_time
  cli:
    - { name: aws, probe: "aws --version" }
  env:
    - AWS_REGION
scripts:
  produce_diff:
    path: scripts/produce_diff.py
    description: "Enumerate AWS resources and return {added, modified, decommissioned} vs last_seen_inventory."
    params:
      last_seen_inventory:
        type: array
        description: "Current platform asset inventory rows; the script diffs against this list."
        default: []
---

# AWS Asset Inventory Scan

Calls the AWS APIs (via `boto3` or the `aws` CLI) to enumerate inventoriable
resources in the account / region the CLI host is authenticated to.

For each resource it produces a normalized row:

```
{
  "external_id": "i-0123...",        # the AWS resource id
  "name": "web-1",                    # tag:Name or resource id
  "asset_type": "server",             # one of server | database | container_workload | data_store
  "environment": "prod",              # inferred from tag:Environment
  "criticality": "moderate",          # configurable; defaults to moderate
  "data_classification": "internal"   # configurable; defaults to internal
}
```

The script then diffs against `last_seen_inventory` (passed in by the CLI's
`inventory scan` command, which fetches it from
`GET /spec/inventory` first) and returns:

```
{
  "added":          [...],   # external_ids not seen before
  "modified":       [...],   # external_ids whose tracked fields differ
  "decommissioned": [...]    # external_ids that disappeared from the live account
}
```

The CLI / MCP layer is responsible for posting that diff to
`POST /spec/inventory/diff`. This recipe deliberately does not write evidence
itself — its job is to produce a *diff*, not to upload artifacts.

v1 scope: EC2 instances. RDS, EKS, and S3 are tracked as follow-ups.
