"""produce_diff for asset-inventory-aws-baseline.

Enumerates EC2 instances in the current AWS account via boto3 and produces an
asset-inventory diff against `last_seen_inventory`. Other AWS resource types
(RDS, EKS, S3) are v1-stubbed and tracked in follow-up issues.

This script does NOT post the diff itself — that's the CLI / MCP layer's job.
"""

from __future__ import annotations

from typing import Any

from pretorin.scanners.cloud_aws import AWSCloudScanner
from pretorin.spec import classify_inventory_diff


def _tag(tags: list[dict[str, str]] | None, key: str) -> str | None:
    if not tags:
        return None
    for tag in tags:
        if tag.get("Key") == key:
            return tag.get("Value")
    return None


def _row_from_ec2(instance: dict[str, Any]) -> dict[str, Any]:
    """Normalize a boto3 EC2 instance dict into our asset row shape."""
    name = _tag(instance.get("Tags"), "Name") or instance.get("InstanceId", "?")
    env_tag = (_tag(instance.get("Tags"), "Environment") or "").lower()
    environment = env_tag if env_tag in {"prod", "stage", "dev", "test"} else "prod"
    return {
        "external_id": instance.get("InstanceId", "?"),
        "name": name,
        "asset_type": "server",
        "environment": environment,
        "criticality": "moderate",
        "data_classification": "internal",
    }


async def _enumerate_ec2_instances(region: str | None) -> list[dict[str, Any]]:
    """Best-effort EC2 enumeration. Returns [] when boto3 or creds aren't usable."""
    try:
        import boto3
    except ImportError:
        return []

    kwargs: dict[str, Any] = {}
    if region:
        kwargs["region_name"] = region

    try:
        ec2 = boto3.client("ec2", **kwargs)
        paginator = ec2.get_paginator("describe_instances")
        rows: list[dict[str, Any]] = []
        for page in paginator.paginate():
            for reservation in page.get("Reservations", []):
                for instance in reservation.get("Instances", []):
                    state = (instance.get("State") or {}).get("Name", "")
                    if state in {"terminated", "shutting-down"}:
                        continue
                    rows.append(_row_from_ec2(instance))
        return rows
    except Exception:
        return []


async def run(
    ctx: Any,
    *,
    last_seen_inventory: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Enumerate AWS resources and produce a diff vs last_seen_inventory."""
    last_seen_inventory = list(last_seen_inventory or [])

    scanner = AWSCloudScanner()
    info = await scanner.detect()
    if not info.available:
        return {
            "added": [],
            "modified": [],
            "decommissioned": [],
            "error": f"AWS scanner not available: {info.install_hint or 'configure AWS credentials'}",
        }

    candidate_rows = await _enumerate_ec2_instances(region=None)
    added, modified, decommissioned = classify_inventory_diff(
        candidate_rows,
        last_seen_inventory,
        decommission_rationale="absent from latest AWS scan",
    )
    return {
        "added": added,
        "modified": modified,
        "decommissioned": decommissioned,
        "scanned": len(candidate_rows),
    }
