"""produce_diff for asset-inventory-iac-workspace.

Reads IaC files from the local workspace (Terraform, Kubernetes manifests,
CloudFormation) and emits asset rows. No live cloud calls. The CLI / MCP
layer posts the diff to the platform.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from pretorin.spec import classify_inventory_diff

# Terraform `resource "<type>" "<name>" { ... }` declarations we extract.
# Keep this list narrow in v1 — auditors care about server-shaped resources
# more than every helper resource an IaC layout contains.
_TF_RESOURCE_TYPES_TO_ASSET_TYPE: dict[str, str] = {
    "aws_instance": "server",
    "azurerm_virtual_machine": "server",
    "azurerm_linux_virtual_machine": "server",
    "azurerm_windows_virtual_machine": "server",
    "google_compute_instance": "server",
}

_TF_RESOURCE_RE = re.compile(
    r'resource\s+"(?P<type>[a-zA-Z0-9_]+)"\s+"(?P<name>[a-zA-Z0-9_-]+)"\s*\{',
)

_K8S_WORKLOAD_KINDS: frozenset[str] = frozenset({"Deployment", "StatefulSet", "DaemonSet"})


# ---------------------------------------------------------------------------
# Terraform .tf parsing
# ---------------------------------------------------------------------------


def _scan_terraform_text(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for match in _TF_RESOURCE_RE.finditer(text):
        rtype = match.group("type")
        rname = match.group("name")
        asset_type = _TF_RESOURCE_TYPES_TO_ASSET_TYPE.get(rtype)
        if not asset_type:
            continue
        rows.append(
            {
                "external_id": f"{rtype}.{rname}",
                "name": rname,
                "asset_type": asset_type,
                "environment": "prod",
                "criticality": "moderate",
                "data_classification": "internal",
            }
        )
    return rows


# ---------------------------------------------------------------------------
# Terraform .tf.json parsing — same shape but JSON
# ---------------------------------------------------------------------------


def _scan_terraform_json(payload: Any) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not isinstance(payload, dict):
        return rows
    resources = payload.get("resource")
    if not isinstance(resources, dict):
        return rows
    for rtype, name_map in resources.items():
        asset_type = _TF_RESOURCE_TYPES_TO_ASSET_TYPE.get(str(rtype))
        if not asset_type or not isinstance(name_map, dict):
            continue
        for rname in name_map:
            rows.append(
                {
                    "external_id": f"{rtype}.{rname}",
                    "name": str(rname),
                    "asset_type": asset_type,
                    "environment": "prod",
                    "criticality": "moderate",
                    "data_classification": "internal",
                }
            )
    return rows


# ---------------------------------------------------------------------------
# Kubernetes YAML parsing
# ---------------------------------------------------------------------------


def _scan_k8s_yaml(text: str) -> list[dict[str, Any]]:
    """Lightweight multi-doc YAML scan for workload controllers.

    Avoids a hard dep on PyYAML by falling back to a regex-based pass when YAML
    isn't installed. The regex pass is tolerant — it picks up `kind: Deployment`
    lines with the nearest `name:` and `namespace:` siblings within the same
    document block.
    """
    try:
        import yaml  # type: ignore[import-not-found]
    except ImportError:
        yaml = None  # type: ignore[assignment]

    rows: list[dict[str, Any]] = []
    if yaml is not None:
        try:
            for doc in yaml.safe_load_all(text):
                row = _row_from_k8s_doc(doc)
                if row:
                    rows.append(row)
            return rows
        except yaml.YAMLError:
            pass  # fall through to regex-best-effort

    # Regex fallback: split on document separators, scan each block.
    for block in re.split(r"^---\s*$", text, flags=re.MULTILINE):
        kind_match = re.search(r"^kind:\s*(\w+)", block, flags=re.MULTILINE)
        if not kind_match or kind_match.group(1) not in _K8S_WORKLOAD_KINDS:
            continue
        name_match = re.search(r"^\s*name:\s*([\w.-]+)", block, flags=re.MULTILINE)
        ns_match = re.search(r"^\s*namespace:\s*([\w.-]+)", block, flags=re.MULTILINE)
        if not name_match:
            continue
        kind = kind_match.group(1)
        name = name_match.group(1)
        namespace = ns_match.group(1) if ns_match else "default"
        rows.append(
            {
                "external_id": f"{kind}/{namespace}/{name}",
                "name": f"{kind}/{namespace}/{name}",
                "asset_type": "container_workload",
                "environment": "prod",
                "criticality": "moderate",
                "data_classification": "internal",
            }
        )
    return rows


def _row_from_k8s_doc(doc: Any) -> dict[str, Any] | None:
    if not isinstance(doc, dict):
        return None
    kind = doc.get("kind")
    if kind not in _K8S_WORKLOAD_KINDS:
        return None
    meta = doc.get("metadata") or {}
    name = meta.get("name")
    if not name:
        return None
    namespace = meta.get("namespace") or "default"
    return {
        "external_id": f"{kind}/{namespace}/{name}",
        "name": f"{kind}/{namespace}/{name}",
        "asset_type": "container_workload",
        "environment": "prod",
        "criticality": "moderate",
        "data_classification": "internal",
    }


# ---------------------------------------------------------------------------
# CloudFormation parsing
# ---------------------------------------------------------------------------


def _scan_cloudformation(payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    resources = payload.get("Resources")
    if not isinstance(resources, dict):
        return []
    rows: list[dict[str, Any]] = []
    for logical_id, decl in resources.items():
        if not isinstance(decl, dict):
            continue
        if decl.get("Type") != "AWS::EC2::Instance":
            continue
        rows.append(
            {
                "external_id": str(logical_id),
                "name": str(logical_id),
                "asset_type": "server",
                "environment": "prod",
                "criticality": "moderate",
                "data_classification": "internal",
            }
        )
    return rows


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------


def _walk_workspace(root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        # Skip common heavyweight or noisy directories.
        if any(part in {".git", "node_modules", ".terraform", "venv", ".venv"} for part in path.parts):
            continue
        suffix = path.suffix.lower()
        try:
            if suffix == ".tf":
                rows.extend(_scan_terraform_text(path.read_text(encoding="utf-8", errors="replace")))
            elif path.name.endswith(".tf.json"):
                rows.extend(_scan_terraform_json(json.loads(path.read_text(encoding="utf-8"))))
            elif suffix in {".yaml", ".yml"}:
                rows.extend(_scan_k8s_yaml(path.read_text(encoding="utf-8", errors="replace")))
            elif path.name == "cloudformation.json" or path.name.endswith(".cfn.json"):
                rows.extend(_scan_cloudformation(json.loads(path.read_text(encoding="utf-8"))))
        except (OSError, json.JSONDecodeError):
            continue
    return rows


async def run(
    ctx: Any,
    *,
    last_seen_inventory: list[dict[str, Any]] | None = None,
    root: str = ".",
) -> dict[str, Any]:
    """Walk `root` looking for IaC files and emit a diff vs last_seen_inventory."""
    last_seen_inventory = list(last_seen_inventory or [])

    root_path = Path(root).resolve()
    if not root_path.is_dir():
        return {
            "added": [],
            "modified": [],
            "decommissioned": [],
            "error": f"root path {root_path} is not a directory",
        }

    candidate_rows = _walk_workspace(root_path)
    added, modified, decommissioned = classify_inventory_diff(
        candidate_rows,
        last_seen_inventory,
        decommission_rationale="absent from latest IaC workspace scan",
    )
    return {
        "added": added,
        "modified": modified,
        "decommissioned": decommissioned,
        "scanned": len(candidate_rows),
        "root": str(root_path),
    }
