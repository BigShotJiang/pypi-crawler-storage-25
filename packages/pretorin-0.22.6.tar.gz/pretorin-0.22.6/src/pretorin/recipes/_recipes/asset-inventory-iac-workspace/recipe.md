---
id: asset-inventory-iac-workspace
version: 0.1.0
name: "IaC Workspace Asset Inventory Scan"
description: "Parse infrastructure-as-code files in the local workspace (Terraform .tf, Kubernetes YAML manifests, CloudFormation templates) and produce an asset-inventory diff against the platform's current snapshot. Use when the auditor needs an inventory derived from the IaC checked into source control rather than from a live cloud account."
use_when: "The system's source of truth is IaC committed in this repo, not a live cloud account. Useful when you don't have credentials in the CLI host's environment, or you want the inventory to match the desired state in source control rather than current cloud state."
produces: evidence
author: "Pretorin Core Team"
license: Apache-2.0
requires:
  sources:
    - kind: workspace_repo
      binding_role: primary
      probe: "test -d ."
      source_version_kind: workspace_revision
scripts:
  produce_diff:
    path: scripts/produce_diff.py
    description: "Scan the cwd for IaC files, normalize the declared resources, and return {added, modified, decommissioned} vs last_seen_inventory."
    params:
      last_seen_inventory:
        type: array
        description: "Current platform asset inventory rows; the script diffs against this list."
        default: []
      root:
        type: string
        description: "Directory to scan. Defaults to the CLI's cwd."
        default: "."
---

# IaC Workspace Asset Inventory Scan

This recipe is the generalized "look at the IaC checked into this repo"
counterpart to the live-cloud recipes (AWS / Azure / K8s). It does not call
any cloud API and does not require any cloud credentials — it just parses
files in the workspace.

## What it scans

- **Terraform**: `*.tf` and `*.tf.json` files. v1 picks up `resource
  "aws_instance"`, `resource "azurerm_virtual_machine"`, and `resource
  "google_compute_instance"` blocks. The resource address (e.g.
  `aws_instance.web`) becomes the `external_id`.
- **Kubernetes manifests**: `*.yaml` / `*.yml` files that contain documents
  with `kind: Deployment | StatefulSet | DaemonSet`. The
  `{kind}/{namespace}/{name}` triple becomes the `external_id`.
- **CloudFormation**: `cloudformation.{json,yaml}` and `*.cfn.{json,yaml}`
  files. `AWS::EC2::Instance` resources become rows; the logical id is the
  `external_id`.

Everything else is ignored. Adding more resource shapes is the natural
extension surface — open a PR or fork the recipe under `~/.pretorin/recipes/`.

## What it doesn't do

- It doesn't `terraform plan` — there's no Terraform invocation. v1 reads the
  static `.tf` text only. Resources hidden behind `count`/`for_each` show up
  as a single row.
- It doesn't try to reconcile real-world cloud state. If your live AWS account
  has drifted away from the IaC, this recipe will report the IaC's view, not
  the cloud's view. Pair it with `asset-inventory-aws-baseline` if you need
  both.

The asset shape is the same as the cloud recipes — see the AWS recipe's
README for the row fields.
