"""redact_answer script for the policy-q-answer recipe."""

from __future__ import annotations

from typing import Any

from pretorin.evidence.redact import redact


async def run(ctx: Any, *, answer_text: str) -> dict[str, Any]:  # ctx unused for now
    """Run answer text through the standard secret-redaction pipeline."""
    redacted_text, result = redact(answer_text)
    return {
        "redacted": redacted_text,
        "redaction_summary": result.to_audit_summary().model_dump(),
    }
