"""Compose Markdown evidence for a generic workspace artifact."""

from __future__ import annotations

from pathlib import Path
from typing import Any


def _fence_language(source_path: str) -> str:
    suffix = Path(source_path).suffix.lower().lstrip(".")
    return {
        "md": "markdown",
        "markdown": "markdown",
        "json": "json",
        "yaml": "yaml",
        "yml": "yaml",
        "toml": "toml",
        "py": "python",
        "sh": "bash",
        "bash": "bash",
        "txt": "text",
    }.get(suffix, "")


async def run(
    ctx: Any,
    *,
    content: str,
    source_path: str,
    source_label: str = "",
    source_locator: str | None = None,
    source_version: str | None = None,
    user_prose: str = "",
    secrets_redacted: int = 0,
) -> dict[str, Any]:
    """Compose a standalone Markdown evidence artifact."""
    label = source_label or source_path
    prose = user_prose.strip() or (
        f"This artifact captures relevant workspace evidence or evaluation results from `{label}`."
    )
    language = _fence_language(source_path)
    locator = f" ({source_locator})" if source_locator else ""
    version = f"; source version: `{source_version}`" if source_version else ""
    redaction = f"; secrets redacted: {secrets_redacted}" if secrets_redacted else ""
    body = (
        f"{prose}\n\n"
        f"```{language}\n{content.rstrip()}\n```\n\n"
        "---\n\n"
        f"_Source: `{source_path}`{locator}{version}{redaction}_\n"
    )
    return {"body": body}
