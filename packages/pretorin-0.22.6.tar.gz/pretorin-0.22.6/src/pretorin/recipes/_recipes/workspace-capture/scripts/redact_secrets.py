"""Redact secrets from supplied workspace artifact text."""

from __future__ import annotations

from typing import Any

from pretorin.evidence.redact import redact


async def run(ctx: Any, *, text: str) -> dict[str, Any]:
    """Run the named-pattern redactor over ``text``."""
    redacted, result = redact(text)
    return {
        "redacted_text": redacted,
        "secrets_count": result.total,
        "details": dict(result.counts) if result.counts else {},
    }
