"""MCP server for Pretorin Compliance API."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import CallToolResult, Resource, TextContent, Tool

from pretorin.cli.version_check import get_update_status
from pretorin.client import PretorianClient
from pretorin.client.api import (
    AuthenticationError,
    NotFoundError,
    PretorianClientError,
    WorkflowRoutingError,
)
from pretorin.mcp.handlers import TOOL_HANDLERS
from pretorin.mcp.helpers import format_error
from pretorin.mcp.resources import list_resources as _list_resources
from pretorin.mcp.resources import read_resource as _read_resource
from pretorin.mcp.tools import list_tools as _list_tools

logger = logging.getLogger(__name__)
PUBLIC_TOOL_NAMES = {
    "check_context",
    "get_cli_status",
    "get_instructions",
    "list_tools",
}

# Tool-name -> intent_verb that the calling agent should pass to
# start_task. Used to enrich WorkflowRoutingError payloads with a
# specific next-step hint. Covers the WORKFLOW_TIER set in tool_metadata.py;
# keep in sync when a new write tool requires active routing context.
_TOOL_TO_INTENT_VERB: dict[str, str] = {
    # Evidence write surface
    "create_evidence": "collect_evidence",
    "create_evidence_batch": "collect_evidence",
    "upload_evidence": "collect_evidence",
    "link_evidence": "collect_evidence",
    "delete_evidence": "collect_evidence",
    "push_monitoring_event": "collect_evidence",
    # Narrative authoring surface
    "update_narrative": "draft_narrative",
    "get_narrative": "draft_narrative",
    # Control implementation surface
    "update_control_status": "work_on",
    "add_control_note": "work_on",
    "resolve_control_note": "work_on",
    "get_control_implementation": "work_on",
}

# Bypass logging — emits structured single-line JSON to stderr so MCP hosts
# can pipe it into their log aggregation. The intent is to learn whether
# agents follow the documented routing (call start_task before
# write tools) or skip it. The data feeds the phase-4 trigger decision in
# RFC #113. Disable by setting PRETORIN_MCP_TELEMETRY_DISABLED=1 in the env.
_TELEMETRY_PREFIX = "PRETORIN_TELEMETRY_EVENT"


def _emit_telemetry_event(event_type: str, tool_name: str, **extra: Any) -> None:
    """Emit one structured telemetry event to stderr as a single JSON line.

    Best-effort and non-blocking — telemetry failures must never break a
    tool call. Hosts/operators that don't want stderr noise can suppress by
    setting ``PRETORIN_MCP_TELEMETRY_DISABLED=1``.
    """
    if os.environ.get("PRETORIN_MCP_TELEMETRY_DISABLED"):
        return
    try:
        event: dict[str, Any] = {
            "ts": time.time(),
            "event_type": event_type,
            "tool": tool_name,
            **extra,
        }
        print(f"{_TELEMETRY_PREFIX} {json.dumps(event, default=str)}", file=sys.stderr, flush=True)
    except Exception:  # pragma: no cover - telemetry must never raise
        logger.debug("Telemetry emission failed", exc_info=True)


def _structured_error_payload(result: CallToolResult) -> dict[str, Any] | None:
    """Return a structured JSON error payload when a tool used format_json_error."""
    if not getattr(result, "isError", False) or not result.content:
        return None
    text = getattr(result.content[0], "text", None)
    if not isinstance(text, str):
        return None
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def _recipe_required_telemetry_fields(
    tool_name: str,
    arguments: dict[str, Any],
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Extract non-content recipe-required telemetry fields.

    Do not include names, descriptions, source excerpts, artifact content,
    narrative text, control ids, or evidence ids here. The watch metric only
    needs categorical/count shape data.
    """
    fields: dict[str, Any] = {}
    recipe_gap = payload.get("recipe_gap")
    if isinstance(recipe_gap, dict):
        for key in ("reason", "suggested_next"):
            value = recipe_gap.get(key)
            if isinstance(value, str):
                fields[key] = value
        requested_evidence_type = recipe_gap.get("requested_evidence_type")
        if isinstance(requested_evidence_type, str) and requested_evidence_type:
            fields["requested_evidence_type"] = requested_evidence_type

    if tool_name == "create_evidence":
        artifact_content = arguments.get("artifact_content")
        if isinstance(artifact_content, str):
            fields["artifact_content_length"] = len(artifact_content)
    elif tool_name == "create_evidence_batch":
        items = arguments.get("items")
        if isinstance(items, list):
            fields["requested_item_count"] = len(items)
    elif tool_name == "update_narrative":
        narrative = arguments.get("narrative")
        if isinstance(narrative, str):
            fields["narrative_length"] = len(narrative)
        evidence_ids = arguments.get("evidence_ids")
        if isinstance(evidence_ids, list):
            fields["evidence_id_count"] = len([item for item in evidence_ids if isinstance(item, str) and item])
    return fields


def _emit_recipe_required_telemetry(name: str, arguments: dict[str, Any], result: Any) -> None:
    if not isinstance(result, CallToolResult):
        return
    payload = _structured_error_payload(result)
    if payload is None or payload.get("error") != "recipe_required":
        return
    _emit_telemetry_event(
        "recipe_required",
        name,
        **_recipe_required_telemetry_fields(name, arguments, payload),
    )


# Create the MCP server instance
server = Server(
    "pretorin",
    instructions=(
        "Pretorin is currently in BETA. Framework and control reference tools "
        "(list_frameworks, get_control, etc.) are available to authenticated users. "
        "\n\n"
        "FIRST CALL — IMPORTANT: At session start, call check_context "
        "once. It's a cheap, unauthenticated probe that returns whether the "
        "client is authenticated, which system/framework is active locally, "
        "and a plain-English `suggested_next` hint. Use it to ground yourself "
        "before any other tool call. If `connected` is false or "
        "`active_system` is null, follow `suggested_next` instead of calling "
        "start_task — start_task without an active system returns a "
        "dead-end response. "
        "\n\n"
        "ROUTING — IMPORTANT: When the user references pretorin work (a control, "
        "system, framework, questionnaire, or campaign), the FIRST tool to call "
        "is start_task. Extract entities (intent_verb, system_id, "
        "framework_id, control_ids, scope_question_ids, policy_question_ids) "
        "from the user prompt and pass them in. Pretorin runs deterministic "
        "rules to pick a workflow and bundles the relevant platform state into "
        "the response. Then read the selected workflow's body via "
        "get_workflow and follow it. Do NOT call evidence/narrative "
        "write tools before start_task has resolved the workflow and "
        "scope — that path produces wrong-framework writes and breaks the "
        "audit chain. For evidence or narrative production, inspect "
        "`suggested_capture_plan`, use check_sources/list_recipes for source "
        "preflight, then write only through a recipe_context_id from "
        "start_recipe. The one exception is when the user is asking pure "
        "reference questions ('show me AC-2', 'list frameworks'); those go "
        "directly to the read-side tools without start_task. "
        "\n\n"
        "Creating a system requires a beta code — systems can only be created on "
        "the Pretorin platform (https://platform.pretorin.com), not through the CLI "
        "or MCP. Without a system, platform write features (evidence, narratives, "
        "monitoring, control status) cannot be used. If list_systems returns no "
        "systems, tell the user they need a beta code to create one on the platform "
        "and can sign up for early access at https://pretorin.com/early-access/. "
        "MCP hosts can inspect get_cli_status or status://cli to surface "
        "local CLI update guidance."
    ),
)


@server.list_resources()
async def list_resources() -> list[Resource]:
    """List available MCP resources for compliance analysis."""
    return await _list_resources()


@server.read_resource()
async def read_resource(uri: str) -> str:
    """Read an analysis resource."""
    return await _read_resource(uri)


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available MCP tools."""
    return await _list_tools()


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent] | CallToolResult:
    """Handle tool calls."""
    logger.info("Tool call: %s", name)
    try:
        handler = TOOL_HANDLERS.get(name)
        if name in PUBLIC_TOOL_NAMES:
            if handler:
                return await handler(None, arguments)
            logger.warning("Unknown tool requested: %s", name)
            return format_error(f"Unknown tool: {name}")

        async with PretorianClient() as client:
            if not client.is_configured:
                logger.warning("Tool call %s failed: client not authenticated", name)
                return format_error("Not authenticated. Please run 'pretorin login' in the terminal first.")

            if handler:
                result = await handler(client, arguments)
                if name == "start_task":
                    _emit_telemetry_event("start_task_succeeded", name)
                _emit_recipe_required_telemetry(name, arguments, result)
                return result
            # Phase C: per-recipe-script tools (recipe_<id>__<tool>) are
            # not in the static TOOL_HANDLERS table — they're registered dynamically
            # from the recipe registry. Dispatch the catch-all here when the name
            # matches the prefix.
            if name.startswith("recipe_") and "__" in name[len("recipe_") :]:
                from pretorin.mcp.handlers.recipe import handle_run_recipe_script

                result = await handle_run_recipe_script(client, arguments, tool_name=name)
                _emit_recipe_required_telemetry(name, arguments, result)
                return result
            logger.warning("Unknown tool requested: %s", name)
            return format_error(f"Unknown tool: {name}")

    except WorkflowRoutingError as e:
        intent_verb = _TOOL_TO_INTENT_VERB.get(name)
        logger.info(
            "Workflow routing required for tool %s (intent_verb=%s)",
            name,
            intent_verb,
        )
        hint = dict(e.routing_hint)
        if intent_verb and "suggested_intent_verb" not in hint:
            hint["suggested_intent_verb"] = intent_verb
        _emit_telemetry_event(
            "workflow_routing_required",
            name,
            error_code=e.error_code,
            reason=hint.get("reason"),
            missing=hint.get("missing"),
            suggested_intent_verb=hint.get("suggested_intent_verb"),
        )
        payload = {
            "error": e.error_code,
            "message": e.message,
            "routing_hint": hint,
        }
        return CallToolResult(
            content=[TextContent(type="text", text=json.dumps(payload, indent=2))],
            isError=True,
        )
    except AuthenticationError as e:
        logger.warning("Authentication error during tool %s: %s", name, e.message)
        return format_error(f"Authentication failed: {e.message}")
    except NotFoundError as e:
        logger.warning("Not found during tool %s: %s", name, e.message)
        return format_error(f"Not found: {e.message}")
    except PretorianClientError as e:
        logger.error("Client error during tool %s: %s", name, e.message)
        return format_error(e.message)
    except Exception as e:
        logger.error("Unexpected error during tool %s: %s", name, e, exc_info=True)
        return format_error(str(e))


async def _run_server() -> None:
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def _maybe_print_startup_update_notice() -> None:
    """Emit a non-blocking update prompt for MCP hosts on stderr."""
    status = get_update_status()
    prompt = status.get("prompt")
    if not prompt:
        return
    print(f"NOTICE: {prompt}", file=sys.stderr, flush=True)


def run_server() -> None:
    """Entry point to run the MCP server."""
    logger.info("Starting Pretorin MCP server")
    _maybe_print_startup_update_notice()
    asyncio.run(_run_server())


if __name__ == "__main__":
    run_server()
