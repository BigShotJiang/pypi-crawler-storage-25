"""Smoke test for the RFC #113 cross-harness tool surface.

Exercises the new behaviors end-to-end against the in-process MCP handlers,
without needing a separate server process or MCP client. Run via::

    pretorin mcp-smoke-test

Coverage:

- ``check_context`` across the four grounding states (no auth, no
  system, no framework, ready).
- ``list_tools`` returns the expected tier classification and
  honors the documented size budget.
- ``get_instructions`` exposes the routing protocol.
- ``get_workflow`` bundles ``required_tool_schemas`` for the
  single-control workflow.
- ``WorkflowRoutingError`` path returns the structured ``workflow_required``
  payload and emits a ``PRETORIN_TELEMETRY_EVENT`` line on stderr.
- ``recipe_required`` producer errors emit telemetry for recipe-convergence
  bypass measurement.

Exit code 0 on success, 1 if any check fails.
"""

from __future__ import annotations

import asyncio
import json
import sys
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from io import StringIO
from typing import Any, cast
from unittest.mock import AsyncMock, patch

GREEN = "\033[0;32m"
RED = "\033[0;31m"
YELLOW = "\033[1;33m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"

_failures: list[str] = []
_passes: list[str] = []


def _ok(name: str, detail: str = "") -> None:
    suffix = f" {DIM}({detail}){RESET}" if detail else ""
    print(f"  {GREEN}✓{RESET} {name}{suffix}")
    _passes.append(name)


def _fail(name: str, reason: str) -> None:
    print(f"  {RED}✗{RESET} {name} — {reason}")
    _failures.append(f"{name}: {reason}")


def _section(title: str) -> None:
    print(f"\n{BOLD}{title}{RESET}")


@contextmanager
def _captured_stderr() -> Iterator[StringIO]:
    """Capture stderr writes during a block. The MCP server emits telemetry
    on stderr — we tap it here to verify events fired."""
    buf = StringIO()
    original = sys.stderr
    sys.stderr = buf
    try:
        yield buf
    finally:
        sys.stderr = original


def _payload(response: Any) -> dict[str, Any]:
    if isinstance(response, list):
        text = response[0].text
    else:
        text = response.content[0].text
    return cast(dict[str, Any], json.loads(text))


async def _check_context_scenarios() -> None:
    _section("check_context")
    from pretorin.mcp.handlers.engagement import handle_check_context

    scenarios: list[tuple[str, dict[str, Any], Callable[[dict[str, Any]], bool]]] = [
        (
            "not connected -> pretorin login",
            {"is_configured": False, "active_system_id": None, "active_framework_id": None},
            lambda p: not p["connected"] and "pretorin login" in p["suggested_next"],
        ),
        (
            "connected, no system -> list_systems",
            {"is_configured": True, "active_system_id": None, "active_framework_id": None},
            lambda p: p["connected"] and p["active_system"] is None and "list_systems" in p["suggested_next"],
        ),
        (
            "system, no framework -> set framework",
            {"is_configured": True, "active_system_id": "sys-1", "active_framework_id": None},
            lambda p: p["active_system"] is not None and "framework" in p["suggested_next"].lower(),
        ),
        (
            "fully grounded -> start_task",
            {"is_configured": True, "active_system_id": "sys-1", "active_framework_id": "nist-800-53-r5"},
            lambda p: "start_task" in p["suggested_next"],
        ),
    ]

    for label, config_attrs, predicate in scenarios:
        with patch("pretorin.client.config.Config") as mock_cls:
            cfg = mock_cls.return_value
            cfg.is_configured = config_attrs["is_configured"]
            cfg.active_system_id = config_attrs["active_system_id"]
            cfg.active_system_name = config_attrs["active_system_id"]
            cfg.active_framework_id = config_attrs["active_framework_id"]

            try:
                payload = _payload(await handle_check_context(None, {}))
                if predicate(payload):
                    _ok(label, f"suggested_next: {payload['suggested_next'][:60]}...")
                else:
                    _fail(label, f"predicate failed; payload={payload}")
            except Exception as exc:
                _fail(label, f"exception: {exc!r}")


async def _list_tools_check() -> None:
    _section("list_tools")
    from pretorin.mcp.handlers.engagement import handle_list_tools

    try:
        payload = _payload(await handle_list_tools(None, {}))
    except Exception as exc:
        _fail("list_tools call", f"exception: {exc!r}")
        return

    if payload["total"] > 0:
        _ok("returns a non-empty catalog", f"total={payload['total']}")
    else:
        _fail("catalog is empty", "total=0")

    counts = payload["tier_counts"]
    if counts.get("default", 0) >= 7:
        _ok("default tier present", f"default={counts.get('default')}")
    else:
        _fail("default tier", f"expected >=7, got {counts.get('default')}")

    if counts.get("workflow", 0) >= 10:
        _ok("workflow tier present", f"workflow={counts.get('workflow')}")
    else:
        _fail("workflow tier", f"expected >=10, got {counts.get('workflow')}")

    long_purposes = [t["name"] for t in payload["tools"] if len(t["purpose"]) > 100]
    if not long_purposes:
        _ok("all purposes fit in <=100 chars")
    else:
        _fail("purpose length", f"{len(long_purposes)} tools exceed 100 chars")


async def _get_instructions_check() -> None:
    _section("get_instructions")
    from pretorin.mcp.handlers.engagement import handle_get_instructions

    try:
        payload = _payload(await handle_get_instructions(None, {}))
    except Exception as exc:
        _fail("get_instructions call", f"exception: {exc!r}")
        return

    text = payload["instructions"]
    required_markers = ("FIRST CALL", "check_context", "start_task", "ROUTING")
    missing = [marker for marker in required_markers if marker not in text]
    if not missing:
        _ok("instructions block contains all routing markers")
    else:
        _fail("instructions block", f"missing markers: {missing}")


async def _get_workflow_schema_bundling_check() -> None:
    _section("get_workflow (schema bundling)")
    from pretorin.mcp.handlers.workflow_lib import handle_get_workflow_lib

    try:
        payload = _payload(
            await handle_get_workflow_lib(None, {"workflow_id": "single-control"})  # type: ignore[arg-type]
        )
    except Exception as exc:
        _fail("get_workflow call", f"exception: {exc!r}")
        return

    schemas = payload.get("required_tool_schemas") or []
    if schemas:
        _ok("required_tool_schemas present", f"count={len(schemas)}")
    else:
        _fail("schema bundle", "required_tool_schemas missing or empty")
        return

    shape_ok = all({"name", "description", "inputSchema"} <= e.keys() for e in schemas)
    if shape_ok:
        _ok("each schema entry has name/description/inputSchema")
    else:
        _fail("schema shape", "one or more entries missing required fields")

    names = {e["name"] for e in schemas}
    expected = {"create_evidence", "update_narrative"}
    if expected <= names:
        _ok("expected tool refs bundled", f"includes {sorted(expected)}")
    else:
        _fail("expected refs", f"missing {expected - names}")


async def _workflow_routing_error_check() -> None:
    _section("WorkflowRoutingError -> structured payload + telemetry")
    from pretorin.client.api import WorkflowRoutingError
    from pretorin.mcp.server import call_tool

    mock_client = AsyncMock()
    mock_client.is_configured = True
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)

    side_effect = WorkflowRoutingError(
        "No active system/framework context.",
        routing_hint={"reason": "no_active_context", "missing": ["system_id", "framework_id"]},
    )

    with (
        patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
        patch(
            "pretorin.mcp.server.TOOL_HANDLERS",
            {"create_evidence": AsyncMock(side_effect=side_effect)},
        ),
        _captured_stderr() as err_buf,
    ):
        try:
            result = await call_tool("create_evidence", {})
        except Exception as exc:
            _fail("call_tool", f"unexpected exception: {exc!r}")
            return

    if getattr(result, "isError", False):
        _ok("CallToolResult marked isError=true")
    else:
        _fail("isError flag", "expected True, got False")

    payload = json.loads(result.content[0].text)
    if payload.get("error") == "workflow_required":
        _ok("payload.error == workflow_required")
    else:
        _fail("error code", f"expected workflow_required, got {payload.get('error')}")

    hint = payload.get("routing_hint", {})
    if hint.get("suggested_intent_verb") == "collect_evidence":
        _ok("routing_hint.suggested_intent_verb == collect_evidence")
    else:
        _fail("suggested_intent_verb", f"got {hint.get('suggested_intent_verb')}")

    telemetry_lines = [line for line in err_buf.getvalue().splitlines() if line.startswith("PRETORIN_TELEMETRY_EVENT")]
    if len(telemetry_lines) == 1:
        event = json.loads(telemetry_lines[0].removeprefix("PRETORIN_TELEMETRY_EVENT").strip())
        if event["event_type"] == "workflow_routing_required":
            _ok("PRETORIN_TELEMETRY_EVENT emitted", f"event_type={event['event_type']}")
        else:
            _fail("telemetry event_type", f"got {event['event_type']}")
    else:
        _fail("telemetry emission", f"expected 1 line, got {len(telemetry_lines)}")


async def _recipe_required_error_check() -> None:
    _section("recipe_required -> telemetry")
    from mcp.types import CallToolResult, TextContent

    from pretorin.mcp.server import call_tool

    mock_client = AsyncMock()
    mock_client.is_configured = True
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)

    recipe_required = CallToolResult(
        content=[
            TextContent(
                type="text",
                text=json.dumps(
                    {
                        "error": "recipe_required",
                        "message": "Open a recipe first.",
                        "recipe_gap": {
                            "tool": "create_evidence",
                            "reason": "agent write attempted without recipe_context_id",
                            "requested_evidence_type": "code_snippet",
                            "suggested_next": "call_start_task_then_start_recipe",
                        },
                    }
                ),
            )
        ],
        isError=True,
    )

    with (
        patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
        patch(
            "pretorin.mcp.server.TOOL_HANDLERS",
            {"create_evidence": AsyncMock(return_value=recipe_required)},
        ),
        _captured_stderr() as err_buf,
    ):
        try:
            result = await call_tool(
                "create_evidence",
                {
                    "artifact_content": "source material",
                    "evidence_type": "code_snippet",
                },
            )
        except Exception as exc:
            _fail("call_tool", f"unexpected exception: {exc!r}")
            return

    if getattr(result, "isError", False):
        _ok("recipe_required CallToolResult marked isError=true")
    else:
        _fail("recipe_required isError flag", "expected True, got False")

    payload = json.loads(result.content[0].text)
    if payload.get("error") == "recipe_required":
        _ok("payload.error == recipe_required")
    else:
        _fail("recipe error code", f"expected recipe_required, got {payload.get('error')}")

    telemetry_lines = [line for line in err_buf.getvalue().splitlines() if line.startswith("PRETORIN_TELEMETRY_EVENT")]
    if len(telemetry_lines) == 1:
        event = json.loads(telemetry_lines[0].removeprefix("PRETORIN_TELEMETRY_EVENT").strip())
        if event["event_type"] == "recipe_required":
            _ok("recipe_required telemetry emitted", f"event_type={event['event_type']}")
        else:
            _fail("recipe telemetry event_type", f"got {event['event_type']}")
        if event.get("requested_evidence_type") == "code_snippet":
            _ok("recipe telemetry includes safe evidence shape")
        else:
            _fail("recipe evidence shape", f"got {event.get('requested_evidence_type')}")
    else:
        _fail("recipe telemetry emission", f"expected 1 line, got {len(telemetry_lines)}")


async def _run() -> int:
    print(f"{BOLD}RFC #113 — MCP Cross-Harness Tool Surface{RESET}")
    print(f"{DIM}Smoke test exercises check_context, list_tools, get_instructions,")
    print(f"get_workflow schema bundling, and structured bypass telemetry.{RESET}")

    await _check_context_scenarios()
    await _list_tools_check()
    await _get_instructions_check()
    await _get_workflow_schema_bundling_check()
    await _workflow_routing_error_check()
    await _recipe_required_error_check()

    print()
    if _failures:
        print(f"{RED}{BOLD}FAILED{RESET} — {len(_failures)} check(s) failed, {len(_passes)} passed")
        for line in _failures:
            print(f"  {RED}•{RESET} {line}")
        return 1
    print(f"{GREEN}{BOLD}PASSED{RESET} — all {len(_passes)} checks green")
    return 0


def run_smoke_test() -> int:
    """Entry point invoked by ``pretorin mcp-smoke-test``."""
    return asyncio.run(_run())


if __name__ == "__main__":
    sys.exit(run_smoke_test())
