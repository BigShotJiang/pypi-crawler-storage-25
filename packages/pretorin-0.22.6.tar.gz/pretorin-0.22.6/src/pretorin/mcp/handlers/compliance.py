"""Handlers for compliance workflow tools (narratives, notes, status, monitoring, artifacts)."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from mcp.types import CallToolResult, TextContent

from pretorin.client import PretorianClient
from pretorin.client.api import PretorianClientError
from pretorin.mcp.helpers import (
    VALID_CONTROL_STATUSES,
    VALID_EVENT_TYPES,
    VALID_SEVERITIES,
    format_error,
    format_json,
    format_json_error,
    require,
    resolve_execution_scope,
    resolve_system_id,
    safe_args,
    validate_enum,
)
from pretorin.recipes.context import ExecutionContext, get_default_store
from pretorin.recipes.errors import RecipeContextError
from pretorin.recipes.registry import RecipeRegistry
from pretorin.workflows.ai_generation import draft_control_artifacts

logger = logging.getLogger(__name__)


def _recipe_required_narrative_error() -> CallToolResult:
    return format_json_error(
        {
            "error": "recipe_required",
            "message": (
                "update_narrative is a narrative-recipe write surface for MCP agents. "
                "Open a recipe with produces='narrative' or 'both' and retry with "
                "recipe_context_id plus evidence_ids."
            ),
            "recipe_gap": {
                "tool": "update_narrative",
                "reason": "agent narrative write attempted without recipe_context_id",
                "suggested_next": "start_recipe_with_evidence_ids",
            },
        }
    )


def _resolve_narrative_recipe_context(arguments: dict[str, Any]) -> ExecutionContext | CallToolResult:
    context_id = arguments.get("recipe_context_id")
    if not context_id:
        return _recipe_required_narrative_error()
    try:
        context = get_default_store().get(str(context_id))
    except RecipeContextError as exc:
        return format_error(str(exc))

    entry = RecipeRegistry().get(context.recipe_id)
    if entry is None:
        return format_error(f"Recipe {context.recipe_id!r} is no longer available")
    if entry.active.manifest.produces not in {"narrative", "both"}:
        return format_error(
            f"Recipe {context.recipe_id!r} produces {entry.active.manifest.produces!r}; "
            "update_narrative requires a narrative-producing recipe."
        )
    return context


def _evidence_ids_for_narrative(arguments: dict[str, Any], context: ExecutionContext) -> list[str] | CallToolResult:
    evidence_ids_raw = arguments.get("evidence_ids")
    if evidence_ids_raw is None:
        evidence_ids_raw = context.evidence_ids
    if not isinstance(evidence_ids_raw, list) or any(not isinstance(item, str) for item in evidence_ids_raw):
        return format_json_error(
            {
                "error": "invalid_evidence_ids",
                "message": "Narrative recipe writes require evidence_ids as an array of evidence id strings.",
            }
        )
    evidence_ids = [item for item in evidence_ids_raw if item]
    if not evidence_ids:
        return format_json_error(
            {
                "error": "evidence_citations_required",
                "message": "Narrative recipe writes must cite at least one evidence id.",
            }
        )
    return evidence_ids


async def handle_generate_control_artifacts(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle read-only AI drafting for control narratives and evidence gaps."""
    logger.debug("handle_generate_control_artifacts called with %s", safe_args(arguments))
    err = require(arguments, "system_id", "control_id", "framework_id")
    if err:
        return format_error(err)

    result = await draft_control_artifacts(
        client,
        system=arguments["system_id"],
        framework_id=arguments["framework_id"],
        control_id=arguments["control_id"],
        working_directory=Path(arguments["working_directory"]) if arguments.get("working_directory") else None,
        model=arguments.get("model"),
    )
    return format_json(result)


async def handle_push_monitoring_event(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the push_monitoring_event tool."""
    logger.debug("handle_push_monitoring_event called with %s", safe_args(arguments))
    err = require(arguments, "title")
    if err:
        return format_error(err)

    from pretorin.client.models import MonitoringEventCreate

    event_type = arguments.get("event_type", "security_scan")
    severity = arguments.get("severity", "medium")
    enum_err = validate_enum(event_type, VALID_EVENT_TYPES, "event_type")
    if enum_err:
        return format_error(enum_err)
    enum_err = validate_enum(severity, VALID_SEVERITIES, "severity")
    if enum_err:
        return format_error(enum_err)

    system_id, framework_id, normalized_control_id = await resolve_execution_scope(
        client,
        arguments,
        enforce_active_context=True,
    )
    event = MonitoringEventCreate(
        event_type=event_type,
        title=arguments["title"],
        description=arguments.get("description", ""),
        severity=severity,
        control_id=normalized_control_id,
        framework_id=framework_id,
        event_data={"source": "cli"},
    )
    result = await client.create_monitoring_event(
        system_id=system_id,
        event=event,
    )
    return format_json(result)


async def handle_get_control_context(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent]:
    """Handle the get_control_context tool."""
    logger.debug("handle_get_control_context called with %s", safe_args(arguments))
    system_id, framework_id, normalized_control_id = await resolve_execution_scope(
        client,
        arguments,
        control_required=True,
    )
    ctx = await client.get_control_context(
        system_id=system_id,
        control_id=normalized_control_id or "",
        framework_id=framework_id,
    )
    return format_json(ctx.model_dump())


async def handle_get_scope(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the get_scope tool."""
    logger.debug("handle_get_scope called with %s", safe_args(arguments))
    err = require(arguments, "system_id", "framework_id")
    if err:
        return format_error(err)
    system_id = await resolve_system_id(client, arguments)
    if system_id is None:
        raise PretorianClientError("system_id is required")
    scope = await client.get_scope(
        system_id=system_id,
        framework_id=arguments["framework_id"],
    )
    return format_json(scope.model_dump())


async def handle_patch_scope_qa(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the patch_scope_qa tool."""
    logger.debug("handle_patch_scope_qa called with %s", safe_args(arguments))
    err = require(arguments, "system_id", "framework_id")
    if err:
        return format_error(err)
    if "updates" not in arguments:
        return format_error("Missing required parameter(s): updates")
    system_id = await resolve_system_id(client, arguments)
    if system_id is None:
        raise PretorianClientError("system_id is required")
    updates = arguments["updates"]
    if not isinstance(updates, list) or not updates:
        return format_error("updates must be a non-empty list of {question_id, answer} objects")
    scope = await client.patch_scope_qa(
        system_id=system_id,
        framework_id=arguments["framework_id"],
        updates=updates,
    )
    return format_json(scope.model_dump())


async def handle_list_org_policies(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the list_org_policies tool."""
    logger.debug("handle_list_org_policies called")
    result = await client.list_org_policies()
    return format_json(result.model_dump())


async def handle_get_org_policy_questionnaire(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the get_org_policy_questionnaire tool."""
    logger.debug("handle_get_org_policy_questionnaire called with %s", safe_args(arguments))
    err = require(arguments, "policy_id")
    if err:
        return format_error(err)
    result = await client.get_org_policy_questionnaire(arguments["policy_id"])
    return format_json(result.model_dump())


async def handle_patch_org_policy_qa(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the patch_org_policy_qa tool."""
    logger.debug("handle_patch_org_policy_qa called with %s", safe_args(arguments))
    err = require(arguments, "policy_id")
    if err:
        return format_error(err)
    if "updates" not in arguments:
        return format_error("Missing required parameter(s): updates")
    updates = arguments["updates"]
    if not isinstance(updates, list) or not updates:
        return format_error("updates must be a non-empty list of {question_id, answer} objects")
    result = await client.patch_org_policy_qa(
        policy_id=arguments["policy_id"],
        updates=updates,
    )
    return format_json(result.model_dump())


async def handle_add_control_note(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the add_control_note tool."""
    logger.debug("handle_add_control_note called with %s", safe_args(arguments))
    err = require(arguments, "control_id", "content")
    if err:
        return format_error(err)

    system_id, framework_id, normalized_control_id = await resolve_execution_scope(
        client,
        arguments,
        control_required=True,
        enforce_active_context=True,
    )
    result = await client.add_control_note(
        system_id=system_id,
        control_id=normalized_control_id or "",
        content=arguments["content"],
        framework_id=framework_id,
        source="cli",
    )
    return format_json(result)


async def handle_resolve_control_note(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the resolve_control_note tool."""
    logger.debug("handle_resolve_control_note called with %s", safe_args(arguments))
    err = require(arguments, "control_id", "note_id")
    if err:
        return format_error(err)

    is_resolved = arguments.get("is_resolved", True)
    if is_resolved and not arguments.get("resolution_note"):
        return format_error("resolution_note is required when is_resolved is true")

    system_id, framework_id, normalized_control_id = await resolve_execution_scope(
        client,
        arguments,
        control_required=True,
        enforce_active_context=True,
    )
    result = await client.resolve_control_note(
        system_id=system_id,
        control_id=normalized_control_id or "",
        note_id=arguments["note_id"],
        framework_id=framework_id,
        is_resolved=is_resolved,
        resolution_note=arguments.get("resolution_note"),
        content=arguments.get("content"),
        is_pinned=arguments.get("is_pinned"),
    )
    return format_json(result)


async def handle_get_control_notes(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent]:
    """Handle the get_control_notes tool."""
    logger.debug("handle_get_control_notes called with %s", safe_args(arguments))
    system_id, framework_id, normalized_control_id = await resolve_execution_scope(
        client,
        arguments,
        control_required=True,
    )
    notes = await client.list_control_notes(
        system_id=system_id,
        control_id=normalized_control_id or "",
        framework_id=framework_id,
    )
    return format_json(
        {
            "control_id": normalized_control_id,
            "system_id": system_id,
            "framework_id": framework_id,
            "total": len(notes),
            "notes": notes,
        }
    )


async def handle_update_narrative(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the update_narrative tool."""
    logger.debug("handle_update_narrative called with %s", safe_args(arguments))
    err = require(arguments, "control_id", "narrative")
    if err:
        return format_error(err)

    recipe_context = _resolve_narrative_recipe_context(arguments)
    if isinstance(recipe_context, CallToolResult):
        return recipe_context
    evidence_ids = _evidence_ids_for_narrative(arguments, recipe_context)
    if isinstance(evidence_ids, CallToolResult):
        return evidence_ids

    system_id, framework_id, normalized_control_id = await resolve_execution_scope(
        client,
        arguments,
        control_required=True,
        enforce_active_context=True,
    )
    try:
        result = await client.update_narrative(
            system_id=system_id,
            control_id=normalized_control_id or "",
            framework_id=framework_id,
            narrative=arguments["narrative"],
            is_ai_generated=arguments.get("is_ai_generated", False),
            recipe_context_id=recipe_context.context_id,
            evidence_ids=evidence_ids,
        )
    except ValueError as e:
        return format_error(str(e))
    get_default_store().record_narrative_write(recipe_context.context_id)
    return format_json(result)


async def handle_update_control_status(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the update_control_status tool."""
    logger.debug("handle_update_control_status called with %s", safe_args(arguments))
    err = require(arguments, "control_id", "status")
    if err:
        return format_error(err)

    enum_err = validate_enum(arguments["status"], VALID_CONTROL_STATUSES, "status")
    if enum_err:
        return format_error(enum_err)

    system_id, framework_id, normalized_control_id = await resolve_execution_scope(
        client,
        arguments,
        control_required=True,
        enforce_active_context=True,
    )
    result = await client.update_control_status(
        system_id=system_id,
        control_id=normalized_control_id or "",
        status=arguments["status"],
        framework_id=framework_id,
    )
    return format_json(result)


async def handle_get_control_implementation(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Handle the get_control_implementation tool."""
    logger.debug("handle_get_control_implementation called with %s", safe_args(arguments))
    err = require(arguments, "control_id")
    if err:
        return format_error(err)

    system_id, framework_id, normalized_control_id = await resolve_execution_scope(
        client,
        arguments,
        control_required=True,
        enforce_active_context=True,
    )
    impl = await client.get_control_implementation(
        system_id=system_id,
        control_id=normalized_control_id or "",
        framework_id=framework_id,
    )
    return format_json(
        {
            "control_id": impl.control_id,
            "system_id": system_id,
            "status": impl.status,
            "narrative": impl.narrative,
            "evidence_count": impl.evidence_count,
            "notes": impl.notes,
        }
    )
