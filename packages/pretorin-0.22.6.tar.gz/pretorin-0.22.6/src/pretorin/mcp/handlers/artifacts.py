"""MCP handlers for the system_spec surface (issue #133).

Three tools, all thin wrappers over `/api/v1/public/systems/{id}/spec/*`:

- ``list_artifact_requirements`` — read-side; lists the 5 artifact kinds.
- ``get_asset_inventory`` — read-side; returns active or historical rows.
- ``submit_asset_inventory_diff`` — write-side; posts a recipe-driven diff.

The diff endpoint accepts ``recipe_context_id`` cleanly (the historical write
bug is fixed per the issue's pinned comment), but unlike ``create_evidence``
it does NOT require an active recipe context — the platform stores
``source = "cli:<recipe_id>"`` per row from whatever ``recipe_id`` the agent
passes. Validate that the optional ``recipe_context_id`` resolves cleanly when
supplied; otherwise let the platform validate the payload shape.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from mcp.types import CallToolResult, TextContent

from pretorin.client import PretorianClient
from pretorin.client.api import PretorianClientError
from pretorin.mcp.helpers import (
    format_error,
    format_json,
    require,
    resolve_recipe_context,
    resolve_system_id,
    safe_args,
)
from pretorin.recipes.errors import RecipeContextError
from pretorin.spec import build_inventory_idempotency_key

logger = logging.getLogger(__name__)


async def _require_system_id(client: PretorianClient, arguments: dict[str, Any]) -> str:
    """Resolve system_id and narrow Optional[str] -> str for type checks."""
    system_id = await resolve_system_id(client, arguments)
    if system_id is None:
        raise PretorianClientError("system_id is required")
    return system_id


async def handle_list_artifact_requirements(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """List the 5 artifact kinds with current toggle/attestation state."""
    logger.debug("handle_list_artifact_requirements called with %s", safe_args(arguments))
    err = require(arguments, "system_id")
    if err:
        return format_error(err)
    try:
        system_id = await _require_system_id(client, arguments)
        result = await client.list_spec_kinds(system_id)
    except PretorianClientError as exc:
        return format_error(exc.message)
    return format_json(result)


async def handle_get_asset_inventory(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Return the active asset inventory, or historical rows when as_of is supplied."""
    logger.debug("handle_get_asset_inventory called with %s", safe_args(arguments))
    err = require(arguments, "system_id")
    if err:
        return format_error(err)
    try:
        system_id = await _require_system_id(client, arguments)
        result = await client.get_asset_inventory(system_id, as_of=arguments.get("as_of"))
    except PretorianClientError as exc:
        return format_error(exc.message)
    return format_json(result)


async def handle_submit_asset_inventory_diff(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Submit a recipe-driven asset-inventory diff.

    Required: ``system_id``, ``recipe_id``. At least one of
    ``added`` / ``modified`` / ``decommissioned`` must be a non-empty array.
    ``idempotency_key`` is derived from ``(system_id, recipe_id, scan_timestamp)``
    when not supplied; agents replaying a scan should pass their own key.
    ``recipe_context_id`` is optional and threaded through when set.
    """
    logger.debug("handle_submit_asset_inventory_diff called with %s", safe_args(arguments))
    err = require(arguments, "system_id", "recipe_id")
    if err:
        return format_error(err)

    added = arguments.get("added") or []
    modified = arguments.get("modified") or []
    decommissioned = arguments.get("decommissioned") or []
    for name, value in (("added", added), ("modified", modified), ("decommissioned", decommissioned)):
        if not isinstance(value, list):
            return format_error(f"{name} must be an array of asset rows")
    if not (added or modified or decommissioned):
        return format_error("at least one of added / modified / decommissioned must be non-empty")

    try:
        recipe_context = resolve_recipe_context(arguments)
    except RecipeContextError as exc:
        return format_error(str(exc))

    try:
        system_id = await _require_system_id(client, arguments)
    except PretorianClientError as exc:
        return format_error(exc.message)

    recipe_id = str(arguments["recipe_id"])
    idempotency_key = arguments.get("idempotency_key")
    if not idempotency_key:
        idempotency_key = build_inventory_idempotency_key(
            system_id,
            recipe_id,
            datetime.now(timezone.utc).isoformat(),
        )

    try:
        result = await client.submit_inventory_diff(
            system_id,
            idempotency_key=str(idempotency_key),
            recipe_id=recipe_id,
            added=added,
            modified=modified,
            decommissioned=decommissioned,
            recipe_context_id=recipe_context.context_id if recipe_context else None,
        )
    except PretorianClientError as exc:
        return format_error(exc.message)
    return format_json(result)
