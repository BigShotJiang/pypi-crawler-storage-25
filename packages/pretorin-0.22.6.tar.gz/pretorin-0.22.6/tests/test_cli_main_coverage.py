"""Coverage tests for src/pretorin/cli/main.py.

Targets missing lines: show_banner, _should_show_update_notice,
_maybe_print_update_notice, _version_callback, main callback (JSON output),
version command, update command, mcp_serve command.
"""

from __future__ import annotations

import json
import sys
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from pretorin import __version__
from pretorin.cli.main import (
    _build_upgrade_command,
    _detect_installer,
    _manual_upgrade_hint,
    _should_show_update_notice,
    app,
    show_banner,
)
from pretorin.cli.output import set_json_mode

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_json_mode():
    set_json_mode(False)
    yield
    set_json_mode(False)


# ---------------------------------------------------------------------------
# --version flag
# ---------------------------------------------------------------------------


class TestVersionFlag:
    def test_version_flag_prints_version_and_exits(self):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_short_version_flag(self):
        result = runner.invoke(app, ["-V"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_version_flag_includes_pretorin_label(self):
        result = runner.invoke(app, ["--version"])
        assert "pretorin" in result.output.lower()


# ---------------------------------------------------------------------------
# No-subcommand (banner + help)
# ---------------------------------------------------------------------------


class TestNoSubcommand:
    def test_no_args_exits_zero(self):
        result = runner.invoke(app, [])
        assert result.exit_code == 0

    def test_no_args_outputs_something(self):
        result = runner.invoke(app, [])
        assert result.output.strip() != ""

    def test_json_flag_no_subcommand_prints_json_version(self):
        result = runner.invoke(app, ["--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["version"] == __version__


# ---------------------------------------------------------------------------
# version subcommand
# ---------------------------------------------------------------------------


class TestVersionSubcommand:
    def test_version_subcommand_prints_version(self):
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_version_subcommand_includes_label(self):
        result = runner.invoke(app, ["version"])
        assert "pretorin" in result.output.lower()


# ---------------------------------------------------------------------------
# _should_show_update_notice
# ---------------------------------------------------------------------------


class TestShouldShowUpdateNotice:
    def test_returns_false_when_json_output(self):
        assert _should_show_update_notice(json_output=True) is False

    def test_returns_false_when_subcommand_is_update(self):
        assert _should_show_update_notice(invoked_subcommand="update") is False

    def test_returns_false_when_subcommand_is_mcp_serve(self):
        assert _should_show_update_notice(invoked_subcommand="mcp-serve") is False

    def test_returns_false_when_not_a_tty(self):
        with patch("sys.stdout") as mock_stdout:
            mock_stdout.isatty = lambda: False
            result = _should_show_update_notice()
        assert result is False

    def test_returns_true_when_tty_and_no_exclusions(self):
        with patch("sys.stdout") as mock_stdout:
            mock_stdout.isatty = lambda: True
            result = _should_show_update_notice()
        assert result is True

    def test_json_output_overrides_tty(self):
        with patch("sys.stdout") as mock_stdout:
            mock_stdout.isatty = lambda: True
            result = _should_show_update_notice(json_output=True)
        assert result is False


# ---------------------------------------------------------------------------
# show_banner
# ---------------------------------------------------------------------------


class TestShowBanner:
    def test_show_banner_without_update_check_does_not_call_update(self):
        with patch("pretorin.cli.main._maybe_print_update_notice") as mock_notice:
            show_banner(check_updates=False)
        mock_notice.assert_not_called()

    def test_show_banner_with_update_check_calls_notice(self):
        with patch("pretorin.cli.main._maybe_print_update_notice") as mock_notice:
            show_banner(check_updates=True)
        mock_notice.assert_called_once()


# ---------------------------------------------------------------------------
# update command
# ---------------------------------------------------------------------------


class TestUpdateCommand:
    """High-level smoke coverage for `pretorin update`.

    The detailed behavior lives in TestBuildUpgradeCommand and
    TestUpdateDispatchesToInstaller below. The pre-publish design had a
    JSON-API + post-install-verify path; that's been removed in favor of
    propagating the installer's exit code directly.
    """

    def test_update_invokes_pip_in_pip_install(self):
        with patch("subprocess.run", return_value=MagicMock(returncode=0)) as mock_run:
            result = runner.invoke(app, ["update"])

        assert result.exit_code == 0
        argv = mock_run.call_args[0][0]
        # Default detect path lands on `pip` for non-uv / non-pipx interpreters.
        assert "pretorin" in argv[-1] or argv[-1] == "pretorin"
        assert "--no-cache-dir" in argv

    def test_update_propagates_installer_failure_exit_code(self):
        with patch("subprocess.run", return_value=MagicMock(returncode=2)):
            result = runner.invoke(app, ["update"])

        assert result.exit_code == 2

    def test_update_specific_version_pins(self):
        with patch("subprocess.run", return_value=MagicMock(returncode=0)) as mock_run:
            result = runner.invoke(app, ["update", "0.14.0"])

        assert result.exit_code == 0
        argv = mock_run.call_args[0][0]
        assert "pretorin==0.14.0" in argv


# ---------------------------------------------------------------------------
# Installer detection + upgrade-command dispatch
# ---------------------------------------------------------------------------


class TestInstallerDetection:
    def test_detect_uv_tool_install(self):
        assert _detect_installer("/Users/x/.local/share/uv/tools/pretorin/bin/python3") == "uv"

    def test_detect_uv_tool_receipt_with_custom_tool_dir(self, tmp_path):
        venv = tmp_path / "tools" / "pretorin"
        (venv / "bin").mkdir(parents=True)
        (venv / "pyvenv.cfg").write_text("include-system-site-packages = false\n")
        (venv / "uv-receipt.toml").write_text("[tool]\n")

        assert _detect_installer(str(venv / "bin" / "python")) == "uv"

    def test_detect_uv_tool_receipt_with_symlinked_python(self, tmp_path):
        venv = tmp_path / "tools" / "pretorin"
        (venv / "bin").mkdir(parents=True)
        (venv / "pyvenv.cfg").write_text("include-system-site-packages = false\n")
        (venv / "uv-receipt.toml").write_text("[tool]\n")
        python = venv / "bin" / "python"
        try:
            python.symlink_to(sys.executable)
        except (NotImplementedError, OSError):
            pytest.skip("symlinks are not available")

        assert _detect_installer(str(python)) == "uv"

    def test_detect_pipx_install(self):
        assert _detect_installer("/Users/x/.local/pipx/venvs/pretorin/bin/python") == "pipx"

    def test_detect_pipx_metadata_with_custom_home(self, tmp_path):
        venv = tmp_path / "home" / "venvs" / "pretorin"
        (venv / "bin").mkdir(parents=True)
        (venv / "pyvenv.cfg").write_text("include-system-site-packages = false\n")
        (venv / "pipx_metadata.json").write_text("{}\n")

        assert _detect_installer(str(venv / "bin" / "python")) == "pipx"

    def test_detect_pip_fallback(self):
        assert _detect_installer("/usr/local/bin/python3") == "pip"

    def test_detect_uv_case_insensitive(self):
        # Path matching must be case-insensitive so Windows-style paths
        # (case-insensitive filesystem) work the same as POSIX
        assert _detect_installer("/opt/UV/Tools/pretorin/bin/python") == "uv"


class TestBuildUpgradeCommand:
    def test_uv_latest_uses_at_latest_spec(self):
        """Unpinned upgrades go through `pretorin@latest` to dodge index-propagation lag.

        Regression for the case where `pretorin update` was telling uv to
        install `pretorin==<freshly-published-version>` and uv's
        simple-index resolver hadn't caught up yet, so the strict pin
        failed with "No solution found". `@latest` is the resolver path
        that works in that window.
        """
        with patch("shutil.which", return_value="/opt/bin/uv"):
            cmd = _build_upgrade_command("uv", None)
        assert cmd == ["/opt/bin/uv", "tool", "install", "--force", "pretorin@latest"]

    def test_uv_pinned_adds_refresh_to_bypass_cache(self):
        """Explicit-version pins use --refresh so uv re-fetches the index."""
        with patch("shutil.which", return_value="/opt/bin/uv"):
            cmd = _build_upgrade_command("uv", "0.21.2")
        assert cmd == [
            "/opt/bin/uv",
            "tool",
            "install",
            "--force",
            "--refresh",
            "pretorin==0.21.2",
        ]

    def test_pipx_latest_uses_no_cache(self):
        with patch("shutil.which", return_value="/opt/bin/pipx"):
            cmd = _build_upgrade_command("pipx", None)
        assert cmd == ["/opt/bin/pipx", "upgrade", "pretorin", "--pip-args=--no-cache-dir"]

    def test_pipx_pinned_uses_no_cache(self):
        with patch("shutil.which", return_value="/opt/bin/pipx"):
            cmd = _build_upgrade_command("pipx", "0.22.2")
        assert cmd == [
            "/opt/bin/pipx",
            "install",
            "--force",
            "pretorin==0.22.2",
            "--pip-args=--no-cache-dir",
        ]

    def test_pip_default_uses_no_cache(self):
        cmd = _build_upgrade_command("pip", None)
        assert cmd is not None
        assert cmd[1:] == ["-m", "pip", "install", "--upgrade", "--no-cache-dir", "pretorin"]

    def test_returns_none_when_uv_missing(self):
        with patch("shutil.which", return_value=None):
            assert _build_upgrade_command("uv", None) is None


class TestManualHint:
    def test_uv_hint_pinned_includes_refresh(self):
        assert "--refresh" in _manual_upgrade_hint("uv", "0.21.2")
        assert "pretorin==0.21.2" in _manual_upgrade_hint("uv", "0.21.2")

    def test_uv_hint_latest_uses_at_latest(self):
        assert _manual_upgrade_hint("uv", None) == "uv tool install --force pretorin@latest"

    def test_pipx_hint_latest_includes_no_cache(self):
        assert "--no-cache-dir" in _manual_upgrade_hint("pipx", None)

    def test_pip_hint_default_uses_no_cache(self):
        assert "--no-cache-dir" in _manual_upgrade_hint("pip", None)


class TestUpdateDispatchesToInstaller:
    def test_uv_update_without_version_uses_at_latest(self):
        """`pretorin update` (no args) dispatches `uv tool install --force pretorin@latest`.

        Regression: the previous design pre-resolved the latest version via
        the PyPI JSON API and passed it as a strict `==X.Y.Z` pin to uv.
        Immediately after a release the JSON API can return a version that
        uv's simple-index resolver hasn't seen yet, so the pin failed with
        "No solution found." Letting uv resolve `@latest` itself eliminates
        the dual-index-view inconsistency.
        """
        with patch("pretorin.cli.main._detect_installer", return_value="uv"):
            with patch("shutil.which", return_value="/opt/bin/uv"):
                with patch("subprocess.run", return_value=MagicMock(returncode=0)) as mock_run:
                    result = runner.invoke(app, ["update"])

        assert result.exit_code == 0
        mock_run.assert_called_once()
        upgrade_argv = mock_run.call_args[0][0]
        assert upgrade_argv == ["/opt/bin/uv", "tool", "install", "--force", "pretorin@latest"]

    def test_uv_update_with_explicit_version_uses_refresh(self):
        with patch("pretorin.cli.main._detect_installer", return_value="uv"):
            with patch("shutil.which", return_value="/opt/bin/uv"):
                with patch("subprocess.run", return_value=MagicMock(returncode=0)) as mock_run:
                    result = runner.invoke(app, ["update", "99.9.9"])

        assert result.exit_code == 0
        upgrade_argv = mock_run.call_args[0][0]
        assert upgrade_argv == [
            "/opt/bin/uv",
            "tool",
            "install",
            "--force",
            "--refresh",
            "pretorin==99.9.9",
        ]

    def test_propagates_installer_exit_code(self):
        """When uv/pipx/pip exits non-zero, propagate that exit code unchanged.

        Don't try to second-guess the installer with a post-install verify
        step — the installer is the source of truth.
        """
        with patch("pretorin.cli.main._detect_installer", return_value="uv"):
            with patch("shutil.which", return_value="/opt/bin/uv"):
                with patch("subprocess.run", return_value=MagicMock(returncode=42)):
                    result = runner.invoke(app, ["update"])

        assert result.exit_code == 42

    def test_does_not_call_pypi_json_api(self):
        """The update path must not hit the JSON metadata API.

        The old design pre-resolved the latest version via the JSON endpoint
        and passed it as a `==` pin to uv, creating a dual-index-view race
        whenever JSON and the simple index disagreed.
        """
        with patch("pretorin.cli.main._detect_installer", return_value="uv"):
            with patch("shutil.which", return_value="/opt/bin/uv"):
                with patch("subprocess.run", return_value=MagicMock(returncode=0)):
                    with patch("pretorin.cli.version_check._fetch_latest_version") as mock_fetch:
                        runner.invoke(app, ["update"])

        mock_fetch.assert_not_called()

    def test_uv_missing_binary_prints_at_latest_manual_hint(self):
        """When uv isn't on PATH, the printed fallback must use the @latest form."""
        with patch("pretorin.cli.main._detect_installer", return_value="uv"):
            with patch("shutil.which", return_value=None):
                result = runner.invoke(app, ["update"])

        assert result.exit_code == 1
        assert "pretorin@latest" in result.output


# ---------------------------------------------------------------------------
# mcp-serve command
# ---------------------------------------------------------------------------


class TestMcpServeCommand:
    def test_mcp_serve_calls_run_server(self):
        with patch("pretorin.mcp.server.run_server") as mock_run:
            result = runner.invoke(app, ["mcp-serve"])

        assert result.exit_code == 0
        mock_run.assert_called_once()
