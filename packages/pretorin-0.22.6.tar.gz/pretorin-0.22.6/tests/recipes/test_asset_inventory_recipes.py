"""Smoke tests for the four asset-inventory recipes (issue #133).

These recipes live under ``src/pretorin/recipes/_recipes/asset-inventory-*/``
and produce an asset-inventory diff (added / modified / decommissioned) that
the CLI / MCP layer then posts to ``POST /spec/inventory/diff``.

This file verifies:
  - All four recipes load cleanly through the registry.
  - Each one declares a ``produce_diff`` script.
  - The iac-workspace recipe actually runs over a tmp workspace and emits the
    expected diff shape.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from pretorin.recipes import loader as loader_module
from pretorin.recipes.loader import clear_cache
from pretorin.recipes.registry import RecipeRegistry
from pretorin.recipes.runner import RecipeScriptContext, run_script

_ASSET_INVENTORY_RECIPE_IDS = [
    "asset-inventory-aws-baseline",
    "asset-inventory-azure-baseline",
    "asset-inventory-k8s-baseline",
    "asset-inventory-iac-workspace",
]


@pytest.fixture(autouse=True)
def _isolate_cache(tmp_path, monkeypatch):
    """Hide user/project recipes so the registry only sees built-ins."""
    clear_cache()
    monkeypatch.setattr(loader_module, "_user_recipes_root", lambda: tmp_path / "no-user")
    monkeypatch.setattr(loader_module, "_project_recipes_root", lambda start=None: None)


def test_all_four_asset_inventory_recipes_load() -> None:
    registry = RecipeRegistry()
    ids = {entry.active.manifest.id for entry in registry.entries()}
    for recipe_id in _ASSET_INVENTORY_RECIPE_IDS:
        assert recipe_id in ids, f"missing built-in asset-inventory recipe: {recipe_id}"


@pytest.mark.parametrize("recipe_id", _ASSET_INVENTORY_RECIPE_IDS)
def test_each_recipe_has_produce_diff_script(recipe_id: str) -> None:
    registry = RecipeRegistry()
    entry = registry.get(recipe_id)
    assert entry is not None
    manifest = entry.active.manifest
    assert "produce_diff" in manifest.scripts
    assert manifest.scripts["produce_diff"].path == "scripts/produce_diff.py"
    assert manifest.tier == "official"


@pytest.mark.parametrize("recipe_id", _ASSET_INVENTORY_RECIPE_IDS)
def test_each_recipe_declares_expected_source_kind(recipe_id: str) -> None:
    registry = RecipeRegistry()
    entry = registry.get(recipe_id)
    assert entry is not None
    source_kinds = {req.kind for req in entry.active.manifest.requires.sources}
    if recipe_id == "asset-inventory-aws-baseline":
        assert "aws_account" in source_kinds
    elif recipe_id == "asset-inventory-azure-baseline":
        assert "azure_tenant" in source_kinds
    elif recipe_id == "asset-inventory-k8s-baseline":
        assert "k8s_cluster" in source_kinds
    elif recipe_id == "asset-inventory-iac-workspace":
        assert "workspace_repo" in source_kinds


@pytest.mark.anyio
async def test_iac_workspace_finds_terraform_aws_instance(tmp_path: Path) -> None:
    """End-to-end smoke: drop a .tf file and confirm the recipe extracts the instance."""
    (tmp_path / "main.tf").write_text(
        """
        resource "aws_instance" "web" {
          ami           = "ami-12345"
          instance_type = "t3.small"
        }
        resource "random_id" "unrelated" {
          byte_length = 4
        }
        """,
        encoding="utf-8",
    )
    registry = RecipeRegistry()
    entry = registry.get("asset-inventory-iac-workspace")
    assert entry is not None

    ctx = RecipeScriptContext(
        system_id="sys-1",
        framework_id=None,
        api_client=AsyncMock(),
        logger=__import__("logging").getLogger("test"),
        recipe_id="asset-inventory-iac-workspace",
        recipe_version="0.1.0",
        recipe_context_id=None,
    )
    result = await run_script(
        recipe=entry.active,
        script_name="produce_diff",
        ctx=ctx,
        params={"last_seen_inventory": [], "root": str(tmp_path)},
    )
    # Only the aws_instance resource should land in the diff; random_id is filtered out.
    assert any(row["external_id"] == "aws_instance.web" for row in result["added"])
    assert all(row["external_id"] != "random_id.unrelated" for row in result["added"])
    assert result["modified"] == []
    assert result["decommissioned"] == []


@pytest.mark.anyio
async def test_iac_workspace_marks_missing_assets_decommissioned(tmp_path: Path) -> None:
    """If a previously-seen external_id is absent from the cwd, it's decommissioned."""
    (tmp_path / "main.tf").write_text('resource "aws_instance" "still_here" { ami = "ami-1" }\n', encoding="utf-8")
    registry = RecipeRegistry()
    entry = registry.get("asset-inventory-iac-workspace")
    assert entry is not None

    ctx = RecipeScriptContext(
        system_id="sys-1",
        framework_id=None,
        api_client=AsyncMock(),
        logger=__import__("logging").getLogger("test"),
        recipe_id="asset-inventory-iac-workspace",
        recipe_version="0.1.0",
        recipe_context_id=None,
    )
    result = await run_script(
        recipe=entry.active,
        script_name="produce_diff",
        ctx=ctx,
        params={
            "last_seen_inventory": [
                {
                    "external_id": "aws_instance.still_here",
                    "name": "still_here",
                    "asset_type": "server",
                    "environment": "prod",
                    "criticality": "moderate",
                    "data_classification": "internal",
                },
                {
                    "external_id": "aws_instance.gone",
                    "name": "gone",
                    "asset_type": "server",
                },
            ],
            "root": str(tmp_path),
        },
    )
    assert any(row["external_id"] == "aws_instance.gone" for row in result["decommissioned"])
    assert all(row.get("external_id") != "aws_instance.still_here" for row in result["added"])
