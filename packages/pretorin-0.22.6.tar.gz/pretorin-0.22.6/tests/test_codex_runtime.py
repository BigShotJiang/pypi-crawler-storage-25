"""Tests for Codex runtime binary management."""

from __future__ import annotations

import stat
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from pretorin.agent.codex_runtime import BinaryTrustAssessment, CodexRuntime, _detect_platform


class TestDetectPlatform:
    """Platform detection tests."""

    def test_darwin_arm64(self) -> None:
        with patch("pretorin.agent.codex_runtime.platform") as mock_platform:
            mock_platform.system.return_value = "Darwin"
            mock_platform.machine.return_value = "arm64"
            assert _detect_platform() == "darwin-arm64"

    def test_darwin_x64(self) -> None:
        with patch("pretorin.agent.codex_runtime.platform") as mock_platform:
            mock_platform.system.return_value = "Darwin"
            mock_platform.machine.return_value = "x86_64"
            assert _detect_platform() == "darwin-x64"

    def test_linux_x64(self) -> None:
        with patch("pretorin.agent.codex_runtime.platform") as mock_platform:
            mock_platform.system.return_value = "Linux"
            mock_platform.machine.return_value = "x86_64"
            assert _detect_platform() == "linux-x64"

    def test_unsupported_platform_raises(self) -> None:
        with patch("pretorin.agent.codex_runtime.platform") as mock_platform:
            mock_platform.system.return_value = "Windows"
            mock_platform.machine.return_value = "AMD64"
            with pytest.raises(RuntimeError, match="Unsupported platform"):
                _detect_platform()


class TestCodexRuntime:
    """CodexRuntime lifecycle tests."""

    def test_binary_path_includes_version(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1.0.0")
        runtime.bin_dir = tmp_path / "bin"
        assert runtime.binary_path == tmp_path / "bin" / "codex-test-v1.0.0"

    def test_is_installed_false_when_missing(self, tmp_path: Path) -> None:
        runtime = CodexRuntime()
        runtime.bin_dir = tmp_path / "bin"
        assert not runtime.is_installed

    def test_is_installed_true_when_executable(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1")
        runtime.bin_dir = tmp_path / "bin"
        runtime.bin_dir.mkdir(parents=True)
        binary = runtime.binary_path
        binary.write_text("#!/bin/sh\necho test")
        binary.chmod(binary.stat().st_mode | stat.S_IXUSR)
        assert runtime.is_installed

    def test_is_installed_false_when_not_executable(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1")
        runtime.bin_dir = tmp_path / "bin"
        runtime.bin_dir.mkdir(parents=True)
        binary = runtime.binary_path
        binary.write_text("not executable")
        binary.chmod(stat.S_IRUSR | stat.S_IWUSR)
        assert not runtime.is_installed

    def test_build_env_isolates_codex_home(self, tmp_path: Path) -> None:
        runtime = CodexRuntime()
        runtime.codex_home = tmp_path / "codex"
        env = runtime.build_env(api_key="sk-test", base_url="https://example.com/v1")

        assert env["CODEX_HOME"] == str(tmp_path / "codex")
        assert env["OPENAI_API_KEY"] == "sk-test"
        assert env["OPENAI_BASE_URL"] == "https://example.com/v1"
        assert "PATH" in env
        assert "HOME" in env

    def test_build_env_raises_when_api_key_missing(self, tmp_path: Path) -> None:
        runtime = CodexRuntime()
        runtime.codex_home = tmp_path / "codex"
        with pytest.raises(RuntimeError, match="OPENAI_API_KEY is not set"):
            runtime.build_env(api_key="", base_url="https://example.com/v1")

    def test_build_env_accepts_extra_vars(self, tmp_path: Path) -> None:
        runtime = CodexRuntime()
        runtime.codex_home = tmp_path / "codex"
        env = runtime.build_env(
            api_key="sk-test",
            base_url="https://example.com/v1",
            CUSTOM_VAR="custom_value",
        )
        assert env["CUSTOM_VAR"] == "custom_value"

    def test_write_config_creates_isolated_toml(self, tmp_path: Path) -> None:
        runtime = CodexRuntime()
        runtime.codex_home = tmp_path / "codex"

        config_path = runtime.write_config(
            model="gpt-4o",
            provider_name="pretorin",
            base_url="https://platform.pretorin.com/api/v1/public/model",
            env_key="OPENAI_API_KEY",
        )

        assert config_path == tmp_path / "codex" / "config.toml"
        assert config_path.exists()

        content = config_path.read_text()
        assert 'model_provider = "pretorin"' in content
        assert 'base_url = "https://platform.pretorin.com/api/v1/public/model"' in content
        assert 'env_key = "OPENAI_API_KEY"' in content
        assert "[mcp_servers.pretorin]" in content
        assert 'command = "pretorin"' in content
        assert 'args = ["mcp-serve"]' in content

    def test_write_config_does_not_touch_user_codex(self, tmp_path: Path) -> None:
        runtime = CodexRuntime()
        runtime.codex_home = tmp_path / "codex"

        # Simulate a user's ~/.codex/config.toml
        user_codex = tmp_path / ".codex"
        user_codex.mkdir()
        user_config = user_codex / "config.toml"
        user_config.write_text("# user config\n")

        runtime.write_config(
            model="gpt-4o",
            provider_name="pretorin",
            base_url="https://example.com/v1",
            env_key="OPENAI_API_KEY",
        )

        # User's config must remain untouched
        assert user_config.read_text() == "# user config\n"

    def test_write_config_merges_user_mcp_servers(self, tmp_path: Path) -> None:
        runtime = CodexRuntime()
        runtime.codex_home = tmp_path / "codex"

        # Create a user mcp.json
        mcp_dir = tmp_path / ".pretorin"
        mcp_dir.mkdir()
        mcp_json = mcp_dir / "mcp.json"
        mcp_json.write_text('{"servers": {"github": {"command": "uvx", "args": ["mcp-server-github"]}}}')

        with patch("pathlib.Path.home", return_value=tmp_path):
            config_path = runtime.write_config(
                model="gpt-4o",
                provider_name="pretorin",
                base_url="https://example.com/v1",
                env_key="OPENAI_API_KEY",
            )

        content = config_path.read_text()
        assert "[mcp_servers.pretorin]" in content
        assert "[mcp_servers.github]" in content
        assert 'command = "uvx"' in content

    def test_ensure_installed_returns_path_when_already_installed(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1")
        runtime.bin_dir = tmp_path / "bin"
        runtime.bin_dir.mkdir(parents=True)
        binary = runtime.binary_path
        binary.write_text("#!/bin/sh\necho test")
        binary.chmod(binary.stat().st_mode | stat.S_IXUSR)

        result = runtime.ensure_installed()
        assert result == binary

    def test_assess_binary_trust_reports_missing_binary(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1")
        runtime.bin_dir = tmp_path / "bin"

        assessment = runtime.assess_binary_trust()

        assert assessment == BinaryTrustAssessment(
            trusted=None,
            status="not_installed",
            detail=f"Codex binary not found at {runtime.binary_path}",
        )

    def test_assess_binary_trust_uses_spctl_on_macos(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1")
        runtime.bin_dir = tmp_path / "bin"
        runtime.bin_dir.mkdir(parents=True)
        runtime.binary_path.write_text("#!/bin/sh\necho codex")
        runtime.binary_path.chmod(runtime.binary_path.stat().st_mode | stat.S_IXUSR)

        completed = MagicMock(returncode=0, stdout="", stderr=f"{runtime.binary_path}: accepted")
        with (
            patch("pretorin.agent.codex_runtime.platform.system", return_value="Darwin"),
            patch("pretorin.agent.codex_runtime.subprocess.run", return_value=completed) as mock_run,
        ):
            assessment = runtime.assess_binary_trust()

        assert assessment.trusted is True
        assert assessment.status == "trusted"
        assert "accepted" in assessment.detail
        assert mock_run.call_args[0][0][:4] == ["spctl", "--assess", "--type", "execute"]

    def test_assess_binary_trust_reports_revoked_macos_cert(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1")
        runtime.bin_dir = tmp_path / "bin"
        runtime.bin_dir.mkdir(parents=True)
        runtime.binary_path.write_text("#!/bin/sh\necho codex")
        runtime.binary_path.chmod(runtime.binary_path.stat().st_mode | stat.S_IXUSR)

        completed = MagicMock(returncode=1, stdout="", stderr="CSSMERR_TP_CERT_REVOKED")
        with (
            patch("pretorin.agent.codex_runtime.platform.system", return_value="Darwin"),
            patch("pretorin.agent.codex_runtime.subprocess.run", return_value=completed),
        ):
            assessment = runtime.assess_binary_trust()

        assert assessment.trusted is False
        assert assessment.status == "untrusted"
        assert "CSSMERR_TP_CERT_REVOKED" in assessment.detail

    def test_assess_binary_trust_accepts_valid_macos_cli_binary(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1")
        runtime.bin_dir = tmp_path / "bin"
        runtime.bin_dir.mkdir(parents=True)
        runtime.binary_path.write_text("#!/bin/sh\necho codex")
        runtime.binary_path.chmod(runtime.binary_path.stat().st_mode | stat.S_IXUSR)

        spctl = MagicMock(returncode=1, stdout="", stderr="rejected (the code is valid but does not seem to be an app)")
        codesign = MagicMock(returncode=0, stdout="", stderr="valid on disk")
        version = MagicMock(returncode=0, stdout="codex-cli 0.133.0", stderr="")
        with (
            patch("pretorin.agent.codex_runtime.platform.system", return_value="Darwin"),
            patch("pretorin.agent.codex_runtime.subprocess.run", side_effect=[spctl, codesign, version]),
        ):
            assessment = runtime.assess_binary_trust()

        assert assessment.trusted is True
        assert assessment.status == "valid_cli_binary"
        assert "valid on disk" in assessment.detail
        assert "codex-cli 0.133.0" in assessment.detail

    def test_assess_binary_trust_runs_version_smoke_on_linux(self, tmp_path: Path) -> None:
        runtime = CodexRuntime(version="test-v1")
        runtime.bin_dir = tmp_path / "bin"
        runtime.bin_dir.mkdir(parents=True)
        runtime.binary_path.write_text("#!/bin/sh\necho codex 1.2.3")
        runtime.binary_path.chmod(runtime.binary_path.stat().st_mode | stat.S_IXUSR)

        completed = MagicMock(returncode=0, stdout="codex 1.2.3", stderr="")
        with (
            patch("pretorin.agent.codex_runtime.platform.system", return_value="Linux"),
            patch("pretorin.agent.codex_runtime.subprocess.run", return_value=completed) as mock_run,
        ):
            assessment = runtime.assess_binary_trust()

        assert assessment.trusted is True
        assert assessment.status == "launchable"
        assert assessment.detail == "codex 1.2.3"
        assert mock_run.call_args[0][0] == [str(runtime.binary_path), "--version"]
