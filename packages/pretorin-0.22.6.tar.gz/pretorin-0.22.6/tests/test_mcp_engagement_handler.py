"""Integration tests for the start_task MCP handler.

The handler chains entity validation → cross-check → inspect → rule
selection → optional ambiguity override. These tests stub the platform
client and verify each branch.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from pretorin.client.api import PretorianClientError
from pretorin.client.models import ConnectedSource, ControlContext, ControlDetail
from pretorin.mcp.handlers.engagement import handle_start_task


def _success_payload(response):
    if isinstance(response, list):
        text = response[0].text
    else:
        text = response.content[0].text
    return json.loads(text)


def _error_text(response) -> str:
    if isinstance(response, list):
        return response[0].text
    return response.content[0].text


def _client_for_routing(*, systems=(), frameworks=()):
    client = MagicMock()
    client.list_systems = AsyncMock(return_value=list(systems))
    framework_objs = MagicMock()
    framework_objs.frameworks = list(frameworks)
    client.list_frameworks = AsyncMock(return_value=framework_objs)
    client.get_control = AsyncMock(return_value=MagicMock())
    client.get_system_compliance_status = AsyncMock(return_value={"frameworks": []})
    # Inspect calls — best-effort, return empty.
    client.get_workflow_state = AsyncMock(return_value={})
    client.get_pending_families = AsyncMock(return_value={})
    client.get_pending_scope_questions = AsyncMock(return_value={})
    client.list_org_policies = AsyncMock(return_value={"policies": []})
    return client


# =============================================================================
# Input validation
# =============================================================================


@pytest.mark.asyncio
async def test_missing_entities_argument_errors() -> None:
    client = _client_for_routing()
    response = await handle_start_task(client, {})
    assert "entities" in _error_text(response)


@pytest.mark.asyncio
async def test_invalid_intent_verb_errors() -> None:
    client = _client_for_routing()
    response = await handle_start_task(
        client,
        {"entities": {"intent_verb": "nonsense", "raw_prompt": "x"}},
    )
    assert "schema validation" in _error_text(response)


# =============================================================================
# Hard errors from cross-check
# =============================================================================


@pytest.mark.asyncio
async def test_hallucinated_system_id_returns_mcp_error() -> None:
    client = _client_for_routing(systems=[{"id": "sys-1", "name": "Primary"}])
    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "test",
                "system_id": "sys-zz",
            }
        },
    )
    assert "not found" in _error_text(response)


@pytest.mark.asyncio
async def test_upstream_validation_failure_is_structured_error() -> None:
    client = _client_for_routing()
    client.list_systems = AsyncMock(side_effect=PretorianClientError("Internal server error", status_code=500))
    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "test",
                "system_id": "sys-1",
            }
        },
    )
    payload = json.loads(_error_text(response))
    assert payload["error"] == "platform_validation_unavailable"
    assert "Could not validate system 'sys-1'" in payload["details"][0]


# =============================================================================
# Successful routing
# =============================================================================


@pytest.mark.asyncio
async def test_inspect_status_returns_no_workflow() -> None:
    client = _client_for_routing()
    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "inspect_status",
                "raw_prompt": "what's the status",
            },
            "skip_inspect": True,
        },
    )
    payload = _success_payload(response)
    assert payload["selected_workflow"] is None
    assert payload["ambiguous"] is False


@pytest.mark.asyncio
async def test_inspect_status_uses_active_context_without_cross_check() -> None:
    client = _client_for_routing()
    client.list_systems = AsyncMock(side_effect=AssertionError("inspect_status should not cross-check systems"))
    client.get_workflow_state = AsyncMock(return_value={"stage": "controls"})
    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "inspect_status",
                "raw_prompt": "what's the status",
            },
            "active_system_id": "sys-1",
            "active_framework_id": "fedramp-moderate",
        },
    )
    payload = _success_payload(response)
    assert payload["selected_workflow"] is None
    assert payload["inspect_summary"]["workflow_state"] == {"stage": "controls"}
    client.list_systems.assert_not_awaited()


@pytest.mark.asyncio
async def test_single_control_routes_to_single_control_workflow() -> None:
    f = MagicMock()
    f.id = "nist-800-53-r5"
    client = _client_for_routing(
        systems=[{"id": "sys-1", "name": "Primary"}],
        frameworks=[f],
    )
    client.get_system_compliance_status = AsyncMock(return_value={"frameworks": [{"framework_id": "nist-800-53-r5"}]})
    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "draft AC-2 for Primary",
                "system_id": "sys-1",
                "framework_id": "nist-800-53-r5",
                "control_ids": ["ac-2"],
            },
            "skip_inspect": True,
        },
    )
    payload = _success_payload(response)
    assert payload["selected_workflow"] == "single-control"
    assert payload["workflow_params"]["control_id"] == "ac-2"
    assert payload["ambiguous"] is False


@pytest.mark.asyncio
async def test_single_control_start_task_includes_capture_plan() -> None:
    f = MagicMock()
    f.id = "nist-800-53-r5"
    client = _client_for_routing(
        systems=[{"id": "sys-1", "name": "Primary"}],
        frameworks=[f],
    )
    client.get_system_compliance_status = AsyncMock(return_value={"frameworks": [{"framework_id": "nist-800-53-r5"}]})
    client.list_connected_sources = AsyncMock(return_value=[ConnectedSource(kind="workspace_repo", identifier="repo")])
    client.get_control_context = AsyncMock(
        return_value=ControlContext(
            control_id="ac-2",
            evidence_expectations=[{"description": "Capture workspace config file"}],
        )
    )

    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "draft AC-2 for Primary",
                "system_id": "sys-1",
                "framework_id": "nist-800-53-r5",
                "control_ids": ["ac-2"],
            },
            "skip_inspect": True,
        },
    )
    payload = _success_payload(response)
    assert payload["suggested_capture_plan"]["workflow_id"] == "single-control"
    assert payload["suggested_capture_plan"]["items"][0]["source_kind"] == "workspace_repo"


@pytest.mark.asyncio
async def test_capture_plan_falls_back_to_control_ai_guidance() -> None:
    f = MagicMock()
    f.id = "fedramp-moderate"
    client = _client_for_routing(
        systems=[{"id": "sys-1", "name": "Primary"}],
        frameworks=[f],
    )
    client.get_system_compliance_status = AsyncMock(return_value={"frameworks": [{"framework_id": "fedramp-moderate"}]})
    client.list_connected_sources = AsyncMock(return_value=[ConnectedSource(kind="workspace_repo", identifier="repo")])
    client.get_control_context = AsyncMock(side_effect=PretorianClientError("context unavailable"))
    client.get_control = AsyncMock(
        return_value=ControlDetail(
            id="au-04",
            title="Audit Log Storage Capacity",
            ai_guidance={
                "evidence_expectations": [
                    {"description": "Documented audit logging retention requirement and supporting workspace evidence"}
                ]
            },
        )
    )

    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "work on AU-04 for Primary",
                "system_id": "sys-1",
                "framework_id": "fedramp-moderate",
                "control_ids": ["au-04"],
            },
            "skip_inspect": True,
        },
    )
    payload = _success_payload(response)
    item = payload["suggested_capture_plan"]["items"][0]
    assert item["expectation_source"] == "control_ai_guidance"
    assert item["selected_recipe_id"] == "workspace-capture"
    assert item["recipe_source"] == "expectation_match"


@pytest.mark.asyncio
async def test_capture_plan_surfaces_workspace_recipe_when_source_unconnected() -> None:
    f = MagicMock()
    f.id = "fedramp-moderate"
    client = _client_for_routing(
        systems=[{"id": "sys-1", "name": "Primary"}],
        frameworks=[f],
    )
    client.get_system_compliance_status = AsyncMock(return_value={"frameworks": [{"framework_id": "fedramp-moderate"}]})
    client.list_connected_sources = AsyncMock(return_value=[])
    client.get_control_context = AsyncMock(return_value=ControlContext(control_id="au-04"))
    client.get_control = AsyncMock(
        return_value=ControlDetail(
            id="au-04",
            title="Audit Log Storage Capacity",
            ai_guidance={"evidence_expectations": [{"description": "Documented audit logging retention requirement"}]},
        )
    )

    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "work on AU-04 for Primary",
                "system_id": "sys-1",
                "framework_id": "fedramp-moderate",
                "control_ids": ["au-04"],
            },
            "skip_inspect": True,
        },
    )
    payload = _success_payload(response)
    item = payload["suggested_capture_plan"]["items"][0]
    assert item["status"] == "source_unavailable"
    assert item["recipes_available"][0] == "workspace-capture"
    assert item["recipe_gap"]["suggested_recipe_id"] == "workspace-capture"


@pytest.mark.asyncio
async def test_capture_plan_uses_workspace_capture_when_no_expectations() -> None:
    f = MagicMock()
    f.id = "fedramp-moderate"
    client = _client_for_routing(
        systems=[{"id": "sys-1", "name": "Primary"}],
        frameworks=[f],
    )
    client.get_system_compliance_status = AsyncMock(return_value={"frameworks": [{"framework_id": "fedramp-moderate"}]})
    client.list_connected_sources = AsyncMock(return_value=[ConnectedSource(kind="workspace_repo", identifier="repo")])
    client.get_control_context = AsyncMock(return_value=ControlContext(control_id="au-04"))
    client.get_control = AsyncMock(return_value=ControlDetail(id="au-04", title="Audit Log Storage Capacity"))

    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "work on AU-04 for Primary",
                "system_id": "sys-1",
                "framework_id": "fedramp-moderate",
                "control_ids": ["au-04"],
            },
            "skip_inspect": True,
        },
    )
    payload = _success_payload(response)
    item = payload["suggested_capture_plan"]["items"][0]
    assert item["status"] == "no_expectations"
    assert item["selected_recipe_id"] == "workspace-capture"
    assert item["recipe_source"] == "workspace_fallback"


# =============================================================================
# Ambiguity overrides
# =============================================================================


@pytest.mark.asyncio
async def test_cross_system_intent_returns_ambiguous() -> None:
    """Even if the rules would route, cross-system writes need confirmation."""
    f = MagicMock()
    f.id = "nist-800-53-r5"
    client = _client_for_routing(
        systems=[{"id": "sys-other", "name": "Other"}],
        frameworks=[f],
    )
    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "draft AC-2",
                "system_id": "sys-other",
                "framework_id": "nist-800-53-r5",
                "control_ids": ["ac-2"],
            },
            "active_system_id": "sys-active",
            "skip_inspect": True,
        },
    )
    payload = _success_payload(response)
    assert payload["ambiguous"] is True
    assert payload["selected_workflow"] is None
    assert "active CLI context" in (payload["ambiguity_reason"] or "")


# =============================================================================
# Inspect bundling
# =============================================================================


@pytest.mark.asyncio
async def test_inspect_summary_populated_when_not_skipped() -> None:
    f = MagicMock()
    f.id = "nist-800-53-r5"
    client = _client_for_routing(
        systems=[{"id": "sys-1", "name": "Primary"}],
        frameworks=[f],
    )
    client.get_system_compliance_status = AsyncMock(return_value={"frameworks": [{"framework_id": "nist-800-53-r5"}]})
    client.get_workflow_state = AsyncMock(return_value={"stage": "drafting"})
    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "AC-2",
                "system_id": "sys-1",
                "framework_id": "nist-800-53-r5",
                "control_ids": ["ac-2"],
            },
        },
    )
    payload = _success_payload(response)
    assert payload["inspect_summary"]["workflow_state"] == {"stage": "drafting"}


@pytest.mark.asyncio
async def test_inspect_resilient_to_platform_failures() -> None:
    """Inspect failures don't fail the whole call — they surface in errors."""
    f = MagicMock()
    f.id = "nist-800-53-r5"
    client = _client_for_routing(
        systems=[{"id": "sys-1", "name": "Primary"}],
        frameworks=[f],
    )
    client.get_system_compliance_status = AsyncMock(return_value={"frameworks": [{"framework_id": "nist-800-53-r5"}]})
    client.get_workflow_state = AsyncMock(side_effect=PretorianClientError("upstream timeout"))
    response = await handle_start_task(
        client,
        {
            "entities": {
                "intent_verb": "work_on",
                "raw_prompt": "x",
                "system_id": "sys-1",
                "framework_id": "nist-800-53-r5",
                "control_ids": ["ac-2"],
            },
        },
    )
    payload = _success_payload(response)
    assert payload["selected_workflow"] == "single-control"
    assert "error" in payload["inspect_summary"]["workflow_state"]
