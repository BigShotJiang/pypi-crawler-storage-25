"""Tests for agent CLI commands (Codex integration)."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

from pretorin.cli import agent as agent_cli

runner = CliRunner()


def _mock_runtime(
    version: str = "test-v1",
    binary_path: Path = Path("/tmp/test/bin/codex-test-v1"),
    is_installed: bool = True,
    codex_home: Path = Path("/tmp/test/codex"),
) -> MagicMock:
    """Create a mock CodexRuntime with common defaults."""
    mock = MagicMock()
    mock.version = version
    mock.binary_path = binary_path
    mock.is_installed = is_installed
    mock.codex_home = codex_home
    mock.assess_binary_trust.return_value = SimpleNamespace(trusted=True, status="trusted", detail="")
    return mock


class TestAgentVersion:
    """Tests for 'pretorin agent version' command."""

    def test_shows_version_and_status_installed(self) -> None:
        mock_runtime = _mock_runtime(version="test-v1.0.0", is_installed=True)
        mock_cls = MagicMock(return_value=mock_runtime)

        with patch("pretorin.agent.codex_runtime.CodexRuntime", mock_cls):
            result = runner.invoke(agent_cli.app, ["version"])
        assert result.exit_code == 0
        assert "test-v1.0.0" in result.stdout
        assert "installed" in result.stdout

    def test_shows_not_installed(self) -> None:
        mock_runtime = _mock_runtime(version="test-v1.0.0", is_installed=False)
        mock_cls = MagicMock(return_value=mock_runtime)

        with patch("pretorin.agent.codex_runtime.CodexRuntime", mock_cls):
            result = runner.invoke(agent_cli.app, ["version"])
        assert result.exit_code == 0
        assert "not installed" in result.stdout


class TestAgentDoctor:
    """Tests for 'pretorin agent doctor' command."""

    def test_doctor_reports_missing_binary(self) -> None:
        mock_runtime = _mock_runtime(is_installed=False)
        mock_cls = MagicMock(return_value=mock_runtime)

        with patch("pretorin.agent.codex_runtime.CodexRuntime", mock_cls):
            result = runner.invoke(agent_cli.app, ["doctor"])
        assert result.exit_code == 1

    def test_doctor_succeeds_with_installed_binary(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        codex_home = tmp_path / "codex"
        codex_home.mkdir()
        (codex_home / "config.toml").write_text("# config")

        mock_runtime = _mock_runtime(is_installed=True, codex_home=codex_home)
        mock_cls = MagicMock(return_value=mock_runtime)

        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

        with patch("pretorin.agent.codex_runtime.CodexRuntime", mock_cls):
            result = runner.invoke(agent_cli.app, ["doctor"])
        assert result.exit_code == 0
        assert "ready" in result.stdout.lower()


class TestAgentInstall:
    """Tests for 'pretorin agent install' command."""

    def test_install_succeeds(self, tmp_path: Path) -> None:
        mock_runtime = _mock_runtime()
        mock_runtime.ensure_installed.return_value = tmp_path / "bin" / "codex-test-v1"
        mock_cls = MagicMock(return_value=mock_runtime)

        with patch("pretorin.agent.codex_runtime.CodexRuntime", mock_cls):
            result = runner.invoke(agent_cli.app, ["install"])
        assert result.exit_code == 0
        assert "installed" in result.stdout.lower()

    def test_install_failure(self) -> None:
        mock_runtime = _mock_runtime()
        mock_runtime.ensure_installed.side_effect = RuntimeError("Download failed")
        mock_cls = MagicMock(return_value=mock_runtime)

        with patch("pretorin.agent.codex_runtime.CodexRuntime", mock_cls):
            result = runner.invoke(agent_cli.app, ["install"])
        assert result.exit_code == 1
        assert "failed" in result.stdout.lower()


class TestAgentRunCLI:
    """Tests for 'pretorin agent run' command argument parsing."""

    @staticmethod
    def _close_coroutine(coro: object) -> None:
        if hasattr(coro, "close"):
            coro.close()

    def test_run_requires_message(self) -> None:
        result = runner.invoke(agent_cli.app, ["run"])
        assert result.exit_code != 0

    def test_run_default_uses_codex(self) -> None:
        with (
            patch.object(agent_cli, "_check_codex_deps"),
            patch("pretorin.cli.agent.asyncio") as mock_asyncio,
        ):
            mock_asyncio.run.side_effect = self._close_coroutine
            runner.invoke(agent_cli.app, ["run", "test task"])
            mock_asyncio.run.assert_called_once()

    def test_run_legacy_flag_uses_agents_sdk(self) -> None:
        with (
            patch.object(agent_cli, "_check_agent_deps"),
            patch("pretorin.cli.agent.asyncio") as mock_asyncio,
        ):
            mock_asyncio.run.side_effect = self._close_coroutine
            runner.invoke(agent_cli.app, ["run", "test task", "--legacy"])
            mock_asyncio.run.assert_called_once()


class TestAgentRunRendering:
    """Tests for output rendering safety."""

    @pytest.mark.asyncio
    async def test_run_codex_agent_prints_todo_blocks_without_markup(self) -> None:
        result = MagicMock()
        result.response = "[[/PRETORIN_TODO]]"
        result.evidence_created = []

        mock_agent = MagicMock()
        mock_agent.model = "gpt-4o"
        mock_agent.run = AsyncMock(return_value=result)

        with (
            patch("pretorin.agent.codex_agent.CodexAgent", return_value=mock_agent),
            patch("pretorin.cli.agent.console.print") as mock_print,
        ):
            await agent_cli._run_codex_agent(
                message="test",
                skill=None,
                model=None,
                base_url=None,
                working_dir=None,
                stream=False,
            )

        mock_print.assert_called_with("[[/PRETORIN_TODO]]", markup=False)


class TestHarnessDeprecation:
    """Tests for harness deprecation warnings."""

    def test_harness_app_is_deprecated(self) -> None:
        from pretorin.cli import harness as harness_cli

        assert harness_cli.app.info.deprecated is True

    def test_harness_run_shows_deprecation_warning(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        from pretorin.cli import harness as harness_cli

        config_path = tmp_path / "config.toml"
        monkeypatch.setattr(harness_cli, "HARNESS_CONFIG_FILE", config_path)

        # Write a valid config so it gets past initial checks
        config_path.write_text(
            'model_provider = "pretorin"\n\n'
            "[model_providers.pretorin]\n"
            'base_url = "https://example.com/v1"\n'
            'env_key = "OPENAI_API_KEY"\n\n'
            "[mcp_servers.pretorin]\n"
            'command = "pretorin"\n'
            'args = ["mcp-serve"]\n'
        )
        monkeypatch.setattr(harness_cli.shutil, "which", lambda _: "/usr/bin/codex")

        result = runner.invoke(harness_cli.app, ["run", "test task", "--dry-run"])
        assert "deprecated" in result.stdout.lower()


class TestPrintAgentError:
    """Coverage for the diagnostic block in _print_agent_error (pretorin-cli#136 bug 2).

    The bare error string from the Codex SDK is often "Connection lost" with
    no further context. We want the operator to see the exception class, the
    chained cause if any, and the runtime context (model + base_url) so they
    can self-diagnose which connection failed.
    """

    def test_includes_exception_class_and_context(self, capsys: pytest.CaptureFixture[str]) -> None:
        exc = ConnectionError("Connection lost")
        agent_cli._print_agent_error(
            exc,
            context={"runtime": "codex", "model": "gpt-4o", "base_url": "http://localhost:8000/v1"},
        )
        captured = capsys.readouterr()
        # Exception class is prefixed to the message so "Connection lost" isn't ambiguous.
        assert "ConnectionError" in captured.out
        assert "Connection lost" in captured.out
        # Runtime context (model + base_url) helps the operator know which
        # connection was being attempted.
        assert "gpt-4o" in captured.out
        assert "localhost:8000" in captured.out
        assert "runtime=codex" in captured.out

    def test_includes_chained_cause_when_present(self, capsys: pytest.CaptureFixture[str]) -> None:
        try:
            try:
                raise OSError("upstream socket closed by peer")
            except OSError as inner:
                raise RuntimeError("Connection lost") from inner
        except RuntimeError as e:
            agent_cli._print_agent_error(e, context={"runtime": "codex", "model": "gpt-4o", "base_url": None})
        captured = capsys.readouterr()
        assert "RuntimeError: Connection lost" in captured.out
        assert "caused by OSError" in captured.out
        assert "upstream socket closed" in captured.out
        # base_url=None → shown as <unset> for clarity.
        assert "base_url=<unset>" in captured.out

    def test_mentions_debug_log_hint(self, capsys: pytest.CaptureFixture[str]) -> None:
        """The block ends with a pointer at PRETORIN_LOG_LEVEL=DEBUG."""
        agent_cli._print_agent_error(
            RuntimeError("boom"), context={"runtime": "legacy", "model": "gpt-4o", "base_url": None}
        )
        captured = capsys.readouterr()
        assert "PRETORIN_LOG_LEVEL=DEBUG" in captured.out
