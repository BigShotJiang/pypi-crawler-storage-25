"""Coverage tests for src/pretorin/mcp/handlers/artifacts.py.

Covers the 3 MCP tools:
- list_artifact_requirements
- get_asset_inventory
- submit_asset_inventory_diff (incl. recipe_context_id thread-through + expired ctx)
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from mcp.types import CallToolResult

from pretorin.mcp.handlers.artifacts import (
    handle_get_asset_inventory,
    handle_list_artifact_requirements,
    handle_submit_asset_inventory_diff,
)


def _make_client(**overrides: object) -> AsyncMock:
    client = AsyncMock()
    client.is_configured = True
    client.list_systems = AsyncMock(return_value=[{"id": "sys-1", "name": "Test System"}])
    for attr, val in overrides.items():
        setattr(client, attr, AsyncMock(return_value=val))
    return client


def _is_error(result: object) -> bool:
    return isinstance(result, CallToolResult) and result.isError is True


# -----------------------------------------------------------------------------
# list_artifact_requirements
# -----------------------------------------------------------------------------


@pytest.mark.anyio
async def test_list_artifact_requirements_success() -> None:
    client = _make_client(list_spec_kinds={"kinds": [{"kind": "asset_inventory"}]})
    result = await handle_list_artifact_requirements(client, {"system_id": "sys-1"})
    client.list_spec_kinds.assert_awaited_once_with("sys-1")
    assert not _is_error(result)
    assert "asset_inventory" in result[0].text


@pytest.mark.anyio
async def test_list_artifact_requirements_missing_system() -> None:
    client = _make_client()
    result = await handle_list_artifact_requirements(client, {})
    assert _is_error(result)


# -----------------------------------------------------------------------------
# get_asset_inventory
# -----------------------------------------------------------------------------


@pytest.mark.anyio
async def test_get_asset_inventory_default() -> None:
    client = _make_client(get_asset_inventory={"items": []})
    result = await handle_get_asset_inventory(client, {"system_id": "sys-1"})
    client.get_asset_inventory.assert_awaited_once_with("sys-1", as_of=None)
    assert not _is_error(result)


@pytest.mark.anyio
async def test_get_asset_inventory_with_as_of() -> None:
    client = _make_client(get_asset_inventory={"items": []})
    await handle_get_asset_inventory(client, {"system_id": "sys-1", "as_of": "2026-05-01T00:00:00Z"})
    client.get_asset_inventory.assert_awaited_once_with("sys-1", as_of="2026-05-01T00:00:00Z")


@pytest.mark.anyio
async def test_get_asset_inventory_propagates_client_error() -> None:
    from pretorin.client.api import NotFoundError

    client = _make_client()
    client.get_asset_inventory = AsyncMock(side_effect=NotFoundError("system not found", 404))
    result = await handle_get_asset_inventory(client, {"system_id": "sys-1"})
    assert _is_error(result)
    assert "system not found" in result.content[0].text.lower()


# -----------------------------------------------------------------------------
# submit_asset_inventory_diff
# -----------------------------------------------------------------------------


@pytest.mark.anyio
async def test_submit_diff_minimal_happy_path() -> None:
    client = _make_client(
        submit_inventory_diff={
            "idempotency_key": "abc",
            "summary": {"created": 1, "modified": 0, "decommissioned": 0, "unchanged": 0, "not_found": 0, "errors": 0},
            "items": [],
        }
    )
    result = await handle_submit_asset_inventory_diff(
        client,
        {
            "system_id": "sys-1",
            "recipe_id": "asset-inventory-aws-baseline",
            "added": [{"external_id": "i-1", "name": "web", "asset_type": "server"}],
        },
    )
    assert not _is_error(result), result.content[0].text if hasattr(result, "content") else result
    client.submit_inventory_diff.assert_awaited_once()
    call = client.submit_inventory_diff.await_args
    assert call.kwargs["recipe_id"] == "asset-inventory-aws-baseline"
    # idempotency_key was auto-derived since the caller didn't supply one
    assert call.kwargs["idempotency_key"]
    assert call.kwargs["recipe_context_id"] is None


@pytest.mark.anyio
async def test_submit_diff_requires_at_least_one_op() -> None:
    client = _make_client()
    result = await handle_submit_asset_inventory_diff(
        client,
        {"system_id": "sys-1", "recipe_id": "asset-inventory-aws-baseline"},
    )
    assert _is_error(result)
    assert "at least one" in result.content[0].text.lower()


@pytest.mark.anyio
async def test_submit_diff_rejects_non_array_added() -> None:
    client = _make_client()
    result = await handle_submit_asset_inventory_diff(
        client,
        {
            "system_id": "sys-1",
            "recipe_id": "asset-inventory-aws-baseline",
            "added": "not-a-list",
        },
    )
    assert _is_error(result)


@pytest.mark.anyio
async def test_submit_diff_missing_recipe_id() -> None:
    client = _make_client()
    result = await handle_submit_asset_inventory_diff(
        client,
        {"system_id": "sys-1", "added": [{"external_id": "i-1"}]},
    )
    assert _is_error(result)


@pytest.mark.anyio
async def test_submit_diff_uses_caller_supplied_idempotency_key() -> None:
    client = _make_client(submit_inventory_diff={"items": [], "summary": {}})
    await handle_submit_asset_inventory_diff(
        client,
        {
            "system_id": "sys-1",
            "recipe_id": "cli-upload-csv",
            "idempotency_key": "deadbeefcafe",
            "added": [{"external_id": "i-1"}],
        },
    )
    assert client.submit_inventory_diff.await_args.kwargs["idempotency_key"] == "deadbeefcafe"


@pytest.mark.anyio
async def test_submit_diff_threads_recipe_context_id_when_valid() -> None:
    """If the caller supplies a valid recipe_context_id, it's threaded through."""
    from pretorin.recipes.context import get_default_store

    store = get_default_store()
    ctx = store.start_recipe(
        recipe_id="asset-inventory-aws-baseline",
        recipe_version="0.1.0",
        params={},
        system_id="sys-1",
    )
    try:
        client = _make_client(submit_inventory_diff={"items": [], "summary": {}})
        await handle_submit_asset_inventory_diff(
            client,
            {
                "system_id": "sys-1",
                "recipe_id": "asset-inventory-aws-baseline",
                "recipe_context_id": ctx.context_id,
                "added": [{"external_id": "i-1"}],
            },
        )
        assert client.submit_inventory_diff.await_args.kwargs["recipe_context_id"] == ctx.context_id
    finally:
        store.end_recipe(ctx.context_id, status="pass")


@pytest.mark.anyio
async def test_submit_diff_rejects_unknown_recipe_context_id() -> None:
    client = _make_client()
    result = await handle_submit_asset_inventory_diff(
        client,
        {
            "system_id": "sys-1",
            "recipe_id": "asset-inventory-aws-baseline",
            "recipe_context_id": "ctx-does-not-exist",
            "added": [{"external_id": "i-1"}],
        },
    )
    assert _is_error(result)
