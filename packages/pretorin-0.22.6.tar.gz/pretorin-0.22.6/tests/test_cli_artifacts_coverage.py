"""Coverage tests for src/pretorin/cli/artifacts.py.

Covers the 5 commands under `pretorin scope artifacts ...`:
- list
- inventory show (active + as_of)
- inventory upload csv (happy + decommission not_found surfacing)
- inventory scan source (dry-run + apply + recipe_context_id thread-through)
- toggle (rationale-required-on-toggle-off)
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

from pretorin.cli.main import app
from pretorin.cli.output import set_json_mode

runner = CliRunner()


@pytest.fixture(autouse=True)
def _reset_json_mode():
    set_json_mode(False)
    yield
    set_json_mode(False)


def _client_ctx(client: AsyncMock) -> MagicMock:
    """Wrap the AsyncMock client into an async-context-manager-compatible MagicMock."""
    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=client)
    ctx.__aexit__ = AsyncMock(return_value=None)
    return ctx


def _base_client() -> AsyncMock:
    client = AsyncMock()
    client.is_configured = True
    return client


def _patches(client: AsyncMock, *, framework_id: str = "fedramp-moderate"):
    return (
        patch("pretorin.cli.artifacts.PretorianClient", return_value=_client_ctx(client)),
        patch(
            "pretorin.cli.artifacts.resolve_execution_context",
            new_callable=AsyncMock,
            return_value=("sys-1", framework_id),
        ),
    )


# =============================================================================
# artifacts list
# =============================================================================


def test_artifacts_list_normal() -> None:
    client = _base_client()
    client.list_spec_kinds = AsyncMock(
        return_value={
            "kinds": [
                {"kind": "asset_inventory", "effective_required": True, "optional": False},
                {
                    "kind": "threat_model",
                    "effective_required": False,
                    "optional": True,
                    "rationale": "single-tenant scope",
                },
            ]
        }
    )
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(app, ["scope", "artifacts", "list", "--system", "Primary"])
    assert result.exit_code == 0, result.output
    assert "asset_inventory" in result.output
    assert "threat_model" in result.output
    client.list_spec_kinds.assert_awaited_once_with("sys-1")


def test_artifacts_list_json_mode() -> None:
    client = _base_client()
    client.list_spec_kinds = AsyncMock(return_value={"kinds": [{"kind": "asset_inventory"}]})
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(app, ["--json", "scope", "artifacts", "list", "--system", "Primary"])
    assert result.exit_code == 0, result.output
    assert json.loads(result.stdout) == {"kinds": [{"kind": "asset_inventory"}]}


def test_artifacts_list_propagates_403() -> None:
    from pretorin.client.api import AuthenticationError

    client = _base_client()
    client.list_spec_kinds = AsyncMock(side_effect=AuthenticationError("Access denied: missing scope", 403))
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(app, ["scope", "artifacts", "list", "--system", "Primary"])
    assert result.exit_code == 1
    assert "Access denied" in result.output


# =============================================================================
# inventory show
# =============================================================================


def test_inventory_show_normal_with_assets() -> None:
    client = _base_client()
    client.get_asset_inventory = AsyncMock(
        return_value={
            "items": [
                {
                    "external_id": "i-0123",
                    "name": "web-1",
                    "asset_type": "server",
                    "environment": "prod",
                    "criticality": "moderate",
                    "data_classification": "internal",
                }
            ]
        }
    )
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(app, ["scope", "artifacts", "inventory", "show", "--system", "Primary"])
    assert result.exit_code == 0
    assert "web-1" in result.output
    client.get_asset_inventory.assert_awaited_once_with("sys-1", as_of=None)


def test_inventory_show_with_as_of_flag() -> None:
    client = _base_client()
    client.get_asset_inventory = AsyncMock(return_value={"items": []})
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(
            app,
            ["scope", "artifacts", "inventory", "show", "--system", "Primary", "--as-of", "2026-05-01T00:00:00Z"],
        )
    assert result.exit_code == 0
    client.get_asset_inventory.assert_awaited_once_with("sys-1", as_of="2026-05-01T00:00:00Z")


# =============================================================================
# inventory upload
# =============================================================================


def _write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        path.write_text("external_id,name,asset_type\n", encoding="utf-8")
        return
    header = ",".join(rows[0].keys())
    body = "\n".join(",".join(r.get(k, "") for k in rows[0].keys()) for r in rows)
    path.write_text(f"{header}\n{body}\n", encoding="utf-8")


def test_inventory_upload_happy_path_with_decommission_warning(tmp_path: Path) -> None:
    csv_path = tmp_path / "assets.csv"
    _write_csv(
        csv_path,
        [
            {"external_id": "i-new", "name": "new-row", "asset_type": "server"},
        ],
    )
    client = _base_client()
    # Existing inventory has one row that is NOT in the CSV → decommissioned.
    client.get_asset_inventory = AsyncMock(
        return_value={
            "items": [
                {"external_id": "i-old", "name": "old-row", "asset_type": "server"},
            ]
        }
    )
    # Diff response includes a not_found outcome (caller hit a decommissioned row).
    client.submit_inventory_diff = AsyncMock(
        return_value={
            "idempotency_key": "abc",
            "summary": {"created": 1, "modified": 0, "decommissioned": 1, "unchanged": 0, "not_found": 0, "errors": 0},
            "items": [],
        }
    )
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(
            app,
            ["scope", "artifacts", "inventory", "upload", str(csv_path), "--system", "Primary", "--yes"],
        )
    assert result.exit_code == 0, result.output
    client.submit_inventory_diff.assert_awaited_once()
    call_kwargs = client.submit_inventory_diff.await_args.kwargs
    assert any(row.get("external_id") == "i-new" for row in call_kwargs["added"])
    assert any(row.get("external_id") == "i-old" for row in call_kwargs["decommissioned"])


def test_inventory_upload_surfaces_not_found_rows(tmp_path: Path) -> None:
    csv_path = tmp_path / "assets.csv"
    _write_csv(csv_path, [{"external_id": "i-decom", "name": "ghost", "asset_type": "server"}])
    client = _base_client()
    client.get_asset_inventory = AsyncMock(return_value={"items": []})
    client.submit_inventory_diff = AsyncMock(
        return_value={
            "idempotency_key": "abc",
            "summary": {"created": 0, "modified": 0, "decommissioned": 0, "unchanged": 0, "not_found": 1, "errors": 0},
            "items": [
                {
                    "external_id": "i-decom",
                    "outcome": "not_found",
                    "error": "external_id matches a decommissioned asset; re-activate via UI rather than re-scan.",
                }
            ],
        }
    )
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(
            app,
            ["scope", "artifacts", "inventory", "upload", str(csv_path), "--system", "Primary", "--yes"],
        )
    assert result.exit_code == 0, result.output
    assert "not_found" in result.output
    assert "re-activate" in result.output


def test_inventory_upload_aborts_when_csv_matches(tmp_path: Path) -> None:
    csv_path = tmp_path / "assets.csv"
    _write_csv(
        csv_path,
        [{"external_id": "i-1", "name": "web", "asset_type": "server"}],
    )
    client = _base_client()
    client.get_asset_inventory = AsyncMock(
        return_value={"items": [{"external_id": "i-1", "name": "web", "asset_type": "server"}]}
    )
    client.submit_inventory_diff = AsyncMock()
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(
            app,
            ["scope", "artifacts", "inventory", "upload", str(csv_path), "--system", "Primary", "--yes"],
        )
    assert result.exit_code == 0
    client.submit_inventory_diff.assert_not_awaited()


def test_inventory_upload_rejects_csv_missing_external_id(tmp_path: Path) -> None:
    csv_path = tmp_path / "assets.csv"
    csv_path.write_text("name,asset_type\nweb-1,server\n", encoding="utf-8")
    client = _base_client()
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(
            app,
            ["scope", "artifacts", "inventory", "upload", str(csv_path), "--system", "Primary", "--yes"],
        )
    assert result.exit_code != 0


# =============================================================================
# inventory scan
# =============================================================================


def test_inventory_scan_unknown_source_errors() -> None:
    client = _base_client()
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(app, ["scope", "artifacts", "inventory", "scan", "snowflake", "--system", "Primary"])
    assert result.exit_code == 1
    assert "Unknown source" in result.output


def test_inventory_scan_dry_run_does_not_post(tmp_path: Path) -> None:
    client = _base_client()
    client.get_asset_inventory = AsyncMock(return_value={"items": []})
    client.submit_inventory_diff = AsyncMock()

    async def _fake_recipe_run(*args, **kwargs):
        return (
            {
                "added": [
                    {
                        "external_id": "i-new",
                        "name": "iac-row",
                        "asset_type": "server",
                        "environment": "prod",
                        "criticality": "moderate",
                        "data_classification": "internal",
                    }
                ],
                "modified": [],
                "decommissioned": [],
            },
            "ctx-1",
        )

    p1, p2 = _patches(client)
    with p1, p2, patch("pretorin.cli.artifacts._run_inventory_recipe", new=AsyncMock(side_effect=_fake_recipe_run)):
        result = runner.invoke(
            app,
            ["scope", "artifacts", "inventory", "scan", "iac-workspace", "--system", "Primary", "--dry-run"],
        )
    assert result.exit_code == 0, result.output
    assert "Dry run" in result.output
    client.submit_inventory_diff.assert_not_awaited()


def test_inventory_scan_apply_threads_recipe_context_id() -> None:
    client = _base_client()
    client.get_asset_inventory = AsyncMock(return_value={"items": []})
    client.submit_inventory_diff = AsyncMock(
        return_value={
            "idempotency_key": "abc",
            "summary": {"created": 1, "modified": 0, "decommissioned": 0, "unchanged": 0, "not_found": 0, "errors": 0},
            "items": [],
        }
    )

    async def _fake_recipe_run(*args, **kwargs):
        return (
            {
                "added": [
                    {
                        "external_id": "i-new",
                        "name": "iac-row",
                        "asset_type": "server",
                        "environment": "prod",
                        "criticality": "moderate",
                        "data_classification": "internal",
                    }
                ],
                "modified": [],
                "decommissioned": [],
            },
            "ctx-XYZ",
        )

    p1, p2 = _patches(client)
    with p1, p2, patch("pretorin.cli.artifacts._run_inventory_recipe", new=AsyncMock(side_effect=_fake_recipe_run)):
        result = runner.invoke(
            app,
            ["scope", "artifacts", "inventory", "scan", "iac-workspace", "--system", "Primary", "--yes"],
        )
    assert result.exit_code == 0, result.output
    client.submit_inventory_diff.assert_awaited_once()
    assert client.submit_inventory_diff.await_args.kwargs["recipe_context_id"] == "ctx-XYZ"
    assert client.submit_inventory_diff.await_args.kwargs["recipe_id"] == "asset-inventory-iac-workspace"


# =============================================================================
# toggle
# =============================================================================


def test_toggle_requires_rationale_when_setting_optional() -> None:
    client = _base_client()
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(
            app,
            ["scope", "artifacts", "toggle", "threat_model", "--system", "Primary", "--optional"],
        )
    assert result.exit_code == 1
    assert "rationale is required" in result.output


def test_toggle_optional_with_rationale_posts() -> None:
    client = _base_client()
    client.toggle_spec_kind = AsyncMock(return_value={"kind": "threat_model", "optional": True})
    p1, p2 = _patches(client)
    with p1, p2:
        result = runner.invoke(
            app,
            [
                "scope",
                "artifacts",
                "toggle",
                "threat_model",
                "--system",
                "Primary",
                "--optional",
                "--rationale",
                "single-tenant scope",
            ],
        )
    assert result.exit_code == 0
    client.toggle_spec_kind.assert_awaited_once_with(
        "sys-1", "threat_model", optional=True, rationale="single-tenant scope"
    )
