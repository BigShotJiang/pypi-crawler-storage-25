"""Tests for evidence audit-trail metadata models + helpers.

Covers the evidence artifact/provenance contract:
- ``EvidenceAuditMetadata`` model validation (required + optional fields,
  source-material hash format).
- ``RedactionSummary`` model defaults and constraints.
- ``build_cli_metadata`` / ``build_agent_metadata`` / ``build_recipe_metadata``
  helpers in ``pretorin.evidence.audit_metadata``.
- Required ``artifact_content`` and ``audit_metadata`` fields on
  ``EvidenceCreate`` and ``EvidenceBatchItemCreate``.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from pretorin import __version__ as pretorin_version
from pretorin.client.models import (
    EvidenceAuditMetadata,
    EvidenceBatchItemCreate,
    EvidenceCreate,
    RedactionSummary,
)
from pretorin.evidence.audit_metadata import (
    build_agent_metadata,
    build_cli_metadata,
    build_recipe_metadata,
    compute_content_hash,
    evidence_type_to_source_type,
)
from pretorin.evidence.types import VALID_EVIDENCE_TYPES

# A valid sha256 hex digest used as a constant in tests that need a content_hash
# but aren't testing the hash itself.
_VALID_HASH = "a" * 64
_NOW = datetime(2026, 4, 29, 12, 0, 0, tzinfo=timezone.utc)


# =============================================================================
# RedactionSummary
# =============================================================================


def test_redaction_summary_defaults() -> None:
    summary = RedactionSummary()
    assert summary.secrets == 0
    assert summary.pii == 0
    assert summary.custom == 0
    assert summary.details is None


def test_redaction_summary_accepts_explicit_counts() -> None:
    summary = RedactionSummary(secrets=2, pii=1, custom=0)
    assert summary.secrets == 2
    assert summary.pii == 1


def test_redaction_summary_accepts_details_dict() -> None:
    summary = RedactionSummary(secrets=3, details={"aws_keys": 2, "github_pats": 1})
    assert summary.details == {"aws_keys": 2, "github_pats": 1}


def test_redaction_summary_rejects_negative_counts() -> None:
    with pytest.raises(ValidationError):
        RedactionSummary(secrets=-1)


# =============================================================================
# EvidenceAuditMetadata — required minimum
# =============================================================================


def _valid_metadata_kwargs(**overrides: object) -> dict[str, object]:
    """Reusable dict of valid kwargs; overrides let tests focus on one field."""
    base: dict[str, object] = {
        "producer_kind": "cli",
        "producer_id": "cli",
        "captured_at": _NOW,
        "source_type": "code_snippet",
        "source_label": "Source file",
        "source_uri": "file:///path/to/source.py",
        "source_locator": "lines 1-2",
        "source_lines": [1, 2],
        "source_excerpt": "source excerpt",
        "content_hash": _VALID_HASH,
        "capture_method": "repository_file_read",
    }
    base.update(overrides)
    return base


def test_metadata_required_minimum_constructs() -> None:
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs())  # type: ignore[arg-type]
    assert meta.producer_kind == "cli"
    assert meta.producer_id == "cli"
    assert meta.captured_at == _NOW
    assert meta.source_type == "code_snippet"
    assert meta.source_label == "Source file"
    assert meta.source_uri == "file:///path/to/source.py"
    assert meta.source_locator == "lines 1-2"
    assert meta.source_lines == [1, 2]
    assert meta.source_excerpt == "source excerpt"
    assert meta.content_hash == _VALID_HASH
    assert meta.capture_method == "repository_file_read"
    assert meta.producer_version is None
    assert meta.source_version is None
    assert meta.redaction_summary is None
    assert meta.recipe_selection is None


@pytest.mark.parametrize(
    "missing_field",
    [
        "producer_kind",
        "producer_id",
        "captured_at",
        "source_type",
        "source_uri",
        "source_excerpt",
        "content_hash",
        "capture_method",
    ],
)
def test_metadata_rejects_missing_required_field(missing_field: str) -> None:
    kwargs = _valid_metadata_kwargs()
    del kwargs[missing_field]
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**kwargs)  # type: ignore[arg-type]


# =============================================================================
# EvidenceAuditMetadata — enum and constraint validation
# =============================================================================


@pytest.mark.parametrize(
    "value",
    ["cli", "recipe", "agent", "manual_upload", "api"],
)
def test_metadata_accepts_all_producer_kinds(value: str) -> None:
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(producer_kind=value))  # type: ignore[arg-type]
    assert meta.producer_kind == value


def test_metadata_accepts_custom_producer_kind() -> None:
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(producer_kind="custom-agent"))  # type: ignore[arg-type]
    assert meta.producer_kind == "custom-agent"


@pytest.mark.parametrize(
    "value",
    [
        "code_snippet",
        "log_excerpt",
        "configuration",
        "screenshot",
        "document",
        "attestation",
        "scan_result",
    ],
)
def test_metadata_accepts_all_source_types(value: str) -> None:
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(source_type=value))  # type: ignore[arg-type]
    assert meta.source_type == value


def test_metadata_accepts_custom_source_type() -> None:
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(source_type="policy_template"))  # type: ignore[arg-type]
    assert meta.source_type == "policy_template"


def test_metadata_rejects_empty_producer_id() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(producer_id=""))  # type: ignore[arg-type]


def test_metadata_rejects_empty_producer_kind() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(producer_kind=""))  # type: ignore[arg-type]


def test_metadata_rejects_empty_source_type() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(source_type=""))  # type: ignore[arg-type]


def test_metadata_rejects_empty_source_uri() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(source_uri=""))  # type: ignore[arg-type]


def test_metadata_rejects_empty_source_excerpt() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(source_excerpt=""))  # type: ignore[arg-type]


def test_metadata_rejects_empty_capture_method() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(capture_method=""))  # type: ignore[arg-type]


def test_metadata_rejects_invalid_source_lines() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(source_lines=[1, 0]))  # type: ignore[arg-type]


# =============================================================================
# EvidenceAuditMetadata — content_hash validation
# =============================================================================


def test_metadata_rejects_short_content_hash() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(content_hash="a" * 63))  # type: ignore[arg-type]


def test_metadata_rejects_long_content_hash() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(content_hash="a" * 65))  # type: ignore[arg-type]


def test_metadata_rejects_uppercase_content_hash() -> None:
    """Convention is lowercase hex; uppercase indicates a different stamping path."""
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(content_hash="A" * 64))  # type: ignore[arg-type]


def test_metadata_rejects_non_hex_content_hash() -> None:
    with pytest.raises(ValidationError):
        EvidenceAuditMetadata(**_valid_metadata_kwargs(content_hash="g" * 64))  # type: ignore[arg-type]


def test_metadata_accepts_real_sha256_digest() -> None:
    real_digest = hashlib.sha256(b"hello").hexdigest()
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(content_hash=real_digest))  # type: ignore[arg-type]
    assert meta.content_hash == real_digest


# =============================================================================
# EvidenceAuditMetadata — optional fields
# =============================================================================


def test_metadata_accepts_optional_producer_version() -> None:
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(producer_version="0.16.3"))  # type: ignore[arg-type]
    assert meta.producer_version == "0.16.3"


def test_metadata_accepts_optional_source_version() -> None:
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(source_version="abc1234"))  # type: ignore[arg-type]
    assert meta.source_version == "abc1234"


def test_metadata_accepts_optional_source_context_fields() -> None:
    meta = EvidenceAuditMetadata(
        **_valid_metadata_kwargs(
            source_label="Asset Management Policy",
            source_locator="section 3.7",
            source_lines=None,
        )
    )  # type: ignore[arg-type]
    assert meta.source_label == "Asset Management Policy"
    assert meta.source_locator == "section 3.7"
    assert meta.source_lines is None


def test_metadata_accepts_optional_redaction_summary() -> None:
    summary = RedactionSummary(secrets=2)
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(redaction_summary=summary))  # type: ignore[arg-type]
    assert meta.redaction_summary is not None
    assert meta.redaction_summary.secrets == 2


def test_metadata_accepts_optional_recipe_selection_dict() -> None:
    selection = {"selected_recipe": "code-evidence-capture", "confidence": "high"}
    meta = EvidenceAuditMetadata(**_valid_metadata_kwargs(recipe_selection=selection))  # type: ignore[arg-type]
    assert meta.recipe_selection == selection


# =============================================================================
# evidence_type_to_source_type mapping
# =============================================================================


@pytest.mark.parametrize(
    "evidence_type,expected",
    [
        ("attestation", "attestation"),
        ("certificate", "document"),
        ("code_snippet", "code_snippet"),
        ("configuration", "configuration"),
        ("interview_notes", "attestation"),
        ("log_file", "log_excerpt"),
        ("other", "document"),
        ("policy_document", "document"),
        ("repository_link", "code_snippet"),
        ("scan_result", "scan_result"),
        ("screen_recording", "screenshot"),
        ("screenshot", "screenshot"),
        ("system_spec_boundary_diagram", "document"),
        ("system_spec_interconnection", "document"),
        ("system_spec_inventory_attestation", "attestation"),
        ("system_spec_network_dfd", "document"),
        ("system_spec_ppsm", "configuration"),
        ("test_result", "scan_result"),
    ],
)
def test_evidence_type_to_source_type_canonical(evidence_type: str, expected: str) -> None:
    assert evidence_type_to_source_type(evidence_type) == expected


def test_evidence_type_to_source_type_covers_all_canonical_evidence_types() -> None:
    """Every value in VALID_EVIDENCE_TYPES has a canonical source_type mapping.

    Without this regression test, adding a new evidence_type to the platform enum
    would silently fall through to the 'document' default. This test forces a
    deliberate choice when the enum grows.
    """
    for ev_type in VALID_EVIDENCE_TYPES:
        # Mapping must return a SourceType from the enum; default-to-document is
        # only acceptable for evidence_type values genuinely best classified that
        # way (other, certificate, policy_document). Everything else needs an
        # explicit entry; assert each maps.
        result = evidence_type_to_source_type(ev_type)
        assert result in {
            "code_snippet",
            "log_excerpt",
            "configuration",
            "screenshot",
            "document",
            "attestation",
            "scan_result",
        }


def test_evidence_type_to_source_type_unknown_defaults_to_document() -> None:
    """Defensive default when an unknown evidence_type slips past the validator."""
    assert evidence_type_to_source_type("not-a-real-type") == "document"


# =============================================================================
# compute_content_hash
# =============================================================================


def test_compute_hash_str_matches_sha256() -> None:
    assert compute_content_hash("hello") == hashlib.sha256(b"hello").hexdigest()


def test_compute_hash_bytes_matches_sha256() -> None:
    assert compute_content_hash(b"hello") == hashlib.sha256(b"hello").hexdigest()


def test_compute_hash_str_and_bytes_agree() -> None:
    """UTF-8 encoding makes str and bytes inputs produce identical hashes."""
    assert compute_content_hash("hello") == compute_content_hash(b"hello")


def test_compute_hash_deterministic() -> None:
    """Same input → same hash. Twice."""
    assert compute_content_hash("payload") == compute_content_hash("payload")


def test_compute_hash_empty() -> None:
    """sha256 of empty string is a known constant."""
    expected = hashlib.sha256(b"").hexdigest()
    assert compute_content_hash("") == expected
    assert compute_content_hash(b"") == expected


def test_compute_hash_unicode() -> None:
    """Non-ASCII strings hash via their UTF-8 encoding."""
    body = "héllo wörld"
    assert compute_content_hash(body) == hashlib.sha256(body.encode("utf-8")).hexdigest()


# =============================================================================
# build_cli_metadata
# =============================================================================


def test_build_cli_basic() -> None:
    meta = build_cli_metadata(
        body="payload",
        source_uri="file:///x.py",
        source_type="code_snippet",
    )
    assert meta.producer_kind == "cli"
    assert meta.producer_id == "cli"
    assert meta.producer_version == pretorin_version
    assert meta.source_type == "code_snippet"
    assert meta.source_uri == "file:///x.py"
    assert meta.source_label == "file:///x.py"
    assert meta.source_excerpt == "payload"
    assert meta.content_hash == compute_content_hash("payload")
    assert meta.capture_method == "cli_manual_entry"
    assert meta.redaction_summary is None
    assert meta.recipe_selection is None


def test_build_cli_captured_at_defaults_to_now_utc() -> None:
    meta = build_cli_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
    )
    # Auto-stamped captured_at should be timezone-aware UTC.
    assert meta.captured_at.tzinfo is timezone.utc


def test_build_cli_captured_at_override_respected() -> None:
    custom = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    meta = build_cli_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
        captured_at=custom,
    )
    assert meta.captured_at == custom


def test_build_cli_passes_through_optional_fields() -> None:
    summary = RedactionSummary(secrets=1)
    meta = build_cli_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
        source_label="x.py",
        source_locator="lines 7-8",
        source_lines=[7, 8],
        source_version="abc1234",
        source_excerpt="source excerpt",
        capture_method="repository_file_read",
        redaction_summary=summary,
    )
    assert meta.source_label == "x.py"
    assert meta.source_locator == "lines 7-8"
    assert meta.source_lines == [7, 8]
    assert meta.source_version == "abc1234"
    assert meta.source_excerpt == "source excerpt"
    assert meta.capture_method == "repository_file_read"
    assert meta.content_hash == compute_content_hash("source excerpt")
    assert meta.redaction_summary is summary


def test_build_cli_accepts_bytes_body() -> None:
    meta = build_cli_metadata(
        body=b"\x00\x01raw",
        source_uri="file:///x.bin",
        source_type="document",
    )
    assert meta.content_hash == compute_content_hash(b"\x00\x01raw")
    assert meta.source_excerpt == "\x00\x01raw"


# =============================================================================
# build_agent_metadata
# =============================================================================


def test_build_agent_basic() -> None:
    meta = build_agent_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
        agent_id="codex-agent",
    )
    assert meta.producer_kind == "agent"
    assert meta.producer_id == "codex-agent"
    assert meta.producer_version is None  # not provided


def test_build_agent_version_passed_through() -> None:
    meta = build_agent_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
        agent_id="claude-code",
        agent_version="claude-opus-4-7",
    )
    assert meta.producer_version == "claude-opus-4-7"


# =============================================================================
# build_recipe_metadata
# =============================================================================


def test_build_recipe_basic() -> None:
    meta = build_recipe_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
        recipe_id="code-evidence-capture",
        recipe_version="0.1.0",
    )
    assert meta.producer_kind == "recipe"
    assert meta.producer_id == "code-evidence-capture"
    assert meta.producer_version == "0.1.0"
    assert meta.recipe_selection is None  # set by workflow layer (WS5), not here


def test_build_recipe_for_scanner_recipe() -> None:
    """Scanner recipes use source_type='scan_result'."""
    meta = build_recipe_metadata(
        body="scan output...",
        source_uri="inspec://disa-stig-rhel-9",
        source_type="scan_result",
        recipe_id="inspec-baseline",
        recipe_version="0.1.0",
    )
    assert meta.source_type == "scan_result"
    assert meta.producer_id == "inspec-baseline"


# =============================================================================
# EvidenceCreate / EvidenceBatchItemCreate integration
# =============================================================================


def test_evidence_create_rejects_missing_artifact_content_and_audit_metadata() -> None:
    with pytest.raises(ValidationError):
        EvidenceCreate(
            name="x",
            description="y",
            evidence_type="code_snippet",
        )


def test_evidence_create_accepts_audit_metadata_instance() -> None:
    meta = build_cli_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
    )
    ev = EvidenceCreate(
        name="x",
        description="y",
        artifact_content="## Evidence\n\n```text\nx\n```",
        evidence_type="code_snippet",
        audit_metadata=meta,
    )
    assert ev.audit_metadata is meta
    assert ev.artifact_content.startswith("## Evidence")


def test_evidence_create_accepts_audit_metadata_dict() -> None:
    """Pydantic auto-coerces a dict into the nested model."""
    meta_dict = {
        "producer_kind": "cli",
        "producer_id": "cli",
        "captured_at": _NOW,
        "source_type": "code_snippet",
        "source_uri": "file:///x.py",
        "source_excerpt": "x",
        "content_hash": _VALID_HASH,
        "capture_method": "repository_file_read",
    }
    ev = EvidenceCreate(
        name="x",
        description="y",
        artifact_content="artifact",
        evidence_type="code_snippet",
        audit_metadata=meta_dict,  # type: ignore[arg-type]
    )
    assert ev.audit_metadata is not None
    assert ev.audit_metadata.producer_kind == "cli"


def test_evidence_create_serialization_round_trip_preserves_metadata() -> None:
    meta = build_recipe_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
        recipe_id="code-evidence-capture",
        recipe_version="0.1.0",
    )
    ev = EvidenceCreate(
        name="x",
        description="y",
        artifact_content="artifact",
        evidence_type="code_snippet",
        audit_metadata=meta,
    )
    payload = ev.model_dump(mode="json")
    assert "audit_metadata" in payload
    assert payload["audit_metadata"]["producer_kind"] == "recipe"
    # Round trip.
    rehydrated = EvidenceCreate.model_validate(payload)
    assert rehydrated.audit_metadata is not None
    assert rehydrated.audit_metadata.producer_id == "code-evidence-capture"


def test_evidence_batch_item_accepts_audit_metadata() -> None:
    meta = build_agent_metadata(
        body="x",
        source_uri="file:///x.py",
        source_type="code_snippet",
        agent_id="codex-agent",
    )
    item = EvidenceBatchItemCreate(
        name="x",
        description="y",
        artifact_content="artifact",
        control_id="AC-2",
        evidence_type="code_snippet",
        audit_metadata=meta,
    )
    assert item.audit_metadata is not None
    assert item.audit_metadata.producer_kind == "agent"


def test_evidence_batch_item_requires_artifact_content_and_audit_metadata() -> None:
    with pytest.raises(ValidationError):
        EvidenceBatchItemCreate(
            name="x",
            description="y",
            control_id="AC-2",
            evidence_type="code_snippet",
        )


@pytest.mark.parametrize(
    "evidence_type",
    [
        "system_spec_inventory_attestation",
        "system_spec_boundary_diagram",
        "system_spec_network_dfd",
        "system_spec_ppsm",
        "system_spec_interconnection",
    ],
)
def test_system_spec_evidence_types_are_accepted_by_create_models(evidence_type: str) -> None:
    meta = build_cli_metadata(
        body="system spec snapshot",
        source_uri=f"pretorin://system-spec/{evidence_type}",
        source_type=evidence_type_to_source_type(evidence_type),
    )

    ev = EvidenceCreate(
        name="System spec snapshot",
        description="System spec snapshot evidence",
        artifact_content="## Evidence\n\n- System spec snapshot captured.",
        evidence_type=evidence_type,
        audit_metadata=meta,
    )
    assert ev.evidence_type == evidence_type

    item = EvidenceBatchItemCreate(
        name="System spec snapshot",
        description="System spec snapshot evidence",
        artifact_content="## Evidence\n\n- System spec snapshot captured.",
        control_id="AC-2",
        evidence_type=evidence_type,
        audit_metadata=meta,
    )
    assert item.evidence_type == evidence_type
