# Model Context Protocol (MCP) Integration

The Pretorin CLI includes a built-in MCP server that enables AI assistants like Claude, Codex, Cursor, and Windsurf to access compliance framework data directly during conversations.

Scoped compliance execution tools on the MCP server run inside exactly one `system + framework` pair at a time. Set the active scope with `pretorin context set`, or pass both values explicitly. If a request spans multiple framework levels or systems, split it into separate runs.

Before running write-heavy MCP workflows from a shell or GUI wrapper, prefer validating the stored scope with:

```bash
pretorin context show --quiet --check
```

## Why MCP?

The Model Context Protocol allows AI assistants to:

- **Access real-time data** - Query the latest compliance frameworks, controls, and requirements
- **Understand context** - Get detailed control guidance and related controls for better recommendations
- **Reduce hallucination** - Work with authoritative compliance data instead of training knowledge
- **Streamline workflows** - No need to copy-paste control requirements or switch between tools

## Quick Setup

### 1. Install Pretorin CLI

```bash
uv tool install pretorin
```

Alternative installs:

```bash
pip install pretorin
pipx install pretorin
```

### 2. Authenticate

```bash
pretorin login
```

### 3. Configure Your AI Tool

<details open>
<summary><strong>Claude Desktop</strong></summary>

Add to your Claude Desktop configuration file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

**Linux**: `~/.config/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "pretorin": {
      "command": "pretorin",
      "args": ["mcp-serve"]
    }
  }
}
```

Restart Claude Desktop after saving.

</details>

<details>
<summary><strong>Claude Code</strong></summary>

**Quick setup** — run a single command:

```bash
claude mcp add --transport stdio pretorin -- pretorin mcp-serve
```

This registers the server for your current project. To make it available across all your projects, add `--scope user`.

**Team setup** — add a `.mcp.json` file to your project root so every team member gets the server automatically:

```json
{
  "mcpServers": {
    "pretorin": {
      "type": "stdio",
      "command": "pretorin",
      "args": ["mcp-serve"]
    }
  }
}
```

Claude Code will detect the file automatically.

</details>

<details>
<summary><strong>Cursor</strong></summary>

Add to `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "pretorin": {
      "command": "pretorin",
      "args": ["mcp-serve"]
    }
  }
}
```

Restart Cursor after saving.

</details>

<details>
<summary><strong>OpenAI Codex CLI</strong></summary>

Add to `~/.codex/config.toml`:

```toml
[mcp_servers.pretorin]
command = "pretorin"
args = ["mcp-serve"]
```

If you installed Pretorin with `uv tool install` or `pipx`, prefer pinning the absolute path from `command -v pretorin` to avoid PATH drift between shells and GUI apps.

</details>

<details>
<summary><strong>Windsurf</strong></summary>

Add to `~/.codeium/windsurf/mcp_config.json`:

```json
{
  "mcpServers": {
    "pretorin": {
      "command": "pretorin",
      "args": ["mcp-serve"]
    }
  }
}
```

Restart Windsurf after saving.

</details>

### 4. Restart Your AI Tool

Restart the application to load the new MCP server.

## Available Tools

The MCP server provides 113 tools organized by category.

### Task Routing

| Tool | Description |
|------|-------------|
| `start_task` | Route a user prompt to the right workflow. Call this FIRST whenever the user references compliance work (a control, system, framework, questionnaire, or campaign). |
| `check_context` | Cheap, unauthenticated probe of session grounding. Call at session start before `start_task` to learn whether the client is authenticated and what to do next. |
| `get_instructions` | Return the server's routing instructions on demand for harnesses that don't render the MCP `initialize` instructions. Unauthenticated. |
| `list_tools` | Compact catalog of every available MCP tool (`{name, purpose, tier, requires_workflow}`). Unauthenticated. |

### Framework & Control Reference

| Tool | Description |
|------|-------------|
| `list_frameworks` | List all available compliance frameworks |
| `get_framework` | Get detailed metadata about a specific framework |
| `list_control_families` | List control families for a framework |
| `list_controls` | List controls, optionally filtered by family |
| `get_control` | Get detailed control information including parameters |
| `get_controls_batch` | Get detailed control data for many controls in one request |
| `get_control_references` | Get control guidance, objectives, and related controls |

### Systems

| Tool | Description |
|------|-------------|
| `list_systems` | List systems in the current organization |
| `get_system` | Get system metadata, attached frameworks, and impact level |
| `get_compliance_status` | Get implementation progress for a system |
| `get_cli_status` | CLI version status with update availability and upgrade guidance |
| `get_source_manifest` | Resolved source manifest and satisfaction status for a system |
| `list_connected_sources` | List source connections bound to a system for recipe preflight |

### Evidence Management

| Tool | Description |
|------|-------------|
| `search_evidence` | Search current evidence items |
| `create_evidence` | Upsert evidence (find-or-create by default) |
| `create_evidence_batch` | Create and link multiple evidence items in one scoped request |
| `upload_evidence` | Upload a file as evidence to the platform (system-scoped, requires WRITE access) |
| `link_evidence` | Link an existing evidence item to a control |
| `link_evidence_to_cci_implementation` | Link an evidence item to a per-system CCI implementation row by UUID |
| `link_evidence_to_stig_rule_workflow` | Link an evidence item to a STIG rule workflow (lazy-creates the row if absent) |
| `delete_evidence` | Delete an evidence item (system-scoped, requires WRITE access) |

### Implementation Context

| Tool | Description |
|------|-------------|
| `get_control_context` | Get rich control context: AI guidance, statement, objectives, and implementation details |
| `get_scope` | Get scope narrative, exclusions, and scope Q&A |
| `get_narrative` | Get the current narrative for a control |
| `get_control_implementation` | Get implementation status, narrative, evidence count, and notes |
| `get_control_notes` | Read notes for a control implementation |
| `update_narrative` | Push a narrative text update for a control implementation |
| `add_control_note` | Add a control note with manual follow-up guidance |
| `resolve_control_note` | Resolve, unresolve, or update an existing control note |
| `update_control_status` | Start/reopen control authoring by setting `in_progress` |
| `generate_control_artifacts` | Generate read-only AI narrative and evidence-gap drafts |

### Monitoring

| Tool | Description |
|------|-------------|
| `push_monitoring_event` | Create a monitoring event for a system |

### Workflow State & Analytics

| Tool | Description |
|------|-------------|
| `get_workflow_state` | Get lifecycle state for a system+framework (scope, policies, controls, evidence) |
| `get_analytics_summary` | Lightweight system progress snapshot |
| `get_family_analytics` | Per-family breakdown: narrative coverage, evidence, status distribution |
| `get_policy_analytics` | Per-policy breakdown: answer completion, review status |

### Family Operations

| Tool | Description |
|------|-------------|
| `get_pending_families` | Identify families that need work (pending vs total counts) |
| `get_family_bundle` | Get all controls in a family with status, narrative, evidence, notes |
| `trigger_family_review` | Trigger AI review of all controls in a family |
| `get_family_review_results` | Poll family review results with findings |

### Scope Workflow

| Tool | Description |
|------|-------------|
| `get_pending_scope_questions` | Get only unanswered scope questions |
| `get_scope_question_detail` | Get guidance, tips, and examples for a scope question |
| `answer_scope_question` | Answer one scope question |
| `patch_scope_qa` | Batch update scope questionnaire answers |
| `trigger_scope_generation` | Trigger AI scope document generation |
| `trigger_scope_review` | Trigger AI scope review |
| `get_scope_review_results` | Poll scope review results |

### Policy Workflow

| Tool | Description |
|------|-------------|
| `list_org_policies` | List organization policies |
| `get_org_policy_questionnaire` | Get policy questionnaire state |
| `get_pending_policy_questions` | Get only unanswered policy questions |
| `get_policy_question_detail` | Get guidance for a policy question |
| `answer_policy_question` | Answer one policy question |
| `patch_org_policy_qa` | Batch update policy questionnaire answers |
| `get_policy_workflow_state` | Per-policy completion and review status |
| `trigger_policy_generation` | Trigger AI policy document generation |
| `trigger_policy_review` | Trigger AI policy review |
| `get_policy_review_results` | Poll policy review results |

### Campaign Operations

| Tool | Description |
|------|-------------|
| `prepare_campaign` | Prepare a campaign run with platform state snapshot |
| `claim_campaign_items` | Claim items for drafting with TTL-based leases |
| `get_campaign_item_context` | Get full item context and drafting instructions |
| `submit_campaign_proposal` | Submit a proposal without applying to platform |
| `apply_campaign` | Push accepted proposals to the platform |
| `get_campaign_status` | Get structured campaign status snapshot |

### Risk Management

| Tool | Description |
|------|-------------|
| `list_risks` | List risks for a system with optional category, risk-level, and status filters |
| `get_risk` | Get full risk detail including eager-loaded `artifact_links` |
| `create_risk` | Create a custom risk; pass `framework_id` + `suggested_control_families` for opt-in control auto-link |
| `seed_risks` | Bulk-instantiate library templates against a system + framework |
| `update_risk` | Update risk fields including the `treatment` mitigation surface (no separate `/mitigate` endpoint) |
| `link_risk_artifact` | Attach a control / evidence / finding / vendor / monitoring event to a risk |
| `unlink_risk_artifact` | Remove a risk artifact link |
| `refresh_risk_summary` | Re-score risk and trigger best-effort AI summary regeneration |
| `list_risk_library` | Browse the org-level risk template library |

### Vendor Management

| Tool | Description |
|------|-------------|
| `list_vendors` | List all vendor entities |
| `create_vendor` | Create a vendor (CSP, SaaS, managed service, internal) |
| `get_vendor` | Get vendor details |
| `update_vendor` | Update vendor fields |
| `delete_vendor` | Delete a vendor entity |
| `upload_vendor_document` | Upload vendor evidence documents |
| `list_vendor_documents` | List documents linked to a vendor |
| `link_evidence_to_vendor` | Link evidence to a vendor with attestation type |

### Inheritance & Responsibility

| Tool | Description |
|------|-------------|
| `set_control_responsibility` | Mark control as inherited/shared from a provider |
| `get_control_responsibility` | Check if control is inherited and from where |
| `remove_control_responsibility` | Convert inherited control to system-specific |
| `generate_inheritance_narrative` | AI-generate inheritance narrative from vendor docs |
| `get_stale_edges` | Identify controls with stale inheritance |
| `sync_stale_edges` | Bulk update inherited controls from source narratives |

### STIG & CCI

| Tool | Description |
|------|-------------|
| `list_stigs` | List STIG benchmarks with filters |
| `get_stig` | Get STIG benchmark detail |
| `list_stig_rules` | List rules with severity/CCI filters |
| `get_stig_rule` | Full rule detail: check text, fix text, CCIs |
| `list_ccis` | List CCIs with optional control filter |
| `get_cci` | CCI detail with linked SRGs and rules |
| `get_cci_chain` | Full traceability: Control -> CCIs -> SRGs -> STIG rules |
| `get_cci_status` | CCI-level compliance rollup for a system |
| `get_cci_implementation` | Read a single per-system CCI implementation row by `(system_id, cci_uuid)` |
| `get_stig_applicability` | Which STIGs apply to a system |
| `infer_stigs` | AI-infer applicable STIGs from system profile |
| `get_test_manifest` | Fetch test manifest for a system |
| `submit_test_results` | Upload STIG scan results |

### Recipes & Workflows

| Tool | Description |
|------|-------------|
| `list_recipes` | List loaded recipes with summary metadata; filter by tier and/or what they produce |
| `get_recipe` | Return one recipe's full manifest and markdown body (the playbook the agent reads) |
| `start_recipe` | Open a recipe execution context; returns a `context_id` to stamp audit metadata on subsequent writes |
| `end_recipe` | Close a recipe execution context and return the RecipeResult summary |
| `check_sources` | Preflight source reachability and candidate recipes for one workflow/control before opening a recipe context |
| `list_workflows` | List loaded workflow playbooks (single-control, scope-question, policy-question, campaign) |
| `get_workflow` | Return one workflow's full manifest and markdown body |

### System Spec Artifacts

| Tool | Description |
|------|-------------|
| `list_artifact_requirements` | List the 5 auditor-required system_spec artifact kinds for a system and their required / toggle / attest state |
| `get_asset_inventory` | Return the system's asset inventory (active rows by default; pass `as_of` for historical replay) |
| `submit_asset_inventory_diff` | Submit a recipe-driven asset-inventory diff (added / modified / decommissioned rows) |

`generate_control_artifacts` is read-only. Use `update_narrative`, `create_evidence`, and `add_control_note` to persist approved changes.

### Tool Reference

#### list_frameworks

List all available compliance frameworks.

**Parameters:** None

**Returns:** List of frameworks with ID, title, version, tier, and control counts.

**Example prompt:** "What compliance frameworks are available?"

---

#### get_framework

Get detailed metadata about a specific framework.

**Parameters:**
- `framework_id` (required): The framework ID (e.g., `nist-800-53-r5`, `fedramp-moderate`)

**Returns:** Framework details including description, version, OSCAL version, and dates.

**Example prompt:** "Tell me about the FedRAMP Moderate framework"

---

#### list_control_families

List all control families for a specific framework.

**Parameters:**
- `framework_id` (required): The framework ID

**Returns:** List of control families with ID, title, class, and control count.

**Example prompt:** "What control families are in NIST 800-53?"

---

#### list_controls

List controls for a framework, optionally filtered by family.

**Parameters:**
- `framework_id` (required): The framework ID
- `family_id` (optional): Filter by control family ID. Family IDs are slugs like `access-control` or `audit-and-accountability`, not short codes like `ac` or `au`. CMMC families include a level suffix (e.g., `access-control-level-2`). Use `pretorin frameworks families <id>` to discover valid family IDs.

**Returns:** List of controls with ID, title, and family.

**Example prompt:** "Show me all Access Control controls in NIST 800-53"

---

#### get_control

Get detailed information about a specific control.

**Parameters:**
- `framework_id` (required): The framework ID
- `control_id` (required): The control ID. NIST/FedRAMP controls are zero-padded (e.g., `ac-01`, not `ac-1`). CMMC controls use dotted notation (e.g., `AC.L2-3.1.1`). Use `pretorin frameworks controls <id>` to discover valid control IDs.

**Returns:** Control details including parameters, parts, and enhancement count.

**Example prompt:** "Explain the Account Management control from NIST 800-53"

---

#### get_controls_batch

Get detailed control data for many controls in a single framework-scoped request.

**Parameters:**
- `framework_id` (required): The framework ID
- `control_ids` (optional): A list of canonical control IDs to retrieve. Omit it to return all controls in the framework.

**Returns:** Full control detail records for the requested controls.

**Example prompt:** "Fetch the full details for AC-02, IA-02, and SC-07 in FedRAMP Moderate"

---

#### get_control_references

Get reference information for a control including guidance and related controls.

**Parameters:**
- `framework_id` (required): The framework ID
- `control_id` (required): The control ID (zero-padded for NIST/FedRAMP, e.g., `ac-01`)

**Returns:** Statement, guidance, objectives, parameters, and related controls.

**Example prompt:** "What is the guidance for implementing Account Management?"

---

#### list_systems

List systems in the current organization.

**Parameters:** None

**Returns:** System IDs, names, and summary metadata.

**Example prompt:** "List my systems"

---

#### get_system

Get metadata about a specific system.

**Parameters:**
- `system_id` (required): The system ID or name

**Returns:** System metadata including security impact level and attached frameworks.

**Example prompt:** "Show me the details for my production system"

---

#### get_compliance_status

Get framework progress and implementation posture for a system.

**Parameters:**
- `system_id` (required): The system ID or name

**Returns:** Framework status summaries and progress metrics.

**Example prompt:** "How far along is my FedRAMP Moderate system?"

---

#### get_cli_status

Return the local Pretorin CLI version status, including update availability and upgrade guidance for MCP hosts and agents.

**Parameters:**
- `force` (optional): Bypass the local cache and re-check PyPI for the latest version (default: `false`)

**Returns:** Current version, latest available version, whether an update is needed, and upgrade command.

**Example prompt:** "Is my Pretorin CLI up to date?"

---

#### get_source_manifest

Get the resolved source manifest for a system and evaluate it against currently detected sources (git, cloud, HRIS, etc.).

**Parameters:**
- `system_id` (optional): Defaults to active scope

**Returns:** Required, recommended, and optional sources with satisfaction status. Returns null manifest if none is configured.

**Example prompt:** "Which data sources does my system need?"

---

#### search_evidence

Search evidence items within one active system/framework scope.

**Parameters:**
- `system_id` (optional): Defaults to active scope
- `control_id` (optional): Filter by control ID
- `framework_id` (optional): Defaults to active scope
- `limit` (optional): Maximum results (default: 20)

**Returns:** Matching evidence items with IDs, names, types, and linked controls.

**Example prompt:** "Show me all evidence linked to AC-02"

---

#### delete_evidence

Delete an evidence item from the platform (system-scoped, requires WRITE access).

**Parameters:**
- `evidence_id` (required): The evidence item ID to delete
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** Deletion confirmation.

**Example prompt:** "Delete evidence item ev_456"

---

#### get_control_context

Get rich context for a control including AI guidance, control statement, assessment objectives, scope status, and current implementation details.

**Parameters:**
- `control_id` (required): The control ID (zero-padded for NIST/FedRAMP, e.g., `ac-01`)
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** Combined control metadata and implementation details: AI guidance, statement, objectives, scope status, narrative, user context.

**Example prompt:** "What's the full context for AC-02 in my FedRAMP Moderate system?"

---

#### get_narrative

Get the current narrative record for a control.

**Parameters:**
- `control_id` (required): The control ID
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** Narrative text, status, and AI confidence metadata when present.

**Example prompt:** "Show me the current narrative for AC-02 in my system"

---

#### get_scope

Get system scope and policy information including excluded controls and Q&A responses.

**Parameters:**
- `system_id` (required): The system ID or name
- `framework_id` (required): The framework ID

**Returns:** Scope narrative, list of excluded controls, Q&A responses, and scope status.

**Example prompt:** "Which controls are excluded from scope for my system?"

---

#### patch_scope_qa

Apply partial scope questionnaire updates for a system/framework.

**Parameters:**
- `system_id` (required): The system ID or name
- `framework_id` (required): The framework ID
- `updates` (required): A non-empty list of `{question_id, answer}` objects

**Returns:** The updated scope questionnaire state including saved answers.

**Example prompt:** "Set my scope answer for sd-1 to say the system handles CUI in production"

---

#### list_org_policies

List organization policies available for questionnaire work.

**Parameters:** None

**Returns:** Policy summaries with IDs, names, template IDs, and questionnaire status.

**Example prompt:** "What organization policies can I work on?"

---

#### get_org_policy_questionnaire

Get the canonical questionnaire state for one organization policy.

**Parameters:**
- `policy_id` (required): The organization policy ID

**Returns:** Policy metadata, saved answers, and template/question structure when available.

**Example prompt:** "Show me the questionnaire for policy pol-123"

---

#### patch_org_policy_qa

Apply partial organization policy questionnaire updates.

**Parameters:**
- `policy_id` (required): The organization policy ID
- `updates` (required): A non-empty list of `{question_id, answer}` objects

**Returns:** The updated policy questionnaire state.

**Example prompt:** "Update the Access Control policy questionnaire to say MFA is required for all users"

---

#### get_control_implementation

Get implementation details for a control in a system.

**Parameters:**
- `control_id` (required): The control ID
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** Current status, narrative, evidence count, and implementation notes metadata.

**Example prompt:** "Show me implementation details for AC-02 in my system"

---

#### update_narrative

Push a narrative text update for a control implementation on the platform.

**Parameters:**
- `control_id` (required): The control ID
- `narrative` (required): The narrative text to set
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope
- `is_ai_generated` (optional): Whether the narrative was AI-generated (default: false)

Validation rules:
- No markdown headings (`#`, `##`, etc.)
- At least two rich markdown elements (fenced code blocks, tables, lists, links)
- At least one structural element (`code block`, `table`, or `list`)
- Markdown images are currently disallowed

**Returns:** Confirmation of the update.

**Example prompt:** "Update the narrative for AC-02 with the implementation details I just described"

---

#### create_evidence

Upsert evidence on the platform (find-or-create by default). If `dedupe` is true, exact matching evidence in the active system/framework scope is reused; otherwise a new record is created. The tool then ensures control linking inside that same scope.

**Parameters:**
- `name` (required): Evidence name
- `description` (required): Evidence description
- `evidence_type` (optional): Evidence type (default: `policy_document`)
- `control_id` (optional): Associated control
- `framework_id` (optional): Associated framework
- `system_id` (optional): Defaults to active scope
- `dedupe` (optional): Reuse exact matches before create (default: `true`)

Validation rules:
- No markdown headings (`#`, `##`, etc.)
- At least one rich markdown element (fenced code blocks, tables, lists, or links)
- Markdown images are currently disallowed

**Returns:** Upsert result with:
- `evidence_id`
- `created` (true if new, false if reused)
- `linked` (whether control/system link succeeded)
- `match_basis` (`exact_name_desc_type_control_framework` or `none`)

---

#### create_evidence_batch

Create and link multiple evidence items within one active system/framework scope.

**Parameters:**
- `items` (required): Array of evidence payloads with `name`, `description`, and `control_id`; may also include `evidence_type` and `relevance_notes`
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** Batch creation summary with per-item status and evidence IDs.

**Example prompt:** "Create three evidence records for AC-02, AC-03, and IA-02 from these notes"

---

#### link_evidence

Link an existing evidence item to a control.

**Parameters:**
- `evidence_id` (required): The evidence item ID
- `control_id` (required): The control ID
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Framework context for the link

**Returns:** Link confirmation for the requested control association.

**Example prompt:** "Link evidence item ev_123 to AC-02"

---

#### upload_evidence

Upload a file as evidence to the platform (system-scoped, requires WRITE access).

**Parameters:**
- `file_path` (required): Absolute path to the file to upload
- `name` (required): Evidence name
- `evidence_type` (optional): Type of evidence (default: `other`)
- `description` (optional): Evidence description
- `control_id` (optional): Associated control
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** Upload confirmation with evidence ID.

**Example prompt:** "Upload the scan report at /tmp/scan.pdf as evidence for SC-07"

---

#### get_control_notes

Get notes for a control implementation in a system.

**Parameters:**
- `control_id` (required): The control ID
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** Note list with `total` count.

---

#### add_control_note

Add a note for unresolved gaps or manual follow-up actions.

**Parameters:**
- `control_id` (required): The control ID
- `content` (required): Note body
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** The created note record.

**Example prompt:** "Add a note that SSO evidence must be collected manually"

---

#### resolve_control_note

Resolve, unresolve, or update an existing control note. Use this to clear blocking notes so control status can advance. Resolving a note requires a `resolution_note` justification for the audit trail.

**Parameters:**
- `system_id` (optional): Defaults to active scope
- `control_id` (required): The control ID
- `note_id` (required): ID of the note to resolve or update
- `framework_id` (optional): Defaults to active scope
- `is_resolved` (optional, default `true`): Set `false` to reopen
- `resolution_note` (required when resolving): Explain why the note can be closed; stored as the resolution audit trail and cascaded to linked RFIs/findings
- `content` (optional): Updated note content
- `is_pinned` (optional): Whether the note is pinned

**Returns:** The updated note record.

**Example prompt:** "Resolve the blocking note on AC-02 now that SSO evidence has been uploaded"

---

#### update_control_status

Start or reopen authoring for a control.

**Parameters:**
- `control_id` (required): The control ID
- `status` (required): Must be `in_progress`
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

CLI/MCP callers cannot set `ready_to_approve`, `implemented`, or `not_applicable`; those decisions happen in the Pretorin UI by a human.

**Returns:** Status update confirmation.

**Example prompt:** "Mark AC-02 as in_progress for my system"

---

#### push_monitoring_event

Create a monitoring event for a system.

**Parameters:**
- `title` (required): Event title
- `severity` (optional): Severity (`critical`, `high`, `medium`, `low`, `info`)
- `event_type` (optional): Event type (`security_scan`, `configuration_change`, `access_review`, `compliance_check`)
- `control_id` (optional): Associated control ID
- `description` (optional): Detailed event description
- `system_id` (optional): Defaults to active scope
- `framework_id` (optional): Defaults to active scope

**Returns:** The created monitoring event.

**Example prompt:** "Record a quarterly access review event for my production system"

---

#### generate_control_artifacts

Generate read-only AI drafts for a control narrative and evidence-gap assessment.

**Parameters:**
- `system_id` (required): The system ID
- `control_id` (required): The control ID
- `framework_id` (required): The framework ID
- `working_directory` (optional): Local workspace path for code-aware drafting
- `model` (optional): Model override

**Returns:** Draft narrative text plus evidence-gap analysis without writing anything to the platform.

**Example prompt:** "Draft narrative and evidence gaps for AC-02 using this repo as context"

#### list_artifact_requirements

List the 5 auditor-required system_spec artifact kinds for a system and their required / toggle / attest state.

**Parameters:**
- `system_id` (required): The system ID

**Returns:** Array of artifact-kind records (`effective_required`, `optional`, `attested_at`, `rationale`).

**Example prompt:** "Which system_spec artifacts is `prod-fedramp` still missing?"

#### get_asset_inventory

Return the system's asset inventory. Active rows by default; pass `as_of` for historical replay.

**Parameters:**
- `system_id` (required): The system ID
- `as_of` (optional): ISO-8601 timestamp for historical replay

**Returns:** Array of asset rows.

**Example prompt:** "Show me the asset inventory for `prod-fedramp` as of 2026-04-01"

#### submit_asset_inventory_diff

Submit a recipe-driven asset-inventory diff. At least one of `added` / `modified` / `decommissioned` must be a non-empty array. `recipe_id` is a free-form string recorded as `cli:<recipe_id>` provenance per row. `idempotency_key` defaults to `sha256(system_id, recipe_id, scan_timestamp)[:32]` — supply your own when replaying a scan. `recipe_context_id` is optional; the diff endpoint accepts it cleanly but does not require it.

**Parameters:**
- `system_id` (required): The system ID
- `recipe_id` (required): Free-form CLI recipe id (e.g., `asset-inventory-aws-baseline`)
- `added` (optional): Array of new asset rows (at least `external_id`)
- `modified` (optional): Array of changed asset rows keyed by `external_id`
- `decommissioned` (optional): Array of `{external_id, rationale}` rows to decommission
- `idempotency_key` (optional): Replay-safe key; auto-derived when omitted
- `recipe_context_id` (optional): UUID returned by `start_recipe`

**Returns:** `{idempotency_key, summary: {created, modified, decommissioned, unchanged, not_found, errors}, items: [...]}`.

**Example prompt:** "Run the AWS inventory scan against `prod-fedramp` and apply the diff"

## Resources

The MCP server also exposes resources for analysis guidance:

| Resource URI | Description |
|--------------|-------------|
| `analysis://schema` | JSON schema for compliance artifacts |
| `analysis://guide/{framework_id}` | Analysis guide for a specific framework |
| `analysis://control/{framework_id}/{control_id}` | Analysis guidance for a specific control within one framework scope |
| `status://cli` | Current CLI version, update availability, and upgrade guidance |
| `workflow://recipe/{recipe_id}` | Step-by-step workflow recipe for common compliance tasks |

## Example Conversations

### Getting Started with a Framework

> **You:** What compliance frameworks are available for government systems?
>
> **Claude:** *Uses list_frameworks* I can see several frameworks available including NIST 800-53 Rev 5, NIST 800-171, and FedRAMP at various impact levels...

### Understanding a Control

> **You:** I need to implement Account Management for our FedRAMP Moderate system. What does it require?
>
> **Claude:** *Uses get_control and get_control_references* Account Management requires organizations to manage system accounts including identifying account types, establishing conditions for membership, and specifying authorized users...

### Planning Documentation

> **You:** What policies and documents do I need to write for FedRAMP Moderate?
>
> **Claude:** *Uses list_org_policies and get_compliance_status* For FedRAMP Moderate, you'll need several key documents including System Security Plan (SSP), Incident Response Plan, Contingency Plan...

### Control Family Overview

> **You:** Give me an overview of the Audit controls in NIST 800-53
>
> **Claude:** *Uses list_controls with family filter* The Audit and Accountability family contains controls for audit events, content, storage, review, and reporting...

## Troubleshooting

### "Not authenticated" Error

If you see authentication errors, ensure you've logged in:

```bash
pretorin login
pretorin whoami  # Verify authentication
```

### MCP Server Not Found

1. Verify pretorin is installed and in your PATH:
   ```bash
   which pretorin
   pretorin --version
   ```

2. Try using the full path in your config:
   ```json
   {
     "mcpServers": {
       "pretorin": {
         "command": "/path/to/pretorin",
         "args": ["mcp-serve"]
       }
     }
   }
   ```

3. For `uv tool` or `pipx` installations, find the path:
   ```bash
   command -v pretorin
   ```

4. If the MCP client can connect but scoped write tools behave strangely, validate the stored CLI context:
   ```bash
   pretorin context show --quiet --check
   ```

   This catches deleted systems, detached frameworks, and other stale local scope before you debug the MCP client itself.

### Server Crashes or Hangs

Check the MCP server logs:

**macOS/Linux:**
```bash
pretorin mcp-serve 2>&1 | tee mcp-debug.log
```

Ensure your API key is valid:
```bash
pretorin whoami
```

### Framework or Control Not Found

- Verify the framework ID exists: `pretorin frameworks list`
- Verify the control ID exists: `pretorin frameworks controls <framework_id>`

## Using with Other MCP Clients

The Pretorin MCP server follows the standard Model Context Protocol and should work with any MCP-compatible client. The server communicates via stdio (standard input/output).

To test the server manually:

```bash
pretorin mcp-serve
```

The server accepts JSON-RPC messages on stdin and responds on stdout.

## Support

- Documentation: [platform.pretorin.com/api/docs](https://platform.pretorin.com/api/docs)
- Issues: [github.com/pretorin-ai/pretorin-cli/issues](https://github.com/pretorin-ai/pretorin-cli/issues)
- Platform: [platform.pretorin.com](https://platform.pretorin.com)
