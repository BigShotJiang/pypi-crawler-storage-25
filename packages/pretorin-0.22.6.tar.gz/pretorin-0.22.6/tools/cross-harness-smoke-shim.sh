#!/usr/bin/env bash
# Wrapper for `pretorin mcp-serve` used by tools/cross-harness-smoke.py.
#
# When PRETORIN_SMOKE_SESSION_LOG is set, the wrapped server's stderr is
# tee'd to that file so the smoke runner can grep for
# PRETORIN_TELEMETRY_EVENT lines. When unset, behaves identically to
# invoking `pretorin mcp-serve` directly.
#
# Each harness's MCP config should point at this script as the server
# command. The runner sets the log path via env var per scenario run.

set -euo pipefail

if [[ -n "${PRETORIN_SMOKE_SESSION_LOG:-}" ]]; then
  exec pretorin mcp-serve 2> >(tee -a "$PRETORIN_SMOKE_SESSION_LOG" >&2)
else
  exec pretorin mcp-serve
fi
