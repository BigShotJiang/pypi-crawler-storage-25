#!/usr/bin/env python3
"""Cross-harness MCP smoke-test runner.

Runs the four scenarios from ``tests/manual/rfc-113-cross-harness-smoke-test.md``
against locally-installed MCP-aware agents (claude, codex, agent, devin) and
produces the comparison table for issue #121.

What it does
------------
1. Verifies (via ``--setup``) that each harness has the pretorin MCP server
   wired through ``tools/cross-harness-smoke-shim.sh`` — that shim tees the
   server's stderr to a per-run log so we can grep ``PRETORIN_TELEMETRY_EVENT``
   lines.
2. For each (harness, scenario) pair: applies the precondition with
   ``pretorin context``, invokes the harness with the scenario prompt under
   non-interactive print + stream-json output, captures stdout (tool-call
   stream) and the MCP-server stderr log, then classifies pass / soft / fail.
3. Renders a paste-ready Markdown comparison table.

Usage
-----
    python tools/cross-harness-smoke.py --setup
    python tools/cross-harness-smoke.py --harness claude
    python tools/cross-harness-smoke.py --scenario S2
    python tools/cross-harness-smoke.py                     # all configured

Results
-------
- Per-run logs:     tools/logs/cross-harness/<run-id>/<harness>-<scenario>.{stdout,stderr,log}
- Results YAML:     tools/logs/cross-harness/<run-id>/results.yaml
- Comparison table: printed to stdout, ready to paste into #121
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent.parent
SHIM_PATH = REPO_ROOT / "tools" / "cross-harness-smoke-shim.sh"
LOG_ROOT = REPO_ROOT / "tools" / "logs" / "cross-harness"

# Known pretorin tool names we care about for classification. Anything else
# in the agent's tool stream gets ignored so noise from harness-builtins
# (e.g. claude's Read/Bash) doesn't muddy the sequence.
PRETORIN_TOOLS = {
    "check_context",
    "start_task",
    "list_systems",
    "list_tools",
    "get_instructions",
    "get_workflow",
    "check_sources",
    "list_recipes",
    "start_recipe",
    "end_recipe",
    "create_evidence",
    "create_evidence_batch",
    "update_narrative",
}

SCHEMA_FETCH_TOOLS = {"list_tools", "get_instructions"}

DEFAULT_TIMEOUT_SECONDS = 240


# ---------------------------------------------------------------------------
# Scenario definitions
# ---------------------------------------------------------------------------


@dataclass
class Scenario:
    id: str
    title: str
    precondition: str  # "grounded" | "cleared" | "any"
    prompt: str
    classifier: Callable[[ScenarioContext], Classification]


@dataclass
class ScenarioContext:
    tool_sequence: list[str]
    tool_inputs: list[dict[str, Any]]
    telemetry_events: list[dict[str, Any]]
    stdout_text: str
    stderr_text: str


@dataclass
class Classification:
    verdict: str  # "pass" | "soft" | "fail" | "error"
    reason: str


def classify_s1(ctx: ScenarioContext) -> Classification:
    seq = ctx.tool_sequence
    if "check_context" not in seq:
        return Classification("fail", "check_context never called")
    if "list_systems" not in seq:
        return Classification("fail", "list_systems never called")
    if seq.index("check_context") < seq.index("list_systems"):
        return Classification("pass", f"sequence: {' -> '.join(seq)}")
    return Classification("fail", f"check_context came after list_systems: {seq}")


def classify_s2(ctx: ScenarioContext) -> Classification:
    """S2 asks: did the agent bypass the workflow guardrails?

    Three "no bypass" pass paths:
      A) Defensive-only — agent grounded and stopped before any write.
      B) Canonical happy path — grounded -> start_task -> start_recipe ->
         create_evidence, no recipe_required error needed (agent provided
         recipe_context_id correctly the first time).
      C) Canonical recovery — tried create_evidence, hit recipe_required,
         then grounded and retried with recipe_context_id.
    """
    seq = ctx.tool_sequence
    inputs = ctx.tool_inputs
    telemetry_kinds = [e.get("event_type") for e in ctx.telemetry_events]
    recipe_required_fired = "recipe_required" in telemetry_kinds

    if not seq and not telemetry_kinds:
        return Classification(
            "error",
            "no tool-call or telemetry signal captured — adapter may not expose stream-json or MCP wiring is broken",
        )

    def _index(tool: str) -> int:
        return seq.index(tool) if tool in seq else -1

    ce_idx = _index("create_evidence")
    st_idx = _index("start_task")
    sr_idx = _index("start_recipe")

    # Path A: defensive-only, never attempted a write.
    if ce_idx < 0:
        grounded = st_idx >= 0 or "check_context" in seq or "list_systems" in seq
        if grounded:
            return Classification(
                "pass",
                "defensive-only — agent grounded via " + " -> ".join(seq[:5]) + " and never attempted a write",
            )
        return Classification(
            "fail",
            f"no grounding and no write attempt; sequence={seq[:6]}",
        )

    # A write happened. Was it preceded by canonical grounding + recipe?
    grounded_before_write = 0 <= st_idx < ce_idx
    recipe_before_write = 0 <= sr_idx < ce_idx
    write_carried_context = isinstance(inputs[ce_idx], dict) and bool(inputs[ce_idx].get("recipe_context_id"))

    # Path B: canonical happy path — start_task -> start_recipe -> create_evidence,
    # no recipe_required needed because the agent provided recipe_context_id.
    if grounded_before_write and recipe_before_write and write_carried_context:
        return Classification(
            "pass",
            "canonical happy path: start_task -> start_recipe ->"
            " create_evidence(recipe_context_id=…), no guardrail needed",
        )

    # Path C: recovery from a recipe_required error.
    if recipe_required_fired:
        after = seq[ce_idx + 1 :]
        inputs_after = inputs[ce_idx + 1 :]
        if "start_task" not in after:
            return Classification("fail", "agent did not call start_task after recipe_required")
        if "start_recipe" not in after:
            return Classification("soft", "agent called start_task but never opened a recipe context")
        retried_with_ctx = any(
            t == "create_evidence" and isinstance(a, dict) and a.get("recipe_context_id")
            for t, a in zip(after, inputs_after, strict=False)
        )
        if not retried_with_ctx:
            return Classification(
                "soft",
                "agent opened a recipe but never retried create_evidence with recipe_context_id",
            )
        return Classification(
            "pass",
            "canonical recovery: create_evidence -> recipe_required -> start_task"
            " -> start_recipe -> create_evidence(recipe_context_id=…)",
        )

    # Write happened but didn't follow either canonical pattern.
    if grounded_before_write and not recipe_before_write:
        return Classification(
            "soft",
            "agent grounded but wrote create_evidence without going through start_recipe",
        )
    return Classification(
        "fail",
        f"create_evidence attempted without canonical grounding; sequence={seq[:8]}",
    )


def classify_s3(ctx: ScenarioContext) -> Classification:
    seq = ctx.tool_sequence
    if "list_tools" in seq or "get_instructions" in seq:
        return Classification("pass", f"used discovery tool: {sorted(set(seq) & SCHEMA_FETCH_TOOLS)}")
    return Classification("fail", f"no discovery tool called; sequence={seq}")


def classify_s4(ctx: ScenarioContext) -> Classification:
    seq = ctx.tool_sequence
    if "start_task" not in seq or "get_workflow" not in seq:
        return Classification("fail", f"expected start_task -> get_workflow, got {seq}")
    if seq.index("start_task") > seq.index("get_workflow"):
        return Classification("fail", f"get_workflow called before start_task: {seq}")
    # After get_workflow, count "extra schema fetches" before any workflow tool.
    after = seq[seq.index("get_workflow") + 1 :]
    schema_fetches_after = [t for t in after if t in SCHEMA_FETCH_TOOLS]
    workflow_tools_after = [t for t in after if t in {"create_evidence", "update_narrative", "create_evidence_batch"}]
    if schema_fetches_after and not workflow_tools_after:
        return Classification(
            "fail",
            f"agent kept fetching schemas after get_workflow without invoking workflow tools: {schema_fetches_after}",
        )
    if schema_fetches_after:
        first_workflow_idx = next(i for i, t in enumerate(after) if t in workflow_tools_after)
        if any(t in SCHEMA_FETCH_TOOLS for t in after[:first_workflow_idx]):
            return Classification(
                "soft",
                f"agent fetched extra schemas before first workflow tool call: {after[:first_workflow_idx]}",
            )
    if workflow_tools_after:
        return Classification("pass", "agent went straight from get_workflow to bundled workflow tools")
    return Classification(
        "soft",
        "agent reached get_workflow but did not invoke any workflow tool in this prompt"
        " — likely answered descriptively",
    )


SCENARIOS: list[Scenario] = [
    Scenario(
        id="S1",
        title="Cold-start grounding",
        precondition="grounded",
        prompt="What systems do I have configured?",
        classifier=classify_s1,
    ),
    Scenario(
        id="S2",
        title="Errors-as-instructions (recipe_required)",
        precondition="cleared",
        prompt="Create an evidence record for AC-2 on prod saying we ran a vuln scan.",
        classifier=classify_s2,
    ),
    Scenario(
        id="S3",
        title="Discovery",
        precondition="any",
        prompt="What can you do with pretorin?",
        classifier=classify_s3,
    ),
    Scenario(
        id="S4",
        title="Workflow schema bundling",
        precondition="grounded",
        prompt="Walk me through documenting a single control. Use the single-control workflow.",
        classifier=classify_s4,
    ),
]


# ---------------------------------------------------------------------------
# Harness adapters
# ---------------------------------------------------------------------------


@dataclass
class HarnessAdapter:
    name: str
    binary: str
    # MCP setup hint printed by --setup
    setup_hint: str

    def is_installed(self) -> bool:
        return shutil.which(self.binary) is not None

    def build_command(self, prompt: str) -> list[str]:
        raise NotImplementedError

    def env(self) -> dict[str, str]:
        return {}

    def extract_tool_calls(self, stdout_text: str) -> tuple[list[str], list[dict[str, Any]]]:
        """Walk every JSON-decodable line of stdout and pull pretorin tool calls.

        Default implementation is duck-typed: any object containing a ``name``
        field whose value is a known pretorin tool counts as a tool call, with
        ``input``/``arguments``/``parameters`` as the input dict.
        """
        names: list[str] = []
        inputs: list[dict[str, Any]] = []
        for obj in _iter_json_objects(stdout_text):
            for tool_name, tool_input in _walk_tool_calls(obj):
                if tool_name in PRETORIN_TOOLS:
                    names.append(tool_name)
                    inputs.append(tool_input)
        return names, inputs


class ClaudeAdapter(HarnessAdapter):
    def build_command(self, prompt: str) -> list[str]:
        mcp_config = json.dumps(
            {
                "mcpServers": {
                    "pretorin": {
                        "command": str(SHIM_PATH),
                    }
                }
            }
        )
        return [
            self.binary,
            "-p",
            prompt,
            "--mcp-config",
            mcp_config,
            "--strict-mcp-config",  # ignore the user's global pretorin entry; use only ours
            "--output-format",
            "stream-json",
            "--verbose",  # required by claude when stream-json is set
            "--allowedTools",
            ",".join(f"mcp__pretorin__{t}" for t in PRETORIN_TOOLS),
        ]


class CodexAdapter(HarnessAdapter):
    def build_command(self, prompt: str) -> list[str]:
        # Assumes the user has already run:
        #   codex mcp add pretorin -- /abs/path/to/cross-harness-smoke-shim.sh
        return [self.binary, "exec", "--json", prompt]


class AgentAdapter(HarnessAdapter):
    """Cursor's `agent` CLI. MCP servers live in ~/.cursor/mcp.json.

    Agent's stream-json wraps MCP calls in ``tool_call`` events with a nested
    ``mcpToolCall.args.toolName`` field; we read that directly and dedupe on
    ``subtype == "started"`` so we don't double-count the started/completed
    pair.
    """

    def build_command(self, prompt: str) -> list[str]:
        return [
            self.binary,
            "-p",
            prompt,
            "--output-format",
            "stream-json",
            "--approve-mcps",
            "--force",
            "--model",
            "auto",  # required on free plans (named models are gated)
        ]

    def extract_tool_calls(self, stdout_text: str) -> tuple[list[str], list[dict[str, Any]]]:
        names: list[str] = []
        inputs: list[dict[str, Any]] = []
        for obj in _iter_json_objects(stdout_text):
            if not (isinstance(obj, dict) and obj.get("type") == "tool_call"):
                continue
            if obj.get("subtype") != "started":  # dedupe started/completed pair
                continue
            mcp_call = (((obj.get("tool_call") or {}).get("mcpToolCall") or {}).get("args")) or {}
            tool_name = _normalize_tool_name(mcp_call.get("toolName") or mcp_call.get("name"))
            if not tool_name:
                continue
            args = mcp_call.get("args") if isinstance(mcp_call.get("args"), dict) else {}
            names.append(tool_name)
            inputs.append(args)
        return names, inputs


class DevinAdapter(HarnessAdapter):
    """Devin's local CLI.

    Devin's --print mode doesn't expose a structured (stream-json) output, so
    this adapter is **telemetry-only**: stdout is captured as plain text but
    no tool sequence is extracted from it. Scenario classifiers should fall
    back to the MCP-server telemetry log for the verdict. Scenarios that
    cannot be scored from telemetry alone will surface as "indeterminate".
    """

    telemetry_only: bool = True

    def build_command(self, prompt: str) -> list[str]:
        return [
            self.binary,
            "-p",
            prompt,
            "--permission-mode",
            "dangerous",
        ]

    def extract_tool_calls(self, stdout_text: str) -> tuple[list[str], list[dict[str, Any]]]:
        return [], []


ADAPTERS: dict[str, HarnessAdapter] = {
    "claude": ClaudeAdapter(
        name="claude",
        binary="claude",
        setup_hint=(
            "Claude wires the MCP server inline via --mcp-config; no setup needed beyond\n"
            "  • `claude` itself on PATH\n"
            "  • a logged-in Claude account (`claude /login` if needed)\n"
            "  • a logged-in pretorin (`pretorin login`)\n"
            "The runner injects the shim path into Claude's per-invocation MCP config."
        ),
    ),
    "codex": CodexAdapter(
        name="codex",
        binary="codex",
        setup_hint=(
            "Register the shim as the pretorin MCP server in Codex (one-time):\n"
            f"  codex mcp add pretorin -- {SHIM_PATH}\n"
            "Then confirm with `codex mcp list`."
        ),
    ),
    "agent": AgentAdapter(
        name="agent",
        binary="agent",
        setup_hint=(
            "Cursor's `agent` reads MCP servers from ~/.cursor/mcp.json. Add or merge:\n"
            "  {\n"
            '    "mcpServers": {\n'
            '      "pretorin": {\n'
            f'        "command": "{SHIM_PATH}"\n'
            "      }\n"
            "    }\n"
            "  }\n"
            "Then run `agent mcp list-tools pretorin` to confirm the server starts."
        ),
    ),
    "devin": DevinAdapter(
        name="devin",
        binary="devin",
        setup_hint=(
            "Register the shim as the pretorin MCP server in Devin (one-time):\n"
            f"  devin mcp add --name pretorin --command {SHIM_PATH}\n"
            "(Run `devin mcp add --help` if the flag names changed.) "
            "Then confirm with `devin mcp list`."
        ),
    ),
}


# ---------------------------------------------------------------------------
# JSON-stream helpers
# ---------------------------------------------------------------------------


def _iter_json_objects(text: str) -> Iterable[Any]:
    """Yield every top-level JSON object found across the stream.

    Tolerates both NDJSON (one object per line) and concatenated bare objects.
    Lines that fail to parse are skipped silently — log noise is not data.
    """
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            continue


# Harnesses prefix MCP tool names differently:
#   • Anthropic / claude   → ``mcp__pretorin__check_context``
#   • Cursor / agent       → ``pretorin-check_context``
#   • Codex                → bare ``check_context`` (server is a sibling field)
_MCP_PREFIXES = ("mcp__pretorin__", "pretorin-")


def _normalize_tool_name(name: str) -> str | None:
    """Strip MCP namespacing and return the bare pretorin tool name, or None."""
    if not isinstance(name, str):
        return None
    for prefix in _MCP_PREFIXES:
        if name.startswith(prefix):
            candidate = name[len(prefix) :]
            return candidate if candidate in PRETORIN_TOOLS else None
    if name in PRETORIN_TOOLS:
        return name
    return None


def _walk_tool_calls(obj: Any) -> Iterable[tuple[str, dict[str, Any]]]:
    """Heuristically extract (tool_name, tool_input) pairs from a JSON object.

    Matches the shapes we've seen in the wild:
      • Anthropic-style:
        ``{"type": "tool_use", "name": "mcp__pretorin__check_context", "input": {...}}``
      • Codex-style:
        ``{"type": "mcp_tool_call", "server": "pretorin", "tool": "...", "arguments": {...}}``
      • Generic: any object with a ``name`` (str) AND an
        ``input``/``arguments``/``parameters`` (dict) sibling.

    Codex emits both ``item.started`` and ``item.completed`` events for each
    call; we dedupe at the caller by only counting "completed" events when
    a status field is present.
    """
    if isinstance(obj, dict):
        # Codex-style mcp_tool_call shape
        if obj.get("type") == "mcp_tool_call" and obj.get("server") == "pretorin":
            normalized = _normalize_tool_name(obj.get("tool"))
            args = obj.get("arguments") if isinstance(obj.get("arguments"), dict) else {}
            status = obj.get("status")
            # Only emit on "completed"-style terminal events so we don't double-count
            # the started/completed pair. "failed" still counts as a call attempt.
            if normalized and status in (None, "completed", "failed", "succeeded"):
                yield normalized, args
        # Anthropic-style tool_use OR any generic name-bearing dict
        raw_name = obj.get("name")
        if isinstance(raw_name, str):
            normalized = _normalize_tool_name(raw_name)
            if normalized:
                for key in ("input", "arguments", "parameters"):
                    value = obj.get(key)
                    if isinstance(value, dict):
                        yield normalized, value
                        break
                else:
                    yield normalized, {}
        for value in obj.values():
            yield from _walk_tool_calls(value)
    elif isinstance(obj, list):
        for item in obj:
            yield from _walk_tool_calls(item)


def _parse_telemetry_lines(stderr_text: str) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for raw in stderr_text.splitlines():
        line = raw.strip()
        if not line.startswith("PRETORIN_TELEMETRY_EVENT"):
            continue
        payload = line.removeprefix("PRETORIN_TELEMETRY_EVENT").strip()
        try:
            events.append(json.loads(payload))
        except json.JSONDecodeError:
            continue
    return events


# ---------------------------------------------------------------------------
# Precondition handling
# ---------------------------------------------------------------------------


@dataclass
class GroundedContext:
    """Captured (system_id, framework_id) so we can re-apply between scenarios."""

    system_id: str
    framework_id: str


_GROUNDED: GroundedContext | None = None


def capture_grounded_context() -> GroundedContext:
    """Read the active context once at run start so later scenarios can restore it.

    Pretorin stores context in ``~/.pretorin/config.json`` as
    ``active_system_id`` / ``active_framework_id`` — we read that directly so we
    don't depend on a CLI flag that may not exist on older builds.
    """
    config_path = Path.home() / ".pretorin" / "config.json"
    if not config_path.exists():
        raise RuntimeError(f"pretorin config not found at {config_path}; run `pretorin login` first.")
    data = json.loads(config_path.read_text())
    system_id = data.get("active_system_id")
    framework_id = data.get("active_framework_id")
    if not system_id or not framework_id:
        raise RuntimeError(
            "Scenario requires a grounded context. Run `pretorin context set` to pick a system+framework first."
        )
    return GroundedContext(system_id=system_id, framework_id=framework_id)


def apply_precondition(kind: str) -> None:
    global _GROUNDED
    if kind == "any":
        return
    if kind == "cleared":
        subprocess.run(["pretorin", "context", "clear"], capture_output=True, text=True, check=False)
        return
    if kind == "grounded":
        if _GROUNDED is None:
            _GROUNDED = capture_grounded_context()
        subprocess.run(
            [
                "pretorin",
                "context",
                "set",
                "--system",
                _GROUNDED.system_id,
                "--framework",
                _GROUNDED.framework_id,
                "--no-verify",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        return
    raise ValueError(f"unknown precondition: {kind}")


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


@dataclass
class RunResult:
    harness: str
    scenario_id: str
    verdict: str
    reason: str
    tool_sequence: list[str] = field(default_factory=list)
    telemetry_kinds: list[str] = field(default_factory=list)
    duration_seconds: float = 0.0
    error: str | None = None


def run_one(adapter: HarnessAdapter, scenario: Scenario, log_dir: Path, timeout: int) -> RunResult:
    log_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{adapter.name}-{scenario.id}"
    stdout_path = log_dir / f"{stem}.stdout"
    stderr_path = log_dir / f"{stem}.stderr"
    mcp_log_path = log_dir / f"{stem}.mcp.log"

    try:
        apply_precondition(scenario.precondition)
    except RuntimeError as e:
        return RunResult(
            harness=adapter.name,
            scenario_id=scenario.id,
            verdict="error",
            reason=str(e),
            error=str(e),
        )

    env = os.environ.copy()
    env.update(adapter.env())
    env["PRETORIN_SMOKE_SESSION_LOG"] = str(mcp_log_path)
    # Truncate the MCP log so we don't pick up events from a prior run.
    mcp_log_path.write_text("")

    cmd = adapter.build_command(scenario.prompt)
    started = time.monotonic()
    try:
        completed = subprocess.run(
            cmd,
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as e:
        stdout_path.write_text(e.stdout.decode("utf-8", errors="replace") if e.stdout else "")
        stderr_path.write_text(e.stderr.decode("utf-8", errors="replace") if e.stderr else "")
        return RunResult(
            harness=adapter.name,
            scenario_id=scenario.id,
            verdict="error",
            reason=f"timeout after {timeout}s",
            duration_seconds=time.monotonic() - started,
            error="timeout",
        )
    except FileNotFoundError:
        return RunResult(
            harness=adapter.name,
            scenario_id=scenario.id,
            verdict="error",
            reason=f"binary `{adapter.binary}` not found on PATH",
            error="missing_binary",
        )

    duration = time.monotonic() - started
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)

    if completed.returncode != 0:
        return RunResult(
            harness=adapter.name,
            scenario_id=scenario.id,
            verdict="error",
            reason=f"harness exited {completed.returncode}; see {stderr_path}",
            duration_seconds=duration,
            error=f"exit_{completed.returncode}",
        )

    names, inputs = adapter.extract_tool_calls(completed.stdout)
    mcp_stderr = mcp_log_path.read_text(encoding="utf-8", errors="replace")
    telemetry = _parse_telemetry_lines(mcp_stderr)

    ctx = ScenarioContext(
        tool_sequence=names,
        tool_inputs=inputs,
        telemetry_events=telemetry,
        stdout_text=completed.stdout,
        stderr_text=completed.stderr,
    )
    classification = scenario.classifier(ctx)
    return RunResult(
        harness=adapter.name,
        scenario_id=scenario.id,
        verdict=classification.verdict,
        reason=classification.reason,
        tool_sequence=names,
        telemetry_kinds=[e.get("event_type", "?") for e in telemetry],
        duration_seconds=duration,
    )


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


VERDICT_SYMBOL = {
    "pass": "✅ pass",
    "soft": "🟡 soft",
    "fail": "❌ fail",
    "error": "⚠️ error",
}


def render_table(results: list[RunResult], harnesses: list[str]) -> str:
    by_harness: dict[str, dict[str, RunResult]] = {h: {} for h in harnesses}
    for r in results:
        by_harness.setdefault(r.harness, {})[r.scenario_id] = r

    cols = ["Scenario", *harnesses]
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for s in SCENARIOS:
        row = [s.id]
        for h in harnesses:
            r = by_harness.get(h, {}).get(s.id)
            if r is None:
                row.append("—")
            else:
                cell = VERDICT_SYMBOL.get(r.verdict, r.verdict)
                if r.verdict in {"fail", "soft", "error"} and r.reason:
                    cell = f"{cell}<br/><sub>{r.reason}</sub>"
                elif r.tool_sequence:
                    head = " → ".join(r.tool_sequence[:6])
                    suffix = "…" if len(r.tool_sequence) > 6 else ""
                    cell = f"{cell}<br/><sub>{head}{suffix}</sub>"
                row.append(cell)
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def write_results_yaml(path: Path, results: list[RunResult]) -> None:
    # Hand-rolled YAML so we don't introduce a pyyaml dependency.
    lines = ["results:"]
    for r in results:
        lines.append(f"  - harness: {r.harness}")
        lines.append(f"    scenario: {r.scenario_id}")
        lines.append(f"    verdict: {r.verdict}")
        lines.append(f"    reason: {json.dumps(r.reason)}")
        lines.append(f"    duration_seconds: {r.duration_seconds:.2f}")
        lines.append(f"    tool_sequence: {json.dumps(r.tool_sequence)}")
        lines.append(f"    telemetry_kinds: {json.dumps(r.telemetry_kinds)}")
        if r.error:
            lines.append(f"    error: {r.error}")
    path.write_text("\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def cmd_setup() -> int:
    print("Cross-harness smoke test setup\n")
    print(f"Shim path: {SHIM_PATH}")
    if not SHIM_PATH.exists():
        print("  ❌ shim missing — check the file is present and chmod +x")
        return 1
    if not os.access(SHIM_PATH, os.X_OK):
        print(f"  ❌ shim not executable — run `chmod +x {SHIM_PATH}`")
        return 1
    print("  ✅ shim present and executable\n")

    for name, adapter in ADAPTERS.items():
        installed = adapter.is_installed()
        marker = "✅" if installed else "❌"
        print(f"{marker} {name} ({adapter.binary} → {shutil.which(adapter.binary) or 'NOT INSTALLED'})")
        if installed:
            print("    setup steps:")
            for line in adapter.setup_hint.splitlines():
                print(f"      {line}")
        print()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--setup", action="store_true", help="Print per-harness MCP setup commands and exit.")
    parser.add_argument(
        "--harness",
        action="append",
        choices=sorted(ADAPTERS),
        help="Harness to run (repeatable). Default: all installed.",
    )
    parser.add_argument(
        "--scenario",
        action="append",
        choices=[s.id for s in SCENARIOS],
        help="Scenario to run (repeatable). Default: all.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=DEFAULT_TIMEOUT_SECONDS,
        help=f"Per-scenario timeout in seconds (default {DEFAULT_TIMEOUT_SECONDS}).",
    )
    parser.add_argument("--yes", action="store_true", help="Skip the run-plan confirmation prompt.")
    args = parser.parse_args()

    if args.setup:
        return cmd_setup()

    selected_harnesses = args.harness or [name for name, adapter in ADAPTERS.items() if adapter.is_installed()]
    selected_scenarios = [s for s in SCENARIOS if not args.scenario or s.id in args.scenario]

    if not selected_harnesses:
        print("No harnesses installed. Run with --setup for guidance.", file=sys.stderr)
        return 1

    run_id = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%SZ")
    log_dir = LOG_ROOT / run_id
    log_dir.mkdir(parents=True, exist_ok=True)

    trial_count = len(selected_harnesses) * len(selected_scenarios)
    print(f"Run id:   {run_id}")
    print(f"Log dir:  {log_dir}")
    print(f"Plan:     {len(selected_harnesses)} harnesses × {len(selected_scenarios)} scenarios = {trial_count} trials")
    print(f"Harness:  {', '.join(selected_harnesses)}")
    print(f"Scenarios: {', '.join(s.id for s in selected_scenarios)}\n")

    if not args.yes:
        try:
            confirm = input("Proceed? [y/N] ").strip().lower()
        except EOFError:
            confirm = ""
        if confirm not in {"y", "yes"}:
            print("Aborted.")
            return 0

    # Capture the user's grounded context up front so we (a) can re-apply it
    # for "grounded" preconditions between scenarios and (b) can restore it at
    # the end of the run no matter what happens.
    needs_grounded = any(s.precondition == "grounded" for s in selected_scenarios)
    grounded: GroundedContext | None = None
    if needs_grounded:
        try:
            grounded = capture_grounded_context()
            global _GROUNDED
            _GROUNDED = grounded
            print(f"Captured grounded context: system={grounded.system_id} framework={grounded.framework_id}\n")
        except RuntimeError as e:
            print(f"⚠️  {e}", file=sys.stderr)
            return 1

    try:
        results: list[RunResult] = []
        for harness_name in selected_harnesses:
            adapter = ADAPTERS[harness_name]
            for scenario in selected_scenarios:
                print(f"→ {harness_name} / {scenario.id} ({scenario.title}) …", flush=True)
                result = run_one(adapter, scenario, log_dir, timeout=args.timeout)
                results.append(result)
                marker = VERDICT_SYMBOL.get(result.verdict, result.verdict)
                print(f"  {marker} — {result.reason}\n")
    finally:
        # Always restore the user's grounded context so their session survives.
        if grounded is not None:
            subprocess.run(
                [
                    "pretorin",
                    "context",
                    "set",
                    "--system",
                    grounded.system_id,
                    "--framework",
                    grounded.framework_id,
                    "--no-verify",
                ],
                capture_output=True,
                text=True,
                check=False,
            )

    write_results_yaml(log_dir / "results.yaml", results)

    print("\n=== Comparison table (paste into issue #121) ===\n")
    print(render_table(results, selected_harnesses))
    print()
    print(f"Logs + YAML: {log_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
