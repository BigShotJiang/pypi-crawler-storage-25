"""
ViperClient — HTTP client for the Viper PQ Chain node API.

Covers all read endpoints defined in API.md and the transaction submission
endpoint (POST /v1/txs). Uses only the Python standard library (``urllib``);
no third-party dependencies required.

Requires Python 3.9+.

Example::

    from viper_pqchain import ViperClient

    client = ViperClient("http://localhost:9000")
    status = client.get_status()
    print(status.height, status.tip_hash)
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Optional
from urllib.request import Request

from .fee import FeeCalculator
from .types import (
    Account,
    Attestation,
    Block,
    BlockHeader,
    ChainStatus,
    GovernanceParameters,
    KeyEntry,
    MultiDimFee,
    SubmitTxResponse,
    Transaction,
    Validator,
    ViperError,
)


def _parse_chain_status(d: dict[str, Any]) -> ChainStatus:
    return ChainStatus(
        height=d["height"],
        tip_hash=d["tip_hash"],
        state_root=d["state_root"],
        timestamp_ms=d["timestamp_ms"],
        node_version=d.get("node_version", ""),
        chain_id=d.get("chain_id", ""),
    )


def _parse_transaction(d: dict[str, Any]) -> Transaction:
    return Transaction(
        tx_hash=d["tx_hash"],
        sender=d["sender"],
        nonce=d["nonce"],
        op_type=d["op_type"],
        op_payload=d.get("op_payload", ""),
        fee_venom=d.get("fee_venom", "0"),
        signature=d.get("signature", ""),
        alg_id=d.get("alg_id", ""),
    )


def _parse_block_header(d: dict[str, Any]) -> BlockHeader:
    # ADR-053 §T1.1 (TASK-205) — surface ``header_version``, ``timestamp_ns``,
    # and ``extension_root`` when the server provides them. All three are
    # absent on pre-ADR-053 server responses; the dataclass treats them as
    # ``None``-defaulted optional fields.
    return BlockHeader(
        height=d["height"],
        prev_hash=d["prev_hash"],
        state_root=d["state_root"],
        timestamp_ms=d.get("timestamp_ms", 0),
        proposer_address=d.get("proposer_address", ""),
        tx_count=d.get("tx_count", 0),
        header_version=d.get("header_version"),
        timestamp_ns=d.get("timestamp_ns") or d.get("timestamp"),
        extension_root=d.get("extension_root"),
    )


def _parse_block(d: dict[str, Any]) -> Block:
    return Block(
        hash=d["hash"],
        header=_parse_block_header(d["header"]),
        transactions=[_parse_transaction(t) for t in d.get("transactions", [])],
    )


def _parse_key_entry(d: dict[str, Any]) -> KeyEntry:
    return KeyEntry(
        key_version=d["key_version"],
        alg_id=d["alg_id"],
        public_key=d["public_key"],
        added_at_height=d["added_at_height"],
        revoked_at_height=d.get("revoked_at_height"),
    )


def _parse_account(d: dict[str, Any]) -> Account:
    # ADR-053 §T3.5 (TASK-205) — surface ``verifier_template_id`` and
    # ``auth_data``. Pre-ADR-053 servers omit both; defaults to ``None``.
    return Account(
        address=d["address"],
        balance_venom=d["balance_venom"],
        nonce=d["nonce"],
        keys=[_parse_key_entry(k) for k in d.get("keys", [])],
        verifier_template_id=d.get("verifier_template_id"),
        auth_data=d.get("auth_data"),
    )


def _parse_attestation(d: dict[str, Any]) -> Attestation:
    return Attestation(
        attestation_id=d["attestation_id"],
        issuer=d["issuer"],
        subject=d["subject"],
        schema_id=d["schema_id"],
        payload_hash=d["payload_hash"],
        issued_at_height=d["issued_at_height"],
        revoked_at_height=d.get("revoked_at_height"),
    )


def _parse_validator(d: dict[str, Any]) -> Validator:
    return Validator(
        address=d["address"],
        consensus_pk=d["consensus_pk"],
        consensus_alg=d["consensus_alg"],
        stake_venom=d["stake_venom"],
        status=d["status"],
        registered_at_height=d["registered_at_height"],
        jailed_at_height=d.get("jailed_at_height"),
    )


def _parse_multi_dim_fee(d: Optional[dict[str, Any]]) -> Optional[MultiDimFee]:
    # ADR-053 §T2.1 (TASK-201) — multi-dimensional fee market shape.
    if not d:
        return None
    return MultiDimFee(
        compute_base_fee_venom=d["compute_base_fee_venom"],
        storage_base_fee_venom=d["storage_base_fee_venom"],
        witness_base_fee_venom=d["witness_base_fee_venom"],
        contention_base_fee_venom=d["contention_base_fee_venom"],
    )


def _parse_governance(d: dict[str, Any]) -> GovernanceParameters:
    return GovernanceParameters(
        base_fee_venom=d["base_fee_venom"],
        byte_fee_venom=d["byte_fee_venom"],
        sigverify_fee_venom=d["sigverify_fee_venom"],
        min_stake_venom=d["min_stake_venom"],
        unbonding_period_blocks=d["unbonding_period_blocks"],
        slash_double_sign=d["slash_double_sign"],
        slash_liveness=d["slash_liveness"],
        slash_downtime_exit=d["slash_downtime_exit"],
        # ADR-053 §T2.1 / §T2.2 — optional multi-dim fee + storage fund.
        multi_dim_fee=_parse_multi_dim_fee(d.get("multi_dim_fee")),
        storage_perpetual_cost_per_byte_venom=d.get(
            "storage_perpetual_cost_per_byte_venom"
        ),
    )


class ViperClient:
    """
    HTTP client for the Viper PQ Chain node API.

    :param base_url: Base URL of the pqcd node, e.g. ``"http://localhost:9000"``.
                     Trailing slashes are stripped automatically.
    :param timeout: Request timeout in seconds. Default: 10.
    """

    def __init__(self, base_url: str, timeout: float = 10.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    # -------------------------------------------------------------------------
    # Chain status
    # -------------------------------------------------------------------------

    def get_status(self) -> ChainStatus:
        """GET /v1/status — current chain height, tip hash, and state root."""
        return _parse_chain_status(self._get("/v1/status"))

    # -------------------------------------------------------------------------
    # Blocks
    # -------------------------------------------------------------------------

    def get_block(self, height: int) -> Block:
        """GET /v1/blocks/:height — fetch a block by height."""
        return _parse_block(self._get(f"/v1/blocks/{height}"))

    def get_block_by_hash(self, block_hash: str) -> Block:
        """GET /v1/blocks/:hash — fetch a block by hash (hex)."""
        return _parse_block(self._get(f"/v1/blocks/{block_hash}"))

    # -------------------------------------------------------------------------
    # Transactions
    # -------------------------------------------------------------------------

    def get_transaction(self, tx_hash: str) -> Transaction:
        """GET /v1/txs/:tx_hash — fetch a transaction by hash."""
        return _parse_transaction(self._get(f"/v1/txs/{tx_hash}"))

    def submit_tx(self, cbor_hex: str) -> SubmitTxResponse:
        """
        POST /v1/txs — submit a signed transaction.

        :param cbor_hex: CBOR-encoded signed transaction as a hex string.
                         Produce this with ``pqcd sign-tx`` after building an
                         unsigned tx with the builders in ``viper_pqchain.tx``.
        """
        d = self._post("/v1/txs", {"tx_cbor_hex": cbor_hex})
        return SubmitTxResponse(
            tx_hash=d["tx_hash"],
            status=d["status"],
            error=d.get("error"),
        )

    # -------------------------------------------------------------------------
    # Accounts
    # -------------------------------------------------------------------------

    def get_account(self, address: str) -> Account:
        """GET /v1/accounts/:address — fetch account state including keys."""
        return _parse_account(self._get(f"/v1/accounts/{address}"))

    # -------------------------------------------------------------------------
    # Attestations
    # -------------------------------------------------------------------------

    def get_attestation(self, attestation_id: str) -> Attestation:
        """GET /v1/attestations/:attestation_id — fetch an attestation record."""
        return _parse_attestation(self._get(f"/v1/attestations/{attestation_id}"))

    def get_account_attestations(self, address: str) -> list[Attestation]:
        """
        GET /v1/accounts/:address/attestations — list attestations issued by
        or targeting this address.
        """
        raw = self._get(f"/v1/accounts/{address}/attestations")
        return [_parse_attestation(a) for a in raw]

    # -------------------------------------------------------------------------
    # Validators
    # -------------------------------------------------------------------------

    def get_validators(self) -> list[Validator]:
        """GET /v1/validators — list all validators in the active set."""
        raw = self._get("/v1/validators")
        return [_parse_validator(v) for v in raw]

    def get_validator(self, address: str) -> Validator:
        """GET /v1/validators/:address — fetch a single validator."""
        return _parse_validator(self._get(f"/v1/validators/{address}"))

    # -------------------------------------------------------------------------
    # Governance
    # -------------------------------------------------------------------------

    def get_governance_parameters(self) -> GovernanceParameters:
        """GET /v1/governance/parameters — fetch current on-chain governance params."""
        return _parse_governance(self._get("/v1/governance/parameters"))

    # -------------------------------------------------------------------------
    # Fee estimation
    # -------------------------------------------------------------------------

    def get_fee_calculator(self) -> FeeCalculator:
        """
        Fetch current governance parameters and return a :class:`FeeCalculator`.

        The calculator is a snapshot — call again if you need fresh values.
        """
        params = self.get_governance_parameters()
        return FeeCalculator(params)

    # -------------------------------------------------------------------------
    # Internal HTTP helpers
    # -------------------------------------------------------------------------

    def _get(self, path: str) -> Any:
        url = f"{self._base_url}{path}"
        req = Request(url, headers={"Accept": "application/json"}, method="GET")
        return self._execute(req, url)

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        url = f"{self._base_url}{path}"
        data = json.dumps(body).encode()
        req = Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST",
        )
        return self._execute(req, url)

    def _execute(self, req: Request, url: str) -> Any:
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                body = resp.read().decode()
        except urllib.error.HTTPError as exc:
            body = exc.read().decode()
            code: Optional[str] = None
            try:
                code = json.loads(body).get("code")
            except Exception:
                pass
            raise ViperError(
                f"HTTP {exc.code} from {url}: {body}",
                status_code=exc.code,
                code=code,
            ) from exc
        except urllib.error.URLError as exc:
            raise ViperError(
                f"Network error reaching {url}: {exc.reason}",
            ) from exc

        try:
            return json.loads(body)
        except json.JSONDecodeError as exc:
            raise ViperError(
                f"Failed to parse JSON response from {url}: {body[:200]}",
                code="PARSE_ERROR",
            ) from exc
