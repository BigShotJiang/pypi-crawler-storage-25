"""CrewAI adapter — automatic agent span instrumentation via OTel.

This adapter leverages the ``opentelemetry-instrumentation-crewai`` package
(maintained by the Traceloop/OpenLLMetry community) to emit standard OTel
spans for every CrewAI agent, task, and tool execution. SpyLLM's OTLP
endpoint then maps ``gen_ai.*`` attributes into the SpyLLM schema.

Usage::

    import spyllm
    spyllm.init(api_key="sk-...")
    spyllm.adapters.instrument_crewai()

    # All CrewAI agent/task/tool spans are now auto-captured.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger("spyllm.adapters.crewai")


def instrument_crewai(
    *,
    api_key: Optional[str] = None,
    endpoint: Optional[str] = None,
    service_name: str = "crewai",
) -> None:
    """Instrument CrewAI with SpyLLM via OTel.

    Requires ``opentelemetry-instrumentation-crewai`` to be installed.
    If not available, falls back to a lightweight monkey-patch.
    """
    from .. import _client
    from ..otel import init_otel

    key = api_key or (_client.api_key if _client else None)
    if not key:
        raise RuntimeError(
            "SpyLLM must be initialised before calling instrument_crewai()"
        )

    base = endpoint or (_client.base_url if _client else "https://api.spyllm.dev")

    try:
        from opentelemetry.instrumentation.crewai import CrewAIInstrumentor

        provider = init_otel(api_key=key, endpoint=base, service_name=service_name)
        CrewAIInstrumentor().instrument(tracer_provider=provider)
        logger.info("CrewAI instrumented via opentelemetry-instrumentation-crewai")
    except ImportError:
        logger.info(
            "opentelemetry-instrumentation-crewai not installed; "
            "using lightweight fallback patch"
        )
        _patch_crewai_fallback()


def _patch_crewai_fallback() -> None:
    """Lightweight monkey-patch for CrewAI when OTel instrumentation is unavailable."""
    try:
        from crewai import Agent  # type: ignore[import-untyped]
    except ImportError:
        logger.warning("crewai package not installed — skipping instrumentation")
        return

    from ..context import agent_span

    if getattr(Agent, "_spyllm_patched", False):
        return

    original_execute = getattr(Agent, "execute_task", None)
    if original_execute is None:
        logger.debug("Agent.execute_task not found — skipping patch")
        return

    def patched_execute(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        name = getattr(self, "role", None) or getattr(self, "name", "crewai-agent")
        with agent_span(str(name), role=str(name), framework="crewai"):
            return original_execute(self, *args, **kwargs)

    Agent.execute_task = patched_execute
    Agent._spyllm_patched = True  # type: ignore[attr-defined]
    logger.info("CrewAI Agent.execute_task patched for SpyLLM tracing")
