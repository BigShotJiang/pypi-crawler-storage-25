"""Framework adapters for automatic agent span instrumentation."""

from __future__ import annotations


def instrument_crewai(**kwargs) -> None:  # type: ignore[no-untyped-def]
    """Convenience shortcut for :func:`crewai.instrument_crewai`."""
    from .crewai import instrument_crewai as _impl

    _impl(**kwargs)


__all__ = ["instrument_crewai"]
