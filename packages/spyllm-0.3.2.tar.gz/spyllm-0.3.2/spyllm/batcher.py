"""Background trace batcher.

Collects traces in a thread-safe queue and flushes them to the SpyLLM API in
a daemon thread so instrumented calls never block on network I/O.
"""

from __future__ import annotations

import atexit
import logging
import queue
import threading
from typing import Any

import httpx

logger = logging.getLogger("spyllm")

_MAX_BATCH = 50
_FLUSH_INTERVAL = 2.0  # seconds


class TraceBatcher:
    def __init__(self, api_key: str, base_url: str) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._queue: queue.Queue[dict[str, Any]] = queue.Queue()
        self._shutdown = threading.Event()
        self._http = httpx.Client(
            timeout=10.0,
            headers={"X-API-Key": self._api_key},
            limits=httpx.Limits(max_connections=10, max_keepalive_connections=5),
        )
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        atexit.register(self.flush)

    def enqueue(self, trace: dict[str, Any]) -> None:
        self._queue.put(trace)

    def flush(self) -> None:
        """Drain the queue and send everything. Called at exit or manually."""
        batch: list[dict[str, Any]] = []
        while True:
            try:
                batch.append(self._queue.get_nowait())
            except queue.Empty:
                break
        if batch:
            self._send(batch)

    def shutdown(self) -> None:
        self._shutdown.set()
        self.flush()
        self._http.close()

    def _run(self) -> None:
        while not self._shutdown.is_set():
            batch: list[dict[str, Any]] = []
            try:
                batch.append(self._queue.get(timeout=_FLUSH_INTERVAL))
            except queue.Empty:
                continue

            while len(batch) < _MAX_BATCH:
                try:
                    batch.append(self._queue.get_nowait())
                except queue.Empty:
                    break

            self._send(batch)

    def _send(self, batch: list[dict[str, Any]]) -> None:
        if not batch:
            return
        try:
            if len(batch) == 1:
                self._http.post(f"{self._base_url}/v1/traces", json=batch[0])
            else:
                self._http.post(f"{self._base_url}/v1/traces/batch", json=batch)
        except Exception:
            logger.debug("spyllm: failed to send %d traces", len(batch), exc_info=True)
