"""Auto-instrumentation for OpenAI and Anthropic Python SDKs.

When `patch_openai()` or `patch_anthropic()` is called, the respective SDK's
`create` methods are monkey-patched via `wrapt` so every LLM call is
automatically traced — zero code changes required for the end user.
"""

from __future__ import annotations

import json
import logging
import time
import types
from dataclasses import dataclass
from typing import Any, Optional

from wrapt import wrap_function_wrapper

from .context import _current_span, _new_id
from .pricing import estimate_cost

logger = logging.getLogger("spyllm")

# Will be set by `init()` in __init__.py
_batcher: Any = None


@dataclass
class _PatchTarget:
    module: str
    cls: str
    method: str
    provider: str
    is_async: bool


# ---------------------------------------------------------------------------
# OpenAI targets
# ---------------------------------------------------------------------------

_OPENAI_TARGETS: list[_PatchTarget] = [
    _PatchTarget(
        "openai.resources.chat.completions", "Completions", "create", "openai", False
    ),
    _PatchTarget(
        "openai.resources.chat.completions",
        "AsyncCompletions",
        "create",
        "openai",
        True,
    ),
    _PatchTarget(
        "openai.resources.completions", "Completions", "create", "openai", False
    ),
    _PatchTarget(
        "openai.resources.completions", "AsyncCompletions", "create", "openai", True
    ),
]

# ---------------------------------------------------------------------------
# Anthropic targets
# ---------------------------------------------------------------------------

_ANTHROPIC_TARGETS: list[_PatchTarget] = [
    _PatchTarget(
        "anthropic.resources.messages", "Messages", "create", "anthropic", False
    ),
    _PatchTarget(
        "anthropic.resources.messages", "AsyncMessages", "create", "anthropic", True
    ),
]


# ---------------------------------------------------------------------------
# Extraction helpers
# ---------------------------------------------------------------------------


def _safe_json(obj: Any) -> str:
    try:
        return json.dumps(obj, default=str)
    except Exception:
        return str(obj)


def _extract_openai_data(kwargs: dict[str, Any], response: Any) -> dict[str, Any]:
    """Pull trace fields from an OpenAI chat/completion response."""
    usage = getattr(response, "usage", None)

    model = getattr(response, "model", None) or kwargs.get("model", "unknown")
    input_tokens = getattr(usage, "prompt_tokens", 0) or 0
    output_tokens = getattr(usage, "completion_tokens", 0) or 0

    messages = kwargs.get("messages", [])
    prompt_str = _safe_json(messages) if messages else kwargs.get("prompt", "")

    choices = getattr(response, "choices", [])
    response_text = ""
    tool_calls_data = None
    if choices:
        choice = choices[0]
        msg = getattr(choice, "message", None)
        if msg:
            response_text = getattr(msg, "content", "") or ""
            tc = getattr(msg, "tool_calls", None)
            if tc:
                tool_calls_data = _safe_json(
                    [t.__dict__ for t in tc] if hasattr(tc[0], "__dict__") else tc
                )
        elif hasattr(choice, "text"):
            response_text = getattr(choice, "text", "")

    cost = estimate_cost(model, input_tokens, output_tokens)

    return {
        "agent_name": model,
        "prompt": prompt_str if isinstance(prompt_str, str) else _safe_json(prompt_str),
        "response": response_text,
        "trace_type": "llm_call",
        "status": "success",
        "token_count": input_tokens + output_tokens,
        "cost_usd": cost,
        "tool_calls": tool_calls_data,
        "metadata": _safe_json(
            {
                "provider": "openai",
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            }
        ),
    }


def _extract_anthropic_data(kwargs: dict[str, Any], response: Any) -> dict[str, Any]:
    """Pull trace fields from an Anthropic messages response."""
    model = getattr(response, "model", None) or kwargs.get("model", "unknown")
    usage = getattr(response, "usage", None)
    input_tokens = getattr(usage, "input_tokens", 0) or 0
    output_tokens = getattr(usage, "output_tokens", 0) or 0

    messages = kwargs.get("messages", [])
    system = kwargs.get("system", "")
    prompt_parts = []
    if system:
        prompt_parts.append({"role": "system", "content": system})
    prompt_parts.extend(messages)
    prompt_str = _safe_json(prompt_parts)

    content_blocks = getattr(response, "content", [])
    response_text = ""
    tool_calls_data = None
    tool_uses = []
    for block in content_blocks:
        block_type = getattr(block, "type", "")
        if block_type == "text":
            response_text += getattr(block, "text", "")
        elif block_type == "tool_use":
            tool_uses.append(
                {
                    "id": getattr(block, "id", ""),
                    "name": getattr(block, "name", ""),
                    "input": getattr(block, "input", {}),
                }
            )
    if tool_uses:
        tool_calls_data = _safe_json(tool_uses)

    cost = estimate_cost(model, input_tokens, output_tokens)

    return {
        "agent_name": model,
        "prompt": prompt_str,
        "response": response_text,
        "trace_type": "llm_call",
        "status": "success",
        "token_count": input_tokens + output_tokens,
        "cost_usd": cost,
        "tool_calls": tool_calls_data,
        "metadata": _safe_json(
            {
                "provider": "anthropic",
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            }
        ),
    }


# ---------------------------------------------------------------------------
# Span context attachment
# ---------------------------------------------------------------------------


def _attach_span_context(trace: dict[str, Any]) -> None:
    """If an agent span is active, stamp its IDs onto the LLM call trace."""
    ctx = _current_span.get()
    if ctx is None:
        return
    trace["trace_id"] = ctx.trace_id
    trace["span_id"] = _new_id()
    trace["parent_span_id"] = ctx.span_id
    trace["agent_role"] = ctx.agent_name
    trace["operation_name"] = "chat"
    if ctx.framework:
        trace["framework"] = ctx.framework


# ---------------------------------------------------------------------------
# Streaming wrappers
# ---------------------------------------------------------------------------


class _OpenAIStreamProxy:
    """Wraps an OpenAI sync Stream to capture chunks, then sends the trace
    when the stream is exhausted."""

    def __init__(self, stream: Any, kwargs: dict[str, Any], start_time: float) -> None:
        self._stream = stream
        self._kwargs = kwargs
        self._start_time = start_time
        self._chunks: list[Any] = []

    def __iter__(self) -> Any:
        try:
            for chunk in self._stream:
                self._chunks.append(chunk)
                yield chunk
        finally:
            self._finalize()

    def __next__(self) -> Any:
        try:
            chunk = next(self._stream)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._finalize()
            raise

    def __enter__(self) -> "_OpenAIStreamProxy":
        return self

    def __exit__(self, *args: Any) -> None:
        self._finalize()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _finalize(self) -> None:
        if not self._chunks or _batcher is None:
            return
        latency_ms = (time.time() - self._start_time) * 1000
        model, content, usage, tool_calls = _reassemble_openai_stream(self._chunks)
        input_tokens = 0
        output_tokens = 0
        if usage:
            input_tokens = getattr(usage, "prompt_tokens", 0) or 0
            output_tokens = getattr(usage, "completion_tokens", 0) or 0

        cost = estimate_cost(
            model or self._kwargs.get("model", "unknown"), input_tokens, output_tokens
        )
        messages = self._kwargs.get("messages", [])
        trace = {
            "agent_name": model or self._kwargs.get("model", "unknown"),
            "prompt": _safe_json(messages),
            "response": content or "",
            "trace_type": "llm_call",
            "status": "success",
            "latency_ms": latency_ms,
            "token_count": input_tokens + output_tokens,
            "cost_usd": cost,
            "tool_calls": _safe_json(tool_calls) if tool_calls else None,
            "metadata": _safe_json(
                {"provider": "openai", "model": model, "streamed": True}
            ),
        }
        _attach_span_context(trace)
        _batcher.enqueue({k: v for k, v in trace.items() if v is not None})
        self._chunks = []


class _OpenAIAsyncStreamProxy:
    """Async variant of the stream proxy."""

    def __init__(self, stream: Any, kwargs: dict[str, Any], start_time: float) -> None:
        self._stream = stream
        self._kwargs = kwargs
        self._start_time = start_time
        self._chunks: list[Any] = []

    async def __aiter__(self) -> Any:
        try:
            async for chunk in self._stream:
                self._chunks.append(chunk)
                yield chunk
        finally:
            self._finalize()

    async def __anext__(self) -> Any:
        try:
            chunk = await self._stream.__anext__()
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            self._finalize()
            raise

    async def __aenter__(self) -> "_OpenAIAsyncStreamProxy":
        return self

    async def __aexit__(self, *args: Any) -> None:
        self._finalize()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _finalize(self) -> None:
        if not self._chunks or _batcher is None:
            return
        latency_ms = (time.time() - self._start_time) * 1000
        model, content, usage, tool_calls = _reassemble_openai_stream(self._chunks)
        input_tokens = 0
        output_tokens = 0
        if usage:
            input_tokens = getattr(usage, "prompt_tokens", 0) or 0
            output_tokens = getattr(usage, "completion_tokens", 0) or 0

        cost = estimate_cost(
            model or self._kwargs.get("model", "unknown"), input_tokens, output_tokens
        )
        messages = self._kwargs.get("messages", [])
        trace = {
            "agent_name": model or self._kwargs.get("model", "unknown"),
            "prompt": _safe_json(messages),
            "response": content or "",
            "trace_type": "llm_call",
            "status": "success",
            "latency_ms": latency_ms,
            "token_count": input_tokens + output_tokens,
            "cost_usd": cost,
            "tool_calls": _safe_json(tool_calls) if tool_calls else None,
            "metadata": _safe_json(
                {"provider": "openai", "model": model, "streamed": True}
            ),
        }
        _attach_span_context(trace)
        _batcher.enqueue({k: v for k, v in trace.items() if v is not None})
        self._chunks = []


def _reassemble_openai_stream(
    chunks: list[Any],
) -> tuple[Optional[str], str, Any, Optional[list[Any]]]:
    """Reassemble streamed OpenAI chunks into (model, content, usage, tool_calls)."""
    model: Optional[str] = None
    content_parts: list[str] = []
    usage = None
    tool_calls: dict[int, dict[str, str]] = {}

    for chunk in chunks:
        c = chunk if isinstance(chunk, dict) else chunk.__dict__
        model = model or c.get("model")
        usage = c.get("usage") or usage
        for choice in c.get("choices", []):
            ch = choice if isinstance(choice, dict) else choice.__dict__
            delta = ch.get("delta")
            if delta is None:
                continue
            d = delta if isinstance(delta, dict) else delta.__dict__
            if d.get("content"):
                content_parts.append(d["content"])
            if d.get("tool_calls"):
                for tc in d["tool_calls"]:
                    tc_d = tc if isinstance(tc, dict) else tc.__dict__
                    idx = tc_d.get("index", 0)
                    if idx not in tool_calls:
                        func = tc_d.get("function", {})
                        func_d = func if isinstance(func, dict) else func.__dict__
                        tool_calls[idx] = {
                            "name": func_d.get("name", ""),
                            "arguments": func_d.get("arguments", ""),
                        }
                    else:
                        func = tc_d.get("function", {})
                        func_d = func if isinstance(func, dict) else func.__dict__
                        tool_calls[idx]["name"] = tool_calls[idx]["name"] or func_d.get(
                            "name", ""
                        )
                        tool_calls[idx]["arguments"] += func_d.get("arguments", "")

    tc_list = list(tool_calls.values()) if tool_calls else None
    return model, "".join(content_parts), usage, tc_list


# ---------------------------------------------------------------------------
# Wrapper factories
# ---------------------------------------------------------------------------


def _make_sync_wrapper(target: _PatchTarget) -> Any:
    extractor = (
        _extract_openai_data if target.provider == "openai" else _extract_anthropic_data
    )

    def wrapper(wrapped: Any, instance: Any, args: Any, kwargs: Any) -> Any:
        if _batcher is None:
            return wrapped(*args, **kwargs)

        start = time.time()
        try:
            response = wrapped(*args, **kwargs)
        except Exception as exc:
            latency_ms = (time.time() - start) * 1000
            trace = {
                "agent_name": kwargs.get("model", "unknown"),
                "prompt": _safe_json(kwargs.get("messages", [])),
                "response": str(exc),
                "trace_type": "llm_call",
                "status": "error",
                "latency_ms": latency_ms,
                "metadata": _safe_json(
                    {"provider": target.provider, "error": str(exc)}
                ),
            }
            _attach_span_context(trace)
            _batcher.enqueue(trace)
            raise

        if _is_stream(response):
            return _OpenAIStreamProxy(response, kwargs, start)

        latency_ms = (time.time() - start) * 1000
        trace = extractor(kwargs, response)
        trace["latency_ms"] = latency_ms
        _attach_span_context(trace)
        _batcher.enqueue({k: v for k, v in trace.items() if v is not None})
        return response

    return wrapper


def _make_async_wrapper(target: _PatchTarget) -> Any:
    extractor = (
        _extract_openai_data if target.provider == "openai" else _extract_anthropic_data
    )

    async def wrapper(wrapped: Any, instance: Any, args: Any, kwargs: Any) -> Any:
        if _batcher is None:
            return await wrapped(*args, **kwargs)

        start = time.time()
        try:
            response = await wrapped(*args, **kwargs)
        except Exception as exc:
            latency_ms = (time.time() - start) * 1000
            trace = {
                "agent_name": kwargs.get("model", "unknown"),
                "prompt": _safe_json(kwargs.get("messages", [])),
                "response": str(exc),
                "trace_type": "llm_call",
                "status": "error",
                "latency_ms": latency_ms,
                "metadata": _safe_json(
                    {"provider": target.provider, "error": str(exc)}
                ),
            }
            _attach_span_context(trace)
            _batcher.enqueue(trace)
            raise

        if _is_stream(response):
            return _OpenAIAsyncStreamProxy(response, kwargs, start)

        latency_ms = (time.time() - start) * 1000
        trace = extractor(kwargs, response)
        trace["latency_ms"] = latency_ms
        _attach_span_context(trace)
        _batcher.enqueue({k: v for k, v in trace.items() if v is not None})
        return response

    return wrapper


def _is_stream(obj: Any) -> bool:
    return (
        isinstance(obj, types.GeneratorType)
        or isinstance(obj, types.AsyncGeneratorType)
        or type(obj).__name__ in ("Stream", "AsyncStream")
    )


# ---------------------------------------------------------------------------
# Public patching API
# ---------------------------------------------------------------------------


def patch_openai() -> None:
    """Monkey-patch the OpenAI Python SDK so all calls are auto-traced."""
    try:
        import openai  # noqa: F401
    except ImportError:
        logger.debug("openai not installed, skipping instrumentation")
        return

    for target in _OPENAI_TARGETS:
        try:
            wrapper = (
                _make_async_wrapper(target)
                if target.is_async
                else _make_sync_wrapper(target)
            )
            wrap_function_wrapper(
                target.module, f"{target.cls}.{target.method}", wrapper
            )
        except Exception:
            logger.debug(
                "Failed to patch %s.%s.%s",
                target.module,
                target.cls,
                target.method,
                exc_info=True,
            )


def patch_anthropic() -> None:
    """Monkey-patch the Anthropic Python SDK so all calls are auto-traced."""
    try:
        import anthropic  # noqa: F401
    except ImportError:
        logger.debug("anthropic not installed, skipping instrumentation")
        return

    for target in _ANTHROPIC_TARGETS:
        try:
            wrapper = (
                _make_async_wrapper(target)
                if target.is_async
                else _make_sync_wrapper(target)
            )
            wrap_function_wrapper(
                target.module, f"{target.cls}.{target.method}", wrapper
            )
        except Exception:
            logger.debug(
                "Failed to patch %s.%s.%s",
                target.module,
                target.cls,
                target.method,
                exc_info=True,
            )


def patch_all() -> None:
    """Patch all supported providers."""
    patch_openai()
    patch_anthropic()
