from __future__ import annotations

import functools
import threading
import time
from typing import Any, Optional

import httpx


class SpyLLMClient:
    """Low-level client for the SpyLLM REST API.

    Most users should use ``spyllm.init()`` instead, which sets up automatic
    instrumentation.  This class is useful for manual tracing or advanced use.
    """

    def __init__(self, api_key: str, base_url: str = "https://api.spyllm.com") -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self.base_url,
            headers={"X-API-Key": self.api_key},
            timeout=30.0,
        )

    def trace(
        self,
        agent_name: str,
        prompt: str,
        response: str,
        *,
        trace_type: str = "llm_call",
        status: str = "success",
        latency_ms: Optional[float] = None,
        token_count: Optional[int] = None,
        cost_usd: Optional[float] = None,
        session_id: Optional[str] = None,
        metadata: Optional[str] = None,
        tool_calls: Optional[str] = None,
    ) -> str:
        payload: dict[str, Any] = {
            "agent_name": agent_name,
            "prompt": prompt,
            "response": response,
            "trace_type": trace_type,
            "status": status,
        }
        for key, val in [
            ("latency_ms", latency_ms),
            ("token_count", token_count),
            ("cost_usd", cost_usd),
            ("session_id", session_id),
            ("metadata", metadata),
            ("tool_calls", tool_calls),
        ]:
            if val is not None:
                payload[key] = val

        resp = self._http.post("/v1/traces", json=payload)
        resp.raise_for_status()
        return resp.json()["id"]

    def search(
        self, query: str, *, top_k: int = 20, status: Optional[str] = None
    ) -> list[dict[str, Any]]:
        payload: dict[str, Any] = {"query": query, "top_k": top_k}
        if status:
            payload["status"] = status
        resp = self._http.post("/v1/search", json=payload)
        resp.raise_for_status()
        return resp.json()


def agent_trace(agent_name: str, client: Optional[SpyLLMClient] = None) -> Any:
    """Decorator that automatically traces a function call."""

    def decorator(func: Any) -> Any:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.time()
            result = None
            call_status = "success"
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as exc:
                call_status = "error"
                result = str(exc)
                raise
            finally:
                sdk_client = client or _get_default_client()
                if sdk_client:
                    threading.Thread(
                        target=sdk_client.trace,
                        kwargs={
                            "agent_name": agent_name,
                            "prompt": str(args) + str(kwargs),
                            "response": str(result),
                            "status": call_status,
                            "latency_ms": (time.time() - start) * 1000,
                        },
                        daemon=True,
                    ).start()

        return wrapper

    return decorator


def _get_default_client() -> Optional[SpyLLMClient]:
    from . import _client

    return _client
