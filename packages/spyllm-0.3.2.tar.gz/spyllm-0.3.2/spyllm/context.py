"""Span context propagation for multi-agent observability.

Uses Python's ``contextvars`` so parent-child links are threaded automatically
through sync and async code without users passing IDs manually.

Usage::

    import spyllm

    with spyllm.agent_span('orchestrator', role='orchestrator'):
        plan = openai.chat(...)  # auto-captured under orchestrator

        with spyllm.agent_span('researcher', role='worker'):
            data = openai.chat(...)  # auto-captured under researcher
"""

from __future__ import annotations

import contextlib
import contextvars
import dataclasses
import time
import uuid
from typing import Any, AsyncIterator, Iterator, Optional


@dataclasses.dataclass
class SpanContext:
    """Immutable snapshot of the current span's identity and metadata."""

    trace_id: str
    span_id: str
    agent_name: str
    agent_role: str = "worker"
    operation_name: str = "invoke_agent"
    start_time: float = 0.0
    parent_span_id: Optional[str] = None
    framework: Optional[str] = None
    input_source: Optional[str] = None


_current_span: contextvars.ContextVar[Optional[SpanContext]] = contextvars.ContextVar(
    "_current_span", default=None
)


def get_current_span() -> Optional[SpanContext]:
    """Return the active span context, or ``None`` if outside any span."""
    return _current_span.get()


def _new_id() -> str:
    return uuid.uuid4().hex[:16]


@contextlib.contextmanager
def agent_span(
    name: str,
    *,
    role: str = "worker",
    operation: str = "invoke_agent",
    trace_id: Optional[str] = None,
    framework: Optional[str] = None,
    input_source: Optional[str] = None,
) -> Iterator[SpanContext]:
    """Open a new agent span. Nested calls inherit ``trace_id`` automatically.

    Args:
        name: Human-readable agent name (e.g. ``'planner'``).
        role: Agent role used for grouping in the topology view.
        operation: One of ``invoke_agent``, ``create_agent``, ``execute_tool``, ``chat``.
        trace_id: Override the trace ID (auto-inherited from parent otherwise).
        framework: Agent framework identifier (``crewai``, ``autogen``, etc.).
        input_source: What triggered this span (``user``, ``agent:planner``, etc.).
    """
    parent = _current_span.get()
    ctx = SpanContext(
        trace_id=trace_id or (parent.trace_id if parent else uuid.uuid4().hex),
        span_id=_new_id(),
        agent_name=name,
        agent_role=role,
        operation_name=operation,
        start_time=time.time(),
        parent_span_id=parent.span_id if parent else None,
        framework=framework,
        input_source=input_source,
    )
    token = _current_span.set(ctx)
    try:
        yield ctx
    finally:
        elapsed_ms = (time.time() - ctx.start_time) * 1000
        _emit_agent_span(ctx, elapsed_ms)
        _current_span.reset(token)


@contextlib.asynccontextmanager
async def async_agent_span(
    name: str,
    *,
    role: str = "worker",
    operation: str = "invoke_agent",
    trace_id: Optional[str] = None,
    framework: Optional[str] = None,
    input_source: Optional[str] = None,
) -> AsyncIterator[SpanContext]:
    """Async variant of :func:`agent_span`."""
    parent = _current_span.get()
    ctx = SpanContext(
        trace_id=trace_id or (parent.trace_id if parent else uuid.uuid4().hex),
        span_id=_new_id(),
        agent_name=name,
        agent_role=role,
        operation_name=operation,
        start_time=time.time(),
        parent_span_id=parent.span_id if parent else None,
        framework=framework,
        input_source=input_source,
    )
    token = _current_span.set(ctx)
    try:
        yield ctx
    finally:
        elapsed_ms = (time.time() - ctx.start_time) * 1000
        _emit_agent_span(ctx, elapsed_ms)
        _current_span.reset(token)


def _emit_agent_span(ctx: SpanContext, elapsed_ms: float) -> None:
    """Enqueue an agent-level span trace if a batcher is available."""
    from . import instrumentor

    batcher = instrumentor._batcher
    if batcher is None:
        return

    trace: dict[str, Any] = {
        "agent_name": ctx.agent_name,
        "prompt": "",
        "response": "",
        "trace_type": "agent_span",
        "status": "success",
        "latency_ms": elapsed_ms,
        "trace_id": ctx.trace_id,
        "span_id": ctx.span_id,
        "operation_name": ctx.operation_name,
        "agent_role": ctx.agent_role,
    }
    if ctx.parent_span_id:
        trace["parent_span_id"] = ctx.parent_span_id
    if ctx.framework:
        trace["framework"] = ctx.framework
    if ctx.input_source:
        trace["input_source"] = ctx.input_source

    batcher.enqueue(trace)
