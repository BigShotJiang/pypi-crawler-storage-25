# `close_session` — Close-Out Reference

Canonical operational reference for the close-out script. This is the
single source of truth: `python -m ai_router.close_session --help`
echoes Section 2 of this document verbatim, and Step 8 of
`docs/ai-led-session-workflow.md` collapses to one paragraph that
points here.

Contents:

- [Section 0 — Session-boundary writes (start and close)](#section-0--session-boundary-writes-start-and-close)
- [Section 1 — When close-out runs](#section-1--when-close-out-runs)
- [Section 2 — How to run close-out](#section-2--how-to-run-close-out)
- [Section 3 — What the script does](#section-3--what-the-script-does)
- [Section 4 — Common failures and remediation](#section-4--common-failures-and-remediation)
- [Section 5 — Manual close-out flags](#section-5--manual-close-out-flags)
- [Section 6 — Troubleshooting](#section-6--troubleshooting)

---

## Section 0 — Session-boundary writes (start and close)

Set 022 made `close_session` half of a symmetric pair. Every session
in a Full-tier set has exactly two router-driven boundary writes:
`start_session` at the beginning, `close_session` at the end. Both
share `compute_effective_completed_sessions(session_set_dir)` from
`ai_router.session_state` as the single source of truth for "how many
sessions are closed," so the two writers cannot disagree about the
set's current shape.

### Why two writers

The Session Set Explorer extension reads `session-state.json` and
`session-events.jsonl` and surfaces the result as a fraction
(`1/4`, `2/4`, `4/4 Done`) plus an "in flight" annotation
(`· session 2 in flight`) on the row. For this UI to track reality,
two transitions must land **on disk** at the right moment:

- **Set first becomes active**, or a between-sessions set's next
  session begins — the moment `start_session` runs.
- **Set advances its fraction**, or hits Done — the moment
  `close_session` returns success.

Before Set 022, the start side was a Python call (`register_session_start`)
embedded inside the orchestrator's automation script, and the close
side already had this contract. Promoting the start side to a CLI
makes the protocol uniform across engines (any orchestrator can
shell out, even if it can't import `ai_router`) and gives the
v0.13.11 defensive guards a writer-side mate so they only ever
have to recover, never prevent.

### Field-by-field protocol

**At session start** (`python -m ai_router.start_session` — see
[`ai_router/start_session.py`](../start_session.py)):

| Field                  | Value at start                                       |
|------------------------|------------------------------------------------------|
| `currentSession`       | inferred via `compute_effective_completed_sessions`  |
| `status`               | `"in-progress"`                                      |
| `lifecycleState`       | `"work_in_progress"`                                 |
| `startedAt`            | now (only if previously null)                        |
| `completedAt`          | null (cleared if was set)                            |
| `verificationVerdict`  | null (cleared if was set)                            |
| `completedSessions[]`  | preserved (or backfilled from events on legacy sets) |
| `orchestrator`         | refreshed for this session                           |
| Events ledger          | append exactly one `work_started` (deduped)          |
| Activity log           | nothing — first real step adds the first entry       |

**At session close** (`python -m ai_router.close_session`, this doc):

| Field                  | Non-final close                              | Final close                                  |
|------------------------|----------------------------------------------|----------------------------------------------|
| `completedSessions[]`  | append `currentSession` (sorted, unique)     | append `currentSession` (sorted, unique)     |
| `currentSession`       | unchanged (= just-closed session)            | unchanged (= `totalSessions`)                |
| `status`               | `"in-progress"`                              | `"complete"`                                 |
| `lifecycleState`       | `"work_in_progress"`                         | `"closed"`                                   |
| `completedAt`          | unchanged (null)                             | now                                          |
| `verificationVerdict`  | latest verdict / unchanged                   | latest verdict / unchanged                   |
| Events ledger          | `closeout_requested` + `closeout_succeeded`  | `closeout_requested` + `closeout_succeeded`  |

Final-session detection uses
`len(completedSessions) == totalSessions` post-append; `change-log.md`
presence remains a belt-and-suspenders signal so a drift case in
either direction is caught.

### Idempotency

Both writers are idempotent and safe to re-run:

- `start_session` re-running for the in-flight session is a no-op.
  The event ledger dedupes `work_started`; the snapshot fields are
  already correct. Re-running asking for a different session number
  exits 3 (boundary violation) — close the in-flight one first.
- `close_session` re-running on an already-closed session exits 0
  with `result: "noop_already_closed"` (see Section 3 step 4).

### Tier symmetry

The protocol applies tier-symmetrically: Full-tier projects use the
two CLIs; Lightweight-tier projects hand-write the same fields. See
[`docs/session-state-schema.md`](../../docs/session-state-schema.md)
for the canonical field list and worked examples, and Step 1 of
[`docs/ai-led-session-workflow.md`](../../docs/ai-led-session-workflow.md)
for the orchestrator-facing pseudo-code.

---

## Section 1 — When close-out runs

Close-out is the **sole synchronization barrier** between session work
and the session being marked complete. It runs once per session, after
all of the following are true:

1. The session's work agent has produced a `disposition.json` whose
   `status` field is `"completed"` (see
   [`docs/disposition-schema.md`](../../docs/disposition-schema.md)
   for the full schema, field-level invariants, and a copy-paste
   template).
2. End-of-session verification (Step 6) has returned a verdict
   (`VERIFIED` or `ISSUES_FOUND`), and any ISSUES_FOUND retries are
   exhausted.
3. **The orchestrator (or its fresh close-out turn — see Set 006
   Session 2) has already committed and pushed the session's work.**
   See "Ownership of commit / push / notification" below for why this
   is a precondition rather than something close-out does itself.

If any of these is not true, close-out refuses to run and emits a gate
failure with concrete remediation instead of producing a half-closed
session. The script is idempotent: running it twice on a session that
is already `complete` exits 0 with `result: "noop_already_closed"` and
no events emitted.

The orchestration layer invokes close-out as a fresh routed turn after
work verification terminates, so the close-out agent encounters
`ai_router/docs/close-out.md` (this file) at the moment the instructions
are needed — which sidesteps the GPT-5.4-flagged risk that collapsing
Step 8 in the workflow doc could lower agent compliance.

### Ownership of commit / push / notification

Close-out's responsibilities are deliberately narrow:

- Lifecycle gate checks (`gate_checks.GATE_CHECKS`)
- Verification-wait (queue mode) / verification-result inspection (api
  mode)
- Idempotent state writes (`mark_session_complete`, ledger events,
  `change-log.md` and the next-orchestrator recommendation in
  `ai-assignment.md`)

Close-out **does not** run `git commit`, `git push`, or
`send_session_complete_notification`. Those are the
**orchestrator's** (or the fresh close-out turn agent's)
responsibility, and they straddle the close-out call:

- **`git commit` and `git push`** run **before** invoking
  `close_session`. The boundary is enforced by
  `gate_checks.check_pushed_to_remote`: a session whose work was not
  pushed fails the gate at Section 3 step 7 and never reaches the
  state flip — so the gate guarantees the precondition rather than
  performing it.
- **`send_session_complete_notification(...)`** (from
  `ai_router/notifications.py`) runs **after** `close_session`
  returns `succeeded`. Firing it before close-out succeeds would
  notify the human about a session that may still gate-fail; firing
  it from inside `close_session` would re-introduce the
  side-effect-as-state-flip coupling that GPT-5.4 flagged in the
  original proposal review (§5 of
  `docs/proposals/2026-04-30-combined-design-alignment-audit.md`,
  drift item D-3).

This is a deliberate revision to the original close-out reliability
proposal (`docs/proposals/2026-04-29-session-close-out-reliability.md`
§3, items 4 and 6), which named close-out as the holder of commit,
push, and notification. The revision is documented in that proposal's
post-implementation revision section. Future audits should treat the
revised contract — close-out owns the gate; the caller owns the side
effects — as canonical.

---

## Section 2 — How to run close-out

```
python -m ai_router.close_session [--session-set-dir PATH] [options]
```

Default invocation:

```bash
.venv/Scripts/python.exe -m ai_router.close_session \
    --session-set-dir docs/session-sets/<slug>
```

Exit codes:

- `0` — close-out succeeded (gates passed; verifications terminal),
  or the session was already closed (idempotent no-op).
- `1` — gate failure (one or more deterministic gates rejected).
- `2` — invalid invocation (incompatible flags; missing
  `disposition.json` outside `--force` / `--repair`).
- `3` — lock contention (another close-out is running on the same
  session set).
- `4` — timeout waiting on queued verification.
- `5` — repair drift detected and not applied (`--repair` without
  `--apply`).

JSON output (`--json`) shape — stable across exit codes so callers
parse it without branching on success:

```json
{
  "result": "succeeded | noop_already_closed | gate_failed | invalid_invocation | lock_contention | verification_timeout | repair_drift",
  "exit_code": 0,
  "session_set_dir": "<absolute path>",
  "session_number": 3,
  "messages": ["<human-readable line>", "..."],
  "gate_results": [
    {"check": "<name>", "passed": true, "remediation": ""}
  ],
  "verification": {
    "method": "api | queue | manual | skipped",
    "message_ids": ["<id>"],
    "wait_outcome": "completed | failed | timed_out"
  },
  "events_emitted": ["closeout_requested", "closeout_succeeded"]
}
```

Flag summary:

| Flag | Purpose |
|---|---|
| `--session-set-dir PATH` | Path to the session set directory. Defaults to active session set in CWD. |
| `--json` | Emit a single JSON object on stdout instead of human-readable lines. |
| `--interactive` | Opt in to interactive prompts. Default is non-interactive — never blocks on stdin. |
| `--force` | Bypass all gate checks. **Hard-scoped to incident recovery only**: requires `AI_ROUTER_ALLOW_FORCE_CLOSE_OUT=1` in the environment AND `--reason-file`. Emits `closeout_force_used` to the events ledger and writes `forceClosed: true` to `session-state.json`. See Section 5. |
| `--allow-empty-commit` | Permit close-out for a session that produced no commits. |
| `--reason-file PATH` | File containing narrative fields (close-out reason, manual-verify attestation). |
| `--manual-verify` | Skip queue verification blocking; treat verifications as completed by human attestation (bootstrapping window only). Requires `--interactive` or `--reason-file`. |
| `--repair` | Diagnostic mode: walk the session set's state and report drift. |
| `--apply` | When combined with `--repair`, apply corrections to detected drift. |
| `--timeout MINUTES` | Maximum minutes to wait for queued verifications to reach a terminal state (default 60). |

Flag combination rules (validated up front; failure exits 2):

- `--force` is bypass-everything; it is incompatible with
  `--interactive`, `--manual-verify`, and `--repair`. Pick one bypass
  at a time so the audit trail stays unambiguous.
- **`--force` is hard-scoped to incident recovery** (Set 9 Session 3,
  D-2). On top of the compatibility rules above, two additional gates
  fire: the environment must export `AI_ROUTER_ALLOW_FORCE_CLOSE_OUT=1`,
  AND a `--reason-file` must be supplied with a non-empty narrative.
  Both rejections exit 2 before any state is touched. See Section 5.
- `--apply` requires `--repair`. Using it alone is almost certainly a
  typo and fails loudly.
- `--manual-verify` requires either `--interactive` or `--reason-file`.
  An operator who genuinely has nothing to say can put a one-line
  reason in a file; silent bypass is refused so the audit trail stays
  honest.
- `--timeout` must be positive.

---

## Section 3 — What the script does

Close-out runs in this order. Each phase is fail-fast: a phase that
rejects emits its `closeout_failed` event with a remediation string and
returns the corresponding exit code without touching downstream state.

1. **Parse and validate args.** Combination rules above. Failure → 2.
2. **Resolve session-set directory** — explicit `--session-set-dir`,
   else discover from CWD via `find_active_session_set`.
3. **Acquire close lock** (`ai_router.close_lock.close_session_lock`).
   The lock file lives at `<session-set-dir>/.close_session.lock` and
   stores `pid`, `worker_id`, and `acquired_at`. A stale lock (dead PID, or
   acquired more than the stale-window ago) is reaped automatically.
   A live lock fails closed with exit 3.
4. **Idempotency check.** Read `session-state.json` (see
   [`docs/session-state-schema.md`](../../docs/session-state-schema.md)
   for the full schema, canonical status values, and the alias map
   applied at the read boundary). If the current session's lifecycle
   state is already `complete`, exit 0 with `noop_already_closed` —
   emit nothing, write nothing, release the lock cleanly.
5. **Read `disposition.json`** (`ai_router.disposition.read_disposition`).
   Must exist with `status: "completed"`. Missing or non-`completed`
   → gate failure unless `--force` or `--repair` is set.
6. **Emit `closeout_requested`** to `session-events.jsonl`.
7. **Run deterministic gate checks** (`ai_router.gate_checks`):
   - `check_working_tree_clean` — `git status` is clean (or only
     ignored patterns remain). Catches "agent forgot to commit".
   - `check_pushed_to_remote` — local HEAD has been pushed to the
     remote tracking branch. Catches "committed but never pushed".
   - `check_activity_log_entry` — the current session has an
     `activity-log.json` entry whose `session_number` matches.
   - `check_next_orchestrator_present` — every session except the
     last has a routed next-orchestrator recommendation. Catches
     drift from the workflow's "always route, never self-opine" rule.
   - `check_change_log_fresh` — last-session-only: the change log was
     updated in the same commit window (timestamp within tolerance).
   Each gate returns `(passed: bool, remediation: str)`. The first
   failing gate stops the phase; the script emits `closeout_failed`
   with the remediation and exits 1.
8. **Wait for verification to terminate** (bounded by `--timeout`):
   - **API mode** — verification is already synchronous; this is a
     no-op flagged as `method: "api"`.
   - **Manual mode** (`--manual-verify`) — record the attestation
     text from stdin or `--reason-file` and proceed. Method
     `"manual"`.
9. **Idempotent writes.** Each of these is safe to retry:
   - `mark_session_complete(session_set, verification_verdict, ...)` —
     flips `session-state.json` from `in-progress` to `complete` and
     records the verdict + `completedAt` ISO timestamp.
   - Append the next-orchestrator recommendation to `ai-assignment.md`
     (every session except the last).
   - Last session only: write `change-log.md` and append the
     next-session-set recommendation.
10. **Emit `closeout_succeeded`** to `session-events.jsonl`,
    release the lock, exit 0.

The caller (orchestrator or fresh close-out turn agent) fires
`send_session_complete_notification(...)` from `ai_router/notifications.py`
**after** `close_session` returns `succeeded`. The script does not
perform the notification itself — see Section 1 "Ownership of commit
/ push / notification" for the rationale and `git` precondition.
Notification failure is non-fatal: the work is preserved in git
regardless and the human can re-fire the notification by hand if
needed.

The cost report (`print_cost_report(SESSION_SET)`) prints during
the close-out turn before step 9. It reads `router-metrics.jsonl` for
this session set and is dual-sourced (Set 4 Session 1) — both per-call
metrics and provider-side aggregation cross-check each other.

---

## Section 4 — Common failures and remediation

Close-out is designed so every failure mode produces a single concrete
remediation string in `messages` (and in `gate_results[].remediation`
for gate failures). The patterns below are the ones operators have
hit during Sets 1–5; new patterns should be added here as the failure
inventory grows.

**Uncommitted files in working tree** — `check_working_tree_clean`
fails with the list of dirty paths. The agent typically forgot to
`git add` a generated file, or a tool wrote to a temp file inside the
repo. Remediation: `git status` to see what's there, `git add` and
re-commit if intentional, `git restore` if scratch. Then re-run
close-out.

**Push rejected (non-fast-forward)** — `check_pushed_to_remote` shows
the local HEAD is ahead of `origin/<branch>` *and* a `git push`
attempt would be rejected. Remediation: `git fetch && git rebase
origin/<branch>` (or `git pull --rebase`), resolve conflicts if any,
push again, re-run close-out. Do not `--force` push to shared branches.

**Missing `nextOrchestrator` recommendation** —
`check_next_orchestrator_present` fails on a non-last session because
the orchestrator forgot to route the recommendation. Remediation: route
it now (`route(content=..., task_type="analysis")`), append to
`ai-assignment.md`, commit, push, re-run close-out. The check enforces
"always route, never self-opine"; do not satisfy it by hand-writing
the recommendation.

**Disposition file missing** — exit 2 with `invalid_invocation`. The
work agent never produced `disposition.json`, which usually means the
session crashed mid-step or the agent ran a partial close-out by
hand. Do not bypass with `--force` reflexively. Investigate first:
read `activity-log.json` to see how far the session got, decide
whether the work is genuinely complete, then either resume the session
(re-run) or run `--repair` to inspect drift.

**Stale lock** — exit 3 with `lock_contention`, but the lock holder
PID is dead. The lock file should be reaped automatically on the next
attempt; if it isn't (clock skew, exotic kill paths), inspect
`<session-set-dir>/.close_session.lock` and remove it manually only
after confirming no other close-out is running.

**Manual-verify silent bypass refused** — exit 2 with the validation
message `"--manual-verify requires either --interactive ... or
--reason-file ..."`. By design: an operator who skips queue
verification must record *why* somewhere durable. Either add
`--interactive` (prompted on stdin) or write a one-line reason to a
file and pass `--reason-file <path>`.

---

## Section 5 — Manual close-out flags

Three flags exist for cases where the deterministic close-out path
cannot run. Each leaves a distinct, audit-able trail.

**`--interactive`** — opts in to stdin prompts. Without it, the
script never blocks on input; the orchestrator's automation path runs
in the default non-interactive mode. Use this when an operator is
running close-out from a terminal and wants to confirm sensitive
actions.

**`--force`** — bypass all gate checks. **Hard-scoped to incident
recovery only** (Set 9 Session 3, drift item D-2 in
`docs/proposals/2026-04-30-combined-design-alignment-audit.md`). The
flag is rejected by default; opting in requires both:

- **Environment gate.** Export `AI_ROUTER_ALLOW_FORCE_CLOSE_OUT=1` in
  the shell that runs `close_session`. A normal terminal session does
  not have this set, so an accidental `--force` invocation during
  day-to-day operation fails fast with a clear `invalid_invocation`
  message before any state is touched.
- **Reason file.** Pass `--reason-file <path>` to a non-empty
  narrative explaining the incident. The file's contents become the
  payload of the `closeout_force_used` event in
  `session-events.jsonl`, so a forensic walk of the ledger always
  answers "why was the gate bypassed?" without requiring a separate
  paper trail.

When both gates pass, close-out:

- emits a loud `WARNING` line to stderr (operator can't miss it,
  even in `--json` mode where stdout is JSON);
- appends a `closeout_force_used` event to `session-events.jsonl`
  with the reason as a payload field;
- writes `forceClosed: true` to `session-state.json` so the VS Code
  Session Set Explorer surfaces a `[FORCED]` description badge on
  the affected set's row.

The badge persists until the session set is restarted from scratch —
that's the point. A force-closed set stays visibly force-closed in
the explorer view so reviewers triaging incidents can spot it
immediately.

`mark_session_complete(force=True)` (the function-level entry point)
does not consult the env-var gate — it trusts callers (tests, the
repair path) to use `force=True` deliberately. The CLI's
`--force` is the operator-facing entry point and carries the gates;
the function-level path is for internal use only and is exercised by
`test_mark_session_complete_gate.py`.

**`--manual-verify`** — skip API verification and record a human
attestation that verification happened out of band. Requires
`--interactive` or `--reason-file` so the attestation lands in the
audit trail. Method `"manual"` is recorded in the JSON output and the
`closeout_succeeded` event payload.

**`--repair`** — diagnostic mode. Walks the session set's state
(`session-state.json`, `activity-log.json`, `session-events.jsonl`,
`disposition.json`) and reports drift between them without touching
anything. Add `--apply` to actually fix detectable drift. `--repair`
without `--apply` exits 5 if drift is found, so it's safe to script as
a pre-flight check.

The drift shapes the walk detects:

1. **State-says-closed-but-no-closeout-event-for-`currentSession`.**
   `session-state.json` reports `lifecycleState: closed` (or v1
   `status: complete`) but `session-events.jsonl` has no
   `closeout_succeeded` event for the session number that state
   claims is closed. Two real-world variants both reduce to this
   check:
     - *Bootstrapping-window drift.* The old Step 8 path committed
       without emitting terminal lifecycle events at all.
     - *Mixed-mode drift.* Earlier sessions in the set ran through
       `close_session` (events ledger has their closeouts) but a
       later session was hand-authored directly — `session-state.json`
       was edited to `currentSession: N` / `status: complete`
       without anyone invoking `close_session` for session `N`, so
       no `closeout_succeeded` event for `N` exists. Until the
       extension's tree-view guard shipped in v0.13.11, this
       displayed as Done; the tracker now downgrades to In Progress,
       and `--repair --apply` will backfill the missing event.
   Repair: with `--apply`, append a synthetic `closeout_requested`
   (if missing) and `closeout_succeeded` for the claimed-closed
   session so the events ledger becomes internally consistent and
   the tree view stops downgrading. **Set 022 extension:** the
   apply path also backfills `completedSessions[]` in
   `session-state.json` using the events ledger directly (post-
   synthesis). **Set 023 refinement (`ai_router 0.2.4`):** the
   backfill is now the **union** of (a) the snapshot's existing
   `completedSessions[]` (sanitized — non-positive-int entries,
   booleans, and duplicates are dropped from the union math) and
   (b) the distinct `closeout_succeeded` session numbers in the
   now-repaired ledger. The union is **monotone-up only** —
   repair appends session numbers to bring the snapshot up to
   ledger reality but never removes a session number the operator
   hand-authored. Four apply outcomes are distinguished in the
   `messages` line:
     - *Backfilled* (snapshot's array was empty, absent, or
       null): the repair writes the events-ledger reconstruction
       in full — `repair applied: backfilled completedSessions=[...]`.
     - *Merged* (snapshot's array is a clean sorted-int list that
       differs from the union view): the repair writes the union
       and reports both sources — `repair applied: merged
       completedSessions=[...] (union of snapshot [...] and
       events [...])`.
     - *Normalized* (snapshot's array exists but has malformed,
       duplicate, or unsorted entries): the repair cleans the
       array while applying the union — `repair applied:
       normalized completedSessions=[...] (raw snapshot [...]
       cleaned + unioned with events [...])`. This branch ensures
       a typo like `[1, -1, 2]` does not survive a repair pass.
     - *Preserved* (snapshot's raw on-disk array already equals
       the canonical merged form): no snapshot rewrite happens;
       the message line reports `repair preserved
       completedSessions=[...] (snapshot already a superset of the
       events-ledger reconstruction)` so the operator sees the
       no-op explicitly.
   This eliminates the pre-Set-023 regression where a hand-migrated
   snapshot with `completedSessions: [1, 2, 3, 4]` would be
   overwritten back to a partial subset whenever the events ledger
   only recorded a later session's closeout (Set 004 on this repo
   hit this on 2026-05-15).

   **Attestation model (Set 023 Session 4 / Session 2 audit — GPT on
   (a)).** `completedSessions[]` is **operator-attested** for migrated
   sets (the operator hand-adds the array to encode their stated
   ground truth) and **tool-maintained** for sets that ran the
   close-out gate end-to-end (every `--apply` close-out writes the
   union). The repair preserves the operator's stated truth and uses
   the events ledger only to add what the operator missed; it never
   removes a session number the operator authored. Mirrors the
   sharpened invariant phrasing in `docs/session-state-schema.md`:
   `completedSessions[]` is authoritative for *whether* a session is
   closed; the events ledger is authoritative for *when* each
   closeout was recorded. The extension's `isMidSetComplete` guard
   (v0.13.13, Set 023 Session 4) consults the array as an
   alternative whether-closed signal to the ledger, so a migrated
   set displays correctly without needing both signals to agree.

2. **Closeout-succeeded-but-state-not-closed.** The reverse drift:
   events ledger says the session closed but `session-state.json`
   is still `work_in_progress` / `work_verified`. Repair: with
   `--apply`, call `_flip_state_to_closed` so the snapshot tracks
   the ledger.

3. **Stranded mid-closeout** (`closeout_requested` without a
   terminal companion). Reported only; recovery is the reconciler's
   job. `--repair` does not re-run the gate from inside itself.

---

## Section 6 — Troubleshooting

**Stranded sessions.** A session is "stranded" when `session-state.json`
says `in-progress` but no further events have been written in a long
time and no daemon is processing it. The reconciler
(`ai_router.reconciler`, registered as a sweeper hook by
`register_sweeper_hook` at orchestrator startup — see Set 3 Session 3)
sweeps stranded sessions periodically and either re-attempts
close-out (if the session looks complete) or files a diagnostic
record (if it does not). To inspect manually:

```bash
.venv/Scripts/python.exe -m ai_router.reconciler --dry-run \
    --session-set docs/session-sets/<slug>
```

The reconciler emits `format_summary(...)` output describing what it
would do. If the dry-run looks right, drop `--dry-run` to apply.

**Lock contention without an obvious holder.** If `--repair` shows a
lock file but `pid_file_path` does not point to a live daemon,
something killed the previous close-out hard. Read the lock file:

```bash
cat docs/session-sets/<slug>/.close_session.lock
```

The `acquired_at` field plus the stale-window constant in
`close_lock.py` tell you whether the lock should already have been
reaped. If the lock is genuinely stale and reaping is failing,
remove the file by hand — but only after confirming no other
close-out is running and no daemon process owns the PID.

**Reconciler behavior at orchestrator startup.** The reconciler's
sweeper hook runs once at orchestrator-role daemon startup and then
on a schedule. The startup pass catches sessions stranded across a
restart; the schedule catches sessions that strand mid-run. Both
re-use the same `_evaluate_one(session_set_dir, ...)` predicate so
the two paths cannot disagree about what "stranded" means.

**Mixed-mode drift (hand-authored session in a router-driven set).**
The supported tiers are Full (every session runs through
`close_session`; events ledger is authoritative) and Lightweight
(no router writer; the human or orchestrator hand-maintains
`session-state.json`). Mixing the two within a single set is **not
supported** but does happen in practice — earlier sessions run
through `close_session` and a later session (often a "quick bug
fix" or "wrap up" session) is authored directly:
`session-state.json` is edited to `currentSession: N` /
`status: "complete"` / `lifecycleState: "closed"`, possibly with a
hand-typed `completedAt`, but `session-events.jsonl` never gets a
`work_started` or `closeout_succeeded` event for session `N`.

Symptoms:

- The tree view shows the set as Done even though session `N`'s
  work didn't actually run through the gate. The extension's
  v0.13.11 guard downgrades the bucket to In Progress when it
  detects this exact shape (snapshot claims `complete` for the
  final session but the ledger has no closeout event for it).
- `--repair` walks emit a "state says closed but no closeout event
  for session N" drift message (drift case 1 in Section 5).
- The cost dashboard misses session `N`'s spend because the
  router never recorded the calls.

Telltale signs in the file itself: hand-typed timestamps with
six trailing zeros (`2026-05-12T15:20:00.000000-04:00`) — the
router's `_now_iso()` always emits microsecond precision. A real
router-written timestamp looks like
`2026-05-12T15:23:47.342195-04:00`.

Recovery:

- **If the work was actually done** and you just want the ledger
  to reflect it, run `python -m ai_router.close_session --repair
  --apply --session-set docs/session-sets/<slug>`. Drift case 1
  fires and appends synthetic `closeout_requested` +
  `closeout_succeeded` events for `currentSession`. The tree view
  recovers on next refresh. Optionally add a manual
  `completedSessions[]` array to `session-state.json` so
  consumers don't have to derive the count.
- **If the work was NOT done** (the state file was over-eagerly
  flipped to complete), roll the snapshot back by hand: set
  `status: "in-progress"`, `lifecycleState: "work_in_progress"`,
  clear `completedAt` and `verificationVerdict`. The set returns
  to In Progress and the work can resume through `close_session`
  normally.

Prevention: the orchestrator instruction file should either commit
the set to Lightweight tier (no router writes, no events ledger,
maintain `completedSessions[]` manually per
`docs/session-state-schema.md`) or Full tier (every session
through `close_session`). Don't switch mid-set.

**Cross-set parallelism on the same `(repo, branch)`.** The close-out
lock at `<session-set-dir>/.close_session.lock` serializes **same-set
close-out re-entry** only. It does not scope to the `(repo, branch)`
pair, so two session sets pointing at the same branch can still race
during their work phase. The shipping operating model assumes parallel
sessions use distinct `session-set/<slug>` branches via the sibling-
worktrees-folder layout (see `docs/planning/repo-worktree-layout.md`),
which makes the cross-set-on-same-branch case rare; when it does
occur, the deterministic gate is the residual safety net rather than
admission-time exclusion.

Concretely, if two sets racing on the same branch both commit and one
pushes first, the loser's `git push` would be rejected non-fast-forward.
`check_pushed_to_remote` surfaces that rejection verbatim with a
`run: git pull --rebase` (or equivalent) remediation, and `close_session`
exits 1 (gate failure) without flipping the lifecycle state. The loser
rebases onto the winner's commit, re-pushes, and re-runs close-out.
The gate's rejection-and-remediation behavior on the loser of the
push race is exercised directly by
`TestScenario7CrossSetParallelRejection` in
`ai_router/tests/test_failure_injection.py`. The downstream
"`close_session` exits 1 without flipping lifecycle state" property is
not asserted by Scenario 7 itself — it is an established invariant of
the close-out flow already covered by the gate-failure tests in
`test_mark_session_complete_gate.py` and the close-out integration
tests; Scenario 7 proves the gate's response in the
specific cross-set push-race scenario.

If the parallel-on-same-branch pattern becomes routine rather than
incidental, reopen the question — a `(repo, branch)`-scoped advisory
lock acquired at session admission is a viable add-on (see drift item
D-1 in `docs/proposals/2026-04-30-combined-design-alignment-audit.md`
§5.2 for the original corrective options). The current contract
deliberately does not include one because the new failure mode it
introduces (a corrupt or stranded admission lock blocking all sessions
on a branch until the TTL elapses) is judged worse than the
rare-but-loud push race the gate already catches.
