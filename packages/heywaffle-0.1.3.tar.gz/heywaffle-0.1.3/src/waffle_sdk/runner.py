import argparse
import asyncio
import json
import logging
import os
import socket
import sys
import traceback
import uuid
from typing import Any

import httpx
from dotenv import load_dotenv
from httpx_sse import aconnect_sse

load_dotenv()

from .trace import Tracer, TraceWatcher
from .types import AgentContext, Handler

logger = logging.getLogger("waffle.sdk")

DEFAULT_HUB_URL = "http://127.0.0.1:8765"
RECONNECT_BACKOFF_SECONDS = 5


def run(
    handler: Handler,
    *,
    agent: str | None = None,
    project: str = "default",
    description: str | None = None,
    model: str | None = None,
    concurrency: int = 1,
    subscriptions: list[dict[str, Any]] | None = None,
    crons: list[dict[str, Any]] | None = None,
) -> None:
    parser = argparse.ArgumentParser(prog="waffle-agent")
    sub = parser.add_subparsers(dest="mode", required=True)

    once = sub.add_parser("once", help="Run handler once with --input payload")
    once.add_argument(
        "--input",
        required=True,
        help="JSON string passed to the handler as the item payload",
    )
    once.add_argument(
        "--hub",
        default=os.getenv("WAFFLE_HUB_URL", DEFAULT_HUB_URL),
        help="Waffle hub URL for trace streaming (default: %(default)s)",
    )
    once.add_argument(
        "--no-trace",
        action="store_true",
        help="Disable trace streaming even if the hub is reachable",
    )

    inbox = sub.add_parser("inbox", help="Connect to Waffle hub and process inbox items")
    inbox.add_argument(
        "--hub",
        default=os.getenv("WAFFLE_HUB_URL", DEFAULT_HUB_URL),
        help="Waffle hub base URL (default: $WAFFLE_HUB_URL or %(default)s)",
    )
    inbox.add_argument(
        "--runner",
        default=os.getenv("WAFFLE_RUNNER_NAME", socket.gethostname()),
        help="Identifier for this runner instance (default: hostname)",
    )
    inbox.add_argument(
        "--no-trace",
        action="store_true",
        help="Process items without forwarding Claude session traces to the hub",
    )

    args = parser.parse_args()
    _configure_logging()

    # Sync WAFFLE_HUB_URL to the resolved hub URL so in-handler components
    # (e.g. phase tracers posting directly to the hub) read the same target
    # as TraceWatcher. Without this, `--hub` would only affect the runner.
    if getattr(args, "hub", None):
        os.environ["WAFFLE_HUB_URL"] = args.hub

    if args.mode == "once":
        _run_once(
            handler,
            args.input,
            agent=agent,
            project=project,
            description=description,
            model=model,
            concurrency=max(1, concurrency),
            subscriptions=subscriptions or [],
            crons=crons or [],
            hub_url=args.hub,
            no_trace=args.no_trace,
        )
    elif args.mode == "inbox":
        if not agent:
            parser.error("inbox mode requires `agent=...` kwarg in run()")
        _run_inbox(
            handler,
            agent=agent,
            project=project,
            description=description,
            model=model,
            concurrency=max(1, concurrency),
            subscriptions=subscriptions or [],
            crons=crons or [],
            hub_url=args.hub,
            runner=args.runner,
            trace=not args.no_trace,
        )
    else:
        parser.error(f"unknown mode: {args.mode}")


def _configure_logging() -> None:
    if logging.getLogger().handlers:
        return
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stderr,
    )


# ---------------------------------------------------------------------------
# once mode
# ---------------------------------------------------------------------------

def _run_once(
    handler: Handler,
    raw_input: str,
    *,
    agent: str | None,
    project: str,
    description: str | None,
    model: str | None,
    concurrency: int,
    subscriptions: list[dict[str, Any]],
    crons: list[dict[str, Any]],
    hub_url: str | None,
    no_trace: bool,
) -> None:
    try:
        item = json.loads(raw_input)
    except json.JSONDecodeError as exc:
        print(f"error: --input is not valid JSON: {exc}", file=sys.stderr)
        sys.exit(1)

    if not isinstance(item, dict):
        print("error: --input must decode to a JSON object", file=sys.stderr)
        sys.exit(1)

    try:
        result = asyncio.run(
            _invoke_once(
                handler,
                item,
                agent=agent,
                project=project,
                description=description,
                model=model,
                concurrency=concurrency,
                subscriptions=subscriptions,
                crons=crons,
                hub_url=hub_url,
                no_trace=no_trace,
            )
        )
    except Exception:
        traceback.print_exc()
        sys.exit(1)

    print(json.dumps(result, indent=2, ensure_ascii=False))


async def _invoke_once(
    handler: Handler,
    item: dict[str, Any],
    *,
    agent: str | None,
    project: str,
    description: str | None,
    model: str | None,
    concurrency: int,
    subscriptions: list[dict[str, Any]],
    crons: list[dict[str, Any]],
    hub_url: str | None,
    no_trace: bool,
) -> dict[str, Any]:
    if no_trace or not hub_url:
        ctx = AgentContext(logger=logging.getLogger("waffle.agent"), model=model)
        return await handler(item, ctx)

    if not await _hub_reachable(hub_url):
        logger.info("hub %s not reachable; running without trace streaming", hub_url)
        ctx = AgentContext(logger=logging.getLogger("waffle.agent"), model=model)
        return await handler(item, ctx)

    # Register the agent so traces appear under its project in the UI. Inbox
    # mode does the same thing on startup — this is the once-mode counterpart.
    if agent:
        try:
            async with httpx.AsyncClient(base_url=hub_url, timeout=5.0) as client:
                await _register(
                    client, agent, project, description, model, concurrency,
                    subscriptions, crons,
                )
        except Exception as exc:
            logger.warning("agent registration failed: %s; trace will still stream", exc)

    run_id = str(uuid.uuid4())
    logger.info("trace streaming to %s (run_id=%s)", hub_url, run_id)
    async with TraceWatcher(hub_url, agent=agent, run_id=run_id) as watcher:
        ctx = AgentContext(
            logger=logging.getLogger("waffle.agent"),
            model=model,
            tracer=Tracer(watcher),
        )
        return await handler(item, ctx)


async def _hub_reachable(hub_url: str) -> bool:
    try:
        async with httpx.AsyncClient(timeout=1.5) as client:
            r = await client.get(hub_url.rstrip("/") + "/")
            return r.status_code == 200
    except Exception:
        return False


# ---------------------------------------------------------------------------
# inbox mode
# ---------------------------------------------------------------------------

def _run_inbox(
    handler: Handler,
    *,
    agent: str,
    project: str = "default",
    description: str | None = None,
    model: str | None = None,
    concurrency: int = 1,
    subscriptions: list[dict[str, Any]],
    crons: list[dict[str, Any]],
    hub_url: str,
    runner: str,
    trace: bool = True,
) -> None:
    asyncio.run(
        _inbox_loop(
            handler,
            agent=agent,
            project=project,
            description=description,
            model=model,
            concurrency=concurrency,
            subscriptions=subscriptions,
            crons=crons,
            hub_url=hub_url,
            runner=runner,
            trace=trace,
        )
    )


async def _inbox_loop(
    handler: Handler,
    *,
    agent: str,
    project: str = "default",
    description: str | None = None,
    model: str | None = None,
    concurrency: int = 1,
    subscriptions: list[dict[str, Any]],
    crons: list[dict[str, Any]],
    hub_url: str,
    runner: str,
    trace: bool = True,
) -> None:
    semaphore = asyncio.Semaphore(concurrency)
    tasks: set[asyncio.Task] = set()

    async with httpx.AsyncClient(base_url=hub_url, timeout=httpx.Timeout(None, connect=10)) as client:
        await _register(
            client, agent, project, description, model, concurrency, subscriptions, crons,
        )
        logger.info(
            "agent=%s runner=%s concurrency=%s model=%s connected to %s, listening for items",
            agent, runner, concurrency, model or "<handler default>", hub_url,
        )

        async def spawn(item_id: int) -> None:
            async with semaphore:
                await _process_item(
                    client, handler, agent, item_id, runner, hub_url, model, trace,
                )

        while True:
            try:
                async with aconnect_sse(client, "GET", f"/inbox/{agent}/stream") as source:
                    async for sse in source.aiter_sse():
                        if sse.event == "item":
                            try:
                                data = json.loads(sse.data)
                                item_id = int(data["id"])
                            except (json.JSONDecodeError, KeyError, ValueError):
                                logger.warning("malformed item event: %r", sse.data)
                                continue
                            task = asyncio.create_task(spawn(item_id))
                            tasks.add(task)
                            task.add_done_callback(tasks.discard)
                        elif sse.event == "ping":
                            continue
            except (httpx.HTTPError, asyncio.TimeoutError) as exc:
                logger.warning(
                    "SSE disconnected (%s); reconnecting in %ss",
                    exc, RECONNECT_BACKOFF_SECONDS,
                )
                await asyncio.sleep(RECONNECT_BACKOFF_SECONDS)


async def _register(
    client: httpx.AsyncClient,
    agent: str,
    project: str,
    description: str | None,
    model: str | None,
    concurrency: int,
    subscriptions: list[dict[str, Any]],
    crons: list[dict[str, Any]],
) -> None:
    # Single declarative registration: hub reconciles subscriptions and crons
    # to match exactly what the agent declared, so removed / edited entries
    # in the agent code take effect on the next restart.
    r = await client.post(
        "/agents/register",
        json={
            "name": agent,
            "project": project,
            "description": description,
            "model": model,
            "concurrency": concurrency,
            "subscriptions": subscriptions,
            "crons": crons,
        },
    )
    r.raise_for_status()
    logger.info(
        "registered agent=%s project=%s · %d subscription(s), %d cron(s)",
        agent, project, len(subscriptions), len(crons),
    )


async def _process_item(
    client: httpx.AsyncClient,
    handler: Handler,
    agent: str,
    item_id: int,
    runner: str,
    hub_url: str,
    model: str | None = None,
    trace: bool = True,
) -> None:
    claim = await client.post(
        f"/inbox/{agent}/claim/{item_id}",
        json={"runner": runner},
    )
    if claim.status_code == 409:
        return
    if claim.status_code == 404:
        logger.warning("item %s not found at claim; skipping", item_id)
        return
    claim.raise_for_status()

    item = claim.json()
    payload = item.get("payload", {})

    run_id = str(uuid.uuid4())
    logger.info("processing item %s (source=%s, run_id=%s)", item_id, item.get("source"), run_id)
    try:
        if trace:
            async with TraceWatcher(hub_url, agent=agent, item_id=item_id, run_id=run_id) as watcher:
                ctx = AgentContext(
                    logger=logging.getLogger("waffle.agent"),
                    model=model,
                    tracer=Tracer(watcher),
                )
                result = await handler(payload, ctx)
        else:
            ctx = AgentContext(logger=logging.getLogger("waffle.agent"), model=model)
            result = await handler(payload, ctx)
    except Exception as exc:
        logger.exception("handler failed for item %s", item_id)
        await client.post(
            f"/inbox/{agent}/fail/{item_id}",
            json={"error": f"{type(exc).__name__}: {exc}"},
        )
        return

    safe_result = result if isinstance(result, dict) else {"value": result}
    await client.post(
        f"/inbox/{agent}/complete/{item_id}",
        json={"result": safe_result},
    )
    logger.info("completed item %s", item_id)
