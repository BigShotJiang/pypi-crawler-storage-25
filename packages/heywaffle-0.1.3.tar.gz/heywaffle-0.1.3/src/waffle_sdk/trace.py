import asyncio
import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import IO, Any

import httpx

logger = logging.getLogger("waffle.trace")

CLAUDE_PROJECTS_DIR = Path.home() / ".claude" / "projects"
POLL_INTERVAL_SECONDS = 0.5
BATCH_FLUSH_INTERVAL_SECONDS = 1.0


def project_dir_for_cwd(cwd: Path) -> Path:
    """Match Claude Code's project-dir naming: absolute cwd with / -> -."""
    return CLAUDE_PROJECTS_DIR / str(cwd.resolve()).replace("/", "-")


class TraceWatcher:
    """Watches the Claude Code project dir for JSONL session files that appear
    while the handler is running, tails them, and POSTs new lines to the Waffle
    hub. Also accepts non-Claude "phase" events posted via `post_phase`, which
    are folded into the same session so a run shows as a single timeline.

    Files that already existed before entry are ignored — they belong to
    earlier runs.
    """

    def __init__(
        self,
        hub_url: str,
        *,
        agent: str | None = None,
        item_id: int | None = None,
        run_id: str | None = None,
        cwd: Path | None = None,
    ) -> None:
        self.hub_url = hub_url
        self.agent = agent
        self.item_id = item_id
        self.run_id = run_id
        self.project_dir = project_dir_for_cwd(cwd or Path.cwd())

        self._known: set[Path] = set()
        self._handles: dict[Path, IO[str]] = {}
        self._seqs: dict[str, int] = {}
        self._buffers: dict[str, list[dict]] = {}

        # Phase events buffered until the first Claude JSONL appears (binds
        # them to the same session_id). If no JSONL ever appears, we emit
        # them under a synthetic session at shutdown.
        self._tracer_session_id: str | None = None
        self._pending_phase: list[str] = []

        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "TraceWatcher":
        if self.project_dir.exists():
            self._known = set(self.project_dir.glob("*.jsonl"))
        self._client = httpx.AsyncClient(base_url=self.hub_url, timeout=10)
        self._task = asyncio.create_task(self._loop(), name="waffle-trace-watcher")
        return self

    async def __aexit__(self, *_exc) -> None:
        self._stop.set()
        if self._task is not None:
            try:
                await self._task
            except Exception:
                logger.exception("trace watcher loop crashed during shutdown")
        # Final scan + flush so we don't lose the last lines.
        try:
            self._scan_for_new_files()
            self._read_all_open_files()
            self._drain_pending_phase_to_session()
            if self._client is not None:
                await self._flush_buffers(self._client)
        except Exception:
            logger.exception("final trace flush failed")
        for handle in self._handles.values():
            try:
                handle.close()
            except OSError:
                pass
        if self._client is not None:
            await self._client.aclose()

    async def _loop(self) -> None:
        assert self._client is not None
        last_flush = asyncio.get_event_loop().time()
        while not self._stop.is_set():
            try:
                self._scan_for_new_files()
                self._read_all_open_files()
                now = asyncio.get_event_loop().time()
                if now - last_flush >= BATCH_FLUSH_INTERVAL_SECONDS:
                    await self._flush_buffers(self._client)
                    last_flush = now
            except Exception:
                logger.exception("trace watcher iteration failed")
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=POLL_INTERVAL_SECONDS)
            except asyncio.TimeoutError:
                pass

    def _scan_for_new_files(self) -> None:
        if not self.project_dir.exists():
            return
        current = set(self.project_dir.glob("*.jsonl"))
        for path in current - self._known:
            try:
                handle = open(path, "r", encoding="utf-8")
            except OSError:
                continue
            self._handles[path] = handle
            self._known.add(path)
            logger.info("watching new session file: %s", path.name)
            # Bind pending phase events to the first session that appears so
            # phase + Claude events share a timeline.
            if self._tracer_session_id is None:
                self._tracer_session_id = path.stem
                self._drain_pending_phase_to_session()

    def _read_all_open_files(self) -> None:
        # Each Claude JSONL keeps its own session_id (= file stem) so that the
        # Waffle session_id is always 1:1 with Claude Code's on-disk file.
        # Cross-session aggregation per run happens via run_id, not by merging.
        for path, handle in list(self._handles.items()):
            session_id = path.stem
            while True:
                pos = handle.tell()
                line = handle.readline()
                if not line:
                    break
                if not line.endswith("\n"):
                    handle.seek(pos)
                    break
                line = line.rstrip("\n")
                if not line:
                    continue
                self._buffers.setdefault(session_id, []).append(
                    {"seq": self._next_seq(session_id), "raw_line": line}
                )

    def _next_seq(self, session_id: str) -> int:
        s = self._seqs.get(session_id, 0)
        self._seqs[session_id] = s + 1
        return s

    async def _flush_buffers(self, client: httpx.AsyncClient) -> None:
        for session_id, lines in list(self._buffers.items()):
            if not lines:
                continue
            self._buffers[session_id] = []
            try:
                await client.post(
                    f"/traces/{session_id}/events",
                    json={
                        "item_id": self.item_id,
                        "agent": self.agent,
                        "run_id": self.run_id,
                        "lines": lines,
                    },
                )
            except Exception:
                logger.exception("trace flush failed; re-buffering %d lines", len(lines))
                self._buffers.setdefault(session_id, [])[:0] = lines

    # -- phase event API (used by Tracer) ---------------------------------

    def post_phase(self, subtype: str, **data: Any) -> None:
        """Buffer a non-Claude phase event into the active session timeline.

        Synchronous — only mutates in-memory buffers; the watcher loop flushes
        them to the hub on its next tick.
        """
        line = json.dumps({
            "type": "system",
            "subtype": subtype,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **data,
        })
        if self._tracer_session_id is None:
            self._pending_phase.append(line)
            return
        sid = self._tracer_session_id
        self._buffers.setdefault(sid, []).append(
            {"seq": self._next_seq(sid), "raw_line": line}
        )

    def _drain_pending_phase_to_session(self) -> None:
        """Move buffered pre-session phase events into the current session.

        If `__aexit__` runs without ever seeing a Claude JSONL, we still want
        the phase events on the hub — emit them under a synthetic session id.
        """
        if not self._pending_phase:
            return
        if self._tracer_session_id is None:
            self._tracer_session_id = f"phase-{uuid.uuid4()}"
        sid = self._tracer_session_id
        for line in self._pending_phase:
            self._buffers.setdefault(sid, []).append(
                {"seq": self._next_seq(sid), "raw_line": line}
            )
        self._pending_phase = []


class Tracer:
    """Handler-facing API for logging non-Claude phase events into the same
    session timeline as Claude messages.

    A no-op when constructed without a watcher (e.g. `--no-trace` mode).
    """

    def __init__(self, watcher: TraceWatcher | None) -> None:
        self._watcher = watcher

    async def log(self, subtype: str, **data: Any) -> None:
        if self._watcher is None:
            return
        try:
            self._watcher.post_phase(subtype, **data)
        except Exception:
            logger.exception("tracer log failed for subtype=%s", subtype)
