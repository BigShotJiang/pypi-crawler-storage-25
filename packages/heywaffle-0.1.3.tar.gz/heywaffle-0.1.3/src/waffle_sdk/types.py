import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Awaitable, Callable

if TYPE_CHECKING:
    from .trace import Tracer


def _default_tracer() -> "Tracer":
    from .trace import Tracer
    return Tracer(None)


@dataclass
class AgentContext:
    logger: logging.Logger
    model: str | None = None
    tracer: "Tracer" = field(default_factory=_default_tracer)


Handler = Callable[[dict[str, Any], AgentContext], Awaitable[dict[str, Any]]]
