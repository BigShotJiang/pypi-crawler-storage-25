import asyncio
import logging
from datetime import UTC, datetime

from croniter import croniter
from sqlmodel import Session, select

from .db import engine
from .models import CronTrigger, InboxItem
from .pubsub import pubsub, ui_events

logger = logging.getLogger("waffle.scheduler")

DEFAULT_TICK_SECONDS = 30


async def scheduler_loop(tick_seconds: int = DEFAULT_TICK_SECONDS) -> None:
    logger.info("scheduler loop starting (tick=%ss)", tick_seconds)
    while True:
        try:
            await tick()
        except Exception:
            logger.exception("scheduler tick failed")
        await asyncio.sleep(tick_seconds)


async def tick(now: datetime | None = None) -> list[int]:
    if now is None:
        now = datetime.now(UTC)
    enqueued_ids: list[int] = []

    with Session(engine) as session:
        triggers = session.exec(
            select(CronTrigger).where(CronTrigger.enabled == True)  # noqa: E712
        ).all()

        for trigger in triggers:
            base = _aware(trigger.last_run_at) or _aware(trigger.created_at)
            try:
                next_due = croniter(trigger.schedule, base).get_next(datetime)
            except Exception:
                logger.warning(
                    "invalid cron schedule for trigger id=%s: %r", trigger.id, trigger.schedule
                )
                continue
            next_due = _aware(next_due)
            if next_due is None or next_due > now:
                continue

            key = f"cron-{trigger.id}-{int(next_due.timestamp())}"
            existing = session.exec(
                select(InboxItem).where(
                    InboxItem.source == trigger.source,
                    InboxItem.idempotency_key == key,
                    InboxItem.agent == trigger.agent,
                )
            ).first()
            if existing is None:
                item = InboxItem(
                    agent=trigger.agent,
                    source=trigger.source,
                    payload=trigger.payload,
                    idempotency_key=key,
                )
                session.add(item)
                session.flush()
                enqueued_ids.append(item.id)  # type: ignore[arg-type]

            trigger.last_run_at = next_due
            session.add(trigger)

        session.commit()

    for item_id in enqueued_ids:
        # We need the agent for publish; refetch minimally.
        with Session(engine) as session:
            item = session.get(InboxItem, item_id)
            if item is not None:
                await pubsub.publish(item.agent, item.id)  # type: ignore[arg-type]
                await ui_events.publish({
                    "type": "item.created",
                    "agent": item.agent,
                    "item_id": item.id,
                    "source": item.source,
                })

    return enqueued_ids


def _aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt
