from datetime import UTC, datetime
from enum import Enum
from typing import Any

from sqlalchemy import JSON, Column, UniqueConstraint
from sqlmodel import Field, SQLModel


def _now() -> datetime:
    return datetime.now(UTC)


class ItemStatus(str, Enum):
    PENDING = "pending"
    CLAIMED = "claimed"
    COMPLETED = "completed"
    FAILED = "failed"
    DEADLETTER = "deadletter"


class Agent(SQLModel, table=True):
    name: str = Field(primary_key=True)
    project: str = Field(default="default", index=True)
    description: str | None = None
    model: str | None = None
    concurrency: int = Field(default=1)
    first_seen_at: datetime = Field(default_factory=_now)
    last_seen_at: datetime = Field(default_factory=_now)


class Subscription(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    agent: str = Field(index=True)
    source: str = Field(index=True)
    filter: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    enabled: bool = Field(default=True, index=True)
    created_at: datetime = Field(default_factory=_now)


class TraceEvent(SQLModel, table=True):
    __table_args__ = (
        UniqueConstraint("session_id", "seq", name="uq_trace_session_seq"),
    )

    id: int | None = Field(default=None, primary_key=True)
    session_id: str = Field(index=True)
    # One agent handler invocation = one run_id. A run can include several
    # session_ids (one per ClaudeSDKClient JSONL + an optional phase-* synth
    # session). NULL on legacy rows from before run-aware SDKs.
    run_id: str | None = Field(default=None, index=True)
    item_id: int | None = Field(default=None, foreign_key="inboxitem.id", index=True)
    agent: str | None = Field(default=None, index=True)
    seq: int  # monotonic per session, assigned by sender
    raw_line: str  # the raw JSONL line as written by Claude Code
    received_at: datetime = Field(default_factory=_now)


class CronTrigger(SQLModel, table=True):
    __table_args__ = (
        UniqueConstraint("agent", "schedule", "source", name="uq_cron_dedupe"),
    )

    id: int | None = Field(default=None, primary_key=True)
    agent: str = Field(index=True)
    schedule: str  # cron expression, evaluated by croniter
    source: str = Field(default="cron", index=True)  # passed through to inbox item
    payload: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    enabled: bool = Field(default=True, index=True)
    last_run_at: datetime | None = None
    created_at: datetime = Field(default_factory=_now)


class InboxItem(SQLModel, table=True):
    __table_args__ = (
        UniqueConstraint("source", "idempotency_key", "agent", name="uq_inbox_dedupe"),
    )

    id: int | None = Field(default=None, primary_key=True)
    agent: str = Field(index=True)
    source: str = Field(index=True)
    payload: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    idempotency_key: str = Field(index=True)
    status: ItemStatus = Field(default=ItemStatus.PENDING, index=True)
    attempts: int = 0
    claimed_by: str | None = None
    claimed_at: datetime | None = None
    completed_at: datetime | None = None
    last_error: str | None = None
    result: dict[str, Any] | None = Field(default=None, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=_now)


class WebhookDelivery(SQLModel, table=True):
    """Every incoming POST /webhooks/<source> is logged here, regardless of
    whether any Subscription matched. Read-only audit log used by the
    Webhooks view to help users discover what providers are sending so
    they can write subscription filters without guesswork.
    """

    id: int | None = Field(default=None, primary_key=True)
    source: str = Field(index=True)
    payload: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    headers: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    idempotency_key: str = Field(index=True)
    matched_agents: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    received_at: datetime = Field(default_factory=_now, index=True)
