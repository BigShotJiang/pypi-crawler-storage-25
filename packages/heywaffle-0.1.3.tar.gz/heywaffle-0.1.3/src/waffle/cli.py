import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(prog="waffle")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()

    # The hub-side dependencies (fastapi, uvicorn, sqlmodel, …) live behind
    # the `[hub]` extra so agents that only use `waffle_sdk` don't have to
    # install the whole web stack. Fail with a clear message when any of
    # them is missing — eagerly probe every import the server needs so a
    # half-provisioned venv (e.g. after a distribution rename) doesn't fall
    # over with a mid-flight ImportError once uvicorn hands control off.
    missing: list[str] = []
    for mod in ("uvicorn", "fastapi", "sqlmodel", "croniter", "sse_starlette", "jinja2"):
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    if missing:
        sys.stderr.write(
            f"error: running the waffle hub needs the 'hub' extras "
            f"(missing: {', '.join(missing)}).\n"
            f"  pip install 'heywaffle[hub]'\n"
            f"  # or, with poetry in this repo:\n"
            f"  poetry install --extras hub\n"
        )
        sys.exit(1)
    import uvicorn

    uvicorn.run(
        "waffle.server:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
