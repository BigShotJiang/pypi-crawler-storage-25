import asyncio
import hashlib
import json
import logging
import os
import uuid
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Any

from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy import delete
from sqlmodel import Session, select
from sse_starlette.sse import EventSourceResponse

from .db import engine, init_db
from .filtering import first_mismatch, matches
from .models import (
    Agent,
    CronTrigger,
    InboxItem,
    ItemStatus,
    Subscription,
    TraceEvent,
    WebhookDelivery,
)
from .pubsub import SyncFailed, activity, pubsub, ui_events, waiters
from .scheduler import scheduler_loop
from .ui.router import router as ui_router

MAX_ATTEMPTS = 3
SSE_HEARTBEAT_SECONDS = 15
SYNC_DEFAULT_TIMEOUT = 300.0
TRACE_BUSY_TTL_SECONDS = 4.0  # how long an agent stays "busy" after its last trace line

_CORS_ORIGINS: list[str] = [
    o.strip() for o in os.getenv("WAFFLE_CORS_ORIGINS", "").split(",") if o.strip()
]
_API_TOKEN: str | None = (os.getenv("WAFFLE_API_TOKEN", "").strip() or None)

logger = logging.getLogger("waffle.server")


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    task = asyncio.create_task(scheduler_loop(), name="waffle-scheduler")
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(title="Waffle", lifespan=lifespan)

if _CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_CORS_ORIGINS,
        allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "Idempotency-Key"],
        allow_credentials=False,
    )

_STATIC_DIR = Path(__file__).resolve().parent.parent.parent / "static"
if _STATIC_DIR.is_dir():
    app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")

app.include_router(ui_router)


def _require_api_token(authorization: str | None = Header(default=None)) -> None:
    """Guard for endpoints that are reachable from the public internet.

    If WAFFLE_API_TOKEN is unset at process start, the check is a no-op
    (dev / localhost-only). When set, callers must send
    `Authorization: Bearer <token>`; mismatch returns 401.
    """
    if _API_TOKEN is None:
        return
    expected = f"Bearer {_API_TOKEN}"
    if authorization != expected:
        raise HTTPException(status_code=401, detail="invalid or missing bearer token")


def get_session():
    with Session(engine) as session:
        yield session


# ---------------------------------------------------------------------------
# Agents + projects
# ---------------------------------------------------------------------------

class SubscriptionSpec(BaseModel):
    source: str
    filter: dict[str, Any] = {}


class CronSpec(BaseModel):
    schedule: str
    source: str = "cron"
    payload: dict[str, Any] = {}
    enabled: bool = True


class AgentRegister(BaseModel):
    name: str
    project: str = "default"
    description: str | None = None
    model: str | None = None
    concurrency: int = 1
    subscriptions: list[SubscriptionSpec] | None = None
    crons: list[CronSpec] | None = None


def _sub_key(source: str, filter_: dict[str, Any]) -> tuple[str, str]:
    return (source, json.dumps(filter_, sort_keys=True, ensure_ascii=False))


def _cron_key(schedule: str, source: str) -> tuple[str, str]:
    return (schedule, source)


@app.post("/agents/register", response_model=Agent)
async def register_agent(body: AgentRegister, session: Session = Depends(get_session)) -> Agent:
    existing = session.get(Agent, body.name)
    now = datetime.now(UTC)
    was_new = existing is None
    old_project = existing.project if existing else None
    if existing is not None:
        existing.project = body.project or "default"
        existing.description = body.description
        existing.model = body.model
        existing.concurrency = max(1, body.concurrency)
        existing.last_seen_at = now
        session.add(existing)
        session.commit()
        session.refresh(existing)
        agent = existing
    else:
        agent = Agent(
            name=body.name,
            project=body.project or "default",
            description=body.description,
            model=body.model,
            concurrency=max(1, body.concurrency),
        )
        session.add(agent)
        session.commit()
        session.refresh(agent)

    # Reconcile subscriptions if the agent declared them. ``None`` means
    # "don't touch" (for manual/partial registrations); an explicit empty
    # list clears subscriptions.
    if body.subscriptions is not None:
        existing_subs = list(
            session.exec(select(Subscription).where(Subscription.agent == body.name)).all()
        )
        wanted_keys = {_sub_key(s.source, s.filter) for s in body.subscriptions}
        existing_by_key = {_sub_key(s.source, s.filter): s for s in existing_subs}
        for key, sub in existing_by_key.items():
            if key not in wanted_keys:
                session.delete(sub)
        for spec in body.subscriptions:
            k = _sub_key(spec.source, spec.filter)
            if k not in existing_by_key:
                session.add(Subscription(
                    agent=body.name, source=spec.source, filter=spec.filter,
                ))
            # existing subscription with matching filter: leave its `enabled`
            # flag alone so a runtime pause survives a restart.
        session.commit()

    if body.crons is not None:
        existing_crons = list(
            session.exec(select(CronTrigger).where(CronTrigger.agent == body.name)).all()
        )
        wanted_keys_cron = {_cron_key(c.schedule, c.source) for c in body.crons}
        existing_by_key_cron = {_cron_key(c.schedule, c.source): c for c in existing_crons}
        for key, cron in existing_by_key_cron.items():
            if key not in wanted_keys_cron:
                session.delete(cron)
        for spec in body.crons:
            k = _cron_key(spec.schedule, spec.source)
            existing_cron = existing_by_key_cron.get(k)
            if existing_cron is None:
                session.add(CronTrigger(
                    agent=body.name,
                    schedule=spec.schedule,
                    source=spec.source,
                    payload=spec.payload,
                    enabled=spec.enabled,
                ))
            else:
                # Keep last_run_at; refresh mutable fields (payload, enabled).
                existing_cron.payload = spec.payload
                existing_cron.enabled = spec.enabled
                session.add(existing_cron)
        session.commit()

    if was_new or old_project != agent.project:
        await ui_events.publish({
            "type": "agent.registered",
            "agent": agent.name,
            "project": agent.project,
            "is_new": was_new,
        })
    return agent


@app.get("/agents", response_model=list[Agent])
def list_agents(
    project: str | None = None,
    session: Session = Depends(get_session),
) -> list[Agent]:
    query = select(Agent)
    if project:
        query = query.where(Agent.project == project)
    return list(session.exec(query.order_by(Agent.name)).all())


@app.get("/projects")
def list_projects(session: Session = Depends(get_session)) -> list[dict[str, Any]]:
    agents = list(session.exec(select(Agent)).all())
    grouped: dict[str, list[Agent]] = {}
    for a in agents:
        grouped.setdefault(a.project, []).append(a)
    return [
        {"name": p, "agent_count": len(ags), "agents": [a.name for a in ags]}
        for p, ags in sorted(grouped.items())
    ]


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------

class SubscriptionCreate(BaseModel):
    agent: str
    source: str
    filter: dict[str, Any] = {}


@app.post("/subscriptions/register", response_model=Subscription)
def register_subscription(
    body: SubscriptionCreate,
    session: Session = Depends(get_session),
) -> Subscription:
    existing = session.exec(
        select(Subscription).where(
            Subscription.agent == body.agent,
            Subscription.source == body.source,
        )
    ).all()
    for sub in existing:
        if sub.filter == body.filter:
            return sub

    new = Subscription(agent=body.agent, source=body.source, filter=body.filter)
    session.add(new)
    session.commit()
    session.refresh(new)
    return new


@app.get("/subscriptions", response_model=list[Subscription])
def list_subscriptions(
    agent: str | None = None,
    source: str | None = None,
    session: Session = Depends(get_session),
) -> list[Subscription]:
    query = select(Subscription)
    if agent:
        query = query.where(Subscription.agent == agent)
    if source:
        query = query.where(Subscription.source == source)
    return list(session.exec(query).all())


class EnabledPatch(BaseModel):
    enabled: bool


@app.patch("/subscriptions/{sub_id}", response_model=Subscription)
async def patch_subscription(
    sub_id: int,
    body: EnabledPatch,
    session: Session = Depends(get_session),
) -> Subscription:
    sub = session.get(Subscription, sub_id)
    if sub is None:
        raise HTTPException(status_code=404, detail="subscription not found")
    sub.enabled = body.enabled
    session.add(sub)
    session.commit()
    session.refresh(sub)
    await ui_events.publish({
        "type": "subscription.updated",
        "agent": sub.agent,
        "subscription_id": sub_id,
        "enabled": sub.enabled,
    })
    return sub


@app.patch("/crons/{cron_id}", response_model=CronTrigger)
async def patch_cron(
    cron_id: int,
    body: EnabledPatch,
    session: Session = Depends(get_session),
) -> CronTrigger:
    cron = session.get(CronTrigger, cron_id)
    if cron is None:
        raise HTTPException(status_code=404, detail="cron not found")
    cron.enabled = body.enabled
    session.add(cron)
    session.commit()
    session.refresh(cron)
    await ui_events.publish({
        "type": "cron.updated",
        "agent": cron.agent,
        "cron_id": cron_id,
        "enabled": cron.enabled,
    })
    return cron


# ---------------------------------------------------------------------------
# Cron triggers
# ---------------------------------------------------------------------------

class CronTriggerCreate(BaseModel):
    agent: str
    schedule: str
    source: str = "cron"
    payload: dict[str, Any] = {}
    enabled: bool = True


@app.post("/crons/register", response_model=CronTrigger)
def register_cron(
    body: CronTriggerCreate,
    session: Session = Depends(get_session),
) -> CronTrigger:
    existing = session.exec(
        select(CronTrigger).where(
            CronTrigger.agent == body.agent,
            CronTrigger.schedule == body.schedule,
            CronTrigger.source == body.source,
        )
    ).first()
    if existing is not None:
        existing.payload = body.payload
        existing.enabled = body.enabled
        session.add(existing)
        session.commit()
        session.refresh(existing)
        return existing

    new = CronTrigger(
        agent=body.agent,
        schedule=body.schedule,
        source=body.source,
        payload=body.payload,
        enabled=body.enabled,
    )
    session.add(new)
    session.commit()
    session.refresh(new)
    return new


@app.get("/crons", response_model=list[CronTrigger])
def list_crons(
    agent: str | None = None,
    session: Session = Depends(get_session),
) -> list[CronTrigger]:
    query = select(CronTrigger)
    if agent:
        query = query.where(CronTrigger.agent == agent)
    return list(session.exec(query).all())


# ---------------------------------------------------------------------------
# Webhook receiver
# ---------------------------------------------------------------------------

class WebhookResult(BaseModel):
    enqueued: list[int]
    skipped_duplicates: list[str]
    matched_agents: list[str]


def _idempotency_key(provided: str | None, payload: dict[str, Any]) -> str:
    if provided:
        return provided
    body = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()
    return hashlib.sha256(body).hexdigest()[:32]


_HEADER_REDACT = {
    "authorization",
    "cookie",
    "x-api-key",
    "x-auth-token",
    "proxy-authorization",
}

WEBHOOK_RETENTION_PER_SOURCE = 200


def _safe_headers(headers) -> dict[str, str]:
    out: dict[str, str] = {}
    for k, v in headers.items():
        kl = k.lower()
        out[kl] = "<redacted>" if kl in _HEADER_REDACT else v
    return out


def _trim_deliveries(session: Session, source: str, *, keep: int = WEBHOOK_RETENTION_PER_SOURCE) -> None:
    ids = session.exec(
        select(WebhookDelivery.id)
        .where(WebhookDelivery.source == source)
        .order_by(WebhookDelivery.id.desc())
        .limit(keep)
    ).all()
    if len(ids) < keep:
        return
    min_kept = min(ids)
    session.exec(
        delete(WebhookDelivery).where(
            WebhookDelivery.source == source,
            WebhookDelivery.id < min_kept,
        )
    )


@app.post("/webhooks/{source}", response_model=WebhookResult)
async def receive_webhook(
    source: str,
    payload: dict[str, Any],
    request: Request,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    session: Session = Depends(get_session),
) -> WebhookResult:
    key = _idempotency_key(idempotency_key, payload)

    subs = session.exec(
        select(Subscription).where(
            Subscription.source == source,
            Subscription.enabled == True,  # noqa: E712
        )
    ).all()
    matching = [s for s in subs if matches(s.filter, payload)]
    matched_agents = [s.agent for s in matching]

    if subs and not matching:
        logger = logging.getLogger("waffle.server")
        for sub in subs:
            reason = first_mismatch(sub.filter, payload) or "filter is empty (matches all)"
            logger.warning(
                "webhook source=%r did not match agent=%r — %s",
                source, sub.agent, reason,
            )

    delivery = WebhookDelivery(
        source=source,
        payload=payload,
        headers=_safe_headers(request.headers),
        idempotency_key=key,
        matched_agents=matched_agents,
    )
    session.add(delivery)
    session.flush()
    _trim_deliveries(session, source)

    enqueued_by_agent: list[tuple[str, int]] = []
    skipped: list[str] = []

    for sub in matching:
        existing = session.exec(
            select(InboxItem).where(
                InboxItem.source == source,
                InboxItem.idempotency_key == key,
                InboxItem.agent == sub.agent,
            )
        ).first()
        if existing:
            skipped.append(sub.agent)
            continue
        item = InboxItem(
            agent=sub.agent,
            source=source,
            payload=payload,
            idempotency_key=key,
        )
        session.add(item)
        session.flush()
        enqueued_by_agent.append((sub.agent, item.id))  # type: ignore[arg-type]

    session.commit()

    await ui_events.publish({
        "type": "delivery.created",
        "source": source,
        "delivery_id": delivery.id,
        "matched_count": len(matched_agents),
    })

    for agent, item_id in enqueued_by_agent:
        await pubsub.publish(agent, item_id)
        await ui_events.publish({
            "type": "item.created",
            "agent": agent,
            "item_id": item_id,
            "source": source,
        })

    return WebhookResult(
        enqueued=[item_id for _, item_id in enqueued_by_agent],
        skipped_duplicates=skipped,
        matched_agents=matched_agents,
    )


@app.get("/webhooks/{source}/deliveries", response_model=list[WebhookDelivery])
def list_deliveries(
    source: str,
    limit: int = Query(default=10, le=200),
    session: Session = Depends(get_session),
) -> list[WebhookDelivery]:
    return list(
        session.exec(
            select(WebhookDelivery)
            .where(WebhookDelivery.source == source)
            .order_by(WebhookDelivery.received_at.desc())  # type: ignore[union-attr]
            .limit(limit)
        ).all()
    )


# ---------------------------------------------------------------------------
# Inbox
# ---------------------------------------------------------------------------

@app.get("/inbox/{agent}", response_model=list[InboxItem])
def list_inbox(
    agent: str,
    status: ItemStatus | None = Query(default=None),
    session: Session = Depends(get_session),
) -> list[InboxItem]:
    query = select(InboxItem).where(InboxItem.agent == agent)
    if status:
        query = query.where(InboxItem.status == status)
    return list(session.exec(query.order_by(InboxItem.id)).all())


class ClaimRequest(BaseModel):
    runner: str = "default"


@app.post("/inbox/{agent}/claim/{item_id}", response_model=InboxItem)
async def claim_item(
    agent: str,
    item_id: int,
    body: ClaimRequest = ClaimRequest(),
    session: Session = Depends(get_session),
) -> InboxItem:
    item = session.get(InboxItem, item_id)
    if not item or item.agent != agent:
        raise HTTPException(status_code=404, detail="item not found")
    if item.status != ItemStatus.PENDING:
        raise HTTPException(
            status_code=409,
            detail=f"item is {item.status.value}, only pending items can be claimed",
        )
    item.status = ItemStatus.CLAIMED
    item.claimed_by = body.runner
    item.claimed_at = datetime.now(UTC)
    item.attempts += 1
    session.add(item)
    session.commit()
    session.refresh(item)

    await activity.claim_started(agent)
    await ui_events.publish({
        "type": "item.updated",
        "agent": agent,
        "item_id": item_id,
        "status": item.status.value,
    })
    return item


class CompleteRequest(BaseModel):
    result: dict[str, Any] | None = None


@app.post("/inbox/{agent}/complete/{item_id}")
async def complete_item(
    agent: str,
    item_id: int,
    body: CompleteRequest = CompleteRequest(),
    session: Session = Depends(get_session),
) -> dict[str, Any]:
    item = session.get(InboxItem, item_id)
    if not item or item.agent != agent:
        raise HTTPException(status_code=404, detail="item not found")
    if item.status != ItemStatus.CLAIMED:
        raise HTTPException(
            status_code=409,
            detail=f"item is {item.status.value}, only claimed items can be completed",
        )
    item.status = ItemStatus.COMPLETED
    item.completed_at = datetime.now(UTC)
    item.result = body.result
    session.add(item)
    session.commit()

    waiters.resolve(item_id, {"item_id": item_id, "result": body.result})
    await activity.claim_ended(agent)
    await ui_events.publish({
        "type": "item.updated",
        "agent": agent,
        "item_id": item_id,
        "status": item.status.value,
    })
    return {"status": item.status.value}


class FailRequest(BaseModel):
    error: str = ""


@app.post("/inbox/{agent}/fail/{item_id}")
async def fail_item(
    agent: str,
    item_id: int,
    body: FailRequest = FailRequest(),
    session: Session = Depends(get_session),
) -> dict[str, Any]:
    item = session.get(InboxItem, item_id)
    if not item or item.agent != agent:
        raise HTTPException(status_code=404, detail="item not found")
    if item.status != ItemStatus.CLAIMED:
        raise HTTPException(
            status_code=409,
            detail=f"item is {item.status.value}, only claimed items can be failed",
        )
    item.last_error = body.error
    if item.attempts >= MAX_ATTEMPTS:
        item.status = ItemStatus.DEADLETTER
    else:
        item.status = ItemStatus.PENDING
        item.claimed_by = None
        item.claimed_at = None
    session.add(item)
    session.commit()

    await activity.claim_ended(agent)
    if item.status == ItemStatus.PENDING:
        await pubsub.publish(agent, item.id)  # type: ignore[arg-type]
    elif item.status == ItemStatus.DEADLETTER:
        waiters.reject(item_id, {
            "item_id": item_id,
            "attempts": item.attempts,
            "last_error": item.last_error,
        })

    await ui_events.publish({
        "type": "item.updated",
        "agent": agent,
        "item_id": item_id,
        "status": item.status.value,
    })
    return {"status": item.status.value, "attempts": item.attempts}


# ---------------------------------------------------------------------------
# Synchronous API invoke
# ---------------------------------------------------------------------------

@app.post("/api/invoke/{agent}", dependencies=[Depends(_require_api_token)])
async def invoke_sync(
    agent: str,
    payload: dict[str, Any],
    timeout: float = SYNC_DEFAULT_TIMEOUT,
    session: Session = Depends(get_session),
) -> Any:
    if not pubsub.has_subscribers(agent):
        raise HTTPException(
            status_code=503,
            detail=f"no agent '{agent}' currently connected to the hub",
        )

    item = InboxItem(
        agent=agent,
        source="api",
        payload=payload,
        idempotency_key=f"api-{uuid.uuid4().hex}",
    )
    session.add(item)
    session.commit()
    session.refresh(item)
    item_id = item.id  # type: ignore[assignment]

    future = waiters.register(item_id)
    await pubsub.publish(agent, item_id)

    try:
        result = await asyncio.wait_for(future, timeout=timeout)
        return result
    except asyncio.TimeoutError:
        waiters.unregister(item_id)
        raise HTTPException(
            status_code=504,
            detail=f"agent '{agent}' did not complete item {item_id} within {timeout}s",
        )
    except SyncFailed as exc:
        raise HTTPException(status_code=502, detail=exc.payload)


# ---------------------------------------------------------------------------
# UI event stream
# ---------------------------------------------------------------------------

@app.get("/api/events")
async def ui_event_stream(
    agent: str | None = None,
    session_id: str | None = None,
    run_id: str | None = None,
):
    """Broadcast SSE stream for UI state changes.

    Optional filters narrow the feed to a specific agent, session, or run.
    Each event is emitted as a typed SSE (`event: item.created`,
    `event: trace.event`, …) with a JSON body.
    """

    filter_: dict[str, Any] = {}
    if agent:
        filter_["agent"] = agent
    if session_id:
        filter_["session_id"] = session_id
    if run_id:
        filter_["run_id"] = run_id

    async def event_generator():
        queue = ui_events.subscribe(filter_)
        try:
            # Let the client know the stream opened successfully.
            yield {"event": "connected", "data": json.dumps(filter_)}
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=SSE_HEARTBEAT_SECONDS)
                    yield {"event": event["type"], "data": json.dumps(event)}
                except asyncio.TimeoutError:
                    yield {"event": "ping", "data": ""}
        finally:
            ui_events.unsubscribe(queue)

    return EventSourceResponse(event_generator())


# ---------------------------------------------------------------------------
# SSE inbox stream
# ---------------------------------------------------------------------------

@app.get("/inbox/{agent}/stream")
async def stream_inbox(agent: str):
    async def event_generator():
        with Session(engine) as session:
            pending = session.exec(
                select(InboxItem)
                .where(
                    InboxItem.agent == agent,
                    InboxItem.status == ItemStatus.PENDING,
                )
                .order_by(InboxItem.id)
            ).all()
            for item in pending:
                yield {"event": "item", "data": json.dumps({"id": item.id})}

        was_empty = not pubsub.has_subscribers(agent)
        queue = pubsub.subscribe(agent)
        if was_empty:
            await ui_events.publish({"type": "agent.connected", "agent": agent})
        try:
            while True:
                try:
                    item_id = await asyncio.wait_for(
                        queue.get(), timeout=SSE_HEARTBEAT_SECONDS
                    )
                    yield {"event": "item", "data": json.dumps({"id": item_id})}
                except asyncio.TimeoutError:
                    yield {"event": "ping", "data": ""}
        finally:
            pubsub.unsubscribe(agent, queue)
            if not pubsub.has_subscribers(agent):
                await ui_events.publish({"type": "agent.disconnected", "agent": agent})

    return EventSourceResponse(event_generator())


# ---------------------------------------------------------------------------
# Traces
# ---------------------------------------------------------------------------

class TraceLine(BaseModel):
    seq: int
    raw_line: str


class TraceBatch(BaseModel):
    item_id: int | None = None
    agent: str | None = None
    run_id: str | None = None
    lines: list[TraceLine]


@app.post("/traces/{session_id}/events")
async def ingest_trace_events(
    session_id: str,
    body: TraceBatch,
    session: Session = Depends(get_session),
) -> dict[str, Any]:
    written = 0
    for line in body.lines:
        existing = session.exec(
            select(TraceEvent).where(
                TraceEvent.session_id == session_id,
                TraceEvent.seq == line.seq,
            )
        ).first()
        if existing is not None:
            continue
        event = TraceEvent(
            session_id=session_id,
            run_id=body.run_id,
            item_id=body.item_id,
            agent=body.agent,
            seq=line.seq,
            raw_line=line.raw_line,
        )
        session.add(event)
        written += 1
    session.commit()

    if written:
        await activity.trace_touched(body.agent)
        await ui_events.publish({
            "type": "trace.event",
            "session_id": session_id,
            "run_id": body.run_id,
            "agent": body.agent,
            "item_id": body.item_id,
            "written": written,
        })
    return {"written": written, "session_id": session_id}


class TraceSummary(BaseModel):
    session_id: str
    agent: str | None
    item_id: int | None
    event_count: int
    first_received_at: datetime
    last_received_at: datetime


@app.get("/traces", response_model=list[TraceSummary])
def list_traces(
    agent: str | None = None,
    session: Session = Depends(get_session),
) -> list[TraceSummary]:
    query = select(TraceEvent)
    if agent:
        query = query.where(TraceEvent.agent == agent)
    events = list(session.exec(query.order_by(TraceEvent.session_id, TraceEvent.seq)).all())
    grouped: dict[str, list[TraceEvent]] = {}
    for ev in events:
        grouped.setdefault(ev.session_id, []).append(ev)
    summaries = []
    for sid, evs in grouped.items():
        summaries.append(
            TraceSummary(
                session_id=sid,
                agent=evs[0].agent,
                item_id=evs[0].item_id,
                event_count=len(evs),
                first_received_at=min(e.received_at for e in evs),
                last_received_at=max(e.received_at for e in evs),
            )
        )
    summaries.sort(key=lambda s: s.last_received_at, reverse=True)
    return summaries


@app.get("/traces/{session_id}", response_model=list[TraceEvent])
def get_trace(
    session_id: str,
    session: Session = Depends(get_session),
) -> list[TraceEvent]:
    query = (
        select(TraceEvent)
        .where(TraceEvent.session_id == session_id)
        .order_by(TraceEvent.seq)
    )
    return list(session.exec(query).all())


@app.get("/")
def root() -> dict[str, str]:
    return {"name": "Waffle", "status": "ok"}
