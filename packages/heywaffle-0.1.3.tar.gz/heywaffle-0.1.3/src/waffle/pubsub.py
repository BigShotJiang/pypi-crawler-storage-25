import asyncio
from collections import defaultdict
from typing import Any


class InboxPubSub:
    def __init__(self) -> None:
        self._subs: dict[str, set[asyncio.Queue[int]]] = defaultdict(set)

    def subscribe(self, agent: str) -> asyncio.Queue[int]:
        q: asyncio.Queue[int] = asyncio.Queue()
        self._subs[agent].add(q)
        return q

    def unsubscribe(self, agent: str, q: asyncio.Queue[int]) -> None:
        self._subs[agent].discard(q)

    async def publish(self, agent: str, item_id: int) -> None:
        for q in list(self._subs[agent]):
            await q.put(item_id)

    def has_subscribers(self, agent: str) -> bool:
        return bool(self._subs.get(agent))

    def connected_agents(self) -> set[str]:
        return {name for name, subs in self._subs.items() if subs}


pubsub = InboxPubSub()


class SyncWaiters:
    """In-process registry of futures waiting for an inbox item to complete.

    Used by the sync /api/invoke endpoint to suspend a request until the agent
    finishes the item it just queued. Survives only within one process — not
    suitable for multi-worker deployments.
    """

    def __init__(self) -> None:
        self._waiters: dict[int, asyncio.Future[dict[str, Any]]] = {}

    def register(self, item_id: int) -> asyncio.Future[dict[str, Any]]:
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        self._waiters[item_id] = future
        return future

    def unregister(self, item_id: int) -> None:
        self._waiters.pop(item_id, None)

    def resolve(self, item_id: int, payload: dict[str, Any]) -> None:
        fut = self._waiters.pop(item_id, None)
        if fut and not fut.done():
            fut.set_result(payload)

    def reject(self, item_id: int, payload: dict[str, Any]) -> None:
        fut = self._waiters.pop(item_id, None)
        if fut and not fut.done():
            fut.set_exception(SyncFailed(payload))


class SyncFailed(Exception):
    def __init__(self, payload: dict[str, Any]) -> None:
        super().__init__(payload.get("last_error") or "agent reported failure")
        self.payload = payload


waiters = SyncWaiters()


class AgentActivity:
    """Tracks whether each agent is currently *busy* — either holding one or
    more claimed inbox items, or recently emitting trace lines (once mode).
    Emits agent.busy / agent.idle broadcast events through ui_events when
    the state flips so the sidebar health dot can reflect it."""

    TRACE_TTL_SECONDS: float = 4.0

    def __init__(self) -> None:
        self._claims: dict[str, int] = {}
        self._trace_tasks: dict[str, asyncio.Task] = {}
        self._flags: dict[str, bool] = {}

    def _is_busy(self, agent: str) -> bool:
        return self._claims.get(agent, 0) > 0 or agent in self._trace_tasks

    async def _flip(self, agent: str) -> None:
        busy = self._is_busy(agent)
        if self._flags.get(agent, False) == busy:
            return
        self._flags[agent] = busy
        await ui_events.publish({
            "type": "agent.busy" if busy else "agent.idle",
            "agent": agent,
        })

    async def claim_started(self, agent: str) -> None:
        self._claims[agent] = self._claims.get(agent, 0) + 1
        await self._flip(agent)

    async def claim_ended(self, agent: str) -> None:
        self._claims[agent] = max(0, self._claims.get(agent, 0) - 1)
        await self._flip(agent)

    async def trace_touched(self, agent: str | None) -> None:
        if not agent:
            return
        existing = self._trace_tasks.pop(agent, None)
        if existing is not None:
            existing.cancel()

        async def _expire() -> None:
            try:
                await asyncio.sleep(self.TRACE_TTL_SECONDS)
            except asyncio.CancelledError:
                return
            self._trace_tasks.pop(agent, None)
            await self._flip(agent)

        self._trace_tasks[agent] = asyncio.create_task(_expire())
        await self._flip(agent)

    def busy_agents(self) -> set[str]:
        return {a for a, flag in self._flags.items() if flag}


activity = AgentActivity()


class UIEventBus:
    """Broadcast pubsub for UI state-change notifications.

    Each subscriber gets its own queue and an optional filter (matched
    against event fields with simple equality). Event types in
    BROADCAST_TYPES bypass the filter so sidebar-relevant changes reach
    every connected client regardless of what page they are on.
    """

    BROADCAST_TYPES: set[str] = {
        "agent.registered",
        "agent.connected",
        "agent.disconnected",
        "agent.busy",
        "agent.idle",
        "subscription.updated",
        "cron.updated",
    }

    def __init__(self) -> None:
        self._subs: list[tuple[dict[str, Any], asyncio.Queue[dict[str, Any]]]] = []

    def subscribe(self, filter_: dict[str, Any] | None = None) -> asyncio.Queue[dict[str, Any]]:
        q: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._subs.append((filter_ or {}, q))
        return q

    def unsubscribe(self, q: asyncio.Queue[dict[str, Any]]) -> None:
        self._subs = [(f, qq) for f, qq in self._subs if qq is not q]

    async def publish(self, event: dict[str, Any]) -> None:
        for filter_, q in list(self._subs):
            if self._matches(event, filter_):
                await q.put(event)

    @classmethod
    def _matches(cls, event: dict[str, Any], filter_: dict[str, Any]) -> bool:
        if event.get("type") in cls.BROADCAST_TYPES:
            return True
        for key, expected in filter_.items():
            if event.get(key) != expected:
                return False
        return True


ui_events = UIEventBus()
