from typing import Any

_MISSING = object()


def get_path(payload: Any, dotted: str) -> Any:
    cur: Any = payload
    for part in dotted.split("."):
        if not isinstance(cur, dict):
            return _MISSING
        if part not in cur:
            return _MISSING
        cur = cur[part]
    return cur


def matches(filter_def: dict[str, Any], payload: dict[str, Any]) -> bool:
    for key, expected in filter_def.items():
        actual = get_path(payload, key)
        if actual is _MISSING:
            return False
        if isinstance(expected, list):
            if actual not in expected:
                return False
        else:
            if actual != expected:
                return False
    return True


def first_mismatch(filter_def: dict[str, Any], payload: dict[str, Any]) -> str | None:
    """Return a human-readable description of the first key that caused a filter miss, or None if it matches."""
    for key, expected in filter_def.items():
        actual = get_path(payload, key)
        if actual is _MISSING:
            return f"{key!r} not found in payload"
        if isinstance(expected, list):
            if actual not in expected:
                return f"{key!r} = {actual!r}, expected one of {expected!r}"
        else:
            if actual != expected:
                return f"{key!r} = {actual!r}, expected {expected!r}"
    return None
