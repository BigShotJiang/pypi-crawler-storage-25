import os
from collections.abc import Iterator
from pathlib import Path

from sqlmodel import Session, SQLModel, create_engine

DEFAULT_DB_PATH = Path("data/waffle.db")


def _resolve_db_path() -> Path:
    override = os.getenv("WAFFLE_DB_PATH")
    path = Path(override) if override else DEFAULT_DB_PATH
    # Pin to an absolute path at startup so subsequent cwd changes can't
    # silently shift where we read/write.
    return path.resolve()


DB_PATH = _resolve_db_path()
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

engine = create_engine(
    f"sqlite:///{DB_PATH}",
    connect_args={"check_same_thread": False},
)


def init_db() -> None:
    # Import models so SQLModel.metadata sees them.
    from . import models  # noqa: F401

    SQLModel.metadata.create_all(engine)
    _apply_lightweight_migrations()


def _apply_lightweight_migrations() -> None:
    """Additive column migrations for schemas that already exist.

    SQLModel.metadata.create_all only creates missing tables; new columns on
    an already-existing table need an explicit ALTER. Keep this list short
    and idempotent — for anything non-trivial we should reach for alembic.
    """
    from sqlalchemy import text

    with engine.connect() as conn:
        cols = conn.exec_driver_sql("PRAGMA table_info(subscription)").fetchall()
        names = {c[1] for c in cols}
        if "enabled" not in names:
            conn.exec_driver_sql(
                "ALTER TABLE subscription ADD COLUMN enabled BOOLEAN NOT NULL DEFAULT 1"
            )
            conn.commit()

        agent_cols = conn.exec_driver_sql("PRAGMA table_info(agent)").fetchall()
        agent_names = {c[1] for c in agent_cols}
        if "model" not in agent_names:
            conn.exec_driver_sql("ALTER TABLE agent ADD COLUMN model VARCHAR")
            conn.commit()
        if "concurrency" not in agent_names:
            conn.exec_driver_sql(
                "ALTER TABLE agent ADD COLUMN concurrency INTEGER NOT NULL DEFAULT 1"
            )
            conn.commit()

        trace_cols = conn.exec_driver_sql("PRAGMA table_info(traceevent)").fetchall()
        trace_names = {c[1] for c in trace_cols}
        if "run_id" not in trace_names:
            conn.exec_driver_sql("ALTER TABLE traceevent ADD COLUMN run_id VARCHAR")
            conn.exec_driver_sql(
                "CREATE INDEX IF NOT EXISTS ix_traceevent_run_id ON traceevent(run_id)"
            )
            conn.commit()


def get_session() -> Iterator[Session]:
    with Session(engine) as session:
        yield session
