"""Parse Claude Code JSONL session events into UI-friendly shapes.

For each session we build three flat lists:
- ``conversation``: chat-bubble view, only user + assistant text
- ``transcript``: linear timeline of meaningful events (user, assistant, thinking, tool_use)
- ``debug``: every entry with a typed label, including internal Claude Code events

Each event carries:
- ``kind``: stable identifier used for badge + styling
- ``label``: short text shown in the row
- ``seq`` / ``received_at``: bookkeeping from the trace storage
- ``ts``: ISO timestamp from the JSONL entry itself (when available)
- ``duration_ms``: delta from the previous JSONL entry (rough wall time)
- ``in_tokens`` / ``out_tokens``: only for assistant turn-leading events
- ``data``: the (lightly cleaned) source JSON, used for the detail pane

A single JSONL line can produce multiple events (an assistant message with
text + tool_use + thinking blocks → three transcript events).
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any

DEBUG_SKIP_TYPES = {"queue-operation", "file-history-snapshot"}


@dataclass
class RawLine:
    seq: int
    raw_line: str
    received_at: Any


def parse_session(raw_lines: list[RawLine]) -> dict[str, Any]:
    transcript: list[dict[str, Any]] = []
    debug: list[dict[str, Any]] = []

    prev_ts: str = ""
    first_ts: str = ""
    last_ts: str = ""
    turn = 0
    total_in = 0
    total_out = 0
    model_seen: str | None = None

    for raw in raw_lines:
        try:
            data = json.loads(raw.raw_line)
        except json.JSONDecodeError:
            debug.append(_make_event(
                kind="raw", label="(invalid JSON)", seq=raw.seq,
                received_at=raw.received_at, ts="", duration_ms=0,
                data={"raw": raw.raw_line},
            ))
            continue

        ts = data.get("timestamp", "")
        duration_ms = _ts_diff_ms(prev_ts, ts) if prev_ts and ts else 0

        if data.get("type") == "assistant" and (data.get("message") or {}).get("role") == "assistant":
            turn += 1
            msg = data.get("message") or {}
            usage = msg.get("usage") or {}
            if model_seen is None and msg.get("model"):
                model_seen = msg.get("model")
            in_tok = (
                usage.get("input_tokens", 0)
                + usage.get("cache_read_input_tokens", 0)
                + usage.get("cache_creation_input_tokens", 0)
            )
            out_tok = usage.get("output_tokens", 0)
            total_in += in_tok
            total_out += out_tok
        else:
            in_tok = 0
            out_tok = 0

        _add_transcript_events(data, raw, ts, duration_ms, in_tok, out_tok, turn, transcript)
        _add_debug_events(data, raw, ts, duration_ms, in_tok, out_tok, debug)

        if ts:
            if not first_ts:
                first_ts = ts
            last_ts = ts
            prev_ts = ts

    results_by_id: dict[str, dict[str, Any]] = {}
    for ev in transcript:
        if ev["kind"] == "tool_result" and ev.get("tool_use_id"):
            results_by_id[ev["tool_use_id"]] = ev

    conversation = [ev for ev in transcript if ev["kind"] in ("user", "assistant")]

    # Aggregate tool usage for a "tools used" summary at the top of the
    # session view. For the Skill tool specifically, expand to the
    # individual skill name(s) the agent actually invoked — "Skill" on its
    # own is meaningless, "Skill · recipe-scraper" is what the reader wants.
    tool_counts: dict[str, int] = {}
    for ev in transcript:
        if ev["kind"] != "tool_use":
            continue
        key = ev.get("tool_label") or ev.get("name") or "(unknown)"
        tool_counts[key] = tool_counts.get(key, 0) + 1
    tool_usage = [
        {"name": n, "count": c}
        for n, c in sorted(tool_counts.items(), key=lambda kv: (-kv[1], kv[0]))
    ]

    wall_ms = _ts_diff_ms(first_ts, last_ts) if first_ts and last_ts else 0

    return {
        "transcript": transcript,
        "debug": debug,
        "conversation": conversation,
        "results_by_id": results_by_id,
        "tool_usage": tool_usage,
        "stats": {
            "turns": turn,
            "wall_ms": wall_ms,
            "input_tokens": total_in,
            "output_tokens": total_out,
            "raw_count": len(raw_lines),
            "model": model_seen,
            "estimated_cost_usd": estimate_cost(model_seen, total_in, total_out),
        },
    }


# Rough public pricing as of early 2026, per 1M tokens. Sources:
# anthropic.com/pricing. Keep conservative — actual billing uses the real
# rate at request time; this is an estimate surfaced for "is this agent
# expensive?" awareness, not an invoice.
MODEL_PRICES_PER_MTOK: list[tuple[str, float, float]] = [
    ("claude-opus",   15.00, 75.00),
    ("claude-sonnet",  3.00, 15.00),
    ("claude-haiku",   1.00,  5.00),
]


def estimate_cost(model: str | None, in_tokens: int, out_tokens: int) -> float | None:
    if not model or (in_tokens == 0 and out_tokens == 0):
        return None
    for prefix, in_price, out_price in MODEL_PRICES_PER_MTOK:
        if model.startswith(prefix):
            return (in_tokens * in_price + out_tokens * out_price) / 1_000_000
    return None


# ---------------------------------------------------------------------------
# Transcript events
# ---------------------------------------------------------------------------

def _add_transcript_events(
    data: dict[str, Any], raw: RawLine, ts: str, duration_ms: int,
    in_tok: int, out_tok: int, turn: int, out: list[dict[str, Any]],
) -> None:
    t = data.get("type")
    msg = data.get("message") or {}
    role = msg.get("role")
    content = msg.get("content")

    if t == "user" and role == "user":
        if isinstance(content, str) and content.strip():
            out.append(_make_event(
                kind="user", label=_trim(content, 200), text=content,
                seq=raw.seq, received_at=raw.received_at, ts=ts, duration_ms=duration_ms,
                data={"text": content}, turn=turn,
            ))
        elif isinstance(content, list):
            for block in content:
                if not isinstance(block, dict):
                    continue
                bt = block.get("type")
                if bt == "tool_result":
                    text = _stringify_tool_content(block.get("content", ""))
                    is_err = bool(block.get("is_error"))
                    out.append(_make_event(
                        kind="tool_result", label=_trim(text, 200), text=text,
                        tool_use_id=block.get("tool_use_id"), is_error=is_err,
                        seq=raw.seq, received_at=raw.received_at, ts=ts, duration_ms=duration_ms,
                        data=block, turn=turn,
                    ))
                elif bt == "text":
                    text = block.get("text", "")
                    if text.strip():
                        out.append(_make_event(
                            kind="user", label=_trim(text, 200), text=text,
                            seq=raw.seq, received_at=raw.received_at, ts=ts, duration_ms=duration_ms,
                            data={"text": text}, turn=turn,
                        ))
        return

    if t == "assistant" and role == "assistant":
        if not isinstance(content, list):
            return
        first_text = True
        for block in content:
            if not isinstance(block, dict):
                continue
            bt = block.get("type")
            if bt == "text":
                text = block.get("text", "")
                if text.strip():
                    out.append(_make_event(
                        kind="assistant", label=_trim(text, 200), text=text,
                        seq=raw.seq, received_at=raw.received_at, ts=ts, duration_ms=duration_ms,
                        in_tokens=in_tok if first_text else 0,
                        out_tokens=out_tok if first_text else 0,
                        data={"text": text}, turn=turn,
                    ))
                    first_text = False
            elif bt == "thinking":
                thinking = block.get("thinking", "").strip()
                if thinking:
                    out.append(_make_event(
                        kind="thinking", label=_trim(thinking, 200), text=thinking,
                        seq=raw.seq, received_at=raw.received_at, ts=ts, duration_ms=duration_ms,
                        data={"thinking": thinking}, turn=turn,
                    ))
            elif bt == "tool_use":
                name = block.get("name", "")
                inp = block.get("input", {})
                inp_str = json.dumps(inp, ensure_ascii=False)
                # Pretty tool labels:
                #  - Skill calls expand to their named skill ("Skill · X")
                #  - Task tool ("Agent") becomes "Subagent" to avoid clashing
                #    with Waffle's own "agent" concept
                #  - MCP tools "mcp__<server>__<tool>" render as "<server> · <tool>"
                tool_label = name
                if name == "Skill" and isinstance(inp, dict) and inp.get("skill"):
                    tool_label = f"Skill · {inp['skill']}"
                elif name == "Agent":
                    tool_label = "Subagent"
                elif name.startswith("mcp__"):
                    parts = name.split("__", 2)
                    if len(parts) == 3:
                        tool_label = f"{parts[1]} · {parts[2]}"
                out.append(_make_event(
                    kind="tool_use", label=_trim(inp_str, 200),
                    name=name, tool_label=tool_label, input=inp, tool_use_id=block.get("id"),
                    badge=name.upper() if name else "TOOL",
                    seq=raw.seq, received_at=raw.received_at, ts=ts, duration_ms=duration_ms,
                    data=block, turn=turn,
                ))


# ---------------------------------------------------------------------------
# Debug events
# ---------------------------------------------------------------------------

def _add_debug_events(
    data: dict[str, Any], raw: RawLine, ts: str, duration_ms: int,
    in_tok: int, out_tok: int, out: list[dict[str, Any]],
) -> None:
    t = data.get("type", "unknown")
    if t in DEBUG_SKIP_TYPES:
        return

    msg = data.get("message") or {}
    role = msg.get("role")
    content = msg.get("content")
    seq = raw.seq
    received_at = raw.received_at
    clean = _strip_noise(data)

    base = dict(seq=seq, received_at=received_at, ts=ts, duration_ms=duration_ms)

    if t == "permission-mode":
        out.append(_make_event(kind="permission-mode", label=data.get("permissionMode", ""), data=clean, **base))
        return

    if t == "last-prompt":
        out.append(_make_event(kind="last-prompt", label="session idle", data=clean, **base))
        return

    if t == "ai-title":
        out.append(_make_event(kind="ai-title", label=data.get("aiTitle", ""), data=clean, **base))
        return

    if t == "system":
        out.append(_make_event(kind="system", label=data.get("subtype", ""), data=clean, **base))
        return

    if t == "attachment":
        att = data.get("attachment") or {}
        subtype = att.get("type", "attachment")
        # The label is what shows in the row; we compress to a useful
        # one-liner per subtype rather than the full payload.
        if subtype == "mcp_instructions_delta":
            names = att.get("addedNames") or []
            label = f"mcp_instructions_delta · {', '.join(names) or 'no servers'}"
        elif subtype == "deferred_tools_delta":
            added = len(att.get("addedNames") or [])
            removed = len(att.get("removedNames") or [])
            label = f"deferred_tools_delta · +{added} -{removed}"
        elif subtype == "skill_listing":
            count = att.get("skillCount", 0)
            initial = " (initial)" if att.get("isInitial") else ""
            label = f"skill_listing · {count} skills{initial}"
        elif subtype == "todo_reminder":
            label = f"todo_reminder · {att.get('itemCount', 0)} items"
        elif subtype == "command_permissions":
            allowed = len(att.get("allowedTools") or [])
            label = f"command_permissions · {allowed} allowed"
        elif subtype == "structured_output":
            label = "structured_output"
        else:
            label = subtype
        out.append(_make_event(
            kind="attachment", label=label,
            attachment_subtype=subtype, attachment=att,
            data=clean, **base,
        ))
        return

    if t == "result":
        cost = data.get("total_cost_usd")
        turns = data.get("num_turns")
        bits: list[str] = []
        if turns is not None:
            bits.append(f"{turns} turns")
        if cost is not None:
            bits.append(f"${cost:.4f}")
        out.append(_make_event(kind="result", label=", ".join(bits) or "result", data=clean, **base))
        return

    if t == "user" and role == "user":
        if isinstance(content, str) and content.strip():
            # `text` carries the full prompt for the detail pane; `label`
            # is the row preview. Missing `text` here was why agent-side
            # prompts appeared truncated at 200 chars in the Debug view.
            out.append(_make_event(
                kind="user", label=_trim(content, 200), text=content,
                data=clean, **base,
            ))
        elif isinstance(content, list):
            for block in content:
                if not isinstance(block, dict):
                    continue
                bt = block.get("type")
                if bt == "tool_result":
                    text = _stringify_tool_content(block.get("content", ""))
                    is_err = bool(block.get("is_error"))
                    out.append(_make_event(
                        kind="tool_result_error" if is_err else "tool_result",
                        label=_trim(text, 200), text=text,
                        tool_use_id=block.get("tool_use_id"),
                        data={"type": "tool_result", **block},
                        **base,
                    ))
                elif bt == "text":
                    text = block.get("text", "")
                    if text.strip():
                        out.append(_make_event(
                            kind="user", label=_trim(text, 200), text=text,
                            data={"text": text}, **base,
                        ))
        return

    if t == "assistant" and role == "assistant":
        if isinstance(content, list):
            had_text = False
            for block in content:
                if not isinstance(block, dict):
                    continue
                bt = block.get("type")
                if bt == "thinking":
                    thinking = block.get("thinking", "").strip()
                    if thinking:
                        out.append(_make_event(
                            kind="thinking", label=_trim(thinking, 200),
                            data={"thinking": _trim(thinking, 1500)}, **base,
                        ))
                elif bt == "text":
                    text = block.get("text", "")
                    out.append(_make_event(
                        kind="assistant", label=_trim(text, 200),
                        in_tokens=in_tok if not had_text else 0,
                        out_tokens=out_tok if not had_text else 0,
                        data={"text": text}, **base,
                    ))
                    had_text = True
                elif bt == "tool_use":
                    name = block.get("name", "")
                    inp = block.get("input", {})
                    inp_str = json.dumps(inp, ensure_ascii=False)
                    out.append(_make_event(
                        kind="tool_use", label=_trim(inp_str, 200),
                        name=name, badge=name.upper() if name else "TOOL_USE",
                        tool_use_id=block.get("id"), input=inp,
                        data=block, **base,
                    ))
        if in_tok or out_tok:
            usage = msg.get("usage") or {}
            cache_read = usage.get("cache_read_input_tokens", 0)
            cache_write = usage.get("cache_creation_input_tokens", 0)
            label = f"{in_tok} in · {out_tok} out · {cache_read} cache-r · {cache_write} cache-w"
            out.append(_make_event(
                kind="tokens", label=label, data={"usage": usage}, **base,
            ))
        return

    out.append(_make_event(kind="unknown", label=t, data=clean, **base))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_STRIP_KEYS = {
    "uuid", "parentUuid", "isSidechain", "promptId", "requestId",
    "userType", "entrypoint", "cwd", "version", "gitBranch",
    "permissionMode", "sessionId",
}


def _make_event(**fields: Any) -> dict[str, Any]:
    fields.setdefault("badge", fields["kind"].upper())
    fields.setdefault("in_tokens", 0)
    fields.setdefault("out_tokens", 0)
    return fields


def _strip_noise(data: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in data.items() if k not in _STRIP_KEYS}


def _trim(s: str, max_len: int) -> str:
    if not s:
        return ""
    s = s.replace("\n", " ").strip()
    return s if len(s) <= max_len else s[: max_len - 1] + "…"


def _stringify_tool_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict):
                if item.get("type") == "text":
                    parts.append(item.get("text", ""))
                else:
                    parts.append(json.dumps(item, ensure_ascii=False))
            else:
                parts.append(str(item))
        return "\n".join(parts)
    return str(content)


def _ts_diff_ms(a: str, b: str) -> int:
    if not a or not b:
        return 0
    try:
        ta = datetime.fromisoformat(a.replace("Z", "+00:00"))
        tb = datetime.fromisoformat(b.replace("Z", "+00:00"))
        return max(0, int((tb - ta).total_seconds() * 1000))
    except ValueError:
        return 0
