import json
from collections import defaultdict
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from markupsafe import Markup, escape
from sqlmodel import Session, select

from ..db import get_session
from ..models import Agent, CronTrigger, InboxItem, Subscription, TraceEvent, WebhookDelivery
from ..pubsub import activity, pubsub
from .parsing import RawLine, parse_session

TEMPLATES_DIR = Path(__file__).parent / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

VALID_TABS = {"conversation", "transcript", "debug"}
DEFAULT_PROJECT = "default"


def pretty_json(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            return value
    return json.dumps(value, indent=2, ensure_ascii=False)


def humanize(dt: datetime | str | None) -> str:
    if dt is None:
        return "—"
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt)
        except ValueError:
            return dt
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    delta = datetime.now(UTC) - dt
    if delta < timedelta(seconds=60):
        return f"{int(delta.total_seconds())}s ago"
    if delta < timedelta(hours=1):
        return f"{int(delta.total_seconds() // 60)}m ago"
    if delta < timedelta(days=1):
        return f"{int(delta.total_seconds() // 3600)}h ago"
    return dt.strftime("%Y-%m-%d %H:%M")


def fmt_time(value: Any) -> str:
    if not value:
        return ""
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return str(value)
    return dt.strftime("%H:%M:%S")


def fmt_tokens(value: Any) -> str:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return ""
    if n == 0:
        return ""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}k"
    return str(n)


def fmt_duration(value: Any) -> str:
    try:
        ms = int(value)
    except (TypeError, ValueError):
        return ""
    if ms <= 0:
        return ""
    if ms < 1000:
        return f"{ms}ms"
    if ms < 60_000:
        return f"{ms / 1000:.1f}s"
    seconds = ms // 1000
    return f"{seconds // 60}m {seconds % 60}s"


def time_span(value: Any) -> Markup:
    """Render a timestamp that can switch between relative ("3m ago") and
    absolute ("2026-04-22 09:30") at runtime via the JS time-format toggle.

    Emits a <span> with data-ts / data-rel / data-abs so the client swap is
    a no-op server-side until the user flips the toggle.
    """
    if value is None or value == "":
        return Markup('<span class="muted">—</span>')
    if isinstance(value, str):
        try:
            dt = datetime.fromisoformat(value)
        except ValueError:
            return Markup(f"<span>{escape(value)}</span>")
    elif isinstance(value, datetime):
        dt = value
    else:
        return Markup(f"<span>{escape(str(value))}</span>")
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    rel = humanize(dt)
    abs_str = dt.strftime("%Y-%m-%d %H:%M")
    iso = dt.isoformat()
    return Markup(
        f'<span data-ts="{escape(iso)}" data-rel="{escape(rel)}" '
        f'data-abs="{escape(abs_str)}">{escape(rel)}</span>'
    )


def project_color(name: str) -> str:
    """Stable hue per project name. Same letters → same colour so the avatar
    is recognisable across reloads without storing anything."""
    if not name:
        return "hsl(220, 15%, 45%)"
    h = 0
    for c in name:
        h = (h * 31 + ord(c)) & 0xFFFF
    hue = h % 360
    return f"hsl({hue}, 42%, 52%)"


templates.env.filters["pretty_json"] = pretty_json
templates.env.filters["humanize"] = humanize
templates.env.filters["fmt_time"] = fmt_time
templates.env.filters["fmt_tokens"] = fmt_tokens
templates.env.filters["fmt_duration"] = fmt_duration
templates.env.filters["time_span"] = time_span
templates.env.filters["project_color"] = project_color

router = APIRouter()


# ---------------------------------------------------------------------------
# Sidebar context
# ---------------------------------------------------------------------------

def _sidebar_ctx(
    session: Session,
    *,
    current_project: str | None = None,
    selected_agent: str | None = None,
    nav_active: str | None = None,
) -> dict[str, Any]:
    agents = list(session.exec(select(Agent).order_by(Agent.name)).all())
    grouped: dict[str, list[Agent]] = {}
    for a in agents:
        grouped.setdefault(a.project, []).append(a)

    projects = [
        {"name": p, "agent_count": len(ags)}
        for p, ags in sorted(grouped.items())
    ]

    if current_project is None:
        current_project = projects[0]["name"] if projects else DEFAULT_PROJECT

    # Always include the current project in the dropdown so:
    #   (a) the <option> matching the URL is actually `selected`
    #   (b) the user can navigate away to a real project even when the
    #       current one is empty (no agents).
    if current_project not in {p["name"] for p in projects}:
        projects.append({"name": current_project, "agent_count": 0})
        projects.sort(key=lambda p: p["name"])

    project_agents = grouped.get(current_project, [])

    connected = pubsub.connected_agents()
    busy = activity.busy_agents()
    return {
        "projects": projects,
        "current_project": current_project,
        "project_agents": project_agents,
        "connected_agents": connected,
        "busy_agents": busy,
        "selected_agent": selected_agent,
        "nav_active": nav_active,
    }


def _project_of_agent(session: Session, agent_name: str | None) -> str:
    if not agent_name:
        return DEFAULT_PROJECT
    agent = session.get(Agent, agent_name)
    return agent.project if agent else DEFAULT_PROJECT


# ---------------------------------------------------------------------------
# Data helpers
# ---------------------------------------------------------------------------

def _parse_session_invocation(session: Session, session_id: str) -> dict[str, Any] | None:
    """Extract per-session runtime config from the first ~40 JSONL lines.

    Returns None if there's nothing meaningful to show. Fields surfaced:
      - permission_mode / cwd / sdk_version / entrypoint: from the first
        `type: "user"` event (the SDK stamps this metadata on every request)
      - mcp_servers: names from `mcp_instructions_delta` attachments
      - mcp_instructions: trimmed preview of each server's instructions
    """
    first_lines = list(session.exec(
        select(TraceEvent)
        .where(TraceEvent.session_id == session_id)
        .order_by(TraceEvent.seq)
        .limit(40)
    ).all())
    if not first_lines:
        return None

    permission_mode: str | None = None
    cwd: str | None = None
    sdk_version: str | None = None
    entrypoint: str | None = None
    mcp_servers: list[str] = []
    mcp_instructions: list[dict[str, str]] = []

    for ev in first_lines:
        try:
            d = json.loads(ev.raw_line)
        except (json.JSONDecodeError, TypeError):
            continue
        if d.get("type") == "user":
            if permission_mode is None:
                permission_mode = d.get("permissionMode")
            if cwd is None:
                cwd = d.get("cwd")
            if sdk_version is None:
                sdk_version = d.get("version")
            if entrypoint is None:
                entrypoint = d.get("entrypoint")
        att = d.get("attachment") if isinstance(d, dict) else None
        if isinstance(att, dict) and att.get("type") == "mcp_instructions_delta":
            names = att.get("addedNames") or []
            for n in names:
                if n not in mcp_servers:
                    mcp_servers.append(n)
            blocks = att.get("addedBlocks") or []
            for name, block in zip(names, blocks):
                preview = (block or "").strip()
                if len(preview) > 280:
                    preview = preview[:280].rstrip() + "…"
                mcp_instructions.append({"name": name, "preview": preview})

    if permission_mode is None and not mcp_servers:
        return None

    return {
        "permission_mode": permission_mode,
        "cwd": cwd,
        "sdk_version": sdk_version,
        "entrypoint": entrypoint,
        "mcp_servers": mcp_servers,
        "mcp_instructions": mcp_instructions,
    }


def _agent_inbox_ctx(agent: str, session: Session) -> dict[str, Any]:
    agent_row = session.get(Agent, agent)
    items = list(
        session.exec(
            select(InboxItem)
            .where(InboxItem.agent == agent)
            .order_by(InboxItem.id.desc())
            .limit(100)
        ).all()
    )
    item_to_session: dict[int, str] = {}
    if items:
        item_ids = [i.id for i in items if i.id is not None]
        traces = list(
            session.exec(
                select(TraceEvent.item_id, TraceEvent.session_id)
                .where(TraceEvent.item_id.in_(item_ids))
                .distinct()
            ).all()
        )
        for item_id, sid in traces:
            item_to_session[item_id] = sid

    subs = list(session.exec(select(Subscription).where(Subscription.agent == agent)).all())
    crons = list(session.exec(select(CronTrigger).where(CronTrigger.agent == agent)).all())

    # Recent sessions for this agent, aggregated from TraceEvent.
    trace_rows = list(
        session.exec(
            select(TraceEvent)
            .where(TraceEvent.agent == agent)
            .order_by(TraceEvent.id.desc())
            .limit(1000)
        ).all()
    )
    session_map: dict[str, dict[str, Any]] = {}
    for ev in trace_rows:
        s = session_map.setdefault(
            ev.session_id,
            {
                "session_id": ev.session_id,
                "item_id": ev.item_id,
                "event_count": 0,
                "first_seen": ev.received_at,
                "last_seen": ev.received_at,
            },
        )
        s["event_count"] += 1
        if ev.received_at > s["last_seen"]:
            s["last_seen"] = ev.received_at
        if ev.received_at < s["first_seen"]:
            s["first_seen"] = ev.received_at
    agent_sessions = sorted(
        session_map.values(), key=lambda s: s["last_seen"], reverse=True,
    )[:20]

    return {
        "agent": agent,
        "agent_row": agent_row,
        "items": items,
        "item_to_session": item_to_session,
        "subs": subs,
        "crons": crons,
        "agent_sessions": agent_sessions,
    }


def _session_ctx(session_id: str, tab: str, session: Session) -> dict[str, Any] | None:
    raw_events = list(
        session.exec(
            select(TraceEvent)
            .where(TraceEvent.session_id == session_id)
            .order_by(TraceEvent.seq)
        ).all()
    )
    if not raw_events:
        return None

    parsed = parse_session([
        RawLine(seq=e.seq, raw_line=e.raw_line, received_at=e.received_at)
        for e in raw_events
    ])

    related_item = None
    item_id = raw_events[0].item_id
    if item_id is not None:
        related_item = session.get(InboxItem, item_id)

    active_tab = tab if tab in VALID_TABS else "conversation"

    events_in_view = parsed["transcript"] if active_tab == "transcript" else parsed["debug"]
    event_kinds = sorted({e["kind"] for e in events_in_view})

    # If this session belongs to a multi-session run, surface a link to the
    # merged run view. Single-session runs (the common case) skip this so the
    # UI stays uncluttered.
    run_id = raw_events[0].run_id
    run_session_count = 0
    if run_id:
        sibling_ids = list(session.exec(
            select(TraceEvent.session_id)
            .where(TraceEvent.run_id == run_id)
            .distinct()
        ).all())
        run_session_count = len(sibling_ids)

    return {
        "session_id": session_id,
        "run_id": run_id,
        "run_session_count": run_session_count,
        "agent": raw_events[0].agent,
        "item": related_item,
        "conversation": parsed["conversation"],
        "transcript": parsed["transcript"],
        "debug": parsed["debug"],
        "results_by_id": parsed["results_by_id"],
        "tool_usage": parsed["tool_usage"],
        "invocation": _parse_session_invocation(session, session_id),
        "stats": parsed["stats"],
        "active_tab": active_tab,
        "event_kinds": event_kinds,
        "first_received_at": min(e.received_at for e in raw_events),
        "last_received_at": max(e.received_at for e in raw_events),
    }


def _run_ctx(run_id: str, tab: str, session: Session) -> dict[str, Any] | None:
    raw_events = list(
        session.exec(
            select(TraceEvent)
            .where(TraceEvent.run_id == run_id)
            .order_by(TraceEvent.received_at)
        ).all()
    )
    if not raw_events:
        return None

    by_session: dict[str, list[TraceEvent]] = defaultdict(list)
    for ev in raw_events:
        by_session[ev.session_id].append(ev)

    sub_sessions: list[dict[str, Any]] = []
    merged_conversation: list[dict[str, Any]] = []
    merged_transcript: list[dict[str, Any]] = []
    merged_debug: list[dict[str, Any]] = []
    aggregate_results_by_id: dict[str, Any] = {}
    tool_counts: dict[str, int] = {}
    agg_in = agg_out = agg_turns = agg_raw = 0
    agg_cost = 0.0
    has_cost = False
    model_seen: str | None = None

    for sid, events in by_session.items():
        events.sort(key=lambda e: e.seq)
        parsed = parse_session([
            RawLine(seq=e.seq, raw_line=e.raw_line, received_at=e.received_at)
            for e in events
        ])
        for ev in parsed["transcript"]:
            ev["source_session_id"] = sid
        for ev in parsed["debug"]:
            ev["source_session_id"] = sid
        for ev in parsed["conversation"]:
            ev["source_session_id"] = sid
        merged_conversation.extend(parsed["conversation"])
        merged_transcript.extend(parsed["transcript"])
        merged_debug.extend(parsed["debug"])
        aggregate_results_by_id.update(parsed["results_by_id"])
        for t in parsed["tool_usage"]:
            tool_counts[t["name"]] = tool_counts.get(t["name"], 0) + t["count"]
        s_stats = parsed["stats"]
        agg_in += s_stats.get("input_tokens", 0) or 0
        agg_out += s_stats.get("output_tokens", 0) or 0
        agg_turns += s_stats.get("turns", 0) or 0
        agg_raw += s_stats.get("raw_count", 0) or 0
        if s_stats.get("estimated_cost_usd") is not None:
            agg_cost += s_stats["estimated_cost_usd"]
            has_cost = True
        if model_seen is None and s_stats.get("model"):
            model_seen = s_stats["model"]
        sub_sessions.append({
            "session_id": sid,
            "event_count": len(events),
            "first_seen": min(e.received_at for e in events),
            "last_seen": max(e.received_at for e in events),
            "stats": s_stats,
            "is_phase_only": sid.startswith("phase-"),
        })

    sub_sessions.sort(key=lambda s: s["first_seen"])

    def _ts_key(ev: dict[str, Any]) -> str:
        ts = ev.get("ts") or ""
        if ts:
            return ts
        rec = ev.get("received_at")
        return rec.isoformat() if isinstance(rec, datetime) else (rec or "")

    merged_conversation.sort(key=_ts_key)
    merged_transcript.sort(key=_ts_key)
    merged_debug.sort(key=_ts_key)

    first = min(e.received_at for e in raw_events)
    last = max(e.received_at for e in raw_events)

    related_item = None
    item_id = next((e.item_id for e in raw_events if e.item_id is not None), None)
    if item_id is not None:
        related_item = session.get(InboxItem, item_id)

    active_tab = tab if tab in VALID_TABS else "conversation"
    events_in_view = merged_transcript if active_tab == "transcript" else merged_debug
    event_kinds = sorted({e["kind"] for e in events_in_view})

    tool_usage_list = sorted(
        ({"name": k, "count": v} for k, v in tool_counts.items()),
        key=lambda t: -t["count"],
    )

    stats = {
        "turns": agg_turns,
        "input_tokens": agg_in,
        "output_tokens": agg_out,
        "raw_count": agg_raw,
        "wall_ms": int((last - first).total_seconds() * 1000),
        "model": model_seen,
        "estimated_cost_usd": agg_cost if has_cost else None,
    }

    return {
        "run_id": run_id,
        "agent": raw_events[0].agent,
        "item": related_item,
        "sub_sessions": sub_sessions,
        "conversation": merged_conversation,
        "transcript": merged_transcript,
        "debug": merged_debug,
        "results_by_id": aggregate_results_by_id,
        "tool_usage": tool_usage_list,
        "stats": stats,
        "active_tab": active_tab,
        "event_kinds": event_kinds,
        "first_received_at": first,
        "last_received_at": last,
    }


def _project_sessions_ctx(project: str, session: Session) -> dict[str, Any]:
    agent_names = [
        a.name for a in session.exec(select(Agent).where(Agent.project == project)).all()
    ]
    summaries: list[dict[str, Any]] = []
    if agent_names:
        trace_events = list(
            session.exec(
                select(TraceEvent)
                .where(TraceEvent.agent.in_(agent_names))
                .order_by(TraceEvent.id.desc())
                .limit(2000)
            ).all()
        )
        sessions: dict[str, dict[str, Any]] = {}
        for ev in trace_events:
            s = sessions.setdefault(
                ev.session_id,
                {
                    "session_id": ev.session_id,
                    "agent": ev.agent,
                    "item_id": ev.item_id,
                    "event_count": 0,
                    "first_seen": ev.received_at,
                    "last_seen": ev.received_at,
                },
            )
            s["event_count"] += 1
            if ev.received_at > s["last_seen"]:
                s["last_seen"] = ev.received_at
            if ev.received_at < s["first_seen"]:
                s["first_seen"] = ev.received_at
        summaries = sorted(sessions.values(), key=lambda s: s["last_seen"], reverse=True)

    return {"project": project, "sessions": summaries}


def _project_subscriptions_ctx(project: str, session: Session) -> dict[str, Any]:
    agent_names = [
        a.name for a in session.exec(select(Agent).where(Agent.project == project)).all()
    ]
    subs: list[Subscription] = []
    if agent_names:
        subs = list(session.exec(
            select(Subscription)
            .where(Subscription.agent.in_(agent_names))
            .order_by(Subscription.agent, Subscription.source)
        ).all())
    return {"project": project, "subs": subs}


def _project_crons_ctx(project: str, session: Session) -> dict[str, Any]:
    agent_names = [
        a.name for a in session.exec(select(Agent).where(Agent.project == project)).all()
    ]
    crons: list[CronTrigger] = []
    if agent_names:
        crons = list(session.exec(
            select(CronTrigger)
            .where(CronTrigger.agent.in_(agent_names))
            .order_by(CronTrigger.agent, CronTrigger.schedule)
        ).all())
    return {"project": project, "crons": crons}


def _webhooks_ctx(session: Session) -> dict[str, Any]:
    deliveries = list(session.exec(
        select(WebhookDelivery)
        .order_by(WebhookDelivery.id.desc())
        .limit(500)
    ).all())
    total_unrouted = sum(1 for d in deliveries if not d.matched_agents)
    return {
        "deliveries": deliveries,
        "total_deliveries": len(deliveries),
        "total_unrouted": total_unrouted,
    }


def _project_inbox_ctx(project: str, session: Session) -> dict[str, Any]:
    agent_names = [
        a.name for a in session.exec(select(Agent).where(Agent.project == project)).all()
    ]
    items: list[InboxItem] = []
    if agent_names:
        items = list(
            session.exec(
                select(InboxItem)
                .where(InboxItem.agent.in_(agent_names))
                .order_by(InboxItem.id.desc())
                .limit(200)
            ).all()
        )
    item_to_session: dict[int, str] = {}
    if items:
        item_ids = [i.id for i in items if i.id is not None]
        for item_id, sid in session.exec(
            select(TraceEvent.item_id, TraceEvent.session_id)
            .where(TraceEvent.item_id.in_(item_ids))
            .distinct()
        ).all():
            item_to_session[item_id] = sid
    return {"project": project, "items": items, "item_to_session": item_to_session}


# ---------------------------------------------------------------------------
# Routes — full pages
# ---------------------------------------------------------------------------

@router.get("/ui/", response_class=HTMLResponse)
def home(session: Session = Depends(get_session)) -> Any:
    # Redirect to the first project's sessions view (or default if empty).
    projects = list(session.exec(select(Agent.project).distinct().order_by(Agent.project)).all())
    target = projects[0] if projects else DEFAULT_PROJECT
    return RedirectResponse(url=f"/ui/projects/{target}/sessions", status_code=302)


@router.get("/ui/projects/{project}/sessions", response_class=HTMLResponse)
def project_sessions(
    request: Request,
    project: str,
    session: Session = Depends(get_session),
) -> Any:
    ctx = _project_sessions_ctx(project, session)
    ctx.update(_sidebar_ctx(session, current_project=project, nav_active="sessions"))
    return templates.TemplateResponse(request, "project_sessions.html", ctx)


@router.get("/ui/projects/{project}/inbox", response_class=HTMLResponse)
def project_inbox(
    request: Request,
    project: str,
    session: Session = Depends(get_session),
) -> Any:
    ctx = _project_inbox_ctx(project, session)
    ctx.update(_sidebar_ctx(session, current_project=project, nav_active="inbox"))
    return templates.TemplateResponse(request, "project_inbox.html", ctx)


@router.get("/ui/projects/{project}/subscriptions", response_class=HTMLResponse)
def project_subscriptions(
    request: Request,
    project: str,
    session: Session = Depends(get_session),
) -> Any:
    ctx = _project_subscriptions_ctx(project, session)
    ctx.update(_sidebar_ctx(session, current_project=project, nav_active="subscriptions"))
    return templates.TemplateResponse(request, "project_subscriptions.html", ctx)


@router.get("/ui/projects/{project}/crons", response_class=HTMLResponse)
def project_crons(
    request: Request,
    project: str,
    session: Session = Depends(get_session),
) -> Any:
    ctx = _project_crons_ctx(project, session)
    ctx.update(_sidebar_ctx(session, current_project=project, nav_active="crons"))
    return templates.TemplateResponse(request, "project_crons.html", ctx)


@router.get("/ui/agents/{agent}/inbox", response_class=HTMLResponse)
def agent_inbox(
    request: Request,
    agent: str,
    session: Session = Depends(get_session),
) -> Any:
    ctx = _agent_inbox_ctx(agent, session)
    project = _project_of_agent(session, agent)
    ctx.update(_sidebar_ctx(
        session, current_project=project, selected_agent=agent,
    ))
    return templates.TemplateResponse(request, "inbox.html", ctx)


@router.get("/ui/webhooks", response_class=HTMLResponse)
def webhooks_view(
    request: Request,
    project: str | None = None,
    session: Session = Depends(get_session),
) -> Any:
    ctx = _webhooks_ctx(session)
    ctx.update(_sidebar_ctx(session, current_project=project, nav_active="webhooks"))
    return templates.TemplateResponse(request, "webhooks.html", ctx)


@router.get("/ui/examples", response_class=HTMLResponse)
def examples_view(
    request: Request,
    project: str | None = None,
    session: Session = Depends(get_session),
) -> Any:
    ctx = _sidebar_ctx(session, current_project=project, nav_active="examples")
    return templates.TemplateResponse(request, "examples.html", ctx)


@router.get("/ui/sessions/{session_id}", response_class=HTMLResponse)
def session_detail(
    request: Request,
    session_id: str,
    tab: str = "conversation",
    session: Session = Depends(get_session),
) -> Any:
    ctx = _session_ctx(session_id, tab, session)
    if ctx is None:
        raise HTTPException(status_code=404, detail="session not found")
    project = _project_of_agent(session, ctx.get("agent"))
    ctx.update(_sidebar_ctx(
        session, current_project=project, selected_agent=ctx.get("agent"),
    ))
    return templates.TemplateResponse(request, "session.html", ctx)


@router.get("/ui/runs/{run_id}", response_class=HTMLResponse)
def run_detail(
    request: Request,
    run_id: str,
    tab: str = "conversation",
    session: Session = Depends(get_session),
) -> Any:
    ctx = _run_ctx(run_id, tab, session)
    if ctx is None:
        raise HTTPException(status_code=404, detail="run not found")
    project = _project_of_agent(session, ctx.get("agent"))
    ctx.update(_sidebar_ctx(
        session, current_project=project, selected_agent=ctx.get("agent"),
    ))
    return templates.TemplateResponse(request, "run.html", ctx)


# ---------------------------------------------------------------------------
# Routes — body-only partials (for realtime innerHTML swaps)
# ---------------------------------------------------------------------------

@router.get("/ui/_partials/projects/{project}/sessions", response_class=HTMLResponse)
def project_sessions_partial(
    request: Request, project: str, session: Session = Depends(get_session),
) -> Any:
    return templates.TemplateResponse(
        request, "_project_sessions_body.html", _project_sessions_ctx(project, session),
    )


@router.get("/ui/_partials/projects/{project}/inbox", response_class=HTMLResponse)
def project_inbox_partial(
    request: Request, project: str, session: Session = Depends(get_session),
) -> Any:
    return templates.TemplateResponse(
        request, "_project_inbox_body.html", _project_inbox_ctx(project, session),
    )


@router.get("/ui/_partials/projects/{project}/subscriptions", response_class=HTMLResponse)
def project_subscriptions_partial(
    request: Request, project: str, session: Session = Depends(get_session),
) -> Any:
    return templates.TemplateResponse(
        request, "_project_subscriptions_body.html", _project_subscriptions_ctx(project, session),
    )


@router.get("/ui/_partials/projects/{project}/crons", response_class=HTMLResponse)
def project_crons_partial(
    request: Request, project: str, session: Session = Depends(get_session),
) -> Any:
    return templates.TemplateResponse(
        request, "_project_crons_body.html", _project_crons_ctx(project, session),
    )


@router.get("/ui/_partials/agents/{agent}/inbox", response_class=HTMLResponse)
def agent_inbox_partial(
    request: Request, agent: str, session: Session = Depends(get_session),
) -> Any:
    return templates.TemplateResponse(request, "_inbox_body.html", _agent_inbox_ctx(agent, session))


@router.get("/ui/_partials/webhooks", response_class=HTMLResponse)
def webhooks_partial(
    request: Request, session: Session = Depends(get_session),
) -> Any:
    return templates.TemplateResponse(
        request, "_webhooks_body.html", _webhooks_ctx(session),
    )


@router.get("/ui/_partials/sessions/{session_id}", response_class=HTMLResponse)
def session_partial(
    request: Request,
    session_id: str,
    tab: str = "conversation",
    session: Session = Depends(get_session),
) -> Any:
    ctx = _session_ctx(session_id, tab, session)
    if ctx is None:
        raise HTTPException(status_code=404, detail="session not found")
    return templates.TemplateResponse(request, "_session_body.html", ctx)


@router.get("/ui/_partials/runs/{run_id}", response_class=HTMLResponse)
def run_partial(
    request: Request,
    run_id: str,
    tab: str = "conversation",
    session: Session = Depends(get_session),
) -> Any:
    ctx = _run_ctx(run_id, tab, session)
    if ctx is None:
        raise HTTPException(status_code=404, detail="run not found")
    return templates.TemplateResponse(request, "_run_body.html", ctx)
