"""
Enhanced Hybrid Search System combining:
1. Semantic Search using embeddings
2. Keyword Search using TF-IDF or BM25
3. Filtered Search
"""
import logging
from typing import List, Tuple, Optional, Dict
import numpy as np
from .hybrid_search_config import SearchConfig
from .bm25 import BM25Scorer
from .tfidf import TFIDFScorer
logger = logging.getLogger(__name__)



class HybridSearchRAG:
    """
    RAG system with enhanced hybrid search
    Combines semantic search and keyword search
    """
    
    def __init__(self, 
                 rag_system,
                 config: Optional[SearchConfig] = None,
                 keyword_method: str = 'bm25',
                 language: str = 'ar',
                 use_lemmatization: bool = True):
        """
        Initialize hybrid search system
        
        Args:
            rag_system:  Base RAG system
            config:  Search configuration
            keyword_method: Keyword search method ('bm25' or 'tfidf')
            language: Language
            use_lemmatization:  Use lemmatization
        """
        if rag_system is None:
            raise ValueError("rag_system is required")
        
        self.rag = rag_system
        self.config = config or SearchConfig()
        self.keyword_method = keyword_method
        self.language = language
        self.use_lemmatization = use_lemmatization
        
        # إنشاء محرك البحث النصي
        # Create keyword search engine
        if keyword_method == 'bm25':
            self.keyword_scorer = BM25Scorer(
                language=language,
                use_lemmatization=use_lemmatization
            )
        else:
            self.keyword_scorer = TFIDFScorer(
                language=language,
                use_lemmatization=use_lemmatization
            )
        
        # حالة التدريب
        # Training state
        self._is_trained = False
        self._document_texts = []
        
        # إحصائيات
        # Statistics
        self.stats = {
            'total_searches': 0,         # إجمالي عمليات البحث | Total searches
            'semantic_searches': 0,      # عمليات البحث الدلالي | Semantic searches
            'keyword_searches': 0,       # عمليات البحث النصي | Keyword searches
            'hybrid_searches': 0         # عمليات البحث الهجين | Hybrid searches
        }
        
        logger.info(f"✅ Hybrid search ready with {keyword_method} and Stanza tokenizer")

    def train_keyword_index(self):
        """
        Train keyword search index
        """
        if not self.rag.vector_db.chunks:
            logger.warning("⚠️ No data available for training keyword index ")
            return
        
        # استخراج نصوص المستندات
        # Extract document texts
        self._document_texts = [chunk.text for chunk in self.rag.vector_db.chunks]
        
        # تدريب المحرك النصي
        # Train keyword engine
        self.keyword_scorer.fit(self._document_texts)
        self._is_trained = True
        
        logger.info(f"✅ Keyword index trained with {len(self._document_texts)} documents ")
    
    def semantic_search(self, query: str, top_k: Optional[int] = None) -> List[Tuple]:
        """
        Semantic search only
        
        Args:
            query:  Query
            top_k:  Number of results
            
        Returns:
            List of results
        """
        self.stats['semantic_searches'] += 1
        k = top_k or self.config.top_k
        return self.rag.retrieve(query, top_k=k)
    
    def keyword_search(self, query: str, top_k: Optional[int] = None) -> List[Tuple]:
        """
        Keyword search only
        
        Args:
            query:  Query
            top_k:  Number of results
            
        Returns:
            List of results
        """
        if not self._is_trained:
            logger.warning("⚠️ Keyword index not trained, training now... ")
            self.train_keyword_index()
        
        self.stats['keyword_searches'] += 1
        k = top_k or self.config.top_k
        
        # حساب درجات BM25/TF-IDF
        # Calculate BM25/TF-IDF scores
        scores = self.keyword_scorer.batch_score(query, self._document_texts)
        
        # ترتيب النتائج
        # Rank results
        ranked_indices = np.argsort(scores)[::-1][:k]
        
        # بناء النتائج
        # Build results
        results = []
        for idx in ranked_indices:
            chunk = self.rag.vector_db.chunks[idx]
            score = scores[idx]
            if score > 0:  # فقط النتائج ذات الدرجات الموجبة | Only positive scores
                results.append((chunk, score))
        
        return results
    
    def hybrid_search(self, 
                     query: str, 
                     top_k: Optional[int] = None,
                     semantic_weight: Optional[float] = None,
                     keyword_weight: Optional[float] = None) -> List[Tuple]:
        """
        Hybrid search - combines semantic and keyword search
        
        Args:
            query: Query
            top_k:  Number of results
            semantic_weight:  Semantic search weight
            keyword_weight:  Keyword search weight
        
        Returns:
            List of (DocumentChunk, combined_score)
        """
        self.stats['total_searches'] += 1
        self.stats['hybrid_searches'] += 1
        
        k = top_k or self.config.top_k
        sem_weight = semantic_weight if semantic_weight is not None else self.config.semantic_weight
        key_weight = keyword_weight if keyword_weight is not None else self.config.keyword_weight
        
        # التأكد من تدريب الفهرس النصي
        # Ensure keyword index is trained
        if not self._is_trained:
            self.train_keyword_index()
        
        # البحث الدلالي
        # Semantic search
        semantic_results = self.semantic_search(query, top_k=k*2)  # جلب المزيد للدمج | Fetch more for fusion
        
        # البحث النصي
        # Keyword search
        keyword_results = self.keyword_search(query, top_k=k*2)
        
        # دمج النتائج
        # Fuse results
        combined_results = self._fuse_results(
            semantic_results,
            keyword_results,
            sem_weight,
            key_weight,
            k
        )
        
        logger.info(f"✅ Hybrid search returned {len(combined_results)} results ")
        return combined_results
    
    def _fuse_results(self,
                     semantic_results: List[Tuple],
                     keyword_results: List[Tuple],
                     sem_weight: float,
                     key_weight: float,
                     top_k: int) -> List[Tuple]:
        """
        Fuse semantic and keyword search results
        
        Args:
            semantic_results:  Semantic search results
            keyword_results:  Keyword search results
            sem_weight:  Semantic weight
            key_weight:  Keyword weight
            top_k:  Number of results
            
        Returns:
            Fused results
        """
        if self.config.fusion_method == 'weighted_sum':
            return self._weighted_sum_fusion(
                semantic_results, keyword_results, 
                sem_weight, key_weight, top_k
            )
        elif self.config.fusion_method == 'rrf':
            return self._reciprocal_rank_fusion(
                semantic_results, keyword_results, top_k
            )
        elif self.config.fusion_method == 'max':
            return self._max_fusion(
                semantic_results, keyword_results, top_k
            )
        else:
            raise ValueError(f"Unsupported fusion method : {self.config.fusion_method}")
    
    def _weighted_sum_fusion(self,
                            semantic_results: List[Tuple],
                            keyword_results: List[Tuple],
                            sem_weight: float,
                            key_weight: float,
                            top_k: int) -> List[Tuple]:
        """
        Weighted sum fusion
        """
        # تطبيع الدرجات
        # Normalize scores
        sem_scores = self._normalize_scores([s for _, s in semantic_results])
        key_scores = self._normalize_scores([s for _, s in keyword_results])
        
        # بناء خريطة الدرجات
        # Build score map
        combined_scores = {}
        
        # إضافة الدرجات الدلالية
        # Add semantic scores
        for i, (chunk, _) in enumerate(semantic_results):
            chunk_id = chunk.chunk_id
            combined_scores[chunk_id] = {
                'chunk': chunk,
                'semantic': sem_scores[i] * sem_weight,
                'keyword': 0.0
            }
        
        # إضافة الدرجات النصية
        # Add keyword scores
        for i, (chunk, _) in enumerate(keyword_results):
            chunk_id = chunk.chunk_id
            if chunk_id in combined_scores:
                combined_scores[chunk_id]['keyword'] = key_scores[i] * key_weight
            else:
                combined_scores[chunk_id] = {
                    'chunk': chunk,
                    'semantic': 0.0,
                    'keyword': key_scores[i] * key_weight
                }
        
        # حساب الدرجة النهائية
        # Calculate final score
        final_results = []
        for chunk_id, scores in combined_scores.items():
            total_score = scores['semantic'] + scores['keyword']
            if total_score >= self.config.min_score:
                final_results.append((scores['chunk'], total_score))
        
        # ترتيب وإرجاع أفضل k
        # Sort and return top k
        final_results.sort(key=lambda x: x[1], reverse=True)
        return final_results[:top_k]
    
    def _reciprocal_rank_fusion(self,
                               semantic_results: List[Tuple],
                               keyword_results: List[Tuple],
                               top_k: int,
                               k: int = 60) -> List[Tuple]:
        """
        Reciprocal Rank Fusion (RRF)
        Effective method that doesn't require score normalization
        
        Args:
            semantic_results: نتائج دلالية | Semantic results
            keyword_results: نتائج نصية | Keyword results
            top_k: عدد النتائج | Number of results
            k: معامل RRF (عادة 60) | RRF constant (usually 60)
            
        Returns:
            النتائج المدمجة | Fused results
        """
        rrf_scores = {}
        
        # معالجة النتائج الدلالية
        # Process semantic results
        for rank, (chunk, _) in enumerate(semantic_results, 1):
            chunk_id = chunk.chunk_id
            if chunk_id not in rrf_scores:
                rrf_scores[chunk_id] = {'chunk': chunk, 'score': 0.0}
            rrf_scores[chunk_id]['score'] += 1.0 / (k + rank)
        
        # معالجة النتائج النصية
        # Process keyword results
        for rank, (chunk, _) in enumerate(keyword_results, 1):
            chunk_id = chunk.chunk_id
            if chunk_id not in rrf_scores:
                rrf_scores[chunk_id] = {'chunk': chunk, 'score': 0.0}
            rrf_scores[chunk_id]['score'] += 1.0 / (k + rank)
        
        # ترتيب النتائج
        # Sort results
        results = [(v['chunk'], v['score']) for v in rrf_scores.values()]
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results[:top_k]
    
    def _max_fusion(self,
                   semantic_results: List[Tuple],
                   keyword_results: List[Tuple],
                   top_k: int) -> List[Tuple]:
        """
        دمج باختيار الدرجة الأعلى
        Max fusion - select highest score
        """
        # تطبيع الدرجات
        # Normalize scores
        sem_scores = self._normalize_scores([s for _, s in semantic_results])
        key_scores = self._normalize_scores([s for _, s in keyword_results])
        
        max_scores = {}
        
        # معالجة النتائج الدلالية
        # Process semantic results
        for i, (chunk, _) in enumerate(semantic_results):
            max_scores[chunk.chunk_id] = {
                'chunk': chunk,
                'score': sem_scores[i]
            }
        
        # معالجة النتائج النصية
        # Process keyword results
        for i, (chunk, _) in enumerate(keyword_results):
            chunk_id = chunk.chunk_id
            if chunk_id in max_scores:
                max_scores[chunk_id]['score'] = max(
                    max_scores[chunk_id]['score'],
                    key_scores[i]
                )
            else:
                max_scores[chunk_id] = {
                    'chunk': chunk,
                    'score': key_scores[i]
                }
        
        # ترتيب النتائج
        # Sort results
        results = [(v['chunk'], v['score']) for v in max_scores.values()]
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results[:top_k]
    
    def _normalize_scores(self, scores: List[float]) -> List[float]:
        """
        تطبيع الدرجات لنطاق [0, 1]
        Normalize scores to range [0, 1]
        
        Args:
            scores: قائمة الدرجات | List of scores
            
        Returns:
            الدرجات المطبعة | Normalized scores
        """
        if not scores:
            return []
        
        min_score = min(scores)
        max_score = max(scores)
        
        if max_score == min_score:
            return [0.0] * len(scores) if max_score == 0.0 else [1.0] * len(scores)
        
        return [(s - min_score) / (max_score - min_score) for s in scores]
    
    def generate(self, query: str, 
                search_method: str = 'hybrid',
                include_sources: bool = False) -> str:
        """
        Generate answer using specified search method
        
        Args:
            query:  Query
            search_method: Search method ('semantic', 'keyword', 'hybrid')
            include_sources:  Include sources
        
        Returns:
            Answer
        """
        # اختيار طريقة البحث
        # Select search method
        if search_method == 'semantic':
            chunks = self.semantic_search(query)
        elif search_method == 'keyword':
            chunks = self.keyword_search(query)
        else:  # hybrid
            chunks = self.hybrid_search(query)
        
        if not chunks:
            return "لا تتوفر معلومات كافية في المستندات للإجابة على هذا السؤال." \
                   if self.language == 'ar' else \
                   "No sufficient information found in the documents to answer this question."

        # فلترة النتائج ضعيفة التشابه
        # Filter out low-similarity results
        chunks = [(chunk, score) for chunk, score in chunks
                  if score >= self.config.min_score]

        if not chunks:
            return "المعلومات المسترجعة غير ذات صلة كافية بسؤالك." \
                   if self.language == 'ar' else \
                   "Retrieved information is not relevant enough to answer your question."

        if self.rag.llm is None:
            return "Language model is not available"

        # بناء السياق
        # Build context
        context = self.rag.context_manager.build(query, chunks)

        # بناء prompt مُقيَّد — يمنع التأليف من خارج المستندات
        # Strict prompt — prevents fabrication outside documents
        if self.language == 'ar':
            prompt = f"""أجب على السؤال فقط بناءً على المعلومات التالية.
                        إذا لم تكن الإجابة موجودة في المعلومات المقدمة، قل بوضوح: "لا تتوفر معلومات كافية في المستندات."
                        لا تُضف أي معلومات من خارج النص المُقدَّم.
                        {context}
                        السؤال: {query}
                        الإجابة:"""
        else:
            prompt = f"""Answer the question ONLY based on the following information.
                        If the answer is not present in the provided information, clearly say: "There is not enough information in the documents."
                        Do NOT add any information from outside the provided text.
                        {context}
                        Question: {query}
                        Answer:"""

        # التوليد
        # Generation
        answer = self.rag.llm.generate(prompt)
        
        # إضافة المصادر
        # Add sources
        if include_sources:
            sources = self._format_sources(chunks)
            answer = f"{answer}\n\n{sources}"
        
        return answer
    
    def _format_sources(self, chunks: List[Tuple]) -> str:
        """
        Format sources for answer
        
        Args:
            chunks:  Retrieved chunks
            
        Returns:
            Sources text
        """
        sources = []
        seen_docs = set()
        
        for chunk, score in chunks[:3]:
            if chunk.doc_id not in seen_docs:
                sources.append(f"- {chunk.doc_id} (similarity score: {score:.2f})")
                seen_docs.add(chunk.doc_id)
        
        return "📚 Sources:\n" + "\n".join(sources) if sources else ""
    
    def compare_methods(self, query: str, top_k: int = 5) -> Dict:
        """
        Compare different search methods
        
        Args:
            query:  Query
            top_k:  Number of results
            
        Returns:
             dict with results from each method
        """
        results = {
            'query': query,
            'semantic': self.semantic_search(query, top_k),
            'keyword': self.keyword_search(query, top_k),
            'hybrid': self.hybrid_search(query, top_k)
        }
        
        # حساب التداخل
        # Calculate overlap
        sem_ids = {c.chunk_id for c, _ in results['semantic']}
        key_ids = {c.chunk_id for c, _ in results['keyword']}
        hyb_ids = {c.chunk_id for c, _ in results['hybrid']}
        
        results['overlap'] = {
            'semantic_keyword': len(sem_ids & key_ids),
            'semantic_hybrid': len(sem_ids & hyb_ids),
            'keyword_hybrid': len(key_ids & hyb_ids)
        }
        
        return results
    
    def get_stats(self) -> dict:
        """
        Get system statistics
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'is_trained': self._is_trained,
            'indexed_documents': len(self._document_texts),
            'keyword_method': self.keyword_method,
            'language': self.language,
            'use_lemmatization': self.use_lemmatization,
            'fusion_method': self.config.fusion_method,
            'weights': {
                'semantic': self.config.semantic_weight,
                'keyword': self.config.keyword_weight
            }
        }
    # ── Async API ────────────────────────────────────────────────────

    async def asemantic_search(self, query: str, top_k=None):
        """Async semantic search """
        import asyncio
        return await asyncio.to_thread(self.semantic_search, query, top_k)

    async def akeyword_search(self, query: str, top_k=None):
        """Async keyword search """
        import asyncio
        return await asyncio.to_thread(self.keyword_search, query, top_k)

    async def ahybrid_search(self, query: str, top_k=None,
                              semantic_weight=None, keyword_weight=None):
        """
        Async hybrid search — runs semantic & keyword searches in parallel.
        """
        import asyncio
        k = top_k or self.config.top_k
        if not self._is_trained:
            await asyncio.to_thread(self.train_keyword_index)

        sem_w = semantic_weight if semantic_weight is not None else self.config.semantic_weight
        key_w = keyword_weight if keyword_weight is not None else self.config.keyword_weight

        semantic_results, keyword_results = await asyncio.gather(
            self.asemantic_search(query, top_k=k * 2),
            self.akeyword_search(query, top_k=k * 2),
        )
        return self._fuse_results(semantic_results, keyword_results, sem_w, key_w, k)

    async def agenerate(self, query: str, search_method: str = "hybrid",
                        include_sources: bool = False) -> str:
        """Async generate answer """
        import asyncio
        if search_method == "semantic":
            chunks = await self.asemantic_search(query)
        elif search_method == "keyword":
            chunks = await self.akeyword_search(query)
        else:
            chunks = await self.ahybrid_search(query)

        if not chunks:
            return "لا تتوفر معلومات كافية في المستندات." \
                   if self.language == 'ar' else \
                   "No sufficient information found in the documents."

        # فلترة النتائج ضعيفة التشابه
        # Filter out low-similarity results
        chunks = [(chunk, score) for chunk, score in chunks
                  if score >= self.config.min_score]

        if not chunks:
            return "المعلومات المسترجعة غير ذات صلة كافية بسؤالك." \
                   if self.language == 'ar' else \
                   "Retrieved information is not relevant enough to answer your question."

        if self.rag.llm is None:
            return "LLM not available"

        context = await asyncio.to_thread(self.rag.context_manager.build, query, chunks)

        if self.language == 'ar':
            prompt = f"""أجب على السؤال فقط بناءً على المعلومات التالية.
                    إذا لم تكن الإجابة موجودة في المعلومات المقدمة، قل بوضوح: "لا تتوفر معلومات كافية في المستندات."
                    لا تُضف أي معلومات من خارج النص المُقدَّم.
                    {context}
                    السؤال: {query}
                    الإجابة:"""
        else:
            prompt = f"""Answer the question ONLY based on the following information.
                        If the answer is not present in the provided information, clearly say: "There is not enough information in the documents."
                        Do NOT add any information from outside the provided text.
                        {context}
                        Question: {query}
                        Answer:"""

        if hasattr(self.rag.llm, "generate_async"):
            answer = await self.rag.llm.generate_async(prompt)
        else:
            answer = await asyncio.to_thread(self.rag.llm.generate, prompt)

        if include_sources:
            answer += "\n\n" + self._format_sources(chunks)
        return answer

    async def astream(self, query: str, search_method: str = "hybrid"):
        """Async streaming generator for hybrid RAG """
        import asyncio
        chunks = await self.ahybrid_search(query)
        if not chunks:
            yield "لا تتوفر معلومات كافية في المستندات." \
                  if self.language == 'ar' else \
                  "No sufficient information found in the documents."
            return

        # فلترة النتائج ضعيفة التشابه
        # Filter out low-similarity results
        chunks = [(chunk, score) for chunk, score in chunks
                  if score >= self.config.min_score]

        if not chunks:
            yield "المعلومات المسترجعة غير ذات صلة كافية." \
                  if self.language == 'ar' else \
                  "Retrieved information is not relevant enough."
            return

        context = await asyncio.to_thread(self.rag.context_manager.build, query, chunks)
        if self.language == 'ar':
            prompt = f"""أجب على السؤال فقط بناءً على المعلومات التالية.
                    إذا لم تكن الإجابة موجودة في المعلومات المقدمة، قل بوضوح: "لا تتوفر معلومات كافية في المستندات."
                    لا تُضف أي معلومات من خارج النص المُقدَّم.
                    {context}
                    السؤال: {query}
                    الإجابة:"""
        else:
            prompt = f"""Answer the question ONLY based on the following information.
                    If the answer is not present in the provided information, clearly say: "There is not enough information in the documents."
                    Do NOT add any information from outside the provided text.
                    {context}
                    Question: {query}
                    Answer:"""

        llm = self.rag.llm
        if hasattr(llm, "astream"):
            async for token in llm.astream(prompt):
                yield token
        else:
            answer = await asyncio.to_thread(llm.generate, prompt)
            for word in answer.split(" "):
                yield word + " "
                await asyncio.sleep(0)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False