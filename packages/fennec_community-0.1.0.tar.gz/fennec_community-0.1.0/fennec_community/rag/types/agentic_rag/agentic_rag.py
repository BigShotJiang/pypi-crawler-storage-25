from __future__ import annotations
import logging
import time
import hashlib
from typing import Any, Callable, Dict, List, Optional
from .agentic_config import AgenticConfig , AgentAction , ReasoningDepth
from .document import Document
from .agentic_result import AgenticResult
from .action_step import ActionStep
from .cache import TTLCache

# ─────────────────────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────────────────────

logging.basicConfig(
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("AgenticRAG")




# ─────────────────────────────────────────────────────────────────────────────
# Exceptions
# ─────────────────────────────────────────────────────────────────────────────

class AgenticRAGError(Exception):
    """Base exception for Agentic RAG errors."""


class RetrievalError(AgenticRAGError):
    """Raised when document retrieval fails."""


class GenerationError(AgenticRAGError):
    """Raised when answer generation fails."""


class MaxIterationsExceeded(AgenticRAGError):
    """Raised when the agent exceeds max allowed iterations."""




# ─────────────────────────────────────────────────────────────────────────────
# Main Class
# ─────────────────────────────────────────────────────────────────────────────

class AgenticRAG:
    """
    Agentic RAG System – autonomous retrieval-augmented generation.

    The agent iteratively decides whether to retrieve, refine, check
    sufficiency, or generate until it has enough context or hits the
    iteration cap.

    Example::

        config = AgenticConfig(max_iterations=4, min_confidence=0.75)
        agent  = AgenticRAG(rag_system, config=config)
        result = agent.query("ما هي أحدث تطورات الذكاء الاصطناعي؟")
        print(result.answer)
    """

    def __init__(
        self,
        rag_system: Any,
        config: Optional[AgenticConfig] = None,
        llm: Optional[Any] = None,
        on_action: Optional[Callable[[ActionStep], None]] = None,
    ) -> None:
        """
        Initialise the Agentic RAG agent.

        Args:
            rag_system: Underlying RAG backend that exposes
                        ``retrieve(query)`` and ``query(query, **kwargs)``.
            config:     Runtime configuration.  Defaults to ``AgenticConfig()``.
            llm:        Language model used for refinement / sufficiency checks.
                        Falls back to ``rag_system.llm`` if not provided.
            on_action:  Optional callback fired after every agent action step.
                        Useful for logging, tracing, or streaming UIs.
        """
        self.rag_system = rag_system
        self.config = config or AgenticConfig()
        self.llm = llm or getattr(rag_system, "llm", None)
        self.on_action = on_action
        self._cache = TTLCache(ttl_seconds=self.config.cache_ttl_seconds)
        self._result_cache: Dict[str, AgenticResult] = {}

    # ──────────────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────────────

    def query(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> AgenticResult:
        """
        Process a query autonomously.

        Args:
            query:   Natural-language question.
            context: Optional extra context forwarded to the RAG backend.

        Returns:
            AgenticResult with answer, docs, action trace, and confidence.

        Raises:
            MaxIterationsExceeded: If the agent loop overruns ``max_iterations``.
        """
        query = query.strip()
        if not query:
            raise ValueError("Query must not be empty.")

        logger.info("🤖 Starting Agentic RAG | query=%r", query)

        # ── Check result cache ────────────────────────────────────────────
        cache_key = self._result_key(query)
        if cache_key in self._result_cache:
            cached = self._result_cache[cache_key]
            logger.info("⚡ Returning cached result for query=%r", query)
            cached.cached = True
            return cached

        action_history: List[ActionStep] = []
        retrieved_docs: List[Document] = []
        current_query = query
        iteration = 0

        while iteration < self.config.max_iterations:
            iteration += 1
            t0 = time.perf_counter()

            action = self._decide_action(current_query, retrieved_docs, iteration)
            duration = (time.perf_counter() - t0) * 1000

            step = ActionStep(
                iteration=iteration,
                action=action,
                query=current_query,
                duration_ms=round(duration, 2),
                confidence=self._compute_confidence(retrieved_docs),
            )
            action_history.append(step)

            logger.debug(
                "  iter=%d | action=%-20s | query=%r",
                iteration, action.value, current_query[:60],
            )

            if action == AgentAction.STOP:
                logger.info("✅ Agent decided to stop at iteration %d", iteration)
                if self.on_action:
                    try:
                        self.on_action(step)
                    except Exception:
                        pass
                break

            elif action == AgentAction.RETRIEVE:
                new_docs = self._retrieve_with_retry(current_query)
                retrieved_docs.extend(new_docs)
                step.details = f"fetched {len(new_docs)} docs"
                step.confidence = self._compute_confidence(retrieved_docs)
                logger.info("📄 Retrieved %d docs (total=%d)", len(new_docs), len(retrieved_docs))

            elif action == AgentAction.REFINE_QUERY:
                refined = self._refine_query(current_query, retrieved_docs)
                step.details = f"refined: {refined}"
                if refined != current_query:
                    step.refined_query = refined
                    current_query = refined
                    logger.info("🔄 Query refined → %r", current_query)
                else:
                    logger.info("↩ Refinement unchanged; forcing RETRIEVE")
                    new_docs = self._retrieve_with_retry(current_query)
                    retrieved_docs.extend(new_docs)
                    step.confidence = self._compute_confidence(retrieved_docs)

            elif action == AgentAction.CHECK_SUFFICIENCY:
                sufficient = self._is_information_sufficient(query, retrieved_docs)
                step.details = "sufficient" if sufficient else "insufficient"
                step.confidence = self._compute_confidence(retrieved_docs)
                if self.on_action:
                    try:
                        self.on_action(step)
                    except Exception:
                        pass
                if sufficient:
                    logger.info("✓ Information is sufficient")
                    break
                else:
                    logger.info("⚠ Need more information – retrieving again")
                continue  # skip the second on_action call below

            elif action == AgentAction.GENERATE:
                logger.info("✍ Generating final answer")
                step.confidence = self._compute_confidence(retrieved_docs)
                if self.on_action:
                    try:
                        self.on_action(step)
                    except Exception:
                        pass
                break

            # Fire callback after action (RETRIEVE / REFINE_QUERY)
            if self.on_action:
                try:
                    self.on_action(step)
                except Exception:
                    pass  # Callbacks must never break the main loop

        else:
            logger.warning("⚠ Max iterations (%d) reached", self.config.max_iterations)

        # ── Deduplicate docs ──────────────────────────────────────────────
        retrieved_docs = self._deduplicate(retrieved_docs)

        # ── Generate answer ───────────────────────────────────────────────
        answer = self._generate_answer_with_retry(query, retrieved_docs, context)

        # ── Self-correction pass ──────────────────────────────────────────
        if self.config.enable_self_correction and self.llm:
            answer = self._self_correct(query, answer, retrieved_docs)

        confidence = self._compute_confidence(retrieved_docs)

        result = AgenticResult(
            answer=answer,
            retrieved_docs=retrieved_docs,
            action_history=action_history,
            iterations=iteration,
            reasoning=self._format_reasoning(action_history),
            confidence=confidence,
        )

        # Store in result cache
        self._result_cache[cache_key] = result
        return result

    def add_document(
        self,
        text: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Add a single document to the underlying RAG index."""
        return self.rag_system.add_document(text, metadata or {})

    def add_documents(
        self,
        documents: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
    ) -> Any:
        """Bulk-add documents to the underlying RAG index."""
        return self.rag_system.add_documents(documents, metadatas or [])

    def clear_cache(self) -> None:
        """Flush both the retrieval TTL cache and the result cache."""
        self._cache.clear()
        self._result_cache.clear()
        logger.info("🗑 All caches cleared")

    # ──────────────────────────────────────────────────────────────────────
    # Decision Logic
    # ──────────────────────────────────────────────────────────────────────

    def _decide_action(
        self,
        query: str,
        retrieved_docs: List[Document],
        iteration: int,
    ) -> AgentAction:
        """
        Select the next action based on current state.

        Decision priority:
        1. First iteration → always RETRIEVE.
        2. No docs yet → RETRIEVE.
        3. Max iterations – 1 → GENERATE (ensure we always answer).
        4. Docs present + sufficiency check enabled → CHECK_SUFFICIENCY.
        5. Low average score + refinement enabled + early iteration → REFINE_QUERY.
        6. Default → GENERATE.
        """
        if iteration == 1 or not retrieved_docs:
            return AgentAction.RETRIEVE

        if iteration >= self.config.max_iterations:
            return AgentAction.GENERATE

        if self.config.enable_sufficiency_check and iteration % 2 == 0:
            return AgentAction.CHECK_SUFFICIENCY

        if self.config.enable_query_refinement and iteration < 4:
            avg_score = self._avg_score(retrieved_docs)
            if avg_score < self.config.min_confidence:
                return AgentAction.REFINE_QUERY

        return AgentAction.GENERATE

    # ──────────────────────────────────────────────────────────────────────
    # Retrieval
    # ──────────────────────────────────────────────────────────────────────

    def _retrieve_with_retry(self, query: str) -> List[Document]:
        """Retrieve with exponential back-off retries."""
        for attempt in range(self.config.retry_attempts + 1):
            try:
                return self._retrieve(query)
            except RetrievalError as exc:
                if attempt == self.config.retry_attempts:
                    logger.error("❌ Retrieval failed after %d attempts: %s", attempt + 1, exc)
                    return []
                wait = self.config.retry_backoff_base * (2 ** attempt)
                logger.warning("⏳ Retrieval attempt %d failed; retrying in %.1fs", attempt + 1, wait)
                time.sleep(wait)
        return []

    def _retrieve(self, query: str) -> List[Document]:
        """
        Retrieve documents, normalising heterogeneous RAG backend formats.

        Supports backends that return:
        - ``{"results": [...]}``
        - ``[{"text": ..., "score": ...}, ...]``
        - ``[Document(...), ...]``
        """
        # Check TTL cache first
        cached = self._cache.get(query)
        if cached is not None:
            logger.debug("⚡ Retrieval cache hit for %r", query[:60])
            return cached

        try:
            raw = self.rag_system.retrieve(query)
        except Exception as exc:
            raise RetrievalError(f"Backend retrieve() raised: {exc}") from exc

        docs = self._normalise_docs(raw)
        self._cache.set(query, docs)
        return docs

    @staticmethod
    def _normalise_docs(raw: Any) -> List[Document]:
        """Convert arbitrary backend output to a list of ``Document``.
        Supports:
        - ``Document`` objects (already normalised)
        - ``Tuple[Any, float]`` — e.g. ``(DocumentChunk, score)`` returned by FAISS
        - ``dict`` with ``text``/``content`` and ``score``/``relevance`` keys
        - Wrapped ``{"results": [...]}`` dict
        """
        if isinstance(raw, dict):
            raw = raw.get("results", [])

        if not isinstance(raw, list):
            return []

        result: List[Document] = []
        for item in raw:
            if isinstance(item, Document):
                result.append(item)

            # ✅ Handle Tuple[DocumentChunk, float] returned by FAISS / base RAG
            elif isinstance(item, tuple) and len(item) == 2:
                chunk, score = item
                text = (
                    getattr(chunk, "text", None)
                    or getattr(chunk, "page_content", None)
                    or getattr(chunk, "content", None)
                    or ""
                )
                source = (
                    getattr(chunk, "chunk_id", None)
                    or getattr(chunk, "doc_id", None)
                    or getattr(chunk, "id", None)
                    or ""
                )
                metadata = getattr(chunk, "metadata", {}) or {}
                if text:
                    result.append(Document(
                        text=text,
                        score=float(score),
                        metadata=metadata,
                        source=str(source),
                    ))

            elif isinstance(item, dict):
                result.append(Document(
                    text=item.get("text", item.get("content", "")),
                    score=float(item.get("score", item.get("relevance", 0.0))),
                    metadata=item.get("metadata", {}),
                    source=item.get("source", item.get("id", "")),
                ))
        return result

    # ──────────────────────────────────────────────────────────────────────
    # Query Refinement
    # ──────────────────────────────────────────────────────────────────────

    def _refine_query(self, query: str, retrieved_docs: List[Document]) -> str:
        """
        Ask the LLM to rewrite the query given the current context.
        Falls back to the original query if the LLM is unavailable or the
        refined version is suspiciously short / identical.
        """
        if not self.llm or not retrieved_docs:
            return query

        context_snippets = "\n\n".join(
            f"[Doc {i + 1}]: {doc.snippet(200)}"
            for i, doc in enumerate(retrieved_docs[:3])
        )

        depth_hints = {
            ReasoningDepth.SHALLOW: "in one concise sentence",
            ReasoningDepth.MEDIUM:  "in one clear sentence, adding specificity",
            ReasoningDepth.DEEP:    "expanding scope and adding sub-questions if needed",
        }
        hint = depth_hints.get(self.config.reasoning_depth, "")

        prompt = (
            f"You are a search-query optimizer.\n\n"
            f"Original query: {query}\n\n"
            f"Retrieved context (low confidence):\n{context_snippets}\n\n"
            f"Rewrite the query {hint} to retrieve better documents.\n"
            f"Output ONLY the refined query, no explanation:"
        )

        try:
            refined = self.llm.generate(prompt).strip()
            if refined and refined != query and len(refined) > 5:
                return refined
        except Exception as exc:
            logger.warning("⚠ Query refinement LLM call failed: %s", exc)

        return query

    # ──────────────────────────────────────────────────────────────────────
    # Sufficiency Check
    # ──────────────────────────────────────────────────────────────────────

    def _is_information_sufficient(
        self,
        query: str,
        retrieved_docs: List[Document],
    ) -> bool:
        """
        Determine whether the retrieved documents are sufficient to answer.
        Uses a fast heuristic first; falls back to an LLM call only when the
        heuristic is inconclusive.
        """
        if len(retrieved_docs) < self.config.min_docs_required:
            return False

        avg_score = self._avg_score(retrieved_docs)
        if avg_score >= self.config.min_confidence:
            return True

        if avg_score < 0.3:
            return False  # Clearly not enough; skip the expensive LLM call

        # Borderline – ask the LLM
        if not self.llm:
            return len(retrieved_docs) >= 3

        context = "\n\n".join(
            f"[Doc {i + 1}]: {doc.snippet(300)}"
            for i, doc in enumerate(retrieved_docs[:5])
        )

        prompt = (
            f"Query: {query}\n\n"
            f"Retrieved information:\n{context}\n\n"
            f"Is the information above sufficient to answer the query accurately?\n"
            f"Respond with exactly 'yes' or 'no':"
        )

        try:
            response = self.llm.generate(prompt).strip().lower()
            return "yes" in response
        except Exception as exc:
            logger.warning("⚠ Sufficiency check LLM call failed: %s", exc)
            return len(retrieved_docs) >= 3

    # ──────────────────────────────────────────────────────────────────────
    # Generation
    # ──────────────────────────────────────────────────────────────────────

    def _generate_answer_with_retry(
        self,
        query: str,
        retrieved_docs: List[Document],
        context: Optional[Dict[str, Any]],
    ) -> str:
        """Generate an answer with retry logic."""
        for attempt in range(self.config.retry_attempts + 1):
            try:
                return self._generate_answer(query, retrieved_docs, context)
            except GenerationError as exc:
                if attempt == self.config.retry_attempts:
                    logger.error("❌ Generation failed after %d attempts: %s", attempt + 1, exc)
                    return self._fallback_answer(retrieved_docs)
                wait = self.config.retry_backoff_base * (2 ** attempt)
                time.sleep(wait)
        return self._fallback_answer(retrieved_docs)

    def _generate_answer(
        self,
        query: str,
        retrieved_docs: List[Document],
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Delegate answer generation to the RAG backend."""
        if not retrieved_docs:
            return "i cant find anything for you"

        try:
            # ✅ بناء الـ prompt محلياً من الـ docs بدل تمرير context كـ kwarg
            # هذا يمنع وصول context كـ kwarg غير معروف لأي LLM API
            context_text = "\n\n".join(
                f"[{i + 1}] {doc.text.strip()}"
                for i, doc in enumerate(retrieved_docs)
            )

            # إضافة أي context خارجي إذا وُجد (بدون retrieved_docs لتجنب التكرار)
            if context:
                extra_parts = [
                    f"{k}: {v}"
                    for k, v in context.items()
                    if k != "retrieved_docs"
                ]
                if extra_parts:
                    context_text += "\n\n" + "\n".join(extra_parts)

            if self.llm:
                # ✅ استدعاء llm.generate مباشرة بدون أي kwargs إضافية
                prompt = (
                            "أنت نظام سؤال وجواب يعتمد فقط على المعلومات المعطاة.\n\n"
                            "القواعد:\n"
                            "- أجب باستخدام المعلومات الموجودة في النص فقط\n"
                            "- لا تستخدم أي معرفة خارجية\n"
                            "اجب بنفس اللغه الموجوده في السوال \n"
                            "- إذا لم تجد الإجابة، قل: 'المعلومة غير موجودة في المستند'\n"
                            "- لا تخمن أو تضيف معلومات\n\n"
                            f"المعلومات:\n{context_text}\n\n"
                            f"السؤال: {query}\n\n"
                            "الإجابة:"
                            )
                result = self.llm.generate(prompt)
            else:
                # ✅ Fallback: استدعاء rag_system.generate بدون context kwarg
                result = self.rag_system.generate(query)

            if isinstance(result, dict):
                return result.get("answer", str(result))
            return str(result)

        except Exception as exc:
            raise GenerationError(f"Backend query() raised: {exc}") from exc

    def _self_correct(
        self,
        query: str,
        answer: str,
        retrieved_docs: List[Document],
        ) -> str:
        """
        Ask the LLM to validate and optionally improve the generated answer.
        Returns the original answer unchanged on any error.
        """
        if not self.llm or not answer:
            return answer

        context = "\n\n".join(
            f"[Doc {i + 1}]: {doc.snippet(300)}"
            for i, doc in enumerate(retrieved_docs[:4])
        )

        prompt = (
                    "راجع الإجابة بناءً على المعلومات فقط.\n\n"
                    "القواعد:\n"
                    "-استخدم نفس اللغه الموجوده في السؤال\n"
                    "- لا تضف أي معلومات جديدة\n"
                    "- احذف أي معلومة غير موجودة في السياق\n"
                    "- إذا كانت الإجابة غير مدعومة، قل: 'المعلومة غير مؤكدة من النص'\n\n"
                    f"السؤال: {query}\n\n"
                    f"المعلومات:\n{context}\n\n"
                    f"الإجابة:\n{answer}\n\n"
                    "الإجابة النهائية:"
                  )

        try:
            corrected = self.llm.generate(prompt).strip()
            if corrected and len(corrected) > 10:
                return corrected
        except Exception as exc:
            logger.warning("⚠ Self-correction LLM call failed: %s", exc)

        return answer

    # ──────────────────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _avg_score(docs: List[Document]) -> float:
        if not docs:
            return 0.0
        return sum(d.score for d in docs) / len(docs)

    def _compute_confidence(self, docs: List[Document]) -> float:
        """
        Weighted confidence: top docs count more than tail docs.
        Returns a value in [0, 1].
        """
        if not docs:
            return 0.0
        sorted_docs = sorted(docs, key=lambda d: d.score, reverse=True)
        weights = [1 / (i + 1) for i in range(len(sorted_docs))]
        total_weight = sum(weights)
        weighted_sum = sum(d.score * w for d, w in zip(sorted_docs, weights))
        return min(weighted_sum / total_weight, 1.0)

    @staticmethod
    def _deduplicate(docs: List[Document]) -> List[Document]:
        """Remove duplicate documents (by text hash), keeping highest score."""
        seen: Dict[str, Document] = {}
        for doc in docs:
            key = hashlib.md5(doc.text.encode()).hexdigest()
            if key not in seen or doc.score > seen[key].score:
                seen[key] = doc
        return list(seen.values())

    @staticmethod
    def _fallback_answer(docs: List[Document]) -> str:
        """Return a simple concatenation when generation fails."""
        if not docs:
            return "i cant find anything for you"
        snippets = "\n\n".join(f"• {doc.snippet(400)}" for doc in docs[:3])
        return f"based on the following snippets:\n\n{snippets}"

    @staticmethod
    def _result_key(query: str) -> str:
        return hashlib.sha256(query.lower().strip().encode()).hexdigest()

    @staticmethod
    def _format_reasoning(history: List[ActionStep]) -> str:
        if not history:
            return "No reasoning steps recorded."
        lines = [
            f"Step {s.iteration:02d} | {s.action.value:<22} | "
            f"{s.duration_ms:6.1f}ms | {s.details or s.query[:50]}"
            for s in history
        ]
        return "\n".join(lines)


    # ── Async API ────────────────────────────────────────────────────

    async def aquery(self, query: str, **kwargs) -> "AgenticResult":
        """
        Async agentic RAG query — runs agent loop asynchronously.
        """
        import asyncio
        return await asyncio.to_thread(self.query, query, **kwargs)

    async def astream_query(self, query: str):
        """
        Same agent logic but streams the final answer token by token.

        Example::

            async for token in agent.astream_query("ما هو الذكاء الاصطناعي؟"):
                print(token, end="", flush=True)
        """
        import asyncio

        query = query.strip()
        if not query:
            yield "⚠️ query is empty"
            return

        if not self.llm or not hasattr(self.llm, "astream"):
            yield "❌ llm not configured correctly for streaming."
            return

        # ── نفس حلقة القرار | Same decision loop ─────────────────────
        retrieved_docs: List[Document] = []
        current_query  = query
        iteration      = 0

        while iteration < self.config.max_iterations:
            iteration += 1
            t0     = time.perf_counter()
            action = self._decide_action(current_query, retrieved_docs, iteration)
            duration = (time.perf_counter() - t0) * 1000

            step = ActionStep(
                iteration=iteration,
                action=action,
                query=current_query,
                duration_ms=round(duration, 2),
                confidence=self._compute_confidence(retrieved_docs),
            )

            if self.on_action:
                try:
                    self.on_action(step)
                except Exception:
                    pass

            if action == AgentAction.STOP:
                break

            elif action == AgentAction.RETRIEVE:
                new_docs = await asyncio.to_thread(
                    self._retrieve_with_retry, current_query
                )
                retrieved_docs.extend(new_docs)
                step.details = f"fetched {len(new_docs)} docs"
                step.confidence = self._compute_confidence(retrieved_docs)

            elif action == AgentAction.REFINE_QUERY:
                refined = await asyncio.to_thread(
                    self._refine_query, current_query, retrieved_docs
                )
                if refined != current_query:
                    current_query = refined
                else:
                    new_docs = await asyncio.to_thread(
                        self._retrieve_with_retry, current_query
                    )
                    retrieved_docs.extend(new_docs)
                    step.confidence = self._compute_confidence(retrieved_docs)

            elif action == AgentAction.CHECK_SUFFICIENCY:
                sufficient = await asyncio.to_thread(
                    self._is_information_sufficient, query, retrieved_docs
                )
                step.details = "sufficient" if sufficient else "insufficient"
                if sufficient:
                    break
                continue

            elif action == AgentAction.GENERATE:
                break

        # ── بناء الـ prompt وبث الإجابة | Build prompt and stream ─────
        retrieved_docs = self._deduplicate(retrieved_docs)

        if not retrieved_docs:
            yield "❌ not enough information to answer."
            return

        context_text = "\n\n".join(
            f"[{i + 1}] {doc.text.strip()}"
            for i, doc in enumerate(retrieved_docs)
        )
        prompt = (
                    f"أجب على السؤال بناءً على المعلومات المقدمة فقط.\n"
                    f"إذا لم تجد الإجابة في المعلومات، قل: 'لا تتوفر معلومات كافية'.\n"
                    f"لا تضف أي معلومات من خارج النص المقدم.\n\n"  # ← القيد الأساسي
                    f"المعلومات:\n{context_text}\n\n"
                    f"السؤال: {query}\n\n"
                    f"الإجابة:"
                                 )

        # ✅ بث token بـ token بدل انتظار الرد كاملاً
        async for token in self.llm.astream(prompt):
            yield token

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False