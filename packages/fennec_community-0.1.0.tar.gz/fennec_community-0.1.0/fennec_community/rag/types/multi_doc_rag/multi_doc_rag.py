from   typing import Dict, List, Optional, Any, Union
from   pathlib import Path
import logging
import json
from   datetime import datetime
logger = logging.getLogger(__name__)


class MultiDocumentRAGSystem:
    """
     RAG system supporting multiple documents with independent chunking
    
    """
    
    def __init__(
        self,
        vector_db: Any,
        llm: Any,
        chunker: Any,
        context_manager: Any,
        config: Optional[Any] = None
    ):
       
        # المكونات الأساسية
        self.vector_db = vector_db
        self.llm = llm
        self.chunker = chunker
        self.context_manager = context_manager
        self.config = config
        
        # تتبع المستندات - كل مستند بشكل منفصل
        self.documents: Dict[str, Dict[str, Any]] = {}
        # {
        #     "doc_id_1": {
        #         "text": "original text",
        #         "chunks": ["chunk_1", "chunk_2", ...],
        #         "num_chunks": 5,
        #         "metadata": {...},
        #         "added_at": "2024-01-01 12:00:00",
        #         "language": "arabic"
        #     }
        # }
        
        # إحصائيات عامة
        self.stats = {
            "total_documents": 0,
            "total_chunks": 0,
            "total_queries": 0,
            "successful_queries": 0,
            "failed_queries": 0
        }
        
        logger.info("✅ Multi-Document RAG System initialized")
    
    # =========================================================================
    # إضافة المستندات | Document Management
    # =========================================================================
    
    def add_document(
        self,
        doc_id: str,
        text: str,
        metadata: Optional[Dict[str, Any]] = None,
        language: Optional[str] = None,
        chunk_independently: bool = True
    ) -> Dict[str, Any]:
        """
        Add a single document with independent chunking
        
        Args:
            doc_id:   document id
            text:     original text
            metadata: metadata for the document (optional)
            language: language of the document (optional)
            chunk_independently: split the document into chunks (optional)
        
        """
        if not text or not text.strip():
            logger.warning(f"⚠️ document is empty: {doc_id}")
            return {
                "success": False,
                "doc_id": doc_id,
                "error": "Empty document"
            }
        
        # التحقق من عدم تكرار المستند
        if doc_id in self.documents:
            logger.warning(f"⚠️ document {doc_id} already exists you can update it")
            return {
                "success": False,
                "doc_id": doc_id,
                "error": "Document already exists. Use update_document()"
            }
        
        try:
            logger.info(f"📄 resource document: {doc_id}")
            
            # كشف اللغة إذا لم تكن محددة
            if language is None:
                language = self._detect_language(text)
            
            # تقسيم النص إلى chunks مستقلة لهذا المستند فقط
            chunks = self._chunk_document(text, doc_id, language)
            
            if not chunks:
                logger.warning(f"⚠️ didn't create chunks for document: {doc_id}")
                return {
                    "success": False,
                    "doc_id": doc_id,
                    "error": "No chunks created"
                }
            
            # إضافة chunks إلى قاعدة البيانات المتجهة
            self.vector_db.add(chunks)
            
            # حفظ معلومات المستند
            doc_info = {
                "text": text,
                "chunks": len(chunks),
                "num_chunks": len(chunks),
                "metadata": metadata or {},
                "added_at": datetime.now().isoformat(),
                "language": language,
                "status": "active"
            }
            
            self.documents[doc_id] = doc_info
            
            # تحديث الإحصائيات
            self.stats["total_documents"] += 1
            self.stats["total_chunks"] += len(chunks)
            
            logger.info(f"✅ document added: {doc_id}: {len(chunks)} chunks")
            
            return {
                "success": True,
                "doc_id": doc_id,
                "num_chunks": len(chunks),
                "language": language,
                "metadata": doc_info["metadata"]
            }
            
        except Exception as e:
            logger.error(f"❌ add document is field  {doc_id}: {e}")
            return {
                "success": False,
                "doc_id": doc_id,
                "error": str(e)
            }
    
    def add_documents(
        self,
        documents: Union[Dict[str, str], List[Dict[str, Any]]],
        global_metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Dict[str, Any]]:
        """
        Add multiple documents at once
        
        Args:
            documents:
                - Dict[doc_id, text]: 
                - List[Dict]: 
                    [{"doc_id": "id1", "text": "...", "metadata": {...}}, ...]
            global_metadata: metadata for all documents (optional)
        
  
        """
        results = {}
        
        # تحويل القاموس البسيط إلى قائمة
        if isinstance(documents, dict):
            documents = [
                {"doc_id": doc_id, "text": text}
                for doc_id, text in documents.items()
            ]
        
        logger.info(f"📚  start adding {len(documents)} ")
        
        for doc in documents:
            doc_id = doc.get("doc_id")
            text = doc.get("text", "")
            
            if not doc_id:
                logger.warning("⚠️ document not have about id ,skiping...")
                continue
            
            # دمج metadata
            doc_metadata = doc.get("metadata", {})
            if global_metadata:
                doc_metadata.update(global_metadata)
            
            # إضافة المستند
            result = self.add_document(
                doc_id=doc_id,
                text=text,
                metadata=doc_metadata,
                language=doc.get("language")
            )
            
            results[doc_id] = result
        
        # ملخص النتائج
        successful = sum(1 for r in results.values() if r.get("success"))
        logger.info(f"✅  document added sucsessfully {successful}/{len(documents)}  ")
        
        return results
    
    def _chunk_document(
        self,
        text: str,
        doc_id: str,
        language: str
    ) -> List[Any]:
        """
        Chunk document safely and flexibly
        """

        try:

            # دعم chunk_text أو chunk
            fn = (
                self.chunker.chunk_text
                if hasattr(self.chunker, "chunk_text")
                else self.chunker.chunk
            )

            chunks = fn(text, doc_id)

            # مهم جدًا لو generator
            chunks = list(chunks)

            logger.info(
                f"✅ chunked document {doc_id} into {len(chunks)} chunks"
            )

            return chunks

        except Exception as e:
            logger.exception(
                f"❌ error while chunking document {doc_id}"
            )
            raise
       
    def _detect_language(self, text: str) -> str:
        """
        كشف لغة النص تلقائياً
        Detect text language automatically
        """
        # كشف بسيط بناءً على الأحرف
        arabic_chars = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        
        total_chars = len(text)
        
        if total_chars == 0:
            return "unknown"
        
        arabic_ratio = arabic_chars / total_chars
        chinese_ratio = chinese_chars / total_chars
        
        if arabic_ratio > 0.3:
            return "arabic"
        elif chinese_ratio > 0.3:
            return "chinese"
        else:
            return "english"
    
    # =========================================================================
    # تحديث وحذف المستندات | Update & Delete
    # =========================================================================
    
    def update_document(
        self,
        doc_id: str,
        new_text: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Update an existing document
        
        Returns:
          result of the update operation
        """
        if doc_id not in self.documents:
            logger.warning(f"⚠️ document: {doc_id} not found ")
            return {
                "success": False,
                "error": "Document not found"
            }
        
        try:
            # حذف المستند القديم
            self.remove_document(doc_id)
            # إضافة المستند الجديد
            old_metadata = self.documents.get(doc_id, {}).get("metadata", {})
            if metadata:
                old_metadata.update(metadata)
            
            result = self.add_document(
                doc_id=doc_id,
                text=new_text,
                metadata=old_metadata
            )
            
            logger.info(f"✅ updated document: {doc_id}")
            return result
            
        except Exception as e:
            logger.error(f"❌ error in update document{doc_id}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def remove_document(self, doc_id: str) -> Dict[str, Any]:
        """
        Remove a document from the system

        Returns:
            result of the remove operation
        """
        if doc_id not in self.documents:
            logger.warning(f"⚠️ document {doc_id}  not found")
            return {
                "success": False,
                "error": "Document not found"
            }
        
        try:
            # حذف chunks من قاعدة البيانات
            removed = self.vector_db.remove_by_doc_id(doc_id)
            
            # حذف من قائمة المستندات
            doc_info = self.documents.pop(doc_id)
            
            # تحديث الإحصائيات
            self.stats["total_documents"] -= 1
            self.stats["total_chunks"] -= doc_info["num_chunks"]
            
            logger.info(f"🗑️ deleated: {doc_id} ({removed} chunks)")
            
            return {
                "success": True,
                "doc_id": doc_id,
                "chunks_removed": removed
            }
            
        except Exception as e:
            logger.error(f"❌ error in deleate document {doc_id}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    # =========================================================================
    # الاستعلام | Query
    # =========================================================================
    
    def query(
        self,
        query: str,
        top_k: Optional[int] = None,
        filter_docs: Optional[List[str]] = None,
        include_sources: bool = True,
        language: str = "ar",
        **llm_kwargs
    ) -> Dict[str, Any]:
        """
        Query from all documents or specific documents
        
        Args:
            query: user query
            top_k: number of results to return (None = all)
            filter_docs:  list of str 'id' to document for search in.
            include_sources:  include source
            language: answer language 
            **llm_kwargs: extra info to LLM
        
        Returns:
             result with answer and sources
        """
        self.stats["total_queries"] += 1
        
        if not query or not query.strip():
            return {
                "success": False,
                "error": "Empty query"
            }
        
        try:
            # استرجاع النتائج
            k = top_k or (self.config.top_k if self.config else 5)
            
            # البحث في قاعدة البيانات
            results = self.vector_db.search(
                query,
                top_k=k
            )
            
            if not results:
                self.stats["failed_queries"] += 1
                return {
                    "success": False,
                    "answer": "no answer for your query",
                    "sources": []
                }
            
            # فلترة النتائج حسب المستندات المحددة
            if filter_docs:
                results = [
                    (chunk, score) for chunk, score in results
                    if getattr(chunk, 'doc_id', None) in filter_docs
                ]
            
            # بناء السياق
            context = self.context_manager.build(query, results)
            
            # توليد الإجابة
            prompt = self._build_prompt(query, context, language)
            answer = self.llm.generate(prompt, **llm_kwargs)
            
            # استخراج المصادر
            sources = self._extract_sources(results) if include_sources else []
            
            self.stats["successful_queries"] += 1
            
            return {
                "success": True,
                "answer": answer,
                "sources": sources,
                "num_results": len(results)
            }
            
        except Exception as e:
            logger.error(f"❌ error in query: {e}")
            self.stats["failed_queries"] += 1
            return {
                "success": False,
                "error": str(e)
            }
    
    def _build_prompt(self, query: str, context: str, language: str = "ar") -> str:
        """بناء prompt محسّن"""
        if language == "ar":
            return f"""أنت مساعد ذكي متخصص في الإجابة على الأسئلة بدقة.
                        استخدم المعلومات التالية للإجابة على السؤال بدقة ووضوح.
                        القواعد المهمة:
                        • أجب بناءً على المعلومات المقدمة فقط
                        • كن دقيقاً ومختصراً
                        .لا تكمل ولا تشرح ولا تستنتج
                        .اذا وجدت الملعومه في المستند اجب بنائا عليها اذا لم تجدها قل لاتوجد معلومات كافيه
                        • إذا لم تجد المعلومات الكافية، قل "لا توجد معلومات كافية للإجابة"
                        • • أجب باللغة العربية فقط ولا تستخدم أي لغة أخرى
                        المعلومات المتاحة:
                        {context}
                        السؤال: {query}
                        الإجابة:"""
        else:
            return f"""You are an intelligent assistant specialized in answering questions accurately.

                    Use the following information to answer the question accurately and clearly.
                    Important rules:
                    • Answer based only on the provided information
                    • Be accurate and concise
                    • If information is insufficient, say "Insufficient information to answer"
                    • • Answer strictly in English only
                    Available Information:
                    {context}
                    Question: {query}
                    Answer:"""
    
    def _extract_sources(self, results: List) -> List[Dict[str, Any]]:
        """استخراج المصادر من النتائج"""
        sources = []
        seen_docs = set()
        
        for chunk, score in results:
            doc_id = getattr(chunk, 'doc_id', 'unknown')
            
            if doc_id in seen_docs:
                continue
            
            seen_docs.add(doc_id)
            
            doc_info = self.documents.get(doc_id, {})
            
            sources.append({
                "doc_id": doc_id,
                "score": float(score),
                "language": doc_info.get("language", "unknown"),
                "metadata": doc_info.get("metadata", {})
            })
        
        return sources
    
    # =========================================================================
    # الإحصائيات والمعلومات | Statistics & Info
    # =========================================================================
    
    def get_document_info(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a specific document
        """
        return self.documents.get(doc_id)
    
    def list_documents(self) -> List[Dict[str, Any]]:
        """
        List all documents
        """
        return [
            {
                "doc_id": doc_id,
                "num_chunks": info["num_chunks"],
                "language": info["language"],
                "added_at": info["added_at"],
                "metadata": info["metadata"]
            }
            for doc_id, info in self.documents.items()
        ]
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get comprehensive statistics
        """
        return {
            **self.stats,
            "documents": {
                doc_id: {
                    "num_chunks": info["num_chunks"],
                    "language": info["language"]
                }
                for doc_id, info in self.documents.items()
            }
        }
    
    def get_document_stats_summary(self) -> Dict[str, Any]:
        """ملخص إحصائيات المستندات"""
        languages = {}
        for doc_id, info in self.documents.items():
            lang = info.get("language", "unknown")
            languages[lang] = languages.get(lang, 0) + 1
        
        return {
            "total_documents": len(self.documents),
            "total_chunks": self.stats["total_chunks"],
            "languages": languages,
            "avg_chunks_per_doc": (
                self.stats["total_chunks"] / len(self.documents)
                if self.documents else 0
            )
        }
    
    # =========================================================================
    # الحفظ والتحميل | Save & Load
    # =========================================================================
    
    def save(self, path: str) -> None:
        """save system"""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        
        # حفظ قاعدة البيانات
        self.vector_db.save(path / "vector_db")
        
        # حفظ معلومات المستندات
        with open(path / "documents.json", "w", encoding="utf-8") as f:
            json.dump(self.documents, f, indent=2, ensure_ascii=False)
        
        # حفظ الإحصائيات
        with open(path / "stats.json", "w", encoding="utf-8") as f:
            json.dump(self.stats, f, indent=2, ensure_ascii=False)
        
        logger.info(f"💾 system saved: {path}")
    
    @classmethod
    def load(
        cls,
        path: str,
        vector_db: Any,
        llm: Any,
        chunker: Any,
        context_manager: Any,
        config: Optional[Any] = None
    ) -> "MultiDocumentRAGSystem":
        """load system"""
        path = Path(path)
        
        if not path.exists():
            raise FileNotFoundError(f" path not found: {path}")
        
        # تحميل قاعدة البيانات
        vector_db.load(path / "vector_db")
        
        # إنشاء النظام
        system = cls(
            vector_db=vector_db,
            llm=llm,
            chunker=chunker,
            context_manager=context_manager,
            config=config
        )
        
        # تحميل المستندات
        with open(path / "documents.json", "r", encoding="utf-8") as f:
            system.documents = json.load(f)
        
        # تحميل الإحصائيات
        with open(path / "stats.json", "r", encoding="utf-8") as f:
            system.stats = json.load(f)
        
        logger.info(f"system loaded: {path}")
        return system
    
    def __repr__(self) -> str:
        return (
            f"MultiDocumentRAGSystem("
            f"documents={len(self.documents)}, "
            f"chunks={self.stats['total_chunks']}, "
            f"queries={self.stats['total_queries']})"
        )
    # ── Async API ────────────────────────────────────────────────────
    async def agenerate(self, query: str, **kwargs) -> str:
        import asyncio
        return await asyncio.to_thread(self.generate, query, **kwargs)

    async def aretrieve(self, query: str, **kwargs):
        import asyncio
        fn = getattr(self, "retrieve_with_context", None) or getattr(self, "retrieve", None)
        if fn:
            return await asyncio.to_thread(fn, query, **kwargs)
        return []

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False
