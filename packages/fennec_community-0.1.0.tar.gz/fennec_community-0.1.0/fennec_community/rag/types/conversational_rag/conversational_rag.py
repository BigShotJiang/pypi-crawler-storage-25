import logging
from typing import List, Tuple, Optional
from .conversation_config import RAGConfigConverstion
from .conversation_turn import ConversationTurn
from .conversation_history import ConversationHistory
import json
import os
from pathlib import Path
config = RAGConfigConverstion()
logger = logging.getLogger(__name__)



class ConversationalRAG:
    """
    RAG system with conversation history and live JSON persistence
    """
    
    def __init__(self, 
                 rag_system, 
                 max_history_turns: int = config.max_history_turns,
                 context_turns: int = config.context_turns,
                 enable_context_compression: bool = config.enable_context_compression,
                 instructions: Optional[str] = None,
                 lang: str = 'ar',
                 history_file: Optional[str] = None,
                 auto_save: bool = True):
        """
        Initialize conversation system
        
        Args:
            rag_system: Base RAG system
            max_history_turns: Number of turns saved in history
            context_turns: Number of turns used in context
            enable_context_compression: Enable context compression for long conversations
            instructions: Instructions for the model
            lang: Language ('ar' or 'en') for default instructions
            history_file: JSON file path for saving (None = automatic)
            auto_save: Auto-save after each question
        """
        if rag_system is None:
            raise ValueError("rag_system is required")
        
        self.rag = rag_system
        self.history = ConversationHistory(
            max_turns=max_history_turns,
            history_file=history_file
        )
        self.context_turns = context_turns
        self.enable_context_compression = enable_context_compression
        self.auto_save = auto_save

        # FIX: حفظ اللغة لاستخدامها في _build_conversational_prompt
        # Save lang for use in _build_conversational_prompt
        self.lang = lang
        
        # التعليمات الافتراضية
        # Default instructions
        if instructions is None:
            if lang == "ar":
                self.instructions = """
                                    أجب باستخدام المعلومات الموجودة في السياق فقط.
                                    قواعد صارمة:
                                    - لا تستخدم أي معرفة خارج السياق
                                    - لا تضف معلومات من نفسك
                                    - إذا لم تجد الإجابة في السياق قل: لا أعرف
                                    - لا تترجم أو تعيد صياغة خارج النص
                                    - لا تخلط بين السياق ومعرفتك
                                    -اجب بنفس لغه السوال
                                    أجب باللغة المطلوبة فقط.
                                    """
            elif lang == "en":
                self.instructions = f"""
                                        You are a helpful assistant. You MUST answer ONLY based on the retrieved context below.
                                        - Use retrieved information to answer; do NOT add any information from your own knowledge.
                                        - Be accurate and concise.
                                        - If the answer is not in the retrieved context, respond: "لا توجد معلومات كافية" (or "I don't have enough information").
                                        - Maintain previous conversation context ONLY if relevant.
                                        - Answer strictly in the requested language.
                                        -answer with same query language
                                        """
            # FIX: أي لغة أخرى كانت تترك self.instructions غير معرّفة → AttributeError
            # Any other lang left self.instructions undefined → AttributeError
            else:
                self.instructions = """You are a helpful assistant answering questions based on available information.
                                - Use retrieved information to answer
                                - Be accurate and concise
                                - If information is insufficient, mention it"""
        else:
            self.instructions = instructions
        
        # إحصائيات
        # Statistics
        self.stats = {
            'total_queries': 0,
            'context_used_count': 0,
            'total_chunks_retrieved': 0
        }
        
        logger.info("✅ Conversational RAG is ready ")
        logger.info(f"📁 History file: {self.history.get_file_path()}")
    
    def ask(self, 
            query: str, 
            include_sources: bool = config.include_sources,
            use_history: bool = config.use_history) -> str:
        """
        Ask a question to the conversational system
        
        Args:
            query: Question
            include_sources:  Include sources in answer
            use_history: Use conversation history
            
        Returns:
            Answer
        """
        if not query or not query.strip() or len(query) == 1:
            return "⚠️Please enter a valid question"
        
        self.stats['total_queries'] += 1
        
        try:
            enhanced_query = self._enhance_query_with_context(query, use_history)
            chunks = self.rag.retrieve(enhanced_query)
            
            if not chunks:
                answer = "I don't have enough information to answer "
                # FIX: كان يُمرّر 0 (int) لمعامل chunks الذي نوعه List → TypeError
                # Was passing 0 (int) for chunks param which expects List → TypeError
                self.history.add_turn(query, answer, None, 0)
                return answer
            
            self.stats['total_chunks_retrieved'] += len(chunks)
            context = self.rag.context_manager.build(enhanced_query, chunks)
            
            prompt = self._build_conversational_prompt(query, context, use_history)
            answer = self.rag.llm.generate(prompt) if self.rag.llm else "⚠️ LLM isn't available"
            
            if include_sources:
                sources = self._format_sources(chunks)
                answer = f"{answer}\n\n{sources}"
            
            self.history.add_turn(query, answer, chunks, len(chunks))
            
            if use_history:
                self.stats['context_used_count'] += 1
            
            return answer
            
        except Exception as e:
            logger.error(f"❌ Error processing question: {e}")
            error_msg = f"Sorry, an error occurred: {str(e)}"
            # FIX: نفس المشكلة — 0 بدلاً من None
            # Same issue — 0 instead of None
            self.history.add_turn(query, error_msg, None, 0)
            return error_msg

    def _enhance_query_with_context(self, query: str, use_history: bool) -> str:
        """
        Enhance query with context from history
        """
        if not use_history or len(self.history) == 0:
            return query
        
        recent_turns = self.history.get_recent_turns(2)
        
        context_indicators = [
        'هذا', 'ذلك', 'نفسه', 'أيضاً', 'كذلك', 'بالإضافة',
        'هذه', 'تلك', 'ذاته', 'علاوة', 'فضلاً', 'إضافةً',
        'المذكور', 'السابق', 'المشار', 'أعلاه', 'المذكورة', 'ذلكم',
        'ده', 'دي', 'دول', 'كمان', 'برضو', 'برضه',
        'بالظبط', 'زيه', 'نفس الكلام', 'هو ده',
        'هيدا', 'هيدي', 'هدول', 'كمان', 'كمان هو', 'متلو',
        'نفس الشي', 'هالشي', 'هيك', 'بالمتل',
        'هذاك', 'ذيك', 'چذي', 'زين', 'أيضاً هو', 'نفس الشي',
        'هو ذا', 'وايد', 'بعد', 'چذا',
        'هادا', 'هادي', 'هادو', 'بحال', 'كيفاش', 'زعما',
        'بزاف', 'حتى هو',
        'هاذا', 'هاي', 'نفس الشغلة', 'هواية',
        'this', 'that', 'it', 'also', 'too', 'as well',
        'itself', 'himself', 'herself', 'themselves',
        'the same', 'likewise', 'similarly', 'in the same way',
        'aforementioned', 'the above', 'the latter', 'the former',
        'said', 'such', 'these', 'those', 'thereof', 'therein',
        'furthermore', 'moreover', 'additionally', 'besides',
        'in addition', 'on top of that', 'what\'s more', 'plus',
        'not only', 'along with', 'together with', 'coupled with',
        'indeed', 'accordingly', 'as mentioned', 'as noted',
        'as stated', 'referring to', 'regarding', 'concerning',
        'with respect to', 'in relation to', 'in this regard',
        'in that sense', 'on that note', 'to that end',
  ]   
        
        if os.path.exists("context_indicators.txt"):
            try:
                with open("context_indicators.txt", "r", encoding="utf-8") as file:
                    context_indicators.extend(file.read().splitlines())
            except Exception as e:
                logger.warning(f"⚠️ Failed to load context_indicators.txt: {e}")
        
        needs_context = any(word in query for word in context_indicators)
        
        if needs_context and recent_turns:
            last_query = recent_turns[-1].query
            enhanced = f"{last_query}. {query}"
            logger.info(f"🔗 Query enhanced with context: {enhanced}")
            return enhanced
        
        return query
    
    def _build_conversational_prompt(self, query: str, context: str, use_history: bool) -> str:
        """
        Build a strict prompt with conversation history and retrieved context
        """
        history_text = ""
        if use_history and len(self.history) > 0:
            history_text = self.history.format_for_prompt(
                n=self.context_turns,
                language=self.lang
            )
    
        # تعليمات صارمة تمنع الموديل من الهلوسة خارج السياق
        instructions_strict = f"""
        {self.instructions}
        ⚠️ IMPORTANT: Use ONLY the information in the retrieved context above.
        - Do NOT add any information from your own knowledge.
        - If the answer is not in the context, say: "لا توجد معلومات كافية" (or "I don't have enough information").
        - Answer strictly in the requested language ({self.lang}).
        """
    
        prompt = f"""
                    ### Conversation History:
                    {history_text}
                    ### Retrieved Context (ONLY source of truth):
                    {context}
                    ### Instructions:
                    {instructions_strict}
                    ### Question:
                    {query}
                    ### Answer:
                    """
    
        return prompt
    
    def _format_sources(self, chunks: List[Tuple]) -> str:
        """
        Format sources for answer
        """
        if not chunks:
            return ""
        
        sources = []
        seen_docs = set()
        
        for chunk, score in chunks[:3]:
            if chunk.doc_id not in seen_docs:
                sources.append(f"- {chunk.doc_id} (similarity: {score:.2f})")
                seen_docs.add(chunk.doc_id)
        
        return "📚 Sources:\n" + "\n".join(sources) if sources else ""
    
    def reset_conversation(self):
        """Reset entire conversation history"""
        self.history.clear()
        logger.info("🔄 Conversation history reset")
    
    def get_conversation_summary(self) -> dict:
        """Get conversation summary"""
        return {
            'total_turns': len(self.history),
            'total_queries': self.stats['total_queries'],
            'context_used_count': self.stats['context_used_count'],
            'total_chunks_retrieved': self.stats['total_chunks_retrieved'],
            'avg_chunks_per_query': (
                self.stats['total_chunks_retrieved'] / self.stats['total_queries']
                if self.stats['total_queries'] > 0 else 0
            ),
            'history_file': self.history.get_file_path(),
            'recent_topics': [
                turn.query[:50] + "..." if len(turn.query) > 50 else turn.query
                for turn in self.history.get_recent_turns(5)
            ]
        }
    
    def export_conversation(self, format: str = 'json', output_file: Optional[str] = None) -> str:
        """Export conversation history"""
        if format == 'text':
            content = "\n\n".join(str(turn) for turn in self.history.turns)
        elif format == 'json':
            data = [turn.to_dict() for turn in self.history.turns]
            content = json.dumps(data, ensure_ascii=False, indent=2)
        else:
            raise ValueError(f"Format not supported : {format}")
        
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info(f"💾 Conversation exported to: {output_file}")
        
        return content
    
    def load_conversation_from_file(self, file_path: str):
        """Load conversation history from file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            turns_data = data.get('turns', data)
            self.history.turns = [
                ConversationTurn.from_dict(turn_data)
                for turn_data in turns_data
            ]
            logger.info(f"✅ Loaded {len(self.history.turns)} turns from : {file_path}")
            
        except Exception as e:
            logger.error(f"❌ Failed to load from file: {e}")
            raise
    
    def get_history_file_path(self) -> str:
        """ Get history file path"""
        return self.history.get_file_path()
    
    def __repr__(self) -> str:
        return (f"ConversationalRAG(turns={len(self.history)}, "
                f"queries={self.stats['total_queries']}, "
                f"file={Path(self.history.get_file_path()).name})")

    # ── Async API ────────────────────────────────────────────────────

    async def aask(self, query: str, use_history: bool = True,
                   include_sources: bool = False, **kwargs) -> str:
        """
        Async conversational query — maintains history context.
        """
        import asyncio
        # FIX: الترتيب كان معكوساً — signature هو ask(query, include_sources, use_history)
        # Order was reversed — signature is ask(query, include_sources, use_history)
        return await asyncio.to_thread(
            self.ask, query, include_sources, use_history
        )

    async def astream(self, query: str, use_history: bool = True):
        """Async streaming conversational answer."""
        import asyncio
        enhanced_query = self._enhance_query_with_context(query, use_history)
        # FIX: self.rag_system غير موجود — الاسم الصحيح هو self.rag
        # self.rag_system does not exist — correct attribute name is self.rag
        rag_system = self.rag

        if hasattr(rag_system, "astream"):
            async for token in rag_system.astream(enhanced_query):
                yield token
        else:
            answer = await self.aask(query, use_history)
            for word in answer.split(" "):
                yield word + " "
                await asyncio.sleep(0)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False