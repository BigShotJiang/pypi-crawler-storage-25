from collections import defaultdict, deque
from typing import Dict, List, Set, Optional, Any
import logging
from .edges import GraphEdge
from .node import GraphNode
from .config import ConfigGraphRAG
logger = logging.getLogger(__name__)



class KnowledgeGraph:
    """
    Knowledge graph implementation with efficient storage and traversal.
    """

    def __init__(self, config: Optional[ConfigGraphRAG] = None):
        """Initialize empty knowledge graph.

        Args:
            config: GraphRAG configuration.  Defaults to ConfigGraphRAG()
                    when not supplied so standalone usage still works.
        """
        self.config = config or ConfigGraphRAG()
        self.nodes: Dict[str, GraphNode] = {}
        self.edges: List[GraphEdge] = []
        self.adjacency: Dict[str, List[str]] = defaultdict(list)
        self._edge_lookup: Dict[str, GraphEdge] = {}
        self._reverse_adj: Dict[str, List[str]] = defaultdict(list)
        self._in_degree: Dict[str, int] = defaultdict(int)
        logger.info("Knowledge graph initialized")

    # ------------------------------------------------------------------
    # Node management
    # ------------------------------------------------------------------

    def add_node(self, node: GraphNode) -> bool:
        """Add node to graph. Returns True if new, False if updated."""
        try:
            is_new = node.id not in self.nodes
            self.nodes[node.id] = node
            logger.debug(f"{'Added' if is_new else 'Updated'} node: {node.id}")
            return is_new
        except Exception as e:
            logger.error(f"Failed to add node {node.id}: {e}")
            return False

    def remove_node(self, node_id: str) -> bool:
        """Remove node and all connected edges."""
        if node_id not in self.nodes:
            logger.warning(f"Node {node_id} does not exist")
            return False
        try:
            del self.nodes[node_id]

            # Remove edges and update degree counters
            kept = []
            for e in self.edges:
                if e.source == node_id or e.target == node_id:
                    self._in_degree[e.target] = max(0, self._in_degree[e.target] - 1)
                else:
                    kept.append(e)
            self.edges = kept

            # Rebuild derived structures (only on deletion — rare op)
            self._edge_lookup = {e.edge_id: e for e in self.edges}
            self._rebuild_adjacency()
            logger.debug(f"Removed node: {node_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to remove node {node_id}: {e}")
            return False

    def get_node(self, node_id: str) -> Optional[GraphNode]:
        return self.nodes.get(node_id)

    # ------------------------------------------------------------------
    # Edge management
    # ------------------------------------------------------------------

    def add_edge(self, edge: GraphEdge) -> bool:
        """Add edge to graph. Returns True if successful."""
        try:
            if edge.source not in self.nodes:
                logger.warning(f"Source node {edge.source} does not exist")
                return False
            if edge.target not in self.nodes:
                logger.warning(f"Target node {edge.target} does not exist")
                return False

            edge_id = edge.edge_id
            if edge_id in self._edge_lookup:
                # Update weight on duplicate
                self._edge_lookup[edge_id].weight = edge.weight
                logger.debug(f"Updated existing edge: {edge_id}")
                return True

            # Add edge
            self.edges.append(edge)
            self._edge_lookup[edge_id] = edge

            # Update outgoing adjacency
            self.adjacency[edge.source].append(edge.target)

            self._reverse_adj[edge.target].append(edge.source)
            self._in_degree[edge.target] += 1

            if edge.bidirectional:
                self.adjacency[edge.target].append(edge.source)
                self._reverse_adj[edge.source].append(edge.target)
                self._in_degree[edge.source] += 1

            logger.debug(f"Added new edge: {edge_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to add edge {edge.edge_id}: {e}")
            return False

    def get_edge(self, source: str, target: str, relation: str) -> Optional[GraphEdge]:
        return self._edge_lookup.get(f"{source}-{relation}->{target}")

    # ------------------------------------------------------------------
    # Traversal
    # ------------------------------------------------------------------

    def get_neighbors(
        self,
        node_id: str,
        max_depth: int = None,
        include_incoming: bool = True,
    ) -> Set[str]:
        """
        Get neighbors using BFS.
        """
        if max_depth is None:
            max_depth = self.config.max_depth   # FIX 6: instance config

        if node_id not in self.nodes:
            logger.warning(f"Node {node_id} does not exist")
            return set()

        visited: Set[str] = set()
        queue = deque([(node_id, 0)])

        while queue:
            current, depth = queue.popleft()
            if current in visited or depth > max_depth:
                continue
            visited.add(current)

            for neighbor in self.adjacency.get(current, []):
                if neighbor not in visited:
                    queue.append((neighbor, depth + 1))

            if include_incoming:
                # FIX 6: O(1) — no per-call rebuild
                for neighbor in self._reverse_adj.get(current, []):
                    if neighbor not in visited:
                        queue.append((neighbor, depth + 1))

        visited.discard(node_id)
        return visited

    def find_path(
        self, start: str, end: str, max_length: Optional[int] = None
    ) -> Optional[List[str]]:
        """Shortest path via BFS."""
        if start not in self.nodes or end not in self.nodes:
            logger.warning("Start or end node does not exist")
            return None
        if start == end:
            return [start]

        visited = {start}
        queue = deque([(start, [start])])
        while queue:
            current, path = queue.popleft()
            if max_length and len(path) > max_length:
                continue
            if current == end:
                return path
            for neighbor in self.adjacency.get(current, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        return None

    def find_all_paths(self, start: str, end: str, max_length: int = 5) -> List[List[str]]:
        """All paths via DFS (up to max_length)."""
        if start not in self.nodes or end not in self.nodes:
            return []
        all_paths: List[List[str]] = []

        def dfs(current: str, path: List[str], visited: Set[str]):
            if len(path) > max_length:
                return
            if current == end:
                all_paths.append(path.copy())
                return
            for neighbor in self.adjacency.get(current, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    path.append(neighbor)
                    dfs(neighbor, path, visited)
                    path.pop()
                    visited.remove(neighbor)

        dfs(start, [start], {start})
        return all_paths

    # ------------------------------------------------------------------
    # Subgraph / analytics
    # ------------------------------------------------------------------

    def get_subgraph(self, node_ids: Set[str]) -> "KnowledgeGraph":
        """Extract subgraph containing specified nodes."""
        # FIX 6: pass config so subgraph inherits same settings
        subgraph = KnowledgeGraph(config=self.config)
        for node_id in node_ids:
            if node_id in self.nodes:
                subgraph.add_node(self.nodes[node_id])
        for edge in self.edges:
            if edge.source in node_ids and edge.target in node_ids:
                subgraph.add_edge(edge)
        logger.debug(
            f"Created subgraph with {len(subgraph.nodes)} nodes "
            f"and {len(subgraph.edges)} edges"
        )
        return subgraph

    def get_node_degree(self, node_id: str) -> Dict[str, int]:
        """
        O(1) degree lookup.

        FIX 7: uses pre-built ``_in_degree`` counter and adjacency length
        instead of scanning every adjacency list (was O(nodes)).
        """
        if node_id not in self.nodes:
            return {"in_degree": 0, "out_degree": 0, "total_degree": 0}
        out_degree = len(self.adjacency.get(node_id, []))
        in_degree  = self._in_degree.get(node_id, 0)    # FIX 7: O(1)
        return {
            "in_degree":    in_degree,
            "out_degree":   out_degree,
            "total_degree": in_degree + out_degree,
        }

    def get_connected_components(self) -> List[Set[str]]:
        """Find all connected components (undirected view)."""
        visited: Set[str] = set()
        components: List[Set[str]] = []

        def bfs_component(start: str) -> Set[str]:
            component: Set[str] = set()
            queue = deque([start])
            while queue:
                node = queue.popleft()
                if node in component:
                    continue
                component.add(node)
                for neighbor in self.adjacency.get(node, []):
                    if neighbor not in component:
                        queue.append(neighbor)
                # reverse edges — use pre-built reverse_adj (FIX 6)
                for neighbor in self._reverse_adj.get(node, []):
                    if neighbor not in component:
                        queue.append(neighbor)
            return component

        for node_id in self.nodes:
            if node_id not in visited:
                component = bfs_component(node_id)
                components.append(component)
                visited.update(component)
        return components

    def get_stats(self) -> Dict[str, Any]:
        node_degrees = [len(neighbors) for neighbors in self.adjacency.values()]
        return {
            "num_nodes":      len(self.nodes),
            "num_edges":      len(self.edges),
            "avg_degree":     sum(node_degrees) / len(node_degrees) if node_degrees else 0,
            "max_degree":     max(node_degrees) if node_degrees else 0,
            "min_degree":     min(node_degrees) if node_degrees else 0,
            "num_components": len(self.get_connected_components()),
            "density": (
                len(self.edges) / (len(self.nodes) * (len(self.nodes) - 1))
                if len(self.nodes) > 1 else 0
            ),
        }

    def validate_integrity(self) -> Dict[str, List[str]]:
        issues: Dict[str, List[str]] = {
            "orphan_edges":    [],
            "duplicate_edges": [],
            "self_loops":      [],
        }
        seen_edges: Set[tuple] = set()
        for edge in self.edges:
            if edge.source not in self.nodes:
                issues["orphan_edges"].append(f"Source {edge.source} not found")
            if edge.target not in self.nodes:
                issues["orphan_edges"].append(f"Target {edge.target} not found")
            if edge.source == edge.target:
                issues["self_loops"].append(edge.edge_id)
            t = (edge.source, edge.target, edge.relation)
            if t in seen_edges:
                issues["duplicate_edges"].append(edge.edge_id)
            seen_edges.add(t)
        return issues

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _rebuild_adjacency(self) -> None:
        """Full rebuild of adjacency, reverse_adj, and in_degree from edges."""
        self.adjacency    = defaultdict(list)
        self._reverse_adj = defaultdict(list)
        self._in_degree   = defaultdict(int)
        for edge in self.edges:
            self.adjacency[edge.source].append(edge.target)
            self._reverse_adj[edge.target].append(edge.source)
            self._in_degree[edge.target] += 1
            if edge.bidirectional:
                self.adjacency[edge.target].append(edge.source)
                self._reverse_adj[edge.source].append(edge.target)
                self._in_degree[edge.source] += 1

    def __repr__(self) -> str:
        return f"KnowledgeGraph(nodes={len(self.nodes)}, edges={len(self.edges)})"