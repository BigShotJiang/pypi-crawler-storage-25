# -*- coding: utf-8 -*-
"""
Node module for knowledge graph
Defines GraphNode with enhanced features
Node:
id = "Paris"
content = "Paris is the capital of France"
node_type = "city"
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import hashlib



@dataclass
class GraphNode:
    """
    Represents a node in the knowledge graph
    
    Attributes:
        id: Unique identifier for the node
        content: Text content of the node
        node_type: Type/category of the node (e.g., 'entity', 'concept')
        metadata: Additional metadata dictionary
        embedding: Vector embedding (stored separately for efficiency)
        created_at: Timestamp of node creation
        updated_at: Timestamp of last update
    """
    
    id: str
    content: str
    node_type: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    
    def __post_init__(self):
        """Validate node after initialization"""
        if not self.id:
            raise ValueError("Node ID cannot be empty")
        
        if not self.content:
            raise ValueError("Node content cannot be empty")
        
        if not self.node_type:
            raise ValueError("Node type cannot be empty")
    
    @property
    def has_embedding(self) -> bool:
        """Check if node has an embedding"""
        return self.embedding is not None and len(self.embedding) > 0
    
    def get_content_hash(self) -> str:
        """
        Generate hash of content for change detection
        
        Returns:
            MD5 hash of content
        """
        return hashlib.md5(self.content.encode('utf-8')).hexdigest()
    
    def to_dict(self, include_embedding: bool = False) -> Dict[str, Any]:
        """
        Convert node to dictionary
        
        Args:
            include_embedding: Whether to include embedding in output
        
        Returns:
            Dictionary representation of node
        """
        result = {
            'id': self.id,
            'content': self.content,
            'node_type': self.node_type,
            'metadata': self.metadata.copy()
        }
        
        if include_embedding and self.has_embedding:
            result['embedding'] = self.embedding
        
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GraphNode':
        """
        Create node from dictionary
        
        Args:
            data: Dictionary with node data
        
        Returns:
            GraphNode instance
        """
        return cls(
            id=data['id'],
            content=data['content'],
            node_type=data['node_type'],
            metadata=data.get('metadata', {}),
            embedding=data.get('embedding')
        )
    
    def update_metadata(self, key: str, value: Any) -> None:
        """
        Update a metadata field
        
        Args:
            key: Metadata key
            value: Metadata value
        """
        self.metadata[key] = value
    
    def merge_metadata(self, metadata: Dict[str, Any]) -> None:
        """
        Merge new metadata with existing
        
        Args:
            metadata: Dictionary of metadata to merge
        """
        self.metadata.update(metadata)
    
    def __repr__(self) -> str:
        """String representation of node"""
        content_preview = self.content[:50] + "..." if len(self.content) > 50 else self.content
        return f"GraphNode(id='{self.id}', type='{self.node_type}', content='{content_preview}')"
    
    def __eq__(self, other) -> bool:
        """Check equality based on ID"""
        if not isinstance(other, GraphNode):
            return False
        return self.id == other.id
    
    def __hash__(self) -> int:
        """Hash based on ID for use in sets/dicts"""
        return hash(self.id)