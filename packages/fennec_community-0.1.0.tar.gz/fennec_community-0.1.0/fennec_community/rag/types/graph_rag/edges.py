"""
Edge module for knowledge graph
Defines GraphEdge with enhanced features
(Paris) ---[capital_of]---> (France)
Paris = source
France = target
capital_of = relation
"""

from dataclasses import dataclass, field
from typing import Dict, Any


@dataclass
class GraphEdge:
    """
    Represents a directed edge in the knowledge graph
    
    Attributes:
        source: Source node ID
        target: Target node ID
        relation: Type of relationship
        weight: Edge weight (default 1.0)
        metadata: Additional metadata dictionary
        bidirectional: Whether edge is bidirectional
    """
    
    source: str
    target: str
    relation: str
    weight: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    bidirectional: bool = False
    
    def __post_init__(self):
        """Validate edge after initialization"""
        if not self.source:
            raise ValueError("Source node ID cannot be empty")
        
        if not self.target:
            raise ValueError("Target node ID cannot be empty")
        
        if not self.relation:
            raise ValueError("Relation type cannot be empty")
        
        if self.weight < 0:
            raise ValueError("Edge weight cannot be negative")
        
        if self.source == self.target:
            raise ValueError("Self-loops are not allowed")
    
    @property
    def edge_id(self) -> str:
        """Generate unique edge identifier"""
        return f"{self.source}-{self.relation}->{self.target}"
    
    def reverse(self) -> 'GraphEdge':
        """
        Create reverse edge
        
        Returns:
            New GraphEdge with reversed direction
        """
        return GraphEdge(
            source=self.target,
            target=self.source,
            relation=f"inverse_{self.relation}",
            weight=self.weight,
            metadata=self.metadata.copy(),
            bidirectional=self.bidirectional
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert edge to dictionary
        
        Returns:
            Dictionary representation of edge
        """
        return {
            'source': self.source,
            'target': self.target,
            'relation': self.relation,
            'weight': self.weight,
            'metadata': self.metadata.copy(),
            'bidirectional': self.bidirectional
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GraphEdge':
        """
        Create edge from dictionary
        
        Args:
            data: Dictionary with edge data
        
        Returns:
            GraphEdge instance
        """
        return cls(
            source=data['source'],
            target=data['target'],
            relation=data['relation'],
            weight=data.get('weight', 1.0),
            metadata=data.get('metadata', {}),
            bidirectional=data.get('bidirectional', False)
        )
    
    def update_weight(self, new_weight: float) -> None:
        """
        Update edge weight
        
        Args:
            new_weight: New weight value
        """
        if new_weight < 0:
            raise ValueError("Edge weight cannot be negative")
        self.weight = new_weight
    
    def __repr__(self) -> str:
        """String representation of edge"""
        arrow = "<->" if self.bidirectional else "->"
        return f"GraphEdge({self.source} {arrow} {self.target} [{self.relation}] w={self.weight})"
    
    def __eq__(self, other) -> bool:
        """Check equality based on source, target, and relation"""
        if not isinstance(other, GraphEdge):
            return False
        return (self.source == other.source and 
                self.target == other.target and 
                self.relation == other.relation)
    
    def __hash__(self) -> int:
        """Hash based on edge_id for use in sets/dicts"""
        return hash(self.edge_id)