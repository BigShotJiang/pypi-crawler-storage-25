from typing import Any, Dict, List, Optional
import json
import logging
import re
from .self_improving_rag import LLMCallError, RetrievalError, _call_llm, _retrieve_safe
from .self_config import RecursiveRAGConfig, _DECOMPOSE_PROMPT, _MERGE_PROMPT
from .self_rag_dataclass import RecursiveRAGResult, SubAnswer
logger = logging.getLogger(__name__)


class RecursiveRAG:
    """
    Recursive RAG – decomposes complex questions and answers recursively.
    Simple questions are answered directly.  Complex ones are split into
    sub-questions, each answered (potentially recursively), then the
    sub-answers are synthesised into a final answer.

    Example::

        rag = RecursiveRAG(rag_system, llm, config=RecursiveRAGConfig(max_depth=3))
        result = rag.query("ما هي أسباب ونتائج الثورة الصناعية؟")
        print(result.answer)
        print(result.sub_questions)
    """

    def __init__(
        self,
        rag_system: Any,
        llm: Any,
        config: Optional[RecursiveRAGConfig] = None,
    ) -> None:
        if not llm:
            raise ValueError("RecursiveRAG requires an LLM.")
        self.rag_system = rag_system
        self.llm = llm
        self.config = config or RecursiveRAGConfig()

    def query(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
        _depth: int = 0,
    ) -> RecursiveRAGResult:
        """
        Recursively answer *query*.

        Args:
            query:    Natural-language question.
            context:  Optional extra context.
            _depth:   Internal recursion depth counter (do not set manually).

        Returns:
            :class:`RecursiveRAGResult` with answer and decomposition trace.
        """
        logger.info("🔁 RecursiveRAG | depth=%d | query=%r", _depth, query[:80])

        if _depth >= self.config.max_depth or not self._is_complex(query):
            reason = "max_depth" if _depth >= self.config.max_depth else "simple"
            logger.info("  → answering directly (%s)", reason)
            return self._answer_directly(query, depth=_depth)

        sub_questions = self._decompose(query)
        if len(sub_questions) <= 1:
            logger.info("  → decomposition yielded ≤1 sub-question; answering directly")
            return self._answer_directly(query, depth=_depth)

        logger.info("  → %d sub-questions", len(sub_questions))

        sub_answers: List[SubAnswer] = []
        for i, sq in enumerate(sub_questions):
            logger.info("    [%d/%d] %r", i + 1, len(sub_questions), sq[:70])
            sub_result = self.query(sq, context, _depth=_depth + 1)
            sub_answers.append(SubAnswer(question=sq, answer=sub_result.answer, depth=_depth + 1))

        final_answer = self._merge(query, sub_answers)

        return RecursiveRAGResult(
            answer=final_answer,
            depth=_depth,
            decomposed=True,
            sub_questions=sub_questions,
            sub_answers=sub_answers,
        )

    def add_document(self, text: str, metadata: Optional[Dict[str, Any]] = None) -> Any:
        return self.rag_system.add_document(text, metadata if metadata is not None else {})

    # ── Private Helpers ───────────────────────────────────────────────────

    def _is_complex(self, query: str) -> bool:
        """
        Heuristic complexity check.

        A query is considered complex if it is long enough AND contains
        at least two complexity keyword markers.
        """
        if len(query) < self.config.min_query_length:
            return False
        q_lower = query.lower()
        hits = sum(1 for kw in self.config.complexity_keywords if kw in q_lower)
        return hits >= 2

    def _decompose(self, query: str) -> List[str]:
        """Ask the LLM to split *query* into sub-questions (JSON array)."""
        prompt = _DECOMPOSE_PROMPT.format(
            query=query, max_sub=self.config.max_sub_questions
        )
        try:
            raw = _call_llm(self.llm, prompt, retries=self.config.llm_retries)
        except LLMCallError as exc:
            logger.warning("  Decomposition LLM call failed: %s", exc)
            return []

        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        try:
            candidates = json.loads(clean)
            if isinstance(candidates, list):
                return [str(q).strip() for q in candidates if len(str(q).strip()) > 8][
                    : self.config.max_sub_questions
                ]
        except json.JSONDecodeError:
            pass

        sub_questions: List[str] = []
        for line in raw.splitlines():
            line = line.strip()
            m = re.match(r"^(?:\d+[.)]\s*|-\s*)(.+)", line)
            if m:
                q = m.group(1).strip()
                if len(q) > 8:
                    sub_questions.append(q)
        return sub_questions[: self.config.max_sub_questions]

    def _answer_directly(self, query: str, depth: int) -> RecursiveRAGResult:
        """
        Answer without further decomposition.
        """
        try:
            docs = _retrieve_safe(self.rag_system, query)
        except RetrievalError as exc:
            logger.error("❌ Retrieval failed in _answer_directly: %s", exc)
            docs = []

        if not docs:
            return RecursiveRAGResult(
                answer="There is not enough information.",
                depth=depth,
                decomposed=False,
            )

        context = "\n\n".join(
            d.get("text", "") for d in docs[:5] if d.get("text")
        )
        prompt = (
            "أنت مساعد ذكي. أجب على السؤال التالي بناءً على السياق المقدم فقط.\n\n"
            f"اجب بنفس اللغه الموجوده في السؤال\n"
            f"لا تعطي اجابه مش موجوده في السياق \n"
            f"لاتعطي امثله ايضا ليسلها علاقه بالسؤال وغير موجوده في السياق\n"
            f"السياق:\n{context}\n\n"
            f"السؤال: {query}\n"
            "الإجابة:"
        )
        try:
            answer = _call_llm(self.llm, prompt, retries=self.config.llm_retries)
        except LLMCallError as exc:
            logger.error("❌ Direct answer LLM call failed: %s", exc)
            answer = "error in answering directly"

        return RecursiveRAGResult(answer=answer, depth=depth, decomposed=False)

    def _merge(self, query: str, sub_answers: List[SubAnswer]) -> str:
        """Ask the LLM to synthesise sub-answers into a final answer."""
        sub_text = "\n\n".join(
            f"Q{i + 1}: {sa.question}\nA{i + 1}: {sa.answer}"
            for i, sa in enumerate(sub_answers)
        )
        prompt = _MERGE_PROMPT.format(query=query, sub_answers=sub_text)
        try:
            merged = _call_llm(self.llm, prompt, retries=self.config.llm_retries)
            return merged if len(merged) > 10 else "\n\n".join(sa.answer for sa in sub_answers)
        except LLMCallError as exc:
            logger.warning("  Merge LLM call failed: %s – concatenating sub-answers", exc)
            return "\n\n".join(sa.answer for sa in sub_answers)