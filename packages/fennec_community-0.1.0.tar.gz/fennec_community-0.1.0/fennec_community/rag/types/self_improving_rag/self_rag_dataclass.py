from dataclasses import dataclass, field
from typing import Any, Dict, List



@dataclass
class EvaluationResult:
    """
    Structured output of a self-evaluation pass.
    All scores are in [0.0, 1.0].
    """
    relevance: float = 0.5
    accuracy: float = 0.5
    completeness: float = 0.5
    clarity: float = 0.5
    issues: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)

    @property
    def confidence(self) -> float:
        """
        Geometric-mean-inspired confidence.
        A single dimension near 0 tanks the overall score, which is
        more honest than a plain arithmetic mean.
        """
        product = self.relevance * self.accuracy * self.completeness * self.clarity
        return product ** 0.25  # fourth root

    def to_dict(self) -> Dict[str, Any]:
        return {
            "relevance": round(self.relevance, 4),
            "accuracy": round(self.accuracy, 4),
            "completeness": round(self.completeness, 4),
            "clarity": round(self.clarity, 4),
            "confidence": round(self.confidence, 4),
            "issues": self.issues,
            "suggestions": self.suggestions,
        }


@dataclass
class RefinementStep:
    """Record of a single Self-RAG iteration."""
    iteration: int
    answer: str
    evaluation: EvaluationResult

    @property
    def confidence(self) -> float:
        return self.evaluation.confidence


@dataclass
class SelfRAGResult:
    """
    النتيجة النهائية لنظام Self-RAG بعد اكتمال كل دورات التحسين.
    Final result of the Self-RAG system after all refinement iterations.
    """
    answer: str
    confidence: float
    iterations: int
    history: List[RefinementStep]

    # ── Aliases for backward-compatibility with example code ──────────
    @property
    def final_answer(self) -> str:
        """Alias for answer — used in example notebooks."""
        return self.answer

    @property
    def refinement_steps(self) -> int:
        """Number of iterations that actually ran (alias for iterations)."""
        return self.iterations

    @property
    def steps(self) -> List[RefinementStep]:
        """
        Flattened iteration steps with .step, .action, .reason attributes
        compatible with the example print loop.
        """
        result = []
        for s in self.history:
            s.step   = s.iteration
            s.action = "evaluate"
            s.reason = (
                f"confidence={s.confidence:.2f} "
                f"(R={s.evaluation.relevance:.2f} "
                f"A={s.evaluation.accuracy:.2f} "
                f"C={s.evaluation.completeness:.2f} "
                f"Cl={s.evaluation.clarity:.2f})"
            )
            if s.evaluation.suggestions:
                s.reason += f" | suggestions: {'; '.join(s.evaluation.suggestions[:2])}"
            result.append(s)
        return result

    @property
    def initial_quality(self) -> float:
        """درجة جودة الإجابة في أول جولة | Confidence score of the first iteration."""
        return self.history[0].confidence if self.history else 0.0

    @property
    def final_quality(self) -> float:
        """درجة جودة الإجابة في آخر جولة | Confidence score of the last iteration."""
        return self.history[-1].confidence if self.history else 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "answer":          self.answer,
            "confidence":      round(self.confidence, 4),
            "iterations":      self.iterations,
            "initial_quality": round(self.initial_quality, 4),
            "final_quality":   round(self.final_quality, 4),
            "history": [
                {"iteration": s.iteration, "confidence": round(s.confidence, 4)}
                for s in self.history
            ],
        }


@dataclass
class HyDEResult:
    answer: str
    hypothetical_docs: List[str]
    num_retrieved: int
    num_ranked: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "answer": self.answer,
            "hypothetical_docs_generated": len(self.hypothetical_docs),
            "num_retrieved": self.num_retrieved,
            "num_ranked": self.num_ranked,
        }


@dataclass
class SubAnswer:
    question: str
    answer: str
    depth: int


@dataclass
class RecursiveRAGResult:
    answer: str
    depth: int
    decomposed: bool
    sub_questions: List[str] = field(default_factory=list)
    sub_answers: List[SubAnswer] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "answer": self.answer,
            "decomposed": self.decomposed,
            "depth": self.depth,
            "sub_questions": self.sub_questions,
        }