"""
Improved version with async streaming, token-level control, callbacks,
metadata events, and graceful fallback.
"""
from __future__ import annotations
import asyncio
import copy
import logging
import inspect
import queue as stdlib_queue   
import threading
import time
from dataclasses import dataclass
from typing import (
    Any, AsyncIterator, Callable, Dict, Iterator,
    List, Optional)
from .streaming_enum import EventType
from .streaming_config import StreamConfig
from .protocols import SyncStreamableLLM, AsyncStreamableLLM

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StreamEvent:
    """
    Typed event emitted during streaming.
    Consumers can choose to handle metadata events or only text chunks.

    Attributes:
        type    : EventType describing what happened
        data    : payload — a text chunk for CHUNK events, metadata otherwise
        latency : seconds since stream start (set by StreamingRAG)
    """
    type: EventType
    data: Any = None
    latency: float = 0.0

    @property
    def is_chunk(self) -> bool:
        return self.type is EventType.CHUNK

    def __str__(self) -> str:  # convenient for simple iteration
        return self.data if self.is_chunk else ""


# ─────────────────────────────────────────────
# StreamingRAG
# ─────────────────────────────────────────────

class StreamingRAG:
    """
    Streaming RAG System 

    Examples
    --------
    # Simple sync iteration (text only):
    >>> for chunk in rag.stream("What is quantum computing?"):
    ...     print(chunk, end="", flush=True)

    # Rich async iteration (events):
    >>> async for event in rag.astream_events("Explain RAG"):
    ...     if event.is_chunk:
    ...         print(event.data, end="", flush=True)
    ...     elif event.type == EventType.RETRIEVAL_DONE:
    ...         print(f"\\nRetrieved {event.data['num_docs']} docs")

    # With on_chunk callback:
    >>> rag = StreamingRAG(rag_sys, llm, on_chunk=lambda c: save_to_db(c))
    """

    def __init__(
        self,
        rag_system: Any,
        llm: Any = None,
        config: Optional[StreamConfig] = None,
        *,
        # Convenience shortcuts (override config values)
        chunk_size: Optional[int] = None,
        on_chunk: Optional[Callable[[str], None]] = None,
        on_event: Optional[Callable[[StreamEvent], None]] = None,
    ):
        self.rag_system = rag_system
        self.llm = llm or getattr(rag_system, "llm", None)

        # when chunk_size override is applied across multiple StreamingRAG objects
        self.config = copy.copy(config) if config is not None else StreamConfig()
        if chunk_size is not None:
            self.config.chunk_size = chunk_size

        self._on_chunk = on_chunk
        self._on_event = on_event

        # Runtime stats
        self._total_streams: int = 0
        self._total_chunks: int = 0
        self._total_errors: int = 0
        self._total_latency: float = 0.0

    # ── Public sync API ──────────────────────

    def stream(self, query: str, context: Optional[Dict] = None) -> Iterator[str]:
        """
        Sync generator — yields plain text chunks.
        Metadata events are silently consumed (callbacks still fire).
        """
        for event in self.stream_events(query, context):
            if event.is_chunk:
                yield event.data

    def stream_events(
        self, query: str, context: Optional[Dict] = None
    ) -> Iterator[StreamEvent]:
        """
        Sync generator — yields StreamEvent objects.
        Bridges the async implementation for synchronous callers.

        """
        # stdlib queue.Queue is thread-safe by design
        sync_q: stdlib_queue.Queue[Optional[StreamEvent]] = stdlib_queue.Queue()

        def _run_loop():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                async def _producer():
                    try:
                        async for ev in self.astream_events(query, context):
                            sync_q.put(ev)
                    finally:
                        sync_q.put(None)  # sentinel — always sent even on error

                loop.run_until_complete(_producer())
            finally:
                loop.close()

        t = threading.Thread(target=_run_loop, daemon=True)
        t.start()

        # Main thread: blocking get() — no polling, no busy-wait, no race
        while True:
            ev = sync_q.get()   # blocks until item available
            if ev is None:
                break
            yield ev

        t.join()

    def _sync_get(self, queue: Any) -> Optional[StreamEvent]:
        """
        Removed: this helper was only needed by the broken asyncio.Queue
        polling loop. With stdlib queue.Queue the main loop uses queue.get()
        directly (blocking, thread-safe). Kept as a no-op stub for any
        subclass that may override it.
        """
        raise NotImplementedError(
            "_sync_get is deprecated; use stdlib queue.Queue.get() directly"
        )

    def query(self, query: str, context: Optional[Dict] = None) -> Dict[str, Any]:
        """Non-streaming convenience method — collects the full answer."""
        chunks: List[str] = []
        events: List[StreamEvent] = []
        for event in self.stream_events(query, context):
            events.append(event)
            if event.is_chunk:
                chunks.append(event.data)
        return {
            "answer": "".join(chunks),
            "events": events,
        }

    # ── Async API ────────────────────────────

    async def astream(
        self, query: str, context: Optional[Dict] = None
    ) -> AsyncIterator[str]:
        """Async generator — yields plain text chunks."""
        async for event in self.astream_events(query, context):
            if event.is_chunk:
                yield event.data

    async def astream_events(
        self, query: str, context: Optional[Dict] = None
    ) -> AsyncIterator[StreamEvent]:
        """
        Async generator — yields StreamEvent objects.
        This is the core implementation; all other methods delegate here.
        """
        start = time.monotonic()
        self._total_streams += 1

        def _elapsed() -> float:
            return round(time.monotonic() - start, 4)

        def _event(etype: EventType, data: Any = None) -> StreamEvent:
            ev = StreamEvent(type=etype, data=data, latency=_elapsed())
            if self._on_event:
                self._on_event(ev)
            return ev

        # ── Step 1: Retrieval ────────────────
        yield _event(EventType.RETRIEVAL_START, {"query": query})

        try:
            docs = await asyncio.wait_for(
                self._retrieve(query), timeout=self.config.retrieval_timeout
            )
        except asyncio.TimeoutError:
            self._total_errors += 1
            yield _event(EventType.ERROR, {"msg": "Retrieval timed out", "stage": "retrieval"})
            return
        except Exception as exc:
            self._total_errors += 1
            logger.error("❌ Retrieval error: %s", exc)
            yield _event(EventType.ERROR, {"msg": str(exc), "stage": "retrieval"})
            return

        yield _event(EventType.RETRIEVAL_DONE, {"num_docs": len(docs), "docs": docs})

        # ── Step 2: Build prompt ─────────────
        context_text = self._build_context(docs)
        prompt = self.config.prompt_template.format(
            context=context_text, query=query
        )

        # ── Step 3: Generation ───────────────
        yield _event(EventType.GENERATION_START, {"prompt_chars": len(prompt)})

        # ✅ FIX: asyncio.wait_for() cannot wrap an async generator — it only
        #         accepts coroutines/futures.  Calling it on self._generate()
        #         raises TypeError at runtime.  The fix: iterate the generator
        #         manually via __anext__(), applying a sliding deadline so the
        #         total generation time is still bounded.
        gen = self._generate(prompt, query, context, docs)
        deadline = time.monotonic() + self.config.generation_timeout
        try:
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise asyncio.TimeoutError()
                try:
                    chunk = await asyncio.wait_for(
                        gen.__anext__(), timeout=remaining
                    )
                except StopAsyncIteration:
                    break
                self._total_chunks += 1
                if self._on_chunk:
                    self._on_chunk(chunk)
                yield _event(EventType.CHUNK, chunk)

        except asyncio.TimeoutError:
            self._total_errors += 1
            yield _event(EventType.ERROR, {"msg": "Generation timed out", "stage": "generation"})
            return
        except Exception as exc:
            self._total_errors += 1
            logger.error("❌ Generation error: %s", exc)
            yield _event(EventType.ERROR, {"msg": str(exc), "stage": "generation"})
            return
        finally:
            # ✅ FIX: always close the generator to free resources (e.g. open
            #         HTTP connections inside the LLM client)
            await gen.aclose()

        self._total_latency += _elapsed()
        yield _event(EventType.GENERATION_DONE, {"total_latency": _elapsed()})

    # ── Internal helpers ─────────────────────

    async def _retrieve(self, query: str) -> List[Dict]:
        """Call rag_system.retrieve (sync or async) and normalise output."""
        retrieve_fn = getattr(self.rag_system, "retrieve", None)
        if retrieve_fn is None:
            return []

        if inspect.iscoroutinefunction(retrieve_fn):
            raw = await retrieve_fn(query)
        else:
            # ✅ FIX: get_running_loop() is correct inside an async function;
            #         get_event_loop() is deprecated in 3.10+ and emits warnings
            loop = asyncio.get_running_loop()
            raw = await loop.run_in_executor(None, retrieve_fn, query)

        if isinstance(raw, dict):
            raw = raw.get("results", [])
        elif not isinstance(raw, list):
            return []

        return [self._normalise_doc(d) for d in raw]

    @staticmethod
    def _normalise_doc(doc: Any) -> Dict:
        """
        Convert any retriever output shape into a plain dict so that
        _build_context can always call .get() safely.

        Supported input shapes
        ─────────────────────
        dict                       → returned as-is
        tuple (text,)              → {"text": text}
        tuple (text, score)        → {"text": text, "score": score}
        tuple (text, score, meta)  → {"text": text, "score": score, **meta}
                                     where meta can be a dict or any str-able value
        anything else              → {"text": str(doc)}
        """
        if isinstance(doc, dict):
            return doc
        if isinstance(doc, tuple):
            text   = str(doc[0]) if len(doc) > 0 else ""
            score  = doc[1]      if len(doc) > 1 else None
            meta   = doc[2]      if len(doc) > 2 else {}
            result: Dict = {"text": text}
            if score is not None:
                result["score"] = score
            if isinstance(meta, dict):
                result.update(meta)
            elif meta:
                result["meta"] = str(meta)
            return result
        return {"text": str(doc)}

    def _build_context(self, docs: List[Dict]) -> str:
        """Truncate and join documents into a context string."""
        limit = self.config.max_context_docs
        char_limit = self.config.max_doc_chars
        parts = []
        for i, doc in enumerate(docs[:limit], 1):
            # _normalise_doc guarantees doc is a dict; this is a safety net
            # for any doc that bypassed _retrieve normalisation
            if not isinstance(doc, dict):
                doc = self._normalise_doc(doc)
            text   = (doc.get("text") or doc.get("content") or str(doc))[:char_limit]
            source = doc.get("source") or doc.get("id") or f"doc-{i}"
            parts.append(f"[{source}]\n{text}")
        return "\n\n".join(parts)

    async def _generate(
        self,
        prompt: str,
        query: str,
        context: Optional[Dict],
        docs: List[Dict],
    ) -> AsyncIterator[str]:
        """
        Route to the best available generation strategy:
            1. async LLM.astream()
            2. sync  LLM.stream()
            3. rag_system.generate() + word-level simulation
        """
        # ── Strategy 1: native async stream ──
        if self.llm and isinstance(self.llm, AsyncStreamableLLM):
            async for chunk in self.llm.astream(prompt):
                yield chunk
            return

        # ── Strategy 2: sync stream wrapped in executor ──
        if self.llm and isinstance(self.llm, SyncStreamableLLM):
            # ✅ FIX: get_running_loop() instead of deprecated get_event_loop()
            loop = asyncio.get_running_loop()
            chunk_queue: asyncio.Queue[Optional[str]] = asyncio.Queue()
            error_holder: List[BaseException] = []  # ✅ FIX: capture worker errors

            def _sync_worker():
                try:
                    for c in self.llm.stream(prompt):
                        asyncio.run_coroutine_threadsafe(chunk_queue.put(c), loop)
                except Exception as exc:
                    # ✅ FIX: old code put None in both except AND finally, sending
                    #         two sentinels. Now the error is captured so the async
                    #         side can re-raise it instead of silently stopping.
                    error_holder.append(exc)
                finally:
                    # single sentinel — always sent exactly once
                    asyncio.run_coroutine_threadsafe(chunk_queue.put(None), loop)

            threading.Thread(target=_sync_worker, daemon=True).start()

            while True:
                chunk = await chunk_queue.get()
                if chunk is None:
                    break
                yield chunk

            # ✅ FIX: re-raise any worker exception so the caller's error
            #         handler sees it (old code silently swallowed it)
            if error_holder:
                raise error_holder[0]
            return

        # ── Strategy 3: simulation via rag_system.generate() ──
        logger.debug("No streaming LLM found — simulating with word chunks")

        # ✅ FIX: check that `generate` actually exists before calling it;
        #         old code raised a bare AttributeError with no helpful context
        generate_fn = getattr(self.rag_system, "generate", None)
        if generate_fn is None:
            raise AttributeError(
                "StreamingRAG fallback (Strategy 3) requires rag_system.generate(), "
                "but the method was not found. Provide an LLM that implements "
                "SyncStreamableLLM or AsyncStreamableLLM instead."
            )

        # ✅ FIX: get_running_loop() instead of deprecated get_event_loop()
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            generate_fn,
            query,
            {**(context or {}), "retrieved_docs": docs},
        )
        answer = (
            result.get("answer", str(result))
            if isinstance(result, dict)
            else str(result)
        ).strip()

        words = answer.split()
        size = self.config.chunk_size
        for i in range(0, len(words), size):
            chunk = " ".join(words[i : i + size])
            yield chunk + " "
            await asyncio.sleep(self.config.sim_delay)

    # ── Stats & repr ─────────────────────────

    @property
    def stats(self) -> Dict[str, Any]:
        avg = self._total_latency / max(self._total_streams, 1)
        return {
            "total_streams": self._total_streams,
            "total_chunks": self._total_chunks,
            "total_errors": self._total_errors,
            "avg_stream_latency_s": round(avg, 3),
        }

    def __repr__(self) -> str:
        has_llm = self.llm is not None
        async_cap = has_llm and isinstance(self.llm, AsyncStreamableLLM)
        return (
            f"StreamingRAG("
            f"llm={'async' if async_cap else 'sync' if has_llm else 'sim'}, "
            f"chunk_size={self.config.chunk_size})"
        )