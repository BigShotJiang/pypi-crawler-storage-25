# -*- coding: utf-8 -*-
"""
Fennec RAG — Unified Exception Hierarchy
All library exceptions inherit from FennecError so callers can catch either
the specific subclass or the general base class.
"""

from __future__ import annotations
from typing import Optional, Any


# ══════════════════════════════════════════════════════════════════════════════
# Base
# ══════════════════════════════════════════════════════════════════════════════

class FennecError(Exception):
    """
    Base class for all Fennec exceptions.

    Attributes:
        message:  Human-readable description  
        details:  Optional extra context      
        code:     Optional machine-readable code
    """

    def __init__(
        self,
        message: str,
        details: Optional[Any] = None,
        code: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.details = details
        self.code = code

    def __str__(self) -> str:
        parts = [self.message]
        if self.details:
            parts.append(f"details={self.details}")
        if self.code:
            parts.append(f"code={self.code}")
        return " | ".join(parts)

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.message!r})"


# ══════════════════════════════════════════════════════════════════════════════
# Configuration
# ══════════════════════════════════════════════════════════════════════════════

class ConfigurationError(FennecError):
    """Raised when library configuration is invalid.
   """


class MissingAPIKeyError(ConfigurationError):
    """Raised when a required API key is absent.
   """

    def __init__(self, provider: str) -> None:
        super().__init__(
            f"API key is missing for provider '{provider}'.",
            code="MISSING_API_KEY",
        )
        self.provider = provider


class InvalidConfigValueError(ConfigurationError):
    """Raised when a config value is out of range or has a wrong type.
   """

    def __init__(self, field: str, value: Any, reason: str) -> None:
        super().__init__(
            f"Invalid value for '{field}': {value!r} — {reason}",
            code="INVALID_CONFIG",
        )
        self.field = field
        self.value = value


# ══════════════════════════════════════════════════════════════════════════════
# Document & Chunking
# ══════════════════════════════════════════════════════════════════════════════

class DocumentError(FennecError):
    """Base for document-related errors."""


class EmptyDocumentError(DocumentError):
    """Raised when a document has no usable text content.
   """

    def __init__(self, doc_id: str) -> None:
        super().__init__(
            f"Document '{doc_id}' is empty or contains no usable text.",
            code="EMPTY_DOCUMENT",
        )
        self.doc_id = doc_id


class DocumentNotFoundError(DocumentError):
    """Raised when a requested document ID does not exist.
   """

    def __init__(self, doc_id: str) -> None:
        super().__init__(
            f"Document '{doc_id}' was not found in the system.",
            code="DOCUMENT_NOT_FOUND",
        )
        self.doc_id = doc_id


class ChunkingError(DocumentError):
    """Raised when text splitting / chunking fails.
   """

    def __init__(self, doc_id: str, reason: str) -> None:
        super().__init__(
            f"Failed to chunk document '{doc_id}': {reason}",
            code="CHUNKING_FAILED",
        )
        self.doc_id = doc_id


# ══════════════════════════════════════════════════════════════════════════════
# Vector Database
# ══════════════════════════════════════════════════════════════════════════════

class VectorDatabaseError(FennecError):
    """Base for vector-database errors. """


class VectorDBConnectionError(VectorDatabaseError):
    """Raised when the vector DB cannot be reached.
   """

    def __init__(self, db_type: str, reason: str) -> None:
        super().__init__(
            f"Cannot connect to vector database '{db_type}': {reason}",
            code="VDB_CONNECTION_FAILED",
        )
        self.db_type = db_type


class VectorDBWriteError(VectorDatabaseError):
    """Raised when adding vectors to the DB fails.
   """


class VectorDBSearchError(VectorDatabaseError):
    """Raised when a similarity search fails.
   """


class VectorDBPersistenceError(VectorDatabaseError):
    """Raised when saving or loading the vector DB fails.
   """

    def __init__(self, operation: str, path: str, reason: str) -> None:
        super().__init__(
            f"Vector DB {operation} failed at '{path}': {reason}",
            code="VDB_PERSISTENCE_FAILED",
        )
        self.operation = operation
        self.path = path


# ══════════════════════════════════════════════════════════════════════════════
# Embedding
# ══════════════════════════════════════════════════════════════════════════════

class EmbeddingError(FennecError):
    """Base for embedding errors. """


class EmbeddingModelNotFoundError(EmbeddingError):
    """Raised when the requested embedding model is unavailable.
   """

    def __init__(self, model_name: str) -> None:
        super().__init__(
            f"Embedding model '{model_name}' is not available or not installed.",
            code="EMBEDDING_MODEL_NOT_FOUND",
        )
        self.model_name = model_name


class EmbeddingDimensionMismatchError(EmbeddingError):
    """Raised when stored and query vector dimensions do not match.
   """

    def __init__(self, expected: int, got: int) -> None:
        super().__init__(
            f"Embedding dimension mismatch: expected {expected}, got {got}.",
            code="EMBEDDING_DIM_MISMATCH",
        )
        self.expected = expected
        self.got = got


class EmbeddingAPIError(EmbeddingError):
    """Raised when the embedding API call fails.
   """

    def __init__(self, provider: str, reason: str) -> None:
        super().__init__(
            f"Embedding API error from '{provider}': {reason}",
            code="EMBEDDING_API_FAILED",
        )
        self.provider = provider


# ══════════════════════════════════════════════════════════════════════════════
# LLM
# ══════════════════════════════════════════════════════════════════════════════

class LLMError(FennecError):
    """Base for LLM interface errors. """


class LLMConnectionError(LLMError):
    """Raised when the LLM API cannot be reached.
   """

    def __init__(self, provider: str, reason: str) -> None:
        super().__init__(
            f"Cannot reach LLM provider '{provider}': {reason}",
            code="LLM_CONNECTION_FAILED",
        )
        self.provider = provider


class LLMGenerationError(LLMError):
    """Raised when text generation fails.
   """

    def __init__(self, provider: str, reason: str) -> None:
        super().__init__(
            f"LLM generation failed for provider '{provider}': {reason}",
            code="LLM_GENERATION_FAILED",
        )
        self.provider = provider


class LLMTimeoutError(LLMError):
    """Raised when an LLM request times out.
    """

    def __init__(self, provider: str, timeout_seconds: float) -> None:
        super().__init__(
            f"LLM request to '{provider}' timed out after {timeout_seconds}s.",
            code="LLM_TIMEOUT",
        )
        self.provider = provider
        self.timeout_seconds = timeout_seconds


class LLMRateLimitError(LLMError):
    """Raised when the LLM API rate limit is exceeded.
   """

    def __init__(self, provider: str) -> None:
        super().__init__(
            f"Rate limit exceeded for provider '{provider}'. Please retry later.",
            code="LLM_RATE_LIMIT",
        )
        self.provider = provider


# ══════════════════════════════════════════════════════════════════════════════
# RAG System
# ══════════════════════════════════════════════════════════════════════════════

class RAGError(FennecError):
    """Base for RAG pipeline errors. """


class RAGInitializationError(RAGError):
    """Raised when the RAG system cannot be initialized.
   """

    def __init__(self, reason: str) -> None:
        super().__init__(
            f"RAG system initialization failed: {reason}",
            code="RAG_INIT_FAILED",
        )


class RAGRetrievalError(RAGError):
    """Raised when the retrieval step fails entirely.
   """

    def __init__(self, query: str, reason: str) -> None:
        super().__init__(
            f"Retrieval failed for query '{query[:60]}...': {reason}",
            code="RAG_RETRIEVAL_FAILED",
        )
        self.query = query


class RAGGenerationError(RAGError):
    """Raised when the generation step fails.
   """

    def __init__(self, reason: str) -> None:
        super().__init__(
            f"Answer generation failed: {reason}",
            code="RAG_GENERATION_FAILED",
        )


class NoRelevantDocumentsError(RAGError):
    """
    Raised when retrieval returns zero relevant chunks.
    This is a *soft* error — callers may handle it gracefully by returning
    a friendly 'no info found' message rather than crashing.
    """

    def __init__(self, query: str) -> None:
        super().__init__(
            f"No relevant documents found for query: '{query[:80]}'",
            code="NO_RELEVANT_DOCS",
        )
        self.query = query


class QueryExpansionError(RAGError):
    """Raised when LLM-based query expansion fails.
   """

    def __init__(self, reason: str) -> None:
        super().__init__(
            f"Query expansion failed: {reason}",
            code="QUERY_EXPANSION_FAILED",
        )


# ══════════════════════════════════════════════════════════════════════════════
# Prompt
# ══════════════════════════════════════════════════════════════════════════════

class PromptError(FennecError):
    """Base for prompt-template errors."""


class PromptFormattingError(PromptError):
    """Raised when a prompt template cannot be formatted.
   """

    def __init__(self, template_name: str, missing_vars: list) -> None:
        super().__init__(
            f"Prompt template '{template_name}' is missing variables: {missing_vars}",
            code="PROMPT_FORMATTING_FAILED",
        )
        self.template_name = template_name
        self.missing_vars = missing_vars


# ══════════════════════════════════════════════════════════════════════════════
# Cache
# ══════════════════════════════════════════════════════════════════════════════

class CacheError(FennecError):
    """Base for cache errors. """


class CacheReadError(CacheError):
    """Raised when reading from cache fails. """


class CacheWriteError(CacheError):
    """Raised when writing to cache fails. """


# ══════════════════════════════════════════════════════════════════════════════
# Loader
# ══════════════════════════════════════════════════════════════════════════════

class LoaderError(FennecError):
    """Base for document loader errors. """


class UnsupportedFileTypeError(LoaderError):
    """Raised when no loader supports the given file extension.
   """

    def __init__(self, extension: str) -> None:
        super().__init__(
            f"No loader found for file type '{extension}'.",
            code="UNSUPPORTED_FILE_TYPE",
        )
        self.extension = extension


class FileReadError(LoaderError):
    """Raised when a file cannot be read."""

    def __init__(self, filepath: str, reason: str) -> None:
        super().__init__(
            f"Cannot read file '{filepath}': {reason}",
            code="FILE_READ_FAILED",
        )
        self.filepath = filepath


# ══════════════════════════════════════════════════════════════════════════════
# __all__
# ══════════════════════════════════════════════════════════════════════════════

__all__ = [
    # Base
    "FennecError",
    # Configuration
    "ConfigurationError",
    "MissingAPIKeyError",
    "InvalidConfigValueError",
    # Document
    "DocumentError",
    "EmptyDocumentError",
    "DocumentNotFoundError",
    "ChunkingError",
    # Vector DB
    "VectorDatabaseError",
    "VectorDBConnectionError",
    "VectorDBWriteError",
    "VectorDBSearchError",
    "VectorDBPersistenceError",
    # Embedding
    "EmbeddingError",
    "EmbeddingModelNotFoundError",
    "EmbeddingDimensionMismatchError",
    "EmbeddingAPIError",
    # LLM
    "LLMError",
    "LLMConnectionError",
    "LLMGenerationError",
    "LLMTimeoutError",
    "LLMRateLimitError",
    # RAG
    "RAGError",
    "RAGInitializationError",
    "RAGRetrievalError",
    "RAGGenerationError",
    "NoRelevantDocumentsError",
    "QueryExpansionError",
    # Prompt
    "PromptError",
    "PromptFormattingError",
    # Cache
    "CacheError",
    "CacheReadError",
    "CacheWriteError",
    # Loader
    "LoaderError",
    "UnsupportedFileTypeError",
    "FileReadError",
]