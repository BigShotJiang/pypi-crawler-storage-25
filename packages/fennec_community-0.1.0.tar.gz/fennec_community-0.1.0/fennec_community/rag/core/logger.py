# -*- coding: utf-8 -*-
"""
Fennec RAG — Centralized Logging System

Usage / الاستخدام:
    logger = get_logger(__name__)
    logger.info("component started")
    logger.debug("retrieved %d chunks", n)

One-time global setup (optional, call once at app startup):
    from fennec.logger import setup_logging
    setup_logging(level="DEBUG", log_file="fennec.log", json_format=False)
"""

from __future__ import annotations

import logging
import logging.handlers
import os
import sys
import time
from pathlib import Path
from typing import Optional

# ── Public API ────────────────────────────────────────────────────────────────
__all__ = ["get_logger", "setup_logging", "FennecLogger"]

# Library root logger name — all child loggers are children of this one.
_ROOT_NAME = "fennec"

# Sentinel: has setup_logging() already been called?
_CONFIGURED = False


# ══════════════════════════════════════════════════════════════════════════════
# Formatters
# ══════════════════════════════════════════════════════════════════════════════

class _PrettyFormatter(logging.Formatter):
    """
    Coloured, human-readable formatter for console output.
    Format: [TIME] LEVEL  [module]  message  {details}
    """

    _LEVEL_ICONS = {
        logging.DEBUG:    "🔍",
        logging.INFO:     "ℹ️ ",
        logging.WARNING:  "⚠️ ",
        logging.ERROR:    "❌",
        logging.CRITICAL: "🔥",
    }

    _COLOURS = {
        logging.DEBUG:    "\033[36m",    # cyan
        logging.INFO:     "\033[32m",    # green
        logging.WARNING:  "\033[33m",    # yellow
        logging.ERROR:    "\033[31m",    # red
        logging.CRITICAL: "\033[1;31m",  # bold red
    }
    _RESET = "\033[0m"
    _DIM   = "\033[2m"
    _BOLD  = "\033[1m"

    def __init__(self, use_colour: bool = True) -> None:
        super().__init__()
        self._use_colour = use_colour and _supports_colour()

    def format(self, record: logging.LogRecord) -> str:
        icon   = self._LEVEL_ICONS.get(record.levelno, "  ")
        colour = self._COLOURS.get(record.levelno, "") if self._use_colour else ""
        reset  = self._RESET if self._use_colour else ""
        dim    = self._DIM   if self._use_colour else ""
        bold   = self._BOLD  if self._use_colour else ""

        # Timestamp
        ts = time.strftime("%H:%M:%S", time.localtime(record.created))
        ms = int(record.msecs)

        # Module — strip the "fennec." prefix for brevity
        module = record.name
        if module.startswith(_ROOT_NAME + "."):
            module = module[len(_ROOT_NAME) + 1:]

        # Base line
        line = (
            f"{dim}[{ts}.{ms:03d}]{reset} "
            f"{colour}{icon} {bold}{record.levelname:<8}{reset} "
            f"{dim}[{module}]{reset}  "
            f"{record.getMessage()}"
        )

        # Append exception info if present
        if record.exc_info:
            line += "\n" + self.formatException(record.exc_info)

        return line


class _PlainFormatter(logging.Formatter):
    """Plain formatter for file output (no ANSI codes)."""

    FMT = "%(asctime)s  %(levelname)-8s  [%(name)s]  %(message)s"
    DATE = "%Y-%m-%d %H:%M:%S"

    def __init__(self) -> None:
        super().__init__(fmt=self.FMT, datefmt=self.DATE)


class _JSONFormatter(logging.Formatter):
    """
    JSON-lines formatter — one JSON object per log line.
    Useful for structured log aggregators (Datadog, ELK, etc.).
    """

    def format(self, record: logging.LogRecord) -> str:
        import json

        payload: dict = {
            "ts":      self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level":   record.levelname,
            "logger":  record.name,
            "msg":     record.getMessage(),
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        if hasattr(record, "extra"):
            payload.update(record.extra)

        return json.dumps(payload, ensure_ascii=False)


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _supports_colour() -> bool:
    """Return True when the terminal likely supports ANSI colour codes."""
    if os.environ.get("NO_COLOR") or os.environ.get("FENNEC_NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty"):
        return False
    return sys.stdout.isatty()


def _make_console_handler(level: int, use_colour: bool) -> logging.StreamHandler:
    h = logging.StreamHandler(sys.stdout)
    h.setLevel(level)
    h.setFormatter(_PrettyFormatter(use_colour=use_colour))
    return h


def _make_file_handler(
    log_file: str,
    level: int,
    json_format: bool,
    max_bytes: int,
    backup_count: int,
) -> logging.handlers.RotatingFileHandler:
    Path(log_file).parent.mkdir(parents=True, exist_ok=True)
    h = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    h.setLevel(level)
    h.setFormatter(_JSONFormatter() if json_format else _PlainFormatter())
    return h


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def setup_logging(
    level: str = "INFO",
    log_file: Optional[str] = None,
    json_format: bool = False,
    use_colour: bool = True,
    max_bytes: int = 10 * 1024 * 1024,   # 10 MB
    backup_count: int = 3,
    propagate: bool = False,
) -> None:
    """
    Configure the library-wide logger **once** at application startup.

    Args:
        level:        Logging level: "DEBUG" | "INFO" | "WARNING" | "ERROR"
        log_file:     Optional path for rotating file output
        json_format:  Use JSON-lines format in the file (ignored for console)
        use_colour:   Enable ANSI colours on the console
        max_bytes:    Max size per log file before rotation
        backup_count: Number of rotated files to keep
        propagate:    Whether to propagate to the root Python logger

    Example:
        from fennec.logger import setup_logging
        setup_logging(level="DEBUG", log_file="logs/fennec.log")
    """
    global _CONFIGURED

    numeric_level = getattr(logging, level.upper(), logging.INFO)
    root = logging.getLogger(_ROOT_NAME)

    # Clear any handlers added by previous calls / third-party code
    root.handlers.clear()
    root.setLevel(numeric_level)
    root.propagate = propagate

    # Console handler
    root.addHandler(_make_console_handler(numeric_level, use_colour))

    # Optional file handler
    if log_file:
        root.addHandler(
            _make_file_handler(log_file, numeric_level, json_format, max_bytes, backup_count)
        )

    _CONFIGURED = True
    root.debug("Fennec logging configured | level=%s | file=%s | json=%s",
                level.upper(), log_file or "none", json_format)


def get_logger(name: str) -> logging.Logger:
    """
    Return a child logger for *name*, ensuring the library root is initialised.
    If ``setup_logging`` has not been called yet the library falls back to a
    minimal console handler so log messages are never silently dropped.

    Args:
        name: Typically ``__name__`` of the calling module.

    Returns:
        logging.Logger bound under the "fennec" hierarchy.

    Example:
        logger = get_logger(__name__)
        logger.info("RAG system initialised with %d docs", n)
    """
    global _CONFIGURED

    if not _CONFIGURED:
        # Lazy bootstrap — INFO level, console only, no colour detection yet
        root = logging.getLogger(_ROOT_NAME)
        if not root.handlers:
            root.setLevel(logging.INFO)
            root.addHandler(_make_console_handler(logging.INFO, use_colour=True))
        _CONFIGURED = True

    # Ensure the child logger name is always under the "fennec" hierarchy
    if name == _ROOT_NAME or name.startswith(_ROOT_NAME + "."):
        full_name = name
    else:
        full_name = f"{_ROOT_NAME}.{name}"

    return logging.getLogger(full_name)


# ══════════════════════════════════════════════════════════════════════════════
# Convenience wrapper (optional — lets callers do FennecLogger.info(...))
# ══════════════════════════════════════════════════════════════════════════════

class FennecLogger:
    """
    Thin static wrapper around ``get_logger`` for users who prefer a
    class-based API.

    Example:
        FennecLogger.setup(level="DEBUG")
        log = FennecLogger.get("mymodule")
        log.info("hello")
    """

    @staticmethod
    def setup(**kwargs) -> None:
        """Alias for :func:`setup_logging`."""
        setup_logging(**kwargs)

    @staticmethod
    def get(name: str) -> logging.Logger:
        """Alias for :func:`get_logger`."""
        return get_logger(name)