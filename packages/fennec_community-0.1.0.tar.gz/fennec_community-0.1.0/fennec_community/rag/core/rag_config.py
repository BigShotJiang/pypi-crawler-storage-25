from dataclasses import dataclass
from typing import Optional , Dict


@dataclass
class RAGConfig:
    """
    RAG System Configuration
    """
    # ── Chunking ─────────────────────────────────────────────────────────────
    chunk_size: int = 512              # حجم القطعة النصية | Chunk size
    overlap: int = 128                 # التداخل بين القطع | Overlap between chunks

    # ── Retrieval ─────────────────────────────────────────────────────────────
    top_k: int = 5                     # عدد النتائج المسترجعة | Number of retrieved results
    min_score: float = 0.0             # الحد الأدنى للدرجة | Minimum score threshold

    # ── Reranking ─────────────────────────────────────────────────────────────
    enable_reranking: bool = False         # تفعيل إعادة الترتيب | Enable reranking
    rerank_mode: str = "heuristic"         # "heuristic" | "llm" | "hybrid"
    rerank_top_k: Optional[int] = None     # عدد النتائج بعد إعادة الترتيب (None = نفس top_k)
                                           # Results after reranking (None = same as top_k)
    rerank_original_weight: float = 0.40   # وزن الدرجة الأصلية | Original score weight
    rerank_llm_weight:      float = 0.40   # وزن درجة LLM | LLM score weight
    rerank_diversity_weight: float = 0.10  # وزن التنوع | Diversity weight
    rerank_length_weight:    float = 0.10  # وزن الطول | Length weight

    # ── Prompt Router ─────────────────────────────────────────────────────────
    enable_prompt_routing: bool = True     # تفعيل توجيه الـ prompt | Enable prompt routing
    prompt_language: Optional[str] = None  # None = كشف تلقائي | None = auto-detect
    include_few_shot: bool = True          # تضمين أمثلة few-shot | Include few-shot examples

    # ── Context ───────────────────────────────────────────────────────────────
    context_max_length: int = 4000         # الطول الأقصى للسياق | Maximum context length

    # ── Retrieval Cache ───────────────────────────────────────────────────────
    enable_retrieval_cache: bool = True    # تفعيل كاش نتائج الاسترجاع | Enable retrieval cache
    cache_maxsize: int = 256               # الحد الأقصى لعدد الاستعلامات المخزنة | Max cached queries
    cache_ttl: float = 300.0               # مدة صلاحية الكاش بالثواني | Cache TTL in seconds

    # ── Batch ingestion ───────────────────────────────────────────────────────
    ingest_batch_size: int = 64            # حجم دفعة الإضافة | Ingestion batch size

    def validate(self):
        """
        Validate configuration settings
        """
        if self.chunk_size <= 0:
            raise ValueError("❌ chunk_size must be positive")
        if self.overlap < 0:
            raise ValueError("❌ overlap cannot be negative")
        if self.top_k <= 0:
            raise ValueError("❌top_k must be positive")
        if self.overlap >= self.chunk_size:
            raise ValueError("❌ overlap must be smaller than chunk_size")
        if self.rerank_mode not in ("heuristic", "llm", "hybrid"):
            raise ValueError("❌ rerank_mode must be 'heuristic' or 'llm' or 'hybrid'")
        weights = self.rerank_original_weight + self.rerank_llm_weight + self.rerank_diversity_weight + self.rerank_length_weight
        if not (0.99 <= weights <= 1.01):
            raise ValueError(f"❌ Rerank weights must sum to 1.0 (got {weights:.2f})")
        

from enum import Enum
class RerankMode(Enum):
    """
    Available reranking modes
    """
    HEURISTIC = "heuristic"   # سريع بلا LLM  / fast, no LLM
    LLM       = "llm"         # دقيق مع LLM   / accurate, uses LLM
    HYBRID    = "hybrid"      # مزيج من الاثنين / combination


@dataclass
class RerankerConfig:
    """
    Reranker configuration
    Weights must sum to 1.0

    Note: In heuristic mode, llm_score_weight is automatically merged with
    original_score_weight via _effective_weights(); no manual adjustment needed.
    """
    mode: RerankMode = RerankMode.HEURISTIC

    # عدد النتائج بعد الترتيب (None = نفس top_k الواردة)
    # Results after reranking (None = same as input top_k)
    top_k: Optional[int] = None

    # ── أوزان الدرجة المركّبة | Composite score weights ─────────────────────
    original_score_weight: float = 0.40   # الدرجة الأصلية من قاعدة البيانات
    llm_score_weight:      float = 0.40   # درجة LLM
    diversity_weight:      float = 0.10   # مكافأة التنوع
    length_weight:         float = 0.10   # مكافأة الطول الأمثل

    # ── إعدادات اللغة لتقييم LLM | Language settings for LLM eval ──────────
    llm_eval_language: str = "ar"         # 'ar' | 'en'

    # ── حدود الطول الأمثل (بالكلمات) | Optimal length bounds (words) ────────
    ideal_min_words: int = 30
    ideal_max_words: int = 300

    # ── إعدادات فلترة النصوص المكررة | Near-duplicate filter settings ────────
    # 🟢 [جديد] تفعيل/تعطيل فلترة النصوص المتشابهة
    dedup_enabled:   bool  = True
    dedup_threshold: float = 0.85   # نسبة Jaccard فوقها تُعدّ القطعة مكررة

    def __post_init__(self) -> None:
        total = (
            self.original_score_weight
            + self.llm_score_weight
            + self.diversity_weight
            + self.length_weight
        )
        if not (0.99 <= total <= 1.01):
            raise ValueError(
                f"❌ Weights must sum to 1.0 (got {total:.3f})"
            )

    def effective_weights(self, mode: RerankMode) -> Dict[str, float]:
        """
        Returns mode-adjusted normalized weights.
        In heuristic mode there is no LLM, so its weight is folded into orig.
        """
        if mode == RerankMode.HEURISTIC:
            merged_orig = self.original_score_weight + self.llm_score_weight
            return {
                "orig": merged_orig,
                "llm":  0.0,
                "len":  self.length_weight,
                "div":  self.diversity_weight,
            }
        # LLM / HYBRID — استخدام الأوزان كما هي
        return {
            "orig": self.original_score_weight,
            "llm":  self.llm_score_weight,
            "len":  self.length_weight,
            "div":  self.diversity_weight,
        }
