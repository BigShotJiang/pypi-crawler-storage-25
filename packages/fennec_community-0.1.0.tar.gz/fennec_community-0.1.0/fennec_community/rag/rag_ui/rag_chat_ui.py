from __future__ import annotations
import json
import logging
import os
import tempfile
import threading
import time
import uuid
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, List, Optional

from .enum import constants
from .adapter import RAGAdapter
from .file_process import FileProcessor
from .session_store import SessionStore
from .dataclass import ChatSession
from .templet import _build_html, _print_banner

logger = logging.getLogger(__name__)


class RagChatUI:
    """
    يُحوّل أي RAGPipeline أو RAGSystem إلى واجهة محادثة احترافية.
    Converts any RAGPipeline / RAGSystem into a professional chat UI.

    Args:
        rag                : RAGPipeline أو RAGSystem
        title              : عنوان الواجهة
        description        : وصف في الشاشة الترحيبية
        theme              : "dark" | "light"
        max_sessions       : أقصى عدد جلسات في الذاكرة (افتراضي: 30)
        include_sources    : إظهار مصادر الإجابة (افتراضي: True)
        language           : "ar" | "en" | None
        allowed_extensions : امتدادات الملفات المسموح برفعها
        on_upload          : معالج رفع مخصص — fn(path, doc_id) -> str
        persist_path       : مسار ملف JSON لحفظ الجلسات دائمًا (اختياري)

    Example:
        >>> ui = RagChatUI(pipeline, title="مساعدي", theme="dark")
        >>> ui.launch(port=7860)
    """

    def __init__(
        self,
        rag: Any,
        title: str = "RAG Chat",
        description: str = "you can ask about anything in your documents",
        theme: str = "dark",
        max_sessions: int = constants.MAX_SESSIONS.value,
        include_sources: bool = True,
        language: Optional[str] = None,
        allowed_extensions: Optional[set] = None,
        on_upload: Optional[Callable[[str, str], str]] = None,
        persist_path: Optional[str] = None,
    ) -> None:
        self.title              = title
        self.description        = description
        self.theme              = theme
        self.allowed_extensions = allowed_extensions or FileProcessor.DEFAULT_EXTENSIONS
        self.on_upload          = on_upload

        self._adapter = RAGAdapter(rag, include_sources=include_sources, language=language)
        self._store   = SessionStore(max_sessions=max_sessions, persist_path=persist_path)
        self._app     = None
        # msg_id → entry_id  (لربط التقييم بـ RAGWithFeedback)
        self._feedback_map: Dict[str, str] = {}

    # ── Public API ────────────────────────────────────────────────────────────

    def launch(
        self,
        host: str = "0.0.0.0",
        port: int = 7860,
        open_browser: bool = True,
        debug: bool = False,
    ) -> None:
        """
        run the application on web

        Args:
            host         :  listener address (default: 0.0.0.0)
            port         : port number (default: 7860)
            open_browser : automatically open the browser
            debug        : debug mode for Flask

        Raises:
            ImportError: if Flask is not installed 
        """
        self._build_app()
        if open_browser:
            threading.Timer(
                constants.BROWSER_OPEN_DELAY.value,
                lambda: webbrowser.open(f"http://localhost:{port}"),
            ).start()
        logger.info("RAG Chat UI on http://%s:%d", host, port)
        _print_banner(self.title, port)
        self._app.run(host=host, port=port, debug=debug, threaded=True)

    def create_session(self) -> ChatSession:
        """إنشاء جلسة برمجيًا (بدون واجهة).\n
        create a session without a UI
        """
        return self._store.create()

    def get_session(self, session_id: str) -> Optional[ChatSession]:
        """الحصول على جلسة بمعرّفها.\n
        get a session by session_id
        """
        return self._store.get(session_id)

    def delete_session(self, session_id: str) -> bool:
        """حذف جلسة.\n
        delete a session by session_id
        """
        return self._store.delete(session_id)

    def ask(self, query: str, session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        إرسال سؤال برمجيًا والحصول على إجابة.\n
        ask a question and get an answer


        Args:
            query      : نص السؤال
            session_id : معرّف الجلسة (يُنشئ جديدة إن لم يُحدَّد)

        Returns:
            Dict: session_id, answer, sources, latency_ms, msg_id

        Raises:
            ValueError: إذا كان الاستعلام فارغًا
        """
        if not query or not query.strip():
            raise ValueError("the query must not be empty")

        session = self._store.get(session_id) if session_id else None
        if session is None:
            session = self._store.create()

        session.add("user", query)
        t0 = time.perf_counter()
        try:
            answer, sources = self._adapter.ask(query)
            error = None
        except Exception as exc:
            logger.exception("RAG error")
            answer  = f"❌ error in resource query: {exc}"
            sources = []
            error   = str(exc)

        latency_ms = (time.perf_counter() - t0) * 1000
        msg = session.add("assistant", answer, sources=sources, latency_ms=latency_ms, error=error)

        # حفظ entry_id لربط التقييم بـ RAGWithFeedback
        entry_id = self._adapter.pop_last_entry_id()
        if entry_id:
            self._feedback_map[msg.msg_id] = entry_id

        self._store.save()
        return {
            "session_id":    session.session_id,
            "session_title": session.title,
            "answer":        answer,
            "sources":       sources,
            "latency_ms":    round(latency_ms, 1),
            "msg_id":        msg.msg_id,
        }

    def get_stats(self) -> Dict[str, Any]:
        """إحصائيات شاملة للواجهة والـ RAG.\n
        get stats for the UI and RAG
        """
        return {
            "sessions":       self._store.count,
            "total_messages": self._store.total_messages,
            "rag":            self._adapter.get_stats(),
        }

    # ── File Handling ─────────────────────────────────────────────────────────

    def _ingest_file(self, file_path: str, doc_id: str) -> str:
        try:
            if self.on_upload:
                return self.on_upload(file_path, doc_id)

            text = FileProcessor.read(file_path)
            if not text.strip():
                return "⚠️ text is empty"

            self._adapter.ingest(doc_id, text)
            return f"✅ added ({len(text):,} characters)"

        except RuntimeError as exc:
            return f"❌ {exc}"
        except Exception as exc:
            logger.exception("Upload error: %s", file_path)
            return f"❌ error: {exc}"

    # ── Flask Builder ─────────────────────────────────────────────────────────

    def _build_app(self) -> None:
        try:
            from flask import Flask, Response, jsonify, request, stream_with_context
        except ImportError as exc:
            raise ImportError("Flask required: pip install flask") from exc

        app = Flask(__name__)
        app.secret_key = os.urandom(24)
        ui = self

        # ── Static page ───────────────────────────────────────────────────────

        @app.route("/")
        def index():
            return Response(
                _build_html(ui.title, ui.description, ui.theme),
                mimetype="text/html",
            )

        @app.route("/api/health")
        def health():
            return jsonify({"status": "ok", "timestamp": datetime.now().isoformat()})

        # ── Session CRUD ──────────────────────────────────────────────────────

        @app.route("/api/session/new", methods=["POST"])
        def new_session():
            s = ui._store.create()
            return jsonify({"session_id": s.session_id, "title": s.title})

        @app.route("/api/sessions")
        def list_sessions():
            return jsonify([
                {
                    "session_id":    s.session_id,
                    "title":         s.title,
                    "updated_at":    s.updated_at,
                    "message_count": s.message_count,
                    "documents":     s.documents,
                    "is_pinned":     s.is_pinned,
                }
                for s in ui._store.list_sorted()
            ])

        @app.route("/api/sessions/search")
        def search_sessions():
            q = request.args.get("q", "").strip()
            return jsonify([
                {
                    "session_id":    s.session_id,
                    "title":         s.title,
                    "updated_at":    s.updated_at,
                    "message_count": s.message_count,
                    "is_pinned":     s.is_pinned,
                }
                for s in ui._store.search(q)
            ])

        @app.route("/api/session/<sid>")
        def get_session(sid):
            s = ui._store.get(sid)
            return jsonify(s.to_dict()) if s else (jsonify({"error": "not found"}), 404)

        @app.route("/api/session/<sid>", methods=["DELETE"])
        def delete_session(sid):
            return jsonify({"ok": True}) if ui._store.delete(sid) else (
                jsonify({"error": "not found"}), 404
            )

        @app.route("/api/session/<sid>/clear", methods=["POST"])
        def clear_session(sid):
            s = ui._store.get(sid)
            if not s:
                return jsonify({"error": "not found"}), 404
            s.clear()
            ui._store.save()
            return jsonify({"ok": True})

        @app.route("/api/session/<sid>/rename", methods=["POST"])
        def rename_session(sid):
            body = request.get_json(force=True)
            title = (body.get("title") or "").strip()
            if not title:
                return jsonify({"error": "title is empty"}), 400
            ok = ui._store.rename(sid, title)
            return jsonify({"ok": ok}) if ok else (jsonify({"error": "not found"}), 404)

        @app.route("/api/session/<sid>/pin", methods=["POST"])
        def pin_session(sid):
            body = request.get_json(force=True)
            pinned = bool(body.get("pinned", True))
            ok = ui._store.pin(sid, pinned)
            return jsonify({"ok": ok}) if ok else (jsonify({"error": "not found"}), 404)

        @app.route("/api/session/<sid>/export")
        def export_session(sid):
            """تصدير الجلسة بصيغة JSON أو TXT."""
            s = ui._store.get(sid)
            if not s:
                return jsonify({"error": "not found"}), 404

            fmt = request.args.get("format", "json").lower()
            if fmt == "txt":
                lines = [f"# {s.title}\n"]
                for m in s.messages:
                    prefix = "👤 User" if m.role == "user" else "🤖 Assistant"
                    lines.append(f"{prefix}:\n{m.content}\n")
                    if m.sources:
                        lines.append(f"Sources: {', '.join(m.sources)}\n")
                    lines.append("")
                content = "\n".join(lines)
                return Response(
                    content,
                    mimetype="text/plain; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="chat_{sid}.txt"'},
                )
            else:
                return Response(
                    json.dumps(s.to_dict(), ensure_ascii=False, indent=2),
                    mimetype="application/json",
                    headers={"Content-Disposition": f'attachment; filename="chat_{sid}.json"'},
                )

        # ── Rating ────────────────────────────────────────────────────────────

        @app.route("/api/session/<sid>/rate", methods=["POST"])
        def rate_message(sid):
            body    = request.get_json(force=True)
            msg_id  = body.get("msg_id", "")
            rating  = int(body.get("rating", 0))
            comment = body.get("comment") or None
            if rating not in (-1, 0, 1):
                return jsonify({"error": "rating must be -1, 0, or 1"}), 400

            # حفظ التقييم في الجلسة
            ok = ui._store.rate_message(sid, msg_id, rating)
            if not ok:
                return jsonify({"error": "not found"}), 404

            # إرسال التقييم لـ RAGWithFeedback إن وُجد entry_id
            feedback_ok = False
            if rating != 0:
                entry_id = ui._feedback_map.pop(msg_id, None)
                if entry_id:
                    feedback_ok = ui._adapter.rate_feedback(entry_id, rating, comment=comment)
                    logger.debug("Feedback rated: msg=%s entry=%s rating=%d ok=%s",
                                 msg_id, entry_id, rating, feedback_ok)

            return jsonify({"ok": True, "feedback_ok": feedback_ok})

        # ── Chat ──────────────────────────────────────────────────────────────

        @app.route("/api/chat", methods=["POST"])
        def chat():
            body  = request.get_json(force=True)
            query = (body.get("query") or "").strip()
            if not query:
                return jsonify({"error": "query is empty"}), 400
            if len(query) > constants.MAX_QUERY_LENGTH.value:
                return jsonify({"error": f"query exceeds {constants.MAX_QUERY_LENGTH.value} characters"}), 400
            return jsonify(ui.ask(query, session_id=body.get("session_id")))

        @app.route("/api/chat/stream", methods=["POST"])
        def chat_stream():
            body  = request.get_json(force=True)
            sid   = body.get("session_id")
            query = (body.get("query") or "").strip()
            if not query:
                return jsonify({"error": "query is empty"}), 400

            session = ui._store.get(sid) if sid else ui._store.create()
            session.add("user", query)

            stop_event = threading.Event()
            stream_id  = body.get("stream_id", str(uuid.uuid4())[:8])
            ui._stop_events = getattr(ui, "_stop_events", {})
            ui._stop_events[stream_id] = stop_event

            def generate() -> Iterator[str]:
                tokens: List[str] = []
                t0 = time.perf_counter()
                try:
                    # محاولة astream أولًا
                    if hasattr(ui._adapter.rag, "astream"):
                        import asyncio
                        collected: List[str] = []

                        async def _collect() -> None:
                            async for t in ui._adapter.rag.astream(
                                query, language=ui._adapter.language
                            ):
                                collected.append(t)

                        try:
                            loop = asyncio.new_event_loop()
                            loop.run_until_complete(_collect())
                            loop.close()
                            for token in collected:
                                if stop_event.is_set():
                                    break
                                tokens.append(token)
                                yield f"data: {json.dumps({'token': token, 'done': False})}\n\n"
                        except Exception as exc:
                            logger.warning("astream failed: %s", exc)

                    # fallback: تقسيم الإجابة كلمة كلمة
                    if not tokens:
                        answer, _ = ui._adapter.ask(query)
                        words = answer.split(" ")
                        for i, word in enumerate(words):
                            if stop_event.is_set():
                                break
                            token = word + (" " if i < len(words) - 1 else "")
                            tokens.append(token)
                            yield f"data: {json.dumps({'token': token, 'done': False})}\n\n"
                            time.sleep(constants.STREAM_WORD_DELAY.value)

                    latency_ms = (time.perf_counter() - t0) * 1000
                    complete   = "".join(tokens)
                    msg        = session.add("assistant", complete, latency_ms=latency_ms)
                    ui._store.save()
                    yield f"data: {json.dumps({'token': '', 'done': True, 'session_id': session.session_id, 'session_title': session.title, 'latency_ms': round(latency_ms, 1), 'msg_id': msg.msg_id})}\n\n"

                except Exception as exc:
                    logger.exception("Streaming error")
                    yield f"data: {json.dumps({'token': f'❌ Error: {exc}', 'done': True})}\n\n"
                finally:
                    ui._stop_events.pop(stream_id, None)

            return Response(
                stream_with_context(generate()),
                mimetype="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )

        @app.route("/api/chat/stop", methods=["POST"])
        def stop_stream():
            """إيقاف بث جاري."""
            body      = request.get_json(force=True)
            stream_id = body.get("stream_id", "")
            stop_events = getattr(ui, "_stop_events", {})
            if stream_id in stop_events:
                stop_events[stream_id].set()
                return jsonify({"ok": True})
            return jsonify({"ok": False, "error": "stream not found"})

        # ── Upload ────────────────────────────────────────────────────────────

        @app.route("/api/upload", methods=["POST"])
        def upload():
            sid     = request.form.get("session_id")
            session = ui._store.get(sid) if sid else ui._store.create()
            if "file" not in request.files:
                return jsonify({"error": "no file"}), 400

            file     = request.files["file"]
            filename = file.filename or "uploaded_file"
            suffix   = Path(filename).suffix.lower()

            if suffix not in ui.allowed_extensions:
                allowed = ", ".join(sorted(ui.allowed_extensions))
                return jsonify({"error": f"extension not supported. Allowed: {allowed}"}), 400

            tmp_fd, tmp_path = tempfile.mkstemp(suffix=suffix)
            try:
                os.close(tmp_fd)                          # أغلق الـ file descriptor فورًا
                file.save(tmp_path)
                doc_id = f"{Path(filename).stem}_{str(uuid.uuid4())[:6]}"
                status = ui._ingest_file(tmp_path, doc_id)
            finally:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass

            if status.startswith("✅"):
                session.documents.append({"filename": filename, "doc_id": doc_id})
                ui._store.save()

            return jsonify({
                "session_id": session.session_id,
                "filename":   filename,
                "doc_id":     doc_id,
                "status":     status,
                "documents":  session.documents,
            })

        # ── Document Delete ───────────────────────────────────────────────────

        @app.route("/api/session/<sid>/document/<doc_id>", methods=["DELETE"])
        def delete_document(sid, doc_id):
            """
            حذف مستند من الجلسة وإزالة كل الـ chunks الخاصة به من الـ RAG.

            Returns:
                ok       : True عند النجاح
                rag_ok   : True إذا دعم الـ RAG الحذف الفعلي
                filename : اسم الملف المحذوف
            """
            session = ui._store.get(sid)
            if not session:
                return jsonify({"error": "session not found"}), 404

            removed = session.remove_document(doc_id)
            if not removed:
                return jsonify({"error": "document not found"}), 404

            # حذف من الـ RAG (chunks + index)
            rag_ok = ui._adapter.delete(doc_id)
            ui._store.save()

            return jsonify({
                "ok":       True,
                "rag_ok":   rag_ok,
                "filename": removed.get("filename", ""),
                "documents": session.documents,
            })

        # ── Stats ─────────────────────────────────────────────────────────────

        @app.route("/api/stats")
        def stats():
            return jsonify(ui.get_stats())

        self._app = app