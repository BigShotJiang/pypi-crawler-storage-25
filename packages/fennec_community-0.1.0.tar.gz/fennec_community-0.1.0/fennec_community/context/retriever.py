"""
Hybrid Multi-Retriever System
"""

from __future__ import annotations

import logging
import math
import re
from collections import defaultdict
from typing import Any, Dict, List, Optional
import numpy as np
from .config import ContextEngineConfig
from .models import RetrievalMethod, ScoredChunk
from .strategy import HybridRetrieverStrategy

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  BM25 Scorer (no external dependency)
# ─────────────────────────────────────────────────────────────────────────────

class BM25Scorer:
    """
    use BM25 algorithm for keyword-based retrieval.
    it's a simple implementation without external libraries, suitable for small corpora.
    BM25 formula:
    score(d, q) = Σ idf(t) * ((tf(t, d) * (k1 + 1)) / (tf(t, d) + k1 * (1 - b + b * |d| / avgdl)))
     - tf(t, d): term frequency of term t in document d
     - idf(t): inverse document frequency of term t in the corpus
     - |d|: length of document d
     - avgdl: average document length in the corpus
     - k1, b: parameters (commonly k1=1.5, b=0.75)
    """

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b  = b
        self._corpus:   List[List[str]] = []
        self._idf:      Dict[str, float] = {}
        self._avg_dl:   float = 0.0

    def index(self, documents: List[str]) -> None:
        """build BM25 index from a list of documents"""
        self._corpus = [self._tokenize(d) for d in documents]
        n = len(self._corpus)
        if n == 0:
            return

        # Average document length
        self._avg_dl = sum(len(d) for d in self._corpus) / n

        # IDF per term
        df: Dict[str, int] = defaultdict(int)
        for doc in self._corpus:
            for term in set(doc):
                df[term] += 1

        self._idf = {
            term: math.log((n - freq + 0.5) / (freq + 0.5) + 1)
            for term, freq in df.items()
        }

    def score(self, query: str, top_k: int = 20) -> List[tuple]:
        """
        Returns:
            List of (index, score) sorted by score desc
        """
        if not self._corpus:
            return []

        q_terms = self._tokenize(query)
        scores  = []

        for idx, doc in enumerate(self._corpus):
            dl   = len(doc) or 1
            sc   = 0.0
            freq_map: Dict[str, int] = defaultdict(int)
            for t in doc:
                freq_map[t] += 1

            for term in q_terms:
                if term not in self._idf:
                    continue
                tf  = freq_map.get(term, 0)
                idf = self._idf[term]
                norm_tf = (tf * (self.k1 + 1)) / (
                    tf + self.k1 * (1 - self.b + self.b * dl / self._avg_dl)
                )
                sc += idf * norm_tf

            scores.append((idx, sc))

        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        return re.findall(r"[\w\u0600-\u06FF]{2,}", text.lower())


# ─────────────────────────────────────────────────────────────────────────────
#  Cosine Similarity helper
# ─────────────────────────────────────────────────────────────────────────────

def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    an, bn = np.linalg.norm(a), np.linalg.norm(b)
    if an == 0 or bn == 0:
        return 0.0
    return float(np.dot(a.flatten(), b.flatten()) / (an * bn))


# ─────────────────────────────────────────────────────────────────────────────
#  VectorRetriever
# ─────────────────────────────────────────────────────────────────────────────

class VectorRetriever(HybridRetrieverStrategy):
    """
     vector retrival using cosine similarity.
     can operate in two modes:
     1. in-memory: store chunks and embeddings in memory (suitable for small corpora)
     2. vector store adapter: delegate to external vector database (e.g., FAISS, Pinecone) via an adapter interface
     supports caching query embeddings for faster retrieval of repeated queries. 
    """

    def __init__(
        self,
        config:               ContextEngineConfig,
        chunks:               Optional[List[Any]]         = None,   # للـ in-memory mode
        embeddings:           Optional[List[np.ndarray]]  = None,   # embeddings مسبقة الحساب
        embed_fn:             Optional[Any]               = None,   # دالة embedding
        vector_store_adapter: Optional[Any]               = None,   # adapter خارجي
    ):
        self.cfg                 = config.retriever
        self._chunks             = chunks or []
        self._embeddings         = embeddings or []
        self._embed_fn           = embed_fn
        self._vector_store       = vector_store_adapter
        self._query_cache:       Dict[str, np.ndarray] = {}

    @property
    def method(self) -> str:
        return "vector"

    def index_chunks(
        self,
        chunks:    List[Any],
        embed_fn:  Any,
    ) -> None:
        """build in-memory index from chunks and embedding function"""
        self._chunks   = chunks
        self._embed_fn = embed_fn
        logger.info("VectorRetriever: بناء فهرس %d chunk ...", len(chunks))
        texts           = [getattr(c, "text", "") or getattr(c, "page_content", "") for c in chunks]
        self._embeddings = [embed_fn(t) for t in texts]
        logger.info("VectorRetriever: الفهرس جاهز ✓")

    def retrieve(
        self,
        query:   str,
        top_k:   int,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[ScoredChunk]:
        # ── Delegate to external vector store if available ─────────────────
        if self._vector_store is not None:
            return self._retrieve_from_store(query, top_k, filters)

        # ── In-memory mode ─────────────────────────────────────────────────
        if not self._chunks or not self._embeddings or self._embed_fn is None:
            logger.warning("VectorRetriever: لا توجد بيانات مُفهرسة")
            return []

        q_emb = self._get_query_embedding(query)
        if q_emb is None:
            return []

        scored = []
        for idx, (chunk, emb) in enumerate(zip(self._chunks, self._embeddings)):
            if emb is None:
                continue
            sim = _cosine(q_emb, emb)
            if sim < self.cfg.min_vector_score:
                continue
            sc = ScoredChunk(
                chunk            = chunk,
                vector_score     = sim,
                composite_score  = sim,
                retrieval_method = RetrievalMethod.VECTOR,
                retrieval_rank   = idx,
            )
            scored.append(sc)

        scored.sort(key=lambda x: x.vector_score, reverse=True)
        return scored[:top_k]

    def _retrieve_from_store(
        self,
        query:   str,
        top_k:   int,
        filters: Optional[Dict[str, Any]],
    ) -> List[ScoredChunk]:
        """استرجاع من vector store خارجي عبر adapter"""
        try:
            results = self._vector_store.similarity_search_with_score(
                query, k=top_k, filter=filters
            )
            scored = []
            for doc, sim in results:
                scored.append(ScoredChunk(
                    chunk           = doc,
                    vector_score    = float(sim),
                    composite_score = float(sim),
                    retrieval_method= RetrievalMethod.VECTOR,
                ))
            return scored
        except Exception as e:
            logger.error("VectorRetriever: خطأ في الاسترجاع: %s", e)
            return []

    def _get_query_embedding(self, query: str) -> Optional[np.ndarray]:
        if query in self._query_cache:
            return self._query_cache[query]
        try:
            emb = self._embed_fn(query)
            self._query_cache[query] = emb
            return emb
        except Exception as e:
            logger.warning("VectorRetriever: فشل حساب embedding للاستعلام: %s", e)
            return None


# ─────────────────────────────────────────────────────────────────────────────
#  KeywordRetriever
# ─────────────────────────────────────────────────────────────────────────────

class KeywordRetriever(HybridRetrieverStrategy):
    """
     keyword-based retriever using BM25 scoring.
     suitable for small to medium corpora where keyword matching is effective.
     not as powerful as vector retrieval for semantic matching, but can capture exact term matches and is more interpretable.
     can be used as a complementary method to boost scores of chunks that have strong keyword matches, even if their vector similarity is low.
     ideal for queries that contain specific terms or when the corpus has a lot of domain-specific jargon that may not be well captured by general embeddings.
    """

    def __init__(self, config: ContextEngineConfig, chunks: Optional[List[Any]] = None):
        self.cfg     = config.retriever
        self._chunks = chunks or []
        self._bm25   = BM25Scorer()
        if chunks:
            self._build_index()

    @property
    def method(self) -> str:
        return "keyword"

    def index_chunks(self, chunks: List[Any]) -> None:
        self._chunks = chunks
        self._build_index()

    def _build_index(self) -> None:
        texts = [getattr(c, "text", "") or getattr(c, "page_content", "") for c in self._chunks]
        self._bm25.index(texts)
        logger.info("KeywordRetriever: فهرس BM25 لـ %d chunk", len(self._chunks))

    def retrieve(
        self,
        query:   str,
        top_k:   int,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[ScoredChunk]:
        if not self._chunks:
            return []

        raw = self._bm25.score(query, top_k=top_k * 2)
        if not raw:
            return []

        # Normalize scores to [0, 1]
        max_sc = max(sc for _, sc in raw) or 1.0
        results = []
        for idx, sc in raw[:top_k]:
            chunk = self._chunks[idx]
            norm_sc = sc / max_sc
            results.append(ScoredChunk(
                chunk            = chunk,
                keyword_score    = norm_sc,
                composite_score  = norm_sc,
                retrieval_method = RetrievalMethod.KEYWORD,
                retrieval_rank   = idx,
            ))
        return results


# ─────────────────────────────────────────────────────────────────────────────
#  MetadataRetriever
# ─────────────────────────────────────────────────────────────────────────────

class MetadataRetriever(HybridRetrieverStrategy):
    """
    metadata-based retriever that filters chunks based on metadata fields.
    does not use the query text for scoring, but relies entirely on the provided filters.
    ideal for scenarios where the user wants to retrieve chunks based on specific attributes (e.g., date, author, category) rather than semantic content.
    can be used in combination with vector and keyword retrievers to boost scores of chunks that match the metadata filters, even if their vector/keyword scores are low.
    requires that the chunks have a 'metadata' attribute that is a dictionary containing the relevant fields for filtering.
    if filters are not provided, it will return an empty list, as metadata retrieval is meaningless without filter criteria.
    """

    def __init__(self, config: ContextEngineConfig, chunks: Optional[List[Any]] = None):
        self.cfg     = config.retriever
        self._chunks = chunks or []

    @property
    def method(self) -> str:
        return "metadata"

    def index_chunks(self, chunks: List[Any]) -> None:
        self._chunks = chunks

    def retrieve(
        self,
        query:   str,
        top_k:   int,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[ScoredChunk]:
        if not self._chunks or not filters:
            return []

        results = []
        for idx, chunk in enumerate(self._chunks):
            meta = getattr(chunk, "metadata", {}) or {}
            if self._matches_filters(meta, filters):
                results.append(ScoredChunk(
                    chunk            = chunk,
                    metadata_score   = 1.0,
                    composite_score  = 1.0,
                    retrieval_method = RetrievalMethod.METADATA,
                    retrieval_rank   = idx,
                ))

        return results[:top_k]

    def _matches_filters(
        self, metadata: Dict[str, Any], filters: Dict[str, Any]
    ) -> bool:
        for key, value in filters.items():
            meta_val = metadata.get(key)
            if meta_val is None:
                return False
            if isinstance(value, list):
                if meta_val not in value:
                    return False
            elif meta_val != value:
                return False
        return True


# ─────────────────────────────────────────────────────────────────────────────
#  HybridRetriever — Orchestrator
# ─────────────────────────────────────────────────────────────────────────────

class HybridRetriever:
    """
    hybrid retriever that combines vector, keyword, and metadata retrieval results using Reciprocal Rank Fusion (RRF) and weighted scoring.
     - RRF fusion gives a boost to chunks that appear in multiple retrieval methods, even if their individual scores are not the highest. This helps to surface chunks that are relevant from multiple perspectives.    
     - The final composite score is a weighted sum of the individual scores, allowing for tuning the importance of each retrieval method based on the use case.
     - The retriever is designed to be flexible and can operate with any combination of the three retrieval methods, depending on the configuration and available data.
     - It also handles cases where one or more retrieval methods may not return results, ensuring that the final output is still meaningful and ranked appropriately.

    """

    RRF_K = 60

    def __init__(
        self,
        config:             ContextEngineConfig,
        vector_retriever:   Optional[VectorRetriever]   = None,
        keyword_retriever:  Optional[KeywordRetriever]  = None,
        metadata_retriever: Optional[MetadataRetriever] = None,
    ):
        self.cfg      = config.retriever
        self._vector  = vector_retriever
        self._keyword = keyword_retriever
        self._meta    = metadata_retriever

    def retrieve(
        self,
        query:   str,
        top_k:   Optional[int]          = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[ScoredChunk]:
        """
        return hybrid retrieval results sorted by composite score (vector + keyword + metadata).
         - each retrieval method is called independently, and their results are merged based on content_hash.
         - RRF fusion is applied to boost chunks that appear in multiple methods.
         - final composite score is calculated as a weighted sum of the individual scores, with weights defined in the configuration.
         - if no results are found, an empty list is returned.
         - the method is robust to cases where one or more retrieval methods may not return results, ensuring that the final output is still meaningful and ranked appropriately.
         - filters are applied to vector and metadata retrieval methods, but not to keyword retrieval, as BM25 operates on the text content. This allows for flexible filtering based on metadata while still leveraging keyword matching for relevance.
         - the top_k parameter can be specified to limit the number of results returned, and it defaults to the value defined in the configuration if not provided.
         - the method logs the number of results retrieved from each method and the final number of merged results for debugging and analysis purposes.
         - the retrieval process is designed to be efficient, with vector retrieval potentially using cached query embeddings and keyword retrieval using a pre-built BM25 index, while metadata retrieval performs simple filtering based on the provided criteria.
         - overall, this method provides a powerful and flexible way to retrieve relevant chunks from a corpus by combining multiple retrieval strategies and leveraging their strengths while mitigating their weaknesses through fusion and weighted scoring.
         - it is suitable for a wide range of applications, from question answering to document retrieval, where relevance can be determined by a combination of semantic similarity, keyword matching, and metadata attributes.
         - the method can be further extended in the future to include additional retrieval strategies (e.g., graph-based, temporal) or more sophisticated fusion techniques (e.g., learning-to-rank, neural re-ranking) as needed.
        """
        k = top_k or self.cfg.top_k
        all_results: Dict[str, ScoredChunk] = {}   # content_hash → ScoredChunk

        # ── 1. Vector ─────────────────────────────────────────────────────
        vec_results: List[ScoredChunk] = []
        if self.cfg.use_vector and self._vector:
            vec_results = self._vector.retrieve(query, top_k=k * 2, filters=filters)
            for sc in vec_results:
                all_results.setdefault(sc.content_hash, sc)
                all_results[sc.content_hash].vector_score = sc.vector_score

        # ── 2. Keyword ────────────────────────────────────────────────────
        kw_results: List[ScoredChunk] = []
        if self.cfg.use_keyword and self._keyword:
            kw_results = self._keyword.retrieve(query, top_k=k * 2, filters=filters)
            for sc in kw_results:
                if sc.content_hash in all_results:
                    all_results[sc.content_hash].keyword_score = sc.keyword_score
                else:
                    all_results[sc.content_hash] = sc

        # ── 3. Metadata ───────────────────────────────────────────────────
        meta_results: List[ScoredChunk] = []
        if self.cfg.use_metadata and self._meta and filters:
            meta_results = self._meta.retrieve(query, top_k=k, filters=filters)
            for sc in meta_results:
                if sc.content_hash in all_results:
                    all_results[sc.content_hash].metadata_score = sc.metadata_score
                else:
                    all_results[sc.content_hash] = sc

        if not all_results:
            logger.warning("HybridRetriever: لا توجد نتائج للاستعلام: %.60s", query)
            return []

        # ── 4. Reciprocal Rank Fusion ─────────────────────────────────────
        chunks_list = list(all_results.values())
        self._apply_rrf(chunks_list, vec_results, kw_results, meta_results)

        # ── 5. Final weighted composite score ─────────────────────────────
        for sc in chunks_list:
            sc.composite_score = (
                sc.vector_score   * self.cfg.vector_weight +
                sc.keyword_score  * self.cfg.keyword_weight +
                sc.metadata_score * self.cfg.metadata_weight
            )

        chunks_list.sort(key=lambda x: x.composite_score, reverse=True)

        logger.debug(
            "HybridRetriever: vector=%d kw=%d meta=%d → merged=%d",
            len(vec_results), len(kw_results), len(meta_results), len(chunks_list),
        )
        return chunks_list[:k]

    def _apply_rrf(
        self,
        merged:   List[ScoredChunk],
        *ranked_lists: List[ScoredChunk],
    ) -> None:
        """حساب درجة RRF وإضافتها كـ bonus للـ composite_score"""
        hash_to_sc = {sc.content_hash: sc for sc in merged}
        rrf_scores: Dict[str, float] = defaultdict(float)

        for ranked in ranked_lists:
            for rank, sc in enumerate(ranked):
                rrf_scores[sc.content_hash] += 1.0 / (self.RRF_K + rank + 1)

        if not rrf_scores:
            return

        max_rrf = max(rrf_scores.values()) or 1.0
        for h, rrf in rrf_scores.items():
            if h in hash_to_sc:
                # نُضيف 20% bonus للـ chunks التي ظهرت في أكثر من مصدر
                hash_to_sc[h].composite_score += (rrf / max_rrf) * 0.20
