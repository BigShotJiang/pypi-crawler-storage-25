"""
fennec.context — Advanced Context Intelligence Engine
محرك ذكاء السياق المتقدم لمكتبة Fennec

المعمارية:
    Query → QueryAnalyzer → HybridRetriever → ChunkFilter
         → CompositeRanker → SmartContextComposer → ContextGuard
         → ContextResult

الاستخدام السريع:
    from fennec.context import ContextEngine, ContextEngineConfig

    engine = ContextEngine()
    engine.index(chunks=my_chunks, embed_fn=my_embed_fn)
    result = engine.run("ما هو التعلم الآلي؟")
    print(result.context)
"""

# ── Config ─────────────────────────────────────────────────────────────────
from .config import (
    ContextEngineConfig,
    ContextConfig,          # backward-compatible alias
    QueryAnalyzerConfig,
    RetrieverConfig,
    FilterConfig,
    RankingConfig,
    ComposerConfig,
    GuardConfig,
    CacheConfig,
    LengthCounter,
)

# ── Models ──────────────────────────────────────────────────────────────────
from .models import (
    QueryAnalysis,
    QueryIntent,
    QueryComplexity,
    RetrievalMethod,
    SourceQuality,
    ScoredChunk,
    ContextResult,
    ConversationTurn,
    ConversationHistory,
)

# ── Strategy interfaces ──────────────────────────────────────────────────────
from .strategy import (
    # Legacy (backward-compatible)
    DeduplicationStrategy,
    RankingStrategy,
    CompressionStrategy,
    BudgetAllocationStrategy,
    # New advanced
    QueryAnalyzerStrategy,
    ChunkFilterStrategy,
    ChunkRankingStrategy,
    ContextComposerStrategy,
    ContextGuardStrategy,
    HybridRetrieverStrategy,
)

from .legacy_compat import PrefixDeduplication, HashDeduplication, GreedyCompression, ScoreRanking,validate_chunk

# ── Query Analyzer ───────────────────────────────────────────────────────────
from .query_analyzer import RuleBasedQueryAnalyzer, build_query_analyzer

# ── Retrieval ────────────────────────────────────────────────────────────────
from .retriever import (
    BM25Scorer,
    VectorRetriever,
    KeywordRetriever,
    MetadataRetriever,
    HybridRetriever,
)

# ── Pipeline ─────────────────────────────────────────────────────────────────
from .pipeline import (
    char_counter,
    make_token_counter,
    ChunkFilter,
    CompositeRanker,
    SmartContextComposer,
)

# ── Guard & Learning ─────────────────────────────────────────────────────────
from .guard_and_learning import (
    ContextGuard,
    AdaptiveLearningSystem,
    ContextCache,
    EqualBudgetAllocation,
    WeightedBudgetAllocation,
    ComplexityBasedAllocation,
)

# ── Main Engine ───────────────────────────────────────────────────────────────
from .engine import ContextEngine, ContextManager

# ── Legacy re-exports (keep old imports working) ─────────────────────────────
from .engine import ContextManager as _LegacyContextManager

# Old context_manager.py symbols (for full backward compatibility)
validate_chunk       = None   # legacy stub — use ScoredChunk
PrefixDeduplication  = None   # legacy stub
HashDeduplication    = None   # legacy stub
GreedyCompression    = None   # legacy stub
ScoreRanking         = None   # legacy stub


def _lazy_legacy():
    """Load legacy symbols only if explicitly imported"""
    from .legacy_compat import (
        validate_chunk,
        PrefixDeduplication,
        HashDeduplication,
        GreedyCompression,
        ScoreRanking,
    )
    return validate_chunk, PrefixDeduplication, HashDeduplication, GreedyCompression, ScoreRanking


__all__ = [
    # ── Config
    "ContextEngineConfig",
    "ContextConfig",
    "QueryAnalyzerConfig",
    "RetrieverConfig",
    "FilterConfig",
    "RankingConfig",
    "ComposerConfig",
    "GuardConfig",
    "CacheConfig",
    "LengthCounter",

    # ── Models
    "QueryAnalysis",
    "QueryIntent",
    "QueryComplexity",
    "RetrievalMethod",
    "SourceQuality",
    "ScoredChunk",
    "ContextResult",
    "ConversationTurn",
    "ConversationHistory",

    # ── Strategy interfaces
    "DeduplicationStrategy",
    "RankingStrategy",
    "CompressionStrategy",
    "BudgetAllocationStrategy",
    "QueryAnalyzerStrategy",
    "ChunkFilterStrategy",
    "ChunkRankingStrategy",
    "ContextComposerStrategy",
    "ContextGuardStrategy",
    "HybridRetrieverStrategy",

    # ── Concrete components
    "RuleBasedQueryAnalyzer",
    "build_query_analyzer",
    "BM25Scorer",
    "VectorRetriever",
    "KeywordRetriever",
    "MetadataRetriever",
    "HybridRetriever",
    "ChunkFilter",
    "CompositeRanker",
    "SmartContextComposer",
    "ContextGuard",
    "AdaptiveLearningSystem",
    "ContextCache",
    "EqualBudgetAllocation",
    "WeightedBudgetAllocation",
    "ComplexityBasedAllocation",
    "char_counter",
    "make_token_counter",

    # ── Main engine
    "ContextEngine",
    "ContextManager",
]
