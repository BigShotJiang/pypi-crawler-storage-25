"""
strategy.py — Abstract strategy interfaces for the Context Intelligence Engine
واجهات الاستراتيجيات المجردة — متوافقة مع الإصدار الأصلي + امتدادات جديدة
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

from .models import QueryAnalysis, ScoredChunk


# ─────────────────────────────────────────────────────────────────────────────
#  Legacy strategies (kept for full backward-compatibility)
# ─────────────────────────────────────────────────────────────────────────────

class DeduplicationStrategy(ABC):
    """duplicate removal strategy for retrieved chunks"""

    @abstractmethod
    def deduplicate(self, chunks: List[Tuple]) -> List[Tuple]:
        ...


class RankingStrategy(ABC):
    """reranking strategy for retrieved chunks"""

    @abstractmethod
    def rank(self, chunks: List[Tuple], max_chunks: Optional[int]) -> List[Tuple]:
        ...


class CompressionStrategy(ABC):
    """compression strategy for the context before feeding it to the LLM"""

    @abstractmethod
    def compress(
        self,
        context:   str,
        target:    int,
        counter:   Any,   # LengthCounter
        separator: str,
    ) -> str:
        ...


class BudgetAllocationStrategy(ABC):
    """budget allocation strategy for multiple queries in a single batch"""

    @abstractmethod
    def allocate(self, total_budget: int, n_queries: int) -> List[int]:
        ...


# ─────────────────────────────────────────────────────────────────────────────
#  New advanced strategy interfaces
# ─────────────────────────────────────────────────────────────────────────────

class QueryAnalyzerStrategy(ABC):
    """
     query analysis strategy to extract structured information from the query.
     This can be used for advanced filtering, ranking, and composition strategies.
    """

    @abstractmethod
    def analyze(self, query: str) -> QueryAnalysis:
        """Analyze a single query and return a QueryAnalysis object."""
        ...


class ChunkFilterStrategy(ABC):
    """Filtering strategy for retrieved chunks."""

    @abstractmethod
    def filter(self, chunks: List[ScoredChunk]) -> List[ScoredChunk]:
        """Filter a list of ScoredChunks and remove unwanted ones."""
        ...


class ChunkRankingStrategy(ABC):
    """
        Reranking strategy for retrieved chunks based on query analysis.
        This can be used to boost chunks that are more relevant to the query intent,or to demote chunks that are less relevant.

    """

    @abstractmethod
    def rank(
        self,
        chunks:   List[ScoredChunk],
        analysis: QueryAnalysis,
        max_n:    Optional[int] = None,
    ) -> List[ScoredChunk]:
        ...


class ContextComposerStrategy(ABC):
    """strategy for composing the final context"""

    @abstractmethod
    def compose(
        self,
        chunks:   List[ScoredChunk],
        analysis: QueryAnalysis,
        budget:   int,
    ) -> str:
        ...


class ContextGuardStrategy(ABC):
    """
    strategy for validating the quality of the composed context.
    can be replaced with an LLM-based hallucination checker.
    """

    @abstractmethod
    def validate(
        self,
        context:  str,
        query:    str,
        analysis: QueryAnalysis,
    ) -> Tuple[bool, List[str]]:
        """
        Returns:
            (passed: bool, warnings: List[str])
        """
        ...


class HybridRetrieverStrategy(ABC):
    """
    hybrid retrieval strategy.
    Each retriever implements this interface.
    """

    @abstractmethod
    def retrieve(
        self,
        query:        str,
        top_k:        int,
        filters:      Optional[Dict[str, Any]] = None,
    ) -> List[ScoredChunk]:
        ...

    @property
    @abstractmethod
    def method(self) -> str:
        """Name of the retrieval method (vector / keyword / metadata)"""
        ...
