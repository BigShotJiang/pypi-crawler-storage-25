from __future__ import annotations

import asyncio
import json
import sqlite3
import sys
import tempfile
import unittest
import warnings
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from soma_mcp.store import METRIC_KINDS, _QUERY_SENSOR_DATA_ALLOWED_TABLES, SomaStore


class QuerySensorDataTests(unittest.TestCase):
    def _store_with_sample_data(self, tmp: str) -> SomaStore:
        # Use a real sensor table from the allowlist so we can exercise both
        # the legacy SQL-shape checks and the table-allowlist gate.
        db_path = Path(tmp) / "sensors.db"
        with closing(sqlite3.connect(db_path)) as connection, connection:
            connection.execute(
                "CREATE TABLE health_samples (id INTEGER PRIMARY KEY, value TEXT)"
            )
            connection.executemany(
                "INSERT INTO health_samples (value) VALUES (?)",
                [("alpha",), ("bravo",), ("charlie",)],
            )
            # Tables that should be blocked by the allowlist — populated so
            # a bypass would actually leak data, not just hit "no such table".
            connection.execute(
                "CREATE TABLE pairing_state (id INTEGER PRIMARY KEY, payload_json TEXT)"
            )
            connection.execute(
                "INSERT INTO pairing_state (id, payload_json) VALUES (1, '{\"secret\":\"x\"}')"
            )
            connection.execute(
                "CREATE TABLE sync_state (key TEXT PRIMARY KEY, value BLOB)"
            )
            connection.execute(
                "INSERT INTO sync_state (key, value) VALUES ('change_token', x'00')"
            )
            connection.execute(
                "CREATE TABLE used_pairing_ids (pairing_id TEXT PRIMARY KEY)"
            )
            connection.execute(
                "INSERT INTO used_pairing_ids (pairing_id) VALUES ('abc')"
            )
        return SomaStore(db_path)

    def test_limit_keyword_inside_literal_does_not_suppress_limit_append(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            rows = store.query_sensor_data(
                "SELECT 'limit' AS marker, value FROM health_samples ORDER BY id",
                limit=2,
            )

            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[0]["marker"], "limit")

    def test_forbidden_keywords_inside_literals_and_comments_are_allowed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            rows = store.query_sensor_data(
                """
                SELECT 'attach' AS literal, value
                FROM health_samples
                WHERE value != 'pragma'
                -- VACUUM in a comment is inert
                ORDER BY id
                """,
                limit=1,
            )

            self.assertEqual(rows, [{"literal": "attach", "value": "alpha"}])

    def test_multi_statement_sql_is_rejected_outside_literals(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            with self.assertRaisesRegex(ValueError, "single SQL statement"):
                store.query_sensor_data(
                    "SELECT ';' AS literal; SELECT value FROM health_samples"
                )

    def test_forbidden_sql_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            with self.assertRaisesRegex(ValueError, "Only read-only SELECT"):
                store.query_sensor_data("ATTACH DATABASE '/tmp/other.db' AS other")

            with self.assertRaisesRegex(ValueError, "Disallowed SQL keyword: PRAGMA_FUNCTION_LIST"):
                store.query_sensor_data("SELECT * FROM pragma_function_list()")

            rows = store.query_sensor_data(
                "SELECT value AS pragmatic FROM health_samples", limit=1
            )
            self.assertEqual(rows[0]["pragmatic"], "alpha")

            with self.assertRaisesRegex(ValueError, "Disallowed SQL keyword: LOAD_EXTENSION"):
                store.query_sensor_data("SELECT load_extension('/tmp/extension')")

            with self.assertRaisesRegex(ValueError, "Disallowed SQL keyword: DELETE"):
                store.query_sensor_data(
                    "WITH stale AS (SELECT id FROM health_samples) DELETE FROM health_samples"
                )

    def test_outer_limit_is_enforced_even_when_query_has_nested_limit(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            rows = store.query_sensor_data(
                """
                SELECT value
                FROM health_samples
                WHERE id IN (SELECT id FROM health_samples LIMIT 3)
                ORDER BY id
                """,
                limit=2,
            )

            self.assertEqual(len(rows), 2)

    def test_query_sensor_data_allows_cte_alias_of_allowed_table(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            rows = store.query_sensor_data(
                """
                WITH recent AS (
                    SELECT id, value FROM health_samples
                )
                SELECT value FROM recent ORDER BY id
                """,
                limit=2,
            )

            self.assertEqual([row["value"] for row in rows], ["alpha", "bravo"])

    def test_query_sensor_data_rejects_pairing_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            with self.assertRaisesRegex(ValueError, r"Disallowed tables.*pairing_state"):
                store.query_sensor_data("SELECT * FROM pairing_state")

    def test_query_sensor_data_rejects_sync_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            with self.assertRaisesRegex(ValueError, r"Disallowed tables.*sync_state"):
                store.query_sensor_data("SELECT * FROM sync_state")

    def test_query_sensor_data_rejects_join_to_non_sensor_table(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            with self.assertRaisesRegex(
                ValueError, r"Disallowed tables.*used_pairing_ids"
            ):
                store.query_sensor_data(
                    "SELECT * FROM health_samples JOIN used_pairing_ids ON 1=1"
                )

    def test_query_sensor_data_rejects_paren_wrapped_disallowed_table(self) -> None:
        # SECURITY REGRESSION: prior to the parser fix, `FROM (pairing_state)`
        # bypassed the regex (it required a non-paren character right after
        # FROM/JOIN). The SQLite authorizer is now the authoritative
        # backstop, but we also tightened the early-reject parser. Both
        # paren-wrapped and nested-paren forms must be rejected.
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            for sql in (
                "SELECT * FROM (pairing_state)",
                "SELECT * FROM ((pairing_state))",
                "SELECT * FROM (((pairing_state)))",
                "SELECT * FROM ( pairing_state )",
                "SELECT * FROM (sync_state)",
                "SELECT * FROM (used_pairing_ids)",
            ):
                with self.assertRaises(
                    ValueError,
                    msg=f"Expected paren-wrapped allowlist rejection: {sql!r}",
                ) as ctx:
                    store.query_sensor_data(sql)
                self.assertRegex(str(ctx.exception), r"Disallowed tables.*\b(pairing_state|sync_state|used_pairing_ids)\b")

    def test_query_sensor_data_rejects_comma_join_to_disallowed_table(self) -> None:
        # SECURITY REGRESSION: prior to the parser fix, `FROM a, b`
        # only checked `a` and let `b` through. SQL's comma-join syntax
        # is equivalent to CROSS JOIN, and any of the comma-separated
        # tables must be in the allowlist.
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            for sql in (
                "SELECT * FROM health_samples, pairing_state",
                "SELECT * FROM health_samples, sync_state",
                "SELECT * FROM health_samples, used_pairing_ids",
                "SELECT * FROM health_samples, health_latest, pairing_state",
                "SELECT * FROM (pairing_state), health_samples",
                "SELECT * FROM health_samples a, pairing_state b",
            ):
                with self.assertRaises(
                    ValueError,
                    msg=f"Expected comma-join allowlist rejection: {sql!r}",
                ) as ctx:
                    store.query_sensor_data(sql)
                self.assertRegex(str(ctx.exception), r"Disallowed tables.*\b(pairing_state|sync_state|used_pairing_ids)\b")

    def test_query_sensor_data_rejects_via_authorizer_when_regex_misses(self) -> None:
        # The SQLite authorizer is the authoritative backstop. Even if a
        # bypass slips past the early-reject regex, the authorizer fires
        # at statement-preparation time and denies the read. We force
        # this by hand-crafting a tricky form via the public API: an
        # explicit CROSS JOIN with bracketed identifiers.
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            for sql in (
                "SELECT * FROM health_samples CROSS JOIN [pairing_state]",
                "SELECT * FROM health_samples CROSS JOIN `pairing_state`",
                "SELECT * FROM health_samples NATURAL JOIN \"pairing_state\"",
            ):
                with self.assertRaises(
                    ValueError,
                    msg=f"Expected authorizer-backed rejection: {sql!r}",
                ) as ctx:
                    store.query_sensor_data(sql)
                self.assertRegex(str(ctx.exception), r"(?i)pairing_state")

    def test_query_sensor_data_rejects_quoted_disallowed_table(self) -> None:
        # SECURITY REGRESSION: prior to the `_sql_code_only` fix, quoted
        # identifiers were blanked out before the allowlist regex ran, so
        # `SELECT * FROM "pairing_state"` silently bypassed the allowlist.
        # All of double-quote, backtick, and square-bracket forms must
        # be rejected.
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            for sql in (
                'SELECT * FROM "pairing_state"',
                "SELECT * FROM `pairing_state`",
                "SELECT * FROM [pairing_state]",
            ):
                with self.assertRaisesRegex(
                    ValueError, r"Disallowed tables.*pairing_state",
                    msg=f"Expected allowlist to reject: {sql!r}",
                ):
                    store.query_sensor_data(sql)

    def test_query_sensor_data_allows_quoted_sensor_table_identifier(self) -> None:
        # Identifier quoting (double quotes, backticks, square brackets) is
        # standard in user SQL — the allowlist must still match.
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            rows = store.query_sensor_data(
                'SELECT COUNT(*) AS n FROM "health_samples"'
            )
            self.assertEqual(rows[0]["n"], 3)

    def test_query_sensor_data_ignores_table_name_inside_literal(self) -> None:
        # 'pairing_state' appearing only inside a quoted literal must not
        # trip the allowlist.
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            rows = store.query_sensor_data(
                "SELECT 'from pairing_state' AS marker, value FROM health_samples ORDER BY id",
                limit=1,
            )
            self.assertEqual(rows[0]["marker"], "from pairing_state")

    def test_query_sensor_data_rejects_tableless_expression(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            with self.assertRaisesRegex(ValueError, "at least one allowed sensor table"):
                store.query_sensor_data("SELECT 1 AS value")

    def test_query_sensor_data_rejects_cte_without_real_sensor_table(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_sample_data(tmp)

            with self.assertRaisesRegex(ValueError, "at least one allowed sensor table"):
                store.query_sensor_data(
                    "WITH constants AS (SELECT 1 AS value) SELECT value FROM constants"
                )


class CategoryLabelTests(unittest.TestCase):
    def _store_with_health_data(self, tmp: str) -> SomaStore:
        db_path = Path(tmp) / "sensors.db"
        with closing(sqlite3.connect(db_path)) as connection, connection:
            connection.execute(
                """
                CREATE TABLE health_samples (
                    metric TEXT NOT NULL,
                    value REAL NOT NULL,
                    unit TEXT NOT NULL,
                    start_at TEXT NOT NULL,
                    end_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE health_latest (
                    metric TEXT NOT NULL,
                    value REAL NOT NULL,
                    unit TEXT NOT NULL,
                    recorded_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE health_daily (
                    metric TEXT NOT NULL,
                    date TEXT NOT NULL,
                    aggregation_kind TEXT NOT NULL,
                    unit TEXT NOT NULL,
                    snapshot_value REAL,
                    sum_value REAL,
                    avg_value REAL,
                    min_value REAL,
                    max_value REAL,
                    count INTEGER,
                    recorded_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                INSERT INTO health_samples (metric, value, unit, start_at, end_at)
                VALUES ('headache', 3, 'severity', '2026-04-22T10:00:00Z', '2026-04-22T10:15:00Z')
                """
            )
            connection.execute(
                """
                INSERT INTO health_latest (metric, value, unit, recorded_at, updated_at)
                VALUES ('ovulation_test', 2, 'result', '2026-04-22T10:00:00Z', '2026-04-22T10:00:00Z')
                """
            )
        return SomaStore(db_path)

    def test_get_health_metric_includes_category_value_label(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_health_data(tmp)

            rows = store.get_health_metric("headache")

            self.assertEqual(rows[0]["value"], 3.0)
            self.assertEqual(rows[0]["value_label"], "Moderate")

    def test_metrics_list_includes_latest_category_value_label(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_health_data(tmp)

            rows = store.get_health_metrics_list()
            ovulation = next(row for row in rows if row["metric"] == "ovulation_test")

            self.assertEqual(ovulation["value"], 2.0)
            self.assertEqual(ovulation["value_label"], "Luteinizing Hormone Surge")


class QueryTimeoutTranslationTests(unittest.TestCase):
    """B4 regression: 2-second timeout must surface as a ValueError, not a raw
    `OperationalError: interrupted` leaking from sqlite3."""

    def test_timeout_translates_to_value_error(self) -> None:
        # Generate enough work that SQLite's progress handler ticks
        # (default `n` is 10000 instructions). A 3-way self-cross-join on a
        # 200-row table produces 8M rows of work, plenty to trigger a
        # SQLITE_INTERRUPT once `time.monotonic() > deadline`.
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            with closing(sqlite3.connect(db_path)) as connection, connection:
                connection.execute(
                    "CREATE TABLE health_samples (id INTEGER PRIMARY KEY, value TEXT)"
                )
                connection.executemany(
                    "INSERT INTO health_samples (value) VALUES (?)",
                    [(f"row-{i}",) for i in range(200)],
                )
            store = SomaStore(db_path)
            with self.assertRaisesRegex(ValueError, r"exceeded the .* time limit"):
                store._query(
                    "SELECT a.id FROM health_samples a, health_samples b, health_samples c",
                    timeout_seconds=0.001,
                    allowed_tables=frozenset({"health_samples"}),
                )


class ResourceWarningTests(unittest.TestCase):
    """B5 regression: `with sqlite3.connect()` no longer closes the connection
    on Python 3.12+. Ensure the production `_query` path does not emit
    `ResourceWarning: unclosed database`."""

    def test_query_does_not_leak_connection(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            with closing(sqlite3.connect(db_path)) as connection, connection:
                connection.execute(
                    "CREATE TABLE health_samples (id INTEGER PRIMARY KEY)"
                )
            store = SomaStore(db_path)
            # Promote ResourceWarning to error so the test fails if `_query`
            # leaks any sqlite3.Connection.
            with warnings.catch_warnings():
                warnings.simplefilter("error", ResourceWarning)
                for _ in range(5):
                    store._query("SELECT * FROM health_samples")


class SchemaContractTests(unittest.TestCase):
    def test_metric_inventory_matches_swift_contract(self) -> None:
        expected_metrics = {
            # Hourly cumulative stats
            "steps": "hourlyStat",
            "active_calories": "hourlyStat",
            "basal_calories": "hourlyStat",
            "distance_walking": "hourlyStat",
            "distance_cycling": "hourlyStat",
            "distance_swimming": "hourlyStat",
            "workout_minutes": "hourlyStat",
            "flights_climbed": "hourlyStat",
            "dietary_energy": "hourlyStat",
            "dietary_water": "hourlyStat",
            "dietary_caffeine": "hourlyStat",
            "dietary_protein": "hourlyStat",
            "dietary_carbs": "hourlyStat",
            "dietary_fat": "hourlyStat",
            "dietary_fiber": "hourlyStat",
            "dietary_sugar": "hourlyStat",
            "dietary_sodium": "hourlyStat",
            # Daily snapshots
            "stand_hours": "dailySnapshot",
            "sleep_duration": "dailySnapshot",
            # Sample events
            "heart_rate": "sampleEvent",
            "resting_heart_rate": "sampleEvent",
            "walking_heart_rate_avg": "sampleEvent",
            "blood_oxygen": "sampleEvent",
            "respiratory_rate": "sampleEvent",
            "body_mass": "sampleEvent",
            "body_fat_percentage": "sampleEvent",
            "bmi": "sampleEvent",
            "lean_body_mass": "sampleEvent",
            "height": "sampleEvent",
            "waist_circumference": "sampleEvent",
            "hrv": "sampleEvent",
            "vo2_max": "sampleEvent",
            "body_temperature": "sampleEvent",
            "wrist_temperature": "sampleEvent",
            "blood_pressure_systolic": "sampleEvent",
            "blood_pressure_diastolic": "sampleEvent",
            "blood_glucose": "sampleEvent",
            "environmental_audio": "sampleEvent",
            "walking_steadiness": "sampleEvent",
            # Category events
            "mindful_session": "categoryEvent",
            "low_heart_rate_event": "categoryEvent",
            "high_heart_rate_event": "categoryEvent",
            "irregular_rhythm_event": "categoryEvent",
            "headache": "categoryEvent",
            "fatigue": "categoryEvent",
            "nausea": "categoryEvent",
            "menstrual_flow": "categoryEvent",
            "cervical_mucus": "categoryEvent",
            "ovulation_test": "categoryEvent",
            "sexual_activity": "categoryEvent",
            # CoreMotion activity
            "user_activity": "activityEvent",
        }
        self.assertEqual(METRIC_KINDS, expected_metrics)

    def test_query_sensor_data_allowlist_matches_replica_sensor_tables(self) -> None:
        expected_tables = {
            "location_current",
            "location_history",
            "health_samples",
            "health_latest",
            "health_daily",
            "health_hourly",
            "activity_samples",
            "activity_current",
            "workout_sessions",
        }
        metadata_tables = {"pairing_state", "sync_state", "used_pairing_ids", "app_state"}

        self.assertEqual(_QUERY_SENSOR_DATA_ALLOWED_TABLES, expected_tables)
        self.assertFalse(_QUERY_SENSOR_DATA_ALLOWED_TABLES & metadata_tables)


class ResponseShapeTests(unittest.TestCase):
    """T1: nominal/empty/error response-shape tests for the 8 typed tools that
    previously had zero coverage. Each tool is exercised against:
        - a fully-populated DB (nominal shape)
        - the same schema with zero rows (empty fallback)
        - a DB file that exists but has none of the expected tables (the
          fresh-pair / corrupt-DB regression that B6 mitigates at the server
          wrapper layer; here we assert that `_query` raises sqlite3 errors
          which the server's `run_with_agent_access` translates).
    """

    def _create_full_schema(self, db_path: Path) -> sqlite3.Connection:
        connection = sqlite3.connect(db_path)
        connection.execute(
            """
            CREATE TABLE location_current (
                id INTEGER PRIMARY KEY,
                latitude REAL, longitude REAL, altitude REAL, accuracy REAL,
                address TEXT, accuracy_mode TEXT,
                recorded_at TEXT, updated_at TEXT
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE location_history (
                source_event_id TEXT PRIMARY KEY,
                latitude REAL, longitude REAL, altitude REAL, accuracy REAL,
                address TEXT, accuracy_mode TEXT,
                recorded_at TEXT
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE health_samples (
                metric TEXT NOT NULL, value REAL NOT NULL, unit TEXT NOT NULL,
                start_at TEXT NOT NULL, end_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE health_latest (
                metric TEXT NOT NULL, value REAL NOT NULL, unit TEXT NOT NULL,
                recorded_at TEXT NOT NULL, updated_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE health_daily (
                metric TEXT NOT NULL, date TEXT NOT NULL,
                aggregation_kind TEXT NOT NULL, unit TEXT NOT NULL,
                snapshot_value REAL, sum_value REAL, avg_value REAL,
                min_value REAL, max_value REAL, count INTEGER,
                recorded_at TEXT NOT NULL, updated_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE activity_samples (
                activity_code INTEGER NOT NULL,
                start_at TEXT NOT NULL, end_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE activity_current (
                id INTEGER PRIMARY KEY,
                activity_code INTEGER NOT NULL,
                start_at TEXT NOT NULL, end_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE workout_sessions (
                workout_id TEXT PRIMARY KEY,
                activity_type TEXT, activity_label TEXT,
                start_at TEXT NOT NULL, end_at TEXT,
                duration REAL, total_distance REAL, total_energy_burned REAL
            )
            """
        )
        return connection

    def _seed_full_data(self, connection: sqlite3.Connection) -> None:
        connection.execute(
            """
            INSERT INTO location_current (id, latitude, longitude, altitude,
                accuracy, address, recorded_at, updated_at)
            VALUES (1, 37.0, -122.0, 5.0, 10.0, '1 Apple Park Way',
                '2026-04-29T12:00:00Z', '2026-04-29T12:00:00Z')
            """
        )
        connection.execute(
            """
            INSERT INTO location_history (source_event_id, latitude, longitude,
                altitude, accuracy, address, recorded_at)
            VALUES ('evt-1', 37.0, -122.0, 5.0, 10.0, '1 Apple Park Way',
                '2026-04-29T11:00:00Z')
            """
        )
        connection.execute(
            """
            INSERT INTO health_samples (metric, value, unit, start_at, end_at)
            VALUES ('heart_rate', 72.0, 'count/min',
                '2026-04-29T12:00:00Z', '2026-04-29T12:00:01Z')
            """
        )
        connection.execute(
            """
            INSERT INTO health_latest (metric, value, unit, recorded_at, updated_at)
            VALUES ('heart_rate', 72.0, 'count/min',
                '2026-04-29T12:00:00Z', '2026-04-29T12:00:00Z')
            """
        )
        connection.execute(
            """
            INSERT INTO health_daily (metric, date, aggregation_kind, unit,
                snapshot_value, recorded_at, updated_at)
            VALUES ('stand_hours', '2026-04-29', 'snapshot', 'hours',
                10.0, '2026-04-29T23:59:59Z', '2026-04-29T23:59:59Z')
            """
        )
        connection.execute(
            """
            INSERT INTO activity_samples (activity_code, start_at, end_at)
            VALUES (1, '2026-04-29T11:00:00Z', '2026-04-29T11:30:00Z')
            """
        )
        connection.execute(
            """
            INSERT INTO activity_current (id, activity_code, start_at, end_at,
                updated_at)
            VALUES (1, 1, '2026-04-29T11:00:00Z', '2026-04-29T11:30:00Z',
                '2026-04-29T11:30:00Z')
            """
        )
        connection.execute(
            """
            INSERT INTO workout_sessions (workout_id, activity_type,
                activity_label, start_at, end_at, duration,
                total_distance, total_energy_burned)
            VALUES ('w1', 'running', 'Running',
                '2026-04-29T07:00:00Z', '2026-04-29T07:30:00Z',
                1800.0, 5000.0, 350.0)
            """
        )

    def _store_populated(self, tmp: str) -> SomaStore:
        db_path = Path(tmp) / "sensors.db"
        with closing(self._create_full_schema(db_path)) as connection, connection:
            self._seed_full_data(connection)
        return SomaStore(db_path)

    def _store_empty_schema(self, tmp: str) -> SomaStore:
        db_path = Path(tmp) / "sensors.db"
        with closing(self._create_full_schema(db_path)) as connection, connection:
            pass
        return SomaStore(db_path)

    def _store_no_tables(self, tmp: str) -> SomaStore:
        # DB file exists but no schema — this is the fresh-pair regression
        # that B6 translates at the server wrapper layer.
        db_path = Path(tmp) / "sensors.db"
        with closing(sqlite3.connect(db_path)):
            pass
        return SomaStore(db_path)

    # ---- get_user_location ----

    def test_get_user_location_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            row = store.get_user_location()
            self.assertEqual(row["latitude"], 37.0)
            self.assertEqual(row["longitude"], -122.0)
            self.assertIn("age_seconds", row)
            self.assertIn("ageSeconds", row)
            self.assertIn("accuracyMode", row)
            self.assertIn("stale", row)

    def test_get_user_location_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_empty_schema(tmp)
            row = store.get_user_location()
            self.assertEqual(row["status"], "unavailable")
            self.assertIn("database", row)

    def test_get_user_location_missing_tables_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_no_tables(tmp)
            with self.assertRaises(sqlite3.OperationalError) as ctx:
                store.get_user_location()
            self.assertIn("no such table", str(ctx.exception).lower())

    # ---- get_location_history ----

    def test_get_location_history_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            rows = store.get_location_history()
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["source_event_id"], "evt-1")
            self.assertIn("age_seconds", rows[0])

    def test_get_location_history_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_empty_schema(tmp)
            self.assertEqual(store.get_location_history(), [])

    def test_get_location_history_missing_tables_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_no_tables(tmp)
            with self.assertRaises(sqlite3.OperationalError):
                store.get_location_history()

    # ---- get_health_summary ----

    def test_get_health_summary_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            summary = store.get_health_summary()
            self.assertIn("latest_metrics", summary)
            self.assertIn("latestMetrics", summary)
            self.assertIn("activity", summary)
            self.assertIn("database", summary)
            self.assertTrue(summary["database"]["exists"])
            self.assertTrue(any(m["metric"] == "heart_rate" for m in summary["latest_metrics"]))
            self.assertEqual(summary["latestMetrics"], summary["latest_metrics"])

    def test_get_health_summary_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_empty_schema(tmp)
            summary = store.get_health_summary()
            self.assertEqual(summary["latest_metrics"], [])
            self.assertEqual(summary["activity"]["status"], "unavailable")

    def test_get_health_summary_missing_tables_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_no_tables(tmp)
            with self.assertRaises(sqlite3.OperationalError):
                store.get_health_summary()

    # ---- get_health_metric ----

    def test_get_health_metric_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            rows = store.get_health_metric("heart_rate")
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["metric"], "heart_rate")
            self.assertEqual(rows[0]["value"], 72.0)
            self.assertIn("age_seconds", rows[0])

    def test_get_health_metric_daily_snapshot_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            rows = store.get_health_metric("stand_hours")
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["metric"], "stand_hours")
            self.assertEqual(rows[0]["value"], 10.0)

    def test_get_health_metric_activity_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            rows = store.get_health_metric("user_activity")
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["activity_code"], 1)
            self.assertEqual(rows[0]["activity_label"], "Walking")

    def test_get_health_metric_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_empty_schema(tmp)
            self.assertEqual(store.get_health_metric("heart_rate"), [])

    def test_get_health_metric_missing_tables_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_no_tables(tmp)
            with self.assertRaises(sqlite3.OperationalError):
                store.get_health_metric("heart_rate")

    # ---- get_health_metrics_list ----

    def test_get_health_metrics_list_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            rows = store.get_health_metrics_list()
            kinds = {row["kind"] for row in rows}
            # Mix of sample and dailySnapshot
            self.assertIn("sampleEvent", kinds)
            self.assertIn("dailySnapshot", kinds)
            for row in rows:
                self.assertIn("metric", row)
                self.assertIn("kind", row)
                self.assertIn("age_seconds", row)

    def test_get_health_metrics_list_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_empty_schema(tmp)
            self.assertEqual(store.get_health_metrics_list(), [])

    def test_get_health_metrics_list_missing_tables_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_no_tables(tmp)
            with self.assertRaises(sqlite3.OperationalError):
                store.get_health_metrics_list()

    # ---- get_user_activity ----

    def test_get_user_activity_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            row = store.get_user_activity()
            self.assertEqual(row["activity_code"], 1)
            self.assertEqual(row["activityCode"], 1)
            self.assertEqual(row["activity_label"], "Walking")
            self.assertEqual(row["activityLabel"], "Walking")
            self.assertIn("age_seconds", row)
            self.assertIn("ageSeconds", row)

    def test_get_user_activity_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_empty_schema(tmp)
            row = store.get_user_activity()
            self.assertEqual(row["status"], "unavailable")

    def test_get_user_activity_missing_tables_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_no_tables(tmp)
            with self.assertRaises(sqlite3.OperationalError):
                store.get_user_activity()

    # ---- get_daily_summary ----

    def test_get_daily_summary_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            summary = store.get_daily_summary("2026-04-29")
            self.assertEqual(summary["date"], "2026-04-29")
            self.assertIn("metrics", summary)
            self.assertEqual(len(summary["metrics"]), 1)
            self.assertEqual(summary["metrics"][0]["metric"], "stand_hours")
            self.assertIn("aggregationKind", summary["metrics"][0])
            self.assertIn("snapshotValue", summary["metrics"][0])

    def test_get_daily_summary_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_empty_schema(tmp)
            summary = store.get_daily_summary("2026-04-29")
            self.assertEqual(summary["metrics"], [])

    def test_get_daily_summary_missing_tables_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_no_tables(tmp)
            with self.assertRaises(sqlite3.OperationalError):
                store.get_daily_summary("2026-04-29")

    # ---- get_workouts ----

    def test_get_workouts_nominal_shape(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_populated(tmp)
            rows = store.get_workouts()
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["workout_id"], "w1")
            self.assertEqual(rows[0]["activity_type"], "running")
            self.assertEqual(rows[0]["duration"], 1800.0)
            self.assertIn("age_seconds", rows[0])

    def test_get_workouts_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_empty_schema(tmp)
            self.assertEqual(store.get_workouts(), [])

    def test_get_workouts_no_table_returns_empty(self) -> None:
        # Existing graceful-fallback contract: get_workouts checks
        # `_table_exists` and returns [] when workout_sessions is missing.
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_no_tables(tmp)
            self.assertEqual(store.get_workouts(), [])


class LocationAccuracyModeTests(unittest.TestCase):
    """C16: MCP must surface `accuracy_mode` (precise vs reduced) so agents
    can tell a real ~5m fix apart from a ~5km fuzzed neighborhood when the
    user granted Approximate Location. Without this, `accuracy: 65.0`
    looks like high precision regardless of what iOS actually delivered.
    """

    def _store_with_location(self, tmp: str, accuracy_mode: str | None) -> SomaStore:
        db_path = Path(tmp) / "sensors.db"
        with closing(sqlite3.connect(db_path)) as connection, connection:
            connection.execute(
                """
                CREATE TABLE location_current (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    latitude REAL NOT NULL,
                    longitude REAL NOT NULL,
                    altitude REAL,
                    accuracy REAL,
                    address TEXT,
                    accuracy_mode TEXT,
                    recorded_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE location_history (
                    source_event_id TEXT PRIMARY KEY,
                    latitude REAL NOT NULL,
                    longitude REAL NOT NULL,
                    altitude REAL,
                    accuracy REAL,
                    address TEXT,
                    accuracy_mode TEXT,
                    recorded_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                INSERT INTO location_current
                    (id, latitude, longitude, accuracy, accuracy_mode, recorded_at, updated_at)
                VALUES (1, 37.3349, -122.0090, 65.0, ?, '2026-04-22T10:00:00Z', '2026-04-22T10:00:00Z')
                """,
                (accuracy_mode,),
            )
            connection.execute(
                """
                INSERT INTO location_history
                    (source_event_id, latitude, longitude, accuracy, accuracy_mode, recorded_at)
                VALUES ('loc-1', 37.3349, -122.0090, 65.0, ?, '2026-04-22T10:00:00Z')
                """,
                (accuracy_mode,),
            )
        return SomaStore(db_path)

    def test_get_user_location_includes_reduced_accuracy_mode(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_location(tmp, accuracy_mode="reduced")
            row = store.get_user_location()
            self.assertEqual(row["accuracy_mode"], "reduced")
            # `accuracy` is still the reported point's horizontal accuracy
            # — the fuzzed value's tightness — but the new field tells
            # the agent the precision is semantically ~5km.
            self.assertEqual(row["accuracy"], 65.0)

    def test_get_user_location_includes_precise_accuracy_mode(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_location(tmp, accuracy_mode="precise")
            row = store.get_user_location()
            self.assertEqual(row["accuracy_mode"], "precise")

    def test_get_location_history_includes_accuracy_mode(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = self._store_with_location(tmp, accuracy_mode="reduced")
            rows = store.get_location_history()
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["accuracy_mode"], "reduced")


class StorePathTests(unittest.TestCase):
    def test_database_status_uses_canonical_db_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            real_dir = tmp_path / "real"
            real_dir.mkdir()
            real_db_path = real_dir / "sensors.db"
            with closing(sqlite3.connect(real_db_path)):
                pass

            link_dir = tmp_path / "links"
            link_dir.mkdir()
            symlink_db_path = link_dir / "sensors-link.db"
            symlink_db_path.symlink_to(real_db_path)

            store = SomaStore(symlink_db_path)

            self.assertEqual(store.database_status()["path"], str(real_db_path.resolve()))
            self.assertTrue(store.database_status()["exists"])


class ServerWrapperErrorTranslationTests(unittest.TestCase):
    """Codex P2: `run_with_agent_access` translated `OperationalError: no such
    column` into `_unavailable()` for ALL tools — including raw-SQL
    `query_sensor_data`. Agents typo-ing column names got `[]` instead of a
    real "no such column" diagnostic, hiding query bugs.

    Typed tools (get_user_location etc.) still rely on the translation for
    fresh-pair / schema-mismatch graceful fallback. `query_sensor_data`
    must let SQLite errors bubble up as `ValueError("SQLite query
    failed: ...")` so agents see the real diagnostic.
    """

    def _setup_replica(self, tmp: str, *, agent_access: bool = True) -> Path:
        """Create a sensors.db with the full schema + access.json so the
        agent-access gate passes. Returns the db_path used by build_server.
        """
        db_path = Path(tmp) / "sensors.db"
        with closing(sqlite3.connect(db_path)) as connection, connection:
            connection.execute(
                """
                CREATE TABLE location_history (
                    source_event_id TEXT PRIMARY KEY,
                    latitude REAL, longitude REAL, altitude REAL, accuracy REAL,
                    address TEXT, accuracy_mode TEXT,
                    recorded_at TEXT
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE health_samples (
                    metric TEXT NOT NULL, value REAL NOT NULL, unit TEXT NOT NULL,
                    start_at TEXT NOT NULL, end_at TEXT NOT NULL
                )
                """
            )
        access_path = Path(tmp) / "access.json"
        access_path.write_text(
            json.dumps(
                {
                    "agent_access_enabled": agent_access,
                    "updated_at": "2026-04-19T00:00:00Z",
                }
            ),
            encoding="utf-8",
        )
        return db_path

    def _query_sensor_data_fn(self, db_path: Path):
        """Resolve the registered `query_sensor_data` tool's underlying
        Python function, bypassing the FastMCP serialization layer so we
        can assert directly on the raised `ValueError`.
        """
        from soma_mcp.server import build_server

        server = build_server(db_path)
        # FastMCP exposes registered tools via `get_tool`; `.fn` is the
        # original Python callable wrapped by `run_with_agent_access`.
        tool = asyncio.run(server.get_tool("query_sensor_data"))
        return tool.fn

    def _typed_tool_fn(self, db_path: Path, name: str):
        from soma_mcp.server import build_server

        server = build_server(db_path)
        tool = asyncio.run(server.get_tool(name))
        return tool.fn

    def test_query_sensor_data_no_such_column_surfaces_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = self._setup_replica(tmp)
            query_sensor_data = self._query_sensor_data_fn(db_path)

            with self.assertRaisesRegex(ValueError, "no such column"):
                query_sensor_data(
                    sql="SELECT bad_column FROM location_history"
                )

    def test_query_sensor_data_no_such_table_surfaces_error(self) -> None:
        # Typo in the table name slips past the early-reject regex (it's
        # an allowlisted-shape table name, just not present in the DB).
        # The SQLite error must reach the agent rather than a silent [].
        with tempfile.TemporaryDirectory() as tmp:
            db_path = self._setup_replica(tmp)
            # Drop one of the allowlisted tables so a query against it
            # fails with "no such table" — but the early-reject parser
            # still admits it because the name is on the allowlist.
            query_sensor_data = self._query_sensor_data_fn(db_path)

            with self.assertRaisesRegex(ValueError, "no such table"):
                # health_latest is allowlisted but never created above.
                query_sensor_data(
                    sql="SELECT * FROM health_latest"
                )

    def test_query_sensor_data_succeeds_on_valid_query(self) -> None:
        # Sanity: a valid query must still return rows (no false-positive
        # ValueError from the new error-translation path).
        with tempfile.TemporaryDirectory() as tmp:
            db_path = self._setup_replica(tmp)
            with closing(sqlite3.connect(db_path)) as conn, conn:
                conn.execute(
                    """
                    INSERT INTO health_samples (metric, value, unit, start_at, end_at)
                    VALUES ('heart_rate', 72.0, 'count/min',
                        '2026-04-29T12:00:00Z', '2026-04-29T12:00:01Z')
                    """
                )
            query_sensor_data = self._query_sensor_data_fn(db_path)

            rows = query_sensor_data(
                sql="SELECT metric, value FROM health_samples"
            )

            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["metric"], "heart_rate")

    def test_tool_checks_agent_access_on_every_call(self) -> None:
        # Build the server while Agent Access is enabled, then flip the
        # consent file off before invoking the tool. The call must fail
        # closed, proving the server does not cache the enabled state.
        with tempfile.TemporaryDirectory() as tmp:
            db_path = self._setup_replica(tmp, agent_access=True)
            query_sensor_data = self._query_sensor_data_fn(db_path)
            Path(tmp, "access.json").write_text(
                json.dumps(
                    {
                        "agent_access_enabled": False,
                        "updated_at": "2026-04-19T00:00:01Z",
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(Exception, "Agent Access is disabled"):
                query_sensor_data(sql="SELECT metric FROM health_samples")

    def test_typed_tool_missing_table_returns_unavailable_envelope(self) -> None:
        # The typed-tool translation must remain intact: a fresh-pair DB
        # (file exists but tables are missing) should produce the
        # graceful `_unavailable()` envelope, not a raw OperationalError.
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            with closing(sqlite3.connect(db_path)):
                pass  # DB file exists, no tables.
            access_path = Path(tmp) / "access.json"
            access_path.write_text(
                json.dumps(
                    {
                        "agent_access_enabled": True,
                        "updated_at": "2026-04-19T00:00:00Z",
                    }
                ),
                encoding="utf-8",
            )
            get_user_location = self._typed_tool_fn(db_path, "get_user_location")

            result = get_user_location()

            self.assertEqual(result["status"], "unavailable")
            self.assertIn("database", result)

    def test_typed_list_tool_missing_table_returns_empty_list(self) -> None:
        # List-shaped typed tools should still degrade to [] on missing
        # tables (so agents can iterate without a None-check).
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            with closing(sqlite3.connect(db_path)):
                pass
            access_path = Path(tmp) / "access.json"
            access_path.write_text(
                json.dumps(
                    {
                        "agent_access_enabled": True,
                        "updated_at": "2026-04-19T00:00:00Z",
                    }
                ),
                encoding="utf-8",
            )
            get_location_history = self._typed_tool_fn(
                db_path, "get_location_history"
            )

            result = get_location_history()

            self.assertEqual(result, [])


if __name__ == "__main__":
    unittest.main()
