from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from soma_mcp.access import AgentAccessDisabledError, AgentAccessGate


class AgentAccessGateTests(unittest.TestCase):
    def test_missing_access_file_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            gate = AgentAccessGate(db_path)

            self.assertFalse(gate.is_enabled())
            with self.assertRaises(AgentAccessDisabledError):
                gate.ensure_enabled()

    def test_explicit_false_disables_access(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            access_path = Path(tmp) / "access.json"
            access_path.write_text(
                json.dumps(
                    {
                        "agent_access_enabled": False,
                        "updated_at": "2026-04-19T00:00:00Z",
                    }
                ),
                encoding="utf-8",
            )

            gate = AgentAccessGate(db_path)

            self.assertFalse(gate.is_enabled())
            with self.assertRaises(AgentAccessDisabledError) as ctx:
                gate.ensure_enabled()
            self.assertIn("Open Soma Mac", str(ctx.exception))
            self.assertIn("Agent Access", str(ctx.exception))

    def test_enabled_requires_valid_updated_at(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            access_path = Path(tmp) / "access.json"

            access_path.write_text(
                json.dumps({"agent_access_enabled": True}),
                encoding="utf-8",
            )
            self.assertFalse(AgentAccessGate(db_path).is_enabled())

            access_path.write_text(
                json.dumps(
                    {
                        "agent_access_enabled": True,
                        "updated_at": "not-a-date",
                    }
                ),
                encoding="utf-8",
            )
            self.assertFalse(AgentAccessGate(db_path).is_enabled())

    def test_enabled_with_timestamp_allows_access(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            access_path = Path(tmp) / "access.json"
            access_path.write_text(
                json.dumps(
                    {
                        "agent_access_enabled": True,
                        "updated_at": "2026-04-19T00:00:00Z",
                    }
                ),
                encoding="utf-8",
            )

            gate = AgentAccessGate(db_path)

            self.assertTrue(gate.is_enabled())
            gate.ensure_enabled()

    def test_malformed_file_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            access_path = Path(tmp) / "access.json"
            access_path.write_text("{not valid json", encoding="utf-8")

            gate = AgentAccessGate(db_path)

            self.assertFalse(gate.is_enabled())
            with self.assertRaises(AgentAccessDisabledError):
                gate.ensure_enabled()

    def test_unreadable_file_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sensors.db"
            access_path = Path(tmp) / "access.json"
            access_path.write_text(
                json.dumps({"agent_access_enabled": True}),
                encoding="utf-8",
            )
            gate = AgentAccessGate(db_path)

            with patch.object(Path, "read_text", side_effect=PermissionError("denied")):
                self.assertFalse(gate.is_enabled())
                with self.assertRaises(AgentAccessDisabledError):
                    gate.ensure_enabled()

    def test_symlinked_db_uses_canonical_access_file_location(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            real_dir = tmp_path / "real"
            real_dir.mkdir()
            real_db_path = real_dir / "sensors.db"
            real_db_path.touch()
            (real_dir / "access.json").write_text(
                json.dumps({"agent_access_enabled": False}),
                encoding="utf-8",
            )

            link_dir = tmp_path / "links"
            link_dir.mkdir()
            (link_dir / "access.json").write_text(
                json.dumps(
                    {
                        "agent_access_enabled": True,
                        "updated_at": "2026-04-19T00:00:00Z",
                    }
                ),
                encoding="utf-8",
            )
            symlink_db_path = link_dir / "sensors-link.db"
            symlink_db_path.symlink_to(real_db_path)

            gate = AgentAccessGate(symlink_db_path)

            self.assertFalse(gate.is_enabled())
            with self.assertRaises(AgentAccessDisabledError):
                gate.ensure_enabled()


if __name__ == "__main__":
    unittest.main()
