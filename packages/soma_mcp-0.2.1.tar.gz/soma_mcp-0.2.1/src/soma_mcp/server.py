from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

from . import __version__
from .access import AgentAccessGate
from .store import SomaStore

# sqlite3 error fragments that indicate the local replica isn't ready or
# is unreadable rather than an agent SQL bug. These are translated to the
# graceful "unavailable" envelope so MCP clients don't see raw Python
# tracebacks. Match is case-insensitive against str(exc).
_DB_UNAVAILABLE_FRAGMENTS = (
    "no such table",
    "no such column",
    "unable to open database file",
    "file is not a database",
    "file is encrypted",
    "database disk image is malformed",
    "database is locked",
)


def _is_db_unavailable_error(exc: sqlite3.Error) -> bool:
    message = str(exc).lower()
    return any(fragment in message for fragment in _DB_UNAVAILABLE_FRAGMENTS)

try:
    from fastmcp import FastMCP
except ImportError as exc:  # pragma: no cover - import guard for local bootstrap
    FastMCP = None
    FASTMCP_IMPORT_ERROR = exc
else:
    FASTMCP_IMPORT_ERROR = None

# MCP tool annotations for read-only, idempotent sensor queries.
# Tells MCP clients these tools are safe to call without confirmation prompts.
_READ_ONLY = {"readOnlyHint": True, "idempotentHint": True, "openWorldHint": False}


def build_server(db_path: str | Path):
    if FastMCP is None:
        raise RuntimeError(
            "fastmcp is required to run soma-mcp. Install dependencies with `pip install -e .`."
        ) from FASTMCP_IMPORT_ERROR

    store = SomaStore(db_path)
    access_gate = AgentAccessGate(db_path)
    mcp = FastMCP(
        "soma",
        version=__version__,
        instructions=(
            "Soma provides real-time Apple Health, Location, and Activity data "
            "from the user's iPhone via a local SQLite replica. Use get_health_summary() "
            "for a quick overview, get_user_location() for current position, and "
            "get_health_metric() for historical data. All timestamps are ISO8601. "
            "Every response includes age_seconds and stale fields for freshness."
        ),
    )

    def run_with_agent_access(
        query_fn,
        *args,
        empty_shape: str = "dict",
        translate_unavailable: bool = True,
        **kwargs,
    ):
        """Run a Store query under the agent-access gate.

        Translates the "DB exists but tables are missing / unreadable" class
        of `sqlite3.OperationalError` and `sqlite3.DatabaseError` into the
        same graceful envelope the typed tools already use when the DB file
        is missing entirely. Without this translation, agents see raw
        Python error strings (`OperationalError: no such table: ...`) on
        a fresh-pair / corrupt-DB / permission-denied scenario.

        `empty_shape` controls the fallback envelope:
            - "dict": `{"status": "unavailable", ...}` — for tools that
              return a single dict.
            - "list": `[]` — for tools that return a list (so agents can
              iterate without a None-check).

        `translate_unavailable` controls whether sqlite3 errors get
        translated to `_unavailable()` envelopes. Typed tools default to
        True (fresh-pair / schema-mismatch → graceful response). Raw-SQL
        tools like `query_sensor_data` pass False so agents see real
        SQLite diagnostics ("no such column: bad_column") for typo'd
        queries instead of an empty-result false negative. Genuine
        unavailability (missing DB file, corrupt file) is still handled
        because `SomaStore._query` short-circuits to `[]` when the file
        doesn't exist before any sqlite3 call.
        """
        access_gate.ensure_enabled()
        try:
            return query_fn(*args, **kwargs)
        except (sqlite3.OperationalError, sqlite3.DatabaseError) as exc:
            if not translate_unavailable:
                # Raw-SQL path: surface SQLite diagnostics as a ValueError
                # so MCP clients see "no such column: foo" rather than a
                # Python traceback or, worse, an empty-result false
                # negative.
                raise ValueError(f"SQLite query failed: {exc}") from exc
            if not _is_db_unavailable_error(exc):
                raise
            if empty_shape == "list":
                return []
            return store._unavailable(
                "The local sensor replica isn't ready yet. "
                "Open Soma Mac to finish setup or wait for the next sync."
            )

    @mcp.tool(annotations=_READ_ONLY)
    def get_user_location() -> dict:
        """Return the latest replicated location projection with freshness metadata.

        The result includes coordinates, optional address fields, and freshness keys such as
        `age_seconds` and `stale`. Timestamp fields are ISO8601 strings.
        """
        return run_with_agent_access(store.get_user_location)

    @mcp.tool(annotations=_READ_ONLY)
    def get_location_history(since: str | None = None, limit: int = 100) -> list[dict]:
        """Return replicated location history ordered by newest first.

        `since` must be an ISO8601 timestamp and filters on `recorded_at >= since`.
        `limit` is clamped to 1...500. Each row includes freshness metadata.
        """
        return run_with_agent_access(
            store.get_location_history, since=since, limit=limit, empty_shape="list"
        )

    @mcp.tool(annotations=_READ_ONLY)
    def get_health_summary() -> dict:
        """Return the current high-value health context for agent tasks.

        The payload includes latest sample metrics, today's replicated daily snapshots,
        current activity, and local database status. Timestamps are ISO8601 strings.
        """
        return run_with_agent_access(store.get_health_summary)

    @mcp.tool(annotations=_READ_ONLY)
    def get_health_metric(metric: str, since: str | None = None, limit: int = 100) -> list[dict]:
        """Return history for one metric using metric-aware semantics.

        Daily snapshot metrics return one row per day from `health_daily`. Sample metrics return
        event history from `health_samples`. `user_activity` returns rows from `activity_samples`.
        `since` accepts an ISO8601 timestamp for event metrics or an ISO8601 date for daily
        snapshots. `limit` is clamped to 1...500.
        """
        return run_with_agent_access(
            store.get_health_metric,
            metric=metric,
            since=since,
            limit=limit,
            empty_shape="list",
        )

    @mcp.tool(annotations=_READ_ONLY)
    def get_health_metrics_list() -> list[dict]:
        """Return the available replicated metrics, kinds, and their latest values.

        The response mixes latest sample metrics and today's daily snapshots, each annotated with
        freshness metadata so agents can decide whether the data is recent enough.
        """
        return run_with_agent_access(store.get_health_metrics_list, empty_shape="list")

    @mcp.tool(annotations=_READ_ONLY)
    def get_user_activity() -> dict:
        """Return the latest replicated motion/activity projection with freshness metadata.

        The response includes `activity_code`, a human-readable `activity_label`, and ISO8601
        start/end timestamps for the current activity interval.
        """
        return run_with_agent_access(store.get_user_activity)

    @mcp.tool(annotations=_READ_ONLY)
    def get_daily_summary(date: str | None = None) -> dict:
        """Return one day's replicated health rollup.

        `date` must be an ISO8601 date (`YYYY-MM-DD`) and defaults to today in the host locale.
        The response includes cumulative daily snapshots and derived sample-stat aggregates for that
        day, each with freshness metadata.
        """
        return run_with_agent_access(store.get_daily_summary, date=date)

    @mcp.tool(annotations=_READ_ONLY)
    def get_workouts(since: str | None = None, limit: int = 50) -> list[dict]:
        """Return workout session history ordered by newest first.

        Each workout includes activity type/label, start/end timestamps, duration in seconds,
        total distance in meters, and total energy burned in kcal. `since` accepts an ISO8601
        timestamp. `limit` is clamped to 1...500.
        """
        return run_with_agent_access(
            store.get_workouts, since=since, limit=limit, empty_shape="list"
        )

    @mcp.tool(annotations=_READ_ONLY)
    def query_sensor_data(sql: str, limit: int = 100) -> list[dict]:
        """Run a single read-only SQL query against the local Soma SQLite replica.

        Only one SELECT or WITH statement is allowed. Mutating SQL is rejected. `limit` is
        clamped to 1...500 and appended to the query result set for safety.
        """
        return run_with_agent_access(
            store.query_sensor_data,
            sql=sql,
            limit=limit,
            empty_shape="list",
            translate_unavailable=False,
        )

    return mcp


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Soma MCP server.")
    parser.add_argument(
        "--db",
        default="~/.soma/sensors.db",
        help="Path to the local Soma SQLite replica.",
    )
    args = parser.parse_args()

    server = build_server(args.db)
    server.run()


if __name__ == "__main__":
    main()
