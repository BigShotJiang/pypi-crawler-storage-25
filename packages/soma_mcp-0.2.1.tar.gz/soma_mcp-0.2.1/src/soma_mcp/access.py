from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path


class AgentAccessDisabledError(PermissionError):
    """Raised when Soma Mac has disabled MCP access to the local replica."""


class AgentAccessGate:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path).expanduser().resolve()
        self.access_path = self.db_path.parent / "access.json"

    def is_enabled(self) -> bool:
        if not self.access_path.exists():
            return False

        try:
            payload = json.loads(self.access_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False

        if not isinstance(payload, dict):
            return False
        if payload.get("agent_access_enabled") is not True:
            return False

        updated_at = payload.get("updated_at")
        if not isinstance(updated_at, str):
            return False
        try:
            datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
        except ValueError:
            return False

        return True

    def ensure_enabled(self) -> None:
        if self.is_enabled():
            return

        raise AgentAccessDisabledError(
            "Agent Access is disabled in Soma Mac. Open Soma Mac, then use Settings "
            "or the menu-bar popover to turn Agent Access back on before using `soma-mcp`."
        )
