from __future__ import annotations

import datetime
import re
import sqlite3
import time
from contextlib import closing
from pathlib import Path
from typing import Any

# Keywords that must not appear in user-supplied SQL. `mode=ro` blocks writes
# but permits ATTACH (which would expose arbitrary filesystem reads), and
# PRAGMA/VACUUM/REINDEX are out-of-scope for a read-only query tool.
# Matching is word-boundary + case-insensitive to avoid false positives from
# substrings inside column names or string literals.
_FORBIDDEN_SQL_KEYWORDS = (
    "attach",
    "detach",
    r"pragma(?:_\w+)?",
    "vacuum",
    "reindex",
    "load_extension",
    "insert",
    "update",
    "delete",
    "drop",
    "create",
    "alter",
    "replace",
)
_FORBIDDEN_SQL_PATTERN = re.compile(
    r"\b(" + "|".join(_FORBIDDEN_SQL_KEYWORDS) + r")\b",
    re.IGNORECASE,
)

# Tables that `query_sensor_data` is allowed to read. The Mac SQLite replica
# also stores routing/sync metadata (`pairing_state`, `sync_state`,
# `used_pairing_ids`) that contains the user record name, CloudKit change
# tokens, and historical pairingId fingerprints. MCP is intended to expose
# sensor data only — the allowlist below mirrors the tables created in
# SomaMac/Storage/MacDatabaseMigrations.swift that hold sensor projections,
# raw events, and workout sessions.
_QUERY_SENSOR_DATA_ALLOWED_TABLES = frozenset({
    "location_current",
    "location_history",
    "health_samples",
    "health_latest",
    "health_daily",
    "health_hourly",
    "activity_samples",
    "activity_current",
    "workout_sessions",
})

# Keywords that terminate a FROM/JOIN table list. Once we see one of these
# (or end-of-statement) we know the table list is over.
_TABLE_LIST_TERMINATOR = re.compile(
    r"\b(where|group|having|order|limit|union|except|intersect|on|using|window|qualify)\b",
    re.IGNORECASE,
)

# Match a single table reference: optional schema-qualifier, optional
# quoted-identifier wrappers (double quote, backtick, square bracket).
# Returns the unqualified table name in group(2) when schema-qualified,
# otherwise group(1).
_TABLE_REF = re.compile(
    r"""
    [\"`\[]? (\w+) [\"`\]]?               # leading identifier (table or schema)
    (?: \s* \. \s* [\"`\[]? (\w+) [\"`\]]? )?   # optional `.table` after schema
    """,
    re.IGNORECASE | re.VERBOSE,
)

# If the user's SQL already contains a LIMIT keyword anywhere, we don't
# append our own — their explicit intent wins. This is conservative (a
# deeply-nested LIMIT in a subquery will also suppress the outer cap) but
# avoids the syntax errors from blind LIMIT concatenation.
_LIMIT_KEYWORD_PATTERN = re.compile(r"\blimit\b", re.IGNORECASE)
_QUERY_SENSOR_DATA_TIMEOUT_SECONDS = 2.0


def _referenced_tables(sql: str) -> set[str]:
    """Return the set of table names referenced by `sql` via FROM/JOIN.

    Operates on the keyword-only projection of the SQL (strings and comments
    blanked out) so identifiers that merely appear inside literals don't get
    mistaken for table references.

    Handles each of these surface forms:
      - `FROM table`
      - ``FROM "table"``, ``FROM `table` ``, ``FROM [table]``
      - `FROM schema.table` (returns `table`)
      - `FROM (table)`  -- leading parens around a name
      - `FROM (((t)))`  -- nested parens
      - `FROM a, b, c`  -- comma-joined table list
      - `FROM a JOIN b ON …` (each separately)

    Subqueries `FROM (SELECT … FROM x)` are caught by the recursive scan
    of the inner SELECT/FROM tokens — `x` is reported, the outer is not.

    This is a best-effort static parse used as an early-rejection hint.
    Authoritative enforcement happens via the SQLite authorizer in
    `_query` when `allowed_tables` is set, so any pattern this misses
    still falls into the authorizer's deny path.
    """
    code = _sql_code_only(sql)
    cte_names = _cte_aliases(code)
    tables: set[str] = set()
    keyword_pattern = re.compile(r"\b(?:from|join)\b", re.IGNORECASE)
    for keyword_match in keyword_pattern.finditer(code):
        pos = keyword_match.end()
        end = len(code)
        # Walk the comma-separated table list following FROM/JOIN.
        while pos < end:
            # Skip whitespace and any number of leading parens.
            while pos < end and code[pos] in " \t\n\r(":
                pos += 1
            if pos >= end:
                break
            # Stop at terminator keywords (WHERE/GROUP/HAVING/...).
            if _TABLE_LIST_TERMINATOR.match(code, pos):
                break
            # If the next token is a sub-SELECT, the inner FROM is
            # caught by the outer keyword_pattern iteration. Skip past
            # this paren group so we don't treat `SELECT` as a table.
            if code[pos:pos + 6].lower() == "select":
                break
            ref_match = _TABLE_REF.match(code, pos)
            if not ref_match:
                break
            # Use the qualified-table component if present, else the bare ident.
            ident = ref_match.group(2) or ref_match.group(1)
            ident = ident.lower()
            if ident not in cte_names:
                tables.add(ident)
            pos = ref_match.end()
            # Skip trailing whitespace, optional alias (AS x | x), and parens.
            while pos < end and code[pos] in " \t\n\r)":
                pos += 1
            # Optional `AS alias` or bare alias — consume a single ident.
            if pos < end and code[pos:pos + 3].lower() in ("as ", "as\t", "as\n"):
                pos += 2
                while pos < end and code[pos] in " \t\n\r":
                    pos += 1
            alias_match = re.match(r"\w+", code[pos:])
            if alias_match and not _TABLE_LIST_TERMINATOR.match(code, pos):
                # Could be alias or end-of-table-list keyword. If it's a
                # bare word that's not a known terminator, treat as alias
                # and skip.
                pos += alias_match.end()
            while pos < end and code[pos] in " \t\n\r)":
                pos += 1
            # Continue the table list across commas; otherwise stop.
            if pos < end and code[pos] == ",":
                pos += 1
                continue
            break
    return tables


def _cte_aliases(code: str) -> set[str]:
    """Return top-level CTE names from a leading WITH clause."""
    pos = 0
    end = len(code)
    while pos < end and code[pos] in " \t\n\r":
        pos += 1
    if code[pos:pos + 4].lower() != "with":
        return set()
    pos += 4
    aliases: set[str] = set()
    while pos < end:
        while pos < end and code[pos] in " \t\n\r,":
            pos += 1
        match = _TABLE_REF.match(code, pos)
        if not match:
            return aliases
        aliases.add((match.group(2) or match.group(1)).lower())
        pos = match.end()
        while pos < end and code[pos] in " \t\n\r":
            pos += 1
        if code[pos:pos + 3].lower() in ("as ", "as\t", "as\n"):
            pos += 2
        while pos < end and code[pos] in " \t\n\r":
            pos += 1
        if pos >= end or code[pos] != "(":
            return aliases
        depth = 0
        while pos < end:
            if code[pos] == "(":
                depth += 1
            elif code[pos] == ")":
                depth -= 1
                if depth == 0:
                    pos += 1
                    break
            pos += 1
        while pos < end and code[pos] in " \t\n\r":
            pos += 1
        if pos >= end or code[pos] != ",":
            return aliases


def _sql_code_only(sql: str) -> str:
    """Return SQL with single-quoted strings and comments blanked out."""
    chars: list[str] = []
    i = 0
    length = len(sql)
    while i < length:
        char = sql[i]
        next_char = sql[i + 1] if i + 1 < length else ""

        if char == "-" and next_char == "-":
            chars.extend("  ")
            i += 2
            while i < length and sql[i] not in "\r\n":
                chars.append(" ")
                i += 1
            continue

        if char == "/" and next_char == "*":
            chars.extend("  ")
            i += 2
            while i < length:
                if sql[i] == "*" and i + 1 < length and sql[i + 1] == "/":
                    chars.extend("  ")
                    i += 2
                    break
                chars.append("\n" if sql[i] in "\r\n" else " ")
                i += 1
            continue

        if char == "'":
            chars.append(" ")
            i += 1
            while i < length:
                if sql[i] == "'":
                    # SQL escape: '' inside a single-quoted string is a
                    # literal apostrophe, not a string terminator.
                    if i + 1 < length and sql[i + 1] == "'":
                        chars.extend("  ")
                        i += 2
                        continue
                    chars.append(" ")
                    i += 1
                    break
                chars.append("\n" if sql[i] in "\r\n" else " ")
                i += 1
            continue

        chars.append(char)
        i += 1

    return "".join(chars)


def _lower_camel_alias(snake_case: str) -> str:
    parts = snake_case.split("_")
    return parts[0] + "".join(part[:1].upper() + part[1:] for part in parts[1:])


def _with_legacy_camel_case_aliases(value: Any) -> Any:
    """Add deprecated 0.2.x lowerCamelCase aliases to typed MCP responses."""
    if isinstance(value, list):
        return [_with_legacy_camel_case_aliases(item) for item in value]
    if not isinstance(value, dict):
        return value

    for key, nested_value in list(value.items()):
        aliased_value = _with_legacy_camel_case_aliases(nested_value)
        value[key] = aliased_value
        if "_" in key:
            value.setdefault(_lower_camel_alias(key), aliased_value)
    return value

# Metric kind mapping matching SomaShared/HealthMetric.swift:
# 50 HealthKit metrics plus CoreMotion `user_activity`.
METRIC_KINDS: dict[str, str] = {
    # Hourly cumulative stats
    "steps": "hourlyStat",
    "active_calories": "hourlyStat",
    "basal_calories": "hourlyStat",
    "distance_walking": "hourlyStat",
    "distance_cycling": "hourlyStat",
    "distance_swimming": "hourlyStat",
    "workout_minutes": "hourlyStat",
    "flights_climbed": "hourlyStat",
    "dietary_energy": "hourlyStat",
    "dietary_water": "hourlyStat",
    "dietary_caffeine": "hourlyStat",
    "dietary_protein": "hourlyStat",
    "dietary_carbs": "hourlyStat",
    "dietary_fat": "hourlyStat",
    "dietary_fiber": "hourlyStat",
    "dietary_sugar": "hourlyStat",
    "dietary_sodium": "hourlyStat",
    # Daily snapshots (category-based)
    "stand_hours": "dailySnapshot",
    "sleep_duration": "dailySnapshot",
    # Sample events
    "heart_rate": "sampleEvent",
    "resting_heart_rate": "sampleEvent",
    "walking_heart_rate_avg": "sampleEvent",
    "blood_oxygen": "sampleEvent",
    "respiratory_rate": "sampleEvent",
    "body_mass": "sampleEvent",
    "body_fat_percentage": "sampleEvent",
    "bmi": "sampleEvent",
    "lean_body_mass": "sampleEvent",
    "height": "sampleEvent",
    "waist_circumference": "sampleEvent",
    "hrv": "sampleEvent",
    "vo2_max": "sampleEvent",
    "body_temperature": "sampleEvent",
    "wrist_temperature": "sampleEvent",
    "blood_pressure_systolic": "sampleEvent",
    "blood_pressure_diastolic": "sampleEvent",
    "blood_glucose": "sampleEvent",
    "environmental_audio": "sampleEvent",
    "walking_steadiness": "sampleEvent",
    # Category events
    "mindful_session": "categoryEvent",
    "low_heart_rate_event": "categoryEvent",
    "high_heart_rate_event": "categoryEvent",
    "irregular_rhythm_event": "categoryEvent",
    "headache": "categoryEvent",
    "fatigue": "categoryEvent",
    "nausea": "categoryEvent",
    "menstrual_flow": "categoryEvent",
    "cervical_mucus": "categoryEvent",
    "ovulation_test": "categoryEvent",
    "sexual_activity": "categoryEvent",
    # Activity
    "user_activity": "activityEvent",
}

# Staleness thresholds in seconds
STALE_THRESHOLDS: dict[str, int] = {
    "location": 600,
    "heart_rate": 600,
    "resting_heart_rate": 3600,
    "blood_oxygen": 3600,
    "respiratory_rate": 3600,
    "body_mass": 86400,
    "hrv": 3600,
    "vo2_max": 86400,
    "activity": 300,
    "dailySnapshot": 86400,
    "hourlyStat": 7200,
    "categoryEvent": 86400,
    "workout": 86400,
}

ACTIVITY_LABELS: dict[int, str] = {
    0: "Stationary",
    1: "Walking",
    2: "Running",
    3: "Automotive",
    4: "Cycling",
    5: "Unknown",
}

CATEGORY_VALUE_LABELS: dict[str, dict[int, str]] = {
    "headache": {
        0: "Unspecified",
        1: "Not Present",
        2: "Mild",
        3: "Moderate",
        4: "Severe",
    },
    "fatigue": {
        0: "Unspecified",
        1: "Not Present",
        2: "Mild",
        3: "Moderate",
        4: "Severe",
    },
    "nausea": {
        0: "Unspecified",
        1: "Not Present",
        2: "Mild",
        3: "Moderate",
        4: "Severe",
    },
    "menstrual_flow": {
        1: "Unspecified",
        2: "Light",
        3: "Medium",
        4: "Heavy",
        5: "None",
    },
    "cervical_mucus": {
        1: "Dry",
        2: "Sticky",
        3: "Creamy",
        4: "Watery",
        5: "Egg White",
    },
    "ovulation_test": {
        1: "Negative",
        2: "Luteinizing Hormone Surge",
        3: "Indeterminate",
        4: "Estrogen Surge",
    },
}

HOURLY_METRICS: tuple[str, ...] = tuple(
    metric for metric, kind in METRIC_KINDS.items() if kind == "hourlyStat"
)
DAILY_SNAPSHOT_METRICS: tuple[str, ...] = tuple(
    metric for metric, kind in METRIC_KINDS.items() if kind == "dailySnapshot"
)


class SomaStore:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path).expanduser().resolve()

    def database_status(self) -> dict[str, Any]:
        return {
            "path": str(self.db_path),
            "exists": self.db_path.exists(),
        }

    def get_user_location(self) -> dict[str, Any]:
        # `accuracy_mode` (C16) distinguishes a precise ~5m fix from a
        # ~5km fuzzed neighborhood when the user grants Approximate
        # Location. NULL on rows persisted before C16 — agents should
        # treat NULL as "unknown precision".
        sql = """
        SELECT
            latitude, longitude, altitude, accuracy, address,
            accuracy_mode, recorded_at, updated_at
        FROM location_current
        WHERE id = 1
        """
        rows = self._query(sql)
        if not rows:
            return self._unavailable("No replicated location is available yet.")
        row = rows[0]
        return self._add_freshness(row, "recorded_at", "location")

    def get_location_history(self, since: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        sql = """
        SELECT
            source_event_id, latitude, longitude, altitude, accuracy,
            address, accuracy_mode, recorded_at
        FROM location_history
        """
        params: list[Any] = []
        if since:
            sql += " WHERE recorded_at >= ?"
            params.append(since)
        sql += " ORDER BY recorded_at DESC"
        rows = self._query(sql, params=params, limit=limit)
        return [self._add_freshness(r, "recorded_at", "location") for r in rows]

    def get_health_metrics_list(self) -> list[dict[str, Any]]:
        # Sample metrics from health_latest
        sample_sql = """
        SELECT metric, value, unit, recorded_at, updated_at
        FROM health_latest
        ORDER BY metric ASC
        """
        sample_rows = self._query(sample_sql)

        # Most recent daily snapshot per metric
        snapshot_sql = """
        SELECT h.metric, h.date, h.snapshot_value as value, h.unit, h.recorded_at, h.updated_at
        FROM health_daily h
        INNER JOIN (
            SELECT metric, MAX(date) as max_date
            FROM health_daily
            WHERE aggregation_kind = 'snapshot' AND metric IN ({placeholders})
            GROUP BY metric
        ) latest ON h.metric = latest.metric AND h.date = latest.max_date
        WHERE h.aggregation_kind = 'snapshot' AND h.metric IN ({placeholders})
        ORDER BY h.metric ASC
        """
        snapshot_placeholders = ", ".join("?" for _ in DAILY_SNAPSHOT_METRICS)
        snapshot_rows = self._query(
            snapshot_sql.format(placeholders=snapshot_placeholders),
            params=list(DAILY_SNAPSHOT_METRICS) + list(DAILY_SNAPSHOT_METRICS),
        )

        hourly_rows = self._latest_hourly_metric_rows()

        results = []
        for row in sample_rows:
            metric_name = row.get("metric", "")
            kind = METRIC_KINDS.get(metric_name, "sampleEvent")
            row["kind"] = kind
            # Use kind for stale threshold lookup, fall back to metric name
            # for metrics with specific thresholds (heart_rate, body_mass, etc.)
            threshold_key = metric_name if metric_name in STALE_THRESHOLDS else kind
            row = self._annotate_metric_value(row)
            results.append(self._add_freshness(row, "recorded_at", threshold_key))
        for row in snapshot_rows:
            row["kind"] = "dailySnapshot"
            results.append(self._add_freshness(row, "recorded_at", "dailySnapshot"))
        for row in hourly_rows:
            row["kind"] = "hourlyStat"
            results.append(self._add_freshness(row, "recorded_at", "hourlyStat"))
        return results

    def get_health_metric(
        self,
        metric: str,
        since: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        kind = METRIC_KINDS.get(metric, "sampleEvent")

        if kind == "hourlyStat":
            rows = self._query_hourly_metric(metric=metric, since=since, limit=limit)
            return [self._add_freshness(r, "recorded_at", "hourlyStat") for r in rows]
        elif kind == "dailySnapshot":
            sql = """
            SELECT metric, date, snapshot_value as value, unit, recorded_at, updated_at
            FROM health_daily
            WHERE metric = ? AND aggregation_kind = 'snapshot'
            """
            params: list[Any] = [metric]
            if since:
                sql += " AND date >= ?"
                params.append(since)
            sql += " ORDER BY date DESC"
            rows = self._query(sql, params=params, limit=limit)
            return [self._add_freshness(r, "recorded_at", "dailySnapshot") for r in rows]
        elif kind == "activityEvent":
            sql = """
            SELECT activity_code, start_at, end_at
            FROM activity_samples
            """
            params = []
            if since:
                sql += " WHERE start_at >= ?"
                params.append(since)
            sql += " ORDER BY start_at DESC"
            rows = self._query(sql, params=params, limit=limit)
            results = []
            for row in rows:
                code = row.get("activity_code", 5)
                row["activity_label"] = ACTIVITY_LABELS.get(code, "Unknown")
                results.append(self._add_freshness(row, "start_at", "activity"))
            return results
        else:
            # Handles sampleEvent AND categoryEvent — both stored in health_samples.
            # Use kind for stale threshold when metric doesn't have its own entry.
            sql = """
            SELECT metric, value, unit, start_at, end_at
            FROM health_samples
            WHERE metric = ?
            """
            params = [metric]
            if since:
                sql += " AND start_at >= ?"
                params.append(since)
            sql += " ORDER BY start_at DESC"
            rows = self._query(sql, params=params, limit=limit)
            threshold_key = metric if metric in STALE_THRESHOLDS else kind
            return [
                self._add_freshness(self._annotate_metric_value(r), "start_at", threshold_key)
                for r in rows
            ]

    def get_health_summary(self) -> dict[str, Any]:
        metrics = self.get_health_metrics_list()
        return _with_legacy_camel_case_aliases({
            "latest_metrics": metrics,
            "activity": self.get_user_activity(),
            "database": self.database_status(),
        })

    def get_user_activity(self) -> dict[str, Any]:
        sql = """
        SELECT activity_code, start_at, end_at, updated_at
        FROM activity_current
        WHERE id = 1
        """
        rows = self._query(sql)
        if not rows:
            return self._unavailable("No activity projection is available yet.")
        row = rows[0]
        code = row.get("activity_code", 5)
        label = ACTIVITY_LABELS.get(code, "Unknown")
        row["activity_label"] = label
        return self._add_freshness(row, "start_at", "activity")

    def get_daily_summary(self, date: str | None = None) -> dict[str, Any]:
        if date is None:
            date = datetime.date.today().isoformat()

        base_sql = """
        SELECT
            metric, date, aggregation_kind, unit,
            snapshot_value, sum_value, avg_value, min_value, max_value,
            count, recorded_at, updated_at
        FROM health_daily
        WHERE date = ? AND metric NOT IN ({placeholders})
        ORDER BY metric ASC
        """
        hourly_placeholders = ", ".join("?" for _ in HOURLY_METRICS)
        metrics = self._query(
            base_sql.format(placeholders=hourly_placeholders),
            params=[date, *HOURLY_METRICS],
        )
        metrics.extend(self._daily_hourly_summary_rows(date))
        metrics.sort(key=lambda row: str(row.get("metric", "")))
        return _with_legacy_camel_case_aliases({
            "date": date,
            "metrics": [self._add_freshness(r, "recorded_at", "dailySnapshot") for r in metrics],
        })

    def get_workouts(self, since: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        if not self._table_exists("workout_sessions"):
            return []

        sql = """
        SELECT
            workout_id, activity_type, activity_label,
            start_at, end_at, duration,
            total_distance, total_energy_burned
        FROM workout_sessions
        """
        params: list[Any] = []
        if since:
            sql += " WHERE start_at >= ?"
            params.append(since)
        sql += " ORDER BY start_at DESC"
        rows = self._query(sql, params=params, limit=limit)
        return [self._add_freshness(r, "start_at", "workout") for r in rows]

    def query_sensor_data(self, sql: str, limit: int = 100) -> list[dict[str, Any]]:
        code_only = _sql_code_only(sql)
        normalized = code_only.strip().lower()
        if not normalized.startswith("select") and not normalized.startswith("with"):
            raise ValueError("Only read-only SELECT queries are allowed.")
        # Reject multi-statement SQL (defense in depth — sqlite3.execute already
        # rejects multiple statements, but this produces a clearer error).
        if ";" in normalized.rstrip(";"):
            raise ValueError("Only a single SQL statement is allowed.")
        # Reject keywords that bypass the read-only contract or reach into
        # other files/extensions even under `mode=ro`.
        match = _FORBIDDEN_SQL_PATTERN.search(code_only)
        if match:
            raise ValueError(
                f"Disallowed SQL keyword: {match.group(1).upper()}. "
                "query_sensor_data is limited to read-only SELECT / WITH statements "
                "against the current database."
            )
        # Restrict reads to sensor tables. The Mac replica also holds
        # routing/sync metadata (pairing_state, sync_state, used_pairing_ids)
        # that should never reach an MCP agent, even though the database is
        # opened read-only.
        referenced = _referenced_tables(sql)
        if not referenced:
            raise ValueError(
                "query_sensor_data must reference at least one allowed sensor table."
            )
        disallowed = referenced - _QUERY_SENSOR_DATA_ALLOWED_TABLES
        if disallowed:
            raise ValueError(
                "query_sensor_data may only read sensor tables. "
                f"Disallowed tables: {sorted(disallowed)}"
            )
        return self._query(
            sql,
            limit=limit,
            force_outer_limit=True,
            timeout_seconds=_QUERY_SENSOR_DATA_TIMEOUT_SECONDS,
            allowed_tables=_QUERY_SENSOR_DATA_ALLOWED_TABLES,
        )

    def _query(
        self,
        sql: str,
        params: list[Any] | None = None,
        limit: int | None = None,
        force_outer_limit: bool = False,
        timeout_seconds: float | None = None,
        allowed_tables: frozenset[str] | None = None,
    ) -> list[dict[str, Any]]:
        if not self.db_path.exists():
            return []

        statement = sql.strip().rstrip(";").rstrip()
        if limit is not None:
            clamped = max(1, min(int(limit), 500))
            if force_outer_limit:
                statement = f"SELECT * FROM ({statement})\nLIMIT {clamped}"
            elif not _LIMIT_KEYWORD_PATTERN.search(_sql_code_only(statement)):
                statement = f"{statement}\nLIMIT {clamped}"

        # `mode=ro` opens the main DB read-only. `PRAGMA query_only = ON` is
        # belt-and-suspenders: SQLite rejects any write attempt with
        # SQLITE_READONLY even if some future code path opened r/w by mistake.
        # Docs: https://www.sqlite.org/pragma.html#pragma_query_only
        # `mode=ro` opens the main DB read-only. Wrapping in `closing()` is
        # required for Python 3.12+: `with sqlite3.connect(...)` no longer
        # closes the connection on exit (it only commits/rollbacks), which
        # leaks one Connection per call and surfaces as `ResourceWarning:
        # unclosed database` under tests with -W error::ResourceWarning.
        uri = f"{self.db_path.as_uri()}?mode=ro"
        with closing(sqlite3.connect(uri, uri=True)) as connection:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA query_only = ON")
            if allowed_tables is not None:
                # The SQLite authorizer is the bulletproof table-allowlist:
                # it fires during statement preparation for every column
                # read on every table, including ones reached via parens
                # (`FROM (t)`), commas (`FROM a, b`), CTEs, schema-qualified
                # names, and any other surface form a regex would miss.
                # `arg1` is the table name for SQLITE_READ; `arg2` is the
                # column name.
                allowed_lower = {name.lower() for name in allowed_tables}
                blocked_table: list[str] = []

                def authorizer(action: int, arg1: str | None, arg2: str | None,
                               db_name: str | None, trigger: str | None) -> int:
                    if action == sqlite3.SQLITE_READ and arg1:
                        table = arg1.lower()
                        if table not in allowed_lower:
                            blocked_table.append(arg1)
                            return sqlite3.SQLITE_DENY
                    return sqlite3.SQLITE_OK

                connection.set_authorizer(authorizer)
            if timeout_seconds is not None:
                deadline = time.monotonic() + timeout_seconds

                def abort_if_timed_out() -> int:
                    return 1 if time.monotonic() > deadline else 0

                connection.set_progress_handler(abort_if_timed_out, 10_000)
            try:
                cursor = connection.execute(statement, params or [])
                return [dict(row) for row in cursor.fetchall()]
            except sqlite3.OperationalError as exc:
                message = str(exc).lower()
                # The 2-second progress-handler deadline aborts the query
                # via SQLITE_INTERRUPT, which surfaces as a bare
                # `OperationalError: interrupted`. Translate to a friendly
                # ValueError so agents can adjust their query.
                if timeout_seconds is not None and "interrupt" in message:
                    raise ValueError(
                        f"query_sensor_data exceeded the "
                        f"{timeout_seconds:.0f}-second time limit. "
                        "Add a more selective WHERE clause or a smaller LIMIT."
                    ) from exc
                # The authorizer's DENY also surfaces as an OperationalError
                # ("not authorized"). Re-raise as a ValueError that names the
                # disallowed table for symmetry with the early-reject path.
                if allowed_tables is not None and "not authorized" in message:
                    table_name = blocked_table[0] if blocked_table else "<unknown>"
                    raise ValueError(
                        "query_sensor_data may only read sensor tables. "
                        f"Disallowed tables: ['{table_name}']"
                    ) from exc
                raise
            except sqlite3.DatabaseError as exc:
                # Other DatabaseError variants (e.g. corrupted DB) flow up
                # to the tool wrapper, which translates them to graceful
                # `_unavailable()` responses for the typed tools.
                raise

    def _annotate_metric_value(self, row: dict[str, Any]) -> dict[str, Any]:
        metric_name = str(row.get("metric", ""))
        labels = CATEGORY_VALUE_LABELS.get(metric_name)
        if not labels:
            return row

        value = row.get("value")
        code: int | None = None
        if isinstance(value, int):
            code = value
        elif isinstance(value, float) and value.is_integer():
            code = int(value)
        elif isinstance(value, str):
            try:
                numeric = float(value)
            except ValueError:
                numeric = None
            if numeric is not None and numeric.is_integer():
                code = int(numeric)

        if code is not None and code in labels:
            row["value_label"] = labels[code]
        return row

    def _table_exists(self, table: str) -> bool:
        rows = self._query(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?",
            params=[table],
        )
        return bool(rows)

    def _latest_hourly_metric_rows(self) -> list[dict[str, Any]]:
        if self._table_exists("health_hourly"):
            sql = """
            SELECT metric, date, SUM(value) as value, unit, MAX(recorded_at) as recorded_at
            FROM health_hourly
            WHERE date = (SELECT MAX(date) FROM health_hourly h2 WHERE h2.metric = health_hourly.metric)
            GROUP BY metric
            ORDER BY metric ASC
            """
            return self._query(sql)

        placeholders = ", ".join("?" for _ in HOURLY_METRICS)
        sql = f"""
        SELECT h.metric, h.date, h.snapshot_value as value, h.unit, h.recorded_at
        FROM health_daily h
        INNER JOIN (
            SELECT metric, MAX(date) as max_date
            FROM health_daily
            WHERE aggregation_kind = 'snapshot' AND metric IN ({placeholders})
            GROUP BY metric
        ) latest ON h.metric = latest.metric AND h.date = latest.max_date
        WHERE h.aggregation_kind = 'snapshot' AND h.metric IN ({placeholders})
        ORDER BY h.metric ASC
        """
        return self._query(sql, params=list(HOURLY_METRICS) + list(HOURLY_METRICS))

    def _query_hourly_metric(
        self,
        metric: str,
        since: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        if self._table_exists("health_hourly"):
            sql = """
            SELECT metric, date, hour, value, unit, recorded_at
            FROM health_hourly
            WHERE metric = ?
            """
            params: list[Any] = [metric]
            if since:
                sql += " AND (date > ? OR (date = ? AND hour >= ?))"
                since_date = since[:10] if len(since) >= 10 else since
                since_hour = 0
                if len(since) >= 13 and since[10] == "T":
                    try:
                        since_hour = int(since[11:13])
                    except ValueError:
                        pass
                params.extend([since_date, since_date, since_hour])
            sql += " ORDER BY date DESC, hour DESC"
            return self._query(sql, params=params, limit=limit)

        sql = """
        SELECT metric, date, NULL as hour, snapshot_value as value, unit, recorded_at
        FROM health_daily
        WHERE metric = ? AND aggregation_kind = 'snapshot'
        """
        params = [metric]
        if since:
            sql += " AND date >= ?"
            params.append(since[:10] if len(since) >= 10 else since)
        sql += " ORDER BY date DESC"
        return self._query(sql, params=params, limit=limit)

    def _daily_hourly_summary_rows(self, date: str) -> list[dict[str, Any]]:
        if self._table_exists("health_hourly"):
            sql = """
            SELECT
                metric,
                date,
                'snapshot' as aggregation_kind,
                unit,
                SUM(value) as snapshot_value,
                NULL as sum_value,
                NULL as avg_value,
                NULL as min_value,
                NULL as max_value,
                COUNT(*) as count,
                MAX(recorded_at) as recorded_at,
                MAX(recorded_at) as updated_at
            FROM health_hourly
            WHERE date = ?
            GROUP BY metric, date, unit
            ORDER BY metric ASC
            """
            return self._query(sql, params=[date])

        placeholders = ", ".join("?" for _ in HOURLY_METRICS)
        sql = f"""
        SELECT
            metric, date, aggregation_kind, unit,
            snapshot_value, sum_value, avg_value, min_value, max_value,
            count, recorded_at, updated_at
        FROM health_daily
        WHERE date = ? AND aggregation_kind = 'snapshot' AND metric IN ({placeholders})
        ORDER BY metric ASC
        """
        return self._query(sql, params=[date, *HOURLY_METRICS])

    def _add_freshness(
        self, row: dict[str, Any], timestamp_key: str, metric_type: str
    ) -> dict[str, Any]:
        ts = row.get(timestamp_key)
        if ts and isinstance(ts, str):
            try:
                # Parse ISO8601 timestamp. SQLite 'now' is UTC, so treat
                # offset-less timestamps as UTC to avoid local-time skew.
                dt = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=datetime.timezone.utc)
                age = int(time.time() - dt.timestamp())
                threshold = STALE_THRESHOLDS.get(metric_type, 3600)
                row["age_seconds"] = age
                row["stale"] = age > threshold
            except (ValueError, TypeError):
                row["age_seconds"] = None
                row["stale"] = None
        else:
            row["age_seconds"] = None
            row["stale"] = None
        return _with_legacy_camel_case_aliases(row)

    def _unavailable(self, message: str) -> dict[str, Any]:
        return {
            "status": "unavailable",
            "message": message,
            "database": self.database_status(),
        }
