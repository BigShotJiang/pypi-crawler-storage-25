from __future__ import annotations

import json
import ssl
import time
from contextlib import contextmanager
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator
from urllib import request
from urllib.error import HTTPError, URLError

from .config import BUNDLED_CA_CERT_SENTINEL, AuthState, ConfigStore, env_auth_state, load_bundled_ca_cert

try:
    import fcntl
except ModuleNotFoundError:  # pragma: no cover
    fcntl = None  # type: ignore[assignment]


class SessionError(RuntimeError):
    """Raised when auth/session handling fails."""


class SessionManager:
    def __init__(
        self,
        store: ConfigStore,
        base_url: str | None,
        anon_key: str | None,
        *,
        tls_insecure: bool = False,
        ca_cert_file: str | None = None,
    ) -> None:
        self.store = store
        self.base_url = base_url
        self.anon_key = anon_key
        self.tls_insecure = tls_insecure
        self.ca_cert_file = ca_cert_file

    def _urlopen(self, req: request.Request):
        if self.tls_insecure:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            return request.urlopen(req, context=context)
        if self.ca_cert_file:
            if self.ca_cert_file == BUNDLED_CA_CERT_SENTINEL:
                bundled_ca_cert = load_bundled_ca_cert()
                if not bundled_ca_cert:
                    raise SessionError("Bundled test CA certificate is unavailable.")
                context = ssl.create_default_context(cadata=bundled_ca_cert)
            else:
                context = ssl.create_default_context(cafile=self.ca_cert_file)
            return request.urlopen(req, context=context)
        return request.urlopen(req)

    def get_auth_state(self) -> AuthState | None:
        return env_auth_state() or self.store.load_auth()

    def is_file_backed(self, auth: AuthState | None) -> bool:
        return bool(auth and auth.source != "env")

    def seconds_until_expiry(self, auth: AuthState | None) -> int | None:
        if not auth or auth.session.expires_at is None:
            return None
        return auth.session.expires_at - int(time.time())

    def ensure_valid(self, skew_seconds: int = 60) -> AuthState | None:
        auth = self.get_auth_state()
        if not auth:
            return None
        remaining = self.seconds_until_expiry(auth)
        if remaining is None or remaining > skew_seconds:
            return auth
        if not auth.session.refresh_token:
            return auth
        return self.refresh(auth)

    def refresh(self, auth: AuthState | None = None) -> AuthState:
        auth = auth or self.get_auth_state()
        if not auth:
            raise SessionError("No authentication session available.")
        if not auth.session.refresh_token:
            raise SessionError("Current session has no refresh token. Please log in again.")
        if not self.base_url or not self.anon_key:
            raise SessionError("base_url and anon_key are required to refresh the session.")

        payload = json.dumps({"refresh_token": auth.session.refresh_token}).encode("utf-8")
        req = request.Request(
            f"{self.base_url.rstrip('/')}/auth/v1/token?grant_type=refresh_token",
            data=payload,
            headers={
                "apikey": self.anon_key,
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with self._urlopen(req) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except HTTPError as exc:  # pragma: no cover - exercised via tests with patched urlopen
            body = exc.read().decode("utf-8", errors="replace")
            raise SessionError(f"Failed to refresh session: {body}") from exc
        except URLError as exc:  # pragma: no cover - depends on runtime/network setup
            raise SessionError(f"Failed to refresh session: {exc.reason}") from exc
        except ssl.SSLError as exc:  # pragma: no cover - depends on runtime/network setup
            raise SessionError(f"Failed to refresh session: {exc}") from exc

        new_auth = AuthState(
            source=auth.source,
            base_url=self.base_url,
            anon_key=self.anon_key,
            session=replace(
                auth.session,
                access_token=data["access_token"],
                refresh_token=data.get("refresh_token", auth.session.refresh_token),
                token_type=data.get("token_type", auth.session.token_type),
                expires_at=data.get("expires_at"),
            ),
            user=data.get("user") or auth.user,
            updated_at=datetime.now(timezone.utc).isoformat(),
        )
        if self.is_file_backed(auth):
            with self.file_lock():
                self.store.save_auth(new_auth)
        return new_auth

    @contextmanager
    def file_lock(self) -> Iterator[None]:
        self.store.ensure_base_dir()
        lock_path = Path(self.store.base_dir) / ".auth.lock"
        with lock_path.open("w", encoding="utf-8") as lock_file:
            if fcntl is not None:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                if fcntl is not None:
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
