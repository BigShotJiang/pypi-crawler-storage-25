from __future__ import annotations

import importlib.resources
import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    tomllib = None  # type: ignore[assignment]

DEFAULT_BASE_URL = "https://console.6.12.235.165.nip.io"
DEFAULT_ANON_KEY = "reallyreallyreallyreallyverysafe"
# This bundled CA is only for the self-signed test deployment so `pip install powerbase-cli`
# can work out of the box. Remove it after the deployed console switches to a publicly trusted
# TLS certificate, then delete the bundled PEM file and its package-data entry as well.
BUNDLED_CA_CERT_SENTINEL = "<bundled test CA>"
BUNDLED_CA_CERT_RESOURCE = "certs/powerbase-test-ca.pem"


def default_config_dir() -> Path:
    env_dir = os.environ.get("POWERBASE_CONFIG_DIR")
    if env_dir:
        return Path(env_dir).expanduser()
    return Path.home() / ".config" / "powerbase"


@dataclass
class AppConfig:
    base_url: str | None = DEFAULT_BASE_URL
    anon_key: str | None = DEFAULT_ANON_KEY
    output: str = "text"
    tls_insecure: bool = False
    ca_cert_file: str | None = None


@dataclass
class AuthSession:
    access_token: str
    refresh_token: str | None = None
    token_type: str = "bearer"
    expires_at: int | None = None


@dataclass
class AuthState:
    source: str
    session: AuthSession
    base_url: str | None = None
    anon_key: str | None = None
    user: dict[str, Any] | None = None
    updated_at: str | None = None


@dataclass
class ContextState:
    instance_id: str | None = None
    org_id: str | None = None
    branch: str | None = None
    updated_at: str | None = None


def _as_path(path: str | Path | None) -> Path:
    if path is None:
        return default_config_dir()
    return Path(path).expanduser()


def env_flag(name: str) -> bool:
    value = os.environ.get(name)
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def load_bundled_ca_cert() -> str | None:
    # The PEM contents are loaded at runtime so test builds can trust the packaged self-signed CA
    # without asking end users to pass `--ca-cert`. Once the server uses a trusted certificate,
    # this helper and its callers can be removed.
    try:
        resource = importlib.resources.files("powerbase_cli").joinpath(BUNDLED_CA_CERT_RESOURCE)
        if not resource.is_file():
            return None
        return resource.read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError):
        return None


class ConfigStore:
    def __init__(self, base_dir: str | Path | None = None) -> None:
        self.base_dir = _as_path(base_dir)
        self.config_path = self.base_dir / "config.toml"
        self.auth_path = self.base_dir / "auth.json"
        self.context_path = self.base_dir / "context.json"

    def ensure_base_dir(self) -> None:
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def load_config(self) -> AppConfig:
        if not self.config_path.exists():
            return AppConfig(base_url=None, anon_key=None)
        if tomllib is None:
            raise RuntimeError("tomllib is required to read config.toml")
        data = tomllib.loads(self.config_path.read_text(encoding="utf-8"))
        return AppConfig(
            base_url=data.get("base_url"),
            anon_key=data.get("anon_key"),
            output=data.get("output", "text"),
            tls_insecure=bool(data.get("tls_insecure", False)),
            ca_cert_file=data.get("ca_cert_file"),
        )

    def save_config(self, config: AppConfig) -> None:
        self.ensure_base_dir()
        lines = []
        if config.base_url and config.base_url != DEFAULT_BASE_URL:
            lines.append(f'base_url = "{config.base_url}"')
        if config.anon_key and config.anon_key != DEFAULT_ANON_KEY:
            lines.append(f'anon_key = "{config.anon_key}"')
        if config.output:
            lines.append(f'output = "{config.output}"')
        if config.tls_insecure:
            lines.append("tls_insecure = true")
        if config.ca_cert_file:
            lines.append(f'ca_cert_file = "{config.ca_cert_file}"')
        self.config_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")

    def load_auth(self) -> AuthState | None:
        if not self.auth_path.exists():
            return None
        data = json.loads(self.auth_path.read_text(encoding="utf-8"))
        session_data = data.get("session") or {
            "access_token": data.get("access_token"),
            "refresh_token": data.get("refresh_token"),
            "token_type": data.get("token_type", "bearer"),
            "expires_at": data.get("expires_at"),
        }
        if not session_data.get("access_token"):
            return None
        return AuthState(
            source=data.get("source", "file"),
            base_url=data.get("base_url"),
            anon_key=data.get("anon_key"),
            session=AuthSession(
                access_token=session_data["access_token"],
                refresh_token=session_data.get("refresh_token"),
                token_type=session_data.get("token_type", "bearer"),
                expires_at=session_data.get("expires_at"),
            ),
            user=data.get("user"),
            updated_at=data.get("updated_at"),
        )

    def save_auth(self, auth: AuthState) -> None:
        self.ensure_base_dir()
        payload = {
            "version": 1,
            "source": auth.source,
            "base_url": auth.base_url,
            "anon_key": auth.anon_key,
            "session": asdict(auth.session),
            "user": auth.user,
            "updated_at": auth.updated_at,
        }
        self.auth_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    def clear_auth(self) -> None:
        if self.auth_path.exists():
            self.auth_path.unlink()

    def load_context(self) -> ContextState:
        if not self.context_path.exists():
            return ContextState()
        data = json.loads(self.context_path.read_text(encoding="utf-8"))
        return ContextState(
            instance_id=data.get("instance_id"),
            org_id=data.get("org_id"),
            branch=data.get("branch"),
            updated_at=data.get("updated_at"),
        )

    def save_context(self, context: ContextState) -> None:
        self.ensure_base_dir()
        self.context_path.write_text(json.dumps(asdict(context), indent=2) + "\n", encoding="utf-8")

    def clear_context(self, *, instance: bool = False, org: bool = False, branch: bool = False) -> ContextState:
        context = self.load_context()
        if not any([instance, org, branch]):
            context = ContextState()
        else:
            if instance:
                context.instance_id = None
            if org:
                context.org_id = None
            if branch:
                context.branch = None
        self.save_context(context)
        return context


def env_auth_state() -> AuthState | None:
    access_token = os.environ.get("POWERBASE_ACCESS_TOKEN")
    if not access_token:
        return None
    refresh_token = os.environ.get("POWERBASE_REFRESH_TOKEN")
    expires_at_raw = os.environ.get("POWERBASE_EXPIRES_AT")
    expires_at = int(expires_at_raw) if expires_at_raw and expires_at_raw.isdigit() else None
    return AuthState(
        source="env",
        base_url=os.environ.get("POWERBASE_BASE_URL"),
        anon_key=os.environ.get("POWERBASE_ANON_KEY"),
        session=AuthSession(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at,
        ),
    )


def merge_config_with_env(config: AppConfig) -> AppConfig:
    return AppConfig(
        base_url=os.environ.get("POWERBASE_BASE_URL") or config.base_url,
        anon_key=os.environ.get("POWERBASE_ANON_KEY") or config.anon_key,
        output=os.environ.get("POWERBASE_OUTPUT") or config.output,
        tls_insecure=env_flag("POWERBASE_TLS_INSECURE") or config.tls_insecure,
        ca_cert_file=os.environ.get("POWERBASE_CA_CERT_FILE") or config.ca_cert_file,
    )


def merge_context_with_env(context: ContextState) -> ContextState:
    return ContextState(
        instance_id=os.environ.get("POWERBASE_INSTANCE_ID") or context.instance_id,
        org_id=os.environ.get("POWERBASE_ORG_ID") or context.org_id,
        branch=os.environ.get("POWERBASE_BRANCH") or context.branch,
        updated_at=context.updated_at,
    )
