from __future__ import annotations

import argparse

from .shared import asdict, build_store, render_output, resolve_config


def handle_config_list(args: argparse.Namespace) -> int:
    store = build_store(args)
    file_config = store.load_config()
    effective = resolve_config(args, store)
    render_output(
        args,
        {
            "effective": asdict(effective),
            "file": asdict(file_config),
            "config_file": str(store.config_path),
        },
    )
    return 0


def handle_config_get(args: argparse.Namespace) -> int:
    store = build_store(args)
    effective = resolve_config(args, store)
    value = getattr(effective, args.key.replace("-", "_"))
    render_output(args, {args.key: value})
    return 0


def handle_config_set(args: argparse.Namespace) -> int:
    store = build_store(args)
    config = store.load_config()
    setattr(config, args.key.replace("-", "_"), args.value)
    store.save_config(config)
    render_output(args, {"status": "saved", "config_file": str(store.config_path), args.key: args.value})
    return 0


def register_config_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    config = subparsers.add_parser("config", help="Read or update config.", description="Manage config.toml values.")
    config_sub = config.add_subparsers(dest="config_command")
    p = config_sub.add_parser(
        "list",
        help="List effective config.",
        description=(
            "Show effective config and file-backed values. Remember that command-line "
            "flags such as `--json` override values saved in config.toml."
        ),
    )
    p.set_defaults(handler=handle_config_list)
    p = config_sub.add_parser(
        "get",
        help="Get one config key.",
        description=(
            "Read one effective config key after applying flags, environment variables, "
            "config.toml, and defaults. For example, passing `--json` still makes the "
            "effective output value `json` even if config.toml says `text`."
        ),
    )
    p.add_argument("key", choices=["base_url", "anon_key", "output"])
    p.set_defaults(handler=handle_config_get)
    p = config_sub.add_parser(
        "set",
        help="Set one config key.",
        description=(
            "Write one value into config.toml. Later commands can still override the "
            "saved value with command-line flags such as `--json`."
        ),
    )
    p.add_argument("key", choices=["base_url", "anon_key", "output"])
    p.add_argument("value")
    p.set_defaults(handler=handle_config_set)
