from __future__ import annotations

import argparse

from .shared import build_api, load_sql, render_output, require_instance, resolve_branch


def handle_sql_run(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    instance_id = require_instance(args.instance_id, context)
    branch = resolve_branch(args.branch_name, context) or "main"
    sql = load_sql(args.sql, args.sql_file)
    render_output(args, api.run_sql(instance_id, sql, branch))
    return 0


def register_sql_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    sql = subparsers.add_parser("sql", help="Run SQL.", description="Run SQL against an instance branch.")
    sql_sub = sql.add_subparsers(dest="sql_command")
    p = sql_sub.add_parser(
        "run",
        help="Run SQL.",
        description=(
            "Run SQL against the current instance. Pass --sql directly, or use --sql-file. "
            "If you omit --instance-id, the saved context instance_id is used."
        ),
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--branch", dest="branch_name", help="Branch slug. Falls back to context.json or main.")
    p.add_argument("--sql", help="Inline SQL string. Prefix with @ to load from a file.")
    p.add_argument("--sql-file", help="Path to a SQL file.")
    p.set_defaults(handler=handle_sql_run)
