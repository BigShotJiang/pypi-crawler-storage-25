from __future__ import annotations

import argparse

from .shared import build_api, render_output, require_instance


def handle_files_list(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.sandbox_files_list(require_instance(args.instance_id, context), args.path, args.include_hidden))
    return 0


def handle_files_tree(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.sandbox_files_tree(require_instance(args.instance_id, context), args.root, args.max_depth))
    return 0


def handle_files_read(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.sandbox_files_read(require_instance(args.instance_id, context), args.path))
    return 0


def handle_files_create_file(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.sandbox_files_create_file(require_instance(args.instance_id, context), args.path, args.content or ""))
    return 0


def handle_files_create_folder(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.sandbox_files_create_folder(require_instance(args.instance_id, context), args.path))
    return 0


def handle_files_upload(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.sandbox_files_upload(require_instance(args.instance_id, context), args.source, args.target_path))
    return 0


def handle_files_delete(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.sandbox_files_delete(require_instance(args.instance_id, context), args.path))
    return 0


def register_sandbox_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    sandbox = subparsers.add_parser("sandbox", help="Sandbox commands.", description="Read or modify sandbox files.")
    sandbox_sub = sandbox.add_subparsers(dest="sandbox_command")
    files = sandbox_sub.add_parser("files", help="Sandbox file commands.", description="Read or modify sandbox files.")
    files_sub = files.add_subparsers(dest="files_command")
    p = files_sub.add_parser("list", help="List a directory.", description="List sandbox files at one path.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--path", default="/", help="Sandbox path, such as /src")
    p.add_argument("--include-hidden", action="store_true", help="Include hidden files.")
    p.set_defaults(handler=handle_files_list)
    p = files_sub.add_parser("tree", help="Show file tree.", description="Show a sandbox directory tree.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--root", default="/", help="Sandbox root path.")
    p.add_argument("--max-depth", type=int, default=3, help="Maximum depth to fetch. Default: 3")
    p.set_defaults(handler=handle_files_tree)
    p = files_sub.add_parser("read", help="Read one file.", description="Read one sandbox file path.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("path", help="Sandbox file path, such as /src/app.tsx")
    p.set_defaults(handler=handle_files_read)
    p = files_sub.add_parser("create-file", help="Create a file.", description="Create a sandbox file at one path.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("path")
    p.add_argument("--content", default="", help="Initial file content.")
    p.set_defaults(handler=handle_files_create_file)
    p = files_sub.add_parser("create-folder", help="Create a folder.", description="Create a sandbox folder at one path.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("path")
    p.set_defaults(handler=handle_files_create_folder)
    p = files_sub.add_parser(
        "upload",
        help="Upload a local file.",
        description="Upload a local file into the sandbox. target-path is the destination directory.",
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("source", help="Local source file path.")
    p.add_argument("--target-path", default="/", help="Sandbox destination directory.")
    p.set_defaults(handler=handle_files_upload)
    p = files_sub.add_parser("delete", help="Delete a sandbox path.", description="Delete a sandbox file or folder.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("path")
    p.set_defaults(handler=handle_files_delete)
