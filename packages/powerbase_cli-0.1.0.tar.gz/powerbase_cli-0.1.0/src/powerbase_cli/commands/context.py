from __future__ import annotations

import argparse

from .shared import asdict, build_store, now_iso, render_output, resolve_context


def handle_context_show(args: argparse.Namespace) -> int:
    store = build_store(args)
    file_context = store.load_context()
    effective = resolve_context(store)
    render_output(
        args,
        {"effective": asdict(effective), "file": asdict(file_context), "context_file": str(store.context_path)},
    )
    return 0


def _save_context_update(
    args: argparse.Namespace,
    *,
    instance_id: str | None = None,
    org_id: str | None = None,
    branch: str | None = None,
) -> int:
    store = build_store(args)
    context = store.load_context()
    if instance_id is not None:
        context.instance_id = instance_id
    if org_id is not None:
        context.org_id = org_id
    if branch is not None:
        context.branch = branch
    context.updated_at = now_iso()
    store.save_context(context)
    render_output(args, {"status": "saved", "context": asdict(context), "context_file": str(store.context_path)})
    return 0


def handle_context_clear(args: argparse.Namespace) -> int:
    store = build_store(args)
    context = store.clear_context(instance=args.instance, org=args.org, branch=args.branch)
    render_output(args, {"status": "cleared", "context": asdict(context), "context_file": str(store.context_path)})
    return 0


def register_context_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    context = subparsers.add_parser(
        "context",
        help="Manage default org, instance, and branch.",
        description="Read or update ~/.config/powerbase/context.json for later commands.",
    )
    context_sub = context.add_subparsers(dest="context_command")
    p = context_sub.add_parser("show", help="Show current context.", description="Show effective and saved context values.")
    p.set_defaults(handler=handle_context_show)
    p = context_sub.add_parser(
        "use-instance",
        help="Set the default instance.",
        description=(
            "Set the default instance used by later commands. The instance ID usually comes from "
            "`powerbase instance list` or `powerbase context show`."
        ),
    )
    p.add_argument("instance_id")
    p.set_defaults(handler=lambda args: _save_context_update(args, instance_id=args.instance_id))
    p = context_sub.add_parser("use-org", help="Set the default org.", description="Set the default organization ID.")
    p.add_argument("org_id")
    p.set_defaults(handler=lambda args: _save_context_update(args, org_id=args.org_id))
    p = context_sub.add_parser(
        "use-branch",
        help="Set the default branch.",
        description="Set the default branch slug, such as main or feature/my-change.",
    )
    p.add_argument("branch")
    p.set_defaults(handler=lambda args: _save_context_update(args, branch=args.branch))
    p = context_sub.add_parser(
        "clear",
        help="Clear saved context.",
        description="Clear saved context values. If no flag is passed, all context values are cleared.",
    )
    p.add_argument("--instance", action="store_true", help="Clear only the saved instance_id.")
    p.add_argument("--org", action="store_true", help="Clear only the saved org_id.")
    p.add_argument("--branch", action="store_true", help="Clear only the saved branch.")
    p.set_defaults(handler=handle_context_clear)
