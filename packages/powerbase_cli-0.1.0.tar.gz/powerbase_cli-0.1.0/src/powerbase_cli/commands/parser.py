from __future__ import annotations

import argparse
import sys

from ..session import SessionError
from ..transport import ApiError
from .agent import register_agent_commands
from .auth import register_auth_commands
from .branch import register_branch_commands
from .config_cmd import register_config_commands
from .context import register_context_commands
from .database import register_database_commands
from .instance import register_instance_commands
from .org import register_org_commands
from .publish import register_publish_commands
from .sandbox import register_sandbox_commands
from .sql import register_sql_commands

GLOBAL_OPTION_ARITY = {
    "--config-dir": 1,
    "--base-url": 1,
    "--anon-key": 1,
    "--ca-cert": 1,
    "--insecure": 0,
    "--json": 0,
}


def normalize_global_argv(argv: list[str] | None) -> list[str] | None:
    if argv is None:
        return None

    global_args: list[str] = []
    remaining_args: list[str] = []
    i = 0
    while i < len(argv):
        token = argv[i]
        arity = GLOBAL_OPTION_ARITY.get(token)
        if arity is None:
            remaining_args.append(token)
            i += 1
            continue

        if arity == 1:
            if i + 1 >= len(argv):
                remaining_args.append(token)
                i += 1
                continue
            global_args.append(token)
            global_args.append(argv[i + 1])
            i += 2
            continue
        global_args.append(token)
        i += 1

    return global_args + remaining_args


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="powerbase",
        description=(
            "Operate Powerbase console workflows from the command line. "
            "Default instance creation uses the managed Powerbase database flow; "
            "`powerbase database ...` is the advanced bring-your-own-database path."
        ),
        epilog=(
            "Important: values are resolved in this order: command flags, environment variables, "
            "~/.config/powerbase files, then defaults."
        ),
    )
    parser.add_argument("--config-dir", help="Override the config directory. Defaults to ~/.config/powerbase.")
    parser.add_argument("--base-url", help="Console base URL. Overrides the built-in default console endpoint.")
    parser.add_argument("--anon-key", help="Supabase anon key used for functions and auth requests. Overrides the built-in default.")
    parser.add_argument(
        "--ca-cert",
        dest="ca_cert_file",
        help="Path to a CA certificate PEM file to trust for HTTPS requests.",
    )
    parser.add_argument(
        "--insecure",
        action="store_true",
        help="Disable TLS certificate verification for HTTPS requests. Use only for testing with self-signed certs.",
    )
    parser.add_argument("--json", action="store_true", help="Print JSON output.")

    subparsers = parser.add_subparsers(dest="command")
    register_auth_commands(subparsers)
    register_config_commands(subparsers)
    register_context_commands(subparsers)
    register_org_commands(subparsers)
    register_database_commands(subparsers)
    register_instance_commands(subparsers)
    register_branch_commands(subparsers)
    register_sql_commands(subparsers)
    register_publish_commands(subparsers)
    register_sandbox_commands(subparsers)
    register_agent_commands(subparsers)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    raw_argv = sys.argv[1:] if argv is None else argv
    args = parser.parse_args(normalize_global_argv(raw_argv))
    if not hasattr(args, "handler"):
        parser.print_help()
        return 0
    try:
        return int(args.handler(args) or 0)
    except (ApiError, SessionError, RuntimeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
