from __future__ import annotations

import argparse

from .shared import build_api, render_output, require_instance


def handle_instance_list(args: argparse.Namespace) -> int:
    _, _, _, _, api = build_api(args)
    render_output(args, api.list_instances())
    return 0


def handle_instance_get(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.get_instance(require_instance(args.instance_id, context)))
    return 0


def handle_instance_create(args: argparse.Namespace) -> int:
    _, _, _, _, api = build_api(args)
    render_output(args, api.create_instance(args.name, args.database_id, args.org_id))
    return 0


def handle_instance_delete(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.delete_instance(require_instance(args.instance_id, context)))
    return 0


def register_instance_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    instance = subparsers.add_parser(
        "instance",
        help="Instance commands.",
        description=(
            "Read or change Powerbase instances. By default, `powerbase instance create` "
            "uses the managed Powerbase database flow. Pass `--database-id` only when "
            "you intentionally want the advanced bring-your-own-database path."
        ),
    )
    instance_sub = instance.add_subparsers(dest="instance_command")
    p = instance_sub.add_parser("list", help="List instances.", description="List instances visible to the current user.")
    p.set_defaults(handler=handle_instance_list)
    p = instance_sub.add_parser(
        "get",
        help="Get one instance.",
        description="Show one instance. If --instance-id is omitted, the saved context instance_id is used.",
    )
    p.add_argument("--instance-id", help="Instance ID. Source: `powerbase instance list` or `powerbase context show`.")
    p.set_defaults(handler=handle_instance_get)
    p = instance_sub.add_parser(
        "create",
        help="Create an instance.",
        description=(
            "Create a new instance. Default behavior: if `--database-id` is omitted, "
            "Powerbase creates or attaches the managed platform database for the "
            "instance. Advanced behavior: pass `--database-id` to bind the instance "
            "to an already registered external database connection. The create call "
            "returns as soon as provisioning starts; `instance get`, `branch list`, "
            "and sandbox operations may need a short retry window before the new "
            "instance becomes fully readable."
        ),
    )
    p.add_argument("--name", help="Optional instance name.")
    p.add_argument(
        "--database-id",
        help=(
            "Optional registered database ID for the advanced bring-your-own-database "
            "flow. Omit this to use the default managed Powerbase database flow."
        ),
    )
    p.add_argument("--org-id", help="Optional organization ID.")
    p.set_defaults(handler=handle_instance_create)
    p = instance_sub.add_parser(
        "delete",
        help="Delete an instance.",
        description="Delete one instance. If --instance-id is omitted, the saved context instance_id is used.",
    )
    p.add_argument("--instance-id", help="Instance ID to delete.")
    p.set_defaults(handler=handle_instance_delete)
