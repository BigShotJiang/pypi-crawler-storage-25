from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any

from ..api import PowerbaseApi
from ..config import (
    BUNDLED_CA_CERT_SENTINEL,
    DEFAULT_ANON_KEY,
    DEFAULT_BASE_URL,
    AppConfig,
    AuthSession,
    AuthState,
    ConfigStore,
    ContextState,
    load_bundled_ca_cert,
    merge_config_with_env,
    merge_context_with_env,
)
from ..session import SessionManager
from ..transport import PowerbaseTransport


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_store(args: argparse.Namespace) -> ConfigStore:
    return ConfigStore(base_dir=args.config_dir)


def resolve_config(args: argparse.Namespace, store: ConfigStore) -> AppConfig:
    config = merge_config_with_env(store.load_config())
    saved_auth = store.load_auth()
    explicit_ca_cert_file = getattr(args, "ca_cert_file", None) or config.ca_cert_file
    return AppConfig(
        base_url=args.base_url or config.base_url or (saved_auth.base_url if saved_auth else None) or DEFAULT_BASE_URL,
        anon_key=args.anon_key or config.anon_key or (saved_auth.anon_key if saved_auth else None) or DEFAULT_ANON_KEY,
        output="json" if args.json else config.output,
        tls_insecure=bool(getattr(args, "insecure", False) or config.tls_insecure),
        # Keep explicit CA settings first. The bundled test CA is only the final fallback for the
        # current self-signed test environment and should be removed once the deployment uses a
        # publicly trusted certificate.
        ca_cert_file=explicit_ca_cert_file or (BUNDLED_CA_CERT_SENTINEL if load_bundled_ca_cert() else None),
    )


def resolve_context(store: ConfigStore) -> ContextState:
    return merge_context_with_env(store.load_context())


def build_api(args: argparse.Namespace) -> tuple[ConfigStore, AppConfig, ContextState, SessionManager, PowerbaseApi]:
    store = build_store(args)
    config = resolve_config(args, store)
    context = resolve_context(store)
    session_manager = SessionManager(
        store,
        config.base_url,
        config.anon_key,
        tls_insecure=config.tls_insecure,
        ca_cert_file=config.ca_cert_file,
    )
    api = PowerbaseApi(PowerbaseTransport(config, session_manager))
    return store, config, context, session_manager, api


def render_output(args: argparse.Namespace, data: Any) -> None:
    if isinstance(data, str):
        print(data)
        return
    print(json.dumps(data, indent=2, ensure_ascii=False))


def require_instance(instance_id: str | None, context: ContextState) -> str:
    resolved = instance_id or context.instance_id
    if not resolved:
        raise RuntimeError(
            "instance_id is required. Pass --instance-id or set one with `powerbase context use-instance`."
        )
    return resolved


def resolve_branch(branch: str | None, context: ContextState) -> str | None:
    return branch or context.branch


def load_sql(sql: str | None, sql_file: str | None) -> str:
    if sql_file:
        return open(sql_file, "r", encoding="utf-8").read()
    if not sql:
        raise RuntimeError("SQL is required. Pass --sql or --sql-file.")
    if sql.startswith("@"):
        return open(sql[1:], "r", encoding="utf-8").read()
    return sql


def load_text(value: str | None, file_path: str | None, *, required_message: str) -> str:
    if file_path:
        return open(file_path, "r", encoding="utf-8").read()
    if value:
        if value.startswith("@"):
            return open(value[1:], "r", encoding="utf-8").read()
        return value
    raise RuntimeError(required_message)


def load_json_document(file_path: str) -> dict[str, Any]:
    with open(file_path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise RuntimeError("JSON document must be an object.")
    return data


def parse_json_specs(raw_values: list[str] | None, *, label: str) -> list[dict[str, Any]]:
    parsed: list[dict[str, Any]] = []
    for raw in raw_values or []:
        try:
            item = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Invalid {label} JSON: {raw}") from exc
        if not isinstance(item, dict):
            raise RuntimeError(f"Each {label} must be a JSON object.")
        parsed.append(item)
    return parsed


__all__ = [
    "AppConfig",
    "AuthSession",
    "AuthState",
    "ConfigStore",
    "ContextState",
    "PowerbaseApi",
    "SessionManager",
    "asdict",
    "build_api",
    "build_store",
    "load_json_document",
    "load_sql",
    "load_text",
    "now_iso",
    "parse_json_specs",
    "render_output",
    "require_instance",
    "resolve_branch",
    "resolve_config",
    "resolve_context",
]
