from __future__ import annotations

import argparse

from .shared import build_api, render_output


def handle_org_list(args: argparse.Namespace) -> int:
    _, _, _, _, api = build_api(args)
    render_output(args, api.list_orgs())
    return 0


def register_org_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    org = subparsers.add_parser("org", help="Organization commands.", description="Read Powerbase organizations.")
    org_sub = org.add_subparsers(dest="org_command")
    p = org_sub.add_parser("list", help="List organizations.", description="List organizations available to the current user.")
    p.set_defaults(handler=handle_org_list)
