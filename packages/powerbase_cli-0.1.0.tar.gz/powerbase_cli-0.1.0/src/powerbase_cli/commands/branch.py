from __future__ import annotations

import argparse

from .shared import build_api, now_iso, render_output, require_instance, resolve_branch


def handle_branch_list(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.list_branches(require_instance(args.instance_id, context)))
    return 0


def handle_branch_create(args: argparse.Namespace) -> int:
    store, _, context, _, api = build_api(args)
    instance_id = require_instance(args.instance_id, context)
    source_branch = args.source_branch or resolve_branch(None, context) or "main"
    created = api.create_branch(instance_id, args.branch_name, source_branch)
    branch_slug = created.get("branchSlug") or created.get("branch_slug") or args.branch_name
    api.switch_branch(instance_id, branch_slug)
    context.instance_id = instance_id
    context.branch = branch_slug
    context.updated_at = now_iso()
    store.save_context(context)
    render_output(args, {"created": created, "switched_to": branch_slug})
    return 0


def handle_branch_switch(args: argparse.Namespace) -> int:
    store, _, context, _, api = build_api(args)
    instance_id = require_instance(args.instance_id, context)
    render_output(args, api.switch_branch(instance_id, args.branch_name))
    context.instance_id = instance_id
    context.branch = args.branch_name
    context.updated_at = now_iso()
    store.save_context(context)
    return 0


def handle_branch_delete(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    instance_id = require_instance(args.instance_id, context)
    render_output(args, api.delete_branch(instance_id, args.branch_name))
    return 0


def register_branch_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    branch = subparsers.add_parser("branch", help="Branch commands.", description="Manage instance branches.")
    branch_sub = branch.add_subparsers(dest="branch_command")
    p = branch_sub.add_parser("list", help="List branches.", description="List branches for one instance.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.set_defaults(handler=handle_branch_list)
    p = branch_sub.add_parser(
        "create",
        help="Create and switch a branch.",
        description=(
            "Create a branch through the platform API, then switch the sandbox to it. "
            "If --source-branch is omitted, the saved context branch is used. The "
            "returned `switched_to` value is the normalized branch slug; use that "
            "slug for later commands such as `branch delete`."
        ),
    )
    p.add_argument("branch_name", help="Branch slug to create.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--source-branch", help="Source branch slug. Example: main")
    p.set_defaults(handler=handle_branch_create)
    p = branch_sub.add_parser(
        "switch",
        help="Switch the sandbox branch.",
        description="Switch the sandbox branch and update context.json.",
    )
    p.add_argument("branch_name", help="Branch slug to switch to.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.set_defaults(handler=handle_branch_switch)
    p = branch_sub.add_parser(
        "delete",
        help="Delete a branch.",
        description=(
            "Delete a branch from the instance. Pass the normalized branch slug, not "
            "necessarily the raw input you originally used with `branch create`. For "
            "example, `feature/foo` may need to be deleted as `feature-foo`."
        ),
    )
    p.add_argument("branch_name", help="Branch slug to delete.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.set_defaults(handler=handle_branch_delete)
