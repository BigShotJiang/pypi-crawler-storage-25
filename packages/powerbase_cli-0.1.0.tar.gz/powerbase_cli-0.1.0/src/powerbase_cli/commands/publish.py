from __future__ import annotations

import argparse

from .shared import build_api, render_output, require_instance


def handle_publish_diff(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    instance_id = require_instance(args.instance_id, context)
    render_output(args, api.publish_diff(instance_id, args.target))
    return 0


def handle_publish_run(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    instance_id = require_instance(args.instance_id, context)
    sql = args.sql
    if not sql:
        diff = api.publish_diff(instance_id, args.target)
        sql = diff.get("sql") or ""
    events = list(api.publish_run(instance_id, sql, args.target))
    render_output(args, {"events": events})
    return 0


def register_publish_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    publish = subparsers.add_parser("publish", help="Publish commands.", description="Generate diffs and publish an instance.")
    publish_sub = publish.add_subparsers(dest="publish_command")
    p = publish_sub.add_parser("diff", help="Show publish diff.", description="Generate publish diff for the current instance.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--target", default="prod", help="Publish target. Default: prod")
    p.set_defaults(handler=handle_publish_diff)
    p = publish_sub.add_parser(
        "run",
        help="Run publish flow.",
        description=(
            "Publish the current instance. If --sql is omitted, the command first runs publish diff and uses its SQL."
        ),
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--target", default="prod", help="Publish target. Default: prod")
    p.add_argument("--sql", help="Optional SQL to execute directly instead of deriving it from diff.")
    p.set_defaults(handler=handle_publish_run)
