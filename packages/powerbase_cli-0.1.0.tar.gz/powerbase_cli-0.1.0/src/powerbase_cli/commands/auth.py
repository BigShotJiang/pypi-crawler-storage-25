from __future__ import annotations

import argparse
import time

from .shared import AuthSession, AuthState, build_api, now_iso, render_output


def handle_auth_login(args: argparse.Namespace) -> int:
    store, config, _, _, api = build_api(args)
    data = api.start_cli_login()
    login_id = data["login_id"]
    timeout_sec = int(args.login_timeout)
    if timeout_sec < 0:
        raise RuntimeError("--timeout must be >= 0 (0 means wait indefinitely).")
    deadline: float | None = None
    if timeout_sec > 0:
        deadline = time.monotonic() + timeout_sec
    print(f"Open this URL in your browser:\n{data['login_url']}\n")
    if deadline is not None:
        print(f"Waiting for authorization (timeout {timeout_sec}s)...")
    else:
        print("Waiting for authorization (no timeout)...")
    while True:
        polled = api.poll_cli_login(login_id)
        status = polled.get("status")
        if status == "pending":
            if deadline is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise RuntimeError(
                        f"Login timed out after {timeout_sec} seconds without browser approval. "
                        "Complete login sooner, run `powerbase auth login` again, or pass a larger "
                        "`--timeout` (use `--timeout 0` to wait indefinitely)."
                    )
            else:
                remaining = float("inf")

            poll_sec = max(0.0, float(int(polled.get("poll_interval", 2))))
            if poll_sec > 0:
                sleep_sec = min(poll_sec, remaining)
            elif deadline is not None:
                # poll_interval 0 would spin; cap backoff when a deadline is set
                sleep_sec = min(1.0, remaining)
            else:
                sleep_sec = 0.0

            if sleep_sec > 0:
                time.sleep(sleep_sec)
            continue
        if status == "approved":
            auth = AuthState(
                source="login",
                base_url=config.base_url,
                anon_key=config.anon_key,
                session=AuthSession(**polled["session"]),
                user=polled.get("user"),
                updated_at=now_iso(),
            )
            store.save_auth(auth)
            render_output(args, {"status": "approved", "saved_to": str(store.auth_path), "user": auth.user})
            return 0
        raise RuntimeError(f"Login failed with status: {status}")


def handle_auth_status(args: argparse.Namespace) -> int:
    store, _, _, session_manager, _ = build_api(args)
    auth = session_manager.get_auth_state()
    data = {
        "authenticated": bool(auth),
        "source": auth.source if auth else None,
        "auth_file": str(store.auth_path),
        "has_refresh_token": bool(auth and auth.session.refresh_token),
        "seconds_until_expiry": session_manager.seconds_until_expiry(auth),
        "user": auth.user if auth else None,
    }
    render_output(args, data)
    return 0


def handle_auth_refresh(args: argparse.Namespace) -> int:
    _, _, _, session_manager, _ = build_api(args)
    auth = session_manager.refresh()
    render_output(args, {"status": "refreshed", "user": auth.user, "expires_at": auth.session.expires_at})
    return 0


def handle_auth_logout(args: argparse.Namespace) -> int:
    store, _, _, _, _ = build_api(args)
    store.clear_auth()
    render_output(args, {"status": "logged_out", "auth_file": str(store.auth_path)})
    return 0


def handle_auth_token_set(args: argparse.Namespace) -> int:
    store, config, _, _, _ = build_api(args)
    auth = AuthState(
        source="manual",
        base_url=config.base_url,
        anon_key=config.anon_key,
        session=AuthSession(
            access_token=args.access_token_value,
            refresh_token=args.refresh_token_value,
            expires_at=args.expires_at,
        ),
        updated_at=now_iso(),
    )
    store.save_auth(auth)
    render_output(args, {"status": "saved", "auth_file": str(store.auth_path)})
    return 0


def register_auth_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    auth = subparsers.add_parser(
        "auth",
        help="Manage login state.",
        description="Log in, inspect, refresh, or clear the saved Powerbase session.",
    )
    auth_sub = auth.add_subparsers(dest="auth_command")
    p = auth_sub.add_parser(
        "login",
        help="Start browser login.",
        description=(
            "Start browser-based login. This prints a login URL, polls until approval in the browser "
            "or until --timeout seconds elapse (default 300), then saves the session to "
            "~/.config/powerbase/auth.json. Use --timeout 0 to wait without a time limit."
        ),
    )
    p.add_argument(
        "--timeout",
        dest="login_timeout",
        type=int,
        default=300,
        metavar="SECONDS",
        help=(
            "Stop polling after this many seconds if login is not approved (default: 300). "
            "Pass 0 to wait indefinitely."
        ),
    )
    p.set_defaults(handler=handle_auth_login)
    p = auth_sub.add_parser(
        "status",
        help="Show current auth status.",
        description=(
            "Show the active authentication source and whether refresh is available. "
            "Reads env vars first, then ~/.config/powerbase/auth.json."
        ),
    )
    p.set_defaults(handler=handle_auth_status)
    p = auth_sub.add_parser(
        "refresh",
        help="Refresh the current session.",
        description="Refresh the saved session using the refresh token from auth.json.",
    )
    p.set_defaults(handler=handle_auth_refresh)
    p = auth_sub.add_parser("logout", help="Clear the saved auth session.", description="Delete the saved auth.json session.")
    p.set_defaults(handler=handle_auth_logout)
    p = auth_sub.add_parser(
        "token-set",
        help="Save tokens into auth.json.",
        description=(
            "Save an access token and optional refresh token into ~/.config/powerbase/auth.json. "
            "If you skip the refresh token, the CLI cannot auto-refresh when the access token expires."
        ),
    )
    p.add_argument("--access-token", dest="access_token_value", required=True, help="Access token to save.")
    p.add_argument("--refresh-token", dest="refresh_token_value", help="Refresh token to save.")
    p.add_argument("--expires-at", type=int, help="Unix timestamp when the access token expires.")
    p.set_defaults(handler=handle_auth_token_set)
