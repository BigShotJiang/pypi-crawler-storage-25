from __future__ import annotations

import argparse

from .shared import build_api, render_output


def handle_database_list(args: argparse.Namespace) -> int:
    _, _, _, _, api = build_api(args)
    render_output(args, api.list_databases())
    return 0


def handle_database_get(args: argparse.Namespace) -> int:
    _, _, _, _, api = build_api(args)
    render_output(args, api.get_database(args.database_id))
    return 0


def handle_database_create(args: argparse.Namespace) -> int:
    _, _, _, _, api = build_api(args)
    render_output(args, api.create_database(args.name, args.dsn, args.description, args.db_type))
    return 0


def handle_database_update(args: argparse.Namespace) -> int:
    _, _, _, _, api = build_api(args)
    render_output(
        args,
        api.update_database(args.database_id, args.name, args.dsn, args.description, args.db_type),
    )
    return 0


def handle_database_delete(args: argparse.Namespace) -> int:
    _, _, _, _, api = build_api(args)
    render_output(args, api.delete_database(args.database_id))
    return 0


def register_database_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    database = subparsers.add_parser(
        "database",
        help="Registered database connection commands.",
        description=(
            "Discover or manage reusable database connections used by instances. "
            "This command group is the advanced bring-your-own-database path. "
            "Use `powerbase instance create` without `--database-id` for the default "
            "managed Powerbase database flow."
        ),
    )
    database_sub = database.add_subparsers(dest="database_command")
    p = database_sub.add_parser(
        "list",
        help="List registered database connections.",
        description=(
            "List registered database connections visible to the current user. "
            "Use this before `powerbase instance create --database-id ...` when you "
            "intentionally want the advanced bring-your-own-database flow."
        ),
    )
    p.set_defaults(handler=handle_database_list)
    p = database_sub.add_parser(
        "get",
        help="Get one registered database connection.",
        description=(
            "Show one registered database connection by ID. The database ID usually "
            "comes from `powerbase database list`."
        ),
    )
    p.add_argument("database_id", help="Database ID from `powerbase database list`.")
    p.set_defaults(handler=handle_database_get)
    p = database_sub.add_parser(
        "create",
        help="Register an existing database connection.",
        description=(
            "Register an existing database DSN for advanced bring-your-own-database "
            "workflows. This does not provision a new physical database. Use the "
            "returned ID with `powerbase instance create --database-id ...`. Prefer "
            "plain `powerbase instance create` for the default managed Powerbase "
            "database flow."
        ),
    )
    p.add_argument("--name", required=True, help="Database display name.")
    p.add_argument(
        "--dsn",
        required=True,
        help=(
            "Existing database DSN or connection string. Treat this as sensitive: "
            "credentials are sent to and stored by the Powerbase platform."
        ),
    )
    p.add_argument("--description", help="Optional description shown in the console.")
    p.add_argument(
        "--db-type",
        help=(
            "Optional database type, such as mysql. Advanced bring-your-own-database "
            "flows may require SeekDB-compatible behavior for branch operations."
        ),
    )
    p.set_defaults(handler=handle_database_create)
    p = database_sub.add_parser(
        "update",
        help="Update one registered database connection.",
        description=(
            "Update one registered database connection by ID. Pass only the fields "
            "you want to change."
        ),
    )
    p.add_argument("database_id", help="Database ID from `powerbase database list`.")
    p.add_argument("--name", help="Updated database display name.")
    p.add_argument(
        "--dsn",
        help="Updated DSN or connection string for an existing external database.",
    )
    p.add_argument("--description", help="Updated description.")
    p.add_argument("--db-type", help="Updated database type.")
    p.set_defaults(handler=handle_database_update)
    p = database_sub.add_parser(
        "delete",
        help="Delete one registered database connection.",
        description=(
            "Delete one registered database connection by ID. This removes the "
            "Powerbase-side record only; it does not delete the physical database. "
            "Discover IDs with `powerbase database list` first."
        ),
    )
    p.add_argument("database_id", help="Database ID from `powerbase database list`.")
    p.set_defaults(handler=handle_database_delete)
