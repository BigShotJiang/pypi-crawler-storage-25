from __future__ import annotations

import argparse
import json

from .shared import build_api, load_json_document, load_text, parse_json_specs, render_output, require_instance


def handle_agent_providers(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.agent_providers(args.instance_id or context.instance_id))
    return 0


def handle_agent_status(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.agent_status(require_instance(args.instance_id, context), args.provider))
    return 0


def handle_agent_login_url(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.agent_login_url(require_instance(args.instance_id, context), args.provider))
    return 0


def handle_agent_opencode_config_get(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(args, api.agent_opencode_config_get(require_instance(args.instance_id, context)))
    return 0


def handle_agent_opencode_config_set(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    instance_id = require_instance(args.instance_id, context)
    models = parse_json_specs(args.model_limit, label="--model-limit entry")
    render_output(
        args,
        api.agent_opencode_config_set(instance_id, args.provider, args.api_key, models or None),
    )
    return 0


def handle_agent_opencode_config_delete(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    render_output(
        args,
        api.agent_opencode_config_delete(require_instance(args.instance_id, context), args.provider),
    )
    return 0


def handle_agent_opencode_json_set(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    payload = load_json_document(args.file)
    render_output(
        args,
        api.agent_opencode_json_set(require_instance(args.instance_id, context), payload),
    )
    return 0


def handle_agent_chat(args: argparse.Namespace) -> int:
    _, _, context, _, api = build_api(args)
    instance_id = require_instance(args.instance_id, context)
    message = load_text(
        args.message,
        args.message_file,
        required_message="A chat message is required. Pass --message or --message-file.",
    )
    first_user_message = None
    if args.first_user_message or args.first_user_message_file:
        first_user_message = load_text(
            args.first_user_message,
            args.first_user_message_file,
            required_message="first_user_message input is missing.",
        )
    events = api.agent_chat(
        instance_id,
        message,
        session_id=args.session_id,
        provider=args.provider,
        model=args.model,
        first_user_message=first_user_message,
        agent=args.agent_name,
    )
    if args.stream_jsonl:
        for event in events:
            print(json.dumps(event, ensure_ascii=False))
        return 0
    render_output(args, {"events": list(events)})
    return 0


def register_agent_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    agent = subparsers.add_parser("agent", help="Agent provider commands.", description="Inspect sandbox agent providers.")
    agent_sub = agent.add_subparsers(dest="agent_command")
    p = agent_sub.add_parser("providers", help="List providers.", description="List available sandbox agent providers.")
    p.add_argument("--instance-id", help="Optional instance ID.")
    p.set_defaults(handler=handle_agent_providers)
    p = agent_sub.add_parser("status", help="Show provider status.", description="Show login status for one agent provider.")
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--provider", default="cursor", help="Provider ID. Example: cursor")
    p.set_defaults(handler=handle_agent_status)
    p = agent_sub.add_parser(
        "login-url",
        help="Get a provider login URL.",
        description="Get a browser login URL for one agent provider.",
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--provider", default="cursor", help="Provider ID. Example: cursor")
    p.set_defaults(handler=handle_agent_login_url)

    p = agent_sub.add_parser(
        "chat",
        help="Send a prompt to the sandbox agent.",
        description=(
            "Send one prompt to the sandbox agent running in an instance. Use this when you want the sandbox "
            "itself to inspect or modify the project. The automatic preview build follows the sandbox's current "
            "branch, so run `powerbase branch switch` first when you want a feature-branch preview. By default "
            "the command collects all streamed events and prints them as JSON. Use --stream-jsonl to print one "
            "JSON event per line as events arrive."
        ),
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--provider", default="cursor", help="Agent provider ID, such as cursor, opencode, or kiro.")
    p.add_argument("--session-id", help="Optional provider session ID to resume an existing conversation.")
    p.add_argument("--model", help="Optional model ID for providers that support explicit model selection.")
    p.add_argument("--agent", dest="agent_name", help="Optional Kiro agent name.")
    p.add_argument("--message", help="Prompt text. Prefix with @ to load from a file.")
    p.add_argument("--message-file", help="Path to a file containing the prompt text.")
    p.add_argument(
        "--first-user-message",
        help="Optional first user message for language alignment during auto-fix. Prefix with @ to load from a file.",
    )
    p.add_argument("--first-user-message-file", help="Path to a file containing the first user message.")
    p.add_argument("--stream-jsonl", action="store_true", help="Print one JSON event per line while the chat runs.")
    p.set_defaults(handler=handle_agent_chat)

    opencode_config = agent_sub.add_parser(
        "opencode-config",
        help="Manage opencode API-key config.",
        description="Read or modify the sandbox opencode auth/config files for one instance.",
    )
    opencode_config_sub = opencode_config.add_subparsers(dest="agent_opencode_config_command")
    p = opencode_config_sub.add_parser(
        "get",
        help="Show opencode config.",
        description="Show configured providers, custom providers, and model limit overrides for one instance.",
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.set_defaults(handler=handle_agent_opencode_config_get)
    p = opencode_config_sub.add_parser(
        "set",
        help="Save one provider API key.",
        description=(
            "Save or update one opencode provider API key for an instance. Repeat --model-limit with JSON objects like "
            '\'{"id":"claude-sonnet-4","limit":{"context":200000,"output":16000}}\'.'
        ),
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--provider", required=True, help="Provider ID to configure, such as anthropic or openai.")
    p.add_argument("--api-key", required=True, help="API key to store in the sandbox.")
    p.add_argument(
        "--model-limit",
        action="append",
        help="Optional JSON object describing one model limit override.",
    )
    p.set_defaults(handler=handle_agent_opencode_config_set)
    p = opencode_config_sub.add_parser(
        "delete",
        help="Delete one provider API key.",
        description="Remove one opencode provider API key from the sandbox auth file.",
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--provider", required=True, help="Provider ID to remove.")
    p.set_defaults(handler=handle_agent_opencode_config_delete)

    opencode_json = agent_sub.add_parser(
        "opencode-json",
        help="Replace the sandbox opencode.json file.",
        description="Replace the sandbox opencode.json file with the contents of one local JSON document.",
    )
    opencode_json_sub = opencode_json.add_subparsers(dest="agent_opencode_json_command")
    p = opencode_json_sub.add_parser(
        "set",
        help="Replace opencode.json.",
        description="Load one local JSON file and replace the sandbox opencode.json file with it.",
    )
    p.add_argument("--instance-id", help="Instance ID. Falls back to context.json.")
    p.add_argument("--file", required=True, help="Path to a local JSON file.")
    p.set_defaults(handler=handle_agent_opencode_json_set)
