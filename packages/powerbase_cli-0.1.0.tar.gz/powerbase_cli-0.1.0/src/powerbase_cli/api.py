from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlencode

from .transport import PowerbaseTransport


def _response_data(response: dict[str, Any]) -> Any:
    if response.get("success") is False:
        raise RuntimeError(response.get("error") or response.get("message") or "Request failed")
    return response.get("data", response)


class PowerbaseApi:
    def __init__(self, transport: PowerbaseTransport) -> None:
        self.transport = transport

    def start_cli_login(self) -> dict[str, Any]:
        return _response_data(
            self.transport.invoke("cli-auth/start", method="POST", body={}, requires_auth=False)
        )

    def poll_cli_login(self, login_id: str) -> dict[str, Any]:
        return _response_data(self.transport.invoke("cli-auth/poll", method="POST", body={"login_id": login_id}, requires_auth=False))

    def list_orgs(self) -> Any:
        return _response_data(self.transport.invoke("organizations", method="GET"))

    def list_databases(self) -> Any:
        return _response_data(self.transport.invoke("databases", method="GET"))

    def get_database(self, database_id: str) -> Any:
        return _response_data(self.transport.invoke(f"databases/{database_id}", method="GET"))

    def create_database(
        self,
        name: str,
        dsn: str,
        description: str | None = None,
        db_type: str | None = None,
    ) -> Any:
        body: dict[str, Any] = {"name": name, "dsn": dsn}
        if description:
            body["description"] = description
        if db_type:
            body["db_type"] = db_type
        return _response_data(self.transport.invoke("databases", method="POST", body=body))

    def update_database(
        self,
        database_id: str,
        name: str | None = None,
        dsn: str | None = None,
        description: str | None = None,
        db_type: str | None = None,
    ) -> Any:
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if dsn is not None:
            body["dsn"] = dsn
        if description is not None:
            body["description"] = description
        if db_type is not None:
            body["db_type"] = db_type
        return _response_data(self.transport.invoke(f"databases/{database_id}", method="PUT", body=body))

    def delete_database(self, database_id: str) -> Any:
        return _response_data(self.transport.invoke(f"databases/{database_id}", method="DELETE"))

    def list_instances(self) -> Any:
        return _response_data(self.transport.invoke("instances", method="GET"))

    def get_instance(self, instance_id: str) -> Any:
        return _response_data(self.transport.invoke(f"instances/{instance_id}", method="GET"))

    def create_instance(self, name: str | None, database_id: str | None, organization_id: str | None) -> Any:
        body: dict[str, Any] = {}
        if name:
            body["name"] = name
        if database_id:
            body["database_id"] = database_id
        if organization_id:
            body["organization_id"] = organization_id
        return _response_data(self.transport.invoke("instances", method="POST", body=body))

    def delete_instance(self, instance_id: str) -> Any:
        return _response_data(self.transport.invoke(f"instances/{instance_id}", method="DELETE"))

    def list_branches(self, instance_id: str) -> Any:
        return _response_data(self.transport.invoke(f"instances/{instance_id}/branches", method="GET"))

    def create_branch(self, instance_id: str, branch_name: str, source_branch_slug: str | None) -> Any:
        body = {
            "branch_name": branch_name,
            "source_branch_slug": source_branch_slug or "main",
        }
        return _response_data(self.transport.invoke(f"instances/{instance_id}/branches", method="POST", body=body))

    def delete_branch(self, instance_id: str, branch_slug: str) -> Any:
        return _response_data(self.transport.invoke(f"instances/{instance_id}/branches/{branch_slug}", method="DELETE"))

    def switch_branch(self, instance_id: str, branch_name: str) -> Any:
        return self.transport.invoke(
            "sandbox-control/switch-branch",
            method="POST",
            body={"instance_id": instance_id, "branch_name": branch_name},
            instance_id=instance_id,
        )

    def run_sql(self, instance_id: str, sql: str, branch: str | None) -> Any:
        return self.transport.invoke(
            "sql-execute",
            method="POST",
            body={"instance_id": instance_id, "sql": sql, "branch": branch or "main"},
            instance_id=instance_id,
        )

    def publish_diff(self, instance_id: str, target: str = "prod") -> Any:
        return self.transport.invoke(
            f"sandbox-control/promote/diff?target={target}",
            method="POST",
            body={"instance_id": instance_id},
            instance_id=instance_id,
        )

    def publish_run(self, instance_id: str, sql: str, target: str = "prod") -> Iterable[dict[str, Any]]:
        resp = self.transport.invoke(
            f"sandbox-control/promote/execute?target={target}&stream=1",
            method="POST",
            body={"instance_id": instance_id, "sql": sql},
            headers={"Accept": "text/event-stream"},
            instance_id=instance_id,
            stream=True,
        )
        buffer = ""
        while True:
            chunk = resp.readline()
            if not chunk:
                break
            line = chunk.decode("utf-8")
            if line == "\n":
                buffer = ""
                continue
            if line.startswith("data:"):
                payload = line[5:].strip()
                if payload:
                    yield json.loads(payload)

    def sandbox_files_list(self, instance_id: str, path: str = "/", include_hidden: bool = False) -> Any:
        params = {
            "path": path,
            "instance_id": instance_id,
        }
        if include_hidden:
            params["includeHidden"] = "true"
        suffix = urlencode(params)
        return self.transport.invoke(f"sandbox-files/list?{suffix}", instance_id=instance_id)

    def sandbox_files_tree(self, instance_id: str, root: str = "/", max_depth: int = 3) -> Any:
        suffix = urlencode({"root": root, "maxDepth": max_depth, "instance_id": instance_id})
        return self.transport.invoke(
            f"sandbox-files/tree?{suffix}",
            instance_id=instance_id,
        )

    def sandbox_files_read(self, instance_id: str, path: str) -> Any:
        suffix = urlencode({"path": path, "instance_id": instance_id})
        return self.transport.invoke(
            f"sandbox-files/content?{suffix}",
            instance_id=instance_id,
        )

    def sandbox_files_create_file(self, instance_id: str, path: str, content: str) -> Any:
        return self.transport.invoke(
            "sandbox-files/create",
            method="POST",
            body={"type": "file", "path": path, "content": content, "instance_id": instance_id},
            instance_id=instance_id,
        )

    def sandbox_files_create_folder(self, instance_id: str, path: str) -> Any:
        return self.transport.invoke(
            "sandbox-files/create",
            method="POST",
            body={"type": "folder", "path": path, "instance_id": instance_id},
            instance_id=instance_id,
        )

    def sandbox_files_upload(self, instance_id: str, source_path: str, target_path: str) -> Any:
        file_bytes = Path(source_path).read_bytes()
        encoded = base64.b64encode(file_bytes).decode("ascii")
        return self.transport.invoke(
            "sandbox-files/upload",
            method="POST",
            body={
                "fileName": Path(source_path).name,
                "fileContent": encoded,
                "path": target_path,
                "instance_id": instance_id,
            },
            instance_id=instance_id,
        )

    def sandbox_files_delete(self, instance_id: str, path: str) -> Any:
        return self.transport.invoke(
            "sandbox-files/delete",
            method="POST",
            body={"path": path, "instance_id": instance_id},
            instance_id=instance_id,
        )

    def agent_providers(self, instance_id: str | None) -> Any:
        return self.transport.invoke(
            "sandbox-agent/providers",
            instance_id=instance_id,
            requires_auth=bool(instance_id),
        )

    def agent_status(self, instance_id: str, provider: str) -> Any:
        return self.transport.invoke(
            f"sandbox-agent/status?provider={provider}",
            instance_id=instance_id,
        )

    def agent_login_url(self, instance_id: str, provider: str) -> Any:
        return self.transport.invoke(
            f"sandbox-agent/login-url?provider={provider}",
            method="POST",
            body={},
            instance_id=instance_id,
        )

    def agent_opencode_config_get(self, instance_id: str) -> Any:
        return self.transport.invoke(
            "sandbox-agent/opencode-config",
            method="GET",
            instance_id=instance_id,
        )

    def agent_opencode_config_set(
        self,
        instance_id: str,
        provider: str,
        api_key: str,
        models: list[dict[str, Any]] | None = None,
    ) -> Any:
        body: dict[str, Any] = {"provider": provider, "apiKey": api_key}
        if models:
            body["models"] = models
        return self.transport.invoke(
            "sandbox-agent/opencode-config",
            method="POST",
            body=body,
            instance_id=instance_id,
        )

    def agent_opencode_config_delete(self, instance_id: str, provider: str) -> Any:
        suffix = urlencode({"provider": provider})
        return self.transport.invoke(
            f"sandbox-agent/opencode-config?{suffix}",
            method="DELETE",
            instance_id=instance_id,
        )

    def agent_custom_provider_create(
        self,
        instance_id: str,
        provider_id: str,
        name: str | None,
        base_url: str,
        api_key: str,
        models: list[dict[str, Any]],
    ) -> Any:
        body: dict[str, Any] = {
            "id": provider_id,
            "baseURL": base_url,
            "apiKey": api_key,
            "models": models,
        }
        if name:
            body["name"] = name
        return self.transport.invoke(
            "sandbox-agent/opencode-custom-provider",
            method="POST",
            body=body,
            instance_id=instance_id,
        )

    def agent_custom_provider_delete(self, instance_id: str, provider_id: str) -> Any:
        suffix = urlencode({"id": provider_id})
        return self.transport.invoke(
            f"sandbox-agent/opencode-custom-provider?{suffix}",
            method="DELETE",
            instance_id=instance_id,
        )

    def agent_opencode_json_set(self, instance_id: str, payload: dict[str, Any]) -> Any:
        return self.transport.invoke(
            "sandbox-agent/opencode-json",
            method="POST",
            body=payload,
            instance_id=instance_id,
        )

    def agent_chat(
        self,
        instance_id: str,
        message: str,
        *,
        session_id: str | None = None,
        provider: str | None = None,
        model: str | None = None,
        first_user_message: str | None = None,
        agent: str | None = None,
    ) -> Iterable[dict[str, Any]]:
        body: dict[str, Any] = {"message": message}
        if session_id:
            body["session_id"] = session_id
        if provider:
            body["provider"] = provider
        if model:
            body["model"] = model
        if first_user_message:
            body["first_user_message"] = first_user_message
        if agent:
            body["agent"] = agent
        resp = self.transport.invoke(
            "sandbox-agent/chat",
            method="POST",
            body=body,
            headers={"Accept": "text/event-stream"},
            instance_id=instance_id,
            stream=True,
        )
        while True:
            chunk = resp.readline()
            if not chunk:
                break
            line = chunk.decode("utf-8")
            if line.startswith("data:"):
                payload = line[5:].strip()
                if payload:
                    yield json.loads(payload)
