from __future__ import annotations

import json
import ssl
from dataclasses import dataclass
from typing import Any
from urllib import request
from urllib.error import HTTPError, URLError

from .config import BUNDLED_CA_CERT_SENTINEL, AppConfig, load_bundled_ca_cert
from .session import SessionError, SessionManager


class ApiError(RuntimeError):
    def __init__(self, message: str, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


@dataclass
class RequestContext:
    instance_id: str | None = None


class PowerbaseTransport:
    def __init__(self, config: AppConfig, session_manager: SessionManager) -> None:
        self.config = config
        self.session_manager = session_manager

    def _urlopen(self, req: request.Request):
        if self.config.tls_insecure:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            return request.urlopen(req, context=context)
        if self.config.ca_cert_file:
            if self.config.ca_cert_file == BUNDLED_CA_CERT_SENTINEL:
                bundled_ca_cert = load_bundled_ca_cert()
                if not bundled_ca_cert:
                    raise ApiError("Bundled test CA certificate is unavailable.")
                context = ssl.create_default_context(cadata=bundled_ca_cert)
            else:
                context = ssl.create_default_context(cafile=self.config.ca_cert_file)
            return request.urlopen(req, context=context)
        return request.urlopen(req)

    def _build_headers(
        self,
        *,
        auth_token: str | None,
        headers: dict[str, str] | None,
        instance_id: str | None,
    ) -> dict[str, str]:
        request_headers = {
            "apikey": self.config.anon_key,
            "Content-Type": "application/json",
        }
        if auth_token:
            request_headers["Authorization"] = f"Bearer {auth_token}"
        if instance_id:
            request_headers["X-Instance-ID"] = instance_id
        if headers:
            request_headers.update(headers)
        return request_headers

    def _send(self, req: request.Request, *, stream: bool) -> Any:
        resp = self._urlopen(req)
        if stream:
            return resp
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else {}

    def _parse_http_error(self, exc: HTTPError) -> ApiError:
        body_text = exc.read().decode("utf-8", errors="replace")
        try:
            data = json.loads(body_text)
        except json.JSONDecodeError:
            data = {"error": body_text}
        return ApiError(data.get("error") or body_text or exc.reason, exc.code)

    def invoke(
        self,
        function_path: str,
        *,
        method: str = "GET",
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        instance_id: str | None = None,
        requires_auth: bool = True,
        stream: bool = False,
    ) -> Any:
        if not self.config.base_url:
            raise ApiError("Powerbase base URL is not configured.")
        if not self.config.anon_key:
            raise ApiError("Powerbase anon key is not configured.")

        auth = self.session_manager.ensure_valid() if requires_auth else None
        url = f"{self.config.base_url.rstrip('/')}/functions/v1/{function_path}"
        payload = None if body is None else json.dumps(body).encode("utf-8")
        request_headers = self._build_headers(
            auth_token=auth.session.access_token if auth else None,
            headers=headers,
            instance_id=instance_id,
        )
        req = request.Request(url, data=payload, headers=request_headers, method=method.upper())

        try:
            return self._send(req, stream=stream)
        except HTTPError as exc:
            if exc.code == 401 and auth and auth.session.refresh_token:
                try:
                    refreshed_auth = self.session_manager.refresh(auth)
                except SessionError as refresh_error:
                    raise ApiError(str(refresh_error), 401) from refresh_error
                retry_headers = self._build_headers(
                    auth_token=refreshed_auth.session.access_token,
                    headers=headers,
                    instance_id=instance_id,
                )
                retry_req = request.Request(url, data=payload, headers=retry_headers, method=method.upper())
                try:
                    return self._send(retry_req, stream=stream)
                except HTTPError as retry_exc:
                    raise self._parse_http_error(retry_exc) from retry_exc
            raise self._parse_http_error(exc) from exc
        except URLError as exc:
            raise ApiError(f"Request failed: {exc.reason}") from exc
        except ssl.SSLError as exc:
            raise ApiError(f"Request failed: {exc}") from exc

