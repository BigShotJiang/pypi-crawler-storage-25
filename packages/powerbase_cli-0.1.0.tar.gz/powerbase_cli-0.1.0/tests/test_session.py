from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from powerbase_cli.config import BUNDLED_CA_CERT_SENTINEL, AuthSession, AuthState, ConfigStore
from powerbase_cli.session import SessionManager


class FakeResponse:
    def __init__(self, payload: dict[str, object]) -> None:
        self.payload = payload

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def read(self) -> bytes:
        return json.dumps(self.payload).encode("utf-8")


class SessionManagerTests(unittest.TestCase):
    def test_refresh_updates_saved_auth_file(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            store.save_auth(
                AuthState(
                    source="login",
                    base_url="https://console.example.com",
                    anon_key="anon",
                    session=AuthSession(
                        access_token="old-access",
                        refresh_token="old-refresh",
                        expires_at=1,
                    ),
                )
            )
            manager = SessionManager(store, "https://console.example.com", "anon")

            with mock.patch("powerbase_cli.session.request.urlopen", return_value=FakeResponse({
                "access_token": "new-access",
                "refresh_token": "new-refresh",
                "expires_at": 9999999999,
                "token_type": "bearer",
                "user": {"id": "user-1"},
            })):
                refreshed = manager.refresh()

            self.assertEqual(refreshed.session.access_token, "new-access")
            saved = store.load_auth()
            assert saved is not None
            self.assertEqual(saved.session.refresh_token, "new-refresh")

    def test_env_session_can_refresh_without_writing_auth_file(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            manager = SessionManager(store, "https://console.example.com", "anon")
            old_env = dict(os.environ)
            try:
                os.environ["POWERBASE_ACCESS_TOKEN"] = "env-access"
                os.environ["POWERBASE_REFRESH_TOKEN"] = "env-refresh"
                os.environ["POWERBASE_EXPIRES_AT"] = "1"
                os.environ["POWERBASE_BASE_URL"] = "https://console.example.com"
                os.environ["POWERBASE_ANON_KEY"] = "anon"
                with mock.patch("powerbase_cli.session.request.urlopen", return_value=FakeResponse({
                    "access_token": "env-new-access",
                    "refresh_token": "env-new-refresh",
                    "expires_at": 9999999999,
                    "token_type": "bearer",
                })):
                    refreshed = manager.ensure_valid()
                assert refreshed is not None
                self.assertEqual(refreshed.session.access_token, "env-new-access")
                self.assertFalse(store.auth_path.exists())
            finally:
                os.environ.clear()
                os.environ.update(old_env)

    def test_refresh_uses_unverified_tls_context_when_insecure(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            store.save_auth(
                AuthState(
                    source="login",
                    base_url="https://console.example.com",
                    anon_key="anon",
                    session=AuthSession(access_token="old-access", refresh_token="old-refresh", expires_at=1),
                )
            )
            manager = SessionManager(store, "https://console.example.com", "anon", tls_insecure=True)

            with mock.patch(
                "powerbase_cli.session.request.urlopen",
                return_value=FakeResponse(
                    {
                        "access_token": "new-access",
                        "refresh_token": "new-refresh",
                        "expires_at": 9999999999,
                        "token_type": "bearer",
                    }
                ),
            ) as urlopen_mock:
                manager.refresh()

            context = urlopen_mock.call_args.kwargs["context"]
            self.assertFalse(context.check_hostname)

    def test_refresh_uses_ca_cert_context_when_configured(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            store.save_auth(
                AuthState(
                    source="login",
                    base_url="https://console.example.com",
                    anon_key="anon",
                    session=AuthSession(access_token="old-access", refresh_token="old-refresh", expires_at=1),
                )
            )
            manager = SessionManager(store, "https://console.example.com", "anon", ca_cert_file="/tmp/test-ca.pem")

            with mock.patch("powerbase_cli.session.ssl.create_default_context") as context_factory:
                fake_context = object()
                context_factory.return_value = fake_context
                with mock.patch(
                    "powerbase_cli.session.request.urlopen",
                    return_value=FakeResponse(
                        {
                            "access_token": "new-access",
                            "refresh_token": "new-refresh",
                            "expires_at": 9999999999,
                            "token_type": "bearer",
                        }
                    ),
                ) as urlopen_mock:
                    manager.refresh()

            context_factory.assert_called_once_with(cafile="/tmp/test-ca.pem")
            self.assertIs(urlopen_mock.call_args.kwargs["context"], fake_context)

    def test_refresh_uses_bundled_ca_cert_when_configured(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            store.save_auth(
                AuthState(
                    source="login",
                    base_url="https://console.example.com",
                    anon_key="anon",
                    session=AuthSession(access_token="old-access", refresh_token="old-refresh", expires_at=1),
                )
            )
            manager = SessionManager(store, "https://console.example.com", "anon", ca_cert_file=BUNDLED_CA_CERT_SENTINEL)

            with mock.patch("powerbase_cli.session.load_bundled_ca_cert", return_value="PEM DATA") as bundled_cert:
                with mock.patch("powerbase_cli.session.ssl.create_default_context") as context_factory:
                    fake_context = object()
                    context_factory.return_value = fake_context
                    with mock.patch(
                        "powerbase_cli.session.request.urlopen",
                        return_value=FakeResponse(
                            {
                                "access_token": "new-access",
                                "refresh_token": "new-refresh",
                                "expires_at": 9999999999,
                                "token_type": "bearer",
                            }
                        ),
                    ) as urlopen_mock:
                        manager.refresh()

            bundled_cert.assert_called_once_with()
            context_factory.assert_called_once_with(cadata="PEM DATA")
            self.assertIs(urlopen_mock.call_args.kwargs["context"], fake_context)

