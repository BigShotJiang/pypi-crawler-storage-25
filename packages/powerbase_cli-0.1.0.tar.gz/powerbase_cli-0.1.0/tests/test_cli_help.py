from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from powerbase_cli.cli import build_parser
from powerbase_cli.commands.parser import main as parser_main
from powerbase_cli.commands.parser import normalize_global_argv


class CliHelpTests(unittest.TestCase):
    def test_root_help_mentions_resolution_order(self) -> None:
        parser = build_parser()
        help_text = parser.format_help()
        self.assertIn("command flags", help_text)
        self.assertIn("environment", help_text)
        self.assertIn("Operate Powerbase console workflows", help_text)
        self.assertIn("--insecure", help_text)
        self.assertIn("--ca-cert", help_text)

    def test_auth_login_help_mentions_timeout(self) -> None:
        parser = build_parser()
        auth_parser = parser._subparsers._group_actions[0].choices["auth"]
        login_parser = auth_parser._subparsers._group_actions[0].choices["login"]
        help_text = login_parser.format_help()
        self.assertIn("--timeout", help_text)
        self.assertIn("300", help_text)

    def test_auth_token_set_help_mentions_refresh_token(self) -> None:
        parser = build_parser()
        auth_parser = parser._subparsers._group_actions[0].choices["auth"]
        token_parser = auth_parser._subparsers._group_actions[0].choices["token-set"]
        help_text = token_parser.format_help()
        self.assertIn("refresh token", help_text.lower())
        self.assertIn("auto-refresh", help_text)

    def test_context_use_instance_help_mentions_source(self) -> None:
        parser = build_parser()
        context_parser = parser._subparsers._group_actions[0].choices["context"]
        use_parser = context_parser._subparsers._group_actions[0].choices["use-instance"]
        help_text = use_parser.format_help()
        self.assertIn("powerbase instance list", help_text)
        self.assertIn("context show", help_text)

    def test_database_create_help_mentions_instance_create_dependency(self) -> None:
        parser = build_parser()
        database_parser = parser._subparsers._group_actions[0].choices["database"]
        create_parser = database_parser._subparsers._group_actions[0].choices["create"]
        help_text = create_parser.format_help()
        self.assertIn("powerbase instance", help_text)
        self.assertIn("--database-id", help_text)
        self.assertIn("--dsn", help_text)

    def test_agent_chat_help_mentions_stream_jsonl(self) -> None:
        parser = build_parser()
        agent_parser = parser._subparsers._group_actions[0].choices["agent"]
        chat_parser = agent_parser._subparsers._group_actions[0].choices["chat"]
        help_text = chat_parser.format_help()
        self.assertIn("sandbox agent", help_text)
        self.assertIn("stream-jsonl", help_text)
        self.assertIn("feature-branch preview", help_text)

    def test_agent_help_does_not_expose_custom_provider_commands(self) -> None:
        parser = build_parser()
        agent_parser = parser._subparsers._group_actions[0].choices["agent"]
        subcommands = agent_parser._subparsers._group_actions[0].choices
        self.assertNotIn("custom-provider", subcommands)

    def test_instance_create_help_mentions_retry_window(self) -> None:
        parser = build_parser()
        instance_parser = parser._subparsers._group_actions[0].choices["instance"]
        create_parser = instance_parser._subparsers._group_actions[0].choices["create"]
        help_text = create_parser.format_help()
        self.assertIn("retry window", help_text)
        self.assertIn("instance get", help_text)

    def test_branch_delete_help_mentions_normalized_slug(self) -> None:
        parser = build_parser()
        branch_parser = parser._subparsers._group_actions[0].choices["branch"]
        delete_parser = branch_parser._subparsers._group_actions[0].choices["delete"]
        help_text = delete_parser.format_help()
        self.assertIn("normalized branch slug", help_text)
        self.assertIn("feature/foo", help_text)

    def test_config_get_help_mentions_json_flag_priority(self) -> None:
        parser = build_parser()
        config_parser = parser._subparsers._group_actions[0].choices["config"]
        get_parser = config_parser._subparsers._group_actions[0].choices["get"]
        help_text = get_parser.format_help()
        self.assertIn("--json", help_text)
        self.assertIn("config.toml says `text`", help_text)

    def test_normalize_global_argv_moves_root_flags_forward(self) -> None:
        normalized = normalize_global_argv(["auth", "status", "--json", "--config-dir", "/tmp/pb", "--insecure"])
        self.assertEqual(normalized, ["--json", "--config-dir", "/tmp/pb", "--insecure", "auth", "status"])

    def test_main_normalizes_sys_argv_when_called_without_explicit_args(self) -> None:
        with mock.patch.object(sys, "argv", ["powerbase", "auth", "status", "--json"]):
            with mock.patch("powerbase_cli.commands.parser.build_parser") as build_parser_mock:
                parser = mock.Mock()
                parser.parse_args.return_value = mock.Mock(handler=lambda args: 0)
                build_parser_mock.return_value = parser
                exit_code = parser_main()

        self.assertEqual(exit_code, 0)
        parsed_argv = parser.parse_args.call_args.args[0]
        self.assertEqual(parsed_argv, ["--json", "auth", "status"])
