from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from powerbase_cli.api import PowerbaseApi


class FakeTransport:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def invoke(self, function_path: str, **kwargs):
        self.calls.append({"function_path": function_path, **kwargs})
        return {"success": True, "data": {"ok": True}}


class ApiTests(unittest.TestCase):
    def test_database_create_builds_expected_request(self) -> None:
        transport = FakeTransport()
        api = PowerbaseApi(transport)
        api.create_database("todo-db", "mysql://dsn", "todo data", "mysql")
        call = transport.calls[0]
        self.assertEqual(call["function_path"], "databases")
        self.assertEqual(call["method"], "POST")
        self.assertEqual(call["body"]["name"], "todo-db")
        self.assertEqual(call["body"]["db_type"], "mysql")

    def test_sql_run_builds_expected_request(self) -> None:
        transport = FakeTransport()
        api = PowerbaseApi(transport)
        api.run_sql("inst-1", "SELECT 1", "main")
        call = transport.calls[0]
        self.assertEqual(call["function_path"], "sql-execute")
        self.assertEqual(call["instance_id"], "inst-1")
        self.assertEqual(call["body"]["branch"], "main")

    def test_branch_create_uses_instances_endpoint(self) -> None:
        transport = FakeTransport()
        api = PowerbaseApi(transport)
        api.create_branch("inst-1", "feature/demo", "main")
        call = transport.calls[0]
        self.assertEqual(call["function_path"], "instances/inst-1/branches")
        self.assertEqual(call["method"], "POST")

    def test_start_cli_login_does_not_require_existing_auth(self) -> None:
        transport = FakeTransport()
        api = PowerbaseApi(transport)
        api.start_cli_login()
        call = transport.calls[0]
        self.assertFalse(call["requires_auth"])

    def test_agent_custom_provider_delete_uses_query_id(self) -> None:
        transport = FakeTransport()
        api = PowerbaseApi(transport)
        api.agent_custom_provider_delete("inst-1", "openai-compatible")
        call = transport.calls[0]
        self.assertEqual(call["function_path"], "sandbox-agent/opencode-custom-provider?id=openai-compatible")
        self.assertEqual(call["method"], "DELETE")
