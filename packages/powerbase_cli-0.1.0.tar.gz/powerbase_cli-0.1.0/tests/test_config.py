from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from powerbase_cli.config import (
    DEFAULT_ANON_KEY,
    DEFAULT_BASE_URL,
    AppConfig,
    AuthSession,
    AuthState,
    ConfigStore,
    ContextState,
    load_bundled_ca_cert,
    merge_config_with_env,
    merge_context_with_env,
)


class ConfigStoreTests(unittest.TestCase):
    def test_load_bundled_ca_cert_returns_pem(self) -> None:
        cert_pem = load_bundled_ca_cert()
        assert cert_pem is not None
        self.assertIn("BEGIN CERTIFICATE", cert_pem)

    def test_app_config_uses_builtin_service_defaults(self) -> None:
        config = AppConfig()
        self.assertEqual(config.base_url, DEFAULT_BASE_URL)
        self.assertEqual(config.anon_key, DEFAULT_ANON_KEY)

    def test_config_store_accepts_string_base_dir(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(temp_dir)
            store.save_config(AppConfig(base_url="https://console.example.com", anon_key="anon"))
            self.assertEqual(store.base_dir, Path(temp_dir))
            self.assertTrue(store.config_path.exists())

    def test_save_config_omits_builtin_service_defaults(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(temp_dir)
            store.save_config(AppConfig())
            self.assertEqual(store.config_path.read_text(encoding="utf-8"), 'output = "text"\n')

    def test_save_and_load_auth(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            auth = AuthState(
                source="login",
                base_url="https://console.example.com",
                anon_key="anon",
                session=AuthSession(access_token="access", refresh_token="refresh", expires_at=123),
                user={"id": "u1", "email": "u@example.com"},
                updated_at="2026-04-03T00:00:00Z",
            )
            store.save_auth(auth)

            loaded = store.load_auth()
            assert loaded is not None
            self.assertEqual(loaded.session.access_token, "access")
            self.assertEqual(loaded.session.refresh_token, "refresh")
            self.assertEqual(loaded.user["id"], "u1")

    def test_save_and_load_context(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            context = ContextState(instance_id="i1", org_id="o1", branch="main", updated_at="now")
            store.save_context(context)
            loaded = store.load_context()
            self.assertEqual(loaded.instance_id, "i1")
            self.assertEqual(loaded.org_id, "o1")
            self.assertEqual(loaded.branch, "main")

    def test_merge_env_overrides(self) -> None:
        old = dict(os.environ)
        try:
            os.environ["POWERBASE_BASE_URL"] = "https://env.example.com"
            os.environ["POWERBASE_INSTANCE_ID"] = "env-instance"
            os.environ["POWERBASE_TLS_INSECURE"] = "true"
            os.environ["POWERBASE_CA_CERT_FILE"] = "/tmp/test-ca.pem"
            merged_config = merge_config_with_env(AppConfig(base_url="https://file.example.com", anon_key="a"))
            merged_context = merge_context_with_env(ContextState(instance_id="file-instance", branch="main"))
            self.assertEqual(merged_config.base_url, "https://env.example.com")
            self.assertTrue(merged_config.tls_insecure)
            self.assertEqual(merged_config.ca_cert_file, "/tmp/test-ca.pem")
            self.assertEqual(merged_context.instance_id, "env-instance")
        finally:
            os.environ.clear()
            os.environ.update(old)
