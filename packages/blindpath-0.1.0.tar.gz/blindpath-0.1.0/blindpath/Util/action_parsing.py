"""
blindpath/Util/action_parsing.py

Extracts a valid BlindPath action from raw LLM output.
"""

from __future__ import annotations

import json
import re
from typing import Optional

from blindpath.core.env import ACTIONS


def parse_action(raw: str) -> Optional[str]:
    """
    Try to extract a valid action string from raw LLM output.

    Extracts the first JSON object/array from the response,
    then checks for a valid "action" field.
    Returns None if no valid action could be extracted.
    """
    match = re.search(r'(\{.*?\}|\[.*?\])', raw, re.DOTALL)
    if not match:
        return None

    try:
        data = json.loads(match.group(0))
        action = data.get("action", "")
        if action in ACTIONS:
            return action
    except (json.JSONDecodeError, AttributeError):
        pass

    return None
