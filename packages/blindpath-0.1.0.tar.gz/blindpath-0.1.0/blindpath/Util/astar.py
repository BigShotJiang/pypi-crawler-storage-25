"""
blindpath/Util/astar.py

A* pathfinding on a BlindPath grid.
"""

import heapq
import math
from typing import List, Optional

import numpy as np

from blindpath.DataClasses.vector2 import Vector2
from blindpath.Constants.tiles import OBSTACLE

# ---------------------------------------------------------------------------
# Directional offsets (shared with other grid algorithms via import)
# ---------------------------------------------------------------------------

NEIGHBOURS: List[Vector2] = [
    Vector2(0, -1),   # Up
    Vector2(0,  1),   # Down
    Vector2(-1, 0),   # Left
    Vector2( 1, 0),   # Right
]


def astar(
    grid: List[List[str]],
    start: Vector2,
    goal: Vector2,
    *,
    cost_grid: Optional[np.ndarray] = None,
) -> Optional[List[Vector2]]:
    """
    A* from *start* to *goal*.

    Parameters
    ----------
    grid : Grid
        The map. 'O' cells are impassable.
    start, goal : Vector2
        Source and target positions (column=x, row=y).
    cost_grid : np.ndarray | None
        If given, adds per-cell movement cost on top of the base cost-1.
        Used during generation to produce naturalistically winding paths.

    Returns
    -------
    List[Vector2] | None
        Ordered list of positions (excluding *start*, including *goal*),
        or None if no path exists.
    """
    rows = len(grid)
    cols = len(grid[0]) if rows else 0

    def h(pos: Vector2) -> float:
        return pos.manhattan(goal)

    def cell_cost(pos: Vector2) -> float:
        base = 1.0
        if cost_grid is not None:
            base += float(cost_grid[pos.y, pos.x])
        return base

    counter = 0   # tie-breaker so Vector2 is never compared by heapq
    open_heap: list = []
    heapq.heappush(open_heap, (h(start), 0.0, counter, start))
    came_from: dict[Vector2, Optional[Vector2]] = {start: None}
    g_score: dict[Vector2, float] = {start: 0.0}

    while open_heap:
        _, g, _, current = heapq.heappop(open_heap)

        if g > g_score.get(current, math.inf):
            continue   # stale entry

        if current == goal:
            # Reconstruct
            path: List[Vector2] = []
            node: Optional[Vector2] = current
            while node is not None and node != start:
                path.append(node)
                node = came_from[node]
            path.reverse()
            return path

        for delta in NEIGHBOURS:
            nb = current + delta
            if not (0 <= nb.x < cols and 0 <= nb.y < rows):
                continue
            if grid[nb.y][nb.x] == OBSTACLE and nb != goal:
                continue
            tentative_g = g_score[current] + cell_cost(nb)
            if tentative_g < g_score.get(nb, math.inf):
                g_score[nb] = tentative_g
                came_from[nb] = current
                f = tentative_g + h(nb)
                counter += 1
                heapq.heappush(open_heap, (f, tentative_g, counter, nb))

    return None   # no path
