"""
blindpath/Util/grid_formatting.py

Display utilities for BlindPath grids.

Cartesian formats  — each tile as an individual data point with coordinates.
Topography formats — full grid rendered as a 2D map.
"""

from __future__ import annotations

import json
import string
from typing import List

from blindpath.Constants.tiles import TILE_WORDS
from blindpath.core.grid import Grid


# ---------------------------------------------------------------------------
# Cartesian
# ---------------------------------------------------------------------------

def grid_to_json(grid: Grid) -> str:
    """
    Each grid point as a JSON object with x, y coordinates and label,
    wrapped in a root object with grid dimensions.

    Example: {"rows": 3, "cols": 3, "tiles": [{"x": 0, "y": 0, "label": "E"}, ...]}
    """
    tiles: List[dict] = []
    for y, row in enumerate(grid):
        for x, label in enumerate(row):
            tiles.append({"x": x, "y": y, "label": label})
    return json.dumps({"matrix_y_size": len(grid), "matrix_x_size": len(grid[0]), "tiles": tiles})


def grid_to_chess(grid: Grid) -> str:
    """
    Each grid point as a JSON object using chess notation for coordinates,
    wrapped in a root object with grid dimensions.

    Columns map to letters (a-z), rows count from the bottom (1-based).
    Example: {"rows": 3, "cols": 3, "tiles": [{"pos": "a3", "label": "E"}, ...]}
    """
    rows = len(grid)
    tiles: List[dict] = []
    for y, row in enumerate(grid):
        rank = rows - y  # chess ranks count from bottom
        for x, label in enumerate(row):
            file = string.ascii_lowercase[x] if x < 26 else f"c{x}"
            tiles.append({"pos": f"{file}{rank}", "label": label})
    return json.dumps({"matrix_y_size": rows, "matrix_x_size": len(grid[0]), "tiles": tiles})


# ---------------------------------------------------------------------------
# Topography
# ---------------------------------------------------------------------------

def grid_to_ascii(grid: Grid) -> str:
    """Convert a 2D grid to a compact ASCII string, one row per line."""
    return "\n".join(" ".join(row) for row in grid)


def grid_to_word(grid: Grid) -> str:
    """
    Like ASCII but each tile is a full word instead of a single letter.

    Uses TILE_WORDS mapping from Constants. Unknown labels pass through as-is.
    Words are space-separated, one row per line.
    """
    lines: List[str] = []
    for row in grid:
        words = [TILE_WORDS.get(tile, tile) for tile in row]
        lines.append(" ".join(words))
    return "\n".join(lines)


_UNIQUE_TILES = {"A", "G"}


def _ordinal(n: int) -> str:
    """Return the ordinal string for a 1-based number: 1st, 2nd, 3rd, 4th..."""
    if 11 <= n % 100 <= 13:
        return f"{n}th"
    return f"{n}{('th','st','nd','rd')[min(n % 10, 4)] if n % 10 < 4 else 'th'}"


def _describe_group(label: str, count: int) -> str:
    """Describe a run of identical tiles in natural language."""
    word = TILE_WORDS.get(label, label).lower()
    if label in _UNIQUE_TILES:
        return f"the {word}"
    cell = "cell" if count == 1 else "cells"
    return f"{count} {word} {cell}"


def _run_length_groups(tiles: List[str]) -> List[tuple[str, int]]:
    """Group consecutive identical tiles into (label, count) pairs."""
    groups: List[tuple[str, int]] = []
    for tile in tiles:
        if groups and groups[-1][0] == tile:
            groups[-1] = (tile, groups[-1][1] + 1)
        else:
            groups.append((tile, 1))
    return groups


def grid_to_row_narrative(grid: Grid) -> str:
    """
    Natural language description of the grid, row by row.

    Groups consecutive identical tiles and describes each run.
    Example: "The 1st row has 3 empty cells, then the goal, then 1 empty cell."
    """
    sentences: List[str] = []
    for i, row in enumerate(grid):
        groups = _run_length_groups(list(row))
        parts = [_describe_group(label, count) for label, count in groups]
        sentences.append(f"The {_ordinal(i + 1)} row has {', then '.join(parts)}.")
    return "\n".join(sentences)


def grid_to_col_narrative(grid: Grid) -> str:
    """
    Natural language description of the grid, column by column.

    Groups consecutive identical tiles and describes each run.
    Example: "The 1st column has 3 empty cells, then the agent, then 1 empty cell."
    """
    sentences: List[str] = []
    cols = grid.cols if hasattr(grid, 'cols') else len(grid[0])
    for x in range(cols):
        column = [grid[y][x] for y in range(len(grid))]
        groups = _run_length_groups(column)
        parts = [_describe_group(label, count) for label, count in groups]
        sentences.append(f"The {_ordinal(x + 1)} column has {', then '.join(parts)}.")
    return "\n".join(sentences)
