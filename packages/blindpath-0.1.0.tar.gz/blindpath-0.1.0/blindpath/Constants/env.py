"""
Constants for BlindPath environment configuration.
"""

from typing import Tuple

# ---------------------------------------------------------------------------
# Default values
# ---------------------------------------------------------------------------

DEFAULT_SEED: None = None
DEFAULT_ENV_SIZE: Tuple[int, int] = (40, 40)
DEFAULT_NUM_GOALS: int = 1
DEFAULT_OBSTACLE_COUNT: int = 0
DEFAULT_VISION_SIZE: int = 11

# ---------------------------------------------------------------------------
# Minimum allowed values
# ---------------------------------------------------------------------------

MIN_ENV_DIMENSION: int = 5
MIN_VISION_SIZE: int = 3
MIN_NUM_GOALS: int = 1
MIN_OBSTACLE_COUNT: int = 0
