"""
blindpath/Constants/tiles.py

Single-character tile labels used throughout the grid system.
"""

AGENT = "A"
EMPTY = "E"
OBSTACLE = "O"
GOAL = "G"
BOUNDARY = "B"

TILE_WORDS: dict[str, str] = {
    AGENT: "Agent",
    EMPTY: "Empty",
    OBSTACLE: "Obstacle",
    GOAL: "Goal",
    BOUNDARY: "Boundary",
}
