from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Vector2:
    x: int   # column
    y: int   # row (0 = top)

    def __add__(self, other: Vector2) -> Vector2:
        return Vector2(self.x + other.x, self.y + other.y)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Vector2):
            return NotImplemented
        return self.x == other.x and self.y == other.y

    def __hash__(self) -> int:
        return hash((self.x, self.y))

    def __repr__(self) -> str:
        return f"Vector2({self.x}, {self.y})"

    def manhattan(self, other: Vector2) -> int:
        return abs(self.x - other.x) + abs(self.y - other.y)
