from dataclasses import dataclass

from blindpath.DataClasses.vector2 import Vector2
from blindpath.core.grid import Grid


@dataclass
class StepResult:
    """Returned by BlindPathEnv.step()."""
    vision_grid: Grid          # NxN vision window (LLM input)
    full_grid: Grid            # Full grid (debug only)
    agent_position: Vector2
    goals_remaining: int
    done: bool                 # episode finished (success OR timeout)
    success: bool              # all goals reached
    timed_out: bool
    legal: bool                # was the attempted action legal?
    iteration: int
