from dataclasses import dataclass
from typing import List

from blindpath.DataClasses.vector2 import Vector2
from blindpath.core.grid import Grid


@dataclass
class GeneratedMap:
    grid: Grid
    agent_start: Vector2
    goals: List[Vector2]
    optimal_path_len: int
    accessible_tiles: int
    accessible_vision_tiles: int
