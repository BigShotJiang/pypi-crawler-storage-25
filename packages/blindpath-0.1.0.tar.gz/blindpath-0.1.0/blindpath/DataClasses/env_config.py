from dataclasses import dataclass
from typing import Optional, Tuple

from blindpath.Constants.env import (
    DEFAULT_SEED,
    DEFAULT_ENV_SIZE,
    DEFAULT_NUM_GOALS,
    DEFAULT_OBSTACLE_COUNT,
    DEFAULT_VISION_SIZE,
    MIN_ENV_DIMENSION,
    MIN_VISION_SIZE,
    MIN_NUM_GOALS,
    MIN_OBSTACLE_COUNT,
)


@dataclass
class EnvConfig:
    """All hyperparameters for one BlindPath environment instance."""

    seed: Optional[int] = DEFAULT_SEED
    env_size: Tuple[int, int] = DEFAULT_ENV_SIZE
    num_goals: int = DEFAULT_NUM_GOALS
    obstacle_count: int = DEFAULT_OBSTACLE_COUNT
    vision_size: int = DEFAULT_VISION_SIZE

    def __post_init__(self) -> None:
        rows, cols = self.env_size
        if rows < MIN_ENV_DIMENSION or cols < MIN_ENV_DIMENSION:
            raise ValueError(f"env_size must be at least {MIN_ENV_DIMENSION}x{MIN_ENV_DIMENSION}")
        if self.vision_size < MIN_VISION_SIZE:
            raise ValueError(f"vision_size must be at least {MIN_VISION_SIZE}")
        if self.vision_size % 2 == 0:
            raise ValueError("vision_size must be odd")
        if self.vision_size > min(rows, cols):
            raise ValueError("vision_size cannot exceed the environment size")
        if self.num_goals < MIN_NUM_GOALS:
            raise ValueError(f"num_goals must be >= {MIN_NUM_GOALS}")
        if self.obstacle_count < MIN_OBSTACLE_COUNT:
            raise ValueError(f"obstacle_count must be >= {MIN_OBSTACLE_COUNT}")
