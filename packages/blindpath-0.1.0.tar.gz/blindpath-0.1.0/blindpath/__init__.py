"""
blindpath — Public API
"""

from blindpath.core.env import BlindPathEnv, ACTIONS
from blindpath.DataClasses.env_config import EnvConfig
from blindpath.DataClasses.step_result import StepResult
from blindpath.DataClasses.vector2 import Vector2
from blindpath.DataClasses.generated_map import GeneratedMap
from blindpath.core.grid import Grid
from blindpath.Constants.tiles import AGENT, EMPTY, OBSTACLE, GOAL, BOUNDARY
from blindpath.Util.grid_formatting import grid_to_ascii, grid_to_json, grid_to_chess, grid_to_word, grid_to_row_narrative, grid_to_col_narrative
from blindpath.Util.action_parsing import parse_action
from blindpath.core.map_generation import generate_map
from blindpath.agents.base import BaseAgent
from blindpath.agents.random_agent import RandomAgent
from blindpath.agents.pomcp_agent import POMCPAgent
from blindpath.agents.llm_agent import LLMAgent
from blindpath.eval.episode_metrics import EpisodeMetrics
from blindpath.eval.benchmark_results import BenchmarkResults
from blindpath.session import Session
from importlib.metadata import version as _version

__version__ = _version("blindpath")

__all__ = [
    # Environment
    "BlindPathEnv",
    "EnvConfig",
    "StepResult",
    "ACTIONS",
    # Grid
    "Vector2",
    "Grid",
    "generate_map",
    "grid_to_ascii",
    "grid_to_json",
    "grid_to_chess",
    "grid_to_word",
    "grid_to_row_narrative",
    "grid_to_col_narrative",
    "parse_action",
    # Agents
    "BaseAgent",
    "RandomAgent",
    "POMCPAgent",
    "LLMAgent",
    # Metrics
    "EpisodeMetrics",
    "BenchmarkResults",
    # Session
    "Session",
]
