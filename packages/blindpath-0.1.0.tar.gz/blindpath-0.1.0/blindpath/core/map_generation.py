"""
blindpath/core/grid.py

Procedural map generation for BlindPath grids.
"""

from __future__ import annotations

import random
from typing import List, Optional, Tuple

import numpy as np

from blindpath.DataClasses.vector2 import Vector2
from blindpath.DataClasses.generated_map import GeneratedMap
from blindpath.core.grid import Grid
from blindpath.Constants.tiles import AGENT, EMPTY, OBSTACLE, GOAL
from blindpath.Util.astar import astar

# ---------------------------------------------------------------------------
# Retry budgets for randomised placement
# ---------------------------------------------------------------------------

_START_GOAL_ATTEMPTS = 30
_EXTRA_GOAL_ATTEMPTS = 50


# ---------------------------------------------------------------------------
# Grid generation
# ---------------------------------------------------------------------------


def _quadrant_bounds(rows: int, cols: int) -> List[Tuple[int, int, int, int]]:
    """
    Returns (row_min, row_max, col_min, col_max) for each quadrant [0..3]
    (top-left, top-right, bottom-left, bottom-right).
    Half-row / half-col excludes the middle line on odd-dimension grids.
    """
    rh = rows // 2
    ch = cols // 2
    return [
        (0,    rh,    0,    ch),     # top-left
        (0,    rh,    ch,   cols),   # top-right
        (rh,   rows,  0,    ch),     # bottom-left
        (rh,   rows,  ch,   cols),   # bottom-right
    ]


def _random_point_in_quadrant(
    rng: random.Random,
    r_min: int, r_max: int, c_min: int, c_max: int,
) -> Vector2:
    row = rng.randint(r_min, r_max - 1)
    col = rng.randint(c_min, c_max - 1)
    return Vector2(col, row)


def _choose_start_goal(
    rng: random.Random,
    rows: int,
    cols: int,
) -> Tuple[Vector2, Vector2]:
    """
    Sector Allocation + Radius Exclusion to pick well-separated start and goal.
    """
    quads = _quadrant_bounds(rows, cols)  # 4 quadrant bounds

    # Choose agent quadrant
    agent_qi = rng.randint(0, 3)

    # Weighted choice for goal quadrant: 60% opposite, 20% each adjacent, 0% same
    opposite = {0: 3, 1: 2, 2: 1, 3: 0}[agent_qi]
    goal_weights = [0.0, 0.0, 0.0, 0.0]
    goal_weights[opposite] = 0.6
    for i in range(4):
        if i != agent_qi and i != opposite:
            goal_weights[i] = 0.2

    goal_qi = rng.choices(range(4), weights=goal_weights, k=1)[0]

    min_dist = (rows + cols) * 0.25   # ~half the average dimension

    best_pair: Optional[Tuple[Vector2, Vector2]] = None
    best_dist = -1.0

    for _ in range(_START_GOAL_ATTEMPTS):
        a = _random_point_in_quadrant(rng, *quads[agent_qi])
        g = _random_point_in_quadrant(rng, *quads[goal_qi])
        d = a.manhattan(g)
        if d > best_dist:
            best_dist = d
            best_pair = (a, g)
        if d >= min_dist:
            break

    assert best_pair is not None
    return best_pair


def generate_map(
    rows: int,
    cols: int,
    *,
    num_goals: int = 1,
    obstacle_count: int = 0,
    vision_size: int = 11,
    seed: Optional[int] = None,
) -> GeneratedMap:
    """
    Full procedural map generation as described in the BlindPath spec.

    Steps
    -----
    1. Choose agent start + first goal via Sector Allocation / Radius Exclusion.
    2. Assign random weights to every cell (1-100).
    3. Run A* with those weights to find a natural, winding guaranteed path.
    4. Lock path cells.
    5. Place additional goals (each guaranteed reachable from the previous goal).
    6. Sprinkle obstacles into unlocked cells.
    7. Compute stats.
    """
    rng = random.Random(seed)
    np_rng = np.random.default_rng(seed)

    # 1. Initialise grid
    grid = Grid([[EMPTY] * cols for _ in range(rows)])

    # 2. Choose start + primary goal
    agent_start, first_goal = _choose_start_goal(rng, rows, cols)

    # 3. Assign random per-cell weights (used to make the path wander)
    weight_map = np_rng.integers(1, 101, size=(rows, cols)).astype(float)

    # 4. Carve winding path: start -> first_goal
    locked: set[Tuple[int, int]] = set()

    def carve_path(src: Vector2, dst: Vector2) -> bool:
        path = astar(grid.matrix, src, dst, cost_grid=weight_map)
        if path is None:
            return False
        for p in path:
            locked.add((p.y, p.x))
        return True

    if not carve_path(agent_start, first_goal):
        # Fallback: straight-line clear path
        locked.add((agent_start.y, agent_start.x))
        locked.add((first_goal.y, first_goal.x))

    locked.add((agent_start.y, agent_start.x))
    locked.add((first_goal.y, first_goal.x))

    # 5. Additional goals — each placed in a new quadrant, guaranteed reachable
    goals: List[Vector2] = [first_goal]
    quads = _quadrant_bounds(rows, cols)
    previous_goal = first_goal

    for _ in range(num_goals - 1):
        extra_goal: Optional[Vector2] = None
        for attempt in range(_EXTRA_GOAL_ATTEMPTS):
            qi = rng.randint(0, 3)
            candidate = _random_point_in_quadrant(rng, *quads[qi])
            # make sure it isn't overwriting agent or an existing goal
            if candidate == agent_start or candidate in goals:
                continue
            if carve_path(previous_goal, candidate):
                extra_goal = candidate
                locked.add((candidate.y, candidate.x))
                goals.append(candidate)
                previous_goal = candidate
                break
        if extra_goal is None:
            # Worst-case: just pick the nearest reachable cell
            reach = grid.reachable_tiles(agent_start)
            candidates = [
                t for t in reach if t != agent_start and t not in goals
            ]
            if candidates:
                extra_goal = rng.choice(candidates)
                carve_path(previous_goal, extra_goal)
                goals.append(extra_goal)
                locked.add((extra_goal.y, extra_goal.x))

    # 6. Drop obstacles
    unlocked_cells = [
        (r, c)
        for r in range(rows)
        for c in range(cols)
        if (r, c) not in locked
    ]
    rng.shuffle(unlocked_cells)
    obstacle_cells = set(unlocked_cells[:obstacle_count])

    # 7. Write final grid
    for r in range(rows):
        for c in range(cols):
            pos = Vector2(c, r)
            if pos == agent_start:
                grid[r][c] = AGENT
            elif pos in goals:
                grid[r][c] = GOAL
            elif (r, c) in obstacle_cells:
                grid[r][c] = OBSTACLE
            else:
                grid[r][c] = EMPTY

    # 8. Stats
    # Reset agent cell for pathfinding (astar treats 'A' as passable already)
    reach = grid.reachable_tiles(agent_start)
    accessible = len(reach)
    accessible_vision = grid.vision_accessible_tiles(reach, vision_size)
    opt_len = grid.optimal_path_length(agent_start, goals)

    return GeneratedMap(
        grid=grid,
        agent_start=agent_start,
        goals=goals,
        optimal_path_len=opt_len,
        accessible_tiles=accessible,
        accessible_vision_tiles=accessible_vision,
    )