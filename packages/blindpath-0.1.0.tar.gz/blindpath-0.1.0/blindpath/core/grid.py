"""
blindpath/DataClasses/grid.py

Grid class — wraps a 2D tile matrix and provides analysis utilities.
"""

from __future__ import annotations

from collections import deque
from typing import List, Optional, Tuple

from blindpath.Constants.tiles import OBSTACLE, BOUNDARY
from blindpath.DataClasses.vector2 import Vector2


class Grid:
    """
    A 2D grid of single-character tile labels.

    Supports indexing (``grid[row][col]``), iteration over rows,
    and ``len(grid)`` for the row count, so it can be used as a
    drop-in replacement for ``List[List[str]]``.
    """

    def __init__(self, matrix: List[List[str]]) -> None:
        self.matrix = matrix

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def rows(self) -> int:
        return len(self.matrix)

    @property
    def cols(self) -> int:
        return len(self.matrix[0]) if self.matrix else 0

    # ------------------------------------------------------------------
    # Sequence protocol (grid[r][c], len, iteration)
    # ------------------------------------------------------------------

    def __getitem__(self, index: int) -> List[str]:
        return self.matrix[index]

    def __len__(self) -> int:
        return self.rows

    def __iter__(self):
        return iter(self.matrix)

    # ------------------------------------------------------------------
    # Copying
    # ------------------------------------------------------------------

    def copy(self) -> Grid:
        """Shallow row-level copy (each row is a new list)."""
        return Grid([row[:] for row in self.matrix])

    # ------------------------------------------------------------------
    # Analysis utilities
    # ------------------------------------------------------------------

    def reachable_tiles(self, start: Vector2) -> List[Vector2]:
        """BFS flood-fill returning all non-obstacle tiles reachable from *start*."""
        from blindpath.Util.astar import NEIGHBOURS

        visited: set[Vector2] = set()
        queue: deque[Vector2] = deque([start])
        visited.add(start)
        while queue:
            current = queue.popleft()
            for delta in NEIGHBOURS:
                nb = current + delta
                if not (0 <= nb.x < self.cols and 0 <= nb.y < self.rows):
                    continue
                if nb in visited:
                    continue
                if self.matrix[nb.y][nb.x] == OBSTACLE:
                    continue
                visited.add(nb)
                queue.append(nb)
        return list(visited)

    def vision_accessible_tiles(
        self,
        reachable: List[Vector2],
        vision_size: int,
    ) -> int:
        """
        Count distinct tile positions that fall inside *any* vision window
        centred on a reachable tile (i.e. tiles an agent could ever see).
        """
        half = vision_size // 2
        seen: set[Tuple[int, int]] = set()
        for pos in reachable:
            for dr in range(-half, half + 1):
                for dc in range(-half, half + 1):
                    r, c = pos.y + dr, pos.x + dc
                    if 0 <= r < self.rows and 0 <= c < self.cols:
                        seen.add((r, c))
        return len(seen)

    def optimal_path_length(
        self,
        agent_start: Vector2,
        goals: List[Vector2],
    ) -> int:
        """
        Greedy nearest-neighbour TSP over goals using A* distances.
        Returns total step count of the resulting tour.
        """
        from blindpath.Util.astar import astar

        remaining = list(goals)
        pos = agent_start
        total = 0
        while remaining:
            best_path: Optional[List[Vector2]] = None
            best_goal: Optional[Vector2] = None
            for g in remaining:
                path = astar(self.matrix, pos, g)
                if path is not None:
                    if best_path is None or len(path) < len(best_path):
                        best_path = path
                        best_goal = g
            if best_path is None:
                break
            total += len(best_path)
            pos = best_goal  # type: ignore[assignment]
            remaining.remove(best_goal)  # type: ignore[arg-type]
        return total

    def vision_window(self, center: Vector2, size: int) -> Grid:
        """
        Extract a *size*x*size* subgrid centred on *center*.
        Out-of-bounds positions are filled with BOUNDARY ('B').
        """
        half = size // 2
        window: List[List[str]] = []
        for dr in range(-half, half + 1):
            row_data: List[str] = []
            for dc in range(-half, half + 1):
                r, c = center.y + dr, center.x + dc
                if 0 <= r < self.rows and 0 <= c < self.cols:
                    row_data.append(self.matrix[r][c])
                else:
                    row_data.append(BOUNDARY)
            window.append(row_data)
        return Grid(window)
