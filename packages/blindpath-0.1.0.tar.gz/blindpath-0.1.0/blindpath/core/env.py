"""
blindpath/core/env.py

The BlindPathEnv class — the main environment interface used by all agents.
"""

from __future__ import annotations

import copy
import time
from typing import Dict, List, Optional, Set, Tuple

from blindpath.DataClasses.vector2 import Vector2
from blindpath.DataClasses.step_result import StepResult
from blindpath.DataClasses.env_config import EnvConfig
from blindpath.core.grid import Grid
from blindpath.Constants.tiles import AGENT, BOUNDARY, EMPTY, GOAL, OBSTACLE
from blindpath.Util.grid_formatting import grid_to_ascii
from blindpath.core.map_generation import generate_map

# ---------------------------------------------------------------------------
# Action space
# ---------------------------------------------------------------------------

ACTIONS: Dict[str, Vector2] = {
    "Up":    Vector2(0, -1),
    "Down":  Vector2(0,  1),
    "Left":  Vector2(-1, 0),
    "Right": Vector2(1,  0),
}


# ---------------------------------------------------------------------------
# Main environment
# ---------------------------------------------------------------------------

class BlindPathEnv:
    """
    The BlindPath grid-world environment.

    Usage
    -----
    >>> from blindpath.core.env import BlindPathEnv, EnvConfig
    >>> env = BlindPathEnv(EnvConfig(seed=42))
    >>> obs = env.reset()
    >>> result = env.step("Up")
    """

    def __init__(self, config: Optional[EnvConfig] = None) -> None:
        self.config = config or EnvConfig()
        self._resolved_seed: int = (
            self.config.seed if self.config.seed is not None
            else int(time.time() * 1000) & 0xFFFF_FFFF
        )
        # --- State (populated by reset()) ---
        self._grid: Grid  # assigned in reset()
        self._agent_pos: Vector2 = Vector2(0, 0)
        self._remaining_goals: Set[Tuple[int, int]] = set()
        self._iteration: int = 0
        self._max_iterations: int = 0
        self._optimal_path_len: int = 0
        self._accessible_tiles: int = 0
        self._accessible_vision_tiles: int = 0
        self._done: bool = True
        self._success: bool = False

    # -----------------------------------------------------------------------
    # Public interface
    # -----------------------------------------------------------------------

    def reset(self) -> StepResult:
        """Generate a fresh map and return the initial observation."""
        cfg = self.config
        rows, cols = cfg.env_size

        generated = generate_map(
            rows, cols,
            num_goals=cfg.num_goals,
            obstacle_count=cfg.obstacle_count,
            vision_size=cfg.vision_size,
            seed=self._resolved_seed,
        )

        # Unpack generated map into env state
        self._grid = generated.grid
        self._agent_pos = copy.copy(generated.agent_start)
        self._remaining_goals = {
            (g.y, g.x) for g in generated.goals
        }
        self._optimal_path_len = generated.optimal_path_len
        self._accessible_tiles = generated.accessible_tiles
        self._accessible_vision_tiles = generated.accessible_vision_tiles

        # Iteration limit: OptimalPathLength * (full_area / vision_area) * 3
        full_area = rows * cols
        vision_area = cfg.vision_size ** 2
        self._max_iterations = max(
            1,
            int(self._optimal_path_len * (full_area / vision_area) * 3),
        )
        self._iteration = 0
        self._done = False
        self._success = False

        return self._make_result(legal=True)

    def step(self, action: str) -> StepResult:
        """
        Apply *action* (one of "Up", "Down", "Left", "Right").

        Returns a StepResult regardless of whether the action was legal.
        Illegal actions (wall/OOB) are ignored (agent stays put) but counted.
        """
        if self._done:
            raise RuntimeError("Episode is done — call reset() first.")
        if action not in ACTIONS:
            raise ValueError(
                f"Unknown action '{action}'. Valid: {list(ACTIONS.keys())}"
            )

        self._iteration += 1
        delta = ACTIONS[action]
        new_pos = self._agent_pos + delta
        legal = self._is_legal(new_pos)

        if legal:
            # Move agent
            self._grid[self._agent_pos.y][self._agent_pos.x] = EMPTY
            self._agent_pos = new_pos
            # Check goal collection
            key = (new_pos.y, new_pos.x)
            self._remaining_goals.discard(key)
            self._grid[new_pos.y][new_pos.x] = AGENT
        # else: agent stays put

        # Termination
        if not self._remaining_goals:
            self._done = True
            self._success = True
        elif self._iteration >= self._max_iterations:
            self._done = True
            self._success = False

        return self._make_result(legal=legal)

    # -----------------------------------------------------------------------
    # Clone (used by POMCP for forward-model simulations)
    # -----------------------------------------------------------------------

    def clone(self) -> "BlindPathEnv":
        """Return a fast shallow-ish copy for POMCP simulations."""
        cloned = BlindPathEnv.__new__(BlindPathEnv)
        cloned.config = self.config
        cloned._resolved_seed = self._resolved_seed
        cloned._grid = self._grid.copy()  # shallow row-level copy
        cloned._agent_pos = Vector2(self._agent_pos.x, self._agent_pos.y)
        cloned._remaining_goals = set(self._remaining_goals)
        cloned._iteration = self._iteration
        cloned._max_iterations = self._max_iterations
        cloned._optimal_path_len = self._optimal_path_len
        cloned._accessible_tiles = self._accessible_tiles
        cloned._accessible_vision_tiles = self._accessible_vision_tiles
        cloned._done = self._done
        cloned._success = self._success
        return cloned

    # -----------------------------------------------------------------------
    # Read-only properties
    # -----------------------------------------------------------------------

    @property
    def full_grid(self) -> Grid:
        return self._grid

    @property
    def agent_position(self) -> Vector2:
        return copy.copy(self._agent_pos)

    @property
    def goals_remaining(self) -> int:
        return len(self._remaining_goals)

    @property
    def iteration(self) -> int:
        return self._iteration

    @property
    def max_iterations(self) -> int:
        return self._max_iterations

    @property
    def done(self) -> bool:
        return self._done

    @property
    def success(self) -> bool:
        return self._success

    @property
    def optimal_path_length(self) -> int:
        return self._optimal_path_len

    @property
    def accessible_tiles(self) -> int:
        return self._accessible_tiles

    @property
    def accessible_vision_tiles(self) -> int:
        return self._accessible_vision_tiles

    @property
    def timed_out(self) -> bool:
        return self._done and not self._success

    # -----------------------------------------------------------------------
    # Vision helpers (part of the public API for LLM agents)
    # -----------------------------------------------------------------------

    def get_vision_grid(self) -> Grid:
        """Return the agent's current vision window (LLM-facing state)."""
        return self._grid.vision_window(self._agent_pos, self.config.vision_size)

    def get_vision_string(self) -> str:
        """
        Format the vision grid as a compact string matrix for LLM prompting.

        Example output (5x5 window):
            O O O O O
            O E E E O
            O E A E O
            O E G E O
            O O O O O
        """
        win = self.get_vision_grid()
        return "\n".join(" ".join(row) for row in win)

    def get_static_prompt(self) -> str:
        """The pre-defined, non-negotiable part of the LLM prompt (spec §Input)."""
        return (
            "LABELS:\n"
            "  'A' -> You (Agent)\n"
            "  'E' -> Empty space\n"
            "  'O' -> Obstacle\n"
            "  'G' -> Goal\n"
            "  'B' -> Boundary (edge of map)\n\n"
            "RULES:\n"
            "1. Your objective is to reach all 'G' tiles.\n"
            "2. You cannot move into tiles labelled as 'O' or 'B'.\n"
            '3. Movement maps to the grid: "Up" (row above), "Down" (row below), '
            '"Left" (column left), "Right" (column right).\n'
            '4. Output ONLY in valid JSON format: {"action": "Up"}'
        )

    # -----------------------------------------------------------------------
    # Display
    # -----------------------------------------------------------------------

    def render(self) -> str:
        """Return a string representation of the full grid (debug)."""
        return grid_to_ascii(self._grid)

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _is_legal(self, pos: Vector2) -> bool:
        rows, cols = self.config.env_size
        if not (0 <= pos.x < cols and 0 <= pos.y < rows):
            return False
        cell = self._grid[pos.y][pos.x]
        return cell != OBSTACLE

    def _make_result(self, *, legal: bool) -> StepResult:
        return StepResult(
            vision_grid=self.get_vision_grid(),
            full_grid=self._grid,
            agent_position=copy.copy(self._agent_pos),
            goals_remaining=self.goals_remaining,
            done=self._done,
            success=self._success,
            timed_out=self.timed_out,
            legal=legal,
            iteration=self._iteration,
        )
