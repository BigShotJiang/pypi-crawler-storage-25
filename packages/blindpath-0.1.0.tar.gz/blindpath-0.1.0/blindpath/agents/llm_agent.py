"""
blindpath/agents/llm_agent.py

Abstract base class for LLM-powered BlindPath agents.

Subclasses implement `_prompt()` to call their LLM of choice.
The base class handles prompt assembly and action parsing.
"""

from __future__ import annotations

import random
from abc import abstractmethod
from typing import Callable, Optional

from blindpath.agents.base import BaseAgent
from blindpath.core.env import ACTIONS, BlindPathEnv
from blindpath.DataClasses.step_result import StepResult
from blindpath.Util.action_parsing import parse_action


PromptBuilder = Callable[[BlindPathEnv, StepResult], Optional[str]]


class LLMAgent(BaseAgent):
    """
    Abstract base for LLM-powered agents.

    Subclasses must implement `_prompt()` to call their LLM and return
    the raw response string. The base class assembles the full prompt
    (custom + static + vision) and parses the action from the response.

    Parameters
    ----------
    prompt_builder : PromptBuilder | None
        Optional callback that receives (env, result) and returns a custom
        prompt string to prepend before the static prompt.
    """

    def __init__(self, *, prompt_builder: Optional[PromptBuilder] = None) -> None:
        self._prompt_builder = prompt_builder
        self.compliance_failures: int = 0

    @abstractmethod
    def _prompt(self, prompt: str) -> str:
        """Send the assembled prompt to the LLM and return the raw response."""

    def reset(self) -> None:
        self.compliance_failures = 0

    def step(self, env: BlindPathEnv, result: StepResult) -> str:
        parts: list[str] = []

        if self._prompt_builder is not None:
            custom = self._prompt_builder(env, result)
            if custom:
                parts.append(custom.strip())

        parts.append(env.get_static_prompt())
        parts.append(f"\nCURRENT VISION GRID:\n{env.get_vision_string()}")

        raw = self._prompt("\n\n".join(parts))
        action = parse_action(raw)

        if action is None:
            self.compliance_failures += 1
            action = random.choice(list(ACTIONS.keys()))

        return action
