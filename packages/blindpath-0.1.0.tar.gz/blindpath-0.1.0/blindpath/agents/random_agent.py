"""
blindpath/agents/random_agent.py

Baseline: uniformly random action selection.
Purpose: prove the task is non-trivial — a random policy should score poorly.
"""

from __future__ import annotations

import random
from typing import Optional

from blindpath.agents.base import BaseAgent
from blindpath.core.env import BlindPathEnv, ACTIONS
from blindpath.DataClasses.step_result import StepResult


class RandomAgent(BaseAgent):
    """
    Selects a uniformly random action from the full action space each step.

    Intentionally naive — it ignores all state information, making it the
    lower-bound baseline for the BlindPath benchmark.
    """

    def __init__(self, seed: Optional[int] = None) -> None:
        self._rng = random.Random(seed)
        self._actions = list(ACTIONS.keys())  # ["Up", "Down", "Left", "Right"]

    def reset(self) -> None:
        pass  # stateless — nothing to reset

    def step(
        self,
        env: BlindPathEnv,
        result: StepResult,
    ) -> str:
        return self._rng.choice(self._actions)
