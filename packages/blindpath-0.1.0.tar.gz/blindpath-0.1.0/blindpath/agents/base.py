"""
blindpath/agents/base.py

Abstract base class for all BlindPath agents.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from blindpath.core.env import BlindPathEnv
from blindpath.DataClasses.step_result import StepResult


class BaseAgent(ABC):
    """
    Every agent must implement `step()`.

    Parameters passed to `step()`:
    - env       : the live environment (agents may read public properties
                  but must NOT modify internal state directly).
    - result    : the StepResult from the previous step (or initial reset).
    """

    @abstractmethod
    def step(
        self,
        env: BlindPathEnv,
        result: StepResult,
    ) -> str:
        """
        Return one of: "Up", "Down", "Left", "Right".
        """

    def reset(self) -> None:
        """Called at the beginning of every new episode. Override if needed."""

    def observe(self, action: str, result: StepResult) -> None:
        """Called after env.step() with the action taken and result. Override if needed."""
