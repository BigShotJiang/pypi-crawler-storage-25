"""
blindpath/agents/pomcp_agent.py

POMCP (Partially Observable Monte-Carlo Planning) agent baseline.

Uses UCT (Upper Confidence Trees) with a particle filter for belief
state management under partial observability.
"""

from __future__ import annotations

import math
import random
from typing import Dict, List

from blindpath.agents.base import BaseAgent
from blindpath.core.env import ACTIONS, BlindPathEnv
from blindpath.DataClasses.step_result import StepResult


# ---------------------------------------------------------------------------
# UCT Node
# ---------------------------------------------------------------------------

class _UCTNode:
    __slots__ = ("visit_count", "value_sum", "children")

    def __init__(self) -> None:
        self.visit_count: int = 0
        self.value_sum: float = 0.0
        self.children: Dict[str, "_UCTNode"] = {}

    def uct_score(self, parent_visits: int, exploration_c: float) -> float:
        if self.visit_count == 0:
            return math.inf
        exploit = self.value_sum / self.visit_count
        explore = exploration_c * math.sqrt(
            math.log(parent_visits) / self.visit_count
        )
        return exploit + explore

    def best_action(self, actions: List[str]) -> str:
        return max(
            actions,
            key=lambda a: self.children[a].visit_count
            if a in self.children
            else 0,
        )


# ---------------------------------------------------------------------------
# POMCP Agent
# ---------------------------------------------------------------------------

class POMCPAgent(BaseAgent):
    """
    POMCP agent for BlindPath.

    Parameters
    ----------
    num_particles : int
        Size of the particle filter (belief state approximation).
    num_simulations : int
        Number of Monte-Carlo rollouts per planning step.
    rollout_depth : int
        Maximum depth of each rollout beyond the tree.
    exploration_c : float
        UCT exploration constant (higher = more exploration).
    discount : float
        Discount factor for future rewards.
    seed : int | None
        RNG seed for reproducibility.
    """

    def __init__(
        self,
        *,
        num_particles: int = 200,
        num_simulations: int = 500,
        rollout_depth: int = 30,
        exploration_c: float = 1.41,
        discount: float = 0.95,
        seed: Optional[int] = None,
    ) -> None:
        self._num_particles = num_particles
        self._num_sims = num_simulations
        self._rollout_depth = rollout_depth
        self._c = exploration_c
        self._gamma = discount
        self._rng = random.Random(seed)
        self._actions = list(ACTIONS.keys())

        self._particles: List[BlindPathEnv] = []
        self._root: Optional[_UCTNode] = None

    # -----------------------------------------------------------------------
    # BaseAgent interface
    # -----------------------------------------------------------------------

    def reset(self) -> None:
        self._particles = []
        self._root = None

    def step(
        self,
        env: BlindPathEnv,
        result: StepResult,
    ) -> str:
        # Initialise belief on first call
        if not self._particles:
            self._particles = [env.clone() for _ in range(self._num_particles)]

        if self._root is None:
            self._root = _UCTNode()

        # Plan via POMCP simulations
        for _ in range(self._num_sims):
            if not self._particles:
                break
            particle = self._rng.choice(self._particles).clone()
            self._simulate(particle, self._root, depth=0)

        # Choose best action by visit count
        if self._root.children:
            action = self._root.best_action(self._actions)
        else:
            action = self._rng.choice(self._actions)

        return action

    def observe(self, action: str, result: StepResult) -> None:
        """
        Called after env.step():
        1. Step all particles forward with the chosen action.
        2. Filter particles whose vision matches the real observation.
        3. Resample if the filter degenerates.
        4. Reuse the subtree for the chosen action as the new root.
        """
        # Step every particle
        for p in self._particles:
            if not p.done:
                try:
                    p.step(action)
                except Exception:
                    pass

        # Filter by observation match
        obs = self._obs_signature(result)
        surviving = [
            p for p in self._particles
            if self._obs_signature_from_env(p) == obs
        ]

        # Resample to target count (or keep all if filter failed)
        if surviving:
            self._particles = self._rng.choices(
                surviving, k=self._num_particles
            )
        # else: keep unfiltered particles (degenerate case)

        # Reuse subtree
        if self._root and action in self._root.children:
            self._root = self._root.children[action]
        else:
            self._root = _UCTNode()

    # -----------------------------------------------------------------------
    # POMCP simulation
    # -----------------------------------------------------------------------

    def _simulate(
        self,
        sim_env: BlindPathEnv,
        node: _UCTNode,
        depth: int,
    ) -> float:
        """Recursive UCT simulation; returns discounted cumulative reward."""
        if sim_env.done or depth > self._rollout_depth:
            return 0.0

        # Expand: create child nodes for unseen actions
        for a in self._actions:
            if a not in node.children:
                node.children[a] = _UCTNode()

        # UCT action selection
        action = max(
            self._actions,
            key=lambda a: node.children[a].uct_score(
                max(node.visit_count, 1), self._c
            ),
        )
        child = node.children[action]

        # Step the simulated environment
        prev_pos = sim_env.agent_position
        step_result = sim_env.step(action)
        reward = self._reward(sim_env, step_result, prev_pos)

        if child.visit_count == 0:
            # Leaf — random rollout
            total = reward + self._gamma * self._rollout(sim_env, depth + 1)
        else:
            # Interior — recurse
            total = reward + self._gamma * self._simulate(
                sim_env, child, depth + 1
            )

        # Backpropagate
        node.visit_count += 1
        node.value_sum += total
        child.visit_count += 1
        child.value_sum += total
        return total

    def _rollout(self, sim_env: BlindPathEnv, depth: int) -> float:
        """Goal-biased rollout until terminal or max depth."""
        total = 0.0
        discount = 1.0
        remaining = max(0, self._rollout_depth - depth)
        for _ in range(remaining):
            if sim_env.done:
                break
            prev_pos = sim_env.agent_position
            action = self._rollout_action(sim_env)
            result = sim_env.step(action)
            total += discount * self._reward(sim_env, result, prev_pos)
            discount *= self._gamma
        return total

    def _rollout_action(self, sim_env: BlindPathEnv) -> str:
        """Bias rollout toward the nearest remaining goal (70%) or random."""
        goals = sim_env._remaining_goals
        if not goals or self._rng.random() > 0.7:
            return self._rng.choice(self._actions)

        pos = sim_env.agent_position
        nearest = min(
            goals, key=lambda g: abs(g[0] - pos.y) + abs(g[1] - pos.x)
        )
        dy = nearest[0] - pos.y
        dx = nearest[1] - pos.x

        preferred: List[str] = []
        if dy < 0:
            preferred.append("Up")
        elif dy > 0:
            preferred.append("Down")
        if dx < 0:
            preferred.append("Left")
        elif dx > 0:
            preferred.append("Right")

        return self._rng.choice(preferred) if preferred else self._rng.choice(self._actions)

    # -----------------------------------------------------------------------
    # Reward
    # -----------------------------------------------------------------------

    @staticmethod
    def _reward(
        sim_env: BlindPathEnv,
        result: StepResult,
        prev_pos: "Vector2",
    ) -> float:
        """
        Shaped reward using manhattan distance to nearest remaining goal.
        Moving closer → positive, moving away → negative, wall → penalty.
        """
        if result.success:
            return 10.0
        if not result.legal:
            return -1.0

        goals = sim_env._remaining_goals
        if not goals:
            return 5.0

        curr = result.agent_position
        prev_dist = min(
            abs(g[0] - prev_pos.y) + abs(g[1] - prev_pos.x) for g in goals
        )
        curr_dist = min(
            abs(g[0] - curr.y) + abs(g[1] - curr.x) for g in goals
        )
        # Progress bonus + small time penalty
        return float(prev_dist - curr_dist) - 0.01

    # -----------------------------------------------------------------------
    # Observation fingerprinting
    # -----------------------------------------------------------------------

    @staticmethod
    def _obs_signature(result: StepResult) -> str:
        return "".join("".join(row) for row in result.vision_grid)

    @staticmethod
    def _obs_signature_from_env(env: BlindPathEnv) -> str:
        win = env.get_vision_grid()
        return "".join("".join(row) for row in win)
