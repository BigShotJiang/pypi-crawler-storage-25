"""
blindpath/eval/metrics.py

Backward-compatibility re-exports.
Prefer importing directly from episode_metrics / benchmark_results.
"""

from blindpath.eval.episode_metrics import EpisodeMetrics
from blindpath.eval.benchmark_results import BenchmarkResults

__all__ = ["EpisodeMetrics", "BenchmarkResults"]