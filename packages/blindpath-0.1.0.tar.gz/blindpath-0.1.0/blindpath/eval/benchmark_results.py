"""
blindpath/eval/benchmark_results.py

Aggregation of multiple EpisodeMetrics across a benchmark run.
"""

import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from blindpath.eval.episode_metrics import EpisodeMetrics


@dataclass
class BenchmarkResults:
    """Aggregation of multiple EpisodeMetrics (one per run)."""

    episodes: List[EpisodeMetrics] = field(default_factory=list)

    def add(self, ep: EpisodeMetrics) -> None:
        self.episodes.append(ep)

    def _avg(self, values: List[Optional[float]]) -> Optional[float]:
        valid = [v for v in values if v is not None]
        return sum(valid) / len(valid) if valid else None

    @property
    def success_rate(self) -> Optional[float]:
        return self._avg([e.success_rate for e in self.episodes])

    @property
    def optimal_rate(self) -> Optional[float]:
        return self._avg([e.optimal_rate for e in self.episodes])

    @property
    def feasible_rate(self) -> Optional[float]:
        return self._avg([e.feasible_rate for e in self.episodes])

    @property
    def compliance_ratio(self) -> Optional[float]:
        return self._avg([e.compliance_ratio for e in self.episodes])

    @property
    def exploration_ratio(self) -> Optional[float]:
        return self._avg([e.exploration_ratio for e in self.episodes])

    def to_dict(self) -> Dict[str, Any]:
        n = len(self.episodes)
        return {
            "num_episodes": n,
            "successes": sum(1 for e in self.episodes if e.success),
            "summary": {
                "success_rate": self.success_rate,
                "optimal_rate": self.optimal_rate,
                "feasible_rate": self.feasible_rate,
                "compliance_ratio": self.compliance_ratio,
                "exploration_ratio": self.exploration_ratio,
            },
            "episodes": [e.to_dict() for e in self.episodes],
        }

    def save(self, filepath: str, extra: Optional[Dict[str, Any]] = None) -> str:
        """
        Save benchmark results to a JSON file.

        Parameters
        ----------
        filepath : str
            Path to the output JSON file.
        extra : dict | None
            Additional top-level fields to include (e.g. config, agent name).

        Returns
        -------
        str
            The absolute path of the saved file.
        """
        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
        data: Dict[str, Any] = {
            "timestamp": datetime.now().isoformat(),
        }
        if extra:
            data.update(extra)
        data.update(self.to_dict())
        with open(filepath, "w") as f:
            json.dump(data, f, indent=2)
        return os.path.abspath(filepath)

    def summary(self) -> str:
        def fmt(v: Optional[float], suffix: str = "%") -> str:
            return f"{v:.2f}{suffix}" if v is not None else "N/A"

        n = len(self.episodes)
        successes = sum(1 for e in self.episodes if e.success)
        lines = [
            "═" * 44,
            "  BlindPath Benchmark Results",
            f"  Episodes: {n}  |  Successes: {successes}",
            "═" * 44,
            f"  Success Rate      : {fmt(self.success_rate)}",
            f"  Optimal Rate      : {fmt(self.optimal_rate)}",
            f"  Feasible Rate     : {fmt(self.feasible_rate)}",
            f"  Compliance Ratio  : {fmt(self.compliance_ratio)}",
            f"  Exploration Ratio : {fmt(self.exploration_ratio)}",
            "═" * 44,
        ]
        return "\n".join(lines)
