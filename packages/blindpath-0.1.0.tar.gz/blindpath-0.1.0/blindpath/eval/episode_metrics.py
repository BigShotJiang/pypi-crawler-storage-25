"""
blindpath/eval/episode_metrics.py

Metrics collected for a single BlindPath episode.
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class EpisodeMetrics:
    """
    Metrics collected for a single episode (one Session.run() call).
    The fields are incrementally updated by Session; computed properties
    derive the final benchmark rates.
    """

    # --- Counters (updated live) ---
    iterations: int = 0
    total_actions: int = 0       # LLM outputs parsed (compliance denominator)
    legal_actions: int = 0       # actions that didn't hit a wall / OOB
    seen_tiles: int = 0          # unique tiles entered by the agent's vision window

    # --- Ground-truth stats (set once at environment creation) ---
    optimal_path_length: int = 0
    accessible_tiles: int = 0
    accessible_vision_tiles: int = 0

    # --- Outcome ---
    success: bool = False
    timed_out: bool = False

    # -----------------------------------------------------------------------
    # Derived metrics
    # -----------------------------------------------------------------------

    @property
    def success_rate(self) -> float:
        """100.0 if the episode succeeded, 0.0 otherwise."""
        return 100.0 if self.success else 0.0

    @property
    def optimal_rate(self) -> Optional[float]:
        """
        OptimalPathLength / LegalActions * 100%.
        Returns None if no legal actions were taken.
        """
        if self.legal_actions == 0:
            return None
        return (self.optimal_path_length / self.legal_actions) * 100.0

    @property
    def feasible_rate(self) -> Optional[float]:
        """
        LegalActions / TotalActions * 100%.
        Returns None if TotalActions == 0.
        """
        if self.total_actions == 0:
            return None
        return (self.legal_actions / self.total_actions) * 100.0

    @property
    def compliance_ratio(self) -> Optional[float]:
        """
        TotalActions (valid JSON outputs) / Iterations * 100%.
        Returns None if no iterations occurred.
        """
        if self.iterations == 0:
            return None
        return (self.total_actions / self.iterations) * 100.0

    @property
    def exploration_ratio(self) -> Optional[float]:
        """
        SeenTiles / AccessibleVisionTiles * 100%.
        Returns None if accessible_vision_tiles == 0.
        """
        if self.accessible_vision_tiles == 0:
            return None
        return (self.seen_tiles / self.accessible_vision_tiles) * 100.0

    # -----------------------------------------------------------------------
    # Serialization
    # -----------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "timed_out": self.timed_out,
            "iterations": self.iterations,
            "total_actions": self.total_actions,
            "legal_actions": self.legal_actions,
            "seen_tiles": self.seen_tiles,
            "optimal_path_length": self.optimal_path_length,
            "accessible_tiles": self.accessible_tiles,
            "accessible_vision_tiles": self.accessible_vision_tiles,
            "success_rate": self.success_rate,
            "optimal_rate": self.optimal_rate,
            "feasible_rate": self.feasible_rate,
            "compliance_ratio": self.compliance_ratio,
            "exploration_ratio": self.exploration_ratio,
        }

    def summary(self) -> str:
        def fmt(v: Optional[float], suffix: str = "%") -> str:
            return f"{v:.2f}{suffix}" if v is not None else "N/A"

        lines = [
            "─" * 40,
            "  BlindPath Episode Metrics",
            "─" * 40,
            f"  Success          : {'✓' if self.success else '✗'}",
            f"  Timed Out        : {'yes' if self.timed_out else 'no'}",
            f"  Iterations       : {self.iterations}",
            f"  Optimal Path Len : {self.optimal_path_length}",
            f"  Total Actions    : {self.total_actions}",
            f"  Legal Actions    : {self.legal_actions}",
            f"  Seen Tiles       : {self.seen_tiles} / {self.accessible_vision_tiles}",
            "─" * 40,
            f"  Success Rate     : {fmt(self.success_rate)}",
            f"  Optimal Rate     : {fmt(self.optimal_rate)}",
            f"  Feasible Rate    : {fmt(self.feasible_rate)}",
            f"  Compliance Ratio : {fmt(self.compliance_ratio)}",
            f"  Exploration Ratio: {fmt(self.exploration_ratio)}",
            "─" * 40,
        ]
        return "\n".join(lines)
