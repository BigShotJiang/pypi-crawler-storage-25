"""
blindpath/session.py

Session: orchestrates the full episode lifecycle.

  reset() -> [read state -> agent.step() -> env.step() -> update metrics] -> done
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional, Any

from blindpath.agents.base import BaseAgent
from blindpath.core.env import BlindPathEnv, EnvConfig, StepResult, ACTIONS
from blindpath.eval.benchmark_results import BenchmarkResults
from blindpath.eval.episode_metrics import EpisodeMetrics

logger = logging.getLogger(__name__)


class Session:
    """
    Runs one or more BlindPath episodes with a given agent and config.

    Parameters
    ----------
    agent : BaseAgent
        The agent to evaluate. Can be RandomAgent, POMCPAgent, or LLMAgent.
    config : EnvConfig | None
        Environment hyperparameters. Uses defaults if not supplied.
    verbose : bool
        Print per-step info to stdout if True.
    render : bool
        Render the full grid to stdout each step (useful for debugging).
    output_dir : str | None
        If set, benchmark results are auto-saved as JSON to this directory.
    """

    def __init__(
        self,
        agent: BaseAgent,
        config: Optional[EnvConfig] = None,
        *,
        verbose: bool = False,
        render: bool = False,
        output_dir: Optional[str] = None,
    ) -> None:
        self._agent = agent
        self._config = config or EnvConfig()
        self._verbose = verbose
        self._render = render
        self._output_dir = output_dir
        self._env = BlindPathEnv(self._config)

    # -----------------------------------------------------------------------
    # Single-episode run
    # -----------------------------------------------------------------------

    def run(self) -> EpisodeMetrics:
        """
        Run a single episode and return its metrics.

        The seed embedded in EnvConfig is fixed, so repeated calls to run()
        on the same Session produce identical episodes. Use run_benchmark()
        for multi-episode evaluation with varying seeds.
        """
        env = self._env
        agent = self._agent
        agent.reset()

        # --- Reset environment ---
        result = env.reset()

        metrics = EpisodeMetrics(
            optimal_path_length=env.optimal_path_length,
            accessible_tiles=env.accessible_tiles,
            accessible_vision_tiles=env.accessible_vision_tiles,
        )

        # Track explored tiles (cells the vision window has covered)
        self._seen_tile_set: set = set()
        self._record_seen_tiles(metrics, result, env)

        if self._verbose:
            self._print_header(env)

        # --- Episode loop ---
        while not result.done and metrics.iterations < env.max_iterations:
            # Agent steps
            metrics.iterations += 1
            raw_action = agent.step(env, result)

            # Compliance check — only valid action strings count
            if raw_action not in ACTIONS:
                logger.debug("Non-compliant action returned: %r", raw_action)
                continue

            metrics.total_actions += 1

            # Step environment (valid action — won't raise ValueError)
            result = env.step(raw_action)

            # Update metrics
            if result.legal:
                metrics.legal_actions += 1
            self._record_seen_tiles(metrics, result, env)

            # Let the agent observe the result (e.g. POMCP belief update)
            agent.observe(raw_action, result)

            if self._verbose:
                self._print_step(result, raw_action, metrics)
            if self._render:
                print(env.render())
                print()

        # --- Terminal ---
        metrics.success = env.success
        metrics.timed_out = not env.success

        if self._verbose:
            print(metrics.summary())

        return metrics

    # -----------------------------------------------------------------------
    # Multi-episode benchmark runner
    # -----------------------------------------------------------------------

    def run_benchmark(
        self,
        num_episodes: int,
        *,
        base_seed: Optional[int] = None,
    ) -> BenchmarkResults:
        """
        Run *num_episodes* episodes, each with a different seed.

        Seeds are derived from base_seed + episode index, ensuring
        reproducibility while testing on diverse map layouts.

        Parameters
        ----------
        num_episodes : int
            Number of episodes to run.
        base_seed : int | None
            If provided, episode seeds = base_seed + i (i=0..n-1).
            If None, seeds are random (time-based) per episode.

        Returns
        -------
        BenchmarkResults
            Aggregated metrics across all episodes.
        """
        results = BenchmarkResults()

        for i in range(num_episodes):
            episode_seed = (base_seed + i) if base_seed is not None else None
            cfg = EnvConfig(
                seed=episode_seed,
                env_size=self._config.env_size,
                num_goals=self._config.num_goals,
                obstacle_count=self._config.obstacle_count,
                vision_size=self._config.vision_size,
            )
            self._env = BlindPathEnv(cfg)
            ep_metrics = self.run()
            results.add(ep_metrics)

            if self._verbose:
                print(f"\n[Episode {i + 1}/{num_episodes}] "
                      f"{'SUCCESS' if ep_metrics.success else 'TIMEOUT'}\n")

        if self._verbose:
            print(results.summary())

        # Auto-save results to disk
        if self._output_dir:
            filepath = self._save_results(results)
            print(f"\nResults saved to: {filepath}")

        return results

    # -----------------------------------------------------------------------
    # Data export
    # -----------------------------------------------------------------------

    def _save_results(self, results: BenchmarkResults) -> str:
        """Save benchmark results as a JSON file. Returns the file path."""
        agent_name = type(self._agent).__name__
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"results_{agent_name}_{timestamp}.json"
        filepath = os.path.join(self._output_dir, filename)  # type: ignore[arg-type]

        extra: Dict[str, Any] = {
            "agent": agent_name,
            "config": {
                "seed": self._config.seed,
                "env_size": list(self._config.env_size),
                "num_goals": self._config.num_goals,
                "obstacle_count": self._config.obstacle_count,
                "vision_size": self._config.vision_size,
            },
        }
        return results.save(filepath, extra=extra)

    # -----------------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------------

    def _record_seen_tiles(
        self, metrics: EpisodeMetrics, result: StepResult, env: BlindPathEnv
    ) -> None:
        """
        Record all real-grid positions visible in the current vision window.
        """
        half = env.config.vision_size // 2
        rows, cols = env.config.env_size
        pos = result.agent_position
        for dr in range(-half, half + 1):
            for dc in range(-half, half + 1):
                r, c = pos.y + dr, pos.x + dc
                if 0 <= r < rows and 0 <= c < cols:
                    self._seen_tile_set.add((r, c))
        metrics.seen_tiles = len(self._seen_tile_set)

    @staticmethod
    def _print_header(env: BlindPathEnv) -> None:
        print("=" * 50)
        print(f"  BlindPath Episode")
        print(f"  Map: {env.config.env_size[0]}x{env.config.env_size[1]}  "
              f"Vision: {env.config.vision_size}x{env.config.vision_size}  "
              f"Goals: {env.config.num_goals}")
        print(f"  Optimal Path: {env.optimal_path_length} steps")
        print(f"  Max Iterations: {env.max_iterations}")
        print("=" * 50)

    @staticmethod
    def _print_step(result: StepResult, action: str, metrics: EpisodeMetrics) -> None:
        legal_marker = "\u2713" if result.legal else "\u2717"
        print(
            f"  [{metrics.iterations:4d}] action={action:<6s} {legal_marker}  "
            f"pos=({result.agent_position.x},{result.agent_position.y})  "
            f"goals_left={result.goals_remaining}"
        )
