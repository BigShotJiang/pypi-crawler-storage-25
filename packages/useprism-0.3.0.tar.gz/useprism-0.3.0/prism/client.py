import threading
import time
import queue
import httpx
from datetime import datetime
from typing import Any

from .config import Config
from .trace import Trace


class PrismClient:
    """
    Manages a background thread that batches and ships traces
    to the Prism API with zero latency impact on the main app.
    """

    def __init__(self, config: Config):
        self.config = config
        self._queue: queue.Queue[Trace] = queue.Queue()
        self._thread: threading.Thread | None = None
        self._running = False
        self._http = httpx.Client(
            base_url=config.base_url,
            headers={
                "x-api-key": config.api_key,
                "content-type": "application/json",
            },
            timeout=10,
        )

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        self._debug("Prism started ✅")

    def shutdown(self):
        self._running = False
        self._flush_all()
        self._http.close()
        self._debug("Prism shutdown — all traces flushed.")

    # ── Public API ───────────────────────────────────────────────────────────

    def record(self, trace: Trace):
        """Enqueue a trace for async shipping."""
        self._queue.put(trace)
        self._debug(f"Queued trace: {trace.model} {trace.status_code} {trace.latency_ms}ms")

    def wrap(self, client: Any, endpoint: str | None = None, user_id: str | None = None, session_id: str | None = None):
        """Return a wrapped LLM client that auto-traces calls."""
        from .wrappers import wrap as _wrap
        return _wrap(client, prism=self, endpoint=endpoint, user_id=user_id, session_id=session_id)

    # ── Background loop ──────────────────────────────────────────────────────

    def _loop(self):
        buffer: list[Trace] = []
        last_flush = time.monotonic()

        while self._running:
            # Drain queue into buffer
            while not self._queue.empty() and len(buffer) < self.config.batch_size:
                try:
                    buffer.append(self._queue.get_nowait())
                except queue.Empty:
                    break

            now = time.monotonic()
            should_flush = (
                len(buffer) >= self.config.batch_size
                or (buffer and now - last_flush >= self.config.flush_interval)
            )

            if should_flush:
                self._send(buffer)
                buffer = []
                last_flush = now

            time.sleep(0.1)

        # Drain remaining on shutdown
        while not self._queue.empty():
            try:
                buffer.append(self._queue.get_nowait())
            except queue.Empty:
                break
        if buffer:
            self._send(buffer)

    def _flush_all(self):
        buffer = []
        while not self._queue.empty():
            try:
                buffer.append(self._queue.get_nowait())
            except queue.Empty:
                break
        if buffer:
            self._send(buffer)

    def _send(self, traces: list[Trace]):
        if not traces:
            return
        try:
            payload = [t.to_dict() for t in traces]
            if len(payload) == 1:
                resp = self._http.post("/api/v1/traces/", json=payload[0])
            else:
                resp = self._http.post("/api/v1/traces/batch", json=payload)
            resp.raise_for_status()
            self._debug(f"Sent {len(payload)} trace(s) → {resp.status_code}")
        except Exception as e:
            self._debug(f"Failed to send traces: {e}")

    def _debug(self, msg: str):
        if self.config.debug:
            print(f"[prism] {msg}")
