"""
Wrappers that intercept LLM calls and record traces automatically.
Supports: anthropic.Anthropic, openai.OpenAI
"""
import time
from typing import Any, Optional

from .trace import Trace


def wrap(client: Any, prism=None, endpoint: str | None = None, user_id: str | None = None, session_id: str | None = None) -> Any:
    """Auto-detect client type and return the appropriate wrapper."""
    cls_name = type(client).__name__
    module = getattr(type(client), "__module__", "")

    if "anthropic" in module:
        return _AnthropicWrapper(client, prism=prism, endpoint=endpoint, user_id=user_id, session_id=session_id)
    if "openai" in module:
        return _OpenAIWrapper(client, prism=prism, endpoint=endpoint, user_id=user_id, session_id=session_id)

    raise ValueError(
        f"Unsupported client type: {cls_name}. "
        "Supported: anthropic.Anthropic, openai.OpenAI"
    )


def _preview(text: str, limit: int = 500) -> str:
    if not text:
        return ""
    return text[:limit] + ("…" if len(text) > limit else "")


# ── Anthropic ────────────────────────────────────────────────────────────────

class _AnthropicMessages:
    def __init__(self, original, prism, endpoint: str, user_id: Optional[str], session_id: Optional[str]):
        self._orig       = original
        self._prism      = prism
        self._endpoint   = endpoint
        self._user_id    = user_id
        self._session_id = session_id

    def create(self, **kwargs) -> Any:
        model    = kwargs.get("model", "unknown")
        messages = kwargs.get("messages", [])
        prompt_text = " ".join(
            m.get("content", "") if isinstance(m.get("content"), str)
            else str(m.get("content", ""))
            for m in messages
        )

        # Extract prompt versioning from extra_headers
        extra_headers = kwargs.get("extra_headers", {}) or {}
        prompt_name    = extra_headers.get("X-Prism-Prompt-Name")
        prompt_version = extra_headers.get("X-Prism-Prompt-Version")

        t0     = time.monotonic()
        status = 200
        response = None

        try:
            response = self._orig.create(**kwargs)
        except Exception as e:
            status = getattr(e, "status_code", 500)
            raise
        finally:
            latency_ms = int((time.monotonic() - t0) * 1000)

            prompt_tokens     = 0
            completion_tokens = 0
            response_text     = ""

            if response is not None:
                usage = getattr(response, "usage", None)
                if usage:
                    prompt_tokens     = getattr(usage, "input_tokens", 0)
                    completion_tokens = getattr(usage, "output_tokens", 0)
                content = getattr(response, "content", [])
                if content:
                    response_text = getattr(content[0], "text", "")

            trace = Trace(
                project_id       = self._prism.config.api_key,
                endpoint         = self._endpoint,
                model            = model,
                prompt_tokens    = prompt_tokens,
                completion_tokens = completion_tokens,
                latency_ms       = latency_ms,
                status_code      = status,
                user_id          = self._user_id,
                session_id       = self._session_id,
                prompt_preview   = _preview(prompt_text),
                response_preview = _preview(response_text),
                prompt_name      = prompt_name,
                prompt_version   = prompt_version,
            )
            self._prism.record(trace)

        return response


class _AnthropicWrapper:
    def __init__(self, client, prism, endpoint: str | None, user_id: Optional[str], session_id: Optional[str]):
        self._client     = client
        self._prism      = prism
        self._endpoint   = endpoint or "/llm/anthropic"
        self._user_id    = user_id
        self._session_id = session_id
        self.messages    = _AnthropicMessages(
            client.messages,
            prism      = prism,
            endpoint   = self._endpoint,
            user_id    = user_id,
            session_id = session_id,
        )

    def __getattr__(self, name):
        return getattr(self._client, name)


# ── OpenAI ───────────────────────────────────────────────────────────────────

class _OpenAIWrapper:
    def __init__(self, client, prism, endpoint: str | None, user_id: Optional[str], session_id: Optional[str]):
        self._client     = client
        self._prism      = prism
        self._endpoint   = endpoint or "/llm/openai"
        self._user_id    = user_id
        self._session_id = session_id

        completions = _OpenAICompletions(
            client.chat.completions,
            prism      = prism,
            endpoint   = self._endpoint,
            user_id    = user_id,
            session_id = session_id,
        )

        class _Chat:
            pass

        chat = _Chat()
        chat.completions = completions
        self.chat = chat

    def __getattr__(self, name):
        return getattr(self._client, name)


class _OpenAICompletions:
    def __init__(self, original, prism, endpoint, user_id, session_id):
        self._orig       = original
        self._prism      = prism
        self._endpoint   = endpoint
        self._user_id    = user_id
        self._session_id = session_id

    def create(self, **kwargs) -> Any:
        model    = kwargs.get("model", "unknown")
        messages = kwargs.get("messages", [])
        prompt_text = " ".join(
            m.get("content", "") for m in messages
            if isinstance(m.get("content"), str)
        )

        # Extract prompt versioning from extra_headers
        extra_headers = kwargs.get("extra_headers", {}) or {}
        prompt_name    = extra_headers.get("X-Prism-Prompt-Name")
        prompt_version = extra_headers.get("X-Prism-Prompt-Version")

        t0     = time.monotonic()
        status = 200
        response = None

        try:
            response = self._orig.create(**kwargs)
        except Exception as e:
            status = getattr(e, "status_code", 500)
            raise
        finally:
            latency_ms = int((time.monotonic() - t0) * 1000)

            prompt_tokens     = 0
            completion_tokens = 0
            response_text     = ""

            if response is not None:
                usage = getattr(response, "usage", None)
                if usage:
                    prompt_tokens     = getattr(usage, "prompt_tokens", 0)
                    completion_tokens = getattr(usage, "completion_tokens", 0)
                choices = getattr(response, "choices", [])
                if choices:
                    msg = getattr(choices[0], "message", None)
                    response_text = getattr(msg, "content", "") or ""

            trace = Trace(
                project_id        = self._prism.config.api_key,
                endpoint          = self._endpoint,
                model             = model,
                prompt_tokens     = prompt_tokens,
                completion_tokens = completion_tokens,
                latency_ms        = latency_ms,
                status_code       = status,
                user_id           = self._user_id,
                session_id        = self._session_id,
                prompt_preview    = _preview(prompt_text),
                response_preview  = _preview(response_text),
                prompt_name       = prompt_name,
                prompt_version    = prompt_version,
            )
            self._prism.record(trace)

        return response
