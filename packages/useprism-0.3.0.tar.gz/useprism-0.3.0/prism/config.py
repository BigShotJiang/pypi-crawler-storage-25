from dataclasses import dataclass, field


@dataclass
class Config:
    api_key: str
    base_url: str = "https://api.useprism.dev"
    endpoint: str | None = None
    flush_interval: float = 2.0
    batch_size: int = 20
    debug: bool = False
