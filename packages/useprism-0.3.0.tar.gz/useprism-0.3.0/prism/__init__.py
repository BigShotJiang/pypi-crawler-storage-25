"""
Prism SDK — LLM Observability in 3 lines.

Usage:
    import prism
    prism.init("prism_your_api_key")
    client = prism.wrap(anthropic_client)
"""

from .client import PrismClient
from .wrappers import wrap
from .config import Config

_instance: PrismClient | None = None


def init(
    api_key: str,
    base_url: str = "https://api.useprism.dev",
    endpoint: str | None = None,
    flush_interval: float = 2.0,
    batch_size: int = 20,
    debug: bool = False,
):
    """
    Initialise the Prism SDK.

    Args:
        api_key:        Your Prism project API key (prism_...)
        base_url:       Prism API URL (default: production)
        endpoint:       Override the endpoint label for all traces
        flush_interval: Seconds between batch flushes (default: 2s)
        batch_size:     Max traces per batch request (default: 20)
        debug:          Print debug logs to stdout
    """
    global _instance
    config = Config(
        api_key=api_key,
        base_url=base_url.rstrip("/"),
        endpoint=endpoint,
        flush_interval=flush_interval,
        batch_size=batch_size,
        debug=debug,
    )
    _instance = PrismClient(config)
    _instance.start()
    return _instance


def get_client() -> PrismClient:
    if _instance is None:
        raise RuntimeError("Call prism.init() before using the SDK.")
    return _instance


def wrap(client, endpoint: str | None = None, user_id: str | None = None, session_id: str | None = None):
    """
    Wrap an LLM client to auto-trace all calls.

    Supports: anthropic.Anthropic, openai.OpenAI
    """
    return get_client().wrap(client, endpoint=endpoint, user_id=user_id, session_id=session_id)


def shutdown():
    """Flush remaining traces and stop background thread."""
    if _instance:
        _instance.shutdown()
