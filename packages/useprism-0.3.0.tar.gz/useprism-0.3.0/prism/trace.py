from dataclasses import dataclass, field
from typing import Optional

# Cost per 1M tokens (input, output)
_COST_TABLE: dict[str, tuple[float, float]] = {
    "claude-opus-4-6":           (15.00, 75.00),
    "claude-sonnet-4-6":         (3.00,  15.00),
    "claude-haiku-4-5-20251001": (0.80,   4.00),
    "gpt-4o":                    (2.50,  10.00),
    "gpt-4o-mini":               (0.15,   0.60),
    "gpt-4-turbo":               (10.00, 30.00),
    "gpt-3.5-turbo":             (0.50,   1.50),
    "gemini-1.5-pro":            (3.50,  10.50),
    "gemini-1.5-flash":          (0.075,  0.30),
}


def _calc_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    rates = _COST_TABLE.get(model, (5.00, 15.00))
    return round((prompt_tokens / 1_000_000) * rates[0] + (completion_tokens / 1_000_000) * rates[1], 8)


def _detect_provider(model: str) -> str:
    if model.startswith("claude"):  return "anthropic"
    if model.startswith(("gpt", "o1", "o3")): return "openai"
    if model.startswith("gemini"): return "google"
    return "unknown"


@dataclass
class Trace:
    project_id:        str
    endpoint:          str
    model:             str
    prompt_tokens:     int
    completion_tokens: int
    latency_ms:        int
    status_code:       int
    user_id:           Optional[str] = None
    session_id:        Optional[str] = None
    metadata:          dict = field(default_factory=dict)
    prompt_preview:    Optional[str] = None
    response_preview:  Optional[str] = None
    prompt_name:       Optional[str] = None
    prompt_version:    Optional[str] = None

    @property
    def provider(self) -> str:
        return _detect_provider(self.model)

    @property
    def cost_usd(self) -> float:
        return _calc_cost(self.model, self.prompt_tokens, self.completion_tokens)

    def to_dict(self) -> dict:
        return {
            "project_id":        self.project_id,
            "endpoint":          self.endpoint,
            "model":             self.model,
            "provider":          self.provider,
            "prompt_tokens":     self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "latency_ms":        self.latency_ms,
            "status_code":       self.status_code,
            "cost_usd":          self.cost_usd,
            "user_id":           self.user_id,
            "session_id":        self.session_id,
            "metadata":          self.metadata,
            "prompt_preview":    self.prompt_preview,
            "response_preview":  self.response_preview,
            "prompt_name":       self.prompt_name,
            "prompt_version":    self.prompt_version,
        }
