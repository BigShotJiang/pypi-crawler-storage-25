"""
Manual tracing utilities for custom LLM calls or HTTP clients.

Usage:
    with prism.trace("my-custom-model", endpoint="/api/summarize") as t:
        response = my_custom_llm_call(...)
        t.set_tokens(prompt=500, completion=200)
        t.set_response(response.text)
"""
import time
from contextlib import contextmanager
from typing import Generator

from .trace import Trace
from . import get_client


class TraceContext:
    def __init__(self, model: str, endpoint: str):
        self.model = model
        self.endpoint = endpoint
        self._prompt_tokens = 0
        self._completion_tokens = 0
        self._prompt_preview = ""
        self._response_preview = ""
        self._user_id = None
        self._metadata = {}
        self._status = 200
        self._t0 = time.monotonic()

    def set_tokens(self, prompt: int = 0, completion: int = 0):
        self._prompt_tokens = prompt
        self._completion_tokens = completion

    def set_prompt(self, text: str):
        self._prompt_preview = text[:500]

    def set_response(self, text: str):
        self._response_preview = text[:500]

    def set_user(self, user_id: str):
        self._user_id = user_id

    def set_metadata(self, **kwargs):
        self._metadata.update(kwargs)

    def set_error(self, status_code: int = 500):
        self._status = status_code

    def _build(self) -> Trace:
        latency_ms = int((time.monotonic() - self._t0) * 1000)
        client = get_client()
        return Trace(
            project_id=client.config.api_key,
            endpoint=self.endpoint,
            model=self.model,
            prompt_tokens=self._prompt_tokens,
            completion_tokens=self._completion_tokens,
            latency_ms=latency_ms,
            status_code=self._status,
            user_id=self._user_id,
            metadata=self._metadata,
            prompt_preview=self._prompt_preview,
            response_preview=self._response_preview,
        )


@contextmanager
def trace(
    model: str,
    endpoint: str = "/custom",
) -> Generator[TraceContext, None, None]:
    """
    Context manager for manually tracing any LLM call.

    Example:
        with prism.trace("my-model", endpoint="/api/chat") as t:
            result = call_my_model(prompt)
            t.set_tokens(prompt=100, completion=50)
            t.set_response(result)
    """
    ctx = TraceContext(model=model, endpoint=endpoint)
    try:
        yield ctx
    except Exception as e:
        ctx.set_error(500)
        raise
    finally:
        client = get_client()
        client.record(ctx._build())
