# prism-sdk

LLM Observability in 3 lines. Costs, latency, errors and quality — automatically.

```bash
pip install useprism
```

---

## Quick Start

### With Anthropic

```python
import anthropic
import prism

# 1. Init
prism.init("prism_your_api_key")

# 2. Wrap your client
client = prism.wrap(anthropic.Anthropic())

# 3. Use exactly as before — everything is traced automatically
response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Summarise this contract..."}],
)
```

### With OpenAI

```python
import openai
import prism

prism.init("prism_your_api_key")
client = prism.wrap(openai.OpenAI())

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

### With a custom / unsupported client

```python
import prism
from prism.manual import trace

prism.init("prism_your_api_key")

with trace("my-model", endpoint="/api/summarize") as t:
    result = my_custom_llm_call(prompt)
    t.set_tokens(prompt=500, completion=200)
    t.set_response(result.text)
```

---

## Configuration

```python
prism.init(
    api_key="prism_your_api_key",
    debug=True,           # print logs to stdout
    flush_interval=2.0,   # seconds between batch flushes
    batch_size=20,        # traces per batch request
)
```

---

## What gets tracked automatically

| Field            | Description                            |
|------------------|----------------------------------------|
| `model`          | Model name (e.g. claude-sonnet-4-6)   |
| `provider`       | anthropic / openai / google            |
| `prompt_tokens`  | Input tokens used                      |
| `completion_tokens` | Output tokens used                  |
| `cost_usd`       | Calculated cost (server-side)          |
| `latency_ms`     | End-to-end response time               |
| `status_code`    | 200 on success, 4xx/5xx on errors      |
| `prompt_preview` | First 500 chars of the prompt          |
| `response_preview` | First 500 chars of the response      |

---

## FastAPI integration example

```python
from fastapi import FastAPI, Request
import anthropic
import prism

prism.init("prism_your_api_key")
app = FastAPI()

@app.post("/api/chat")
async def chat(request: Request):
    body = await request.json()

    # Wrap per-request for endpoint-level tracking
    client = prism.wrap(
        anthropic.Anthropic(),
        endpoint="/api/chat",
    )

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        messages=[{"role": "user", "content": body["message"]}],
    )
    return {"reply": response.content[0].text}
```

---

## Overhead

- **~0ms** added to your LLM calls (async background thread)
- Traces are batched and sent every 2 seconds
- On shutdown, all pending traces are flushed

---

## License

MIT
