import os
import torch
import random
import numpy as np
from PIL import Image
from diffusers import (
    ControlNetModel,
    StableDiffusionXLInstantIDPipeline,
    EDDPMScheduler
)
from insightface.app import FaceAnalysis
from deep_translator import GoogleTranslator

# Cihaz ve Veri Tipi Ayarları
device = "cuda" if torch.cuda.is_available() else "cpu"
dtype = torch.float16 if device == "cuda" else torch.float32
OUTPUT_FILE = "vho_tutarlı.png"

# Kalite ve Çeviri Ayarları
NEGATIVE_PROMPT = (
    "lowres, bad anatomy, bad hands, text, error, missing fingers, "
    "extra digit, fewer digits, cropped, worst quality, low quality, blurry"
)
QUALITY_LOCK = "masterpiece, incredible detail, photo-realistic, 8k uhd, highly detailed face"
translator = GoogleTranslator(source="tr", target="en")

# 1. Modelleri Hazırla (Global tanımlama hızı artırır)
app = FaceAnalysis(name="antelopev2", root="./", providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
app.prepare(ctx_id=0, det_size=(640, 640))

# InstantID ve ControlNet Yükleme
controlnet = ControlNetModel.from_pretrained(
    "InstantX/InstantID",
    subfolder="ControlNetModel",
    torch_dtype=dtype
).to(device)

pipe = StableDiffusionXLInstantIDPipeline.from_pretrained(
    "stabilityai/stable-diffusion-xl-base-1.0",
    controlnet=controlnet,
    torch_dtype=dtype
).to(device)

pipe.scheduler = EDDPMScheduler.from_config(pipe.scheduler.config)
pipe.load_ip_adapter_instantid("InstantX/InstantID", subfolder="ip_adapter", weight_name="ip_adapter.bin")

def get_face_info(image: Image):
    """Görselden yüz hatlarını ve embedding verisini çıkarır."""
    face_data = np.array(image)
    faces = app.get(face_data)
    if len(faces) == 0:
        raise ValueError("Görselde yüz bulunamadı!")
    # En büyük yüzü al
    face = sorted(faces, key=lambda x: (x.bbox[2] - x.bbox[0]) * (x.bbox[3] - x.bbox[1]))[-1]
    return face

def create_foto(
    foto: str, 
    prompt: str, 
    seed: int = None, 
    steps: int = 30, 
    cfg: float = 5.0,
    identity_strength: float = 0.8
) -> str:
    """Karakter tutarlı görsel oluşturur."""
    if not os.path.exists(foto):
        raise FileNotFoundError(f"Görsel bulunamadı: {foto}")

    # Girdi resmini hazırla
    face_image = Image.open(foto).convert("RGB")
    face_info = get_face_info(face_image)
    
    # Prompt Çevirisi
    translated = translator.translate(prompt)
    final_prompt = f"{translated}, {QUALITY_LOCK}"

    # Üretim Ayarları
    if seed is None:
        seed = random.randint(0, 2**32 - 1)
    generator = torch.Generator(device=device).manual_seed(seed)

    # Görsel Üretimi (Safety Checker Kapalı)
    result = pipe(
        prompt=final_prompt,
        negative_prompt=NEGATIVE_PROMPT,
        image_embeds=face_info.embedding,
        image=face_image,
        controlnet_conditioning_scale=0.6,
        ip_adapter_scale=identity_strength,
        num_inference_steps=steps,
        guidance_scale=cfg,
        generator=generator
    ).images[0]

    result.save(OUTPUT_FILE)
    print(f"Başarıyla kaydedildi: {OUTPUT_FILE} (Seed: {seed})")
    return os.path.abspath(OUTPUT_FILE)
    