"""
docker_wts_build.builder — Docker build engine.

This module is designed to be run either:
- By Windows Task Scheduler (via wrapper .cmd file)
- Directly from the MCP server (for testing)

All parameters are passed via environment variables (DWTB_* prefix):
    DWTB_PROJECT_DIR     — path to project with docker-compose.yml
    DWTB_COMPOSE_FILE    — compose file name (default: docker-compose.yml)
    DWTB_CUSTOM_SERVICES — semicolon-separated service list
    DWTB_LOGS_DIR        — logs directory
    BUILD_ACTION         — build_all | build | rebuild_all | rebuild
    BUILD_SERVICE        — service name (for build/rebuild actions)
    BUILD_NO_CACHE       — true | false (default: false)
    BUILD_TASK_ID        — unique task ID for log file naming
"""

import os
import subprocess
import sys
import time

from .utils import (
    ensure_logs_dir,
    get_compose_file,
    get_custom_services,
    get_logs_dir,
    get_project_dir,
    log_path,
    safe_print,
    write_exit_code,
)


# ─── Helpers ──────────────────────────────────────────────────────────────────


def get_env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


def run_command(cmd: list, task_id: str, label: str) -> int:
    """
    Run a command, tee stdout/stderr to both console and log files.
    Returns exit code.
    """
    log_file = log_path(task_id, "log")
    err_file = log_path(task_id, "err")

    print(f"\n{'='*60}")
    print(f"[{label}] Running: {' '.join(cmd)}")
    print(f"[{label}] Log: {log_file}")
    print(f"{'='*60}\n")

    with open(log_file, "a", encoding="utf-8") as log_f, \
         open(err_file, "a", encoding="utf-8") as err_f:

        # Write header to log
        header = f"\n--- [{label}] {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n"
        log_f.write(header)
        err_f.write(header)

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            cwd=get_project_dir(),
        )

        # Read stdout line by line
        for line in process.stdout:
            print(line, end="")
            log_f.write(line)
            log_f.flush()

        # Read stderr
        for line in process.stderr:
            print(line, end="", file=sys.stderr)
            err_f.write(line)
            err_f.flush()

        process.wait()
        return process.returncode


# ─── Build Actions ────────────────────────────────────────────────────────────


def build_service(service: str, no_cache: bool, task_id: str) -> int:
    """Build a single service."""
    compose_file = os.path.join(get_project_dir(), get_compose_file())
    cmd = [
        "docker", "compose",
        "-f", compose_file,
        "build",
    ]
    if no_cache:
        cmd.append("--no-cache")
    cmd.append(service)
    return run_command(cmd, task_id, f"build:{service}")


def build_all(no_cache: bool, task_id: str) -> int:
    """Build all custom services sequentially."""
    services = get_custom_services()
    if not services:
        print("[FAIL] No custom services configured (DWTB_CUSTOM_SERVICES is empty)")
        return 1

    overall_exit = 0
    for service in services:
        print(f"\n{'#'*60}")
        print(f"# Building: {service}")
        print(f"{'#'*60}")
        code = build_service(service, no_cache, task_id)
        if code != 0:
            print(f"[FAIL] {service} failed with exit code {code}")
            overall_exit = code
        else:
            print(f"[OK] {service} built successfully")
    return overall_exit


def rebuild_service(service: str, no_cache: bool, task_id: str) -> int:
    """Rebuild a single service: rm + build + up."""
    compose_file = os.path.join(get_project_dir(), get_compose_file())

    # Stop the service
    cmd_down = [
        "docker", "compose",
        "-f", compose_file,
        "rm", "-f", "-s", service,
    ]
    code = run_command(cmd_down, task_id, f"down:{service}")
    if code != 0:
        print(f"[WARN] 'docker compose rm' for {service} returned {code}")

    # Build
    code = build_service(service, no_cache, task_id)
    if code != 0:
        return code

    # Start
    cmd_up = [
        "docker", "compose",
        "-f", compose_file,
        "up", "-d", service,
    ]
    code = run_command(cmd_up, task_id, f"up:{service}")
    return code


def rebuild_all(no_cache: bool, task_id: str) -> int:
    """Rebuild all custom services: build all + up all."""
    services = get_custom_services()
    if not services:
        print("[FAIL] No custom services configured (DWTB_CUSTOM_SERVICES is empty)")
        return 1

    compose_file = os.path.join(get_project_dir(), get_compose_file())

    code = build_all(no_cache, task_id)
    if code != 0:
        print("[WARN] Some services failed to build, but attempting to start...")

    # Start all custom services
    cmd_up = [
        "docker", "compose",
        "-f", compose_file,
        "up", "-d",
    ] + services
    code = run_command(cmd_up, task_id, "up:all")
    return code


# ─── Main (for Task Scheduler execution) ──────────────────────────────────────


def main():
    action = get_env("BUILD_ACTION")
    service = get_env("BUILD_SERVICE")
    no_cache = get_env("BUILD_NO_CACHE", "false").lower() == "true"
    task_id = get_env("BUILD_TASK_ID", f"build_{int(time.time())}")

    # Ensure logs directory exists
    ensure_logs_dir()

    print("[BUILD] Docker Build System")
    print(f"   Task ID:    {task_id}")
    print(f"   Action:     {action}")
    print(f"   Service:    {service or '(all)'}")
    print(f"   No cache:   {no_cache}")
    print(f"   Project:    {get_project_dir()}")
    print()

    exit_code = 1  # Default: error

    try:
        if action == "build_all":
            exit_code = build_all(no_cache, task_id)
        elif action == "build":
            if not service:
                print("[FAIL] BUILD_SERVICE is required for action 'build'")
                exit_code = 1
            else:
                exit_code = build_service(service, no_cache, task_id)
        elif action == "rebuild_all":
            exit_code = rebuild_all(no_cache, task_id)
        elif action == "rebuild":
            if not service:
                print("[FAIL] BUILD_SERVICE is required for action 'rebuild'")
                exit_code = 1
            else:
                exit_code = rebuild_service(service, no_cache, task_id)
        else:
            print(f"[FAIL] Unknown action: {action}")
            print(f"   Valid actions: build_all, build, rebuild_all, rebuild")
            exit_code = 1
    except Exception as e:
        print(f"[FAIL] Unexpected error: {e}")
        exit_code = 1

    # Write exit code
    write_exit_code(task_id, exit_code)

    print(f"\n{'='*60}")
    if exit_code == 0:
        print(f"[OK] Build completed successfully (exit code: {exit_code})")
    else:
        print(f"[FAIL] Build failed (exit code: {exit_code})")
    print(f"{'='*60}")

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
