"""
docker_wts_build.server — MCP server for Docker builds via Windows Task Scheduler.

Provides three tools:
  - schedule_build: Schedule a Docker build via Windows Task Scheduler
  - check_build: Check build status
  - cleanup_builds: Clean up old build tasks and logs

Usage (stdio mode — for MCP):
    python -m docker_wts_build
"""

import sys
from typing import Any

from . import __version__
from .scheduler import (
    cleanup_old_tasks,
    create_task,
    generate_task_id,
    get_max_task_age_days,
    run_task,
    show_all_tasks,
    show_task_detail,
)
from .utils import (
    get_config,
    get_custom_services,
    get_project_dir,
    safe_print,
)


# ─── MCP Server Implementation ──────────────────────────────────────────────


def create_mcp_server():
    """Create and return an MCP server instance."""
    try:
        from mcp.server import Server
        from mcp.types import Tool
    except ImportError:
        print("ERROR: mcp package not installed. Run: pip install mcp", file=sys.stderr)
        sys.exit(1)

    server = Server("docker-wts-build")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="schedule_build",
                description="Schedule a Docker build via Windows Task Scheduler. "
                            "Use this instead of running docker compose build directly, "
                            "because VS Code terminal has a ~10 min timeout.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["build_all", "build", "rebuild_all", "rebuild"],
                            "description": "Build action: build_all (all images), "
                                           "build (single), rebuild_all, rebuild (single)",
                        },
                        "service": {
                            "type": "string",
                            "description": "Service name (required for build/rebuild). "
                                           "Examples: ad-crewai-core, ad-crewai-stt-batch",
                        },
                        "no_cache": {
                            "type": "boolean",
                            "description": "Disable Docker build cache",
                            "default": False,
                        },
                    },
                    "required": ["action"],
                },
            ),
            Tool(
                name="check_build",
                description="Check the status of Docker builds. "
                            "Shows all builds if no task ID specified.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "task_id": {
                            "type": "string",
                            "description": "Task ID to check "
                                           "(e.g., DockerBuild_20260427_195000). "
                                           "If omitted, shows all builds.",
                        },
                        "lines": {
                            "type": "number",
                            "description": "Number of log lines to show (default: 20)",
                            "default": 20,
                        },
                    },
                },
            ),
            Tool(
                name="cleanup_builds",
                description="Clean up old build tasks and log files "
                            "older than specified days.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "max_age": {
                            "type": "number",
                            "description": "Maximum age in days (default: 30)",
                            "default": 30,
                        },
                    },
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[dict[str, Any]]:
        if name == "schedule_build":
            return await handle_schedule_build(arguments)
        elif name == "check_build":
            return await handle_check_build(arguments)
        elif name == "cleanup_builds":
            return await handle_cleanup_builds(arguments)
        else:
            raise ValueError(f"Unknown tool: {name}")

    return server


# ─── Tool Handlers ──────────────────────────────────────────────────────────


async def handle_schedule_build(args: dict) -> list[dict[str, Any]]:
    action = args.get("action", "build_all")
    service = args.get("service", "")
    no_cache = args.get("no_cache", False)

    if action in ("build", "rebuild") and not service:
        return [{"type": "text", "text": f"[FAIL] --service is required for --action {action}"}]

    # Validate project dir is set
    try:
        get_project_dir()
    except SystemExit:
        return [{"type": "text", "text": "[FAIL] DWTB_PROJECT_DIR environment variable is not set"}]

    # Validate services list for build_all/rebuild_all
    if action in ("build_all", "rebuild_all"):
        services = get_custom_services()
        if not services:
            return [{"type": "text", "text": "[FAIL] DWTB_CUSTOM_SERVICES is empty. "
                                             "Set it to a semicolon-separated list of service names."}]

    # Cleanup old tasks first
    output_lines = []
    output_lines.append("==> Checking for old tasks...")
    cleanup_old_tasks(get_max_task_age_days())
    output_lines.append("")

    # Generate task ID
    task_id = generate_task_id()
    output_lines.append(f"[INFO] Task ID: {task_id}")

    # Prepare environment variables for builder.py
    env_vars = {
        "BUILD_ACTION": action,
        "BUILD_SERVICE": service,
        "BUILD_NO_CACHE": "true" if no_cache else "false",
        "BUILD_TASK_ID": task_id,
    }

    # Create task
    output_lines.append("[INFO] Creating scheduled task...")
    if not create_task(task_id, env_vars):
        return [{"type": "text", "text": "\n".join(output_lines) + "\n[FAIL] Failed to create task"}]

    # Run task
    output_lines.append("[INFO] Starting build...")
    if not run_task(task_id):
        # Try to clean up the failed task
        from .utils import run_schtasks
        run_schtasks(["/delete", "/tn", task_id, "/f"])
        return [{"type": "text", "text": "\n".join(output_lines) + "\n[FAIL] Failed to run task"}]

    output_lines.append("")
    output_lines.append(f"[OK] Task created: {task_id}")
    output_lines.append("")
    output_lines.append("[INFO] To check status:")
    output_lines.append(f"   Use check_build tool with task_id: {task_id}")
    output_lines.append("")
    output_lines.append("[INFO] To view all builds:")
    output_lines.append("   Use check_build tool without task_id")

    return [{"type": "text", "text": "\n".join(output_lines)}]


async def handle_check_build(args: dict) -> list[dict[str, Any]]:
    task_id = args.get("task_id", "")
    lines = args.get("lines", 20)

    # Capture output by redirecting stdout
    import io
    from contextlib import redirect_stdout

    buf = io.StringIO()
    with redirect_stdout(buf):
        if task_id:
            show_task_detail(task_id, lines)
        else:
            show_all_tasks()

    return [{"type": "text", "text": buf.getvalue()}]


async def handle_cleanup_builds(args: dict) -> list[dict[str, Any]]:
    max_age = args.get("max_age", 30)

    import io
    from contextlib import redirect_stdout

    buf = io.StringIO()
    with redirect_stdout(buf):
        from .utils import safe_print

        safe_print(f"[INFO] Cleanup: removing tasks and logs older than {max_age} days")
        print()

        safe_print("[INFO] Checking Task Scheduler...")
        cleanup_old_tasks(max_age)

    return [{"type": "text", "text": buf.getvalue()}]
