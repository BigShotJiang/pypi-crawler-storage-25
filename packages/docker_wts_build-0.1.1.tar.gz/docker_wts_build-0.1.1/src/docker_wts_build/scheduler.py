"""
docker_wts_build.scheduler — Windows Task Scheduler operations.

Handles creating, running, querying, and deleting scheduled tasks
via schtasks.exe for Docker builds.
"""

import datetime
import os
import sys

from .utils import (
    decode_output,
    ensure_logs_dir,
    generate_task_id,
    get_logs_dir,
    get_max_task_age_days,
    get_project_dir,
    get_task_prefix,
    get_task_timeout_ms,
    read_exit_code,
    read_log_file,
    run_schtasks,
    safe_print,
)


# ─── Task Creation ────────────────────────────────────────────────────────────


def create_task_cmd_wrapper(task_id: str, env_vars: dict) -> str:
    """
    Create a .cmd wrapper file that sets environment variables and
    calls the build script. Returns the path to the wrapper file.
    """
    logs_dir = get_logs_dir()
    wrapper_path = os.path.join(logs_dir, f"{task_id}_wrapper.cmd")

    # Get the path to the builder module
    builder_module = os.path.join(os.path.dirname(__file__), "builder.py")

    with open(wrapper_path, "w", encoding="utf-8") as f:
        f.write("@echo off\r\n")
        f.write(f"cd /d \"{get_project_dir()}\"\r\n")
        f.write("setlocal\r\n")
        for key, value in env_vars.items():
            f.write(f"set {key}={value}\r\n")
        f.write(f"\"{sys.executable}\" \"{builder_module}\"\r\n")
        f.write("endlocal\r\n")

    return wrapper_path


def create_task(task_id: str, env_vars: dict) -> bool:
    """Create a scheduled task via schtasks.exe /create (CLI-based)."""
    ensure_logs_dir()

    # Create wrapper .cmd file
    wrapper_path = create_task_cmd_wrapper(task_id, env_vars)

    # Create task with /sc once and a past date so it doesn't auto-run
    result = run_schtasks([
        "/create",
        "/tn", task_id,
        "/tr", wrapper_path,
        "/sc", "once",
        "/st", "00:00",
        "/sd", "01/01/2000",
        "/f",
    ])

    if result.returncode != 0:
        err = decode_output(result.stderr)
        safe_print(f"[FAIL] Failed to create task: {err}")
        # Clean up wrapper
        try:
            os.remove(wrapper_path)
        except OSError:
            pass
        return False

    return True


def run_task(task_id: str) -> bool:
    """Run the scheduled task immediately."""
    result = run_schtasks(["/run", "/tn", task_id])
    if result.returncode != 0:
        err = decode_output(result.stderr)
        safe_print(f"[FAIL] Failed to run task: {err}")
        return False
    return True


# ─── Task Querying ────────────────────────────────────────────────────────────


def get_task_status(task_name: str) -> dict:
    """
    Get detailed status of a single task.
    Returns dict with: name, status, last_run, next_run, exit_code
    """
    result = run_schtasks(["/query", "/tn", task_name, "/fo", "LIST", "/v"])

    info = {
        "name": task_name,
        "status": "UNKNOWN",
        "last_run": "",
        "next_run": "",
        "exit_code": "",
    }

    if result.returncode != 0:
        info["status"] = "NOT_FOUND"
        return info

    for line in decode_output(result.stdout).splitlines():
        line = line.strip()
        if line.startswith("Status:"):
            info["status"] = line.split(":", 1)[1].strip()
        elif line.startswith("Last Run Time:"):
            info["last_run"] = line.split(":", 1)[1].strip()
        elif line.startswith("Next Run Time:"):
            info["next_run"] = line.split(":", 1)[1].strip()
        elif line.startswith("Last Result:"):
            info["exit_code"] = line.split(":", 1)[1].strip()

    return info


def get_all_build_tasks() -> list:
    """Get list of all build tasks from Task Scheduler."""
    prefix = get_task_prefix()
    result = run_schtasks(["/query", "/fo", "LIST", "/v"])

    tasks = []
    if result.returncode != 0:
        return tasks

    current_task = {}

    for line in decode_output(result.stdout).splitlines():
        line = line.strip()
        if line.startswith("TaskName:"):
            # Save previous task if it's ours
            if current_task.get("name", "").startswith(f"\\{prefix}"):
                tasks.append(current_task)
            # Start new task
            name = line.split(":", 1)[1].strip()
            current_task = {"name": name}
        elif line.startswith("Status:"):
            current_task["status"] = line.split(":", 1)[1].strip()
        elif line.startswith("Last Run Time:"):
            current_task["last_run"] = line.split(":", 1)[1].strip()
        elif line.startswith("Next Run Time:"):
            current_task["next_run"] = line.split(":", 1)[1].strip()
        elif line.startswith("Last Result:"):
            current_task["exit_code"] = line.split(":", 1)[1].strip()

    # Don't forget the last task
    if current_task.get("name", "").startswith(f"\\{prefix}"):
        tasks.append(current_task)

    return tasks


# ─── Task Deletion ────────────────────────────────────────────────────────────


def delete_task(task_name: str) -> bool:
    """Delete a scheduled task."""
    result = run_schtasks(["/delete", "/tn", task_name, "/f"])
    return result.returncode == 0


def delete_log_file(task_id: str, suffix: str) -> bool:
    """Delete a log file."""
    from .utils import log_path

    filepath = log_path(task_id, suffix)
    try:
        if os.path.isfile(filepath):
            os.remove(filepath)
            return True
    except OSError:
        pass
    return False


# ─── Cleanup ──────────────────────────────────────────────────────────────────


def is_task_older_than(task_name: str, cutoff_date: str) -> bool:
    """
    Check if a task is older than cutoff_date based on its name.
    Task name format: {prefix}_YYYYMMDD_HHMMSS
    """
    clean_name = task_name.lstrip("\\")
    parts = clean_name.split("_")
    if len(parts) >= 3:
        task_date = parts[2]
        return task_date < cutoff_date
    return False


def cleanup_old_tasks(max_age_days: int = 30) -> None:
    """
    Remove tasks and log files older than max_age_days.
    Also removes orphaned log files (without corresponding task).
    """
    prefix = get_task_prefix()
    cutoff = datetime.datetime.now() - datetime.timedelta(days=max_age_days)
    cutoff_str = cutoff.strftime("%Y%m%d")

    # Get all build tasks
    result = run_schtasks(["/query", "/fo", "LIST", "/v"])
    if result.returncode != 0:
        return

    tasks_to_delete = []
    current_task_name = None

    for line in decode_output(result.stdout).splitlines():
        line = line.strip()
        if line.startswith("TaskName:"):
            parts = line.split(":", 1)
            if len(parts) > 1:
                current_task_name = parts[1].strip()
                if current_task_name.startswith(f"\\{prefix}"):
                    task_parts = current_task_name.split("_")
                    if len(task_parts) >= 3:
                        task_date = task_parts[2]
                        if task_date < cutoff_str:
                            tasks_to_delete.append(current_task_name)

    # Delete old tasks
    for task_name in tasks_to_delete:
        display_name = task_name.lstrip("\\")
        result = run_schtasks(["/delete", "/tn", task_name, "/f"])
        if result.returncode == 0:
            print(f"  [OK] Deleted task: {display_name}")
        else:
            err = decode_output(result.stderr)
            safe_print(f"  [WARN] Failed to delete task {display_name}: {err}")

    # Clean up old log files and wrapper .cmd files
    logs_dir = get_logs_dir()
    if os.path.isdir(logs_dir):
        for filename in os.listdir(logs_dir):
            if not filename.startswith(prefix):
                continue
            parts = filename.split("_")
            if len(parts) >= 3:
                file_date = parts[2]
                if file_date < cutoff_str:
                    filepath = os.path.join(logs_dir, filename)
                    try:
                        os.remove(filepath)
                        print(f"  [OK] Deleted: {filename}")
                    except OSError:
                        pass

    if tasks_to_delete:
        print(f"  Cleaned up {len(tasks_to_delete)} old task(s)")


# ─── Display ──────────────────────────────────────────────────────────────────


def show_all_tasks() -> None:
    """Show all build tasks."""
    from .utils import format_status_icon

    tasks = get_all_build_tasks()

    if not tasks:
        print("No build tasks found")
        print()
        print("To start a build:")
        print("   python -m docker_wts_build --schedule build_all")
        return

    print(f"Found {len(tasks)} task(s)")
    print()

    for task in tasks:
        display_name = task["name"].lstrip("\\")
        status = task.get("status", "UNKNOWN")
        last_run = task.get("last_run", "")
        exit_code_str = task.get("exit_code", "")

        # Try to read exit code from file
        file_exit_code = read_exit_code(display_name)
        exit_code_display = file_exit_code if file_exit_code >= 0 else exit_code_str

        icon = format_status_icon(status, file_exit_code)

        print(f"  {icon} {display_name}")
        print(f"     Status:    {status}")
        if last_run and last_run not in ("N/A", ""):
            print(f"     Last run:  {last_run}")
        if exit_code_display not in ("", "-1", "N/A"):
            print(f"     Exit code: {exit_code_display}")

        # Show last log lines if task is running or completed
        if status == "Running":
            log_lines = read_log_file(display_name, "log", 5)
            if log_lines:
                print(f"     -- Last log lines --")
                for line in log_lines:
                    print(f"     {line.rstrip()}")
        elif file_exit_code >= 0:
            log_lines = read_log_file(display_name, "log", 3)
            if log_lines:
                print(f"     -- Last log lines --")
                for line in log_lines:
                    print(f"     {line.rstrip()}")

        print()


def show_task_detail(task_id: str, num_lines: int = 20) -> None:
    """Show detailed status of a specific task."""
    from .utils import format_status_icon

    # Get task status from Task Scheduler
    task_info = get_task_status(task_id)

    if task_info["status"] == "NOT_FOUND":
        # Check if we have log files anyway
        log_lines = read_log_file(task_id, "log", num_lines)
        err_lines = read_log_file(task_id, "err", num_lines)
        exit_code = read_exit_code(task_id)

        if not log_lines and not err_lines:
            print(f"[FAIL] Task '{task_id}' not found in Task Scheduler")
            print(f"   And no log files found in {get_logs_dir()}")
            return

        print(f"[INFO] {task_id}")
        print(f"   Status:    COMPLETED (task removed from scheduler)")
        if exit_code >= 0:
            icon = "[OK]" if exit_code == 0 else "[FAIL]"
            print(f"   Exit code: {icon} {exit_code}")
        print()
    else:
        display_name = task_info["name"].lstrip("\\")
        status = task_info["status"]
        exit_code_str = task_info.get("exit_code", "")
        file_exit_code = read_exit_code(display_name)
        exit_code_display = file_exit_code if file_exit_code >= 0 else exit_code_str

        icon = format_status_icon(status, file_exit_code)

        print(f"[INFO] {display_name}")
        print(f"   Status:    {icon} {status}")
        if task_info.get("last_run") and task_info["last_run"] not in ("N/A", ""):
            print(f"   Last run:  {task_info['last_run']}")
        if exit_code_display not in ("", "-1", "N/A"):
            print(f"   Exit code: {exit_code_display}")
        print()

    # Show log
    log_lines = read_log_file(task_id, "log", num_lines)
    err_lines = read_log_file(task_id, "err", num_lines)

    if log_lines:
        print(f"   [LOG] Last {len(log_lines)} lines of stdout:")
        print(f"   {'-'*50}")
        for line in log_lines:
            print(f"   {line.rstrip()}")
        print()

    if err_lines:
        print(f"   [ERR] Last {len(err_lines)} lines of stderr:")
        print(f"   {'-'*50}")
        for line in err_lines:
            print(f"   {line.rstrip()}")
        print()

    # Show log file paths
    log_path = os.path.join(get_logs_dir(), f"{task_id}.log")
    err_path = os.path.join(get_logs_dir(), f"{task_id}.err")
    exit_path = os.path.join(get_logs_dir(), f"{task_id}.exit")

    print(f"   Files:")
    print(f"      stdout: {log_path}" if os.path.isfile(log_path) else f"      stdout: (not found)")
    print(f"      stderr: {err_path}" if os.path.isfile(err_path) else f"      stderr: (not found)")
    print(f"      exit:   {exit_path}" if os.path.isfile(exit_path) else f"      exit:   (not found)")
