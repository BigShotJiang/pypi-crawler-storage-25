"""
docker_wts_build.utils — Shared utilities for Docker+WTS build system.

Provides safe printing, schtasks execution, log file management,
and configuration helpers used by scheduler, builder, and server modules.
"""

import datetime
import locale
import os
import subprocess
import sys
from typing import Optional


# ─── Configuration ────────────────────────────────────────────────────────────

# All config comes from environment variables (DWTB_* prefix).
# This makes the package universal — no hardcoded project paths.


def get_config(key: str, default: str = "") -> str:
    """Get a DWTB_* configuration value from environment."""
    return os.environ.get(f"DWTB_{key}", default)


def get_project_dir() -> str:
    """Get the project directory (must be set)."""
    val = get_config("PROJECT_DIR")
    if not val:
        print("[FAIL] DWTB_PROJECT_DIR is not set", file=sys.stderr)
        sys.exit(1)
    return val


def get_compose_file() -> str:
    """Get the docker-compose file path."""
    return get_config("COMPOSE_FILE", "docker-compose.yml")


def get_custom_services() -> list[str]:
    """Get the list of custom services (semicolon-separated)."""
    val = get_config("CUSTOM_SERVICES", "")
    if not val:
        return []
    return [s.strip() for s in val.split(";") if s.strip()]


def get_logs_dir() -> str:
    """Get the logs directory."""
    return get_config("LOGS_DIR", os.path.join(get_project_dir(), "builds", "logs"))


def get_task_prefix() -> str:
    """Get the task name prefix."""
    return get_config("TASK_PREFIX", "DockerBuild")


def get_task_timeout_ms() -> int:
    """Get the task timeout in milliseconds."""
    try:
        return int(get_config("TASK_TIMEOUT_MS", "28800000"))
    except ValueError:
        return 28800000


def get_max_task_age_days() -> int:
    """Get the default max age for cleanup."""
    try:
        return int(get_config("MAX_TASK_AGE_DAYS", "30"))
    except ValueError:
        return 30


# ─── Safe Printing ────────────────────────────────────────────────────────────


def safe_print(text: str) -> None:
    """Print text safely in Windows console (handles cp866 encoding issues)."""
    try:
        print(text)
    except UnicodeEncodeError:
        enc = locale.getpreferredencoding(do_setlocale=False)
        safe = text.encode(enc, errors="replace").decode(enc, errors="replace")
        print(safe)


# ─── schtasks Helpers ─────────────────────────────────────────────────────────


def run_schtasks(args: list) -> subprocess.CompletedProcess:
    """Run schtasks.exe with given arguments, return raw bytes."""
    cmd = ["schtasks"] + args
    result = subprocess.run(cmd, capture_output=True)
    return result


def decode_output(data: bytes) -> str:
    """Decode schtasks output using cp866 (OEM encoding on Russian Windows)."""
    return data.decode("cp866", errors="replace")


# ─── Log File Management ──────────────────────────────────────────────────────


def log_path(task_id: str, suffix: str) -> str:
    """Get the full path to a log file for the given task ID."""
    return os.path.join(get_logs_dir(), f"{task_id}.{suffix}")


def write_exit_code(task_id: str, code: int) -> None:
    """Write exit code to a file for later retrieval."""
    path = log_path(task_id, "exit")
    with open(path, "w") as f:
        f.write(str(code))


def read_exit_code(task_id: str) -> int:
    """Read exit code from file. Returns -1 if not found."""
    filepath = log_path(task_id, "exit")
    if not os.path.isfile(filepath):
        return -1
    try:
        with open(filepath, "r") as f:
            return int(f.read().strip())
    except (ValueError, OSError):
        return -1


def read_log_file(task_id: str, suffix: str, num_lines: int = 20) -> list[str]:
    """Read last N lines from a log file."""
    filepath = log_path(task_id, suffix)
    if not os.path.isfile(filepath):
        return []

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            lines = f.readlines()
        return lines[-num_lines:]
    except (OSError, UnicodeDecodeError):
        return []


def ensure_logs_dir() -> None:
    """Ensure the logs directory exists."""
    os.makedirs(get_logs_dir(), exist_ok=True)


# ─── Task ID Generation ───────────────────────────────────────────────────────


def generate_task_id() -> str:
    """Generate unique task ID: {prefix}_YYYYMMDD_HHMMSS"""
    prefix = get_task_prefix()
    now = datetime.datetime.now()
    return f"{prefix}_{now.strftime('%Y%m%d_%H%M%S')}"


# ─── Status Formatting ────────────────────────────────────────────────────────


def format_status_icon(status: str, exit_code: int) -> str:
    """Return status icon based on task status and exit code."""
    if status == "Running":
        return "[RUN]"
    elif status in ("Ready", "Queued"):
        if exit_code == 0:
            return "[OK]"
        elif exit_code > 0:
            return "[FAIL]"
        else:
            return "[WAIT]"
    elif status == "NOT_FOUND":
        return "[?]"
    else:
        return "[?]"
