"""
docker-wts-build — Docker builds via Windows Task Scheduler.

A self-contained MCP server that provides tools to schedule, check,
and clean up Docker builds via Windows Task Scheduler (schtasks.exe).

Configuration via environment variables (DWTB_* prefix):
    DWTB_PROJECT_DIR      — Path to project with docker-compose.yml (required)
    DWTB_COMPOSE_FILE     — Compose file name (default: docker-compose.yml)
    DWTB_CUSTOM_SERVICES  — Semicolon-separated service list
    DWTB_LOGS_DIR         — Logs directory (default: {project_dir}/builds/logs)
    DWTB_TASK_PREFIX      — Task name prefix (default: DockerBuild)
    DWTB_TASK_TIMEOUT_MS  — Task timeout in ms (default: 28800000 = 8h)
    DWTB_MAX_TASK_AGE_DAYS — Default cleanup age (default: 30)
"""

__version__ = "0.1.1"
