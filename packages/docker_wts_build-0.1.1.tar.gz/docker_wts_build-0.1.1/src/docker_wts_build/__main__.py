"""
docker_wts_build.__main__ — Entry point for `python -m docker_wts_build`.

Usage:
    python -m docker_wts_build              # Run as MCP server (stdio mode)
    python -m docker_wts_build --help        # Show CLI help
    python -m docker_wts_build --schedule build_all
    python -m docker_wts_build --check
    python -m docker_wts_build --check DockerBuild_20260427_195000
    python -m docker_wts_build --cleanup
    python -m docker_wts_build --cleanup 14
"""

import argparse
import asyncio
import sys

from . import __version__
from .scheduler import show_all_tasks, show_task_detail, cleanup_old_tasks
from .server import handle_schedule_build, handle_check_build, handle_cleanup_builds
from .utils import safe_print


def run_cli():
    """Run in CLI mode for testing."""
    parser = argparse.ArgumentParser(
        description="docker-wts-build — Docker builds via Windows Task Scheduler"
    )
    parser.add_argument("--version", action="store_true", help="Show version")
    parser.add_argument("--schedule", choices=["build_all", "build", "rebuild_all", "rebuild"])
    parser.add_argument("--service", default="")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--check", nargs="?", const="", default=None)
    parser.add_argument("--cleanup", type=int, nargs="?", const=30, default=None)
    parser.add_argument("--lines", type=int, default=20)
    args = parser.parse_args()

    if args.version:
        print(f"docker-wts-build v{__version__}")
        return

    if args.schedule:
        result = asyncio.run(handle_schedule_build({
            "action": args.schedule,
            "service": args.service,
            "no_cache": args.no_cache,
        }))
        for item in result:
            safe_print(item["text"])

    elif args.check is not None:
        result = asyncio.run(handle_check_build({
            "task_id": args.check if args.check else "",
            "lines": args.lines,
        }))
        for item in result:
            safe_print(item["text"])

    elif args.cleanup is not None:
        result = asyncio.run(handle_cleanup_builds({
            "max_age": args.cleanup,
        }))
        for item in result:
            safe_print(item["text"])

    else:
        parser.print_help()


def main():
    # If CLI args provided, run in CLI mode
    if len(sys.argv) > 1:
        run_cli()
        return

    # Otherwise run as MCP server (stdio mode)
    from .server import create_mcp_server
    from mcp.server.stdio import stdio_server

    server = create_mcp_server()

    async def run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    asyncio.run(run())


if __name__ == "__main__":
    main()
