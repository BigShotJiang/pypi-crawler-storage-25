<!-- mcp-name: io.github.dbpj/docker-wts-build -->

# docker-wts-build

**Docker builds via Windows Task Scheduler** — an MCP server for Cline.

## Problem

VS Code terminal has a ~10 minute timeout. Docker builds (especially with
torch, cudnn, etc.) can take 30+ minutes. If Cline interrupts the task,
the build is lost.

## Solution

This MCP server schedules Docker builds as Windows Task Scheduler tasks.
The build runs outside VS Code, survives interruptions, and logs progress
to files for later inspection.

## Installation

```bash
pip install docker-wts-build
```

## Configuration

Set these environment variables (in `cline_mcp_settings.json`):

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DWTB_PROJECT_DIR` | Yes | — | Path to project with `docker-compose.yml` |
| `DWTB_COMPOSE_FILE` | No | `docker-compose.yml` | Compose file name |
| `DWTB_CUSTOM_SERVICES` | No | — | Semicolon-separated service list |
| `DWTB_LOGS_DIR` | No | `{project_dir}/builds/logs` | Logs directory |
| `DWTB_TASK_PREFIX` | No | `DockerBuild` | Task name prefix |
| `DWTB_TASK_TIMEOUT_MS` | No | `28800000` (8h) | Task timeout |
| `DWTB_MAX_TASK_AGE_DAYS` | No | `30` | Default cleanup age |

## Usage

### As MCP server (for Cline)

Add to `cline_mcp_settings.json`:

```json
{
  "mcpServers": {
    "docker-wts-build": {
      "autoApprove": ["schedule_build", "check_build", "cleanup_builds"],
      "disabled": false,
      "timeout": 120,
      "command": "python",
      "args": ["-m", "docker_wts_build"],
      "env": {
        "DWTB_PROJECT_DIR": "C:\\path\\to\\my-project",
        "DWTB_CUSTOM_SERVICES": "service-1;service-2;service-3"
      },
      "type": "stdio"
    }
  }
}
```

### CLI mode (for testing)

```bash
# Schedule a build of all services
python -m docker_wts_build --schedule build_all

# Schedule a single service build
python -m docker_wts_build --schedule build --service my-service

# Rebuild a single service (rm + build + up)
python -m docker_wts_build --schedule rebuild --service my-service

# Check all builds
python -m docker_wts_build --check

# Check a specific build
python -m docker_wts_build --check DockerBuild_20260427_195000

# Clean up old builds (default: 30 days)
python -m docker_wts_build --cleanup

# Clean up builds older than 14 days
python -m docker_wts_build --cleanup 14

# Show version
python -m docker_wts_build --version
```

## How it works

1. `schedule_build` creates a `.cmd` wrapper file with environment variables,
   registers it as a Windows Task Scheduler task, and runs it immediately.
2. The task runs `builder.py` outside VS Code, executing `docker compose`
   commands and logging output to files.
3. `check_build` queries Task Scheduler status and reads log files.
4. `cleanup_builds` removes old tasks and log files.

## Requirements

- Windows (uses `schtasks.exe`)
- Docker Desktop
- Python 3.10+
- `mcp` package (installed automatically)

## License

MIT
