import asyncio
import getpass
import json
import logging
import os
import shlex
import shutil
import signal
import subprocess  # nosec
import sys
from pathlib import Path

import structlog
from prompt_toolkit import HTML
from prompt_toolkit.shortcuts import radiolist_dialog
from requests.exceptions import HTTPError, SSLError

from openconnect_saml import config
from openconnect_saml.authenticator import (
    CHROME_MODE,
    HEADLESS_MODE,
    Authenticator,
    AuthResponseError,
)
from openconnect_saml.browser import Terminated
from openconnect_saml.config import (
    BitwardenConfig,
    Credentials,
    KeePassXCConfig,
    OnePasswordConfig,
    PassConfig,
    TwoFAuthConfig,
)
from openconnect_saml.history import ConnectionTracker
from openconnect_saml.profile import get_profiles
from openconnect_saml.totp_providers import (
    BitwardenProvider,
    KeePassXCProvider,
    OnePasswordProvider,
    PassProvider,
    TwoFAuthProvider,
)

logger = structlog.get_logger()


def _read_password(prompt: str) -> str:
    """Prompt for a secret without echo when stdin is a TTY; read a
    plain line from stdin otherwise.

    ``getpass.getpass`` on Windows reads directly from the console
    (``msvcrt.getwch``) and ignores ``sys.stdin``. When the wrapper
    runs as a subprocess with piped stdin (CI, scripts, ``run`` mode)
    that means it blocks forever waiting for console input that will
    never arrive. Detecting a non-TTY stdin here and falling back to
    ``sys.stdin.readline`` keeps the wrapper drivable from a pipe on
    every platform.
    """
    if sys.stdin.isatty():
        return getpass.getpass(prompt=prompt)
    sys.stderr.write(prompt)
    sys.stderr.flush()
    line = sys.stdin.readline()
    if not line:
        return ""
    return line.rstrip("\r\n")


def run(args):
    configure_logger(logging.getLogger(), args.log_level)

    cfg = config.load()

    on_error_cmd = getattr(args, "on_error", "") or ""

    def _bail(rc: int) -> int:
        if on_error_cmd:
            handle_error(on_error_cmd, rc)
        return rc

    try:
        auth_response, selected_profile = asyncio.run(_run(args, cfg))
    except KeyboardInterrupt:
        logger.warning("CTRL-C pressed, exiting")
        return _bail(130)
    except ValueError as e:
        msg, retval = e.args
        logger.error(msg)
        return _bail(retval)
    except Terminated:
        logger.warning("Browser window terminated, exiting")
        return _bail(2)
    except AuthResponseError as exc:
        logger.error(
            f'Required attributes not found in response ("{exc}", '
            "does this endpoint do SSO?), exiting"
        )
        return _bail(3)
    except SSLError as exc:
        # Most users hit this with self-signed corporate gateways. Point
        # them at the wrapper-only flag rather than letting the bare
        # SSLError trail off into "unable to get local issuer certificate".
        logger.error(
            "TLS verification failed against the gateway during the SAML "
            "auth phase. If the gateway uses a self-signed or "
            "internal-CA certificate, retry with `--no-cert-check` "
            "(BEFORE any `--` separator). The cert hash is still pinned "
            "via openconnect's `--servercert` so the bypass only affects "
            "the requests-side SAML handshake.",
            error=str(exc),
        )
        return _bail(4)
    except HTTPError as exc:
        logger.error(f"Request error: {exc}")
        return _bail(4)

    config.save(cfg)

    if args.authenticate:
        logger.warning("Exiting after login, as requested")
        details = {
            "host": selected_profile.vpn_url,
            "cookie": auth_response.session_token,
            "fingerprint": auth_response.server_cert_hash,
        }
        if args.authenticate == "json":
            print(json.dumps(details, indent=4))
        elif args.authenticate == "shell":
            print("\n".join(f"{k.upper()}={shlex.quote(v)}" for k, v in details.items()))
        return 0

    reconnect = getattr(args, "reconnect", False)
    max_retries = getattr(args, "max_retries", None)

    profile_name = getattr(args, "profile_name", None)
    profile = cfg.get_profile(profile_name) if profile_name else None

    # Resolution order for any setting: CLI > per-profile > top-level config.
    notify = getattr(args, "notify", False)
    if not notify and profile is not None and profile.notify is not None:
        notify = profile.notify
    if not notify:
        notify = cfg.notifications

    # Resolve routes: CLI > profile config
    routes = getattr(args, "routes", None) or []
    no_routes = getattr(args, "no_routes", None) or []

    if profile is not None:
        if not routes and profile.routes:
            routes = profile.routes
        if not no_routes and profile.no_routes:
            no_routes = profile.no_routes

    # Kill-switch — resolve CLI > per-profile > top-level config
    ks_cli_enabled = getattr(args, "kill_switch", False)
    ks_cfg = profile.kill_switch if profile and profile.kill_switch else cfg.kill_switch
    ks_persisted = ks_cfg.enabled if ks_cfg else False
    killswitch_enabled = ks_cli_enabled or ks_persisted
    killswitch = None
    if killswitch_enabled:
        killswitch = _setup_killswitch(args, cfg, selected_profile)

    # History tracker
    history_enabled = cfg.connection_history and not getattr(args, "no_history", False)
    tracker = None
    if history_enabled:
        username = args.user or (cfg.credentials.username if cfg.credentials else "")
        tracker = ConnectionTracker(
            server=selected_profile.vpn_url,
            profile=profile_name or "default",
            user=username,
        )

    if reconnect:
        return _run_with_reconnect(
            args,
            cfg,
            auth_response,
            selected_profile,
            max_retries=max_retries,
            notify=notify,
            routes=routes,
            no_routes=no_routes,
            killswitch=killswitch,
            tracker=tracker,
        )

    if notify:
        from openconnect_saml.notify import notify_connected

        notify_connected(selected_profile.vpn_url)

    if tracker:
        tracker.start()

    detach = getattr(args, "detach", False)
    session_username = args.user or (cfg.credentials.username if cfg.credentials else "")
    session_profile_name = profile_name or "default"

    def _record_pid(pid):
        from openconnect_saml.sessions import Session, record

        record(
            Session(
                profile=session_profile_name,
                server=selected_profile.vpn_url,
                user=session_username,
                pid=pid,
                parent_pid=os.getpid(),
            )
        )

    cert = getattr(args, "cert", None)
    cert_key = getattr(args, "cert_key", None)
    if profile is not None:
        cert = cert or profile.cert
        cert_key = cert_key or profile.cert_key

    try:
        rc = run_openconnect(
            auth_response,
            selected_profile,
            args.proxy,
            args.ac_version,
            args.openconnect_args,
            no_sudo=getattr(args, "no_sudo", False),
            csd_wrapper=getattr(args, "csd_wrapper", None),
            on_connect=cfg.on_connect,
            routes=routes,
            no_routes=no_routes,
            useragent=getattr(args, "useragent", None),
            detach=detach,
            on_pid=_record_pid,
            cert=cert,
            cert_key=cert_key,
            wait_seconds=getattr(args, "wait_seconds", 0),
            no_cert_check=getattr(args, "no_cert_check", False),
        )
        return rc
    except KeyboardInterrupt:
        logger.warning("CTRL-C pressed, exiting")
        return 0
    finally:
        if notify:
            from openconnect_saml.notify import notify_disconnected

            notify_disconnected(selected_profile.vpn_url)
        if tracker:
            tracker.stop()
        if not detach:
            # In foreground mode, remove the session record on exit so
            # status / sessions list stay accurate. Detached sessions are
            # cleaned up by `disconnect` or the next `sessions list` (which
            # prunes stale records).
            from openconnect_saml.sessions import remove

            remove(session_profile_name)
        # Only auto-disable kill-switch if it was a CLI-session enablement.
        # If the user persisted it in config, keep it active.
        if killswitch and ks_cli_enabled and not ks_persisted:
            try:
                killswitch.disable()
            except Exception as exc:
                logger.warning("Could not disable kill-switch on exit", error=str(exc))
        handle_disconnect(cfg.on_disconnect)


def _setup_killswitch(args, cfg, selected_profile):
    """Build a KillSwitch instance and enable it. Returns the instance or None."""
    try:
        from openconnect_saml.killswitch import (
            KillSwitch,
            KillSwitchConfig,
            KillSwitchError,
            KillSwitchNotSupported,
        )
    except ImportError as exc:
        logger.error("Cannot import kill-switch module", error=str(exc))
        return None

    dns_servers: list[str] = list(getattr(args, "ks_allow_dns", None) or [])
    if cfg.kill_switch and not dns_servers:
        dns_servers = list(cfg.kill_switch.dns_servers)
    allow_lan = getattr(args, "ks_allow_lan", False) or (
        cfg.kill_switch.allow_lan if cfg.kill_switch else False
    )
    ipv6 = not getattr(args, "ks_no_ipv6", False)
    if cfg.kill_switch:
        ipv6 = ipv6 and cfg.kill_switch.ipv6

    ks_config = KillSwitchConfig(
        server_host=selected_profile.vpn_url,
        server_port=getattr(args, "ks_port", 443) or 443,
        dns_servers=dns_servers,
        allow_lan=allow_lan,
        ipv6=ipv6,
        sudo=getattr(args, "ks_sudo", None),
    )

    try:
        ks = KillSwitch(ks_config)
        ks.enable()
        logger.info("Kill-switch active — traffic locked to VPN")
        return ks
    except KillSwitchNotSupported as exc:
        logger.warning("Kill-switch not supported on this platform", error=str(exc))
        return None
    except KillSwitchError as exc:
        logger.error("Kill-switch setup failed", error=str(exc))
        return None


# Backoff schedule for reconnection (seconds)
RECONNECT_BACKOFF = [30, 60, 120, 300]


def _run_with_reconnect(
    args,
    cfg,
    auth_response,
    selected_profile,
    max_retries=None,
    notify=False,
    routes=None,
    no_routes=None,
    killswitch=None,
    tracker=None,
):
    """Run openconnect with automatic reconnection on failure."""
    import time

    if notify:
        from openconnect_saml.notify import (
            notify_connected,
            notify_disconnected,
            notify_error,
            notify_reconnecting,
        )

        notify_connected(selected_profile.vpn_url)

    if tracker:
        tracker.start()

    attempt = 0
    try:
        while True:
            try:
                rc = run_openconnect(
                    auth_response,
                    selected_profile,
                    args.proxy,
                    args.ac_version,
                    args.openconnect_args,
                    no_sudo=getattr(args, "no_sudo", False),
                    csd_wrapper=getattr(args, "csd_wrapper", None),
                    on_connect=cfg.on_connect,
                    routes=routes,
                    no_routes=no_routes,
                    useragent=getattr(args, "useragent", None),
                )
            except KeyboardInterrupt:
                logger.warning("CTRL-C pressed, stopping reconnect loop")
                if notify:
                    notify_disconnected(selected_profile.vpn_url)
                if tracker:
                    tracker.stop("user interrupted")
                handle_disconnect(cfg.on_disconnect)
                return 0

            if rc == 0:
                if notify:
                    notify_disconnected(selected_profile.vpn_url)
                if tracker:
                    tracker.stop("clean exit")
                handle_disconnect(cfg.on_disconnect)
                return 0

            attempt += 1
            if max_retries is not None and attempt >= max_retries:
                logger.error(
                    "Max reconnection retries reached",
                    attempts=attempt,
                    max_retries=max_retries,
                )
                if notify:
                    notify_error(selected_profile.vpn_url, f"Max retries ({max_retries}) reached")
                if tracker:
                    tracker.error(f"max retries ({max_retries}) reached")
                handle_disconnect(cfg.on_disconnect)
                return rc

            backoff_idx = min(attempt - 1, len(RECONNECT_BACKOFF) - 1)
            delay = RECONNECT_BACKOFF[backoff_idx]
            logger.warning(
                "VPN connection dropped, reconnecting",
                attempt=attempt,
                delay=delay,
                exit_code=rc,
            )

            if notify:
                notify_reconnecting(selected_profile.vpn_url, attempt, delay)
            if tracker:
                tracker.reconnecting(attempt, delay)

            try:
                time.sleep(delay)
            except KeyboardInterrupt:
                logger.warning("CTRL-C pressed during backoff, exiting")
                if tracker:
                    tracker.stop("user interrupted during backoff")
                handle_disconnect(cfg.on_disconnect)
                return 0

            try:
                auth_response, selected_profile = asyncio.run(_run(args, cfg))
            except KeyboardInterrupt:
                logger.warning("CTRL-C pressed during re-authentication, exiting")
                if tracker:
                    tracker.stop("user interrupted during re-auth")
                handle_disconnect(cfg.on_disconnect)
                return 0
            except Exception as exc:
                logger.error("Re-authentication failed", error=str(exc))
                if tracker:
                    tracker.error(f"re-auth failed: {exc}")
                continue
    finally:
        # Only clear transient kill-switch — persistent ones stay.
        if (
            killswitch
            and getattr(args, "kill_switch", False)
            and not (cfg.kill_switch and cfg.kill_switch.enabled)
        ):
            try:
                killswitch.disable()
            except Exception as exc:
                logger.warning("Could not disable kill-switch on exit", error=str(exc))


def configure_logger(logger, level):
    structlog.configure(
        processors=[
            structlog.stdlib.add_log_level,
            structlog.stdlib.add_logger_name,
            structlog.processors.format_exc_info,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
    )

    formatter = structlog.stdlib.ProcessorFormatter(processor=structlog.dev.ConsoleRenderer())

    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(level)


def resolve_totp_source(args, credentials) -> str:
    """Return the effective TOTP source name from CLI flags + saved credentials.

    Precedence: ``--no-totp`` > ``--totp-source`` > saved-credentials default
    > ``"local"``. Pure function — no side effects, no logging.
    """
    if getattr(args, "no_totp", False):
        return "none"
    return getattr(args, "totp_source", None) or (
        credentials.totp_source if credentials else "local"
    )


def configure_totp_provider(args, cfg, credentials) -> None:
    """Wire up the chosen TOTP provider (mutates ``credentials`` and ``cfg``).

    Raises ``ValueError(msg, exit_code)`` if a provider is selected but the
    required configuration (CLI flag or config section) is missing. ``"none"``
    and ``"local"`` are no-ops here; the caller may still prompt for a local
    secret when needed.
    """
    if not credentials:
        return
    source = resolve_totp_source(args, credentials)

    if source == "none":
        credentials.totp_source = "none"
        logger.debug("TOTP prompt disabled (totp_source=none)")
        return

    if source == "bitwarden":
        bw_item_id = getattr(args, "bw_item_id", None)
        if cfg.bitwarden:
            bw_item_id = bw_item_id or cfg.bitwarden.item_id
        if not bw_item_id:
            logger.error(
                "Bitwarden TOTP source requires --bw-item-id (or [bitwarden] config section)"
            )
            raise ValueError("Missing Bitwarden configuration", 22)
        credentials.totp_source = "bitwarden"
        credentials.set_totp_provider(BitwardenProvider(item_id=bw_item_id))
        cfg.bitwarden = BitwardenConfig(item_id=bw_item_id)
        logger.info("Using Bitwarden TOTP provider")
        return

    if source == "1password":
        op_item = getattr(args, "op_item", None)
        op_vault = getattr(args, "op_vault", None)
        op_account = getattr(args, "op_account", None)
        if cfg.onepassword:
            op_item = op_item or cfg.onepassword.item
            op_vault = op_vault or cfg.onepassword.vault or None
            op_account = op_account or cfg.onepassword.account or None
        if not op_item:
            logger.error(
                "1Password TOTP source requires --1password-item (or [1password] config section)"
            )
            raise ValueError("Missing 1Password configuration", 23)
        credentials.totp_source = "1password"
        credentials.set_totp_provider(
            OnePasswordProvider(item=op_item, vault=op_vault, account=op_account)
        )
        cfg.onepassword = OnePasswordConfig(
            item=op_item, vault=op_vault or "", account=op_account or ""
        )
        logger.info("Using 1Password TOTP provider")
        return

    if source == "pass":
        pass_entry = getattr(args, "pass_entry", None)
        if cfg.pass_:
            pass_entry = pass_entry or cfg.pass_.entry
        if not pass_entry:
            logger.error("pass TOTP source requires --pass-entry (or [pass] config section)")
            raise ValueError("Missing pass configuration", 24)
        credentials.totp_source = "pass"
        credentials.set_totp_provider(PassProvider(entry=pass_entry))
        cfg.pass_ = PassConfig(entry=pass_entry)
        logger.info("Using pass TOTP provider")
        return

    if source == "keepassxc":
        kp_db = getattr(args, "keepassxc_db", None)
        kp_entry = getattr(args, "keepassxc_entry", None)
        kp_keyfile = getattr(args, "keepassxc_keyfile", None)
        if cfg.keepassxc:
            kp_db = kp_db or cfg.keepassxc.database
            kp_entry = kp_entry or cfg.keepassxc.entry
            kp_keyfile = kp_keyfile or (cfg.keepassxc.keyfile or None)
        if not kp_db or not kp_entry:
            logger.error(
                "keepassxc TOTP source requires --keepassxc-db AND --keepassxc-entry "
                "(or [keepassxc] config section)"
            )
            raise ValueError("Missing keepassxc configuration", 25)
        credentials.totp_source = "keepassxc"
        credentials.set_totp_provider(
            KeePassXCProvider(database=kp_db, entry=kp_entry, keyfile=kp_keyfile)
        )
        cfg.keepassxc = KeePassXCConfig(database=kp_db, entry=kp_entry, keyfile=kp_keyfile or "")
        logger.info("Using KeePassXC TOTP provider")
        return

    if source == "2fauth":
        twofauth_url = getattr(args, "twofauth_url", None)
        twofauth_token = getattr(args, "twofauth_token", None)
        twofauth_account_id = getattr(args, "twofauth_account_id", None)
        if cfg.twofauth:
            twofauth_url = twofauth_url or cfg.twofauth.url
            twofauth_token = twofauth_token or cfg.twofauth.token
            twofauth_account_id = (
                twofauth_account_id if twofauth_account_id is not None else cfg.twofauth.account_id
            )
        if not all([twofauth_url, twofauth_token, twofauth_account_id]):
            logger.error(
                "2FAuth TOTP source requires --2fauth-url, --2fauth-token, "
                "and --2fauth-account-id (or [2fauth] config section)"
            )
            raise ValueError("Missing 2FAuth configuration", 21)
        credentials.totp_source = "2fauth"
        credentials.set_totp_provider(
            TwoFAuthProvider(
                url=twofauth_url,
                token=twofauth_token,
                account_id=twofauth_account_id,
            )
        )
        cfg.twofauth = TwoFAuthConfig(
            url=twofauth_url, token=twofauth_token, account_id=twofauth_account_id
        )
        logger.info("Using 2FAuth TOTP provider")


async def _run(args, cfg):
    # Handle --reset-credentials
    if getattr(args, "reset_credentials", False):
        if args.user:
            logger.info("Resetting stored credentials", user=args.user)
            cred = Credentials(args.user)
            del cred.password
            del cred.totp
        else:
            logger.error("--reset-credentials requires --user")
        raise ValueError("Credentials reset complete", 0)

    credentials = None
    if cfg.credentials:
        credentials = cfg.credentials
    elif args.user:
        credentials = Credentials(args.user)

    if credentials and not credentials.password:
        credentials.password = _read_password(prompt=f"Password ({args.user}): ")
        cfg.credentials = credentials

    configure_totp_provider(args, cfg, credentials)
    totp_source = resolve_totp_source(args, credentials)

    # Catch-all: if no provider was configured and no TOTP secret is on file,
    # ask for one (unless the user explicitly opted out via "none"). When the
    # user responds with empty input, treat that as opting out so we don't
    # prompt again on every reconnect / next run (#TOTP-loop).
    if (
        credentials
        and totp_source not in ("none", "bitwarden", "1password", "pass", "2fauth")
        and not credentials.totp
    ):
        entered = _read_password(
            prompt=f"TOTP secret (leave blank if not required) ({args.user}): "
        )
        if entered.strip():
            credentials.totp = entered.strip()
        else:
            # Persist the opt-out so subsequent runs / reconnect cycles don't
            # re-ask. Also clear any stale / corrupt secret previously stored
            # in the keyring.
            logger.info(
                "Empty TOTP entered — disabling TOTP prompts for this account "
                "(set --totp-source local manually to re-enable)."
            )
            try:
                del credentials.totp
            except Exception as exc:  # noqa: BLE001
                logger.debug("Could not clear stale TOTP from keyring", error=str(exc))
            credentials.totp_source = "none"
        cfg.credentials = credentials

    if cfg.default_profile and not (args.use_profile_selector or args.server):
        selected_profile = cfg.default_profile
    elif args.use_profile_selector or args.profile_path:
        profiles = get_profiles(Path(args.profile_path))
        if not profiles:
            raise ValueError("No profile found", 17)
        selected_profile = await select_profile(profiles)
        if not selected_profile:
            raise ValueError("No profile selected", 18)
    elif args.server:
        selected_profile = config.HostProfile(args.server, args.usergroup, args.authgroup)
    else:
        raise ValueError("Cannot determine server address. Invalid arguments specified.", 19)

    cfg.default_profile = config.HostProfile(
        selected_profile.address, selected_profile.user_group, selected_profile.name
    )

    # Browser backend: CLI > per-profile > Qt default
    browser_backend = getattr(args, "browser", None)
    profile_for_browser = (
        cfg.get_profile(getattr(args, "profile_name", None))
        if getattr(args, "profile_name", None)
        else None
    )
    if not browser_backend and profile_for_browser and profile_for_browser.browser:
        browser_backend = profile_for_browser.browser
        if browser_backend == "headless":
            args.headless = True

    if browser_backend == "chrome":
        display_mode = CHROME_MODE
    elif getattr(args, "headless", False) or browser_backend == "headless":
        display_mode = HEADLESS_MODE
    else:
        display_mode = config.DisplayMode[args.browser_display_mode.upper()]

    timeout = getattr(args, "timeout", None) or cfg.timeout or 30

    window_size = getattr(args, "window_size", None)
    if window_size:
        try:
            w, h = window_size.split("x")
            cfg.window_width = int(w)
            cfg.window_height = int(h)
        except (ValueError, AttributeError):
            logger.warning("Invalid --window-size format, using defaults", value=window_size)

    ssl_legacy = getattr(args, "ssl_legacy", False)
    no_cert_check = getattr(args, "no_cert_check", False)
    allowed_hosts_raw = getattr(args, "allowed_hosts", None)
    allowed_hosts: list[str] | None = None
    if allowed_hosts_raw:
        allowed_hosts = [h.strip() for h in allowed_hosts_raw.split(",") if h.strip()]

    # Resolve auth_script: CLI > profile > None (use auto-auth).
    #
    # Loud warning when the path comes from a profile rather than the
    # CLI: anyone who can write to ``~/.config/openconnect-saml/config.toml``
    # could otherwise plant an ``auth_script`` pointing at an arbitrary
    # binary that we'd then execute under sudo. The warning gives the
    # operator a chance to notice. CLI-supplied paths skip the warning
    # because they're an explicit one-shot opt-in by the user.
    auth_script = getattr(args, "auth_script", None)
    if auth_script is None and selected_profile is not None:
        # ``selected_profile`` is a ``HostProfile`` (parsed from the
        # AnyConnect XML profile), not a ``ProfileConfig`` — only the
        # latter exposes ``auth_script``. The CLI / setup-wizard ones
        # are ``ProfileConfig``, which is why ``getattr`` is the safe
        # access pattern here.
        auth_script = getattr(selected_profile, "auth_script", None)
        if auth_script:
            logger.warning(
                "Profile-defined auth_script will be executed; if your "
                "profile config is shared / writable by others, this is "
                "a code-execution surface. Pass --auth-script on the "
                "command line to suppress this warning.",
                script=auth_script,
                profile=getattr(args, "profile_name", None),
            )

    auth_response = await authenticate_to(
        selected_profile,
        args.proxy,
        credentials,
        display_mode,
        args.ac_version,
        ssl_legacy=ssl_legacy,
        timeout=timeout,
        window_width=cfg.window_width,
        window_height=cfg.window_height,
        verify_tls=not no_cert_check,
        allowed_hosts=allowed_hosts,
        auth_script=auth_script,
        chrome_channel=getattr(args, "chrome_channel", None),
    )

    if credentials:
        credentials.save()

    # on_connect / on_disconnect: CLI > per-profile > top-level config.
    profile_for_hooks = profile_for_browser
    if args.on_disconnect:
        cfg.on_disconnect = args.on_disconnect
    elif profile_for_hooks and profile_for_hooks.on_disconnect:
        cfg.on_disconnect = profile_for_hooks.on_disconnect

    on_connect = getattr(args, "on_connect", "")
    if on_connect:
        cfg.on_connect = on_connect
    elif profile_for_hooks and profile_for_hooks.on_connect:
        cfg.on_connect = profile_for_hooks.on_connect

    return auth_response, selected_profile


async def select_profile(profile_list):
    selection = await radiolist_dialog(
        title="Select AnyConnect profile",
        text=HTML(
            "The following AnyConnect profiles are detected.\n"
            "The selection will be <b>saved</b> and not asked again unless the "
            "<pre>--profile-selector</pre> command line option is used"
        ),
        values=[(p, p.name) for i, p in enumerate(profile_list)],
    ).run_async()
    if hasattr(signal, "SIGWINCH"):
        asyncio.get_running_loop().remove_signal_handler(signal.SIGWINCH)
    if not selection:
        return selection
    logger.info("Selected profile", profile=selection.name)
    return selection


def authenticate_to(
    host,
    proxy,
    credentials,
    display_mode,
    version,
    ssl_legacy=False,
    timeout=30,
    window_width=800,
    window_height=600,
    verify_tls=True,
    allowed_hosts=None,
    auth_script=None,
    chrome_channel=None,
):
    logger.info("Authenticating to VPN endpoint", name=host.name, address=host.address)
    return Authenticator(
        host,
        proxy,
        credentials,
        version,
        ssl_legacy=ssl_legacy,
        timeout=timeout,
        window_width=window_width,
        window_height=window_height,
        verify_tls=verify_tls,
        allowed_hosts=allowed_hosts,
        auth_script=auth_script,
        chrome_channel=chrome_channel,
    ).authenticate(display_mode)


def _wait_for_tunnel(deadline_seconds: float) -> bool:
    """Block until a ``tun*``/``utun*`` interface appears, or timeout.

    Uses ``ip link show`` (Linux) or ``ifconfig`` (macOS) — best-effort,
    failure is silent. Returns True if a tunnel was observed.
    """
    import time as _time

    end = _time.monotonic() + deadline_seconds
    while _time.monotonic() < end:
        try:
            from openconnect_saml.tui import _get_vpn_interface

            iface = _get_vpn_interface()
            if iface:
                logger.info("Tunnel up", interface=iface)
                return True
        except Exception:  # noqa: BLE001
            pass
        _time.sleep(0.5)
    logger.warning(
        "--wait timeout: tunnel interface didn't appear in time",
        deadline_seconds=deadline_seconds,
    )
    return False


def run_openconnect(
    auth_info,
    host,
    proxy,
    version,
    args,
    no_sudo=False,
    csd_wrapper=None,
    on_connect="",
    routes=None,
    no_routes=None,
    useragent=None,
    detach=False,
    on_pid=None,
    cert=None,
    cert_key=None,
    wait_seconds=0,
    no_cert_check=False,
):
    """Spawn the openconnect process.

    Parameters
    ----------
    detach
        If True, return as soon as openconnect is launched (the process
        keeps running in its own session). Useful with the ``--detach``
        CLI flag and ``openconnect-saml disconnect``.
    on_pid
        Optional callback invoked with the openconnect process PID right
        after spawn (and before any blocking wait). Used to register the
        session in ``sessions.py`` so other commands can find it.
    """
    superuser_cmd = None

    if os.name == "nt":
        import ctypes

        if not ctypes.windll.shell32.IsUserAnAdmin():
            logger.error("OpenConnect must be run as Administrator on Windows, exiting")
            return 20
    elif not no_sudo:
        superuser_cmd = next((prog for prog in ("doas", "sudo") if shutil.which(prog)), None)
        if not superuser_cmd:
            logger.error(
                "Cannot find suitable program to execute as superuser (doas/sudo), exiting"
            )
            return 20

    user_agent = useragent
    if not user_agent:
        user_agent = (
            f"AnyConnect Win {version}" if os.name == "nt" else f"AnyConnect Linux_64 {version}"
        )
    openconnect_args = [
        "openconnect",
        "--useragent",
        user_agent,
        "--version-string",
        version,
        "--cookie-on-stdin",
        "--servercert",
        auth_info.server_cert_hash,
        *args,
        host.vpn_url,
    ]
    if proxy:
        openconnect_args.extend(["--proxy", proxy])
    if csd_wrapper:
        openconnect_args.extend(["--csd-wrapper", csd_wrapper])
    if cert:
        openconnect_args.extend(["--certificate", os.path.expanduser(cert)])
    if cert_key:
        openconnect_args.extend(["--sslkey", os.path.expanduser(cert_key)])
    if no_cert_check:
        # Ask openconnect itself to skip cert validation. Note: --servercert
        # is still pinned via the SAML auth response, which is what we want
        # for self-signed gateways: the hash binds to the actual certificate.
        openconnect_args.extend(["--no-system-trust"])

    if routes:
        for route in routes:
            openconnect_args.extend(["--route", route])
    if no_routes:
        for no_route in no_routes:
            openconnect_args.extend(["--no-route", no_route])

    if os.name == "nt":
        command_line = ["powershell.exe", "-Command", shlex.join(openconnect_args)]
    elif superuser_cmd:
        command_line = [superuser_cmd, *openconnect_args]
    else:
        command_line = openconnect_args

    session_token = auth_info.session_token.encode("utf-8")
    logger.debug("Starting OpenConnect", command_line=command_line)

    if detach:
        # Detach from the controlling terminal so the openconnect process
        # survives when openconnect-saml exits.
        popen_kwargs: dict = {
            "stdin": subprocess.PIPE,
            "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL,
        }
        if os.name != "nt":
            popen_kwargs["start_new_session"] = True
        proc = subprocess.Popen(command_line, **popen_kwargs)  # nosec
        try:
            proc.stdin.write(session_token)
            proc.stdin.close()
        except BrokenPipeError:
            pass
        if on_pid:
            try:
                on_pid(proc.pid)
            except Exception as exc:
                logger.warning("on_pid callback raised", error=str(exc))
        if on_connect:
            handle_connect(on_connect)
        if wait_seconds and wait_seconds > 0:
            _wait_for_tunnel(wait_seconds)
        logger.info("openconnect detached", pid=proc.pid)
        return 0

    if on_connect:
        proc = subprocess.Popen(command_line, stdin=subprocess.PIPE)  # nosec
        proc.stdin.write(session_token)
        proc.stdin.close()
        if on_pid:
            try:
                on_pid(proc.pid)
            except Exception as exc:
                logger.warning("on_pid callback raised", error=str(exc))
        handle_connect(on_connect)
        return proc.wait()

    if on_pid:
        proc = subprocess.Popen(command_line, stdin=subprocess.PIPE)  # nosec
        proc.stdin.write(session_token)
        proc.stdin.close()
        try:
            on_pid(proc.pid)
        except Exception as exc:
            logger.warning("on_pid callback raised", error=str(exc))
        return proc.wait()
    return subprocess.run(command_line, input=session_token).returncode  # nosec


def _validate_hook_command(command):
    """Basic validation for on-connect/on-disconnect hook commands."""
    if not command:
        return True
    suspicious = ["`", "$(", "${", "||", "&&", ";", "\n", "|"]
    for pattern in suspicious:
        if pattern in command:
            logger.warning(
                "Hook command contains suspicious shell metacharacter",
                command=command,
                pattern=pattern,
            )
            return False
    return True


def handle_connect(command):
    if command:
        if not _validate_hook_command(command):
            logger.error(
                "Refusing to run on-connect command with suspicious content",
                command_line=command,
            )
            return 1
        logger.info("Running on-connect command", command_line=command)
        try:
            return subprocess.run(shlex.split(command), timeout=30, shell=False).returncode  # nosec
        except subprocess.TimeoutExpired:
            logger.warning("On-connect command timed out after 30s", command_line=command)
            return 1
        except (FileNotFoundError, OSError) as exc:
            logger.error("On-connect command failed", command_line=command, error=str(exc))
            return 1


def handle_disconnect(command):
    if command:
        if not _validate_hook_command(command):
            logger.error(
                "Refusing to run on-disconnect command with suspicious content",
                command_line=command,
            )
            return 1
        logger.info("Running command on disconnect", command_line=command)
        try:
            return subprocess.run(shlex.split(command), timeout=5, shell=False).returncode  # nosec
        except subprocess.TimeoutExpired:
            logger.warning("On-disconnect command timed out after 5s", command_line=command)
            return 1
        except (FileNotFoundError, OSError) as exc:
            logger.error("On-disconnect command failed", command_line=command, error=str(exc))
            return 1


def handle_error(command, exit_code: int):
    """Run an on-error hook (with $RC set to the exit code) if one is configured."""
    if not command:
        return
    if not _validate_hook_command(command):
        logger.error(
            "Refusing to run on-error command with suspicious content",
            command_line=command,
        )
        return
    env = dict(os.environ)
    env["RC"] = str(exit_code)
    logger.info("Running on-error command", command_line=command, exit_code=exit_code)
    try:
        subprocess.run(  # nosec
            shlex.split(command), timeout=10, shell=False, env=env, check=False
        )
    except subprocess.TimeoutExpired:
        logger.warning("On-error command timed out after 10s", command_line=command)
    except (FileNotFoundError, OSError) as exc:
        logger.error("On-error command failed", command_line=command, error=str(exc))
