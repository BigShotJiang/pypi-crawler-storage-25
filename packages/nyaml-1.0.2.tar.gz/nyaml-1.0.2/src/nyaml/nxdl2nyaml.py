#
# Copyright The NOMAD Authors.
#
# This file is part of NOMAD. See https://nomad-lab.eu for further info.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
This file collects the functions for conversion from nxdl.xml to yaml version.
"""

# pylint: disable=too-many-lines

import os
import re
import textwrap
from pathlib import Path
from typing import Any, TextIO

import lxml.etree as ET

from nyaml.helper import (
    LIMITED_RESERVED_KEYWORDS,
    NXDL_ATTRIBUTES_ATTRIBUTES,
    NXDL_FIELD_ATTRIBUTES,
    NXDL_GROUP_ATTRIBUTES,
    NXDL_LINK_ATTRIBUTES,
    RESERVED_KEYWORDS,
    check_for_proper_nameType,
    clean_empty_lines,
    get_node_parent_info,
    get_yaml_escape_char_dict,
    is_copyright_comment,
    remove_namespace_from_tag,
)

DEPTH_SIZE = 2 * " "
COMMENT_TAG = "!--"
COMMENT_TAG_END = "--"
COMMENT_START = "<!--"
COMMENT_END = "-->"
DEFINITION_CATEGORIES = (r"\category: application", r"\category: base")


def separate_pi_comments(input_file: str | os.PathLike[str]) -> list[str]:
    """Separate PI comments from ProcessesInstruction (PI).

    ProcessesInstruction refers xml element process and version
    Separate the comments that comes immediately after XML process instruction part,
    i.e. copyright comment part.
    """
    comments_list: list[str] = []
    comment: list[str] = []

    with open(input_file, encoding="utf-8") as file:
        lines = file.readlines()
        def_tag = "<definition"
        for line in lines:
            if COMMENT_START in line:
                line = line.replace(COMMENT_START, "")
                if COMMENT_END in line:
                    line = line.replace(COMMENT_END, "")
                    comments_list.append(line)
                else:
                    comment.append(line)
            elif COMMENT_END in line and len(comment) > 0:
                comment.append(line.replace(COMMENT_END, ""))
                comments_list.append("".join(comment))
                comment.clear()
            elif len(comment) > 0:
                comment.append(line)
            elif def_tag in line:
                break
    return comments_list


# Collected: https://dustinoprea.com/2019/01/22/python-parsing-xml-and-retaining-the-comments/
class _CommentedTreeBuilder(ET.TreeBuilder):
    def start(self, tag, attrs):
        super().start(tag=tag, attrs=attrs)

    def Comment(self, text):  # pylint: disable=invalid-name
        """Defining comment builder in TreeBuilder"""
        self.start(COMMENT_TAG, {})
        self.data(text)
        self.end(COMMENT_TAG_END)


def parse(filepath: str | os.PathLike[str]) -> tuple[list[str], ET._ElementTree]:
    """Parse xml function.

    Construct parser function for modified tree builder for including modified TreeBuilder
    and rebuilding XMLParser.
    """
    comments = separate_pi_comments(filepath)
    ctb = _CommentedTreeBuilder()
    xp_parser = ET.XMLParser(target=ctb, encoding="UTF-8")
    root = ET.parse(filepath, xp_parser)
    return comments, root


def handle_mapping_char(
    text: str, depth: int = -1, skip_n_line_on_top: bool = False
) -> str:
    """Check for escape character and replace by alternative character."""

    escape_char = get_yaml_escape_char_dict()
    for esc_key, val in escape_char.items():
        if esc_key in text:
            text = text.replace(esc_key, val)
    if not skip_n_line_on_top:
        if depth > 0:
            text = add_new_line_with_pipe_on_top(text, depth)
        else:
            raise ValueError("Need depth size to co-ordinate text line in yaml file.")
    return text


def add_new_line_with_pipe_on_top(text: str, depth: int) -> str:
    """Design docs block.

    Restructure the text by adding pipe '|' and '\n' char if ':' is found in text.
    """
    char = ":"
    if char in text:
        return "|" + "\n" + depth * DEPTH_SIZE + text
    return text


# pylint: disable=too-many-instance-attributes, too-many-public-methods
class Nxdl2yaml:
    """Parse XML file and print a YML file."""

    def __init__(
        self,
        symbol_list: list[str],
        root_level_definition: list[str],
        root_level_doc: str = "",
        root_level_symbols: str = "",
    ) -> None:
        # updated part of yaml_dict
        self.found_definition: bool = False
        self.root_level_doc: str = root_level_doc
        self.root_level_symbols: str = root_level_symbols
        self.root_level_definition: list[str] = root_level_definition
        self.symbol_list: list[str] = symbol_list
        self.include_comment: bool = True
        self.pi_comments: list[str] | None = None
        # NOTE: Here is how root_level_comments organized for storing comments
        # root_level_comment= {'root_doc': comment,
        #                      'symbols': comment,
        #       The 'symbol_doc_comments' list is for comments from all 'symbol doc'
        #                      'symbol_doc_comments' : [comments]
        #                      'symbol_list': [symbols],
        #       The 'symbol_comments' contains comments for 'symbols doc' and all 'symbol'
        #                      'symbol_comments': [comments]}
        self.root_level_comment: dict[str, Any] = {}

        self.optionality_keys: tuple[str, ...] = (
            "minOccurs",
            "maxOccurs",
            "optional",
            "recommended",
            "required",
        )
        # "Take care of general attributes. Note other choices may be allowed in the future"
        self.choice_allowed_attr: tuple[str, ...] = ()

    def print_yml(
        self,
        input_file: str | os.PathLike[str],
        output_yml: str | os.PathLike[str],
        verbose: bool,
    ) -> None:
        """Parse an XML file provided as input and print a YML file."""
        output_file_path: Path = Path(output_yml)
        if output_file_path.is_file():
            output_file_path.unlink()

        depth: int = 0

        self.pi_comments, root = parse(input_file)
        xml_tree: dict[str, Any] = {"tree": root, "node": root}
        self.xml_parse(os.fspath(output_yml), xml_tree, depth, verbose)

    def handle_symbols(self, depth: int, node: ET._Element) -> None:
        """Handle symbols field and its children symbol"""

        self.root_level_symbols = (
            f"\\{remove_namespace_from_tag(node.tag)}: "
            f"{node.text.strip() if node.text else ''}"
        )
        depth += 1
        last_comment = ""
        symbol_doc_comment_list: list[str] = []
        # Comments that come above symbol tag
        symbol_comment_list: list[str] = []
        for child in list(node):
            tag = remove_namespace_from_tag(child.tag)
            if tag == COMMENT_TAG and self.include_comment:
                last_comment = self.convert_to_yaml_comment(depth, child.text)
            if tag == "doc":
                symbol_comment_list.append(last_comment)
                # The line below is for handling length of 'symbol_comments' and
                # 'symbol_doc_comments'. Otherwise print_root_level_info() gets inconsistency
                # over for the loop while writing comment on file
                symbol_doc_comment_list.append("")
                last_comment = ""
                self.symbol_list.append(
                    self.handle_not_root_level_doc(depth, text=child.text)
                )
            elif tag == "symbol":
                # place holder is symbol name
                symbol_comment_list.append(last_comment)
                last_comment = ""
                if "doc" in child.attrib:
                    self.symbol_list.append(
                        self.handle_not_root_level_doc(
                            depth, tag=child.attrib["name"], text=child.attrib["doc"]
                        )
                    )
                else:
                    for symbol_doc in list(child):
                        tag = remove_namespace_from_tag(symbol_doc.tag)
                        if tag == COMMENT_TAG and self.include_comment:
                            last_comment = self.convert_to_yaml_comment(
                                depth, symbol_doc.text
                            )
                        if tag == "doc":
                            symbol_doc_comment_list.append(last_comment)
                            last_comment = ""
                            self.symbol_list.append(
                                self.handle_not_root_level_doc(
                                    depth,
                                    tag=child.attrib["name"],
                                    text=symbol_doc.text,
                                )
                            )
        self.store_root_level_comments("symbol_doc_comments", symbol_doc_comment_list)
        self.store_root_level_comments("symbol_comments", symbol_comment_list)

    def store_root_level_comments(self, holder: str, comment: str | list[str]) -> None:
        """Store yaml text or section line and the comments intended for that lines or section"""

        self.root_level_comment[holder] = comment

    def handle_definition(self, node: ET._Element) -> None:
        """Handle definition group and its attributes.

        NOTE: Here we try to store the order of the xml element attributes, so that we get
        the same order in nxdl from yaml.
        """
        keyword: str = ""
        # tmp_word for reserving the location
        tmp_word = "#xx#"
        attributes = node.attrib
        # for tracking the order of name and type
        keyword_order: int = -1
        for item in attributes:
            if "name" == item:
                keyword = keyword + attributes[item]
                if keyword_order == -1:
                    self.root_level_definition.append(tmp_word)
                    keyword_order = self.root_level_definition.index(tmp_word)
            elif "extends" == item:
                keyword = f"{keyword}({attributes[item]})"
                if keyword_order == -1:
                    self.root_level_definition.append(tmp_word)
                    keyword_order = self.root_level_definition.index(tmp_word)
            elif "schemaLocation" not in item and "extends" != item:
                prefix = "\\" if item in LIMITED_RESERVED_KEYWORDS["definition"] else ""
                text = f"{prefix}{item}: {attributes[item]}"
                self.root_level_definition.append(text)
        self.root_level_definition[keyword_order] = f"{keyword}:"

    def handle_root_level_doc(self, node: ET._Element) -> None:
        """
        Handle the documentation field found at root level.
        """
        text = self.handle_not_root_level_doc(depth=0, text=node.text)
        self.root_level_doc = text

    def clean_and_organize_text(self, text: str | None, depth: int) -> str:
        """Reconstruct text from doc and comment.

        Cleaning up unintentional and accidental empty lines and spaces.
        """
        # Handling empty doc
        if not text:
            text = ""
        else:
            text = handle_mapping_char(text, -1, True)
        if "\n" in text:
            # To remove '\n' with non-space character as it will be added before text.
            text_lines: list[str] = clean_empty_lines(text.split("\n"))
            text_tmp: list[str] = []
            yaml_indent_n = len((depth + 1) * DEPTH_SIZE)

            # Find indentation in the first line of text having alphabet
            first_line_indent_n = 0
            for line in text_lines:
                # Consider only the lines that has at least one non-space character
                # and skip starting lines of a text block are empty
                if len(line.lstrip()) != 0:
                    first_line_indent_n = len(line) - len(line.lstrip())
                    break
            # Taking care of doc like below:
            # <doc>Text lines
            # text continues</doc>
            # So no indentation at the start of doc. So doc group will come along general
            # alignment
            if first_line_indent_n == 0:
                first_line_indent_n = yaml_indent_n

            # for indent_diff -ve all lines will move left by the same amount
            # for indent_diff +ve all lines will move right by the same amount
            indent_diff = yaml_indent_n - first_line_indent_n
            # Check if first line empty if not keep first line empty

            for line in text_lines:
                line_indent_n = 0
                # count first empty spaces without alphabet
                line_indent_n = len(line) - len(line.lstrip())
                line_indent_n = line_indent_n + indent_diff
                if line_indent_n < yaml_indent_n:
                    # if line still under yaml indentation
                    text_tmp.append(yaml_indent_n * " " + line.strip())
                else:
                    text_tmp.append(line_indent_n * " " + line.strip())

            text = "\n" + "\n".join(text_tmp)

        elif text:
            text = "\n" + (depth + 1) * DEPTH_SIZE + text.strip()

        return text

    def check_and_handle_doc_xref_and_other_doc(
        self, text: str, indent: str
    ) -> tuple[str, bool]:
        """Check for xref doc which comes as a block of text.

        The doc part below is the example how xref comes:
        '''
        This concept is related to term `<term>`_ of the <spec> standard.
        .. _<term>: <url>
        '''
        converter as
        '''
        <indent>  "xref:
        <indent>    xpec: <value>
        <indent>    erm: <value>
        <indent>    url: <value>"
        '''

        Parameters
        ----------
        text: str
            plain text.
        Returns
        -------
        str
            return part of doc as formatted
        """

        xref_key, spec_key, term_key, url_key = (r"\xref", r"\spec", r"\term", r"\url")
        spec, term, url = (None, None, None)
        matches = re.search(
            r"This concept is related to term `([^`:]+)`_ of the"
            r" (.*?) standard\.\s+\.\. _\1: ([^\s]+)",
            text,
        )
        if matches:
            term = matches.group(1)
            spec = matches.group(2)
            url = matches.group(3)
            indent = indent + DEPTH_SIZE  # see example in func doc
            return (
                f"{indent}{xref_key}:\n{indent + DEPTH_SIZE}{spec_key}: {spec}"
                f"\n{indent + DEPTH_SIZE}{term_key}"
                f": {term}\n{indent + DEPTH_SIZE}{url_key}: {url}"
            ), True
        return text, False

    # pylint: disable=too-many-branches, too-many-locals
    def handle_not_root_level_doc(
        self,
        depth: int,
        text: str | None,
        tag: str = "doc",
        file_out: TextIO | None = None,
    ) -> str | None:
        """Handle docs field of group and field but not root.

        Handle docs field along the yaml file. In this function we also tried to keep
        the track of indentation. E.g. the below doc block.
            * Topic name
                Description of topic
        """
        if "}" in tag:
            tag = remove_namespace_from_tag(tag)
        if tag in RESERVED_KEYWORDS:
            tag = f"\\{tag}"
        indent = depth * DEPTH_SIZE
        text = self.clean_and_organize_text(text, depth)  # starts with '\n'
        docs = re.split(r"\n\s*\n", text)
        parts: list[str] = []

        # Add links to previous docstring
        for doc in docs:
            link_match = re.match(r"\s*\.\. _.*", doc)
            if link_match is not None and len(parts) > 0:
                parts[-1] += doc
            else:
                parts.append(doc)

        modified_docs: list[str] = []
        xref_in_doc = False
        for doc_part in parts:
            if not doc_part.isspace():
                mod_doc, xref_present = self.check_and_handle_doc_xref_and_other_doc(
                    doc_part, indent
                )
                xref_in_doc = xref_in_doc or xref_present
                modified_docs.append(mod_doc)

        # Note on doc example:
        # doc:
        #  - |
        #   text
        #  - |
        #   xref:
        #       spec:
        #       term:
        if len(modified_docs) == 1:
            if xref_in_doc:
                doc_str = f"{indent}{tag}: |\n{modified_docs[0]}\n"
            else:
                doc_str = f"{indent}{tag}: |{modified_docs[0]}\n"
        elif len(modified_docs) > 1 and xref_in_doc:
            doc_str = f"{indent}{tag}:\n"
            for mod_doc in modified_docs:
                if not re.match(
                    r"^\s*\n", mod_doc
                ):  # if not starts with 'spaces and/or \n'
                    mod_doc = "\n" + mod_doc
                # doc_str = f"{doc_str}{indent} - |\n{textwrap.indent(mod_doc, indent+'  ')}\n"
                doc_str = f"{doc_str}{indent}- |{textwrap.indent(mod_doc, '')}\n"
        else:
            doc_str = f"{indent}{tag}: |{text}\n"

        if file_out:
            file_out.write(doc_str)
            return None
        return doc_str

    def write_out(self, indent: str, text: str, file_out: TextIO) -> None:
        """
        Write text line in output file.
        """
        line_string = f"{indent}{text.rstrip()}\n"
        file_out.write(line_string)

    def print_root_level_doc(self, file_out: TextIO) -> None:
        """Print at the root level of YML file the general documentation field found in XML file"""
        indent = 0 * DEPTH_SIZE

        text = self.root_level_comment.get("root_doc")
        if text:
            self.write_out(indent, text, file_out)

        text = self.root_level_doc
        self.write_out(indent, text, file_out)
        self.root_level_doc = ""

    def convert_to_yaml_comment(self, depth: int, text: str) -> str:
        """
        Convert into yaml comment by adding an extra '#' char in front of comment lines
        """
        # To store indentation text from comment
        lines = self.clean_and_organize_text(text, depth).split("\n")
        indent = DEPTH_SIZE * depth
        mod_lines: list[str] = []
        for line in lines:
            line = line.strip()
            if line:
                if line[0] != "#":
                    line = "# " + line
                mod_lines.append(line)
        # The starting '\n' to keep multiple comments separate
        return "\n" + "\n".join(map(lambda line: indent + line, mod_lines))

    def print_root_level_info(self, depth: int, file_out: TextIO) -> None:
        """
        Print at the root level of YML file \
        the information stored as definition attributes in the XML file
        """
        if depth < 0:
            raise ValueError("Something wrong with the indentation in root level.")

        has_category = False
        for def_line in self.root_level_definition:
            if def_line in DEFINITION_CATEGORIES:
                self.write_out(indent=0 * DEPTH_SIZE, text=def_line, file_out=file_out)
                has_category = True

        if not has_category:
            raise ValueError(
                "Definition dose not get any category from 'base or application'."
            )
        self.print_root_level_doc(file_out)
        text = self.root_level_comment.get("symbols", "")
        if text:
            indent = depth * DEPTH_SIZE
            self.write_out(indent, text, file_out)
        if self.root_level_symbols:
            self.write_out(
                indent=0 * DEPTH_SIZE, text=self.root_level_symbols, file_out=file_out
            )
            # symbol_list include 'symbols doc', and all 'symbol'
            for ind, symbol in enumerate(self.symbol_list):
                # Taking care of comments that come on top of 'symbols doc' and 'symbol'
                if (
                    "symbol_comments" in self.root_level_comment
                    and self.root_level_comment["symbol_comments"][ind] != ""
                ):
                    indent = depth * DEPTH_SIZE
                    self.write_out(
                        indent,
                        self.root_level_comment["symbol_comments"][ind],
                        file_out,
                    )
                if (
                    "symbol_doc_comments" in self.root_level_comment
                    and self.root_level_comment["symbol_doc_comments"][ind] != ""
                ):
                    indent = depth * DEPTH_SIZE
                    self.write_out(
                        indent,
                        self.root_level_comment["symbol_doc_comments"][ind],
                        file_out,
                    )

                self.write_out(indent=(0 * DEPTH_SIZE), text=symbol, file_out=file_out)
        indent = depth * DEPTH_SIZE
        # Take care copyright doc string
        for comment in self.pi_comments:
            if comment and not is_copyright_comment(comment):
                self.write_out(
                    indent, self.convert_to_yaml_comment(depth, comment), file_out
                )
        if self.root_level_definition:
            # Store NXname for writing at end of definition attributes
            nx_name = ""
            for defs in self.root_level_definition:
                if "NX" in defs and defs[-1] == ":":
                    nx_name = defs
                    continue
                if defs in DEFINITION_CATEGORIES:
                    continue
                self.write_out(indent=0 * DEPTH_SIZE, text=defs, file_out=file_out)
            self.write_out(indent=0 * DEPTH_SIZE, text=nx_name, file_out=file_out)
        self.found_definition = False

    def handle_exists(
        self, exists_dict: dict[str, list[str] | str], key: str, val: Any
    ) -> None:
        """
        Create exist component as follows:

        {'min' : value for min,
         'max' : value for max,
         'optional' : value for optional}

        This is created separately so that the keys stays in order.
        """
        if not val:
            val = ""
        else:
            val = str(val)
        if "minOccurs" == key:
            exists_dict["minOccurs"] = ["min", val]
        elif "maxOccurs" == key:
            exists_dict["maxOccurs"] = ["max", val]
        elif "optional" == key:
            exists_dict["optional"] = ["optional", val]
        elif "recommended" == key:
            exists_dict["recommended"] = ["recommended", val]
        elif "required" == key:
            exists_dict["required"] = ["required", val]

    # pylint: disable=too-many-branches
    def handle_group_or_field(
        self, depth: int, node: ET._Element, file_out: TextIO
    ) -> None:
        """Handle all the possible attributes that come along a field or group"""
        node_attr = node.attrib
        rm_key_list: list[str] = []
        # Order: name and type in form name(type)
        name = node_attr.get("name", "")
        if name:
            rm_key_list.append("name")
        nx_type = node_attr.get("type", "")
        if nx_type:
            rm_key_list.append("type")
            nx_type = f"({nx_type})"

        name_and_type = f"{name}{nx_type}"

        if not name_and_type:
            raise ValueError(
                f"No 'name' or 'type' has been found. But, 'group' or 'field' "
                f"must have at least a name.We have attributes:  {node_attr}"
            )
        indent = depth * DEPTH_SIZE
        file_out.write(f"{indent}{name_and_type}:\n")

        name = node_attr.get("name")
        nameType = node_attr.get("nameType")
        check_for_proper_nameType(name, nameType, name)

        for key in rm_key_list:
            del node_attr[key]

        # tmp_dict intended to preserve order of attributes
        tmp_dict: dict[str, Any] = {}
        exists_dict: dict[str, str | list[str]] = {}
        for key, val in node_attr.items():
            # Check for any unwanted attributes
            self.check_for_unwanted_attributes(node=node)
            # As both 'minOccurs', 'maxOccurs' and optionality move to the 'exists'
            if key in self.optionality_keys:
                if r"\exists" not in tmp_dict:
                    tmp_dict[r"\exists"] = []
                self.handle_exists(exists_dict, key, val)
            elif key == "deprecated":
                tmp_dict[r"\deprecated"] = str(val)
            elif key == "units":
                tmp_dict[r"\unit"] = str(val)
            else:
                # Escape reserved keywords so they are not misinterpreted on round-trip
                escaped_key = f"\\{key}" if key in RESERVED_KEYWORDS else key
                tmp_dict[escaped_key] = str(val)

        if exists_dict:
            for key, exists_val in exists_dict.items():
                if key in ["minOccurs", "maxOccurs"]:
                    tmp_dict[r"\exists"] = (
                        tmp_dict[r"\exists"] + exists_val
                        if isinstance(exists_val, list)
                        else [exists_val]
                    )
                elif key in ["optional", "recommended", "required"]:
                    tmp_dict[r"\exists"] = key

        depth_ = depth + 1
        for key, val_ in tmp_dict.items():
            # Increase depth size inside handle_map...() for writing text with one
            # more indentation.
            file_out.write(
                f"{depth_ * DEPTH_SIZE}{key}: "
                f"{handle_mapping_char(val_, depth_ + 1, False)}\n"
            )

    def check_for_unwanted_attributes(
        self,
        node: ET._Element,
        allowed_attributes_li: tuple[str, ...] | None = None,
        tag: str | None = None,
    ) -> None:
        """Check for any attributes that NeXus does not allow."""
        node_tag: str = remove_namespace_from_tag(node.tag)
        if node_tag == "field":
            for key in node.attrib.keys():
                if key not in NXDL_FIELD_ATTRIBUTES:
                    raise ValueError(
                        f"Field has an unwanted attribute {key}."
                        f"NeXus field allows attributes from {NXDL_FIELD_ATTRIBUTES}"
                    )
        elif node_tag == "group":
            for key in node.attrib.keys():
                if key not in NXDL_GROUP_ATTRIBUTES:
                    raise ValueError(
                        f"Attribute has an unwanted attribute {key}."
                        f"NeXus attribute allows attributes from {NXDL_GROUP_ATTRIBUTES}"
                    )
        elif isinstance(tag, str) and node_tag == tag:
            for key in node.attrib.keys():
                if key not in allowed_attributes_li:
                    raise ValueError(
                        f"{tag.capitalize()} has an unwanted attribute {key}."
                        f"NeXus {tag.capitalize()} allows attributes from {allowed_attributes_li}"
                    )

    # pylint: disable=too-many-branches, too-many-locals, too-many-statements
    def handle_dimensions(
        self, depth: int, node: ET._Element, file_out: TextIO
    ) -> None:
        """
        Handle instances of dimensionsType and its child nodes.

        tests/data/NXdimensionsType.yaml documents the choices
        """
        # analyze first the entire sub-graph behind the dimensionsType element
        yml_dim_dct: dict[str, Any] = {}
        # dimensionsType, rank if present
        for attr, val in node.attrib.items():
            if not isinstance(val, dict):
                if attr in ["rank"]:
                    # indent = (depth + 1) * DEPTH_SIZE
                    yml_dim_dct[r"\rank"] = val
                    break
                # rank is the only allowed attribute of a dimensionsType node
                # see https://manual.nexusformat.org/nxdl_desc.html#dimensionstype
                # for why doc needs to be defined as an XML element instead of an
                # attribute, i.e. using this
                # <dimensions rank="someint" doc="somedocstring"/> is invalid
                # instead, refactor that NeXus class to
                # <dimensions>
                #   <doc>somedocstring</doc>

        # dimensionsType, docstring, if present
        for child in list(node):
            tag = remove_namespace_from_tag(child.tag)
            if tag == "doc":
                yml_dim_dct["doc"] = self.handle_not_root_level_doc(
                    depth + 1, child.text, "doc", None
                )
                break  # dimensionsType can have only one top-level docstring

        # individual dimensionsType dim elements - the individual dimensions - if present
        for child in list(node):
            tag = remove_namespace_from_tag(child.tag)
            child_attrs = child.attrib
            # taking care of index and value attributes
            if tag == "dim":
                # taking care of index and value in format [[index, value]]
                if "index" in child_attrs:
                    idx_val = child_attrs.pop("index", "")
                    if idx_val != "":
                        yml_dim_dct[idx_val] = {}
                        for child_attrs_key, child_attrs_val in child_attrs.items():
                            if child_attrs_key in ["value", "required"]:
                                yml_dim_dct[idx_val][child_attrs_key] = child_attrs_val
                            elif child_attrs_key in ["ref", "incr", "refindex"]:
                                # deprecated !
                                yml_dim_dct[idx_val][child_attrs_key] = child_attrs_val
                            else:
                                raise ValueError(
                                    f"Found incorrect dim child attribute {child_attrs_key}, {child_attrs_val} !"
                                )
                    else:
                        raise ValueError(
                            "Found incorrect dim child that has no index attribute !"
                        )

        dim_count = sum(1 for val in yml_dim_dct.values() if isinstance(val, dict))
        rank_value = yml_dim_dct.get(r"\rank")
        if rank_value is not None and dim_count > 0:
            try:
                rank_as_int = int(rank_value)
            except (TypeError, ValueError):
                rank_as_int = None  # Symbolic rank is allowed and cannot be validated.
            if rank_as_int is not None and rank_as_int != dim_count:
                line_info = (
                    f"Line {node.sourceline}: "
                    if getattr(node, "sourceline", None) is not None
                    else ""
                )
                raise ValueError(
                    f"{line_info}rank '{rank_as_int}' does not match the "
                    f"number of dim entries ({dim_count})."
                )

        # perform I/O based on the cases analyzed
        yml_dim_dct_keys = list(yml_dim_dct)
        indent = depth * DEPTH_SIZE
        if set(yml_dim_dct_keys) in [{r"\rank"}, {r"\doc", r"\rank"}]:
            # rank only notation
            file_out.write(f"{indent}\\dimensions:\n")
            for key, val in yml_dim_dct.items():
                if key == "doc":
                    file_out.write(f"{val}")
                    continue
                file_out.write(f"{indent}{DEPTH_SIZE}{key}: {val}\n")
        else:
            use_shorthand_notation = True  # try to falsify this default assumption
            for key, obj in yml_dim_dct.items():
                if isinstance(obj, dict):  # inside an individual dimension
                    for attr_key, attr_val in obj.items():
                        if attr_key in ["ref", "required", "incr", "refindex"]:
                            use_shorthand_notation = False
                            break
            if use_shorthand_notation:  # shorthand_explicit_rank_new
                file_out.write(f"{indent}\\dimensions:\n")
                dim_index_value: list[str] = []
                for key, obj in yml_dim_dct.items():
                    if key == r"\rank":  # "doc"
                        if isinstance(obj, str):
                            file_out.write(f"{indent}{' ' * 2}{key}: {obj}\n")
                    elif key == "doc":
                        if isinstance(obj, str):
                            file_out.write(f"{obj}")
                    else:
                        if isinstance(obj, dict):  # inside an individual dimension
                            for attr_key, attr_val in obj.items():
                                # will be in order now because numbered indices!
                                if attr_key == "value" and attr_val != "":
                                    dim_index_value.append(attr_val)
                if len(dim_index_value) > 1:
                    file_out.write(
                        f"{indent}{' ' * 2}\\dim: ({', '.join(dim_index_value)})\n"
                    )
                elif len(dim_index_value) == 1:
                    file_out.write(f"{indent}{' ' * 2}\\dim: ({dim_index_value[0]},)\n")
            else:  # full syntax
                file_out.write(f"{indent}\\dimensions:\n")
                for key, obj in yml_dim_dct.items():
                    if key == r"\rank":  # "doc"
                        if isinstance(obj, str):
                            file_out.write(f"{indent}{' ' * 2}{key}: {obj}\n")
                    elif key == "doc":
                        if isinstance(obj, str):
                            file_out.write(f"{obj}")
                # two loops to assure that doc and rank are written before
                # the individual explicit dimension dicts
                for key, obj in sorted(yml_dim_dct.items()):
                    if key not in [r"\rank", r"\doc"] and isinstance(obj, dict):
                        if (
                            sum(
                                1
                                for attr_key, attr_val in obj.items()
                                if attr_val != ""
                            )
                            > 0
                        ):
                            file_out.write(f"{indent}{' ' * 2}{key}:\n")
                            for attr_key, attr_val in obj.items():
                                if attr_val != "":
                                    file_out.write(
                                        f"{indent}{' ' * 4}{attr_key}: {attr_val}\n"
                                    )

    def handle_enumeration(
        self, depth: int, node: ET._Element, file_out: TextIO
    ) -> None:
        r"""
        Handle the enumeration field parsed from the XML file.

        - If enumeration items contain a <doc> field, they will be stored as child fields.
        - If no docs are provided, items will be stored in a list format.
        - If the enumeration is open, an '\open' key will be included.
        """
        indent = depth * DEPTH_SIZE
        tag = remove_namespace_from_tag(node.tag)
        if tag in RESERVED_KEYWORDS:
            tag = f"\\{tag}"
        attributes = node.attrib
        open_enum = attributes.get("open", "false").lower() == "true"
        node_children = list(node)

        check_doc = any(list(child) for child in node_children)

        file_out.write(f"{indent}{tag}:")

        if check_doc:
            file_out.write("\n")
            if open_enum:
                file_out.write(f"{indent + DEPTH_SIZE}\\open: true\n")
            for child in node_children:
                child_tag = remove_namespace_from_tag(child.tag)
                if child_tag == "item":
                    item_indent = indent + DEPTH_SIZE
                    value = child.attrib["value"]
                    if value.startswith("[") and value.endswith("]"):
                        value = f'"{value}"'
                    file_out.write(f"{item_indent}{value}:\n")

                    doc_depth = depth + 2
                    for item_doc in list(child):
                        if remove_namespace_from_tag(item_doc.tag) == "doc":
                            self.handle_not_root_level_doc(
                                doc_depth, item_doc.text, str(item_doc.tag), file_out
                            )
                        if (
                            remove_namespace_from_tag(item_doc.tag) == COMMENT_TAG
                            and self.include_comment
                        ):
                            self.handle_comment(doc_depth, item_doc, file_out)
                elif child_tag == COMMENT_TAG and self.include_comment:
                    self.handle_comment(depth + 1, child, file_out)
        else:
            enum_with_comment = False
            enum_list: list[str] = []
            for child in node_children:
                child_tag = remove_namespace_from_tag(child.tag)
                if child_tag == "item":
                    enum_list.append(child.attrib["value"])
                elif child_tag == COMMENT_TAG and self.include_comment:
                    file_out.write("\n")
                    self.handle_comment(depth + 1, child, file_out)
                    # If there is a comment, we need to use the long notation with "\items:"
                    enum_with_comment = True

            if open_enum:
                if not enum_with_comment:
                    file_out.write(f"\n{indent + DEPTH_SIZE}\\open: true\n")
                else:
                    file_out.write(f"{indent + DEPTH_SIZE}\\open: true\n")

            if open_enum or enum_with_comment:
                file_out.write(
                    f"{indent + DEPTH_SIZE}\\items: [{', '.join(enum_list)}]\n"
                )

            else:
                # Short notation as list if there is no comment or open enum
                file_out.write(f" [{', '.join(enum_list)}]\n")

    def handle_attributes(
        self, depth: int, node: ET._Element, file_out: TextIO
    ) -> None:
        """Handle the attributes parsed from the xml file"""

        name = ""
        nm_attr = "name"
        node_attr = node.attrib

        # Maintain order: name and type in form name(type) or (type)name that come first
        name = node_attr.pop(nm_attr, "")
        if not name:
            raise ValueError("Attribute must have a name key.")

        indent = depth * DEPTH_SIZE
        escape_symbol = r"\@"

        tmp_dict: dict[str, Any] = {}
        exists_dict: dict[str, list[str] | str] = {}

        nameType = node_attr.get("nameType")
        check_for_proper_nameType(name, nameType, name)

        for key, val in node_attr.items():
            if key not in NXDL_ATTRIBUTES_ATTRIBUTES:
                raise ValueError(
                    f"An attribute ({key}) has been found that is not allowed."
                    f"The allowed attr is {NXDL_ATTRIBUTES_ATTRIBUTES}."
                )
            # As both 'minOccurs', 'maxOccurs' and optionality move to the 'exists'
            if key in self.optionality_keys:
                if r"\exists" not in tmp_dict:
                    tmp_dict[r"\exists"] = []
                self.handle_exists(exists_dict, key, val)
            elif key == "units":
                tmp_dict[r"\unit"] = val
            elif key == "deprecated":
                tmp_dict[r"\deprecated"] = str(val)
            else:
                # Escape reserved keywords so they are not misinterpreted on round-trip
                escaped_key = f"\\{key}" if key in RESERVED_KEYWORDS else key
                tmp_dict[escaped_key] = val

        datatype = tmp_dict.get("type")

        if datatype:
            name_txt = f"{indent}{escape_symbol}{name}({datatype}):\n"
            del tmp_dict["type"]
        else:
            name_txt = f"{indent}{escape_symbol}{name}:\n"

        file_out.write(name_txt)

        has_min_max = False
        has_opt_recommended_required = False
        if exists_dict:
            for key, exists_val in exists_dict.items():
                if key in ["minOccurs", "maxOccurs"]:
                    tmp_dict[r"\exists"] = tmp_dict[r"\exists"] + val
                    has_min_max = True
                elif key in ["optional", "recommended", "required"]:
                    tmp_dict[r"\exists"] = key
                    has_opt_recommended_required = True
        if has_min_max and has_opt_recommended_required:
            raise ValueError(
                "Optionality 'exists' can take only either from ['minOccurs',"
                " 'maxOccurs'] or from ['optional', 'recommended', 'required']"
                ". But not from both of the groups together. Please check in"
                " attributes"
            )

        depth_ = depth + 1
        for key, val in tmp_dict.items():
            # Increase depth size inside handle_map...() for writing text with one
            # more indentation.
            file_out.write(
                f"{depth_ * DEPTH_SIZE}{key}: "
                f"{handle_mapping_char(val, depth_ + 1, False)}\n"
            )

    def handle_link(self, depth: int, node: ET._Element, file_out: TextIO) -> None:
        """Handle link elements of nxdl"""

        node_attr = node.attrib
        # Handle special cases
        name = node_attr.pop("name", "")
        if name:
            indent = depth * DEPTH_SIZE
            file_out.write(f"{indent}{name}(link):\n")

        nameType = node_attr.get("nameType")
        check_for_proper_nameType(name, nameType, name)

        depth_ = depth + 1
        # Handle general cases
        for attr_key, val in node_attr.items():
            if attr_key in NXDL_LINK_ATTRIBUTES:
                indent = depth_ * DEPTH_SIZE
                escaped_key = (
                    f"\\{attr_key}"
                    if attr_key in LIMITED_RESERVED_KEYWORDS["link"]
                    else attr_key
                )
                file_out.write(f"{indent}{escaped_key}: {val}\n")
            else:
                raise ValueError(
                    f"An unexpected attribute '{attr_key}' of link has found."
                    f"At this moment the allowed keys are {NXDL_LINK_ATTRIBUTES}"
                )

    def handle_choice(self, depth: int, node: ET._Element, file_out: TextIO) -> None:
        """
        Handle choice element which is a parent node of group.
        """

        node_attr = node.attrib
        name = node_attr.pop("name", "")
        # Handle special cases
        if name:
            indent = depth * DEPTH_SIZE
            file_out.write(f"{indent}{name}(choice): \n")

        depth_ = depth + 1
        # Take care of attributes of choice element, attributes may come in future.
        for attr_key, value in node_attr.items():
            if attr_key in self.choice_allowed_attr:
                indent = depth_ * DEPTH_SIZE
                file_out.write(f"{indent}{attr_key}: {value}\n")
            else:
                raise ValueError(
                    f"An unexpected attribute '{attr_key}' of 'choice' has been found."
                    f"At this moment allowed attributes for choice {self.choice_allowed_attr}"
                )

    def handle_comment(self, depth: int, node: ET._Element, file_out: TextIO) -> None:
        """
        Collect comment element and pass to write_out function
        """
        indent = depth * DEPTH_SIZE
        text = self.convert_to_yaml_comment(depth, node.text)
        self.write_out(indent, text, file_out)

    def recursion_in_xml_tree(
        self, depth: int, xml_tree: dict[str, Any], output_yml: str, verbose: bool
    ) -> None:
        """
            Descend lower level in xml tree. If we are in the symbols branch, the recursive
        behavior is not triggered as we already handled the symbols' children.
        """

        tree = xml_tree["tree"]
        node = xml_tree["node"]
        for child in list(node):
            xml_tree_children = {"tree": tree, "node": child}
            self.xml_parse(output_yml, xml_tree_children, depth, verbose)

    # pylint: disable=too-many-branches, too-many-statements
    def xml_parse(
        self, output_yml: str, xml_tree: dict[str, Any], depth: int, verbose: bool
    ) -> None:
        """
        Main method of the nxdl2yaml converter.
        It parses XML tree, then prints recursively each level of the tree
        """
        tree = xml_tree["tree"]
        node = xml_tree["node"]
        if verbose:
            if callable(node.tag):
                print(f"Node tag: {node.tag}\n")
                print(f"Node text: {node.text}\n")
            else:
                print(f"Node tag: {remove_namespace_from_tag(node.tag)}\n")
                print(f"Attributes: {node.attrib}\n")
        with open(output_yml, "a", encoding="utf-8") as file_out:
            # too much file I/O, this with statement is in the recursion build
            # the entire yaml dictionary nest in main memory and dump thereafter
            tag = remove_namespace_from_tag(node.tag)
            if tag == "definition":
                self.found_definition = True
                self.handle_definition(node)
                # Taking care of root level doc and symbols
                remove_comment_n = None
                last_comment = ""
                for child in node:
                    tag_tmp = remove_namespace_from_tag(child.tag)
                    if tag_tmp == COMMENT_TAG and self.include_comment:
                        last_comment = self.convert_to_yaml_comment(depth, child.text)
                        remove_comment_n = child
                    if tag_tmp == "doc":
                        self.store_root_level_comments("root_doc", last_comment)
                        last_comment = ""
                        self.handle_root_level_doc(child)
                        node.remove(child)
                        if remove_comment_n is not None:
                            node.remove(remove_comment_n)
                            remove_comment_n = None
                    if tag_tmp == "symbols":
                        self.store_root_level_comments("symbols", last_comment)
                        last_comment = ""
                        self.handle_symbols(depth, child)
                        node.remove(child)
                        if remove_comment_n is not None:
                            node.remove(remove_comment_n)
                            remove_comment_n = None

            if tag == "doc" and depth != 1:
                parent = get_node_parent_info(tree, node)[0]
                doc_parent = remove_namespace_from_tag(parent.tag)
                if doc_parent != "item":
                    self.handle_not_root_level_doc(
                        depth, text=node.text, tag=node.tag, file_out=file_out
                    )

            recurse_again = True
            if self.found_definition is True and self.root_level_doc:
                self.print_root_level_info(depth, file_out)
            # End of print root-level definitions in file
            if tag in ("field", "group") and depth != 0:
                self.handle_group_or_field(depth, node, file_out)
            if tag == ("attribute"):
                self.handle_attributes(depth, node, file_out)
            if tag == ("enumeration"):
                self.handle_enumeration(depth, node, file_out)
                recurse_again = False
            if tag == ("dimensions"):
                # self.handle_dimension(depth, node, file_out)
                self.handle_dimensions(depth, node, file_out)
                recurse_again = False
            if tag == ("link"):
                self.handle_link(depth, node, file_out)
            if tag == ("choice"):
                self.handle_choice(depth, node, file_out)
            if tag == COMMENT_TAG and self.include_comment:
                self.handle_comment(depth, node, file_out)

        if recurse_again is True:
            depth += 1
            # Write nested nodes
            self.recursion_in_xml_tree(depth, xml_tree, output_yml, verbose)
