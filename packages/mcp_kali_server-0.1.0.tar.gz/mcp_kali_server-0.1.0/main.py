def main():
    print("Hello from mcp-kali-server!")


if __name__ == "__main__":
    main()
