import inspect
import mimetypes
import os
import traceback

from jinja2 import Environment, FileSystemLoader, select_autoescape
from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

from slush.core.exception import HTTPBaseException
from slush.core.request import Request
from slush.core.response import Response
from slush.core.routing import Router
from slush.exception import ValidationError as SlushValidationError
from slush.openapi import OpenAPIGenerator
from slush.settings import Config


class Slush:
    def __init__(self, config: Config = None):
        self.router = Router()
        self.config = config or Config()
        self.openapi = OpenAPIGenerator(
            title="Slush API", description="Auto-generated API docs"
        )
        self.cors_config = None
        self._register_builtin_docs_routes()
        self.static_mounts = []
        self.cache_backend = None
        self.template_env = None

    def route(self, path, methods=["GET"], middlewares=None):
        """ "Decorator to register a route handler for a specific path and HTTP method(s)."""
        return self.router.route(path, methods, middlewares=middlewares)

    def add_router(self, router: Router, prefix: str = ""):
        """Mount another Router instance under a specific URL prefix."""
        if not isinstance(router, Router):
            raise TypeError("add_router expects a Router instance.")

        prefix = self._normalize_prefix(prefix)

        for route in router.routes:
            full_path = self._join_paths(prefix, route.path)
            self.router.add_route(
                full_path, route.method, route.handler, route.middlewares
            )

    def _normalize_prefix(self, prefix: str) -> str:
        if not prefix:
            return ""

        if not prefix.startswith("/"):
            raise ValueError("Router prefix must start with a '/' character.")

        return prefix.rstrip("/")

    def _join_paths(self, prefix: str, path: str) -> str:
        if not path.startswith("/"):
            raise ValueError("Router path must start with a '/' character.")

        if not prefix:
            return path

        return f"{prefix}{path}"

    def configure_templates(self, directory="./templates"):
        self.template_env = Environment(
            loader=FileSystemLoader(os.path.abspath(directory)),
            autoescape=select_autoescape(["html", "xml"]),
        )

    def render_template(self, template_name, context=None, status=200, headers=None):
        return Response.render_template(
            self.template_env,
            template_name,
            context=context,
            status=status,
            headers=headers,
        )

    def configure_cache(self, backend="memory", url=None):
        if backend == "memory":
            from slush.cache.memory import InMemoryCacheBackend

            self.cache_backend = InMemoryCacheBackend()

        elif backend == "redis":
            from slush.cache.redis_backend import RedisCacheBackend

            if not url:
                raise ValueError("Redis backend requires 'url'")
            self.cache_backend = RedisCacheBackend(url)

        else:
            raise ValueError(f"Unknown cache backend: {backend}")

    def add_cors(
        self,
        allow_origins=None,
        allow_methods=None,
        allow_headers=None,
        allow_credentials=False,
    ):
        self.cors_config = {
            "allow_origins": allow_origins or ["*"],
            "allow_methods": allow_methods
            or ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
            "allow_headers": allow_headers or ["Content-Type", "Authorization"],
            "allow_credentials": allow_credentials,
        }

    def _apply_cors_headers(self, request, response: Response):
        if not self.cors_config:
            return response

        origin = request.headers.get("Origin")
        allow_origins = self.cors_config["allow_origins"]
        allow_methods = self.cors_config["allow_methods"]
        allow_headers = self.cors_config["allow_headers"]
        allow_credentials = self.cors_config["allow_credentials"]

        if "*" in allow_origins:
            response.set_header(
                "Access-Control-Allow-Origin",
                "*" if not allow_credentials else (origin or "*"),
            )
        elif origin in allow_origins:
            response.set_header("Access-Control-Allow-Origin", origin)

        if allow_credentials:
            response.set_header("Access-Control-Allow-Credentials", "true")

        response.set_header("Access-Control-Allow-Methods", ", ".join(allow_methods))
        response.set_header("Access-Control-Allow-Headers", ", ".join(allow_headers))
        response.set_header("Vary", "Origin")

        return response

    def _handle_preflight(self, request):
        if not self.cors_config or request.method != "OPTIONS":
            return None

        response = Response(body="", status=204, content_type="text/plain")
        return self._apply_cors_headers(request, response)

    def mount_static(self, url_prefix="/static", directory="./static"):
        if not url_prefix.startswith("/"):
            raise ValueError("Static URL prefix must start with '/'.")

        self.static_mounts.append(
            {
                "url_prefix": url_prefix.rstrip("/"),
                "directory": os.path.abspath(directory),
            }
        )

    def _is_pydantic_model(self, annotation):
        try:
            return issubclass(annotation, BaseModel)
        except TypeError:
            return False

    def _build_handler_kwargs(self, handler, request, path_params):
        sig = inspect.signature(handler)
        kwargs = {}

        for name, param in sig.parameters.items():
            annotation = param.annotation

            if name == "request":
                kwargs["request"] = request
                continue

            if name in path_params:
                kwargs[name] = path_params[name]
                continue

            if annotation is not inspect.Parameter.empty and self._is_pydantic_model(
                annotation
            ):
                data = request.json

                if data is None:
                    raise SlushValidationError(
                        error="Invalid JSON body",
                        details=[
                            {
                                "loc": ["body"],
                                "msg": "Request body must be valid JSON",
                                "type": "json_invalid",
                            }
                        ],
                    )

                try:
                    kwargs[name] = annotation(**data)
                except PydanticValidationError as e:
                    raise SlushValidationError(
                        error="Validation Error", details=e.errors()
                    )

        return kwargs

    def _execute_handler(self, request, handler, path_params, middlewares=None):
        def call_handler(req):
            kwargs = self._build_handler_kwargs(handler, req, path_params)
            result = handler(**kwargs)

            if isinstance(result, Response):
                return result

            return Response(body=result)

        next_callable = call_handler

        for middleware in reversed(middlewares or []):
            current_next = next_callable

            def make_middleware_call(mw, nxt):
                def wrapped(req):
                    return mw(req, nxt)

                return wrapped

            next_callable = make_middleware_call(middleware, current_next)

        return next_callable(request)

    def _handle_request(self, request):
        route, path_params = self.router.resolve(request.path, request.method)

        return self._execute_handler(
            request=request,
            handler=route.handler,
            path_params=path_params,
            middlewares=route.middlewares,
        )

    def get_openapi_spec(self):
        return self.openapi.generate(self.router.routes)

    def _register_builtin_docs_routes(self):
        @self.route("/openapi.json", methods=["GET"])
        def openapi_json(request):
            return self.get_openapi_spec()

        @self.route("/docs", methods=["GET"])
        def swagger_ui(request):
            html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Slush Docs</title>
        <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist/swagger-ui.css">
    </head>
    <body>
        <div id="swagger-ui"></div>
        <script src="https://unpkg.com/swagger-ui-dist/swagger-ui-bundle.js"></script>
        <script>
            window.onload = function() {
                SwaggerUIBundle({
                    url: '/openapi.json',
                    dom_id: '#swagger-ui'
                });
            };
        </script>
    </body>
    </html>
    """
            return Response.html(html)

    def _match_static_mount(self, path):
        for mount in self.static_mounts:
            prefix = mount["url_prefix"]
            if path == prefix or path.startswith(prefix + "/"):
                return mount
        return None

    def _handle_static_request(self, request):
        mount = self._match_static_mount(request.path)
        if not mount:
            return None

        prefix = mount["url_prefix"]
        directory = mount["directory"]

        rel_path = request.path[len(prefix) :].lstrip("/")
        file_path = os.path.abspath(os.path.join(directory, rel_path))

        if not file_path.startswith(directory):
            return Response({"error": "Forbidden"}, status=403)

        if not os.path.isfile(file_path):
            return Response({"error": "Not Found"}, status=404)

        content_type, _ = mimetypes.guess_type(file_path)
        content_type = content_type or "application/octet-stream"

        with open(file_path, "rb") as f:
            data = f.read()

        return Response(body=data, status=200, content_type=content_type)

    def __call__(self, environ, start_response):
        request = Request(environ)
        request.environ["slush.app"] = self

        try:
            preflight_response = self._handle_preflight(request)
            if preflight_response is not None:
                status, headers, body = preflight_response.finalize()
                start_response(status, headers)
                return body

            response = self._handle_static_request(request)
            if response is None:
                response = self._handle_request(request)

            if not isinstance(response, Response):
                response = Response(body=response)
            response = self._apply_cors_headers(request, response)

            status, headers, body = response.finalize()
            start_response(status, headers)
            return body

        except HTTPBaseException as http_exc:
            response = http_exc.as_response()
            response = self._apply_cors_headers(request, response)
            start_response(response.status, response.headers)
            return [response.body]

        except Exception as e:
            traceback.print_exc()

            if self.config.debug:
                tb_str = traceback.format_exc()
                response = Response({"error": str(e), "trace": tb_str}, status=500)
            else:
                response = Response({"error": "Internal Server Error"}, status=500)

            response = self._apply_cors_headers(request, response)
            status, headers, body = response.finalize()
            start_response(status, headers)
            return body
