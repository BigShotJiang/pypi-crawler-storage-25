import time
from collections import defaultdict, deque

from slush.exception import TooManyRequests

_request_store = defaultdict(deque)


def _get_client_ip(request):
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()

    real_ip = request.headers.get("X-Real-Ip")
    if real_ip:
        return real_ip.strip()

    return request.environ.get("REMOTE_ADDR", "unknown")


def rate_limit(limit: int, per: int, key_func=None):
    if limit <= 0:
        raise ValueError("limit must be greater than 0")
    if per <= 0:
        raise ValueError("per must be greater than 0")

    def middleware(request, call_next):
        key_builder = key_func or _get_client_ip
        client_key = key_builder(request)
        now = time.time()

        store_key = f"{request.method}:{request.path}:{client_key}"
        hits = _request_store[store_key]

        cutoff = now - per
        while hits and hits[0] <= cutoff:
            hits.popleft()

        if len(hits) >= limit:
            retry_after = max(1, int(hits[0] + per - now))
            raise TooManyRequests(
                detail=f"Rate limit exceeded: {limit} requests per {per} seconds",
                retry_after=retry_after,
            )

        hits.append(now)
        response = call_next(request)

        # Optional informational headers
        remaining = max(0, limit - len(hits))
        response.set_header("X-RateLimit-Limit", str(limit))
        response.set_header("X-RateLimit-Remaining", str(remaining))
        response.set_header("X-RateLimit-Reset", str(int(now + per)))

        return response

    return middleware
