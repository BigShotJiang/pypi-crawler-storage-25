import re
from functools import wraps
from typing import Any, Callable, Dict, Tuple

from slush.exception import MethodNotAllowed, NotFound


class Route:
    def __init__(
        self,
        path: str,
        method: str,
        handler: Callable,
        middlewares: list[Callable] = None,
    ):
        """
        Initialize a Route object.
        :param path: The URL path for the route.
        :param method: The HTTP method (GET, POST, etc.) for the route.
        :param handler: The function that handles requests to this route.
        """
        self.path = path
        self.method = method.upper()
        self.handler = handler
        self.middlewares = middlewares or []
        self.path_regex, self.param_names = self._compile_path(path)

    def _compile_path(self, path: str):
        # Convert /user/<int:id>/ to regex pattern
        """
        Compile the path into a regex pattern and extract parameter names.
        :param path: The URL path to compile.
        :return: A tuple containing the compiled regex pattern and a list of parameter names.
        """
        pattern = "^"
        param_names = []

        tokens = path.strip("/").split("/")
        for token in tokens:
            if token.startswith("<") and token.endswith(">"):
                type_and_name = token[1:-1].split(":")
                if len(type_and_name) != 2:
                    raise ValueError("Invalid dynamic path: " + token)
                type_, name = type_and_name
                param_names.append((name, type_))
                if type_ == "int":
                    pattern += r"/(?P<%s>\d+)" % name
                elif type_ == "str":
                    pattern += r"/(?P<%s>[^/]+)" % name
                else:
                    raise ValueError(f"Unsupported path type: {type_}")
            else:
                pattern += f"/{token}"

        pattern += "/?$"
        return re.compile(pattern), param_names

    def match(self, path: str):
        """
        Match the given path against the route's regex pattern.
        :param path: The URL path to match.
        :return: A dictionary of extracted parameters if the path matches, otherwise None.
        """
        match = self.path_regex.match(path)
        if not match:
            return None
        return match.groupdict()

    def openapi_path(self) -> str:
        """
        Convert the route's path to OpenAPI format (e.g., /user/{id}).
        :return: The OpenAPI-formatted path."""
        path = self.path
        path = re.sub(r"<int:(\w+)>", r"{\1}", path)
        path = re.sub(r"<str:(\w+)>", r"{\1}", path)
        return path


class Router:
    """A singleton router that manages routes and resolves them based on the request path and method."""

    def __init__(self):
        self.routes: list[Route] = []

    def add_route(
        self,
        path: str,
        method: str,
        handler: Callable,
        middlewares: list[Callable] = None,
    ):
        """Add a new route to the router."""
        self.routes.append(Route(path, method, handler, middlewares))

    def resolve(self, path: str, method: str) -> Tuple[Route, Dict[str, Any]]:
        method = method.upper()
        allowed_methods = []

        for route in self.routes:
            params = route.match(path)
            if params is not None:
                allowed_methods.append(route.method)
                if route.method == method:
                    return route, params

        if allowed_methods:
            raise MethodNotAllowed(
                detail=f"Allowed methods: {', '.join(allowed_methods)}",
                allowed_methods=allowed_methods,
            )

        raise NotFound()

    def route(self, path, methods=["GET"], middlewares=None):
        if isinstance(methods, str):
            methods = [methods.upper()]

        allowed = ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"]
        if not all(method in allowed for method in methods):
            raise ValueError(
                "Invalid HTTP method specified. Allowed methods are: GET, POST, PUT, DELETE, PATCH, OPTIONS."
            )

        if not path:
            raise ValueError("Path cannot be empty.")

        if not path.startswith("/"):
            raise ValueError("Path must start with a '/' character.")

        def decorator(func):
            @wraps(func)
            def wrapped_func(*args, **kwargs):
                return func(*args, **kwargs)

            for method in methods:
                self.add_route(path, method, wrapped_func, middlewares)

            return wrapped_func

        return decorator
