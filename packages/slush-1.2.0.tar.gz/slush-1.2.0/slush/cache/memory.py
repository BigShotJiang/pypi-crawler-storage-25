import time

from .base import CacheBackend


class InMemoryCacheBackend(CacheBackend):
    def __init__(self):
        self.store = {}

    def get(self, key):
        entry = self.store.get(key)
        if not entry:
            return None

        value, expires_at = entry

        if expires_at and expires_at < time.time():
            del self.store[key]
            return None

        return value

    def set(self, key, value, ttl=None):
        expires_at = time.time() + ttl if ttl else None
        self.store[key] = (value, expires_at)

    def delete(self, key):
        self.store.pop(key, None)

    def clear(self):
        self.store.clear()
