from .base import CacheBackend


class RedisCacheBackend(CacheBackend):
    def __init__(self, url):
        try:
            import redis
        except ImportError:
            raise RuntimeError(
                "Redis backend requires 'redis' package. Install via pip install redis"
            )

        self.client = redis.Redis.from_url(url)

    def get(self, key):
        value = self.client.get(key)
        if value is None:
            return None
        return value

    def set(self, key, value, ttl=None):
        if ttl:
            self.client.setex(key, ttl, value)
        else:
            self.client.set(key, value)

    def delete(self, key):
        self.client.delete(key)

    def clear(self):
        self.client.flushdb()
