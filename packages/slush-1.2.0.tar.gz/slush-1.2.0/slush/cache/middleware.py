import hashlib
import json


def _default_cache_key(request):
    query = request.environ.get("QUERY_STRING", "")
    raw = f"{request.method}:{request.path}?{query}"
    return hashlib.md5(raw.encode()).hexdigest()


def cache_response(ttl=60, key_func=None):
    def middleware(request, call_next):
        app = request.environ.get("slush.app")

        if not app or not app.cache_backend:
            return call_next(request)

        if request.method != "GET":
            return call_next(request)

        key_builder = key_func or _default_cache_key
        cache_key = key_builder(request)

        cached = app.cache_backend.get(cache_key)
        if cached:
            data = json.loads(cached)
            from slush.core.response import Response

            return Response(
                body=data["body"], status=data["status"], headers=data["headers"]
            )

        response = call_next(request)

        # store response
        app.cache_backend.set(
            cache_key,
            json.dumps(
                {
                    "body": response.body.decode("utf-8"),
                    "status": response.status,
                    "headers": response.headers,
                }
            ),
            ttl=ttl,
        )

        return response

    return middleware
