import inspect

from pydantic import BaseModel


class OpenAPIGenerator:
    def __init__(self, title="Slush API", description="API documentation"):
        self.title = title
        self.description = description

    def generate(self, routes):
        spec = {
            "openapi": "3.0.3",
            "info": {
                "title": self.title,
                "description": self.description,
            },
            "paths": {},
            "components": {"schemas": {}},
        }

        for route in routes:
            if route.path in ["/openapi.json", "/docs"]:
                continue
            openapi_path = route.openapi_path()
            method = route.method.lower()

            if openapi_path not in spec["paths"]:
                spec["paths"][openapi_path] = {}

            operation = self._build_operation(route, spec["components"]["schemas"])
            spec["paths"][openapi_path][method] = operation

        return spec

    def _build_operation(self, route, schemas):
        handler = route.handler
        sig = inspect.signature(handler)

        operation = {
            "summary": handler.__name__.replace("_", " ").title(),
            "description": inspect.getdoc(handler) or "",
            "responses": {"200": {"description": "Successful Response"}},
        }

        parameters = self._extract_path_parameters(route)
        if parameters:
            operation["parameters"] = parameters

        request_body = self._extract_request_body(route, sig, schemas)
        if request_body:
            operation["requestBody"] = request_body

        return operation

    def _extract_path_parameters(self, route):
        params = []

        for name, type_ in route.param_names:
            schema_type = "integer" if type_ == "int" else "string"

            params.append(
                {
                    "name": name,
                    "in": "path",
                    "required": True,
                    "schema": {"type": schema_type},
                }
            )

        return params

    def _extract_request_body(self, route, signature, schemas):
        path_param_names = {name for name, _ in route.param_names}

        body_params = []

        for param in signature.parameters.values():
            if param.name == "request":
                continue

            if param.name in path_param_names:
                continue

            annotation = param.annotation
            if annotation is inspect.Parameter.empty:
                continue

            if self._is_pydantic_model(annotation):
                body_params.append(param)

        if not body_params:
            return None

        if len(body_params) > 1:
            # first version: support one model body only
            raise ValueError(
                f"Route '{route.path}' has multiple Pydantic body parameters. "
                "Only one request body model is supported right now."
            )

        model = body_params[0].annotation
        model_name = model.__name__
        schemas[model_name] = model.model_json_schema()

        required = body_params[0].default is inspect.Parameter.empty

        return {
            "required": required,
            "content": {
                "application/json": {
                    "schema": {"$ref": f"#/components/schemas/{model_name}"}
                }
            },
        }

    def _is_pydantic_model(self, annotation):
        try:
            return issubclass(annotation, BaseModel)
        except TypeError:
            return False
