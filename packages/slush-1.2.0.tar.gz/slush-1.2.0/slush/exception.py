from slush.core.exception import HTTPBaseException


class NotFound(HTTPBaseException):
    def __init__(self, detail="Not Found"):
        super().__init__(404, detail)


class MethodNotAllowed(HTTPBaseException):
    def __init__(self, detail="Method Not Allowed", allowed_methods=None):
        headers = [("Content-Type", "application/json")]
        if allowed_methods:
            headers.append(("Allow", ", ".join(allowed_methods)))
        super().__init__(405, detail, headers)


class BadRequest(HTTPBaseException):
    def __init__(self, detail="Bad Request"):
        super().__init__(400, detail)


class InternalServerError(HTTPBaseException):
    def __init__(self, detail="Internal Server Error"):
        super().__init__(500, detail)


class ValidationError(HTTPBaseException):
    def __init__(self, error="Validation Error", details=None):
        super().__init__(422, error)
        self.error = error
        self.details = details or []

    def as_response(self):
        from slush.core.response import Response

        return Response(
            body={"error": self.error, "details": self.details},
            status=422,
            headers=self.headers,
        )


class TooManyRequests(HTTPBaseException):
    def __init__(self, detail="Too Many Requests", retry_after=None):
        headers = [("Content-Type", "application/json")]
        if retry_after is not None:
            headers.append(("Retry-After", str(retry_after)))
        super().__init__(429, detail, headers)
