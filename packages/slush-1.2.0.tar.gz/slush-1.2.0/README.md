<p align="center">
  <img src="https://i.ibb.co/M5Pv76X0/slushlogo.png" alt="Slush Logo" width="480" />
</p>

# Slush

**Slush** is a lightweight Python web framework for building fast, clean, and extensible APIs and backend services.

---

## 🚀 Overview

Slush is designed to give developers full control without unnecessary complexity. It provides a minimal core with powerful built-in features, allowing you to build APIs and web applications quickly while keeping the codebase clean and understandable.

Whether you're prototyping, building microservices, or creating production-ready backends, Slush offers a solid and flexible foundation.

## ✨ Features

- ⚡ Built-in development server with auto-reload
- 🧭 Simple and expressive routing system
- 🔌 Route-level middleware support
- 📥 Request parsing (query params, JSON, form data, files)
- 📤 Flexible response handling (JSON, text, HTML, redirects)
- 📦 Pydantic-based request validation
- 📄 Automatic OpenAPI schema generation
- 📊 Interactive API docs (Swagger UI)
- 🌐 CORS support with preflight handling
- 📁 Static file serving
- 🧩 Jinja2 template rendering
- 🚦 Rate limiting (throttling) middleware
- ⚡ Response caching with optional Redis backend

## 📦 Installation

```bash
$ pip install slush
```


## ⚡ Quick Start

### Create your application

```python
# main.py
from slush.app import Slush

app = Slush()

@app.route("/hello", methods=["GET"])
def hello(request):
    return {"message": "Hello from Slush!"}
```


### Run the server

```bash
$ python run.py
```

### Or use the built-in CLI:
```bash
$ slush runserver main:app
```

### Gunicorn
```bash
$ gunicorn main:app
```


- Minimal core, maximum flexibility
- Explicit behavior over implicit assumptions
- Easy to extend, easy to reason about

## 📄 License

This project is licensed under the **BSD 3-Clause License**.

## 🌐 Links

- 🐙 GitHub: https://github.com/farazkhanfk7/slush
- 📦 PyPI: https://pypi.org/project/slush
- 📘 Documentation: https://slush.gitbook.io/docs
