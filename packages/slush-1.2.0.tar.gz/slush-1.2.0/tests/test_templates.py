from pathlib import Path

from slush.app import Slush


def test_template_rendering(client_factory, tmp_path: Path):
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()

    template_file = templates_dir / "index.html"
    template_file.write_text("<h1>Hello {{ name }}</h1>", encoding="utf-8")

    app = Slush()
    app.configure_templates(str(templates_dir))

    @app.route("/", methods=["GET"])
    def home(request):
        return app.render_template("index.html", {"name": "Faraz"})

    client = client_factory(app)
    response = client.get("/")

    assert response.status_code == 200
    assert "<h1>Hello Faraz</h1>" in response.text


def test_missing_template_returns_error(client_factory, tmp_path: Path):
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()

    app = Slush()
    app.configure_templates(str(templates_dir))

    @app.route("/", methods=["GET"])
    def home(request):
        return app.render_template("missing.html", {"name": "Faraz"})

    client = client_factory(app)
    response = client.get("/")

    assert response.status_code == 500