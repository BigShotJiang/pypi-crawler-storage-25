from pydantic import BaseModel

from slush.app import Slush


class UserCreate(BaseModel):
    name: str
    age: int


def test_valid_pydantic_body(client_factory):
    app = Slush()

    @app.route("/users", methods=["POST"])
    def create_user(request, body: UserCreate):
        return {"name": body.name, "age": body.age}

    client = client_factory(app)
    response = client.post("/users", json={"name": "Faraz", "age": 25})

    assert response.status_code == 200
    assert response.json() == {"name": "Faraz", "age": 25}


def test_invalid_pydantic_body_type(client_factory):
    app = Slush()

    @app.route("/users", methods=["POST"])
    def create_user(request, body: UserCreate):
        return {"name": body.name, "age": body.age}

    client = client_factory(app)
    response = client.post("/users", json={"name": "Faraz", "age": "wrong"})

    assert response.status_code == 422
    data = response.json()
    assert "error" in data
    assert "details" in data


def test_invalid_json_body(client_factory):
    app = Slush()

    @app.route("/users", methods=["POST"])
    def create_user(request, body: UserCreate):
        return {"name": body.name, "age": body.age}

    client = client_factory(app)
    response = client.post(
        "/users",
        data="{bad json",
        headers={"Content-Type": "application/json"},
    )

    assert response.status_code == 422
    data = response.json()
    assert "error" in data
    assert "details" in data