import io
import json
from urllib.parse import urlencode


class TestResponse:
    def __init__(self, status, headers, body):
        self.status = status
        self.headers = dict(headers)
        self.body = body

    @property
    def status_code(self):
        return int(self.status.split()[0])

    @property
    def text(self):
        return self.body.decode("utf-8")

    def json(self):
        if not self.body:
            return None
        return json.loads(self.body.decode("utf-8"))


class TestClient:
    def __init__(self, app):
        self.app = app

    def _build_environ(
        self,
        path="/",
        method="GET",
        query_params=None,
        json_body=None,
        data=None,
        headers=None,
    ):
        query_string = urlencode(query_params or {}, doseq=True)

        if json_body is not None:
            body = json.dumps(json_body).encode("utf-8")
            content_type = "application/json"
        elif data is not None:
            if isinstance(data, str):
                body = data.encode("utf-8")
            else:
                body = data
            content_type = "application/octet-stream"
        else:
            body = b""
            content_type = ""

        environ = {
            "REQUEST_METHOD": method.upper(),
            "PATH_INFO": path,
            "QUERY_STRING": query_string,
            "CONTENT_TYPE": content_type,
            "CONTENT_LENGTH": str(len(body)),
            "wsgi.input": io.BytesIO(body),
            "REMOTE_ADDR": "127.0.0.1",
        }

        for key, value in (headers or {}).items():
            header_name = "HTTP_" + key.upper().replace("-", "_")
            if key.lower() == "content-type":
                environ["CONTENT_TYPE"] = value
            elif key.lower() == "content-length":
                environ["CONTENT_LENGTH"] = value
            else:
                environ[header_name] = value

        return environ

    def request(
        self,
        method,
        path,
        query_params=None,
        json=None,
        data=None,
        headers=None,
    ):
        environ = self._build_environ(
            path=path,
            method=method,
            query_params=query_params,
            json_body=json,
            data=data,
            headers=headers,
        )

        captured = {}

        def start_response(status, response_headers):
            captured["status"] = status
            captured["headers"] = response_headers

        body_iter = self.app(environ, start_response)
        body = b"".join(body_iter)

        return TestResponse(
            status=captured["status"],
            headers=captured["headers"],
            body=body,
        )

    def get(self, path, query_params=None, headers=None):
        return self.request(
            "GET",
            path,
            query_params=query_params,
            headers=headers,
        )

    def post(self, path, json=None, data=None, headers=None):
        return self.request(
            "POST",
            path,
            json=json,
            data=data,
            headers=headers,
        )

    def put(self, path, json=None, data=None, headers=None):
        return self.request(
            "PUT",
            path,
            json=json,
            data=data,
            headers=headers,
        )

    def patch(self, path, json=None, data=None, headers=None):
        return self.request(
            "PATCH",
            path,
            json=json,
            data=data,
            headers=headers,
        )

    def delete(self, path, headers=None):
        return self.request("DELETE", path, headers=headers)

    def options(self, path, headers=None):
        return self.request("OPTIONS", path, headers=headers)