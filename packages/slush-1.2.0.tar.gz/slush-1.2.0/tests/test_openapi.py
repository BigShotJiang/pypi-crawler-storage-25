from pydantic import BaseModel

from slush.app import Slush


class UserCreate(BaseModel):
    name: str
    age: int


def test_openapi_json_available(client_factory):
    app = Slush()

    client = client_factory(app)
    response = client.get("/openapi.json")

    assert response.status_code == 200
    data = response.json()
    assert "openapi" in data
    assert "paths" in data


def test_route_appears_in_openapi(client_factory):
    app = Slush()

    @app.route("/hello", methods=["GET"])
    def hello(request):
        return {"message": "ok"}

    client = client_factory(app)
    response = client.get("/openapi.json")

    data = response.json()
    assert "/hello" in data["paths"]
    assert "get" in data["paths"]["/hello"]


def test_pydantic_body_schema_appears_in_openapi(client_factory):
    app = Slush()

    @app.route("/users", methods=["POST"])
    def create_user(request, body: UserCreate):
        return {"ok": True}

    client = client_factory(app)
    response = client.get("/openapi.json")

    data = response.json()
    assert "/users" in data["paths"]
    assert "post" in data["paths"]["/users"]
    assert "requestBody" in data["paths"]["/users"]["post"]
    assert "UserCreate" in data["components"]["schemas"]