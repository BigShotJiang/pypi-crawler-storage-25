from slush.app import Slush
from slush.cache.middleware import cache_response


def test_cache_response_returns_cached_value(client_factory):
    app = Slush()
    app.configure_cache(backend="memory")

    call_count = {"count": 0}

    @app.route("/hello", methods=["GET"], middlewares=[cache_response(ttl=60)])
    def hello(request):
        call_count["count"] += 1
        return {"count": call_count["count"]}

    client = client_factory(app)

    r1 = client.get("/hello")
    r2 = client.get("/hello")

    assert r1.status_code == 200
    assert r2.status_code == 200
    assert r1.json() == {"count": 1}
    assert r2.json() == {"count": 1}
    assert call_count["count"] == 1