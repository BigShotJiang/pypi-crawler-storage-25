from slush.app import Slush
from slush.core.throttle import rate_limit


def test_rate_limit_blocks_after_threshold(client_factory):
    app = Slush()

    @app.route("/hello", methods=["GET"], middlewares=[rate_limit(2, per=60)])
    def hello(request):
        return {"message": "ok"}

    client = client_factory(app)

    r1 = client.get("/hello")
    r2 = client.get("/hello")
    r3 = client.get("/hello")

    assert r1.status_code == 200
    assert r2.status_code == 200
    assert r3.status_code == 429