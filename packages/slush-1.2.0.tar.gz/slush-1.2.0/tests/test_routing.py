from slush.app import Slush


def test_static_route(client_factory):
    app = Slush()

    @app.route("/hello", methods=["GET"])
    def hello(request):
        return {"message": "ok"}

    client = client_factory(app)
    response = client.get("/hello")

    assert response.status_code == 200
    assert response.json() == {"message": "ok"}


def test_dynamic_int_route(client_factory):
    app = Slush()

    @app.route("/user/<int:id>", methods=["GET"])
    def get_user(id, request):
        return {"id": id}

    client = client_factory(app)
    response = client.get("/user/5")

    assert response.status_code == 200
    assert response.json() == {"id": "5"} or response.json() == {"id": 5}


def test_not_found(client_factory):
    app = Slush()

    client = client_factory(app)
    response = client.get("/missing")

    assert response.status_code == 404
    assert "error" in response.json()


def test_method_not_allowed(client_factory):
    app = Slush()

    @app.route("/hello", methods=["GET"])
    def hello(request):
        return {"message": "ok"}

    client = client_factory(app)
    response = client.post("/hello", json={"x": 1})

    assert response.status_code == 405
    assert "error" in response.json()