from pathlib import Path

from slush.app import Slush


def test_static_file_serving(client_factory, tmp_path: Path):
    static_dir = tmp_path / "static"
    static_dir.mkdir()

    file_path = static_dir / "hello.txt"
    file_path.write_text("hello from static", encoding="utf-8")

    app = Slush()
    app.mount_static("/static", str(static_dir))

    client = client_factory(app)
    response = client.get("/static/hello.txt")

    assert response.status_code == 200
    assert response.text == "hello from static"


def test_static_file_not_found(client_factory, tmp_path: Path):
    static_dir = tmp_path / "static"
    static_dir.mkdir()

    app = Slush()
    app.mount_static("/static", str(static_dir))

    client = client_factory(app)
    response = client.get("/static/missing.txt")

    assert response.status_code == 404


def test_static_path_traversal_blocked(client_factory, tmp_path: Path):
    static_dir = tmp_path / "static"
    static_dir.mkdir()

    outside = tmp_path / "outside.txt"
    outside.write_text("should not be visible", encoding="utf-8")

    app = Slush()
    app.mount_static("/static", str(static_dir))

    client = client_factory(app)
    response = client.get("/static/../outside.txt")

    assert response.status_code == 403