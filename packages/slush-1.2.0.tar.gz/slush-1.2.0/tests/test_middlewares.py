from slush.app import Slush
from slush.core.response import Response


def test_route_middleware_blocks_request(client_factory):
    app = Slush()

    def block_middleware(request, call_next):
        return Response({"error": "blocked"}, status=403)

    @app.route("/secret", methods=["GET"], middlewares=[block_middleware])
    def secret(request):
        return {"message": "should not run"}

    client = client_factory(app)
    response = client.get("/secret")

    assert response.status_code == 403
    assert response.json() == {"error": "blocked"}


def test_route_middleware_allows_request(client_factory):
    app = Slush()

    def pass_middleware(request, call_next):
        return call_next(request)

    @app.route("/hello", methods=["GET"], middlewares=[pass_middleware])
    def hello(request):
        return {"message": "ok"}

    client = client_factory(app)
    response = client.get("/hello")

    assert response.status_code == 200
    assert response.json() == {"message": "ok"}


def test_middleware_order(client_factory):
    app = Slush()
    events = []

    def mw1(request, call_next):
        events.append("mw1-before")
        response = call_next(request)
        events.append("mw1-after")
        return response

    def mw2(request, call_next):
        events.append("mw2-before")
        response = call_next(request)
        events.append("mw2-after")
        return response

    @app.route("/hello", methods=["GET"], middlewares=[mw1, mw2])
    def hello(request):
        events.append("handler")
        return {"message": "ok"}

    client = client_factory(app)
    response = client.get("/hello")

    assert response.status_code == 200
    assert events == [
        "mw1-before",
        "mw2-before",
        "handler",
        "mw2-after",
        "mw1-after",
    ]