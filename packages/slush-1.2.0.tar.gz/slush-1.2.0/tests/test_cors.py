from slush.app import Slush


def test_cors_headers_added_to_normal_response(client_factory):
    app = Slush()
    app.add_cors(
        allow_origins=["http://localhost:3000"],
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization"],
    )

    @app.route("/hello", methods=["GET"])
    def hello(request):
        return {"message": "ok"}

    client = client_factory(app)
    response = client.get(
        "/hello",
        headers={"Origin": "http://localhost:3000"},
    )

    assert response.status_code == 200
    assert response.headers["Access-Control-Allow-Origin"] == "http://localhost:3000"
    assert "GET" in response.headers["Access-Control-Allow-Methods"]


def test_cors_preflight_request(client_factory):
    app = Slush()
    app.add_cors(
        allow_origins=["http://localhost:3000"],
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization"],
    )

    client = client_factory(app)
    response = client.options(
        "/hello",
        headers={
            "Origin": "http://localhost:3000",
            "Access-Control-Request-Method": "GET",
            "Access-Control-Request-Headers": "Content-Type",
        },
    )

    assert response.status_code == 204
    assert response.headers["Access-Control-Allow-Origin"] == "http://localhost:3000"
    assert "OPTIONS" in response.headers["Access-Control-Allow-Methods"]