import logging
import math

import numpy as np
from typing import List, Iterator, Union, Optional

from acmenra_cv.YOLOUtils.point import Point


logger = logging.getLogger(__name__)


class Obb:
    """
    Represents an Oriented Bounding Box (OBB) — a rotated rectangle defined by 4 corner points.

    This class is designed to work with YOLO OBB detection models (YOLOv8/v11 OBB).
    It combines features from both Box (geometric properties) and Polygon (point iteration).

    Key differences from Polygon:
    - Exactly 4 points (enforced)
    - Points must be in clockwise order: [top-left, top-right, bottom-right, bottom-left]
    - Provides Box-like properties: center, width, height, angle, area
    - Provides Box-like boundaries: left, right, top, bottom (axis-aligned bounding box)

    Key differences from Box:
    - Supports rotation (angle)
    - Defined by 4 corner points, not 6 planes
    - 2D only (no Z-axis)

    Designed for seamless integration with downstream processing pipelines such as:
    - ADAS zone analysis and collision detection
    - Visualization and rendering utilities
    - Geometric transformations (scale, translate)
    - Business logic for event detection

    All coordinates are maintained in normalized space (0.0-1.0) relative to the
    original image dimensions, making instances resolution-independent.

    Attributes:
        _points (List[Point]): Internal storage of exactly 4 corner points (copy).
        _angle (Optional[float]): Cached rotation angle in degrees (computed on demand).

    Note:
        - All coordinates use normalized space (0.0-1.0)
        - Points are stored as a copy to prevent external modifications
        - Z coordinate is supported but typically 0.0 for 2D images
        - Points should be in clockwise order for correct angle calculation
    """

    def __init__(self, points: List[Point]):
        """
        Initializes an Obb with exactly 4 corner points.

        A copy of the input list is stored to prevent external modifications.
        Points should be in clockwise order: [top-left, top-right, bottom-right, bottom-left]

        Args:
            points (List[Point]): List of exactly 4 Point objects representing corners.

        Raises:
            TypeError: If any element in points is not an instance of Point.
            ValueError: If points does not contain exactly 4 points.

        Note:
            - For best results, points should form a valid rectangle (parallel opposite sides)
            - However, this is not enforced — any 4-point quadrilateral is accepted
            - Points are stored as a shallow copy
        """
        if not isinstance(points, list) or len(points) != 4:
            raise ValueError(
                f"'points' must be a list of exactly 4 Points, got {len(points) if isinstance(points, list) else type(points).__name__}")

        for i, point in enumerate(points):
            if not isinstance(point, Point):
                raise TypeError(f"'points[{i}]' must be '<Point>', but got {type(point).__name__}")

        self._points = points[:]  # копия
        self._angle: Optional[float] = None

    def __len__(self) -> int:
        """
        Returns the number of vertices in the OBB (always 4).

        Returns:
            int: Always returns 4.

        Note:
            OBB always has exactly 4 corner points by definition.
        """
        return 4

    def __iter__(self) -> Iterator[Point]:
        """
        Returns an iterator over the OBB's points in clockwise order.

        Allows the OBB to be used in loops and comprehensions.

        Returns:
            Iterator[Point]: Iterator yielding each Point in order.
        """
        return iter(self._points)

    def __getitem__(self, index: int) -> Point:
        """
        Gets a point by index.

        Args:
            index (int): Index (0-3). Negative indices supported (-1 = last point).

        Returns:
            Point: A single point.

        Raises:
            IndexError: If index is out of range (0-3).

        Note:
            Slicing not supported (always 4 points).
        """
        return self._points[index]

    def __eq__(self, other: object) -> bool:
        """
        Checks if two OBBs are equal.

        Two OBBs are considered equal if they have the same 4 points
        and all corresponding points have equal coordinates.

        Args:
            other (object): Other object to compare.

        Returns:
            bool: True if OBBs have same points in same order.

        Note:
            This does NOT account for:
            - Different starting points (rotated vertex order)
            - Reverse order (clockwise vs counter-clockwise)
            - Floating point precision issues

            For geometric equality, use custom comparison logic.
        """
        if not isinstance(other, Obb):
            return False
        return all(p1.X == p2.X and p1.Y == p2.Y and p1.Z == p2.Z for p1, p2 in zip(self._points, other._points))

    def __repr__(self) -> str:
        """
        Returns a detailed string representation suitable for debugging.

        Returns:
            str: Exact representation with center and angle.
        """
        return f"Obb(points=4, center=({self.center.X:.3f}, {self.center.Y:.3f}), angle={self.angle:.1f}°)"

    def __str__(self) -> str:
        """
        Returns a human-readable string representation of the OBB.

        Returns:
            str: Formatted string with center, dimensions, and angle.
        """
        return f"Obb(center=({self.center.X:.3f}, {self.center.Y:.3f}), width={self.width:.3f}, height={self.height:.3f}, angle={self.angle:.1f}°)"

    @property
    def points(self) -> List[Point]:
        """
        Returns a shallow copy of the internal list of points.

        This prevents external code from modifying the internal state directly.

        Returns:
            List[Point]: A copy of the list of 4 points.

        Note:
            - Modifying the returned list does not affect the OBB
            - For direct access, use iteration or __getitem__
        """
        return self._points[:]

    @property
    def left(self) -> float:
        """
        Gets the left boundary (X min) of the axis-aligned bounding box.

        Returns:
            float: Minimum X coordinate among all 4 points.

        Note:
            Useful for bounding box calculations and collision detection.
        """
        return min(p.X for p in self._points)

    @property
    def right(self) -> float:
        """
        Gets the right boundary (X max) of the axis-aligned bounding box.

        Returns:
            float: Maximum X coordinate among all 4 points.

        Note:
            Useful for bounding box calculations and collision detection.
        """
        return max(p.X for p in self._points)

    @property
    def top(self) -> float:
        """
        Gets the top boundary (Y max) of the axis-aligned bounding box.

        Returns:
            float: Maximum Y coordinate among all 4 points.

        Note:
            In image coordinates, Y increases downward (0=top, 1=bottom).
        """
        return max(p.Y for p in self._points)

    @property
    def bottom(self) -> float:
        """
        Gets the bottom boundary (Y min) of the axis-aligned bounding box.

        Returns:
            float: Minimum Y coordinate among all 4 points.

        Note:
            In image coordinates, Y increases downward (0=top, 1=bottom).
        """
        return min(p.Y for p in self._points)

    @property
    def width(self) -> float:
        """
        Gets the width of the OBB (longer side).

        Calculated as the average of the two horizontal sides.

        Returns:
            float: Width in normalized coordinates (0.0-1.0).

        Note:
            Consistent with Box.width and Polygon.width for unified interface.
        """
        side1 = math.sqrt((self._points[1].X - self._points[0].X) ** 2 +  (self._points[1].Y - self._points[0].Y) ** 2)
        side2 = math.sqrt((self._points[2].X - self._points[3].X) ** 2 + (self._points[2].Y - self._points[3].Y) ** 2)
        return (side1 + side2) / 2.0

    @property
    def height(self) -> float:
        """
        Gets the height of the OBB (shorter side).

        Calculated as the average of the two vertical sides.

        Returns:
            float: Height in normalized coordinates (0.0-1.0).

        Note:
            Consistent with Box.height and Polygon.height for unified interface.
        """
        side1 = math.sqrt((self._points[3].X - self._points[0].X) ** 2 + (self._points[3].Y - self._points[0].Y) ** 2)
        side2 = math.sqrt((self._points[2].X - self._points[1].X) ** 2 +  (self._points[2].Y - self._points[1].Y) ** 2)
        return (side1 + side2) / 2.0

    @property
    def center(self) -> Point:
        """
        Gets the geometric center (centroid) of the OBB.

        Calculated as the average of all 4 corner points.

        Returns:
            Point: Center point with coordinates (avg_x, avg_y, avg_z).

        Note:
            - Consistent with Box.center and Polygon.center for unified interface
            - For trajectory tracking, use bottom_center instead
            - Z coordinate is typically 0.0 for 2D images
        """
        return Point.safe(x=sum(p.X for p in self._points) / 4.0,
                          y=sum(p.Y for p in self._points) / 4.0,
                          z=sum(p.Z for p in self._points) / 4.0)

    @property
    def bottom_center(self) -> Point:
        """
        Gets the bottom center point of the OBB.

        Calculated as (center.X, bottom, 0.0).

        Returns:
            Point: Bottom center point for trajectory tracking.

        Note:
            - Consistent with Box.bottom_center and Polygon.bottom_center
            - Used for trajectory tracking in systems
            - Represents the point closest to the bottom of the image
        """
        return Point.safe(x=self.center.X, y=self.bottom, z=0.0)

    @property
    def angle(self) -> float:
        """
        Gets the rotation angle of the OBB in degrees.

        The angle is calculated from the top edge (top-left to top-right).
        Range: -90° to +90° (0° = horizontal, +90° = vertical clockwise)

        Returns:
            float: Rotation angle in degrees.

        Note:
            - Angle is cached after first calculation for performance
            - For axis-aligned boxes, angle will be close to 0°
            - Positive angle = clockwise rotation
        """
        if self._angle is not None:
            return self._angle

        angle_rad = math.atan2(self._points[1].Y - self._points[0].Y,
                               self._points[1].X - self._points[0].X)
        angle_deg = math.degrees(angle_rad)

        if angle_deg > 90:
            angle_deg -= 180
        elif angle_deg < -90:
            angle_deg += 180

        self._angle = angle_deg
        return self._angle

    @property
    def area(self) -> float:
        """
        Gets the area of the OBB.

        Calculated as width × height.

        Returns:
            float: Area in normalized square units (0.0-1.0).

        Note:
            - Consistent with Polygon.get_area() for unified interface
            - For OBB, this is more accurate than shoelace formula
        """
        return self.width * self.height

    def get_area(self) -> float:
        """
        Calculates the area of the OBB.

        Alias for area property (for consistency with Polygon).

        Returns:
            float: Area in normalized square units (0.0-1.0).
        """
        return self.area

    def scale(self, sx: float, sy: float, sz: float = 1.0) -> 'Obb':
        """
        Returns a new Obb scaled by the given factors in X, Y, and Z directions.

        Each point in the OBB is transformed as:
            new_x = x * sx
            new_y = y * sy
            new_z = z * sz

        This is useful for converting normalized coordinates (0..1) to absolute pixel
        coordinates by scaling with image width and height.

        Args:
            sx (float): Scale factor along the X axis. Must be a positive number.
            sy (float): Scale factor along the Y axis. Must be a positive number.
            sz (float): Scale factor along the Z axis. Defaults to 1.0.

        Returns:
            Obb: A new Obb with all points scaled.
                The original OBB is not modified.

        Raises:
            TypeError: If sx, sy, or sz is not a numeric type or is a boolean.
            ValueError: If sx, sy, or sz is negative or zero.

        Note:
            - For pixel conversion, use sx=image_width, sy=image_height
            - Original OBB remains unchanged (immutable operation)
            - Z scaling typically not needed for 2D images
        """
        if not isinstance(sx, (int, float)) or isinstance(sx, bool):
            raise TypeError(f"'sx' must be '<float>', but got {type(sx).__name__}")
        if sx <= 0:
            raise ValueError(f"'sx' must be > 0, got {sx}")
        if not isinstance(sy, (int, float)) or isinstance(sy, bool):
            raise TypeError(f"'sy' must be '<float>', but got {type(sy).__name__}")
        if sy <= 0:
            raise ValueError(f"'sy' must be > 0, got {sy}")
        if not isinstance(sz, (int, float)) or isinstance(sz, bool):
            raise TypeError(f"'sz' must be '<float>', but got {type(sz).__name__}")
        if sz <= 0:
            raise ValueError(f"'sz' must be > 0, got {sz}")

        return Obb([point.scale(float(sx), float(sy), float(sz)) for point in self])

    def translate(self, dx: float, dy: float, dz: float = 0.0) -> 'Obb':
        """
        Returns a new Obb translated by the given offsets in X, Y, and Z directions.

        Each point in the OBB is shifted as:
            new_x = x + dx
            new_y = y + dy
            new_z = z + dz

        This operation is useful for converting local coordinates (e.g., inside an ROI)
        to global image coordinates, or for geometric transformations.

        Args:
            dx (float): Offset along the X axis.
                Can be positive (right) or negative (left).
                Must be in range [-1.0, 1.0] for normalized coordinates.
            dy (float): Offset along the Y axis.
                Can be positive (down) or negative (up).
                Must be in range [-1.0, 1.0] for normalized coordinates.
            dz (float): Offset along the Z axis. Defaults to 0.0.
                Can be positive (front) or negative (back).

        Returns:
            Obb: A new Obb with all points shifted.
                The original OBB is not modified.

        Raises:
            TypeError: If dx, dy, or dz is not of type float.
            ValueError: If dx, dy, or dz is outside range [-1.0, 1.0].

        Note:
            - For normalized coordinates (0.0-1.0), offsets are typically small values
            - Use scale() for multiplicative transformations
            - Original OBB remains unchanged (immutable operation)
        """
        if not isinstance(dx, float):
            raise TypeError(f"'dx' must be '<float>', but got {type(dx).__name__}")
        if not -1.0 <= dx <= 1.0:
            raise ValueError(f"'dx' must be in range [-1.0, 1.0], got {dx}")
        if not isinstance(dy, float):
            raise TypeError(f"'dy' must be '<float>', but got {type(dy).__name__}")
        if not -1.0 <= dy <= 1.0:
            raise ValueError(f"'dy' must be in range [-1.0, 1.0], got {dy}")
        if not isinstance(dz, float):
            raise TypeError(f"'dz' must be '<float>', but got {type(dz).__name__}")
        if not -1.0 <= dz <= 1.0:
            raise ValueError(f"'dz' must be in range [-1.0, 1.0], got {dz}")

        return Obb([point.translate(dx=dx, dy=dy, dz=dz) for point in self])

    def to_array(self) -> np.ndarray:
        """
        Converts the OBB to a NumPy array of shape (4, 2).

        Coordinates are in the same space as the original points (usually normalized).
        Points are in clockwise order: [top-left, top-right, bottom-right, bottom-left]

        Returns:
            np.ndarray: Array of shape (4, 2), where each row is [x, y].

        Note:
            - Z coordinates are not included (2D output)
            - Useful for OpenCV operations
        """
        return np.array([[point.X, point.Y] for point in self._points])

    def to_absolute_array(self, width: float, height: float) -> np.ndarray:
        """
        Converts normalized coordinates (0..1) to absolute pixel coordinates.

        Useful for extracting ROIs or drawing on original images.

        Args:
            width (float): Width of the target image in pixels.
            height (float): Height of the target image in pixels.

        Returns:
            np.ndarray: Array of absolute coordinates, shape (4, 2).
                Values are in pixel coordinates (0 to width/height).

        Note:
            - Z coordinates are not included (2D output)
            - Values are not rounded (keep as float for sub-pixel accuracy)
        """
        return np.array([[point.X * width, point.Y * height] for point in self._points])

    @staticmethod
    def from_yolo_obb(xyxyxyxyn: Union[list, tuple, np.ndarray]) -> 'Obb':
        """
        Creates a Polygon from YOLO's masks.xyn output.

        YOLO returns normalized polygon coordinates as a list/array of shape (N, 2).
        This method converts each [x, y] into a Point and builds a Polygon.

        Args:
            xyn (Union[list, tuple, np.ndarray]): Normalized polygon points from YOLO,
                shape (N, 2), where each point is [x, y] in range [0, 1].

        Returns:
            Polygon: A new Polygon instance with normalized Point objects.

        Raises:
            TypeError: If input is not list, tuple, or np.ndarray.
            ValueError: If input shape is not (N, 2).

        Note:
            - Coordinates are expected to be normalized (0.0-1.0)
            - Polygon closure is not enforced (YOLO provides closed polygons)
            - For segmentation masks, use result.masks.xyn
        """
        if isinstance(xyxyxyxyn, (list, tuple)):
            xyn = np.array(xyxyxyxyn)
        elif isinstance(xyxyxyxyn, np.ndarray):
            pass
        else:
            raise TypeError(f"Expected list, tuple, or np.ndarray, got {type(xyxyxyxyn).__name__}")

        if xyxyxyxyn.ndim != 2 or xyxyxyxyn.shape[1] != 2:
            raise ValueError(f"Expected array of shape (N, 2), got {xyxyxyxyn.shape}")

        return Obb([Point.safe(x=float(xi), y=float(yi)) for xi, yi in xyxyxyxyn])

