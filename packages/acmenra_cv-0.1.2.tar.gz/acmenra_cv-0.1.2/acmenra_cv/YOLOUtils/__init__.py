"""
YOLOUtils: Type-safe spatial primitives for YOLO detection pipelines.

Provides validated geometric containers (Point, Box, Polygon, Obb, YOLOInstance)
with normalized coordinate support and immutable transformations.
"""

from acmenra_cv.YOLOUtils.point import Point
from acmenra_cv.YOLOUtils.box import Box
from acmenra_cv.YOLOUtils.polygon import Polygon
from acmenra_cv.YOLOUtils.obb import Obb
from acmenra_cv.YOLOUtils.instance import YOLOInstance

__all__ = [
    'Point',
    'Box',
    'Polygon',
    'Obb',
    'YOLOInstance',
]

__version__ = "0.1.1"