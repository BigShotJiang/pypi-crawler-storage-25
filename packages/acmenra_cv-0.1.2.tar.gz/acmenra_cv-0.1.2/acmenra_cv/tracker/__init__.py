"""
Tracker: Multi-object tracking system for YOLO detection models.

Provides persistent object IDs, trajectory management, and integration
with ADAS pipelines and real-time monitoring systems.
"""

from acmenra_cv.tracker.tracked_object import TrackedObject
from acmenra_cv.tracker.timed_point import TimedPoint
from acmenra_cv.tracker.timed_point_queue import TimedPointQueue
from acmenra_cv.tracker.tracker import Tracker

__all__ = [
    'TrackedObject',
    'TimedPoint',
    'TimedPointQueue',
    'Tracker',
]

__version__ = "0.1.1"