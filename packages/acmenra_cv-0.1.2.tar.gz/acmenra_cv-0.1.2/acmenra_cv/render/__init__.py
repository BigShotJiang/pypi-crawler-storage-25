"""
Render: Visualization layer for computer vision pipelines.

Provides type-safe, style-driven drawing operations optimized for
embedded systems and real-time ADAS monitoring.
"""

from acmenra_cv.render.font import Font
from acmenra_cv.render.style import Style
from acmenra_cv.render.draw import Drawer

__all__ = [
    'Font',
    'Style',
    'Drawer',
]

__version__ = "0.1.1"