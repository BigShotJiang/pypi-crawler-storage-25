"""
evaluate_queue_doctor.py — LearnLens evaluation of Queue Doctor.

Demonstrates MCPAdapter — the generic adapter for any MCP-based OpenEnv
environment — running against a real multi-step clinical RL environment.

Usage:
    python evaluate_queue_doctor.py
    python evaluate_queue_doctor.py --episodes 3
    python evaluate_queue_doctor.py --task task_3_hard
"""

from __future__ import annotations

import argparse
import json
import sys
import time

from learnlens import LensWrapper, LensConfig
from learnlens.adapters.mcp import MCPAdapter, QueueDoctorMCPAdapter, extract_json_from_obs


# ── Config ─────────────────────────────────────────────────────────────────

DEFAULT_URL = "https://ajaybandiwaddar01-queue-doctor.hf.space"

TASKS = {
    "task_1_easy":   "Basic Triage        (6 patients,  1 doctor,  10 steps)",
    "task_2_medium": "Dynamic Queue       (29 patients, 2 doctors, 20 steps)",
    "task_3_hard":   "Mass Casualty       (21 patients, 3 doctors, 1 ICU, 30 steps)",
}


# ── Greedy triage agent ────────────────────────────────────────────────────

def queue_doctor_greedy_agent(obs_str: str) -> str:
    """
    Greedy triage agent for Queue Doctor.

    Strategy: serve highest-priority SERVABLE patient at each step.
    Priority: lowest severity first, then longest wait, then deterioration urgency.
    Robust JSON parsing handles all 5 ConsistencyProbe paraphrase templates.
    """
    obs = extract_json_from_obs(obs_str)

    if not obs or obs.get("done", False):
        return json.dumps({"action": "wait", "reasoning": "episode done or no obs"})

    queue = obs.get("queue", [])
    if not queue:
        return json.dumps({"action": "wait", "reasoning": "queue empty"})

    servable = [p for p in queue if p.get("can_serve_now", True)]
    if not servable:
        return json.dumps({"action": "wait", "reasoning": "all patients resource-blocked"})

    def priority_key(p: dict) -> tuple:
        countdown = p.get("deterioration_countdown", 999)
        urgency   = countdown if countdown and countdown > 0 else 999
        return (p.get("severity", 5), urgency, -p.get("wait_time", 0))

    best = sorted(servable, key=priority_key)[0]
    return json.dumps({
        "action":     "serve_patient",
        "patient_id": best["patient_id"],
        "reasoning":  (
            f"Serving {best['patient_id']} — "
            f"severity={best.get('severity')}, "
            f"waited={best.get('wait_time')} steps"
        ),
    })


# ── Per-task evaluation ────────────────────────────────────────────────────

def run_task_eval(url: str, task_id: str, label: str, n_episodes: int) -> dict | None:
    print(f"\n{'─' * 60}")
    print(f"  Task: {label}")
    print(f"{'─' * 60}")

    adapter = QueueDoctorMCPAdapter(env_url=url, task_id=task_id)
    config  = LensConfig(
        run_reasoning=False,
        max_steps_per_episode=35,
        step_timeout_s=45,
        hack_threshold=0.3,
    )
    env = LensWrapper(adapter=adapter, config=config)

    try:
        report = env.evaluate(
            agent_fn=queue_doctor_greedy_agent,
            n_episodes=n_episodes,
        )
        report.print_report()
        adapter.close()
        time.sleep(2)

        return {
            "task_id": task_id,
            "label":   label,
            "lqs":     report.lqs,
            "reward":  report.mean_reward,
            "G":       report.generalization_score,
            "C":       report.consistency_score,
            "H":       report.hack_index,
            "flagged": report.hack_flagged,
        }

    except Exception as exc:
        print(f"\n  ERROR on {task_id}: {exc}")
        print(
            "  If CAPACITY_REACHED: wait 30s and retry.\n"
            "  Run: python evaluate_queue_doctor.py --episodes 2"
        )
        adapter.close()
        return None


# ── Main ───────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="LearnLens x Queue Doctor — MCPAdapter evaluation"
    )
    parser.add_argument("--url",      default=DEFAULT_URL)
    parser.add_argument("--episodes", "-e", type=int, default=3)
    parser.add_argument("--task",     default=None, choices=list(TASKS.keys()))
    args = parser.parse_args()

    url = args.url.rstrip("/")

    print()
    print("=" * 60)
    print("  LearnLens x Queue Doctor Evaluation")
    print("=" * 60)
    print(f"  URL      : {url}")
    print(f"  Episodes : {args.episodes} per task")
    print()

    # Health check
    print("  Checking environment health...")
    try:
        import httpx
        resp = httpx.get(f"{url}/health", timeout=15)
        if resp.status_code != 200:
            print(f"  ERROR: /health returned {resp.status_code}")
            sys.exit(1)
        print(f"  Environment live: {resp.text}\n")
    except Exception as exc:
        print(f"  ERROR: Cannot reach {url}: {exc}")
        sys.exit(1)

    # Run evaluations
    tasks_to_run = {args.task: TASKS[args.task]} if args.task else TASKS
    results = []

    for task_id, label in tasks_to_run.items():
        result = run_task_eval(url, task_id, label, args.episodes)
        if result:
            results.append(result)

    if not results:
        print("\n  No results collected.")
        sys.exit(1)

    # Summary table
    print()
    print("=" * 70)
    print("  LearnLens x Queue Doctor — Summary")
    print("=" * 70)
    print(f"  {'Task':<30}  {'Reward':>6}  {'LQS':>6}  {'G':>5}  {'C':>5}  {'H':>5}")
    print(f"  {'─'*30}  {'──────':>6}  {'──────':>6}  {'─────':>5}  {'─────':>5}  {'─────':>5}")
    for r in results:
        flag = " ⚠" if r["flagged"] else "  "
        print(
            f"  {r['label']:<30}  "
            f"{r['reward']:>6.3f}  "
            f"{r['lqs']:>6.3f}{flag}  "
            f"{r['G']:>5.2f}  "
            f"{r['C']:>5.2f}  "
            f"{r['H']:>5.2f}"
        )

    if len(results) > 1:
        avg_lqs    = sum(r["lqs"]    for r in results) / len(results)
        avg_reward = sum(r["reward"] for r in results) / len(results)
        print(f"\n  {'Average':<30}  {avg_reward:>6.3f}  {avg_lqs:>6.3f}")

    print()
    print("  Queue Doctor is a genuine multi-step MDP.")
    print("  HackDetectionProbe has full trajectory signal across 10/20/30 steps.")
    print("  LQS measures HOW the agent behaves — not just HOW MUCH reward it scored.")
    print()

if __name__ == "__main__":
    main()