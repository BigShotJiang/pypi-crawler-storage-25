"""
Tests for WCAG Checker.
"""

import pytest
from wcag_checker import (
    WCAGChecker, ConformanceLevel, IssueLevel, Report, ReportFormat
)


class TestImageAlt:
    """Tests for 1.1.1 Non-text Content."""
    
    def test_missing_alt(self):
        """Images without alt should be flagged."""
        html = '<html><body><img src="test.jpg"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("1.1.1")
        assert len(errors) > 0
        assert any("alt" in e.message.lower() for e in errors)
    
    def test_empty_alt_ok(self):
        """Empty alt (decorative) should not error."""
        html = '<html><body><img src="decorative.jpg" alt=""></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("1.1.1") 
                  if e.level == IssueLevel.ERROR]
        assert len(errors) == 0
    
    def test_valid_alt_ok(self):
        """Images with valid alt should pass."""
        html = '<html><body><img src="cat.jpg" alt="A fluffy orange cat"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("1.1.1") 
                  if e.level == IssueLevel.ERROR]
        assert len(errors) == 0
    
    def test_filename_as_alt(self):
        """Alt text that looks like filename should be flagged."""
        html = '<html><body><img src="test.jpg" alt="IMG_1234.jpg"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("1.1.1")
        assert any("filename" in e.message.lower() for e in errors)


class TestHeadings:
    """Tests for 1.3.1 Info and Relationships - Headings."""
    
    def test_missing_h1(self):
        """Pages without h1 should be flagged."""
        html = '<html><body><h2>Subtitle</h2></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        issues = result.filter_by_criterion("1.3.1")
        assert any("h1" in e.message.lower() for e in issues)
    
    def test_skipped_heading_level(self):
        """Skipped heading levels should be flagged."""
        html = '<html><body><h1>Title</h1><h3>Subtitle</h3></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        issues = result.filter_by_criterion("1.3.1")
        assert any("skipped" in e.message.lower() for e in issues)
    
    def test_proper_heading_structure(self):
        """Proper heading structure should pass."""
        html = '''
        <html><body>
            <h1>Main Title</h1>
            <h2>Section</h2>
            <h3>Subsection</h3>
        </body></html>
        '''
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("1.3.1") 
                  if "heading" in e.message.lower() and e.level == IssueLevel.ERROR]
        assert len(errors) == 0


class TestLanguage:
    """Tests for 3.1.1 Language of Page."""
    
    def test_missing_lang(self):
        """Missing lang attribute should be flagged."""
        html = '<html><body>Content</body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("3.1.1")
        assert len(errors) > 0
        assert any("lang" in e.message.lower() for e in errors)
    
    def test_valid_lang(self):
        """Valid lang attribute should pass."""
        html = '<html lang="en"><body>Content</body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("3.1.1") 
                  if e.level == IssueLevel.ERROR]
        assert len(errors) == 0
    
    def test_invalid_lang(self):
        """Invalid lang code should be flagged."""
        html = '<html lang="invalid-code"><body>Content</body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("3.1.1")
        assert any("invalid" in e.message.lower() for e in errors)


class TestFormLabels:
    """Tests for 3.3.2 Labels or Instructions."""
    
    def test_input_without_label(self):
        """Inputs without labels should be flagged."""
        html = '<html lang="en"><body><input type="text"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("3.3.2")
        assert len(errors) > 0
    
    def test_input_with_label(self):
        """Inputs with proper labels should pass."""
        html = '''
        <html lang="en"><body>
            <label for="name">Name:</label>
            <input type="text" id="name">
        </body></html>
        '''
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("3.3.2") 
                  if e.level == IssueLevel.ERROR]
        assert len(errors) == 0
    
    def test_input_with_aria_label(self):
        """Inputs with aria-label should pass."""
        html = '''
        <html lang="en"><body>
            <input type="text" aria-label="Search">
        </body></html>
        '''
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("3.3.2") 
                  if e.level == IssueLevel.ERROR]
        assert len(errors) == 0


class TestLinks:
    """Tests for 2.4.4 Link Purpose."""
    
    def test_empty_link(self):
        """Links without text should be flagged."""
        html = '<html lang="en"><body><a href="page.html"></a></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("2.4.4")
        assert any("no accessible text" in e.message.lower() for e in errors)
    
    def test_ambiguous_link(self):
        """Ambiguous link text should be flagged."""
        html = '<html lang="en"><body><a href="page.html">Click here</a></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        issues = result.filter_by_criterion("2.4.4")
        assert any("ambiguous" in e.message.lower() for e in issues)
    
    def test_descriptive_link(self):
        """Descriptive links should pass."""
        html = '<html lang="en"><body><a href="products.html">View our products</a></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("2.4.4") 
                  if e.level == IssueLevel.ERROR]
        assert len(errors) == 0


class TestPageTitle:
    """Tests for 2.4.2 Page Titled."""
    
    def test_missing_title(self):
        """Pages without title should be flagged."""
        html = '<html lang="en"><head></head><body>Content</body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("2.4.2")
        assert len(errors) > 0
    
    def test_empty_title(self):
        """Empty title should be flagged."""
        html = '<html lang="en"><head><title></title></head><body>Content</body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("2.4.2")
        assert any("empty" in e.message.lower() for e in errors)
    
    def test_valid_title(self):
        """Pages with valid title should pass."""
        html = '<html lang="en"><head><title>My Page - Company</title></head><body>Content</body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("2.4.2") 
                  if e.level == IssueLevel.ERROR]
        assert len(errors) == 0


class TestButtons:
    """Tests for 4.1.2 Name, Role, Value - Buttons."""
    
    def test_button_without_text(self):
        """Buttons without accessible name should be flagged."""
        html = '<html lang="en"><body><button></button></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("4.1.2")
        assert any("button" in e.message.lower() and "name" in e.message.lower() 
                   for e in errors)
    
    def test_button_with_text(self):
        """Buttons with text should pass."""
        html = '<html lang="en"><body><button>Submit</button></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = [e for e in result.filter_by_criterion("4.1.2") 
                  if "button" in e.message.lower() and e.level == IssueLevel.ERROR]
        assert len(errors) == 0


class TestDuplicateIds:
    """Tests for 4.1.1 Parsing - Duplicate IDs."""
    
    def test_duplicate_ids(self):
        """Duplicate IDs should be flagged."""
        html = '''
        <html lang="en"><body>
            <div id="test">First</div>
            <div id="test">Second</div>
        </body></html>
        '''
        checker = WCAGChecker()
        result = checker.check(html)
        
        errors = result.filter_by_criterion("4.1.1")
        assert any("duplicate" in e.message.lower() for e in errors)


class TestConformanceLevels:
    """Tests for conformance level filtering."""
    
    def test_level_a_only(self):
        """Level A should only run A checks."""
        html = '<html><body><img src="test.jpg"></body></html>'
        checker = WCAGChecker(level=ConformanceLevel.A)
        result = checker.check(html)
        
        # 1.1.1 is Level A, should have issues
        assert len(result.filter_by_criterion("1.1.1")) > 0
    
    def test_level_aa(self):
        """Level AA should run A and AA checks."""
        checker = WCAGChecker(level=ConformanceLevel.AA)
        # This is testing that checker doesn't crash with different levels
        result = checker.check('<html lang="en"><body>Test</body></html>')
        assert result.level == ConformanceLevel.AA


class TestReportGeneration:
    """Tests for report generation."""
    
    def test_text_report(self):
        """Text report should generate."""
        html = '<html><body><img src="test.jpg"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        report = Report(result)
        
        text = report.to_text()
        assert "WCAG 2.2" in text
        assert "ERROR" in text or "WARNING" in text or "NOTICE" in text
    
    def test_json_report(self):
        """JSON report should be valid JSON."""
        import json
        
        html = '<html lang="en"><body><img src="test.jpg"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        report = Report(result)
        
        json_str = report.to_json()
        data = json.loads(json_str)
        
        assert "summary" in data
        assert "issues" in data
    
    def test_html_report(self):
        """HTML report should be valid HTML."""
        html = '<html lang="en"><body><img src="test.jpg"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        report = Report(result)
        
        html_report = report.to_html()
        assert "<!DOCTYPE html>" in html_report
        assert "<title>" in html_report
    
    def test_markdown_report(self):
        """Markdown report should generate."""
        html = '<html lang="en"><body><img src="test.jpg"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        report = Report(result)
        
        md = report.to_markdown()
        assert "# WCAG 2.2" in md


class TestCheckResult:
    """Tests for CheckResult methods."""
    
    def test_is_compliant(self):
        """is_compliant should reflect error status."""
        # With errors
        html = '<html><body><img src="test.jpg"></body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        assert result.is_compliant is False
        
        # Without errors (minimal valid page)
        html = '''
        <!DOCTYPE html>
        <html lang="en">
        <head><title>Test Page</title></head>
        <body><main><h1>Test</h1><p>Content</p></main></body>
        </html>
        '''
        result = checker.check(html)
        # May still have warnings/notices, but check error count
        errors = result.filter_by_level(IssueLevel.ERROR)
        if not errors:
            assert result.is_compliant is True
    
    def test_summary(self):
        """summary() should return string."""
        html = '<html lang="en"><body>Test</body></html>'
        checker = WCAGChecker()
        result = checker.check(html)
        
        summary = result.summary()
        assert isinstance(summary, str)
        assert "issue" in summary.lower() or "error" in summary.lower() or "check" in summary.lower()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
