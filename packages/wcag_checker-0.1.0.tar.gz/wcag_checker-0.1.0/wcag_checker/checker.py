"""
Main WCAG Checker API.

This module provides the primary interface for checking HTML content
against WCAG 2.2 guidelines.
"""

from typing import List, Optional, Set, Union
from bs4 import BeautifulSoup
import re

from wcag_checker.models import (
    Issue, IssueLevel, ConformanceLevel, CheckResult, WCAGCriterion
)
from wcag_checker.checks.base import CheckRegistry, BaseCheck
from wcag_checker.criteria import (
    ALL_CRITERIA, LEVEL_A_CRITERIA, LEVEL_AA_CRITERIA, LEVEL_AAA_CRITERIA,
    get_criteria_for_level, get_criterion
)

# Import checks to register them
from wcag_checker.checks import perceivable
from wcag_checker.checks import operable
from wcag_checker.checks import understandable
from wcag_checker.checks import robust


class WCAGChecker:
    """
    WCAG 2.2 accessibility checker.
    
    Analyzes HTML content for accessibility issues based on
    Web Content Accessibility Guidelines (WCAG) 2.2.
    
    Example:
        >>> checker = WCAGChecker()
        >>> result = checker.check('<html><body><img src="test.jpg"></body></html>')
        >>> print(result.summary())
        >>> for issue in result.issues:
        ...     print(f"{issue.level.value}: {issue.message}")
    """
    
    def __init__(
        self,
        level: ConformanceLevel = ConformanceLevel.AA,
        include_notices: bool = True,
        enabled_criteria: Optional[Set[str]] = None,
        disabled_criteria: Optional[Set[str]] = None,
    ):
        """
        Initialize the WCAG checker.
        
        Args:
            level: Target conformance level (A, AA, or AAA). Checks for
                   this level and all lower levels will be run.
            include_notices: Whether to include NOTICE-level issues.
            enabled_criteria: If provided, only run checks for these criteria IDs.
            disabled_criteria: Criteria IDs to skip.
        """
        self.level = level
        self.include_notices = include_notices
        self.enabled_criteria = enabled_criteria
        self.disabled_criteria = disabled_criteria or set()
    
    def check(self, html: str) -> CheckResult:
        """
        Check HTML content for WCAG issues.
        
        Args:
            html: HTML string to check.
            
        Returns:
            CheckResult containing all found issues.
        """
        # Parse HTML
        soup = BeautifulSoup(html, 'lxml')
        
        # Get applicable criteria
        criteria = self._get_applicable_criteria()
        
        # Run all registered checks
        all_issues: List[Issue] = []
        checks_run = 0
        
        for check_class in CheckRegistry.get_checks():
            # Check if this check's criterion is applicable
            if check_class.criterion not in criteria:
                continue
            
            # Check if criterion is disabled
            if check_class.criterion.id in self.disabled_criteria:
                continue
            
            # Check if specific criteria are enabled
            if self.enabled_criteria and check_class.criterion.id not in self.enabled_criteria:
                continue
            
            # Run the check
            try:
                check_instance = check_class(soup, html)
                issues = check_instance.check()
                
                # Filter notices if needed
                if not self.include_notices:
                    issues = [i for i in issues if i.level != IssueLevel.NOTICE]
                
                all_issues.extend(issues)
                checks_run += 1
            except Exception as e:
                # Log error but continue with other checks
                all_issues.append(Issue(
                    criterion=check_class.criterion,
                    level=IssueLevel.ERROR,
                    message=f"Check failed with error: {str(e)}",
                    recommendation="This may indicate a bug in the checker"
                ))
        
        return CheckResult(
            issues=all_issues,
            html_length=len(html),
            checks_run=checks_run,
            level=self.level
        )
    
    def check_file(self, filepath: str, encoding: str = 'utf-8') -> CheckResult:
        """
        Check an HTML file for WCAG issues.
        
        Args:
            filepath: Path to HTML file.
            encoding: File encoding (default: utf-8).
            
        Returns:
            CheckResult containing all found issues.
        """
        with open(filepath, 'r', encoding=encoding) as f:
            html = f.read()
        
        result = self.check(html)
        result.source_file = filepath
        return result
    
    def _get_applicable_criteria(self) -> List[WCAGCriterion]:
        """Get criteria applicable for the target conformance level."""
        return get_criteria_for_level(self.level)


def check_html(
    html: str,
    level: ConformanceLevel = ConformanceLevel.AA,
    include_notices: bool = True,
) -> CheckResult:
    """
    Quick function to check HTML for WCAG issues.
    
    Args:
        html: HTML string to check.
        level: Target conformance level.
        include_notices: Whether to include NOTICE-level issues.
        
    Returns:
        CheckResult containing all found issues.
        
    Example:
        >>> result = check_html('<img src="test.jpg">')
        >>> print(f"Found {len(result.issues)} issues")
    """
    checker = WCAGChecker(level=level, include_notices=include_notices)
    return checker.check(html)


def check_file(
    filepath: str,
    level: ConformanceLevel = ConformanceLevel.AA,
    include_notices: bool = True,
    encoding: str = 'utf-8',
) -> CheckResult:
    """
    Quick function to check an HTML file for WCAG issues.
    
    Args:
        filepath: Path to HTML file.
        level: Target conformance level.
        include_notices: Whether to include NOTICE-level issues.
        encoding: File encoding.
        
    Returns:
        CheckResult containing all found issues.
    """
    checker = WCAGChecker(level=level, include_notices=include_notices)
    return checker.check_file(filepath, encoding=encoding)


def get_available_criteria() -> List[WCAGCriterion]:
    """Get list of all WCAG 2.2 criteria."""
    return ALL_CRITERIA.copy()


def get_available_checks() -> List[type]:
    """Get list of all registered check classes."""
    return CheckRegistry.get_checks()
