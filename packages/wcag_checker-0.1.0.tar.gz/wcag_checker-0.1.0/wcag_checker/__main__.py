"""
Command-line interface for WCAG Checker.
"""

import argparse
import sys
from pathlib import Path

from wcag_checker import WCAGChecker, ConformanceLevel, Report, ReportFormat


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="wcag-checker",
        description="Check HTML content for WCAG 2.2 accessibility issues"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Check command
    check_parser = subparsers.add_parser("check", help="Check HTML file(s)")
    check_parser.add_argument(
        "files",
        nargs="+",
        help="HTML file(s) to check"
    )
    check_parser.add_argument(
        "-l", "--level",
        choices=["A", "AA", "AAA"],
        default="AA",
        help="Target conformance level (default: AA)"
    )
    check_parser.add_argument(
        "-f", "--format",
        choices=["text", "json", "html", "markdown"],
        default="text",
        help="Output format (default: text)"
    )
    check_parser.add_argument(
        "-o", "--output",
        help="Output file (default: stdout)"
    )
    check_parser.add_argument(
        "--no-notices",
        action="store_true",
        help="Exclude NOTICE-level issues"
    )
    check_parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Only show error count"
    )
    
    args = parser.parse_args()
    
    if args.command == "check":
        return run_check(args)
    else:
        parser.print_help()
        return 1


def run_check(args):
    """Run the check command."""
    # Map level string to enum
    level_map = {
        "A": ConformanceLevel.A,
        "AA": ConformanceLevel.AA,
        "AAA": ConformanceLevel.AAA,
    }
    level = level_map[args.level]
    
    # Create checker
    checker = WCAGChecker(
        level=level,
        include_notices=not args.no_notices
    )
    
    # Track overall results
    total_errors = 0
    total_warnings = 0
    total_notices = 0
    all_issues = []
    
    # Check each file
    for filepath in args.files:
        path = Path(filepath)
        if not path.exists():
            print(f"Error: File not found: {filepath}", file=sys.stderr)
            continue
        
        try:
            result = checker.check_file(str(path))
            total_errors += len([i for i in result.issues if i.level.value == "error"])
            total_warnings += len([i for i in result.issues if i.level.value == "warning"])
            total_notices += len([i for i in result.issues if i.level.value == "notice"])
            
            if not args.quiet:
                all_issues.extend(result.issues)
                
        except Exception as e:
            print(f"Error checking {filepath}: {e}", file=sys.stderr)
            continue
    
    if args.quiet:
        print(f"Errors: {total_errors}, Warnings: {total_warnings}, Notices: {total_notices}")
        return 1 if total_errors > 0 else 0
    
    # Generate report
    from wcag_checker.models import CheckResult
    combined_result = CheckResult(
        issues=all_issues,
        html_length=0,
        checks_run=0,
        level=level
    )
    
    report = Report(combined_result)
    
    # Map format string to enum
    format_map = {
        "text": ReportFormat.TEXT,
        "json": ReportFormat.JSON,
        "html": ReportFormat.HTML,
        "markdown": ReportFormat.MARKDOWN,
    }
    fmt = format_map[args.format]
    
    # Generate output
    if fmt == ReportFormat.TEXT:
        output = report.to_text()
    elif fmt == ReportFormat.JSON:
        output = report.to_json()
    elif fmt == ReportFormat.HTML:
        output = report.to_html()
    elif fmt == ReportFormat.MARKDOWN:
        output = report.to_markdown()
    
    # Write output
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"Report saved to {args.output}")
    else:
        print(output)
    
    return 1 if total_errors > 0 else 0


if __name__ == "__main__":
    sys.exit(main())
