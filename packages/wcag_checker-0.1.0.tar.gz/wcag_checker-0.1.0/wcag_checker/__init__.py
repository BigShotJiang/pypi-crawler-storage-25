"""
WCAG Checker - A comprehensive Python library for WCAG 2.2 accessibility testing.

This library provides automated checking of HTML content against 
Web Content Accessibility Guidelines (WCAG) 2.2 success criteria.
"""

from wcag_checker.checker import WCAGChecker
from wcag_checker.models import (
    Issue,
    IssueLevel,
    ConformanceLevel,
    CheckResult,
    WCAGCriterion,
)
from wcag_checker.report import Report, ReportFormat

__version__ = "1.0.0"
__all__ = [
    "WCAGChecker",
    "Issue",
    "IssueLevel",
    "ConformanceLevel",
    "CheckResult",
    "WCAGCriterion",
    "Report",
    "ReportFormat",
]
