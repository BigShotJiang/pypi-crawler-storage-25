"""
WCAG 2.2 Success Criteria definitions.

This module contains all WCAG 2.2 success criteria with their
metadata for reference during checks.
"""

from wcag_checker.models import WCAGCriterion, ConformanceLevel, WCAGPrinciple


# Helper function to create criteria
def _criterion(
    id: str,
    name: str,
    level: str,
    principle: str,
    guideline: str,
    description: str
) -> WCAGCriterion:
    return WCAGCriterion(
        id=id,
        name=name,
        level=ConformanceLevel[level],
        principle=WCAGPrinciple(principle),
        guideline=guideline,
        description=description,
        url=f"https://www.w3.org/WAI/WCAG22/Understanding/{name.lower().replace(' ', '-').replace('(', '').replace(')', '')}.html"
    )


# =============================================================================
# Principle 1: Perceivable
# =============================================================================

# Guideline 1.1 Text Alternatives
SC_1_1_1 = _criterion(
    "1.1.1", "Non-text Content", "A", "1",
    "1.1 Text Alternatives",
    "All non-text content has a text alternative that serves the equivalent purpose."
)

# Guideline 1.2 Time-based Media
SC_1_2_1 = _criterion(
    "1.2.1", "Audio-only and Video-only (Prerecorded)", "A", "1",
    "1.2 Time-based Media",
    "For prerecorded audio-only and video-only media, alternatives are provided."
)

SC_1_2_2 = _criterion(
    "1.2.2", "Captions (Prerecorded)", "A", "1",
    "1.2 Time-based Media",
    "Captions are provided for all prerecorded audio content in synchronized media."
)

SC_1_2_3 = _criterion(
    "1.2.3", "Audio Description or Media Alternative (Prerecorded)", "A", "1",
    "1.2 Time-based Media",
    "An alternative for time-based media or audio description is provided."
)

SC_1_2_4 = _criterion(
    "1.2.4", "Captions (Live)", "AA", "1",
    "1.2 Time-based Media",
    "Captions are provided for all live audio content in synchronized media."
)

SC_1_2_5 = _criterion(
    "1.2.5", "Audio Description (Prerecorded)", "AA", "1",
    "1.2 Time-based Media",
    "Audio description is provided for all prerecorded video content."
)

SC_1_2_6 = _criterion(
    "1.2.6", "Sign Language (Prerecorded)", "AAA", "1",
    "1.2 Time-based Media",
    "Sign language interpretation is provided for all prerecorded audio content."
)

SC_1_2_7 = _criterion(
    "1.2.7", "Extended Audio Description (Prerecorded)", "AAA", "1",
    "1.2 Time-based Media",
    "Extended audio description is provided where pauses are insufficient."
)

SC_1_2_8 = _criterion(
    "1.2.8", "Media Alternative (Prerecorded)", "AAA", "1",
    "1.2 Time-based Media",
    "An alternative for time-based media is provided for all prerecorded media."
)

SC_1_2_9 = _criterion(
    "1.2.9", "Audio-only (Live)", "AAA", "1",
    "1.2 Time-based Media",
    "An alternative for time-based media is provided for live audio-only content."
)

# Guideline 1.3 Adaptable
SC_1_3_1 = _criterion(
    "1.3.1", "Info and Relationships", "A", "1",
    "1.3 Adaptable",
    "Information, structure, and relationships can be programmatically determined."
)

SC_1_3_2 = _criterion(
    "1.3.2", "Meaningful Sequence", "A", "1",
    "1.3 Adaptable",
    "When sequence affects meaning, a correct reading sequence can be determined."
)

SC_1_3_3 = _criterion(
    "1.3.3", "Sensory Characteristics", "A", "1",
    "1.3 Adaptable",
    "Instructions do not rely solely on sensory characteristics."
)

SC_1_3_4 = _criterion(
    "1.3.4", "Orientation", "AA", "1",
    "1.3 Adaptable",
    "Content does not restrict view and operation to a single display orientation."
)

SC_1_3_5 = _criterion(
    "1.3.5", "Identify Input Purpose", "AA", "1",
    "1.3 Adaptable",
    "The purpose of input fields collecting user information can be programmatically determined."
)

SC_1_3_6 = _criterion(
    "1.3.6", "Identify Purpose", "AAA", "1",
    "1.3 Adaptable",
    "The purpose of UI components, icons, and regions can be programmatically determined."
)

# Guideline 1.4 Distinguishable
SC_1_4_1 = _criterion(
    "1.4.1", "Use of Color", "A", "1",
    "1.4 Distinguishable",
    "Color is not used as the only visual means of conveying information."
)

SC_1_4_2 = _criterion(
    "1.4.2", "Audio Control", "A", "1",
    "1.4 Distinguishable",
    "A mechanism is available to pause or stop audio that plays automatically."
)

SC_1_4_3 = _criterion(
    "1.4.3", "Contrast (Minimum)", "AA", "1",
    "1.4 Distinguishable",
    "Text has a contrast ratio of at least 4.5:1 (3:1 for large text)."
)

SC_1_4_4 = _criterion(
    "1.4.4", "Resize Text", "AA", "1",
    "1.4 Distinguishable",
    "Text can be resized without assistive technology up to 200 percent."
)

SC_1_4_5 = _criterion(
    "1.4.5", "Images of Text", "AA", "1",
    "1.4 Distinguishable",
    "Text is used to convey information rather than images of text."
)

SC_1_4_6 = _criterion(
    "1.4.6", "Contrast (Enhanced)", "AAA", "1",
    "1.4 Distinguishable",
    "Text has a contrast ratio of at least 7:1 (4.5:1 for large text)."
)

SC_1_4_7 = _criterion(
    "1.4.7", "Low or No Background Audio", "AAA", "1",
    "1.4 Distinguishable",
    "Prerecorded audio-only content has low or no background audio."
)

SC_1_4_8 = _criterion(
    "1.4.8", "Visual Presentation", "AAA", "1",
    "1.4 Distinguishable",
    "For blocks of text, visual presentation can be customized."
)

SC_1_4_9 = _criterion(
    "1.4.9", "Images of Text (No Exception)", "AAA", "1",
    "1.4 Distinguishable",
    "Images of text are only used for pure decoration or essential purposes."
)

SC_1_4_10 = _criterion(
    "1.4.10", "Reflow", "AA", "1",
    "1.4 Distinguishable",
    "Content can be presented without loss at 320 CSS pixels width."
)

SC_1_4_11 = _criterion(
    "1.4.11", "Non-text Contrast", "AA", "1",
    "1.4 Distinguishable",
    "UI components and graphical objects have a contrast ratio of at least 3:1."
)

SC_1_4_12 = _criterion(
    "1.4.12", "Text Spacing", "AA", "1",
    "1.4 Distinguishable",
    "No loss of content when text spacing is increased."
)

SC_1_4_13 = _criterion(
    "1.4.13", "Content on Hover or Focus", "AA", "1",
    "1.4 Distinguishable",
    "Additional content on hover/focus is dismissible, hoverable, and persistent."
)

# =============================================================================
# Principle 2: Operable
# =============================================================================

# Guideline 2.1 Keyboard Accessible
SC_2_1_1 = _criterion(
    "2.1.1", "Keyboard", "A", "2",
    "2.1 Keyboard Accessible",
    "All functionality is operable through a keyboard interface."
)

SC_2_1_2 = _criterion(
    "2.1.2", "No Keyboard Trap", "A", "2",
    "2.1 Keyboard Accessible",
    "Keyboard focus can be moved away from any component."
)

SC_2_1_3 = _criterion(
    "2.1.3", "Keyboard (No Exception)", "AAA", "2",
    "2.1 Keyboard Accessible",
    "All functionality is operable through a keyboard without exception."
)

SC_2_1_4 = _criterion(
    "2.1.4", "Character Key Shortcuts", "A", "2",
    "2.1 Keyboard Accessible",
    "Character key shortcuts can be turned off, remapped, or are only active on focus."
)

# Guideline 2.2 Enough Time
SC_2_2_1 = _criterion(
    "2.2.1", "Timing Adjustable", "A", "2",
    "2.2 Enough Time",
    "Users can turn off, adjust, or extend time limits."
)

SC_2_2_2 = _criterion(
    "2.2.2", "Pause, Stop, Hide", "A", "2",
    "2.2 Enough Time",
    "Moving, blinking, or auto-updating content can be paused, stopped, or hidden."
)

SC_2_2_3 = _criterion(
    "2.2.3", "No Timing", "AAA", "2",
    "2.2 Enough Time",
    "Timing is not an essential part of the activity."
)

SC_2_2_4 = _criterion(
    "2.2.4", "Interruptions", "AAA", "2",
    "2.2 Enough Time",
    "Interruptions can be postponed or suppressed."
)

SC_2_2_5 = _criterion(
    "2.2.5", "Re-authenticating", "AAA", "2",
    "2.2 Enough Time",
    "Data is preserved when re-authenticating after session expiry."
)

SC_2_2_6 = _criterion(
    "2.2.6", "Timeouts", "AAA", "2",
    "2.2 Enough Time",
    "Users are warned of inactivity timeouts that could cause data loss."
)

# Guideline 2.3 Seizures and Physical Reactions
SC_2_3_1 = _criterion(
    "2.3.1", "Three Flashes or Below Threshold", "A", "2",
    "2.3 Seizures and Physical Reactions",
    "Content does not flash more than three times per second."
)

SC_2_3_2 = _criterion(
    "2.3.2", "Three Flashes", "AAA", "2",
    "2.3 Seizures and Physical Reactions",
    "Content does not contain anything that flashes more than three times per second."
)

SC_2_3_3 = _criterion(
    "2.3.3", "Animation from Interactions", "AAA", "2",
    "2.3 Seizures and Physical Reactions",
    "Motion animation triggered by interaction can be disabled."
)

# Guideline 2.4 Navigable
SC_2_4_1 = _criterion(
    "2.4.1", "Bypass Blocks", "A", "2",
    "2.4 Navigable",
    "A mechanism is available to bypass blocks of repeated content."
)

SC_2_4_2 = _criterion(
    "2.4.2", "Page Titled", "A", "2",
    "2.4 Navigable",
    "Web pages have titles that describe topic or purpose."
)

SC_2_4_3 = _criterion(
    "2.4.3", "Focus Order", "A", "2",
    "2.4 Navigable",
    "Focusable components receive focus in an order that preserves meaning."
)

SC_2_4_4 = _criterion(
    "2.4.4", "Link Purpose (In Context)", "A", "2",
    "2.4 Navigable",
    "The purpose of each link can be determined from the link text or its context."
)

SC_2_4_5 = _criterion(
    "2.4.5", "Multiple Ways", "AA", "2",
    "2.4 Navigable",
    "More than one way is available to locate a web page within a set of pages."
)

SC_2_4_6 = _criterion(
    "2.4.6", "Headings and Labels", "AA", "2",
    "2.4 Navigable",
    "Headings and labels describe topic or purpose."
)

SC_2_4_7 = _criterion(
    "2.4.7", "Focus Visible", "AA", "2",
    "2.4 Navigable",
    "Any keyboard operable UI has a visible keyboard focus indicator."
)

SC_2_4_8 = _criterion(
    "2.4.8", "Location", "AAA", "2",
    "2.4 Navigable",
    "Information about the user's location within a set of pages is available."
)

SC_2_4_9 = _criterion(
    "2.4.9", "Link Purpose (Link Only)", "AAA", "2",
    "2.4 Navigable",
    "A mechanism is available to identify link purpose from link text alone."
)

SC_2_4_10 = _criterion(
    "2.4.10", "Section Headings", "AAA", "2",
    "2.4 Navigable",
    "Section headings are used to organize content."
)

SC_2_4_11 = _criterion(
    "2.4.11", "Focus Not Obscured (Minimum)", "AA", "2",
    "2.4 Navigable",
    "When a component receives focus, it is not entirely hidden by author-created content."
)

SC_2_4_12 = _criterion(
    "2.4.12", "Focus Not Obscured (Enhanced)", "AAA", "2",
    "2.4 Navigable",
    "When a component receives focus, no part is hidden by author-created content."
)

SC_2_4_13 = _criterion(
    "2.4.13", "Focus Appearance", "AAA", "2",
    "2.4 Navigable",
    "Focus indicator meets minimum area and contrast requirements."
)

# Guideline 2.5 Input Modalities
SC_2_5_1 = _criterion(
    "2.5.1", "Pointer Gestures", "A", "2",
    "2.5 Input Modalities",
    "Multipoint or path-based gestures have single-pointer alternatives."
)

SC_2_5_2 = _criterion(
    "2.5.2", "Pointer Cancellation", "A", "2",
    "2.5 Input Modalities",
    "Functions using a single pointer can be cancelled or aborted."
)

SC_2_5_3 = _criterion(
    "2.5.3", "Label in Name", "A", "2",
    "2.5 Input Modalities",
    "UI components with visible labels include the label text in their name."
)

SC_2_5_4 = _criterion(
    "2.5.4", "Motion Actuation", "A", "2",
    "2.5 Input Modalities",
    "Motion-activated functionality has UI alternatives and can be disabled."
)

SC_2_5_5 = _criterion(
    "2.5.5", "Target Size (Enhanced)", "AAA", "2",
    "2.5 Input Modalities",
    "Target size for pointer inputs is at least 44 by 44 CSS pixels."
)

SC_2_5_6 = _criterion(
    "2.5.6", "Concurrent Input Mechanisms", "AAA", "2",
    "2.5 Input Modalities",
    "Web content does not restrict use of available input modalities."
)

SC_2_5_7 = _criterion(
    "2.5.7", "Dragging Movements", "AA", "2",
    "2.5 Input Modalities",
    "Dragging functionality has single-pointer alternatives."
)

SC_2_5_8 = _criterion(
    "2.5.8", "Target Size (Minimum)", "AA", "2",
    "2.5 Input Modalities",
    "Target size for pointer inputs is at least 24 by 24 CSS pixels."
)

# =============================================================================
# Principle 3: Understandable
# =============================================================================

# Guideline 3.1 Readable
SC_3_1_1 = _criterion(
    "3.1.1", "Language of Page", "A", "3",
    "3.1 Readable",
    "The default human language of the page can be programmatically determined."
)

SC_3_1_2 = _criterion(
    "3.1.2", "Language of Parts", "AA", "3",
    "3.1 Readable",
    "The language of each passage can be programmatically determined."
)

SC_3_1_3 = _criterion(
    "3.1.3", "Unusual Words", "AAA", "3",
    "3.1 Readable",
    "A mechanism identifies definitions of unusual words or jargon."
)

SC_3_1_4 = _criterion(
    "3.1.4", "Abbreviations", "AAA", "3",
    "3.1 Readable",
    "A mechanism for identifying the expanded form of abbreviations is available."
)

SC_3_1_5 = _criterion(
    "3.1.5", "Reading Level", "AAA", "3",
    "3.1 Readable",
    "Supplemental content or simpler versions are available for complex text."
)

SC_3_1_6 = _criterion(
    "3.1.6", "Pronunciation", "AAA", "3",
    "3.1 Readable",
    "A mechanism identifies specific pronunciation of ambiguous words."
)

# Guideline 3.2 Predictable
SC_3_2_1 = _criterion(
    "3.2.1", "On Focus", "A", "3",
    "3.2 Predictable",
    "Receiving focus does not initiate a change of context."
)

SC_3_2_2 = _criterion(
    "3.2.2", "On Input", "A", "3",
    "3.2 Predictable",
    "Changing a setting does not automatically cause a change of context."
)

SC_3_2_3 = _criterion(
    "3.2.3", "Consistent Navigation", "AA", "3",
    "3.2 Predictable",
    "Navigational mechanisms occur in the same relative order on each page."
)

SC_3_2_4 = _criterion(
    "3.2.4", "Consistent Identification", "AA", "3",
    "3.2 Predictable",
    "Components with same functionality are identified consistently."
)

SC_3_2_5 = _criterion(
    "3.2.5", "Change on Request", "AAA", "3",
    "3.2 Predictable",
    "Changes of context are initiated only by user request."
)

SC_3_2_6 = _criterion(
    "3.2.6", "Consistent Help", "A", "3",
    "3.2 Predictable",
    "Help mechanisms occur in the same relative order on each page."
)

# Guideline 3.3 Input Assistance
SC_3_3_1 = _criterion(
    "3.3.1", "Error Identification", "A", "3",
    "3.3 Input Assistance",
    "Input errors are automatically detected and described to the user in text."
)

SC_3_3_2 = _criterion(
    "3.3.2", "Labels or Instructions", "A", "3",
    "3.3 Input Assistance",
    "Labels or instructions are provided when content requires user input."
)

SC_3_3_3 = _criterion(
    "3.3.3", "Error Suggestion", "AA", "3",
    "3.3 Input Assistance",
    "If an input error is detected, correction suggestions are provided."
)

SC_3_3_4 = _criterion(
    "3.3.4", "Error Prevention (Legal, Financial, Data)", "AA", "3",
    "3.3 Input Assistance",
    "For legal/financial submissions, submissions are reversible, checked, or confirmed."
)

SC_3_3_5 = _criterion(
    "3.3.5", "Help", "AAA", "3",
    "3.3 Input Assistance",
    "Context-sensitive help is available."
)

SC_3_3_6 = _criterion(
    "3.3.6", "Error Prevention (All)", "AAA", "3",
    "3.3 Input Assistance",
    "For all user submissions, submissions are reversible, checked, or confirmed."
)

SC_3_3_7 = _criterion(
    "3.3.7", "Redundant Entry", "A", "3",
    "3.3 Input Assistance",
    "Information previously entered is auto-populated or available for selection."
)

SC_3_3_8 = _criterion(
    "3.3.8", "Accessible Authentication (Minimum)", "AA", "3",
    "3.3 Input Assistance",
    "Cognitive function tests are not required for authentication unless alternatives exist."
)

SC_3_3_9 = _criterion(
    "3.3.9", "Accessible Authentication (Enhanced)", "AAA", "3",
    "3.3 Input Assistance",
    "No cognitive function tests are required for authentication."
)

# =============================================================================
# Principle 4: Robust
# =============================================================================

# Guideline 4.1 Compatible
# Note: SC 4.1.1 Parsing is obsolete in WCAG 2.2 but we still check for
# common issues like duplicate IDs as they can still cause accessibility problems
SC_4_1_1 = _criterion(
    "4.1.1", "Parsing", "A", "4",
    "4.1 Compatible",
    "Elements have complete start/end tags, are nested properly, have unique IDs."
)

SC_4_1_2 = _criterion(
    "4.1.2", "Name, Role, Value", "A", "4",
    "4.1 Compatible",
    "UI components have name and role that can be programmatically determined."
)

SC_4_1_3 = _criterion(
    "4.1.3", "Status Messages", "AA", "4",
    "4.1 Compatible",
    "Status messages can be presented to the user by assistive technologies."
)


# =============================================================================
# Criteria Collections
# =============================================================================

ALL_CRITERIA = [
    # Principle 1
    SC_1_1_1, SC_1_2_1, SC_1_2_2, SC_1_2_3, SC_1_2_4, SC_1_2_5, SC_1_2_6,
    SC_1_2_7, SC_1_2_8, SC_1_2_9, SC_1_3_1, SC_1_3_2, SC_1_3_3, SC_1_3_4,
    SC_1_3_5, SC_1_3_6, SC_1_4_1, SC_1_4_2, SC_1_4_3, SC_1_4_4, SC_1_4_5,
    SC_1_4_6, SC_1_4_7, SC_1_4_8, SC_1_4_9, SC_1_4_10, SC_1_4_11, SC_1_4_12,
    SC_1_4_13,
    # Principle 2
    SC_2_1_1, SC_2_1_2, SC_2_1_3, SC_2_1_4, SC_2_2_1, SC_2_2_2, SC_2_2_3,
    SC_2_2_4, SC_2_2_5, SC_2_2_6, SC_2_3_1, SC_2_3_2, SC_2_3_3, SC_2_4_1,
    SC_2_4_2, SC_2_4_3, SC_2_4_4, SC_2_4_5, SC_2_4_6, SC_2_4_7, SC_2_4_8,
    SC_2_4_9, SC_2_4_10, SC_2_4_11, SC_2_4_12, SC_2_4_13, SC_2_5_1, SC_2_5_2,
    SC_2_5_3, SC_2_5_4, SC_2_5_5, SC_2_5_6, SC_2_5_7, SC_2_5_8,
    # Principle 3
    SC_3_1_1, SC_3_1_2, SC_3_1_3, SC_3_1_4, SC_3_1_5, SC_3_1_6, SC_3_2_1,
    SC_3_2_2, SC_3_2_3, SC_3_2_4, SC_3_2_5, SC_3_2_6, SC_3_3_1, SC_3_3_2,
    SC_3_3_3, SC_3_3_4, SC_3_3_5, SC_3_3_6, SC_3_3_7, SC_3_3_8, SC_3_3_9,
    # Principle 4
    SC_4_1_1, SC_4_1_2, SC_4_1_3,
]

LEVEL_A_CRITERIA = [c for c in ALL_CRITERIA if c.level == ConformanceLevel.A]
LEVEL_AA_CRITERIA = [c for c in ALL_CRITERIA if c.level == ConformanceLevel.AA]
LEVEL_AAA_CRITERIA = [c for c in ALL_CRITERIA if c.level == ConformanceLevel.AAA]

# Criteria by ID for quick lookup
CRITERIA_BY_ID = {c.id: c for c in ALL_CRITERIA}


def get_criterion(criterion_id: str) -> WCAGCriterion:
    """Get a criterion by its ID."""
    if criterion_id not in CRITERIA_BY_ID:
        raise ValueError(f"Unknown criterion ID: {criterion_id}")
    return CRITERIA_BY_ID[criterion_id]


def get_criteria_for_level(level: ConformanceLevel) -> list:
    """Get all criteria for a conformance level (includes lower levels)."""
    if level == ConformanceLevel.A:
        return LEVEL_A_CRITERIA.copy()
    elif level == ConformanceLevel.AA:
        return LEVEL_A_CRITERIA + LEVEL_AA_CRITERIA
    else:
        return ALL_CRITERIA.copy()
