"""
Utility functions for WCAG checking.
"""

import re
from typing import Optional, Tuple, List
from bs4 import Tag


def get_accessible_name(element: Tag) -> str:
    """
    Get the accessible name of an element following the 
    accessible name computation algorithm.
    
    Args:
        element: The BeautifulSoup Tag element
        
    Returns:
        The computed accessible name
    """
    if element is None:
        return ""
    
    # 1. Check aria-labelledby
    labelledby = element.get('aria-labelledby')
    if labelledby:
        # Find referenced elements and concatenate their text
        soup = element.find_parent(['html', '[document]'])
        if soup:
            labels = []
            for ref_id in labelledby.split():
                ref_elem = soup.find(id=ref_id)
                if ref_elem:
                    labels.append(get_text_content(ref_elem))
            if labels:
                return ' '.join(labels).strip()
    
    # 2. Check aria-label
    aria_label = element.get('aria-label')
    if aria_label:
        return aria_label.strip()
    
    # 3. For <img>, check alt attribute
    if element.name == 'img':
        alt = element.get('alt')
        if alt is not None:
            return alt.strip()
    
    # 4. For <input>, check associated label
    if element.name == 'input':
        # Check for label wrapping the input
        parent_label = element.find_parent('label')
        if parent_label:
            return get_text_content(parent_label).strip()
        
        # Check for label with for attribute
        input_id = element.get('id')
        if input_id:
            soup = element.find_parent(['html', '[document]'])
            if soup:
                label = soup.find('label', {'for': input_id})
                if label:
                    return get_text_content(label).strip()
        
        # Check title attribute
        title = element.get('title')
        if title:
            return title.strip()
        
        # Check placeholder
        placeholder = element.get('placeholder')
        if placeholder:
            return placeholder.strip()
    
    # 5. For <button>, <a>, etc., use text content
    if element.name in ('button', 'a', 'th', 'td', 'label'):
        return get_text_content(element).strip()
    
    # 6. Check title attribute
    title = element.get('title')
    if title:
        return title.strip()
    
    return ""


def get_text_content(element: Tag) -> str:
    """
    Get the text content of an element, including alt text of images.
    
    Args:
        element: The BeautifulSoup Tag element
        
    Returns:
        The text content
    """
    if element is None:
        return ""
    
    texts = []
    for child in element.descendants:
        if isinstance(child, str):
            texts.append(child)
        elif hasattr(child, 'name'):
            if child.name == 'img':
                alt = child.get('alt', '')
                if alt:
                    texts.append(alt)
    
    return ' '.join(texts).strip()


def is_hidden(element: Tag) -> bool:
    """
    Check if an element is hidden from accessibility tree.
    
    Args:
        element: The BeautifulSoup Tag element
        
    Returns:
        True if the element is hidden
    """
    if element is None:
        return True
    
    # Check HTML hidden attribute
    if element.has_attr('hidden'):
        return True
    
    # Check aria-hidden
    if element.get('aria-hidden') == 'true':
        return True
    
    # Check CSS display/visibility in style attribute
    style = element.get('style', '')
    if 'display:none' in style.replace(' ', '') or 'display: none' in style:
        return True
    if 'visibility:hidden' in style.replace(' ', '') or 'visibility: hidden' in style:
        return True
    
    # Check type="hidden" for inputs
    if element.name == 'input' and element.get('type') == 'hidden':
        return True
    
    return False


def is_decorative(element: Tag) -> bool:
    """
    Check if an element is marked as decorative.
    
    Args:
        element: The BeautifulSoup Tag element
        
    Returns:
        True if the element is decorative
    """
    if element is None:
        return False
    
    # Empty alt indicates decorative image
    if element.name == 'img' and element.get('alt') == '':
        return True
    
    # role="presentation" or role="none"
    role = element.get('role', '').lower()
    if role in ('presentation', 'none'):
        return True
    
    # aria-hidden="true"
    if element.get('aria-hidden') == 'true':
        return True
    
    return False


def is_focusable(element: Tag) -> bool:
    """
    Check if an element is focusable.
    
    Args:
        element: The BeautifulSoup Tag element
        
    Returns:
        True if the element is focusable
    """
    if element is None:
        return False
    
    if is_hidden(element):
        return False
    
    # Check tabindex
    tabindex = element.get('tabindex')
    if tabindex is not None:
        try:
            return int(tabindex) >= 0
        except ValueError:
            pass
    
    # Natively focusable elements
    focusable_elements = {
        'a': lambda e: e.has_attr('href'),
        'button': lambda e: not e.get('disabled'),
        'input': lambda e: e.get('type') != 'hidden' and not e.get('disabled'),
        'select': lambda e: not e.get('disabled'),
        'textarea': lambda e: not e.get('disabled'),
        'area': lambda e: e.has_attr('href'),
        'iframe': lambda e: True,
        'object': lambda e: True,
        'embed': lambda e: True,
    }
    
    if element.name in focusable_elements:
        return focusable_elements[element.name](element)
    
    # Elements with contenteditable
    if element.get('contenteditable') == 'true':
        return True
    
    return False


def is_interactive(element: Tag) -> bool:
    """
    Check if an element is interactive (clickable, etc.).
    
    Args:
        element: The BeautifulSoup Tag element
        
    Returns:
        True if the element is interactive
    """
    if element is None:
        return False
    
    # Check for click handlers
    for attr in element.attrs:
        if attr.startswith('on'):
            return True
    
    # Check focusable
    if is_focusable(element):
        return True
    
    # Check for interactive roles
    interactive_roles = {
        'button', 'link', 'checkbox', 'radio', 'textbox', 'listbox',
        'combobox', 'menuitem', 'menuitemcheckbox', 'menuitemradio',
        'option', 'slider', 'spinbutton', 'switch', 'tab', 'treeitem'
    }
    role = element.get('role', '').lower()
    if role in interactive_roles:
        return True
    
    return False


def parse_color(color_str: str) -> Optional[Tuple[int, int, int]]:
    """
    Parse a color string to RGB tuple.
    
    Args:
        color_str: Color in various formats (hex, rgb, named)
        
    Returns:
        Tuple of (r, g, b) values, or None if parsing fails
    """
    if not color_str:
        return None
    
    color_str = color_str.strip().lower()
    
    # Named colors (common ones)
    named_colors = {
        'black': (0, 0, 0),
        'white': (255, 255, 255),
        'red': (255, 0, 0),
        'green': (0, 128, 0),
        'blue': (0, 0, 255),
        'yellow': (255, 255, 0),
        'cyan': (0, 255, 255),
        'magenta': (255, 0, 255),
        'gray': (128, 128, 128),
        'grey': (128, 128, 128),
        'silver': (192, 192, 192),
        'maroon': (128, 0, 0),
        'navy': (0, 0, 128),
        'olive': (128, 128, 0),
        'purple': (128, 0, 128),
        'teal': (0, 128, 128),
        'orange': (255, 165, 0),
        'transparent': None,
    }
    
    if color_str in named_colors:
        return named_colors[color_str]
    
    # Hex format
    hex_match = re.match(r'^#?([0-9a-f]{3}|[0-9a-f]{6})$', color_str)
    if hex_match:
        hex_str = hex_match.group(1)
        if len(hex_str) == 3:
            hex_str = ''.join([c*2 for c in hex_str])
        return (
            int(hex_str[0:2], 16),
            int(hex_str[2:4], 16),
            int(hex_str[4:6], 16)
        )
    
    # RGB format
    rgb_match = re.match(r'rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)', color_str)
    if rgb_match:
        return (
            int(rgb_match.group(1)),
            int(rgb_match.group(2)),
            int(rgb_match.group(3))
        )
    
    return None


def calculate_luminance(rgb: Tuple[int, int, int]) -> float:
    """
    Calculate relative luminance of a color.
    
    Args:
        rgb: Tuple of (r, g, b) values (0-255)
        
    Returns:
        Relative luminance value
    """
    def srgb_to_linear(value):
        value = value / 255.0
        if value <= 0.04045:
            return value / 12.92
        return ((value + 0.055) / 1.055) ** 2.4
    
    r = srgb_to_linear(rgb[0])
    g = srgb_to_linear(rgb[1])
    b = srgb_to_linear(rgb[2])
    
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def calculate_contrast_ratio(color1: Tuple[int, int, int], 
                             color2: Tuple[int, int, int]) -> float:
    """
    Calculate contrast ratio between two colors.
    
    Args:
        color1: First color as (r, g, b)
        color2: Second color as (r, g, b)
        
    Returns:
        Contrast ratio (1.0 to 21.0)
    """
    l1 = calculate_luminance(color1)
    l2 = calculate_luminance(color2)
    
    lighter = max(l1, l2)
    darker = min(l1, l2)
    
    return (lighter + 0.05) / (darker + 0.05)


def is_large_text(font_size: float, is_bold: bool = False) -> bool:
    """
    Determine if text qualifies as "large" for contrast requirements.
    
    Large text is at least 18pt (24px) or 14pt (18.5px) if bold.
    
    Args:
        font_size: Font size in pixels
        is_bold: Whether the text is bold
        
    Returns:
        True if text is large
    """
    if is_bold:
        return font_size >= 18.5  # 14pt
    return font_size >= 24.0  # 18pt


def get_heading_level(element: Tag) -> Optional[int]:
    """
    Get the heading level of an element.
    
    Args:
        element: The BeautifulSoup Tag element
        
    Returns:
        Heading level (1-6) or None if not a heading
    """
    if element is None:
        return None
    
    # Check native heading elements
    if element.name in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
        return int(element.name[1])
    
    # Check ARIA heading role
    if element.get('role') == 'heading':
        level = element.get('aria-level')
        if level:
            try:
                return int(level)
            except ValueError:
                pass
        return 2  # Default heading level
    
    return None


def has_valid_language_code(lang: str) -> bool:
    """
    Check if a language code is valid (basic check).
    
    Args:
        lang: Language code (e.g., "en", "en-US")
        
    Returns:
        True if valid
    """
    if not lang:
        return False
    
    # Basic pattern: 2-3 letter language code, optional region
    pattern = r'^[a-zA-Z]{2,3}(-[a-zA-Z]{2,4})?$'
    return bool(re.match(pattern, lang))


# Input purposes for autocomplete (from WCAG 2.2 Section 7)
VALID_AUTOCOMPLETE_VALUES = {
    'name', 'honorific-prefix', 'given-name', 'additional-name',
    'family-name', 'honorific-suffix', 'nickname', 'username',
    'new-password', 'current-password', 'one-time-code',
    'organization-title', 'organization', 'street-address',
    'address-line1', 'address-line2', 'address-line3',
    'address-level4', 'address-level3', 'address-level2', 'address-level1',
    'country', 'country-name', 'postal-code', 'cc-name',
    'cc-given-name', 'cc-additional-name', 'cc-family-name',
    'cc-number', 'cc-exp', 'cc-exp-month', 'cc-exp-year',
    'cc-csc', 'cc-type', 'transaction-currency', 'transaction-amount',
    'language', 'bday', 'bday-day', 'bday-month', 'bday-year',
    'sex', 'url', 'photo', 'tel', 'tel-country-code',
    'tel-national', 'tel-area-code', 'tel-local', 'tel-local-prefix',
    'tel-local-suffix', 'tel-extension', 'email', 'impp',
    # Section modifiers
    'shipping', 'billing',
    # off and on values
    'off', 'on',
}


def is_valid_autocomplete(value: str) -> bool:
    """
    Check if an autocomplete attribute value is valid.
    
    Args:
        value: The autocomplete attribute value
        
    Returns:
        True if valid
    """
    if not value:
        return False
    
    tokens = value.lower().split()
    
    # Check each token
    for token in tokens:
        if token not in VALID_AUTOCOMPLETE_VALUES:
            # Check if it's a section token (section-*)
            if not token.startswith('section-'):
                return False
    
    return True
