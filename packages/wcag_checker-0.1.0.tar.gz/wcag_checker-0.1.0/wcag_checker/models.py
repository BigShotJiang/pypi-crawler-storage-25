"""
Data models for WCAG Checker results and issues.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any, Union


class ConformanceLevel(Enum):
    """WCAG conformance levels."""
    A = "A"
    AA = "AA"
    AAA = "AAA"


class IssueLevel(Enum):
    """Severity level of accessibility issues."""
    ERROR = "error"          # Definite WCAG violation
    WARNING = "warning"      # Potential issue, needs manual review
    NOTICE = "notice"        # Best practice recommendation


class WCAGPrinciple(Enum):
    """The four WCAG principles."""
    PERCEIVABLE = "1"
    OPERABLE = "2"
    UNDERSTANDABLE = "3"
    ROBUST = "4"


@dataclass
class WCAGCriterion:
    """Represents a WCAG 2.2 success criterion."""
    id: str                           # e.g., "1.1.1"
    name: str                         # e.g., "Non-text Content"
    level: ConformanceLevel           # A, AA, or AAA
    principle: WCAGPrinciple
    guideline: str                    # e.g., "1.1 Text Alternatives"
    description: str
    url: str = ""                     # Link to WCAG documentation
    
    @property
    def full_id(self) -> str:
        """Return the full criterion identifier."""
        return f"WCAG {self.id}"
    
    def __str__(self) -> str:
        return f"{self.full_id} {self.name} (Level {self.level.value})"


@dataclass
class Issue:
    """Represents a single accessibility issue found in the content."""
    criterion: WCAGCriterion
    level: IssueLevel
    message: str
    element: Optional[str] = None      # The HTML element causing the issue
    selector: Optional[str] = None     # CSS selector to locate the element
    line: Optional[int] = None         # Line number in source
    column: Optional[int] = None       # Column number in source
    context: Optional[str] = None      # Surrounding HTML context
    recommendation: Optional[str] = None  # How to fix the issue
    techniques: List[str] = field(default_factory=list)  # WCAG techniques
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert issue to dictionary format."""
        return {
            "criterion": {
                "id": self.criterion.id,
                "name": self.criterion.name,
                "level": self.criterion.level.value,
                "principle": self.criterion.principle.value,
            },
            "severity": self.level.value,
            "message": self.message,
            "element": self.element,
            "selector": self.selector,
            "line": self.line,
            "column": self.column,
            "context": self.context,
            "recommendation": self.recommendation,
            "techniques": self.techniques,
        }
    
    def __str__(self) -> str:
        location = ""
        if self.line:
            location = f" at line {self.line}"
            if self.column:
                location += f", column {self.column}"
        return f"[{self.level.value.upper()}] {self.criterion}: {self.message}{location}"


@dataclass
class CheckResult:
    """Result of running WCAG checks on content."""
    issues: List[Issue] = field(default_factory=list)
    checks_run: int = 0
    level: ConformanceLevel = ConformanceLevel.AA
    source_file: Optional[str] = None
    html_length: int = 0
    
    @property
    def errors(self) -> List[Issue]:
        """Get all error-level issues."""
        return [i for i in self.issues if i.level == IssueLevel.ERROR]
    
    @property
    def warnings(self) -> List[Issue]:
        """Get all warning-level issues."""
        return [i for i in self.issues if i.level == IssueLevel.WARNING]
    
    @property
    def notices(self) -> List[Issue]:
        """Get all notice-level issues."""
        return [i for i in self.issues if i.level == IssueLevel.NOTICE]
    
    @property
    def is_compliant(self) -> bool:
        """Check if content has no errors (warnings/notices allowed)."""
        return len(self.errors) == 0
    
    def filter_by_level(self, level: IssueLevel) -> List[Issue]:
        """Filter issues by severity level."""
        return [i for i in self.issues if i.level == level]
    
    def filter_by_criterion(self, criterion_id: str) -> List[Issue]:
        """Filter issues by criterion ID."""
        return [i for i in self.issues if i.criterion.id == criterion_id]
    
    def filter_by_principle(self, principle: Union[str, WCAGPrinciple]) -> List[Issue]:
        """Filter issues by principle."""
        if isinstance(principle, str):
            principle = WCAGPrinciple(principle.upper())
        return [i for i in self.issues if i.criterion.principle == principle]
    
    def summary(self) -> str:
        """Get a text summary of the check results."""
        status = "PASS" if self.is_compliant else "FAIL"
        return (
            f"WCAG Check Result: {status}\n"
            f"  Errors: {len(self.errors)}, Warnings: {len(self.warnings)}, "
            f"Notices: {len(self.notices)}\n"
            f"  Checks Run: {self.checks_run}"
        )
    
    def __str__(self) -> str:
        return self.summary()
