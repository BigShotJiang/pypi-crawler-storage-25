"""
Report generation for WCAG check results.
"""

from enum import Enum
from typing import Optional
import json
from datetime import datetime

from wcag_checker.models import CheckResult, Issue, IssueLevel, ConformanceLevel


class ReportFormat(Enum):
    """Available report formats."""
    TEXT = "text"
    JSON = "json"
    HTML = "html"
    MARKDOWN = "markdown"


class Report:
    """
    Generate reports from WCAG check results.
    
    Example:
        >>> result = checker.check(html)
        >>> report = Report(result)
        >>> print(report.to_text())
        >>> report.save("report.html", ReportFormat.HTML)
    """
    
    def __init__(self, result: CheckResult):
        """
        Initialize report generator.
        
        Args:
            result: CheckResult from WCAGChecker.
        """
        self.result = result
    
    def to_text(self, include_context: bool = True) -> str:
        """
        Generate plain text report.
        
        Args:
            include_context: Whether to include code context for issues.
            
        Returns:
            Formatted text report.
        """
        lines = []
        lines.append("=" * 60)
        lines.append("WCAG 2.2 Accessibility Report")
        lines.append("=" * 60)
        lines.append("")
        
        # Summary
        lines.append(self.result.summary())
        lines.append("")
        
        if not self.result.issues:
            lines.append("No issues found!")
            return "\n".join(lines)
        
        # Issues by level
        for level in [IssueLevel.ERROR, IssueLevel.WARNING, IssueLevel.NOTICE]:
            level_issues = self.result.filter_by_level(level)
            if not level_issues:
                continue
            
            lines.append("-" * 40)
            lines.append(f"{level.value.upper()}S ({len(level_issues)})")
            lines.append("-" * 40)
            
            for i, issue in enumerate(level_issues, 1):
                lines.append(f"\n{i}. [{issue.criterion.id}] {issue.message}")
                
                if issue.selector:
                    lines.append(f"   Selector: {issue.selector}")
                
                if issue.line:
                    lines.append(f"   Line: {issue.line}")
                
                if include_context and issue.context:
                    context_lines = issue.context.split('\n')
                    lines.append("   Context:")
                    for ctx_line in context_lines:
                        lines.append(f"      {ctx_line}")
                
                if issue.recommendation:
                    lines.append(f"   Fix: {issue.recommendation}")
                
                if issue.techniques:
                    lines.append(f"   Techniques: {', '.join(issue.techniques)}")
            
            lines.append("")
        
        return "\n".join(lines)
    
    def to_json(self, indent: int = 2) -> str:
        """
        Generate JSON report.
        
        Args:
            indent: JSON indentation level.
            
        Returns:
            JSON string.
        """
        data = {
            "report": {
                "generated": datetime.now().isoformat(),
                "level": self.result.level.value,
                "source": self.result.source_file,
            },
            "summary": {
                "total_issues": len(self.result.issues),
                "errors": len(self.result.filter_by_level(IssueLevel.ERROR)),
                "warnings": len(self.result.filter_by_level(IssueLevel.WARNING)),
                "notices": len(self.result.filter_by_level(IssueLevel.NOTICE)),
                "checks_run": self.result.checks_run,
                "compliant": self.result.is_compliant,
            },
            "issues": [
                {
                    "level": issue.level.value,
                    "criterion_id": issue.criterion.id,
                    "criterion_name": issue.criterion.name,
                    "message": issue.message,
                    "element": issue.element,
                    "selector": issue.selector,
                    "line": issue.line,
                    "context": issue.context,
                    "recommendation": issue.recommendation,
                    "techniques": issue.techniques,
                }
                for issue in self.result.issues
            ]
        }
        
        return json.dumps(data, indent=indent)
    
    def to_html(self) -> str:
        """
        Generate HTML report.
        
        Returns:
            HTML string.
        """
        error_count = len(self.result.filter_by_level(IssueLevel.ERROR))
        warning_count = len(self.result.filter_by_level(IssueLevel.WARNING))
        notice_count = len(self.result.filter_by_level(IssueLevel.NOTICE))
        
        html_parts = [
            '<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '<meta charset="UTF-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '<title>WCAG 2.2 Accessibility Report</title>',
            '<style>',
            self._get_html_styles(),
            '</style>',
            '</head>',
            '<body>',
            '<main>',
            '<h1>WCAG 2.2 Accessibility Report</h1>',
            f'<p class="meta">Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} | Target Level: {self.result.level.value}</p>',
            '',
            '<section class="summary">',
            '<h2>Summary</h2>',
            '<div class="stats">',
            f'<div class="stat error"><span class="count">{error_count}</span><span class="label">Errors</span></div>',
            f'<div class="stat warning"><span class="count">{warning_count}</span><span class="label">Warnings</span></div>',
            f'<div class="stat notice"><span class="count">{notice_count}</span><span class="label">Notices</span></div>',
            '</div>',
        ]
        
        if self.result.is_compliant:
            html_parts.append('<p class="compliant">✓ No errors found - Document appears compliant</p>')
        else:
            html_parts.append('<p class="not-compliant">✗ Errors found - Document is not compliant</p>')
        
        html_parts.append('</section>')
        
        # Issues section
        if self.result.issues:
            html_parts.append('<section class="issues">')
            html_parts.append('<h2>Issues</h2>')
            
            for level in [IssueLevel.ERROR, IssueLevel.WARNING, IssueLevel.NOTICE]:
                level_issues = self.result.filter_by_level(level)
                if not level_issues:
                    continue
                
                html_parts.append(f'<h3>{level.value.title()}s ({len(level_issues)})</h3>')
                html_parts.append('<ul class="issue-list">')
                
                for issue in level_issues:
                    html_parts.append(f'<li class="issue {level.value}">')
                    html_parts.append(f'<span class="criterion">[{issue.criterion.id}]</span>')
                    html_parts.append(f'<span class="message">{self._escape_html(issue.message)}</span>')
                    
                    if issue.selector or issue.line:
                        html_parts.append('<div class="location">')
                        if issue.selector:
                            html_parts.append(f'<code>{self._escape_html(issue.selector)}</code>')
                        if issue.line:
                            html_parts.append(f'<span>Line {issue.line}</span>')
                        html_parts.append('</div>')
                    
                    if issue.context:
                        html_parts.append(f'<pre class="context">{self._escape_html(issue.context)}</pre>')
                    
                    if issue.recommendation:
                        html_parts.append(f'<p class="recommendation"><strong>Fix:</strong> {self._escape_html(issue.recommendation)}</p>')
                    
                    if issue.techniques:
                        techniques_links = ', '.join(
                            f'<a href="https://www.w3.org/WAI/WCAG22/Techniques/{t[:1]}/{t}" target="_blank">{t}</a>'
                            for t in issue.techniques
                        )
                        html_parts.append(f'<p class="techniques"><strong>Techniques:</strong> {techniques_links}</p>')
                    
                    html_parts.append('</li>')
                
                html_parts.append('</ul>')
            
            html_parts.append('</section>')
        
        html_parts.extend([
            '</main>',
            '</body>',
            '</html>'
        ])
        
        return '\n'.join(html_parts)
    
    def to_markdown(self) -> str:
        """
        Generate Markdown report.
        
        Returns:
            Markdown string.
        """
        lines = []
        lines.append("# WCAG 2.2 Accessibility Report")
        lines.append("")
        lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**Target Level:** {self.result.level.value}")
        lines.append("")
        
        # Summary
        lines.append("## Summary")
        lines.append("")
        error_count = len(self.result.filter_by_level(IssueLevel.ERROR))
        warning_count = len(self.result.filter_by_level(IssueLevel.WARNING))
        notice_count = len(self.result.filter_by_level(IssueLevel.NOTICE))
        
        lines.append(f"| Type | Count |")
        lines.append("|------|-------|")
        lines.append(f"| Errors | {error_count} |")
        lines.append(f"| Warnings | {warning_count} |")
        lines.append(f"| Notices | {notice_count} |")
        lines.append("")
        
        if self.result.is_compliant:
            lines.append("✅ **No errors found - Document appears compliant**")
        else:
            lines.append("❌ **Errors found - Document is not compliant**")
        lines.append("")
        
        if not self.result.issues:
            return "\n".join(lines)
        
        # Issues
        lines.append("## Issues")
        lines.append("")
        
        for level in [IssueLevel.ERROR, IssueLevel.WARNING, IssueLevel.NOTICE]:
            level_issues = self.result.filter_by_level(level)
            if not level_issues:
                continue
            
            emoji = {"error": "🔴", "warning": "🟡", "notice": "🔵"}[level.value]
            lines.append(f"### {emoji} {level.value.title()}s ({len(level_issues)})")
            lines.append("")
            
            for i, issue in enumerate(level_issues, 1):
                lines.append(f"#### {i}. [{issue.criterion.id}] {issue.message}")
                lines.append("")
                
                if issue.selector:
                    lines.append(f"**Selector:** `{issue.selector}`")
                    lines.append("")
                
                if issue.line:
                    lines.append(f"**Line:** {issue.line}")
                    lines.append("")
                
                if issue.context:
                    lines.append("**Context:**")
                    lines.append("```html")
                    lines.append(issue.context)
                    lines.append("```")
                    lines.append("")
                
                if issue.recommendation:
                    lines.append(f"**Fix:** {issue.recommendation}")
                    lines.append("")
                
                if issue.techniques:
                    techniques = ', '.join(
                        f"[{t}](https://www.w3.org/WAI/WCAG22/Techniques/{t[:1]}/{t})"
                        for t in issue.techniques
                    )
                    lines.append(f"**Techniques:** {techniques}")
                    lines.append("")
        
        return "\n".join(lines)
    
    def save(self, filepath: str, format: ReportFormat = ReportFormat.HTML) -> None:
        """
        Save report to file.
        
        Args:
            filepath: Output file path.
            format: Report format.
        """
        content = {
            ReportFormat.TEXT: self.to_text,
            ReportFormat.JSON: self.to_json,
            ReportFormat.HTML: self.to_html,
            ReportFormat.MARKDOWN: self.to_markdown,
        }[format]()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ""
        return (
            text
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
            .replace("'", '&#x27;')
        )
    
    def _get_html_styles(self) -> str:
        """Get CSS styles for HTML report."""
        return '''
            * { box-sizing: border-box; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                line-height: 1.6;
                max-width: 1000px;
                margin: 0 auto;
                padding: 20px;
                background: #f5f5f5;
                color: #333;
            }
            main {
                background: white;
                padding: 30px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
            h2 { color: #34495e; margin-top: 30px; }
            h3 { color: #7f8c8d; }
            .meta { color: #7f8c8d; font-size: 0.9em; }
            .stats {
                display: flex;
                gap: 20px;
                margin: 20px 0;
            }
            .stat {
                padding: 15px 25px;
                border-radius: 8px;
                text-align: center;
            }
            .stat.error { background: #fee; border: 1px solid #e74c3c; }
            .stat.warning { background: #fff3e0; border: 1px solid #f39c12; }
            .stat.notice { background: #e3f2fd; border: 1px solid #3498db; }
            .stat .count { display: block; font-size: 2em; font-weight: bold; }
            .stat .label { font-size: 0.9em; text-transform: uppercase; }
            .compliant { color: #27ae60; font-weight: bold; }
            .not-compliant { color: #e74c3c; font-weight: bold; }
            .issue-list { list-style: none; padding: 0; }
            .issue {
                padding: 15px;
                margin: 10px 0;
                border-radius: 6px;
                border-left: 4px solid;
            }
            .issue.error { background: #fee; border-left-color: #e74c3c; }
            .issue.warning { background: #fff3e0; border-left-color: #f39c12; }
            .issue.notice { background: #e3f2fd; border-left-color: #3498db; }
            .criterion {
                background: #34495e;
                color: white;
                padding: 2px 6px;
                border-radius: 3px;
                font-size: 0.85em;
                margin-right: 8px;
            }
            .message { font-weight: 500; }
            .location { margin-top: 8px; font-size: 0.9em; color: #666; }
            .location code {
                background: #ecf0f1;
                padding: 2px 6px;
                border-radius: 3px;
            }
            .context {
                background: #2c3e50;
                color: #ecf0f1;
                padding: 10px;
                border-radius: 4px;
                overflow-x: auto;
                font-size: 0.85em;
                margin-top: 10px;
            }
            .recommendation, .techniques {
                margin-top: 8px;
                font-size: 0.9em;
            }
            .techniques a { color: #3498db; }
        '''
