"""
Base classes for WCAG checks.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Type
from bs4 import BeautifulSoup, Tag

from wcag_checker.models import Issue, WCAGCriterion, CheckResult


class BaseCheck(ABC):
    """Base class for all WCAG checks."""
    
    # The criterion this check verifies
    criterion: WCAGCriterion
    
    # Description of what this check does
    description: str = ""
    
    def __init__(self, soup: BeautifulSoup, html: str):
        """
        Initialize the check.
        
        Args:
            soup: Parsed BeautifulSoup object
            html: Original HTML source
        """
        self.soup = soup
        self.html = html
        self.issues: List[Issue] = []
    
    @abstractmethod
    def check(self) -> List[Issue]:
        """
        Run the check and return any issues found.
        
        Returns:
            List of Issue objects found during the check
        """
        pass
    
    def get_element_selector(self, element: Tag) -> str:
        """Generate a CSS selector for an element."""
        if element is None:
            return ""
        
        parts = []
        current = element
        
        while current and current.name:
            selector = current.name
            
            # Add ID if present
            if current.get('id'):
                selector += f"#{current['id']}"
                parts.insert(0, selector)
                break
            
            # Add classes if present
            classes = current.get('class', [])
            if classes:
                if isinstance(classes, list):
                    selector += '.' + '.'.join(classes[:2])  # Limit to 2 classes
                else:
                    selector += f'.{classes}'
            
            # Add nth-child if needed for disambiguation
            if current.parent:
                siblings = [s for s in current.parent.children 
                           if isinstance(s, Tag) and s.name == current.name]
                if len(siblings) > 1:
                    index = siblings.index(current) + 1
                    selector += f":nth-of-type({index})"
            
            parts.insert(0, selector)
            current = current.parent
            
            # Limit depth
            if len(parts) >= 5:
                break
        
        return ' > '.join(parts)
    
    def get_element_context(self, element: Tag, max_length: int = 200) -> str:
        """Get the HTML context around an element."""
        if element is None:
            return ""
        
        html_str = str(element)
        if len(html_str) > max_length:
            return html_str[:max_length] + "..."
        return html_str
    
    def get_element_line(self, element: Tag) -> Optional[int]:
        """Get the line number of an element in the source."""
        if element is None or not hasattr(element, 'sourceline'):
            return None
        return element.sourceline
    
    def get_element_column(self, element: Tag) -> Optional[int]:
        """Get the column number of an element in the source."""
        if element is None or not hasattr(element, 'sourcepos'):
            return None
        return element.sourcepos


class CheckRegistry:
    """Registry of all available checks."""
    
    _checks: List[Type[BaseCheck]] = []
    
    @classmethod
    def register(cls, check_class: Type[BaseCheck]) -> Type[BaseCheck]:
        """Decorator to register a check class."""
        cls._checks.append(check_class)
        return check_class
    
    @classmethod
    def get_checks(cls) -> List[Type[BaseCheck]]:
        """Get all registered checks."""
        return cls._checks.copy()
    
    @classmethod
    def get_checks_for_criterion(cls, criterion_id: str) -> List[Type[BaseCheck]]:
        """Get checks for a specific criterion."""
        return [c for c in cls._checks if c.criterion.id == criterion_id]
    
    @classmethod
    def clear(cls):
        """Clear all registered checks (for testing)."""
        cls._checks = []


def register_check(check_class: Type[BaseCheck]) -> Type[BaseCheck]:
    """Decorator to register a check."""
    return CheckRegistry.register(check_class)
