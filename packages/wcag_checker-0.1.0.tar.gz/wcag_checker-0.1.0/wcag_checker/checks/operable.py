"""
WCAG Principle 2: Operable checks.

User interface components and navigation must be operable.
"""

from typing import List
from bs4 import Tag

from wcag_checker.models import Issue, IssueLevel
from wcag_checker.checks.base import BaseCheck, register_check
from wcag_checker.criteria import (
    SC_2_1_1, SC_2_1_2, SC_2_1_4, SC_2_2_1, SC_2_2_2, SC_2_3_1,
    SC_2_4_1, SC_2_4_2, SC_2_4_3, SC_2_4_4, SC_2_4_6, SC_2_4_7,
    SC_2_4_11, SC_2_5_1, SC_2_5_2, SC_2_5_3, SC_2_5_7, SC_2_5_8
)
from wcag_checker.utils import (
    get_accessible_name, is_hidden, is_focusable, is_interactive,
    get_text_content
)


# =============================================================================
# 2.1.1 Keyboard Accessible
# =============================================================================

@register_check
class KeyboardAccessibleCheck(BaseCheck):
    """Check that interactive elements are keyboard accessible."""
    
    criterion = SC_2_1_1
    description = "All functionality must be keyboard accessible"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for elements with click handlers that aren't focusable
        for elem in self.soup.find_all(True):
            if is_hidden(elem):
                continue
            
            # Check for onclick without being focusable
            onclick = elem.get('onclick')
            has_click_handler = onclick is not None
            
            # Also check for other click-related attributes
            for attr in elem.attrs:
                if attr in ('onclick', 'onmousedown', 'onmouseup', 'ondblclick'):
                    has_click_handler = True
                    break
            
            if has_click_handler and not is_focusable(elem):
                # Elements that are naturally interactive don't need this warning
                if elem.name not in ('a', 'button', 'input', 'select', 'textarea', 'area'):
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message=f"Element with click handler is not keyboard accessible",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Add tabindex='0' and keyboard event handlers (onkeydown/onkeyup)",
                        techniques=["SCR20", "SCR35", "G90"]
                    ))
        
        # Check for divs/spans used as buttons without proper roles
        for elem in self.soup.find_all(['div', 'span']):
            if is_hidden(elem):
                continue
            
            role = elem.get('role', '').lower()
            tabindex = elem.get('tabindex')
            
            # If it has tabindex and looks interactive
            if tabindex is not None and tabindex != '-1':
                if role not in ('button', 'link', 'checkbox', 'radio', 'menuitem', 
                               'tab', 'switch', 'option', 'treeitem'):
                    # Check if it has click handlers
                    if elem.get('onclick') or any(a.startswith('on') for a in elem.attrs):
                        issues.append(Issue(
                            criterion=self.criterion,
                            level=IssueLevel.WARNING,
                            message="Interactive element may need appropriate ARIA role",
                            element=str(elem)[:200],
                            selector=self.get_element_selector(elem),
                            line=self.get_element_line(elem),
                            context=self.get_element_context(elem),
                            recommendation="Add appropriate role (e.g., role='button') for custom interactive elements",
                            techniques=["ARIA4"]
                        ))
        
        return issues


@register_check
class AccessKeyCheck(BaseCheck):
    """Check accesskey attributes for potential conflicts."""
    
    criterion = SC_2_1_4
    description = "Character key shortcuts should be configurable"
    
    def check(self) -> List[Issue]:
        issues = []
        
        accesskeys = {}
        for elem in self.soup.find_all(True):
            if is_hidden(elem):
                continue
            
            accesskey = elem.get('accesskey')
            if accesskey:
                key = accesskey.lower()
                if key in accesskeys:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message=f"Duplicate accesskey '{accesskey}' found",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Use unique accesskey values or remove duplicates",
                        techniques=["G202"]
                    ))
                else:
                    accesskeys[key] = elem
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.NOTICE,
                        message=f"accesskey attribute used ('{accesskey}')",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Ensure users can disable or remap character key shortcuts",
                        techniques=["G217"]
                    ))
        
        return issues


# =============================================================================
# 2.2.1 Timing Adjustable & 2.2.2 Pause, Stop, Hide
# =============================================================================

@register_check
class MetaRefreshCheck(BaseCheck):
    """Check for meta refresh that could cause timing issues."""
    
    criterion = SC_2_2_1
    description = "Users should be able to control time limits"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for meta in self.soup.find_all('meta', {'http-equiv': 'refresh'}):
            content = meta.get('content', '')
            
            # Parse refresh time
            if ';' in content:
                time_part = content.split(';')[0].strip()
            else:
                time_part = content.strip()
            
            try:
                refresh_time = int(time_part)
                
                if refresh_time == 0:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message="Immediate page redirect using meta refresh",
                        element=str(meta),
                        selector=self.get_element_selector(meta),
                        line=self.get_element_line(meta),
                        context=self.get_element_context(meta),
                        recommendation="Use server-side redirects (HTTP 301/302) instead",
                        techniques=["SVR1"]
                    ))
                else:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message=f"Page will auto-refresh in {refresh_time} seconds",
                        element=str(meta),
                        selector=self.get_element_selector(meta),
                        line=self.get_element_line(meta),
                        context=self.get_element_context(meta),
                        recommendation="Remove auto-refresh or provide user control over timing",
                        techniques=["G198"]
                    ))
            except ValueError:
                pass
        
        return issues


@register_check
class BlinkMarqueeCheck(BaseCheck):
    """Check for blink and marquee elements."""
    
    criterion = SC_2_2_2
    description = "Moving content should be able to be paused"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for blink element (deprecated but might still be used)
        for blink in self.soup.find_all('blink'):
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.ERROR,
                message="Blink element causes content to flash/blink",
                element=str(blink),
                selector=self.get_element_selector(blink),
                line=self.get_element_line(blink),
                context=self.get_element_context(blink),
                recommendation="Remove blink element entirely",
                techniques=["G11"]
            ))
        
        # Check for marquee element
        for marquee in self.soup.find_all('marquee'):
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.ERROR,
                message="Marquee element creates moving content without pause control",
                element=str(marquee),
                selector=self.get_element_selector(marquee),
                line=self.get_element_line(marquee),
                context=self.get_element_context(marquee),
                recommendation="Remove marquee or replace with pausable CSS animation",
                techniques=["G11", "G187"]
            ))
        
        return issues


# =============================================================================
# 2.3.1 Three Flashes or Below Threshold
# =============================================================================

@register_check
class AnimationGifCheck(BaseCheck):
    """Check for animated GIFs that might cause seizures."""
    
    criterion = SC_2_3_1
    description = "Content should not flash more than 3 times per second"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for img in self.soup.find_all('img'):
            if is_hidden(img):
                continue
            
            src = img.get('src', '')
            if src.lower().endswith('.gif'):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.NOTICE,
                    message="GIF image found - verify it does not flash more than 3 times/second",
                    element=str(img),
                    selector=self.get_element_selector(img),
                    line=self.get_element_line(img),
                    context=self.get_element_context(img),
                    recommendation="Ensure animated GIFs don't flash rapidly or provide controls to stop animation",
                    techniques=["G15", "G19"]
                ))
        
        return issues


# =============================================================================
# 2.4.1 Bypass Blocks
# =============================================================================

@register_check
class SkipLinkCheck(BaseCheck):
    """Check for skip navigation links."""
    
    criterion = SC_2_4_1
    description = "A mechanism should exist to bypass repeated content"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for skip links
        skip_patterns = ['skip', 'jump', 'bypass', 'main content', 'maincontent']
        has_skip_link = False
        
        for a in self.soup.find_all('a'):
            href = a.get('href', '')
            text = get_text_content(a).lower()
            
            # Check if it's a skip link
            if href.startswith('#'):
                for pattern in skip_patterns:
                    if pattern in text:
                        has_skip_link = True
                        break
        
        # Check for landmark regions as alternative
        main = self.soup.find('main') or self.soup.find(role='main')
        nav = self.soup.find('nav') or self.soup.find(role='navigation')
        header = self.soup.find('header') or self.soup.find(role='banner')
        
        has_landmarks = main is not None
        
        if not has_skip_link and not has_landmarks:
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.WARNING,
                message="No skip link or main landmark found",
                recommendation="Add a 'Skip to main content' link or use <main> element",
                techniques=["G1", "ARIA11"]
            ))
        
        return issues


@register_check
class LandmarkRegionsCheck(BaseCheck):
    """Check for proper use of landmark regions."""
    
    criterion = SC_2_4_1
    description = "Content should be organized using landmark regions"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for main landmark
        main = self.soup.find('main') or self.soup.find(role='main')
        if not main:
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.WARNING,
                message="No main content region found",
                recommendation="Add <main> element or role='main' to identify main content",
                techniques=["ARIA11"]
            ))
        
        # Check for multiple mains
        mains = self.soup.find_all('main')
        mains += self.soup.find_all(role='main')
        if len(mains) > 1:
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.ERROR,
                message=f"Multiple main landmarks found ({len(mains)})",
                recommendation="Page should have only one main landmark",
                techniques=["ARIA11"]
            ))
        
        return issues


# =============================================================================
# 2.4.2 Page Titled
# =============================================================================

@register_check
class PageTitleCheck(BaseCheck):
    """Check that page has a descriptive title."""
    
    criterion = SC_2_4_2
    description = "Pages must have descriptive titles"
    
    def check(self) -> List[Issue]:
        issues = []
        
        title = self.soup.find('title')
        
        if not title:
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.ERROR,
                message="Page has no title element",
                recommendation="Add a <title> element in the <head> section",
                techniques=["H25", "G88"]
            ))
        elif not title.string or not title.string.strip():
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.ERROR,
                message="Page title is empty",
                element=str(title),
                selector="head > title",
                context=self.get_element_context(title),
                recommendation="Add descriptive text to the title element",
                techniques=["H25", "G88"]
            ))
        else:
            title_text = title.string.strip()
            # Check for suspicious titles
            suspicious = ['untitled', 'document', 'new page', 'home', 'index']
            if title_text.lower() in suspicious:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message=f"Page title may not be descriptive: '{title_text}'",
                    element=str(title),
                    selector="head > title",
                    context=self.get_element_context(title),
                    recommendation="Use a title that describes the page topic or purpose",
                    techniques=["H25", "G88"]
                ))
        
        return issues


# =============================================================================
# 2.4.4 Link Purpose (In Context)
# =============================================================================

@register_check
class LinkPurposeCheck(BaseCheck):
    """Check that link purposes are clear."""
    
    criterion = SC_2_4_4
    description = "Link purpose should be determinable from link text or context"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Ambiguous link texts
        ambiguous_texts = {
            'click here', 'here', 'more', 'read more', 'learn more',
            'click', 'link', 'this', 'continue', 'go', 'details'
        }
        
        for a in self.soup.find_all('a'):
            if is_hidden(a):
                continue
            
            href = a.get('href')
            if not href or href == '#':
                continue
            
            accessible_name = get_accessible_name(a)
            text = get_text_content(a).strip().lower()
            
            # Check for empty links
            if not accessible_name:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Link has no accessible text",
                    element=str(a),
                    selector=self.get_element_selector(a),
                    line=self.get_element_line(a),
                    context=self.get_element_context(a),
                    recommendation="Add link text, aria-label, or aria-labelledby",
                    techniques=["H30", "ARIA8"]
                ))
            # Check for ambiguous texts
            elif text in ambiguous_texts:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message=f"Link text '{text}' may be ambiguous",
                    element=str(a),
                    selector=self.get_element_selector(a),
                    line=self.get_element_line(a),
                    context=self.get_element_context(a),
                    recommendation="Use descriptive link text that indicates the destination or action",
                    techniques=["H30", "G91"]
                ))
            # Check for links that are just URLs
            elif text.startswith('http://') or text.startswith('https://'):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message="Link text is a URL",
                    element=str(a),
                    selector=self.get_element_selector(a),
                    line=self.get_element_line(a),
                    context=self.get_element_context(a),
                    recommendation="Replace URL with descriptive link text",
                    techniques=["H30"]
                ))
        
        return issues


# =============================================================================
# 2.4.6 Headings and Labels
# =============================================================================

@register_check
class DescriptiveHeadingsCheck(BaseCheck):
    """Check that headings and labels are descriptive."""
    
    criterion = SC_2_4_6
    description = "Headings and labels should describe topic or purpose"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check headings
        for heading in self.soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
            if is_hidden(heading):
                continue
            
            text = get_text_content(heading).strip()
            
            # Very short headings might not be descriptive
            if len(text) <= 2 and text not in ('OK', 'No', 'Go'):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message=f"Heading may not be descriptive: '{text}'",
                    element=str(heading),
                    selector=self.get_element_selector(heading),
                    line=self.get_element_line(heading),
                    context=self.get_element_context(heading),
                    recommendation="Use descriptive heading text that indicates the content",
                    techniques=["G130"]
                ))
        
        # Check labels
        for label in self.soup.find_all('label'):
            if is_hidden(label):
                continue
            
            text = get_text_content(label).strip()
            
            if not text:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Label element is empty",
                    element=str(label),
                    selector=self.get_element_selector(label),
                    line=self.get_element_line(label),
                    context=self.get_element_context(label),
                    recommendation="Add descriptive text to the label",
                    techniques=["G131"]
                ))
        
        return issues


# =============================================================================
# 2.4.7 Focus Visible
# =============================================================================

@register_check
class FocusVisibleCheck(BaseCheck):
    """Check for potential focus visibility issues."""
    
    criterion = SC_2_4_7
    description = "Keyboard focus indicator must be visible"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for outline:none in style attributes
        for elem in self.soup.find_all(True):
            if is_hidden(elem):
                continue
            
            style = elem.get('style', '')
            
            if 'outline:none' in style.replace(' ', '') or 'outline:0' in style.replace(' ', '') or \
               'outline: none' in style or 'outline: 0' in style:
                if is_focusable(elem):
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message="Focus outline removed on focusable element",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Provide an alternative visible focus indicator if removing default outline",
                        techniques=["C15", "G149", "G195"]
                    ))
        
        return issues


# =============================================================================
# 2.5.3 Label in Name
# =============================================================================

@register_check
class LabelInNameCheck(BaseCheck):
    """Check that visible labels are included in accessible names."""
    
    criterion = SC_2_5_3
    description = "Accessible name should contain visible label text"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for elem in self.soup.find_all(['button', 'a', 'input', 'select', 'textarea']):
            if is_hidden(elem):
                continue
            
            # Get visible text
            visible_text = get_text_content(elem).strip().lower()
            
            # Get accessible name (including aria-label)
            accessible_name = get_accessible_name(elem).lower()
            
            # If there's an aria-label that doesn't contain the visible text
            aria_label = elem.get('aria-label', '').lower()
            if aria_label and visible_text and visible_text not in aria_label:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message=f"Visible label '{visible_text}' not included in accessible name '{aria_label}'",
                    element=str(elem)[:200],
                    selector=self.get_element_selector(elem),
                    line=self.get_element_line(elem),
                    context=self.get_element_context(elem),
                    recommendation="Ensure aria-label includes the visible label text",
                    techniques=["G208"]
                ))
        
        return issues


# =============================================================================
# 2.5.7 Dragging Movements (WCAG 2.2)
# =============================================================================

@register_check
class DraggableCheck(BaseCheck):
    """Check for elements that require dragging."""
    
    criterion = SC_2_5_7
    description = "Dragging functionality should have single-pointer alternatives"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for elem in self.soup.find_all(True):
            if is_hidden(elem):
                continue
            
            # Check for draggable attribute
            if elem.get('draggable') == 'true':
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.NOTICE,
                    message="Element has draggable='true' - ensure alternative input method exists",
                    element=str(elem)[:200],
                    selector=self.get_element_selector(elem),
                    line=self.get_element_line(elem),
                    context=self.get_element_context(elem),
                    recommendation="Provide single-pointer alternative for drag functionality (e.g., buttons to move items)",
                    techniques=["G219"]
                ))
            
            # Check for drag event handlers
            drag_handlers = ['ondrag', 'ondragstart', 'ondragend', 'ondragover', 'ondrop']
            for handler in drag_handlers:
                if elem.get(handler):
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message=f"Element has {handler} handler - ensure drag operation has alternative",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Provide single-pointer alternative (buttons, menus) for drag operations",
                        techniques=["G219"]
                    ))
                    break
        
        return issues


# =============================================================================
# 2.5.8 Target Size (Minimum) (WCAG 2.2)
# =============================================================================

@register_check
class TargetSizeCheck(BaseCheck):
    """Check for potentially undersized touch targets."""
    
    criterion = SC_2_5_8
    description = "Touch targets should be at least 24x24 CSS pixels"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check inline links that might be too small
        for p in self.soup.find_all(['p', 'li', 'td', 'span']):
            links = p.find_all('a')
            for link in links:
                if is_hidden(link):
                    continue
                
                # Check if link text is very short
                text = get_text_content(link).strip()
                if len(text) <= 2 and text.isalnum():
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.NOTICE,
                        message=f"Short inline link '{text}' may have insufficient target size",
                        element=str(link),
                        selector=self.get_element_selector(link),
                        line=self.get_element_line(link),
                        context=self.get_element_context(link),
                        recommendation="Ensure touch target is at least 24x24 CSS pixels",
                        techniques=["C42"]
                    ))
        
        # Check icon-only buttons
        for button in self.soup.find_all(['button', 'a']):
            if is_hidden(button):
                continue
            
            # Check for icon-only (has class suggesting icon but no text)
            classes = button.get('class', [])
            if isinstance(classes, list):
                classes = ' '.join(classes)
            
            text = get_text_content(button).strip()
            has_icon_class = any(word in classes.lower() for word in ['icon', 'btn-icon', 'fa-', 'glyphicon', 'material-icons'])
            
            if has_icon_class and not text:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.NOTICE,
                    message="Icon-only button should have minimum 24x24 CSS pixel target size",
                    element=str(button)[:200],
                    selector=self.get_element_selector(button),
                    line=self.get_element_line(button),
                    context=self.get_element_context(button),
                    recommendation="Ensure touch target is at least 24x24 CSS pixels, or provide spacing",
                    techniques=["C42"]
                ))
        
        return issues
