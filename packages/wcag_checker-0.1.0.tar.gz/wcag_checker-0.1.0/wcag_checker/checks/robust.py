"""
WCAG Principle 4: Robust checks.

Content must be robust enough to be interpreted by a variety of
user agents, including assistive technologies.
"""

from typing import List, Set, Dict
import re
from bs4 import Tag

from wcag_checker.models import Issue, IssueLevel
from wcag_checker.checks.base import BaseCheck, register_check
from wcag_checker.criteria import SC_4_1_1, SC_4_1_2, SC_4_1_3
from wcag_checker.utils import (
    get_accessible_name, is_hidden, get_text_content, is_interactive
)


# =============================================================================
# 4.1.1 Parsing (Obsolete in WCAG 2.2 but still useful)
# =============================================================================

@register_check
class DuplicateIdCheck(BaseCheck):
    """Check for duplicate ID attributes."""
    
    criterion = SC_4_1_1
    description = "IDs must be unique within a document"
    
    def check(self) -> List[Issue]:
        issues = []
        
        seen_ids: Dict[str, Tag] = {}
        
        for elem in self.soup.find_all(True):
            elem_id = elem.get('id')
            
            if elem_id:
                if elem_id in seen_ids:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message=f"Duplicate ID: '{elem_id}'",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Ensure all ID values are unique",
                        techniques=["H93"]
                    ))
                else:
                    seen_ids[elem_id] = elem
        
        return issues


@register_check
class InvalidAttributeCheck(BaseCheck):
    """Check for common invalid HTML patterns."""
    
    criterion = SC_4_1_1
    description = "HTML should follow specification"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for duplicate attributes (BeautifulSoup already handles this,
        # but we can check the raw HTML)
        # This is a simplified check
        
        # Check for common invalid nesting
        invalid_nesting = [
            ('a', 'a'),  # Links within links
            ('button', 'a'),  # Links in buttons
            ('button', 'button'),  # Buttons in buttons
            ('a', 'button'),  # Buttons in links
            ('p', 'div'),  # Block elements in p
            ('p', 'p'),  # Paragraphs in paragraphs
        ]
        
        for parent_tag, child_tag in invalid_nesting:
            for parent in self.soup.find_all(parent_tag):
                if is_hidden(parent):
                    continue
                
                children = parent.find_all(child_tag)
                for child in children:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message=f"Invalid nesting: <{child_tag}> inside <{parent_tag}>",
                        element=str(child)[:200],
                        selector=self.get_element_selector(child),
                        line=self.get_element_line(child),
                        context=self.get_element_context(parent),
                        recommendation=f"Move the <{child_tag}> element outside of <{parent_tag}>",
                        techniques=["H74"]
                    ))
        
        return issues


# =============================================================================
# 4.1.2 Name, Role, Value
# =============================================================================

@register_check
class ButtonNameCheck(BaseCheck):
    """Check that buttons have accessible names."""
    
    criterion = SC_4_1_2
    description = "Buttons must have accessible names"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for button in self.soup.find_all('button'):
            if is_hidden(button):
                continue
            
            name = get_accessible_name(button)
            
            if not name:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Button has no accessible name",
                    element=str(button)[:200],
                    selector=self.get_element_selector(button),
                    line=self.get_element_line(button),
                    context=self.get_element_context(button),
                    recommendation="Add text content, aria-label, or aria-labelledby",
                    techniques=["ARIA14", "G108"]
                ))
        
        # Check input buttons
        for inp in self.soup.find_all('input', {'type': ['button', 'submit', 'reset']}):
            if is_hidden(inp):
                continue
            
            value = inp.get('value')
            aria_label = inp.get('aria-label')
            
            if not value and not aria_label:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message=f"Input type='{inp.get('type')}' has no accessible name",
                    element=str(inp),
                    selector=self.get_element_selector(inp),
                    line=self.get_element_line(inp),
                    context=self.get_element_context(inp),
                    recommendation="Add value attribute or aria-label",
                    techniques=["H91", "G108"]
                ))
        
        return issues


@register_check
class IframeNameCheck(BaseCheck):
    """Check that iframes have accessible names."""
    
    criterion = SC_4_1_2
    description = "Iframes must have accessible names"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for iframe in self.soup.find_all(['iframe', 'frame']):
            if is_hidden(iframe):
                continue
            
            title = iframe.get('title')
            aria_label = iframe.get('aria-label')
            aria_labelledby = iframe.get('aria-labelledby')
            
            if not title and not aria_label and not aria_labelledby:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Iframe has no accessible name",
                    element=str(iframe)[:200],
                    selector=self.get_element_selector(iframe),
                    line=self.get_element_line(iframe),
                    context=self.get_element_context(iframe),
                    recommendation="Add title attribute describing the iframe content",
                    techniques=["H64"]
                ))
            elif title and not title.strip():
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Iframe has empty title attribute",
                    element=str(iframe)[:200],
                    selector=self.get_element_selector(iframe),
                    line=self.get_element_line(iframe),
                    context=self.get_element_context(iframe),
                    recommendation="Add descriptive text to the title attribute",
                    techniques=["H64"]
                ))
        
        return issues


@register_check
class AriaRoleCheck(BaseCheck):
    """Check for valid ARIA roles and required properties."""
    
    criterion = SC_4_1_2
    description = "ARIA roles must be valid and have required properties"
    
    # Valid ARIA roles
    VALID_ROLES = {
        # Widget roles
        'alert', 'alertdialog', 'button', 'checkbox', 'dialog', 'gridcell',
        'link', 'log', 'marquee', 'menuitem', 'menuitemcheckbox', 'menuitemradio',
        'option', 'progressbar', 'radio', 'scrollbar', 'searchbox', 'slider',
        'spinbutton', 'status', 'switch', 'tab', 'tabpanel', 'textbox', 'timer',
        'tooltip', 'treeitem',
        # Composite roles
        'combobox', 'grid', 'listbox', 'menu', 'menubar', 'radiogroup', 'tablist',
        'tree', 'treegrid',
        # Document structure roles
        'application', 'article', 'cell', 'columnheader', 'definition', 'directory',
        'document', 'feed', 'figure', 'group', 'heading', 'img', 'list', 'listitem',
        'math', 'none', 'note', 'presentation', 'row', 'rowgroup', 'rowheader',
        'separator', 'table', 'term', 'toolbar',
        # Landmark roles
        'banner', 'complementary', 'contentinfo', 'form', 'main', 'navigation',
        'region', 'search',
        # Live region roles
        'alert', 'log', 'marquee', 'status', 'timer',
        # Window roles
        'alertdialog', 'dialog',
    }
    
    # Required properties for certain roles
    REQUIRED_PROPERTIES = {
        'checkbox': ['aria-checked'],
        'combobox': ['aria-expanded'],
        'heading': ['aria-level'],
        'meter': ['aria-valuenow'],
        'option': [],  # Must be owned by listbox
        'radio': ['aria-checked'],
        'scrollbar': ['aria-valuenow', 'aria-controls', 'aria-orientation'],
        'separator': [],  # aria-valuenow required if focusable
        'slider': ['aria-valuenow'],
        'spinbutton': ['aria-valuenow'],
        'switch': ['aria-checked'],
    }
    
    def check(self) -> List[Issue]:
        issues = []
        
        for elem in self.soup.find_all(True):
            if is_hidden(elem):
                continue
            
            role = elem.get('role')
            
            if role:
                # Handle multiple roles (use first)
                roles = role.strip().split()
                primary_role = roles[0].lower()
                
                # Check if role is valid
                if primary_role not in self.VALID_ROLES:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message=f"Invalid ARIA role: '{primary_role}'",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Use a valid ARIA role from the specification",
                        techniques=["ARIA4"]
                    ))
                # Check required properties
                elif primary_role in self.REQUIRED_PROPERTIES:
                    for prop in self.REQUIRED_PROPERTIES[primary_role]:
                        if not elem.has_attr(prop):
                            issues.append(Issue(
                                criterion=self.criterion,
                                level=IssueLevel.ERROR,
                                message=f"Role '{primary_role}' missing required property: {prop}",
                                element=str(elem)[:200],
                                selector=self.get_element_selector(elem),
                                line=self.get_element_line(elem),
                                context=self.get_element_context(elem),
                                recommendation=f"Add {prop} attribute to element with role='{primary_role}'",
                                techniques=["ARIA5"]
                            ))
        
        return issues


@register_check
class AriaHiddenFocusableCheck(BaseCheck):
    """Check for focusable elements with aria-hidden."""
    
    criterion = SC_4_1_2
    description = "Focusable elements should not have aria-hidden='true'"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for elem in self.soup.find_all(True):
            aria_hidden = elem.get('aria-hidden')
            
            if aria_hidden == 'true':
                # Check if element or descendants are focusable
                focusable_elements = []
                
                # Check the element itself
                if elem.get('tabindex') is not None and elem.get('tabindex') != '-1':
                    focusable_elements.append(elem)
                
                # Check descendants
                for child in elem.find_all(['a', 'button', 'input', 'select', 'textarea', 'area']):
                    if child.get('tabindex') != '-1':
                        focusable_elements.append(child)
                
                for child in elem.find_all(True):
                    tabindex = child.get('tabindex')
                    if tabindex is not None and tabindex != '-1':
                        if child not in focusable_elements:
                            focusable_elements.append(child)
                
                for focusable in focusable_elements:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message="Focusable element within aria-hidden='true' region",
                        element=str(focusable)[:200],
                        selector=self.get_element_selector(focusable),
                        line=self.get_element_line(focusable),
                        context=self.get_element_context(focusable),
                        recommendation="Remove aria-hidden='true' from ancestor or add tabindex='-1' to focusable elements",
                        techniques=["ARIA12"]
                    ))
        
        return issues


@register_check
class FormControlNameCheck(BaseCheck):
    """Check that form controls have accessible names."""
    
    criterion = SC_4_1_2
    description = "Form controls must have accessible names"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for select in self.soup.find_all('select'):
            if is_hidden(select):
                continue
            
            name = get_accessible_name(select)
            
            if not name:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Select element has no accessible name",
                    element=str(select)[:200],
                    selector=self.get_element_selector(select),
                    line=self.get_element_line(select),
                    context=self.get_element_context(select),
                    recommendation="Add <label>, aria-label, or aria-labelledby",
                    techniques=["H91", "ARIA16"]
                ))
        
        return issues


# =============================================================================
# 4.1.3 Status Messages
# =============================================================================

@register_check
class LiveRegionCheck(BaseCheck):
    """Check that status messages use appropriate ARIA live regions."""
    
    criterion = SC_4_1_3
    description = "Status messages should use ARIA live regions"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Look for elements that might be status messages
        status_patterns = ['alert', 'error', 'warning', 'success', 'info', 'message', 
                         'notification', 'toast', 'status', 'feedback']
        
        for elem in self.soup.find_all(True):
            if is_hidden(elem):
                continue
            
            classes = elem.get('class', [])
            if isinstance(classes, list):
                classes = ' '.join(classes)
            classes = classes.lower()
            
            elem_id = (elem.get('id') or '').lower()
            
            # Check if this looks like a status/alert element
            is_potential_status = any(pattern in classes or pattern in elem_id 
                                     for pattern in status_patterns)
            
            if is_potential_status:
                role = elem.get('role', '').lower()
                aria_live = elem.get('aria-live')
                
                valid_status_roles = ['alert', 'status', 'log', 'progressbar']
                
                if role not in valid_status_roles and not aria_live:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message="Element appears to be status message but lacks ARIA live region",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Add role='alert', role='status', or aria-live attribute",
                        techniques=["ARIA22", "ARIA19"]
                    ))
        
        # Check for properly configured live regions
        for elem in self.soup.find_all(True):
            role = elem.get('role', '').lower()
            
            if role == 'alert' or elem.name == 'output':
                # Alert is good - it's assertive by default
                pass
            elif role == 'status':
                # Status is good - it's polite by default
                pass
        
        return issues


@register_check
class OutputElementCheck(BaseCheck):
    """Check that output elements are properly used."""
    
    criterion = SC_4_1_3
    description = "Output elements should be used for calculation results"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for output in self.soup.find_all('output'):
            if is_hidden(output):
                continue
            
            # Check for for attribute (links to inputs)
            for_attr = output.get('for')
            form_attr = output.get('form')
            
            if not for_attr and not form_attr:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.NOTICE,
                    message="Output element should be associated with form inputs",
                    element=str(output)[:200],
                    selector=self.get_element_selector(output),
                    line=self.get_element_line(output),
                    context=self.get_element_context(output),
                    recommendation="Add 'for' attribute referencing input IDs",
                    techniques=["ARIA19"]
                ))
        
        return issues
