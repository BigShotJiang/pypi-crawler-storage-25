"""
WCAG Principle 3: Understandable checks.

Information and the operation of user interface must be understandable.
"""

from typing import List
from bs4 import Tag

from wcag_checker.models import Issue, IssueLevel
from wcag_checker.checks.base import BaseCheck, register_check
from wcag_checker.criteria import (
    SC_3_1_1, SC_3_1_2, SC_3_2_1, SC_3_2_2, SC_3_2_6,
    SC_3_3_1, SC_3_3_2, SC_3_3_7
)
from wcag_checker.utils import (
    get_accessible_name, is_hidden, get_text_content,
    has_valid_language_code
)


# =============================================================================
# 3.1.1 Language of Page
# =============================================================================

@register_check
class PageLanguageCheck(BaseCheck):
    """Check that page has valid language declaration."""
    
    criterion = SC_3_1_1
    description = "Page must have a language attribute"
    
    def check(self) -> List[Issue]:
        issues = []
        
        html = self.soup.find('html')
        
        if html:
            lang = html.get('lang') or html.get('xml:lang')
            
            if not lang:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="HTML element missing lang attribute",
                    element=f"<html {' '.join(f'{k}=\"{v}\"' for k,v in list(html.attrs.items())[:3])}...>",
                    selector="html",
                    recommendation="Add lang attribute to the html element (e.g., lang='en')",
                    techniques=["H57"]
                ))
            elif not has_valid_language_code(lang):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message=f"Invalid language code: '{lang}'",
                    element=f"<html lang=\"{lang}\">",
                    selector="html",
                    recommendation="Use a valid BCP 47 language tag (e.g., 'en', 'en-US', 'fr')",
                    techniques=["H57"]
                ))
        else:
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.ERROR,
                message="No HTML element found",
                recommendation="Ensure document has proper HTML structure",
                techniques=["H57"]
            ))
        
        return issues


# =============================================================================
# 3.1.2 Language of Parts
# =============================================================================

@register_check
class LanguageOfPartsCheck(BaseCheck):
    """Check that language changes are properly marked."""
    
    criterion = SC_3_1_2
    description = "Language changes within content should be identified"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for lang attributes with invalid values
        for elem in self.soup.find_all(True):
            if is_hidden(elem):
                continue
            
            lang = elem.get('lang')
            if lang and not has_valid_language_code(lang):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message=f"Invalid language code on element: '{lang}'",
                    element=str(elem)[:200],
                    selector=self.get_element_selector(elem),
                    line=self.get_element_line(elem),
                    context=self.get_element_context(elem),
                    recommendation="Use a valid BCP 47 language tag",
                    techniques=["H58"]
                ))
        
        return issues


# =============================================================================
# 3.2.1 On Focus
# =============================================================================

@register_check
class OnFocusChangeCheck(BaseCheck):
    """Check for context changes on focus."""
    
    criterion = SC_3_2_1
    description = "Focus should not trigger context changes"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for elem in self.soup.find_all(True):
            if is_hidden(elem):
                continue
            
            onfocus = elem.get('onfocus', '')
            
            # Check for potentially problematic onfocus handlers
            problematic_patterns = [
                'submit', 'location', 'href', 'window.open',
                'document.location', 'navigate', 'redirect'
            ]
            
            for pattern in problematic_patterns:
                if pattern in onfocus.lower():
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message=f"Element may change context on focus (contains '{pattern}')",
                        element=str(elem)[:200],
                        selector=self.get_element_selector(elem),
                        line=self.get_element_line(elem),
                        context=self.get_element_context(elem),
                        recommendation="Avoid context changes on focus; require user activation",
                        techniques=["G107"]
                    ))
                    break
        
        return issues


# =============================================================================
# 3.2.2 On Input
# =============================================================================

@register_check
class OnInputChangeCheck(BaseCheck):
    """Check for context changes on input."""
    
    criterion = SC_3_2_2
    description = "Input should not trigger unexpected context changes"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check select elements for auto-submit
        for select in self.soup.find_all('select'):
            if is_hidden(select):
                continue
            
            onchange = select.get('onchange', '')
            
            # Check for form submission on change
            if 'submit' in onchange.lower():
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Select element auto-submits form on change",
                    element=str(select)[:200],
                    selector=self.get_element_selector(select),
                    line=self.get_element_line(select),
                    context=self.get_element_context(select),
                    recommendation="Add a submit button instead of auto-submitting on change",
                    techniques=["G80", "H84"]
                ))
            elif any(p in onchange.lower() for p in ['location', 'href', 'navigate', 'redirect', 'window.open']):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Select element triggers navigation on change",
                    element=str(select)[:200],
                    selector=self.get_element_selector(select),
                    line=self.get_element_line(select),
                    context=self.get_element_context(select),
                    recommendation="Add a 'Go' button instead of navigating on change",
                    techniques=["G80", "H84"]
                ))
        
        # Check for input fields that trigger actions
        for inp in self.soup.find_all(['input', 'textarea']):
            if is_hidden(inp):
                continue
            
            onchange = inp.get('onchange', '')
            oninput = inp.get('oninput', '')
            
            for handler in [onchange, oninput]:
                if 'submit' in handler.lower() or 'location' in handler.lower():
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message="Input element may trigger context change on input",
                        element=str(inp)[:200],
                        selector=self.get_element_selector(inp),
                        line=self.get_element_line(inp),
                        context=self.get_element_context(inp),
                        recommendation="Require explicit user action (button press) to change context",
                        techniques=["G80"]
                    ))
                    break
        
        return issues


# =============================================================================
# 3.2.6 Consistent Help (WCAG 2.2)
# =============================================================================

@register_check
class ConsistentHelpCheck(BaseCheck):
    """Check for help mechanisms."""
    
    criterion = SC_3_2_6
    description = "Help mechanisms should be consistently located"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Look for help-related elements
        help_patterns = ['help', 'support', 'contact', 'faq', 'assistance']
        found_help = False
        
        for a in self.soup.find_all('a'):
            if is_hidden(a):
                continue
            
            text = get_text_content(a).lower()
            href = (a.get('href') or '').lower()
            
            for pattern in help_patterns:
                if pattern in text or pattern in href:
                    found_help = True
                    break
        
        # Check for contact information
        for elem in self.soup.find_all(['a', 'address']):
            if is_hidden(elem):
                continue
            
            href = elem.get('href', '')
            if href.startswith('mailto:') or href.startswith('tel:'):
                found_help = True
                break
        
        if not found_help:
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.NOTICE,
                message="No help mechanism found - consider adding help/contact link",
                recommendation="Add consistent help mechanism (contact info, FAQ link, chat) across pages",
                techniques=["G220"]
            ))
        
        return issues


# =============================================================================
# 3.3.1 Error Identification
# =============================================================================

@register_check
class FormErrorCheck(BaseCheck):
    """Check that form errors can be identified."""
    
    criterion = SC_3_3_1
    description = "Input errors should be clearly identified"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for inp in self.soup.find_all(['input', 'select', 'textarea']):
            if is_hidden(inp):
                continue
            
            # Check for aria-invalid without description
            aria_invalid = inp.get('aria-invalid')
            aria_describedby = inp.get('aria-describedby')
            aria_errormessage = inp.get('aria-errormessage')
            
            if aria_invalid == 'true':
                if not aria_describedby and not aria_errormessage:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message="Input marked as invalid but has no error description",
                        element=str(inp)[:200],
                        selector=self.get_element_selector(inp),
                        line=self.get_element_line(inp),
                        context=self.get_element_context(inp),
                        recommendation="Add aria-describedby or aria-errormessage pointing to error text",
                        techniques=["ARIA21"]
                    ))
        
        return issues


# =============================================================================
# 3.3.2 Labels or Instructions
# =============================================================================

@register_check
class InputLabelCheck(BaseCheck):
    """Check that form inputs have labels."""
    
    criterion = SC_3_3_2
    description = "Form inputs must have labels or instructions"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for inp in self.soup.find_all(['input', 'select', 'textarea']):
            if is_hidden(inp):
                continue
            
            # Skip certain input types
            input_type = inp.get('type', 'text')
            if input_type in ('hidden', 'submit', 'button', 'reset', 'image'):
                continue
            
            # Check for associated label
            has_label = False
            
            # Explicit label with for
            input_id = inp.get('id')
            if input_id:
                label = self.soup.find('label', {'for': input_id})
                if label and get_text_content(label).strip():
                    has_label = True
            
            # Implicit label (wrapped)
            if not has_label:
                parent_label = inp.find_parent('label')
                if parent_label and get_text_content(parent_label).strip():
                    has_label = True
            
            # aria-label
            if not has_label and inp.get('aria-label'):
                has_label = True
            
            # aria-labelledby
            if not has_label and inp.get('aria-labelledby'):
                labelledby_ids = inp['aria-labelledby'].split()
                for lid in labelledby_ids:
                    ref = self.soup.find(id=lid)
                    if ref and get_text_content(ref).strip():
                        has_label = True
                        break
            
            # title attribute (last resort)
            if not has_label and inp.get('title'):
                has_label = True
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.NOTICE,
                    message="Input uses title attribute as label - prefer visible label",
                    element=str(inp)[:200],
                    selector=self.get_element_selector(inp),
                    line=self.get_element_line(inp),
                    context=self.get_element_context(inp),
                    recommendation="Use <label> element or aria-label instead of title",
                    techniques=["H44", "H65"]
                ))
            
            # placeholder is not sufficient
            if not has_label:
                if inp.get('placeholder'):
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message="Input uses placeholder as label - placeholder is not accessible label",
                        element=str(inp)[:200],
                        selector=self.get_element_selector(inp),
                        line=self.get_element_line(inp),
                        context=self.get_element_context(inp),
                        recommendation="Add a visible <label> element in addition to placeholder",
                        techniques=["H44"]
                    ))
                else:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message="Input has no accessible label",
                        element=str(inp)[:200],
                        selector=self.get_element_selector(inp),
                        line=self.get_element_line(inp),
                        context=self.get_element_context(inp),
                        recommendation="Add <label for='id'>, aria-label, or wrap input in <label>",
                        techniques=["H44", "H65", "ARIA16"]
                    ))
        
        return issues


# =============================================================================
# 3.3.7 Redundant Entry (WCAG 2.2)
# =============================================================================

@register_check
class RedundantEntryCheck(BaseCheck):
    """Check for potentially redundant form entries."""
    
    criterion = SC_3_3_7
    description = "Don't require users to re-enter previously provided information"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for multiple fields collecting same type of data
        field_types = {}
        
        for inp in self.soup.find_all(['input', 'select', 'textarea']):
            if is_hidden(inp):
                continue
            
            input_type = inp.get('type', 'text')
            if input_type in ('hidden', 'submit', 'button', 'reset', 'checkbox', 'radio'):
                continue
            
            # Identify field purpose
            name = (inp.get('name') or '').lower()
            autocomplete = (inp.get('autocomplete') or '').lower()
            
            # Track by autocomplete or name pattern
            field_key = autocomplete or name
            
            if field_key:
                if field_key not in field_types:
                    field_types[field_key] = []
                field_types[field_key].append(inp)
        
        # Check for duplicates that aren't expected
        expected_duplicates = {'password', 'new-password', 'confirm-password'}
        
        for field_key, inputs in field_types.items():
            if len(inputs) > 1 and field_key not in expected_duplicates:
                # Could be billing/shipping - check context
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.NOTICE,
                    message=f"Multiple inputs collect '{field_key}' - ensure auto-fill is available",
                    element=str(inputs[0])[:200],
                    selector=self.get_element_selector(inputs[0]),
                    line=self.get_element_line(inputs[0]),
                    context=self.get_element_context(inputs[0]),
                    recommendation="Allow users to auto-fill or copy previously entered information",
                    techniques=["G221"]
                ))
        
        return issues
