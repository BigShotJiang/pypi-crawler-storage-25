"""
WCAG checks initialization.
"""

from wcag_checker.checks.base import BaseCheck, CheckRegistry, register_check

# Import all check modules to register them
from wcag_checker.checks import perceivable
from wcag_checker.checks import operable
from wcag_checker.checks import understandable
from wcag_checker.checks import robust

__all__ = ['BaseCheck', 'CheckRegistry', 'register_check']
