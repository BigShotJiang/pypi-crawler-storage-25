"""
WCAG Principle 1: Perceivable checks.

Information and user interface components must be presentable 
to users in ways they can perceive.
"""

from typing import List
from bs4 import Tag

from wcag_checker.models import Issue, IssueLevel
from wcag_checker.checks.base import BaseCheck, register_check
from wcag_checker.criteria import (
    SC_1_1_1, SC_1_2_1, SC_1_2_2, SC_1_2_3, SC_1_3_1, SC_1_3_2,
    SC_1_3_5, SC_1_4_1, SC_1_4_2, SC_1_4_3, SC_1_4_4, SC_1_4_5,
    SC_1_4_10, SC_1_4_11, SC_1_4_12, SC_1_4_13
)
from wcag_checker.utils import (
    get_accessible_name, is_hidden, is_decorative, get_text_content,
    is_valid_autocomplete, get_heading_level
)


# =============================================================================
# 1.1.1 Non-text Content
# =============================================================================

@register_check
class ImageAltCheck(BaseCheck):
    """Check that images have appropriate alternative text."""
    
    criterion = SC_1_1_1
    description = "Images must have alt attributes"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for img in self.soup.find_all('img'):
            if is_hidden(img):
                continue
            
            alt = img.get('alt')
            
            # No alt attribute at all
            if alt is None:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Image missing alt attribute",
                    element=str(img),
                    selector=self.get_element_selector(img),
                    line=self.get_element_line(img),
                    context=self.get_element_context(img),
                    recommendation="Add an alt attribute describing the image content, or alt='' for decorative images",
                    techniques=["H37", "H67"]
                ))
            # Check for suspicious alt text
            elif alt.lower() in ('image', 'picture', 'photo', 'graphic', 'icon'):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message=f"Image has non-descriptive alt text: '{alt}'",
                    element=str(img),
                    selector=self.get_element_selector(img),
                    line=self.get_element_line(img),
                    context=self.get_element_context(img),
                    recommendation="Provide meaningful alternative text that describes the image content",
                    techniques=["H37"]
                ))
            # Check for filename as alt
            elif '.' in alt and alt.split('.')[-1].lower() in ('jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message=f"Image alt text appears to be a filename: '{alt}'",
                    element=str(img),
                    selector=self.get_element_selector(img),
                    line=self.get_element_line(img),
                    context=self.get_element_context(img),
                    recommendation="Replace filename with meaningful alternative text",
                    techniques=["H37"]
                ))
        
        return issues


@register_check
class InputImageAltCheck(BaseCheck):
    """Check that image inputs have alt text."""
    
    criterion = SC_1_1_1
    description = "Image inputs must have alt attributes"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for inp in self.soup.find_all('input', {'type': 'image'}):
            if is_hidden(inp):
                continue
            
            alt = inp.get('alt')
            
            if not alt:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Image input missing alt attribute",
                    element=str(inp),
                    selector=self.get_element_selector(inp),
                    line=self.get_element_line(inp),
                    context=self.get_element_context(inp),
                    recommendation="Add an alt attribute describing the button's function",
                    techniques=["H36"]
                ))
        
        return issues


@register_check
class AreaAltCheck(BaseCheck):
    """Check that image map areas have alt text."""
    
    criterion = SC_1_1_1
    description = "Image map areas must have alt attributes"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for area in self.soup.find_all('area'):
            if is_hidden(area):
                continue
            
            alt = area.get('alt')
            
            if not alt:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Image map area missing alt attribute",
                    element=str(area),
                    selector=self.get_element_selector(area),
                    line=self.get_element_line(area),
                    context=self.get_element_context(area),
                    recommendation="Add an alt attribute describing the link destination",
                    techniques=["H24"]
                ))
        
        return issues


@register_check
class SvgAccessibilityCheck(BaseCheck):
    """Check that SVG elements are accessible."""
    
    criterion = SC_1_1_1
    description = "SVG elements must be accessible"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for svg in self.soup.find_all('svg'):
            if is_hidden(svg) or is_decorative(svg):
                continue
            
            # Check for title or aria-label
            has_title = svg.find('title') is not None
            has_aria_label = svg.get('aria-label') is not None
            has_aria_labelledby = svg.get('aria-labelledby') is not None
            has_role = svg.get('role') is not None
            
            if not (has_title or has_aria_label or has_aria_labelledby):
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message="SVG element lacks accessible name",
                    element=str(svg)[:200],
                    selector=self.get_element_selector(svg),
                    line=self.get_element_line(svg),
                    context=self.get_element_context(svg),
                    recommendation="Add a <title> element, aria-label, or aria-labelledby attribute",
                    techniques=["ARIA1"]
                ))
            
            if not has_role:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.NOTICE,
                    message="SVG element should have role='img' for meaningful images",
                    element=str(svg)[:200],
                    selector=self.get_element_selector(svg),
                    line=self.get_element_line(svg),
                    context=self.get_element_context(svg),
                    recommendation="Add role='img' for meaningful SVGs or role='presentation' for decorative ones",
                    techniques=["ARIA1"]
                ))
        
        return issues


@register_check
class ObjectAccessibilityCheck(BaseCheck):
    """Check that object/embed elements have alternatives."""
    
    criterion = SC_1_1_1
    description = "Object/embed elements must have text alternatives"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for obj in self.soup.find_all(['object', 'embed']):
            if is_hidden(obj):
                continue
            
            # Check for fallback content
            text_content = get_text_content(obj)
            has_aria_label = obj.get('aria-label') is not None
            has_aria_labelledby = obj.get('aria-labelledby') is not None
            
            if not text_content and not has_aria_label and not has_aria_labelledby:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message=f"{obj.name.upper()} element lacks text alternative",
                    element=str(obj),
                    selector=self.get_element_selector(obj),
                    line=self.get_element_line(obj),
                    context=self.get_element_context(obj),
                    recommendation="Provide fallback content or aria-label for non-text content",
                    techniques=["H53"]
                ))
        
        return issues


# =============================================================================
# 1.2.x Time-based Media
# =============================================================================

@register_check
class VideoAccessibilityCheck(BaseCheck):
    """Check that video elements have captions/tracks."""
    
    criterion = SC_1_2_2
    description = "Videos must have captions"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for video in self.soup.find_all('video'):
            if is_hidden(video):
                continue
            
            # Check for track elements
            captions = video.find_all('track', {'kind': 'captions'})
            subtitles = video.find_all('track', {'kind': 'subtitles'})
            
            if not captions and not subtitles:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message="Video element lacks caption track",
                    element=str(video)[:200],
                    selector=self.get_element_selector(video),
                    line=self.get_element_line(video),
                    context=self.get_element_context(video),
                    recommendation="Add <track kind='captions'> element for deaf/hard of hearing users",
                    techniques=["H95", "G87"]
                ))
        
        return issues


@register_check
class AudioDescriptionCheck(BaseCheck):
    """Check that videos have audio descriptions."""
    
    criterion = SC_1_2_3
    description = "Videos should have audio descriptions"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for video in self.soup.find_all('video'):
            if is_hidden(video):
                continue
            
            descriptions = video.find_all('track', {'kind': 'descriptions'})
            
            if not descriptions:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.NOTICE,
                    message="Video may need audio description for blind users",
                    element=str(video)[:200],
                    selector=self.get_element_selector(video),
                    line=self.get_element_line(video),
                    context=self.get_element_context(video),
                    recommendation="Consider adding <track kind='descriptions'> for videos with important visual content",
                    techniques=["G78", "G173"]
                ))
        
        return issues


@register_check
class AudioAlternativeCheck(BaseCheck):
    """Check that audio elements have text alternatives."""
    
    criterion = SC_1_2_1
    description = "Audio content should have text alternatives"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for audio in self.soup.find_all('audio'):
            if is_hidden(audio):
                continue
            
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.NOTICE,
                message="Audio element found - ensure transcript is available",
                element=str(audio)[:200],
                selector=self.get_element_selector(audio),
                line=self.get_element_line(audio),
                context=self.get_element_context(audio),
                recommendation="Provide a text transcript for audio-only content",
                techniques=["G158"]
            ))
        
        return issues


# =============================================================================
# 1.3.1 Info and Relationships
# =============================================================================

@register_check
class HeadingStructureCheck(BaseCheck):
    """Check for proper heading structure."""
    
    criterion = SC_1_3_1
    description = "Document should have proper heading structure"
    
    def check(self) -> List[Issue]:
        issues = []
        
        headings = self.soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
        
        # Check for h1
        h1_count = len(self.soup.find_all('h1'))
        if h1_count == 0:
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.WARNING,
                message="Page has no h1 heading",
                recommendation="Add an h1 heading that describes the page content",
                techniques=["G130", "H42"]
            ))
        elif h1_count > 1:
            issues.append(Issue(
                criterion=self.criterion,
                level=IssueLevel.NOTICE,
                message=f"Page has {h1_count} h1 headings - consider if this is intentional",
                recommendation="Generally, pages should have a single h1 heading",
                techniques=["G130"]
            ))
        
        # Check heading hierarchy
        prev_level = 0
        for heading in headings:
            if is_hidden(heading):
                continue
            
            level = get_heading_level(heading)
            if level is None:
                continue
            
            # Check for skipped levels
            if prev_level > 0 and level > prev_level + 1:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message=f"Heading level skipped: h{prev_level} followed by h{level}",
                    element=str(heading),
                    selector=self.get_element_selector(heading),
                    line=self.get_element_line(heading),
                    context=self.get_element_context(heading),
                    recommendation=f"Use h{prev_level + 1} instead of h{level}",
                    techniques=["G141"]
                ))
            
            # Check for empty headings
            text = get_text_content(heading)
            if not text.strip():
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.ERROR,
                    message="Empty heading element",
                    element=str(heading),
                    selector=self.get_element_selector(heading),
                    line=self.get_element_line(heading),
                    context=self.get_element_context(heading),
                    recommendation="Remove empty heading or add descriptive text",
                    techniques=["H42"]
                ))
            
            prev_level = level
        
        return issues


@register_check
class TableStructureCheck(BaseCheck):
    """Check that tables have proper structure."""
    
    criterion = SC_1_3_1
    description = "Data tables must have proper headers"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for table in self.soup.find_all('table'):
            if is_hidden(table):
                continue
            
            # Check if table is used for layout
            if table.get('role') == 'presentation':
                continue
            
            # Check for caption
            caption = table.find('caption')
            has_summary = table.get('summary') or table.get('aria-label') or table.get('aria-labelledby')
            
            # Check for headers
            headers = table.find_all('th')
            rows = table.find_all('tr')
            
            # If table has data cells, check for headers
            data_cells = table.find_all('td')
            if data_cells and not headers:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message="Data table lacks header cells (th elements)",
                    element=str(table)[:200],
                    selector=self.get_element_selector(table),
                    line=self.get_element_line(table),
                    context=self.get_element_context(table),
                    recommendation="Add th elements for column and/or row headers",
                    techniques=["H51", "H63"]
                ))
            
            # Check th elements have scope
            for th in headers:
                if not th.get('scope') and not th.get('id'):
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message="Table header lacks scope attribute",
                        element=str(th),
                        selector=self.get_element_selector(th),
                        line=self.get_element_line(th),
                        context=self.get_element_context(th),
                        recommendation="Add scope='col' or scope='row' to th elements",
                        techniques=["H63"]
                    ))
        
        return issues


@register_check
class ListStructureCheck(BaseCheck):
    """Check for proper list structure."""
    
    criterion = SC_1_3_1
    description = "Lists must be properly structured"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check ul/ol lists
        for list_elem in self.soup.find_all(['ul', 'ol']):
            if is_hidden(list_elem):
                continue
            
            # Check that children are li elements
            for child in list_elem.children:
                if isinstance(child, Tag) and child.name not in ('li', 'script', 'template'):
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.ERROR,
                        message=f"List contains invalid child element: {child.name}",
                        element=str(child)[:100],
                        selector=self.get_element_selector(child),
                        line=self.get_element_line(child),
                        context=self.get_element_context(list_elem),
                        recommendation="Only li elements should be direct children of ul/ol",
                        techniques=["H48"]
                    ))
        
        # Check dl lists
        for dl in self.soup.find_all('dl'):
            if is_hidden(dl):
                continue
            
            has_dt = dl.find('dt') is not None
            has_dd = dl.find('dd') is not None
            
            if not has_dt or not has_dd:
                issues.append(Issue(
                    criterion=self.criterion,
                    level=IssueLevel.WARNING,
                    message="Description list should contain both dt and dd elements",
                    element=str(dl)[:200],
                    selector=self.get_element_selector(dl),
                    line=self.get_element_line(dl),
                    context=self.get_element_context(dl),
                    recommendation="Use dt for terms and dd for definitions",
                    techniques=["H40"]
                ))
        
        return issues


@register_check
class FormGroupingCheck(BaseCheck):
    """Check that form controls are properly grouped."""
    
    criterion = SC_1_3_1
    description = "Related form controls should be grouped"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for radio/checkbox groups
        radio_groups = {}
        for inp in self.soup.find_all('input', {'type': ['radio', 'checkbox']}):
            if is_hidden(inp):
                continue
            
            name = inp.get('name', '')
            if name:
                if name not in radio_groups:
                    radio_groups[name] = []
                radio_groups[name].append(inp)
        
        # Check if groups have fieldset/legend
        for name, inputs in radio_groups.items():
            if len(inputs) > 1:
                # Check if wrapped in fieldset
                first_input = inputs[0]
                fieldset = first_input.find_parent('fieldset')
                
                if not fieldset:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message=f"Group of {len(inputs)} related inputs (name='{name}') should be in a fieldset",
                        element=str(first_input),
                        selector=self.get_element_selector(first_input),
                        line=self.get_element_line(first_input),
                        context=self.get_element_context(first_input),
                        recommendation="Wrap related inputs in <fieldset> with <legend>",
                        techniques=["H71", "H82"]
                    ))
                elif not fieldset.find('legend'):
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message="Fieldset lacks legend element",
                        element=str(fieldset)[:200],
                        selector=self.get_element_selector(fieldset),
                        line=self.get_element_line(fieldset),
                        context=self.get_element_context(fieldset),
                        recommendation="Add <legend> to describe the fieldset",
                        techniques=["H71"]
                    ))
        
        return issues


# =============================================================================
# 1.3.5 Identify Input Purpose
# =============================================================================

@register_check
class InputAutocompleteCheck(BaseCheck):
    """Check that user input fields have autocomplete attributes."""
    
    criterion = SC_1_3_5
    description = "Input fields collecting user information should have autocomplete"
    
    # Input types that commonly collect user information
    USER_INPUT_PATTERNS = {
        'name': ['name', 'full-name', 'fullname'],
        'given-name': ['first-name', 'firstname', 'fname', 'given-name'],
        'family-name': ['last-name', 'lastname', 'lname', 'surname', 'family-name'],
        'email': ['email', 'e-mail', 'mail'],
        'tel': ['phone', 'telephone', 'tel', 'mobile'],
        'street-address': ['address', 'street', 'addr'],
        'postal-code': ['zip', 'zipcode', 'postal', 'postcode'],
        'country': ['country'],
        'username': ['username', 'user', 'login'],
        'new-password': ['new-password', 'newpassword', 'password-new'],
        'current-password': ['password', 'pass', 'pwd'],
        'cc-number': ['card-number', 'cardnumber', 'cc-num', 'ccnumber'],
        'cc-exp': ['expiry', 'exp-date', 'expiration'],
        'bday': ['birthday', 'dob', 'dateofbirth', 'birth-date'],
    }
    
    def check(self) -> List[Issue]:
        issues = []
        
        for inp in self.soup.find_all(['input', 'select', 'textarea']):
            if is_hidden(inp):
                continue
            
            # Skip certain input types
            input_type = inp.get('type', 'text')
            if input_type in ('hidden', 'submit', 'button', 'reset', 'image', 'file', 'checkbox', 'radio'):
                continue
            
            autocomplete = inp.get('autocomplete')
            name = (inp.get('name') or '').lower()
            input_id = (inp.get('id') or '').lower()
            placeholder = (inp.get('placeholder') or '').lower()
            
            # Check if input appears to collect user info
            for ac_value, patterns in self.USER_INPUT_PATTERNS.items():
                for pattern in patterns:
                    if pattern in name or pattern in input_id or pattern in placeholder:
                        if not autocomplete:
                            issues.append(Issue(
                                criterion=self.criterion,
                                level=IssueLevel.WARNING,
                                message=f"Input appears to collect '{ac_value}' but lacks autocomplete attribute",
                                element=str(inp),
                                selector=self.get_element_selector(inp),
                                line=self.get_element_line(inp),
                                context=self.get_element_context(inp),
                                recommendation=f"Add autocomplete='{ac_value}' attribute",
                                techniques=["H98"]
                            ))
                        elif not is_valid_autocomplete(autocomplete):
                            issues.append(Issue(
                                criterion=self.criterion,
                                level=IssueLevel.WARNING,
                                message=f"Invalid autocomplete value: '{autocomplete}'",
                                element=str(inp),
                                selector=self.get_element_selector(inp),
                                line=self.get_element_line(inp),
                                context=self.get_element_context(inp),
                                recommendation="Use a valid autocomplete token from the specification",
                                techniques=["H98"]
                            ))
                        break
        
        return issues


# =============================================================================
# 1.4.1 Use of Color
# =============================================================================

@register_check
class ColorOnlyIndicatorCheck(BaseCheck):
    """Check for potential color-only indicators."""
    
    criterion = SC_1_4_1
    description = "Color should not be the only means of conveying information"
    
    def check(self) -> List[Issue]:
        issues = []
        
        # Check for required fields indicated only by color
        for inp in self.soup.find_all(['input', 'select', 'textarea']):
            if is_hidden(inp):
                continue
            
            if inp.get('required') or inp.get('aria-required') == 'true':
                # Check if there's a visible indicator besides color
                label = None
                if inp.get('id'):
                    label = self.soup.find('label', {'for': inp['id']})
                if not label:
                    label = inp.find_parent('label')
                
                if label:
                    label_text = get_text_content(label)
                    if '*' not in label_text and 'required' not in label_text.lower():
                        issues.append(Issue(
                            criterion=self.criterion,
                            level=IssueLevel.NOTICE,
                            message="Required field may rely on color alone to indicate status",
                            element=str(inp),
                            selector=self.get_element_selector(inp),
                            line=self.get_element_line(inp),
                            context=self.get_element_context(inp),
                            recommendation="Ensure required status is indicated with more than color (e.g., asterisk, text)",
                            techniques=["G14", "G205"]
                        ))
        
        # Check links within paragraphs
        for p in self.soup.find_all('p'):
            links = p.find_all('a')
            for link in links:
                if is_hidden(link):
                    continue
                
                # Check if link has underline or other non-color indicator
                style = link.get('style', '')
                if 'text-decoration:none' in style.replace(' ', '') or 'text-decoration: none' in style:
                    issues.append(Issue(
                        criterion=self.criterion,
                        level=IssueLevel.WARNING,
                        message="Link within text may only be distinguished by color",
                        element=str(link),
                        selector=self.get_element_selector(link),
                        line=self.get_element_line(link),
                        context=self.get_element_context(link),
                        recommendation="Ensure links are distinguishable by more than color (e.g., underline)",
                        techniques=["G183"]
                    ))
        
        return issues


# =============================================================================
# 1.4.2 Audio Control
# =============================================================================

@register_check
class AutoplayAudioCheck(BaseCheck):
    """Check for auto-playing audio."""
    
    criterion = SC_1_4_2
    description = "Audio that plays automatically must be controllable"
    
    def check(self) -> List[Issue]:
        issues = []
        
        for media in self.soup.find_all(['audio', 'video']):
            if is_hidden(media):
                continue
            
            if media.has_attr('autoplay'):
                has_controls = media.has_attr('controls')
                has_muted = media.has_attr('muted')
                
                if not has_muted:
                    if not has_controls:
                        issues.append(Issue(
                            criterion=self.criterion,
                            level=IssueLevel.ERROR,
                            message=f"{media.name.upper()} element has autoplay but no controls",
                            element=str(media)[:200],
                            selector=self.get_element_selector(media),
                            line=self.get_element_line(media),
                            context=self.get_element_context(media),
                            recommendation="Add 'controls' attribute or 'muted' attribute to autoplay media",
                            techniques=["G170", "G171"]
                        ))
                    else:
                        issues.append(Issue(
                            criterion=self.criterion,
                            level=IssueLevel.WARNING,
                            message=f"{media.name.upper()} element autoplays audio - ensure volume can be controlled",
                            element=str(media)[:200],
                            selector=self.get_element_selector(media),
                            line=self.get_element_line(media),
                            context=self.get_element_context(media),
                            recommendation="Consider starting muted or providing prominent pause control",
                            techniques=["G170", "G171"]
                        ))
        
        return issues
