__version__ = "0.3.0"
__version_date__ = "2026-04-27"  # Stamped automatically at build time by hatch_build.py
