from __future__ import annotations

import json
from urllib import error

import pandas as pd
import pytest

from mysphinx_forge.model_testing import (
    ModelTestRuntimeConfig,
    HttpPostModelTester,
    OpenAICompatibleModelTester,
    model_test_dataframe,
    run_model_test,
)


def test_openai_model_tester_reads_text_from_response(monkeypatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps(
                {
                    "choices": [
                        {
                            "message": {
                                "content": "基金",
                            }
                        }
                    ]
                }
            ).encode("utf-8")

    def fake_urlopen(request_obj, timeout=60.0):
        payload = json.loads(request_obj.data.decode("utf-8"))
        assert request_obj.full_url == "https://example.test/v1/chat/completions"
        assert request_obj.get_header("Authorization") == "Bearer test-key"
        assert payload["model"] == "gpt-4.1-mini"
        assert payload["messages"][0]["role"] == "system"
        assert payload["messages"][1]["content"] == "请问退款怎么申请？"
        assert payload["max_tokens"] == 32
        assert payload["temperature"] == 0
        assert timeout == 60.0
        return FakeResponse()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    tester = OpenAICompatibleModelTester(
        "gpt-4.1-mini",
        api_base_url="https://example.test/v1",
    )

    assert tester.generate_text("请问退款怎么申请？", max_new_tokens=32) == "基金"


def test_openai_model_tester_reads_text_from_content_parts(monkeypatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps(
                {
                    "choices": [
                        {
                            "message": {
                                "content": [
                                    {"text": "基"},
                                    {"text": "金"},
                                ],
                            }
                        }
                    ]
                }
            ).encode("utf-8")

    monkeypatch.setattr(
        "mysphinx_forge.http_client.request.urlopen",
        lambda request_obj, timeout=60.0: FakeResponse(),
    )

    tester = OpenAICompatibleModelTester(
        "gpt-4.1-mini",
        api_base_url="https://example.test/v1",
    )

    assert tester.generate_text("请问退款怎么申请？", max_new_tokens=32) == "基金"


def test_openai_model_tester_requires_api_key(monkeypatch) -> None:
    monkeypatch.chdir("/")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    with pytest.raises(ValueError, match="OPENAI_API_KEY"):
        OpenAICompatibleModelTester("gpt-4.1-mini")


def test_openai_model_tester_loads_api_key_from_project_env_file(tmp_path, monkeypatch) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text('OPENAI_API_KEY="env-file-key"\n', encoding="utf-8")

    def fake_urlopen(request_obj, timeout=60.0):
        assert request_obj.get_header("Authorization") == "Bearer env-file-key"
        raise error.URLError("stop after header assertion")

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    with pytest.raises(ValueError, match="stop after header assertion"):
        OpenAICompatibleModelTester("gpt-4.1-mini").generate_text("退款怎么申请")


def test_openai_model_tester_surfaces_http_errors(monkeypatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class FakeHttpError(error.HTTPError):
        def __init__(self):
            super().__init__(
                url="https://api.openai.com/v1/chat/completions",
                code=401,
                msg="Unauthorized",
                hdrs=None,
                fp=None,
            )

        def read(self):
            return b'{"error":"bad key"}'

    def fake_urlopen(_request_obj, timeout=60.0):
        raise FakeHttpError()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    with pytest.raises(ValueError, match="HTTP 401"):
        OpenAICompatibleModelTester("gpt-4.1-mini").generate_text("退款怎么申请")


def test_run_model_test_supports_openai_mode(monkeypatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps(
                {
                    "choices": [
                        {
                            "message": {
                                "content": "股票",
                            }
                        }
                    ]
                }
            ).encode("utf-8")

    monkeypatch.setattr(
        "mysphinx_forge.http_client.request.urlopen",
        lambda request_obj, timeout=60.0: FakeResponse(),
    )

    result = run_model_test(
        model_path="gpt-4.1-mini",
        mode="openai",
        api_base_url="https://example.test/v1",
    )

    assert result.model_path == "gpt-4.1-mini"
    assert result.generated_text == "股票"
    assert result.model_class == "OpenAICompatibleChatCompletions"
    assert result.device == "openai-api"


def test_http_model_tester_reads_text_from_response_and_sends_api_key_header(monkeypatch) -> None:
    monkeypatch.setenv("HTTP_API_KEY", "http-test-key")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps({"generated_text": "基金"}).encode("utf-8")

    def fake_urlopen(request_obj, timeout=60.0):
        payload = json.loads(request_obj.data.decode("utf-8"))
        headers = {key.lower(): value for key, value in request_obj.header_items()}
        assert request_obj.full_url == "https://example.test/infer"
        assert headers["api_key"] == "http-test-key"
        assert payload["model"] == "custom-http-model"
        assert payload["user_input"] == "请问退款怎么申请？"
        assert payload["max_new_tokens"] == 32
        return FakeResponse()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    tester = HttpPostModelTester(
        "custom-http-model",
        api_base_url="https://example.test/infer",
    )

    assert tester.generate_text("请问退款怎么申请？", max_new_tokens=32) == "基金"


def test_http_model_tester_supports_explicit_headers_without_api_key(monkeypatch) -> None:
    monkeypatch.chdir("/")
    monkeypatch.delenv("HTTP_API_KEY", raising=False)

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps({"generated_text": "基金"}).encode("utf-8")

    def fake_urlopen(request_obj, timeout=60.0):
        headers = {key.lower(): value for key, value in request_obj.header_items()}
        assert headers["authorization"] == "Bearer custom-token"
        assert headers["x-tenant"] == "forge"
        return FakeResponse()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    tester = HttpPostModelTester(
        "custom-http-model",
        api_base_url="https://example.test/infer",
        headers={
            "Authorization": "Bearer custom-token",
            "X-Tenant": "forge",
        },
    )

    assert tester.generate_text("请问退款怎么申请？") == "基金"


def test_http_model_tester_supports_request_field_map_and_extra_body(monkeypatch) -> None:
    monkeypatch.setenv("HTTP_API_KEY", "http-test-key")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps({"result": "基金"}).encode("utf-8")

    def fake_urlopen(request_obj, timeout=60.0):
        payload = json.loads(request_obj.data.decode("utf-8"))
        assert payload["model_name"] == "custom-http-model"
        assert payload["system"] == "系统指令"
        assert payload["prompt"] == "请问退款怎么申请？"
        assert payload["max_tokens"] == 12
        assert payload["tenant"] == "forge"
        assert payload["stream"] is False
        return FakeResponse()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    tester = HttpPostModelTester(
        "custom-http-model",
        system_prompt="系统指令",
        api_base_url="https://example.test/infer",
        request_field_map={
            "model": "model_name",
            "system_prompt": "system",
            "user_input": "prompt",
            "max_new_tokens": "max_tokens",
        },
        extra_body={"tenant": "forge", "stream": False},
    )

    assert tester.generate_text("请问退款怎么申请？", max_new_tokens=12) == "基金"


def test_http_model_tester_supports_chat_completions_style_endpoint(monkeypatch) -> None:
    monkeypatch.setenv("HTTP_API_KEY", "http-test-key")
    monkeypatch.setenv("HTTP_API_KEY_HEADER", "Authorization")
    monkeypatch.setenv("HTTP_API_KEY_PREFIX", "Bearer ")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps(
                {
                    "choices": [
                        {
                            "message": {
                                "content": "基金",
                            }
                        }
                    ]
                }
            ).encode("utf-8")

    def fake_urlopen(request_obj, timeout=60.0):
        payload = json.loads(request_obj.data.decode("utf-8"))
        assert request_obj.full_url == "https://api.deepseek.com/chat/completions"
        assert request_obj.get_header("Authorization") == "Bearer http-test-key"
        assert payload["model"] == "deepseek-chat"
        assert payload["messages"][0]["role"] == "system"
        assert payload["messages"][1]["content"] == "ETF"
        assert payload["max_tokens"] == 32
        assert payload["stream"] is False
        return FakeResponse()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    tester = HttpPostModelTester(
        "deepseek-chat",
        api_base_url="https://api.deepseek.com/chat/completions",
        extra_body={"stream": False},
    )

    assert tester.generate_text("ETF", max_new_tokens=32) == "基金"


def test_http_model_tester_normalizes_bearer_prefix_without_space(monkeypatch) -> None:
    monkeypatch.setenv("HTTP_API_KEY", "http-test-key")
    monkeypatch.setenv("HTTP_API_KEY_HEADER", "Authorization")
    monkeypatch.setenv("HTTP_API_KEY_PREFIX", "Bearer")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps(
                {
                    "choices": [
                        {
                            "message": {
                                "content": "基金",
                            }
                        }
                    ]
                }
            ).encode("utf-8")

    def fake_urlopen(request_obj, timeout=60.0):
        assert request_obj.get_header("Authorization") == "Bearer http-test-key"
        return FakeResponse()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    tester = HttpPostModelTester(
        "deepseek-chat",
        api_base_url="https://api.deepseek.com/chat/completions",
    )

    assert tester.generate_text("ETF") == "基金"


def test_http_model_tester_appends_deepseek_chat_completions_path(monkeypatch) -> None:
    monkeypatch.setenv("HTTP_API_KEY", "http-test-key")
    monkeypatch.setenv("HTTP_API_KEY_HEADER", "Authorization")
    monkeypatch.setenv("HTTP_API_KEY_PREFIX", "Bearer ")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps(
                {
                    "choices": [
                        {
                            "message": {
                                "content": "股票",
                            }
                        }
                    ]
                }
            ).encode("utf-8")

    def fake_urlopen(request_obj, timeout=60.0):
        payload = json.loads(request_obj.data.decode("utf-8"))
        assert request_obj.full_url == "https://api.deepseek.com/v1/chat/completions"
        assert payload["messages"][1]["content"] == "ETF"
        return FakeResponse()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    tester = HttpPostModelTester(
        "deepseek-chat",
        api_base_url="https://api.deepseek.com/v1",
    )

    assert tester.generate_text("ETF") == "股票"


def test_http_model_tester_requires_api_key(monkeypatch) -> None:
    monkeypatch.chdir("/")
    monkeypatch.delenv("HTTP_API_KEY", raising=False)

    with pytest.raises(ValueError, match="HTTP_API_KEY"):
        HttpPostModelTester("custom-http-model", api_base_url="https://example.test/infer")


def test_run_model_test_supports_http_mode(monkeypatch) -> None:
    monkeypatch.setenv("HTTP_API_KEY", "http-test-key")

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps({"text": "股票"}).encode("utf-8")

    monkeypatch.setattr(
        "mysphinx_forge.http_client.request.urlopen",
        lambda request_obj, timeout=60.0: FakeResponse(),
    )

    result = run_model_test(
        model_path="custom-http-model",
        mode="http",
        api_base_url="https://example.test/infer",
    )

    assert result.model_path == "custom-http-model"
    assert result.generated_text == "股票"
    assert result.model_class == "HttpPostModelService"
    assert result.device == "http-api"


def test_model_test_dataframe_supports_openai_mode(monkeypatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    responses = iter(["基金", "股票"])

    class FakeResponse:
        def __init__(self, text: str):
            self.text = text

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps(
                {
                    "choices": [
                        {
                            "message": {
                                "content": self.text,
                            }
                        }
                    ]
                }
            ).encode("utf-8")

    def fake_urlopen(_request_obj, timeout=60.0):
        return FakeResponse(next(responses))

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    dataframe = pd.DataFrame(
        {
            "用户输入": ["退款怎么申请", "基金怎么买"],
            "预期结果": ["基金", "股票"],
        }
    )
    progress = []

    tested, stats = model_test_dataframe(
        dataframe=dataframe,
        model_path="gpt-4.1-mini",
        runtime_config=ModelTestRuntimeConfig(mode="openai", api_base_url="https://example.test/v1"),
        target_column="用户输入",
        progress_callback=progress.append,
    )

    assert tested["模型结果"].tolist() == ["基金", "股票"]
    assert tested["匹配预期"].tolist() == [True, True]
    assert stats.model_path == "gpt-4.1-mini"
    assert stats.device == "openai-api"
    assert stats.num_workers == 1
    assert progress == [1, 1]


def test_model_test_dataframe_supports_http_mode(monkeypatch) -> None:
    monkeypatch.setenv("HTTP_API_KEY", "http-test-key")

    responses = iter(["基金", "股票"])

    class FakeResponse:
        def __init__(self, text: str):
            self.text = text

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps({"generated_text": self.text}).encode("utf-8")

    def fake_urlopen(_request_obj, timeout=60.0):
        return FakeResponse(next(responses))

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)

    dataframe = pd.DataFrame(
        {
            "用户输入": ["退款怎么申请", "基金怎么买"],
            "预期结果": ["基金", "股票"],
        }
    )
    progress = []

    tested, stats = model_test_dataframe(
        dataframe=dataframe,
        model_path="custom-http-model",
        runtime_config=ModelTestRuntimeConfig(
            mode="http",
            api_base_url="https://example.test/infer",
        ),
        target_column="用户输入",
        progress_callback=progress.append,
    )

    assert tested["模型结果"].tolist() == ["基金", "股票"]
    assert tested["匹配预期"].tolist() == [True, True]
    assert stats.model_path == "custom-http-model"
    assert stats.device == "http-api"
    assert stats.num_workers == 1
    assert progress == [1, 1]
