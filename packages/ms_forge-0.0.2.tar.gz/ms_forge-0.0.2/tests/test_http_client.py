from __future__ import annotations

import json
from urllib import error

import pytest

from mysphinx_forge.http_client import HttpClientError, post_json


def test_post_json_retries_until_success(monkeypatch) -> None:
    attempts = {"count": 0}

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps({"ok": True}).encode("utf-8")

    def fake_urlopen(request_obj, timeout=30.0):
        attempts["count"] += 1
        assert request_obj.full_url == "https://example.test/api"
        assert timeout == 12.0
        if attempts["count"] < 3:
            raise error.URLError("temporary network issue")
        return FakeResponse()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)
    monkeypatch.setattr("mysphinx_forge.http_client.time.sleep", lambda _seconds: None)

    result = post_json(
        "https://example.test/api",
        {"hello": "world"},
        timeout_seconds=12.0,
        max_retries=3,
    )

    assert result == {"ok": True}
    assert attempts["count"] == 3


def test_post_json_does_not_retry_non_retryable_http_error(monkeypatch) -> None:
    attempts = {"count": 0}

    class FakeHttpError(error.HTTPError):
        def __init__(self):
            super().__init__(
                url="https://example.test/api",
                code=401,
                msg="Unauthorized",
                hdrs=None,
                fp=None,
            )

        def read(self):
            return b'{"error":"bad key"}'

    def fake_urlopen(_request_obj, timeout=30.0):
        attempts["count"] += 1
        raise FakeHttpError()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)
    monkeypatch.setattr("mysphinx_forge.http_client.time.sleep", lambda _seconds: None)

    with pytest.raises(HttpClientError, match="HTTP 401"):
        post_json("https://example.test/api", {"hello": "world"})

    assert attempts["count"] == 1


def test_post_json_retries_retryable_http_error_until_limit(monkeypatch) -> None:
    attempts = {"count": 0}

    class FakeHttpError(error.HTTPError):
        def __init__(self):
            super().__init__(
                url="https://example.test/api",
                code=503,
                msg="Service Unavailable",
                hdrs=None,
                fp=None,
            )

        def read(self):
            return b'{"error":"busy"}'

    def fake_urlopen(_request_obj, timeout=30.0):
        attempts["count"] += 1
        raise FakeHttpError()

    monkeypatch.setattr("mysphinx_forge.http_client.request.urlopen", fake_urlopen)
    monkeypatch.setattr("mysphinx_forge.http_client.time.sleep", lambda _seconds: None)

    with pytest.raises(HttpClientError, match="HTTP 503"):
        post_json("https://example.test/api", {"hello": "world"}, max_retries=2)

    assert attempts["count"] == 3
