from __future__ import annotations

from collections.abc import Mapping


def extract_chat_completion_text(
    payload: Mapping[str, object],
    *,
    error_prefix: str,
) -> str:
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        raise ValueError(f"{error_prefix}：响应中缺少 choices。")

    first_choice = choices[0]
    message = first_choice.get("message") if isinstance(first_choice, dict) else None
    if not isinstance(message, dict):
        raise ValueError(f"{error_prefix}：响应中缺少 message。")

    content = message.get("content")
    if isinstance(content, str):
        return content

    if isinstance(content, list):
        text = "".join(_extract_content_text_parts(content))
        if text:
            return text

    raise ValueError(f"{error_prefix}：响应中缺少 content。")


def _extract_content_text_parts(content: list[object]) -> list[str]:
    parts: list[str] = []
    for item in content:
        if not isinstance(item, dict):
            continue

        text_value = item.get("text")
        if isinstance(text_value, str):
            parts.append(text_value)

    return parts
