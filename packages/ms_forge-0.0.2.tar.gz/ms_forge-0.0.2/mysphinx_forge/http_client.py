from __future__ import annotations

import json
import ssl
import time
from collections.abc import Collection
from urllib import error, request


DEFAULT_HTTP_MAX_RETRIES = 3
DEFAULT_RETRY_BACKOFF_SECONDS = 1.0
DEFAULT_RETRYABLE_STATUS_CODES = frozenset({408, 409, 425, 429, 500, 502, 503, 504})


class HttpClientError(RuntimeError):
    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


def post_json(
    url: str,
    payload: dict[str, object],
    *,
    headers: dict[str, str] | None = None,
    timeout_seconds: float = 30.0,
    max_retries: int = DEFAULT_HTTP_MAX_RETRIES,
    retry_backoff_seconds: float = DEFAULT_RETRY_BACKOFF_SECONDS,
    retryable_status_codes: Collection[int] = DEFAULT_RETRYABLE_STATUS_CODES,
) -> dict[str, object]:
    if max_retries < 0:
        raise ValueError("max_retries 不能小于 0。")
    if timeout_seconds <= 0:
        raise ValueError("timeout_seconds 必须大于 0。")
    if retry_backoff_seconds < 0:
        raise ValueError("retry_backoff_seconds 不能小于 0。")

    body = json.dumps(payload).encode("utf-8")
    request_headers = {
        "Content-Type": "application/json",
        **(headers or {}),
    }
    last_error: HttpClientError | None = None

    for attempt in range(max_retries + 1):
        api_request = request.Request(
            url=url,
            data=body,
            headers=request_headers,
            method="POST",
        )
        try:
            with request.urlopen(api_request, timeout=timeout_seconds) as response:
                response_text = response.read().decode("utf-8")
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="ignore")
            last_error = HttpClientError(
                f"HTTP {exc.code}: {detail}",
                status_code=exc.code,
            )
            if exc.code not in retryable_status_codes or attempt >= max_retries:
                raise last_error from exc
        except error.URLError as exc:
            reason = exc.reason
            message = str(reason)
            if isinstance(reason, ssl.SSLError):
                message = (
                    f"{message}（请求地址：{url}；这通常表示 TLS 握手失败。"
                    "请优先检查是否把仅支持 HTTP 的接口写成了 HTTPS，"
                    "或服务端证书/反向代理配置异常。）"
                )
            else:
                message = f"{message}（请求地址：{url}）"
            last_error = HttpClientError(message)
            if attempt >= max_retries:
                raise last_error from exc
        else:
            try:
                response_payload = json.loads(response_text)
            except json.JSONDecodeError as exc:
                raise HttpClientError("响应不是合法 JSON。") from exc
            if not isinstance(response_payload, dict):
                raise HttpClientError("响应 JSON 顶层结构必须是对象。")
            return response_payload

        if retry_backoff_seconds > 0 and attempt < max_retries:
            time.sleep(retry_backoff_seconds * (2**attempt))

    if last_error is not None:
        raise last_error
    raise HttpClientError("HTTP 请求失败。")
