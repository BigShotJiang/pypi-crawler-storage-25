from __future__ import annotations

import os
from pathlib import Path


def load_project_env_files(*, include_project_root: bool = True) -> None:
    candidate_paths = [Path.cwd() / ".env"]
    if include_project_root:
        candidate_paths.append(Path(__file__).resolve().parents[1] / ".env")
    seen_paths: set[Path] = set()
    for env_path in candidate_paths:
        resolved_path = env_path.resolve()
        if resolved_path in seen_paths or not env_path.is_file():
            continue
        seen_paths.add(resolved_path)
        load_env_file(env_path)


def load_env_file(path: Path) -> None:
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(key, value)
