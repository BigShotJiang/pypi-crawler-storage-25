# Copyright 2025 Vangelis Technologies Inc.
# SPDX-License-Identifier: Apache-2.0

"""Simulation routes."""

from fastapi import APIRouter, Depends

from archetype.api.deps import get_actor_ctx, get_command_service
from archetype.api.errors import raise_api_error
from archetype.api.models import (
    EpisodeConfig,
    RolloutConfig,
    RunRequest,
    RunResultResponse,
    StepRequest,
)
from archetype.app.auth.models import ActorCtx
from archetype.app.command_service import CommandService
from archetype.app.models import EpisodeResult, RolloutResult

router = APIRouter(prefix="/worlds/{world_id}", tags=["simulation"])


@router.post("/step")
async def step_world(
    world_id: str,
    req: StepRequest | None = None,
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """Advance one tick. Requires operator or admin."""
    try:
        run_config = (req or StepRequest()).to_run_config()
        commands_applied = await cs.step(ctx, world_id, run_config)
        info = await cs.get_world_info(ctx, world_id)
        return {
            "world_id": str(info.world_id),
            "tick": info.tick,
            "commands_applied": commands_applied,
        }
    except Exception as exc:
        raise_api_error(exc)


@router.post("/run", response_model=RunResultResponse)
async def run_world(
    world_id: str,
    req: RunRequest,
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """Run a bounded simulation. Requires operator or admin."""
    try:
        result = await cs.run(ctx, world_id, req.to_run_config())
        return RunResultResponse(
            run_id=str(result.run_id),
            world_id=str(result.world_id),
            ticks_completed=result.ticks_completed,
            commands_applied=result.commands_applied,
            final_tick=result.final_tick,
        )
    except Exception as exc:
        raise_api_error(exc)


@router.post("/episode", response_model=EpisodeResult)
async def run_episode(
    world_id: str,
    config: EpisodeConfig,
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """Run one episode. Requires operator or admin."""
    try:
        return await cs.run_episode(ctx, world_id, config)
    except Exception as exc:
        raise_api_error(exc)


@router.post("/rollout", response_model=RolloutResult)
async def run_rollout(
    world_id: str,
    config: RolloutConfig,
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """Run a rollout. Requires operator or admin; emits one rollout audit row."""
    try:
        return await cs.run_rollout(ctx, world_id, config)
    except Exception as exc:
        raise_api_error(exc)
