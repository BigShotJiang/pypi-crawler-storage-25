# Copyright 2025 Vangelis Technologies Inc.
# SPDX-License-Identifier: Apache-2.0

"""World lifecycle routes."""

from fastapi import APIRouter, Depends, Response, status

from archetype.api.deps import get_actor_ctx, get_command_service
from archetype.api.errors import raise_api_error
from archetype.api.models import CreateWorldRequest, ForkWorldRequest
from archetype.app.auth.models import ActorCtx
from archetype.app.command_service import CommandService
from archetype.app.models import WorldInfo

router = APIRouter(prefix="/worlds", tags=["worlds"])


@router.post("", response_model=WorldInfo, status_code=status.HTTP_201_CREATED)
async def create_world(
    req: CreateWorldRequest,
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """Create a world. Requires admin."""
    try:
        return await cs.create_world(ctx, req.world_config(), req.storage(), req.cache_config)
    except Exception as exc:
        raise_api_error(exc, conflict=True)


@router.get("", response_model=list[WorldInfo])
async def list_worlds(
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """List live worlds. Requires admin."""
    try:
        return await cs.list_worlds(ctx)
    except Exception as exc:
        raise_api_error(exc)


@router.get("/{world_id}", response_model=WorldInfo)
async def get_world(
    world_id: str,
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """Get world metadata. Requires viewer, player, operator, or admin."""
    try:
        return await cs.get_world_info(ctx, world_id)
    except Exception as exc:
        raise_api_error(exc)


@router.delete("/{world_id}", status_code=status.HTTP_204_NO_CONTENT)
async def destroy_world(
    world_id: str,
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """Drop the in-memory world instance. Persisted storage and audit rows are retained.

    Requires operator or admin. Destroying an unknown world is a no-op.
    """
    try:
        await cs.destroy_world(ctx, world_id)
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    except Exception as exc:
        raise_api_error(exc)


@router.post("/{world_id}/fork", response_model=WorldInfo, status_code=status.HTTP_201_CREATED)
async def fork_world(
    world_id: str,
    req: ForkWorldRequest,
    cs: CommandService = Depends(get_command_service),
    ctx: ActorCtx = Depends(get_actor_ctx),
):
    """Fork a world. Requires operator or admin."""
    try:
        return await cs.fork_world(
            ctx,
            world_id,
            req.name,
            storage_config=req.storage_config,
            cache_config=req.cache_config,
        )
    except Exception as exc:
        raise_api_error(exc)
