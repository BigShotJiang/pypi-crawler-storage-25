from .Main import *
from fastapi import FastAPI, Request
from fastapi.responses import Response
import uvicorn

class CToolRegisterFastApi(CToolRegister):
    """Registrador para FastApi HTTP Server"""

    def __init__(self, config : Dict[str, Any], main_pointer: CMt5McpConection):
        super().__init__(main_pointer)

        # App
        self.app : FastAPI = FastAPI(title=config["http"].get("name","MyServer")) # Nombre del server

        # Seteo de parametros
        self.m_names_pace_name : str = config["http"].get("tools_namespace","tools")  # Tools namespace
        self.m_port_http : int = config["http"]["http_port"] # Puerto HTTP
        self.m_host : str = config["general_config"]["host"] # Host base

        # Extra
        caracteres_a_limpiar : str = '\n\r\t'
        self.m_tabla_chars_clean = str.maketrans('', '', caracteres_a_limpiar)


        #------- Base funcion
        @self.app.get(f"/{self.m_names_pace_name}")
        def mcp_discovery():
            """MCP Discovery endpoint"""
            return {
                "protocolVersion": "2025-11-25",
                "capabilities": {"tools": {}},
                "serverInfo": {
                    "name": config["http"].get("name", "MyServer"),
                    "version": "1.0.0"
                }
            }

        #------- Endpoint base
        @self.app.post(f"/{self.m_names_pace_name}")
        async def mcp_handle(request: Request) -> Response:
            """Handler del protocolo MCP"""
            
            #import time 
            #start  = time.perf_counter()
            
            body = await request.json()
            method = body.get("method")
            req_id = body.get("id")

            #print(f"[MCP] Recibido: method={method}, id={req_id}")
            #print(f"[MCP] Body completo: {body}")

            # Call a tool
            if method == "tools/call":
                # Llamar un tool específico
                tool_name = body.get("params", {}).get("name")
                arguments = body.get("params", {}).get("arguments", {})

                if tool_name in self.tools:
                    try:
                        result : str = self.tools[tool_name](arguments) #  retorna string estramos seguros.
                        res_final : str = result.replace('"', '\\"')
                        
                        #end = time.perf_counter() - start
                        #print(f"Timepo = {end}")
                        
                        return Response(
                            content=f'{{"jsonrpc":"2.0","id":{req_id},"result":{{"content":[{{ "type":"text","text":"{res_final}"}}],"isError":false}}}}',
                            media_type="application/json")


                    except Exception as e:
                        return Response(
                            content=f'{{"jsonrpc":"2.0","id":{req_id},"error":{{"code":-32603,"message":"{str(e)}"}}}}',
                            media_type="application/json")

                else:
                    err_msg : str =  f"Tool '{tool_name}' not found"
                    return Response(
                        content=f'{{"jsonrpc":"2.0","id":{req_id},"error":{{"code":-32601,"message":"{err_msg}"}}}}',
                        media_type="application/json")


            # Lista de tools
            elif method == "tools/list":
                # Retornar lista de tools registrados
                tools = "["
                k : int = 0
                tools_size : int = len(self.tools)

                for tool_name, tool_func in self.tools.items():
                    k+=1
                    # Obtencion de la descripcion y limpiado
                    doc : str = tool_func.__doc__ or ""
                    # Concatenamos
                    tools +=  "{" + f'"name":"{tool_name}",' + doc.translate(self.m_tabla_chars_clean) + "}"

                    if k < tools_size:
                        tools += ","

                tools += "]"
                
                #print(tools)

                return Response(
                    content=f'{{"jsonrpc":"2.0","id":{req_id},"result":{{"tools":{tools}}}}}',
                    media_type="application/json")


            # Inicializacion
            elif method == "initialize":
                return Response(
                    content=f'{{"jsonrpc":"2.0","id":{req_id},"result":{{"protocolVersion":"2025-11-25","capabilities":{{"tools":{{}}}},"serverInfo":{{"name":"MyServer","version":"1.0.0"}}}}}}',
                    media_type="application/json")

            # Metodo invalido
            else:
                return Response(
                    content=f'{{"jsonrpc":"2.0","id":{req_id},"error":{{"code":-32700,"message":"Invalid Method"}}}}',
                    media_type="application/json")
           
        
    
    def registrar(self, tool_name: str, funcion_tool_nueva: Callable[[Dict[str, Any]], Any]) -> None:
        """Registra en MCP como tool"""
        pass
    
    def _get_sender_function(self, original_func: Callable[[Dict[str, Any]], None]) -> Callable[[Dict[str, Any]], Any]:
        """Crea handler para MCP"""
        def wraper(data : Dict[str, Any]) -> Any:
            # Retornamos directo dado que el string deuvelto por send es un json valido
            return self.m_main_pointer.send(original_func.__name__, data)
        return wraper
    
    def run(self) -> None:
        uvicorn.run(self.app,host=self.m_host,port=self.m_port_http)