#+------------------------------------------------------------------+
#| Imports                                                          |
#+------------------------------------------------------------------+
from .All import * 
 
#+------------------------------------------------------------------+
#| General                                                          |
#+------------------------------------------------------------------+
__version__ = "1.0.2"             
__author__ = "TradeSystemsNique"    
__license__ = "Niquel & Leo NL-ND P License"                
__copyright__ = "Copyright 2026, TradeSystemsNique"   


__all__ = [
"CMt5McpConection" , 
"CToolRegisterMCP", 
"CToolRegisterFastApi", 
"CToolRegister"
] 