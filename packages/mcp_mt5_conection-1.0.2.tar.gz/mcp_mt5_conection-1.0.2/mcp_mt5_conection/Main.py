from abc import ABC, abstractmethod
from typing import Dict, Any, Callable
import socket
import threading
import json
 
#+------------------------------------------------------------------+
#| CMt5McpConection                                                 |
#+------------------------------------------------------------------+
class CMt5McpConection:
    def __init__(self, host: str, port: int):
        self.m_host: str = host
        self.m_port: int = port
        self.mt5_conn = None
        
        # Iniciar servidor
        threading.Thread(target=self.esperar_mt5, daemon=True).start()
    
    def esperar_mt5(self) -> None: 
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_sock.bind((self.m_host, self.m_port))
        server_sock.listen(1)
        self.mt5_conn, _ = server_sock.accept()
        self.mt5_conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    
    # Usar el decorador del register
    def register_tool(self) -> Callable: 
        return self.m_register.register_tool_decorator()
    
    # Funcion generica para enviar datos a mt5
    def send(self, name: str, payload: Dict[str, Any]) -> str:
        if self.mt5_conn is None:
            return json.dumps({"ok": False, "error": "mt5_no_conectado"})
        
        try:
            payload_clean = json.dumps(payload, separators=(',', ':'))
            msg = f'{{"name":"{name}","data":{payload_clean}}}\n'
            
            # Enviamos
            self.mt5_conn.sendall( msg.encode("utf-8"))
            
            # Esperamos la repuesta
            response = b""
            while not response.endswith(b"\n"):
                chunk = self.mt5_conn.recv(4096)
                if not chunk:
                    return json.dumps({"ok": False, "error": "mt5_desconectado"})
                response += chunk
            
            return response.decode("utf-8").strip()
        
        except Exception as e:
            return json.dumps({"ok": False, "error": str(e)})  
        
        
#+------------------------------------------------------------------+
#| Clase Abstracta: Registrador de Tools y clase base               |
#+------------------------------------------------------------------+
class CToolRegister(ABC):
    """Clase abstracta para registrar herramientas en app/mcp"""
    
    def __init__(self, main_ptr : CMt5McpConection):
        self.m_main_pointer : CMt5McpConection = main_ptr
        self.tools : Dict[str, Callable[[Dict[str, Any]], Any]] = {} 
        
    
    @abstractmethod
    def registrar(self, tool_name: str, funcion_tool_nueva: Callable[[Dict[str, Any]], Any]) -> None:
        """Registra un tool en la plataforma"""
        pass
    
    @abstractmethod
    def _get_sender_function(self, original_func: Callable[[Dict[str, Any]], None]) -> Callable[[Dict[str, Any]], Any]:
        """Crea el handler específico (sobrescribir en subclases)"""
        pass

    def register_tool_decorator(self):
        """ 
        La idea con esta funcion es pasar uan funcion base... y luego esta con este decorador crea una nueva en su lugar
        Registrandola en el tool necesario asignale doc, valor de retorno (funcion _get_sender que retornan un puntero a funcion callable)
        """
        def decorator(func : Callable[[Dict[str, Any]], None]) -> Callable[[Dict[str, Any]], Any]:
            # Extraer nombre de la función
            tool_name = func.__name__
            
            # Extraer docstring
            docstring = func.__doc__
            
            # Crear el handler específfico
            funcion_tool_nueva : Callable[[Dict[str, Any]], Any] = self._get_sender_function(func)
             
            # Copiar metadata
            funcion_tool_nueva.__name__ = func.__name__
            funcion_tool_nueva.__doc__ = docstring

            # Registrar
            self.registrar(tool_name, funcion_tool_nueva)
            self.tools[tool_name] = funcion_tool_nueva
            
            return funcion_tool_nueva
        return decorator
    
    @abstractmethod
    def run(self) -> None:
        pass 