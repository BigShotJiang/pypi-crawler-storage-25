from .Main import *
from mcp.server.fastmcp import FastMCP

class CToolRegisterMCP(CToolRegister):
    """Registrador para MCP"""
    
    def __init__(self, config : Dict[str, Any], main_pointer: CMt5McpConection):
        super().__init__(main_pointer)
        
        # Servidor base
        self.m_mcp : FastMCP = FastMCP(config["fast_mcp"].get("name","MyServer"))

    def registrar(self, tool_name: str, funcion_tool_nueva: Callable[[Dict[str, Any]], Any]) -> None:
        """Registra en MCP como tool"""
        self.m_mcp.tool()(funcion_tool_nueva)
    
    def _get_sender_function(self, original_func: Callable[[Dict[str, Any]], None]) -> Callable[[Dict[str, Any]], Any]:
        """Crea handler para MCP"""
        def wraper(data : Dict[str, Any]) -> Any:
            return self.m_main_pointer.send(original_func.__name__,data)
        return wraper

    def run(self) -> None:
        self.m_mcp.run()