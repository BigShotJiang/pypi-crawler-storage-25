//+------------------------------------------------------------------+
//|                                                         Main.mqh |
//|                                  Copyright 2026, Niquel Mendoza. |
//|                          https://www.mql5.com/es/users/nique_372 |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Niquel Mendoza."
#property link      "https://www.mql5.com/es/users/nique_372"
#property strict

#ifndef MCPSERVER_SRC_MCP_MAIN_MQH
#define MCPSERVER_SRC_MCP_MAIN_MQH

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#include "Def.mqh"

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#import "McpServerByLeo.ex5"
IMcpBase* McpServerByLeo_Create(const string userId);
#import
//+------------------------------------------------------------------+
#endif // MCPSERVER_SRC_MCP_MAIN_MQH