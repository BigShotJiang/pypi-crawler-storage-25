//+------------------------------------------------------------------+
//|                                                          Def.mqh |
//|                                  Copyright 2026, Niquel Mendoza. |
//|                          https://www.mql5.com/es/users/nique_372 |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Niquel Mendoza."
#property link      "https://www.mql5.com/es/users/nique_372"
#property strict

#ifndef MCPSERVER_SRC_MCP_DEF_MQH
#define MCPSERVER_SRC_MCP_DEF_MQH

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#include <TSN\\Json\\Json.mqh>
#include <TSN\\MQLArticles\\Utils\\Basic.mqh>

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CMcpFunction;

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class IMcpBase : public CManagerBasesSimple<CMcpFunction, CLoggerBase>
 {
public:
                     IMcpBase() {}
                    ~IMcpBase() {}

  //---
  virtual void       Set(const int ms_timer, int ms_timeout_read_not_tls) = 0;
  virtual bool       Conectar(const string address, const uint port, const uint tiemout_para_coneccion_ms) = 0;

  //---
  virtual void       TimerEvent(void) = 0;
  virtual void       ChartEvent(const int32_t id, const long& lparam, const double& dparam, const string& sparam) = 0;
  virtual void       _RecibedEvent(const string& res) = 0;

  //---
  virtual void       Desconectar(bool cerrar_socket) = 0;
  virtual bool       Reconectar(void) = 0;

  //---
  virtual __forceinline uint Flags(void) const = 0;
  virtual __forceinline string Address(void) const = 0;
  virtual __forceinline bool IsTLS(void) const = 0;
  virtual __forceinline uint Port(void) const = 0;
 };

//+------------------------------------------------------------------+
//| Estado flags                                                     |
//+------------------------------------------------------------------+
#define MCPSERVB_BASE_POLEANDO                  (1)
#define MCPSERVB_BASE_CONECTADO                 (2)
#define MCPSERVB_BASE_ESPERANDO_FUNCIONES_ASYNC (4)


//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#define MCPSERVERBYLEO_FLAG_CHARTEVENT (1)
#define MCPSERVERBYLEO_FLAG_TIMEREVENT (2)

//---
class CMcpFunction : public CLoggerBase
 {
protected:
  IMcpBase*          m_mcp_server;
public:
                     CMcpFunction(const uint8_t flags, const bool is_async, const string& func_name_) : m_run_flags(flags), m_async(is_async), m_func_name(func_name_),
                     m_mcp_server(NULL) {}
                    ~CMcpFunction(void) {}

  //---
  const uint8_t      m_run_flags;
  const bool         m_async;
  const string       m_func_name;

  //---
  virtual void       Run(CJsonNode& param, string& res) = 0;

  //---
  // Para comunicacion
  virtual void       ChartEvent(const int32_t id, const long& lparam, const double& dparam, const string& sparam) {}
  virtual void       TimerEvent() {}

  //---
  void               MainPointer(IMcpBase* mcp_server) { m_mcp_server = mcp_server; }
 };

#endif // MCPSERVER_SRC_MCP_DEF_MQH 
//+------------------------------------------------------------------+
