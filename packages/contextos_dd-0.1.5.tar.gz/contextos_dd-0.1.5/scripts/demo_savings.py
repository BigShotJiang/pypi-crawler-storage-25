"""Real-Anthropic LinkedIn-demo harness for ContextOS.

Loads ANTHROPIC_API_KEY from .env (never prints it), spawns the daemon in an
isolated .demo/ data dir on a free port, runs a multi-turn coding-help
conversation where each turn carries the full prior history, captures per-turn
raw/sent/saved from the ledger, then writes a markdown snapshot under
snapshots/.

Run: python scripts/demo_savings.py
"""
from __future__ import annotations

import builtins as _b
import datetime as dt
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx

# Always flush stdout so background runs surface progress immediately.
_orig_print = _b.print
def _p(*a, **k):
    _orig_print(*a, **{**k, "flush": True})
_b.print = _p


REPO = Path(__file__).resolve().parent.parent
ENV_FILE = REPO / ".env"
MODEL = "claude-sonnet-4-6"
MAX_TOKENS = 400
TURN_LIMIT = 15  # cap for the demo run; full PROMPTS list is 25

PROMPTS = [
    "I want to build a Python web scraper for collecting weather data. Where do I start?",
    "Got it. Which library do you recommend: requests + BeautifulSoup, or httpx + selectolax?",
    "Let's go with httpx + selectolax. Show me a minimal example fetching one page.",
    "Now make it async so I can scrape 50 URLs in parallel.",
    "Add a semaphore to cap concurrency at 10.",
    "How do I retry transient failures? Show me a clean decorator approach.",
    "Add exponential backoff to that retry decorator.",
    "Now suppose the target site has Cloudflare. What are my options?",
    "Skip Cloudflare for now. Add a User-Agent rotation pool.",
    "How do I parse the temperature value out of a span with class 'temp'?",
    "Now I need to persist results. Compare SQLite vs DuckDB for this workload.",
    "Let's use DuckDB. Show the schema and an upsert pattern.",
    "Wrap the scraper in a CLI using Typer. Commands: 'scrape', 'export', 'stats'.",
    "Add structured logging with structlog. Include URL and duration on every fetch.",
    "I want a progress bar. Rich or tqdm?",
    "Use Rich. Show me integration with the async loop.",
    "How do I test this? Outline a pytest strategy that doesn't hit the live site.",
    "Show me a test using respx to mock httpx responses.",
    "Now the test for the retry decorator: how do I make it deterministic?",
    "Add a Dockerfile. Multi-stage build, minimal final image.",
    "What's the right base image for httpx + DuckDB? python:3.12-slim?",
    "How do I schedule this to run hourly? cron vs systemd timer vs APScheduler in-process?",
    "Let's do APScheduler. Show the integration with the existing CLI.",
    "Finally, how do I expose a /metrics endpoint for Prometheus to scrape this scraper?",
    "Summarize the full architecture in 5 bullet points so I can paste it into a README.",
]


def load_env(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def wait_health(url: str, timeout_s: float = 30.0) -> bool:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        try:
            if httpx.get(url, timeout=1.0).status_code == 200:
                return True
        except httpx.HTTPError:
            time.sleep(0.3)
    return False


def first_text_block(resp_json: dict) -> str:
    for b in resp_json.get("content", []):
        if b.get("type") == "text":
            return b.get("text", "")
    return ""


def main() -> int:
    if not ENV_FILE.exists():
        print("ERROR: .env not found at", ENV_FILE)
        return 1
    key = load_env(ENV_FILE).get("ANTHROPIC_API_KEY")
    if not key or not key.startswith("sk-ant-"):
        print("ERROR: ANTHROPIC_API_KEY missing or malformed in .env")
        return 1
    print(f"[ok] loaded key (prefix '{key[:8]}***')")

    port = free_port()
    data_dir = REPO / ".demo" / "data"
    log_dir = REPO / ".demo" / "logs"
    data_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)

    proc_env = os.environ.copy()
    upstream = os.environ.get(
        "DEMO_UPSTREAM", "https://api.anthropic.com",
    )  # set DEMO_UPSTREAM=http://127.0.0.1:9999 to hit the local mock
    proc_env.update({
        "CONTEXTOS_DATA_DIR": str(data_dir),
        "CONTEXTOS_LOG_DIR": str(log_dir),
        "CONTEXTOS_PROXY_PORT": str(port),
        "CONTEXTOS_ANTHROPIC_UPSTREAM": upstream,
        "PYTHONUNBUFFERED": "1",
    })
    print(f"[ok] using upstream: {upstream}")

    # Daemon stdout/stderr MUST go to files, not subprocess.PIPE. With PIPE
    # the OS buffer (4 KB on Windows anonymous pipes) fills after a few hundred
    # log lines, daemon writes block, Python's logging RLock is held forever,
    # and the asyncio event loop freezes mid-request. Production (`contextos
    # start`) already redirects to files for this same reason.
    daemon_stdout = open(log_dir / "harness_daemon.stdout.log", "ab", buffering=0)
    daemon_stderr = open(log_dir / "harness_daemon.stderr.log", "ab", buffering=0)
    print(f"[..] starting daemon on 127.0.0.1:{port}")
    proc = subprocess.Popen(
        [sys.executable, "-m", "contextos.daemon"],
        env=proc_env,
        stdout=daemon_stdout,
        stderr=daemon_stderr,
    )
    base = f"http://127.0.0.1:{port}"
    try:
        if not wait_health(f"{base}/_contextos/health"):
            err = (log_dir / "harness_daemon.stderr.log").read_text(errors="ignore")[-1500:]
            print("ERROR: daemon never healthy. stderr tail:\n", err)
            return 1
        print("[ok] daemon healthy")

        headers = {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
            "user-agent": "contextos-demo/0.1",
        }
        history: list[dict] = []
        rows: list[dict] = []
        prev_raw = 0
        prev_sent = 0
        prev_saved_usd = 0.0

        prompts = PROMPTS[:TURN_LIMIT]
        for i, user_prompt in enumerate(prompts, 1):
            history.append({"role": "user", "content": user_prompt})
            body = {"model": MODEL, "max_tokens": MAX_TOKENS, "messages": history}
            t0 = time.time()
            r = None
            for attempt in range(2):
                try:
                    r = httpx.post(
                        f"{base}/v1/messages", json=body, headers=headers, timeout=150.0,
                    )
                    break
                except httpx.HTTPError as e:
                    print(f"  turn {i:02d}: attempt {attempt+1} HTTP error {e}")
                    time.sleep(2.0)
            if r is None:
                print(f"  turn {i:02d}: both attempts failed; skipping turn")
                history.pop()
                continue
            dur = time.time() - t0
            if r.status_code != 200:
                print(f"  turn {i:02d}: status {r.status_code} body={r.text[:200]}")
                history.pop()
                continue
            assistant_text = first_text_block(r.json())
            history.append({"role": "assistant", "content": assistant_text})

            try:
                stats = httpx.get(f"{base}/_contextos/stats", timeout=15.0).json()
            except httpx.HTTPError as e:
                print(f"  turn {i:02d}: stats fetch failed {e}; continuing")
                continue
            cum_raw = int(stats.get("raw_tokens", 0))
            cum_sent = int(stats.get("sent_tokens", 0))
            cum_usd = float(stats.get("savings_usd", 0.0))
            d_raw = cum_raw - prev_raw
            d_sent = cum_sent - prev_sent
            d_saved = max(0, d_raw - d_sent)
            d_usd = cum_usd - prev_saved_usd
            prev_raw, prev_sent, prev_saved_usd = cum_raw, cum_sent, cum_usd
            pct = (100.0 * d_saved / d_raw) if d_raw else 0.0
            rows.append({
                "turn": i, "raw": d_raw, "sent": d_sent, "saved": d_saved,
                "pct": pct, "usd": d_usd, "ms": int(dur * 1000),
            })
            print(f"  turn {i:02d}: raw={d_raw:6d}  sent={d_sent:6d}  "
                  f"saved={d_saved:5d} ({pct:5.1f}%)  ${d_usd:0.5f}  {int(dur*1000)}ms")
            time.sleep(0.3)

        stats: dict = {}
        sessions: list = []
        try:
            stats = httpx.get(f"{base}/_contextos/stats", timeout=30.0).json()
            sessions = httpx.get(f"{base}/_contextos/sessions", timeout=30.0).json()
        except httpx.HTTPError as e:
            print(f"[warn] final stats fetch failed: {e}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            proc.kill()

    total_raw = sum(r["raw"] for r in rows)
    total_sent = sum(r["sent"] for r in rows)
    total_saved = total_raw - total_sent
    total_usd = sum(r["usd"] for r in rows)
    total_pct = (100.0 * total_saved / total_raw) if total_raw else 0.0

    print("\n========== FINAL ==========")
    print(f"  turns       : {len(rows)}")
    print(f"  raw tokens  : {total_raw:,}")
    print(f"  sent tokens : {total_sent:,}")
    print(f"  saved       : {total_saved:,}  ({total_pct:.1f}%)")
    print(f"  $ saved     : ${total_usd:.4f}")

    snap_dir = REPO / "snapshots"
    snap_dir.mkdir(exist_ok=True)
    ts = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    md_path = snap_dir / f"demo-{ts}.md"

    import json as _json
    lines: list[str] = []
    lines.append(f"# ContextOS live demo — {ts}\n")
    lines.append(f"- Model: `{MODEL}`")
    lines.append(f"- Turns: **{len(rows)}**")
    lines.append(f"- Raw tokens (what your IDE wanted to send): **{total_raw:,}**")
    lines.append(f"- Sent tokens (what ContextOS actually forwarded): **{total_sent:,}**")
    lines.append(f"- Tokens saved: **{total_saved:,}** (**{total_pct:.1f}%**)")
    lines.append(f"- USD saved: **${total_usd:.4f}**\n")
    lines.append("## Per-turn breakdown\n")
    lines.append("| Turn | Raw | Sent | Saved | Saved % | $ saved | Latency |")
    lines.append("|---:|---:|---:|---:|---:|---:|---:|")
    for r in rows:
        lines.append(
            f"| {r['turn']} | {r['raw']:,} | {r['sent']:,} | {r['saved']:,} | "
            f"{r['pct']:.1f}% | ${r['usd']:.5f} | {r['ms']} ms |"
        )
    lines.append("\n## Raw stats endpoint dump\n```json")
    lines.append(_json.dumps(stats, indent=2))
    lines.append("```\n\n## Sessions endpoint dump\n```json")
    lines.append(_json.dumps(sessions, indent=2))
    lines.append("```")
    md_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"\n[ok] snapshot written: {md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
