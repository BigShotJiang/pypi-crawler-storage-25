"""Tiny fake Anthropic /v1/messages server for offline debugging.

Runs on 127.0.0.1:9999, accepts POST /v1/messages, returns a canned response
that looks structurally like a real Sonnet response. Lets us repro proxy
behavior end-to-end without spending real API credits.

Usage:
    python scripts/mock_anthropic.py
Then set CONTEXTOS_ANTHROPIC_UPSTREAM=http://127.0.0.1:9999 before starting
the daemon.
"""
from __future__ import annotations

import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CANNED_TEXT = (
    "Sure — here is a brief, illustrative response. "
    "Use httpx and selectolax for the scraping; add a "
    "semaphore-bound async loop to cap concurrency. For "
    "persistence, DuckDB is a great fit because it can "
    "ingest CSV/Parquet directly and supports upserts. "
    "Wrap the entry-point in a Typer CLI so it composes well. "
)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args) -> None:  # silence default per-line log
        return

    def do_POST(self) -> None:
        n = int(self.headers.get("content-length", "0"))
        _ = self.rfile.read(n)  # discard body
        body = {
            "id": f"msg_{int(time.time()*1000)}",
            "type": "message",
            "role": "assistant",
            "model": "claude-sonnet-4-6",
            "content": [{"type": "text", "text": CANNED_TEXT}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 100, "output_tokens": 80},
        }
        payload = json.dumps(body).encode("utf-8")
        self.send_response(200)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


def main() -> None:
    srv = ThreadingHTTPServer(("127.0.0.1", 9999), Handler)
    print("mock anthropic listening on http://127.0.0.1:9999")
    srv.serve_forever()


if __name__ == "__main__":
    main()
