from __future__ import annotations

import contextlib
import logging
import os
import signal
from pathlib import Path

import uvicorn

from contextos.proxy import create_app
from contextos.settings import configure_logging, get_settings

log = logging.getLogger("contextos.daemon")


def _warmup_app(app) -> None:
    """Download + load the local models *before* the proxy starts serving.
    Without this, the first compaction job triggers a 400 MB Hugging Face
    download and a llama-cpp model load on a thread that — despite being
    submitted via run_in_threadpool — blocks the asyncio event loop on
    Windows. Result: every IDE request stalls for several minutes mid-session.

    Doing the work at startup converts that mid-conversation freeze into a
    one-time slower 'contextos start' (only on first run; subsequent starts
    are fast because the GGUF is cached).

    Set CONTEXTOS_SKIP_WARMUP=1 to opt out (e.g., for dev iteration).
    """
    if os.environ.get("CONTEXTOS_SKIP_WARMUP", "").lower() in {"1", "true", "yes"}:
        log.info("warmup skipped (CONTEXTOS_SKIP_WARMUP set)")
        return
    if app.state.generator is None:
        # Compactor disabled — no local models to warm up.
        return
    s = app.state.settings
    log.info("warmup: ensuring local models cached (first run downloads ~430 MB)")
    try:
        from contextos.llm.warmup import warmup
        warmup(s, on_progress=lambda m: log.info("warmup: %s", m))
        app.state.generator._ensure_loaded()
        log.info("warmup: models ready")
    except Exception as e:
        log.warning("warmup failed: %s — proxy will start without local models", e)


def run() -> None:
    s = get_settings()
    configure_logging(s)
    s.pid_file.write_text(str(os.getpid()), encoding="utf-8")
    app = create_app(s)
    _warmup_app(app)
    try:
        uvicorn.run(
            app,
            host=s.proxy_host,
            port=s.proxy_port,
            log_config=None,
            access_log=False,
        )
    finally:
        with contextlib.suppress(FileNotFoundError):
            s.pid_file.unlink()


def read_pid(pid_file: Path) -> int | None:
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except (FileNotFoundError, ValueError):
        return None


def stop() -> bool:
    s = get_settings()
    pid = read_pid(s.pid_file)
    if pid is None:
        return False
    try:
        os.kill(pid, signal.SIGTERM)
        return True
    except (OSError, ProcessLookupError):
        return False


if __name__ == "__main__":
    run()
