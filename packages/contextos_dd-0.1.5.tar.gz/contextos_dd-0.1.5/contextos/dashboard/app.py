"""Streamlit dashboard for ContextOS — corporate-muted, info-dense version.

Visual design goals:
- one hero strip of KPIs at the top, with an auto-narrated headline
- tabbed body: Overview, Sessions, Memory map, Activity
- native st.dataframe with column_config for in-cell progress bars and pills
- Altair charts (no extra deps) for time-series, donuts, stacked heat bars
- corporate muted palette: teal-greens, deep blues, slate-blacks, restrained accents
"""
from __future__ import annotations

from datetime import datetime

import altair as alt
import pandas as pd
import polars as pl
import streamlit as st

from contextos import __version__
from contextos.dashboard import queries
from contextos.dashboard.queries import DaemonUnreachable
from contextos.settings import get_settings

try:
    from streamlit_autorefresh import st_autorefresh
except ImportError:
    st_autorefresh = None


# Brand palette — pick from here, do not introduce ad-hoc hex values elsewhere.
TEAL_900 = "#134e4a"
TEAL_700 = "#0f766e"
TEAL_500 = "#14b8a6"
TEAL_300 = "#5eead4"
SKY_700  = "#0369a1"
SKY_500  = "#0ea5e9"
SLATE_900 = "#0f172a"
SLATE_700 = "#334155"
SLATE_500 = "#64748b"
SLATE_300 = "#cbd5e1"
AMBER_600 = "#d97706"     # warm contrast, used sparingly (HOT heat)
EMERALD_600 = "#047857"   # savings green


# ---------------------------------------------------------------- page chrome
st.set_page_config(
    page_title="ContextOS",
    page_icon="🧊",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# A little CSS polish: tighter padding, nicer metric cards, badge styling.
st.markdown(
    """
    <style>
      .block-container { padding-top: 1.5rem; padding-bottom: 2rem; }
      [data-testid="stMetric"] {
        background: linear-gradient(135deg, rgba(15,118,110,0.06), rgba(3,105,161,0.04));
        border: 1px solid rgba(15,118,110,0.20);
        padding: 14px 18px; border-radius: 12px;
      }
      [data-testid="stMetricValue"] { font-weight: 700; font-size: 1.7rem; color:#0f172a; }
      [data-testid="stMetricLabel"] { color: #64748b; letter-spacing: .06em; font-size: .72rem; }
      .pill {
        display: inline-block; padding: 2px 10px; border-radius: 999px;
        font-size: 0.76rem; font-weight: 600; letter-spacing: .02em;
        margin-right: 6px;
      }
      .pill-hot   { background:#fef3c7; color:#92400e; }            /* amber */
      .pill-warm  { background:#ccfbf1; color:#0f766e; }            /* teal-light */
      .pill-cold  { background:#e0f2fe; color:#0369a1; }            /* sky */
      .pill-dead  { background:#e2e8f0; color:#334155; }            /* slate */
      .pill-ide   { background:#ccfbf1; color:#0f766e; border:1px solid #5eead4; }
      .pill-model { background:#e0f2fe; color:#0369a1; border:1px solid #7dd3fc; }
      .narrative {
        font-size: 1.04rem; line-height: 1.6;
        background: linear-gradient(135deg, #0f172a, #134e4a);
        color: #e2e8f0; padding: 18px 22px; border-radius: 12px;
        border-left: 4px solid #14b8a6;
      }
      .narrative b { color: #5eead4; font-weight: 700; }
      .empty-card {
        text-align:center; padding: 36px 12px;
        background: rgba(15,118,110,0.04);
        border: 1px dashed rgba(15,118,110,0.35);
        border-radius: 12px;
      }
    </style>
    """,
    unsafe_allow_html=True,
)

settings = get_settings()
base_url = f"http://{settings.proxy_host}:{settings.proxy_port}"

if st_autorefresh is not None:
    st_autorefresh(interval=4000, limit=1800, key="contextos-tick")


# ---------------------------------------------------------------- header
top_l, top_r = st.columns([4, 1])
with top_l:
    st.markdown(
        "## 🧊 ContextOS — *agentic memory lifecycle, on your machine*"
    )
    st.caption(
        f"v{__version__} · daemon `{base_url}` · "
        f"auto-refresh every 4s · {datetime.now().strftime('%a %d %b %Y · %H:%M:%S')}"
    )
with top_r:
    st.markdown(
        "<div style='text-align:right;padding-top:18px'>"
        "<span class='pill pill-ide'>local-only</span>"
        "<span class='pill pill-model'>no telemetry</span>"
        "</div>",
        unsafe_allow_html=True,
    )

# ---------------------------------------------------------------- daemon check
try:
    t = queries.totals(base_url)
except DaemonUnreachable as e:
    st.error(
        f"Cannot reach the daemon at {base_url}.\n\n"
        "Start it with `contextos start` in another terminal, then refresh."
    )
    st.caption(f"Details: {e}")
    st.stop()


# ---------------------------------------------------------------- KPI strip
k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("SESSIONS", f"{t.sessions:,}")
k2.metric("RAW TOKENS IN", f"{t.raw_tokens:,}")
k3.metric("SENT UPSTREAM", f"{t.sent_tokens:,}")
k4.metric(
    "TOKENS SAVED",
    f"{t.saved_tokens:,}",
    delta=f"{t.reduction_pct:.1f}% trimmed" if t.raw_tokens else None,
    delta_color="normal",
)
k5.metric(
    "USD SAVED",
    f"${t.savings_usd:,.4f}",
    delta="estimated at vendor list prices" if t.savings_usd else None,
    delta_color="off",
)


# ---------------------------------------------------------------- narrative
def _narrative(totals, sessions_rows: list[dict]) -> str:
    if not sessions_rows or totals.raw_tokens == 0:
        return (
            "<b>Waiting for traffic.</b> Run a call from Claude Code, Cursor, "
            "Codex, Continue, or Aider — this dashboard will fill in within "
            "seconds. No data leaves your machine."
        )
    n_ide = len({r["ide"] for r in sessions_rows if r["ide"] not in ("-", None)})
    n_model = len({r["model"] for r in sessions_rows if r["model"] not in ("-", None)})
    top_session = max(sessions_rows, key=lambda r: r["saved"])
    return (
        f"Across <b>{totals.sessions:,} session(s)</b> spanning "
        f"<b>{max(n_ide,1)} IDE(s)</b> and <b>{max(n_model,1)} model(s)</b>, "
        f"ContextOS has trimmed <b>{totals.saved_tokens:,} tokens "
        f"({totals.reduction_pct:.1f}%)</b> before they reached the cloud — "
        f"saving an estimated <b>${totals.savings_usd:,.4f}</b>. "
        f"Best single session so far: <b>{top_session['saved']:,} tokens</b> "
        f"({top_session['reduction_pct']:.1f}%) on "
        f"<i>{top_session['model']}</i>."
    )

try:
    sessions_rows = queries.sessions(base_url, limit=50)
except DaemonUnreachable:
    sessions_rows = []

st.markdown(
    f"<div class='narrative'>{_narrative(t, sessions_rows)}</div>",
    unsafe_allow_html=True,
)
st.write("")  # breathing room


# ---------------------------------------------------------------- tabs
tab_overview, tab_sessions, tab_memory, tab_activity = st.tabs([
    "📊 Overview",
    "💬 Sessions",
    "🧠 Memory map",
    "📈 Activity",
])


def _ide_emoji(ide: str) -> str:
    return {
        "claude-code": "🟠", "cursor": "🟣", "codex": "🟢",
        "continue": "🔵", "aider": "🟡",
    }.get(ide, "⚪")


def _pretty_sessions_df(rows: list[dict]) -> pd.DataFrame:
    df = pl.DataFrame(rows).to_pandas()
    df["IDE"] = df["ide"].map(lambda i: f"{_ide_emoji(i)}  {i}")
    df["Model"] = df["model"]
    df["Started"] = pd.to_datetime(df["started_at"], errors="coerce")
    df = df.rename(columns={
        "raw_tokens": "Raw",
        "sent_tokens": "Sent",
        "saved": "Saved",
        "reduction_pct": "Reduction",
        "savings_usd": "$ saved",
        "session_id": "Session",
    })
    return df[["Session", "IDE", "Model", "Started",
               "Raw", "Sent", "Saved", "Reduction", "$ saved"]]


# ---------------------------------------------------------------- Overview tab
with tab_overview:
    if not sessions_rows:
        st.markdown(
            "<div class='empty-card'>"
            "<h3>No traffic yet</h3>"
            "<p>Run any chat request through Claude Code / Cursor / Codex.<br>"
            "Within a few seconds you'll see sessions, savings, and the "
            "memory heat map appear here.</p>"
            "</div>",
            unsafe_allow_html=True,
        )
    else:
        left, right = st.columns([3, 2], gap="large")

        with left:
            st.markdown("##### 📉 Trim ratio per session")
            st.caption(
                "How aggressively the pipeline could shrink each session's "
                "payload. Higher is better. New sessions show 0% until enough "
                "history accumulates for COLD/DEAD detection to fire."
            )
            df = pl.DataFrame(sessions_rows).to_pandas()
            chart = (
                alt.Chart(df)
                .mark_bar(cornerRadiusTopLeft=4, cornerRadiusTopRight=4)
                .encode(
                    x=alt.X("session_id:N", title=None,
                            axis=alt.Axis(labelAngle=-30, labelLimit=80)),
                    y=alt.Y("reduction_pct:Q", title="reduction %",
                            scale=alt.Scale(domain=[0, 100])),
                    color=alt.Color(
                        "reduction_pct:Q",
                        scale=alt.Scale(
                            domain=[0, 50, 100],
                            range=[SLATE_300, TEAL_500, TEAL_900],
                        ),
                        legend=None,
                    ),
                    tooltip=[
                        alt.Tooltip("session_id:N", title="session"),
                        alt.Tooltip("ide:N"),
                        alt.Tooltip("model:N"),
                        alt.Tooltip("raw_tokens:Q", title="raw", format=","),
                        alt.Tooltip("sent_tokens:Q", title="sent", format=","),
                        alt.Tooltip("saved:Q", format=","),
                        alt.Tooltip("reduction_pct:Q",
                                    title="reduction %", format=".1f"),
                    ],
                )
                .properties(height=320)
            )
            st.altair_chart(chart, use_container_width=True)

        with right:
            st.markdown("##### 🍩 Where the savings come from")
            st.caption(
                "Donut by model — the bigger slices are where ContextOS is "
                "earning its keep for you."
            )
            by_model = queries.by_dimension(base_url, "model")
            if by_model:
                bm_df = pd.DataFrame(by_model)
                # Avoid all-zero domain (donut needs >0 to render).
                if bm_df["saved"].sum() > 0:
                    donut = (
                        alt.Chart(bm_df)
                        .mark_arc(innerRadius=55, outerRadius=110)
                        .encode(
                            theta=alt.Theta("saved:Q", stack=True),
                            color=alt.Color(
                                "key:N", title="model",
                                scale=alt.Scale(
                                    range=[TEAL_700, SKY_700, TEAL_500,
                                           SKY_500, TEAL_300, SLATE_500,
                                           SLATE_700, SLATE_900],
                                ),
                            ),
                            tooltip=[
                                alt.Tooltip("key:N", title="model"),
                                alt.Tooltip("saved:Q", format=","),
                                alt.Tooltip("savings_usd:Q", title="$",
                                            format="$.4f"),
                            ],
                        )
                        .properties(height=280)
                    )
                    st.altair_chart(donut, use_container_width=True)
                else:
                    st.info("No savings recorded yet — try a few more turns.")
            else:
                st.info("No model data yet.")

        st.divider()

        # By IDE — horizontal bar with $ saved
        st.markdown("##### 🛠️ Savings by IDE")
        st.caption(
            "Group your $ saved by the AI IDE that produced the traffic. "
            "Useful for deciding where ContextOS pays off most."
        )
        by_ide = queries.by_dimension(base_url, "ide")
        if by_ide:
            bi_df = pd.DataFrame(by_ide)
            chart = (
                alt.Chart(bi_df)
                .mark_bar(cornerRadiusEnd=4, color=TEAL_700)
                .encode(
                    x=alt.X("savings_usd:Q", title="USD saved",
                            axis=alt.Axis(format="$.4f")),
                    y=alt.Y("key:N", title=None, sort="-x"),
                    color=alt.Color(
                        "savings_usd:Q", legend=None,
                        scale=alt.Scale(
                            range=[SLATE_300, TEAL_500, TEAL_700, TEAL_900],
                        ),
                    ),
                    tooltip=[
                        alt.Tooltip("key:N", title="IDE"),
                        alt.Tooltip("raw_tokens:Q", title="raw", format=","),
                        alt.Tooltip("sent_tokens:Q", title="sent", format=","),
                        alt.Tooltip("saved:Q", format=","),
                        alt.Tooltip("savings_usd:Q", title="USD saved",
                                    format="$.4f"),
                    ],
                )
                .properties(height=max(120, 38 * len(bi_df)))
            )
            st.altair_chart(chart, use_container_width=True)
        else:
            st.info("No IDE breakdown yet.")


# ---------------------------------------------------------------- Sessions tab
with tab_sessions:
    st.markdown("##### Recent sessions")
    st.caption(
        "Each row is one running session keyed by the upstream API-key hash. "
        "The reduction bar is the live trim ratio; click a header to sort."
    )
    if not sessions_rows:
        st.info("No sessions yet.")
    else:
        df = _pretty_sessions_df(sessions_rows)
        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "Session": st.column_config.TextColumn(
                    "Session", help="API-key hash", width="small",
                ),
                "IDE": st.column_config.TextColumn("IDE", width="small"),
                "Model": st.column_config.TextColumn("Model", width="medium"),
                "Started": st.column_config.DatetimeColumn(
                    "Started", format="MMM D · HH:mm:ss",
                ),
                "Raw": st.column_config.NumberColumn(
                    "Raw", format="%d", help="tokens your IDE wanted to send",
                ),
                "Sent": st.column_config.NumberColumn(
                    "Sent", format="%d", help="tokens we actually forwarded",
                ),
                "Saved": st.column_config.NumberColumn(
                    "Saved", format="%d",
                ),
                "Reduction": st.column_config.ProgressColumn(
                    "Reduction", format="%.1f%%", min_value=0.0, max_value=100.0,
                ),
                "$ saved": st.column_config.NumberColumn(
                    "$ saved", format="$%.4f",
                ),
            },
        )


# ---------------------------------------------------------------- Memory tab
with tab_memory:
    st.markdown("##### Per-session memory heat")
    st.caption(
        "Every turn ever recorded for the selected session, colored by "
        "current heat. **HOT** turns are forwarded verbatim; **WARM** stay "
        "in but may be trimmed; **COLD** runs collapse into a placeholder "
        "(or a Qwen-summary if the compactor is enabled); **DEAD** are "
        "deduped exact repeats."
    )
    if not sessions_rows:
        st.info("Pick a session here after you've run some traffic.")
    else:
        sid_options = {
            f"{_ide_emoji(r['ide'])} {r['session_id']} · "
            f"{r['model']} · saved {r['saved']:,} ({r['reduction_pct']:.0f}%)": r["session_id"]
            for r in sessions_rows
        }
        label = st.selectbox("Session", list(sid_options.keys()), index=0)
        selected = sid_options[label]
        mm = queries.memory_map(base_url, selected)

        if not mm:
            st.info("This session has no turns recorded yet.")
        else:
            # Legend strip
            legend = (
                "<span class='pill pill-hot'>🔥 HOT (verbatim)</span>"
                "<span class='pill pill-warm'>☀️ WARM (eligible)</span>"
                "<span class='pill pill-cold'>❄️ COLD (collapse / summarize)</span>"
                "<span class='pill pill-dead'>💀 DEAD (deduped)</span>"
            )
            st.markdown(legend, unsafe_allow_html=True)

            mm_df = pd.DataFrame(mm)
            heat_color = {"HOT": AMBER_600, "WARM": TEAL_500,
                          "COLD": SKY_700, "DEAD": SLATE_500}
            heat_order = ["HOT", "WARM", "COLD", "DEAD"]

            chart = (
                alt.Chart(mm_df)
                .mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3)
                .encode(
                    x=alt.X("turn_index:O", title="turn"),
                    y=alt.Y("tokens:Q", title="tokens"),
                    color=alt.Color(
                        "heat:N", title="heat",
                        scale=alt.Scale(
                            domain=heat_order,
                            range=[heat_color[h] for h in heat_order],
                        ),
                        legend=alt.Legend(orient="top", direction="horizontal"),
                    ),
                    tooltip=[
                        alt.Tooltip("turn_index:O", title="turn"),
                        alt.Tooltip("role:N"),
                        alt.Tooltip("heat:N"),
                        alt.Tooltip("tokens:Q", format=","),
                    ],
                )
                .properties(height=320)
            )
            st.altair_chart(chart, use_container_width=True)

            # Heat tally pills
            counts = mm_df["heat"].value_counts().to_dict()
            tally = " ".join(
                f"<span class='pill pill-{h.lower()}'>"
                f"{ {'HOT':'🔥','WARM':'☀️','COLD':'❄️','DEAD':'💀'}[h] } "
                f"{h}: {counts.get(h,0)}</span>"
                for h in heat_order
            )
            st.markdown(tally, unsafe_allow_html=True)


# ---------------------------------------------------------------- Activity tab
with tab_activity:
    st.markdown("##### Savings activity — last 14 days")
    st.caption(
        "Daily rollup of every payload ContextOS trimmed. The green area is "
        "what we saved; the line is what still went upstream. Empty days "
        "mean no traffic, not a failure."
    )
    try:
        tl = queries.timeline(base_url, days=14)
    except DaemonUnreachable as e:
        st.error(f"Could not load timeline: {e}")
        tl = []

    if not tl:
        st.info("No request history yet. Run some traffic to populate this view.")
    else:
        tl_df = pd.DataFrame(tl)
        tl_df["date"] = pd.to_datetime(tl_df["date"])

        long = tl_df.melt(
            id_vars=["date", "requests"],
            value_vars=["sent", "saved"],
            var_name="series", value_name="tokens",
        )
        stacked = (
            alt.Chart(long)
            .mark_area(opacity=0.85, interpolate="monotone")
            .encode(
                x=alt.X("date:T", title=None),
                y=alt.Y("tokens:Q", title="tokens", stack="zero"),
                color=alt.Color(
                    "series:N",
                    scale=alt.Scale(
                        domain=["saved", "sent"],
                        range=[EMERALD_600, SLATE_500],
                    ),
                    legend=alt.Legend(orient="top", title=None),
                ),
                tooltip=[
                    alt.Tooltip("date:T", format="%b %d"),
                    alt.Tooltip("series:N"),
                    alt.Tooltip("tokens:Q", format=","),
                    alt.Tooltip("requests:Q", title="reqs that day"),
                ],
            )
            .properties(height=320)
        )
        st.altair_chart(stacked, use_container_width=True)

        # Daily table with pills
        daily = tl_df.assign(
            reduction=lambda d: (100 * d["saved"] / (d["sent"] + d["saved"])
                                  .where(d["sent"] + d["saved"] > 0, 1)),
        )[["date", "requests", "raw", "sent", "saved", "reduction"]]
        st.dataframe(
            daily, use_container_width=True, hide_index=True,
            column_config={
                "date": st.column_config.DateColumn("Day", format="MMM D"),
                "requests": st.column_config.NumberColumn("Requests"),
                "raw": st.column_config.NumberColumn("Raw", format="%d"),
                "sent": st.column_config.NumberColumn("Sent", format="%d"),
                "saved": st.column_config.NumberColumn("Saved", format="%d"),
                "reduction": st.column_config.ProgressColumn(
                    "Reduction", format="%.1f%%",
                    min_value=0.0, max_value=100.0,
                ),
            },
        )

# ---------------------------------------------------------------- footer
st.divider()
st.caption(
    "🧊 ContextOS · local-first agentic memory · "
    "issues / requests → github.com/skappal7/context-os"
)
