"""Jira Ticket Updater v1.1.1 - Main entry point for the CLI application."""

import os
import sys

# Handle imports for both package execution and direct execution
try:
    from .cli_handlers import parse_arguments, process_issue_operation
except ImportError:
    # Running as script - add parent directory to path
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from cli_handlers import parse_arguments, process_issue_operation


def main():
    """Main entry point for the jira-ticket-updater v1.1.1 command-line tool."""
    # Check for --version flag first (works for all execution methods)
    if "--version" in sys.argv or "-v" in sys.argv:
        try:
            import jira_ticket_updater
            version = jira_ticket_updater.__version__
        except (ImportError, AttributeError):
            try:
                from . import __version__
                version = __version__
            except (ImportError, AttributeError):
                version = "unknown"
        print(f"jira-ticket-updater {version}")
        sys.exit(0)
    
    parsed_args = parse_arguments(sys.argv[1:])
    if parsed_args is None:
        sys.exit(1)
    
    # Handle version flag (backup check)
    if parsed_args.get("version"):
        sys.exit(0)

    success = process_issue_operation(parsed_args)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    # Check for --version flag first (doesn't require env vars)
    if "--version" in sys.argv or "-v" in sys.argv:
        try:
            import jira_ticket_updater
            version = jira_ticket_updater.__version__
        except (ImportError, AttributeError):
            try:
                from . import __version__
                version = __version__
            except (ImportError, AttributeError):
                version = "unknown"
        print(f"jira-ticket-updater {version}")
        sys.exit(0)
    
    # Check for ENV variables
    missing_env_vars = []
    if not os.environ.get("JIRA_EMAIL"):
        missing_env_vars.append("JIRA_EMAIL")
    if not os.environ.get("JIRA_API_TOKEN"):
        missing_env_vars.append("JIRA_API_TOKEN")
    if not os.environ.get("JIRA_BASE_URL"):
        missing_env_vars.append("JIRA_BASE_URL")
    if missing_env_vars:
        print(
            f"Missing environment variables: {', '.join(missing_env_vars)}. Please set them in the environment variables."
        )
        sys.exit(1)
    try:
        main()
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
