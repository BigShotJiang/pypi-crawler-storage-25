"""
impulse_telemetry — usage examples

Each example is self-contained and ordered from simplest to most advanced.
"""

# ---------------------------------------------------------------------------
# 1. Basic setup (FastAPI service)
# ---------------------------------------------------------------------------

from fastapi import FastAPI
from impulse_telemetry import init

app = FastAPI()
init(app, service="my-service", version="1.0.0", env="production")

# That's it. Every HTTP request now gets:
#   - Prometheus RED metrics  (http_requests_total, latency, errors)
#   - A distributed trace     (exported via OTLP gRPC)
#   - A structured JSON log line


# ---------------------------------------------------------------------------
# 2. Structured logging
# ---------------------------------------------------------------------------

from impulse_telemetry.logging import get_logger

log = get_logger(__name__)

log.info("server_started", port=8080)
# {"service":"my-service","env":"production","event":"server_started","port":8080,
#  "trace_id":"abc123","span_id":"def456","timestamp":"2026-03-19T10:00:00Z"}


# ---------------------------------------------------------------------------
# 3. Per-request context (user_id, request_id automatically on every log)
# ---------------------------------------------------------------------------

from impulse_telemetry.logging import bind_request_context, clear_request_context

async def handle_request(user_id: str, request_id: str):
    token = bind_request_context(user_id=user_id, request_id=request_id)
    try:
        log.info("processing")           # user_id + request_id injected automatically
        log.warning("slow_query", ms=320)
    finally:
        clear_request_context(token)


# ---------------------------------------------------------------------------
# 4. Manual span + propagating trace headers to downstream services
# ---------------------------------------------------------------------------

import requests
from impulse_telemetry.tracing import get_tracer, inject_headers

tracer = get_tracer(__name__)

def call_downstream():
    with tracer.start_as_current_span("downstream_call") as span:
        span.set_attribute("downstream.service", "inventory")
        headers = inject_headers({})          # adds W3C traceparent header
        resp = requests.get("http://inventory-service/items", headers=headers)
        span.set_attribute("http.status_code", resp.status_code)
        return resp.json()


# ---------------------------------------------------------------------------
# 5. Recording infrastructure metrics manually
# ---------------------------------------------------------------------------

from impulse_telemetry.metrics import get_metrics

m = get_metrics()

def call_redis(key: str):
    with tracer.start_as_current_span("redis_get"):
        import time, redis
        client = redis.Redis()
        start = time.perf_counter()
        try:
            value = client.get(key)
        except Exception:
            m.dependency_errors.labels(**m.labels(dependency="redis")).inc()
            raise
        finally:
            elapsed = time.perf_counter() - start
            m.dependency_latency.labels(**m.labels(dependency="redis")).observe(elapsed)
    return value


# ---------------------------------------------------------------------------
# 6. ML inference monitoring
# ---------------------------------------------------------------------------

import pandas as pd
from impulse_telemetry import init
from impulse_telemetry.ml import MLMonitor, InferenceMetrics

# Register InferenceMetrics at startup
init(app, service="rec-service", optional_metrics=[InferenceMetrics()])

monitor = MLMonitor(model_id="rec-v3", user_id="usr_42")

def predict(features: pd.DataFrame):
    with monitor.inference(features=features) as span:
        result = model.predict(features)   # your model here
        span.record_output(result)         # records output shape/sample
        span.set("custom_attr", "value")   # arbitrary span attributes
    return result


# ---------------------------------------------------------------------------
# 7. ML monitoring — decorator style
# ---------------------------------------------------------------------------

@monitor.trace
def score(features: pd.DataFrame):
    return model.predict(features)        # latency + errors tracked automatically


# ---------------------------------------------------------------------------
# 8. Recording drift and model performance metrics
# ---------------------------------------------------------------------------

# Call from a batch evaluation job, not the hot path
monitor.record_drift("age", score=0.18, metric="psi")       # feature drift
monitor.record_drift("prediction", score=0.07, metric="kl") # output drift

monitor.record_performance(rmse=0.042, precision=0.87, recall=0.81)


# ---------------------------------------------------------------------------
# 9. Training pipeline monitoring
# ---------------------------------------------------------------------------

from impulse_telemetry.ml import TrainingMetrics
from impulse_telemetry.metrics import get_metrics

init(service="training-svc", optional_metrics=[TrainingMetrics()])

m = get_metrics()
m.training.record_job("xgboost", "success", duration_seconds=42.1)
m.training.record_model("xgboost", accuracy=0.91, loss=0.12)
m.training.record_dataset("dataset-v3", row_count=100_000, size_bytes=52_428_800)


# ---------------------------------------------------------------------------
# 9. Background worker (no HTTP server) — expose /metrics on a sidecar port
# ---------------------------------------------------------------------------

from impulse_telemetry import init

init(
    service="ingest-worker",
    prometheus_port=9090,   # Prometheus scrapes localhost:9090/metrics
    log_level="DEBUG",
)

log = get_logger(__name__)
log.info("worker_started")
