"""
ml/monitor.py — MLMonitor: telemetry wrapper for model inference.

Usage:
    monitor = MLMonitor(model_id="rec-v3", user_id=user_id)

    # Context manager
    with monitor.inference(features=df) as span:
        result = model.predict(df)
        span.record_output(result)

    # Decorator
    @monitor.trace
    def predict(features):
        return model.predict(features)

    # From drift/eval batch jobs
    monitor.record_drift("age", score=0.18)
    monitor.record_performance(rmse=0.042, precision=0.87, recall=0.81)
"""

from __future__ import annotations

import functools
import time
from contextlib import contextmanager
from typing import Any, Generator

from opentelemetry import trace

from ..logging      import get_logger
from ..metrics      import get_metrics
from ..metrics.instruments import InferenceMetrics
from .quality       import check_data_quality

log_factory = get_logger  # alias for clarity at call site


def _ml() -> InferenceMetrics | None:
    """Return InferenceMetrics if registered via optional_metrics=[InferenceMetrics()], else None."""
    return getattr(get_metrics(), "inference", None)


class MLMonitor:
    """
    Telemetry wrapper for a single model.

    Parameters
    ----------
    model_id : Model identifier — appears on all metrics and traces
    user_id  : User making the request — used for per-user metric labels
    """

    def __init__(self, model_id: str, user_id: str = "unknown") -> None:
        self.model_id = model_id
        self.user_id  = user_id
        self._tracer  = trace.get_tracer("impulse.ml")
        self._log     = get_logger("ml", model_id=model_id, user_id=user_id)

    @contextmanager
    def inference(self, features=None) -> Generator[_InferenceSpan, None, None]:
        """
        Context manager — records latency, errors, and data quality for one inference call.

        with monitor.inference(features=df) as span:
            result = model.predict(df)
            span.record_output(result)
        """
        m      = get_metrics()
        ml     = _ml()
        start  = time.perf_counter()
        status = "success"

        with self._tracer.start_as_current_span("model.inference") as otel_span:
            otel_span.set_attribute("model.id", self.model_id)
            otel_span.set_attribute("user.id",  self.user_id)

            if features is not None and ml is not None:
                check_data_quality(
                    features,
                    ml=ml,
                    labels=m.labels(model_id=self.model_id),
                    log=self._log,
                )

            try:
                yield _InferenceSpan(otel_span)

            except Exception as exc:
                status = "error"
                otel_span.record_exception(exc)
                if ml:
                    ml.inference_errors.labels(
                        **m.labels(model_id=self.model_id),
                        error_type=type(exc).__name__,
                    ).inc()
                self._log.error("inference_error", error=str(exc))
                raise

            finally:
                latency = time.perf_counter() - start
                if ml:
                    lm = m.labels(model_id=self.model_id, user_id=self.user_id)
                    ml.inference_latency.labels(**lm).observe(latency)
                    ml.inference_total.labels(**lm, status=status).inc()

                self._log.info("inference_complete",
                               latency_ms=round(latency * 1000, 2), status=status)

    def trace(self, fn):
        """Decorator version of inference() — no data quality checks."""
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with self.inference():
                return fn(*args, **kwargs)
        return wrapper

    def record_drift(self, feature: str, score: float, metric: str = "psi") -> None:
        """
        Record a drift score for one input feature.
        Call from your drift computation batch job.
        """
        m  = get_metrics()
        ml = _ml()
        if ml:
            ml.feature_drift.labels(
                **m.labels(model_id=self.model_id), feature_name=feature,
            ).set(score)
        self._log.info("drift_recorded", feature=feature, score=score, metric=metric)

    def record_performance(
        self,
        *,
        rmse: float | None = None,
        precision: float | None = None,
        recall: float | None = None,
    ) -> None:
        """
        Record rolling model performance metrics.
        Call from your ground-truth label-join job.
        """
        m  = get_metrics()
        ml = _ml()
        if not ml:
            return
        lm = m.labels(model_id=self.model_id)
        if rmse      is not None: ml.rmse.labels(**lm).set(rmse)
        if precision is not None: ml.precision.labels(**lm).set(precision)
        if recall    is not None: ml.recall.labels(**lm).set(recall)
        self._log.info("performance_recorded", rmse=rmse, precision=precision, recall=recall)


class _InferenceSpan:
    """Handle passed into the 'with' block for attaching output metadata to the span."""

    def __init__(self, span) -> None:
        self._span = span

    def record_output(self, output: Any) -> None:
        """Attach prediction output metadata (size, sample) to the OTEL span."""
        try:
            if hasattr(output, "__len__"):
                self._span.set_attribute("output.size", len(output))
            if hasattr(output, "tolist"):
                sample = output.tolist()[:3]
                if sample and isinstance(sample[0], (int, float)):
                    self._span.set_attribute("output.sample", str(sample))
        except Exception:
            pass

    def set(self, key: str, value: Any) -> None:
        """Attach any arbitrary attribute to the span."""
        self._span.set_attribute(key, value)
