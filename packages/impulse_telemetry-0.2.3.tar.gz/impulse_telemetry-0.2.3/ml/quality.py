"""
ml/quality.py — lightweight data quality checks at inference time.

Separated from monitor.py so quality logic can be tested and extended
independently of the MLMonitor class.

Checks performed:
  - Missing value rate per feature column
  - (Extensible: add dtype checks, range checks, schema validation here)
"""

from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import structlog
    from ..metrics.instruments import MLMetrics


def check_data_quality(features, *, ml: "MLMetrics", labels: dict, log: "structlog.BoundLogger") -> None:
    """
    Run quality checks on inference input features.

    Parameters
    ----------
    features : Input passed to the model (expected: pd.DataFrame)
    ml       : MLMetrics instance for recording missing_feature_rate
    labels   : Base Prometheus labels dict (service, env, model_id)
    log      : Bound logger for emitting warnings
    """
    try:
        import pandas as pd
        if not isinstance(features, pd.DataFrame) or features.empty:
            return
        _check_missing_values(features, ml=ml, labels=labels, log=log)
    except ImportError:
        pass  # pandas not installed — skip silently


def _check_missing_values(features, *, ml, labels, log) -> None:
    """Record missing value rate per column and warn if non-zero."""
    for col in features.columns:
        rate = float(features[col].isna().mean())
        ml.missing_feature_rate.labels(**labels, feature_name=col).set(rate)
        if rate > 0:
            log.warning("missing_feature_values",
                        feature=col, missing_rate=round(rate, 4))
