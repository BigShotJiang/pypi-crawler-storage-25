"""
ml/training_metrics.py — Prometheus instruments for model training pipelines.

Covers the training phase (job orchestration, data ingestion, model fit).
Inference-time signals are handled by MLMonitor / MLMetrics.

Usage:
    from impulse_telemetry import init
    from impulse_telemetry.ml import TrainingMetrics

    init(app, service="training-svc", optional_metrics=[TrainingMetrics()])

    # anywhere after init():
    from impulse_telemetry.metrics import get_metrics
    get_metrics().training.record_job("xgboost", "success", duration_seconds=42.1)
"""
from __future__ import annotations

from prometheus_client import Counter, Histogram, Gauge


class TrainingMetrics:
    """
    Metric instruments for model training pipelines.

    Attach via optional_metrics=[TrainingMetrics()] in init().
    Access via get_metrics().training after init().

    Excluded (already covered by impulse_telemetry core):
      - HTTP rate / errors / latency  → SystemMetrics via FastAPI middleware
      - Inference latency / drift     → MLMetrics (enable_ml=True)
      - System CPU / memory           → prometheus node_exporter
    """

    # The name used as the attribute on the Metrics singleton:
    #   get_metrics().training
    name = "training"

    def __init__(self) -> None:
        self.jobs_total = Counter(
            "training_jobs_total",
            "Training jobs completed",
            ["model_type", "status"],
        )
        self.job_duration = Histogram(
            "training_job_duration_seconds",
            "Wall-clock time from job start to completion",
            ["model_type", "status"],
            buckets=[10, 30, 60, 120, 300, 600, 1800, 3600, 7200],
        )
        self.jobs_active = Gauge(
            "training_jobs_active",
            "Currently running training jobs",
            ["model_type"],
        )
        self.job_queue_size = Gauge(
            "training_job_queue_size",
            "Jobs waiting in the training queue",
        )
        self.model_accuracy = Histogram(
            "model_training_accuracy",
            "Best validation accuracy reached during training",
            ["model_type"],
            buckets=[0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.99, 1.0],
        )
        self.model_loss = Histogram(
            "model_training_loss",
            "Final validation loss after training",
            ["model_type"],
            buckets=[0.001, 0.01, 0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0],
        )
        self.dataset_rows = Counter(
            "dataset_rows_processed_total",
            "Dataset rows ingested for training",
            ["dataset_id"],
        )
        self.dataset_bytes = Histogram(
            "dataset_size_bytes",
            "Size of datasets processed",
            ["dataset_id"],
            buckets=[1024, 10240, 102400, 1048576, 10485760, 104857600],
        )

    # ------------------------------------------------------------------
    # Convenience wrappers — prefer these over direct instrument access
    # ------------------------------------------------------------------

    def record_job(
        self,
        model_type: str,
        status: str,
        duration_seconds: float | None = None,
    ) -> None:
        """Record a completed (or failed) training job."""
        self.jobs_total.labels(model_type=model_type, status=status).inc()
        if duration_seconds is not None:
            self.job_duration.labels(
                model_type=model_type, status=status
            ).observe(duration_seconds)

    def record_model(
        self,
        model_type: str,
        accuracy: float | None = None,
        loss: float | None = None,
    ) -> None:
        """Record validation accuracy / loss at the end of training."""
        if accuracy is not None:
            self.model_accuracy.labels(model_type=model_type).observe(accuracy)
        if loss is not None:
            self.model_loss.labels(model_type=model_type).observe(loss)

    def record_dataset(
        self,
        dataset_id: str,
        row_count: int,
        size_bytes: int,
    ) -> None:
        """Record rows and byte size processed for a dataset."""
        self.dataset_rows.labels(dataset_id=dataset_id).inc(row_count)
        self.dataset_bytes.labels(dataset_id=dataset_id).observe(size_bytes)
