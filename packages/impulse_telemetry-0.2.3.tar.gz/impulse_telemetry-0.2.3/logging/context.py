"""
logging/context.py — per-request context using contextvars.

Why contextvars instead of a global dict:
  - FastAPI handles many concurrent requests in the same process
  - A global dict is shared across all of them → requests overwrite each other
  - ContextVar gives each async task its own isolated copy automatically
  - No locking, no leakage, safe for async/await

Usage:
    # In middleware — set at request start
    token = bind_request_context(user_id="usr_123", request_id="req_456")

    # In any handler or service — read automatically via get_logger()
    log.info("doing_thing")  # user_id + request_id appear automatically

    # In middleware — clear at request end
    clear_request_context(token)
"""

from contextvars import ContextVar, Token
from typing import Any

# Each async task (request) gets its own isolated copy of this dict
_request_ctx: ContextVar[dict[str, Any]] = ContextVar("request_ctx", default={})


def bind_request_context(**fields: Any) -> Token:
    """
    Bind key-value fields to the current request context.
    Returns a token needed to restore the previous context when the request ends.

    Usage:
        token = bind_request_context(user_id="usr_123", request_id="req_456")
        # ... handle request ...
        clear_request_context(token)
    """
    current = _request_ctx.get()
    token   = _request_ctx.set({**current, **fields})
    return token


def clear_request_context(token: Token) -> None:
    """Restore context to its state before bind_request_context() was called."""
    _request_ctx.reset(token)


def get_request_context() -> dict[str, Any]:
    """Return the current request context dict (read-only copy)."""
    return dict(_request_ctx.get())
