"""
impulse_telemetry.logging
--------------------------
Structured JSON logging with automatic trace_id injection.

Public API:
    from impulse_telemetry.logging import get_logger, bind_request_context
"""

from .logger    import setup, get_logger
from .context   import bind_request_context, clear_request_context

__all__ = ["setup", "get_logger", "bind_request_context", "clear_request_context"]
