"""
logging/logger.py — structlog JSON logger.

Every log line automatically includes:
  - trace_id, span_id   from the active OTEL span  (via _inject_trace_context)
  - user_id, request_id from the current request    (via _inject_request_context)
  - service, version, env                           (set once at startup)
  - timestamp, level

Usage:
    log = get_logger(__name__)
    log.info("prediction_served", model_id="v3", latency_ms=43)
    # {"service":"rec-service","trace_id":"abc..","event":"prediction_served",...}
"""

import logging
import sys
from typing import Any

import structlog

# Service-level fields set once at startup via setup()
# Safe as a module-level dict because these never change after init
_SERVICE_FIELDS: dict[str, str] = {}


def setup(*, service: str, version: str, env: str, level: str) -> None:
    """Configure structlog. Called once by core.init()."""
    global _SERVICE_FIELDS
    _SERVICE_FIELDS = {"service": service, "version": version, "env": env}

    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, level.upper(), logging.INFO),
    )

    structlog.configure(
        processors=[
            _inject_request_context,   # per-request fields (user_id, request_id, ...)
            _inject_trace_context,     # trace_id + span_id from active OTEL span
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.upper(), logging.INFO)
        ),
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str = "app", **extra: Any) -> structlog.BoundLogger:
    """
    Return a logger pre-bound with service fields + any extra fields.
    Per-request context (user_id etc.) is injected automatically at log time.

    Usage:
        log = get_logger(__name__)
        log.info("order_placed", order_id="ord_99")
    """
    return structlog.get_logger(name).bind(**_SERVICE_FIELDS, **extra)


# ── structlog processors (called on every log() invocation) ───────────────────

def _inject_trace_context(_logger, _method, event_dict: dict) -> dict:
    """Stamp every log line with trace_id + span_id from the active OTEL span."""
    from opentelemetry import trace
    span = trace.get_current_span()
    ctx  = span.get_span_context()
    if ctx.is_valid:
        event_dict["trace_id"] = format(ctx.trace_id, "032x")
        event_dict["span_id"]  = format(ctx.span_id,  "016x")
    return event_dict


def _inject_request_context(_logger, _method, event_dict: dict) -> dict:
    """Merge per-request contextvars fields (user_id, request_id, ...) into the log line."""
    from .context import get_request_context
    event_dict.update(get_request_context())
    return event_dict
