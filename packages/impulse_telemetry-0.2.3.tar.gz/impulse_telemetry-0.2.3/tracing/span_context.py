"""
tracing/span_context.py — helpers for reading and propagating the active span.
"""

from opentelemetry import trace
from opentelemetry.propagate import inject


def current_span_context() -> dict[str, str]:
    """
    Return trace_id and span_id of the currently active span as hex strings.
    Returns empty strings when no span is active (e.g. background jobs).

    Usage:
        ctx = current_span_context()
        # {"trace_id": "abc123...", "span_id": "def456..."}
    """
    span = trace.get_current_span()
    ctx  = span.get_span_context()
    if ctx.is_valid:
        return {
            "trace_id": format(ctx.trace_id, "032x"),
            "span_id":  format(ctx.span_id,  "016x"),
        }
    return {"trace_id": "", "span_id": ""}


def inject_headers(headers: dict) -> dict:
    """
    Inject W3C traceparent (and B3) headers into an outgoing request dict.
    Use when calling a service that is NOT auto-instrumented.

    Usage:
        headers = inject_headers({})
        requests.post("http://legacy-service/api", headers=headers)
    """
    inject(headers)
    return headers
