"""
tracing/provider.py — TracerProvider setup with OTLP gRPC exporter.
"""

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.resources import Resource
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.propagate import set_global_textmap
from opentelemetry.propagators.composite import CompositePropagator
from opentelemetry.propagators.b3 import B3MultiFormat
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

from .instrumentation import auto_instrument


def setup(*, service: str, version: str, env: str, endpoint: str) -> None:
    """
    Configure the global TracerProvider with OTLP gRPC export.
    Called once by core.init().
    """
    resource = Resource.create({
        "service.name":           service,
        "service.version":        version,
        "deployment.environment": env,
    })

    provider = TracerProvider(resource=resource)
    provider.add_span_processor(
        BatchSpanProcessor(OTLPSpanExporter(endpoint=endpoint, insecure=True))
    )
    trace.set_tracer_provider(provider)

    # W3C traceparent (primary) + B3 (for services not yet migrated to W3C)
    set_global_textmap(CompositePropagator([
        TraceContextTextMapPropagator(),
        B3MultiFormat(),
    ]))

    auto_instrument()
