"""
tracing/instrumentation.py — best-effort auto-instrumentation.

Instruments common libraries (requests, httpx, SQLAlchemy, Redis, Celery)
if they are installed in the service. Silently skips any that are missing.
This means outgoing HTTP calls, DB queries, and queue tasks are all traced
automatically without any changes to application code.
"""

_INSTRUMENTORS = [
    ("opentelemetry.instrumentation.requests",  "RequestsInstrumentor"),
    ("opentelemetry.instrumentation.httpx",      "HTTPXClientInstrumentor"),
    ("opentelemetry.instrumentation.sqlalchemy", "SQLAlchemyInstrumentor"),
    ("opentelemetry.instrumentation.redis",      "RedisInstrumentor"),
    ("opentelemetry.instrumentation.celery",     "CeleryInstrumentor"),
]


def auto_instrument() -> None:
    """Import and activate each available instrumentor."""
    import importlib
    for module_path, class_name in _INSTRUMENTORS:
        try:
            cls = getattr(importlib.import_module(module_path), class_name)
            cls().instrument()
        except Exception:
            pass  # Not installed or already instrumented — skip silently
