"""
impulse_telemetry.tracing
--------------------------
OTEL distributed tracing — TracerProvider, OTLP exporter, propagation.

Public API:
    from impulse_telemetry.tracing import get_tracer, current_span_context
"""

from .provider     import setup
from .span_context import current_span_context, inject_headers

__all__ = ["setup", "get_tracer", "current_span_context", "inject_headers"]


def get_tracer(name: str):
    from opentelemetry import trace
    return trace.get_tracer(name)
