"""
impulse_telemetry.metrics
--------------------------
Prometheus metric instruments — HTTP RED + optional service-specific bundles.

Public API:
    from impulse_telemetry.metrics import get_metrics
    m = get_metrics()
    m.system.requests_total.labels(...).inc()
    m.inference.inference_latency.labels(...).observe(s)  # if InferenceMetrics() passed
    m.training.record_job(...)                            # if TrainingMetrics() passed
"""

from .registry    import setup, get_metrics, Metrics
from .instruments import InferenceMetrics

__all__ = ["setup", "get_metrics", "Metrics", "InferenceMetrics"]
