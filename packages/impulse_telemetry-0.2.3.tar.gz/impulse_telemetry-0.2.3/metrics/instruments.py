"""
metrics/instruments.py — Prometheus instrument definitions.

Separated from registry.py so instrument definitions are readable on their own
and can be imported/tested independently of the singleton.
"""

from prometheus_client import Counter, Histogram, Gauge

# Base labels present on every metric
_BASE = ["service", "env"]


class SystemMetrics:
    """RED metrics + infra signals for every microservice."""

    def __init__(self, buckets: tuple) -> None:

        # ── R: Rate ──────────────────────────────────────────────────────────
        self.requests_total = Counter(
            "http_requests_total",
            "Total HTTP requests",
            _BASE + ["route", "method", "status"],
        )

        # ── E: Errors ────────────────────────────────────────────────────────
        self.errors_total = Counter(
            "http_request_errors_total",
            "HTTP 4xx/5xx responses",
            _BASE + ["route", "status"],
        )

        # ── D: Duration ──────────────────────────────────────────────────────
        self.request_latency = Histogram(
            "http_request_duration_seconds",
            "HTTP request latency",
            _BASE + ["route", "method", "status"],
            buckets=buckets,
        )

        # ── Infra signals ────────────────────────────────────────────────────
        self.active_requests = Gauge(
            "http_active_requests",
            "In-flight HTTP requests",
            _BASE,
        )
        self.rate_limiter_hits = Counter(
            "rate_limiter_hits_total",
            "Requests rejected by rate limiter",
            _BASE + ["user_id", "tier"],
        )
        self.rate_limiter_remaining = Gauge(
            "rate_limiter_quota_remaining",
            "Remaining quota for a user/tier",
            _BASE + ["user_id", "tier"],
        )
        self.dependency_latency = Histogram(
            "dependency_call_duration_seconds",
            "Latency of calls to downstream services, DBs, caches",
            _BASE + ["dependency", "operation"],
            buckets=buckets,
        )
        self.dependency_errors = Counter(
            "dependency_errors_total",
            "Failed downstream dependency calls",
            _BASE + ["dependency", "operation"],
        )
        self.queue_depth = Gauge(
            "queue_depth",
            "Current async job queue depth",
            _BASE + ["queue_name"],
        )
        self.circuit_breaker = Gauge(
            "circuit_breaker_state",
            "Circuit breaker state: 0=closed  1=open  2=half-open",
            _BASE + ["dependency"],
        )


class InferenceMetrics:
    """
    Instruments for a deployed model serving live user queries.
    Attach via optional_metrics=[InferenceMetrics()].
    Accessible as get_metrics().inference after init().
    """

    name = "inference"

    def __init__(self) -> None:
        _ML = _BASE + ["model_id"]

        self.inference_latency = Histogram(
            "ml_inference_duration_seconds",
            "End-to-end model inference latency",
            _ML + ["user_id"],
            buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 5.0),
        )
        self.inference_total = Counter(
            "ml_inference_requests_total",
            "Total inference requests",
            _ML + ["user_id", "status"],
        )
        self.inference_errors = Counter(
            "ml_inference_errors_total",
            "Failed inference requests",
            _ML + ["error_type"],
        )
        self.missing_feature_rate = Gauge(
            "ml_missing_feature_rate",
            "Fraction of requests with null/missing feature values",
            _ML + ["feature_name"],
        )
        self.schema_violations = Counter(
            "ml_schema_violations_total",
            "Input shape or dtype violations at inference time",
            _ML + ["violation_type"],
        )
        self.feature_drift = Gauge(
            "ml_feature_drift_score",
            "PSI/JSD drift score per input feature",
            _ML + ["feature_name"],
        )
        self.prediction_drift = Gauge(
            "ml_prediction_drift_score",
            "Output distribution drift score",
            _ML,
        )
        self.rmse      = Gauge("ml_rmse",      "Rolling RMSE on production data",      _ML)
        self.precision = Gauge("ml_precision", "Rolling precision on production data",  _ML)
        self.recall    = Gauge("ml_recall",    "Rolling recall on production data",     _ML)
