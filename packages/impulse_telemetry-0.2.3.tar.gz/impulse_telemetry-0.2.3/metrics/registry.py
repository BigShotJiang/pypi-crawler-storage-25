"""
metrics/registry.py — Prometheus metric instruments.

All instruments are defined once here and accessed via get_metrics()
from anywhere in the service after init() is called.

Why a singleton:
  Prometheus instruments must be registered globally exactly once.
  If two parts of the code create the same metric name, prometheus-client
  raises a conflict error. The singleton pattern prevents that.
"""

from __future__ import annotations
from prometheus_client import start_http_server

from .instruments import SystemMetrics

_LATENCY_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)

_registry: Metrics | None = None


class Metrics:
    """
    Container for all registered metric instruments.
    Access via get_metrics() — do not instantiate directly.
    """

    def __init__(self, service: str, env: str) -> None:
        self._defaults = {"service": service, "env": env}
        self.system    = SystemMetrics(buckets=_LATENCY_BUCKETS)

    def labels(self, **extra) -> dict:
        """
        Merge service + env defaults with request-specific labels.

        Usage:
            m.system.requests_total.labels(**m.labels(route="/predict", status="200")).inc()
        """
        return {**self._defaults, **extra}

    def attach(self, metric_instance) -> None:
        """
        Attach an optional metric bundle to the singleton.

        The instance must expose a ``name`` class attribute (str) which
        becomes the attribute name on this object:

            init(..., optional_metrics=[TrainingMetrics()])
            get_metrics().training.record_job(...)

        Called automatically by setup() for each item in optional_metrics.
        """
        if not hasattr(metric_instance, "name"):
            raise ValueError(
                f"{type(metric_instance).__name__} must define a 'name' class attribute "
                "to be used as optional_metrics."
            )
        setattr(self, metric_instance.name, metric_instance)


def setup(
    *,
    service: str,
    env: str,
    prometheus_port: int | None,
    optional_metrics: list | None = None,
) -> None:
    """Initialize the metrics registry. Called once by core.init()."""
    global _registry
    _registry = Metrics(service=service, env=env)

    for m in optional_metrics or []:
        _registry.attach(m)

    if prometheus_port:
        # For workers / non-HTTP services: start a standalone scrape server
        start_http_server(prometheus_port)


def get_metrics() -> Metrics:
    """
    Return the initialized Metrics singleton.
    Raises RuntimeError if called before init().
    """
    if _registry is None:
        raise RuntimeError(
            "Metrics not initialized. Call init() before get_metrics()."
        )
    return _registry
