"""
impulse_telemetry
-----------------
Minimal observability SDK for Impulse microservices.

Usage:
    from impulse_telemetry import init
    app = FastAPI()
    init(app, service="my-service")
"""

from .core    import init
from .logging import get_logger
from .metrics import get_metrics
from .tracing import get_tracer
from .ml      import MLMonitor, InferenceMetrics, TrainingMetrics

__all__ = ["init", "get_logger", "get_metrics", "get_tracer", "MLMonitor", "InferenceMetrics", "TrainingMetrics"]
