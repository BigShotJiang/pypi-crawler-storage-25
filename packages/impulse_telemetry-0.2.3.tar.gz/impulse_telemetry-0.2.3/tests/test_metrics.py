"""
Tests for impulse_telemetry.metrics

Covers: get_metrics singleton, labels(), system instruments, ML instruments.
"""

import pytest
from impulse_telemetry.metrics import get_metrics
from impulse_telemetry.metrics.registry import Metrics


def test_get_metrics_returns_instance(app):
    m = get_metrics()
    assert isinstance(m, Metrics)


def test_get_metrics_is_singleton(app):
    assert get_metrics() is get_metrics()


def test_labels_merges_defaults(app):
    m = get_metrics()
    labels = m.labels(route="/predict", status="200")
    assert labels["service"] == "test-svc"
    assert labels["env"] == "dev"
    assert labels["route"] == "/predict"
    assert labels["status"] == "200"


def test_labels_defaults_only(app):
    m = get_metrics()
    labels = m.labels()
    assert set(labels.keys()) == {"service", "env"}


def test_system_instruments_present(app):
    sys = get_metrics().system
    assert sys.requests_total is not None
    assert sys.errors_total is not None
    assert sys.request_latency is not None
    assert sys.active_requests is not None
    assert sys.dependency_latency is not None
    assert sys.dependency_errors is not None


def test_inference_instruments_present(app):
    inf = get_metrics().inference
    assert inf is not None
    assert inf.inference_latency is not None
    assert inf.inference_total is not None
    assert inf.inference_errors is not None
    assert inf.feature_drift is not None
    assert inf.missing_feature_rate is not None
    assert inf.rmse is not None
    assert inf.precision is not None
    assert inf.recall is not None


def test_training_instruments_present(app):
    tr = get_metrics().training
    assert tr is not None
    assert tr.jobs_total is not None
    assert tr.job_duration is not None
    assert tr.jobs_active is not None
    assert tr.model_accuracy is not None
    assert tr.model_loss is not None
    assert tr.dataset_rows is not None
    assert tr.dataset_bytes is not None


def test_counter_increment_does_not_raise(app):
    m = get_metrics()
    m.system.requests_total.labels(
        **m.labels(route="/test", method="GET", status="200")
    ).inc()


def test_gauge_set_does_not_raise(app):
    m = get_metrics()
    m.system.queue_depth.labels(**m.labels(queue_name="default")).set(5)
