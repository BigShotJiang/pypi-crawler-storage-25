"""
Tests for impulse_telemetry.tracing

Covers: current_span_context, inject_headers, get_tracer.
Uses a local TracerProvider + InMemorySpanExporter so tests are
self-contained and don't require an OTLP collector.
"""

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from impulse_telemetry.tracing import get_tracer, current_span_context, inject_headers


def _local_tracer():
    """Create an isolated tracer backed by an in-memory exporter."""
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    return provider.get_tracer("test"), exporter


def test_no_active_span_returns_empty_strings():
    ctx = current_span_context()
    assert ctx == {"trace_id": "", "span_id": ""}


def test_active_span_returns_hex_ids():
    tracer, _ = _local_tracer()
    with tracer.start_as_current_span("op"):
        ctx = current_span_context()
    assert len(ctx["trace_id"]) == 32
    assert len(ctx["span_id"]) == 16
    assert all(c in "0123456789abcdef" for c in ctx["trace_id"])
    assert all(c in "0123456789abcdef" for c in ctx["span_id"])


def test_inject_headers_adds_traceparent():
    tracer, _ = _local_tracer()
    with tracer.start_as_current_span("op"):
        headers = inject_headers({})
    assert "traceparent" in headers


def test_inject_headers_no_span_returns_empty():
    headers = inject_headers({})
    # No active span — propagator injects nothing (or a zero traceparent)
    assert isinstance(headers, dict)


def test_get_tracer_returns_tracer():
    tracer = get_tracer(__name__)
    assert tracer is not None


def test_span_can_set_attributes():
    tracer, exporter = _local_tracer()
    with tracer.start_as_current_span("op") as span:
        span.set_attribute("key", "value")
        span.set_attribute("count", 42)

    finished = exporter.get_finished_spans()
    assert len(finished) == 1
    assert finished[0].attributes["key"] == "value"
    assert finished[0].attributes["count"] == 42
