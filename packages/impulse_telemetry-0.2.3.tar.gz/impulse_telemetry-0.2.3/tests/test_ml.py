"""
Tests for impulse_telemetry.ml

Covers: MLMonitor.inference() context manager, @trace decorator,
record_drift, record_performance, data quality checks, error handling.
"""

import pytest
from impulse_telemetry.ml import MLMonitor, InferenceMetrics


@pytest.fixture(scope="module")
def monitor(app):  # app ensures init(optional_metrics=[InferenceMetrics()]) ran first
    return MLMonitor(model_id="test-model", user_id="test-user")


def test_inference_context_manager(monitor):
    with monitor.inference() as span:
        assert span is not None


def test_inference_span_set(monitor):
    with monitor.inference() as span:
        span.set("custom_attr", "hello")


def test_inference_record_output_list(monitor):
    with monitor.inference() as span:
        span.record_output([0.1, 0.9, 0.5])


def test_inference_record_output_no_len(monitor):
    # record_output is best-effort — scalars should not raise
    with monitor.inference() as span:
        span.record_output(0.42)


def test_inference_propagates_exception(monitor):
    with pytest.raises(ValueError, match="boom"):
        with monitor.inference():
            raise ValueError("boom")


def test_trace_decorator(monitor):
    @monitor.trace
    def predict(x):
        return x * 2

    assert predict(5) == 10


def test_trace_decorator_propagates_exception(monitor):
    @monitor.trace
    def bad():
        raise RuntimeError("fail")

    with pytest.raises(RuntimeError):
        bad()


def test_record_drift_does_not_raise(monitor):
    monitor.record_drift("age", score=0.18)
    monitor.record_drift("income", score=0.05, metric="kl")


def test_record_performance_does_not_raise(monitor):
    monitor.record_performance(rmse=0.042, precision=0.87, recall=0.81)


def test_record_performance_partial(monitor):
    monitor.record_performance(rmse=0.1)
    monitor.record_performance(precision=0.9)


def test_inference_with_clean_dataframe(monitor):
    pd = pytest.importorskip("pandas")
    df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    with monitor.inference(features=df) as span:
        span.record_output([0.1, 0.2, 0.3])


def test_inference_with_missing_values_warns(monitor):
    pd = pytest.importorskip("pandas")
    df = pd.DataFrame({"a": [1, None, 3], "b": [None, None, 6]})
    # Missing values are recorded as metrics + logged as warnings — should not raise
    with monitor.inference(features=df):
        pass


def test_inference_with_empty_dataframe(monitor):
    pd = pytest.importorskip("pandas")
    df = pd.DataFrame()
    with monitor.inference(features=df):
        pass
