"""
Tests for impulse_telemetry.logging

Covers: get_logger, bind_request_context, clear_request_context, get_request_context.
"""

from impulse_telemetry.logging import get_logger, bind_request_context, clear_request_context
from impulse_telemetry.logging.context import get_request_context


def test_get_logger_returns_bound_logger():
    log = get_logger(__name__)
    assert log is not None


def test_log_does_not_raise():
    log = get_logger(__name__)
    log.info("test_event", key="value")
    log.warning("test_warning", code=42)
    log.error("test_error", reason="none")


def test_bind_injects_fields():
    token = bind_request_context(user_id="u1", request_id="r1")
    ctx = get_request_context()
    assert ctx["user_id"] == "u1"
    assert ctx["request_id"] == "r1"
    clear_request_context(token)


def test_clear_restores_previous_context():
    token = bind_request_context(user_id="u1")
    clear_request_context(token)
    ctx = get_request_context()
    assert "user_id" not in ctx


def test_context_empty_by_default():
    ctx = get_request_context()
    assert isinstance(ctx, dict)
    # No stale fields from previous tests (each test gets its own call stack)


def test_nested_context_bind():
    outer = bind_request_context(user_id="outer")
    inner = bind_request_context(user_id="inner", extra="yes")

    ctx = get_request_context()
    assert ctx["user_id"] == "inner"
    assert ctx["extra"] == "yes"

    clear_request_context(inner)
    ctx = get_request_context()
    assert ctx["user_id"] == "outer"
    assert "extra" not in ctx

    clear_request_context(outer)
