"""
core.py — single entrypoint for all microservices.

    init(app, service="my-service")

That one call wires up tracing, metrics, structured logging,
and FastAPI middleware automatically.
"""

import os

from .logging  import setup as setup_logging
from .metrics  import setup as setup_metrics
from .tracing  import setup as setup_tracing


def init(
    app=None,
    *,
    service: str,
    version: str = "0.0.0",
    env: str | None = None,
    otlp_endpoint: str | None = None,
    prometheus_port: int | None = None,
    log_level: str = "INFO",
    optional_metrics: list | None = None,
) -> None:
    """
    Instrument a microservice with tracing, metrics, and structured logging.

    Parameters
    ----------
    app              : FastAPI app (optional — pass for automatic HTTP instrumentation)
    service          : Service name shown on all traces, metrics, and logs
    version          : Semver string tagged on all telemetry
    env              : "production" | "staging" | "dev"  (default: ENV env var)
    otlp_endpoint    : OTEL Collector gRPC address       (default: OTEL_EXPORTER_OTLP_ENDPOINT env var)
    prometheus_port  : Expose /metrics on this port — for workers without an HTTP server
    log_level        : "DEBUG" | "INFO" | "WARNING" | "ERROR"
    optional_metrics : List of metric bundle instances to attach to the Metrics singleton.
                       Each must define a ``name`` class attribute.
                       Access after init via get_metrics().<name>, e.g.:
                           from impulse_telemetry.ml import TrainingMetrics, MLMetrics
                           init(app, service="training-svc",
                                optional_metrics=[MLMetrics(), TrainingMetrics()])
                           get_metrics().ml.inference_total ...
                           get_metrics().training.record_job(...)
    """
    _env      = env           or os.getenv("ENV", "production")
    _endpoint = otlp_endpoint or os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")

    # Order matters: logging first so setup steps are themselves logged
    setup_logging(service=service, version=version, env=_env, level=log_level)
    setup_tracing(service=service, version=version, env=_env, endpoint=_endpoint)
    setup_metrics(
        service=service,
        env=_env,
        prometheus_port=prometheus_port,
        optional_metrics=optional_metrics,
    )

    if app is not None:
        from .middleware import attach
        attach(app, service=service)
