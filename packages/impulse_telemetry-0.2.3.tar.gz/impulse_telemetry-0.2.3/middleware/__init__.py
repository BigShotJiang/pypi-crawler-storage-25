"""
impulse_telemetry.middleware
-----------------------------
FastAPI HTTP middleware — auto traces, RED metrics, structured logs per request.

Public API:
    from impulse_telemetry.middleware import attach
"""

from .fastapi import ImpulseMiddleware


def attach(app, *, service: str) -> None:
    """Attach OTEL auto-instrumentation + ImpulseMiddleware to a FastAPI app."""
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
    FastAPIInstrumentor.instrument_app(app)
    app.add_middleware(ImpulseMiddleware, service=service)


__all__ = ["attach", "ImpulseMiddleware"]
