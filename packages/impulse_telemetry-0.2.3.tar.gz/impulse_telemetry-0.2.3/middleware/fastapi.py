"""
middleware/fastapi.py — Starlette/FastAPI request middleware.

For every HTTP request automatically:
  - Records RED metrics (rate, errors, duration) via Prometheus
  - Tracks active_requests gauge
  - Emits one structured JSON log line with trace_id + latency + status
  - Injects X-Trace-Id into the response header

Skips health/readiness/metrics endpoints to avoid polluting dashboards.
"""

import time

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from ..logging  import get_logger, bind_request_context, clear_request_context
from ..metrics  import get_metrics
from ..tracing  import current_span_context

_SKIP = {"/healthz", "/readyz", "/metrics", "/livez"}

log = get_logger("http")


class ImpulseMiddleware(BaseHTTPMiddleware):

    def __init__(self, app, *, service: str) -> None:
        super().__init__(app)
        self.service = service

    async def dispatch(self, request: Request, call_next) -> Response:
        if request.url.path in _SKIP:
            return await call_next(request)

        m      = get_metrics()
        route  = _matched_route(request)
        method = request.method

        # Bind request-scoped context so all logs in this request include these fields
        # Uses contextvars — each concurrent request gets its own isolated copy
        token = bind_request_context(
            route=route,
            method=method,
            request_id=request.headers.get("x-request-id", ""),
        )

        m.system.active_requests.labels(**m.labels()).inc()
        start = time.perf_counter()

        try:
            response = await call_next(request)
        except Exception as exc:
            _record_metrics(m, route, method, "500", time.perf_counter() - start)
            log.error("request_unhandled_exception", error=str(exc))
            raise
        finally:
            m.system.active_requests.labels(**m.labels()).dec()
            clear_request_context(token)

        status  = str(response.status_code)
        latency = time.perf_counter() - start

        _record_metrics(m, route, method, status, latency)

        # Inject trace_id into response — useful for customer bug reports
        ctx = current_span_context()
        if ctx["trace_id"]:
            response.headers["X-Trace-Id"] = ctx["trace_id"]

        # One structured log line per request — trace_id included automatically
        level = log.warning if response.status_code >= 400 else log.info
        level("http_request", status=status, latency_ms=round(latency * 1000, 2))

        return response


def _record_metrics(m, route: str, method: str, status: str, latency: float) -> None:
    base   = m.labels()
    labels = {**base, "route": route, "method": method, "status": status}

    m.system.request_latency.labels(**labels).observe(latency)
    m.system.requests_total.labels(**labels).inc()

    if status.startswith(("4", "5")):
        m.system.errors_total.labels(**base, route=route, status=status).inc()


def _matched_route(request: Request) -> str:
    """
    Return the route pattern (/users/{id}) not the raw URL (/users/12345).
    This prevents high-cardinality metrics — one series per route, not per URL.
    """
    if request.scope.get("route"):
        return request.scope["route"].path
    return request.url.path
