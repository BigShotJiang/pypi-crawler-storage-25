# Larimar 🛡️

Prompt injection scanner built for humans.
Coming soon.
