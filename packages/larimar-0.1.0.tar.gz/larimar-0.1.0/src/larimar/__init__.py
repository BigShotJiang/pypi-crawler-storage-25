"""Larimar - Prompt injection scanner built for humans."""
__version__ = "0.1.0"