"""
Repository API Endpoints

Provides endpoints for repository file tree, diff, status, and branch management operations.
"""

from sanic import Blueprint, response
from sanic.exceptions import InvalidUsage, ServerError, NotFound, SanicException

import git_utils
from git import InvalidGitRepositoryError


# Custom exception for conflict responses (HTTP 409)
class Conflict(SanicException):
    status_code = 409


repository_bp = Blueprint("repository", url_prefix="/api/repo")


@repository_bp.route("/tree")
async def get_tree(request):
    """
    Get repository file tree.
    
    Query params:
        all: "true" to get all files, otherwise only changed files (default: false)
        no_cache: "true" to bypass cache and get fresh data (default: false)
    
    Returns:
        JSON with file tree structure and file statuses
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    # Check if user wants all files or just changed files
    show_all = request.args.get("all", "false").lower() == "true"
    changed_only = not show_all
    
    # Check if cache should be bypassed
    no_cache = request.args.get("no_cache", "false").lower() == "true"
    if no_cache:
        git_utils.clear_cache()
    
    tree_data = git_utils.get_file_tree(repo_path, changed_only=changed_only)
    return response.json(tree_data)


@repository_bp.route("/browse")
async def browse_directory(request):
    """
    Browse contents of a specific directory within the repository.
    
    Query params:
        path: Directory path relative to repository root (required)
              Use "/" for root directory
    
    Returns:
        JSON with directory contents including files and subdirectories
    """
    repo_path = request.ctx.repo_path
    dir_path = request.args.get("path")
    
    if not dir_path and dir_path != "":
        raise InvalidUsage("Missing 'path' parameter")
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    try:
        directory_data = git_utils.browse_directory(repo_path, dir_path)
        return response.json(directory_data)
    except ValueError as e:
        # Path traversal or invalid path
        raise InvalidUsage(str(e))
    except FileNotFoundError as e:
        raise NotFound(str(e))
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to browse directory: {str(e)}")


@repository_bp.route("/diff")
async def get_diff(request):
    """
    Get diff for a specific file.
    
    Query params:
        file: File path relative to repository root (required)
        staged: "true" to get staged diff, otherwise unstaged (optional)
        context: Number of context lines (default 3, optional)
    
    Returns:
        JSON with diff information
    """
    repo_path = request.ctx.repo_path
    file_path = request.args.get("file")
    
    if not file_path:
        raise InvalidUsage("Missing 'file' parameter")
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    staged = request.args.get("staged", "false").lower() == "true"
    context = int(request.args.get("context", "3"))
    
    diff_data = git_utils.get_file_diff(repo_path, file_path, staged, context)
    return response.json(diff_data)


@repository_bp.route("/status")
async def get_status(request):
    """
    Get repository status.
    
    Returns:
        JSON with current branch, modified/added/deleted files, and ahead/behind counts
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    status_data = git_utils.get_repo_status(repo_path)
    return response.json(status_data)


@repository_bp.route("/branches")
async def get_branches(request):
    """
    Get all repository branches.
    
    Query params:
        type: Filter by 'local' or 'remote' (optional, default: all)
    
    Returns:
        JSON with local and remote branches
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    try:
        branches = git_utils.list_branches(repo_path)
        
        # Filter by type if requested
        branch_type = request.args.get("type")
        if branch_type == "local":
            branches = {'local': branches['local'], 'current': branches['current']}
        elif branch_type == "remote":
            branches = {'remote': branches['remote']}
        
        return response.json(branches)
    
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to list branches: {str(e)}")


@repository_bp.route("/branches", methods=["POST"])
async def create_branch(request):
    """
    Create a new branch.
    
    Request body:
        {
            "name": str (required),
            "start_point": str (optional, default: HEAD)
        }
    
    Returns:
        JSON with new branch details (HTTP 201)
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    # Validate request body
    if not request.json:
        raise InvalidUsage("Request body required")
    
    branch_name = request.json.get("name")
    if not branch_name:
        raise InvalidUsage("Missing 'name' in request body")
    
    start_point = request.json.get("start_point")
    
    try:
        branch_data = git_utils.create_branch(repo_path, branch_name, start_point)
        return response.json(branch_data, status=201)
    
    except ValueError as e:
        if "already exists" in str(e):
            raise Conflict(str(e))
        else:
            raise InvalidUsage(str(e))
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to create branch: {str(e)}")


@repository_bp.route("/branches/checkout", methods=["PUT"])
async def checkout_branch(request):
    """
    Switch to a different branch.
    
    Request body:
        {
            "name": str (required)
        }
    
    Returns:
        JSON with new branch details and repository status
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    # Validate request body
    if not request.json:
        raise InvalidUsage("Request body required")
    
    branch_name = request.json.get("name")
    if not branch_name:
        raise InvalidUsage("Missing 'name' in request body")
    
    try:
        status_data = git_utils.switch_branch(repo_path, branch_name)
        return response.json(status_data)
    
    except ValueError as e:
        raise NotFound(str(e))
    except git_utils.GitPermissionError as e:
        if "Uncommitted changes" in str(e):
            raise Conflict(str(e))
        else:
            raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to switch branch: {str(e)}")


@repository_bp.route("/branches/<branch_name:path>", methods=["DELETE"])
async def delete_branch(request, branch_name):
    """
    Delete a branch.
    
    Path params:
        branch_name: Name of branch to delete
    
    Query params:
        force: "true" to delete even if unmerged (optional, default: false)
    
    Returns:
        HTTP 204 No Content on success
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    force = request.args.get("force", "false").lower() == "true"
    
    try:
        git_utils.delete_branch(repo_path, branch_name, force)
        return response.empty(status=204)
    
    except ValueError as e:
        if "Cannot delete current branch" in str(e):
            raise InvalidUsage(str(e))
        elif "not found" in str(e).lower():
            raise NotFound(str(e))
        elif "unmerged commits" in str(e):
            raise Conflict(str(e))
        else:
            raise InvalidUsage(str(e))
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to delete branch: {str(e)}")


@repository_bp.route("/branches/merge", methods=["POST"])
async def merge_branch(request):
    """
    Merge a branch into the current branch.
    
    Request body:
        {
            "source": str (required),
            "message": str (optional)
        }
    
    Returns:
        JSON with merge details
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    # Validate request body
    if not request.json:
        raise InvalidUsage("Request body required")
    
    source_branch = request.json.get("source")
    if not source_branch:
        raise InvalidUsage("Missing 'source' in request body")
    
    merge_message = request.json.get("message")
    
    try:
        merge_data = git_utils.merge_branch(repo_path, source_branch, merge_message)
        return response.json(merge_data)
    
    except ValueError as e:
        raise NotFound(str(e))
    except git_utils.GitConflictError as e:
        raise Conflict(str(e))
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to merge branch: {str(e)}")


@repository_bp.route("/file/content", methods=["GET"])
async def get_file_content(request):
    """
    Get file content for viewing in code editor.
    
    Query params:
        file_path: Path to file relative to repository root (required)
    
    Returns:
        JSON with file content and metadata:
        {
            'file_path': str,
            'content': str (if text file),
            'encoding': str,
            'size': int,
            'mime_type': str,
            'is_binary': bool,
            'message': str (if binary or too large)
        }
    """
    repo_path = request.ctx.repo_path
    file_path = request.args.get("file_path")
    
    if not file_path:
        raise InvalidUsage("Missing 'file_path' parameter")
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    try:
        file_data = git_utils.read_file_content(repo_path, file_path)
        return response.json(file_data)
    
    except ValueError as e:
        # Invalid path or path traversal
        if "traversal" in str(e).lower():
            raise InvalidUsage(str(e))
        elif "outside repository" in str(e):
            raise ServerError(str(e), status_code=403)
        else:
            raise InvalidUsage(str(e))
    except FileNotFoundError as e:
        raise NotFound(str(e))
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e), status_code=500)
    except Exception as e:
        raise ServerError(f"Failed to read file content: {str(e)}")


@repository_bp.route("/file/content", methods=["PUT"])
async def save_file_content(request):
    """
    Save file content from code editor.
    
    Query params:
        file_path: Path to file relative to repository root (required)
    
    JSON body:
        {
            'content': str (file content to save),
            'encoding': str (optional, default: utf-8)
        }
    
    Returns:
        JSON with save confirmation:
        {
            'file_path': str,
            'size': int,
            'message': str
        }
    """
    repo_path = request.ctx.repo_path
    file_path = request.args.get("file_path")
    
    if not file_path:
        raise InvalidUsage("Missing 'file_path' parameter")
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    # Get request body
    try:
        body = request.json
        if not body:
            raise InvalidUsage("Missing request body")
        
        content = body.get('content')
        if content is None:
            raise InvalidUsage("Missing 'content' in request body")
        
        encoding = body.get('encoding', 'utf-8')
        
    except Exception as e:
        raise InvalidUsage(f"Invalid request body: {str(e)}")
    
    try:
        result = git_utils.write_file_content(repo_path, file_path, content, encoding)
        return response.json(result)
    
    except ValueError as e:
        # Invalid path or path traversal
        if "traversal" in str(e).lower():
            raise InvalidUsage(str(e))
        elif "outside repository" in str(e):
            raise ServerError(str(e), status_code=403)
        else:
            raise InvalidUsage(str(e))
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e), status_code=500)
    except Exception as e:
        raise ServerError(f"Failed to save file content: {str(e)}")


@repository_bp.route("/stage", methods=["POST"])
async def stage_files(request):
    """
    Stage files for commit.
    
    Request body:
        {
            "file_path": str (optional, for single file),
            "stage_all": bool (optional, to stage all changed files)
        }
    
    Returns:
        JSON with staging result
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    # Validate request body
    if not request.json:
        raise InvalidUsage("Request body required")
    
    file_path = request.json.get("file_path")
    stage_all = request.json.get("stage_all", False)
    
    if not file_path and not stage_all:
        raise InvalidUsage("Missing 'file_path' or 'stage_all' in request body")
    
    try:
        if stage_all:
            result = git_utils.stage_all_files(repo_path)
        else:
            result = git_utils.stage_file(repo_path, file_path)
        
        # Clear cache to ensure fresh data on next request
        git_utils.clear_cache()
        
        return response.json(result)
    
    except FileNotFoundError as e:
        raise NotFound(str(e))
    except ValueError as e:
        raise InvalidUsage(str(e))
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to stage files: {str(e)}")


@repository_bp.route("/unstage", methods=["POST"])
async def unstage_files(request):
    """
    Remove files from staging area.
    
    Request body:
        {
            "file_path": str (required)
        }
    
    Returns:
        JSON with unstaging result
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    # Validate request body
    if not request.json:
        raise InvalidUsage("Request body required")
    
    file_path = request.json.get("file_path")
    if not file_path:
        raise InvalidUsage("Missing 'file_path' in request body")
    
    try:
        result = git_utils.unstage_file(repo_path, file_path)
        
        # Clear cache to ensure fresh data on next request
        git_utils.clear_cache()
        
        return response.json(result)
    
    except ValueError as e:
        raise InvalidUsage(str(e))
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to unstage file: {str(e)}")


@repository_bp.route("/commit", methods=["POST"])
async def create_commit(request):
    """
    Create a commit with staged changes.
    
    Request body:
        {
            "message": str (required),
            "author_name": str (optional),
            "author_email": str (optional)
        }
    
    Returns:
        JSON with commit details (HTTP 201)
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    # Validate request body
    if not request.json:
        raise InvalidUsage("Request body required")
    
    message = request.json.get("message")
    if not message:
        raise InvalidUsage("Missing 'message' in request body")
    
    author_name = request.json.get("author_name")
    author_email = request.json.get("author_email")
    
    try:
        result = git_utils.create_commit(repo_path, message, author_name, author_email)
        
        # Clear cache to ensure fresh data on next request
        git_utils.clear_cache()
        
        return response.json(result, status=201)
    
    except ValueError as e:
        # Empty message, too long, no staged changes, invalid email
        raise InvalidUsage(str(e))
    except git_utils.GitPermissionError as e:
        if "locked" in str(e).lower():
            raise Conflict(str(e))
        else:
            raise ServerError(str(e))
    except git_utils.GitCommandError as e:
        # Commit hook failure
        raise ServerError(str(e))
    except Exception as e:
        raise ServerError(f"Failed to create commit: {str(e)}")

