"""
Commit API Endpoints

Provides endpoints for repository commit history operations.
"""

from sanic import Blueprint, response
from sanic.exceptions import InvalidUsage, ServerError, NotFound

import git_utils


commit_bp = Blueprint("commit", url_prefix="/api/repo")


@commit_bp.route("/commits")
async def get_commits(request):
    """
    Get commit history with pagination.
    
    Query params:
        limit: Maximum number of commits to return (default 50, max 100)
        offset: Number of commits to skip (default 0)
    
    Returns:
        JSON with list of commits and pagination info
    """
    repo_path = request.ctx.repo_path
    
    limit = int(request.args.get("limit", "50"))
    offset = int(request.args.get("offset", "0"))
    
    # Validate parameters
    if limit < 1 or limit > 100:
        raise InvalidUsage("Limit must be between 1 and 100")
    if offset < 0:
        raise InvalidUsage("Offset must be non-negative")
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    commits = git_utils.get_commit_history(repo_path, limit, offset)
    
    return response.json({
        "commits": commits,
        "limit": limit,
        "offset": offset,
        "count": len(commits)
    })


@commit_bp.route("/commit/<commit_hash>")
async def get_commit_details(request, commit_hash):
    """
    Get detailed information about a specific commit.
    
    Path params:
        commit_hash: Full or abbreviated commit hash
    
    Returns:
        JSON with commit metadata, changed files, and diffs
    """
    repo_path = request.ctx.repo_path
    
    if not git_utils.is_valid_repository(repo_path):
        raise InvalidUsage(f"Not a valid Git repository: {repo_path}")
    
    try:
        commit_details = git_utils.get_commit_details(repo_path, commit_hash)
        return response.json(commit_details)
    except ValueError as e:
        # Invalid commit hash or commit not found
        error_msg = str(e)
        if "not found" in error_msg.lower():
            raise NotFound(error_msg)
        else:
            raise InvalidUsage(error_msg)
    except git_utils.GitPermissionError as e:
        raise ServerError(str(e))
    except git_utils.InvalidGitRepositoryError as e:
        raise InvalidUsage(str(e))

