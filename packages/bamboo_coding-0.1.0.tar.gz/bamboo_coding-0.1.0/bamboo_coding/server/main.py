from __future__ import annotations

import argparse
import os

import uvicorn
from dotenv import load_dotenv

from controller.app.main import app, create_app


load_dotenv()


def main() -> None:
    parser = argparse.ArgumentParser(description="Bamboo Coding")
    parser.add_argument("--dev", action="store_true", help="Run in development mode with auto-reload")
    parser.add_argument("--port", type=int, help="Port to run on")
    parser.add_argument("--host", help="Host to bind to")
    args = parser.parse_args()

    host = args.host or os.getenv("HOST", "0.0.0.0")
    port = args.port or int(os.getenv("PORT", 8100))
    reload_enabled = bool(args.dev)

    uvicorn.run(
        "bamboo_coding.server.main:app",
        host=host,
        port=port,
        reload=reload_enabled,
        factory=False,
    )


__all__ = ["app", "create_app", "main"]


if __name__ == "__main__":
    main()
