from __future__ import annotations

from pathlib import Path
from typing import Callable

import git_utils
from bamboo_coding.shared.protocol import TaskMessage


def _allowed_roots(repositories: dict[str, str] | list[str] | tuple[str, ...]) -> list[str]:
    if isinstance(repositories, dict):
        values = list(repositories.values()) or list(repositories.keys())
    else:
        values = list(repositories)
    return [str(Path(item).expanduser().resolve()) for item in values]


def _resolve_allowed_path(task: TaskMessage, repositories: dict[str, str] | list[str] | tuple[str, ...]) -> str:
    return _ensure_allowed_path(task.path, repositories)


def _ensure_allowed_path(raw_path: str, repositories: dict[str, str] | list[str] | tuple[str, ...]) -> str:
    target = str(Path(raw_path).expanduser().resolve())
    for root in _allowed_roots(repositories):
        try:
            Path(target).relative_to(root)
            return target
        except ValueError:
            continue
    raise PermissionError(f"Path outside allowed roots: {raw_path}")


def _resolve_repo_root(task: TaskMessage, repositories: dict[str, str] | list[str] | tuple[str, ...]) -> str:
    allowed_path = _resolve_allowed_path(task, repositories)
    return git_utils.resolve_git_repository_path(allowed_path)


def execute_task(task: TaskMessage, repositories: dict[str, str] | list[str] | tuple[str, ...]) -> dict:
    handler = _HANDLERS.get((task.capability, task.action))
    if handler is None:
        raise KeyError(f"Unsupported task: {task.capability}/{task.action}")
    git_utils.clear_cache()
    return handler(task, repositories)


def _fs_tree(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    include_nested = bool(task.params.get("all", False))
    if git_utils.is_git_repository_path(path):
        repo_path = git_utils.resolve_git_repository_path(path)
        return git_utils.get_file_tree(repo_path, changed_only=not include_nested)
    return git_utils.get_workspace_tree(path, include_nested=include_nested)


def _fs_browse(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    return git_utils.browse_workspace(path)


def _fs_read(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    return git_utils.read_workspace_file(path)


def _fs_read_raw(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    max_size = int(task.params.get("max_size_bytes") or task.params.get("max_size") or 0)
    kwargs = {"max_size_bytes": max_size} if max_size > 0 else {}
    return git_utils.read_workspace_file_bytes(path, **kwargs)


def _fs_write(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    return git_utils.write_workspace_file(path, task.params["content"], task.params.get("encoding", "utf-8"))


def _fs_mkdir(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    return git_utils.create_workspace_folder(path, bool(task.params.get("exist_ok", True)))


def _fs_delete(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    for root in _allowed_roots(repositories):
        if path == root:
            raise PermissionError(f"Refusing to delete workspace root: {path}")
    return git_utils.delete_workspace_path(path, bool(task.params.get("recursive", False)))


def _fs_rename(task: TaskMessage, repositories) -> dict:
    src = _resolve_allowed_path(task, repositories)
    raw_destination = task.params.get("to") or task.params.get("new_path")
    if not raw_destination:
        raise ValueError("Missing destination path (params.to)")
    dst = _ensure_allowed_path(str(raw_destination), repositories)
    for root in _allowed_roots(repositories):
        if src == root:
            raise PermissionError(f"Refusing to rename workspace root: {src}")
    return git_utils.rename_workspace_path(src, dst)


def _tree(task: TaskMessage, repositories) -> dict:
    show_all = bool(task.params.get("all", False))
    return git_utils.get_file_tree(_resolve_repo_root(task, repositories), changed_only=not show_all)


def _browse(task: TaskMessage, repositories) -> dict:
    return git_utils.browse_directory(_resolve_repo_root(task, repositories), task.params.get("path", "/"))


def _diff(task: TaskMessage, repositories) -> dict:
    return git_utils.get_file_diff(
        _resolve_repo_root(task, repositories),
        task.params["file"],
        bool(task.params.get("staged", False)),
        int(task.params.get("context", 3)),
    )


def _status(task: TaskMessage, repositories) -> dict:
    return git_utils.get_repo_status(_resolve_repo_root(task, repositories))


def _commits(task: TaskMessage, repositories) -> dict:
    limit = int(task.params.get("limit", 50))
    offset = int(task.params.get("offset", 0))
    repo_path = _resolve_repo_root(task, repositories)
    return {
        "commits": git_utils.get_commit_history(repo_path, limit=limit, offset=offset),
        "limit": limit,
        "offset": offset,
    }


def _commit_details(task: TaskMessage, repositories) -> dict:
    return git_utils.get_commit_details(_resolve_repo_root(task, repositories), task.params["commit_hash"])


def _read_file(task: TaskMessage, repositories) -> dict:
    return git_utils.read_file_content(_resolve_repo_root(task, repositories), task.params["file_path"])


def _write_file(task: TaskMessage, repositories) -> dict:
    return git_utils.write_file_content(
        _resolve_repo_root(task, repositories),
        task.params["file_path"],
        task.params["content"],
        task.params.get("encoding", "utf-8"),
    )


def _stage(task: TaskMessage, repositories) -> dict:
    repo_path = _resolve_repo_root(task, repositories)
    if task.params.get("stage_all"):
        return git_utils.stage_all_files(repo_path)
    return git_utils.stage_file(repo_path, task.params["file_path"])


def _unstage(task: TaskMessage, repositories) -> dict:
    return git_utils.unstage_file(_resolve_repo_root(task, repositories), task.params["file_path"])


def _list_branches(task: TaskMessage, repositories) -> dict:
    return git_utils.list_branches(_resolve_repo_root(task, repositories))


def _create_branch(task: TaskMessage, repositories) -> dict:
    return git_utils.create_branch(_resolve_repo_root(task, repositories), task.params["name"], task.params.get("start_point"))


def _checkout_branch(task: TaskMessage, repositories) -> dict:
    return git_utils.switch_branch(_resolve_repo_root(task, repositories), task.params["name"])


def _delete_branch(task: TaskMessage, repositories) -> dict:
    return git_utils.delete_branch(_resolve_repo_root(task, repositories), task.params["name"], bool(task.params.get("force", False)))


def _merge_branch(task: TaskMessage, repositories) -> dict:
    return git_utils.merge_branch(_resolve_repo_root(task, repositories), task.params["source"], task.params.get("message"))


def _create_commit(task: TaskMessage, repositories) -> dict:
    return git_utils.create_commit(
        _resolve_repo_root(task, repositories),
        task.params["message"],
        task.params.get("author_name"),
        task.params.get("author_email"),
    )


def _list_remotes(task: TaskMessage, repositories) -> dict:
    return git_utils.list_remotes(_resolve_repo_root(task, repositories))


def _add_remote(task: TaskMessage, repositories) -> dict:
    return git_utils.add_remote(
        _resolve_repo_root(task, repositories),
        task.params["name"],
        task.params["url"],
    )


def _remove_remote(task: TaskMessage, repositories) -> dict:
    return git_utils.remove_remote(
        _resolve_repo_root(task, repositories),
        task.params["name"],
    )


def _push_remote(task: TaskMessage, repositories) -> dict:
    return git_utils.push_to_remote(
        _resolve_repo_root(task, repositories),
        task.params["remote"],
        task.params.get("local_branch"),
        task.params.get("remote_branch"),
        bool(task.params.get("set_upstream", False)),
        bool(task.params.get("force", False)),
    )


def _pull_remote(task: TaskMessage, repositories) -> dict:
    return git_utils.pull_from_remote(
        _resolve_repo_root(task, repositories),
        task.params["remote"],
        task.params.get("local_branch"),
        task.params.get("remote_branch"),
        bool(task.params.get("rebase", False)),
    )


_HANDLERS: dict[tuple[str, str], Callable[[TaskMessage, dict[str, str] | list[str] | tuple[str, ...]], dict]] = {
    ("fs.tree", "get"): _fs_tree,
    ("fs.browse", "get"): _fs_browse,
    ("fs.file.read", "get"): _fs_read,
    ("fs.file.read_raw", "get"): _fs_read_raw,
    ("fs.file.write", "put"): _fs_write,
    ("fs.folder.create", "post"): _fs_mkdir,
    ("fs.path.delete", "delete"): _fs_delete,
    ("fs.path.rename", "put"): _fs_rename,
    ("repo.tree", "get"): _tree,
    ("repo.browse", "get"): _browse,
    ("repo.diff", "get"): _diff,
    ("repo.status", "get"): _status,
    ("repo.commits", "list"): _commits,
    ("repo.commit_details", "get"): _commit_details,
    ("repo.file.read", "get"): _read_file,
    ("repo.file.write", "put"): _write_file,
    ("repo.stage", "post"): _stage,
    ("repo.unstage", "post"): _unstage,
    ("repo.branches.list", "get"): _list_branches,
    ("repo.branches.create", "post"): _create_branch,
    ("repo.branches.checkout", "put"): _checkout_branch,
    ("repo.branches.delete", "delete"): _delete_branch,
    ("repo.branches.merge", "post"): _merge_branch,
    ("repo.commit.create", "post"): _create_commit,
    ("repo.remotes.list", "get"): _list_remotes,
    ("repo.remotes.add", "post"): _add_remote,
    ("repo.remotes.remove", "delete"): _remove_remote,
    ("repo.remotes.push", "post"): _push_remote,
    ("repo.remotes.pull", "post"): _pull_remote,
    ("git.remotes.list", "get"): _list_remotes,
    ("git.remotes.add", "post"): _add_remote,
    ("git.remotes.remove", "delete"): _remove_remote,
    ("git.remotes.push", "post"): _push_remote,
    ("git.remotes.pull", "post"): _pull_remote,
    ("git.status", "get"): _status,
    ("git.diff", "get"): _diff,
    ("git.commits", "list"): _commits,
    ("git.commit_details", "get"): _commit_details,
    ("git.stage", "post"): _stage,
    ("git.unstage", "post"): _unstage,
    ("git.branches.list", "get"): _list_branches,
    ("git.branches.create", "post"): _create_branch,
    ("git.branches.checkout", "put"): _checkout_branch,
    ("git.branches.delete", "delete"): _delete_branch,
    ("git.branches.merge", "post"): _merge_branch,
    ("git.commit.create", "post"): _create_commit,
}
