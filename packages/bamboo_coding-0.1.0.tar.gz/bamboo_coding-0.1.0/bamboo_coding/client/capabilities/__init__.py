"""Client capability handlers."""
