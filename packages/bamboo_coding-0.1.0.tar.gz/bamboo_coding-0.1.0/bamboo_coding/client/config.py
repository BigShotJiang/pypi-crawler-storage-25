from __future__ import annotations

import json
import os
import platform
import tomllib
from dataclasses import dataclass, field
from importlib import metadata
from pathlib import Path


DEFAULT_CONFIG_DIRNAME = ".bamboo-coding"
DEFAULT_CONFIG_FILENAME = "bamboo-coding.toml"
DEFAULT_CONTROLLER_URL = "ws://127.0.0.1:8100/ws/agents"
DEFAULT_CLIENT_ID = "bamboo-coding-client"


@dataclass(frozen=True)
class RepositoryConfig:
    repo_id: str
    name: str
    path: str


@dataclass(frozen=True)
class AgentConfig:
    controller_url: str
    client_id: str
    hostname: str
    version: str
    token: str
    token_path: Path
    journal_path: Path
    config_path: Path = field(default_factory=Path)
    max_concurrent_tasks: int = 1
    allowed_roots: tuple[str, ...] = field(default_factory=tuple)
    repositories: tuple[RepositoryConfig, ...] = field(default_factory=tuple)


def _first_env(*names: str) -> str | None:
    for name in names:
        value = os.getenv(name)
        if value:
            return value
    return None


def _default_version() -> str:
    try:
        return metadata.version("bamboo-coding")
    except metadata.PackageNotFoundError:
        return "0.1.0"


def _normalize_root(path_value: str) -> str:
    return str(Path(path_value).expanduser().resolve())


def _resolve_path(value: str | None, *, default: Path, base_dir: Path) -> Path:
    if not value:
        return default
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = base_dir / path
    return path.resolve()


def _load_toml(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open("rb") as handle:
        data = tomllib.load(handle)
    return data if isinstance(data, dict) else {}


def _coerce_allowed_roots(value: object) -> tuple[str, ...]:
    if isinstance(value, str):
        items = [item for item in value.split(os.pathsep) if item.strip()]
    elif isinstance(value, (list, tuple)):
        items = [str(item) for item in value if str(item).strip()]
    else:
        items = []
    return tuple(_normalize_root(item) for item in items)


def _load_stored_token(token_path: Path) -> str:
    if not token_path.exists():
        return ""
    try:
        payload = json.loads(token_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    token = payload.get("token")
    return token if isinstance(token, str) else ""


def _persist_token(token_path: Path, token: str) -> None:
    token_path.parent.mkdir(parents=True, exist_ok=True)
    token_path.write_text(json.dumps({"token": token}), encoding="utf-8")


def _load_legacy_token(default_token_path: Path) -> str:
    legacy_path = Path.cwd() / ".agent" / "token.json"
    token = _load_stored_token(legacy_path)
    if token and not default_token_path.exists():
        _persist_token(default_token_path, token)
    return token


def load_config() -> AgentConfig:
    config_home = Path(_first_env("BAMBOO_CODING_HOME") or (Path.home() / DEFAULT_CONFIG_DIRNAME)).expanduser().resolve()
    config_path = _resolve_path(
        _first_env("BAMBOO_CODING_CONFIG_PATH"),
        default=config_home / DEFAULT_CONFIG_FILENAME,
        base_dir=config_home,
    )
    raw_config = _load_toml(config_path)
    client_config = raw_config.get("client") if isinstance(raw_config.get("client"), dict) else {}
    storage_config = raw_config.get("storage") if isinstance(raw_config.get("storage"), dict) else {}

    storage_home_value = _first_env("BAMBOO_CODING_HOME", "AGENT_HOME")
    storage_home = Path(storage_home_value).expanduser().resolve() if storage_home_value else config_home

    controller_url = _first_env("BAMBOO_CODING_CONTROLLER_URL", "CONTROLLER_URL") or str(
        client_config.get("controller_url") or DEFAULT_CONTROLLER_URL
    )
    client_id = _first_env("BAMBOO_CODING_CLIENT_ID", "AGENT_CLIENT_ID") or str(
        client_config.get("client_id") or platform.node() or DEFAULT_CLIENT_ID
    )
    hostname = _first_env("BAMBOO_CODING_HOSTNAME", "AGENT_HOSTNAME") or str(
        client_config.get("hostname") or platform.node() or client_id
    )
    version = _first_env("BAMBOO_CODING_VERSION", "AGENT_VERSION") or str(client_config.get("version") or _default_version())
    allowed_roots = _coerce_allowed_roots(
        _first_env("BAMBOO_CODING_ALLOWED_ROOTS", "AGENT_ALLOWED_ROOTS", "AGENT_ROOT", "AGENT_REPO_PATH")
        or client_config.get("allowed_roots")
    )
    max_concurrent_tasks = int(
        _first_env("BAMBOO_CODING_MAX_CONCURRENT_TASKS", "AGENT_MAX_CONCURRENT_TASKS")
        or client_config.get("max_concurrent_tasks")
        or 1
    )

    token_path = _resolve_path(
        _first_env("BAMBOO_CODING_TOKEN_PATH", "AGENT_TOKEN_PATH") or storage_config.get("token_path"),
        default=storage_home / "token.json",
        base_dir=config_path.parent,
    )
    journal_path = _resolve_path(
        _first_env("BAMBOO_CODING_JOURNAL_PATH", "AGENT_JOURNAL_PATH") or storage_config.get("journal_path"),
        default=storage_home / "journal.db",
        base_dir=config_path.parent,
    )

    token = _first_env("BAMBOO_CODING_TOKEN", "AGENT_TOKEN") or _load_stored_token(token_path)
    if not token and not _first_env("BAMBOO_CODING_TOKEN_PATH", "AGENT_TOKEN_PATH", "AGENT_HOME"):
        token = _load_legacy_token(token_path)

    repositories = tuple(
        RepositoryConfig(
            repo_id=root,
            name=Path(root).name or root,
            path=root,
        )
        for root in allowed_roots
    )
    return AgentConfig(
        controller_url=controller_url,
        client_id=client_id,
        hostname=hostname,
        version=version,
        token=token,
        token_path=token_path,
        journal_path=journal_path,
        config_path=config_path,
        max_concurrent_tasks=max_concurrent_tasks,
        allowed_roots=allowed_roots,
        repositories=repositories,
    )
