from fastapi.testclient import TestClient

from bamboo_coding.server.main import create_app
from controller.app.services.agents import AgentService


def build_app(tmp_path):
    app = create_app(database_path=tmp_path / "controller.db")
    agents = AgentService(app.state.database)
    agents.create_registration_request("worker-1")
    agents.approve_registration("worker-1", token="token-1")
    agent = agents.register_connection(
        client_id="worker-1",
        token="token-1",
        client_info={"hostname": "worker-1", "version": "0.1.0", "platform": "linux"},
    )
    app.state.repositories.upsert_root_binding(
        agent_id=agent["agent_id"],
        path="/tmp/demo",
        name="Demo",
        status="ready",
    )
    return app


def test_health_check(tmp_path):
    app = create_app(database_path=tmp_path / "controller.db")
    client = TestClient(app)

    response = client.get("/api/health")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_list_roots_returns_paths(tmp_path):
    app = build_app(tmp_path)
    client = TestClient(app)

    response = client.get("/api/roots")

    assert response.status_code == 200
    assert response.json() == [{"path": "/tmp/demo", "name": "Demo", "status": "ready"}]


def test_browse_endpoint_dispatches_task(tmp_path):
    app = build_app(tmp_path)
    client = TestClient(app)

    async def fake_dispatch(path, capability, action, params, agent_id=None):
        assert path == "/tmp/demo"
        assert capability == "fs.browse"
        assert action == "get"
        assert params == {}
        assert agent_id is None
        return {"path": "/tmp/demo", "entries": [], "is_git_repo": False}

    app.state.router.dispatch_task = fake_dispatch
    response = client.get("/api/fs/browse", params={"path": "/tmp/demo"})

    assert response.status_code == 200
    assert response.json()["path"] == "/tmp/demo"


def test_status_endpoint_dispatches_task(tmp_path):
    app = build_app(tmp_path)
    client = TestClient(app)

    async def fake_dispatch(path, capability, action, params, agent_id=None):
        assert path == "/tmp/demo"
        assert capability == "git.status"
        assert action == "get"
        assert params == {}
        assert agent_id is None
        return {
            "branch": "main",
            "is_detached": False,
            "modified": ["README.md"],
            "added": [],
            "deleted": [],
            "untracked": [],
            "ahead": 0,
            "behind": 0,
        }

    app.state.router.dispatch_task = fake_dispatch
    response = client.get("/api/git/status", params={"path": "/tmp/demo"})

    assert response.status_code == 200
    assert response.json()["branch"] == "main"


def test_browse_endpoint_dispatches_task_with_selected_agent(tmp_path):
    app = build_app(tmp_path)
    client = TestClient(app)

    async def fake_dispatch(path, capability, action, params, agent_id=None):
        assert path == "/tmp/demo"
        assert capability == "fs.browse"
        assert action == "get"
        assert params == {}
        assert agent_id == "agent-2"
        return {"path": "/tmp/demo", "entries": [], "is_git_repo": False}

    app.state.router.dispatch_task = fake_dispatch
    response = client.get("/api/fs/browse", params={"path": "/tmp/demo", "agent_id": "agent-2"})

    assert response.status_code == 200
    assert response.json()["path"] == "/tmp/demo"


def test_diff_endpoint_requires_file_parameter(tmp_path):
    app = build_app(tmp_path)
    client = TestClient(app)

    response = client.get("/api/git/diff", params={"path": "/tmp/demo"})

    assert response.status_code == 400
    assert "Missing file parameter" in response.json()["message"]


def test_commits_endpoint_validates_limit_and_offset(tmp_path):
    app = build_app(tmp_path)
    client = TestClient(app)

    response_limit = client.get("/api/git/commits", params={"path": "/tmp/demo", "limit": 200})
    response_offset = client.get("/api/git/commits", params={"path": "/tmp/demo", "offset": -1})

    assert response_limit.status_code == 400
    assert response_offset.status_code == 400


def test_status_endpoint_returns_503_without_live_agent(tmp_path):
    app = build_app(tmp_path)
    client = TestClient(app)

    response = client.get("/api/git/status", params={"path": "/tmp/demo"})

    assert response.status_code == 503
    assert "No live agent" in response.json()["message"]
