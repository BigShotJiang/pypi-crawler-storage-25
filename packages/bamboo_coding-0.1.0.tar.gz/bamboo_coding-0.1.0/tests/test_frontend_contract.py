from __future__ import annotations

from pathlib import Path
import subprocess
import textwrap


def test_index_html_includes_bamboo_branding_assets():
    index_html = Path('static/index.html').read_text()
    terminal_html = Path('static/terminal.html').read_text()

    assert 'rel="icon"' in index_html
    assert '/static/favicon.ico' in index_html
    assert '/static/branding/bamboo-logo.png' in index_html
    assert 'brand-eyebrow' in index_html
    assert 'fonts.googleapis.com' not in index_html
    assert 'fonts.googleapis.com' not in terminal_html



def test_main_css_uses_structured_sanctuary_tokens_and_light_explorer_sidebar():
    main_css = Path('static/css/main.css').read_text()

    assert "--font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;" in main_css
    assert '--workspace-canvas' in main_css
    assert '--explorer-surface' in main_css
    assert '.sidebar {' in main_css
    assert 'background: var(--explorer-surface);' in main_css



def test_index_header_places_file_controls_on_the_left_and_workspace_actions_on_the_right():
    index_html = Path('static/index.html').read_text()
    header_html = index_html.split('</header>', 1)[0]
    sidebar_html = index_html.split('<aside class="sidebar"', 1)[1].split('<div class="file-tree"', 1)[0]

    assert 'class="header-leading"' in header_html
    assert 'class="header-file-controls header-action-group"' in header_html
    assert 'class="header-toolbar"' in header_html
    assert 'class="btn-header-icon btn-file-view active"' in header_html
    assert 'class="header-icon-select terminal-layout-label"' in header_html
    assert 'aria-label="Show changed files"' in header_html
    assert 'aria-label="Show all files"' in header_html
    assert 'aria-label="Stage all changed files"' in header_html
    assert 'aria-label="Refresh file tree"' in header_html
    assert 'aria-label="Switch client"' in header_html
    assert 'aria-label="Open terminal"' in header_html
    assert 'aria-label="Customize shortcuts"' in header_html
    assert 'aria-label="View commits"' in header_html
    assert 'aria-label="Commit staged changes"' in header_html
    assert 'sr-only' in header_html

    leading_start = header_html.index('class="header-leading"')
    center_start = header_html.index('class="header-center"')
    toolbar_start = header_html.index('class="header-toolbar"')
    leading_html = header_html[leading_start:center_start]
    toolbar_html = header_html[toolbar_start:]

    for element_id in ['stageAllBtn', 'fileViewChangedBtn', 'fileViewAllBtn', 'refreshBtn']:
        assert f'id="{element_id}"' in leading_html
        assert f'id="{element_id}"' not in sidebar_html
        assert f'id="{element_id}"' not in toolbar_html

    for element_id in ['switchClientBtn', 'openTerminalBtn', 'terminalLayoutSelect', 'shortcutsBtn', 'viewCommitsBtn', 'commitBtn']:
        assert f'id="{element_id}"' in toolbar_html



def test_toolbar_and_browser_styles_match_light_explorer_direction():
    main_css = Path('static/css/main.css').read_text()
    index_html = Path('static/index.html').read_text()

    active_block = main_css.split('.btn-file-view.active {', 1)[1].split('}', 1)[0]

    assert 'background: rgba(38, 115, 231, 0.12);' in active_block
    assert 'color: var(--primary-color);' in active_block
    assert '.header-leading {' in main_css
    assert '.header-file-controls {' in main_css
    assert '.header-toolbar {' in main_css
    assert '.btn-header-icon {' in main_css
    assert '.header-icon-select select {' in main_css
    assert '.sidebar .folder-name' in main_css
    assert 'var(--text-primary)' in main_css
    assert 'Select a file from the tree to inspect its diff or content' in index_html



def test_workspace_layout_selector_includes_right_sidebar_only():
    index_html = Path('static/index.html').read_text()
    terminal_html = Path('static/terminal.html').read_text()

    assert '<option value="right-sidebar">Right Sidebar</option>' in index_html
    assert 'value="right-sidebar"' not in terminal_html



def test_main_css_uses_one_pixel_workspace_pane_gaps():
    main_css = Path('static/css/main.css').read_text()

    assert '.app-main {' in main_css
    assert 'gap: 1px;' in main_css
    assert '.content {' in main_css
    assert 'padding: 1px;' in main_css
    assert '--workspace-right-terminal-width' in main_css
    assert '--workspace-right-terminal-gap: 1px;' in main_css
    assert 'body.workspace-right-sidebar-layout .app-main {' in main_css
    assert 'padding-right: calc(var(--workspace-right-terminal-width) + var(--workspace-right-terminal-gap));' in main_css



def test_terminal_manager_right_sidebar_layout_reserves_workspace_and_docks_overflow_sessions():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        function createClassList() {
          const classes = new Set();
          return {
            add(...tokens) { for (const token of tokens) classes.add(token); },
            remove(...tokens) { for (const token of tokens) classes.delete(token); },
            toggle(token, force) {
              if (force === undefined) {
                if (classes.has(token)) {
                  classes.delete(token);
                  return false;
                }
                classes.add(token);
                return true;
              }
              if (force) {
                classes.add(token);
                return true;
              }
              classes.delete(token);
              return false;
            },
            contains(token) { return classes.has(token); }
          };
        }

        function createStyle() {
          return {
            props: {},
            setProperty(name, value) { this.props[name] = value; },
            removeProperty(name) { delete this.props[name]; },
            getPropertyValue(name) { return this.props[name] || ''; }
          };
        }

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: createStyle(),
            classList: createClassList(),
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        const body = createElement('body');
        const appMain = createElement('main');
        const sidebar = createElement('aside');
        const content = createElement('section');

        globalThis.document = {
          body,
          createElement,
          querySelector(selector) {
            if (selector === '.app-header') {
              return { offsetHeight: 60 };
            }
            if (selector === '.app-main') {
              return appMain;
            }
            if (selector === '.sidebar') {
              return sidebar;
            }
            if (selector === '.content') {
              return content;
            }
            return null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1400,
          innerHeight: 900,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            focus() {}
          })
        });

        const one = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/a' });
        const two = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/b' });
        manager.applyLayout('right-sidebar');

        if (manager.activeLayoutId !== 'right-sidebar') {
          throw new Error(`wrong active layout: ${manager.activeLayoutId}`);
        }
        if (!manager.sessions.get(one).layoutManaged) {
          throw new Error('first terminal should be layout-managed');
        }
        if (manager.sessions.get(two).layoutManaged) {
          throw new Error('overflow terminal should not be layout-managed');
        }
        if (!manager.dockedSessionIds.includes(two)) {
          throw new Error(`overflow terminal should be docked: ${JSON.stringify(manager.dockedSessionIds)}`);
        }

        const frame = manager.sessions.get(one).frame;
        if (frame.top !== 61) {
          throw new Error(`expected top margin 61, got ${frame.top}`);
        }
        if (frame.left < 800) {
          throw new Error(`terminal frame should be docked on the right: ${JSON.stringify(frame)}`);
        }
        if (frame.width < 360 || frame.width > 560) {
          throw new Error(`unexpected right-sidebar width: ${frame.width}`);
        }
        if (!body.classList.contains('workspace-right-sidebar-layout')) {
          throw new Error('body should advertise right-sidebar layout state');
        }
        if (!appMain.classList.contains('workspace-right-sidebar-layout')) {
          throw new Error('workspace shell should advertise right-sidebar layout state');
        }

        const reservedWidth = body.style.getPropertyValue('--workspace-right-terminal-width');
        const reservedGap = body.style.getPropertyValue('--workspace-right-terminal-gap');
        if (!reservedWidth || !reservedWidth.endsWith('px')) {
          throw new Error(`missing reserved width variable: ${reservedWidth}`);
        }
        if (reservedGap !== '1px') {
          throw new Error(`expected 1px reserved gap, got ${reservedGap}`);
        }
        if (Number.parseInt(reservedWidth, 10) < frame.width) {
          throw new Error(`reserved workspace width should cover terminal width: ${reservedWidth} vs ${frame.width}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_file_tree_browser_mode_accepts_entries_payload():
    script = textwrap.dedent(
        """
        import { FileTree } from './static/js/file-tree.js';

        globalThis.fetch = async () => ({
          ok: true,
          async json() {
            return {
              path: '/tmp/demo',
              entries: [
                { name: 'src', path: '/tmp/demo/src', type: 'directory' },
                { name: 'README.md', path: '/tmp/demo/README.md', type: 'file', status: 'unmodified' }
              ]
            };
          }
        });

        const container = {
          innerHTML: '',
          querySelector() { return null; },
          querySelectorAll() { return []; },
          dispatchEvent() {}
        };

        const app = {
          buildApiUrl() {
            return '/api/fs/browse?path=/tmp/demo';
          }
        };

        const tree = new FileTree(container, () => {}, app);
        await tree.loadDirectory('/');

        const cached = tree.folderCache.get('/');
        if (!Array.isArray(cached) || cached.length !== 2) {
          throw new Error(`expected 2 cached entries, got ${JSON.stringify(cached)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_file_tree_uses_sidebar_modes_without_inline_browse_or_stage_controls():
    script = textwrap.dedent(
        """
        import { FileTree } from './static/js/file-tree.js';

        globalThis.fetch = async () => ({
          ok: true,
          async json() {
            return {
              path: '/',
              entries: [
                { name: 'src', path: 'src', type: 'directory' },
                { name: 'README.md', path: 'README.md', type: 'file', status: 'unmodified' }
              ]
            };
          }
        });

        const container = {
          innerHTML: '',
          querySelector() { return null; },
          querySelectorAll() { return []; },
          dispatchEvent() {}
        };

        const app = {
          buildApiUrl() {
            return '/api/fs/browse?path=/tmp/demo';
          }
        };

        const tree = new FileTree(container, () => {}, app);
        tree.files = [
          { path: 'src/app.js', status: 'modified', type: 'file' },
          { path: 'notes.txt', status: 'untracked', type: 'file' },
          { path: 'README.md', status: 'staged', type: 'file' }
        ];

        tree.renderChangedFiles();

        if (container.innerHTML.includes('Browse All Files')) {
          throw new Error(container.innerHTML);
        }
        if (container.innerHTML.includes('btn-stage-all')) {
          throw new Error(container.innerHTML);
        }
        if (typeof tree.getStageableCount !== 'function') {
          throw new Error('missing getStageableCount helper');
        }
        if (tree.getStageableCount() !== 2) {
          throw new Error(`expected 2 stageable files, got ${tree.getStageableCount()}`);
        }

        await tree.setSidebarMode('browser', '/');
        if (tree.viewMode !== 'browser') {
          throw new Error(`expected browser mode, got ${tree.viewMode}`);
        }
        if (!container.innerHTML.includes('browser-view')) {
          throw new Error(container.innerHTML);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_code_editor_accepts_workspace_file_payload_with_path_field():
    script = textwrap.dedent(
        """
        import { CodeEditor } from './static/js/code-editor.js';

        globalThis.window = {
          CodeMirror: {
            basicSetup: {},
            languages: {},
            EditorView: class {
              constructor(options) {
                this.options = options;
              }
              destroy() {}
            }
          }
        };

        window.CodeMirror.EditorView.editable = { of(value) { return { editable: value }; } };
        window.CodeMirror.EditorView.updateListener = { of(listener) { return { listener }; } };

        const container = {
          querySelector() { return null; }
        };

        const editor = new CodeEditor(container, {});
        editor.displayContent({
          path: '/tmp/demo/AGENTS.md',
          content: 'hello',
          encoding: 'utf-8',
          size: 5,
          mime_type: 'text/plain',
          is_binary: false
        });

        if (!editor.editor || editor.editor.options.doc !== 'hello') {
          throw new Error('editor did not receive workspace file content');
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_git_diff_app_routes_sidebar_selection_to_diff_or_content_by_status():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const mainContent = { innerHTML: '' };
        const filePathEl = { textContent: '', style: {}, title: '', classList: { add() {}, remove() {} } };
        const diffViewerEl = { innerHTML: '' };

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector(selector) {
            return selector === '.app-main' ? mainContent : null;
          },
          querySelectorAll() { return []; },
          getElementById(id) {
            if (id === 'filePath') return filePathEl;
            if (id === 'diffViewer') return diffViewerEl;
            return null;
          },
          createElement() { return { textContent: '', innerHTML: '' }; },
          head: { appendChild() {} }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-2&path=/tmp/demo')
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.selectedAgentId = 'agent-2';
        app.selectedPath = '/tmp/demo';
        app.isGitRepo = true;

        const calls = [];
        app.loadDiff = async (filePath) => calls.push(['diff', filePath]);
        app.loadMainFileContent = async (filePath) => calls.push(['content', filePath]);

        await app.onFileSelected({ path: '/tmp/demo/src/app.js', status: 'modified' });
        await app.onFileSelected({ path: '/tmp/demo/README.md', status: 'unmodified' });

        if (!calls.find((entry) => entry[0] === 'diff' && entry[1] === '/tmp/demo/src/app.js')) {
          throw new Error(`missing diff call: ${JSON.stringify(calls)}`);
        }
        if (!calls.find((entry) => entry[0] === 'content' && entry[1] === '/tmp/demo/README.md')) {
          throw new Error(`missing content call: ${JSON.stringify(calls)}`);
        }
        if (filePathEl.textContent !== '/tmp/demo/README.md') {
          throw new Error(`unexpected file path header: ${filePathEl.textContent}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_requests_worktree_diff_for_untracked_files_even_in_staged_mode():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const mainContent = { innerHTML: '' };
        const filePathEl = { textContent: '', style: {}, title: '', classList: { add() {}, remove() {} } };
        const diffViewerEl = { innerHTML: '' };

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector(selector) {
            return selector === '.app-main' ? mainContent : null;
          },
          querySelectorAll() { return []; },
          getElementById(id) {
            if (id === 'filePath') return filePathEl;
            if (id === 'diffViewer') return diffViewerEl;
            return null;
          },
          createElement() { return { textContent: '', innerHTML: '' }; },
          head: { appendChild() {} }
        };

        globalThis.window = {
          location: new URL('http://localhost/?path=/tmp/demo')
        };

        let requestedUrl = null;
        globalThis.fetch = async (url) => {
          requestedUrl = new URL(url, 'http://localhost');
          return {
            ok: true,
            async json() {
              return { diff: `@@ -0,0 +1 @@\n+hello`, additions: 1, deletions: 0, is_binary: false, file_path: 'notes.txt' };
            }
          };
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.selectedPath = '/tmp/demo';
        app.isGitRepo = true;
        app.showStaged = true;
        app.showLoading = () => {};
        app.showError = (message) => { throw new Error(message); };
        app.diffViewer = { render() {}, setViewMode() {} };
        app.currentFile = { path: '/tmp/demo/notes.txt', status: 'untracked' };

        await app.loadDiff('/tmp/demo/notes.txt');

        if (!requestedUrl) {
          throw new Error('diff request was not sent');
        }
        if (requestedUrl.pathname !== '/api/git/diff') {
          throw new Error(`unexpected pathname: ${requestedUrl.pathname}`);
        }
        if (requestedUrl.searchParams.get('file') !== 'notes.txt') {
          throw new Error(`unexpected file path: ${requestedUrl.search}`);
        }
        if (requestedUrl.searchParams.get('staged') !== 'false') {
          throw new Error(`expected untracked file to force unstaged diff, got ${requestedUrl.search}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_build_api_url_includes_selected_agent():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const mainContent = { innerHTML: '' };
        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector(selector) {
            return selector === '.app-main' ? mainContent : null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          createElement() { return {}; },
          head: { appendChild() {} }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-2&path=/tmp/demo')
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.selectedAgentId = 'agent-2';
        app.selectedPath = '/tmp/demo';

        const url = new URL(app.buildApiUrl('/api/repo/status'), 'http://localhost');
        if (url.pathname !== '/api/git/status') {
          throw new Error(`unexpected pathname: ${url.pathname}`);
        }
        if (url.searchParams.get('path') !== '/tmp/demo') {
          throw new Error(`missing path param: ${url.search}`);
        }
        if (url.searchParams.get('agent_id') !== 'agent-2') {
          throw new Error(`missing agent_id param: ${url.search}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_git_diff_app_renders_client_selector_before_workspace_paths():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const mainContent = { innerHTML: '' };
        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector(selector) {
            return selector === '.app-main' ? mainContent : null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          createElement() { return {}; },
          head: { appendChild() {} }
        };

        globalThis.window = {
          location: new URL('http://localhost/')
        };

        globalThis.fetch = async (url) => {
          if (url === '/api/agents') {
            return {
              ok: true,
              async json() {
                return [
                  {
                    agent_id: 'agent-1',
                    client_id: 'worker-1',
                    approval_status: 'approved',
                    status: 'connected',
                    client_info: { hostname: 'box-1' },
                    roots: [{ path: '/tmp/demo', name: 'Demo' }]
                  },
                  {
                    agent_id: 'agent-2',
                    client_id: 'worker-2',
                    approval_status: 'pending',
                    status: 'pending',
                    client_info: { hostname: 'box-2' },
                    roots: []
                  }
                ];
              }
            };
          }
          throw new Error(`unexpected fetch: ${url}`);
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        await app.showRepositorySelector();

        if (!mainContent.innerHTML.includes('Select Client')) {
          throw new Error(mainContent.innerHTML);
        }
        if (!mainContent.innerHTML.includes('worker-1')) {
          throw new Error('approved client missing');
        }
        if (!mainContent.innerHTML.includes('Pending approval')) {
          throw new Error('pending client section missing');
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_git_diff_app_renders_selected_client_workspace_list():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const mainContent = { innerHTML: '' };
        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector(selector) {
            return selector === '.app-main' ? mainContent : null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          createElement() { return {}; },
          head: { appendChild() {} }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1')
        };

        globalThis.fetch = async (url) => {
          if (url === '/api/agents') {
            return {
              ok: true,
              async json() {
                return [
                  {
                    agent_id: 'agent-1',
                    client_id: 'worker-1',
                    approval_status: 'approved',
                    status: 'connected',
                    client_info: { hostname: 'box-1' },
                    roots: [{ path: '/tmp/demo', name: 'Demo' }]
                  }
                ];
              }
            };
          }
          if (String(url).startsWith('/api/fs/browse?')) {
            return {
              ok: true,
              async json() {
                return {
                  path: '/tmp/demo',
                  entries: [{ name: 'src', path: '/tmp/demo/src', type: 'directory' }]
                };
              }
            };
          }
          throw new Error(`unexpected fetch: ${url}`);
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.selectedAgentId = 'agent-1';
        await app.showRepositorySelector();

        if (!mainContent.innerHTML.includes('Select Workspace')) {
          throw new Error(mainContent.innerHTML);
        }
        if (!mainContent.innerHTML.includes('/tmp/demo')) {
          throw new Error('root path missing');
        }
        if (!mainContent.innerHTML.includes('src')) {
          throw new Error('child entry missing');
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_git_diff_app_selector_styles_allow_scrolling_for_long_lists():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const appended = [];
        const mainContent = { innerHTML: '' };
        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector(selector) {
            return selector === '.app-main' ? mainContent : null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          createElement() { return {}; },
          head: { appendChild(node) { appended.push(node); } }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1')
        };

        globalThis.fetch = async (url) => {
          if (url === '/api/agents') {
            return {
              ok: true,
              async json() {
                return [
                  {
                    agent_id: 'agent-1',
                    client_id: 'worker-1',
                    approval_status: 'approved',
                    status: 'connected',
                    client_info: { hostname: 'box-1' },
                    roots: [{ path: '/tmp/demo', name: 'Demo' }]
                  }
                ];
              }
            };
          }
          if (String(url).startsWith('/api/fs/browse?')) {
            return {
              ok: true,
              async json() {
                return { path: '/tmp/demo', entries: [] };
              }
            };
          }
          throw new Error(`unexpected fetch: ${url}`);
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.selectedAgentId = 'agent-1';
        await app.showRepositorySelector();

        const styleNode = appended.find((node) => node.id === 'repo-selector-styles');
        if (!styleNode) {
          throw new Error('selector style node missing');
        }
        if (!styleNode.textContent.includes('overflow-y: auto;')) {
          throw new Error(styleNode.textContent);
        }
        if (!styleNode.textContent.includes('align-items: flex-start;')) {
          throw new Error(styleNode.textContent);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_terminal_manager_tracks_docked_sessions_and_beforeunload_warning():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        const listeners = new Map();

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          getElementById() { return null; },
          querySelector() { return null; },
          querySelectorAll() { return []; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener(type, handler) { listeners.set(type, handler); },
          removeEventListener(type, handler) {
            if (listeners.get(type) === handler) {
              listeners.delete(type);
            }
          }
        };

        const events = [];
        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() { events.push(['open', options.sessionId, options.agentId, options.path]); },
            minimize() { events.push(['minimize', options.sessionId]); },
            restore() { events.push(['restore', options.sessionId]); },
            destroy() { events.push(['destroy', options.sessionId]); },
            updateDockState() {},
            focus() {}
          })
        });

        const sessionId = manager.openFromCurrentSelection();
        if (!sessionId) {
          throw new Error('session id missing');
        }
        if (!listeners.has('beforeunload')) {
          throw new Error('beforeunload listener missing');
        }

        const unloadEvent = {
          preventDefaultCalled: false,
          preventDefault() { this.preventDefaultCalled = true; },
          returnValue: undefined
        };
        listeners.get('beforeunload')(unloadEvent);
        if (!unloadEvent.preventDefaultCalled || unloadEvent.returnValue !== '') {
          throw new Error('beforeunload protection missing');
        }

        manager.minimizeSession(sessionId);
        if (!manager.dockedSessionIds.includes(sessionId)) {
          throw new Error(`session not docked: ${JSON.stringify(manager.dockedSessionIds)}`);
        }

        manager.restoreSession(sessionId);
        if (manager.dockedSessionIds.includes(sessionId)) {
          throw new Error('session still docked after restore');
        }

        manager.closeSession(sessionId);
        if (listeners.has('beforeunload')) {
          throw new Error('beforeunload listener not removed');
        }

        const labels = events.map((entry) => entry[0]);
        const expected = ['open', 'minimize', 'restore', 'destroy'];
        for (const label of expected) {
          if (!labels.includes(label)) {
            throw new Error(`missing event ${label}: ${JSON.stringify(events)}`);
          }
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_opens_terminal_for_current_selection():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          createElement() { return {}; },
          head: { appendChild() {} }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo')
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.selectedAgentId = 'agent-1';
        app.selectedPath = '/tmp/demo';

        let opened = null;
        app.terminalManager = {
          openFromCurrentSelection() {
            opened = ['agent-1', '/tmp/demo'];
            return 'term-1';
          }
        };

        app.openTerminalForCurrentSelection();

        if (!opened || opened[0] !== 'agent-1' || opened[1] !== '/tmp/demo') {
          throw new Error(`terminal did not open from current selection: ${JSON.stringify(opened)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_opens_new_terminal_from_ctrl_p_shortcut():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const listeners = new Map();

        function addListener(type, handler) {
          if (!listeners.has(type)) listeners.set(type, []);
          listeners.get(type).push(handler);
        }

        function genericEl() {
          return {
            style: {},
            value: 'free',
            innerHTML: '',
            textContent: '',
            disabled: false,
            hidden: false,
            classList: { add() {}, remove() {}, toggle() {} },
            addEventListener(type, handler) { addListener(type, handler); },
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        const selectEl = genericEl();

        globalThis.document = {
          readyState: 'loading',
          addEventListener(type, handler) { addListener(type, handler); },
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'terminalLayoutSelect') return selectEl;
            return genericEl();
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        let opened = null;
        app.terminalManager = {
          openFromCurrentSelection() {
            opened = 'term-1';
            return opened;
          }
        };

        app.attachEventListeners();

        const keydownHandlers = listeners.get('keydown') || [];
        const target = { tagName: 'DIV', isContentEditable: false, closest() { return null; } };

        for (const handler of keydownHandlers) {
          handler({ key: 'p', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }

        if (opened !== 'term-1') {
          throw new Error(`expected Ctrl+P to open a terminal: ${opened}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_manager_applies_layout_and_docks_overflow_sessions():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        const listeners = new Map();

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector(selector) {
            if (selector === '.app-header') {
              return { offsetHeight: 56 };
            }
            return null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1400,
          innerHeight: 900,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener(type, handler) { listeners.set(type, handler); },
          removeEventListener(type, handler) {
            if (listeners.get(type) === handler) listeners.delete(type);
          }
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            focus() {}
          })
        });

        const one = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/a' });
        const two = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/b' });
        const three = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/c' });
        manager.applyLayout('columns-2');

        if (manager.activeLayoutId !== 'columns-2') {
          throw new Error(`wrong active layout: ${manager.activeLayoutId}`);
        }
        if (!manager.sessions.get(one).layoutManaged || !manager.sessions.get(two).layoutManaged) {
          throw new Error('first two terminals should be layout-managed');
        }
        if (manager.sessions.get(three).layoutManaged) {
          throw new Error('third terminal should not be layout-managed');
        }
        if (!manager.dockedSessionIds.includes(three)) {
          throw new Error(`third terminal should be docked: ${JSON.stringify(manager.dockedSessionIds)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_manager_assigns_page_local_numeric_terminal_labels():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector(selector) {
            if (selector === '.app-header') {
              return { offsetHeight: 60 };
            }
            return null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1400,
          innerHeight: 900,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const titles = [];
        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => {
            titles.push(options.title);
            return {
              ...options,
              open() {},
              minimize() {},
              restore() {},
              destroy() {},
              updateDockState() {},
              setWindowIndex() {},
              setFrame() {},
              focus() {},
              setTitle() {}
            };
          }
        });

        const one = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/a' });
        const two = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/b' });
        const three = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/c' });
        manager.closeSession(two);
        const four = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/d' });

        const labels = [manager.sessions.get(one)?.title, manager.sessions.get(three)?.title, manager.sessions.get(four)?.title];
        if (JSON.stringify(titles) !== JSON.stringify(['1', '2', '3', '4'])) {
          throw new Error(`expected numeric titles, got ${JSON.stringify(titles)}`);
        }
        if (JSON.stringify(labels) !== JSON.stringify(['1', '3', '4'])) {
          throw new Error(`expected surviving labels to remain stable, got ${JSON.stringify(labels)}`);
        }
      """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_manager_active_layout_autofills_then_floats_new_terminal():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector() { return null; },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1280,
          innerHeight: 800,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            focus() {}
          })
        });

        manager.applyLayout('columns-2');
        const one = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/a' });
        const two = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/b' });
        const three = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/c' });

        if (!manager.sessions.get(one).layoutManaged || !manager.sessions.get(two).layoutManaged) {
          throw new Error('first two terminals should join layout automatically');
        }
        if (manager.sessions.get(three).layoutManaged) {
          throw new Error('third terminal should float once layout is full');
        }
        if (manager.dockedSessionIds.includes(three)) {
          throw new Error('third terminal should float, not dock, on new open');
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_manager_hidden_layout_docks_existing_and_new_terminals():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector() { return null; },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1280,
          innerHeight: 800,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            focus() {}
          })
        });

        const one = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/a' });
        const two = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/b' });

        manager.applyLayout('hidden');

        if (manager.activeLayoutId !== 'hidden') {
          throw new Error(`wrong active layout: ${manager.activeLayoutId}`);
        }
        if (!manager.dockedSessionIds.includes(one) || !manager.dockedSessionIds.includes(two)) {
          throw new Error(`hidden layout should dock all open terminals: ${JSON.stringify(manager.dockedSessionIds)}`);
        }
        if (!manager.sessions.get(one).minimized || !manager.sessions.get(two).minimized) {
          throw new Error('hidden layout should minimize existing terminals');
        }

        const three = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/c' });
        if (!manager.dockedSessionIds.includes(three)) {
          throw new Error(`new terminal should dock while hidden layout is active: ${JSON.stringify(manager.dockedSessionIds)}`);
        }
        if (!manager.sessions.get(three).minimized) {
          throw new Error('new terminal should start minimized while hidden layout is active');
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_manager_detaches_and_maximizes_terminal_windows():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector(selector) {
            if (selector === '.app-header') {
              return { offsetHeight: 60 };
            }
            return null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1440,
          innerHeight: 960,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            focus() {}
          })
        });

        const terminalId = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/a' });
        manager.applyLayout('single');
        manager.detachSessionToFloat(terminalId, { left: 40, top: 120, width: 640, height: 360 });

        const floating = manager.sessions.get(terminalId);
        if (floating.layoutManaged) {
          throw new Error('terminal should be detached from layout');
        }
        if (floating.frame.left !== 40 || floating.frame.width !== 640) {
          throw new Error(`unexpected floating frame: ${JSON.stringify(floating.frame)}`);
        }

        const before = { ...floating.frame };
        manager.toggleMaximizeSession(terminalId);
        const maximized = manager.sessions.get(terminalId);
        if (!maximized.maximized) {
          throw new Error('terminal should be maximized');
        }
        manager.toggleMaximizeSession(terminalId);
        const restored = manager.sessions.get(terminalId);
        if (restored.maximized) {
          throw new Error('terminal should restore from maximized');
        }
        if (restored.frame.left !== before.left || restored.frame.height !== before.height) {
          throw new Error(`floating frame should restore: ${JSON.stringify(restored.frame)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_applies_terminal_layout_selection():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const listeners = new Map();
        const selectEl = {
          value: 'columns-2',
          addEventListener(type, handler) { listeners.set(type, handler); }
        };

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return {}; },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'terminalLayoutSelect') return selectEl;
            return { addEventListener() {}, classList: { toggle() {}, remove() {}, add() {} }, style: {} };
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        let selected = null;
        app.terminalManager = {
          applyLayout(value) {
            selected = value;
          }
        };

        app.attachEventListeners();
        listeners.get('change')({ target: selectEl });

        if (selected !== 'columns-2') {
          throw new Error(`layout selection not forwarded: ${selected}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_auto_opens_terminal_when_right_sidebar_layout_selected():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const listeners = new Map();
        const selectEl = {
          value: 'right-sidebar',
          addEventListener(type, handler) { listeners.set(type, handler); }
        };

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return {}; },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'terminalLayoutSelect') return selectEl;
            return { addEventListener() {}, classList: { toggle() {}, remove() {}, add() {} }, style: {} };
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        let selected = null;
        let opened = null;
        app.terminalManager = {
          applyLayout(value) {
            selected = value;
          },
          hasActiveSessions() {
            return false;
          },
          openFromCurrentSelection() {
            opened = 'term-1';
            return opened;
          }
        };

        app.attachEventListeners();
        listeners.get('change')({ target: selectEl });

        if (selected !== 'right-sidebar' || selectEl.value !== 'right-sidebar') {
          throw new Error(`right-sidebar layout selection not forwarded: ${JSON.stringify({ selected, value: selectEl.value })}`);
        }
        if (opened !== 'term-1') {
          throw new Error(`right-sidebar layout should auto-open terminal when none exist: ${opened}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_defaults_to_full_file_browser_on_git_workspace_load():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        function genericEl() {
          return {
            style: {},
            value: '',
            innerHTML: '',
            textContent: '',
            disabled: false,
            classList: { add() {}, remove() {}, toggle() {} },
            addEventListener() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById() { return genericEl(); }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        const calls = [];

        app.showLoading = () => {};
        app.initializeComponents = () => {
          app.fileTree = {
            async loadTree() {
              calls.push(['loadTree']);
            },
            async switchToBrowser(path) {
              calls.push(['switchToBrowser', path]);
            }
          };
        };
        app.attachEventListeners = () => {};
        app.loadRepositoryStatus = async () => {
          app.isGitRepo = true;
        };

        await app.init();

        if (calls.length !== 1 || calls[0][0] !== 'switchToBrowser' || calls[0][1] !== '/') {
          throw new Error(`expected init to open full file browser at repo root, got ${JSON.stringify(calls)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_shortcut_manager_rejects_duplicate_terminal_bindings():
    script = textwrap.dedent(
        """
        import { ShortcutManager } from './static/js/shortcut-manager.js';

        const manager = new ShortcutManager({
          documentRef: { addEventListener() {}, removeEventListener() {} },
          shouldHandleEvent() { return true; }
        });

        manager.registerAction('hideAllTerminals', {
          label: 'Hide All Terminals',
          defaultBinding: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'ArrowDown' },
          handler() {}
        });
        manager.registerAction('layout2x2', {
          label: '2x2 Terminal Layout',
          defaultBinding: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'ArrowUp' },
          handler() {}
        });

        const duplicate = { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'ArrowDown' };
        const validation = manager.validateBindings({
          hideAllTerminals: duplicate,
          layout2x2: duplicate
        });

        if (validation.valid) {
          throw new Error('duplicate bindings should not validate');
        }
        if (!String(validation.message || '').includes('Hide All Terminals')) {
          throw new Error(`unexpected validation message: ${validation.message}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_uses_default_terminal_shortcuts_and_syncs_layout_select():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const listeners = new Map();

        function addListener(type, handler) {
          if (!listeners.has(type)) listeners.set(type, []);
          listeners.get(type).push(handler);
        }

        function genericEl() {
          return {
            style: {},
            value: 'free',
            innerHTML: '',
            textContent: '',
            disabled: false,
            classList: { add() {}, remove() {}, toggle() {} },
            addEventListener(type, handler) { addListener(type, handler); },
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        const selectEl = genericEl();
        const shortcutButtonEl = genericEl();

        globalThis.document = {
          readyState: 'loading',
          addEventListener(type, handler) { addListener(type, handler); },
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'terminalLayoutSelect') return selectEl;
            if (id === 'shortcutsBtn') return shortcutButtonEl;
            return genericEl();
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        const applied = [];
        app.terminalManager = {
          applyLayout(value) {
            applied.push(value);
          }
        };

        app.attachEventListeners();

        const keydownHandlers = listeners.get('keydown') || [];
        const target = { tagName: 'DIV', isContentEditable: false, closest() { return null; } };

        for (const handler of keydownHandlers) {
          handler({ key: 'ArrowDown', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }
        if (applied[0] !== 'hidden' || selectEl.value !== 'hidden') {
          throw new Error(`expected hidden layout from Ctrl+Down: ${JSON.stringify({ applied, value: selectEl.value })}`);
        }

        for (const handler of keydownHandlers) {
          handler({ key: 'ArrowUp', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }
        if (applied[1] !== 'grid-2x2' || selectEl.value !== 'grid-2x2') {
          throw new Error(`expected 2x2 layout from Ctrl+Up: ${JSON.stringify({ applied, value: selectEl.value })}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_uses_saved_terminal_shortcut_bindings():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() {
            return JSON.stringify({
              viewMode: 'unified',
              terminalShortcuts: {
                hideAllTerminals: { ctrlKey: true, altKey: true, shiftKey: false, metaKey: false, key: 'h' },
                layout2x2: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'ArrowUp' }
              }
            });
          },
          setItem() {}
        };

        const listeners = new Map();

        function addListener(type, handler) {
          if (!listeners.has(type)) listeners.set(type, []);
          listeners.get(type).push(handler);
        }

        function genericEl() {
          return {
            style: {},
            value: 'free',
            innerHTML: '',
            textContent: '',
            disabled: false,
            classList: { add() {}, remove() {}, toggle() {} },
            addEventListener(type, handler) { addListener(type, handler); },
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        const selectEl = genericEl();

        globalThis.document = {
          readyState: 'loading',
          addEventListener(type, handler) { addListener(type, handler); },
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'terminalLayoutSelect') return selectEl;
            return genericEl();
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        let applied = null;
        app.terminalManager = {
          applyLayout(value) {
            applied = value;
          }
        };

        app.attachEventListeners();

        const keydownHandlers = listeners.get('keydown') || [];
        const target = { tagName: 'DIV', isContentEditable: false, closest() { return null; } };

        for (const handler of keydownHandlers) {
          handler({ key: 'ArrowDown', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }
        if (applied !== null) {
          throw new Error(`default binding should not fire after customization: ${applied}`);
        }

        for (const handler of keydownHandlers) {
          handler({ key: 'h', ctrlKey: true, altKey: true, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }
        if (applied !== 'hidden' || selectEl.value !== 'hidden') {
          throw new Error(`saved shortcut binding did not apply hidden layout: ${JSON.stringify({ applied, value: selectEl.value })}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_git_diff_app_opens_terminal_shortcut_dialog_from_header_button():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        function genericEl() {
          return {
            style: {},
            value: 'free',
            innerHTML: '',
            textContent: '',
            disabled: false,
            classList: { add() {}, remove() {}, toggle() {} },
            listeners: new Map(),
            addEventListener(type, handler) { this.listeners.set(type, handler); },
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        const shortcutButtonEl = genericEl();
        const selectEl = genericEl();

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'shortcutsBtn') return shortcutButtonEl;
            if (id === 'terminalLayoutSelect') return selectEl;
            return genericEl();
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        let opened = false;
        app.terminalShortcutManager = {
          start() {},
          registerAction() {},
          updateBindings() {},
          getBindings() { return {}; },
          getDefaultBindings() { return {}; },
          getActionDefinitions() { return []; }
        };
        app.terminalShortcutsDialog = {
          open() { opened = true; },
          isOpen() { return false; }
        };

        app.attachEventListeners();
        shortcutButtonEl.listeners.get('click')();

        if (!opened) {
          throw new Error('shortcut dialog did not open from header button');
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_terminal_manager_uses_tighter_layout_spacing():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector(selector) {
            if (selector === '.app-header') {
              return { offsetHeight: 60 };
            }
            return null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1400,
          innerHeight: 900,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            focus() {}
          })
        });

        const one = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/a' });
        const two = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/b' });
        manager.applyLayout('columns-2');

        const frameOne = manager.sessions.get(one).frame;
        const frameTwo = manager.sessions.get(two).frame;
        const gap = frameTwo.left - (frameOne.left + frameOne.width);

        if (frameOne.left !== 1) {
          throw new Error(`expected left margin 1, got ${frameOne.left}`);
        }
        if (frameOne.top !== 61) {
          throw new Error(`expected top margin 61, got ${frameOne.top}`);
        }
        if (gap !== 1) {
          throw new Error(`expected layout gap 1, got ${gap}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_dock_uses_two_pixel_chip_gap_and_full_height_work_area():
    terminal_css = Path('static/css/terminal.css').read_text()

    assert '.terminal-dock {' in terminal_css
    assert 'gap: 2px;' in terminal_css

    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector(selector) {
            if (selector === '.app-header') {
              return { offsetHeight: 60 };
            }
            return null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1400,
          innerHeight: 900,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            focus() {}
          })
        });

        const bounds = manager.getWorkAreaBounds();
        if (bounds.top !== 61) {
          throw new Error(`expected top margin 61, got ${bounds.top}`);
        }
        if (bounds.height !== 838) {
          throw new Error(`expected full-height work area of 838, got ${bounds.height}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_manager_reflows_layout_when_viewport_resizes():
    script = textwrap.dedent(
        """
        import { TerminalManager } from './static/js/terminal-manager.js';

        const listeners = new Map();

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector(selector) {
            if (selector === '.app-header') {
              return { offsetHeight: 60 };
            }
            return null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1400,
          innerHeight: 900,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener(type, handler) { listeners.set(type, handler); },
          removeEventListener(type, handler) {
            if (listeners.get(type) === handler) {
              listeners.delete(type);
            }
          }
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo' },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            focus() {}
          })
        });

        const one = manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/a' });
        manager.openTerminal({ agentId: 'agent-1', path: '/tmp/demo/b' });
        manager.applyLayout('columns-2');

        const before = { ...manager.sessions.get(one).frame };

        window.innerWidth = 1000;
        window.innerHeight = 700;
        listeners.get('resize')();

        const after = manager.sessions.get(one).frame;

        if (after.width >= before.width) {
          throw new Error(`layout width did not shrink after resize: before=${before.width} after=${after.width}`);
        }
        if (after.height >= before.height) {
          throw new Error(`layout height did not shrink after resize: before=${before.height} after=${after.height}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_shortcut_manager_allows_exclusive_scope_duplicates_but_rejects_workspace_conflicts():
    script = textwrap.dedent(
        """
        import { ShortcutManager } from './static/js/shortcut-manager.js';

        const manager = new ShortcutManager({
          documentRef: { addEventListener() {}, removeEventListener() {} },
          shouldHandleEvent() { return true; },
          getActiveScopes() { return ['workspace']; }
        });

        manager.registerAction('closeCommitDialog', {
          scope: 'commit-dialog',
          label: 'Close Commit Dialog',
          defaultBinding: { ctrlKey: false, altKey: false, shiftKey: false, metaKey: false, key: 'Escape' },
          handler() {}
        });
        manager.registerAction('closeFileBrowserDialog', {
          scope: 'file-browser-dialog',
          label: 'Close File Browser Dialog',
          defaultBinding: { ctrlKey: false, altKey: false, shiftKey: false, metaKey: false, key: 'Escape' },
          handler() {}
        });

        const allowed = manager.validateBindings({
          closeCommitDialog: { ctrlKey: false, altKey: false, shiftKey: false, metaKey: false, key: 'Escape' },
          closeFileBrowserDialog: { ctrlKey: false, altKey: false, shiftKey: false, metaKey: false, key: 'Escape' }
        });

        if (!allowed.valid) {
          throw new Error(`expected Escape duplicates across exclusive scopes to validate, got: ${allowed.message}`);
        }

        manager.registerAction('refreshWorkspace', {
          scope: 'workspace',
          label: 'Refresh Workspace',
          defaultBinding: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'r' },
          handler() {}
        });
        manager.registerAction('openCommitHistory', {
          scope: 'workspace',
          label: 'Open Commit History',
          defaultBinding: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'h' },
          handler() {}
        });

        const rejected = manager.validateBindings({
          closeCommitDialog: { ctrlKey: false, altKey: false, shiftKey: false, metaKey: false, key: 'Escape' },
          closeFileBrowserDialog: { ctrlKey: false, altKey: false, shiftKey: false, metaKey: false, key: 'Escape' },
          refreshWorkspace: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'r' },
          openCommitHistory: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'r' }
        });

        if (rejected.valid) {
          throw new Error('expected duplicate workspace bindings to be rejected');
        }
        if (!String(rejected.message || '').includes('Refresh Workspace')) {
          throw new Error(`unexpected workspace conflict message: ${rejected.message}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_shortcut_manager_prefers_active_dialog_scope_over_workspace_dispatch():
    script = textwrap.dedent(
        """
        import { ShortcutManager } from './static/js/shortcut-manager.js';

        let activeScopes = ['workspace'];
        const calls = [];
        const manager = new ShortcutManager({
          documentRef: { addEventListener() {}, removeEventListener() {} },
          shouldHandleEvent() { return true; },
          getActiveScopes() { return activeScopes; }
        });

        manager.registerAction('refreshWorkspace', {
          scope: 'workspace',
          label: 'Refresh Workspace',
          defaultBinding: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'r' },
          handler() { calls.push('workspace'); }
        });
        manager.registerAction('saveFileBrowser', {
          scope: 'file-browser-dialog',
          label: 'Save File Browser',
          defaultBinding: { ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, key: 'r' },
          handler() { calls.push('file-browser'); }
        });

        activeScopes = ['file-browser-dialog', 'workspace'];
        manager.handleKeydown({
          key: 'r',
          ctrlKey: true,
          altKey: false,
          shiftKey: false,
          metaKey: false,
          target: { tagName: 'DIV', isContentEditable: false, closest() { return null; } },
          preventDefault() {}
        });

        if (calls.length !== 1 || calls[0] !== 'file-browser') {
          throw new Error(`expected active dialog scope to win, got ${JSON.stringify(calls)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_git_diff_app_migrates_legacy_terminal_shortcuts_into_unified_shortcut_preferences():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() {
            return JSON.stringify({
              viewMode: 'unified',
              terminalShortcuts: {
                hideAllTerminals: { ctrlKey: true, altKey: true, shiftKey: false, metaKey: false, key: 'h' },
                layout2x2: { ctrlKey: false, altKey: true, shiftKey: false, metaKey: false, key: 'g' }
              }
            });
          },
          setItem() {}
        };

        function genericEl() {
          return {
            style: {},
            value: 'free',
            innerHTML: '',
            textContent: '',
            disabled: false,
            classList: { add() {}, remove() {}, toggle() {} },
            addEventListener() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById() { return genericEl(); }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();

        if (!app.preferences.shortcuts) {
          throw new Error('expected unified shortcut preferences map to exist');
        }
        if (app.preferences.shortcuts.hideAllTerminals?.key !== 'h' || !app.preferences.shortcuts.hideAllTerminals?.altKey) {
          throw new Error(`legacy hide-all binding was not migrated: ${JSON.stringify(app.preferences.shortcuts.hideAllTerminals)}`);
        }
        if (app.preferences.shortcuts.layout2x2?.key !== 'g' || !app.preferences.shortcuts.layout2x2?.altKey) {
          throw new Error(`legacy 2x2 binding was not migrated: ${JSON.stringify(app.preferences.shortcuts.layout2x2)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_git_diff_app_renders_unified_shortcut_settings_dialog_contents():
    script = textwrap.dedent(
        """
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        function genericEl() {
          return {
            style: {},
            value: 'free',
            innerHTML: '',
            textContent: '',
            disabled: false,
            hidden: false,
            dataset: {},
            classList: { add() {}, remove() {}, toggle() {} },
            listeners: new Map(),
            addEventListener(type, handler) { this.listeners.set(type, handler); },
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        const shortcutButtonEl = genericEl();
        const selectEl = genericEl();
        const dialogEl = genericEl();
        dialogEl.style.display = 'none';
        const overlayEl = genericEl();
        dialogEl.querySelector = () => overlayEl;
        const closeBtnEl = genericEl();
        const listEl = genericEl();
        const errorEl = genericEl();
        const resetDefaultsBtnEl = genericEl();
        const cancelBtnEl = genericEl();
        const saveBtnEl = genericEl();

        globalThis.document = {
          readyState: 'loading',
          addEventListener() {},
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'shortcutsBtn') return shortcutButtonEl;
            if (id === 'terminalLayoutSelect') return selectEl;
            if (id === 'shortcutDialog') return dialogEl;
            if (id === 'shortcutDialogCloseBtn') return closeBtnEl;
            if (id === 'shortcutDialogList') return listEl;
            if (id === 'shortcutDialogError') return errorEl;
            if (id === 'shortcutResetDefaultsBtn') return resetDefaultsBtnEl;
            if (id === 'shortcutDialogCancelBtn') return cancelBtnEl;
            if (id === 'shortcutDialogSaveBtn') return saveBtnEl;
            return genericEl();
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.attachEventListeners();
        shortcutButtonEl.listeners.get('click')();

        if (dialogEl.style.display !== 'flex') {
          throw new Error('shortcut dialog did not open');
        }
        if (!String(listEl.innerHTML).includes('Hide All Terminals')) {
          throw new Error(`shortcut list missing terminal action: ${listEl.innerHTML}`);
        }
        if (!String(listEl.innerHTML).includes('Refresh Workspace')) {
          throw new Error(`shortcut list missing workspace action: ${listEl.innerHTML}`);
        }
        if (!String(listEl.innerHTML).includes('Right Sidebar Terminal Layout')) {
          throw new Error(`shortcut list missing right-sidebar layout action: ${listEl.innerHTML}`);
        }
        if (!String(listEl.innerHTML).includes('Open New Terminal')) {
          throw new Error(`shortcut list missing open-terminal action: ${listEl.innerHTML}`);
        }
        if (!String(listEl.innerHTML).includes('Send Selected Content To Right Sidebar Terminal')) {
          throw new Error(`shortcut list missing selected-content terminal action: ${listEl.innerHTML}`);
        }
        if (!String(listEl.innerHTML).includes('Send File Path To Right Sidebar Terminal')) {
          throw new Error(`shortcut list missing file-path terminal action: ${listEl.innerHTML}`);
        }
        if (!String(listEl.innerHTML).includes('Open Commit Dialog')) {
          throw new Error(`shortcut list missing commit action: ${listEl.innerHTML}`);
        }
        if (!String(listEl.innerHTML).includes('Close Active File Browser Tab')) {
          throw new Error(`shortcut list missing file browser action: ${listEl.innerHTML}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_shortcut_dialog_uses_internal_scroll_layout_and_aligned_header():
    css = Path('static/css/main.css').read_text()

    assert '.shortcut-dialog .dialog-header {' in css
    assert 'justify-content: space-between;' in css
    assert '.shortcut-dialog-content {' in css
    assert 'min-height: 0;' in css
    assert '.shortcut-dialog-list {' in css
    assert 'overflow-y: auto;' in css



def test_git_diff_app_supports_right_sidebar_layout_and_terminal_context_shortcuts():
    script = textwrap.dedent(
        r"""
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const listeners = new Map();

        function addListener(type, handler) {
          if (!listeners.has(type)) listeners.set(type, []);
          listeners.get(type).push(handler);
        }

        function genericEl() {
          return {
            style: {},
            value: 'free',
            innerHTML: '',
            textContent: '',
            disabled: false,
            hidden: false,
            classList: { add() {}, remove() {}, toggle() {} },
            addEventListener(type, handler) { addListener(type, handler); },
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        const selectEl = genericEl();
        const shortcutButtonEl = genericEl();
        const filePathEl = genericEl();
        filePathEl.textContent = 'src/app.js';

        globalThis.document = {
          readyState: 'loading',
          addEventListener(type, handler) { addListener(type, handler); },
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'terminalLayoutSelect') return selectEl;
            if (id === 'shortcutsBtn') return shortcutButtonEl;
            if (id === 'filePath') return filePathEl;
            return genericEl();
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {},
          getSelection() {
            return { toString() { return 'const answer = 42;'; } };
          }
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.currentFile = { path: 'src/app.js' };
        const applied = [];
        const inserted = [];
        let opened = null;
        app.terminalManager = {
          activeLayoutId: 'right-sidebar',
          applyLayout(value) {
            this.activeLayoutId = value;
            applied.push(value);
          },
          hasActiveSessions() {
            return false;
          },
          openFromCurrentSelection() {
            opened = 'term-1';
            return opened;
          },
          insertTextIntoRightSidebar(value) {
            inserted.push(value);
            return { ok: true };
          }
        };

        app.attachEventListeners();

        const keydownHandlers = listeners.get('keydown') || [];
        const target = { tagName: 'DIV', isContentEditable: false, closest() { return null; } };

        for (const handler of keydownHandlers) {
          handler({ key: 'l', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }
        if (applied[0] !== 'right-sidebar' || selectEl.value !== 'right-sidebar') {
          throw new Error(`expected right-sidebar layout from Ctrl+L: ${JSON.stringify({ applied, value: selectEl.value })}`);
        }
        if (opened !== 'term-1') {
          throw new Error(`expected Ctrl+L to auto-open a terminal when none exist: ${opened}`);
        }

        for (const handler of keydownHandlers) {
          handler({ key: 'i', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }
        if (inserted[0] !== 'File: /tmp/demo/src/app.js\n\nconst answer = 42;') {
          throw new Error(`unexpected selected-content payload: ${JSON.stringify(inserted)}`);
        }

        for (const handler of keydownHandlers) {
          handler({ key: '.', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }
        if (inserted[1] !== 'File: /tmp/demo/src/app.js') {
          throw new Error(`unexpected file-path payload: ${JSON.stringify(inserted)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_git_diff_app_requires_right_sidebar_layout_for_terminal_context_shortcuts():
    script = textwrap.dedent(
        r"""
        globalThis.localStorage = {
          getItem() { return null; },
          setItem() {}
        };

        const listeners = new Map();

        function addListener(type, handler) {
          if (!listeners.has(type)) listeners.set(type, []);
          listeners.get(type).push(handler);
        }

        function genericEl() {
          return {
            style: {},
            value: 'free',
            innerHTML: '',
            textContent: '',
            disabled: false,
            hidden: false,
            classList: { add() {}, remove() {}, toggle() {} },
            addEventListener(type, handler) { addListener(type, handler); },
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        const selectEl = genericEl();
        const filePathEl = genericEl();
        filePathEl.textContent = 'src/app.js';

        globalThis.document = {
          readyState: 'loading',
          addEventListener(type, handler) { addListener(type, handler); },
          removeEventListener() {},
          querySelector() { return null; },
          querySelectorAll() { return []; },
          createElement() { return genericEl(); },
          head: { appendChild() {} },
          getElementById(id) {
            if (id === 'terminalLayoutSelect') return selectEl;
            if (id === 'filePath') return filePathEl;
            return genericEl();
          }
        };

        globalThis.window = {
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {},
          getSelection() {
            return { toString() { return 'const answer = 42;'; } };
          }
        };

        const { GitDiffApp } = await import('./static/js/app.js');
        const app = new GitDiffApp();
        app.currentFile = { path: 'src/app.js' };
        const errors = [];
        app.showError = (message) => errors.push(message);
        app.terminalManager = {
          activeLayoutId: 'columns-2',
          applyLayout() {},
          insertTextIntoRightSidebar() {
            throw new Error('should not attempt insertion outside right-sidebar layout');
          }
        };

        app.attachEventListeners();

        const keydownHandlers = listeners.get('keydown') || [];
        const target = { tagName: 'DIV', isContentEditable: false, closest() { return null; } };
        for (const handler of keydownHandlers) {
          handler({ key: 'i', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
          handler({ key: '.', ctrlKey: true, altKey: false, shiftKey: false, metaKey: false, target, preventDefault() {} });
        }

        if (errors.length < 2 || !errors.every((message) => String(message).includes('Right Sidebar'))) {
          throw new Error(`expected right-sidebar layout errors, got ${JSON.stringify(errors)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_terminal_manager_opens_and_targets_right_sidebar_session_for_context_insertion():
    script = textwrap.dedent(
        r"""
        import { TerminalManager } from './static/js/terminal-manager.js';

        const inserted = [];

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            removeChild(child) { this.children = this.children.filter((item) => item !== child); },
            remove() { this.removed = true; },
            addEventListener() {},
            setAttribute() {},
            querySelector() { return null; },
            querySelectorAll() { return []; }
          };
        }

        globalThis.document = {
          body: createElement('body'),
          createElement,
          querySelector(selector) {
            if (selector === '.app-header') {
              return { offsetHeight: 60 };
            }
            return null;
          },
          querySelectorAll() { return []; },
          getElementById() { return null; },
          addEventListener() {},
          removeEventListener() {},
          head: { appendChild() {} }
        };

        globalThis.window = {
          innerWidth: 1400,
          innerHeight: 900,
          location: new URL('http://localhost/?agent_id=agent-1&path=/tmp/demo'),
          addEventListener() {},
          removeEventListener() {}
        };

        const manager = new TerminalManager({
          app: { selectedAgentId: 'agent-1', selectedPath: '/tmp/demo', showError(message) { throw new Error(message); } },
          container: document.body,
          sessionFactory: (options) => ({
            ...options,
            open() {},
            minimize() {},
            restore() {},
            destroy() {},
            updateDockState() {},
            setWindowIndex() {},
            setFrame() {},
            setLayoutManaged() {},
            setMaximized() {},
            focus() {},
            insertText(value) { inserted.push(value); }
          })
        });

        manager.applyLayout('right-sidebar');
        const result = manager.insertTextIntoRightSidebar('File: /tmp/demo/src/app.js\n\nconst answer = 42;');

        if (!result?.ok) {
          throw new Error(`expected insertion result to succeed: ${JSON.stringify(result)}`);
        }
        if (manager.sessions.size !== 1) {
          throw new Error(`expected manager to open a right-sidebar session, got ${manager.sessions.size}`);
        }
        if (inserted[0] !== 'File: /tmp/demo/src/app.js\n\nconst answer = 42;') {
          throw new Error(`unexpected inserted payload: ${JSON.stringify(inserted)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout



def test_terminal_session_view_insert_text_uses_bracketed_paste_without_submit():
    script = textwrap.dedent(
        r"""
        import { TerminalSessionView } from './static/js/terminal-session.js';

        const sent = [];
        const session = new TerminalSessionView({
          sessionId: 'terminal-1',
          agentId: 'agent-1',
          path: '/tmp/demo',
          title: 'demo',
          manager: {
            toggleMaximizeSession() {},
            minimizeSession() {},
            closeSession() {},
            focusSession() {},
            detachSessionToFloat() {},
            updateFloatingFrame() {},
            reflowSessionWindows() {},
            setSessionStatus() {}
          },
          documentRef: { createElement() { return { addEventListener() {}, appendChild() {}, remove() {}, style: {}, dataset: {} }; } },
          windowRef: { addEventListener() {}, removeEventListener() {} },
          layerEl: { appendChild() {} },
        });

        session.socket = {
          readyState: 1,
          send(payload) { sent.push(JSON.parse(payload)); }
        };

        session.insertText('File: /tmp/demo/src/app.js\n\nconst answer = 42;');
        const data = sent[0]?.data;
        const expected = '\u001b[200~File: /tmp/demo/src/app.js\n\nconst answer = 42;\u001b[201~';
        if (data !== expected) {
          throw new Error(`expected bracketed paste payload, got ${JSON.stringify(data)}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_session_view_commits_inline_title_rename_to_manager():
    script = textwrap.dedent(
        r"""
        import { TerminalSessionView } from './static/js/terminal-session.js';

        function createElement(tagName) {
          return {
            tagName,
            className: '',
            textContent: '',
            innerHTML: '',
            dataset: {},
            style: {},
            value: '',
            hidden: false,
            children: [],
            appendChild(child) { this.children.push(child); return child; },
            remove() {},
            addEventListener() {},
            focus() { this.focused = true; },
            select() { this.selected = true; },
            setAttribute() {},
          };
        }

        const renamed = [];
        const session = new TerminalSessionView({
          sessionId: 'terminal-1',
          agentId: 'agent-1',
          path: '/tmp/demo',
          title: '1',
          manager: {
            renameSessionTitle(sessionId, title) { renamed.push([sessionId, title]); },
            toggleMaximizeSession() {},
            minimizeSession() {},
            closeSession() {},
            focusSession() {},
            detachSessionToFloat() {},
            updateFloatingFrame() {},
            reflowSessionWindows() {},
            setSessionStatus() {}
          },
          documentRef: { createElement },
          windowRef: { addEventListener() {}, removeEventListener() {} },
          layerEl: { appendChild() {} },
        });

        session.ensureWindow();
        session.beginTitleEdit();
        session.titleInputEl.value = 'backend';
        session.commitTitleEdit();

        if (JSON.stringify(renamed) !== JSON.stringify([['terminal-1', 'backend']])) {
          throw new Error(`expected rename callback, got ${JSON.stringify(renamed)}`);
        }
        if (session.title !== 'backend') {
          throw new Error(`expected session title to update, got ${session.title}`);
        }
        if (session.titleEl.textContent !== 'backend') {
          throw new Error(`expected visible title text to update, got ${session.titleEl.textContent}`);
        }
      """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout


def test_terminal_session_view_sends_heartbeat_ping_and_marks_stale_without_pong():
    script = textwrap.dedent(
        r"""
        import { TerminalSessionView } from './static/js/terminal-session.js';

        const sent = [];
        const session = new TerminalSessionView({
          sessionId: 'terminal-1',
          agentId: 'agent-1',
          path: '/tmp/demo',
          title: 'demo',
          manager: {
            toggleMaximizeSession() {},
            minimizeSession() {},
            closeSession() {},
            focusSession() {},
            detachSessionToFloat() {},
            updateFloatingFrame() {},
            reflowSessionWindows() {},
            setSessionStatus() {}
          },
          documentRef: { createElement() { return { addEventListener() {}, appendChild() {}, remove() {}, style: {}, dataset: {} }; } },
          windowRef: { addEventListener() {}, removeEventListener() {} },
          layerEl: { appendChild() {} },
        });

        session.socket = {
          readyState: 1,
          send(payload) { sent.push(JSON.parse(payload)); }
        };
        session.statusEl = { textContent: '', className: '' };
        session.status = 'ready';
        session.lastPongAt = 0;
        session.lastClientHeartbeatAt = 0;
        session.sendHeartbeatPing();
        session.evaluateConnectionHealth(60000);

        if (sent[0]?.type !== 'terminal_ping') {
          throw new Error(`expected terminal_ping, got ${JSON.stringify(sent)}`);
        }
        if (session.status !== 'stale') {
          throw new Error(`expected stale status, got ${session.status}`);
        }
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout
