import os
import stat
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _write_executable(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IXUSR)


def test_client_deploy_prompts_for_missing_pypi_token(tmp_path):
    log_file = tmp_path / "commands.log"
    fake_pip = tmp_path / "fake-pip"
    fake_python = tmp_path / "fake-python"
    fake_dist = tmp_path / "dist"
    fake_dist.mkdir()

    _write_executable(
        fake_pip,
        "#!/bin/sh\n"
        'printf "pip %s\\n" "$*" >> "$LOG_FILE"\n',
    )
    _write_executable(
        fake_python,
        "#!/bin/sh\n"
        'printf "python %s\\n" "$*" >> "$LOG_FILE"\n'
        'printf "twine-user=%s\\n" "$TWINE_USERNAME" >> "$LOG_FILE"\n'
        'printf "twine-pass=%s\\n" "$TWINE_PASSWORD" >> "$LOG_FILE"\n',
    )

    env = os.environ.copy()
    env["LOG_FILE"] = str(log_file)
    env.pop("TWINE_USERNAME", None)
    env.pop("TWINE_PASSWORD", None)
    env.pop("PYPI_TOKEN", None)

    result = subprocess.run(
        [
            "make",
            "client-deploy",
            f"PIP={fake_pip}",
            f"PYTHON={fake_python}",
            f"DIST_DIR={fake_dist}",
        ],
        cwd=ROOT,
        env=env,
        input="pypi-test-token\n",
        text=True,
        capture_output=True,
        timeout=10,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    log = log_file.read_text(encoding="utf-8")
    assert "python -m build" in log
    assert "python -m twine upload" in log
    assert "twine-user=__token__" in log
    assert "twine-pass=pypi-test-token" in log
