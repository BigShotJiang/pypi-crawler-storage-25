from pathlib import Path


def test_server_dockerfile_installs_project_in_editable_mode():
    dockerfile = Path("docker/server.Dockerfile").read_text(encoding="utf-8")

    assert "python -m pip install -e ." in dockerfile
