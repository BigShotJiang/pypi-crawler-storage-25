"""
Tests for git_utils module.

Tests Git operations including validation, file tree, diffs, commits, and status.
"""

import pytest
from pathlib import Path

import git_utils
from git import InvalidGitRepositoryError


class TestRepositoryValidation:
    """Tests for repository validation."""
    
    def test_valid_repository(self, temp_repo):
        """Test that a valid repository is recognized."""
        temp_dir, _ = temp_repo
        assert git_utils.is_valid_repository(temp_dir) is True
    
    def test_invalid_repository(self, temp_dir):
        """Test that a non-repository directory is rejected."""
        assert git_utils.is_valid_repository(temp_dir) is False
    
    def test_nonexistent_path(self):
        """Test that a nonexistent path is rejected."""
        assert git_utils.is_valid_repository("/nonexistent/path") is False
    
    def test_path_traversal_rejected(self, temp_repo):
        """Test that path traversal attempts are rejected."""
        temp_dir, _ = temp_repo
        assert git_utils.is_valid_repository(f"{temp_dir}/../..") is False


class TestFileTree:
    """Tests for file tree generation."""
    
    def test_get_file_tree_basic(self, temp_repo):
        """Test getting file tree from a basic repository."""
        temp_dir, _ = temp_repo
        tree = git_utils.get_file_tree(temp_dir, changed_only=False)
        
        assert 'files' in tree
        assert 'branch' in tree
        assert len(tree['files']) >= 1
        assert any(f['path'] == 'README.md' for f in tree['files'])
    
    def test_get_file_tree_with_changes(self, temp_repo_with_changes):
        """Test file tree includes status information."""
        temp_dir, _ = temp_repo_with_changes
        tree = git_utils.get_file_tree(temp_dir)
        
        files = tree['files']
        
        # Check for modified file
        readme = next((f for f in files if f['path'] == 'README.md'), None)
        assert readme is not None
        assert readme['status'] == 'modified'
        
        # Check for added file
        new_file = next((f for f in files if f['path'] == 'new_file.txt'), None)
        assert new_file is not None
        assert new_file['status'] in ['staged', 'modified', 'added']
        
        # Check for untracked file
        untracked = next((f for f in files if f['path'] == 'untracked.txt'), None)
        assert untracked is not None
        assert untracked['status'] == 'untracked'
    
    def test_invalid_repository_raises(self, temp_dir):
        """Test that invalid repository raises exception."""
        with pytest.raises(InvalidGitRepositoryError):
            git_utils.get_file_tree(temp_dir)


class TestFileDiff:
    """Tests for file diff generation."""
    
    def test_get_unstaged_diff(self, temp_repo_with_changes):
        """Test getting unstaged diff for a modified file."""
        temp_dir, _ = temp_repo_with_changes
        diff = git_utils.get_file_diff(temp_dir, "README.md", staged=False)
        
        assert diff['is_binary'] is False
        assert 'diff' in diff
        assert diff['file_path'] == 'README.md'
        assert 'additions' in diff
        assert 'deletions' in diff
    
    def test_get_staged_diff(self, temp_repo_with_changes):
        """Test getting staged diff for an added file."""
        temp_dir, _ = temp_repo_with_changes
        diff = git_utils.get_file_diff(temp_dir, "new_file.txt", staged=True)
        
        assert diff['is_binary'] is False
        assert 'diff' in diff
        assert diff['additions'] > 0

    def test_get_untracked_diff(self, temp_repo_with_changes):
        """Test getting a synthetic diff for an untracked file."""
        temp_dir, _ = temp_repo_with_changes
        diff = git_utils.get_file_diff(temp_dir, "untracked.txt", staged=False)

        assert diff['is_binary'] is False
        assert diff['file_path'] == 'untracked.txt'
        assert diff['additions'] > 0
        assert '+Untracked content' in diff['diff']
    
    def test_binary_file_detected(self, temp_repo_with_binary):
        """Test that binary files are detected and handled."""
        temp_dir, _ = temp_repo_with_binary
        diff = git_utils.get_file_diff(temp_dir, "image.bin", staged=False)
        
        assert diff['is_binary'] is True
        assert 'size' in diff
    
    def test_empty_diff(self, temp_repo):
        """Test file with no changes returns empty diff."""
        temp_dir, _ = temp_repo
        diff = git_utils.get_file_diff(temp_dir, "README.md", staged=False)
        
        assert diff['diff'] == ''
        assert diff['additions'] == 0
        assert diff['deletions'] == 0
    
    def test_invalid_repository_raises(self, temp_dir):
        """Test that invalid repository raises exception."""
        with pytest.raises(InvalidGitRepositoryError):
            git_utils.get_file_diff(temp_dir, "any_file.txt")


class TestCommitHistory:
    """Tests for commit history."""
    
    def test_get_commit_history_basic(self, temp_repo):
        """Test getting basic commit history."""
        temp_dir, _ = temp_repo
        commits = git_utils.get_commit_history(temp_dir, limit=10)
        
        assert len(commits) >= 1
        assert 'hash' in commits[0]
        assert 'short_hash' in commits[0]
        assert 'author' in commits[0]
        assert 'date' in commits[0]
        assert 'message' in commits[0]
    
    def test_commit_history_pagination(self, temp_repo_with_history):
        """Test commit history pagination."""
        temp_dir, _ = temp_repo_with_history
        
        # Get first page
        page1 = git_utils.get_commit_history(temp_dir, limit=3, offset=0)
        assert len(page1) == 3
        
        # Get second page
        page2 = git_utils.get_commit_history(temp_dir, limit=3, offset=3)
        assert len(page2) >= 1
        
        # Verify different commits
        assert page1[0]['hash'] != page2[0]['hash']
    
    def test_commit_history_limit(self, temp_repo_with_history):
        """Test that limit parameter works correctly."""
        temp_dir, _ = temp_repo_with_history
        commits = git_utils.get_commit_history(temp_dir, limit=2)
        
        assert len(commits) == 2
    
    def test_invalid_repository_raises(self, temp_dir):
        """Test that invalid repository raises exception."""
        with pytest.raises(InvalidGitRepositoryError):
            git_utils.get_commit_history(temp_dir)


class TestRepositoryStatus:
    """Tests for repository status."""
    
    def test_get_repo_status_basic(self, temp_repo):
        """Test getting repository status."""
        temp_dir, _ = temp_repo
        status = git_utils.get_repo_status(temp_dir)
        
        assert 'branch' in status
        assert 'is_detached' in status
        assert 'modified' in status
        assert 'added' in status
        assert 'deleted' in status
        assert 'untracked' in status
        assert 'ahead' in status
        assert 'behind' in status
    
    def test_repo_status_with_changes(self, temp_repo_with_changes):
        """Test that status includes file changes."""
        temp_dir, _ = temp_repo_with_changes
        status = git_utils.get_repo_status(temp_dir)
        
        # Should have modified files
        assert len(status['modified']) > 0 or len(status['added']) > 0
        
        # Should have untracked files
        assert len(status['untracked']) > 0
        
        # Should have deleted files
        assert len(status['deleted']) > 0
    
    def test_branch_name(self, temp_repo):
        """Test that branch name is returned correctly."""
        temp_dir, repo = temp_repo
        status = git_utils.get_repo_status(temp_dir)
        
        assert status['branch'] == repo.active_branch.name
        assert status['is_detached'] is False
    
    def test_invalid_repository_raises(self, temp_dir):
        """Test that invalid repository raises exception."""
        with pytest.raises(InvalidGitRepositoryError):
            git_utils.get_repo_status(temp_dir)


class TestPathValidation:
    """Tests for path validation and security."""
    
    def test_path_traversal_in_normalize(self):
        """Test that path traversal is detected."""
        with pytest.raises(ValueError):
            git_utils._normalize_path("../../etc/passwd")
    
    def test_valid_path_normalized(self, temp_dir):
        """Test that valid paths are normalized correctly."""
        normalized = git_utils._normalize_path(temp_dir)
        assert normalized == Path(temp_dir).resolve()


class TestCaching:
    """Tests for caching functionality."""
    
    def test_file_tree_cached(self, temp_repo):
        """Test that file tree results are cached."""
        temp_dir, _ = temp_repo
        
        # First call
        tree1 = git_utils.get_file_tree(temp_dir)
        
        # Second call should return cached result
        tree2 = git_utils.get_file_tree(temp_dir)
        
        # Should be same object (cached)
        assert tree1 == tree2



class TestWorkspaceBrowsing:
    """Tests for non-Git workspace helpers."""

    def test_browse_workspace_lists_non_git_directory(self, temp_dir):
        workspace = Path(temp_dir) / "workspace"
        workspace.mkdir()
        (workspace / "notes.txt").write_text("hello\n")

        result = git_utils.browse_workspace(str(workspace))

        assert result['is_git_repo'] is False
        assert any(item['name'] == 'notes.txt' for item in result['entries'])

    def test_read_and_write_workspace_file(self, temp_dir):
        file_path = Path(temp_dir) / "notes.txt"
        file_path.write_text("before\n")

        git_utils.write_workspace_file(str(file_path), "after\n")
        result = git_utils.read_workspace_file(str(file_path))

        assert result['content'] == 'after\n'


class TestGitRootResolution:
    """Tests for resolving a repo from a nested path."""

    def test_resolve_git_repository_path_from_subdirectory(self, temp_repo):
        temp_dir, _ = temp_repo
        nested = Path(temp_dir) / 'src' / 'module'
        nested.mkdir(parents=True)

        resolved = git_utils.resolve_git_repository_path(str(nested))

        assert resolved == str(Path(temp_dir).resolve())
