from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AgentRecord:
    agent_id: str
    client_id: str
    approval_status: str
    status: str
    token: str | None
    client_info: dict[str, Any]


@dataclass(frozen=True)
class RepositoryBindingRecord:
    repo_id: str
    agent_id: str
    name: str
    path: str
    status: str


@dataclass(frozen=True)
class TaskRecord:
    task_id: str
    repo_id: str
    agent_id: str | None
    capability: str
    action: str
    status: str
    params: dict[str, Any]


@dataclass(frozen=True)
class TaskResultRecord:
    task_id: str
    success: bool
    result: dict[str, Any]
    error: str | None
