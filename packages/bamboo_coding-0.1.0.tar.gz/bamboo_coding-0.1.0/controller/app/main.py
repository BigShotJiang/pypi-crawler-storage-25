from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from controller.app.api.agents import router as agent_router
from controller.app.api.public import router as public_router
from controller.app.core.config import load_config
from controller.app.db.session import ControllerDatabase
from controller.app.services.agents import AgentService
from controller.app.services.registrations import RegistrationService
from controller.app.services.repositories import RepositoryService
from controller.app.services.router import TaskRouter
from controller.app.services.terminals import TerminalRelayService
from controller.app.services.tasks import TaskService


def create_app(database_path: Path | str | None = None) -> FastAPI:
    app = FastAPI(title="Bamboo Coding")
    config = load_config()
    static_dir = Path(__file__).resolve().parents[2] / "static"
    index_file = static_dir / "index.html"
    terminal_file = static_dir / "terminal.html"
    resolved_db_path = Path(database_path) if database_path is not None else config.database_path
    database = ControllerDatabase(resolved_db_path)
    database.initialize()
    repositories = RepositoryService(database)
    tasks = TaskService(database)
    agents = AgentService(database)
    router = TaskRouter(repositories=repositories, tasks=tasks)
    terminals = TerminalRelayService(router=router)

    app.state.config = config
    app.state.database = database
    app.state.repositories = repositories
    app.state.tasks = tasks
    app.state.agents = agents
    app.state.registrations = RegistrationService(agents)
    app.state.router = router
    app.state.terminals = terminals

    @app.exception_handler(HTTPException)
    async def http_error_handler(_request: Request, exc: HTTPException) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content={"error": "request_error", "message": str(exc.detail)})

    @app.exception_handler(Exception)
    async def unexpected_error_handler(_request: Request, exc: Exception) -> JSONResponse:
        return JSONResponse(status_code=500, content={"error": "internal_error", "message": str(exc)})

    @app.get("/api/health")
    async def health_check() -> JSONResponse:
        return JSONResponse({"status": "ok", "version": "2.0.0"})

    @app.get("/")
    async def index() -> FileResponse:
        return FileResponse(index_file)

    @app.get("/terminal")
    async def terminal_page() -> FileResponse:
        return FileResponse(terminal_file)

    app.include_router(public_router)
    app.include_router(agent_router)
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
    return app


app = create_app()
