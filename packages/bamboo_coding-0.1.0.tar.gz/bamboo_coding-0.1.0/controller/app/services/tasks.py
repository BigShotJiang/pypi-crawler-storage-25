from __future__ import annotations

from datetime import UTC, datetime
import json

from controller.app.core.errors import TaskNotFoundError
from controller.app.db.session import ControllerDatabase


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _decode_task(row) -> dict | None:
    if row is None:
        return None
    payload = dict(row)
    payload["params"] = json.loads(payload.pop("params_json"))
    result_json = payload.pop("result_json")
    payload["result"] = json.loads(result_json) if result_json else None
    payload["success"] = None if payload["result_success"] is None else bool(payload["result_success"])
    return payload


class TaskService:
    def __init__(self, database: ControllerDatabase):
        self.database = database

    def create_task(self, task_id: str, repo_id: str, capability: str, action: str, params: dict, agent_id: str | None = None) -> dict:
        now = _now()
        with self.database.connection() as conn:
            conn.execute(
                "INSERT INTO tasks (task_id, repo_id, agent_id, capability, action, params_json, status, created_at, updated_at, terminal_at, result_success, result_json, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (task_id, repo_id, agent_id, capability, action, json.dumps(params), "queued", now, now, None, None, None, None),
            )
            row = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
            return _decode_task(row)

    def append_event(self, task_id: str, status: str, message: str | None = None, details: dict | None = None) -> dict:
        now = _now()
        details = details or {}
        with self.database.connection() as conn:
            task = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
            if task is None:
                raise TaskNotFoundError(f"Unknown task: {task_id}")
            conn.execute(
                "INSERT INTO task_events (task_id, status, message, details_json, created_at) VALUES (?, ?, ?, ?, ?)",
                (task_id, status, message, json.dumps(details), now),
            )
            conn.execute(
                "UPDATE tasks SET status = ?, updated_at = ? WHERE task_id = ?",
                (status, now, task_id),
            )
        return {"task_id": task_id, "status": status, "message": message, "details": details}

    def list_events(self, task_id: str) -> list[dict]:
        with self.database.connection() as conn:
            rows = conn.execute(
                "SELECT task_id, status, message, details_json, created_at FROM task_events WHERE task_id = ? ORDER BY id ASC",
                (task_id,),
            ).fetchall()
        return [
            {
                "task_id": row["task_id"],
                "status": row["status"],
                "message": row["message"],
                "details": json.loads(row["details_json"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def store_result(self, task_id: str, success: bool, result: dict | None = None, error: str | None = None) -> dict:
        now = _now()
        result = result or {}
        terminal_status = "succeeded" if success else "failed"
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
            if row is None:
                raise TaskNotFoundError(f"Unknown task: {task_id}")
            if row["result_success"] is not None:
                return {"inserted": False, "task": _decode_task(row)}
            conn.execute(
                "UPDATE tasks SET status = ?, updated_at = ?, terminal_at = ?, result_success = ?, result_json = ?, error = ? WHERE task_id = ?",
                (terminal_status, now, now, int(success), json.dumps(result), error, task_id),
            )
            updated = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
        return {"inserted": True, "task": _decode_task(updated)}

    def get_task(self, task_id: str) -> dict | None:
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
            return _decode_task(row)

    def get_result(self, task_id: str) -> dict | None:
        task = self.get_task(task_id)
        if task is None or task["success"] is None:
            return None
        return {
            "task_id": task_id,
            "success": task["success"],
            "result": task["result"] or {},
            "error": task["error"],
        }
