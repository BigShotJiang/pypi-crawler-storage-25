from __future__ import annotations

from datetime import UTC, datetime
import json
from uuid import uuid4

from controller.app.core.errors import AgentApprovalError
from controller.app.db.session import ControllerDatabase


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _decode_agent(row) -> dict | None:
    if row is None:
        return None
    payload = dict(row)
    payload["client_info"] = json.loads(payload.pop("client_info_json"))
    return payload


class AgentService:
    def __init__(self, database: ControllerDatabase):
        self.database = database

    def create_registration_request(self, client_id: str) -> dict:
        now = _now()
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM agents WHERE client_id = ?", (client_id,)).fetchone()
            if row is None:
                agent_id = str(uuid4())
                conn.execute(
                    "INSERT INTO agents (agent_id, client_id, token, approval_status, status, client_info_json, created_at, updated_at, last_seen_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (agent_id, client_id, None, "pending", "pending", json.dumps({}), now, now, None),
                )
                row = conn.execute("SELECT * FROM agents WHERE client_id = ?", (client_id,)).fetchone()
            return _decode_agent(row)

    def approve_registration(self, client_id: str, token: str) -> dict:
        now = _now()
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM agents WHERE client_id = ?", (client_id,)).fetchone()
            if row is None:
                self.create_registration_request(client_id)
            conn.execute(
                "UPDATE agents SET token = ?, approval_status = ?, updated_at = ? WHERE client_id = ?",
                (token, "approved", now, client_id),
            )
            row = conn.execute("SELECT * FROM agents WHERE client_id = ?", (client_id,)).fetchone()
            return _decode_agent(row)

    def approve_agent(self, agent_id: str, token: str) -> dict:
        now = _now()
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM agents WHERE agent_id = ?", (agent_id,)).fetchone()
            if row is None:
                raise AgentApprovalError(f"Unknown agent: {agent_id}")
            conn.execute(
                "UPDATE agents SET token = ?, approval_status = ?, updated_at = ? WHERE agent_id = ?",
                (token, "approved", now, agent_id),
            )
            row = conn.execute("SELECT * FROM agents WHERE agent_id = ?", (agent_id,)).fetchone()
            return _decode_agent(row)

    def register_connection(self, client_id: str, token: str, client_info: dict) -> dict:
        now = _now()
        with self.database.connection() as conn:
            row = conn.execute(
                "SELECT * FROM agents WHERE client_id = ? AND token = ?",
                (client_id, token),
            ).fetchone()
            if row is None or row["approval_status"] != "approved":
                raise AgentApprovalError(f"Agent {client_id} is not approved")
            conn.execute(
                "UPDATE agents SET status = ?, client_info_json = ?, updated_at = ?, last_seen_at = ? WHERE client_id = ?",
                ("connected", json.dumps(client_info), now, now, client_id),
            )
            row = conn.execute("SELECT * FROM agents WHERE client_id = ?", (client_id,)).fetchone()
            return _decode_agent(row)

    def get_agent_by_token(self, token: str) -> dict | None:
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM agents WHERE token = ?", (token,)).fetchone()
            return _decode_agent(row)

    def get_agent_by_client_id(self, client_id: str) -> dict | None:
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM agents WHERE client_id = ?", (client_id,)).fetchone()
            return _decode_agent(row)

    def get_agent_by_id(self, agent_id: str) -> dict | None:
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM agents WHERE agent_id = ?", (agent_id,)).fetchone()
            return _decode_agent(row)

    def list_agents(self) -> list[dict]:
        with self.database.connection() as conn:
            rows = conn.execute("SELECT * FROM agents ORDER BY created_at ASC").fetchall()
            return [_decode_agent(row) for row in rows]

    def mark_disconnected(self, agent_id: str) -> None:
        now = _now()
        with self.database.connection() as conn:
            conn.execute(
                "UPDATE agents SET status = ?, updated_at = ? WHERE agent_id = ?",
                ("disconnected", now, agent_id),
            )
