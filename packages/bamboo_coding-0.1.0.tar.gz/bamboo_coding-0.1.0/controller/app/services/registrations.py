from __future__ import annotations

from controller.app.services.agents import AgentService
from shared.protocol import RegisterRequestMessage


class RegistrationService:
    def __init__(self, agents: AgentService):
        self.agents = agents

    def ensure_pending(self, client_id: str) -> RegisterRequestMessage:
        self.agents.create_registration_request(client_id)
        return RegisterRequestMessage(approved=False, client_id=client_id, message="pending approval")

    def approve(self, client_id: str, token: str) -> RegisterRequestMessage:
        self.agents.approve_registration(client_id=client_id, token=token)
        return RegisterRequestMessage(approved=True, client_id=client_id, token=token, message="approved")
