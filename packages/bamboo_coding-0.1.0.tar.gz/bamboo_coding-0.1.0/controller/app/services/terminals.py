from __future__ import annotations

from dataclasses import dataclass
from typing import Awaitable, Callable

from controller.app.services.router import TaskRouter, _normalize_path, _path_is_within_root
from shared.protocol import (
    TerminalCloseMessage,
    TerminalClosedMessage,
    TerminalHeartbeatMessage,
    TerminalInputMessage,
    TerminalOpenMessage,
    TerminalOutputMessage,
    TerminalResizeMessage,
    TerminalStatusMessage,
)


SendJson = Callable[[dict], Awaitable[None]]


@dataclass
class BrowserTerminalSession:
    terminal_id: str
    agent_id: str
    path: str
    cols: int
    rows: int
    send_json: SendJson


class TerminalRelayService:
    def __init__(self, router: TaskRouter):
        self.router = router
        self.sessions: dict[str, BrowserTerminalSession] = {}

    async def open_browser_terminal(
        self,
        *,
        terminal_id: str,
        agent_id: str,
        path: str,
        cols: int,
        rows: int,
        send_json: SendJson,
    ) -> str:
        normalized_path = _normalize_path(path)
        live_agent = self.router.live_agents.get(agent_id)
        if live_agent is None:
            raise RuntimeError(f"No live agent for selected client {agent_id}")
        if not live_agent.supports('terminal.open', 'post'):
            raise RuntimeError(f"Selected client {agent_id} does not support terminal.open:post")
        if not any(_path_is_within_root(normalized_path, root.get('path', '')) for root in live_agent.roots):
            raise RuntimeError(f"Path {normalized_path} is outside selected client roots")

        session = BrowserTerminalSession(
            terminal_id=terminal_id,
            agent_id=agent_id,
            path=normalized_path,
            cols=cols,
            rows=rows,
            send_json=send_json,
        )
        self.sessions[terminal_id] = session
        await send_json(TerminalStatusMessage(terminal_id=terminal_id, status='connecting').model_dump())
        await live_agent.send_json(
            TerminalOpenMessage(terminal_id=terminal_id, path=normalized_path, cols=cols, rows=rows).model_dump()
        )
        return terminal_id

    async def forward_browser_message(self, terminal_id: str, payload: dict) -> None:
        session = self.sessions.get(terminal_id)
        if session is None:
            return
        live_agent = self.router.live_agents.get(session.agent_id)
        if live_agent is None:
            await self.handle_terminal_closed(TerminalClosedMessage(terminal_id=terminal_id, reason='client_disconnected'))
            return

        message_type = payload.get('type')
        if message_type == 'terminal_input':
            message = TerminalInputMessage(**payload)
            await live_agent.send_json(message.model_dump())
        elif message_type == 'terminal_resize':
            message = TerminalResizeMessage(**payload)
            await live_agent.send_json(message.model_dump())
        elif message_type == 'terminal_close':
            message = TerminalCloseMessage(**payload)
            await live_agent.send_json(message.model_dump())

    async def handle_terminal_status(self, message: TerminalStatusMessage) -> None:
        await self._safe_send_to_browser(message.terminal_id, message.model_dump())

    async def handle_terminal_output(self, message: TerminalOutputMessage) -> None:
        await self._safe_send_to_browser(message.terminal_id, message.model_dump())

    async def handle_terminal_heartbeat(self, message: TerminalHeartbeatMessage) -> None:
        await self._safe_send_to_browser(message.terminal_id, message.model_dump())

    async def handle_terminal_closed(self, message: TerminalClosedMessage) -> None:
        session = self.sessions.pop(message.terminal_id, None)
        if session is None:
            return
        try:
            await session.send_json(message.model_dump())
        except Exception:
            return

    async def close_browser_terminal(self, terminal_id: str, reason: str = 'browser_disconnected') -> None:
        session = self.sessions.pop(terminal_id, None)
        if session is None:
            return
        live_agent = self.router.live_agents.get(session.agent_id)
        if live_agent is None:
            return
        if live_agent.supports('terminal.close', 'post'):
            await live_agent.send_json(TerminalCloseMessage(terminal_id=terminal_id, reason=reason).model_dump())

    async def close_agent_sessions(self, agent_id: str, reason: str = 'client_disconnected') -> None:
        terminal_ids = [terminal_id for terminal_id, session in self.sessions.items() if session.agent_id == agent_id]
        for terminal_id in terminal_ids:
            session = self.sessions.pop(terminal_id, None)
            if session is None:
                continue
            try:
                await session.send_json(TerminalClosedMessage(terminal_id=terminal_id, reason=reason).model_dump())
            except Exception:
                continue

    async def _safe_send_to_browser(self, terminal_id: str, payload: dict) -> None:
        session = self.sessions.get(terminal_id)
        if session is None:
            return
        try:
            await session.send_json(payload)
        except Exception:
            self.sessions.pop(terminal_id, None)
            await self.close_remote_terminal(terminal_id, session.agent_id, reason='browser_send_failed')

    async def close_remote_terminal(self, terminal_id: str, agent_id: str, reason: str) -> None:
        live_agent = self.router.live_agents.get(agent_id)
        if live_agent is None:
            return
        if live_agent.supports('terminal.close', 'post'):
            try:
                await live_agent.send_json(TerminalCloseMessage(terminal_id=terminal_id, reason=reason).model_dump())
            except Exception:
                return
