from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
import os

from controller.app.core.errors import RepositoryNotFoundError
from controller.app.db.session import ControllerDatabase
from shared.protocol import PublicRepositorySummary, PublicRootSummary


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _normalize_path(path_value: str) -> str:
    return str(Path(path_value).expanduser().resolve())


class RepositoryService:
    def __init__(self, database: ControllerDatabase):
        self.database = database

    def upsert_repository_binding(self, agent_id: str, repo_id: str, name: str, path: str, status: str) -> dict:
        now = _now()
        normalized_path = _normalize_path(path)
        storage_key = _normalize_path(repo_id) if repo_id else normalized_path
        with self.database.connection() as conn:
            conn.execute(
                """
                INSERT INTO repositories (repo_id, agent_id, name, path, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(repo_id) DO UPDATE SET
                    agent_id = excluded.agent_id,
                    name = excluded.name,
                    path = excluded.path,
                    status = excluded.status,
                    updated_at = excluded.updated_at
                """,
                (storage_key, agent_id, name, normalized_path, status, now, now),
            )
            return self.get_repository_binding(storage_key)

    def upsert_root_binding(self, agent_id: str, path: str, name: str, status: str) -> dict:
        normalized_path = _normalize_path(path)
        return self.upsert_repository_binding(agent_id=agent_id, repo_id=normalized_path, name=name, path=normalized_path, status=status)

    def list_public_repositories(self) -> list[PublicRepositorySummary]:
        return self.list_public_roots()

    def list_public_roots(self) -> list[PublicRootSummary]:
        with self.database.connection() as conn:
            rows = conn.execute("SELECT path, name, status FROM repositories ORDER BY path ASC").fetchall()
        return [PublicRootSummary(path=row["path"], name=row["name"], status=row["status"]) for row in rows]

    def get_repository_binding(self, repo_id: str) -> dict | None:
        with self.database.connection() as conn:
            row = conn.execute("SELECT * FROM repositories WHERE repo_id = ?", (_normalize_path(repo_id),)).fetchone()
            return dict(row) if row is not None else None

    def get_root_binding(self, path: str) -> dict | None:
        return self.get_repository_binding(path)

    def require_repository_binding(self, repo_id: str) -> dict:
        binding = self.get_repository_binding(repo_id)
        if binding is None:
            raise RepositoryNotFoundError(f"Unknown repository: {repo_id}")
        return binding

    def find_root_bindings_for_path(self, path: str) -> list[dict]:
        normalized_target = _normalize_path(path)
        with self.database.connection() as conn:
            rows = conn.execute("SELECT * FROM repositories ORDER BY LENGTH(path) DESC, path ASC").fetchall()
        bindings: list[dict] = []
        for row in rows:
            binding = dict(row)
            binding_path = _normalize_path(binding["path"])
            try:
                contains = os.path.commonpath([binding_path, normalized_target]) == binding_path
            except ValueError:
                contains = False
            if contains:
                binding["path"] = binding_path
                bindings.append(binding)
        return bindings
