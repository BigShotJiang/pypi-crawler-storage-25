from __future__ import annotations

import asyncio
from dataclasses import dataclass
import os
from pathlib import Path
from typing import Awaitable, Callable
from uuid import uuid4

from controller.app.services.repositories import RepositoryService
from controller.app.services.tasks import TaskService
from shared.protocol import TaskMessage


SendJson = Callable[[dict], Awaitable[None]]


def _normalize_path(path_value: str) -> str:
    return str(Path(path_value).expanduser().resolve())


def _path_is_within_root(path_value: str, root_path: str) -> bool:
    if not root_path:
        return False
    normalized_target = _normalize_path(path_value)
    normalized_root = _normalize_path(root_path)
    try:
        return os.path.commonpath([normalized_root, normalized_target]) == normalized_root
    except ValueError:
        return False


@dataclass
class LiveAgent:
    agent_id: str
    send_json: SendJson
    capabilities: list[dict]
    roots: list[dict]

    def supports(self, capability: str, action: str) -> bool:
        for item in self.capabilities:
            if item.get("capability") != capability:
                continue
            if action in (item.get("actions") or []):
                return True
        return False


class TaskRouter:
    def __init__(self, repositories: RepositoryService, tasks: TaskService, timeout_seconds: float = 15.0):
        self.repositories = repositories
        self.tasks = tasks
        self.timeout_seconds = timeout_seconds
        self.live_agents: dict[str, LiveAgent] = {}
        self.pending_tasks: dict[str, asyncio.Future] = {}
        self.pending_tasks_history: list[str] = []

    def attach_agent(
        self,
        *,
        agent_id: str,
        send_json: SendJson,
        capabilities: list[dict],
        roots: list[dict] | None = None,
        repositories: list[dict] | None = None,
    ) -> None:
        self.live_agents[agent_id] = LiveAgent(
            agent_id=agent_id,
            send_json=send_json,
            capabilities=capabilities,
            roots=roots if roots is not None else (repositories or []),
        )

    def detach_agent(self, agent_id: str) -> None:
        self.live_agents.pop(agent_id, None)

    async def dispatch_task(self, path: str, capability: str, action: str, params: dict, agent_id: str | None = None) -> dict:
        normalized_path = _normalize_path(path)
        selected_agent_id = agent_id

        if selected_agent_id is not None:
            live_agent = self.live_agents.get(selected_agent_id)
            if live_agent is None:
                raise RuntimeError(f"No live agent for selected client {selected_agent_id}")
            if not live_agent.supports(capability, action):
                raise RuntimeError(f"Selected client {selected_agent_id} does not support {capability}:{action}")
            if not any(_path_is_within_root(normalized_path, root.get("path", "")) for root in live_agent.roots):
                raise RuntimeError(f"Path {normalized_path} is outside selected client roots")
        else:
            candidate_bindings = self.repositories.find_root_bindings_for_path(normalized_path)
            routed: list[tuple[dict, LiveAgent]] = []
            for binding in candidate_bindings:
                live_agent = self.live_agents.get(binding["agent_id"])
                if live_agent is None:
                    continue
                if not live_agent.supports(capability, action):
                    continue
                routed.append((binding, live_agent))

            if not routed:
                raise RuntimeError(f"No live agent for path {normalized_path}")
            if len(routed) > 1:
                raise RuntimeError(f"Ambiguous path owner for {normalized_path}")

            binding, live_agent = routed[0]
            selected_agent_id = binding["agent_id"]

        task_id = str(uuid4())
        task = TaskMessage(task_id=task_id, path=normalized_path, capability=capability, action=action, params=params)
        self.tasks.create_task(
            task_id=task_id,
            repo_id=normalized_path,
            capability=capability,
            action=action,
            params=params,
            agent_id=selected_agent_id,
        )
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_tasks[task_id] = future
        self.pending_tasks_history.append(task_id)
        await live_agent.send_json(task.model_dump())
        try:
            return await asyncio.wait_for(future, timeout=self.timeout_seconds)
        finally:
            self.pending_tasks.pop(task_id, None)

    async def handle_event(self, *, task_id: str, status: str, message: str | None = None, details: dict | None = None) -> dict:
        return self.tasks.append_event(task_id, status=status, message=message, details=details)

    async def handle_result(self, task_id: str, success: bool, result: dict | None, error: str | None) -> dict:
        stored = self.tasks.store_result(task_id, success=success, result=result, error=error)
        future = self.pending_tasks.get(task_id)
        if future is None or future.done() or not stored["inserted"]:
            return stored
        if success:
            future.set_result(result or {})
        else:
            future.set_exception(RuntimeError(error or "Task failed"))
        return stored
