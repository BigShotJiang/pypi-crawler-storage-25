from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os


@dataclass(frozen=True)
class AppConfig:
    database_path: Path
    host: str = "0.0.0.0"
    port: int = 8100


def load_config() -> AppConfig:
    root_dir = Path(__file__).resolve().parents[3]
    database_path = Path(os.getenv("CONTROLLER_DB_PATH", root_dir / ".controller" / "controller.db"))
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8100"))
    return AppConfig(database_path=database_path, host=host, port=port)
