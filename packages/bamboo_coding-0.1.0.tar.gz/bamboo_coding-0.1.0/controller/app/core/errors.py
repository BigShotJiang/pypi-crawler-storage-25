class ControllerError(Exception):
    """Base error for controller services."""


class AgentApprovalError(ControllerError):
    """Raised when an agent is not approved for connection."""


class RepositoryNotFoundError(ControllerError):
    """Raised when a repository binding is missing."""


class TaskNotFoundError(ControllerError):
    """Raised when a task is not present in controller storage."""
