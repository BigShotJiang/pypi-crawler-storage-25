from fastapi import APIRouter

from .repos import router as repos_router
from .terminals import router as terminals_router


router = APIRouter()
router.include_router(repos_router)
router.include_router(terminals_router)

__all__ = ["router"]
