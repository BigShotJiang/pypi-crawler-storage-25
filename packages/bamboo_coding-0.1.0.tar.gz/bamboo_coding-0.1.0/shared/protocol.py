from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class ProtocolModel(BaseModel):
    model_config = {"extra": "forbid", "populate_by_name": True}


class CapabilityDescriptor(ProtocolModel):
    capability: str
    actions: list[str] = Field(default_factory=list)


class RootDescriptor(ProtocolModel):
    path: str
    name: str
    repo_id: str | None = Field(default=None, exclude=True)

    @model_validator(mode="before")
    @classmethod
    def _accept_legacy_repo_id(cls, data: Any) -> Any:
        if isinstance(data, dict):
            payload = dict(data)
            if "path" not in payload and "repo_id" in payload:
                payload["path"] = payload["repo_id"]
            if "repo_id" not in payload and "path" in payload:
                payload["repo_id"] = payload["path"]
            return payload
        return data


class PublicRootSummary(ProtocolModel):
    path: str
    name: str
    status: str
    repo_id: str | None = Field(default=None, exclude=True)

    @model_validator(mode="before")
    @classmethod
    def _accept_legacy_repo_id(cls, data: Any) -> Any:
        if isinstance(data, dict):
            payload = dict(data)
            if "path" not in payload and "repo_id" in payload:
                payload["path"] = payload["repo_id"]
            if "repo_id" not in payload and "path" in payload:
                payload["repo_id"] = payload["path"]
            return payload
        return data


class ClientInfo(ProtocolModel):
    hostname: str
    version: str
    platform: str


class ConnectivityTarget(ProtocolModel):
    connected: bool


class ConnectivityState(ProtocolModel):
    controller: ConnectivityTarget


class RuntimeHealth(ProtocolModel):
    active_tasks: int
    queued_tasks: int
    max_concurrent_tasks: int


class TaskMessage(ProtocolModel):
    type: Literal["task"] = "task"
    task_id: str
    path: str
    capability: str
    action: str
    params: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def _accept_legacy_repo_id(cls, data: Any) -> Any:
        if isinstance(data, dict):
            payload = dict(data)
            if "path" not in payload and "repo_id" in payload:
                payload["path"] = payload["repo_id"]
            return payload
        return data

    @property
    def repo_id(self) -> str:
        return self.path


class AgentRegisterMessage(ProtocolModel):
    type: Literal["register"] = "register"
    protocol_version: int
    client_id: str | None = None
    client_info: ClientInfo
    capabilities: list[CapabilityDescriptor] = Field(default_factory=list)
    roots: list[RootDescriptor] = Field(default_factory=list)
    connectivity: ConnectivityState
    runtime_health: RuntimeHealth

    @model_validator(mode="before")
    @classmethod
    def _accept_legacy_repositories(cls, data: Any) -> Any:
        if isinstance(data, dict):
            payload = dict(data)
            repositories = payload.pop("repositories", None)
            if "roots" not in payload and repositories is not None:
                payload["roots"] = repositories
            return payload
        return data

    @property
    def repositories(self) -> list[RootDescriptor]:
        return self.roots


class ClientStatusMessage(ProtocolModel):
    type: Literal["client_status"] = "client_status"
    protocol_version: int = 2
    client_id: str | None = None
    client_info: ClientInfo | None = None
    reason: str
    capabilities: list[CapabilityDescriptor] = Field(default_factory=list)
    roots: list[RootDescriptor] = Field(default_factory=list)
    connectivity: ConnectivityState
    runtime_health: RuntimeHealth

    @model_validator(mode="before")
    @classmethod
    def _accept_legacy_repositories(cls, data: Any) -> Any:
        if isinstance(data, dict):
            payload = dict(data)
            repositories = payload.pop("repositories", None)
            if "roots" not in payload and repositories is not None:
                payload["roots"] = repositories
            return payload
        return data

    @property
    def repositories(self) -> list[RootDescriptor]:
        return self.roots


class RegisterRequestMessage(ProtocolModel):
    type: Literal["register_request"] = "register_request"
    approved: bool
    client_id: str
    token: str | None = None
    message: str | None = None


class TerminalOpenMessage(ProtocolModel):
    type: Literal["terminal_open"] = "terminal_open"
    terminal_id: str
    path: str
    cols: int = 120
    rows: int = 32


class TerminalInputMessage(ProtocolModel):
    type: Literal["terminal_input"] = "terminal_input"
    terminal_id: str
    data: str


class TerminalResizeMessage(ProtocolModel):
    type: Literal["terminal_resize"] = "terminal_resize"
    terminal_id: str
    cols: int
    rows: int


class TerminalCloseMessage(ProtocolModel):
    type: Literal["terminal_close"] = "terminal_close"
    terminal_id: str
    reason: str | None = None


class TerminalPingMessage(ProtocolModel):
    type: Literal["terminal_ping"] = "terminal_ping"
    terminal_id: str


class TerminalPongMessage(ProtocolModel):
    type: Literal["terminal_pong"] = "terminal_pong"
    terminal_id: str


class TerminalStatusMessage(ProtocolModel):
    type: Literal["terminal_status"] = "terminal_status"
    terminal_id: str
    status: str
    message: str | None = None


class TerminalOutputMessage(ProtocolModel):
    type: Literal["terminal_output"] = "terminal_output"
    terminal_id: str
    data: str


class TerminalHeartbeatMessage(ProtocolModel):
    type: Literal["terminal_heartbeat"] = "terminal_heartbeat"
    terminal_id: str
    process_alive: bool


class TerminalClosedMessage(ProtocolModel):
    type: Literal["terminal_closed"] = "terminal_closed"
    terminal_id: str
    reason: str | None = None
    exit_code: int | None = None


class TaskEventMessage(ProtocolModel):
    type: Literal["task_event"] = "task_event"
    task_id: str
    status: str
    message: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class TaskResultMessage(ProtocolModel):
    type: Literal["task_result"] = "task_result"
    task_id: str
    success: bool
    result: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None


class TaskQueryMessage(ProtocolModel):
    type: Literal["task_query"] = "task_query"
    task_id: str


class TaskQueryResultMessage(ProtocolModel):
    type: Literal["task_query_result"] = "task_query_result"
    task_id: str
    found: bool
    success: bool | None = None
    result: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None


# Temporary compatibility aliases while the rest of the branch is converted.
RepositoryDescriptor = RootDescriptor
PublicRepositorySummary = PublicRootSummary
