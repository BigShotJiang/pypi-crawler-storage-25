from __future__ import annotations

import json
from typing import Awaitable, Callable

from websockets import connect
from websockets.exceptions import ConnectionClosed

from shared.protocol import (
    AgentRegisterMessage,
    ClientStatusMessage,
    TaskEventMessage,
    TaskMessage,
    TaskQueryResultMessage,
    TaskResultMessage,
)


class ControllerConnection:
    def __init__(self, controller_url: str, token: str = ""):
        self.controller_url = controller_url
        self.token = token
        self.websocket = None

    async def connect(self):
        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        self.websocket = await connect(self.controller_url, extra_headers=headers or None, ping_interval=None, ping_timeout=None)
        return self.websocket

    async def send_register(self, message: AgentRegisterMessage) -> dict:
        await self._send(message.model_dump())
        return await self._receive()

    async def send_status(self, message: ClientStatusMessage) -> None:
        await self._send(message.model_dump())

    async def send_event(self, message: TaskEventMessage) -> None:
        await self._send(message.model_dump())

    async def send_result(self, message: TaskResultMessage) -> None:
        await self._send(message.model_dump())

    async def send_query_result(self, message: TaskQueryResultMessage) -> None:
        await self._send(message.model_dump())

    async def listen(self, on_task: Callable[[TaskMessage], Awaitable[None]]) -> None:
        if self.websocket is None:
            raise RuntimeError("connection not established")
        try:
            async for raw in self.websocket:
                data = json.loads(raw)
                if data.get("type") == "task":
                    await on_task(TaskMessage(**data))
        except ConnectionClosed:
            return

    async def close(self) -> None:
        if self.websocket is not None:
            await self.websocket.close()
            self.websocket = None

    async def _send(self, payload: dict) -> None:
        if self.websocket is None:
            raise RuntimeError("connection not established")
        await self.websocket.send(json.dumps(payload))

    async def _receive(self) -> dict:
        if self.websocket is None:
            raise RuntimeError("connection not established")
        raw = await self.websocket.recv()
        return json.loads(raw)
