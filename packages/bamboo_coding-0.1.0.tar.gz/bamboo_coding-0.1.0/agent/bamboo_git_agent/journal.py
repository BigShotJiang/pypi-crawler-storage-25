from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path


ACTIVE_STATUSES = {"received", "queued", "accepted", "running"}
TERMINAL_STATUSES = {"succeeded", "failed", "cancelled", "timeout"}


def _json_dumps(value) -> str | None:
    if value is None:
        return None
    return json.dumps(value, sort_keys=True)


def _json_loads(value):
    if not value:
        return None
    return json.loads(value)


class RuntimeJournal:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS tasks (
                    task_id TEXT PRIMARY KEY,
                    repo_id TEXT NOT NULL,
                    capability TEXT NOT NULL,
                    action TEXT NOT NULL,
                    status TEXT NOT NULL,
                    params_json TEXT NOT NULL DEFAULT '{}',
                    result_json TEXT,
                    error TEXT,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    completed_at REAL,
                    last_seq INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS task_events (
                    task_id TEXT NOT NULL,
                    seq INTEGER NOT NULL,
                    event_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL DEFAULT '{}',
                    created_at REAL NOT NULL,
                    PRIMARY KEY (task_id, seq),
                    FOREIGN KEY (task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
                );
                """
            )

    def record_task_received(self, *, task_id: str, repo_id: str, capability: str, action: str, params: dict) -> dict:
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO tasks (
                    task_id, repo_id, capability, action, status, params_json, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (task_id, repo_id, capability, action, "received", _json_dumps(params), now, now),
            )
            row = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
        return self._row_to_task(row)

    def append_event(self, *, task_id: str, event_type: str, status: str, payload: dict | None = None) -> dict:
        payload = payload or {}
        now = time.time()
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
            if row is None:
                raise KeyError(f"unknown task_id: {task_id}")
            seq = int(row["last_seq"]) + 1
            completed_at = row["completed_at"]
            if status in TERMINAL_STATUSES and completed_at is None:
                completed_at = now
            conn.execute(
                "INSERT INTO task_events (task_id, seq, event_type, status, payload_json, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (task_id, seq, event_type, status, _json_dumps(payload), now),
            )
            conn.execute(
                "UPDATE tasks SET status = ?, updated_at = ?, completed_at = ?, last_seq = ? WHERE task_id = ?",
                (status, now, completed_at, seq, task_id),
            )
        return {
            "task_id": task_id,
            "seq": seq,
            "event_type": event_type,
            "status": status,
            "payload": payload,
            "created_at": now,
        }

    def record_terminal_result(self, *, task_id: str, status: str, result: dict | None = None, error: str | None = None) -> dict:
        if status not in TERMINAL_STATUSES:
            raise ValueError(f"terminal status required, got {status}")
        payload = {"result": result or {}}
        if error is not None:
            payload["error"] = error
        event = self.append_event(task_id=task_id, event_type="result", status=status, payload=payload)
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                "UPDATE tasks SET result_json = ?, error = ?, updated_at = ?, completed_at = COALESCE(completed_at, ?) WHERE task_id = ?",
                (_json_dumps(result or {}), error, now, now, task_id),
            )
            row = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
        summary = self._row_to_task(row)
        return {
            "task_id": task_id,
            "status": summary["status"],
            "seq": event["seq"],
            "result": summary["result"],
            "error": summary["error"],
        }

    def get_task(self, task_id: str) -> dict | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,)).fetchone()
        return self._row_to_task(row)

    def get_events(self, task_id: str, *, after_seq: int = 0) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT task_id, seq, event_type, status, payload_json, created_at FROM task_events WHERE task_id = ? AND seq > ? ORDER BY seq ASC",
                (task_id, after_seq),
            ).fetchall()
        return [self._row_to_event(row) for row in rows]

    def list_active_tasks(self) -> list[dict]:
        placeholders = ",".join("?" for _ in ACTIVE_STATUSES)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM tasks WHERE status IN ({placeholders}) ORDER BY created_at ASC",
                tuple(sorted(ACTIVE_STATUSES)),
            ).fetchall()
        return [self._row_to_task(row) for row in rows]

    def build_replay_payload(self, cursor_map: dict[str, int] | None) -> dict:
        cursor_map = cursor_map or {}
        active_tasks = self.list_active_tasks()
        events = {}
        terminal_results = []
        for task_id, cursor in cursor_map.items():
            summary = self.get_task(task_id)
            if summary is None:
                continue
            replay_events = self.get_events(task_id, after_seq=int(cursor or 0))
            if replay_events:
                events[task_id] = replay_events
            if summary["status"] in TERMINAL_STATUSES and summary["last_seq"] > int(cursor or 0):
                terminal_results.append(
                    {
                        "task_id": task_id,
                        "repo_id": summary["repo_id"],
                        "capability": summary["capability"],
                        "action": summary["action"],
                        "status": summary["status"],
                        "seq": summary["last_seq"],
                        "result": summary["result"],
                        "error": summary["error"],
                    }
                )
        return {"active_tasks": active_tasks, "events": events, "terminal_results": terminal_results}

    def _row_to_task(self, row: sqlite3.Row | None) -> dict | None:
        if row is None:
            return None
        return {
            "task_id": row["task_id"],
            "repo_id": row["repo_id"],
            "capability": row["capability"],
            "action": row["action"],
            "status": row["status"],
            "params": _json_loads(row["params_json"]) or {},
            "result": _json_loads(row["result_json"]) or {},
            "error": row["error"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "completed_at": row["completed_at"],
            "last_seq": row["last_seq"],
        }

    def _row_to_event(self, row: sqlite3.Row) -> dict:
        return {
            "task_id": row["task_id"],
            "seq": row["seq"],
            "event_type": row["event_type"],
            "status": row["status"],
            "payload": _json_loads(row["payload_json"]) or {},
            "created_at": row["created_at"],
        }
