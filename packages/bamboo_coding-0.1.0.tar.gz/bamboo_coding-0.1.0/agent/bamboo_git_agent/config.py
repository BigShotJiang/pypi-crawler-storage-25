from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import json
import os
import platform


@dataclass(frozen=True)
class RepositoryConfig:
    repo_id: str
    name: str
    path: str


@dataclass(frozen=True)
class AgentConfig:
    controller_url: str
    client_id: str
    hostname: str
    version: str
    token: str
    token_path: Path
    journal_path: Path
    max_concurrent_tasks: int = 1
    allowed_roots: tuple[str, ...] = field(default_factory=tuple)
    repositories: tuple[RepositoryConfig, ...] = field(default_factory=tuple)


def _normalize_root(path_value: str) -> str:
    return str(Path(path_value).expanduser().resolve())


def _load_allowed_roots() -> tuple[str, ...]:
    raw_value = os.getenv("AGENT_ALLOWED_ROOTS") or os.getenv("AGENT_ROOT") or os.getenv("AGENT_REPO_PATH") or str(Path.cwd())
    roots = tuple(_normalize_root(item) for item in raw_value.split(os.pathsep) if item.strip())
    return roots or (_normalize_root(str(Path.cwd())),)


def _load_stored_token(token_path: Path) -> str:
    if not token_path.exists():
        return ""
    try:
        payload = json.loads(token_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    token = payload.get("token")
    return token if isinstance(token, str) else ""


def load_config() -> AgentConfig:
    base_dir = Path(os.getenv("AGENT_HOME", Path.cwd() / ".agent"))
    token_path = Path(os.getenv("AGENT_TOKEN_PATH", base_dir / "token.json"))
    allowed_roots = _load_allowed_roots()
    repositories = tuple(
        RepositoryConfig(
            repo_id=root,
            name=Path(root).name or root,
            path=root,
        )
        for root in allowed_roots
    )
    token = os.getenv("AGENT_TOKEN") or _load_stored_token(token_path)
    return AgentConfig(
        controller_url=os.getenv("CONTROLLER_URL", "ws://127.0.0.1:8100/ws/agents"),
        client_id=os.getenv("AGENT_CLIENT_ID", platform.node() or "git-agent"),
        hostname=os.getenv("AGENT_HOSTNAME", platform.node() or "git-agent"),
        version=os.getenv("AGENT_VERSION", "0.1.0"),
        token=token,
        token_path=token_path,
        journal_path=Path(os.getenv("AGENT_JOURNAL_PATH", base_dir / "journal.db")),
        max_concurrent_tasks=int(os.getenv("AGENT_MAX_CONCURRENT_TASKS", "1")),
        allowed_roots=allowed_roots,
        repositories=repositories,
    )
