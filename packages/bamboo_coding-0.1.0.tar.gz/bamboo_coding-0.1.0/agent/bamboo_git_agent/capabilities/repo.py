from __future__ import annotations

from pathlib import Path
from typing import Callable

import git_utils
from shared.protocol import TaskMessage


def _allowed_roots(repositories: dict[str, str] | list[str] | tuple[str, ...]) -> list[str]:
    if isinstance(repositories, dict):
        values = list(repositories.values()) or list(repositories.keys())
    else:
        values = list(repositories)
    return [str(Path(item).expanduser().resolve()) for item in values]


def _resolve_allowed_path(task: TaskMessage, repositories: dict[str, str] | list[str] | tuple[str, ...]) -> str:
    target = str(Path(task.path).expanduser().resolve())
    for root in _allowed_roots(repositories):
        try:
            Path(target).relative_to(root)
            return target
        except ValueError:
            continue
    raise PermissionError(f"Path outside allowed roots: {task.path}")


def _resolve_repo_root(task: TaskMessage, repositories: dict[str, str] | list[str] | tuple[str, ...]) -> str:
    allowed_path = _resolve_allowed_path(task, repositories)
    return git_utils.resolve_git_repository_path(allowed_path)


def execute_task(task: TaskMessage, repositories: dict[str, str] | list[str] | tuple[str, ...]) -> dict:
    handler = _HANDLERS.get((task.capability, task.action))
    if handler is None:
        raise KeyError(f"Unsupported task: {task.capability}/{task.action}")
    git_utils.clear_cache()
    return handler(task, repositories)


def _fs_tree(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    include_nested = bool(task.params.get("all", False))
    if git_utils.is_git_repository_path(path):
        repo_path = git_utils.resolve_git_repository_path(path)
        return git_utils.get_file_tree(repo_path, changed_only=not include_nested)
    return git_utils.get_workspace_tree(path, include_nested=include_nested)


def _fs_browse(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    return git_utils.browse_workspace(path)


def _fs_read(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    return git_utils.read_workspace_file(path)


def _fs_write(task: TaskMessage, repositories) -> dict:
    path = _resolve_allowed_path(task, repositories)
    return git_utils.write_workspace_file(path, task.params["content"], task.params.get("encoding", "utf-8"))


def _tree(task: TaskMessage, repositories) -> dict:
    show_all = bool(task.params.get("all", False))
    return git_utils.get_file_tree(_resolve_repo_root(task, repositories), changed_only=not show_all)


def _browse(task: TaskMessage, repositories) -> dict:
    return git_utils.browse_directory(_resolve_repo_root(task, repositories), task.params.get("path", "/"))


def _diff(task: TaskMessage, repositories) -> dict:
    return git_utils.get_file_diff(
        _resolve_repo_root(task, repositories),
        task.params["file"],
        bool(task.params.get("staged", False)),
        int(task.params.get("context", 3)),
    )


def _status(task: TaskMessage, repositories) -> dict:
    return git_utils.get_repo_status(_resolve_repo_root(task, repositories))


def _commits(task: TaskMessage, repositories) -> dict:
    limit = int(task.params.get("limit", 50))
    offset = int(task.params.get("offset", 0))
    repo_path = _resolve_repo_root(task, repositories)
    return {
        "commits": git_utils.get_commit_history(repo_path, limit=limit, offset=offset),
        "limit": limit,
        "offset": offset,
    }


def _commit_details(task: TaskMessage, repositories) -> dict:
    return git_utils.get_commit_details(_resolve_repo_root(task, repositories), task.params["commit_hash"])


def _read_file(task: TaskMessage, repositories) -> dict:
    return git_utils.read_file_content(_resolve_repo_root(task, repositories), task.params["file_path"])


def _write_file(task: TaskMessage, repositories) -> dict:
    return git_utils.write_file_content(
        _resolve_repo_root(task, repositories),
        task.params["file_path"],
        task.params["content"],
        task.params.get("encoding", "utf-8"),
    )


def _stage(task: TaskMessage, repositories) -> dict:
    repo_path = _resolve_repo_root(task, repositories)
    if task.params.get("stage_all"):
        return git_utils.stage_all_files(repo_path)
    return git_utils.stage_file(repo_path, task.params["file_path"])


def _unstage(task: TaskMessage, repositories) -> dict:
    return git_utils.unstage_file(_resolve_repo_root(task, repositories), task.params["file_path"])


def _list_branches(task: TaskMessage, repositories) -> dict:
    return git_utils.list_branches(_resolve_repo_root(task, repositories))


def _create_branch(task: TaskMessage, repositories) -> dict:
    return git_utils.create_branch(_resolve_repo_root(task, repositories), task.params["name"], task.params.get("start_point"))


def _checkout_branch(task: TaskMessage, repositories) -> dict:
    return git_utils.switch_branch(_resolve_repo_root(task, repositories), task.params["name"])


def _delete_branch(task: TaskMessage, repositories) -> dict:
    return git_utils.delete_branch(_resolve_repo_root(task, repositories), task.params["name"], bool(task.params.get("force", False)))


def _merge_branch(task: TaskMessage, repositories) -> dict:
    return git_utils.merge_branch(_resolve_repo_root(task, repositories), task.params["source"], task.params.get("message"))


def _create_commit(task: TaskMessage, repositories) -> dict:
    return git_utils.create_commit(
        _resolve_repo_root(task, repositories),
        task.params["message"],
        task.params.get("author_name"),
        task.params.get("author_email"),
    )


_HANDLERS: dict[tuple[str, str], Callable[[TaskMessage, dict[str, str] | list[str] | tuple[str, ...]], dict]] = {
    ("fs.tree", "get"): _fs_tree,
    ("fs.browse", "get"): _fs_browse,
    ("fs.file.read", "get"): _fs_read,
    ("fs.file.write", "put"): _fs_write,
    ("repo.tree", "get"): _tree,
    ("repo.browse", "get"): _browse,
    ("repo.diff", "get"): _diff,
    ("repo.status", "get"): _status,
    ("repo.commits", "list"): _commits,
    ("repo.commit_details", "get"): _commit_details,
    ("repo.file.read", "get"): _read_file,
    ("repo.file.write", "put"): _write_file,
    ("repo.stage", "post"): _stage,
    ("repo.unstage", "post"): _unstage,
    ("repo.branches.list", "get"): _list_branches,
    ("repo.branches.create", "post"): _create_branch,
    ("repo.branches.checkout", "put"): _checkout_branch,
    ("repo.branches.delete", "delete"): _delete_branch,
    ("repo.branches.merge", "post"): _merge_branch,
    ("repo.commit.create", "post"): _create_commit,
    ("git.status", "get"): _status,
    ("git.diff", "get"): _diff,
    ("git.commits", "list"): _commits,
    ("git.commit_details", "get"): _commit_details,
    ("git.stage", "post"): _stage,
    ("git.unstage", "post"): _unstage,
    ("git.branches.list", "get"): _list_branches,
    ("git.branches.create", "post"): _create_branch,
    ("git.branches.checkout", "put"): _checkout_branch,
    ("git.branches.delete", "delete"): _delete_branch,
    ("git.branches.merge", "post"): _merge_branch,
    ("git.commit.create", "post"): _create_commit,
}
