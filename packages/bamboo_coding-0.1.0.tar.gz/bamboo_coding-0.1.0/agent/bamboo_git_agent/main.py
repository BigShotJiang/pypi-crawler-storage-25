from __future__ import annotations

import asyncio
import json
from dataclasses import asdict
from pathlib import Path
from typing import Awaitable, Callable

from agent.bamboo_git_agent.capabilities.repo import execute_task
from agent.bamboo_git_agent.config import load_config
from agent.bamboo_git_agent.controller_client import ControllerConnection
from agent.bamboo_git_agent.journal import RuntimeJournal
from agent.bamboo_git_agent.status import build_register_message, build_status_message
from shared.protocol import TaskEventMessage, TaskMessage, TaskResultMessage


TaskExecutor = Callable[[TaskMessage], Awaitable[dict]]


class AgentRuntime:
    def __init__(self, executor: TaskExecutor, config=None):
        self.config = config or load_config()
        self.executor = executor
        self.journal = RuntimeJournal(self.config.journal_path)
        self.connection = ControllerConnection(self.config.controller_url, token=self.config.token)

    def capabilities(self) -> list[dict]:
        return [
            {"capability": "fs.tree", "actions": ["get"]},
            {"capability": "fs.browse", "actions": ["get"]},
            {"capability": "fs.file.read", "actions": ["get"]},
            {"capability": "fs.file.write", "actions": ["put"]},
            {"capability": "git.diff", "actions": ["get"]},
            {"capability": "git.status", "actions": ["get"]},
            {"capability": "git.commits", "actions": ["list"]},
            {"capability": "git.commit_details", "actions": ["get"]},
            {"capability": "git.stage", "actions": ["post"]},
            {"capability": "git.unstage", "actions": ["post"]},
            {"capability": "git.branches.list", "actions": ["get"]},
            {"capability": "git.branches.create", "actions": ["post"]},
            {"capability": "git.branches.checkout", "actions": ["put"]},
            {"capability": "git.branches.delete", "actions": ["delete"]},
            {"capability": "git.branches.merge", "actions": ["post"]},
            {"capability": "git.commit.create", "actions": ["post"]},
            {"capability": "repo.tree", "actions": ["get"]},
            {"capability": "repo.browse", "actions": ["get"]},
            {"capability": "repo.diff", "actions": ["get"]},
            {"capability": "repo.status", "actions": ["get"]},
            {"capability": "repo.commits", "actions": ["list"]},
            {"capability": "repo.commit_details", "actions": ["get"]},
            {"capability": "repo.file.read", "actions": ["get"]},
            {"capability": "repo.file.write", "actions": ["put"]},
            {"capability": "repo.stage", "actions": ["post"]},
            {"capability": "repo.unstage", "actions": ["post"]},
            {"capability": "repo.branches.list", "actions": ["get"]},
            {"capability": "repo.branches.create", "actions": ["post"]},
            {"capability": "repo.branches.checkout", "actions": ["put"]},
            {"capability": "repo.branches.delete", "actions": ["delete"]},
            {"capability": "repo.branches.merge", "actions": ["post"]},
            {"capability": "repo.commit.create", "actions": ["post"]},
        ]

    def roots(self) -> list[dict]:
        return [{"path": item.path, "name": item.name} for item in self.config.repositories]

    def repositories(self) -> list[dict]:
        return [asdict(item) for item in self.config.repositories]

    def runtime_health(self) -> tuple[int, int, int]:
        active = len(self.journal.list_active_tasks())
        queued = 0
        return active, queued, self.config.max_concurrent_tasks

    def _persist_token(self, token: str) -> None:
        self.config.token_path.parent.mkdir(parents=True, exist_ok=True)
        self.config.token_path.write_text(json.dumps({"token": token}), encoding="utf-8")
        self.connection.token = token

    async def register_once(self) -> bool:
        await self.connection.connect()
        active, queued, max_concurrent = self.runtime_health()
        register = build_register_message(
            client_id=self.config.client_id,
            hostname=self.config.hostname,
            version=self.config.version,
            platform_name="python",
            capabilities=self.capabilities(),
            roots=self.roots(),
            active_tasks=active,
            queued_tasks=queued,
            max_concurrent_tasks=max_concurrent,
            connected=True,
        )
        registration = await self.connection.send_register(register)
        approved = bool(registration.get("approved", False))
        token = registration.get("token")
        if approved and isinstance(token, str) and token:
            self._persist_token(token)
        return approved

    async def run(self) -> None:
        while True:
            try:
                approved = await self.register_once()
                if not approved:
                    await self.connection.close()
                    await asyncio.sleep(1)
                    continue
                await self.connection.listen(self.handle_task)
            except Exception:
                await self.connection.close()
                await asyncio.sleep(1)
                continue
            await self.connection.close()
            await asyncio.sleep(1)

    async def handle_task(self, task: TaskMessage) -> None:
        self.journal.record_task_received(
            task_id=task.task_id,
            repo_id=task.repo_id,
            capability=task.capability,
            action=task.action,
            params=task.params,
        )
        self.journal.append_event(task_id=task.task_id, event_type="accepted", status="running", payload={"message": "started"})
        await self.connection.send_event(TaskEventMessage(task_id=task.task_id, status="running", message="started"))
        try:
            result = await self.executor(task)
            self.journal.record_terminal_result(task_id=task.task_id, status="succeeded", result=result)
            await self.connection.send_result(TaskResultMessage(task_id=task.task_id, success=True, result=result))
        except Exception as exc:
            self.journal.record_terminal_result(task_id=task.task_id, status="failed", error=str(exc))
            await self.connection.send_result(TaskResultMessage(task_id=task.task_id, success=False, error=str(exc)))
        active, queued, max_concurrent = self.runtime_health()
        await self.connection.send_status(
            build_status_message(
                client_id=self.config.client_id,
                hostname=self.config.hostname,
                version=self.config.version,
                platform_name="python",
                reason="task_update",
                capabilities=self.capabilities(),
                roots=self.roots(),
                active_tasks=active,
                queued_tasks=queued,
                max_concurrent_tasks=max_concurrent,
                connected=True,
            )
        )


def main() -> None:
    config = load_config()
    repositories = {item.repo_id: item.path for item in config.repositories}

    async def _execute(task: TaskMessage) -> dict:
        return execute_task(task, repositories)

    runtime = AgentRuntime(_execute, config=config)
    asyncio.run(runtime.run())


if __name__ == "__main__":
    main()
