"""Homelab Infrastructure MCP modules."""
