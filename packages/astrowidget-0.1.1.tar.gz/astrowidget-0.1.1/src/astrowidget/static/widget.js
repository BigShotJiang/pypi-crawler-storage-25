function tc(j) {
  return j && j.__esModule && Object.prototype.hasOwnProperty.call(j, "default") ? j.default : j;
}
var un = { exports: {} }, nc = un.exports, _f;
function ac() {
  return _f || (_f = 1, (function(j, ge) {
    (function(fe, oe) {
      j.exports = oe();
    })(nc, (function() {
      var fe = function(e) {
        return e instanceof Uint8Array || e instanceof Uint16Array || e instanceof Uint32Array || e instanceof Int8Array || e instanceof Int16Array || e instanceof Int32Array || e instanceof Float32Array || e instanceof Float64Array || e instanceof Uint8ClampedArray;
      }, oe = function(e, t) {
        for (var u = Object.keys(t), x = 0; x < u.length; ++x)
          e[u[x]] = t[u[x]];
        return e;
      }, Se = `
`;
      function pe(e) {
        return typeof atob < "u" ? atob(e) : "base64:" + e;
      }
      function me(e) {
        var t = new Error("(regl) " + e);
        throw console.error(t), t;
      }
      function be(e, t) {
        e || me(t);
      }
      function Le(e) {
        return e ? ": " + e : "";
      }
      function Ae(e, t, u) {
        e in t || me("unknown parameter (" + e + ")" + Le(u) + ". possible values: " + Object.keys(t).join());
      }
      function Ce(e, t) {
        fe(e) || me(
          "invalid parameter type" + Le(t) + ". must be a typed array"
        );
      }
      function Xe(e, t) {
        switch (t) {
          case "number":
            return typeof e == "number";
          case "object":
            return typeof e == "object";
          case "string":
            return typeof e == "string";
          case "boolean":
            return typeof e == "boolean";
          case "function":
            return typeof e == "function";
          case "undefined":
            return typeof e > "u";
          case "symbol":
            return typeof e == "symbol";
        }
      }
      function yr(e, t, u) {
        Xe(e, t) || me(
          "invalid parameter type" + Le(u) + ". expected " + t + ", got " + typeof e
        );
      }
      function mr(e, t) {
        e >= 0 && (e | 0) === e || me("invalid parameter type, (" + e + ")" + Le(t) + ". must be a nonnegative integer");
      }
      function Pe(e, t, u) {
        t.indexOf(e) < 0 && me("invalid value" + Le(u) + ". must be one of: " + t);
      }
      var Ze = [
        "gl",
        "canvas",
        "container",
        "attributes",
        "pixelRatio",
        "extensions",
        "optionalExtensions",
        "profile",
        "onDone"
      ];
      function hr(e) {
        Object.keys(e).forEach(function(t) {
          Ze.indexOf(t) < 0 && me('invalid regl constructor argument "' + t + '". must be one of ' + Ze);
        });
      }
      function er(e, t) {
        for (e = e + ""; e.length < t; )
          e = " " + e;
        return e;
      }
      function je() {
        this.name = "unknown", this.lines = [], this.index = {}, this.hasErrors = !1;
      }
      function tr(e, t) {
        this.number = e, this.line = t, this.errors = [];
      }
      function Wr(e, t, u) {
        this.file = e, this.line = t, this.message = u;
      }
      function sr() {
        var e = new Error(), t = (e.stack || e).toString(), u = /compileProcedure.*\n\s*at.*\((.*)\)/.exec(t);
        if (u)
          return u[1];
        var x = /compileProcedure.*\n\s*at\s+(.*)(\n|$)/.exec(t);
        return x ? x[1] : "unknown";
      }
      function Yr() {
        var e = new Error(), t = (e.stack || e).toString(), u = /at REGLCommand.*\n\s+at.*\((.*)\)/.exec(t);
        if (u)
          return u[1];
        var x = /at REGLCommand.*\n\s+at\s+(.*)\n/.exec(t);
        return x ? x[1] : "unknown";
      }
      function Er(e, t) {
        var u = e.split(`
`), x = 1, w = 0, E = {
          unknown: new je(),
          0: new je()
        };
        E.unknown.name = E[0].name = t || sr(), E.unknown.lines.push(new tr(0, ""));
        for (var g = 0; g < u.length; ++g) {
          var G = u[g], C = /^\s*#\s*(\w+)\s+(.+)\s*$/.exec(G);
          if (C)
            switch (C[1]) {
              case "line":
                var I = /(\d+)(\s+\d+)?/.exec(C[2]);
                I && (x = I[1] | 0, I[2] && (w = I[2] | 0, w in E || (E[w] = new je())));
                break;
              case "define":
                var k = /SHADER_NAME(_B64)?\s+(.*)$/.exec(C[2]);
                k && (E[w].name = k[1] ? pe(k[2]) : k[2]);
                break;
            }
          E[w].lines.push(new tr(x++, G));
        }
        return Object.keys(E).forEach(function(P) {
          var z = E[P];
          z.lines.forEach(function(D) {
            z.index[D.number] = D;
          });
        }), E;
      }
      function cn(e) {
        var t = [];
        return e.split(`
`).forEach(function(u) {
          if (!(u.length < 5)) {
            var x = /^ERROR:\s+(\d+):(\d+):\s*(.*)$/.exec(u);
            x ? t.push(new Wr(
              x[1] | 0,
              x[2] | 0,
              x[3].trim()
            )) : u.length > 0 && t.push(new Wr("unknown", 0, u));
          }
        }), t;
      }
      function ln(e, t) {
        t.forEach(function(u) {
          var x = e[u.file];
          if (x) {
            var w = x.index[u.line];
            if (w) {
              w.errors.push(u), x.hasErrors = !0;
              return;
            }
          }
          e.unknown.hasErrors = !0, e.unknown.lines[0].errors.push(u);
        });
      }
      function xf(e, t, u, x, w) {
        if (!e.getShaderParameter(t, e.COMPILE_STATUS)) {
          var E = e.getShaderInfoLog(t), g = x === e.FRAGMENT_SHADER ? "fragment" : "vertex";
          ca(u, "string", g + " shader source must be a string", w);
          var G = Er(u, w), C = cn(E);
          ln(G, C), Object.keys(G).forEach(function(I) {
            var k = G[I];
            if (!k.hasErrors)
              return;
            var P = [""], z = [""];
            function D(B, v) {
              P.push(B), z.push(v || "");
            }
            D("file number " + I + ": " + k.name + `
`, "color:red;text-decoration:underline;font-weight:bold"), k.lines.forEach(function(B) {
              if (B.errors.length > 0) {
                D(er(B.number, 4) + "|  ", "background-color:yellow; font-weight:bold"), D(B.line + Se, "color:red; background-color:yellow; font-weight:bold");
                var v = 0;
                B.errors.forEach(function(T) {
                  var N = T.message, Z = /^\s*'(.*)'\s*:\s*(.*)$/.exec(N);
                  if (Z) {
                    var O = Z[1];
                    switch (N = Z[2], O) {
                      case "assign":
                        O = "=";
                        break;
                    }
                    v = Math.max(B.line.indexOf(O, v), 0);
                  } else
                    v = 0;
                  D(er("| ", 6)), D(er("^^^", v + 3) + Se, "font-weight:bold"), D(er("| ", 6)), D(N + Se, "font-weight:bold");
                }), D(er("| ", 6) + Se);
              } else
                D(er(B.number, 4) + "|  "), D(B.line + Se, "color:red");
            }), typeof document < "u" && !window.chrome ? (z[0] = P.join("%c"), console.log.apply(console, z)) : console.log(P.join(""));
          }), be.raise("Error compiling " + g + " shader, " + G[0].name);
        }
      }
      function Af(e, t, u, x, w) {
        if (!e.getProgramParameter(t, e.LINK_STATUS)) {
          var E = e.getProgramInfoLog(t), g = Er(u, w), G = Er(x, w), C = 'Error linking program with vertex shader, "' + G[0].name + '", and fragment shader "' + g[0].name + '"';
          typeof document < "u" ? console.log(
            "%c" + C + Se + "%c" + E,
            "color:red;text-decoration:underline;font-weight:bold",
            "color:red"
          ) : console.log(C + Se + E), be.raise(C);
        }
      }
      function sa(e) {
        e._commandRef = sr();
      }
      function Tf(e, t, u, x) {
        sa(e);
        function w(C) {
          return C ? x.id(C) : 0;
        }
        e._fragId = w(e.static.frag), e._vertId = w(e.static.vert);
        function E(C, I) {
          Object.keys(I).forEach(function(k) {
            C[x.id(k)] = !0;
          });
        }
        var g = e._uniformSet = {};
        E(g, t.static), E(g, t.dynamic);
        var G = e._attributeSet = {};
        E(G, u.static), E(G, u.dynamic), e._hasCount = "count" in e.static || "count" in e.dynamic || "elements" in e.static || "elements" in e.dynamic;
      }
      function Rt(e, t) {
        var u = Yr();
        me(e + " in command " + (t || sr()) + (u === "unknown" ? "" : " called from " + u));
      }
      function gf(e, t, u) {
        e || Rt(t, u || sr());
      }
      function Sf(e, t, u, x) {
        e in t || Rt(
          "unknown parameter (" + e + ")" + Le(u) + ". possible values: " + Object.keys(t).join(),
          x || sr()
        );
      }
      function ca(e, t, u, x) {
        Xe(e, t) || Rt(
          "invalid parameter type" + Le(u) + ". expected " + t + ", got " + typeof e,
          x || sr()
        );
      }
      function wf(e) {
        e();
      }
      function Lf(e, t, u) {
        e.texture ? Pe(
          e.texture._texture.internalformat,
          t,
          "unsupported texture format for attachment"
        ) : Pe(
          e.renderbuffer._renderbuffer.format,
          u,
          "unsupported renderbuffer format for attachment"
        );
      }
      var Ot = 33071, la = 9728, Rf = 9984, Of = 9985, Cf = 9986, Gf = 9987, Df = 5120, Ff = 5121, Nf = 5122, Bf = 5123, If = 5124, Pf = 5125, da = 5126, ma = 32819, ha = 32820, va = 33635, pa = 34042, kf = 36193, nr = {};
      nr[Df] = nr[Ff] = 1, nr[Nf] = nr[Bf] = nr[kf] = nr[va] = nr[ma] = nr[ha] = 2, nr[If] = nr[Pf] = nr[da] = nr[pa] = 4;
      function _a(e, t) {
        return e === ha || e === ma || e === va ? 2 : e === pa ? 4 : nr[e] * t;
      }
      function Ct(e) {
        return !(e & e - 1) && !!e;
      }
      function Mf(e, t, u) {
        var x, w = t.width, E = t.height, g = t.channels;
        be(
          w > 0 && w <= u.maxTextureSize && E > 0 && E <= u.maxTextureSize,
          "invalid texture shape"
        ), (e.wrapS !== Ot || e.wrapT !== Ot) && be(
          Ct(w) && Ct(E),
          "incompatible wrap mode for texture, both width and height must be power of 2"
        ), t.mipmask === 1 ? w !== 1 && E !== 1 && be(
          e.minFilter !== Rf && e.minFilter !== Cf && e.minFilter !== Of && e.minFilter !== Gf,
          "min filter requires mipmap"
        ) : (be(
          Ct(w) && Ct(E),
          "texture must be a square power of 2 to support mipmapping"
        ), be(
          t.mipmask === (w << 1) - 1,
          "missing or incomplete mipmap data"
        )), t.type === da && (u.extensions.indexOf("oes_texture_float_linear") < 0 && be(
          e.minFilter === la && e.magFilter === la,
          "filter not supported, must enable oes_texture_float_linear"
        ), be(
          !e.genMipmaps,
          "mipmap generation not supported with float textures"
        ));
        var G = t.images;
        for (x = 0; x < 16; ++x)
          if (G[x]) {
            var C = w >> x, I = E >> x;
            be(t.mipmask & 1 << x, "missing mipmap data");
            var k = G[x];
            if (be(
              k.width === C && k.height === I,
              "invalid shape for mip images"
            ), be(
              k.format === t.format && k.internalformat === t.internalformat && k.type === t.type,
              "incompatible type for mip image"
            ), !k.compressed) if (k.data) {
              var P = Math.ceil(_a(k.type, g) * C / k.unpackAlignment) * k.unpackAlignment;
              be(
                k.data.byteLength === P * I,
                "invalid data for image, buffer size is inconsistent with image format"
              );
            } else k.element || k.copy;
          } else e.genMipmaps || be((t.mipmask & 1 << x) === 0, "extra mipmap data");
        t.compressed && be(
          !e.genMipmaps,
          "mipmap generation for compressed images not supported"
        );
      }
      function Uf(e, t, u, x) {
        var w = e.width, E = e.height, g = e.channels;
        be(
          w > 0 && w <= x.maxTextureSize && E > 0 && E <= x.maxTextureSize,
          "invalid texture shape"
        ), be(
          w === E,
          "cube map must be square"
        ), be(
          t.wrapS === Ot && t.wrapT === Ot,
          "wrap mode not supported by cube map"
        );
        for (var G = 0; G < u.length; ++G) {
          var C = u[G];
          be(
            C.width === w && C.height === E,
            "inconsistent cube map face shape"
          ), t.genMipmaps && (be(
            !C.compressed,
            "can not generate mipmap for compressed textures"
          ), be(
            C.mipmask === 1,
            "can not specify mipmaps and generate mipmaps"
          ));
          for (var I = C.images, k = 0; k < 16; ++k) {
            var P = I[k];
            if (P) {
              var z = w >> k, D = E >> k;
              be(C.mipmask & 1 << k, "missing mipmap data"), be(
                P.width === z && P.height === D,
                "invalid shape for mip images"
              ), be(
                P.format === e.format && P.internalformat === e.internalformat && P.type === e.type,
                "incompatible type for mip image"
              ), P.compressed || (P.data ? be(
                P.data.byteLength === z * D * Math.max(_a(P.type, g), P.unpackAlignment),
                "invalid data for image, buffer size is inconsistent with image format"
              ) : P.element || P.copy);
            }
          }
        }
      }
      var a = oe(be, {
        optional: wf,
        raise: me,
        commandRaise: Rt,
        command: gf,
        parameter: Ae,
        commandParameter: Sf,
        constructor: hr,
        type: yr,
        commandType: ca,
        isTypedArray: Ce,
        nni: mr,
        oneOf: Pe,
        shaderError: xf,
        linkError: Af,
        callSite: Yr,
        saveCommandRef: sa,
        saveDrawInfo: Tf,
        framebufferFormat: Lf,
        guessCommand: sr,
        texture2D: Mf,
        textureCube: Uf
      }), Vf = 0, zf = 0, Hf = 5, jf = 6;
      function Fr(e, t) {
        this.id = Vf++, this.type = e, this.data = t;
      }
      function ba(e) {
        return e.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      }
      function ct(e) {
        if (e.length === 0)
          return [];
        var t = e.charAt(0), u = e.charAt(e.length - 1);
        if (e.length > 1 && t === u && (t === '"' || t === "'"))
          return ['"' + ba(e.substr(1, e.length - 2)) + '"'];
        var x = /\[(false|true|null|\d+|'[^']*'|"[^"]*")\]/.exec(e);
        if (x)
          return ct(e.substr(0, x.index)).concat(ct(x[1])).concat(ct(e.substr(x.index + x[0].length)));
        var w = e.split(".");
        if (w.length === 1)
          return ['"' + ba(e) + '"'];
        for (var E = [], g = 0; g < w.length; ++g)
          E = E.concat(ct(w[g]));
        return E;
      }
      function ya(e) {
        return "[" + ct(e).join("][") + "]";
      }
      function $f(e, t) {
        return new Fr(e, ya(t + ""));
      }
      function Xf(e) {
        return typeof e == "function" && !e._reglType || e instanceof Fr;
      }
      function Ea(e, t) {
        if (typeof e == "function")
          return new Fr(zf, e);
        if (typeof e == "number" || typeof e == "boolean")
          return new Fr(Hf, e);
        if (Array.isArray(e))
          return new Fr(jf, e.map(function(u, x) {
            return Ea(u, t + "[" + x + "]");
          }));
        if (e instanceof Fr)
          return e;
        a(!1, "invalid option type in uniform " + t);
      }
      var ar = {
        DynamicVariable: Fr,
        define: $f,
        isDynamic: Xf,
        unbox: Ea,
        accessor: ya
      }, dn = {
        next: typeof requestAnimationFrame == "function" ? function(e) {
          return requestAnimationFrame(e);
        } : function(e) {
          return setTimeout(e, 16);
        },
        cancel: typeof cancelAnimationFrame == "function" ? function(e) {
          return cancelAnimationFrame(e);
        } : clearTimeout
      }, xa = typeof performance < "u" && performance.now ? function() {
        return performance.now();
      } : function() {
        return +/* @__PURE__ */ new Date();
      };
      function Wf() {
        var e = { "": 0 }, t = [""];
        return {
          id: function(u) {
            var x = e[u];
            return x || (x = e[u] = t.length, t.push(u), x);
          },
          str: function(u) {
            return t[u];
          }
        };
      }
      function Yf(e, t, u) {
        var x = document.createElement("canvas");
        oe(x.style, {
          border: 0,
          margin: 0,
          padding: 0,
          top: 0,
          left: 0,
          width: "100%",
          height: "100%"
        }), e.appendChild(x), e === document.body && (x.style.position = "absolute", oe(e.style, {
          margin: 0,
          padding: 0
        }));
        function w() {
          var G = window.innerWidth, C = window.innerHeight;
          if (e !== document.body) {
            var I = x.getBoundingClientRect();
            G = I.right - I.left, C = I.bottom - I.top;
          }
          x.width = u * G, x.height = u * C;
        }
        var E;
        e !== document.body && typeof ResizeObserver == "function" ? (E = new ResizeObserver(function() {
          setTimeout(w);
        }), E.observe(e)) : window.addEventListener("resize", w, !1);
        function g() {
          E ? E.disconnect() : window.removeEventListener("resize", w), e.removeChild(x);
        }
        return w(), {
          canvas: x,
          onDestroy: g
        };
      }
      function qf(e, t) {
        function u(x) {
          try {
            return e.getContext(x, t);
          } catch {
            return null;
          }
        }
        return u("webgl") || u("experimental-webgl") || u("webgl-experimental");
      }
      function Qf(e) {
        return typeof e.nodeName == "string" && typeof e.appendChild == "function" && typeof e.getBoundingClientRect == "function";
      }
      function Kf(e) {
        return typeof e.drawArrays == "function" || typeof e.drawElements == "function";
      }
      function Aa(e) {
        return typeof e == "string" ? e.split() : (a(Array.isArray(e), "invalid extension array"), e);
      }
      function Ta(e) {
        return typeof e == "string" ? (a(typeof document < "u", "not supported outside of DOM"), document.querySelector(e)) : e;
      }
      function Zf(e) {
        var t = e || {}, u, x, w, E, g = {}, G = [], C = [], I = typeof window > "u" ? 1 : window.devicePixelRatio, k = !1, P = function(B) {
          B && a.raise(B);
        }, z = function() {
        };
        if (typeof t == "string" ? (a(
          typeof document < "u",
          "selector queries only supported in DOM environments"
        ), u = document.querySelector(t), a(u, "invalid query string for element")) : typeof t == "object" ? Qf(t) ? u = t : Kf(t) ? (E = t, w = E.canvas) : (a.constructor(t), "gl" in t ? E = t.gl : "canvas" in t ? w = Ta(t.canvas) : "container" in t && (x = Ta(t.container)), "attributes" in t && (g = t.attributes, a.type(g, "object", "invalid context attributes")), "extensions" in t && (G = Aa(t.extensions)), "optionalExtensions" in t && (C = Aa(t.optionalExtensions)), "onDone" in t && (a.type(
          t.onDone,
          "function",
          "invalid or missing onDone callback"
        ), P = t.onDone), "profile" in t && (k = !!t.profile), "pixelRatio" in t && (I = +t.pixelRatio, a(I > 0, "invalid pixel ratio"))) : a.raise("invalid arguments to regl"), u && (u.nodeName.toLowerCase() === "canvas" ? w = u : x = u), !E) {
          if (!w) {
            a(
              typeof document < "u",
              "must manually specify webgl context outside of DOM environments"
            );
            var D = Yf(x || document.body, P, I);
            if (!D)
              return null;
            w = D.canvas, z = D.onDestroy;
          }
          g.premultipliedAlpha === void 0 && (g.premultipliedAlpha = !0), E = qf(w, g);
        }
        return E ? {
          gl: E,
          canvas: w,
          container: x,
          extensions: G,
          optionalExtensions: C,
          pixelRatio: I,
          profile: k,
          onDone: P,
          onDestroy: z
        } : (z(), P("webgl not supported, try upgrading your browser or graphics drivers http://get.webgl.org"), null);
      }
      function Jf(e, t) {
        var u = {};
        function x(g) {
          a.type(g, "string", "extension name must be string");
          var G = g.toLowerCase(), C;
          try {
            C = u[G] = e.getExtension(G);
          } catch {
          }
          return !!C;
        }
        for (var w = 0; w < t.extensions.length; ++w) {
          var E = t.extensions[w];
          if (!x(E))
            return t.onDestroy(), t.onDone('"' + E + '" extension is not supported by the current WebGL context, try upgrading your system or a different browser'), null;
        }
        return t.optionalExtensions.forEach(x), {
          extensions: u,
          restore: function() {
            Object.keys(u).forEach(function(g) {
              if (u[g] && !x(g))
                throw new Error("(regl): error restoring extension " + g);
            });
          }
        };
      }
      function ir(e, t) {
        for (var u = Array(e), x = 0; x < e; ++x)
          u[x] = t(x);
        return u;
      }
      var eo = 5120, ro = 5121, to = 5122, no = 5123, ao = 5124, io = 5125, fo = 5126;
      function oo(e) {
        for (var t = 16; t <= 1 << 28; t *= 16)
          if (e <= t)
            return t;
        return 0;
      }
      function ga(e) {
        var t, u;
        return t = (e > 65535) << 4, e >>>= t, u = (e > 255) << 3, e >>>= u, t |= u, u = (e > 15) << 2, e >>>= u, t |= u, u = (e > 3) << 1, e >>>= u, t |= u, t | e >> 1;
      }
      function Sa() {
        var e = ir(8, function() {
          return [];
        });
        function t(E) {
          var g = oo(E), G = e[ga(g) >> 2];
          return G.length > 0 ? G.pop() : new ArrayBuffer(g);
        }
        function u(E) {
          e[ga(E.byteLength) >> 2].push(E);
        }
        function x(E, g) {
          var G = null;
          switch (E) {
            case eo:
              G = new Int8Array(t(g), 0, g);
              break;
            case ro:
              G = new Uint8Array(t(g), 0, g);
              break;
            case to:
              G = new Int16Array(t(2 * g), 0, g);
              break;
            case no:
              G = new Uint16Array(t(2 * g), 0, g);
              break;
            case ao:
              G = new Int32Array(t(4 * g), 0, g);
              break;
            case io:
              G = new Uint32Array(t(4 * g), 0, g);
              break;
            case fo:
              G = new Float32Array(t(4 * g), 0, g);
              break;
            default:
              return null;
          }
          return G.length !== g ? G.subarray(0, g) : G;
        }
        function w(E) {
          u(E.buffer);
        }
        return {
          alloc: t,
          free: u,
          allocType: x,
          freeType: w
        };
      }
      var ke = Sa();
      ke.zero = Sa();
      var uo = 3408, so = 3410, co = 3411, lo = 3412, mo = 3413, ho = 3414, vo = 3415, po = 33901, _o = 33902, bo = 3379, yo = 3386, Eo = 34921, xo = 36347, Ao = 36348, To = 35661, go = 35660, So = 34930, wo = 36349, Lo = 34076, Ro = 34024, Oo = 7936, Co = 7937, Go = 7938, Do = 35724, Fo = 34047, No = 36063, Bo = 34852, Gt = 3553, wa = 34067, Io = 34069, Po = 33984, lt = 6408, mn = 5126, La = 5121, hn = 36160, ko = 36053, Mo = 36064, Uo = 16384, Vo = function(e, t) {
        var u = 1;
        t.ext_texture_filter_anisotropic && (u = e.getParameter(Fo));
        var x = 1, w = 1;
        t.webgl_draw_buffers && (x = e.getParameter(Bo), w = e.getParameter(No));
        var E = !!t.oes_texture_float;
        if (E) {
          var g = e.createTexture();
          e.bindTexture(Gt, g), e.texImage2D(Gt, 0, lt, 1, 1, 0, lt, mn, null);
          var G = e.createFramebuffer();
          if (e.bindFramebuffer(hn, G), e.framebufferTexture2D(hn, Mo, Gt, g, 0), e.bindTexture(Gt, null), e.checkFramebufferStatus(hn) !== ko) E = !1;
          else {
            e.viewport(0, 0, 1, 1), e.clearColor(1, 0, 0, 1), e.clear(Uo);
            var C = ke.allocType(mn, 4);
            e.readPixels(0, 0, 1, 1, lt, mn, C), e.getError() ? E = !1 : (e.deleteFramebuffer(G), e.deleteTexture(g), E = C[0] === 1), ke.freeType(C);
          }
        }
        var I = typeof navigator < "u" && (/MSIE/.test(navigator.userAgent) || /Trident\//.test(navigator.appVersion) || /Edge/.test(navigator.userAgent)), k = !0;
        if (!I) {
          var P = e.createTexture(), z = ke.allocType(La, 36);
          e.activeTexture(Po), e.bindTexture(wa, P), e.texImage2D(Io, 0, lt, 3, 3, 0, lt, La, z), ke.freeType(z), e.bindTexture(wa, null), e.deleteTexture(P), k = !e.getError();
        }
        return {
          // drawing buffer bit depth
          colorBits: [
            e.getParameter(so),
            e.getParameter(co),
            e.getParameter(lo),
            e.getParameter(mo)
          ],
          depthBits: e.getParameter(ho),
          stencilBits: e.getParameter(vo),
          subpixelBits: e.getParameter(uo),
          // supported extensions
          extensions: Object.keys(t).filter(function(D) {
            return !!t[D];
          }),
          // max aniso samples
          maxAnisotropic: u,
          // max draw buffers
          maxDrawbuffers: x,
          maxColorAttachments: w,
          // point and line size ranges
          pointSizeDims: e.getParameter(po),
          lineWidthDims: e.getParameter(_o),
          maxViewportDims: e.getParameter(yo),
          maxCombinedTextureUnits: e.getParameter(To),
          maxCubeMapSize: e.getParameter(Lo),
          maxRenderbufferSize: e.getParameter(Ro),
          maxTextureUnits: e.getParameter(So),
          maxTextureSize: e.getParameter(bo),
          maxAttributes: e.getParameter(Eo),
          maxVertexUniforms: e.getParameter(xo),
          maxVertexTextureUnits: e.getParameter(go),
          maxVaryingVectors: e.getParameter(Ao),
          maxFragmentUniforms: e.getParameter(wo),
          // vendor info
          glsl: e.getParameter(Do),
          renderer: e.getParameter(Co),
          vendor: e.getParameter(Oo),
          version: e.getParameter(Go),
          // quirks
          readFloat: E,
          npotTextureCube: k
        };
      };
      function cr(e) {
        return !!e && typeof e == "object" && Array.isArray(e.shape) && Array.isArray(e.stride) && typeof e.offset == "number" && e.shape.length === e.stride.length && (Array.isArray(e.data) || fe(e.data));
      }
      var fr = function(e) {
        return Object.keys(e).map(function(t) {
          return e[t];
        });
      }, Dt = {
        shape: $o,
        flatten: jo
      };
      function zo(e, t, u) {
        for (var x = 0; x < t; ++x)
          u[x] = e[x];
      }
      function Ho(e, t, u, x) {
        for (var w = 0, E = 0; E < t; ++E)
          for (var g = e[E], G = 0; G < u; ++G)
            x[w++] = g[G];
      }
      function Ra(e, t, u, x, w, E) {
        for (var g = E, G = 0; G < t; ++G)
          for (var C = e[G], I = 0; I < u; ++I)
            for (var k = C[I], P = 0; P < x; ++P)
              w[g++] = k[P];
      }
      function Oa(e, t, u, x, w) {
        for (var E = 1, g = u + 1; g < t.length; ++g)
          E *= t[g];
        var G = t[u];
        if (t.length - u === 4) {
          var C = t[u + 1], I = t[u + 2], k = t[u + 3];
          for (g = 0; g < G; ++g)
            Ra(e[g], C, I, k, x, w), w += E;
        } else
          for (g = 0; g < G; ++g)
            Oa(e[g], t, u + 1, x, w), w += E;
      }
      function jo(e, t, u, x) {
        var w = 1;
        if (t.length)
          for (var E = 0; E < t.length; ++E)
            w *= t[E];
        else
          w = 0;
        var g = x || ke.allocType(u, w);
        switch (t.length) {
          case 0:
            break;
          case 1:
            zo(e, t[0], g);
            break;
          case 2:
            Ho(e, t[0], t[1], g);
            break;
          case 3:
            Ra(e, t[0], t[1], t[2], g, 0);
            break;
          default:
            Oa(e, t, 0, g, 0);
        }
        return g;
      }
      function $o(e) {
        for (var t = [], u = e; u.length; u = u[0])
          t.push(u.length);
        return t;
      }
      var vn = {
        "[object Int8Array]": 5120,
        "[object Int16Array]": 5122,
        "[object Int32Array]": 5124,
        "[object Uint8Array]": 5121,
        "[object Uint8ClampedArray]": 5121,
        "[object Uint16Array]": 5123,
        "[object Uint32Array]": 5125,
        "[object Float32Array]": 5126,
        "[object Float64Array]": 5121,
        "[object ArrayBuffer]": 5121
      }, Xo = 5120, Wo = 5122, Yo = 5124, qo = 5121, Qo = 5123, Ko = 5125, Zo = 5126, Jo = 5126, Nr = {
        int8: Xo,
        int16: Wo,
        int32: Yo,
        uint8: qo,
        uint16: Qo,
        uint32: Ko,
        float: Zo,
        float32: Jo
      }, eu = 35048, ru = 35040, Ft = {
        dynamic: eu,
        stream: ru,
        static: 35044
      }, pn = Dt.flatten, Ca = Dt.shape, Ga = 35044, tu = 35040, _n = 5121, bn = 5126, wr = [];
      wr[5120] = 1, wr[5122] = 2, wr[5124] = 4, wr[5121] = 1, wr[5123] = 2, wr[5125] = 4, wr[5126] = 4;
      function Nt(e) {
        return vn[Object.prototype.toString.call(e)] | 0;
      }
      function Da(e, t) {
        for (var u = 0; u < t.length; ++u)
          e[u] = t[u];
      }
      function Fa(e, t, u, x, w, E, g) {
        for (var G = 0, C = 0; C < u; ++C)
          for (var I = 0; I < x; ++I)
            e[G++] = t[w * C + E * I + g];
      }
      function nu(e, t, u, x) {
        var w = 0, E = {};
        function g(v) {
          this.id = w++, this.buffer = e.createBuffer(), this.type = v, this.usage = Ga, this.byteLength = 0, this.dimension = 1, this.dtype = _n, this.persistentData = null, u.profile && (this.stats = { size: 0 });
        }
        g.prototype.bind = function() {
          e.bindBuffer(this.type, this.buffer);
        }, g.prototype.destroy = function() {
          z(this);
        };
        var G = [];
        function C(v, T) {
          var N = G.pop();
          return N || (N = new g(v)), N.bind(), P(N, T, tu, 0, 1, !1), N;
        }
        function I(v) {
          G.push(v);
        }
        function k(v, T, N) {
          v.byteLength = T.byteLength, e.bufferData(v.type, T, N);
        }
        function P(v, T, N, Z, O, Q) {
          var W;
          if (v.usage = N, Array.isArray(T)) {
            if (v.dtype = Z || bn, T.length > 0) {
              var ue;
              if (Array.isArray(T[0])) {
                W = Ca(T);
                for (var L = 1, S = 1; S < W.length; ++S)
                  L *= W[S];
                v.dimension = L, ue = pn(T, W, v.dtype), k(v, ue, N), Q ? v.persistentData = ue : ke.freeType(ue);
              } else if (typeof T[0] == "number") {
                v.dimension = O;
                var re = ke.allocType(v.dtype, T.length);
                Da(re, T), k(v, re, N), Q ? v.persistentData = re : ke.freeType(re);
              } else fe(T[0]) ? (v.dimension = T[0].length, v.dtype = Z || Nt(T[0]) || bn, ue = pn(
                T,
                [T.length, T[0].length],
                v.dtype
              ), k(v, ue, N), Q ? v.persistentData = ue : ke.freeType(ue)) : a.raise("invalid buffer data");
            }
          } else if (fe(T))
            v.dtype = Z || Nt(T), v.dimension = O, k(v, T, N), Q && (v.persistentData = new Uint8Array(new Uint8Array(T.buffer)));
          else if (cr(T)) {
            W = T.shape;
            var H = T.stride, F = T.offset, $ = 0, X = 0, ve = 0, de = 0;
            W.length === 1 ? ($ = W[0], X = 1, ve = H[0], de = 0) : W.length === 2 ? ($ = W[0], X = W[1], ve = H[0], de = H[1]) : a.raise("invalid shape"), v.dtype = Z || Nt(T.data) || bn, v.dimension = X;
            var Y = ke.allocType(v.dtype, $ * X);
            Fa(
              Y,
              T.data,
              $,
              X,
              ve,
              de,
              F
            ), k(v, Y, N), Q ? v.persistentData = Y : ke.freeType(Y);
          } else T instanceof ArrayBuffer ? (v.dtype = _n, v.dimension = O, k(v, T, N), Q && (v.persistentData = new Uint8Array(new Uint8Array(T)))) : a.raise("invalid buffer data");
        }
        function z(v) {
          t.bufferCount--, x(v);
          var T = v.buffer;
          a(T, "buffer must not be deleted already"), e.deleteBuffer(T), v.buffer = null, delete E[v.id];
        }
        function D(v, T, N, Z) {
          t.bufferCount++;
          var O = new g(T);
          E[O.id] = O;
          function Q(L) {
            var S = Ga, re = null, H = 0, F = 0, $ = 1;
            return Array.isArray(L) || fe(L) || cr(L) || L instanceof ArrayBuffer ? re = L : typeof L == "number" ? H = L | 0 : L && (a.type(
              L,
              "object",
              "buffer arguments must be an object, a number or an array"
            ), "data" in L && (a(
              re === null || Array.isArray(re) || fe(re) || cr(re),
              "invalid data for buffer"
            ), re = L.data), "usage" in L && (a.parameter(L.usage, Ft, "invalid buffer usage"), S = Ft[L.usage]), "type" in L && (a.parameter(L.type, Nr, "invalid buffer type"), F = Nr[L.type]), "dimension" in L && (a.type(L.dimension, "number", "invalid dimension"), $ = L.dimension | 0), "length" in L && (a.nni(H, "buffer length must be a nonnegative integer"), H = L.length | 0)), O.bind(), re ? P(O, re, S, F, $, Z) : (H && e.bufferData(O.type, H, S), O.dtype = F || _n, O.usage = S, O.dimension = $, O.byteLength = H), u.profile && (O.stats.size = O.byteLength * wr[O.dtype]), Q;
          }
          function W(L, S) {
            a(
              S + L.byteLength <= O.byteLength,
              "invalid buffer subdata call, buffer is too small.  Can't write data of size " + L.byteLength + " starting from offset " + S + " to a buffer of size " + O.byteLength
            ), e.bufferSubData(O.type, S, L);
          }
          function ue(L, S) {
            var re = (S || 0) | 0, H;
            if (O.bind(), fe(L) || L instanceof ArrayBuffer)
              W(L, re);
            else if (Array.isArray(L)) {
              if (L.length > 0)
                if (typeof L[0] == "number") {
                  var F = ke.allocType(O.dtype, L.length);
                  Da(F, L), W(F, re), ke.freeType(F);
                } else if (Array.isArray(L[0]) || fe(L[0])) {
                  H = Ca(L);
                  var $ = pn(L, H, O.dtype);
                  W($, re), ke.freeType($);
                } else
                  a.raise("invalid buffer data");
            } else if (cr(L)) {
              H = L.shape;
              var X = L.stride, ve = 0, de = 0, Y = 0, K = 0;
              H.length === 1 ? (ve = H[0], de = 1, Y = X[0], K = 0) : H.length === 2 ? (ve = H[0], de = H[1], Y = X[0], K = X[1]) : a.raise("invalid shape");
              var ce = Array.isArray(L.data) ? O.dtype : Nt(L.data), he = ke.allocType(ce, ve * de);
              Fa(
                he,
                L.data,
                ve,
                de,
                Y,
                K,
                L.offset
              ), W(he, re), ke.freeType(he);
            } else
              a.raise("invalid data for buffer subdata");
            return Q;
          }
          return N || Q(v), Q._reglType = "buffer", Q._buffer = O, Q.subdata = ue, u.profile && (Q.stats = O.stats), Q.destroy = function() {
            z(O);
          }, Q;
        }
        function B() {
          fr(E).forEach(function(v) {
            v.buffer = e.createBuffer(), e.bindBuffer(v.type, v.buffer), e.bufferData(
              v.type,
              v.persistentData || v.byteLength,
              v.usage
            );
          });
        }
        return u.profile && (t.getTotalBufferSize = function() {
          var v = 0;
          return Object.keys(E).forEach(function(T) {
            v += E[T].stats.size;
          }), v;
        }), {
          create: D,
          createStream: C,
          destroyStream: I,
          clear: function() {
            fr(E).forEach(z), G.forEach(z);
          },
          getBuffer: function(v) {
            return v && v._buffer instanceof g ? v._buffer : null;
          },
          restore: B,
          _initBuffer: P
        };
      }
      var au = 0, iu = 0, fu = 1, ou = 1, uu = 4, su = 4, Lr = {
        points: au,
        point: iu,
        lines: fu,
        line: ou,
        triangles: uu,
        triangle: su,
        "line loop": 2,
        "line strip": 3,
        "triangle strip": 5,
        "triangle fan": 6
      }, cu = 0, lu = 1, dt = 4, du = 5120, qr = 5121, Na = 5122, Qr = 5123, Ba = 5124, Br = 5125, yn = 34963, mu = 35040, hu = 35044;
      function vu(e, t, u, x) {
        var w = {}, E = 0, g = {
          uint8: qr,
          uint16: Qr
        };
        t.oes_element_index_uint && (g.uint32 = Br);
        function G(B) {
          this.id = E++, w[this.id] = this, this.buffer = B, this.primType = dt, this.vertCount = 0, this.type = 0;
        }
        G.prototype.bind = function() {
          this.buffer.bind();
        };
        var C = [];
        function I(B) {
          var v = C.pop();
          return v || (v = new G(u.create(
            null,
            yn,
            !0,
            !1
          )._buffer)), P(v, B, mu, -1, -1, 0, 0), v;
        }
        function k(B) {
          C.push(B);
        }
        function P(B, v, T, N, Z, O, Q) {
          B.buffer.bind();
          var W;
          if (v) {
            var ue = Q;
            !Q && (!fe(v) || cr(v) && !fe(v.data)) && (ue = t.oes_element_index_uint ? Br : Qr), u._initBuffer(
              B.buffer,
              v,
              T,
              ue,
              3
            );
          } else
            e.bufferData(yn, O, T), B.buffer.dtype = W || qr, B.buffer.usage = T, B.buffer.dimension = 3, B.buffer.byteLength = O;
          if (W = Q, !Q) {
            switch (B.buffer.dtype) {
              case qr:
              case du:
                W = qr;
                break;
              case Qr:
              case Na:
                W = Qr;
                break;
              case Br:
              case Ba:
                W = Br;
                break;
              default:
                a.raise("unsupported type for element array");
            }
            B.buffer.dtype = W;
          }
          B.type = W, a(
            W !== Br || !!t.oes_element_index_uint,
            "32 bit element buffers not supported, enable oes_element_index_uint first"
          );
          var L = Z;
          L < 0 && (L = B.buffer.byteLength, W === Qr ? L >>= 1 : W === Br && (L >>= 2)), B.vertCount = L;
          var S = N;
          if (N < 0) {
            S = dt;
            var re = B.buffer.dimension;
            re === 1 && (S = cu), re === 2 && (S = lu), re === 3 && (S = dt);
          }
          B.primType = S;
        }
        function z(B) {
          x.elementsCount--, a(B.buffer !== null, "must not double destroy elements"), delete w[B.id], B.buffer.destroy(), B.buffer = null;
        }
        function D(B, v) {
          var T = u.create(null, yn, !0), N = new G(T._buffer);
          x.elementsCount++;
          function Z(O) {
            if (!O)
              T(), N.primType = dt, N.vertCount = 0, N.type = qr;
            else if (typeof O == "number")
              T(O), N.primType = dt, N.vertCount = O | 0, N.type = qr;
            else {
              var Q = null, W = hu, ue = -1, L = -1, S = 0, re = 0;
              Array.isArray(O) || fe(O) || cr(O) ? Q = O : (a.type(O, "object", "invalid arguments for elements"), "data" in O && (Q = O.data, a(
                Array.isArray(Q) || fe(Q) || cr(Q),
                "invalid data for element buffer"
              )), "usage" in O && (a.parameter(
                O.usage,
                Ft,
                "invalid element buffer usage"
              ), W = Ft[O.usage]), "primitive" in O && (a.parameter(
                O.primitive,
                Lr,
                "invalid element buffer primitive"
              ), ue = Lr[O.primitive]), "count" in O && (a(
                typeof O.count == "number" && O.count >= 0,
                "invalid vertex count for elements"
              ), L = O.count | 0), "type" in O && (a.parameter(
                O.type,
                g,
                "invalid buffer type"
              ), re = g[O.type]), "length" in O ? S = O.length | 0 : (S = L, re === Qr || re === Na ? S *= 2 : (re === Br || re === Ba) && (S *= 4))), P(
                N,
                Q,
                W,
                ue,
                L,
                S,
                re
              );
            }
            return Z;
          }
          return Z(B), Z._reglType = "elements", Z._elements = N, Z.subdata = function(O, Q) {
            return T.subdata(O, Q), Z;
          }, Z.destroy = function() {
            z(N);
          }, Z;
        }
        return {
          create: D,
          createStream: I,
          destroyStream: k,
          getElements: function(B) {
            return typeof B == "function" && B._elements instanceof G ? B._elements : null;
          },
          clear: function() {
            fr(w).forEach(z);
          }
        };
      }
      var Ia = new Float32Array(1), pu = new Uint32Array(Ia.buffer), _u = 5123;
      function Pa(e) {
        for (var t = ke.allocType(_u, e.length), u = 0; u < e.length; ++u)
          if (isNaN(e[u]))
            t[u] = 65535;
          else if (e[u] === 1 / 0)
            t[u] = 31744;
          else if (e[u] === -1 / 0)
            t[u] = 64512;
          else {
            Ia[0] = e[u];
            var x = pu[0], w = x >>> 31 << 15, E = (x << 1 >>> 24) - 127, g = x >> 13 & 1023;
            if (E < -24)
              t[u] = w;
            else if (E < -14) {
              var G = -14 - E;
              t[u] = w + (g + 1024 >> G);
            } else E > 15 ? t[u] = w + 31744 : t[u] = w + (E + 15 << 10) + g;
          }
        return t;
      }
      function Ne(e) {
        return Array.isArray(e) || fe(e);
      }
      var ka = function(e) {
        return !(e & e - 1) && !!e;
      }, bu = 34467, vr = 3553, En = 34067, Bt = 34069, Ir = 6408, xn = 6406, It = 6407, mt = 6409, Pt = 6410, Ma = 32854, An = 32855, Ua = 36194, yu = 32819, Eu = 32820, xu = 33635, Au = 34042, Tn = 6402, kt = 34041, gn = 35904, Sn = 35906, Kr = 36193, wn = 33776, Ln = 33777, Rn = 33778, On = 33779, Va = 35986, za = 35987, Ha = 34798, ja = 35840, $a = 35841, Xa = 35842, Wa = 35843, Ya = 36196, Zr = 5121, Cn = 5123, Gn = 5125, ht = 5126, Tu = 10242, gu = 10243, Su = 10497, Dn = 33071, wu = 33648, Lu = 10240, Ru = 10241, Fn = 9728, Ou = 9729, Nn = 9984, qa = 9985, Qa = 9986, Bn = 9987, Cu = 33170, Mt = 4352, Gu = 4353, Du = 4354, Fu = 34046, Nu = 3317, Bu = 37440, Iu = 37441, Pu = 37443, Ka = 37444, vt = 33984, ku = [
        Nn,
        Qa,
        qa,
        Bn
      ], Ut = [
        0,
        mt,
        Pt,
        It,
        Ir
      ], or = {};
      or[mt] = or[xn] = or[Tn] = 1, or[kt] = or[Pt] = 2, or[It] = or[gn] = 3, or[Ir] = or[Sn] = 4;
      function Jr(e) {
        return "[object " + e + "]";
      }
      var Za = Jr("HTMLCanvasElement"), Ja = Jr("OffscreenCanvas"), ei = Jr("CanvasRenderingContext2D"), ri = Jr("ImageBitmap"), ti = Jr("HTMLImageElement"), ni = Jr("HTMLVideoElement"), Mu = Object.keys(vn).concat([
        Za,
        Ja,
        ei,
        ri,
        ti,
        ni
      ]), et = [];
      et[Zr] = 1, et[ht] = 4, et[Kr] = 2, et[Cn] = 2, et[Gn] = 4;
      var qe = [];
      qe[Ma] = 2, qe[An] = 2, qe[Ua] = 2, qe[kt] = 4, qe[wn] = 0.5, qe[Ln] = 0.5, qe[Rn] = 1, qe[On] = 1, qe[Va] = 0.5, qe[za] = 1, qe[Ha] = 1, qe[ja] = 0.5, qe[$a] = 0.25, qe[Xa] = 0.5, qe[Wa] = 0.25, qe[Ya] = 0.5;
      function ai(e) {
        return Array.isArray(e) && (e.length === 0 || typeof e[0] == "number");
      }
      function ii(e) {
        if (!Array.isArray(e))
          return !1;
        var t = e.length;
        return !(t === 0 || !Ne(e[0]));
      }
      function Pr(e) {
        return Object.prototype.toString.call(e);
      }
      function fi(e) {
        return Pr(e) === Za;
      }
      function oi(e) {
        return Pr(e) === Ja;
      }
      function Uu(e) {
        return Pr(e) === ei;
      }
      function Vu(e) {
        return Pr(e) === ri;
      }
      function zu(e) {
        return Pr(e) === ti;
      }
      function Hu(e) {
        return Pr(e) === ni;
      }
      function In(e) {
        if (!e)
          return !1;
        var t = Pr(e);
        return Mu.indexOf(t) >= 0 ? !0 : ai(e) || ii(e) || cr(e);
      }
      function ui(e) {
        return vn[Object.prototype.toString.call(e)] | 0;
      }
      function ju(e, t) {
        var u = t.length;
        switch (e.type) {
          case Zr:
          case Cn:
          case Gn:
          case ht:
            var x = ke.allocType(e.type, u);
            x.set(t), e.data = x;
            break;
          case Kr:
            e.data = Pa(t);
            break;
          default:
            a.raise("unsupported texture type, must specify a typed array");
        }
      }
      function si(e, t) {
        return ke.allocType(
          e.type === Kr ? ht : e.type,
          t
        );
      }
      function ci(e, t) {
        e.type === Kr ? (e.data = Pa(t), ke.freeType(t)) : e.data = t;
      }
      function $u(e, t, u, x, w, E) {
        for (var g = e.width, G = e.height, C = e.channels, I = g * G * C, k = si(e, I), P = 0, z = 0; z < G; ++z)
          for (var D = 0; D < g; ++D)
            for (var B = 0; B < C; ++B)
              k[P++] = t[u * D + x * z + w * B + E];
        ci(e, k);
      }
      function Vt(e, t, u, x, w, E) {
        var g;
        if (typeof qe[e] < "u" ? g = qe[e] : g = or[e] * et[t], E && (g *= 6), w) {
          for (var G = 0, C = u; C >= 1; )
            G += g * C * C, C /= 2;
          return G;
        } else
          return g * u * x;
      }
      function Xu(e, t, u, x, w, E, g) {
        var G = {
          "don't care": Mt,
          "dont care": Mt,
          nice: Du,
          fast: Gu
        }, C = {
          repeat: Su,
          clamp: Dn,
          mirror: wu
        }, I = {
          nearest: Fn,
          linear: Ou
        }, k = oe({
          mipmap: Bn,
          "nearest mipmap nearest": Nn,
          "linear mipmap nearest": qa,
          "nearest mipmap linear": Qa,
          "linear mipmap linear": Bn
        }, I), P = {
          none: 0,
          browser: Ka
        }, z = {
          uint8: Zr,
          rgba4: yu,
          rgb565: xu,
          "rgb5 a1": Eu
        }, D = {
          alpha: xn,
          luminance: mt,
          "luminance alpha": Pt,
          rgb: It,
          rgba: Ir,
          rgba4: Ma,
          "rgb5 a1": An,
          rgb565: Ua
        }, B = {};
        t.ext_srgb && (D.srgb = gn, D.srgba = Sn), t.oes_texture_float && (z.float32 = z.float = ht), t.oes_texture_half_float && (z.float16 = z["half float"] = Kr), t.webgl_depth_texture && (oe(D, {
          depth: Tn,
          "depth stencil": kt
        }), oe(z, {
          uint16: Cn,
          uint32: Gn,
          "depth stencil": Au
        })), t.webgl_compressed_texture_s3tc && oe(B, {
          "rgb s3tc dxt1": wn,
          "rgba s3tc dxt1": Ln,
          "rgba s3tc dxt3": Rn,
          "rgba s3tc dxt5": On
        }), t.webgl_compressed_texture_atc && oe(B, {
          "rgb atc": Va,
          "rgba atc explicit alpha": za,
          "rgba atc interpolated alpha": Ha
        }), t.webgl_compressed_texture_pvrtc && oe(B, {
          "rgb pvrtc 4bppv1": ja,
          "rgb pvrtc 2bppv1": $a,
          "rgba pvrtc 4bppv1": Xa,
          "rgba pvrtc 2bppv1": Wa
        }), t.webgl_compressed_texture_etc1 && (B["rgb etc1"] = Ya);
        var v = Array.prototype.slice.call(
          e.getParameter(bu)
        );
        Object.keys(B).forEach(function(o) {
          var A = B[o];
          v.indexOf(A) >= 0 && (D[o] = A);
        });
        var T = Object.keys(D);
        u.textureFormats = T;
        var N = [];
        Object.keys(D).forEach(function(o) {
          var A = D[o];
          N[A] = o;
        });
        var Z = [];
        Object.keys(z).forEach(function(o) {
          var A = z[o];
          Z[A] = o;
        });
        var O = [];
        Object.keys(I).forEach(function(o) {
          var A = I[o];
          O[A] = o;
        });
        var Q = [];
        Object.keys(k).forEach(function(o) {
          var A = k[o];
          Q[A] = o;
        });
        var W = [];
        Object.keys(C).forEach(function(o) {
          var A = C[o];
          W[A] = o;
        });
        var ue = T.reduce(function(o, A) {
          var y = D[A];
          return y === mt || y === xn || y === mt || y === Pt || y === Tn || y === kt || t.ext_srgb && (y === gn || y === Sn) ? o[y] = y : y === An || A.indexOf("rgba") >= 0 ? o[y] = Ir : o[y] = It, o;
        }, {});
        function L() {
          this.internalformat = Ir, this.format = Ir, this.type = Zr, this.compressed = !1, this.premultiplyAlpha = !1, this.flipY = !1, this.unpackAlignment = 1, this.colorSpace = Ka, this.width = 0, this.height = 0, this.channels = 0;
        }
        function S(o, A) {
          o.internalformat = A.internalformat, o.format = A.format, o.type = A.type, o.compressed = A.compressed, o.premultiplyAlpha = A.premultiplyAlpha, o.flipY = A.flipY, o.unpackAlignment = A.unpackAlignment, o.colorSpace = A.colorSpace, o.width = A.width, o.height = A.height, o.channels = A.channels;
        }
        function re(o, A) {
          if (!(typeof A != "object" || !A)) {
            if ("premultiplyAlpha" in A && (a.type(
              A.premultiplyAlpha,
              "boolean",
              "invalid premultiplyAlpha"
            ), o.premultiplyAlpha = A.premultiplyAlpha), "flipY" in A && (a.type(
              A.flipY,
              "boolean",
              "invalid texture flip"
            ), o.flipY = A.flipY), "alignment" in A && (a.oneOf(
              A.alignment,
              [1, 2, 4, 8],
              "invalid texture unpack alignment"
            ), o.unpackAlignment = A.alignment), "colorSpace" in A && (a.parameter(
              A.colorSpace,
              P,
              "invalid colorSpace"
            ), o.colorSpace = P[A.colorSpace]), "type" in A) {
              var y = A.type;
              a(
                t.oes_texture_float || !(y === "float" || y === "float32"),
                "you must enable the OES_texture_float extension in order to use floating point textures."
              ), a(
                t.oes_texture_half_float || !(y === "half float" || y === "float16"),
                "you must enable the OES_texture_half_float extension in order to use 16-bit floating point textures."
              ), a(
                t.webgl_depth_texture || !(y === "uint16" || y === "uint32" || y === "depth stencil"),
                "you must enable the WEBGL_depth_texture extension in order to use depth/stencil textures."
              ), a.parameter(
                y,
                z,
                "invalid texture type"
              ), o.type = z[y];
            }
            var ee = o.width, ye = o.height, i = o.channels, r = !1;
            "shape" in A ? (a(
              Array.isArray(A.shape) && A.shape.length >= 2,
              "shape must be an array"
            ), ee = A.shape[0], ye = A.shape[1], A.shape.length === 3 && (i = A.shape[2], a(i > 0 && i <= 4, "invalid number of channels"), r = !0), a(ee >= 0 && ee <= u.maxTextureSize, "invalid width"), a(ye >= 0 && ye <= u.maxTextureSize, "invalid height")) : ("radius" in A && (ee = ye = A.radius, a(ee >= 0 && ee <= u.maxTextureSize, "invalid radius")), "width" in A && (ee = A.width, a(ee >= 0 && ee <= u.maxTextureSize, "invalid width")), "height" in A && (ye = A.height, a(ye >= 0 && ye <= u.maxTextureSize, "invalid height")), "channels" in A && (i = A.channels, a(i > 0 && i <= 4, "invalid number of channels"), r = !0)), o.width = ee | 0, o.height = ye | 0, o.channels = i | 0;
            var c = !1;
            if ("format" in A) {
              var h = A.format;
              a(
                t.webgl_depth_texture || !(h === "depth" || h === "depth stencil"),
                "you must enable the WEBGL_depth_texture extension in order to use depth/stencil textures."
              ), a.parameter(
                h,
                D,
                "invalid texture format"
              );
              var _ = o.internalformat = D[h];
              o.format = ue[_], h in z && ("type" in A || (o.type = z[h])), h in B && (o.compressed = !0), c = !0;
            }
            !r && c ? o.channels = or[o.format] : r && !c ? o.channels !== Ut[o.format] && (o.format = o.internalformat = Ut[o.channels]) : c && r && a(
              o.channels === or[o.format],
              "number of channels inconsistent with specified format"
            );
          }
        }
        function H(o) {
          e.pixelStorei(Bu, o.flipY), e.pixelStorei(Iu, o.premultiplyAlpha), e.pixelStorei(Pu, o.colorSpace), e.pixelStorei(Nu, o.unpackAlignment);
        }
        function F() {
          L.call(this), this.xOffset = 0, this.yOffset = 0, this.data = null, this.needsFree = !1, this.element = null, this.needsCopy = !1;
        }
        function $(o, A) {
          var y = null;
          if (In(A) ? y = A : A && (a.type(A, "object", "invalid pixel data type"), re(o, A), "x" in A && (o.xOffset = A.x | 0), "y" in A && (o.yOffset = A.y | 0), In(A.data) && (y = A.data)), a(
            !o.compressed || y instanceof Uint8Array,
            "compressed texture data must be stored in a uint8array"
          ), A.copy) {
            a(!y, "can not specify copy and data field for the same texture");
            var ee = w.viewportWidth, ye = w.viewportHeight;
            o.width = o.width || ee - o.xOffset, o.height = o.height || ye - o.yOffset, o.needsCopy = !0, a(
              o.xOffset >= 0 && o.xOffset < ee && o.yOffset >= 0 && o.yOffset < ye && o.width > 0 && o.width <= ee && o.height > 0 && o.height <= ye,
              "copy texture read out of bounds"
            );
          } else if (!y)
            o.width = o.width || 1, o.height = o.height || 1, o.channels = o.channels || 4;
          else if (fe(y))
            o.channels = o.channels || 4, o.data = y, !("type" in A) && o.type === Zr && (o.type = ui(y));
          else if (ai(y))
            o.channels = o.channels || 4, ju(o, y), o.alignment = 1, o.needsFree = !0;
          else if (cr(y)) {
            var i = y.data;
            !Array.isArray(i) && o.type === Zr && (o.type = ui(i));
            var r = y.shape, c = y.stride, h, _, d, l, m, n;
            r.length === 3 ? (d = r[2], n = c[2]) : (a(r.length === 2, "invalid ndarray pixel data, must be 2 or 3D"), d = 1, n = 1), h = r[0], _ = r[1], l = c[0], m = c[1], o.alignment = 1, o.width = h, o.height = _, o.channels = d, o.format = o.internalformat = Ut[d], o.needsFree = !0, $u(o, i, l, m, n, y.offset);
          } else if (fi(y) || oi(y) || Uu(y))
            fi(y) || oi(y) ? o.element = y : o.element = y.canvas, o.width = o.element.width, o.height = o.element.height, o.channels = 4;
          else if (Vu(y))
            o.element = y, o.width = y.width, o.height = y.height, o.channels = 4;
          else if (zu(y))
            o.element = y, o.width = y.naturalWidth, o.height = y.naturalHeight, o.channels = 4;
          else if (Hu(y))
            o.element = y, o.width = y.videoWidth, o.height = y.videoHeight, o.channels = 4;
          else if (ii(y)) {
            var s = o.width || y[0].length, f = o.height || y.length, p = o.channels;
            Ne(y[0][0]) ? p = p || y[0][0].length : p = p || 1;
            for (var b = Dt.shape(y), R = 1, U = 0; U < b.length; ++U)
              R *= b[U];
            var V = si(o, R);
            Dt.flatten(y, b, "", V), ci(o, V), o.alignment = 1, o.width = s, o.height = f, o.channels = p, o.format = o.internalformat = Ut[p], o.needsFree = !0;
          }
          o.type === ht ? a(
            u.extensions.indexOf("oes_texture_float") >= 0,
            "oes_texture_float extension not enabled"
          ) : o.type === Kr && a(
            u.extensions.indexOf("oes_texture_half_float") >= 0,
            "oes_texture_half_float extension not enabled"
          );
        }
        function X(o, A, y) {
          var ee = o.element, ye = o.data, i = o.internalformat, r = o.format, c = o.type, h = o.width, _ = o.height;
          H(o), ee ? e.texImage2D(A, y, r, r, c, ee) : o.compressed ? e.compressedTexImage2D(A, y, i, h, _, 0, ye) : o.needsCopy ? (x(), e.copyTexImage2D(
            A,
            y,
            r,
            o.xOffset,
            o.yOffset,
            h,
            _,
            0
          )) : e.texImage2D(A, y, r, h, _, 0, r, c, ye || null);
        }
        function ve(o, A, y, ee, ye) {
          var i = o.element, r = o.data, c = o.internalformat, h = o.format, _ = o.type, d = o.width, l = o.height;
          H(o), i ? e.texSubImage2D(
            A,
            ye,
            y,
            ee,
            h,
            _,
            i
          ) : o.compressed ? e.compressedTexSubImage2D(
            A,
            ye,
            y,
            ee,
            c,
            d,
            l,
            r
          ) : o.needsCopy ? (x(), e.copyTexSubImage2D(
            A,
            ye,
            y,
            ee,
            o.xOffset,
            o.yOffset,
            d,
            l
          )) : e.texSubImage2D(
            A,
            ye,
            y,
            ee,
            d,
            l,
            h,
            _,
            r
          );
        }
        var de = [];
        function Y() {
          return de.pop() || new F();
        }
        function K(o) {
          o.needsFree && ke.freeType(o.data), F.call(o), de.push(o);
        }
        function ce() {
          L.call(this), this.genMipmaps = !1, this.mipmapHint = Mt, this.mipmask = 0, this.images = Array(16);
        }
        function he(o, A, y) {
          var ee = o.images[0] = Y();
          o.mipmask = 1, ee.width = o.width = A, ee.height = o.height = y, ee.channels = o.channels = 4;
        }
        function Ee(o, A) {
          var y = null;
          if (In(A))
            y = o.images[0] = Y(), S(y, o), $(y, A), o.mipmask = 1;
          else if (re(o, A), Array.isArray(A.mipmap))
            for (var ee = A.mipmap, ye = 0; ye < ee.length; ++ye)
              y = o.images[ye] = Y(), S(y, o), y.width >>= ye, y.height >>= ye, $(y, ee[ye]), o.mipmask |= 1 << ye;
          else
            y = o.images[0] = Y(), S(y, o), $(y, A), o.mipmask = 1;
          S(o, o.images[0]), o.compressed && (o.internalformat === wn || o.internalformat === Ln || o.internalformat === Rn || o.internalformat === On) && a(
            o.width % 4 === 0 && o.height % 4 === 0,
            "for compressed texture formats, mipmap level 0 must have width and height that are a multiple of 4"
          );
        }
        function De(o, A) {
          for (var y = o.images, ee = 0; ee < y.length; ++ee) {
            if (!y[ee])
              return;
            X(y[ee], A, ee);
          }
        }
        var Fe = [];
        function Te() {
          var o = Fe.pop() || new ce();
          L.call(o), o.mipmask = 0;
          for (var A = 0; A < 16; ++A)
            o.images[A] = null;
          return o;
        }
        function Ve(o) {
          for (var A = o.images, y = 0; y < A.length; ++y)
            A[y] && K(A[y]), A[y] = null;
          Fe.push(o);
        }
        function Ge() {
          this.minFilter = Fn, this.magFilter = Fn, this.wrapS = Dn, this.wrapT = Dn, this.anisotropic = 1, this.genMipmaps = !1, this.mipmapHint = Mt;
        }
        function Ue(o, A) {
          if ("min" in A) {
            var y = A.min;
            a.parameter(y, k), o.minFilter = k[y], ku.indexOf(o.minFilter) >= 0 && !("faces" in A) && (o.genMipmaps = !0);
          }
          if ("mag" in A) {
            var ee = A.mag;
            a.parameter(ee, I), o.magFilter = I[ee];
          }
          var ye = o.wrapS, i = o.wrapT;
          if ("wrap" in A) {
            var r = A.wrap;
            typeof r == "string" ? (a.parameter(r, C), ye = i = C[r]) : Array.isArray(r) && (a.parameter(r[0], C), a.parameter(r[1], C), ye = C[r[0]], i = C[r[1]]);
          } else {
            if ("wrapS" in A) {
              var c = A.wrapS;
              a.parameter(c, C), ye = C[c];
            }
            if ("wrapT" in A) {
              var h = A.wrapT;
              a.parameter(h, C), i = C[h];
            }
          }
          if (o.wrapS = ye, o.wrapT = i, "anisotropic" in A) {
            var _ = A.anisotropic;
            a(
              typeof _ == "number" && _ >= 1 && _ <= u.maxAnisotropic,
              "aniso samples must be between 1 and "
            ), o.anisotropic = A.anisotropic;
          }
          if ("mipmap" in A) {
            var d = !1;
            switch (typeof A.mipmap) {
              case "string":
                a.parameter(
                  A.mipmap,
                  G,
                  "invalid mipmap hint"
                ), o.mipmapHint = G[A.mipmap], o.genMipmaps = !0, d = !0;
                break;
              case "boolean":
                d = o.genMipmaps = A.mipmap;
                break;
              case "object":
                a(Array.isArray(A.mipmap), "invalid mipmap type"), o.genMipmaps = !1, d = !0;
                break;
              default:
                a.raise("invalid mipmap type");
            }
            d && !("min" in A) && (o.minFilter = Nn);
          }
        }
        function ze(o, A) {
          e.texParameteri(A, Ru, o.minFilter), e.texParameteri(A, Lu, o.magFilter), e.texParameteri(A, Tu, o.wrapS), e.texParameteri(A, gu, o.wrapT), t.ext_texture_filter_anisotropic && e.texParameteri(A, Fu, o.anisotropic), o.genMipmaps && (e.hint(Cu, o.mipmapHint), e.generateMipmap(A));
        }
        var He = 0, We = {}, Qe = u.maxTextureUnits, Be = Array(Qe).map(function() {
          return null;
        });
        function _e(o) {
          L.call(this), this.mipmask = 0, this.internalformat = Ir, this.id = He++, this.refCount = 1, this.target = o, this.texture = e.createTexture(), this.unit = -1, this.bindCount = 0, this.texInfo = new Ge(), g.profile && (this.stats = { size: 0 });
        }
        function Ke(o) {
          e.activeTexture(vt), e.bindTexture(o.target, o.texture);
        }
        function Re() {
          var o = Be[0];
          o ? e.bindTexture(o.target, o.texture) : e.bindTexture(vr, null);
        }
        function se(o) {
          var A = o.texture;
          a(A, "must not double destroy texture");
          var y = o.unit, ee = o.target;
          y >= 0 && (e.activeTexture(vt + y), e.bindTexture(ee, null), Be[y] = null), e.deleteTexture(A), o.texture = null, o.params = null, o.pixels = null, o.refCount = 0, delete We[o.id], E.textureCount--;
        }
        oe(_e.prototype, {
          bind: function() {
            var o = this;
            o.bindCount += 1;
            var A = o.unit;
            if (A < 0) {
              for (var y = 0; y < Qe; ++y) {
                var ee = Be[y];
                if (ee) {
                  if (ee.bindCount > 0)
                    continue;
                  ee.unit = -1;
                }
                Be[y] = o, A = y;
                break;
              }
              A >= Qe && a.raise("insufficient number of texture units"), g.profile && E.maxTextureUnits < A + 1 && (E.maxTextureUnits = A + 1), o.unit = A, e.activeTexture(vt + A), e.bindTexture(o.target, o.texture);
            }
            return A;
          },
          unbind: function() {
            this.bindCount -= 1;
          },
          decRef: function() {
            --this.refCount <= 0 && se(this);
          }
        });
        function xe(o, A) {
          var y = new _e(vr);
          We[y.id] = y, E.textureCount++;
          function ee(r, c) {
            var h = y.texInfo;
            Ge.call(h);
            var _ = Te();
            return typeof r == "number" ? typeof c == "number" ? he(_, r | 0, c | 0) : he(_, r | 0, r | 0) : r ? (a.type(r, "object", "invalid arguments to regl.texture"), Ue(h, r), Ee(_, r)) : he(_, 1, 1), h.genMipmaps && (_.mipmask = (_.width << 1) - 1), y.mipmask = _.mipmask, S(y, _), a.texture2D(h, _, u), y.internalformat = _.internalformat, ee.width = _.width, ee.height = _.height, Ke(y), De(_, vr), ze(h, vr), Re(), Ve(_), g.profile && (y.stats.size = Vt(
              y.internalformat,
              y.type,
              _.width,
              _.height,
              h.genMipmaps,
              !1
            )), ee.format = N[y.internalformat], ee.type = Z[y.type], ee.mag = O[h.magFilter], ee.min = Q[h.minFilter], ee.wrapS = W[h.wrapS], ee.wrapT = W[h.wrapT], ee;
          }
          function ye(r, c, h, _) {
            a(!!r, "must specify image data");
            var d = c | 0, l = h | 0, m = _ | 0, n = Y();
            return S(n, y), n.width = 0, n.height = 0, $(n, r), n.width = n.width || (y.width >> m) - d, n.height = n.height || (y.height >> m) - l, a(
              y.type === n.type && y.format === n.format && y.internalformat === n.internalformat,
              "incompatible format for texture.subimage"
            ), a(
              d >= 0 && l >= 0 && d + n.width <= y.width && l + n.height <= y.height,
              "texture.subimage write out of bounds"
            ), a(
              y.mipmask & 1 << m,
              "missing mipmap data"
            ), a(
              n.data || n.element || n.needsCopy,
              "missing image data"
            ), Ke(y), ve(n, vr, d, l, m), Re(), K(n), ee;
          }
          function i(r, c) {
            var h = r | 0, _ = c | 0 || h;
            if (h === y.width && _ === y.height)
              return ee;
            ee.width = y.width = h, ee.height = y.height = _, Ke(y);
            for (var d = 0; y.mipmask >> d; ++d) {
              var l = h >> d, m = _ >> d;
              if (!l || !m) break;
              e.texImage2D(
                vr,
                d,
                y.format,
                l,
                m,
                0,
                y.format,
                y.type,
                null
              );
            }
            return Re(), g.profile && (y.stats.size = Vt(
              y.internalformat,
              y.type,
              h,
              _,
              !1,
              !1
            )), ee;
          }
          return ee(o, A), ee.subimage = ye, ee.resize = i, ee._reglType = "texture2d", ee._texture = y, g.profile && (ee.stats = y.stats), ee.destroy = function() {
            y.decRef();
          }, ee;
        }
        function we(o, A, y, ee, ye, i) {
          var r = new _e(En);
          We[r.id] = r, E.cubeCount++;
          var c = new Array(6);
          function h(l, m, n, s, f, p) {
            var b, R = r.texInfo;
            for (Ge.call(R), b = 0; b < 6; ++b)
              c[b] = Te();
            if (typeof l == "number" || !l) {
              var U = l | 0 || 1;
              for (b = 0; b < 6; ++b)
                he(c[b], U, U);
            } else if (typeof l == "object")
              if (m)
                Ee(c[0], l), Ee(c[1], m), Ee(c[2], n), Ee(c[3], s), Ee(c[4], f), Ee(c[5], p);
              else if (Ue(R, l), re(r, l), "faces" in l) {
                var V = l.faces;
                for (a(
                  Array.isArray(V) && V.length === 6,
                  "cube faces must be a length 6 array"
                ), b = 0; b < 6; ++b)
                  a(
                    typeof V[b] == "object" && !!V[b],
                    "invalid input for cube map face"
                  ), S(c[b], r), Ee(c[b], V[b]);
              } else
                for (b = 0; b < 6; ++b)
                  Ee(c[b], l);
            else
              a.raise("invalid arguments to cube map");
            for (S(r, c[0]), a.optional(function() {
              u.npotTextureCube || a(ka(r.width) && ka(r.height), "your browser does not support non power or two texture dimensions");
            }), R.genMipmaps ? r.mipmask = (c[0].width << 1) - 1 : r.mipmask = c[0].mipmask, a.textureCube(r, R, c, u), r.internalformat = c[0].internalformat, h.width = c[0].width, h.height = c[0].height, Ke(r), b = 0; b < 6; ++b)
              De(c[b], Bt + b);
            for (ze(R, En), Re(), g.profile && (r.stats.size = Vt(
              r.internalformat,
              r.type,
              h.width,
              h.height,
              R.genMipmaps,
              !0
            )), h.format = N[r.internalformat], h.type = Z[r.type], h.mag = O[R.magFilter], h.min = Q[R.minFilter], h.wrapS = W[R.wrapS], h.wrapT = W[R.wrapT], b = 0; b < 6; ++b)
              Ve(c[b]);
            return h;
          }
          function _(l, m, n, s, f) {
            a(!!m, "must specify image data"), a(typeof l == "number" && l === (l | 0) && l >= 0 && l < 6, "invalid face");
            var p = n | 0, b = s | 0, R = f | 0, U = Y();
            return S(U, r), U.width = 0, U.height = 0, $(U, m), U.width = U.width || (r.width >> R) - p, U.height = U.height || (r.height >> R) - b, a(
              r.type === U.type && r.format === U.format && r.internalformat === U.internalformat,
              "incompatible format for texture.subimage"
            ), a(
              p >= 0 && b >= 0 && p + U.width <= r.width && b + U.height <= r.height,
              "texture.subimage write out of bounds"
            ), a(
              r.mipmask & 1 << R,
              "missing mipmap data"
            ), a(
              U.data || U.element || U.needsCopy,
              "missing image data"
            ), Ke(r), ve(U, Bt + l, p, b, R), Re(), K(U), h;
          }
          function d(l) {
            var m = l | 0;
            if (m !== r.width) {
              h.width = r.width = m, h.height = r.height = m, Ke(r);
              for (var n = 0; n < 6; ++n)
                for (var s = 0; r.mipmask >> s; ++s)
                  e.texImage2D(
                    Bt + n,
                    s,
                    r.format,
                    m >> s,
                    m >> s,
                    0,
                    r.format,
                    r.type,
                    null
                  );
              return Re(), g.profile && (r.stats.size = Vt(
                r.internalformat,
                r.type,
                h.width,
                h.height,
                !1,
                !0
              )), h;
            }
          }
          return h(o, A, y, ee, ye, i), h.subimage = _, h.resize = d, h._reglType = "textureCube", h._texture = r, g.profile && (h.stats = r.stats), h.destroy = function() {
            r.decRef();
          }, h;
        }
        function Ie() {
          for (var o = 0; o < Qe; ++o)
            e.activeTexture(vt + o), e.bindTexture(vr, null), Be[o] = null;
          fr(We).forEach(se), E.cubeCount = 0, E.textureCount = 0;
        }
        g.profile && (E.getTotalTextureSize = function() {
          var o = 0;
          return Object.keys(We).forEach(function(A) {
            o += We[A].stats.size;
          }), o;
        });
        function _r() {
          for (var o = 0; o < Qe; ++o) {
            var A = Be[o];
            A && (A.bindCount = 0, A.unit = -1, Be[o] = null);
          }
          fr(We).forEach(function(y) {
            y.texture = e.createTexture(), e.bindTexture(y.target, y.texture);
            for (var ee = 0; ee < 32; ++ee)
              if ((y.mipmask & 1 << ee) !== 0)
                if (y.target === vr)
                  e.texImage2D(
                    vr,
                    ee,
                    y.internalformat,
                    y.width >> ee,
                    y.height >> ee,
                    0,
                    y.internalformat,
                    y.type,
                    null
                  );
                else
                  for (var ye = 0; ye < 6; ++ye)
                    e.texImage2D(
                      Bt + ye,
                      ee,
                      y.internalformat,
                      y.width >> ee,
                      y.height >> ee,
                      0,
                      y.internalformat,
                      y.type,
                      null
                    );
            ze(y.texInfo, y.target);
          });
        }
        function jr() {
          for (var o = 0; o < Qe; ++o) {
            var A = Be[o];
            A && (A.bindCount = 0, A.unit = -1, Be[o] = null), e.activeTexture(vt + o), e.bindTexture(vr, null), e.bindTexture(En, null);
          }
        }
        return {
          create2D: xe,
          createCube: we,
          clear: Ie,
          getTexture: function(o) {
            return null;
          },
          restore: _r,
          refresh: jr
        };
      }
      var Rr = 36161, zt = 32854, li = 32855, di = 36194, mi = 33189, hi = 36168, vi = 34041, pi = 35907, _i = 34836, bi = 34842, yi = 34843, lr = [];
      lr[zt] = 2, lr[li] = 2, lr[di] = 2, lr[mi] = 2, lr[hi] = 1, lr[vi] = 4, lr[pi] = 4, lr[_i] = 16, lr[bi] = 8, lr[yi] = 6;
      function Ei(e, t, u) {
        return lr[e] * t * u;
      }
      var Wu = function(e, t, u, x, w) {
        var E = {
          rgba4: zt,
          rgb565: di,
          "rgb5 a1": li,
          depth: mi,
          stencil: hi,
          "depth stencil": vi
        };
        t.ext_srgb && (E.srgba = pi), t.ext_color_buffer_half_float && (E.rgba16f = bi, E.rgb16f = yi), t.webgl_color_buffer_float && (E.rgba32f = _i);
        var g = [];
        Object.keys(E).forEach(function(D) {
          var B = E[D];
          g[B] = D;
        });
        var G = 0, C = {};
        function I(D) {
          this.id = G++, this.refCount = 1, this.renderbuffer = D, this.format = zt, this.width = 0, this.height = 0, w.profile && (this.stats = { size: 0 });
        }
        I.prototype.decRef = function() {
          --this.refCount <= 0 && k(this);
        };
        function k(D) {
          var B = D.renderbuffer;
          a(B, "must not double destroy renderbuffer"), e.bindRenderbuffer(Rr, null), e.deleteRenderbuffer(B), D.renderbuffer = null, D.refCount = 0, delete C[D.id], x.renderbufferCount--;
        }
        function P(D, B) {
          var v = new I(e.createRenderbuffer());
          C[v.id] = v, x.renderbufferCount++;
          function T(Z, O) {
            var Q = 0, W = 0, ue = zt;
            if (typeof Z == "object" && Z) {
              var L = Z;
              if ("shape" in L) {
                var S = L.shape;
                a(
                  Array.isArray(S) && S.length >= 2,
                  "invalid renderbuffer shape"
                ), Q = S[0] | 0, W = S[1] | 0;
              } else
                "radius" in L && (Q = W = L.radius | 0), "width" in L && (Q = L.width | 0), "height" in L && (W = L.height | 0);
              "format" in L && (a.parameter(
                L.format,
                E,
                "invalid renderbuffer format"
              ), ue = E[L.format]);
            } else typeof Z == "number" ? (Q = Z | 0, typeof O == "number" ? W = O | 0 : W = Q) : Z ? a.raise("invalid arguments to renderbuffer constructor") : Q = W = 1;
            if (a(
              Q > 0 && W > 0 && Q <= u.maxRenderbufferSize && W <= u.maxRenderbufferSize,
              "invalid renderbuffer size"
            ), !(Q === v.width && W === v.height && ue === v.format))
              return T.width = v.width = Q, T.height = v.height = W, v.format = ue, e.bindRenderbuffer(Rr, v.renderbuffer), e.renderbufferStorage(Rr, ue, Q, W), a(
                e.getError() === 0,
                "invalid render buffer format"
              ), w.profile && (v.stats.size = Ei(v.format, v.width, v.height)), T.format = g[v.format], T;
          }
          function N(Z, O) {
            var Q = Z | 0, W = O | 0 || Q;
            return Q === v.width && W === v.height || (a(
              Q > 0 && W > 0 && Q <= u.maxRenderbufferSize && W <= u.maxRenderbufferSize,
              "invalid renderbuffer size"
            ), T.width = v.width = Q, T.height = v.height = W, e.bindRenderbuffer(Rr, v.renderbuffer), e.renderbufferStorage(Rr, v.format, Q, W), a(
              e.getError() === 0,
              "invalid render buffer format"
            ), w.profile && (v.stats.size = Ei(
              v.format,
              v.width,
              v.height
            ))), T;
          }
          return T(D, B), T.resize = N, T._reglType = "renderbuffer", T._renderbuffer = v, w.profile && (T.stats = v.stats), T.destroy = function() {
            v.decRef();
          }, T;
        }
        w.profile && (x.getTotalRenderbufferSize = function() {
          var D = 0;
          return Object.keys(C).forEach(function(B) {
            D += C[B].stats.size;
          }), D;
        });
        function z() {
          fr(C).forEach(function(D) {
            D.renderbuffer = e.createRenderbuffer(), e.bindRenderbuffer(Rr, D.renderbuffer), e.renderbufferStorage(Rr, D.format, D.width, D.height);
          }), e.bindRenderbuffer(Rr, null);
        }
        return {
          create: P,
          clear: function() {
            fr(C).forEach(k);
          },
          restore: z
        };
      }, xr = 36160, Pn = 36161, kr = 3553, Ht = 34069, xi = 36064, Ai = 36096, Ti = 36128, gi = 33306, Si = 36053, Yu = 36054, qu = 36055, Qu = 36057, Ku = 36061, Zu = 36193, Ju = 5121, es = 5126, wi = 6407, Li = 6408, rs = 6402, ts = [
        wi,
        Li
      ], kn = [];
      kn[Li] = 4, kn[wi] = 3;
      var jt = [];
      jt[Ju] = 1, jt[es] = 4, jt[Zu] = 2;
      var ns = 32854, as = 32855, is = 36194, fs = 33189, os = 36168, Ri = 34041, us = 35907, ss = 34836, cs = 34842, ls = 34843, ds = [
        ns,
        as,
        is,
        us,
        cs,
        ls,
        ss
      ], rt = {};
      rt[Si] = "complete", rt[Yu] = "incomplete attachment", rt[Qu] = "incomplete dimensions", rt[qu] = "incomplete, missing attachment", rt[Ku] = "unsupported";
      function ms(e, t, u, x, w, E) {
        var g = {
          cur: null,
          next: null,
          dirty: !1,
          setFBO: null
        }, G = ["rgba"], C = ["rgba4", "rgb565", "rgb5 a1"];
        t.ext_srgb && C.push("srgba"), t.ext_color_buffer_half_float && C.push("rgba16f", "rgb16f"), t.webgl_color_buffer_float && C.push("rgba32f");
        var I = ["uint8"];
        t.oes_texture_half_float && I.push("half float", "float16"), t.oes_texture_float && I.push("float", "float32");
        function k(F, $, X) {
          this.target = F, this.texture = $, this.renderbuffer = X;
          var ve = 0, de = 0;
          $ ? (ve = $.width, de = $.height) : X && (ve = X.width, de = X.height), this.width = ve, this.height = de;
        }
        function P(F) {
          F && (F.texture && F.texture._texture.decRef(), F.renderbuffer && F.renderbuffer._renderbuffer.decRef());
        }
        function z(F, $, X) {
          if (F)
            if (F.texture) {
              var ve = F.texture._texture, de = Math.max(1, ve.width), Y = Math.max(1, ve.height);
              a(
                de === $ && Y === X,
                "inconsistent width/height for supplied texture"
              ), ve.refCount += 1;
            } else {
              var K = F.renderbuffer._renderbuffer;
              a(
                K.width === $ && K.height === X,
                "inconsistent width/height for renderbuffer"
              ), K.refCount += 1;
            }
        }
        function D(F, $) {
          $ && ($.texture ? e.framebufferTexture2D(
            xr,
            F,
            $.target,
            $.texture._texture.texture,
            0
          ) : e.framebufferRenderbuffer(
            xr,
            F,
            Pn,
            $.renderbuffer._renderbuffer.renderbuffer
          ));
        }
        function B(F) {
          var $ = kr, X = null, ve = null, de = F;
          typeof F == "object" && (de = F.data, "target" in F && ($ = F.target | 0)), a.type(de, "function", "invalid attachment data");
          var Y = de._reglType;
          return Y === "texture2d" ? (X = de, a($ === kr)) : Y === "textureCube" ? (X = de, a(
            $ >= Ht && $ < Ht + 6,
            "invalid cube map target"
          )) : Y === "renderbuffer" ? (ve = de, $ = Pn) : a.raise("invalid regl object for attachment"), new k($, X, ve);
        }
        function v(F, $, X, ve, de) {
          if (X) {
            var Y = x.create2D({
              width: F,
              height: $,
              format: ve,
              type: de
            });
            return Y._texture.refCount = 0, new k(kr, Y, null);
          } else {
            var K = w.create({
              width: F,
              height: $,
              format: ve
            });
            return K._renderbuffer.refCount = 0, new k(Pn, null, K);
          }
        }
        function T(F) {
          return F && (F.texture || F.renderbuffer);
        }
        function N(F, $, X) {
          F && (F.texture ? F.texture.resize($, X) : F.renderbuffer && F.renderbuffer.resize($, X), F.width = $, F.height = X);
        }
        var Z = 0, O = {};
        function Q() {
          this.id = Z++, O[this.id] = this, this.framebuffer = e.createFramebuffer(), this.width = 0, this.height = 0, this.colorAttachments = [], this.depthAttachment = null, this.stencilAttachment = null, this.depthStencilAttachment = null;
        }
        function W(F) {
          F.colorAttachments.forEach(P), P(F.depthAttachment), P(F.stencilAttachment), P(F.depthStencilAttachment);
        }
        function ue(F) {
          var $ = F.framebuffer;
          a($, "must not double destroy framebuffer"), e.deleteFramebuffer($), F.framebuffer = null, E.framebufferCount--, delete O[F.id];
        }
        function L(F) {
          var $;
          e.bindFramebuffer(xr, F.framebuffer);
          var X = F.colorAttachments;
          for ($ = 0; $ < X.length; ++$)
            D(xi + $, X[$]);
          for ($ = X.length; $ < u.maxColorAttachments; ++$)
            e.framebufferTexture2D(
              xr,
              xi + $,
              kr,
              null,
              0
            );
          e.framebufferTexture2D(
            xr,
            gi,
            kr,
            null,
            0
          ), e.framebufferTexture2D(
            xr,
            Ai,
            kr,
            null,
            0
          ), e.framebufferTexture2D(
            xr,
            Ti,
            kr,
            null,
            0
          ), D(Ai, F.depthAttachment), D(Ti, F.stencilAttachment), D(gi, F.depthStencilAttachment);
          var ve = e.checkFramebufferStatus(xr);
          !e.isContextLost() && ve !== Si && a.raise("framebuffer configuration not supported, status = " + rt[ve]), e.bindFramebuffer(xr, g.next ? g.next.framebuffer : null), g.cur = g.next, e.getError();
        }
        function S(F, $) {
          var X = new Q();
          E.framebufferCount++;
          function ve(Y, K) {
            var ce;
            a(
              g.next !== X,
              "can not update framebuffer which is currently in use"
            );
            var he = 0, Ee = 0, De = !0, Fe = !0, Te = null, Ve = !0, Ge = "rgba", Ue = "uint8", ze = 1, He = null, We = null, Qe = null, Be = !1;
            if (typeof Y == "number")
              he = Y | 0, Ee = K | 0 || he;
            else if (!Y)
              he = Ee = 1;
            else {
              a.type(Y, "object", "invalid arguments for framebuffer");
              var _e = Y;
              if ("shape" in _e) {
                var Ke = _e.shape;
                a(
                  Array.isArray(Ke) && Ke.length >= 2,
                  "invalid shape for framebuffer"
                ), he = Ke[0], Ee = Ke[1];
              } else
                "radius" in _e && (he = Ee = _e.radius), "width" in _e && (he = _e.width), "height" in _e && (Ee = _e.height);
              ("color" in _e || "colors" in _e) && (Te = _e.color || _e.colors, Array.isArray(Te) && a(
                Te.length === 1 || t.webgl_draw_buffers,
                "multiple render targets not supported"
              )), Te || ("colorCount" in _e && (ze = _e.colorCount | 0, a(ze > 0, "invalid color buffer count")), "colorTexture" in _e && (Ve = !!_e.colorTexture, Ge = "rgba4"), "colorType" in _e && (Ue = _e.colorType, Ve ? (a(
                t.oes_texture_float || !(Ue === "float" || Ue === "float32"),
                "you must enable OES_texture_float in order to use floating point framebuffer objects"
              ), a(
                t.oes_texture_half_float || !(Ue === "half float" || Ue === "float16"),
                "you must enable OES_texture_half_float in order to use 16-bit floating point framebuffer objects"
              )) : Ue === "half float" || Ue === "float16" ? (a(
                t.ext_color_buffer_half_float,
                "you must enable EXT_color_buffer_half_float to use 16-bit render buffers"
              ), Ge = "rgba16f") : (Ue === "float" || Ue === "float32") && (a(
                t.webgl_color_buffer_float,
                "you must enable WEBGL_color_buffer_float in order to use 32-bit floating point renderbuffers"
              ), Ge = "rgba32f"), a.oneOf(Ue, I, "invalid color type")), "colorFormat" in _e && (Ge = _e.colorFormat, G.indexOf(Ge) >= 0 ? Ve = !0 : C.indexOf(Ge) >= 0 ? Ve = !1 : a.optional(function() {
                Ve ? a.oneOf(
                  _e.colorFormat,
                  G,
                  "invalid color format for texture"
                ) : a.oneOf(
                  _e.colorFormat,
                  C,
                  "invalid color format for renderbuffer"
                );
              }))), ("depthTexture" in _e || "depthStencilTexture" in _e) && (Be = !!(_e.depthTexture || _e.depthStencilTexture), a(
                !Be || t.webgl_depth_texture,
                "webgl_depth_texture extension not supported"
              )), "depth" in _e && (typeof _e.depth == "boolean" ? De = _e.depth : (He = _e.depth, Fe = !1)), "stencil" in _e && (typeof _e.stencil == "boolean" ? Fe = _e.stencil : (We = _e.stencil, De = !1)), "depthStencil" in _e && (typeof _e.depthStencil == "boolean" ? De = Fe = _e.depthStencil : (Qe = _e.depthStencil, De = !1, Fe = !1));
            }
            var Re = null, se = null, xe = null, we = null;
            if (Array.isArray(Te))
              Re = Te.map(B);
            else if (Te)
              Re = [B(Te)];
            else
              for (Re = new Array(ze), ce = 0; ce < ze; ++ce)
                Re[ce] = v(
                  he,
                  Ee,
                  Ve,
                  Ge,
                  Ue
                );
            a(
              t.webgl_draw_buffers || Re.length <= 1,
              "you must enable the WEBGL_draw_buffers extension in order to use multiple color buffers."
            ), a(
              Re.length <= u.maxColorAttachments,
              "too many color attachments, not supported"
            ), he = he || Re[0].width, Ee = Ee || Re[0].height, He ? se = B(He) : De && !Fe && (se = v(
              he,
              Ee,
              Be,
              "depth",
              "uint32"
            )), We ? xe = B(We) : Fe && !De && (xe = v(
              he,
              Ee,
              !1,
              "stencil",
              "uint8"
            )), Qe ? we = B(Qe) : !He && !We && Fe && De && (we = v(
              he,
              Ee,
              Be,
              "depth stencil",
              "depth stencil"
            )), a(
              !!He + !!We + !!Qe <= 1,
              "invalid framebuffer configuration, can specify exactly one depth/stencil attachment"
            );
            var Ie = null;
            for (ce = 0; ce < Re.length; ++ce)
              if (z(Re[ce], he, Ee), a(
                !Re[ce] || Re[ce].texture && ts.indexOf(Re[ce].texture._texture.format) >= 0 || Re[ce].renderbuffer && ds.indexOf(Re[ce].renderbuffer._renderbuffer.format) >= 0,
                "framebuffer color attachment " + ce + " is invalid"
              ), Re[ce] && Re[ce].texture) {
                var _r = kn[Re[ce].texture._texture.format] * jt[Re[ce].texture._texture.type];
                Ie === null ? Ie = _r : a(
                  Ie === _r,
                  "all color attachments much have the same number of bits per pixel."
                );
              }
            return z(se, he, Ee), a(
              !se || se.texture && se.texture._texture.format === rs || se.renderbuffer && se.renderbuffer._renderbuffer.format === fs,
              "invalid depth attachment for framebuffer object"
            ), z(xe, he, Ee), a(
              !xe || xe.renderbuffer && xe.renderbuffer._renderbuffer.format === os,
              "invalid stencil attachment for framebuffer object"
            ), z(we, he, Ee), a(
              !we || we.texture && we.texture._texture.format === Ri || we.renderbuffer && we.renderbuffer._renderbuffer.format === Ri,
              "invalid depth-stencil attachment for framebuffer object"
            ), W(X), X.width = he, X.height = Ee, X.colorAttachments = Re, X.depthAttachment = se, X.stencilAttachment = xe, X.depthStencilAttachment = we, ve.color = Re.map(T), ve.depth = T(se), ve.stencil = T(xe), ve.depthStencil = T(we), ve.width = X.width, ve.height = X.height, L(X), ve;
          }
          function de(Y, K) {
            a(
              g.next !== X,
              "can not resize a framebuffer which is currently in use"
            );
            var ce = Math.max(Y | 0, 1), he = Math.max(K | 0 || ce, 1);
            if (ce === X.width && he === X.height)
              return ve;
            for (var Ee = X.colorAttachments, De = 0; De < Ee.length; ++De)
              N(Ee[De], ce, he);
            return N(X.depthAttachment, ce, he), N(X.stencilAttachment, ce, he), N(X.depthStencilAttachment, ce, he), X.width = ve.width = ce, X.height = ve.height = he, L(X), ve;
          }
          return ve(F, $), oe(ve, {
            resize: de,
            _reglType: "framebuffer",
            _framebuffer: X,
            destroy: function() {
              ue(X), W(X);
            },
            use: function(Y) {
              g.setFBO({
                framebuffer: ve
              }, Y);
            }
          });
        }
        function re(F) {
          var $ = Array(6);
          function X(de) {
            var Y;
            a(
              $.indexOf(g.next) < 0,
              "can not update framebuffer which is currently in use"
            );
            var K = {
              color: null
            }, ce = 0, he = null, Ee = "rgba", De = "uint8", Fe = 1;
            if (typeof de == "number")
              ce = de | 0;
            else if (!de)
              ce = 1;
            else {
              a.type(de, "object", "invalid arguments for framebuffer");
              var Te = de;
              if ("shape" in Te) {
                var Ve = Te.shape;
                a(
                  Array.isArray(Ve) && Ve.length >= 2,
                  "invalid shape for framebuffer"
                ), a(
                  Ve[0] === Ve[1],
                  "cube framebuffer must be square"
                ), ce = Ve[0];
              } else
                "radius" in Te && (ce = Te.radius | 0), "width" in Te ? (ce = Te.width | 0, "height" in Te && a(Te.height === ce, "must be square")) : "height" in Te && (ce = Te.height | 0);
              ("color" in Te || "colors" in Te) && (he = Te.color || Te.colors, Array.isArray(he) && a(
                he.length === 1 || t.webgl_draw_buffers,
                "multiple render targets not supported"
              )), he || ("colorCount" in Te && (Fe = Te.colorCount | 0, a(Fe > 0, "invalid color buffer count")), "colorType" in Te && (a.oneOf(
                Te.colorType,
                I,
                "invalid color type"
              ), De = Te.colorType), "colorFormat" in Te && (Ee = Te.colorFormat, a.oneOf(
                Te.colorFormat,
                G,
                "invalid color format for texture"
              ))), "depth" in Te && (K.depth = Te.depth), "stencil" in Te && (K.stencil = Te.stencil), "depthStencil" in Te && (K.depthStencil = Te.depthStencil);
            }
            var Ge;
            if (he)
              if (Array.isArray(he))
                for (Ge = [], Y = 0; Y < he.length; ++Y)
                  Ge[Y] = he[Y];
              else
                Ge = [he];
            else {
              Ge = Array(Fe);
              var Ue = {
                radius: ce,
                format: Ee,
                type: De
              };
              for (Y = 0; Y < Fe; ++Y)
                Ge[Y] = x.createCube(Ue);
            }
            for (K.color = Array(Ge.length), Y = 0; Y < Ge.length; ++Y) {
              var ze = Ge[Y];
              a(
                typeof ze == "function" && ze._reglType === "textureCube",
                "invalid cube map"
              ), ce = ce || ze.width, a(
                ze.width === ce && ze.height === ce,
                "invalid cube map shape"
              ), K.color[Y] = {
                target: Ht,
                data: Ge[Y]
              };
            }
            for (Y = 0; Y < 6; ++Y) {
              for (var He = 0; He < Ge.length; ++He)
                K.color[He].target = Ht + Y;
              Y > 0 && (K.depth = $[0].depth, K.stencil = $[0].stencil, K.depthStencil = $[0].depthStencil), $[Y] ? $[Y](K) : $[Y] = S(K);
            }
            return oe(X, {
              width: ce,
              height: ce,
              color: Ge
            });
          }
          function ve(de) {
            var Y, K = de | 0;
            if (a(
              K > 0 && K <= u.maxCubeMapSize,
              "invalid radius for cube fbo"
            ), K === X.width)
              return X;
            var ce = X.color;
            for (Y = 0; Y < ce.length; ++Y)
              ce[Y].resize(K);
            for (Y = 0; Y < 6; ++Y)
              $[Y].resize(K);
            return X.width = X.height = K, X;
          }
          return X(F), oe(X, {
            faces: $,
            resize: ve,
            _reglType: "framebufferCube",
            destroy: function() {
              $.forEach(function(de) {
                de.destroy();
              });
            }
          });
        }
        function H() {
          g.cur = null, g.next = null, g.dirty = !0, fr(O).forEach(function(F) {
            F.framebuffer = e.createFramebuffer(), L(F);
          });
        }
        return oe(g, {
          getFramebuffer: function(F) {
            if (typeof F == "function" && F._reglType === "framebuffer") {
              var $ = F._framebuffer;
              if ($ instanceof Q)
                return $;
            }
            return null;
          },
          create: S,
          createCube: re,
          clear: function() {
            fr(O).forEach(ue);
          },
          restore: H
        });
      }
      var hs = 5126, Oi = 34962, $t = 34963, Ci = [
        "attributes",
        "elements",
        "offset",
        "count",
        "primitive",
        "instances"
      ];
      function Mn() {
        this.state = 0, this.x = 0, this.y = 0, this.z = 0, this.w = 0, this.buffer = null, this.size = 0, this.normalized = !1, this.type = hs, this.offset = 0, this.stride = 0, this.divisor = 0;
      }
      function vs(e, t, u, x, w, E, g) {
        for (var G = u.maxAttributes, C = new Array(G), I = 0; I < G; ++I)
          C[I] = new Mn();
        var k = 0, P = {}, z = {
          Record: Mn,
          scope: {},
          state: C,
          currentVAO: null,
          targetVAO: null,
          restore: B() ? W : function() {
          },
          createVAO: ue,
          getVAO: T,
          destroyBuffer: D,
          setVAO: B() ? N : Z,
          clear: B() ? O : function() {
          }
        };
        function D(L) {
          for (var S = 0; S < C.length; ++S) {
            var re = C[S];
            re.buffer === L && (e.disableVertexAttribArray(S), re.buffer = null);
          }
        }
        function B() {
          return t.oes_vertex_array_object;
        }
        function v() {
          return t.angle_instanced_arrays;
        }
        function T(L) {
          return typeof L == "function" && L._vao ? L._vao : null;
        }
        function N(L) {
          if (L !== z.currentVAO) {
            var S = B();
            L ? S.bindVertexArrayOES(L.vao) : S.bindVertexArrayOES(null), z.currentVAO = L;
          }
        }
        function Z(L) {
          if (L !== z.currentVAO) {
            if (L)
              L.bindAttrs();
            else {
              for (var S = v(), re = 0; re < C.length; ++re) {
                var H = C[re];
                H.buffer ? (e.enableVertexAttribArray(re), H.buffer.bind(), e.vertexAttribPointer(re, H.size, H.type, H.normalized, H.stride, H.offfset), S && H.divisor && S.vertexAttribDivisorANGLE(re, H.divisor)) : (e.disableVertexAttribArray(re), e.vertexAttrib4f(re, H.x, H.y, H.z, H.w));
              }
              g.elements ? e.bindBuffer($t, g.elements.buffer.buffer) : e.bindBuffer($t, null);
            }
            z.currentVAO = L;
          }
        }
        function O() {
          fr(P).forEach(function(L) {
            L.destroy();
          });
        }
        function Q() {
          this.id = ++k, this.attributes = [], this.elements = null, this.ownsElements = !1, this.count = 0, this.offset = 0, this.instances = -1, this.primitive = 4;
          var L = B();
          L ? this.vao = L.createVertexArrayOES() : this.vao = null, P[this.id] = this, this.buffers = [];
        }
        Q.prototype.bindAttrs = function() {
          for (var L = v(), S = this.attributes, re = 0; re < S.length; ++re) {
            var H = S[re];
            H.buffer ? (e.enableVertexAttribArray(re), e.bindBuffer(Oi, H.buffer.buffer), e.vertexAttribPointer(re, H.size, H.type, H.normalized, H.stride, H.offset), L && H.divisor && L.vertexAttribDivisorANGLE(re, H.divisor)) : (e.disableVertexAttribArray(re), e.vertexAttrib4f(re, H.x, H.y, H.z, H.w));
          }
          for (var F = S.length; F < G; ++F)
            e.disableVertexAttribArray(F);
          var $ = E.getElements(this.elements);
          $ ? e.bindBuffer($t, $.buffer.buffer) : e.bindBuffer($t, null);
        }, Q.prototype.refresh = function() {
          var L = B();
          L && (L.bindVertexArrayOES(this.vao), this.bindAttrs(), z.currentVAO = null, L.bindVertexArrayOES(null));
        }, Q.prototype.destroy = function() {
          if (this.vao) {
            var L = B();
            this === z.currentVAO && (z.currentVAO = null, L.bindVertexArrayOES(null)), L.deleteVertexArrayOES(this.vao), this.vao = null;
          }
          this.ownsElements && (this.elements.destroy(), this.elements = null, this.ownsElements = !1), P[this.id] && (delete P[this.id], x.vaoCount -= 1);
        };
        function W() {
          var L = B();
          L && fr(P).forEach(function(S) {
            S.refresh();
          });
        }
        function ue(L) {
          var S = new Q();
          x.vaoCount += 1;
          function re(H) {
            var F;
            if (Array.isArray(H))
              F = H, S.elements && S.ownsElements && S.elements.destroy(), S.elements = null, S.ownsElements = !1, S.offset = 0, S.count = 0, S.instances = -1, S.primitive = 4;
            else {
              if (a(typeof H == "object", "invalid arguments for create vao"), a("attributes" in H, "must specify attributes for vao"), H.elements) {
                var $ = H.elements;
                S.ownsElements ? typeof $ == "function" && $._reglType === "elements" ? (S.elements.destroy(), S.ownsElements = !1) : (S.elements($), S.ownsElements = !1) : E.getElements(H.elements) ? (S.elements = H.elements, S.ownsElements = !1) : (S.elements = E.create(H.elements), S.ownsElements = !0);
              } else
                S.elements = null, S.ownsElements = !1;
              F = H.attributes, S.offset = 0, S.count = -1, S.instances = -1, S.primitive = 4, S.elements && (S.count = S.elements._elements.vertCount, S.primitive = S.elements._elements.primType), "offset" in H && (S.offset = H.offset | 0), "count" in H && (S.count = H.count | 0), "instances" in H && (S.instances = H.instances | 0), "primitive" in H && (a(H.primitive in Lr, "bad primitive type: " + H.primitive), S.primitive = Lr[H.primitive]), a.optional(() => {
                for (var De = Object.keys(H), Fe = 0; Fe < De.length; ++Fe)
                  a(Ci.indexOf(De[Fe]) >= 0, 'invalid option for vao: "' + De[Fe] + '" valid options are ' + Ci);
              }), a(Array.isArray(F), "attributes must be an array");
            }
            a(F.length < G, "too many attributes"), a(F.length > 0, "must specify at least one attribute");
            var X = {}, ve = S.attributes;
            ve.length = F.length;
            for (var de = 0; de < F.length; ++de) {
              var Y = F[de], K = ve[de] = new Mn(), ce = Y.data || Y;
              if (Array.isArray(ce) || fe(ce) || cr(ce)) {
                var he;
                S.buffers[de] && (he = S.buffers[de], fe(ce) && he._buffer.byteLength >= ce.byteLength ? he.subdata(ce) : (he.destroy(), S.buffers[de] = null)), S.buffers[de] || (he = S.buffers[de] = w.create(Y, Oi, !1, !0)), K.buffer = w.getBuffer(he), K.size = K.buffer.dimension | 0, K.normalized = !1, K.type = K.buffer.dtype, K.offset = 0, K.stride = 0, K.divisor = 0, K.state = 1, X[de] = 1;
              } else w.getBuffer(Y) ? (K.buffer = w.getBuffer(Y), K.size = K.buffer.dimension | 0, K.normalized = !1, K.type = K.buffer.dtype, K.offset = 0, K.stride = 0, K.divisor = 0, K.state = 1) : w.getBuffer(Y.buffer) ? (K.buffer = w.getBuffer(Y.buffer), K.size = (+Y.size || K.buffer.dimension) | 0, K.normalized = !!Y.normalized || !1, "type" in Y ? (a.parameter(Y.type, Nr, "invalid buffer type"), K.type = Nr[Y.type]) : K.type = K.buffer.dtype, K.offset = (Y.offset || 0) | 0, K.stride = (Y.stride || 0) | 0, K.divisor = (Y.divisor || 0) | 0, K.state = 1, a(K.size >= 1 && K.size <= 4, "size must be between 1 and 4"), a(K.offset >= 0, "invalid offset"), a(K.stride >= 0 && K.stride <= 255, "stride must be between 0 and 255"), a(K.divisor >= 0, "divisor must be positive"), a(!K.divisor || !!t.angle_instanced_arrays, "ANGLE_instanced_arrays must be enabled to use divisor")) : "x" in Y ? (a(de > 0, "first attribute must not be a constant"), K.x = +Y.x || 0, K.y = +Y.y || 0, K.z = +Y.z || 0, K.w = +Y.w || 0, K.state = 2) : a(!1, "invalid attribute spec for location " + de);
            }
            for (var Ee = 0; Ee < S.buffers.length; ++Ee)
              !X[Ee] && S.buffers[Ee] && (S.buffers[Ee].destroy(), S.buffers[Ee] = null);
            return S.refresh(), re;
          }
          return re.destroy = function() {
            for (var H = 0; H < S.buffers.length; ++H)
              S.buffers[H] && S.buffers[H].destroy();
            S.buffers.length = 0, S.ownsElements && (S.elements.destroy(), S.elements = null, S.ownsElements = !1), S.destroy();
          }, re._vao = S, re._reglType = "vao", re(L);
        }
        return z;
      }
      var Gi = 35632, ps = 35633, _s = 35718, bs = 35721;
      function ys(e, t, u, x) {
        var w = {}, E = {};
        function g(v, T, N, Z) {
          this.name = v, this.id = T, this.location = N, this.info = Z;
        }
        function G(v, T) {
          for (var N = 0; N < v.length; ++N)
            if (v[N].id === T.id) {
              v[N].location = T.location;
              return;
            }
          v.push(T);
        }
        function C(v, T, N) {
          var Z = v === Gi ? w : E, O = Z[T];
          if (!O) {
            var Q = t.str(T);
            O = e.createShader(v), e.shaderSource(O, Q), e.compileShader(O), a.shaderError(e, O, Q, v, N), Z[T] = O;
          }
          return O;
        }
        var I = {}, k = [], P = 0;
        function z(v, T) {
          this.id = P++, this.fragId = v, this.vertId = T, this.program = null, this.uniforms = [], this.attributes = [], this.refCount = 1, x.profile && (this.stats = {
            uniformsCount: 0,
            attributesCount: 0
          });
        }
        function D(v, T, N) {
          var Z, O, Q = C(Gi, v.fragId), W = C(ps, v.vertId), ue = v.program = e.createProgram();
          if (e.attachShader(ue, Q), e.attachShader(ue, W), N)
            for (Z = 0; Z < N.length; ++Z) {
              var L = N[Z];
              e.bindAttribLocation(ue, L[0], L[1]);
            }
          e.linkProgram(ue), a.linkError(
            e,
            ue,
            t.str(v.fragId),
            t.str(v.vertId),
            T
          );
          var S = e.getProgramParameter(ue, _s);
          x.profile && (v.stats.uniformsCount = S);
          var re = v.uniforms;
          for (Z = 0; Z < S; ++Z)
            if (O = e.getActiveUniform(ue, Z), O)
              if (O.size > 1)
                for (var H = 0; H < O.size; ++H) {
                  var F = O.name.replace("[0]", "[" + H + "]");
                  G(re, new g(
                    F,
                    t.id(F),
                    e.getUniformLocation(ue, F),
                    O
                  ));
                }
              else
                G(re, new g(
                  O.name,
                  t.id(O.name),
                  e.getUniformLocation(ue, O.name),
                  O
                ));
          var $ = e.getProgramParameter(ue, bs);
          x.profile && (v.stats.attributesCount = $);
          var X = v.attributes;
          for (Z = 0; Z < $; ++Z)
            O = e.getActiveAttrib(ue, Z), O && G(X, new g(
              O.name,
              t.id(O.name),
              e.getAttribLocation(ue, O.name),
              O
            ));
        }
        x.profile && (u.getMaxUniformsCount = function() {
          var v = 0;
          return k.forEach(function(T) {
            T.stats.uniformsCount > v && (v = T.stats.uniformsCount);
          }), v;
        }, u.getMaxAttributesCount = function() {
          var v = 0;
          return k.forEach(function(T) {
            T.stats.attributesCount > v && (v = T.stats.attributesCount);
          }), v;
        });
        function B() {
          w = {}, E = {};
          for (var v = 0; v < k.length; ++v)
            D(k[v], null, k[v].attributes.map(function(T) {
              return [T.location, T.name];
            }));
        }
        return {
          clear: function() {
            var v = e.deleteShader.bind(e);
            fr(w).forEach(v), w = {}, fr(E).forEach(v), E = {}, k.forEach(function(T) {
              e.deleteProgram(T.program);
            }), k.length = 0, I = {}, u.shaderCount = 0;
          },
          program: function(v, T, N, Z) {
            a.command(v >= 0, "missing vertex shader", N), a.command(T >= 0, "missing fragment shader", N);
            var O = I[T];
            O || (O = I[T] = {});
            var Q = O[v];
            if (Q && (Q.refCount++, !Z))
              return Q;
            var W = new z(T, v);
            return u.shaderCount++, D(W, N, Z), Q || (O[v] = W), k.push(W), oe(W, {
              destroy: function() {
                if (W.refCount--, W.refCount <= 0) {
                  e.deleteProgram(W.program);
                  var ue = k.indexOf(W);
                  k.splice(ue, 1), u.shaderCount--;
                }
                O[W.vertId].refCount <= 0 && (e.deleteShader(E[W.vertId]), delete E[W.vertId], delete I[W.fragId][W.vertId]), Object.keys(I[W.fragId]).length || (e.deleteShader(w[W.fragId]), delete w[W.fragId], delete I[W.fragId]);
              }
            });
          },
          restore: B,
          shader: C,
          frag: -1,
          vert: -1
        };
      }
      var Es = 6408, pt = 5121, xs = 3333, Xt = 5126;
      function As(e, t, u, x, w, E, g) {
        function G(k) {
          var P;
          t.next === null ? (a(
            w.preserveDrawingBuffer,
            'you must create a webgl context with "preserveDrawingBuffer":true in order to read pixels from the drawing buffer'
          ), P = pt) : (a(
            t.next.colorAttachments[0].texture !== null,
            "You cannot read from a renderbuffer"
          ), P = t.next.colorAttachments[0].texture._texture.type, a.optional(function() {
            E.oes_texture_float ? (a(
              P === pt || P === Xt,
              "Reading from a framebuffer is only allowed for the types 'uint8' and 'float'"
            ), P === Xt && a(g.readFloat, "Reading 'float' values is not permitted in your browser. For a fallback, please see: https://www.npmjs.com/package/glsl-read-float")) : a(
              P === pt,
              "Reading from a framebuffer is only allowed for the type 'uint8'"
            );
          }));
          var z = 0, D = 0, B = x.framebufferWidth, v = x.framebufferHeight, T = null;
          fe(k) ? T = k : k && (a.type(k, "object", "invalid arguments to regl.read()"), z = k.x | 0, D = k.y | 0, a(
            z >= 0 && z < x.framebufferWidth,
            "invalid x offset for regl.read"
          ), a(
            D >= 0 && D < x.framebufferHeight,
            "invalid y offset for regl.read"
          ), B = (k.width || x.framebufferWidth - z) | 0, v = (k.height || x.framebufferHeight - D) | 0, T = k.data || null), T && (P === pt ? a(
            T instanceof Uint8Array,
            "buffer must be 'Uint8Array' when reading from a framebuffer of type 'uint8'"
          ) : P === Xt && a(
            T instanceof Float32Array,
            "buffer must be 'Float32Array' when reading from a framebuffer of type 'float'"
          )), a(
            B > 0 && B + z <= x.framebufferWidth,
            "invalid width for read pixels"
          ), a(
            v > 0 && v + D <= x.framebufferHeight,
            "invalid height for read pixels"
          ), u();
          var N = B * v * 4;
          return T || (P === pt ? T = new Uint8Array(N) : P === Xt && (T = T || new Float32Array(N))), a.isTypedArray(T, "data buffer for regl.read() must be a typedarray"), a(T.byteLength >= N, "data buffer for regl.read() too small"), e.pixelStorei(xs, 4), e.readPixels(
            z,
            D,
            B,
            v,
            Es,
            P,
            T
          ), T;
        }
        function C(k) {
          var P;
          return t.setFBO({
            framebuffer: k.framebuffer
          }, function() {
            P = G(k);
          }), P;
        }
        function I(k) {
          return !k || !("framebuffer" in k) ? G(k) : C(k);
        }
        return I;
      }
      function tt(e) {
        return Array.prototype.slice.call(e);
      }
      function nt(e) {
        return tt(e).join("");
      }
      function Ts() {
        var e = 0, t = [], u = [];
        function x(P) {
          for (var z = 0; z < u.length; ++z)
            if (u[z] === P)
              return t[z];
          var D = "g" + e++;
          return t.push(D), u.push(P), D;
        }
        function w() {
          var P = [];
          function z() {
            P.push.apply(P, tt(arguments));
          }
          var D = [];
          function B() {
            var v = "v" + e++;
            return D.push(v), arguments.length > 0 && (P.push(v, "="), P.push.apply(P, tt(arguments)), P.push(";")), v;
          }
          return oe(z, {
            def: B,
            toString: function() {
              return nt([
                D.length > 0 ? "var " + D.join(",") + ";" : "",
                nt(P)
              ]);
            }
          });
        }
        function E() {
          var P = w(), z = w(), D = P.toString, B = z.toString;
          function v(T, N) {
            z(T, N, "=", P.def(T, N), ";");
          }
          return oe(function() {
            P.apply(P, tt(arguments));
          }, {
            def: P.def,
            entry: P,
            exit: z,
            save: v,
            set: function(T, N, Z) {
              v(T, N), P(T, N, "=", Z, ";");
            },
            toString: function() {
              return D() + B();
            }
          });
        }
        function g() {
          var P = nt(arguments), z = E(), D = E(), B = z.toString, v = D.toString;
          return oe(z, {
            then: function() {
              return z.apply(z, tt(arguments)), this;
            },
            else: function() {
              return D.apply(D, tt(arguments)), this;
            },
            toString: function() {
              var T = v();
              return T && (T = "else{" + T + "}"), nt([
                "if(",
                P,
                "){",
                B(),
                "}",
                T
              ]);
            }
          });
        }
        var G = w(), C = {};
        function I(P, z) {
          var D = [];
          function B() {
            var O = "a" + D.length;
            return D.push(O), O;
          }
          z = z || 0;
          for (var v = 0; v < z; ++v)
            B();
          var T = E(), N = T.toString, Z = C[P] = oe(T, {
            arg: B,
            toString: function() {
              return nt([
                "function(",
                D.join(),
                "){",
                N(),
                "}"
              ]);
            }
          });
          return Z;
        }
        function k() {
          var P = [
            '"use strict";',
            G,
            "return {"
          ];
          Object.keys(C).forEach(function(B) {
            P.push('"', B, '":', C[B].toString(), ",");
          }), P.push("}");
          var z = nt(P).replace(/;/g, `;
`).replace(/}/g, `}
`).replace(/{/g, `{
`), D = Function.apply(null, t.concat(z));
          return D.apply(null, u);
        }
        return {
          global: G,
          link: x,
          block: w,
          proc: I,
          scope: E,
          cond: g,
          compile: k
        };
      }
      var at = "xyzw".split(""), Di = 5121, it = 1, Un = 2, Vn = 0, zn = 1, Hn = 2, jn = 3, Wt = 4, Fi = 5, Ni = 6, Bi = "dither", Ii = "blend.enable", Pi = "blend.color", $n = "blend.equation", Xn = "blend.func", ki = "depth.enable", Mi = "depth.func", Ui = "depth.range", Vi = "depth.mask", Wn = "colorMask", zi = "cull.enable", Hi = "cull.face", Yn = "frontFace", qn = "lineWidth", ji = "polygonOffset.enable", Qn = "polygonOffset.offset", $i = "sample.alpha", Xi = "sample.enable", Kn = "sample.coverage", Wi = "stencil.enable", Yi = "stencil.mask", Zn = "stencil.func", Jn = "stencil.opFront", _t = "stencil.opBack", qi = "scissor.enable", Yt = "scissor.box", Ar = "viewport", bt = "profile", Mr = "framebuffer", yt = "vert", Et = "frag", Ur = "elements", Vr = "primitive", zr = "count", qt = "offset", Qt = "instances", xt = "vao", ea = "Width", ra = "Height", ft = Mr + ea, ot = Mr + ra, gs = Ar + ea, Ss = Ar + ra, Qi = "drawingBuffer", Ki = Qi + ea, Zi = Qi + ra, ws = [
        Xn,
        $n,
        Zn,
        Jn,
        _t,
        Kn,
        Ar,
        Yt,
        Qn
      ], ut = 34962, ta = 34963, Ls = 35632, Rs = 35633, Ji = 3553, Os = 34067, Cs = 2884, Gs = 3042, Ds = 3024, Fs = 2960, Ns = 2929, Bs = 3089, Is = 32823, Ps = 32926, ks = 32928, na = 5126, Kt = 35664, Zt = 35665, Jt = 35666, aa = 5124, en = 35667, rn = 35668, tn = 35669, ia = 35670, nn = 35671, an = 35672, fn = 35673, At = 35674, Tt = 35675, gt = 35676, St = 35678, wt = 35680, fa = 4, Lt = 1028, Hr = 1029, ef = 2304, oa = 2305, Ms = 32775, Us = 32776, Vs = 519, Or = 7680, rf = 0, tf = 1, nf = 32774, zs = 513, af = 36160, Hs = 36064, pr = {
        0: 0,
        1: 1,
        zero: 0,
        one: 1,
        "src color": 768,
        "one minus src color": 769,
        "src alpha": 770,
        "one minus src alpha": 771,
        "dst color": 774,
        "one minus dst color": 775,
        "dst alpha": 772,
        "one minus dst alpha": 773,
        "constant color": 32769,
        "one minus constant color": 32770,
        "constant alpha": 32771,
        "one minus constant alpha": 32772,
        "src alpha saturate": 776
      }, ff = [
        "constant color, constant alpha",
        "one minus constant color, constant alpha",
        "constant color, one minus constant alpha",
        "one minus constant color, one minus constant alpha",
        "constant alpha, constant color",
        "constant alpha, one minus constant color",
        "one minus constant alpha, constant color",
        "one minus constant alpha, one minus constant color"
      ], st = {
        never: 512,
        less: 513,
        "<": 513,
        equal: 514,
        "=": 514,
        "==": 514,
        "===": 514,
        lequal: 515,
        "<=": 515,
        greater: 516,
        ">": 516,
        notequal: 517,
        "!=": 517,
        "!==": 517,
        gequal: 518,
        ">=": 518,
        always: 519
      }, Cr = {
        0: 0,
        zero: 0,
        keep: 7680,
        replace: 7681,
        increment: 7682,
        decrement: 7683,
        "increment wrap": 34055,
        "decrement wrap": 34056,
        invert: 5386
      }, of = {
        frag: Ls,
        vert: Rs
      }, ua = {
        cw: ef,
        ccw: oa
      };
      function on(e) {
        return Array.isArray(e) || fe(e) || cr(e);
      }
      function uf(e) {
        return e.sort(function(t, u) {
          return t === Ar ? -1 : u === Ar ? 1 : t < u ? -1 : 1;
        });
      }
      function $e(e, t, u, x) {
        this.thisDep = e, this.contextDep = t, this.propDep = u, this.append = x;
      }
      function Gr(e) {
        return e && !(e.thisDep || e.contextDep || e.propDep);
      }
      function Me(e) {
        return new $e(!1, !1, !1, e);
      }
      function rr(e, t) {
        var u = e.type;
        if (u === Vn) {
          var x = e.data.length;
          return new $e(
            !0,
            x >= 1,
            x >= 2,
            t
          );
        } else if (u === Wt) {
          var w = e.data;
          return new $e(
            w.thisDep,
            w.contextDep,
            w.propDep,
            t
          );
        } else {
          if (u === Fi)
            return new $e(
              !1,
              !1,
              !1,
              t
            );
          if (u === Ni) {
            for (var E = !1, g = !1, G = !1, C = 0; C < e.data.length; ++C) {
              var I = e.data[C];
              if (I.type === zn)
                G = !0;
              else if (I.type === Hn)
                g = !0;
              else if (I.type === jn)
                E = !0;
              else if (I.type === Vn) {
                E = !0;
                var k = I.data;
                k >= 1 && (g = !0), k >= 2 && (G = !0);
              } else I.type === Wt && (E = E || I.data.thisDep, g = g || I.data.contextDep, G = G || I.data.propDep);
            }
            return new $e(
              E,
              g,
              G,
              t
            );
          } else
            return new $e(
              u === jn,
              u === Hn,
              u === zn,
              t
            );
        }
      }
      var sf = new $e(!1, !1, !1, function() {
      });
      function js(e, t, u, x, w, E, g, G, C, I, k, P, z, D, B) {
        var v = I.Record, T = {
          add: 32774,
          subtract: 32778,
          "reverse subtract": 32779
        };
        u.ext_blend_minmax && (T.min = Ms, T.max = Us);
        var N = u.angle_instanced_arrays, Z = u.webgl_draw_buffers, O = u.oes_vertex_array_object, Q = {
          dirty: !0,
          profile: B.profile
        }, W = {}, ue = [], L = {}, S = {};
        function re(i) {
          return i.replace(".", "_");
        }
        function H(i, r, c) {
          var h = re(i);
          ue.push(i), W[h] = Q[h] = !!c, L[h] = r;
        }
        function F(i, r, c) {
          var h = re(i);
          ue.push(i), Array.isArray(c) ? (Q[h] = c.slice(), W[h] = c.slice()) : Q[h] = W[h] = c, S[h] = r;
        }
        H(Bi, Ds), H(Ii, Gs), F(Pi, "blendColor", [0, 0, 0, 0]), F(
          $n,
          "blendEquationSeparate",
          [nf, nf]
        ), F(
          Xn,
          "blendFuncSeparate",
          [tf, rf, tf, rf]
        ), H(ki, Ns, !0), F(Mi, "depthFunc", zs), F(Ui, "depthRange", [0, 1]), F(Vi, "depthMask", !0), F(Wn, Wn, [!0, !0, !0, !0]), H(zi, Cs), F(Hi, "cullFace", Hr), F(Yn, Yn, oa), F(qn, qn, 1), H(ji, Is), F(Qn, "polygonOffset", [0, 0]), H($i, Ps), H(Xi, ks), F(Kn, "sampleCoverage", [1, !1]), H(Wi, Fs), F(Yi, "stencilMask", -1), F(Zn, "stencilFunc", [Vs, 0, -1]), F(
          Jn,
          "stencilOpSeparate",
          [Lt, Or, Or, Or]
        ), F(
          _t,
          "stencilOpSeparate",
          [Hr, Or, Or, Or]
        ), H(qi, Bs), F(
          Yt,
          "scissor",
          [0, 0, e.drawingBufferWidth, e.drawingBufferHeight]
        ), F(
          Ar,
          Ar,
          [0, 0, e.drawingBufferWidth, e.drawingBufferHeight]
        );
        var $ = {
          gl: e,
          context: z,
          strings: t,
          next: W,
          current: Q,
          draw: P,
          elements: E,
          buffer: w,
          shader: k,
          attributes: I.state,
          vao: I,
          uniforms: C,
          framebuffer: G,
          extensions: u,
          timer: D,
          isBufferArgs: on
        }, X = {
          primTypes: Lr,
          compareFuncs: st,
          blendFuncs: pr,
          blendEquations: T,
          stencilOps: Cr,
          glTypes: Nr,
          orientationType: ua
        };
        a.optional(function() {
          $.isArrayLike = Ne;
        }), Z && (X.backBuffer = [Hr], X.drawBuffer = ir(x.maxDrawbuffers, function(i) {
          return i === 0 ? [0] : ir(i, function(r) {
            return Hs + r;
          });
        }));
        var ve = 0;
        function de() {
          var i = Ts(), r = i.link, c = i.global;
          i.id = ve++, i.batchId = "0";
          var h = r($), _ = i.shared = {
            props: "a0"
          };
          Object.keys($).forEach(function(s) {
            _[s] = c.def(h, ".", s);
          }), a.optional(function() {
            i.CHECK = r(a), i.commandStr = a.guessCommand(), i.command = r(i.commandStr), i.assert = function(s, f, p) {
              s(
                "if(!(",
                f,
                "))",
                this.CHECK,
                ".commandRaise(",
                r(p),
                ",",
                this.command,
                ");"
              );
            }, X.invalidBlendCombinations = ff;
          });
          var d = i.next = {}, l = i.current = {};
          Object.keys(S).forEach(function(s) {
            Array.isArray(Q[s]) && (d[s] = c.def(_.next, ".", s), l[s] = c.def(_.current, ".", s));
          });
          var m = i.constants = {};
          Object.keys(X).forEach(function(s) {
            m[s] = c.def(JSON.stringify(X[s]));
          }), i.invoke = function(s, f) {
            switch (f.type) {
              case Vn:
                var p = [
                  "this",
                  _.context,
                  _.props,
                  i.batchId
                ];
                return s.def(
                  r(f.data),
                  ".call(",
                  p.slice(0, Math.max(f.data.length + 1, 4)),
                  ")"
                );
              case zn:
                return s.def(_.props, f.data);
              case Hn:
                return s.def(_.context, f.data);
              case jn:
                return s.def("this", f.data);
              case Wt:
                return f.data.append(i, s), f.data.ref;
              case Fi:
                return f.data.toString();
              case Ni:
                return f.data.map(function(b) {
                  return i.invoke(s, b);
                });
            }
          }, i.attribCache = {};
          var n = {};
          return i.scopeAttrib = function(s) {
            var f = t.id(s);
            if (f in n)
              return n[f];
            var p = I.scope[f];
            p || (p = I.scope[f] = new v());
            var b = n[f] = r(p);
            return b;
          }, i;
        }
        function Y(i) {
          var r = i.static, c = i.dynamic, h;
          if (bt in r) {
            var _ = !!r[bt];
            h = Me(function(l, m) {
              return _;
            }), h.enable = _;
          } else if (bt in c) {
            var d = c[bt];
            h = rr(d, function(l, m) {
              return l.invoke(m, d);
            });
          }
          return h;
        }
        function K(i, r) {
          var c = i.static, h = i.dynamic;
          if (Mr in c) {
            var _ = c[Mr];
            return _ ? (_ = G.getFramebuffer(_), a.command(_, "invalid framebuffer object"), Me(function(l, m) {
              var n = l.link(_), s = l.shared;
              m.set(
                s.framebuffer,
                ".next",
                n
              );
              var f = s.context;
              return m.set(
                f,
                "." + ft,
                n + ".width"
              ), m.set(
                f,
                "." + ot,
                n + ".height"
              ), n;
            })) : Me(function(l, m) {
              var n = l.shared;
              m.set(
                n.framebuffer,
                ".next",
                "null"
              );
              var s = n.context;
              return m.set(
                s,
                "." + ft,
                s + "." + Ki
              ), m.set(
                s,
                "." + ot,
                s + "." + Zi
              ), "null";
            });
          } else if (Mr in h) {
            var d = h[Mr];
            return rr(d, function(l, m) {
              var n = l.invoke(m, d), s = l.shared, f = s.framebuffer, p = m.def(
                f,
                ".getFramebuffer(",
                n,
                ")"
              );
              a.optional(function() {
                l.assert(
                  m,
                  "!" + n + "||" + p,
                  "invalid framebuffer object"
                );
              }), m.set(
                f,
                ".next",
                p
              );
              var b = s.context;
              return m.set(
                b,
                "." + ft,
                p + "?" + p + ".width:" + b + "." + Ki
              ), m.set(
                b,
                "." + ot,
                p + "?" + p + ".height:" + b + "." + Zi
              ), p;
            });
          } else
            return null;
        }
        function ce(i, r, c) {
          var h = i.static, _ = i.dynamic;
          function d(n) {
            if (n in h) {
              var s = h[n];
              a.commandType(s, "object", "invalid " + n, c.commandStr);
              var f = !0, p = s.x | 0, b = s.y | 0, R, U;
              return "width" in s ? (R = s.width | 0, a.command(R >= 0, "invalid " + n, c.commandStr)) : f = !1, "height" in s ? (U = s.height | 0, a.command(U >= 0, "invalid " + n, c.commandStr)) : f = !1, new $e(
                !f && r && r.thisDep,
                !f && r && r.contextDep,
                !f && r && r.propDep,
                function(M, ae) {
                  var J = M.shared.context, te = R;
                  "width" in s || (te = ae.def(J, ".", ft, "-", p));
                  var ne = U;
                  return "height" in s || (ne = ae.def(J, ".", ot, "-", b)), [p, b, te, ne];
                }
              );
            } else if (n in _) {
              var V = _[n], q = rr(V, function(M, ae) {
                var J = M.invoke(ae, V);
                a.optional(function() {
                  M.assert(
                    ae,
                    J + "&&typeof " + J + '==="object"',
                    "invalid " + n
                  );
                });
                var te = M.shared.context, ne = ae.def(J, ".x|0"), ie = ae.def(J, ".y|0"), le = ae.def(
                  '"width" in ',
                  J,
                  "?",
                  J,
                  ".width|0:",
                  "(",
                  te,
                  ".",
                  ft,
                  "-",
                  ne,
                  ")"
                ), Oe = ae.def(
                  '"height" in ',
                  J,
                  "?",
                  J,
                  ".height|0:",
                  "(",
                  te,
                  ".",
                  ot,
                  "-",
                  ie,
                  ")"
                );
                return a.optional(function() {
                  M.assert(
                    ae,
                    le + ">=0&&" + Oe + ">=0",
                    "invalid " + n
                  );
                }), [ne, ie, le, Oe];
              });
              return r && (q.thisDep = q.thisDep || r.thisDep, q.contextDep = q.contextDep || r.contextDep, q.propDep = q.propDep || r.propDep), q;
            } else return r ? new $e(
              r.thisDep,
              r.contextDep,
              r.propDep,
              function(M, ae) {
                var J = M.shared.context;
                return [
                  0,
                  0,
                  ae.def(J, ".", ft),
                  ae.def(J, ".", ot)
                ];
              }
            ) : null;
          }
          var l = d(Ar);
          if (l) {
            var m = l;
            l = new $e(
              l.thisDep,
              l.contextDep,
              l.propDep,
              function(n, s) {
                var f = m.append(n, s), p = n.shared.context;
                return s.set(
                  p,
                  "." + gs,
                  f[2]
                ), s.set(
                  p,
                  "." + Ss,
                  f[3]
                ), f;
              }
            );
          }
          return {
            viewport: l,
            scissor_box: d(Yt)
          };
        }
        function he(i, r) {
          var c = i.static, h = typeof c[Et] == "string" && typeof c[yt] == "string";
          if (h) {
            if (Object.keys(r.dynamic).length > 0)
              return null;
            var _ = r.static, d = Object.keys(_);
            if (d.length > 0 && typeof _[d[0]] == "number") {
              for (var l = [], m = 0; m < d.length; ++m)
                a(typeof _[d[m]] == "number", "must specify all vertex attribute locations when using vaos"), l.push([_[d[m]] | 0, d[m]]);
              return l;
            }
          }
          return null;
        }
        function Ee(i, r, c) {
          var h = i.static, _ = i.dynamic;
          function d(f) {
            if (f in h) {
              var p = t.id(h[f]);
              a.optional(function() {
                k.shader(of[f], p, a.guessCommand());
              });
              var b = Me(function() {
                return p;
              });
              return b.id = p, b;
            } else if (f in _) {
              var R = _[f];
              return rr(R, function(U, V) {
                var q = U.invoke(V, R), M = V.def(U.shared.strings, ".id(", q, ")");
                return a.optional(function() {
                  V(
                    U.shared.shader,
                    ".shader(",
                    of[f],
                    ",",
                    M,
                    ",",
                    U.command,
                    ");"
                  );
                }), M;
              });
            }
            return null;
          }
          var l = d(Et), m = d(yt), n = null, s;
          return Gr(l) && Gr(m) ? (n = k.program(m.id, l.id, null, c), s = Me(function(f, p) {
            return f.link(n);
          })) : s = new $e(
            l && l.thisDep || m && m.thisDep,
            l && l.contextDep || m && m.contextDep,
            l && l.propDep || m && m.propDep,
            function(f, p) {
              var b = f.shared.shader, R;
              l ? R = l.append(f, p) : R = p.def(b, ".", Et);
              var U;
              m ? U = m.append(f, p) : U = p.def(b, ".", yt);
              var V = b + ".program(" + U + "," + R;
              return a.optional(function() {
                V += "," + f.command;
              }), p.def(V + ")");
            }
          ), {
            frag: l,
            vert: m,
            progVar: s,
            program: n
          };
        }
        function De(i, r) {
          var c = i.static, h = i.dynamic, _ = {}, d = !1;
          function l() {
            if (xt in c) {
              var ae = c[xt];
              return ae !== null && I.getVAO(ae) === null && (ae = I.createVAO(ae)), d = !0, _.vao = ae, Me(function(te) {
                var ne = I.getVAO(ae);
                return ne ? te.link(ne) : "null";
              });
            } else if (xt in h) {
              d = !0;
              var J = h[xt];
              return rr(J, function(te, ne) {
                var ie = te.invoke(ne, J);
                return ne.def(te.shared.vao + ".getVAO(" + ie + ")");
              });
            }
            return null;
          }
          var m = l(), n = !1;
          function s() {
            if (Ur in c) {
              var ae = c[Ur];
              if (_.elements = ae, on(ae)) {
                var J = _.elements = E.create(ae, !0);
                ae = E.getElements(J), n = !0;
              } else ae && (ae = E.getElements(ae), n = !0, a.command(ae, "invalid elements", r.commandStr));
              var te = Me(function(ie, le) {
                if (ae) {
                  var Oe = ie.link(ae);
                  return ie.ELEMENTS = Oe, Oe;
                }
                return ie.ELEMENTS = null, null;
              });
              return te.value = ae, te;
            } else if (Ur in h) {
              n = !0;
              var ne = h[Ur];
              return rr(ne, function(ie, le) {
                var Oe = ie.shared, Ye = Oe.isBufferArgs, Tr = Oe.elements, gr = ie.invoke(le, ne), Sr = le.def("null"), Je = le.def(Ye, "(", gr, ")"), br = ie.cond(Je).then(Sr, "=", Tr, ".createStream(", gr, ");").else(Sr, "=", Tr, ".getElements(", gr, ");");
                return a.optional(function() {
                  ie.assert(
                    br.else,
                    "!" + gr + "||" + Sr,
                    "invalid elements"
                  );
                }), le.entry(br), le.exit(
                  ie.cond(Je).then(Tr, ".destroyStream(", Sr, ");")
                ), ie.ELEMENTS = Sr, Sr;
              });
            } else if (d)
              return new $e(
                m.thisDep,
                m.contextDep,
                m.propDep,
                function(ie, le) {
                  return le.def(ie.shared.vao + ".currentVAO?" + ie.shared.elements + ".getElements(" + ie.shared.vao + ".currentVAO.elements):null");
                }
              );
            return null;
          }
          var f = s();
          function p() {
            if (Vr in c) {
              var ae = c[Vr];
              return _.primitive = ae, a.commandParameter(ae, Lr, "invalid primitve", r.commandStr), Me(function(te, ne) {
                return Lr[ae];
              });
            } else if (Vr in h) {
              var J = h[Vr];
              return rr(J, function(te, ne) {
                var ie = te.constants.primTypes, le = te.invoke(ne, J);
                return a.optional(function() {
                  te.assert(
                    ne,
                    le + " in " + ie,
                    "invalid primitive, must be one of " + Object.keys(Lr)
                  );
                }), ne.def(ie, "[", le, "]");
              });
            } else {
              if (n)
                return Gr(f) ? f.value ? Me(function(te, ne) {
                  return ne.def(te.ELEMENTS, ".primType");
                }) : Me(function() {
                  return fa;
                }) : new $e(
                  f.thisDep,
                  f.contextDep,
                  f.propDep,
                  function(te, ne) {
                    var ie = te.ELEMENTS;
                    return ne.def(ie, "?", ie, ".primType:", fa);
                  }
                );
              if (d)
                return new $e(
                  m.thisDep,
                  m.contextDep,
                  m.propDep,
                  function(te, ne) {
                    return ne.def(te.shared.vao + ".currentVAO?" + te.shared.vao + ".currentVAO.primitive:" + fa);
                  }
                );
            }
            return null;
          }
          function b(ae, J) {
            if (ae in c) {
              var te = c[ae] | 0;
              return J ? _.offset = te : _.instances = te, a.command(!J || te >= 0, "invalid " + ae, r.commandStr), Me(function(ie, le) {
                return J && (ie.OFFSET = te), te;
              });
            } else if (ae in h) {
              var ne = h[ae];
              return rr(ne, function(ie, le) {
                var Oe = ie.invoke(le, ne);
                return J && (ie.OFFSET = Oe, a.optional(function() {
                  ie.assert(
                    le,
                    Oe + ">=0",
                    "invalid " + ae
                  );
                })), Oe;
              });
            } else if (J) {
              if (n)
                return Me(function(ie, le) {
                  return ie.OFFSET = 0, 0;
                });
              if (d)
                return new $e(
                  m.thisDep,
                  m.contextDep,
                  m.propDep,
                  function(ie, le) {
                    return le.def(ie.shared.vao + ".currentVAO?" + ie.shared.vao + ".currentVAO.offset:0");
                  }
                );
            } else if (d)
              return new $e(
                m.thisDep,
                m.contextDep,
                m.propDep,
                function(ie, le) {
                  return le.def(ie.shared.vao + ".currentVAO?" + ie.shared.vao + ".currentVAO.instances:-1");
                }
              );
            return null;
          }
          var R = b(qt, !0);
          function U() {
            if (zr in c) {
              var ae = c[zr] | 0;
              return _.count = ae, a.command(
                typeof ae == "number" && ae >= 0,
                "invalid vertex count",
                r.commandStr
              ), Me(function() {
                return ae;
              });
            } else if (zr in h) {
              var J = h[zr];
              return rr(J, function(le, Oe) {
                var Ye = le.invoke(Oe, J);
                return a.optional(function() {
                  le.assert(
                    Oe,
                    "typeof " + Ye + '==="number"&&' + Ye + ">=0&&" + Ye + "===(" + Ye + "|0)",
                    "invalid vertex count"
                  );
                }), Ye;
              });
            } else if (n)
              if (Gr(f)) {
                if (f)
                  return R ? new $e(
                    R.thisDep,
                    R.contextDep,
                    R.propDep,
                    function(le, Oe) {
                      var Ye = Oe.def(
                        le.ELEMENTS,
                        ".vertCount-",
                        le.OFFSET
                      );
                      return a.optional(function() {
                        le.assert(
                          Oe,
                          Ye + ">=0",
                          "invalid vertex offset/element buffer too small"
                        );
                      }), Ye;
                    }
                  ) : Me(function(le, Oe) {
                    return Oe.def(le.ELEMENTS, ".vertCount");
                  });
                var te = Me(function() {
                  return -1;
                });
                return a.optional(function() {
                  te.MISSING = !0;
                }), te;
              } else {
                var ne = new $e(
                  f.thisDep || R.thisDep,
                  f.contextDep || R.contextDep,
                  f.propDep || R.propDep,
                  function(le, Oe) {
                    var Ye = le.ELEMENTS;
                    return le.OFFSET ? Oe.def(
                      Ye,
                      "?",
                      Ye,
                      ".vertCount-",
                      le.OFFSET,
                      ":-1"
                    ) : Oe.def(Ye, "?", Ye, ".vertCount:-1");
                  }
                );
                return a.optional(function() {
                  ne.DYNAMIC = !0;
                }), ne;
              }
            else if (d) {
              var ie = new $e(
                m.thisDep,
                m.contextDep,
                m.propDep,
                function(le, Oe) {
                  return Oe.def(le.shared.vao, ".currentVAO?", le.shared.vao, ".currentVAO.count:-1");
                }
              );
              return ie;
            }
            return null;
          }
          var V = p(), q = U(), M = b(Qt, !1);
          return {
            elements: f,
            primitive: V,
            count: q,
            instances: M,
            offset: R,
            vao: m,
            vaoActive: d,
            elementsActive: n,
            // static draw props
            static: _
          };
        }
        function Fe(i, r) {
          var c = i.static, h = i.dynamic, _ = {};
          return ue.forEach(function(d) {
            var l = re(d);
            function m(n, s) {
              if (d in c) {
                var f = n(c[d]);
                _[l] = Me(function() {
                  return f;
                });
              } else if (d in h) {
                var p = h[d];
                _[l] = rr(p, function(b, R) {
                  return s(b, R, b.invoke(R, p));
                });
              }
            }
            switch (d) {
              case zi:
              case Ii:
              case Bi:
              case Wi:
              case ki:
              case qi:
              case ji:
              case $i:
              case Xi:
              case Vi:
                return m(
                  function(n) {
                    return a.commandType(n, "boolean", d, r.commandStr), n;
                  },
                  function(n, s, f) {
                    return a.optional(function() {
                      n.assert(
                        s,
                        "typeof " + f + '==="boolean"',
                        "invalid flag " + d,
                        n.commandStr
                      );
                    }), f;
                  }
                );
              case Mi:
                return m(
                  function(n) {
                    return a.commandParameter(n, st, "invalid " + d, r.commandStr), st[n];
                  },
                  function(n, s, f) {
                    var p = n.constants.compareFuncs;
                    return a.optional(function() {
                      n.assert(
                        s,
                        f + " in " + p,
                        "invalid " + d + ", must be one of " + Object.keys(st)
                      );
                    }), s.def(p, "[", f, "]");
                  }
                );
              case Ui:
                return m(
                  function(n) {
                    return a.command(
                      Ne(n) && n.length === 2 && typeof n[0] == "number" && typeof n[1] == "number" && n[0] <= n[1],
                      "depth range is 2d array",
                      r.commandStr
                    ), n;
                  },
                  function(n, s, f) {
                    a.optional(function() {
                      n.assert(
                        s,
                        n.shared.isArrayLike + "(" + f + ")&&" + f + ".length===2&&typeof " + f + '[0]==="number"&&typeof ' + f + '[1]==="number"&&' + f + "[0]<=" + f + "[1]",
                        "depth range must be a 2d array"
                      );
                    });
                    var p = s.def("+", f, "[0]"), b = s.def("+", f, "[1]");
                    return [p, b];
                  }
                );
              case Xn:
                return m(
                  function(n) {
                    a.commandType(n, "object", "blend.func", r.commandStr);
                    var s = "srcRGB" in n ? n.srcRGB : n.src, f = "srcAlpha" in n ? n.srcAlpha : n.src, p = "dstRGB" in n ? n.dstRGB : n.dst, b = "dstAlpha" in n ? n.dstAlpha : n.dst;
                    return a.commandParameter(s, pr, l + ".srcRGB", r.commandStr), a.commandParameter(f, pr, l + ".srcAlpha", r.commandStr), a.commandParameter(p, pr, l + ".dstRGB", r.commandStr), a.commandParameter(b, pr, l + ".dstAlpha", r.commandStr), a.command(
                      ff.indexOf(s + ", " + p) === -1,
                      "unallowed blending combination (srcRGB, dstRGB) = (" + s + ", " + p + ")",
                      r.commandStr
                    ), [
                      pr[s],
                      pr[p],
                      pr[f],
                      pr[b]
                    ];
                  },
                  function(n, s, f) {
                    var p = n.constants.blendFuncs;
                    a.optional(function() {
                      n.assert(
                        s,
                        f + "&&typeof " + f + '==="object"',
                        "invalid blend func, must be an object"
                      );
                    });
                    function b(J, te) {
                      var ne = s.def(
                        '"',
                        J,
                        te,
                        '" in ',
                        f,
                        "?",
                        f,
                        ".",
                        J,
                        te,
                        ":",
                        f,
                        ".",
                        J
                      );
                      return a.optional(function() {
                        n.assert(
                          s,
                          ne + " in " + p,
                          "invalid " + d + "." + J + te + ", must be one of " + Object.keys(pr)
                        );
                      }), ne;
                    }
                    var R = b("src", "RGB"), U = b("dst", "RGB");
                    a.optional(function() {
                      var J = n.constants.invalidBlendCombinations;
                      n.assert(
                        s,
                        J + ".indexOf(" + R + '+", "+' + U + ") === -1 ",
                        "unallowed blending combination for (srcRGB, dstRGB)"
                      );
                    });
                    var V = s.def(p, "[", R, "]"), q = s.def(p, "[", b("src", "Alpha"), "]"), M = s.def(p, "[", U, "]"), ae = s.def(p, "[", b("dst", "Alpha"), "]");
                    return [V, M, q, ae];
                  }
                );
              case $n:
                return m(
                  function(n) {
                    if (typeof n == "string")
                      return a.commandParameter(n, T, "invalid " + d, r.commandStr), [
                        T[n],
                        T[n]
                      ];
                    if (typeof n == "object")
                      return a.commandParameter(
                        n.rgb,
                        T,
                        d + ".rgb",
                        r.commandStr
                      ), a.commandParameter(
                        n.alpha,
                        T,
                        d + ".alpha",
                        r.commandStr
                      ), [
                        T[n.rgb],
                        T[n.alpha]
                      ];
                    a.commandRaise("invalid blend.equation", r.commandStr);
                  },
                  function(n, s, f) {
                    var p = n.constants.blendEquations, b = s.def(), R = s.def(), U = n.cond("typeof ", f, '==="string"');
                    return a.optional(function() {
                      function V(q, M, ae) {
                        n.assert(
                          q,
                          ae + " in " + p,
                          "invalid " + M + ", must be one of " + Object.keys(T)
                        );
                      }
                      V(U.then, d, f), n.assert(
                        U.else,
                        f + "&&typeof " + f + '==="object"',
                        "invalid " + d
                      ), V(U.else, d + ".rgb", f + ".rgb"), V(U.else, d + ".alpha", f + ".alpha");
                    }), U.then(
                      b,
                      "=",
                      R,
                      "=",
                      p,
                      "[",
                      f,
                      "];"
                    ), U.else(
                      b,
                      "=",
                      p,
                      "[",
                      f,
                      ".rgb];",
                      R,
                      "=",
                      p,
                      "[",
                      f,
                      ".alpha];"
                    ), s(U), [b, R];
                  }
                );
              case Pi:
                return m(
                  function(n) {
                    return a.command(
                      Ne(n) && n.length === 4,
                      "blend.color must be a 4d array",
                      r.commandStr
                    ), ir(4, function(s) {
                      return +n[s];
                    });
                  },
                  function(n, s, f) {
                    return a.optional(function() {
                      n.assert(
                        s,
                        n.shared.isArrayLike + "(" + f + ")&&" + f + ".length===4",
                        "blend.color must be a 4d array"
                      );
                    }), ir(4, function(p) {
                      return s.def("+", f, "[", p, "]");
                    });
                  }
                );
              case Yi:
                return m(
                  function(n) {
                    return a.commandType(n, "number", l, r.commandStr), n | 0;
                  },
                  function(n, s, f) {
                    return a.optional(function() {
                      n.assert(
                        s,
                        "typeof " + f + '==="number"',
                        "invalid stencil.mask"
                      );
                    }), s.def(f, "|0");
                  }
                );
              case Zn:
                return m(
                  function(n) {
                    a.commandType(n, "object", l, r.commandStr);
                    var s = n.cmp || "keep", f = n.ref || 0, p = "mask" in n ? n.mask : -1;
                    return a.commandParameter(s, st, d + ".cmp", r.commandStr), a.commandType(f, "number", d + ".ref", r.commandStr), a.commandType(p, "number", d + ".mask", r.commandStr), [
                      st[s],
                      f,
                      p
                    ];
                  },
                  function(n, s, f) {
                    var p = n.constants.compareFuncs;
                    a.optional(function() {
                      function V() {
                        n.assert(
                          s,
                          Array.prototype.join.call(arguments, ""),
                          "invalid stencil.func"
                        );
                      }
                      V(f + "&&typeof ", f, '==="object"'), V(
                        '!("cmp" in ',
                        f,
                        ")||(",
                        f,
                        ".cmp in ",
                        p,
                        ")"
                      );
                    });
                    var b = s.def(
                      '"cmp" in ',
                      f,
                      "?",
                      p,
                      "[",
                      f,
                      ".cmp]",
                      ":",
                      Or
                    ), R = s.def(f, ".ref|0"), U = s.def(
                      '"mask" in ',
                      f,
                      "?",
                      f,
                      ".mask|0:-1"
                    );
                    return [b, R, U];
                  }
                );
              case Jn:
              case _t:
                return m(
                  function(n) {
                    a.commandType(n, "object", l, r.commandStr);
                    var s = n.fail || "keep", f = n.zfail || "keep", p = n.zpass || "keep";
                    return a.commandParameter(s, Cr, d + ".fail", r.commandStr), a.commandParameter(f, Cr, d + ".zfail", r.commandStr), a.commandParameter(p, Cr, d + ".zpass", r.commandStr), [
                      d === _t ? Hr : Lt,
                      Cr[s],
                      Cr[f],
                      Cr[p]
                    ];
                  },
                  function(n, s, f) {
                    var p = n.constants.stencilOps;
                    a.optional(function() {
                      n.assert(
                        s,
                        f + "&&typeof " + f + '==="object"',
                        "invalid " + d
                      );
                    });
                    function b(R) {
                      return a.optional(function() {
                        n.assert(
                          s,
                          '!("' + R + '" in ' + f + ")||(" + f + "." + R + " in " + p + ")",
                          "invalid " + d + "." + R + ", must be one of " + Object.keys(Cr)
                        );
                      }), s.def(
                        '"',
                        R,
                        '" in ',
                        f,
                        "?",
                        p,
                        "[",
                        f,
                        ".",
                        R,
                        "]:",
                        Or
                      );
                    }
                    return [
                      d === _t ? Hr : Lt,
                      b("fail"),
                      b("zfail"),
                      b("zpass")
                    ];
                  }
                );
              case Qn:
                return m(
                  function(n) {
                    a.commandType(n, "object", l, r.commandStr);
                    var s = n.factor | 0, f = n.units | 0;
                    return a.commandType(s, "number", l + ".factor", r.commandStr), a.commandType(f, "number", l + ".units", r.commandStr), [s, f];
                  },
                  function(n, s, f) {
                    a.optional(function() {
                      n.assert(
                        s,
                        f + "&&typeof " + f + '==="object"',
                        "invalid " + d
                      );
                    });
                    var p = s.def(f, ".factor|0"), b = s.def(f, ".units|0");
                    return [p, b];
                  }
                );
              case Hi:
                return m(
                  function(n) {
                    var s = 0;
                    return n === "front" ? s = Lt : n === "back" && (s = Hr), a.command(!!s, l, r.commandStr), s;
                  },
                  function(n, s, f) {
                    return a.optional(function() {
                      n.assert(
                        s,
                        f + '==="front"||' + f + '==="back"',
                        "invalid cull.face"
                      );
                    }), s.def(f, '==="front"?', Lt, ":", Hr);
                  }
                );
              case qn:
                return m(
                  function(n) {
                    return a.command(
                      typeof n == "number" && n >= x.lineWidthDims[0] && n <= x.lineWidthDims[1],
                      "invalid line width, must be a positive number between " + x.lineWidthDims[0] + " and " + x.lineWidthDims[1],
                      r.commandStr
                    ), n;
                  },
                  function(n, s, f) {
                    return a.optional(function() {
                      n.assert(
                        s,
                        "typeof " + f + '==="number"&&' + f + ">=" + x.lineWidthDims[0] + "&&" + f + "<=" + x.lineWidthDims[1],
                        "invalid line width"
                      );
                    }), f;
                  }
                );
              case Yn:
                return m(
                  function(n) {
                    return a.commandParameter(n, ua, l, r.commandStr), ua[n];
                  },
                  function(n, s, f) {
                    return a.optional(function() {
                      n.assert(
                        s,
                        f + '==="cw"||' + f + '==="ccw"',
                        "invalid frontFace, must be one of cw,ccw"
                      );
                    }), s.def(f + '==="cw"?' + ef + ":" + oa);
                  }
                );
              case Wn:
                return m(
                  function(n) {
                    return a.command(
                      Ne(n) && n.length === 4,
                      "color.mask must be length 4 array",
                      r.commandStr
                    ), n.map(function(s) {
                      return !!s;
                    });
                  },
                  function(n, s, f) {
                    return a.optional(function() {
                      n.assert(
                        s,
                        n.shared.isArrayLike + "(" + f + ")&&" + f + ".length===4",
                        "invalid color.mask"
                      );
                    }), ir(4, function(p) {
                      return "!!" + f + "[" + p + "]";
                    });
                  }
                );
              case Kn:
                return m(
                  function(n) {
                    a.command(typeof n == "object" && n, l, r.commandStr);
                    var s = "value" in n ? n.value : 1, f = !!n.invert;
                    return a.command(
                      typeof s == "number" && s >= 0 && s <= 1,
                      "sample.coverage.value must be a number between 0 and 1",
                      r.commandStr
                    ), [s, f];
                  },
                  function(n, s, f) {
                    a.optional(function() {
                      n.assert(
                        s,
                        f + "&&typeof " + f + '==="object"',
                        "invalid sample.coverage"
                      );
                    });
                    var p = s.def(
                      '"value" in ',
                      f,
                      "?+",
                      f,
                      ".value:1"
                    ), b = s.def("!!", f, ".invert");
                    return [p, b];
                  }
                );
            }
          }), _;
        }
        function Te(i, r) {
          var c = i.static, h = i.dynamic, _ = {};
          return Object.keys(c).forEach(function(d) {
            var l = c[d], m;
            if (typeof l == "number" || typeof l == "boolean")
              m = Me(function() {
                return l;
              });
            else if (typeof l == "function") {
              var n = l._reglType;
              n === "texture2d" || n === "textureCube" ? m = Me(function(s) {
                return s.link(l);
              }) : n === "framebuffer" || n === "framebufferCube" ? (a.command(
                l.color.length > 0,
                'missing color attachment for framebuffer sent to uniform "' + d + '"',
                r.commandStr
              ), m = Me(function(s) {
                return s.link(l.color[0]);
              })) : a.commandRaise('invalid data for uniform "' + d + '"', r.commandStr);
            } else Ne(l) ? m = Me(function(s) {
              var f = s.global.def(
                "[",
                ir(l.length, function(p) {
                  return a.command(
                    typeof l[p] == "number" || typeof l[p] == "boolean",
                    "invalid uniform " + d,
                    s.commandStr
                  ), l[p];
                }),
                "]"
              );
              return f;
            }) : a.commandRaise('invalid or missing data for uniform "' + d + '"', r.commandStr);
            m.value = l, _[d] = m;
          }), Object.keys(h).forEach(function(d) {
            var l = h[d];
            _[d] = rr(l, function(m, n) {
              return m.invoke(n, l);
            });
          }), _;
        }
        function Ve(i, r) {
          var c = i.static, h = i.dynamic, _ = {};
          return Object.keys(c).forEach(function(d) {
            var l = c[d], m = t.id(d), n = new v();
            if (on(l))
              n.state = it, n.buffer = w.getBuffer(
                w.create(l, ut, !1, !0)
              ), n.type = 0;
            else {
              var s = w.getBuffer(l);
              if (s)
                n.state = it, n.buffer = s, n.type = 0;
              else if (a.command(
                typeof l == "object" && l,
                "invalid data for attribute " + d,
                r.commandStr
              ), "constant" in l) {
                var f = l.constant;
                n.buffer = "null", n.state = Un, typeof f == "number" ? n.x = f : (a.command(
                  Ne(f) && f.length > 0 && f.length <= 4,
                  "invalid constant for attribute " + d,
                  r.commandStr
                ), at.forEach(function(M, ae) {
                  ae < f.length && (n[M] = f[ae]);
                }));
              } else {
                on(l.buffer) ? s = w.getBuffer(
                  w.create(l.buffer, ut, !1, !0)
                ) : s = w.getBuffer(l.buffer), a.command(!!s, 'missing buffer for attribute "' + d + '"', r.commandStr);
                var p = l.offset | 0;
                a.command(
                  p >= 0,
                  'invalid offset for attribute "' + d + '"',
                  r.commandStr
                );
                var b = l.stride | 0;
                a.command(
                  b >= 0 && b < 256,
                  'invalid stride for attribute "' + d + '", must be integer betweeen [0, 255]',
                  r.commandStr
                );
                var R = l.size | 0;
                a.command(
                  !("size" in l) || R > 0 && R <= 4,
                  'invalid size for attribute "' + d + '", must be 1,2,3,4',
                  r.commandStr
                );
                var U = !!l.normalized, V = 0;
                "type" in l && (a.commandParameter(
                  l.type,
                  Nr,
                  "invalid type for attribute " + d,
                  r.commandStr
                ), V = Nr[l.type]);
                var q = l.divisor | 0;
                a.optional(function() {
                  "divisor" in l && (a.command(
                    q === 0 || N,
                    'cannot specify divisor for attribute "' + d + '", instancing not supported',
                    r.commandStr
                  ), a.command(
                    q >= 0,
                    'invalid divisor for attribute "' + d + '"',
                    r.commandStr
                  ));
                  var M = r.commandStr, ae = [
                    "buffer",
                    "offset",
                    "divisor",
                    "normalized",
                    "type",
                    "size",
                    "stride"
                  ];
                  Object.keys(l).forEach(function(J) {
                    a.command(
                      ae.indexOf(J) >= 0,
                      'unknown parameter "' + J + '" for attribute pointer "' + d + '" (valid parameters are ' + ae + ")",
                      M
                    );
                  });
                }), n.buffer = s, n.state = it, n.size = R, n.normalized = U, n.type = V || s.dtype, n.offset = p, n.stride = b, n.divisor = q;
              }
            }
            _[d] = Me(function(M, ae) {
              var J = M.attribCache;
              if (m in J)
                return J[m];
              var te = {
                isStream: !1
              };
              return Object.keys(n).forEach(function(ne) {
                te[ne] = n[ne];
              }), n.buffer && (te.buffer = M.link(n.buffer), te.type = te.type || te.buffer + ".dtype"), J[m] = te, te;
            });
          }), Object.keys(h).forEach(function(d) {
            var l = h[d];
            function m(n, s) {
              var f = n.invoke(s, l), p = n.shared, b = n.constants, R = p.isBufferArgs, U = p.buffer;
              a.optional(function() {
                n.assert(
                  s,
                  f + "&&(typeof " + f + '==="object"||typeof ' + f + '==="function")&&(' + R + "(" + f + ")||" + U + ".getBuffer(" + f + ")||" + U + ".getBuffer(" + f + ".buffer)||" + R + "(" + f + '.buffer)||("constant" in ' + f + "&&(typeof " + f + '.constant==="number"||' + p.isArrayLike + "(" + f + ".constant))))",
                  'invalid dynamic attribute "' + d + '"'
                );
              });
              var V = {
                isStream: s.def(!1)
              }, q = new v();
              q.state = it, Object.keys(q).forEach(function(te) {
                V[te] = s.def("" + q[te]);
              });
              var M = V.buffer, ae = V.type;
              s(
                "if(",
                R,
                "(",
                f,
                ")){",
                V.isStream,
                "=true;",
                M,
                "=",
                U,
                ".createStream(",
                ut,
                ",",
                f,
                ");",
                ae,
                "=",
                M,
                ".dtype;",
                "}else{",
                M,
                "=",
                U,
                ".getBuffer(",
                f,
                ");",
                "if(",
                M,
                "){",
                ae,
                "=",
                M,
                ".dtype;",
                '}else if("constant" in ',
                f,
                "){",
                V.state,
                "=",
                Un,
                ";",
                "if(typeof " + f + '.constant === "number"){',
                V[at[0]],
                "=",
                f,
                ".constant;",
                at.slice(1).map(function(te) {
                  return V[te];
                }).join("="),
                "=0;",
                "}else{",
                at.map(function(te, ne) {
                  return V[te] + "=" + f + ".constant.length>" + ne + "?" + f + ".constant[" + ne + "]:0;";
                }).join(""),
                "}}else{",
                "if(",
                R,
                "(",
                f,
                ".buffer)){",
                M,
                "=",
                U,
                ".createStream(",
                ut,
                ",",
                f,
                ".buffer);",
                "}else{",
                M,
                "=",
                U,
                ".getBuffer(",
                f,
                ".buffer);",
                "}",
                ae,
                '="type" in ',
                f,
                "?",
                b.glTypes,
                "[",
                f,
                ".type]:",
                M,
                ".dtype;",
                V.normalized,
                "=!!",
                f,
                ".normalized;"
              );
              function J(te) {
                s(V[te], "=", f, ".", te, "|0;");
              }
              return J("size"), J("offset"), J("stride"), J("divisor"), s("}}"), s.exit(
                "if(",
                V.isStream,
                "){",
                U,
                ".destroyStream(",
                M,
                ");",
                "}"
              ), V;
            }
            _[d] = rr(l, m);
          }), _;
        }
        function Ge(i) {
          var r = i.static, c = i.dynamic, h = {};
          return Object.keys(r).forEach(function(_) {
            var d = r[_];
            h[_] = Me(function(l, m) {
              return typeof d == "number" || typeof d == "boolean" ? "" + d : l.link(d);
            });
          }), Object.keys(c).forEach(function(_) {
            var d = c[_];
            h[_] = rr(d, function(l, m) {
              return l.invoke(m, d);
            });
          }), h;
        }
        function Ue(i, r, c, h, _) {
          var d = i.static, l = i.dynamic;
          a.optional(function() {
            var J = [
              Mr,
              yt,
              Et,
              Ur,
              Vr,
              qt,
              zr,
              Qt,
              bt,
              xt
            ].concat(ue);
            function te(ne) {
              Object.keys(ne).forEach(function(ie) {
                a.command(
                  J.indexOf(ie) >= 0,
                  'unknown parameter "' + ie + '"',
                  _.commandStr
                );
              });
            }
            te(d), te(l);
          });
          var m = he(i, r), n = K(i), s = ce(i, n, _), f = De(i, _), p = Fe(i, _), b = Ee(i, _, m);
          function R(J) {
            var te = s[J];
            te && (p[J] = te);
          }
          R(Ar), R(re(Yt));
          var U = Object.keys(p).length > 0, V = {
            framebuffer: n,
            draw: f,
            shader: b,
            state: p,
            dirty: U,
            scopeVAO: null,
            drawVAO: null,
            useVAO: !1,
            attributes: {}
          };
          if (V.profile = Y(i), V.uniforms = Te(c, _), V.drawVAO = V.scopeVAO = f.vao, !V.drawVAO && b.program && !m && u.angle_instanced_arrays && f.static.elements) {
            var q = !0, M = b.program.attributes.map(function(J) {
              var te = r.static[J];
              return q = q && !!te, te;
            });
            if (q && M.length > 0) {
              var ae = I.getVAO(I.createVAO({
                attributes: M,
                elements: f.static.elements
              }));
              V.drawVAO = new $e(null, null, null, function(J, te) {
                return J.link(ae);
              }), V.useVAO = !0;
            }
          }
          return m ? V.useVAO = !0 : V.attributes = Ve(r, _), V.context = Ge(h), V;
        }
        function ze(i, r, c) {
          var h = i.shared, _ = h.context, d = i.scope();
          Object.keys(c).forEach(function(l) {
            r.save(_, "." + l);
            var m = c[l], n = m.append(i, r);
            Array.isArray(n) ? d(_, ".", l, "=[", n.join(), "];") : d(_, ".", l, "=", n, ";");
          }), r(d);
        }
        function He(i, r, c, h) {
          var _ = i.shared, d = _.gl, l = _.framebuffer, m;
          Z && (m = r.def(_.extensions, ".webgl_draw_buffers"));
          var n = i.constants, s = n.drawBuffer, f = n.backBuffer, p;
          c ? p = c.append(i, r) : p = r.def(l, ".next"), h || r("if(", p, "!==", l, ".cur){"), r(
            "if(",
            p,
            "){",
            d,
            ".bindFramebuffer(",
            af,
            ",",
            p,
            ".framebuffer);"
          ), Z && r(
            m,
            ".drawBuffersWEBGL(",
            s,
            "[",
            p,
            ".colorAttachments.length]);"
          ), r(
            "}else{",
            d,
            ".bindFramebuffer(",
            af,
            ",null);"
          ), Z && r(m, ".drawBuffersWEBGL(", f, ");"), r(
            "}",
            l,
            ".cur=",
            p,
            ";"
          ), h || r("}");
        }
        function We(i, r, c) {
          var h = i.shared, _ = h.gl, d = i.current, l = i.next, m = h.current, n = h.next, s = i.cond(m, ".dirty");
          ue.forEach(function(f) {
            var p = re(f);
            if (!(p in c.state)) {
              var b, R;
              if (p in l) {
                b = l[p], R = d[p];
                var U = ir(Q[p].length, function(q) {
                  return s.def(b, "[", q, "]");
                });
                s(i.cond(U.map(function(q, M) {
                  return q + "!==" + R + "[" + M + "]";
                }).join("||")).then(
                  _,
                  ".",
                  S[p],
                  "(",
                  U,
                  ");",
                  U.map(function(q, M) {
                    return R + "[" + M + "]=" + q;
                  }).join(";"),
                  ";"
                ));
              } else {
                b = s.def(n, ".", p);
                var V = i.cond(b, "!==", m, ".", p);
                s(V), p in L ? V(
                  i.cond(b).then(_, ".enable(", L[p], ");").else(_, ".disable(", L[p], ");"),
                  m,
                  ".",
                  p,
                  "=",
                  b,
                  ";"
                ) : V(
                  _,
                  ".",
                  S[p],
                  "(",
                  b,
                  ");",
                  m,
                  ".",
                  p,
                  "=",
                  b,
                  ";"
                );
              }
            }
          }), Object.keys(c.state).length === 0 && s(m, ".dirty=false;"), r(s);
        }
        function Qe(i, r, c, h) {
          var _ = i.shared, d = i.current, l = _.current, m = _.gl;
          uf(Object.keys(c)).forEach(function(n) {
            var s = c[n];
            if (!(h && !h(s))) {
              var f = s.append(i, r);
              if (L[n]) {
                var p = L[n];
                Gr(s) ? f ? r(m, ".enable(", p, ");") : r(m, ".disable(", p, ");") : r(i.cond(f).then(m, ".enable(", p, ");").else(m, ".disable(", p, ");")), r(l, ".", n, "=", f, ";");
              } else if (Ne(f)) {
                var b = d[n];
                r(
                  m,
                  ".",
                  S[n],
                  "(",
                  f,
                  ");",
                  f.map(function(R, U) {
                    return b + "[" + U + "]=" + R;
                  }).join(";"),
                  ";"
                );
              } else
                r(
                  m,
                  ".",
                  S[n],
                  "(",
                  f,
                  ");",
                  l,
                  ".",
                  n,
                  "=",
                  f,
                  ";"
                );
            }
          });
        }
        function Be(i, r) {
          N && (i.instancing = r.def(
            i.shared.extensions,
            ".angle_instanced_arrays"
          ));
        }
        function _e(i, r, c, h, _) {
          var d = i.shared, l = i.stats, m = d.current, n = d.timer, s = c.profile;
          function f() {
            return typeof performance > "u" ? "Date.now()" : "performance.now()";
          }
          var p, b;
          function R(J) {
            p = r.def(), J(p, "=", f(), ";"), typeof _ == "string" ? J(l, ".count+=", _, ";") : J(l, ".count++;"), D && (h ? (b = r.def(), J(b, "=", n, ".getNumPendingQueries();")) : J(n, ".beginQuery(", l, ");"));
          }
          function U(J) {
            J(l, ".cpuTime+=", f(), "-", p, ";"), D && (h ? J(
              n,
              ".pushScopeStats(",
              b,
              ",",
              n,
              ".getNumPendingQueries(),",
              l,
              ");"
            ) : J(n, ".endQuery();"));
          }
          function V(J) {
            var te = r.def(m, ".profile");
            r(m, ".profile=", J, ";"), r.exit(m, ".profile=", te, ";");
          }
          var q;
          if (s) {
            if (Gr(s)) {
              s.enable ? (R(r), U(r.exit), V("true")) : V("false");
              return;
            }
            q = s.append(i, r), V(q);
          } else
            q = r.def(m, ".profile");
          var M = i.block();
          R(M), r("if(", q, "){", M, "}");
          var ae = i.block();
          U(ae), r.exit("if(", q, "){", ae, "}");
        }
        function Ke(i, r, c, h, _) {
          var d = i.shared;
          function l(n) {
            switch (n) {
              case Kt:
              case en:
              case nn:
                return 2;
              case Zt:
              case rn:
              case an:
                return 3;
              case Jt:
              case tn:
              case fn:
                return 4;
              default:
                return 1;
            }
          }
          function m(n, s, f) {
            var p = d.gl, b = r.def(n, ".location"), R = r.def(d.attributes, "[", b, "]"), U = f.state, V = f.buffer, q = [
              f.x,
              f.y,
              f.z,
              f.w
            ], M = [
              "buffer",
              "normalized",
              "offset",
              "stride"
            ];
            function ae() {
              r(
                "if(!",
                R,
                ".buffer){",
                p,
                ".enableVertexAttribArray(",
                b,
                ");}"
              );
              var te = f.type, ne;
              if (f.size ? ne = r.def(f.size, "||", s) : ne = s, r(
                "if(",
                R,
                ".type!==",
                te,
                "||",
                R,
                ".size!==",
                ne,
                "||",
                M.map(function(le) {
                  return R + "." + le + "!==" + f[le];
                }).join("||"),
                "){",
                p,
                ".bindBuffer(",
                ut,
                ",",
                V,
                ".buffer);",
                p,
                ".vertexAttribPointer(",
                [
                  b,
                  ne,
                  te,
                  f.normalized,
                  f.stride,
                  f.offset
                ],
                ");",
                R,
                ".type=",
                te,
                ";",
                R,
                ".size=",
                ne,
                ";",
                M.map(function(le) {
                  return R + "." + le + "=" + f[le] + ";";
                }).join(""),
                "}"
              ), N) {
                var ie = f.divisor;
                r(
                  "if(",
                  R,
                  ".divisor!==",
                  ie,
                  "){",
                  i.instancing,
                  ".vertexAttribDivisorANGLE(",
                  [b, ie],
                  ");",
                  R,
                  ".divisor=",
                  ie,
                  ";}"
                );
              }
            }
            function J() {
              r(
                "if(",
                R,
                ".buffer){",
                p,
                ".disableVertexAttribArray(",
                b,
                ");",
                R,
                ".buffer=null;",
                "}if(",
                at.map(function(te, ne) {
                  return R + "." + te + "!==" + q[ne];
                }).join("||"),
                "){",
                p,
                ".vertexAttrib4f(",
                b,
                ",",
                q,
                ");",
                at.map(function(te, ne) {
                  return R + "." + te + "=" + q[ne] + ";";
                }).join(""),
                "}"
              );
            }
            U === it ? ae() : U === Un ? J() : (r("if(", U, "===", it, "){"), ae(), r("}else{"), J(), r("}"));
          }
          h.forEach(function(n) {
            var s = n.name, f = c.attributes[s], p;
            if (f) {
              if (!_(f))
                return;
              p = f.append(i, r);
            } else {
              if (!_(sf))
                return;
              var b = i.scopeAttrib(s);
              a.optional(function() {
                i.assert(
                  r,
                  b + ".state",
                  "missing attribute " + s
                );
              }), p = {}, Object.keys(new v()).forEach(function(R) {
                p[R] = r.def(b, ".", R);
              });
            }
            m(
              i.link(n),
              l(n.info.type),
              p
            );
          });
        }
        function Re(i, r, c, h, _, d) {
          for (var l = i.shared, m = l.gl, n, s = 0; s < h.length; ++s) {
            var f = h[s], p = f.name, b = f.info.type, R = c.uniforms[p], U = i.link(f), V = U + ".location", q;
            if (R) {
              if (!_(R))
                continue;
              if (Gr(R)) {
                var M = R.value;
                if (a.command(
                  M !== null && typeof M < "u",
                  'missing uniform "' + p + '"',
                  i.commandStr
                ), b === St || b === wt) {
                  a.command(
                    typeof M == "function" && (b === St && (M._reglType === "texture2d" || M._reglType === "framebuffer") || b === wt && (M._reglType === "textureCube" || M._reglType === "framebufferCube")),
                    "invalid texture for uniform " + p,
                    i.commandStr
                  );
                  var ae = i.link(M._texture || M.color[0]._texture);
                  r(m, ".uniform1i(", V, ",", ae + ".bind());"), r.exit(ae, ".unbind();");
                } else if (b === At || b === Tt || b === gt) {
                  a.optional(function() {
                    a.command(
                      Ne(M),
                      "invalid matrix for uniform " + p,
                      i.commandStr
                    ), a.command(
                      b === At && M.length === 4 || b === Tt && M.length === 9 || b === gt && M.length === 16,
                      "invalid length for matrix uniform " + p,
                      i.commandStr
                    );
                  });
                  var J = i.global.def("new Float32Array([" + Array.prototype.slice.call(M) + "])"), te = 2;
                  b === Tt ? te = 3 : b === gt && (te = 4), r(
                    m,
                    ".uniformMatrix",
                    te,
                    "fv(",
                    V,
                    ",false,",
                    J,
                    ");"
                  );
                } else {
                  switch (b) {
                    case na:
                      a.commandType(M, "number", "uniform " + p, i.commandStr), n = "1f";
                      break;
                    case Kt:
                      a.command(
                        Ne(M) && M.length === 2,
                        "uniform " + p,
                        i.commandStr
                      ), n = "2f";
                      break;
                    case Zt:
                      a.command(
                        Ne(M) && M.length === 3,
                        "uniform " + p,
                        i.commandStr
                      ), n = "3f";
                      break;
                    case Jt:
                      a.command(
                        Ne(M) && M.length === 4,
                        "uniform " + p,
                        i.commandStr
                      ), n = "4f";
                      break;
                    case ia:
                      a.commandType(M, "boolean", "uniform " + p, i.commandStr), n = "1i";
                      break;
                    case aa:
                      a.commandType(M, "number", "uniform " + p, i.commandStr), n = "1i";
                      break;
                    case nn:
                      a.command(
                        Ne(M) && M.length === 2,
                        "uniform " + p,
                        i.commandStr
                      ), n = "2i";
                      break;
                    case en:
                      a.command(
                        Ne(M) && M.length === 2,
                        "uniform " + p,
                        i.commandStr
                      ), n = "2i";
                      break;
                    case an:
                      a.command(
                        Ne(M) && M.length === 3,
                        "uniform " + p,
                        i.commandStr
                      ), n = "3i";
                      break;
                    case rn:
                      a.command(
                        Ne(M) && M.length === 3,
                        "uniform " + p,
                        i.commandStr
                      ), n = "3i";
                      break;
                    case fn:
                      a.command(
                        Ne(M) && M.length === 4,
                        "uniform " + p,
                        i.commandStr
                      ), n = "4i";
                      break;
                    case tn:
                      a.command(
                        Ne(M) && M.length === 4,
                        "uniform " + p,
                        i.commandStr
                      ), n = "4i";
                      break;
                  }
                  r(
                    m,
                    ".uniform",
                    n,
                    "(",
                    V,
                    ",",
                    Ne(M) ? Array.prototype.slice.call(M) : M,
                    ");"
                  );
                }
                continue;
              } else
                q = R.append(i, r);
            } else {
              if (!_(sf))
                continue;
              q = r.def(l.uniforms, "[", t.id(p), "]");
            }
            b === St ? (a(!Array.isArray(q), "must specify a scalar prop for textures"), r(
              "if(",
              q,
              "&&",
              q,
              '._reglType==="framebuffer"){',
              q,
              "=",
              q,
              ".color[0];",
              "}"
            )) : b === wt && (a(!Array.isArray(q), "must specify a scalar prop for cube maps"), r(
              "if(",
              q,
              "&&",
              q,
              '._reglType==="framebufferCube"){',
              q,
              "=",
              q,
              ".color[0];",
              "}"
            )), a.optional(function() {
              function Je(dr, pf) {
                i.assert(
                  r,
                  dr,
                  'bad data or missing for uniform "' + p + '".  ' + pf
                );
              }
              function br(dr) {
                a(!Array.isArray(q), "must not specify an array type for uniform"), Je(
                  "typeof " + q + '==="' + dr + '"',
                  "invalid type, expected " + dr
                );
              }
              function ur(dr, pf) {
                Array.isArray(q) ? a(q.length === dr, "must have length " + dr) : Je(
                  l.isArrayLike + "(" + q + ")&&" + q + ".length===" + dr,
                  "invalid vector, should have length " + dr,
                  i.commandStr
                );
              }
              function vf(dr) {
                a(!Array.isArray(q), "must not specify a value type"), Je(
                  "typeof " + q + '==="function"&&' + q + '._reglType==="texture' + (dr === Ji ? "2d" : "Cube") + '"',
                  "invalid texture type",
                  i.commandStr
                );
              }
              switch (b) {
                case aa:
                  br("number");
                  break;
                case en:
                  ur(2);
                  break;
                case rn:
                  ur(3);
                  break;
                case tn:
                  ur(4);
                  break;
                case na:
                  br("number");
                  break;
                case Kt:
                  ur(2);
                  break;
                case Zt:
                  ur(3);
                  break;
                case Jt:
                  ur(4);
                  break;
                case ia:
                  br("boolean");
                  break;
                case nn:
                  ur(2);
                  break;
                case an:
                  ur(3);
                  break;
                case fn:
                  ur(4);
                  break;
                case At:
                  ur(4);
                  break;
                case Tt:
                  ur(9);
                  break;
                case gt:
                  ur(16);
                  break;
                case St:
                  vf(Ji);
                  break;
                case wt:
                  vf(Os);
                  break;
              }
            });
            var ne = 1;
            switch (b) {
              case St:
              case wt:
                var ie = r.def(q, "._texture");
                r(m, ".uniform1i(", V, ",", ie, ".bind());"), r.exit(ie, ".unbind();");
                continue;
              case aa:
              case ia:
                n = "1i";
                break;
              case en:
              case nn:
                n = "2i", ne = 2;
                break;
              case rn:
              case an:
                n = "3i", ne = 3;
                break;
              case tn:
              case fn:
                n = "4i", ne = 4;
                break;
              case na:
                n = "1f";
                break;
              case Kt:
                n = "2f", ne = 2;
                break;
              case Zt:
                n = "3f", ne = 3;
                break;
              case Jt:
                n = "4f", ne = 4;
                break;
              case At:
                n = "Matrix2fv";
                break;
              case Tt:
                n = "Matrix3fv";
                break;
              case gt:
                n = "Matrix4fv";
                break;
            }
            if (n.charAt(0) === "M") {
              r(m, ".uniform", n, "(", V, ",");
              var le = Math.pow(b - At + 2, 2), Oe = i.global.def("new Float32Array(", le, ")");
              Array.isArray(q) ? r(
                "false,(",
                ir(le, function(Je) {
                  return Oe + "[" + Je + "]=" + q[Je];
                }),
                ",",
                Oe,
                ")"
              ) : r(
                "false,(Array.isArray(",
                q,
                ")||",
                q,
                " instanceof Float32Array)?",
                q,
                ":(",
                ir(le, function(Je) {
                  return Oe + "[" + Je + "]=" + q + "[" + Je + "]";
                }),
                ",",
                Oe,
                ")"
              ), r(");");
            } else if (ne > 1) {
              for (var Ye = [], Tr = [], gr = 0; gr < ne; ++gr)
                Array.isArray(q) ? Tr.push(q[gr]) : Tr.push(r.def(q + "[" + gr + "]")), d && Ye.push(r.def());
              d && r("if(!", i.batchId, "||", Ye.map(function(Je, br) {
                return Je + "!==" + Tr[br];
              }).join("||"), "){", Ye.map(function(Je, br) {
                return Je + "=" + Tr[br] + ";";
              }).join("")), r(m, ".uniform", n, "(", V, ",", Tr.join(","), ");"), d && r("}");
            } else {
              if (a(!Array.isArray(q), "uniform value must not be an array"), d) {
                var Sr = r.def();
                r(
                  "if(!",
                  i.batchId,
                  "||",
                  Sr,
                  "!==",
                  q,
                  "){",
                  Sr,
                  "=",
                  q,
                  ";"
                );
              }
              r(m, ".uniform", n, "(", V, ",", q, ");"), d && r("}");
            }
          }
        }
        function se(i, r, c, h) {
          var _ = i.shared, d = _.gl, l = _.draw, m = h.draw;
          function n() {
            var ne = m.elements, ie, le = r;
            return ne ? ((ne.contextDep && h.contextDynamic || ne.propDep) && (le = c), ie = ne.append(i, le), m.elementsActive && le(
              "if(" + ie + ")" + d + ".bindBuffer(" + ta + "," + ie + ".buffer.buffer);"
            )) : (ie = le.def(), le(
              ie,
              "=",
              l,
              ".",
              Ur,
              ";",
              "if(",
              ie,
              "){",
              d,
              ".bindBuffer(",
              ta,
              ",",
              ie,
              ".buffer.buffer);}",
              "else if(",
              _.vao,
              ".currentVAO){",
              ie,
              "=",
              i.shared.elements + ".getElements(" + _.vao,
              ".currentVAO.elements);",
              O ? "" : "if(" + ie + ")" + d + ".bindBuffer(" + ta + "," + ie + ".buffer.buffer);",
              "}"
            )), ie;
          }
          function s() {
            var ne = m.count, ie, le = r;
            return ne ? ((ne.contextDep && h.contextDynamic || ne.propDep) && (le = c), ie = ne.append(i, le), a.optional(function() {
              ne.MISSING && i.assert(r, "false", "missing vertex count"), ne.DYNAMIC && i.assert(le, ie + ">=0", "missing vertex count");
            })) : (ie = le.def(l, ".", zr), a.optional(function() {
              i.assert(le, ie + ">=0", "missing vertex count");
            })), ie;
          }
          var f = n();
          function p(ne) {
            var ie = m[ne];
            return ie ? ie.contextDep && h.contextDynamic || ie.propDep ? ie.append(i, c) : ie.append(i, r) : r.def(l, ".", ne);
          }
          var b = p(Vr), R = p(qt), U = s();
          if (typeof U == "number") {
            if (U === 0)
              return;
          } else
            c("if(", U, "){"), c.exit("}");
          var V, q;
          N && (V = p(Qt), q = i.instancing);
          var M = f + ".type", ae = m.elements && Gr(m.elements) && !m.vaoActive;
          function J() {
            function ne() {
              c(q, ".drawElementsInstancedANGLE(", [
                b,
                U,
                M,
                R + "<<((" + M + "-" + Di + ")>>1)",
                V
              ], ");");
            }
            function ie() {
              c(
                q,
                ".drawArraysInstancedANGLE(",
                [b, R, U, V],
                ");"
              );
            }
            f && f !== "null" ? ae ? ne() : (c("if(", f, "){"), ne(), c("}else{"), ie(), c("}")) : ie();
          }
          function te() {
            function ne() {
              c(d + ".drawElements(" + [
                b,
                U,
                M,
                R + "<<((" + M + "-" + Di + ")>>1)"
              ] + ");");
            }
            function ie() {
              c(d + ".drawArrays(" + [b, R, U] + ");");
            }
            f && f !== "null" ? ae ? ne() : (c("if(", f, "){"), ne(), c("}else{"), ie(), c("}")) : ie();
          }
          N && (typeof V != "number" || V >= 0) ? typeof V == "string" ? (c("if(", V, ">0){"), J(), c("}else if(", V, "<0){"), te(), c("}")) : J() : te();
        }
        function xe(i, r, c, h, _) {
          var d = de(), l = d.proc("body", _);
          return a.optional(function() {
            d.commandStr = r.commandStr, d.command = d.link(r.commandStr);
          }), N && (d.instancing = l.def(
            d.shared.extensions,
            ".angle_instanced_arrays"
          )), i(d, l, c, h), d.compile().body;
        }
        function we(i, r, c, h) {
          Be(i, r), c.useVAO ? c.drawVAO ? r(i.shared.vao, ".setVAO(", c.drawVAO.append(i, r), ");") : r(i.shared.vao, ".setVAO(", i.shared.vao, ".targetVAO);") : (r(i.shared.vao, ".setVAO(null);"), Ke(i, r, c, h.attributes, function() {
            return !0;
          })), Re(i, r, c, h.uniforms, function() {
            return !0;
          }, !1), se(i, r, r, c);
        }
        function Ie(i, r) {
          var c = i.proc("draw", 1);
          Be(i, c), ze(i, c, r.context), He(i, c, r.framebuffer), We(i, c, r), Qe(i, c, r.state), _e(i, c, r, !1, !0);
          var h = r.shader.progVar.append(i, c);
          if (c(i.shared.gl, ".useProgram(", h, ".program);"), r.shader.program)
            we(i, c, r, r.shader.program);
          else {
            c(i.shared.vao, ".setVAO(null);");
            var _ = i.global.def("{}"), d = c.def(h, ".id"), l = c.def(_, "[", d, "]");
            c(
              i.cond(l).then(l, ".call(this,a0);").else(
                l,
                "=",
                _,
                "[",
                d,
                "]=",
                i.link(function(m) {
                  return xe(we, i, r, m, 1);
                }),
                "(",
                h,
                ");",
                l,
                ".call(this,a0);"
              )
            );
          }
          Object.keys(r.state).length > 0 && c(i.shared.current, ".dirty=true;"), i.shared.vao && c(i.shared.vao, ".setVAO(null);");
        }
        function _r(i, r, c, h) {
          i.batchId = "a1", Be(i, r);
          function _() {
            return !0;
          }
          Ke(i, r, c, h.attributes, _), Re(i, r, c, h.uniforms, _, !1), se(i, r, r, c);
        }
        function jr(i, r, c, h) {
          Be(i, r);
          var _ = c.contextDep, d = r.def(), l = "a0", m = "a1", n = r.def();
          i.shared.props = n, i.batchId = d;
          var s = i.scope(), f = i.scope();
          r(
            s.entry,
            "for(",
            d,
            "=0;",
            d,
            "<",
            m,
            ";++",
            d,
            "){",
            n,
            "=",
            l,
            "[",
            d,
            "];",
            f,
            "}",
            s.exit
          );
          function p(M) {
            return M.contextDep && _ || M.propDep;
          }
          function b(M) {
            return !p(M);
          }
          if (c.needsContext && ze(i, f, c.context), c.needsFramebuffer && He(i, f, c.framebuffer), Qe(i, f, c.state, p), c.profile && p(c.profile) && _e(i, f, c, !1, !0), h)
            c.useVAO ? c.drawVAO ? p(c.drawVAO) ? f(i.shared.vao, ".setVAO(", c.drawVAO.append(i, f), ");") : s(i.shared.vao, ".setVAO(", c.drawVAO.append(i, s), ");") : s(i.shared.vao, ".setVAO(", i.shared.vao, ".targetVAO);") : (s(i.shared.vao, ".setVAO(null);"), Ke(i, s, c, h.attributes, b), Ke(i, f, c, h.attributes, p)), Re(i, s, c, h.uniforms, b, !1), Re(i, f, c, h.uniforms, p, !0), se(i, s, f, c);
          else {
            var R = i.global.def("{}"), U = c.shader.progVar.append(i, f), V = f.def(U, ".id"), q = f.def(R, "[", V, "]");
            f(
              i.shared.gl,
              ".useProgram(",
              U,
              ".program);",
              "if(!",
              q,
              "){",
              q,
              "=",
              R,
              "[",
              V,
              "]=",
              i.link(function(M) {
                return xe(
                  _r,
                  i,
                  c,
                  M,
                  2
                );
              }),
              "(",
              U,
              ");}",
              q,
              ".call(this,a0[",
              d,
              "],",
              d,
              ");"
            );
          }
        }
        function o(i, r) {
          var c = i.proc("batch", 2);
          i.batchId = "0", Be(i, c);
          var h = !1, _ = !0;
          Object.keys(r.context).forEach(function(R) {
            h = h || r.context[R].propDep;
          }), h || (ze(i, c, r.context), _ = !1);
          var d = r.framebuffer, l = !1;
          d ? (d.propDep ? h = l = !0 : d.contextDep && h && (l = !0), l || He(i, c, d)) : He(i, c, null), r.state.viewport && r.state.viewport.propDep && (h = !0);
          function m(R) {
            return R.contextDep && h || R.propDep;
          }
          We(i, c, r), Qe(i, c, r.state, function(R) {
            return !m(R);
          }), (!r.profile || !m(r.profile)) && _e(i, c, r, !1, "a1"), r.contextDep = h, r.needsContext = _, r.needsFramebuffer = l;
          var n = r.shader.progVar;
          if (n.contextDep && h || n.propDep)
            jr(
              i,
              c,
              r,
              null
            );
          else {
            var s = n.append(i, c);
            if (c(i.shared.gl, ".useProgram(", s, ".program);"), r.shader.program)
              jr(
                i,
                c,
                r,
                r.shader.program
              );
            else {
              c(i.shared.vao, ".setVAO(null);");
              var f = i.global.def("{}"), p = c.def(s, ".id"), b = c.def(f, "[", p, "]");
              c(
                i.cond(b).then(b, ".call(this,a0,a1);").else(
                  b,
                  "=",
                  f,
                  "[",
                  p,
                  "]=",
                  i.link(function(R) {
                    return xe(jr, i, r, R, 2);
                  }),
                  "(",
                  s,
                  ");",
                  b,
                  ".call(this,a0,a1);"
                )
              );
            }
          }
          Object.keys(r.state).length > 0 && c(i.shared.current, ".dirty=true;"), i.shared.vao && c(i.shared.vao, ".setVAO(null);");
        }
        function A(i, r) {
          var c = i.proc("scope", 3);
          i.batchId = "a2";
          var h = i.shared, _ = h.current;
          ze(i, c, r.context), r.framebuffer && r.framebuffer.append(i, c), uf(Object.keys(r.state)).forEach(function(l) {
            var m = r.state[l], n = m.append(i, c);
            Ne(n) ? n.forEach(function(s, f) {
              c.set(i.next[l], "[" + f + "]", s);
            }) : c.set(h.next, "." + l, n);
          }), _e(i, c, r, !0, !0), [Ur, qt, zr, Qt, Vr].forEach(
            function(l) {
              var m = r.draw[l];
              m && c.set(h.draw, "." + l, "" + m.append(i, c));
            }
          ), Object.keys(r.uniforms).forEach(function(l) {
            var m = r.uniforms[l].append(i, c);
            Array.isArray(m) && (m = "[" + m.join() + "]"), c.set(
              h.uniforms,
              "[" + t.id(l) + "]",
              m
            );
          }), Object.keys(r.attributes).forEach(function(l) {
            var m = r.attributes[l].append(i, c), n = i.scopeAttrib(l);
            Object.keys(new v()).forEach(function(s) {
              c.set(n, "." + s, m[s]);
            });
          }), r.scopeVAO && c.set(h.vao, ".targetVAO", r.scopeVAO.append(i, c));
          function d(l) {
            var m = r.shader[l];
            m && c.set(h.shader, "." + l, m.append(i, c));
          }
          d(yt), d(Et), Object.keys(r.state).length > 0 && (c(_, ".dirty=true;"), c.exit(_, ".dirty=true;")), c("a1(", i.shared.context, ",a0,", i.batchId, ");");
        }
        function y(i) {
          if (!(typeof i != "object" || Ne(i))) {
            for (var r = Object.keys(i), c = 0; c < r.length; ++c)
              if (ar.isDynamic(i[r[c]]))
                return !0;
            return !1;
          }
        }
        function ee(i, r, c) {
          var h = r.static[c];
          if (!h || !y(h))
            return;
          var _ = i.global, d = Object.keys(h), l = !1, m = !1, n = !1, s = i.global.def("{}");
          d.forEach(function(p) {
            var b = h[p];
            if (ar.isDynamic(b)) {
              typeof b == "function" && (b = h[p] = ar.unbox(b));
              var R = rr(b, null);
              l = l || R.thisDep, n = n || R.propDep, m = m || R.contextDep;
            } else {
              switch (_(s, ".", p, "="), typeof b) {
                case "number":
                  _(b);
                  break;
                case "string":
                  _('"', b, '"');
                  break;
                case "object":
                  Array.isArray(b) && _("[", b.join(), "]");
                  break;
                default:
                  _(i.link(b));
                  break;
              }
              _(";");
            }
          });
          function f(p, b) {
            d.forEach(function(R) {
              var U = h[R];
              if (ar.isDynamic(U)) {
                var V = p.invoke(b, U);
                b(s, ".", R, "=", V, ";");
              }
            });
          }
          r.dynamic[c] = new ar.DynamicVariable(Wt, {
            thisDep: l,
            contextDep: m,
            propDep: n,
            ref: s,
            append: f
          }), delete r.static[c];
        }
        function ye(i, r, c, h, _) {
          var d = de();
          d.stats = d.link(_), Object.keys(r.static).forEach(function(m) {
            ee(d, r, m);
          }), ws.forEach(function(m) {
            ee(d, i, m);
          });
          var l = Ue(i, r, c, h, d);
          return Ie(d, l), A(d, l), o(d, l), oe(d.compile(), {
            destroy: function() {
              l.shader.program.destroy();
            }
          });
        }
        return {
          next: W,
          current: Q,
          procs: (function() {
            var i = de(), r = i.proc("poll"), c = i.proc("refresh"), h = i.block();
            r(h), c(h);
            var _ = i.shared, d = _.gl, l = _.next, m = _.current;
            h(m, ".dirty=false;"), He(i, r), He(i, c, null, !0);
            var n;
            N && (n = i.link(N)), u.oes_vertex_array_object && c(i.link(u.oes_vertex_array_object), ".bindVertexArrayOES(null);");
            for (var s = 0; s < x.maxAttributes; ++s) {
              var f = c.def(_.attributes, "[", s, "]"), p = i.cond(f, ".buffer");
              p.then(
                d,
                ".enableVertexAttribArray(",
                s,
                ");",
                d,
                ".bindBuffer(",
                ut,
                ",",
                f,
                ".buffer.buffer);",
                d,
                ".vertexAttribPointer(",
                s,
                ",",
                f,
                ".size,",
                f,
                ".type,",
                f,
                ".normalized,",
                f,
                ".stride,",
                f,
                ".offset);"
              ).else(
                d,
                ".disableVertexAttribArray(",
                s,
                ");",
                d,
                ".vertexAttrib4f(",
                s,
                ",",
                f,
                ".x,",
                f,
                ".y,",
                f,
                ".z,",
                f,
                ".w);",
                f,
                ".buffer=null;"
              ), c(p), N && c(
                n,
                ".vertexAttribDivisorANGLE(",
                s,
                ",",
                f,
                ".divisor);"
              );
            }
            return c(
              i.shared.vao,
              ".currentVAO=null;",
              i.shared.vao,
              ".setVAO(",
              i.shared.vao,
              ".targetVAO);"
            ), Object.keys(L).forEach(function(b) {
              var R = L[b], U = h.def(l, ".", b), V = i.block();
              V(
                "if(",
                U,
                "){",
                d,
                ".enable(",
                R,
                ")}else{",
                d,
                ".disable(",
                R,
                ")}",
                m,
                ".",
                b,
                "=",
                U,
                ";"
              ), c(V), r(
                "if(",
                U,
                "!==",
                m,
                ".",
                b,
                "){",
                V,
                "}"
              );
            }), Object.keys(S).forEach(function(b) {
              var R = S[b], U = Q[b], V, q, M = i.block();
              if (M(d, ".", R, "("), Ne(U)) {
                var ae = U.length;
                V = i.global.def(l, ".", b), q = i.global.def(m, ".", b), M(
                  ir(ae, function(J) {
                    return V + "[" + J + "]";
                  }),
                  ");",
                  ir(ae, function(J) {
                    return q + "[" + J + "]=" + V + "[" + J + "];";
                  }).join("")
                ), r(
                  "if(",
                  ir(ae, function(J) {
                    return V + "[" + J + "]!==" + q + "[" + J + "]";
                  }).join("||"),
                  "){",
                  M,
                  "}"
                );
              } else
                V = h.def(l, ".", b), q = h.def(m, ".", b), M(
                  V,
                  ");",
                  m,
                  ".",
                  b,
                  "=",
                  V,
                  ";"
                ), r(
                  "if(",
                  V,
                  "!==",
                  q,
                  "){",
                  M,
                  "}"
                );
              c(M);
            }), i.compile();
          })(),
          compile: ye
        };
      }
      function $s() {
        return {
          vaoCount: 0,
          bufferCount: 0,
          elementsCount: 0,
          framebufferCount: 0,
          shaderCount: 0,
          textureCount: 0,
          cubeCount: 0,
          renderbufferCount: 0,
          maxTextureUnits: 0
        };
      }
      var Xs = 34918, Ws = 34919, cf = 35007, Ys = function(e, t) {
        if (!t.ext_disjoint_timer_query)
          return null;
        var u = [];
        function x() {
          return u.pop() || t.ext_disjoint_timer_query.createQueryEXT();
        }
        function w(N) {
          u.push(N);
        }
        var E = [];
        function g(N) {
          var Z = x();
          t.ext_disjoint_timer_query.beginQueryEXT(cf, Z), E.push(Z), D(E.length - 1, E.length, N);
        }
        function G() {
          t.ext_disjoint_timer_query.endQueryEXT(cf);
        }
        function C() {
          this.startQueryIndex = -1, this.endQueryIndex = -1, this.sum = 0, this.stats = null;
        }
        var I = [];
        function k() {
          return I.pop() || new C();
        }
        function P(N) {
          I.push(N);
        }
        var z = [];
        function D(N, Z, O) {
          var Q = k();
          Q.startQueryIndex = N, Q.endQueryIndex = Z, Q.sum = 0, Q.stats = O, z.push(Q);
        }
        var B = [], v = [];
        function T() {
          var N, Z, O = E.length;
          if (O !== 0) {
            v.length = Math.max(v.length, O + 1), B.length = Math.max(B.length, O + 1), B[0] = 0, v[0] = 0;
            var Q = 0;
            for (N = 0, Z = 0; Z < E.length; ++Z) {
              var W = E[Z];
              t.ext_disjoint_timer_query.getQueryObjectEXT(W, Ws) ? (Q += t.ext_disjoint_timer_query.getQueryObjectEXT(W, Xs), w(W)) : E[N++] = W, B[Z + 1] = Q, v[Z + 1] = N;
            }
            for (E.length = N, N = 0, Z = 0; Z < z.length; ++Z) {
              var ue = z[Z], L = ue.startQueryIndex, S = ue.endQueryIndex;
              ue.sum += B[S] - B[L];
              var re = v[L], H = v[S];
              H === re ? (ue.stats.gpuTime += ue.sum / 1e6, P(ue)) : (ue.startQueryIndex = re, ue.endQueryIndex = H, z[N++] = ue);
            }
            z.length = N;
          }
        }
        return {
          beginQuery: g,
          endQuery: G,
          pushScopeStats: D,
          update: T,
          getNumPendingQueries: function() {
            return E.length;
          },
          clear: function() {
            u.push.apply(u, E);
            for (var N = 0; N < u.length; N++)
              t.ext_disjoint_timer_query.deleteQueryEXT(u[N]);
            E.length = 0, u.length = 0;
          },
          restore: function() {
            E.length = 0, u.length = 0;
          }
        };
      }, qs = 16384, Qs = 256, Ks = 1024, Zs = 34962, lf = "webglcontextlost", df = "webglcontextrestored", mf = 1, Js = 2, ec = 3;
      function hf(e, t) {
        for (var u = 0; u < e.length; ++u)
          if (e[u] === t)
            return u;
        return -1;
      }
      function rc(e) {
        var t = Zf(e);
        if (!t)
          return null;
        var u = t.gl, x = u.getContextAttributes(), w = u.isContextLost(), E = Jf(u, t);
        if (!E)
          return null;
        var g = Wf(), G = $s(), C = E.extensions, I = Ys(u, C), k = xa(), P = u.drawingBufferWidth, z = u.drawingBufferHeight, D = {
          tick: 0,
          time: 0,
          viewportWidth: P,
          viewportHeight: z,
          framebufferWidth: P,
          framebufferHeight: z,
          drawingBufferWidth: P,
          drawingBufferHeight: z,
          pixelRatio: t.pixelRatio
        }, B = {}, v = {
          elements: null,
          primitive: 4,
          // GL_TRIANGLES
          count: -1,
          offset: 0,
          instances: -1
        }, T = Vo(u, C), N = nu(
          u,
          G,
          t,
          Q
        ), Z = vu(u, C, N, G), O = vs(
          u,
          C,
          T,
          G,
          N,
          Z,
          v
        );
        function Q(se) {
          return O.destroyBuffer(se);
        }
        var W = ys(u, g, G, t), ue = Xu(
          u,
          C,
          T,
          function() {
            re.procs.poll();
          },
          D,
          G,
          t
        ), L = Wu(u, C, T, G, t), S = ms(
          u,
          C,
          T,
          ue,
          L,
          G
        ), re = js(
          u,
          g,
          C,
          T,
          N,
          Z,
          ue,
          S,
          B,
          O,
          W,
          v,
          D,
          I,
          t
        ), H = As(
          u,
          S,
          re.procs.poll,
          D,
          x,
          C,
          T
        ), F = re.next, $ = u.canvas, X = [], ve = [], de = [], Y = [t.onDestroy], K = null;
        function ce() {
          if (X.length === 0) {
            I && I.update(), K = null;
            return;
          }
          K = dn.next(ce), Qe();
          for (var se = X.length - 1; se >= 0; --se) {
            var xe = X[se];
            xe && xe(D, null, 0);
          }
          u.flush(), I && I.update();
        }
        function he() {
          !K && X.length > 0 && (K = dn.next(ce));
        }
        function Ee() {
          K && (dn.cancel(ce), K = null);
        }
        function De(se) {
          se.preventDefault(), w = !0, Ee(), ve.forEach(function(xe) {
            xe();
          });
        }
        function Fe(se) {
          u.getError(), w = !1, E.restore(), W.restore(), N.restore(), ue.restore(), L.restore(), S.restore(), O.restore(), I && I.restore(), re.procs.refresh(), he(), de.forEach(function(xe) {
            xe();
          });
        }
        $ && ($.addEventListener(lf, De, !1), $.addEventListener(df, Fe, !1));
        function Te() {
          X.length = 0, Ee(), $ && ($.removeEventListener(lf, De), $.removeEventListener(df, Fe)), W.clear(), S.clear(), L.clear(), O.clear(), ue.clear(), Z.clear(), N.clear(), I && I.clear(), Y.forEach(function(se) {
            se();
          });
        }
        function Ve(se) {
          a(!!se, "invalid args to regl({...})"), a.type(se, "object", "invalid args to regl({...})");
          function xe(_) {
            var d = oe({}, _);
            delete d.uniforms, delete d.attributes, delete d.context, delete d.vao, "stencil" in d && d.stencil.op && (d.stencil.opBack = d.stencil.opFront = d.stencil.op, delete d.stencil.op);
            function l(m) {
              if (m in d) {
                var n = d[m];
                delete d[m], Object.keys(n).forEach(function(s) {
                  d[m + "." + s] = n[s];
                });
              }
            }
            return l("blend"), l("depth"), l("cull"), l("stencil"), l("polygonOffset"), l("scissor"), l("sample"), "vao" in _ && (d.vao = _.vao), d;
          }
          function we(_, d) {
            var l = {}, m = {};
            return Object.keys(_).forEach(function(n) {
              var s = _[n];
              if (ar.isDynamic(s)) {
                m[n] = ar.unbox(s, n);
                return;
              } else if (d && Array.isArray(s)) {
                for (var f = 0; f < s.length; ++f)
                  if (ar.isDynamic(s[f])) {
                    m[n] = ar.unbox(s, n);
                    return;
                  }
              }
              l[n] = s;
            }), {
              dynamic: m,
              static: l
            };
          }
          var Ie = we(se.context || {}, !0), _r = we(se.uniforms || {}, !0), jr = we(se.attributes || {}, !1), o = we(xe(se), !1), A = {
            gpuTime: 0,
            cpuTime: 0,
            count: 0
          }, y = re.compile(o, jr, _r, Ie, A), ee = y.draw, ye = y.batch, i = y.scope, r = [];
          function c(_) {
            for (; r.length < _; )
              r.push(null);
            return r;
          }
          function h(_, d) {
            var l;
            if (w && a.raise("context lost"), typeof _ == "function")
              return i.call(this, null, _, 0);
            if (typeof d == "function")
              if (typeof _ == "number")
                for (l = 0; l < _; ++l)
                  i.call(this, null, d, l);
              else if (Array.isArray(_))
                for (l = 0; l < _.length; ++l)
                  i.call(this, _[l], d, l);
              else
                return i.call(this, _, d, 0);
            else if (typeof _ == "number") {
              if (_ > 0)
                return ye.call(this, c(_ | 0), _ | 0);
            } else if (Array.isArray(_)) {
              if (_.length)
                return ye.call(this, _, _.length);
            } else
              return ee.call(this, _);
          }
          return oe(h, {
            stats: A,
            destroy: function() {
              y.destroy();
            }
          });
        }
        var Ge = S.setFBO = Ve({
          framebuffer: ar.define.call(null, mf, "framebuffer")
        });
        function Ue(se, xe) {
          var we = 0;
          re.procs.poll();
          var Ie = xe.color;
          Ie && (u.clearColor(+Ie[0] || 0, +Ie[1] || 0, +Ie[2] || 0, +Ie[3] || 0), we |= qs), "depth" in xe && (u.clearDepth(+xe.depth), we |= Qs), "stencil" in xe && (u.clearStencil(xe.stencil | 0), we |= Ks), a(!!we, "called regl.clear with no buffer specified"), u.clear(we);
        }
        function ze(se) {
          if (a(
            typeof se == "object" && se,
            "regl.clear() takes an object as input"
          ), "framebuffer" in se)
            if (se.framebuffer && se.framebuffer_reglType === "framebufferCube")
              for (var xe = 0; xe < 6; ++xe)
                Ge(oe({
                  framebuffer: se.framebuffer.faces[xe]
                }, se), Ue);
            else
              Ge(se, Ue);
          else
            Ue(null, se);
        }
        function He(se) {
          a.type(se, "function", "regl.frame() callback must be a function"), X.push(se);
          function xe() {
            var we = hf(X, se);
            a(we >= 0, "cannot cancel a frame twice");
            function Ie() {
              var _r = hf(X, Ie);
              X[_r] = X[X.length - 1], X.length -= 1, X.length <= 0 && Ee();
            }
            X[we] = Ie;
          }
          return he(), {
            cancel: xe
          };
        }
        function We() {
          var se = F.viewport, xe = F.scissor_box;
          se[0] = se[1] = xe[0] = xe[1] = 0, D.viewportWidth = D.framebufferWidth = D.drawingBufferWidth = se[2] = xe[2] = u.drawingBufferWidth, D.viewportHeight = D.framebufferHeight = D.drawingBufferHeight = se[3] = xe[3] = u.drawingBufferHeight;
        }
        function Qe() {
          D.tick += 1, D.time = _e(), We(), re.procs.poll();
        }
        function Be() {
          ue.refresh(), We(), re.procs.refresh(), I && I.update();
        }
        function _e() {
          return (xa() - k) / 1e3;
        }
        Be();
        function Ke(se, xe) {
          a.type(xe, "function", "listener callback must be a function");
          var we;
          switch (se) {
            case "frame":
              return He(xe);
            case "lost":
              we = ve;
              break;
            case "restore":
              we = de;
              break;
            case "destroy":
              we = Y;
              break;
            default:
              a.raise("invalid event, must be one of frame,lost,restore,destroy");
          }
          return we.push(xe), {
            cancel: function() {
              for (var Ie = 0; Ie < we.length; ++Ie)
                if (we[Ie] === xe) {
                  we[Ie] = we[we.length - 1], we.pop();
                  return;
                }
            }
          };
        }
        var Re = oe(Ve, {
          // Clear current FBO
          clear: ze,
          // Short cuts for dynamic variables
          prop: ar.define.bind(null, mf),
          context: ar.define.bind(null, Js),
          this: ar.define.bind(null, ec),
          // executes an empty draw command
          draw: Ve({}),
          // Resources
          buffer: function(se) {
            return N.create(se, Zs, !1, !1);
          },
          elements: function(se) {
            return Z.create(se, !1);
          },
          texture: ue.create2D,
          cube: ue.createCube,
          renderbuffer: L.create,
          framebuffer: S.create,
          framebufferCube: S.createCube,
          vao: O.createVAO,
          // Expose context attributes
          attributes: x,
          // Frame rendering
          frame: He,
          on: Ke,
          // System limits
          limits: T,
          hasExtension: function(se) {
            return T.extensions.indexOf(se.toLowerCase()) >= 0;
          },
          // Read pixels
          read: H,
          // Destroy regl and all associated resources
          destroy: Te,
          // Direct GL state manipulation
          _gl: u,
          _refresh: Be,
          poll: function() {
            Qe(), I && I.update();
          },
          // Current time
          now: _e,
          // regl Statistics Information
          stats: G
        });
        return t.onDone(null, Re), Re;
      }
      return rc;
    }));
  })(un)), un.exports;
}
var ic = ac();
const fc = /* @__PURE__ */ tc(ic);
function Ef() {
  return sn([
    [0, 1e-3, 0, 0.014],
    [32, 0.122, 6e-3, 0.262],
    [64, 0.329, 0.01, 0.407],
    [96, 0.533, 0.068, 0.352],
    [128, 0.729, 0.212, 0.227],
    [160, 0.891, 0.393, 0.101],
    [192, 0.981, 0.588, 0.024],
    [224, 0.993, 0.802, 0.162],
    [255, 0.988, 0.998, 0.645]
  ]);
}
function oc() {
  return sn([
    [0, 0.267, 4e-3, 0.329],
    [32, 0.282, 0.14, 0.458],
    [64, 0.254, 0.265, 0.53],
    [96, 0.206, 0.372, 0.553],
    [128, 0.163, 0.471, 0.558],
    [160, 0.128, 0.567, 0.551],
    [192, 0.134, 0.658, 0.517],
    [224, 0.267, 0.749, 0.441],
    [255, 0.993, 0.906, 0.144]
  ]);
}
function uc() {
  return sn([
    [0, 0.05, 0.03, 0.53],
    [32, 0.28, 0.01, 0.63],
    [64, 0.49, 0.01, 0.66],
    [96, 0.66, 0.06, 0.57],
    [128, 0.8, 0.16, 0.43],
    [160, 0.9, 0.29, 0.3],
    [192, 0.97, 0.44, 0.16],
    [224, 0.99, 0.62, 0.04],
    [255, 0.94, 0.98, 0.13]
  ]);
}
function sc() {
  return sn([
    [0, 1e-3, 0, 0.014],
    [32, 0.1, 0.03, 0.26],
    [64, 0.27, 0.04, 0.43],
    [96, 0.45, 0.07, 0.48],
    [128, 0.64, 0.13, 0.44],
    [160, 0.83, 0.24, 0.37],
    [192, 0.95, 0.44, 0.38],
    [224, 0.99, 0.68, 0.53],
    [255, 0.99, 0.99, 0.75]
  ]);
}
function cc() {
  const j = new Float32Array(768);
  for (let ge = 0; ge < 256; ge++) {
    const fe = ge / 255;
    j[ge * 3] = fe, j[ge * 3 + 1] = fe, j[ge * 3 + 2] = fe;
  }
  return j;
}
function sn(j) {
  const ge = new Float32Array(768);
  for (let fe = 0; fe < 256; fe++) {
    let oe = 0;
    for (let be = 0; be < j.length - 1; be++)
      fe >= j[be][0] && (oe = be);
    const Se = Math.min(oe + 1, j.length - 1), pe = j[Se][0] - j[oe][0], me = pe > 0 ? (fe - j[oe][0]) / pe : 0;
    ge[fe * 3] = j[oe][1] + me * (j[Se][1] - j[oe][1]), ge[fe * 3 + 1] = j[oe][2] + me * (j[Se][2] - j[oe][2]), ge[fe * 3 + 2] = j[oe][3] + me * (j[Se][3] - j[oe][3]);
  }
  return ge;
}
const lc = {
  inferno: Ef,
  viridis: oc,
  plasma: uc,
  magma: sc,
  grayscale: cc
};
function bf(j) {
  const ge = lc[j];
  return ge ? ge() : (console.warn(`Unknown colormap "${j}", falling back to inferno`), Ef());
}
const $r = Math.PI / 180;
function dc(j, ge, fe, oe, Se) {
  const pe = ge * fe, me = new Uint8Array(pe * 4), be = Se - oe || 1e-30;
  for (let Le = 0; Le < pe; Le++) {
    const Ae = j[Le];
    if (Ae !== Ae || !isFinite(Ae)) {
      me[Le * 4 + 3] = 0;
      continue;
    }
    let Ce = (Ae - oe) / be;
    Ce = Ce < 0 ? 0 : Ce > 1 ? 1 : Ce, me[Le * 4] = Ce * 255 + 0.5 | 0, me[Le * 4 + 1] = 0, me[Le * 4 + 2] = 0, me[Le * 4 + 3] = 255;
  }
  return me;
}
function yf(j) {
  const ge = j.length / 3, fe = new Uint8Array(ge * 4);
  for (let oe = 0; oe < ge; oe++)
    fe[oe * 4] = j[oe * 3] * 255 + 0.5 | 0, fe[oe * 4 + 1] = j[oe * 3 + 1] * 255 + 0.5 | 0, fe[oe * 4 + 2] = j[oe * 3 + 2] * 255 + 0.5 | 0, fe[oe * 4 + 3] = 255;
  return fe;
}
const mc = `
precision highp float;

uniform sampler2D u_image;
uniform sampler2D u_colormap;
uniform vec2 u_crval;       // phase center (RA, Dec) in radians
uniform vec2 u_cdelt;       // pixel scale in radians
uniform vec2 u_crpix;       // reference pixel (1-based)
uniform vec2 u_imageSize;   // (width, height) in pixels
uniform vec2 u_viewCenter;  // view center (RA, Dec) in radians
uniform float u_fov;        // field of view in radians
uniform float u_opacity;
uniform int u_stretch;      // 0=linear, 1=log, 2=sqrt, 3=asinh
uniform vec2 u_resolution;  // canvas (width, height)

void main() {
    // Normalized screen coordinates [-1, 1]
    vec2 screen = (gl_FragCoord.xy / u_resolution) * 2.0 - 1.0;
    float aspect = u_resolution.x / u_resolution.y;

    // Inverse gnomonic projection: screen -> (RA, Dec) from view center
    float scale = tan(u_fov * 0.5);
    float lView = -screen.x * scale * aspect;
    float mView = screen.y * scale;

    float r = sqrt(lView * lView + mView * mView);
    float c = atan(r);
    float sinc = sin(c);
    float cosc = cos(c);

    float sinDec0 = sin(u_viewCenter.y);
    float cosDec0 = cos(u_viewCenter.y);

    float dec, ra;
    if (r < 1.0e-10) {
        dec = u_viewCenter.y;
        ra = u_viewCenter.x;
    } else {
        dec = asin(cosc * sinDec0 + (mView * sinc * cosDec0) / r);
        ra = u_viewCenter.x + atan(
            lView * sinc,
            r * cosDec0 * cosc - mView * sinDec0 * sinc
        );
    }

    // SIN projection: (RA, Dec) -> (l, m) direction cosines from phase center
    float dra = ra - u_crval.x;
    float sinDecP = sin(dec);
    float cosDecP = cos(dec);
    float sinDec0P = sin(u_crval.y);
    float cosDec0P = cos(u_crval.y);
    float cosDra = cos(dra);

    // Visibility check
    float cosAngDist = sinDecP * sinDec0P + cosDecP * cosDec0P * cosDra;
    if (cosAngDist <= 0.0) {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
        return;
    }

    float l = cosDecP * sin(dra);
    float m = sinDecP * cosDec0P - cosDecP * sinDec0P * cosDra;

    // (l, m) -> pixel coordinates (0-based for texture UV)
    float px = l / u_cdelt.x + u_crpix.x - 1.0;
    float py = m / u_cdelt.y + u_crpix.y - 1.0;

    // Texture UV (0-1 range)
    vec2 uv = vec2(px / u_imageSize.x, py / u_imageSize.y);

    // Bounds check
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
        return;
    }

    // Sample — R channel holds pre-normalized value [0,1], A=0 means NaN
    vec4 texel = texture2D(u_image, uv);
    if (texel.a < 0.5) {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
        return;
    }

    float norm = texel.r;

    // Apply stretch
    if (u_stretch == 1) {       // log
        norm = log(norm * 99.0 + 1.0) / log(100.0);
    } else if (u_stretch == 2) { // sqrt
        norm = sqrt(norm);
    } else if (u_stretch == 3) { // asinh
        norm = log(norm * 10.0 + sqrt(norm * norm * 100.0 + 1.0)) / log(10.0 + sqrt(101.0));
    }

    // Colormap lookup
    gl_FragColor = texture2D(u_colormap, vec2(norm, 0.5));
    gl_FragColor.a *= u_opacity;
}
`, hc = `
precision highp float;
attribute vec2 a_position;
void main() {
    gl_Position = vec4(a_position, 0.0, 1.0);
}
`, vc = { linear: 0, log: 1, sqrt: 2, asinh: 3 };
function pc(j) {
  let ge;
  try {
    ge = fc({ canvas: j });
  } catch (Ae) {
    return console.error("regl init failed:", Ae), null;
  }
  const fe = ge.buffer([
    [-1, -1],
    [1, -1],
    [-1, 1],
    [-1, 1],
    [1, -1],
    [1, 1]
  ]);
  let oe = ge.texture({
    width: 1,
    height: 1,
    data: new Uint8Array([0, 0, 0, 255]),
    mag: "nearest",
    min: "nearest",
    wrap: "clamp"
  }), Se = ge.texture({
    width: 256,
    height: 1,
    data: yf(bf("inferno")),
    mag: "linear",
    min: "linear",
    wrap: "clamp"
  });
  const pe = {
    crval: [0, 0],
    cdelt: [1, 1],
    crpix: [0, 0],
    imageSize: [1, 1],
    viewCenter: [0, 0],
    fov: Math.PI,
    opacity: 1,
    stretch: 0,
    // Raw float data for re-normalization on vmin/vmax change
    rawData: null,
    rawWidth: 0,
    rawHeight: 0,
    vmin: 0,
    vmax: 1
  }, me = ge({
    frag: mc,
    vert: hc,
    attributes: { a_position: fe },
    count: 6,
    uniforms: {
      u_image: () => oe,
      u_colormap: () => Se,
      u_crval: () => pe.crval,
      u_cdelt: () => pe.cdelt,
      u_crpix: () => pe.crpix,
      u_imageSize: () => pe.imageSize,
      u_viewCenter: () => pe.viewCenter,
      u_fov: () => pe.fov,
      u_opacity: () => pe.opacity,
      u_stretch: () => pe.stretch,
      u_resolution: () => [j.width, j.height]
    },
    blend: {
      enable: !0,
      func: {
        srcRGB: "src alpha",
        dstRGB: "one minus src alpha",
        srcAlpha: 1,
        dstAlpha: "one minus src alpha"
      }
    }
  });
  function be() {
    if (!pe.rawData) return;
    const Ae = dc(
      pe.rawData,
      pe.rawWidth,
      pe.rawHeight,
      pe.vmin,
      pe.vmax
    );
    oe = ge.texture({
      width: pe.rawWidth,
      height: pe.rawHeight,
      data: Ae,
      mag: "nearest",
      min: "nearest",
      wrap: "clamp"
    });
  }
  function Le() {
    ge.clear({ color: [0, 0, 0, 1], depth: 1 }), me();
  }
  return {
    state: pe,
    setImage(Ae, Ce, Xe) {
      pe.rawData = Ae, pe.rawWidth = Ce, pe.rawHeight = Xe, pe.imageSize = [Ce, Xe], be();
    },
    setWCS(Ae, Ce, Xe) {
      pe.crval = [Ae[0] * $r, Ae[1] * $r], pe.cdelt = [Ce[0] * $r, Ce[1] * $r], pe.crpix = Xe;
    },
    setView(Ae, Ce, Xe) {
      pe.viewCenter = [Ae * $r, Ce * $r], pe.fov = Xe * $r;
    },
    setColorScale(Ae, Ce) {
      pe.vmin = Ae, pe.vmax = Ce, be();
    },
    setOpacity(Ae) {
      pe.opacity = Ae;
    },
    setStretch(Ae) {
      pe.stretch = vc[Ae] ?? 0;
    },
    setColormap(Ae) {
      Se = ge.texture({
        width: 256,
        height: 1,
        data: yf(bf(Ae)),
        mag: "linear",
        min: "linear",
        wrap: "clamp"
      });
    },
    resize(Ae, Ce) {
      j.width = Ae, j.height = Ce, ge.poll();
    },
    render: Le,
    destroy() {
      ge.destroy();
    }
  };
}
const Xr = Math.PI / 180, Dr = 180 / Math.PI;
function _c(j, ge, fe, oe, Se, pe) {
  const me = Math.tan(Se * 0.5), be = -j * me * pe, Le = ge * me, Ae = Math.sqrt(be * be + Le * Le), Ce = Math.atan(Ae);
  if (Ae === 0) return { ra: fe, dec: oe };
  const Xe = Math.sin(Ce), yr = Math.cos(Ce), mr = Math.sin(oe), Pe = Math.cos(oe), Ze = Math.asin(yr * mr + Le * Xe * Pe / Ae);
  return { ra: fe + Math.atan2(
    be * Xe,
    Ae * Pe * yr - Le * mr * Xe
  ), dec: Ze };
}
function bc(j) {
  const fe = (j % 360 + 360) % 360 / 15, oe = Math.floor(fe), Se = Math.floor((fe - oe) * 60), pe = ((fe - oe) * 60 - Se) * 60;
  return `${oe}h${String(Se).padStart(2, "0")}m${pe.toFixed(1).padStart(4, "0")}s`;
}
function yc(j) {
  const ge = j >= 0 ? "+" : "-", fe = Math.abs(j), oe = Math.floor(fe), Se = Math.floor((fe - oe) * 60), pe = ((fe - oe) * 60 - Se) * 60;
  return `${ge}${oe}°${String(Se).padStart(2, "0")}'${pe.toFixed(1).padStart(4, "0")}"`;
}
function Ec(j, ge, fe, oe) {
  let Se = !1, pe = 0, me = 0, be = (fe.get("view_ra") || 0) * Xr, Le = (fe.get("view_dec") || 0) * Xr, Ae = (fe.get("view_fov") || 180) * Xr;
  function Ce() {
    fe.set("view_ra", be * Dr), fe.set("view_dec", Le * Dr), fe.set("view_fov", Ae * Dr), fe.save_changes();
  }
  function Xe() {
    ge.setView(be * Dr, Le * Dr, Ae * Dr);
  }
  function yr(je) {
    Se = !0, pe = je.clientX, me = je.clientY, j.style.cursor = "grabbing";
  }
  function mr(je) {
    if (Se) {
      const tr = (je.clientX - pe) / j.clientWidth * Ae, Wr = (je.clientY - me) / j.clientHeight * Ae, sr = Math.cos(Le), Yr = Math.max(sr, 0.01), Er = j.clientWidth / j.clientHeight;
      be -= tr * Er / Yr, Le += Wr, Le = Math.max(-Math.PI / 2 + 1e-3, Math.min(Math.PI / 2 - 1e-3, Le)), pe = je.clientX, me = je.clientY, Xe(), requestAnimationFrame(() => ge.render());
    } else
      hr(je);
  }
  function Pe() {
    Se && (Se = !1, j.style.cursor = "grab", Ce());
  }
  function Ze(je) {
    je.preventDefault();
    const tr = je.deltaY > 0 ? 1.1 : 1 / 1.1;
    Ae *= tr, Ae = Math.max(1e-3 * Xr, Math.min(Math.PI, Ae)), Xe(), Ce(), requestAnimationFrame(() => ge.render());
  }
  function hr(je) {
    if (!oe) return;
    const tr = j.getBoundingClientRect(), Wr = (je.clientX - tr.left) / tr.width * 2 - 1, sr = -((je.clientY - tr.top) / tr.height * 2 - 1), Yr = j.clientWidth / j.clientHeight, Er = _c(Wr, sr, be, Le, Ae, Yr);
    if (Er) {
      const cn = (Er.ra * Dr % 360 + 360) % 360, ln = Er.dec * Dr;
      oe.textContent = `${bc(cn)}  ${yc(ln)}`;
    } else
      oe.textContent = "";
  }
  function er() {
    be = (fe.get("view_ra") || 0) * Xr, Le = (fe.get("view_dec") || 0) * Xr, Ae = (fe.get("view_fov") || 180) * Xr, Xe(), requestAnimationFrame(() => ge.render());
  }
  return fe.on("change:view_ra", er), fe.on("change:view_dec", er), fe.on("change:view_fov", er), j.addEventListener("mousedown", yr), window.addEventListener("mousemove", mr), window.addEventListener("mouseup", Pe), j.addEventListener("wheel", Ze, { passive: !1 }), j.style.cursor = "grab", {
    destroy() {
      j.removeEventListener("mousedown", yr), window.removeEventListener("mousemove", mr), window.removeEventListener("mouseup", Pe), j.removeEventListener("wheel", Ze), fe.off("change:view_ra", er), fe.off("change:view_dec", er), fe.off("change:view_fov", er);
    }
  };
}
function xc({ model: j, el: ge }) {
  const fe = document.createElement("div");
  fe.style.position = "relative", fe.style.width = "100%", fe.style.height = "600px", fe.style.backgroundColor = "#000", ge.appendChild(fe);
  const oe = document.createElement("canvas");
  oe.style.width = "100%", oe.style.height = "100%", oe.style.display = "block", fe.appendChild(oe);
  const Se = document.createElement("div");
  Se.style.position = "absolute", Se.style.bottom = "8px", Se.style.left = "8px", Se.style.color = "#fff", Se.style.fontFamily = "monospace", Se.style.fontSize = "13px", Se.style.textShadow = "0 0 4px #000, 0 0 4px #000", Se.style.pointerEvents = "none", Se.style.userSelect = "none", fe.appendChild(Se);
  function pe() {
    const Pe = fe.getBoundingClientRect(), Ze = window.devicePixelRatio || 1;
    oe.width = Pe.width * Ze, oe.height = Pe.height * Ze, me && (me.resize(oe.width, oe.height), me.render());
  }
  pe();
  const me = pc(oe);
  if (!me) {
    fe.textContent = "WebGL2 not available";
    return;
  }
  function be() {
    const Pe = j.get("image_data"), Ze = j.get("image_shape");
    if (!Pe || !Ze || Ze[0] === 0) return;
    const hr = Pe.byteLength || Pe.length;
    if (hr === 0) return;
    const [er, je] = Ze, tr = new Float32Array(
      Pe.buffer.slice(Pe.byteOffset, Pe.byteOffset + hr)
    );
    me.setImage(tr, je, er);
  }
  function Le() {
    const Pe = j.get("crval"), Ze = j.get("cdelt"), hr = j.get("crpix");
    Pe && Ze && hr && me.setWCS(Pe, Ze, hr);
  }
  function Ae() {
    me.setView(
      j.get("view_ra") || 0,
      j.get("view_dec") || 0,
      j.get("view_fov") || 180
    );
  }
  function Ce() {
    me.setColorScale(j.get("vmin") || 0, j.get("vmax") || 1);
  }
  function Xe() {
    be(), Le(), Ae(), Ce(), me.setOpacity(j.get("opacity") ?? 1), me.setStretch(j.get("stretch") || "linear"), me.setColormap(j.get("colormap") || "inferno"), me.render();
  }
  Xe(), j.on("change:image_data", () => {
    be(), me.render();
  }), j.on("change:crval", () => {
    Le(), me.render();
  }), j.on("change:cdelt", () => {
    Le(), me.render();
  }), j.on("change:crpix", () => {
    Le(), me.render();
  }), j.on("change:colormap", () => {
    me.setColormap(j.get("colormap")), me.render();
  }), j.on("change:stretch", () => {
    me.setStretch(j.get("stretch")), me.render();
  }), j.on("change:vmin", () => {
    Ce(), me.render();
  }), j.on("change:vmax", () => {
    Ce(), me.render();
  }), j.on("change:opacity", () => {
    me.setOpacity(j.get("opacity")), me.render();
  });
  const yr = Ec(oe, me, j, Se), mr = new ResizeObserver(() => pe());
  return mr.observe(fe), () => {
    yr.destroy(), mr.disconnect(), me.destroy();
  };
}
export {
  xc as render
};
//# sourceMappingURL=widget.js.map
