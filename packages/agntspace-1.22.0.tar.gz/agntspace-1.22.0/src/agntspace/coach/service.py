"""Coach service: goal tracking, stall detection, nudges."""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta

from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

_GOAL_TEMPLATE = """---
title: "{title}"
entity_type: goal
type: {goal_type}
status: active
target_date: "{target_date}"
created: "{created}"
domain: "{domain}"
success_metric: "{success_metric}"
budget: {budget}
budget_consumed: 0.0
dispatches: 0
max_attempts: {max_attempts}
attempt_failures: 0
pursuit_status: idle
---

## What
{description}

## Why


## Success Criteria


## Milestones

"""


class CoachService:
    """Tracks goals, detects stalls, and generates nudges."""

    def __init__(
        self,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        knowledge_graph: object | None = None,
    ) -> None:
        self._reader = vault_reader
        self._writer = vault_writer
        self._graph = knowledge_graph

    def _refresh_graph(self) -> None:
        """Refresh structural triples if the graph is wired."""
        if self._graph is not None:
            try:
                self._graph.refresh_structural_triples()  # type: ignore[attr-defined]
            except Exception as exc:  # pragma: no cover
                log.debug("Graph structural refresh failed: %s", exc)

    def list_goals(self, status_filter: str | None = None) -> list[dict]:
        """List all goals from vault/goals/."""
        files = self._reader.list_files("goals", "*.md")
        goals = []
        for f in files:
            try:
                doc = self._reader.read(f"goals/{f.name}")
                meta = doc.metadata
                goal_status = meta.get("status", "active")
                if status_filter and goal_status != status_filter:
                    continue
                goals.append({
                    "slug": f.stem,
                    "title": meta.get("title", f.stem),
                    "type": meta.get("type", "goal"),
                    "status": goal_status,
                    "target_date": meta.get("target_date", ""),
                    "created": meta.get("created", ""),
                })
            except Exception:
                continue
        return goals

    def get_goal(self, slug: str) -> dict | None:
        """Get a goal by slug."""
        path = f"goals/{slug}.md"
        if not self._reader.exists(path):
            return None
        doc = self._reader.read(path)
        return {
            "slug": slug,
            "content": doc.content,
            "metadata": doc.metadata,
        }

    def create_goal(
        self,
        title: str,
        description: str,
        goal_type: str = "goal",
        target_date: str = "",
        success_metric: str = "",
        budget: float = 0.0,
        max_attempts: int = 20,
        domain: str = "general",
    ) -> str:
        """Create a new goal file. Returns the vault path."""
        slug = title.lower().strip()
        slug = "".join(c if c.isalnum() or c == " " else "" for c in slug)
        slug = slug.replace(" ", "-")[:60].strip("-")
        path = f"goals/{slug}.md"

        now = datetime.now(UTC).strftime("%Y-%m-%d")
        content = _GOAL_TEMPLATE.format(
            title=title,
            goal_type=goal_type,
            target_date=target_date or "",
            created=now,
            description=description,
            success_metric=success_metric,
            budget=budget,
            max_attempts=max_attempts,
            domain=domain,
        )
        self._writer.write(path, content, contract_action="create_task")
        self._refresh_graph()
        return path

    def rename_goal(self, slug: str, new_title: str) -> dict:
        """Rename a goal file and rewrite references in PROJECT.md files.

        Returns {"slug": new_slug, "projects_updated": n}.
        """
        import re

        old_path = f"goals/{slug}.md"
        if not self._reader.exists(old_path):
            raise FileNotFoundError(f"Goal not found: {slug}")

        new_slug = "".join(c if c.isalnum() or c == " " else "" for c in new_title.lower().strip())
        new_slug = new_slug.replace(" ", "-")[:60].strip("-")
        if not new_slug:
            raise ValueError("New title produces an empty slug")

        doc = self._reader.read(old_path)
        content = re.sub(
            r'^title:\s*".*"',
            f'title: "{new_title}"',
            doc.raw,
            count=1,
            flags=re.MULTILINE,
        )

        if new_slug == slug:
            self._writer.write(old_path, content, contract_action="create_task")
            self._refresh_graph()
            return {"slug": slug, "projects_updated": 0}

        new_path = f"goals/{new_slug}.md"
        if self._reader.exists(new_path):
            raise ValueError(f"Goal already exists: {new_slug}")

        self._writer.write(new_path, content, contract_action="create_task")

        try:
            old_physical = (
                self._reader.paths.resolve(old_path)
                if self._reader.paths
                else self._reader._vault_dir / old_path  # noqa: SLF001
            )
            if old_physical.is_file():
                old_physical.unlink()
        except Exception:
            pass

        projects_updated = 0
        projects_dir = (
            self._reader.paths.resolve("projects")
            if self._reader.paths
            else self._reader._vault_dir / "projects"  # noqa: SLF001
        )
        if projects_dir.is_dir():
            for project_dir in projects_dir.iterdir():
                if not project_dir.is_dir():
                    continue
                project_file = project_dir / "PROJECT.md"
                if not project_file.is_file():
                    continue
                try:
                    pdoc = self._reader.read(f"projects/{project_dir.name}/PROJECT.md")
                    goals_list = pdoc.metadata.get("related_goals", []) or []
                    if slug in goals_list:
                        new_goals = [new_slug if g == slug else g for g in goals_list]
                        yaml_list = (
                            "[" + ", ".join(f'"{g}"' for g in new_goals) + "]" if new_goals else "[]"
                        )
                        new_content = re.sub(
                            r"^related_goals:\s*.*$",
                            f"related_goals: {yaml_list}",
                            pdoc.raw,
                            count=1,
                            flags=re.MULTILINE,
                        )
                        self._writer.write(
                            f"projects/{project_dir.name}/PROJECT.md", new_content,
                            contract_action="create_task",
                        )
                        projects_updated += 1
                except Exception:
                    continue

        self._refresh_graph()
        return {"slug": new_slug, "projects_updated": projects_updated}

    def update_goal(
        self,
        slug: str,
        description: str | None = None,
        target_date: str | None = None,
    ) -> None:
        """Update a goal's editable body fields (description, target_date)."""
        import re

        path = f"goals/{slug}.md"
        if not self._reader.exists(path):
            raise FileNotFoundError(f"Goal not found: {slug}")
        doc = self._reader.read(path)
        content = doc.raw

        if target_date is not None:
            content = re.sub(
                r'^target_date:\s*".*"',
                f'target_date: "{target_date}"',
                content,
                count=1,
                flags=re.MULTILINE,
            )

        if description is not None:
            pattern = r"(## What\n)(.*?)(\n## |\Z)"
            replacement = rf"\g<1>{description}\g<3>"
            content = re.sub(pattern, replacement, content, count=1, flags=re.DOTALL)

        self._writer.write(path, content, contract_action="create_task")

    def update_goal_status(self, slug: str, status: str) -> None:
        """Update a goal's status (active/paused/achieved/abandoned)."""
        import re

        path = f"goals/{slug}.md"
        doc = self._reader.read(path)
        content = re.sub(
            r"^status:\s*\S+",
            f"status: {status}",
            doc.raw,
            count=1,
            flags=re.MULTILINE,
        )
        self._writer.write(path, content, contract_action="create_task")
        if self._graph:
            try:
                self._graph.build()
            except Exception:
                log.debug("Graph rebuild after goal status change failed", exc_info=True)

    def delete_goal(self, slug: str) -> dict:
        """Delete a goal file and remove references from all PROJECT.md files.

        Returns {"slug": slug, "projects_cleaned": n}.
        """
        import re as _re

        path = f"goals/{slug}.md"
        if not self._reader.exists(path):
            raise FileNotFoundError(f"Goal not found: {slug}")

        # Delete the file
        physical = (
            self._reader.paths.resolve(path)
            if self._reader.paths
            else self._reader._vault_dir / path  # noqa: SLF001
        )
        if physical.is_file():
            physical.unlink()

        # Clean up project references (same pattern as rename_goal)
        projects_cleaned = 0
        projects_dir = (
            self._reader.paths.resolve("projects")
            if self._reader.paths
            else self._reader._vault_dir / "projects"  # noqa: SLF001
        )
        if projects_dir.is_dir():
            for project_dir in projects_dir.iterdir():
                if not project_dir.is_dir():
                    continue
                project_file = project_dir / "PROJECT.md"
                if not project_file.is_file():
                    continue
                try:
                    pdoc = self._reader.read(f"projects/{project_dir.name}/PROJECT.md")
                    goals_list = pdoc.metadata.get("related_goals", []) or []
                    if slug in goals_list:
                        new_goals = [g for g in goals_list if g != slug]
                        yaml_list = (
                            "[" + ", ".join(f'"{g}"' for g in new_goals) + "]"
                            if new_goals
                            else "[]"
                        )
                        new_content = _re.sub(
                            r"^related_goals:\s*.*$",
                            f"related_goals: {yaml_list}",
                            pdoc.raw,
                            count=1,
                            flags=_re.MULTILINE,
                        )
                        self._writer.write(
                            f"projects/{project_dir.name}/PROJECT.md",
                            new_content,
                            contract_action="create_task",
                        )
                        projects_cleaned += 1
                except Exception:
                    continue

        self._refresh_graph()
        return {"slug": slug, "projects_cleaned": projects_cleaned}

    # ── Pursuit tracking ──

    def get_pursuable_goals(self) -> list[dict]:
        """Return active goals that have budget > 0 and are eligible for pursuit."""
        goals = self.list_goals(status_filter="active")
        pursuable = []
        for g in goals:
            path = f"goals/{g['slug']}.md"
            try:
                doc = self._reader.read(path)
            except (FileNotFoundError, OSError):
                continue
            meta = doc.metadata
            budget = float(meta.get("budget", 0))
            if budget <= 0:
                continue
            consumed = float(meta.get("budget_consumed", 0))
            pursuit_status = meta.get("pursuit_status", "idle")
            attempt_failures = int(meta.get("attempt_failures", 0))
            max_attempts = int(meta.get("max_attempts", 20))
            if pursuit_status not in ("idle", "pursuing"):
                continue
            if attempt_failures >= max_attempts:
                continue
            pursuable.append({
                **g,
                "success_metric": meta.get("success_metric", ""),
                "budget": budget,
                "budget_consumed": consumed,
                "dispatches": int(meta.get("dispatches", 0)),
                "attempt_failures": attempt_failures,
                "max_attempts": max_attempts,
                "pursuit_status": pursuit_status,
                "domain": meta.get("domain", "general"),
            })
        return pursuable

    def get_pursuit_status(self, slug: str) -> dict:
        """Return pursuit-related fields for a goal."""
        path = f"goals/{slug}.md"
        if not self._reader.exists(path):
            raise FileNotFoundError(f"Goal not found: {slug}")
        doc = self._reader.read(path)
        meta = doc.metadata
        return {
            "slug": slug,
            "success_metric": meta.get("success_metric", ""),
            "budget": float(meta.get("budget", 0)),
            "budget_consumed": float(meta.get("budget_consumed", 0)),
            "dispatches": int(meta.get("dispatches", 0)),
            "max_attempts": int(meta.get("max_attempts", 20)),
            "attempt_failures": int(meta.get("attempt_failures", 0)),
            "pursuit_status": meta.get("pursuit_status", "idle"),
        }

    def record_pursuit_attempt(self, slug: str, succeeded: bool, cost: float) -> None:
        """Update pursuit tracking fields after an agent dispatch."""
        import re as _re

        path = f"goals/{slug}.md"
        if not self._reader.exists(path):
            raise FileNotFoundError(f"Goal not found: {slug}")
        doc = self._reader.read(path)
        meta = doc.metadata
        content = doc.raw

        dispatches = int(meta.get("dispatches", 0)) + 1
        consumed = float(meta.get("budget_consumed", 0)) + cost
        failures = 0 if succeeded else int(meta.get("attempt_failures", 0)) + 1

        for field, val in [
            ("dispatches", str(dispatches)),
            ("budget_consumed", f"{consumed:.2f}"),
            ("attempt_failures", str(failures)),
        ]:
            content = _re.sub(
                rf"^{field}:\s*.*$", f"{field}: {val}",
                content, count=1, flags=_re.MULTILINE,
            )

        self._writer.write(path, content, contract_action="create_task")

    def set_pursuit_status(self, slug: str, status: str, reason: str = "") -> None:
        """Set pursuit_status (idle, pursuing, paused, completed, failed)."""
        import re as _re

        valid = ("idle", "pursuing", "paused", "completed", "failed")
        if status not in valid:
            raise ValueError(f"Invalid pursuit_status: {status}")

        path = f"goals/{slug}.md"
        if not self._reader.exists(path):
            raise FileNotFoundError(f"Goal not found: {slug}")
        doc = self._reader.read(path)
        content = _re.sub(
            r"^pursuit_status:\s*.*$", f"pursuit_status: {status}",
            doc.raw, count=1, flags=_re.MULTILINE,
        )
        self._writer.write(path, content, contract_action="create_task")

        if status == "completed":
            self.update_goal_status(slug, "achieved")
        if status == "paused" and reason:
            log.info("Goal '%s' pursuit paused: %s", slug, reason)

    def detect_stalls(self, stall_days: int = 7) -> list[dict]:
        """Detect goals that haven't had activity in stall_days.

        Checks if goals have related tasks or journal mentions recently.
        """
        stalls = []
        cutoff = (datetime.now(UTC) - timedelta(days=stall_days)).strftime("%Y-%m-%d")

        for goal in self.list_goals(status_filter="active"):
            # Check if any recent journal entries mention this goal
            title_lower = goal["title"].lower()
            has_recent_activity = False

            # Check recent journal files (user + agent + legacy)
            journal_files = []
            for d in ("journal/user", "journal/agnt", "journal"):
                for jf in self._reader.list_files(d, "*.md"):
                    journal_files.append((d, jf))
            for d, jf in sorted(journal_files, key=lambda x: x[1].name, reverse=True)[:stall_days * 2]:
                stem = jf.stem.replace("user-journal_", "").replace("agent-observations_", "")
                if stem < cutoff:
                    break
                try:
                    doc = self._reader.read(f"{d}/{jf.name}")
                    if title_lower in doc.content.lower():
                        has_recent_activity = True
                        break
                except Exception:
                    continue

            if not has_recent_activity:
                stalls.append({
                    "goal": goal["title"],
                    "slug": goal["slug"],
                    "days_inactive": stall_days,
                    "nudge": (
                        f"Your goal '{goal['title']}' hasn't had any activity "
                        f"in the last {stall_days} days. Want to plan the next step?"
                    ),
                })

        return stalls

    def generate_nudges(self) -> list[str]:
        """Generate coaching nudges for stalled goals and approaching deadlines."""
        nudges = []
        today = datetime.now(UTC).strftime("%Y-%m-%d")

        # Stall nudges
        for stall in self.detect_stalls():
            nudges.append(stall["nudge"])

        # Deadline nudges
        for goal in self.list_goals(status_filter="active"):
            target = goal.get("target_date", "")
            if not target:
                continue
            try:
                target_date = datetime.strptime(target, "%Y-%m-%d")
                days_left = (target_date - datetime.strptime(today, "%Y-%m-%d")).days
                if 0 < days_left <= 7:
                    nudges.append(
                        f"Goal '{goal['title']}' is due in {days_left} day(s) ({target})."
                    )
                elif days_left <= 0:
                    nudges.append(
                        f"Goal '{goal['title']}' was due on {target}. "
                        f"Want to update the deadline or mark it?"
                    )
            except ValueError:
                continue

        return nudges
