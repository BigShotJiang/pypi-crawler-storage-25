"""Heartbeat: periodic background loop that checks state and logs observations.

Every pulse is recorded to SQLite for the cardiogram time series.
Deviations (blocked tasks, overdue items, errors) are flagged.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import aiosqlite

if TYPE_CHECKING:
    from agntspace.agent.orchestrator import Orchestrator
    from agntspace.journal.service import JournalService
    from agntspace.tasks.service import TaskService

log = logging.getLogger(__name__)


class Heartbeat:
    """15-minute background loop that monitors state and logs to journal.

    Every pulse is persisted to SQLite so the UI can render a cardiogram.
    """

    def __init__(
        self,
        journal: JournalService,
        task_service: TaskService,
        db: aiosqlite.Connection | None = None,
        interval_seconds: int = 900,
        llm: object | None = None,
    ) -> None:
        self._journal = journal
        self._task_service = task_service
        self._db = db
        self._interval = interval_seconds
        self._llm = llm  # LLM provider for connectivity checks
        self._work_queue: object | None = None  # Set post-init by main.py
        self._orchestrator: Orchestrator | None = None  # Set post-init by main.py
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False

    async def init_schema(self) -> None:
        """Create heartbeat tables if they don't exist."""
        if not self._db:
            return
        await self._db.executescript("""
            CREATE TABLE IF NOT EXISTS heartbeat_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                pulse_type TEXT NOT NULL DEFAULT 'heartbeat',
                status TEXT NOT NULL DEFAULT 'normal',
                observations INTEGER NOT NULL DEFAULT 0,
                active_tasks INTEGER NOT NULL DEFAULT 0,
                blocked_tasks INTEGER NOT NULL DEFAULT 0,
                overdue_tasks INTEGER NOT NULL DEFAULT 0,
                details TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_heartbeat_ts ON heartbeat_log(ts);
        """)
        # Add pulse_type column if upgrading from older schema
        try:
            await self._db.execute("SELECT pulse_type FROM heartbeat_log LIMIT 1")
        except Exception:
            await self._db.execute("ALTER TABLE heartbeat_log ADD COLUMN pulse_type TEXT NOT NULL DEFAULT 'heartbeat'")
        await self._db.commit()

    def start(self) -> None:
        """Start the heartbeat background loop."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        log.debug("Heartbeat started (interval: %ds)", self._interval)

    def stop(self) -> None:
        """Stop the heartbeat background loop."""
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None
        log.debug("Heartbeat stopped")

    async def record_pulse(
        self,
        pulse_type: str,
        details: str | None = None,
        status: str | None = None,
    ) -> None:
        """Record any agent activity as a pulse on the cardiogram.

        Pulse types:
        - heartbeat: regular 15-min check (automatic)
        - chat: agent responded to a message
        - tool_use: agent used a tool (email, vault, task, etc.)
        - automation: briefing, EOD, reflection, memory generation
        - channel: handled a channel message
        - cron: cron job executed
        - error: LLM failure, integration error, etc. (auto-deviation)
        - startup: server startup pulse
        """
        if not self._db:
            return
        # Error pulses are always deviations
        if status is None:
            status = "deviation" if pulse_type == "error" else "normal"
        now = datetime.now(UTC).isoformat()
        try:
            await self._db.execute(
                "INSERT INTO heartbeat_log (ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks, details) "
                "VALUES (?, ?, ?, 0, 0, 0, 0, ?)",
                (now, pulse_type, status, details),
            )
            await self._db.commit()
        except Exception:
            log.debug("Failed to record %s pulse", pulse_type, exc_info=True)

    @property
    def is_running(self) -> bool:
        return self._running

    async def run_once(self) -> list[str]:
        """Run a single heartbeat cycle. Returns list of observations logged.

        Opens a ``heartbeat-*`` correlation scope so every observation,
        LLM health check, and outreach dispatched from this cycle
        shares one causal chain id in /decisions (Rule #17 Tier B).
        """
        from agntspace.activity.decisions import (
            correlation_scope,
            new_correlation_id,
        )

        with correlation_scope(new_correlation_id("heartbeat")):
            return await self._do_run_once()

    async def _do_run_once(self) -> list[str]:
        """Internal heartbeat body — caller owns the correlation scope."""
        observations: list[str] = []
        now = datetime.now(UTC)
        now_str = now.strftime("%H:%M")

        active_count = 0
        blocked_count = 0
        overdue_count = 0

        # Check tasks
        try:
            tasks = self._task_service.list_tasks()
            blocked = [t for t in tasks if t.get("status") == "blocked"]
            in_review = [t for t in tasks if t.get("status") == "review"]
            active = [t for t in tasks if t.get("status") == "in_progress"]

            active_count = len(active)
            blocked_count = len(blocked)

            if blocked:
                names = ", ".join(t.get("title", "?") for t in blocked)
                observations.append(f"Heartbeat: {len(blocked)} blocked task(s): {names}")

            if in_review:
                names = ", ".join(t.get("title", "?") for t in in_review)
                observations.append(f"Heartbeat: {len(in_review)} task(s) awaiting review: {names}")

            if active:
                observations.append(f"Heartbeat: {len(active)} task(s) in progress")

        except Exception:
            log.debug("Heartbeat: task check failed", exc_info=True)

        # Check for overdue tasks
        try:
            tasks = self._task_service.list_tasks()
            today = now.strftime("%Y-%m-%d")
            for t in tasks:
                due = t.get("due", "")
                if due and due < today and t.get("status") not in ("done", "cancelled"):
                    overdue_count += 1
                    observations.append(f"Heartbeat: task '{t.get('title', '?')}' is overdue (due: {due})")
        except Exception:
            pass

        # Check LLM connectivity and update work queue health
        llm_error = None
        if self._llm:
            try:
                from agntspace.llm.base import Message as LLMMessage

                await self._llm.complete(
                    messages=[LLMMessage(role="user", content="ping")],
                    system="Reply with exactly: pong",
                    max_tokens=10,
                    temperature=0,
                )
                # LLM is healthy — notify work queue to drain pending jobs
                if self._work_queue and hasattr(self._work_queue, "set_llm_health"):
                    model_name = getattr(self._llm, "model_name", getattr(self._llm, "_model", ""))
                    self._work_queue.set_llm_health(True, model=model_name)
            except Exception as exc:
                llm_error = str(exc)
                log.info("Heartbeat: LLM check failed: %s", llm_error)

                # If local/Ollama mode, try to auto-start Ollama before giving up
                _model = getattr(self._llm, "_model", "") or ""
                if _model.startswith("ollama/") or _model.startswith("ollama_chat/"):
                    from agntspace.llm.ollama_discovery import ensure_ollama_running
                    if ensure_ollama_running():
                        # Ollama is back — retry the health check once
                        try:
                            await self._llm.complete(
                                messages=[LLMMessage(role="user", content="ping")],
                                system="Reply with exactly: pong",
                                max_tokens=10,
                                temperature=0,
                            )
                            llm_error = None  # recovered
                            if self._work_queue and hasattr(self._work_queue, "set_llm_health"):
                                model_name = getattr(self._llm, "model_name", getattr(self._llm, "_model", ""))
                                self._work_queue.set_llm_health(True, model=model_name)
                            observations.append("Heartbeat: Ollama auto-started and recovered")
                        except Exception:
                            pass  # still failing — fall through to unhealthy

                if llm_error:
                    observations.append(f"Heartbeat: LLM unreachable — {llm_error}")
                    # Mark LLM unhealthy — work queue will defer jobs
                    if self._work_queue and hasattr(self._work_queue, "set_llm_health"):
                        self._work_queue.set_llm_health(False)

        # Determine status
        if llm_error or overdue_count > 0 or blocked_count > 0:
            status = "deviation"
        else:
            status = "normal"

        # Log observations to agent file
        for obs in observations:
            try:
                self._journal.append_observation(obs)
            except Exception:
                log.debug("Heartbeat: failed to log observation", exc_info=True)

        # Record pulse to SQLite
        if self._db:
            details = "; ".join(observations) if observations else None
            try:
                await self._db.execute(
                    "INSERT INTO heartbeat_log (ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks, details) "
                    "VALUES (?, 'heartbeat', ?, ?, ?, ?, ?, ?)",
                    (now.isoformat(), status, len(observations), active_count, blocked_count, overdue_count, details),
                )
                await self._db.commit()
            except Exception:
                log.debug("Heartbeat: failed to record pulse", exc_info=True)

        if observations:
            log.info("Heartbeat: %d observations logged (%s)", len(observations), status)
        else:
            log.debug("Heartbeat: pulse at %s — normal", now_str)

        # ── Rule #17 learning loop: SkillSchool zero-effect analysis ──
        # On every heartbeat cycle, check the decision log for skills
        # that produced zero-effect outcomes and surface them as action
        # plan proposals. This is the feedback channel between the
        # zero-effect detector (Agent.invoke_skill) and the tuner.
        if hasattr(self, "_skillschool") and self._skillschool:
            try:
                proposals = await self._skillschool.analyze_zero_effects()
                if proposals:
                    log.info("SkillSchool: %d zero-effect proposals from heartbeat", len(proposals))
                    # Write proposals to the persistent action plan so they
                    # appear in the Simulate/Agents page UI alongside health
                    # check issues. The user sees "Skill 'kb-ingest' had N
                    # zero-effect failures — upgrade tier or add examples."
                    try:
                        from agntspace.agent.action_plan import (
                            append_action_plan_items,
                            skillschool_proposals_to_plan_items,
                        )
                        plan_items = skillschool_proposals_to_plan_items(proposals)
                        vault_dir = getattr(self, "_vault_dir", None)
                        if vault_dir and plan_items:
                            added = await append_action_plan_items(vault_dir, plan_items)
                            if added:
                                log.info("SkillSchool: %d item(s) added to action plan", added)
                    except Exception:
                        log.debug("SkillSchool: action plan write failed", exc_info=True)
                    # Also emit as activity events for the agent's world model
                    if hasattr(self, "_activity") and self._activity:
                        for p in proposals[:5]:
                            self._activity.log(
                                "system", "skill_tune_proposal",
                                p.get("what", "zero-effect skill detected"),
                                p,
                                importance="high" if p.get("severity") == "high" else "medium",
                            )
            except Exception:
                log.debug("SkillSchool analyze_zero_effects failed", exc_info=True)

        # ── Version update check (uses 6h cache — no PyPI spam) ──
        try:
            from agntspace.api.routes.health import (
                _check_pypi_latest,
                _get_version,
                _parse_version,
            )
            current = _get_version()
            if current != "dev":
                latest = await _check_pypi_latest()
                if latest and _parse_version(latest) > _parse_version(current):
                    if hasattr(self, "_activity") and self._activity:
                        self._activity.log(
                            "system", "update_available",
                            f"AgntSpace v{latest} is available (running v{current})",
                            {"current": current, "latest": latest},
                            importance="medium",
                        )
        except Exception:
            pass

        # ── Proactive outreach (silence check, important event alerts) ──
        if hasattr(self, "_outreach") and self._outreach:
            try:
                _agent = getattr(self, "_agent", None)
                await self._outreach.check_and_reach_out(agent=_agent)
            except Exception:
                log.debug("Proactive outreach failed", exc_info=True)

        # ── Agent insights generation (proactive awareness) ──
        insights_engine = getattr(self, "_insights_engine", None)
        if insights_engine:
            try:
                snapshot = await insights_engine.generate()
                warning_count = len([i for i in snapshot.insights if i.severity == "warning"])
                if warning_count:
                    observations.append(
                        f"Agent insights: {warning_count} warning(s), "
                        f"{len(snapshot.insights) - warning_count} suggestion(s)"
                    )
            except Exception:
                log.debug("Insights generation failed", exc_info=True)

        # ── Autonomous pipeline triggers (agent-first KB health) ──
        try:
            pipeline_obs = await self._check_autonomous_pipelines()
            observations.extend(pipeline_obs)
        except Exception:
            log.debug("Autonomous pipeline check failed", exc_info=True)

        # ── Autonomous goal pursuit (staggered 30s after other checks) ──
        coach = getattr(self, "_coach", None)
        if coach:
            try:
                import asyncio as _aio
                await _aio.sleep(30)  # stagger to avoid LLM contention with outreach
                goal_obs = await self._pursue_active_goals()
                observations.extend(goal_obs)
            except Exception:
                log.debug("Goal pursuit check failed", exc_info=True)

        return observations

    async def _check_autonomous_pipelines(self) -> list[str]:
        """Auto-trigger KB ingest/compile when the agent notices pending work.

        This is a key agent-first behavior: the agent doesn't wait for
        the user to click "Run Pipeline" — it notices files in the inbox
        and acts on them autonomously.
        """
        observations: list[str] = []
        kb_service = getattr(self, "_kb_service", None)
        wq = getattr(self, "_work_queue", None)
        if not kb_service or not wq:
            return observations

        # Check each KB for pending inbox files
        try:
            kbs = kb_service.list_knowledge_bases()
        except Exception:
            return observations

        for kb in kbs:
            slug = kb.get("slug", "")
            if not slug:
                continue

            # Check inbox for files that the watcher might have missed
            # (e.g., files added while server was down)
            try:
                inbox_files = kb_service._reader.list_files(
                    f"knowledge/{slug}/inbox", "*"
                )
                pending = [
                    f for f in inbox_files
                    if ".quarantine" not in str(f)
                    and not f.name.startswith(".")
                    and f.stat().st_size > 0
                ]
                if len(pending) > 0:
                    # Enqueue ingest job — deduplicate so we don't spam
                    job_id = await wq.enqueue(
                        "ingest",
                        {"slug": slug, "source": "heartbeat_auto"},
                        deduplicate=True,
                    )
                    if job_id:
                        observations.append(
                            f"Auto-triggered ingest for KB '{slug}' "
                            f"({len(pending)} file(s) pending)"
                        )
                        if hasattr(self, "_activity") and self._activity:
                            self._activity.log(
                                "knowledge", "auto_ingest_triggered",
                                f"Agent auto-triggered ingest for '{slug}' — {len(pending)} files pending",
                                {"kb_slug": slug, "file_count": len(pending)},
                                importance="medium",
                            )
            except Exception:
                pass

        return observations

    def _is_local_mode(self) -> bool:
        """True when running against a local LLM (Ollama). Used for budget
        gating — local mode has zero dollar cost so only the dispatch cap
        and futility gate are meaningful."""
        from agntspace.infra.config import get_settings
        try:
            return get_settings().llm.mode == "local"
        except Exception:
            return False

    async def _pursue_active_goals(self) -> list[str]:
        """Check for pursuable goals and enqueue one dispatch per tick.

        Budget gating is mode-aware:
        - **Dispatch cap** (``max_dispatches``) — always enforced regardless
          of LLM mode. This is the universal effort budget.
        - **Dollar budget** — only enforced in cloud mode. Local models cost
          $0.00 so the dollar check would never trigger; dispatch cap is the
          meaningful constraint.
        - **Futility gate** (``max_attempts``) — always enforced. Consecutive
          failures pause the goal to prevent pointless retries.
        """
        observations: list[str] = []
        coach = getattr(self, "_coach", None)
        wq = getattr(self, "_work_queue", None)
        cost = getattr(self, "_cost_tracker", None)
        activity = getattr(self, "_activity", None)
        if not coach or not wq:
            return observations

        try:
            pursuable = coach.get_pursuable_goals()
        except Exception:
            log.debug("Failed to get pursuable goals", exc_info=True)
            return observations

        if not pursuable:
            return observations

        # Max 1 goal pursuit per heartbeat tick to prevent parallel budget drain
        goal = pursuable[0]
        slug = goal["slug"]
        budget = goal["budget"]
        consumed = goal["budget_consumed"]
        dispatches = goal.get("dispatches", 0)
        max_dispatches = goal.get("max_dispatches", 50)
        local_mode = self._is_local_mode()

        # Gate 0: trust level — goal domain must reach Assistant to dispatch
        trust_svc = getattr(self, "_trust_service", None)
        contract = getattr(self, "_contract", None)
        if trust_svc:
            goal_domain = goal.get("domain", "general")
            proactivity = contract.rules.proactivity if contract else "advisor"
            trust_check = trust_svc.check_tool_trust(
                "create_task", proactivity, is_autonomous=True,
            )
            # For goal pursuit, we need at least Assistant (idx 2)
            # because pursuit dispatches real work autonomously.
            from agntspace.trust.service import TRUST_LEVELS, _TRUST_LEVEL_INDEX
            effective_idx = _TRUST_LEVEL_INDEX.get(trust_check.effective_level, 0)
            if effective_idx < 2:  # Below Assistant
                observations.append(
                    f"Goal '{goal['title']}' skipped: trust too low in domain "
                    f"'{goal_domain}' (need Assistant, have {trust_check.effective_level})"
                )
                if activity:
                    activity.log(
                        "trust", "goal_pursuit_blocked",
                        f"Goal '{slug}' pursuit blocked by trust: {trust_check.effective_level}",
                        {"goal_slug": slug, "domain": goal_domain,
                         "effective_level": trust_check.effective_level,
                         "domain_trust": trust_check.domain_trust,
                         "proactivity": proactivity},
                        importance="medium",
                    )
                return observations

        # Gate 1: dispatch cap (universal — works in ALL modes)
        if dispatches >= max_dispatches:
            reason = f"Dispatch limit reached ({dispatches}/{max_dispatches})"
            observations.append(f"Goal '{goal['title']}' paused: {reason}")
            coach.set_pursuit_status(slug, "paused", reason=reason)
            if activity:
                activity.log(
                    "system", "goal_pursuit_paused",
                    f"Goal '{slug}' paused: {reason}",
                    {"goal_slug": slug, "reason": "dispatch_limit",
                     "dispatches": dispatches, "max_dispatches": max_dispatches},
                    importance="high",
                )
            return observations

        # Gate 2: dollar budget (cloud mode only — local is free)
        if not local_mode and cost:
            try:
                check = await cost.check_goal_budget(slug, budget)
                if not check["allowed"]:
                    observations.append(
                        f"Goal '{goal['title']}' budget exhausted "
                        f"(${check['spent']:.2f} / ${budget:.2f})"
                    )
                    coach.set_pursuit_status(slug, "paused", reason="Budget exhausted")
                    return observations
            except Exception:
                log.debug("Goal budget check failed for %s", slug, exc_info=True)

        # Build remaining budget info for the dispatch context
        if local_mode:
            budget_remaining_str = f"local mode (free), dispatch {dispatches + 1}/{max_dispatches}"
        else:
            budget_remaining_str = f"${budget - consumed:.2f} remaining, dispatch {dispatches + 1}/{max_dispatches}"

        # Enqueue pursuit job
        try:
            job_id = await wq.enqueue(
                "pursue_goal",
                {
                    "goal_slug": slug,
                    "goal_title": goal["title"],
                    "goal_metric": goal.get("success_metric", ""),
                    "budget_remaining": budget - consumed,
                    "dispatch_number": dispatches + 1,
                    "max_dispatches": max_dispatches,
                    "local_mode": local_mode,
                },
                deduplicate=True,
            )
            if job_id:
                observations.append(
                    f"Dispatched pursuit of goal '{goal['title']}' "
                    f"({budget_remaining_str})"
                )
            else:
                observations.append(f"Goal '{goal['title']}' pursuit already queued")
        except Exception:
            log.debug("Failed to enqueue goal pursuit for %s", slug, exc_info=True)

        return observations

    async def get_history(self, hours: int = 24, limit: int = 200) -> list[dict]:
        """Get heartbeat history for the cardiogram chart."""
        if not self._db:
            return []
        from datetime import timedelta

        cutoff = (datetime.now(UTC) - timedelta(hours=hours)).isoformat()
        cursor = await self._db.execute(
            "SELECT ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks "
            "FROM heartbeat_log WHERE ts >= ? ORDER BY ts DESC LIMIT ?",
            (cutoff, limit),
        )
        rows = await cursor.fetchall()
        return [
            {
                "ts": row[0],
                "pulse_type": row[1],
                "status": row[2],
                "observations": row[3],
                "active_tasks": row[4],
                "blocked_tasks": row[5],
                "overdue_tasks": row[6],
            }
            for row in reversed(rows)  # chronological order
        ]

    async def get_deviations(self, limit: int = 50) -> list[dict]:
        """Get recent deviations (non-normal pulses)."""
        if not self._db:
            return []
        cursor = await self._db.execute(
            "SELECT ts, status, observations, blocked_tasks, overdue_tasks, details "
            "FROM heartbeat_log WHERE status != 'normal' ORDER BY ts DESC LIMIT ?",
            (limit,),
        )
        rows = await cursor.fetchall()
        return [
            {
                "ts": row[0],
                "status": row[1],
                "observations": row[2],
                "blocked_tasks": row[3],
                "overdue_tasks": row[4],
                "details": row[5],
            }
            for row in rows
        ]

    async def get_status(self) -> dict:
        """Get current heartbeat status summary."""
        last_pulse = None
        total_pulses = 0
        total_deviations = 0

        if self._db:
            cursor = await self._db.execute(
                "SELECT ts, status FROM heartbeat_log ORDER BY ts DESC LIMIT 1"
            )
            row = await cursor.fetchone()
            if row:
                last_pulse = {"ts": row[0], "status": row[1]}

            cursor = await self._db.execute("SELECT COUNT(*) FROM heartbeat_log")
            total_pulses = (await cursor.fetchone())[0]

            cursor = await self._db.execute(
                "SELECT COUNT(*) FROM heartbeat_log WHERE status != 'normal'"
            )
            total_deviations = (await cursor.fetchone())[0]

        # Include active dispatches from orchestrator
        active_dispatches: dict[str, str] = {}
        if self._orchestrator:
            try:
                active_dispatches = self._orchestrator.get_active_dispatches()
            except Exception:
                pass

        return {
            "running": self._running,
            "interval_seconds": self._interval,
            "last_pulse": last_pulse,
            "total_pulses": total_pulses,
            "total_deviations": total_deviations,
            "active_dispatches": active_dispatches,
        }

    def _seconds_until_next_slot(self) -> float:
        """Calculate seconds until the next clock-aligned slot.

        With a 15-minute interval, pulses land on :00, :15, :30, :45.
        With a 30-minute interval, pulses land on :00, :30.
        """
        now = datetime.now(UTC)
        interval_min = self._interval // 60 or 1
        current_min = now.minute
        next_slot = ((current_min // interval_min) + 1) * interval_min
        seconds_into_minute = now.second + now.microsecond / 1_000_000
        wait = (next_slot - current_min) * 60 - seconds_into_minute
        if wait <= 0:
            wait += self._interval
        return wait

    async def _loop(self) -> None:
        """Main heartbeat loop — clock-aligned pulses.

        Pulses land on clean clock boundaries (e.g., 08:00, 08:15, 08:30, 08:45).
        """
        # Immediate pulse on startup, then align to clock
        try:
            await self.run_once()
        except Exception:
            log.exception("Heartbeat startup pulse failed")

        # Wait until the first aligned slot
        wait = self._seconds_until_next_slot()
        log.debug("Heartbeat: next pulse in %.0fs (aligned to clock)", wait)
        await asyncio.sleep(wait)

        while self._running:
            try:
                await self.run_once()
            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("Heartbeat error")
            # Sleep until next aligned slot
            await asyncio.sleep(self._seconds_until_next_slot())
