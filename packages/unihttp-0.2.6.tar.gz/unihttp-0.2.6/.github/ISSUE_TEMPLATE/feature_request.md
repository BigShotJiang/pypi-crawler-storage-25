---
name: Feature Request
about: Suggest an idea for this project
title: 'Feature:'
labels: enhancement
assignees: ''
---

To suggest an idea or feature or any other enhancement, please follow this template:

**Is your feature request related to a problem? Please describe.**
Provide a clear and concise description of the problem you've encountered. For example: "I'm always frustrated when..."

**Describe the solution you'd like**
Clearly and concisely describe the desired outcome or solution.

**Feature code example**
To help others understand the proposed feature, illustrate it with a code example.

**Describe alternatives you've considered**
Provide a clear and concise description of any alternative solutions or features you've thought about.

**Additional context**
Include any other relevant context or screenshots related to the feature request.