# anycloud Python SDK

Submit jobs, run workloads on any cloud.

## Install

```bash
pip install anycloud-sdk
```

For the latest pre-release version:

```bash
pip install --pre anycloud-sdk
```

## Quick start

```python
import anycloud

ac = anycloud.Client()

job = ac.submit("my-training:latest", gpu="h100:8", env={"LR": "0.01"})
job.wait()
print(job.logs())
```

## Chaining jobs

```python
prep = ac.submit("prep:latest")
prep.wait()

train = ac.submit("train:latest", gpu="h100:8", env={"LR": "0.01"})
train.wait()

eval_job = ac.submit("eval:latest")
eval_job.wait()
```

## Fan-out / fan-in

```python
from anycloud import JobGroup

split = ac.submit("split:latest")
split.wait()

shards = JobGroup([ac.submit("worker:latest", env={"LR": lr}) for lr in ["0.1", "0.01", "0.001"]])
shards.wait_all()

merge = ac.submit("merge:latest")
merge.wait()
```
