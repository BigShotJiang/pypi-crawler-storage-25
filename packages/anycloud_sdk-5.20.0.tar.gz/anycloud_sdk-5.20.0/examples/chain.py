#!/usr/bin/env python3
"""Example: submit a 3-step chain (prep → train → eval) using the anycloud SDK."""

import anycloud


def main(ac: anycloud.Client):
    # -- Step 1: prep ----------------------------------------------------------
    prep = ac.submit("my-prep:latest", gpu="a100:1")
    print(f"Submitted prep: {prep.id}")
    prep.wait()

    # -- Step 2: train ---------------------------------------------------------
    train = ac.submit("my-train:latest", gpu="a100:8")
    print(f"Submitted train: {train.id}")
    train.wait()

    # -- Step 3: eval ----------------------------------------------------------
    eval_ = ac.submit("my-eval:latest", gpu="a100:1")
    print(f"Submitted eval: {eval_.id}")
    eval_.wait()

    # -- Print logs from the final step ----------------------------------------
    logs = eval_.logs()
    if logs:
        print(f"\n--- eval logs ---\n{logs}")


if __name__ == "__main__":
    # Reads credentials from ~/.anycloud/credentials.json automatically.
    # Use credentials="name" if you have multiple credential sets.
    with anycloud.Client() as ac:
        main(ac)
