"""anycloud Client — submit jobs, manage deployments."""

from __future__ import annotations

import json
import os
from importlib.metadata import version as _pkg_version, PackageNotFoundError
from pathlib import Path
from typing import Any

import httpx

from anycloud.errors import APIError, ConflictError, NotFoundError
from anycloud.job import Job
from anycloud.types import (
    AWSCredentials,
    AzureCredentials,
    CloudConfig,
    CloudType,
    Deployment,
    GCPCredentials,
    LambdaCredentials,
    StatusResponse,
)

BUILDER_IMAGE = "ghcr.io/anycloud-sh/builder"

_BUILD_DEFAULTS: dict[str, dict[str, str]] | None = None


def _load_build_defaults() -> dict[str, dict[str, str]]:
    global _BUILD_DEFAULTS
    if _BUILD_DEFAULTS is None:
        defaults_path = Path(__file__).parent / "build-defaults.json"
        with open(defaults_path) as f:
            _BUILD_DEFAULTS = json.load(f)
    return _BUILD_DEFAULTS


def _apply_build_defaults(cc: CloudConfig) -> CloudConfig:
    """Return a copy of *cc* with vmType/region filled from build defaults."""
    defaults = _load_build_defaults()
    provider_defaults = defaults.get(cc.cloud_provider.value, {})
    overrides: dict[str, Any] = {}
    if not cc.vm_type and "vmType" in provider_defaults:
        overrides["vm_type"] = provider_defaults["vmType"]
    if not cc.region and "region" in provider_defaults:
        overrides["region"] = provider_defaults["region"]
    if overrides:
        return cc.model_copy(update=overrides)
    return cc


def _read_version() -> str:
    """Resolve SDK version: monorepo package.json first, then installed package metadata.

    When running from the monorepo, package.json has the canonical version
    (e.g. 5.17.2) while pyproject.toml has a placeholder (0.1.0).
    The placeholder is only overwritten at publish time, so we prefer
    package.json when it exists.
    """
    pkg = Path(__file__).resolve().parent.parent.parent.parent / "package.json"
    try:
        with open(pkg) as f:
            return json.load(f)["version"]
    except (FileNotFoundError, KeyError):
        pass
    # Installed from PyPI — version was set at publish time
    try:
        return _pkg_version("anycloud-sdk")
    except PackageNotFoundError:
        raise RuntimeError(
            "Could not determine anycloud-sdk version. "
            "Install the package (pip install anycloud-sdk) or run from the monorepo."
        )


_SDK_VERSION = _read_version()

# Default path for CLI-compatible credentials file
_DEFAULT_CREDENTIALS_PATH = Path.home() / ".anycloud" / "credentials.json"

# Map cloudProvider string → (CloudType, credential model)
_CRED_BUILDERS: dict[str, tuple[CloudType, type]] = {
    "AWS": (CloudType.AWS, AWSCredentials),
    "GCP": (CloudType.GCP, GCPCredentials),
    "Azure": (CloudType.Azure, AzureCredentials),
    "Lambda": (CloudType.Lambda, LambdaCredentials),
}


def _load_credentials_file() -> dict[str, Any]:
    """Read ~/.anycloud/credentials.json (same file the CLI uses).

    Returns an empty dict if the file doesn't exist.
    """
    path = Path(os.environ.get("ANYCLOUD_CREDENTIALS_PATH", str(_DEFAULT_CREDENTIALS_PATH)))
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return {}


def _build_cloud_config(name: str, cred_data: dict[str, Any]) -> CloudConfig:
    """Build a ``CloudConfig`` from a single credentials.json entry."""
    provider = cred_data.get("cloudProvider")
    if provider not in _CRED_BUILDERS:
        raise ValueError(
            f"Unsupported cloudProvider {provider!r} in credential {name!r}. "
            f"Supported: {', '.join(_CRED_BUILDERS)}"
        )
    cloud_type, cred_cls = _CRED_BUILDERS[provider]
    return CloudConfig(
        cloudProvider=cloud_type,
        credentials=cred_cls.model_validate(cred_data),
    )


class Client:
    """anycloud Python client.

    Usage::

        # Simplest — reads ~/.anycloud/credentials.json automatically
        ac = Client()
        job = ac.submit("train:latest", gpu="h100:8")

        # Multiple credential sets — pick one by name
        ac = Client(credentials="aws-prod")

        # Explicit cloud config (always works)
        ac = Client(cloud_config=CloudConfig(...))

    Args:
        access_token: GitHub token for authentication.
            Falls back to ``ANYCLOUD_ACCESS_TOKEN`` env var.
        api_url: Base URL of the API server.
            Falls back to ``ANYCLOUD_API_URL``, then legacy ``ANYCLOUD_CONDUCTOR_URL``,
            then ``http://localhost:8080``.
        cloud_config: Default ``CloudConfig`` applied to every ``submit()`` call.
            Can be overridden per-submit via ``submit(cloud_config=...)``.
        credentials: Name of a credential set in ``~/.anycloud/credentials.json``.
            If the file has exactly one entry, it is used automatically.
            Ignored when *cloud_config* is provided.
    """

    def __init__(
        self,
        *,
        access_token: str | None = None,
        api_url: str | None = None,
        cloud_config: CloudConfig | None = None,
        credentials: str | None = None,
    ):
        token = access_token or os.environ.get("ANYCLOUD_ACCESS_TOKEN", "")
        if not token:
            raise ValueError(
                "access_token is required. Pass access_token='...' or set the "
                "ANYCLOUD_ACCESS_TOKEN environment variable."
            )
        self._access_token = token

        self._base_url = (
            api_url
            or os.environ.get("ANYCLOUD_API_URL")
            or os.environ.get("ANYCLOUD_CONDUCTOR_URL")
            or "http://localhost:8080"
        ).rstrip("/")

        self._default_cloud_config = cloud_config or self._auto_load_cloud_config(credentials)
        self._http = httpx.Client(base_url=self._base_url, timeout=30.0)

    # ------------------------------------------------------------------
    # Credential auto-loading
    # ------------------------------------------------------------------

    @staticmethod
    def _auto_load_cloud_config(name: str | None) -> CloudConfig | None:
        """Try to build a default CloudConfig from ~/.anycloud/credentials.json.

        Returns ``None`` silently when the file is missing or empty (the user
        can still pass ``cloud_config`` per-submit).
        """
        creds = _load_credentials_file()
        if not creds:
            return None

        if name is not None:
            if name not in creds:
                available = ", ".join(creds)
                raise ValueError(
                    f"Credential {name!r} not found in credentials file. "
                    f"Available: {available}"
                )
            return _build_cloud_config(name, creds[name])

        if len(creds) == 1:
            only_name, only_data = next(iter(creds.items()))
            return _build_cloud_config(only_name, only_data)

        # Multiple entries, none selected — don't guess
        return None

    # ------------------------------------------------------------------
    # Core: submit
    # ------------------------------------------------------------------

    def submit(
        self,
        image: str,
        *,
        cloud_config: CloudConfig | None = None,
        gpu: str | None = None,
        env: dict[str, str] | None = None,
        docker_options: dict[str, Any] | None = None,
        command: list[str] | None = None,
        persist: bool = False,
        deployment_id: str | None = None,
        image_digest: str | None = None,
    ) -> Job:
        """Submit a job and return a ``Job`` promise.

        Args:
            image: Docker image reference (e.g. ``"train:latest"``).
            cloud_config: ``CloudConfig`` specifying provider, credentials, region, etc.
                Falls back to the default set on ``Client(cloud_config=...)``.
            gpu: GPU type shorthand (e.g. ``"h100:8"``).
            env: Environment variables passed to the container.
            docker_options: Docker runtime options (shmSize, gpus, etc.).
            command: Override container CMD.
            persist: Keep VM alive after job completion.
            deployment_id: Custom deployment ID (auto-generated if omitted).
            image_digest: Docker image digest (e.g. ``"sha256:abc..."``).

        Returns:
            A ``Job`` handle you can poll or wait on.
        """
        body = self._build_request_body(
            image=image,
            gpu=gpu,
            env=env,
            docker_options=docker_options,
            command=command,
            persist=persist,
            deployment_id=deployment_id,
            cloud_config=cloud_config,
            image_digest=image_digest,
        )

        data = self._submit_raw(body)
        return Job(self, data["id"])

    # ------------------------------------------------------------------
    # Core: build
    # ------------------------------------------------------------------

    def build(
        self,
        dockerfile: str,
        target_image: str,
        *,
        cloud_config: CloudConfig | None = None,
        deployment_id: str | None = None,
    ) -> Job:
        """Submit a remote build job. Returns a ``Job`` handle.

        Provisions a VM, builds a Docker image from the provided Dockerfile
        content, and pushes it to the target registry. Uses the conductor's
        builder image with Docker socket mount.

        Args:
            dockerfile: Dockerfile content as a string.
            target_image: Full registry path to push the built image
                (e.g. ``"ghcr.io/user/repo:v1"``).
            cloud_config: ``CloudConfig`` for the build VM.
                Falls back to the default set on ``Client(cloud_config=...)``.
                If no ``vm_type`` is set, build-specific defaults are applied.
            deployment_id: Custom deployment ID (auto-generated if omitted).

        Returns:
            A ``Job`` handle you can poll or wait on.
        """
        cc = cloud_config or self._default_cloud_config
        if cc is None:
            raise ValueError(
                "A cloud config is required. Pass cloud_config=CloudConfig(...) "
                "or set a default via Client(cloud_config=...)."
            )
        # Apply build-specific VM defaults if no vmType specified
        if not cc.vm_type:
            cc = _apply_build_defaults(cc)

        return self.submit(
            BUILDER_IMAGE,
            env={
                "DOCKERFILE": dockerfile,
                "TARGET_IMAGE": target_image,
            },
            docker_options={"binds": ["/var/run/docker.sock:/var/run/docker.sock"]},
            cloud_config=cc,
            deployment_id=deployment_id,
        )

    # ------------------------------------------------------------------
    # Deployment management
    # ------------------------------------------------------------------

    def list(self, *, limit: int = 20) -> list[Deployment]:
        """List recent deployments."""
        data = self._post("/v1/list", {
            "accessToken": self._access_token,
            "version": _SDK_VERSION,
            "limit": limit,
        })
        return [Deployment.model_validate(d) for d in data]

    def get(self, deployment_id: str) -> Job:
        """Get a ``Job`` handle for an existing deployment."""
        return Job(self, deployment_id)

    # ------------------------------------------------------------------
    # Internal API calls (used by Job)
    # ------------------------------------------------------------------

    def _submit_raw(self, body: dict[str, Any]) -> dict[str, Any]:
        """POST /v1/new and return the response dict."""
        return self._post("/v1/new", body)

    def _status(self, deployment_id: str, *, verbose: bool = False) -> StatusResponse:
        body: dict[str, Any] = {
            "id": deployment_id,
            "accessToken": self._access_token,
            "version": _SDK_VERSION,
        }
        if verbose:
            body["verbose"] = True
        data = self._post("/v1/status", body)
        return StatusResponse.model_validate(data)

    def _terminate(self, deployment_id: str) -> None:
        self._post("/v1/terminate", {
            "id": deployment_id,
            "accessToken": self._access_token,
            "version": _SDK_VERSION,
        })

    def _resubmit(self, deployment_id: str) -> None:
        self._post("/v1/resubmit", {
            "id": deployment_id,
            "accessToken": self._access_token,
            "version": _SDK_VERSION,
        })

    # ------------------------------------------------------------------
    # HTTP
    # ------------------------------------------------------------------

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        resp = self._http.post(path, json=body)
        if resp.status_code == 409:
            raise ConflictError(resp.text)
        if resp.status_code == 404:
            raise NotFoundError(resp.text)
        if resp.status_code >= 400:
            # /v1/status returns 400 (not 404) for missing deployments
            if "not found" in resp.text.lower():
                raise NotFoundError(resp.text)
            raise APIError(resp.status_code, resp.text)
        return resp.json()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_request_body(
        self,
        *,
        image: str,
        gpu: str | None,
        env: dict[str, str] | None,
        docker_options: dict[str, Any] | None,
        command: list[str] | None,
        persist: bool,
        deployment_id: str | None,
        cloud_config: CloudConfig | None,
        image_digest: str | None = None,
    ) -> dict[str, Any]:
        cc = cloud_config or self._default_cloud_config
        if cc is None:
            raise ValueError(
                "A cloud config is required. Either:\n"
                "  - Add credentials via 'anycloud credentials new'\n"
                "  - Pass cloud_config=CloudConfig(...) to submit()\n"
                "  - Pass credentials='name' to Client() to select from credentials file"
            )

        body: dict[str, Any] = {
            "image": image,
            "deploymentType": "job",
            "version": _SDK_VERSION,
            "accessToken": self._access_token,
            "cloudConfig": cc.model_dump(by_alias=True, exclude_none=True),
        }

        if deployment_id is not None:
            body["id"] = deployment_id
        if env is not None:
            body["env"] = env
        if persist:
            body["persist"] = True
        if docker_options is not None:
            body["dockerOptions"] = docker_options
        if command is not None:
            body["command"] = command
        if gpu is not None:
            body["gpuType"] = gpu
        if image_digest is not None:
            body["imageDigest"] = image_digest

        return body

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()
