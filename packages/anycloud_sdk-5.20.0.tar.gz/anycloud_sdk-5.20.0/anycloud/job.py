"""Job — a future-like handle to a running deployment."""

from __future__ import annotations

import subprocess
import tempfile
import time
from pathlib import Path
from typing import TYPE_CHECKING

from anycloud.errors import JobFailedError, TimeoutError
from anycloud.types import DeploymentState, StatusResponse

if TYPE_CHECKING:
    from anycloud.client import Client


class Job:
    """A promise-like handle to an anycloud deployment.

    Returned by ``Client.submit()``. Supports polling and blocking waits.

    Usage::

        job = client.submit("train:latest", cloud_config=cc, gpu="h100:8")
        job.wait()          # block until terminal
        print(job.logs())   # container stdout/stderr
    """

    def __init__(
        self,
        client: Client,
        deployment_id: str,
    ):
        self._client = client
        self._id = deployment_id
        self._state: DeploymentState | None = None
        self._status_response: StatusResponse | None = None

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    @property
    def id(self) -> str:
        return self._id

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def state(self) -> DeploymentState:
        """Fetch the current deployment state from the API."""
        self.status()
        if self._state is None:
            raise RuntimeError(
                f"Deployment {self._id} has no events yet — state is unknown"
            )
        return self._state

    def status(self) -> StatusResponse:
        """Fetch full status from the API server (events, VM health, etc.)."""
        resp = self._client._status(self._id)
        self._status_response = resp
        if resp.events:
            self._state = resp.events[-1].state
        return resp

    # ------------------------------------------------------------------
    # Blocking wait
    # ------------------------------------------------------------------

    def wait(self, *, timeout: float | None = None, poll_interval: float = 2.0) -> Job:
        """Block until the job reaches a terminal state.

        Returns ``self`` on success (Completed).
        Raises ``JobFailedError`` (with ``.logs``) on Errored / Failed / Invalid.
        Raises ``TimeoutError`` if *timeout* seconds elapse.
        """
        deadline = time.monotonic() + timeout if timeout is not None else None

        while True:
            self.status()
            if self._state is not None and self._state.is_terminal:
                if self._state == DeploymentState.Completed:
                    return self
                # Auto-fetch logs before raising
                container_logs = self._fetch_logs_quiet()
                raise JobFailedError(
                    self._id,
                    self._state.value,
                    self._error_message(),
                    logs=container_logs,
                )
            if deadline is not None and time.monotonic() >= deadline:
                raise TimeoutError(f"Job {self._id} did not complete within {timeout}s")
            time.sleep(poll_interval)

    # ------------------------------------------------------------------
    # Build result
    # ------------------------------------------------------------------

    @property
    def built_image(self) -> str | None:
        """Return the built image reference after a build job completes.

        Parses the ``BUILT_IMAGE=...`` line from container logs.
        Returns ``None`` if not available yet or not a build job.
        """
        log_output = self.logs()
        if log_output:
            for line in log_output.splitlines():
                if line.startswith("BUILT_IMAGE="):
                    return line[len("BUILT_IMAGE="):]
        return None

    # ------------------------------------------------------------------
    # Logs
    # ------------------------------------------------------------------

    def logs(self) -> str | None:
        """Return the most recent container logs (from the status endpoint)."""
        resp = self._client._status(self._id, verbose=True)
        self._status_response = resp
        if resp.events:
            self._state = resp.events[-1].state
        if resp.vm_statuses:
            for vm in resp.vm_statuses:
                container = vm.get("container", {})
                if container and container.get("logs"):
                    return container["logs"]
        return None

    # ------------------------------------------------------------------
    # Exec
    # ------------------------------------------------------------------

    def exec(self, command: str, *, vm: bool = False) -> str:
        """Run a command and return its stdout.

        Args:
            command: Shell command to execute.
            vm: If ``True``, run on the VM host.  If ``False`` (default),
                run inside the container via ``docker exec``.

        Returns:
            Standard output of the command (decoded UTF-8, stripped).

        Raises:
            RuntimeError: If SSH connection fails or the command exits non-zero.
        """
        resp = self._ensure_status()

        ssh_key = resp.ssh_private_key
        if not ssh_key:
            raise RuntimeError(f"SSH key not available for deployment {self._id}")

        if not resp.vm_statuses:
            raise RuntimeError(f"No VMs found for deployment {self._id}")

        vm_ip = resp.vm_statuses[0].get("ip")
        if not vm_ip:
            raise RuntimeError(f"No VM IP found for deployment {self._id}")

        if vm:
            remote_cmd = command
        else:
            remote_cmd = f"docker exec {self._id} sh -c {_shell_quote(command)}"

        return self._ssh_exec(vm_ip, ssh_key, remote_cmd)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def terminate(self) -> None:
        """Terminate the deployment."""
        self._client._terminate(self._id)
        self._state = DeploymentState.Terminated

    def resubmit(self) -> Job:
        """Resubmit a terminal deployment. Returns a new Job handle."""
        self._client._resubmit(self._id)
        return Job(self._client, self._id)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _ensure_status(self) -> StatusResponse:
        """Return cached status or fetch it."""
        if self._status_response is None:
            self.status()
        assert self._status_response is not None
        return self._status_response

    def _fetch_logs_quiet(self) -> str | None:
        """Best-effort log fetch (swallows errors)."""
        try:
            return self.logs()
        except Exception:
            return None

    def _error_message(self) -> str | None:
        if self._status_response and self._status_response.events:
            last = self._status_response.events[-1]
            if last.metadata:
                return last.metadata.get("error")
        return None

    def _ssh_exec(self, vm_ip: str, ssh_key: str, command: str) -> str:
        """Run a command over SSH and return stdout."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix="-anycloud-key", delete=False
        ) as f:
            f.write(ssh_key)
            key_path = Path(f.name)

        try:
            key_path.chmod(0o600)
            result = subprocess.run(
                [
                    "ssh",
                    "-i", str(key_path),
                    "-o", "StrictHostKeyChecking=no",
                    "-o", "UserKnownHostsFile=/dev/null",
                    "-o", "LogLevel=ERROR",
                    "-o", "ConnectTimeout=30",
                    f"root@{vm_ip}",
                    command,
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
            if result.returncode != 0:
                raise RuntimeError(
                    f"Command failed (exit {result.returncode}): {result.stderr.strip()}"
                )
            return result.stdout.strip()
        finally:
            key_path.unlink(missing_ok=True)

    def __repr__(self) -> str:
        state_str = self._state.value if self._state else "pending"
        return f"Job({self._id!r}, state={state_str!r})"


def _shell_quote(s: str) -> str:
    """Single-quote a string for sh -c."""
    return "'" + s.replace("'", "'\\''") + "'"
