"""Tests for Client.submit() and Job interactions using httpx mock transport."""

import json
import os
from unittest.mock import patch

import httpx
import pytest

from anycloud import Client, Job, JobGroup
from anycloud.errors import (
    APIError,
    ConflictError,
    JobFailedError,
    JobGroupError,
    NotFoundError,
    TimeoutError,
)
from anycloud.types import AWSCredentials, CloudConfig, DeploymentState, StatusResponse


def _mock_transport(routes: dict[str, tuple[int, dict | list]]) -> httpx.MockTransport:
    """Create a mock transport that returns canned responses by path."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path in routes:
            status, body = routes[path]
            return httpx.Response(status, json=body)
        return httpx.Response(404, json={"error": "not found"})

    return httpx.MockTransport(handler)


def _status_response(state: str, *, logs: str | None = None) -> dict:
    resp: dict = {
        "events": [
            {"id": 1, "deploymentId": "j1", "state": state, "metadata": None, "createdAt": 1000}
        ],
        "status": "up" if state == "running" else "down",
    }
    if logs is not None:
        resp["vmStatuses"] = [{"container": {"state": state, "logs": logs}}]
    return resp


def _aws_config(**overrides) -> CloudConfig:
    """Build a minimal AWS CloudConfig for tests."""
    defaults = dict(
        cloudProvider="AWS",
        credentials=AWSCredentials(accessKeyId="fake", secretAccessKey="fake"),
    )
    defaults.update(overrides)
    return CloudConfig(**defaults)


class TestSubmit:
    def test_submit_returns_job(self):
        transport = _mock_transport({
            "/v1/new": (200, {"id": "test-123"}),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = ac.submit("my-image:latest", cloud_config=_aws_config())
            assert isinstance(job, Job)
            assert job.id == "test-123"

    def test_submit_with_all_options(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "full-opts"})

        cc = _aws_config(region="us-east-1", spot=True)
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit(
                "train:latest",
                cloud_config=cc,
                gpu="h100:8",
                env={"LR": "0.001"},
                command=["python", "train.py"],
                persist=True,
            )

        body = captured["body"]
        assert body["image"] == "train:latest"
        assert body["gpuType"] == "h100:8"
        assert body["env"] == {"LR": "0.001"}
        assert body["command"] == ["python", "train.py"]
        assert body["persist"] is True
        assert body["deploymentType"] == "job"
        assert body["cloudConfig"]["region"] == "us-east-1"
        assert body["cloudConfig"]["spot"] is True

    def test_submit_conflict_raises(self):
        transport = _mock_transport({
            "/v1/new": (409, {"error": "exists"}),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(ConflictError):
                ac.submit("img:latest", cloud_config=_aws_config())

    def test_submit_not_found_raises(self):
        transport = _mock_transport({
            "/v1/new": (404, {"error": "not found"}),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(NotFoundError):
                ac.submit("img:latest", cloud_config=_aws_config())

    def test_submit_api_error_raises(self):
        transport = _mock_transport({
            "/v1/new": (500, {"error": "internal"}),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(APIError) as exc_info:
                ac.submit("img:latest", cloud_config=_aws_config())
            assert exc_info.value.status_code == 500



class TestJobStatus:
    def test_status_returns_full_response_and_updates_state(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("running")),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            resp = job.status()
            assert isinstance(resp, StatusResponse)
            assert len(resp.events) == 1
            assert resp.events[0].state == DeploymentState.Running



class TestWait:
    def test_wait_returns_self_on_success(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("completed")),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            result = job.wait()
            assert result is job

    def test_wait_timeout_raises(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("running")),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            with pytest.raises(TimeoutError, match="did not complete"):
                job.wait(timeout=0.05, poll_interval=0.01)

    def test_wait_failure_includes_logs(self):
        """JobFailedError should auto-fetch and include container logs."""
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            body = json.loads(request.content)
            verbose = body.get("verbose", False)
            # First call: status poll (non-verbose) → errored
            # Second call: logs fetch (verbose) → includes logs
            if verbose:
                return httpx.Response(
                    200, json=_status_response("errored", logs="CUDA OOM at step 42")
                )
            return httpx.Response(200, json=_status_response("errored"))

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(
                transport=httpx.MockTransport(handler), base_url="http://test"
            )
            job = Job(ac, "j1")
            with pytest.raises(JobFailedError) as exc_info:
                job.wait()
            assert exc_info.value.logs == "CUDA OOM at step 42"
            assert "CUDA OOM" in str(exc_info.value)


class TestTerminate:
    def test_terminate(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"message": "ok"})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = Job(ac, "j1")
            job.terminate()
            assert "/v1/terminate" in calls


class TestList:
    def test_list_deployments(self):
        transport = _mock_transport({
            "/v1/list": (200, [
                {
                    "id": "d1",
                    "userId": "u1",
                    "deploymentType": "job",
                    "image": "img:latest",
                    "cloudProvider": "AWS",
                    "spot": False,
                    "persist": False,
                    "state": "completed",
                    "startedAt": 1000,
                    "dockerCommand": "docker run img:latest",
                    "vmCount": 1,
                    "sshPrivateKey": "key",
                    "credentialId": "cred-1",
                },
            ]),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            deployments = ac.list()
            assert len(deployments) == 1
            assert deployments[0].id == "d1"
            assert deployments[0].state == DeploymentState.Completed


class TestGet:
    def test_get_returns_job(self):
        with Client(access_token="tok") as ac:
            job = ac.get("existing-id")
            assert isinstance(job, Job)
            assert job.id == "existing-id"


class TestResubmit:
    def test_resubmit(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"message": "ok"})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = Job(ac, "j1")
            new_job = job.resubmit()
            assert isinstance(new_job, Job)
            assert new_job.id == "j1"
            assert "/v1/resubmit" in calls


class TestLogs:
    def test_logs_returns_container_logs(self):
        status_data = {
            "events": [
                {"id": 1, "deploymentId": "j1", "state": "running", "metadata": None, "createdAt": 1000}
            ],
            "status": "up",
            "vmStatuses": [
                {"container": {"state": "running", "logs": "epoch 1/10 loss=0.5\n"}}
            ],
        }
        transport = _mock_transport({"/v1/status": (200, status_data)})
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.logs() == "epoch 1/10 loss=0.5\n"

    def test_logs_returns_none_when_empty(self):
        transport = _mock_transport({"/v1/status": (200, _status_response("running"))})
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.logs() is None


class TestCloudConfig:
    def test_submit_without_cloud_raises(self):
        with Client(access_token="tok") as ac:
            with pytest.raises(ValueError, match="cloud config is required"):
                ac.submit("img:latest")

    def test_cloud_config_fields_sent(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config(
            region="us-west-2",
            vmType="p4d.24xlarge",
            spot=True,
            inputBucket="my-input",
            outputBucket="my-output",
            diskSizeGb=200,
        )
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest", cloud_config=cc)

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["region"] == "us-west-2"
        assert cc_body["vmType"] == "p4d.24xlarge"
        assert cc_body["spot"] is True
        assert cc_body["inputBucket"] == "my-input"
        assert cc_body["outputBucket"] == "my-output"
        assert cc_body["diskSizeGb"] == 200

    def test_default_cloud_config(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config(region="us-east-1")
        with Client(access_token="tok", cloud_config=cc) as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest")

        assert captured["body"]["cloudConfig"]["region"] == "us-east-1"


class TestBuild:
    def test_build_submits_builder_image(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "build-123"})

        cc = _aws_config(vmType="c5.xlarge")
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = ac.build(
                dockerfile="FROM alpine:latest\nRUN echo hello",
                target_image="ghcr.io/user/repo:v1",
                cloud_config=cc,
            )

        assert isinstance(job, Job)
        assert job.id == "build-123"
        body = captured["body"]
        assert body["image"] == "ghcr.io/anycloud-sh/builder"
        assert body["env"]["DOCKERFILE"] == "FROM alpine:latest\nRUN echo hello"
        assert body["env"]["TARGET_IMAGE"] == "ghcr.io/user/repo:v1"
        assert body["dockerOptions"]["binds"] == ["/var/run/docker.sock:/var/run/docker.sock"]

    def test_build_applies_defaults_when_no_vmtype(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "build-456"})

        cc = _aws_config()  # no vmType
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.build(
                dockerfile="FROM alpine:latest",
                target_image="ghcr.io/user/repo:v1",
                cloud_config=cc,
            )

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["vmType"] == "c5.xlarge"  # AWS build default

    def test_build_without_cloud_config_raises(self):
        with Client(access_token="tok") as ac:
            with pytest.raises(ValueError, match="cloud config is required"):
                ac.build(
                    dockerfile="FROM alpine:latest",
                    target_image="ghcr.io/user/repo:v1",
                )

    def test_built_image_property(self):
        status_data = {
            "events": [
                {"id": 1, "deploymentId": "b1", "state": "completed", "metadata": None, "createdAt": 1000}
            ],
            "status": "down",
            "vmStatuses": [
                {"container": {"state": "exited", "logs": "Building...\nBUILT_IMAGE=ghcr.io/user/repo:v1\n"}}
            ],
        }
        transport = _mock_transport({"/v1/status": (200, status_data)})
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "b1")
            assert job.built_image == "ghcr.io/user/repo:v1"

    def test_built_image_returns_none_when_not_build(self):
        status_data = {
            "events": [
                {"id": 1, "deploymentId": "j1", "state": "completed", "metadata": None, "createdAt": 1000}
            ],
            "status": "down",
            "vmStatuses": [
                {"container": {"state": "exited", "logs": "training complete\n"}}
            ],
        }
        transport = _mock_transport({"/v1/status": (200, status_data)})
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.built_image is None


class TestClientInit:
    @patch.dict("os.environ", {
        "ANYCLOUD_ACCESS_TOKEN": "env-token",
        "ANYCLOUD_API_URL": "http://custom:9090",
    })
    def test_env_var_fallbacks(self):
        with Client() as ac:
            assert ac._access_token == "env-token"
            assert ac._base_url == "http://custom:9090"

    @patch.dict("os.environ", {
        "ANYCLOUD_ACCESS_TOKEN": "tok",
        "ANYCLOUD_CONDUCTOR_URL": "http://legacy:9090",
    }, clear=False)
    def test_legacy_conductor_url_fallback(self):
        with Client() as ac:
            assert ac._base_url == "http://legacy:9090"

    def test_missing_access_token_raises(self):
        with patch.dict("os.environ", {}, clear=True):
            # Ensure no env var and no explicit token
            os.environ.pop("ANYCLOUD_ACCESS_TOKEN", None)
            with pytest.raises(ValueError, match="access_token is required"):
                Client()


class TestCredentialAutoLoading:
    def test_single_credential_auto_loaded(self, tmp_path):
        creds_file = tmp_path / "credentials.json"
        creds_file.write_text(json.dumps({
            "my-aws": {
                "cloudProvider": "AWS",
                "accessKeyId": "AKIA...",
                "secretAccessKey": "secret",
            }
        }))

        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        with patch.dict("os.environ", {"ANYCLOUD_CREDENTIALS_PATH": str(creds_file)}):
            with Client(access_token="tok") as ac:
                ac._http = httpx.Client(
                    transport=httpx.MockTransport(handler), base_url="http://test"
                )
                ac.submit("img:latest")

        cc = captured["body"]["cloudConfig"]
        assert cc["cloudProvider"] == "AWS"
        assert cc["credentials"]["accessKeyId"] == "AKIA..."

    def test_named_credential_selected(self, tmp_path):
        creds_file = tmp_path / "credentials.json"
        creds_file.write_text(json.dumps({
            "aws-prod": {
                "cloudProvider": "AWS",
                "accessKeyId": "prod-key",
                "secretAccessKey": "prod-secret",
            },
            "gcp-dev": {
                "cloudProvider": "GCP",
                "projectId": "my-proj",
                "privateKey": "key",
                "clientEmail": "email@test.com",
            },
        }))

        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        with patch.dict("os.environ", {"ANYCLOUD_CREDENTIALS_PATH": str(creds_file)}):
            with Client(access_token="tok", credentials="gcp-dev") as ac:
                ac._http = httpx.Client(
                    transport=httpx.MockTransport(handler), base_url="http://test"
                )
                ac.submit("img:latest")

        cc = captured["body"]["cloudConfig"]
        assert cc["cloudProvider"] == "GCP"
        assert cc["credentials"]["projectId"] == "my-proj"

    def test_missing_named_credential_raises(self, tmp_path):
        creds_file = tmp_path / "credentials.json"
        creds_file.write_text(json.dumps({
            "aws-prod": {
                "cloudProvider": "AWS",
                "accessKeyId": "key",
                "secretAccessKey": "secret",
            },
        }))

        with patch.dict("os.environ", {"ANYCLOUD_CREDENTIALS_PATH": str(creds_file)}):
            with pytest.raises(ValueError, match="not found"):
                Client(access_token="tok", credentials="nonexistent")

    def test_multiple_credentials_no_name_requires_explicit(self, tmp_path):
        creds_file = tmp_path / "credentials.json"
        creds_file.write_text(json.dumps({
            "a": {"cloudProvider": "AWS", "accessKeyId": "k", "secretAccessKey": "s"},
            "b": {"cloudProvider": "GCP", "projectId": "p", "privateKey": "k", "clientEmail": "e"},
        }))

        with patch.dict("os.environ", {"ANYCLOUD_CREDENTIALS_PATH": str(creds_file)}):
            with Client(access_token="tok") as ac:
                # No default cloud config → must pass per-submit
                with pytest.raises(ValueError, match="cloud config is required"):
                    ac.submit("img:latest")

    def test_explicit_cloud_config_overrides_credentials(self, tmp_path):
        creds_file = tmp_path / "credentials.json"
        creds_file.write_text(json.dumps({
            "my-aws": {
                "cloudProvider": "AWS",
                "accessKeyId": "file-key",
                "secretAccessKey": "file-secret",
            }
        }))

        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config(region="eu-west-1")
        with patch.dict("os.environ", {"ANYCLOUD_CREDENTIALS_PATH": str(creds_file)}):
            with Client(access_token="tok", cloud_config=cc) as ac:
                ac._http = httpx.Client(
                    transport=httpx.MockTransport(handler), base_url="http://test"
                )
                ac.submit("img:latest")

        # Should use explicit config, not file
        assert captured["body"]["cloudConfig"]["region"] == "eu-west-1"
        assert captured["body"]["cloudConfig"]["credentials"]["accessKeyId"] == "fake"


class TestJobGroup:
    def test_wait_all_success(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("completed")),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            jobs = JobGroup([Job(ac, f"j{i}") for i in range(3)])
            result = jobs.wait_all()
            assert result is jobs

    def test_wait_all_partial_failure(self):
        """If some jobs fail, JobGroupError is raised with all failures."""
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            body = json.loads(request.content)
            dep_id = body.get("id", "")
            verbose = body.get("verbose", False)
            # j0 completes, j1 errors
            if "j0" in dep_id:
                return httpx.Response(200, json=_status_response("completed"))
            if verbose:
                return httpx.Response(
                    200, json=_status_response("errored", logs="OOM")
                )
            return httpx.Response(200, json=_status_response("errored"))

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(
                transport=httpx.MockTransport(handler), base_url="http://test"
            )
            jobs = JobGroup([Job(ac, "j0"), Job(ac, "j1")])
            with pytest.raises(JobGroupError) as exc_info:
                jobs.wait_all()
            assert len(exc_info.value.errors) == 1
            assert exc_info.value.errors[0][0] == "j1"

    def test_terminate_all(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"message": "ok"})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(
                transport=httpx.MockTransport(handler), base_url="http://test"
            )
            jobs = JobGroup([Job(ac, "j0"), Job(ac, "j1")])
            jobs.terminate_all()
            assert calls.count("/v1/terminate") == 2

    def test_sequence_protocol(self):
        with Client(access_token="tok") as ac:
            jobs = JobGroup([Job(ac, "j0"), Job(ac, "j1"), Job(ac, "j2")])
            assert len(jobs) == 3
            assert jobs[1].id == "j1"
            assert [j.id for j in jobs] == ["j0", "j1", "j2"]
            assert jobs.ids == ["j0", "j1", "j2"]


class TestState:
    def test_state_fetches_from_api(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("running")),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.state() == DeploymentState.Running

    def test_state_is_method_not_property(self):
        with Client(access_token="tok") as ac:
            job = Job(ac, "j1")
            assert callable(job.state)
