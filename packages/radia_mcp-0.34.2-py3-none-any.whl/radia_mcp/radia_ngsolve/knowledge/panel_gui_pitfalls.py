"""
Radia GUI / Cubit panel pitfalls — bugs we hit, root causes, and the rules
that prevent them from coming back. Read this BEFORE adding new
parameters, methods, or modes to a `radia_*.py` panel.

Each entry is structured as:

  ## <symptom>
  Root cause: ...
  Rule: ...
  Reference: <commit hash, file:line>

The MCP server exposes this via panel_gui_pitfalls(topic=...). Topics
are stable keywords (combo_state, mode_switch, gmsh_viz, subprocess_args,
cubit_jou) so they can be referenced from prompts.
"""

PANEL_GUI_PITFALLS = """\
# Radia GUI / Cubit Panel Pitfalls

This document lists pitfalls we have hit (and fixed) while developing
the Radia panels and the calc_*.py subprocess scripts. Each section
ends with a **rule** to prevent the same bug from coming back.

Topics: combo_state, mode_switch, gmsh_viz, subprocess_args, cubit_jou,
        sample_jou, layout_unification, learn_edition_cap

============================================================
## combo_state — Combo box save/restore by INDEX is fragile
============================================================

**Symptom**: After dropping a Method combo item ("BEM-SIBC (WP)") in
one release, the next time the panel opens the Method combo is BLANK.
The user cannot pick anything until they manually re-select.

**Root cause**: ``ModePanel.save_state`` was storing
``QComboBox.currentIndex()`` (an integer). The user's saved settings
contained ``method=2`` from the previous 3-item combo
(BEM, BEM-SIBC (WP), FEM). After the cleanup the combo had only 2
items (BEM, FEM). ``setCurrentIndex(2)`` on a 2-item combo silently
sets the selection to ``-1`` (no item displayed).

**Rule**: Save QComboBox state by **text** (``currentText()``), not
index. On restore use ``findText(val)`` and only apply when
``>= 0``; otherwise leave the panel default. Index-based restore is
acceptable ONLY as a legacy migration path with bounds-check
(``0 <= ival < w.count()``).

**Reference**: commit ``1aa66ee``, ``radia_gui_base.py::ModePanel.
save_state / restore_state``.

============================================================
## mode_switch — Hidden widgets still feed build_command
============================================================

**Symptom**: User picks FEM mode, runs solve, the script crashes with
``argument --material: invalid choice: 'custom'`` even though the FEM
panel does NOT show any custom-material UI. Or: the FEM solve uses
``mu_r = 100`` (the BEM default) regardless of what the user picks.

**Root cause**: ``_build_fem_command`` reads ``self.val("mu_r")``,
but the ``mu_r`` widget was created in the BEM workpiece group and
hidden in FEM mode. The user has no way to change it from the FEM
panel, so the BEM default leaks into the FEM call. Worse, the
``--material custom`` flag was sent without the calc script declaring
"custom" as an accepted ``argparse`` choice — the script died with
exit 2.

**Rules**:

  1. Any widget READ by ``_build_*_command`` for a method MUST be
     visible in that method's panel. Hidden widgets are
     no-user-control state — silent UI bug.
  2. Every CLI flag the GUI sends MUST be in the calc script's
     ``argparse choices``. Use ``custom`` as the explicit "user
     specifies mu_r/sigma directly" choice when the script also
     supports built-in material lookup.
  3. When you delete a Method combo entry, scrub ALL widget
     visibility in ``_on_method_changed`` so the new mode does not
     inherit stale rows from the old one.

**Reference**: commit ``8b34b04`` (calc_fem_kelvin --material custom),
commit ``1aa66ee`` (unified BEM/FEM widget set).

============================================================
## layout_unification — Mode-specific widgets are usually wrong
============================================================

**Symptom**: BEM panel shows "Coil sigma" but FEM does not. FEM shows
"Current [A]" + "Coil radius" + "Workpiece radius" but BEM does not.
The two panels look unrelated even though they solve the same
physics problem.

**Root cause**: Each method was developed independently with its own
widget set. Over time the two diverged because nobody enforced
"same physics -> same parameters".

**Rule**: For panels that offer multiple solver methods, the widget
set should be a SHARED superset. Method-specific differences should
be limited to:

  - Solver combo items (different solver per method)
  - Iteration cap (FEM iterative, BEM direct)
  - Post-processing toggles (e.g. "air field calc" — BEM only because
    FEM volume mesh always carries the field)

For Radia IH the user has stated explicitly:

  > BEMとFEMの違いは、Solverの違いと、Air field calcの有無程度では？

i.e. the only allowed differences are Solver and Air field calc.
Frequency, current, coil sigma, workpiece sigma, mu_r, half thickness,
SIBC/ESIM choice, BH file are SHARED across methods.

**Reference**: commit ``1aa66ee``, ``radia_ih.py::IHPanel._build_ui``
("Layout (per user request 2026-04-12)" comment block).

============================================================
## gmsh_viz — Mesh elements obscure the field
============================================================

**Symptom**: GMSH opens the .msh file the panel wrote and the model
is **completely black** — a sphere of internal triangle edges
covering the entire object. No field arrows visible.

**Root cause**: ``GmshPostExport`` writes the volume / surface mesh
together with the field views. GMSH defaults render
``Mesh.Volumes / VolumeFaces / VolumeEdges / SurfaceEdges /
SurfaceFaces`` all to ON, so a 100k-element sphere mesh draws as a
black blob.

**Rule**: Always write a **companion ``.geo`` file** next to the
``.msh`` that hides the mesh primitives and configures the field
views as 3D arrows:

```
Merge "model.msh";
Mesh.NumSubEdges = 4;
Mesh.Volumes = 0;
Mesh.VolumeFaces = 0;
Mesh.VolumeEdges = 0;
Mesh.SurfaceEdges = 0;
Mesh.SurfaceFaces = 0;
View[0].VectorType = 4;       // 3D arrow
View[0].IntervalsType = 3;
View[1].VectorType = 4;
View[1].IntervalsType = 3;
```

The "Open GMSH" button in the panel should open the ``.geo``, NOT
the raw ``.msh``, so these display options are applied automatically.

**Reference**: commit ``1aa66ee``, ``calc_fem_kelvin.py`` Step 7;
commit ``8dbee35``, ``calc_inductance.py::post_process``.

============================================================
## gmsh_viz — Scalar |B| / |J| views are redundant
============================================================

**Symptom**: The panel exports both a vector ``B`` view and a scalar
``|B|`` view. The user reports they only want the vector. Same for
``|J|``.

**Root cause**: GMSH's vector view already shows the magnitude (the
arrow color encodes ``|B|`` by default). A separate scalar view
clutters the View list and wastes file space.

**Rule**: Export VECTORS only. Drop ``add_field("|B|", ...)`` and
``add_scalar_field("|B|", ...)`` calls. The user picks the vector
view in GMSH and gets magnitude as a free side effect. The same
applies to ``|J|``: vector only, never the scalar magnitude.

**Reference**: commit ``8dbee35`` (BEM B/J), commit ``1aa66ee`` (FEM
B/J).

============================================================
## gmsh_viz — Visualization quality checklist (regression guard)
============================================================

**Symptom**: New GMSH outputs look noticeably worse than older
outputs from the same panel. Common regression patterns:

  - sphere appears black (volume mesh edges fill the screen)
  - field views are present but show flat color (no arrows)
  - high-order curving is lost; coil renders as faceted polygon
  - only B is exported; J is missing
  - the Open GMSH button enables but the .msh has no field data

**Root cause**: Each new export refactor drops one or two of the
quality knobs the previous version had. Without a checklist the
quality drifts down monotonically with every refactor.

**Rule — checklist for any new GMSH export from a panel**:

DO:

  - Write a **vector** view per physical quantity (B, J, A, ...).
    Use ``add_field("B", node_data, ncomp=3)``.
  - Per-vertex evaluate the CoefficientFunction directly:

    ```python
    arr = np.zeros((mesh.nv, 3))
    for vi, v in enumerate(mesh.vertices):
        val = cf(mesh(*v.point))
        arr[vi] = [float(getattr(x, "real", x)) for x in val[:3]]
    ```

    NodeData on the original vertices renders cleanly even on
    high-order curved meshes — no projection-induced artifacts.

  - Export BOTH the field-source view (J on the coil) AND the
    field-effect view (B everywhere). One view alone is half the
    story; the user always wants to correlate the two.

  - Restrict source-side views to the relevant material:
    ``add_field("J", node_J, ncomp=3, material="coil")`` so the
    arrows do not pollute the air domain.

  - Write a **companion ``.geo`` file** next to the .msh and have
    the panel's "Open GMSH" button open the .geo, NOT the .msh.
    The .geo applies the display options below automatically.

  - Apply these display options in the .geo:

    ```
    Mesh.NumSubEdges = 4;       // smooth high-order curving
    Mesh.Volumes = 0;           // hide air tetrahedra
    Mesh.VolumeFaces = 0;
    Mesh.VolumeEdges = 0;
    Mesh.SurfaceEdges = 0;      // hide internal triangle edges
    Mesh.SurfaceFaces = 0;
    View[0].VectorType = 4;     // 3D arrow style for B
    View[0].IntervalsType = 3;  // continuous color map
    View[1].VectorType = 4;     // 3D arrow style for J
    View[1].IntervalsType = 3;
    ```

  - Activate ``mesh.Curve(N)`` (N >= 2) on the source mesh BEFORE
    writing so the GMSH exporter can emit Tri6/Tri10 elements with
    correct mid-edge nodes. Linear-only export of a high-order .vol
    silently degrades the geometry visualization.

  - Always provide a **fallback** path that writes a mesh-only
    .msh when the field-write fails (see ``silent_except`` topic),
    so the Open GMSH button always enables.

DON'T:

  - **Do not** add a separate ``|B|`` / ``|J|`` scalar view. The
    vector view already encodes magnitude in its arrow color. The
    scalar duplicates information and clutters the View list.

  - **Do not** leave ``Mesh.Volumes = 1`` (the GMSH default). On a
    100k-element sphere mesh that draws as a black blob and hides
    every field arrow.

  - **Do not** write per-element ElementData when per-vertex
    NodeData is what GMSH wants for arrow rendering. Per-element
    arrows are constant within each cell and look chunky;
    per-vertex arrows interpolate smoothly.

  - **Do not** project a vector quantity to a scalar GridFunction
    just to use ``Set()``. ``H1(mesh, dim=3)`` is not a real API;
    ``VectorH1`` and ``H1(...)**3`` work but add nothing over
    direct CF evaluation, and ``Set(complex_cf)`` on a real space
    raises silently. Skip the projection entirely.

  - **Do not** ship just B without J (or vice versa). The user
    always wants both.

  - **Do not** open the raw .msh from the panel button. Open the
    companion .geo instead so the display options are applied.

**Reference**: commits ``d364796`` (FEM B/J vector + companion .geo
+ mesh-only fallback), ``1aa66ee`` (initial unified BEM/FEM viz),
``8dbee35`` (BEM dropping ``|B|``/``|J|`` scalars). Past quality
regressions traced from comparing ``calc_fem_kelvin.py`` Step 7
across these commits.

============================================================
## gmsh_arrow_size — Without ArrowSizeMin/Max the field is invisible
============================================================

**Symptom**: GMSH .geo opens, B view is selected, the user sees a
clean wireframe coil but **no arrows at all**. Or: arrows are
visible but tiny dots, indistinguishable from the background mesh.
The user reports "出力されるgmshの質が過去のものより劣化していた".

**Root cause**: GMSH's vector view defaults to ``ArrowSize* = 60``
**relative to the bounding box**, which for a 0.24 m air sphere
gives arrows that are physically a few mm long — invisible at the
default zoom. ``View.VectorType = 4`` alone is not enough; without
fixed pixel sizes the arrows do not render at a useful scale.

The v3.6.1 (commit ``5e0b69c``, 2026-03-23) version of
``calc_inductance.py post_process`` set:

```
View[0].ArrowSizeMin = 20;
View[0].ArrowSizeMax = 20;
View[1].ArrowSizeMin = 20;
View[1].ArrowSizeMax = 20;
```

That gave the consistently beautiful field arrows everyone praised.
A 2026-04-12 refactor of the same companion .geo writer dropped
these lines (left it at GMSH defaults), and the field views became
invisible without the user noticing — the comment in the new code
even said "the arrow size is left at GMSH's auto-scale" as if that
were a feature.

**Rule**: Every ``.geo`` companion file the panel writes MUST set:

```
View[N].VectorType = 4;          // 3D arrow style
View[N].IntervalsType = 3;       // continuous color map
View[N].ArrowSizeMin = 20;       // FIXED 20 px — do NOT auto-scale
View[N].ArrowSizeMax = 20;
```

for **every** vector view in the .msh. Without ArrowSizeMin/Max
the field is functionally invisible. There is no scenario where
GMSH's auto-scale produces a useful default for Radia output, so
the "leave it default" path is wrong by definition.

**Reference**: commit ``5e0b69c`` (original beautiful version),
commit ``d949d50`` (regression: dropped the arrow sizes), this
commit (restored).

============================================================
## subprocess_args — calc_*.py choices must match GUI combos
============================================================

**Symptom**: GUI combo has items ``[sibc, esim]``, but the calc
script's ``argparse`` declares ``choices=["esim", "dowell"]``. User
picks "sibc" in the GUI, the subprocess dies with
``argument --impedance-model: invalid choice: 'sibc'``.

**Root cause**: GUI labels and CLI labels drifted independently.
Often the GUI uses the more user-friendly term and the script keeps
the original internal name.

**Rule**: When you rename a combo item, EITHER:

  1. Add the new name as an explicit alias in the calc script's
     argparse ``choices`` and translate to the internal name in the
     ``__main__`` block (``imp == "sibc" -> imp = "dowell"``), OR
  2. Update both sides in the same commit and verify.

Either way, write a quick smoke test that constructs the command via
``_build_*_command`` and checks ``argparse.parse_args(cmd[1:])``
accepts every option.

**Reference**: commit ``8dbee35``, ``calc_inductance.py`` accepts
``sibc`` as alias for legacy ``dowell``.

============================================================
## subprocess_args — Hidden widgets feed argparse
============================================================

**Symptom**: GUI runs the FEM solver successfully but the result is
nonsense — sigma reports 2e6 even though user typed 5.8e7 in
the BEM tab.

**Root cause**: ``self.val("wp_sigma")`` returns the LAST text the
user typed in that widget, regardless of whether the widget is
currently visible. Mode switches don't reset values — they only
toggle visibility. So a value set under BEM persists across mode
switches and silently feeds the FEM call.

**Rule**: Either keep the widget VISIBLE in every mode that reads
it (preferred — see ``layout_unification``), or RESET its value to
the per-method default in ``_on_method_changed``. Never read a hidden
widget in ``_build_*_command``.

**Reference**: commit ``1aa66ee``, ``IHPanel._build_fem_command``
now reads only widgets that are visible in FEM mode.

============================================================
## cubit_jou — `subtract A from B keep_tool` id semantics
============================================================

**Symptom**: ``${kelvin_top = Id("volume")}`` after a subtract
returns the wrong volume id. Subsequent block / sideset commands
silently target the wrong volume, blocks come up empty, sidesets
fail with "no surface".

**Root cause**: Cubit 2025.3's ``subtract A from B keep_tool`` has
two behaviors depending on B's id:

  - **B is below the current max id**: B is MODIFIED in place. Its
    id stays the same. ``Id("volume")`` after the call returns the
    global max (some unrelated volume), not B.
  - **B IS the current max id**: B is REPLACED with a new id =
    max + 1. ``Id("volume")`` after the call returns the new id.

The two cases are silent — Cubit's "Updated volume(s): N" message
shows the modified id either way.

**Rule**: Capture volume ids RIGHT AFTER the operation that creates
them, and re-capture only when the operation creates a new id.
Single-tool subtract on a non-max body does NOT create a new id; do
not re-capture in that case. Multi-tool subtract on a max-id body
DOES create a new id; re-capture with ``${name = Id("volume")}``.

When in doubt, write a smoke ``test_*.jou`` that runs the script
through ``coreform_cubit -batch -nographics`` and verifies the block
membership.

**Reference**: commit ``ac64254``, ``examples/induction_heating/demoted_samples/ih_fem_kelvin_sample.jou``
header comment "subtract ... keep_tool id semantics".

============================================================
## cubit_jou — Sweep gap-face surface ids drift after imprint
============================================================

**Symptom**: ``sideset 1 add surface 1`` works in ``ih_bem_sample.jou``
(simple subtract sequence) but fails in ``examples/induction_heating/demoted_samples/ih_fem_kelvin_sample.jou``
(extra webcuts + subtracts) — surface 1 no longer exists after the
multiple imprint+merge cycles.

**Root cause**: Each ``imprint`` operation can renumber surface ids.
Hardcoded IDs are valid only for the EXACT operation order they were
captured under.

**Rule**: For sample .jou files that go through multiple imprint
cycles, identify the gap faces by **area + centroid** instead of by
hardcoded id:

```
group "coil_gaps" add surface in volume {coil_vid} with area < 0.0001
sideset 1 add surface in coil_gaps with y_coord > -0.001
sideset 1 name "source"
sideset 2 add surface in coil_gaps with y_coord < -0.001
sideset 2 name "sink"
```

Keep simpler scripts (single subtract, no webcut) on hardcoded ids
if they are verified to work — those are easier to read.

**Reference**: commit ``ac64254``, ``examples/induction_heating/demoted_samples/ih_fem_kelvin_sample.jou``
section 11 ``Sidesets``.

============================================================
## sample_jou — One sample per (panel, solver method) pair
============================================================

**Symptom**: A single ``ih_sample.jou`` was used for both BEM and FEM
modes of the IH panel, but BEM needs only a small air sphere
(surface integral equation, open BC) and FEM needs either a large
air sphere (Dirichlet truncation) or a Kelvin exterior domain (exact open BC).
Forcing one geometry to serve both made BEM slow and FEM inaccurate.

**Rule**: Ship one sample .jou per (panel, solver method) pair when
the methods need fundamentally different mesh topology. Naming
convention:

  ``{stem}_{method}_sample.jou``

Examples (current layout after the 2026-04-23 demotion):

  panels/samples/ih_bem_sample.jou        (BEM, shipped in wheel)
  panels/samples/ih_peec_bem_coarse.jou   (peec_bem canonical, golden)
  panels/samples/ih_fem_kelvin_skin_fine.jou
                                          (fem_coilmesh canonical, golden)
  panels/samples/ih_peec_inductance.jou   (peec_inductance canonical)

The no-Kelvin FEM baseline (``ih_fem_sample.jou``) and the small-mesh
FEM + Kelvin variant (``ih_fem_kelvin_sample.jou``) that used to live
next to these are now under ``examples/induction_heating/demoted_samples/``
— they were not golden-tested and the Kelvin variant shipped with a
misleading "auto-Kelvin" comment.  Any NEW sample must stay aligned
with the (panel, solver method) = one-file rule and be golden-locked
before joining ``panels/samples/``.

**Reference**: commit ``ac64254`` (split), commit ``241090c``
(restored BEM-validated mesh density), 2026-04-23 demotion commit
(moved non-canonical samples to examples/).

============================================================
## silent_action — Menu actions must produce visible feedback
============================================================

**Symptom**: User clicks "Verify Deploy" in the Solve menu. Nothing
happens — no dialog, no console output, no busy cursor. The user
reports "押しても何もおきない".

**Root cause**: The handler wrote its mtime/sha1 report to
``C:/radia_panel_log.txt`` via ``_panel_log()`` and **only** there.
The user has no reason to be tailing that file, so the action is
indistinguishable from a no-op.

**Rule**: Any user-triggered menu action MUST produce a visible
result. Acceptable channels:

  1. **QMessageBox** for ad-hoc reports / confirmations
  2. The panel **output text widget** (``self._output.appendPlainText``)
     for streaming subprocess output
  3. A new **window** for non-trivial reports

Writing to a debug log file is fine as a SECONDARY record but never
the only output. Test by clicking the button: if the screen does not
change, the handler is broken regardless of whether the file got
written.

**Reference**: commit ``d364796``, ``register_toolbar.py::
_verify_deploy``.

============================================================
## silent_except — Bare except hides field-export bugs
============================================================

**Symptom**: GMSH "Open" button stays disabled after a successful
FEM run. Result panel shows L, P, Q, time — everything looks normal.
Panel debug log says ``msh_file (value='') — Open GMSH disabled``.

**Root cause**: The GMSH export step inside ``calc_fem_kelvin.py``
was wrapped in ``try / except Exception as e: _log(f"GMSH_ERROR:{e}")``.
The actual exception was ``H1() got an unexpected keyword argument
'dim'`` (the ``H1(mesh, order=1, dim=3)`` API does not exist — vector
H1 is built via ``H1(...)**3`` or ``VectorH1``). The bare except
swallowed the AttributeError, ``_log`` printed only the short
``str(e)`` to stderr (which was already past the visible output
window), and ``gmsh_file`` stayed at its initial empty string.

The result dict shipped ``msh_file=""``, the panel saw an empty
path, and disabled the Open GMSH button — looking exactly like a
"no field exported, success ignored" silent failure.

**Rules**:

  1. Never log just ``str(e)`` from a bare except. Log
     ``type(e).__name__`` AND the **last few lines of the
     traceback** so the actual offending API call is visible:

     ```python
     except Exception as e:
         import traceback
         tb = traceback.format_exc()
         _log(f"GMSH_ERROR:{type(e).__name__}: {e}")
         for line in tb.splitlines()[-4:]:
             _log(f"GMSH_ERROR:  {line}")
     ```

  2. **Always provide a fallback** that still produces SOMETHING
     openable. Even if the field-write fails, write a mesh-only
     ``.msh`` so the Open GMSH button enables and the user gets
     the geometry:

     ```python
     except Exception:
         post_min = GmshPostExport(mesh, boundary=False)
         post_min.write_mesh(msh_output)
         gmsh_file = msh_output
     ```

  3. Don't use ``H1(mesh, dim=N)`` — that signature does not exist
     in NGSolve. For per-vertex vector evaluation in a GMSH export,
     skip the GridFunction projection entirely and evaluate the
     CoefficientFunction directly at each ``mesh.vertices[i].point``.
     The (n_v, 3) numpy array goes straight into the GMSH NodeData
     section.

**Reference**: commit ``d364796``, ``calc_fem_kelvin.py`` Step 7.

============================================================
## result_keys — Subprocess result dict keys are an API contract
============================================================

**Symptom**: One panel script returns ``"msh_file"`` in its result
dict, another returns ``"msh_output"``, a third returns
``"gmsh_file"``. The GUI's ``_on_finished`` has to test for all of
them, and any new script that picks a different name silently
breaks the Open GMSH button.

**Root cause**: Each calc_*.py was developed independently and
each author picked a slightly different key name for the same
concept ("path of the GMSH file the user should open").

**Rule**: Subprocess result dicts have a **stable, documented set
of keys** that the GUI relies on. The current contract for the IH
panel:

  ``msh_output`` or ``msh_file``  -- raw .msh path the user can open
                                     (Open GMSH button uses either)
  ``field_gmsh_file``              -- preferred .geo path that Merges
                                     mesh + field views with display
                                     options applied (overrides
                                     msh_output when present)
  ``inductance_H``                 -- headline result for L
  ``coupled_*``                    -- coupled BEM headline results
  ``error``                        -- single string, presence
                                     suppresses success display

When you add a new key, update the gui_base.py ``_on_finished``
handler in the same commit. When you rename a key, grep for it
across ``radia_gui_base.py`` AND every ``radia_*.py`` panel before
shipping.

**Reference**: ``radia_gui_base.py::_on_finished`` lines 425-470,
which has the canonical "what the GUI looks for" logic.

============================================================
## regression_blast_radius — One edit breaks an unrelated place
============================================================

**Symptom**: Fixing the FEM panel's Open GMSH button suddenly
breaks the BEM panel. Adding a return_vertex_map kwarg to
``_extract_surface_mesh_filtered`` makes BEM die with
``TypeError: int() argument must be a string ... not PointId``
on a code path the FEM fix did not touch. The user reports
"どっかをいじるとどっか別のところが壊れる".

**Root cause**: The Radia panels share a lot of utility code via
``calc_common.py`` / ``calc_heating_bem.py`` / the BEM solver. A
"local" change to one panel that touches a shared helper has a
**blast radius** that the immediate test doesn't catch:

  - Adding a kwarg with a new return type breaks every existing
    caller that did not opt in.
  - Renaming a result-dict key breaks the GUI's ``_on_finished``
    consumer regardless of which panel script wrote it.
  - Changing a calc_*.py argparse default breaks any sample run
    that relied on the old default being passed implicitly.
  - Tightening a CoefficientFunction signature breaks every
    GridFunction.Set() call in the same module.

The PointId crash above came from a one-line construction:

```python
new_to_old = {int(new_id) - 1: int(old_nr)
               for old_nr, new_id in old_to_new.items()}
```

``int(PointId)`` raises TypeError on netgen's PointId class.
Discovered only when the user ran BEM (not FEM, the panel I was
editing).

**Rules**:

  1. **Run BOTH panels** after touching any shared helper, even
     when "the change is only for FEM". If the helper lives in
     ``calc_heating_bem.py`` or ``calc_common.py``, the smoke
     test must cover at least one BEM run AND one FEM run.

  2. **Optional kwargs** that change return type are dangerous —
     prefer adding a separate function or making the new return
     a tuple ``(old_result, extra)`` with a clear opt-in flag,
     and write a regression test that exercises the OLD signature.

  3. **Cast carefully** — ``int(x)`` works for built-in numerics
     but not for opaque library wrappers like netgen's PointId.
     When in doubt use the explicit attribute (``x.nr`` for
     PointId) and document why in a comment.

  4. **Result dict keys** are an API contract (see ``result_keys``
     topic). Renaming requires grep across every consumer.

  5. After any non-trivial edit, **list every file that imports
     the changed function** and run the smoke test for each
     consumer panel. ``grep -rln "_extract_surface_mesh_filtered"
     src/radia/`` is faster than discovering the regression in
     production.

**Reference**: commits ``1aa66ee`` (introduced
``return_vertex_map``), ``d364796`` (broke BEM via PointId int
cast), this commit (restored ``.nr`` access + added rule).

============================================================
## panel_qt_testing — Headless Qt tests catch behaviour bugs
============================================================

**Symptom**: Multiple GUI bugs slipped past pre-deployment string-
grep "tests" because ``inspect.getsource(IHPanel)`` only proves a
literal substring is present in the code, not that the widget
actually does what the user sees:

  - empty Method combo on first launch (combo_state)
  - Open GMSH grey out after FEM (silent_except)
  - hidden widgets feeding build_command (mode_switch)

**Rule**: Use **headless PySide6 widget tests** for any user-visible
panel behaviour. The test infrastructure lives in:

```
tests/panels/conftest.py             # session QApplication fixture
tests/panels/test_ih_panel_qt.py     # Method combo, mode switch,
                                     # workpiece group, command
                                     # roundtrip
tests/panels/test_panel_state_restore.py
                                     # save/restore by text + legacy
                                     # int migration
tests/panels/test_open_gmsh_button.py
                                     # button enable/disable rules
                                     # against mock result dicts
```

The conftest fixture sets ``QT_QPA_PLATFORM=offscreen`` BEFORE
importing PySide6, so the tests run on a CI runner without an
X server. The session-scoped ``QApplication`` is shared across all
test files; per-test ``ih_panel`` and ``ih_window`` fixtures
instantiate fresh widgets and call ``deleteLater()`` on teardown.

**Patterns to copy when adding a new pitfall test**:

```python
def test_default_method_is_BEM(self, ih_panel):
    # Pin the panel-level default — no blank widget on first launch
    assert ih_panel._method_combo.currentText() == "BEM"

def test_FEM_workpiece_widgets_visible(self, ih_panel):
    # Pin layout_unification: shared widget set across modes
    ih_panel._method_combo.setCurrentText("FEM")
    ih_panel._widgets["workpiece_mode"].setCurrentText("SIBC")
    assert ih_panel._widgets["wp_sigma"].isVisibleTo(ih_panel)
    assert ih_panel._widgets["mu_r"].isVisibleTo(ih_panel)

def test_FEM_command_parses(self, ih_panel):
    # Pin subprocess_args: GUI -> calc_*.py argparse roundtrip
    ih_panel._method_combo.setCurrentText("FEM")
    cmd = ih_panel.build_command("model.vol")
    parser = _calc_fem_kelvin_argparse()
    ns = parser.parse_args(cmd[2:])
    assert ns.material == "custom"
```

When you add a new pitfall to this knowledge file, add a matching
test to the panel_qt suite in the SAME commit. The test stays
green forever as a regression guard, and the next contributor sees
both "the pitfall" and "the test that proves you fixed it".

Run::

    QT_QPA_PLATFORM=offscreen pytest tests/panels/test_ih_panel_qt.py
                                     tests/panels/test_panel_state_restore.py
                                     tests/panels/test_open_gmsh_button.py

30 tests, ~1.2 s on a laptop. Cheap enough to run on every commit.

**Reference**: this commit (test infrastructure bootstrap, 2026-04-12).

============================================================
## learn_edition_cap — Cubit Learn Edition 50k limit is harmless
============================================================

**Symptom**: Running a sample .jou through Cubit Learn Edition prints
``ERROR: Coreform Cubit - Learn Edition restricts export to models
with less than 50k elements.`` for a 147k-element model. New
contributors think the export failed and start coarsening the mesh.

**Root cause**: The cap applies to Cubit's own ``export gmsh`` /
``export vtk`` / ``export exo`` exporters. The Radia in-tree
``radia_export netgen`` plugin BYPASSES the cap and writes the .vol
regardless of the warning. Both the ERROR line and the
``Exported Netgen Vol (order N): ...`` line appear in the same Cubit
run, so the export succeeded.

**Rule**: Tune sample .jou meshes to whatever density the physics
needs (typically the BEM-validated reference density). Never coarsen
to "fit under 50k". The deployed LAB / 100号機 / mdx machines all
run Cubit Pro and never see the warning.

**Reference**: ``CLAUDE.md`` § "Cubit Learn Edition 50k Element Cap",
commit ``334d84f``.
"""


_TOPICS = (
    "combo_state",
    "mode_switch",
    "layout_unification",
    "gmsh_viz",
    "gmsh_arrow_size",
    "subprocess_args",
    "cubit_jou",
    "sample_jou",
    "silent_action",
    "silent_except",
    "result_keys",
    "regression_blast_radius",
    "panel_qt_testing",
    "learn_edition_cap",
)


def get_panel_gui_pitfalls(topic: str = "") -> str:
    """Return the panel GUI pitfalls knowledge.

    Args:
        topic: Empty for the full document, or one of the entries in
               ``_TOPICS`` above.

    Multiple sections share the same ``gmsh_viz`` keyword (vector-only
    + companion .geo); requesting that topic returns BOTH sections so
    the reader gets the complete pitfall together.
    """
    if not topic:
        return PANEL_GUI_PITFALLS

    if topic not in _TOPICS:
        return (f"Unknown topic: {topic!r}. Available topics:\n"
                f"  {', '.join(_TOPICS)}\n\n"
                f"Pass empty string for the full document.")

    # Build a list of (topic_keyword, char_offset) for every section
    # header in the document. The header line format is exactly
    # ``## <topic> — <title>`` (one space, em-dash). Then slice from
    # the requested topic's previous "## ===" delimiter up to the
    # NEXT topic's "## ===" delimiter (or end of document).
    headers = []
    pos = 0
    while True:
        next_pos = PANEL_GUI_PITFALLS.find("\n## ", pos)
        if next_pos < 0:
            break
        line_end = PANEL_GUI_PITFALLS.find("\n", next_pos + 1)
        line = PANEL_GUI_PITFALLS[next_pos + 1:line_end]
        for t in _TOPICS:
            if line.startswith(f"## {t} "):
                headers.append((t, next_pos + 1))
                break
        pos = next_pos + 1

    # Find requested + next-distinct-topic positions.
    req_starts = [off for kw, off in headers if kw == topic]
    if not req_starts:
        return f"Topic {topic!r} declared but not found in document."
    section_start = PANEL_GUI_PITFALLS.rfind(
        "## ===", 0, req_starts[0])
    if section_start < 0:
        section_start = req_starts[0]

    # End = start of the next section whose topic differs from the
    # requested one. This keeps both ``gmsh_viz`` sections together.
    section_end = len(PANEL_GUI_PITFALLS)
    last_req = req_starts[-1]
    for kw, off in headers:
        if kw != topic and off > last_req:
            # Slice ends at the delimiter line just above this header.
            delim = PANEL_GUI_PITFALLS.rfind("## ===", 0, off)
            section_end = delim if delim > 0 else off
            break

    return PANEL_GUI_PITFALLS[section_start:section_end].rstrip() + "\n"
