# neruva-mcp

Model Context Protocol server for [Neruva](https://neruva.io) — vector memory + HD-native substrate. Same 8 tools as the TypeScript package, for Python-only MCP hosts (e.g. Codex, custom agents).

## Install

```bash
pip install neruva-mcp
export NERUVA_API_KEY=...        # from https://app.neruva.io
```

Or zero-install via `uvx`:

```bash
uvx neruva-mcp
```

## Use

Add to your MCP host's config. Example for Claude Code:

```bash
claude mcp add neruva -- uvx neruva-mcp -e NERUVA_API_KEY=YOUR_KEY
```

Or run directly:

```bash
NERUVA_API_KEY=YOUR_KEY neruva-mcp
```

## Tools

| Tool | What it does |
|---|---|
| `memory_upsert` | Insert/update vectors in a namespace (Pinecone-compatible) |
| `memory_query`  | Top-K cosine search |
| `memory_delete` | Delete by id |
| `hd_kg_add_fact` | Add (subject, relation, object) to a KG |
| `hd_kg_query` | Query KG for object of (subject, relation) |
| `hd_analogy` | Four-term analogy in HD feature space |
| `hd_causal_query` | Observational / interventional query on stored SCM |
| `hd_plan` | EFE active-inference planner |

## Env

| Variable | Default |
|---|---|
| `NERUVA_API_KEY` | required |
| `NERUVA_URL` | `https://api.neruva.io` |

## License

MIT — Clouthier Simulation Labs.
