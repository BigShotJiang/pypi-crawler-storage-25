"""Neruva MCP server.

Exposes Neruva Memory + HD Substrate to any MCP-aware host as a small
set of tools. Pure thin wrapper over the REST API at api.neruva.io --
this process holds NO algorithmic state and imports nothing from the
substrate core. The hard work happens server-side; this is just glue.

Env:
  NERUVA_API_KEY  required, your key from app.neruva.io
  NERUVA_URL      optional, defaults to https://api.neruva.io
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from typing import Any
from urllib.parse import quote

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

API_KEY = os.environ.get("NERUVA_API_KEY")
BASE_URL = os.environ.get("NERUVA_URL", "https://api.neruva.io").rstrip("/")


def _enc(s: str) -> str:
    return quote(s, safe="")


async def _call(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    body: Any | None = None,
) -> Any:
    headers = {"Api-Key": API_KEY or ""}
    if body is not None:
        headers["Content-Type"] = "application/json"
    r = await client.request(method, BASE_URL + path, headers=headers, json=body)
    if r.status_code >= 400:
        raise RuntimeError(f"{method} {path} -> {r.status_code}: {r.text}")
    try:
        return r.json()
    except Exception:
        return r.text


TOOLS: list[Tool] = [
    Tool(
        name="memory_create_index",
        description=(
            "Create a Pinecone-compatible vector index. Required once before "
            "memory_upsert / memory_query / memory_delete can be used. "
            "Idempotent on existing indexes."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Index name"},
                "dimension": {
                    "type": "integer",
                    "description": "Vector dimension (e.g. 1024 for static-MRL)",
                },
                "metric": {
                    "type": "string",
                    "enum": ["cosine", "dotproduct", "euclidean"],
                    "default": "cosine",
                },
            },
            "required": ["name", "dimension"],
        },
    ),
    Tool(
        name="memory_upsert",
        description=(
            "Insert or update vectors in a Neruva Memory namespace. The "
            "index must exist (create it once with memory_create_index)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string", "description": "Index name"},
                "namespace": {
                    "type": "string",
                    "description": "Namespace; defaults to ''",
                    "default": "",
                },
                "vectors": {
                    "type": "array",
                    "description": "Vectors: {id, values, metadata?}",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "values": {"type": "array", "items": {"type": "number"}},
                            "metadata": {"type": "object"},
                        },
                        "required": ["id", "values"],
                    },
                },
            },
            "required": ["index", "vectors"],
        },
    ),
    Tool(
        name="memory_query",
        description="Cosine-search a namespace by vector. Returns top-K matches with metadata.",
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "vector": {"type": "array", "items": {"type": "number"}},
                "topK": {"type": "integer", "default": 10},
                "includeMetadata": {"type": "boolean", "default": True},
                "includeValues": {"type": "boolean", "default": False},
            },
            "required": ["index", "vector"],
        },
    ),
    Tool(
        name="memory_delete",
        description="Delete vectors by id from a namespace. The index must exist.",
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["index", "ids"],
        },
    ),
    Tool(
        name="hd_kg_add_fact",
        description=(
            "Add a (subject, relation, object) fact to a knowledge graph. "
            "The KG is auto-created on first add. Persists across restarts."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string", "description": "Knowledge-graph name"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "object": {"type": "string"},
            },
            "required": ["kg", "subject", "relation", "object"],
        },
    ),
    Tool(
        name="hd_kg_query",
        description=(
            "Query a knowledge graph for the object of (subject, relation). "
            "Returns object + confidence. Returns object=null with confidence=0 "
            "when the subject is unknown or no fact matches above the noise "
            "threshold (cosine 0.05)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
            },
            "required": ["kg", "subject", "relation"],
        },
    ),
    Tool(
        name="hd_kg_delete_fact",
        description=(
            "Remove a previously-added (subject, relation, object) triple from a "
            "knowledge graph. Subtracts the bound vector from the relation shard, "
            "exactly cancelling the original add. Required for any mutable-state "
            "use case (refactor tracking, deploy status, project state). Triples "
            "whose tokens are unknown are skipped (no-op, not error)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string", "description": "Knowledge-graph name"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "object": {"type": "string"},
            },
            "required": ["kg", "subject", "relation", "object"],
        },
    ),
    Tool(
        name="hd_analogy",
        description=(
            "Solve a four-term analogy in HD feature space: a is to b as c is to ? "
            "Items are integer feature IDs in [0, 2^n_feat). Returns the cleaned-up "
            "candidate plus cosine, runner-up cosine, and a confidence gap."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "n_feat": {"type": "integer", "description": "Number of binary features. Item space size is 2^n_feat."},
                "a": {"type": "integer"},
                "b": {"type": "integer"},
                "c": {"type": "integer"},
                "seed": {"type": "integer", "default": 4301},
            },
            "required": ["n_feat", "a", "b", "c"],
        },
    ),
    Tool(
        name="hd_causal_add_worlds",
        description=(
            "Add or extend a structural causal model (SCM) with integer-coded worlds. "
            "Required once before hd_causal_query can run on a given SCM name. Worlds "
            "are rows of length n_vars; each entry is the value of that variable."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string", "description": "SCM name"},
                "n_vars": {"type": "integer", "description": "Number of variables"},
                "vocab_per_var": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Cardinality per variable; length must equal n_vars",
                },
                "worlds": {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "integer"}},
                    "description": "Shape (N, n_vars). Each row is one world.",
                },
                "seed": {"type": "integer", "default": 4401},
            },
            "required": ["scm", "n_vars", "vocab_per_var", "worlds"],
        },
    ),
    Tool(
        name="hd_causal_query",
        description=(
            "Run an observational or interventional query against a stored causal model. "
            "The SCM must exist (call hd_causal_add_worlds first). query_type is "
            "'observation' or 'intervention' -- arithmetically distinct."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string", "description": "Causal-model name"},
                "query_type": {"type": "string", "enum": ["observation", "intervention"]},
                "condition_var": {"type": "integer"},
                "condition_value": {"type": "integer"},
                "query_var": {"type": "integer"},
                "query_value": {"type": "integer"},
            },
            "required": [
                "scm",
                "query_type",
                "condition_var",
                "condition_value",
                "query_var",
                "query_value",
            ],
        },
    ),
    # hd_plan removed in 0.2.0. Returning in 0.2.x with
    # hd_plan_register_model + hd_plan_with_model so users can describe
    # their actual transition kernels.
]


async def _dispatch(client: httpx.AsyncClient, name: str, args: dict[str, Any]) -> Any:
    if name == "memory_create_index":
        return await _call(
            client,
            "POST",
            "/v1/indexes",
            {
                "name": args["name"],
                "dimension": args["dimension"],
                "metric": args.get("metric", "cosine"),
            },
        )
    if name == "memory_upsert":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/vectors/upsert",
            {
                "vectors": args["vectors"],
                "namespace": args.get("namespace", ""),
            },
        )
    if name == "memory_query":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/query",
            {
                "vector": args["vector"],
                "namespace": args.get("namespace", ""),
                "topK": args.get("topK", 10),
                "includeMetadata": args.get("includeMetadata", True),
                "includeValues": args.get("includeValues", False),
            },
        )
    if name == "memory_delete":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/vectors/delete",
            {
                "ids": args["ids"],
                "namespace": args.get("namespace", ""),
            },
        )
    if name == "hd_kg_add_fact":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/facts",
            {
                "facts": [
                    {
                        "subject": args["subject"],
                        "relation": args["relation"],
                        "object": args["object"],
                    }
                ]
            },
        )
    if name == "hd_kg_query":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/query",
            {"subject": args["subject"], "relation": args["relation"]},
        )
    if name == "hd_kg_delete_fact":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/facts/delete",
            {
                "facts": [
                    {
                        "subject": args["subject"],
                        "relation": args["relation"],
                        "object": args["object"],
                    }
                ]
            },
        )
    if name == "hd_analogy":
        return await _call(
            client,
            "POST",
            "/v1/hd/analogy",
            {
                "n_feat": args["n_feat"],
                "a": args["a"],
                "b": args["b"],
                "c": args["c"],
                "seed": args.get("seed", 4301),
            },
        )
    if name == "hd_causal_add_worlds":
        return await _call(
            client,
            "POST",
            f"/v1/hd/causal/{_enc(args['scm'])}/worlds",
            {
                "n_vars": args["n_vars"],
                "vocab_per_var": args["vocab_per_var"],
                "worlds": args["worlds"],
                "seed": args.get("seed", 4401),
            },
        )
    if name == "hd_causal_query":
        return await _call(
            client,
            "POST",
            f"/v1/hd/causal/{_enc(args['scm'])}/query",
            {
                "query_type": args["query_type"],
                "condition_var": args["condition_var"],
                "condition_value": args["condition_value"],
                "query_var": args["query_var"],
                "query_value": args["query_value"],
            },
        )
    raise ValueError(f"unknown tool: {name}")


async def _run() -> None:
    if not API_KEY:
        print(
            "[neruva-mcp] NERUVA_API_KEY not set. Get one at https://app.neruva.io",
            file=sys.stderr,
        )
        sys.exit(1)

    server: Server = Server("neruva")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return TOOLS

    async with httpx.AsyncClient(timeout=60.0) as client:

        @server.call_tool()
        async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
            try:
                result = await _dispatch(client, name, arguments or {})
                return [TextContent(type="text", text=json.dumps(result, indent=2))]
            except Exception as e:
                return [TextContent(type="text", text=f"error: {e}")]

        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
