"""supportsVision：profile 标记与解析。"""

from __future__ import annotations

from aicd.config import (
    LLMProfile,
    parse_supports_vision_bool,
)
from aicd.config_settings import format_llm_profiles_lines
from aicd.agent.handlers.llm_profiles import _profile_as_raw


def test_parse_supports_vision_string_false() -> None:
    assert parse_supports_vision_bool("false", default=True) is False
    assert parse_supports_vision_bool(False, default=True) is False
    assert parse_supports_vision_bool(None, default=True) is True


def test_llm_profile_to_mapping_includes_supports_vision() -> None:
    p = LLMProfile(
        name="x",
        proto="openai",
        base_url="https://api.openai.com/v1",
        api_key="k",
        model="gpt-4o-mini",
        supports_vision=False,
    )
    d = p.to_mapping()
    assert d["supportsVision"] is False


def test_llm_profile_from_mapping_roundtrip() -> None:
    p = LLMProfile.from_mapping(
        {
            "name": "t",
            "proto": "openai",
            "baseUrl": "https://x/v1",
            "apiKey": "",
            "modelId": "m",
            "supportsVision": False,
        }
    )
    assert p.supports_vision is False
    p2 = LLMProfile.from_mapping(p.to_mapping())
    assert p2.supports_vision is False


def test_profile_as_raw_preserves_supports_vision() -> None:
    p = LLMProfile(
        name="t",
        proto="openai",
        base_url="u",
        api_key="",
        model="m",
        supports_vision=False,
    )
    raw = _profile_as_raw(p)
    assert raw.get("supportsVision") is False


def test_format_llm_profiles_lines_shows_text_only() -> None:
    from aicd.config import AppConfig

    cfg = AppConfig()
    cfg.llm_profiles = [
        LLMProfile(
            name="a",
            proto="openai",
            base_url="",
            api_key="",
            model="m",
            supports_vision=False,
        )
    ]
    cfg.active_llm_profile = "a"
    s = format_llm_profiles_lines(cfg)
    assert "text-only" in s
