"""runtime_env.yaml 生成与刷新。"""

from __future__ import annotations

from pathlib import Path

import yaml

from aicd.env_probe import (
    CAPABILITIES_SUMMARY_FILENAME,
    RUNTIME_ENV_FILENAME,
    build_environment_digest,
    collect_runtime_env,
    format_env_capabilities_for_prompt,
    load_runtime_env_snapshot,
    refresh_runtime_env_file,
    runtime_env_path,
    summarize_commands,
)


def test_collect_runtime_env_shape() -> None:
    data = collect_runtime_env()
    assert "generated_at" in data
    assert "os" in data and "system" in data["os"]
    assert "terminal" in data
    assert "python" in data
    assert "commands" in data
    assert "python_modules_optional" in data
    assert isinstance(data["commands"], dict)
    assert "desktop_gui" in data
    assert "session_ok" in data["desktop_gui"]


def test_refresh_writes_yaml(tmp_path: Path) -> None:
    layout = {
        "data": tmp_path / "data",
        "root": tmp_path,
    }
    layout["data"].mkdir(parents=True)
    path, data = refresh_runtime_env_file(
        layout, aicd_runtime={"block_external_network": True}
    )
    assert path == tmp_path / "data" / RUNTIME_ENV_FILENAME
    assert path.is_file()
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert raw["aicd_version"] == data["aicd_version"]
    assert raw.get("aicd_runtime", {}).get("block_external_network") is True
    cap_txt = (
        tmp_path / "data" / CAPABILITIES_SUMMARY_FILENAME
    ).read_text(encoding="utf-8")
    assert "block_external_network=ON" in cap_txt
    avail, total = summarize_commands(data)
    assert total == len(data["commands"])
    assert 0 <= avail <= total
    cap = tmp_path / "data" / CAPABILITIES_SUMMARY_FILENAME
    assert cap.is_file()
    assert "Host capability snapshot" in cap.read_text(encoding="utf-8")


def test_format_env_capabilities_lists_missing(tmp_path: Path) -> None:
    data = collect_runtime_env()
    text = format_env_capabilities_for_prompt(data, yaml_path="/tmp/x.yaml")
    assert "Host capability snapshot" in text
    assert "runtime_env_refresh" in text.lower() or "skip" in text.lower()


def test_runtime_env_path_helper(tmp_path: Path) -> None:
    layout = {"data": tmp_path / "d"}
    assert runtime_env_path(layout) == tmp_path / "d" / RUNTIME_ENV_FILENAME


def test_load_runtime_env_snapshot_reads_disk(tmp_path: Path) -> None:
    layout = {
        "data": tmp_path / "data",
        "root": tmp_path,
    }
    layout["data"].mkdir(parents=True)
    refresh_runtime_env_file(layout)
    snap = load_runtime_env_snapshot(layout)
    assert "generated_at" in snap
    assert snap.get("os")


def test_build_environment_digest_shape() -> None:
    data = collect_runtime_env()
    d = build_environment_digest(
        data,
        ai_workspace_cwd="/w",
        ai_output_root="/w/aicd",
        ai_tmp_dir="/w/aicd/tmp",
        runtime_yaml_path="/h/runtime_env.yaml",
        capabilities_summary_path_str="/h/env_capabilities_summary.txt",
        agent_max_tool_rounds=10,
        sub_agent_max_tool_rounds=8,
        llm_proto="openai",
        llm_model="gpt-4o-mini",
        llm_api_key_configured=True,
        aicd_home="/home/aicd",
        aicd_session_logs_dir="/home/aicd/logs",
    )
    assert d["paths"]["ai_workspace_cwd"] == "/w"
    assert d["paths"]["aicd_home"] == "/home/aicd"
    assert d["paths"]["aicd_session_logs_dir"] == "/home/aicd/logs"
    assert "git" in d["cli_highlights"]
    assert "playwright" in d["python_modules_highlights"]
    assert d["llm_config_surface"]["api_key_configured"] is True
    assert len(d["introspection_checklist_zh"]) >= 3
    assert "desktop_gui" in d
    assert "session_ok" in d["desktop_gui"]
