"""fs_read_file：非 UTF-8 与 BOM 解码。"""

from __future__ import annotations

from pathlib import Path

from aicd.config import AppConfig
from aicd.tools.fs_tool import FSTool
from aicd.tools.path_policy import PathPolicy


def test_read_file_gbk_detected(tmp_path: Path) -> None:
    cfg = AppConfig()
    pol = PathPolicy(cfg.paths)
    pol.set_workspace_root(tmp_path)
    fs = FSTool(pol, cwd=tmp_path)
    p = tmp_path / "legacy.txt"
    p.write_bytes("中文GBK测试".encode("gbk"))
    r = fs.read_file(str(p), align_utf8=True)
    assert r["ok"] is True
    assert r["text"] == "中文GBK测试"
    assert r.get("source_encoding")
    assert "encoding_note" in r


def test_read_file_utf8_no_extra_encoding_meta(tmp_path: Path) -> None:
    cfg = AppConfig()
    pol = PathPolicy(cfg.paths)
    pol.set_workspace_root(tmp_path)
    fs = FSTool(pol, cwd=tmp_path)
    p = tmp_path / "plain.txt"
    p.write_text("ascii only", encoding="utf-8")
    r = fs.read_file(str(p), align_utf8=True)
    assert r["ok"] is True
    assert r["text"] == "ascii only"
    assert "source_encoding" not in r
    assert "encoding_note" not in r


def test_read_file_utf8_bom_marks_source(tmp_path: Path) -> None:
    cfg = AppConfig()
    pol = PathPolicy(cfg.paths)
    pol.set_workspace_root(tmp_path)
    fs = FSTool(pol, cwd=tmp_path)
    p = tmp_path / "bom.txt"
    p.write_bytes(b"\xef\xbb\xbfx")
    r = fs.read_file(str(p), align_utf8=True)
    assert r["ok"] is True
    assert r["text"] == "x"
    assert r.get("source_encoding") == "utf-8-sig"
    assert r.get("bom") == "utf-8-sig"
