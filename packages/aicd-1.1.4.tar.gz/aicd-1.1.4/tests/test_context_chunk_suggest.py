"""context_adaptive：大号文本切块建议与模型窗的关系。"""

from __future__ import annotations

from aicd.agent.context_adaptive import (
    compute_suggested_text_chunk_limits,
)


def test_suggested_chunk_128k_high_window() -> None:
    r = compute_suggested_text_chunk_limits(
        effective_budget_tokens=128_000,
        model_context_window_tokens=128_000,
        window_confidence="high",
    )
    assert r["suggested_chunk_max_bytes"] <= 128_000 * 3
    assert r["suggested_chunk_max_chars"] < 80_000


def test_suggested_chunk_1m_larger_than_128k() -> None:
    a = compute_suggested_text_chunk_limits(
        effective_budget_tokens=1_000_000,
        model_context_window_tokens=1_000_000,
        window_confidence="high",
    )
    b = compute_suggested_text_chunk_limits(
        effective_budget_tokens=128_000,
        model_context_window_tokens=128_000,
        window_confidence="high",
    )
    assert a["suggested_chunk_max_bytes"] > b["suggested_chunk_max_bytes"]


def test_low_window_more_conservative_than_high() -> None:
    hi = compute_suggested_text_chunk_limits(
        effective_budget_tokens=200_000,
        model_context_window_tokens=200_000,
        window_confidence="high",
    )
    lo = compute_suggested_text_chunk_limits(
        effective_budget_tokens=200_000,
        model_context_window_tokens=None,
        window_confidence="low",
    )
    assert lo["suggested_chunk_max_bytes"] <= hi["suggested_chunk_max_bytes"]
