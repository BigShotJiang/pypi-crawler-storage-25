"""script_run(py)：执行前 AST 预检。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from aicd.config import PathPolicyConfig
from aicd.tools.path_policy import PathPolicy
from aicd.tools.process_tool import ProcessTool
from aicd.tools.script_backup import policy_allow_under_ai_output_or_workspace
from aicd.tools.script_tool import ScriptTool


def test_run_python_syntax_precheck_no_subprocess(tmp_path: Path) -> None:
    async def _go() -> None:
        scripts_dir = tmp_path / "scripts"
        bak = tmp_path / "aicd" / "bak"
        pol = PathPolicy(PathPolicyConfig(full_disk=True))
        pt = ProcessTool(pol, cwd=tmp_path)
        st = ScriptTool(scripts_dir, pt)
        bad = "x = (\n"
        policy_check = policy_allow_under_ai_output_or_workspace(
            tmp_path / "aicd",
            pol.check_allowed,
        )
        out = await st.run_python(
            bad,
            timeout_sec=10,
            related_doc="t",
            backup_dir=bak,
            policy_check=policy_check,
        )
        assert out.get("ok") is False
        assert out.get("returncode") == 1
        assert "syntax_precheck" in out
        assert out["syntax_precheck"].get("ok") is False
        assert out.get("aicd_hint")
        assert out.get("script_bak_path")
        assert Path(out["script_bak_path"]).is_file()
        assert ".py" in out["script_bak_path"]
        temp_left = list(scripts_dir.glob("*.py"))
        assert not temp_left

    asyncio.run(_go())


def test_run_python_ok_reaches_run_command(tmp_path: Path) -> None:
    """语法合法时应走 subprocess；避免在部分 Windows/pytest 环境下真起子进程（易 WinError）。"""
    from unittest.mock import AsyncMock, patch

    async def _go() -> None:
        scripts_dir = tmp_path / "scripts2"
        bak = tmp_path / "o" / "aicd2" / "bak"
        pol = PathPolicy(PathPolicyConfig(full_disk=True))
        pt = ProcessTool(pol, cwd=tmp_path)
        st = ScriptTool(scripts_dir, pt)
        src = "print(42)\n"
        policy_check = policy_allow_under_ai_output_or_workspace(
            tmp_path / "o" / "aicd2",
            pol.check_allowed,
        )
        fake_out = {
            "ok": True,
            "returncode": 0,
            "stdout": "42\n",
            "stderr": "",
        }
        with patch.object(pt, "run_command", new_callable=AsyncMock, return_value=fake_out):
            out = await st.run_python(
                src,
                timeout_sec=30,
                related_doc="ok",
                backup_dir=bak,
                policy_check=policy_check,
            )
        assert out.get("ok") is True
        assert "syntax_precheck" not in out
        assert "42" in (out.get("stdout") or "")

    asyncio.run(_go())
