"""子进程 PIPE 文本解码（Windows GBK/UTF-8 混用回退）。"""

from __future__ import annotations

import sys

import pytest

from aicd.tools.text_encoding import decode_subprocess_bytes, decode_subprocess_pipe_line


def test_decode_subprocess_utf8_strict() -> None:
    assert decode_subprocess_bytes(b"ascii\n") == "ascii\n"
    assert decode_subprocess_bytes("\u4e2d\u6587".encode("utf-8")) == "\u4e2d\u6587"


def test_decode_subprocess_pipe_line_strips_newline() -> None:
    assert decode_subprocess_pipe_line(b"a\r\n") == "a"
    assert decode_subprocess_pipe_line(b"a\n") == "a"


@pytest.mark.skipif(sys.platform != "win32", reason="GBK fallback tuned for Windows consoles")
def test_decode_subprocess_gbk_fallback_on_windows() -> None:
    raw = "\u51e1\u4eba\u4fee\u4ed9".encode("gbk") + b"\r\n"
    assert decode_subprocess_pipe_line(raw) == "\u51e1\u4eba\u4fee\u4ed9"


def test_decode_subprocess_gbk_heuristic_when_many_replacement_chars() -> None:
    """非 Windows 上无回退时仍为 UTF-8 replace；Windows 上应能用 gb18030 解典型双字节中文。"""
    phrase = "\u51e1\u4eba\u4fee\u4ed9"
    raw = phrase.encode("gb18030") + b"\n"
    out = decode_subprocess_bytes(raw)
    if sys.platform == "win32":
        assert phrase in out
    else:
        # 严格 UTF-8 失败 → replace，中文 GBK 字节会产生大量 U+FFFD
        assert "\ufffd" in out or phrase in out
