"""agent_registry：工具布尔参数解析（字符串 false 等）。"""

from __future__ import annotations

from aicd.agent.handlers.agent_registry import _tool_bool_arg


def test_tool_bool_arg_string_false() -> None:
    assert _tool_bool_arg("false", default=True) is False
    assert _tool_bool_arg("FALSE", default=True) is False
    assert _tool_bool_arg("0", default=True) is False


def test_tool_bool_arg_string_true() -> None:
    assert _tool_bool_arg("true", default=False) is True
    assert _tool_bool_arg("1", default=False) is True


def test_tool_bool_arg_none_uses_default() -> None:
    assert _tool_bool_arg(None, default=True) is True
    assert _tool_bool_arg(None, default=False) is False


def test_tool_bool_arg_native() -> None:
    assert _tool_bool_arg(True, default=False) is True
    assert _tool_bool_arg(False, default=True) is False
