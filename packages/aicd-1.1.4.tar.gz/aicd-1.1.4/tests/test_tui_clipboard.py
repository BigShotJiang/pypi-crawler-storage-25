"""Windows 剪贴板 Unicode 写入（/history、/copy 等）。"""

from __future__ import annotations

import sys

import pytest


@pytest.mark.skipif(sys.platform != "win32", reason="uses Win32 clipboard API")
def test_win32_set_clipboard_unicode_cjk() -> None:
    from aicd.ui.tui import _win32_set_clipboard_unicode

    ok = _win32_set_clipboard_unicode("根据内容进行艺术化表达。演讲备注去掉不要。")
    if not ok:
        pytest.skip("OpenClipboard failed (headless or denied)")
    assert ok is True
