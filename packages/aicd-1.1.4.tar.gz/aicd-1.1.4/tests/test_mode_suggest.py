from aicd.agent.mode_suggest import suggest_work_mode_hint


def test_suggest_empty() -> None:
    assert suggest_work_mode_hint("", current_mode="general") == ""


def test_suggest_pentest_keyword() -> None:
    h = suggest_work_mode_hint("请做渗透测试扫描", current_mode="general")
    assert "pentest" in h or "workmode" in h


def test_suggest_no_repeat_when_already_pentest() -> None:
    assert suggest_work_mode_hint("渗透测试授权范围", current_mode="pentest") == ""
