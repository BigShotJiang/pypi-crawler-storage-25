"""markdown_to_docx：依赖系统 Pandoc。"""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from aicd.tools.markdown_to_pdf import export_markdown_to_docx


def _policy(p: Path) -> None:
    return None


@pytest.mark.skipif(not shutil.which("pandoc"), reason="pandoc not on PATH")
def test_export_markdown_to_docx_smoke(tmp_path: Path) -> None:
    md = tmp_path / "src.md"
    md.write_text("# 标题\n\n|列1|列2|\n|---|---|\n|a|b|\n", encoding="utf-8")
    out = tmp_path / "out.docx"
    r = export_markdown_to_docx(
        output_docx_path=out,
        policy_check=_policy,
        markdown_path=md,
    )
    assert r.get("ok") is True
    assert out.is_file() and out.stat().st_size > 2000
