"""chat_serialize：多模态消息 token 粗估。"""

from __future__ import annotations

from aicd.agent.chat_serialize import (
    VISION_IMAGE_TOKENS_PER_IMAGE,
    estimate_message_tokens,
    sanitize_assistant_leaked_tool_markers,
    slim_spill_tool_envelope_json,
)


def test_estimate_message_tokens_plain_string() -> None:
    msg = {"role": "user", "content": "abcd"}
    assert estimate_message_tokens(msg) == 2  # 4 // 4 + 1


def test_estimate_message_tokens_multimodal_one_image() -> None:
    msg = {
        "role": "user",
        "content": [
            {"type": "text", "text": "x"},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64,..."}},
        ],
    }
    # text: 1 char -> 1//4+1 = 1; one image -> + 8000
    assert estimate_message_tokens(msg) == 1 + VISION_IMAGE_TOKENS_PER_IMAGE


def test_slim_spill_tool_envelope_truncates_preview() -> None:
    import json

    raw = json.dumps(
        {
            "_aicd_tool_result_spill": True,
            "preview": "abcdefghij" * 50,
            "p": 1,
        },
        ensure_ascii=False,
    )
    out = slim_spill_tool_envelope_json(raw, target_max_preview_chars=20)
    assert out is not None
    o = json.loads(out)
    assert len(o["preview"]) <= 25


def test_sanitize_assistant_leaked_tool_markers_removes_fragments() -> None:
    assert (
        sanitize_assistant_leaked_tool_markers("前言\n<tool_call|>\n后续")
        == "前言\n\n后续"
    )
    assert sanitize_assistant_leaked_tool_markers('<tool_call name="x" args="{}">') == ""
    assert sanitize_assistant_leaked_tool_markers(None) == ""


def test_estimate_message_tokens_multimodal_two_images() -> None:
    msg = {
        "role": "user",
        "content": [
            {"type": "image_url", "image_url": {"url": "http://a"}},
            {"type": "image_url", "image_url": {"url": "http://b"}},
        ],
    }
    assert estimate_message_tokens(msg) == 2 * VISION_IMAGE_TOKENS_PER_IMAGE
