from __future__ import annotations

from aicd.config import AppConfig


def test_agent_startup_workspace_and_default_work_mode_yaml() -> None:
    raw = {
        "agent": {
            "startupWorkspaceFromCwd": True,
            "defaultWorkMode": "pentest",
        }
    }
    cfg = AppConfig.from_dict(raw)
    assert cfg.agent.startup_workspace_from_cwd is True
    assert cfg.agent.default_work_mode == "pentest"


def test_agent_default_work_mode_invalid_falls_back_general() -> None:
    raw = {"agent": {"defaultWorkMode": "nope"}}
    cfg = AppConfig.from_dict(raw)
    assert cfg.agent.default_work_mode == "general"
