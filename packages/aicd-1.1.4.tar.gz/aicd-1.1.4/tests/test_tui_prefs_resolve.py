from __future__ import annotations

import json
from pathlib import Path

import pytest

from aicd.tui_prefs import (
    resolve_boot_work_mode,
    resolve_tui_assistant_markdown_chat,
    save_work_mode,
)


def test_resolve_assistant_markdown_env_overrides_prefs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    d = tmp_path / "data"
    d.mkdir(parents=True)
    p = d / "tui_prefs.json"
    p.write_text('{"assistant_markdown_chat": true}\n', encoding="utf-8")
    monkeypatch.setenv("AICD_TUI_ASSISTANT_MARKDOWN", "0")
    assert resolve_tui_assistant_markdown_chat(d) is False
    monkeypatch.setenv("AICD_TUI_ASSISTANT_MARKDOWN", "1")
    assert resolve_tui_assistant_markdown_chat(d) is True


def test_resolve_assistant_markdown_reads_prefs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    d = tmp_path / "data"
    d.mkdir(parents=True)
    monkeypatch.delenv("AICD_TUI_ASSISTANT_MARKDOWN", raising=False)
    assert resolve_tui_assistant_markdown_chat(d) is True
    (d / "tui_prefs.json").write_text(
        '{"assistant_markdown_chat": false}\n', encoding="utf-8"
    )
    assert resolve_tui_assistant_markdown_chat(d) is False
    (d / "tui_prefs.json").write_text(
        '{"assistant_markdown_chat": true}\n', encoding="utf-8"
    )
    assert resolve_tui_assistant_markdown_chat(d) is True


def test_resolve_boot_work_mode_explicit_prefs_win() -> None:
    assert resolve_boot_work_mode("general", "dev", True) == "dev"
    assert resolve_boot_work_mode("dev", "script", True) == "script"


def test_resolve_boot_work_mode_explicit_false_uses_config() -> None:
    assert resolve_boot_work_mode("dev", "script", False) == "dev"


def test_resolve_boot_work_mode_legacy_general_yields_to_config() -> None:
    assert resolve_boot_work_mode("dev", "general", None) == "dev"
    assert resolve_boot_work_mode("script", "general", None) == "script"


def test_resolve_boot_work_mode_legacy_non_general_keeps_prefs() -> None:
    assert resolve_boot_work_mode("general", "dev", None) == "dev"


def test_resolve_boot_work_mode_no_prefs_uses_config() -> None:
    assert resolve_boot_work_mode("pentest", None, None) == "pentest"


def test_save_work_mode_sets_user_override_flag(tmp_path: Path) -> None:
    d = tmp_path / "data"
    save_work_mode(d, "ops")
    obj = json.loads((d / "tui_prefs.json").read_text(encoding="utf-8"))
    assert obj["work_mode"] == "ops"
    assert obj.get("work_mode_user_override") is True
