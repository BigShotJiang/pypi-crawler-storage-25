"""docx_compose：表格与东亚字体默认值。"""

from __future__ import annotations

import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml.ns import qn

from aicd.tools.docx_compose import docx_compose


def _policy(p: Path) -> None:
    return None


def test_docx_table_rows_as_json_string(tmp_path: Path) -> None:
    """部分模型把 table.rows 序列化成 JSON 字符串。"""
    p = tmp_path / "out_json_rows.docx"
    r = docx_compose(
        p,
        [
            {
                "type": "table",
                "rows": '[["A","B"],["1","2"]]',
            },
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    assert r["tables_added"] == 1


def test_docx_table_and_simsun_defaults(tmp_path: Path) -> None:
    p = tmp_path / "out.docx"
    r = docx_compose(
        p,
        [
            {"type": "heading", "text": "H", "level": 1},
            {"type": "paragraph", "text": "body"},
            {
                "type": "table",
                "rows": [["A", "B"], ["1", "2"]],
                "header_row": True,
            },
        ],
        policy_check=_policy,
        default_east_asia_font="宋体",
        default_color_hex="000000",
        default_body_font_pt=11.0,
    )
    assert r["ok"] is True
    assert r["tables_added"] == 1
    assert r["defaults_applied"] is True
    doc = Document(str(p))
    assert len(doc.tables) == 1
    assert len(doc.paragraphs) >= 2


def test_docx_table_fixed_width_disables_autofit_and_repeats_header(
    tmp_path: Path,
) -> None:
    """有列宽时自动关闭 autofit；header_row 默认启用分页表头。"""
    p = tmp_path / "tbl.docx"
    r = docx_compose(
        p,
        [
            {
                "type": "table",
                "rows": [["A", "B"], ["1", "2"]],
                "header_row": True,
                "column_width_cm": [4.0, 4.0],
            },
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    doc = Document(str(p))
    tbl = doc.tables[0]
    assert tbl.autofit is False
    tr_pr = tbl.rows[0]._tr.trPr
    assert tr_pr is not None
    assert any(el.tag == qn("w:tblHeader") for el in tr_pr)


def test_docx_table_repeat_header_can_be_disabled(tmp_path: Path) -> None:
    p = tmp_path / "nr.docx"
    r = docx_compose(
        p,
        [
            {
                "type": "table",
                "rows": [["H"], ["b"]],
                "header_row": True,
                "repeat_header_row": False,
            },
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    doc = Document(str(p))
    tr_pr = doc.tables[0].rows[0]._tr.trPr
    if tr_pr is None:
        return
    assert not any(el.tag == qn("w:tblHeader") for el in tr_pr)


def test_docx_table_body_vertical_alignment(tmp_path: Path) -> None:
    p = tmp_path / "va.docx"
    r = docx_compose(
        p,
        [
            {
                "type": "table",
                "rows": [["x"]],
                "body_vertical_alignment": "center",
            },
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    doc = Document(str(p))
    assert (
        doc.tables[0].rows[0].cells[0].vertical_alignment
        == WD_CELL_VERTICAL_ALIGNMENT.CENTER
    )


def test_docx_paragraph_newlines_become_separate_paragraphs(tmp_path: Path) -> None:
    """默认：\\n 拆成真实段落，避免 Word 中满篇 ↓ 软换行。"""
    p = tmp_path / "nl.docx"
    r = docx_compose(
        p,
        [{"type": "paragraph", "text": "line1\nline2"}],
        policy_check=_policy,
    )
    assert r["ok"] is True
    doc = Document(str(p))
    texts = [pp.text for pp in doc.paragraphs if pp.text.strip() != ""]
    assert texts == ["line1", "line2"]


def test_docx_paragraph_soft_line_breaks_retain_shift_enter_style(
    tmp_path: Path,
) -> None:
    """soft_line_breaks: true 时仍为段内 w:br（读回 paragraph.text 含 \\n）。"""
    p = tmp_path / "soft.docx"
    r = docx_compose(
        p,
        [
            {
                "type": "paragraph",
                "text": "line1\nline2",
                "soft_line_breaks": True,
            },
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    doc = Document(str(p))
    assert doc.paragraphs[0].text == "line1\nline2"


def test_docx_table_cell_newlines_are_paragraphs_by_default(tmp_path: Path) -> None:
    p = tmp_path / "tc.docx"
    r = docx_compose(
        p,
        [{"type": "table", "rows": [["a\nb"]]}],
        policy_check=_policy,
    )
    assert r["ok"] is True
    doc = Document(str(p))
    cell = doc.tables[0].rows[0].cells[0]
    tx = [pp.text for pp in cell.paragraphs if pp.text.strip() != ""]
    assert tx == ["a", "b"]


def test_docx_toc_inserts_field_and_settings_update_fields(tmp_path: Path) -> None:
    """插入 TOC 复杂域（instrText 含 1-3）并写入 w:updateFields。"""
    p = tmp_path / "toc.docx"
    r = docx_compose(
        p,
        [
            {"type": "toc", "caption": "目录", "placeholder": "…"},
            {"type": "heading", "text": "第一章", "level": 1},
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    assert r.get("toc_inserted") == 1
    assert r.get("update_fields_on_open") is True
    with zipfile.ZipFile(p) as zf:
        doc_xml = zf.read("word/document.xml").decode("utf-8")
        settings_xml = zf.read("word/settings.xml").decode("utf-8")
    assert "w:fldChar" in doc_xml and "w:instrText" in doc_xml
    assert "TOC" in doc_xml and "1-3" in doc_xml
    assert "updateFields" in settings_xml


def test_docx_compose_from_template_appends_after_template_body(tmp_path: Path) -> None:
    """模板正文保留，blocks 追加在后。"""
    tpl = tmp_path / "corp.docx"
    d0 = Document()
    d0.add_paragraph("TPL_MARKER")
    d0.save(str(tpl))
    out = tmp_path / "out.docx"
    r = docx_compose(
        out,
        [{"type": "heading", "text": "一章", "level": 1}],
        policy_check=_policy,
        template_path=tpl,
    )
    assert r["ok"] is True
    assert r.get("from_template") is True
    assert r.get("template_source") == str(tpl.resolve())
    doc = Document(str(out))
    texts = [p.text for p in doc.paragraphs]
    assert "TPL_MARKER" in texts
    assert "一章" in texts
    assert texts.index("TPL_MARKER") < texts.index("一章")


def test_docx_compose_template_ignored_when_append_to_existing(tmp_path: Path) -> None:
    tpl = tmp_path / "tpl.docx"
    d0 = Document()
    d0.add_paragraph("ONLY_IN_TEMPLATE")
    d0.save(str(tpl))
    out = tmp_path / "exist.docx"
    d1 = Document()
    d1.add_paragraph("EXISTING")
    d1.save(str(out))
    r = docx_compose(
        out,
        [{"type": "paragraph", "text": "appended"}],
        policy_check=_policy,
        append=True,
        template_path=tpl,
    )
    assert r["ok"] is True
    assert r.get("template_ignored_because_append") is True
    assert r.get("from_template") is False
    doc = Document(str(out))
    blob = "\n".join(p.text for p in doc.paragraphs)
    assert "EXISTING" in blob
    assert "appended" in blob
    assert "ONLY_IN_TEMPLATE" not in blob


def test_docx_toc_respects_global_update_fields_false(tmp_path: Path) -> None:
    p = tmp_path / "toc2.docx"
    r = docx_compose(
        p,
        [{"type": "toc"}],
        policy_check=_policy,
        update_fields_on_open=False,
    )
    assert r["ok"] is True
    assert r.get("update_fields_on_open") is False
    with zipfile.ZipFile(p) as zf:
        settings_xml = zf.read("word/settings.xml").decode("utf-8")
    assert "updateFields" not in settings_xml
