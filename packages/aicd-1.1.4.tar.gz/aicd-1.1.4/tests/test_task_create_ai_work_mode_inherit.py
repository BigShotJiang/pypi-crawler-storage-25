"""create_ai_task：嵌套 task_ai 省略 work_mode 时继承父任务。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from aicd.bus.event_bus import AsyncEventBus
from aicd.config import PathPolicyConfig
from aicd.db.store import TaskStore
from aicd.tasks.manager import TaskManager
from aicd.tools.path_policy import PathPolicy
from aicd.tools.process_tool import ProcessTool


async def _noop_ai_runner(_task_id: str, _instruction: str) -> None:
    return


def test_nested_task_ai_inherits_parent_work_mode_column(tmp_path: Path) -> None:
    async def _go() -> None:
        db = tmp_path / "t.db"
        store = TaskStore(db)
        conn = await store.connect()
        try:
            bus = AsyncEventBus()
            pol = PathPolicy(PathPolicyConfig(full_disk=True))
            pt = ProcessTool(pol, cwd=tmp_path)
            tm = TaskManager(
                store=store,
                conn=conn,
                bus=bus,
                tasks_root=tmp_path / "tr",
                process_tool=pt,
            )
            tm.set_ai_runner(_noop_ai_runner)

            parent = await store.insert_task(
                conn,
                task_type="ai_agent",
                status="running",
                parent_id=None,
                payload={"instruction": "parent"},
                work_mode="pentest",
            )
            child = await tm.create_ai_task(
                "child job",
                parent_id=parent,
                default_work_mode="general",
            )
            row = await store.get_task(conn, child)
            assert row is not None
            assert row.work_mode == "pentest"
            await tm.cancel_all_running(reason="test_cleanup")
        finally:
            await conn.close()

    asyncio.run(_go())


def test_nested_task_ai_inherits_parent_payload_work_mode_when_column_empty(
    tmp_path: Path,
) -> None:
    async def _go() -> None:
        db = tmp_path / "t2.db"
        store = TaskStore(db)
        conn = await store.connect()
        try:
            bus = AsyncEventBus()
            pol = PathPolicy(PathPolicyConfig(full_disk=True))
            pt = ProcessTool(pol, cwd=tmp_path)
            tm = TaskManager(
                store=store,
                conn=conn,
                bus=bus,
                tasks_root=tmp_path / "tr2",
                process_tool=pt,
            )
            tm.set_ai_runner(_noop_ai_runner)

            parent = await store.insert_task(
                conn,
                task_type="ai_agent",
                status="running",
                parent_id=None,
                payload={"instruction": "parent", "work_mode": "script"},
                work_mode=None,
            )
            child = await tm.create_ai_task(
                "nested",
                parent_id=parent,
                default_work_mode="general",
            )
            row = await store.get_task(conn, child)
            assert row is not None
            assert row.work_mode == "script"
            await tm.cancel_all_running(reason="test_cleanup")
        finally:
            await conn.close()

    asyncio.run(_go())
