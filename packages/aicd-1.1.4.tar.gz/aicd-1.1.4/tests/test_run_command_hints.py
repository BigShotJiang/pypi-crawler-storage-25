"""run_command 的 aicd_hint 启发式。"""

from __future__ import annotations

import sys

from aicd.tools.run_command_hints import hint_for_run_command_result


def test_hint_syntaxerror_string_inline() -> None:
    h = hint_for_run_command_result(
        command='python -c "print(1"',
        argv=None,
        ok=False,
        returncode=1,
        stderr='  File "<string>", line 1\n    "print(1\n    ^\nSyntaxError: unterminated string literal\n',
    )
    assert h is not None
    assert "script_run" in h.lower()


def test_hint_windows_chain_python_c_on_failure() -> None:
    if sys.platform != "win32":
        return
    h = hint_for_run_command_result(
        command='cd /d . && python -c "print(1)"',
        argv=None,
        ok=False,
        returncode=1,
        stderr="nope",
    )
    assert h is not None
    assert "script_run" in h.lower()


def test_no_hint_windows_chain_when_ok() -> None:
    if sys.platform != "win32":
        return
    h = hint_for_run_command_result(
        command='cd /d . && python -c "print(1)"',
        argv=None,
        ok=True,
        returncode=0,
        stderr="",
    )
    assert h is None


def test_no_hint_clean_run() -> None:
    h = hint_for_run_command_result(
        command="echo hi",
        argv=None,
        ok=True,
        returncode=0,
        stderr="",
    )
    assert h is None


def test_hint_argv_python_c_odd_quotes() -> None:
    if sys.platform != "win32":
        return
    h = hint_for_run_command_result(
        command=None,
        argv=["python", "-c", 'print("x'],
        ok=False,
        returncode=1,
        stderr="SyntaxError: unterminated string literal",
    )
    assert h is not None
