"""llm_profile_resolve：子 Agent profile 链与主对话 work_mode 覆盖解析。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from aicd.agent.llm_profile_resolve import (
    resolve_sub_agent_llm_profile_name,
    resolve_work_mode_llm_profile_name,
)
from aicd.config import AppConfig
from aicd.db.store import TaskStore


def _cfg(active: str | None = "default") -> AppConfig:
    c = AppConfig()
    c.active_llm_profile = active
    return c


def test_resolve_sub_agent_explicit_over_kind_over_active() -> None:
    cfg = _cfg("alpha")
    assert (
        resolve_sub_agent_llm_profile_name(
            cfg,
            explicit_llm_profile_name="ex",
            agent_kind_def_llm_profile_name="kind",
        )
        == "ex"
    )
    assert (
        resolve_sub_agent_llm_profile_name(
            cfg,
            explicit_llm_profile_name=None,
            agent_kind_def_llm_profile_name="kind",
        )
        == "kind"
    )
    assert (
        resolve_sub_agent_llm_profile_name(
            cfg,
            explicit_llm_profile_name="  ",
            agent_kind_def_llm_profile_name=None,
        )
        == "alpha"
    )


def test_resolve_sub_agent_fallback_default_when_no_active() -> None:
    cfg = _cfg(None)
    assert (
        resolve_sub_agent_llm_profile_name(
            cfg,
            explicit_llm_profile_name=None,
            agent_kind_def_llm_profile_name=None,
        )
        == "default"
    )


def test_resolve_work_mode_llm_from_db(tmp_path: Path) -> None:
    async def _go() -> None:
        db = tmp_path / "wm.db"
        store = TaskStore(db)
        conn = await store.connect()
        try:
            await store.upsert_work_mode_def(
                conn,
                key="customwm",
                display_name="Custom",
                llm_profile_name="  myprof  ",
                builtin=0,
            )
            r = await resolve_work_mode_llm_profile_name(store, conn, "customwm")
            assert r == "myprof"
            g = await resolve_work_mode_llm_profile_name(store, conn, "general")
            assert g is None
            await store.delete_work_mode_def(conn, "customwm", hard=False)
            r2 = await resolve_work_mode_llm_profile_name(store, conn, "customwm")
            assert r2 is None
        finally:
            await conn.close()

    asyncio.run(_go())
