"""agent_scripts 库：stem 校验、写入与索引。"""

from __future__ import annotations

from aicd.tools import agent_scripts_lib as asl


def test_validate_stem_reserved() -> None:
    assert asl.validate_stem("index")[1]
    assert asl.validate_stem("readme")[1]
    assert asl.validate_stem("ok")[0] == "ok"


def test_write_and_index(tmp_path) -> None:
    root = tmp_path / "agent_scripts"
    root.mkdir()
    r = asl.write_pair(
        root,
        "demo",
        "py",
        "print(1)\n",
        "# Demo\n\nHello.",
        rebuild_index=True,
    )
    assert r["ok"] is True
    assert (root / "demo.py").read_text(encoding="utf-8") == "print(1)\n"
    assert (root / "demo.md").read_text(encoding="utf-8").startswith("# Demo")
    assert (root / asl.INDEX_NAME).is_file()
    lst = asl.list_entries(root)
    assert lst["count"] == 1
    assert lst["entries"][0]["stem"] == "demo"


def test_argv_for_run_py(tmp_path) -> None:
    import sys

    p = tmp_path / "x.py"
    p.write_text("pass\n", encoding="utf-8")
    argv = asl.argv_for_run(p, ["a", "b"])
    assert argv is not None
    assert argv[0] == sys.executable
    assert argv[1] == str(p)
    assert argv[2:] == ["a", "b"]
