"""markitdown_bridge：允许的后缀与旧版 Office 映射。"""

from __future__ import annotations

from pathlib import Path

from aicd.tools import markitdown_bridge as mb


def test_markitdown_office_suffixes_include_doc_xls_ppt() -> None:
    assert ".xls" in mb._MARKITDOWN_OFFICE
    assert ".doc" in mb._MARKITDOWN_OFFICE
    assert ".ppt" in mb._MARKITDOWN_OFFICE
    assert ".docx" in mb._MARKITDOWN_OFFICE


def test_legacy_lo_mapping() -> None:
    assert mb._LEGACY_LO_TO_OOXML[".doc"] == "docx"
    assert mb._LEGACY_LO_TO_OOXML[".ppt"] == "pptx"


def test_convert_rejects_unknown_suffix(tmp_path: Path) -> None:
    p = tmp_path / "a.bin"
    p.write_bytes(b"x")
    r = mb.convert_with_markitdown(
        p, tmp_path, "a", tmp_path / "images_a"
    )
    assert r.get("ok") is False
    assert "only supports" in str(r.get("error", ""))
