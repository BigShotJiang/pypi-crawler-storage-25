from __future__ import annotations

from aicd.ui.tui_chat_render import (
    _is_table_separator_row,
    normalize_markdown_blocks,
    replace_gfm_tables_with_plain_text_tables,
    render_assistant_message,
)


def test_is_table_separator_row() -> None:
    assert _is_table_separator_row("| :--- | :--- |")
    assert _is_table_separator_row("| --- | --- |")
    assert _is_table_separator_row("|:---|:---|")
    assert not _is_table_separator_row("| **a** | b |")
    assert not _is_table_separator_row("plain")


def test_normalize_inserts_blank_before_table_after_paragraph() -> None:
    raw = "下面是参数：\n| A | B |\n| --- | --- |\n| 1 | 2 |"
    out = normalize_markdown_blocks(raw)
    lines = out.split("\n")
    pipe_i = next(i for i, ln in enumerate(lines) if ln.startswith("| A |"))
    assert pipe_i >= 1 and lines[pipe_i - 1] == ""


def test_render_assistant_message_empty() -> None:
    r = render_assistant_message("")
    assert r is not None


def test_render_assistant_message_plain_by_default() -> None:
    raw = "| K | V |\n# Title\n**bold**"
    r = render_assistant_message(raw)
    assert r is not None


def test_render_assistant_message_markdown_table_when_enabled() -> None:
    raw = "| K | V |\n| --- | --- |\n| a | b |"
    r = render_assistant_message(raw, use_markdown=True)
    assert r is not None


def test_replace_gfm_tables_strips_pipe_syntax() -> None:
    raw = "下面是参数：\n| A | B |\n| --- | --- |\n| 1 | 2 |"
    out = replace_gfm_tables_with_plain_text_tables(raw, width=80)
    assert "| ---" not in out
    assert "| 1 |" not in out
    assert "1" in out and "2" in out


def test_replace_gfm_tables_wrap_fenced_for_markdown_mode() -> None:
    raw = "| K | V |\n| --- | --- |\n| x | y |"
    out = replace_gfm_tables_with_plain_text_tables(raw, width=80, wrap_fenced=True)
    assert "```text" in out
    assert "```" in out
    assert "| ---" not in out


def test_replace_gfm_tables_skips_pipe_lines_inside_code_fence() -> None:
    raw = "```\n| A | B |\n| --- | --- |\n| 1 | 2 |\n```\n| X | Y |\n| --- | --- |\n| a | b |"
    out = replace_gfm_tables_with_plain_text_tables(raw, width=80)
    assert "| A |" in out
    assert "X" in out and "Y" in out
    # 围栏内保留原样（仍含 GFM 分隔行）；仅围栏外表格被转换
    assert out.count("| --- |") == 1
