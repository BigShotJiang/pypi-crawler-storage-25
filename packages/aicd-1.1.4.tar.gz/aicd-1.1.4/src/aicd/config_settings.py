"""运行时合并 agent/llm 配置补丁（斜杠命令与 agent_settings_update 工具）。"""

from __future__ import annotations

import copy
from typing import Any

from aicd.config import (
    MAX_AGENT_TOOL_ROUNDS,
    AppConfig,
    DEFAULT_PROFILE_CONTEXT_TOKENS,
    LLMConfig,
    LLMProfile,
    PROTO_DASHSCOPE,
    PROTO_OLLAMA,
    PROTO_OPENAI,
    VALID_PROTOS,
    apply_active_profile_to_llm,
    normalize_model_context_tokens_map,
    parse_supports_vision_bool,
)


def _clamp_int(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, v))


def _clamp_agent_heartbeat(sec: int) -> int:
    """0=关闭；正数夹紧到 [5, 3600]（秒）。"""
    if sec <= 0:
        return 0
    return max(5, min(3600, int(sec)))


def _clamp_lifecycle_coalesce_sec(sec: float) -> float:
    return max(0.0, min(3.0, float(sec)))


def _parse_float(raw: str) -> float | None:
    try:
        return float(raw.strip())
    except (TypeError, ValueError):
        return None


def _parse_int(raw: str) -> int | None:
    try:
        return int(raw.strip(), 10)
    except (TypeError, ValueError):
        return None


def _coerce_llm_proto(value_str: str) -> str:
    p = (value_str or "").strip().lower()
    if p in VALID_PROTOS:
        return p
    if p in ("openai", "openai_compat", "openai-compatible"):
        return PROTO_OPENAI
    if p in ("ollama",):
        return PROTO_OLLAMA
    if p in ("dashscope", "dash", "qwen", "compatible-mode"):
        return PROTO_DASHSCOPE
    return PROTO_OPENAI


_SLASH_LLM_CONNECTION_KEYS = frozenset(
    {
        "model",
        "modelid",
        "url",
        "base_url",
        "baseurl",
        "key",
        "api_key",
        "apikey",
        "proto",
        "type",
        "protocol",
        "provider",
        "vision",
        "vision_model",
        "visionmodel",
        "timeout",
        "timeout_sec",
        "timeoutsec",
    }
)


def set_llm_scalar_from_slash(cfg: LLMConfig, key: str, value_str: str) -> tuple[bool, str]:
    """``/llm <key> <value>`` 解析；``key`` 已小写。"""
    k = key.strip().lower().replace("-", "_")
    aliases = {
        "temp": "temperature",
        "topp": "top_p",
        "top_p": "top_p",
        "freq": "frequency_penalty",
        "frequencypenalty": "frequency_penalty",
        "frequency_penalty": "frequency_penalty",
        "pres": "presence_penalty",
        "presencepenalty": "presence_penalty",
        "presence_penalty": "presence_penalty",
        "maxtokens": "max_output_tokens",
        "max_output_tokens": "max_output_tokens",
        "maxoutputtokens": "max_output_tokens",
        "repetition": "repetition_penalty",
        "repetitionpenalty": "repetition_penalty",
        "repeat_penalty": "repetition_penalty",
        "repetition_penalty": "repetition_penalty",
        "timeout": "timeout_sec",
        "timeoutsec": "timeout_sec",
        "model": "model",
        "modelid": "model",
        "maxretries": "max_retries",
        "retrydelay": "retry_base_delay_sec",
        "retrybasedelaysec": "retry_base_delay_sec",
        "url": "base_url",
        "baseurl": "base_url",
        "key": "api_key",
        "apikey": "api_key",
        "type": "proto",
        "protocol": "proto",
        "provider": "proto",
    }
    field = aliases.get(k, k)
    if field == "base_url":
        cfg.base_url = value_str.strip()
        return True, f"llm.base_url={cfg.base_url!r}"
    if field == "api_key":
        cfg.api_key = value_str.strip()
        return True, "llm.api_key=(已更新)"
    if field == "proto":
        cfg.proto = _coerce_llm_proto(value_str)
        return True, f"llm.proto={cfg.proto!r}"
    if field in ("vision_model", "vision"):
        v = value_str.strip()
        cfg.vision_model = v if v else None
        return True, f"llm.vision_model={cfg.vision_model!r}"
    if field == "model":
        cfg.model = value_str.strip()
        return True, f"llm.model={cfg.model!r}"
    if field in ("max_retries", "maxretries", "retries"):
        n = _parse_int(value_str)
        if n is None or n < 0:
            return False, "max_retries must be a non-negative integer (0–20)"
        cfg.max_retries = _clamp_int(n, 0, 20)
        return True, f"llm.max_retries={cfg.max_retries}"
    if field in ("retry_base_delay_sec", "retrybasedelay", "retry_delay"):
        f = _parse_float(value_str)
        if f is None or f <= 0:
            return False, "retry_base_delay_sec must be > 0"
        cfg.retry_base_delay_sec = float(f)
        return True, f"llm.retry_base_delay_sec={cfg.retry_base_delay_sec}"
    if field == "timeout_sec":
        f = _parse_float(value_str)
        if f is None or f <= 0:
            return False, "timeout_sec must be a positive number"
        cfg.timeout_sec = float(f)
        return True, f"llm.timeout_sec={cfg.timeout_sec}"
    if field == "temperature":
        f = _parse_float(value_str)
        if f is None or not 0 <= f <= 2:
            return False, "temperature must be a number in [0, 2]"
        cfg.temperature = float(f)
        return True, f"llm.temperature={cfg.temperature}"
    if field == "top_p":
        f = _parse_float(value_str)
        if f is None or not 0 < f <= 1:
            return False, "top_p must be in (0, 1]"
        cfg.top_p = float(f)
        return True, f"llm.top_p={cfg.top_p}"
    if field == "frequency_penalty":
        f = _parse_float(value_str)
        if f is None or not -2 <= f <= 2:
            return False, "frequency_penalty must be in [-2, 2]"
        cfg.frequency_penalty = float(f)
        return True, f"llm.frequency_penalty={cfg.frequency_penalty}"
    if field == "presence_penalty":
        f = _parse_float(value_str)
        if f is None or not -2 <= f <= 2:
            return False, "presence_penalty must be in [-2, 2]"
        cfg.presence_penalty = float(f)
        return True, f"llm.presence_penalty={cfg.presence_penalty}"
    if field == "max_output_tokens":
        n = _parse_int(value_str)
        if n is None or n < 1:
            return False, "max_output_tokens must be a positive integer"
        cfg.max_output_tokens = int(n)
        return True, f"llm.max_output_tokens={cfg.max_output_tokens}"
    if field == "repetition_penalty":
        f = _parse_float(value_str)
        if f is None or f <= 0:
            return False, "repetition_penalty must be a positive number"
        cfg.repetition_penalty = float(f)
        return True, f"llm.repetition_penalty={cfg.repetition_penalty}"
    return False, f"unknown llm key: {key!r} (try temperature, topP, maxOutputTokens, …)"


def apply_llm_slash_key_value(
    cfg: AppConfig, key: str, value_str: str
) -> tuple[bool, str, bool]:
    """返回 ``(ok, message, need_hot_reload)``；连接字段变更需重建 LLM 客户端。"""
    k0 = key.strip().lower().replace("-", "_")
    hot = k0 in _SLASH_LLM_CONNECTION_KEYS
    ok, msg = set_llm_scalar_from_slash(cfg.llm, k0, value_str)
    return ok, msg, bool(ok and hot)


def format_llm_profiles_lines(cfg: AppConfig) -> str:
    """编号列表；当前激活行前加 ``*``。切换：``/llm use <n|名称>`` 或 ``/llm <n>``。"""
    act = (cfg.active_llm_profile or "").strip() or "default"
    lines: list[str] = ["[llmProfiles] active=" + repr(act)]
    for i, p in enumerate(cfg.llm_profiles, start=1):
        star = "*" if p.name == act else " "
        ctx = p.context_window_tokens
        ctx_s = str(ctx) if ctx is not None else "(auto / probe)"
        vis = "vision" if getattr(p, "supports_vision", True) else "text-only"
        lines.append(
            f"  {star}{i}. name={p.name!r} type={p.proto} model={p.model!r} "
            f"{vis} context={ctx_s} url={p.base_url!r}"
        )
    if not cfg.llm_profiles:
        lines.append("  (无条目；将回落到默认合成 profile)")
    else:
        lines.append(
            "  — 切换：/llm use <序号|配置名>  或只打  /llm <序号> ；列出：/llm list"
        )
    return "\n".join(lines)


def switch_llm_profile_by_token(cfg: AppConfig, token: str) -> tuple[bool, str]:
    """``token`` 为 **1-based** 序号或 **name**（先精确匹配再大小写不敏感）。"""
    t = (token or "").strip()
    if not t:
        return False, "空参数：请提供序号或配置名"
    if not cfg.llm_profiles:
        return False, "当前没有 llmProfiles 条目"
    if t.isdigit():
        idx = int(t, 10)
        if idx < 1 or idx > len(cfg.llm_profiles):
            return False, f"序号应在 1–{len(cfg.llm_profiles)} 之间"
        prof = cfg.llm_profiles[idx - 1]
        cfg.active_llm_profile = prof.name
        apply_active_profile_to_llm(cfg)
        return True, f"已切换为 #{idx} → activeLlmProfile={prof.name!r}"
    for p in cfg.llm_profiles:
        if p.name == t:
            cfg.active_llm_profile = p.name
            apply_active_profile_to_llm(cfg)
            return True, f"已切换为 activeLlmProfile={p.name!r}"
    tl = t.lower()
    for p in cfg.llm_profiles:
        if p.name.lower() == tl:
            cfg.active_llm_profile = p.name
            apply_active_profile_to_llm(cfg)
            return True, f"已切换为 activeLlmProfile={p.name!r}"
    return False, f"未找到配置: {t!r}（可用 /llm list 查看序号）"


def set_agent_scalar_from_slash(cfg: AppConfig, key: str, value_str: str) -> tuple[bool, str]:
    k = key.strip().lower().replace("-", "_")
    if k in (
        "lifecycle_coalesce",
        "lifecyclecoalesce",
        "lifecycle_coalesce_sec",
        "lifecyclecoalescesec",
    ):
        f = _parse_float(value_str)
        if f is None or f < 0:
            return False, "lifecycle coalesce must be a non-negative number (seconds, max 3)"
        cfg.agent.lifecycle_coalesce_sec = _clamp_lifecycle_coalesce_sec(f)
        return True, f"agent.lifecycle_coalesce_sec={cfg.agent.lifecycle_coalesce_sec} (0–3，TUI/GUI lifecycle 合并)"
    n = _parse_int(value_str)
    if n is None:
        return False, "value must be an integer"
    if k in ("rounds", "max_tool_rounds", "maxtoolrounds"):
        cfg.agent.max_tool_rounds = _clamp_int(n, 1, MAX_AGENT_TOOL_ROUNDS)
        return True, f"agent.max_tool_rounds={cfg.agent.max_tool_rounds}"
    if k in ("subrounds", "sub_rounds", "subagent", "sub_agent_max_tool_rounds", "subagentmaxtoolrounds"):
        cfg.agent.sub_agent_max_tool_rounds = _clamp_int(n, 1, MAX_AGENT_TOOL_ROUNDS)
        return True, f"agent.sub_agent_max_tool_rounds={cfg.agent.sub_agent_max_tool_rounds}"
    if k in ("heartbeat", "idle_heartbeat", "idleheartbeat", "idle_heartbeat_sec"):
        cfg.agent.idle_heartbeat_sec = _clamp_agent_heartbeat(n)
        return True, f"agent.idle_heartbeat_sec={cfg.agent.idle_heartbeat_sec} (0=关闭, 否则 5–3600 秒)"
    if k in (
        "subheartbeat",
        "sub_heartbeat",
        "sub_agent_idle_heartbeat",
        "subagentidleheartbeat",
        "sub_agent_idle_heartbeat_sec",
    ):
        cfg.agent.sub_agent_idle_heartbeat_sec = _clamp_agent_heartbeat(n)
        return (
            True,
            f"agent.sub_agent_idle_heartbeat_sec={cfg.agent.sub_agent_idle_heartbeat_sec} "
            "(0=关闭；子任务仍有 running/pending 时启用协调心跳)",
        )
    return False, f"unknown agent key: {key!r} (rounds | subRounds | heartbeat | subHeartbeat | lifecycleCoalesce)"


def apply_nested_settings_patch(cfg: AppConfig, patch: dict[str, Any]) -> tuple[bool, str]:
    """
    ``patch`` 形如 ``{"llm": {...}, "agent": {...}, "integrations": {...}}``。
    仅更新出现的字段；校验失败则不改配置并返回错误说明。
    """
    if not isinstance(patch, dict):
        return False, "patch must be an object"
    errs: list[str] = []
    backup = copy.deepcopy(cfg)

    try:
        profile_refresh = False
        al_p = patch.get("activeLlmProfile") or patch.get("active_llm_profile")
        if al_p is not None:
            cfg.active_llm_profile = str(al_p).strip() or "default"
            profile_refresh = True
        prof_list = patch.get("llmProfiles") or patch.get("llm_profiles")
        if prof_list is not None:
            if not isinstance(prof_list, list):
                raise ValueError("llmProfiles must be a list of profile objects")
            cfg.llm_profiles = [
                LLMProfile.from_mapping(x) for x in prof_list if isinstance(x, dict)
            ]
            profile_refresh = True

        llm_p = patch.get("llm")
        if isinstance(llm_p, dict):
            for rk, rv in llm_p.items():
                key = str(rk).replace("-", "_")
                camel_map = {
                    "baseUrl": "base_url",
                    "apiKey": "api_key",
                    "modelId": "model",
                    "timeoutSec": "timeout_sec",
                    "topP": "top_p",
                    "frequencyPenalty": "frequency_penalty",
                    "presencePenalty": "presence_penalty",
                    "maxOutputTokens": "max_output_tokens",
                    "repetitionPenalty": "repetition_penalty",
                    "extraBody": "extra_body",
                    "visionModel": "vision_model",
                    "supportsVision": "supports_vision",
                    "maxRetries": "max_retries",
                    "retryBaseDelaySec": "retry_base_delay_sec",
                    "modelContextTokens": "model_context_tokens",
                }
                key = camel_map.get(key, key)
                if key == "model":
                    cfg.llm.model = str(rv).strip()
                elif key == "vision_model":
                    cfg.llm.vision_model = (
                        str(rv).strip() if str(rv).strip() else None
                    )
                elif key == "supports_vision":
                    cfg.llm.supports_vision = parse_supports_vision_bool(
                        rv, default=True
                    )
                elif key == "proto":
                    cfg.llm.proto = _coerce_llm_proto(str(rv))
                elif key == "base_url":
                    cfg.llm.base_url = str(rv).strip()
                elif key == "api_key":
                    cfg.llm.api_key = str(rv).strip()
                elif key == "timeout_sec":
                    cfg.llm.timeout_sec = float(rv)
                    if cfg.llm.timeout_sec <= 0:
                        raise ValueError("timeout_sec must be > 0")
                elif key == "max_retries":
                    cfg.llm.max_retries = _clamp_int(int(rv), 0, 20)
                elif key == "retry_base_delay_sec":
                    cfg.llm.retry_base_delay_sec = max(0.1, float(rv))
                elif key == "temperature":
                    cfg.llm.temperature = float(rv)
                    if not 0 <= cfg.llm.temperature <= 2:
                        raise ValueError("temperature in [0,2]")
                elif key == "top_p":
                    cfg.llm.top_p = float(rv)
                    if not 0 < cfg.llm.top_p <= 1:
                        raise ValueError("top_p in (0,1]")
                elif key == "frequency_penalty":
                    cfg.llm.frequency_penalty = float(rv)
                    if not -2 <= cfg.llm.frequency_penalty <= 2:
                        raise ValueError("frequency_penalty in [-2,2]")
                elif key == "presence_penalty":
                    cfg.llm.presence_penalty = float(rv)
                    if not -2 <= cfg.llm.presence_penalty <= 2:
                        raise ValueError("presence_penalty in [-2,2]")
                elif key == "max_output_tokens":
                    cfg.llm.max_output_tokens = int(rv)
                    if cfg.llm.max_output_tokens < 1:
                        raise ValueError("max_output_tokens >= 1")
                elif key == "repetition_penalty":
                    cfg.llm.repetition_penalty = float(rv)
                    if cfg.llm.repetition_penalty <= 0:
                        raise ValueError("repetition_penalty > 0")
                elif key == "extra_body":
                    if rv is not None and not isinstance(rv, dict):
                        raise ValueError("extra_body must be an object")
                    cfg.llm.extra_body = dict(rv) if rv else {}
                elif key == "model_context_tokens":
                    if rv is None:
                        cfg.llm.model_context_tokens = {}
                    elif not isinstance(rv, dict):
                        raise ValueError("model_context_tokens must be an object")
                    else:
                        cfg.llm.model_context_tokens = normalize_model_context_tokens_map(
                            rv
                        )
                elif key == "clear_sampling":
                    if rv:
                        cfg.llm.temperature = None
                        cfg.llm.top_p = None
                        cfg.llm.frequency_penalty = None
                        cfg.llm.presence_penalty = None
                        cfg.llm.max_output_tokens = None
                        cfg.llm.repetition_penalty = None
                else:
                    errs.append(f"unknown llm field: {rk!r}")

        ag_p = patch.get("agent")
        if isinstance(ag_p, dict):
            for rk, rv in ag_p.items():
                k = str(rk)
                if k in ("maxToolRounds", "max_tool_rounds"):
                    cfg.agent.max_tool_rounds = _clamp_int(
                        int(rv), 1, MAX_AGENT_TOOL_ROUNDS
                    )
                elif k in ("subAgentMaxToolRounds", "sub_agent_max_tool_rounds"):
                    cfg.agent.sub_agent_max_tool_rounds = _clamp_int(
                        int(rv), 1, MAX_AGENT_TOOL_ROUNDS
                    )
                elif k in ("contextBudgetTokens", "context_budget_tokens"):
                    cfg.agent.context_budget_tokens = max(4096, min(2_000_000, int(rv)))
                elif k in ("chatHistoryMaxMessages", "chat_history_max_messages"):
                    cfg.agent.chat_history_max_messages = max(
                        10, min(20_000, int(rv))
                    )
                elif k in (
                    "chatHistoryRecentFullRows",
                    "chat_history_recent_full_rows",
                ):
                    cfg.agent.chat_history_recent_full_rows = max(
                        4, min(2000, int(rv))
                    )
                elif k in ("idleHeartbeatSec", "idle_heartbeat_sec"):
                    cfg.agent.idle_heartbeat_sec = _clamp_agent_heartbeat(int(rv))
                elif k in (
                    "subAgentIdleHeartbeatSec",
                    "sub_agent_idle_heartbeat_sec",
                ):
                    cfg.agent.sub_agent_idle_heartbeat_sec = _clamp_agent_heartbeat(
                        int(rv)
                    )
                elif k in (
                    "lifecycleCoalesceSec",
                    "lifecycle_coalesce_sec",
                ):
                    cfg.agent.lifecycle_coalesce_sec = _clamp_lifecycle_coalesce_sec(
                        float(rv)
                    )
                elif k in ("blockExternalNetwork", "block_external_network"):
                    cfg.agent.block_external_network = bool(rv)
                elif k in (
                    "interactiveProcessIdleSec",
                    "interactive_process_idle_sec",
                ):
                    cfg.agent.interactive_process_idle_sec = max(
                        0.0, min(86_400.0, float(rv))
                    )
                elif k in (
                    "visionImageTokenBudgetPerImage",
                    "vision_image_token_budget_per_image",
                ):
                    if rv in (None, "", False):
                        cfg.agent.vision_image_token_budget_per_image = None
                    else:
                        cfg.agent.vision_image_token_budget_per_image = max(
                            2000, min(32_000, int(rv))
                        )
                else:
                    errs.append(f"unknown agent field: {rk!r}")

        int_p = patch.get("integrations")
        if isinstance(int_p, dict):
            wf = int_p.get("webFetch") or int_p.get("web_fetch")
            if isinstance(wf, dict):
                for rk, rv in wf.items():
                    kk = str(rk)
                    if kk in ("userAgent", "user_agent"):
                        cfg.integrations.web_fetch.user_agent = str(rv or "").strip()
                    elif kk in ("maxResponseBytes", "max_response_bytes"):
                        cfg.integrations.web_fetch.max_response_bytes = max(
                            4096,
                            min(8_000_000, int(rv)),
                        )
                    elif kk in ("defaultTimeoutSec", "default_timeout_sec"):
                        cfg.integrations.web_fetch.default_timeout_sec = max(
                            5.0, min(600.0, float(rv))
                        )
                    else:
                        errs.append(f"unknown integrations.webFetch field: {rk!r}")
            gh = int_p.get("github")
            if isinstance(gh, dict):
                for rk, rv in gh.items():
                    kk = str(rk)
                    if kk in ("apiBaseUrl", "api_base_url"):
                        cfg.integrations.github.api_base_url = str(rv or "").strip().rstrip(
                            "/"
                        )
                    elif kk in ("token", "apiToken", "api_token"):
                        cfg.integrations.github.token = str(rv or "").strip()
                    elif kk == "accept":
                        cfg.integrations.github.accept = str(rv or "").strip()
                    else:
                        errs.append(f"unknown integrations.github field: {rk!r}")

        if profile_refresh:
            apply_active_profile_to_llm(cfg)
    except (TypeError, ValueError) as e:
        # restore
        cfg.llm = backup.llm
        cfg.agent = backup.agent
        cfg.integrations = backup.integrations
        return False, str(e)

    if errs:
        cfg.llm = backup.llm
        cfg.agent = backup.agent
        cfg.integrations = backup.integrations
        return False, "; ".join(errs)
    return True, "ok"


def patch_requests_llm_runtime_reload(patch: dict[str, Any]) -> bool:
    """判断 ``agent_settings_update`` 的补丁是否需重建 LLM 客户端。"""
    if not isinstance(patch, dict):
        return False
    if any(
        k in patch
        for k in (
            "llmProfiles",
            "llm_profiles",
            "activeLlmProfile",
            "active_llm_profile",
        )
    ):
        return True
    lp = patch.get("llm")
    if not isinstance(lp, dict):
        return False
    watch = {
        "baseUrl",
        "base_url",
        "apiKey",
        "api_key",
        "proto",
        "modelId",
        "model",
        "visionModel",
        "vision_model",
        "timeoutSec",
        "timeout_sec",
        "modelContextTokens",
        "model_context_tokens",
    }
    return any(str(k) in watch for k in lp.keys())


def format_settings_summary(cfg: AppConfig) -> str:
    llm = cfg.llm
    lines = [
        "[agent]",
        f"  startup_workspace_from_cwd={cfg.agent.startup_workspace_from_cwd} (交互 TUI 且无 --work/--work-here 时以进程 cwd 为工作区)",
        f"  default_work_mode={cfg.agent.default_work_mode!r} (tui_prefs 未写 work_mode 时的默认场景)",
        f"  max_tool_rounds={cfg.agent.max_tool_rounds}",
        f"  sub_agent_max_tool_rounds={cfg.agent.sub_agent_max_tool_rounds}",
        f"  idle_heartbeat_sec={cfg.agent.idle_heartbeat_sec} (主对话空闲定时检查；0=关)",
        f"  sub_agent_idle_heartbeat_sec={cfg.agent.sub_agent_idle_heartbeat_sec} (子 Agent 协调；0=关)",
        f"  lifecycle_coalesce_sec={cfg.agent.lifecycle_coalesce_sec} (lifecycle 合并延迟秒，0–3)",
        f"  block_external_network={cfg.agent.block_external_network} (工具禁外网，仅回环；LLM 不受影响)",
        f"  interactive_process_idle_sec={cfg.agent.interactive_process_idle_sec} (交互子进程空闲自动结束秒数，0=关，最大86400)",
        f"  context_budget_tokens={cfg.agent.context_budget_tokens}",
        f"  chat_history_max_messages={cfg.agent.chat_history_max_messages}",
        f"  chat_history_recent_full_rows={cfg.agent.chat_history_recent_full_rows}",
        "[llm sampling]",
        f"  temperature={llm.temperature}",
        f"  top_p={llm.top_p}",
        f"  frequency_penalty={llm.frequency_penalty}",
        f"  presence_penalty={llm.presence_penalty}",
        f"  max_output_tokens={llm.max_output_tokens}",
        f"  repetition_penalty={llm.repetition_penalty}",
        f"  extra_body keys={list(llm.extra_body.keys()) if llm.extra_body else []}",
        "[llm core]",
        f"  model={llm.model!r} vision_model={llm.vision_model!r} timeout_sec={llm.timeout_sec}",
        f"  max_retries={llm.max_retries} retry_base_delay_sec={llm.retry_base_delay_sec}",
        "[integrations]",
        f"  web_fetch.max_response_bytes={cfg.integrations.web_fetch.max_response_bytes}",
        f"  web_fetch.default_timeout_sec={cfg.integrations.web_fetch.default_timeout_sec}",
        f"  github.api_base_url={cfg.integrations.github.api_base_url!r}",
        f"  github.token_configured={bool((cfg.integrations.github.token or '').strip())}",
        "",
        format_llm_profiles_lines(cfg),
    ]
    return "\n".join(lines)
