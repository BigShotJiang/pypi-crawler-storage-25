﻿"""可选 MarkItDown 引擎：PDF 与 Office（含旧版 .doc/.xls/.ppt）→ Markdown（可选 OpenAI 兼容 llm_client）。"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from aicd.cli_encoding import subprocess_env_utf8

# OOXML + PDF + 旧版 Office（.doc/.ppt 先经 LibreOffice 无界面转为 docx/pptx 再交给 MarkItDown）。
_MARKITDOWN_OFFICE = frozenset(
    {".pdf", ".docx", ".pptx", ".xlsx", ".xls", ".doc", ".ppt"}
)

_LO_CONVERT_TIMEOUT_SEC = 180

_LEGACY_LO_TO_OOXML = {".doc": "docx", ".ppt": "pptx"}


def markitdown_available() -> bool:
    try:
        import markitdown  # noqa: F401
    except ImportError:
        return False
    return True


def _soffice_convert_to(
    src: Path,
    out_dir: Path,
    *,
    convert_to: str,
) -> tuple[Path | None, str | None]:
    """LibreOffice ``--convert-to``；输出目录内应仅新增一个目标文件。返回 (path, err_msg)。"""
    from aicd.tools.docx_to_pdf import find_soffice_executable

    exe = find_soffice_executable()
    if exe is None:
        return (
            None,
            "LibreOffice (soffice) not found; required to convert legacy .doc/.ppt "
            "before MarkItDown (install LibreOffice or set AICD_SOFFICE)",
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(exe),
        "--headless",
        "--norestore",
        "--nofirststartwizard",
        "--convert-to",
        convert_to,
        "--outdir",
        str(out_dir),
        str(src.resolve()),
    ]
    try:
        cp = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=_LO_CONVERT_TIMEOUT_SEC,
            env=subprocess_env_utf8(),
            encoding="utf-8",
            errors="replace",
        )
    except subprocess.TimeoutExpired:
        return None, f"LibreOffice timed out after {_LO_CONVERT_TIMEOUT_SEC}s"
    except OSError as e:
        return None, f"LibreOffice spawn failed: {e}"

    want = f".{convert_to.lower().lstrip('.')}"
    produced: list[Path] = []
    for p in out_dir.iterdir():
        if p.is_file() and p.suffix.lower() == want:
            produced.append(p)
    if not produced:
        tail = (cp.stderr or cp.stdout or "").strip()[:1500]
        return (
            None,
            f"LibreOffice did not produce *{want} (exit {cp.returncode}); {tail}",
        )
    # 多文件时按与源 stem 匹配（不区分大小写）
    stem_l = src.stem.lower()
    for p in produced:
        if p.stem.lower() == stem_l:
            return p, None
    return produced[0], None


def convert_with_markitdown(
    src: Path,
    out: Path,
    stem: str,
    images_dir: Path,
    *,
    llm_client: Any | None = None,
    llm_model: str | None = None,
) -> dict[str, Any]:
    suf = src.suffix.lower()
    if suf not in _MARKITDOWN_OFFICE:
        return {
            "ok": False,
            "error": f"markitdown path only supports {sorted(_MARKITDOWN_OFFICE)} here",
        }
    try:
        from markitdown import MarkItDown
    except ImportError:
        return {
            "ok": False,
            "error": "markitdown package not installed",
            "hint": "pip install 'aicd[markitdown]' or pip install 'markitdown[pdf,docx,pptx,xlsx,xls]'",
        }

    notes: list[str] = []
    work_src = src
    tmp_root: Path | None = None
    try:
        lo_fmt = _LEGACY_LO_TO_OOXML.get(suf)
        if lo_fmt is not None:
            tmp_root = Path(
                tempfile.mkdtemp(prefix="aicd_markitdown_lo_")
            ).resolve()
            converted, err = _soffice_convert_to(
                src, tmp_root, convert_to=lo_fmt
            )
            if err or converted is None:
                return {
                    "ok": False,
                    "error": err or "LibreOffice conversion failed",
                }
            work_src = converted
            notes.append(
                f"Legacy **{suf}** pre-converted to **.{lo_fmt}** via LibreOffice headless, "
                "then passed to MarkItDown."
            )

        init_kw: dict[str, Any] = {}
        if llm_client is not None and llm_model:
            init_kw["llm_client"] = llm_client
            init_kw["llm_model"] = llm_model
        md = MarkItDown(**init_kw)
        result = md.convert(str(work_src))
        text = getattr(result, "text_content", None)
        if text is None:
            text = str(result)
        text_s = text or ""
        out_path = out / f"{stem}.md"
        out_path.write_text(text_s, encoding="utf-8")
        notes.append("Extracted via optional **markitdown** engine.")
        if llm_client is not None:
            notes.append(
                "MarkItDown LLM caption path enabled (provider billing applies)."
            )
        return {
            "ok": True,
            "output_path": str(out_path.resolve()),
            "output_format": "markdown",
            "output_text_chars": len(text_s),
            "images_dir": str(images_dir.resolve()),
            "images_relative_prefix": images_dir.name,
            "notes": notes,
        }
    finally:
        if tmp_root is not None and tmp_root.is_dir():
            shutil.rmtree(tmp_root, ignore_errors=True)
