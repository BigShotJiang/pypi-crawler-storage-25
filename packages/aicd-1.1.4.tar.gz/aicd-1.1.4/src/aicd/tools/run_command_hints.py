"""run_command 结果附加可读 **aicd_hint**（引号/python -c/Windows CMD 常见失败）。"""

from __future__ import annotations

import sys


def _joined_command(command: str | None, argv: list[str] | None) -> str:
    if command is not None and str(command).strip():
        return str(command)
    if argv:
        return " ".join(str(x) for x in argv)
    return ""


def hint_for_run_command_result(
    *,
    command: str | None,
    argv: list[str] | None,
    ok: bool | None,
    returncode: int | None,
    stderr: str | None,
) -> str | None:
    """
    在 **失败** 或 **可疑命令形态** 时返回简短英文提示，写入工具结果 **aicd_hint**。
    """
    se_raw = stderr or ""
    se = se_raw.lower()
    ct = _joined_command(command, argv)
    hints: list[str] = []

    if not ok or (returncode not in (None, 0)):
        if "unterminated string literal" in se or (
            "syntaxerror" in se and "<string>" in se_raw.lower()
        ):
            hints.append(
                "Inline Python (-c) hit SyntaxError: prefer script_run(kind=py) with full source, "
                "or argv [python, workspace/path/script.py]."
            )

    if sys.platform == "win32" and ct:
        lc = ct.lower()
        py_c = "-c" in ct and (
            "python" in lc
            or "pythonw" in lc
            or lc.startswith("py ")
            or " py " in lc
            or "py.exe" in lc
        )
        if py_c:
            odd_q = ct.count('"') % 2 == 1
            chained = "&&" in ct
            failed = not ok or (returncode not in (None, 0))
            if odd_q or (chained and failed):
                hints.append(
                    "Windows CMD: python -c combined with && or fragile quoting often breaks; "
                    "use script_run(kind=py) or a .py file + argv."
                )

    if not hints:
        return None
    return " ".join(dict.fromkeys(hints))
