"""文本文件字节 → Unicode：BOM 处理、UTF-8 边界与 charset 探测（供 fs_read 等使用）。"""

from __future__ import annotations

import codecs
import locale
import sys
from pathlib import Path
from typing import Any

# 范围读时首尾最多修剪的字节数（不完整 UTF-8 序列）
_UTF8_BOUNDARY_TRIM_MAX = 4

# 编码探测用的文件头最大字节数
ENCODING_DETECTION_HEAD_MAX = 2_097_152


def decode_utf8_range(chunk: bytes, *, file_offset: int) -> tuple[str, int, int]:
    """
    将 ``chunk`` 解码为 UTF-8；必要时跳过首部 0–3 字节（``file_offset > 0`` 时）并去掉尾部不完整序列。
    返回 ``(text, trim_prefix, trim_suffix)``（相对 **chunk** 的字节数）。
    """
    if not chunk:
        return "", 0, 0
    max_skip = min(_UTF8_BOUNDARY_TRIM_MAX, len(chunk)) if file_offset > 0 else 0
    for skip in range(max_skip + 1):
        tail = chunk[skip:]
        end_keep = len(tail)
        while end_keep > 0:
            try:
                text = tail[:end_keep].decode("utf-8")
                return text, skip, len(tail) - end_keep
            except UnicodeDecodeError:
                end_keep -= 1
    text = chunk.decode("utf-8", errors="replace")
    return text, 0, 0


def strip_unicode_bom(data: bytes) -> tuple[bytes, str | None]:
    """去掉常见 Unicode BOM；返回 ``(payload, bom_label)``。"""
    if data.startswith(codecs.BOM_UTF8):
        return data[3:], "utf-8-sig"
    if data.startswith(codecs.BOM_UTF32_LE):
        return data[4:], "utf-32-le"
    if data.startswith(codecs.BOM_UTF32_BE):
        return data[4:], "utf-32-be"
    if data.startswith(codecs.BOM_UTF16_LE):
        return data[2:], "utf-16-le"
    if data.startswith(codecs.BOM_UTF16_BE):
        return data[2:], "utf-16-be"
    return data, None


def read_file_head_bytes(path: Path, limit: int) -> bytes:
    lim = max(0, int(limit))
    with path.open("rb") as f:
        return f.read(lim)


_CJK_ENCODING_PRIORITY = (
    "gb18030",
    "gbk",
    "gb2312",
    "big5",
    "cp950",
    "cp949",
    "euc_jp",
    "euc_kr",
    "shift_jis",
    "cp932",
)


def _enc_norm(name: str) -> str:
    return (name or "").lower().replace("-", "_")


def _pick_among_charset_matches(matches: Any) -> Any | None:
    """在 chaos 相同的候选间优先大陆简体常见编码，减轻短文本误判为 Big5 等。"""
    best = matches.best()
    if best is None:
        return None
    b_chaos = float(getattr(best, "chaos", 0.0) or 0.0)
    tied: list[Any] = [
        m
        for m in matches
        if abs(float(getattr(m, "chaos", 0.0) or 0.0) - b_chaos) < 1e-9
    ]
    if len(tied) <= 1:
        return best

    def _score(m: Any) -> tuple[int, str]:
        enc = _enc_norm(getattr(m, "encoding", None) or "")
        for i, pref in enumerate(_CJK_ENCODING_PRIORITY):
            if enc == pref or enc.startswith(pref + "_"):
                return (i, enc)
        return (len(_CJK_ENCODING_PRIORITY) + 8, enc)

    return min(tied, key=_score)


def encoding_probe_from_sample(sample: bytes) -> dict[str, Any]:
    """使用 charset_normalizer 探测；未安装时返回空 ``encoding``。"""
    try:
        from charset_normalizer import from_bytes
    except ImportError:
        return {"encoding": None, "language": None, "chaos": None}
    if not sample:
        return {"encoding": None, "language": None, "chaos": None}
    matches = from_bytes(sample)
    best = _pick_among_charset_matches(matches)
    if best is None:
        return {"encoding": None, "language": None, "chaos": None}
    lang = getattr(best, "language", None)
    chaos = getattr(best, "chaos", None)
    return {
        "encoding": best.encoding,
        "language": str(lang) if lang is not None else None,
        "chaos": float(chaos) if chaos is not None else None,
    }


def is_probably_binary_bytes(sample: bytes, *, max_scan: int = 4096) -> bool:
    """启发式：高 NUL 比例视为二进制，跳过编码探测。"""
    if not sample or len(sample) < 64:
        return False
    head = sample[:max_scan]
    zeros = head.count(0)
    if zeros == 0:
        return False
    ratio = zeros / len(head)
    return ratio > 0.12


def decode_text_bytes_for_llm(
    chunk: bytes,
    *,
    path: Path,
    file_offset: int,
    full_size: int,
    align_utf8: bool,
) -> tuple[str, dict[str, Any]]:
    """
    将文件中读取的一段 **原始字节** 解码为 **str**（Unicode，便于模型消费）。

    * offset 0 时去除 Unicode BOM。
    * 优先 **UTF-8 严格**；失败则读文件头样本用 **charset_normalizer** 探测编码再解码。
    """
    meta: dict[str, Any] = {}
    work = chunk
    if file_offset == 0:
        work, bom = strip_unicode_bom(work)
        if bom:
            meta["bom"] = bom
    try:
        work.decode("utf-8", "strict")
        utf8_strict = True
    except UnicodeDecodeError:
        utf8_strict = False

    if utf8_strict:
        if align_utf8:
            text, tp, ts = decode_utf8_range(work, file_offset=file_offset)
            meta["utf8_trim_prefix"] = tp
            meta["utf8_trim_suffix"] = ts
        else:
            text = work.decode("utf-8")
            meta["utf8_trim_prefix"] = 0
            meta["utf8_trim_suffix"] = 0
        if meta.get("bom") == "utf-8-sig":
            meta["source_encoding"] = "utf-8-sig"
        return text, meta

    head = read_file_head_bytes(
        path, min(ENCODING_DETECTION_HEAD_MAX, max(full_size, 0))
    )
    if is_probably_binary_bytes(head):
        text = work.decode("utf-8", errors="replace")
        meta["source_encoding"] = "utf-8"
        meta["encoding_note"] = (
            "文件前部含大量 NUL，可能为二进制；已按 UTF-8 宽松解码（可能有替换符），请核实是否误读文本。"
        )
        meta["utf8_trim_prefix"] = 0
        meta["utf8_trim_suffix"] = 0
        return text, meta

    det = encoding_probe_from_sample(head)
    enc = det.get("encoding") or "utf-8"
    if det.get("language"):
        meta["language_guess"] = det["language"]
    if det.get("chaos") is not None:
        meta["encoding_chaos"] = det["chaos"]
    meta["source_encoding"] = enc
    note = (
        f"内容不是合法 UTF-8；已按探测编码 **{enc}** 解码为 Unicode（模型侧等价于 UTF-8 码位）。"
    )
    if meta.get("language_guess"):
        note += f" charset_normalizer 推测语言: **{meta['language_guess']}**。"
    meta["encoding_note"] = note
    text = work.decode(enc, errors="replace")
    meta["utf8_trim_prefix"] = 0
    meta["utf8_trim_suffix"] = 0
    return text, meta


def decode_subprocess_bytes(data: bytes) -> str:
    """
    解码 **子进程 PIPE** 捕获的字节流（单行 ``readline`` 或整块 ``communicate``）。

    * 优先 **UTF-8 严格**。
    * **Windows**：若宽松 UTF-8 出现大量 **U+FFFD**，回退 **gb18030** / **gbk** / **cp936** /
      ``locale.getpreferredencoding``，缓解 CMD/外部程序按 **系统 ANSI（简体中文多为 GBK）**
      输出而父进程按 UTF-8 解码导致的成片菱形问号。
    """
    if not data:
        return ""
    try:
        return data.decode("utf-8", errors="strict")
    except UnicodeDecodeError:
        pass
    u8 = data.decode("utf-8", errors="replace")
    if sys.platform != "win32":
        return u8
    n = len(u8)
    ffd = u8.count("\ufffd")
    # 少量替换符保留 UTF-8（可能夹杂非法单字节）；比例高则当作误用 UTF-8 解 GBK
    if ffd == 0 or ffd < max(2, n // 120):
        return u8
    for enc in ("gb18030", "gbk", "cp936"):
        try:
            return data.decode(enc, errors="strict")
        except UnicodeDecodeError:
            continue
    try:
        le = locale.getpreferredencoding(False)
        if le and le.lower().replace("_", "-") not in ("utf-8", "utf8", "cp65001"):
            return data.decode(le, errors="replace")
    except (LookupError, TypeError, ValueError):
        pass
    return u8


def decode_subprocess_pipe_line(raw: bytes) -> str:
    """等价于 ``decode_subprocess_bytes(raw).rstrip(\"\\r\\n\")``（``StreamReader.readline`` 结果）。"""
    return decode_subprocess_bytes(raw).rstrip("\r\n")
