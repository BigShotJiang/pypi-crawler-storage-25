"""AICD_HOME/agent_scripts：可积累的脚本库（.py/.sh/.ps1 等）+ 同名 .md 说明 + index.md 索引。"""

from __future__ import annotations

import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

INDEX_NAME = "index.md"
README_NAME = "README.md"

# 允许的脚本后缀（小写）
SCRIPT_EXTENSIONS: tuple[str, ...] = (".py", ".sh", ".ps1", ".bat", ".cmd")

_STEM_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$")


def validate_stem(raw: str) -> tuple[str | None, str | None]:
    s = (raw or "").strip()
    if not s:
        return None, "stem 为空"
    if ".." in s or "/" in s or "\\" in s:
        return None, "stem 不得包含路径分隔符"
    if not _STEM_RE.match(s):
        return None, "stem 须为 1–80 字符：字母数字开头，仅含 . _ -"
    low = s.lower()
    if low in ("index", "readme"):
        return None, "保留名 index / readme，请换 stem"
    return s, None


def kind_to_ext(kind: str) -> str | None:
    k = (kind or "").strip().lower()
    m = {
        "py": ".py",
        "python": ".py",
        "sh": ".sh",
        "bash": ".sh",
        "shell": ".sh",
        "ps1": ".ps1",
        "powershell": ".ps1",
        "bat": ".bat",
        "cmd": ".cmd",
    }
    return m.get(k)


def script_path_for_stem(root: Path, stem: str) -> Path | None:
    """返回已存在的脚本路径（每种 stem 只认一个脚本文件）。"""
    for ext in SCRIPT_EXTENSIONS:
        p = (root / f"{stem}{ext}").resolve()
        if p.is_file():
            return p
    return None


def doc_path_for_stem(root: Path, stem: str) -> Path:
    return (root / f"{stem}.md").resolve()


def ensure_agent_scripts_readme(agent_scripts: Path) -> None:
    agent_scripts.mkdir(parents=True, exist_ok=True)
    readme = agent_scripts / README_NAME
    if readme.is_file():
        return
    readme.write_text(
        "# AICD HOME 脚本库 (`agent_scripts`)\n\n"
        "本目录由 **home_scripts_*** 工具与 AI 维护，用于积累可复用的短脚本（**py** / **sh** / **ps1** / **bat** / **cmd**）。\n\n"
        "- 每个逻辑脚本一份：**`<stem>.<ext>`**，并配 **`<stem>.md`** 说明用途、参数、示例与安全注意。\n"
        "- 总索引：**`index.md`**（可用 **home_scripts_index_rebuild** 从目录扫描重建）。\n"
        "- 与 **`tmp/scripts`**（一次性 script_run 暂存）不同：此处脚本是**长期保留**、可版本化改进的「工具箱」。\n",
        encoding="utf-8",
    )


def list_entries(agent_scripts: Path) -> dict[str, Any]:
    ensure_agent_scripts_readme(agent_scripts)
    root = agent_scripts.resolve()
    entries: list[dict[str, Any]] = []
    stems: set[str] = set()
    for ext in SCRIPT_EXTENSIONS:
        for p in sorted(root.glob(f"*{ext}")):
            if not p.is_file():
                continue
            stem = p.stem
            if stem in (INDEX_NAME[:-3], README_NAME[:-3]):
                continue
            stems.add(stem)
    for stem in sorted(stems):
        sp = script_path_for_stem(root, stem)
        dp = doc_path_for_stem(root, stem)
        ext = sp.suffix.lower() if sp else ""
        doc_excerpt = ""
        if dp.is_file():
            try:
                raw = dp.read_text(encoding="utf-8", errors="replace")
                doc_excerpt = raw.strip().replace("\n", " ")[:240]
            except OSError:
                doc_excerpt = ""
        entries.append(
            {
                "stem": stem,
                "ext": ext,
                "script_path": str(sp) if sp else "",
                "doc_path": str(dp),
                "has_doc": dp.is_file(),
                "doc_excerpt": doc_excerpt,
            }
        )
    index_exists = (root / INDEX_NAME).is_file()
    return {
        "ok": True,
        "agent_scripts_dir": str(root),
        "index_path": str(root / INDEX_NAME),
        "index_exists": index_exists,
        "count": len(entries),
        "entries": entries,
    }


def read_pair(agent_scripts: Path, stem: str) -> dict[str, Any]:
    stem_ok, err = validate_stem(stem)
    if err:
        return {"ok": False, "error": err}
    assert stem_ok is not None
    root = agent_scripts.resolve()
    sp = script_path_for_stem(root, stem_ok)
    dp = doc_path_for_stem(root, stem_ok)
    out: dict[str, Any] = {
        "ok": True,
        "stem": stem_ok,
        "script_path": str(sp) if sp else "",
        "doc_path": str(dp),
    }
    if sp and sp.is_file():
        try:
            out["script_text"] = sp.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            out["script_text"] = ""
            out["script_read_error"] = str(e)
    else:
        out["script_text"] = None
    if dp.is_file():
        try:
            out["doc_text"] = dp.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            out["doc_text"] = ""
            out["doc_read_error"] = str(e)
    else:
        out["doc_text"] = None
    idx = root / INDEX_NAME
    if idx.is_file():
        try:
            out["index_text"] = idx.read_text(encoding="utf-8", errors="replace")
        except OSError:
            out["index_text"] = None
    else:
        out["index_text"] = None
    return out


def write_pair(
    agent_scripts: Path,
    stem: str,
    kind: str,
    script_body: str,
    doc_md: str,
    *,
    rebuild_index: bool = True,
) -> dict[str, Any]:
    stem_ok, err = validate_stem(stem)
    if err:
        return {"ok": False, "error": err}
    assert stem_ok is not None
    ext = kind_to_ext(kind)
    if not ext:
        return {"ok": False, "error": f"不支持的 kind: {kind!r}，使用 py|sh|ps1|bat|cmd"}
    root = agent_scripts.resolve()
    ensure_agent_scripts_readme(root)
    # 若已存在其它后缀的同名 stem，先拒绝双脚本
    existing = script_path_for_stem(root, stem_ok)
    if existing is not None and existing.suffix.lower() != ext:
        return {
            "ok": False,
            "error": f"stem {stem_ok!r} 已存在 {existing.suffix}，请先删除或换 stem",
        }
    script_path = root / f"{stem_ok}{ext}"
    doc_path = doc_path_for_stem(root, stem_ok)
    try:
        script_path.write_text(script_body or "", encoding="utf-8")
        doc_path.write_text(doc_md or "", encoding="utf-8")
    except OSError as e:
        return {"ok": False, "error": f"write_failed: {e}"}
    idx_msg = ""
    if rebuild_index:
        rb = rebuild_index_md(root)
        idx_msg = rb.get("message", "")
    return {
        "ok": True,
        "stem": stem_ok,
        "script_path": str(script_path),
        "doc_path": str(doc_path),
        "index_updated": bool(rebuild_index),
        "detail": idx_msg,
    }


def rebuild_index_md(agent_scripts: Path) -> dict[str, Any]:
    ensure_agent_scripts_readme(agent_scripts)
    root = agent_scripts.resolve()
    info = list_entries(root)
    rows = info.get("entries") or []
    ts = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    lines = [
        "# AICD HOME 脚本索引 (`agent_scripts/index.md`)",
        "",
        f"自动生成（UTC）：**{ts}**",
        "",
        "| stem | 脚本 | 说明文件 |",
        "|------|------|----------|",
    ]
    for e in rows:
        st = str(e.get("stem") or "")
        ext = str(e.get("ext") or "")
        has_doc = "✓" if e.get("has_doc") else "—"
        lines.append(f"| `{st}` | `{st}{ext}` | `{st}.md` ({has_doc}) |")
    lines.append("")
    lines.append("## 摘录")
    lines.append("")
    for e in rows:
        st = str(e.get("stem") or "")
        ex = str(e.get("doc_excerpt") or "").strip()
        if ex:
            lines.append(f"- **{st}**：{ex}")
    lines.append("")
    body = "\n".join(lines)
    idx = root / INDEX_NAME
    try:
        idx.write_text(body, encoding="utf-8")
    except OSError as e:
        return {"ok": False, "error": str(e)}
    return {
        "ok": True,
        "index_path": str(idx),
        "bytes": len(body.encode("utf-8")),
        "message": f"已写入 {idx}",
    }


def delete_script(agent_scripts: Path, stem: str) -> dict[str, Any]:
    stem_ok, err = validate_stem(stem)
    if err:
        return {"ok": False, "error": err}
    assert stem_ok is not None
    root = agent_scripts.resolve()
    sp = script_path_for_stem(root, stem_ok)
    dp = doc_path_for_stem(root, stem_ok)
    removed: list[str] = []
    for p in (sp, dp):
        if p is not None and p.is_file():
            try:
                p.unlink()
                removed.append(str(p))
            except OSError as e:
                return {"ok": False, "error": str(e)}
    rebuild_index_md(root)
    return {"ok": True, "removed": removed}


def argv_for_run(script_path: Path, extra_argv: list[str] | None) -> list[str] | None:
    """构造 run_command 的 argv；脚本须在 agent_scripts 下。"""
    p = script_path.resolve()
    if not p.is_file():
        return None
    ext = p.suffix.lower()
    rest = [str(x) for x in (extra_argv or []) if str(x).strip()]
    if ext == ".py":
        return [sys.executable, str(p), *rest]
    if ext == ".sh":
        if sys.platform == "win32":
            return ["bash", str(p), *rest]
        return ["/bin/bash", str(p), *rest]
    if ext == ".ps1":
        if sys.platform == "win32":
            return [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(p),
                *rest,
            ]
        return ["pwsh", "-NoProfile", "-File", str(p), *rest]
    if ext in (".bat", ".cmd"):
        if sys.platform != "win32":
            return None
        return ["cmd", "/d", "/c", str(p), *rest]
    return None
