"""跨平台交互式子进程会话（PIPE 多轮 stdin/stdout/stderr），供 AI 在多轮工具调用中驱动需应答 CLI。

状态挂在 **ToolRouter._interactive_bucket**（每路由一份：主 Agent 与子 Agent、多 Runtime 互不共享）。
"""

from __future__ import annotations

import asyncio
import logging
import sys
import time
import uuid
from collections import OrderedDict
from pathlib import Path
from typing import TYPE_CHECKING, Any

from aicd.cli_encoding import subprocess_env_utf8
from aicd.tools.text_encoding import decode_subprocess_bytes
from aicd.tools.process_tool import (
    _PASSWORD_PROMPT_RE,
    _NONINTERACTIVE_ENV_DEFAULTS,
    _terminate_subprocess,
    shell_argv_from_user_input,
    warn_shell_preflight,
)

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter

_MAX_SESSIONS = 8
_MAX_CAPTURE_BYTES_PER_SESSION = 2_000_000
_MAX_LABEL_LEN = 64
_DEFAULT_READ_TIMEOUT = 5.0
_DEFAULT_READ_MAX_BYTES = 65_536
_MAX_READ_RESULT_BYTES = 400_000
_READ_TIMEOUT_MAX_SEC = 600.0
_WRITE_CHUNK_BYTES = 65_536
_MAX_WRITE_TOTAL_BYTES = 8 * 1024 * 1024
_READ_LOG_MAX_LINES_PER_STREAM = 64
_MAX_IDLE_TTL_SEC = 86_400.0

# 对外稳定名（实现仍用带下划线常量）；测试与集成可引用。
WRITE_CHUNK_BYTES = _WRITE_CHUNK_BYTES
MAX_WRITE_TOTAL_BYTES = _MAX_WRITE_TOTAL_BYTES

_LOG = logging.getLogger(__name__)


def _normalize_session_label(raw: Any) -> str | None:
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    if len(s) > _MAX_LABEL_LEN:
        s = s[:_MAX_LABEL_LEN]
    if any(ord(c) < 32 for c in s):
        return None
    return s


def _argv_preview_join(argv: list[str], *, max_len: int = 120) -> str:
    joined = " ".join(argv)
    if len(joined) <= max_len:
        return joined
    return joined[: max_len - 3] + "..."


class _InteractiveSession:
    __slots__ = (
        "session_id",
        "proc",
        "cwd",
        "argv",
        "label",
        "creation_seq",
        "capture_total",
        "recent_tail",
        "lock",
        "last_activity_monotonic",
    )

    def __init__(
        self,
        session_id: str,
        proc: asyncio.subprocess.Process,
        cwd: Path,
        argv: list[str],
        *,
        label: str | None,
        creation_seq: int,
    ) -> None:
        self.session_id = session_id
        self.proc = proc
        self.cwd = cwd
        self.argv = argv
        self.label = label
        self.creation_seq = creation_seq
        self.capture_total = 0
        self.recent_tail = ""
        self.lock = asyncio.Lock()
        self.last_activity_monotonic = time.monotonic()

    def touch_activity(self) -> None:
        self.last_activity_monotonic = time.monotonic()

    def _note_capture(self, chunk: str) -> None:
        # 常见子进程输出为 ASCII：避免整段 encode 仅为了计字节。
        if chunk.isascii():
            self.capture_total += len(chunk)
        else:
            self.capture_total += len(chunk.encode("utf-8", errors="replace"))
        tail = self.recent_tail + chunk
        if len(tail) > 12000:
            tail = tail[-12000:]
        self.recent_tail = tail

    def password_hint(self) -> bool:
        return bool(_PASSWORD_PROMPT_RE.search(self.recent_tail))


class InteractiveProcessBucket:
    """单台 ToolRouter 下的会话表；支持空闲 TTL 与满额淘汰。"""

    def __init__(self, *, idle_ttl_sec: float | None = None) -> None:
        self._idle_ttl_sec: float | None = (
            float(idle_ttl_sec)
            if idle_ttl_sec is not None and float(idle_ttl_sec) > 0
            else None
        )
        if self._idle_ttl_sec is not None:
            self._idle_ttl_sec = min(_MAX_IDLE_TTL_SEC, self._idle_ttl_sec)
        self._registry: "OrderedDict[str, _InteractiveSession]" = OrderedDict()
        self._registry_lock = asyncio.Lock()
        self._label_map: dict[str, str] = {}
        self._creation_seq_counter = 0

    def set_idle_ttl_sec(self, sec: float) -> None:
        """运行中随配置更新；``<=0`` 表示关闭空闲回收。"""
        s = float(sec)
        if s <= 0:
            self._idle_ttl_sec = None
        else:
            self._idle_ttl_sec = min(_MAX_IDLE_TTL_SEC, s)

    def _drop_session_labels(self, sess: _InteractiveSession) -> None:
        if sess.label and self._label_map.get(sess.label) == sess.session_id:
            self._label_map.pop(sess.label, None)

    async def cleanup_all(self, *, reason: str = "shutdown") -> None:
        async with self._registry_lock:
            items = list(self._registry.values())
            self._registry.clear()
            self._label_map.clear()
        _LOG.debug("interactive_process cleanup_all: %s sessions=%s", reason, len(items))
        if not items:
            return

        async def _terminate_session(sess: _InteractiveSession) -> None:
            async with sess.lock:
                if sess.proc.returncode is None:
                    await _terminate_subprocess(
                        sess.proc, kill_subtree=sys.platform == "win32"
                    )

        async def _one(sess: _InteractiveSession) -> None:
            try:
                await asyncio.wait_for(_terminate_session(sess), timeout=14.0)
            except (asyncio.TimeoutError, asyncio.CancelledError, OSError, Exception):
                pass

        await asyncio.gather(*(_one(s) for s in items), return_exceptions=True)

    async def _terminate_and_remove_session(self, sess: _InteractiveSession) -> None:
        try:
            async with sess.lock:
                if sess.proc.returncode is None:
                    await _terminate_subprocess(
                        sess.proc, kill_subtree=sys.platform == "win32"
                    )
        except Exception:
            pass
        async with self._registry_lock:
            self._drop_session_labels(sess)
            self._registry.pop(sess.session_id, None)

    async def prune_idle_sessions(self) -> None:
        if self._idle_ttl_sec is None:
            return
        now = time.monotonic()
        stale: list[_InteractiveSession] = []
        async with self._registry_lock:
            for sess in list(self._registry.values()):
                if now - sess.last_activity_monotonic >= self._idle_ttl_sec:
                    stale.append(sess)
        for sess in stale:
            await self._terminate_and_remove_session(sess)

    async def _reg_put(self, sess: _InteractiveSession) -> dict[str, Any] | None:
        while True:
            evicted: _InteractiveSession | None = None
            async with self._registry_lock:
                if sess.label and sess.label in self._label_map:
                    return {
                        "ok": False,
                        "error": "duplicate_session_label",
                        "session_label": sess.label,
                        "hint": "当前已存在同名 session_label，请先 terminate 或换名。",
                    }
                if len(self._registry) < _MAX_SESSIONS:
                    self._creation_seq_counter += 1
                    sess.creation_seq = self._creation_seq_counter
                    self._registry[sess.session_id] = sess
                    self._registry.move_to_end(sess.session_id)
                    if sess.label:
                        self._label_map[sess.label] = sess.session_id
                    sess.touch_activity()
                    return None
                _, evicted = self._registry.popitem(last=False)
                self._drop_session_labels(evicted)
            if evicted is not None:
                async with evicted.lock:
                    if evicted.proc.returncode is None:
                        await _terminate_subprocess(
                            evicted.proc,
                            kill_subtree=sys.platform == "win32",
                        )

    def _merge_env_base(
        self, env: dict[str, str] | None, noninteractive_env: bool
    ) -> dict[str, str] | None:
        if not env and not noninteractive_env:
            return None
        base = dict(env) if env else {}
        if noninteractive_env:
            for k, v in _NONINTERACTIVE_ENV_DEFAULTS.items():
                base.setdefault(k, v)
        return base

    async def _read_stream(
        self, stream: asyncio.StreamReader | None, max_bytes: int, timeout_sec: float
    ) -> bytes:
        if stream is None:
            return b""

        async def _one() -> bytes:
            return await stream.read(max_bytes)

        try:
            return await asyncio.wait_for(_one(), timeout=timeout_sec)
        except TimeoutError:
            return b""

    async def handle(self, router: Any, args: dict[str, Any]) -> dict[str, Any]:
        await self.prune_idle_sessions()
        op = str(args.get("operation") or "").strip().lower()
        if op not in ("start", "write", "read", "terminate", "status", "list_sessions"):
            return {
                "ok": False,
                "error": "invalid_operation",
                "hint": "operation 须为 start | write | read | terminate | status | list_sessions",
            }

        if op == "start":
            return await self._op_start(router, args)
        if op == "list_sessions":
            return await self._op_list_sessions()

        res_sess, err = await self._resolve_session_async(args)
        if err is not None:
            return err
        assert res_sess is not None
        sess = res_sess

        async with self._registry_lock:
            self._registry.move_to_end(sess.session_id)

        if op == "write":
            return await self._op_write(router, sess, args)
        if op == "read":
            return await self._op_read(router, sess, args)
        if op == "terminate":
            return await self._op_terminate(sess, args)
        return await self._op_status(router, sess)

    async def _attach_session_identity(
        self, sess: _InteractiveSession, out: dict[str, Any]
    ) -> None:
        if sess.label is not None:
            out["session_label"] = sess.label
        async with self._registry_lock:
            items_sorted = sorted(self._registry.values(), key=lambda s: s.creation_seq)
            for i, s in enumerate(items_sorted, start=1):
                if s.session_id == sess.session_id:
                    out["session_index"] = i
                    return
        out["session_index"] = None

    def _argv_preview(self, argv: list[str], *, max_len: int = 120) -> str:
        return _argv_preview_join(argv, max_len=max_len)

    async def _resolve_session_async(
        self, args: dict[str, Any]
    ) -> tuple[_InteractiveSession | None, dict[str, Any] | None]:
        sid_raw = str(args.get("session_id") or "").strip()
        label = _normalize_session_label(args.get("session_label"))
        idx_raw = args.get("session_index")
        has_idx = idx_raw is not None and str(idx_raw).strip() != ""

        if not sid_raw and not label and not has_idx:
            return None, {
                "ok": False,
                "error": "session_selector_required",
                "hint": "write/read/terminate/status 需要 session_id、session_label 或 session_index；可先 list_sessions。",
            }

        async with self._registry_lock:
            if sid_raw:
                sess = self._registry.get(sid_raw)
                if sess is None:
                    return None, {
                        "ok": False,
                        "error": "unknown_session_id",
                        "session_id": sid_raw,
                    }
                return sess, None
            if label:
                sid = self._label_map.get(label)
                if not sid:
                    return None, {
                        "ok": False,
                        "error": "unknown_session_label",
                        "session_label": label,
                    }
                sess = self._registry.get(sid)
                if sess is None:
                    return None, {
                        "ok": False,
                        "error": "unknown_session_label",
                        "session_label": label,
                        "hint": "内部不一致，请 list_sessions。",
                    }
                return sess, None
            if isinstance(idx_raw, bool):
                return None, {"ok": False, "error": "invalid_session_index"}
            if isinstance(idx_raw, float):
                return None, {"ok": False, "error": "invalid_session_index"}
            try:
                idx = int(idx_raw)  # type: ignore[arg-type]
            except (TypeError, ValueError):
                return None, {"ok": False, "error": "invalid_session_index"}
            if idx < 1:
                return None, {"ok": False, "error": "invalid_session_index"}
            items_sorted = sorted(self._registry.values(), key=lambda s: s.creation_seq)
            if idx > len(items_sorted):
                return None, {
                    "ok": False,
                    "error": "session_index_out_of_range",
                    "session_index": idx,
                    "session_count": len(items_sorted),
                    "hint": "先用 list_sessions 查看当前 session_index。",
                }
            return items_sorted[idx - 1], None

    async def _op_list_sessions(self) -> dict[str, Any]:
        async with self._registry_lock:
            items_sorted = sorted(self._registry.values(), key=lambda s: s.creation_seq)
        sessions: list[dict[str, Any]] = []
        for i, s in enumerate(items_sorted, start=1):
            async with s.lock:
                rc = s.proc.returncode
                pid = s.proc.pid
                running = rc is None
                ph = s.password_hint()
                idle_sec: float | None = None
                if self._idle_ttl_sec is not None:
                    idle_sec = max(
                        0.0, self._idle_ttl_sec - (time.monotonic() - s.last_activity_monotonic)
                    )
            row: dict[str, Any] = {
                "session_index": i,
                "session_id": s.session_id,
                "session_label": s.label,
                "pid": pid,
                "running": running,
                "returncode": rc,
                "argv_preview": self._argv_preview(s.argv),
                "cwd": str(s.cwd),
                "password_hint": ph,
            }
            if idle_sec is not None:
                row["approx_idle_until_auto_close_sec"] = round(idle_sec, 1)
            sessions.append(row)
        out_ls: dict[str, Any] = {
            "ok": True,
            "operation": "list_sessions",
            "count": len(sessions),
            "sessions": sessions,
            "hint": "与用户对话时可说「写到名为 db 的会话」或「第 2 个交互任务」；模型应把名称填入 session_label，或序号填入 session_index。",
        }
        if self._idle_ttl_sec is not None:
            out_ls["idle_ttl_sec"] = self._idle_ttl_sec
        return out_ls

    async def _op_start(self, router: Any, args: dict[str, Any]) -> dict[str, Any]:
        from aicd.agent.tool_args_coerce import coerce_tool_json_array, coerce_tool_json_object

        raw_argv = args.get("argv")
        if raw_argv is not None:
            co = coerce_tool_json_array(raw_argv, "argv", allow_empty=True)
            if isinstance(co, dict):
                return co
            raw_argv = co
        cmd = args.get("command")
        if raw_argv is None and cmd is not None and str(cmd).strip():
            if (w := warn_shell_preflight(str(cmd))):
                return {"ok": False, "error": w}
        try:
            argv = shell_argv_from_user_input(
                command=args.get("command"),
                argv=[str(x) for x in raw_argv] if raw_argv else None,
                shell=str(args.get("shell")).strip() if args.get("shell") is not None else None,
            )
        except ValueError as e:
            return {"ok": False, "error": str(e)}

        cwd_arg = args.get("cwd")
        wd = Path(cwd_arg).resolve() if cwd_arg else router._process._cwd
        router._process._policy.check_allowed(wd)

        env_obj = args.get("env")
        env_merged: dict[str, str] | None = None
        if env_obj is not None:
            e_obj, e_err = coerce_tool_json_object(env_obj, "env")
            if e_err:
                return {"ok": False, "error": e_err}
            env_merged = {str(k): str(v) for k, v in e_obj.items()}
        noninteractive_env = bool(args.get("noninteractive_env"))
        env_merged = self._merge_env_base(env_merged, noninteractive_env)

        exec_kw: dict[str, Any] = {
            "cwd": str(wd),
            "env": subprocess_env_utf8(env_merged),
            "stdin": asyncio.subprocess.PIPE,
            "stdout": asyncio.subprocess.PIPE,
            "stderr": asyncio.subprocess.PIPE,
        }
        raw_label = args.get("session_label")
        if raw_label is not None and str(raw_label).strip():
            label = _normalize_session_label(raw_label)
            if label is None:
                return {
                    "ok": False,
                    "error": "invalid_session_label",
                    "hint": "标签须为可打印文本，最长 64，勿含控制字符。",
                }
            async with self._registry_lock:
                if label in self._label_map:
                    return {
                        "ok": False,
                        "error": "duplicate_session_label",
                        "session_label": label,
                        "hint": "同名会话仍在运行，请先 terminate 或换 session_label。",
                    }
        else:
            label = None

        try:
            proc = await asyncio.create_subprocess_exec(*argv, **exec_kw)
        except FileNotFoundError as e:
            return {"ok": False, "error": f"executable_not_found: {e}"}
        except OSError as e:
            return {"ok": False, "error": str(e)}

        sid = str(uuid.uuid4())
        sess = _InteractiveSession(
            sid,
            proc,
            wd,
            argv,
            label=label,
            creation_seq=0,
        )
        reg_err = await self._reg_put(sess)
        if reg_err is not None:
            await _terminate_subprocess(proc, kill_subtree=sys.platform == "win32")
            return reg_err

        out: dict[str, Any] = {
            "ok": True,
            "operation": "start",
            "session_id": sid,
            "session_index": None,
            "pid": proc.pid,
            "argv": argv,
            "cwd": str(wd),
            "hint": "后续 read/write/terminate 可用 session_id、session_label 或 list_sessions 中的 session_index。聊天里可说「第 N 个」或名称。",
        }
        if label is not None:
            out["session_label"] = label
        if self._idle_ttl_sec is not None:
            out["idle_ttl_sec"] = self._idle_ttl_sec
        async with self._registry_lock:
            items_sorted = sorted(self._registry.values(), key=lambda s: s.creation_seq)
            for i, s in enumerate(items_sorted, start=1):
                if s.session_id == sid:
                    out["session_index"] = i
                    break
        await _maybe_publish_started(router, sess)
        return out

    async def _op_write(
        self, router: Any, sess: _InteractiveSession, args: dict[str, Any]
    ) -> dict[str, Any]:
        text = args.get("text")
        if text is None:
            return {"ok": False, "error": "text_required"}
        raw = str(text)
        if bool(args.get("append_newline", True)) and not raw.endswith("\n"):
            raw = raw + "\n"
        blob = raw.encode("utf-8", errors="replace")
        total = len(blob)
        if total > _MAX_WRITE_TOTAL_BYTES:
            return {
                "ok": False,
                "error": "write_payload_too_large",
                "session_id": sess.session_id,
                "max_bytes": _MAX_WRITE_TOTAL_BYTES,
                "hint": f"单次工具写入总长不超过 {_MAX_WRITE_TOTAL_BYTES} 字节；更大请 **fs_write_file** 后让子进程读文件。",
            }

        n_chunks = max(1, (total + _WRITE_CHUNK_BYTES - 1) // _WRITE_CHUNK_BYTES)

        async with sess.lock:
            if sess.proc.returncode is not None:
                return {
                    "ok": False,
                    "error": "process_already_exited",
                    "session_id": sess.session_id,
                    "returncode": sess.proc.returncode,
                }
            if sess.proc.stdin is None:
                return {"ok": False, "error": "stdin_not_available"}
            try:
                for off in range(0, total, _WRITE_CHUNK_BYTES):
                    chunk = blob[off : off + _WRITE_CHUNK_BYTES]
                    sess.proc.stdin.write(chunk)
                    await sess.proc.stdin.drain()
            except (BrokenPipeError, ConnectionResetError, OSError) as e:
                return {
                    "ok": False,
                    "error": f"stdin_write_failed: {e}",
                    "session_id": sess.session_id,
                }
            ph = sess.password_hint()
            sess.touch_activity()

        out_wr = {
            "ok": True,
            "operation": "write",
            "session_id": sess.session_id,
            "bytes_written": total,
            "write_chunks": n_chunks,
            "password_hint": ph,
        }
        await self._attach_session_identity(sess, out_wr)
        return out_wr

    async def _op_read(
        self, router: Any, sess: _InteractiveSession, args: dict[str, Any]
    ) -> dict[str, Any]:
        try:
            timeout_sec = float(args.get("timeout_sec", _DEFAULT_READ_TIMEOUT))
        except (TypeError, ValueError):
            timeout_sec = _DEFAULT_READ_TIMEOUT
        if timeout_sec < 0:
            timeout_sec = 0.0
        if timeout_sec > _READ_TIMEOUT_MAX_SEC:
            timeout_sec = _READ_TIMEOUT_MAX_SEC
        try:
            max_bytes = int(args.get("max_bytes", _DEFAULT_READ_MAX_BYTES))
        except (TypeError, ValueError):
            max_bytes = _DEFAULT_READ_MAX_BYTES
        max_bytes = max(256, min(max_bytes, 4_194_304))

        stream = str(args.get("stream") or "both").strip().lower()
        if stream not in ("both", "stdout", "stderr"):
            stream = "both"

        async with sess.lock:
            if sess.capture_total >= _MAX_CAPTURE_BYTES_PER_SESSION:
                return {
                    "ok": False,
                    "error": "capture_per_session_limit",
                    "session_id": sess.session_id,
                    "hint": f"本会话累计输出已超过 {_MAX_CAPTURE_BYTES_PER_SESSION} 字节，请 terminate 后改用日志文件或非交互方式。",
                }

            if stream == "stdout":
                out_b = await self._read_stream(sess.proc.stdout, max_bytes, timeout_sec)
                err_b = b""
            elif stream == "stderr":
                out_b = b""
                err_b = await self._read_stream(sess.proc.stderr, max_bytes, timeout_sec)
            else:
                out_b, err_b = await asyncio.gather(
                    self._read_stream(sess.proc.stdout, max_bytes, timeout_sec),
                    self._read_stream(sess.proc.stderr, max_bytes, timeout_sec),
                )

            out_s = decode_subprocess_bytes(out_b)
            err_s = decode_subprocess_bytes(err_b)
            sess._note_capture(out_s)
            sess._note_capture(err_s)

            rc = sess.proc.returncode
            exited = rc is not None
            ph = sess.password_hint()
            cap = sess.capture_total
            sess.touch_activity()

        combined = ""
        if out_s:
            combined += out_s
        if err_s:
            combined += err_s

        truncated = False
        out_part, err_part = out_s, err_s
        if len(combined) > _MAX_READ_RESULT_BYTES:
            truncated = True
            budget = _MAX_READ_RESULT_BYTES
            if err_s and len(err_s) <= budget // 4:
                take_out = budget - len(err_s)
                out_part = out_s[:take_out] if take_out > 0 else ""
                err_part = err_s
            else:
                half = budget // 2
                out_part = out_s[:half]
                err_part = err_s[: budget - len(out_part)]

        hint_read = "若输出不完整可再次 read；若需用户选择可先展示输出再询问用户，下一轮再 write。"
        if ph:
            hint_read += " 输出中疑似密码/敏感提示，不要自动代填，应询问用户或让其在本机终端处理。"

        out_rd = {
            "ok": True,
            "operation": "read",
            "session_id": sess.session_id,
            "stdout": out_part,
            "stderr": err_part,
            "stdout_bytes": len(out_b),
            "stderr_bytes": len(err_b),
            "process_exited": exited,
            "returncode": rc,
            "password_hint": ph,
            "capture_total_bytes_approx": cap,
            "result_truncated": truncated,
            "hint": hint_read,
        }
        await self._attach_session_identity(sess, out_rd)
        await _maybe_publish_read_streams(router, sess, out_s, err_s)
        return out_rd

    async def _op_terminate(
        self, sess: _InteractiveSession, args: dict[str, Any]
    ) -> dict[str, Any]:
        kill_subtree = bool(args.get("kill_subtree")) if args.get("kill_subtree") is not None else (
            sys.platform == "win32"
        )
        async with sess.lock:
            if sess.proc.returncode is None:
                await _terminate_subprocess(sess.proc, kill_subtree=kill_subtree)
            rc = sess.proc.returncode
        out_te: dict[str, Any] = {
            "ok": True,
            "operation": "terminate",
            "session_id": sess.session_id,
            "returncode": rc,
        }
        if sess.label is not None:
            out_te["session_label"] = sess.label
        async with self._registry_lock:
            items_sorted = sorted(self._registry.values(), key=lambda s: s.creation_seq)
            for i, s in enumerate(items_sorted, start=1):
                if s.session_id == sess.session_id:
                    out_te["session_index"] = i
                    break
            else:
                out_te["session_index"] = None
            self._drop_session_labels(sess)
            self._registry.pop(sess.session_id, None)
        return out_te

    async def _op_status(
        self, router: Any, sess: _InteractiveSession
    ) -> dict[str, Any]:
        async with sess.lock:
            rc = sess.proc.returncode
            pid = sess.proc.pid
            ph = sess.password_hint()
            cap = sess.capture_total
        out_st: dict[str, Any] = {
            "ok": True,
            "operation": "status",
            "session_id": sess.session_id,
            "pid": pid,
            "returncode": rc,
            "running": rc is None,
            "argv": sess.argv,
            "cwd": str(sess.cwd),
            "capture_total_bytes_approx": cap,
            "password_hint": ph,
        }
        if self._idle_ttl_sec is not None:
            out_st["approx_idle_until_auto_close_sec"] = max(
                0.0,
                self._idle_ttl_sec - (time.monotonic() - sess.last_activity_monotonic),
            )
            out_st["idle_ttl_sec"] = self._idle_ttl_sec
        await self._attach_session_identity(sess, out_st)
        return out_st


def _event_bus(router: Any) -> Any | None:
    tasks = getattr(router, "_tasks", None)
    if tasks is None:
        return None
    return getattr(tasks, "bus", None)


async def _maybe_publish_started(router: Any, sess: _InteractiveSession) -> None:
    bus = _event_bus(router)
    if bus is None:
        return
    from aicd.ui.shell_log_sanitize import sanitize_shell_log_line

    tag = sess.label or sess.session_id[:8]
    prev = sanitize_shell_log_line(_argv_preview_join(sess.argv, max_len=200))
    line = sanitize_shell_log_line(
        f"[ipc:{tag}] started pid={sess.proc.pid} cwd={sess.cwd} argv={prev}",
        max_len=12000,
    )
    await bus.publish({"topic": "agent", "event": "log", "line": line})


async def _maybe_publish_read_streams(
    router: Any, sess: _InteractiveSession, out_s: str, err_s: str
) -> None:
    bus = _event_bus(router)
    if bus is None:
        return
    from aicd.ui.shell_log_sanitize import sanitize_shell_log_line

    tag = sess.label or sess.session_id[:8]

    async def _emit(stream_name: str, text: str) -> None:
        if not text or not text.strip():
            return
        lines = text.splitlines()
        total = len(lines)
        chunk = lines[:_READ_LOG_MAX_LINES_PER_STREAM]
        prefix = f"[ipc:{tag}] [{stream_name}] "
        for ln in chunk:
            sl = sanitize_shell_log_line(ln, max_len=8000)
            if sl.strip():
                await bus.publish({"topic": "agent", "event": "log", "line": prefix + sl})
        if total > len(chunk):
            await bus.publish(
                {
                    "topic": "agent",
                    "event": "log",
                    "line": prefix + f"... ({total} lines, log truncated for TUI)",
                }
            )

    await _emit("stdout", out_s)
    await _emit("stderr", err_s)


_FALLBACK_BUCKET: InteractiveProcessBucket | None = None


def _bucket_for(router: Any) -> InteractiveProcessBucket:
    b = getattr(router, "_interactive_bucket", None)
    if isinstance(b, InteractiveProcessBucket):
        return b
    global _FALLBACK_BUCKET
    if _FALLBACK_BUCKET is None:
        _FALLBACK_BUCKET = InteractiveProcessBucket(idle_ttl_sec=None)
    return _FALLBACK_BUCKET


async def dispatch(router: Any, args: dict[str, Any]) -> dict[str, Any]:
    return await _bucket_for(router).handle(router, args)


async def cleanup_all_interactive_sessions(*, reason: str = "shutdown") -> None:
    """兼容测试与旧调用点：清理**回退**全局桶。生产路径应使用 ``ToolRouter._interactive_bucket.cleanup_all``。"""
    global _FALLBACK_BUCKET
    if _FALLBACK_BUCKET is not None:
        await _FALLBACK_BUCKET.cleanup_all(reason=reason)
