"""将标题、段落、分页、表格与本地图片写入 .docx（python-docx）。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from aicd.tools.raster_document_fit import fit_display_cm, read_raster_pixel_size

MAX_BLOCKS = 200
MAX_IMAGE_BYTES = 25 * 1024 * 1024
MAX_TABLE_ROWS = 80
MAX_TABLE_COLS = 20
MAX_CELL_CHARS = 8000


def _norm_blocks(raw: Any) -> tuple[list[dict[str, Any]] | None, str | None]:
    if not isinstance(raw, list):
        return None, "blocks must be a JSON array"
    if len(raw) > MAX_BLOCKS:
        return None, f"at most {MAX_BLOCKS} blocks"
    out: list[dict[str, Any]] = []
    for i, b in enumerate(raw):
        if not isinstance(b, dict):
            return None, f"blocks[{i}] must be object"
        bc = dict(b)
        if str(bc.get("type") or "").strip().lower() == "table":
            rr = bc.get("rows")
            if isinstance(rr, str):
                s = rr.strip()
                if s:
                    try:
                        bc["rows"] = json.loads(s)
                    except json.JSONDecodeError:
                        return None, f"blocks[{i}]: table.rows is not valid JSON"
        out.append(bc)
    return out, None


def _hex_rgb(color_hex: str) -> RGBColor | None:
    h = color_hex.strip().lstrip("#")
    if len(h) != 6:
        return None
    try:
        return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except ValueError:
        return None


def _parse_alignment(raw: Any) -> WD_ALIGN_PARAGRAPH | None:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    m = {
        "left": WD_ALIGN_PARAGRAPH.LEFT,
        "center": WD_ALIGN_PARAGRAPH.CENTER,
        "right": WD_ALIGN_PARAGRAPH.RIGHT,
        "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
    }
    return m.get(s)


def _parse_table_alignment(raw: Any) -> WD_TABLE_ALIGNMENT | None:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    m = {
        "left": WD_TABLE_ALIGNMENT.LEFT,
        "center": WD_TABLE_ALIGNMENT.CENTER,
        "right": WD_TABLE_ALIGNMENT.RIGHT,
    }
    return m.get(s)


def _parse_vertical_alignment(raw: Any) -> WD_CELL_VERTICAL_ALIGNMENT | None:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    m = {
        "top": WD_CELL_VERTICAL_ALIGNMENT.TOP,
        "start": WD_CELL_VERTICAL_ALIGNMENT.TOP,
        "center": WD_CELL_VERTICAL_ALIGNMENT.CENTER,
        "middle": WD_CELL_VERTICAL_ALIGNMENT.CENTER,
        "bottom": WD_CELL_VERTICAL_ALIGNMENT.BOTTOM,
        "end": WD_CELL_VERTICAL_ALIGNMENT.BOTTOM,
    }
    return m.get(s)


def _repeat_table_header_row(row: Any) -> None:
    """标记首行为表头行，分页时重复（OOXML w:tblHeader）。"""
    tr = row._tr
    tr_pr = tr.get_or_add_trPr()
    for child in list(tr_pr):
        if child.tag == qn("w:tblHeader"):
            tr_pr.remove(child)
    tr_pr.append(OxmlElement("w:tblHeader"))


def _set_cell_padding_pt(cell: Any, pt: float) -> None:
    """单元格内边距（四边相同），改善表格可读性；单位为 pt。"""
    if pt <= 0:
        return
    tw = str(int(Pt(pt).twips))
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.find(qn("w:tcMar"))
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for side in ("top", "left", "bottom", "right"):
        el = tc_mar.find(qn(f"w:{side}"))
        if el is None:
            el = OxmlElement(f"w:{side}")
            tc_mar.append(el)
        el.set(qn("w:w"), tw)
        el.set(qn("w:type"), "dxa")


def _set_document_update_fields_on_open(doc: Any) -> None:
    """打开文档时提示更新域（目录/页码等）；需在 Word 中确认，python-docx 无法计算页码。"""
    elt = doc.settings.element
    found = elt.find(qn("w:updateFields"))
    if found is None:
        found = OxmlElement("w:updateFields")
        elt.append(found)
    found.set(qn("w:val"), "true")


def _toc_field_instruction(
    *,
    min_level: int,
    max_level: int,
    hyperlinks: bool,
    hide_page_numbers_web: bool,
    use_outline_levels: bool,
) -> str:
    parts: list[str] = ["TOC", rf'\o "{min_level}-{max_level}"']
    if hyperlinks:
        parts.append(r"\h")
    if hide_page_numbers_web:
        parts.append(r"\z")
    if use_outline_levels:
        parts.append(r"\u")
    return " " + " ".join(parts) + " "


def _paragraph_add_toc_field(
    para: Any,
    instruction: str,
    placeholder: str,
) -> None:
    """插入 Word 目录域（复杂域：begin / instrText / separate / 占位 / end）。"""
    r1 = para.add_run()
    fc_b = OxmlElement("w:fldChar")
    fc_b.set(qn("w:fldCharType"), "begin")
    r1._r.append(fc_b)

    r2 = para.add_run()
    ix = OxmlElement("w:instrText")
    ix.set(qn("xml:space"), "preserve")
    ix.text = instruction
    r2._r.append(ix)

    r3 = para.add_run()
    fc_s = OxmlElement("w:fldChar")
    fc_s.set(qn("w:fldCharType"), "separate")
    r3._r.append(fc_s)

    r4 = para.add_run(placeholder or " ")

    r5 = para.add_run()
    fc_e = OxmlElement("w:fldChar")
    fc_e.set(qn("w:fldCharType"), "end")
    r5._r.append(fc_e)


def _apply_document_normal_base(
    doc: Any,
    *,
    east_asia: str | None,
    latin: str | None,
    body_pt: float,
    rgb: RGBColor | None,
) -> None:
    """新建文档时同步 Normal 样式，减少与显式 run 格式不一致的隐患。"""
    normal = doc.styles["Normal"]
    if east_asia:
        set_paragraph_style_east_asia_font(normal, east_asia, latin=latin)
    try:
        normal.font.size = Pt(body_pt)
    except (AttributeError, TypeError):
        pass
    if rgb is not None:
        try:
            normal.font.color.rgb = rgb
        except (AttributeError, TypeError):
            pass


def _heading_pt(level: int) -> float:
    return {1: 22.0, 2: 16.0, 3: 14.0, 4: 12.0, 5: 11.0, 6: 11.0}.get(
        max(1, min(9, level)), 11.0
    )


def _ensure_rfonts(rPr: Any) -> Any:
    el = rPr.find(qn("w:rFonts"))
    if el is None:
        el = OxmlElement("w:rFonts")
        rPr.insert(0, el)
    return el


def ensure_paragraph_style_rPr(style: Any) -> Any:
    """
    段落样式 ``style.element`` 上可能没有 ``w:rPr``（新建 ``Document()`` 的 **Normal** 常见），
    此时 ``style.element.rPr`` 为 ``None``，若再访问 ``.rFonts`` 会 **AttributeError**。
    本函数保证返回可用的 ``rPr`` 元素（供 ``_ensure_rfonts`` / 东亚字体等）。
    """
    se = style.element
    rPr = getattr(se, "rPr", None)
    if rPr is None:
        rPr = OxmlElement("w:rPr")
        se.append(rPr)
    return rPr


def set_paragraph_style_east_asia_font(
    style: Any,
    east_asia: str,
    *,
    latin: str | None = None,
) -> None:
    """在段落**样式**上设置 ``w:eastAsia``（含补全 ``w:rPr``），避免手写 ``.element.rPr.rFonts`` 踩空。"""
    ea = east_asia.strip()
    if not ea:
        return
    lat = (latin or "").strip() or None
    base = lat or ea
    rPr = ensure_paragraph_style_rPr(style)
    rf = _ensure_rfonts(rPr)
    rf.set(qn("w:ascii"), base)
    rf.set(qn("w:hAnsi"), base)
    rf.set(qn("w:eastAsia"), ea)
    rf.set(qn("w:cs"), ea)
    try:
        style.font.name = base
    except (AttributeError, TypeError):
        pass


def _apply_run_font(
    run: Any,
    *,
    east_asia: str | None,
    latin: str | None,
    size_pt: float | None,
    bold: bool | None,
    rgb: RGBColor | None,
) -> None:
    if east_asia or latin:
        base = latin or east_asia or "Calibri"
        run.font.name = base
        if east_asia:
            rPr = run._element.get_or_add_rPr()
            rf = _ensure_rfonts(rPr)
            rf.set(qn("w:ascii"), base)
            rf.set(qn("w:hAnsi"), base)
            rf.set(qn("w:eastAsia"), east_asia)
            rf.set(qn("w:cs"), east_asia)
    if size_pt is not None:
        run.font.size = Pt(size_pt)
    if bold is not None:
        run.font.bold = bold
    if rgb is not None:
        run.font.color.rgb = rgb


def _paragraph_add_lines_as_word_breaks(para: Any, text: str) -> None:
    """段内软换行（Word 中显示为 ↓，等同 Shift+Enter / ``w:br``）。仅当块级 **`soft_line_breaks`: true** 时使用。"""
    t = text.replace("\r\n", "\n").replace("\r", "\n")
    if "\n" not in t:
        if t:
            para.add_run(t)
        return
    parts = t.split("\n")
    para.add_run(parts[0])
    for part in parts[1:]:
        para.add_run().add_break(WD_BREAK.LINE)
        para.add_run(part)


def _paragraph_line_segments(text: str) -> list[str]:
    """
    将 ``\\n`` 拆成多个 **独立段落** 用的文本段；连续空行合并为单个空段；去掉首尾多余空行。
    默认用此策略写入 Word，避免出现大量「手动换行」箭头。
    """
    t = text.replace("\r\n", "\n").replace("\r", "\n")
    raw = t.split("\n")
    out: list[str] = []
    for seg in raw:
        if seg == "":
            if not out:
                continue
            if out[-1] == "":
                continue
            out.append("")
        else:
            out.append(seg)
    while out and out[-1] == "":
        out.pop()
    return out if out else [""]


def _heading_flatten_newlines(text: str) -> str:
    """标题内换行压成一行（空格分隔），避免标题里出现软换行箭头。"""
    t = text.replace("\r\n", "\n").replace("\r", "\n")
    return " ".join(s.strip() for s in t.split("\n") if s.strip())


def _block_soft_line_breaks(b: dict[str, Any]) -> bool:
    v = b.get("soft_line_breaks")
    if v is None:
        return False
    return bool(v)


def _apply_paragraph_spacing_multi(paras: list[Any], b: dict[str, Any]) -> None:
    """多段共享同一 ``space_*`` 时：段前距只加在第一段，段后距只在最后一段。"""
    n = len(paras)
    for j, para in enumerate(paras):
        adj = dict(b)
        if j > 0:
            adj["space_before_pt"] = None
        if j < n - 1:
            adj["space_after_pt"] = None
        _apply_paragraph_spacing(para, adj)


def _apply_paragraph_spacing(para: Any, b: dict[str, Any]) -> None:
    """段前/段后/行距（倍），用于精细排版。"""
    pf = para.paragraph_format
    sb = b.get("space_before_pt")
    if sb is not None:
        try:
            pf.space_before = Pt(float(sb))
        except (TypeError, ValueError):
            pass
    sa = b.get("space_after_pt")
    if sa is not None:
        try:
            pf.space_after = Pt(float(sa))
        except (TypeError, ValueError):
            pass
    ls = b.get("line_spacing")
    if ls is not None:
        try:
            f = float(ls)
            if 0.5 <= f <= 5.0:
                pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
                pf.line_spacing = f
        except (TypeError, ValueError):
            pass


def _format_paragraph(
    para: Any,
    *,
    east_asia: str | None,
    latin: str | None,
    size_pt: float | None,
    bold: bool | None,
    rgb: RGBColor | None,
    alignment: WD_ALIGN_PARAGRAPH | None,
) -> None:
    if alignment is not None:
        para.alignment = alignment
    if not para.runs:
        run = para.add_run("")
    else:
        run = None
    targets = list(para.runs) if para.runs else []
    if run is not None:
        targets = [run]
    for r in targets:
        _apply_run_font(
            r,
            east_asia=east_asia,
            latin=latin,
            size_pt=size_pt,
            bold=bold,
            rgb=rgb,
        )


@dataclass
class _DocDefaults:
    east_asia: str | None = None
    latin: str | None = None
    color: RGBColor | None = None
    body_pt: float = 10.5


_DOCX_TEMPLATE_SUFFIX = frozenset({".docx", ".dotx"})


def docx_compose(
    docx_path: Path,
    blocks: list[dict[str, Any]],
    *,
    policy_check: Callable[[Path], None],
    append: bool = False,
    template_path: Path | str | None = None,
    default_east_asia_font: str | None = None,
    default_latin_font: str | None = None,
    default_color_hex: str | None = None,
    default_body_font_pt: float | None = None,
    update_fields_on_open: bool | None = None,
) -> dict[str, Any]:
    """
    **模板**（可选）：``template_path`` 为现有 **.docx** / **.dotx** 时，在**非 append 到已有输出文件**
    的情况下用 ``python-docx.Document(template)`` 打开，**保留**样式、页面设置、页眉页脚等；``blocks`` 追加在模板正文末尾。
    此时**不**调用文档级 ``Normal`` 基底改写（避免覆盖模板正文默认样式）；块级 ``default_*`` 仍作用于**新写入**的 run。
    **append**=**true** 且输出已存在时，始终打开输出文件，**忽略** ``template_path``（结果中 ``template_ignored_because_append`` 为 **true**）。

    ``blocks`` 元素 ``type``:

    - ``heading``: ``text``, ``level`` (1–9)；可选 ``soft_line_breaks``（默认 **false**：标题内 ``\\n`` 压成一行；
      **true** 时保留 **Shift+Enter** 式段内换行）、``font_size_pt``、``bold``、``center``、
      ``alignment`` (left|center|right|justify)、``east_asia_font``、``latin_font``、``color_hex``、
      ``space_before_pt``、``space_after_pt``、``line_spacing``（行距倍数 **0.5–5**）
    - ``paragraph``: ``text``；可选 ``soft_line_breaks``（默认 **false**：``\\n`` 拆成多个 **Enter** 段落；
      **true** 时用 **w:br**）、``center``、``alignment``、``font_size_pt``、``bold``、
      ``east_asia_font``、``latin_font``、``color_hex``、``space_before_pt``、``space_after_pt``、
      ``line_spacing``
    - ``table``: ``rows`` 为二维字符串数组（矩形）；可选 ``header_row``、``table_style``、``caption``、
      ``header_font_size_pt`` / ``body_font_size_pt``、``header_cell_alignment`` / ``body_cell_alignment``、
      ``header_vertical_alignment`` / ``body_vertical_alignment``（top|center|middle|bottom）、
      ``table_alignment``（整表相对页边 left|center|right）、
      ``allow_autofit``（默认在提供 ``column_width_cm`` 任一列宽时自动 ``false`` 以稳定列宽）、
      ``repeat_header_row``（默认与 ``header_row`` 相同：分页重复表头）、
      ``cell_margin_pt``（单元格内边距）、``cell_space_before_pt`` / ``cell_space_after_pt`` / ``cell_line_spacing``（单元格段间距）、
      ``column_width_cm``（与列数一致的列表）、``cell_styles``（与 ``rows`` 同形的二维数组，每项可为
      ``{font_size_pt, bold, color_hex, east_asia_font, alignment}`` 之一或组合）；
      可选 ``soft_line_breaks``：表内单元格与 ``caption`` 的换行策略（默认 **false** = 真实段落）
    - ``image``: ``path``；可选 ``width_cm``、``caption``、``soft_line_breaks``（**caption** 内换行，默认 **false**）
    - ``toc`` / ``table_of_contents``：**Word 目录域**（依赖正文中的 **标题 1…N** / ``add_heading`` 样式，与对话框「来自模板」一致由模板决定 TOC 外观）。
      默认 ``min_level``=**1**、``max_level``=**3**（域开关 ``\\o "1-3"``，与常见 3 级目录 POC 一致）；可选 ``hyperlinks``（默认 **true**，``\\h``）、
      ``hide_page_numbers_web``（默认 **true**，``\\z``）、``use_outline_levels``（默认 **true**，``\\u``）。
      可选 ``caption`` + ``caption_heading_level``（**1–9**：目录标题用 ``heading``；省略则 ``caption`` 为居中正文）。
      ``placeholder``：域未更新时的占位文字；``update_fields_on_open``：是否在本块要求保存 **打开时更新域**（默认 **true**）。
      **摆放顺序**：目录应出现在**其要收录的标题之前**——把 ``toc`` 块放在 ``blocks`` 里封面/概述之后、**第一章标题之前**；若用 ``append`` 分多次写入，最后一次在成章节后**再** ``append`` 一次仅含 ``toc`` **无法**插入到文首，需首轮就排好顺序或整篇一次 ``docx_compose``。
      **页码**：python-docx 不能替你算页码；保存后首次用 **Word 打开**会按 **设置→更新域** 提示刷新（本工具可选写入 ``w:updateFields``）；也可用 **Ctrl+A → F9** 更新。
    - ``page_break``: 分页

    文档级 ``update_fields_on_open``：**None** 时，若存在任一 **toc** 块且未将该块 ``update_fields_on_open`` 设为 **false**，则保存前写入 **打开时更新域**；**true**/**false** 为全局强制开/关。

    文档级默认（中文正文推荐）：传入 ``default_east_asia_font='宋体'`` 与 ``default_color_hex='000000'``，
    会为标题/段落/表格单元格设置 **w:eastAsia**（东亚字体）及颜色；比手写 ``script_run`` 更可靠。

    **换行（默认）**：``\\n`` / ``\\r\\n`` 会拆成多个 **Word 段落**（回车），避免满篇 **↓** 软换行。
    需要旧版 **Shift+Enter**（``w:br``）时在对应块上设 **`soft_line_breaks`: true**。
    """
    path = docx_path.expanduser().resolve()
    policy_check(path)
    if path.suffix.lower() != ".docx":
        return {"ok": False, "error": "path must end with .docx"}

    nb, err = _norm_blocks(blocks)
    if err:
        return {"ok": False, "error": err}
    assert nb is not None

    ea = (default_east_asia_font or "").strip() or None
    lat = (default_latin_font or "").strip() or None
    ch = (default_color_hex or "").strip() or None
    rgb_d = _hex_rgb(ch) if ch else None
    body_pt = float(default_body_font_pt) if default_body_font_pt is not None else 10.5
    body_pt = max(6.0, min(72.0, body_pt))
    defaults = _DocDefaults(
        east_asia=ea, latin=lat, color=rgb_d, body_pt=body_pt
    )

    path.parent.mkdir(parents=True, exist_ok=True)
    opened_existing = append and path.is_file()

    tpl_resolved: Path | None = None
    if template_path is not None and str(template_path).strip():
        tp = Path(str(template_path)).expanduser().resolve()
        policy_check(tp)
        if not tp.is_file():
            return {"ok": False, "error": "template_path must be an existing file"}
        if tp.suffix.lower() not in _DOCX_TEMPLATE_SUFFIX:
            return {
                "ok": False,
                "error": "template_path must be .docx or .dotx",
            }
        tpl_resolved = tp

    template_ignored_because_append = bool(
        tpl_resolved is not None and opened_existing
    )
    from_template = False
    if opened_existing:
        doc = Document(str(path))
    elif tpl_resolved is not None:
        doc = Document(str(tpl_resolved))
        from_template = True
    else:
        doc = Document()

    images_added = 0
    tables_added = 0
    toc_added = 0
    toc_default_update_on_open = False

    if not opened_existing and not from_template:
        _apply_document_normal_base(
            doc,
            east_asia=ea,
            latin=lat,
            body_pt=body_pt,
            rgb=rgb_d,
        )

    def _blk_str(b: dict[str, Any], key: str, default: str | None = None) -> str | None:
        v = b.get(key)
        if v is None:
            return default
        s = str(v).strip()
        return s if s else default

    for i, b in enumerate(nb):
        t = str(b.get("type") or "").strip().lower()
        if t == "heading":
            lvl = int(b.get("level", 1))
            lvl = max(1, min(9, lvl))
            h_soft = _block_soft_line_breaks(b)
            h_raw = str(b.get("text") or "")
            para = doc.add_heading("", level=lvl)
            if h_soft:
                _paragraph_add_lines_as_word_breaks(para, h_raw)
            else:
                hf = _heading_flatten_newlines(h_raw)
                if hf:
                    para.add_run(hf)
            fs = b.get("font_size_pt")
            size_pt = float(fs) if fs is not None else _heading_pt(lvl)
            size_pt = max(6.0, min(72.0, size_pt))
            bold = b.get("bold")
            if bold is None:
                bold = True
            else:
                bold = bool(bold)
            ea_b = _blk_str(b, "east_asia_font") or defaults.east_asia
            lat_b = _blk_str(b, "latin_font") or defaults.latin
            ch_b = _blk_str(b, "color_hex")
            rgb = _hex_rgb(ch_b) if ch_b else defaults.color
            al = None
            if bool(b.get("center")):
                al = WD_ALIGN_PARAGRAPH.CENTER
            if al is None:
                al = _parse_alignment(b.get("alignment"))
            _format_paragraph(
                para,
                east_asia=ea_b,
                latin=lat_b,
                size_pt=size_pt,
                bold=bold,
                rgb=rgb,
                alignment=al,
            )
            _apply_paragraph_spacing(para, b)
        elif t == "paragraph":
            pr_soft = _block_soft_line_breaks(b)
            p_raw = str(b.get("text") or "")
            fs = b.get("font_size_pt")
            size_pt = float(fs) if fs is not None else defaults.body_pt
            size_pt = max(6.0, min(72.0, size_pt))
            bold_v = b.get("bold")
            bold = bool(bold_v) if bold_v is not None else False
            ea_b = _blk_str(b, "east_asia_font") or defaults.east_asia
            lat_b = _blk_str(b, "latin_font") or defaults.latin
            ch_b = _blk_str(b, "color_hex")
            rgb = _hex_rgb(ch_b) if ch_b else defaults.color
            al = None
            if bool(b.get("center")):
                al = WD_ALIGN_PARAGRAPH.CENTER
            if al is None:
                al = _parse_alignment(b.get("alignment"))
            if al is None and defaults.east_asia:
                al = WD_ALIGN_PARAGRAPH.JUSTIFY
            if pr_soft:
                para = doc.add_paragraph()
                _paragraph_add_lines_as_word_breaks(para, p_raw)
                paras_px = [para]
            else:
                segments = _paragraph_line_segments(p_raw)
                paras_px = []
                for seg in segments:
                    para = doc.add_paragraph()
                    if seg:
                        para.add_run(seg)
                    paras_px.append(para)
            for para in paras_px:
                _format_paragraph(
                    para,
                    east_asia=ea_b,
                    latin=lat_b,
                    size_pt=size_pt,
                    bold=bold,
                    rgb=rgb,
                    alignment=al,
                )
            _apply_paragraph_spacing_multi(paras_px, b)
        elif t == "page_break":
            doc.add_page_break()
        elif t == "table":
            raw_rows = b.get("rows")
            if not isinstance(raw_rows, list) or not raw_rows:
                return {
                    "ok": False,
                    "error": (
                        f"blocks[{i}]: table.rows must be a non-empty array of row arrays; "
                        "remove the table block or add at least one data row"
                    ),
                }
            rows_norm: list[list[str]] = []
            for ri, row in enumerate(raw_rows):
                if not isinstance(row, (list, tuple)):
                    return {
                        "ok": False,
                        "error": f"blocks[{i}]: table.rows[{ri}] must be array",
                    }
                rows_norm.append([str(c) for c in row])
            nrows = len(rows_norm)
            ncols = len(rows_norm[0])
            if nrows > MAX_TABLE_ROWS or ncols > MAX_TABLE_COLS or ncols < 1:
                return {
                    "ok": False,
                    "error": f"blocks[{i}]: table size {nrows}x{ncols} out of range",
                }
            for ri, row in enumerate(rows_norm):
                if len(row) != ncols:
                    return {
                        "ok": False,
                        "error": f"blocks[{i}]: ragged row at index {ri}",
                    }
                for ci, cell in enumerate(row):
                    if len(cell) > MAX_CELL_CHARS:
                        return {
                            "ok": False,
                            "error": f"blocks[{i}]: cell too long at ({ri},{ci})",
                        }
            style_name = _blk_str(b, "table_style") or "Table Grid"
            tbl = doc.add_table(rows=nrows, cols=ncols)
            try:
                tbl.style = style_name
            except (ValueError, KeyError):
                tbl.style = "Table Grid"
            colw = b.get("column_width_cm")
            has_fixed_widths = False
            if isinstance(colw, list):
                for wcm in colw:
                    if wcm is None:
                        continue
                    try:
                        if float(wcm) > 0:
                            has_fixed_widths = True
                            break
                    except (TypeError, ValueError):
                        continue
            af_raw = b.get("allow_autofit")
            if af_raw is None:
                tbl.autofit = not has_fixed_widths
            else:
                tbl.autofit = bool(af_raw)
            ta_tbl = _parse_table_alignment(b.get("table_alignment"))
            if ta_tbl is not None:
                tbl.alignment = ta_tbl
            header_row = bool(b.get("header_row", False))
            rh = b.get("repeat_header_row")
            repeat_hdr = header_row if rh is None else bool(rh)
            tbl_soft = _block_soft_line_breaks(b)
            ch_tb = _blk_str(b, "color_hex")
            rgb_tbl = _hex_rgb(ch_tb) if ch_tb else defaults.color
            ea_tbl = _blk_str(b, "east_asia_font") or defaults.east_asia
            lat_tbl = _blk_str(b, "latin_font") or defaults.latin
            h_fs = b.get("header_font_size_pt")
            b_fs = b.get("body_font_size_pt")
            header_font_pt: float | None = None
            body_font_pt: float | None = None
            if h_fs is not None:
                try:
                    header_font_pt = float(h_fs)
                    header_font_pt = max(6.0, min(72.0, header_font_pt))
                except (TypeError, ValueError):
                    header_font_pt = None
            if b_fs is not None:
                try:
                    body_font_pt = float(b_fs)
                    body_font_pt = max(6.0, min(72.0, body_font_pt))
                except (TypeError, ValueError):
                    body_font_pt = None
            ha_tbl = _parse_alignment(b.get("header_cell_alignment"))
            ba_tbl = _parse_alignment(b.get("body_cell_alignment"))
            hv_tbl = _parse_vertical_alignment(b.get("header_vertical_alignment"))
            bv_tbl = _parse_vertical_alignment(b.get("body_vertical_alignment"))
            cmargin = b.get("cell_margin_pt")
            cell_margin_pt: float | None = None
            if cmargin is not None:
                try:
                    cell_margin_pt = max(0.0, min(72.0, float(cmargin)))
                except (TypeError, ValueError):
                    cell_margin_pt = None
            cell_pf_keys = {
                "space_before_pt": b.get("cell_space_before_pt"),
                "space_after_pt": b.get("cell_space_after_pt"),
                "line_spacing": b.get("cell_line_spacing"),
            }
            css = b.get("cell_styles")
            if css is not None:
                if not isinstance(css, list) or len(css) != nrows:
                    return {
                        "ok": False,
                        "error": f"blocks[{i}]: cell_styles must be list with same length as rows",
                    }
                for ri2, row2 in enumerate(css):
                    if not isinstance(row2, list) or len(row2) != ncols:
                        return {
                            "ok": False,
                            "error": f"blocks[{i}]: cell_styles[{ri2}] width must match table columns",
                        }
                    for ci2, cobj in enumerate(row2):
                        if cobj is not None and not isinstance(cobj, dict):
                            return {
                                "ok": False,
                                "error": f"blocks[{i}]: cell_styles[{ri2}][{ci2}] must be object or null",
                            }
            for ri, row_data in enumerate(rows_norm):
                row_cells = tbl.rows[ri].cells
                is_header = header_row and ri == 0
                for ci, text in enumerate(row_data):
                    cell = row_cells[ci]
                    cell.text = ""
                    if tbl_soft:
                        cp0 = cell.paragraphs[0]
                        _paragraph_add_lines_as_word_breaks(cp0, text)
                        cell_paras = [cp0]
                    else:
                        segs = _paragraph_line_segments(text)
                        cell_paras = []
                        for si, seg in enumerate(segs):
                            if si == 0:
                                cp0 = cell.paragraphs[0]
                            else:
                                cp0 = cell.add_paragraph()
                            if seg:
                                cp0.add_run(seg)
                            cell_paras.append(cp0)
                    cel_ov: dict[str, Any] | None = None
                    if isinstance(css, list) and ri < len(css):
                        row_ov = css[ri]
                        if isinstance(row_ov, list) and ci < len(row_ov):
                            raw_ov = row_ov[ci]
                            cel_ov = raw_ov if isinstance(raw_ov, dict) else None
                    base_ea = _blk_str(cel_ov, "east_asia_font") if cel_ov else None
                    base_ea = base_ea or ea_tbl
                    base_lat = _blk_str(cel_ov, "latin_font") if cel_ov else None
                    base_lat = base_lat or lat_tbl
                    ch_c = _blk_str(cel_ov, "color_hex") if cel_ov else None
                    rgb_c = _hex_rgb(ch_c) if ch_c else rgb_tbl
                    if is_header:
                        size_u = header_font_pt if header_font_pt is not None else defaults.body_pt
                    else:
                        size_u = body_font_pt if body_font_pt is not None else defaults.body_pt
                    if cel_ov and cel_ov.get("font_size_pt") is not None:
                        try:
                            size_u = float(cel_ov["font_size_pt"])
                            size_u = max(6.0, min(72.0, size_u))
                        except (TypeError, ValueError):
                            pass
                    bold_cell = True if is_header else False
                    if cel_ov and cel_ov.get("bold") is not None:
                        bold_cell = bool(cel_ov["bold"])
                    elif not is_header:
                        bold_cell = False
                    al_cell = ha_tbl if is_header else ba_tbl
                    if cel_ov:
                        al_o = _parse_alignment(cel_ov.get("alignment"))
                        if al_o is not None:
                            al_cell = al_o
                    if al_cell is None:
                        al_cell = (
                            WD_ALIGN_PARAGRAPH.CENTER
                            if is_header
                            else WD_ALIGN_PARAGRAPH.LEFT
                        )
                    for cp in cell_paras:
                        _format_paragraph(
                            cp,
                            east_asia=base_ea,
                            latin=base_lat,
                            size_pt=size_u,
                            bold=bold_cell,
                            rgb=rgb_c,
                            alignment=al_cell,
                        )
                    _apply_paragraph_spacing_multi(cell_paras, cell_pf_keys)
                    v_al = hv_tbl if is_header else bv_tbl
                    if v_al is not None:
                        cell.vertical_alignment = v_al
                    if cell_margin_pt:
                        _set_cell_padding_pt(cell, cell_margin_pt)
            if repeat_hdr and header_row and nrows > 0:
                _repeat_table_header_row(tbl.rows[0])
            if isinstance(colw, list) and colw:
                for ci3, wcm in enumerate(colw):
                    if ci3 >= ncols or wcm is None:
                        continue
                    try:
                        tbl.columns[ci3].width = Cm(float(wcm))
                    except (TypeError, ValueError):
                        pass
            cap = b.get("caption")
            if cap:
                cap_raw = str(cap)
                if tbl_soft:
                    cap_p = doc.add_paragraph()
                    _paragraph_add_lines_as_word_breaks(cap_p, cap_raw)
                    cap_paras = [cap_p]
                else:
                    cap_paras = []
                    for seg in _paragraph_line_segments(cap_raw):
                        cap_p = doc.add_paragraph()
                        if seg:
                            cap_p.add_run(seg)
                        cap_paras.append(cap_p)
                for cap_p in cap_paras:
                    _format_paragraph(
                        cap_p,
                        east_asia=defaults.east_asia,
                        latin=defaults.latin,
                        size_pt=defaults.body_pt,
                        bold=False,
                        rgb=defaults.color,
                        alignment=WD_ALIGN_PARAGRAPH.CENTER,
                    )
            tables_added += 1
        elif t == "image":
            ip = Path(str(b.get("path") or "")).expanduser().resolve()
            policy_check(ip)
            if not ip.is_file():
                return {"ok": False, "error": f"image not found: {ip}"}
            sz = ip.stat().st_size
            if sz > MAX_IMAGE_BYTES:
                return {
                    "ok": False,
                    "error": f"image too large ({sz} bytes > {MAX_IMAGE_BYTES})",
                }
            # 默认可打印宽约 17cm；过高图按版心高度同比缩小（与 markdown_to_pdf / pdf_compose 策略一致）
            w_req = float(b.get("width_cm", 17.0))
            w_req = max(3.0, min(19.5, w_req))
            max_h_cm = float(b.get("max_height_cm", 24.7))
            max_h_cm = max(6.0, min(27.0, max_h_cm))
            sz_px = read_raster_pixel_size(ip)
            if sz_px:
                iw, ih = sz_px
                w_cm, h_cm = fit_display_cm(
                    iw, ih, max_width_cm=w_req, max_height_cm=max_h_cm
                )
                doc.add_picture(str(ip), width=Cm(w_cm), height=Cm(h_cm))
            else:
                doc.add_picture(str(ip), width=Cm(w_req))
            cap = b.get("caption")
            if cap:
                img_soft = _block_soft_line_breaks(b)
                cap_raw = str(cap)
                if img_soft:
                    p = doc.add_paragraph()
                    _paragraph_add_lines_as_word_breaks(p, cap_raw)
                    cap_ps = [p]
                else:
                    cap_ps = []
                    for seg in _paragraph_line_segments(cap_raw):
                        p = doc.add_paragraph()
                        if seg:
                            p.add_run(seg)
                        cap_ps.append(p)
                for p in cap_ps:
                    _format_paragraph(
                        p,
                        east_asia=defaults.east_asia,
                        latin=defaults.latin,
                        size_pt=defaults.body_pt,
                        bold=False,
                        rgb=defaults.color,
                        alignment=WD_ALIGN_PARAGRAPH.CENTER,
                    )
            images_added += 1
        elif t in ("toc", "table_of_contents"):
            mn = b.get("min_level", 1)
            mx = b.get("max_level", 3)
            try:
                min_lv = int(mn)
                max_lv = int(mx)
            except (TypeError, ValueError):
                return {
                    "ok": False,
                    "error": f"blocks[{i}]: toc min_level/max_level must be integers",
                }
            if min_lv < 1 or max_lv > 9 or min_lv > max_lv:
                return {
                    "ok": False,
                    "error": f"blocks[{i}]: toc levels must satisfy 1 <= min_level <= max_level <= 9",
                }
            hy = b.get("hyperlinks")
            hyperlinks = True if hy is None else bool(hy)
            hz = b.get("hide_page_numbers_web")
            hide_web = True if hz is None else bool(hz)
            uo = b.get("use_outline_levels")
            use_ol = True if uo is None else bool(uo)
            uf_blk = b.get("update_fields_on_open")
            if uf_blk is None or bool(uf_blk):
                toc_default_update_on_open = True
            cap = b.get("caption")
            chl = b.get("caption_heading_level")
            if cap is not None and str(cap).strip():
                cap_s = str(cap).strip()
                ch_lvl: int | None = None
                if chl is not None:
                    try:
                        ch_lvl = int(chl)
                    except (TypeError, ValueError):
                        ch_lvl = None
                    if ch_lvl is not None:
                        ch_lvl = max(1, min(9, ch_lvl))
                if ch_lvl is not None:
                    hp = doc.add_heading("", level=ch_lvl)
                    hp.add_run(cap_s)
                    _format_paragraph(
                        hp,
                        east_asia=_blk_str(b, "east_asia_font") or defaults.east_asia,
                        latin=_blk_str(b, "latin_font") or defaults.latin,
                        size_pt=float(
                            b.get("caption_font_size_pt")
                            or _heading_pt(ch_lvl)
                        ),
                        bold=bool(b.get("caption_bold", True)),
                        rgb=_hex_rgb(str(b.get("caption_color_hex") or ""))
                        if b.get("caption_color_hex")
                        else defaults.color,
                        alignment=WD_ALIGN_PARAGRAPH.CENTER
                        if bool(b.get("caption_center", True))
                        else _parse_alignment(b.get("caption_alignment")),
                    )
                else:
                    cp = doc.add_paragraph()
                    cp.add_run(cap_s)
                    cal = WD_ALIGN_PARAGRAPH.CENTER if bool(b.get("caption_center", True)) else None
                    if cal is None:
                        cal = _parse_alignment(b.get("caption_alignment"))
                    _format_paragraph(
                        cp,
                        east_asia=_blk_str(b, "east_asia_font") or defaults.east_asia,
                        latin=_blk_str(b, "latin_font") or defaults.latin,
                        size_pt=float(b.get("caption_font_size_pt") or defaults.body_pt),
                        bold=bool(b.get("caption_bold", True)),
                        rgb=_hex_rgb(str(b.get("caption_color_hex") or ""))
                        if b.get("caption_color_hex")
                        else defaults.color,
                        alignment=cal,
                    )
                    _apply_paragraph_spacing(cp, b)
            instr = _toc_field_instruction(
                min_level=min_lv,
                max_level=max_lv,
                hyperlinks=hyperlinks,
                hide_page_numbers_web=hide_web,
                use_outline_levels=use_ol,
            )
            ph = _blk_str(b, "placeholder")
            if not ph:
                ph = "（请更新目录域：在 Word 中打开后按提示更新域，或 Ctrl+A 再 F9）"
            tp = doc.add_paragraph()
            _paragraph_add_toc_field(tp, instr, ph)
            if defaults.east_asia or defaults.latin or defaults.color:
                _format_paragraph(
                    tp,
                    east_asia=defaults.east_asia,
                    latin=defaults.latin,
                    size_pt=defaults.body_pt,
                    bold=False,
                    rgb=defaults.color,
                    alignment=_parse_alignment(b.get("alignment")) or WD_ALIGN_PARAGRAPH.LEFT,
                )
            note = b.get("note_after")
            if note is not None and str(note).strip():
                np = doc.add_paragraph(str(note).strip())
                _format_paragraph(
                    np,
                    east_asia=defaults.east_asia,
                    latin=defaults.latin,
                    size_pt=max(6.0, defaults.body_pt - 1.0),
                    bold=False,
                    rgb=defaults.color,
                    alignment=WD_ALIGN_PARAGRAPH.LEFT,
                )
            toc_added += 1
        else:
            return {"ok": False, "error": f"blocks[{i}]: unknown type {t!r}"}

    uf_save = update_fields_on_open
    if uf_save is None:
        uf_save = toc_added > 0 and toc_default_update_on_open
    if uf_save:
        _set_document_update_fields_on_open(doc)

    doc.save(str(path))
    return {
        "ok": True,
        "path": str(path),
        "append_mode": append,
        "opened_existing": opened_existing,
        "from_template": from_template,
        "template_source": str(tpl_resolved) if tpl_resolved is not None else None,
        "template_ignored_because_append": template_ignored_because_append,
        "blocks_applied": len(nb),
        "images_added": images_added,
        "tables_added": tables_added,
        "toc_inserted": toc_added,
        "update_fields_on_open": bool(uf_save),
        "defaults_applied": bool(ea or lat or rgb_d),
    }
