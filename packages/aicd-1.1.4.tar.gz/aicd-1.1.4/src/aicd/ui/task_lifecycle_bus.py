"""主会话收件箱 lifecycle 总线事件：顶层与嵌套子任务投递的 **task_message** 均以 **main-inbox-<session>** 为 **task_id**。"""

from __future__ import annotations

from typing import Any

from aicd.tasks.main_inbox import main_inbox_id


def bus_event_is_main_session_lifecycle(
    ev: dict[str, Any], *, chat_session_id: str
) -> bool:
    """``task`` / ``task_message`` / ``lifecycle`` 且 ``task_id`` 为 ``main-inbox-<session>``。"""
    if ev.get("topic") != "task" or ev.get("event") != "task_message":
        return False
    if str(ev.get("kind") or "") != "lifecycle":
        return False
    tid = ev.get("task_id")
    if not isinstance(tid, str):
        return False
    try:
        return tid == main_inbox_id(chat_session_id)
    except ValueError:
        return False
