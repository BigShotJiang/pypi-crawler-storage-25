"""Textual Linux：stdin 出现非 UTF-8 字节时，strict 解码会抛 UnicodeDecodeError 并拖垮输入线程。

将 ``linux_driver`` / ``linux_inline_driver`` 模块内的 ``getincrementaldecoder("utf-8")`` 替换为
默认 ``errors="replace"`` 的增量解码器，避免 TUI 在子任务跑 nmap 等时因 stdin 混入杂字节而崩溃。

在 ``app.py`` 创建 ``AicdTui`` **之前**调用 :func:`apply_textual_linux_stdin_utf8_replace`。
"""

from __future__ import annotations

import sys


def apply_textual_linux_stdin_utf8_replace() -> None:
    if sys.platform == "win32":
        return
    try:
        from codecs import getincrementaldecoder as _orig_gid
    except ImportError:
        return
    try:
        orig_utf8_cls = _orig_gid("utf-8")
    except Exception:
        return

    class _Utf8IncrementalDecoder(orig_utf8_cls):
        def __init__(self, errors: str = "replace") -> None:
            super().__init__(errors=errors)

    def _patched_getincrementaldecoder(encoding: str):
        if encoding == "utf-8":
            return _Utf8IncrementalDecoder
        return _orig_gid(encoding)

    for mod_name in (
        "textual.drivers.linux_driver",
        "textual.drivers.linux_inline_driver",
    ):
        try:
            mod = __import__(mod_name, fromlist=["*"])
        except Exception:
            continue
        if getattr(mod, "_aicd_patched_utf8_replace", False):
            continue
        mod.getincrementaldecoder = _patched_getincrementaldecoder  # type: ignore[assignment]
        setattr(mod, "_aicd_patched_utf8_replace", True)
