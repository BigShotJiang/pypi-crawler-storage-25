"""从 DB 覆盖与插件片段组装提示文本。"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aicd.agent.prompt_blocks.builtin_text import AGENT_KIND_BUILTINS, WORK_MODE_BUILTINS

if TYPE_CHECKING:
    from aicd.plugins.registry import PluginRegistry


def _plugin_mode_append(
    reg: Any | None,
    mode: str,
) -> str:
    if reg is None:
        return ""
    fn = getattr(reg, "work_mode_prompt_for", None)
    if callable(fn):
        return str(fn(mode) or "").strip()
    return ""


def _plugin_kind_append(
    reg: Any | None,
    kind: str,
) -> str:
    if reg is None:
        return ""
    fn = getattr(reg, "agent_kind_prompt_for", None)
    if callable(fn):
        return str(fn(kind) or "").strip()
    return ""


def work_mode_prompt_text(
    mode: str,
    *,
    db_content: str | None = None,
    plugin_registry: PluginRegistry | None = None,
) -> str:
    """主对话或子 Agent 的 work_mode 片段（非空则拼接）。"""
    m = (mode or "").strip().lower() or "general"
    parts: list[str] = []
    if db_content and str(db_content).strip():
        parts.append(str(db_content).strip())
    else:
        base = WORK_MODE_BUILTINS.get(m)
        if base:
            parts.append(base)
    plug = _plugin_mode_append(plugin_registry, m)
    if plug:
        parts.append(plug)
    return "\n\n".join(parts).strip()


def agent_kind_prompt_text(
    kind: str,
    *,
    db_content: str | None = None,
    plugin_registry: PluginRegistry | None = None,
) -> str:
    """子 Agent 的 agent_kind 片段。"""
    k = (kind or "").strip().lower() or "coder"
    parts: list[str] = []
    if db_content and str(db_content).strip():
        parts.append(str(db_content).strip())
    else:
        base = AGENT_KIND_BUILTINS.get(k)
        if base:
            parts.append(base)
    plug = _plugin_kind_append(plugin_registry, k)
    if plug:
        parts.append(plug)
    return "\n\n".join(parts).strip()
