"""模块化提示：工作模式与 Agent 类型块（与主系统提示组合使用）。"""

from __future__ import annotations

from aicd.agent.prompt_blocks.builtin_text import (
    AGENT_KIND_BUILTINS,
    WORK_MODE_BUILTINS,
)
from aicd.agent.prompt_blocks.compose import (
    agent_kind_prompt_text,
    work_mode_prompt_text,
)

CANONICAL_WORK_MODES: frozenset[str] = frozenset(WORK_MODE_BUILTINS.keys())
DEFAULT_WORK_MODE = "general"

CANONICAL_AGENT_KINDS: frozenset[str] = frozenset(AGENT_KIND_BUILTINS.keys())
DEFAULT_AGENT_KIND = "coder"

__all__ = [
    "AGENT_KIND_BUILTINS",
    "WORK_MODE_BUILTINS",
    "CANONICAL_AGENT_KINDS",
    "CANONICAL_WORK_MODES",
    "DEFAULT_AGENT_KIND",
    "DEFAULT_WORK_MODE",
    "agent_kind_prompt_text",
    "work_mode_prompt_text",
]
