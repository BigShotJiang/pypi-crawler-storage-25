"""主对话与子 Agent 的「无用户输入」定时唤醒文案（TUI 心跳 / 子任务协调）。"""

from __future__ import annotations

# 与 TUI 侧识别一致：勿改前缀，否则 _chat_pump_loop 无法标记系统行
MAIN_IDLE_PULSE_PREFIX = "（Aicd·主对话·定时心跳）"
MAIN_LIFECYCLE_WAKEUP_PREFIX = "（Aicd·主对话·子任务终态）"

# TUI / Tk GUI 在注入接续回合前写入聊天的同一行提示（嵌套失败/取消经主收件箱 lifecycle 时同样走此路径）
MAIN_LIFECYCLE_UI_LOG_LINE = (
    "[系统] 子任务已至终态（含嵌套失败/取消），主对话接续处理主收件箱…"
)


def is_main_idle_pulse(user_text: str) -> bool:
    return user_text.lstrip().startswith(MAIN_IDLE_PULSE_PREFIX)


def is_main_lifecycle_wakeup(user_text: str) -> bool:
    return user_text.lstrip().startswith(MAIN_LIFECYCLE_WAKEUP_PREFIX)


def main_idle_pulse_user_text() -> str:
    # 刻意简短：协调状态应由 task_* 工具读取，避免长段心跳反复占满上下文（参见系统提示 AGENT_IDLE_LOOP_DIRECTIVES）。
    return (
        MAIN_IDLE_PULSE_PREFIX
        + " 无新真人输入。**task_main_inbox** / **task_session_children_digest** → **task_list** / **task_result** / **task_thread_stats**；"
        "嵌套子任务 **failed/cancelled** 也会经主收件箱 **lifecycle**（含 **scope=nested_terminal**）。"
        "汇报具体 **task_id** 进度前须以工具为准：**failed/cancelled** 时不得继续声称「仍在第 N 轮跑」；可 **task_cancel** / **task_message_send**。"
        "间隔 **`agent.idleHeartbeatSec`**。无事回 **·**。"
    )


def main_lifecycle_wakeup_user_text() -> str:
    """顶层或嵌套子任务终态后由 TUI 注入，驱动主对话读主收件箱并接续。"""
    return (
        MAIN_LIFECYCLE_WAKEUP_PREFIX
        + " **lifecycle** 已入收件箱（含 **scope=nested_terminal** 的嵌套 **failed/cancelled**；运行时亦有 **【主收件箱】**）。"
        "**task_main_inbox** / **task_list** / **task_result** → 核对 **failed** 勿当作 **running**；可回 **·**。"
    )


def sub_agent_idle_pulse_user_text() -> str:
    return (
        "（Aicd·子 Agent·定时心跳）收件箱空但有 **running/pending** 子任务：**task_list**（**parent_id**=你的 **task_id**）→ **task_result**；"
        "同步上级：**task_result** 自取 **parent_id** 后 **task_message_send**（**status**/**question**/**alert**）。"
        "**task_progress** 保活。失败可 **task_cancel** / 拆 **task_ai**。无事 **·**。"
    )
