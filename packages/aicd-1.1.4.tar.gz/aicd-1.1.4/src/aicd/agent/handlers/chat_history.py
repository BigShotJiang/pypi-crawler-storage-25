from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Any

from aicd.home import new_chat_session_id

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


def _require_session(router: ToolRouter) -> str | None:
    sid = getattr(router, "_chat_session_id", None)
    return sid if sid else None


async def _chat_new_session(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    del args
    if router._chat_session_id is None:
        return {"ok": False, "error": "chat_new_session only available on main agent"}
    b = getattr(router, "_interactive_bucket", None)
    if b is not None and hasattr(b, "cleanup_all"):
        await b.cleanup_all(reason="chat_new_session")
    new_sid = new_chat_session_id(router._layout["data"])
    router.set_chat_session_id(new_sid)
    switch = getattr(router, "_chat_session_switch", None)
    if switch:
        switch(new_sid)
    return {
        "ok": True,
        "session_id": new_sid,
        "in_memory_context_cleared": True,
        "note": "Earlier turns stay in SQLite under the old session_id; new messages use the new session_id.",
    }


async def _chat_session_info(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    del args
    sid = _require_session(router)
    if not sid:
        return {"ok": False, "error": "chat history only available on main agent session"}
    store = router._tasks.store
    conn = router._tasks.db_conn
    n = await store.count_chat_messages(conn, sid)
    sn = await store.count_chat_summaries(conn, sid)
    cfg = router._cfg.agent
    meta = router.model_context_meta()
    cap = router.context_adaptive_params()
    return {
        "ok": True,
        "session_id": sid,
        "message_count": n,
        "summary_count": sn,
        "context_budget_tokens": meta.get(
            "context_budget_tokens_effective", cfg.context_budget_tokens
        ),
        "context_budget_tokens_configured": meta.get(
            "context_budget_tokens_configured", cfg.context_budget_tokens
        ),
        "model_context_window_tokens": meta.get("model_context_window_tokens"),
        "model_context_probe_source": meta.get("model_context_probe_source"),
        "completion_reserve_tokens": meta.get("completion_reserve_tokens"),
        "chat_history_max_messages": cfg.chat_history_max_messages,
        "chat_history_recent_full_rows": cfg.chat_history_recent_full_rows,
        "vision_image_token_budget_per_image": cap["vision_tokens_per_image"],
        "supports_vision": bool(getattr(router._cfg.llm, "supports_vision", True)),
        "context_adaptive": {
            "tool_result_max_chars": cap["tool_result_max_chars"],
            "hydrate_preview_max_chars": cap["hydrate_preview_max_chars"],
            "effective_recent_full_rows": cap["effective_recent_full_rows"],
            "window_confidence": cap["window_confidence"],
            "context_pressure": cap["context_pressure"],
            "cap_B_chars": cap["cap_B_chars"],
            "cap_W_chars": cap["cap_W_chars"],
            "suggested_chunk_max_chars": cap.get("suggested_chunk_max_chars"),
            "suggested_chunk_max_bytes": cap.get("suggested_chunk_max_bytes"),
            "suggested_chunking_note": cap.get("suggested_chunking_note"),
            "notes": cap.get("notes") or [],
            "formula_coefficients": cap.get("formula_coefficients") or {},
        },
    }


async def _chat_history_list(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    sid = _require_session(router)
    if not sid:
        return {"ok": False, "error": "chat history only available on main agent session"}
    limit = int(args.get("limit", 40))
    limit = max(1, min(200, limit))
    store = router._tasks.store
    conn = router._tasks.db_conn
    rows = await store.list_chat_messages_tail(conn, sid, limit=limit)
    items: list[dict[str, Any]] = []
    for r in rows:
        prev = (r.content or "")[:240].replace("\n", " ")
        item: dict[str, Any] = {
            "id": r.id,
            "role": r.role,
            "created_at": r.created_at,
            "content_preview": prev + ("…" if len(r.content or "") > 240 else ""),
        }
        if r.tool_name:
            item["tool_name"] = r.tool_name
        if r.tool_call_id:
            item["tool_call_id"] = r.tool_call_id
        if r.tool_calls_json:
            item["has_tool_calls"] = True
        items.append(item)
    return {"ok": True, "session_id": sid, "messages": items}


async def _chat_history_search(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    sid = _require_session(router)
    if not sid:
        return {"ok": False, "error": "chat history only available on main agent session"}
    q = str(args.get("query") or "").strip()
    if not q:
        return {"ok": False, "error": "query is required"}
    use_regex = bool(args.get("use_regex") or args.get("regex") or False)
    limit = int(args.get("limit", 25))
    limit = max(1, min(100, limit))
    scan_limit = int(args.get("scan_limit", 2000))
    scan_limit = max(50, min(8000, scan_limit))
    if use_regex:
        try:
            re.compile(q)
        except re.error as e:
            return {"ok": False, "error": f"invalid regex: {e}"}
    store = router._tasks.store
    conn = router._tasks.db_conn
    rows = await store.search_chat_messages(
        conn,
        sid,
        query=q,
        use_regex=use_regex,
        limit=limit,
        scan_limit=scan_limit,
    )
    items: list[dict[str, Any]] = []
    for r in rows:
        prev = (r.content or "")[:240].replace("\n", " ")
        item: dict[str, Any] = {
            "id": r.id,
            "role": r.role,
            "created_at": r.created_at,
            "content_preview": prev + ("…" if len(r.content or "") > 240 else ""),
        }
        if r.tool_name:
            item["tool_name"] = r.tool_name
        if r.tool_call_id:
            item["tool_call_id"] = r.tool_call_id
        if r.tool_calls_json:
            item["has_tool_calls"] = True
        items.append(item)
    return {
        "ok": True,
        "session_id": sid,
        "use_regex": use_regex,
        "scan_limit": scan_limit if use_regex else None,
        "messages": items,
    }


async def _chat_history_get(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    sid = _require_session(router)
    if not sid:
        return {"ok": False, "error": "chat history only available on main agent session"}
    mid = int(args["message_id"])
    store = router._tasks.store
    conn = router._tasks.db_conn
    row = await store.get_chat_message(conn, mid)
    if row is None or row.session_id != sid:
        return {"ok": False, "error": "message not found for this session"}
    tool_calls: list[dict[str, Any]] | None = None
    if row.tool_calls_json:
        try:
            tc = json.loads(row.tool_calls_json)
            tool_calls = tc if isinstance(tc, list) else None
        except json.JSONDecodeError:
            tool_calls = None
    return {
        "ok": True,
        "message": {
            "id": row.id,
            "session_id": row.session_id,
            "role": row.role,
            "content": row.content,
            "created_at": row.created_at,
            "tool_calls": tool_calls,
            "tool_call_id": row.tool_call_id,
            "tool_name": row.tool_name,
        },
    }


async def _chat_save_summary(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    sid = _require_session(router)
    if not sid:
        return {"ok": False, "error": "chat history only available on main agent session"}
    content = str(args.get("content") or "").strip()
    if not content:
        return {"ok": False, "error": "content is required"}
    covers = args.get("covers_up_to_message_id")
    cid = int(covers) if covers is not None else None
    store = router._tasks.store
    conn = router._tasks.db_conn
    rid = await store.append_chat_summary(
        conn, session_id=sid, content=content, covers_up_to_message_id=cid
    )
    return {"ok": True, "summary_id": rid}


async def _chat_summaries_list(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    sid = _require_session(router)
    if not sid:
        return {"ok": False, "error": "chat history only available on main agent session"}
    limit = int(args.get("limit", 15))
    limit = max(1, min(100, limit))
    store = router._tasks.store
    conn = router._tasks.db_conn
    rows = await store.list_chat_summaries(conn, sid, limit=limit)
    return {
        "ok": True,
        "session_id": sid,
        "summaries": [
            {
                "id": r.id,
                "content": r.content,
                "covers_up_to_message_id": r.covers_up_to_message_id,
                "created_at": r.created_at,
            }
            for r in rows
        ],
    }


HANDLERS: dict[str, Any] = {
    "chat_new_session": _chat_new_session,
    "chat_session_info": _chat_session_info,
    "chat_history_list": _chat_history_list,
    "chat_history_search": _chat_history_search,
    "chat_history_get": _chat_history_get,
    "chat_save_summary": _chat_save_summary,
    "chat_summaries_list": _chat_summaries_list,
}
