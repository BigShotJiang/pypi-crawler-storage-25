"""HOME agent_scripts 脚本库工具。"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from aicd.agent.tool_args_coerce import coerce_tool_json_array
from aicd.tools import agent_scripts_lib as asl
from aicd.tools.process_tool import coerce_run_command_options

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


def _root(router: "ToolRouter") -> Path:
    return router._layout["agent_scripts"]


def _ensure_under_script_dir(script_path: Path, agent_scripts: Path) -> bool:
    try:
        script_path.resolve().relative_to(agent_scripts.resolve())
        return True
    except ValueError:
        return False


def _home_scripts_list(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    return asl.list_entries(_root(router))


def _home_scripts_read(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    stem = str(args.get("stem") or "").strip()
    include_index = bool(args.get("include_index", True))
    r = asl.read_pair(_root(router), stem)
    if not r.get("ok"):
        return r
    if not include_index:
        r.pop("index_text", None)
    return r


def _home_scripts_write(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    return asl.write_pair(
        _root(router),
        str(args.get("stem") or ""),
        str(args.get("kind") or "py"),
        str(args.get("script_body") or ""),
        str(args.get("doc_md") or ""),
        rebuild_index=bool(args.get("rebuild_index", True)),
    )


def _home_scripts_index_rebuild(router: "ToolRouter", _args: dict[str, Any]) -> dict[str, Any]:
    return asl.rebuild_index_md(_root(router))


def _home_scripts_delete(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    return asl.delete_script(_root(router), str(args.get("stem") or ""))


async def _home_scripts_run(router: "ToolRouter", args: dict[str, Any]) -> dict[str, Any]:
    stem = str(args.get("stem") or "").strip()
    timeout = float(args.get("timeout_sec", 600))
    raw_argv = args.get("argv")
    extra: list[str] | None = None
    if raw_argv is not None:
        co = coerce_tool_json_array(raw_argv, "argv", allow_empty=True)
        if isinstance(co, dict):
            return co
        extra = [str(x) for x in co]

    agent_scripts = _root(router).resolve()
    sp = asl.script_path_for_stem(agent_scripts, stem)
    if sp is None:
        return {
            "ok": False,
            "error": f"未找到 stem={stem!r} 的脚本（允许后缀 {asl.SCRIPT_EXTENSIONS}）",
        }
    if not _ensure_under_script_dir(sp, agent_scripts):
        return {"ok": False, "error": "路径不在 agent_scripts 目录内"}

    argv = asl.argv_for_run(sp, extra)
    if not argv:
        return {
            "ok": False,
            "error": f"当前平台无法运行 {sp.suffix}（例如 .bat/.cmd 仅 Windows）",
        }

    async def _log(line: str) -> None:
        await router._tasks.bus.publish(
            {"topic": "agent", "event": "log", "line": line}
        )

    rc_opts = coerce_run_command_options(args)
    out = await router._process.run_command(
        argv,
        cwd=str(agent_scripts),
        timeout_sec=timeout,
        on_line=_log,
        **rc_opts,
    )
    if isinstance(out, dict):
        out = {
            **out,
            "agent_scripts_stem": stem,
            "argv": argv,
            "script_path": str(sp),
        }
    return out


HANDLERS: dict[str, Any] = {
    "home_scripts_list": _home_scripts_list,
    "home_scripts_read": _home_scripts_read,
    "home_scripts_write": _home_scripts_write,
    "home_scripts_index_rebuild": _home_scripts_index_rebuild,
    "home_scripts_delete": _home_scripts_delete,
    "home_scripts_run": _home_scripts_run,
}
