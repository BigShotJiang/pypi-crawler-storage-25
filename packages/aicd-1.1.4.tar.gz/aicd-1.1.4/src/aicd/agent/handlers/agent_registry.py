"""Agent 类型与工作模式注册表（SQLite）CRUD 工具。"""

from __future__ import annotations

import json
from typing import Any

from aicd.agent.tool_router import ToolRouter


def _tool_bool_arg(v: object, *, default: bool) -> bool:
    """工具入参布尔：兼容 JSON bool 与常见字符串（避免 ``bool('false') is True``）。"""
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v != 0
    if isinstance(v, str):
        s = v.strip().lower()
        if s in ("", "0", "false", "no", "off", "n"):
            return False
        if s in ("1", "true", "yes", "on", "y"):
            return True
    return bool(v)


async def _agent_kind_list(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    include_disabled = _tool_bool_arg(args.get("include_disabled"), default=True)
    rows = await router._tasks.store.list_agent_kind_defs(
        router._tasks.db_conn, include_disabled=include_disabled
    )
    return {"ok": True, "agent_kinds": rows}


async def _agent_kind_upsert(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    key = str(args.get("key") or "").strip().lower()
    if not key:
        return {"ok": False, "error": "key required"}
    display_name = str(args.get("display_name") or key).strip()
    category = str(args.get("category") or "custom").strip()
    parent_key = args.get("parent_key")
    llm_profile_name = args.get("llm_profile_name")
    prompt_block_id = args.get("prompt_block_id")
    enabled = _tool_bool_arg(args.get("enabled"), default=True)
    meta = args.get("meta")
    meta_json: str | None = None
    if meta is not None:
        meta_json = json.dumps(meta, ensure_ascii=False) if not isinstance(meta, str) else meta
    try:
        await router._tasks.store.upsert_agent_kind_def(
            router._tasks.db_conn,
            key=key,
            display_name=display_name,
            category=category,
            parent_key=str(parent_key).strip() if parent_key else None,
            llm_profile_name=str(llm_profile_name).strip()
            if isinstance(llm_profile_name, str) and llm_profile_name.strip()
            else None,
            prompt_block_id=str(prompt_block_id).strip()
            if isinstance(prompt_block_id, str) and prompt_block_id.strip()
            else None,
            enabled=enabled,
            meta_json=meta_json,
            builtin=0,
        )
    except ValueError as e:
        return {"ok": False, "error": str(e)}
    return {"ok": True, "key": key}


async def _agent_kind_delete(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    key = str(args.get("key") or "").strip().lower()
    if not key:
        return {"ok": False, "error": "key required"}
    hard = _tool_bool_arg(args.get("hard"), default=False)
    ok, msg = await router._tasks.store.delete_agent_kind_def(
        router._tasks.db_conn, key, hard=hard
    )
    return {"ok": ok, "message": msg}


async def _work_mode_list(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    include_disabled = _tool_bool_arg(args.get("include_disabled"), default=True)
    rows = await router._tasks.store.list_work_mode_defs(
        router._tasks.db_conn, include_disabled=include_disabled
    )
    return {"ok": True, "work_modes": rows}


async def _work_mode_upsert(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    key = str(args.get("key") or "").strip().lower()
    if not key:
        return {"ok": False, "error": "key required"}
    display_name = str(args.get("display_name") or key).strip()
    llm_profile_name = args.get("llm_profile_name")
    prompt_block_id = args.get("prompt_block_id")
    tmp_policy_json = args.get("tmp_policy_json")
    policies = args.get("policies_json") or args.get("policies")
    policies_json: str | None = None
    if policies is not None:
        policies_json = (
            json.dumps(policies, ensure_ascii=False)
            if not isinstance(policies, str)
            else policies
        )
    enabled = _tool_bool_arg(args.get("enabled"), default=True)
    meta = args.get("meta")
    meta_json: str | None = None
    if meta is not None:
        meta_json = json.dumps(meta, ensure_ascii=False) if not isinstance(meta, str) else meta
    tpj = (
        str(tmp_policy_json) if isinstance(tmp_policy_json, str) and tmp_policy_json.strip() else None
    )
    try:
        await router._tasks.store.upsert_work_mode_def(
            router._tasks.db_conn,
            key=key,
            display_name=display_name,
            llm_profile_name=str(llm_profile_name).strip()
            if isinstance(llm_profile_name, str) and llm_profile_name.strip()
            else None,
            prompt_block_id=str(prompt_block_id).strip()
            if isinstance(prompt_block_id, str) and prompt_block_id.strip()
            else None,
            tmp_policy_json=tpj,
            policies_json=policies_json,
            enabled=enabled,
            meta_json=meta_json,
            builtin=0,
        )
    except ValueError as e:
        return {"ok": False, "error": str(e)}
    return {"ok": True, "key": key}


async def _work_mode_delete(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    key = str(args.get("key") or "").strip().lower()
    if not key:
        return {"ok": False, "error": "key required"}
    hard = _tool_bool_arg(args.get("hard"), default=False)
    ok, msg = await router._tasks.store.delete_work_mode_def(
        router._tasks.db_conn, key, hard=hard
    )
    return {"ok": ok, "message": msg}


async def _prompt_block_upsert(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    bid = str(args.get("id") or args.get("block_id") or "").strip()
    name = str(args.get("name") or bid).strip()
    content = str(args.get("content") or "")
    ver = int(args.get("version") or 1)
    if not bid:
        return {"ok": False, "error": "id required"}
    await router._tasks.store.upsert_prompt_block(
        router._tasks.db_conn,
        block_id=bid,
        name=name,
        content=content,
        version=ver,
    )
    return {"ok": True, "id": bid}


async def _prompt_block_delete(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    bid = str(args.get("id") or args.get("block_id") or "").strip()
    if not bid:
        return {"ok": False, "error": "id required"}
    ok, msg = await router._tasks.store.delete_prompt_block(router._tasks.db_conn, bid)
    return {"ok": ok, "message": msg}


HANDLERS: dict[str, Any] = {
    "agent_kind_list": _agent_kind_list,
    "agent_kind_upsert": _agent_kind_upsert,
    "agent_kind_delete": _agent_kind_delete,
    "work_mode_list": _work_mode_list,
    "work_mode_upsert": _work_mode_upsert,
    "work_mode_delete": _work_mode_delete,
    "prompt_block_upsert": _prompt_block_upsert,
    "prompt_block_delete": _prompt_block_delete,
}
