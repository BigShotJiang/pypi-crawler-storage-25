﻿"""信号驱动的上下文自适应（连续公式 + clamp，非刚性档位）。见方案定稿系数。"""

from __future__ import annotations

from typing import Any

# 供 chat_session_info / 排障：与实现一致的系数表（仅文档性，业务以函数为准）
ADAPTIVE_FORMULA_COEFFICIENTS: dict[str, Any] = {
    "tool_cap_B": {
        "linear": 0.12,
        "offset": 2048,
        "clamp": [6144, 32768],
        "low_discount": 0.92,
    },
    "tool_cap_W": {"linear": 0.018, "offset": 3072, "clamp": [6144, 32768]},
    "hydrate_preview": {
        "linear": 0.000055,
        "offset": 48,
        "clamp": [72, 200],
        "low_max": 110,
    },
    "vision_per_image": {"linear": 0.0045, "offset": 3500, "clamp": [4000, 8000]},
    "recent_full_scale": {
        "divisor": 262_144,
        "scale_clamp": [0.58, 1.0],
        "min_rows": 8,
    },
    "context_pressure": {"note": "B / max(W or B, 1), display only"},
    "text_chunk": {
        "frac_high_window": 0.16,
        "frac_low_window": 0.12,
        "bytes_per_char_pessimistic": 3,
        "min_chars": 3200,
        "max_bytes_cap_high": 480_000,
        "max_bytes_cap_low": 280_000,
        "note": "单次 fs_read / markdownChunk 正文占比；CJK 按 1 字≈1 token 悲观",
    },
}


def _clamp_int(x: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(x)))


def infer_window_confidence(*, model_context_window_tokens: int | None) -> str:
    """计划：W 已知则为 high，否则 low（未知窗宽时保守）。"""
    if model_context_window_tokens is None:
        return "low"
    if int(model_context_window_tokens) <= 0:
        return "low"
    return "high"


def compute_cap_B(effective_budget_tokens: int, *, window_confidence: str) -> int:
    b = max(0, int(effective_budget_tokens))
    b_eff = max(4096, b)
    v = round(0.12 * b_eff + 2048)
    v = _clamp_int(v, 6144, 32768)
    if window_confidence == "low":
        v = int(round(v * 0.92))
    return _clamp_int(v, 6144, 32768)


def compute_cap_W(model_window_tokens: int) -> int:
    w = max(1, int(model_window_tokens))
    v = round(0.018 * w + 3072)
    return _clamp_int(v, 6144, 32768)


def compute_tool_result_max_chars(
    *,
    effective_budget_tokens: int,
    model_context_window_tokens: int | None,
    window_confidence: str,
) -> int:
    cap_b = compute_cap_B(effective_budget_tokens, window_confidence=window_confidence)
    if model_context_window_tokens is not None and int(model_context_window_tokens) > 0:
        cap_w = compute_cap_W(int(model_context_window_tokens))
        base = min(cap_b, cap_w)
    else:
        base = cap_b
    return _clamp_int(base, 6144, 32768)


def compute_hydrate_preview_max_chars(
    effective_budget_tokens: int, *, window_confidence: str
) -> int:
    b = max(0, int(effective_budget_tokens))
    prev = _clamp_int(round(48 + 0.000055 * b), 72, 200)
    if window_confidence == "low":
        prev = min(prev, 110)
    return prev


def compute_effective_recent_full_rows(
    cfg_rows: int, effective_budget_tokens: int
) -> int:
    cfg = max(1, min(2000, int(cfg_rows)))
    b = max(0, int(effective_budget_tokens))
    scale = b / 262_144.0
    scale = min(1.0, max(0.58, scale))
    n = max(8, int(round(cfg * scale)))
    return min(n, cfg)


def compute_vision_tokens_per_image(
    effective_budget_tokens: int, agent: Any
) -> int:
    o = getattr(agent, "vision_image_token_budget_per_image", None)
    if o is not None:
        try:
            v = int(o)
        except (TypeError, ValueError):
            v = 0
        if v > 0:
            return _clamp_int(v, 2000, 32_000)
    b = max(0, int(effective_budget_tokens))
    return _clamp_int(round(3500 + 0.0045 * b), 4000, 8000)


def compute_context_pressure(
    effective_budget_tokens: int, model_context_window_tokens: int | None
) -> float:
    b = max(1, int(effective_budget_tokens))
    w = model_context_window_tokens
    denom = max((int(w) if w is not None and int(w) > 0 else b), 1)
    return round(b / denom, 4)


def compute_suggested_text_chunk_limits(
    *,
    effective_budget_tokens: int,
    model_context_window_tokens: int | None,
    window_confidence: str,
) -> dict[str, Any]:
    """
    大号小说 / 日志等切条、**markdown_chunk_split**、**fs_read_file** 单块大小的保守建议。

    - 用 **min(有效预算 B, 模型窗 W)** 与**正文占比**估单块「汉字级」token 上限（中文悲观 **1 字≈1 token**）。
    - UTF-8 字节按每字至多 **3** 字节换算，避免「500KB ≈ 二十万汉字」远超 128K 窗仍塞进一轮。
    """
    cfg = ADAPTIVE_FORMULA_COEFFICIENTS.get("text_chunk", {})
    frac_hi = float(cfg.get("frac_high_window", 0.16))
    frac_lo = float(cfg.get("frac_low_window", 0.12))
    bpp = int(cfg.get("bytes_per_char_pessimistic", 3))
    min_ch = int(cfg.get("min_chars", 3200))
    cap_hi = int(cfg.get("max_bytes_cap_high", 480_000))
    cap_lo = int(cfg.get("max_bytes_cap_low", 280_000))

    b = max(4096, int(effective_budget_tokens))
    w_int: int | None = None
    if model_context_window_tokens is not None:
        try:
            wi = int(model_context_window_tokens)
            w_int = wi if wi > 0 else None
        except (TypeError, ValueError):
            w_int = None
    base = min(b, w_int) if w_int is not None else b
    frac = frac_hi if window_confidence == "high" else frac_lo
    slice_chars = max(min_ch, int(base * frac))
    byte_cap = cap_hi if window_confidence == "high" else cap_lo
    max_bytes = _clamp_int(slice_chars * max(2, bpp), 36_000, byte_cap)
    note = (
        f"当前探测 min(会话预算,模型窗)≈{base} token，单块正文按≈{frac:.0%}估算≈{slice_chars} 字（CJK 悲观当 token），"
        f"对应 UTF-8 建议 ≤{max_bytes} 字节。**与 config `agent.contextBudgetTokens` 或实际 API 窗不一致时**请先 "
        "**`/llm`** 切到目标模型再 **chat_session_info** 核对 **model_context_window_tokens**。"
    )
    if window_confidence != "high":
        note += "（**window_confidence=low**：窗宽未探测或不可靠，已用更保守比例与字节上限。）"
    return {
        "suggested_chunk_max_chars": slice_chars,
        "suggested_chunk_max_bytes": max_bytes,
        "suggested_chunking_note": note,
    }


def compute_adaptive_context(
    *,
    meta: dict[str, Any],
    effective_budget_tokens: int,
    agent: Any,
) -> dict[str, Any]:
    w_raw = meta.get("model_context_window_tokens")
    w_int: int | None
    try:
        w_int = int(w_raw) if w_raw is not None else None
    except (TypeError, ValueError):
        w_int = None
    if w_int is not None and w_int <= 0:
        w_int = None

    wc = infer_window_confidence(model_context_window_tokens=w_int)
    cap_b = compute_cap_B(effective_budget_tokens, window_confidence=wc)
    cap_w = compute_cap_W(w_int) if w_int is not None else None
    tool_max = compute_tool_result_max_chars(
        effective_budget_tokens=effective_budget_tokens,
        model_context_window_tokens=w_int,
        window_confidence=wc,
    )
    preview = compute_hydrate_preview_max_chars(
        effective_budget_tokens, window_confidence=wc
    )
    recent = compute_effective_recent_full_rows(
        int(agent.chat_history_recent_full_rows), effective_budget_tokens
    )
    vision_tok = compute_vision_tokens_per_image(effective_budget_tokens, agent)
    pressure = compute_context_pressure(effective_budget_tokens, w_int)
    notes: list[str] = []
    if wc == "low":
        notes.append(
            "model_context_window unknown or unset; using conservative tool caps "
            "and shorter hydrate previews. Configure llm.modelContextTokens or rely on probe."
        )
    chunk = compute_suggested_text_chunk_limits(
        effective_budget_tokens=int(
            meta.get("context_budget_tokens_effective") or effective_budget_tokens
        ),
        model_context_window_tokens=w_int,
        window_confidence=wc,
    )
    return {
        "tool_result_max_chars": tool_max,
        "hydrate_preview_max_chars": preview,
        "vision_tokens_per_image": vision_tok,
        "effective_recent_full_rows": recent,
        "window_confidence": wc,
        "context_pressure": pressure,
        "cap_B_chars": cap_b,
        "cap_W_chars": cap_w,
        "effective_budget_tokens": int(effective_budget_tokens),
        "model_context_window_tokens": w_int,
        "notes": notes,
        "formula_coefficients": dict(ADAPTIVE_FORMULA_COEFFICIENTS),
        **chunk,
    }
