"""OpenAI 消息与数据库存储之间的序列化。"""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from pathlib import Path
from typing import Any


def json_safe_dumps(
    obj: Any,
    *,
    ensure_ascii: bool = False,
    max_len: int | None = None,
) -> str:
    """``json.dumps`` 的安全包装：不可序列化对象用 ``repr``；循环引用时退化为摘要。"""

    def _default(o: Any) -> str:
        try:
            r = repr(o)
        except Exception:  # noqa: BLE001
            return f"<{type(o).__name__}>"
        return r if len(r) <= 8000 else r[:7997] + "..."

    try:
        s = json.dumps(obj, ensure_ascii=ensure_ascii, default=_default)
    except (TypeError, ValueError):
        s = _default(obj)
    if max_len is not None and len(s) > max_len:
        return s[: max_len - 24] + '\n..."__truncated__"'
    return s


def slim_spill_tool_envelope_json(
    content: str, *, target_max_preview_chars: int
) -> str | None:
    """若 ``content`` 为带 ``_aicd_tool_result_spill`` 的 JSON，将 ``preview`` 截断到目标长度；否则返回 ``None``。"""
    if not content or "_aicd_tool_result_spill" not in content:
        return None
    lim = max(0, int(target_max_preview_chars))
    try:
        o = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(o, dict) or not o.get("_aicd_tool_result_spill"):
        return None
    prev = o.get("preview")
    if not isinstance(prev, str):
        return json.dumps(o, ensure_ascii=False)
    if len(prev) <= lim:
        return None
    o["preview"] = prev[:lim] + ("…" if lim > 0 else "")
    return json.dumps(o, ensure_ascii=False)


def tool_result_content_for_llm(
    result: Any,
    *,
    max_len: int = 24_000,
    spill_dir: Path | None = None,
    workspace_root: Path | None = None,
    tool_name: str | None = None,
) -> str:
    """工具返回写入 ``role=tool`` / SQLite 时使用，避免插件误传 ``ToolRouter`` 等导致崩溃。

    若序列化长度超过 ``max_len`` 且提供 ``spill_dir``：完整 JSON 落盘到
    ``{spill_dir}/sp_<id>_<tool>.json``，上下文只保留 **预览 + 路径 + 哈希**；
    否则退化为原地截断（与旧行为一致）。
    """
    full = json_safe_dumps(result, ensure_ascii=False, max_len=None)
    if len(full) <= max_len:
        return full
    if spill_dir is None:
        return json_safe_dumps(result, ensure_ascii=False, max_len=max_len)

    d = spill_dir.expanduser().resolve()
    d.mkdir(parents=True, exist_ok=True)
    safe_tool = re.sub(r"[^a-zA-Z0-9_.-]+", "_", (tool_name or "tool"))[:48]
    path = d / f"sp_{uuid.uuid4().hex[:14]}_{safe_tool}.json"
    path.write_text(full, encoding="utf-8")
    digest = hashlib.sha256(full.encode("utf-8")).hexdigest()[:16]

    rel: str | None = None
    if workspace_root is not None:
        try:
            rel = str(path.resolve().relative_to(workspace_root.resolve())).replace(
                "\\", "/"
            )
        except ValueError:
            rel = None

    preview_cap = max(200, min(12_000, max_len - 1100))
    preview = full[:preview_cap]
    if len(full) > preview_cap:
        preview += "\n…(_aicd: preview only; full JSON in spill file)…"

    envelope: dict[str, Any] = {
        "_aicd_tool_result_spill": True,
        "tool_name": tool_name,
        "spill_path_absolute": str(path.resolve()),
        "spill_path_workspace_relative": rel,
        "total_chars": len(full),
        "sha256_16": digest,
        "preview": preview,
        "hint": "Use artifact_query (meta|line_range|regex_lines|regex_multiline|json_path|xml_flat) "
        "or fs_read_file(byte_offset) on the spill path; for .md also markdown_section_slice / markdown_regex_scan.",
    }
    out = json_safe_dumps(envelope, ensure_ascii=False, max_len=None)
    if len(out) <= max_len:
        return out
    envelope["preview"] = full[: max(120, max_len // 4)] + "\n…"
    return json_safe_dumps(envelope, ensure_ascii=False, max_len=max_len)

# 多模态上下文粗估：与系统提示一致，**每张** vision 图统一按 **8000 token** 计入
# （与 `context_budget_tokens`、hydrate 裁剪对齐；实际计费以各模型为准）。
VISION_IMAGE_TOKENS_PER_IMAGE = 8000
VISION_IMAGE_TOKENS_ESTIMATE = VISION_IMAGE_TOKENS_PER_IMAGE
# 兼容旧名
VISION_IMAGE_TOKENS_MIN = 2000
VISION_IMAGE_TOKENS_MAX = VISION_IMAGE_TOKENS_PER_IMAGE


def tool_calls_to_jsonable(tool_calls: Any) -> list[dict[str, Any]]:
    if not tool_calls:
        return []
    out: list[dict[str, Any]] = []
    for tc in tool_calls:
        fn = getattr(tc, "function", None)
        name = getattr(fn, "name", "") if fn else ""
        args = getattr(fn, "arguments", None) if fn else None
        out.append(
            {
                "id": getattr(tc, "id", "") or "",
                "type": getattr(tc, "type", None) or "function",
                "function": {
                    "name": name,
                    "arguments": args if isinstance(args, str) else (args or "{}"),
                },
            }
        )
    return out


# 部分模型在 assistant 的 *content* 里回显伪 XML 工具标记（应用 API 的 tool_calls）。
_ASSISTANT_LEAKED_TOOL_FRAGMENT_RES: tuple[re.Pattern[str], ...] = (
    re.compile(r"<\s*tool_call\b[^>]*>", re.IGNORECASE),
    re.compile(r"<\s*/\s*tool_call\s*>", re.IGNORECASE),
    re.compile(r"<\s*tool_calls\b[^>]*>", re.IGNORECASE),
    re.compile(r"<\s*/\s*tool_calls\s*>", re.IGNORECASE),
    re.compile(r"<\s*function_calls\b[^>]*>", re.IGNORECASE),
    re.compile(r"<\s*/\s*function_calls\s*>", re.IGNORECASE),
)


def sanitize_assistant_leaked_tool_markers(text: str | None) -> str:
    """从助手正文中去掉泄漏的 ``<tool_call>`` 类标记，避免 TUI/会话记录出现残缺标签。"""

    if text is None:
        return ""
    t = str(text)
    if not t.strip():
        return t
    for rx in _ASSISTANT_LEAKED_TOOL_FRAGMENT_RES:
        t = rx.sub("", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.rstrip()


def estimate_message_tokens(
    msg: dict[str, Any], *, vision_tokens_per_image: int | None = None
) -> int:
    """
    粗估 token：纯文本约 4 字符/token；含 ``tool_calls`` JSON。
    若 ``content`` 为 OpenAI 多模态列表（``text`` + ``image_url``），
    每张 ``image_url`` 按 ``vision_tokens_per_image`` 或默认 ``VISION_IMAGE_TOKENS_PER_IMAGE`` 加计。
    """
    per = (
        int(vision_tokens_per_image)
        if vision_tokens_per_image is not None
        else VISION_IMAGE_TOKENS_PER_IMAGE
    )
    raw_c = msg.get("content")
    if isinstance(raw_c, list):
        text_chars = 0
        image_n = 0
        for part in raw_c:
            if not isinstance(part, dict):
                continue
            if part.get("type") == "text":
                text_chars += len(str(part.get("text") or ""))
            elif part.get("type") == "image_url":
                image_n += 1
        text_tok = (text_chars // 4 + 1) if text_chars else 0
        vision_tok = image_n * per
        tc = msg.get("tool_calls")
        extra = len(json.dumps(tc, ensure_ascii=False)) // 4 + 1 if tc else 0
        return max(1, text_tok + vision_tok + extra)

    n = len(str(raw_c or ""))
    tc = msg.get("tool_calls")
    if tc:
        n += len(json.dumps(tc, ensure_ascii=False))
    return max(1, n // 4 + 1)
