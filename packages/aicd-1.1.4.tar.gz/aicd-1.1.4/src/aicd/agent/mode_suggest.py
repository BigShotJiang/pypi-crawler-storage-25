"""根据用户文本轻量建议工作模式（不自动切换）。"""

from __future__ import annotations

import re


def suggest_work_mode_hint(user_text: str, *, current_mode: str) -> str:
    """
    返回一行中文提示，建议是否切换到某 **work_mode**；若无需建议则返回空串。

    不读取网络、不调用 LLM；仅作软提示。
    """
    t = (user_text or "").strip()
    if len(t) > 8000:
        t = t[:8000]
    low = t.lower()
    cur = (current_mode or "general").strip().lower()

    # 已处于目标模式则不再絮叨
    if cur == "pentest" and re.search(
        r"(漏洞|渗透|扫描|nmap|burp|授权|靶机|ctf)", t
    ):
        return ""
    if cur == "ops" and re.search(
        r"(部署|发布|回滚|日志|监控|systemd|kubectl|docker\s+(logs|ps))", low
    ):
        return ""

    if re.search(
        r"(漏洞|渗透测试|nmap|burp|msf|metasploit|授权渗透|靶机|ctf\s*题)", t
    ) and cur != "pentest":
        return (
            "（场景提示：你似乎在讨论安全评估/渗透相关主题；"
            "若仅在**已授权**环境工作，可考虑 `/workmode pentest` 收紧策略说明。）"
        )
    if re.search(
        r"(部署|发布|回滚|灰度|kubectl|systemd|docker\s+compose|日志轮转|监控告警)", t
    ) and cur != "ops":
        return "（场景提示：偏运维/发布流程；可考虑 `/workmode ops` 强调安全变更与可观测性。）"
    if re.search(
        r"(pytest|单元测试|npm\s+test|mypy|ruff|refactor|重构\s*代码)", low
    ) and cur != "dev":
        return "（场景提示：偏开发迭代；可考虑 `/workmode dev` 聚焦实现与静态检查。）"
    if re.search(
        r"(脚本|powershell|bash|批处理|定时任务|cron|pipeline)", t
    ) and cur != "script":
        return "（场景提示：偏脚本化自动化；可考虑 `/workmode script`。）"

    return ""
