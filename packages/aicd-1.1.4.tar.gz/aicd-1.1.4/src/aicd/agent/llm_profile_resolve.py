"""子 Agent / 主对话 的 LLM profile 名称解析（集中一处，避免散落）。"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aicd.config import AppConfig


def resolve_sub_agent_llm_profile_name(
    cfg: "AppConfig",
    *,
    explicit_llm_profile_name: str | None,
    agent_kind_def_llm_profile_name: str | None,
) -> str:
    """
    子 ``task_ai``：显式工具参数 > ``agent_kind_defs.llm_profile_name`` > 当前激活 profile。
    返回 **具名 profile**（``llmProfiles.name``），供 :func:`aicd.agent.llm.create_llm_client_for_profile_name` 使用。
    """
    ex = (
        str(explicit_llm_profile_name).strip()
        if isinstance(explicit_llm_profile_name, str) and explicit_llm_profile_name.strip()
        else ""
    )
    ak = (
        str(agent_kind_def_llm_profile_name).strip()
        if isinstance(agent_kind_def_llm_profile_name, str)
        and agent_kind_def_llm_profile_name.strip()
        else ""
    )
    return ex or ak or (cfg.active_llm_profile or "default")


async def resolve_work_mode_llm_profile_name(
    store: Any,
    conn: Any,
    work_mode: str,
) -> str | None:
    """
    主对话：若 ``work_mode_defs`` 为当前场景配置了 **llm_profile_name**，则返回该名称（覆盖全局 **activeLlmProfile**）；
    未配置或行不存在则返回 ``None``（调用方使用全局 ``self._llm``）。
    """
    wm = (work_mode or "").strip().lower()
    if not wm:
        return None
    row = await store.get_work_mode_def_row(conn, wm)
    if not row:
        return None
    raw = row.get("llm_profile_name")
    if not isinstance(raw, str) or not raw.strip():
        return None
    return raw.strip()
