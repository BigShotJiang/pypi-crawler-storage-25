from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import aiosqlite

from aicd.agent.llm import OpenAICompatibleClient, create_llm_client
from aicd.agent.loop import AgentLoop, merge_env_api_key, merge_env_integration_tokens
from aicd.network_policy import (
    aicd_runtime_flags_from_config,
    merge_env_block_external_network,
)
from aicd.agent.tool_router import ToolRouter
from aicd.bus.event_bus import AsyncEventBus
from aicd.config import AppConfig, apply_active_profile_to_llm, load_config, save_config
from aicd.config_settings import (
    apply_llm_slash_key_value,
    apply_nested_settings_patch,
    format_llm_profiles_lines,
    format_settings_summary,
    set_agent_scalar_from_slash,
    switch_llm_profile_by_token,
)
from aicd.db.store import TaskStore
from aicd.env_probe import format_env_capabilities_for_prompt, refresh_runtime_env_file
from aicd.home import init_home, new_chat_session_id
from aicd.home_instance_lock import (
    HomeInstanceLockError,
    acquire_home_instance_lock,
    release_home_instance_lock,
    should_acquire_instance_lock,
)
from aicd.setup_wizard import (
    run_first_time_setup,
    should_prompt_setup,
    skip_first_time_setup_interactive,
)
from aicd.session_log import (
    SessionLogger,
    app_config_for_log,
    build_startup_info,
    new_session_log_path,
)
from aicd.invocation import (
    InvocationContext,
    load_invocation_context,
    should_load_plugins_at_boot,
)
from aicd.plugins.registry import PluginRegistry
from aicd.tasks.manager import TaskManager
from aicd.tools.path_policy import PathPolicy
from aicd.tools.process_tool import ProcessTool
from aicd.config import _normalize_agent_default_work_mode
from aicd.tui_prefs import (
    load_main_chat_mode,
    load_work_mode,
    load_work_mode_user_override,
    resolve_boot_work_mode,
)


def _sync_boot_env(
    cfg: AppConfig, *, block_external_override: bool | None
) -> None:
    merge_env_api_key(cfg)
    merge_env_integration_tokens(cfg)
    merge_env_block_external_network(cfg)
    if block_external_override is True:
        cfg.agent.block_external_network = True


@dataclass
class RuntimeContext:
    home: Path
    layout: dict[str, Path]
    config: AppConfig
    bus: AsyncEventBus
    conn: aiosqlite.Connection
    store: TaskStore
    tasks: TaskManager
    router: ToolRouter
    llm: OpenAICompatibleClient
    agent: AgentLoop
    session_log: SessionLogger
    runtime_env_snapshot: dict[str, Any] = field(default_factory=dict)
    runtime_env_yaml: Path | None = None
    plugin_registry: PluginRegistry | None = None
    invocation: InvocationContext | None = None
    workspace_cwd: Path = field(init=False)
    ai_output_dir: Path = field(init=False)
    ai_tmp_dir: Path = field(init=False)
    _ai_output_user_set: bool = field(init=False, repr=False)
    _shutdown_done: bool = field(default=False, init=False, repr=False)
    _shutdown_lock: asyncio.Lock = field(init=False, repr=False)
    home_instance_lock_held: bool = field(default=False, repr=False)

    def __post_init__(self) -> None:
        self.workspace_cwd = self.router.cwd
        self._ai_output_user_set = False
        object.__setattr__(self, "_shutdown_lock", asyncio.Lock())
        self._recompute_ai_output_paths()
        self._sync_ai_paths_to_router_and_agent()

    async def shutdown_graceful(self, *, force: bool = False) -> None:
        """取消后台任务并关闭数据库（可重复调用，幂等）。

        * **force**：缩短交互子进程清理时间并 **abandon** 后台任务协程，尽快关库（TUI ``/exit force``）。
        * 正常路径若抛错，会自动再尝试一轮 **force** 收尾。
        """
        async with self._shutdown_lock:
            if self._shutdown_done:
                return
            try:
                if force:
                    await self._shutdown_forced_unlocked()
                else:
                    await self._shutdown_graceful_unlocked()
            except Exception as e:  # noqa: BLE001
                if not force:
                    try:
                        self.session_log.write_exception(
                            "runtime",
                            "RuntimeContext",
                            "shutdown_graceful_body",
                            e,
                        )
                    except Exception:
                        pass
                    try:
                        await self._shutdown_forced_unlocked()
                    except Exception as e2:  # noqa: BLE001
                        try:
                            self.session_log.write_exception(
                                "runtime",
                                "RuntimeContext",
                                "shutdown_after_graceful_fail",
                                e2,
                            )
                        except Exception:
                            pass
                else:
                    try:
                        self.session_log.write_exception(
                            "runtime",
                            "RuntimeContext",
                            "shutdown_forced_body",
                            e,
                        )
                    except Exception:
                        pass
            finally:
                self._shutdown_done = True
                if self.home_instance_lock_held:
                    try:
                        release_home_instance_lock(self.home)
                    except Exception as e:  # noqa: BLE001
                        try:
                            self.session_log.write_exception(
                                "runtime",
                                "RuntimeContext",
                                "home_instance_lock_release",
                                e,
                            )
                        except Exception:
                            pass
                    self.home_instance_lock_held = False

    async def _shutdown_graceful_unlocked(self) -> None:
        self.session_log.write_event(
            "runtime",
            "RuntimeContext",
            "shutdown_graceful",
            "",
            "cancel_tasks_close_db",
        )
        try:
            await asyncio.wait_for(
                self.router._interactive_bucket.cleanup_all(reason="safe_exit"),
                timeout=24.0,
            )
        except asyncio.TimeoutError:
            self.session_log.write_event(
                "runtime",
                "RuntimeContext",
                "interactive_cleanup_timeout",
                "",
                "24s",
            )
        except Exception as e:  # noqa: BLE001
            self.session_log.write_exception(
                "runtime",
                "RuntimeContext",
                "cleanup_interactive_sessions",
                e,
            )
        try:
            await asyncio.wait_for(
                self.tasks.cancel_all_running(reason="safe_exit"),
                timeout=45.0,
            )
        except asyncio.TimeoutError:
            leaked = self.tasks.abandon_stale_running_tasks()
            self.session_log.write_event(
                "runtime",
                "RuntimeContext",
                "cancel_all_running_timeout",
                f"abandoned_n={len(leaked)}",
                ",".join(leaked[:12]),
            )
        except Exception as e:  # noqa: BLE001
            self.session_log.write_exception(
                "runtime",
                "RuntimeContext",
                "cancel_all_running",
                e,
            )
        try:
            await asyncio.wait_for(self.conn.close(), timeout=8.0)
        except asyncio.TimeoutError:
            self.session_log.write_event(
                "runtime",
                "RuntimeContext",
                "conn_close_timeout",
                "",
                "",
            )
        except Exception as e:  # noqa: BLE001
            self.session_log.write_exception(
                "runtime",
                "RuntimeContext",
                "conn_close",
                e,
            )

    async def _shutdown_forced_unlocked(self) -> None:
        try:
            self.session_log.write_event(
                "runtime",
                "RuntimeContext",
                "shutdown_forced",
                "",
                "short_cleanup_abandon_tasks_close_db",
            )
        except Exception:
            pass
        try:
            await asyncio.wait_for(
                self.router._interactive_bucket.cleanup_all(reason="safe_exit_force"),
                timeout=6.0,
            )
        except Exception:
            pass
        try:
            self.tasks.abandon_stale_running_tasks()
        except Exception:
            pass
        try:
            await asyncio.wait_for(self.conn.close(), timeout=4.0)
        except Exception:
            try:
                self.session_log.write_event(
                    "runtime",
                    "RuntimeContext",
                    "conn_close_forced_fail",
                    "",
                    "",
                )
            except Exception:
                pass

    def _recompute_ai_output_paths(self) -> None:
        """默认：工作目录下的 aicd/ 与 aicd/tmp/。"""
        self.ai_output_dir = (self.workspace_cwd / "aicd").resolve()
        self.ai_tmp_dir = (self.ai_output_dir / "tmp").resolve()

    def _sync_ai_paths_to_router_and_agent(self) -> None:
        self.router.set_ai_paths(self.ai_output_dir, self.ai_tmp_dir)
        self.agent.set_ai_storage_paths(self.ai_output_dir, self.ai_tmp_dir)

    def ensure_ai_output_layout(self) -> None:
        """首次使用或 /doc 时创建输出目录与 tmp。"""
        self.ai_output_dir.mkdir(parents=True, exist_ok=True)
        self.ai_tmp_dir.mkdir(parents=True, exist_ok=True)

    def get_ai_storage_paths(self) -> dict[str, str]:
        return {
            "workspace": str(self.workspace_cwd),
            "ai_output_dir": str(self.ai_output_dir),
            "ai_tmp_dir": str(self.ai_tmp_dir),
        }

    def persist_tui_main_chat_mode(self, canonical: str) -> None:
        """将 ``/mode`` 写入 ``HOME/data/tui_prefs.json``（TUI 与 Host 共用）。"""
        from aicd.tui_prefs import MAIN_CHAT_CANONICAL_MODES, save_main_chat_mode

        if canonical not in MAIN_CHAT_CANONICAL_MODES:
            return
        save_main_chat_mode(self.layout["data"], canonical)

    def persist_tui_work_mode(self, canonical: str) -> None:
        """将 ``/workmode`` 写入 ``HOME/data/tui_prefs.json``。"""
        from aicd.tui_prefs import WORK_MODE_CANONICAL_MODES, save_work_mode

        if canonical not in WORK_MODE_CANONICAL_MODES:
            return
        save_work_mode(self.layout["data"], canonical)

    def list_home_session_workspaces(self) -> list[Path]:
        """``HOME/workspaces`` 下受管 ``workspace_*`` 目录列表。"""
        from aicd.session_workspace import list_managed_workspaces

        return list_managed_workspaces(self.home)

    def clear_home_session_workspaces_except_current(self) -> tuple[int, list[str]]:
        """删除上述目录中除当前 ``workspace_cwd`` 以外的项。"""
        from aicd.session_workspace import clear_managed_workspaces_except

        return clear_managed_workspaces_except(self.home, self.workspace_cwd)

    def create_and_set_home_session_workspace(self) -> tuple[bool, str]:
        """在 ``AICD_HOME/workspaces`` 下新建 ``workspace_YYYYMMDDHHMMSS`` 并设为当前 AI 工作区。"""
        from aicd.session_workspace import create_session_workspace

        container = self.layout["workspaces"]
        path = create_session_workspace(container)
        return self.set_ai_workspace(str(path))

    def set_ai_workspace(self, path_str: str | None) -> tuple[bool, str]:
        """设置主 AI 工作目录（与 AICD_HOME 无关）。无 path 时返回当前目录。"""
        if path_str is None or not str(path_str).strip():
            return True, str(self.workspace_cwd)
        raw = str(path_str).strip()
        p = Path(raw).expanduser()
        if not p.is_absolute():
            p = (self.workspace_cwd / p).resolve()
        else:
            p = p.resolve()
        try:
            self.router.path_policy.check_allowed(p)
        except PermissionError as e:
            return False, str(e)
        if not p.is_dir():
            return False, f"not a directory: {p}"
        old_ws = self.workspace_cwd.resolve()
        self.router.set_cwd(p)
        self.tasks.set_process_tool(ProcessTool(self.router.path_policy, p))
        self.workspace_cwd = p
        self.agent.set_workspace(p)
        if not self._ai_output_user_set:
            self._recompute_ai_output_paths()
        else:
            # 若用户曾设过 /doc，但目录仍在「旧工作区」下，切换 /work 后应跟到新工作区，否则会一直写到启动目录或旧项目路径
            try:
                self.ai_output_dir.resolve().relative_to(old_ws)
            except ValueError:
                pass
            else:
                self._ai_output_user_set = False
                self._recompute_ai_output_paths()
        self.ensure_ai_output_layout()
        self._sync_ai_paths_to_router_and_agent()
        return True, str(p)

    def set_ai_output_dir(self, path_str: str | None) -> tuple[bool, str]:
        """设置 AI 输出根目录（其下自动使用 tmp/）。无参数时返回当前路径；default/reset 恢复为 workspace/aicd。"""
        if path_str is None or not str(path_str).strip():
            self.ensure_ai_output_layout()
            return True, (
                f"ai_output_dir={self.ai_output_dir}\n"
                f"ai_tmp_dir={self.ai_tmp_dir}"
            )
        raw = str(path_str).strip()
        low = raw.lower()
        if low in ("default", "reset"):
            self._ai_output_user_set = False
            self._recompute_ai_output_paths()
            self.ensure_ai_output_layout()
            self._sync_ai_paths_to_router_and_agent()
            return True, f"已恢复默认（相对当前工作目录）:\n{self.ai_output_dir}"
        policy = PathPolicy(self.config.paths)
        p = Path(raw).expanduser()
        if not p.is_absolute():
            p = (self.workspace_cwd / p).resolve()
        else:
            p = p.resolve()
        try:
            policy.check_allowed(p)
        except PermissionError as e:
            return False, str(e)
        if p.exists() and not p.is_dir():
            return False, f"not a directory: {p}"
        p.mkdir(parents=True, exist_ok=True)
        self.ai_output_dir = p
        self.ai_tmp_dir = (p / "tmp").resolve()
        self._ai_output_user_set = True
        self.ensure_ai_output_layout()
        self._sync_ai_paths_to_router_and_agent()
        return True, (
            f"ai_output_dir={self.ai_output_dir}\n"
            f"ai_tmp_dir={self.ai_tmp_dir}"
        )

    def settings_summary_text(self) -> str:
        return format_settings_summary(self.config)

    def persist_config(self) -> None:
        save_config(self.layout["config"], self.config)

    async def reload_llm_client(self) -> tuple[bool, str]:
        """按当前内存中的 ``config``（含 ``activeLlmProfile``）重建 LLM 并挂回 Router / Agent。"""
        cfg = self.config
        apply_active_profile_to_llm(cfg)
        merge_env_api_key(cfg)
        merge_env_integration_tokens(cfg)
        new_llm = create_llm_client(cfg)
        new_llm.attach_session_log(self.session_log)
        try:
            await new_llm.probe_model_context()
        except Exception as e:  # noqa: BLE001
            self.session_log.write_event(
                "llm",
                "OpenAICompatibleClient",
                "model_context_probe_reload",
                "failed",
                repr(e)[:2000],
            )
        self.llm = new_llm
        self.router.attach_llm_client(new_llm)
        self.router.set_vision_llm(new_llm)
        self.agent.rebind_llm(new_llm)
        return True, "LLM 客户端已热重载"

    def apply_settings_patch(
        self, patch: dict, *, persist: bool = True
    ) -> tuple[bool, str]:
        ok, msg = apply_nested_settings_patch(self.config, patch)
        if ok and persist:
            self.persist_config()
        return ok, msg

    def apply_slash_llm(self, args: list[str]) -> tuple[bool, str]:
        if not args:
            return True, self.settings_summary_text()
        # 快捷：/llm 3  等同  /llm use 3（按列表序号切换）
        if len(args) == 1 and args[0].strip().isdigit():
            token = args[0].strip()
            ok, msg = switch_llm_profile_by_token(self.config, token)
            if ok:
                self.persist_config()
                self.router.schedule_llm_hot_reload()
            return ok, msg
        a0 = args[0].strip().lower()
        if a0 in ("list", "profiles", "ls"):
            return True, format_llm_profiles_lines(self.config)
        if a0 in ("use", "select", "profile"):
            if len(args) < 2:
                return (
                    False,
                    "用法: /llm use <序号1..n|配置名>  —  或 /llm 查看全部与采样项",
                )
            token = " ".join(args[1:]).strip()
            ok, msg = switch_llm_profile_by_token(self.config, token)
            if ok:
                self.persist_config()
                self.router.schedule_llm_hot_reload()
            return ok, msg
        if len(args) < 2:
            return (
                False,
                "用法: /llm 查看  |  /llm list  |  /llm use <n|name>  |  /llm <键> <值>",
            )
        key, *rest = args
        value = " ".join(rest)
        ok, msg, hot = apply_llm_slash_key_value(self.config, key, value)
        if ok:
            self.persist_config()
            if hot:
                self.router.schedule_llm_hot_reload()
        return ok, msg

    def apply_slash_agent(self, args: list[str]) -> tuple[bool, str]:
        if not args:
            return True, self.settings_summary_text()
        if len(args) < 2:
            return (
                False,
                "用法: /agent rounds <n> | /agent subRounds <n> | /agent heartbeat <秒> | "
                "/agent subHeartbeat <秒> | /agent lifecycleCoalesce <秒>（0–3，lifecycle 合并延迟） "
                "或 /agent 查看（0=关闭定时心跳）",
            )
        key, *rest = args
        value = " ".join(rest)
        ok, msg = set_agent_scalar_from_slash(self.config, key, value)
        if ok:
            self.persist_config()
        return ok, msg


async def build_runtime(
    home: Path | None = None,
    session_id: str | None = None,
    *,
    skip_first_setup: bool = False,
    setup_tty_relaxed: bool = False,
    cli_no_plugins: bool = False,
    plugin_policy_override: str | None = None,
    block_external_network: bool | None = None,
    initial_ai_workspace: Path | None = None,
    exclusive_home_lock: bool | None = None,
) -> RuntimeContext:
    inv = load_invocation_context(plugin_policy_override=plugin_policy_override)
    root, layout, cfg = init_home(home)

    lock_requested = should_acquire_instance_lock(inv, explicit=exclusive_home_lock)
    instance_lock_held = False
    if lock_requested:
        ok, msg = acquire_home_instance_lock(root)
        if not ok:
            raise HomeInstanceLockError(msg)
        instance_lock_held = True

    async def _inner() -> RuntimeContext:
        nonlocal cfg
        _sync_boot_env(cfg, block_external_override=block_external_network)
        cfg_path = layout["config"]
        if (
            not skip_first_setup
            and should_prompt_setup(relaxed=setup_tty_relaxed)
            and not skip_first_time_setup_interactive(layout, cfg_path, cfg)
        ):
            cfg = run_first_time_setup(layout, cfg, home_label=str(root.resolve()))
            _sync_boot_env(cfg, block_external_override=block_external_network)
        if not cfg.llm.api_key and cfg_path.is_file():
            cfg = load_config(cfg_path)
            _sync_boot_env(cfg, block_external_override=block_external_network)

        _runtime_path, _runtime_snap = refresh_runtime_env_file(
            layout, aicd_runtime=aicd_runtime_flags_from_config(cfg)
        )
        _caps_block = format_env_capabilities_for_prompt(
            _runtime_snap, yaml_path=str(_runtime_path.resolve())
        )
        bus = AsyncEventBus()
        store = TaskStore(layout["db"])
        conn = await store.connect()
        policy = PathPolicy(cfg.paths)
        if initial_ai_workspace is not None:
            start_cwd = initial_ai_workspace.expanduser().resolve()
            if not start_cwd.is_dir():
                raise ValueError(f"initial_ai_workspace 不是目录: {start_cwd}")
        else:
            start_cwd = Path.cwd().resolve()
        sid = session_id or new_chat_session_id(layout["data"])
        log_path = new_session_log_path(layout["logs"])
        session_log = SessionLogger(log_path)
        session_log.write_startup(
            build_startup_info(
                home=root,
                session_log_path=log_path,
                session_id=sid,
                workspace_cwd=start_cwd,
                cfg_summary=app_config_for_log(cfg),
                layout=layout,
                runtime_env_path=str(_runtime_path),
            )
        )
        if store.last_open_rebuilt_db:
            session_log.write_event(
                "runtime",
                "TaskStore",
                "schema_rebuild",
                "",
                "数据库 schema 已升级并整库重建；历史任务与聊天记录已清空。",
            )
        if inv.host_nonce:
            from aicd.host_tokens import verify_host_nonce

            n_ok, n_msg = verify_host_nonce(layout["plugins_state"], inv.host_nonce)
            if not n_ok:
                session_log.write_event(
                    "runtime",
                    "host_nonce",
                    "verify_failed",
                    n_msg,
                    (inv.host_nonce[:120] if inv.host_nonce else ""),
                )
        process = ProcessTool(policy, start_cwd)
        task_mgr = TaskManager(
            store=store,
            conn=conn,
            bus=bus,
            tasks_root=layout["tasks"],
            process_tool=process,
            session_log=session_log,
        )
        router = ToolRouter(
            cfg,
            layout=layout,
            task_manager=task_mgr,
            cwd=start_cwd,
            path_policy=policy,
            session_log=session_log,
            chat_session_id=sid,
        )
        llm = create_llm_client(cfg)
        llm.attach_session_log(session_log)
        try:
            await llm.probe_model_context()
        except Exception as e:  # noqa: BLE001
            session_log.write_event(
                "llm",
                "OpenAICompatibleClient",
                "model_context_probe_boot",
                "failed",
                repr(e)[:2000],
            )
        agent = AgentLoop(
            cfg,
            llm,
            router,
            task_mgr,
            store,
            conn,
            layout,
            bus,
            sid,
            session_log=session_log,
            env_capabilities_block=_caps_block,
        )
        agent.set_invocation_context(inv)
        _persisted_mode = load_main_chat_mode(layout["data"])
        if _persisted_mode:
            agent.assign_main_chat_mode_canonical(_persisted_mode)
        _cfg_wm = _normalize_agent_default_work_mode(cfg.agent.default_work_mode)
        _persisted_wm = load_work_mode(layout["data"])
        _wm_explicit = load_work_mode_user_override(layout["data"])
        _boot_wm = resolve_boot_work_mode(_cfg_wm, _persisted_wm, _wm_explicit)
        agent.assign_work_mode_canonical(_boot_wm)
        router.set_env_capabilities_callback(
            lambda data, p: agent.set_env_capabilities_block(
                format_env_capabilities_for_prompt(data, yaml_path=str(p.resolve()))
            )
        )
        router.set_chat_session_switch(agent.apply_chat_session_id)
        router.attach_llm_client(llm)
        router.set_work_mode_supplier(lambda: agent.work_mode)
        task_mgr.set_ai_paths_resolver(router.get_ai_paths)
        task_mgr.set_ai_runner(agent.run_sub_agent_worker)
        await agent.hydrate_chat_from_store()
        load_plugins, boot_reason = should_load_plugins_at_boot(
            inv,
            cfg.plugins,
            cli_no_plugins=cli_no_plugins,
        )
        if inv.depth_exceeds(cfg.plugins.max_invocation_depth):
            session_log.write_event(
                "runtime",
                "invocation",
                "depth_exceeds_config",
                f"depth={inv.depth} max={cfg.plugins.max_invocation_depth}",
                "",
            )
        plugin_reg = PluginRegistry(layout=layout, app=cfg)
        if load_plugins:
            plugin_reg.load_all()
        else:
            plugin_reg.load_all(plugin_ids=frozenset())
        session_log.write_event(
            "runtime",
            "plugins",
            "boot",
            f"load={load_plugins} reason={boot_reason}",
            f"depth={inv.depth} spawned_by={inv.spawned_by}",
        )
        router.set_plugin_registry(plugin_reg)
        router.refresh_plugin_handlers(plugin_reg.plugin_handlers())

        def _plugin_reload_hook() -> None:
            agent.set_plugin_prompt_block(plugin_reg.prompt_block)
            from aicd.capabilities import (
                build_capabilities_payload,
                format_capabilities_prompt_chunk,
            )

            loaded = any(p.get("ok") for p in plugin_reg.summarize())
            agent.set_capabilities_prompt_block(
                format_capabilities_prompt_chunk(
                    build_capabilities_payload(
                        plugin_registry=plugin_reg,
                        invocation=inv,
                        plugins_boot_loaded=loaded,
                    )
                )
            )

        router.set_plugin_reload_hook(_plugin_reload_hook)
        agent.set_plugin_registry(plugin_reg)
        agent.set_plugin_prompt_block(plugin_reg.prompt_block)
        from aicd.capabilities import (
            build_capabilities_payload,
            format_capabilities_prompt_chunk,
        )

        agent.set_capabilities_prompt_block(
            format_capabilities_prompt_chunk(
                build_capabilities_payload(
                    plugin_registry=plugin_reg,
                    invocation=inv,
                    plugins_boot_loaded=load_plugins,
                )
            )
        )
        plugin_errors = [p for p in plugin_reg.summarize() if not p.get("ok")]
        if plugin_errors:
            session_log.write_event(
                "runtime",
                "plugins",
                "load",
                f"errors_in={len(plugin_errors)}",
                str(plugin_errors)[:2000],
            )
        ctx = RuntimeContext(
            home=root,
            layout=layout,
            config=cfg,
            bus=bus,
            conn=conn,
            store=store,
            tasks=task_mgr,
            router=router,
            llm=llm,
            agent=agent,
            session_log=session_log,
            runtime_env_snapshot=_runtime_snap,
            runtime_env_yaml=_runtime_path,
            plugin_registry=plugin_reg,
            invocation=inv,
            home_instance_lock_held=instance_lock_held,
        )
        router.set_ai_workspace_setter(ctx.set_ai_workspace)
        router.set_ai_workspace_create_new(ctx.create_and_set_home_session_workspace)
        router.set_vision_llm(llm)
        router.set_llm_hot_reload(ctx.reload_llm_client)
        return ctx

    try:
        return await _inner()
    except BaseException:
        if instance_lock_held:
            release_home_instance_lock(root)
        raise


def persist_config(layout: dict[str, Path], cfg: AppConfig) -> None:
    save_config(layout["config"], cfg)
