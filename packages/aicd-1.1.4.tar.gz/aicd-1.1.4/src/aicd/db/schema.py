"""
SQLite DDL for the runtime task + chat database.

**Breaking**：以 ``PRAGMA user_version`` 为准；与 :data:`SCHEMA_USER_VERSION` 不一致时
整库 ``DROP`` 后重建（任务与聊天均清空）。仅保留仓库侧核心配置 JSON/YAML，不迁移旧 DB。
"""

from __future__ import annotations

# 递增此值即触发现有 *.db 在下次连接时被重建（无数据迁移）。
SCHEMA_USER_VERSION = 3

SCHEMA = """
CREATE TABLE IF NOT EXISTS prompt_blocks (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    content TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agent_kind_defs (
    key TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    category TEXT NOT NULL,
    parent_key TEXT,
    llm_profile_name TEXT,
    prompt_block_id TEXT,
    builtin INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1,
    meta_json TEXT,
    FOREIGN KEY(prompt_block_id) REFERENCES prompt_blocks(id)
);

CREATE INDEX IF NOT EXISTS idx_agent_kind_category ON agent_kind_defs(category);
CREATE INDEX IF NOT EXISTS idx_agent_kind_enabled ON agent_kind_defs(enabled);

CREATE TABLE IF NOT EXISTS work_mode_defs (
    key TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    llm_profile_name TEXT,
    prompt_block_id TEXT,
    tmp_policy_json TEXT,
    policies_json TEXT,
    builtin INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1,
    meta_json TEXT,
    FOREIGN KEY(prompt_block_id) REFERENCES prompt_blocks(id)
);

CREATE INDEX IF NOT EXISTS idx_work_mode_enabled ON work_mode_defs(enabled);

CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    status TEXT NOT NULL,
    parent_id TEXT,
    thread_root_id TEXT,
    agent_workflow TEXT,
    agent_kind TEXT,
    work_mode TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    payload_json TEXT,
    result_summary TEXT,
    error TEXT
);

CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_parent ON tasks(parent_id);
CREATE INDEX IF NOT EXISTS idx_tasks_thread_root ON tasks(thread_root_id);
CREATE INDEX IF NOT EXISTS idx_tasks_agent_workflow ON tasks(agent_workflow);
CREATE INDEX IF NOT EXISTS idx_tasks_agent_kind ON tasks(agent_kind);
CREATE INDEX IF NOT EXISTS idx_tasks_work_mode ON tasks(work_mode);

CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT,
    tool_calls_json TEXT,
    created_at TEXT NOT NULL,
    tool_call_id TEXT,
    tool_name TEXT
);

CREATE INDEX IF NOT EXISTS idx_chat_session ON chat_messages(session_id);

CREATE TABLE IF NOT EXISTS chat_summaries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    content TEXT NOT NULL,
    covers_up_to_message_id INTEGER,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chat_summaries_session ON chat_summaries(session_id);

CREATE TABLE IF NOT EXISTS task_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_root_id TEXT,
    to_task_id TEXT NOT NULL,
    from_task_id TEXT NOT NULL,
    kind TEXT NOT NULL,
    body_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    read_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_task_messages_to ON task_messages(to_task_id);
CREATE INDEX IF NOT EXISTS idx_task_messages_from ON task_messages(from_task_id);
CREATE INDEX IF NOT EXISTS idx_task_messages_thread ON task_messages(thread_root_id);
"""

RESET_DROP_SCRIPT = """
DROP TABLE IF EXISTS task_messages;
DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS chat_summaries;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS agent_kind_defs;
DROP TABLE IF EXISTS work_mode_defs;
DROP TABLE IF EXISTS prompt_blocks;
"""
