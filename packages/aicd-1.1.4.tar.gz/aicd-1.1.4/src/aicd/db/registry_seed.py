"""内置 Agent 类型与工作模式注册表种子（SCHEMA v3）。"""

from __future__ import annotations

from typing import Any

import aiosqlite

_SEED_AGENT_KINDS: list[dict[str, Any]] = [
    {
        "key": "coder",
        "display_name": "Coder",
        "category": "coder",
        "parent_key": None,
        "llm_profile_name": None,
        "builtin": 1,
    },
    {
        "key": "doc",
        "display_name": "Doc",
        "category": "doc",
        "parent_key": "coder",
        "llm_profile_name": None,
        "builtin": 1,
    },
    {
        "key": "validator",
        "display_name": "Validator",
        "category": "validate",
        "parent_key": "coder",
        "llm_profile_name": None,
        "builtin": 1,
    },
    {
        "key": "maintainer",
        "display_name": "Maintainer",
        "category": "maintain",
        "parent_key": "coder",
        "llm_profile_name": None,
        "builtin": 1,
    },
    {
        "key": "operator",
        "display_name": "Operator",
        "category": "operator",
        "parent_key": "coder",
        "llm_profile_name": None,
        "builtin": 1,
    },
]

_SEED_WORK_MODES: list[dict[str, Any]] = [
    {
        "key": "general",
        "display_name": "General",
        "llm_profile_name": None,
        "builtin": 1,
    },
    {
        "key": "dev",
        "display_name": "Development",
        "llm_profile_name": None,
        "builtin": 1,
    },
    {
        "key": "script",
        "display_name": "Script",
        "llm_profile_name": None,
        "builtin": 1,
    },
    {
        "key": "pentest",
        "display_name": "Security assessment",
        "llm_profile_name": None,
        "builtin": 1,
    },
    {
        "key": "ops",
        "display_name": "Operations",
        "llm_profile_name": None,
        "builtin": 1,
    },
]


async def seed_agent_work_mode_registry(conn: aiosqlite.Connection) -> None:
    """幂等：仅补充缺失的内置行。"""
    for row in _SEED_AGENT_KINDS:
        await conn.execute(
            """
            INSERT OR IGNORE INTO agent_kind_defs (
                key, display_name, category, parent_key, llm_profile_name,
                prompt_block_id, builtin, enabled, meta_json)
            VALUES (?, ?, ?, ?, ?, NULL, ?, 1, NULL)
            """,
            (
                row["key"],
                row["display_name"],
                row["category"],
                row["parent_key"],
                row["llm_profile_name"],
                int(row["builtin"]),
            ),
        )
    for row in _SEED_WORK_MODES:
        await conn.execute(
            """
            INSERT OR IGNORE INTO work_mode_defs (
                key, display_name, llm_profile_name, prompt_block_id,
                tmp_policy_json, policies_json, builtin, enabled, meta_json)
            VALUES (?, ?, ?, NULL, NULL, NULL, ?, 1, NULL)
            """,
            (
                row["key"],
                row["display_name"],
                row["llm_profile_name"],
                int(row["builtin"]),
            ),
        )
    await conn.commit()
