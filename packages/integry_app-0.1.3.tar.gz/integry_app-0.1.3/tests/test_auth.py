from __future__ import annotations

import json
import os
import stat
import time
from pathlib import Path

import pytest

from integry_cli import auth as auth_mod
from integry_cli.auth import Tokens, decode_jwt_claims, expires_in_seconds
from integry_cli.errors import AuthError


def test_decode_jwt_claims_roundtrip(jwt_access_token):
    claims = decode_jwt_claims(jwt_access_token)
    assert claims["user_id"] == 42


def test_expires_in_positive(jwt_access_token):
    remaining = expires_in_seconds(jwt_access_token)
    assert remaining is not None
    assert 0 < remaining <= 3600


def test_save_tokens_uses_0600_perms(config):
    tokens = Tokens(access="a", refresh="r", obtained_at=int(time.time()))
    auth_mod.save_tokens(config, tokens)
    mode = stat.S_IMODE(os.stat(config.credentials_path).st_mode)
    assert mode == 0o600


def test_load_tokens_returns_none_when_missing(config):
    assert auth_mod.load_tokens(config) is None


def test_clear_tokens_is_idempotent(config):
    assert auth_mod.clear_tokens(config) is False
    auth_mod.save_tokens(config, Tokens("a", "r", 0))
    assert auth_mod.clear_tokens(config) is True
    assert auth_mod.clear_tokens(config) is False


def test_login_posts_credentials_and_stores_tokens(config, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/token/",
        method="POST",
        json={"access": "ACCESS", "refresh": "REFRESH"},
    )
    tokens = auth_mod.login(config, "alice", "secret")
    assert tokens.access == "ACCESS"
    assert tokens.refresh == "REFRESH"
    stored = json.loads(config.credentials_path.read_text())
    assert stored["access"] == "ACCESS"


def test_login_401_raises_auth_error(config, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/token/",
        method="POST",
        status_code=401,
        json={"detail": "No active account"},
    )
    with pytest.raises(AuthError):
        auth_mod.login(config, "alice", "wrong")


def test_refresh_access_token_updates_access(config, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/token/refresh/",
        method="POST",
        json={"access": "NEW_ACCESS"},
    )
    tokens = auth_mod.refresh_access_token(config, "old_refresh")
    assert tokens.access == "NEW_ACCESS"
    assert tokens.refresh == "old_refresh"


def test_refresh_401_raises_auth_error(config, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/token/refresh/",
        method="POST",
        status_code=401,
        json={"detail": "Token is invalid"},
    )
    with pytest.raises(AuthError):
        auth_mod.refresh_access_token(config, "old_refresh")
