from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from integry_cli.cli import app

runner = CliRunner()

DRAFT_URL = "http://api.test/api/v2/templates/42/?return_as_draft=true"
PATCH_URL = "http://api.test/api/v5/templates/42/"


def _draft_response(steps: list | None = None, meta: dict | None = None) -> dict:
    return {
        "meta": meta or {"revision_number": 1, "app_id": 1, "title": "T"},
        "steps": steps if steps is not None else _sample_steps(),
    }


def _sample_steps() -> list:
    return [
        {
            "machine_name": "send_email",
            "title": "Send Email",
            "type": "ACTION",
            "weight": 0,
            "is_hidden": False,
            "fields": [
                {
                    "machine_name": "to",
                    "label": "To",
                    "type": "STRING",
                    "is_required": True,
                    "is_hidden": False,
                    "weight": 0,
                    "default_value": "test@example.com",
                },
                {
                    "machine_name": "subject",
                    "label": "Subject",
                    "type": "STRING",
                    "is_required": True,
                    "is_hidden": False,
                    "weight": 1,
                    "default_value": "Hello",
                },
            ],
            "steps": [],
        },
        {
            "machine_name": "log_result",
            "title": "Log Result",
            "type": "ACTION",
            "weight": 1,
            "is_hidden": False,
            "fields": [],
            "steps": [],
        },
    ]


def _nested_steps() -> list:
    return [
        {
            "machine_name": "loop_step",
            "title": "Loop",
            "type": "ACTION",
            "weight": 0,
            "is_hidden": False,
            "fields": [],
            "steps": [
                {
                    "machine_name": "inner_action",
                    "title": "Inner",
                    "type": "ACTION",
                    "weight": 0,
                    "is_hidden": False,
                    "fields": [
                        {
                            "machine_name": "body",
                            "label": "Body",
                            "type": "STRING",
                            "is_required": False,
                            "is_hidden": False,
                            "weight": 0,
                            "default_value": "old",
                        }
                    ],
                    "steps": [],
                },
            ],
        },
    ]


def _write_json(tmp_path: Path, name: str, data) -> Path:
    p = tmp_path / name
    p.write_text(json.dumps(data))
    return p


# ---------------------------------------------------------------------------
# list-steps
# ---------------------------------------------------------------------------


class TestListSteps:
    def test_lists_top_level_steps(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "list-steps"])
        assert result.exit_code == 0, result.output
        assert "send_email" in result.output
        assert "log_result" in result.output

    def test_lists_children_of_step(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response(_nested_steps()))
        result = runner.invoke(app, ["templates", "42", "list-steps", "loop_step"])
        assert result.exit_code == 0, result.output
        assert "inner_action" in result.output
        assert "loop_step" not in result.output.split("next:")[0].split("inner_action")[0]

    def test_empty_steps(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response([]))
        result = runner.invoke(app, ["templates", "42", "list-steps"])
        assert result.exit_code == 0, result.output
        assert "no steps" in result.output

    def test_step_not_found(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "list-steps", "nonexistent"])
        assert result.exit_code == 3

    def test_json_format(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "list-steps", "--format", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_tree_output(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response(_nested_steps()))
        result = runner.invoke(app, ["templates", "42", "list-steps"])
        assert result.exit_code == 0, result.output
        # Tree format shows step labels
        assert "loop_step (ACTION)" in result.output
        # Nested step is indented
        assert "    inner_action (ACTION)" in result.output
        # Title shown when different from machine_name
        assert '"Loop"' in result.output

    def test_tree_full_uses_toon(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "list-steps", "--full"])
        assert result.exit_code == 0, result.output
        # --full uses regular TOON, not tree
        assert "total: 2" in result.output


# ---------------------------------------------------------------------------
# get-step
# ---------------------------------------------------------------------------


class TestGetStep:
    def test_returns_step(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "get-step", "send_email"])
        assert result.exit_code == 0, result.output
        assert "send_email" in result.output
        assert "Send Email" in result.output

    def test_step_not_found(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "get-step", "nonexistent"])
        assert result.exit_code == 3

    def test_full_flag(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "get-step", "send_email", "--full"])
        assert result.exit_code == 0, result.output

    def test_json_format(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(
            app, ["templates", "42", "get-step", "send_email", "--format", "json"]
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["ok"] is True


# ---------------------------------------------------------------------------
# add-step
# ---------------------------------------------------------------------------


class TestAddStep:
    def test_appends_step(self, tmp_path, config, authenticated, httpx_mock):
        new_step = {"machine_name": "new_step", "title": "New", "type": "ACTION", "fields": [], "steps": []}
        input_file = _write_json(tmp_path, "step.json", new_step)
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(app, ["templates", "42", "add-step", "--input", str(input_file)])
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        assert len(body["steps"]) == 3
        assert body["steps"][2]["machine_name"] == "new_step"
        assert body["steps"][2]["weight"] == 2

    def test_inserts_at_position(self, tmp_path, config, authenticated, httpx_mock):
        new_step = {"machine_name": "new_step", "title": "New", "type": "ACTION", "fields": [], "steps": []}
        input_file = _write_json(tmp_path, "step.json", new_step)
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app, ["templates", "42", "add-step", "--input", str(input_file), "--at", "0"]
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        assert body["steps"][0]["machine_name"] == "new_step"
        assert body["steps"][0]["weight"] == 0
        assert body["steps"][1]["weight"] == 1

    def test_requires_input(self, config, authenticated, httpx_mock):
        result = runner.invoke(app, ["templates", "42", "add-step"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# update-step
# ---------------------------------------------------------------------------


class TestUpdateStep:
    def test_replaces_step(self, tmp_path, config, authenticated, httpx_mock):
        replacement = {
            "machine_name": "send_email",
            "title": "Send Email v2",
            "type": "ACTION",
            "fields": [],
            "steps": [],
        }
        input_file = _write_json(tmp_path, "step.json", replacement)
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app, ["templates", "42", "update-step", "send_email", "--input", str(input_file)]
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        updated = [s for s in body["steps"] if s["machine_name"] == "send_email"][0]
        assert updated["title"] == "Send Email v2"

    def test_step_not_found(self, tmp_path, config, authenticated, httpx_mock):
        input_file = _write_json(tmp_path, "step.json", {"machine_name": "x"})
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(
            app, ["templates", "42", "update-step", "nonexistent", "--input", str(input_file)]
        )
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# remove-step
# ---------------------------------------------------------------------------


class TestRemoveStep:
    def test_removes_step_cascade(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(app, ["templates", "42", "remove-step", "send_email"])
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        assert len(body["steps"]) == 1
        assert body["steps"][0]["machine_name"] == "log_result"
        assert body["steps"][0]["weight"] == 0

    def test_removes_step_no_cascade(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response(_nested_steps()))
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app, ["templates", "42", "remove-step", "loop_step", "--no-cascade"]
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        assert len(body["steps"]) == 1
        assert body["steps"][0]["machine_name"] == "inner_action"
        assert body["steps"][0]["weight"] == 0

    def test_step_not_found(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "remove-step", "nonexistent"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# move-step
# ---------------------------------------------------------------------------


class TestMoveStep:
    def test_reorder_within_parent(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(app, ["templates", "42", "move-step", "send_email", "--to", "1"])
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        assert body["steps"][0]["machine_name"] == "log_result"
        assert body["steps"][1]["machine_name"] == "send_email"
        assert body["steps"][0]["weight"] == 0
        assert body["steps"][1]["weight"] == 1

    def test_reparent_step(self, config, authenticated, httpx_mock):
        steps = _nested_steps() + [
            {
                "machine_name": "orphan",
                "title": "Orphan",
                "type": "ACTION",
                "weight": 1,
                "is_hidden": False,
                "fields": [],
                "steps": [],
            }
        ]
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response(steps))
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app,
            ["templates", "42", "move-step", "orphan", "--parent", "loop_step", "--at", "0"],
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        assert len(body["steps"]) == 1
        loop = body["steps"][0]
        assert loop["machine_name"] == "loop_step"
        assert len(loop["steps"]) == 2
        assert loop["steps"][0]["machine_name"] == "orphan"
        assert loop["steps"][1]["machine_name"] == "inner_action"

    def test_requires_to_or_parent(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "move-step", "send_email"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# list-fields
# ---------------------------------------------------------------------------


class TestListFields:
    def test_lists_fields(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "list-fields", "send_email"])
        assert result.exit_code == 0, result.output
        assert "to" in result.output
        assert "subject" in result.output

    def test_empty_fields(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "list-fields", "log_result"])
        assert result.exit_code == 0, result.output
        assert "no fields" in result.output

    def test_step_not_found(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "list-fields", "nonexistent"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# get-field
# ---------------------------------------------------------------------------


class TestGetField:
    def test_returns_field(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "get-field", "send_email:to"])
        assert result.exit_code == 0, result.output
        assert "test@example.com" in result.output

    def test_field_not_found(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "get-field", "send_email:nonexistent"])
        assert result.exit_code == 3

    def test_step_not_found(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        result = runner.invoke(app, ["templates", "42", "get-field", "nonexistent:to"])
        assert result.exit_code == 3

    def test_bad_format(self, config, authenticated, httpx_mock):
        result = runner.invoke(app, ["templates", "42", "get-field", "nocolon"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# set-field-value
# ---------------------------------------------------------------------------


class TestSetFieldValue:
    def test_sets_string_value(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app, ["templates", "42", "set-field-value", "send_email:to", "--value", "new@example.com"]
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        field = _find_field(body["steps"], "send_email", "to")
        assert field["default_value"] == "new@example.com"

    def test_sets_json_value(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app,
            ["templates", "42", "set-field-value", "send_email:to", "--value", '{"key": "val"}'],
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        field = _find_field(body["steps"], "send_email", "to")
        assert field["default_value"] == {"key": "val"}

    def test_preserves_other_fields(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app, ["templates", "42", "set-field-value", "send_email:to", "--value", "changed"]
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        field = _find_field(body["steps"], "send_email", "to")
        assert field["is_required"] is True
        assert field["label"] == "To"

    def test_requires_value(self, config, authenticated, httpx_mock):
        result = runner.invoke(app, ["templates", "42", "set-field-value", "send_email:to"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# update-field
# ---------------------------------------------------------------------------


class TestUpdateField:
    def test_replaces_field(self, tmp_path, config, authenticated, httpx_mock):
        replacement = {
            "machine_name": "to",
            "label": "Recipient",
            "type": "STRING",
            "is_required": False,
            "is_hidden": False,
            "weight": 0,
            "default_value": "updated@example.com",
        }
        input_file = _write_json(tmp_path, "field.json", replacement)
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app, ["templates", "42", "update-field", "send_email:to", "--input", str(input_file)]
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        field = _find_field(body["steps"], "send_email", "to")
        assert field["label"] == "Recipient"
        assert field["is_required"] is False


# ---------------------------------------------------------------------------
# add-field
# ---------------------------------------------------------------------------


class TestAddField:
    def test_appends_field(self, tmp_path, config, authenticated, httpx_mock):
        new_field = {
            "machine_name": "cc",
            "label": "CC",
            "type": "STRING",
            "is_required": False,
            "is_hidden": False,
            "default_value": None,
        }
        input_file = _write_json(tmp_path, "field.json", new_field)
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app, ["templates", "42", "add-field", "send_email", "--input", str(input_file)]
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        step = [s for s in body["steps"] if s["machine_name"] == "send_email"][0]
        assert len(step["fields"]) == 3
        assert step["fields"][2]["machine_name"] == "cc"
        assert step["fields"][2]["weight"] == 2

    def test_inserts_at_position(self, tmp_path, config, authenticated, httpx_mock):
        new_field = {"machine_name": "cc", "label": "CC", "type": "STRING"}
        input_file = _write_json(tmp_path, "field.json", new_field)
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app,
            ["templates", "42", "add-field", "send_email", "--input", str(input_file), "--at", "0"],
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        step = [s for s in body["steps"] if s["machine_name"] == "send_email"][0]
        assert step["fields"][0]["machine_name"] == "cc"


# ---------------------------------------------------------------------------
# remove-field
# ---------------------------------------------------------------------------


class TestRemoveField:
    def test_removes_field(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(app, ["templates", "42", "remove-field", "send_email:to"])
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        step = [s for s in body["steps"] if s["machine_name"] == "send_email"][0]
        assert len(step["fields"]) == 1
        assert step["fields"][0]["machine_name"] == "subject"
        assert step["fields"][0]["weight"] == 0


# ---------------------------------------------------------------------------
# move-field
# ---------------------------------------------------------------------------


class TestMoveField:
    def test_reorders_field(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response())
        httpx_mock.add_response(url=PATCH_URL, method="PATCH", json={"success": True})
        result = runner.invoke(
            app, ["templates", "42", "move-field", "send_email:to", "--to", "1"]
        )
        assert result.exit_code == 0, result.output
        req = [r for r in httpx_mock.get_requests() if r.method == "PATCH"][0]
        body = json.loads(req.content)
        step = [s for s in body["steps"] if s["machine_name"] == "send_email"][0]
        assert step["fields"][0]["machine_name"] == "subject"
        assert step["fields"][1]["machine_name"] == "to"
        assert step["fields"][0]["weight"] == 0
        assert step["fields"][1]["weight"] == 1


# ---------------------------------------------------------------------------
# diff-step
# ---------------------------------------------------------------------------

VERSION_URL = "http://api.test/api/v2/templates/42/?version=3"
GET_URL = "http://api.test/api/v2/templates/42/"


def _full_template(steps: list | None = None) -> dict:
    return {
        "meta": {"id": 42, "type": "FUNCTION", "publishing_status": "PUB"},
        "steps": steps if steps is not None else _sample_steps(),
    }


class TestDiffStep:
    def test_shows_field_changes(self, config, authenticated, httpx_mock):
        ver_steps = [
            {"machine_name": "s1", "title": "Step", "fields": [
                {"machine_name": "f1", "default_value": "old"},
                {"machine_name": "f2", "default_value": "same"},
            ], "steps": []},
        ]
        draft_steps = [
            {"machine_name": "s1", "title": "Step", "fields": [
                {"machine_name": "f1", "default_value": "new"},
                {"machine_name": "f2", "default_value": "same"},
            ], "steps": []},
        ]
        httpx_mock.add_response(url=VERSION_URL, json=_full_template(ver_steps))
        httpx_mock.add_response(url=GET_URL, json=_full_template(draft_steps))
        result = runner.invoke(app, ["templates", "42", "diff-step", "s1", "--version", "3"])
        assert result.exit_code == 0, result.output
        # Default shows changed props, not values
        assert "~ f1" in result.output
        assert "default_value" in result.output
        assert "1 unchanged" in result.output

    def test_shows_added_removed_fields(self, config, authenticated, httpx_mock):
        ver_steps = [
            {"machine_name": "s1", "title": "Step", "fields": [
                {"machine_name": "old_field", "default_value": "x"},
            ], "steps": []},
        ]
        draft_steps = [
            {"machine_name": "s1", "title": "Step", "fields": [
                {"machine_name": "new_field", "default_value": "y"},
            ], "steps": []},
        ]
        httpx_mock.add_response(url=VERSION_URL, json=_full_template(ver_steps))
        httpx_mock.add_response(url=GET_URL, json=_full_template(draft_steps))
        result = runner.invoke(app, ["templates", "42", "diff-step", "s1", "--version", "3"])
        assert result.exit_code == 0, result.output
        assert "+ new_field" in result.output
        assert "- old_field" in result.output

    def test_step_not_found(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=VERSION_URL, json=_full_template([]))
        httpx_mock.add_response(url=GET_URL, json=_full_template([]))
        result = runner.invoke(app, ["templates", "42", "diff-step", "nope", "--version", "3"])
        assert result.exit_code == 3

    def test_step_added_in_draft(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(url=VERSION_URL, json=_full_template([]))
        draft_steps = [{"machine_name": "new_step", "title": "New", "fields": [], "steps": []}]
        httpx_mock.add_response(url=GET_URL, json=_full_template(draft_steps))
        result = runner.invoke(app, ["templates", "42", "diff-step", "new_step", "--version", "3"])
        assert result.exit_code == 0, result.output
        assert "+ new_step" in result.output

    def test_json_format(self, config, authenticated, httpx_mock):
        ver_steps = [{"machine_name": "s1", "title": "S", "fields": [
            {"machine_name": "f1", "default_value": "old"},
        ], "steps": []}]
        draft_steps = [{"machine_name": "s1", "title": "S", "fields": [
            {"machine_name": "f1", "default_value": "new"},
        ], "steps": []}]
        httpx_mock.add_response(url=VERSION_URL, json=_full_template(ver_steps))
        httpx_mock.add_response(url=GET_URL, json=_full_template(draft_steps))
        result = runner.invoke(
            app, ["templates", "42", "diff-step", "s1", "--version", "3", "--format", "json"]
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["ok"] is True
        assert len(data["data"]["changed"]) == 1
        assert data["data"]["changed"][0]["field"] == "f1"


# ---------------------------------------------------------------------------
# Existing commands still work
# ---------------------------------------------------------------------------


class TestBackwardCompatibility:
    def test_templates_list_still_works(self, config, authenticated, httpx_mock):
        httpx_mock.add_response(
            url="http://api.test/api/v1/templates/",
            json={"count": 0, "results": []},
        )
        result = runner.invoke(app, ["templates", "list"])
        assert result.exit_code == 0, result.output

    def test_templates_create_still_works(self, tmp_path, config, authenticated, httpx_mock):
        body = {"meta": {"app_id": 1}}
        input_file = _write_json(tmp_path, "tpl.json", body)
        httpx_mock.add_response(
            url="http://api.test/api/v2/templates/",
            method="POST",
            json={"id": 99, "name": "New"},
        )
        result = runner.invoke(app, ["templates", "create", "--input", str(input_file)])
        assert result.exit_code == 0, result.output


# ---------------------------------------------------------------------------
# Help text
# ---------------------------------------------------------------------------


class TestHelp:
    def test_templates_help_shows_step_field_section(self):
        result = runner.invoke(app, ["templates", "--help"])
        assert result.exit_code == 0, result.output
        assert "Step & field operations" in result.output
        assert "list-steps" in result.output
        assert "set-field-value" in result.output
        assert "templates <id>" in result.output
        assert "machine_name" in result.output
        assert "step:field" in result.output

    def test_resource_group_help(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "--help"])
        assert result.exit_code == 0, result.output
        assert "list-steps" in result.output
        assert "get-step" in result.output
        assert "add-step" in result.output
        assert "update-step" in result.output
        assert "remove-step" in result.output
        assert "move-step" in result.output
        assert "list-fields" in result.output
        assert "get-field" in result.output
        assert "set-field-value" in result.output
        assert "update-field" in result.output
        assert "add-field" in result.output
        assert "remove-field" in result.output
        assert "move-field" in result.output

    def test_list_steps_help(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "list-steps", "--help"])
        assert result.exit_code == 0, result.output
        assert "PARENT_STEP" in result.output
        assert "--format" in result.output
        assert "--full" in result.output

    def test_get_step_help(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "get-step", "--help"])
        assert result.exit_code == 0, result.output
        assert "STEP_NAME" in result.output

    def test_add_step_help(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "add-step", "--help"])
        assert result.exit_code == 0, result.output
        assert "--input" in result.output
        assert "--at" in result.output

    def test_remove_step_help(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "remove-step", "--help"])
        assert result.exit_code == 0, result.output
        assert "--no-cascade" in result.output

    def test_move_step_help(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "move-step", "--help"])
        assert result.exit_code == 0, result.output
        assert "--to" in result.output
        assert "--parent" in result.output
        assert "--at" in result.output

    def test_set_field_value_help(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "set-field-value", "--help"])
        assert result.exit_code == 0, result.output
        assert "FIELD_REF" in result.output
        assert "--value" in result.output
        assert "step_name:field_name" in result.output

    def test_move_field_help(self, config, authenticated):
        result = runner.invoke(app, ["templates", "42", "move-field", "--help"])
        assert result.exit_code == 0, result.output
        assert "--to" in result.output
        assert "step_name:field_name" in result.output


# ---------------------------------------------------------------------------
# Output field sanitization
# ---------------------------------------------------------------------------


class TestRedundantKeyStripping:
    def test_step_operations_strip_redundant_keys(self, config, authenticated, httpx_mock):
        steps = [
            {
                "machine_name": "s1",
                "title": "S1",
                "type": "ACTION",
                "weight": 0,
                "is_hidden": False,
                "activity": {"id": 123},
                "authorization_type": {"id": 1},
                "test_output": "stale",
                "fields": [
                    {
                        "machine_name": "f1",
                        "activity_field_id": 999,
                        "default_value": "val",
                        "weight": 0,
                        "classname": "x",
                        "test_value": "tv",
                    }
                ],
                "steps": [],
            }
        ]
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response(steps))
        result = runner.invoke(
            app, ["templates", "42", "get-step", "s1", "--format", "json", "--full"]
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)["data"]
        assert "activity" not in data
        assert "test_output" not in data
        assert "classname" not in data["fields"][0]
        assert data["fields"][0]["default_value"] == "val"


class TestOutputFieldSanitization:
    def test_get_step_sanitizes_output_fields(self, config, authenticated, httpx_mock):
        steps = [
            {
                "machine_name": "code_step",
                "title": "Code",
                "type": "ACTION",
                "weight": 0,
                "is_hidden": False,
                "fields": [
                    {
                        "machine_name": "code",
                        "activity_field_id": 999,
                        "default_value": "print('hello')",
                        "weight": 0,
                    },
                    {
                        "machine_name": "output",
                        "activity_field_id": 152552,
                        "default_value": "stale_test_output",
                        "weight": 1,
                    },
                ],
                "steps": [],
            }
        ]
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response(steps))
        result = runner.invoke(
            app, ["templates", "42", "get-step", "code_step", "--format", "json", "--full"]
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)["data"]
        output_field = [f for f in data["fields"] if f["machine_name"] == "output"][0]
        assert output_field["default_value"] == ""
        code_field = [f for f in data["fields"] if f["machine_name"] == "code"][0]
        assert code_field["default_value"] == "print('hello')"

    def test_get_field_sanitizes_output_field(self, config, authenticated, httpx_mock):
        steps = [
            {
                "machine_name": "http_step",
                "title": "HTTP",
                "type": "ACTION",
                "weight": 0,
                "is_hidden": False,
                "fields": [
                    {
                        "machine_name": "output",
                        "activity_field_id": 116460,
                        "default_value": "stale",
                        "weight": 0,
                    },
                ],
                "steps": [],
            }
        ]
        httpx_mock.add_response(url=DRAFT_URL, json=_draft_response(steps))
        result = runner.invoke(
            app, ["templates", "42", "get-field", "http_step:output", "--format", "json", "--full"]
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)["data"]
        assert data["default_value"] == ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _find_field(steps: list, step_name: str, field_name: str) -> dict:
    for step in steps:
        if step.get("machine_name") == step_name:
            for field in step.get("fields", []):
                if field.get("machine_name") == field_name:
                    return field
        found = _find_field(step.get("steps", []), step_name, field_name)
        if found:
            return found
    return {}
