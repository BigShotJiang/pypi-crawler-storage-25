from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from integry_cli.cli import app
from integry_cli.config import load_config

runner = CliRunner()


# ---------------------------------------------------------------------------
# Config: persisted account_id + env override
# ---------------------------------------------------------------------------


def test_config_account_id_defaults_to_none(integry_home):
    cfg = load_config()
    assert cfg.account_id is None


def test_config_reads_persisted_account_id(integry_home):
    (integry_home / "config.json").write_text(
        json.dumps({"api_url": "http://api.test", "account_id": 7})
    )
    cfg = load_config()
    assert cfg.account_id == 7


def test_env_var_overrides_persisted_account_id(integry_home, monkeypatch):
    (integry_home / "config.json").write_text(
        json.dumps({"api_url": "http://api.test", "account_id": 7})
    )
    monkeypatch.setenv("INTEGRY_ACCOUNT_ID", "11")
    cfg = load_config()
    assert cfg.account_id == 11


def test_env_var_invalid_value_is_ignored(integry_home, monkeypatch):
    monkeypatch.setenv("INTEGRY_ACCOUNT_ID", "not-an-int")
    cfg = load_config()
    assert cfg.account_id is None


# ---------------------------------------------------------------------------
# ApiClient sends X-Account-Id header
# ---------------------------------------------------------------------------


def test_request_sends_x_account_id_header_when_set(
    integry_home, authenticated, httpx_mock, monkeypatch
):
    monkeypatch.setenv("INTEGRY_ACCOUNT_ID", "55")
    config = load_config()

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json={"id": 42, "meta": {"publishing_status": "PUB"}},
    )
    result = runner.invoke(app, ["templates", "get", "42"])
    assert result.exit_code == 0, result.output

    req = httpx_mock.get_request()
    assert req.headers.get("x-account-id") == "55"


def test_request_omits_header_when_unset(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json={"id": 42, "meta": {"publishing_status": "PUB"}},
    )
    result = runner.invoke(app, ["templates", "get", "42"])
    assert result.exit_code == 0, result.output

    req = httpx_mock.get_request()
    assert "x-account-id" not in {k.lower() for k in req.headers.keys()}


# ---------------------------------------------------------------------------
# `integry accounts use|clear|current` commands
# ---------------------------------------------------------------------------


def test_accounts_use_persists_account_id(integry_home):
    result = runner.invoke(app, ["accounts", "use", "7"])
    assert result.exit_code == 0, result.output
    stored = json.loads((integry_home / "config.json").read_text())
    assert stored["account_id"] == 7
    assert "account_id: 7" in result.output
    # Once an account is selected, the natural next action is to list templates.
    assert "next: integry templates list" in result.output


def test_accounts_use_overwrites_existing(integry_home):
    (integry_home / "config.json").write_text(
        json.dumps({"api_url": "http://api.test", "account_id": 1})
    )
    result = runner.invoke(app, ["accounts", "use", "9"])
    assert result.exit_code == 0, result.output
    stored = json.loads((integry_home / "config.json").read_text())
    assert stored["account_id"] == 9


def test_accounts_clear_removes_account_id(integry_home):
    (integry_home / "config.json").write_text(
        json.dumps({"api_url": "http://api.test", "account_id": 7})
    )
    result = runner.invoke(app, ["accounts", "clear"])
    assert result.exit_code == 0, result.output
    stored = json.loads((integry_home / "config.json").read_text())
    assert "account_id" not in stored
    assert "cleared: true" in result.output


def test_accounts_clear_is_idempotent(integry_home):
    result = runner.invoke(app, ["accounts", "clear"])
    assert result.exit_code == 0, result.output
    assert "cleared: false" in result.output


def test_accounts_current_shows_active_account(integry_home, monkeypatch):
    monkeypatch.setenv("INTEGRY_ACCOUNT_ID", "55")
    result = runner.invoke(app, ["accounts", "current"])
    assert result.exit_code == 0, result.output
    assert "account_id: 55" in result.output
    assert "source: env" in result.output


def test_accounts_current_reports_stored_source(integry_home):
    (integry_home / "config.json").write_text(
        json.dumps({"api_url": "http://api.test", "account_id": 7})
    )
    result = runner.invoke(app, ["accounts", "current"])
    assert result.exit_code == 0, result.output
    assert "account_id: 7" in result.output
    assert "source: config" in result.output


def test_accounts_current_unset_exits_3(integry_home):
    result = runner.invoke(app, ["accounts", "current"])
    assert result.exit_code == 3
    assert "no account selected" in result.output


# ---------------------------------------------------------------------------
# Surfaces in `auth status` and ambient state
# ---------------------------------------------------------------------------


def test_auth_status_includes_account_id(integry_home, authenticated, monkeypatch):
    monkeypatch.setenv("INTEGRY_ACCOUNT_ID", "12")
    result = runner.invoke(app, ["auth", "status"])
    assert result.exit_code == 0, result.output
    assert "account_id: 12" in result.output


def test_ambient_state_includes_account_id(integry_home, authenticated, monkeypatch):
    monkeypatch.setenv("INTEGRY_ACCOUNT_ID", "12")
    result = runner.invoke(app, [])
    assert result.exit_code == 0, result.output
    assert "account_id: 12" in result.output


# ---------------------------------------------------------------------------
# `integry accounts list`
# ---------------------------------------------------------------------------


def test_accounts_list_renders_table(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/accounts/me/",
        method="GET",
        json={
            "id": 42,
            "username": "alice",
            "accounts": [
                {"id": 7, "name": "Acme", "is_currently_selected": True, "icon_url": ""},
                {"id": 9, "name": "Beta Co", "is_currently_selected": False, "icon_url": ""},
            ],
        },
    )
    result = runner.invoke(app, ["accounts", "list"])
    assert result.exit_code == 0, result.output
    assert "total: 2" in result.output
    assert "id" in result.output and "name" in result.output and "is_currently_selected" in result.output
    assert "Acme" in result.output and "Beta Co" in result.output
    assert "next: integry accounts use" in result.output


def test_accounts_list_empty_state(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/accounts/me/",
        method="GET",
        json={"id": 42, "username": "alice", "accounts": []},
    )
    result = runner.invoke(app, ["accounts", "list"])
    assert result.exit_code == 0, result.output
    assert "no accounts" in result.output.lower()


def test_accounts_list_json_envelope(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/accounts/me/",
        method="GET",
        json={
            "id": 42,
            "accounts": [
                {"id": 7, "name": "Acme", "is_currently_selected": True, "icon_url": ""},
            ],
        },
    )
    result = runner.invoke(app, ["accounts", "list", "--format", "json"])
    assert result.exit_code == 0, result.output
    parsed = json.loads(result.output.strip())
    assert parsed["ok"] is True
    assert parsed["data"]["total"] == 1
    assert parsed["data"]["accounts"][0]["id"] == 7


def test_accounts_list_unauthenticated_exits_2(integry_home):
    result = runner.invoke(app, ["accounts", "list"])
    assert result.exit_code == 2
    assert "integry auth login" in result.output


def test_accounts_list_search_filters_by_name_case_insensitive(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/accounts/me/",
        method="GET",
        json={
            "id": 42,
            "accounts": [
                {"id": 1, "name": "Acme", "is_currently_selected": False, "icon_url": ""},
                {"id": 2, "name": "Beta Co", "is_currently_selected": False, "icon_url": ""},
                {"id": 3, "name": "betamax", "is_currently_selected": True, "icon_url": ""},
            ],
        },
    )
    result = runner.invoke(app, ["accounts", "list", "--search", "BETA"])
    assert result.exit_code == 0, result.output
    assert "total: 2" in result.output
    assert "Beta Co" in result.output
    assert "betamax" in result.output
    assert "Acme" not in result.output


def test_accounts_list_search_no_matches(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/accounts/me/",
        method="GET",
        json={
            "id": 42,
            "accounts": [
                {"id": 1, "name": "Acme", "is_currently_selected": True, "icon_url": ""},
            ],
        },
    )
    result = runner.invoke(app, ["accounts", "list", "--search", "zzz"])
    assert result.exit_code == 0, result.output
    assert "no accounts match 'zzz'" in result.output


def test_accounts_list_pagination_slices_client_side(
    config, authenticated, httpx_mock
):
    rows = [
        {"id": i, "name": f"acct-{i:02d}", "is_currently_selected": False, "icon_url": ""}
        for i in range(1, 8)
    ]
    httpx_mock.add_response(
        url=f"{config.api_url}/accounts/me/",
        method="GET",
        json={"id": 42, "accounts": rows},
    )
    result = runner.invoke(
        app, ["accounts", "list", "--page", "2", "--page-size", "3"]
    )
    assert result.exit_code == 0, result.output
    # total reflects the *unpaginated* count, not the slice
    assert "total: 7" in result.output
    # page 2 of size 3 → ids 4, 5, 6
    assert "acct-04" in result.output
    assert "acct-05" in result.output
    assert "acct-06" in result.output
    # rows from other pages should be absent
    assert "acct-01" not in result.output
    assert "acct-07" not in result.output


def test_accounts_list_pagination_after_search(
    config, authenticated, httpx_mock
):
    rows = [
        {"id": i, "name": f"beta-{i:02d}" if i % 2 else f"acme-{i:02d}",
         "is_currently_selected": False, "icon_url": ""}
        for i in range(1, 11)
    ]
    httpx_mock.add_response(
        url=f"{config.api_url}/accounts/me/",
        method="GET",
        json={"id": 42, "accounts": rows},
    )
    result = runner.invoke(
        app,
        [
            "accounts", "list",
            "--search", "beta",
            "--page", "1", "--page-size", "2",
        ],
    )
    assert result.exit_code == 0, result.output
    # 5 odd ids: 1,3,5,7,9 → all named beta-XX
    assert "total: 5" in result.output
    assert "beta-01" in result.output
    assert "beta-03" in result.output
    assert "beta-05" not in result.output


def test_accounts_list_search_json_envelope_includes_query(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/accounts/me/",
        method="GET",
        json={
            "id": 42,
            "accounts": [
                {"id": 1, "name": "Acme", "is_currently_selected": True, "icon_url": ""},
                {"id": 2, "name": "Beta Co", "is_currently_selected": False, "icon_url": ""},
            ],
        },
    )
    result = runner.invoke(
        app, ["accounts", "list", "--search", "acme", "--format", "json"]
    )
    assert result.exit_code == 0, result.output
    parsed = json.loads(result.output.strip())
    assert parsed["ok"] is True
    assert parsed["data"]["total"] == 1
    assert parsed["data"]["query"] == "acme"
    assert parsed["data"]["accounts"][0]["id"] == 1
