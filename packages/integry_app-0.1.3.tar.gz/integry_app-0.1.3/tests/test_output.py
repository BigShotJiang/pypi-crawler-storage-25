from __future__ import annotations

import io
import json
import sys

import pytest

from integry_cli.errors import ApiError, UsageError
from integry_cli.output import print_error, print_success, to_toon, truncate


def _capture(func, *args, **kwargs) -> str:
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        func(*args, **kwargs)
    finally:
        sys.stdout = old
    return buf.getvalue()


def test_toon_scalars():
    assert to_toon(None) == "null"
    assert to_toon(True) == "true"
    assert to_toon(42) == "42"
    assert to_toon("plain") == "plain"
    assert to_toon("has: colon") == '"has: colon"'


def test_toon_dict_flat():
    out = to_toon({"id": 1, "name": "hello"})
    assert out == "id: 1\nname: hello"


def test_toon_dict_nested():
    out = to_toon({"id": 1, "meta": {"a": 2}})
    assert "id: 1" in out
    assert "meta:" in out
    assert "  a: 2" in out


def test_toon_homogeneous_list_uses_table_form():
    rows = [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}]
    out = to_toon(rows)
    assert out.startswith("[2] id,name:")
    assert "1,a" in out
    assert "2,b" in out


def test_toon_heterogeneous_list_uses_bullets():
    out = to_toon([1, "two", {"k": 3}])
    assert "- 1" in out
    assert "- two" in out


def test_truncate_adds_hint_with_total_length():
    long = "x" * 500
    out = truncate(long)
    assert out.startswith("x" * 400)
    assert "truncated, 500 chars total" in out
    assert "--full" in out


def test_print_success_toon_includes_next_hints(capsys):
    print_success({"id": 1, "name": "t"}, fmt="toon", next_hints=["integry templates update 1 --input patch.json"])
    out = capsys.readouterr().out
    assert "id: 1" in out
    assert "next: integry templates update 1" in out


def test_print_success_json_envelope(capsys):
    print_success({"id": 1}, fmt="json", next_hints=["integry x"])
    out = capsys.readouterr().out.strip()
    parsed = json.loads(out)
    assert parsed == {"ok": True, "data": {"id": 1}, "next": ["integry x"]}


def test_print_success_entity_filters_default_fields(capsys):
    payload = {
        "id": 7,
        "name": "T",
        "app_id": 3,
        "publishing_status": "DR",
        "revision_number": "abc",
        "extra_noise": "x" * 50,
    }
    print_success(payload, fmt="toon", entity="template")
    out = capsys.readouterr().out
    assert "id: 7" in out
    assert "extra_noise" not in out


def test_print_success_full_skips_filtering(capsys):
    payload = {"id": 7, "name": "T", "extra_noise": "y"}
    print_success(payload, fmt="toon", entity="template", full=True)
    out = capsys.readouterr().out
    assert "extra_noise: y" in out


def test_print_error_toon_shape(capsys):
    err = ApiError("bad request", status=400, detail={"field": "missing"})
    print_error(err, fmt="toon")
    out = capsys.readouterr().out
    assert out.startswith("error: api_error: bad request\n")
    assert "field: missing" in out


def test_print_error_json_envelope(capsys):
    err = UsageError("oops")
    print_error(err, fmt="json")
    out = capsys.readouterr().out.strip()
    parsed = json.loads(out)
    assert parsed == {"ok": False, "error": {"code": "usage_error", "message": "oops"}}
