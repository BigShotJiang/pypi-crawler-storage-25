from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from integry_cli.cli import app

runner = CliRunner()


def _write_json(tmp_path: Path, name: str, payload: dict) -> Path:
    p = tmp_path / name
    p.write_text(json.dumps(payload))
    return p


def test_create_posts_body_verbatim(
    tmp_path, config, authenticated, httpx_mock
):
    body = {"meta": {"title": "T", "app_id": 1}, "trigger": {}, "actions": []}
    input_file = _write_json(tmp_path, "create.json", body)

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/",
        method="POST",
        json={"id": 99, "meta": {"title": "T", "app_id": 1, "publishing_status": "DR", "revision_number": "r1"}},
    )

    result = runner.invoke(app, ["templates", "create", "--input", str(input_file)])
    assert result.exit_code == 0, result.output
    assert "id: 99" in result.output
    assert "next: integry templates update 99" in result.output

    req = httpx_mock.get_request()
    assert json.loads(req.content) == body


def test_create_publish_appends_query_param(
    tmp_path, config, authenticated, httpx_mock
):
    body = {"meta": {"title": "T", "app_id": 1}, "trigger": {}, "actions": []}
    input_file = _write_json(tmp_path, "create.json", body)

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/?publish=true",
        method="POST",
        json={"id": 1, "meta": {"publishing_status": "PUB"}},
    )
    result = runner.invoke(
        app, ["templates", "create", "--input", str(input_file), "--publish"]
    )
    assert result.exit_code == 0, result.output


def test_update_sends_patch_with_query_params(
    tmp_path, config, authenticated, httpx_mock
):
    body = {"meta": {"app_id": 1, "revision_number": 7}}
    input_file = _write_json(tmp_path, "patch.json", body)

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v5/templates/42/?version=3&publish=true",
        method="PATCH",
        json={"id": 42, "meta": {"revision_number": 8, "app_id": 1, "publishing_status": "PUB"}},
    )
    result = runner.invoke(
        app,
        [
            "templates",
            "update",
            "42",
            "--input",
            str(input_file),
            "--version",
            "3",
            "--publish",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "id: 42" in result.output
    assert "publishing_status: PUB" in result.output


def test_update_meta_only_uses_exclude_flag(
    tmp_path, config, authenticated, httpx_mock
):
    body = {"meta": {"app_id": 1, "revision_number": 7}}
    input_file = _write_json(tmp_path, "patch.json", body)

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v5/templates/42/?exclude_template_from_response=true",
        method="PATCH",
        json={"success": True},
    )
    result = runner.invoke(
        app,
        ["templates", "update", "42", "--input", str(input_file), "--meta-only"],
    )
    assert result.exit_code == 0, result.output
    assert "success: true" in result.output


def test_update_revision_flag_merges_into_meta(
    tmp_path, config, authenticated, httpx_mock
):
    body = {"meta": {"app_id": 1}}
    input_file = _write_json(tmp_path, "patch.json", body)

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v5/templates/42/",
        method="PATCH",
        json={"id": 42, "meta": {"revision_number": 12, "app_id": 1}},
    )
    result = runner.invoke(
        app,
        ["templates", "update", "42", "--input", str(input_file), "--revision", "11"],
    )
    assert result.exit_code == 0, result.output
    sent = json.loads(httpx_mock.get_request().content)
    assert sent["meta"]["revision_number"] == 11


def test_update_meta_only_with_steps_is_rejected(tmp_path, config, authenticated):
    body = {"meta": {"app_id": 1, "revision_number": 7}, "steps": []}
    input_file = _write_json(tmp_path, "patch.json", body)

    result = runner.invoke(
        app,
        ["templates", "update", "42", "--input", str(input_file), "--meta-only"],
    )
    assert result.exit_code == 3
    assert "--meta-only" in result.output


def test_missing_input_file_exits_3(tmp_path, config, authenticated):
    result = runner.invoke(
        app, ["templates", "create", "--input", str(tmp_path / "no.json")]
    )
    assert result.exit_code == 3
    assert "input file not found" in result.output


def test_not_authenticated_exits_2(tmp_path, config):
    body = {"meta": {"title": "T", "app_id": 1}, "trigger": {}, "actions": []}
    input_file = _write_json(tmp_path, "create.json", body)
    result = runner.invoke(app, ["templates", "create", "--input", str(input_file)])
    assert result.exit_code == 2
    assert "integry auth login" in result.output


def test_401_triggers_refresh_then_retries(
    tmp_path, config, authenticated, httpx_mock
):
    body = {"meta": {"title": "T", "app_id": 1}, "trigger": {}, "actions": []}
    input_file = _write_json(tmp_path, "create.json", body)

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/",
        method="POST",
        status_code=401,
        json={"detail": "expired"},
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/token/refresh/",
        method="POST",
        json={"access": "NEWACCESS"},
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/",
        method="POST",
        json={"id": 5, "meta": {"publishing_status": "DR"}},
    )

    result = runner.invoke(app, ["templates", "create", "--input", str(input_file)])
    assert result.exit_code == 0, result.output


def test_401_twice_exits_2(tmp_path, config, authenticated, httpx_mock):
    body = {"meta": {"title": "T", "app_id": 1}, "trigger": {}, "actions": []}
    input_file = _write_json(tmp_path, "create.json", body)

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/",
        method="POST",
        status_code=401,
        json={"detail": "expired"},
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/token/refresh/",
        method="POST",
        json={"access": "NEWACCESS"},
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/",
        method="POST",
        status_code=401,
        json={"detail": "still expired"},
    )
    result = runner.invoke(app, ["templates", "create", "--input", str(input_file)])
    assert result.exit_code == 2
    assert "session expired" in result.output


def test_api_400_exits_1_with_detail(tmp_path, config, authenticated, httpx_mock):
    body = {"meta": {"app_id": 1, "revision_number": 1}}
    input_file = _write_json(tmp_path, "patch.json", body)

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v5/templates/42/",
        method="PATCH",
        status_code=400,
        json={"meta": "Must be valid"},
    )
    result = runner.invoke(
        app, ["templates", "update", "42", "--input", str(input_file)]
    )
    assert result.exit_code == 1
    assert "error: api_error" in result.output
    assert "meta: Must be valid" in result.output


# ---------------------------------------------------------------------------
# templates get
# ---------------------------------------------------------------------------


def test_get_returns_filtered_template(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json={
            "id": 42,
            "meta": {
                "title": "T",
                "app_id": 1,
                "publishing_status": "PUB",
                "revision_number": "r9",
            },
            "steps": [],
        },
    )
    result = runner.invoke(app, ["templates", "get", "42"])
    assert result.exit_code == 0, result.output
    # Default TOON is now a tree summary header
    assert "42" in result.output
    assert "PUB" in result.output
    assert "next: integry templates list-versions 42" in result.output


def test_get_with_version_uses_version_endpoint(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/3/",
        method="GET",
        json={
            "id": 99,
            "version": 3,
            "publishing_status": "PUB",
            "is_live": True,
            "integration_count": 5,
            "changelog": "fix",
        },
    )
    result = runner.invoke(app, ["templates", "get", "42", "--version", "3"])
    assert result.exit_code == 0, result.output
    assert "id: 99" in result.output
    assert "version: 3" in result.output
    assert "next: integry templates get-draft 42 --version 3" in result.output


def test_get_full_skips_filtering(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json={"id": 42, "name": "T", "extra": "kept"},
    )
    result = runner.invoke(app, ["templates", "get", "42", "--full"])
    assert result.exit_code == 0, result.output
    assert "extra: kept" in result.output


def test_get_404_exits_1(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        status_code=404,
        json={"detail": "Not found."},
    )
    result = runner.invoke(app, ["templates", "get", "42"])
    assert result.exit_code == 1
    assert "error: api_error" in result.output


# ---------------------------------------------------------------------------
# templates list-versions
# ---------------------------------------------------------------------------


def test_list_versions_renders_table_with_total(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/",
        method="GET",
        json={
            "count": 2,
            "next": None,
            "previous": None,
            "results": [
                {
                    "id": 100,
                    "version": 2,
                    "publishing_status": "PUB",
                    "is_live": True,
                    "integration_count": 3,
                    "changelog": "second",
                },
                {
                    "id": 99,
                    "version": 1,
                    "publishing_status": "DR",
                    "is_live": False,
                    "integration_count": 0,
                    "changelog": "first",
                },
            ],
        },
    )
    result = runner.invoke(app, ["templates", "list-versions", "42"])
    assert result.exit_code == 0, result.output
    assert "total: 2" in result.output
    assert "id" in result.output and "version" in result.output
    assert "100" in result.output and "99" in result.output
    assert "next: integry templates publish 42" in result.output


def test_list_versions_empty_state(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/",
        method="GET",
        json={"count": 0, "next": None, "previous": None, "results": []},
    )
    result = runner.invoke(app, ["templates", "list-versions", "42"])
    assert result.exit_code == 0, result.output
    assert "no versions" in result.output.lower()
    assert "next: integry templates publish 42" in result.output


def test_list_versions_pagination_flags_forwarded(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/?page=2&page_size=5",
        method="GET",
        json={"count": 12, "results": []},
    )
    result = runner.invoke(
        app,
        ["templates", "list-versions", "42", "--page", "2", "--page-size", "5"],
    )
    assert result.exit_code == 0, result.output


def test_list_versions_total_reflects_unpaginated_count(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/?page_size=2",
        method="GET",
        json={
            "count": 12,
            "results": [
                {"id": 100, "version": 12, "publishing_status": "PUB", "is_live": True, "integration_count": 0, "changelog": ""},
                {"id": 99, "version": 11, "publishing_status": "PUB", "is_live": False, "integration_count": 0, "changelog": ""},
            ],
        },
    )
    result = runner.invoke(
        app, ["templates", "list-versions", "42", "--page-size", "2"]
    )
    assert result.exit_code == 0, result.output
    assert "total: 12" in result.output


def test_list_versions_json_envelope(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/",
        method="GET",
        json={
            "count": 1,
            "results": [
                {"id": 1, "version": 1, "publishing_status": "PUB", "is_live": True, "integration_count": 0, "changelog": ""}
            ],
        },
    )
    result = runner.invoke(app, ["templates", "list-versions", "42", "--format", "json"])
    assert result.exit_code == 0, result.output
    parsed = json.loads(result.output.strip())
    assert parsed["ok"] is True
    assert parsed["data"]["total"] == 1
    assert len(parsed["data"]["versions"]) == 1


# ---------------------------------------------------------------------------
# templates publish
# ---------------------------------------------------------------------------


def test_publish_posts_empty_body_when_no_changelog(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/",
        method="POST",
        status_code=201,
        json={"id": 100, "meta": {"title": "T", "app_id": 1, "publishing_status": "PUB", "revision_number": "r1"}},
    )
    result = runner.invoke(app, ["templates", "publish", "42"])
    assert result.exit_code == 0, result.output
    assert "id: 100" in result.output
    sent = json.loads(httpx_mock.get_request().content or b"{}")
    assert "changelog" not in sent


def test_publish_with_changelog_includes_body(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/",
        method="POST",
        status_code=201,
        json={"id": 100, "meta": {"publishing_status": "PUB"}},
    )
    result = runner.invoke(
        app, ["templates", "publish", "42", "--changelog", "Fixed the bug"]
    )
    assert result.exit_code == 0, result.output
    sent = json.loads(httpx_mock.get_request().content)
    assert sent == {"changelog": "Fixed the bug"}


def test_publish_beta_appends_query_param(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/?publish_for_beta_users=true",
        method="POST",
        status_code=201,
        json={"id": 100, "meta": {}},
    )
    result = runner.invoke(app, ["templates", "publish", "42", "--beta"])
    assert result.exit_code == 0, result.output


def test_publish_upgrade_integrations_appends_query_param(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/?upgrade_integrations=true",
        method="POST",
        status_code=201,
        json={"id": 100, "meta": {}},
    )
    result = runner.invoke(
        app, ["templates", "publish", "42", "--upgrade-integrations"]
    )
    assert result.exit_code == 0, result.output


def test_publish_combined_flags_send_both_query_params(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/?publish_for_beta_users=true&upgrade_integrations=true",
        method="POST",
        status_code=201,
        json={"id": 100, "meta": {}},
    )
    result = runner.invoke(
        app,
        [
            "templates",
            "publish",
            "42",
            "--beta",
            "--upgrade-integrations",
            "--changelog",
            "x",
        ],
    )
    assert result.exit_code == 0, result.output
    sent = json.loads(httpx_mock.get_request().content)
    assert sent == {"changelog": "x"}


def test_publish_400_exits_1_with_detail(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/42/versions/",
        method="POST",
        status_code=400,
        json="External actions are not supported in versioned flows. Please replace them with steps using your auth.",
    )
    result = runner.invoke(app, ["templates", "publish", "42"])
    assert result.exit_code == 1
    assert "External actions are not supported" in result.output


# ---------------------------------------------------------------------------
# templates get-draft
# ---------------------------------------------------------------------------


def test_get_draft_appends_return_as_draft(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?return_as_draft=true&version=3",
        method="GET",
        json={
            "meta": {
                "title": "T",
                "app_id": 1,
                "publishing_status": "DR",
                "id": 42,
                "version_template_id": 99,
            },
            "steps": [{"name": "a"}, {"name": "b"}],
        },
    )
    result = runner.invoke(app, ["templates", "get-draft", "42", "--version", "3"])
    assert result.exit_code == 0, result.output
    assert "title: T" in result.output
    assert "step_count: 2" in result.output
    assert "next: integry templates create" in result.output


def test_get_draft_latest_version_no_version_flag(config, authenticated, httpx_mock):
    """Without --version, get-draft fetches the base template as draft."""
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?return_as_draft=true",
        method="GET",
        json={
            "meta": {"title": "T", "app_id": 1, "publishing_status": "DR"},
            "steps": [{"name": "a"}],
        },
    )
    result = runner.invoke(app, ["templates", "get-draft", "42"])
    assert result.exit_code == 0, result.output
    assert "title: T" in result.output


def test_get_draft_full_returns_complete_payload(
    config, authenticated, httpx_mock
):
    payload = {
        "meta": {"title": "T", "app_id": 1, "publishing_status": "DR"},
        "steps": [{"name": "a"}],
    }
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?return_as_draft=true",
        method="GET",
        json=payload,
    )
    result = runner.invoke(app, ["templates", "get-draft", "42", "--full"])
    assert result.exit_code == 0, result.output
    assert "steps:" in result.output


# ---------------------------------------------------------------------------
# templates list
# ---------------------------------------------------------------------------


def _list_response(rows, count=None, **extra):
    return {
        "count": count if count is not None else len(rows),
        "links": {"next": None, "previous": None},
        "results": rows,
        **extra,
    }


def test_list_templates_renders_table_with_machine_name(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/",
        method="GET",
        json=_list_response([
            {
                "id": 1,
                "name": "send_email",
                "type": "FUNCTION",
                "machine_name": "send_email",
                "publishing_status": "PUB",
                "revision_number": "r3",
            },
            {
                "id": 2,
                "name": "Onboarding",
                "type": "STANDARD",
                "machine_name": None,
                "publishing_status": "DR",
                "revision_number": "r1",
            },
        ]),
    )
    result = runner.invoke(app, ["templates", "list"])
    assert result.exit_code == 0, result.output
    assert "total: 2" in result.output
    assert "machine_name" in result.output
    assert "send_email" in result.output
    assert "FUNCTION" in result.output
    assert "next: integry templates get" in result.output


def test_list_templates_search_param_forwarded(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/?search=email",
        method="GET",
        json=_list_response([
            {
                "id": 1,
                "name": "send_email",
                "type": "FUNCTION",
                "machine_name": "send_email",
                "publishing_status": "PUB",
                "revision_number": "r1",
            }
        ]),
    )
    result = runner.invoke(app, ["templates", "list", "--search", "email"])
    assert result.exit_code == 0, result.output
    assert "send_email" in result.output


def test_list_templates_type_filter_joins_with_comma(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/?types=FUNCTION%2CACTION",
        method="GET",
        json=_list_response([]),
    )
    result = runner.invoke(
        app,
        ["templates", "list", "--type", "FUNCTION", "--type", "ACTION"],
    )
    assert result.exit_code == 0, result.output


def test_list_templates_empty_state(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/",
        method="GET",
        json=_list_response([], count=0),
    )
    result = runner.invoke(app, ["templates", "list"])
    assert result.exit_code == 0, result.output
    assert "no templates" in result.output.lower()


def test_list_templates_empty_state_with_filter_mentions_filter(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/?search=zzz&types=FUNCTION",
        method="GET",
        json=_list_response([], count=0),
    )
    result = runner.invoke(
        app, ["templates", "list", "--search", "zzz", "--type", "FUNCTION"]
    )
    assert result.exit_code == 0, result.output
    assert "no templates match" in result.output.lower()


def test_list_templates_json_envelope(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/?search=fn&types=FUNCTION",
        method="GET",
        json=_list_response([
            {
                "id": 7,
                "name": "fn",
                "type": "FUNCTION",
                "machine_name": "fn",
                "publishing_status": "PUB",
                "revision_number": "r1",
            }
        ], count=1),
    )
    result = runner.invoke(
        app,
        [
            "templates",
            "list",
            "--search",
            "fn",
            "--type",
            "FUNCTION",
            "--format",
            "json",
        ],
    )
    assert result.exit_code == 0, result.output
    parsed = json.loads(result.output.strip())
    assert parsed["ok"] is True
    assert parsed["data"]["total"] == 1
    assert parsed["data"]["query"] == "fn"
    assert parsed["data"]["types"] == ["FUNCTION"]
    assert parsed["data"]["templates"][0]["machine_name"] == "fn"


def test_list_templates_pagination_flags_forwarded(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/?page=2&page_size=5",
        method="GET",
        json=_list_response([], count=0),
    )
    result = runner.invoke(
        app, ["templates", "list", "--page", "2", "--page-size", "5"]
    )
    assert result.exit_code == 0, result.output


# ---------------------------------------------------------------------------
# templates get returns machine_name in default schema
# ---------------------------------------------------------------------------


def test_get_function_template_includes_machine_name(
    config, authenticated, httpx_mock
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json={
            "id": 42,
            "name": "fn_one",
            "type": "FUNCTION",
            "machine_name": "fn_one",
            "meta": {
                "app_id": 1,
                "publishing_status": "PUB",
                "revision_number": "r5",
            },
        },
    )
    result = runner.invoke(app, ["templates", "get", "42"])
    assert result.exit_code == 0, result.output
    # Tree header includes machine_name
    assert "fn_one" in result.output


# ---------------------------------------------------------------------------
# templates create/update --example: print stub body, no API call
# ---------------------------------------------------------------------------


def test_create_example_prints_json_body_and_skips_api(config, authenticated):
    # No httpx_mock fixture → any HTTP call would error out via pytest-httpx.
    result = runner.invoke(app, ["templates", "create", "--example"])
    assert result.exit_code == 0, result.output
    body = json.loads(result.output)
    assert body == {"template_type": "FUNCTION", "type": "ACTION"}


def test_create_without_input_or_example_errors():
    result = runner.invoke(app, ["templates", "create"])
    assert result.exit_code == 3, result.output
    assert "--input is required" in result.output
    assert "--example" in result.output


def test_update_example_prints_json_body_and_skips_api(config, authenticated):
    result = runner.invoke(app, ["templates", "update", "1", "--example"])
    assert result.exit_code == 0, result.output
    body = json.loads(result.output)
    assert "meta" in body
    assert "steps" in body
    assert isinstance(body["steps"], list)
    # update meta should be comprehensive — spot-check a wide variety of fields
    meta_keys = set(body["meta"].keys())
    expected_subset = {
        "revision_number", "title", "machine_name", "description", "type",
        "app_id", "publishing_status", "is_wizard", "execution_type",
        "function_type", "function_verb", "tags", "events", "product_info",
    }
    missing = expected_subset - meta_keys
    assert not missing, f"missing expected meta fields: {missing}"
    # steps should have at least one step with comprehensive fields, plus nested steps as []
    assert len(body["steps"]) >= 1
    step = body["steps"][0]
    assert "fields" in step
    assert "steps" in step and step["steps"] == []
    assert isinstance(step["fields"], list) and len(step["fields"]) >= 1


def test_update_without_input_or_example_errors():
    result = runner.invoke(app, ["templates", "update", "1"])
    assert result.exit_code == 3, result.output
    assert "--input is required" in result.output
    assert "--example" in result.output


# ---------------------------------------------------------------------------
# templates list / get include version and draft fields
# ---------------------------------------------------------------------------


def test_list_includes_live_or_latest_version(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v1/templates/",
        method="GET",
        json=_list_response([
            {
                "id": 1,
                "name": "T1",
                "type": "STANDARD",
                "machine_name": None,
                "publishing_status": "PUB",
                "revision_number": "r3",
                "live_or_latest_version": 2,
            },
        ]),
    )
    result = runner.invoke(app, ["templates", "list"])
    assert result.exit_code == 0, result.output
    assert "live_or_latest_version" in result.output
    assert "2" in result.output


def test_get_includes_version_and_draft_fields(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json={
            "id": 42,
            "name": "My Template",
            "type": "STANDARD",
            "machine_name": None,
            "meta": {
                "app_id": 1,
                "publishing_status": "DR",
                "revision_number": "r5",
            },
            "live_or_latest_version": 3,
            "is_draft_empty": False,
        },
    )
    result = runner.invoke(app, ["templates", "get", "42"])
    assert result.exit_code == 0, result.output
    # Tree header shows version number
    assert "v3" in result.output
    assert "DR" in result.output


# ---------------------------------------------------------------------------
# templates diff — compare version vs draft
# ---------------------------------------------------------------------------


def _version_payload(**overrides):
    base = {
        "id": 901,
        "meta": {
            "id": 42,
            "version_template_id": 901,
            "title": "My Template",
            "description": "Original description",
            "app_id": 7,
            "publishing_status": "PUB",
            "revision_number": "r3",
            "last_modified": "2026-01-01T00:00:00Z",
            "last_modified_by": {"id": 1, "username": "alice"},
            "created": "2025-01-01T00:00:00Z",
        },
        "steps": [
            {
                "id": 100,
                "title": "Send Email",
                "activity_id": 5,
                "fields": [
                    {"id": 200, "activity_field_id": 10, "default_value": "hello@test.com"},
                    {"id": 201, "activity_field_id": 11, "default_value": "Subject line"},
                ],
            }
        ],
    }
    base.update(overrides)
    return base


def _draft_payload(**overrides):
    base = {
        "id": 42,
        "meta": {
            "id": 42,
            "title": "My Template",
            "description": "Updated description",
            "app_id": 7,
            "publishing_status": "DR",
            "revision_number": "r4",
            "last_modified": "2026-04-17T00:00:00Z",
            "last_modified_by": {"id": 2, "username": "bob"},
            "created": "2025-01-01T00:00:00Z",
        },
        "steps": [
            {
                "id": 500,
                "title": "Send Email",
                "activity_id": 5,
                "fields": [
                    {"id": 600, "activity_field_id": 10, "default_value": "new@test.com"},
                    {"id": 601, "activity_field_id": 11, "default_value": "Subject line"},
                ],
            }
        ],
    }
    base.update(overrides)
    return base


def test_diff_shows_changes_ignoring_ids(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?version=3",
        method="GET",
        json=_version_payload(),
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_draft_payload(),
    )
    result = runner.invoke(app, ["templates", "diff", "42", "--version", "3"])
    assert result.exit_code == 0, result.output
    # Tree summary shows meta change and step modification
    assert "meta:" in result.output
    assert "description" in result.output
    # Step with field changes should be marked as modified
    assert "~" in result.output or "+" in result.output


def test_diff_no_changes_after_stripping_ids(config, authenticated, httpx_mock):
    """When version and draft are identical except for IDs, report no diff."""
    version = _version_payload()
    draft = _draft_payload()
    # Make content identical — only IDs and read-only fields differ
    draft["meta"]["description"] = "Original description"
    draft["meta"]["publishing_status"] = "PUB"
    draft["meta"]["revision_number"] = "r3"
    draft["steps"][0]["fields"][0]["default_value"] = "hello@test.com"
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?version=3",
        method="GET",
        json=version,
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=draft,
    )
    result = runner.invoke(app, ["templates", "diff", "42", "--version", "3"])
    assert result.exit_code == 0, result.output
    assert "no differences" in result.output.lower()


def test_diff_context_flag(config, authenticated, httpx_mock):
    """--context with --full gives unified diff with reduced context."""
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?version=3",
        method="GET",
        json=_version_payload(),
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_draft_payload(),
    )
    result = runner.invoke(
        app, ["templates", "diff", "42", "--version", "3", "--context", "2", "--full"]
    )
    assert result.exit_code == 0, result.output
    assert "Original description" in result.output
    assert "Updated description" in result.output


def test_diff_version_required():
    result = runner.invoke(app, ["templates", "diff", "42"])
    assert result.exit_code != 0, result.output


def test_diff_json_format(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?version=3",
        method="GET",
        json=_version_payload(),
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_draft_payload(),
    )
    result = runner.invoke(
        app, ["templates", "diff", "42", "--version", "3", "--format", "json"]
    )
    assert result.exit_code == 0, result.output
    envelope = json.loads(result.output)
    assert envelope["ok"] is True
    assert "diff" in envelope["data"]
    assert isinstance(envelope["data"]["diff"], str)


# ---------------------------------------------------------------------------
# Tree output for get and diff
# ---------------------------------------------------------------------------


def _template_with_steps():
    return {
        "id": 42,
        "name": "invoice_flow",
        "type": "FUNCTION",
        "machine_name": "invoice_flow",
        "meta": {
            "id": 42,
            "name": "invoice_flow",
            "type": "FUNCTION",
            "machine_name": "invoice_flow",
            "app_id": 1,
            "publishing_status": "PUB",
            "live_or_latest_version": 2,
        },
        "live_or_latest_version": 2,
        "steps": [
            {"machine_name": "get_user", "type": "HTTP_CALL", "title": "Fetch user"},
            {"machine_name": "check", "type": "CUSTOM_CODE", "title": "check"},
            {
                "machine_name": "loop", "type": "LOOP", "title": "Send all",
                "steps": [
                    {"machine_name": "send_email", "type": "HTTP_CALL", "title": "Email"},
                ],
            },
        ],
    }


def test_get_tree_output(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_with_steps(),
    )
    result = runner.invoke(app, ["templates", "get", "42"])
    assert result.exit_code == 0, result.output
    # Header line
    assert "42" in result.output
    assert "invoice_flow" in result.output
    assert "(FUNCTION)" in result.output
    assert "v2" in result.output
    assert "PUB" in result.output
    # Step tree
    assert "get_user (HTTP_CALL)" in result.output
    assert 'check (CUSTOM_CODE)' in result.output
    assert "loop (LOOP)" in result.output
    # Nested step indented
    assert "    send_email (HTTP_CALL)" in result.output
    # Title shown when different from machine_name
    assert '"Fetch user"' in result.output
    # Title NOT shown when same as machine_name
    assert '"check"' not in result.output


def test_get_tree_with_full_uses_toon(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_with_steps(),
    )
    result = runner.invoke(app, ["templates", "get", "42", "--full"])
    assert result.exit_code == 0, result.output
    # --full uses regular TOON, not tree
    assert "machine_name: invoice_flow" in result.output


def test_diff_tree_shows_changes(config, authenticated, httpx_mock):
    version = _template_with_steps()
    draft = _template_with_steps()
    draft["meta"]["description"] = "New desc"
    # Add a step to draft
    draft["steps"].append({"machine_name": "new_step", "type": "CUSTOM_CODE", "title": "New"})
    # Remove a step from draft
    draft["steps"] = [s for s in draft["steps"] if s.get("machine_name") != "check"]

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?version=2",
        method="GET",
        json=version,
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=draft,
    )
    result = runner.invoke(app, ["templates", "diff", "42", "--version", "2"])
    assert result.exit_code == 0, result.output
    # Added step
    assert "+ new_step (CUSTOM_CODE)" in result.output
    # Removed step
    assert "- check (CUSTOM_CODE)" in result.output
    # Unchanged step (space-prefixed)
    assert "  get_user (HTTP_CALL)" in result.output
    # Meta change
    assert "~ meta:" in result.output
    assert "description" in result.output


def test_diff_tree_ignores_ids_and_parent_ids(config, authenticated, httpx_mock):
    """Steps matched by machine_name; id, parent_id, intra_version_guid diffs are ignored."""
    version = {
        "id": 901, "meta": {"id": 42, "type": "FUNCTION", "publishing_status": "PUB"},
        "steps": [
            {
                "id": 100, "parent_id": 50, "intra_version_guid": "aaa",
                "machine_name": "step_a", "type": "HTTP_CALL", "title": "Fetch",
                "fields": [
                    {"id": 200, "machine_name": "to", "default_value": "old@test.com"},
                ],
            },
            {
                "id": 101, "parent_id": 50, "intra_version_guid": "bbb",
                "machine_name": "step_b", "type": "CUSTOM_CODE", "title": "Process",
                "fields": [],
            },
        ],
    }
    draft = {
        "id": 42, "meta": {"id": 42, "type": "FUNCTION", "publishing_status": "DR"},
        "steps": [
            {
                "id": 500, "parent_id": 99, "intra_version_guid": "xxx",
                "machine_name": "step_a", "type": "HTTP_CALL", "title": "Fetch",
                "fields": [
                    {"id": 600, "machine_name": "to", "default_value": "new@test.com"},
                ],
            },
            {
                "id": 501, "parent_id": 99, "intra_version_guid": "yyy",
                "machine_name": "step_b", "type": "CUSTOM_CODE", "title": "Process",
                "fields": [],
            },
        ],
    }
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?version=1",
        method="GET", json=version,
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET", json=draft,
    )
    result = runner.invoke(app, ["templates", "diff", "42", "--version", "1"])
    assert result.exit_code == 0, result.output
    # step_a has a field change (default_value changed)
    assert "~ " in result.output
    assert "step_a" in result.output
    assert "fields:" in result.output
    assert "1 changed" in result.output
    # step_b is unchanged (only id, parent_id, intra_version_guid differ)
    assert "  step_b" in result.output or "step_b (CUSTOM_CODE)" in result.output
    # No steps should be shown as added or removed
    assert "+ " not in result.output
    assert "- " not in result.output


def test_diff_tree_full_falls_back_to_unified(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?version=2",
        method="GET",
        json=_template_with_steps(),
    )
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_with_steps(),
    )
    result = runner.invoke(
        app, ["templates", "diff", "42", "--version", "2", "--full"]
    )
    assert result.exit_code == 0, result.output
    # --full uses unified diff, not tree
    assert "no differences" in result.output.lower()


# ---------------------------------------------------------------------------
# templates test — call a FUNCTION draft via signed request
# ---------------------------------------------------------------------------

ME_PATH = "/accounts/me/"


def _me_response(*, account_id=5041, app_key="ak_test", app_secret="sk_test"):
    """Minimal /accounts/me/ payload with default_workspace_app."""
    return {
        "accounts": [{"id": account_id, "name": "Acme"}],
        "account": {
            "id": account_id,
            "default_workspace_app": {
                "id": 1,
                "name": "Workspace App",
                "key": app_key,
                "secret": app_secret,
                "icon_url": "",
                "is_public": False,
                "machine_name": "workspace_app",
            },
        },
    }


def _template_response(*, id=42, type="FUNCTION", machine_name="send_email"):
    return {
        "id": id,
        "name": "Send Email",
        "type": type,
        "machine_name": machine_name,
        "meta": {
            "app_id": 7,
            "publishing_status": "DR",
            "revision_number": "r1",
        },
    }


def _app_response(*, connected_accounts):
    return {
        "id": 7,
        "name": "email_app",
        "title": "Email App",
        "icon_url": "",
        "connected_accounts": connected_accounts,
    }


def test_test_function_happy_path(tmp_path, config, authenticated, httpx_mock, monkeypatch):
    """Full flow: get template → get me → get app with accounts → call function."""
    monkeypatch.setattr("integry_cli.config._resolve_account_id", lambda _: (5041, "config"))
    # Re-load config with the monkeypatched account_id.
    from integry_cli.config import load_config as _lc
    _cfg = _lc()

    # 1. GET template
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_response(),
    )
    # 2. GET /accounts/me/
    httpx_mock.add_response(
        url=f"{config.api_url}{ME_PATH}",
        method="GET",
        json=_me_response(),
    )
    # 3. POST apps/<machine_name>/get/
    httpx_mock.add_response(
        method="POST",
        json=_app_response(connected_accounts=[
            {"id": 100, "display_name": "user@test.com"},
        ]),
    )
    # 4. POST functions/<machine_name>/call/
    httpx_mock.add_response(
        method="POST",
        json={"result": "sent"},
    )

    args_file = tmp_path / "args.json"
    args_file.write_text('{"to": "a@b.com"}')

    result = runner.invoke(
        app, ["templates", "test", "42", "--input", str(args_file)]
    )
    assert result.exit_code == 0, result.output
    assert "result" in result.output

    # Verify the function call used signed request auth, not JWT
    requests = httpx_mock.get_requests()
    fn_call = [r for r in requests if "functions/" in str(r.url)][0]
    assert "user_id=INTEGRY_TEST_INTEGRATION_CREATOR_5041" in str(fn_call.url)
    assert "app_key=ak_test" in str(fn_call.url)
    assert "hash=" in str(fn_call.url)
    assert fn_call.headers.get("version") == "DRAFT"
    assert json.loads(fn_call.content) == {"to": "a@b.com"}


def test_test_rejects_non_function_template(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_response(type="STANDARD", machine_name=None),
    )
    result = runner.invoke(app, ["templates", "test", "42"])
    assert result.exit_code == 3, result.output
    assert "FUNCTION" in result.output


def test_test_prompts_connected_account_selection(
    tmp_path, config, authenticated, httpx_mock, monkeypatch
):
    """When multiple connected accounts exist, prompt user to choose."""
    monkeypatch.setattr("integry_cli.config._resolve_account_id", lambda _: (5041, "config"))

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_response(),
    )
    httpx_mock.add_response(
        url=f"{config.api_url}{ME_PATH}",
        method="GET",
        json=_me_response(),
    )
    httpx_mock.add_response(
        method="POST",
        json=_app_response(connected_accounts=[
            {"id": 100, "display_name": "user1@test.com"},
            {"id": 200, "display_name": "user2@test.com"},
        ]),
    )
    httpx_mock.add_response(
        method="POST",
        json={"result": "ok"},
    )

    args_file = tmp_path / "args.json"
    args_file.write_text("{}")

    # Simulate user picking option 1 (id=100)
    result = runner.invoke(
        app, ["templates", "test", "42", "--input", str(args_file)], input="1\n"
    )
    assert result.exit_code == 0, result.output

    # Verify connected_account_id=100 in the function call URL
    requests = httpx_mock.get_requests()
    fn_call = [r for r in requests if "functions/" in str(r.url)][0]
    assert "connected_account_id=100" in str(fn_call.url)


def test_test_no_connected_accounts_errors(config, authenticated, httpx_mock, monkeypatch):
    monkeypatch.setattr("integry_cli.config._resolve_account_id", lambda _: (5041, "config"))

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_response(),
    )
    httpx_mock.add_response(
        url=f"{config.api_url}{ME_PATH}",
        method="GET",
        json=_me_response(),
    )
    httpx_mock.add_response(
        method="POST",
        json=_app_response(connected_accounts=[]),
    )

    result = runner.invoke(app, ["templates", "test", "42"])
    assert result.exit_code != 0, result.output
    assert "no connected accounts" in result.output.lower()


def test_test_requires_account_id(config, authenticated, httpx_mock):
    """Account ID must be set for test (needed to build user_id)."""
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_response(),
    )
    result = runner.invoke(app, ["templates", "test", "42"])
    assert result.exit_code != 0, result.output
    assert "account" in result.output.lower()


def test_test_connected_account_flag_skips_prompt(
    tmp_path, config, authenticated, httpx_mock, monkeypatch
):
    """--connected-account-id bypasses the selection prompt."""
    monkeypatch.setattr("integry_cli.config._resolve_account_id", lambda _: (5041, "config"))

    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        method="GET",
        json=_template_response(),
    )
    httpx_mock.add_response(
        url=f"{config.api_url}{ME_PATH}",
        method="GET",
        json=_me_response(),
    )
    # Skip app/get — connected_account_id is provided directly
    httpx_mock.add_response(
        method="POST",
        json={"result": "done"},
    )

    args_file = tmp_path / "args.json"
    args_file.write_text('{"x": 1}')

    result = runner.invoke(
        app,
        ["templates", "test", "42", "--input", str(args_file), "--connected-account-id", "777"],
    )
    assert result.exit_code == 0, result.output
    requests = httpx_mock.get_requests()
    fn_call = [r for r in requests if "functions/" in str(r.url)][0]
    assert "connected_account_id=777" in str(fn_call.url)


# ---------------------------------------------------------------------------
# Output field sanitization
# ---------------------------------------------------------------------------


def _template_with_output_field(activity_field_id, default_value="stored_test_output"):
    return {
        "id": 42,
        "name": "T",
        "type": "STANDARD",
        "machine_name": "t",
        "app_id": 1,
        "publishing_status": "DR",
        "revision_number": 1,
        "live_or_latest_version": None,
        "is_draft_empty": False,
        "steps": [
            {
                "machine_name": "http_step",
                "title": "HTTP",
                "type": "ACTION",
                "weight": 0,
                "fields": [
                    {
                        "machine_name": "url",
                        "activity_field_id": 999,
                        "default_value": "https://example.com",
                    },
                    {
                        "machine_name": "output",
                        "activity_field_id": activity_field_id,
                        "default_value": default_value,
                    },
                ],
                "steps": [],
            }
        ],
    }


def test_get_sanitizes_http_output_field(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        json=_template_with_output_field(116460),
    )
    result = runner.invoke(app, ["templates", "get", "42", "--format", "json", "--full"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output)["data"]
    output_field = data["steps"][0]["fields"][1]
    assert output_field["default_value"] == ""
    normal_field = data["steps"][0]["fields"][0]
    assert normal_field["default_value"] == "https://example.com"


def test_get_sanitizes_code_output_field(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        json=_template_with_output_field(152552),
    )
    result = runner.invoke(app, ["templates", "get", "42", "--format", "json", "--full"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output)["data"]
    output_field = data["steps"][0]["fields"][1]
    assert output_field["default_value"] == ""


def test_get_strips_redundant_meta_keys(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        json={
            "id": 42,
            "meta": {
                "title": "T",
                "app_id": 1,
                "tooltip": "should be stripped",
                "webhook_url": "should be stripped",
                "notes": "should be stripped",
            },
            "steps": [],
        },
    )
    result = runner.invoke(app, ["templates", "get", "42", "--format", "json", "--full"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output)["data"]
    assert data["meta"]["title"] == "T"
    assert "tooltip" not in data["meta"]
    assert "webhook_url" not in data["meta"]
    assert "notes" not in data["meta"]


def test_get_strips_redundant_step_keys(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        json={
            "id": 42,
            "meta": {"title": "T"},
            "steps": [
                {
                    "machine_name": "s1",
                    "title": "S1",
                    "type": "ACTION",
                    "weight": 0,
                    "activity": {"id": 123, "name": "Send"},
                    "authorization_type": {"id": 1},
                    "test_output": "stale",
                    "intra_version_guid": "abc",
                    "fields": [],
                    "steps": [],
                }
            ],
        },
    )
    result = runner.invoke(app, ["templates", "get", "42", "--format", "json", "--full"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output)["data"]
    step = data["steps"][0]
    assert step["machine_name"] == "s1"
    assert "activity" not in step
    assert "authorization_type" not in step
    assert "test_output" not in step
    assert "intra_version_guid" not in step


def test_get_strips_redundant_field_keys(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/",
        json={
            "id": 42,
            "meta": {"title": "T"},
            "steps": [
                {
                    "machine_name": "s1",
                    "title": "S1",
                    "type": "ACTION",
                    "weight": 0,
                    "fields": [
                        {
                            "machine_name": "f1",
                            "activity_field_id": 999,
                            "default_value": "val",
                            "is_hidden": True,
                            "classname": "x",
                            "test_value": "tv",
                            "description": "should be stripped for non-parameter",
                        },
                        {
                            "machine_name": "f2",
                            "activity_field_id": None,
                            "default_value": "param",
                            "is_hidden": True,
                            "description": "kept for parameter",
                        },
                    ],
                    "steps": [],
                }
            ],
        },
    )
    result = runner.invoke(app, ["templates", "get", "42", "--format", "json", "--full"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output)["data"]
    f1 = data["steps"][0]["fields"][0]
    f2 = data["steps"][0]["fields"][1]
    assert "is_hidden" not in f1
    assert "classname" not in f1
    assert "test_value" not in f1
    assert "description" not in f1
    assert f1["default_value"] == "val"
    assert "is_hidden" not in f2
    assert "description" in f2


def test_get_draft_sanitizes_output_fields(config, authenticated, httpx_mock):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/v2/templates/42/?return_as_draft=true",
        json=_template_with_output_field(116460),
    )
    result = runner.invoke(app, ["templates", "get-draft", "42", "--format", "json", "--full"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output)["data"]
    output_field = data["steps"][0]["fields"][1]
    assert output_field["default_value"] == ""
