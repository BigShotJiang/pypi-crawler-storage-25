from __future__ import annotations

from typer.testing import CliRunner

from integry_cli.cli import app

runner = CliRunner()


def test_bare_integry_unauthenticated_exits_2(config):
    result = runner.invoke(app, [])
    assert result.exit_code == 2
    assert "authenticated: false" in result.output
    assert "next: integry auth login" in result.output


def test_bare_integry_authenticated_no_account_suggests_accounts_list(
    config, authenticated
):
    result = runner.invoke(app, [])
    assert result.exit_code == 0
    assert "authenticated: true" in result.output
    # Account selection is the very next step after login.
    assert "next: integry accounts list" in result.output


def test_bare_integry_authenticated_with_account_suggests_templates(
    integry_home, authenticated, monkeypatch
):
    monkeypatch.setenv("INTEGRY_ACCOUNT_ID", "7")
    result = runner.invoke(app, [])
    assert result.exit_code == 0
    assert "authenticated: true" in result.output
    assert "account_id: 7" in result.output
    assert "next: integry templates list" in result.output


def test_auth_status_unauthenticated_exits_2(config):
    result = runner.invoke(app, ["auth", "status"])
    assert result.exit_code == 3
    assert "not authenticated" in result.output


def test_auth_status_authenticated(config, authenticated):
    result = runner.invoke(app, ["auth", "status"])
    assert result.exit_code == 0
    assert "user_id: 42" in result.output
    assert "api_url:" in result.output


def test_auth_logout_is_idempotent(config, authenticated):
    result = runner.invoke(app, ["auth", "logout"])
    assert result.exit_code == 0
    assert "cleared: true" in result.output
    result = runner.invoke(app, ["auth", "logout"])
    assert result.exit_code == 0
    assert "cleared: false" in result.output


def test_auth_login_suggests_accounts_list_next(
    config, httpx_mock, jwt_access_token, jwt_refresh_token
):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/token/",
        method="POST",
        json={"access": jwt_access_token, "refresh": jwt_refresh_token},
    )
    result = runner.invoke(
        app,
        ["auth", "login", "--username", "alice", "--password", "secret"],
    )
    assert result.exit_code == 0
    assert "next: integry accounts list" in result.output


def test_auth_login_json_format(config, httpx_mock, jwt_access_token, jwt_refresh_token):
    httpx_mock.add_response(
        url=f"{config.api_url}/api/token/",
        method="POST",
        json={"access": jwt_access_token, "refresh": jwt_refresh_token},
    )
    result = runner.invoke(
        app,
        [
            "auth",
            "login",
            "--format",
            "json",
            "--username",
            "alice",
            "--password",
            "secret",
        ],
    )
    assert result.exit_code == 0
    import json

    parsed = json.loads(result.output.strip())
    assert parsed["ok"] is True
    assert parsed["data"]["username"] == "alice"
