from __future__ import annotations

from typing import Any

import httpx

from integry_cli import __version__
from integry_cli.auth import Tokens, load_tokens, refresh_access_token, save_tokens
from integry_cli.config import Config
from integry_cli.errors import ApiError, AuthError


class ApiClient:
    """HTTPX wrapper that attaches bearer auth and retries once on 401 after refresh."""

    def __init__(self, config: Config, tokens: Tokens):
        self.config = config
        self.tokens = tokens
        base_headers = {"User-Agent": f"integry-cli/{__version__}"}
        if config.account_id is not None:
            base_headers["X-Account-Id"] = str(config.account_id)
        self._client = httpx.Client(
            base_url=config.api_url,
            timeout=600,
            headers=base_headers,
        )

    @classmethod
    def from_config(cls, config: Config) -> "ApiClient":
        tokens = load_tokens(config)
        if tokens is None:
            raise AuthError("not authenticated — run: integry auth login")
        return cls(config, tokens)

    def get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        return self._request("GET", path, json=None, params=params)

    def post(self, path: str, *, json: Any, params: dict[str, Any] | None = None) -> Any:
        return self._request("POST", path, json=json, params=params)

    def patch(self, path: str, *, json: Any, params: dict[str, Any] | None = None) -> Any:
        return self._request("PATCH", path, json=json, params=params)

    def close(self) -> None:
        self._client.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any,
        params: dict[str, Any] | None,
    ) -> Any:
        response = self._send(method, path, json, params)
        if response.status_code == 401:
            self._refresh_tokens()
            response = self._send(method, path, json, params)
            if response.status_code == 401:
                raise AuthError("session expired — run: integry auth login")

        if response.status_code >= 400:
            raise ApiError(
                f"{method} {path} failed ({response.status_code})",
                status=response.status_code,
                detail=_safe_json(response),
            )

        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    def _send(
        self,
        method: str,
        path: str,
        json: Any,
        params: dict[str, Any] | None,
    ) -> httpx.Response:
        return self._client.request(
            method,
            path,
            json=json,
            params=params,
            headers={"Authorization": f"Bearer {self.tokens.access}"},
        )

    def _refresh_tokens(self) -> None:
        refreshed = refresh_access_token(self.config, self.tokens.refresh)
        self.tokens = refreshed
        save_tokens(self.config, refreshed)


def _safe_json(response: httpx.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        return response.text
