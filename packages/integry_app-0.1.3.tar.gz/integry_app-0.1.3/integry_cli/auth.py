from __future__ import annotations

import base64
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from integry_cli.config import Config
from integry_cli.errors import ApiError, AuthError

TOKEN_OBTAIN_PATH = "/api/token/"
TOKEN_REFRESH_PATH = "/api/token/refresh/"


@dataclass
class Tokens:
    access: str
    refresh: str
    obtained_at: int

    def to_dict(self) -> dict[str, Any]:
        return {"access": self.access, "refresh": self.refresh, "obtained_at": self.obtained_at}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Tokens":
        return cls(
            access=data["access"],
            refresh=data["refresh"],
            obtained_at=int(data.get("obtained_at", 0)),
        )


def login(config: Config, username: str, password: str) -> Tokens:
    response = httpx.post(
        config.api_url + TOKEN_OBTAIN_PATH,
        json={"username": username, "password": password},
        timeout=30,
    )
    if response.status_code == 401:
        raise AuthError("invalid credentials")
    if response.status_code >= 400:
        raise ApiError(
            f"login failed ({response.status_code})",
            status=response.status_code,
            detail=_safe_json(response),
        )
    data = response.json()
    tokens = Tokens(
        access=data["access"], refresh=data["refresh"], obtained_at=int(time.time())
    )
    save_tokens(config, tokens)
    return tokens


def refresh_access_token(config: Config, refresh_token: str) -> Tokens:
    response = httpx.post(
        config.api_url + TOKEN_REFRESH_PATH,
        json={"refresh": refresh_token},
        timeout=30,
    )
    if response.status_code in (400, 401):
        raise AuthError("session expired — run: integry auth login")
    if response.status_code >= 400:
        raise ApiError(
            f"token refresh failed ({response.status_code})",
            status=response.status_code,
            detail=_safe_json(response),
        )
    data = response.json()
    tokens = Tokens(
        access=data["access"],
        refresh=data.get("refresh", refresh_token),
        obtained_at=int(time.time()),
    )
    save_tokens(config, tokens)
    return tokens


def load_tokens(config: Config) -> Tokens | None:
    path = config.credentials_path
    if not path.exists():
        return None
    try:
        return Tokens.from_dict(json.loads(path.read_text()))
    except (json.JSONDecodeError, KeyError, OSError):
        return None


def save_tokens(config: Config, tokens: Tokens) -> None:
    config.home.mkdir(parents=True, exist_ok=True)
    path = config.credentials_path
    path.write_text(json.dumps(tokens.to_dict(), indent=2))
    _chmod_600(path)


def clear_tokens(config: Config) -> bool:
    path = config.credentials_path
    if not path.exists():
        return False
    path.unlink()
    return True


def decode_jwt_claims(token: str) -> dict[str, Any]:
    """Decode JWT payload without verifying signature (server enforces that)."""
    try:
        _, payload, _ = token.split(".")
    except ValueError:
        return {}
    padding = "=" * (-len(payload) % 4)
    try:
        raw = base64.urlsafe_b64decode(payload + padding)
        return json.loads(raw)
    except (ValueError, json.JSONDecodeError):
        return {}


def expires_in_seconds(token: str) -> int | None:
    claims = decode_jwt_claims(token)
    exp = claims.get("exp")
    if not isinstance(exp, (int, float)):
        return None
    return int(exp - time.time())


def _chmod_600(path: Path) -> None:
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _safe_json(response: httpx.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        return response.text
