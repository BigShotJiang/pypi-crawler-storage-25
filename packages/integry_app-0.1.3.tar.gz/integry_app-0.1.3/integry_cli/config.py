from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

DEFAULT_API_URL = "https://api.integry.io"


@dataclass(frozen=True)
class Config:
    api_url: str
    home: Path
    account_id: int | None = None
    account_id_source: str | None = None  # "env" | "config" | None

    @property
    def credentials_path(self) -> Path:
        return self.home / "credentials.json"

    @property
    def config_path(self) -> Path:
        return self.home / "config.json"


def load_config() -> Config:
    home = _resolve_home()
    stored = _read_json(home / "config.json")

    api_url = (
        os.environ.get("INTEGRY_API_URL")
        or (stored.get("api_url") if isinstance(stored.get("api_url"), str) else None)
        or DEFAULT_API_URL
    )

    account_id, source = _resolve_account_id(stored)

    return Config(
        api_url=api_url.rstrip("/"),
        home=home,
        account_id=account_id,
        account_id_source=source,
    )


def save_api_url(api_url: str) -> None:
    _update_config({"api_url": api_url.rstrip("/")})


def save_account_id(account_id: int) -> None:
    _update_config({"account_id": int(account_id)})


def clear_account_id() -> bool:
    home = _resolve_home()
    path = home / "config.json"
    existing = _read_json(path)
    if "account_id" not in existing:
        return False
    existing.pop("account_id")
    home.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(existing, indent=2))
    return True


def _update_config(updates: dict) -> None:
    home = _resolve_home()
    home.mkdir(parents=True, exist_ok=True)
    path = home / "config.json"
    existing = _read_json(path)
    existing.update(updates)
    path.write_text(json.dumps(existing, indent=2))


def _resolve_home() -> Path:
    override = os.environ.get("INTEGRY_HOME")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".integry"


def _resolve_account_id(stored: dict) -> tuple[int | None, str | None]:
    env_value = os.environ.get("INTEGRY_ACCOUNT_ID")
    if env_value:
        try:
            return int(env_value), "env"
        except ValueError:
            pass
    raw = stored.get("account_id")
    if isinstance(raw, int):
        return raw, "config"
    if isinstance(raw, str):
        try:
            return int(raw), "config"
        except ValueError:
            return None, None
    return None, None


def _read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}
