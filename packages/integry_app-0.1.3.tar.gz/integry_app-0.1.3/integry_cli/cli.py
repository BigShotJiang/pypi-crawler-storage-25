from __future__ import annotations

import functools

import click
import typer

from integry_cli import auth as auth_mod
from integry_cli.commands import accounts as accounts_cmd
from integry_cli.commands import auth as auth_cmd
from integry_cli.commands import templates as templates_cmd
from integry_cli.config import load_config
from integry_cli.errors import CLIError
from integry_cli.output import print_error, print_success

app = typer.Typer(
    name="integry",
    help="CLI for the Integry backend (templates create + partial update v5).",
    no_args_is_help=False,
    invoke_without_command=True,
)

app.add_typer(auth_cmd.app, name="auth")
app.add_typer(accounts_cmd.app, name="accounts")
app.add_typer(templates_cmd.app, name="templates")

from integry_cli.commands.template_dispatch import install_templates_group
install_templates_group(app)


@app.callback()
def _root(
    ctx: typer.Context,
    fmt: str = typer.Option(
        "toon", "--format", help="Output format for ambient state: toon|json"
    ),
) -> None:
    ctx.ensure_object(dict)
    ctx.obj["format"] = fmt

    if ctx.invoked_subcommand is not None:
        return

    _show_ambient_state(fmt)


def handle_cli_errors(fn):
    """Convert CLIError raised by a command body into structured output + typer.Exit."""

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        fmt = _current_format(kwargs.get("fmt"))
        try:
            return fn(*args, **kwargs)
        except CLIError as err:
            print_error(err, fmt=fmt)
            raise typer.Exit(code=err.exit_code)

    return wrapper


def main() -> None:
    app()


def _show_ambient_state(fmt: str) -> None:
    try:
        config = load_config()
        tokens = auth_mod.load_tokens(config)
        authenticated = tokens is not None
        payload = {
            "api_url": config.api_url,
            "authenticated": authenticated,
            "access_expires_in": auth_mod.expires_in_seconds(tokens.access) if tokens else None,
            "account_id": config.account_id,
        }
        if authenticated:
            if config.account_id is None:
                hints = [
                    "integry accounts list",
                    "integry accounts use <id>",
                ]
            else:
                hints = [
                    "integry templates list",
                    "integry templates create --input ./template.json",
                ]
        else:
            hints = [
                "integry auth login --username <you>",
                "integry accounts list",
            ]
        print_success(payload, fmt=fmt, next_hints=hints)
    except CLIError as err:
        print_error(err, fmt=fmt)
        raise typer.Exit(code=err.exit_code)

    raise typer.Exit(code=0 if authenticated else 2)


def _current_format(fmt: str | None) -> str:
    if fmt:
        return fmt
    ctx = click.get_current_context(silent=True)
    if ctx is not None and ctx.obj:
        return ctx.obj.get("format", "toon")
    return "toon"


if __name__ == "__main__":
    main()
