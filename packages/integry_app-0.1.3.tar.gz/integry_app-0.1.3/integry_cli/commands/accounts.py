from __future__ import annotations

import sys
from typing import Any

import typer

from integry_cli.client import ApiClient
from integry_cli.config import clear_account_id, load_config, save_account_id
from integry_cli.errors import UsageError
from integry_cli.output import print_success

app = typer.Typer(help="Select the account used for X-Account-Id.", no_args_is_help=True)

ME_PATH = "/accounts/me/"
ACCOUNT_FIELDS = ("id", "name", "is_currently_selected")


@app.command("use")
def use(
    account_id: int = typer.Argument(..., help="Account primary key to send as X-Account-Id."),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
) -> None:
    """Persist the account id used for every subsequent request."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_use_impl)(account_id=account_id, fmt=fmt)


def _use_impl(account_id: int, fmt: str) -> None:
    save_account_id(account_id)
    print_success(
        {"account_id": account_id, "source": "config"},
        fmt=fmt,
        next_hints=["integry templates list"],
    )


@app.command("clear")
def clear(fmt: str = typer.Option("toon", "--format", help="Output format: toon|json")) -> None:
    """Forget the persisted account id. Idempotent."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_clear_impl)(fmt=fmt)


def _clear_impl(fmt: str) -> None:
    cleared = clear_account_id()
    print_success({"cleared": cleared}, fmt=fmt)


@app.command("current")
def current(fmt: str = typer.Option("toon", "--format", help="Output format: toon|json")) -> None:
    """Show the active account id and where it came from (env|config)."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_current_impl)(fmt=fmt)


def _current_impl(fmt: str) -> None:
    config = load_config()
    if config.account_id is None:
        raise UsageError(
            "no account selected — set INTEGRY_ACCOUNT_ID or run: integry accounts use <id>"
        )
    print_success(
        {"account_id": config.account_id, "source": config.account_id_source},
        fmt=fmt,
    )


@app.command("list")
def list_accounts(
    search: str = typer.Option(
        None,
        "--search",
        "-s",
        help="Case-insensitive substring filter on account name.",
    ),
    page: int = typer.Option(None, "--page", help="Page number (1-indexed). Sliced client-side."),
    page_size: int = typer.Option(
        None, "--page-size", help="Results per page. Sliced client-side."
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """List accounts the current user belongs to; --search filters by name."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_list_impl)(
        search=search, page=page, page_size=page_size, fmt=fmt, full=full
    )


def _list_impl(
    search: str | None,
    page: int | None,
    page_size: int | None,
    fmt: str,
    full: bool,
) -> None:
    config = load_config()
    client = ApiClient.from_config(config)
    try:
        response = client.get(ME_PATH)
    finally:
        client.close()

    accounts = response.get("accounts", []) if isinstance(response, dict) else []
    if search:
        needle = search.lower()
        accounts = [
            a for a in accounts
            if isinstance(a, dict) and needle in str(a.get("name", "")).lower()
        ]

    total = len(accounts)
    sliced = _paginate(accounts, page, page_size)
    hints = ["integry accounts use <id>"]

    if not sliced:
        payload: dict = {"total": total, "accounts": []}
        if search:
            payload["query"] = search
        if fmt == "json":
            print_success(payload, fmt=fmt, full=True, next_hints=hints)
            return
        if total == 0:
            message = (
                f"no accounts match '{search}'" if search else "no accounts found"
            )
        else:
            message = f"page out of range — {total} account(s) total"
        sys.stdout.write(f"{message}\n")
        for hint in hints:
            sys.stdout.write(f"next: {hint}\n")
        return

    shaped = [_shape_account(a, full) for a in sliced]
    payload = {"total": total, "accounts": shaped}
    if search:
        payload["query"] = search
    print_success(
        payload,
        fmt=fmt,
        full=True,
        next_hints=hints,
    )


def _paginate(items: list, page: int | None, page_size: int | None) -> list:
    if page is None and page_size is None:
        return items
    p = page if page and page > 0 else 1
    size = page_size if page_size and page_size > 0 else len(items)
    start = (p - 1) * size
    return items[start : start + size]


def _shape_account(account: Any, full: bool) -> dict:
    if not isinstance(account, dict):
        return {"raw": account}
    if full:
        return account
    return {k: account.get(k) for k in ACCOUNT_FIELDS if k in account}
