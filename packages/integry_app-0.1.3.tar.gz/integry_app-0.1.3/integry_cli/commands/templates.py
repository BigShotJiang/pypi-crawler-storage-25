from __future__ import annotations

import difflib
import hashlib
import hmac
import json
import sys
from pathlib import Path
from typing import Any

import httpx
import typer

from integry_cli.client import ApiClient
from integry_cli.config import load_config
from integry_cli.errors import ApiError, UsageError
from integry_cli.output import print_success, render_diff_tree, render_step_tree, render_template_header

app = typer.Typer(help="Create or update Integry templates.", no_args_is_help=True)

CREATE_PATH = "/api/v2/templates/"
LIST_PATH = "/api/v1/templates/"
UPDATE_PATH_TMPL = "/api/v5/templates/{pk}/"
GET_PATH_TMPL = "/api/v2/templates/{pk}/"
VERSIONS_PATH_TMPL = "/api/v1/templates/{pk}/versions/"
VERSION_DETAIL_PATH_TMPL = "/api/v1/templates/{pk}/versions/{version}/"
APP_GET_PATH_TMPL = "/apps/{machine_name}/get/"
FUNCTION_CALL_PATH_TMPL = "/functions/{machine_name}/call/"
ME_PATH = "/accounts/me/"

TEMPLATE_LIST_FIELDS = (
    "id",
    "name",
    "type",
    "machine_name",
    "publishing_status",
    "revision_number",
    "live_or_latest_version",
)


CREATE_EXAMPLE: dict[str, Any] = {
    "template_type": "FUNCTION",
    "type": "ACTION",
}


UPDATE_EXAMPLE: dict[str, Any] = {
    "meta": {
        "revision_number": 0,
        "title": "",
        "machine_name": "",
        "description": "",
        "tooltip": "",
        "type": "STANDARD",
        "app_id": 0,
        "branding_app_id": 0,
        "app_object_id": None,
        "return_app_object_id": None,
        "icon_url": "",
        "status": 1,
        "return_data": False,
        "return_format": None,
        "direction": "ONE_WAY",
        "publishing_status": "DR",
        "is_wizard": False,
        "button_text": "",
        "execution_type": "SYNC",
        "execution_behaviour": "DEFAULT",
        "abort_on_step_error": True,
        "allow_multiple_instances": False,
        "partial_trigger_response": False,
        "allow_unauthenticated_call": False,
        "is_end_user_template": False,
        "is_public": False,
        "is_direct_action": False,
        "limit_one_integration": False,
        "is_accessible_to_beta_users": False,
        "webhook_url": "",
        "webhook_payload": None,
        "error_notification_throttling": 0,
        "enable_loop_prevention": False,
        "enable_jobs_serialization": False,
        "cache_integration_output": False,
        "cache_integration_duration": 0,
        "is_error_notification_enabled": True,
        "should_auto_disable_integrations_on_errors": False,
        "function_type": None,
        "function_verb": "",
        "function_call_mode": None,
        "return_function_verb": "",
        "is_pagination_enabled": False,
        "auth_scopes": [],
        "notes": "",
        "tags": [],
        "enable_product_info": False,
        "product_info": {
            "name": "",
            "description": "",
            "icon_url": "",
            "category": "",
            "website": "",
            "documentation_url": "",
            "support_email": "",
            "privacy_policy_url": "",
            "terms_of_service_url": "",
            "video_url": "",
            "screenshots": [],
            "features": [],
            "tags": [],
        },
        "changelog": "",
        "can_end_users_upgrade_integrations": False,
        "events": [],
    },
    "steps": [
        {
            "activity_id": 0,
            "title": "",
            "description": "",
            "tooltip": "",
            "icon_url": "",
            "weight": 0,
            "type": "ACTION",
            "is_hidden": False,
            "is_optional": False,
            "is_disabled": False,
            "is_loop": False,
            "loop_over": None,
            "loop_input": None,
            "loop_max_iterations": 0,
            "execution_type": "SYNC",
            "execution_behaviour": "DEFAULT",
            "abort_on_error": True,
            "retry_on_error": False,
            "max_retries": 0,
            "retry_delay": 0,
            "retry_backoff": 1.0,
            "wait_for": None,
            "condition": None,
            "branch_condition": None,
            "default_branch": None,
            "transform_input": None,
            "transform_output": None,
            "cache_output": False,
            "cache_duration": 0,
            "auth_id": None,
            "selected_account_field_id": None,
            "machine_name": "",
            "notes": "",
            "fields": [
                {
                    "activity_field_id": 0,
                    "machine_name": "",
                    "label": "",
                    "description": "",
                    "tooltip": "",
                    "placeholder": "",
                    "default_value": None,
                    "is_required": True,
                    "is_hidden": False,
                    "is_optional": False,
                    "is_dynamic": False,
                    "is_repeatable": False,
                    "is_lookup": False,
                    "is_secret": False,
                    "weight": 0,
                    "type": "STRING",
                    "format": None,
                    "min_length": None,
                    "max_length": None,
                    "min_value": None,
                    "max_value": None,
                    "pattern": None,
                    "choices": [],
                    "depends_on": [],
                    "visibility_rules": [],
                    "validation_rules": [],
                    "transform": None,
                    "lookup_template_id": None,
                    "lookup_value_field": "",
                    "lookup_label_field": "",
                    "lookup_filter": None,
                    "ai_hint": "",
                    "metadata": {},
                }
            ],
            "steps": [],
        }
    ],
}


@app.command("create")
def create(
    input_path: str = typer.Option(
        None, "--input", "-i", help="Path to JSON body, or '-' for stdin."
    ),
    publish: bool = typer.Option(False, "--publish", help="Publish on create."),
    example: bool = typer.Option(
        False,
        "--example",
        help="Print a comprehensive example body to stdout and exit. --input is ignored.",
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """Create a template.

    Body has two shapes (forwarded verbatim):

    1. Fast path - just `template_type` (and optional discriminator):
       {"template_type": "FUNCTION", "type": "ACTION"|"QUERY"|"PAGINATED_QUERY"}
       {"template_type": "FUNCTION_TRIGGER"}
       {"template_type": "AGENT", "playbook_id": <id>}
       The backend builds a complete starter tree from the workspace's default app.

    2. Standard branch - full tree with `meta` and `steps`:
       {"meta": {"title": ..., "app_id": ..., ...}, "steps": [ {...}, ... ]}
       Required: meta.title, meta.app_id. See docs/features/templates-create.md.
    """
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_create_impl)(
        input_path=input_path, publish=publish, example=example, fmt=fmt, full=full
    )


def _create_impl(
    input_path: str | None, publish: bool, example: bool, fmt: str, full: bool
) -> None:
    if example:
        sys.stdout.write(json.dumps(CREATE_EXAMPLE, indent=2) + "\n")
        return
    if not input_path:
        raise UsageError("--input is required (or pass --example to print a stub body)")
    body = _read_json_input(input_path)
    params: dict[str, Any] = {}
    if publish:
        params["publish"] = "true"

    config = load_config()
    client = ApiClient.from_config(config)
    try:
        response = client.post(CREATE_PATH, json=body, params=params or None)
    finally:
        client.close()

    template = _extract_template(response)
    template_id = _template_id(template)
    hints: list[str] = []
    if template_id is not None:
        hints.append(f"integry templates update {template_id} --input ./patch.json")

    print_success(template, fmt=fmt, entity="template", full=full, next_hints=hints)


@app.command("list")
def list_templates(
    search: str = typer.Option(
        None, "--search", "-s", help="Server-side text search across name + machine_name."
    ),
    type_filter: list[str] = typer.Option(
        None,
        "--type",
        "-t",
        help="Filter by template type (FUNCTION, STANDARD, ACTION, TRIGGER, ...). Repeatable.",
    ),
    page: int = typer.Option(None, "--page", help="Page number (1-indexed)."),
    page_size: int = typer.Option(None, "--page-size", help="Results per page."),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """List templates; --search filters by name+machine_name, --type filters by template type."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_list_impl)(
        search=search,
        type_filter=type_filter,
        page=page,
        page_size=page_size,
        fmt=fmt,
        full=full,
    )


def _list_impl(
    search: str | None,
    type_filter: list[str] | None,
    page: int | None,
    page_size: int | None,
    fmt: str,
    full: bool,
) -> None:
    params: dict[str, Any] = {}
    if search:
        params["search"] = search
    types = [t for t in (type_filter or []) if t]
    if types:
        params["types"] = ",".join(types)
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size

    config = load_config()
    client = ApiClient.from_config(config)
    try:
        response = client.get(LIST_PATH, params=params or None)
    finally:
        client.close()

    results = response.get("results", []) if isinstance(response, dict) else []
    total = response.get("count", len(results)) if isinstance(response, dict) else len(results)

    hints = ["integry templates get <id>"]
    payload: dict[str, Any] = {"total": total}
    if search:
        payload["query"] = search
    if types:
        payload["types"] = types

    if not results:
        payload["templates"] = []
        if fmt == "json":
            print_success(payload, fmt=fmt, full=True, next_hints=hints)
            return
        message = (
            "no templates match the filter"
            if (search or types)
            else "no templates found"
        )
        sys.stdout.write(f"{message}\n")
        for hint in hints:
            sys.stdout.write(f"next: {hint}\n")
        return

    payload["templates"] = [_shape_list_row(r, full) for r in results]
    print_success(payload, fmt=fmt, full=True, next_hints=hints)


@app.command("update")
def update(
    template_id: int = typer.Argument(..., help="Template primary key."),
    input_path: str = typer.Option(
        None, "--input", "-i", help="Path to JSON body, or '-' for stdin."
    ),
    version: int = typer.Option(None, "--version", help="Target specific template version."),
    publish: bool = typer.Option(False, "--publish", help="Publish after update."),
    archive: bool = typer.Option(False, "--archive", help="Archive after update."),
    meta_only: bool = typer.Option(
        False,
        "--meta-only",
        help="Meta-only update: send ?exclude_template_from_response=true.",
    ),
    revision: int = typer.Option(
        None,
        "--revision",
        help="Set meta.revision_number in the body (convenience for static patch files).",
    ),
    example: bool = typer.Option(
        False,
        "--example",
        help="Print a comprehensive example body to stdout and exit. --input is ignored.",
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """Partial-update a template."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_update_impl)(
        template_id=template_id,
        input_path=input_path,
        version=version,
        publish=publish,
        archive=archive,
        meta_only=meta_only,
        revision=revision,
        example=example,
        fmt=fmt,
        full=full,
    )


def _update_impl(
    template_id: int,
    input_path: str | None,
    version: int | None,
    publish: bool,
    archive: bool,
    meta_only: bool,
    revision: int | None,
    example: bool,
    fmt: str,
    full: bool,
) -> None:
    if example:
        sys.stdout.write(json.dumps(UPDATE_EXAMPLE, indent=2) + "\n")
        return
    if not input_path:
        raise UsageError("--input is required (or pass --example to print a stub body)")
    body = _read_json_input(input_path)
    if not isinstance(body, dict):
        raise UsageError("body must be a JSON object")
    meta = body.get("meta")
    if not isinstance(meta, dict):
        raise UsageError("body must contain a `meta` object")

    if revision is not None:
        meta["revision_number"] = revision
        body["meta"] = meta

    if meta_only and "steps" in body:
        raise UsageError("--meta-only is incompatible with `steps` in the body")

    params: dict[str, Any] = {}
    if version is not None:
        params["version"] = version
    if publish:
        params["publish"] = "true"
    if archive:
        params["archive"] = "true"
    if meta_only:
        params["exclude_template_from_response"] = "true"

    config = load_config()
    client = ApiClient.from_config(config)
    try:
        response = client.patch(
            UPDATE_PATH_TMPL.format(pk=template_id),
            json=body,
            params=params or None,
        )
    finally:
        client.close()

    if meta_only:
        print_success(
            response if isinstance(response, dict) else {"success": True},
            fmt=fmt,
            full=True,
            next_hints=[f"integry templates update {template_id} --input ./patch.json"],
        )
        return

    template = _extract_template(response)
    print_success(
        template,
        fmt=fmt,
        entity="template",
        full=full,
        next_hints=[f"integry templates update {template_id} --input ./patch.json"],
    )


@app.command("get")
def get_template(
    template_id: int = typer.Argument(..., help="Template primary key."),
    version: int = typer.Option(
        None,
        "--version",
        help="Fetch a specific published version of the template.",
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """Retrieve a template (or a specific version with --version).

    Default output is a one-line header followed by a step tree showing
    machine_name, type, and title for each step. Use --full for the
    complete payload.
    """
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_get_impl)(template_id=template_id, version=version, fmt=fmt, full=full)


def _get_impl(template_id: int, version: int | None, fmt: str, full: bool) -> None:
    config = load_config()
    client = ApiClient.from_config(config)
    try:
        if version is not None:
            response = client.get(
                VERSION_DETAIL_PATH_TMPL.format(pk=template_id, version=version)
            )
            entity = "template_version"
            hints = [f"integry templates get-draft {template_id} --version {version}"]
        else:
            response = client.get(GET_PATH_TMPL.format(pk=template_id))
            entity = "template"
            hints = [f"integry templates list-versions {template_id}"]
    finally:
        client.close()

    template = _extract_template(response)

    # Tree summary in TOON mode for templates (unless --full)
    if entity == "template" and fmt != "json" and not full:
        header = render_template_header(template)
        steps = template.get("steps", [])
        sys.stdout.write(header + "\n")
        if steps:
            sys.stdout.write(render_step_tree(steps) + "\n")
        for hint in hints:
            sys.stdout.write(f"next: {hint}\n")
        return

    print_success(template, fmt=fmt, entity=entity, full=full, next_hints=hints)


@app.command("list-versions")
def list_versions(
    template_id: int = typer.Argument(..., help="Base template primary key."),
    page: int = typer.Option(None, "--page", help="Page number (1-indexed)."),
    page_size: int = typer.Option(None, "--page-size", help="Results per page."),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """List versions of a template."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_list_versions_impl)(
        template_id=template_id, page=page, page_size=page_size, fmt=fmt, full=full
    )


def _list_versions_impl(
    template_id: int,
    page: int | None,
    page_size: int | None,
    fmt: str,
    full: bool,
) -> None:
    params: dict[str, Any] = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size

    config = load_config()
    client = ApiClient.from_config(config)
    try:
        response = client.get(
            VERSIONS_PATH_TMPL.format(pk=template_id), params=params or None
        )
    finally:
        client.close()

    results = response.get("results", []) if isinstance(response, dict) else []
    total = response.get("count", len(results)) if isinstance(response, dict) else len(results)
    hints = [f"integry templates publish {template_id}"]

    if not results:
        _print_empty_versions(template_id, total, fmt, hints)
        return

    shaped = [_shape_version(v, full) for v in results]
    payload = {"total": total, "versions": shaped}
    print_success(payload, fmt=fmt, full=True, next_hints=hints)


@app.command("publish")
def publish(
    template_id: int = typer.Argument(..., help="Draft template primary key."),
    changelog: str = typer.Option(
        None, "--changelog", help="Optional changelog to attach to the new version."
    ),
    beta: bool = typer.Option(
        False,
        "--beta",
        help="Publish for beta users only (?publish_for_beta_users=true).",
    ),
    upgrade_integrations: bool = typer.Option(
        False,
        "--upgrade-integrations",
        help="Upgrade existing integrations to the new version (?upgrade_integrations=true).",
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """Publish the current draft as a new version."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_publish_impl)(
        template_id=template_id,
        changelog=changelog,
        beta=beta,
        upgrade_integrations=upgrade_integrations,
        fmt=fmt,
        full=full,
    )


def _publish_impl(
    template_id: int,
    changelog: str | None,
    beta: bool,
    upgrade_integrations: bool,
    fmt: str,
    full: bool,
) -> None:
    body: dict[str, Any] = {}
    if changelog is not None:
        body["changelog"] = changelog

    params: dict[str, Any] = {}
    if beta:
        params["publish_for_beta_users"] = "true"
    if upgrade_integrations:
        params["upgrade_integrations"] = "true"

    config = load_config()
    client = ApiClient.from_config(config)
    try:
        response = client.post(
            VERSIONS_PATH_TMPL.format(pk=template_id),
            json=body,
            params=params or None,
        )
    finally:
        client.close()

    template = _extract_template(response)
    print_success(
        template,
        fmt=fmt,
        entity="template",
        full=full,
        next_hints=[f"integry templates list-versions {template_id}"],
    )


@app.command("get-draft")
def get_draft(
    template_id: int = typer.Argument(
        ..., help="Base template primary key."
    ),
    version: int = typer.Option(
        None, "--version", help="Specific version number to export as draft."
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """Fetch a template (or a specific version) as a draft body usable by `templates create`."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_get_draft_impl)(
        template_id=template_id, version=version, fmt=fmt, full=full
    )


def _get_draft_impl(template_id: int, version: int | None, fmt: str, full: bool) -> None:
    params: dict[str, Any] = {"return_as_draft": "true"}
    if version is not None:
        params["version"] = version

    config = load_config()
    client = ApiClient.from_config(config)
    try:
        response = client.get(
            GET_PATH_TMPL.format(pk=template_id),
            params=params,
        )
    finally:
        client.close()

    if isinstance(response, dict):
        _sanitize_output_fields(response)
        _strip_redundant_keys(response)

    if full:
        payload: Any = response
    else:
        payload = _summarize_draft(response)

    print_success(
        payload,
        fmt=fmt,
        full=True,
        next_hints=["integry templates create --input <draft.json>"],
    )


@app.command("diff")
def diff_template(
    template_id: int = typer.Argument(..., help="Base template primary key."),
    version: int = typer.Option(
        ..., "--version", help="Version number to compare against the current draft."
    ),
    context: int = typer.Option(
        5, "--context", "-C", help="Number of context lines around each change."
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(
        False, "--full", help="Show full unified JSON diff instead of step-level summary."
    ),
) -> None:
    """Show differences between a published version and the current draft.

    Default output is a step-level tree summary with diff markers:

      + added step
      - removed step
      ~ modified step  [details]
      (unmarked) unchanged step

    Modified steps show hints like [fields: 2 changed] or [1 prop changed].
    Meta changes appear as: ~ meta: title, description changed

    Use --full for a unified JSON diff (ignoring IDs).
    Use `integry templates <id> diff-step <step> --version N` to drill into field-level changes.
    """
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_diff_impl)(
        template_id=template_id, version=version, context=context, fmt=fmt, full=full
    )


def _diff_impl(template_id: int, version: int, context: int, fmt: str, full: bool) -> None:
    config = load_config()
    client = ApiClient.from_config(config)
    try:
        version_response = client.get(
            GET_PATH_TMPL.format(pk=template_id),
            params={"version": version},
        )
        draft_response = client.get(GET_PATH_TMPL.format(pk=template_id))
    finally:
        client.close()

    # Sanitize output fields on both responses
    if isinstance(version_response, dict):
        _sanitize_output_fields(version_response)
    if isinstance(draft_response, dict):
        _sanitize_output_fields(draft_response)

    # Tree summary in TOON mode (unless --full)
    if fmt != "json" and not full:
        ver_template = version_response if isinstance(version_response, dict) else {}
        draft_template = draft_response if isinstance(draft_response, dict) else {}

        header = render_template_header(draft_template)

        # Strip redundant keys so diff only sees meaningful properties
        _strip_redundant_keys(ver_template)
        _strip_redundant_keys(draft_template)

        ver_meta = _strip_ids(ver_template.get("meta", {}))
        draft_meta = _strip_ids(draft_template.get("meta", {}))
        ver_steps = ver_template.get("steps", [])
        draft_steps = draft_template.get("steps", [])

        diff_lines = render_diff_tree(ver_steps, draft_steps, ver_meta, draft_meta)
        has_changes = any(line.startswith(("+", "-", "~")) for line in diff_lines)
        if not has_changes:
            sys.stdout.write("no differences\n")
        else:
            sys.stdout.write(f"{header} (v{version} vs draft)\n")
            sys.stdout.write("\n".join(diff_lines) + "\n")
            sys.stdout.write(f"next: integry templates {template_id} diff-step <machine_name> --version {version}\n")
        return

    # Full unified diff path - strip redundant keys
    if isinstance(version_response, dict):
        _strip_redundant_keys(version_response)
    if isinstance(draft_response, dict):
        _strip_redundant_keys(draft_response)

    cleaned_version = _strip_ids(version_response)
    cleaned_draft = _strip_ids(draft_response)

    version_lines = json.dumps(cleaned_version, indent=2, sort_keys=True).splitlines(keepends=True)
    draft_lines = json.dumps(cleaned_draft, indent=2, sort_keys=True).splitlines(keepends=True)

    diff_lines = list(difflib.unified_diff(
        version_lines,
        draft_lines,
        fromfile=f"version {version}",
        tofile="draft",
        n=context,
    ))

    if not diff_lines:
        if fmt == "json":
            sys.stdout.write(json.dumps({"ok": True, "data": {"diff": "", "has_changes": False}}) + "\n")
        else:
            sys.stdout.write("no differences\n")
        return

    diff_text = "".join(diff_lines)

    if fmt == "json":
        sys.stdout.write(json.dumps({"ok": True, "data": {"diff": diff_text, "has_changes": True}}) + "\n")
    else:
        sys.stdout.write(diff_text)
        if not diff_text.endswith("\n"):
            sys.stdout.write("\n")


_STRIP_KEYS = frozenset({
    "id", "version_template_id", "version_of", "version_number",
    "last_modified", "last_modified_by", "created",
    "publishing_status", "revision_number",
})


def _strip_ids(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _strip_ids(v) for k, v in value.items() if k not in _STRIP_KEYS}
    if isinstance(value, list):
        return [_strip_ids(item) for item in value]
    return value


@app.command("test")
def test_function(
    template_id: int = typer.Argument(..., help="Template primary key (must be type=FUNCTION)."),
    input_path: str = typer.Option(
        None, "--input", "-i", help="Path to JSON arguments, or '-' for stdin."
    ),
    connected_account_id: int = typer.Option(
        None,
        "--connected-account-id",
        help="Connected account id to use. Skips the selection prompt.",
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
    full: bool = typer.Option(False, "--full", help="Skip field filtering and truncation."),
) -> None:
    """Test a FUNCTION template draft with a connected account."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_test_impl)(
        template_id=template_id,
        input_path=input_path,
        connected_account_id=connected_account_id,
        fmt=fmt,
        full=full,
    )


def _test_impl(
    template_id: int,
    input_path: str | None,
    connected_account_id: int | None,
    fmt: str,
    full: bool,
) -> None:
    config = load_config()
    client = ApiClient.from_config(config)

    # 1. Fetch template and verify it's a FUNCTION
    try:
        template = client.get(GET_PATH_TMPL.format(pk=template_id))
    finally:
        client.close()

    tpl = _extract_template(template)
    tpl_type = tpl.get("type") or (tpl.get("meta", {}) or {}).get("type")
    machine_name = tpl.get("machine_name") or (tpl.get("meta", {}) or {}).get("machine_name")
    if tpl_type != "FUNCTION":
        raise UsageError(f"template {template_id} is type={tpl_type}, expected FUNCTION")
    if not machine_name:
        raise UsageError(f"template {template_id} has no machine_name")

    # 2. Need account_id for the test user_id
    if config.account_id is None:
        raise UsageError(
            "account id required for testing — set INTEGRY_ACCOUNT_ID or run: integry accounts use <id>"
        )

    # 3. Fetch workspace app credentials from /accounts/me/
    client2 = ApiClient.from_config(config)
    try:
        me = client2.get(ME_PATH)
    finally:
        client2.close()

    ws_app = (me.get("account") or {}).get("default_workspace_app") if isinstance(me, dict) else None
    if not isinstance(ws_app, dict) or not ws_app.get("key") or not ws_app.get("secret"):
        raise UsageError("could not retrieve workspace app credentials from /accounts/me/")

    app_key = ws_app["key"]
    app_secret = ws_app["secret"]
    user_id = f"INTEGRY_TEST_INTEGRATION_CREATOR_{config.account_id}"

    # 4. Compute HMAC-SHA256 hash
    sig = hmac.new(
        app_secret.encode("utf-8"),
        user_id.encode("utf-8"),
        digestmod=hashlib.sha256,
    ).hexdigest()

    # 5. Resolve connected account
    if connected_account_id is None:
        connected_account_id = _resolve_connected_account(
            config, app_key, app_secret, user_id, sig, machine_name
        )

    # 6. Read arguments
    args_body: Any = {}
    if input_path:
        args_body = _read_json_input(input_path)

    # 7. Call the function
    call_params = {
        "user_id": user_id,
        "app_key": app_key,
        "hash": sig,
        "connected_account_id": str(connected_account_id),
        "allow_workspace_connected_accounts": "true",
    }
    call_url = FUNCTION_CALL_PATH_TMPL.format(machine_name=machine_name)

    with httpx.Client(base_url=config.api_url, timeout=60) as raw_client:
        resp = raw_client.post(
            call_url,
            params=call_params,
            json=args_body,
            headers={
                "Content-Type": "application/json",
                "version": "DRAFT",
            },
        )

    if resp.status_code >= 400:
        detail = None
        try:
            detail = resp.json()
        except ValueError:
            detail = resp.text
        raise ApiError(
            f"function call failed ({resp.status_code})",
            status=resp.status_code,
            detail=detail,
        )

    result = resp.json() if resp.content else {}
    print_success(result, fmt=fmt, full=full, next_hints=[])


def _resolve_connected_account(
    config: Any,
    app_key: str,
    app_secret: str,
    user_id: str,
    sig: str,
    machine_name: str,
) -> int:
    """Fetch connected accounts for the app and prompt if multiple."""
    app_get_url = APP_GET_PATH_TMPL.format(machine_name=machine_name)
    params = {
        "include": "connected_accounts.extras",
        "ignore_marketplace": "true",
        "user_id": user_id,
        "app_key": app_key,
        "hash": sig,
        "allow_workspace_connected_accounts": "true",
    }

    with httpx.Client(base_url=config.api_url, timeout=30) as raw_client:
        resp = raw_client.post(app_get_url, params=params, json={})

    if resp.status_code >= 400:
        detail = None
        try:
            detail = resp.json()
        except ValueError:
            detail = resp.text
        raise ApiError(
            f"failed to fetch app connected accounts ({resp.status_code})",
            status=resp.status_code,
            detail=detail,
        )

    body = resp.json() if resp.content else {}
    accounts = body.get("connected_accounts", []) if isinstance(body, dict) else []
    if not accounts:
        raise UsageError(
            f"no connected accounts for app '{machine_name}' — connect one first"
        )

    if len(accounts) == 1:
        return accounts[0]["id"]

    # Multiple accounts — prompt user to choose
    sys.stdout.write("Multiple connected accounts found:\n")
    for idx, acct in enumerate(accounts, 1):
        display = acct.get("display_name") or acct.get("id")
        sys.stdout.write(f"  {idx}. {display} (id={acct['id']})\n")
    sys.stdout.write("Select account [1]: ")
    sys.stdout.flush()

    raw = sys.stdin.readline().strip()
    choice = int(raw) if raw.isdigit() else 1
    if choice < 1 or choice > len(accounts):
        choice = 1
    return accounts[choice - 1]["id"]


def _read_json_input(path_arg: str) -> Any:
    if path_arg == "-":
        raw = sys.stdin.read()
    else:
        path = Path(path_arg)
        if not path.is_file():
            raise UsageError(f"input file not found: {path_arg}")
        raw = path.read_text()
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        raise UsageError(f"invalid JSON in {path_arg}: {e.msg} (line {e.lineno})")


def _extract_template(response: Any) -> dict:
    if isinstance(response, dict):
        _sanitize_output_fields(response)
        _strip_redundant_keys(response)
        return response
    if isinstance(response, list) and response and isinstance(response[0], dict):
        _sanitize_output_fields(response[0])
        _strip_redundant_keys(response[0])
        return response[0]
    return {"raw": response}


def _template_id(template: dict) -> Any:
    if "id" in template:
        return template["id"]
    meta = template.get("meta") if isinstance(template, dict) else None
    if isinstance(meta, dict):
        return meta.get("id")
    return None


def _shape_list_row(row: Any, full: bool) -> dict:
    if not isinstance(row, dict):
        return {"raw": row}
    if full:
        return row
    return {k: row.get(k) for k in TEMPLATE_LIST_FIELDS}


def _shape_version(version: dict, full: bool) -> dict:
    if full:
        return version
    fields = ("id", "version", "publishing_status", "is_live", "integration_count", "changelog")
    return {k: version.get(k) for k in fields if k in version}


def _summarize_draft(response: Any) -> dict:
    if not isinstance(response, dict):
        return {"raw": response}
    meta = response.get("meta", {}) if isinstance(response.get("meta"), dict) else {}
    steps = response.get("steps", []) if isinstance(response.get("steps"), list) else []
    return {
        "title": meta.get("title"),
        "app_id": meta.get("app_id"),
        "publishing_status": meta.get("publishing_status"),
        "step_count": len(steps),
    }


OUTPUT_ACTIVITY_FIELD_IDS = frozenset({116460, 152552})

META_KEYS_TO_REMOVE = frozenset({
    "tooltip", "return_data", "return_format", "enable_product_info", "product_info",
    "app", "branding_app", "status", "direction", "tags", "is_saving", "is_publishable",
    "is_wizard", "button_text", "webhook_url", "error_notification_throttling",
    "webhook_payload", "enable_loop_prevention", "enable_jobs_serialization", "notes",
    "cache_integration_output", "cache_integration_duration", "version",
    "is_error_notification_enabled", "end_user_integration_count", "is_shared",
    "bundle_url", "last_modified_by", "execution_type", "allow_multiple_instances",
    "events", "integration", "app_object", "app_object_id", "chat_initialization_prompt",
    "is_system_template", "abort_on_step_error", "execution_behaviour",
    "integration_update_job_in_progress", "active_integrations_count", "test_integration",
    "should_auto_disable_integrations_on_errors", "storage_version", "integration_count",
    "apps", "last_modified", "created", "locked_by", "revision_number",
    "function_call_mode", "icon_url", "test_user_hash",
    "can_end_users_upgrade_integrations", "allow_unauthenticated_call", "is_draft_empty",
    "is_available_as_built_in", "built_in_function", "original_template_id",
    "function_verb", "draft_template_id", "root_node_id",
})

STEP_KEYS_TO_REMOVE = frozenset({
    "app", "step_obj_ref", "is_visible", "button_text", "sample_output", "summary",
    "auth_description", "query_records_limit", "step_condition", "is_form_step",
    "is_custom_machine_name", "authorization_id", "authorization",
    "omit_keys_with_empty_values", "follow_redirects", "use_internal_auth",
    "activity", "authorization_type",
    "tag_source_function", "function_template_id", "remove_unresolved_tags",
    "activity_version", "comments", "hide_authorization", "app_id", "step_app",
    "custom_fields", "step_type", "description", "form_step_machine_name",
    "activity_output_url", "trigger_test_url", "test_output",
    "should_abort_run_on_error", "query_iteration_mode", "retry_config",
    "output_keys_to_omit", "show_exposed_fields_only", "built_in_function_id",
    "integration_template_trigger_url", "is_paginated_function_template",
    "tag_source_function_id", "enable_realtime_updates", "use_connected_tables",
    "intra_version_guid", "function_template", "credits_expression", "body_type",
    "trigger_url_instructions",
})

FIELD_KEYS_TO_REMOVE = frozenset({
    "is_hidden", "summary", "manual_template", "long_description", "is_visible",
    "classname", "field_actions", "data", "added_in_mapping", "field_mapping_source",
    "activity_field_type", "test_value", "auto_machine_name", "dynamic_field_src",
    "is_searchable", "sample_data_src", "is_custom_machine_name",
    "tag_source_step_machine_name", "child_field", "child_field_value", "button_text",
    "icon_url", "condition_json", "form_field_machine_name",
    "activity_field_machine_name", "activity_field_description",
    "activity_field_is_required", "activity_field_title", "is_button_enabled",
    "on_button_click_script", "regex", "regex_msg", "is_editable",
    "allow_tags_in_text", "is_mappable",
})

FIELD_NON_PARAMETER_KEYS_TO_REMOVE = frozenset({
    "technical_description", "description", "title", "type", "fields", "placeholder",
    "parent_fields", "is_dynamic", "is_multiselect", "source_template_id",
    "source_template_config", "option_key_path", "value_key_path", "type_key_path",
    "is_required_key_path", "description_key_path", "data_src",
})


def _sanitize_output_fields(template: dict) -> None:
    for step in template.get("steps", []):
        _sanitize_step_output_fields(step)


def _sanitize_step_output_fields(step: dict) -> None:
    for field in step.get("fields", []):
        if field.get("activity_field_id") in OUTPUT_ACTIVITY_FIELD_IDS:
            field["default_value"] = ""
    for sub_step in step.get("steps", []):
        _sanitize_step_output_fields(sub_step)


def _strip_redundant_keys(template: dict) -> None:
    meta = template.get("meta")
    if isinstance(meta, dict):
        for key in META_KEYS_TO_REMOVE:
            meta.pop(key, None)
    for step in template.get("steps", []):
        _strip_step_keys(step)


def _strip_step_keys(step: dict) -> None:
    for key in STEP_KEYS_TO_REMOVE:
        step.pop(key, None)
    for field in step.get("fields", []):
        _strip_field_keys(field)
    for sub_step in step.get("steps", []):
        _strip_step_keys(sub_step)


def _strip_field_keys(field: dict) -> None:
    for key in FIELD_KEYS_TO_REMOVE:
        field.pop(key, None)
    if field.get("activity_field_id") is not None:
        for key in FIELD_NON_PARAMETER_KEYS_TO_REMOVE:
            field.pop(key, None)
    for nested_field in field.get("fields", []):
        _strip_field_keys(nested_field)


def _print_empty_versions(template_id: int, total: int, fmt: str, hints: list[str]) -> None:
    if fmt == "json":
        print_success({"total": total, "versions": []}, fmt=fmt, full=True, next_hints=hints)
        return
    sys.stdout.write("no versions yet — publish a draft to create one\n")
    for hint in hints:
        sys.stdout.write(f"next: {hint}\n")
