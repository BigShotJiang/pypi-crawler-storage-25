from __future__ import annotations

from typing import Any

import click
import typer.main

from integry_cli.commands import template_steps as ops


def install_templates_group(typer_app) -> None:
    """Monkey-patch the Typer app so its Click group resolves numeric IDs."""
    original_get_group = typer.main.get_group

    def patched_get_group(typer_instance, *args, **kwargs):
        group = original_get_group(typer_instance, *args, **kwargs)
        if id(typer_instance) == id(typer_app):
            original_templates = group.commands.get("templates")
            if original_templates is not None and not isinstance(original_templates, TemplatesGroup):
                group.commands["templates"] = TemplatesGroup(original_templates)
        return group

    typer.main.get_group = patched_get_group


class TemplatesGroup(click.Group):
    """Custom group that dispatches both named commands and `<id> <operation>` syntax."""

    def __init__(self, original: click.Group):
        super().__init__(
            name="templates",
            help=original.help or "Create or update Integry templates.",
        )
        self._original = original

    def list_commands(self, ctx: click.Context) -> list[str]:
        return self._original.list_commands(ctx)

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        if cmd_name.isdigit():
            ctx.ensure_object(dict)
            ctx.obj["_template_id"] = int(cmd_name)
            return _resource_group
        return self._original.get_command(ctx, cmd_name)

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        self._original.format_help(ctx, formatter)
        formatter.write("\n")
        with formatter.section("Step & field operations"):
            formatter.write_text(
                "Use templates <id> <command> to operate on a specific template's"
                " steps and fields. STEP and FIELD refer to machine_name."
                " Fields use step:field colon notation."
            )
            formatter.write_paragraph()
            formatter.write_text(
                "Examples:"
            )
            formatter.indent()
            formatter.write_text("integry templates 42 list-steps")
            formatter.write_text('integry templates 42 set-field-value send_email:subject --value "Hello"')
            formatter.dedent()
            formatter.write_dl([
                ("list-steps [STEP]", "List top-level steps, or children of STEP."),
                ("get-step STEP", "Get a step by machine_name."),
                ("diff-step STEP --version N", "Field-level diff vs a published version."),
                ("add-step", "Add a new step (--input FILE [--at N])."),
                ("update-step STEP", "Replace a step (--input FILE)."),
                ("remove-step STEP", "Remove a step (--no-cascade to keep children)."),
                ("move-step STEP", "Reorder (--to N) or reparent (--parent NAME --at N)."),
                ("list-fields STEP", "List fields of a step."),
                ("get-field STEP:FIELD", "Get a field."),
                ("set-field-value STEP:FIELD", "Set default_value (--value VAL)."),
                ("update-field STEP:FIELD", "Replace a field (--input FILE)."),
                ("add-field STEP", "Add a field to a step (--input FILE [--at N])."),
                ("remove-field STEP:FIELD", "Remove a field."),
                ("move-field STEP:FIELD", "Reorder a field (--to N)."),
            ])


_FMT_OPTION = click.Option(
    ["--format", "fmt"], default="toon", help="Output format: toon|json"
)
_FULL_OPTION = click.Option(
    ["--full"], is_flag=True, default=False, help="Skip field filtering and truncation."
)


def _template_id(ctx: click.Context) -> int:
    return ctx.parent.obj["_template_id"]


@click.group(name="resource", invoke_without_command=True)
@click.pass_context
def _resource_group(ctx: click.Context) -> None:
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ---------------------------------------------------------------------------
# Step commands
# ---------------------------------------------------------------------------


@_resource_group.command("list-steps")
@click.argument("parent_step", required=False, default=None)
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def list_steps(ctx: click.Context, parent_step: str | None, fmt: str, full: bool) -> None:
    """List direct child steps as an indented tree (machine_name, type, title).

    Use --full for the complete payload in TOON table format.
    """
    _run(ops.list_steps, ctx, parent_step=parent_step, fmt=fmt, full=full)


@_resource_group.command("get-step")
@click.argument("step_name")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def get_step(ctx: click.Context, step_name: str, fmt: str, full: bool) -> None:
    """Get a step by machine_name."""
    _run(ops.get_step, ctx, step_name=step_name, fmt=fmt, full=full)


@_resource_group.command("diff-step")
@click.argument("step_name")
@click.option("--version", required=True, type=int, help="Version number to compare against the draft.")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Show full values without truncation.")
@click.pass_context
def diff_step(ctx: click.Context, step_name: str, version: int, fmt: str, full: bool) -> None:
    """Show field-level diff for a step between a published version and the draft.

    Legend: + added field/prop, - removed field/prop, ~ changed (old -> new).
    Use --full to show complete values without truncation.
    """
    _run(ops.diff_step, ctx, step_name=step_name, version=version, fmt=fmt, full=full)


@_resource_group.command("add-step")
@click.option("--input", "input_path", required=False, help="Path to JSON step, or '-' for stdin.")
@click.option("--at", "at_position", type=int, default=None, help="Insert at this position (0-indexed).")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def add_step(ctx: click.Context, input_path: str | None, at_position: int | None, fmt: str, full: bool) -> None:
    """Add a new step to the template."""
    _run(ops.add_step, ctx, input_path=input_path, at_position=at_position, fmt=fmt, full=full)


@_resource_group.command("update-step")
@click.argument("step_name")
@click.option("--input", "input_path", required=False, help="Path to JSON step, or '-' for stdin.")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def update_step(ctx: click.Context, step_name: str, input_path: str | None, fmt: str, full: bool) -> None:
    """Replace a step by machine_name."""
    _run(ops.update_step, ctx, step_name=step_name, input_path=input_path, fmt=fmt, full=full)


@_resource_group.command("remove-step")
@click.argument("step_name")
@click.option("--no-cascade", is_flag=True, default=False, help="Move children to parent instead of deleting them.")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def remove_step(ctx: click.Context, step_name: str, no_cascade: bool, fmt: str, full: bool) -> None:
    """Remove a step. Default cascades (deletes children). --no-cascade moves children to parent."""
    _run(ops.remove_step, ctx, step_name=step_name, no_cascade=no_cascade, fmt=fmt, full=full)


@_resource_group.command("move-step")
@click.argument("step_name")
@click.option("--to", "to_position", type=int, default=None, help="New position within current parent (0-indexed).")
@click.option("--parent", "parent_name", default=None, help="Reparent under this step (by machine_name).")
@click.option("--at", "at_position", type=int, default=None, help="Position within new parent (used with --parent).")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def move_step(
    ctx: click.Context,
    step_name: str,
    to_position: int | None,
    parent_name: str | None,
    at_position: int | None,
    fmt: str,
    full: bool,
) -> None:
    """Move a step: --to N reorders within parent, --parent NAME --at N reparents."""
    _run(
        ops.move_step,
        ctx,
        step_name=step_name,
        to_position=to_position,
        parent_name=parent_name,
        at_position=at_position,
        fmt=fmt,
        full=full,
    )


# ---------------------------------------------------------------------------
# Field commands
# ---------------------------------------------------------------------------


@_resource_group.command("list-fields")
@click.argument("step_name")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def list_fields(ctx: click.Context, step_name: str, fmt: str, full: bool) -> None:
    """List fields of a step."""
    _run(ops.list_fields, ctx, step_name=step_name, fmt=fmt, full=full)


@_resource_group.command("get-field")
@click.argument("field_ref")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def get_field(ctx: click.Context, field_ref: str, fmt: str, full: bool) -> None:
    """Get a field by step_name:field_name."""
    _run(ops.get_field, ctx, field_ref=field_ref, fmt=fmt, full=full)


@_resource_group.command("set-field-value")
@click.argument("field_ref")
@click.option("--value", required=True, help="New default_value. JSON auto-detected; '-' reads stdin.")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def set_field_value(ctx: click.Context, field_ref: str, value: str, fmt: str, full: bool) -> None:
    """Set a field's default_value. FIELD_REF is step_name:field_name."""
    _run(ops.set_field_value, ctx, field_ref=field_ref, value=value, fmt=fmt, full=full)


@_resource_group.command("update-field")
@click.argument("field_ref")
@click.option("--input", "input_path", required=False, help="Path to JSON field, or '-' for stdin.")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def update_field(ctx: click.Context, field_ref: str, input_path: str | None, fmt: str, full: bool) -> None:
    """Replace a full field object. FIELD_REF is step_name:field_name."""
    _run(ops.update_field, ctx, field_ref=field_ref, input_path=input_path, fmt=fmt, full=full)


@_resource_group.command("add-field")
@click.argument("step_name")
@click.option("--input", "input_path", required=False, help="Path to JSON field, or '-' for stdin.")
@click.option("--at", "at_position", type=int, default=None, help="Insert at this position (0-indexed).")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def add_field(ctx: click.Context, step_name: str, input_path: str | None, at_position: int | None, fmt: str, full: bool) -> None:
    """Add a new field to a step."""
    _run(ops.add_field, ctx, step_name=step_name, input_path=input_path, at_position=at_position, fmt=fmt, full=full)


@_resource_group.command("remove-field")
@click.argument("field_ref")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def remove_field(ctx: click.Context, field_ref: str, fmt: str, full: bool) -> None:
    """Remove a field from its step. FIELD_REF is step_name:field_name."""
    _run(ops.remove_field, ctx, field_ref=field_ref, fmt=fmt, full=full)


@_resource_group.command("move-field")
@click.argument("field_ref")
@click.option("--to", "to_position", type=int, required=True, help="New position (0-indexed).")
@click.option("--format", "fmt", default="toon", help="Output format: toon|json")
@click.option("--full", is_flag=True, default=False, help="Skip field filtering and truncation.")
@click.pass_context
def move_field(ctx: click.Context, field_ref: str, to_position: int, fmt: str, full: bool) -> None:
    """Reorder a field within its step (0-indexed). FIELD_REF is step_name:field_name."""
    _run(ops.move_field, ctx, field_ref=field_ref, to_position=to_position, fmt=fmt, full=full)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run(fn, ctx: click.Context, **kwargs: Any) -> None:
    from integry_cli.cli import handle_cli_errors
    from integry_cli.errors import CLIError
    from integry_cli.output import print_error

    template_id = _template_id(ctx)
    try:
        handle_cli_errors(fn)(template_id=template_id, **kwargs)
    except SystemExit as exc:
        ctx.exit(exc.code)
