from __future__ import annotations

import typer

from integry_cli import auth as auth_mod
from integry_cli.config import load_config, save_api_url
from integry_cli.errors import UsageError
from integry_cli.output import print_success

app = typer.Typer(help="Manage CLI credentials.", no_args_is_help=True)


@app.command("login")
def login(
    username: str = typer.Option(..., "--username", "-u", help="Account username."),
    password: str = typer.Option(
        None,
        "--password",
        "-p",
        help="Password. Prompted if omitted.",
        hide_input=True,
        prompt=True,
    ),
    api_url: str = typer.Option(
        None, "--api-url", help="Override and persist the backend base URL."
    ),
    fmt: str = typer.Option("toon", "--format", help="Output format: toon|json"),
) -> None:
    """Obtain and store access+refresh tokens."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_login_impl)(username=username, password=password, api_url=api_url, fmt=fmt)


def _login_impl(username: str, password: str, api_url: str | None, fmt: str) -> None:
    if api_url:
        save_api_url(api_url)
    config = load_config()
    tokens = auth_mod.login(config, username, password)
    print_success(
        {
            "username": username,
            "api_url": config.api_url,
            "access_expires_in": auth_mod.expires_in_seconds(tokens.access),
            "refresh_expires_in": auth_mod.expires_in_seconds(tokens.refresh),
        },
        fmt=fmt,
        next_hints=["integry accounts list"],
    )


@app.command("logout")
def logout(fmt: str = typer.Option("toon", "--format", help="Output format: toon|json")) -> None:
    """Clear stored credentials. Idempotent."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_logout_impl)(fmt=fmt)


def _logout_impl(fmt: str) -> None:
    config = load_config()
    cleared = auth_mod.clear_tokens(config)
    print_success({"cleared": cleared, "api_url": config.api_url}, fmt=fmt)


@app.command("status")
def status(fmt: str = typer.Option("toon", "--format", help="Output format: toon|json")) -> None:
    """Show current auth state."""
    from integry_cli.cli import handle_cli_errors

    handle_cli_errors(_status_impl)(fmt=fmt)


def _status_impl(fmt: str) -> None:
    config = load_config()
    tokens = auth_mod.load_tokens(config)
    if tokens is None:
        raise UsageError("not authenticated — run: integry auth login")
    claims = auth_mod.decode_jwt_claims(tokens.access)
    print_success(
        {
            "api_url": config.api_url,
            "user_id": claims.get("user_id"),
            "account_id": config.account_id,
            "access_expires_in": auth_mod.expires_in_seconds(tokens.access),
            "refresh_expires_in": auth_mod.expires_in_seconds(tokens.refresh),
        },
        fmt=fmt,
    )
