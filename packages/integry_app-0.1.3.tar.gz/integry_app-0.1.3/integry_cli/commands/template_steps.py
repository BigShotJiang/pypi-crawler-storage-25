from __future__ import annotations

import difflib
import json
import sys
from pathlib import Path
from typing import Any

from integry_cli.client import ApiClient
from integry_cli.config import load_config
from integry_cli.errors import UsageError
from integry_cli.output import print_success, render_step_tree

GET_PATH_TMPL = "/api/v2/templates/{pk}/"
UPDATE_PATH_TMPL = "/api/v5/templates/{pk}/"


# ---------------------------------------------------------------------------
# Step operations
# ---------------------------------------------------------------------------


def list_steps(
    template_id: int,
    parent_step: str | None,
    fmt: str,
    full: bool,
) -> None:
    draft = _fetch_draft(template_id)
    all_steps = draft.get("steps", [])

    if parent_step is not None:
        parent = _find_step_recursive(all_steps, parent_step)
        if parent is None:
            raise UsageError(f"step '{parent_step}' not found")
        children = parent.get("steps", [])
    else:
        children = all_steps

    if not children:
        _print_empty("no steps", template_id, fmt)
        return

    # Tree view in TOON mode (unless --full)
    if fmt != "json" and not full:
        sys.stdout.write(render_step_tree(children) + "\n")
        sys.stdout.write(f"next: integry templates {template_id} get-step <machine_name>\n")
        return

    payload = {"total": len(children), "steps": children}
    print_success(
        payload,
        fmt=fmt,
        full=full,
        next_hints=[f"integry templates {template_id} get-step <machine_name>"],
    )


def get_step(
    template_id: int,
    step_name: str,
    fmt: str,
    full: bool,
) -> None:
    draft = _fetch_draft(template_id)
    step = _find_step_recursive(draft.get("steps", []), step_name)
    if step is None:
        raise UsageError(f"step '{step_name}' not found")
    print_success(
        step,
        fmt=fmt,
        entity="step",
        full=full,
        next_hints=[f"integry templates {template_id} list-fields {step_name}"],
    )


def add_step(
    template_id: int,
    input_path: str | None,
    at_position: int | None,
    fmt: str,
    full: bool,
) -> None:
    if not input_path:
        raise UsageError("--input is required")
    new_step = _read_json_input(input_path)

    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])

    if at_position is not None:
        steps.insert(at_position, new_step)
    else:
        steps.append(new_step)

    _reweight(steps)
    _patch_template(template_id, draft, steps)
    print_success(
        new_step,
        fmt=fmt,
        entity="step",
        full=full,
        next_hints=[f"integry templates {template_id} list-steps"],
    )


def update_step(
    template_id: int,
    step_name: str,
    input_path: str | None,
    fmt: str,
    full: bool,
) -> None:
    if not input_path:
        raise UsageError("--input is required")
    replacement = _read_json_input(input_path)

    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])
    parent_list, idx = _find_step_in_parent(steps, step_name)
    if idx is None:
        raise UsageError(f"step '{step_name}' not found")

    parent_list[idx] = replacement
    _reweight(parent_list)
    _patch_template(template_id, draft, steps)
    print_success(
        replacement,
        fmt=fmt,
        entity="step",
        full=full,
        next_hints=[f"integry templates {template_id} get-step {step_name}"],
    )


def remove_step(
    template_id: int,
    step_name: str,
    no_cascade: bool,
    fmt: str,
    full: bool,
) -> None:
    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])
    parent_list, idx = _find_step_in_parent(steps, step_name)
    if idx is None:
        raise UsageError(f"step '{step_name}' not found")

    removed = parent_list.pop(idx)
    if no_cascade:
        children = removed.get("steps", [])
        for i, child in enumerate(children):
            parent_list.insert(idx + i, child)

    _reweight(parent_list)
    _patch_template(template_id, draft, steps)
    print_success(
        {"removed": step_name},
        fmt=fmt,
        full=True,
        next_hints=[f"integry templates {template_id} list-steps"],
    )


def move_step(
    template_id: int,
    step_name: str,
    to_position: int | None,
    parent_name: str | None,
    at_position: int | None,
    fmt: str,
    full: bool,
) -> None:
    if to_position is None and parent_name is None:
        raise UsageError("--to or --parent is required")

    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])
    source_list, idx = _find_step_in_parent(steps, step_name)
    if idx is None:
        raise UsageError(f"step '{step_name}' not found")

    moved = source_list.pop(idx)
    _reweight(source_list)

    if parent_name is not None:
        target_parent = _find_step_recursive(steps, parent_name)
        if target_parent is None:
            raise UsageError(f"parent step '{parent_name}' not found")
        target_list = target_parent.setdefault("steps", [])
        insert_at = at_position if at_position is not None else len(target_list)
        target_list.insert(insert_at, moved)
        _reweight(target_list)
    else:
        source_list.insert(to_position, moved)
        _reweight(source_list)

    _patch_template(template_id, draft, steps)
    print_success(
        moved,
        fmt=fmt,
        entity="step",
        full=full,
        next_hints=[f"integry templates {template_id} list-steps"],
    )


# ---------------------------------------------------------------------------
# Field operations
# ---------------------------------------------------------------------------


def list_fields(
    template_id: int,
    step_name: str,
    fmt: str,
    full: bool,
) -> None:
    draft = _fetch_draft(template_id)
    step = _find_step_recursive(draft.get("steps", []), step_name)
    if step is None:
        raise UsageError(f"step '{step_name}' not found")

    fields = step.get("fields", [])
    if not fields:
        _print_empty("no fields", template_id, fmt, step_name=step_name)
        return

    payload = {"total": len(fields), "fields": fields}
    print_success(
        payload,
        fmt=fmt,
        full=full,
        next_hints=[f"integry templates {template_id} get-field {step_name}:<machine_name>"],
    )


def get_field(
    template_id: int,
    field_ref: str,
    fmt: str,
    full: bool,
) -> None:
    step_name, field_name = _parse_field_ref(field_ref)
    draft = _fetch_draft(template_id)
    step = _find_step_recursive(draft.get("steps", []), step_name)
    if step is None:
        raise UsageError(f"step '{step_name}' not found")

    field = _find_by_machine_name(step.get("fields", []), field_name)
    if field is None:
        raise UsageError(f"field '{field_name}' not found in step '{step_name}'")

    print_success(
        field,
        fmt=fmt,
        entity="field",
        full=full,
        next_hints=[f"integry templates {template_id} set-field-value {field_ref} --value <value>"],
    )


def set_field_value(
    template_id: int,
    field_ref: str,
    value: str,
    fmt: str,
    full: bool,
) -> None:
    step_name, field_name = _parse_field_ref(field_ref)
    parsed_value = _parse_value(value)

    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])
    step = _find_step_recursive(steps, step_name)
    if step is None:
        raise UsageError(f"step '{step_name}' not found")

    field = _find_by_machine_name(step.get("fields", []), field_name)
    if field is None:
        raise UsageError(f"field '{field_name}' not found in step '{step_name}'")

    field["default_value"] = parsed_value
    _patch_template(template_id, draft, steps)
    print_success(
        field,
        fmt=fmt,
        entity="field",
        full=full,
        next_hints=[f"integry templates {template_id} get-field {field_ref}"],
    )


def update_field(
    template_id: int,
    field_ref: str,
    input_path: str | None,
    fmt: str,
    full: bool,
) -> None:
    if not input_path:
        raise UsageError("--input is required")
    step_name, field_name = _parse_field_ref(field_ref)
    replacement = _read_json_input(input_path)

    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])
    step = _find_step_recursive(steps, step_name)
    if step is None:
        raise UsageError(f"step '{step_name}' not found")

    fields = step.get("fields", [])
    idx = _index_by_machine_name(fields, field_name)
    if idx is None:
        raise UsageError(f"field '{field_name}' not found in step '{step_name}'")

    fields[idx] = replacement
    _reweight_flat(fields)
    _patch_template(template_id, draft, steps)
    print_success(
        replacement,
        fmt=fmt,
        entity="field",
        full=full,
        next_hints=[f"integry templates {template_id} get-field {field_ref}"],
    )


def add_field(
    template_id: int,
    step_name: str,
    input_path: str | None,
    at_position: int | None,
    fmt: str,
    full: bool,
) -> None:
    if not input_path:
        raise UsageError("--input is required")
    new_field = _read_json_input(input_path)

    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])
    step = _find_step_recursive(steps, step_name)
    if step is None:
        raise UsageError(f"step '{step_name}' not found")

    fields = step.setdefault("fields", [])
    if at_position is not None:
        fields.insert(at_position, new_field)
    else:
        fields.append(new_field)

    _reweight_flat(fields)
    _patch_template(template_id, draft, steps)
    print_success(
        new_field,
        fmt=fmt,
        entity="field",
        full=full,
        next_hints=[f"integry templates {template_id} list-fields {step_name}"],
    )


def remove_field(
    template_id: int,
    field_ref: str,
    fmt: str,
    full: bool,
) -> None:
    step_name, field_name = _parse_field_ref(field_ref)

    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])
    step = _find_step_recursive(steps, step_name)
    if step is None:
        raise UsageError(f"step '{step_name}' not found")

    fields = step.get("fields", [])
    idx = _index_by_machine_name(fields, field_name)
    if idx is None:
        raise UsageError(f"field '{field_name}' not found in step '{step_name}'")

    fields.pop(idx)
    _reweight_flat(fields)
    _patch_template(template_id, draft, steps)
    print_success(
        {"removed": field_ref},
        fmt=fmt,
        full=True,
        next_hints=[f"integry templates {template_id} list-fields {step_name}"],
    )


def move_field(
    template_id: int,
    field_ref: str,
    to_position: int,
    fmt: str,
    full: bool,
) -> None:
    step_name, field_name = _parse_field_ref(field_ref)

    draft = _fetch_draft(template_id)
    steps = draft.get("steps", [])
    step = _find_step_recursive(steps, step_name)
    if step is None:
        raise UsageError(f"step '{step_name}' not found")

    fields = step.get("fields", [])
    idx = _index_by_machine_name(fields, field_name)
    if idx is None:
        raise UsageError(f"field '{field_name}' not found in step '{step_name}'")

    moved = fields.pop(idx)
    fields.insert(to_position, moved)
    _reweight_flat(fields)
    _patch_template(template_id, draft, steps)
    print_success(
        moved,
        fmt=fmt,
        entity="field",
        full=full,
        next_hints=[f"integry templates {template_id} list-fields {step_name}"],
    )


# ---------------------------------------------------------------------------
# Step diff (version vs draft)
# ---------------------------------------------------------------------------


def diff_step(
    template_id: int,
    step_name: str,
    version: int,
    fmt: str,
    full: bool = False,
) -> None:
    from integry_cli.commands.templates import (
        _sanitize_output_fields,
        _strip_redundant_keys,
    )

    config = load_config()
    client = ApiClient.from_config(config)
    try:
        version_response = client.get(
            GET_PATH_TMPL.format(pk=template_id),
            params={"version": version},
        )
        draft_response = client.get(
            GET_PATH_TMPL.format(pk=template_id),
        )
    finally:
        client.close()

    for resp in (version_response, draft_response):
        if isinstance(resp, dict):
            _sanitize_output_fields(resp)
            _strip_redundant_keys(resp)

    ver_step = _find_step_recursive(version_response.get("steps", []), step_name)
    draft_step = _find_step_recursive(draft_response.get("steps", []), step_name)

    if ver_step is None and draft_step is None:
        raise UsageError(f"step '{step_name}' not found in version {version} or draft")

    if ver_step is None:
        if fmt == "json":
            sys.stdout.write(json.dumps({"ok": True, "data": {"status": "added", "step": draft_step}}) + "\n")
        else:
            sys.stdout.write(f"+ {step_name} (added in draft)\n")
        return

    if draft_step is None:
        if fmt == "json":
            sys.stdout.write(json.dumps({"ok": True, "data": {"status": "removed", "step": ver_step}}) + "\n")
        else:
            sys.stdout.write(f"- {step_name} (removed in draft)\n")
        return

    # Both exist -- compare fields
    from integry_cli.output import _DIFF_SKIP_KEYS

    ver_fields = {f.get("machine_name") or str(f.get("activity_field_id", "?")): f for f in ver_step.get("fields", [])}
    draft_fields = {f.get("machine_name") or str(f.get("activity_field_id", "?")): f for f in draft_step.get("fields", [])}

    def _clean(field: dict) -> dict:
        return {k: v for k, v in field.items() if k not in _DIFF_SKIP_KEYS}

    added = sorted(set(draft_fields) - set(ver_fields))
    removed = sorted(set(ver_fields) - set(draft_fields))
    common = sorted(set(ver_fields) & set(draft_fields))
    changed = [k for k in common if _clean(ver_fields[k]) != _clean(draft_fields[k])]
    unchanged = [k for k in common if _clean(ver_fields[k]) == _clean(draft_fields[k])]

    if fmt == "json":
        data: dict[str, Any] = {
            "step": step_name,
            "added": [draft_fields[k] for k in added],
            "removed": [ver_fields[k] for k in removed],
            "changed": [
                {"field": k, "version": ver_fields[k], "draft": draft_fields[k]}
                for k in changed
            ],
            "unchanged_count": len(unchanged),
        }
        sys.stdout.write(json.dumps({"ok": True, "data": data}) + "\n")
        return

    if not added and not removed and not changed:
        sys.stdout.write(f"{step_name}: no field differences\n")
        return

    def _v(value: Any) -> str:
        return _short(value) if not full else _short(value, limit=0)

    def _write_value_diff(old_v: Any, new_v: Any, key: str, indent: str) -> None:
        """Write a diff for two values. Uses unified diff for multiline strings."""
        if (
            isinstance(old_v, str)
            and isinstance(new_v, str)
            and ("\n" in old_v or "\n" in new_v)
        ):
            sys.stdout.write(f"{indent}~ {key}:\n")
            diff_lines = difflib.unified_diff(
                old_v.splitlines(keepends=True),
                new_v.splitlines(keepends=True),
                fromfile=f"v{version}",
                tofile="draft",
                n=3,
            )
            for line in diff_lines:
                sys.stdout.write(f"{indent}    {line}")
                if not line.endswith("\n"):
                    sys.stdout.write("\n")
        else:
            sys.stdout.write(f"{indent}~ {key}: {_v(old_v)} -> {_v(new_v)}\n")

    sys.stdout.write(f"{step_name} (v{version} vs draft)\n")
    for k in added:
        sys.stdout.write(f"+ {k}\n")
    for k in removed:
        sys.stdout.write(f"- {k}\n")
    for k in changed:
        old_f = _clean(ver_fields[k])
        new_f = _clean(draft_fields[k])
        diff_keys = sorted(dk for dk in set(old_f) | set(new_f) if old_f.get(dk) != new_f.get(dk))
        sys.stdout.write(f"~ {k}\n")
        for dk in diff_keys:
            old_v = old_f.get(dk)
            new_v = new_f.get(dk)
            if old_v is None:
                sys.stdout.write(f"    + {dk}: {_v(new_v)}\n")
            elif new_v is None:
                sys.stdout.write(f"    - {dk}: {_v(old_v)}\n")
            elif isinstance(old_v, dict) and isinstance(new_v, dict):
                sub_changes = sorted(
                    sk for sk in set(old_v) | set(new_v)
                    if old_v.get(sk) != new_v.get(sk)
                )
                sys.stdout.write(f"    ~ {dk}:\n")
                for sk in sub_changes:
                    sv_old = old_v.get(sk)
                    sv_new = new_v.get(sk)
                    if sv_old is None:
                        sys.stdout.write(f"        + {sk}: {_v(sv_new)}\n")
                    elif sv_new is None:
                        sys.stdout.write(f"        - {sk}: {_v(sv_old)}\n")
                    else:
                        _write_value_diff(sv_old, sv_new, sk, "        ")
            else:
                _write_value_diff(old_v, new_v, dk, "    ")
    if unchanged:
        sys.stdout.write(f"  ({len(unchanged)} unchanged)\n")
    sys.stdout.write(f"next: integry templates {template_id} get-step {step_name}\n")


def _short(value: Any, limit: int = 80) -> str:
    """Compact repr of a value, truncated. limit=0 means no truncation."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        if limit == 0 or len(value) <= limit:
            return repr(value)
        return repr(value[:limit]) + "..."
    s = json.dumps(value, ensure_ascii=False)
    if limit == 0 or len(s) <= limit:
        return s
    return s[:limit] + "..."


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fetch_draft(template_id: int) -> dict:
    config = load_config()
    client = ApiClient.from_config(config)
    try:
        draft = client.get(
            GET_PATH_TMPL.format(pk=template_id),
            params={"return_as_draft": "true"},
        )
    finally:
        client.close()

    from integry_cli.commands.templates import _sanitize_output_fields, _strip_redundant_keys
    _sanitize_output_fields(draft)
    _strip_redundant_keys(draft)
    return draft


def _patch_template(template_id: int, draft: dict, steps: list) -> None:
    config = load_config()
    client = ApiClient.from_config(config)
    try:
        client.patch(
            UPDATE_PATH_TMPL.format(pk=template_id),
            json={"meta": draft["meta"], "steps": steps},
        )
    finally:
        client.close()


def _find_step_recursive(steps: list, machine_name: str) -> dict | None:
    for step in steps:
        if step.get("machine_name") == machine_name:
            return step
        found = _find_step_recursive(step.get("steps", []), machine_name)
        if found is not None:
            return found
    return None


def _find_step_in_parent(steps: list, machine_name: str) -> tuple[list, int | None]:
    for i, step in enumerate(steps):
        if step.get("machine_name") == machine_name:
            return steps, i
        result = _find_step_in_parent(step.get("steps", []), machine_name)
        if result[1] is not None:
            return result
    return steps, None


def _find_by_machine_name(items: list, machine_name: str) -> dict | None:
    for item in items:
        if item.get("machine_name") == machine_name:
            return item
    return None


def _index_by_machine_name(items: list, machine_name: str) -> int | None:
    for i, item in enumerate(items):
        if item.get("machine_name") == machine_name:
            return i
    return None


def _reweight(steps: list) -> None:
    for i, step in enumerate(steps):
        step["weight"] = i
        _reweight_flat(step.get("fields", []))
        _reweight(step.get("steps", []))


def _reweight_flat(items: list) -> None:
    for i, item in enumerate(items):
        item["weight"] = i


def _parse_field_ref(ref: str) -> tuple[str, str]:
    if ":" not in ref:
        raise UsageError(f"field reference must be step_name:field_name, got '{ref}'")
    step_name, field_name = ref.split(":", 1)
    if not step_name or not field_name:
        raise UsageError(f"field reference must be step_name:field_name, got '{ref}'")
    return step_name, field_name


def _parse_value(raw: str) -> Any:
    if raw == "-":
        raw = sys.stdin.read()
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return raw


def _read_json_input(path_arg: str) -> Any:
    if path_arg == "-":
        raw = sys.stdin.read()
    else:
        path = Path(path_arg)
        if not path.is_file():
            raise UsageError(f"input file not found: {path_arg}")
        raw = path.read_text()
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        raise UsageError(f"invalid JSON in {path_arg}: {e.msg} (line {e.lineno})")


def _print_empty(message: str, template_id: int, fmt: str, step_name: str | None = None) -> None:
    if fmt == "json":
        import json as _json
        sys.stdout.write(_json.dumps({"ok": True, "data": {"total": 0}}) + "\n")
        return
    sys.stdout.write(f"{message}\n")
    if step_name:
        sys.stdout.write(f"next: integry templates {template_id} add-field {step_name} --input <field.json>\n")
    else:
        sys.stdout.write(f"next: integry templates {template_id} add-step --input <step.json>\n")
