from __future__ import annotations

import json
import sys
from typing import Any, Iterable

from integry_cli.errors import CLIError

TRUNCATE_AT = 400

DEFAULT_FIELDS: dict[str, tuple[str, ...]] = {
    "template": (
        "id",
        "name",
        "type",
        "machine_name",
        "app_id",
        "publishing_status",
        "revision_number",
        "live_or_latest_version",
        "is_draft_empty",
    ),
    "template_summary": (
        "id",
        "name",
        "type",
        "machine_name",
        "publishing_status",
        "revision_number",
        "live_or_latest_version",
    ),
    "template_version": (
        "id",
        "version",
        "publishing_status",
        "is_live",
        "integration_count",
        "changelog",
    ),
    "step": (
        "machine_name",
        "title",
        "type",
        "weight",
        "is_hidden",
    ),
    "field": (
        "machine_name",
        "label",
        "type",
        "is_required",
        "is_hidden",
        "weight",
        "default_value",
    ),
}


def print_success(
    payload: Any,
    *,
    fmt: str,
    entity: str | None = None,
    full: bool = False,
    next_hints: Iterable[str] = (),
) -> None:
    """Render a successful API payload + optional next-step hints.

    - In `toon` mode: emit TOON and append `next:` lines.
    - In `json` mode: wrap in an envelope {"ok": true, "data": ..., "next": [...]}
      so programmatic consumers get a single structured object.
    """
    shaped = _shape(payload, entity=entity, full=full)

    if fmt == "json":
        envelope: dict[str, Any] = {"ok": True, "data": shaped}
        if next_hints:
            envelope["next"] = list(next_hints)
        sys.stdout.write(json.dumps(envelope) + "\n")
        return

    sys.stdout.write(to_toon(shaped) + "\n")
    for hint in next_hints:
        sys.stdout.write(f"next: {hint}\n")


def print_error(err: CLIError, *, fmt: str) -> None:
    if fmt == "json":
        envelope: dict[str, Any] = {
            "ok": False,
            "error": {"code": err.code, "message": err.message},
        }
        if err.detail is not None:
            envelope["error"]["detail"] = err.detail
        status = getattr(err, "status", None)
        if status is not None:
            envelope["error"]["status"] = status
        sys.stdout.write(json.dumps(envelope) + "\n")
        return

    sys.stdout.write(f"error: {err.code}: {err.message}\n")
    if err.detail is not None:
        rendered = to_toon(err.detail) if isinstance(err.detail, (dict, list)) else str(err.detail)
        for line in rendered.splitlines():
            sys.stdout.write(f"  {line}\n")


def to_toon(value: Any, indent: int = 0) -> str:
    """Minimal TOON (Token-Optimized Object Notation) serializer.

    Scalars → `value`
    Dicts   → `key: value` per line, nested dicts/lists indented.
    Lists of homogeneous dicts → header row + CSV-style rows.
    Other lists → `- item` per line.
    """
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        return _scalar_str(value)
    if isinstance(value, dict):
        return _dict_to_toon(value, indent)
    if isinstance(value, list):
        return _list_to_toon(value, indent)
    return _scalar_str(str(value))


def truncate(text: str, limit: int = TRUNCATE_AT) -> str:
    if len(text) <= limit:
        return text
    return f"{text[:limit]}… (truncated, {len(text)} chars total — use --full to see complete body)"


def _shape(payload: Any, *, entity: str | None, full: bool) -> Any:
    if full or entity is None:
        return _truncate_deep(payload, full)
    fields = DEFAULT_FIELDS.get(entity)
    if not fields or not isinstance(payload, dict):
        return _truncate_deep(payload, full)

    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    combined = {**meta, **{k: v for k, v in payload.items() if k != "meta"}}
    shaped = {k: combined[k] for k in fields if k in combined}
    return _truncate_deep(shaped, full)


def _truncate_deep(value: Any, full: bool) -> Any:
    if full:
        return value
    if isinstance(value, str):
        return truncate(value)
    if isinstance(value, dict):
        return {k: _truncate_deep(v, full) for k, v in value.items()}
    if isinstance(value, list):
        return [_truncate_deep(v, full) for v in value]
    return value


def _dict_to_toon(value: dict, indent: int) -> str:
    if not value:
        return "{}"
    pad = "  " * indent
    lines: list[str] = []
    for k, v in value.items():
        key = _scalar_str(str(k)) if _needs_quotes(str(k)) else str(k)
        if isinstance(v, (dict, list)) and v:
            lines.append(f"{pad}{key}:")
            lines.append(to_toon(v, indent + 1))
        else:
            lines.append(f"{pad}{key}: {to_toon(v, indent + 1)}")
    return "\n".join(lines)


def _list_to_toon(value: list, indent: int) -> str:
    if not value:
        return "[]"
    pad = "  " * indent

    if _is_homogeneous_dict_list(value):
        headers = list(value[0].keys())
        header_line = f"{pad}[{len(value)}] {','.join(headers)}:"
        body = [
            pad + "  " + ",".join(_csv_cell(row.get(h)) for h in headers)
            for row in value
        ]
        return "\n".join([header_line, *body])

    lines = []
    for item in value:
        rendered = to_toon(item, indent + 1)
        if "\n" in rendered:
            lines.append(f"{pad}-")
            lines.append(rendered)
        else:
            lines.append(f"{pad}- {rendered}")
    return "\n".join(lines)


def _is_homogeneous_dict_list(value: list) -> bool:
    if not value or not all(isinstance(x, dict) for x in value):
        return False
    first_keys = tuple(value[0].keys())
    if not first_keys:
        return False
    for item in value:
        if tuple(item.keys()) != first_keys:
            return False
        for v in item.values():
            if isinstance(v, (dict, list)):
                return False
    return True


def _csv_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    if any(c in text for c in (",", '"', "\n")):
        return '"' + text.replace('"', '""') + '"'
    return text


def _scalar_str(value: str) -> str:
    if _needs_quotes(value):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    return value


def _needs_quotes(value: str) -> bool:
    if value == "":
        return True
    if value[0].isspace() or value[-1].isspace():
        return True
    return any(c in value for c in (":", ",", "\n", '"', "#"))


# ---------------------------------------------------------------------------
# Step tree rendering
# ---------------------------------------------------------------------------


def render_step_tree(steps: list[dict], indent: int = 0) -> str:
    """Render steps as an indented tree: ``machine_name (TYPE) "title"``."""
    lines: list[str] = []
    pad = "    " * indent
    for step in steps:
        lines.append(pad + _step_label(step))
        children = step.get("steps", [])
        if children:
            lines.append(render_step_tree(children, indent + 1))
    return "\n".join(lines)


def render_template_header(template: dict) -> str:
    """One-line summary: ``id machine_name (TYPE) vN STATUS``."""
    meta = template.get("meta", {})
    tid = template.get("id") or meta.get("id") or ""
    name = template.get("machine_name") or meta.get("machine_name") or meta.get("name") or template.get("name") or ""
    ttype = template.get("type") or meta.get("type", "")
    version = template.get("live_or_latest_version") or meta.get("live_or_latest_version") or ""
    status = template.get("publishing_status") or meta.get("publishing_status", "")
    parts = [str(tid), name, f"({ttype})"]
    if version:
        parts.append(f"v{version}")
    if status:
        parts.append(status)
    return " ".join(p for p in parts if p)


def render_diff_tree(
    version_steps: list[dict],
    draft_steps: list[dict],
    version_meta: dict | None = None,
    draft_meta: dict | None = None,
    indent: int = 0,
) -> list[str]:
    """Compare two step lists and return diff-annotated tree lines.

    Markers: ``+`` added, ``-`` removed, ``~`` modified, space = unchanged.
    """
    lines: list[str] = []
    pad = "    " * indent

    # Meta diff
    if indent == 0 and version_meta is not None and draft_meta is not None:
        changed_keys = [
            k for k in set(version_meta) | set(draft_meta)
            if version_meta.get(k) != draft_meta.get(k)
        ]
        if changed_keys:
            changed_keys.sort()
            lines.append(f"~ meta: {', '.join(changed_keys)} changed")

    def _step_key(s: dict) -> str:
        return s.get("machine_name") or s.get("title") or str(s.get("activity_id", "?"))

    ver_by_name = {_step_key(s): s for s in version_steps}

    # Walk draft order for present/added steps
    seen: set[str] = set()
    for step in draft_steps:
        key = _step_key(step)
        seen.add(key)
        old = ver_by_name.get(key)
        if old is None:
            lines.append(f"+ {pad}{_step_label(step)}")
        else:
            diff_detail = _step_diff_detail(old, step)
            if diff_detail:
                lines.append(f"~ {pad}{_step_label(step)}  {diff_detail}")
            else:
                lines.append(f"  {pad}{_step_label(step)}")
            # Recurse into children
            old_children = old.get("steps", [])
            new_children = step.get("steps", [])
            if old_children or new_children:
                lines.extend(render_diff_tree(old_children, new_children, indent=indent + 1))
            continue
        # Added step - show children without diff markers
        children = step.get("steps", [])
        if children:
            for child_line in render_step_tree(children, indent + 1).splitlines():
                lines.append(f"+ {child_line}")

    # Removed steps (in version but not in draft)
    for step in version_steps:
        key = _step_key(step)
        if key not in seen:
            lines.append(f"- {pad}{_step_label(step)}")
            children = step.get("steps", [])
            if children:
                for child_line in render_step_tree(children, indent + 1).splitlines():
                    lines.append(f"- {child_line}")

    return lines


def _step_label(step: dict) -> str:
    name = step.get("machine_name", "?")
    stype = step.get("type") or step.get("step_type") or ""
    title = step.get("title", "")
    parts = [name]
    if stype:
        parts[0] = f"{name} ({stype})"
    if title and title != name:
        parts.append(f'"{title}"')
    return " ".join(parts)


_DIFF_SKIP_KEYS = frozenset({
    "steps", "fields", "weight", "id", "parent_id", "intra_version_guid",
    "version_template_id", "version_of", "version_number",
    "last_modified", "last_modified_by", "created",
    "publishing_status", "revision_number",
})


def _step_diff_detail(old: dict, new: dict) -> str:
    """Return a bracketed hint like ``[2 fields changed]`` or empty string."""
    hints: list[str] = []

    # Compare step-level keys (excluding nested steps, fields, and IDs)
    step_changes = sum(
        1 for k in set(old) | set(new)
        if k not in _DIFF_SKIP_KEYS and old.get(k) != new.get(k)
    )
    if step_changes:
        hints.append(f"{step_changes} {'prop' if step_changes == 1 else 'props'} changed")

    # Compare fields (strip ID keys before comparing)
    def _field_key(f: dict) -> str:
        return f.get("machine_name") or str(f.get("activity_field_id", "?"))

    def _strip_field_ids(f: dict) -> dict:
        return {k: v for k, v in f.items() if k not in _DIFF_SKIP_KEYS}

    old_fields = {_field_key(f): f for f in old.get("fields", [])}
    new_fields = {_field_key(f): f for f in new.get("fields", [])}
    added = len(set(new_fields) - set(old_fields))
    removed = len(set(old_fields) - set(new_fields))
    modified = sum(
        1 for k in set(old_fields) & set(new_fields)
        if _strip_field_ids(old_fields[k]) != _strip_field_ids(new_fields[k])
    )
    field_parts = []
    if added:
        field_parts.append(f"{added} added")
    if removed:
        field_parts.append(f"{removed} removed")
    if modified:
        field_parts.append(f"{modified} changed")
    if field_parts:
        hints.append(f"fields: {', '.join(field_parts)}")

    if not hints:
        return ""
    return f"[{'; '.join(hints)}]"
