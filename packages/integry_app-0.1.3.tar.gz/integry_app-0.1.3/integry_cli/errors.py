from __future__ import annotations

from typing import Any

EXIT_OK = 0
EXIT_API_ERROR = 1
EXIT_AUTH_ERROR = 2
EXIT_USAGE_ERROR = 3


class CLIError(Exception):
    exit_code: int = EXIT_USAGE_ERROR
    code: str = "usage_error"

    def __init__(self, message: str, detail: Any = None):
        super().__init__(message)
        self.message = message
        self.detail = detail


class UsageError(CLIError):
    exit_code = EXIT_USAGE_ERROR
    code = "usage_error"


class AuthError(CLIError):
    exit_code = EXIT_AUTH_ERROR
    code = "auth_error"


class ApiError(CLIError):
    exit_code = EXIT_API_ERROR
    code = "api_error"

    def __init__(self, message: str, status: int, detail: Any = None):
        super().__init__(message, detail)
        self.status = status
