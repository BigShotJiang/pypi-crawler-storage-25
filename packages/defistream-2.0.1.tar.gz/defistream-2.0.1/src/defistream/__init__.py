"""
DeFiStream Python Client

Official Python client for the DeFiStream API.

Example:
    >>> from defistream import DeFiStream
    >>> client = DeFiStream(api_key="dsk_...")
    >>>
    >>> # EVM protocols
    >>> df = (
    ...     client.evm.erc20.transfers("USDT")
    ...     .network("ETH")
    ...     .block_range(21000000, 21010000)
    ...     .as_df()
    ... )
    >>>
    >>> # Tron
    >>> df = client.tron.trc20.transfers("USDT").as_df()
    >>>
    >>> # Bitcoin
    >>> df = client.bitcoin.native.transfers().as_df()
    >>>
    >>> # Exchange data
    >>> df = client.exchange.binance.ohlcv().token("BTC").as_df()
    >>> df = client.exchange.hyperliquid.fills().tokens("ETH").as_df()
"""

from .client import (
    AsyncBitcoinChain,
    AsyncDeFiStream,
    AsyncEVMChain,
    AsyncExchangeNamespace,
    AsyncTronChain,
    BitcoinChain,
    DeFiStream,
    EVMChain,
    ExchangeNamespace,
    TronChain,
)
from .exceptions import (
    AuthenticationError,
    DeFiStreamError,
    NotFoundError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .models import CostEstimate, LinkInfo
from .protocols import (
    AsyncBinanceProtocol,
    AsyncHyperliquidProtocol,
    BinanceProtocol,
    HyperliquidProtocol,
)
from .query import (
    AggregateQueryBuilder,
    AsyncAggregateQueryBuilder,
    AsyncExchangeDataQueryBuilder,
    AsyncHLQueryBuilder,
    AsyncOHLCVQueryBuilder,
    AsyncQueryBuilder,
    AsyncTradeQueryBuilder,
    ExchangeDataQueryBuilder,
    HLQueryBuilder,
    OHLCVQueryBuilder,
    QueryBuilder,
    TradeQueryBuilder,
)

__version__ = "2.0.1"

__all__ = [
    # Clients
    "DeFiStream",
    "AsyncDeFiStream",
    # Chain namespaces
    "EVMChain",
    "TronChain",
    "BitcoinChain",
    "ExchangeNamespace",
    "AsyncEVMChain",
    "AsyncTronChain",
    "AsyncBitcoinChain",
    "AsyncExchangeNamespace",
    # Query builders
    "QueryBuilder",
    "AsyncQueryBuilder",
    "AggregateQueryBuilder",
    "AsyncAggregateQueryBuilder",
    "TradeQueryBuilder",
    "AsyncTradeQueryBuilder",
    "OHLCVQueryBuilder",
    "AsyncOHLCVQueryBuilder",
    "ExchangeDataQueryBuilder",
    "AsyncExchangeDataQueryBuilder",
    "HLQueryBuilder",
    "AsyncHLQueryBuilder",
    # Protocol classes
    "BinanceProtocol",
    "AsyncBinanceProtocol",
    "HyperliquidProtocol",
    "AsyncHyperliquidProtocol",
    # Models
    "CostEstimate",
    "LinkInfo",
    # Exceptions
    "DeFiStreamError",
    "AuthenticationError",
    "QuotaExceededError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
]
