# tsk-cli

Command-line interface for [TSK](https://tsk.tools) — pull projects and things into your editor so AI agents can work with them.

## Install

```bash
pipx install tsk-cli
# or
pip install tsk-cli
```

Requires Python 3.11+.

## Quick start

```bash
tsk login              # authenticate via browser
tsk orgs               # list your organizations
tsk org <name>         # set the default org
tsk pull               # sync projects and things to .task/
```

## Commands

| Command | Description |
|---------|-------------|
| `tsk login [--server URL]` | Authenticate via browser OAuth |
| `tsk logout` | Clear stored credentials |
| `tsk orgs` | List your organizations |
| `tsk org <name-or-id>` | Set the default organization |
| `tsk pull` | Sync projects/things to `.task/` |
| `tsk push [--force]` | Upload local edits to the server |
| `tsk status` | Show current config and auth state |
| `tsk list [--status S] [--project P]` | List things with optional filters |
| `tsk show <ref>` | Display a thing's details |
| `tsk set-status <ref> <status>` | Update status and push immediately |
| `tsk start <ref>` | Set status to `in_progress` |
| `tsk done <ref>` | Set status to `done` |
| `tsk review <ref>` | Set status to `in_review` |
| `tsk open <ref>` | Open thing in browser |

## How it works

`tsk pull` writes a `.task/` directory containing your projects and things as markdown files. Editor agents (Cursor, Copilot, etc.) can read these files to understand what to work on. After making changes locally, `tsk push` syncs them back to the server.

## License

MIT
