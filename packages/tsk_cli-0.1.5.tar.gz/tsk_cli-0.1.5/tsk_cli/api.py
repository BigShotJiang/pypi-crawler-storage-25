"""
HTTP client that uses stored session cookies to talk to the TSK backend.
"""

from __future__ import annotations

import sys
from urllib.parse import urlparse

import click
import requests

from .config import get_auth, get_server_url, save_auth


def create_session() -> requests.Session:
    """Build a requests.Session pre-loaded with stored auth cookies."""
    auth = get_auth()
    s = requests.Session()
    sessionid = auth.get("sessionid", "")
    csrftoken = auth.get("csrftoken", "")
    if sessionid:
        s.cookies.set("sessionid", sessionid)
    if csrftoken:
        s.cookies.set("csrftoken", csrftoken)
        s.headers["X-CSRFToken"] = csrftoken

    # Django's CSRF middleware requires Origin (or Referer on HTTPS) for unsafe
    # methods. Browsers send these automatically; urllib3/requests does not.
    base = get_server_url().rstrip("/")
    parsed = urlparse(base)
    if parsed.scheme in ("http", "https") and parsed.netloc:
        origin = f"{parsed.scheme}://{parsed.netloc}"
        s.headers.setdefault("Origin", origin)
        s.headers.setdefault("Referer", f"{origin}/")

    return s


def _persist_csrf_from_response(resp: requests.Response) -> None:
    """If the server rotated csrftoken, keep ~/.config/tsk/auth.json in sync."""
    new = resp.cookies.get("csrftoken")
    if not new:
        return
    auth = get_auth()
    sid = auth.get("sessionid", "")
    if not sid:
        return
    save_auth(sessionid=sid, csrftoken=new)


def require_auth() -> tuple[requests.Session, str]:
    """
    Return (session, server_url) or exit with an error message
    if not configured / not authenticated.
    """
    server_url = get_server_url()
    auth = get_auth()
    if not auth.get("sessionid"):
        click.echo("Not logged in. Run: tsk login", err=True)
        sys.exit(1)

    session = create_session()
    server_url = server_url.rstrip("/")
    return session, server_url


def _check_auth_response(resp: requests.Response) -> None:
    """Exit with a helpful message on 401/403."""
    if resp.status_code == 401:
        click.echo("Session expired. Run: tsk login", err=True)
        sys.exit(1)
    if resp.status_code == 403:
        detail = ""
        try:
            detail = resp.json().get("detail", "")
        except Exception:
            pass
        if "CSRF" in detail:
            click.echo("CSRF check failed. Run: tsk login", err=True)
        else:
            click.echo(
                f"Permission denied ({detail or 'no details'}). "
                "You may need a higher org role, or run: tsk login",
                err=True,
            )
        sys.exit(1)


def api_get(path: str) -> dict | list:
    """GET an API endpoint. Exits on auth failure."""
    session, server_url = require_auth()
    resp = session.get(f"{server_url}{path}")
    _check_auth_response(resp)
    resp.raise_for_status()
    _persist_csrf_from_response(resp)
    return resp.json()


def api_post(path: str, json_data: dict) -> dict:
    """POST to an API endpoint. Exits on auth failure."""
    session, server_url = require_auth()
    resp = session.post(f"{server_url}{path}", json=json_data)
    _check_auth_response(resp)
    resp.raise_for_status()
    _persist_csrf_from_response(resp)
    return resp.json()


def api_patch(path: str, json_data: dict) -> dict:
    """PATCH an API endpoint. Exits on auth failure."""
    session, server_url = require_auth()
    resp = session.patch(f"{server_url}{path}", json=json_data)
    _check_auth_response(resp)
    resp.raise_for_status()
    _persist_csrf_from_response(resp)
    return resp.json()
