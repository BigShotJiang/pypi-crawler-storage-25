"""
Shared utilities for resolving thing refs to local .task/ files.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from .push import ParsedThingFile, parse_thing_markdown


def task_root(target_dir: Path | None = None) -> Path:
    return (target_dir or Path.cwd()) / ".task"


def find_thing_file(ref: str, target_dir: Path | None = None) -> Optional[Path]:
    """Find the .md file for a thing ref like COM-001."""
    root = task_root(target_dir)
    projects_dir = root / "projects"
    if not projects_dir.is_dir():
        return None

    ref_upper = ref.upper()
    for md in sorted(projects_dir.glob("**/things/*.md")):
        if md.stem.upper() == ref_upper:
            return md
    return None


def parse_thing_at(path: Path) -> ParsedThingFile:
    return parse_thing_markdown(path.read_text())


def snapshot_path_for(thing_path: Path, target_dir: Path | None = None) -> Path:
    """Return the .snapshot/ counterpart of a thing file."""
    root = task_root(target_dir)
    projects_dir = root / "projects"
    rel = thing_path.relative_to(projects_dir)
    return root / ".snapshot" / "projects" / rel
