"""
Browser-based OAuth login flow for the CLI.

1. Start a tiny HTTP server on a random localhost port.
2. Open the browser to the app's login page with ?cli_callback=http://localhost:<port>/callback
3. After the user signs in, the frontend redirects to our callback with a one-time auth code.
4. We exchange the code for session credentials via the backend's code-exchange endpoint.
"""

from __future__ import annotations

import http.server
import threading
import urllib.parse
import webbrowser
from typing import Optional

import click
import requests

from .config import get_server_url, save_auth


class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    """Handles the redirect from the frontend after successful OAuth."""

    auth_code: Optional[str] = None

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        code = params.get("code", [None])[0]

        if code:
            _CallbackHandler.auth_code = code
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"<html><body><h2>Authenticated!</h2>"
                b"<p>You can close this tab and return to the terminal.</p>"
                b"</body></html>"
            )
        else:
            self.send_response(400)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body><p>Missing credentials.</p></body></html>")

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002
        pass


def login_flow() -> bool:
    """Run the interactive browser login. Returns True on success."""
    server_url = get_server_url().rstrip("/")

    server = http.server.HTTPServer(("127.0.0.1", 0), _CallbackHandler)
    port = server.server_address[1]
    callback_url = f"http://localhost:{port}/callback"

    login_url = f"{server_url}/login?cli_callback={urllib.parse.quote(callback_url)}"

    click.echo(f"Opening browser to sign in...")
    click.echo(f"  {login_url}")
    click.echo()
    click.echo("Waiting for authentication...")

    webbrowser.open(login_url)

    _CallbackHandler.auth_code = None

    server.timeout = 120
    while _CallbackHandler.auth_code is None:
        server.handle_request()
        if _CallbackHandler.auth_code is None:
            break

    server.server_close()

    if _CallbackHandler.auth_code:
        ok = _exchange_code(server_url, _CallbackHandler.auth_code)
        if ok:
            ok2, who = _verify_session(server_url)
            if ok2:
                click.echo(f"Logged in as {who}")
                return True
            else:
                click.echo("Session could not be verified. Try again.")
                return False
        else:
            click.echo("Code exchange failed. Try again.")
            return False

    click.echo("Login timed out or was cancelled.")
    return False


def _exchange_code(server_url: str, code: str) -> bool:
    """Exchange the one-time auth code for session credentials."""
    try:
        resp = requests.post(
            f"{server_url}/api/auth/cli-code-exchange/",
            json={"code": code},
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json()
            sid = data.get("sessionid", "")
            csrf = data.get("csrftoken", "")
            if sid:
                save_auth(sessionid=sid, csrftoken=csrf)
                return True
    except requests.RequestException:
        pass
    return False


def _verify_session(server_url: str) -> tuple[bool, str]:
    """Hit /api/auth/me/ to confirm the stored session is valid."""
    from .api import create_session

    session = create_session()
    try:
        resp = session.get(f"{server_url}/api/auth/me/")
        if resp.status_code == 200:
            data = resp.json()
            name = data.get("display_name") or data.get("email", "unknown")
            return True, name
    except requests.RequestException:
        pass
    return False, ""
