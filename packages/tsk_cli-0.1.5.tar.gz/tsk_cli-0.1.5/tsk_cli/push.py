"""
tsk push -- upload local .task/ thing edits to the server.

Compares each thing file to .task/.snapshot/ (baseline from last pull).
Uses optimistic concurrency: server updated_at must match snapshot unless --force.
"""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import click
import requests

from .api import api_get, api_patch


@dataclass
class ParsedThingFile:
    frontmatter: dict[str, str]
    name: str
    body: str  # markdown body below the # title line
    raw: str


def parse_thing_markdown(text: str) -> ParsedThingFile:
    """Parse a thing .md file: YAML frontmatter, # title, body."""
    text = text.replace("\r\n", "\n")
    if not text.startswith("---\n"):
        raise ValueError("Expected YAML frontmatter starting with ---")
    end = text.find("\n---\n", 4)
    if end == -1:
        raise ValueError("Expected closing --- for frontmatter")

    fm_block = text[4:end]
    rest = text[end + 5 :]

    frontmatter: dict[str, str] = {}
    for line in fm_block.split("\n"):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" in line:
            k, v = line.split(":", 1)
            frontmatter[k.strip()] = v.strip()

    lines = rest.split("\n")
    name = "Untitled"
    body_start = 0
    if lines and lines[0].startswith("# "):
        name = lines[0][2:].strip()
        body_start = 1
    elif lines and lines[0].startswith("#"):
        name = lines[0].lstrip("#").strip()
        body_start = 1

    body_lines = lines[body_start:]
    while body_lines and not body_lines[0].strip():
        body_lines.pop(0)
    body = "\n".join(body_lines).rstrip("\n")

    return ParsedThingFile(
        frontmatter=frontmatter, name=name, body=body, raw=text
    )


def build_thing_markdown(frontmatter: dict[str, str], name: str, body: str) -> str:
    """Rebuild .md content; frontmatter key order matches pull output."""
    order = [
        "id",
        "ref",
        "project",
        "status",
        "assigned_to",
        "created_at",
        "updated_at",
    ]
    lines = ["---"]
    for key in order:
        if key in frontmatter:
            lines.append(f"{key}: {frontmatter[key]}")
    for k, v in sorted(frontmatter.items()):
        if k not in order:
            lines.append(f"{k}: {v}")
    lines.append("---")
    text = "\n".join(lines) + "\n"
    text += f"# {name}\n\n"
    if body:
        text += body + "\n"
    return text


def markdown_body_to_html(body: str) -> str:
    """Convert plain / markdown-ish body to HTML the backend can migrate to ProseMirror."""
    body = body.replace("\r\n", "\n").strip()
    if not body:
        return ""

    parts: list[str] = []
    for para in body.split("\n\n"):
        para = para.strip()
        if not para:
            continue
        inner = html.escape(para).replace("\n", "<br/>")
        parts.append(f"<p>{inner}</p>")
    return "".join(parts)


def _semantic_tuple(p: ParsedThingFile) -> tuple[str, str, str]:
    return (p.name, p.frontmatter.get("status", ""), p.body)


def push(*, force: bool = False, target_dir: Path | None = None) -> None:
    root = (target_dir or Path.cwd()) / ".task"
    projects_dir = root / "projects"
    snapshot_root = root / ".snapshot" / "projects"

    if not projects_dir.is_dir():
        click.echo("No .task/projects directory. Run: tsk pull", err=True)
        raise SystemExit(1)

    if not snapshot_root.is_dir():
        click.echo(
            "No .task/.snapshot baseline. Run: tsk pull (to refresh snapshots for push)",
            err=True,
        )
        raise SystemExit(1)

    unchanged = 0
    pushed = 0
    conflicts = 0
    errors = 0

    for local_path in sorted(projects_dir.glob("**/things/*.md")):
        rel = local_path.relative_to(projects_dir)
        snap_path = snapshot_root / rel

        if not snap_path.is_file():
            click.echo(
                f"  skip {rel}: no snapshot (run tsk pull)", err=True
            )
            errors += 1
            continue

        try:
            local_raw = local_path.read_text()
            snap_raw = snap_path.read_text()
        except OSError as e:
            click.echo(f"  skip {rel}: read error: {e}", err=True)
            errors += 1
            continue

        if local_raw == snap_raw:
            unchanged += 1
            continue

        try:
            local_p = parse_thing_markdown(local_raw)
            snap_p = parse_thing_markdown(snap_raw)
        except ValueError as e:
            click.echo(f"  skip {rel}: parse error: {e}", err=True)
            errors += 1
            continue

        thing_id = local_p.frontmatter.get("id", "")
        if not thing_id:
            click.echo(f"  skip {rel}: missing id in frontmatter", err=True)
            errors += 1
            continue

        if _semantic_tuple(local_p) == _semantic_tuple(snap_p):
            unchanged += 1
            continue

        ref = local_p.frontmatter.get("ref", rel.stem)

        if not force:
            try:
                server_thing = api_get(f"/api/things/{thing_id}/")
            except Exception as e:
                click.echo(f"  {ref}: could not fetch server state: {e}", err=True)
                errors += 1
                continue

            if not isinstance(server_thing, dict):
                click.echo(f"  {ref}: unexpected API response", err=True)
                errors += 1
                continue

            snap_updated = snap_p.frontmatter.get("updated_at", "")
            srv_updated = str(server_thing.get("updated_at", ""))
            if srv_updated != snap_updated:
                click.echo(
                    f"  conflict {ref}: server was modified since last pull "
                    f"(run tsk pull, then re-apply edits). Use --force to overwrite.",
                    err=True,
                )
                conflicts += 1
                continue

        payload: dict[str, Any] = {}
        if local_p.name != snap_p.name:
            payload["name"] = local_p.name
        if local_p.frontmatter.get("status") != snap_p.frontmatter.get("status"):
            payload["status"] = local_p.frontmatter.get("status", "not_started")
        if local_p.body != snap_p.body:
            payload["body"] = markdown_body_to_html(local_p.body)

        if not payload:
            unchanged += 1
            continue

        try:
            updated = api_patch(f"/api/things/{thing_id}/", payload)
        except requests.HTTPError as e:
            click.echo(f"  {ref}: PATCH failed: {e}", err=True)
            if e.response is not None and e.response.text:
                click.echo(f"    {e.response.text[:500]}", err=True)
            errors += 1
            continue
        except Exception as e:
            click.echo(f"  {ref}: PATCH failed: {e}", err=True)
            errors += 1
            continue

        if not isinstance(updated, dict) or not updated.get("updated_at"):
            updated = api_get(f"/api/things/{thing_id}/")

        if isinstance(updated, dict) and updated.get("updated_at"):
            local_p.frontmatter["updated_at"] = str(updated["updated_at"])
            new_raw = build_thing_markdown(
                local_p.frontmatter, local_p.name, local_p.body
            )
            local_path.write_text(new_raw)
            snap_path.write_text(new_raw)

        pushed += 1
        click.echo(f"  pushed {ref}")

    click.echo(
        f"Done: {pushed} pushed, {unchanged} unchanged, "
        f"{conflicts} conflict(s), {errors} error(s)"
    )
