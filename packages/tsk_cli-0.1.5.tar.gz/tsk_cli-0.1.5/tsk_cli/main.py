"""
tsk -- CLI for TSK task management.

Commands:
  tsk login [--server URL]     Authenticate via browser
  tsk logout                   Clear stored credentials
  tsk orgs                     List your organizations
  tsk org <name-or-id>         Set the default organization
  tsk pull                     Sync projects/things to .task/
  tsk push [--force]           Upload local thing edits to the server
  tsk status                   Show current config and auth state
  tsk list [--status] [--project]  List things with optional filters
  tsk show <ref>               Display a thing's details
  tsk set-status <ref> <status>  Update status and push immediately
  tsk start <ref>              Set status to in_progress
  tsk done <ref>               Set status to done
  tsk review <ref>             Set status to in_review
  tsk open <ref>               Open thing in browser
"""

from __future__ import annotations

import click

from . import config as cfg


@click.group()
@click.version_option(package_name="tsk-cli")
def cli() -> None:
    """TSK -- pull projects and things for editor agents."""


@cli.command()
@click.option("--server", default=None, help="Server URL (default: https://tsk.tools)")
def login(server: str | None) -> None:
    """Authenticate with the TSK server via browser OAuth."""
    if server:
        cfg.set_config(server_url=server.rstrip("/"))
        click.echo(f"Server set to: {server}")

    from .auth import login_flow

    login_flow()


@cli.command()
def logout() -> None:
    """Clear stored credentials."""
    cfg.clear_auth()
    click.echo("Logged out.")


@cli.command()
def orgs() -> None:
    """List organizations you belong to."""
    from .api import api_get

    data = api_get("/api/organizations/")
    if not data:
        click.echo("No organizations found.")
        return

    current = cfg.get_default_org()
    current_id = current["id"] if current else None

    for org in data:
        marker = " *" if org["id"] == current_id else ""
        click.echo(f"  {org['name']} ({org['id']}){marker}")

    if not current_id:
        click.echo()
        click.echo("Set a default org with: tsk org <name-or-id>")


@cli.command()
@click.argument("name_or_id")
def org(name_or_id: str) -> None:
    """Set the default organization by name or ID."""
    from .api import api_get

    data = api_get("/api/organizations/")
    match = None
    needle = name_or_id.lower()
    for o in data:
        if o["id"] == name_or_id or o["name"].lower() == needle:
            match = o
            break

    if not match:
        click.echo(f"Organization not found: {name_or_id}", err=True)
        raise SystemExit(1)

    cfg.set_config(org={"id": match["id"], "name": match["name"]})
    click.echo(f"Default org set to: {match['name']}")


@cli.command()
def pull() -> None:
    """Fetch projects and things, write to .task/ directory."""
    from .pull import pull as do_pull

    do_pull()


@cli.command()
@click.option(
    "--force",
    is_flag=True,
    help="Skip server updated_at check (may overwrite others' edits).",
)
def push(force: bool) -> None:
    """Upload local changes under .task/ to the server (things only)."""
    from .push import push as do_push

    do_push(force=force)


@cli.command()
def status() -> None:
    """Show current configuration and auth state."""
    conf = cfg.get_config()
    auth = cfg.get_auth()

    server = conf.get("server_url") or cfg.get_server_url()
    click.echo(f"Server:  {server}")

    org_info = conf.get("org")
    if org_info:
        click.echo(f"Org:     {org_info['name']} ({org_info['id']})")
    else:
        click.echo("Org:     (not set)")

    if auth.get("sessionid"):
        click.echo("Auth:    logged in")
        # Verify the session is still valid
        if conf.get("server_url"):
            from .api import create_session

            session = create_session()
            try:
                resp = session.get(f"{conf['server_url']}/api/auth/me/")
                if resp.status_code == 200:
                    user = resp.json()
                    name = user.get("display_name") or user.get("email", "")
                    click.echo(f"User:    {name}")
                else:
                    click.echo("User:    (session expired -- run tsk login)")
            except Exception:
                click.echo("User:    (could not reach server)")
    else:
        click.echo("Auth:    not logged in")


# ── New commands ──────────────────────────────────────────────────────


@cli.command("set-status")
@click.argument("ref")
@click.argument("new_status")
def set_status_cmd(ref: str, new_status: str) -> None:
    """Update a thing's status and push immediately. REF is e.g. COM-001."""
    from .set_status import set_status

    set_status(ref, new_status)


@cli.command()
@click.argument("ref")
def start(ref: str) -> None:
    """Set a thing's status to in_progress."""
    from .set_status import set_status

    set_status(ref, "in_progress")


@cli.command()
@click.argument("ref")
def done(ref: str) -> None:
    """Set a thing's status to done."""
    from .set_status import set_status

    set_status(ref, "done")


@cli.command()
@click.argument("ref")
def review(ref: str) -> None:
    """Set a thing's status to in_review."""
    from .set_status import set_status

    set_status(ref, "in_review")


@cli.command("show")
@click.argument("ref")
def show_cmd(ref: str) -> None:
    """Display a thing's details."""
    from .show import show

    show(ref)


@cli.command("list")
@click.option("--status", "status_filter", default=None, help="Filter by status.")
@click.option("--project", "project_filter", default=None, help="Filter by project abbreviation.")
def list_cmd(status_filter: str | None, project_filter: str | None) -> None:
    """List things with optional filters."""
    from .list_cmd import list_things

    list_things(status_filter=status_filter, project_filter=project_filter)


@cli.command("open")
@click.argument("ref")
def open_cmd(ref: str) -> None:
    """Open a thing in the browser at tsk.tools."""
    from .resolve import find_thing_file, parse_thing_at

    thing_path = find_thing_file(ref)
    if not thing_path:
        click.echo(f"Thing not found: {ref}. Run tsk pull first.", err=True)
        raise SystemExit(1)

    parsed = parse_thing_at(thing_path)
    thing_id = parsed.frontmatter.get("id", "")
    if not thing_id:
        click.echo(f"Thing file missing id: {thing_path}", err=True)
        raise SystemExit(1)

    server = cfg.get_server_url()
    url = f"{server}/projects?thing={thing_id}"
    click.echo(f"Opening {url}")
    click.launch(url)
