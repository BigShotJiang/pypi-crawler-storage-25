"""
tsk set-status -- update a thing's status and push immediately.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import click

from .api import api_get, api_patch
from .push import build_thing_markdown
from .resolve import find_thing_file, parse_thing_at, snapshot_path_for

VALID_STATUSES = ("not_started", "in_progress", "in_review", "done")


def set_status(ref: str, status: str, target_dir: Path | None = None) -> None:
    if status not in VALID_STATUSES:
        click.echo(
            f"Invalid status: {status}. Must be one of: {', '.join(VALID_STATUSES)}",
            err=True,
        )
        raise SystemExit(1)

    thing_path = find_thing_file(ref, target_dir)
    if not thing_path:
        click.echo(f"Thing not found: {ref}. Run tsk pull first.", err=True)
        raise SystemExit(1)

    parsed = parse_thing_at(thing_path)
    thing_id = parsed.frontmatter.get("id", "")
    if not thing_id:
        click.echo(f"Thing file missing id: {thing_path}", err=True)
        raise SystemExit(1)

    old_status = parsed.frontmatter.get("status", "")
    if old_status == status:
        click.echo(f"{ref} is already {status}")
        return

    try:
        updated = api_patch(f"/api/things/{thing_id}/", {"status": status})
    except Exception as e:
        click.echo(f"Failed to update {ref}: {e}", err=True)
        raise SystemExit(1)

    parsed.frontmatter["status"] = status
    if isinstance(updated, dict) and updated.get("updated_at"):
        parsed.frontmatter["updated_at"] = str(updated["updated_at"])

    new_raw = build_thing_markdown(parsed.frontmatter, parsed.name, parsed.body)
    thing_path.write_text(new_raw)

    snap = snapshot_path_for(thing_path, target_dir)
    if snap.parent.is_dir():
        snap.write_text(new_raw)

    click.echo(f"{ref}: {old_status} → {status}")
