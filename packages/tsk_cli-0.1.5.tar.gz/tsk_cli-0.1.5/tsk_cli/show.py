"""
tsk show -- display a thing's details in the terminal.
"""

from __future__ import annotations

from pathlib import Path

import click

from .config import get_server_url
from .resolve import find_thing_file, parse_thing_at

_STATUS_COLORS = {
    "not_started": "white",
    "in_progress": "cyan",
    "in_review": "yellow",
    "done": "green",
}


def show(ref: str, target_dir: Path | None = None) -> None:
    thing_path = find_thing_file(ref, target_dir)
    if not thing_path:
        click.echo(f"Thing not found: {ref}. Run tsk pull first.", err=True)
        raise SystemExit(1)

    parsed = parse_thing_at(thing_path)
    fm = parsed.frontmatter

    display_ref = fm.get("ref", ref)
    status = fm.get("status", "not_started")
    assigned = fm.get("assigned_to", "")
    thing_id = fm.get("id", "")
    created = fm.get("created_at", "")
    updated = fm.get("updated_at", "")

    color = _STATUS_COLORS.get(status, "white")

    click.echo()
    click.echo(click.style(f"  {display_ref}", bold=True) + f"  {parsed.name}")
    click.echo(f"  Status:      {click.style(status, fg=color)}")
    if assigned:
        click.echo(f"  Assigned to: {assigned}")
    if created:
        click.echo(f"  Created:     {created}")
    if updated:
        click.echo(f"  Updated:     {updated}")

    if thing_id:
        server = get_server_url()
        click.echo(f"  Web:         {server}/projects?thing={thing_id}")

    if parsed.body.strip():
        click.echo()
        for line in parsed.body.strip().split("\n"):
            click.echo(f"  {line}")

    click.echo()
