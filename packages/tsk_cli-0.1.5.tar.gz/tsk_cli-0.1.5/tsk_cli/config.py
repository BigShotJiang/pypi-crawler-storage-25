"""
Manage CLI configuration stored in ~/.config/tsk/.

config.json  -- server URL, default org id/name
auth.json    -- session cookie + CSRF token
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

CONFIG_DIR = Path.home() / ".config" / "tsk"
CONFIG_FILE = CONFIG_DIR / "config.json"
AUTH_FILE = CONFIG_DIR / "auth.json"


def _ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text())


def _write_json(path: Path, data: dict[str, Any]) -> None:
    _ensure_dir()
    path.write_text(json.dumps(data, indent=2) + "\n")


# ── Config (server + org) ────────────────────────────────────────────


def get_config() -> dict[str, Any]:
    return _read_json(CONFIG_FILE)


def set_config(**fields: Any) -> dict[str, Any]:
    cfg = get_config()
    cfg.update(fields)
    _write_json(CONFIG_FILE, cfg)
    return cfg


DEFAULT_SERVER_URL = "https://tsk.tools"


def get_server_url() -> str:
    return get_config().get("server_url") or DEFAULT_SERVER_URL


def get_default_org() -> Optional[dict[str, str]]:
    """Return {"id": ..., "name": ...} or None."""
    return get_config().get("org")


# ── Auth (cookies) ───────────────────────────────────────────────────


def get_auth() -> dict[str, Any]:
    return _read_json(AUTH_FILE)


def save_auth(*, sessionid: str, csrftoken: str) -> None:
    _write_json(AUTH_FILE, {"sessionid": sessionid, "csrftoken": csrftoken})


def clear_auth() -> None:
    if AUTH_FILE.exists():
        AUTH_FILE.unlink()
