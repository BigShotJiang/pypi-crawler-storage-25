"""
tsk list -- list things with optional filters.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import click

from .push import parse_thing_markdown
from .resolve import task_root

VALID_STATUSES = ("not_started", "in_progress", "in_review", "done")

_STATUS_COLORS = {
    "not_started": "white",
    "in_progress": "cyan",
    "in_review": "yellow",
    "done": "green",
}


def list_things(
    *,
    status_filter: Optional[str] = None,
    project_filter: Optional[str] = None,
    target_dir: Path | None = None,
) -> None:
    root = task_root(target_dir)
    projects_dir = root / "projects"

    if not projects_dir.is_dir():
        click.echo("No .task/projects directory. Run: tsk pull", err=True)
        raise SystemExit(1)

    if status_filter and status_filter not in VALID_STATUSES:
        click.echo(
            f"Invalid status: {status_filter}. Must be one of: {', '.join(VALID_STATUSES)}",
            err=True,
        )
        raise SystemExit(1)

    items: list[tuple[str, str, str, str]] = []

    for md in sorted(projects_dir.glob("**/things/*.md")):
        try:
            parsed = parse_thing_markdown(md.read_text())
        except ValueError:
            continue

        ref = parsed.frontmatter.get("ref", md.stem)
        status = parsed.frontmatter.get("status", "not_started")
        assigned = parsed.frontmatter.get("assigned_to", "")
        name = parsed.name

        if project_filter:
            abbr_part = ref.split("-")[0] if "-" in ref else ""
            if abbr_part.upper() != project_filter.upper():
                continue

        if status_filter and status != status_filter:
            continue

        items.append((ref, status, name, assigned))

    if not items:
        click.echo("No things found matching filters.")
        return

    ref_w = max(len(r) for r, _, _, _ in items)
    status_w = max(len(s) for _, s, _, _ in items)

    for ref, status, name, assigned in items:
        color = _STATUS_COLORS.get(status, "white")
        name_trunc = name[:50] + ("…" if len(name) > 50 else "")
        line = (
            f"  {ref:<{ref_w}}  "
            f"{click.style(status, fg=color):<{status_w + 10}}  "
            f"{name_trunc}"
        )
        if assigned:
            line += f"  ({assigned})"
        click.echo(line)

    click.echo(f"\n  {len(items)} thing(s)")
