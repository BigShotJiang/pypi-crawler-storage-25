class DjTranslateMessagesException(Exception):
    pass
