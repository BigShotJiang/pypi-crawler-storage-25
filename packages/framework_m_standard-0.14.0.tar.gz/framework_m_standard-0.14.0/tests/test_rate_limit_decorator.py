from framework_m_standard.adapters.web.decorators import rate_limit
from framework_m_standard.adapters.web.middleware.rate_limit import RateLimitKeyResolver
from litestar import Litestar, get
from litestar.middleware.rate_limit import RateLimitConfig
from litestar.status_codes import HTTP_200_OK, HTTP_429_TOO_MANY_REQUESTS
from litestar.testing import TestClient


@rate_limit(requests=1, unit="minute")
@get("/strict")
def strict_handler() -> dict:
    return {"hello": "strict"}


@get("/relaxed")
def relaxed_handler() -> dict:
    return {"hello": "relaxed"}


def test_granular_rate_limit_decorator():
    # Global limit is high
    rate_limit_config = RateLimitConfig(
        rate_limit=("minute", 100), identifier_for_request=RateLimitKeyResolver()
    )

    with TestClient(
        app=Litestar(
            route_handlers=[strict_handler, relaxed_handler],
            middleware=[rate_limit_config.middleware],
        )
    ) as client:
        # First request to strict should pass
        response = client.get("/strict")
        assert response.status_code == HTTP_200_OK

        # Second request to strict should fail (limit is 1)
        response = client.get("/strict")
        assert response.status_code == HTTP_429_TOO_MANY_REQUESTS

        # Request to relaxed should still pass (global limit is 100)
        response = client.get("/relaxed")
        assert response.status_code == HTTP_200_OK


def test_rate_limit_decorator_plain_function():
    """Test applying @rate_limit to a plain function (no middleware attr)."""

    @rate_limit(requests=5)
    def some_func():
        return "ok"

    assert hasattr(some_func, "middleware")
    assert isinstance(some_func.middleware, list)
    assert len(some_func.middleware) == 1


def test_rate_limit_decorator_existing_middleware():
    """Test applying @rate_limit to an object that already has middleware."""

    def mock_middleware(app, handler):
        return app

    @get("/")
    def handler():
        return "ok"

    handler.middleware = [mock_middleware]

    # Applying decorator should append to existing list
    decorated = rate_limit(requests=10)(handler)

    assert len(decorated.middleware) == 2
    assert decorated.middleware[0] == mock_middleware


def test_rate_limit_decorator_non_list_middleware():
    """Test applying @rate_limit to an object where middleware is not a list."""

    def some_func():
        return "ok"

    some_func.middleware = "not-a-list"  # type: ignore

    decorated = rate_limit(requests=5)(some_func)

    assert isinstance(decorated.middleware, list)
    assert len(decorated.middleware) == 1
