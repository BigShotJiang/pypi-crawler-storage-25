from unittest.mock import MagicMock

from framework_m_core.interfaces.auth_context import UserContext
from framework_m_standard.adapters.web.middleware.rate_limit import RateLimitKeyResolver


def test_resolve_user_id_for_authenticated_requests():
    resolver = RateLimitKeyResolver()
    connection = MagicMock()
    user = UserContext(id="user_123", email="test@example.com", roles=[], tenants=[])
    # Connection in Litestar has scope. We mock enough of it.
    connection.scope = {"state": {"user": user, "tenant": None}}

    assert resolver(connection) == "user:user_123"


def test_resolve_tenant_id_for_multi_tenant_isolation():
    resolver = RateLimitKeyResolver()
    connection = MagicMock()
    tenant = MagicMock()
    tenant.id = "tenant_abc"
    connection.scope = {"state": {"user": None, "tenant": tenant}}

    assert resolver(connection) == "tenant:tenant_abc"


def test_fallback_to_ip_for_unauthenticated_requests():
    resolver = RateLimitKeyResolver()
    connection = MagicMock()
    connection.scope = {
        "state": {"user": None, "tenant": None},
        "client": ("1.2.3.4", 12345),
    }

    assert resolver(connection) == "ip:1.2.3.4"


def test_prefer_tenant_over_user():
    resolver = RateLimitKeyResolver()
    connection = MagicMock()
    user = UserContext(
        id="user_123", email="test@example.com", roles=[], tenants=["tenant_abc"]
    )
    tenant = MagicMock()
    tenant.id = "tenant_abc"
    connection.scope = {"state": {"user": user, "tenant": tenant}}

    # In multi-tenant systems, we usually want to limit the tenant as a whole
    # to protect shared resources, or limit user within tenant.
    # The TODO says "Resolve tenant_id for multi-tenant isolation".
    assert resolver(connection) == "tenant:tenant_abc"
