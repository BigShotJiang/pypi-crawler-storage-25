"""Tests for background worker logging."""

import pytest
import structlog

# This import will intentionally fail until the Green phase is implemented
from framework_m_standard.adapters.jobs.taskiq_adapter import StructlogTaskiqMiddleware
from taskiq import TaskiqMessage, TaskiqResult


@pytest.mark.asyncio
async def test_taskiq_middleware_binds_structlog_context() -> None:
    """
    Test that the structlog middleware binds job context variables
    (job_id, job_name) to the logger before execution and clears them after.
    """
    middleware = StructlogTaskiqMiddleware()

    message = TaskiqMessage(
        task_id="job-1234",
        task_name="process_payment",
        labels={},
        args=[],
        kwargs={},
    )

    # 1. Simulate the worker starting the job
    await middleware.pre_execute(message)

    # 2. Assert that structlog context variables were bound
    context = structlog.contextvars.get_contextvars()
    assert context.get("job_id") == "job-1234"
    assert context.get("job_name") == "process_payment"

    # 3. Simulate the worker finishing the job
    result = TaskiqResult(is_err=False, return_value=None, execution_time=0.1)
    await middleware.post_execute(message, result)

    # 4. Assert that context was cleanly unbound
    context_after = structlog.contextvars.get_contextvars()
    assert "job_id" not in context_after
