"""Integration tests for Hierarchical Rate Limiting."""

from typing import Any
from unittest.mock import AsyncMock

import pytest
from framework_m_core.interfaces.permission import (
    DecisionSource,
    PermissionAction,
    PolicyEvaluateRequest,
    PolicyEvaluateResult,
)
from framework_m_standard.adapters.auth.quota_handler import QuotaPolicyHandler


class TestHierarchicalQuotas:
    """Tests for hierarchical quota enforcement."""

    @pytest.mark.asyncio
    async def test_hierarchical_quota_caps_child(self) -> None:
        """Parent tenant's quota exhaustion should deny child tenant's request."""
        # Mock RBAC to always allow
        mock_base = AsyncMock()
        mock_base.evaluate.return_value = PolicyEvaluateResult(
            authorized=True, decision_source=DecisionSource.RBAC
        )

        # Mock metering service
        mock_meter = AsyncMock()

        async def mock_get_usage(tenant_id: str, **kwargs: Any) -> float:
            if tenant_id == "root-org":
                return 10.0  # Root has reached its quota
            return 2.0  # Child has not reached quota

        mock_meter.get_current_usage.side_effect = mock_get_usage

        handler = QuotaPolicyHandler(
            base_adapter=mock_base,
            metering_service=mock_meter,
            quotas={"Invoice": {"feature": "invoice_count", "limit": 10.0}},
        )

        request = PolicyEvaluateRequest(
            principal="user-1",
            action=PermissionAction.CREATE,
            resource="Invoice",
            tenant_id="child-org",
            tenant_lineage=["root-org", "child-org"],
        )
        result = await handler.evaluate(request)

        assert result.authorized is False
        assert result.decision_source == DecisionSource.CUSTOM
        assert "Quota exceeded" in (result.reason or "")
        assert "root-org" in (result.reason or "")
