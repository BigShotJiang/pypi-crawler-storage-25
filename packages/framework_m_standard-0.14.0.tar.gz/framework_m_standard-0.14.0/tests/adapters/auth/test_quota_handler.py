"""Tests for QuotaPolicyHandler."""

from unittest.mock import AsyncMock

import pytest
from framework_m_core.interfaces.permission import (
    DecisionSource,
    PermissionAction,
    PolicyEvaluateRequest,
    PolicyEvaluateResult,
)


class TestQuotaPolicyHandler:
    """Tests for the QuotaPolicyHandler decorator."""

    @pytest.mark.asyncio
    async def test_allows_when_under_quota(self) -> None:
        """Should allow request if base permits and usage is under quota."""
        from framework_m_standard.adapters.auth.quota_handler import QuotaPolicyHandler

        # Mock base permission (Allows)
        mock_base = AsyncMock()
        mock_base.evaluate.return_value = PolicyEvaluateResult(
            authorized=True, decision_source=DecisionSource.RBAC
        )

        # Mock metering (Current usage is 5)
        mock_meter = AsyncMock()
        mock_meter.get_current_usage.return_value = 5.0

        handler = QuotaPolicyHandler(
            base_adapter=mock_base,
            metering_service=mock_meter,
            quotas={"Invoice": {"feature": "invoice_count", "limit": 10.0}},
        )

        request = PolicyEvaluateRequest(
            principal="user-1",
            action=PermissionAction.CREATE,
            resource="Invoice",
            tenant_id="tenant-1",
        )
        result = await handler.evaluate(request)

        assert result.authorized is True
        assert result.decision_source == DecisionSource.RBAC

    @pytest.mark.asyncio
    async def test_denies_when_over_quota(self) -> None:
        """Should deny request if usage meets or exceeds the quota limit."""
        from framework_m_standard.adapters.auth.quota_handler import QuotaPolicyHandler

        mock_base = AsyncMock()
        mock_base.evaluate.return_value = PolicyEvaluateResult(authorized=True)

        # Current usage is 10 (Limit is 10)
        mock_meter = AsyncMock()
        mock_meter.get_current_usage.return_value = 10.0

        handler = QuotaPolicyHandler(
            base_adapter=mock_base,
            metering_service=mock_meter,
            quotas={"Invoice": {"feature": "invoice_count", "limit": 10.0}},
        )

        request = PolicyEvaluateRequest(
            principal="user-1",
            action=PermissionAction.CREATE,
            resource="Invoice",
            tenant_id="tenant-1",
        )
        result = await handler.evaluate(request)

        assert result.authorized is False
        assert result.decision_source == DecisionSource.CUSTOM
        assert "Quota exceeded" in (result.reason or "")

    @pytest.mark.asyncio
    async def test_skips_quota_check_for_non_create_actions(self) -> None:
        """Should only enforce quotas on CREATE actions by default."""
        from framework_m_standard.adapters.auth.quota_handler import QuotaPolicyHandler

        mock_base = AsyncMock()
        mock_base.evaluate.return_value = PolicyEvaluateResult(authorized=True)
        mock_meter = AsyncMock()

        handler = QuotaPolicyHandler(
            base_adapter=mock_base,
            metering_service=mock_meter,
            quotas={"Invoice": {"feature": "invoice_count", "limit": 0.0}},
        )

        # Action is READ, so it should bypass the 0.0 quota limit
        request = PolicyEvaluateRequest(
            principal="user-1",
            action=PermissionAction.READ,
            resource="Invoice",
            tenant_id="tenant-1",
        )
        result = await handler.evaluate(request)

        assert result.authorized is True
        mock_meter.get_current_usage.assert_not_called()
