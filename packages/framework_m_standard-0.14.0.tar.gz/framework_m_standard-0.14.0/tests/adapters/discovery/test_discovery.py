"""Tests for project discovery utilities."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from framework_m_standard.adapters.discovery import (
    discover_local_packages,
    get_project_root,
    is_containerized,
    resolve_app_modules,
    safe_import_module,
)


class TestPathRootDetection:
    """Tests for get_project_root() path resolution."""

    def test_discovery_path_root_detection_pyproject(self, tmp_path: Path) -> None:
        """Should discover project root via pyproject.toml."""
        root = tmp_path / "my_project"
        root.mkdir()
        (root / "pyproject.toml").touch()

        sub_dir = root / "src" / "app"
        sub_dir.mkdir(parents=True)

        assert get_project_root(sub_dir) == root

    def test_discovery_path_root_detection_git(self, tmp_path: Path) -> None:
        """Should discover project root via .git directory."""
        root = tmp_path / "my_project"
        root.mkdir()
        (root / ".git").mkdir()

        sub_dir = root / "src" / "app"
        sub_dir.mkdir(parents=True)

        assert get_project_root(sub_dir) == root

    def test_discovery_path_root_detection_framework_config(
        self, tmp_path: Path
    ) -> None:
        """Should discover project root via framework_config.toml (Container/Prod)."""
        root = tmp_path / "my_project"
        root.mkdir()
        (root / "framework_config.toml").touch()

        sub_dir = root / "src" / "app"
        sub_dir.mkdir(parents=True)

        assert get_project_root(sub_dir) == root

    def test_discovery_path_root_detection_alembic_ini(self, tmp_path: Path) -> None:
        """Should discover project root via alembic.ini (Container/Prod)."""
        root = tmp_path / "my_project"
        root.mkdir()
        (root / "alembic.ini").touch()

        sub_dir = root / "src" / "app"
        sub_dir.mkdir(parents=True)

        assert get_project_root(sub_dir) == root

    def test_discovery_path_root_detection_fallback(self, tmp_path: Path) -> None:
        """Should fallback to CWD if no root markers are found."""
        sub_dir = tmp_path / "some" / "random" / "path"
        sub_dir.mkdir(parents=True)

        with patch("pathlib.Path.cwd", return_value=sub_dir):
            assert get_project_root(sub_dir) == sub_dir


class TestEnvironmentContext:
    """Tests for is_containerized() execution context detection."""

    def test_discovery_environment_context_dockerenv(self) -> None:
        """Should detect container via /.dockerenv existence."""

        def mock_path(p: Any) -> MagicMock:
            m = MagicMock()
            m.exists.return_value = str(p) == "/.dockerenv"
            return m

        with patch(
            "framework_m_standard.adapters.discovery.env.Path", side_effect=mock_path
        ):
            assert is_containerized() is True

    def test_discovery_environment_context_containerenv(self) -> None:
        """Should detect Podman container via /run/.containerenv existence."""

        def mock_path(p: Any) -> MagicMock:
            m = MagicMock()
            m.exists.return_value = str(p) == "/run/.containerenv"
            return m

        with patch(
            "framework_m_standard.adapters.discovery.env.Path", side_effect=mock_path
        ):
            assert is_containerized() is True

    def test_discovery_environment_context_cgroup_libpod(self) -> None:
        """Should detect Podman via libpod cgroup parsing."""

        def mock_path(p: Any) -> MagicMock:
            m = MagicMock()
            if str(p) == "/proc/1/cgroup":
                m.exists.return_value = True
                m.read_text.return_value = "1:name=systemd:/libpod-123456789"
            else:
                m.exists.return_value = False
            return m

        with patch(
            "framework_m_standard.adapters.discovery.env.Path", side_effect=mock_path
        ):
            assert is_containerized() is True

    def test_discovery_environment_context_cgroup(self) -> None:
        """Should detect container via cgroup parsing."""

        def mock_path(p: Any) -> MagicMock:
            m = MagicMock()
            if str(p) == "/proc/1/cgroup":
                m.exists.return_value = True
                m.read_text.return_value = "1:name=systemd:/docker/123456789"
            else:
                m.exists.return_value = False
            return m

        with patch(
            "framework_m_standard.adapters.discovery.env.Path", side_effect=mock_path
        ):
            assert is_containerized() is True

    def test_discovery_environment_context_bare_metal(self) -> None:
        """Should correctly identify bare metal environments."""

        def mock_path(p: Any) -> MagicMock:
            m = MagicMock()
            if str(p) == "/proc/1/cgroup":
                m.exists.return_value = True
                m.read_text.return_value = "1:name=systemd:/init.scope"
            else:
                m.exists.return_value = False
            return m

        with patch(
            "framework_m_standard.adapters.discovery.env.Path", side_effect=mock_path
        ):
            assert is_containerized() is False


class TestRecursiveModuleScanning:
    """Tests for package scanning and safe imports."""

    def test_discovery_package_scanning_src_layout(self, tmp_path: Path) -> None:
        """Should discover packages inside a src/ directory."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()

        # Create a valid package
        pkg_dir = src_dir / "my_local_app"
        pkg_dir.mkdir()
        (pkg_dir / "__init__.py").touch()

        # Create an invalid package (no init)
        (src_dir / "not_a_pkg").mkdir()

        packages = discover_local_packages(tmp_path)
        assert "my_local_app" in packages
        assert "not_a_pkg" not in packages

    def test_discovery_package_scanning_flat_layout(self, tmp_path: Path) -> None:
        """Should fallback to scanning root if src/ does not exist."""
        pkg_dir = tmp_path / "flat_app"
        pkg_dir.mkdir()
        (pkg_dir / "__init__.py").touch()

        packages = discover_local_packages(tmp_path)
        assert "flat_app" in packages

    def test_discovery_doctype_import_safety_success(self) -> None:
        """safe_import_module should return the module if successful."""
        # Import a known standard library module
        mod = safe_import_module("json")
        assert mod is not None
        assert mod.__name__ == "json"

    def test_discovery_doctype_import_safety_failure(self, tmp_path: Path) -> None:
        """safe_import_module should swallow exceptions and return None."""
        # Create a Python file with a deliberate syntax error
        bad_file = tmp_path / "bad_syntax.py"
        bad_file.write_text("def broken_function(:\n    pass")

        sys.path.insert(0, str(tmp_path))
        try:
            mod = safe_import_module("bad_syntax")
            assert mod is None
        finally:
            sys.path.remove(str(tmp_path))


class TestDiscoveryConflictResolution:
    """Tests for app deduplication and override logic."""

    @patch("os.environ.get")
    def test_discovery_deduplication_logic(
        self, mock_env_get: MagicMock, tmp_path: Path
    ) -> None:
        """Should deduplicate apps found in INSTALLED_APPS vs local discovery."""
        mock_env_get.return_value = "my_local_app, remote_app, another_app"

        # Setup local app
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        pkg_dir = src_dir / "my_local_app"
        pkg_dir.mkdir()
        (pkg_dir / "__init__.py").touch()

        apps = resolve_app_modules(tmp_path)

        assert len(apps) == 3
        assert set(apps) == {"my_local_app", "remote_app", "another_app"}
        # Ensure local app maintains first priority
        assert apps[0] == "my_local_app"

    @patch("importlib.metadata.entry_points")
    def test_discovery_local_override_priority(
        self, mock_entry_points: MagicMock, tmp_path: Path
    ) -> None:
        """Should prioritize local source code over installed entry points."""
        # Setup mock entry point
        mock_ep = MagicMock()
        mock_ep.name = "core_app"
        mock_entry_points.return_value = {"framework_m.apps": [mock_ep]}

        # Setup local override of the same app
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        pkg_dir = src_dir / "core_app"
        pkg_dir.mkdir()
        (pkg_dir / "__init__.py").touch()

        apps = resolve_app_modules(tmp_path)

        # Should only appear once, and local discovery ensures it stays first
        assert apps.count("core_app") == 1
        assert apps[0] == "core_app"
