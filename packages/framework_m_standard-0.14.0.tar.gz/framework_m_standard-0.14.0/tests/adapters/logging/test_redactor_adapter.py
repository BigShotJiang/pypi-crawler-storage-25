"""Tests for the Structlog Redaction Adapter."""

from typing import Any

from framework_m_core.config import LoggingConfig
from framework_m_core.interfaces.redactor import RedactorProtocol

# This import will intentionally fail until Phase 4 Green is implemented
from framework_m_standard.adapters.logging.redactor_processor import (
    SecretRedactionProcessor,
)


class DummyRedactor(RedactorProtocol):
    """Fake redactor protocol implementation for testing."""

    def scrub(self, event_dict: dict[str, Any]) -> dict[str, Any]:
        """Simple mock behavior replacing 'secret' key."""
        # We copy to simulate the behavior of the real domain logic
        new_dict = event_dict.copy()
        if "secret" in new_dict:
            new_dict["secret"] = "***REDACTED***"
        return new_dict


def test_processor_calls_redactor() -> None:
    """Test that the processor delegates to the redactor protocol when enabled."""
    config = LoggingConfig(enabled=True)
    redactor = DummyRedactor()
    processor = SecretRedactionProcessor(config=config, redactor=redactor)

    event_dict = {"event": "user_login", "secret": "my_password", "public": "data"}

    # structlog processors take (logger, method_name, event_dict)
    result = processor(None, "info", event_dict)

    assert result["secret"] == "***REDACTED***"
    assert result["public"] == "data"


def test_processor_skips_when_disabled() -> None:
    """Test that redaction is bypassed if logging config disables it."""
    config = LoggingConfig(enabled=False)

    class BoomRedactor(RedactorProtocol):
        def scrub(self, event_dict: dict[str, Any]) -> dict[str, Any]:
            raise RuntimeError("Should not be called when disabled!")

    redactor = BoomRedactor()
    processor = SecretRedactionProcessor(config=config, redactor=redactor)

    event_dict = {"event": "test", "secret": "unmasked"}
    result = processor(None, "info", event_dict)

    assert result["secret"] == "unmasked"
