"""Tests for Temporal Worker Adapter."""

import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.interfaces.worker import (
    ActivityRegistry,
    WorkerProtocol,
    worker_activity,
)
from framework_m_standard.adapters.workflow.temporal_worker import TemporalWorkerAdapter


def test_temporal_worker_implements_protocol() -> None:
    """Ensure the Temporal worker conforms to WorkerProtocol."""
    adapter = TemporalWorkerAdapter()
    assert isinstance(adapter, WorkerProtocol)


def test_temporal_worker_init_defaults():
    """Test default values when no args or env are provided."""
    with patch.dict("os.environ", {}, clear=True):
        adapter = TemporalWorkerAdapter()
        assert adapter._host == "localhost:7233"
        assert adapter._namespace == "default"
        assert adapter._task_queue == "framework-m-workflows"


def test_temporal_worker_init_env():
    """Test resolution from environment variables."""
    env = {
        "TEMPORAL_URL": "remote:7233",
        "TEMPORAL_NAMESPACE": "custom",
        "TEMPORAL_TASK_QUEUE": "custom-queue",
        "TEMPORAL_API_KEY": "sk-123",
        "TEMPORAL_CLIENT_CERT": "cert-data",
        "TEMPORAL_CLIENT_KEY": "key-data",
    }
    with patch.dict("os.environ", env):
        adapter = TemporalWorkerAdapter()
        assert adapter._host == "remote:7233"
        assert adapter._namespace == "custom"
        assert adapter._task_queue == "custom-queue"
        assert adapter._api_key == "sk-123"
        assert adapter._client_cert == "cert-data"
        assert adapter._client_key == "key-data"


def test_temporal_worker_set_secrets_manager():
    """Test secret override from secrets manager."""
    adapter = TemporalWorkerAdapter()
    secrets = MagicMock()
    secrets.get.side_effect = lambda k, d=None: f"secret-{k}"

    adapter.set_secrets_manager(secrets)
    assert adapter._api_key == "secret-TEMPORAL_API_KEY"
    assert adapter._client_cert == "secret-TEMPORAL_CLIENT_CERT"
    assert adapter._client_key == "secret-TEMPORAL_CLIENT_KEY"


def test_temporal_worker_set_secrets_manager_none() -> None:
    """Test secret override when secrets manager is None or empty."""
    adapter = TemporalWorkerAdapter()
    adapter._api_key = "orig"

    # Passing None should safely skip the override branch
    adapter.set_secrets_manager(None)  # type: ignore
    assert adapter._api_key == "orig"


@pytest.mark.asyncio
async def test_temporal_worker_lifecycle() -> None:
    """Test that the worker starts, registers activities, and stops cleanly."""
    # 1. Register a mock activity
    ActivityRegistry.get_instance().clear()

    @worker_activity(name="send_welcome_email")
    async def mock_activity(email: str) -> bool:
        return True

    # 2. Mock the temporalio SDK so we don't need a real server
    mock_temporalio = MagicMock()
    mock_client_cls = MagicMock()
    mock_client_cls.connect = AsyncMock()
    mock_worker_cls = MagicMock()
    mock_worker_instance = MagicMock()

    async def blocking_run(*args: Any, **kwargs: Any) -> None:
        # Simulate a long-running worker loop until cancelled
        await asyncio.sleep(3600)

    mock_worker_instance.run = AsyncMock(side_effect=blocking_run)
    mock_worker_cls.return_value = mock_worker_instance

    mock_temporalio.client.Client = mock_client_cls
    mock_temporalio.worker.Worker = mock_worker_cls

    with patch.dict(
        "sys.modules",
        {
            "temporalio": mock_temporalio,
            "temporalio.client": mock_temporalio.client,
            "temporalio.worker": mock_temporalio.worker,
        },
    ):
        adapter = TemporalWorkerAdapter(host="localhost:7233", task_queue="test-queue")

        # 3. Start the worker
        await adapter.start()

        # Yield to event loop to allow background task to run
        await asyncio.sleep(0)

        mock_client_cls.connect.assert_called_once_with(
            "localhost:7233",
            namespace="default",
            tls=False,
            rpc_metadata={},
        )
        mock_worker_cls.assert_called_once()
        mock_worker_instance.run.assert_called_once()

        # 4. Stop the worker
        await adapter.stop()
        assert adapter._worker_task is None or adapter._worker_task.cancelled()


@pytest.mark.asyncio
async def test_temporal_worker_stop_cancels_task() -> None:
    """Test stopping a worker with an active task."""
    adapter = TemporalWorkerAdapter()

    async def dummy_task() -> None:
        await asyncio.sleep(3600)

    adapter._worker_task = asyncio.create_task(dummy_task())

    assert not adapter._worker_task.done()
    await adapter.stop()
    assert adapter._worker_task.cancelled()


@pytest.mark.asyncio
async def test_temporal_worker_import_error() -> None:
    """Temporal worker should raise ImportError if SDK is not installed."""
    adapter = TemporalWorkerAdapter()
    with (
        patch.dict(
            "sys.modules", {"temporalio.client": None, "temporalio.worker": None}
        ),
        pytest.raises(ImportError, match="Temporal SDK not installed"),
    ):
        await adapter.start()


@pytest.mark.asyncio
async def test_temporal_worker_with_mtls_and_api_key() -> None:
    """Test worker correctly configures TLS and API key."""
    ActivityRegistry.get_instance().clear()

    mock_temporalio = MagicMock()
    mock_client_cls = MagicMock()
    mock_client_cls.connect = AsyncMock()
    mock_worker_cls = MagicMock()
    mock_worker_instance = MagicMock()
    mock_worker_instance.run = AsyncMock()
    mock_worker_cls.return_value = mock_worker_instance

    mock_temporalio.client.Client = mock_client_cls
    mock_temporalio.worker.Worker = mock_worker_cls
    mock_temporalio.client.TLSConfig = MagicMock()

    with (
        patch.dict(
            "sys.modules",
            {
                "temporalio": mock_temporalio,
                "temporalio.client": mock_temporalio.client,
                "temporalio.worker": mock_temporalio.worker,
            },
        ),
        patch.dict(
            "os.environ",
            {
                "TEMPORAL_API_KEY": "test-key",
                "TEMPORAL_CLIENT_CERT": "-----BEGIN CERTIFICATE-----",
                "TEMPORAL_CLIENT_KEY": "-----BEGIN PRIVATE KEY-----",
            },
        ),
    ):
        adapter = TemporalWorkerAdapter(host="localhost:7233", task_queue="test-queue")
        await adapter.start()

        # Ensure TLSConfig was instantiated
        mock_temporalio.client.TLSConfig.assert_called_once()

        # Verify connect was called with TLS and RPC metadata
        connect_kwargs = mock_client_cls.connect.call_args.kwargs
        assert connect_kwargs["tls"] is not False
        assert connect_kwargs["rpc_metadata"] == {"Authorization": "Bearer test-key"}

        await adapter.stop()


@pytest.mark.asyncio
async def test_temporal_worker_stop_without_start() -> None:
    """Stopping a worker that hasn't started should be a no-op."""
    adapter = TemporalWorkerAdapter()
    await adapter.stop()
    assert adapter._worker_task is None


@pytest.mark.asyncio
async def test_temporal_worker_tls_config_path(tmp_path) -> None:
    """Test loading TLS certs from file paths."""
    cert_file = tmp_path / "cert.pem"
    key_file = tmp_path / "key.pem"
    cert_file.write_bytes(b"cert-from-file")
    key_file.write_bytes(b"key-from-file")

    mock_temporalio = MagicMock()
    mock_temporalio.client.Client.connect = AsyncMock()
    mock_temporalio.client.TLSConfig = MagicMock()
    mock_worker_instance = MagicMock()
    mock_worker_instance.run = AsyncMock()
    mock_temporalio.worker.Worker = MagicMock(return_value=mock_worker_instance)

    with (
        patch.dict(
            "sys.modules",
            {
                "temporalio": mock_temporalio,
                "temporalio.client": mock_temporalio.client,
                "temporalio.worker": mock_temporalio.worker,
            },
        ),
        patch.dict(
            "os.environ",
            {
                "TEMPORAL_CLIENT_CERT": str(cert_file),
                "TEMPORAL_CLIENT_KEY": str(key_file),
            },
        ),
        patch("framework_m_core.interfaces.worker.ActivityRegistry.get_instance"),
    ):
        adapter = TemporalWorkerAdapter()
        await adapter.start()

        mock_temporalio.client.TLSConfig.assert_called_once_with(
            client_cert=b"cert-from-file", client_private_key=b"key-from-file"
        )
        await adapter.stop()
