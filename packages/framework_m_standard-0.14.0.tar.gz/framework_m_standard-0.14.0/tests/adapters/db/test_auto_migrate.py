"""Tests for auto_migrate() functionality."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_standard.adapters.db.migration import MigrationManager
from sqlalchemy import Column, Integer, MetaData, String, Table, create_engine, inspect
from sqlalchemy.types import JSON


class TestAutoMigrate:
    """Tests for auto_migrate() functionality."""

    def test_auto_migrate_returns_changes(self, tmp_path: Path) -> None:
        """auto_migrate() should return detected changes."""
        target_metadata = MetaData()
        Table(
            "products",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("name", String(100)),
        )

        # Create explicit sync SQLite engine to avoid aiosqlite async issues
        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        changes = manager.auto_migrate(
            target_metadata=target_metadata,
            dry_run=True,
            engine=engine,
        )

        assert len(changes) >= 1

    def test_auto_migrate_dry_run_no_files(self, tmp_path: Path) -> None:
        """auto_migrate(dry_run=True) should not create migration files."""
        target_metadata = MetaData()
        Table(
            "test_table",
            target_metadata,
            Column("id", Integer, primary_key=True),
        )

        # Create explicit sync SQLite engine to avoid aiosqlite async issues
        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        manager.auto_migrate(
            target_metadata=target_metadata, dry_run=True, engine=engine
        )

        # No migration files should be created
        versions_dir = tmp_path / "alembic" / "versions"
        migration_files = list(versions_dir.glob("*.py"))
        assert len(migration_files) == 0


class TestAutoMigrateDevMode:
    """Tests for auto_migrate() dev mode functionality."""

    def test_auto_migrate_dev_mode_creates_table(self, tmp_path: Path) -> None:
        """auto_migrate(dev_mode=True) should create new tables directly."""
        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        target_metadata = MetaData()
        Table(
            "items",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("name", String(100)),
        )

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        changes = manager.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=True,
            engine=engine,
        )

        # Should have detected and applied the change
        assert len(changes) >= 1

        # Verify table was created
        inspector = inspect(engine)
        assert "items" in inspector.get_table_names()

    def test_auto_migrate_dev_mode_adds_column(self, tmp_path: Path) -> None:
        """auto_migrate(dev_mode=True) should add new columns directly."""
        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        # Create initial table
        initial_metadata = MetaData()
        Table(
            "items",
            initial_metadata,
            Column("id", Integer, primary_key=True),
        )
        initial_metadata.create_all(engine)

        # Target with new column
        target_metadata = MetaData()
        Table(
            "items",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("description", String(255)),
        )

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        changes = manager.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=True,
            engine=engine,
        )

        # Should have detected the new column
        assert len(changes) >= 1

        # Verify column was added
        inspector = inspect(engine)
        columns = [c["name"] for c in inspector.get_columns("items")]
        assert "description" in columns

    def test_auto_migrate_dev_mode_adds_column_with_defaults(
        self, tmp_path: Path
    ) -> None:
        """auto_migrate(dev_mode=True) should correctly stringify JSON/SQL defaults."""
        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        # Create initial table
        initial_metadata = MetaData()
        Table(
            "complex_items",
            initial_metadata,
            Column("id", Integer, primary_key=True),
        )
        initial_metadata.create_all(engine)

        # Target with new columns showcasing various defaults
        target_metadata = MetaData()
        Table(
            "complex_items",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("str_col", String(255), default="default string with ' quote"),
            Column("json_dict", JSON, default={"key": "value"}),
            Column("json_list", JSON, default=[1, 2, 3]),
            Column("json_call_dict", JSON, default=dict),
            Column("json_call_list", JSON, default=list),
            Column("num_col", Integer, default=42),
            Column("custom_fields", JSON),  # should trigger the fallback
        )

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        changes = manager.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=True,
            engine=engine,
        )

        assert len(changes) >= 1

        inspector = inspect(engine)
        columns = {c["name"]: c for c in inspector.get_columns("complex_items")}

        assert "str_col" in columns
        assert "json_dict" in columns
        assert "json_list" in columns
        assert "json_call_dict" in columns
        assert "json_call_list" in columns
        assert "num_col" in columns
        assert "custom_fields" in columns


class TestAutoMigrateProdMode:
    """Tests for auto_migrate() standard/production mode functionality."""

    @patch("alembic.command.revision")
    def test_auto_migrate_creates_revision(
        self, mock_revision: MagicMock, tmp_path: Path
    ) -> None:
        """auto_migrate(dev_mode=False) should generate an Alembic revision."""
        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        target_metadata = MetaData()
        Table(
            "items",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("name", String(100)),
        )

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        changes = manager.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=False,
            dry_run=False,
            engine=engine,
        )

        assert len(changes) >= 1
        mock_revision.assert_called_once()
        assert mock_revision.call_args.kwargs.get("autogenerate") is True


class TestAutoMigrateIdempotency:
    """Tests to verify idempotency of migration runs."""

    def test_migrate_all_idempotent_run(self, tmp_path: Path) -> None:
        """auto_migrate() should detect zero changes on subsequent runs with identical schema."""
        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        target_metadata = MetaData()
        # Complex schema with multiple tables, foreign keys, and indexes
        Table(
            "companies",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("name", String(100)),
        )
        Table(
            "users",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("email", String(255), unique=True),
        )
        Table(
            "logs",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("data", JSON),
        )

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        # 1. Initial Run (Should create tables and return changes)
        initial_changes = manager.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=True,
            engine=engine,
        )
        assert len(initial_changes) == 3  # 3 NEW_TABLE changes

        # 2. Idempotent Run (Should detect 0 changes)
        subsequent_changes = manager.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=True,
            engine=engine,
        )
        assert len(subsequent_changes) == 0
