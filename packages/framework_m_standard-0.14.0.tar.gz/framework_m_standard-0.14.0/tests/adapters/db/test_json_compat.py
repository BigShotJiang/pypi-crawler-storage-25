"""Tests for JSON compatibility helpers."""

from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal
from uuid import UUID

from framework_m_standard.adapters.db.json_compat import to_json_compatible


def test_to_json_compatible_primitives() -> None:
    """Should return primitives as-is."""
    assert to_json_compatible(1) == 1
    assert to_json_compatible("test") == "test"
    assert to_json_compatible(True) is True
    assert to_json_compatible(None) is None


def test_to_json_compatible_decimal() -> None:
    """Should convert Decimal to string."""
    val = Decimal("10.50")
    assert to_json_compatible(val) == "10.50"


def test_to_json_compatible_datetime() -> None:
    """Should convert date/time objects to ISO strings."""
    dt = datetime(2026, 4, 21, 12, 0, 0)
    d = date(2026, 4, 21)
    t = time(12, 0, 0)

    assert to_json_compatible(dt) == "2026-04-21T12:00:00"
    assert to_json_compatible(d) == "2026-04-21"
    assert to_json_compatible(t) == "12:00:00"


def test_to_json_compatible_uuid() -> None:
    """Should convert UUID to string."""
    val = UUID("550e8400-e29b-41d4-a716-446655440000")
    assert to_json_compatible(val) == "550e8400-e29b-41d4-a716-446655440000"


def test_to_json_compatible_list_tuple() -> None:
    """Should convert lists and tuples recursively."""
    val_list = [Decimal("1.1"), UUID("550e8400-e29b-41d4-a716-446655440000")]
    val_tuple = (date(2026, 4, 21), "nested")

    assert to_json_compatible(val_list) == [
        "1.1",
        "550e8400-e29b-41d4-a716-446655440000",
    ]
    assert to_json_compatible(val_tuple) == ["2026-04-21", "nested"]


def test_to_json_compatible_dict() -> None:
    """Should convert dicts recursively and stringify keys."""
    val = {
        "price": Decimal("25.00"),
        date(2026, 4, 21): "today",
        "tags": (1, 2),
    }

    result = to_json_compatible(val)
    assert result["price"] == "25.00"
    assert result["2026-04-21"] == "today"
    assert result["tags"] == [1, 2]
