# =============================================================================
# Test: Performance & Lock Protection
# =============================================================================


from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.adapters.db.migration import MigrationManager


class TestPerformanceAndLockProtection:
    """Tests for performance and lock protection features."""

    @patch(
        "framework_m_standard.adapters.db.migration.resolve_app_modules",
        return_value=[],
    )
    def test_perf_dangerous_op_detection(
        self,
        mock_resolve: MagicMock,
        tmp_path: Path,
    ) -> None:
        """auto_migrate should detect and warn about dangerous operations."""
        from framework_m_standard.adapters.db.exceptions import DangerousOperationError
        from sqlalchemy import Column, Integer, MetaData, String, Table, create_engine

        # Simulate a dangerous operation: adding a NOT NULL column without a default
        target_metadata = MetaData()
        Table("users", target_metadata, Column("id", Integer, primary_key=True))
        # Initial migration
        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{tmp_path}/test.db"
        )
        manager.init()
        manager.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=False,
            engine=create_engine(f"sqlite:///{tmp_path}/test.db"),
        )

        # Add a dangerous column
        Table(
            "users",
            target_metadata,
            Column("id", Integer, primary_key=True),
            Column("new_col", String, nullable=False),
            extend_existing=True,
        )

        with pytest.raises(
            DangerousOperationError, match="Detected dangerous operation"
        ):
            manager.auto_migrate(
                target_metadata=target_metadata,
                dev_mode=True,
                engine=create_engine(f"sqlite:///{tmp_path}/test.db"),
            )

    @patch(
        "framework_m_standard.adapters.db.migration.resolve_app_modules",
        return_value=[],
    )
    def test_perf_lock_timeout_guard(
        self,
        mock_resolve: MagicMock,
        tmp_path: Path,
    ) -> None:
        """auto_migrate should apply lock_timeout guard in PostgreSQL."""
        from framework_m_standard.adapters.db.schema_detector import (
            SchemaChange,
            SchemaChangeType,
        )
        from sqlalchemy import Column, Integer, MetaData, Table

        target_metadata = MetaData()
        Table("users", target_metadata, Column("id", Integer, primary_key=True))

        manager = MigrationManager(
            tmp_path, database_url="postgresql+asyncpg://user:pass@localhost/db"
        )
        manager.init()

        mock_engine = MagicMock()
        mock_engine.dialect.name = "postgresql"
        mock_engine.url = "postgresql+asyncpg://user:pass@localhost/db"
        mock_conn = MagicMock()
        mock_engine.begin.return_value.__enter__.return_value = mock_conn

        with (
            patch("sqlalchemy.MetaData.reflect"),
            patch.object(target_metadata, "create_all"),
        ):
            manager.detect_schema_changes = MagicMock(
                return_value=[SchemaChange(SchemaChangeType.NEW_TABLE, "users")]
            )
            manager.auto_migrate(
                target_metadata=target_metadata,
                dev_mode=True,
                engine=mock_engine,
                max_lock_time=5,
            )

        executed_sqls = [
            call.args[0].text for call in mock_conn.execute.call_args_list if call.args
        ]
        assert "SET LOCAL lock_timeout = '5s';" in executed_sqls
