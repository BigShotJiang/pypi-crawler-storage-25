"""Tests for multi-tenancy and schema isolation during migration sync."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_standard.cli.migrate import sync_command
from sqlalchemy import MetaData


class PublicDoc(BaseDocType):
    title: str

    class Meta:
        is_tenant_specific = False


class TenantDoc(BaseDocType):
    title: str

    class Meta:
        is_tenant_specific = True


class TestMultiTenancyIsolation:
    """Tests for multi-tenancy schema isolation."""

    @patch("framework_m_standard.cli.migrate.get_manager")
    @patch("framework_m_core.registry.MetaRegistry.get_instance")
    def test_mt_tenant_filter_sync(
        self, mock_get_instance: MagicMock, mock_get_manager: MagicMock
    ) -> None:
        """Verify that --tenant [ID] filters for schema-scoped sync and sets MetaData schema."""
        mock_registry = MagicMock()
        mock_registry.list_doctypes.return_value = ["PublicDoc", "TenantDoc"]
        mock_registry.get_doctype.side_effect = lambda n: (
            PublicDoc if n == "PublicDoc" else TenantDoc
        )
        mock_get_instance.return_value = mock_registry

        mock_manager = MagicMock()
        mock_get_manager.return_value = mock_manager

        # Run sync for tenant "acme"
        sync_command(dry_run=True, tenant="acme")

        mock_manager.auto_migrate.assert_called_once()
        kwargs = mock_manager.auto_migrate.call_args.kwargs
        target_metadata: MetaData = kwargs["target_metadata"]

        # MetaData should be bound to the tenant schema
        assert target_metadata.schema == "acme"

        table_names = [t.name for t in target_metadata.tables.values()]
        assert "tenantdoc" in table_names

    @patch("framework_m_standard.cli.migrate.get_manager")
    @patch("framework_m_core.registry.MetaRegistry.get_instance")
    def test_mt_public_isolation_check(
        self, mock_get_instance: MagicMock, mock_get_manager: MagicMock
    ) -> None:
        """Validate that `public` DocTypes are never synced to tenant schemas."""
        mock_registry = MagicMock()
        mock_registry.list_doctypes.return_value = ["PublicDoc", "TenantDoc"]
        mock_registry.get_doctype.side_effect = lambda n: (
            PublicDoc if n == "PublicDoc" else TenantDoc
        )
        mock_get_instance.return_value = mock_registry

        mock_manager = MagicMock()
        mock_get_manager.return_value = mock_manager

        # Run sync for tenant "acme"
        sync_command(dry_run=True, tenant="acme")

        kwargs = mock_manager.auto_migrate.call_args.kwargs
        target_metadata: MetaData = kwargs["target_metadata"]

        # PublicDoc should NOT be in the tenant's target metadata
        table_names = [t.name for t in target_metadata.tables.values()]
        assert "publicdoc" not in table_names

        # Now test public sync (no tenant specified)
        mock_manager.auto_migrate.reset_mock()
        sync_command(dry_run=True, tenant=None)

        kwargs = mock_manager.auto_migrate.call_args.kwargs
        public_metadata: MetaData = kwargs["target_metadata"]

        table_names_public = [t.name for t in public_metadata.tables.values()]
        # PublicDoc should be present
        assert "publicdoc" in table_names_public
        # TenantDoc should NOT be in the public metadata
        assert "tenantdoc" not in table_names_public
