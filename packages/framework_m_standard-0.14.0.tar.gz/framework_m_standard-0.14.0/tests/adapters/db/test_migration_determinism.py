# =============================================================================
# Test: Alembic Determinism
# =============================================================================


from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_standard.adapters.db.migration import MigrationManager


class TestAlembicDeterminism:
    """Tests for Alembic file generation determinism."""

    @patch(
        "framework_m_standard.adapters.db.migration.resolve_app_modules",
        return_value=[],
    )
    def test_determinism_operation_sorting(
        self, mock_resolve: MagicMock, tmp_path: Path
    ) -> None:
        """upgrade() operations and columns should be sorted alphabetically."""
        from sqlalchemy import Column, Integer, MetaData, Table, create_engine

        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        # Target metadata with multiple tables and columns added out of order
        target_metadata = MetaData()
        Table(
            "zeta", target_metadata, Column("z_col", Integer), Column("a_col", Integer)
        )
        Table(
            "alpha", target_metadata, Column("y_col", Integer), Column("b_col", Integer)
        )

        manager.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=False,
            dry_run=False,
            engine=engine,
        )

        # Find the generated revision file
        versions_dir = tmp_path / "alembic" / "versions"
        files = list(versions_dir.glob("*.py"))
        assert len(files) == 1

        content = files[0].read_text()

        # Check column order within alpha (b_col should be generated before y_col)
        alpha_idx = content.find("create_table('alpha'")
        if alpha_idx == -1:
            alpha_idx = content.find('create_table("alpha"')

        zeta_idx = content.find("create_table('zeta'")
        if zeta_idx == -1:
            zeta_idx = content.find('create_table("zeta"')

        b_col_idx = content.find("'b_col'", alpha_idx, zeta_idx)
        if b_col_idx == -1:
            b_col_idx = content.find('"b_col"', alpha_idx, zeta_idx)

        y_col_idx = content.find("'y_col'", alpha_idx, zeta_idx)
        if y_col_idx == -1:
            y_col_idx = content.find('"y_col"', alpha_idx, zeta_idx)

        assert b_col_idx != -1
        assert y_col_idx != -1
        assert b_col_idx < y_col_idx  # b_col should be sorted before y_col

    @patch(
        "framework_m_standard.adapters.db.migration.resolve_app_modules",
        return_value=[],
    )
    def test_determinism_slug_generation(
        self, mock_resolve: MagicMock, tmp_path: Path
    ) -> None:
        """Migration IDs (slugs) should be deterministically generated based on content."""
        from sqlalchemy import Column, Integer, MetaData, Table, create_engine

        target_metadata = MetaData()
        Table("users", target_metadata, Column("id", Integer, primary_key=True))

        # Generate first revision
        db1 = tmp_path / "run1.db"
        manager1 = MigrationManager(
            tmp_path / "run1", database_url=f"sqlite+aiosqlite:///{db1}"
        )
        manager1.init()
        manager1.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=False,
            engine=create_engine(f"sqlite:///{db1}"),
        )
        files1 = list((tmp_path / "run1" / "alembic" / "versions").glob("*.py"))

        # Generate second identical revision in separate manager
        db2 = tmp_path / "run2.db"
        manager2 = MigrationManager(
            tmp_path / "run2", database_url=f"sqlite+aiosqlite:///{db2}"
        )
        manager2.init()
        manager2.auto_migrate(
            target_metadata=target_metadata,
            dev_mode=False,
            engine=create_engine(f"sqlite:///{db2}"),
        )
        files2 = list((tmp_path / "run2" / "alembic" / "versions").glob("*.py"))

        # The revision ID (filename prefix) should be identical because the inputs are identical
        assert files1[0].name == files2[0].name
