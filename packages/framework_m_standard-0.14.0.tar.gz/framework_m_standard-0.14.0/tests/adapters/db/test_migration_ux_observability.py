"""Tests for UX and Observability features of migrations."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from framework_m_standard.adapters.db.schema_detector import (
    SchemaChange,
    SchemaChangeType,
)
from framework_m_standard.cli.migrate import sync_command
from rich.table import Table


class TestUXAndObservability:
    """Tests for color-coded diff outputs and summary tables."""

    @patch("framework_m_standard.cli.migrate.console.print")
    @patch("framework_m_standard.cli.migrate.get_manager")
    @patch("framework_m_core.registry.MetaRegistry.get_instance")
    def test_ux_diff_color_coding(
        self,
        mock_get_instance: MagicMock,
        mock_get_manager: MagicMock,
        mock_print: MagicMock,
    ) -> None:
        """Verify that schema changes are printed with color coding."""
        mock_registry = MagicMock()
        mock_registry.list_doctypes.return_value = []
        mock_get_instance.return_value = mock_registry

        mock_manager = MagicMock()
        mock_get_manager.return_value = mock_manager

        # Mock changes: 1 added, 1 modified, 1 dropped
        changes = [
            SchemaChange(change_type=SchemaChangeType.NEW_TABLE, table_name="users"),
            SchemaChange(
                change_type=SchemaChangeType.TYPE_CHANGE,
                table_name="users",
                column_name="age",
            ),
            SchemaChange(
                change_type=SchemaChangeType.DROPPED_COLUMN,
                table_name="users",
                column_name="old_age",
            ),
        ]
        mock_manager.auto_migrate.return_value = changes

        sync_command(dry_run=True)

        printed_strings = [
            call.args[0]
            for call in mock_print.call_args_list
            if call.args and isinstance(call.args[0], str)
        ]

        assert any("[green]new_table: users[/green]" in s for s in printed_strings)
        assert any(
            "[yellow]type_change: users.age[/yellow]" in s for s in printed_strings
        )
        assert any(
            "[red]dropped_column: users.old_age[/red]" in s for s in printed_strings
        )

    @patch("framework_m_standard.cli.migrate.console.print")
    @patch("framework_m_standard.cli.migrate.get_manager")
    @patch("framework_m_core.registry.MetaRegistry.get_instance")
    def test_ux_sync_summary_table(
        self,
        mock_get_instance: MagicMock,
        mock_get_manager: MagicMock,
        mock_print: MagicMock,
    ) -> None:
        """Verify that a summary table is printed with counts of added, modified, and dropped changes."""
        mock_registry = MagicMock()
        mock_registry.list_doctypes.return_value = []
        mock_get_instance.return_value = mock_registry

        mock_manager = MagicMock()
        mock_get_manager.return_value = mock_manager

        # Mock changes: 2 added, 1 modified, 0 dropped
        changes = [
            SchemaChange(change_type=SchemaChangeType.NEW_TABLE, table_name="table1"),
            SchemaChange(
                change_type=SchemaChangeType.NEW_COLUMN,
                table_name="table1",
                column_name="col1",
            ),
            SchemaChange(
                change_type=SchemaChangeType.TYPE_CHANGE,
                table_name="table2",
                column_name="col2",
            ),
        ]
        mock_manager.auto_migrate.return_value = changes

        sync_command(dry_run=True)

        # Check that a Table was printed
        tables = [
            call.args[0]
            for call in mock_print.call_args_list
            if call.args and isinstance(call.args[0], Table)
        ]
        assert len(tables) == 1

        table = tables[0]
        assert table.title == "Migration Summary"

        counts = list(table.columns[1]._cells)
        assert counts == ["2", "1", "0"]
