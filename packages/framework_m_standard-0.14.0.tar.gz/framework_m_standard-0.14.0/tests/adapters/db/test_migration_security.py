# =============================================================================
# Test: Security & Governance
# =============================================================================


from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.adapters.db.migration import MigrationManager


class TestSecurityAndGovernance:
    """Tests for security and governance features."""

    @patch(
        "framework_m_standard.adapters.db.migration.resolve_app_modules",
        return_value=[],
    )
    @patch("framework_m_standard.adapters.db.migration.DevSyncEngine")
    def test_security_ddl_permission_check(
        self,
        mock_dev_sync_engine_cls: MagicMock,
        mock_resolve: MagicMock,
        tmp_path: Path,
    ) -> None:
        """auto_migrate should fail early if user lacks DDL permissions."""
        from framework_m_standard.adapters.db.exceptions import DDLPermissionDeniedError
        from sqlalchemy import Column, Integer, MetaData, Table, create_engine

        # Simulate DevSyncEngine raising a permission error
        mock_dev_sync_engine_instance = MagicMock()
        mock_dev_sync_engine_instance.sync.side_effect = DDLPermissionDeniedError(
            "DDL permission check failed for postgresql+asyncpg://user:********@host:5432/dbname: Permission denied to execute DDL"
        )
        mock_dev_sync_engine_cls.return_value = mock_dev_sync_engine_instance

        db_path = tmp_path / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")

        manager = MigrationManager(
            tmp_path, database_url=f"sqlite+aiosqlite:///{db_path}"
        )
        manager.init()

        target_metadata = MetaData()
        Table("users", target_metadata, Column("id", Integer, primary_key=True))

        with pytest.raises(
            DDLPermissionDeniedError, match="DDL permission check failed"
        ):
            manager.auto_migrate(
                target_metadata=target_metadata, dev_mode=True, engine=engine
            )

    def test_security_credential_masking(self) -> None:
        """Sensitive credentials in database URL should be masked in logs/exceptions."""
        from framework_m_standard.adapters.db.dev_sync_engine import DevSyncEngine
        from framework_m_standard.adapters.db.exceptions import DDLPermissionDeniedError
        from sqlalchemy import MetaData, create_engine

        dev_engine = DevSyncEngine()
        engine = create_engine(
            "postgresql+asyncpg://user:password123@invalid_host:9999/dbname"
        )
        engine.begin = MagicMock(side_effect=Exception("Simulated connection failure"))

        with pytest.raises(DDLPermissionDeniedError) as excinfo:
            dev_engine.sync(MetaData(), [], engine)

        assert "password123" not in str(excinfo.value)
        assert "********" in str(excinfo.value)
