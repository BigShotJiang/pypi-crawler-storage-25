"""Tests for MigrationManager."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_standard.adapters.db.migration import MigrationManager

# =============================================================================
# Test: MigrationManager Creation
# =============================================================================


class TestMigrationManagerCreation:
    """Tests for MigrationManager instantiation."""

    def test_create_migration_manager(self) -> None:
        """MigrationManager should be creatable with base path."""
        manager = MigrationManager("/tmp/test")  # nosec B108
        assert manager is not None

    def test_create_with_database_url(self) -> None:
        """MigrationManager should accept database URL."""
        manager = MigrationManager(
            "/tmp/test", database_url="sqlite+aiosqlite:///test.db"
        )  # nosec B108
        assert manager._database_url == "sqlite+aiosqlite:///test.db"

    def test_create_with_version_table(self) -> None:
        """MigrationManager should accept version_table and set it in config."""
        manager = MigrationManager("/tmp/test", version_table="custom_version_table")  # nosec B108
        assert manager.config.get_main_option("version_table") == "custom_version_table"

    def test_create_with_x_args(self) -> None:
        """MigrationManager should accept x_args and make them available in config cmd_opts."""
        manager = MigrationManager("/tmp/test", x_args=("tenant=acme", "dry_run=True"))  # nosec B108

        cmd_opts = getattr(manager.config, "cmd_opts", None)
        assert cmd_opts is not None
        assert getattr(cmd_opts, "x", None) == ["tenant=acme", "dry_run=True"]


# =============================================================================
# Test: Initialization
# =============================================================================


class TestMigrationManagerInit:
    """Tests for MigrationManager initialization."""

    def test_init_creates_alembic_directory(self, tmp_path: Path) -> None:
        """init() should create alembic directory."""
        manager = MigrationManager(tmp_path)
        manager.init()

        assert (tmp_path / "alembic").exists()
        assert (tmp_path / "alembic").is_dir()

    def test_init_creates_versions_directory(self, tmp_path: Path) -> None:
        """init() should create versions directory."""
        manager = MigrationManager(tmp_path)
        manager.init()

        assert (tmp_path / "alembic" / "versions").exists()
        assert (tmp_path / "alembic" / "versions").is_dir()

    def test_init_creates_alembic_ini(self, tmp_path: Path) -> None:
        """init() should create alembic.ini file."""
        manager = MigrationManager(tmp_path)
        manager.init()

        ini_path = tmp_path / "alembic.ini"
        assert ini_path.exists()
        assert "script_location = alembic" in ini_path.read_text()

    def test_init_creates_env_py(self, tmp_path: Path) -> None:
        """init() should create env.py with async support."""
        manager = MigrationManager(tmp_path)
        manager.init()

        env_path = tmp_path / "alembic" / "env.py"
        assert env_path.exists()

        content = env_path.read_text()
        assert "async_engine_from_config" in content
        assert "run_async_migrations" in content

    def test_init_creates_script_template(self, tmp_path: Path) -> None:
        """init() should create script.py.mako template."""
        manager = MigrationManager(tmp_path)
        manager.init()

        template_path = tmp_path / "alembic" / "script.py.mako"
        assert template_path.exists()
        assert "upgrade()" in template_path.read_text()

    def test_init_is_idempotent(self, tmp_path: Path) -> None:
        """init() should not overwrite existing files."""
        manager = MigrationManager(tmp_path)
        manager.init()

        ini_path = tmp_path / "alembic.ini"
        original_content = ini_path.read_text()

        # Add custom content
        ini_path.write_text(original_content + "\n# custom")

        # Run init again
        manager.init()

        # Custom content should still be there
        assert "# custom" in ini_path.read_text()

    def test_init_enables_sqlite_batch_mode(self, tmp_path: Path) -> None:
        """init() should create env.py with render_as_batch=True for sqlite."""
        manager = MigrationManager(tmp_path)
        manager.init()

        env_path = tmp_path / "alembic" / "env.py"
        content = env_path.read_text()

        assert "render_as_batch=is_sqlite" in content  # Offline mode
        assert 'render_as_batch=connection.dialect.name == "sqlite"' in content


# =============================================================================
# Test: Properties
# =============================================================================


class TestMigrationManagerProperties:
    """Tests for MigrationManager properties."""

    def test_alembic_path_property(self, tmp_path: Path) -> None:
        """alembic_path should return correct path."""
        manager = MigrationManager(tmp_path)
        assert manager.alembic_path == tmp_path / "alembic"

    def test_versions_path_property(self, tmp_path: Path) -> None:
        """versions_path should return correct path."""
        manager = MigrationManager(tmp_path)
        assert manager.versions_path == tmp_path / "alembic" / "versions"


# =============================================================================
# Test: Import
# =============================================================================


class TestMigrationImport:
    """Tests for migration module imports."""

    def test_import_migration_manager(self) -> None:
        """MigrationManager should be importable."""
        from framework_m_standard.adapters.db.migration import MigrationManager

        assert MigrationManager is not None

    def test_import_schema_change(self) -> None:
        """SchemaChange should be importable."""
        from framework_m_standard.adapters.db.migration import (
            SchemaChange,
        )
        from framework_m_standard.adapters.db.schema_detector import (
            SchemaChangeType,
        )

        assert SchemaChange is not None
        assert SchemaChangeType is not None


# =============================================================================
# Test: Config Creation
# =============================================================================


class TestConfigCreation:
    """Tests for config creation and properties."""

    def test_config_property_creates_on_demand(self, tmp_path: Path) -> None:
        """config property should create config on first access."""
        manager = MigrationManager(tmp_path, database_url="sqlite+aiosqlite:///test.db")
        manager.init()

        config = manager.config
        assert config is not None

    def test_config_sets_database_url(self, tmp_path: Path) -> None:
        """config should have database URL set."""
        manager = MigrationManager(tmp_path, database_url="sqlite+aiosqlite:///test.db")
        manager.init()

        config = manager.config
        assert "sqlite" in config.get_main_option("sqlalchemy.url")

    @patch("importlib.metadata.entry_points")
    @patch("importlib.util.find_spec")
    def test_config_discovers_versions_via_entry_points(
        self, mock_find_spec: MagicMock, mock_entry_points: MagicMock, tmp_path: Path
    ) -> None:
        """config should discover version locations via framework_m.apps entry points."""
        # Setup fake entry point simulating an installed app
        mock_ep = MagicMock()
        mock_ep.name = "my_plugin_app"
        mock_ep.value = "my_plugin_app.plugin:app"

        # Simulate entry_points() returning our plugin under the framework_m.apps group
        mock_entry_points.return_value = {"framework_m.apps": [mock_ep]}

        # Setup fake module spec
        app_path = tmp_path / "my_plugin_app"
        app_path.mkdir()
        app_versions = app_path / "alembic" / "versions"
        app_versions.mkdir(parents=True)

        mock_spec = MagicMock()
        mock_spec.origin = str(app_path / "__init__.py")
        mock_find_spec.return_value = mock_spec

        manager = MigrationManager(
            tmp_path, database_url="sqlite+aiosqlite:///:memory:"
        )
        manager.init()

        config = manager.config
        locations = config.get_main_option("version_locations")

        assert locations is not None
        assert str(app_versions) in locations

    @patch("os.environ.get")
    @patch("importlib.util.find_spec")
    def test_config_uses_custom_app_migrations_dir(
        self, mock_find_spec: MagicMock, mock_environ_get: MagicMock, tmp_path: Path
    ) -> None:
        """config should use custom migrations/ directory if present instead of alembic/versions."""
        mock_environ_get.return_value = "custom_app"

        app_path = tmp_path / "custom_app"
        app_path.mkdir()

        # Create a 'migrations' dir instead of 'alembic/versions'
        app_versions = app_path / "migrations"
        app_versions.mkdir(parents=True)

        mock_spec = MagicMock()
        mock_spec.origin = str(app_path / "__init__.py")
        mock_find_spec.return_value = mock_spec

        manager = MigrationManager(
            tmp_path, database_url="sqlite+aiosqlite:///:memory:"
        )
        config = manager.config
        locations = config.get_main_option("version_locations")

        assert locations is not None
        assert str(app_versions) in locations


# =============================================================================
# Test: Migration Commands
# =============================================================================


class TestMigrationCommands:
    """Tests for Alembic wrapper commands in MigrationManager."""

    @patch("alembic.command.upgrade")
    def test_upgrade(self, mock_upgrade: MagicMock, tmp_path: Path) -> None:
        """upgrade() should delegate to alembic.command.upgrade."""
        manager = MigrationManager(tmp_path)
        manager.init()
        manager.upgrade("head")
        mock_upgrade.assert_called_once_with(manager.config, "head")

    @patch("alembic.command.downgrade")
    def test_downgrade(self, mock_downgrade: MagicMock, tmp_path: Path) -> None:
        """downgrade() should delegate to alembic.command.downgrade."""
        manager = MigrationManager(tmp_path)
        manager.init()
        manager.downgrade("-1")
        mock_downgrade.assert_called_once_with(manager.config, "-1")

    @patch("alembic.command.history")
    def test_history(self, mock_history: MagicMock, tmp_path: Path) -> None:
        """history() should delegate to alembic.command.history."""
        manager = MigrationManager(tmp_path)
        manager.init()
        manager.history()
        mock_history.assert_called_once_with(manager.config)

    @patch("alembic.command.current")
    def test_current(self, mock_current: MagicMock, tmp_path: Path) -> None:
        """current() should delegate to alembic.command.current."""
        manager = MigrationManager(tmp_path)
        manager.init()
        manager.current()
        mock_current.assert_called_once_with(manager.config)

    @patch("alembic.script.ScriptDirectory")
    def test_migrate_merge_head_detection(
        self, mock_script_dir: MagicMock, tmp_path: Path
    ) -> None:
        """has_multiple_heads() should return True if > 1 head exists."""
        mock_script = MagicMock()
        mock_script.get_heads.return_value = ["head1", "head2"]
        mock_script_dir.from_config.return_value = mock_script

        manager = MigrationManager(tmp_path)
        manager.init()
        assert manager.has_multiple_heads() is True

        mock_script.get_heads.return_value = ["head1"]
        assert manager.has_multiple_heads() is False

    @patch("alembic.command.merge")
    def test_migrate_merge_command_resolution(
        self, mock_merge: MagicMock, tmp_path: Path
    ) -> None:
        """merge() should delegate to alembic.command.merge."""
        manager = MigrationManager(tmp_path)
        manager.init()
        manager.merge(revisions=["head1", "head2"], message="Merge branches")
        mock_merge.assert_called_once_with(
            manager.config, revisions=["head1", "head2"], message="Merge branches"
        )
