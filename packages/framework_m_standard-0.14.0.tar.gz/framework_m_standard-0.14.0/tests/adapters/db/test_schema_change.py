"""Tests for SchemaChange dataclass."""

from __future__ import annotations

from framework_m_standard.adapters.db.migration import (
    SchemaChange,
)
from framework_m_standard.adapters.db.schema_detector import SchemaChangeType


class TestSchemaChange:
    """Tests for SchemaChange dataclass."""

    def test_schema_change_creation(self) -> None:
        """SchemaChange should be creatable with required fields."""
        change = SchemaChange(
            change_type=SchemaChangeType.NEW_TABLE,
            table_name="users",
        )

        assert change.change_type == SchemaChangeType.NEW_TABLE
        assert change.table_name == "users"
        assert change.column_name is None

    def test_schema_change_with_column(self) -> None:
        """SchemaChange should support column information."""
        change = SchemaChange(
            change_type=SchemaChangeType.NEW_COLUMN,
            table_name="users",
            column_name="email",
        )

        assert change.column_name == "email"


class TestSchemaChangeDetails:
    """Tests for SchemaChange details field."""

    def test_schema_change_with_details(self) -> None:
        """SchemaChange should support details field."""
        change = SchemaChange(
            change_type=SchemaChangeType.TYPE_CHANGE,
            table_name="users",
            column_name="age",
            old_type="VARCHAR(10)",
            new_type="INTEGER",
            details={"reason": "schema update"},
        )

        assert change.old_type == "VARCHAR(10)"
        assert change.new_type == "INTEGER"
        assert change.details["reason"] == "schema update"
