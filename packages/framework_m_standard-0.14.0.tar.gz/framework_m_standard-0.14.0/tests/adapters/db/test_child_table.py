"""Tests for ChildTableManager.

TDD tests for extracting Child Table logic out of the GenericRepository.
"""

from __future__ import annotations

from typing import ClassVar
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_standard.adapters.db.child_table import ChildTableManager
from sqlalchemy import Column, Integer, MetaData, String, Table
from sqlalchemy.types import UUID as SA_UUID

# =============================================================================
# Test Models
# =============================================================================


class MockChild(BaseDocType):
    """Child DocType for testing."""

    content: str

    class Meta:
        is_child: ClassVar[bool] = True


class MockNotChild(BaseDocType):
    """Not a child DocType (missing is_child flag)."""

    content: str


class MockParent(BaseDocType):
    """Parent DocType for testing."""

    title: str = Field(default="Test Parent")
    children: list[MockChild] = Field(default_factory=list)
    not_children: list[MockNotChild] = Field(default_factory=list)


class MockJsonChild(BaseDocType):
    """Child DocType with JSON field for testing."""

    content: str
    custom_data: dict[str, str] = Field(
        default_factory=dict, json_schema_extra={"persistence": "json"}
    )

    class Meta:
        is_child: ClassVar[bool] = True


class MockJsonParent(BaseDocType):
    """Parent DocType with JSON child for testing."""

    json_children: list[MockJsonChild] = Field(default_factory=list)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def child_table() -> Table:
    metadata = MetaData()
    return Table(
        "mockchild",
        metadata,
        Column("id", SA_UUID, primary_key=True),
        Column("name", String, unique=True),
        Column("content", String),
        Column("parent", String),
        Column("parenttype", String),
        Column("idx", Integer),
    )


@pytest.fixture
def mock_session() -> AsyncMock:
    return AsyncMock()


# =============================================================================
# Tests
# =============================================================================


class TestChildTableManager:
    """Tests for ChildTableManager."""

    def test_get_child_table_fields(self) -> None:
        """Should correctly identify list[DocType] fields with Meta.is_child=True."""
        manager = ChildTableManager(MockParent)
        fields = manager.get_child_table_fields()

        assert "children" in fields
        assert fields["children"] is MockChild
        assert "not_children" not in fields

    def test_get_child_table_fields_no_annotation(self) -> None:
        """Should skip fields without annotations."""
        manager = ChildTableManager(MockParent)
        mock_field = MagicMock()
        mock_field.annotation = None

        with patch.object(MockParent, "model_fields", {"bad_field": mock_field}):
            fields = manager.get_child_table_fields()
            assert "bad_field" not in fields

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_save_child_tables(
        self,
        mock_get_table: MagicMock,
        child_table: Table,
        mock_session: AsyncMock,
    ) -> None:
        """Should format child data and insert into child tables."""
        # Setup mock TableRegistry return
        mock_get_table.return_value = child_table

        parent_id = uuid4()
        parent = MockParent(id=parent_id)
        parent.children = [
            MockChild(content="Child 1"),
            MockChild(content="Child 2"),
        ]

        manager = ChildTableManager(MockParent)
        fields = manager.get_child_table_fields()
        await manager.save_child_tables(mock_session, parent, fields)

        # session.execute should be called twice (once for each child)
        assert mock_session.execute.call_count == 2

        # Inspect the first insert statement values
        call_args = mock_session.execute.call_args_list[0]
        stmt = call_args.args[0]
        values = {
            getattr(column, "key", column): getattr(bind, "value", bind)
            for column, bind in stmt._values.items()
        }

        assert values["content"] == "Child 1"
        assert values["parent"] == str(parent_id)
        assert values["parenttype"] == "MockParent"
        assert values["idx"] == 1

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_save_child_tables_empty(
        self, mock_get_table: MagicMock, child_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should do nothing if children list is empty."""
        mock_get_table.return_value = child_table
        parent = MockParent(id=uuid4())
        parent.children = []

        manager = ChildTableManager(MockParent)
        await manager.save_child_tables(mock_session, parent, {"children": MockChild})

        mock_session.execute.assert_not_called()

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_save_child_tables_missing_table(
        self, mock_get_table: MagicMock, mock_session: AsyncMock
    ) -> None:
        """Should skip if table is not found in registry."""
        mock_get_table.return_value = None
        parent = MockParent(id=uuid4())
        parent.children = [MockChild(content="A")]

        manager = ChildTableManager(MockParent)
        await manager.save_child_tables(mock_session, parent, {"children": MockChild})

        mock_session.execute.assert_not_called()

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_save_child_tables_table_not_found(
        self, mock_get_table: MagicMock, mock_session: AsyncMock
    ) -> None:
        """Should skip if TableNotFoundError is raised by registry."""
        from framework_m_standard.adapters.db.table_registry import TableNotFoundError

        mock_get_table.side_effect = TableNotFoundError("Not found")
        parent = MockParent(id=uuid4())
        parent.children = [MockChild(content="A")]

        manager = ChildTableManager(MockParent)
        await manager.save_child_tables(mock_session, parent, {"children": MockChild})

        mock_session.execute.assert_not_called()

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_save_child_tables_json_fields(
        self, mock_get_table: MagicMock, mock_session: AsyncMock
    ) -> None:
        """Should pack JSON fields correctly into custom_fields column."""
        mock_table = MagicMock()
        mock_get_table.return_value = mock_table

        parent = MockJsonParent(id=uuid4())
        parent.json_children = [MockJsonChild(content="B", custom_data={"key": "val"})]

        manager = ChildTableManager(MockJsonParent)
        await manager.save_child_tables(
            mock_session, parent, {"json_children": MockJsonChild}
        )

        mock_table.insert.assert_called_once()
        call_args = mock_table.insert.return_value.values.call_args
        kwargs = call_args.kwargs
        assert "custom_fields" in kwargs
        assert kwargs["custom_fields"]["custom_data"] == {"key": "val"}

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_delete_child_tables(
        self,
        mock_get_table: MagicMock,
        child_table: Table,
        mock_session: AsyncMock,
    ) -> None:
        """Should delete records from child tables matching parent ID."""
        mock_get_table.return_value = child_table
        parent_id = uuid4()

        manager = ChildTableManager(MockParent)
        fields = manager.get_child_table_fields()
        await manager.delete_child_tables(mock_session, parent_id, fields)

        assert mock_session.execute.call_count == 1
        stmt = mock_session.execute.call_args.args[0]
        assert "DELETE" in str(stmt)
        assert "parent = :parent_1" in str(stmt)

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_delete_child_tables_missing_table(
        self, mock_get_table: MagicMock, mock_session: AsyncMock
    ) -> None:
        """Should skip delete if table is not found in registry."""
        mock_get_table.return_value = None

        manager = ChildTableManager(MockParent)
        await manager.delete_child_tables(
            mock_session, uuid4(), {"children": MockChild}
        )

        mock_session.execute.assert_not_called()

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_delete_child_tables_table_not_found(
        self, mock_get_table: MagicMock, mock_session: AsyncMock
    ) -> None:
        """Should skip delete if TableNotFoundError is raised by registry."""
        from framework_m_standard.adapters.db.table_registry import TableNotFoundError

        mock_get_table.side_effect = TableNotFoundError("Not found")

        manager = ChildTableManager(MockParent)
        await manager.delete_child_tables(
            mock_session, uuid4(), {"children": MockChild}
        )

        mock_session.execute.assert_not_called()

    @pytest.mark.asyncio
    @patch(
        "framework_m_standard.adapters.db.child_table.ChildTableManager.load_children_for_parents"
    )
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_load_child_tables(
        self,
        mock_get_table: MagicMock,
        mock_load_children: AsyncMock,
        child_table: Table,
        mock_session: AsyncMock,
    ) -> None:
        """Should populate child records directly onto the parent entity."""
        mock_get_table.return_value = child_table

        parent_id = uuid4()
        parent = MockParent(id=parent_id)
        child_instance = MockChild(content="Loaded Child")

        mock_load_children.return_value = {str(parent_id): [child_instance]}

        manager = ChildTableManager(MockParent)
        fields = manager.get_child_table_fields()
        await manager.load_child_tables(mock_session, parent, fields)

        assert len(parent.children) == 1
        assert parent.children[0].content == "Loaded Child"

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_load_child_tables_missing_table(
        self, mock_get_table: MagicMock, mock_session: AsyncMock
    ) -> None:
        """Should skip loading if table is not found in registry."""
        mock_get_table.return_value = None
        parent = MockParent(id=uuid4())
        manager = ChildTableManager(MockParent)

        await manager.load_child_tables(mock_session, parent, {"children": MockChild})
        assert len(parent.children) == 0

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_load_child_tables_table_not_found(
        self, mock_get_table: MagicMock, mock_session: AsyncMock
    ) -> None:
        """Should skip loading if TableNotFoundError is raised by registry."""
        from framework_m_standard.adapters.db.table_registry import TableNotFoundError

        mock_get_table.side_effect = TableNotFoundError("Not found")
        parent = MockParent(id=uuid4())
        manager = ChildTableManager(MockParent)

        await manager.load_child_tables(mock_session, parent, {"children": MockChild})
        assert len(parent.children) == 0

    @pytest.mark.asyncio
    async def test_load_children_for_parents(
        self,
        child_table: Table,
        mock_session: AsyncMock,
    ) -> None:
        """Should map raw child rows back to correct parents via IN query."""
        parent1_id = uuid4()
        parent2_id = uuid4()

        # Mock DB rows returned
        mock_row_1 = MagicMock()
        mock_row_1._mapping = {
            "content": "Child A",
            "parent": str(parent1_id),
            "idx": 1,
        }

        mock_row_2 = MagicMock()
        mock_row_2._mapping = {
            "content": "Child B",
            "parent": str(parent2_id),
            "idx": 1,
        }

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row_1, mock_row_2]
        mock_session.execute.return_value = mock_result

        manager = ChildTableManager(MockParent)
        result = await manager.load_children_for_parents(
            mock_session,
            [parent1_id, parent2_id],
            child_table,
            MockChild,
        )

        assert str(parent1_id) in result
        assert str(parent2_id) in result
        assert len(result[str(parent1_id)]) == 1
        assert result[str(parent1_id)][0].content == "Child A"
        assert isinstance(result[str(parent1_id)][0], MockChild)

    @pytest.mark.asyncio
    async def test_load_children_for_parents_missing_parent_in_row(
        self, child_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should ignore rows with no parent ID."""
        mock_row = MagicMock()
        mock_row._mapping = {"content": "Orphan", "parent": None, "idx": 1}

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row]
        mock_session.execute.return_value = mock_result

        manager = ChildTableManager(MockParent)
        result = await manager.load_children_for_parents(
            mock_session, [uuid4()], child_table, MockChild
        )

        assert len(result) == 0
