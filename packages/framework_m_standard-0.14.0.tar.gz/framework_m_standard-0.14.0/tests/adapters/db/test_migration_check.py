"""Tests for MigrationStatusUtility.

TDD tests for checking database migration readiness, particularly for
Zero Downtime Migration (ZDM) scenarios.
"""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.adapters.db.migration import SchemaChange
from framework_m_standard.adapters.db.migration_check import MigrationStatusUtility
from framework_m_standard.adapters.db.schema_detector import SchemaChangeType


class TestMigrationStatusUtility:
    """Tests for MigrationStatusUtility."""

    @pytest.fixture
    def mock_engine(self) -> AsyncMock:
        """Mock SQLAlchemy AsyncEngine."""
        return AsyncMock()

    @pytest.mark.asyncio
    async def test_is_up_to_date_true_when_all_applied(
        self, mock_engine: AsyncMock
    ) -> None:
        """is_up_to_date() should return True when Alembic is at head."""
        utility = MigrationStatusUtility(engine=mock_engine)

        with (
            patch.object(utility, "_is_alembic_up_to_date", return_value=True),
            patch.object(
                utility, "_has_breaking_declarative_changes", return_value=False
            ),
        ):
            assert await utility.is_up_to_date() is True

    @pytest.mark.asyncio
    async def test_is_up_to_date_false_when_alembic_behind(
        self, mock_engine: AsyncMock
    ) -> None:
        """is_up_to_date() should return False if Phase 1 (Alembic) is missing."""
        utility = MigrationStatusUtility(engine=mock_engine)

        with patch.object(utility, "_is_alembic_up_to_date", return_value=False):
            assert await utility.is_up_to_date() is False

    @pytest.mark.asyncio
    async def test_graceful_sync_ignores_non_breaking_changes(
        self, mock_engine: AsyncMock
    ) -> None:
        """Graceful sync should allow pod readiness if declarative changes are non-breaking."""
        utility = MigrationStatusUtility(engine=mock_engine)

        with (
            patch.object(utility, "_is_alembic_up_to_date", return_value=True),
            patch.object(
                utility, "_has_breaking_declarative_changes", return_value=False
            ),
        ):
            # Even with pending non-breaking declarative changes, it should report True
            assert await utility.is_up_to_date(graceful_sync=True) is True

    @pytest.mark.asyncio
    async def test_graceful_sync_fails_on_breaking_changes(
        self, mock_engine: AsyncMock
    ) -> None:
        """Graceful sync should return False if declarative changes are breaking."""
        utility = MigrationStatusUtility(engine=mock_engine)

        with (
            patch.object(utility, "_is_alembic_up_to_date", return_value=True),
            patch.object(
                utility, "_has_breaking_declarative_changes", return_value=True
            ),
        ):
            assert await utility.is_up_to_date(graceful_sync=True) is False

    @pytest.mark.asyncio
    async def test_zdm_aware_with_env_var(
        self, mock_engine: AsyncMock, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Support CHECK_DECLARATIVE_SYNC=False env var for ZDM scenarios."""
        monkeypatch.setenv("CHECK_DECLARATIVE_SYNC", "False")
        utility = MigrationStatusUtility(engine=mock_engine)

        with (
            patch.object(utility, "_is_alembic_up_to_date", return_value=True),
            patch.object(
                utility,
                "_has_breaking_declarative_changes",
                side_effect=Exception("Should not be called"),
            ),
        ):
            assert await utility.is_up_to_date() is True


class TestMigrationStatusUtilityInternalMethods:
    """Tests for the actual internal DB checking logic."""

    @pytest.fixture
    def mock_engine(self) -> MagicMock:
        """Mock AsyncEngine with a synchronous run_sync side effect."""
        engine = MagicMock()
        conn = AsyncMock()

        # mock conn.run_sync to just call the function directly to test the sync callbacks
        async def run_sync_mock(fn, *args, **kwargs):
            return fn(MagicMock(), *args, **kwargs)

        conn.run_sync.side_effect = run_sync_mock
        ctx = AsyncMock()
        ctx.__aenter__.return_value = conn
        engine.connect.return_value = ctx
        return engine

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.migration_check.ScriptDirectory")
    @patch("framework_m_standard.adapters.db.migration_check.MigrationContext")
    async def test_is_alembic_up_to_date_true(
        self, mock_ctx, mock_script, mock_engine: MagicMock
    ) -> None:
        from framework_m_core.container import Container

        mock_ctx.configure.return_value.get_current_heads.return_value = ("head1",)
        mock_script.from_config.return_value.get_heads.return_value = ("head1",)

        with Container.migration_manager.override(MagicMock()):
            utility = MigrationStatusUtility(engine=mock_engine)
            assert await utility._is_alembic_up_to_date() is True

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.migration_check.ScriptDirectory")
    @patch("framework_m_standard.adapters.db.migration_check.MigrationContext")
    async def test_is_alembic_up_to_date_false(
        self, mock_ctx, mock_script, mock_engine: MagicMock
    ) -> None:
        from framework_m_core.container import Container

        mock_ctx.configure.return_value.get_current_heads.return_value = ()
        mock_script.from_config.return_value.get_heads.return_value = ("head1",)

        with Container.migration_manager.override(MagicMock()):
            utility = MigrationStatusUtility(engine=mock_engine)
            assert await utility._is_alembic_up_to_date() is False

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.migration_check.MetaData")
    async def test_has_breaking_declarative_changes_true(
        self, mock_metadata, mock_engine: MagicMock
    ) -> None:
        from framework_m_core.container import Container

        mock_mgr = MagicMock()
        mock_mgr.detect_schema_changes.return_value = [
            SchemaChange(change_type=SchemaChangeType.DROPPED_COLUMN, table_name="test")
        ]

        with (
            Container.migration_manager.override(mock_mgr),
            Container.schema_mapper.override(MagicMock()),
        ):
            utility = MigrationStatusUtility(engine=mock_engine)
            assert await utility._has_breaking_declarative_changes() is True

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.migration_check.MetaData")
    async def test_has_breaking_declarative_changes_false(
        self, mock_metadata, mock_engine: MagicMock
    ) -> None:
        from framework_m_core.container import Container

        mock_mgr = MagicMock()
        mock_mgr.detect_schema_changes.return_value = [
            SchemaChange(change_type=SchemaChangeType.NEW_COLUMN, table_name="test")
        ]

        with (
            Container.migration_manager.override(mock_mgr),
            Container.schema_mapper.override(MagicMock()),
        ):
            utility = MigrationStatusUtility(engine=mock_engine)
            assert await utility._has_breaking_declarative_changes() is False
