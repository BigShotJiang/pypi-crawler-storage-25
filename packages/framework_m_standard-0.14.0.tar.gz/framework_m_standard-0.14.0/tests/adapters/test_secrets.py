"""Tests for Secrets Management (Step 2.4)."""

import os
from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.container import Container
from framework_m_core.services.secrets_service import SecretsManager
from framework_m_standard.adapters.secrets.env_secret import EnvSecretAdapter
from framework_m_standard.adapters.web.app import create_app


def test_env_secret_adapter():
    """Verify EnvSecretAdapter reads from environment."""
    adapter = EnvSecretAdapter()
    os.environ["TEST_SECRET_KEY"] = "super-secret"
    try:
        assert adapter.get_secret("TEST_SECRET_KEY") == "super-secret"
        assert adapter.get_secret("NON_EXISTENT_KEY", "default") == "default"
    finally:
        del os.environ["TEST_SECRET_KEY"]


def test_secrets_manager_validation():
    """Verify SecretsManager validate() method."""
    mock_adapter = MagicMock()
    mock_adapter.get_secret.side_effect = lambda k, d=None: (
        "val" if k == "FOUND" else None
    )

    manager = SecretsManager(adapter=mock_adapter)

    # Should pass
    manager.validate(["FOUND"])

    # Should raise RuntimeError
    with pytest.raises(RuntimeError) as excinfo:
        manager.validate(["FOUND", "MISSING"])

    assert "Missing required secrets: MISSING" in str(excinfo.value)


def test_container_integration():
    """Verify that Container provides SecretsManager with EnvSecretAdapter."""
    container = Container()
    manager = container.secrets_manager()

    assert isinstance(manager, SecretsManager)
    # The adapter should be an instance of EnvSecretAdapter (loaded via string)
    assert manager._adapter.__class__.__name__ == "EnvSecretAdapter"


def test_app_fail_fast_validation():
    """Verify that app fails to start in production if secrets are missing."""
    # Mock M_DEV_MODE to "false" to simulate production
    # And mock load_env to prevent it from re-loading real .env files
    with (
        patch("framework_m_standard.adapters.web.app.load_env"),
        patch.dict(os.environ, {"M_DEV_MODE": "false"}, clear=True),
    ):
        # FRAMEWORK_M_JWT_SECRET is missing
        with pytest.raises(RuntimeError) as excinfo:
            create_app()

        assert "Missing required secrets: FRAMEWORK_M_JWT_SECRET" in str(excinfo.value)


def test_app_uses_secrets_manager_for_config():
    """Verify that app uses SecretsManager to fetch config."""
    with (
        patch("framework_m_standard.adapters.web.app.load_env"),
        patch.dict(
            os.environ, {"FRAMEWORK_M_JWT_SECRET": "custom-secret-from-env"}, clear=True
        ),
    ):
        app = create_app(serve_static=False)
        assert app.state.jwt_secret == "custom-secret-from-env"
        assert hasattr(app.state, "secrets_manager")
        assert isinstance(app.state.secrets_manager, SecretsManager)
