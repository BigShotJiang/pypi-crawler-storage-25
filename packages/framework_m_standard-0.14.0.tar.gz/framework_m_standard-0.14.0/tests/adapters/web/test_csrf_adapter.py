"""Tests for the DefaultCSRFAdapter."""

import pytest
from framework_m_standard.adapters.web.middleware.csrf import DefaultCSRFAdapter
from framework_m_standard.interfaces.web import WebRequestInfo


@pytest.fixture
def csrf_adapter() -> DefaultCSRFAdapter:
    """Provides a DefaultCSRFAdapter with a standard allowed origin."""
    return DefaultCSRFAdapter(allowed_origins=["https://app.example.com"])


@pytest.mark.asyncio
class TestDefaultCSRFAdapter:
    """Test suite for the default CSRF adapter logic."""

    @pytest.mark.parametrize("method", ["GET", "HEAD", "OPTIONS", "TRACE"])
    async def test_safe_methods_are_bypassed(
        self, csrf_adapter: DefaultCSRFAdapter, method: str
    ) -> None:
        """CSRF validation should be skipped for safe HTTP methods."""
        request_info = WebRequestInfo(
            method=method,
            path="/api/data",
            is_session_auth=True,
            origin="https://evil.com",  # A malicious origin
        )
        assert await csrf_adapter.validate_request(request_info) is True

    async def test_non_session_auth_is_bypassed(
        self, csrf_adapter: DefaultCSRFAdapter
    ) -> None:
        """CSRF validation should be skipped for non-cookie/session auth (e.g., JWT)."""
        request_info = WebRequestInfo(
            method="POST",
            path="/api/data",
            is_session_auth=False,  # API Key or JWT Bearer token auth
            origin="https://evil.com",
        )
        assert await csrf_adapter.validate_request(request_info) is True

    async def test_session_auth_with_allowed_origin_is_valid(
        self, csrf_adapter: DefaultCSRFAdapter
    ) -> None:
        """A request with a valid Origin header should pass."""
        request_info = WebRequestInfo(
            method="POST",
            path="/api/data",
            is_session_auth=True,
            origin="https://app.example.com",
        )
        assert await csrf_adapter.validate_request(request_info) is True

    async def test_session_auth_with_allowed_referer_is_valid(
        self, csrf_adapter: DefaultCSRFAdapter
    ) -> None:
        """A request with a valid Referer header should pass as a fallback."""
        request_info = WebRequestInfo(
            method="POST",
            path="/api/data",
            is_session_auth=True,
            origin=None,  # Origin header might be missing on older browsers
            referer="https://app.example.com/some/page",
        )
        assert await csrf_adapter.validate_request(request_info) is True

    async def test_session_auth_with_disallowed_origin_is_invalid(
        self, csrf_adapter: DefaultCSRFAdapter
    ) -> None:
        """A request from a disallowed origin should be rejected."""
        request_info = WebRequestInfo(
            method="POST",
            path="/api/data",
            is_session_auth=True,
            origin="https://evil.com",
        )
        assert await csrf_adapter.validate_request(request_info) is False

    async def test_session_auth_with_disallowed_referer_is_invalid(
        self, csrf_adapter: DefaultCSRFAdapter
    ) -> None:
        """A request from a disallowed referer should be rejected."""
        request_info = WebRequestInfo(
            method="POST",
            path="/api/data",
            is_session_auth=True,
            origin=None,
            referer="https://evil.com/some/page",
        )
        assert await csrf_adapter.validate_request(request_info) is False

    async def test_session_auth_with_no_origin_or_referer_is_invalid(
        self, csrf_adapter: DefaultCSRFAdapter
    ) -> None:
        """A state-changing request from a browser must have an Origin or Referer."""
        request_info = WebRequestInfo(
            method="POST",
            path="/api/data",
            is_session_auth=True,
            origin=None,
            referer=None,
        )
        assert await csrf_adapter.validate_request(request_info) is False
