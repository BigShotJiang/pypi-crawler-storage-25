"""Tests for Litestar CSRF Middleware."""

from framework_m_standard.adapters.web.middleware.csrf import CSRFMiddlewareFactory
from framework_m_standard.interfaces.web import CSRFProtocol, WebRequestInfo
from litestar import Litestar, post
from litestar.status_codes import HTTP_201_CREATED, HTTP_403_FORBIDDEN
from litestar.testing import TestClient


class MockCSRFAdapter(CSRFProtocol):
    """Mock adapter to isolate middleware testing."""

    def __init__(self, allow: bool) -> None:
        self.allow = allow
        self.last_info: WebRequestInfo | None = None

    async def validate_request(self, request_info: WebRequestInfo) -> bool:
        self.last_info = request_info
        return self.allow


@post("/mutate")
async def mutate_handler() -> dict[str, str]:
    return {"status": "ok"}


def test_csrf_middleware_blocks_invalid_request() -> None:
    """Middleware should return 403 Forbidden when adapter returns False."""
    adapter = MockCSRFAdapter(allow=False)
    app = Litestar(
        route_handlers=[mutate_handler],
        middleware=[CSRFMiddlewareFactory(adapter)],
    )

    with TestClient(app) as client:
        response = client.post("/mutate", headers={"Origin": "https://evil.com"})

        assert response.status_code == HTTP_403_FORBIDDEN
        assert response.json()["detail"] == "CSRF validation failed"


def test_csrf_middleware_maps_request_info_correctly() -> None:
    """Middleware should correctly map Litestar Request to WebRequestInfo."""
    adapter = MockCSRFAdapter(allow=True)
    app = Litestar(
        route_handlers=[mutate_handler],
        middleware=[CSRFMiddlewareFactory(adapter)],
    )

    with TestClient(app) as client:
        response = client.post(
            "/mutate",
            headers={
                "Origin": "https://app.example.com",
                "Referer": "https://app.example.com/page",
            },
            cookies={"session_id": "abc123xyz"},
        )

        assert response.status_code == HTTP_201_CREATED
        assert adapter.last_info is not None
        assert adapter.last_info.method == "POST"
        assert adapter.last_info.path == "/mutate"
        assert adapter.last_info.origin == "https://app.example.com"
        assert adapter.last_info.referer == "https://app.example.com/page"
        assert adapter.last_info.is_session_auth is True
