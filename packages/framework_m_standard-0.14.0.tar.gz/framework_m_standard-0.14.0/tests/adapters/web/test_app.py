"""Tests for Litestar Application Setup.

TDD tests for the web application factory and configuration.
Tests written FIRST per CONTRIBUTING.md guidelines.
"""

from unittest.mock import patch

import pytest
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.web.app import (
    create_app,
)
from litestar import Litestar
from litestar.testing import TestClient


@pytest.fixture(autouse=True)
def reset_registry():
    """Clear MetaRegistry before and after each test to avoid DuplicateDocTypeError."""
    MetaRegistry.get_instance()._doctypes.clear()
    with patch("framework_m_standard.adapters.web.app.load_env"):
        yield
    MetaRegistry.get_instance()._doctypes.clear()


class TestAppFactory:
    """Test the application factory function."""

    def test_create_app_returns_litestar_instance(self) -> None:
        """Create_app should return a Litestar application instance."""
        app = create_app()
        assert isinstance(app, Litestar)

    def test_app_has_openapi_configured(self) -> None:
        """App should have OpenAPI documentation configured."""
        app = create_app()
        # OpenAPI config should be present
        assert app.openapi_config is not None
        # Should have a title set
        assert app.openapi_config.title is not None

    def test_app_has_cors_configured_for_development(self) -> None:
        """App should have CORS configured for development mode."""
        app = create_app()
        # CORS middleware should be added
        # In Litestar, CORS is configured via CORSConfig
        assert app.cors_config is not None

    def test_app_has_exception_handlers(self) -> None:
        """App should have custom exception handlers registered."""
        app = create_app()
        # Exception handlers should be configured
        assert app.exception_handlers is not None
        # Should have at least one handler
        assert len(app.exception_handlers) > 0


class TestAppLifecycle:
    """Test application lifecycle hooks."""

    @pytest.mark.asyncio
    async def test_lifespan_context_manager(self) -> None:
        """App should properly handle startup and shutdown."""
        app = create_app()
        # The lifespan context manager should be set
        # Litestar uses on_startup and on_shutdown or lifespan
        # We check that the app can be used as async context manager
        assert app is not None


class TestOpenAPIConfiguration:
    """Test OpenAPI/Swagger documentation configuration."""

    def test_swagger_ui_available(self) -> None:
        """Swagger UI should be available at /schema/swagger."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/schema/swagger")
            # Should redirect or return HTML
            assert response.status_code in [200, 301, 302, 307, 308]

    def test_openapi_schema_available(self) -> None:
        """OpenAPI JSON schema should be available."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/schema/openapi.json")
            assert response.status_code == 200
            data = response.json()
            # Should have OpenAPI version
            assert "openapi" in data
            # Should have info section
            assert "info" in data


class TestServeStaticMode:
    """Test serve_static parameter and M_DEV_MODE detection.

    Tests written FIRST per TDD principles.
    """

    def test_create_app_with_serve_static_true_includes_ui_routes(self) -> None:
        """When serve_static=True, app should include UI routes."""
        app = create_app(serve_static=True)

        # Check that UI routes are registered
        route_paths = [route.path for route in app.routes]

        # Should have root redirect
        assert "/" in route_paths
        # Should have desk routes
        assert "/desk/" in route_paths or "/desk" in route_paths

        # Should have static files route (usually matches /desk/assets/{...})
        assert any("/desk/assets" in p for p in route_paths)

    def test_create_app_with_serve_static_false_excludes_ui_routes(self) -> None:
        """When serve_static=False, app should NOT include UI routes."""
        app = create_app(serve_static=False)

        # Should NOT have root redirect to /desk/
        # Note: / might still exist for other purposes, but redirect shouldn't
        # We test by trying to access the endpoint
        with TestClient(app) as client:
            response = client.get("/", follow_redirects=False)
            # Should NOT redirect to /desk/ (would get 404 or other)
            assert response.status_code != 307  # Not a redirect

        # Should NOT have static files config
        assert app.static_files_config == []

    def test_create_app_defaults_to_serve_static_true(self, monkeypatch) -> None:
        """When serve_static is not specified, should default to True (production mode)."""
        monkeypatch.delenv("M_DEV_MODE", raising=False)

        app = create_app()  # No parameter

        # Should include UI routes (production default)
        route_paths = [route.path for route in app.routes]
        assert "/" in route_paths or any("/desk" in path for path in route_paths)

        # Should have static files config
        assert app.static_files_config is not None

    def test_create_app_detects_m_dev_mode_env_var(self, monkeypatch) -> None:
        """When M_DEV_MODE=true env var is set, should automatically use serve_static=False."""

        # Set M_DEV_MODE environment variable
        monkeypatch.setenv("M_DEV_MODE", "true")

        # Create app without specifying serve_static (should auto-detect)
        app = create_app()

        # Should NOT have static files config (dev mode)
        assert app.static_files_config == []

        # Clean up
        monkeypatch.delenv("M_DEV_MODE")

    def test_create_app_defaults_dev_allowed_origins(self, monkeypatch) -> None:
        """Dev mode should default allowed origins to local Vite hosts."""

        monkeypatch.delenv("FRAMEWORK_M_CORS_ORIGINS", raising=False)
        monkeypatch.setenv("M_DEV_MODE", "true")

        app = create_app(serve_static=False)

        assert app.cors_config is not None
        assert app.cors_config.allow_origins == [
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        ]

    def test_env_origins_override_dev_defaults(self, monkeypatch) -> None:
        """Explicit FRAMEWORK_M_CORS_ORIGINS should override dev defaults."""

        monkeypatch.setenv("M_DEV_MODE", "true")
        monkeypatch.setenv(
            "FRAMEWORK_M_CORS_ORIGINS",
            "http://localhost:3000,http://localhost:5173/",
        )

        app = create_app(serve_static=False)

        assert app.cors_config is not None
        assert app.cors_config.allow_origins == [
            "http://localhost:3000",
            "http://localhost:5173",
        ]

    def test_dev_mode_still_has_api_routes(self) -> None:
        """When serve_static=False, API routes should still be available."""
        app = create_app(serve_static=False)

        with TestClient(app) as client:
            # Health check should work
            response = client.get("/health")
            assert response.status_code == 200

            # Metadata API should work
            response = client.get("/api/meta/doctypes")
            assert response.status_code == 200

    def test_dev_mode_desk_path_returns_clean_404_json(self) -> None:
        """When serve_static=False, /desk should return structured 404 JSON."""
        app = create_app(serve_static=False)

        with TestClient(app) as client:
            response = client.get("/desk/")
            assert response.status_code == 404
            assert response.json() == {"status_code": 404, "detail": "Not Found"}

    def test_production_mode_has_both_api_and_ui_routes(self) -> None:
        """When serve_static=True, both API and UI routes should be available."""
        app = create_app(serve_static=True)

        with TestClient(app) as client:
            # API routes should work
            response = client.get("/health")
            assert response.status_code == 200

            # UI route should redirect or serve content
            response = client.get("/", follow_redirects=False)
            # Should redirect to /desk/ or serve content
            assert response.status_code in [200, 301, 302, 307, 308]


class TestIdempotencyConfiguration:
    """Tests for Idempotency middleware configuration."""

    def test_app_has_idempotency_middleware_by_default(self) -> None:
        """App should include IdempotencyMiddleware by default."""
        from framework_m_standard.adapters.web.middleware.idempotency import (
            IdempotencyMiddleware,
        )
        from litestar.middleware.base import DefineMiddleware

        app = create_app()

        has_idem = False
        for m in app.middleware:
            if (
                isinstance(m, DefineMiddleware)
                and m.middleware == IdempotencyMiddleware
            ):
                has_idem = True
        assert has_idem

    def test_app_can_disable_idempotency_middleware(self) -> None:
        """App should allow disabling IdempotencyMiddleware via config."""
        from framework_m_standard.adapters.web.middleware.idempotency import (
            IdempotencyMiddleware,
        )
        from litestar.middleware.base import DefineMiddleware

        with patch("framework_m_standard.adapters.web.app.load_config") as mock_load:
            mock_load.return_value = {"web": {"idempotency": {"enabled": False}}}
            app = create_app()

            has_idem = False
            for m in app.middleware:
                if (
                    isinstance(m, DefineMiddleware)
                    and m.middleware == IdempotencyMiddleware
                ):
                    has_idem = True
            assert not has_idem


class TestAppDiscovery:
    """Tests for application discovery in create_app."""

    def test_create_app_calls_app_discovery(self) -> None:
        """create_app should call load_installed_apps on the registry."""

        from framework_m_core.registry import MetaRegistry
        from framework_m_standard.adapters.web.app import create_app

        registry = MetaRegistry.get_instance()
        with patch.object(registry, "load_installed_apps") as mock_load:
            create_app(serve_static=False)
            assert mock_load.called
