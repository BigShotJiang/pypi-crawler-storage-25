"""Tests for the Web Idempotency Middleware."""

import json
from typing import Any
from unittest.mock import MagicMock

import pytest
from framework_m_core.interfaces.idempotency import (
    IdempotencyProtocol,
    SerializedResponse,
)
from framework_m_standard.adapters.web.middleware.idempotency import (
    IdempotencyMiddleware,
)
from litestar import Litestar, Request, Response, post
from litestar.middleware import AbstractMiddleware, DefineMiddleware
from litestar.status_codes import (
    HTTP_201_CREATED,
    HTTP_400_BAD_REQUEST,
    HTTP_409_CONFLICT,
)
from litestar.testing import TestClient


class MockIdempotencyAdapter(IdempotencyProtocol):
    """In-memory adapter for testing the middleware."""

    def __init__(self) -> None:
        self.store: dict[str, SerializedResponse] = {}
        self.locks: set[str] = set()

    async def get_response(self, key: str) -> SerializedResponse | None:
        return self.store.get(key)

    async def save_response(self, key: str, response: SerializedResponse) -> None:
        self.store[key] = response

    async def acquire_lock(self, key: str, timeout: float = 5.0) -> bool:
        if key in self.locks:
            return False
        self.locks.add(key)
        return True

    async def release_lock(self, key: str) -> None:
        self.locks.discard(key)


@pytest.fixture
def adapter() -> MockIdempotencyAdapter:
    return MockIdempotencyAdapter()


@pytest.fixture
def test_client(adapter: MockIdempotencyAdapter) -> TestClient:
    """Provides a Litestar app configured with the idempotency middleware."""

    class MockTenantMiddleware(AbstractMiddleware):
        """Simulates the TenantContext being populated by earlier middlewares."""

        async def __call__(
            self, scope: dict[str, Any], receive: Any, send: Any
        ) -> None:
            if "state" not in scope:
                scope["state"] = {}
            scope["state"]["tenant"] = MagicMock(tenant_id="tenant-123")
            await self.app(scope, receive, send)

    hit_counter = {"count": 0}

    @post("/test")
    async def test_route(request: Request[Any, Any, Any]) -> dict[str, Any]:
        hit_counter["count"] += 1
        return {"status": "success", "hits": hit_counter["count"]}

    @post("/error")
    async def error_route(request: Request[Any, Any, Any]) -> Response[dict[str, str]]:
        hit_counter["count"] += 1
        return Response({"error": "bad validation"}, status_code=HTTP_400_BAD_REQUEST)

    app = Litestar(
        route_handlers=[test_route, error_route],
        middleware=[
            MockTenantMiddleware,
            DefineMiddleware(IdempotencyMiddleware, adapter=adapter),
        ],
    )
    app.state.hit_counter = hit_counter
    return TestClient(app=app)


def test_successful_response_is_cached(
    test_client: TestClient, adapter: MockIdempotencyAdapter
) -> None:
    """Verify that a new successful response is saved to the cache."""
    response = test_client.post("/test", headers={"Idempotency-Key": "client-key-new"})

    assert response.status_code == HTTP_201_CREATED
    assert test_client.app.state.hit_counter["count"] == 1

    # Verify it was saved in the adapter
    cached = adapter.store.get("tenant-123:client-key-new")
    assert cached is not None
    assert cached.status_code == HTTP_201_CREATED
    assert json.loads(cached.body.decode("utf-8")) == {"status": "success", "hits": 1}


def test_cached_response_skips_controller(
    test_client: TestClient, adapter: MockIdempotencyAdapter
) -> None:
    """Verify cached responses are returned directly and controller is skipped."""
    adapter.store["tenant-123:client-key-1"] = SerializedResponse(
        status_code=HTTP_201_CREATED,
        headers={"Content-Type": "application/json"},
        body=b'{"cached": true}',
    )

    response = test_client.post("/test", headers={"Idempotency-Key": "client-key-1"})

    assert response.status_code == HTTP_201_CREATED
    assert response.json() == {"cached": True}
    assert test_client.app.state.hit_counter["count"] == 0  # Controller was skipped


def test_4xx_errors_are_cached(test_client: TestClient) -> None:
    """Verify client errors are cached to prevent re-execution of bad requests."""
    response1 = test_client.post("/error", headers={"Idempotency-Key": "client-key-3"})
    assert response1.status_code == HTTP_400_BAD_REQUEST
    assert test_client.app.state.hit_counter["count"] == 1

    response2 = test_client.post("/error", headers={"Idempotency-Key": "client-key-3"})
    assert response2.status_code == HTTP_400_BAD_REQUEST
    assert test_client.app.state.hit_counter["count"] == 1  # Controller NOT hit again


def test_concurrent_request_returns_409(
    test_client: TestClient, adapter: MockIdempotencyAdapter
) -> None:
    """Verify an active lock returns a 409 Conflict."""
    adapter.locks.add("tenant-123:client-key-4")
    response = test_client.post("/test", headers={"Idempotency-Key": "client-key-4"})
    assert response.status_code == HTTP_409_CONFLICT
