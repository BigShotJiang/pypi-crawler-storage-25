"""Tests for the library-agnostic Web and CSRF protocols."""

import pytest
from framework_m_standard.interfaces.web import CSRFProtocol, WebRequestInfo
from pydantic import ValidationError


def test_web_request_info_model() -> None:
    """Test that WebRequestInfo holds necessary HTTP context."""
    req_info = WebRequestInfo(
        method="POST",
        origin="https://example.com",
        referer="https://example.com/page",
        path="/api/v1/data",
        is_session_auth=True,
    )

    assert req_info.method == "POST"
    assert req_info.origin == "https://example.com"
    assert req_info.referer == "https://example.com/page"
    assert req_info.path == "/api/v1/data"
    assert req_info.is_session_auth is True


def test_web_request_info_validation() -> None:
    """Test that WebRequestInfo requires essential fields."""
    with pytest.raises(ValidationError):
        # Missing required fields like method and path
        WebRequestInfo(origin="https://example.com")  # type: ignore


@pytest.mark.asyncio
async def test_csrf_protocol_definition() -> None:
    """Test that CSRFProtocol defines the correct contract."""

    class MockCSRFAdapter(CSRFProtocol):
        async def validate_request(self, request_info: WebRequestInfo) -> bool:
            return request_info.origin == "https://example.com"

    adapter = MockCSRFAdapter()
    assert hasattr(adapter, "validate_request")
