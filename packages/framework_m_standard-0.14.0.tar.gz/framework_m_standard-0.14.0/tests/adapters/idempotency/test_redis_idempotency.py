"""Tests for the Redis-backed Idempotency Adapter."""

import base64
import json
from unittest.mock import AsyncMock

import pytest
from framework_m_core.interfaces.idempotency import SerializedResponse

# This import will intentionally fail (Red) until we implement the adapter
from framework_m_standard.adapters.idempotency.redis import (
    RedisIdempotencyAdapter,
)


@pytest.fixture
def mock_redis() -> AsyncMock:
    """Fixture providing a mocked Redis client."""
    return AsyncMock()


@pytest.fixture
def adapter(mock_redis: AsyncMock) -> RedisIdempotencyAdapter:
    """Fixture providing the RedisIdempotencyAdapter."""
    return RedisIdempotencyAdapter(redis_client=mock_redis)


@pytest.mark.asyncio
async def test_get_response_found(
    adapter: RedisIdempotencyAdapter, mock_redis: AsyncMock
) -> None:
    """Test retrieving a cached response successfully from Redis."""
    body_bytes = b'{"success": true}'
    body_b64 = base64.b64encode(body_bytes).decode("utf-8")

    cached_data = {
        "status_code": 200,
        "headers": {"Content-Type": "application/json"},
        "body": body_b64,
    }

    mock_redis.get.return_value = json.dumps(cached_data)

    response = await adapter.get_response("test-key-1")

    assert response is not None
    assert response.status_code == 200
    assert response.headers == {"Content-Type": "application/json"}
    assert response.body == body_bytes
    mock_redis.get.assert_called_once_with("idem:resp:test-key-1")


@pytest.mark.asyncio
async def test_save_response(
    adapter: RedisIdempotencyAdapter, mock_redis: AsyncMock
) -> None:
    """Test saving a serialized response to Redis with Base64 encoding."""
    response = SerializedResponse(
        status_code=201,
        headers={"Content-Type": "application/json"},
        body=b'{"created": true}',
    )

    await adapter.save_response("test-key-2", response)

    mock_redis.set.assert_called_once()
    args, kwargs = mock_redis.set.call_args
    assert args[0] == "idem:resp:test-key-2"

    # Verify payload was serialized to JSON with Base64 body
    saved_data = json.loads(args[1])
    assert saved_data["status_code"] == 201
    assert saved_data["body"] == base64.b64encode(b'{"created": true}').decode("utf-8")


@pytest.mark.asyncio
async def test_acquire_lock_success(
    adapter: RedisIdempotencyAdapter, mock_redis: AsyncMock
) -> None:
    """Test acquiring a distributed lock using Redis SET NX."""
    mock_redis.set.return_value = True

    acquired = await adapter.acquire_lock("test-key-3", timeout=1.0)

    assert acquired is True
    mock_redis.set.assert_called_once_with(
        "idem:lock:test-key-3", "locked", nx=True, ex=1
    )


@pytest.mark.asyncio
async def test_release_lock(
    adapter: RedisIdempotencyAdapter, mock_redis: AsyncMock
) -> None:
    """Test releasing the Redis lock."""
    await adapter.release_lock("test-key-4")
    mock_redis.delete.assert_called_once_with("idem:lock:test-key-4")
