"""Tests for the Database-backed Idempotency Adapter."""

from unittest.mock import AsyncMock, MagicMock

import pytest
from framework_m_core.interfaces.idempotency import SerializedResponse

# This import will intentionally fail (Red) until we implement the adapter
from framework_m_standard.adapters.idempotency.database import (
    DatabaseIdempotencyAdapter,
)
from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Integer,
    LargeBinary,
    MetaData,
    String,
    Table,
    Uuid,
)


@pytest.fixture
def mock_session() -> AsyncMock:
    """Fixture providing a mocked SQLAlchemy AsyncSession."""
    session = AsyncMock()
    session.add = MagicMock()  # add is synchronous in SQLAlchemy
    return session


@pytest.fixture
def mock_table_registry() -> MagicMock:
    """Fixture providing a mocked TableRegistry."""
    registry = MagicMock()
    metadata = MetaData()
    dummy_table = Table(
        "idempotency_keys",
        metadata,
        Column("id", Uuid, primary_key=True),
        Column("key", String(255)),
        Column("status_code", Integer),
        Column("headers", JSON),
        Column("body", LargeBinary),
        Column("creation", DateTime),
        Column("modified", DateTime),
    )
    registry.get_table.return_value = dummy_table
    return registry


@pytest.fixture
def mock_session_factory(mock_session: AsyncMock) -> MagicMock:
    """Fixture providing a factory that yields the mocked session."""
    factory = MagicMock()
    factory.return_value.__aenter__.return_value = mock_session
    return factory


@pytest.fixture
def adapter(
    mock_session_factory: MagicMock, mock_table_registry: MagicMock
) -> DatabaseIdempotencyAdapter:
    """Fixture providing the DatabaseIdempotencyAdapter."""
    return DatabaseIdempotencyAdapter(
        session_factory=mock_session_factory, table_registry=mock_table_registry
    )


@pytest.mark.asyncio
async def test_get_response_found(
    adapter: DatabaseIdempotencyAdapter, mock_session: AsyncMock
) -> None:
    """Test retrieving a cached response successfully."""
    mock_record = {
        "status_code": 200,
        "headers": {"Content-Type": "application/json"},
        "body": b'{"success": true}',
    }

    mock_mappings = MagicMock()
    mock_mappings.one_or_none.return_value = mock_record
    mock_result = MagicMock()
    mock_result.mappings.return_value = mock_mappings
    mock_session.execute.return_value = mock_result

    response = await adapter.get_response("test-key-1")

    assert response is not None
    assert response.status_code == 200
    assert response.headers == {"Content-Type": "application/json"}
    assert response.body == b'{"success": true}'


@pytest.mark.asyncio
async def test_save_response(
    adapter: DatabaseIdempotencyAdapter, mock_session: AsyncMock
) -> None:
    """Test saving a serialized response to the database."""
    response = SerializedResponse(
        status_code=201,
        headers={"Content-Type": "application/json"},
        body=b'{"created": true}',
    )

    await adapter.save_response("test-key-2", response)

    mock_session.execute.assert_called_once()
    mock_session.commit.assert_awaited_once()


@pytest.mark.asyncio
async def test_acquire_lock_calls_db(
    adapter: DatabaseIdempotencyAdapter, mock_session: AsyncMock
) -> None:
    """Test that lock acquisition attempts to execute a database-level lock query."""
    await adapter.acquire_lock("test-key-3", timeout=1.0)
    mock_session.execute.assert_awaited()
