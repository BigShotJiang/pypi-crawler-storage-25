"""Tests for UsageMeterService."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock

import pytest
from framework_m_core.interfaces.metering import UsageEvent


class TestUsageMeterService:
    """Tests for the application-level UsageMeterService."""

    @pytest.mark.asyncio
    async def test_track_usage(self) -> None:
        """Should wrap parameters into a UsageEvent and pass to adapter."""
        from framework_m_standard.adapters.metering.usage_meter_service import (
            UsageMeterService,
        )

        mock_metering = AsyncMock()
        service = UsageMeterService(metering=mock_metering)

        await service.track_usage(
            tenant_id="tenant-1",
            feature_name="api_calls",
            quantity=1.0,
            metadata={"endpoint": "/test"},
        )

        assert mock_metering.record_usage.call_count == 1
        event = mock_metering.record_usage.call_args[0][0]
        assert isinstance(event, UsageEvent)
        assert event.tenant_id == "tenant-1"
        assert event.feature_name == "api_calls"
        assert event.quantity == 1.0
        assert event.metadata == {"endpoint": "/test"}

    @pytest.mark.asyncio
    async def test_get_current_usage(self) -> None:
        """Should delegate to the underlying metering adapter."""
        from framework_m_standard.adapters.metering.usage_meter_service import (
            UsageMeterService,
        )

        mock_metering = AsyncMock()
        mock_metering.get_usage.return_value = 150.0
        service = UsageMeterService(metering=mock_metering)

        now = datetime.now(UTC)
        start = now - timedelta(days=30)

        total = await service.get_current_usage(
            tenant_id="tenant-1",
            feature_name="api_calls",
            start_time=start,
            end_time=now,
        )

        assert total == 150.0
        mock_metering.get_usage.assert_called_once_with(
            "tenant-1", "api_calls", start, now
        )
