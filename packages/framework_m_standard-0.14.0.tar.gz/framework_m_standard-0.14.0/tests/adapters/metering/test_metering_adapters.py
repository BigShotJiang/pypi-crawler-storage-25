"""Tests for Metering Adapters."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import pytest
from framework_m_core.interfaces.metering import UsageEvent


class TestPostgresMeteringAdapter:
    """Tests for the Postgres implementation of MeteringProtocol."""

    @pytest.mark.asyncio
    async def test_record_and_get_usage(self) -> None:
        """Should record usage events and aggregate them correctly."""
        from framework_m_standard.adapters.metering.metered_usage import MeteredUsage
        from framework_m_standard.adapters.metering.postgres_adapter import (
            PostgresMeteringAdapter,
        )

        # Mock the RepositoryProtocol and AsyncSession
        mock_repo = AsyncMock()
        mock_session = AsyncMock()
        adapter = PostgresMeteringAdapter(repository=mock_repo, session=mock_session)

        now = datetime.now(UTC)
        event1 = UsageEvent(
            tenant_id="tenant-1",
            feature_name="api_calls",
            quantity=5.0,
            timestamp=now - timedelta(minutes=10),
            metadata={"endpoint": "/api/v1/users"},
        )
        event2 = UsageEvent(
            tenant_id="tenant-1",
            feature_name="api_calls",
            quantity=3.0,
            timestamp=now - timedelta(minutes=5),
            metadata={"endpoint": "/api/v1/projects"},
        )

        # Record usage
        await adapter.record_usage(event1)
        assert mock_repo.save.call_count == 1
        saved_doc1 = mock_repo.save.call_args_list[0][0][1]
        assert saved_doc1.tenant_id == "tenant-1"
        assert saved_doc1.quantity == 5.0

        await adapter.record_usage(event2)
        assert mock_repo.save.call_count == 2

        # Mock the return value for the repository list method in get_usage
        mock_paginated = MagicMock()
        mock_paginated.items = [
            MeteredUsage(
                tenant_id="tenant-1",
                feature_name="api_calls",
                quantity=5.0,
                timestamp=now,
            ),
            MeteredUsage(
                tenant_id="tenant-1",
                feature_name="api_calls",
                quantity=3.0,
                timestamp=now,
            ),
        ]
        mock_repo.list_entities.return_value = mock_paginated

        # Get usage
        total_usage = await adapter.get_usage(
            tenant_id="tenant-1",
            feature_name="api_calls",
            start_time=now - timedelta(hours=1),
            end_time=now,
        )

        assert total_usage == 8.0
