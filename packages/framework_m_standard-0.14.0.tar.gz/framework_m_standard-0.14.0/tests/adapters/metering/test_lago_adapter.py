"""Tests for LagoMeteringAdapter using Testcontainers."""

from datetime import UTC, datetime

import pytest
from framework_m_core.interfaces.metering import UsageEvent
from framework_m_standard.adapters.metering.lago_adapter import (
    CircuitBreakerOpenError,
    LagoMeteringAdapter,
)

# @pytest.fixture(scope="module")
# def lago_setup():
#     import subprocess
#     from testcontainers.compose import DockerCompose

#     compose_path = "libs/framework-m-standard/tests/adapters/metering"
#     compose_file = "docker-compose.lago.yml"

#     with DockerCompose(compose_path, compose_file_name=compose_file) as compose:
#         host = compose.get_service_host("lago-api", 3000)
#         port = compose.get_service_port("lago-api", 3000)
#         url = f"http://{host}:{port}"

#         # Extract valid API credentials dynamically
#         res = subprocess.run(
#             [
#                 "docker",
#                 "compose",
#                 "-f",
#                 f"{compose_path}/{compose_file}",
#                 "exec",
#                 "-T",
#                 "lago-api",
#                 "bundle",
#                 "exec",
#                 "rails",
#                 "runner",
#                 "org = Organization.first || Organization.create!(name: 'TestOrg'); puts org.api_keys.first&.value || org.api_keys.create!.value",
#             ],
#             check=True,
#             capture_output=True,
#             text=True,
#         )

#         api_key = res.stdout.strip()
#         yield {"url": url, "api_key": api_key}


# @pytest.mark.integration
# @pytest.mark.asyncio
# async def test_lago_adapter_record_usage(lago_setup):
#     adapter = LagoMeteringAdapter(
#         api_key=lago_setup["api_key"], api_url=lago_setup["url"]
#     )
#     event = UsageEvent(
#         tenant_id="tenant-1",
#         feature_name="api_calls",
#         quantity=1.0,
#         timestamp=datetime.now(UTC),
#     )

#     # Should pass safely against verified APIs
#     await adapter.record_usage(event)


@pytest.mark.asyncio
async def test_lago_adapter_record_usage_mocked():
    from unittest.mock import AsyncMock, Mock, patch

    adapter = LagoMeteringAdapter(api_key="mock-key", api_url="http://localhost:3000")
    event = UsageEvent(
        tenant_id="tenant-1",
        feature_name="api_calls",
        quantity=1.0,
        timestamp=datetime.now(UTC),
    )

    mock_response = AsyncMock()
    mock_response.status_code = 200
    mock_response.is_success = True
    mock_response.raise_for_status = Mock()

    with patch("httpx.AsyncClient.post", return_value=mock_response) as mock_post:
        await adapter.record_usage(event)
        mock_post.assert_called_once()


@pytest.mark.asyncio
async def test_lago_circuit_breaker_open_state():
    adapter = LagoMeteringAdapter(
        api_key="test-key", api_url="http://localhost:9999", failure_threshold=2
    )
    event = UsageEvent(
        tenant_id="tenant-1",
        feature_name="api_calls",
        quantity=1.0,
        timestamp=datetime.now(UTC),
    )

    with pytest.raises(Exception) as _:
        await adapter.record_usage(event)

    with pytest.raises(Exception) as _:
        await adapter.record_usage(event)

    with pytest.raises(CircuitBreakerOpenError) as _:
        await adapter.record_usage(event)
