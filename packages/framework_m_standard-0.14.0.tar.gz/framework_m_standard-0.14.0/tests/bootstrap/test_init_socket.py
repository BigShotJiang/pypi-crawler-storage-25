"""Tests for InitSocket bootstrap step."""

import json
from unittest.mock import ANY, AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.bootstrap.init_socket import InitSocket


class TestInitSocket:
    """Tests for InitSocket bootstrap step."""

    @pytest.mark.asyncio
    async def test_run_no_nats_url_skips(self) -> None:
        """Should skip if NATS_URL is not set."""
        step = InitSocket()
        container = MagicMock()
        mock_secrets = MagicMock()
        mock_secrets.get.return_value = None
        container.secrets_manager.return_value = mock_secrets

        with patch.dict("os.environ", {}, clear=True):
            await step.run(container)

        # Verify no adapter was created
        with (
            patch(
                "framework_m_standard.adapters.socket.nats_socket.NatsSocketAdapter"
            ) as mock_adapter,
            patch.dict("os.environ", {}, clear=True),
        ):
            await step.run(container)
            mock_adapter.assert_not_called()

    @pytest.mark.asyncio
    async def test_run_with_nats_url_bridges(self) -> None:
        """Should connect and subscribe when NATS_URL is set."""
        step = InitSocket()
        container = MagicMock()
        container.socket_adapter = MagicMock()

        mock_adapter_instance = AsyncMock()

        with (
            patch.dict("os.environ", {"NATS_URL": "nats://localhost:4222"}),
            patch(
                "framework_m_standard.bootstrap.init_socket.NatsSocketAdapter",
                return_value=mock_adapter_instance,
            ),
            patch(
                "framework_m_standard.bootstrap.init_socket.get_connection_manager"
            ) as mock_get_manager,
        ):
            mock_manager = MagicMock()
            mock_get_manager.return_value = mock_manager

            mock_secrets = MagicMock()
            mock_secrets.get.return_value = "nats://localhost:4222"
            container.secrets_manager.return_value = mock_secrets

            await step.run(container)
            # Verify connection
            mock_adapter_instance.connect.assert_awaited_once()

            # Verify subscription to ws.>
            mock_adapter_instance.subscribe.assert_called_once_with("ws.>", ANY)

            # Verify container override
            container.socket_adapter.override.assert_called_once_with(
                mock_adapter_instance
            )

    @pytest.mark.asyncio
    async def test_bridge_callback_broadcast(self) -> None:
        """Verify the bridge callback handles broadcasts correctly."""
        step = InitSocket()
        container = MagicMock()

        mock_adapter_instance = AsyncMock()
        mock_manager = AsyncMock()

        with (
            patch.dict("os.environ", {"NATS_URL": "nats://localhost:4222"}),
            patch(
                "framework_m_standard.bootstrap.init_socket.NatsSocketAdapter",
                return_value=mock_adapter_instance,
            ),
            patch(
                "framework_m_standard.bootstrap.init_socket.get_connection_manager",
                return_value=mock_manager,
            ),
        ):
            mock_secrets = MagicMock()
            mock_secrets.get.return_value = "nats://localhost:4222"
            container.secrets_manager.return_value = mock_secrets

            await step.run(container)

            # Extract the callback passed to subscribe
            callback = mock_adapter_instance.subscribe.call_args[0][1]

            # Simulate a message
            from collections import namedtuple

            Msg = namedtuple("Msg", ["subject", "data"])
            data_mock = MagicMock()
            data_mock.decode.return_value = json.dumps({"event": "hello"})
            msg = Msg(subject="ws.broadcast", data=data_mock)

            await callback(msg)

            # Verify broadcast was called on local manager
            mock_manager.broadcast.assert_awaited_once_with({"event": "hello"})

    @pytest.mark.asyncio
    async def test_bridge_callback_user_message(self) -> None:
        """Verify the bridge callback handles user-specific messages correctly."""
        step = InitSocket()
        container = MagicMock()

        mock_adapter_instance = AsyncMock()
        mock_manager = AsyncMock()

        with (
            patch.dict("os.environ", {"NATS_URL": "nats://localhost:4222"}),
            patch(
                "framework_m_standard.bootstrap.init_socket.NatsSocketAdapter",
                return_value=mock_adapter_instance,
            ),
            patch(
                "framework_m_standard.bootstrap.init_socket.get_connection_manager",
                return_value=mock_manager,
            ),
        ):
            mock_secrets = MagicMock()
            mock_secrets.get.return_value = "nats://localhost:4222"
            container.secrets_manager.return_value = mock_secrets

            await step.run(container)

            # Extract the callback passed to subscribe
            callback = mock_adapter_instance.subscribe.call_args[0][1]

            # Simulate a message
            from collections import namedtuple

            Msg = namedtuple("Msg", ["subject", "data"])
            data_mock = MagicMock()
            data_mock.decode.return_value = json.dumps({"event": "hello"})
            msg = Msg(subject="ws.user.abc-123", data=data_mock)

            await callback(msg)

            # Verify send_to_user was called on local manager
            mock_manager.send_to_user.assert_awaited_once_with(
                "abc-123", {"event": "hello"}
            )
