"""Tests for the logging bootstrap process."""

from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.config import RootConfig
from framework_m_standard.adapters.logging.redactor_processor import (
    SecretRedactionProcessor,
)
from framework_m_standard.bootstrap.logging import InitLogging


@pytest.mark.asyncio
@pytest.mark.parametrize("enabled_state", [True, False])
async def test_init_logging_adds_redactor_conditionally(enabled_state: bool) -> None:
    """
    Verify SecretRedactionProcessor is added only when logging.enabled is True.
    """
    # 1. Arrange: Create a config with logging enabled or disabled
    config = RootConfig()
    config.logging.enabled = enabled_state
    config.logging.redact_keys.append("custom_secret")

    container = MagicMock()
    container.config.return_value = config.model_dump()

    step = InitLogging()

    # 2. Act: Call the configuration function while mocking structlog
    with patch("structlog.configure") as mock_configure:
        await step.run(container)

        # 3. Assert: Check if the processor was added correctly
        mock_configure.assert_called_once()

        # Get the 'processors' list from the call arguments
        _, kwargs = mock_configure.call_args
        processors = kwargs.get("processors", [])

        processor_found = any(
            isinstance(p, SecretRedactionProcessor) for p in processors
        )

        assert processor_found is enabled_state

        if enabled_state:
            # Further inspect the processor to ensure it was configured correctly
            redactor_proc = next(
                p for p in processors if isinstance(p, SecretRedactionProcessor)
            )
            # The domain logic should have received the keys from the config
            assert "custom_secret" in redactor_proc._redactor._redact_keys
            assert "password" in redactor_proc._redactor._redact_keys
