from framework_m_standard.adapters.web.middleware.rate_limit import RateLimitKeyResolver
from litestar import Litestar, get
from litestar.middleware.rate_limit import RateLimitConfig
from litestar.status_codes import HTTP_200_OK
from litestar.testing import TestClient


@get("/")
def handler() -> dict:
    return {"hello": "world"}


def test_rate_limit_headers_present():
    rate_limit_config = RateLimitConfig(
        rate_limit=("second", 10),
        identifier_for_request=RateLimitKeyResolver(),
        set_rate_limit_headers=True,
        rate_limit_limit_header_key="X-RateLimit-Limit",
        rate_limit_remaining_header_key="X-RateLimit-Remaining",
        rate_limit_reset_header_key="X-RateLimit-Reset",
    )

    with TestClient(
        app=Litestar(
            route_handlers=[handler], middleware=[rate_limit_config.middleware]
        )
    ) as client:
        response = client.get("/")
        assert response.status_code == HTTP_200_OK

        # Check for standardized headers (X- prefix as configured)
        assert "X-RateLimit-Limit" in response.headers
        assert "X-RateLimit-Remaining" in response.headers
        assert "X-RateLimit-Reset" in response.headers
