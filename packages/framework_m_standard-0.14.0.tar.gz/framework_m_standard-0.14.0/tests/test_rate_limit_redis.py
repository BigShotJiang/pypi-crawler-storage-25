import asyncio

import pytest
import redis.asyncio as redis_async
from litestar import Litestar, get
from litestar.middleware.rate_limit import RateLimitConfig
from litestar.stores.redis import RedisStore
from litestar.testing import TestClient
from testcontainers.redis import RedisContainer


@get("/")
def handler() -> dict:
    return {"hello": "world"}


@pytest.fixture(scope="module")
def redis_container():
    with RedisContainer("redis:7") as redis:
        yield redis


def test_redis_shared_counter(redis_container):
    host = redis_container.get_container_host_ip()
    port = redis_container.get_exposed_port(6379)
    url = f"redis://{host}:{port}"

    # Simulate two independent app instances sharing the same Redis store
    # In Litestar, the middleware uses the store provided in config.

    async def run_test():
        redis_client = redis_async.from_url(url)
        store = RedisStore(redis_client)

        # Limit to 2 requests per minute
        rate_limit_config = RateLimitConfig(
            rate_limit=("minute", 2),
            store=store,
            identifier_for_request=lambda _: "fixed_key",  # Shared key for all requests
        )

        app = Litestar(
            route_handlers=[handler], middleware=[rate_limit_config.middleware]
        )

        with TestClient(app=app) as client:
            # First request (from "worker 1")
            assert client.get("/").status_code == 200

            # Second request (from "worker 2" - simulated by same client but we care about the store)
            assert client.get("/").status_code == 200

            # Third request should be throttled because they share the same Redis bucket
            assert client.get("/").status_code == 429

        await redis_client.aclose()

    asyncio.run(run_test())
