"""
End-to-end test for the XaaS lifecycle.

This test simulates the full flow:
1. A user attempts to create a resource.
2. The QuotaPolicyHandler intercepts the request.
3. It checks the current usage via the UsageMeterService.
4. It allows or denies the creation based on the quota.
5. If allowed, the UsageMeterService records the new usage event.
"""

from typing import Any
from unittest.mock import AsyncMock

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.permission import (
    DecisionSource,
    PermissionAction,
    PolicyEvaluateRequest,
)
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.auth.quota_handler import QuotaPolicyHandler
from framework_m_standard.adapters.auth.rbac_permission import RbacPermissionAdapter
from framework_m_standard.adapters.metering.usage_meter_service import UsageMeterService


class Project(BaseDocType):
    """A simple DocType representing a billable resource."""

    class Meta:
        permissions = {"create": ["User"]}


class TestXaaSLifecycle:
    """End-to-end tests for XaaS metering and quota enforcement."""

    @pytest.fixture(autouse=True)
    def setup_registry(self) -> None:
        """Register test DocTypes before each test."""
        registry = MetaRegistry.get_instance()
        registry.clear()
        registry.register_doctype(Project)

    @pytest.mark.asyncio
    async def test_full_lifecycle_quota_enforcement(self) -> None:
        """
        Simulates a user creating projects against a quota.
        - Quota: 2 projects
        - User creates project 1 (allowed)
        - User creates project 2 (allowed)
        - User creates project 3 (denied)
        """
        usage_db: dict[str, float] = {}
        mock_metering_adapter = AsyncMock()

        async def mock_record_usage(event: Any) -> None:
            key = f"{event.tenant_id}:{event.feature_name}"
            usage_db[key] = usage_db.get(key, 0) + event.quantity

        async def mock_get_usage(
            tenant_id: str, feature_name: str, *args: Any, **kwargs: Any
        ) -> float:
            key = f"{tenant_id}:{feature_name}"
            return usage_db.get(key, 0.0)

        mock_metering_adapter.record_usage.side_effect = mock_record_usage
        mock_metering_adapter.get_usage.side_effect = mock_get_usage

        metering_service = UsageMeterService(metering=mock_metering_adapter)
        rbac_adapter = RbacPermissionAdapter()
        quota_handler = QuotaPolicyHandler(
            base_adapter=rbac_adapter,
            metering_service=metering_service,
            quotas={"Project": {"feature": "project_count", "limit": 2.0}},
        )

        request = PolicyEvaluateRequest(
            principal="user-1",
            action=PermissionAction.CREATE,
            resource="Project",
            tenant_id="tenant-acme",
            principal_attributes={"roles": ["User"]},
        )

        # --- Create Project 1 (Should be allowed) ---
        assert (await quota_handler.evaluate(request)).authorized is True
        await metering_service.track_usage(
            tenant_id="tenant-acme", feature_name="project_count"
        )
        assert usage_db.get("tenant-acme:project_count") == 1.0

        # --- Create Project 2 (Should be allowed) ---
        assert (await quota_handler.evaluate(request)).authorized is True
        await metering_service.track_usage(
            tenant_id="tenant-acme", feature_name="project_count"
        )
        assert usage_db.get("tenant-acme:project_count") == 2.0

        # --- Create Project 3 (Should be denied) ---
        result3 = await quota_handler.evaluate(request)
        assert result3.authorized is False
        assert result3.decision_source == DecisionSource.CUSTOM
        assert "Quota exceeded" in (result3.reason or "")
        assert usage_db.get("tenant-acme:project_count") == 2.0
