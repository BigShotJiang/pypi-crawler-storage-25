"""Tests for Migration CLI Commands."""

from __future__ import annotations

import importlib
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import framework_m_standard.cli.migrate as migrate_module
import pytest
from framework_m_standard.cli.migrate import get_manager


def test_module_env_loading() -> None:
    """Test the module-level dotenv loading logic."""
    import sys
    from unittest.mock import MagicMock, patch

    # Mock the dotenv module completely to avoid dependency on the environment
    mock_dotenv = MagicMock()
    sys.modules["dotenv"] = mock_dotenv

    try:
        # 1. Test ../../.env
        with patch("pathlib.Path.exists", lambda self: str(self) == "../../.env"):
            importlib.reload(migrate_module)
            mock_dotenv.load_dotenv.assert_called_with("../../.env")

        mock_dotenv.reset_mock()

        # 2. Test ../.env
        with patch("pathlib.Path.exists", lambda self: str(self) == "../.env"):
            importlib.reload(migrate_module)
            mock_dotenv.load_dotenv.assert_called_with("../.env")

        mock_dotenv.reset_mock()

        # 3. Test .env
        with patch("pathlib.Path.exists", lambda self: str(self) == ".env"):
            importlib.reload(migrate_module)
            mock_dotenv.load_dotenv.assert_called_with(".env")

    finally:
        if "dotenv" in sys.modules and sys.modules["dotenv"] is mock_dotenv:
            del sys.modules["dotenv"]

        # Reload cleanly to avoid side effects
        with patch("pathlib.Path.exists", return_value=False):
            importlib.reload(migrate_module)


def test_get_manager(tmp_path: Path) -> None:
    """Test get_manager initialization and validation."""
    from dependency_injector import providers
    from framework_m_core.container import Container

    mock_factory = MagicMock()
    mock_mgr_instance = MagicMock()
    mock_factory.return_value = mock_mgr_instance

    with Container.migration_manager.override(providers.Callable(mock_factory)):
        path = tmp_path / "fake_app"

        # 1. Test success with alembic dir existing
        with patch.object(Path, "exists", return_value=True):
            manager = get_manager(path, database_url="sqlite+aiosqlite:///test.db")
            assert manager == mock_mgr_instance
            mock_factory.assert_called_once_with(
                base_path=path,
                database_url="sqlite+aiosqlite:///test.db",
                version_table=None,
                x_args=None,
            )

        # 2. Test failure with missing alembic dir
        mock_factory.reset_mock()
        with (
            patch.object(Path, "exists", return_value=False),
            pytest.raises(SystemExit),
        ):
            get_manager(path)

        # 3. Test failure with invalid async sqlite URL
        with patch.object(Path, "exists", return_value=True), pytest.raises(SystemExit):
            get_manager(path, database_url="sqlite:///test.db")


def test_migrate_run_command() -> None:
    """Test the run command."""
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        # Test basic run
        from framework_m_standard.cli.migrate import migrate

        migrate(path=Path("/app"), database_url="sqlite+aiosqlite:///db")
        mock_mgr.upgrade.assert_called_once_with("head")

        # Test with apps env var
        with patch.dict(os.environ, {}, clear=False):
            migrate(path=Path("/app"), apps="app1,app2")
            assert os.environ["INSTALLED_APPS"] == "app1,app2"

        # Test failure (SystemExit with code 1)
        mock_mgr.upgrade.side_effect = Exception("error")
        with pytest.raises(SystemExit) as exc:
            migrate(path=Path("/app"))
        assert exc.value.code == 1


def test_migrate_create_command() -> None:
    """Test the create command."""
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        from framework_m_standard.cli.migrate import create

        create(message="new migration", path=Path("/app"))
        mock_mgr.revision.assert_called_once_with(
            "new migration", autogenerate=True, version_path=None
        )

        # Test with --app
        mock_mgr.reset_mock()
        mock_spec = MagicMock()
        mock_spec.origin = "/path/to/app/__init__.py"
        with (
            patch("importlib.util.find_spec", return_value=mock_spec),
            patch("pathlib.Path.mkdir"),
            patch("pathlib.Path.exists", return_value=False),
        ):
            create(message="app migration", path=Path("/app"), app="myapp")
            # Should have called revision with version_path
            assert mock_mgr.revision.called

        # Test create failure
        mock_mgr.revision.side_effect = Exception("error")
        with pytest.raises(SystemExit):
            create(message="fail", path=Path("/app"))


def test_migrate_rollback_command() -> None:
    """Test the rollback command."""
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        from framework_m_standard.cli.migrate import rollback

        rollback(path=Path("/app"), steps=2)
        mock_mgr.downgrade.assert_called_once_with("-2")


def test_migrate_status_history_init() -> None:
    """Test status, history, and init commands."""
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        from framework_m_standard.cli.migrate import history, init_alembic, status

        status(path=Path("/app"))
        mock_mgr.current.assert_called_once()

        history(path=Path("/app"))
        mock_mgr.history.assert_called_once()

        init_alembic(path=Path("/app"))
        mock_get_mgr.assert_called_with(Path("/app"), None, skip_alembic_check=True)
        mock_mgr.init.assert_called_once()

        # Test init failure
        mock_mgr.init.side_effect = Exception("error")
        with pytest.raises(SystemExit):
            init_alembic(path=Path("/app"))


def test_migrate_sync_command_with_apps(capsys: pytest.CaptureFixture[str]) -> None:
    """Test sync_command iterates registries and prints changes."""
    mock_change = MagicMock()
    mock_change.change_type.value = "add_table"
    mock_change.table_name = "new_table"

    with (
        patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr,
        patch("framework_m_core.registry.MetaRegistry.get_instance") as mock_get_reg,
        patch("framework_m_core.container.Container") as mock_container_cls,
        patch("sqlalchemy.create_engine"),
    ):
        from framework_m_core.domain.base_doctype import BaseDocType, Field

        class DummyUser(BaseDocType):
            title: str = Field(default="dummy")

        # Provide Basedoctype to trigger the mapper creation loop
        mock_container = mock_container_cls.return_value
        mock_mapper = mock_container.schema_mapper.return_value
        mock_reg_inst = mock_get_reg.return_value
        mock_reg_inst.list_doctypes.return_value = ["User"]
        mock_reg_inst.get_doctype.return_value = DummyUser
        mock_reg_inst.load_apps.return_value = None

        # Provide a change payload to trigger the changes output block
        mock_mgr_inst = mock_get_mgr.return_value
        mock_mgr_inst.auto_migrate.return_value = [mock_change]

        from framework_m_standard.cli.migrate import sync_command

        # Execute with apps arg
        with patch.dict(os.environ, {}, clear=False):
            sync_command(path=Path("/app"), apps="app1", dry_run=True)
            assert os.environ["INSTALLED_APPS"] == "app1"

        assert mock_reg_inst.list_doctypes.call_count >= 1
        mock_mapper.create_tables.assert_called_once()

        captured = capsys.readouterr()
        assert "add_table: new_table" in captured.out


def test_migrate_sync_command_no_apps() -> None:
    """Test sync_command skips the `if apps:` branch when None is passed."""
    with (
        patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr,
        patch("framework_m_core.registry.MetaRegistry"),
        patch("framework_m_standard.adapters.db.schema_mapper.SchemaMapper"),
        patch("sqlalchemy.create_engine"),
    ):
        mock_mgr_inst = mock_get_mgr.return_value
        mock_mgr_inst.auto_migrate.return_value = []

        from framework_m_standard.cli.migrate import sync_command

        # Should not raise any errors, and bypass the `if apps:` check
        sync_command(path=Path("/app"), apps=None, dry_run=True)


def test_migrate_all_command() -> None:
    """Test the 'all' command orchestrator."""
    with (
        patch("framework_m_standard.cli.migrate.migrate") as mock_migrate,
        patch("framework_m_standard.cli.migrate.sync_command") as mock_sync,
    ):
        from framework_m_standard.cli.migrate import all_command

        with patch.dict(os.environ, {}, clear=False):
            all_command(path=Path("/app"), apps="app1")
            assert os.environ["INSTALLED_APPS"] == "app1"

        mock_migrate.assert_called_once()
        mock_sync.assert_called_once()

        # Test failure in migrate (SystemExit 1)
        mock_migrate.side_effect = SystemExit(1)
        with pytest.raises(SystemExit):
            all_command(path=Path("/app"))


def test_migrate_isolated_macroservice() -> None:
    """Verify that running `m migrate` targets distinct decoupled database strings per micro-boundary appropriately."""
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        from framework_m_standard.cli.migrate import migrate

        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        migrate(path=Path("/app"), database_url="sqlite+aiosqlite:///boundary.db")
        mock_get_mgr.assert_called_with(
            Path("/app"),
            "sqlite+aiosqlite:///boundary.db",
            version_table=None,
            x_args=None,
        )
        mock_mgr.upgrade.assert_called_once_with("head")


def test_migrate_isolated_version_table() -> None:
    """Ensure applications sharing a single Monolith database can utilize decoupled tracking via custom version_table prefixes."""
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        from framework_m_standard.cli.migrate import migrate

        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        migrate(path=Path("/app"), version_table="_alembic_version_wms")
        mock_get_mgr.assert_called_with(
            Path("/app"), None, version_table="_alembic_version_wms", x_args=None
        )


def test_migrate_passes_custom_alembic_args() -> None:
    """Verify that deep parameters pass through successfully down into the internal MigrationManager runner safely."""
    with patch("framework_m_standard.cli.migrate.get_manager") as mock_get_mgr:
        from framework_m_standard.cli.migrate import migrate

        mock_mgr = MagicMock()
        mock_get_mgr.return_value = mock_mgr

        migrate(path=Path("/app"), x_args=("tenant=acme", "dry_run=True"))
        mock_get_mgr.assert_called_with(
            Path("/app"),
            None,
            version_table=None,
            x_args=("tenant=acme", "dry_run=True"),
        )


def test_sync_respects_create_schema_false() -> None:
    """Verify that DocTypes with create_schema=False are ignored by the sync command."""
    with (
        patch("framework_m_standard.cli.migrate.get_manager"),
        patch("framework_m_core.registry.MetaRegistry") as mock_reg,
        patch(
            "framework_m_standard.adapters.db.schema_mapper.SchemaMapper"
        ) as mock_mapper,
        patch("sqlalchemy.create_engine"),
    ):
        mock_reg_inst = mock_reg.get_instance.return_value
        mock_reg_inst.list_doctypes.return_value = ["VirtualDoc"]

        class MockVirtualDoc:
            class Meta:
                create_schema = False

        mock_reg_inst.get_doctype.return_value = MockVirtualDoc

        from framework_m_standard.cli.migrate import sync_command

        sync_command(path=Path("/app"), apps=None, dry_run=True)

        # SchemaMapper.create_tables should NOT be called since create_schema is False
        mock_mapper.return_value.create_tables.assert_not_called()
