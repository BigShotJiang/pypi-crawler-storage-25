"""Tests for migration environment validator."""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_standard.cli.migration_validator import validate_environment


def test_validate_environment_success_alembic_exists(tmp_path: Path) -> None:
    (tmp_path / "alembic").mkdir()
    errors = validate_environment(tmp_path, "sqlite+aiosqlite:///test.db")
    assert not errors


def test_validate_environment_success_skip_alembic(tmp_path: Path) -> None:
    errors = validate_environment(
        tmp_path, "sqlite+aiosqlite:///test.db", skip_alembic_check=True
    )
    assert not errors


def test_validate_environment_missing_alembic(tmp_path: Path) -> None:
    errors = validate_environment(tmp_path, "sqlite+aiosqlite:///test.db")
    assert len(errors) == 1
    assert "Alembic not initialized" in errors[0]


def test_validate_environment_invalid_sqlite_url(tmp_path: Path) -> None:
    (tmp_path / "alembic").mkdir()
    errors = validate_environment(tmp_path, "sqlite:///test.db")
    assert len(errors) == 1
    assert "Invalid database URL for async operation" in errors[0]


def test_validate_environment_invalid_url_from_env(tmp_path: Path) -> None:
    (tmp_path / "alembic").mkdir()
    with patch.dict(os.environ, {"DATABASE_URL": "sqlite:///env.db"}):
        errors = validate_environment(tmp_path)
        assert len(errors) == 1
        assert "Got: sqlite:///env.db" in errors[0]


@patch("importlib.metadata.entry_points")
@patch("importlib.util.find_spec")
def test_validate_environment_packaged_prod_mode(
    mock_find_spec: MagicMock, mock_entry_points: MagicMock, tmp_path: Path
) -> None:
    """Validation should pass in packaged mode if entry points have migrations."""
    # 1. Setup fake entry point for an installed app
    mock_ep = MagicMock()
    mock_ep.name = "my_packaged_app"
    mock_ep.value = "my_packaged_app.app:main"
    mock_entry_points.return_value = {"framework_m.apps": [mock_ep]}

    # 2. Setup a fake module spec and directory for the app
    app_path = tmp_path / "site-packages" / "my_packaged_app"
    (app_path / "migrations").mkdir(parents=True)
    mock_spec = MagicMock(origin=str(app_path / "__init__.py"))
    mock_find_spec.return_value = mock_spec

    # 3. Run the validator. This will fail until the validator is updated
    errors = validate_environment(tmp_path, "sqlite+aiosqlite:///test.db")
    assert not any("Alembic not initialized" in e for e in errors)
