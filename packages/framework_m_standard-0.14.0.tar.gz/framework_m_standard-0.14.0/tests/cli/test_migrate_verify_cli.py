"""Tests for the Migrate Verify CLI Integration."""

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.domain.migration_engine import ChangeType, RiskLevel, SchemaDiff
from framework_m_core.interfaces.introspection import ColumnMeta, TableMeta
from framework_m_standard.cli.migrate_verify import (
    get_introspection_adapter,
    run_verification,
    verify_migration_command,
)
from pydantic import BaseModel, Field


class MockUserDocType(BaseModel):
    """Mock DocType for testing schema generation."""

    id: int
    username: str = Field(max_length=50)
    is_active: bool

    @classmethod
    def get_apply_rls(cls) -> bool:
        return False

    @classmethod
    def get_indexes(cls) -> list:
        return []


class TestVerifyMigrationCLI:
    """Test suite for the migrate verify CLI command."""

    @patch("framework_m_standard.cli.migrate_verify.run_verification")
    def test_verify_migration_safe(
        self, mock_run_verification: AsyncMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should print safe messages and exit 0 for safe changes."""
        # Mock the workflow to return a SAFE schema difference
        mock_run_verification.return_value = [
            SchemaDiff(
                change_type=ChangeType.ADD_COLUMN,
                risk=RiskLevel.SAFE,
                column_name="new_field",
                message="Adding new column 'new_field'. This is a safe operation.",
            )
        ]

        verify_migration_command(engine="sqlalchemy")

        captured = capsys.readouterr()
        assert "SAFE" in captured.out or "SAFE" in captured.err
        assert (
            "Adding new column 'new_field'" in captured.out
            or "Adding new column 'new_field'" in captured.err
        )

    @patch("framework_m_standard.cli.migrate_verify.run_verification")
    def test_verify_migration_breaking(
        self, mock_run_verification: AsyncMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should print actionable advice for breaking changes and exit with 1."""
        # Mock the workflow to return a BREAKING schema difference
        mock_run_verification.return_value = [
            SchemaDiff(
                change_type=ChangeType.DROP_COLUMN,
                risk=RiskLevel.BREAKING,
                column_name="old_field",
                message="Dropping column 'old_field'. This is a breaking change requiring ZDM backfill patterns.",
            )
        ]

        with pytest.raises(SystemExit) as exc:
            verify_migration_command(engine="sqlalchemy")

        # Breaking changes should fail the CI pipeline
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "BREAKING" in captured.err
        assert "ZDM" in captured.err
        assert "backfill patterns" in captured.err

    @patch("framework_m_standard.cli.migrate_verify.run_verification")
    def test_verify_migration_warning(
        self, mock_run_verification: AsyncMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should print warning messages for warning-level changes."""
        mock_run_verification.return_value = [
            SchemaDiff(
                change_type=ChangeType.ALTER_COLUMN,
                risk=RiskLevel.WARNING,
                column_name="username",
                message="Column 'username' max_length is changing.",
            )
        ]

        verify_migration_command(engine="sqlalchemy")

        captured = capsys.readouterr()
        assert "WARNING" in captured.out or "WARNING" in captured.err
        assert (
            "max_length is changing" in captured.out
            or "max_length is changing" in captured.err
        )

    @patch("framework_m_standard.cli.migrate_verify.get_introspection_adapter")
    @patch("framework_m_standard.cli.migrate_verify.run_verification")
    def test_verify_migration_respects_engine_flag(
        self, mock_run_verification: AsyncMock, mock_get_adapter: AsyncMock
    ) -> None:
        """Should resolve the correct introspection adapter based on the --engine flag."""
        mock_run_verification.return_value = []

        # Mock the adapter factory to return a dummy adapter
        mock_adapter = AsyncMock()
        mock_get_adapter.return_value = mock_adapter

        # Test with default engine (sqlalchemy)
        verify_migration_command(engine="sqlalchemy")
        mock_get_adapter.assert_called_with("sqlalchemy")

        # Test with specific engine override (e.g., motor)
        verify_migration_command(engine="motor")
        mock_get_adapter.assert_called_with("motor")

    @patch("framework_m_standard.cli.migrate_verify.importlib.metadata.entry_points")
    def test_get_introspection_adapter_success(self, mock_eps: MagicMock) -> None:
        """Should correctly find and load the adapter from entry points."""
        mock_ep = MagicMock()
        mock_ep.name = "sqlalchemy"
        mock_ep.load.return_value = "MockSQLAlchemyAdapterClass"
        mock_eps.return_value = [mock_ep]

        adapter = get_introspection_adapter("sqlalchemy")
        assert adapter == "MockSQLAlchemyAdapterClass"
        mock_ep.load.assert_called_once()

    def test_get_introspection_adapter_not_found(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should exit with 1 if introspection engine is not found."""
        with (
            patch(
                "framework_m_standard.cli.migrate_verify.importlib.metadata.entry_points",
                return_value=[],
            ),
            pytest.raises(SystemExit) as exc,
        ):
            get_introspection_adapter("nonexistent_engine")

        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert (
            "Error: Introspection engine 'nonexistent_engine' not found."
            in captured.err
        )


class TestRunVerification:
    """Test suite for the run_verification logic."""

    @pytest.mark.asyncio
    @patch("framework_m_core.config.load_config")
    @patch("framework_m_core.registry.MetaRegistry")
    @patch("framework_m_standard.adapters.db.connection.ConnectionFactory")
    async def test_run_verification_empty_db(
        self,
        mock_conn_factory_cls: MagicMock,
        mock_meta_registry_cls: MagicMock,
        mock_load_config: MagicMock,
    ) -> None:
        """Test verification when database has no tables."""
        mock_load_config.return_value = {}

        mock_registry = MagicMock()
        mock_meta_registry_cls.get_instance.return_value = mock_registry
        mock_registry.list_doctypes.return_value = ["User"]
        mock_registry.get_doctype.return_value = MockUserDocType

        mock_conn_factory = MagicMock()
        mock_conn_factory_cls.return_value = mock_conn_factory
        mock_conn_factory.dispose_all = AsyncMock()

        mock_adapter = AsyncMock()
        mock_adapter.introspect_database.return_value = []
        mock_adapter_class = MagicMock(return_value=mock_adapter)

        with patch.dict(os.environ, {}, clear=False):
            diffs = await run_verification(mock_adapter_class, apps="auth, users")

        assert len(diffs) > 0
        # Since table is empty, all columns should be ADD_COLUMN
        assert any(
            d.column_name == "id" and d.change_type == ChangeType.ADD_COLUMN
            for d in diffs
        )
        assert any(
            d.column_name == "username" and d.change_type == ChangeType.ADD_COLUMN
            for d in diffs
        )
        assert any(
            d.column_name == "is_active" and d.change_type == ChangeType.ADD_COLUMN
            for d in diffs
        )

        mock_registry.load_apps.assert_called_with(["auth", "users"])
        mock_conn_factory.dispose_all.assert_called_once()

    @pytest.mark.asyncio
    @patch("framework_m_core.config.load_config")
    @patch("framework_m_core.registry.MetaRegistry")
    @patch("framework_m_standard.adapters.db.connection.ConnectionFactory")
    async def test_run_verification_existing_db(
        self,
        mock_conn_factory_cls: MagicMock,
        mock_meta_registry_cls: MagicMock,
        mock_load_config: MagicMock,
    ) -> None:
        """Test verification when database has existing tables and handles type mapping."""
        mock_load_config.return_value = {
            "database": {"url": "sqlite+aiosqlite:///custom.db"}
        }

        mock_registry = MagicMock()
        mock_meta_registry_cls.get_instance.return_value = mock_registry
        mock_registry.list_doctypes.return_value = ["User"]
        mock_registry.get_doctype.return_value = MockUserDocType

        mock_conn_factory = MagicMock()
        mock_conn_factory_cls.return_value = mock_conn_factory
        mock_conn_factory.dispose_all = AsyncMock()

        mock_adapter = AsyncMock()
        mock_adapter.introspect_database.return_value = [
            TableMeta(
                name="mockuserdoctype",
                columns=[
                    ColumnMeta(name="id", type="UUID", primary_key=True),
                    ColumnMeta(name="username", type="VARCHAR", max_length=255),
                    ColumnMeta(name="is_active", type="BOOLEAN"),
                    ColumnMeta(name="custom_fields", type="JSON"),
                ],
                indexes=[],
            )
        ]
        mock_adapter_class = MagicMock(return_value=mock_adapter)

        # Passing no apps and specific database_url to trigger those branches
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("INSTALLED_APPS", None)
            diffs = await run_verification(
                mock_adapter_class, database_url="sqlite:///override.db"
            )

        # We should have a diff because username max_length shrunk from 255 to 50
        assert len(diffs) == 1
        assert diffs[0].column_name == "username"
        assert diffs[0].change_type == ChangeType.ALTER_COLUMN
        assert diffs[0].risk == RiskLevel.WARNING

        assert mock_registry.load_apps.called

    @pytest.mark.asyncio
    @patch("framework_m_core.config.load_config")
    @patch("framework_m_core.registry.MetaRegistry")
    @patch("framework_m_standard.adapters.db.connection.ConnectionFactory")
    @patch("framework_m_standard.cli.migrate_verify.importlib.metadata.entry_points")
    async def test_run_verification_app_discovery_entry_points(
        self,
        mock_eps: MagicMock,
        mock_conn_factory_cls: MagicMock,
        mock_meta_registry_cls: MagicMock,
        mock_load_config: MagicMock,
    ) -> None:
        """Test app discovery via entry points when INSTALLED_APPS is not set."""
        mock_load_config.return_value = {}
        mock_registry = mock_meta_registry_cls.get_instance.return_value
        mock_conn_factory = mock_conn_factory_cls.return_value
        mock_conn_factory.dispose_all = AsyncMock()

        mock_ep = MagicMock()
        mock_ep.name = "my_plugin_app"
        mock_eps.return_value = [mock_ep]

        mock_adapter = AsyncMock()
        mock_adapter.introspect_database.return_value = []
        mock_adapter_class = MagicMock(return_value=mock_adapter)

        with patch.dict(os.environ, {}, clear=True):
            await run_verification(mock_adapter_class)

        mock_registry.load_apps.assert_called_with(["my_plugin_app"])

    @pytest.mark.asyncio
    @patch("framework_m_core.config.load_config")
    @patch("framework_m_core.registry.MetaRegistry")
    @patch("framework_m_standard.adapters.db.connection.ConnectionFactory")
    @patch(
        "framework_m_standard.cli.migrate_verify.importlib.metadata.entry_points",
        return_value=[],
    )
    @patch("framework_m_standard.cli.migrate_verify.Path")
    async def test_run_verification_app_discovery_src_fallback(
        self,
        mock_path_cls: MagicMock,
        mock_eps: MagicMock,
        mock_conn_factory_cls: MagicMock,
        mock_meta_registry_cls: MagicMock,
        mock_load_config: MagicMock,
    ) -> None:
        """Test app discovery via src/ directory fallback."""
        mock_load_config.return_value = {}
        mock_registry = mock_meta_registry_cls.get_instance.return_value
        mock_conn_factory = mock_conn_factory_cls.return_value
        mock_conn_factory.dispose_all = AsyncMock()

        mock_src_path = MagicMock()
        mock_src_path.exists.return_value = True
        mock_app_dir = MagicMock()
        mock_app_dir.is_dir.return_value = True
        mock_app_dir.name = "my_local_app"
        (mock_app_dir / "__init__.py").exists.return_value = True
        mock_src_path.iterdir.return_value = [mock_app_dir]
        mock_path_cls.return_value = mock_src_path

        mock_adapter = AsyncMock()
        mock_adapter.introspect_database.return_value = []
        mock_adapter_class = MagicMock(return_value=mock_adapter)

        with patch.dict(os.environ, {}, clear=True):
            await run_verification(mock_adapter_class)

        mock_registry.discover_doctypes.assert_called_with("my_local_app")

    @pytest.mark.asyncio
    @patch("framework_m_core.config.load_config", return_value={})
    @patch("framework_m_core.registry.MetaRegistry")
    @patch("framework_m_standard.adapters.db.connection.ConnectionFactory")
    async def test_run_verification_respects_create_schema_flags(
        self,
        mock_conn_factory_cls: MagicMock,
        mock_meta_registry_cls: MagicMock,
        mock_load_config: MagicMock,
    ) -> None:
        """Test that run_verification respects create_schema from _meta_config and Meta."""

        class MockDocTypeWithMetaConfig:
            _meta_config = MagicMock(create_schema=False)

        class MockDocTypeWithMetaClass:
            class Meta:
                create_schema = False

        class MockDocTypeWithNoSchemaFlag:
            pass

        mock_registry = mock_meta_registry_cls.get_instance.return_value
        mock_registry.list_doctypes.return_value = [
            "WithMetaConfig",
            "WithMetaClass",
            "NoFlag",
        ]
        mock_registry.get_doctype.side_effect = [
            MockDocTypeWithMetaConfig,
            MockDocTypeWithMetaClass,
            MockDocTypeWithNoSchemaFlag,
        ]
        mock_conn_factory = mock_conn_factory_cls.return_value
        mock_conn_factory.dispose_all = AsyncMock()
        mock_adapter = AsyncMock()
        mock_adapter.introspect_database.return_value = []
        mock_adapter_class = MagicMock(return_value=mock_adapter)

        with patch(
            "framework_m_standard.adapters.db.schema_mapper.SchemaMapper"
        ) as mock_mapper_cls:
            mock_mapper = mock_mapper_cls.return_value
            await run_verification(mock_adapter_class, apps="dummy")

        mock_mapper.create_tables.assert_called_once()
        assert mock_mapper.create_tables.call_args[0][0] == MockDocTypeWithNoSchemaFlag
