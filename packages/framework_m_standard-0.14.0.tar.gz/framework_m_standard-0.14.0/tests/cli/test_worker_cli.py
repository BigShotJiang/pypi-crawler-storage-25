"""Tests for Worker CLI core routing and registry."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.cli.worker import (
    get_worker_runners,
    worker_command,
)


def test_get_worker_runners_loads_entry_points() -> None:
    """get_worker_runners should discover runners via importlib entry_points."""
    mock_ep = MagicMock()
    mock_ep.name = "custom_test_runner"
    mock_ep.load.return_value = AsyncMock()

    with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
        runners = get_worker_runners()
        assert "custom_test_runner" in runners
        assert "taskiq" in runners
        assert "temporal" in runners


def test_worker_command_valid_type(capsys: pytest.CaptureFixture[str]) -> None:
    """worker_command should execute the registered runner."""
    mock_runner = AsyncMock()

    # Mock get_worker_runners to return our test runner
    runners_dict = {"test_runner": mock_runner}

    with patch(
        "framework_m_standard.cli.worker.get_worker_runners", return_value=runners_dict
    ):
        worker_command(worker_type="test_runner", concurrency=5, verbose=True)
        mock_runner.assert_called_once_with(concurrency=5)

        captured = capsys.readouterr()
        assert "Verbose mode enabled" in captured.out
        assert "Framework M Worker (Type: test_runner)" in captured.out


def test_worker_command_invalid_type(capsys: pytest.CaptureFixture[str]) -> None:
    """worker_command should fail and exit on unknown worker type."""
    runners_dict = {"taskiq": AsyncMock()}

    with (
        patch(
            "framework_m_standard.cli.worker.get_worker_runners",
            return_value=runners_dict,
        ),
        pytest.raises(SystemExit) as exc,
    ):
        worker_command(worker_type="nonexistent_runner")

    assert exc.value.code == 1
    captured = capsys.readouterr()
    combined_output = captured.out + captured.err
    assert "Unknown worker type 'nonexistent_runner'" in combined_output
    assert "Available types:" in combined_output


def test_worker_command_keyboard_interrupt(capsys: pytest.CaptureFixture[str]) -> None:
    """worker_command should handle KeyboardInterrupt gracefully."""
    mock_runner = MagicMock(side_effect=KeyboardInterrupt())
    runners_dict = {"interrupt_runner": mock_runner}

    with patch(
        "framework_m_standard.cli.worker.get_worker_runners", return_value=runners_dict
    ):
        worker_command(worker_type="interrupt_runner", concurrency=5, verbose=True)
        mock_runner.assert_called_once()


def test_worker_constants() -> None:
    """DEFAULT_CONCURRENCY and DEFAULT_NATS_URL should be defined correctly."""
    from framework_m_standard.cli.worker import DEFAULT_CONCURRENCY, DEFAULT_NATS_URL

    assert DEFAULT_CONCURRENCY >= 1
    assert "nats://" in DEFAULT_NATS_URL
