from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.cli.admin import (
    _create_local_user,
    _normalize_role,
    create_admin,
    create_user,
)


def test_normalize_role():
    assert _normalize_role(" admin ") == "Admin"
    assert _normalize_role("USER") == "User"
    assert _normalize_role("") == "User"
    assert _normalize_role("super") == "Super"


@pytest.mark.asyncio
async def test_create_local_user_implementation():
    with (
        patch("framework_m_core.config.load_config"),
        patch(
            "framework_m_standard.adapters.db.connection.ConnectionFactory"
        ) as mock_conn_factory,
        patch(
            "framework_m_standard.adapters.db.session.SessionFactory"
        ) as mock_session_factory,
        patch("framework_m_standard.adapters.db.schema_mapper.SchemaMapper"),
        patch(
            "framework_m_standard.adapters.db.repository_factory.RepositoryFactory"
        ) as mock_repo_factory,
    ):
        # Mock engine to handle async context manager correctly
        mock_engine = MagicMock()
        mock_engine.begin.return_value = AsyncMock()
        mock_conn_factory.return_value.get_engine.return_value = mock_engine
        mock_conn_factory.return_value.dispose_all = AsyncMock()

        mock_repo = MagicMock()
        mock_repo.list_entities = AsyncMock(return_value=MagicMock(items=[]))
        mock_repo_factory.return_value.get_repository.return_value = mock_repo

        # Mock session to handle execute
        mock_session = AsyncMock()
        mock_session_factory.return_value.get_session.return_value.__aenter__.return_value = mock_session

        # Test case 1: Successful creation with name missing in model_dump (covers line 137)
        mock_user = MagicMock()
        mock_user.model_dump.return_value = {
            "email": "test@example.com"
        }  # name missing
        mock_user.password_hash = "hash"

        with (
            patch("sqlalchemy.insert"),
            patch("framework_m_core.doctypes.user.LocalUser", return_value=mock_user),
            patch("framework_m_core.security.hash_password"),
        ):
            await _create_local_user(
                email="new@example.com",
                password="password123",
                full_name="New User",
                role="User",
            )

        assert mock_repo.list_entities.called
        assert mock_session.execute.called
        assert mock_conn_factory.return_value.dispose_all.called


@pytest.mark.asyncio
async def test_create_local_user_no_repo():
    with (
        patch("framework_m_core.config.load_config"),
        patch(
            "framework_m_standard.adapters.db.connection.ConnectionFactory"
        ) as mock_conn_factory,
        patch("framework_m_standard.adapters.db.session.SessionFactory"),
        patch("framework_m_standard.adapters.db.schema_mapper.SchemaMapper"),
        patch(
            "framework_m_standard.adapters.db.repository_factory.RepositoryFactory"
        ) as mock_repo_factory,
    ):
        mock_engine = MagicMock()
        mock_engine.begin.return_value = AsyncMock()
        mock_conn_factory.return_value.get_engine.return_value = mock_engine
        mock_conn_factory.return_value.dispose_all = AsyncMock()
        mock_repo_factory.return_value.get_repository.return_value = None

        with pytest.raises(
            RuntimeError, match="LocalUser repository could not be initialized"
        ):
            await _create_local_user("test@example.com", "pass", "Name", "User")


def test_create_user_entrypoint():
    with (
        patch("asyncio.run"),
        patch("framework_m_standard.cli.admin._normalize_role"),
        patch("framework_m_standard.cli.admin._create_local_user"),
    ):
        create_user(
            email="test@test.com",
            password="password123",
            full_name="Full Name",
            role="User",
        )


def test_create_user_interactive_errors():
    # Test missing email
    with patch("builtins.input", return_value=""), pytest.raises(SystemExit):
        create_user(email=None)

    # Test missing password
    with (
        patch("builtins.input", return_value="user@example.com"),
        patch("getpass.getpass", return_value=""),
        pytest.raises(SystemExit),
    ):
        create_user(email=None, password=None)

    # Test short password
    with (
        patch("builtins.input", return_value="user@example.com"),
        patch("getpass.getpass", return_value="short"),
        pytest.raises(SystemExit),
    ):
        create_user(email=None, password=None)

    # Test invalid email
    with (
        patch("builtins.input", side_effect=["invalid", "password123", "User"]),
        patch("getpass.getpass", return_value="password123"),
        pytest.raises(SystemExit),
    ):
        create_user(email=None, password=None)


def test_create_admin_entrypoint():
    with patch("framework_m_standard.cli.admin.create_user") as mock_create:
        create_admin(email="admin@test.com", password="password123")
        mock_create.assert_called_once_with(
            email="admin@test.com",
            password="password123",
            full_name="Administrator",
            role="Admin",
        )


@pytest.mark.asyncio
async def test_create_local_user_exists(capsys):
    with (
        patch("framework_m_core.config.load_config"),
        patch(
            "framework_m_standard.adapters.db.connection.ConnectionFactory"
        ) as mock_conn_factory,
        patch(
            "framework_m_standard.adapters.db.session.SessionFactory"
        ) as mock_session_factory,
        patch("framework_m_standard.adapters.db.schema_mapper.SchemaMapper"),
        patch(
            "framework_m_standard.adapters.db.repository_factory.RepositoryFactory"
        ) as mock_repo_factory,
    ):
        mock_engine = MagicMock()
        mock_engine.begin.return_value = AsyncMock()
        mock_conn_factory.return_value.get_engine.return_value = mock_engine
        mock_conn_factory.return_value.dispose_all = AsyncMock()

        mock_repo = MagicMock()
        mock_repo.list_entities = AsyncMock(
            return_value=MagicMock(items=[MagicMock(id="1")])
        )
        mock_repo_factory.return_value.get_repository.return_value = mock_repo

        mock_session = AsyncMock()
        mock_session_factory.return_value.get_session.return_value.__aenter__.return_value = mock_session

        await _create_local_user("exists@example.com", "password123", "User", "User")

        captured = capsys.readouterr()
        assert "already exists" in (captured.out + captured.err)
