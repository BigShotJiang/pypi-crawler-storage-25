"""Worker CLI - Background job processing command.

This module provides the `m worker` CLI command for running
Taskiq workers that process background jobs from NATS JetStream.
It can also be used to run Temporal workflow workers.

Usage:
    m worker                             # Start background job worker (Taskiq)
    m worker --worker-type=temporal      # Start durable workflow worker (Temporal)
    m worker --concurrency 4             # Start Taskiq with 4 concurrent workers
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import sys
from collections.abc import Callable, Coroutine
from typing import TYPE_CHECKING, Annotated, Any, cast

import cyclopts
from framework_m_core.cli.utility import console

if TYPE_CHECKING:
    from taskiq import AsyncBroker

# Default worker configuration
DEFAULT_CONCURRENCY = 4
DEFAULT_NATS_URL = "nats://localhost:4222"

# Define the generic worker runner protocol
WorkerRunner = Callable[..., Coroutine[Any, Any, None]]


def get_worker_runners() -> dict[str, WorkerRunner]:
    """Discover and return all registered worker runners via entry points."""
    runners: dict[str, WorkerRunner] = {
        "taskiq": _run_taskiq_worker_wrapper,
        "temporal": _run_temporal_worker_async,
    }

    try:
        from importlib.metadata import entry_points

        # Python 3.10+ syntax for entry points
        eps = entry_points(group="framework_m.workers")
        for ep in eps:
            runners[ep.name] = ep.load()
    except Exception as e:
        import logging

        logging.warning(f"Failed to load worker plugins: {e}")

    return runners


def get_nats_url() -> str:
    """Get NATS URL from environment or default.

    Returns:
        NATS server URL
    """
    return os.environ.get("NATS_URL", DEFAULT_NATS_URL)


def get_broker() -> AsyncBroker:
    """Get or create the Taskiq broker.

    Returns:
        Configured Taskiq broker for NATS JetStream
    """
    from framework_m_standard.adapters.jobs.taskiq_adapter import create_taskiq_broker

    return cast("AsyncBroker", create_taskiq_broker(nats_url=get_nats_url()))


def discover_jobs() -> list[str]:
    """Discover all registered jobs.

    Scans the global job registry for registered job handlers.

    Returns:
        List of registered job names
    """
    from framework_m_standard.adapters.jobs.taskiq_adapter import get_global_registry

    registry = get_global_registry()
    return registry.list()


async def load_scheduled_jobs() -> list[dict[str, str]]:
    """Load enabled scheduled jobs from database.

    Queries the ScheduledJob DocType for enabled jobs and
    returns them in Taskiq schedule format. Also includes
    built-in system jobs like outbox processing.

    Returns:
        List of schedule dicts with 'task_name' and 'cron' keys

    Example:
        >>> schedules = await load_scheduled_jobs()
        >>> # [{"task_name": "daily_report", "cron": "0 9 * * *"}]
    """
    # Built-in system jobs
    schedules: list[dict[str, str]] = [
        # Process outbox entries every minute
        {"task_name": "process_outbox", "cron": "* * * * *"},
    ]

    try:
        from framework_m_core.doctypes.scheduled_job import ScheduledJob

        # Query enabled jobs only
        # Note: This uses the DocType query API from Phase 02
        # If not available yet, gracefully return empty list
        jobs = await ScheduledJob.query().filter(enabled=True).all()  # type: ignore[attr-defined]

        schedules.extend(
            [
                {
                    "task_name": job.name,
                    "cron": job.cron_expression,
                }
                for job in jobs
            ]
        )
    except Exception:
        # If ScheduledJob not available or DB not ready, return built-in only
        # This allows worker to start even without full DocType system
        pass

    return schedules


async def _run_worker_async(
    broker: AsyncBroker,
    concurrency: int = DEFAULT_CONCURRENCY,
) -> None:
    """Run the Taskiq worker asynchronously.

    Args:
        broker: Configured Taskiq broker
        concurrency: Number of concurrent workers
    """
    # Discover and log registered jobs
    jobs = discover_jobs()
    if jobs:
        console.info(f"Discovered {len(jobs)} jobs: {', '.join(jobs)}")
    else:
        console.warning("No jobs discovered. Register jobs with @job decorator.")

    console.info(f"Starting worker with concurrency={concurrency}...")
    console.info(f"NATS URL: {get_nats_url()}")

    try:
        # Import and run the Taskiq receiver
        from taskiq.receiver import Receiver

        # Start the broker first
        await broker.startup()

        # Create receiver with run_startup=False since we already called startup
        finish_event = asyncio.Event()
        receiver = Receiver(broker, max_async_tasks=concurrency, run_startup=False)

        console.info("Worker listening for jobs... (Ctrl+C to stop)")
        await receiver.listen(finish_event)
    except KeyboardInterrupt:
        console.print("\n[bold yellow]Shutting down worker...[/bold yellow]")
    finally:
        await broker.shutdown()


async def _run_temporal_worker_async(**kwargs: Any) -> None:
    """Run the Temporal workflow worker asynchronously."""
    from framework_m_core.container import Container

    from framework_m_standard.adapters.workflow.temporal_worker import (
        TemporalWorkerAdapter,
    )

    namespace = os.environ.get("TEMPORAL_NAMESPACE", "default")
    task_queue = os.environ.get("TEMPORAL_TASK_QUEUE", "framework-m-workflows")
    temporal_url = os.environ.get("TEMPORAL_URL", "localhost:7233")

    adapter = TemporalWorkerAdapter(
        namespace=namespace, task_queue=task_queue, host=temporal_url
    )

    # Resolve and inject secrets manager from container
    container = Container()
    if hasattr(container, "secrets_manager"):
        adapter.set_secrets_manager(container.secrets_manager())

    console.info(f"Starting Temporal worker on {temporal_url} (queue: {task_queue})...")
    await adapter.start()

    stop_event = asyncio.Event()
    try:
        console.info(
            "Temporal Worker listening for workflows and activities... (Ctrl+C to stop)"
        )
        await stop_event.wait()
    except asyncio.CancelledError:
        pass
    finally:
        console.print("\n[bold yellow]Shutting down Temporal worker...[/bold yellow]")
        await adapter.stop()


async def _run_taskiq_worker_wrapper(
    concurrency: int = DEFAULT_CONCURRENCY, **kwargs: Any
) -> None:
    """Wrapper to run the default Taskiq worker."""
    broker = get_broker()
    await _run_worker_async(broker, concurrency)


def run_worker(concurrency: int = DEFAULT_CONCURRENCY) -> None:
    """Run the default Taskiq worker (synchronous wrapper for backwards compatibility)."""
    runners = get_worker_runners()
    asyncio.run(runners["taskiq"](concurrency=concurrency))


def worker_command(
    worker_type: Annotated[
        str,
        cyclopts.Parameter(
            name="--worker-type", help="Type of worker to run (e.g. taskiq, temporal)"
        ),
    ] = "taskiq",
    concurrency: Annotated[
        int,
        cyclopts.Parameter(name="--concurrency", help="Number of concurrent workers"),
    ] = DEFAULT_CONCURRENCY,
    verbose: Annotated[
        bool,
        cyclopts.Parameter(name="--verbose", help="Enable verbose logging"),
    ] = False,
) -> None:
    """Start a background worker for processing async jobs or workflows.

    By default, connects to NATS JetStream ('taskiq') and processes jobs.
    Use --worker-type=temporal to execute durable workflows instead.

    Examples:
        m worker                             # Default (Taskiq)
        m worker --worker-type=temporal      # Start Temporal worker
        m worker --concurrency 8             # 8 concurrent Taskiq workers
        NATS_URL=nats://prod:4222 m worker
    """
    from framework_m_core.registry import MetaRegistry

    from framework_m_standard.adapters.discovery import (
        get_project_root,
        resolve_app_modules,
    )

    if verbose:
        console.info("Verbose mode enabled")

    console.print(f"[bold cyan]Framework M Worker (Type: {worker_type})[/bold cyan]")
    console.print("=" * 40)

    registry = MetaRegistry.get_instance()
    apps = resolve_app_modules(get_project_root())
    registry.load_apps(apps)

    runners = get_worker_runners()
    if worker_type not in runners:
        console.error(f"Error: Unknown worker type '{worker_type}'.")
        console.info(f"Available types: {', '.join(runners.keys())}")
        sys.exit(1)

    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(runners[worker_type](concurrency=concurrency))


__all__ = [
    "DEFAULT_CONCURRENCY",
    "DEFAULT_NATS_URL",
    "_run_worker_async",
    "_run_temporal_worker_async",
    "get_worker_runners",
    "discover_jobs",
    "get_broker",
    "get_nats_url",
    "load_scheduled_jobs",
    "run_worker",
    "worker_command",
]
