"""Job CLI Commands - Job management from command line.

This module provides CLI commands for managing background jobs:
- job list - List registered jobs
- job run - Run a job immediately
- job status - Check job status

Usage:
    m job list              # List all registered jobs
    m job run send_email    # Run job immediately
    m job status job-123    # Check job status
"""

from __future__ import annotations

import asyncio
from typing import Annotated, Any

import cyclopts
from framework_m_core.cli.utility import console
from rich.table import Table

job_app = cyclopts.App(name="job", help="Job management commands")


@job_app.command(name="list")
def list_jobs() -> None:
    """List all registered job handlers.

    Shows all jobs that have been registered with the @job decorator.
    """
    from framework_m_standard.adapters.jobs.taskiq_adapter import get_global_registry

    registry = get_global_registry()
    jobs = registry.list()

    if not jobs:
        console.warning("No jobs registered.")
        console.print("Register jobs using the @job decorator:")
        console.print("  @job(name='my_job')")
        console.print("  async def my_job(): ...")
        return

    table = Table(title=f"Registered jobs ({len(jobs)})")
    table.add_column("Job Name", style="cyan")
    table.add_column("Retry", style="green")
    table.add_column("Timeout", style="yellow")

    for job_name in sorted(jobs):
        metadata = registry.get_metadata(job_name)
        retry = metadata.get("retry", 3)
        timeout = metadata.get("timeout", 300)
        table.add_row(job_name, str(retry), f"{timeout}s")

    console.print(table)


@job_app.command(name="run")
def run_job(
    name: Annotated[str, cyclopts.Parameter(help="Name of the job to run")],
    kwargs_json: Annotated[
        str,
        cyclopts.Parameter(name="--kwargs", help="JSON string of keyword arguments"),
    ] = "{}",
) -> None:
    """Run a job immediately.

    Enqueues the job for immediate processing. The job runs
    asynchronously in the worker process.
    """
    import json

    from framework_m_standard.adapters.jobs.taskiq_adapter import get_global_registry

    registry = get_global_registry()

    if name not in registry.list():
        console.error(f"Error: Job '{name}' is not registered.")
        console.info("Use 'job list' to see available jobs.")
        raise SystemExit(1)

    # Parse kwargs
    try:
        kwargs: dict[str, Any] = json.loads(kwargs_json)
    except json.JSONDecodeError as e:
        console.error(f"Error: Invalid JSON in --kwargs: {e}")
        raise SystemExit(1) from e

    async def _run() -> str:
        from framework_m_standard.adapters.factory import get_job_queue

        queue = get_job_queue()
        job_id = await queue.enqueue(name, **kwargs)
        return job_id

    console.info(f"Enqueueing job '{name}'...")
    job_id = asyncio.run(_run())
    console.success(f"Job enqueued: {job_id}")
    console.info(f"Use 'job status {job_id}' to check status.")


@job_app.command(name="status")
def job_status(
    job_id: Annotated[str, cyclopts.Parameter(help="Job ID to check")],
) -> None:
    """Check the status of a job.

    Shows the current status, timestamps, and result/error
    for a specific job.
    """

    async def get_status() -> None:
        from framework_m_standard.adapters.factory import get_job_queue

        queue = get_job_queue()
        status_info = await queue.get_status(job_id)

        if status_info is None:
            console.error(f"Job '{job_id}' not found.")
            raise SystemExit(1)

        console.print(f"Job: [bold]{status_info.name}[/bold]")
        console.print(f"ID: {status_info.id}")
        console.print(f"Status: {status_info.status.value}")

        if status_info.enqueued_at:
            console.print(f"Enqueued: {status_info.enqueued_at.isoformat()}")
        if status_info.started_at:
            console.print(f"Started: {status_info.started_at.isoformat()}")
        if status_info.completed_at:
            console.print(f"Completed: {status_info.completed_at.isoformat()}")

        if status_info.error:
            console.error(f"Error: {status_info.error}")
        if status_info.result:
            console.success(f"Result: {status_info.result}")

    asyncio.run(get_status())


__all__ = [
    "job_app",
]


# Alias for backward compatibility with stale entry points
jobs_command = job_app
