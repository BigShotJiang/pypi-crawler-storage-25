"""Migration CLI commands for Framework M.

This module provides CLI commands for database migrations:
- m migrate: Run pending migrations
- m migrate create: Create a new migration
- m migrate rollback: Rollback the last migration
- m migrate status: Show current migration status
- m migrate verify: Verify the desired blueprint schema against the current database
"""

from __future__ import annotations

import contextlib
import os
from pathlib import Path
from typing import Annotated, cast

import cyclopts
from framework_m_core.cli.utility import console
from rich.table import Table

from framework_m_standard.adapters.db.schema_detector import SchemaChangeType

# Load .env from current directory, then parent directories
try:
    from dotenv import load_dotenv

    # Try current directory first
    if Path(".env").exists():
        load_dotenv(".env")
    # Then try parent directories (for monorepo structure)
    elif Path("../../.env").exists():
        load_dotenv("../../.env")
    elif Path("../.env").exists():
        load_dotenv("../.env")
except ImportError:  # pragma: no cover
    pass  # dotenv not installed, skip env loading

from framework_m_standard.adapters.db.migration import MigrationManager
from framework_m_standard.cli.migrate_verify import verify_migration_command

# Create the migrate command group
migrate_app = cyclopts.App(
    name="migrate",
    help="Database migration commands",
)
# Register the verify command from migrate_verify
migrate_app.command(name="verify")(verify_migration_command)


def get_manager(
    path: Path,
    database_url: str | None = None,
    skip_alembic_check: bool = False,
    version_table: str | None = None,
    x_args: tuple[str, ...] | None = None,
) -> MigrationManager:
    """Create a MigrationManager instance.

    Args:
        path: Base path for the application
        database_url: Optional database URL
        skip_alembic_check: Skip checking if alembic directory exists (for init command)

    Returns:
        Configured MigrationManager

    Raises:
        SystemExit: If alembic directory not found or database URL is invalid
    """
    from framework_m_core.container import Container, load_overrides

    container = Container()
    load_overrides(container, group="framework_m.*")

    if database_url is None:
        secrets = container.secrets_manager()
        database_url = secrets.get("DATABASE_URL")

    from framework_m_standard.cli.migration_validator import validate_environment

    errors = validate_environment(path, database_url, skip_alembic_check)
    if errors:  # pragma: no cover
        for error in errors:
            console.error(f"✗ Error: {error}")
        raise SystemExit(1)

    return cast(
        MigrationManager,
        container.migration_manager(
            base_path=path,
            database_url=database_url,
            version_table=version_table,
            x_args=x_args,
        ),
    )


@migrate_app.default
@migrate_app.command(name="run")
def migrate(
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--database-url",
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
    revision: Annotated[
        str,
        cyclopts.Parameter(name="--revision", help="Target revision (default: head)"),
    ] = "head",
    apps: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--apps", help="Comma-separated list of apps to migrate"
        ),
    ] = None,
    version_table: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--version-table", help="Custom Alembic version table name"
        ),
    ] = None,
    x_args: Annotated[
        tuple[str, ...] | None,
        cyclopts.Parameter(
            name=["-x", "--x-arg"],
            help="Additional arguments consumed by custom env.py scripts",
        ),
    ] = None,
) -> None:
    """Run pending database migrations.

    By default, upgrades to the latest revision (head).
    Can be called as 'm migrate' or 'm migrate run'.
    """
    if apps:  # pragma: no cover
        os.environ["INSTALLED_APPS"] = apps

    manager = get_manager(
        path, database_url, version_table=version_table, x_args=x_args
    )

    console.print(f"Running migrations in {path.resolve()}...")
    try:
        manager.upgrade(revision)
        console.success("✓ Migrations completed successfully")
    except Exception as e:  # pragma: no cover
        console.error(f"✗ Migration failed: {e}")
        raise SystemExit(1) from e


@migrate_app.command
def create(
    message: Annotated[str, cyclopts.Parameter(help="Migration description")],
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--database-url",
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
    autogenerate: Annotated[
        bool,
        cyclopts.Parameter(name="--autogenerate", help="Auto-detect schema changes"),
    ] = True,
    apps: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--apps", help="Comma-separated list of apps to include"
        ),
    ] = None,
    app: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--app", help="Target app/package to store the migration in"
        ),
    ] = None,
) -> None:
    """Create a new migration file.

    Creates a new Alembic revision with the specified message.
    Use --no-autogenerate for an empty migration template.
    """
    import importlib.util

    if apps:  # pragma: no cover
        os.environ["INSTALLED_APPS"] = apps

    # Determine version_path if --app is provided
    version_path = None
    if app:
        spec = importlib.util.find_spec(app)
        if not spec or not spec.origin:  # pragma: no cover
            console.error(f"Error: Could not find package/app '{app}'")
            return

        package_path = Path(spec.origin).parent
        version_path = package_path / "alembic" / "versions"
        if not version_path.exists():  # pragma: no cover
            console.warning(f"Location {version_path} does not exist. Creating it.")
            version_path.mkdir(parents=True, exist_ok=True)

    manager = get_manager(path, database_url)

    console.print(f"Creating migration: {message}")
    try:
        manager.revision(message, autogenerate=autogenerate, version_path=version_path)
        console.success("✓ Migration created successfully")
    except Exception as e:  # pragma: no cover
        console.error(f"✗ Failed to create migration: {e}")
        raise SystemExit(1) from e


@migrate_app.command
def rollback(
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--database-url",
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
    steps: Annotated[
        int,
        cyclopts.Parameter(name="--steps", help="Number of migrations to rollback"),
    ] = 1,
    apps: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--apps", help="Comma-separated list of apps (optional)"
        ),
    ] = None,
) -> None:
    """Rollback database migrations.

    By default, rolls back one migration. Use --steps to rollback more.
    """
    if apps:  # pragma: no cover
        os.environ["INSTALLED_APPS"] = apps

    manager = get_manager(path, database_url)

    revision = f"-{steps}"
    console.print(f"Rolling back {steps} migration(s)...")
    try:
        manager.downgrade(revision)
        console.success("✓ Rollback completed successfully")
    except Exception as e:  # pragma: no cover
        console.error(f"✗ Rollback failed: {e}")
        raise SystemExit(1) from e


@migrate_app.command
def status(
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--database-url",
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
    apps: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--apps", help="Comma-separated list of apps to include"
        ),
    ] = None,
) -> None:
    """Show current migration status.

    Displays the current database revision information.
    """
    if apps:  # pragma: no cover
        os.environ["INSTALLED_APPS"] = apps

    manager = get_manager(path, database_url)

    console.print("Migration Status:")
    console.print("-" * 40)
    try:
        manager.current()
    except Exception as e:  # pragma: no cover
        console.error(f"✗ Failed to get status: {e}")
        raise SystemExit(1) from e


@migrate_app.command
def history(
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--database-url",
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
    apps: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--apps", help="Comma-separated list of apps to include"
        ),
    ] = None,
) -> None:
    """Show migration history.

    Lists all migrations in chronological order.
    """
    if apps:  # pragma: no cover
        os.environ["INSTALLED_APPS"] = apps

    manager = get_manager(path, database_url)

    console.print("Migration History:")
    console.print("-" * 40)
    try:
        manager.history()
    except Exception as e:  # pragma: no cover
        console.error(f"✗ Failed to get history: {e}")
        raise SystemExit(1) from e


@migrate_app.command(name="init")
def init_alembic(
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--database-url",
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
) -> None:
    """Initialize Alembic for this project.

    Creates the alembic directory structure and configuration files.
    """
    manager = get_manager(path, database_url, skip_alembic_check=True)

    console.print(f"Initializing Alembic in {path.resolve()}...")
    try:
        manager.init()
        console.success("✓ Alembic initialized successfully")
        console.print(f"  Created: {manager.alembic_path}")
    except Exception as e:  # pragma: no cover
        console.error(f"✗ Initialization failed: {e}")
        raise SystemExit(1) from e


@migrate_app.command(name="sync")
def sync_command(
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name=["--database-url", "-d"],
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
    apps: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--apps", help="Comma-separated list of apps to include"
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        cyclopts.Parameter(name="--dry-run", help="Show changes without applying"),
    ] = False,
    allow_drop: Annotated[
        bool,
        cyclopts.Parameter(name="--allow-drop", help="Allow dropping tables/columns"),
    ] = False,
    allow_dangerous: Annotated[
        bool,
        cyclopts.Parameter(
            name="--allow-dangerous", help="Allow dangerous DDL (e.g. NOT NULL columns)"
        ),
    ] = False,
    max_lock_time: Annotated[
        int | None,
        cyclopts.Parameter(
            name="--max-lock-time", help="Max lock time in seconds for DDL operations"
        ),
    ] = None,
    tenant: Annotated[
        str | None,
        cyclopts.Parameter(name="--tenant", help="Tenant ID for schema-scoped sync"),
    ] = None,
) -> None:
    """Sync database schema directly from DocTypes (Frappe-style).

    Bypasses Alembic version files and applies DDL directly.
    Recommended for development and rapid prototyping.
    """
    import importlib.metadata
    import importlib.util

    from framework_m_core.registry import MetaRegistry
    from sqlalchemy import MetaData, create_engine

    apps_str = apps or os.environ.get("INSTALLED_APPS")
    apps_list = []

    if apps_str:
        os.environ["INSTALLED_APPS"] = apps_str
        apps_list = [a.strip() for a in apps_str.split(",") if a.strip()]
        MetaRegistry.get_instance().load_apps(apps_list)
    else:
        # Discover modular apps via entry points (ADR 0011)
        apps_list = [
            ep.name for ep in importlib.metadata.entry_points(group="framework_m.apps")
        ]
        if apps_list:
            MetaRegistry.get_instance().load_apps(apps_list)
        else:
            # Monolithic fallback
            with contextlib.suppress(Exception):
                MetaRegistry.get_instance().load_apps(
                    ["framework_m_core", "framework_m_standard"]
                )
            if Path("src").exists():
                for item in Path("src").iterdir():
                    if item.is_dir() and (item / "__init__.py").exists():
                        MetaRegistry.get_instance().discover_doctypes(item.name)

    if database_url is None:
        from framework_m_core.container import Container, load_overrides

        container = Container()
        load_overrides(container, group="framework_m.*")
        secrets = container.secrets_manager()
        db_url = secrets.get("DATABASE_URL", "sqlite+aiosqlite:///dev.db")
    else:
        db_url = database_url
    # Ensure sync URL for schema reflection/DDL (remove async prefixes)
    sync_url = db_url.replace("+aiosqlite", "").replace("+asyncpg", "")

    from framework_m_core.container import Container, load_overrides

    container = Container()
    load_overrides(container, group="framework_m.*")

    engine = create_engine(sync_url)
    metadata = MetaData(schema=tenant) if tenant else MetaData()
    mapper = container.schema_mapper()
    registry = MetaRegistry.get_instance()

    # Build target metadata from registered DocTypes
    for name in registry.list_doctypes():
        doctype_class = registry.get_doctype(name)
        create_schema = True
        is_tenant_specific = False

        if hasattr(doctype_class, "_meta_config"):
            create_schema = getattr(doctype_class._meta_config, "create_schema", True)
            is_tenant_specific = getattr(
                doctype_class._meta_config, "is_tenant_specific", False
            )
        elif hasattr(doctype_class, "Meta"):
            create_schema = getattr(doctype_class.Meta, "create_schema", True)
            is_tenant_specific = getattr(
                doctype_class.Meta, "is_tenant_specific", False
            )

        # Enforce multi-tenancy isolation
        if tenant and not is_tenant_specific:
            continue
        if not tenant and is_tenant_specific:
            continue

        if create_schema:
            mapper.create_tables(doctype_class, metadata)

    manager = get_manager(path, database_url)

    # Discover and execute before_sync hooks
    hooks = []
    if apps_list:  # pragma: no cover
        for app_name in apps_list:  # pragma: no cover
            try:
                module = importlib.import_module(f"{app_name}.migrations")
                before = getattr(module, "before_sync", None)
                after = getattr(module, "after_sync", None)
                if before or after:
                    hooks.append((app_name, before, after))
            except ImportError:  # pragma: no cover
                continue

    # 1. Execute BEFORE hooks
    if hooks:  # pragma: no cover
        console.info("Executing before_sync hooks...")
        for app_name, before, _ in hooks:
            if before:
                console.print(f"  [{app_name}] before_sync...")
                before(engine=engine)

    # 2. Perform DDL Sync
    tenant_info = f" (Tenant: {tenant})" if tenant else ""
    console.info(
        f"Syncing schema for {len(registry.list_doctypes())} DocTypes{tenant_info}..."
    )
    changes = manager.auto_migrate(
        target_metadata=metadata,
        dev_mode=True,
        dry_run=dry_run,
        engine=engine,
        allow_drop=allow_drop,
        allow_dangerous=allow_dangerous,
        max_lock_time=max_lock_time,
    )

    if not changes:
        console.success("✓ Schema is already up to date.")
    else:
        added_count = 0
        changed_count = 0
        dropped_count = 0

        for change in changes:
            if change.change_type in (
                SchemaChangeType.NEW_TABLE,
                SchemaChangeType.NEW_COLUMN,
                SchemaChangeType.NEW_INDEX,
            ):
                color = "green"
                added_count += 1
            elif change.change_type == SchemaChangeType.TYPE_CHANGE:
                color = "yellow"
                changed_count += 1
            else:
                color = "red"
                dropped_count += 1

            detail = f".{change.column_name}" if change.column_name else ""
            console.print(
                f"  [{color}]{change.change_type.value}: {change.table_name}{detail}[/{color}]"
            )

        summary = Table(title="Migration Summary")
        summary.add_column("Operation")
        summary.add_column("Count", justify="right")
        summary.add_row("[green]Added[/green]", str(added_count))
        summary.add_row("[yellow]Modified[/yellow]", str(changed_count))
        summary.add_row("[red]Dropped[/red]", str(dropped_count))

        console.print()
        console.print(summary)

        if not dry_run:  # pragma: no cover
            console.success("✓ Schema synced successfully.")

    # 3. Execute AFTER hooks
    if hooks and not dry_run:  # pragma: no cover
        console.info("Executing after_sync hooks...")
        for app_name, _, after in hooks:
            if after:
                console.print(f"  [{app_name}] after_sync...")
                after(engine=engine)

    engine.dispose()


@migrate_app.command(name="all")
def all_command(
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name=["--database-url", "-d"],
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
    apps: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--apps", help="Comma-separated list of apps to include"
        ),
    ] = None,
    tenant: Annotated[
        str | None,
        cyclopts.Parameter(name="--tenant", help="Tenant ID for schema-scoped sync"),
    ] = None,
) -> None:
    """Run all migrations (Patches + Sync).

    Equivalent to running 'm migrate run' followed by 'm migrate sync'.
    This is the recommended command for most deployments.
    """
    if apps:  # pragma: no cover
        os.environ["INSTALLED_APPS"] = apps

    # 1. Run Alembic Patches
    console.info("Step 1: Running versioned patches (Alembic)...")
    try:
        migrate(path=path, database_url=database_url, apps=apps)
    except SystemExit as e:  # pragma: no cover
        if e.code != 0:
            raise

    # 2. Run Declarative Sync
    console.info("\nStep 2: Running declarative sync (DocTypes)...")
    try:
        sync_command(path=path, database_url=database_url, apps=apps, tenant=tenant)
    except SystemExit as e:  # pragma: no cover
        if e.code != 0:
            raise


__all__ = [
    "get_manager",
    "migrate_app",
]

# Alias for backward compatibility with stale entry points
migrate_command = migrate_app
