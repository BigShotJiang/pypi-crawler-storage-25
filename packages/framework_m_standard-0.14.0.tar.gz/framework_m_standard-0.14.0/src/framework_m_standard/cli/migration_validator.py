"""Migration environment validation logic."""

import importlib.metadata
import importlib.util
import os
from pathlib import Path


def _has_packaged_migrations() -> bool:
    """Check if any installed apps provide migration directories."""
    installed_apps_raw = os.environ.get("INSTALLED_APPS", "")
    apps = []
    if installed_apps_raw:
        apps = [a.strip() for a in installed_apps_raw.split(",") if a.strip()]
    else:
        try:
            eps = importlib.metadata.entry_points()
            if isinstance(eps, dict):
                app_eps = eps.get("framework_m.apps", [])
            else:
                app_eps = eps.select(group="framework_m.apps")
            apps = [ep.name for ep in app_eps]
        except Exception:
            pass

    for app_name in apps:
        try:
            spec = importlib.util.find_spec(app_name)
            if spec and spec.origin:
                package_path = Path(spec.origin).parent
                if (package_path / "migrations").is_dir() or (
                    package_path / "alembic" / "versions"
                ).is_dir():
                    return True
        except Exception:
            continue

    return False


def validate_environment(
    path: Path, database_url: str | None = None, skip_alembic_check: bool = False
) -> list[str]:
    """Validate the environment for running migrations.

    Args:
        path: Base path for the application
        database_url: Optional database URL
        skip_alembic_check: Skip checking if alembic directory exists

    Returns:
        List of error messages. Empty list if environment is valid.
    """
    errors = []

    alembic_dir = path / "alembic"
    if (
        not skip_alembic_check
        and not alembic_dir.exists()
        and not _has_packaged_migrations()
    ):
        errors.append(
            f"Alembic not initialized in {path.absolute()}\n"
            f"  Expected to find: {alembic_dir}\n\n"
            f"  Run 'm migrate init' first, or specify --path to your app directory:\n"
            f"    cd apps/test_app && m migrate init\n"
            f"    m migrate status --path apps/test_app"
        )

    db_url = database_url or os.environ.get("DATABASE_URL", "")
    if (
        db_url
        and db_url.startswith("sqlite://")
        and not db_url.startswith("sqlite+aiosqlite://")
    ):
        errors.append(
            f"Invalid database URL for async operation\n"
            f"  Got: {db_url}\n"
            f"  Use 'sqlite+aiosqlite:///' instead of 'sqlite:///'\n\n"
            f"  Example:\n"
            f"    DATABASE_URL='sqlite+aiosqlite:///./dev.db' m migrate status"
        )

    return errors
