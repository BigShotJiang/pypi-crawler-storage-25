"""User management CLI commands.

Provides:
- ``m create-user`` for creating users with a selected role
- ``m create-admin`` as a backward-compatible alias for admin creation

Usage:
    m create-user --email user@example.com --password secret --role User
    m create-user  # Interactive mode (prompts for missing values)
    m create-admin --email admin@example.com --password secret

Security:
- Password must be at least 8 characters
- Checks for existing user before creating to prevent duplicates
"""

from __future__ import annotations

import asyncio
import os
import sys
from typing import Annotated

import cyclopts
from framework_m_core.cli.utility import console


def _normalize_role(raw_role: str) -> str:
    """Normalize user-provided role names.

    Common aliases are normalized to canonical casing.
    """
    value = raw_role.strip()
    if not value:
        return "User"

    lookup = {
        "admin": "Admin",
        "administrator": "Admin",
        "user": "User",
    }
    return lookup.get(value.lower(), value.title())


async def _create_local_user(
    email: str,
    password: str,
    full_name: str,
    role: str,
) -> None:
    """Async implementation of local user creation.

    Bootstraps the database, creates a LocalUser with assigned role,
    and prints the result.

    Args:
        email: User email address
        password: User password
        full_name: User full name for display
        role: Normalized role assigned to the user
    """
    # Import here to avoid slow startup import at CLI parse time
    from framework_m_core.config import load_config
    from framework_m_core.doctypes.session import Session
    from framework_m_core.doctypes.social_account import SocialAccount
    from framework_m_core.doctypes.user import LocalUser
    from framework_m_core.interfaces.repository import FilterOperator, FilterSpec
    from framework_m_core.security import hash_password
    from sqlalchemy import MetaData, insert

    from framework_m_standard.adapters.db.connection import ConnectionFactory
    from framework_m_standard.adapters.db.repository_factory import RepositoryFactory
    from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
    from framework_m_standard.adapters.db.session import SessionFactory

    config = load_config()
    database_url = os.environ.get(
        "DATABASE_URL",
        config.get("database", {}).get("url", "sqlite+aiosqlite:///./dev.db"),
    )

    console.info(f"Connecting to database: {database_url.split('://')[0]}://...")

    # Set up database
    connection_factory = ConnectionFactory()
    connection_factory.configure({"default": database_url})

    session_factory = SessionFactory()
    session_factory.configure(connection_factory)

    metadata = MetaData()
    schema_mapper = SchemaMapper()
    for doctype in (LocalUser, SocialAccount, Session):
        schema_mapper.create_tables(doctype, metadata)

    engine = connection_factory.get_engine("default")
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    repo_factory = RepositoryFactory(metadata, session_factory)

    console.success("✓ Database connected")

    try:
        user_repo = repo_factory.get_repository(LocalUser)
        if user_repo is None:
            raise RuntimeError("LocalUser repository could not be initialized")

        async with session_factory.get_session() as db_session:
            existing = await user_repo.list_entities(
                session=db_session,
                filters=[
                    FilterSpec(
                        field="email",
                        operator=FilterOperator.EQ,
                        value=email,
                    )
                ],
                limit=1,
                offset=0,
            )
            if existing.items:
                found = existing.items[0]
                console.error(
                    f"✗ User with email {email!r} already exists (id={found.id})"
                )
                return

            user = LocalUser(
                email=email,
                password_hash=hash_password(password),
                full_name=full_name,
                is_active=True,
                roles=[role],
            )

            payload = user.model_dump(mode="python")
            payload["password_hash"] = user.password_hash
            if payload.get("name") is None:
                payload["name"] = email

            await db_session.execute(insert(user_repo.table).values(**payload))

            console.success("✓ User created:")
            console.print(f"  Email: {user.email}")
            console.print(f"  ID: {user.id}")
            console.print(f"  Roles: {user.roles}")
            console.print()
            console.info("You can now log in at /desk/login or via /api/v1/auth/login")
    finally:
        await connection_factory.dispose_all()


def create_user(
    email: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--email",
            help="User email address",
        ),
    ] = None,
    password: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--password",
            help="User password (min 8 characters)",
        ),
    ] = None,
    full_name: Annotated[
        str,
        cyclopts.Parameter(
            name="--name",
            help="User display name",
        ),
    ] = "User",
    role: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--role",
            help="User role (e.g., User, Admin)",
        ),
    ] = None,
) -> None:
    """Create a local user for Framework M.

    If --email, --password, or --role are not provided,
    values are collected interactively.

    Examples:
        m create-user --email user@example.com --password mypassword --role User
        m create-user  # Interactive mode
        m create-user --email admin@example.com --role Admin --name "Site Admin"
    """
    if email is None:
        email = input("User email: ").strip()
        if not email:
            console.error("✗ Email is required.")
            sys.exit(1)

    if password is None:
        import getpass

        password = getpass.getpass("User password: ")
        if not password:
            console.error("✗ Password is required.")
            sys.exit(1)

    if role is None:
        role = input("Role [User]: ").strip() or "User"

    normalized_role = _normalize_role(role)

    if len(password) < 8:
        console.error("✗ Password must be at least 8 characters.")
        sys.exit(1)

    if "@" not in email or "." not in email.split("@")[-1]:
        console.error(f"✗ Invalid email address: {email!r}")
        sys.exit(1)

    console.print(f"\nCreating user: {email}")
    console.print(f"Role: {normalized_role}")
    console.print()

    try:
        asyncio.run(
            _create_local_user(
                email=email,
                password=password,
                full_name=full_name,
                role=normalized_role,
            )
        )
    except KeyboardInterrupt:
        console.print("\n[bold yellow]✗ Cancelled.[/bold yellow]")
        sys.exit(1)
    except Exception as e:
        console.error(f"✗ Failed to create user: {e}")
        if os.environ.get("M_DEBUG"):
            import traceback

            traceback.print_exc()
        sys.exit(1)


def create_admin(
    email: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--email",
            help="Admin user email address",
        ),
    ] = None,
    password: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--password",
            help="Admin user password (min 8 characters)",
        ),
    ] = None,
    full_name: Annotated[
        str,
        cyclopts.Parameter(
            name="--name",
            help="Admin user display name",
        ),
    ] = "Administrator",
) -> None:
    """Backward-compatible alias for creating an Admin user."""
    create_user(
        email=email,
        password=password,
        full_name=full_name,
        role="Admin",
    )


__all__ = ["create_admin", "create_user"]
