"""Web-related protocols and data structures."""

from typing import Protocol

from pydantic import BaseModel


class WebRequestInfo(BaseModel):
    """A library-agnostic representation of an HTTP request for security validation."""

    method: str
    path: str
    is_session_auth: bool
    origin: str | None = None
    referer: str | None = None


class CSRFProtocol(Protocol):
    """Protocol for Cross-Site Request Forgery protection."""

    async def validate_request(self, request_info: WebRequestInfo) -> bool:
        """Validate whether the incoming request is safe from CSRF.

        Args:
            request_info: Agnostic information about the incoming web request.

        Returns:
            bool: True if the request is valid, False if it should be rejected.
        """
        ...
