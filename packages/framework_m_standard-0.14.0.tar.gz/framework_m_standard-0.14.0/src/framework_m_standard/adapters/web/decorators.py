from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any, TypeVar

from litestar.middleware.rate_limit import RateLimitConfig

if TYPE_CHECKING:
    from litestar.middleware.rate_limit import DurationUnit

F = TypeVar("F", bound=Callable[..., Any])


def rate_limit(
    requests: int,
    unit: DurationUnit = "minute",
) -> Callable[[F], F]:
    """Decorator to apply granular rate limiting to a specific route handler.

    This decorator overrides the global rate limit policy for the decorated handler.
    If no global rate limiter is configured, it will still enforce the limit
    specified here.

    Args:
        requests: Number of allowed requests per unit.
        unit: The time unit for the limit ("second", "minute", "hour", "day").

    Returns:
        Decorated route handler with rate limit middleware attached.

    Example:
        @get("/sensitive-data")
        @rate_limit(requests=5, unit="minute")
        def get_data() -> dict:
            return {"data": "..."}
    """

    def decorator(handler: F) -> F:
        # Litestar stores middleware in the handler's middleware list.
        # We append a new RateLimitMiddleware configured specifically for this handler.
        config = RateLimitConfig(rate_limit=(unit, requests))

        # We treat the handler as Any to avoid MyPy errors when accessing 'middleware'
        # which isn't part of the Callable interface but is part of Litestar's route handlers.
        target: Any = handler
        if not hasattr(target, "middleware") or not isinstance(target.middleware, list):
            target.middleware = []

        # We use late-binding if possible, but Litestar's RateLimitConfig
        # is usually instantiated here.
        target.middleware.append(config.middleware)

        return handler

    return decorator
