from typing import Any

from pydantic import BaseModel, Field


class IdempotencyConfig(BaseModel):
    """Configuration for API Idempotency caching."""

    enabled: bool = True
    ttl: int = 86400  # 24 hours in seconds
    exclude_paths: list[str] = Field(default_factory=list)


class WebConfig(BaseModel):
    """Web/API layer configuration."""

    rate_limit: dict[str, Any] = Field(default_factory=dict)
    idempotency: IdempotencyConfig = Field(default_factory=IdempotencyConfig)
