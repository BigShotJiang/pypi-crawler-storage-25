"""Auth Routes - Authentication API for Indie mode (BFF Cookie Mode).

This module provides REST endpoints for authentication:
- GET /api/v1/auth/me - Get current user context
- POST /api/v1/auth/login - Authenticate and set HttpOnly session cookie
- POST /api/v1/auth/logout - Logout (delete session, clear cookie)

Strategy A (BFF Cookie Mode):
- Backend creates a server-side session on login
- Returns Set-Cookie: session_id=...; HttpOnly; Secure; SameSite=Lax
- SessionCookieAuth strategy reads cookie on subsequent requests
- No JWT in response body (XSS-safe)

Example:
    from litestar import Litestar
    from framework_m_standard.adapters.web.auth_routes import auth_routes_router

    app = Litestar(route_handlers=[auth_routes_router])
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Literal, TypedDict, cast

from framework_m_core.exceptions import AuthenticationError
from framework_m_core.interfaces.identity import PasswordCredentials
from litestar import Router, get, post
from litestar.connection import Request
from litestar.datastructures import Cookie
from litestar.exceptions import NotAuthorizedException
from litestar.response import Response
from pydantic import BaseModel, Field

from framework_m_standard.adapters.web.decorators import rate_limit

if TYPE_CHECKING:
    from framework_m_core.services.user_manager import UserManager


# =============================================================================
# DTOs
# =============================================================================


class LoginRequest(BaseModel):
    """Login request body.

    Attributes:
        email: Email address (preferred)
        username: Username (alternative to email)
        password: Plain-text password
    """

    email: str | None = Field(default=None, description="Email address")
    username: str | None = Field(default=None, description="Username (alternative)")
    password: str = Field(description="Password")

    @property
    def login_id(self) -> str:
        """Get the login identifier (email or username)."""
        return self.email or self.username or ""


# =============================================================================
# Module-level singletons (set via configure_* at startup)
# =============================================================================

_user_manager: UserManager | None = None
_session_store: Any | None = None

# Cookie configuration
_COOKIE_NAME = "session_id"
_COOKIE_PATH = "/"
_COOKIE_SAMESITE = "lax"
_COOKIE_MAX_AGE = 14 * 24 * 3600  # 14 days


class _CookieSettings(TypedDict):
    samesite: Literal["lax", "strict", "none"]
    domain: str | None
    secure: bool


def _parse_bool_env(value: str | None, default: bool) -> bool:
    """Parse boolean environment variable values safely."""
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _get_cookie_settings() -> _CookieSettings:
    """Resolve cookie security settings from environment variables."""
    samesite = os.environ.get("FRAMEWORK_M_COOKIE_SAMESITE", _COOKIE_SAMESITE).lower()
    if samesite not in {"lax", "strict", "none"}:
        samesite = _COOKIE_SAMESITE

    domain = os.environ.get("FRAMEWORK_M_COOKIE_DOMAIN")
    dev_mode = os.environ.get("M_DEV_MODE", "").lower() == "true"
    secure = _parse_bool_env(os.environ.get("FRAMEWORK_M_COOKIE_SECURE"), not dev_mode)

    return {
        "samesite": cast(Literal["lax", "strict", "none"], samesite),
        "domain": domain,
        "secure": secure,
    }


def get_user_manager() -> UserManager:
    """Get the UserManager instance.

    Returns:
        UserManager instance

    Raises:
        RuntimeError: If UserManager not configured
    """
    if _user_manager is None:
        raise RuntimeError(
            "UserManager not configured. "
            "Call configure_auth_routes() during app startup."
        )
    return _user_manager


def configure_auth_routes(user_manager: UserManager) -> None:
    """Configure auth routes with a UserManager instance.

    Call this during app startup to inject the UserManager.

    Args:
        user_manager: The UserManager to use for auth operations
    """
    global _user_manager
    _user_manager = user_manager


def configure_session_store(session_store: Any) -> None:
    """Configure auth routes with a session store adapter.

    Call this during app startup alongside configure_auth_routes().
    Session store can be DatabaseSessionAdapter or RedisSessionAdapter.

    Args:
        session_store: Session storage adapter implementing create/get/delete
    """
    global _session_store
    _session_store = session_store


# =============================================================================
# Route Handlers
# =============================================================================


@get("/me")
async def get_current_user(request: Request[Any, Any, Any]) -> dict[str, Any]:
    """Get current authenticated user context.

    Returns user information from the authenticated session context.
    If no user is authenticated, returns a guest user response.

    Args:
        request: The HTTP request with user context in state

    Returns:
        Dict with user info (authenticated, id, email, name, roles, tenants)
    """
    user = getattr(request.state, "user", None)

    if user is None:
        return {
            "authenticated": False,
            "id": "guest",
            "email": None,
            "name": "Guest User",
            "roles": [],
            "tenants": [],
            "teams": [],
            "is_system_user": False,
        }

    return {
        "authenticated": True,
        "id": user.id,
        "email": user.email,
        "name": user.name,
        "roles": user.roles,
        "tenants": user.tenants,
        "teams": getattr(user, "teams", []),
        "is_system_user": getattr(user, "is_system_user", False),
    }


@rate_limit(requests=5, unit="minute")
@post("/login")
async def login(
    data: LoginRequest,
    request: Request[Any, Any, Any],
) -> Response[dict[str, Any]]:
    """Authenticate user and set an HttpOnly session cookie (BFF Cookie Mode).

    Validates email/password against LocalUser, creates a server-side session,
    and returns a Set-Cookie header. No token is included in the response body.

    Args:
        data: Login credentials (email/username + password)
        request: The HTTP request (for IP/user-agent extraction)

    Returns:
        Dict with user info. Session cookie set via Set-Cookie header.

    Raises:
        NotAuthorizedException: If credentials are invalid or UserManager not configured
    """
    login_id = data.login_id

    if _user_manager is None:
        raise NotAuthorizedException(
            detail="Authentication not configured. Run 'm create-admin' to set up."
        )

    # Authenticate credentials via UserManager
    try:
        credentials = PasswordCredentials(
            username=login_id,
            password=data.password,
        )
        token = await _user_manager.authenticate(credentials)
    except AttributeError as e:
        raise NotAuthorizedException(
            detail=(
                "Authentication backend is not initialized. "
                "Set DATABASE_URL, run migrations/sync, then create an admin user."
            )
        ) from e
    except AuthenticationError as e:
        raise NotAuthorizedException(detail=str(e)) from e

    # Resolve actual user context for the response
    user_context = await _user_manager.get_by_email(login_id)
    if user_context is None:
        # Fallback: construct minimal context from token claims if available
        user_id = getattr(token, "user_id", login_id)
        user_name = login_id.split("@")[0].title() if "@" in login_id else login_id
        user_roles: list[str] = []
    else:
        user_id = user_context.id
        user_name = getattr(user_context, "name", None) or login_id
        user_roles = getattr(user_context, "roles", [])

    # Create server-side session
    session_id: str | None = None
    if _session_store is not None:
        # Extract client metadata for security audit
        ip_address: str | None = None
        user_agent: str | None = None
        if request.client:
            ip_address = request.client.host
        if hasattr(request, "headers"):
            user_agent = request.headers.get("user-agent")

        session_data = await _session_store.create(
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        session_id = session_data.session_id

    # Build response body
    response_body: dict[str, Any] = {
        "user": {
            "id": user_id,
            "email": login_id,
            "name": user_name,
            "roles": user_roles,
        },
        "session_cookie_set": session_id is not None,
    }

    # Return a proper Response with Set-Cookie header
    # Litestar's Cookie dataclass sets HttpOnly, SameSite, Path automatically.
    cookies = []
    if session_id is not None:
        cookie_settings = _get_cookie_settings()
        cookies.append(
            Cookie(
                key=_COOKIE_NAME,
                value=session_id,
                path=_COOKIE_PATH,
                httponly=True,
                secure=bool(cookie_settings["secure"]),
                domain=(
                    str(cookie_settings["domain"])
                    if cookie_settings["domain"] is not None
                    else None
                ),
                samesite=cookie_settings["samesite"],
                max_age=_COOKIE_MAX_AGE,
            )
        )

    return Response(
        content=response_body,
        status_code=200,
        cookies=cookies,
    )


@post("/logout")
async def logout(request: Request[Any, Any, Any]) -> Response[dict[str, str]]:
    """Logout current user — delete session, clear cookie.

    Reads session_id from the request cookie, deletes it from the session store,
    and signals the client to clear the cookie (Max-Age=0).

    Args:
        request: The HTTP request (to read session cookie)

    Returns:
        Success message dict. Cookie-clearing is handled by response middleware.
    """
    # Read session cookie
    session_id: str | None = None
    if hasattr(request, "cookies"):
        session_id = request.cookies.get(_COOKIE_NAME)

    # Delete session from store if present
    if session_id and _session_store is not None:
        await _session_store.delete(session_id)

    # Clear the session cookie on the client (Max-Age=0)
    cookie_settings = _get_cookie_settings()
    clear_cookie = Cookie(
        key=_COOKIE_NAME,
        value="",
        path=_COOKIE_PATH,
        httponly=True,
        secure=bool(cookie_settings["secure"]),
        domain=(
            str(cookie_settings["domain"])
            if cookie_settings["domain"] is not None
            else None
        ),
        samesite=cookie_settings["samesite"],
        max_age=0,
    )
    return Response(
        content={"message": "Logged out successfully"},
        status_code=200,
        cookies=[clear_cookie],
    )


# =============================================================================
# Router
# =============================================================================


auth_routes_router = Router(
    path="/api/v1/auth",
    route_handlers=[get_current_user, login, logout],
    tags=["auth"],
)


def create_auth_router() -> Router:
    """Create the auth router.

    Returns:
        Litestar Router with auth endpoints
    """
    return auth_routes_router


__all__ = [
    "LoginRequest",
    "auth_routes_router",
    "configure_auth_routes",
    "configure_session_store",
    "create_auth_router",
    "get_current_user",
    "login",
    "logout",
]
