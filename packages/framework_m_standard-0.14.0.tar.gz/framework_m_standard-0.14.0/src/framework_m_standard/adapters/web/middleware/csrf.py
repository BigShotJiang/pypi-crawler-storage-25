"""CSRF Protection Middleware Adapter.

Provides the default implementation for Cross-Site Request Forgery protection
based on Origin and Referer header validation.
"""

import importlib.metadata
from collections.abc import Sequence
from typing import Any
from urllib.parse import urlparse

import structlog
from litestar.connection import Request
from litestar.exceptions import PermissionDeniedException
from litestar.middleware import AbstractMiddleware
from litestar.types import Receive, Scope, Send

from framework_m_standard.interfaces.web import CSRFProtocol, WebRequestInfo

SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}


class DefaultCSRFAdapter(CSRFProtocol):
    """Default CSRF protection using Origin and Referer headers."""

    def __init__(self, allowed_origins: Sequence[str]) -> None:
        """Initialize the CSRF adapter.

        Args:
            allowed_origins: List of allowed origins (e.g., ['https://example.com']).
        """
        self.allowed_origins = [o.rstrip("/") for o in allowed_origins]

    async def validate_request(self, request_info: WebRequestInfo) -> bool:
        """Validate the incoming request against CSRF rules.

        Bypasses safe HTTP methods and non-session authenticated requests.
        Enforces strict Origin/Referer checking for state-changing browser requests.
        """
        # 1. Safe methods do not require CSRF protection
        if request_info.method.upper() in SAFE_METHODS:
            return True

        # 2. APIs using Bearer tokens/API keys do not require CSRF protection
        if not request_info.is_session_auth:
            return True

        # 3. Check Origin header first
        if request_info.origin:
            return request_info.origin.rstrip("/") in self.allowed_origins

        # 4. Check Referer header as fallback
        if request_info.referer:
            parsed_referer = urlparse(request_info.referer)
            referer_origin = f"{parsed_referer.scheme}://{parsed_referer.netloc}"
            return referer_origin in self.allowed_origins

        # 5. Missing both headers for a state-changing browser request is unsafe
        return False


def CSRFMiddlewareFactory(adapter: CSRFProtocol) -> type[AbstractMiddleware]:
    """Create a Litestar middleware class using the provided CSRF adapter."""

    class CSRFMiddleware(AbstractMiddleware):
        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
            if scope["type"] == "http":  # type: ignore[comparison-overlap]
                request = Request[Any, Any, Any](scope)

                # Extract framework-agnostic info from Litestar Request
                request_info = WebRequestInfo(
                    method=request.method,
                    path=request.url.path,
                    # Treat as session auth if 'session_id' cookie is present
                    is_session_auth="session_id" in request.cookies,
                    origin=request.headers.get("origin"),
                    referer=request.headers.get("referer"),
                )

                # Validate via Port
                if not await adapter.validate_request(request_info):
                    raise PermissionDeniedException("CSRF validation failed")

            await self.app(scope, receive, send)

    return CSRFMiddleware


logger = structlog.get_logger(__name__)


def get_csrf_adapter(allowed_origins: Sequence[str]) -> CSRFProtocol:
    """Resolve and instantiate the active CSRF adapter.

    Defaults to DefaultCSRFAdapter, but allows MX packages to override
    via the 'framework_m.adapters.csrf' entry point.
    """
    try:
        eps = importlib.metadata.entry_points(group="framework_m.adapters.csrf")
        if eps:
            ep = next(iter(eps))
            adapter_class = ep.load()
            logger.info(
                "Loaded custom CSRF adapter", adapter_class=adapter_class.__name__
            )
            return adapter_class(allowed_origins=allowed_origins)  # type: ignore[no-any-return]
    except Exception as e:
        logger.warning("Failed to load custom CSRF adapter", error=str(e))

    return DefaultCSRFAdapter(allowed_origins=allowed_origins)
