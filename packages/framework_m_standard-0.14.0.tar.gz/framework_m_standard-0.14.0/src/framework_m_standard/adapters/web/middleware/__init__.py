"""Web middleware components for Framework M.

This module provides middleware for:
- Authentication
- Locale resolution (i18n)
- Request logging
- Performance monitoring
- Idempotency
"""

# Import from middleware/authentication.py
from framework_m_standard.adapters.web.middleware.authentication import (
    AuthMiddleware,
    create_auth_middleware,
)

# Import from idempotency.py
from framework_m_standard.adapters.web.middleware.idempotency import (
    IdempotencyMiddleware,
)

# Import from this package
from framework_m_standard.adapters.web.middleware.locale import (
    LocaleResolutionMiddleware,
    create_locale_middleware,
    provide_locale,
)

# Import from logging.py
from framework_m_standard.adapters.web.middleware.logging import (
    CustomJsonFormatter,
    LoggingMiddleware,
    RequestContextFilter,
)

# Import from metrics.py
from framework_m_standard.adapters.web.middleware.metrics import (
    MetricsMiddleware,
    metrics_endpoint,
)

__all__ = [
    # Auth middleware
    "AuthMiddleware",
    "create_auth_middleware",
    # Idempotency middleware
    "IdempotencyMiddleware",
    # Locale middleware
    "LocaleResolutionMiddleware",
    "create_locale_middleware",
    "provide_locale",
    # Logging middleware
    "CustomJsonFormatter",
    "LoggingMiddleware",
    "RequestContextFilter",
    # Metrics middleware
    "MetricsMiddleware",
    "metrics_endpoint",
]
