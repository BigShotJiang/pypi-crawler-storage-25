"""Idempotency Middleware.

Intercepts the Idempotency-Key header, checks the cache, and manages
concurrent request locking using the configured adapter.
"""

import json
from typing import Any

from framework_m_core.interfaces.idempotency import (
    IdempotencyProtocol,
    SerializedResponse,
)
from litestar.connection import Request
from litestar.middleware import AbstractMiddleware
from litestar.types import ASGIApp, Message, Receive, Scope, Send


class IdempotencyMiddleware(AbstractMiddleware):
    """Idempotency Middleware.

    Intercepts the Idempotency-Key header, checks the cache, and manages
    concurrent request locking using the configured adapter.
    """

    def __init__(
        self,
        app: ASGIApp,
        adapter: IdempotencyProtocol,
        exclude: str | list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize middleware.

        Args:
            app: The ASGI application
            adapter: The idempotency infrastructure adapter to use.
            exclude: Paths to exclude from this middleware.
        """
        super().__init__(app=app, exclude=exclude, **kwargs)
        self.adapter = adapter

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":  # type: ignore[comparison-overlap]
            await self.app(scope, receive, send)
            return

        request = Request[Any, Any, Any](scope)

        # Only state-changing methods are idempotent
        if request.method not in ("POST", "PUT", "PATCH", "DELETE"):
            await self.app(scope, receive, send)
            return

        idem_key = request.headers.get("Idempotency-Key")
        if not idem_key:
            await self.app(scope, receive, send)
            return

        # Expose the key to downstream controllers and background jobs
        request.state.idempotency_key = idem_key

        # Safely extract Tenant ID to prevent cross-tenant key collisions
        tenant_ctx = getattr(request.state, "tenant", None)
        tenant_id = getattr(tenant_ctx, "tenant_id", "global")

        effective_key = f"{tenant_id}:{idem_key}"

        # 1. Check cache
        cached = await self.adapter.get_response(effective_key)
        if cached:
            headers = [
                (k.encode("latin-1"), v.encode("latin-1"))
                for k, v in cached.headers.items()
            ]
            await send(
                {
                    "type": "http.response.start",
                    "status": cached.status_code,
                    "headers": headers,
                }
            )
            await send(
                {
                    "type": "http.response.body",
                    "body": cached.body,
                    "more_body": False,
                }
            )
            return

        # 2. Acquire Lock (prevent concurrent identical requests)
        acquired = await self.adapter.acquire_lock(effective_key, timeout=2.0)
        if not acquired:
            body = json.dumps(
                {"detail": "Concurrent request in progress for this idempotency key"}
            ).encode("utf-8")
            await send(
                {
                    "type": "http.response.start",
                    "status": 409,
                    "headers": [
                        (b"content-type", b"application/json"),
                        (b"content-length", str(len(body)).encode("utf-8")),
                    ],
                }
            )
            await send({"type": "http.response.body", "body": body, "more_body": False})
            return

        # 3. Execute and capture response
        status_code = 500
        response_headers: dict[str, str] = {}
        response_body = b""

        async def send_wrapper(message: Message) -> None:
            nonlocal status_code, response_headers, response_body
            if message["type"] == "http.response.start":
                status_code = message.get("status", 500)
                for k, v in message.get("headers", []):
                    response_headers[k.decode("latin-1")] = v.decode("latin-1")
            elif message["type"] == "http.response.body":
                response_body += message.get("body", b"")

            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            # 4. Save and Release
            # Only cache successful responses and client errors (4xx)
            if status_code < 500:
                serialized = SerializedResponse(
                    status_code=status_code,
                    headers=response_headers,
                    body=response_body,
                )
                await self.adapter.save_response(effective_key, serialized)

            await self.adapter.release_lock(effective_key)


__all__ = ["IdempotencyMiddleware"]
