from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from framework_m_core.interfaces.auth_context import UserContext
    from litestar.connection import ASGIConnection


class RateLimitKeyResolver:
    """Resolves a unique key for rate limiting based on request context.

    This ensures that rate limits are applied fairly across tenants and users,
    preventing a single user or tenant from exhausting resources for others.

    Resolution Priority:
    1. Tenant ID (Isolation for multi-tenant environments)
    2. User ID (Identity-based limits for authenticated users)
    3. Client IP (Fallback for unauthenticated public traffic)
    """

    def __call__(self, connection: ASGIConnection[Any, Any, Any, Any]) -> str:
        """Resolve the rate limit key from connection scope.

        Args:
            connection: The Litestar connection (Request or WebSocket)

        Returns:
            A string key in format 'type:identifier'
        """
        state = connection.scope.get("state", {})

        # 1. Resolve by Tenant (Multi-tenant isolation)
        tenant = state.get("tenant")
        if tenant and hasattr(tenant, "id") and tenant.id:
            return f"tenant:{tenant.id}"

        # 2. Resolve by User (Authenticated identity)
        user: UserContext | None = state.get("user")
        if user and hasattr(user, "id") and user.id:
            return f"user:{user.id}"

        # 3. Resolve by Client IP (Anonymous/Public fallback)
        client = connection.scope.get("client")
        if client and isinstance(client, (list, tuple)) and len(client) > 0:
            return f"ip:{client[0]}"

        return "ip:unknown"
