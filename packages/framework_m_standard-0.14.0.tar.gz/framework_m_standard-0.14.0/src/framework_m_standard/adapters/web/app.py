"""Litestar Application Factory.

This module provides the application factory for creating the Litestar
web application with all required configuration.

Features:
- CORS configuration for development
- Exception handlers for domain exceptions
- OpenAPI documentation (Swagger/ReDoc)
- Application lifecycle management
- Dependency injection container integration

Example:
    from framework_m_standard.adapters.web.app import create_app

    app = create_app()

    # Run with uvicorn
    # uvicorn framework_m_standard.adapters.web.app:create_app --factory
"""

# ruff: noqa: E402 - Module imports must come after dotenv loading

import logging
import os
from typing import Any

from framework_m_core.config import load_config
from framework_m_core.container import Container
from framework_m_core.exceptions import (
    DocTypeNotFoundError,
    DuplicateNameError,
    EntityNotFoundError,
    FrameworkError,
    PermissionDeniedError,
    ValidationError,
)
from framework_m_core.registry import MetaRegistry
from framework_m_core.services.user_manager import UserManager
from litestar import Litestar
from litestar.config.cors import CORSConfig
from litestar.exceptions import NotFoundException
from litestar.middleware.base import DefineMiddleware
from litestar.middleware.rate_limit import RateLimitConfig
from litestar.openapi import OpenAPIConfig
from litestar.openapi.plugins import RedocRenderPlugin, SwaggerRenderPlugin
from litestar.openapi.spec import Components, SecurityScheme
from litestar.stores.memory import MemoryStore

from framework_m_standard.adapters.auth.local_identity import LocalIdentityAdapter
from framework_m_standard.adapters.auth.session_store import (
    RedisSessionAdapter,
)
from framework_m_standard.adapters.auth.strategies import (
    AuthChain,
    GatewayAuth,
    JwtAuth,
    SessionCookieAuth,
)
from framework_m_standard.adapters.idempotency import (
    DatabaseIdempotencyAdapter,
    RedisIdempotencyAdapter,
)
from framework_m_standard.adapters.web.activity_routes import ActivityController
from framework_m_standard.adapters.web.auth_routes import (
    auth_routes_router,
    configure_auth_routes,
    configure_session_store,
)
from framework_m_standard.adapters.web.config import WebConfig
from framework_m_standard.adapters.web.correction_router import correction_router
from framework_m_standard.adapters.web.desk_routes import (
    ROOT_ASSET_PREFIX,
    create_static_files_config,
    root_redirect,
    serve_desk_root,
    serve_desk_spa,
    serve_favicon,
    serve_mfe_assets,
    serve_root_routing,
    serve_well_known_probe,
)
from framework_m_standard.adapters.web.exception_handlers import (
    duplicate_name_handler,
    framework_error_handler,
    litestar_not_found_handler,
    not_found_handler,
    permission_denied_handler,
    validation_error_handler,
)
from framework_m_standard.adapters.web.health_routes import (
    health_check,
    readiness_check,
)
from framework_m_standard.adapters.web.lifespan import app_lifespan
from framework_m_standard.adapters.web.meta_router import create_meta_router
from framework_m_standard.adapters.web.metadata_router import metadata_router
from framework_m_standard.adapters.web.middleware import (
    IdempotencyMiddleware,
    MetricsMiddleware,
    create_auth_middleware,
    metrics_endpoint,
)
from framework_m_standard.adapters.web.middleware.csrf import (
    CSRFMiddlewareFactory,
    get_csrf_adapter,
)
from framework_m_standard.adapters.web.middleware.rate_limit import RateLimitKeyResolver
from framework_m_standard.adapters.web.oauth_routes import (
    oauth_routes_router,
)
from framework_m_standard.adapters.web.print_routes import PrintController
from framework_m_standard.adapters.web.sibling_meta_router import sibling_meta_router
from framework_m_standard.adapters.web.socket import create_websocket_router
from framework_m_standard.adapters.web.tree_routes import tree_routes_router
from framework_m_standard.adapters.web.workflow_router import workflow_router
from framework_m_standard.bootstrap.init_adapters import load_env

logger = logging.getLogger(__name__)

DEFAULT_DEV_ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]


def _is_dev_mode() -> bool:
    """Resolve development mode from M_DEV_MODE environment variable.

    Returns True when M_DEV_MODE is set to any truthy value
    ("1", "true", "yes", "on", case-insensitive).

    When running `m dev`, M_DEV_MODE is automatically set to "true".
    """
    return os.environ.get("M_DEV_MODE", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


# Default exclusions keep rate limiting focused on sensitive endpoints (e.g. login)
# while avoiding false-positive throttling during Desk bootstrap in development.
DEFAULT_RATE_LIMIT_EXCLUDE = (
    r"^/(health|ready|metrics|schema"
    r"|desk(?:/.*)?"
    r"|favicon\.ico|index-[^/]+"
    r"|api/meta(?:/.*)?"
    r"|api/v1/auth/me"
    r"|api/v1/Translation(?:/.*)?)$"
)


# =============================================================================
# Application Factory
# =============================================================================


def create_app(serve_static: bool | None = None) -> Litestar:
    """Create and configure the Litestar application.

    This factory function creates a fully configured Litestar app with:
    - CORS configured for development (allows all origins)
    - Exception handlers for domain exceptions
    - OpenAPI documentation with Swagger UI
    - Health check endpoint
    - Application lifecycle management
    - Conditional UI serving (production vs development mode)

    Args:
        serve_static: Whether to serve bundled static UI files.
            - True: Serve UI + API (production mode)
            - False: Serve API only (development mode, Vite serves UI separately)
            - None (default): Auto-detect from M_DEV_MODE env var
                - M_DEV_MODE=true → serve_static=False
                - Otherwise → serve_static=True

    Returns:
        Configured Litestar application instance

    Example:
        # Production mode (serves bundled static files + API)
        app = create_app(serve_static=True)

        # Development mode (API only, Vite dev server serves UI)
        app = create_app(serve_static=False)

        # Auto-detect from environment
        # M_DEV_MODE=true → API only
        # M_DEV_MODE not set → Serve static + API
        app = create_app()
    """
    # Load environment variables (from .env or system env)
    load_env()

    container = Container()

    # Detection of development mode
    dev_mode = _is_dev_mode()

    # Auto-detect serve_static if not explicitly set
    if serve_static is None:
        serve_static = not dev_mode

    # Detect application version dynamically from package metadata
    try:
        import importlib.metadata

        app_version = importlib.metadata.version("framework-m")
    except Exception:
        app_version = "0.1.0"

    # CORS Configuration
    cors_origins_env = os.environ.get("FRAMEWORK_M_CORS_ORIGINS")
    if cors_origins_env:
        allow_origins = [
            o.strip().rstrip("/") for o in cors_origins_env.split(",") if o.strip()
        ]
    else:
        allow_origins = list(DEFAULT_DEV_ALLOWED_ORIGINS) if dev_mode else []

    cors_config = CORSConfig(
        allow_origins=allow_origins,
        allow_methods=["*"],
        allow_headers=["*"],
        allow_credentials=True,
    )

    # OpenAPI Configuration
    openapi_config = OpenAPIConfig(
        title="Framework M API",
        version=app_version,
        description="A modular, metadata-driven business application framework",
        path="/schema",
        render_plugins=[
            SwaggerRenderPlugin(),
            RedocRenderPlugin(),
        ],
        # Security scheme for header-based authentication
        components=Components(
            security_schemes={
                "HeaderAuth": SecurityScheme(
                    type="apiKey",
                    name="x-user-id",
                    security_scheme_in="header",
                    description="User ID for authentication. Required for protected endpoints.",
                ),
                "RolesHeader": SecurityScheme(
                    type="apiKey",
                    name="x-roles",
                    security_scheme_in="header",
                    description="Comma-separated list of roles (e.g., 'Manager,Employee').",
                ),
            },
        ),
    )

    # Exception Handlers - type: ignore needed for union return types
    exception_handlers = {
        ValidationError: validation_error_handler,
        PermissionDeniedError: permission_denied_handler,
        DocTypeNotFoundError: not_found_handler,
        EntityNotFoundError: not_found_handler,
        NotFoundException: litestar_not_found_handler,
        DuplicateNameError: duplicate_name_handler,
        FrameworkError: framework_error_handler,
    }

    # Static Files Configuration (only in production mode)
    static_routers = create_static_files_config() if serve_static else []

    registry = MetaRegistry.get_instance()

    # Discover and load all installed apps (via entry points)
    registry.load_installed_apps()

    # ==========================================================================
    # Secrets Management & DI Container
    # ==========================================================================
    # Container already initialized during bootstrap

    # Get Secrets Manager
    secrets_manager = container.secrets_manager()

    # Validate essential secrets (Fail Fast)
    if not dev_mode:
        # Mandatory in production
        secrets_manager.validate(["FRAMEWORK_M_JWT_SECRET"])

    # Read config for jwt_secret via SecretsManager
    config = load_config()
    jwt_secret = secrets_manager.get(
        "FRAMEWORK_M_JWT_SECRET",
        config.get("auth", {}).get(
            "jwt_secret", "change-me-in-production-min-32-bytes-secret"
        ),
    )

    # Secret Entropy Check
    if not dev_mode and (
        len(jwt_secret) < 32
        or jwt_secret == "change-me-in-production-min-32-bytes-secret"
    ):
        import logging

        logging.getLogger("framework_m").warning(
            "CRITICAL SECURITY WARNING: FRAMEWORK_M_JWT_SECRET is either using the default "
            "value or is too short (< 32 chars). This is UNSAFE for production."
        )

    # Build session store: Redis if REDIS_URL is set, else DB-backed
    redis_url = secrets_manager.get("REDIS_URL", "")
    if redis_url:
        _session_store: Any = RedisSessionAdapter(redis_url=redis_url)
    else:
        # DB-based session store (zero external dependencies for indie)
        # The actual repo is wired during lifespan; we store a placeholder here.
        # It will be replaced by the lifespan startup with the real repo.
        _session_store = None  # Will be finalized in lifespan startup

    # Build LocalIdentityAdapter and UserManager
    # These are temporary placeholders and are finalized with real repositories in lifespan.
    _local_identity = LocalIdentityAdapter(
        user_repository=None,
        jwt_secret=jwt_secret,
    )

    _user_manager_instance = UserManager(identity_provider=_local_identity)

    # Configure auth routes module-level singletons
    configure_auth_routes(_user_manager_instance)
    if _session_store is not None:
        configure_session_store(_session_store)

    # Build AuthChain: SessionCookieAuth → BearerTokenAuth → HeaderAuth
    # SessionCookieAuth is added when session store is wired (in lifespan).
    auth_strategies: list[Any] = []
    if _session_store is not None:
        auth_strategies.append(SessionCookieAuth(session_store=_session_store))
    auth_strategies.append(JwtAuth(jwt_secret=jwt_secret))
    auth_strategies.append(GatewayAuth())
    auth_chain = AuthChain(strategies=auth_strategies)

    # ==========================================================================
    # Rate Limiting Configuration
    # ==========================================================================
    rate_limit_store: Any
    if redis_url:
        try:
            import redis.asyncio as redis_async
            from litestar.stores.redis import RedisStore

            rate_limit_store = RedisStore(
                redis_async.from_url(redis_url)  # type: ignore[no-untyped-call,unused-ignore]
            )
        except ImportError:
            rate_limit_store = MemoryStore()
    else:
        rate_limit_store = MemoryStore()

    # Rate Limiting Configuration
    # Reads from [web.rate_limit] in framework_config.toml or env vars.
    # FRAMEWORK_M_RATE_LIMIT_REQUESTS: requests per unit.
    # Default is relaxed in dev mode to avoid throttling normal Desk boot/list traffic.
    # FRAMEWORK_M_RATE_LIMIT_UNIT: time unit — "second", "minute", "hour" (default: "minute")
    # FRAMEWORK_M_RATE_LIMIT_EXCLUDE: optional regex for paths to exclude from rate limiting.
    # By default, framework excludes health/static/bootstrap routes to prevent
    # desk startup traffic from exhausting the global limit.
    rate_limit_data = config.get("web", {}).get("rate_limit", {})
    default_rl_requests = 300 if dev_mode else 60

    rl_requests = int(
        secrets_manager.get(
            "FRAMEWORK_M_RATE_LIMIT_REQUESTS",
            rate_limit_data.get("requests", default_rl_requests),
        )
    )
    rl_unit = secrets_manager.get(
        "FRAMEWORK_M_RATE_LIMIT_UNIT", rate_limit_data.get("unit", "minute")
    )
    rl_exclude = secrets_manager.get(
        "FRAMEWORK_M_RATE_LIMIT_EXCLUDE",
        rate_limit_data.get("exclude", DEFAULT_RATE_LIMIT_EXCLUDE),
    )

    rate_limit_kwargs: dict[str, Any] = {
        "rate_limit": (rl_unit, rl_requests),
        "store": rate_limit_store,
        "identifier_for_request": RateLimitKeyResolver(),
        "set_rate_limit_headers": True,
        "rate_limit_limit_header_key": "X-RateLimit-Limit",
        "rate_limit_remaining_header_key": "X-RateLimit-Remaining",
        "rate_limit_reset_header_key": "X-RateLimit-Reset",
    }

    if rl_exclude:
        rate_limit_kwargs["exclude"] = [rl_exclude]

    rate_limit_config = RateLimitConfig(**rate_limit_kwargs)

    # ==========================================================================
    # CSRF Protection Configuration
    # ==========================================================================
    csrf_adapter = get_csrf_adapter(allow_origins)

    # ==========================================================================
    # Idempotency Configuration
    # ==========================================================================
    idempotency_adapter: Any = None
    web_config = WebConfig(**config.get("web", {}))
    if web_config.idempotency.enabled:
        if redis_url:
            import redis.asyncio as redis_async

            idem_redis_client = redis_async.from_url(redis_url)  # type: ignore[no-untyped-call,unused-ignore]
            idempotency_adapter = RedisIdempotencyAdapter(
                redis_client=idem_redis_client
            )
        else:
            idempotency_adapter = DatabaseIdempotencyAdapter(
                session_factory=container.session_factory().get_session
            )

    # Build route handlers list
    route_handlers: list[Any] = [
        health_check,
        readiness_check,
        metrics_endpoint,
        serve_favicon,
        serve_well_known_probe,
        auth_routes_router,
        oauth_routes_router,  # OAuth2/OIDC social login (now registered!)
        PrintController,
        metadata_router,  # Metadata API including doctype listing for menus
        sibling_meta_router,
        ActivityController,
        correction_router,
        workflow_router,
        tree_routes_router,  # Tree API for hierarchical DocTypes
    ]

    # Add UI routes only in production mode (when serving static files)
    if serve_static:
        route_handlers.extend(static_routers)
        route_handlers.extend(
            [
                root_redirect,  # Redirect / to /desk/
                serve_desk_root,  # Serve Desk UI at /desk/
                serve_desk_spa,  # Catchall for Desk SPA routing
                serve_root_routing,  # Unified handler for root-level SPA routes and assets
                serve_mfe_assets,  # Serve MFE assets
            ]
        )

    # Add auto-CRUD routes for DocTypes with api_resource=True
    try:
        crud_router = create_meta_router()
        route_handlers.append(crud_router)
    except Exception:
        # No DocTypes registered yet, skip CRUD routes
        pass

    # Add WebSocket router for real-time streaming
    websocket_router = create_websocket_router()
    route_handlers.append(websocket_router)

    # Build Middleware Stack
    app_middlewares: list[Any] = [
        rate_limit_config.middleware,
        MetricsMiddleware,
        CSRFMiddlewareFactory(csrf_adapter),
    ]

    if idempotency_adapter is not None:
        app_middlewares.append(
            DefineMiddleware(
                IdempotencyMiddleware,
                adapter=idempotency_adapter,
                exclude=web_config.idempotency.exclude_paths or None,
            )
        )

    app_middlewares.append(
        create_auth_middleware(
            auth_chain=auth_chain,
            require_auth=False,  # Enforce auth per-DocType via Meta.requires_auth
            excluded_paths=[
                "/health",
                "/ready",
                "/metrics",
                "/schema",
                "/api/v1/auth/login",
                "/api/v1/auth/logout",
                "/api/v1/auth/oauth/",
                "/api/meta",
                "/desk",
                "/favicon.ico",
                ROOT_ASSET_PREFIX,
                "/",  # Root redirect to /desk/
            ],
        )
    )

    # Create and return app
    app = Litestar(
        route_handlers=route_handlers,
        middleware=app_middlewares,
        cors_config=cors_config,
        openapi_config=openapi_config,
        exception_handlers=exception_handlers,  # type: ignore[arg-type]
        lifespan=[app_lifespan],
        debug=dev_mode,
    )

    app.state.jwt_secret = jwt_secret
    app.state.redis_url = redis_url
    app.state.auth_chain = auth_chain
    app.state.secrets_manager = secrets_manager
    app.state.container = container

    return app


__all__ = ["create_app"]
