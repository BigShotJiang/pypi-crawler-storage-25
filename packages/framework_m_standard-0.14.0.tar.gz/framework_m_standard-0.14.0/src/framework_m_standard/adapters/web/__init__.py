"""Web Adapters - HTTP/API layer for Framework M.

This package provides the Litestar-based web application with:
- Application factory
- Authentication middleware
- Middleware discovery and registration
- Auto-CRUD router generation
- RPC routes for controller methods
- Share management routes
- Exception handlers
- OpenAPI documentation
"""

import framework_m_standard.adapters.web.app as app
import framework_m_standard.adapters.web.auth_routes as auth_routes
import framework_m_standard.adapters.web.correction_router as correction_routes
import framework_m_standard.adapters.web.oauth_routes as oauth_routes
import framework_m_standard.adapters.web.sibling_meta_router as sibling_meta_routes
from framework_m_standard.adapters.web.app import create_app
from framework_m_standard.adapters.web.correction_router import correction_router
from framework_m_standard.adapters.web.decorators import rate_limit
from framework_m_standard.adapters.web.dtos import (
    ErrorResponse,
    PaginatedResponse,
    SuccessResponse,
)
from framework_m_standard.adapters.web.meta_router import (
    create_crud_routes,
    create_meta_router,
)
from framework_m_standard.adapters.web.meta_routes import meta_routes_router
from framework_m_standard.adapters.web.middleware import (
    AuthMiddleware,
    LocaleResolutionMiddleware,
    create_auth_middleware,
    create_locale_middleware,
)
from framework_m_standard.adapters.web.middleware_registry import (
    MiddlewareConfig,
    MiddlewareRegistry,
    create_middleware_stack,
)
from framework_m_standard.adapters.web.rpc_routes import rpc_router
from framework_m_standard.adapters.web.share_routes import (
    CreateShareRequest,
    ShareController,
    ShareListResponse,
    ShareResponse,
    share_router,
)
from framework_m_standard.adapters.web.sibling_meta_router import sibling_meta_router
from framework_m_standard.adapters.web.tree_routes import tree_routes_router

__all__ = [
    "AuthMiddleware",
    "CreateShareRequest",
    "ErrorResponse",
    "LocaleResolutionMiddleware",
    "MiddlewareConfig",
    "MiddlewareRegistry",
    "PaginatedResponse",
    "ShareController",
    "ShareListResponse",
    "ShareResponse",
    "SuccessResponse",
    "app",
    "auth_routes",
    "correction_router",
    "correction_routes",
    "create_app",
    "create_auth_middleware",
    "create_crud_routes",
    "create_locale_middleware",
    "create_meta_router",
    "create_middleware_stack",
    "meta_routes_router",
    "tree_routes_router",
    "oauth_routes",
    "rpc_router",
    "share_router",
    "sibling_meta_router",
    "sibling_meta_routes",
    "rate_limit",
]
