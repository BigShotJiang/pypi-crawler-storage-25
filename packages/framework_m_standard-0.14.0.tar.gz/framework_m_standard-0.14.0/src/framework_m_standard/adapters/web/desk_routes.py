"""Desk & SPA Routing.

This module handles serving the static single-page application (SPA),
redirects, static assets, and dynamic UI injections (like OAuth providers).
"""

from __future__ import annotations

import importlib.metadata
import importlib.resources
import json
import mimetypes
import os
import re
from importlib.resources import files
from pathlib import Path
from typing import Any

import httpx
import structlog
from framework_m_core.config import load_config
from litestar import get
from litestar.response import Redirect, Response
from litestar.static_files import create_static_files_router

from framework_m_standard.adapters.web.frontend_discovery import (
    discover_active_shell,
    discover_mfe_remotes,
)
from framework_m_standard.adapters.web.oauth_routes import get_oauth_config

logger = structlog.get_logger(__name__)

PREFERRED_FRONTEND_DIST_ENV = "FRAMEWORK_M_FRONTEND_DIST"
ROOT_ASSET_PREFIX = "/index-"


@get("/", sync_to_thread=False, include_in_schema=False)
def root_redirect() -> Redirect:
    """Redirect root to /desk/.

    This ensures the Desk UI is accessed at a dedicated path,
    avoiding conflicts with API routes.

    Returns:
        Redirect response to /desk/
    """
    return Redirect(path="/desk/")


@get(["desk", "/desk/"], sync_to_thread=False, include_in_schema=False)
def serve_desk_root() -> Response[bytes]:
    """Serve bundled Desk UI index.html at /desk/.

    This is the entry point for the Desk UI.

    Returns:
        HTML response with Desk UI or 404 error
    """
    return _get_desk_html_response()


@get("/favicon.ico", sync_to_thread=False, include_in_schema=False)
def serve_favicon() -> Response[bytes]:
    """Serve favicon when available, otherwise return a clean 404 response."""
    return _get_favicon_response()


@get("/.well-known/{path:path}", sync_to_thread=False, include_in_schema=False)
def serve_well_known_probe(path: str) -> Response[bytes]:
    """Return clean 404 for browser/tooling discovery probes.

    Some clients (e.g. Chrome DevTools) probe under `/.well-known/*`.
    Handling this explicitly avoids noisy stack traces in development logs.
    """
    _ = path
    return Response(content=b"Not Found", status_code=404)


@get("/desk/{path:path}", sync_to_thread=False, include_in_schema=False)
def serve_desk_spa(path: str) -> Response[bytes]:
    """Serve Desk SPA with client-side routing support.

    This catchall route ensures that React Router paths like /desk/doctypes/User
    work correctly when the user refreshes or enters the URL directly.

    Static asset requests (paths with file extensions like .js, .css, .ico)
    are NOT handled here — they are served by the static files router instead.

    Args:
        path: The requested path within /desk/

    Returns:
        HTML response with Desk UI index.html, or 404 for static asset paths
    """
    # If the path looks like a static file (has a file extension),
    # don't serve index.html — let the static files router handle it.
    # This prevents returning text/html for .js/.css requests.
    last_segment = path.rsplit("/", 1)[-1]
    if "." in last_segment:
        # This is a static file request (e.g., assets/index-xxx.js)
        preferred_dist = _get_preferred_frontend_dist_path()
        if preferred_dist:
            preferred_file = preferred_dist / path
            if preferred_file.exists() and preferred_file.is_file():
                content_type = (
                    mimetypes.guess_type(str(preferred_file))[0]
                    or "application/octet-stream"
                )
                return Response(
                    content=preferred_file.read_bytes(),
                    media_type=content_type,
                )

        # Try to serve the actual file from bundled static
        static_path = _get_bundled_static_path()
        if static_path:
            file_path = static_path / path
            if file_path.exists() and file_path.is_file():
                content_type = (
                    mimetypes.guess_type(str(file_path))[0]
                    or "application/octet-stream"
                )
                return Response(
                    content=file_path.read_bytes(),
                    media_type=content_type,
                )

        # Fallback to local dev directories
        local_dirs = [
            Path.cwd() / "frontend" / "dist" / path,
            Path.cwd() / "dist" / path,
        ]
        for local_file in local_dirs:
            if local_file.exists() and local_file.is_file():
                content_type = (
                    mimetypes.guess_type(str(local_file))[0]
                    or "application/octet-stream"
                )
                return Response(
                    content=local_file.read_bytes(),
                    media_type=content_type,
                )

        return Response(content=b"Not Found", status_code=404)

    # For navigation routes (no file extension), serve index.html
    # The React app will handle the actual routing
    return _get_desk_html_response()


@get("/{path:path}", sync_to_thread=False, include_in_schema=False)
def serve_root_routing(path: str) -> Response[bytes]:
    """Unified handler for root-level SPA entry points and assets.

    Ensures that navigation paths like /login serve the SPA index, while
    assets like /index-abc.js are correctly resolved.
    """
    # Normalize path for matching
    clean_path = path.lstrip("/")

    # 1. Exclude system and API paths
    if clean_path.startswith(
        ("api/", "schema", "health", "ready", "metrics", ".well-known")
    ):
        return Response(content=b"Not Found", status_code=404)

    # 2. Resolve root assets (index-*.js, index-*.css)
    if re.fullmatch(r"index-[A-Za-z0-9_-]+\.(js|css)", clean_path):
        return _get_root_asset_compat_response(clean_path)

    # 3. For any other path with a file extension, 404
    if "." in clean_path.rsplit("/", 1)[-1]:
        return Response(content=b"Not Found", status_code=404)

    # 4. Serve the SPA index.html for navigation routes
    return _get_desk_html_response()


@get("/mfe/{app_name:str}/{version:str}/{file_path:path}")
async def serve_mfe_assets(
    app_name: str, version: str, file_path: str
) -> Response[bytes]:
    """Serve static assets for Micro-Frontend (MFE) remotes.

    Maps /mfe/{app}/{version}/{file} to the package's static/mfe directory.
    If the MFE is remote and MFE_PROXY_ENABLED is set, proxies the request.
    """
    remotes = discover_mfe_remotes()
    remote_url = remotes.get(app_name)

    if not remote_url:
        return Response(content=b"Not Found", status_code=404)

    # 1. Handle Proxying for Remote MFEs
    if remote_url.startswith(("http://", "https://")):
        if os.environ.get("FRAMEWORK_M_MFE_PROXY_ENABLED", "").lower() == "true":
            try:
                # Reconstruct the origin URL from the remote entry URL
                # Example: http://host:8000/mfe/app/1.0.0/remoteEntry.js -> http://host:8000
                origin = remote_url.split("/mfe/")[0]
                upstream_url = (
                    f"{origin}/mfe/{app_name}/{version}/{file_path.lstrip('/')}"
                )

                async with httpx.AsyncClient() as client:
                    response = await client.get(upstream_url, follow_redirects=True)
                    return Response(
                        content=response.content,
                        status_code=response.status_code,
                        media_type=response.headers.get(
                            "Content-Type", "application/javascript"
                        ),
                    )
            except Exception:
                # Fallback to 404 if proxy fails
                return Response(content=b"Proxy Error", status_code=502)
        else:
            # If proxying is disabled but URL is absolute, the browser should fetch directly.
            # But since the browser asked THIS host, we return 404 or a redirect?
            # Usually return 404 as discovery should have pointed the browser elsewhere.
            return Response(content=b"Not Found (Proxy disabled)", status_code=404)

    # 2. Local discovery (fallback)
    try:
        eps = importlib.metadata.entry_points(group="framework_m.frontend")
        target_ep = next((ep for ep in eps if ep.name == app_name), None)

        if not target_ep:
            return Response(content=b"Not Found", status_code=404)

        package_name = target_ep.module.split(".")[0]

        # Security: Ensure file_path doesn't escape directory (basic check)
        if ".." in file_path:
            return Response(content=b"Not Found", status_code=404)

        resource_path = (
            importlib.resources.files(package_name) / "static" / "mfe" / file_path
        )

        if resource_path.is_file():
            content_type = (
                mimetypes.guess_type(file_path)[0] or "application/javascript"
            )
            return Response(content=resource_path.read_bytes(), media_type=content_type)

    except Exception:
        pass

    return Response(content=b"Not Found", status_code=404)


def _inject_oauth_providers_into_html(html_bytes: bytes) -> bytes:
    """Inject configured OAuth providers into HTML before the config script."""
    try:
        providers: list[str] = get_oauth_config().get("providers", [])
    except Exception:
        providers = []

    providers_json = json.dumps(providers)
    injection = f"<script>globalThis.__FRAMEWORK_OAUTH_PROVIDERS__ = {providers_json};</script>\n"

    try:
        html = html_bytes.decode("utf-8")
    except UnicodeDecodeError:
        return html_bytes

    if "__FRAMEWORK_CONFIG__" not in html:
        return html_bytes

    if "</body>" in html:
        html = html.replace("</body>", injection + "</body>", 1)
    else:
        html = injection + html

    return html.encode("utf-8")


def _get_desk_html_response() -> Response[bytes]:
    """Get the Desk UI HTML response."""
    preferred_dist = _get_preferred_frontend_dist_path()
    if preferred_dist:
        preferred_index = preferred_dist / "index.html"
        if preferred_index.exists():
            html = _rewrite_root_asset_urls_for_desk(preferred_index.read_bytes())
            html = _inject_oauth_providers_into_html(html)
            return Response(content=html, media_type="text/html")

    try:
        shell_path = discover_active_shell()
        index_file = shell_path / "index.html"
        if index_file.is_file():
            html = _rewrite_root_asset_urls_for_desk(index_file.read_bytes())
            html = _inject_oauth_providers_into_html(html)
            return Response(content=html, media_type="text/html")
    except Exception:
        pass

    local_dirs = [
        Path.cwd() / "frontend" / "dist" / "index.html",
        Path.cwd() / "dist" / "index.html",
    ]
    for index_file in local_dirs:
        if index_file.exists():
            html = _rewrite_root_asset_urls_for_desk(index_file.read_bytes())
            html = _inject_oauth_providers_into_html(html)
            return Response(content=html, media_type="text/html")

    return Response(
        content=b"Desk UI not available. Run 'pnpm build' in frontend/ or install framework-m with bundled UI.",
        status_code=404,
    )


def _rewrite_root_asset_urls_for_desk(html_content: bytes) -> bytes:
    """Rewrite root asset URLs to /desk/* for SPA static serving."""
    try:
        html = html_content.decode("utf-8")
    except UnicodeDecodeError:
        return html_content

    rewritten = re.sub(
        r'(src|href)="/(?!desk/|/)([^"]+)"',
        r'\1="/desk/\2"',
        html,
    )
    rewritten = re.sub(
        r'(src|href)="(?:\./)?(?!https?:|data:|/|#)([^"]+)"',
        r'\1="/desk/\2"',
        rewritten,
    )
    return rewritten.encode("utf-8")


def _get_favicon_response() -> Response[bytes]:
    """Get favicon response from preferred, bundled, or local dist paths."""
    search_paths: list[Path] = []

    preferred_dist = _get_preferred_frontend_dist_path()
    if preferred_dist:
        search_paths.append(preferred_dist / "favicon.ico")

    bundled = _get_bundled_static_path()
    if bundled:
        search_paths.append(bundled / "favicon.ico")

    search_paths.extend(
        [
            Path.cwd() / "frontend" / "dist" / "favicon.ico",
            Path.cwd() / "dist" / "favicon.ico",
        ]
    )

    for favicon in search_paths:
        if favicon.exists() and favicon.is_file():
            return Response(content=favicon.read_bytes(), media_type="image/x-icon")

    return Response(content=b"Not Found", status_code=404)


def _get_root_asset_compat_response(asset_file: str) -> Response[bytes]:
    """Serve root index-* assets by resolving them to dist/assets locations."""
    import mimetypes

    if not re.fullmatch(r"index-[A-Za-z0-9_-]+\.(js|css)", asset_file):
        return Response(content=b"Not Found", status_code=404)

    search_paths: list[Path] = []

    preferred_dist = _get_preferred_frontend_dist_path()
    if preferred_dist:
        search_paths.extend(
            [
                preferred_dist / asset_file,
                preferred_dist / "assets" / asset_file,
            ]
        )

    bundled = _get_bundled_static_path()
    if bundled:
        search_paths.extend(
            [
                bundled / asset_file,
                bundled / "assets" / asset_file,
            ]
        )

    search_paths.extend(
        [
            Path.cwd() / "frontend" / "dist" / asset_file,
            Path.cwd() / "frontend" / "dist" / "assets" / asset_file,
            Path.cwd() / "dist" / asset_file,
            Path.cwd() / "dist" / "assets" / asset_file,
        ]
    )

    for file_path in search_paths:
        if file_path.exists() and file_path.is_file():
            content_type = mimetypes.guess_type(str(file_path))[0] or "text/plain"
            return Response(content=file_path.read_bytes(), media_type=content_type)

    return Response(content=b"Not Found", status_code=404)


def _get_bundled_static_path() -> Path | None:
    """Get path to bundled Desk static files from package."""
    try:
        static_dir = files("framework_m_standard") / "static"
        if hasattr(static_dir, "__fspath__"):
            static_path = Path(str(static_dir))
        else:
            try:
                static_path = Path(str(static_dir))
            except Exception:
                import contextlib
                from importlib.resources import as_file

                with contextlib.suppress(Exception), as_file(static_dir) as path:
                    static_path = path
                    if static_path.exists() and static_path.is_dir():
                        return Path(str(static_path))
                return None

        if static_path.exists() and static_path.is_dir():
            assets_dir = static_path / "assets"
            index_file = static_path / "index.html"
            if assets_dir.exists() or index_file.exists():
                return static_path
    except Exception as e:
        logger.warning("Could not locate bundled static files", error=str(e))

    return None


def _get_preferred_frontend_dist_path() -> Path | None:
    """Get explicitly requested frontend dist path from environment."""
    raw_path = os.environ.get(PREFERRED_FRONTEND_DIST_ENV)
    if not raw_path:
        return None

    path = Path(raw_path)
    if path.exists() and path.is_dir():
        return path

    return None


def create_static_files_config() -> list[Any]:
    """Create static files configuration."""
    configs: list[Any] = []

    preferred_dist = _get_preferred_frontend_dist_path()
    if preferred_dist:
        assets_dir = preferred_dist / "assets"
        if assets_dir.exists():
            logger.info("Using preferred frontend dist", path=str(preferred_dist))
            configs.append(
                create_static_files_router(
                    path="/desk/assets",
                    directories=[assets_dir],
                    html_mode=False,
                )
            )
            return configs

    bundled_path = _get_bundled_static_path()
    if bundled_path:
        assets_dir = bundled_path / "assets"
        if assets_dir.exists():
            logger.info("Using bundled static files", path=str(bundled_path))
            configs.append(
                create_static_files_router(
                    path="/desk/assets",
                    directories=[assets_dir],
                    html_mode=False,
                )
            )
            return configs

    search_dirs = [
        Path.cwd() / "frontend" / "dist",
        Path.cwd() / "dist",
        Path.cwd() / ".." / ".." / "frontend" / "dist",
    ]

    for d in search_dirs:
        if d.exists() and d.is_dir():
            assets_dir = d / "assets"
            if assets_dir.exists():
                logger.info("Using local static files", path=str(d))
                configs.append(
                    create_static_files_router(
                        path="/desk/assets",
                        directories=[assets_dir],
                        html_mode=False,
                    )
                )
                return configs

    fallback_assets = Path.cwd() / ".m" / "empty-assets"
    fallback_assets.mkdir(parents=True, exist_ok=True)
    logger.warning("Using empty static fallback", path=str(fallback_assets))
    return [
        create_static_files_router(
            path="/desk/assets",
            directories=[fallback_assets],
            html_mode=False,
        )
    ]


def get_asset_url(asset_path: str) -> str:
    """Get the URL for a static asset.

    If CDN is configured, returns CDN URL. Otherwise returns local URL.
    This function can be used in templates to generate asset URLs.
    """
    config = load_config()
    frontend_config = config.get("frontend", {})
    cdn_url = frontend_config.get("cdn_url")

    if cdn_url:
        if not cdn_url.endswith("/"):
            cdn_url += "/"
        return f"{cdn_url}{asset_path.lstrip('/')}"

    return f"/assets/{asset_path.lstrip('/')}"
