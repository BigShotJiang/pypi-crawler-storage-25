"""Adapter Factory - Auto-selects adapters based on environment.

This module provides factory functions that automatically select
the appropriate adapter based on environment configuration.

For local development without external dependencies:
- If NATS_URL not set → InMemoryJobQueue, InMemoryEventBus
- If REDIS_URL not set → MemoryCacheAdapter

For production:
- Set NATS_URL → TaskiqJobQueue, NatsEventBus
- Set REDIS_URL → RedisCacheAdapter
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from framework_m_core.interfaces.cache import CacheProtocol
    from framework_m_core.interfaces.event_bus import EventBusProtocol
    from framework_m_core.interfaces.job_queue import JobQueueProtocol


def get_job_queue() -> JobQueueProtocol:
    """Get the appropriate job queue based on environment."""
    from framework_m_core.container import Container

    container = Container()
    secrets = container.secrets_manager()
    nats_url = secrets.get("NATS_URL")

    if nats_url:
        from framework_m_standard.adapters.jobs.taskiq_adapter import (
            TaskiqJobQueueAdapter,
        )

        adapter = TaskiqJobQueueAdapter(nats_url=nats_url)
        if hasattr(container, "secrets_manager") and hasattr(
            adapter, "set_secrets_manager"
        ):
            adapter.set_secrets_manager(container.secrets_manager())
        return adapter

    from framework_m_standard.adapters.jobs import InMemoryJobQueue

    return InMemoryJobQueue()


def get_event_bus() -> EventBusProtocol:
    """Get the appropriate event bus based on environment."""
    from framework_m_core.container import Container

    container = Container()
    secrets = container.secrets_manager()
    nats_url = secrets.get("NATS_URL")

    if nats_url:
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        adapter = NatsEventBusAdapter(nats_url=nats_url)
        if hasattr(container, "secrets_manager") and hasattr(
            adapter, "set_secrets_manager"
        ):
            adapter.set_secrets_manager(container.secrets_manager())
        return adapter

    from framework_m_standard.adapters.events.inmemory_event_bus import InMemoryEventBus

    return InMemoryEventBus()


def get_cache() -> CacheProtocol:
    """Get the appropriate cache adapter based on environment."""
    from framework_m_core.container import Container

    container = Container()
    secrets = container.secrets_manager()
    redis_url = secrets.get("REDIS_URL")

    if redis_url:
        from framework_m_standard.adapters.cache import (
            MemoryCacheAdapter,
            MultiLevelCacheAdapter,
            RedisCacheAdapter,
        )

        l1 = MemoryCacheAdapter()
        l2 = RedisCacheAdapter(redis_url)
        if hasattr(container, "secrets_manager") and hasattr(l2, "set_secrets_manager"):
            l2.set_secrets_manager(container.secrets_manager())

        return MultiLevelCacheAdapter(l1, l2)

    from framework_m_standard.adapters.cache import MemoryCacheAdapter

    return MemoryCacheAdapter()


def is_dev_mode() -> bool:
    """Check if running in development mode (no external dependencies)."""
    from framework_m_core.container import Container

    container = Container()
    secrets = container.secrets_manager()
    return not secrets.get("NATS_URL") and not secrets.get("REDIS_URL")


__all__ = [
    "get_cache",
    "get_event_bus",
    "get_job_queue",
    "is_dev_mode",
]
