from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from sqlalchemy import MetaData


class SchemaChangeType(Enum):
    """Types of schema changes that can be detected."""

    NEW_TABLE = "new_table"
    NEW_COLUMN = "new_column"
    TYPE_CHANGE = "type_change"
    DROPPED_TABLE = "dropped_table"
    DROPPED_COLUMN = "dropped_column"
    NEW_INDEX = "new_index"
    DROPPED_INDEX = "dropped_index"


@dataclass
class SchemaChange:
    """Represents a detected schema change.

    Attributes:
        change_type: Type of change (new table, new column, etc.)
        table_name: Name of the affected table
        column_name: Name of the affected column (if applicable)
        old_type: Previous column type (for type changes)
        new_type: New column type (for type changes)
        details: Additional details about the change
    """

    change_type: SchemaChangeType
    table_name: str
    column_name: str | None = None
    old_type: str | None = None
    new_type: str | None = None
    details: dict[str, str] = field(default_factory=dict)


class SchemaDetector:
    """Detects schema differences between target and current metadata."""

    def __init__(self, version_table: str | None = None) -> None:
        """Initialize detector with optional alembic version table name to ignore."""
        self.version_table = version_table

    def _normalize_type(self, type_obj: Any) -> str:
        """Normalize a SQLAlchemy type into a base string for stable comparison."""
        type_str = str(type_obj).lower()
        base_type = type_str.split("(")[0].strip()

        if base_type in (
            "varchar",
            "string",
            "nvarchar",
            "character varying",
            "unicode",
        ):
            return "string"
        if base_type in ("text", "unicodetext"):
            return "text"
        if base_type in (
            "integer",
            "int",
            "bigint",
            "smallint",
            "tinyint",
            "boolean",
            "bool",
        ):
            return "integer"
        if base_type in ("numeric", "decimal", "float", "real", "double precision"):
            return "numeric"
        if base_type in ("jsonb", "json"):
            return "json"
        if base_type in ("blob", "binary", "largebinary", "bytea"):
            return "binary"
        if base_type in ("timestamp", "datetime"):
            return "datetime"

        return base_type

    def detect(
        self,
        target_metadata: MetaData,
        current_metadata: MetaData | None = None,
        allow_drop: bool = False,
        force_unowned: bool = False,
    ) -> list[SchemaChange]:
        """Run detection logic."""
        changes: list[SchemaChange] = []

        if current_metadata is None:
            current_metadata = MetaData()

        managed_tables = set(target_metadata.tables.keys())
        reflected_tables = set(current_metadata.tables.keys())

        # Detect new tables
        for table_name in managed_tables - reflected_tables:
            changes.append(
                SchemaChange(
                    change_type=SchemaChangeType.NEW_TABLE,
                    table_name=table_name,
                )
            )

        # Detect dropped tables
        if allow_drop and force_unowned:
            for table_name in reflected_tables - managed_tables:
                if table_name == "alembic_version" or table_name == self.version_table:
                    continue

                # Check for incoming foreign keys
                incoming_fks = []
                for t in current_metadata.tables.values():
                    for fk in t.foreign_keys:
                        if fk.column.table.name == table_name:
                            incoming_fks.append(f"{t.name}({fk.parent.name})")

                changes.append(
                    SchemaChange(
                        change_type=SchemaChangeType.DROPPED_TABLE,
                        table_name=table_name,
                        details={"incoming_fks": ",".join(incoming_fks)}
                        if incoming_fks
                        else {},
                    )
                )

        # Detect column changes for existing tables
        for table_name in managed_tables & reflected_tables:
            target_table = target_metadata.tables[table_name]
            current_table = current_metadata.tables[table_name]

            target_columns = {c.name for c in target_table.columns}
            current_columns = {c.name for c in current_table.columns}

            # New columns
            for column_name in target_columns - current_columns:
                changes.append(
                    SchemaChange(
                        change_type=SchemaChangeType.NEW_COLUMN,
                        table_name=table_name,
                        column_name=column_name,
                    )
                )

            # Dropped columns
            if allow_drop:
                for column_name in current_columns - target_columns:
                    changes.append(
                        SchemaChange(
                            change_type=SchemaChangeType.DROPPED_COLUMN,
                            table_name=table_name,
                            column_name=column_name,
                        )
                    )

            # Type changes (for columns that exist in both)
            for column_name in target_columns & current_columns:
                target_col = target_table.columns[column_name]
                current_col = current_table.columns[column_name]

                target_type = self._normalize_type(target_col.type)
                current_type = self._normalize_type(current_col.type)

                type_changed = target_type != current_type
                details = {}

                # Handle Postgres ENUM value changes
                target_enums = getattr(target_col.type, "enums", None)
                current_enums = getattr(current_col.type, "enums", None)

                if (
                    target_enums is not None
                    and current_enums is not None
                    and tuple(target_enums) != tuple(current_enums)
                ):
                    type_changed = True
                    details["target_enums"] = ",".join(target_enums)
                    details["current_enums"] = ",".join(current_enums)

                if type_changed:
                    changes.append(
                        SchemaChange(
                            change_type=SchemaChangeType.TYPE_CHANGE,
                            table_name=table_name,
                            column_name=column_name,
                            old_type=current_type,
                            new_type=target_type,
                            details=details,
                        )
                    )

            # Index changes
            from sqlalchemy import UniqueConstraint

            target_indices = {
                (tuple(c.name for c in idx.columns), getattr(idx, "unique", False))
                for idx in target_table.indexes
            }
            target_indices.update(
                (tuple(c.name for c in cons.columns), True)
                for cons in getattr(target_table, "constraints", set())
                if isinstance(cons, UniqueConstraint)
            )

            current_indices = {
                (tuple(c.name for c in idx.columns), getattr(idx, "unique", False))
                for idx in current_table.indexes
            }
            current_indices.update(
                (tuple(c.name for c in cons.columns), True)
                for cons in getattr(current_table, "constraints", set())
                if isinstance(cons, UniqueConstraint)
            )

            for idx_spec in target_indices - current_indices:
                changes.append(
                    SchemaChange(
                        change_type=SchemaChangeType.NEW_INDEX,
                        table_name=table_name,
                        column_name=", ".join(idx_spec[0]),
                    )
                )

            if allow_drop:
                for idx_spec in current_indices - target_indices:
                    cols = idx_spec[0]
                    is_implicit = False

                    # Check if index exactly matches the Primary Key
                    pk_cols = tuple(c.name for c in current_table.primary_key.columns)
                    if cols == pk_cols:
                        is_implicit = True

                    # Check if index exactly matches a single Foreign Key
                    for fk in getattr(current_table, "foreign_keys", []):
                        if cols == (fk.parent.name,):
                            is_implicit = True
                            break

                    if not is_implicit:
                        changes.append(
                            SchemaChange(
                                change_type=SchemaChangeType.DROPPED_INDEX,
                                table_name=table_name,
                                column_name=", ".join(idx_spec[0]),
                            )
                        )

        return changes


__all__ = ["SchemaChange", "SchemaChangeType"]
