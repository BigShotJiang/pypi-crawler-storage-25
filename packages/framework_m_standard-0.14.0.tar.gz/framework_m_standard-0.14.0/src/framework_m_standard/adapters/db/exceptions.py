"""Custom exceptions for the database adapter."""


class DDLPermissionDeniedError(Exception):
    """Raised when the database user lacks permissions to execute DDL operations."""


class DangerousOperationError(Exception):
    """Raised when a dangerous database operation is detected during migration."""
