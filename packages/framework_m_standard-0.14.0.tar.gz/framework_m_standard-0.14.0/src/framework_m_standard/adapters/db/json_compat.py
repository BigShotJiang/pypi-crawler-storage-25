"""JSON compatibility helpers for database persistence."""

from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal
from typing import Any
from uuid import UUID


def to_json_compatible(value: Any) -> Any:
    """Convert runtime values into JSON-serializable equivalents.

    Custom field payloads are stored in JSON columns and must not contain
    Python-native types such as Decimal, date/datetime, or UUID objects.
    """

    if isinstance(value, Decimal):
        # Keep precision instead of coercing to float.
        return str(value)

    if isinstance(value, (datetime, date, time)):
        return value.isoformat()

    if isinstance(value, UUID):
        return str(value)

    if isinstance(value, list):
        return [to_json_compatible(item) for item in value]

    if isinstance(value, tuple):
        return [to_json_compatible(item) for item in value]

    if isinstance(value, dict):
        return {str(key): to_json_compatible(item) for key, item in value.items()}

    return value
