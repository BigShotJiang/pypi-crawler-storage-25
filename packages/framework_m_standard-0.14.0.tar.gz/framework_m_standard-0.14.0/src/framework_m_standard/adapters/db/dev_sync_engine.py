import json

from sqlalchemy import MetaData, Table
from sqlalchemy.engine import Engine

from framework_m_standard.adapters.db.exceptions import (
    DangerousOperationError,
    DDLPermissionDeniedError,
)
from framework_m_standard.adapters.db.schema_detector import (
    SchemaChange,
    SchemaChangeType,
)
from framework_m_standard.adapters.discovery import mask_url_credentials


class DevSyncEngine:
    """Applies schema changes directly to the database via DDL for dev mode."""

    def sync(
        self,
        target_metadata: MetaData,
        changes: list[SchemaChange],
        engine: Engine,
        max_lock_time: int | None = None,
        allow_dangerous: bool = False,
    ) -> None:
        """Execute raw DDL commands to apply changes."""
        from sqlalchemy import text
        from sqlalchemy.types import JSON

        # Pre-check DDL permissions
        if engine.dialect.name != "sqlite":
            try:
                with engine.begin() as conn:
                    conn.execute(
                        text(
                            "CREATE TEMPORARY TABLE _ddl_permission_check (id INTEGER)"
                        )
                    )
                    conn.execute(text("DROP TABLE _ddl_permission_check"))
            except Exception as e:  # pragma: no cover
                masked_url = mask_url_credentials(str(engine.url))
                raise DDLPermissionDeniedError(
                    f"DDL permission check failed for {masked_url}: {e}"
                ) from e

        with engine.begin() as conn:
            if max_lock_time and engine.dialect.name == "postgresql":
                conn.execute(text(f"SET LOCAL lock_timeout = '{max_lock_time}s';"))

            if target_metadata.schema and engine.dialect.name == "postgresql":
                conn.execute(
                    text(f'CREATE SCHEMA IF NOT EXISTS "{target_metadata.schema}"')
                )

            # 1. Create all new tables together to handle circular FKs safely
            new_tables: list[Table] = []
            for change in changes:
                if change.change_type == SchemaChangeType.NEW_TABLE:
                    table = target_metadata.tables.get(change.table_name)
                    if table is not None:
                        new_tables.append(table)

            if new_tables:
                target_metadata.create_all(bind=conn, tables=new_tables)

            # 2. Add new columns
            for change in changes:
                if change.change_type == SchemaChangeType.NEW_COLUMN:
                    table = target_metadata.tables.get(change.table_name)
                    if table is not None and change.column_name:
                        column = table.c.get(change.column_name)
                        if column is not None:
                            if (
                                not column.nullable
                                and column.default is None
                                and column.server_default is None
                                and not allow_dangerous
                            ):
                                raise DangerousOperationError(
                                    f"Detected dangerous operation: adding NOT NULL column '{change.column_name}' without a default."
                                )

                            col_type = column.type.compile(dialect=engine.dialect)
                            nullable = "NULL" if column.nullable else "NOT NULL"
                            default = ""
                            if column.default is not None:
                                default_val = getattr(column.default, "arg", None)
                                if callable(default_val):
                                    if (
                                        isinstance(column.type, JSON)
                                        and default_val is dict
                                    ):
                                        default = " DEFAULT '{}'"
                                    elif (
                                        isinstance(column.type, JSON)
                                        and default_val is list
                                    ):
                                        default = " DEFAULT '[]'"
                                elif isinstance(default_val, str):
                                    escaped = default_val.replace("'", "''")
                                    default = f" DEFAULT '{escaped}'"
                                elif isinstance(default_val, (dict, list)):
                                    if isinstance(column.type, JSON):
                                        json_default = json.dumps(default_val)
                                        escaped = json_default.replace("'", "''")
                                        default = f" DEFAULT '{escaped}'"
                                elif default_val is not None:
                                    default = f" DEFAULT {default_val}"

                            if (
                                not default
                                and change.column_name == "custom_fields"
                                and isinstance(column.type, JSON)
                            ):
                                default = " DEFAULT '{}'"

                            if "sqlite" in str(engine.url):
                                sql = (
                                    f"ALTER TABLE {change.table_name} "
                                    f"ADD COLUMN {change.column_name} "
                                    f"{col_type}{default}"
                                )
                            else:
                                sql = (
                                    f"ALTER TABLE {change.table_name} "
                                    f"ADD COLUMN {change.column_name} "
                                    f"{col_type} {nullable}{default}"
                                )
                            conn.execute(text(sql))
