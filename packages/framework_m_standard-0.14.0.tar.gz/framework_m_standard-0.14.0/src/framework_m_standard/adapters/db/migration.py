"""Migration support for Framework M using Alembic.

This module provides utilities for database migrations using Alembic,
with integration to the Framework M DocType system.

Features:
- Auto-detection of schema changes from DocType definitions
- Integration with MetaRegistry and SchemaMapper
- Async database support
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING

from alembic.config import Config
from sqlalchemy import MetaData

from alembic import command
from framework_m_standard.adapters.db.dev_sync_engine import DevSyncEngine
from framework_m_standard.adapters.db.exceptions import DDLPermissionDeniedError
from framework_m_standard.adapters.db.migration_templates import (
    ALEMBIC_ENV_PY_CONTENT,
    ALEMBIC_INI_TEMPLATE,
    ALEMBIC_SCRIPT_PY_MAKO_CONTENT,
)
from framework_m_standard.adapters.db.schema_detector import (
    SchemaChange,
    SchemaDetector,
)
from framework_m_standard.adapters.discovery import resolve_app_modules

if TYPE_CHECKING:
    from framework_m_core.services.secrets_service import SecretsManager
    from sqlalchemy.engine import Engine


class MigrationManager:
    """Manages database migrations using Alembic.

    This class provides methods to initialize, run, and manage
    database migrations for Framework M applications.

    Example:
        >>> manager = MigrationManager("/path/to/app")
        >>> manager.init()  # Initialize Alembic
        >>> manager.upgrade("head")  # Run migrations
    """

    def __init__(
        self,
        base_path: str | Path,
        database_url: str | None = None,
        secrets_manager: SecretsManager | None = None,
        version_table: str | None = None,
        x_args: tuple[str, ...] | None = None,
        schema_detector: SchemaDetector | None = None,
        dev_sync_engine: DevSyncEngine | None = None,
    ) -> None:
        """Initialize the migration manager.

        Args:
            base_path: Base path for the application (where alembic/ will be created)
            database_url: Database connection URL (can also come from env var)
            secrets_manager: Optional secrets manager for resolving URLs
            version_table: Custom Alembic version table name
            x_args: Additional arguments for env.py scripts
            schema_detector: Optional injected schema detector
            dev_sync_engine: Optional injected development sync engine
        """
        self._base_path = Path(base_path)
        self._secrets = secrets_manager

        if database_url:
            self._database_url = database_url
        elif self._secrets:
            self._database_url = self._secrets.get("DATABASE_URL") or ""
        else:
            self._database_url = os.environ.get("DATABASE_URL", "")
        self._version_table = version_table
        self._x_args = x_args
        self._alembic_path = self._base_path / "alembic"
        self._config: Config | None = None
        self._schema_detector = schema_detector or SchemaDetector(
            version_table=self._version_table
        )
        self._dev_sync_engine = dev_sync_engine or DevSyncEngine()

    @property
    def alembic_path(self) -> Path:
        """Path to the alembic directory."""
        return self._alembic_path

    @property
    def versions_path(self) -> Path:
        """Path to the versions directory."""
        return self._alembic_path / "versions"

    @property
    def config(self) -> Config:
        """Get or create the Alembic configuration."""
        if self._config is None:
            self._config = self._create_config()
        return self._config

    def _create_config(self) -> Config:
        """Create an Alembic configuration object.

        Returns:
            Configured Alembic Config object
        """
        import importlib.metadata
        import importlib.util

        ini_path = self._base_path / "alembic.ini"
        config = Config(str(ini_path) if ini_path.exists() else None)

        if self._x_args:
            from argparse import Namespace

            cmd_opts = getattr(config, "cmd_opts", None)
            if cmd_opts is None:
                cmd_opts = Namespace()
                config.cmd_opts = cmd_opts
            cmd_opts.x = list(self._x_args)

        # 1. Set base script location
        config.set_main_option("script_location", str(self._alembic_path))

        # 2. Dynamic Version Locations
        version_locations = [str(self.versions_path)]

        # Discover versions from installed apps
        apps = resolve_app_modules(self._base_path)

        for app_name in apps:
            spec = importlib.util.find_spec(app_name)
            if spec and spec.origin:
                package_path = Path(spec.origin).parent
                custom_versions = package_path / "migrations"
                app_versions = package_path / "alembic" / "versions"
                if custom_versions.exists() and custom_versions.is_dir():
                    version_locations.append(str(custom_versions))
                elif app_versions.exists() and app_versions.is_dir():
                    version_locations.append(str(app_versions))

        config.set_main_option("version_locations", " ".join(version_locations))
        config.set_main_option("version_path_separator", "os")

        if self._version_table:
            config.set_main_option("version_table", self._version_table)

        # 3. Set database URL
        if self._database_url:
            config.set_main_option("sqlalchemy.url", self._database_url)
        elif not ini_path.exists():
            config.set_main_option("sqlalchemy.url", "sqlite+aiosqlite:///./dev.db")

        return config

    def init(self, metadata: MetaData | None = None) -> None:
        """Initialize Alembic for this project.

        Creates the alembic directory structure and configuration files.

        Args:
            metadata: Optional SQLAlchemy MetaData for schema comparison
        """
        # Create directories
        self._alembic_path.mkdir(parents=True, exist_ok=True)
        self.versions_path.mkdir(parents=True, exist_ok=True)

        # Create alembic.ini if it doesn't exist
        self._create_alembic_ini()

        # Create env.py with async support
        self._create_env_py()

        # Create script.py.mako template
        self._create_script_template()

    def _create_alembic_ini(self) -> None:
        """Create the alembic.ini configuration file."""
        ini_path = self._base_path / "alembic.ini"

        if ini_path.exists():
            return

        db_url = self._database_url or "sqlite+aiosqlite:///./dev.db"

        ini_content = ALEMBIC_INI_TEMPLATE.format(db_url=db_url)
        ini_path.write_text(ini_content)

    def _create_env_py(self) -> None:
        """Create the env.py file with async support and DocType discovery."""
        env_path = self._alembic_path / "env.py"

        if env_path.exists():
            return

        env_path.write_text(ALEMBIC_ENV_PY_CONTENT)

    def _create_script_template(self) -> None:
        """Create the script.py.mako template."""
        template_path = self._alembic_path / "script.py.mako"

        if template_path.exists():
            return

        template_path.write_text(ALEMBIC_SCRIPT_PY_MAKO_CONTENT)

    def upgrade(self, revision: str = "head") -> None:
        """Upgrade to a later version.

        Args:
            revision: Target revision (default: "head")
        """
        command.upgrade(self.config, revision)

    def downgrade(self, revision: str = "-1") -> None:
        """Downgrade to a previous version.

        Args:
            revision: Target revision (default: previous version)
        """
        command.downgrade(self.config, revision)

    def revision(
        self,
        message: str,
        autogenerate: bool = True,
        version_path: str | Path | None = None,
        target_metadata: MetaData | None = None,
    ) -> None:
        """Create a new revision file.

        Args:
            message: Message describing the revision
            autogenerate: Whether to auto-detect schema changes
            version_path: Optional specific path to store the migration
            target_metadata: Optional SQLAlchemy MetaData for schema comparison
        """
        config = self.config
        if version_path:
            config.set_main_option("version_locations", str(version_path))
        if target_metadata is not None:
            config.attributes["target_metadata"] = target_metadata

        command.revision(
            config,
            message=message,
            autogenerate=autogenerate,
        )

    def current(self) -> None:
        """Display the current revision."""
        command.current(self.config)

    def history(self) -> None:
        """List revision history."""
        command.history(self.config)

    def heads(self) -> None:
        """Show current available heads."""
        command.heads(self.config)

    def has_multiple_heads(self) -> bool:
        """Check if there are multiple branches/heads in the migration history."""
        from alembic.script import ScriptDirectory

        script = ScriptDirectory.from_config(self.config)
        return len(script.get_heads()) > 1

    def merge(
        self,
        revisions: str | list[str] = "heads",
        message: str = "Merge multiple heads",
    ) -> None:
        """Merge multiple revision heads.

        Args:
            revisions: Revisions to merge (default: "heads" merges all heads)
            message: Message describing the merge
        """
        command.merge(self.config, revisions=revisions, message=message)

    def detect_schema_changes(
        self,
        target_metadata: MetaData,
        current_metadata: MetaData | None = None,
        allow_drop: bool = False,
        force_unowned: bool = False,
    ) -> list[SchemaChange]:
        """Detect schema changes between target and current database schema.

        Compares the target metadata (from DocType definitions) with the
        current database schema to detect:
        - New tables
        - New columns
        - Type changes
        - Dropped tables/columns

        Args:
            target_metadata: Target schema (from DocTypes)
            current_metadata: Current database schema (if None, compares against empty)
            allow_drop: If True, detect and return dropped tables/columns
            force_unowned: If True, allow dropping tables not owned by target metadata

        Returns:
            List of SchemaChange objects describing detected changes
        """
        return self._schema_detector.detect(
            target_metadata=target_metadata,
            current_metadata=current_metadata,
            allow_drop=allow_drop,
            force_unowned=force_unowned,
        )

    def auto_migrate(
        self,
        target_metadata: MetaData,
        dry_run: bool = False,
        dev_mode: bool = False,
        engine: Engine | None = None,
        allow_drop: bool = False,
        allow_dangerous: bool = False,
        force_unowned: bool = False,
        max_lock_time: int | None = None,
    ) -> list[SchemaChange]:
        """Auto-detect and optionally apply schema migrations.

        This method:
        1. Reflects current database schema
        2. Detects schema changes from target metadata
        3. If dev_mode is True, applies changes directly using DDL
        4. Otherwise, generates an Alembic migration file

        Args:
            target_metadata: Target schema (from DocTypes)
            dry_run: If True, only detect changes without applying
            dev_mode: If True, apply changes directly (no Alembic)
            engine: SQLAlchemy engine for reflection (uses database_url if None)
            allow_drop: If True, detect and apply table/column drops
            force_unowned: If True, allow dropping unowned tables
            max_lock_time: Max lock time in seconds for DDL operations (PostgreSQL only)

        Returns:
            List of detected SchemaChange objects
        """
        from sqlalchemy import create_engine

        # Create engine if not provided
        if engine is None:
            db_url = self._database_url or "sqlite+aiosqlite:///app.db"
            engine = create_engine(db_url)

        # Reflect current database schema
        current_metadata = MetaData()
        current_metadata.reflect(bind=engine)

        # Detect changes
        changes = self.detect_schema_changes(
            target_metadata=target_metadata,
            current_metadata=current_metadata,
            allow_drop=allow_drop,
            force_unowned=force_unowned,
        )

        if not changes or dry_run:
            return changes

        if dev_mode:
            # Apply changes directly using DDL (avoids Alembic async issues)
            self._dev_sync_engine.sync(
                target_metadata=target_metadata,
                changes=changes,
                engine=engine,
                max_lock_time=max_lock_time,
                allow_dangerous=allow_dangerous,
            )
        else:
            # Generate Alembic migration (for production use)
            change_summary = ", ".join(
                f"{c.change_type.value}: {c.table_name}" for c in changes[:3]
            )
            if len(changes) > 3:
                change_summary += f" (+{len(changes) - 3} more)"

            self.revision(
                message=f"Auto-migration: {change_summary}",
                autogenerate=True,
                target_metadata=target_metadata,
            )
            self.upgrade("head")

        return changes


__all__ = ["MigrationManager", "DDLPermissionDeniedError"]
