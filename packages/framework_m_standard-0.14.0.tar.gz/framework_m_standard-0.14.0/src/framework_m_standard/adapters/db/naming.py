"""Naming Service - Auto-generates unique names for documents."""

from __future__ import annotations

import re
from datetime import UTC, datetime
from uuid import uuid4

from framework_m_core.domain.base_doctype import BaseDocType
from sqlalchemy import Sequence, Table, select
from sqlalchemy.ext.asyncio import AsyncSession


class DocumentNamingService[T: BaseDocType]:
    """Service for generating document names.

    Handles UUID defaults, naming patterns, and database sequences.
    """

    def __init__(self, model: type[T], table: Table) -> None:
        """Initialize the naming service.

        Args:
            model: The DocType model class
            table: SQLAlchemy Table object for querying counters
        """
        self._model = model
        self._table = table

    async def generate_name(self, session: AsyncSession, entity: T) -> str:
        """Generate a unique name for an entity based on Meta.name_pattern.

        If Meta.name_pattern is defined, generates name using pattern.
        Otherwise, uses default UUID-based naming.

        Supports:
        - Regular patterns: "INV-.YYYY.-.####" -> "INV-2026-0001"
        - Sequence patterns: "sequence:invoice_seq" -> Uses DB sequence

        Args:
            session: SQLAlchemy async session for counter queries
            entity: The entity to generate name for

        Returns:
            Generated name string
        """
        # Check if model has name_pattern
        meta = getattr(self._model, "Meta", None)
        name_pattern = getattr(meta, "name_pattern", None) if meta else None

        if not name_pattern:
            # No pattern - use default UUID-based naming
            prefix = self._model.__name__.upper()[:4]
            unique_part = uuid4().hex[:8].upper()
            return f"{prefix}-{unique_part}"

        # Check for sequence-based pattern
        if name_pattern.startswith("sequence:"):
            return await self._generate_name_from_sequence(session, name_pattern)

        # Generate name from regular pattern
        return await self._generate_name_from_pattern(session, entity, name_pattern)

    async def _generate_name_from_sequence(
        self, session: AsyncSession, pattern: str
    ) -> str:
        """Generate name using a database sequence.

        For PostgreSQL, uses native sequences for high performance.
        For other databases, falls back to counter-based approach.

        Args:
            session: SQLAlchemy async session
            pattern: Sequence pattern like "sequence:invoice_seq"

        Returns:
            Generated name from sequence value
        """
        sequence_name = pattern.split(":", 1)[1]
        prefix = f"{self._model.__name__.upper()[:4]}-"

        # Try to use native PostgreSQL sequence
        try:
            # Check if we're on PostgreSQL by trying to use nextval via builder
            stmt = select(Sequence(sequence_name).next_value())
            result = await session.execute(stmt)
            seq_value = result.scalar()
            return f"{prefix}{seq_value:08d}"

        except Exception:
            # Fallback for non-PostgreSQL (SQLite, etc.)
            # Use prefix-based counter approach
            counter = await self._get_next_counter(session, prefix)
            return f"{prefix}{counter:08d}"

    async def _generate_name_from_pattern(
        self, session: AsyncSession, entity: T, pattern: str
    ) -> str:
        """Generate name from naming pattern.

        Args:
            session: SQLAlchemy async session
            entity: The entity
            pattern: Naming pattern string

        Returns:
            Generated name
        """
        now = datetime.now(UTC)

        # Replace date/time placeholders
        result = pattern
        result = result.replace(".YYYY.", f"{now.year}")
        result = result.replace(".MM.", f"{now.month:02d}")
        result = result.replace(".DD.", f"{now.day:02d}")

        # Also handle patterns without surrounding dots
        result = result.replace("YYYY", f"{now.year}")
        result = result.replace("MM", f"{now.month:02d}")
        result = result.replace("DD", f"{now.day:02d}")

        # Replace field value placeholders {field}
        field_pattern = re.compile(r"\{(\w+)\}")
        for match in field_pattern.finditer(result):
            field_name = match.group(1)
            if hasattr(entity, field_name):
                field_value = getattr(entity, field_name)
                result = result.replace(f".{{{field_name}}}.", str(field_value))
                result = result.replace(f"{{{field_name}}}", str(field_value))

        # Remove pattern separator dots (.) - they delimit placeholders
        result = result.replace(".", "")

        # Count # characters to determine counter width
        hash_count = pattern.count("#")
        if hash_count == 0:
            # No counter needed
            return result

        # Get prefix (everything before the counter)
        prefix = result.split("#")[0]

        # Get next counter value for this prefix
        counter = await self._get_next_counter(session, prefix)

        # Replace #### with padded counter
        counter_str = str(counter).zfill(hash_count)
        result = result.replace("#" * hash_count, counter_str)

        return result

    async def _get_next_counter(self, session: AsyncSession, prefix: str) -> int:
        """Get next counter value for a prefix."""
        stmt = (
            select(self._table.c.name)
            .where(self._table.c.name.like(f"{prefix}%"))
            .order_by(self._table.c.name.desc())
        )
        result = await session.execute(stmt)
        rows = result.fetchall()

        if not rows:
            return 1

        last_name = rows[0][0]
        suffix = last_name[len(prefix) :]

        try:
            last_counter = int(suffix)
            return last_counter + 1
        except ValueError:
            return 1


__all__ = ["DocumentNamingService"]
