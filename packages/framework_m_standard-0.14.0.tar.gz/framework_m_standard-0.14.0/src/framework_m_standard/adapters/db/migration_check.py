"""Migration Status Utility.

Provides checks for database migration readiness, particularly for
Zero Downtime Migration (ZDM) scenarios.
"""

import os

from alembic.migration import MigrationContext
from alembic.script import ScriptDirectory
from framework_m_core.registry import MetaRegistry
from sqlalchemy import MetaData
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import AsyncEngine

from framework_m_standard.adapters.db.schema_detector import (
    SchemaChangeType,
)
from framework_m_standard.adapters.discovery import get_project_root


class MigrationStatusUtility:
    """Utility for checking database migration readiness."""

    def __init__(self, engine: AsyncEngine) -> None:
        """Initialize the utility.

        Args:
            engine: The SQLAlchemy async engine.
        """
        self.engine = engine

    async def is_up_to_date(self, graceful_sync: bool = False) -> bool:
        """Check if the database migrations are up to date.

        Args:
            graceful_sync: If True, allows readiness even if there are pending
                           non-breaking declarative changes.

        Returns:
            True if up to date or within graceful sync parameters, False otherwise.
        """
        # Phase 1: Check mandatory Alembic state
        if not await self._is_alembic_up_to_date():
            return False

        # Phase 2: Check Declarative Sync state (configurable for ZDM)
        check_declarative = os.environ.get(
            "CHECK_DECLARATIVE_SYNC", "True"
        ).lower() in ("true", "1", "t", "yes")

        if not check_declarative:
            return True

        return not await self._has_breaking_declarative_changes()

    async def _is_alembic_up_to_date(self) -> bool:
        """Check if Alembic head matches the database's current revision."""
        async with self.engine.connect() as conn:
            return await conn.run_sync(self._sync_check_alembic)

    async def _has_breaking_declarative_changes(self) -> bool:
        """Check if there are breaking declarative schema changes pending."""
        async with self.engine.connect() as conn:
            return await conn.run_sync(self._sync_check_declarative)

    @staticmethod
    def _sync_check_alembic(conn: Connection) -> bool:
        from framework_m_core.container import Container

        container = Container()

        manager = container.migration_manager(base_path=get_project_root())
        script = ScriptDirectory.from_config(manager.config)

        context = MigrationContext.configure(conn)
        db_heads = set(context.get_current_heads())
        script_heads = set(script.get_heads())

        if not script_heads:
            return True

        return db_heads == script_heads

    @staticmethod
    def _sync_check_declarative(conn: Connection) -> bool:
        current_metadata = MetaData()
        current_metadata.reflect(bind=conn)

        target_metadata = MetaData()
        from framework_m_core.container import Container

        container = Container()

        mapper = container.schema_mapper()
        registry = MetaRegistry.get_instance()

        for doctype_name in registry.list_doctypes():
            doctype_class = registry.get_doctype(doctype_name)
            mapper.create_tables(doctype_class, target_metadata)

        manager = container.migration_manager(base_path=get_project_root())
        changes = manager.detect_schema_changes(target_metadata, current_metadata)

        breaking_types = {
            SchemaChangeType.DROPPED_TABLE,
            SchemaChangeType.DROPPED_COLUMN,
            SchemaChangeType.TYPE_CHANGE,
        }

        return any(change.change_type in breaking_types for change in changes)
