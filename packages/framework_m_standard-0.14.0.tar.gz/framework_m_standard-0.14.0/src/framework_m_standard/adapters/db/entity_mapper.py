"""Entity Mapper - Converts between DB rows and Domain Entities."""

from __future__ import annotations

from typing import Any

from framework_m_core.domain.base_doctype import BaseDocType
from sqlalchemy import Table

from framework_m_standard.adapters.db.child_table import ChildTableManager
from framework_m_standard.adapters.db.json_compat import to_json_compatible


class EntityRowMapper[T: BaseDocType]:
    """Handles mapping between SQLAlchemy rows and Pydantic entities."""

    def __init__(
        self,
        model: type[T],
        table: Table,
        child_table_manager: ChildTableManager[T],
    ) -> None:
        self._model = model
        self._table = table
        self._child_table_manager = child_table_manager

    def row_to_entity(self, row: Any) -> T:
        """Convert a database row to an entity."""
        data = dict(row._mapping)
        custom_fields = data.pop("custom_fields", {})
        if isinstance(custom_fields, dict):
            data.update(custom_fields)

        model_fields = set(self._model.model_fields.keys())
        filtered_data: dict[str, Any] = {}
        for key, value in data.items():
            if key in model_fields:
                if value == "true":
                    filtered_data[key] = True
                elif value == "false":
                    filtered_data[key] = False
                else:
                    filtered_data[key] = value

        return self._model.model_validate(filtered_data)

    def get_excluded_fields(self) -> set[str]:
        """Get fields that should be excluded from database operations."""
        excluded: set[str] = set()
        child_fields = self._child_table_manager.get_child_table_fields()
        excluded.update(child_fields.keys())
        computed_fields = getattr(self._model, "model_computed_fields", {})
        excluded.update(computed_fields.keys())
        return excluded

    def entity_to_db_payload(
        self, entity: T, exclude_fields: set[str]
    ) -> dict[str, Any]:
        """Build DB payload from entity attributes."""
        table_columns = {column.name for column in self._table.columns}
        payload: dict[str, Any] = {"custom_fields": {}}
        for field_name, field_info in self._model.model_fields.items():
            if field_name in exclude_fields:
                continue
            value = getattr(entity, field_name, None)
            extra = field_info.json_schema_extra
            if isinstance(extra, dict) and extra.get("persistence") == "json":
                payload["custom_fields"][field_name] = to_json_compatible(value)
            elif field_name in table_columns:
                payload[field_name] = value
        return payload
