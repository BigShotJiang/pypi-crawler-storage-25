"""Templates for Alembic initialization."""

ALEMBIC_INI_TEMPLATE = """# Alembic Configuration for Framework M
# Auto-generated - customize as needed

[alembic]
script_location = alembic
prepend_sys_path = .
version_path_separator = os

# Database URL - recommend setting via DATABASE_URL env var
# For async SQLite: sqlite+aiosqlite:///./dev.db
# For PostgreSQL: postgresql+asyncpg://user:pass@localhost/dbname
sqlalchemy.url = {db_url}

[post_write_hooks]

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level = WARN
handlers = console
qualname =

[logger_sqlalchemy]
level = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level = INFO
handlers =
qualname = alembic

[handler_console]
class = StreamHandler
args = (sys.stderr,)
level = NOTSET
formatter = generic

[formatter_generic]
format = %(levelname)-5.5s [%(name)s] %(message)s
datefmt = %H:%M:%S
"""

ALEMBIC_ENV_PY_CONTENT = '''"""Alembic environment configuration for Framework M.

This file is auto-generated but can be customized.
It provides async database support and integration with the DocType system.
"""

import asyncio
import os
import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import MetaData, pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

# Add project root to path for imports
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

config = context.config

# Interpret the config file for Python logging
if config.config_file_name is not None:
    fileConfig(config.config_file_name)


def discover_doctypes() -> MetaData:
    """Discover DocTypes from the project and build MetaData.

    Prioritizes discovery from INSTALLED_APPS (env var).
    Falls back to automated entry-point discovery.
    """
    from framework_m_standard.adapters.discovery import resolve_app_modules, get_project_root
    from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
    from framework_m_core.registry import MetaRegistry

    metadata = MetaData()
    mapper = SchemaMapper()
    registry = MetaRegistry.get_instance()

    apps = resolve_app_modules(get_project_root())
    registry.load_apps(apps)

    # Build MetaData from all registered DocTypes
    for name in registry.list_doctypes():
        doctype_class = registry.get_doctype(name)
        mapper.create_table(doctype_class, metadata)

    return metadata


# Build target_metadata from discovered DocTypes
target_metadata = config.attributes.get("target_metadata")
if target_metadata is None:
    target_metadata = discover_doctypes()


def get_url() -> str:
    """Get database URL from config or environment."""
    url = config.get_main_option("sqlalchemy.url")
    if url and not url.startswith("${"):
        return url

    from framework_m_standard.adapters.discovery import mask_url_credentials
    from framework_m_standard.adapters.secrets.env_secret import EnvSecretAdapter
    secrets = EnvSecretAdapter()
    db_url = secrets.get_secret("DATABASE_URL", "")
    return mask_url_credentials(db_url)


def process_revision_directives(context, revision, directives):
    """Modify the auto-generated revision for determinism."""
    import hashlib
    from alembic.operations import ops

    if not directives:
        return

    script = directives[0]

    # 1. Deterministic Sorting
    def sort_operations(directive):
        if hasattr(directive, "ops"):
            # Sort operations by type and table name
            directive.ops.sort(key=lambda x: (
                type(x).__name__,
                getattr(x, "table_name", None) or getattr(x, "name", None) or ""
            ))

            # Sort columns within create table operations
            for op in directive.ops:
                if isinstance(op, ops.CreateTableOp):
                    op.columns.sort(key=lambda c: getattr(c, "name", None) or type(c).__name__)
                elif hasattr(op, "ops"):
                    sort_operations(op)

    sort_operations(script.upgrade_ops)
    sort_operations(script.downgrade_ops)

    # 2. Deterministic Revision ID
    def get_hashable_content(directive) -> str:
        content = []
        if hasattr(directive, "ops"):
            for op in directive.ops:
                if isinstance(op, ops.CreateTableOp):
                    cols = ",".join(getattr(c, "name", None) or type(c).__name__ for c in op.columns)
                    content.append(f"create:{op.table_name}:{cols}")
                elif isinstance(op, ops.DropTableOp):
                    content.append(f"drop:{op.table_name}")
                elif isinstance(op, ops.AddColumnOp):
                    content.append(f"add_col:{op.table_name}:{op.column.name}")
                elif isinstance(op, ops.DropColumnOp):
                    content.append(f"drop_col:{op.table_name}:{op.column_name}")
                elif hasattr(op, "ops"):
                    content.append(get_hashable_content(op))
                else:
                    content.append(str(type(op).__name__))
        return "|".join(content)

    content_str = get_hashable_content(script.upgrade_ops)
    if content_str:
        down_rev = revision[0] if revision else "base"
        hash_input = f"{down_rev}:{content_str}"
        deterministic_id = hashlib.sha1(hash_input.encode("utf-8")).hexdigest()[:12]
        script.rev_id = deterministic_id


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL and not an Engine,
    though an Engine is acceptable here as well. By skipping the Engine
    creation we don't even need a DBAPI to be available.
    """
    url = get_url()
    is_sqlite = "sqlite" in url
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        render_as_batch=is_sqlite,
        process_revision_directives=process_revision_directives,
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    """Run migrations with the given connection."""
    # When using multiple version locations, there might be multiple heads.
    # Alembic handles this, but it's good to be explicit if needed.
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        render_as_batch=connection.dialect.name == "sqlite",
        process_revision_directives=process_revision_directives,
        # ensure multiple heads are merged or handled
    )

    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """Run migrations in 'online' mode with async engine."""
    configuration = config.get_section(config.config_ini_section, {})
    configuration["sqlalchemy.url"] = get_url()

    connectable = async_engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
'''

ALEMBIC_SCRIPT_PY_MAKO_CONTENT = '''"""${message}

Revision ID: ${up_revision}
Revises: ${down_revision | comma,n}
Create Date: ${create_date}
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
${imports if imports else ""}

# revision identifiers, used by Alembic.
revision: str = ${repr(up_revision)}
down_revision: Union[str, None] = ${repr(down_revision)}
branch_labels: Union[str, Sequence[str], None] = ${repr(branch_labels)}
depends_on: Union[str, Sequence[str], None] = ${repr(depends_on)}


def upgrade() -> None:
    """Upgrade database schema."""
    ${upgrades if upgrades else "pass"}


def downgrade() -> None:
    """Downgrade database schema."""
    ${downgrades if downgrades else "pass"}
'''
