"""Child Table Manager - Handles operations for nested document lists."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any, get_args, get_origin
from uuid import UUID

from framework_m_core.domain.base_doctype import BaseDocType
from sqlalchemy import Table, delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from framework_m_standard.adapters.db.json_compat import to_json_compatible
from framework_m_standard.adapters.db.table_registry import (
    TableNotFoundError,
    TableRegistry,
)

logger = logging.getLogger(__name__)


class ChildTableManager[T: BaseDocType]:
    """Manager for handling child table (list[DocType]) persistence.

    Provides operations to save, load, and delete child tables safely.
    """

    def __init__(self, parent_model: type[T]) -> None:
        """Initialize the child table manager.

        Args:
            parent_model: The parent DocType model class
        """
        self._parent_model = parent_model

    def get_child_table_fields(self) -> dict[str, type[BaseDocType]]:
        """Detect list[ChildDocType] fields in the parent model.

        Returns:
            Dict mapping field name to child DocType class.
            Only includes fields where the child has Meta.is_child = True.
        """
        child_fields: dict[str, type[BaseDocType]] = {}

        for field_name, field_info in self._parent_model.model_fields.items():
            annotation = field_info.annotation
            if annotation is None:
                continue

            # Check if field is list[SomeType]
            origin = get_origin(annotation)
            if origin is list:
                args = get_args(annotation)
                if args:
                    child_type = args[0]
                    # Check if child_type is a BaseDocType subclass with is_child flag
                    if isinstance(child_type, type) and issubclass(
                        child_type, BaseDocType
                    ):
                        meta = getattr(child_type, "Meta", None)
                        if meta and getattr(meta, "is_child", False):
                            child_fields[field_name] = child_type

        return child_fields

    async def save_child_tables(
        self,
        session: AsyncSession,
        parent: T,
        child_fields: dict[str, type[BaseDocType]],
    ) -> None:
        """Save child records for a parent document.

        Args:
            session: SQLAlchemy async session
            parent: Parent document
            child_fields: Dict of field_name -> child DocType class
        """
        table_registry = TableRegistry()

        for field_name, child_model in child_fields.items():
            # Get children from parent
            children: list[BaseDocType] = getattr(parent, field_name, [])
            if not children:
                continue

            # Get child table
            try:
                child_table = table_registry.get_table(child_model.__name__)
                if child_table is None:
                    logger.warning("Child table not found for %s", child_model.__name__)
                    continue
            except TableNotFoundError:
                logger.warning("Child table not found for %s", child_model.__name__)
                continue

            # Insert each child with parent reference
            for idx, child in enumerate(children, start=1):
                # Exclude computed fields from child data
                computed_fields = getattr(child_model, "model_computed_fields", {})
                exclude_fields = set(computed_fields.keys())
                child_data = child.model_dump(exclude=exclude_fields)

                # Pack json fields
                json_fields = set()
                for field_name, field_info in child_model.model_fields.items():
                    extra = field_info.json_schema_extra
                    if isinstance(extra, dict) and extra.get("persistence") == "json":
                        json_fields.add(field_name)

                custom_fields = {}
                for field in json_fields:
                    if field in child_data:
                        custom_fields[field] = to_json_compatible(child_data.pop(field))

                # Add parent reference columns
                child_data["parent"] = str(parent.id)
                child_data["parenttype"] = self._parent_model.__name__
                child_data["idx"] = idx
                child_data["modified"] = datetime.now(UTC)
                child_data["custom_fields"] = custom_fields

                # Insert child
                stmt = child_table.insert().values(**child_data)
                await session.execute(stmt)

    async def delete_child_tables(
        self,
        session: AsyncSession,
        parent_id: UUID,
        child_fields: dict[str, type[BaseDocType]],
    ) -> None:
        """Delete all child records for a parent document.

        Args:
            session: SQLAlchemy async session
            parent_id: Parent document ID
            child_fields: Dict of field_name -> child DocType class
        """
        table_registry = TableRegistry()
        parent_id_str = str(parent_id)

        for _field_name, child_model in child_fields.items():
            # Get child table
            try:
                child_table = table_registry.get_table(child_model.__name__)
                if child_table is None:
                    continue
            except TableNotFoundError:
                continue

            # Delete all children for this parent
            delete_stmt = delete(child_table).where(
                child_table.c.parent == parent_id_str
            )
            await session.execute(delete_stmt)

    async def load_child_tables(
        self,
        session: AsyncSession,
        parent: T,
        child_fields: dict[str, type[BaseDocType]],
    ) -> None:
        """Load child records for a parent document.

        Args:
            session: SQLAlchemy async session
            parent: Parent document to populate with children
            child_fields: Dict of field_name -> child DocType class
        """
        table_registry = TableRegistry()

        for field_name, child_model in child_fields.items():
            try:
                child_table = table_registry.get_table(child_model.__name__)
                if child_table is None:
                    continue
            except TableNotFoundError:
                continue

            # Load children for this parent
            children_by_parent = await self.load_children_for_parents(
                session,
                [parent.id],
                child_table,
                child_model,
            )

            # Populate the field
            parent_id_str = str(parent.id)
            children = children_by_parent.get(parent_id_str, [])
            setattr(parent, field_name, children)

    async def load_children_for_parents[C: BaseDocType](
        self,
        session: AsyncSession,
        parent_ids: list[Any],
        child_table: Table,
        child_model: type[C],
    ) -> dict[str, list[C]]:
        """Load child table rows for multiple parents using select_in_loading."""
        if not parent_ids:
            return {}

        parent_id_strs = [str(pid) for pid in parent_ids]

        stmt = (
            select(child_table)
            .where(child_table.c.parent.in_(parent_id_strs))
            .order_by(child_table.c.parent, child_table.c.idx)
        )

        result = await session.execute(stmt)
        rows = result.fetchall()

        children_by_parent: dict[str, list[C]] = {}
        for row in rows:
            row_dict = dict(row._mapping)
            parent_id = row_dict.pop("parent", None)

            # Remove parent reference columns
            row_dict.pop("parentfield", None)
            row_dict.pop("parenttype", None)
            row_dict.pop("idx", None)

            # Unpack custom_fields
            custom_fields = row_dict.pop("custom_fields", {})
            if isinstance(custom_fields, dict):
                row_dict.update(custom_fields)

            # Filter out any extra db columns
            model_fields = set(child_model.model_fields.keys())
            filtered_data = {k: v for k, v in row_dict.items() if k in model_fields}

            if parent_id is not None:
                parent_id = str(parent_id)
                if parent_id not in children_by_parent:
                    children_by_parent[parent_id] = []

                # Create child model instance
                child_instance = child_model.model_validate(filtered_data)
                children_by_parent[parent_id].append(child_instance)

        return children_by_parent
