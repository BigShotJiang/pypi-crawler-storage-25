"""PostgreSQL implementation of the Metering Protocol."""

from datetime import datetime

from framework_m_core.interfaces.metering import MeteringProtocol, UsageEvent
from framework_m_core.interfaces.repository import (
    FilterOperator,
    FilterSpec,
)
from sqlalchemy.ext.asyncio import AsyncSession

from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.metering.metered_usage import MeteredUsage


class PostgresMeteringAdapter(MeteringProtocol):
    """PostgreSQL adapter for XaaS usage metering.

    Wraps a GenericRepository to record and aggregate UsageEvents
    against the MeteredUsage DocType.
    """

    def __init__(
        self, repository: GenericRepository[MeteredUsage], session: AsyncSession
    ) -> None:
        """Initialize the adapter with a repository and DB session.

        Args:
            repository: The GenericRepository for MeteredUsage
            session: The SQLAlchemy AsyncSession to use
        """
        self.repository = repository
        self.session = session

    async def record_usage(self, event: UsageEvent) -> None:
        """Record a single usage event for a tenant.

        Args:
            event: The usage event details to record
        """
        usage_doc = MeteredUsage(
            tenant_id=event.tenant_id,
            feature_name=event.feature_name,
            quantity=event.quantity,
            timestamp=event.timestamp,
            metadata_dict=event.metadata,
        )
        await self.repository.save(self.session, usage_doc)

    async def get_usage(
        self,
        tenant_id: str,
        feature_name: str,
        start_time: datetime,
        end_time: datetime,
    ) -> float:
        """Get aggregated usage for a specific feature and tenant within a time window."""
        filters = [
            FilterSpec(field="tenant_id", operator=FilterOperator.EQ, value=tenant_id),
            FilterSpec(
                field="feature_name", operator=FilterOperator.EQ, value=feature_name
            ),
            FilterSpec(
                field="timestamp",
                operator=FilterOperator.GTE,
                value=start_time,
            ),
            FilterSpec(
                field="timestamp",
                operator=FilterOperator.LTE,
                value=end_time,
            ),
        ]

        result = await self.repository.list_entities(self.session, filters=filters)

        if not result.items:
            return 0.0

        return sum(item.quantity for item in result.items)
