"""Lago implementation of the Metering Protocol."""

import asyncio
import logging
import time
from datetime import datetime

import httpx
from framework_m_core.interfaces.metering import MeteringProtocol, UsageEvent

logger = logging.getLogger(__name__)


class CircuitBreakerOpenError(Exception):
    """Raised when the circuit breaker is open."""

    pass


class LagoMeteringAdapter(MeteringProtocol):
    """Lago adapter for usage tracking.

    Leverages optional lago-python-client bindings or direct HTTP fallbacks.
    Enforces circuit-breaker logic and exponential backoff strategies.
    """

    def __init__(
        self,
        api_key: str,
        api_url: str = "https://api.getlago.com/api/v1",
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
    ) -> None:
        self.api_key = api_key
        base_url = api_url.rstrip("/")
        if not base_url.endswith("/api/v1"):
            base_url = f"{base_url}/api/v1"
        self.api_url = base_url

        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout

        # Circuit Breaker state
        self._failures = 0
        self._state = "CLOSED"  # CLOSED, OPEN, HALF-OPEN
        self._last_failure_time = 0.0

    def _update_state(self) -> None:
        if (
            self._state == "OPEN"
            and time.time() - self._last_failure_time > self._recovery_timeout
        ):
            self._state = "HALF-OPEN"
            logger.info("Lago Circuit Breaker transitioning to HALF-OPEN")

    async def record_usage(self, event: UsageEvent) -> None:
        self._update_state()
        if self._state == "OPEN":
            raise CircuitBreakerOpenError("Circuit breaker is open for Lago API")

        # Exponential Backoff Retry Loop
        max_retries = 3
        for attempt in range(max_retries):
            try:
                await self._send_event(event)
                self._on_success()
                return
            except Exception as e:
                logger.warning(f"Lago recording attempt {attempt + 1} failed: {e}")
                if attempt == max_retries - 1:
                    self._on_failure()
                    raise e
                await asyncio.sleep(2**attempt)

    def _on_success(self) -> None:
        self._failures = 0
        if self._state == "HALF-OPEN":
            logger.info("Lago Circuit Breaker returning to CLOSED")
        self._state = "CLOSED"

    def _on_failure(self) -> None:
        self._failures += 1
        self._last_failure_time = time.time()
        if self._failures >= self._failure_threshold:
            self._state = "OPEN"
            logger.error(f"Lago Circuit Breaker opened after {self._failures} failures")

    async def _send_event(self, event: UsageEvent) -> None:
        payload = {
            "event": {
                "transaction_id": f"{event.tenant_id}-{event.feature_name}-{event.timestamp.timestamp()}",
                "external_customer_id": event.tenant_id,
                "code": event.feature_name,
                "timestamp": int(event.timestamp.timestamp()),
                "properties": {"quantity": event.quantity},
            }
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{self.api_url}/events", json=payload, headers=headers
            )
            response.raise_for_status()

    async def get_usage(
        self,
        tenant_id: str,
        feature_name: str,
        start_time: datetime,
        end_time: datetime,
    ) -> float:
        # Standard method required by Protocol
        # Lago API aggregates usage automatically - retrieving requires customer usage metrics
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            # GET /api/v1/customers/{external_customer_id}/usage
            response = await client.get(
                f"{self.api_url}/customers/{tenant_id}/usage", headers=headers
            )
            if response.status_code == 404:
                return 0.0
            response.raise_for_status()
            data = response.json()

            # Parse feature usage
            # Payload structure: { "usage": { "charges_usage": [...] } }
            charges = data.get("usage", {}).get("charges_usage", [])
            for charge in charges:
                if charge.get("billable_metric_code") == feature_name:
                    return float(charge.get("units", 0.0))

            return 0.0
