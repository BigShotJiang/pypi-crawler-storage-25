"""Usage Meter Service - Application service for tracking tenant metrics."""

from datetime import UTC, datetime
from typing import Any

from framework_m_core.interfaces.metering import MeteringProtocol, UsageEvent


class UsageMeterService:
    """Service for tracking and querying tenant usage.

    Acts as an application layer orchestrator over the raw MeteringProtocol.
    """

    def __init__(self, metering: MeteringProtocol) -> None:
        """Initialize with a metering adapter.

        Args:
            metering: The underlying MeteringProtocol implementation.
        """
        self.metering = metering

    async def track_usage(
        self,
        tenant_id: str,
        feature_name: str,
        quantity: float = 1.0,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Track a usage event for a tenant.

        Args:
            tenant_id: Unique tenant identifier
            feature_name: Name of the feature being consumed
            quantity: Amount consumed (defaults to 1.0)
            metadata: Optional dimensions or context
        """
        event = UsageEvent(
            tenant_id=tenant_id,
            feature_name=feature_name,
            quantity=quantity,
            timestamp=datetime.now(UTC),
            metadata=metadata,
        )
        await self.metering.record_usage(event)

    async def get_current_usage(
        self,
        tenant_id: str,
        feature_name: str,
        start_time: datetime,
        end_time: datetime,
    ) -> float:
        """Get total usage for a tenant within a time window.

        Args:
            tenant_id: Unique tenant identifier
            feature_name: Name of the feature
            start_time: Start of the billing/quota period
            end_time: End of the billing/quota period

        Returns:
            Total quantity consumed
        """
        return await self.metering.get_usage(
            tenant_id, feature_name, start_time, end_time
        )
