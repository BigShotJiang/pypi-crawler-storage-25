"""Metered Usage DocType definition."""

from datetime import datetime
from typing import Any

from framework_m_core.domain.base_doctype import BaseDocType, Field


class MeteredUsage(BaseDocType):
    """DocType representing a persisted usage event.

    Used by the metering adapter to track tenant usage.
    """

    tenant_id: str = Field(description="Unique tenant identifier")
    feature_name: str = Field(description="Name of the metered feature")
    quantity: float = Field(description="Amount of usage consumed")
    timestamp: datetime = Field(description="When the usage occurred")
    metadata_dict: dict[str, Any] | None = Field(
        default=None, description="Optional context or dimensions"
    )

    class Meta:
        api_resource = False
        apply_rls = True
