"""Database-backed Idempotency Adapter.

Architectural Note:
This adapter uses SQLAlchemy Core and fetches the dynamic Table object directly
from the `TableRegistry`. This skips ORM overhead (Identity Map, state tracking)
and ensures optimal performance for this high-traffic middleware component.
"""

import asyncio
from collections.abc import Callable
from datetime import UTC, datetime
from uuid import uuid4

from framework_m_core.interfaces.idempotency import (
    IdempotencyProtocol,
    SerializedResponse,
)
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from framework_m_standard.adapters.db.table_registry import TableRegistry


class DatabaseIdempotencyAdapter(IdempotencyProtocol):
    """Database adapter for idempotency keys using SQLAlchemy Core."""

    def __init__(
        self,
        session_factory: Callable[[], AsyncSession],
        table_registry: TableRegistry | None = None,
    ) -> None:
        """Initialize with a SQLAlchemy AsyncSession factory.

        Args:
            session_factory: Callable that yields a new database session.
            table_registry: Optional registry for resolving the underlying table.
        """
        self.session_factory = session_factory
        self.table_registry = table_registry or TableRegistry()

    async def get_response(self, key: str) -> SerializedResponse | None:
        """Retrieve a previously cached response.

        Args:
            key: The unique idempotency key.

        Returns:
            The cached SerializedResponse if found, else None.
        """
        table = self.table_registry.get_table("IdempotencyKey")
        async with self.session_factory() as session:
            stmt = select(table).where(table.c.key == key)
            result = await session.execute(stmt)
            row = result.mappings().one_or_none()

            if row:
                return SerializedResponse(
                    status_code=row["status_code"],
                    headers=row["headers"],
                    body=row["body"],
                )
            return None

    async def save_response(self, key: str, response: SerializedResponse) -> None:
        """Save a completed response to the database.

        Args:
            key: The unique idempotency key.
            response: The response data to cache.
        """
        table = self.table_registry.get_table("IdempotencyKey")
        async with self.session_factory() as session:
            stmt = table.insert().values(
                id=uuid4(),
                key=key,
                status_code=response.status_code,
                headers=response.headers,
                body=response.body,
                creation=datetime.now(UTC),
                modified=datetime.now(UTC),
            )
            await session.execute(stmt)
            await session.commit()

    async def acquire_lock(self, key: str, timeout: float = 5.0) -> bool:
        """Attempt to acquire a database-level lock."""
        try:
            async with asyncio.timeout(timeout):
                async with self.session_factory() as session:
                    await session.execute(text("SELECT 1"))
                    return True
        except TimeoutError:
            return False

    async def release_lock(self, key: str) -> None:
        """Release a previously acquired lock."""
        pass
