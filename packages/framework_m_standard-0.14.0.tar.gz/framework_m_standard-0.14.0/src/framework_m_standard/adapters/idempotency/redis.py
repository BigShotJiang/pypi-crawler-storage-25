"""Redis-backed Idempotency Adapter."""

import base64
import json
from typing import Any

from framework_m_core.interfaces.idempotency import (
    IdempotencyProtocol,
    SerializedResponse,
)


class RedisIdempotencyAdapter(IdempotencyProtocol):
    """Redis adapter for idempotency keys and distributed locking."""

    def __init__(self, redis_client: Any) -> None:
        """Initialize with an async Redis client.

        Args:
            redis_client: An async Redis client instance (e.g., redis.asyncio.Redis).
        """
        self.redis_client = redis_client

    async def get_response(self, key: str) -> SerializedResponse | None:
        """Retrieve a previously cached response from Redis."""
        raw_data = await self.redis_client.get(f"idem:resp:{key}")
        if not raw_data:
            return None

        data = json.loads(raw_data)
        body_bytes = base64.b64decode(data["body"])

        return SerializedResponse(
            status_code=data["status_code"],
            headers=data["headers"],
            body=body_bytes,
        )

    async def save_response(self, key: str, response: SerializedResponse) -> None:
        """Save a completed response to Redis with Base64 body encoding."""
        body_b64 = base64.b64encode(response.body).decode("utf-8")
        data = {
            "status_code": response.status_code,
            "headers": response.headers,
            "body": body_b64,
        }
        await self.redis_client.set(f"idem:resp:{key}", json.dumps(data))

    async def acquire_lock(self, key: str, timeout: float = 5.0) -> bool:
        """Attempt to acquire a distributed lock using Redis SET NX."""
        acquired = await self.redis_client.set(
            f"idem:lock:{key}", "locked", nx=True, ex=int(timeout)
        )
        # Redis py returns True if set, None if NX prevented it
        return bool(acquired)

    async def release_lock(self, key: str) -> None:
        """Release a previously acquired Redis lock."""
        await self.redis_client.delete(f"idem:lock:{key}")
