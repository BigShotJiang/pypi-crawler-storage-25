"""Idempotency Adapters.

This package contains the infrastructure implementations (adapters) for the
IdempotencyProtocol, supporting various backends like Database (SQLite/Postgres)
and Redis.
"""

from framework_m_standard.adapters.idempotency.database import (
    DatabaseIdempotencyAdapter,
)
from framework_m_standard.adapters.idempotency.redis import (
    RedisIdempotencyAdapter,
)

__all__ = [
    "DatabaseIdempotencyAdapter",
    "RedisIdempotencyAdapter",
]
