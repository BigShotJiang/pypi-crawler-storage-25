"""Discovery Adapter Package."""

from framework_m_standard.adapters.discovery.env import (
    discover_local_packages,
    get_project_root,
    is_containerized,
    mask_url_credentials,
    resolve_app_modules,
    safe_import_module,
)

__all__ = [
    "get_project_root",
    "is_containerized",
    "resolve_app_modules",
    "mask_url_credentials",
    "discover_local_packages",
    "safe_import_module",
]
