"""Project discovery utilities for local development.

Provides tools to locate project roots and determine the execution environment.
"""

from __future__ import annotations

import importlib
import importlib.metadata
import logging
import os
import pkgutil
import re
from pathlib import Path
from types import ModuleType

logger = logging.getLogger(__name__)


def get_project_root(start_path: Path | None = None) -> Path:
    """Find the root directory of the project.

    Recursively searches upwards for standard project markers:
    - .git or pyproject.toml (Local Dev)
    - framework_config.toml or alembic.ini (Production/Container)

    Falls back to current working directory if no markers are found.
    """
    current = start_path or Path.cwd()

    markers = {".git", "pyproject.toml", "framework_config.toml", "alembic.ini"}

    for parent in [current, *current.parents]:
        if any((parent / marker).exists() for marker in markers):
            return parent

    return Path.cwd()


def is_containerized() -> bool:
    """Check if running inside a container (Docker/Podman/LXC/K8s)."""
    # .dockerenv for Docker, .containerenv for native Podman
    if Path("/.dockerenv").exists() or Path("/run/.containerenv").exists():
        return True

    cgroup_path = Path("/proc/1/cgroup")
    if cgroup_path.exists():
        try:
            content = cgroup_path.read_text()
            if any(m in content for m in ("docker", "lxc", "kubepods", "libpod")):
                return True
        except Exception:
            pass

    return False


def discover_local_packages(root_path: Path) -> list[str]:
    """Discover top-level Python packages in the given root path.

    Checks the standard `src/` layout first, falling back to the root path.
    Used primarily in local development to auto-discover un-installed packages.
    """
    packages = []

    # Prefer standard src/ layout if it exists
    src_path = root_path / "src"
    search_paths = (
        [str(src_path)] if src_path.exists() and src_path.is_dir() else [str(root_path)]
    )

    # Use pkgutil to find valid Python packages without walking arbitrary non-Python files
    for _finder, name, is_pkg in pkgutil.iter_modules(search_paths):
        if is_pkg and not name.startswith(".") and not name.startswith("tests"):
            packages.append(name)

    return packages


def safe_import_module(module_name: str) -> ModuleType | None:
    """Safely import a module, suppressing and logging exceptions.

    Essential for development mode where half-written files with SyntaxErrors
    or NameErrors might exist. Prevents discovery loops from crashing entirely.
    """
    try:
        return importlib.import_module(module_name)
    except Exception as e:
        logger.warning(f"Failed to import module '{module_name}' during discovery: {e}")
        return None
    except BaseException as e:
        # Catch SyntaxError, IndentationError, etc. which don't inherit from Exception
        logger.warning(f"Critical error importing module '{module_name}': {e}")
        return None


def resolve_app_modules(root_path: Path) -> list[str]:
    """Resolve and deduplicate apps from local source, env vars, and entry points.

    Prioritizes local source code over installed site-packages for dev overrides.
    """
    resolved: dict[str, None] = {}

    # 1. Local discovery (Highest priority for dev overrides)
    for app in discover_local_packages(root_path):
        resolved[app] = None

    # 2. Environment variable (Explicit selection)
    env_apps = os.environ.get("INSTALLED_APPS", "")
    if env_apps:
        for app in env_apps.split(","):
            app = app.strip()
            if app and app not in resolved:
                resolved[app] = None
    else:
        # 3. Entry points (Installed packages fallback)
        try:
            eps = importlib.metadata.entry_points()
            app_eps = (
                eps.get("framework_m.apps", [])
                if isinstance(eps, dict)
                else eps.select(group="framework_m.apps")
            )
            for ep in app_eps:
                if ep.name not in resolved:
                    resolved[ep.name] = None
        except Exception:
            pass

    return list(resolved.keys())


def mask_url_credentials(url: str) -> str:
    """Mask sensitive credentials (e.g., password) in a database URL."""
    return re.sub(r"(://[^:]+:)[^@]+(@)", r"\1********\2", url)
