"""Structlog processor for redacting sensitive data."""

from typing import Any

from framework_m_core.config import LoggingConfig
from framework_m_core.interfaces.redactor import RedactorProtocol


class SecretRedactionProcessor:
    """Structlog processor that delegates to a RedactorProtocol to scrub logs.

    This acts as the Adapter connecting the external logging library (structlog)
    to the internal domain scrubbing logic (RedactorProtocol).
    """

    def __init__(self, config: LoggingConfig, redactor: RedactorProtocol) -> None:
        """Initialize the processor with configuration and a scrubbing strategy.

        Args:
            config: The logging configuration containing policies (e.g., enabled state).
            redactor: The domain logic port responsible for actual data scrubbing.
        """
        self._config = config
        self._redactor = redactor

    def __call__(
        self, logger: Any, method_name: str, event_dict: dict[str, Any]
    ) -> dict[str, Any]:
        """Process the log event dictionary.

        Args:
            logger: The structlog logger instance.
            method_name: The name of the logger method being called.
            event_dict: The current state of the log event dictionary.

        Returns:
            The scrubbed event dictionary (or unmodified if disabled).
        """
        if not self._config.enabled:
            return event_dict

        return self._redactor.scrub(event_dict)
