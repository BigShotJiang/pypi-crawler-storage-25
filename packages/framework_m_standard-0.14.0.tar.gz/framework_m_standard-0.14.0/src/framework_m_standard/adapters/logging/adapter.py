"""Logging Adapter implementation using structlog."""

from typing import Any

import structlog
from framework_m_core.interfaces.logging import LoggingProtocol


class StructlogAdapter(LoggingProtocol):
    """Implementation of LoggingProtocol using the structlog library.

    This adapter bridges the core Logging Port to the structlog implementation.
    """

    def __init__(self, logger: Any | None = None) -> None:
        """Initialize with a structlog logger or create a new one."""
        self._logger = logger or structlog.get_logger()

    def info(self, event: str, **kwargs: Any) -> None:
        """Log an info level event."""
        self._logger.info(event, **kwargs)

    def error(self, event: str, **kwargs: Any) -> None:
        """Log an error level event."""
        self._logger.error(event, **kwargs)
