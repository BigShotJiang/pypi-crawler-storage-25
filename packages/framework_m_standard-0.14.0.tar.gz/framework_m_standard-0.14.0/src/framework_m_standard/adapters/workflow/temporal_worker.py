"""Temporal Worker Adapter.

Generic worker implementation for executing Temporal workflows and activities
registered via Framework M's ActivityRegistry.
"""

import asyncio
import contextlib
import os
from pathlib import Path
from typing import Any

import structlog
from framework_m_core.interfaces.worker import ActivityRegistry
from framework_m_core.services.secrets_service import SecretsManager

logger = structlog.get_logger(__name__)


class TemporalWorkerAdapter:
    """Generic Temporal worker for Framework M workflows.

    Connects to the Temporal server, pulls registered activities from the
    core ActivityRegistry, and listens on the specified task queue.
    """

    def __init__(
        self,
        host: str | None = None,
        namespace: str | None = None,
        task_queue: str | None = None,
        workflows: list[Any] | None = None,
    ) -> None:
        """Initialize the Temporal worker adapter.

        Args:
            host: Temporal server host (falls back to TEMPORAL_URL env var)
            namespace: Temporal namespace
            task_queue: Temporal task queue
            workflows: List of workflow classes to register
        """
        from framework_m_core.services.secrets_service import SecretsManager

        self._host = host or os.environ.get("TEMPORAL_URL", "localhost:7233")
        self._namespace = namespace or os.environ.get("TEMPORAL_NAMESPACE", "default")
        self._task_queue = task_queue or os.environ.get(
            "TEMPORAL_TASK_QUEUE", "framework-m-workflows"
        )
        self._workflows = workflows or []

        self._secrets: SecretsManager | None = None
        self._api_key = os.environ.get("TEMPORAL_API_KEY")
        self._client_cert = os.environ.get("TEMPORAL_CLIENT_CERT")
        self._client_key = os.environ.get("TEMPORAL_CLIENT_KEY")

        self._client: Any = None
        self._worker: Any = None
        self._worker_task: asyncio.Task[None] | None = None

    def set_secrets_manager(self, secrets: SecretsManager) -> None:
        """Set the secrets gateway for sensitive configuration."""
        self._secrets = secrets
        if secrets:
            self._api_key = secrets.get("TEMPORAL_API_KEY") or self._api_key
            self._client_cert = secrets.get("TEMPORAL_CLIENT_CERT") or self._client_cert
            self._client_key = secrets.get("TEMPORAL_CLIENT_KEY") or self._client_key

    async def start(self) -> None:
        """Start the Temporal worker to begin polling for tasks."""
        try:
            from temporalio.client import (  # type: ignore[import-not-found]
                Client,
                TLSConfig,
            )
            from temporalio.worker import Worker  # type: ignore[import-not-found]
        except ImportError as e:
            raise ImportError(
                "Temporal SDK not installed. Install with: pip install temporalio"
            ) from e

        tls_config: TLSConfig | bool = False
        if self._client_cert and self._client_key:
            cert_bytes = (
                self._client_cert.encode()
                if "-----BEGIN" in self._client_cert
                else Path(self._client_cert).read_bytes()
            )
            key_bytes = (
                self._client_key.encode()
                if "-----BEGIN" in self._client_key
                else Path(self._client_key).read_bytes()
            )
            tls_config = TLSConfig(
                client_cert=cert_bytes,
                client_private_key=key_bytes,
            )

        rpc_metadata = {}
        if self._api_key:
            rpc_metadata["Authorization"] = f"Bearer {self._api_key}"

        logger.info(
            "Connecting Temporal Worker",
            host=self._host,
            namespace=self._namespace,
        )
        self._client = await Client.connect(
            self._host,
            namespace=self._namespace,
            tls=tls_config,
            rpc_metadata=rpc_metadata,
        )

        # Dynamically load all activities registered via @worker_activity
        activities = list(ActivityRegistry.get_instance().get_all().values())
        logger.info(
            "Registering activities and workflows",
            activity_count=len(activities),
            workflow_count=len(self._workflows),
        )

        self._worker = Worker(
            self._client,
            task_queue=self._task_queue,
            workflows=self._workflows,
            activities=activities,
        )

        # Run the worker as a background asyncio task
        logger.info("Started polling on task queue", task_queue=self._task_queue)
        self._worker_task = asyncio.create_task(self._worker.run())

    async def stop(self) -> None:
        """Gracefully stop the worker."""
        logger.info("Stopping Temporal Worker...")
        if self._worker_task and not self._worker_task.done():
            self._worker_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._worker_task
