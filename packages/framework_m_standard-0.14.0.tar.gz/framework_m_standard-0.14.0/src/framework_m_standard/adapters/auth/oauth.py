"""OAuthAdapter - authlib-based OAuth2/OIDC adapter for Indie mode.

Provides a reusable adapter that implements the OAuth2Protocol contract
for provider authorization URL generation, code exchange, and user info
resolution.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass
from datetime import UTC, datetime

with warnings.catch_warnings(record=True):
    from authlib.integrations.httpx_client import (  # type: ignore[import-untyped]
        AsyncOAuth2Client,
    )
from framework_m_core.doctypes.social_account import SocialAccount
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.oauth import (
    OAuth2Protocol,
    OAuth2Token,
    OAuth2UserInfo,
)


@dataclass(frozen=True)
class OAuthCallbackResult:
    """Hydrated callback result for downstream account-linking workflows."""

    token: OAuth2Token
    user_info: OAuth2UserInfo
    social_account: SocialAccount
    user_context: UserContext


class OAuthAdapter(OAuth2Protocol):
    """Authlib-backed OAuth2/OIDC adapter for a configured provider."""

    def __init__(
        self,
        *,
        provider_name: str,
        client_id: str,
        client_secret: str,
        authorization_url: str,
        token_url: str,
        userinfo_url: str,
        scope: str,
        token_endpoint_auth_method: str = "client_secret_basic",
        emails_url: str | None = None,
    ) -> None:
        self._provider_name = provider_name
        self._client_id = client_id
        self._client_secret = client_secret
        self._authorization_url = authorization_url
        self._token_url = token_url
        self._userinfo_url = userinfo_url
        self._scope = scope
        self._token_endpoint_auth_method = token_endpoint_auth_method
        self._emails_url = emails_url

    @property
    def provider_name(self) -> str:
        return self._provider_name

    async def get_authorization_url(self, state: str, redirect_uri: str) -> str:
        """Generate provider authorization URL with state and redirect URI."""
        async with AsyncOAuth2Client(
            client_id=self._client_id,
            redirect_uri=redirect_uri,
            scope=self._scope,
        ) as client:
            authorization_url, _ = client.create_authorization_url(
                self._authorization_url,
                state=state,
            )
            return str(authorization_url)

    async def exchange_code(self, code: str, redirect_uri: str) -> OAuth2Token:
        """Exchange authorization code for OAuth2 token payload."""
        async with AsyncOAuth2Client(
            client_id=self._client_id,
            client_secret=self._client_secret,
            redirect_uri=redirect_uri,
            token_endpoint_auth_method=self._token_endpoint_auth_method,
        ) as client:
            token_payload = await client.fetch_token(
                url=self._token_url,
                code=code,
                grant_type="authorization_code",
            )

        return OAuth2Token(
            access_token=str(token_payload.get("access_token", "")),
            token_type=str(token_payload.get("token_type", "Bearer")),
            expires_in=(
                int(token_payload["expires_in"])
                if token_payload.get("expires_in") is not None
                else None
            ),
            refresh_token=(
                str(token_payload["refresh_token"])
                if token_payload.get("refresh_token") is not None
                else None
            ),
            scope=(
                str(token_payload["scope"])
                if token_payload.get("scope") is not None
                else None
            ),
        )

    async def get_user_info(self, token: OAuth2Token) -> OAuth2UserInfo:
        """Fetch and normalize user profile from provider endpoints."""
        access_token = token.access_token
        token_type = token.token_type or "Bearer"

        async with AsyncOAuth2Client(
            token={"access_token": access_token, "token_type": token_type}
        ) as client:
            profile_response = await client.get(self._userinfo_url)
            profile_response.raise_for_status()
            profile = profile_response.json()

            if (
                self.provider_name == "github"
                and self._emails_url
                and not profile.get("email")
            ):
                emails_response = await client.get(self._emails_url)
                emails_response.raise_for_status()
                emails = emails_response.json()
                if isinstance(emails, list):
                    primary_verified = next(
                        (
                            item
                            for item in emails
                            if isinstance(item, dict)
                            and item.get("primary")
                            and item.get("verified")
                        ),
                        None,
                    )
                    if isinstance(primary_verified, dict):
                        profile["email"] = primary_verified.get("email")

        provider_user_id = self._extract_provider_user_id(profile)
        display_name = (
            profile.get("name")
            or profile.get("login")
            or profile.get("preferred_username")
            or profile.get("email")
            or provider_user_id
        )

        avatar_url = profile.get("picture") or profile.get("avatar_url")

        return OAuth2UserInfo(
            provider=self.provider_name,
            provider_user_id=str(provider_user_id),
            email=str(profile["email"]) if profile.get("email") else None,
            display_name=str(display_name),
            avatar_url=str(avatar_url) if avatar_url else None,
        )

    async def handle_callback(
        self,
        *,
        code: str,
        redirect_uri: str,
        local_user_id: str,
    ) -> OAuthCallbackResult:
        """Handle callback and hydrate Framework M models for linking/session flows."""
        token = await self.exchange_code(code=code, redirect_uri=redirect_uri)
        user_info = await self.get_user_info(token)

        email = user_info.email or f"{user_info.provider_user_id}@placeholder.invalid"
        social_account = SocialAccount(
            provider=self.provider_name,
            provider_user_id=user_info.provider_user_id,
            user_id=local_user_id,
            display_name=user_info.display_name,
            email=user_info.email,
            last_login_at=datetime.now(UTC),
        )
        user_context = UserContext(
            id=local_user_id,
            email=email,
            name=user_info.display_name,
            roles=["User"],
        )

        return OAuthCallbackResult(
            token=token,
            user_info=user_info,
            social_account=social_account,
            user_context=user_context,
        )

    def _extract_provider_user_id(self, profile: dict[str, object]) -> str:
        if self.provider_name == "github":
            value = profile.get("id") or profile.get("node_id") or profile.get("sub")
            return str(value or "")

        value = profile.get("sub") or profile.get("id")
        return str(value or "")


__all__ = ["OAuthAdapter", "OAuthCallbackResult"]
