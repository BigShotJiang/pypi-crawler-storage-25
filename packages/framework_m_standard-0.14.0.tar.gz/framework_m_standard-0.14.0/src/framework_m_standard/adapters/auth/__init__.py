"""Auth Adapters - Authentication and Authorization implementations.

This package provides adapter implementations for:
- RbacPermissionAdapter: Role-Based Access Control using DocType.Meta.permissions
- LocalIdentityAdapter: Identity management for Indie mode (SQL-backed users)
- FederatedIdentityAdapter: Identity management for Enterprise mode (header hydration)
- Authentication strategies: JwtAuth, ApiKeyAuth, GatewayAuth, AuthChain
"""

from framework_m_standard.adapters.auth.federated_identity import (
    FederatedIdentityAdapter,
    hydrate_from_headers,
)
from framework_m_standard.adapters.auth.local_identity import (
    LocalIdentityAdapter,
    hash_password,
    verify_password,
)
from framework_m_standard.adapters.auth.oauth import OAuthAdapter, OAuthCallbackResult
from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth
from framework_m_standard.adapters.auth.quota_handler import QuotaPolicyHandler
from framework_m_standard.adapters.auth.rbac_permission import RbacPermissionAdapter
from framework_m_standard.adapters.auth.strategies import (
    ApiKeyAuth,
    AuthChain,
    GatewayAuth,
    JwtAuth,
    create_auth_chain_from_config,
)

__all__ = [
    "ApiKeyAuth",
    "AuthChain",
    "FederatedIdentityAdapter",
    "GatewayAuth",
    "JwtAuth",
    "LocalIdentityAdapter",
    "OAuthAdapter",
    "OidcFederatedAuth",
    "OAuthCallbackResult",
    "QuotaPolicyHandler",
    "RbacPermissionAdapter",
    "create_auth_chain_from_config",
    "hash_password",
    "hydrate_from_headers",
    "verify_password",
]
