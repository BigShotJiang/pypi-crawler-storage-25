"""Quota Policy Handler - Enforces usage limits on authorization requests."""

from datetime import UTC, datetime
from typing import Any

from framework_m_core.interfaces.permission import (
    DecisionSource,
    PermissionAction,
    PermissionProtocol,
    PolicyEvaluateRequest,
    PolicyEvaluateResult,
)


class QuotaPolicyHandler(PermissionProtocol):
    """Decorator for PermissionProtocol that enforces quotas on CREATE actions.

    Args:
        base_adapter: The underlying permission adapter (e.g., RBAC)
        metering_service: Service to check current usage
        quotas: Dictionary mapping DocType to quota rules.
                Format: {"DocType": {"feature": "feature_name", "limit": float}}
    """

    def __init__(
        self,
        base_adapter: PermissionProtocol,
        metering_service: Any,
        quotas: dict[str, dict[str, Any]],
    ) -> None:
        self.base_adapter = base_adapter
        self.metering_service = metering_service
        self.quotas = quotas

    async def evaluate(self, request: PolicyEvaluateRequest) -> PolicyEvaluateResult:
        """Evaluate permissions and enforce quotas if applicable."""
        # 1. Check base permissions first
        result = await self.base_adapter.evaluate(request)

        if not result.authorized:
            return result

        # 2. Only enforce quotas on CREATE actions
        if request.action != PermissionAction.CREATE:
            return result

        # 3. Check if there is a quota defined for this resource
        quota_rule = self.quotas.get(request.resource)
        if not quota_rule:
            return result

        # 4. Check current usage
        tenants_to_check = (
            request.tenant_lineage
            if request.tenant_lineage
            else [request.tenant_id or "default"]
        )
        feature_name = quota_rule["feature"]
        limit = float(quota_rule["limit"])

        # Check usage for the current billing period (e.g., start of month)
        now = datetime.now(UTC)
        start_time = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        for t_id in tenants_to_check:
            current_usage = await self.metering_service.get_current_usage(
                tenant_id=t_id,
                feature_name=feature_name,
                start_time=start_time,
                end_time=now,
            )

            if current_usage >= limit:
                return PolicyEvaluateResult(
                    authorized=False,
                    decision_source=DecisionSource.CUSTOM,
                    reason=f"Quota exceeded for {feature_name} at tenant '{t_id}'. Limit: {limit}, Current: {current_usage}",
                )

        return result

    async def get_permitted_filters(
        self,
        principal: str,
        principal_attributes: dict[str, Any],
        resource: str,
        tenant_id: str | None = None,
    ) -> dict[str, Any]:
        """Pass through to the base adapter for Row-Level Security filters."""
        return await self.base_adapter.get_permitted_filters(
            principal, principal_attributes, resource, tenant_id
        )
