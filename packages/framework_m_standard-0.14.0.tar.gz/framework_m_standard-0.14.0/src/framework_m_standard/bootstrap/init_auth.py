"""InitAuth - Initialize Authentication Chain in DI container.

This bootstrap step configures the authentication strategies (Bearer, Header, Citadel)
based on environment variables and framework configuration.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any, cast

from framework_m_core.interfaces.bootstrap import BootstrapProtocol

from framework_m_standard.adapters.auth.citadel_auth import CitadelAuth, S2sClient
from framework_m_standard.adapters.auth.strategies import (
    AuthChain,
    GatewayAuth,
    JwtAuth,
)

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class InitAuth(BootstrapProtocol):
    """
    Initialize Authentication Chain in DI container.

    Order: 35 (runs after DB init but before final adapter binding)
    """

    name = "init_auth"
    order = 35

    async def run(self, container: Any) -> None:
        """
        Configure AuthChain from environment and config.

        Args:
            container: DI container to configure
        """
        logger.info("[InitAuth] Initializing authentication chain...")

        auth_provider = os.getenv("AUTH_PROVIDER", "default")
        auth_strategies: list[Any] = []

        # Resolve secrets from container
        secrets = container.secrets_manager()

        if auth_provider == "citadel":
            # Citadel-specific config
            token_endpoint = os.getenv("CITADEL_S2S_TOKEN_ENDPOINT", "")
            client_id = os.getenv("CITADEL_S2S_CLIENT_ID", "")
            client_secret = secrets.get("CITADEL_S2S_CLIENT_SECRET", "")
            iam_url = os.getenv("CITADEL_IAM_SERVICE_URL", "http://localhost:8080")
            strategy = cast(Any, os.getenv("CITADEL_IAM_STRATEGY", "ZERO_TRUST"))

            s2s_client = None
            if strategy == "ZERO_TRUST" and all(
                [token_endpoint, client_id, client_secret]
            ):
                s2s_client = S2sClient(
                    token_endpoint=token_endpoint,
                    client_id=client_id,
                    client_secret=client_secret,
                )

            auth_strategies.append(
                CitadelAuth(strategy=strategy, iam_url=iam_url, s2s_client=s2s_client)
            )

        # Standards: JWT and Headers
        jwt_secret = secrets.get("JWT_SECRET", "super-secret-key")
        auth_strategies.append(JwtAuth(jwt_secret=jwt_secret))
        auth_strategies.append(GatewayAuth())

        auth_chain = AuthChain(strategies=auth_strategies)

        # Bind the AuthChain if the container supports it
        # This allows middleware to access it via container.auth_chain
        if hasattr(container, "auth_chain"):
            # We use attribute setting for flexibility across different container impls
            container.auth_chain = auth_chain
            logger.info(
                f"[InitAuth]   ✓ AuthChain initialized (provider: {auth_provider})"
            )
        else:
            # Fallback if no attribute but potentially used via specialized providers
            # In full framework-m-standard, we'd use container.auth_chain.override(auth_chain)
            pass


# Helper for type casting if needed
