"""InitSocket - Initialize distributed WebSocket backplane.

This bootstrap step configures the SocketProtocol implementation and
establishes the bridge between the distributed backplane (NATS) and
local WebSocket connections.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from framework_m_core.interfaces.bootstrap import BootstrapProtocol

from framework_m_standard.adapters.socket.nats_socket import NatsSocketAdapter
from framework_m_standard.adapters.web.socket import get_connection_manager

logger = logging.getLogger(__name__)


class InitSocket:
    """
    Initialize distributed WebSocket backplane.

    This step:
    1. Selects the appropriate SocketProtocol implementation.
    2. Connects to the backplane (if using NATS).
    3. Establishes a bridge that routes distributed messages to local connections.

    Order: 45 (runs after InitAdapters)
    """

    name = "init_socket"
    order = 45

    async def run(self, container: Any) -> None:
        """
        Initialize the NATS socket bridge.

        Args:
            container: DI container to configure
        """
        from framework_m_core.services.secrets_service import SecretsManager

        secrets: SecretsManager = container.secrets_manager()
        nats_url = secrets.get("NATS_URL")

        if not nats_url or not isinstance(nats_url, str):
            logger.warning(
                "[InitSocket]   ⚠ No NATS_URL found, skipping socket initialization"
            )
            return

        logger.info(
            "[InitSocket] Initializing NATS WebSocket backplane at %s", nats_url
        )

        # Initialize and connect the adapter
        adapter = NatsSocketAdapter(nats_url=nats_url)
        await adapter.connect()

        # Get the local connection manager
        manager = get_connection_manager()

        # Define the bridge callback
        async def socket_bridge_callback(msg: Any) -> None:
            """Bridge NATS messages to local WebSocket connections."""
            try:
                subject = msg.subject
                data = json.loads(msg.data.decode())

                # ws.user.<user_id>
                if subject.startswith("ws.user."):
                    user_id = subject.split(".")[-1]
                    await manager.send_to_user(user_id, data)

                # ws.<topic> (broadcast)
                elif subject.startswith("ws."):
                    await manager.broadcast(data)

            except Exception as e:
                logger.error(
                    "[InitSocket] Bridge error for subject %s: %s", msg.subject, e
                )

        # Subscribe to all websocket subjects
        await adapter.subscribe("ws.>", socket_bridge_callback)

        # Store adapter in container if the provider exists
        if hasattr(container, "socket_adapter"):
            container.socket_adapter.override(adapter)

        logger.info(
            "[InitSocket] Distributed WebSocket backplane initialized and bridged"
        )


# Verify protocol compliance
assert isinstance(InitSocket(), BootstrapProtocol)
