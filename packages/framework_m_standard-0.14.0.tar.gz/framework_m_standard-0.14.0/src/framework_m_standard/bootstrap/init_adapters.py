"""InitAdapters - Bind SQLAlchemy adapters to DI container.

This bootstrap step binds the SQLAlchemy adapter implementations
(GenericRepository, UnitOfWork, etc.) to their protocol interfaces
in the DI container. It runs last (order=40) after everything is ready.
"""

import logging
from typing import Any

from framework_m_core.interfaces.bootstrap import BootstrapProtocol

logger = logging.getLogger(__name__)


def load_env() -> None:
    """Load environment variables from .env files.

    Searches for .env file from current directory up to root and loads
    it using python-dotenv.
    """
    from pathlib import Path

    from dotenv import load_dotenv

    # Search for .env file from current directory up to root
    _cwd = Path.cwd()
    for _parent in [_cwd, *_cwd.parents]:
        _env_file = _parent / ".env"
        if _env_file.exists():
            load_dotenv(_env_file)
            break


class InitAdapters:
    """
    Bind SQLAlchemy adapters to protocol interfaces in DI container.

    This step configures dependency injection by binding concrete
    SQLAlchemy adapter implementations to their protocol interfaces.
    This allows code to depend on protocols (RepositoryProtocol) while
    getting SQLAlchemy implementations at runtime.

    Order: 40 (runs last, after schema sync)

    What this step does:
        1. Bind GenericRepository to RepositoryProtocol
        2. Bind UnitOfWork to UnitOfWorkProtocol
        3. Bind SchemaMapper to SchemaMapperProtocol
        4. Bind other SQLAlchemy adapters as needed
        5. Configure any adapter-specific settings

    After this step runs:
        - Dependency injection is fully configured
        - Services can @inject protocol dependencies
        - SQLAlchemy adapters are used for all persistence

    MX Override Example (MongoDB):
        class InitMongoAdapters:
            name = "init_adapters"
            order = 40

            async def run(self, container: Container) -> None:
                from framework_mx_mongo.repository import MongoRepository
                from framework_mx_mongo.unit_of_work import MongoUnitOfWork

                # Bind MongoDB implementations
                container.repository.override(MongoRepository)
                container.unit_of_work.override(MongoUnitOfWork)

    Configuration:
        - Adapters can be overridden via entry points
        - See framework_m.adapters.* entry point groups
    """

    name = "init_adapters"
    order = 40

    async def run(self, container: Any) -> None:
        """
        Bind SQLAlchemy adapters to DI container.

        Args:
            container: DI container to configure
        """
        # Ensure environment is loaded before resolving adapters
        load_env()

        from framework_m_standard.adapters.db.generic_repository import (
            GenericRepository,
        )
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
        from framework_m_standard.adapters.db.session import SessionFactory

        logger.info("[InitAdapters] Binding SQLAlchemy adapters to DI container...")

        # Bind Repository Protocol
        if hasattr(container, "repository"):
            container.repository.override(GenericRepository)
            logger.info("[InitAdapters]   ✓ RepositoryProtocol -> GenericRepository")

        # Bind Session Factory (UnitOfWork Protocol)
        if hasattr(container, "session_factory"):
            container.session_factory.override(SessionFactory)
            logger.info("[InitAdapters]   ✓ SessionFactory bound")

        # Bind SchemaMapper Protocol
        if hasattr(container, "schema_mapper"):
            container.schema_mapper.override(SchemaMapper)
            logger.info("[InitAdapters]   ✓ SchemaMapperProtocol -> SchemaMapper")

        # Wire Secrets to ConnectionFactory
        if hasattr(container, "connection_factory") and hasattr(
            container, "secrets_manager"
        ):
            from framework_m_standard.adapters.db.connection import ConnectionFactory

            factory = ConnectionFactory()
            factory.set_secrets_manager(container.secrets_manager())
            logger.info("[InitAdapters]   ✓ SecretsManager -> ConnectionFactory")

        # Check for adapter overrides from entry points
        # This allows MX packages to override specific adapters
        try:
            from importlib.metadata import entry_points

            # Check for repository overrides
            eps = entry_points(group="framework_m.adapters.repository")
            if eps:
                for ep in eps:
                    adapter_class = ep.load()
                    container.repository.override(adapter_class)
                    logger.info(
                        f"[InitAdapters]   ⚡ Repository override: {ep.name} -> {adapter_class.__name__}"
                    )

            # Check for unit_of_work overrides
            eps = entry_points(group="framework_m.adapters.unit_of_work")
            if eps:
                for ep in eps:
                    adapter_class = ep.load()
                    container.unit_of_work.override(adapter_class)
                    logger.info(
                        f"[InitAdapters]   ⚡ UnitOfWork override: {ep.name} -> {adapter_class.__name__}"
                    )

            # Check for schema_mapper overrides
            eps = entry_points(group="framework_m.adapters.schema_mapper")
            if eps:
                for ep in eps:
                    adapter_class = ep.load()
                    container.schema_mapper.override(adapter_class)
                    logger.info(
                        f"[InitAdapters]   ⚡ SchemaMapper override: {ep.name} -> {adapter_class.__name__}"
                    )

        except ImportError:
            # importlib.metadata not available (Python < 3.8)
            pass
        except Exception as e:
            logger.warning(
                f"[InitAdapters] Warning: Failed to check entry point overrides: {e}"
            )

        logger.info("[InitAdapters] Adapter binding complete")


# Verify protocol compliance
assert isinstance(InitAdapters(), BootstrapProtocol)
