"""InitLogging - Initialize structured logging.

This bootstrap step configures structlog and injects the
SecretRedactionProcessor based on the logging configuration.
"""

from typing import Any

from framework_m_core.interfaces.bootstrap import BootstrapProtocol


class InitLogging(BootstrapProtocol):
    """
    Initialize the global structlog logging pipeline.

    Applies standard processors (timestamps, log levels) and conditionally
    injects the SecretRedactionProcessor based on the logging configuration.

    Order: 5 (runs very early to ensure all subsequent steps are logged)
    """

    name = "init_logging"
    order = 5

    async def run(self, container: Any) -> None:
        """Configure unified structured logging for the entire process."""
        import logging

        import structlog
        from framework_m_core.config import RootConfig, load_config
        from framework_m_core.domain.redactor import ScrubbingLogic

        from framework_m_standard.adapters.logging.redactor_processor import (
            SecretRedactionProcessor,
        )

        # Retrieve config
        try:
            config_dict = (
                container.config() if callable(container.config) else container.config
            ) or {}
            if not config_dict:
                from framework_m_core.config import load_config

                config_dict = load_config()

            # Initialize RootConfig (Pydantic will merge config_dict with .env)
            config = RootConfig(**config_dict)
        except Exception:
            config = RootConfig()

        # 1. Define Shared Processors (Redaction + Metadata)
        shared_processors: list[Any] = [
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.add_log_level,
            structlog.stdlib.add_logger_name,
            structlog.processors.TimeStamper(fmt="iso"),
        ]

        if config.logging.enabled:
            redactor = ScrubbingLogic(keys_to_redact=config.logging.redact_keys)
            redaction_processor = SecretRedactionProcessor(
                config=config.logging, redactor=redactor
            )
            shared_processors.append(redaction_processor)

        shared_processors.extend(
            [
                structlog.processors.StackInfoRenderer(),
                structlog.processors.format_exc_info,
            ]
        )

        if hasattr(container, "config"):
            # Sync the consolidated config (File + Env) into the DI container
            container.config.from_dict(config.model_dump())

        # 2. Configure Structlog to use the standard logging bridge
        structlog.configure(
            processors=shared_processors
            + [
                structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
            ],
            logger_factory=structlog.stdlib.LoggerFactory(),
            cache_logger_on_first_use=True,
        )

        # 3. Configure the Standard Logging Bridge (The Formatter)
        renderer = (
            structlog.processors.JSONRenderer()
            if config.logging.format == "json"
            else structlog.dev.ConsoleRenderer(colors=True)
        )

        formatter = structlog.stdlib.ProcessorFormatter(
            foreign_pre_chain=shared_processors,
            processors=[
                structlog.stdlib.ProcessorFormatter.remove_processors_meta,
                renderer,
            ],
        )

        handler = logging.StreamHandler()
        handler.setFormatter(formatter)

        root_logger = logging.getLogger()
        # Clear existing handlers to avoid duplicates during bootstrap
        root_logger.handlers = [handler]
        root_logger.setLevel(logging.INFO)

        # 4. Hijack Uvicorn (Propagate to root)
        for name in ["uvicorn", "uvicorn.error", "uvicorn.access"]:
            logger = logging.getLogger(name)
            logger.handlers = []
            logger.propagate = True

        # Silence primitive access logs (we prefer rich middleware logs)
        logging.getLogger("uvicorn.access").setLevel(logging.WARNING)


# Verify protocol compliance
assert isinstance(InitLogging(), BootstrapProtocol)
