from foxange.input import collect_input
from . import input 
from . import list_proce   
from . import file
from . import math

__all__ = [
    "collect_input"
]

__version__ = '0.3.2'

def version()->str:
    print(f"version : {__version__}")
    return __version__

def help()->None:
    print("plase read GITBUH's foxange-org user 's 'PyPI-foxange'")
    return 


if __name__ == "__main__":
    print("this is a Python 's other mod,if you want use there,plasece use 'import foxange'or 'from foxange import ...'")
    print("down is test the other mod 's text:")
    
    from os import system
    
    print("input.py:")
    system("python input.py")