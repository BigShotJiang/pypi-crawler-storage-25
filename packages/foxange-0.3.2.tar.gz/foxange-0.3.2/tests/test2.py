import foxange

LIST = [1,2,3,4,5,6,7,8]

a = foxange.input.collect_input(foxange.list_proce.unique(LIST))