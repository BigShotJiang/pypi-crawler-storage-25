# Changelog

All notable changes to ADRI will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [7.4.0] - 2026-03-04

**Feature Release: Agent Mode — Governed AI Agent Delegation**

This release adds the new `AGENT` mode to the ADRI Mode Detection System, enabling governed AI agent delegation with sandbox controls. The agent mode extends the `ADRIMode` enum alongside existing modes (reasoning, conversation, deterministic).

Addresses Issue #45 on `Verodat/verodat-adri` and Issue #108 on `adri-standard/adri`.

### Added
- **Agent Mode**: New `AGENT = "agent"` member in `ADRIMode` enum for governed AI agent delegation with sandbox controls
- **Mode Description**: Human-readable description for agent mode via `get_mode_description()`
- **Mode Sections**: Agent mode section definitions with optional `input_requirements` and `output_requirements` via `get_mode_sections()`
- **`ADRIMode.from_string("agent")`**: String-to-enum conversion support for the new agent mode

### Packages
- `verodat-adri` (enterprise): [PyPI](https://pypi.org/project/verodat-adri/)
- `adri` (open source): [PyPI](https://pypi.org/project/adri/)

---

## [7.3.0] - 2026-03-27

**Feature Release: Artifact Declaration — Protocol Compatibility with A2UI, MCP, A2A**

This release adds optional `artifact_declaration` / `artifact_declarations` sections to ADRI contracts, enabling protocol compatibility with A2UI, MCP, WebMCP, and A2A. ADRI contracts can now declare what validated data outputs are FOR — reports, UI components, dataset pushes, notifications, etc. This is a non-breaking, fully backward-compatible addition.

Addresses RFC Discussion #100 and Feature Issue #101 on upstream `adri-standard/adri`.

### Added
- **Artifact Declaration**: New optional contract section declaring output artifact types and rendering metadata
  - Singular form: `artifact_declaration` (dict) for single artifacts
  - Plural form: `artifact_declarations` (list) for multiple artifacts from one contract
  - Both forms are mutually exclusive; singular is treated as single-element array internally
- **7 Core Artifact Types**: `report`, `ui_component`, `dataset_push`, `notification`, `config_update`, `scaffold`, `certification_evidence`
- **Custom Type Extension**: `x-custom-*` prefix pattern for platform-specific artifact types
- **5 Render Formats**: `markdown`, `json`, `html`, `a2ui_json`, `text` — validated in `render_hints.format`
- **Lifecycle Management**: `ephemeral` (run-scoped, default) and `persistent` (outlives run, optional `retention_days`)
- **`ArtifactDeclaration` Dataclass**: Typed Python class with `from_dict()`, `to_dict()`, `is_custom_type()` methods
- **Validation Pipeline Integration**: Artifact declarations validated as part of `ContractValidator.validate_contract()` flow
- **Accessor API**: `BundledStandardWrapper.get_artifact_declaration()` and `get_artifact_declarations()` methods
- **Comprehensive Test Suite**: 53 new tests across 5 test classes covering dataclass, validation, integration, and accessor API
- **Example Contracts**: `artifact_declaration_example.yaml` and `multi_artifact_example.yaml` in ADRI/contracts/

### Technical Details
- New module: `src/adri/contracts/artifact.py` — constants, dataclass, and validation functions
- Updated: `schema.py` (OPTIONAL_SECTIONS), `validator.py` (pipeline wiring), `engine.py` (accessor methods)
- Exports: `ArtifactDeclaration` available via `from adri import ArtifactDeclaration` and `from adri.contracts import ArtifactDeclaration`
- Warning (not error) for `lifecycle: persistent` without `retention_days` — per community feedback

### Package Information
- PyPI: `verodat-adri` v7.3.0 (enterprise), `adri` v7.3.0 (open source)
- Requires: Python 3.10+
- Tests: All passing (53 new + existing suite)

---

## [7.2.10] - 2026-01-27

**Critical Bug Fix: Threshold Paradox Resolution**

This patch release fixes a critical threshold resolution bug that caused inconsistent behavior between assessment and execution decisions in the decorator.

### Fixed
- **Threshold Paradox Bug**: Fixed threshold resolution timing issue in `@adri_protected` decorator
  - Bug: Threshold was resolved BEFORE contract auto-generation, causing decorator to use config default (80.0) instead of contract-specified threshold (75.0)
  - Impact: Assessments passed with 75.0 threshold, but execution decisions incorrectly used 80.0
  - Fix: Moved threshold resolution to AFTER contract creation to ensure contract-specified thresholds are always respected
  - File: `src/adri/guard/modes.py` - reordered `protect_function_call()` to resolve threshold after `_ensure_contract_exists()`
  - Result: Assessment threshold and execution threshold now always consistent

### Technical Details
**Root Cause**: In auto-generation scenarios, the decorator resolved thresholds before the contract file existed, falling back to config defaults. After contract generation (with 75.0), the assessor correctly read 75.0 from the contract, but the decorator still used the previously resolved 80.0 for execution decisions.

**Solution**: Ensuring contract existence before threshold resolution guarantees that contract-specified thresholds take precedence over config defaults, maintaining consistency throughout the protection flow.

### Package Information
- PyPI: `verodat-adri` v7.2.10 (enterprise), `adri` v7.2.10 (open source)
- Requires: Python 3.10+
- Tests: All passing

## [7.2.9] - 2026-01-27

**verodat-adri v7.2.9 / adri v7.2.9 - Complete output_requirements Support**

### Fixed
- **Complete fix for `output_requirements` format** across both code paths:
  - `BundledStandardWrapper.get_field_requirements()` — field loading for deterministic mode contracts
  - `DataQualityAssessor.assess()` schema validation path
- `@adri_protected` decorator now works correctly with deterministic mode contracts

### Package Information
- PyPI: `verodat-adri` v7.2.9 and `adri` v7.2.9
- All CI tests passing

---

## [7.2.8] - 2026-01-27

**verodat-adri v7.2.8 - output_requirements BundledStandardWrapper Fix**

### Fixed
- **Critical bug**: `BundledStandardWrapper.get_field_requirements()` now correctly loads field requirements from `output_requirements` format contracts
- Added 6 new tests for `output_requirements` format handling
- Documentation coherence improvements (example imports, broken links)

### Package Information
- PyPI: `verodat-adri` v7.2.8
- Tests: 139 tests passing, zero regressions

---

## [7.2.7] - 2026-01-23

**verodat-adri v7.2.7 - Package Context Resolution Fix**

### Fixed
- `package_context` resolution from project root (baseline regression fix)
- Windows path normalisation issue in package context lookup
- 5 environment-dependent tests marked as flaky and isolated

### Changed
- Implemented 3-tier CI architecture for more reliable test pipeline

### Package Information
- PyPI: `verodat-adri` v7.2.7

---

## [7.2.6] - 2026-01-21

**verodat-adri v7.2.6 - Run-Scoped Audit Logs**

### Added
- **Per-call `audit_log_dir` parameter** for `@adri_protected` decorator — enables run-scoped JSONL audit logs
- Allows each decorator invocation to write to a different log directory, useful for parallel or multi-run pipelines

### Package Information
- PyPI: `verodat-adri` v7.2.6

---

## [7.2.5] - 2026-01-21

**verodat-adri v7.2.5 - CI Release Workflow Fix**

### Fixed
- GitHub release creation step is now idempotent — re-running a release workflow no longer fails if the GitHub release already exists

### Package Information
- PyPI: `verodat-adri` v7.2.5

---

## [7.2.4] - 2026-01-21

**verodat-adri v7.2.4 - README and Release Workflow Polish**

### Changed
- Polished README for clarity and accuracy
- Release workflow made more resilient to transient failures

### Package Information
- PyPI: `verodat-adri` v7.2.4

---

## [7.2.3] - 2026-01-21

**verodat-adri v7.2.3 - README Import/Installation/License Wording Fix**

### Fixed
- Corrected import examples, installation instructions, and license wording in README for PyPI display

### Package Information
- PyPI: `verodat-adri` v7.2.3

---

## [7.2.2] - 2026-01-21

**verodat-adri v7.2.2 - PyPI README Accuracy**

### Changed
- Updated enterprise README to only document fully implemented features (removed forward-looking statements)

### Package Information
- PyPI: `verodat-adri` v7.2.2

---

## [7.2.1] - 2026-01-21

**verodat-adri v7.2.1 - PyPI README Accuracy**

### Changed
- Updated enterprise README to clarify implementation status of features for PyPI display

### Package Information
- PyPI: `verodat-adri` v7.2.1

---

## [7.2.0] - 2026-01-19

**verodat-adri v7.2.0 - Code Quality and Documentation Accuracy Release**

This release focuses on code quality improvements and documentation accuracy for the enterprise package.

### Changed
- Resolved all 25 flake8 code quality issues for cleaner, more maintainable codebase
- Fixed docstring formatting across enterprise and core modules for better documentation generation
- Updated README.enterprise.md with Implementation Status section clarifying current vs planned features
- Improved code consistency with proper docstring formatting (D205, D400, D401 compliance)

### Fixed
- Trailing whitespace and indentation issues in license validation module
- Docstring imperative mood compliance across all modules
- Documentation accuracy regarding workflow_context, data_provenance, and AI reasoning features
  - Clarified that these features currently provide basic console/file logging
  - Full API integration planned for future releases

### Documentation
- Added "Implementation Status" section to README.enterprise.md distinguishing:
  - ✅ Fully implemented: License validation, centralized logging, environment-aware config
  - 🔄 Basic logging only: Workflow context, data provenance, AI reasoning (full API integration planned)
- Improved transparency about current capabilities vs. planned features

### Package Information
- PyPI: `verodat-adri` v7.2.0
- Requires: Python 3.10+, Valid Verodat API key
- Tests: 1,956 passing, 0 flake8 issues

---

## [7.1.0] - 2026-01-19

**adri v7.1.0 - Code Quality Improvements**

This release aligns the open source package with enterprise code quality improvements.

### Changed
- Resolved code quality issues in shared core modules
- Improved docstring formatting for better documentation
- Enhanced code consistency and maintainability

### Fixed
- Docstring formatting issues in contract generation and validation modules
- Code style compliance for cleaner codebase

### Package Information
- PyPI: `adri` v7.1.0
- Requires: Python 3.10+
- Open source, no license key required

---

## [7.0.0] - 2026-08-01

**ADRI v7.0.0 - Version Alignment Release**

This release aligns the open source `adri` package with the enterprise `verodat-adri` package at v7.0.0, incorporating bug fixes and improvements from both repositories.

### Added
- Comprehensive Python 3.10+ compatibility improvements
- Enhanced validation rules failure extraction for all dimensions
- `'number'` type handling in field type checking
- Standardized configuration to single `ADRI/config.yaml` location
- Standard validation system with critical bug fixes

### Changed
- Version aligned between open source (`adri`) and enterprise (`verodat-adri`) packages
- Improved f-string handling across codebase
- Enhanced decorator audit logging
- Updated dependencies and test infrastructure
- Clean package structure: `adri` (core) + `adri_enterprise` (enterprise-only)

### Fixed
- Python 3.10 syntax error in pipeline.py
- Python 3.11 multi-line f-string syntax errors
- Broken f-strings across multiple files
- Validation rules format support for failure extraction
- Flake8 linting errors for CI compliance
- Multiple test failures resolved for PR readiness

### Removed
- Experimental `callbacks/` module (untested, not integrated into core decorator)
- Experimental `events/` module (untested, not integrated into core decorator)
- These features may return in a future release once properly validated

### Enterprise Features (verodat-adri only)
- `adri_enterprise.decorator` - Enhanced decorator with reasoning_mode, workflow_context
- `adri_enterprise.license` - API key validation (requires VERODAT_API_KEY)
- `adri_enterprise.logging.verodat` - Verodat cloud integration
- `adri_enterprise.logging.reasoning` - AI reasoning step logging

### Migration Guide
- No breaking API changes for standard usage
- If you were using `from adri.callbacks import ...` or `from adri.events import ...`, these imports will fail. These were experimental and undocumented features.

---

## [6.1.0] - 2025-12-19

**verodat-adri v6.1.0 - Enterprise License Validation**

This release introduces mandatory license validation for the verodat-adri enterprise package.
The package now requires a valid Verodat API key to function, ensuring enterprise features are
only accessible to licensed users.

### Added

**License Validation System**
- New `adri_enterprise.license` module for API key validation
- `validate_license()` function for explicit license validation
- `is_license_valid()` function to check cached validation status
- `LicenseValidationError` exception for validation failures
- `LicenseInfo` dataclass with validation details (valid, account_id, username)
- Automatic validation on first decorator use (lazy validation)
- 24-hour validation cache to minimize API calls
- Environment variable support: `VERODAT_API_KEY` and `VERODAT_API_URL`

**Enterprise Decorator Enhancement**
- `@adri_protected` decorator now validates license on first use
- Clear error messages with guidance on obtaining API keys
- Graceful handling of network errors during validation

### Changed

- Package name: `verodat-adri` (enterprise) is now distinct from `adri` (open source)
- Package requires `VERODAT_API_KEY` environment variable to function
- Updated `__init__.py` to export license validation components
- Updated project URLs to point to Verodat/verodat-adri repository
- Enhanced package description to clarify enterprise licensing requirement

### Security

- API keys are validated against Verodat API endpoint (`/ai/key`)
- API key is passed via `Authorization: ApiKey {key}` header
- Validation results are cached to prevent unnecessary network calls
- Invalid or expired keys result in clear `LicenseValidationError`

### Migration Guide

To use verodat-adri v6.1.0+, you must:

1. **Obtain a Verodat API key** from your Verodat account settings
2. **Set the environment variable**:
   ```bash
   export VERODAT_API_KEY="your-api-key"
   ```
3. **Use the decorator as before** - validation happens automatically:
   ```python
   from adri_enterprise.decorator import adri_protected

   @adri_protected(contract="my_contract")
   def my_function(data):
       return process(data)
   ```

For open source features without licensing, use the `adri` package instead.

## [5.1.0] - 2025-10-21

**Documentation Improvements for Open-Source Adoption**

### Changed
- Enhanced documentation structure and clarity for better developer experience
- Improved getting started guides with clearer onboarding paths
- Optimized README for first-time users and quick adoption
- Refined code examples and usage patterns
- Updated architecture documentation for better understanding
- Streamlined contribution guidelines
- Enhanced API reference documentation

### Fixed
- Documentation consistency across all guides
- Code example accuracy and completeness
- Cross-reference links and navigation

## [5.0.1] - 2026-01-17

**Standards Library & Documentation Updates**

### Added
- 13 production-ready standards for common use cases (customer service, e-commerce, financial, healthcare, marketing)
- Framework integration standards (LangChain, CrewAI, LlamaIndex, AutoGen)
- Template standards for API responses, time series, and nested JSON
- Comprehensive test suite validating all standards

### Changed
- Improved README clarity and organization
- Enhanced documentation with better examples
- Updated contribution guidelines

### Fixed
- Documentation consistency improvements
- Code example updates

## [5.0.0] - 2025-10-17

**ADRI v5.0.0 - The missing data layer for AI agents**

Initial release of the open-source ADRI framework. Protect your AI agents from bad data with a single decorator.

### Features

**Core Protection**
- `@adri_protected` decorator for automatic data quality validation
- Five-dimension quality assessment (validity, completeness, consistency, accuracy, timeliness)
- Auto-generation of quality standards from your data
- Configurable protection modes: `raise`, `warn`, or `continue`
- Environment-based standard management (dev/prod separation)

**Framework Integration**
- Works with any Python function or AI framework
- Native support for LangChain, CrewAI, AutoGen, LlamaIndex, Haystack, Semantic Kernel
- Zero configuration required - add decorator and go

**CLI Tools**
- `adri setup` - Initialize ADRI in your project with guided setup
- `adri generate-standard` - Create quality standards from your data
- `adri assess` - Validate data quality against standards
- `adri list-standards` - View available quality standards
- `adri validate-standard` - Verify standard file correctness

**Developer Experience**
- 2-minute integration time
- Local logging for debugging and development
- YAML-based standards for transparency and version control
- Comprehensive documentation and examples
- Intelligent CI with docs-only detection

**Additional Features**
- Dimension-specific quality thresholds
- Auto-generation from sample data
- Configurable failure handling
- Assessment caching for performance
- Local JSONL logging

### Getting Started

```python
from adri import adri_protected

@adri_protected(standard="customer_data", data_param="data")
def process_customers(data):
    # Your agent logic here - now protected!
    return results
```

First run with good data → ADRI generates quality standard
Future runs → ADRI validates against that standard
Bad data → Blocked with detailed quality report

### Documentation

Complete documentation available in the repository:
- **QUICKSTART.md** - 2-minute integration guide
- **docs/GETTING_STARTED.md** - 10-minute detailed tutorial
- **docs/HOW_IT_WORKS.md** - Five quality dimensions explained
- **docs/FRAMEWORK_PATTERNS.md** - Framework-specific integration patterns
- **docs/CLI_REFERENCE.md** - Complete CLI command reference
- **docs/API_REFERENCE.md** - Full programmatic API documentation
- **docs/FAQ.md** - Common questions and answers
- **docs/ARCHITECTURE.md** - Technical architecture details

### Requirements

- Python 3.10+
- Works on Linux, macOS, and Windows

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for how to contribute to ADRI.

## License

Apache License 2.0 - See [LICENSE](LICENSE) for details.
