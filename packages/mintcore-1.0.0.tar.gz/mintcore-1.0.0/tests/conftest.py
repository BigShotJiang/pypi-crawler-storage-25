import pytest
from fastapi.testclient import TestClient
from mintcore.app import create_app

@pytest.fixture(scope="session")
def client():
    app = create_app()
    with TestClient(app) as c:
        yield c

@pytest.fixture(scope="session")
def admin_headers():
    return {"X-Admin-Key": "admin-secret"}