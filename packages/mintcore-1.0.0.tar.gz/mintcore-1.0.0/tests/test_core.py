"""Core engine smoke tests."""

def setup_module():
    from fastapi.testclient import TestClient
    from mintcore.app import create_app
    c = TestClient(create_app())
    c.post("/admin/currency",
           json={"currency_id": "GLD", "name": "Gold", "symbol": "G"},
           headers={"X-Admin-Key": "admin-secret"})
    c.post("/users", json={"user_id": "alice"})
    c.post("/users", json={"user_id": "bob"})

def test_mint_and_balance(client, admin_headers):
    client.post("/admin/mint",
                json={"to": "alice", "amount": 500, "currency_id": "GLD"},
                headers=admin_headers)
    r = client.get("/users/alice/balance")
    assert r.status_code == 200
    assert r.json()["wallets"]["GLD"] == 500

def test_transfer(client):
    r = client.post("/transactions/transfer", json={
        "from_user": "alice", "to_user": "bob",
        "amount": 100, "currency_id": "GLD",
    })
    assert r.status_code == 200
    assert r.json()["from_balance"] == 400

def test_debt_cap(client):
    r = client.post("/transactions/transfer", json={
        "from_user": "bob", "to_user": "alice",
        "amount": 9999, "currency_id": "GLD",
    })
    assert r.status_code == 400

def test_analytics(client):
    r = client.get("/analytics/stats")
    assert "user_count" in r.json()
    assert "supply_by_currency" in r.json()