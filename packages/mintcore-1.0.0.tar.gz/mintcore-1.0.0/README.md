# MintCore

[![PyPI](https://img.shields.io/pypi/v/mintcore)](https://pypi.org/project/mintcore/)
[![Python](https://img.shields.io/pypi/pyversions/mintcore)](https://pypi.org/project/mintcore/)
[![License: SOCL-1.0](https://img.shields.io/badge/License-SOCL--1.0-blue.svg)](LICENSE)

Centralized virtual currency engine for game economies.
FastAPI + SQLAlchemy + a `mintcore` CLI out of the box.

## Install

```bash
pip install mintcore           # core engine + CLI
pip install mintcore[bot]      # + Discord bot support
pip install mintcore[dev]      # + dev/test tools
```

## Quickstart

```bash
mintcore init    # writes .env template
mintcore start   # starts API on http://127.0.0.1:8000
```

Or embed directly in your code:

```python
from mintcore import MintCore

engine = MintCore(
    database_url="sqlite:///./mygame.db",
    admin_key="super-secret",
    debt_cap=-500,
)
engine.run(host="0.0.0.0", port=8000)
```

## CLI

```bash
mintcore start                             # start API server
mintcore init                              # write .env template
mintcore status                            # check server health

mintcore admin currency GLD Gold G        # create currency
mintcore admin mint player1 500 GLD       # mint to player
mintcore admin tax 5 GLD                  # 5% tax sweep
mintcore admin interest                   # apply interest
mintcore admin stats                      # economy snapshot
mintcore admin richlist GLD               # top holders
```

## Discord bot

```bash
# Add your DISCORD_TOKEN to .env, then:
python -m mintcore.bot.main
```

See [discord bot docs](https://github.com/TheServer-lab/mintcore/blob/main/docs/bot.md) for slash command reference.

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `MINTCORE_ADMIN_KEY` | `admin-secret` | Admin API key |
| `MINTCORE_DB_URL` | `sqlite:///./mintcore.db` | SQLAlchemy DB URL |
| `MINTCORE_TREASURY` | `treasury` | Treasury account ID |
| `MINTCORE_INTEREST_RATE` | `5` | Interest % per cycle |
| `MINTCORE_DEBT_CAP` | `-1000` | Max overdraft |
| `MINTCORE_CACHE_TTL` | `300` | Rate cache TTL (seconds) |
| `DISCORD_TOKEN` | — | Discord bot token |

