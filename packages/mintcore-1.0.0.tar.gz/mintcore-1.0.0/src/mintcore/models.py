import uuid
from sqlalchemy import Column, String, Integer, Float, DateTime
from sqlalchemy.sql import func
from mintcore.database import Base

def _uuid():
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"
    user_id = Column(String,  primary_key=True)
    debt    = Column(Integer, default=0)

class Currency(Base):
    __tablename__ = "currencies"
    currency_id = Column(String,  primary_key=True)
    name        = Column(String,  nullable=False)
    symbol      = Column(String,  nullable=False)
    supply_cap  = Column(Integer, nullable=True)

class Wallet(Base):
    __tablename__ = "wallets"
    id          = Column(String,  primary_key=True, default=_uuid)
    user_id     = Column(String,  nullable=False)
    currency_id = Column(String,  nullable=False)
    balance     = Column(Integer, default=0)

class ExchangeRate(Base):
    __tablename__ = "exchange_rates"
    id              = Column(String,   primary_key=True, default=_uuid)
    base_currency   = Column(String,   nullable=False)
    target_currency = Column(String,   nullable=False)
    rate            = Column(Float,    nullable=False)
    updated_at      = Column(DateTime, server_default=func.now(), onupdate=func.now())

class Transaction(Base):
    __tablename__ = "transactions"
    tx_id       = Column(String,   primary_key=True, default=_uuid)
    type        = Column(String,   nullable=False)
    currency_id = Column(String,   nullable=True)
    from_user   = Column(String,   nullable=False)
    to_user     = Column(String,   nullable=False)
    amount      = Column(Integer,  nullable=False)
    timestamp   = Column(DateTime, server_default=func.now())