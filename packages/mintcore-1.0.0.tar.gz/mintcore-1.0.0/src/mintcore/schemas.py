from pydantic import BaseModel, Field
from typing import Optional

class CreateUser(BaseModel):
    user_id: str

class CreateCurrency(BaseModel):
    currency_id: str
    name:        str
    symbol:      str
    supply_cap:  Optional[int] = None

class SetRate(BaseModel):
    base:   str
    target: str
    rate:   float = Field(gt=0)

class Mint(BaseModel):
    to:          str
    amount:      int = Field(gt=0)
    currency_id: str

class Burn(BaseModel):
    from_user:   str
    amount:      int = Field(gt=0)
    currency_id: str

class Transfer(BaseModel):
    from_user:   str
    to_user:     str
    amount:      int = Field(gt=0)
    currency_id: str

class Tax(BaseModel):
    percentage:  int = Field(gt=0, le=100)
    currency_id: str

class Loan(BaseModel):
    user_id:     str
    amount:      int = Field(gt=0)
    currency_id: str

class Repay(BaseModel):
    user_id:     str
    amount:      int = Field(gt=0)
    currency_id: str