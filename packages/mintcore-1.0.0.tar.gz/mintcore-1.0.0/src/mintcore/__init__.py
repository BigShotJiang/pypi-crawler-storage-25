"""
MintCore — Centralized virtual currency engine.

Quick start:
    from mintcore import MintCore
    engine = MintCore()          # SQLite in current dir
    engine.run()                 # starts FastAPI on :8000

Programmatic use:
    from mintcore.api import mint, transfer, get_balance
"""

from mintcore.engine import MintCore

__version__ = "1.0.0"
__all__     = ["MintCore"]