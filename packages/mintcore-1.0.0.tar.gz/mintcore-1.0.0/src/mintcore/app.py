from fastapi import FastAPI
from mintcore.database import Base, engine, SessionLocal
from mintcore.models import User
from mintcore import config
from mintcore.routers import users, transactions, admin, rates, analytics


def create_app() -> FastAPI:
    app = FastAPI(
        title="MintCore",
        description="Centralized virtual currency engine",
        version="1.0.0",
    )

    # Create tables
    Base.metadata.create_all(bind=engine)

    # Seed treasury account
    with SessionLocal() as db:
        if not db.query(User).filter_by(user_id=config.TREASURY_ID).first():
            db.add(User(user_id=config.TREASURY_ID))
            db.commit()

    app.include_router(users.router)
    app.include_router(transactions.router)
    app.include_router(admin.router)
    app.include_router(rates.router)
    app.include_router(analytics.router)

    @app.get("/", tags=["root"])
    def root():
        return {"engine": "MintCore", "version": "1.0.0", "docs": "/docs"}

    return app