"""
MintCore engine class.
Wraps FastAPI app creation + uvicorn launch into a simple interface
so library consumers never need to touch uvicorn directly.
"""
from __future__ import annotations

import uvicorn
from mintcore.app import create_app


class MintCore:
    """
    Programmatic interface to the MintCore currency engine.

    Example::

        from mintcore import MintCore

        engine = MintCore(
            database_url="sqlite:///./game.db",
            admin_key="super-secret",
            debt_cap=-500,
        )
        engine.run(host="0.0.0.0", port=8000)
    """

    def __init__(
        self,
        database_url: str  = "sqlite:///./mintcore.db",
        admin_key: str     = "admin-secret",
        treasury_id: str   = "treasury",
        interest_rate: int = 5,
        debt_cap: int      = -1000,
        cache_ttl: int     = 300,
    ):
        from mintcore import config as _cfg

        # Override module-level config with constructor values
        _cfg.DATABASE_URL  = database_url
        _cfg.ADMIN_KEY     = admin_key
        _cfg.TREASURY_ID   = treasury_id
        _cfg.INTEREST_RATE = interest_rate
        _cfg.DEBT_CAP      = debt_cap
        _cfg.CACHE_TTL     = cache_ttl

        self._app = create_app()

    @property
    def app(self):
        """Return the raw FastAPI app (for ASGI mounting, testing, etc.)."""
        return self._app

    def run(self, host: str = "127.0.0.1", port: int = 8000, **kwargs):
        """Start the uvicorn server (blocking)."""
        uvicorn.run(self._app, host=host, port=port, **kwargs)