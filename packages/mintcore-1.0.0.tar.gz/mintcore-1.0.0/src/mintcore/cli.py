"""
mintcore CLI — installed as `mintcore` command via pyproject.toml scripts.

Usage:
    mintcore start                  # Start the API server
    mintcore start --port 9000      # Custom port
    mintcore init                   # Write a .env template
    mintcore status                 # Check if server is running
    mintcore admin mint ...         # Admin commands (pass-through to API)
"""
import os
import typer
import httpx
from rich.console import Console
from rich.table   import Table
from rich.panel   import Panel

app     = typer.Typer(help="MintCore — virtual currency engine CLI")
admin   = typer.Typer(help="Admin commands")
app.add_typer(admin, name="admin")

console = Console()

def _base_url():
    return os.getenv("MINTCORE_URL", "http://127.0.0.1:8000")

def _headers():
    return {"X-Admin-Key": os.getenv("MINTCORE_ADMIN_KEY", "admin-secret")}

# ── mintcore start ────────────────────────────────────────────

@app.command()
def start(
    host:   str = typer.Option("127.0.0.1", help="Bind host"),
    port:   int = typer.Option(8000,        help="Bind port"),
    reload: bool = typer.Option(False,      help="Hot reload (dev mode)"),
):
    """Start the MintCore API server."""
    import uvicorn
    from mintcore.app import create_app

    console.print(Panel(
        f"[bold green]MintCore[/] starting on [cyan]http://{host}:{port}[/]\n"
        f"Docs → [cyan]http://{host}:{port}/docs[/]",
        title="🪙 MintCore", border_style="green",
    ))
    uvicorn.run("mintcore.app:create_app", host=host, port=port,
                reload=reload, factory=True)

# ── mintcore init ─────────────────────────────────────────────

@app.command()
def init():
    """Write a .env template to the current directory."""
    env_path = ".env"
    if os.path.exists(env_path):
        console.print("[yellow].env already exists — skipping.[/]")
        return
    with open(env_path, "w") as f:
        f.write(
            "MINTCORE_ADMIN_KEY=admin-secret\n"
            "MINTCORE_DB_URL=sqlite:///./mintcore.db\n"
            "MINTCORE_TREASURY=treasury\n"
            "MINTCORE_INTEREST_RATE=5\n"
            "MINTCORE_DEBT_CAP=-1000\n"
            "MINTCORE_CACHE_TTL=300\n"
        )
    console.print("[green]✓ .env written.[/] Edit it before going to production.")

# ── mintcore status ───────────────────────────────────────────

@app.command()
def status():
    """Check whether the MintCore server is reachable."""
    url = _base_url()
    try:
        r = httpx.get(f"{url}/analytics/stats", timeout=3.0)
        r.raise_for_status()
        data = r.json()
        console.print(Panel(
            f"[green]● Online[/]  {url}\n\n"
            f"Users: [bold]{data['user_count']}[/]   "
            f"Transactions: [bold]{data['total_tx']}[/]   "
            f"Total debt: [bold]{data['total_debt']}[/]",
            title="MintCore Status", border_style="green",
        ))
    except Exception:
        console.print(Panel(
            f"[red]● Offline[/]  {url}\n\nIs the server running? Try [bold]mintcore start[/].",
            title="MintCore Status", border_style="red",
        ))

# ── mintcore admin mint ───────────────────────────────────────

@admin.command("mint")
def admin_mint(
    to:       str = typer.Argument(..., help="User ID"),
    amount:   int = typer.Argument(..., help="Amount"),
    currency: str = typer.Argument(..., help="Currency ID"),
):
    """Mint currency to a user."""
    r = httpx.post(f"{_base_url()}/admin/mint",
                   json={"to": to, "amount": amount, "currency_id": currency},
                   headers=_headers())
    console.print(r.json())

@admin.command("burn")
def admin_burn(
    from_user: str = typer.Argument(..., help="User ID"),
    amount:    int = typer.Argument(..., help="Amount"),
    currency:  str = typer.Argument(..., help="Currency ID"),
):
    """Burn currency from a user."""
    r = httpx.post(f"{_base_url()}/admin/burn",
                   json={"from_user": from_user, "amount": amount, "currency_id": currency},
                   headers=_headers())
    console.print(r.json())

@admin.command("tax")
def admin_tax(
    percentage: int = typer.Argument(..., help="Tax percentage"),
    currency:   str = typer.Argument(..., help="Currency ID"),
):
    """Apply a tax sweep."""
    r = httpx.post(f"{_base_url()}/admin/tax",
                   json={"percentage": percentage, "currency_id": currency},
                   headers=_headers())
    console.print(r.json())

@admin.command("interest")
def admin_interest():
    """Apply interest to all outstanding debts."""
    r = httpx.post(f"{_base_url()}/admin/apply-interest", headers=_headers())
    console.print(r.json())

@admin.command("currency")
def admin_currency(
    currency_id: str = typer.Argument(..., help="Short ID e.g. GLD"),
    name:        str = typer.Argument(..., help="Full name e.g. Gold"),
    symbol:      str = typer.Argument(..., help="Symbol e.g. G"),
    supply_cap:  int = typer.Option(0,    help="Max supply (0 = unlimited)"),
):
    """Create a new virtual currency."""
    payload = {"currency_id": currency_id, "name": name, "symbol": symbol}
    if supply_cap > 0:
        payload["supply_cap"] = supply_cap
    r = httpx.post(f"{_base_url()}/admin/currency", json=payload, headers=_headers())
    console.print(r.json())

@admin.command("stats")
def admin_stats():
    """Show economy-wide stats."""
    r = httpx.get(f"{_base_url()}/analytics/stats")
    data = r.json()
    t = Table("Metric", "Value")
    t.add_row("Users",        str(data["user_count"]))
    t.add_row("Transactions", str(data["total_tx"]))
    t.add_row("Total debt",   str(data["total_debt"]))
    for cid, supply in data.get("supply_by_currency", {}).items():
        t.add_row(f"Supply ({cid})", str(supply))
    console.print(t)

@admin.command("richlist")
def admin_richlist(
    currency: str = typer.Argument(..., help="Currency ID"),
    limit:    int = typer.Option(10, help="Number of entries"),
):
    """Top holders for a currency."""
    r    = httpx.get(f"{_base_url()}/analytics/richlist/{currency}?limit={limit}")
    data = r.json()
    t    = Table("Rank", "User", "Balance")
    for i, row in enumerate(data["richlist"], 1):
        t.add_row(str(i), row["user_id"], f"{row['balance']:,}")
    console.print(t)

if __name__ == "__main__":
    app()