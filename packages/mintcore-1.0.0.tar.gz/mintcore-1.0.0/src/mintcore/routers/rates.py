import time
import httpx
from fastapi import APIRouter, HTTPException
from mintcore.database import get_db
from mintcore.models import ExchangeRate
from mintcore import config

router = APIRouter(prefix="/rate", tags=["rates"])
_cache: dict = {}

async def fetch_live_rate(base: str, target: str):
    key = f"{base}_{target}"
    now = time.time()
    if key in _cache and now - _cache[key]["time"] < config.CACHE_TTL:
        return _cache[key]["rate"], "cache"
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            res  = await client.get(config.LIVE_RATE_URL.format(base=base))
            res.raise_for_status()
            data = res.json()
            rate = data["rates"].get(target)
            if rate is None:
                return None, None
            _cache[key] = {"rate": rate, "time": now}
            return rate, "live"
    except (httpx.RequestError, httpx.HTTPStatusError, KeyError) as e:
        print(f"[rate fetch error] {base}/{target}: {e}")
        return None, None

@router.get("/{base}/{target}")
async def get_rate(base: str, target: str):
    rate, source = await fetch_live_rate(base.upper(), target.upper())
    if rate:
        return {"base": base, "target": target, "rate": rate, "source": source}
    with get_db() as db:
        stored = db.query(ExchangeRate).filter_by(
            base_currency=base.upper(), target_currency=target.upper()).first()
        if stored:
            return {"base": base, "target": target,
                    "rate": stored.rate, "source": "stored"}
    raise HTTPException(404, "Rate not found — set one via /admin/rates")