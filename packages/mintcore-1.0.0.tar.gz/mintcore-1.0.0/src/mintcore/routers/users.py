from fastapi import APIRouter, HTTPException
from mintcore.database import get_db
from mintcore.models import User, Wallet
from mintcore.schemas import CreateUser

router = APIRouter(prefix="/users", tags=["users"])

@router.post("")
def create_user(data: CreateUser):
    with get_db() as db:
        if db.query(User).filter_by(user_id=data.user_id).first():
            raise HTTPException(400, "User already exists")
        db.add(User(user_id=data.user_id))
        db.commit()
    return {"status": "created", "user_id": data.user_id}

@router.get("")
def list_users():
    with get_db() as db:
        users = db.query(User).all()
        return [{"user_id": u.user_id, "debt": u.debt} for u in users]

@router.get("/{user_id}/balance")
def get_balance(user_id: str):
    with get_db() as db:
        user = db.query(User).filter_by(user_id=user_id).first()
        if not user:
            raise HTTPException(404, "User not found")
        wallets = db.query(Wallet).filter_by(user_id=user_id).all()
        return {
            "user_id": user_id,
            "debt":    user.debt,
            "wallets": {w.currency_id: w.balance for w in wallets},
        }