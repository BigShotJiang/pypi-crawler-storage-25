from fastapi import APIRouter
from sqlalchemy import func
from mintcore.database import get_db
from mintcore.models import Wallet, Transaction, User
from datetime import datetime, timedelta

router = APIRouter(prefix="/analytics", tags=["analytics"])

@router.get("/supply")
def supply_by_currency():
    with get_db() as db:
        rows = db.query(Wallet.currency_id, func.sum(Wallet.balance))\
                 .group_by(Wallet.currency_id).all()
        return {"supply": {cid: total for cid, total in rows}}

@router.get("/velocity")
def transaction_velocity(hours: int = 24):
    since = datetime.utcnow() - timedelta(hours=hours)
    with get_db() as db:
        rows = db.query(Transaction.currency_id,
                        func.sum(Transaction.amount), func.count())\
                 .filter(Transaction.timestamp >= since)\
                 .group_by(Transaction.currency_id).all()
        return {"window_hours": hours, "velocity": {
            cid: {"volume": vol, "tx_count": count}
            for cid, vol, count in rows if cid
        }}

@router.get("/richlist/{currency_id}")
def richlist(currency_id: str, limit: int = 10):
    with get_db() as db:
        rows = db.query(Wallet.user_id, Wallet.balance)\
                 .filter(Wallet.currency_id == currency_id,
                         Wallet.user_id != "treasury")\
                 .order_by(Wallet.balance.desc()).limit(limit).all()
        return {"currency_id": currency_id,
                "richlist": [{"user_id": u, "balance": b} for u, b in rows]}

@router.get("/debt")
def debt_overview():
    with get_db() as db:
        users = db.query(User).filter(User.debt > 0).order_by(User.debt.desc()).all()
        return {"total_debt": sum(u.debt for u in users),
                "debtors": [{"user_id": u.user_id, "debt": u.debt} for u in users]}

@router.get("/stats")
def global_stats():
    with get_db() as db:
        supply_rows = db.query(Wallet.currency_id, func.sum(Wallet.balance))\
                       .group_by(Wallet.currency_id).all()
        return {
            "user_count":         db.query(User).count(),
            "total_debt":         db.query(func.sum(User.debt)).scalar() or 0,
            "total_tx":           db.query(Transaction).count(),
            "supply_by_currency": {cid: total for cid, total in supply_rows},
        }