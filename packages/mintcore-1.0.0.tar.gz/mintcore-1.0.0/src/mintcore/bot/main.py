"""
Entry point for the MintCore Discord bot.

Install:  pip install mintcore[bot]
Configure: mintcore init  (fills .env)
Run:       python -m mintcore.bot.main
"""
import os
import asyncio
import discord
from discord.ext import commands
from dotenv import load_dotenv
from mintcore.bot.client import close_client

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN not set — run `mintcore init` and fill in .env")

intents         = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

COGS = ["mintcore.bot.cogs.player", "mintcore.bot.cogs.admin"]

@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"[MintCore Bot] Logged in as {bot.user} — slash commands synced.")

@bot.event
async def on_disconnect():
    await close_client()

async def main():
    async with bot:
        for cog in COGS:
            await bot.load_extension(cog)
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())