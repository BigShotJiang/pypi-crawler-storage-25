"""Async HTTP client wrapping the MintCore REST API."""
import os
import httpx
from dotenv import load_dotenv

load_dotenv()

BASE_URL  = os.getenv("MINTCORE_URL",       "http://127.0.0.1:8000")
ADMIN_KEY = os.getenv("MINTCORE_ADMIN_KEY", "admin-secret")
HEADERS   = {"X-Admin-Key": ADMIN_KEY}

_client: httpx.AsyncClient | None = None

async def get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(base_url=BASE_URL, timeout=10.0)
    return _client

async def close_client():
    global _client
    if _client and not _client.is_closed:
        await _client.aclose()

async def _get(path):
    c = await get_client(); r = await c.get(path); r.raise_for_status(); return r.json()
async def _post(path, json=None, headers=None):
    c = await get_client(); r = await c.post(path, json=json, headers=headers or {}); r.raise_for_status(); return r.json()

async def get_balance(uid):        return await _get(f"/users/{uid}/balance")
async def ensure_user(uid):        return await _post("/users", {"user_id": uid})
async def get_ledger(uid):         return await _get(f"/ledger/{uid}")
async def get_rate(base, target):  return await _get(f"/rate/{base}/{target}")
async def get_stats():             return await _get("/analytics/stats")
async def get_richlist(cid, n=10): return await _get(f"/analytics/richlist/{cid}?limit={n}")

async def transfer(from_user, to_user, amount, currency_id):
    return await _post("/transactions/transfer",
        {"from_user": from_user, "to_user": to_user, "amount": amount, "currency_id": currency_id})

async def take_loan(user_id, amount, currency_id):
    return await _post("/admin/loan",
        {"user_id": user_id, "amount": amount, "currency_id": currency_id}, HEADERS)

async def repay_loan(user_id, amount, currency_id):
    return await _post("/repay",
        {"user_id": user_id, "amount": amount, "currency_id": currency_id})

async def admin_mint(to, amount, currency_id):
    return await _post("/admin/mint",
        {"to": to, "amount": amount, "currency_id": currency_id}, HEADERS)

async def admin_burn(from_user, amount, currency_id):
    return await _post("/admin/burn",
        {"from_user": from_user, "amount": amount, "currency_id": currency_id}, HEADERS)

async def admin_tax(percentage, currency_id):
    return await _post("/admin/tax",
        {"percentage": percentage, "currency_id": currency_id}, HEADERS)

async def admin_apply_interest():
    return await _post("/admin/apply-interest", headers=HEADERS)

async def admin_create_currency(currency_id, name, symbol, supply_cap=None):
    payload = {"currency_id": currency_id, "name": name, "symbol": symbol}
    if supply_cap: payload["supply_cap"] = supply_cap
    return await _post("/admin/currency", payload, HEADERS)