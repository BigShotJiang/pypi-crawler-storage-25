# Publishing MintCore to PyPI

## First time setup

1. Create accounts at https://pypi.org and https://test.pypi.org
2. Generate an API token at PyPI → Account settings → API tokens
3. Store it in `~/.pypirc`:

```ini
[pypi]
  username = __token__
  password = pypi-YOUR-TOKEN-HERE

[testpypi]
  username = __token__
  password = pypi-YOUR-TESTPYPI-TOKEN-HERE
```

## Build and publish

```bash
# Install build tools
pip install hatch twine

# Build wheel + sdist
hatch build
# → dist/mintcore-1.0.0-py3-none-any.whl
# → dist/mintcore-1.0.0.tar.gz

# Test on TestPyPI first
twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ mintcore

# Publish to real PyPI
twine upload dist/*
```

## Bump version for a new release

Edit `version` in `pyproject.toml` and `src/mintcore/__init__.py`,
then rebuild:

```bash
hatch build
twine upload dist/*
```