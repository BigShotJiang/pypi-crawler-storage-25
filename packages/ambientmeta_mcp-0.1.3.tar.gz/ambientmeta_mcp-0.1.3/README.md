# AmbientMeta MCP Server

MCP server that provides PII sanitization tools for Claude Desktop, Cursor, and any MCP-compatible client.

## Tools

| Tool | Description |
|------|-------------|
| `sanitize_text` | Detect and replace PII with safe placeholders. Returns session_id for rehydration. |
| `rehydrate_text` | Restore original values from placeholders using a session_id. |
| `check_pii` | Scan text for PII without modifying it. |

## Setup

### Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "ambientmeta": {
      "command": "uvx",
      "args": ["ambientmeta-mcp"],
      "env": {
        "AMBIENTMETA_API_KEY": "am_your_api_key_here"
      }
    }
  }
}
```

### Cursor

Add to your MCP server configuration:

```json
{
  "ambientmeta": {
    "command": "uvx",
    "args": ["ambientmeta-mcp"],
    "env": {
      "AMBIENTMETA_API_KEY": "am_your_api_key_here"
    }
  }
}
```

### From source

```bash
cd mcp-server
pip install -e .
AMBIENTMETA_API_KEY=am_xxx ambientmeta-mcp
```

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AMBIENTMETA_API_KEY` | Yes | — | Your AmbientMeta API key |
| `AMBIENTMETA_BASE_URL` | No | `https://api.ambientmeta.com` | API base URL (for self-hosted) |

## Usage

Once configured, the tools are available in your MCP client:

1. **Before sending text to AI:** Use `sanitize_text` to replace PII with placeholders
2. **After receiving AI response:** Use `rehydrate_text` to restore original values
3. **To check for PII:** Use `check_pii` to scan without modifying

Session IDs are valid for 24 hours.
