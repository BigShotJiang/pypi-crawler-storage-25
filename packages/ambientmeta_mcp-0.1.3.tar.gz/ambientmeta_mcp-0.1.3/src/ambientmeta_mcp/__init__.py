"""AmbientMeta MCP Server — PII sanitization tools for Claude Desktop, Cursor, and MCP clients."""

from ambientmeta_mcp.server import main

__all__ = ["main"]
