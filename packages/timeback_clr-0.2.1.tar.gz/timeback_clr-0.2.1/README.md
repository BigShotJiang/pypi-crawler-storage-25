# timeback-clr

Timeback CLR (Comprehensive Learner Record) client for Python.

Provides an async client for managing CLR v2.0 verifiable credentials and API discovery.

## Installation

```bash
pip install timeback-clr
```

## Quick Start

```python
from timeback_clr import ClrClient

async with ClrClient(env="staging", client_id="...", client_secret="...") as client:
    # Upsert a CLR credential
    result = await client.credentials.upsert(credential)

    # Get API discovery information
    discovery = await client.discovery.get()
```
