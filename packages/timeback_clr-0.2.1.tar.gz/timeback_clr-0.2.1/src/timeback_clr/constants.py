"""
CLR Constants

Configuration constants for the CLR client.
"""

SERVICE_NAME = "clr"
