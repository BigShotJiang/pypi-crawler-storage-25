"""
Timeback CLR Client

A Python client for CLR (Comprehensive Learner Record) v2.0 operations.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("timeback-clr")
except PackageNotFoundError:
    __version__ = "0.0.0"

from .client import ClrClient
from .exceptions import (
    APIError,
    AuthenticationError,
    ClrError,
    ForbiddenError,
    InputValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    create_input_validation_error,
)
from .types import (
    ACHIEVEMENT_TYPES,
    Achievement,
    AchievementCriteria,
    AchievementType,
    Association,
    AssociationType,
    ClrCredential,
    ClrCredentialInput,
    ClrCredentialSchema,
    ClrCredentialSubject,
    ClrImage,
    ClrProfile,
    ClrProof,
    DiscoveryResponse,
    IdentityObject,
    NestedCredentialSubject,
    VerifiableCredential,
)

__all__ = [
    "ACHIEVEMENT_TYPES",
    "APIError",
    "Achievement",
    "AchievementCriteria",
    "AchievementType",
    "Association",
    "AssociationType",
    "AuthenticationError",
    "ClrClient",
    "ClrCredential",
    "ClrCredentialInput",
    "ClrCredentialSchema",
    "ClrCredentialSubject",
    "ClrError",
    "ClrImage",
    "ClrProfile",
    "ClrProof",
    "DiscoveryResponse",
    "ForbiddenError",
    "IdentityObject",
    "InputValidationError",
    "NestedCredentialSubject",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "VerifiableCredential",
    "__version__",
    "create_input_validation_error",
]
