"""
CLR Response Types

Pydantic models for CLR API responses.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ClrImage(BaseModel):
    """Image reference."""

    id: str
    type: str = "Image"
    caption: str | None = None


class ClrProfile(BaseModel):
    """Profile (issuer or creator)."""

    id: str
    type: list[str]
    name: str | None = None
    url: str | None = None
    phone: str | None = None
    description: str | None = None
    image: ClrImage | None = None
    email: str | None = None


class ClrProof(BaseModel):
    """Cryptographic proof."""

    type: str
    proof_purpose: str = Field(alias="proofPurpose")
    verification_method: str = Field(alias="verificationMethod")
    created: str
    proof_value: str = Field(alias="proofValue")
    cryptosuite: str | None = None

    model_config = {"populate_by_name": True}


class ClrCredentialSchema(BaseModel):
    """Credential schema reference."""

    id: str
    type: str


class AchievementCriteria(BaseModel):
    """Achievement criteria."""

    id: str | None = None
    narrative: str | None = None


class Achievement(BaseModel):
    """Achievement."""

    id: str
    type: list[str]
    name: str
    description: str
    criteria: AchievementCriteria
    image: ClrImage | None = None
    achievement_type: str | None = Field(None, alias="achievementType")
    creator: ClrProfile | None = None

    model_config = {"populate_by_name": True}


class IdentityObject(BaseModel):
    """Identity object for the credential subject."""

    type: str
    identity_hash: str = Field(alias="identityHash")
    identity_type: str = Field(alias="identityType")
    hashed: bool
    salt: str | None = None

    model_config = {"populate_by_name": True}


class Association(BaseModel):
    """Association between achievements or credentials."""

    type: str
    association_type: str = Field(alias="associationType")
    source_id: str = Field(alias="sourceId")
    target_id: str = Field(alias="targetId")

    model_config = {"populate_by_name": True}


class NestedCredentialSubject(BaseModel):
    """Credential subject for nested verifiable credentials."""

    id: str | None = None


class VerifiableCredential(BaseModel):
    """Nested verifiable credential within a CLR."""

    context: list[str] = Field(alias="@context")
    id: str
    type: list[str]
    issuer: ClrProfile
    valid_from: str = Field(alias="validFrom")
    valid_until: str | None = Field(None, alias="validUntil")
    credential_subject: NestedCredentialSubject = Field(alias="credentialSubject")
    proof: list[ClrProof] | None = None

    model_config = {"populate_by_name": True}


class ClrCredentialSubject(BaseModel):
    """Credential subject containing achievements and nested credentials."""

    id: str | None = None
    type: list[str]
    identifier: list[IdentityObject] | None = None
    achievement: list[Achievement] | None = None
    verifiable_credential: list[VerifiableCredential] = Field(alias="verifiableCredential")
    association: list[Association] | None = None

    model_config = {"populate_by_name": True}


class ClrCredential(BaseModel):
    """Top-level CLR Credential response model."""

    context: list[str] = Field(alias="@context")
    id: str
    type: list[str]
    issuer: ClrProfile
    name: str
    description: str | None = None
    valid_from: str = Field(alias="validFrom")
    valid_until: str | None = Field(None, alias="validUntil")
    credential_subject: ClrCredentialSubject = Field(alias="credentialSubject")
    proof: list[ClrProof] | None = None
    credential_schema: list[ClrCredentialSchema] | None = Field(None, alias="credentialSchema")

    model_config = {"populate_by_name": True}


# Discovery response is a dynamic OpenAPI spec object
DiscoveryResponse = dict[str, Any]
