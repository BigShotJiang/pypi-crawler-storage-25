"""Recording transport for fixture-driven CLR tests."""

from __future__ import annotations

from typing import Any

from test_support.transport_base import BaseRecordingTransport
from test_support.transport_helpers import dump_model
from timeback_common import ClrPaths

from ..types.responses import ClrCredential


def create_recording_transport(
    fail_request: dict[str, Any] | None = None,
    transport_config: dict[str, Any] | None = None,
) -> BaseRecordingTransport:
    """Create a transport-like object that records calls and returns stub responses."""
    return _ClrRecordingTransport(fail_request=fail_request, transport_config=transport_config)


class _ClrRecordingTransport(BaseRecordingTransport):
    """CLR-specific recording transport with CLR paths and stubs."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.paths = ClrPaths()
        self._apply_exclude_paths()

    def _default_get_stub(self, path: str) -> dict[str, Any]:  # noqa: ARG002
        return {"openapi": "3.0.0", "info": {"title": "CLR v2.0", "version": "2.0"}}

    def _default_post_stub(self, path: str) -> dict[str, Any]:  # noqa: ARG002
        return dump_model(_stub_credential())


def _stub_credential() -> ClrCredential:
    return ClrCredential.model_validate(
        {
            "@context": ["https://www.w3.org/ns/credentials/v2"],
            "id": "urn:uuid:stub-credential",
            "type": ["VerifiableCredential", "ClrCredential"],
            "issuer": {"id": "https://example.edu", "type": ["Profile"], "name": "Stub University"},
            "name": "Stub Credential",
            "validFrom": "2024-01-01T00:00:00Z",
            "credentialSubject": {
                "type": ["ClrSubject"],
                "verifiableCredential": [
                    {
                        "@context": ["https://www.w3.org/ns/credentials/v2"],
                        "id": "urn:uuid:stub-nested",
                        "type": ["VerifiableCredential"],
                        "issuer": {"id": "https://example.edu", "type": ["Profile"]},
                        "validFrom": "2024-01-01T00:00:00Z",
                        "credentialSubject": {},
                    }
                ],
            },
        }
    )
