"""
Discovery Resource

CLR v2.0 API discovery endpoint.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..lib.transport import Transport
    from ..types.responses import DiscoveryResponse


class DiscoveryResource:
    """
    Discovery resource for CLR API capabilities.

    Provides access to the CLR v2.0 API discovery endpoint,
    which returns the OpenAPI specification including available
    endpoints, OAuth2 flows, and supported scopes.
    """

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def get(self) -> DiscoveryResponse:
        """
        Get CLR v2.0 API discovery information.

        Returns the OpenAPI 3.0 specification for the CLR v2.0 API,
        allowing clients to dynamically discover the service's capabilities.

        Returns:
            Discovery information (OpenAPI spec object)
        """
        return await self._transport.get(
            f"{self._transport.paths.discovery}/",
        )
