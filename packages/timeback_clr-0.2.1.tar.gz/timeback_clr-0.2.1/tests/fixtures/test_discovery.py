"""Fixture-driven tests for CLR discovery resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_clr.lib.testing import create_recording_transport
from timeback_clr.resources.discovery import DiscoveryResource

FIXTURES_DIR = fixtures_dir("clr", "discovery")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": DiscoveryResource(transport), "calls": transport.calls}


test_clr_discovery_fixtures = make_resource_fixture_test(
    name="clr > discovery",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
