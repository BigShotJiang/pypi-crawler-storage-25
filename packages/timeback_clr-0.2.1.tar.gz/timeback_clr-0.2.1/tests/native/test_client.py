"""Tests for ClrClient initialization and configuration."""

import os
from unittest.mock import patch

import pytest

from timeback_clr import ClrClient


class TestClrClientInit:
    """Tests for client initialization."""

    def test_staging_environment(self):
        """Staging environment should use staging URL."""
        client = ClrClient(env="staging", client_id="id", client_secret="secret")
        assert client._transport.base_url is not None

    def test_production_environment(self):
        """Production environment should use production URL."""
        client = ClrClient(env="production", client_id="id", client_secret="secret")
        assert "dev" not in client._transport.base_url
        assert "staging" not in client._transport.base_url

    def test_custom_base_url(self):
        """Custom base URL should override environment."""
        client = ClrClient(
            base_url="https://custom.example.com",
            auth_url="https://auth.example.com/oauth2/token",
            client_id="id",
            client_secret="secret",
        )
        assert client._transport.base_url == "https://custom.example.com"

    def test_explicit_credentials(self):
        """Explicit credentials should work."""
        client = ClrClient(
            env="staging",
            client_id="my-id",
            client_secret="my-secret",
        )
        assert client._provider is not None
        tm = client._provider.get_token_manager("clr")
        assert tm is not None
        assert tm._config.client_id == "my-id"
        assert tm._config.client_secret == "my-secret"

    def test_missing_credentials_raises(self):
        """Missing credentials should raise ValueError."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("CLR_CLIENT_ID", None)
            os.environ.pop("CLR_CLIENT_SECRET", None)
            os.environ.pop("TIMEBACK_API_CLIENT_ID", None)
            os.environ.pop("TIMEBACK_API_CLIENT_SECRET", None)
            os.environ.pop("TIMEBACK_CLIENT_ID", None)
            os.environ.pop("TIMEBACK_CLIENT_SECRET", None)
            with pytest.raises(ValueError, match="Missing required environment variable"):
                ClrClient(env="staging")

    def test_default_platform_is_beyond_ai(self):
        """Default platform should be BEYOND_AI."""
        client = ClrClient(env="staging", client_id="id", client_secret="secret")
        assert client._transport.base_url is not None

    def test_beyond_ai_platform(self):
        """BEYOND_AI platform should succeed."""
        client = ClrClient(
            platform="BEYOND_AI",
            env="staging",
            client_id="id",
            client_secret="secret",
        )
        assert client._transport.base_url is not None

    def test_custom_provider(self):
        """Custom base URL and auth should work."""
        client = ClrClient(
            base_url="https://custom.api.com",
            auth_url="https://custom.auth.com/token",
            client_id="test-id",
            client_secret="test-secret",
        )
        assert client._transport.base_url == "https://custom.api.com"


class TestClrClientTransport:
    """Tests for transport access."""

    def test_get_transport(self):
        """Client should expose transport via get_transport()."""
        client = ClrClient(env="staging", client_id="id", client_secret="secret")

        transport = client.get_transport()
        assert transport is not None
        assert transport.base_url is not None

    def test_transport_has_clr_paths(self):
        """Transport should have CLR-specific paths."""
        client = ClrClient(env="staging", client_id="id", client_secret="secret")

        transport = client.get_transport()
        assert hasattr(transport, "paths")
        assert "/ims/clr/v2p0/credentials" in transport.paths.credentials
        assert "/ims/clr/v2p0/discovery" in transport.paths.discovery


class TestClrClientCheckAuth:
    """Tests for check_auth."""

    @pytest.mark.asyncio
    async def test_check_auth_raises_without_provider(self):
        """check_auth should raise when no provider is set (custom transport)."""
        from timeback_common import ClrPaths

        class MockTransport:
            base_url = "https://mock.api.com"
            paths = ClrPaths()

            async def close(self) -> None:
                pass

        client = ClrClient(transport=MockTransport())

        with pytest.raises(RuntimeError, match="Cannot check auth"):
            await client.check_auth()

    def test_custom_transport_without_paths_raises(self):
        """Custom transport without paths should raise TypeError."""

        class BadTransport:
            base_url = "https://mock.api.com"

            async def close(self) -> None:
                pass

        with pytest.raises(TypeError, match="paths"):
            ClrClient(transport=BadTransport())


class TestClrClientPlatformSupport:
    """Tests for platform-specific behavior."""

    def test_learnwith_ai_platform_raises(self):
        """LearnWith.AI platform should raise (CLR not supported on LearnWith.AI)."""
        with pytest.raises(ValueError, match=r"not configured|not supported"):
            ClrClient(
                platform="LEARNWITH_AI",
                env="staging",
                client_id="id",
                client_secret="secret",
            )

    def test_learnwith_ai_path_profile_raises(self):
        """Custom provider with LearnWith.AI pathProfile should raise (CLR paths are None)."""
        from timeback_common import TimebackProvider

        provider = TimebackProvider(
            base_url="https://custom.api.com",
            auth_url="https://custom.auth.com/token",
            client_id="id",
            client_secret="secret",
            path_profile="LEARNWITH_AI",
        )
        with pytest.raises(ValueError, match=r"not supported"):
            ClrClient(provider=provider)

    def test_learnwith_ai_path_profile_with_custom_clr_paths_succeeds(self):
        """LearnWith.AI pathProfile with custom CLR paths should succeed."""
        from timeback_common import ClrPaths, TimebackProvider

        provider = TimebackProvider(
            base_url="https://custom.api.com",
            auth_url="https://custom.auth.com/token",
            client_id="id",
            client_secret="secret",
            path_profile="LEARNWITH_AI",
            paths={"clr": ClrPaths()},
        )
        client = ClrClient(provider=provider)
        assert client._transport.base_url == "https://custom.api.com"


class TestClrClientContextManager:
    """Tests for context manager support."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Client should work as async context manager."""
        async with ClrClient(env="staging", client_id="id", client_secret="secret") as client:
            assert client._provider is not None
