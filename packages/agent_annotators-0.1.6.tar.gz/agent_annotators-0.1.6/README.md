# agent-annotators

A reusable Python library for annotating agent, tool, and execution traces.

## Installation
```bash
pip install -e .
