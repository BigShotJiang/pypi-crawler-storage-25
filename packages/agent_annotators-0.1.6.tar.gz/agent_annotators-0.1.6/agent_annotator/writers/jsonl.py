import json
import os
from typing import Dict, Any


class JSONLWriter:
    """
    Writes annotation records to a JSONL file.
    Each execution record is written as ONE JSON object per line.
    """

    def __init__(self, file_path: str, indent: int = 2):
        """
        :param file_path: Path to the .jsonl file
        :param indent: JSON indentation (default = 2 for readable output)
        """
        self.file_path = file_path
        self.indent = indent

        # Ensure directory exists
        dir_path = os.path.dirname(file_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)

    def write(self, record: Dict[str, Any]) -> None:
        """
        Write a single execution record to the JSONL file.
        """
        with open(self.file_path, "a", encoding="utf-8") as f:
            f.write(
                json.dumps(record, ensure_ascii=False, indent=self.indent)
                + "\n"
            )