import time
from typing import Any, Dict, Optional
from agent_annotator.writers import JSONLWriter


class ExecutionCollector:
    """
    Core execution collector for the annotators library.

    Responsibilities:
    - Maintain a single execution record
    - Track run-level, agent-level, and tool-level executions
    - Compute execution timings
    - Remain framework-agnostic
    """

    def __init__(self) -> None:
        self.writer = JSONLWriter("actual_output.jsonl")
        self.reset()

    # --------------------------------------------------
    # Reset
    # --------------------------------------------------
    def reset(self) -> None:
        self.record: Dict[str, Any] = {
            "testcaseId": None,
            "execution": {
                "type": None,
                "target": None,
                "status": None,
                "error": None,
                "execution_time": None,
            },
            "request": {},
            "response": {},
            "agentCall": [],
        }

        self._run_start: Optional[float] = None
        self._current_agent: Optional[Dict[str, Any]] = None

    # --------------------------------------------------
    # Run-level
    # --------------------------------------------------
    def start_run(
            self,
            testcase_id: str,
            execution_type: str = "api",
            target: Optional[str] = None,
    ) -> None:
        self.reset()
        self.record["testcaseId"] = testcase_id
        self._run_start = time.time()

        self.record["execution"]["type"] = execution_type
        self.record["execution"]["target"] = target

    def end_run(
            self,
            status: str,
            error: Optional[str] = None,
    ) -> None:
        if self._run_start is None:
            return

        execution_time = int((time.time() - self._run_start) * 1000)

        self.record["execution"]["status"] = status
        self.record["execution"]["error"] = error
        self.record["execution"]["execution_time"] = execution_time

        if self.writer:
            self.writer.write(self.record)

    # --------------------------------------------------
    # Agent-level
    # --------------------------------------------------
    def start_agent(self, name: str, input_data: Any) -> None:
        agent: Dict[str, Any] = {
            "agentName": name,
            "order": len(self.record["agentCall"]) + 1,
            "input": input_data,
            "output": None,
            "execution": {
                "status": None,
                "error": None,
                "execution_time": None,
            },
            "toolCall": [],
        }

        agent["_start"] = time.time()
        self.record["agentCall"].append(agent)
        self._current_agent = agent

    def end_agent(
            self,
            output: Any,
            status: str,
            error: Optional[str] = None,
    ) -> None:
        if self._current_agent is None:
            return

        start_time = self._current_agent.get("_start")
        if start_time is None:
            return

        execution_time = int((time.time() - start_time) * 1000)

        self._current_agent["output"] = output
        self._current_agent["execution"]["status"] = status
        self._current_agent["execution"]["error"] = error
        self._current_agent["execution"]["execution_time"] = execution_time

        self._current_agent.pop("_start")
        self._current_agent = None

    # --------------------------------------------------
    # Tool-level
    # --------------------------------------------------
    def add_tool(
            self,
            name: str,
            input_data: Any,
            output: Any,
            start_time: float,
            status: str,
            error: Optional[str] = None,
    ) -> None:
        if self._current_agent is None:
            return

        execution_time = int((time.time() - start_time) * 1000)

        tool_entry = {
            "toolName": name,
            "order": len(self._current_agent["toolCall"]) + 1,
            "input": input_data,
            "output": output,
            "execution": {
                "status": status,
                "error": error,
                "execution_time": execution_time,
            },
        }

        self._current_agent["toolCall"].append(tool_entry)
