import functools
import time
from typing import Any, Optional

from agent_annotator.collector import ExecutionCollector
from agent_annotator.utils import normalize_input
from agent_annotator.context import testcase_id_ctx

# One collector per execution context
collector = ExecutionCollector()


# ==========================================================
# RUN LEVEL DECORATOR
# Name MUST be exactly: observe
# ==========================================================
def observe(execution_type: str = "api", target: Optional[str] = None):
    """
    Observes a full execution run.
    testcaseId MUST be set in ContextVar before execution.
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):

            testcase_id = testcase_id_ctx.get()
            if not testcase_id:
                raise RuntimeError(
                    "testcaseId not set in ContextVar. "
                    "Use testcase_id_ctx.set('TC_001') before calling."
                )

            # Start run only once
            if collector._run_start is None:
                collector.start_run(
                    testcase_id=testcase_id,
                    execution_type=execution_type,
                    target=target
                )

            run_status = "success"
            run_error = None

            try:
                result = func(*args, **kwargs)
                return result

            except Exception as e:
                run_status = "failed"
                run_error = str(e)
                raise

            finally:
                collector.end_run(
                    status=run_status,
                    error=run_error
                )

        return wrapper
    return decorator


# ==========================================================
# AGENT LEVEL DECORATOR
# Name MUST be exactly: observe_agent
# ==========================================================
def observe_agent(func):
    """
    Observes an agent execution.
    Supports multiple agents per run.
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):

        collector.start_agent(
            name=func.__name__,
            input_data=normalize_input(args, kwargs)
        )

        try:
            result = func(*args, **kwargs)

            collector.end_agent(
                output=result,
                status="success",
                error=None
            )
            return result

        except Exception as e:
            collector.end_agent(
                output=None,
                status="failed",
                error=str(e)
            )
            raise

    return wrapper


# ==========================================================
# TOOL LEVEL DECORATOR
# Name MUST be exactly: observe_tool
# ==========================================================
def observe_tool(func):
    """
    Observes tool execution inside an agent.
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()

        try:
            result = func(*args, **kwargs)

            collector.add_tool(
                name=func.__name__,
                input_data=normalize_input(args, kwargs),
                output=result,
                start_time=start_time,
                status="success",
                error=None
            )
            return result

        except Exception as e:
            collector.add_tool(
                name=func.__name__,
                input_data=normalize_input(args, kwargs),
                output=None,
                start_time=start_time,
                status="failed",
                error=str(e)
            )
            raise

    return wrapper