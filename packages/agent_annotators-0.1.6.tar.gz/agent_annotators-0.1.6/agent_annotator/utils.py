from typing import Any, Tuple, Dict


def normalize_input(
    args: Tuple[Any, ...],
    kwargs: Dict[str, Any]
) -> Any:
    """
    Normalize function inputs into a clean, human-readable form
    for annotation datasets.

    Rules:
    - If positional arguments exist, return ONLY the first one.
      (Primary semantic input, e.g., order_id, user_query)
    - Else if kwargs exist, return kwargs
    - Else return None

    This avoids leaking internal arguments (like helper data)
    into the dataset while keeping the library generic.
    """
    if args:
        return args[0]

    if kwargs:
        return kwargs

    return None