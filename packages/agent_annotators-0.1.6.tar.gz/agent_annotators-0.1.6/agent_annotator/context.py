from contextvars import ContextVar
from typing import Optional

# Stores testcaseId for the current execution context
testcase_id_ctx: ContextVar[Optional[str]] = ContextVar(
    "testcase_id",
    default=None
)
