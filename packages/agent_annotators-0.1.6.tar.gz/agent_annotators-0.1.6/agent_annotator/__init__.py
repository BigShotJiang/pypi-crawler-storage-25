"""
agent_annotator

Reusable annotators library for recording
execution, agent, and tool traces.
"""

from agent_annotator.collector import ExecutionCollector
from agent_annotator.decorators import observe, observe_agent, observe_tool
from agent_annotator.context import testcase_id_ctx

__all__ = [
    "ExecutionCollector",
    "observe",
    "observe_agent",
    "observe_tool",
    "testcase_id_ctx",
]

__version__ = "0.1.6"
