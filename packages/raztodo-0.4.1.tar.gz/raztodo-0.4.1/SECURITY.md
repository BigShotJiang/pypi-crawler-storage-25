# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| 0.4.x   | ✅ |
| 0.3.x   | ❌ |
| 0.2.x   | ❌ |
| 0.1.x   | ❌ |

## Reporting a Vulnerability

If you discover a security vulnerability, please:

1. **Do NOT** open a public issue
2. Email the maintainer directly at: `real.raz.dev@gmail.com`
3. Include a detailed description of the vulnerability
4. Allow up to 48 hours for an initial response

We take security seriously and will address valid reports promptly.
