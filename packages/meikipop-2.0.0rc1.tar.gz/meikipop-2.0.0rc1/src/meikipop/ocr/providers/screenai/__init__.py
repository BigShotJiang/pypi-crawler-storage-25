from .provider import ScreenAiOcr
