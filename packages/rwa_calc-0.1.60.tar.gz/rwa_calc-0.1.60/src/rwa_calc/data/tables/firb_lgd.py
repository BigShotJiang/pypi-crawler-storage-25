"""
F-IRB supervisory LGD values — CRR Art. 161 and PRA PS1/26 Art. 161 / CRE32.

Canonical home for both the CRR and Basel 3.1 Foundation IRB supervisory LGD
tables, plus the CRR Art. 230 / CRE32.9-12 overcollateralisation ratios and
minimum thresholds (identical under both frameworks). Framework selection
happens at the call site via ``CalculationConfig`` or the ``is_basel_3_1``
flag on the lookup helpers.

Reference:
    CRR Art. 161: LGD for Foundation IRB approach (CRR values)
    PRA PS1/26 Art. 161 / CRE32.9-12: Basel 3.1 revised supervisory LGDs
    CRR Art. 230 / CRE32.9-12: Overcollateralisation requirements
"""

from __future__ import annotations

from decimal import Decimal

import polars as pl

# =============================================================================
# F-IRB SUPERVISORY LGD VALUES (CRR Art. 161)
# =============================================================================

# Supervisory LGD values by seniority and collateral type
# CRR values (Art. 161)
FIRB_SUPERVISORY_LGD: dict[str, Decimal] = {
    # Unsecured exposures — Art. 161(1)(a): all senior unsecured (no FSE split under CRR)
    "unsecured_senior": Decimal("0.45"),  # 45% for senior unsecured
    "subordinated": Decimal("0.75"),  # 75% for subordinated (Art. 161(1)(b))
    # Covered bonds — Art. 161(1)(d)
    "covered_bond": Decimal("0.1125"),  # 11.25%
    # Fully secured by eligible financial collateral
    "financial_collateral": Decimal("0.00"),  # 0% (after haircuts)
    # Secured by receivables — Art. 230 Table 5 (senior)
    "receivables": Decimal("0.35"),  # 35%
    # Secured by real estate — Art. 230 Table 5 (senior)
    "residential_re": Decimal("0.35"),  # 35% for residential RE
    "commercial_re": Decimal("0.35"),  # 35% for commercial RE
    # Secured by other physical collateral — Art. 230 Table 5 (senior)
    "other_physical": Decimal("0.40"),  # 40% for other physical
    # CRR Art. 230 Table 5 subordinated LGDS (secured portion of subordinated claims)
    "financial_collateral_subordinated": Decimal("0.00"),  # 0% (same as senior)
    "receivables_subordinated": Decimal("0.65"),  # 65% (senior: 35%)
    "residential_re_subordinated": Decimal("0.65"),  # 65% (senior: 35%)
    "commercial_re_subordinated": Decimal("0.65"),  # 65% (senior: 35%)
    "other_physical_subordinated": Decimal("0.70"),  # 70% (senior: 40%)
}

# Basel 3.1 revised supervisory LGD values (CRE32.9-12, PRA PS1/26)
# Key changes from CRR: non-FSE senior 45%→40%, FSE senior stays 45%,
# receivables 35%→20%, RE 35%→20%, other physical 40%→25%,
# covered bonds added at 11.25%
BASEL31_FIRB_SUPERVISORY_LGD: dict[str, Decimal] = {
    # Unsecured exposures — Art. 161(1)(aa): non-FSE corporates
    "unsecured_senior": Decimal("0.40"),  # 40% (CRR: 45%)
    # Unsecured exposures — Art. 161(1)(a): financial sector entities (FSE)
    "unsecured_senior_fse": Decimal("0.45"),  # 45% (unchanged from CRR)
    "subordinated": Decimal("0.75"),  # 75% (unchanged)
    # Covered bonds — Art. 161(1)(d)
    "covered_bond": Decimal("0.1125"),  # 11.25%
    # Fully secured by eligible financial collateral
    "financial_collateral": Decimal("0.00"),  # 0% (unchanged)
    # Secured by receivables
    "receivables": Decimal("0.20"),  # 20% (CRR: 35%)
    # Secured by real estate
    "residential_re": Decimal("0.20"),  # 20% (CRR: 35%)
    "commercial_re": Decimal("0.20"),  # 20% (CRR: 35%)
    # Secured by other physical collateral
    "other_physical": Decimal("0.25"),  # 25% (CRR: 40%)
}


def get_firb_lgd_table_for_framework(is_basel_3_1: bool = False) -> dict[str, Decimal]:
    """Get the F-IRB supervisory LGD table for the given framework.

    Args:
        is_basel_3_1: True for Basel 3.1 values, False for CRR values

    Returns:
        Dictionary of collateral_type -> supervisory LGD
    """
    return BASEL31_FIRB_SUPERVISORY_LGD if is_basel_3_1 else FIRB_SUPERVISORY_LGD


# =============================================================================
# F-IRB OVERCOLLATERALISATION REQUIREMENTS (CRR Art. 230 / CRE32.9-12)
# =============================================================================

# Overcollateralisation ratios: collateral must cover this multiple of EAD
# for the full reduced LGD to apply. effectively_secured = value / ratio.
FIRB_OVERCOLLATERALISATION_RATIOS: dict[str, float] = {
    "financial": 1.0,  # No overcollateralisation required
    "receivables": 1.25,  # 125% overcollateralisation
    "real_estate": 1.40,  # 140% overcollateralisation
    "other_physical": 1.40,  # 140% overcollateralisation
    "life_insurance": 1.0,  # Art. 232: no overcollateralisation required
}

# Minimum collateralisation thresholds: if collateral value is below this
# fraction of EAD, non-financial collateral is ignored entirely.
FIRB_MIN_COLLATERALISATION_THRESHOLDS: dict[str, float] = {
    "financial": 0.0,  # No minimum threshold
    "receivables": 0.0,  # No minimum threshold
    "real_estate": 0.30,  # 30% minimum threshold
    "other_physical": 0.30,  # 30% minimum threshold
    "life_insurance": 0.0,  # Art. 232: no minimum collateralisation threshold
}

# PD floor under CRR (single floor for all classes)
CRR_PD_FLOOR: Decimal = Decimal("0.0003")  # 0.03%

# Maturity parameters
CRR_MATURITY_FLOOR: Decimal = Decimal("1.0")  # 1 year minimum
CRR_MATURITY_CAP: Decimal = Decimal("5.0")  # 5 year maximum

# IRB K scaling factor (CRR Art. 153(1)). Removed under Basel 3.1 (set to 1.0).
# Used in CRR-vs-B31 attribution math to isolate the scaling-factor delta.
CRR_K_SCALING_FACTOR: Decimal = Decimal("1.06")


# =============================================================================
# DATAFRAME ROW SPECIFICATIONS
#
# Each row-spec tuple names the dict keys from which the LGD, OC ratio, and
# min threshold are looked up. Row ordering is part of the DataFrame contract
# and must be preserved.
# =============================================================================

# CRR spec tuple fields:
#   (collateral_type, seniority, lgd_key, oc_key, description)
_FirbRowSpec = tuple[str, str, str, str, str]

_CRR_FIRB_ROW_SPECS: tuple[_FirbRowSpec, ...] = (
    # Unsecured exposures
    ("unsecured", "senior", "unsecured_senior", "financial", "Unsecured senior claims"),
    ("unsecured", "subordinated", "subordinated", "financial", "Subordinated claims"),
    # Financial collateral (eligible)
    (
        "financial_collateral",
        "senior",
        "financial_collateral",
        "financial",
        "Eligible financial collateral (after haircuts)",
    ),
    ("cash", "senior", "financial_collateral", "financial", "Cash collateral"),
    # Receivables — Art. 230 Table 5
    (
        "receivables",
        "senior",
        "receivables",
        "receivables",
        "Secured by receivables (senior)",
    ),
    (
        "receivables",
        "subordinated",
        "receivables_subordinated",
        "receivables",
        "Secured by receivables (subordinated)",
    ),
    # Real estate — Art. 230 Table 5
    (
        "residential_re",
        "senior",
        "residential_re",
        "real_estate",
        "Secured by residential real estate (senior)",
    ),
    (
        "residential_re",
        "subordinated",
        "residential_re_subordinated",
        "real_estate",
        "Secured by residential real estate (subordinated)",
    ),
    (
        "commercial_re",
        "senior",
        "commercial_re",
        "real_estate",
        "Secured by commercial real estate (senior)",
    ),
    (
        "commercial_re",
        "subordinated",
        "commercial_re_subordinated",
        "real_estate",
        "Secured by commercial real estate (subordinated)",
    ),
    (
        "real_estate",
        "senior",
        "residential_re",
        "real_estate",
        "Secured by real estate (general, senior)",
    ),
    (
        "real_estate",
        "subordinated",
        "residential_re_subordinated",
        "real_estate",
        "Secured by real estate (general, subordinated)",
    ),
    # Other physical collateral — Art. 230 Table 5
    (
        "other_physical",
        "senior",
        "other_physical",
        "other_physical",
        "Other eligible physical collateral (senior)",
    ),
    (
        "other_physical",
        "subordinated",
        "other_physical_subordinated",
        "other_physical",
        "Other eligible physical collateral (subordinated)",
    ),
)


# Basel 3.1 spec tuple fields:
#   (collateral_type, seniority, is_fse, lgd_key, oc_key, description)
_B31FirbRowSpec = tuple[str, str, bool, str, str, str]

_B31_FIRB_ROW_SPECS: tuple[_B31FirbRowSpec, ...] = (
    # Unsecured — non-FSE (Art. 161(1)(aa))
    (
        "unsecured",
        "senior",
        False,
        "unsecured_senior",
        "financial",
        "Unsecured senior claims — non-FSE (Art. 161(1)(aa))",
    ),
    # Unsecured — FSE (Art. 161(1)(a))
    (
        "unsecured",
        "senior",
        True,
        "unsecured_senior_fse",
        "financial",
        "Unsecured senior claims — FSE (Art. 161(1)(a))",
    ),
    # Subordinated — unchanged
    (
        "unsecured",
        "subordinated",
        False,
        "subordinated",
        "financial",
        "Subordinated claims (Art. 161(1)(b))",
    ),
    # Covered bonds — Art. 161(1B)
    (
        "covered_bond",
        "senior",
        False,
        "covered_bond",
        "financial",
        "Covered bonds (Art. 161(1B))",
    ),
    # Financial collateral — unchanged
    (
        "financial_collateral",
        "senior",
        False,
        "financial_collateral",
        "financial",
        "Eligible financial collateral (after haircuts)",
    ),
    (
        "cash",
        "senior",
        False,
        "financial_collateral",
        "financial",
        "Cash collateral",
    ),
    # Receivables — reduced (CRE32.9)
    (
        "receivables",
        "senior",
        False,
        "receivables",
        "receivables",
        "Secured by receivables (CRR: 35%)",
    ),
    # Real estate — reduced (CRE32.10-11)
    (
        "residential_re",
        "senior",
        False,
        "residential_re",
        "real_estate",
        "Secured by residential RE (CRR: 35%)",
    ),
    (
        "commercial_re",
        "senior",
        False,
        "commercial_re",
        "real_estate",
        "Secured by commercial RE (CRR: 35%)",
    ),
    (
        "real_estate",
        "senior",
        False,
        "residential_re",
        "real_estate",
        "Secured by real estate — general (CRR: 35%)",
    ),
    # Other physical — reduced (CRE32.12)
    (
        "other_physical",
        "senior",
        False,
        "other_physical",
        "other_physical",
        "Other eligible physical collateral (CRR: 40%)",
    ),
)


def _build_firb_lgd_df(
    row_specs: tuple[_FirbRowSpec, ...],
    lgd_dict: dict[str, Decimal],
    oc_ratios: dict[str, float],
    min_thresholds: dict[str, float],
) -> pl.DataFrame:
    """Build a CRR F-IRB LGD DataFrame from row specs + authoritative dicts."""
    return pl.DataFrame(
        {
            "collateral_type": [spec[0] for spec in row_specs],
            "seniority": [spec[1] for spec in row_specs],
            "lgd": [float(lgd_dict[spec[2]]) for spec in row_specs],
            "overcollateralisation_ratio": [oc_ratios[spec[3]] for spec in row_specs],
            "min_threshold": [min_thresholds[spec[3]] for spec in row_specs],
            "description": [spec[4] for spec in row_specs],
        }
    ).with_columns(
        [
            pl.col("lgd").cast(pl.Float64),
            pl.col("overcollateralisation_ratio").cast(pl.Float64),
            pl.col("min_threshold").cast(pl.Float64),
        ]
    )


def _build_b31_firb_lgd_df(
    row_specs: tuple[_B31FirbRowSpec, ...],
    lgd_dict: dict[str, Decimal],
    oc_ratios: dict[str, float],
    min_thresholds: dict[str, float],
) -> pl.DataFrame:
    """Build a Basel 3.1 F-IRB LGD DataFrame from row specs + authoritative dicts."""
    return pl.DataFrame(
        {
            "collateral_type": [spec[0] for spec in row_specs],
            "seniority": [spec[1] for spec in row_specs],
            "is_fse": [spec[2] for spec in row_specs],
            "lgd": [float(lgd_dict[spec[3]]) for spec in row_specs],
            "overcollateralisation_ratio": [oc_ratios[spec[4]] for spec in row_specs],
            "min_threshold": [min_thresholds[spec[4]] for spec in row_specs],
            "description": [spec[5] for spec in row_specs],
        }
    ).with_columns(
        [
            pl.col("lgd").cast(pl.Float64),
            pl.col("overcollateralisation_ratio").cast(pl.Float64),
            pl.col("min_threshold").cast(pl.Float64),
        ]
    )


def _create_firb_lgd_df() -> pl.DataFrame:
    """Create F-IRB supervisory LGD lookup DataFrame.

    Values are sourced from ``FIRB_SUPERVISORY_LGD`` (LGD),
    ``FIRB_OVERCOLLATERALISATION_RATIOS`` and
    ``FIRB_MIN_COLLATERALISATION_THRESHOLDS`` (Art. 230 / CRE32.9-12).
    """
    return _build_firb_lgd_df(
        _CRR_FIRB_ROW_SPECS,
        FIRB_SUPERVISORY_LGD,
        FIRB_OVERCOLLATERALISATION_RATIOS,
        FIRB_MIN_COLLATERALISATION_THRESHOLDS,
    )


def get_firb_lgd_table() -> pl.DataFrame:
    """
    Get F-IRB supervisory LGD lookup table.

    Returns:
        DataFrame with columns: collateral_type, seniority, lgd, description
    """
    return _create_firb_lgd_df()


def lookup_firb_lgd(
    collateral_type: str | None = None,
    is_subordinated: bool = False,
    is_basel_3_1: bool = False,
    is_financial_sector_entity: bool = False,
) -> Decimal:
    """
    Look up F-IRB supervisory LGD.

    This is a convenience function for single lookups. For bulk processing,
    use the DataFrame tables with joins.

    Under Basel 3.1, Art. 161(1)(a) vs (aa) distinguishes:
    - Financial sector entities (FSE): senior unsecured = 45%
    - Non-FSE corporates: senior unsecured = 40%

    Args:
        collateral_type: Type of collateral securing the exposure (None = unsecured)
        is_subordinated: Whether the exposure is subordinated
        is_basel_3_1: Whether to use Basel 3.1 revised values (CRE32.9-12)
        is_financial_sector_entity: Whether the obligor is a financial sector entity
            (only affects unsecured LGD under Basel 3.1)

    Returns:
        Supervisory LGD as Decimal
    """
    table = BASEL31_FIRB_SUPERVISORY_LGD if is_basel_3_1 else FIRB_SUPERVISORY_LGD

    # Subordinated unsecured: 75% (Art. 161(1)(b))
    if is_subordinated and collateral_type is None:
        return table["subordinated"]

    # No collateral - senior unsecured (with FSE distinction under B31)
    if collateral_type is None:
        if is_basel_3_1 and is_financial_sector_entity:
            return table["unsecured_senior_fse"]
        return table["unsecured_senior"]

    coll_lower = collateral_type.lower()

    # CRR Art. 230 Table 5: subordinated LGDS for the secured portion.
    # Basel 3.1 Art. 230(2) removes the subordinated LGDS column.
    _sub_suffix = "_subordinated" if (is_subordinated and not is_basel_3_1) else ""

    # Covered bonds — Art. 161(1)(d), no subordinated distinction
    if coll_lower in ("covered_bond", "covered_bonds"):
        return table["covered_bond"]

    # Financial collateral
    if coll_lower in ("financial_collateral", "cash", "deposit", "gold"):
        key = f"financial_collateral{_sub_suffix}"
        return table.get(key, table["financial_collateral"])

    # Receivables
    if coll_lower in ("receivables", "trade_receivables"):
        key = f"receivables{_sub_suffix}"
        return table.get(key, table["receivables"])

    # Real estate
    if coll_lower in ("residential_re", "rre", "residential"):
        key = f"residential_re{_sub_suffix}"
        return table.get(key, table["residential_re"])

    if coll_lower in ("commercial_re", "cre", "commercial"):
        key = f"commercial_re{_sub_suffix}"
        return table.get(key, table["commercial_re"])

    if coll_lower in ("real_estate", "property"):
        key = f"residential_re{_sub_suffix}"
        return table.get(key, table["residential_re"])

    # Other physical collateral
    if coll_lower in ("other_physical", "equipment", "inventory"):
        key = f"other_physical{_sub_suffix}"
        return table.get(key, table["other_physical"])

    # Unknown - treat as unsecured (with FSE distinction under B31)
    if is_subordinated:
        return table["subordinated"]
    if is_basel_3_1 and is_financial_sector_entity:
        return table["unsecured_senior_fse"]
    return table["unsecured_senior"]


def _get_overcollateralisation_params(collateral_type: str) -> tuple[float, float]:
    """
    Get overcollateralisation ratio and minimum threshold for a collateral type.

    Args:
        collateral_type: Type of collateral

    Returns:
        Tuple of (overcollateralisation_ratio, min_threshold)
    """
    coll_lower = collateral_type.lower()

    # Financial collateral
    if coll_lower in (
        "financial_collateral",
        "cash",
        "deposit",
        "gold",
        "government_bond",
        "corporate_bond",
        "equity",
    ):
        return FIRB_OVERCOLLATERALISATION_RATIOS[
            "financial"
        ], FIRB_MIN_COLLATERALISATION_THRESHOLDS["financial"]

    # Receivables
    if coll_lower in ("receivables", "trade_receivables"):
        return FIRB_OVERCOLLATERALISATION_RATIOS[
            "receivables"
        ], FIRB_MIN_COLLATERALISATION_THRESHOLDS["receivables"]

    # Real estate
    if coll_lower in (
        "real_estate",
        "property",
        "rre",
        "cre",
        "residential_re",
        "commercial_re",
        "residential",
        "commercial",
        "residential_property",
        "commercial_property",
    ):
        return FIRB_OVERCOLLATERALISATION_RATIOS[
            "real_estate"
        ], FIRB_MIN_COLLATERALISATION_THRESHOLDS["real_estate"]

    # Other physical
    if coll_lower in ("other_physical", "equipment", "inventory", "other"):
        return FIRB_OVERCOLLATERALISATION_RATIOS[
            "other_physical"
        ], FIRB_MIN_COLLATERALISATION_THRESHOLDS["other_physical"]

    # Unknown: treat as unsecured (no overcollateralisation benefit)
    return 1.0, 0.0


def calculate_effective_lgd_secured(
    base_lgd_unsecured: Decimal,
    collateral_value_adjusted: Decimal,
    ead: Decimal,
    collateral_type: str,
    collateral_lgd: Decimal | None = None,
    is_subordinated: bool = False,
    is_basel_3_1: bool = False,
) -> tuple[Decimal, str]:
    """
    Calculate effective LGD for partially secured exposure.

    For F-IRB, when collateral covers part of the exposure:
    - Secured portion: use collateral-specific LGD (Art. 230 Table 5)
    - Unsecured portion: use 45% (senior) or 75% (subordinated)

    CRR Art. 230 Table 5 has distinct subordinated LGDS values (65%/70%)
    for the secured portion. Basel 3.1 removes this distinction.

    Non-financial collateral requires overcollateralisation (CRR Art. 230 / CRE32.9-12):
    - Real estate: 140% overcollateralisation, 30% minimum threshold
    - Receivables: 125% overcollateralisation, no minimum threshold
    - Other physical: 140% overcollateralisation, 30% minimum threshold
    - Financial: no overcollateralisation required

    Args:
        base_lgd_unsecured: LGD for unsecured portion (45% or 75%)
        collateral_value_adjusted: Adjusted collateral value (after haircuts)
        ead: Exposure at default
        collateral_type: Type of collateral
        collateral_lgd: Override LGD for secured portion (optional)
        is_subordinated: Whether the exposure is a subordinated claim
        is_basel_3_1: Whether Basel 3.1 framework applies

    Returns:
        Tuple of (effective_lgd, description)
    """
    if ead <= 0:
        return base_lgd_unsecured, "Zero EAD"

    # Determine LGD for secured portion
    if collateral_lgd is not None:
        lgd_secured = collateral_lgd
    else:
        lgd_secured = lookup_firb_lgd(
            collateral_type, is_subordinated=is_subordinated, is_basel_3_1=is_basel_3_1
        )

    # Apply overcollateralisation and minimum threshold
    overcoll_ratio, min_threshold = _get_overcollateralisation_params(collateral_type)

    # Minimum threshold check: if collateral < threshold * EAD, ignore it
    if min_threshold > 0 and collateral_value_adjusted < Decimal(str(min_threshold)) * ead:
        return base_lgd_unsecured, f"Below min threshold ({min_threshold:.0%} of EAD)"

    # Effectively secured = adjusted_value / overcollateralisation_ratio
    effectively_secured = collateral_value_adjusted / Decimal(str(overcoll_ratio))

    # Calculate portions
    secured_portion = min(effectively_secured, ead)
    unsecured_portion = max(ead - effectively_secured, Decimal("0"))

    # Weighted average LGD
    if secured_portion + unsecured_portion > 0:
        effective_lgd = (
            lgd_secured * secured_portion + base_lgd_unsecured * unsecured_portion
        ) / ead
    else:
        effective_lgd = base_lgd_unsecured

    secured_pct = (secured_portion / ead * 100) if ead > 0 else Decimal("0")
    description = (
        f"Eff LGD: {effective_lgd:.1%} "
        f"(eff secured {secured_pct:.0f}% @ {lgd_secured:.0%}, "
        f"overcoll ratio {overcoll_ratio:.2f}, "
        f"unsecured @ {base_lgd_unsecured:.0%})"
    )

    return effective_lgd, description


# =============================================================================
# IRB PARAMETER FLOORS AND CAPS
# =============================================================================


def get_irb_parameters_df() -> pl.DataFrame:
    """
    Get IRB parameter floors and caps as DataFrame.

    Returns:
        DataFrame with regulatory parameter bounds
    """
    return pl.DataFrame(
        {
            "parameter": ["pd_floor", "maturity_floor", "maturity_cap"],
            "value": [0.0003, 1.0, 5.0],
            "unit": ["decimal", "years", "years"],
            "description": [
                "Minimum PD (0.03%)",
                "Minimum effective maturity",
                "Maximum effective maturity",
            ],
            "regulatory_reference": [
                "CRR Art. 163",
                "CRR Art. 162",
                "CRR Art. 162",
            ],
        }
    ).with_columns(
        [
            pl.col("value").cast(pl.Float64),
        ]
    )


def apply_pd_floor(pd: Decimal | float) -> Decimal:
    """
    Apply PD floor.

    Args:
        pd: Probability of default

    Returns:
        Floored PD (minimum 0.03%)
    """
    pd_decimal = Decimal(str(pd)) if not isinstance(pd, Decimal) else pd
    return max(pd_decimal, CRR_PD_FLOOR)


def apply_maturity_bounds(maturity: Decimal | float) -> Decimal:
    """
    Apply maturity floor and cap.

    Args:
        maturity: Effective maturity in years

    Returns:
        Bounded maturity (1-5 years)
    """
    mat_decimal = Decimal(str(maturity)) if not isinstance(maturity, Decimal) else maturity
    return max(CRR_MATURITY_FLOOR, min(CRR_MATURITY_CAP, mat_decimal))


# =============================================================================
# BASEL 3.1 F-IRB SUPERVISORY LGD CONSTANTS (PRA PS1/26 Art. 161)
# =============================================================================

# Key changes from CRR -> Basel 3.1:
# - Non-FSE senior unsecured: 45% -> 40% (Art. 161(1)(aa))
# - FSE senior unsecured: 45% unchanged (Art. 161(1)(a))
# - Covered bonds: new at 11.25% (Art. 161(1B))
# - Receivables LGDS: 35% -> 20% (CRE32.9)
# - Real estate LGDS: 35% -> 20% (CRE32.10-11)
# - Other physical LGDS: 40% -> 25% (CRE32.12)
# - Financial collateral: 0% unchanged
# - Subordinated: 75% unchanged

# The following scalars are thin aliases over ``BASEL31_FIRB_SUPERVISORY_LGD``.
# The dict above is the single source of truth — update it to change a value.
B31_FIRB_LGD_UNSECURED_SENIOR: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["unsecured_senior"]
"""Non-FSE senior unsecured LGD under Basel 3.1 (Art. 161(1)(aa))."""

B31_FIRB_LGD_UNSECURED_SENIOR_FSE: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["unsecured_senior_fse"]
"""FSE senior unsecured LGD under Basel 3.1 (Art. 161(1)(a))."""

B31_FIRB_LGD_SUBORDINATED: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["subordinated"]
"""Subordinated LGD, unchanged from CRR (Art. 161(1)(b))."""

B31_FIRB_LGD_COVERED_BOND: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["covered_bond"]
"""Covered bond LGD (Art. 161(1B))."""

B31_FIRB_LGD_FINANCIAL_COLLATERAL: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["financial_collateral"]
"""Financial collateral LGD, unchanged from CRR."""

B31_FIRB_LGD_RECEIVABLES: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["receivables"]
"""Receivables LGDS under Basel 3.1 (CRR: 35%, CRE32.9)."""

B31_FIRB_LGD_RESIDENTIAL_RE: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["residential_re"]
"""Residential RE LGDS under Basel 3.1 (CRR: 35%, CRE32.10)."""

B31_FIRB_LGD_COMMERCIAL_RE: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["commercial_re"]
"""Commercial RE LGDS under Basel 3.1 (CRR: 35%, CRE32.11)."""

B31_FIRB_LGD_OTHER_PHYSICAL: Decimal = BASEL31_FIRB_SUPERVISORY_LGD["other_physical"]
"""Other physical collateral LGDS under Basel 3.1 (CRR: 40%, CRE32.12)."""


def _create_b31_firb_lgd_df() -> pl.DataFrame:
    """Create Basel 3.1 F-IRB supervisory LGD lookup DataFrame.

    Values are sourced from ``BASEL31_FIRB_SUPERVISORY_LGD`` (LGD),
    ``FIRB_OVERCOLLATERALISATION_RATIOS`` and
    ``FIRB_MIN_COLLATERALISATION_THRESHOLDS`` (Art. 230 / CRE32.9-12,
    unchanged from CRR). Includes FSE/non-FSE distinction for unsecured
    exposures per Art. 161(1)(a) vs (aa).

    Returns:
        DataFrame with columns: collateral_type, seniority, is_fse, lgd,
        overcollateralisation_ratio, min_threshold, description
    """
    return _build_b31_firb_lgd_df(
        _B31_FIRB_ROW_SPECS,
        BASEL31_FIRB_SUPERVISORY_LGD,
        FIRB_OVERCOLLATERALISATION_RATIOS,
        FIRB_MIN_COLLATERALISATION_THRESHOLDS,
    )


def get_b31_firb_lgd_table() -> pl.DataFrame:
    """Get Basel 3.1 F-IRB supervisory LGD lookup table.

    Returns:
        DataFrame with columns: collateral_type, seniority, is_fse, lgd,
        overcollateralisation_ratio, min_threshold, description
    """
    return _create_b31_firb_lgd_df()


def lookup_b31_firb_lgd(
    collateral_type: str | None = None,
    is_subordinated: bool = False,
    is_financial_sector_entity: bool = False,
) -> tuple[Decimal, str]:
    """Look up Basel 3.1 F-IRB supervisory LGD.

    Under Basel 3.1 (PRA PS1/26 Art. 161(1)), key differences from CRR:
    - Non-FSE senior unsecured: 40% (CRR: 45%)
    - FSE senior unsecured: 45% (unchanged)
    - Covered bonds: 11.25% (Art. 161(1B))
    - Receivables LGDS: 20% (CRR: 35%)
    - Real estate LGDS (RRE/CRE): 20% (CRR: 35%)
    - Other physical LGDS: 25% (CRR: 40%)

    Args:
        collateral_type: Type of collateral securing the exposure (None = unsecured)
        is_subordinated: Whether the exposure is subordinated
        is_financial_sector_entity: Whether the obligor is a financial sector entity
            (only affects unsecured LGD)

    Returns:
        Tuple of (supervisory_lgd, description)
    """
    table = BASEL31_FIRB_SUPERVISORY_LGD

    # Subordinated always gets 75% regardless of collateral
    if is_subordinated:
        return table["subordinated"], "Subordinated (75%)"

    # No collateral — senior unsecured (with FSE distinction)
    if collateral_type is None:
        if is_financial_sector_entity:
            return table["unsecured_senior_fse"], "Unsecured senior FSE (45%)"
        return table["unsecured_senior"], "Unsecured senior non-FSE (40%)"

    coll_lower = collateral_type.lower()

    # Covered bonds — Art. 161(1B)
    if coll_lower in ("covered_bond", "covered_bonds"):
        return table["covered_bond"], "Covered bond (11.25%)"

    # Financial collateral
    if coll_lower in ("financial_collateral", "cash", "deposit", "gold"):
        return table["financial_collateral"], "Financial collateral (0%)"

    # Receivables
    if coll_lower in ("receivables", "trade_receivables"):
        return table["receivables"], "Receivables (20%)"

    # Real estate
    if coll_lower in ("residential_re", "rre", "residential"):
        return table["residential_re"], "Residential RE (20%)"

    if coll_lower in ("commercial_re", "cre", "commercial"):
        return table["commercial_re"], "Commercial RE (20%)"

    if coll_lower in ("real_estate", "property"):
        return table["residential_re"], "Real estate (20%)"

    # Other physical collateral
    if coll_lower in ("other_physical", "equipment", "inventory"):
        return table["other_physical"], "Other physical (25%)"

    # Unknown — treat as unsecured (with FSE distinction)
    if is_financial_sector_entity:
        return table["unsecured_senior_fse"], "Unknown collateral -> unsecured FSE (45%)"
    return table["unsecured_senior"], "Unknown collateral -> unsecured non-FSE (40%)"


def get_b31_vs_crr_lgd_comparison() -> pl.DataFrame:
    """Get a comparison DataFrame showing CRR vs Basel 3.1 FIRB LGD values.

    Useful for audit, reporting, and validation of the B31 LGD changes.

    Returns:
        DataFrame with columns: collateral_type, crr_lgd, b31_lgd, change_bps
    """
    comparison_rows = []
    for key in FIRB_SUPERVISORY_LGD:
        crr_val = float(FIRB_SUPERVISORY_LGD[key])
        b31_val = float(BASEL31_FIRB_SUPERVISORY_LGD.get(key, FIRB_SUPERVISORY_LGD[key]))
        comparison_rows.append(
            {
                "collateral_type": key,
                "crr_lgd": crr_val,
                "b31_lgd": b31_val,
                "change_bps": round((b31_val - crr_val) * 10000),
            }
        )

    # Add FSE-specific entry (only in B31)
    comparison_rows.append(
        {
            "collateral_type": "unsecured_senior_fse",
            "crr_lgd": float(FIRB_SUPERVISORY_LGD["unsecured_senior"]),
            "b31_lgd": float(BASEL31_FIRB_SUPERVISORY_LGD["unsecured_senior_fse"]),
            "change_bps": 0,
        }
    )

    return pl.DataFrame(comparison_rows).with_columns(
        [
            pl.col("crr_lgd").cast(pl.Float64),
            pl.col("b31_lgd").cast(pl.Float64),
            pl.col("change_bps").cast(pl.Int32),
        ]
    )
