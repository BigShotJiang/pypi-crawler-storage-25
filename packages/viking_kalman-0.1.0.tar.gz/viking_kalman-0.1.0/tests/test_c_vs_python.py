try:
    from viking_kalman import grid

    print("✅ Version C activated !")
    print("File used :", grid.__file__)
except ImportError:
    print("⚠️ Pure Python, fallback activated.")
