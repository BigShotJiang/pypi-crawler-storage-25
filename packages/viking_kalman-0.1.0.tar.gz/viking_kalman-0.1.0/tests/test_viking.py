import os
import pytest
import numpy as np
from viking_kalman.viking import viking

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


@pytest.fixture
def viking_ground_truth():
    X = np.load(os.path.join(DATA_DIR, "X.npy"))
    y = np.load(os.path.join(DATA_DIR, "y.npy"))
    expected = {
        "theta_arr": np.load(os.path.join(DATA_DIR, "vik_theta_arr.npy")),
        "P_arr": np.load(os.path.join(DATA_DIR, "vik_P_arr.npy")),
        "q_arr": np.load(os.path.join(DATA_DIR, "vik_q_arr.npy")),
        "hata_arr": np.load(os.path.join(DATA_DIR, "vik_hata_arr.npy")),
        "s_arr": np.load(os.path.join(DATA_DIR, "vik_s_arr.npy")),
        "hatb_arr": np.load(os.path.join(DATA_DIR, "vik_hatb_arr.npy")),
        "Sigma_arr": np.load(os.path.join(DATA_DIR, "vik_Sigma_arr.npy")),
    }
    return X, y, expected


def test_viking(viking_ground_truth):
    X, y, expected = viking_ground_truth
    _, d = X.shape

    result = viking(
        X,
        y,
        theta0=np.zeros((d, 1)),
        P0=np.eye(d),
        hata0=0.0,
        s0=0.0,
        hatb0=np.zeros((d, 1)),
        Sigma0=np.eye(d) * 0.1,
        mc=0,
        phi=np.exp,
        phi1=np.exp,
        phi2=np.exp,
    )

    assert result["theta_arr"].shape == expected["theta_arr"].shape
    assert np.all(np.isfinite(result["theta_arr"]))
    assert result["P_arr"].size == expected["P_arr"].size
    assert np.all(np.isfinite(result["P_arr"]))
    assert result["q_arr"].shape == expected["q_arr"].shape
    assert np.all(np.isfinite(result["q_arr"]))
    assert result["hata_arr"].shape == expected["hata_arr"].shape
    assert result["s_arr"].shape == expected["s_arr"].shape
    assert result["hatb_arr"].shape == expected["hatb_arr"].shape
    assert result["Sigma_arr"].size == expected["Sigma_arr"].size
