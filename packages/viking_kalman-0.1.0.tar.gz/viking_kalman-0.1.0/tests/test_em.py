# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import os
import pytest
import numpy as np
from numpy.testing import assert_allclose
from viking_kalman.expectation_maximization import expectation_maximization

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


@pytest.fixture
def em_ground_truth():
    """Loads the inputs and the expected R-generated outputs from .npy files."""

    X = np.load(os.path.join(DATA_DIR, "X.npy"))
    y = np.load(os.path.join(DATA_DIR, "y.npy"))

    expected = {
        "P": np.load(os.path.join(DATA_DIR, "P.npy")),
        "theta": np.load(os.path.join(DATA_DIR, "theta.npy")),
        "Q": np.load(os.path.join(DATA_DIR, "Q.npy")),
        "sig": np.load(os.path.join(DATA_DIR, "sig.npy")),
        "diff": np.load(os.path.join(DATA_DIR, "diff.npy")),
        "loglik": np.load(os.path.join(DATA_DIR, "loglik.npy")),
    }
    return X, y, expected


def test_expectation_maximization(em_ground_truth):
    X, y, expected = em_ground_truth

    n, d = X.shape
    n_iter = len(expected["loglik"])

    Q_init = np.eye(d) * 0.1
    sig_init = 1.0
    p1_init = 0.0

    result = expectation_maximization(
        X=X, y=y, n_iter=n_iter, Q_init=Q_init, sig_init=sig_init, p1=p1_init, verbose=0
    )

    assert_allclose(
        result["P"], expected["P"], rtol=1e-5, atol=1e-8, err_msg="P matrix mismatch"
    )
    assert_allclose(
        result["theta"],
        expected["theta"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="Theta mismatch",
    )
    assert_allclose(
        result["Q"], expected["Q"], rtol=1e-5, atol=1e-8, err_msg="Q matrix mismatch"
    )
    assert_allclose(
        result["sig"], expected["sig"], rtol=1e-5, atol=1e-8, err_msg="Sigma mismatch"
    )
    assert_allclose(
        result["diff"].flatten(),
        expected["diff"].flatten(),
        rtol=1e-5,
        atol=1e-8,
        err_msg="Diff mismatch",
    )
    assert_allclose(
        result["loglik"].flatten(),
        expected["loglik"].flatten(),
        rtol=1e-5,
        atol=1e-8,
        err_msg="Loglik mismatch",
    )
