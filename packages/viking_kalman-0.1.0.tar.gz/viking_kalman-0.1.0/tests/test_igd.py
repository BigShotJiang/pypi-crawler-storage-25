# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import os
import pytest
import numpy as np
from numpy.testing import assert_allclose

# 1. Import the Pure Python version directly
from viking_kalman.iterative_grid_search_other import (
    iterative_grid_search as igd_python,
)

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


@pytest.fixture
def igd_ground_truth():
    """Loads the inputs and the expected R-generated outputs from .npy files."""
    X = np.load(os.path.join(DATA_DIR, "X.npy"))
    y = np.load(os.path.join(DATA_DIR, "y.npy"))

    expected = {
        "P": np.load(os.path.join(DATA_DIR, "igd_P.npy")),
        "theta": np.load(os.path.join(DATA_DIR, "igd_theta.npy")),
        "Q": np.load(os.path.join(DATA_DIR, "igd_Q.npy")),
        "sig": np.load(os.path.join(DATA_DIR, "igd_sig.npy")),
        "loglik": np.load(os.path.join(DATA_DIR, "igd_loglik.npy")),
    }
    return X, y, expected


def test_iterative_grid_search_python(igd_ground_truth):
    """Tests the pure Python fallback implementation."""
    X, y, expected = igd_ground_truth
    n, d = X.shape
    q_list = [0.0, 0.01, 0.1, 1.0]
    Q_init = np.eye(d) * 0.1
    p1_init = 0.0
    max_iter = 0

    result = igd_python(
        X=X,
        y=y,
        q_list=q_list,
        Q_init=Q_init,
        p1=p1_init,
        max_iter=max_iter,
        verbose=False,
    )

    assert_allclose(
        result["P"],
        expected["P"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="P matrix mismatch (Python)",
    )
    assert_allclose(
        result["theta"],
        expected["theta"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="Theta mismatch (Python)",
    )
    assert_allclose(
        result["Q"],
        expected["Q"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="Q matrix mismatch (Python)",
    )
    assert_allclose(
        result["sig"],
        expected["sig"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="Sigma mismatch (Python)",
    )

    assert_allclose(
        np.array(result["LOGLIK"]).flatten(),
        expected["loglik"].flatten(),
        rtol=1e-5,
        atol=1e-8,
        err_msg="Loglik mismatch (Python)",
    )


def test_iterative_grid_search_c(igd_ground_truth):
    """Tests the optimized C-extension, skipping if not compiled."""
    # 2. Skip this test gracefully if the C-extension is not built
    grid_c = pytest.importorskip("viking_kalman.grid")

    X, y, expected = igd_ground_truth
    n, d = X.shape
    q_list = [0.0, 0.01, 0.1, 1.0]
    Q_init = np.eye(d) * 0.1
    p1_init = 0.0
    max_iter = 0

    result = grid_c.iterative_grid_search(
        X, y, q_list, Q_init=Q_init, p1=p1_init, max_iter=max_iter, verbose=False
    )

    assert_allclose(
        result["P"],
        expected["P"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="P matrix mismatch (C-extension)",
    )
    assert_allclose(
        result["theta"],
        expected["theta"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="Theta mismatch (C-extension)",
    )
    assert_allclose(
        result["Q"],
        expected["Q"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="Q matrix mismatch (C-extension)",
    )
    assert_allclose(
        result["sig"],
        expected["sig"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="Sigma mismatch (C-extension)",
    )

    assert_allclose(
        np.array(result["LOGLIK"]).flatten(),
        expected["loglik"].flatten(),
        rtol=1e-5,
        atol=1e-8,
        err_msg="Loglik mismatch (C-extension)",
    )
