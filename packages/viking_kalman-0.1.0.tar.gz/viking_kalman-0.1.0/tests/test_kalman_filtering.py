import os
import pytest
import numpy as np
from numpy.testing import assert_allclose
from viking_kalman.kalman_filtering import kalman_filtering

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


@pytest.fixture
def kf_ground_truth():
    X = np.load(os.path.join(DATA_DIR, "X.npy"))
    y = np.load(os.path.join(DATA_DIR, "y.npy"))
    expected = {
        "theta_arr": np.load(os.path.join(DATA_DIR, "kf_theta_arr.npy")),
        "P_arr": np.load(os.path.join(DATA_DIR, "kf_P_arr.npy")),
        "theta": np.load(os.path.join(DATA_DIR, "kf_theta.npy")),
        "P": np.load(os.path.join(DATA_DIR, "kf_P.npy")),
    }
    return X, y, expected


def test_kalman_filtering(kf_ground_truth):
    X, y, expected = kf_ground_truth
    n, d = X.shape

    theta1 = np.zeros(d)
    P1 = np.eye(d)
    Q = np.diag([0, 0, 0.25, 0.25, 0.25])
    sig = 1.0

    result = kalman_filtering(X, y, theta1, P1, Q, sig)

    assert_allclose(result["theta_arr"], expected["theta_arr"], rtol=1e-5, atol=1e-8)
    expected_P_arr_3d = expected["P_arr"].reshape((n, d, d), order="F")
    assert_allclose(result["P_arr"], expected_P_arr_3d, rtol=1e-5, atol=1e-8)
    assert_allclose(
        result["theta"].flatten(), expected["theta"].flatten(), rtol=1e-5, atol=1e-8
    )
    assert_allclose(result["P"], expected["P"], rtol=1e-5, atol=1e-8)
