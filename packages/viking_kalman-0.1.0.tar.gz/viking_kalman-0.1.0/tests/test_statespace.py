# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import pytest
import numpy as np
from scipy.stats import multivariate_normal
from viking_kalman import StateSpaceModel


@pytest.fixture
def simulated_data():
    """Simulates data for testing the StateSpaceModel wrapper."""
    np.random.seed(1)

    n = 100
    d = 5
    Q = np.diag([0, 0, 0.25, 0.25, 0.25])
    sig = 1

    X = np.hstack([np.random.normal(0, 1, size=(n, d - 1)), np.ones((n, 1))])
    theta = np.random.normal(0, 1, size=(d))
    theta_arr = np.zeros((n, d))
    for t in range(n):
        theta_arr[t, :] = theta
        theta = theta + multivariate_normal.rvs(mean=np.zeros(d), cov=Q)

    y = np.sum(X * theta_arr, axis=1) + np.random.normal(0, sig, n)

    return X, y, Q, sig


def test_statespacemodel_initialization(simulated_data):
    """Tests that the StateSpaceModel initializes and runs its first internal prediction."""
    X, y, Q, sig = simulated_data

    ssm = StateSpaceModel(X, y, kalman_params={"Q": Q, "sig": sig})

    assert ssm.X is not None
    assert ssm.y is not None
    assert ssm.pred_mean is not None
    assert ssm.pred_sd is not None
    assert len(ssm.pred_mean) == X.shape[0]


def test_statespacemodel_predict(simulated_data):
    """Tests that the .predict() method returns the correct types and shapes."""
    X, y, Q, sig = simulated_data

    ssm = StateSpaceModel(X, y, kalman_params={"Q": Q, "sig": sig})

    pred_mean = ssm.predict(X, _type="mean", online=False)
    assert isinstance(pred_mean, np.ndarray)
    assert pred_mean.shape == (X.shape[0],)

    pred_proba = ssm.predict(X, _type="proba", online=False)
    assert isinstance(pred_proba, dict)
    assert "mean" in pred_proba
    assert "sd" in pred_proba
    assert pred_proba["mean"].shape == (X.shape[0],)
    assert pred_proba["sd"].shape == (X.shape[0],)


def test_statespacemodel_plot(simulated_data, monkeypatch):
    """Tests that the .plot() method runs without raising errors."""
    X, y, Q, sig = simulated_data

    import matplotlib.pyplot as plt

    monkeypatch.setattr(plt, "show", lambda: None)

    ssm = StateSpaceModel(X, y, kalman_params={"Q": Q, "sig": sig})

    try:
        ssm.plot()
    except Exception as e:
        pytest.fail(f"ssm.plot() raised an exception: {e}")
