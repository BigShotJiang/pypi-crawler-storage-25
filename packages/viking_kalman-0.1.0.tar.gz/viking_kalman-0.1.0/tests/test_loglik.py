# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import os
import pytest
import numpy as np
from numpy.testing import assert_allclose

from viking_kalman.loglik import loglik, parameters_star, get_theta1, get_sig

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


@pytest.fixture
def loglik_ground_truth():
    """Loads the inputs and the expected R-generated outputs from .npy files."""
    X = np.load(os.path.join(DATA_DIR, "X.npy"))
    y = np.load(os.path.join(DATA_DIR, "y.npy"))
    expected = {
        "thetastar_arr": np.load(os.path.join(DATA_DIR, "ll_thetastar_arr.npy")),
        "Pstar_arr": np.load(os.path.join(DATA_DIR, "ll_Pstar_arr.npy")),
        "C_arr": np.load(os.path.join(DATA_DIR, "ll_C_arr.npy")),
        "theta1": np.load(os.path.join(DATA_DIR, "ll_theta1.npy")),
        "sig": np.load(os.path.join(DATA_DIR, "ll_sig.npy")),
        "loglik_val": np.load(os.path.join(DATA_DIR, "ll_loglik_val.npy")),
    }
    return X, y, expected


def test_loglik_components(loglik_ground_truth):
    X, y, expected = loglik_ground_truth
    n, d = X.shape
    Qstar = np.zeros((d, d))
    p1_init = 0.0
    use = np.arange(n)
    train_theta1 = np.arange(n)
    train_Q = np.arange(n)
    mode = "gaussian"

    par = parameters_star(X, y, Qstar, p1=p1_init)

    assert_allclose(
        par["thetastar_arr"],
        expected["thetastar_arr"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="thetastar_arr mismatch",
    )
    expected_Pstar_3d = expected["Pstar_arr"].reshape((n + 1, d, d), order="F")
    expected_C_3d = expected["C_arr"].reshape((n + 1, d, d), order="F")
    assert_allclose(
        par["Pstar_arr"],
        expected_Pstar_3d,
        rtol=1e-5,
        atol=1e-8,
        err_msg="Pstar_arr mismatch",
    )
    assert_allclose(
        par["C_arr"], expected_C_3d, rtol=1e-5, atol=1e-8, err_msg="C_arr mismatch"
    )

    theta1 = get_theta1(X, y, par, Qstar, use, mode=mode)
    assert_allclose(
        theta1, expected["theta1"], rtol=1e-5, atol=1e-8, err_msg="theta1 mismatch"
    )

    sig = get_sig(X, y, par, Qstar, use)
    assert_allclose(sig, expected["sig"], rtol=1e-5, atol=1e-8, err_msg="sig mismatch")

    ll_val = loglik(X, y, Qstar, use, p1_init, train_theta1, train_Q, mode=mode)
    assert_allclose(
        ll_val,
        expected["loglik_val"],
        rtol=1e-5,
        atol=1e-8,
        err_msg="loglik value mismatch",
    )
