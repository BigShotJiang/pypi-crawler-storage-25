# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
# --------------------------------------------------------------------------------

"""
.. module:: iterative_grid_search_other
   :synopsis: Pure Python fallback implementation of the iterative grid search.
"""

import numpy as np
from .loglik import loglik, parameters_star, get_theta1, get_sig


def iterative_grid_search(
    X,
    y,
    q_list,
    Q_init=None,
    max_iter=0,
    delay=1,
    use=None,
    restrict=None,
    mode="gaussian",
    p1=0.0,
    ncores=1,
    train_theta1=None,
    train_Q=None,
    verbose=True,
):
    """
    Pure Python fallback for the iterative grid search algorithm.
    Used automatically when the optimized C-extension cannot be compiled.

    Parameters
    ----------
    X : np.ndarray
        The explanatory variables.
    y : np.ndarray
        The observations.
    q_list : list
        The list of possible values for the diagonal elements of Q / sig^2.
    Q_init : np.ndarray, optional
        Initial value of Q / sig^2. If None, it is set to a zero matrix, by default None.
    max_iter : int, optional
        Maximal number of iterations. If 0, optimization continues as long as
        the log-likelihood can be improved, by default 0.
    delay : int, optional
        To predict y[t], the model has access to y[t-delay], by default 1.
    use : list, optional
        The availability variable, by default None.
    restrict : list, optional
        If not None, specifies the indices of the diagonal coefficients of Q to optimize,
        by default None.
    mode : str, optional
        The calculation mode, by default "gaussian".
    p1 : float, optional
        Coefficient for P1/sig^2 = p1 * I, by default 0.0.
    ncores : int, optional
        Number of available cores for computation, by default 1.
    train_theta1 : list, optional
        Training set indices for the estimation of theta1, by default None.
    train_Q : list, optional
        Time step indices on which the log-likelihood is computed, by default None.
    verbose : bool, optional
        Whether to print intermediate progress, by default True.

    Returns
    -------
    dict
        A dictionary containing the estimated parameters: `theta`, `P`, `sig`, `Q`,
        and `LOGLIK` (the evolution of the log-likelihood during the search).
    """
    n, d = X.shape
    if use is None:
        use = np.maximum(np.arange(n) - delay, -1)
    if train_theta1 is None:
        train_theta1 = np.arange(n)
    if train_Q is None:
        train_Q = np.arange(n)

    if Q_init is None:
        Qstar = np.zeros((d, d))
    else:
        Qstar = np.array(Q_init).copy()

    if restrict is None:
        search_dimensions = list(range(d))
    else:
        search_dimensions = restrict

    b = True
    l_opt = loglik(X, y, Qstar, use, p1, train_theta1, train_Q, mode=mode)
    n_iter = 0
    LOGLIK = []

    while b:
        n_iter += 1
        b = (n_iter < max_iter) or (max_iter == 0)
        best_i = -1
        best_q = 0

        for k in search_dimensions:
            q_prev = Qstar[k, k]
            l_arr = []

            for q in q_list:
                Qstar[k, k] = q
                l_arr.append(
                    loglik(X, y, Qstar, use, p1, train_theta1, train_Q, mode=mode)
                )

            max_l = max(l_arr)
            if max_l > l_opt:
                l_opt = max_l
                best_i = k
                best_q = q_list[np.argmax(l_arr)]

            Qstar[k, k] = q_prev

        LOGLIK.append(l_opt)
        if best_i == -1:
            b = False
        else:
            Qstar[best_i, best_i] = best_q
            if verbose:
                if best_q in [min(q_list), max(q_list)]:
                    print("Warning: Values may not be suited")
                print(
                    f"Iteration: {n_iter} | Log-likelihood: {l_opt:.6f} | Diagonal of Q/sigma^2:"
                )
                print(np.diag(Qstar))

    par = parameters_star(X, y, Qstar, p1=p1)

    theta = get_theta1(X, y, par, Qstar, use, mode=mode)
    sig = get_sig(X, y, par, Qstar, use)

    P = np.eye(d) * p1 * (sig**2)
    Q_final = Qstar * (sig**2)

    return {
        "P": P,
        "theta": theta,
        "Q": Q_final,
        "sig": sig,
        "LOGLIK": np.array(LOGLIK),
    }
