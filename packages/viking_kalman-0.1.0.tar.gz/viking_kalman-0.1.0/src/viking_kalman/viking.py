# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import numpy as np
from numpy.linalg import inv
from scipy.stats import norm, multivariate_normal


def viking(
    X,
    y,
    theta0,
    P0,
    hata0,
    s0,
    hatb0,
    Sigma0,
    n_iter=2,
    mc=10,
    rho_a=0,
    rho_b=0,
    learn_sigma=True,
    learn_Q=True,
    K=None,
    mode="diagonal",
    thresh=True,
    phi=lambda b: np.log(1 + (b + np.abs(b)) / 2),
    phi1=lambda b: 1 / (1 + (b + np.abs(b)) / 2) * (b >= 0),
    phi2=lambda b: -1 / (1 + (b + np.abs(b)) / 2) ** 2 * (b >= 0),
):
    """
    Performs state-space estimation using the Viking algorithm.

    Viking (Variational bayesIan variance tracKING) generalizes the Kalman Filter
    to handle uncertainty in variances.

    Parameters
    ----------
    X : np.ndarray
        The explanatory variables.
    y : np.ndarray
        The time series.
    theta0, P0, hata0, s0, hatb0, Sigma0 :
        Initial values for the model and variational parameters.
    n_iter : int, optional
        Number of alternate steps in the variational update, by default 2.
    mc : int, optional
        Number of Monte-Carlo samples for expectations. If 0, a Taylor
        approximation is used, by default 10.
    rho_a, rho_b : float, optional
        Learning rates for the variance parameters, by default 0.
    learn_sigma, learn_Q : bool, optional
        Flags to enable learning of variance parameters, by default True.
    K : np.ndarray, optional
        State transition factor. If None, identity matrix is used, by default None.
    mode : str, optional
        Can be 'diagonal' or 'scalar', by default "diagonal".
    thresh : bool, optional
        Whether to apply a threshold to `hatb_new`, by default True.

    Returns
    -------
    dict
        A dictionary containing the evolving values of all parameters.

    References
    ----------
    J. de Vilmarest, O. Wintenberger (2021), Viking: Variational Bayesian Variance
    Tracking. <https://arxiv.org/abs/2104.10777>
    """
    n, d = X.shape

    if K is None:
        K = np.eye(d)

    # Use conventional (n, ...) shape for time-varying arrays
    q_arr = np.zeros((n, d))
    theta_arr = np.zeros((n, d))
    P_arr = np.zeros((n, d, d))
    hata_arr = np.zeros(n)
    s_arr = np.zeros(n)
    hatb_arr = np.zeros((n, d))
    Sigma_arr = np.zeros((n, d, d))

    # Ensure inputs are NumPy arrays and flatten vectors to 1D
    theta = np.asarray(theta0).flatten()
    P = np.asarray(P0)
    hata = hata0
    s = s0
    hatb = np.asarray(hatb0).flatten()
    Sigma = np.asarray(Sigma0)

    for t in range(n):
        hata_new = hata
        s_new = s + rho_a
        hatb_new = hatb
        Sigma_new = Sigma + rho_b * (np.eye(d) if mode == "diagonal" else 1.0)

        if mode == "scalar":
            bMC = norm.rvs(hatb_new, np.sqrt(Sigma_new), size=10**3)
            q_arr[t, :] = np.mean(phi(bMC))
        elif mode == "diagonal":
            bMC = multivariate_normal.rvs(hatb_new.flatten(), Sigma_new, size=10**3)
            q_arr[t, :] = np.mean(phi(bMC), axis=0)

        theta_arr[t, :] = (K @ theta).flatten()
        P_arr[t, :, :] = K @ P @ K.T + np.diag(q_arr[t, :])
        hata_arr[t] = hata_new
        s_arr[t] = s_new
        hatb_arr[t, :] = hatb_new.flatten()
        Sigma_arr[t, :, :] = Sigma_new

        for _ in range(n_iter):
            P_pred = K @ P @ K.T

            if mode == "scalar":
                if mc > 0:
                    bMC = norm.rvs(hatb_new, np.sqrt(Sigma_new), size=mc)
                    A = np.mean([inv(P_pred + phi(b) * np.eye(d)) for b in bMC], axis=0)
                else:
                    C_inv = inv(P_pred + phi(hatb_new) * np.eye(d))
                    term2 = phi2(hatb_new) * Sigma_new * (C_inv @ C_inv) / 2
                    term3 = (phi1(hatb_new) ** 2) * Sigma_new * (C_inv @ C_inv @ C_inv)
                    A = C_inv - term2 + term3

            elif mode == "diagonal":
                if mc > 0:
                    bMC = multivariate_normal.rvs(
                        hatb_new.flatten(), Sigma_new, size=mc
                    )
                    A = np.mean([inv(P_pred + np.diag(phi(b))) for b in bMC], axis=0)
                else:
                    C_inv = inv(P_pred + np.diag(phi(hatb_new)))
                    term2 = (
                        C_inv @ np.diag(phi2(hatb_new) * np.diag(Sigma_new)) @ C_inv / 2
                    )
                    B = C_inv * np.outer(phi1(hatb_new), phi1(hatb_new)) * Sigma_new
                    term3 = C_inv @ B @ C_inv
                    A = C_inv - term2 + term3

            A_inv = inv((A + A.T) / 2)

            v = np.exp(hata_new - s_new / 2)
            Xt = X[t, :].reshape(-1, 1)
            A_invX = A_inv @ Xt

            P_new = A_inv - (A_invX @ A_invX.T) / ((Xt.T @ A_invX).item() + v)
            theta_new = (K @ theta).reshape(-1, 1) + (P_new @ Xt / v) * (
                y[t] - (Xt.T @ K @ theta).item()
            )
            theta_new = theta_new.flatten()

            if learn_sigma:
                c = (y[t] - (Xt.T @ theta_new).item()) ** 2 + (Xt.T @ P_new @ Xt).item()
                s_new = 1 / (1 / (s + rho_a + 1e-9) + 0.5 * c * np.exp(-hata_new))
                Ma = 3 * s
                diff = (
                    0.5
                    * (
                        1 / (s + rho_a + 1e-9)
                        + 0.5 * c * np.exp(-hata + s_new / 2 + Ma)
                    )
                    ** -1
                    * (c * np.exp(-hata + s_new / 2) - 1)
                )
                hata_new = hata + np.clip(diff, -Ma, Ma)

            if learn_Q:
                tKt = theta_new - (K @ theta)
                B = P_new + np.outer(tKt, tKt)

                if mode == "scalar":
                    C_inv = inv(P_pred + phi(hatb) * np.eye(d))
                    g = np.trace(C_inv @ (np.eye(d) - B @ C_inv)) * phi1(hatb)
                    H = (
                        -np.trace(C_inv @ B @ C_inv) * phi2(hatb)
                        + 2 * np.trace(C_inv @ C_inv @ B @ C_inv) * phi1(hatb) ** 2
                    )
                    Sigma_new = 1 / (1 / (Sigma + rho_b + 1e-9) + H / 2)
                    hatb_new = hatb - Sigma_new * g / 2

                elif mode == "diagonal":
                    C_inv = inv(P_pred + np.diag(phi(hatb)))
                    g = np.diag(C_inv @ (np.eye(d) - B @ C_inv)) * phi1(hatb)
                    H_term1 = -(C_inv @ B @ C_inv @ np.diag(phi2(hatb))) * np.eye(d)
                    H_term2 = (
                        2
                        * (C_inv @ B @ C_inv)
                        * C_inv
                        * np.outer(phi1(hatb), phi1(hatb))
                    )
                    H = H_term1 + H_term2
                    Sigma_new = inv(inv(Sigma + (rho_b + 1e-9) * np.eye(d)) + H / 2)
                    hatb_new = hatb - (Sigma_new @ g / 2).flatten()

                if thresh:
                    hatb_new = (hatb_new + np.abs(hatb_new)) / 2

        P = P_new
        theta = theta_new.copy()
        hata = hata_new
        s = s_new
        hatb = hatb_new
        Sigma = Sigma_new

    return {
        "theta_arr": theta_arr,
        "P_arr": P_arr,
        "q_arr": q_arr,
        "hata_arr": hata_arr,
        "s_arr": s_arr,
        "hatb_arr": hatb_arr,
        "Sigma_arr": Sigma_arr,
    }
