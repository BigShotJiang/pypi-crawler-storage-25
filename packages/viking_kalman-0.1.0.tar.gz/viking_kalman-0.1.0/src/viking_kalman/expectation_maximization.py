# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------


import numpy as np
from datetime import datetime


def expectation_maximization(
    X: np.ndarray,
    y: np.ndarray,
    n_iter: int,
    Q_init: np.ndarray,
    sig_init: float = 1,
    verbose: int = 1000,
    Lambda: float = 1e-9,
    mode_diag: bool = False,
    p1: float = 0,
) -> dict:
    """
    Selects hyperparameters of a linear Gaussian State-Space Model with
    time-invariant variances, using the Expectation-Maximization (EM) algorithm.

    Parameters
    ----------
    X : np.ndarray
        Explanatory variables matrix (n, d).
    y : np.ndarray
        Time series of observations (n,).
    n_iter : int
        Number of iterations of the EM algorithm.
    Q_init : np.ndarray
        Initial covariance matrix for the state noise Q.
    sig_init : float, optional
        Initial value of the standard deviation of the observation noise, by default 1.
    verbose : int, optional
        Frequency for printing progress (every `verbose` iterations), by default 1000.
    Lambda : float, optional
        Regularization parameter to avoid singularity, by default 1e-9.
    mode_diag : bool, optional
        If True, the search for Q is restricted to diagonal matrices, by default False.
    p1 : float, optional
        Coefficient for the initial covariance P1 = p1 * I, by default 0.

    Returns
    -------
    dict
        A dictionary containing the estimated values for 'P', 'theta', 'sig', 'Q',
        as well as 'diff' and 'loglik' which track the algorithm's convergence.

    Details
    -------
    The E-step (Expectation) is realized through recursive Kalman formulas (filtering then smoothing).
    The M-step (Maximization) is the maximization of the expected complete likelihood
    with respect to the hyperparameters.
    Convergence to a GLOBAL optimum is not guaranteed, only to a LOCAL optimum.
    """
    # Initialize
    n, d = X.shape
    sig2 = sig_init**2
    theta_1 = np.zeros((d, 1))
    Q = Q_init
    diff = np.zeros((n_iter, 1))
    loglik = -0.5 * np.log(2 * np.pi) * np.ones((n_iter, 1))
    flag_decrease = False
    init_time = datetime.now()

    # Iterations
    for i in range(n_iter):
        theta_arr = np.zeros((n, d))
        theta_arr_2 = np.zeros((n, d))
        theta = np.zeros((d, 1))
        P_arr = np.zeros((n, d, d))
        P = np.eye(d) * p1
        C_arr = np.zeros((n, d, d))
        C_arr_2 = np.zeros((n, d, d))
        C = np.eye(d)

        # E-step
        # Filtering
        for t in range(n):
            theta_arr_2[t, :] = theta.flatten()
            C_arr_2[t, :, :] = C
            Xt = X[t, :].reshape((d, 1))
            loglik[i] = (
                loglik[i]
                - 0.5 * np.log(sig2 + Xt.T @ (P @ Xt)) / n
                - 0.5
                * (y[t] - ((theta + (C @ theta_1)).T @ Xt)) ** 2
                / (sig2 + Xt.T @ (P @ Xt))
                / n
            )
            P = P - (P @ Xt) @ (P @ Xt).T / (sig2 + Xt.T @ (P @ Xt))
            P_arr[t, :, :] = P
            theta = theta + (P @ Xt) * (y[t] - (theta.T @ Xt)) / sig2
            theta_arr[t, :] = theta.flatten()
            C = (np.eye(d) - ((P @ Xt) @ Xt.T) / sig2) @ C
            C_arr[t, :, :] = C
            P = P + Q
        Pn = P - Q

        # Smoothing
        Q_new = np.zeros((d, d))
        sig2_new = X[n - 1, :].T @ (Pn @ X[n - 1, :]) / n
        for t in range(n - 2, -1, -1):
            Pt = P_arr[t, :, :]
            Pt_inv = np.linalg.inv(Pt + Q)
            Q_new = Q_new + (Pn - Pn @ Pt_inv @ Pt - (Pn @ Pt_inv @ Pt).T) / (n - 1)
            thetat = np.array([theta_arr[t, :]]).T
            theta_arr[t, :] = (
                thetat + (Pt @ Pt_inv @ (theta_arr[t + 1, :].reshape((d, 1)) - thetat))
            ).flatten()
            Pn = Pt + Pt @ Pt_inv @ (Pn - Pt - Q) @ Pt_inv @ Pt
            Q_new = Q_new + Pn / (n - 1)
            sig2_new = sig2_new + (X[t, :].T @ (Pn @ X[t, :])) / n
            C = C_arr[t, :, :] + Pt @ Pt_inv @ (C - C_arr[t, :, :])
            C_arr[t, :, :] = C

        # M-step
        # Update theta_1
        A = Lambda * np.eye(d)
        b = np.zeros((d, 1))
        for t in range(n):
            Xt = X[t, :].reshape((d, 1))
            Ct = C_arr_2[t, :, :]
            _crossprod = Ct.T @ Xt
            A = A + (_crossprod @ _crossprod.T)
            b = b + (y[t] - theta_arr_2[t, :].T @ Xt) * _crossprod
        theta_1 = np.linalg.solve(A, b)

        for t in range(n):
            theta_arr[t, :] = theta_arr[t, :] + C_arr[t, :, :] @ theta_1.flatten()

        Q_last = Q.copy()
        Q = Q_new.copy()

        for t in range(n - 1):
            delta_theta = (theta_arr[t + 1, :] - theta_arr[t, :]).reshape((d, 1))
            Q += np.dot(
                delta_theta,
                delta_theta.T,
            ) / (n - 1)
        Q = (Q + Q.T) / 2
        if mode_diag:
            Q = np.diag(np.diag(Q))
        sig2 = sig2_new

        for t in range(n):
            sig2 = sig2 + (y[t] - theta_arr[t, :].T @ X[t, :]) ** 2 / n

        diff[i] = np.sqrt(
            np.sum(np.diag((Q - Q_last).T @ (Q - Q_last)))
            / np.sum(np.diag(Q_last.T @ Q_last))
        )
        if verbose > 0 and i % verbose == 0:
            print(
                f"Iteration: {i} | Relative variation of Q: {diff[i]} | Log-likelihood: {loglik[i]}"
            )
            flag_decrease = False
        if verbose > 0:
            if not np.allclose(Q, Q.T, atol=1e-6):
                print("Q is not symmetric")
            if np.min(np.linalg.eigvals(Q)) < 0:
                print("Q is not positive")
        if i > 1:
            if loglik[i] < loglik[i - 1] and not flag_decrease:
                print("Log-likelihood is decreasing")
                flag_decrease = True
    if verbose > 0:
        print(
            f"Computation time of the expectation-maximization: \
                {datetime.now() - init_time}"
        )
    return {
        "P": np.eye(d) * p1,
        "theta": theta_1,
        "Q": Q,
        "sig": np.sqrt(sig2),
        "diff": diff,
        "loglik": loglik,
    }
