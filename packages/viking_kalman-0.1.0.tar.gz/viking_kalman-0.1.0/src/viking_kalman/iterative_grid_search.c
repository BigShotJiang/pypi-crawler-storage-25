/*
 * Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
 * Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
 * The original R package Viking is distributed under the terms of the license GNU LGPL 3.
 *
 * --------------------------------------------------------------------------------
 * This file is part of the Python port of the Viking package.
 * Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
 *
 * Project Supervisor, Packaging, and Documentation: Yann Allioux
 * Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * --------------------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdbool.h>

#include <Python.h>

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include <numpy/ndarrayobject.h>

typedef struct { 
    double* thetastar_arr;
    double* Pstar_arr;
    double* C_arr;
} Results;

extern double loglik(double** X, double* y, double** Qstar, int* use,int n ,int d,double p1,int* train_theta1, int* train_Q, const char *mode,int size_theta1, int size_Q);
extern Results parameters_star(double** X, double* y, double** Qstar, double p1,int n, int d);
extern double get_sig(double** X, double* y, Results par, double** Qstar, int* use,int n, int d);
extern double* get_theta1(double** X, double* y, Results par, double** Qstar, int* use,int n, int d, const char *mode);

typedef struct {
    double* theta;
    double** P;
    double sig;
    double** Q;
    double* LOGLIK;
    int size;
} Result;

typedef struct Node {
    double value;     
    struct Node* next;
} Node;

Node* create_node(double value) {
    Node* new_node = (Node*)malloc(sizeof(Node));
    if (new_node == NULL) {
        return NULL;
    }
    new_node->value = value;
    new_node->next = NULL;
    return new_node;
}

void append(Node** head, double value) {
    Node* new_node = create_node(value);
    if (new_node == NULL) return;
    
    if (*head == NULL) {
        *head = new_node; 
    } else {
        Node* temp = *head;
        while (temp->next != NULL) {
            temp = temp->next; 
        }
        temp->next = new_node; 
    }
}

Result iterative_grid_search(
    double** X, 
    double* y, 
    double* q_list, 
    int n,         
    int d, 
    int q_list_size, 
    double** Q_init, 
    int max_iter, 
    int delay, 
    int* use,  
    int* restrict_par, 
    const char *mode, 
    double p1, 
    int ncores, 
    int* train_theta1, 
    int* train_Q, 
    int size_theta1, 
    int size_Q, 
    int size_restr,
    bool verbose 
) { 

    bool alloc_train_theta1 = (train_theta1 == NULL);
    if (alloc_train_theta1) {
        size_theta1 = n;
        train_theta1 = (int*)malloc(n * sizeof(int));
        for (int i = 0; i < n; i++) train_theta1[i] = i;
    }

    bool alloc_train_Q = (train_Q == NULL);
    if (alloc_train_Q) {
        size_Q = n;
        train_Q = (int*)malloc(n * sizeof(int));
        for (int i = 0; i < n; i++) train_Q[i] = i;
    }
    
    double** Qstar;
    if (Q_init != NULL) {
        Qstar = (double**)malloc(d * sizeof(double*));
        for (int i = 0; i < d; i++) {
            Qstar[i] = (double*)calloc(d, sizeof(double));
            Qstar[i][i] = Q_init[i][i];
        }
    } else {
        Qstar = (double**)calloc(d, sizeof(double*));
        for (int i = 0; i < d; i++) Qstar[i] = (double*)calloc(d, sizeof(double));
    }

    bool alloc_use = (use == NULL);
    if (alloc_use) {
        use = (int*)malloc((n+1) * sizeof(int));
        for (int i = 0; i < n + 1; i++) use[i] = (int)fmax(i - delay, -1);
    }

    int* search_dimensions;
    int s=0;
    if (restrict_par != NULL) {
        search_dimensions = (int*)malloc(size_restr * sizeof(int));
        s = size_restr;
        for (int i = 0; i < size_restr; i++) search_dimensions[i] = restrict_par[i];
    } else {
        search_dimensions = (int*)malloc(d * sizeof(int));
        s = d;
        for (int i = 0; i < d; i++) search_dimensions[i] = i;
    }

    bool b = true;
    double l_opt = loglik(X, y, Qstar, use, n, d, p1, train_theta1, train_Q, mode, size_theta1, size_Q);
    int n_iter = 0;
    Node* LOGLIK = NULL;
    double* l_arr = (double*)malloc(q_list_size * sizeof(double));

    while (b) {
        n_iter++;
        b = n_iter < max_iter || max_iter == 0;
        int i = -1;
        double q_i = 0;

        for (int k = 0; k < s; k++) {
            double q_prev = Qstar[search_dimensions[k]][search_dimensions[k]];
            for (int j = 0; j < q_list_size; j++) {
                Qstar[search_dimensions[k]][search_dimensions[k]] = q_list[j];
                l_arr[j] = loglik(X, y, Qstar, use, n, d, p1, train_theta1, train_Q, mode, size_theta1, size_Q);
            }

            double max_l = l_arr[0];
            int max_index = 0;
            for (int j = 1; j < q_list_size; j++) {
                if (!isnan(l_arr[j]) && (isnan(max_l) || l_arr[j] > max_l)) {
                    max_l = l_arr[j];
                    max_index = j;
                }
            }
            if (!isnan(max_l) && (isnan(l_opt) || max_l > l_opt)) {
                l_opt = max_l;
                i = search_dimensions[k];
                q_i = q_list[max_index];
            }    
            Qstar[search_dimensions[k]][search_dimensions[k]] = q_prev;
        }
        append(&LOGLIK, l_opt);

        if (i == -1) {
            b = false;
        } else {
            Qstar[i][i] = q_i;
        }
    }

    Results par = parameters_star(X, y, Qstar, p1, n, d);
    double sig = get_sig(X, y, par, Qstar, use, n, d);

    Result result;
    result.theta = get_theta1(X, y, par, Qstar, use, n, d, mode);
    
    if (result.theta == NULL) {
        result.P = NULL;
        result.Q = NULL;
        result.LOGLIK = NULL;
        result.size = 0;
        result.sig = -1.0;
    } else {
        result.P = (double**)malloc(d * sizeof(double*));
        for (int i = 0; i < d; i++) {
            result.P[i] = (double*)calloc(d, sizeof(double));
            result.P[i][i] = p1 * sig * sig;
        }
        result.sig = sig;
        result.Q = (double**)malloc(d * sizeof(double*));
        for (int i = 0; i < d; i++) {
            result.Q[i] = (double*)malloc(d * sizeof(double));
            for (int j = 0; j < d; j++) {
                result.Q[i][j] = Qstar[i][j] * sig * sig;
            }
        }
        int size = 0;
        Node* temp = LOGLIK;
        while (temp != NULL) {
            size++;
            temp = temp->next;
        }
        result.LOGLIK = (double*)malloc(size * sizeof(double));
        if (result.LOGLIK == NULL) {
            result.size = 0;
        } else {
            temp = LOGLIK;
            int index = 0;
            while (temp != NULL) {
                result.LOGLIK[index] = temp->value;
                index++;
                Node* next_node = temp->next;
                free(temp);
                temp = next_node;
            }
            result.size = size;
        }
    }

    for (int i = 0; i < d; i++) {
        free(Qstar[i]);
    }
    free(Qstar);
    free(search_dimensions);
    if (alloc_train_theta1) free(train_theta1);
    if (alloc_train_Q) free(train_Q);
    if (alloc_use) free(use);
    free(l_arr);

    free(par.thetastar_arr);
    free(par.Pstar_arr);
    free(par.C_arr);

    return result;
}

static PyObject* iterative_grid_search_wrapper(PyObject* self, PyObject* args, PyObject* kwargs) {
    PyObject *X_array = NULL, *y_array = NULL, *q_list_list = NULL;
    PyObject *Q_init_array = Py_None;
    PyObject *use_list = Py_None;
    PyObject *restrict_par_list = Py_None;
    PyObject *train_theta1_list = Py_None;
    PyObject *train_Q_list = Py_None;
    const char *mode_str = "gaussian";
    int max_iter = 0;
    int delay = 1;
    int ncores = 1;
    double p1 = 0;
    bool verbose = true;

    if (args != NULL) {
        PyObject *arg1 = PyTuple_GetItem(args, 0); 
        PyObject *arg2 = PyTuple_GetItem(args, 1); 
        PyObject *arg3 = PyTuple_GetItem(args, 2); 

        if (arg1 != NULL) X_array = arg1;
        if (arg2 != NULL) y_array = arg2;
        if (arg3 != NULL) q_list_list= arg3;
    }

    if (kwargs != NULL) {
        PyObject *temp;
        
        temp = PyDict_GetItemString(kwargs, "Q_init");
        if (temp != NULL && temp != Py_None) Q_init_array = temp;

        temp = PyDict_GetItemString(kwargs, "use");
        if (temp != NULL && temp != Py_None) use_list = temp;

        temp = PyDict_GetItemString(kwargs, "restrict_par");
        if (temp != NULL && temp != Py_None) restrict_par_list = temp;

        temp = PyDict_GetItemString(kwargs, "mode");
        if (temp != NULL) mode_str = PyUnicode_AsUTF8(temp);

        temp = PyDict_GetItemString(kwargs, "max_iter");
        if (temp != NULL) max_iter = (int)PyLong_AsLong(temp);

        temp = PyDict_GetItemString(kwargs, "delay");
        if (temp != NULL) delay = (int)PyLong_AsLong(temp);

        temp = PyDict_GetItemString(kwargs, "ncores");
        if (temp != NULL) ncores = (int)PyLong_AsLong(temp);

        temp = PyDict_GetItemString(kwargs, "p1");
        if (temp != NULL) p1 = PyFloat_AsDouble(temp);

        temp = PyDict_GetItemString(kwargs, "verbose");
        if (temp != NULL) verbose = (temp == Py_True) ? true : false;

        temp = PyDict_GetItemString(kwargs, "train_theta1");
        if (temp != NULL && temp != Py_None) train_theta1_list = temp;

        temp = PyDict_GetItemString(kwargs, "train_Q");
        if (temp != NULL && temp != Py_None) train_Q_list = temp;
    }
   
    PyArrayObject *X_array_obj = (PyArrayObject *)X_array;
    PyArrayObject *y_array_obj = (PyArrayObject *)y_array;
   
    int n = (int)PyArray_DIM(X_array_obj, 0);
    int d = (int)PyArray_DIM(X_array_obj, 1);

    double **X = NULL;
    double *y = NULL;
    double *q_list = NULL;
    double **Q_init = NULL;
    int q_init_rows = 0;
    int q_list_size = 0;
    int *use = NULL;
    int *restrict_par = NULL;
    int size_restr = 0;
    int *train_theta1 = NULL;
    int size_theta1 = 0;
    int *train_Q = NULL;
    int size_Q = 0;
    PyObject *result_dict = NULL;

    X = (double **)malloc(n * sizeof(double *));
    if (X == NULL) {
        PyErr_SetString(PyExc_MemoryError, "Failed to allocate X");
        goto cleanup; 
    }
    for (int i = 0; i < n; i++) X[i] = NULL;
    
    for (int i = 0; i < n; i++) {
        X[i] = (double *)malloc(d * sizeof(double));
        if (X[i] == NULL) {
            PyErr_SetString(PyExc_MemoryError, "Failed to allocate row in X");
            goto cleanup; 
        }
        for (int j = 0; j < d; j++) {
            X[i][j] = *(double *)PyArray_GETPTR2(X_array_obj, i, j);
        }
    }

    y = (double *)malloc(n * sizeof(double));
    if (y == NULL) {
        PyErr_SetString(PyExc_MemoryError, "Failed to allocate y");
        goto cleanup;
    }
    for (int i = 0; i < n; i++) {
        y[i] = *(double *)PyArray_GETPTR1(y_array_obj, i);
    }

    q_list_size = (int)PyList_Size(q_list_list);
    q_list = (double *)malloc(q_list_size * sizeof(double));
    if (q_list == NULL) {
        PyErr_SetString(PyExc_MemoryError, "Failed to allocate q_list");
        goto cleanup;
    }
    for (int i = 0; i < q_list_size; i++) {
        q_list[i] = PyFloat_AsDouble(PyList_GetItem(q_list_list, i));
    }

    if (Q_init_array != Py_None) {
        PyArrayObject *Q_init_array_obj = (PyArrayObject *)Q_init_array;

        if (PyArray_NDIM(Q_init_array_obj) != 2) {
            PyErr_SetString(PyExc_ValueError, "Q_init must be a 2D array");
            goto cleanup;
        }

        q_init_rows = (int)PyArray_DIM(Q_init_array_obj, 0);
        int q_init_cols = (int)PyArray_DIM(Q_init_array_obj, 1);

        if (q_init_cols != d) {
            PyErr_SetString(PyExc_ValueError, "Q_init must have the same number of columns as X");
            goto cleanup;
        }

        Q_init = (double **)malloc(q_init_rows * sizeof(double *));
        if (Q_init == NULL) {
            PyErr_SetString(PyExc_MemoryError, "Failed to allocate Q_init");
            goto cleanup;
        }
        for (int i = 0; i < q_init_rows; i++) Q_init[i] = NULL;
        
        for (int i = 0; i < q_init_rows; i++) {
            Q_init[i] = (double *)malloc(q_init_cols * sizeof(double));
            if (Q_init[i] == NULL) {
                PyErr_SetString(PyExc_MemoryError, "Failed to allocate row in Q_init");
                goto cleanup;
            }
            for (int j = 0; j < q_init_cols; j++) {
                Q_init[i][j] = *(double *)PyArray_GETPTR2(Q_init_array_obj, i, j);
            }
        }
    }

    if (use_list != Py_None) {
        int use_size = (int)PyList_Size(use_list);
        use = (int *)malloc(use_size * sizeof(int));
        if (use == NULL) {
            PyErr_SetString(PyExc_MemoryError, "Failed to allocate use");
            goto cleanup;
        }
        for (int i = 0; i < use_size; i++) {
            use[i] = (int)PyLong_AsLong(PyList_GetItem(use_list, i));
        }
    }

    if (restrict_par_list != Py_None) {
        size_restr = (int)PyList_Size(restrict_par_list);
        restrict_par = (int *)malloc(size_restr * sizeof(int));
        if (restrict_par == NULL) {
            PyErr_SetString(PyExc_MemoryError, "Failed to allocate restrict_par");
            goto cleanup;
        }
        for (int i = 0; i < size_restr; i++) {
            restrict_par[i] = (int)PyLong_AsLong(PyList_GetItem(restrict_par_list, i));
        }
    }

    if (train_theta1_list != Py_None) {
        size_theta1 = (int)PyList_Size(train_theta1_list);
        train_theta1 = (int *)malloc(size_theta1 * sizeof(int));
        if (train_theta1 == NULL) {
            PyErr_SetString(PyExc_MemoryError, "Failed to allocate train_theta1");
            goto cleanup;
        }
        for (int i = 0; i < size_theta1; i++) {
            train_theta1[i] = (int)PyLong_AsLong(PyList_GetItem(train_theta1_list, i));
        }
    }

    if (train_Q_list != Py_None) {
        size_Q = (int)PyList_Size(train_Q_list);
        train_Q = (int *)malloc(size_Q * sizeof(int));
        if (train_Q == NULL) {
            PyErr_SetString(PyExc_MemoryError, "Failed to allocate train_Q");
            goto cleanup;
        }
        for (int i = 0; i < size_Q; i++) {
            train_Q[i] = (int)PyLong_AsLong(PyList_GetItem(train_Q_list, i));
        }
    }

    Result result = iterative_grid_search(X, y, q_list, n, d, q_list_size, Q_init, max_iter, delay, 
                                          use, restrict_par, mode_str, p1, ncores, train_theta1, 
                                          train_Q, size_theta1, size_Q, size_restr, verbose);

    if (result.theta == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "GSL matrix solver failed.");
        goto cleanup;
    }

    result_dict = PyDict_New();

    PyObject *theta_list = PyList_New(d);
    for (int i = 0; i < d; i++) {
        PyObject *row = PyList_New(1);
        PyList_SetItem(row, 0, PyFloat_FromDouble(result.theta[i]));
        PyList_SetItem(theta_list, i, row);
    }
    PyDict_SetItemString(result_dict, "theta", theta_list);
    Py_DECREF(theta_list);

    PyObject *P_list = PyList_New(d);
    for (int i = 0; i < d; i++) {
        PyObject *P_row = PyList_New(d);
        for (int j = 0; j < d; j++) {
            PyList_SetItem(P_row, j, PyFloat_FromDouble(result.P[i][j]));
        }
        PyList_SetItem(P_list, i, P_row);
    }
    PyDict_SetItemString(result_dict, "P", P_list);
    Py_DECREF(P_list);

    PyObject* sig_val = PyFloat_FromDouble(result.sig);
    PyDict_SetItemString(result_dict, "sig", sig_val);
    Py_DECREF(sig_val);

    PyObject *Q_list = PyList_New(d);
    for (int i = 0; i < d; i++) {
        PyObject *Q_row = PyList_New(d);
        for (int j = 0; j < d; j++) {
            PyList_SetItem(Q_row, j, PyFloat_FromDouble(result.Q[i][j]));
        }
        PyList_SetItem(Q_list, i, Q_row);
    }
    PyDict_SetItemString(result_dict, "Q", Q_list);
    Py_DECREF(Q_list);

    PyObject *LOGLIK_list = PyList_New(result.size);
    for (int i = 0; i < result.size; i++) {
        PyObject *py_value = PyFloat_FromDouble(result.LOGLIK[i]);
        PyList_SetItem(LOGLIK_list, i, py_value);
    }
    PyDict_SetItemString(result_dict, "LOGLIK", LOGLIK_list);
    Py_DECREF(LOGLIK_list);

    if (result.theta != NULL) free(result.theta);
    if (result.P != NULL) {
        for (int i = 0; i < d; i++) {
            if (result.P[i] != NULL) free(result.P[i]);
        }
        free(result.P);
    }
    if (result.Q != NULL) {
        for (int i = 0; i < d; i++) {
            if (result.Q[i] != NULL) free(result.Q[i]);
        }
        free(result.Q);
    }
    if (result.LOGLIK != NULL) free(result.LOGLIK);

cleanup:
    if (X != NULL) {
        for (int i = 0; i < n; i++) {
            if (X[i] != NULL) free(X[i]);
        }
        free(X);
    }
    if (y != NULL) free(y);
    if (q_list != NULL) free(q_list);
    
    if (Q_init != NULL) {
        for (int i = 0; i < q_init_rows; i++) {
            if (Q_init[i] != NULL) free(Q_init[i]);
        }
        free(Q_init);
    }

    if (use != NULL) free(use);
    if (restrict_par != NULL) free(restrict_par);
    if (train_theta1 != NULL) free(train_theta1);
    if (train_Q != NULL) free(train_Q);

    return result_dict;
}

static PyMethodDef YourMethods[] = {
    {"iterative_grid_search", (PyCFunction)iterative_grid_search_wrapper, METH_VARARGS | METH_KEYWORDS, ""},
    {NULL, NULL, 0, NULL}  
};

static struct PyModuleDef yourmodule = {
    PyModuleDef_HEAD_INIT,
    "grid", 
    "", 
    -1,   
    YourMethods
};

PyMODINIT_FUNC PyInit_grid(void) {  
    import_array();  
    return PyModule_Create(&yourmodule);
}