# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import numpy as np


def iterative_grid_search(
    X,
    y,
    q_list,
    Q_init=None,
    max_iter=0,
    delay=1,
    use=None,
    restrict=None,
    mode="gaussian",
    p1=0,
    ncores=1,
    train_theta1=None,
    train_Q=None,
    verbose=True,
):
    """
    Performs an iterative grid search to select hyperparameters. This function
    acts as a dispatcher, calling an optimized C extension if successfully compiled
    on the user's system, or a pure Python fallback otherwise.

    Parameters
    ----------
    X : np.ndarray
        The explanatory variables.
    y : np.ndarray
        The observations.
    q_list : list
        The list of possible values for the diagonal elements of `Q / sig^2`.
    Q_init : np.ndarray, optional
        Initial value of `Q / sig^2`. If None, it is set to a zero matrix, by default None.
    max_iter : int, optional
        Maximal number of iterations. If 0, optimization continues as long as
        the log-likelihood can be improved, by default 0.
    delay : int, optional
        To predict `y[t]`, the model has access to `y[t-delay]`, by default 1.
    use : list, optional
        The availability variable, by default None.
    restrict : list, optional
        If not None, specifies the indices of the diagonal coefficients of Q to optimize,
        by default None.
    mode : str, optional
        The calculation mode, by default "gaussian".
    p1 : float, optional
        Coefficient for `P1/sig^2 = p1 * I`, by default 0.
    ncores : int, optional
        Number of available cores for computation, by default 1.
    train_theta1 : list, optional
        Training set indices for the estimation of `theta1`, by default None.
    train_Q : list, optional
        Time step indices on which the log-likelihood is computed, by default None.
    verbose : bool, optional
        Whether to print intermediate progress, by default True.

    Returns
    -------
    dict
        A dictionary containing the estimated parameters: `theta`, `P`, `sig`, `Q`,
        and `LOGLIK` (the evolution of the log-likelihood during the search).
    """
    X = X.astype(np.float64) if X.dtype != np.float64 else X
    y = y.astype(np.float64) if y.dtype != np.float64 else y
    q_list = list(q_list)
    Q_init = np.array(Q_init) if Q_init is not None else Q_init
    use = list(use) if use is not None else use
    restrict = list(restrict) if restrict is not None else restrict
    train_theta1 = list(train_theta1) if train_theta1 is not None else train_theta1
    train_Q = list(train_Q) if train_Q is not None else train_Q

    try:
        from viking_kalman import grid

        return grid.iterative_grid_search(
            X,
            y,
            q_list,
            Q_init=Q_init,
            max_iter=max_iter,
            delay=delay,
            use=use,
            restrict_par=restrict,
            mode=mode,
            p1=p1,
            ncores=ncores,
            train_theta1=train_theta1,
            train_Q=train_Q,
            verbose=verbose,
        )
    except ImportError as e:
        if verbose:
            print(f"Warning: Optimized C extension not found. Reason: {e}")
            print("Using pure Python fallback. Execution will take longer.")
        from . import iterative_grid_search_other as iter

        return iter.iterative_grid_search(
            X,
            y,
            q_list,
            Q_init=Q_init,
            max_iter=max_iter,
            delay=delay,
            use=use,
            restrict=restrict,
            mode=mode,
            p1=p1,
            ncores=ncores,
            train_theta1=train_theta1,
            train_Q=train_Q,
            verbose=verbose,
        )
