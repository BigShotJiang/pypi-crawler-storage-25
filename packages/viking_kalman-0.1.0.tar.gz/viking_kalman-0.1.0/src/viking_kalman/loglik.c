/*
 * Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
 * Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
 * The original R package Viking is distributed under the terms of the license GNU LGPL 3.
 *
 * --------------------------------------------------------------------------------
 * This file is part of the Python port of the Viking package.
 * Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
 *
 * Project Supervisor, Packaging, and Documentation: Yann Allioux
 * Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * --------------------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdbool.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#define PY_SSIZE_T_CLEAN

typedef struct {
    double* thetastar_arr;
    double* Pstar_arr;
    double* C_arr;
} Results;

Results parameters_star(double** X , double* y , double** Qstar, double p1, int n, int d) {
    double* thetastar = (double*)malloc(d * sizeof(double));
    double* Pstar = (double *)malloc(d*d* sizeof(double));
    double* C = (double *)malloc(d*d* sizeof(double));
    double* thetastar_new = (double *)malloc(d* sizeof(double));
    double* Pstar_new = (double *)malloc(d*d* sizeof(double));
    double* C_new = (double *)malloc(d*d* sizeof(double));
    double* Xt=(double *)malloc(d * sizeof(double));
    double* Pr = (double*)malloc(d * sizeof(double));
    double* PP = (double*)malloc(d * d* sizeof(double));
    double* Pstar_Xt = (double*)malloc(d * sizeof(double));
    double* result_matrix = (double*)malloc(d*d*sizeof(double));
    double* result_matri = (double*)malloc(d*d*sizeof(double));  

    memset(thetastar, 0, d * sizeof(double));
    memset(Pstar, 0, d * d * sizeof(double));
    memset(C, 0, d * d * sizeof(double));
    memset(C_new, 0, d * d * sizeof(double));

    for (int i = 0; i < d; i++) {
        for (int j = 0; j < d; j++) {
            if (i == j) {
                C[i * d + j] = 1.0;  
            } else {
                C[i * d + j] = 0.0;  
            }
        }
    }

    for (int i = 0; i < d; i++) {
        for (int j = 0; j < d; j++) {
            if (i == j) {
                Pstar[i * d + j] = p1; 
            } else {
                Pstar[i * d + j] = 0.0;  
            }
        }
    }

    Results result;
    result.thetastar_arr =(double *)malloc((n+1)*d * sizeof(double));
    result.Pstar_arr = (double *)malloc((n+1)*d *d* sizeof(double));
    result.C_arr = (double *)malloc((n+1)*d *d* sizeof(double));

    memset(result.thetastar_arr, 0, (n+1)*d * sizeof(double));
    memset(result.Pstar_arr, 0,(n+1)* d * d * sizeof(double));
    memcpy(result.C_arr, C, d * d * sizeof(double));

    for (int t = 0; t < n; t++) {
        for (int i = 0; i < d; i++) {
            Xt[i] = X[t][i];
        }

        double err = y[t];
        for (int i = 0; i < d; i++) {
            err -= thetastar[i] * Xt[i];
        }

        double inv = 1.0;
        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                inv += Xt[i] * Pstar[i*d+j] * Xt[j];
            }
        }
        if (inv != 0.0) {
            inv = 1.0 / inv;
        }

        for (int i = 0; i < d; i++) {
            double temp = 0;
            for (int j = 0; j < d; j++) {
                temp += Pstar[i*d+j] * Xt[j];
            }
            thetastar_new[i] = thetastar[i] + inv * err * temp;
        }

        for (int i = 0; i < d; i++) {
            Pr[i]=0;
            for (int j = 0; j < d; j++) {
                Pr[i]+=Pstar[i*d + j] * Xt[j];
            }
        }

        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                PP[i*d+j]=Pr[i] * Pr[j];
            }
        }

        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                Pstar_new[i*d+j] = Pstar[i*d+j] +(Qstar[i][j]) -(inv *PP[i*d+j]);
            }
        }

        for (int i = 0; i < d; i++) {
            Pstar_Xt[i] = 0.0;
            for (int k = 0; k < d; k++) {
                Pstar_Xt[i] += Pstar[i * d + k] * Xt[k];  
            }
        }

        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                result_matrix[i * d + j] = Pstar_Xt[i] * Xt[j]*inv; 
            }
        }

        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                if (i == j) {
                    result_matri[i * d + j] =(1-result_matrix[i * d + j]);  
                }else{
                    result_matri[i * d + j] =-result_matrix[i * d + j];
                }
            }
        }

        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                for (int k = 0; k < d; k++) {
                    C_new[i * d + j] += result_matri[i * d + k] * C[k * d + j]; 
                }
            }
        }

        memcpy(thetastar, thetastar_new, d * sizeof(double));
        memcpy(Pstar, Pstar_new, d * d * sizeof(double));
        memcpy(C, C_new, d * d * sizeof(double));

        memcpy(result.thetastar_arr + (t + 1) * d, thetastar, d * sizeof(double));
        memcpy(result.Pstar_arr + (t + 1) * d * d, Pstar, d * d * sizeof(double));
        memcpy(result.C_arr+ (t + 1) * d * d, C, d * d * sizeof(double));
        memset(C_new, 0, d * d * sizeof(double));
    }

    free(Xt);
    free(thetastar);
    free(thetastar_new);
    free(Pstar);
    free(Pstar_new);
    free(C_new);
    free(C);
    free(PP);
    free(Pr);
    free(Pstar_Xt);
    free(result_matri);
    free(result_matrix);

    return result;
}

double* get_theta1(double** X, double* y, Results par, double** Qstar, int* use, int n, int d, const char* mode) {
    double* A = (double *)malloc(d * d * sizeof(double));  
    double* b = (double *)malloc(d * sizeof(double));      
    double* Xt = (double *)malloc(d * sizeof(double));     
    double* Zt = (double *)malloc(d * sizeof(double));
    double* x = (double *)malloc(d * sizeof(double));   

    for (int i = 0; i < d; i++) {
        b[i] = 0.0;
        for (int j = 0; j < d; j++) {
            A[i * d + j] = 0.0;
        }
    }

    for (int t = 0; t < n; t++) {
        for (int i = 0; i < d; i++) {
            Xt[i] = X[t][i];
        }

        double err = y[t];
        for (int i = 0; i < d; i++) {
            err -= par.thetastar_arr[(use[t] + 1) * d + i] * Xt[i];
        }

        double inv = 1.0;

        if (strcmp(mode, "gaussian") == 0) {
            double temp = 0.0;
            for (int i = 0; i < d; i++) {
                for (int j = 0; j < d; j++) {
                    temp += Xt[i] * (par.Pstar_arr[(use[t] + 1) * d * d + i * d + j] + fmax(0, t - use[t] - 1) * Qstar[i][j]) * Xt[j];
                }
            }
            inv = 1.0 / (1.0 + temp);
        }

        for (int i = 0; i < d; i++) {
            Zt[i] = 0.0;
            for (int j = 0; j < d; j++) {
                Zt[i] += par.C_arr[(use[t] + 1) * d * d + j * d + i] * Xt[j];
            }
        }

        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                A[i * d + j] += Zt[i] * Zt[j] * inv;
            }
            b[i] += Zt[i] * err * inv;
        }
    }

    gsl_matrix *gsl_A = gsl_matrix_alloc(d, d);
    gsl_vector *gsl_b = gsl_vector_alloc(d);
    gsl_vector *gsl_x = gsl_vector_alloc(d);

    for (int i = 0; i < d; i++) {
        gsl_vector_set(gsl_b, i, b[i]);
        gsl_vector_set(gsl_x, i, 0.0);  
        for (int j = 0; j < d; j++) {
            gsl_matrix_set(gsl_A, i, j, A[i * d + j]);
        }
    }
    
    int info = gsl_linalg_HH_solve(gsl_A, gsl_b, gsl_x);

    if (info == 0) {
        for (int i = 0; i < d; i++) {
            x[i] = gsl_vector_get(gsl_x, i);
        }
    } else {
        gsl_matrix_free(gsl_A);
        gsl_vector_free(gsl_b);
        gsl_vector_free(gsl_x);
        free(Xt);
        free(Zt);
        free(A);
        free(b);
        free(x);
        return NULL; 
    }

    gsl_matrix_free(gsl_A);
    gsl_vector_free(gsl_b);
    gsl_vector_free(gsl_x);
    free(Xt);
    free(Zt);
    free(A);
    free(b);
    return x;
}

double get_sig(double **X, double *y, Results par, double **Qstar, int *use, int n, int d) {
    double* x = get_theta1(X, y, par, Qstar, use, n, d, "gaussian");
    
    if (x == NULL) {
        return -1.0; 
    }
    
    double sig2 = 0.0;
    double* Xt = (double *)malloc(d* sizeof(double));
    double* P = (double *)malloc(d*d* sizeof(double));
    double* thetastar = (double *)malloc(d* sizeof(double));
    double* C_theta1 = (double *)malloc(d* sizeof(double));

    for (int t = 0; t < n; t++) {
        for (int i = 0; i < d; i++) {
            Xt[i] = X[t][i];
        }
        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                P[i*d+j] = par.Pstar_arr[(use[t] + 1)*d*d+i*d+j] + fmax(t - use[t] - 1, 0) * Qstar[i][j];
            }
        }
        for (int i = 0; i < d; i++) {
            thetastar[i] = par.thetastar_arr[(use[t] + 1)*d+i];
        }
        for (int i = 0; i < d; i++) {
            C_theta1[i] = 0.0;
            for (int j = 0; j < d; j++) {
                C_theta1[i] += par.C_arr[(use[t] + 1)*d*d+i*d+j] * x[j];
            }
        }

        double numerator = 0;
        for (int i = 0; i < d; i++) {
            numerator += (thetastar[i] + C_theta1[i]) * Xt[i];
        }
        numerator = y[t] - numerator;
        numerator = numerator * numerator;
        double denominator = 1.0;
        for (int i = 0; i < d; i++) {
            for (int j = 0; j < d; j++) {
                denominator += Xt[i] * P[i*d+j]* Xt[j];
            }
        }

        sig2 += numerator / denominator / n;
    }

    free(Xt);
    free(P);
    free(thetastar);
    free(C_theta1);
    free(x);
    return sqrt(sig2);
}

double loglik(double **X, double *y, double **Qstar, int *use, int n, int d, double p1,int *train_theta1, int *train_Q, const char *mode,int size_theta1,int size_Q) {
    double sum1 = 0.0;
    double sum2 = 0.0;

    Results par=parameters_star(X, y, Qstar, p1, n, d);  

    double** Xm = (double **)malloc(size_theta1 * sizeof(double *));  
    for (int i = 0; i < size_theta1; i++) {
        Xm[i] = (double *)malloc(d * sizeof(double));  
        for (int j = 0; j < d; j++) {
            Xm[i][j] = X[train_theta1[i]][j];
        }
    }

    double* ym=(double *)malloc(size_theta1* sizeof(double));
    for (int i = 0; i < size_theta1; i++) {
        ym[i] = y[train_theta1[i]];
    }

    double* x = get_theta1(Xm, ym, par, Qstar, use, size_theta1, d, mode);  

    if (x == NULL) {
        free(ym);
        for (int i = 0; i < size_theta1; i++) free(Xm[i]);
        free(Xm);
        free(par.thetastar_arr);
        free(par.Pstar_arr);
        free(par.C_arr);
        return NAN; 
    }

    double* Xt = (double *)malloc(d* sizeof(double));
    double* Pstar_arr = par.Pstar_arr;  
    double* thetastar_arr = par.thetastar_arr; 
    double* C_arr = par.C_arr;
    double* C_theta1 = (double*)malloc(d * sizeof(double));
    double* P=(double*)malloc(d *d* sizeof(double));
 
    for (int i = 0; i < size_Q; i++) {
        int t = train_Q[i]; 
        for (int j = 0; j < d; j++) {
            Xt[j] = X[t][j];
        }   

        for (int j = 0; j < d; j++) {
            for (int k = 0; k < d; k++) {
                P[j*d+k]=Pstar_arr [(use[t] + 1) * d * d+j*d+k]+fmax(0, t - use[t] - 1) * Qstar[j][k];
            }
        }
        double PXt_dot = 0.0;
        for (int j = 0; j < d; j++) {
            for (int k = 0; k < d; k++) {
                PXt_dot += P[j*d+k] * Xt[k]*Xt[j];
            }
        }

        sum1 += log(1 + PXt_dot) / size_Q;

        double err = y[t];
        for (int j = 0; j < d; j++) {
            C_theta1[j] = 0.0;
            for (int k = 0; k < d; k++) {
                C_theta1[j] += C_arr[(use[t] + 1) * d * d + j * d + k] * x[k];  
            }
        }
        for (int j = 0; j < d; j++) {
            double prediction = thetastar_arr[(use[t] + 1) * d + j] + C_theta1[j];
            err -= prediction * Xt[j];
        }
        err *= err; 

        if (strcmp(mode, "gaussian") == 0) {
            sum2 += err / (1 + PXt_dot) / size_Q;
        } else if (strcmp(mode, "rmse") == 0) {
            sum2 += err / n;
        }
    }

    free(Xt);
    free(x);
    free(Pstar_arr);
    free(thetastar_arr);
    free(C_arr); 
    free(C_theta1);
    free(ym);
    for (int i = 0; i < size_theta1; i++) {
        free(Xm[i]);
    }
    free(Xm);
    free(P);

    if (strcmp(mode, "gaussian") == 0) {
        return -0.5 * sum1 - 0.5 - 0.5 * log(2 * M_PI * sum2);
    } else if (strcmp(mode, "rmse") == 0) {
        return -sqrt(sum2);
    }
    return 0.0; 
}