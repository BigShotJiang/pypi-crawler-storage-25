# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import numpy as np


def kalman_filtering(X, y, theta1, P1, Q=0, sig=1):
    """
    Computes the filtered estimation of the state `theta` and its covariance `P`.

    This function is a direct port of the original R 'viking' package. It follows
    the specific formulation detailed in de Vilmarest (2022, Equations 5.3, 5.4),
    which ensures 1-to-1 numerical compatibility with the R package's output.

    Parameters
    ----------
    X : np.ndarray
        Explanatory variables matrix of shape (n, d).
    y : np.ndarray
        Time series of observations of shape (n,).
    theta1 : np.ndarray
        Initial state vector `theta` of shape (d,).
    P1 : np.ndarray
        Initial state covariance matrix `P` of shape (d, d).
    Q : np.ndarray or float, optional
        Process noise covariance matrix, by default 0.
    sig : float, optional
        Standard deviation of the observation noise, by default 1.

    Returns
    -------
    dict
        A dictionary containing the results of the filtering:
        - 'theta_arr': The sequence of filtered states (n, d).
        - 'P_arr': The sequence of filtered covariances (n, d, d).
        - 'theta': The final filtered state at time n.
        - 'P': The final filtered covariance at time n.

    References
    ----------
    [1] de Vilmarest, J. (2022). *State-space models for time series forecasting.
        Application to the electricity markets*. PhD Thesis, Sorbonne Université.
    """
    n, d = X.shape
    R = sig**2

    # Initialization
    theta_arr = np.zeros((n, d))
    P_arr = np.zeros((n, d, d))

    theta = np.array(theta1)
    P = np.array(P1)

    # Filtering loop
    for t in range(n):
        theta_arr[t, :] = theta.flatten()
        P_arr[t, :, :] = P

        Xt = X[t, :].reshape((-1, 1))

        if np.isfinite(Xt).all() and np.isfinite(y[t]):
            # Update P
            P_updated = P - (P @ Xt) @ (Xt.T @ P) / (Xt.T @ P @ Xt + R)

            # Update theta
            theta = theta + (P_updated @ Xt * (y[t] - theta.T @ Xt) / R).flatten()

            # Prediction step
            P = P_updated + Q

    return {"theta_arr": theta_arr, "P_arr": P_arr, "theta": theta, "P": P}
