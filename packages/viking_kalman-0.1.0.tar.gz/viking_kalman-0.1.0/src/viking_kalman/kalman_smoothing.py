# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import numpy as np


def kalman_smoothing(X, y, theta1, P1, Q=0, sig=1):
    """
    Computes the smoothed estimation of the state `theta` and its covariance `P`.

    Parameters
    ----------
    X : np.ndarray
        Explanatory variables matrix of shape (n, d).
    y : np.ndarray
        Time series of observations of shape (n,).
    theta1 : np.ndarray
        Initial state vector `theta` of shape (d,).
    P1 : np.ndarray
        Initial state covariance matrix `P` of shape (d, d).
    Q : np.ndarray or float, optional
        Process noise covariance matrix, by default 0.
    sig : float, optional
        Standard deviation of the observation noise, by default 1.

    Returns
    -------
    dict
        A dictionary containing the results of the smoothing:
        - 'theta_arr': The sequence of smoothed states (n, d).
        - 'P_arr': The sequence of smoothed covariances (n, d, d).

    References
    ----------
    [1] de Vilmarest, J. (2022). *State-space models for time series forecasting.
        Application to the electricity markets*. PhD Thesis, Sorbonne Université.
    """
    n, d = X.shape
    R = sig**2

    # Initialization
    theta_arr = np.zeros((n, d))
    P_arr = np.zeros((n, d, d))

    theta = np.array(theta1).copy()
    P = np.array(P1).copy()

    # Step 1: Forward Pass
    for t in range(n):
        Xt = X[t, :].reshape(-1, 1)

        if not (np.isnan(Xt).any() or np.isnan(y[t])):
            P = P - (P @ Xt) @ (Xt.T @ P) / ((Xt.T @ P @ Xt).item() + R)

        theta_arr[t, :] = theta.flatten()
        P_arr[t, :, :] = P

        if not (np.isnan(Xt).any() or np.isnan(y[t])):
            theta = (
                theta
                + (P @ Xt * (y[t] - (theta.T @ Xt.flatten()).item()) / R).flatten()
            )
            P = P + Q

    # Get the final P from the filtering pass
    Pn = P - Q

    # Step 2: Backward Pass
    for t in range(n - 2, -1, -1):
        Pt = P_arr[t, :, :]
        P_inv = np.linalg.inv(Pt + Q)

        thetat = theta_arr[t, :]
        theta_arr[t, :] = thetat + Pt @ P_inv @ (theta_arr[t + 1, :] - thetat)

        Pn = Pt + Pt @ P_inv @ (Pn - Pt - Q) @ P_inv @ Pt
        P_arr[t, :, :] = Pn

    return {"theta_arr": theta_arr, "P_arr": P_arr}
