# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import numpy as np


def parameters_star(X, y, Qstar, p1=0):
    """
    Computes intermediate star-parameters used for log-likelihood calculation.

    These parameters are calculated based on the scaled state covariance `Qstar`.
    This is an internal helper function for `loglik`.

    Parameters
    ----------
    X : np.ndarray
        Explanatory variables matrix.
    y : np.ndarray
        Time series of observations.
    Qstar : np.ndarray
        The ratio Q/sig^2.
    p1 : float, optional
        Coefficient for P1/sig^2 = p1 * I, by default 0.

    Returns
    -------
    dict
        A dictionary containing the intermediate arrays:
        `thetastar_arr`, `Pstar_arr`, `C_arr`.
    """

    n, d = np.shape(X)
    thetastar = np.zeros((d, 1))
    Pstar = p1 * np.eye(d)
    C = np.eye(d)
    thetastar_arr = np.zeros((n + 1, d))
    Pstar_arr = np.zeros((n + 1, d, d))
    C_arr = np.zeros((n + 1, d, d))
    C_arr[0, :, :] = C

    for t in range(n):
        Xt = np.transpose([X[t, :]])
        err = y[t] - np.dot(np.transpose(thetastar), Xt)[0, 0]
        inv = 1 / (1 + np.dot(np.transpose(Xt), np.dot(Pstar, Xt))[0, 0])

        thetastar_new = thetastar + inv * err * np.dot(Pstar, Xt)
        Pstar_new = (
            Pstar
            + Qstar
            - inv * np.dot(np.dot(Pstar, Xt), np.transpose(np.dot(Pstar, Xt)))
        )
        C_new = np.dot(np.eye(d) - np.dot(np.dot(Pstar, Xt), np.transpose(Xt)) * inv, C)

        thetastar = thetastar_new
        Pstar = Pstar_new
        C = C_new

        thetastar_arr[t + 1, :] = np.transpose(thetastar)
        Pstar_arr[t + 1, :, :] = Pstar
        C_arr[t + 1, :, :] = C

    return {"thetastar_arr": thetastar_arr, "Pstar_arr": Pstar_arr, "C_arr": C_arr}


def get_theta1(X, y, par, Qstar, use, mode="gaussian"):
    """
    Estimates the initial state vector `theta1` based on the star-parameters.

    This is an internal helper function for `loglik`.

    Parameters
    ----------
    X : np.ndarray
        Explanatory variables matrix.
    y : np.ndarray
        Time series of observations.
    par : dict
        The dictionary of star-parameters returned by `parameters_star`.
    Qstar : np.ndarray
        The ratio Q/sig^2.
    use : array-like
        The availability variable.
    mode : str, optional
        The calculation mode, by default "gaussian".

    Returns
    -------
    np.ndarray
        The estimated initial state vector `theta1`.
    """
    n, d = np.shape(X)
    A = np.zeros((d, d))
    b = np.zeros((d, 1))

    for t in range(n):
        Xt = np.transpose([X[t, :]])
        err = y[t] - np.dot(np.transpose(par["thetastar_arr"][use[t] + 1, :]), Xt)[0]
        inv = 1

        if mode == "gaussian":
            inv = 1 / (
                1
                + np.dot(
                    np.transpose(Xt),
                    np.dot(
                        par["Pstar_arr"][use[t] + 1, :, :]
                        + max(0, t - use[t] - 1) * Qstar,
                        Xt,
                    ),
                )[0, 0]
            )

        Ct_T = np.transpose(par["C_arr"][use[t] + 1, :, :])
        C_T_x = np.dot(Ct_T, Xt)

        A = A + np.dot(C_T_x, np.transpose(C_T_x)) * inv
        b = b + C_T_x * err * inv

    return np.linalg.solve(A, b)


def get_sig(X, y, par, Qstar, use):
    """
    Estimates the observation noise standard deviation `sig`.

    This is an internal helper function for `loglik`.

    Parameters
    ----------
    X : np.ndarray
        Explanatory variables matrix.
    y : np.ndarray
        Time series of observations.
    par : dict
        The dictionary of star-parameters returned by `parameters_star`.
    Qstar : np.ndarray
        The ratio Q/sig^2.
    use : array-like
        The availability variable.

    Returns
    -------
    float
        The estimated standard deviation `sig`.
    """
    n, d = np.shape(X)
    theta1 = get_theta1(X, y, par, Qstar, use)
    sig2 = 0

    for t in range(n):
        Xt = X[t, :].reshape(-1, 1)
        P = par["Pstar_arr"][use[t] + 1, :, :] + max(t - use[t] - 1, 0) * Qstar
        sig2 = (
            sig2
            + (
                y[t]
                - np.dot(
                    np.transpose(
                        par["thetastar_arr"][use[t] + 1, :].reshape(-1, 1)
                        + np.dot(par["C_arr"][use[t] + 1, :, :], theta1)
                    ),
                    Xt,
                )[0, 0]
            )
            ** 2
            / (1 + np.dot(np.transpose(Xt), np.dot(P, Xt))[0, 0])
            / n
        )

    return np.sqrt(sig2)


def loglik(X, y, Qstar, use, p1, train_theta1, train_Q, mode="gaussian"):
    """
    Computes the log-likelihood of a state-space model for specified hyperparameters.

    Calculates the log-likelihood for a given Q/sig^2, P1/sig^2, and theta1.

    Parameters
    ----------
    X : np.ndarray
        Explanatory variables matrix.
    y : np.ndarray
        Time series of observations.
    Qstar : np.ndarray
        The ratio Q/sig^2.
    use : array-like
        The availability variable.
    p1 : float
        Coefficient for P1/sig^2 = p1 * I.
    train_theta1 : array-like
        Training set indices for the estimation of `theta1`.
    train_Q : array-like
        Time step indices on which the log-likelihood is computed.
    mode : str, optional
        The calculation mode, can be 'gaussian' or 'rmse', by default "gaussian".

    Returns
    -------
    float
        A numeric value for the log-likelihood.
    """
    par = parameters_star(X, y, Qstar, p1)
    theta1 = get_theta1(X[train_theta1, :], y[train_theta1], par, Qstar, use, mode=mode)

    sum1 = 0
    sum2 = 0

    n = len(train_Q)

    for t in train_Q:
        Xt = np.transpose([X[t, :]])
        P = par["Pstar_arr"][use[t] + 1, :, :] + max(0, t - use[t] - 1) * Qstar

        sum1 = sum1 + np.log(1 + np.dot(np.transpose(Xt), np.dot(P, Xt))[0, 0]) / n

        err2 = (
            y[t]
            - np.dot(
                np.transpose(
                    par["thetastar_arr"][use[t] + 1, :].reshape(-1, 1)
                    + np.dot(par["C_arr"][use[t] + 1, :, :], theta1)
                ),
                Xt,
            )[0, 0]
        ) ** 2

        if mode == "gaussian":
            sum2 = sum2 + err2 / (1 + np.dot(np.transpose(Xt), np.dot(P, Xt))[0, 0]) / n
        elif mode == "rmse":
            sum2 = sum2 + err2 / n

    if mode == "gaussian":
        return -0.5 * sum1 - 0.5 - 0.5 * np.log(2 * np.pi * sum2)
    elif mode == "rmse":
        return -np.sqrt(sum2)
