# Copyright 2019-2022 EDF, Sorbonne Université and CNRS.
# Original Author : Joseph de Vilmarest (EDF, Sorbonne Université)
# The original R package Viking is distributed under the terms of the license GNU LGPL 3.

# --------------------------------------------------------------------------------
# This file is part of the Python port of the Viking package.
# Copyright 2024-2026 Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# Project Supervisor, Packaging, and Documentation: Yann Allioux
# Algorithm Porting: Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# --------------------------------------------------------------------------------

import numpy as np
from viking_kalman import kalman_smoothing, kalman_filtering, viking
import matplotlib.pyplot as plt
import scipy.stats as stats
import matplotlib.cm as cm
import pandas as pd


class StateSpaceModel:
    """
    Class to build and handle a state-space model.
    """

    X = None
    y = None
    ks = None
    kf = None
    vik = {}
    kalman_params = None
    viking_params = None
    pred_mean = None
    pred_sd = None

    def __init__(self, X, y, kalman_params=None, viking_params=None, **kwargs):
        """
        Builds a state-space model, with known or unknown variances.

        By default, it builds a static model with a constant state (Q=0) and
        constant observation noise variance.

        Parameters
        ----------
        X : np.ndarray
            Design matrix (n, d).
        y : np.ndarray
            Variable of interest (n,).
        kalman_params : dict, optional
            Dictionary containing initial values for `theta`, `P`, as well as
            the variances `Q` and `sig`. If not specified, a static model is
            built (theta=0, P=I, Q=0, sig=1).
        viking_params : dict, optional
            Dictionary of parameters for the Viking algorithm.
        """
        n, p = np.shape(X)

        # Create state-space object
        if p == 0:
            d = 1
        else:
            d = p
        if kalman_params is not None:
            kp = {
                "theta": np.ravel(kalman_params.get("theta", np.zeros(d))),
                "P": kalman_params.get("P", np.eye(d)),
                "Q": kalman_params.get("Q", np.zeros((d, d))),
                "sig": kalman_params.get("sig", 1),
                "opt_Kalman_call": kalman_params.get("opt_Kalman_call", []),
            }
        else:
            kp = {
                "theta": np.zeros((d,)),
                "P": np.eye(d),
                "Q": np.zeros((d, d)),
                "sig": 1,
                "opt_Kalman_call": [],
            }

        if viking_params is not None:
            vp = {
                "theta": np.ravel(viking_params.get("theta", np.zeros(d))),
                "P": viking_params.get("P", np.eye(d)),
                "hata": viking_params.get("hata", 0),
                "s": viking_params.get("s", 0),
                "mode": viking_params.get("mode", "diagonal"),
            }

            if vp["mode"] == "scalar":
                vp["hatb"] = viking_params.get("hatb", 0)
                vp["Sigma"] = viking_params.get("Sigma", 0)
            else:
                vp["hatb"] = np.zeros((d, 1))
                vp["Sigma"] = np.zeros((d, d))
        else:
            vp = None

        self.kalman_params = kp
        self.viking_params = vp
        self.predict(X, y, type="model", **kwargs)

    def predict(
        self,
        newX,
        newy=None,
        _type="model",
        online=True,
        compute_smooth=False,
        **kwargs,
    ):
        """
        Makes a prediction for a `StateSpaceModel` object, in online or offline mode.

        Parameters
        ----------
        newX : np.ndarray
            The design matrix for the prediction set.
        newy : np.ndarray, optional
            The variable of interest for the prediction set. If specified,
            allows using the model in online mode. Otherwise, the prediction is offline.
        _type : str, optional
            Type of prediction. Can be 'mean', 'proba', or 'model', by default 'model'.
            - 'mean': returns the mean forecast.
            - 'proba': returns a probabilistic forecast (mean and standard deviation).
            - 'model': returns the updated `StateSpaceModel` object.
        online : bool, optional
            Specifies if the prediction is made online, i.e., if the observation
            at time t-1 is used to update the model before predicting at time t,
            by default True.
        compute_smooth : bool, optional
            Specifies if Kalman Smoothing should also be computed, by default False.

        Returns
        -------
        np.ndarray or dict or StateSpaceModel
            The result depends on the `_type` parameter.
        """

        if _type not in ("mean", "proba", "model"):
            raise ValueError("type should be 'mean', 'proba' or 'model', not " + _type)

        if hasattr(newX, "columns"):
            self._feature_names = newX.columns
        elif not hasattr(self, "_feature_names"):
            self._feature_names = None

        X = np.array(newX, copy=True)
        if X.ndim == 1:
            X = X.reshape(-1, 1)

        self.X = X
        self.y = newy

        if online:
            if newy is None:
                raise ValueError("newy should be specified if online is TRUE")

            if self.viking_params is None:
                if compute_smooth:
                    self.ks = kalman_smoothing(
                        X,
                        newy,
                        self.kalman_params["theta"],
                        self.kalman_params["P"],
                        Q=self.kalman_params["Q"],
                        sig=self.kalman_params["sig"],
                    )

                self.kf = kalman_filtering(
                    X,
                    newy,
                    self.kalman_params["theta"],
                    self.kalman_params["P"],
                    Q=self.kalman_params["Q"],
                    sig=self.kalman_params["sig"],
                )
                self.kalman_params["theta"] = self.kf["theta"]
                self.kalman_params["P"] = self.kf["P"]

                self.pred_mean = np.zeros(np.shape(X)[0])
                for t in range(np.shape(X)[0]):
                    self.pred_mean[t] = np.dot(
                        self.kf["theta_arr"][t, :], X[t, :]
                    ).item()

                self.pred_sd = np.zeros(np.shape(X)[0])
                for t in range(np.shape(X)[0]):
                    variance = np.dot(
                        X[t, :], np.dot(self.kf["P_arr"][t, :, :], X[t, :])
                    )
                    self.pred_sd[t] = np.sqrt(
                        variance + self.kalman_params["sig"] ** 2
                    ).item()

            else:
                self.vik = viking(
                    X=X,
                    y=newy,
                    theta0=self.viking_params["theta"],
                    P0=self.viking_params["P"],
                    hata0=self.viking_params["hata"],
                    s0=self.viking_params["s"],
                    hatb0=self.viking_params["hatb"],
                    Sigma0=self.viking_params["Sigma"],
                )

                self.pred_mean = np.zeros(np.shape(X)[0])
                for t in range(np.shape(X)[0]):
                    self.pred_mean[t] = np.dot(
                        self.vik["theta_arr"][t, :], X[t, :]
                    ).item()

                self.pred_sd = np.zeros(np.shape(X)[0])
                for t in range(np.shape(X)[0]):
                    variance = np.dot(
                        X[t, :], np.dot(self.vik["P_arr"][t, :, :], X[t, :])
                    )
                    obs_noise = np.exp(self.vik["hata"] + self.vik["s"] / 2)
                    self.pred_sd[t] = np.sqrt(variance + obs_noise).item()

        else:
            if self.viking_params is None:
                theta = self.kalman_params["theta"]
                P = self.kalman_params["P"]
            else:
                theta = self.viking_params["theta"]
                P = self.viking_params["P"]

            self.pred_mean = np.zeros(np.shape(X)[0])
            self.pred_sd = np.zeros(np.shape(X)[0])
            for t in range(np.shape(X)[0]):
                self.pred_mean[t] = np.dot(X[t, :], theta).item()
                variance = np.dot(
                    X[t, :], np.dot(P + (t - 1) * self.kalman_params["Q"], X[t, :])
                )
                self.pred_sd[t] = np.sqrt(
                    variance + self.kalman_params["sig"] ** 2
                ).item()
        if _type == "mean":
            return self.pred_mean

        elif _type == "proba":
            final_model = {
                "mean": self.pred_mean,
                "sd": self.pred_sd,
            }
            return final_model

        else:
            return self

    def plot(
        self, pause: bool = False, window_size: int = 7, date=None, sel=None
    ) -> None:
        """
        Plots a statespace object, displaying analysis graphs.

        Displays different graphs expressing the behavior of the state-space model:
        1. Evolution of the Bias: Rolling version of the model's error.
        2. Evolution of the RMSE: Root-mean-square-error computed on a rolling window.
        3. State Evolution: Time-varying state coefficients, with the initial state subtracted.
        4. Normal Q-Q Plot: Checks if the standardized residuals follow a standard
           normal distribution, to assess the model's probabilistic assumptions.

        Parameters
        ----------
        pause : bool, optional
            If False, plots are displayed on a single page. Otherwise, a new page
            is created for each plot, by default False.
        window_size : int, optional
            The window size for the rolling mean used to display the bias and RMSE,
            by default 7.
        date : array-like, optional
            Defines the values for the x-axis. If None, integer indices are used,
            by default None.
        sel : array-like, optional
            Defines a subset of the data to zoom in on (e.g., a test set),
            by default None.

        Returns
        -------
        None
            This function is called for its side effect of displaying plots.
        """

        if pause:
            plt.figure(figsize=(6, 4))
        else:
            fig, axis = plt.subplots(3, 2, figsize=(12, 12))

        if date is None:
            date = np.array(range(len(self.y)))

        if sel is None:
            sel = list(range(len(self.y)))

        res = self.y[sel] - self.pred_mean[sel]

        if self.kf:
            th_fixed = self.kf["theta_arr"][sel[0], :]
        else:
            th_fixed = self.vik["theta_arr"][sel[0], :]

        res_fixed = self.y[sel] - np.dot(self.X[sel, :], th_fixed)
        date_sel = date[sel]

        bias_fixed = [
            np.mean(res_fixed[t - window_size : t])
            for t in range(window_size, len(res))
        ]
        bias_ssm = [
            np.mean(res[t - window_size : t]) for t in range(window_size, len(res))
        ]

        axis[0, 0].plot(date_sel[window_size:], bias_fixed, linewidth=2, label="Fixed")
        axis[0, 0].plot(
            date_sel[window_size:],
            bias_ssm,
            color="darkgreen",
            linewidth=2,
            label="SSM",
        )
        axis[0, 0].set_title("Evolution of the Bias")
        axis[0, 0].set_xlabel("Date")
        axis[0, 0].set_ylabel("Bias")
        axis[0, 0].legend()

        lfixed_rmse = [
            np.sqrt(np.mean(res_fixed[t - window_size : t] ** 2))
            for t in range(window_size, len(res))
        ]
        l_rmse = [
            np.sqrt(np.mean(res[t - window_size : t] ** 2))
            for t in range(window_size, len(res))
        ]

        axis[0, 1].plot(date_sel[window_size:], lfixed_rmse, linewidth=2, label="Fixed")
        axis[0, 1].plot(
            date_sel[window_size:], l_rmse, color="darkgreen", linewidth=2, label="SSM"
        )
        axis[0, 1].set_title("Evolution of the RMSE")
        axis[0, 1].set_xlabel("Date")
        axis[0, 1].set_ylabel("RMSE")
        axis[0, 1].legend()

        def plot_evol(evol, title, coln=None, logpar=False):
            colors = cm.Spectral(np.linspace(0, 1, max(evol.shape[1], 11)))
            axis[1, 0].plot(
                date_sel,
                evol[:, 0],
                color=colors[0],
                linewidth=2,
                label=coln[0] if coln else None,
            )
            for j in range(1, evol.shape[1]):
                axis[1, 0].plot(
                    date_sel,
                    evol[:, j],
                    color=colors[j],
                    linewidth=2,
                    label=coln[j] if coln else None,
                )
            axis[1, 0].set_title(title)
            axis[1, 0].set_xlabel("Date")
            axis[1, 0].set_ylabel("")
            if coln:
                axis[1, 0].legend(loc="upper right")

        if self.kf:
            evoltheta = self.kf["theta_arr"][sel, :]
            evoltheta -= np.tile(evoltheta[0, :], (evoltheta.shape[0], 1))
            plot_evol(
                evoltheta,
                "State Evolution: Kalman Filtering",
                coln=self.X.columns if isinstance(self.X, pd.DataFrame) else None,
            )

        if self.ks:
            evoltheta = self.ks["theta_arr"][sel, :]
            evoltheta -= np.tile(evoltheta[0, :], (evoltheta.shape[0], 1))
            plot_evol(
                evoltheta,
                "State Evolution: Kalman Smoothing",
                coln=self.X.columns if isinstance(self.X, pd.DataFrame) else None,
            )

        if self.vik:
            evoltheta = self.vik["theta_arr"][sel, :]
            evoltheta -= np.tile(evoltheta[0, :], (evoltheta.shape[0], 1))
            plot_evol(
                evoltheta,
                "State Evolution: Viking",
                coln=self.X.columns if isinstance(self.X, pd.DataFrame) else None,
            )

        if self.vik:
            axis[2, 0].plot(
                date_sel,
                np.exp(self.vik["hata_arr"][sel] + self.vik["s_arr"][sel] / 2),
                linewidth=2,
            )
            axis[2, 0].set_title("Evolution of the observation noise variance")
            plot_evol(
                self.vik["q_arr"][sel, :],
                "Evolution of the state noise covariance matrix",
                coln=self.X.columns if isinstance(self.X, pd.DataFrame) else None,
            )

        if self.kf:
            diagQ = np.diag(self.kalman_params["Q"])
            colors = cm.Spectral(np.linspace(0, 1, max(len(diagQ), 11)))
            axis[2, 1].bar(np.arange(len(diagQ)), diagQ, color=colors)
            axis[2, 1].set_title("Diagonal of Q")
            axis[2, 1].set_ylim(0, max(diagQ) * 1.4)
            axis[2, 1].set_xlabel("Index")
            axis[2, 1].set_ylabel("Value")

        std_res = res / self.pred_sd[sel]
        stats.probplot(std_res, dist="norm", plot=axis[1, 1])
        axis[1, 1].set_title("Normal Q-Q Plot of the Residuals")
        axis[1, 1].plot(
            [-4, 4], [-4, 4], color="darkred", linewidth=2
        )  # Standard Normal line
        axis[1, 1].plot(
            [-4, 4],
            [-4 * np.std(std_res), 4 * np.std(std_res)],
            color="darkgreen",
            linewidth=2,
        )  # Best Constant line
        axis[1, 1].legend(
            ["Standard Normal", "Best Constant"], loc="upper left", fontsize="large"
        )

        plt.tight_layout()
        plt.subplots_adjust(hspace=0.4, wspace=0.4)
        plt.show()
