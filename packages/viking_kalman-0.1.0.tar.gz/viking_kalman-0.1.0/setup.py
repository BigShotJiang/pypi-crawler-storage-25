from setuptools import setup, find_packages, Extension
from setuptools.command.build_ext import build_ext
from distutils.errors import CCompilerError, DistutilsExecError, DistutilsPlatformError
from pathlib import Path
import os

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

libs = ["gsl", "gslcblas"]

if os.name != "nt":
    libs.append("m")

grid_extension = Extension(
    name="viking_kalman.grid",
    sources=["src/viking_kalman/iterative_grid_search.c", "src/viking_kalman/loglik.c"],
    libraries=libs,
    optional=True,
)


def show_fallback_warning():
    print("*" * 30 + " WARNING " + "*" * 30)
    print("C compiler not found or compilation failed.")
    print("Falling back to pure Python installation. The package will work, but")
    print("`iterative_grid_search` will be slower.")
    print("*" * 70)


class optional_build_ext(build_ext):
    def run(self):
        try:
            super().run()
        except (
            CCompilerError,
            DistutilsExecError,
            DistutilsPlatformError,
            FileNotFoundError,
        ):
            show_fallback_warning()
            self.extensions = []

    def build_extensions(self):
        try:
            import numpy as np

            for ext in self.extensions:
                ext.include_dirs.append(np.get_include())
        except ImportError:
            show_fallback_warning()
            self.extensions = []
            return

        try:
            super().build_extensions()
        except (CCompilerError, DistutilsExecError, DistutilsPlatformError, ValueError):
            show_fallback_warning()
            self.extensions = []


setup(
    name="viking_kalman",
    version="0.1.0",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=["numpy", "scipy", "matplotlib", "pandas"],
    ext_modules=[grid_extension],
    cmdclass={"build_ext": optional_build_ext},
    include_package_data=True,
    author="Louis Viennot, Ismaïl El Azzaoui, Antoine Gourbilleau, Athir Hamadieh, Yann Allioux",
    description="Viking: Variational bayesIan variance tracKING. A Python package for variational inference in state-space models.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="LGPL-3.0-or-later",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU Lesser General Public License v3 (LGPLv3)",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    url="https://github.com/EDF-Lab/viking_kalman",
    project_urls={
        "Bug Tracker": "https://github.com/EDF-Lab/viking_kalman/issues",
        "Source Code": "https://github.com/EDF-Lab/viking_kalman",
    },
)
