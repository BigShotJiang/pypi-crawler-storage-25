"""
exceptions.py - Custom exceptions for the agricultural security framework
"""

class AgriSecureError(Exception):
    """Base exception for all framework errors"""
    pass

# Authentication Errors
class AuthenticationError(AgriSecureError):
    """Base authentication error"""
    pass

class InvalidCredentialsError(AuthenticationError):
    """Invalid username or password"""
    pass

class MFASetupRequiredError(AuthenticationError):
    """MFA not configured for user"""
    pass

class AccountLockedError(AuthenticationError):
    """Account locked due to too many attempts"""
    pass

class SessionExpiredError(AuthenticationError):
    """User session has expired"""
    pass

class TokenExpiredError(AuthenticationError):
    """JWT token has expired"""
    pass

class TokenInvalidError(AuthenticationError):
    """JWT token is invalid"""
    pass

# Authorization Errors
class AuthorizationError(AgriSecureError):
    """Base authorization error"""
    pass

class PermissionDeniedError(AuthorizationError):
    """User lacks required permission"""
    pass

class RoleNotFoundError(AuthorizationError):
    """Role does not exist"""
    pass

class ResourceNotFoundError(AuthorizationError):
    """Resource not found or inaccessible"""
    pass

# Encryption Errors
class EncryptionError(AgriSecureError):
    """Base encryption error"""
    pass

class DecryptionError(EncryptionError):
    """Failed to decrypt data"""
    pass

class KeyNotFoundError(EncryptionError):
    """Encryption key not found"""
    pass

class KeyExpiredError(EncryptionError):
    """Encryption key has expired"""
    pass

class SignatureError(EncryptionError):
    """Digital signature verification failed"""
    pass

# Validation Errors
class ValidationError(AgriSecureError):
    """Data validation error"""
    pass

class SchemaValidationError(ValidationError):
    """JSON schema validation failed"""
    pass

class FieldValidationError(ValidationError):
    """Individual field validation failed"""
    
    def __init__(self, field: str, message: str):
        self.field = field
        self.message = message
        super().__init__(f"Field '{field}': {message}")

class DataTypeError(ValidationError):
    """Invalid data type"""
    pass

# Blockchain Errors
class BlockchainError(AgriSecureError):
    """Base blockchain error"""
    pass

class TransactionNotFoundError(BlockchainError):
    """Transaction not found in ledger"""
    pass

class BlockNotFoundError(BlockchainError):
    """Block not found in chain"""
    pass

class ConsensusError(BlockchainError):
    """Consensus mechanism failed"""
    pass

# Database Errors
class DatabaseError(AgriSecureError):
    """Base database error"""
    pass

class ConnectionError(DatabaseError):
    """Database connection failed"""
    pass

class QueryError(DatabaseError):
    """Database query failed"""
    pass

class MigrationError(DatabaseError):
    """Database migration failed"""
    pass

# Configuration Errors
class ConfigurationError(AgriSecureError):
    """Configuration error"""
    pass

class MissingConfigurationError(ConfigurationError):
    """Required configuration missing"""
    
    def __init__(self, key: str):
        self.key = key
        super().__init__(f"Missing required configuration: {key}")

class InvalidConfigurationError(ConfigurationError):
    """Invalid configuration value"""
    pass

# Network Errors
class NetworkError(AgriSecureError):
    """Network communication error"""
    pass

class TimeoutError(NetworkError):
    """Request timed out"""
    pass

class ConnectionRefusedError(NetworkError):
    """Connection refused"""
    pass

# Integration Errors
class IntegrationError(AgriSecureError):
    """Third-party integration error"""
    pass

class APIError(IntegrationError):
    """API call failed"""
    
    def __init__(self, service: str, status_code: int, message: str):
        self.service = service
        self.status_code = status_code
        super().__init__(f"{service} API error ({status_code}): {message}")

class WebhookError(IntegrationError):
    """Webhook delivery failed"""
    pass

# Rate Limiting
class RateLimitError(AgriSecureError):
    """Rate limit exceeded"""
    
    def __init__(self, limit: int, reset_time: int):
        self.limit = limit
        self.reset_time = reset_time
        super().__init__(f"Rate limit exceeded: {limit} requests per {reset_time}s")

# Concurrency Errors
class ConcurrencyError(AgriSecureError):
    """Concurrency conflict"""
    pass

class LockAcquisitionError(ConcurrencyError):
    """Failed to acquire lock"""
    pass

class DeadlockError(ConcurrencyError):
    """Deadlock detected"""
    pass

# Backup/Restore Errors
class BackupError(AgriSecureError):
    """Backup operation failed"""
    pass

class RestoreError(AgriSecureError):
    """Restore operation failed"""
    pass

# Audit Errors
class AuditError(AgriSecureError):
    """Audit logging failed"""
    pass

# Monitoring Errors
class MonitoringError(AgriSecureError):
    """Metrics/monitoring error"""
    pass

# Cache Errors
class CacheError(AgriSecureError):
    """Cache operation failed"""
    pass

class CacheMissError(CacheError):
    """Cache key not found"""
    pass

# CSRF Errors
class CSRFError(AgriSecureError):
    """CSRF token validation failed"""
    pass

class CSRFTokenMissingError(CSRFError):
    """CSRF token not present in request"""
    pass

class CSRFTokenExpiredError(CSRFError):
    """CSRF token has expired"""
    pass

class CSRFTokenInvalidError(CSRFError):
    """CSRF token does not match stored token"""
    pass

# Brute Force Errors
class BruteForceError(AgriSecureError):
    """Brute-force protection triggered"""
    pass

class IPBlockedError(BruteForceError):
    """IP address is temporarily blocked"""

    def __init__(self, ip: str, remaining_seconds: int):
        self.ip = ip
        self.remaining_seconds = remaining_seconds
        super().__init__(
            f"IP {ip} is blocked for {remaining_seconds} seconds due to excessive attempts"
        )

# File Upload Errors
class FileUploadError(AgriSecureError):
    """File upload security check failed"""
    pass

class FileMalwareError(FileUploadError):
    """File contains malware signature"""
    pass

class FileTypeError(FileUploadError):
    """File type is not allowed"""
    pass

class FileSizeError(FileUploadError):
    """File exceeds size limit"""
    pass

# Input Validation Errors
class InputValidationError(AgriSecureError):
    """Input validation failed"""
    pass

class SQLInjectionError(InputValidationError):
    """SQL injection pattern detected in input"""
    pass

class XSSError(InputValidationError):
    """Cross-site scripting pattern detected in input"""
    pass

# Recovery Errors
class RecoveryError(AgriSecureError):
    """Recovery operation failed"""
    pass

class RestoreVerificationError(RecoveryError):
    """Backup integrity verification failed before restore"""
    pass

# Incident Response Errors
class IncidentError(AgriSecureError):
    """Incident response operation failed"""
    pass

# Import all exceptions for easy access
__all__ = [
    "AgriSecureError",
    
    # Authentication
    "AuthenticationError",
    "InvalidCredentialsError",
    "MFASetupRequiredError",
    "AccountLockedError",
    "SessionExpiredError",
    "TokenExpiredError",
    "TokenInvalidError",
    
    # Authorization
    "AuthorizationError",
    "PermissionDeniedError",
    "RoleNotFoundError",
    "ResourceNotFoundError",
    
    # Encryption
    "EncryptionError",
    "DecryptionError",
    "KeyNotFoundError",
    "KeyExpiredError",
    "SignatureError",
    
    # Validation
    "ValidationError",
    "SchemaValidationError",
    "FieldValidationError",
    "DataTypeError",
    
    # Blockchain
    "BlockchainError",
    "TransactionNotFoundError",
    "BlockNotFoundError",
    "ConsensusError",
    
    # Database
    "DatabaseError",
    "ConnectionError",
    "QueryError",
    "MigrationError",
    
    # Configuration
    "ConfigurationError",
    "MissingConfigurationError",
    "InvalidConfigurationError",
    
    # Network
    "NetworkError",
    "TimeoutError",
    "ConnectionRefusedError",
    
    # Integration
    "IntegrationError",
    "APIError",
    "WebhookError",
    
    # Rate Limiting
    "RateLimitError",
    
    # Concurrency
    "ConcurrencyError",
    "LockAcquisitionError",
    "DeadlockError",
    
    # Backup/Restore
    "BackupError",
    "RestoreError",
    
    # Audit
    "AuditError",
    
    # Monitoring
    "MonitoringError",
    
    # Cache
    "CacheError",
    "CacheMissError",

    # CSRF
    "CSRFError",
    "CSRFTokenMissingError",
    "CSRFTokenExpiredError",
    "CSRFTokenInvalidError",

    # Brute Force
    "BruteForceError",
    "IPBlockedError",

    # File Upload
    "FileUploadError",
    "FileMalwareError",
    "FileTypeError",
    "FileSizeError",

    # Input Validation
    "InputValidationError",
    "SQLInjectionError",
    "XSSError",

    # Recovery
    "RecoveryError",
    "RestoreVerificationError",

    # Incident Response
    "IncidentError",
]