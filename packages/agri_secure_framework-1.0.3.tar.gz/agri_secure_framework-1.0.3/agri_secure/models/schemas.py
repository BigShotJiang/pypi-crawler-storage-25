"""
schemas.py - Pydantic models for agricultural data validation and serialization
Implements strict data validation with comprehensive error handling
"""

from pydantic import BaseModel, Field, validator, root_validator, EmailStr, constr
from typing import Optional, List, Dict, Any, Union
from datetime import datetime, date
from enum import Enum
import re
import json
from uuid import uuid4

class UserRole(str, Enum):
    """User roles in the agricultural system"""
    FARMER = "farmer"
    EXTENSION_OFFICER = "extension_officer"
    MINISTRY_OFFICIAL = "ministry_official"
    RESEARCHER = "researcher"
    AGRIBUSINESS = "agribusiness"
    SYSTEM_ADMIN = "system_admin"
    AUDITOR = "auditor"

class DataClassification(str, Enum):
    """Data sensitivity classification"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    SECRET = "secret"

class FarmType(str, Enum):
    """Types of farms"""
    SMALLHOLDER = "smallholder"
    COMMERCIAL = "commercial"
    COOPERATIVE = "cooperative"
    STATE = "state"
    RESEARCH = "research"

class CropType(str, Enum):
    """Types of crops"""
    MAIZE = "maize"
    SOYBEAN = "soybean"
    WHEAT = "wheat"
    RICE = "rice"
    COTTON = "cotton"
    TOBACCO = "tobacco"
    GROUNDNUTS = "groundnuts"
    SORGHUM = "sorghum"
    MILLET = "millet"
    CASSAVA = "cassava"
    SWEET_POTATO = "sweet_potato"
    VEGETABLES = "vegetables"
    FRUITS = "fruits"
    COFFEE = "coffee"
    TEA = "tea"
    SUGARCANE = "sugarcane"

class LivestockType(str, Enum):
    """Types of livestock"""
    CATTLE = "cattle"
    GOATS = "goats"
    SHEEP = "sheep"
    PIGS = "pigs"
    CHICKENS = "chickens"
    DUCKS = "ducks"
    TURKEYS = "turkeys"
    RABBITS = "rabbits"
    BEES = "bees"
    FISH = "fish"

class UserBase(BaseModel):
    """Base user model"""
    username: constr(min_length=3, max_length=50, pattern="^[a-zA-Z0-9_]+$")
    email: Optional[EmailStr] = None
    phone: Optional[constr(pattern=r"^\+?[0-9]{10,15}$")] = None
    role: UserRole
    first_name: Optional[constr(min_length=1, max_length=100)] = None
    last_name: Optional[constr(min_length=1, max_length=100)] = None
    district: Optional[constr(min_length=1, max_length=100)] = None
    province: Optional[constr(min_length=1, max_length=100)] = None
    language: str = "en"
    timezone: str = "Africa/Lusaka"
    metadata: Dict[str, Any] = Field(default_factory=dict)

class UserCreate(UserBase):
    """User creation model"""
    password: constr(min_length=8, max_length=100)
    
    @validator('password')
    def validate_password(cls, v):
        """Validate password strength"""
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not re.search(r'[0-9]', v):
            raise ValueError('Password must contain at least one number')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Password must contain at least one special character')
        return v

class UserInDB(UserBase):
    """User model as stored in database"""
    user_id: str = Field(default_factory=lambda: f"usr_{uuid4().hex[:16]}")
    password_hash: str
    mfa_secret: Optional[str] = None
    mfa_enabled: bool = False
    mfa_verified: bool = False
    email_verified: bool = False
    phone_verified: bool = False
    failed_attempts: int = 0
    locked_until: Optional[datetime] = None
    last_login: Optional[datetime] = None
    last_password_change: datetime = Field(default_factory=datetime.utcnow)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    created_by: Optional[str] = None
    is_active: bool = True
    is_deleted: bool = False

class UserResponse(UserBase):
    """User response model (excludes sensitive data)"""
    user_id: str
    email_verified: bool
    phone_verified: bool
    mfa_enabled: bool
    last_login: Optional[datetime]
    created_at: datetime
    is_active: bool

class Location(BaseModel):
    """Location model"""
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    altitude: Optional[float] = None
    accuracy: Optional[float] = Field(None, ge=0)
    
    @validator('latitude')
    def validate_latitude(cls, v):
        if v < -90 or v > 90:
            raise ValueError('Latitude must be between -90 and 90')
        return v
    
    @validator('longitude')
    def validate_longitude(cls, v):
        if v < -180 or v > 180:
            raise ValueError('Longitude must be between -180 and 180')
        return v

class FarmBase(BaseModel):
    """Base farm model"""
    name: constr(min_length=1, max_length=200)
    farm_type: FarmType
    size_hectares: float = Field(..., gt=0, le=100000)
    location: Location
    district: str
    province: str
    traditional_authority: Optional[str] = None
    village: Optional[str] = None
    crops: List[CropType] = Field(default_factory=list)
    livestock: List[LivestockType] = Field(default_factory=list)
    irrigation: bool = False
    irrigation_type: Optional[str] = None
    water_source: Optional[str] = None
    soil_type: Optional[str] = None
    land_tenure: Optional[str] = None
    year_established: Optional[int] = Field(None, ge=1900, le=datetime.now().year)
    certifications: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class FarmCreate(FarmBase):
    """Farm creation model"""
    farmer_id: str
    
    @validator('size_hectares')
    def validate_size(cls, v):
        if v <= 0:
            raise ValueError('Farm size must be greater than 0')
        if v > 100000:
            raise ValueError('Farm size cannot exceed 100,000 hectares')
        return v

class FarmInDB(FarmBase):
    """Farm model as stored in database"""
    farm_id: str = Field(default_factory=lambda: f"farm_{uuid4().hex[:16]}")
    farmer_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    created_by: str
    is_active: bool = True
    is_deleted: bool = False
    classification: DataClassification = DataClassification.CONFIDENTIAL

class FarmResponse(FarmBase):
    """Farm response model"""
    farm_id: str
    farmer_id: str
    created_at: datetime
    updated_at: datetime
    is_active: bool

class CropDataBase(BaseModel):
    """Base crop data model"""
    farm_id: str
    crop_type: CropType
    season: str
    planting_date: date
    harvest_date: Optional[date] = None
    area_planted: float = Field(..., gt=0)
    expected_yield: Optional[float] = Field(None, gt=0)
    actual_yield: Optional[float] = Field(None, gt=0)
    seed_variety: Optional[str] = None
    seed_source: Optional[str] = None
    fertilizer_used: Optional[str] = None
    fertilizer_amount: Optional[float] = Field(None, ge=0)
    pesticide_used: Optional[str] = None
    pesticide_amount: Optional[float] = Field(None, ge=0)
    irrigation_applied: Optional[float] = Field(None, ge=0)
    labor_used: Optional[int] = Field(None, ge=0)
    notes: Optional[str] = None
    
    @validator('harvest_date')
    def validate_harvest_date(cls, v, values):
        if v and 'planting_date' in values:
            if v < values['planting_date']:
                raise ValueError('Harvest date cannot be before planting date')
        return v

class CropDataCreate(CropDataBase):
    """Crop data creation model"""
    pass

class CropDataInDB(CropDataBase):
    """Crop data model as stored in database"""
    crop_data_id: str = Field(default_factory=lambda: f"crop_{uuid4().hex[:16]}")
    recorded_by: str
    recorded_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    is_verified: bool = False
    verified_by: Optional[str] = None
    verified_at: Optional[datetime] = None
    classification: DataClassification = DataClassification.CONFIDENTIAL

class CropDataResponse(CropDataBase):
    """Crop data response model"""
    crop_data_id: str
    recorded_by: str
    recorded_at: datetime
    updated_at: datetime
    is_verified: bool

class LivestockDataBase(BaseModel):
    """Base livestock data model"""
    farm_id: str
    livestock_type: LivestockType
    breed: Optional[str] = None
    count: int = Field(..., ge=0)
    birth_rate: Optional[float] = Field(None, ge=0, le=100)
    mortality_rate: Optional[float] = Field(None, ge=0, le=100)
    health_status: Optional[str] = None
    vaccinations: List[str] = Field(default_factory=list)
    last_vaccination: Optional[date] = None
    feed_type: Optional[str] = None
    feed_amount: Optional[float] = Field(None, ge=0)
    milk_production: Optional[float] = Field(None, ge=0)
    egg_production: Optional[int] = Field(None, ge=0)
    notes: Optional[str] = None

class LivestockDataCreate(LivestockDataBase):
    """Livestock data creation model"""
    pass

class LivestockDataInDB(LivestockDataBase):
    """Livestock data model as stored in database"""
    livestock_data_id: str = Field(default_factory=lambda: f"live_{uuid4().hex[:16]}")
    recorded_by: str
    recorded_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    classification: DataClassification = DataClassification.CONFIDENTIAL

class LivestockDataResponse(LivestockDataBase):
    """Livestock data response model"""
    livestock_data_id: str
    recorded_by: str
    recorded_at: datetime
    updated_at: datetime

class SoilDataBase(BaseModel):
    """Base soil data model"""
    farm_id: str
    sample_date: date
    sample_depth: Optional[float] = Field(None, ge=0)
    ph: Optional[float] = Field(None, ge=0, le=14)
    nitrogen: Optional[float] = Field(None, ge=0)
    phosphorus: Optional[float] = Field(None, ge=0)
    potassium: Optional[float] = Field(None, ge=0)
    organic_matter: Optional[float] = Field(None, ge=0, le=100)
    cation_exchange: Optional[float] = Field(None, ge=0)
    texture: Optional[str] = None
    moisture: Optional[float] = Field(None, ge=0, le=100)
    salinity: Optional[float] = Field(None, ge=0)
    notes: Optional[str] = None

class SoilDataCreate(SoilDataBase):
    """Soil data creation model"""
    pass

class SoilDataInDB(SoilDataBase):
    """Soil data model as stored in database"""
    soil_data_id: str = Field(default_factory=lambda: f"soil_{uuid4().hex[:16]}")
    recorded_by: str
    recorded_at: datetime = Field(default_factory=datetime.utcnow)
    classification: DataClassification = DataClassification.CONFIDENTIAL

class SoilDataResponse(SoilDataBase):
    """Soil data response model"""
    soil_data_id: str
    recorded_by: str
    recorded_at: datetime

class WeatherDataBase(BaseModel):
    """Base weather data model"""
    location: Location
    timestamp: datetime
    temperature: Optional[float] = None
    humidity: Optional[float] = Field(None, ge=0, le=100)
    pressure: Optional[float] = None
    rainfall: Optional[float] = Field(None, ge=0)
    wind_speed: Optional[float] = Field(None, ge=0)
    wind_direction: Optional[float] = Field(None, ge=0, le=360)
    solar_radiation: Optional[float] = Field(None, ge=0)
    soil_temperature: Optional[float] = None
    soil_moisture: Optional[float] = Field(None, ge=0, le=100)
    evapotranspiration: Optional[float] = Field(None, ge=0)
    notes: Optional[str] = None

class WeatherDataCreate(WeatherDataBase):
    """Weather data creation model"""
    source: str
    station_id: Optional[str] = None

class WeatherDataInDB(WeatherDataBase):
    """Weather data model as stored in database"""
    weather_data_id: str = Field(default_factory=lambda: f"wth_{uuid4().hex[:16]}")
    source: str
    station_id: Optional[str] = None
    recorded_at: datetime = Field(default_factory=datetime.utcnow)
    classification: DataClassification = DataClassification.PUBLIC

class WeatherDataResponse(WeatherDataBase):
    """Weather data response model"""
    weather_data_id: str
    source: str
    recorded_at: datetime

class MarketDataBase(BaseModel):
    """Base market data model"""
    product: str
    product_type: str
    grade: Optional[str] = None
    price: float = Field(..., gt=0)
    currency: str = "ZMW"
    unit: str
    market: str
    district: str
    province: str
    date: date
    min_price: Optional[float] = Field(None, gt=0)
    max_price: Optional[float] = Field(None, gt=0)
    volume: Optional[float] = Field(None, ge=0)
    notes: Optional[str] = None

class MarketDataCreate(MarketDataBase):
    """Market data creation model"""
    source: str

class MarketDataInDB(MarketDataBase):
    """Market data model as stored in database"""
    market_data_id: str = Field(default_factory=lambda: f"mkt_{uuid4().hex[:16]}")
    source: str
    recorded_at: datetime = Field(default_factory=datetime.utcnow)
    classification: DataClassification = DataClassification.PUBLIC

class MarketDataResponse(MarketDataBase):
    """Market data response model"""
    market_data_id: str
    source: str
    recorded_at: datetime

class ExtensionAdviceBase(BaseModel):
    """Base extension advice model"""
    farmer_id: str
    farm_id: str
    advisor_id: str
    advice_type: str
    title: str
    description: str
    recommendations: List[str]
    priority: str = "medium"
    status: str = "pending"
    due_date: Optional[date] = None
    completed_date: Optional[date] = None
    follow_up_required: bool = False
    notes: Optional[str] = None

class ExtensionAdviceCreate(ExtensionAdviceBase):
    """Extension advice creation model"""
    pass

class ExtensionAdviceInDB(ExtensionAdviceBase):
    """Extension advice model as stored in database"""
    advice_id: str = Field(default_factory=lambda: f"adv_{uuid4().hex[:16]}")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    classification: DataClassification = DataClassification.CONFIDENTIAL

class ExtensionAdviceResponse(ExtensionAdviceBase):
    """Extension advice response model"""
    advice_id: str
    created_at: datetime
    updated_at: datetime
    status: str

class AuditLogBase(BaseModel):
    """Base audit log model"""
    event_type: str
    user_id: Optional[str] = None
    user_role: Optional[str] = None
    resource_type: str
    resource_id: Optional[str] = None
    action: str
    status: str
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    request_id: Optional[str] = None
    details: Dict[str, Any] = Field(default_factory=dict)

class AuditLogCreate(AuditLogBase):
    """Audit log creation model"""
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class AuditLogInDB(AuditLogBase):
    """Audit log model as stored in database"""
    log_id: str = Field(default_factory=lambda: f"log_{uuid4().hex[:16]}")
    timestamp: datetime
    blockchain_tx_id: Optional[str] = None

class ShareRequestBase(BaseModel):
    """Base share request model"""
    data_id: str
    data_type: str
    shared_by: str
    shared_with: List[str]
    purpose: str
    expiry_date: Optional[datetime] = None
    allow_download: bool = False
    require_consent: bool = True
    consent_obtained: bool = False
    classification: DataClassification

class ShareRequestCreate(ShareRequestBase):
    """Share request creation model"""
    pass

class ShareRequestInDB(ShareRequestBase):
    """Share request model as stored in database"""
    share_id: str = Field(default_factory=lambda: f"shr_{uuid4().hex[:16]}")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    status: str = "pending"
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    access_log: List[Dict] = Field(default_factory=list)

class ShareRequestResponse(ShareRequestBase):
    """Share request response model"""
    share_id: str
    created_at: datetime
    status: str
    approved_by: Optional[str]
    approved_at: Optional[datetime]

class ErrorResponse(BaseModel):
    """Standard error response model"""
    error_code: str
    message: str
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    request_id: Optional[str] = None
    path: Optional[str] = None

class SuccessResponse(BaseModel):
    """Standard success response model"""
    success: bool = True
    message: Optional[str] = None
    data: Optional[Any] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    request_id: Optional[str] = None

class PaginatedResponse(BaseModel):
    """Paginated response model"""
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int
    has_next: bool
    has_previous: bool

class HealthCheckResponse(BaseModel):
    """Health check response model"""
    status: str
    version: str
    timestamp: datetime
    components: Dict[str, Any]
    uptime: float
    environment: str

# Export all models
__all__ = [
    "UserRole",
    "DataClassification",
    "FarmType",
    "CropType",
    "LivestockType",
    "UserBase",
    "UserCreate",
    "UserInDB",
    "UserResponse",
    "Location",
    "FarmBase",
    "FarmCreate",
    "FarmInDB",
    "FarmResponse",
    "CropDataBase",
    "CropDataCreate",
    "CropDataInDB",
    "CropDataResponse",
    "LivestockDataBase",
    "LivestockDataCreate",
    "LivestockDataInDB",
    "LivestockDataResponse",
    "SoilDataBase",
    "SoilDataCreate",
    "SoilDataInDB",
    "SoilDataResponse",
    "WeatherDataBase",
    "WeatherDataCreate",
    "WeatherDataInDB",
    "WeatherDataResponse",
    "MarketDataBase",
    "MarketDataCreate",
    "MarketDataInDB",
    "MarketDataResponse",
    "ExtensionAdviceBase",
    "ExtensionAdviceCreate",
    "ExtensionAdviceInDB",
    "ExtensionAdviceResponse",
    "AuditLogBase",
    "AuditLogCreate",
    "AuditLogInDB",
    "ShareRequestBase",
    "ShareRequestCreate",
    "ShareRequestInDB",
    "ShareRequestResponse",
    "ErrorResponse",
    "SuccessResponse",
    "PaginatedResponse",
    "HealthCheckResponse"
]
