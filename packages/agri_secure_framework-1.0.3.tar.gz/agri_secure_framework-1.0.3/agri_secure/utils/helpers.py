"""
helpers.py - Utility helper functions for the agricultural security framework
"""

import os
import re
import json
import uuid
import hashlib
import secrets
import base64
import datetime
from typing import Any, Dict, List, Optional, Union
from functools import wraps
import time
import logging

logger = logging.getLogger(__name__)

def generate_id(prefix: str = "", length: int = 16) -> str:
    """
    Generate a unique ID.
    
    Args:
        prefix: Optional prefix for the ID
        length: Length of random part
    
    Returns:
        Unique ID string
    """
    random_part = secrets.token_urlsafe(length)[:length]
    if prefix:
        return f"{prefix}_{random_part}"
    return random_part

def generate_api_key() -> str:
    """Generate a secure API key"""
    return f"agri_{secrets.token_urlsafe(32)}"

def hash_password(password: str) -> str:
    """Hash password using bcrypt"""
    import bcrypt
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def verify_password(password: str, password_hash: str) -> bool:
    """Verify password against hash"""
    import bcrypt
    return bcrypt.checkpw(
        password.encode('utf-8'),
        password_hash.encode('utf-8')
    )

def create_jwt_token(payload: Dict, secret: str, expiry: int = 3600) -> str:
    """Create JWT token"""
    import jwt
    payload['exp'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=expiry)
    payload['iat'] = datetime.datetime.utcnow()
    return jwt.encode(payload, secret, algorithm='HS256')

def decode_jwt_token(token: str, secret: str) -> Dict:
    """Decode JWT token"""
    import jwt
    return jwt.decode(token, secret, algorithms=['HS256'])

def mask_sensitive_data(data: Dict, fields: List[str]) -> Dict:
    """Mask sensitive data fields"""
    masked = data.copy()
    for field in fields:
        if field in masked:
            value = str(masked[field])
            if len(value) > 4:
                masked[field] = value[:2] + '*' * (len(value) - 4) + value[-2:]
            else:
                masked[field] = '****'
    return masked

def format_phone_number(phone: str, country: str = "ZM") -> str:
    """Format phone number to international format"""
    import phonenumbers
    try:
        parsed = phonenumbers.parse(phone, country)
        return phonenumbers.format_number(
            parsed,
            phonenumbers.PhoneNumberFormat.INTERNATIONAL
        )
    except:
        return phone

def parse_gps_coordinates(gps_string: str) -> Dict[str, float]:
    """Parse GPS coordinates from string"""
    # Format: "15.4167° S, 28.2833° E"
    patterns = [
        r'(-?\d+\.?\d*)[°\s]*([NS])[,\s]*(-?\d+\.?\d*)[°\s]*([EW])',
        r'(-?\d+\.?\d*)[,\s]+(-?\d+\.?\d*)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, gps_string, re.IGNORECASE)
        if match:
            if len(match.groups()) == 4:
                lat = float(match.group(1))
                if match.group(2).upper() == 'S':
                    lat = -lat
                lon = float(match.group(3))
                if match.group(4).upper() == 'W':
                    lon = -lon
                return {'latitude': lat, 'longitude': lon}
            else:
                return {
                    'latitude': float(match.group(1)),
                    'longitude': float(match.group(2))
                }
    
    raise ValueError(f"Could not parse GPS coordinates: {gps_string}")

def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between two GPS coordinates (Haversine formula)"""
    import math
    
    R = 6371  # Earth's radius in kilometers
    
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)
    
    a = math.sin(delta_lat/2)**2 + \
        math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    
    return R * c

def format_file_size(size_bytes: int) -> str:
    """Format file size in human-readable format"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} PB"

def chunk_list(lst: List, chunk_size: int) -> List[List]:
    """Split a list into chunks"""
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def merge_dicts(dict1: Dict, dict2: Dict, deep: bool = True) -> Dict:
    """Merge two dictionaries"""
    result = dict1.copy()
    
    for key, value in dict2.items():
        if deep and isinstance(value, dict) and key in result and isinstance(result[key], dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    
    return result

def timer_decorator(func):
    """Decorator to measure function execution time"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        logger.debug(f"{func.__name__} took {end - start:.3f}s")
        return result
    return wrapper

def retry_decorator(max_retries: int = 3, delay: int = 1):
    """Decorator to retry failed functions"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying...")
                    time.sleep(delay * (attempt + 1))
            return None
        return wrapper
    return decorator

class RateLimiter:
    """Rate limiter for API endpoints"""
    
    def __init__(self, max_requests: int, time_window: int):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = {}
    
    def is_allowed(self, client_id: str) -> bool:
        """Check if client is allowed to make request"""
        now = time.time()
        
        if client_id not in self.requests:
            self.requests[client_id] = []
        
        # Clean old requests
        self.requests[client_id] = [
            t for t in self.requests[client_id]
            if now - t < self.time_window
        ]
        
        if len(self.requests[client_id]) >= self.max_requests:
            return False
        
        self.requests[client_id].append(now)
        return True
    
    def get_remaining(self, client_id: str) -> int:
        """Get remaining requests for client"""
        if client_id not in self.requests:
            return self.max_requests
        
        now = time.time()
        recent = [t for t in self.requests[client_id] if now - t < self.time_window]
        return max(0, self.max_requests - len(recent))

class CacheManager:
    """Simple cache manager"""
    
    def __init__(self, default_ttl: int = 300):
        self.default_ttl = default_ttl
        self.cache = {}
        self.expiry = {}
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """Set cache value"""
        ttl = ttl or self.default_ttl
        self.cache[key] = value
        self.expiry[key] = time.time() + ttl
    
    def get(self, key: str) -> Optional[Any]:
        """Get cache value"""
        if key not in self.cache:
            return None
        
        if time.time() > self.expiry[key]:
            del self.cache[key]
            del self.expiry[key]
            return None
        
        return self.cache[key]
    
    def delete(self, key: str):
        """Delete cache key"""
        if key in self.cache:
            del self.cache[key]
        if key in self.expiry:
            del self.expiry[key]
    
    def clear(self):
        """Clear all cache"""
        self.cache.clear()
        self.expiry.clear()

class Paginator:
    """Simple pagination helper"""
    
    def __init__(self, items: List, page: int = 1, page_size: int = 20):
        self.items = items
        self.page = max(1, page)
        self.page_size = min(100, max(1, page_size))
        self.total = len(items)
        self.total_pages = (self.total + self.page_size - 1) // self.page_size
    
    def get_page(self) -> List:
        """Get current page items"""
        start = (self.page - 1) * self.page_size
        end = start + self.page_size
        return self.items[start:end]
    
    def get_metadata(self) -> Dict:
        """Get pagination metadata"""
        return {
            "page": self.page,
            "page_size": self.page_size,
            "total": self.total,
            "total_pages": self.total_pages,
            "has_next": self.page < self.total_pages,
            "has_previous": self.page > 1
        }

class DataExporter:
    """Export data in various formats"""
    
    @staticmethod
    def to_json(data: Any, pretty: bool = True) -> str:
        """Export to JSON"""
        if pretty:
            return json.dumps(data, indent=2, default=str)
        return json.dumps(data, default=str)
    
    @staticmethod
    def to_csv(data: List[Dict], headers: Optional[List[str]] = None) -> str:
        """Export to CSV"""
        import csv
        from io import StringIO
        
        if not data:
            return ""
        
        if not headers:
            headers = list(data[0].keys())
        
        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=headers)
        writer.writeheader()
        writer.writerows(data)
        
        return output.getvalue()
    
    @staticmethod
    def to_xml(data: Dict, root_name: str = "root") -> str:
        """Export to XML (simplified)"""
        import xml.etree.ElementTree as ET
        from xml.dom import minidom
        
        def dict_to_xml(parent, data):
            if isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, list):
                        for item in value:
                            elem = ET.SubElement(parent, key)
                            dict_to_xml(elem, item)
                    else:
                        elem = ET.SubElement(parent, key)
                        dict_to_xml(elem, value)
            else:
                parent.text = str(data)
        
        root = ET.Element(root_name)
        dict_to_xml(root, data)
        
        rough_string = ET.tostring(root, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ")

__all__ = [
    "generate_id",
    "generate_api_key",
    "hash_password",
    "verify_password",
    "create_jwt_token",
    "decode_jwt_token",
    "mask_sensitive_data",
    "format_phone_number",
    "parse_gps_coordinates",
    "calculate_distance",
    "format_file_size",
    "chunk_list",
    "merge_dicts",
    "timer_decorator",
    "retry_decorator",
    "RateLimiter",
    "CacheManager",
    "Paginator",
    "DataExporter"
]