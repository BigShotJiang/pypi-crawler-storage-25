"""
validators.py - Comprehensive data validation utilities
"""

import re
import json
from typing import Any, Dict, List, Optional, Union
from datetime import datetime, date
import phonenumbers
import email_validator
from pydantic import ValidationError

class DataValidator:
    """Comprehensive data validation utilities"""
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email address"""
        try:
            email_validator.validate_email(email)
            return True
        except email_validator.EmailNotValidError:
            return False
    
    @staticmethod
    def validate_phone(phone: str, country: str = "ZM") -> bool:
        """Validate phone number"""
        try:
            parsed = phonenumbers.parse(phone, country)
            return phonenumbers.is_valid_number(parsed)
        except:
            return False
    
    @staticmethod
    def validate_nrc(nrc: str) -> bool:
        """Validate Zambian National Registration Card number"""
        # Format: 123456/78/1
        pattern = r'^\d{6}/\d{2}/\d{1}$'
        if not re.match(pattern, nrc):
            return False
        
        # Validate check digit (simplified)
        parts = nrc.split('/')
        if len(parts) != 3:
            return False
        
        return True
    
    @staticmethod
    def validate_tpin(tpin: str) -> bool:
        """Validate Zambian Taxpayer PIN"""
        # Format: 1234567890
        pattern = r'^\d{10}$'
        return bool(re.match(pattern, tpin))
    
    @staticmethod
    def validate_gps_coordinates(lat: float, lon: float) -> bool:
        """Validate GPS coordinates"""
        return -90 <= lat <= 90 and -180 <= lon <= 180
    
    @staticmethod
    def validate_date_range(start_date: date, end_date: date) -> bool:
        """Validate date range"""
        return start_date <= end_date
    
    @staticmethod
    def validate_password_strength(password: str) -> Dict[str, bool]:
        """Validate password strength"""
        return {
            "length": len(password) >= 8,
            "uppercase": bool(re.search(r'[A-Z]', password)),
            "lowercase": bool(re.search(r'[a-z]', password)),
            "numbers": bool(re.search(r'[0-9]', password)),
            "special": bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password)),
            "no_spaces": " " not in password
        }
    
    @staticmethod
    def validate_farm_size(hectares: float) -> bool:
        """Validate farm size"""
        return 0 < hectares <= 100000
    
    @staticmethod
    def validate_yield_amount(amount: float, unit: str) -> bool:
        """Validate crop yield amount"""
        if amount <= 0:
            return False
        
        # Validate based on unit
        valid_units = ['kg', 'tonnes', 'bags', 'mt']
        return unit.lower() in valid_units
    
    @staticmethod
    def validate_json_schema(data: Dict, schema: Dict) -> List[str]:
        """Validate data against JSON schema"""
        errors = []
        
        def validate_field(field_name, field_value, field_schema):
            if 'required' in field_schema and field_schema['required']:
                if field_name not in data:
                    errors.append(f"Missing required field: {field_name}")
                    return
            
            if field_name not in data:
                return
            
            # Type validation
            expected_type = field_schema.get('type')
            if expected_type == 'string' and not isinstance(field_value, str):
                errors.append(f"{field_name} must be a string")
            elif expected_type == 'number' and not isinstance(field_value, (int, float)):
                errors.append(f"{field_name} must be a number")
            elif expected_type == 'integer' and not isinstance(field_value, int):
                errors.append(f"{field_name} must be an integer")
            elif expected_type == 'boolean' and not isinstance(field_value, bool):
                errors.append(f"{field_name} must be a boolean")
            elif expected_type == 'array' and not isinstance(field_value, list):
                errors.append(f"{field_name} must be an array")
            elif expected_type == 'object' and not isinstance(field_value, dict):
                errors.append(f"{field_name} must be an object")
            
            # Pattern validation for strings
            if expected_type == 'string' and 'pattern' in field_schema:
                if not re.match(field_schema['pattern'], str(field_value)):
                    errors.append(f"{field_name} does not match required pattern")
            
            # Range validation for numbers
            if expected_type in ['number', 'integer']:
                if 'minimum' in field_schema and field_value < field_schema['minimum']:
                    errors.append(f"{field_name} must be >= {field_schema['minimum']}")
                if 'maximum' in field_schema and field_value > field_schema['maximum']:
                    errors.append(f"{field_name} must be <= {field_schema['maximum']}")
            
            # Length validation for strings
            if expected_type == 'string':
                if 'minLength' in field_schema and len(str(field_value)) < field_schema['minLength']:
                    errors.append(f"{field_name} must be at least {field_schema['minLength']} characters")
                if 'maxLength' in field_schema and len(str(field_value)) > field_schema['maxLength']:
                    errors.append(f"{field_name} must be at most {field_schema['maxLength']} characters")
            
            # Enum validation
            if 'enum' in field_schema and field_value not in field_schema['enum']:
                errors.append(f"{field_name} must be one of: {field_schema['enum']}")
        
        for field_name, field_schema in schema.get('properties', {}).items():
            field_value = data.get(field_name)
            validate_field(field_name, field_value, field_schema)
        
        return errors
    
    @staticmethod
    def sanitize_input(text: str) -> str:
        """Sanitize user input to prevent injection attacks"""
        # Remove potentially dangerous characters
        dangerous = ['<', '>', '"', "'", ';', '--', '/*', '*/']
        for char in dangerous:
            text = text.replace(char, '')
        
        # Escape HTML
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        
        return text
    
    @staticmethod
    def validate_file_upload(filename: str, content_type: str, size: int) -> Dict[str, Any]:
        """Validate file upload"""
        allowed_extensions = {
            'images': ['.jpg', '.jpeg', '.png', '.gif', '.bmp'],
            'documents': ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.csv'],
            'data': ['.json', '.xml', '.geojson']
        }
        
        allowed_mime_types = {
            'images': ['image/jpeg', 'image/png', 'image/gif', 'image/bmp'],
            'documents': ['application/pdf', 'application/msword', 
                         'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                         'application/vnd.ms-excel',
                         'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                         'text/csv'],
            'data': ['application/json', 'application/xml', 'application/geo+json']
        }
        
        max_sizes = {
            'images': 10 * 1024 * 1024,  # 10MB
            'documents': 20 * 1024 * 1024,  # 20MB
            'data': 5 * 1024 * 1024  # 5MB
        }
        
        # Determine file type
        file_type = None
        for ftype, extensions in allowed_extensions.items():
            if any(filename.lower().endswith(ext) for ext in extensions):
                file_type = ftype
                break
        
        if not file_type:
            return {"valid": False, "error": "File type not allowed"}
        
        # Validate MIME type
        if content_type not in allowed_mime_types.get(file_type, []):
            return {"valid": False, "error": "Invalid file content type"}
        
        # Validate size
        if size > max_sizes[file_type]:
            max_size_mb = max_sizes[file_type] / (1024 * 1024)
            return {
                "valid": False,
                "error": f"File too large. Maximum size: {max_size_mb}MB"
            }
        
        return {
            "valid": True,
            "file_type": file_type,
            "size": size,
            "filename": filename
        }
    
    @staticmethod
    def validate_batch_operation(items: List[Any], max_items: int = 1000) -> Dict[str, Any]:
        """Validate batch operation"""
        if len(items) > max_items:
            return {
                "valid": False,
                "error": f"Batch size exceeds maximum of {max_items}"
            }
        
        if len(items) == 0:
            return {
                "valid": False,
                "error": "Batch cannot be empty"
            }
        
        return {
            "valid": True,
            "count": len(items)
        }

class AgriculturalDataValidator:
    """Specialized validator for agricultural data"""
    
    def __init__(self):
        self.validator = DataValidator()
    
    def validate_crop_data(self, data: Dict) -> List[str]:
        """Validate crop data"""
        errors = []
        
        # Required fields
        required = ['crop_type', 'planting_date', 'area_planted']
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: {field}")
        
        if 'planting_date' in data and 'harvest_date' in data:
            try:
                planting = datetime.strptime(data['planting_date'], '%Y-%m-%d').date()
                harvest = datetime.strptime(data['harvest_date'], '%Y-%m-%d').date()
                if harvest < planting:
                    errors.append("Harvest date cannot be before planting date")
            except:
                errors.append("Invalid date format. Use YYYY-MM-DD")
        
        if 'area_planted' in data:
            if not isinstance(data['area_planted'], (int, float)) or data['area_planted'] <= 0:
                errors.append("Area planted must be a positive number")
        
        return errors
    
    def validate_livestock_data(self, data: Dict) -> List[str]:
        """Validate livestock data"""
        errors = []
        
        required = ['livestock_type', 'count']
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: {field}")
        
        if 'count' in data:
            if not isinstance(data['count'], int) or data['count'] < 0:
                errors.append("Count must be a non-negative integer")
        
        if 'birth_rate' in data:
            if not 0 <= data['birth_rate'] <= 100:
                errors.append("Birth rate must be between 0 and 100")
        
        if 'mortality_rate' in data:
            if not 0 <= data['mortality_rate'] <= 100:
                errors.append("Mortality rate must be between 0 and 100")
        
        return errors
    
    def validate_soil_data(self, data: Dict) -> List[str]:
        """Validate soil data"""
        errors = []
        
        required = ['farm_id', 'sample_date']
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: {field}")
        
        if 'ph' in data:
            if not 0 <= data['ph'] <= 14:
                errors.append("pH must be between 0 and 14")
        
        if 'organic_matter' in data:
            if not 0 <= data['organic_matter'] <= 100:
                errors.append("Organic matter must be between 0 and 100")
        
        return errors
    
    def validate_weather_data(self, data: Dict) -> List[str]:
        """Validate weather data"""
        errors = []
        
        required = ['location', 'timestamp']
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: {field}")
        
        if 'location' in data:
            loc = data['location']
            if 'latitude' not in loc or 'longitude' not in loc:
                errors.append("Location must include latitude and longitude")
            else:
                if not -90 <= loc['latitude'] <= 90:
                    errors.append("Latitude must be between -90 and 90")
                if not -180 <= loc['longitude'] <= 180:
                    errors.append("Longitude must be between -180 and 180")
        
        if 'temperature' in data and data['temperature'] < -50:
            errors.append("Temperature seems too low")
        
        if 'humidity' in data and not 0 <= data['humidity'] <= 100:
            errors.append("Humidity must be between 0 and 100")
        
        return errors
    
    def validate_market_data(self, data: Dict) -> List[str]:
        """Validate market data"""
        errors = []
        
        required = ['product', 'price', 'market', 'date']
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: {field}")
        
        if 'price' in data and data['price'] <= 0:
            errors.append("Price must be positive")
        
        if 'min_price' in data and 'max_price' in data:
            if data['min_price'] > data['max_price']:
                errors.append("Min price cannot exceed max price")
        
        return errors

__all__ = [
    "DataValidator",
    "AgriculturalDataValidator"
]