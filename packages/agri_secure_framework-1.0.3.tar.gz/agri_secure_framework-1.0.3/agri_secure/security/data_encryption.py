"""
data_encryption.py - Field-level and transport-layer encryption helpers.

Extends the core AgriculturalEncryption module with:
  - Field-level encryption for database columns (PII, financial data)
  - Transparent encrypt/decrypt for Pydantic models
  - Key-per-tenant support
  - Searchable encryption (deterministic HMAC for equality queries)
  - TLS/transport security configuration helpers
"""

import base64
import hashlib
import hmac
import json
import logging
import os
from typing import Any, Dict, List, Optional, Set, Type, Union
from datetime import datetime

logger = logging.getLogger(__name__)


class FieldEncryptionError(Exception):
    """Raised when field encryption/decryption fails"""
    pass


class FieldEncryption:
    """
    Field-level encryption for sensitive database columns.

    Wraps the core AgriculturalEncryption engine and adds:
      - Declarative field marking (``encrypted_fields`` set)
      - Transparent encrypt-on-write / decrypt-on-read
      - Deterministic HMAC tokens for searchable encrypted fields
      - Per-tenant key isolation
      - Audit logging of every encrypt/decrypt operation

    Usage::

        from agri_secure.core.encryption import AgriculturalEncryption
        from agri_secure.security.data_encryption import FieldEncryption

        engine = AgriculturalEncryption(master_key=os.getenv("ENCRYPTION_KEY"))
        field_enc = FieldEncryption(
            encryption_engine=engine,
            encrypted_fields={"national_id", "phone", "bank_account"},
            searchable_fields={"national_id"},   # allow equality search
        )

        # Encrypt before saving to DB
        record = field_enc.encrypt_record({"name": "John", "national_id": "123456/78/1"})

        # Decrypt after reading from DB
        plain = field_enc.decrypt_record(record)

        # Search token for equality query
        token = field_enc.search_token("national_id", "123456/78/1")
        # Use token in: WHERE national_id_token = :token
    """

    def __init__(
        self,
        encryption_engine,                          # AgriculturalEncryption instance
        encrypted_fields: Optional[Set[str]] = None,
        searchable_fields: Optional[Set[str]] = None,
        tenant_id: Optional[str] = None,
        audit_enabled: bool = True,
    ):
        """
        Args:
            encryption_engine: Initialised AgriculturalEncryption instance
            encrypted_fields: Set of field names to encrypt automatically
            searchable_fields: Subset of encrypted_fields that need equality search
            tenant_id: Optional tenant identifier for key isolation
            audit_enabled: Log every encrypt/decrypt operation
        """
        self.engine = encryption_engine
        self.encrypted_fields: Set[str] = encrypted_fields or set()
        self.searchable_fields: Set[str] = searchable_fields or set()
        self.tenant_id = tenant_id
        self.audit_enabled = audit_enabled

        # Derive a stable HMAC key for searchable tokens
        self._hmac_key = self._derive_hmac_key()

        logger.info(
            f"FieldEncryption initialized | fields={len(self.encrypted_fields)} "
            f"searchable={len(self.searchable_fields)} tenant={tenant_id}"
        )

    # ------------------------------------------------------------------
    # Record-level helpers
    # ------------------------------------------------------------------

    def encrypt_record(
        self, record: Dict[str, Any], context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Encrypt all marked fields in a record dictionary.

        Args:
            record: Plain-text record dict
            context: Optional context string bound to the ciphertext (e.g. table name)

        Returns:
            New dict with encrypted values and optional search tokens
        """
        result = dict(record)
        ctx = context or self.tenant_id or "agri_secure"

        for field in self.encrypted_fields:
            if field in result and result[field] is not None:
                plain = result[field]
                plain_str = json.dumps(plain) if not isinstance(plain, str) else plain

                try:
                    ciphertext = self.engine.encrypt(plain_str, context=ctx)
                    result[field] = ciphertext
                except Exception as exc:
                    raise FieldEncryptionError(
                        f"Failed to encrypt field '{field}': {exc}"
                    ) from exc

                # Add search token for searchable fields
                if field in self.searchable_fields:
                    result[f"{field}_token"] = self.search_token(field, plain_str)

                if self.audit_enabled:
                    logger.debug(f"Field encrypted: {field} | context={ctx}")

        return result

    def decrypt_record(
        self, record: Dict[str, Any], context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Decrypt all marked fields in a record dictionary.

        Args:
            record: Record dict with encrypted values
            context: Context string used during encryption

        Returns:
            New dict with decrypted plain-text values
        """
        result = dict(record)
        ctx = context or self.tenant_id or "agri_secure"

        for field in self.encrypted_fields:
            if field in result and result[field] is not None:
                ciphertext = result[field]
                # Skip if already plain (e.g. not yet encrypted in dev)
                if not isinstance(ciphertext, (str, bytes)):
                    continue

                try:
                    plain_str = self.engine.decrypt(ciphertext, context=ctx)
                    # Try to restore original type
                    try:
                        result[field] = json.loads(plain_str)
                    except (json.JSONDecodeError, TypeError):
                        result[field] = plain_str
                except Exception as exc:
                    raise FieldEncryptionError(
                        f"Failed to decrypt field '{field}': {exc}"
                    ) from exc

                if self.audit_enabled:
                    logger.debug(f"Field decrypted: {field} | context={ctx}")

        return result

    def encrypt_fields(
        self, data: Dict[str, Any], fields: List[str], context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Encrypt a specific list of fields (ad-hoc, not using the declared set).

        Args:
            data: Input dictionary
            fields: List of field names to encrypt
            context: Encryption context

        Returns:
            Dict with specified fields encrypted
        """
        original_fields = self.encrypted_fields
        self.encrypted_fields = set(fields)
        try:
            return self.encrypt_record(data, context=context)
        finally:
            self.encrypted_fields = original_fields

    # ------------------------------------------------------------------
    # Searchable encryption
    # ------------------------------------------------------------------

    def search_token(self, field: str, value: str) -> str:
        """
        Generate a deterministic HMAC token for equality search on encrypted data.

        The token is safe to store alongside the ciphertext and query against.
        It reveals nothing about the plaintext to an attacker who does not know
        the HMAC key.

        Args:
            field: Field name (included in the HMAC to prevent cross-field attacks)
            value: Plain-text value to tokenise

        Returns:
            Hex-encoded HMAC-SHA256 token
        """
        message = f"{field}:{value}".encode()
        return hmac.new(self._hmac_key, message, hashlib.sha256).hexdigest()

    # ------------------------------------------------------------------
    # Pydantic model helpers
    # ------------------------------------------------------------------

    def encrypt_model(self, model_instance, context: Optional[str] = None) -> Dict[str, Any]:
        """
        Encrypt marked fields in a Pydantic model instance.

        Args:
            model_instance: Pydantic BaseModel instance
            context: Encryption context

        Returns:
            Dict suitable for database insertion with encrypted fields
        """
        try:
            data = model_instance.model_dump()
        except AttributeError:
            data = model_instance.dict()  # Pydantic v1 fallback
        return self.encrypt_record(data, context=context)

    def decrypt_to_model(
        self,
        record: Dict[str, Any],
        model_class: Type,
        context: Optional[str] = None,
    ):
        """
        Decrypt a database record and instantiate a Pydantic model.

        Args:
            record: Raw database record with encrypted fields
            model_class: Pydantic model class to instantiate
            context: Encryption context

        Returns:
            Instantiated Pydantic model with decrypted values
        """
        plain = self.decrypt_record(record, context=context)
        return model_class(**plain)

    # ------------------------------------------------------------------
    # Bulk operations
    # ------------------------------------------------------------------

    def encrypt_batch(
        self, records: List[Dict[str, Any]], context: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Encrypt a list of records."""
        return [self.encrypt_record(r, context=context) for r in records]

    def decrypt_batch(
        self, records: List[Dict[str, Any]], context: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Decrypt a list of records."""
        return [self.decrypt_record(r, context=context) for r in records]

    # ------------------------------------------------------------------
    # Transport security helpers
    # ------------------------------------------------------------------

    @staticmethod
    def get_tls_config(
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        ca_file: Optional[str] = None,
        min_version: str = "TLSv1.2",
    ) -> Dict[str, Any]:
        """
        Return a TLS configuration dict for use with database/HTTP clients.

        Args:
            cert_file: Path to client certificate
            key_file: Path to client private key
            ca_file: Path to CA certificate bundle
            min_version: Minimum TLS version (TLSv1.2 or TLSv1.3)

        Returns:
            Dict with ssl_context and connection kwargs
        """
        import ssl
        ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        ctx.minimum_version = (
            ssl.TLSVersion.TLSv1_2
            if min_version == "TLSv1.2"
            else ssl.TLSVersion.TLSv1_3
        )
        ctx.set_ciphers(
            "ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20:!aNULL:!MD5:!DSS"
        )

        if ca_file:
            ctx.load_verify_locations(ca_file)
        if cert_file and key_file:
            ctx.load_cert_chain(cert_file, key_file)

        return {
            "ssl_context": ctx,
            "ssl": True,
            "ssl_verify_cert": True,
            "ssl_ca": ca_file,
            "ssl_cert": cert_file,
            "ssl_key": key_file,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _derive_hmac_key(self) -> bytes:
        """Derive a stable HMAC key from the encryption engine's master key."""
        try:
            # Access the raw key material from the engine
            key_id = self.engine.current_key_id
            raw_key = self.engine.keys.get(key_id, b"")
            if isinstance(raw_key, str):
                raw_key = raw_key.encode()
            salt = (self.tenant_id or "agri_secure").encode()
            return hashlib.pbkdf2_hmac("sha256", raw_key, salt, iterations=100_000)
        except Exception:
            # Fallback: derive from a random seed (tokens won't survive restarts)
            logger.warning(
                "FieldEncryption: could not derive HMAC key from engine; "
                "using random seed — search tokens will not persist across restarts"
            )
            return os.urandom(32)

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict[str, Any]:
        """Return health status of the field encryption module."""
        try:
            test = self.engine.encrypt("health_check_test")
            self.engine.decrypt(test)
            engine_ok = True
        except Exception:
            engine_ok = False

        return {
            "module": "FieldEncryption",
            "encrypted_fields": sorted(self.encrypted_fields),
            "searchable_fields": sorted(self.searchable_fields),
            "tenant_id": self.tenant_id,
            "engine_healthy": engine_ok,
            "healthy": engine_ok,
        }
