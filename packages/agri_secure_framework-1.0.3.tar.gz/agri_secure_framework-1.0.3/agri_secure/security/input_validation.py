"""
input_validation.py - Comprehensive input validation and SQL injection prevention.

Provides a layered defence:
  1. Strict allow-list validation for every field type
  2. Parameterised-query enforcement helpers
  3. Pattern-based SQL injection detection (defence-in-depth)
  4. HTML/script injection sanitisation
  5. Pydantic-based schema validation helpers
"""

import re
import html
import logging
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)


class InputValidationError(Exception):
    """Raised when input fails validation"""
    pass


class SQLInjectionError(Exception):
    """Raised when SQL injection is detected"""
    pass


# ---------------------------------------------------------------------------
# SQL Injection Prevention
# ---------------------------------------------------------------------------

class SQLInjectionPrevention:
    """
    SQL injection detection and parameterised-query helpers.

    This class provides two layers of protection:

    1. **Parameterised query helpers** — the correct, primary defence.
       Always use these instead of string-formatting SQL.

    2. **Pattern detection** — a defence-in-depth layer that raises an
       alert when suspicious SQL patterns are found in user input.
       This is NOT a substitute for parameterised queries.

    Usage::

        sql_guard = SQLInjectionPrevention()

        # Safe query construction
        query, params = sql_guard.safe_query(
            "SELECT * FROM farms WHERE owner_id = {owner_id} AND district = {district}",
            owner_id="usr_abc",
            district="Lusaka",
        )
        cursor.execute(query, params)

        # Scan raw input before use
        sql_guard.scan(user_input)
    """

    # Patterns that indicate SQL injection attempts
    # Ordered from most specific to most general
    INJECTION_PATTERNS: List[Tuple[str, str]] = [
        # Classic comment-based bypass
        (r"(--|#|/\*|\*/)", "SQL comment sequence"),
        # UNION-based injection
        (r"\bUNION\b.*\bSELECT\b", "UNION SELECT injection"),
        # Stacked queries
        (r";\s*(DROP|DELETE|INSERT|UPDATE|CREATE|ALTER|EXEC|EXECUTE)\b", "stacked query"),
        # Boolean-based blind injection
        (r"\bOR\b\s+[\'\"]?\d+[\'\"]?\s*=\s*[\'\"]?\d+[\'\"]?", "boolean OR injection"),
        (r"\bAND\b\s+[\'\"]?\d+[\'\"]?\s*=\s*[\'\"]?\d+[\'\"]?", "boolean AND injection"),
        # Time-based blind injection
        (r"\bSLEEP\s*\(", "time-based SLEEP"),
        (r"\bWAITFOR\s+DELAY\b", "time-based WAITFOR"),
        (r"\bBENCHMARK\s*\(", "time-based BENCHMARK"),
        # Dangerous DDL/DML keywords in input context
        (r"\b(DROP|TRUNCATE)\s+(TABLE|DATABASE|SCHEMA)\b", "destructive DDL"),
        (r"\bEXEC(UTE)?\s*\(", "EXEC injection"),
        (r"\bxp_cmdshell\b", "xp_cmdshell"),
        # Hex/char encoding tricks
        (r"0x[0-9a-fA-F]{4,}", "hex-encoded payload"),
        (r"\bCHAR\s*\(\s*\d+", "CHAR() encoding"),
        # Information schema probing
        (r"\binformation_schema\b", "schema probing"),
        (r"\bsys\.(tables|columns|objects)\b", "sys table probing"),
    ]

    def __init__(self, strict_mode: bool = True):
        """
        Args:
            strict_mode: If True, raise on detection; if False, only log a warning.
        """
        self.strict_mode = strict_mode
        self._compiled = [
            (re.compile(pattern, re.IGNORECASE), label)
            for pattern, label in self.INJECTION_PATTERNS
        ]
        logger.info(f"SQLInjectionPrevention initialized | strict_mode={strict_mode}")

    def scan(self, value: Any, field_name: str = "input") -> str:
        """
        Scan a string value for SQL injection patterns.

        Args:
            value: The value to scan (converted to str)
            field_name: Field name for error messages

        Returns:
            The original value (as str) if clean

        Raises:
            SQLInjectionError: If a pattern is detected and strict_mode=True
        """
        text = str(value)
        for pattern, label in self._compiled:
            if pattern.search(text):
                msg = (
                    f"Potential SQL injection detected in field '{field_name}': {label}"
                )
                if self.strict_mode:
                    logger.error(msg)
                    raise SQLInjectionError(msg)
                else:
                    logger.warning(msg)
        return text

    def scan_dict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Scan all string values in a dictionary.

        Args:
            data: Dictionary of field_name -> value

        Returns:
            The original dict if all values are clean

        Raises:
            SQLInjectionError: If any value contains injection patterns
        """
        for field, value in data.items():
            if isinstance(value, str):
                self.scan(value, field_name=field)
            elif isinstance(value, dict):
                self.scan_dict(value)
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    if isinstance(item, str):
                        self.scan(item, field_name=f"{field}[{i}]")
        return data

    def safe_query(self, template: str, **params) -> Tuple[str, tuple]:
        """
        Build a parameterised SQL query from a template.

        Replace ``{placeholder}`` tokens with ``%s`` (psycopg2/MySQLdb style)
        and return the ordered parameter tuple.

        Example::

            query, args = sql_guard.safe_query(
                "SELECT * FROM farms WHERE owner_id = {owner_id}",
                owner_id="usr_abc123",
            )
            cursor.execute(query, args)

        Args:
            template: SQL template with ``{name}`` placeholders
            **params: Named parameter values

        Returns:
            Tuple of (parameterised_query_string, params_tuple)
        """
        ordered_params = []
        placeholder_pattern = re.compile(r"\{(\w+)\}")

        def replace(match):
            name = match.group(1)
            if name not in params:
                raise InputValidationError(
                    f"Missing parameter '{name}' for SQL template"
                )
            ordered_params.append(params[name])
            return "%s"

        query = placeholder_pattern.sub(replace, template)
        return query, tuple(ordered_params)

    def safe_like(self, value: str) -> str:
        """
        Escape a value for use in a SQL LIKE clause.

        Args:
            value: Raw user input

        Returns:
            Escaped string safe for LIKE patterns
        """
        return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    def safe_identifier(self, identifier: str) -> str:
        """
        Validate and quote a SQL identifier (table/column name).

        Only allows alphanumeric characters and underscores.

        Args:
            identifier: Table or column name

        Returns:
            Quoted identifier

        Raises:
            InputValidationError: If the identifier contains invalid characters
        """
        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", identifier):
            raise InputValidationError(
                f"Invalid SQL identifier: '{identifier}'. "
                "Only letters, digits, and underscores are allowed."
            )
        return f'"{identifier}"'


# ---------------------------------------------------------------------------
# General Input Validator
# ---------------------------------------------------------------------------

class InputValidator:
    """
    Comprehensive input validation with allow-list approach.

    Validates and sanitises user-supplied data before it reaches the
    business logic or database layer.

    Usage::

        validator = InputValidator()

        clean = validator.validate_and_sanitize({
            "username": "john.farmer",
            "district": "Lusaka",
            "farm_size": "12.5",
        }, rules={
            "username": {"type": "username"},
            "district": {"type": "text", "max_length": 100},
            "farm_size": {"type": "decimal", "min": 0.01, "max": 100000},
        })
    """

    # Pre-compiled allow-list patterns
    PATTERNS: Dict[str, re.Pattern] = {
        "username":    re.compile(r"^[a-zA-Z0-9_]{3,50}$"),
        "alphanumeric": re.compile(r"^[a-zA-Z0-9]+$"),
        "alpha":       re.compile(r"^[a-zA-Z\s]+$"),
        "slug":        re.compile(r"^[a-z0-9\-]+$"),
        "uuid":        re.compile(
            r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
            re.IGNORECASE,
        ),
        "email":       re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"),
        "phone_zm":    re.compile(r"^\+?[0-9]{10,15}$"),
        "nrc":         re.compile(r"^\d{6}/\d{2}/\d{1}$"),
        "tpin":        re.compile(r"^\d{10}$"),
        "date":        re.compile(r"^\d{4}-\d{2}-\d{2}$"),
        "datetime":    re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}"),
        "ipv4":        re.compile(
            r"^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$"
        ),
        "url":         re.compile(r"^https?://[^\s/$.?#].[^\s]*$", re.IGNORECASE),
        "hex_color":   re.compile(r"^#[0-9a-fA-F]{6}$"),
        "latitude":    re.compile(r"^-?(90(\.0+)?|[1-8]?\d(\.\d+)?)$"),
        "longitude":   re.compile(r"^-?(180(\.0+)?|1[0-7]\d(\.\d+)?|\d{1,2}(\.\d+)?)$"),
    }

    # Characters that are always stripped from text fields
    STRIP_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

    def __init__(self, sql_guard: Optional[SQLInjectionPrevention] = None):
        """
        Args:
            sql_guard: Optional SQLInjectionPrevention instance for deep scanning
        """
        self.sql_guard = sql_guard or SQLInjectionPrevention()

    # ------------------------------------------------------------------
    # Main validation entry point
    # ------------------------------------------------------------------

    def validate_and_sanitize(
        self,
        data: Dict[str, Any],
        rules: Dict[str, Dict[str, Any]],
        strict: bool = True,
    ) -> Dict[str, Any]:
        """
        Validate and sanitise a dictionary of user inputs.

        Args:
            data: Raw input dictionary
            rules: Validation rules per field.  Each rule is a dict with:
                - type (str): One of text, integer, decimal, boolean, email,
                  username, phone, date, datetime, uuid, url, enum, pattern
                - required (bool): Default False
                - min_length / max_length (int): For text fields
                - min / max (float): For numeric fields
                - enum (list): Allowed values
                - pattern (str): Custom regex pattern
                - allow_html (bool): Default False — strip HTML tags
            strict: Raise on first error (True) or collect all errors (False)

        Returns:
            Dict of sanitised values

        Raises:
            InputValidationError: If validation fails (in strict mode)
        """
        errors: Dict[str, str] = {}
        clean: Dict[str, Any] = {}

        for field, rule in rules.items():
            raw = data.get(field)
            required = rule.get("required", False)

            if raw is None or raw == "":
                if required:
                    errors[field] = "This field is required"
                continue

            try:
                clean[field] = self._validate_field(field, raw, rule)
            except InputValidationError as exc:
                if strict:
                    raise
                errors[field] = str(exc)

        if errors:
            raise InputValidationError(f"Validation failed: {errors}")

        # SQL injection scan on all string values
        self.sql_guard.scan_dict(clean)

        return clean

    def _validate_field(self, field: str, value: Any, rule: Dict[str, Any]) -> Any:
        """Validate and sanitise a single field."""
        field_type = rule.get("type", "text")

        if field_type == "text":
            return self._validate_text(field, value, rule)
        elif field_type == "integer":
            return self._validate_integer(field, value, rule)
        elif field_type == "decimal":
            return self._validate_decimal(field, value, rule)
        elif field_type == "boolean":
            return self._validate_boolean(field, value)
        elif field_type == "email":
            return self._validate_pattern(field, str(value).strip(), "email")
        elif field_type == "username":
            return self._validate_pattern(field, str(value).strip(), "username")
        elif field_type == "phone":
            return self._validate_pattern(field, str(value).strip(), "phone_zm")
        elif field_type == "date":
            return self._validate_pattern(field, str(value).strip(), "date")
        elif field_type == "datetime":
            return self._validate_pattern(field, str(value).strip(), "datetime")
        elif field_type == "uuid":
            return self._validate_pattern(field, str(value).strip(), "uuid")
        elif field_type == "url":
            return self._validate_pattern(field, str(value).strip(), "url")
        elif field_type == "enum":
            return self._validate_enum(field, value, rule)
        elif field_type == "pattern":
            custom = rule.get("pattern")
            if not custom:
                raise InputValidationError(f"Field '{field}': 'pattern' rule requires a pattern")
            if not re.match(custom, str(value)):
                raise InputValidationError(
                    f"Field '{field}' does not match the required format"
                )
            return str(value)
        else:
            raise InputValidationError(f"Unknown field type '{field_type}' for field '{field}'")

    # ------------------------------------------------------------------
    # Type-specific validators
    # ------------------------------------------------------------------

    def _validate_text(self, field: str, value: Any, rule: Dict[str, Any]) -> str:
        text = str(value)
        # Strip control characters
        text = self.STRIP_CHARS.sub("", text).strip()

        # Strip HTML unless explicitly allowed
        if not rule.get("allow_html", False):
            text = self.strip_html(text)

        min_len = rule.get("min_length", 0)
        max_len = rule.get("max_length", 10000)

        if len(text) < min_len:
            raise InputValidationError(
                f"Field '{field}' must be at least {min_len} characters"
            )
        if len(text) > max_len:
            raise InputValidationError(
                f"Field '{field}' must be at most {max_len} characters"
            )
        return text

    def _validate_integer(self, field: str, value: Any, rule: Dict[str, Any]) -> int:
        try:
            num = int(str(value).strip())
        except (ValueError, TypeError):
            raise InputValidationError(f"Field '{field}' must be an integer")
        self._check_range(field, num, rule)
        return num

    def _validate_decimal(self, field: str, value: Any, rule: Dict[str, Any]) -> float:
        try:
            num = float(str(value).strip())
        except (ValueError, TypeError):
            raise InputValidationError(f"Field '{field}' must be a number")
        self._check_range(field, num, rule)
        return num

    def _validate_boolean(self, field: str, value: Any) -> bool:
        if isinstance(value, bool):
            return value
        if str(value).lower() in ("true", "1", "yes", "on"):
            return True
        if str(value).lower() in ("false", "0", "no", "off"):
            return False
        raise InputValidationError(f"Field '{field}' must be a boolean value")

    def _validate_pattern(self, field: str, value: str, pattern_name: str) -> str:
        pattern = self.PATTERNS.get(pattern_name)
        if pattern and not pattern.match(value):
            raise InputValidationError(
                f"Field '{field}' has an invalid format (expected {pattern_name})"
            )
        return value

    def _validate_enum(self, field: str, value: Any, rule: Dict[str, Any]) -> Any:
        allowed = rule.get("enum", [])
        if value not in allowed:
            raise InputValidationError(
                f"Field '{field}' must be one of: {allowed}"
            )
        return value

    def _check_range(self, field: str, num: Union[int, float], rule: Dict[str, Any]) -> None:
        if "min" in rule and num < rule["min"]:
            raise InputValidationError(
                f"Field '{field}' must be >= {rule['min']}"
            )
        if "max" in rule and num > rule["max"]:
            raise InputValidationError(
                f"Field '{field}' must be <= {rule['max']}"
            )

    # ------------------------------------------------------------------
    # Sanitisation utilities
    # ------------------------------------------------------------------

    @staticmethod
    def strip_html(text: str) -> str:
        """Remove HTML tags and decode HTML entities."""
        # Decode entities first
        text = html.unescape(text)
        # Remove tags
        text = re.sub(r"<[^>]+>", "", text)
        return text

    @staticmethod
    def escape_html(text: str) -> str:
        """Escape HTML special characters for safe display."""
        return html.escape(text, quote=True)

    @staticmethod
    def sanitize_for_log(value: str, max_length: int = 200) -> str:
        """
        Sanitise a value before writing it to a log file.

        Prevents log injection by removing newlines and truncating.
        """
        safe = re.sub(r"[\r\n\t]", " ", str(value))
        return safe[:max_length]

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict[str, Any]:
        """Return health status of the input validation module."""
        return {
            "module": "InputValidator",
            "sql_injection_patterns": len(SQLInjectionPrevention.INJECTION_PATTERNS),
            "validation_types": list(self.PATTERNS.keys()),
            "healthy": True,
        }
