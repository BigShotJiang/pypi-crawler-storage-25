"""
file_upload.py - Secure file upload handling for agricultural data systems.

Provides deep content inspection, malware signature scanning, path traversal
prevention, and quarantine support.  Works with Django, Flask, and FastAPI.
"""

import os
import re
import hashlib
import logging
import mimetypes
import struct
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple, BinaryIO, Union
from datetime import datetime

logger = logging.getLogger(__name__)


class FileUploadError(Exception):
    """Raised when a file upload fails security checks"""
    pass


class SecureFileUpload:
    """
    Secure file upload handler with deep content inspection.

    Features:
        - Magic-byte (file signature) validation — not just extension/MIME
        - Extension allow-list enforcement
        - MIME type verification
        - File size limits per category
        - Path traversal prevention
        - Filename sanitization
        - Duplicate detection via SHA-256 hash
        - Quarantine directory for suspicious files
        - Audit logging of every upload attempt
        - Configurable storage paths

    Usage::

        uploader = SecureFileUpload(
            upload_dir="/var/agri_secure/uploads",
            quarantine_dir="/var/agri_secure/quarantine",
        )

        result = uploader.process_upload(
            file_data=file_bytes,
            filename="farm_photo.jpg",
            content_type="image/jpeg",
            uploaded_by="usr_abc123",
        )
    """

    # Magic bytes (file signatures) for allowed types
    MAGIC_BYTES: Dict[str, List[bytes]] = {
        "image/jpeg":   [b"\xff\xd8\xff"],
        "image/png":    [b"\x89PNG\r\n\x1a\n"],
        "image/gif":    [b"GIF87a", b"GIF89a"],
        "image/bmp":    [b"BM"],
        "image/webp":   [b"RIFF"],
        "application/pdf": [b"%PDF-"],
        "application/zip": [b"PK\x03\x04"],
        "text/csv":     [],   # No reliable magic bytes; rely on extension + MIME
        "application/json": [],
        "application/xml":  [],
        "text/plain":   [],
    }

    # Allowed extensions mapped to MIME types
    ALLOWED_EXTENSIONS: Dict[str, str] = {
        ".jpg":  "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png":  "image/png",
        ".gif":  "image/gif",
        ".bmp":  "image/bmp",
        ".webp": "image/webp",
        ".pdf":  "application/pdf",
        ".csv":  "text/csv",
        ".json": "application/json",
        ".xml":  "application/xml",
        ".txt":  "text/plain",
    }

    # Dangerous extensions that must never be accepted
    BLOCKED_EXTENSIONS: set = {
        ".exe", ".bat", ".cmd", ".sh", ".ps1", ".vbs", ".js", ".jar",
        ".py", ".rb", ".php", ".asp", ".aspx", ".jsp", ".cgi",
        ".dll", ".so", ".dylib", ".msi", ".deb", ".rpm",
        ".zip", ".tar", ".gz", ".7z", ".rar",  # archives blocked by default
    }

    # Max sizes per category (bytes)
    MAX_SIZES: Dict[str, int] = {
        "image":    10 * 1024 * 1024,   # 10 MB
        "document": 20 * 1024 * 1024,   # 20 MB
        "data":      5 * 1024 * 1024,   #  5 MB
        "default":   2 * 1024 * 1024,   #  2 MB
    }

    # Simple malware signature patterns (hex strings in file content)
    MALWARE_SIGNATURES: List[bytes] = [
        b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR",  # EICAR test string
        b"eval(base64_decode(",                    # PHP webshell pattern
        b"<script>document.write(unescape(",       # JS obfuscation
        b"cmd.exe /c",                             # Windows shell execution
        b"/bin/sh -c",                             # Unix shell execution
    ]

    def __init__(
        self,
        upload_dir: str = "uploads",
        quarantine_dir: str = "quarantine",
        max_filename_length: int = 255,
        allow_archives: bool = False,
        scan_for_malware: bool = True,
        generate_unique_names: bool = True,
    ):
        """
        Args:
            upload_dir: Directory for accepted uploads
            quarantine_dir: Directory for quarantined suspicious files
            max_filename_length: Maximum sanitized filename length
            allow_archives: Allow ZIP/TAR archives (disabled by default)
            scan_for_malware: Scan file content for malware signatures
            generate_unique_names: Rename files to UUID-based names on save
        """
        self.upload_dir = Path(upload_dir)
        self.quarantine_dir = Path(quarantine_dir)
        self.max_filename_length = max_filename_length
        self.scan_for_malware = scan_for_malware
        self.generate_unique_names = generate_unique_names

        if allow_archives:
            self.BLOCKED_EXTENSIONS -= {".zip", ".tar", ".gz", ".7z", ".rar"}

        # Ensure directories exist
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.quarantine_dir.mkdir(parents=True, exist_ok=True)

        logger.info(
            f"SecureFileUpload initialized | upload_dir={upload_dir} "
            f"quarantine_dir={quarantine_dir}"
        )

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def process_upload(
        self,
        file_data: bytes,
        filename: str,
        content_type: str,
        uploaded_by: str,
        category: Optional[str] = None,
        save_file: bool = True,
    ) -> Dict[str, Any]:
        """
        Validate and optionally save an uploaded file.

        Args:
            file_data: Raw file bytes
            filename: Original filename from the client
            content_type: MIME type declared by the client
            uploaded_by: User ID performing the upload
            category: Override category for size limit (image/document/data)
            save_file: Whether to persist the file to disk

        Returns:
            Dict with keys: success, safe_filename, sha256, size, category,
            content_type, saved_path (if save_file=True)

        Raises:
            FileUploadError: If any security check fails
        """
        # 1. Sanitize filename
        safe_name = self.sanitize_filename(filename)

        # 2. Extension check
        self._check_extension(safe_name)

        # 3. Size check
        detected_category = category or self._detect_category(safe_name)
        self._check_size(len(file_data), detected_category)

        # 4. Magic-byte validation
        self._check_magic_bytes(file_data, safe_name, content_type)

        # 5. MIME type consistency
        self._check_mime_consistency(safe_name, content_type)

        # 6. Malware scan
        if self.scan_for_malware:
            self._scan_malware(file_data, safe_name, uploaded_by)

        # 7. Compute hash for deduplication / integrity
        sha256 = hashlib.sha256(file_data).hexdigest()

        result: Dict[str, Any] = {
            "success": True,
            "original_filename": filename,
            "safe_filename": safe_name,
            "sha256": sha256,
            "size": len(file_data),
            "category": detected_category,
            "content_type": content_type,
            "uploaded_by": uploaded_by,
            "uploaded_at": datetime.utcnow().isoformat(),
        }

        # 8. Save file
        if save_file:
            saved_path = self._save_file(file_data, safe_name, sha256)
            result["saved_path"] = str(saved_path)

        logger.info(
            f"File upload accepted | filename={safe_name} | "
            f"size={len(file_data)} | user={uploaded_by} | sha256={sha256[:16]}…"
        )
        return result

    # ------------------------------------------------------------------
    # Validation methods
    # ------------------------------------------------------------------

    def sanitize_filename(self, filename: str) -> str:
        """
        Sanitize a filename to prevent path traversal and injection.

        - Strips directory components
        - Removes null bytes and control characters
        - Replaces spaces and special chars with underscores
        - Truncates to max_filename_length
        - Preserves the file extension

        Args:
            filename: Raw filename from the client

        Returns:
            Safe filename string
        """
        if not filename:
            raise FileUploadError("Filename cannot be empty")

        # Strip directory components (path traversal prevention)
        name = os.path.basename(filename)
        name = name.replace("..", "").replace("/", "").replace("\\", "")

        # Remove null bytes and control characters
        name = re.sub(r"[\x00-\x1f\x7f]", "", name)

        # Replace dangerous characters
        name = re.sub(r"[^\w.\-]", "_", name)

        # Collapse multiple dots (prevent double-extension tricks like file.php.jpg)
        parts = name.rsplit(".", 1)
        if len(parts) == 2:
            stem = re.sub(r"\.+", "_", parts[0])
            ext = parts[1].lower()
            name = f"{stem}.{ext}"
        else:
            name = re.sub(r"\.+", "_", name)

        # Truncate
        if len(name) > self.max_filename_length:
            ext = Path(name).suffix
            stem = name[: self.max_filename_length - len(ext)]
            name = stem + ext

        if not name or name in (".", ".."):
            raise FileUploadError("Invalid filename after sanitization")

        return name

    def _check_extension(self, filename: str) -> None:
        ext = Path(filename).suffix.lower()
        if ext in self.BLOCKED_EXTENSIONS:
            raise FileUploadError(f"File extension '{ext}' is not allowed")
        if ext not in self.ALLOWED_EXTENSIONS:
            raise FileUploadError(
                f"File extension '{ext}' is not in the allowed list: "
                f"{sorted(self.ALLOWED_EXTENSIONS.keys())}"
            )

    def _check_size(self, size: int, category: str) -> None:
        limit = self.MAX_SIZES.get(category, self.MAX_SIZES["default"])
        if size > limit:
            limit_mb = limit / (1024 * 1024)
            raise FileUploadError(
                f"File size {size / (1024*1024):.1f} MB exceeds the "
                f"{category} limit of {limit_mb:.0f} MB"
            )
        if size == 0:
            raise FileUploadError("File is empty")

    def _check_magic_bytes(self, data: bytes, filename: str, content_type: str) -> None:
        """Verify file content matches its declared type via magic bytes."""
        ext = Path(filename).suffix.lower()
        expected_mime = self.ALLOWED_EXTENSIONS.get(ext, "")
        signatures = self.MAGIC_BYTES.get(expected_mime, [])

        if not signatures:
            # No magic bytes defined for this type (e.g. CSV, JSON) — skip
            return

        for sig in signatures:
            if data[: len(sig)] == sig:
                return

        raise FileUploadError(
            f"File content does not match declared type '{expected_mime}'. "
            "Possible file spoofing attempt."
        )

    def _check_mime_consistency(self, filename: str, declared_mime: str) -> None:
        """Ensure the declared MIME type matches the file extension."""
        ext = Path(filename).suffix.lower()
        expected_mime = self.ALLOWED_EXTENSIONS.get(ext)
        if expected_mime and declared_mime:
            # Normalize: text/csv vs application/csv are both acceptable
            if declared_mime not in (expected_mime, "application/octet-stream"):
                logger.warning(
                    f"MIME mismatch: extension={ext} expected={expected_mime} "
                    f"declared={declared_mime}"
                )
                # Warn but don't block — some browsers send generic MIME types

    def _scan_malware(self, data: bytes, filename: str, uploaded_by: str) -> None:
        """Scan file bytes for known malware signatures."""
        for sig in self.MALWARE_SIGNATURES:
            if sig in data:
                self._quarantine(data, filename, uploaded_by, reason="malware_signature")
                raise FileUploadError(
                    f"File '{filename}' contains a known malware signature and has been quarantined"
                )

    # ------------------------------------------------------------------
    # Storage helpers
    # ------------------------------------------------------------------

    def _detect_category(self, filename: str) -> str:
        ext = Path(filename).suffix.lower()
        if ext in {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"}:
            return "image"
        if ext in {".pdf", ".doc", ".docx", ".xls", ".xlsx"}:
            return "document"
        if ext in {".csv", ".json", ".xml", ".txt"}:
            return "data"
        return "default"

    def _save_file(self, data: bytes, filename: str, sha256: str) -> Path:
        """Save file to the upload directory, optionally with a unique name."""
        if self.generate_unique_names:
            ext = Path(filename).suffix.lower()
            dest = self.upload_dir / f"{sha256[:32]}{ext}"
        else:
            dest = self.upload_dir / filename

        dest.write_bytes(data)
        return dest

    def _quarantine(
        self, data: bytes, filename: str, uploaded_by: str, reason: str
    ) -> None:
        """Move a suspicious file to the quarantine directory."""
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        dest = self.quarantine_dir / f"{ts}_{filename}"
        dest.write_bytes(data)
        logger.error(
            f"File quarantined | filename={filename} | reason={reason} | "
            f"user={uploaded_by} | path={dest}"
        )

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict[str, Any]:
        """Return health status of the file upload module."""
        return {
            "module": "SecureFileUpload",
            "upload_dir": str(self.upload_dir),
            "upload_dir_exists": self.upload_dir.exists(),
            "quarantine_dir": str(self.quarantine_dir),
            "quarantine_dir_exists": self.quarantine_dir.exists(),
            "malware_scan_enabled": self.scan_for_malware,
            "allowed_extensions": sorted(self.ALLOWED_EXTENSIONS.keys()),
            "healthy": self.upload_dir.exists() and self.quarantine_dir.exists(),
        }
