﻿"""
mfa.py - Complete Multi-Factor Authentication system for agri_secure.

Supports all MFA types:
  - TOTP  : Time-based One-Time Password (Google Authenticator, Authy)
  - SMS   : OTP delivered via SMS (Twilio / Africa's Talking)
  - Email : OTP delivered via email (SMTP / SendGrid)
  - Backup codes : Single-use recovery codes
  - WebAuthn stub : FIDO2/WebAuthn placeholder for hardware keys

NIST SP 800-63B compliant:
  - 6-digit codes, 30-second window
  - Rate limiting on verification attempts
  - Secure backup code storage (bcrypt hashed)
  - Audit logging of every MFA event
"""

import base64
import hashlib
import hmac
import json
import logging
import os
import secrets
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from io import BytesIO
from typing import Any, Dict, List, Optional, Tuple

import bcrypt
import pyotp
import qrcode

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums & data classes
# ---------------------------------------------------------------------------

class MFAType(str, Enum):
    TOTP    = "totp"
    SMS     = "sms"
    EMAIL   = "email"
    BACKUP  = "backup"
    WEBAUTHN = "webauthn"


class MFAError(Exception):
    """Base MFA error"""
    pass

class MFANotSetupError(MFAError):
    """MFA has not been configured for this user"""
    pass

class MFAInvalidCodeError(MFAError):
    """Submitted code is wrong or expired"""
    pass

class MFARateLimitError(MFAError):
    """Too many verification attempts"""
    pass

class MFAExpiredError(MFAError):
    """OTP code has expired"""
    pass


@dataclass
class MFAConfig:
    """Stored MFA configuration for one user"""
    user_id: str
    mfa_type: MFAType
    enabled: bool = False
    verified: bool = False          # user completed setup verification
    totp_secret: Optional[str] = None
    backup_codes: List[str] = field(default_factory=list)   # bcrypt hashes
    phone: Optional[str] = None
    email: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    last_used: Optional[str] = None
    attempt_count: int = 0
    locked_until: Optional[float] = None   # unix timestamp


# ---------------------------------------------------------------------------
# Main MFA manager
# ---------------------------------------------------------------------------

class MFAManager:
    """
    Complete Multi-Factor Authentication manager.

    Features:
        - TOTP (Google Authenticator / Authy) with QR code generation
        - SMS OTP via Twilio or Africa's Talking
        - Email OTP via SMTP or SendGrid
        - 10 single-use backup recovery codes (bcrypt hashed)
        - WebAuthn/FIDO2 stub (ready for integration)
        - Rate limiting: max 5 attempts before 15-minute lockout
        - Redis-backed storage with in-memory fallback
        - Full audit logging

    Usage::

        mfa = MFAManager(app_name="AgriSecure")

        # Setup TOTP for a user
        setup = mfa.setup_totp("usr_abc123", username="john.farmer")
        # -> returns secret + QR code PNG (base64)

        # User scans QR, enters first code to confirm setup
        mfa.confirm_setup("usr_abc123", code="123456")

        # On every login, verify the submitted code
        mfa.verify("usr_abc123", code="123456")
    """

    MAX_ATTEMPTS   = 5
    LOCKOUT_SECS   = 900        # 15 minutes
    OTP_TTL        = 300        # 5 minutes for SMS/Email OTPs
    BACKUP_COUNT   = 10
    TOTP_WINDOW    = 1          # ±1 period tolerance

    def __init__(
        self,
        app_name: str = "AgriSecure",
        issuer: str = "agri-secure-framework",
        redis_url: Optional[str] = None,
        sms_provider: Optional[str] = None,     # "twilio" | "africastalking"
        sms_config: Optional[Dict] = None,
        email_provider: Optional[str] = None,   # "smtp" | "sendgrid"
        email_config: Optional[Dict] = None,
    ):
        self.app_name      = app_name
        self.issuer        = issuer
        self.sms_provider  = sms_provider
        self.sms_config    = sms_config or {}
        self.email_provider = email_provider
        self.email_config  = email_config or {}

        # Storage
        self._redis = None
        self._store: Dict[str, MFAConfig] = {}      # user_id -> MFAConfig
        self._otp_store: Dict[str, Dict] = {}       # user_id -> {code, expires_at}

        if redis_url:
            try:
                import redis as redis_lib
                self._redis = redis_lib.from_url(redis_url, decode_responses=True)
                self._redis.ping()
                logger.info("MFAManager: connected to Redis")
            except Exception as exc:
                logger.warning(f"MFAManager: Redis unavailable ({exc}), using memory")

        logger.info(f"MFAManager initialized | app={app_name}")

    # ------------------------------------------------------------------
    # TOTP setup
    # ------------------------------------------------------------------

    def setup_totp(self, user_id: str, username: str) -> Dict[str, Any]:
        """
        Generate a TOTP secret and QR code for the user.

        The user must scan the QR code with Google Authenticator / Authy,
        then call confirm_setup() with the first code to activate MFA.

        Args:
            user_id:  Unique user identifier
            username: Display name shown in the authenticator app

        Returns:
            Dict with keys: secret, qr_code_base64, otpauth_uri, backup_codes
        """
        secret = pyotp.random_base32()
        totp   = pyotp.TOTP(secret)
        uri    = totp.provisioning_uri(name=username, issuer_name=self.app_name)

        # QR code as base64 PNG
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = BytesIO()
        img.save(buf, format="PNG")
        qr_b64 = base64.b64encode(buf.getvalue()).decode()

        # Generate backup codes
        plain_codes, hashed_codes = self._generate_backup_codes()

        cfg = MFAConfig(
            user_id    = user_id,
            mfa_type   = MFAType.TOTP,
            enabled    = False,     # enabled only after confirm_setup
            verified   = False,
            totp_secret = secret,
            backup_codes = hashed_codes,
        )
        self._save_config(cfg)

        logger.info(f"TOTP setup initiated for user {user_id}")
        return {
            "mfa_type":       MFAType.TOTP,
            "secret":         secret,
            "otpauth_uri":    uri,
            "qr_code_base64": qr_b64,
            "backup_codes":   plain_codes,   # show ONCE, never again
            "message":        "Scan the QR code with Google Authenticator, then call confirm_setup().",
        }

    def confirm_setup(self, user_id: str, code: str) -> Dict[str, Any]:
        """
        Confirm MFA setup by verifying the first code from the authenticator.

        Args:
            user_id: User identifier
            code:    6-digit code from the authenticator app

        Returns:
            Dict with success and message

        Raises:
            MFANotSetupError: setup_totp() was not called first
            MFAInvalidCodeError: code is wrong
        """
        cfg = self._load_config(user_id)
        if not cfg or cfg.mfa_type != MFAType.TOTP:
            raise MFANotSetupError("TOTP setup not initiated. Call setup_totp() first.")

        totp = pyotp.TOTP(cfg.totp_secret)
        if not totp.verify(code, valid_window=self.TOTP_WINDOW):
            raise MFAInvalidCodeError("Invalid TOTP code. Check your authenticator app.")

        cfg.enabled  = True
        cfg.verified = True
        cfg.updated_at = datetime.utcnow().isoformat()
        self._save_config(cfg)

        logger.info(f"MFA confirmed and enabled for user {user_id}")
        return {"success": True, "mfa_type": MFAType.TOTP, "message": "MFA enabled successfully."}

    # ------------------------------------------------------------------
    # SMS OTP setup & send
    # ------------------------------------------------------------------

    def setup_sms(self, user_id: str, phone: str) -> Dict[str, Any]:
        """
        Configure SMS-based MFA for a user.

        Args:
            user_id: User identifier
            phone:   E.164 phone number e.g. +260971234567

        Returns:
            Dict confirming setup and indicating an OTP was sent
        """
        plain_codes, hashed_codes = self._generate_backup_codes()
        cfg = MFAConfig(
            user_id      = user_id,
            mfa_type     = MFAType.SMS,
            enabled      = True,
            verified     = True,
            phone        = phone,
            backup_codes = hashed_codes,
        )
        self._save_config(cfg)
        self.send_sms_otp(user_id)
        logger.info(f"SMS MFA configured for user {user_id}")
        return {
            "mfa_type":     MFAType.SMS,
            "phone":        self._mask_phone(phone),
            "backup_codes": plain_codes,
            "message":      "SMS OTP sent. Verify with verify().",
        }

    def send_sms_otp(self, user_id: str) -> None:
        """
        Generate and send a fresh SMS OTP.

        Args:
            user_id: User identifier

        Raises:
            MFANotSetupError: SMS MFA not configured
        """
        cfg = self._load_config(user_id)
        if not cfg or cfg.mfa_type != MFAType.SMS:
            raise MFANotSetupError("SMS MFA not configured for this user.")

        code = self._generate_otp()
        self._store_otp(user_id, code)

        if self.sms_provider == "twilio":
            self._send_twilio(cfg.phone, f"Your AgriSecure code: {code}. Valid for 5 minutes.")
        elif self.sms_provider == "africastalking":
            self._send_africastalking(cfg.phone, f"Your AgriSecure code: {code}. Valid for 5 minutes.")
        else:
            # Log for development; replace with real provider in production
            logger.info(f"[DEV] SMS OTP for {user_id}: {code}")

    # ------------------------------------------------------------------
    # Email OTP setup & send
    # ------------------------------------------------------------------

    def setup_email(self, user_id: str, email: str) -> Dict[str, Any]:
        """
        Configure email-based MFA for a user.

        Args:
            user_id: User identifier
            email:   Email address

        Returns:
            Dict confirming setup
        """
        plain_codes, hashed_codes = self._generate_backup_codes()
        cfg = MFAConfig(
            user_id      = user_id,
            mfa_type     = MFAType.EMAIL,
            enabled      = True,
            verified     = True,
            email        = email,
            backup_codes = hashed_codes,
        )
        self._save_config(cfg)
        self.send_email_otp(user_id)
        logger.info(f"Email MFA configured for user {user_id}")
        return {
            "mfa_type":     MFAType.EMAIL,
            "email":        self._mask_email(email),
            "backup_codes": plain_codes,
            "message":      "Email OTP sent. Verify with verify().",
        }

    def send_email_otp(self, user_id: str) -> None:
        """
        Generate and send a fresh email OTP.

        Args:
            user_id: User identifier

        Raises:
            MFANotSetupError: Email MFA not configured
        """
        cfg = self._load_config(user_id)
        if not cfg or cfg.mfa_type != MFAType.EMAIL:
            raise MFANotSetupError("Email MFA not configured for this user.")

        code = self._generate_otp()
        self._store_otp(user_id, code)

        subject = "Your AgriSecure verification code"
        body    = (
            f"Your one-time verification code is: {code}\n\n"
            f"This code expires in 5 minutes.\n"
            f"If you did not request this, please contact support immediately."
        )

        if self.email_provider == "sendgrid":
            self._send_sendgrid(cfg.email, subject, body)
        elif self.email_provider == "smtp":
            self._send_smtp(cfg.email, subject, body)
        else:
            logger.info(f"[DEV] Email OTP for {user_id} → {cfg.email}: {code}")

    # ------------------------------------------------------------------
    # Core verify (all types)
    # ------------------------------------------------------------------

    def verify(self, user_id: str, code: str) -> Dict[str, Any]:
        """
        Verify an MFA code for any configured MFA type.

        Handles TOTP, SMS, Email, and backup codes transparently.

        Args:
            user_id: User identifier
            code:    Code submitted by the user

        Returns:
            Dict with verified=True and mfa_type

        Raises:
            MFANotSetupError:    MFA not configured
            MFARateLimitError:   Too many failed attempts
            MFAInvalidCodeError: Wrong code
            MFAExpiredError:     SMS/Email OTP expired
        """
        cfg = self._load_config(user_id)
        if not cfg or not cfg.enabled:
            raise MFANotSetupError("MFA not configured or not enabled for this user.")

        # Rate limit check
        self._check_rate_limit(cfg)

        # Try backup code first (works for all MFA types)
        if self._verify_backup_code(cfg, code):
            cfg.last_used  = datetime.utcnow().isoformat()
            cfg.attempt_count = 0
            self._save_config(cfg)
            logger.info(f"MFA verified via backup code for user {user_id}")
            return {"verified": True, "mfa_type": "backup", "user_id": user_id}

        # Type-specific verification
        verified = False
        if cfg.mfa_type == MFAType.TOTP:
            verified = self._verify_totp(cfg, code)
        elif cfg.mfa_type in (MFAType.SMS, MFAType.EMAIL):
            verified = self._verify_otp(user_id, code)

        if not verified:
            cfg.attempt_count += 1
            if cfg.attempt_count >= self.MAX_ATTEMPTS:
                cfg.locked_until = time.time() + self.LOCKOUT_SECS
                logger.warning(f"MFA locked for user {user_id} after {self.MAX_ATTEMPTS} failures")
            self._save_config(cfg)
            raise MFAInvalidCodeError(
                f"Invalid MFA code. "
                f"{max(0, self.MAX_ATTEMPTS - cfg.attempt_count)} attempts remaining."
            )

        cfg.attempt_count = 0
        cfg.locked_until  = None
        cfg.last_used     = datetime.utcnow().isoformat()
        self._save_config(cfg)

        logger.info(f"MFA verified ({cfg.mfa_type}) for user {user_id}")
        return {"verified": True, "mfa_type": cfg.mfa_type, "user_id": user_id}

    # ------------------------------------------------------------------
    # Backup codes
    # ------------------------------------------------------------------

    def regenerate_backup_codes(self, user_id: str) -> List[str]:
        """
        Regenerate all backup codes for a user (invalidates old ones).

        Args:
            user_id: User identifier

        Returns:
            List of 10 new plain-text backup codes (show once)
        """
        cfg = self._load_config(user_id)
        if not cfg:
            raise MFANotSetupError("MFA not configured for this user.")

        plain_codes, hashed_codes = self._generate_backup_codes()
        cfg.backup_codes = hashed_codes
        cfg.updated_at   = datetime.utcnow().isoformat()
        self._save_config(cfg)

        logger.info(f"Backup codes regenerated for user {user_id}")
        return plain_codes

    # ------------------------------------------------------------------
    # MFA management
    # ------------------------------------------------------------------

    def disable_mfa(self, user_id: str, admin: bool = False) -> None:
        """
        Disable MFA for a user (admin action or user self-service).

        Args:
            user_id: User identifier
            admin:   If True, skip additional checks
        """
        cfg = self._load_config(user_id)
        if cfg:
            cfg.enabled    = False
            cfg.updated_at = datetime.utcnow().isoformat()
            self._save_config(cfg)
        logger.warning(f"MFA disabled for user {user_id} (admin={admin})")

    def get_status(self, user_id: str) -> Dict[str, Any]:
        """
        Return the MFA status for a user.

        Args:
            user_id: User identifier

        Returns:
            Dict with enabled, mfa_type, verified, last_used, backup_codes_remaining
        """
        cfg = self._load_config(user_id)
        if not cfg:
            return {"enabled": False, "mfa_type": None, "verified": False}

        locked = bool(cfg.locked_until and cfg.locked_until > time.time())
        return {
            "enabled":                cfg.enabled,
            "mfa_type":               cfg.mfa_type,
            "verified":               cfg.verified,
            "last_used":              cfg.last_used,
            "backup_codes_remaining": len(cfg.backup_codes),
            "locked":                 locked,
            "locked_until":           datetime.utcfromtimestamp(cfg.locked_until).isoformat()
                                      if locked else None,
        }

    # ------------------------------------------------------------------
    # WebAuthn stub
    # ------------------------------------------------------------------

    def setup_webauthn(self, user_id: str, username: str) -> Dict[str, Any]:
        """
        WebAuthn/FIDO2 setup stub.

        Returns the registration challenge that should be passed to the
        browser's navigator.credentials.create() call.  Full implementation
        requires the `py_webauthn` library and a relying-party server.

        Args:
            user_id:  User identifier
            username: Display name

        Returns:
            Dict with challenge and rp info
        """
        challenge = base64.urlsafe_b64encode(os.urandom(32)).decode().rstrip("=")
        logger.info(f"WebAuthn setup challenge generated for user {user_id}")
        return {
            "mfa_type":  MFAType.WEBAUTHN,
            "challenge": challenge,
            "rp":        {"name": self.app_name, "id": self.issuer},
            "user":      {"id": user_id, "name": username},
            "message":   "Pass challenge to navigator.credentials.create(). "
                         "Install py_webauthn for full server-side verification.",
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _verify_totp(self, cfg: MFAConfig, code: str) -> bool:
        if not cfg.totp_secret:
            return False
        totp = pyotp.TOTP(cfg.totp_secret)
        return totp.verify(code.strip(), valid_window=self.TOTP_WINDOW)

    def _verify_otp(self, user_id: str, code: str) -> bool:
        """Verify a time-limited SMS/Email OTP."""
        record = self._load_otp(user_id)
        if not record:
            raise MFAExpiredError("OTP has expired or was never sent. Request a new code.")
        if time.time() > record["expires_at"]:
            self._delete_otp(user_id)
            raise MFAExpiredError("OTP has expired. Request a new code.")
        # Constant-time comparison
        if hmac.compare_digest(record["code"], code.strip()):
            self._delete_otp(user_id)
            return True
        return False

    def _verify_backup_code(self, cfg: MFAConfig, code: str) -> bool:
        """Check code against stored bcrypt-hashed backup codes."""
        code_bytes = code.strip().encode()
        for i, hashed in enumerate(cfg.backup_codes):
            try:
                if bcrypt.checkpw(code_bytes, hashed.encode()):
                    cfg.backup_codes.pop(i)   # single-use
                    return True
            except Exception:
                continue
        return False

    def _check_rate_limit(self, cfg: MFAConfig) -> None:
        if cfg.locked_until and cfg.locked_until > time.time():
            remaining = int(cfg.locked_until - time.time())
            raise MFARateLimitError(
                f"Too many failed attempts. Try again in {remaining} seconds."
            )

    @staticmethod
    def _generate_otp(length: int = 6) -> str:
        """Generate a cryptographically secure numeric OTP."""
        return "".join([str(secrets.randbelow(10)) for _ in range(length)])

    @staticmethod
    def _generate_backup_codes(count: int = 10) -> Tuple[List[str], List[str]]:
        """
        Generate backup codes.

        Returns:
            Tuple of (plain_codes, bcrypt_hashed_codes)
        """
        plain, hashed = [], []
        for _ in range(count):
            code = secrets.token_hex(4).upper()   # e.g. "A3F2-9C1B"
            formatted = f"{code[:4]}-{code[4:]}"
            plain.append(formatted)
            hashed.append(
                bcrypt.hashpw(formatted.encode(), bcrypt.gensalt(rounds=10)).decode()
            )
        return plain, hashed

    # ------------------------------------------------------------------
    # OTP storage
    # ------------------------------------------------------------------

    def _store_otp(self, user_id: str, code: str) -> None:
        record = {"code": code, "expires_at": time.time() + self.OTP_TTL}
        if self._redis:
            self._redis.setex(f"mfa_otp:{user_id}", self.OTP_TTL, json.dumps(record))
        else:
            self._otp_store[user_id] = record

    def _load_otp(self, user_id: str) -> Optional[Dict]:
        if self._redis:
            raw = self._redis.get(f"mfa_otp:{user_id}")
            return json.loads(raw) if raw else None
        return self._otp_store.get(user_id)

    def _delete_otp(self, user_id: str) -> None:
        if self._redis:
            self._redis.delete(f"mfa_otp:{user_id}")
        else:
            self._otp_store.pop(user_id, None)

    # ------------------------------------------------------------------
    # Config storage
    # ------------------------------------------------------------------

    def _save_config(self, cfg: MFAConfig) -> None:
        data = {
            "user_id":      cfg.user_id,
            "mfa_type":     cfg.mfa_type,
            "enabled":      cfg.enabled,
            "verified":     cfg.verified,
            "totp_secret":  cfg.totp_secret,
            "backup_codes": cfg.backup_codes,
            "phone":        cfg.phone,
            "email":        cfg.email,
            "created_at":   cfg.created_at,
            "updated_at":   cfg.updated_at,
            "last_used":    cfg.last_used,
            "attempt_count": cfg.attempt_count,
            "locked_until": cfg.locked_until,
        }
        if self._redis:
            self._redis.set(f"mfa_cfg:{cfg.user_id}", json.dumps(data))
        else:
            self._store[cfg.user_id] = cfg

    def _load_config(self, user_id: str) -> Optional[MFAConfig]:
        if self._redis:
            raw = self._redis.get(f"mfa_cfg:{user_id}")
            if not raw:
                return None
            d = json.loads(raw)
            return MFAConfig(**d)
        return self._store.get(user_id)

    # ------------------------------------------------------------------
    # SMS providers
    # ------------------------------------------------------------------

    def _send_twilio(self, phone: str, message: str) -> None:
        try:
            from twilio.rest import Client
            client = Client(
                self.sms_config["account_sid"],
                self.sms_config["auth_token"],
            )
            client.messages.create(
                body=message,
                from_=self.sms_config["from_number"],
                to=phone,
            )
            logger.info(f"SMS sent via Twilio to {self._mask_phone(phone)}")
        except ImportError:
            logger.error("twilio package not installed. Run: pip install twilio")
        except Exception as exc:
            logger.error(f"Twilio SMS failed: {exc}")

    def _send_africastalking(self, phone: str, message: str) -> None:
        try:
            import africastalking
            africastalking.initialize(
                self.sms_config["username"],
                self.sms_config["api_key"],
            )
            sms = africastalking.SMS
            sms.send(message, [phone], sender_id=self.sms_config.get("sender_id"))
            logger.info(f"SMS sent via Africa's Talking to {self._mask_phone(phone)}")
        except ImportError:
            logger.error("africastalking package not installed. Run: pip install africastalking")
        except Exception as exc:
            logger.error(f"Africa's Talking SMS failed: {exc}")

    # ------------------------------------------------------------------
    # Email providers
    # ------------------------------------------------------------------

    def _send_smtp(self, to_email: str, subject: str, body: str) -> None:
        try:
            import smtplib
            from email.mime.text import MIMEText
            msg = MIMEText(body)
            msg["Subject"] = subject
            msg["From"]    = self.email_config.get("from_email", "noreply@agrisecure.com")
            msg["To"]      = to_email
            with smtplib.SMTP(
                self.email_config.get("host", "localhost"),
                int(self.email_config.get("port", 587)),
            ) as server:
                if self.email_config.get("use_tls", True):
                    server.starttls()
                if self.email_config.get("username"):
                    server.login(
                        self.email_config["username"],
                        self.email_config["password"],
                    )
                server.send_message(msg)
            logger.info(f"Email OTP sent via SMTP to {self._mask_email(to_email)}")
        except Exception as exc:
            logger.error(f"SMTP email failed: {exc}")

    def _send_sendgrid(self, to_email: str, subject: str, body: str) -> None:
        try:
            import sendgrid
            from sendgrid.helpers.mail import Mail
            sg  = sendgrid.SendGridAPIClient(api_key=self.email_config["api_key"])
            msg = Mail(
                from_email=self.email_config.get("from_email", "noreply@agrisecure.com"),
                to_emails=to_email,
                subject=subject,
                plain_text_content=body,
            )
            sg.send(msg)
            logger.info(f"Email OTP sent via SendGrid to {self._mask_email(to_email)}")
        except ImportError:
            logger.error("sendgrid package not installed. Run: pip install sendgrid")
        except Exception as exc:
            logger.error(f"SendGrid email failed: {exc}")

    # ------------------------------------------------------------------
    # Masking helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _mask_phone(phone: str) -> str:
        if len(phone) < 6:
            return "***"
        return phone[:3] + "****" + phone[-3:]

    @staticmethod
    def _mask_email(email: str) -> str:
        parts = email.split("@")
        if len(parts) != 2:
            return "***"
        local = parts[0]
        masked_local = local[0] + "***" + local[-1] if len(local) > 2 else "***"
        return f"{masked_local}@{parts[1]}"

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict[str, Any]:
        """Return health status of the MFA module."""
        status: Dict[str, Any] = {
            "module":           "MFAManager",
            "storage":          "redis" if self._redis else "memory",
            "sms_provider":     self.sms_provider or "none",
            "email_provider":   self.email_provider or "none",
            "totp_supported":   True,
            "sms_supported":    self.sms_provider is not None,
            "email_supported":  self.email_provider is not None,
            "webauthn_stub":    True,
            "healthy":          True,
        }
        if self._redis:
            try:
                self._redis.ping()
            except Exception:
                status["healthy"] = False
                status["redis_error"] = "ping failed"
        return status
