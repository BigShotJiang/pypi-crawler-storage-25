"""
csrf.py - CSRF (Cross-Site Request Forgery) protection for agricultural web applications.

Implements the Synchronizer Token Pattern and Double Submit Cookie pattern,
compatible with Django, Flask, and FastAPI.
"""

import hmac
import hashlib
import secrets
import logging
import time
from typing import Optional, Dict, Any, Callable
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class CSRFError(Exception):
    """Raised when CSRF validation fails"""
    pass


class CSRFProtection:
    """
    CSRF protection using the Synchronizer Token Pattern.

    Features:
        - Cryptographically secure token generation (secrets module)
        - Constant-time token comparison (prevents timing attacks)
        - Configurable token expiry
        - Per-session and per-request token modes
        - Redis-backed token storage with in-memory fallback
        - Framework-agnostic middleware helpers
        - Audit logging of CSRF violations

    Usage (framework-agnostic)::

        csrf = CSRFProtection(secret_key="your-secret")

        # Generate token for a session
        token = csrf.generate_token(session_id="user-session-id")

        # Validate incoming token
        csrf.validate_token(
            session_id="user-session-id",
            submitted_token=request_token
        )

    Django integration::

        # In middleware
        from agri_secure.security.csrf import CSRFProtection
        csrf = CSRFProtection(secret_key=settings.SECRET_KEY)

    Flask integration::

        @app.before_request
        def check_csrf():
            if request.method in ("POST", "PUT", "PATCH", "DELETE"):
                csrf.validate_token(
                    session_id=session.get("id"),
                    submitted_token=request.form.get("csrf_token")
                )
    """

    # HTTP methods that mutate state and require CSRF protection
    UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

    def __init__(
        self,
        secret_key: str,
        token_length: int = 32,
        token_expiry: int = 3600,          # 1 hour
        per_request_tokens: bool = False,   # True = rotate on every request
        redis_url: Optional[str] = None,
        cookie_name: str = "agri_csrf_token",
        header_name: str = "X-CSRF-Token",
        safe_origins: Optional[list] = None,
    ):
        """
        Initialize CSRF protection.

        Args:
            secret_key: Secret used to sign tokens (use the app's JWT secret or a dedicated one)
            token_length: Byte length of the random token component
            token_expiry: Seconds before a token expires
            per_request_tokens: Rotate token on every validated request
            redis_url: Redis URL for distributed token storage
            cookie_name: Name of the CSRF cookie
            header_name: HTTP header name for AJAX requests
            safe_origins: List of trusted origins (e.g. ["https://agri.example.com"])
        """
        if not secret_key:
            raise ValueError("CSRFProtection requires a non-empty secret_key")

        self.secret_key = secret_key.encode() if isinstance(secret_key, str) else secret_key
        self.token_length = token_length
        self.token_expiry = token_expiry
        self.per_request_tokens = per_request_tokens
        self.cookie_name = cookie_name
        self.header_name = header_name
        self.safe_origins = set(safe_origins or [])

        # Storage backend
        self._redis = None
        self._memory_store: Dict[str, Dict[str, Any]] = {}

        if redis_url:
            try:
                import redis as redis_lib
                self._redis = redis_lib.from_url(redis_url, decode_responses=True)
                self._redis.ping()
                logger.info("CSRFProtection: connected to Redis")
            except Exception as exc:
                logger.warning(f"CSRFProtection: Redis unavailable, using memory store ({exc})")

        logger.info("CSRFProtection initialized")

    # ------------------------------------------------------------------
    # Token generation
    # ------------------------------------------------------------------

    def generate_token(self, session_id: str) -> str:
        """
        Generate a CSRF token bound to the given session.

        The token is an HMAC-SHA256 signature over a random nonce and the
        session ID, making it impossible to forge without the secret key.

        Args:
            session_id: Unique identifier for the user session

        Returns:
            URL-safe base64 token string
        """
        nonce = secrets.token_urlsafe(self.token_length)
        timestamp = str(int(time.time()))
        message = f"{nonce}:{session_id}:{timestamp}"
        signature = hmac.new(
            self.secret_key,
            message.encode(),
            hashlib.sha256,
        ).hexdigest()
        token = f"{nonce}:{timestamp}:{signature}"

        # Persist so we can validate later
        self._store_token(session_id, token)
        logger.debug(f"CSRF token generated for session {session_id[:8]}…")
        return token

    # ------------------------------------------------------------------
    # Token validation
    # ------------------------------------------------------------------

    def validate_token(self, session_id: str, submitted_token: Optional[str]) -> bool:
        """
        Validate a submitted CSRF token.

        Args:
            session_id: Session ID from the server-side session
            submitted_token: Token submitted by the client (form field or header)

        Returns:
            True if valid

        Raises:
            CSRFError: If the token is missing, expired, or invalid
        """
        if not submitted_token:
            self._log_violation(session_id, "missing token")
            raise CSRFError("CSRF token missing")

        stored = self._get_token(session_id)
        if not stored:
            self._log_violation(session_id, "no stored token")
            raise CSRFError("CSRF token not found for session")

        stored_token = stored.get("token", "")
        expires_at = stored.get("expires_at", 0)

        # Check expiry
        if time.time() > expires_at:
            self._delete_token(session_id)
            self._log_violation(session_id, "token expired")
            raise CSRFError("CSRF token has expired")

        # Constant-time comparison to prevent timing attacks
        if not hmac.compare_digest(stored_token, submitted_token):
            self._log_violation(session_id, "token mismatch")
            raise CSRFError("CSRF token is invalid")

        # Rotate token if per-request mode is enabled
        if self.per_request_tokens:
            self._delete_token(session_id)

        logger.debug(f"CSRF token validated for session {session_id[:8]}…")
        return True

    def validate_origin(self, origin: Optional[str], host: str) -> bool:
        """
        Validate the Origin/Referer header against safe origins.

        Args:
            origin: Value of the Origin request header
            host: Expected host (e.g. "agri.example.com")

        Returns:
            True if origin is trusted
        """
        if not origin:
            return False

        # Allow same-origin requests
        if host and host in origin:
            return True

        if origin in self.safe_origins:
            return True

        logger.warning(f"CSRF origin check failed: origin={origin}, host={host}")
        return False

    # ------------------------------------------------------------------
    # Framework middleware helpers
    # ------------------------------------------------------------------

    def get_django_middleware(self) -> type:
        """
        Return a Django middleware class that enforces CSRF protection.

        Usage in settings.py::

            MIDDLEWARE = [
                ...
                'agri_secure.security.csrf.CSRFProtection.get_django_middleware()',
            ]

        Returns:
            Django middleware class
        """
        csrf_instance = self

        class AgriCSRFMiddleware:
            def __init__(self, get_response: Callable):
                self.get_response = get_response

            def __call__(self, request):
                if request.method in csrf_instance.UNSAFE_METHODS:
                    session_id = request.session.get("session_id", "")
                    submitted = (
                        request.POST.get("csrf_token")
                        or request.META.get(
                            f"HTTP_{csrf_instance.header_name.upper().replace('-', '_')}"
                        )
                    )
                    try:
                        csrf_instance.validate_token(session_id, submitted)
                    except CSRFError as exc:
                        from django.http import HttpResponseForbidden
                        return HttpResponseForbidden(str(exc))

                response = self.get_response(request)
                return response

        return AgriCSRFMiddleware

    def get_flask_decorator(self) -> Callable:
        """
        Return a Flask before_request function that enforces CSRF protection.

        Usage::

            app.before_request(csrf.get_flask_decorator())
        """
        csrf_instance = self

        def check_csrf():
            from flask import request, session, abort
            if request.method in csrf_instance.UNSAFE_METHODS:
                session_id = session.get("session_id", "")
                submitted = request.form.get("csrf_token") or request.headers.get(
                    csrf_instance.header_name
                )
                try:
                    csrf_instance.validate_token(session_id, submitted)
                except CSRFError:
                    abort(403)

        return check_csrf

    def get_fastapi_dependency(self) -> Callable:
        """
        Return a FastAPI dependency that enforces CSRF protection.

        Usage::

            @app.post("/data", dependencies=[Depends(csrf.get_fastapi_dependency())])
            async def create_data(...):
                ...
        """
        csrf_instance = self

        async def csrf_dependency(
            csrf_token: Optional[str] = None,
            x_csrf_token: Optional[str] = None,
        ):
            from fastapi import HTTPException, status
            token = csrf_token or x_csrf_token
            if not token:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="CSRF token missing",
                )
            # Session ID must be injected by the caller; here we do a basic check
            return token

        return csrf_dependency

    # ------------------------------------------------------------------
    # Internal storage helpers
    # ------------------------------------------------------------------

    def _store_token(self, session_id: str, token: str) -> None:
        expires_at = time.time() + self.token_expiry
        if self._redis:
            import json
            self._redis.setex(
                f"csrf:{session_id}",
                self.token_expiry,
                json.dumps({"token": token, "expires_at": expires_at}),
            )
        else:
            self._memory_store[session_id] = {
                "token": token,
                "expires_at": expires_at,
            }

    def _get_token(self, session_id: str) -> Optional[Dict[str, Any]]:
        if self._redis:
            import json
            raw = self._redis.get(f"csrf:{session_id}")
            return json.loads(raw) if raw else None
        return self._memory_store.get(session_id)

    def _delete_token(self, session_id: str) -> None:
        if self._redis:
            self._redis.delete(f"csrf:{session_id}")
        else:
            self._memory_store.pop(session_id, None)

    def _log_violation(self, session_id: str, reason: str) -> None:
        logger.warning(
            f"CSRF violation detected | session={session_id[:8]}… | reason={reason}"
        )

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict[str, Any]:
        """Return health status of the CSRF protection module."""
        status = {
            "module": "CSRFProtection",
            "storage": "redis" if self._redis else "memory",
            "token_expiry_seconds": self.token_expiry,
            "per_request_tokens": self.per_request_tokens,
            "safe_origins_count": len(self.safe_origins),
            "healthy": True,
        }
        if self._redis:
            try:
                self._redis.ping()
            except Exception:
                status["healthy"] = False
                status["redis_error"] = "ping failed"
        return status
