"""
brute_force.py - Brute-force and credential-stuffing protection.

Implements progressive lockout with exponential back-off, IP-level throttling,
and optional CAPTCHA challenge integration.  Backed by Redis with an in-memory
fallback so the module works in development without a cache server.
"""

import logging
import time
import hashlib
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


class BruteForceError(Exception):
    """Raised when a brute-force threshold is exceeded"""
    pass


class AccountLockedError(BruteForceError):
    """Account is temporarily locked"""
    pass


class IPBlockedError(BruteForceError):
    """IP address is temporarily blocked"""
    pass


@dataclass
class AttemptRecord:
    """In-memory record of failed attempts (used when Redis is unavailable)"""
    count: int = 0
    first_attempt: float = field(default_factory=time.time)
    last_attempt: float = field(default_factory=time.time)
    locked_until: Optional[float] = None
    ip_addresses: List[str] = field(default_factory=list)


class BruteForceProtection:
    """
    Progressive brute-force protection for login endpoints and sensitive actions.

    Features:
        - Per-account failed-attempt tracking
        - Per-IP failed-attempt tracking
        - Exponential back-off lockout (30 s → 5 min → 30 min → 24 h)
        - Permanent lock after configurable threshold (requires admin unlock)
        - Suspicious IP detection (too many accounts targeted from one IP)
        - Redis-backed with in-memory fallback
        - Audit logging of all lockout events
        - CAPTCHA challenge flag after soft threshold

    Usage::

        protection = BruteForceProtection(redis_url="redis://localhost:6379/0")

        # Call on every failed login
        protection.record_failure(identifier="john.farmer", ip_address="1.2.3.4")

        # Call before allowing a login attempt
        protection.check_allowed(identifier="john.farmer", ip_address="1.2.3.4")

        # Call on successful login to reset counters
        protection.record_success(identifier="john.farmer", ip_address="1.2.3.4")
    """

    # Lockout durations in seconds for each tier
    LOCKOUT_TIERS: List[int] = [30, 300, 1800, 86400]  # 30s, 5m, 30m, 24h

    def __init__(
        self,
        max_attempts: int = 5,
        ip_max_attempts: int = 20,
        ip_window_seconds: int = 600,       # 10-minute sliding window for IP
        captcha_threshold: int = 3,          # Show CAPTCHA after this many failures
        permanent_lock_threshold: int = 20,  # Lock permanently after this many total failures
        redis_url: Optional[str] = None,
        namespace: str = "agri_bf",
    ):
        """
        Args:
            max_attempts: Failed attempts before account lockout begins
            ip_max_attempts: Failed attempts from one IP before IP block
            ip_window_seconds: Sliding window for IP attempt counting
            captcha_threshold: Failures before CAPTCHA is required
            permanent_lock_threshold: Total failures before permanent lock
            redis_url: Redis connection URL
            namespace: Redis key namespace
        """
        self.max_attempts = max_attempts
        self.ip_max_attempts = ip_max_attempts
        self.ip_window_seconds = ip_window_seconds
        self.captcha_threshold = captcha_threshold
        self.permanent_lock_threshold = permanent_lock_threshold
        self.namespace = namespace

        self._redis = None
        self._memory: Dict[str, AttemptRecord] = {}

        if redis_url:
            try:
                import redis as redis_lib
                self._redis = redis_lib.from_url(redis_url, decode_responses=True)
                self._redis.ping()
                logger.info("BruteForceProtection: connected to Redis")
            except Exception as exc:
                logger.warning(
                    f"BruteForceProtection: Redis unavailable, using memory ({exc})"
                )

        logger.info(
            f"BruteForceProtection initialized | max_attempts={max_attempts} "
            f"ip_max={ip_max_attempts}"
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check_allowed(self, identifier: str, ip_address: Optional[str] = None) -> Dict[str, Any]:
        """
        Check whether a login attempt is allowed.

        Args:
            identifier: Username, email, or user ID
            ip_address: Client IP address

        Returns:
            Dict with keys: allowed (bool), requires_captcha (bool),
            lockout_remaining (int seconds), reason (str)

        Raises:
            AccountLockedError: If the account is locked
            IPBlockedError: If the IP is blocked
        """
        now = time.time()

        # --- IP-level check ---
        if ip_address:
            ip_record = self._get_record(self._ip_key(ip_address))
            if ip_record and ip_record.get("locked_until", 0) > now:
                remaining = int(ip_record["locked_until"] - now)
                logger.warning(f"IP blocked: {ip_address} | remaining={remaining}s")
                raise IPBlockedError(
                    f"IP address blocked for {remaining} seconds due to excessive attempts"
                )

        # --- Account-level check ---
        record = self._get_record(self._account_key(identifier))
        if not record:
            return {"allowed": True, "requires_captcha": False, "lockout_remaining": 0, "reason": ""}

        count = record.get("count", 0)
        locked_until = record.get("locked_until", 0)

        if locked_until and locked_until > now:
            remaining = int(locked_until - now)
            logger.warning(f"Account locked: {identifier} | remaining={remaining}s")
            raise AccountLockedError(
                f"Account locked for {remaining} seconds. "
                "Contact support if you believe this is an error."
            )

        requires_captcha = count >= self.captcha_threshold
        return {
            "allowed": True,
            "requires_captcha": requires_captcha,
            "lockout_remaining": 0,
            "reason": "",
            "failed_attempts": count,
        }

    def record_failure(
        self,
        identifier: str,
        ip_address: Optional[str] = None,
        reason: str = "invalid_credentials",
    ) -> Dict[str, Any]:
        """
        Record a failed authentication attempt.

        Args:
            identifier: Username, email, or user ID
            ip_address: Client IP address
            reason: Failure reason for audit log

        Returns:
            Dict with lockout info and whether CAPTCHA is now required
        """
        now = time.time()
        account_key = self._account_key(identifier)
        record = self._get_record(account_key) or {
            "count": 0,
            "first_attempt": now,
            "last_attempt": now,
            "locked_until": None,
            "tier": 0,
        }

        record["count"] = record.get("count", 0) + 1
        record["last_attempt"] = now

        count = record["count"]
        result: Dict[str, Any] = {
            "identifier": identifier,
            "failed_attempts": count,
            "requires_captcha": count >= self.captcha_threshold,
            "locked": False,
            "lockout_duration": 0,
        }

        # Determine lockout
        if count >= self.max_attempts:
            tier = min(record.get("tier", 0), len(self.LOCKOUT_TIERS) - 1)
            duration = self.LOCKOUT_TIERS[tier]
            record["locked_until"] = now + duration
            record["tier"] = tier + 1
            result["locked"] = True
            result["lockout_duration"] = duration

            logger.warning(
                f"Account locked: identifier={identifier} | "
                f"attempts={count} | duration={duration}s | reason={reason}"
            )

        # Permanent lock
        if count >= self.permanent_lock_threshold:
            record["locked_until"] = now + 86400 * 365  # 1 year ≈ permanent
            result["permanent_lock"] = True
            logger.error(
                f"PERMANENT LOCK applied: identifier={identifier} | "
                f"total_attempts={count}"
            )

        self._set_record(account_key, record, ttl=86400 * 2)

        # --- IP-level tracking ---
        if ip_address:
            self._record_ip_failure(ip_address, now)

        return result

    def record_success(self, identifier: str, ip_address: Optional[str] = None) -> None:
        """
        Reset failure counters after a successful authentication.

        Args:
            identifier: Username, email, or user ID
            ip_address: Client IP address
        """
        self._delete_record(self._account_key(identifier))
        if ip_address:
            self._delete_record(self._ip_key(ip_address))
        logger.debug(f"Brute-force counters reset for: {identifier}")

    def unlock_account(self, identifier: str, admin_id: str) -> None:
        """
        Manually unlock an account (admin action).

        Args:
            identifier: Username or user ID to unlock
            admin_id: ID of the admin performing the unlock
        """
        self._delete_record(self._account_key(identifier))
        logger.info(f"Account manually unlocked: {identifier} by admin={admin_id}")

    def get_status(self, identifier: str) -> Dict[str, Any]:
        """
        Return the current brute-force status for an account.

        Args:
            identifier: Username or user ID

        Returns:
            Dict with count, locked, lockout_remaining, tier
        """
        now = time.time()
        record = self._get_record(self._account_key(identifier))
        if not record:
            return {"count": 0, "locked": False, "lockout_remaining": 0, "tier": 0}

        locked_until = record.get("locked_until") or 0
        locked = locked_until > now
        return {
            "count": record.get("count", 0),
            "locked": locked,
            "lockout_remaining": max(0, int(locked_until - now)) if locked else 0,
            "tier": record.get("tier", 0),
            "last_attempt": record.get("last_attempt"),
        }

    # ------------------------------------------------------------------
    # IP-level helpers
    # ------------------------------------------------------------------

    def _record_ip_failure(self, ip_address: str, now: float) -> None:
        ip_key = self._ip_key(ip_address)
        record = self._get_record(ip_key) or {
            "count": 0,
            "first_attempt": now,
            "locked_until": None,
        }
        record["count"] = record.get("count", 0) + 1
        record["last_attempt"] = now

        if record["count"] >= self.ip_max_attempts:
            record["locked_until"] = now + self.ip_window_seconds
            logger.warning(
                f"IP blocked: {ip_address} | attempts={record['count']} | "
                f"duration={self.ip_window_seconds}s"
            )

        self._set_record(ip_key, record, ttl=self.ip_window_seconds * 2)

    # ------------------------------------------------------------------
    # Storage helpers
    # ------------------------------------------------------------------

    def _account_key(self, identifier: str) -> str:
        hashed = hashlib.sha256(identifier.encode()).hexdigest()[:16]
        return f"{self.namespace}:acct:{hashed}"

    def _ip_key(self, ip_address: str) -> str:
        hashed = hashlib.sha256(ip_address.encode()).hexdigest()[:16]
        return f"{self.namespace}:ip:{hashed}"

    def _get_record(self, key: str) -> Optional[Dict[str, Any]]:
        if self._redis:
            import json
            raw = self._redis.get(key)
            return json.loads(raw) if raw else None
        return {**vars(self._memory[key])} if key in self._memory else None

    def _set_record(self, key: str, record: Dict[str, Any], ttl: int = 86400) -> None:
        if self._redis:
            import json
            self._redis.setex(key, ttl, json.dumps(record))
        else:
            obj = AttemptRecord()
            obj.__dict__.update(record)
            self._memory[key] = obj

    def _delete_record(self, key: str) -> None:
        if self._redis:
            self._redis.delete(key)
        else:
            self._memory.pop(key, None)

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict[str, Any]:
        """Return health status of the brute-force protection module."""
        status = {
            "module": "BruteForceProtection",
            "storage": "redis" if self._redis else "memory",
            "max_attempts": self.max_attempts,
            "ip_max_attempts": self.ip_max_attempts,
            "captcha_threshold": self.captcha_threshold,
            "healthy": True,
        }
        if self._redis:
            try:
                self._redis.ping()
            except Exception:
                status["healthy"] = False
                status["redis_error"] = "ping failed"
        return status
