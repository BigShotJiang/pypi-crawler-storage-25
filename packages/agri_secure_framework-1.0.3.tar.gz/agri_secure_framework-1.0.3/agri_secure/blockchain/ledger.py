"""
ledger.py - Production blockchain-inspired immutable audit trail
Implements tamper-evident logging with cryptographic verification
"""

import hashlib
import json
import logging
import datetime
from typing import Dict, Any, Optional, List, Tuple, Union
from dataclasses import dataclass, field
from enum import Enum
import hmac
import time
import zlib
import base64
import threading
from queue import Queue
import os

logger = logging.getLogger(__name__)

class BlockchainError(Exception):
    """Base exception for blockchain operations"""
    pass

class TransactionType(Enum):
    """Types of transactions that can be recorded"""
    DATA_CREATE = "data_create"
    DATA_UPDATE = "data_update"
    DATA_DELETE = "data_delete"
    DATA_SHARE = "data_share"
    DATA_ACCESS = "data_access"
    USER_CREATE = "user_create"
    USER_UPDATE = "user_update"
    USER_DELETE = "user_delete"
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    PERMISSION_GRANT = "permission_grant"
    PERMISSION_REVOKE = "permission_revoke"
    KEY_ROTATION = "key_rotation"
    SYSTEM_EVENT = "system_event"
    AUDIT_EVENT = "audit_event"

@dataclass
class Block:
    """Single block in the blockchain"""
    index: int
    timestamp: str
    transactions: List[Dict]
    previous_hash: str
    hash: str = ""
    nonce: int = 0
    merkle_root: str = ""
    version: str = "2.0"
    created_by: Optional[str] = None
    
    def __post_init__(self):
        if not self.hash:
            self.hash = self.calculate_hash()
        if not self.merkle_root:
            self.merkle_root = self.calculate_merkle_root()
    
    def calculate_hash(self) -> str:
        """Calculate SHA-512 hash of block contents"""
        block_string = json.dumps({
            "index": self.index,
            "timestamp": self.timestamp,
            "merkle_root": self.merkle_root,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce,
            "version": self.version
        }, sort_keys=True).encode('utf-8')
        
        return hashlib.sha512(block_string).hexdigest()
    
    def calculate_merkle_root(self) -> str:
        """Calculate Merkle root of all transactions"""
        if not self.transactions:
            return hashlib.sha256(b"empty").hexdigest()
        
        # Hash all transactions
        tx_hashes = []
        for tx in self.transactions:
            tx_string = json.dumps(tx, sort_keys=True).encode('utf-8')
            tx_hashes.append(hashlib.sha256(tx_string).hexdigest())
        
        # Build Merkle tree
        while len(tx_hashes) > 1:
            if len(tx_hashes) % 2 != 0:
                tx_hashes.append(tx_hashes[-1])
            
            new_hashes = []
            for i in range(0, len(tx_hashes), 2):
                combined = tx_hashes[i] + tx_hashes[i+1]
                new_hashes.append(hashlib.sha256(combined.encode()).hexdigest())
            
            tx_hashes = new_hashes
        
        return tx_hashes[0]
    
    def mine_block(self, difficulty: int = 4) -> int:
        """
        Proof of work mining.
        
        Args:
            difficulty: Number of leading zeros required
        
        Returns:
            Nonce that satisfies difficulty
        """
        target = "0" * difficulty
        start_time = time.time()
        
        while self.hash[:difficulty] != target:
            self.nonce += 1
            self.hash = self.calculate_hash()
        
        mining_time = time.time() - start_time
        logger.debug(f"Block {self.index} mined in {mining_time:.2f}s (nonce: {self.nonce})")
        
        return self.nonce

class AgriculturalLedger:
    """
    Production blockchain-inspired immutable ledger.
    
    Features:
        - Tamper-evident logging
        - Cryptographic verification
        - Merkle tree for efficient verification
        - Proof of work (configurable)
        - Asynchronous writing
        - Backup and recovery
        - Query interface
    """
    
    def __init__(
        self,
        database_url: Optional[str] = None,
        consensus: str = "raft",
        backup_enabled: bool = True,
        mining_difficulty: int = 2,
        async_writes: bool = True,
        batch_size: int = 100,
        sync_interval: int = 60
    ):
        """
        Initialize blockchain ledger.
        
        Args:
            database_url: Database URL for persistent storage
            consensus: Consensus mechanism (raft, pbft, pow)
            backup_enabled: Enable automatic backups
            mining_difficulty: Proof of work difficulty
            async_writes: Enable asynchronous writes
            batch_size: Batch size for async writes
            sync_interval: Sync interval in seconds
        """
        self.consensus = consensus
        self.backup_enabled = backup_enabled
        self.mining_difficulty = mining_difficulty
        self.async_writes = async_writes
        self.batch_size = batch_size
        self.sync_interval = sync_interval
        
        # Blockchain state
        self.chain: List[Block] = []
        self.pending_transactions: List[Dict] = []
        self.nodes = set()
        self.transaction_index = {}  # tx_id -> (block_index, tx_index)
        
        # Async write queue
        self.write_queue = Queue()
        self.stop_async = False
        self.async_thread = None
        
        if async_writes:
            self._start_async_worker()
        
        # Create genesis block
        self._create_genesis_block()
        
        # Load from database if available
        if database_url:
            self._load_from_database(database_url)
        
        logger.info(f"Ledger initialized with {len(self.chain)} blocks")
    
    def _create_genesis_block(self):
        """Create the genesis block"""
        genesis_transactions = [{
            "transaction_id": "genesis",
            "type": TransactionType.SYSTEM_EVENT.value,
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "data": {
                "message": "Agricultural Security Framework Genesis Block",
                "version": "2.0",
                "created": datetime.datetime.utcnow().isoformat()
            },
            "initiator": "system"
        }]
        
        genesis_block = Block(
            index=0,
            timestamp=datetime.datetime.utcnow().isoformat(),
            transactions=genesis_transactions,
            previous_hash="0" * 128
        )
        
        self.chain.append(genesis_block)
        logger.info("Genesis block created")
    
    def add_transaction(
        self,
        transaction_type: Union[str, TransactionType],
        data: Dict[str, Any],
        initiator: str,
        signature: Optional[str] = None
    ) -> str:
        """
        Add a transaction to the pending pool.
        
        Args:
            transaction_type: Type of transaction
            data: Transaction data
            initiator: User/system that initiated transaction
            signature: Digital signature for verification
        
        Returns:
            Transaction ID
        """
        if isinstance(transaction_type, TransactionType):
            transaction_type = transaction_type.value
        
        # Generate transaction ID
        tx_id = hashlib.sha256(
            f"{transaction_type}{json.dumps(data)}{initiator}{time.time()}".encode()
        ).hexdigest()[:16]
        
        transaction = {
            "transaction_id": tx_id,
            "type": transaction_type,
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "data": data,
            "initiator": initiator,
            "signature": signature
        }
        
        # Add to pending pool
        self.pending_transactions.append(transaction)
        
        # Auto-mine if batch size reached
        if len(self.pending_transactions) >= self.batch_size:
            if self.async_writes:
                self.write_queue.put("mine")
            else:
                self.mine_block()
        
        logger.debug(f"Transaction added: {tx_id} ({transaction_type})")
        
        return tx_id
    
    def mine_block(self) -> Optional[Block]:
        """
        Mine a new block with pending transactions.
        
        Returns:
            New block or None if no transactions
        """
        if not self.pending_transactions:
            return None
        
        # Create new block
        block = Block(
            index=len(self.chain),
            timestamp=datetime.datetime.utcnow().isoformat(),
            transactions=self.pending_transactions.copy(),
            previous_hash=self.chain[-1].hash
        )
        
        # Mine block (proof of work)
        block.mine_block(self.mining_difficulty)
        
        # Add to chain
        self.chain.append(block)
        
        # Update transaction index
        for i, tx in enumerate(block.transactions):
            self.transaction_index[tx["transaction_id"]] = (block.index, i)
        
        # Clear pending transactions
        self.pending_transactions.clear()
        
        logger.info(f"Block {block.index} mined with {len(block.transactions)} transactions")
        
        # Backup if enabled
        if self.backup_enabled:
            self._backup_block(block)
        
        return block
    
    def verify_transaction(
        self,
        transaction_id: str,
        include_proof: bool = False
    ) -> Dict[str, Any]:
        """
        Verify a transaction's integrity.
        
        Args:
            transaction_id: Transaction ID to verify
            include_proof: Include Merkle proof
        
        Returns:
            Verification result with proof if requested
        """
        # Find transaction
        if transaction_id not in self.transaction_index:
            raise BlockchainError(f"Transaction {transaction_id} not found")
        
        block_index, tx_index = self.transaction_index[transaction_id]
        block = self.chain[block_index]
        transaction = block.transactions[tx_index]
        
        # Verify block hash
        block_hash_valid = block.hash == block.calculate_hash()
        
        # Verify Merkle proof
        merkle_valid = self._verify_merkle_proof(block, tx_index)
        
        # Verify chain link
        chain_valid = self._verify_chain_link(block_index)
        
        result = {
            "valid": block_hash_valid and merkle_valid and chain_valid,
            "transaction_id": transaction_id,
            "block_index": block_index,
            "timestamp": transaction["timestamp"],
            "type": transaction["type"],
            "initiator": transaction["initiator"],
            "verifications": {
                "block_hash": block_hash_valid,
                "merkle_proof": merkle_valid,
                "chain_link": chain_valid
            }
        }
        
        # Generate Merkle proof if requested
        if include_proof:
            result["merkle_proof"] = self._generate_merkle_proof(block, tx_index)
        
        return result
    
    def verify_chain(self) -> Dict[str, Any]:
        """
        Verify entire blockchain integrity.
        
        Returns:
            Verification results
        """
        results = {
            "valid": True,
            "blocks_checked": 0,
            "errors": [],
            "chain_length": len(self.chain)
        }
        
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i-1]
            
            # Check current block hash
            if current.hash != current.calculate_hash():
                results["valid"] = False
                results["errors"].append(f"Block {i} hash mismatch")
            
            # Check link to previous
            if current.previous_hash != previous.hash:
                results["valid"] = False
                results["errors"].append(f"Block {i} previous hash mismatch")
            
            # Check Merkle root
            if current.merkle_root != current.calculate_merkle_root():
                results["valid"] = False
                results["errors"].append(f"Block {i} Merkle root mismatch")
            
            results["blocks_checked"] += 1
        
        return results
    
    def get_transactions(
        self,
        user_id: Optional[str] = None,
        transaction_type: Optional[str] = None,
        start_date: Optional[datetime.datetime] = None,
        end_date: Optional[datetime.datetime] = None,
        limit: int = 1000
    ) -> List[Dict]:
        """
        Query transactions with filters.
        
        Args:
            user_id: Filter by user
            transaction_type: Filter by type
            start_date: Start date
            end_date: End date
            limit: Max results
        
        Returns:
            List of matching transactions
        """
        transactions = []
        
        for block in self.chain:
            for tx in block.transactions:
                # Apply filters
                if user_id and tx.get("initiator") != user_id:
                    continue
                
                if transaction_type and tx.get("type") != transaction_type:
                    continue
                
                tx_time = datetime.datetime.fromisoformat(tx["timestamp"])
                if start_date and tx_time < start_date:
                    continue
                
                if end_date and tx_time > end_date:
                    continue
                
                # Add block info
                tx_copy = tx.copy()
                tx_copy["block_index"] = block.index
                tx_copy["block_hash"] = block.hash[:16] + "..."
                
                transactions.append(tx_copy)
                
                if len(transactions) >= limit:
                    break
        
        return transactions
    
    def get_block(self, index: int) -> Optional[Dict]:
        """Get block by index"""
        if 0 <= index < len(self.chain):
            block = self.chain[index]
            return {
                "index": block.index,
                "timestamp": block.timestamp,
                "transactions": block.transactions,
                "previous_hash": block.previous_hash,
                "hash": block.hash,
                "merkle_root": block.merkle_root,
                "transaction_count": len(block.transactions)
            }
        return None
    
    def get_height(self) -> int:
        """Get current blockchain height"""
        return len(self.chain) - 1
    
    def _verify_merkle_proof(self, block: Block, tx_index: int) -> bool:
        """Verify Merkle proof for a transaction"""
        # Simplified verification - recalculate Merkle root
        return block.merkle_root == block.calculate_merkle_root()
    
    def _verify_chain_link(self, block_index: int) -> bool:
        """Verify link between blocks"""
        if block_index == 0:
            return True
        
        current = self.chain[block_index]
        previous = self.chain[block_index - 1]
        
        return current.previous_hash == previous.hash
    
    def _generate_merkle_proof(self, block: Block, tx_index: int) -> List[str]:
        """Generate Merkle proof for a transaction"""
        # Get transaction hash
        tx = block.transactions[tx_index]
        tx_hash = hashlib.sha256(
            json.dumps(tx, sort_keys=True).encode()
        ).hexdigest()
        
        # Get all transaction hashes
        tx_hashes = []
        for t in block.transactions:
            h = hashlib.sha256(
                json.dumps(t, sort_keys=True).encode()
            ).hexdigest()
            tx_hashes.append(h)
        
        # Build proof path
        proof = []
        index = tx_index
        
        while len(tx_hashes) > 1:
            if len(tx_hashes) % 2 != 0:
                tx_hashes.append(tx_hashes[-1])
            
            if index % 2 == 0:
                # Even index - need right sibling
                sibling = tx_hashes[index + 1]
                proof.append(f"R:{sibling}")
            else:
                # Odd index - need left sibling
                sibling = tx_hashes[index - 1]
                proof.append(f"L:{sibling}")
            
            # Move up tree
            index = index // 2
            new_hashes = []
            for i in range(0, len(tx_hashes), 2):
                combined = tx_hashes[i] + tx_hashes[i+1]
                new_hashes.append(hashlib.sha256(combined.encode()).hexdigest())
            tx_hashes = new_hashes
        
        return proof
    
    def _backup_block(self, block: Block):
        """Backup block to persistent storage"""
        backup_data = {
            "index": block.index,
            "timestamp": block.timestamp,
            "transactions": block.transactions,
            "previous_hash": block.previous_hash,
            "hash": block.hash,
            "nonce": block.nonce,
            "merkle_root": block.merkle_root,
            "version": block.version
        }
        
        # In production, save to database or cloud storage
        backup_file = f"backups/block_{block.index}_{block.hash[:8]}.json"
        os.makedirs("backups", exist_ok=True)
        
        with open(backup_file, "w") as f:
            json.dump(backup_data, f, indent=2)
        
        logger.debug(f"Block {block.index} backed up to {backup_file}")
    
    def _load_from_database(self, database_url: str):
        """Load blockchain from database"""
        # Implementation would load from PostgreSQL, etc.
        pass
    
    def _start_async_worker(self):
        """Start asynchronous write worker"""
        def worker():
            while not self.stop_async:
                try:
                    cmd = self.write_queue.get(timeout=1)
                    if cmd == "mine":
                        self.mine_block()
                    elif cmd == "sync":
                        self._sync_to_database()
                except:
                    pass
        
        self.async_thread = threading.Thread(target=worker, daemon=True)
        self.async_thread.start()
        logger.info("Async write worker started")
    
    def _sync_to_database(self):
        """Sync blockchain to database"""
        # Implementation would sync to PostgreSQL
        pass
    
    def export_ledger(self, format: str = "json") -> str:
        """Export entire ledger for backup"""
        if format == "json":
            export_data = []
            for block in self.chain:
                export_data.append({
                    "index": block.index,
                    "timestamp": block.timestamp,
                    "transactions": block.transactions,
                    "previous_hash": block.previous_hash,
                    "hash": block.hash,
                    "merkle_root": block.merkle_root
                })
            
            return json.dumps(export_data, indent=2)
        
        raise ValueError(f"Unsupported export format: {format}")
    
    def health_check(self) -> Dict[str, Any]:
        """Health check for ledger"""
        return {
            "status": "healthy",
            "blocks": len(self.chain),
            "pending_transactions": len(self.pending_transactions),
            "height": self.get_height(),
            "last_block": {
                "index": self.chain[-1].index,
                "hash": self.chain[-1].hash[:16] + "...",
                "timestamp": self.chain[-1].timestamp
            },
            "consensus": self.consensus,
            "mining_difficulty": self.mining_difficulty,
            "async_writes": self.async_writes
        }

__all__ = [
    "AgriculturalLedger",
    "Block",
    "TransactionType",
    "BlockchainError"
]