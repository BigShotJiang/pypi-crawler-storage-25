#!/usr/bin/env python
"""
cli.py - Command-line interface for Agri-Secure Framework
"""

import os
import sys
import json
import click
import logging
from pathlib import Path
from typing import Optional
import getpass

# Add parent directory to path for development
sys.path.insert(0, str(Path(__file__).parent.parent))

from agri_secure import AgriculturalSecurity
from agri_secure.exceptions import (
    AgriSecureError,
    AuthenticationError,
    ValidationError
)
from agri_secure.utils.helpers import generate_api_key, mask_sensitive_data
from agri_secure.models.schemas import UserRole

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)

# Disable verbose logging from dependencies
logging.getLogger("urllib3").setLevel(logging.WARNING)

class AliasedGroup(click.Group):
    """Command group with command aliases"""
    
    def get_command(self, ctx, cmd_name):
        # Try to get builtin command
        rv = click.Group.get_command(self, ctx, cmd_name)
        if rv is not None:
            return rv
        
        # Try aliases
        aliases = {
            "ls": "list",
            "rm": "delete",
            "add": "create",
            "info": "show",
            "inspect": "show"
        }
        
        if cmd_name in aliases:
            return click.Group.get_command(self, ctx, aliases[cmd_name])
        
        return None

@click.group(cls=AliasedGroup)
@click.version_option(version="2.0.0", prog_name="agri-secure")
def cli():
    """
    🌾 Agri-Secure Framework - Cybersecurity for Agricultural Data Systems
    
    A production-ready security framework for agricultural applications.
    """
    pass

@cli.group()
def config():
    """Configuration management commands"""
    pass

@config.command("init")
@click.option("--env", default="development", help="Environment (development/production)")
@click.option("--force", is_flag=True, help="Overwrite existing config")
def config_init(env, force):
    """Initialize configuration files"""
    click.echo("🌾 Initializing Agri-Secure Framework configuration...")
    
    # Create .env file
    env_file = Path(".env")
    if env_file.exists() and not force:
        click.echo("⚠️  .env file already exists. Use --force to overwrite.")
    else:
        env_content = f"""# Agri-Secure Framework Configuration
# Environment: {env}

# Security Settings
ENCRYPTION_KEY={generate_api_key()}
JWT_SECRET={generate_api_key()}
MFA_REQUIRED=true

# Database (choose one)
DATABASE_URL=postgresql://user:pass@localhost/agri_secure
# DATABASE_URL=mysql://user:pass@localhost/agri_secure
# DATABASE_URL=sqlite:///./agri_secure.db
# DATABASE_URL=mongodb://localhost:27017/agri_secure

# Cache (optional)
REDIS_URL=redis://localhost:6379/0
# MEMCACHED_URL=memcache://localhost:11211

# Application Settings
ENVIRONMENT={env}
LOG_LEVEL=INFO
BLOCKCHAIN_ENABLED=true

# Cloud Storage (optional)
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_REGION=af-south-1
S3_BUCKET=agri-secure-data

# Monitoring
METRICS_ENABLED=true
TRACING_ENABLED=false
"""
        env_file.write_text(env_content)
        click.echo("✅ Created .env file")
    
    # Create config.json
    config_file = Path("agri_secure_config.json")
    if config_file.exists() and not force:
        click.echo("⚠️  Config file already exists. Use --force to overwrite.")
    else:
        config_content = {
            "app_name": "my_agricultural_app",
            "environment": env,
            "version": "1.0.0",
            "features": {
                "mfa_required": True,
                "blockchain_enabled": True,
                "metrics_enabled": True
            }
        }
        config_file.write_text(json.dumps(config_content, indent=2))
        click.echo("✅ Created agri_secure_config.json")
    
    click.echo("\n📋 Next steps:")
    click.echo("  1. Edit .env with your database credentials")
    click.echo("  2. Run 'agri-secure db init' to create tables")
    click.echo("  3. Run 'agri-secure check' to verify setup")

@config.command("show")
@click.option("--show-secrets", is_flag=True, help="Show secret values (masked by default)")
def config_show(show_secrets):
    """Show current configuration"""
    click.echo("📋 Current Configuration:")
    click.echo("-" * 50)
    
    # Load .env
    env_file = Path(".env")
    if env_file.exists():
        from dotenv import load_dotenv
        load_dotenv()
        
        config_vars = [
            "ENVIRONMENT",
            "DATABASE_URL",
            "REDIS_URL",
            "LOG_LEVEL",
            "MFA_REQUIRED",
            "BLOCKCHAIN_ENABLED",
            "METRICS_ENABLED"
        ]
        
        for var in config_vars:
            value = os.getenv(var, "")
            if not show_secrets and any(secret in var.lower() for secret in ["key", "secret", "password"]):
                value = "********"
            click.echo(f"  {var}: {value}")
    
    # Load config file
    config_file = Path("agri_secure_config.json")
    if config_file.exists():
        config = json.loads(config_file.read_text())
        click.echo("\n  Config file:")
        for key, value in config.items():
            if isinstance(value, dict):
                click.echo(f"    {key}:")
                for k, v in value.items():
                    click.echo(f"      {k}: {v}")
            else:
                click.echo(f"    {key}: {value}")

@cli.group()
def db():
    """Database management commands"""
    pass

@db.command("init")
@click.option("--url", envvar="DATABASE_URL", help="Database URL")
def db_init(url):
    """Initialize database tables"""
    if not url:
        click.echo("❌ DATABASE_URL not set. Run 'agri-secure config init' first.")
        return
    
    click.echo("🗄️  Initializing database...")
    
    try:
        from agri_secure.adapters.database import DatabaseAdapter
        db = DatabaseAdapter(url)
        db.create_tables()
        click.echo("✅ Database tables created")
    except Exception as e:
        click.echo(f"❌ Failed to initialize database: {e}")

@db.command("migrate")
@click.option("--url", envvar="DATABASE_URL", help="Database URL")
def db_migrate(url):
    """Run database migrations"""
    if not url:
        click.echo("❌ DATABASE_URL not set")
        return
    
    click.echo("🔄 Running migrations...")
    
    try:
        from agri_secure.adapters.database import DatabaseAdapter
        db = DatabaseAdapter(url, auto_migrate=True)
        click.echo("✅ Migrations completed")
    except Exception as e:
        click.echo(f"❌ Migration failed: {e}")

@db.command("backup")
@click.option("--url", envvar="DATABASE_URL", help="Database URL")
@click.option("--path", default="./backups", help="Backup directory")
def db_backup(url, path):
    """Backup database"""
    if not url:
        click.echo("❌ DATABASE_URL not set")
        return
    
    click.echo(f"💾 Backing up database to {path}...")
    
    try:
        from agri_secure.adapters.database import DatabaseAdapter
        db = DatabaseAdapter(url)
        backup_file = db.backup(path)
        click.echo(f"✅ Backup created: {backup_file}")
    except Exception as e:
        click.echo(f"❌ Backup failed: {e}")

@cli.group()
def user():
    """User management commands"""
    pass

@user.command("create")
@click.option("--username", prompt=True, help="Username")
@click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True, help="Password")
@click.option("--role", type=click.Choice([r.value for r in UserRole]), prompt=True, help="User role")
@click.option("--email", help="Email address")
@click.option("--phone", help="Phone number")
@click.option("--first-name", help="First name")
@click.option("--last-name", help="Last name")
@click.option("--district", help="District")
@click.option("--province", help="Province")
def user_create(username, password, role, email, phone, first_name, last_name, district, province):
    """Create a new user"""
    click.echo(f"👤 Creating user: {username}")
    
    try:
        # Initialize framework
        from agri_secure import AgriculturalSecurity
        
        framework = AgriculturalSecurity(
            app_name="cli",
            environment=os.getenv("ENVIRONMENT", "development"),
            encryption_key=os.getenv("ENCRYPTION_KEY"),
            jwt_secret=os.getenv("JWT_SECRET")
        )
        
        # Create user
        user = framework.create_user(
            username=username,
            password=password,
            role=role,
            email=email,
            phone=phone,
            metadata={
                "first_name": first_name,
                "last_name": last_name,
                "district": district,
                "province": province
            }
        )
        
        # Show MFA setup
        if user.get("mfa_secret"):
            click.echo("\n🔐 Multi-Factor Authentication Setup:")
            click.echo(f"   Secret: {user['mfa_secret']}")
            click.echo("   Scan this QR code with Google Authenticator:")
            
            # Generate and display QR code
            try:
                import pyotp
                import qrcode
                from io import BytesIO
                import base64
                
                totp_uri = pyotp.totp.TOTP(user['mfa_secret']).provisioning_uri(
                    name=username,
                    issuer_name="AgriSecure"
                )
                
                qr = qrcode.QRCode(version=1, box_size=10, border=5)
                qr.add_data(totp_uri)
                qr.make(fit=True)
                img = qr.make_image(fill_color="black", back_color="white")
                
                # Save QR code to file
                img_file = f"qrcode_{username}.png"
                img.save(img_file)
                click.echo(f"   QR code saved to: {img_file}")
            except:
                pass
        
        click.echo(f"\n✅ User created successfully!")
        click.echo(f"   User ID: {user['user_id']}")
        
    except ValidationError as e:
        click.echo(f"❌ Validation error: {e}")
    except Exception as e:
        click.echo(f"❌ Failed to create user: {e}")

@user.command("list")
@click.option("--limit", default=20, help="Number of users to show")
def user_list(limit):
    """List users"""
    click.echo(f"📋 Listing users (limit: {limit})")
    
    try:
        # This would connect to database and list users
        click.echo("   Feature coming soon...")
    except Exception as e:
        click.echo(f"❌ Failed to list users: {e}")

@cli.command()
@click.option("--config", default="agri_secure_config.json", help="Config file path")
def check(config):
    """Run health check"""
    click.echo("🔍 Running health check...")
    
    try:
        # Load config
        config_file = Path(config)
        if not config_file.exists():
            click.echo("❌ Config file not found. Run 'agri-secure config init' first.")
            return
        
        app_config = json.loads(config_file.read_text())
        
        # Initialize framework
        framework = AgriculturalSecurity(
            app_name=app_config.get("app_name", "cli"),
            environment=os.getenv("ENVIRONMENT", "development"),
            encryption_key=os.getenv("ENCRYPTION_KEY"),
            jwt_secret=os.getenv("JWT_SECRET"),
            database_url=os.getenv("DATABASE_URL"),
            redis_url=os.getenv("REDIS_URL"),
            log_level=os.getenv("LOG_LEVEL", "INFO")
        )
        
        # Run health check
        health = framework.health_check(deep=True)
        
        click.echo("\n📊 Health Check Results:")
        click.echo("-" * 50)
        click.echo(f"Status: {'✅' if health['status'] == 'healthy' else '⚠️'} {health['status']}")
        click.echo(f"Version: {health['version']}")
        click.echo(f"Environment: {health['environment']}")
        click.echo(f"Uptime: {health['uptime']:.2f} seconds")
        
        click.echo("\nModules:")
        for module, status in health.get('modules', {}).items():
            if isinstance(status, dict):
                module_status = status.get('status', 'unknown')
                icon = '✅' if module_status == 'operational' else '⚠️' if module_status == 'degraded' else '❌'
                click.echo(f"  {icon} {module}: {module_status}")
            else:
                click.echo(f"  {module}: {status}")
        
        click.echo("-" * 50)
        
        if health['status'] == 'healthy':
            click.echo("✅ All systems operational")
        else:
            click.echo("⚠️  Some systems degraded")
        
    except Exception as e:
        click.echo(f"❌ Health check failed: {e}")

@cli.command()
@click.argument("transaction_id")
@click.option("--url", envvar="DATABASE_URL", help="Database URL")
def verify(transaction_id, url):
    """Verify data integrity using blockchain"""
    click.echo(f"🔍 Verifying transaction: {transaction_id}")
    
    try:
        framework = AgriculturalSecurity(
            app_name="cli",
            environment=os.getenv("ENVIRONMENT", "development"),
            encryption_key=os.getenv("ENCRYPTION_KEY"),
            jwt_secret=os.getenv("JWT_SECRET"),
            database_url=url
        )
        
        result = framework.verify_data_integrity(transaction_id, include_proof=True)
        
        if result.get('verified'):
            click.echo(f"✅ Transaction verified!")
            click.echo(f"   Block height: {result.get('block_height')}")
            click.echo(f"   Timestamp: {result.get('timestamp')}")
        else:
            click.echo(f"❌ Transaction verification failed!")
            if result.get('error'):
                click.echo(f"   Error: {result['error']}")
        
    except Exception as e:
        click.echo(f"❌ Verification failed: {e}")

@cli.command()
@click.option("--days", default=7, help="Number of days to look back")
@click.option("--format", type=click.Choice(['json', 'csv']), default='json', help="Output format")
@click.option("--output", help="Output file")
def audit(days, format, output):
    """Generate audit report"""
    click.echo(f"📋 Generating audit report for last {days} days")
    
    try:
        framework = AgriculturalSecurity(
            app_name="cli",
            environment=os.getenv("ENVIRONMENT", "development"),
            encryption_key=os.getenv("ENCRYPTION_KEY"),
            jwt_secret=os.getenv("JWT_SECRET"),
            database_url=os.getenv("DATABASE_URL")
        )
        
        report = framework.get_audit_report(days=days)
        
        if format == 'json':
            output_data = json.dumps(report, indent=2, default=str)
        else:
            import csv
            from io import StringIO
            
            output_data = StringIO()
            writer = csv.writer(output_data)
            writer.writerow(['Timestamp', 'Event Type', 'User', 'Resource', 'Action'])
            for event in report.get('events', []):
                writer.writerow([
                    event.get('timestamp'),
                    event.get('type'),
                    event.get('user'),
                    event.get('resource'),
                    event.get('action')
                ])
            output_data = output_data.getvalue()
        
        if output:
            with open(output, 'w') as f:
                f.write(output_data)
            click.echo(f"✅ Report saved to: {output}")
        else:
            click.echo(output_data)
        
    except Exception as e:
        click.echo(f"❌ Failed to generate audit report: {e}")

@cli.command()
@click.argument("file")
@click.option("--type", help="File type (image/document/data)")
def validate(file, type):
    """Validate file upload"""
    click.echo(f"🔍 Validating file: {file}")
    
    try:
        from agri_secure.utils.validators import DataValidator
        
        file_path = Path(file)
        if not file_path.exists():
            click.echo(f"❌ File not found: {file}")
            return
        
        size = file_path.stat().st_size
        
        # Detect MIME type
        import mimetypes
        content_type, _ = mimetypes.guess_type(file)
        
        result = DataValidator.validate_file_upload(
            file_path.name,
            content_type or 'application/octet-stream',
            size
        )
        
        if result['valid']:
            click.echo(f"✅ File is valid")
            click.echo(f"   Type: {result['file_type']}")
            click.echo(f"   Size: {result['size']} bytes")
        else:
            click.echo(f"❌ File validation failed: {result['error']}")
        
    except Exception as e:
        click.echo(f"❌ Validation failed: {e}")

@cli.command()
def docs():
    """Open documentation"""
    click.echo("📚 Opening documentation...")
    import webbrowser
    webbrowser.open("https://agri-secure-framework.readthedocs.io")

@cli.command()
def shell():
    """Start interactive shell with framework pre-loaded"""
    click.echo("🐚 Starting Agri-Secure shell...")
    
    try:
        import code
        import readline
        import rlcompleter
        
        # Create framework instance
        framework = AgriculturalSecurity(
            app_name="shell",
            environment=os.getenv("ENVIRONMENT", "development"),
            encryption_key=os.getenv("ENCRYPTION_KEY"),
            jwt_secret=os.getenv("JWT_SECRET"),
            database_url=os.getenv("DATABASE_URL")
        )
        
        # Set up namespace
        namespace = {
            'framework': framework,
            'AgriculturalSecurity': AgriculturalSecurity,
            'os': os,
            'json': json
        }
        
        # Start shell
        readline.parse_and_bind("tab: complete")
        code.interact(
            banner="\n🌾 Agri-Secure Framework Interactive Shell\nType 'framework' to access the main object\n",
            local=namespace
        )
        
    except Exception as e:
        click.echo(f"❌ Failed to start shell: {e}")

def main():
    """Main entry point"""
    try:
        cli()
    except KeyboardInterrupt:
        click.echo("\n⚠️  Interrupted")
        sys.exit(1)
    except Exception as e:
        click.echo(f"\n❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()