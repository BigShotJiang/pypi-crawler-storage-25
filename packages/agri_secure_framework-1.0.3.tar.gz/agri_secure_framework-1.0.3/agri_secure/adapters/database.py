"""
database.py - Production database adapter supporting multiple database backends
PostgreSQL, MySQL, SQLite, MongoDB with connection pooling and migrations
"""

import os
import logging
import json
from typing import Any, Dict, List, Optional, Union
from contextlib import contextmanager
from datetime import datetime
import threading
import time

logger = logging.getLogger(__name__)

class DatabaseError(Exception):
    """Base database error"""
    pass

class DatabaseAdapter:
    """
    Multi-database adapter with connection pooling and migrations.
    
    Supports:
        - PostgreSQL
        - MySQL
        - SQLite
        - MongoDB
    """
    
    def __init__(
        self,
        database_url: str,
        auto_migrate: bool = False,
        pool_size: int = 10,
        max_overflow: int = 20,
        pool_timeout: int = 30,
        pool_recycle: int = 3600,
        echo: bool = False
    ):
        """
        Initialize database adapter.
        
        Args:
            database_url: Database connection URL
            auto_migrate: Automatically run migrations
            pool_size: Connection pool size
            max_overflow: Maximum overflow connections
            pool_timeout: Connection pool timeout
            pool_recycle: Recycle connections after seconds
            echo: Log SQL queries
        """
        self.database_url = database_url
        self.pool_size = pool_size
        self.max_overflow = max_overflow
        self.pool_timeout = pool_timeout
        self.pool_recycle = pool_recycle
        self.echo = echo
        
        # Determine database type
        self.db_type = self._detect_database_type(database_url)
        logger.info(f"Initializing {self.db_type} database adapter")
        
        # Initialize appropriate driver
        self.engine = None
        self.SessionLocal = None
        self.Base = None
        self.mongo_client = None
        self.mongo_db = None
        
        self._init_database()
        
        if auto_migrate:
            self.run_migrations()
    
    def _detect_database_type(self, url: str) -> str:
        """Detect database type from URL"""
        if url.startswith('postgresql'):
            return 'postgresql'
        elif url.startswith('mysql'):
            return 'mysql'
        elif url.startswith('sqlite'):
            return 'sqlite'
        elif url.startswith('mongodb'):
            return 'mongodb'
        else:
            raise DatabaseError(f"Unsupported database type: {url}")
    
    def _init_database(self):
        """Initialize database connection"""
        if self.db_type == 'postgresql':
            self._init_postgresql()
        elif self.db_type == 'mysql':
            self._init_mysql()
        elif self.db_type == 'sqlite':
            self._init_sqlite()
        elif self.db_type == 'mongodb':
            self._init_mongodb()
    
    def _init_postgresql(self):
        """Initialize PostgreSQL connection"""
        try:
            from sqlalchemy import create_engine
            from sqlalchemy.ext.declarative import declarative_base
            from sqlalchemy.orm import sessionmaker
            
            self.engine = create_engine(
                self.database_url,
                pool_size=self.pool_size,
                max_overflow=self.max_overflow,
                pool_timeout=self.pool_timeout,
                pool_recycle=self.pool_recycle,
                echo=self.echo,
                pool_pre_ping=True  # Verify connections before using
            )
            
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )
            
            self.Base = declarative_base()
            logger.info("PostgreSQL adapter initialized")
            
        except ImportError:
            raise DatabaseError("SQLAlchemy not installed. Run: pip install sqlalchemy psycopg2-binary")
        except Exception as e:
            raise DatabaseError(f"Failed to initialize PostgreSQL: {e}")
    
    def _init_mysql(self):
        """Initialize MySQL connection"""
        try:
            from sqlalchemy import create_engine
            from sqlalchemy.ext.declarative import declarative_base
            from sqlalchemy.orm import sessionmaker
            
            self.engine = create_engine(
                self.database_url,
                pool_size=self.pool_size,
                max_overflow=self.max_overflow,
                pool_timeout=self.pool_timeout,
                pool_recycle=self.pool_recycle,
                echo=self.echo,
                pool_pre_ping=True
            )
            
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )
            
            self.Base = declarative_base()
            logger.info("MySQL adapter initialized")
            
        except ImportError:
            raise DatabaseError("SQLAlchemy not installed. Run: pip install sqlalchemy mysqlclient")
        except Exception as e:
            raise DatabaseError(f"Failed to initialize MySQL: {e}")
    
    def _init_sqlite(self):
        """Initialize SQLite connection"""
        try:
            from sqlalchemy import create_engine
            from sqlalchemy.ext.declarative import declarative_base
            from sqlalchemy.orm import sessionmaker
            
            # Ensure directory exists for file-based SQLite
            if self.database_url.startswith('sqlite:///'):
                db_path = self.database_url[10:]
                os.makedirs(os.path.dirname(db_path), exist_ok=True)
            
            self.engine = create_engine(
                self.database_url,
                connect_args={"check_same_thread": False},
                echo=self.echo,
                pool_size=1  # SQLite doesn't support multiple connections well
            )
            
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )
            
            self.Base = declarative_base()
            logger.info("SQLite adapter initialized")
            
        except ImportError:
            raise DatabaseError("SQLAlchemy not installed. Run: pip install sqlalchemy")
        except Exception as e:
            raise DatabaseError(f"Failed to initialize SQLite: {e}")
    
    def _init_mongodb(self):
        """Initialize MongoDB connection"""
        try:
            from pymongo import MongoClient
            from pymongo.errors import ConnectionFailure
            
            self.mongo_client = MongoClient(
                self.database_url,
                maxPoolSize=self.pool_size,
                serverSelectionTimeoutMS=5000
            )
            
            # Test connection
            self.mongo_client.admin.command('ping')
            
            # Get database name from URL
            db_name = self.database_url.split('/')[-1].split('?')[0]
            if not db_name:
                db_name = 'agri_secure'
            
            self.mongo_db = self.mongo_client[db_name]
            logger.info(f"MongoDB adapter initialized: {db_name}")
            
        except ImportError:
            raise DatabaseError("PyMongo not installed. Run: pip install pymongo")
        except ConnectionFailure as e:
            raise DatabaseError(f"Failed to connect to MongoDB: {e}")
        except Exception as e:
            raise DatabaseError(f"Failed to initialize MongoDB: {e}")
    
    @contextmanager
    def session(self):
        """Get database session (SQL databases)"""
        if self.db_type == 'mongodb':
            raise DatabaseError("Sessions not supported for MongoDB. Use get_collection() instead.")
        
        db_session = self.SessionLocal()
        try:
            yield db_session
            db_session.commit()
        except Exception as e:
            db_session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            db_session.close()
    
    def get_collection(self, collection_name: str):
        """Get MongoDB collection"""
        if self.db_type != 'mongodb':
            raise DatabaseError(f"Collections not supported for {self.db_type}")
        
        return self.mongo_db[collection_name]
    
    def create_tables(self):
        """Create all tables (SQL databases)"""
        if self.db_type == 'mongodb':
            logger.warning("create_tables() not supported for MongoDB")
            return
        
        try:
            self.Base.metadata.create_all(bind=self.engine)
            logger.info("Database tables created")
        except Exception as e:
            raise DatabaseError(f"Failed to create tables: {e}")
    
    def drop_tables(self):
        """Drop all tables (SQL databases)"""
        if self.db_type == 'mongodb':
            logger.warning("drop_tables() not supported for MongoDB")
            return
        
        try:
            self.Base.metadata.drop_all(bind=self.engine)
            logger.warning("Database tables dropped")
        except Exception as e:
            raise DatabaseError(f"Failed to drop tables: {e}")
    
    def run_migrations(self):
        """Run database migrations using Alembic"""
        if self.db_type == 'mongodb':
            logger.warning("Migrations not supported for MongoDB")
            return
        
        try:
            from alembic.config import Config
            from alembic import command
            
            # Check if migrations directory exists
            migrations_dir = 'migrations'
            if not os.path.exists(migrations_dir):
                logger.info("Initializing migrations directory")
                os.makedirs(migrations_dir)
                
                # Create alembic.ini
                alembic_cfg = Config()
                alembic_cfg.set_main_option("script_location", migrations_dir)
                alembic_cfg.set_main_option("sqlalchemy.url", self.database_url)
                
                command.init(alembic_cfg, migrations_dir)
                
                # Set up env.py to use our models
                self._setup_alembic_env(migrations_dir)
            
            # Run migrations
            alembic_cfg = Config("alembic.ini")
            command.upgrade(alembic_cfg, "head")
            logger.info("Database migrations completed")
            
        except ImportError:
            logger.warning("Alembic not installed. Run: pip install alembic")
        except Exception as e:
            raise DatabaseError(f"Migration failed: {e}")
    
    def _setup_alembic_env(self, migrations_dir: str):
        """Set up alembic env.py to use our models"""
        env_file = os.path.join(migrations_dir, 'env.py')
        if os.path.exists(env_file):
            with open(env_file, 'a') as f:
                f.write("""
# Import our models
from agri_secure.models import Base
target_metadata = Base.metadata
""")
    
    def execute_raw_sql(self, sql: str, params: Optional[Dict] = None):
        """Execute raw SQL query"""
        if self.db_type == 'mongodb':
            raise DatabaseError("Raw SQL not supported for MongoDB")
        
        with self.session() as session:
            result = session.execute(sql, params or {})
            return result.fetchall()
    
    def health_check(self) -> Dict[str, Any]:
        """Check database health"""
        health = {
            "status": "unknown",
            "type": self.db_type,
            "url": self.database_url.split('@')[-1] if '@' in self.database_url else self.database_url
        }
        
        try:
            if self.db_type == 'mongodb':
                self.mongo_client.admin.command('ping')
                health["status"] = "operational"
                health["collections"] = self.mongo_db.list_collection_names()
            else:
                with self.session() as session:
                    session.execute("SELECT 1")
                    health["status"] = "operational"
                    health["pool_size"] = self.engine.pool.size()
                    health["active_connections"] = self.engine.pool.checkedin()
            
        except Exception as e:
            health["status"] = "failed"
            health["error"] = str(e)
        
        return health
    
    def backup(self, backup_path: str) -> str:
        """Create database backup"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = f"{backup_path}/backup_{timestamp}.dump"
        
        os.makedirs(backup_path, exist_ok=True)
        
        if self.db_type == 'postgresql':
            # Use pg_dump
            import subprocess
            db_name = self.database_url.split('/')[-1]
            cmd = f"pg_dump {db_name} > {backup_file}"
            subprocess.run(cmd, shell=True, check=True)
            
        elif self.db_type == 'mysql':
            # Use mysqldump
            import subprocess
            db_name = self.database_url.split('/')[-1]
            cmd = f"mysqldump {db_name} > {backup_file}"
            subprocess.run(cmd, shell=True, check=True)
            
        elif self.db_type == 'mongodb':
            # Use mongodump
            import subprocess
            cmd = f"mongodump --uri='{self.database_url}' --out={backup_path}"
            subprocess.run(cmd, shell=True, check=True)
            backup_file = backup_path
        
        logger.info(f"Database backup created: {backup_file}")
        return backup_file
    
    def restore(self, backup_file: str):
        """Restore database from backup"""
        if not os.path.exists(backup_file):
            raise DatabaseError(f"Backup file not found: {backup_file}")
        
        if self.db_type == 'postgresql':
            import subprocess
            db_name = self.database_url.split('/')[-1]
            cmd = f"psql {db_name} < {backup_file}"
            subprocess.run(cmd, shell=True, check=True)
            
        elif self.db_type == 'mysql':
            import subprocess
            db_name = self.database_url.split('/')[-1]
            cmd = f"mysql {db_name} < {backup_file}"
            subprocess.run(cmd, shell=True, check=True)
            
        elif self.db_type == 'mongodb':
            import subprocess
            cmd = f"mongorestore --uri='{self.database_url}' {backup_file}"
            subprocess.run(cmd, shell=True, check=True)
        
        logger.info(f"Database restored from: {backup_file}")

# SQLAlchemy Models for agricultural data
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class UserModel(Base):
    """SQLAlchemy User model"""
    __tablename__ = "users"
    
    user_id = Column(String(50), primary_key=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, index=True)
    phone = Column(String(20), unique=True, index=True)
    password_hash = Column(String(200), nullable=False)
    role = Column(String(50), nullable=False)
    first_name = Column(String(100))
    last_name = Column(String(100))
    district = Column(String(100))
    province = Column(String(100))
    mfa_secret = Column(String(100))
    mfa_enabled = Column(Boolean, default=False)
    email_verified = Column(Boolean, default=False)
    phone_verified = Column(Boolean, default=False)
    failed_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime)
    last_login = Column(DateTime)
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)
    is_active = Column(Boolean, default=True)
    metadata = Column(JSON)

class FarmModel(Base):
    """SQLAlchemy Farm model"""
    __tablename__ = "farms"
    
    farm_id = Column(String(50), primary_key=True)
    farmer_id = Column(String(50), ForeignKey("users.user_id"), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    farm_type = Column(String(50), nullable=False)
    size_hectares = Column(Float, nullable=False)
    district = Column(String(100), nullable=False)
    province = Column(String(100), nullable=False)
    traditional_authority = Column(String(100))
    village = Column(String(100))
    latitude = Column(Float)
    longitude = Column(Float)
    crops = Column(JSON)
    livestock = Column(JSON)
    irrigation = Column(Boolean, default=False)
    irrigation_type = Column(String(100))
    water_source = Column(String(100))
    soil_type = Column(String(100))
    land_tenure = Column(String(100))
    year_established = Column(Integer)
    certifications = Column(JSON)
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)
    created_by = Column(String(50), nullable=False)
    is_active = Column(Boolean, default=True)
    metadata = Column(JSON)

class CropDataModel(Base):
    """SQLAlchemy Crop Data model"""
    __tablename__ = "crop_data"
    
    crop_data_id = Column(String(50), primary_key=True)
    farm_id = Column(String(50), ForeignKey("farms.farm_id"), nullable=False, index=True)
    crop_type = Column(String(50), nullable=False)
    season = Column(String(50), nullable=False)
    planting_date = Column(DateTime, nullable=False)
    harvest_date = Column(DateTime)
    area_planted = Column(Float, nullable=False)
    expected_yield = Column(Float)
    actual_yield = Column(Float)
    seed_variety = Column(String(100))
    seed_source = Column(String(100))
    fertilizer_used = Column(String(100))
    fertilizer_amount = Column(Float)
    pesticide_used = Column(String(100))
    pesticide_amount = Column(Float)
    irrigation_applied = Column(Float)
    labor_used = Column(Integer)
    recorded_by = Column(String(50), nullable=False)
    recorded_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)
    is_verified = Column(Boolean, default=False)
    verified_by = Column(String(50))
    verified_at = Column(DateTime)
    notes = Column(String(500))
    classification = Column(String(50), default="confidential")

class AuditLogModel(Base):
    """SQLAlchemy Audit Log model"""
    __tablename__ = "audit_logs"
    
    log_id = Column(String(50), primary_key=True)
    event_type = Column(String(50), nullable=False, index=True)
    user_id = Column(String(50), ForeignKey("users.user_id"), index=True)
    user_role = Column(String(50))
    resource_type = Column(String(50), nullable=False)
    resource_id = Column(String(50), index=True)
    action = Column(String(50), nullable=False)
    status = Column(String(20), nullable=False)
    ip_address = Column(String(50))
    user_agent = Column(String(200))
    request_id = Column(String(50))
    timestamp = Column(DateTime, nullable=False, index=True)
    details = Column(JSON)
    blockchain_tx_id = Column(String(100))

__all__ = [
    "DatabaseAdapter",
    "DatabaseError",
    "UserModel",
    "FarmModel",
    "CropDataModel",
    "AuditLogModel"
] 