"""
cache.py - Production caching adapter supporting Redis, Memcached, and in-memory
"""

import json
import logging
import pickle
from typing import Any, Optional, Dict, List, Union
from datetime import timedelta
import hashlib

logger = logging.getLogger(__name__)

class CacheError(Exception):
    """Cache operation error"""
    pass

class CacheAdapter:
    """
    Multi-backend cache adapter.
    
    Supports:
        - Redis
        - Memcached
        - In-memory (for development)
    """
    
    def __init__(
        self,
        cache_url: str,
        default_ttl: int = 3600,
        namespace: str = "agri_secure",
        serializer: str = "json"
    ):
        """
        Initialize cache adapter.
        
        Args:
            cache_url: Cache connection URL
            default_ttl: Default TTL in seconds
            namespace: Cache key namespace
            serializer: Serializer to use (json, pickle)
        """
        self.cache_url = cache_url
        self.default_ttl = default_ttl
        self.namespace = namespace
        self.serializer = serializer
        
        # Determine cache type
        self.cache_type = self._detect_cache_type(cache_url)
        logger.info(f"Initializing {self.cache_type} cache adapter")
        
        # Initialize cache client
        self.client = None
        self._init_cache()
        
        # In-memory fallback
        self._memory_cache = {}
        self._memory_expiry = {}
    
    def _detect_cache_type(self, url: str) -> str:
        """Detect cache type from URL"""
        if url.startswith('redis'):
            return 'redis'
        elif url.startswith('memcache'):
            return 'memcached'
        elif url == 'memory':
            return 'memory'
        else:
            return 'memory'  # Default to memory
    
    def _init_cache(self):
        """Initialize cache client"""
        if self.cache_type == 'redis':
            self._init_redis()
        elif self.cache_type == 'memcached':
            self._init_memcached()
        elif self.cache_type == 'memory':
            logger.info("Using in-memory cache")
    
    def _init_redis(self):
        """Initialize Redis client"""
        try:
            import redis
            
            self.client = redis.from_url(
                self.cache_url,
                decode_responses=False,
                socket_connect_timeout=5,
                socket_keepalive=True,
                health_check_interval=30
            )
            
            # Test connection
            self.client.ping()
            logger.info("Redis cache initialized")
            
        except ImportError:
            raise CacheError("Redis not installed. Run: pip install redis")
        except Exception as e:
            raise CacheError(f"Failed to connect to Redis: {e}")
    
    def _init_memcached(self):
        """Initialize Memcached client"""
        try:
            from pymemcache.client import base
            
            # Parse URL
            import re
            match = re.match(r'memcache://([^:]+):(\d+)', self.cache_url)
            if match:
                host, port = match.groups()
                self.client = base.Client((host, int(port)))
            else:
                raise CacheError(f"Invalid memcached URL: {self.cache_url}")
            
            # Test connection
            self.client.version()
            logger.info("Memcached cache initialized")
            
        except ImportError:
            raise CacheError("pymemcache not installed. Run: pip install pymemcache")
        except Exception as e:
            raise CacheError(f"Failed to connect to Memcached: {e}")
    
    def _make_key(self, key: str) -> str:
        """Create namespaced cache key"""
        return f"{self.namespace}:{key}"
    
    def _serialize(self, value: Any) -> bytes:
        """Serialize value for storage"""
        if self.serializer == 'json':
            return json.dumps(value, default=str).encode('utf-8')
        elif self.serializer == 'pickle':
            return pickle.dumps(value)
        else:
            return str(value).encode('utf-8')
    
    def _deserialize(self, data: bytes) -> Any:
        """Deserialize value from storage"""
        if not data:
            return None
        
        if self.serializer == 'json':
            return json.loads(data.decode('utf-8'))
        elif self.serializer == 'pickle':
            return pickle.loads(data)
        else:
            return data.decode('utf-8')
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get value from cache"""
        cache_key = self._make_key(key)
        
        try:
            if self.cache_type == 'redis' and self.client:
                value = self.client.get(cache_key)
                if value:
                    return self._deserialize(value)
            
            elif self.cache_type == 'memcached' and self.client:
                value = self.client.get(cache_key)
                if value:
                    return self._deserialize(value)
            
            elif self.cache_type == 'memory':
                if cache_key in self._memory_cache:
                    if time.time() < self._memory_expiry.get(cache_key, 0):
                        return self._memory_cache[cache_key]
                    else:
                        del self._memory_cache[cache_key]
                        del self._memory_expiry[cache_key]
            
            return default
            
        except Exception as e:
            logger.error(f"Cache get error for key {key}: {e}")
            return default
    
    def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None
    ) -> bool:
        """Set value in cache"""
        cache_key = self._make_key(key)
        ttl = ttl or self.default_ttl
        
        try:
            serialized = self._serialize(value)
            
            if self.cache_type == 'redis' and self.client:
                return bool(self.client.setex(cache_key, ttl, serialized))
            
            elif self.cache_type == 'memcached' and self.client:
                return self.client.set(cache_key, serialized, expire=ttl)
            
            elif self.cache_type == 'memory':
                self._memory_cache[cache_key] = value
                self._memory_expiry[cache_key] = time.time() + ttl
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Cache set error for key {key}: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete key from cache"""
        cache_key = self._make_key(key)
        
        try:
            if self.cache_type == 'redis' and self.client:
                return bool(self.client.delete(cache_key))
            
            elif self.cache_type == 'memcached' and self.client:
                return bool(self.client.delete(cache_key))
            
            elif self.cache_type == 'memory':
                if cache_key in self._memory_cache:
                    del self._memory_cache[cache_key]
                if cache_key in self._memory_expiry:
                    del self._memory_expiry[cache_key]
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Cache delete error for key {key}: {e}")
            return False
    
    def exists(self, key: str) -> bool:
        """Check if key exists"""
        cache_key = self._make_key(key)
        
        try:
            if self.cache_type == 'redis' and self.client:
                return bool(self.client.exists(cache_key))
            
            elif self.cache_type == 'memcached' and self.client:
                return self.client.get(cache_key) is not None
            
            elif self.cache_type == 'memory':
                if cache_key in self._memory_cache:
                    if time.time() < self._memory_expiry.get(cache_key, 0):
                        return True
                    else:
                        del self._memory_cache[cache_key]
                        del self._memory_expiry[cache_key]
                return False
            
            return False
            
        except Exception as e:
            logger.error(f"Cache exists error for key {key}: {e}")
            return False
    
    def increment(self, key: str, amount: int = 1) -> Optional[int]:
        """Increment numeric value"""
        cache_key = self._make_key(key)
        
        try:
            if self.cache_type == 'redis' and self.client:
                return self.client.incr(cache_key, amount)
            
            elif self.cache_type == 'memcached' and self.client:
                # Memcached doesn't support atomic increment with our client
                value = self.get(key, 0)
                value += amount
                self.set(key, value)
                return value
            
            elif self.cache_type == 'memory':
                value = self.get(key, 0)
                value += amount
                self.set(key, value)
                return value
            
            return None
            
        except Exception as e:
            logger.error(f"Cache increment error for key {key}: {e}")
            return None
    
    def expire(self, key: str, ttl: int) -> bool:
        """Set expiration on key"""
        cache_key = self._make_key(key)
        
        try:
            if self.cache_type == 'redis' and self.client:
                return bool(self.client.expire(cache_key, ttl))
            
            elif self.cache_type == 'memcached' and self.client:
                # Get current value and reset with new TTL
                value = self.get(key)
                if value is not None:
                    return self.set(key, value, ttl)
                return False
            
            elif self.cache_type == 'memory':
                if cache_key in self._memory_cache:
                    self._memory_expiry[cache_key] = time.time() + ttl
                    return True
                return False
            
            return False
            
        except Exception as e:
            logger.error(f"Cache expire error for key {key}: {e}")
            return False
    
    def ttl(self, key: str) -> Optional[int]:
        """Get remaining TTL for key"""
        cache_key = self._make_key(key)
        
        try:
            if self.cache_type == 'redis' and self.client:
                return self.client.ttl(cache_key)
            
            elif self.cache_type == 'memory':
                if cache_key in self._memory_expiry:
                    remaining = self._memory_expiry[cache_key] - time.time()
                    return max(0, int(remaining))
            
            return None
            
        except Exception as e:
            logger.error(f"Cache TTL error for key {key}: {e}")
            return None
    
    def clear(self, pattern: Optional[str] = None):
        """Clear cache keys"""
        try:
            if self.cache_type == 'redis' and self.client:
                if pattern:
                    keys = self.client.keys(f"{self.namespace}:{pattern}")
                    if keys:
                        self.client.delete(*keys)
                else:
                    keys = self.client.keys(f"{self.namespace}:*")
                    if keys:
                        self.client.delete(*keys)
            
            elif self.cache_type == 'memcached' and self.client:
                # Memcached doesn't support pattern deletion
                self.client.flush_all()
            
            elif self.cache_type == 'memory':
                if pattern:
                    pattern_key = f"{self.namespace}:{pattern}"
                    keys_to_delete = []
                    for key in self._memory_cache:
                        if key.startswith(pattern_key.replace('*', '')):
                            keys_to_delete.append(key)
                    for key in keys_to_delete:
                        del self._memory_cache[key]
                        if key in self._memory_expiry:
                            del self._memory_expiry[key]
                else:
                    self._memory_cache.clear()
                    self._memory_expiry.clear()
            
            logger.info(f"Cache cleared (pattern: {pattern})")
            
        except Exception as e:
            logger.error(f"Cache clear error: {e}")
    
    def get_many(self, keys: List[str]) -> Dict[str, Any]:
        """Get multiple keys"""
        result = {}
        for key in keys:
            value = self.get(key)
            if value is not None:
                result[key] = value
        return result
    
    def set_many(self, mapping: Dict[str, Any], ttl: Optional[int] = None):
        """Set multiple keys"""
        for key, value in mapping.items():
            self.set(key, value, ttl)
    
    def delete_many(self, keys: List[str]):
        """Delete multiple keys"""
        for key in keys:
            self.delete(key)
    
    def health_check(self) -> Dict[str, Any]:
        """Check cache health"""
        health = {
            "status": "unknown",
            "type": self.cache_type,
            "url": self.cache_url
        }
        
        try:
            test_key = "health_check"
            test_value = "ok"
            
            self.set(test_key, test_value, ttl=10)
            retrieved = self.get(test_key)
            self.delete(test_key)
            
            if retrieved == test_value:
                health["status"] = "operational"
            else:
                health["status"] = "degraded"
            
        except Exception as e:
            health["status"] = "failed"
            health["error"] = str(e)
        
        return health
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        stats = {
            "type": self.cache_type,
            "namespace": self.namespace,
            "default_ttl": self.default_ttl
        }
        
        try:
            if self.cache_type == 'redis' and self.client:
                info = self.client.info()
                stats.update({
                    "redis_version": info.get("redis_version"),
                    "used_memory": info.get("used_memory_human"),
                    "total_connections": info.get("total_connections_received"),
                    "keyspace_hits": info.get("keyspace_hits"),
                    "keyspace_misses": info.get("keyspace_misses"),
                    "uptime": info.get("uptime_in_seconds")
                })
            
            elif self.cache_type == 'memory':
                stats.update({
                    "items": len(self._memory_cache),
                    "memory_usage": "unknown"
                })
            
        except Exception as e:
            stats["error"] = str(e)
        
        return stats

class CacheManager:
    """
    High-level cache manager for agricultural data.
    Provides specialized caching for common operations.
    """
    
    def __init__(self, cache: CacheAdapter):
        self.cache = cache
    
    def get_farm_data(self, farm_id: str) -> Optional[Dict]:
        """Get cached farm data"""
        return self.cache.get(f"farm:{farm_id}")
    
    def set_farm_data(self, farm_id: str, data: Dict, ttl: int = 3600):
        """Cache farm data"""
        self.cache.set(f"farm:{farm_id}", data, ttl)
    
    def invalidate_farm_data(self, farm_id: str):
        """Invalidate farm data cache"""
        self.cache.delete(f"farm:{farm_id}")
    
    def get_user_session(self, session_id: str) -> Optional[Dict]:
        """Get cached user session"""
        return self.cache.get(f"session:{session_id}")
    
    def set_user_session(self, session_id: str, data: Dict, ttl: int = 28800):
        """Cache user session (8 hours default)"""
        self.cache.set(f"session:{session_id}", data, ttl)
    
    def invalidate_user_session(self, session_id: str):
        """Invalidate user session"""
        self.cache.delete(f"session:{session_id}")
    
    def get_rate_limit(self, client_id: str) -> Optional[int]:
        """Get rate limit counter"""
        return self.cache.get(f"rate_limit:{client_id}")
    
    def increment_rate_limit(self, client_id: str, ttl: int = 60) -> int:
        """Increment rate limit counter"""
        return self.cache.increment(f"rate_limit:{client_id}") or 0
    
    def reset_rate_limit(self, client_id: str):
        """Reset rate limit counter"""
        self.cache.delete(f"rate_limit:{client_id}")
    
    def lock_resource(self, resource_id: str, owner: str, ttl: int = 30) -> bool:
        """Acquire distributed lock"""
        lock_key = f"lock:{resource_id}"
        
        # Try to set lock with NX option (only if not exists)
        if self.cache.cache_type == 'redis' and self.cache.client:
            result = self.cache.client.set(
                self.cache._make_key(lock_key),
                owner,
                nx=True,
                ex=ttl
            )
            return bool(result)
        else:
            # Fallback for non-redis caches
            if not self.cache.exists(lock_key):
                self.cache.set(lock_key, owner, ttl)
                return True
            return False
    
    def release_lock(self, resource_id: str, owner: str) -> bool:
        """Release distributed lock"""
        lock_key = f"lock:{resource_id}"
        
        # Only release if we own the lock
        current_owner = self.cache.get(lock_key)
        if current_owner == owner:
            self.cache.delete(lock_key)
            return True
        return False

__all__ = [
    "CacheAdapter",
    "CacheManager",
    "CacheError"
]