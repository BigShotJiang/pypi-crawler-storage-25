"""
admin.py - Administrative interface for framework management
"""

import os
import sys
import json
import logging
import datetime
from typing import Optional, Dict, Any, List
from pathlib import Path

logger = logging.getLogger(__name__)

class AdminInterface:
    """
    Administrative interface for framework management.
    Provides tools for monitoring, debugging, and maintenance.
    """
    
    def __init__(self, framework):
        self.framework = framework
        self.start_time = datetime.datetime.utcnow()
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        status = {
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "uptime": (datetime.datetime.utcnow() - self.start_time).total_seconds(),
            "framework_version": self.framework.__version__,
            "environment": self.framework.environment,
            "health": self.framework.health_check(),
            "stats": self.get_statistics()
        }
        return status
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics"""
        stats = {
            "users": {
                "total": 0,
                "active_sessions": len(self.framework.auth.active_sessions) if hasattr(self.framework.auth, 'active_sessions') else 0
            },
            "data": {
                "total_records": 0,
                "encrypted_records": 0
            },
            "blockchain": {
                "blocks": 0,
                "transactions": 0
            }
        }
        
        # Get blockchain stats
        if hasattr(self.framework, 'ledger') and self.framework.ledger:
            stats["blockchain"]["blocks"] = len(self.framework.ledger.chain)
            stats["blockchain"]["transactions"] = sum(
                len(block.transactions) for block in self.framework.ledger.chain
            )
        
        return stats
    
    def get_recent_events(self, limit: int = 100) -> List[Dict]:
        """Get recent system events"""
        events = []
        
        if hasattr(self.framework, 'ledger') and self.framework.ledger:
            transactions = self.framework.ledger.get_transactions(limit=limit)
            for tx in transactions:
                events.append({
                    "timestamp": tx.get("timestamp"),
                    "type": tx.get("type"),
                    "initiator": tx.get("initiator"),
                    "data": tx.get("data"),
                    "block_index": tx.get("block_index")
                })
        
        return events
    
    def get_error_logs(self, limit: int = 100) -> List[Dict]:
        """Get recent error logs"""
        # This would read from log files
        log_file = Path("agri_secure.log")
        errors = []
        
        if log_file.exists():
            with open(log_file, 'r') as f:
                for line in f.readlines()[-limit:]:
                    if "ERROR" in line or "CRITICAL" in line:
                        errors.append(line.strip())
        
        return errors
    
    def cleanup_expired_data(self, days: int = 30) -> Dict:
        """Clean up expired data"""
        results = {
            "sessions_cleaned": 0,
            "tokens_cleaned": 0,
            "logs_cleaned": 0
        }
        
        # Clean expired sessions
        if hasattr(self.framework, 'auth'):
            now = datetime.datetime.utcnow()
            expired = []
            
            for session_id, session in self.framework.auth.active_sessions.items():
                if session.expires_at < now:
                    expired.append(session_id)
            
            for session_id in expired:
                del self.framework.auth.active_sessions[session_id]
                results["sessions_cleaned"] += 1
        
        return results
    
    def rotate_all_keys(self) -> Dict:
        """Rotate all encryption keys"""
        results = {}
        
        if hasattr(self.framework, 'encryption'):
            old_key_id = self.framework.encryption.current_key_id
            new_key_id = self.framework.encryption.rotate_key()
            results["encryption_key"] = {
                "old": old_key_id,
                "new": new_key_id
            }
        
        return results
    
    def get_performance_metrics(self) -> Dict:
        """Get performance metrics"""
        metrics = {}
        
        if hasattr(self.framework, 'metrics'):
            # Get Prometheus metrics
            pass
        
        return metrics
    
    def generate_report(self, report_type: str = "summary") -> str:
        """Generate administrative report"""
        report = []
        report.append("=" * 80)
        report.append(f"AGRI-SECURE FRAMEWORK ADMINISTRATIVE REPORT")
        report.append(f"Generated: {datetime.datetime.utcnow().isoformat()}")
        report.append("=" * 80)
        
        if report_type == "summary":
            status = self.get_system_status()
            report.append(f"\nSYSTEM STATUS:")
            report.append(f"  Status: {status['health']['status']}")
            report.append(f"  Uptime: {status['uptime']:.2f} seconds")
            report.append(f"  Environment: {status['environment']}")
            
            report.append(f"\nSTATISTICS:")
            for category, values in status['stats'].items():
                report.append(f"  {category}:")
                for key, value in values.items():
                    report.append(f"    {key}: {value}")
            
            report.append(f"\nRECENT EVENTS:")
            events = self.get_recent_events(limit=10)
            for event in events:
                report.append(f"  [{event['timestamp']}] {event['type']} by {event['initiator']}")
        
        elif report_type == "audit":
            audit = self.framework.get_audit_report(days=7)
            report.append(f"\nAUDIT TRAIL:")
            for event in audit.get('events', [])[:50]:
                report.append(f"  [{event['timestamp']}] {event['type']} - {event['user']}")
        
        elif report_type == "errors":
            errors = self.get_error_logs(limit=50)
            report.append(f"\nERROR LOGS:")
            for error in errors:
                report.append(f"  {error}")
        
        report.append("\n" + "=" * 80)
        
        return "\n".join(report)
    
    def save_report(self, filename: Optional[str] = None) -> str:
        """Save administrative report to file"""
        if not filename:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"admin_report_{timestamp}.txt"
        
        report = self.generate_report("summary")
        
        with open(filename, 'w') as f:
            f.write(report)
        
        logger.info(f"Admin report saved to {filename}")
        return filename
    
    def interactive_shell(self):
        """Start administrative shell"""
        import code
        import readline
        import rlcompleter
        
        namespace = {
            'admin': self,
            'framework': self.framework,
            'datetime': datetime,
            'json': json
        }
        
        readline.parse_and_bind("tab: complete")
        code.interact(
            banner="\n🔧 Agri-Secure Administrative Shell\nAvailable: admin, framework\n",
            local=namespace
        )

# Admin CLI commands
@click.group()
def admin_cli():
    """Administrative commands"""
    pass

@admin_cli.command()
@click.pass_context
def status(ctx):
    """Show system status"""
    from agri_secure import AgriculturalSecurity
    
    framework = AgriculturalSecurity(
        app_name="admin",
        environment=os.getenv("ENVIRONMENT", "development"),
        encryption_key=os.getenv("ENCRYPTION_KEY"),
        jwt_secret=os.getenv("JWT_SECRET"),
        database_url=os.getenv("DATABASE_URL")
    )
    
    admin = AdminInterface(framework)
    status = admin.get_system_status()
    
    click.echo(json.dumps(status, indent=2, default=str))

@admin_cli.command()
@click.option("--type", type=click.Choice(['summary', 'audit', 'errors']), default='summary')
@click.option("--output", help="Output file")
@click.pass_context
def report(ctx, type, output):
    """Generate administrative report"""
    from agri_secure import AgriculturalSecurity
    
    framework = AgriculturalSecurity(
        app_name="admin",
        environment=os.getenv("ENVIRONMENT", "development"),
        encryption_key=os.getenv("ENCRYPTION_KEY"),
        jwt_secret=os.getenv("JWT_SECRET"),
        database_url=os.getenv("DATABASE_URL")
    )
    
    admin = AdminInterface(framework)
    
    if output:
        filename = admin.save_report(output)
        click.echo(f"✅ Report saved to: {filename}")
    else:
        report = admin.generate_report(type)
        click.echo(report)

@admin_cli.command()
@click.option("--days", default=30, help="Cleanup data older than days")
@click.pass_context
def cleanup(ctx, days):
    """Clean up expired data"""
    from agri_secure import AgriculturalSecurity
    
    framework = AgriculturalSecurity(
        app_name="admin",
        environment=os.getenv("ENVIRONMENT", "development"),
        encryption_key=os.getenv("ENCRYPTION_KEY"),
        jwt_secret=os.getenv("JWT_SECRET")
    )
    
    admin = AdminInterface(framework)
    results = admin.cleanup_expired_data(days)
    
    click.echo("✅ Cleanup completed:")
    for key, value in results.items():
        click.echo(f"  {key}: {value}")

@admin_cli.command()
@click.confirmation_option(prompt='Are you sure you want to rotate all keys?')
@click.pass_context
def rotate_keys(ctx):
    """Rotate all encryption keys"""
    from agri_secure import AgriculturalSecurity
    
    framework = AgriculturalSecurity(
        app_name="admin",
        environment=os.getenv("ENVIRONMENT", "development"),
        encryption_key=os.getenv("ENCRYPTION_KEY"),
        jwt_secret=os.getenv("JWT_SECRET")
    )
    
    admin = AdminInterface(framework)
    results = admin.rotate_all_keys()
    
    click.echo("✅ Keys rotated:")
    for key, value in results.items():
        click.echo(f"  {key}: {value}")

@admin_cli.command()
@click.pass_context
def shell(ctx):
    """Start administrative shell"""
    from agri_secure import AgriculturalSecurity
    
    framework = AgriculturalSecurity(
        app_name="admin",
        environment=os.getenv("ENVIRONMENT", "development"),
        encryption_key=os.getenv("ENCRYPTION_KEY"),
        jwt_secret=os.getenv("JWT_SECRET")
    )
    
    admin = AdminInterface(framework)
    admin.interactive_shell()

# Add admin commands to main CLI
cli.add_command(admin_cli, name="admin")

__all__ = [
    "AdminInterface",
    "admin_cli"
]