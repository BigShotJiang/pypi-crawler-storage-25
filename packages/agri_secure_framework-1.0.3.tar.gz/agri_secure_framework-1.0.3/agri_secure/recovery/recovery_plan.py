"""
recovery_plan.py - Disaster Recovery Plan (DRP) for agricultural data systems.

Provides:
  - Structured recovery procedures for each failure scenario
  - RTO/RPO tracking
  - Automated restore from backup
  - System health verification post-restore
  - Recovery runbook generation
"""

import json
import logging
import os
import subprocess
import tempfile
import gzip
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class RecoveryError(Exception):
    """Raised when a recovery operation fails"""
    pass


class RecoveryPlan:
    """
    Disaster Recovery Plan with automated restore capabilities.

    Recovery Scenarios Covered:
        1. Database corruption / accidental deletion
        2. Ransomware / data encryption attack
        3. Hardware failure
        4. Cloud provider outage
        5. Application deployment failure
        6. Encryption key loss

    RTO (Recovery Time Objective):  < 4 hours for critical systems
    RPO (Recovery Point Objective): < 1 hour (with 6-hour incremental backups)

    Usage::

        plan = RecoveryPlan(
            backup_system=backup,           # AutomatedBackup instance
            database_url="postgresql://...",
            encryption_engine=encryption,   # AgriculturalEncryption instance
        )

        # Restore from the latest backup
        result = plan.restore_latest(dry_run=True)

        # Restore from a specific backup file
        result = plan.restore_from_file("/var/backups/full_20260415_120000.sql.gz.enc")
    """

    # Recovery priority levels
    PRIORITY = {
        "critical": 1,   # Authentication, encryption keys
        "high": 2,       # Database, user data
        "medium": 3,     # Cache, sessions
        "low": 4,        # Logs, metrics
    }

    def __init__(
        self,
        backup_system,                          # AutomatedBackup instance
        database_url: str,
        encryption_engine=None,
        restore_dir: str = "restore_staging",
        verify_after_restore: bool = True,
        notification_email: Optional[str] = None,
    ):
        """
        Args:
            backup_system: AutomatedBackup instance
            database_url: Target database URL for restore
            encryption_engine: AgriculturalEncryption instance (required if backups are encrypted)
            restore_dir: Staging directory for restore operations
            verify_after_restore: Run health checks after restore
            notification_email: Email for recovery notifications
        """
        self.backup = backup_system
        self.database_url = database_url
        self.encryption_engine = encryption_engine
        self.restore_dir = Path(restore_dir)
        self.verify_after_restore = verify_after_restore
        self.notification_email = notification_email

        self.restore_dir.mkdir(parents=True, exist_ok=True)
        self._recovery_log: List[Dict[str, Any]] = []

        logger.info("RecoveryPlan initialized")

    # ------------------------------------------------------------------
    # Restore operations
    # ------------------------------------------------------------------

    def restore_latest(self, backup_type: str = "full", dry_run: bool = False) -> Dict[str, Any]:
        """
        Restore from the most recent backup.

        Args:
            backup_type: "full" or "incremental"
            dry_run: If True, validate the backup without actually restoring

        Returns:
            Dict with restore result metadata
        """
        backups = self.backup.list_backups(backup_type=backup_type)
        if not backups:
            raise RecoveryError(f"No {backup_type} backups found")

        latest = backups[0]
        logger.info(
            f"Restoring from latest {backup_type} backup: {latest['filename']} "
            f"(created {latest['created_at']})"
        )
        return self.restore_from_manifest(latest, dry_run=dry_run)

    def restore_from_file(self, backup_path: str, dry_run: bool = False) -> Dict[str, Any]:
        """
        Restore from a specific backup file.

        Args:
            backup_path: Absolute or relative path to the backup file
            dry_run: Validate without restoring

        Returns:
            Dict with restore result metadata
        """
        path = Path(backup_path)
        if not path.exists():
            raise RecoveryError(f"Backup file not found: {backup_path}")

        # Verify integrity first
        verification = self.backup.verify_backup(str(path))
        if not verification.get("verified") and not dry_run:
            raise RecoveryError(
                f"Backup integrity check failed: {verification.get('error', 'checksum mismatch')}"
            )

        manifest = {
            "filename": path.name,
            "path": str(path),
            "encrypted": path.suffix == ".enc",
            "compressed": ".gz" in path.name,
            "db_type": self.backup.db_type,
        }
        return self.restore_from_manifest(manifest, dry_run=dry_run)

    def restore_from_manifest(
        self, manifest: Dict[str, Any], dry_run: bool = False
    ) -> Dict[str, Any]:
        """
        Restore using a backup manifest dict.

        Args:
            manifest: Backup manifest (from list_backups or backup log)
            dry_run: Validate without restoring

        Returns:
            Dict with restore result metadata
        """
        start = datetime.utcnow()
        result: Dict[str, Any] = {
            "filename": manifest.get("filename"),
            "dry_run": dry_run,
            "started_at": start.isoformat(),
            "steps": [],
        }

        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                work_path = Path(tmpdir) / manifest["filename"]
                src_path = Path(manifest["path"])

                # Step 1: Copy to staging
                shutil.copy2(src_path, work_path)
                result["steps"].append({"step": "copy_to_staging", "status": "ok"})

                # Step 2: Decrypt
                if manifest.get("encrypted") or work_path.suffix == ".enc":
                    work_path = self._decrypt_backup(work_path, tmpdir)
                    result["steps"].append({"step": "decrypt", "status": "ok"})

                # Step 3: Decompress
                if ".gz" in work_path.name:
                    work_path = self._decompress_backup(work_path, tmpdir)
                    result["steps"].append({"step": "decompress", "status": "ok"})

                # Step 4: Validate SQL
                self._validate_sql_file(work_path)
                result["steps"].append({"step": "validate_sql", "status": "ok"})

                if dry_run:
                    result["success"] = True
                    result["message"] = "Dry run completed — backup is valid and restorable"
                    logger.info(f"Dry run restore successful: {manifest['filename']}")
                    return result

                # Step 5: Restore to database
                self._restore_to_database(work_path, manifest.get("db_type", "postgresql"))
                result["steps"].append({"step": "restore_database", "status": "ok"})

        except Exception as exc:
            result["success"] = False
            result["error"] = str(exc)
            logger.error(f"Restore failed: {exc}")
            self._log_recovery_event("restore_failed", manifest, str(exc))
            raise RecoveryError(f"Restore failed: {exc}") from exc

        # Step 6: Post-restore verification
        if self.verify_after_restore:
            verification = self._verify_system_health()
            result["post_restore_health"] = verification
            result["steps"].append({
                "step": "health_check",
                "status": "ok" if verification.get("healthy") else "warning",
            })

        duration = (datetime.utcnow() - start).total_seconds()
        result["success"] = True
        result["duration_seconds"] = round(duration, 2)
        result["completed_at"] = datetime.utcnow().isoformat()

        self._log_recovery_event("restore_completed", manifest)
        logger.info(
            f"Restore completed: {manifest['filename']} | duration={duration:.1f}s"
        )
        return result

    # ------------------------------------------------------------------
    # Recovery procedures (runbook)
    # ------------------------------------------------------------------

    def get_recovery_runbook(self, scenario: str) -> Dict[str, Any]:
        """
        Return a structured recovery runbook for a given failure scenario.

        Args:
            scenario: One of: database_corruption, ransomware, hardware_failure,
                      cloud_outage, deployment_failure, key_loss

        Returns:
            Dict with steps, RTO, RPO, and responsible parties
        """
        runbooks = {
            "database_corruption": {
                "scenario": "Database Corruption / Accidental Deletion",
                "severity": "critical",
                "rto_hours": 2,
                "rpo_hours": 1,
                "steps": [
                    "1. IMMEDIATELY stop all write operations to the database",
                    "2. Alert the on-call DBA and security team",
                    "3. Identify the last known-good backup using: backup.list_backups()",
                    "4. Verify backup integrity: plan.restore_latest(dry_run=True)",
                    "5. Spin up a new database instance (do NOT overwrite the corrupted one yet)",
                    "6. Restore to the new instance: plan.restore_latest(dry_run=False)",
                    "7. Verify data integrity with application smoke tests",
                    "8. Switch application connection string to the new instance",
                    "9. Monitor for 30 minutes before decommissioning the old instance",
                    "10. Document the incident and root cause",
                ],
                "contacts": ["DBA Team", "Security Team", "System Admin"],
                "tools": ["pg_restore / mysql / mongorestore", "agri-secure backup restore"],
            },
            "ransomware": {
                "scenario": "Ransomware / Data Encryption Attack",
                "severity": "critical",
                "rto_hours": 4,
                "rpo_hours": 6,
                "steps": [
                    "1. IMMEDIATELY isolate all affected systems from the network",
                    "2. Do NOT pay the ransom — restore from offline backups",
                    "3. Alert security team and management",
                    "4. Preserve forensic evidence (do not wipe systems yet)",
                    "5. Identify the attack vector and patch it",
                    "6. Provision clean infrastructure (new VMs/containers)",
                    "7. Restore encryption keys from offline key backup",
                    "8. Restore database from the last clean backup",
                    "9. Restore application code from version control",
                    "10. Rotate ALL credentials (DB passwords, API keys, JWT secrets)",
                    "11. Enable enhanced monitoring and alerting",
                    "12. File incident report with relevant authorities",
                ],
                "contacts": ["CISO", "Security Team", "Management", "Legal"],
                "tools": ["Offline backup storage", "Key vault", "agri-secure incident-response"],
            },
            "hardware_failure": {
                "scenario": "Hardware / Infrastructure Failure",
                "severity": "high",
                "rto_hours": 2,
                "rpo_hours": 1,
                "steps": [
                    "1. Confirm hardware failure with infrastructure team",
                    "2. Activate standby/replica database if available",
                    "3. If no replica: provision replacement hardware/VM",
                    "4. Restore from latest backup to new hardware",
                    "5. Update DNS/load balancer to point to new instance",
                    "6. Verify application connectivity",
                    "7. Monitor performance for 1 hour",
                ],
                "contacts": ["Infrastructure Team", "DBA Team"],
                "tools": ["Cloud console", "agri-secure backup restore"],
            },
            "cloud_outage": {
                "scenario": "Cloud Provider Outage",
                "severity": "high",
                "rto_hours": 4,
                "rpo_hours": 6,
                "steps": [
                    "1. Confirm outage on cloud provider status page",
                    "2. Activate cross-region failover if configured",
                    "3. If no failover: restore from cross-region backup",
                    "4. Update application configuration for new region",
                    "5. Communicate status to users",
                    "6. Monitor recovery progress",
                ],
                "contacts": ["Infrastructure Team", "Management"],
                "tools": ["Cloud provider console", "Cross-region backups"],
            },
            "deployment_failure": {
                "scenario": "Failed Application Deployment",
                "severity": "medium",
                "rto_hours": 1,
                "rpo_hours": 0,
                "steps": [
                    "1. Identify the failing deployment",
                    "2. Roll back to the previous version: git revert / docker rollback",
                    "3. If database migration was applied: run rollback migration",
                    "4. Verify application health after rollback",
                    "5. Investigate root cause before re-deploying",
                ],
                "contacts": ["DevOps Team", "Development Team"],
                "tools": ["CI/CD pipeline", "Docker/Kubernetes rollback", "Alembic downgrade"],
            },
            "key_loss": {
                "scenario": "Encryption Key Loss",
                "severity": "critical",
                "rto_hours": 8,
                "rpo_hours": 0,
                "steps": [
                    "1. CRITICAL: Do NOT delete any encrypted data",
                    "2. Locate offline key backup (hardware security module or key escrow)",
                    "3. Restore key from backup to key vault",
                    "4. Verify decryption works on a test record",
                    "5. If key is unrecoverable: data encrypted with that key is LOST",
                    "6. Rotate to new key for all future operations",
                    "7. Re-encrypt any data that can be recovered from plaintext sources",
                    "8. Implement key escrow to prevent future key loss",
                ],
                "contacts": ["CISO", "Security Team", "Key Custodians"],
                "tools": ["HSM", "Key vault", "agri-secure key-rotation"],
            },
        }

        if scenario not in runbooks:
            return {
                "error": f"Unknown scenario: {scenario}",
                "available_scenarios": list(runbooks.keys()),
            }

        return runbooks[scenario]

    def generate_runbook_report(self, output_path: Optional[str] = None) -> str:
        """
        Generate a full recovery runbook report in Markdown format.

        Args:
            output_path: Optional file path to save the report

        Returns:
            Markdown string
        """
        scenarios = [
            "database_corruption", "ransomware", "hardware_failure",
            "cloud_outage", "deployment_failure", "key_loss",
        ]
        lines = [
            "# Agri-Secure Disaster Recovery Runbook",
            f"\nGenerated: {datetime.utcnow().isoformat()} UTC",
            "\n---\n",
            "## Recovery Objectives",
            "| Metric | Target |",
            "|--------|--------|",
            "| RTO (Recovery Time Objective) | < 4 hours |",
            "| RPO (Recovery Point Objective) | < 1 hour |",
            "\n---\n",
        ]

        for scenario_key in scenarios:
            rb = self.get_recovery_runbook(scenario_key)
            lines += [
                f"## {rb['scenario']}",
                f"**Severity:** {rb['severity'].upper()}  ",
                f"**RTO:** {rb['rto_hours']} hour(s)  ",
                f"**RPO:** {rb['rpo_hours']} hour(s)  ",
                "\n### Steps",
            ]
            for step in rb["steps"]:
                lines.append(f"- {step}")
            lines += [
                "\n### Contacts",
                ", ".join(rb["contacts"]),
                "\n### Tools",
                ", ".join(rb["tools"]),
                "\n---\n",
            ]

        report = "\n".join(lines)

        if output_path:
            Path(output_path).write_text(report)
            logger.info(f"Recovery runbook saved to: {output_path}")

        return report

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _decrypt_backup(self, path: Path, tmpdir: str) -> Path:
        if not self.encryption_engine:
            raise RecoveryError("Backup is encrypted but no encryption engine provided")
        encrypted = path.read_text()
        plain = self.encryption_engine.decrypt(encrypted, context="backup")
        out_path = Path(tmpdir) / path.stem  # Remove .enc
        out_path.write_bytes(plain.encode("latin-1"))
        return out_path

    @staticmethod
    def _decompress_backup(path: Path, tmpdir: str) -> Path:
        out_name = path.name.replace(".gz", "")
        out_path = Path(tmpdir) / out_name
        with gzip.open(path, "rb") as f_in, open(out_path, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
        return out_path

    @staticmethod
    def _validate_sql_file(path: Path) -> None:
        """Basic SQL file validation — check it starts with expected SQL content."""
        with open(path, "r", errors="replace") as f:
            header = f.read(512)
        if not any(kw in header.upper() for kw in ("CREATE", "INSERT", "BEGIN", "--", "PRAGMA")):
            raise RecoveryError(
                "Backup file does not appear to be a valid SQL dump"
            )

    def _restore_to_database(self, sql_path: Path, db_type: str) -> None:
        if db_type == "postgresql":
            cmd = ["psql", self.database_url, "-f", str(sql_path)]
        elif db_type == "mysql":
            cmd = ["mysql", self.database_url, "<", str(sql_path)]
        elif db_type == "sqlite":
            db_path = self.database_url.replace("sqlite:///", "")
            cmd = ["sqlite3", db_path, f".read {sql_path}"]
        else:
            raise RecoveryError(f"Restore not supported for db_type: {db_type}")

        result = subprocess.run(cmd, capture_output=True, timeout=3600)
        if result.returncode != 0:
            raise RecoveryError(
                f"Database restore failed: {result.stderr.decode()}"
            )

    def _verify_system_health(self) -> Dict[str, Any]:
        """Run basic health checks after restore."""
        checks = {
            "database_connection": False,
            "backup_system": False,
        }
        try:
            # Attempt a simple DB connection check
            if hasattr(self.backup, "health_check"):
                bh = self.backup.health_check()
                checks["backup_system"] = bh.get("healthy", False)
            checks["database_connection"] = True  # If we got here, DB is accessible
        except Exception as exc:
            logger.warning(f"Post-restore health check warning: {exc}")

        checks["healthy"] = all(checks.values())
        return checks

    def _log_recovery_event(
        self, event: str, manifest: Dict[str, Any], error: Optional[str] = None
    ) -> None:
        entry = {
            "event": event,
            "timestamp": datetime.utcnow().isoformat(),
            "filename": manifest.get("filename"),
            "error": error,
        }
        self._recovery_log.append(entry)
        log_path = Path("recovery_events.jsonl")
        with open(log_path, "a") as f:
            f.write(json.dumps(entry) + "\n")

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict[str, Any]:
        """Return health status of the recovery plan module."""
        backups = self.backup.list_backups()
        last_full = next((b for b in backups if b.get("type") == "full"), None)
        last_inc = next((b for b in backups if b.get("type") == "incremental"), None)

        rpo_ok = False
        if last_inc:
            try:
                last_time = datetime.fromisoformat(last_inc["created_at"])
                rpo_ok = (datetime.utcnow() - last_time) < timedelta(hours=1)
            except Exception:
                pass

        return {
            "module": "RecoveryPlan",
            "total_backups": len(backups),
            "last_full_backup": last_full.get("created_at") if last_full else None,
            "last_incremental_backup": last_inc.get("created_at") if last_inc else None,
            "rpo_within_1_hour": rpo_ok,
            "encryption_available": self.encryption_engine is not None,
            "healthy": len(backups) > 0,
        }
