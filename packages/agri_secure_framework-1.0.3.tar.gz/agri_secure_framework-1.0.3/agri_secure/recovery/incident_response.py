"""
incident_response.py - Incident Response Plan (IRP) for agricultural data security incidents.

Implements NIST SP 800-61 Computer Security Incident Handling Guide:
  - Preparation
  - Detection & Analysis
  - Containment, Eradication & Recovery
  - Post-Incident Activity

Provides:
  - Incident classification and severity scoring
  - Automated containment actions (account lockout, IP block, session revocation)
  - Evidence collection and preservation
  - Notification workflows
  - Incident timeline tracking
  - Post-incident report generation
"""

import json
import logging
import os
import platform
import socket
import threading
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class IncidentSeverity(str, Enum):
    """NIST-aligned incident severity levels"""
    CRITICAL = "critical"   # Active breach, data exfiltration, ransomware
    HIGH = "high"           # Suspected breach, privilege escalation
    MEDIUM = "medium"       # Policy violation, brute-force attack
    LOW = "low"             # Anomalous activity, failed intrusion attempt
    INFORMATIONAL = "informational"  # Security event, no immediate threat


class IncidentStatus(str, Enum):
    """Incident lifecycle status"""
    OPEN = "open"
    INVESTIGATING = "investigating"
    CONTAINED = "contained"
    ERADICATED = "eradicated"
    RECOVERED = "recovered"
    CLOSED = "closed"


class IncidentCategory(str, Enum):
    """NIST incident categories"""
    UNAUTHORIZED_ACCESS = "unauthorized_access"
    DENIAL_OF_SERVICE = "denial_of_service"
    MALWARE = "malware"
    DATA_BREACH = "data_breach"
    INSIDER_THREAT = "insider_threat"
    PHISHING = "phishing"
    BRUTE_FORCE = "brute_force"
    SQL_INJECTION = "sql_injection"
    CSRF_ATTACK = "csrf_attack"
    FILE_UPLOAD_ATTACK = "file_upload_attack"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    CRYPTOGRAPHIC_FAILURE = "cryptographic_failure"
    CONFIGURATION_ERROR = "configuration_error"
    POLICY_VIOLATION = "policy_violation"
    OTHER = "other"


class IncidentResponsePlan:
    """
    Automated Incident Response Plan following NIST SP 800-61.

    Features:
        - Incident creation, classification, and tracking
        - Automated containment actions (lock accounts, block IPs, revoke sessions)
        - Evidence collection (logs, system state, network info)
        - Notification to security team and management
        - Incident timeline with immutable audit trail
        - Post-incident report generation
        - Integration with brute-force protection and authentication modules

    Usage::

        irp = IncidentResponsePlan(
            incident_dir="incidents",
            notification_email="security@agri.example.com",
        )

        # Detect and open an incident
        incident = irp.open_incident(
            title="Multiple failed login attempts from single IP",
            category=IncidentCategory.BRUTE_FORCE,
            severity=IncidentSeverity.MEDIUM,
            affected_users=["john.farmer"],
            source_ip="1.2.3.4",
            evidence={"failed_attempts": 50, "time_window_minutes": 5},
        )

        # Contain the threat
        irp.contain_incident(incident["id"], actions=["block_ip", "lock_accounts"])

        # Close with report
        irp.close_incident(incident["id"], resolution="IP blocked, accounts unlocked after review")
    """

    def __init__(
        self,
        incident_dir: str = "incidents",
        notification_email: Optional[str] = None,
        notification_webhook: Optional[str] = None,
        auto_contain: bool = True,
        brute_force_protection=None,    # BruteForceProtection instance
        authenticator=None,             # AgriculturalAuthenticator instance
        retention_days: int = 365,
    ):
        """
        Args:
            incident_dir: Directory for incident records
            notification_email: Email for security alerts
            notification_webhook: Webhook URL for Slack/Teams notifications
            auto_contain: Automatically apply containment actions on CRITICAL/HIGH incidents
            brute_force_protection: BruteForceProtection instance for account lockout
            authenticator: AgriculturalAuthenticator instance for session revocation
            retention_days: Keep incident records for this many days
        """
        self.incident_dir = Path(incident_dir)
        self.notification_email = notification_email
        self.notification_webhook = notification_webhook
        self.auto_contain = auto_contain
        self.brute_force = brute_force_protection
        self.authenticator = authenticator
        self.retention_days = retention_days

        self.incident_dir.mkdir(parents=True, exist_ok=True)
        (self.incident_dir / "active").mkdir(exist_ok=True)
        (self.incident_dir / "closed").mkdir(exist_ok=True)
        (self.incident_dir / "evidence").mkdir(exist_ok=True)

        self._lock = threading.Lock()
        self._containment_handlers: Dict[str, Callable] = {}
        self._register_default_handlers()

        logger.info(
            f"IncidentResponsePlan initialized | dir={incident_dir} "
            f"auto_contain={auto_contain}"
        )

    # ------------------------------------------------------------------
    # Incident lifecycle
    # ------------------------------------------------------------------

    def open_incident(
        self,
        title: str,
        category: IncidentCategory,
        severity: IncidentSeverity,
        description: str = "",
        affected_users: Optional[List[str]] = None,
        affected_systems: Optional[List[str]] = None,
        source_ip: Optional[str] = None,
        evidence: Optional[Dict[str, Any]] = None,
        reported_by: str = "system",
    ) -> Dict[str, Any]:
        """
        Open a new security incident.

        Args:
            title: Short incident title
            category: Incident category (IncidentCategory enum)
            severity: Incident severity (IncidentSeverity enum)
            description: Detailed description
            affected_users: List of affected user IDs
            affected_systems: List of affected system names
            source_ip: Attacker/source IP address
            evidence: Dict of evidence data
            reported_by: Who/what reported the incident

        Returns:
            Incident record dict with id, status, and all metadata
        """
        incident_id = self._generate_id()
        now = datetime.utcnow()

        incident: Dict[str, Any] = {
            "id": incident_id,
            "title": title,
            "category": category.value if isinstance(category, IncidentCategory) else category,
            "severity": severity.value if isinstance(severity, IncidentSeverity) else severity,
            "status": IncidentStatus.OPEN.value,
            "description": description,
            "affected_users": affected_users or [],
            "affected_systems": affected_systems or [],
            "source_ip": source_ip,
            "evidence": evidence or {},
            "reported_by": reported_by,
            "opened_at": now.isoformat(),
            "updated_at": now.isoformat(),
            "timeline": [
                {
                    "timestamp": now.isoformat(),
                    "action": "incident_opened",
                    "actor": reported_by,
                    "details": f"Incident opened: {title}",
                }
            ],
            "containment_actions": [],
            "notifications_sent": [],
        }

        self._save_incident(incident)

        logger.warning(
            f"SECURITY INCIDENT OPENED | id={incident_id} | "
            f"severity={incident['severity']} | category={incident['category']} | "
            f"title={title}"
        )

        # Auto-contain critical and high severity incidents
        if self.auto_contain and incident["severity"] in (
            IncidentSeverity.CRITICAL.value, IncidentSeverity.HIGH.value
        ):
            self._auto_contain(incident)

        # Send notifications
        self._notify(incident)

        return incident

    def update_incident(
        self,
        incident_id: str,
        status: Optional[IncidentStatus] = None,
        notes: str = "",
        actor: str = "system",
        evidence: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing incident.

        Args:
            incident_id: Incident ID
            status: New status (optional)
            notes: Update notes
            actor: Who is making the update
            evidence: Additional evidence to append

        Returns:
            Updated incident record
        """
        incident = self._load_incident(incident_id)
        now = datetime.utcnow()

        if status:
            old_status = incident["status"]
            incident["status"] = status.value if isinstance(status, IncidentStatus) else status
            incident["timeline"].append({
                "timestamp": now.isoformat(),
                "action": "status_changed",
                "actor": actor,
                "details": f"Status changed: {old_status} → {incident['status']}",
            })

        if notes:
            incident["timeline"].append({
                "timestamp": now.isoformat(),
                "action": "notes_added",
                "actor": actor,
                "details": notes,
            })

        if evidence:
            incident["evidence"].update(evidence)

        incident["updated_at"] = now.isoformat()
        self._save_incident(incident)
        return incident

    def contain_incident(
        self,
        incident_id: str,
        actions: Optional[List[str]] = None,
        actor: str = "security_team",
    ) -> Dict[str, Any]:
        """
        Apply containment actions to an incident.

        Available actions:
            - block_ip: Block the source IP via BruteForceProtection
            - lock_accounts: Lock all affected user accounts
            - revoke_sessions: Revoke all active sessions for affected users
            - isolate_system: Mark affected systems as isolated (manual action required)
            - rotate_keys: Trigger encryption key rotation

        Args:
            incident_id: Incident ID
            actions: List of action names to apply
            actor: Who is applying containment

        Returns:
            Updated incident record with containment results
        """
        incident = self._load_incident(incident_id)
        actions = actions or self._recommend_containment(incident)
        results = []

        for action in actions:
            handler = self._containment_handlers.get(action)
            if handler:
                try:
                    result = handler(incident)
                    results.append({"action": action, "status": "applied", "result": result})
                    logger.info(f"Containment action applied: {action} | incident={incident_id}")
                except Exception as exc:
                    results.append({"action": action, "status": "failed", "error": str(exc)})
                    logger.error(f"Containment action failed: {action} | {exc}")
            else:
                results.append({"action": action, "status": "manual_required"})

        incident["containment_actions"].extend(results)
        incident["timeline"].append({
            "timestamp": datetime.utcnow().isoformat(),
            "action": "containment_applied",
            "actor": actor,
            "details": f"Containment actions: {[r['action'] for r in results]}",
        })
        incident["status"] = IncidentStatus.CONTAINED.value
        incident["updated_at"] = datetime.utcnow().isoformat()
        self._save_incident(incident)
        return incident

    def close_incident(
        self,
        incident_id: str,
        resolution: str,
        root_cause: str = "",
        lessons_learned: str = "",
        actor: str = "security_team",
    ) -> Dict[str, Any]:
        """
        Close an incident and generate a post-incident report.

        Args:
            incident_id: Incident ID
            resolution: How the incident was resolved
            root_cause: Root cause analysis
            lessons_learned: Lessons learned and recommendations
            actor: Who is closing the incident

        Returns:
            Closed incident record with post-incident report
        """
        incident = self._load_incident(incident_id)
        now = datetime.utcnow()

        opened_at = datetime.fromisoformat(incident["opened_at"])
        duration = now - opened_at

        incident["status"] = IncidentStatus.CLOSED.value
        incident["closed_at"] = now.isoformat()
        incident["resolution"] = resolution
        incident["root_cause"] = root_cause
        incident["lessons_learned"] = lessons_learned
        incident["duration_hours"] = round(duration.total_seconds() / 3600, 2)
        incident["updated_at"] = now.isoformat()
        incident["timeline"].append({
            "timestamp": now.isoformat(),
            "action": "incident_closed",
            "actor": actor,
            "details": f"Resolution: {resolution}",
        })

        # Move to closed directory
        active_path = self.incident_dir / "active" / f"{incident_id}.json"
        closed_path = self.incident_dir / "closed" / f"{incident_id}.json"
        if active_path.exists():
            active_path.rename(closed_path)
        else:
            self._save_incident(incident, directory="closed")

        logger.info(
            f"Incident closed: {incident_id} | duration={incident['duration_hours']}h | "
            f"resolution={resolution[:80]}"
        )
        return incident

    # ------------------------------------------------------------------
    # Evidence collection
    # ------------------------------------------------------------------

    def collect_evidence(self, incident_id: str) -> Dict[str, Any]:
        """
        Collect system evidence for an incident.

        Gathers: system info, environment variables (sanitised), network info,
        running processes, and recent log entries.

        Args:
            incident_id: Incident ID

        Returns:
            Dict with collected evidence
        """
        evidence: Dict[str, Any] = {
            "collected_at": datetime.utcnow().isoformat(),
            "system": {
                "hostname": socket.gethostname(),
                "platform": platform.platform(),
                "python_version": platform.python_version(),
            },
            "environment": self._safe_env_snapshot(),
            "log_tail": self._collect_log_tail(),
        }

        # Save evidence file
        evidence_path = self.incident_dir / "evidence" / f"{incident_id}_evidence.json"
        evidence_path.write_text(json.dumps(evidence, indent=2))

        # Update incident
        incident = self._load_incident(incident_id)
        incident["evidence"]["system_snapshot"] = evidence_path.name
        incident["timeline"].append({
            "timestamp": datetime.utcnow().isoformat(),
            "action": "evidence_collected",
            "actor": "system",
            "details": f"System evidence saved to {evidence_path.name}",
        })
        self._save_incident(incident)

        logger.info(f"Evidence collected for incident {incident_id}")
        return evidence

    # ------------------------------------------------------------------
    # Reporting
    # ------------------------------------------------------------------

    def generate_report(self, incident_id: str) -> str:
        """
        Generate a Markdown post-incident report.

        Args:
            incident_id: Incident ID

        Returns:
            Markdown report string
        """
        incident = self._load_incident(incident_id)
        lines = [
            f"# Security Incident Report: {incident['id']}",
            f"\n**Title:** {incident['title']}",
            f"**Severity:** {incident['severity'].upper()}",
            f"**Category:** {incident['category']}",
            f"**Status:** {incident['status']}",
            f"**Opened:** {incident['opened_at']}",
            f"**Closed:** {incident.get('closed_at', 'N/A')}",
            f"**Duration:** {incident.get('duration_hours', 'N/A')} hours",
            "\n---\n",
            "## Description",
            incident.get("description", "N/A"),
            "\n## Affected Users",
            ", ".join(incident.get("affected_users", [])) or "None identified",
            "\n## Affected Systems",
            ", ".join(incident.get("affected_systems", [])) or "None identified",
            "\n## Source IP",
            incident.get("source_ip") or "Unknown",
            "\n## Containment Actions",
        ]

        for action in incident.get("containment_actions", []):
            lines.append(f"- **{action['action']}**: {action['status']}")

        lines += [
            "\n## Timeline",
        ]
        for event in incident.get("timeline", []):
            lines.append(
                f"- `{event['timestamp']}` [{event['action']}] {event['details']} "
                f"(by {event.get('actor', 'system')})"
            )

        lines += [
            "\n## Resolution",
            incident.get("resolution", "N/A"),
            "\n## Root Cause",
            incident.get("root_cause", "N/A"),
            "\n## Lessons Learned",
            incident.get("lessons_learned", "N/A"),
        ]

        return "\n".join(lines)

    def list_incidents(
        self,
        status: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """
        List incidents with optional filtering.

        Args:
            status: Filter by status (open, investigating, contained, closed)
            severity: Filter by severity (critical, high, medium, low)
            limit: Maximum number of incidents to return

        Returns:
            List of incident dicts sorted by opened_at (newest first)
        """
        incidents = []
        for directory in ("active", "closed"):
            for path in (self.incident_dir / directory).glob("*.json"):
                try:
                    incident = json.loads(path.read_text())
                    if status and incident.get("status") != status:
                        continue
                    if severity and incident.get("severity") != severity:
                        continue
                    incidents.append(incident)
                except Exception:
                    pass

        incidents.sort(key=lambda i: i.get("opened_at", ""), reverse=True)
        return incidents[:limit]

    # ------------------------------------------------------------------
    # Containment handlers
    # ------------------------------------------------------------------

    def _register_default_handlers(self) -> None:
        self._containment_handlers["block_ip"] = self._handle_block_ip
        self._containment_handlers["lock_accounts"] = self._handle_lock_accounts
        self._containment_handlers["revoke_sessions"] = self._handle_revoke_sessions
        self._containment_handlers["isolate_system"] = self._handle_isolate_system
        self._containment_handlers["rotate_keys"] = self._handle_rotate_keys

    def register_containment_handler(self, action: str, handler: Callable) -> None:
        """Register a custom containment action handler."""
        self._containment_handlers[action] = handler

    def _handle_block_ip(self, incident: Dict[str, Any]) -> str:
        ip = incident.get("source_ip")
        if not ip:
            return "No source IP to block"
        if self.brute_force:
            # Force-lock the IP by recording many failures
            for _ in range(self.brute_force.ip_max_attempts + 1):
                self.brute_force._record_ip_failure(ip, __import__("time").time())
            return f"IP {ip} blocked via BruteForceProtection"
        return f"IP {ip} — manual firewall rule required"

    def _handle_lock_accounts(self, incident: Dict[str, Any]) -> str:
        users = incident.get("affected_users", [])
        if not users:
            return "No affected users to lock"
        locked = []
        for user_id in users:
            if self.brute_force:
                # Force lockout by injecting failures
                for _ in range(self.brute_force.max_attempts + 1):
                    self.brute_force.record_failure(user_id, reason="incident_containment")
                locked.append(user_id)
        return f"Locked accounts: {locked}"

    def _handle_revoke_sessions(self, incident: Dict[str, Any]) -> str:
        users = incident.get("affected_users", [])
        if not users:
            return "No affected users"
        if self.authenticator and hasattr(self.authenticator, "revoke_all_sessions"):
            for user_id in users:
                try:
                    self.authenticator.revoke_all_sessions(user_id)
                except Exception:
                    pass
            return f"Sessions revoked for: {users}"
        return "Session revocation — manual action required (no authenticator configured)"

    def _handle_isolate_system(self, incident: Dict[str, Any]) -> str:
        systems = incident.get("affected_systems", [])
        return f"MANUAL ACTION REQUIRED: Isolate systems from network: {systems}"

    def _handle_rotate_keys(self, incident: Dict[str, Any]) -> str:
        return "MANUAL ACTION REQUIRED: Rotate encryption keys via agri-secure key-rotation"

    def _auto_contain(self, incident: Dict[str, Any]) -> None:
        """Automatically apply containment for critical/high incidents."""
        actions = self._recommend_containment(incident)
        try:
            self.contain_incident(incident["id"], actions=actions, actor="auto_response")
        except Exception as exc:
            logger.error(f"Auto-containment failed: {exc}")

    def _recommend_containment(self, incident: Dict[str, Any]) -> List[str]:
        """Recommend containment actions based on incident category."""
        category = incident.get("category", "")
        recommendations = {
            IncidentCategory.BRUTE_FORCE.value: ["block_ip", "lock_accounts"],
            IncidentCategory.UNAUTHORIZED_ACCESS.value: ["lock_accounts", "revoke_sessions"],
            IncidentCategory.DATA_BREACH.value: ["lock_accounts", "revoke_sessions", "rotate_keys"],
            IncidentCategory.MALWARE.value: ["isolate_system", "revoke_sessions"],
            IncidentCategory.SQL_INJECTION.value: ["block_ip"],
            IncidentCategory.CSRF_ATTACK.value: ["revoke_sessions"],
            IncidentCategory.FILE_UPLOAD_ATTACK.value: ["block_ip"],
            IncidentCategory.PRIVILEGE_ESCALATION.value: ["lock_accounts", "revoke_sessions"],
            IncidentCategory.CRYPTOGRAPHIC_FAILURE.value: ["rotate_keys"],
        }
        return recommendations.get(category, ["lock_accounts"])

    # ------------------------------------------------------------------
    # Notification
    # ------------------------------------------------------------------

    def _notify(self, incident: Dict[str, Any]) -> None:
        severity = incident.get("severity", "")
        if severity in (IncidentSeverity.CRITICAL.value, IncidentSeverity.HIGH.value):
            self._send_notification(incident)

    def _send_notification(self, incident: Dict[str, Any]) -> None:
        message = (
            f"[SECURITY ALERT] {incident['severity'].upper()} incident: "
            f"{incident['title']} | ID: {incident['id']}"
        )
        logger.critical(message)

        if self.notification_email:
            logger.info(f"Notification → {self.notification_email}: {message}")
            # In production: integrate with SendGrid / SES / SMTP

        if self.notification_webhook:
            try:
                import urllib.request
                payload = json.dumps({"text": message}).encode()
                req = urllib.request.Request(
                    self.notification_webhook,
                    data=payload,
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=5)
            except Exception as exc:
                logger.error(f"Webhook notification failed: {exc}")

        incident["notifications_sent"].append({
            "timestamp": datetime.utcnow().isoformat(),
            "channel": "email" if self.notification_email else "log",
            "message": message,
        })

    # ------------------------------------------------------------------
    # Storage helpers
    # ------------------------------------------------------------------

    def _save_incident(
        self, incident: Dict[str, Any], directory: str = "active"
    ) -> None:
        path = self.incident_dir / directory / f"{incident['id']}.json"
        path.write_text(json.dumps(incident, indent=2))

    def _load_incident(self, incident_id: str) -> Dict[str, Any]:
        for directory in ("active", "closed"):
            path = self.incident_dir / directory / f"{incident_id}.json"
            if path.exists():
                return json.loads(path.read_text())
        raise FileNotFoundError(f"Incident not found: {incident_id}")

    @staticmethod
    def _generate_id() -> str:
        import secrets
        ts = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        return f"INC-{ts}-{secrets.token_hex(4).upper()}"

    @staticmethod
    def _safe_env_snapshot() -> Dict[str, str]:
        """Collect environment variables, masking secrets."""
        sensitive_keys = {
            "password", "secret", "key", "token", "credential",
            "api_key", "private", "auth",
        }
        snapshot = {}
        for k, v in os.environ.items():
            if any(s in k.lower() for s in sensitive_keys):
                snapshot[k] = "***REDACTED***"
            else:
                snapshot[k] = v[:100]  # Truncate long values
        return snapshot

    @staticmethod
    def _collect_log_tail(log_file: str = "agri_secure.log", lines: int = 50) -> List[str]:
        """Collect the last N lines from the application log."""
        path = Path(log_file)
        if not path.exists():
            return []
        try:
            with open(path) as f:
                all_lines = f.readlines()
            return [l.rstrip() for l in all_lines[-lines:]]
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict[str, Any]:
        """Return health status of the incident response module."""
        active = list((self.incident_dir / "active").glob("*.json"))
        critical_open = sum(
            1 for p in active
            if json.loads(p.read_text()).get("severity") == IncidentSeverity.CRITICAL.value
        )
        return {
            "module": "IncidentResponsePlan",
            "incident_dir": str(self.incident_dir),
            "active_incidents": len(active),
            "critical_open_incidents": critical_open,
            "auto_contain_enabled": self.auto_contain,
            "notification_configured": bool(
                self.notification_email or self.notification_webhook
            ),
            "healthy": critical_open == 0,
        }
