"""
access_control.py - Production-grade Role-Based Access Control (RBAC) system
Implements NIST SP 800-53 Access Control guidelines with fine-grained permissions
"""

import json
import logging
import datetime
from typing import Dict, Any, Optional, List, Set, Union
from enum import Enum
from dataclasses import dataclass, field
import hashlib
import redis
import os

logger = logging.getLogger(__name__)

class AccessControlError(Exception):
    """Base exception for access control errors"""
    pass

class PermissionDenied(AccessControlError):
    """Raised when user lacks required permission"""
    pass

class RoleNotFound(AccessControlError):
    """Raised when role doesn't exist"""
    pass

class ResourceType(Enum):
    """Types of resources in the agricultural system"""
    FARM_DATA = "farm_data"
    FARMER_PROFILE = "farmer_profile"
    CROP_DATA = "crop_data"
    LIVESTOCK_DATA = "livestock_data"
    SOIL_DATA = "soil_data"
    WEATHER_DATA = "weather_data"
    MARKET_DATA = "market_data"
    EXTENSION_ADVICE = "extension_advice"
    RESEARCH_DATA = "research_data"
    AGGREGATED_STATS = "aggregated_stats"
    AUDIT_LOG = "audit_log"
    SYSTEM_CONFIG = "system_config"
    USER_ACCOUNT = "user_account"
    ROLE_DEFINITION = "role_definition"

class Action(Enum):
    """Actions that can be performed on resources"""
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    SHARE = "share"
    EXPORT = "export"
    APPROVE = "approve"
    REJECT = "reject"
    AUDIT = "audit"
    ADMIN = "admin"

class DataClassification(Enum):
    """Data sensitivity levels"""
    PUBLIC = "public"           # Anyone can view
    INTERNAL = "internal"        # Any authenticated user
    CONFIDENTIAL = "confidential" # Specific roles only
    RESTRICTED = "restricted"     # Named individuals only
    SECRET = "secret"            # Highest sensitivity

@dataclass
class Permission:
    """Fine-grained permission definition"""
    resource_type: ResourceType
    actions: Set[Action]
    conditions: Optional[Dict] = None
    data_classification: DataClassification = DataClassification.INTERNAL
    created_at: datetime.datetime = field(default_factory=datetime.datetime.utcnow)
    expires_at: Optional[datetime.datetime] = None

@dataclass
class Role:
    """Role definition with permissions"""
    name: str
    description: str
    permissions: List[Permission]
    parent_roles: List[str] = field(default_factory=list)
    created_at: datetime.datetime = field(default_factory=datetime.datetime.utcnow)
    updated_at: datetime.datetime = field(default_factory=datetime.datetime.utcnow)
    is_system_role: bool = False

class AgriculturalAccessControl:
    """
    Enterprise-grade Role-Based Access Control system.
    
    Features:
        - Fine-grained permissions
        - Role hierarchy (inheritance)
        - Attribute-based conditions
        - Data classification levels
        - Policy caching
        - Audit logging
        - Time-based access
        - Geographic restrictions
    """
    
    def __init__(
        self,
        cache_ttl: int = 3600,
        redis_url: Optional[str] = None,
        enable_audit: bool = True,
        enable_hierarchy: bool = True,
        policy_enforcement_point: str = "strict"  # strict, permissive
    ):
        """
        Initialize access control system.
        
        Args:
            cache_ttl: Cache TTL in seconds
            redis_url: Redis URL for caching
            enable_audit: Enable audit logging
            enable_hierarchy: Enable role inheritance
            policy_enforcement_point: PEP mode (strict/permissive)
        """
        self.cache_ttl = cache_ttl
        self.enable_audit = enable_audit
        self.enable_hierarchy = enable_hierarchy
        self.policy_enforcement_point = policy_enforcement_point
        
        # Redis cache
        self.redis_client = None
        if redis_url:
            try:
                self.redis_client = redis.from_url(redis_url, decode_responses=True)
                logger.info("Connected to Redis for access control cache")
            except Exception as e:
                logger.error(f"Failed to connect to Redis: {e}")
        
        # In-memory storage
        self._roles = {}  # role_name -> Role
        self._user_roles = {}  # user_id -> [role_names]
        self._resource_policies = {}  # resource_id -> policy
        self._permission_cache = {}  # cache_key -> bool
        
        # Initialize system roles
        self._init_system_roles()
        
        logger.info("Access control system initialized")
    
    def _init_system_roles(self):
        """Initialize built-in system roles"""
        
        # Farmer role - can manage own data only
        farmer_permissions = [
            Permission(
                resource_type=ResourceType.FARM_DATA,
                actions={Action.CREATE, Action.READ, Action.UPDATE, Action.DELETE, Action.SHARE},
                conditions={"owner": "${user_id}"},
                data_classification=DataClassification.CONFIDENTIAL
            ),
            Permission(
                resource_type=ResourceType.FARMER_PROFILE,
                actions={Action.READ, Action.UPDATE},
                conditions={"owner": "${user_id}"},
                data_classification=DataClassification.RESTRICTED
            ),
            Permission(
                resource_type=ResourceType.AGGREGATED_STATS,
                actions={Action.READ},
                data_classification=DataClassification.PUBLIC
            ),
            Permission(
                resource_type=ResourceType.WEATHER_DATA,
                actions={Action.READ},
                data_classification=DataClassification.PUBLIC
            ),
            Permission(
                resource_type=ResourceType.MARKET_DATA,
                actions={Action.READ},
                data_classification=DataClassification.PUBLIC
            )
        ]
        
        self._roles["farmer"] = Role(
            name="farmer",
            description="Individual farmer who owns and manages their farm data",
            permissions=farmer_permissions,
            is_system_role=True
        )
        
        # Extension Officer role - helps multiple farmers
        extension_permissions = [
            Permission(
                resource_type=ResourceType.FARM_DATA,
                actions={Action.READ, Action.UPDATE, Action.CREATE},
                conditions={"assigned_district": "${user.district}"},
                data_classification=DataClassification.CONFIDENTIAL
            ),
            Permission(
                resource_type=ResourceType.FARMER_PROFILE,
                actions={Action.READ},
                conditions={"assigned_district": "${user.district}"},
                data_classification=DataClassification.RESTRICTED
            ),
            Permission(
                resource_type=ResourceType.EXTENSION_ADVICE,
                actions={Action.CREATE, Action.READ, Action.UPDATE},
                conditions={"recipient_district": "${user.district}"}
            ),
            Permission(
                resource_type=ResourceType.AGGREGATED_STATS,
                actions={Action.READ, Action.CREATE},
                data_classification=DataClassification.INTERNAL
            ),
            Permission(
                resource_type=ResourceType.CROP_DATA,
                actions={Action.READ},
                conditions={"district": "${user.district}"}
            )
        ]
        
        self._roles["extension_officer"] = Role(
            name="extension_officer",
            description="Agricultural extension officer providing advisory services",
            permissions=extension_permissions,
            parent_roles=["farmer"],
            is_system_role=True
        )
        
        # Ministry Official role - oversight and policy
        ministry_permissions = [
            Permission(
                resource_type=ResourceType.FARM_DATA,
                actions={Action.READ, Action.EXPORT},
                conditions={"anonymized": True},
                data_classification=DataClassification.INTERNAL
            ),
            Permission(
                resource_type=ResourceType.AGGREGATED_STATS,
                actions={Action.CREATE, Action.READ, Action.UPDATE, Action.EXPORT},
                data_classification=DataClassification.INTERNAL
            ),
            Permission(
                resource_type=ResourceType.AUDIT_LOG,
                actions={Action.READ, Action.AUDIT},
                data_classification=DataClassification.RESTRICTED
            ),
            Permission(
                resource_type=ResourceType.SYSTEM_CONFIG,
                actions={Action.READ, Action.UPDATE},
                data_classification=DataClassification.RESTRICTED
            ),
            Permission(
                resource_type=ResourceType.USER_ACCOUNT,
                actions={Action.READ, Action.UPDATE},
                conditions={"role": {"$in": ["farmer", "extension_officer"]}}
            )
        ]
        
        self._roles["ministry_official"] = Role(
            name="ministry_official",
            description="Ministry of Agriculture official",
            permissions=ministry_permissions,
            parent_roles=["extension_officer"],
            is_system_role=True
        )
        
        # Researcher role - academic research
        researcher_permissions = [
            Permission(
                resource_type=ResourceType.FARM_DATA,
                actions={Action.READ},
                conditions={"anonymized": True, "research_approved": True},
                data_classification=DataClassification.CONFIDENTIAL
            ),
            Permission(
                resource_type=ResourceType.AGGREGATED_STATS,
                actions={Action.READ, Action.EXPORT},
                data_classification=DataClassification.INTERNAL
            ),
            Permission(
                resource_type=ResourceType.RESEARCH_DATA,
                actions={Action.CREATE, Action.READ, Action.UPDATE},
                conditions={"researcher_id": "${user_id}"}
            )
        ]
        
        self._roles["researcher"] = Role(
            name="researcher",
            description="Agricultural researcher",
            permissions=researcher_permissions,
            is_system_role=True
        )
        
        # System Admin role - full access
        admin_permissions = [
            Permission(
                resource_type=ResourceType.SYSTEM_CONFIG,
                actions={Action.CREATE, Action.READ, Action.UPDATE, Action.DELETE, Action.ADMIN},
                data_classification=DataClassification.SECRET
            ),
            Permission(
                resource_type=ResourceType.USER_ACCOUNT,
                actions={Action.CREATE, Action.READ, Action.UPDATE, Action.DELETE, Action.ADMIN},
                data_classification=DataClassification.RESTRICTED
            ),
            Permission(
                resource_type=ResourceType.ROLE_DEFINITION,
                actions={Action.CREATE, Action.READ, Action.UPDATE, Action.DELETE},
                data_classification=DataClassification.SECRET
            ),
            Permission(
                resource_type=ResourceType.AUDIT_LOG,
                actions={Action.READ, Action.AUDIT, Action.EXPORT},
                data_classification=DataClassification.RESTRICTED
            )
        ]
        
        self._roles["system_admin"] = Role(
            name="system_admin",
            description="System administrator",
            permissions=admin_permissions,
            is_system_role=True
        )
        
        # Auditor role - read-only access to logs
        auditor_permissions = [
            Permission(
                resource_type=ResourceType.AUDIT_LOG,
                actions={Action.READ, Action.AUDIT, Action.EXPORT},
                data_classification=DataClassification.RESTRICTED
            ),
            Permission(
                resource_type=ResourceType.USER_ACCOUNT,
                actions={Action.READ},
                data_classification=DataClassification.CONFIDENTIAL
            )
        ]
        
        self._roles["auditor"] = Role(
            name="auditor",
            description="Security auditor",
            permissions=auditor_permissions,
            is_system_role=True
        )
        
        logger.info(f"Initialized {len(self._roles)} system roles")
    
    def check_permission(
        self,
        user_role: str,
        resource_type: Union[str, ResourceType],
        action: Union[str, Action],
        resource_owner: Optional[str] = None,
        current_user: Optional[str] = None,
        resource_attributes: Optional[Dict] = None,
        context: Optional[Dict] = None
    ) -> bool:
        """
        Check if user has permission to perform action on resource.
        
        Args:
            user_role: Role of user
            resource_type: Type of resource
            action: Action to perform
            resource_owner: Owner of resource (for ownership checks)
            current_user: Current user ID
            resource_attributes: Additional resource attributes
            context: Request context (time, location, etc.)
        
        Returns:
            True if allowed, False otherwise
        """
        # Convert string enums if needed
        if isinstance(resource_type, str):
            try:
                resource_type = ResourceType(resource_type)
            except ValueError:
                logger.error(f"Invalid resource type: {resource_type}")
                return False
        
        if isinstance(action, str):
            try:
                action = Action(action)
            except ValueError:
                logger.error(f"Invalid action: {action}")
                return False
        
        # Create cache key
        cache_key = self._create_cache_key(
            user_role, resource_type.value, action.value,
            resource_owner, current_user, str(resource_attributes)
        )
        
        # Check cache
        if cache_key in self._permission_cache:
            logger.debug(f"Cache hit for permission check: {cache_key}")
            return self._permission_cache[cache_key]
        
        if self.redis_client:
            cached = self.redis_client.get(f"perm:{cache_key}")
            if cached:
                result = cached == "true"
                self._permission_cache[cache_key] = result
                return result
        
        # Get role
        role = self._get_role(user_role)
        if not role:
            logger.error(f"Role not found: {user_role}")
            return False
        
        # Get all permissions including inherited
        all_permissions = self._get_all_permissions(role)
        
        # Check each permission
        allowed = False
        for permission in all_permissions:
            if permission.resource_type != resource_type:
                continue
            
            if action not in permission.actions:
                continue
            
            # Check conditions
            if permission.conditions:
                if not self._evaluate_conditions(
                    permission.conditions,
                    resource_owner=resource_owner,
                    current_user=current_user,
                    resource_attributes=resource_attributes,
                    context=context
                ):
                    continue
            
            # Check data classification
            if not self._check_classification(
                permission.data_classification,
                user_role,
                resource_attributes
            ):
                continue
            
            # Check expiry
            if permission.expires_at:
                if permission.expires_at < datetime.datetime.utcnow():
                    continue
            
            allowed = True
            break
        
        # Cache result
        self._permission_cache[cache_key] = allowed
        if self.redis_client:
            self.redis_client.setex(
                f"perm:{cache_key}",
                self.cache_ttl,
                "true" if allowed else "false"
            )
        
        # Audit log
        if self.enable_audit:
            self._log_access_check(
                user_role=user_role,
                resource_type=resource_type.value,
                action=action.value,
                resource_owner=resource_owner,
                current_user=current_user,
                allowed=allowed
            )
        
        logger.debug(
            f"Permission check: {user_role} {action.value} {resource_type.value} = {allowed}"
        )
        
        return allowed
    
    def assert_permission(
        self,
        user_role: str,
        resource_type: Union[str, ResourceType],
        action: Union[str, Action],
        resource_owner: Optional[str] = None,
        current_user: Optional[str] = None,
        resource_attributes: Optional[Dict] = None,
        context: Optional[Dict] = None
    ):
        """
        Assert that user has permission, raise PermissionDenied if not.
        
        Raises:
            PermissionDenied: If user doesn't have permission
        """
        if not self.check_permission(
            user_role, resource_type, action,
            resource_owner, current_user,
            resource_attributes, context
        ):
            raise PermissionDenied(
                f"{user_role} does not have {action} permission on {resource_type}"
            )
    
    def add_custom_role(
        self,
        name: str,
        description: str,
        permissions: List[Dict],
        parent_roles: Optional[List[str]] = None
    ) -> Role:
        """
        Add a custom role.
        
        Args:
            name: Role name
            description: Role description
            permissions: List of permission dictionaries
            parent_roles: List of parent role names
        
        Returns:
            Created Role object
        """
        # Validate parent roles
        if parent_roles:
            for parent in parent_roles:
                if parent not in self._roles:
                    raise RoleNotFound(f"Parent role not found: {parent}")
        
        # Convert permission dicts to Permission objects
        permission_objects = []
        for perm_dict in permissions:
            perm = Permission(
                resource_type=ResourceType(perm_dict["resource_type"]),
                actions={Action(a) for a in perm_dict["actions"]},
                conditions=perm_dict.get("conditions"),
                data_classification=DataClassification(
                    perm_dict.get("data_classification", "internal")
                )
            )
            permission_objects.append(perm)
        
        role = Role(
            name=name,
            description=description,
            permissions=permission_objects,
            parent_roles=parent_roles or [],
            is_system_role=False
        )
        
        self._roles[name] = role
        logger.info(f"Added custom role: {name}")
        
        return role
    
    def assign_role(self, user_id: str, role_name: str):
        """Assign a role to a user"""
        if role_name not in self._roles:
            raise RoleNotFound(f"Role not found: {role_name}")
        
        if user_id not in self._user_roles:
            self._user_roles[user_id] = []
        
        if role_name not in self._user_roles[user_id]:
            self._user_roles[user_id].append(role_name)
            logger.info(f"Assigned role {role_name} to user {user_id}")
    
    def remove_role(self, user_id: str, role_name: str):
        """Remove a role from a user"""
        if user_id in self._user_roles and role_name in self._user_roles[user_id]:
            self._user_roles[user_id].remove(role_name)
            logger.info(f"Removed role {role_name} from user {user_id}")
    
    def get_user_roles(self, user_id: str) -> List[str]:
        """Get all roles assigned to a user"""
        return self._user_roles.get(user_id, [])
    
    def _get_role(self, role_name: str) -> Optional[Role]:
        """Get role by name"""
        return self._roles.get(role_name)
    
    def _get_all_permissions(self, role: Role) -> List[Permission]:
        """Get all permissions including inherited"""
        all_permissions = list(role.permissions)
        
        if self.enable_hierarchy and role.parent_roles:
            for parent_name in role.parent_roles:
                parent = self._get_role(parent_name)
                if parent:
                    all_permissions.extend(self._get_all_permissions(parent))
        
        return all_permissions
    
    def _evaluate_conditions(
        self,
        conditions: Dict,
        resource_owner: Optional[str] = None,
        current_user: Optional[str] = None,
        resource_attributes: Optional[Dict] = None,
        context: Optional[Dict] = None
    ) -> bool:
        """Evaluate permission conditions"""
        try:
            # Simple condition evaluation
            # In production, use a proper expression evaluator
            for key, value in conditions.items():
                if key == "owner":
                    if resource_owner != current_user:
                        return False
                
                elif key == "assigned_district":
                    if not context or context.get("district") != value:
                        return False
                
                elif key == "anonymized":
                    if not resource_attributes or not resource_attributes.get("anonymized"):
                        return False
                
                elif key == "research_approved":
                    if not resource_attributes or not resource_attributes.get("research_approved"):
                        return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error evaluating conditions: {e}")
            return False
    
    def _check_classification(
        self,
        classification: DataClassification,
        user_role: str,
        resource_attributes: Optional[Dict]
    ) -> bool:
        """Check if user can access data at this classification level"""
        # Public data - anyone can access
        if classification == DataClassification.PUBLIC:
            return True
        
        # Internal data - any authenticated user
        if classification == DataClassification.INTERNAL:
            return user_role in self._roles
        
        # Confidential - specific roles only
        if classification == DataClassification.CONFIDENTIAL:
            return user_role in ["farmer", "extension_officer", "ministry_official"]
        
        # Restricted - named individuals or special roles
        if classification == DataClassification.RESTRICTED:
            return user_role in ["ministry_official", "system_admin", "auditor"]
        
        # Secret - admin only
        if classification == DataClassification.SECRET:
            return user_role == "system_admin"
        
        return False
    
    def _create_cache_key(self, *args) -> str:
        """Create cache key from arguments"""
        key_string = ":".join(str(arg) for arg in args if arg is not None)
        return hashlib.sha256(key_string.encode()).hexdigest()
    
    def _log_access_check(
        self,
        user_role: str,
        resource_type: str,
        action: str,
        resource_owner: Optional[str],
        current_user: Optional[str],
        allowed: bool
    ):
        """Log access check for audit"""
        log_entry = {
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "event_type": "access_check",
            "user_role": user_role,
            "resource_type": resource_type,
            "action": action,
            "resource_owner": resource_owner,
            "current_user": current_user,
            "allowed": allowed
        }
        
        # In production, send to audit system
        logger.info(f"Access audit: {json.dumps(log_entry)}")
    
    def create_resource_policy(
        self,
        resource_id: str,
        resource_type: ResourceType,
        owner: str,
        classification: DataClassification,
        custom_rules: Optional[Dict] = None
    ):
        """Create a policy for a specific resource"""
        self._resource_policies[resource_id] = {
            "resource_id": resource_id,
            "resource_type": resource_type.value,
            "owner": owner,
            "classification": classification.value,
            "custom_rules": custom_rules or {},
            "created_at": datetime.datetime.utcnow().isoformat()
        }
    
    def get_resource_policy(self, resource_id: str) -> Optional[Dict]:
        """Get policy for a resource"""
        return self._resource_policies.get(resource_id)
    
    def list_roles(self) -> List[Dict]:
        """List all available roles"""
        roles = []
        for name, role in self._roles.items():
            roles.append({
                "name": role.name,
                "description": role.description,
                "parent_roles": role.parent_roles,
                "is_system_role": role.is_system_role,
                "permission_count": len(role.permissions)
            })
        return roles
    
    def health_check(self) -> Dict[str, Any]:
        """Health check for access control system"""
        health = {
            "status": "healthy",
            "roles_count": len(self._roles),
            "user_assignments": len(self._user_roles),
            "cache_size": len(self._permission_cache),
            "policy_enforcement_point": self.policy_enforcement_point,
            "enable_hierarchy": self.enable_hierarchy
        }
        
        # Check Redis
        if self.redis_client:
            try:
                self.redis_client.ping()
                health["redis"] = "connected"
            except Exception:
                health["redis"] = "disconnected"
                health["status"] = "degraded"
        
        return health

# Export enums for easy access
__all__ = [
    "AgriculturalAccessControl",
    "ResourceType",
    "Action",
    "DataClassification",
    "Permission",
    "Role",
    "AccessControlError",
    "PermissionDenied",
    "RoleNotFound"
]