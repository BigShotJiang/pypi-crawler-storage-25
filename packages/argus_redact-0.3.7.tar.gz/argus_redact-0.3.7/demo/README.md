---
title: argus-redact
emoji: 🔐
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: "4.44.0"
python_version: "3.12"
app_file: app.py
pinned: false
license: apache-2.0
---

# argus-redact — The privacy layer between you and AI.

~47 PII types, 8 languages, PRvL Gold, PII leak 0% across GPT-4o/Claude/Gemini.

- **GitHub**: https://github.com/wan9yu/argus-redact
- **PyPI**: `pip install argus-redact`
