from foxange.input import collect_input

a:list = collect_input("test1>","test2>")

print(a)