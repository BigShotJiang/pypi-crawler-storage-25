# Integration modules for popular ML frameworks.
# Each module must be imported explicitly -- no framework code is imported here.
#
# Available integrations:
#   openrunner.integration.pytorch     - PyTorch gradient logging
#   openrunner.integration.huggingface - HuggingFace Transformers TrainerCallback
#   openrunner.integration.lightning   - PyTorch Lightning Logger
#   openrunner.integration.keras       - Keras / TensorFlow Callback
#   openrunner.integration.xgboost     - XGBoost TrainingCallback
#   openrunner.integration.sklearn     - Scikit-learn utility functions
#   openrunner.integration.fastai      - FastAI Callback
#   openrunner.integration.langchain   - LangChain CallbackHandler
