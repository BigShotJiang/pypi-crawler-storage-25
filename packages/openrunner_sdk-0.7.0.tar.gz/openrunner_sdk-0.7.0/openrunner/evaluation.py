"""LLM evaluation framework -- scorers, datasets, evaluation runs.

Provides the ``@scorer`` decorator and ``evaluate()`` function for
running structured evaluations of model functions against datasets.

Usage::

    import openrunner

    @openrunner.scorer
    def accuracy_scorer(output, expected):
        return {"score": 1.0 if output == expected else 0.0}

    results = openrunner.evaluate(
        model=my_model,
        dataset=[{"input": "2+2?", "expected": "4"}],
        scorers=[accuracy_scorer],
        project="eval-project",
        name="gpt4-eval-v1",
    )
    print(results.summary)
"""

from __future__ import annotations

import functools
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, TypeVar

logger = logging.getLogger("openrunner")

F = TypeVar("F", bound=Callable[..., Any])

# ---------------------------------------------------------------------------
# Scorer decorator
# ---------------------------------------------------------------------------

_SCORER_ATTR = "_openrunner_scorer"


def scorer(func: F) -> F:
    """Decorator that marks a function as an evaluation scorer.

    A scorer function must accept ``(output, expected)`` and return a
    dict with at least a ``"score"`` key (float 0.0-1.0).

    Can be used with or without parentheses::

        @openrunner.scorer
        def my_scorer(output, expected):
            return {"score": 1.0 if output == expected else 0.0}
    """
    setattr(func, _SCORER_ATTR, True)

    @functools.wraps(func)
    def wrapper(output: Any, expected: Any) -> dict[str, Any]:
        result = func(output, expected)
        if not isinstance(result, dict) or "score" not in result:
            raise ValueError(
                f"Scorer '{func.__name__}' must return a dict with a 'score' key, "
                f"got: {result!r}"
            )
        return result

    # Preserve the scorer marker on the wrapper
    setattr(wrapper, _SCORER_ATTR, True)
    return wrapper  # type: ignore[return-value]


def is_scorer(func: Any) -> bool:
    """Check if a function is decorated with @scorer."""
    return getattr(func, _SCORER_ATTR, False) is True


# ---------------------------------------------------------------------------
# EvalResult
# ---------------------------------------------------------------------------


@dataclass
class EvalResult:
    """Result of an evaluation run.

    Attributes:
        summary: Mean score per scorer, keyed as ``scorer_name.score``.
        table: List of dicts with columns: input, expected, output, and
               one column per scorer (``scorer_name.score``).
        scores: List of per-row score dicts (one dict per dataset row,
                containing scorer name -> score value mappings).
        name: Name of the evaluation run.
        project: Project name.
        dataset_hash: SHA-256 hash of the serialized dataset for dedup.
    """

    summary: dict[str, float] = field(default_factory=dict)
    table: list[dict[str, Any]] = field(default_factory=list)
    scores: list[dict[str, float]] = field(default_factory=list)
    name: str = ""
    project: str = ""
    dataset_hash: str = ""


# ---------------------------------------------------------------------------
# evaluate()
# ---------------------------------------------------------------------------


def _hash_dataset(dataset: list[dict[str, Any]]) -> str:
    """Compute a stable SHA-256 hash of the dataset for deduplication."""
    serialized = json.dumps(dataset, sort_keys=True, default=str)
    return hashlib.sha256(serialized.encode()).hexdigest()[:16]


def evaluate(
    model: Callable[..., Any],
    dataset: list[dict[str, Any]],
    scorers: list[Callable[..., dict[str, Any]]],
    project: str = "uncategorized",
    name: str = "eval",
    **kwargs: Any,
) -> EvalResult:
    """Run an evaluation of a model function against a dataset.

    For each row in the dataset, calls ``model(input)`` and then runs
    each scorer against the output and expected value. Collects results
    into an ``EvalResult`` with summary statistics, a results table,
    and per-row scores.

    Args:
        model: Callable that accepts an input string and returns output.
        dataset: List of dicts, each with ``"input"`` and ``"expected"`` keys.
        scorers: List of scorer functions (decorated with ``@scorer`` or
                 plain functions returning ``{"score": float}``).
        project: Project name for grouping evaluations.
        name: Name for this evaluation run.

    Returns:
        EvalResult with summary, table, and scores.
    """
    if not dataset:
        logger.warning("evaluate(): empty dataset, returning empty result")
        return EvalResult(name=name, project=project)

    if not scorers:
        logger.warning("evaluate(): no scorers provided, returning empty result")
        return EvalResult(name=name, project=project)

    dataset_hash = _hash_dataset(dataset)

    table: list[dict[str, Any]] = []
    all_scores: list[dict[str, float]] = []

    # Accumulate totals for mean computation
    scorer_totals: dict[str, float] = {}
    scorer_names = [s.__name__ for s in scorers]
    for sname in scorer_names:
        scorer_totals[f"{sname}.score"] = 0.0

    for row_idx, row in enumerate(dataset):
        input_val = row.get("input", "")
        expected_val = row.get("expected", "")

        # Call model
        try:
            output_val = model(input_val)
        except Exception as e:
            logger.warning(
                "evaluate(): model raised %s on row %d: %s",
                type(e).__name__,
                row_idx,
                e,
            )
            output_val = f"ERROR: {e}"

        # Run scorers
        row_scores: dict[str, float] = {}
        row_result: dict[str, Any] = {
            "input": input_val,
            "expected": expected_val,
            "output": output_val,
        }

        for scorer_fn in scorers:
            sname = scorer_fn.__name__
            try:
                score_result = scorer_fn(output_val, expected_val)
                score_val = float(score_result.get("score", 0.0))
            except Exception as e:
                logger.warning(
                    "evaluate(): scorer '%s' raised %s on row %d: %s",
                    sname,
                    type(e).__name__,
                    row_idx,
                    e,
                )
                score_val = 0.0

            key = f"{sname}.score"
            row_scores[key] = score_val
            row_result[key] = score_val
            scorer_totals[key] += score_val

        table.append(row_result)
        all_scores.append(row_scores)

    # Compute summary (mean per scorer)
    n = len(dataset)
    summary = {k: v / n for k, v in scorer_totals.items()}

    # Log results via SDK if there is an active run
    _log_eval_results(project, name, summary, table, scorer_names, dataset_hash)

    return EvalResult(
        summary=summary,
        table=table,
        scores=all_scores,
        name=name,
        project=project,
        dataset_hash=dataset_hash,
    )


def _log_eval_results(
    project: str,
    name: str,
    summary: dict[str, float],
    table: list[dict[str, Any]],
    scorer_names: list[str],
    dataset_hash: str,
) -> None:
    """Log evaluation results to the server if an active run exists.

    Creates a run with group='evaluation', logs the results table and
    summary metrics. This is best-effort -- failures are logged but
    do not interrupt the evaluation.
    """
    try:
        import openrunner
        from openrunner.media import Table

        # Try to use existing active run or create a new one
        run = openrunner._active_run
        created_run = False

        if run is None:
            # Create a temporary run for evaluation results
            run = openrunner.init(
                project=project,
                name=name,
                group="evaluation",
                config={
                    "evaluation_name": name,
                    "dataset_hash": dataset_hash,
                    "scorer_names": scorer_names,
                },
            )
            created_run = True

        if run is not None:
            # Log summary metrics
            openrunner.log(summary)

            # Log the results as a Table
            columns = ["input", "expected", "output"] + [
                f"{s}.score" for s in scorer_names
            ]
            eval_table = Table(columns=columns, data=[
                [row.get(c, "") for c in columns] for row in table
            ])
            openrunner.log({"eval_results": eval_table})

            if created_run:
                openrunner.finish(quiet=True)

    except Exception as e:
        logger.debug("_log_eval_results failed: %s", e)
