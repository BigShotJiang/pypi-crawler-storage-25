"""Offline storage for JSONL-based local data persistence.

When OPENRUNNER_MODE=offline, the SDK writes metrics, config, summary,
and metadata to local files instead of sending them over HTTP. This
enables ML engineers to train without network connectivity.

File layout under base_dir / run_id /:
  meta.json       - Run metadata (project, name, tags, etc.)
  config.json     - Hyperparameter config (written at init time)
  metrics.jsonl   - Metric records, one JSON object per line (append)
  summary.json    - Summary snapshot (overwritten each time)
  .sync_position  - Byte offset for incremental sync
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger("openrunner")


class OfflineStorage:
    """JSONL file-based offline data persistence for a single run."""

    def __init__(self, run_id: str, base_dir: Path | None = None) -> None:
        self._base_dir = base_dir or (Path.home() / ".openrunner" / "offline")
        self._run_dir = self._base_dir / run_id
        self._run_dir.mkdir(parents=True, exist_ok=True)
        self._metrics_fh: Any = None  # lazy file handle

    # -- Write operations ----------------------------------------------------

    def write_meta(self, meta: dict[str, Any]) -> None:
        """Write run metadata to meta.json."""
        (self._run_dir / "meta.json").write_text(
            json.dumps(meta, default=str), encoding="utf-8"
        )

    def write_config(self, config: dict[str, Any]) -> None:
        """Write hyperparameter config to config.json.

        Called at init() time, NOT finish(). This fixes W&B's biggest
        offline bug where config was lost on crash.
        """
        (self._run_dir / "config.json").write_text(
            json.dumps(config, default=str), encoding="utf-8"
        )

    def append_metrics(self, records: list[dict[str, Any]]) -> None:
        """Append metric records as JSONL (one JSON object per line).

        Uses a lazy file handle opened in append mode. Flushes after
        each batch for crash safety.
        """
        if self._metrics_fh is None:
            self._metrics_fh = open(
                self._run_dir / "metrics.jsonl", "a", encoding="utf-8"
            )
        for record in records:
            self._metrics_fh.write(json.dumps(record, default=str) + "\n")
        self._metrics_fh.flush()

    def write_summary(self, summary: dict[str, Any]) -> None:
        """Write summary snapshot to summary.json (overwritten each time)."""
        (self._run_dir / "summary.json").write_text(
            json.dumps(summary, default=str), encoding="utf-8"
        )

    # -- Read operations -----------------------------------------------------

    def read_metrics(self) -> list[dict[str, Any]]:
        """Read all valid metric records from metrics.jsonl.

        Skips corrupt/incomplete lines (e.g., from a crash) gracefully.
        """
        metrics_file = self._run_dir / "metrics.jsonl"
        if not metrics_file.exists():
            return []
        records: list[dict[str, Any]] = []
        with open(metrics_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    logger.warning(
                        "Skipping corrupt JSONL line in %s", metrics_file
                    )
        return records

    # -- Sync position -------------------------------------------------------

    def get_sync_position(self) -> int:
        """Read the sync position (byte offset). Returns 0 if not set."""
        pos_file = self._run_dir / ".sync_position"
        if not pos_file.exists():
            return 0
        try:
            return int(pos_file.read_text().strip())
        except (ValueError, OSError):
            return 0

    def set_sync_position(self, pos: int) -> None:
        """Write the sync position (byte offset)."""
        (self._run_dir / ".sync_position").write_text(str(pos), encoding="utf-8")

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the metrics file handle if open."""
        if self._metrics_fh is not None:
            try:
                self._metrics_fh.flush()
                self._metrics_fh.close()
            except Exception:
                pass
            self._metrics_fh = None

    # -- Class methods -------------------------------------------------------

    @classmethod
    def list_offline_runs(cls, base_dir: Path | None = None) -> list[Path]:
        """Return list of run directories under base_dir."""
        base = base_dir or (Path.home() / ".openrunner" / "offline")
        if not base.exists():
            return []
        return [p for p in base.iterdir() if p.is_dir()]


class OfflineSync:
    """Sync an offline run directory to the server.

    Reads meta.json, config.json, metrics.jsonl, and summary.json from
    a run directory and uploads them to the server via APIClient.

    Sync is idempotent: a .sync_position file tracks byte offset into
    metrics.jsonl so re-running sync never re-sends already-synced data.
    """

    BATCH_SIZE = 500

    def __init__(self, run_dir: Path, client: Any) -> None:
        self._run_dir = Path(run_dir)
        self._client = client

    def sync(self) -> bool:
        """Sync the offline run to the server.

        Steps:
          1. Read meta.json and config.json.
          2. Create run on server (fall back to PATCH on failure/409).
          3. Read metrics.jsonl from .sync_position byte offset.
          4. Batch-send metrics, updating .sync_position after each batch.
          5. Send summary.json if present.

        Returns True on success, False on critical failure.
        """
        try:
            # Step 1: Read metadata and config
            meta = self._read_json("meta.json")
            if meta is None:
                logger.warning("No meta.json in %s, skipping sync", self._run_dir)
                return False

            config = self._read_json("config.json") or {}
            run_id = meta.get("id", self._run_dir.name)

            # Step 2: Create or update run
            create_data = {**meta, "config": config}
            result = self._client.create_run(create_data)
            if result is None:
                # Fall back to PATCH (run may already exist -- 409)
                self._client.update_run(run_id, {"config": config})

            # Step 3: Read and sync metrics from position
            self._sync_metrics(run_id)

            # Step 4: Send summary if present
            summary = self._read_json("summary.json")
            if summary is not None:
                self._client.update_run(run_id, {"summary": summary})

            return True
        except Exception:
            logger.exception("Sync failed for %s", self._run_dir)
            return False

    def _sync_metrics(self, run_id: str) -> None:
        """Read metrics.jsonl from sync position and send in batches."""
        metrics_file = self._run_dir / "metrics.jsonl"
        if not metrics_file.exists():
            return

        pos_file = self._run_dir / ".sync_position"
        position = 0
        if pos_file.exists():
            try:
                position = int(pos_file.read_text().strip())
            except (ValueError, OSError):
                position = 0

        with open(metrics_file, "rb") as f:
            f.seek(position)
            batch: list[dict[str, Any]] = []

            while True:
                line_bytes = f.readline()
                if not line_bytes:
                    break

                line = line_bytes.decode("utf-8").strip()
                if not line:
                    continue

                try:
                    record = json.loads(line)
                    batch.append(record)
                except json.JSONDecodeError:
                    logger.warning(
                        "Skipping corrupt JSONL line in %s", metrics_file
                    )
                    continue

                if len(batch) >= self.BATCH_SIZE:
                    self._client.sync_metrics(run_id, batch)
                    position = f.tell()
                    self._write_position(position)
                    batch = []

            # Send remaining batch
            if batch:
                self._client.sync_metrics(run_id, batch)
                position = f.tell()
                self._write_position(position)

        # Final position update even if no new data
        self._write_position(position)

    def _write_position(self, pos: int) -> None:
        """Write sync position to .sync_position file."""
        (self._run_dir / ".sync_position").write_text(
            str(pos), encoding="utf-8"
        )

    def _read_json(self, filename: str) -> dict[str, Any] | None:
        """Read a JSON file from the run directory, or return None."""
        filepath = self._run_dir / filename
        if not filepath.exists():
            return None
        try:
            return json.loads(filepath.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            logger.warning("Failed to read %s", filepath)
            return None
