"""SDK settings with env var cascade (OPENRUNNER_* -> OPENRUN_* -> WANDB_* -> defaults)."""

from __future__ import annotations

import os
from pathlib import Path


class SDKSettings:
    """SDK settings resolved from environment variables.

    Cascade order for each setting:
      1. OPENRUNNER_* env var
      2. OPENRUN_* env var (backward compatibility)
      3. WANDB_* env var (migration convenience)
      4. Built-in default
    """

    def __init__(self) -> None:
        self._api_key: str | None = None
        self._base_url: str | None = None
        self._project: str | None = None
        self._system_metrics_enabled: bool | None = None

    @property
    def api_key(self) -> str | None:
        """API key for authentication (OPENRUNNER_API_KEY -> OPENRUN_API_KEY -> WANDB_API_KEY)."""
        if self._api_key is not None:
            return self._api_key
        return (
            os.environ.get("OPENRUNNER_API_KEY")
            or os.environ.get("OPENRUN_API_KEY")
            or os.environ.get("WANDB_API_KEY")
        )

    @api_key.setter
    def api_key(self, value: str | None) -> None:
        self._api_key = value

    @property
    def base_url(self) -> str:
        """Server base URL (OPENRUNNER_BASE_URL -> OPENRUN_BASE_URL -> WANDB_BASE_URL -> http://localhost:8000)."""
        if self._base_url is not None:
            return self._base_url
        return (
            os.environ.get("OPENRUNNER_BASE_URL")
            or os.environ.get("OPENRUN_BASE_URL")
            or os.environ.get("WANDB_BASE_URL")
            or "http://localhost:8000"
        )

    @base_url.setter
    def base_url(self, value: str | None) -> None:
        self._base_url = value

    @property
    def project(self) -> str | None:
        """Project name (OPENRUNNER_PROJECT -> OPENRUN_PROJECT -> WANDB_PROJECT)."""
        if self._project is not None:
            return self._project
        return (
            os.environ.get("OPENRUNNER_PROJECT")
            or os.environ.get("OPENRUN_PROJECT")
            or os.environ.get("WANDB_PROJECT")
        )

    @project.setter
    def project(self, value: str | None) -> None:
        self._project = value

    @property
    def system_metrics_enabled(self) -> bool:
        """Whether to collect system metrics (OPENRUNNER_SYSTEM_METRICS -> OPENRUN_SYSTEM_METRICS -> default True)."""
        if self._system_metrics_enabled is not None:
            return self._system_metrics_enabled
        val = (
            os.environ.get("OPENRUNNER_SYSTEM_METRICS")
            or os.environ.get("OPENRUN_SYSTEM_METRICS")
            or "true"
        )
        return val.lower() in ("true", "1", "yes")

    @system_metrics_enabled.setter
    def system_metrics_enabled(self, value: bool) -> None:
        self._system_metrics_enabled = value

    @property
    def mode(self) -> str:
        """SDK mode: 'online' (default), 'offline', or 'disabled' (OPENRUNNER_MODE or OPENRUN_MODE env var).

        When mode is 'disabled', init() returns a no-op run that silently
        discards all log/finish/artifact calls without any network I/O.
        """
        return (
            os.environ.get("OPENRUNNER_MODE")
            or os.environ.get("OPENRUN_MODE")
            or "online"
        )

    @property
    def offline_dir(self) -> Path:
        """Directory for offline storage (OPENRUNNER_OFFLINE_DIR -> OPENRUN_OFFLINE_DIR -> ~/.openrunner/offline)."""
        return Path(
            os.environ.get("OPENRUNNER_OFFLINE_DIR")
            or os.environ.get(
                "OPENRUN_OFFLINE_DIR",
                str(Path.home() / ".openrunner" / "offline"),
            )
        )

    # ------------------------------------------------------------------
    # Run metadata env vars (W&B-compatible with OPENRUNNER_ precedence)
    # ------------------------------------------------------------------

    @property
    def name(self) -> str | None:
        """Run display name (OPENRUNNER_NAME -> WANDB_NAME)."""
        return os.environ.get("OPENRUNNER_NAME") or os.environ.get("WANDB_NAME")

    @property
    def tags(self) -> str | None:
        """Comma-separated tags (OPENRUNNER_TAGS -> WANDB_TAGS)."""
        return os.environ.get("OPENRUNNER_TAGS") or os.environ.get("WANDB_TAGS")

    @property
    def notes(self) -> str | None:
        """Run notes/description (OPENRUNNER_NOTES -> WANDB_NOTES)."""
        return os.environ.get("OPENRUNNER_NOTES") or os.environ.get("WANDB_NOTES")

    @property
    def run_group(self) -> str | None:
        """Run group name (OPENRUNNER_RUN_GROUP -> WANDB_RUN_GROUP)."""
        return os.environ.get("OPENRUNNER_RUN_GROUP") or os.environ.get("WANDB_RUN_GROUP")

    @property
    def job_type(self) -> str | None:
        """Job type label (OPENRUNNER_JOB_TYPE -> WANDB_JOB_TYPE)."""
        return os.environ.get("OPENRUNNER_JOB_TYPE") or os.environ.get("WANDB_JOB_TYPE")

    @property
    def run_id(self) -> str | None:
        """Custom run ID (OPENRUNNER_RUN_ID -> WANDB_RUN_ID)."""
        return os.environ.get("OPENRUNNER_RUN_ID") or os.environ.get("WANDB_RUN_ID")

    @property
    def entity(self) -> str | None:
        """Organization/entity slug (OPENRUNNER_ENTITY -> WANDB_ENTITY)."""
        return os.environ.get("OPENRUNNER_ENTITY") or os.environ.get("WANDB_ENTITY")

    @property
    def resume(self) -> str | None:
        """Resume mode (OPENRUNNER_RESUME -> WANDB_RESUME)."""
        return os.environ.get("OPENRUNNER_RESUME") or os.environ.get("WANDB_RESUME")

    # ------------------------------------------------------------------
    # Behavior env vars
    # ------------------------------------------------------------------

    @property
    def silent(self) -> bool:
        """Suppress SDK output (OPENRUNNER_SILENT -> WANDB_SILENT). Default False."""
        val = os.environ.get("OPENRUNNER_SILENT") or os.environ.get("WANDB_SILENT") or "false"
        return val.lower() in ("true", "1", "yes")

    @property
    def console(self) -> str:
        """Console capture mode (OPENRUNNER_CONSOLE -> WANDB_CONSOLE). Values: auto/off/wrap. Default auto."""
        return (
            os.environ.get("OPENRUNNER_CONSOLE")
            or os.environ.get("WANDB_CONSOLE")
            or "auto"
        )

    @property
    def disable_git(self) -> bool:
        """Disable git info capture (OPENRUNNER_DISABLE_GIT -> WANDB_DISABLE_GIT). Default False."""
        val = os.environ.get("OPENRUNNER_DISABLE_GIT") or os.environ.get("WANDB_DISABLE_GIT") or "false"
        return val.lower() in ("true", "1", "yes")

    @property
    def disable_code(self) -> bool:
        """Disable code saving (OPENRUNNER_DISABLE_CODE -> WANDB_DISABLE_CODE). Default False."""
        val = os.environ.get("OPENRUNNER_DISABLE_CODE") or os.environ.get("WANDB_DISABLE_CODE") or "false"
        return val.lower() in ("true", "1", "yes")

    @property
    def dir(self) -> str | None:
        """Local log directory (OPENRUNNER_DIR -> WANDB_DIR)."""
        return os.environ.get("OPENRUNNER_DIR") or os.environ.get("WANDB_DIR")
