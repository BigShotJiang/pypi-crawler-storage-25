"""Media types for rich experiment logging.

Image wraps numpy arrays, PIL Images, or file paths for lazy PNG serialization.
Table wraps columnar data for structured logging.
Audio wraps numpy arrays, file paths, or bytes for WAV serialization.
Video wraps file paths or numpy arrays for video media.
Histogram computes bin edges/counts from numeric arrays.
Plotly wraps plotly.graph_objects.Figure for JSON serialization.
Embedding wraps (N, D) vectors for t-SNE/PCA/UMAP projection visualization.
BoundingBoxes2D overlays bounding box annotations on images.

Serialization is deferred to the sender thread to keep log() non-blocking.
"""

from __future__ import annotations

import io
import json
import struct
import wave
from pathlib import Path
from typing import Any


class Image:
    """An image for experiment logging.

    Accepts a numpy array, PIL Image, or file path (str/Path).
    Serialization to PNG bytes is lazy -- only called by the sender thread,
    not in the ``log()`` call, keeping the main thread non-blocking.
    """

    def __init__(self, data: Any, caption: str | None = None) -> None:
        self._data = data
        self.caption = caption

    def _serialize(self) -> tuple[bytes, str]:
        """Convert to image bytes. Returns (bytes, content_type).

        - File path (str/Path): read raw bytes, infer content type
        - PIL Image: save to BytesIO as PNG
        - numpy array: convert via PIL.Image.fromarray() then save as PNG
        """
        # File path
        if isinstance(self._data, (str, Path)):
            path = Path(self._data)
            raw = path.read_bytes()
            # Infer content type from extension
            suffix = path.suffix.lower()
            ct_map = {
                ".png": "image/png",
                ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg",
                ".gif": "image/gif",
                ".bmp": "image/bmp",
                ".webp": "image/webp",
            }
            content_type = ct_map.get(suffix, "image/png")
            return raw, content_type

        # PIL Image
        try:
            from PIL import Image as PILImage

            if isinstance(self._data, PILImage.Image):
                buf = io.BytesIO()
                self._data.save(buf, format="PNG")
                return buf.getvalue(), "image/png"
        except ImportError:
            pass

        # numpy array
        try:
            import numpy as np

            if isinstance(self._data, np.ndarray):
                from PIL import Image as PILImage

                arr = self._data
                # Handle float arrays: normalize 0-1 to 0-255 uint8
                if arr.dtype.kind == "f":
                    arr = (arr.clip(0.0, 1.0) * 255).astype(np.uint8)
                elif arr.dtype != np.uint8:
                    arr = arr.astype(np.uint8)

                # Handle grayscale (2D) vs RGB (3D)
                if arr.ndim == 2:
                    pil_img = PILImage.fromarray(arr, mode="L")
                elif arr.ndim == 3 and arr.shape[2] == 1:
                    pil_img = PILImage.fromarray(arr[:, :, 0], mode="L")
                elif arr.ndim == 3 and arr.shape[2] == 3:
                    pil_img = PILImage.fromarray(arr, mode="RGB")
                elif arr.ndim == 3 and arr.shape[2] == 4:
                    pil_img = PILImage.fromarray(arr, mode="RGBA")
                else:
                    pil_img = PILImage.fromarray(arr)

                buf = io.BytesIO()
                pil_img.save(buf, format="PNG")
                return buf.getvalue(), "image/png"
        except ImportError:
            pass

        raise TypeError(
            f"Image: unsupported data type {type(self._data).__name__}. "
            "Expected numpy array, PIL Image, or file path."
        )


class Table:
    """A table for structured data logging.

    Stores columnar data that is serialized inline as JSON (no S3 upload needed).
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        data: list[list[Any]] | None = None,
        dataframe: Any | None = None,
    ) -> None:
        if dataframe is not None:
            self.columns: list[str] = list(dataframe.columns)
            self._data: list[list[Any]] = dataframe.values.tolist()
        else:
            self.columns = columns or []
            self._data = data or []

    def add_data(self, *row: Any) -> None:
        """Add a row of data to the table."""
        self._data.append(list(row))

    def add_column(self, name: str, data: list) -> None:
        """Append a column to the table.

        Args:
            name: Column name
            data: Column values (must match number of rows)
        """
        if len(data) != len(self._data):
            raise ValueError(
                f"Column data length {len(data)} != row count {len(self._data)}"
            )
        self.columns.append(name)
        for i, val in enumerate(data):
            self._data[i].append(val)

    def get_column(self, name: str, convert_to: str | None = None) -> Any:
        """Retrieve a column's values.

        Args:
            name: Column name
            convert_to: Optional ``"numpy"`` to return a numpy array
        Returns:
            list or numpy array of column values
        """
        idx = self.columns.index(name)
        values = [row[idx] for row in self._data]
        if convert_to == "numpy":
            import numpy as np

            return np.array(values)
        return values

    def iterrows(self):
        """Iterate over rows as dicts."""
        for row in self._data:
            yield dict(zip(self.columns, row))

    @classmethod
    def from_dataframe(cls, df: Any) -> "Table":
        """Create a Table from a pandas DataFrame."""
        columns = list(df.columns)
        data = df.values.tolist()
        return cls(columns=columns, data=data)

    def _serialize(self) -> dict[str, Any]:
        """Serialize to a dict for JSON transmission."""
        return {"columns": self.columns, "data": self._data}


class Audio:
    """An audio clip for experiment logging.

    Accepts a numpy array (mono or stereo), file path (str/Path), or raw bytes.
    Serialization to WAV bytes is lazy -- only called by the sender thread.
    """

    def __init__(
        self,
        data: Any,
        caption: str | None = None,
        sample_rate: int = 44100,
    ) -> None:
        self._data = data
        self.caption = caption
        self.sample_rate = sample_rate

    def _serialize(self) -> tuple[bytes, str]:
        """Convert to WAV bytes. Returns (bytes, content_type).

        - File path (str/Path): read raw bytes, return as-is
        - bytes: return as-is (assumed WAV)
        - numpy array: encode as WAV (int16) via stdlib wave module
        """
        # File path
        if isinstance(self._data, (str, Path)):
            path = Path(self._data)
            raw = path.read_bytes()
            suffix = path.suffix.lower()
            ct_map = {
                ".wav": "audio/wav",
                ".mp3": "audio/mpeg",
                ".ogg": "audio/ogg",
                ".flac": "audio/flac",
            }
            content_type = ct_map.get(suffix, "audio/wav")
            return raw, content_type

        # Raw bytes
        if isinstance(self._data, (bytes, bytearray)):
            return bytes(self._data), "audio/wav"

        # numpy array
        try:
            import numpy as np

            if isinstance(self._data, np.ndarray):
                arr = self._data
                # Normalize float arrays to int16
                if arr.dtype.kind == "f":
                    arr = (arr.clip(-1.0, 1.0) * 32767).astype(np.int16)
                elif arr.dtype != np.int16:
                    arr = arr.astype(np.int16)

                # Determine channels: 1D = mono, 2D = (samples, channels)
                if arr.ndim == 1:
                    n_channels = 1
                    samples = arr
                elif arr.ndim == 2:
                    n_channels = arr.shape[1]
                    samples = arr.flatten()
                else:
                    raise ValueError(
                        f"Audio: expected 1D or 2D array, got {arr.ndim}D"
                    )

                buf = io.BytesIO()
                with wave.open(buf, "wb") as wf:
                    wf.setnchannels(n_channels)
                    wf.setsampwidth(2)  # 16-bit
                    wf.setframerate(self.sample_rate)
                    wf.writeframes(samples.tobytes())
                return buf.getvalue(), "audio/wav"
        except ImportError:
            pass

        raise TypeError(
            f"Audio: unsupported data type {type(self._data).__name__}. "
            "Expected numpy array, file path, or bytes."
        )


class Video:
    """A video for experiment logging.

    Accepts a file path (str/Path) for MP4/WebM files, or a numpy array
    with shape (T, H, W, C) which is stored as raw frames.
    """

    def __init__(
        self,
        data: Any,
        caption: str | None = None,
        fps: int = 30,
    ) -> None:
        self._data = data
        self.caption = caption
        self.fps = fps

    def _serialize(self) -> tuple[bytes, str]:
        """Convert to video bytes. Returns (bytes, content_type).

        - File path (str/Path): read raw bytes, infer content type
        - numpy array (T,H,W,C): encode frames to MP4 via imageio if available,
          otherwise store as raw frame data with metadata
        """
        # File path
        if isinstance(self._data, (str, Path)):
            path = Path(self._data)
            raw = path.read_bytes()
            suffix = path.suffix.lower()
            ct_map = {
                ".mp4": "video/mp4",
                ".webm": "video/webm",
                ".avi": "video/x-msvideo",
                ".mov": "video/quicktime",
            }
            content_type = ct_map.get(suffix, "video/mp4")
            return raw, content_type

        # numpy array (T, H, W, C)
        try:
            import numpy as np

            if isinstance(self._data, np.ndarray):
                arr = self._data
                if arr.ndim != 4:
                    raise ValueError(
                        f"Video: expected 4D array (T,H,W,C), got {arr.ndim}D"
                    )

                if arr.dtype.kind == "f":
                    arr = (arr.clip(0.0, 1.0) * 255).astype(np.uint8)
                elif arr.dtype != np.uint8:
                    arr = arr.astype(np.uint8)

                # Try imageio for MP4 encoding
                try:
                    import imageio.v3 as iio

                    buf = io.BytesIO()
                    iio.imwrite(
                        buf,
                        arr,
                        extension=".mp4",
                        plugin="pyav",
                        codec="libx264",
                        fps=self.fps,
                    )
                    return buf.getvalue(), "video/mp4"
                except (ImportError, Exception):
                    pass

                # Fallback: store as raw frame bundle (JSON metadata + raw bytes)
                # This allows the server to at least store the data
                meta = json.dumps({
                    "frames": arr.shape[0],
                    "height": arr.shape[1],
                    "width": arr.shape[2],
                    "channels": arr.shape[3],
                    "fps": self.fps,
                    "format": "raw_uint8",
                }).encode()
                meta_len = struct.pack("<I", len(meta))
                return meta_len + meta + arr.tobytes(), "application/octet-stream"
        except ImportError:
            pass

        raise TypeError(
            f"Video: unsupported data type {type(self._data).__name__}. "
            "Expected file path or numpy array (T,H,W,C)."
        )


class Histogram:
    """A histogram for numeric distribution logging.

    Accepts a list or numpy array of values. Computes bin edges and counts.
    Stores as JSON (no S3 upload needed).
    """

    def __init__(
        self,
        values: Any,
        num_bins: int = 64,
        caption: str | None = None,
    ) -> None:
        self._values = values
        self.num_bins = num_bins
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Compute histogram bins and counts. Returns dict for JSON."""
        try:
            import numpy as np

            arr = np.asarray(self._values, dtype=np.float64)
            arr = arr.ravel()
            # Remove NaN/Inf
            arr = arr[np.isfinite(arr)]

            if len(arr) == 0:
                return {
                    "bins": [],
                    "counts": [],
                    "num_bins": self.num_bins,
                }

            counts, bin_edges = np.histogram(arr, bins=self.num_bins)
            return {
                "bins": bin_edges.tolist(),
                "counts": counts.tolist(),
                "num_bins": self.num_bins,
                "min": float(arr.min()),
                "max": float(arr.max()),
                "mean": float(arr.mean()),
                "std": float(arr.std()),
                "count": int(len(arr)),
            }
        except ImportError:
            # Fallback without numpy: simple binning
            values = [float(v) for v in self._values if v is not None]
            values = [v for v in values if v == v and abs(v) != float("inf")]
            if not values:
                return {"bins": [], "counts": [], "num_bins": self.num_bins}

            mn, mx = min(values), max(values)
            if mn == mx:
                return {
                    "bins": [mn, mx + 1],
                    "counts": [len(values)],
                    "num_bins": self.num_bins,
                    "min": mn,
                    "max": mx,
                    "mean": mn,
                    "std": 0.0,
                    "count": len(values),
                }

            width = (mx - mn) / self.num_bins
            bins = [mn + i * width for i in range(self.num_bins + 1)]
            counts = [0] * self.num_bins
            for v in values:
                idx = min(int((v - mn) / width), self.num_bins - 1)
                counts[idx] += 1

            mean = sum(values) / len(values)
            std = (sum((v - mean) ** 2 for v in values) / len(values)) ** 0.5
            return {
                "bins": bins,
                "counts": counts,
                "num_bins": self.num_bins,
                "min": mn,
                "max": mx,
                "mean": mean,
                "std": std,
                "count": len(values),
            }


class Plotly:
    """A Plotly figure for interactive chart logging.

    Accepts a plotly.graph_objects.Figure. Serializes to JSON via fig.to_json().
    Stores as JSON (no S3 upload needed).
    """

    def __init__(
        self,
        figure: Any,
        caption: str | None = None,
    ) -> None:
        self._figure = figure
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize Plotly figure to dict. Returns dict for JSON."""
        # Try to use figure's built-in JSON serialization
        if hasattr(self._figure, "to_json"):
            json_str = self._figure.to_json()
            return json.loads(json_str)
        elif hasattr(self._figure, "to_dict"):
            return self._figure.to_dict()
        elif isinstance(self._figure, dict):
            return self._figure
        else:
            raise TypeError(
                f"Plotly: unsupported figure type {type(self._figure).__name__}. "
                "Expected plotly.graph_objects.Figure or dict."
            )


class MatplotlibFigure:
    """Capture a Matplotlib figure as a PNG image for experiment logging.

    Accepts an optional ``matplotlib.figure.Figure``.  When *fig* is ``None``
    the current active figure (``pyplot.gcf()``) is used, making the
    common pattern ``openrunner.log({"chart": openrunner.MatplotlibFigure()})``
    a one-liner.

    Serialization is lazy -- the PNG bytes are produced only when the sender
    thread calls ``_serialize()``.
    """

    def __init__(
        self,
        fig: Any | None = None,
        caption: str | None = None,
        dpi: int = 150,
    ) -> None:
        self._fig = fig
        self.caption = caption
        self.dpi = dpi

    def _serialize(self) -> tuple[bytes, str]:
        """Render figure to PNG bytes. Returns (bytes, content_type)."""
        import matplotlib.pyplot as plt  # lazy import

        fig = self._fig if self._fig is not None else plt.gcf()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=self.dpi, bbox_inches="tight")
        buf.seek(0)
        return buf.getvalue(), "image/png"


class PlotlyChart:
    """Enhanced Plotly figure that stores both interactive JSON and static PNG.

    Stores the full Plotly JSON for interactive rendering in the frontend,
    and optionally generates a static PNG fallback via ``fig.to_image()``
    (requires the ``kaleido`` package).

    Use ``Plotly`` for JSON-only storage, ``PlotlyChart`` when you also
    want a static image fallback.
    """

    def __init__(
        self,
        figure: Any,
        caption: str | None = None,
    ) -> None:
        self._figure = figure
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize Plotly figure to dict with optional static PNG.

        Returns a dict with keys:
        - ``data``, ``layout`` (standard Plotly JSON)
        - ``static_image`` (base64-encoded PNG string, or None if kaleido
          is not available)
        """
        import base64

        # Get the JSON representation
        if hasattr(self._figure, "to_json"):
            json_str = self._figure.to_json()
            result = json.loads(json_str)
        elif hasattr(self._figure, "to_dict"):
            result = self._figure.to_dict()
        elif isinstance(self._figure, dict):
            result = dict(self._figure)
        else:
            raise TypeError(
                f"PlotlyChart: unsupported figure type {type(self._figure).__name__}. "
                "Expected plotly.graph_objects.Figure or dict."
            )

        # Try to generate a static PNG fallback
        static_image: str | None = None
        if hasattr(self._figure, "to_image"):
            try:
                png_bytes = self._figure.to_image(format="png", width=800, height=500)
                static_image = base64.b64encode(png_bytes).decode("ascii")
            except Exception:
                pass  # kaleido not installed or failed -- skip

        result["_static_image"] = static_image
        return result


class PointCloud3D:
    """A 3D point cloud for experiment logging.

    Accepts XYZ coordinates as a numpy array of shape (N, 3), with optional
    per-point RGB colors and string labels.  Data is serialized inline as
    JSON (no S3 upload needed).

    Usage::

        pts = np.random.randn(1000, 3)
        colors = np.random.randint(0, 255, (1000, 3))
        openrunner.log({"cloud": openrunner.PointCloud3D(pts, colors=colors)})
    """

    def __init__(
        self,
        points: Any,
        colors: Any | None = None,
        labels: list[str] | None = None,
        caption: str | None = None,
    ) -> None:
        self._points = points
        self._colors = colors
        self._labels = labels
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize point cloud data to dict for JSON transmission.

        Returns a dict with:
        - ``points``: list of [x, y, z] lists
        - ``colors``: list of [r, g, b] lists (or None)
        - ``labels``: list of strings (or None)
        - ``num_points``: total point count
        - ``bounds``: {min: [x,y,z], max: [x,y,z]}
        """
        import numpy as np

        pts = np.asarray(self._points, dtype=np.float64)
        if pts.ndim != 2 or pts.shape[1] != 3:
            raise ValueError(
                f"PointCloud3D: expected array of shape (N, 3), "
                f"got {pts.shape}"
            )

        result: dict[str, Any] = {
            "points": pts.tolist(),
            "num_points": int(pts.shape[0]),
        }

        # Bounds for frontend camera setup
        if pts.shape[0] > 0:
            result["bounds"] = {
                "min": pts.min(axis=0).tolist(),
                "max": pts.max(axis=0).tolist(),
            }
        else:
            result["bounds"] = {"min": [0, 0, 0], "max": [0, 0, 0]}

        # Colors
        if self._colors is not None:
            clr = np.asarray(self._colors)
            if clr.shape != pts.shape:
                raise ValueError(
                    f"PointCloud3D: colors shape {clr.shape} does not match "
                    f"points shape {pts.shape}"
                )
            # Normalize float colors (0-1) to int (0-255)
            if clr.dtype.kind == "f":
                clr = (clr.clip(0.0, 1.0) * 255).astype(np.uint8)
            result["colors"] = clr.tolist()
        else:
            result["colors"] = None

        # Labels
        if self._labels is not None:
            if len(self._labels) != pts.shape[0]:
                raise ValueError(
                    f"PointCloud3D: labels length {len(self._labels)} does not "
                    f"match points count {pts.shape[0]}"
                )
            result["labels"] = list(self._labels)
        else:
            result["labels"] = None

        return result


class Html:
    """Raw HTML content for rich experiment logging.

    Accepts an HTML string which is stored inline as JSONB (no S3 upload needed).
    Useful for custom reports, formatted output, or embedded visualizations.
    """

    def __init__(
        self,
        data: str,
        caption: str | None = None,
    ) -> None:
        self._data = data
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize to a dict for JSON transmission."""
        result: dict[str, Any] = {"html": self._data}
        if self.caption is not None:
            result["caption"] = self.caption
        return result


class Embedding:
    """An embedding projection for experiment logging.

    Accepts an (N, D) array of vectors (N points in D dimensions) with optional
    per-point labels and metadata columns.  Data is serialized inline as JSON
    (no S3 upload needed), following the same pattern as Table.

    Usage::

        vecs = np.random.randn(200, 128)
        labels = ["cat"] * 100 + ["dog"] * 100
        openrunner.log({"emb": openrunner.Embedding(vecs, labels=labels)})
    """

    def __init__(
        self,
        vectors: Any,
        labels: list[str] | None = None,
        metadata: dict[str, list[Any]] | None = None,
        caption: str | None = None,
    ) -> None:
        self._vectors = vectors
        self._labels = labels
        self._metadata = metadata
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize embedding data to dict for JSON transmission.

        Returns a dict with:
        - ``vectors``: list of lists (N x D)
        - ``labels``: list of strings (or None)
        - ``metadata``: dict of lists (or None)
        - ``dim``: dimensionality D
        - ``count``: number of points N
        """
        import numpy as np

        vecs = np.asarray(self._vectors, dtype=np.float64)
        if vecs.ndim != 2:
            raise ValueError(
                f"Embedding: expected 2D array (N, D), got {vecs.ndim}D"
            )

        n, d = vecs.shape

        # Validate labels length
        if self._labels is not None:
            if len(self._labels) != n:
                raise ValueError(
                    f"Embedding: labels length {len(self._labels)} does not "
                    f"match vector count {n}"
                )

        # Validate metadata column lengths
        if self._metadata is not None:
            for col_name, col_values in self._metadata.items():
                if len(col_values) != n:
                    raise ValueError(
                        f"Embedding: metadata column '{col_name}' length "
                        f"{len(col_values)} does not match vector count {n}"
                    )

        result: dict[str, Any] = {
            "vectors": vecs.tolist(),
            "dim": int(d),
            "count": int(n),
        }

        result["labels"] = list(self._labels) if self._labels is not None else None

        if self._metadata is not None:
            result["metadata"] = {
                k: list(v) for k, v in self._metadata.items()
            }
        else:
            result["metadata"] = None

        return result


class BoundingBoxes2D:
    """Bounding box annotations overlaid on an image.

    Accepts an Image and a list of bounding box dicts with format:
    {
        "position": {"minX": float, "minY": float, "maxX": float, "maxY": float},
        "class_id": int,  # optional
        "scores": {"confidence": float},  # optional
    }
    Stores image reference + box data as JSON.
    """

    def __init__(
        self,
        image: Image,
        boxes: list[dict[str, Any]],
        class_labels: dict[int, str] | None = None,
        caption: str | None = None,
    ) -> None:
        self._image = image
        self._boxes = boxes
        self.class_labels = class_labels or {}
        self.caption = caption

    def _serialize_image(self) -> tuple[bytes, str]:
        """Serialize the underlying image. Returns (bytes, content_type)."""
        return self._image._serialize()

    def _serialize_boxes(self) -> dict[str, Any]:
        """Serialize bounding box data to dict for JSON."""
        return {
            "boxes": self._boxes,
            "class_labels": self.class_labels,
        }
