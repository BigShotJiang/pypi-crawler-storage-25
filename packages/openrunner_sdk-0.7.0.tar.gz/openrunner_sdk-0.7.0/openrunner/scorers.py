"""Built-in scorers for LLM evaluation.

Provides common scoring functions that can be used directly with
``openrunner.evaluate()`` or composed into custom scorers.

Usage::

    import openrunner
    from openrunner.scorers import exact_match, contains, json_valid, length_ratio

    results = openrunner.evaluate(
        model=my_model,
        dataset=dataset,
        scorers=[exact_match, contains],
    )
"""

from __future__ import annotations

import json
from typing import Any

from openrunner.evaluation import scorer


@scorer
def exact_match(output: Any, expected: Any) -> dict[str, float]:
    """Score 1.0 if output exactly equals expected, 0.0 otherwise.

    Both values are compared as strings after stripping whitespace.
    """
    out_str = str(output).strip()
    exp_str = str(expected).strip()
    return {"score": 1.0 if out_str == exp_str else 0.0}


@scorer
def contains(output: Any, expected: Any) -> dict[str, float]:
    """Score 1.0 if expected is a substring of output, 0.0 otherwise.

    Case-insensitive comparison after stripping whitespace.
    """
    out_str = str(output).strip().lower()
    exp_str = str(expected).strip().lower()
    return {"score": 1.0 if exp_str in out_str else 0.0}


@scorer
def json_valid(output: Any, expected: Any) -> dict[str, float]:
    """Score 1.0 if output is valid JSON, 0.0 otherwise.

    The ``expected`` argument is ignored -- this scorer only checks
    whether the output parses as valid JSON.
    """
    try:
        json.loads(str(output))
        return {"score": 1.0}
    except (json.JSONDecodeError, TypeError, ValueError):
        return {"score": 0.0}


@scorer
def length_ratio(output: Any, expected: Any) -> dict[str, float]:
    """Score based on the ratio of output length to expected length.

    Returns min(len(output) / len(expected), 1.0), so outputs that are
    at least as long as expected score 1.0. Returns 0.0 if expected is
    empty to avoid division by zero.
    """
    out_len = len(str(output))
    exp_len = len(str(expected))
    if exp_len == 0:
        return {"score": 0.0}
    return {"score": min(out_len / exp_len, 1.0)}
