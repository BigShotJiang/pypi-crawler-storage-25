"""OpenRunner CLI - ML experiment tracking command-line interface.

Commands:
  login  - Authenticate and store API key
  sync   - Upload offline training runs to server
  ls     - List projects and runs
  sweep  - Hyperparameter sweep commands (create, agent)
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import click

from openrunner.api_client import APIClient
from openrunner.offline import OfflineStorage, OfflineSync

logger = logging.getLogger("openrunner")


# ---------------------------------------------------------------------------
# Settings helpers
# ---------------------------------------------------------------------------


def _settings_dir() -> Path:
    """Return the OpenRunner settings directory (~/.openrunner)."""
    return Path.home() / ".openrunner"


def _load_settings() -> dict[str, Any]:
    """Load settings from ~/.openrunner/settings.json."""
    settings_file = _settings_dir() / "settings.json"
    if not settings_file.exists():
        return {}
    try:
        return json.loads(settings_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _save_settings(settings: dict[str, Any]) -> None:
    """Save settings to ~/.openrunner/settings.json."""
    d = _settings_dir()
    d.mkdir(parents=True, exist_ok=True)
    (d / "settings.json").write_text(
        json.dumps(settings, indent=2), encoding="utf-8"
    )


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------


@click.group()
def main() -> None:
    """OpenRunner CLI - ML experiment tracking."""
    pass


# ---------------------------------------------------------------------------
# login command
# ---------------------------------------------------------------------------


@main.command()
def login() -> None:
    """Authenticate and store API key in ~/.openrunner/settings.json."""
    settings = _load_settings()

    api_key = click.prompt("API Key", hide_input=True)
    base_url = click.prompt(
        "Server URL", default="http://localhost:8000"
    )

    settings["api_key"] = api_key
    settings["base_url"] = base_url
    _save_settings(settings)

    settings_path = _settings_dir() / "settings.json"
    click.echo(f"Login successful. API key stored at {settings_path}")


# ---------------------------------------------------------------------------
# sync command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("path", required=False)
@click.option("--all", "sync_all", is_flag=True, help="Sync all offline runs")
def sync(path: str | None, sync_all: bool) -> None:
    """Upload offline training runs to the server.

    Provide a PATH to sync a specific run directory, or use --all to
    discover and sync all offline runs.
    """
    settings = _load_settings()
    api_key = settings.get("api_key")
    base_url = settings.get("base_url", "http://localhost:8000")

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    client = APIClient(base_url=base_url, api_key=api_key)

    run_dirs: list[Path] = []

    if sync_all:
        run_dirs = OfflineStorage.list_offline_runs()
    elif path:
        run_dirs = [Path(path)]
    else:
        click.echo("Error: Provide a path or use --all.", err=True)
        raise SystemExit(1)

    if not run_dirs:
        click.echo("No offline runs found.")
        return

    total = len(run_dirs)
    synced = 0

    for run_dir in run_dirs:
        run_id = run_dir.name
        click.echo(f"Syncing run {run_id}... ", nl=False)
        try:
            syncer = OfflineSync(run_dir, client)
            if syncer.sync():
                click.echo("done")
                synced += 1
            else:
                click.echo("failed")
        except Exception as e:
            click.echo(f"failed: {e}")

    click.echo(f"Synced {synced}/{total} runs.")

    client.close()


# ---------------------------------------------------------------------------
# ls command
# ---------------------------------------------------------------------------


@main.command()
@click.option("--project", "-p", default=None, help="List runs in a project")
def ls(project: str | None) -> None:
    """List projects or runs.

    Without --project, lists all projects. With --project, lists runs
    in the specified project.
    """
    settings = _load_settings()
    api_key = settings.get("api_key")
    base_url = settings.get("base_url", "http://localhost:8000")

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    client = APIClient(base_url=base_url, api_key=api_key)

    if project is None:
        # List projects
        projects = client.list_projects()
        if not projects:
            click.echo("No projects found.")
        else:
            click.echo(f"{'NAME':<30} {'ID'}")
            click.echo("-" * 60)
            for p in projects:
                name = p.get("name", p.get("slug", "unknown"))
                pid = p.get("id", "")
                click.echo(f"{name:<30} {pid}")
    else:
        # List runs in a project
        # First resolve project name to ID
        projects = client.list_projects()
        project_id = None
        for p in projects:
            pname = p.get("name", p.get("slug", ""))
            if pname == project:
                project_id = p.get("id")
                break

        if project_id is None:
            click.echo(f"Project '{project}' not found.")
            client.close()
            return

        runs = client.list_runs(project_id)
        if not runs:
            click.echo(f"No runs found in project '{project}'.")
        else:
            click.echo(f"{'ID':<12} {'NAME':<25} {'STATE':<12}")
            click.echo("-" * 50)
            for r in runs:
                rid = r.get("id", "")
                name = r.get("display_name", "") or ""
                state = r.get("state", "")
                click.echo(f"{rid:<12} {name:<25} {state:<12}")

    client.close()


# ---------------------------------------------------------------------------
# artifact command group
# ---------------------------------------------------------------------------


def _get_client() -> "APIClient":
    """Create an APIClient from stored settings. Exits on auth failure."""
    import os

    settings = _load_settings()
    api_key = os.environ.get("OPENRUNNER_API_KEY") or settings.get("api_key")
    base_url = os.environ.get("OPENRUNNER_BASE_URL") or settings.get(
        "base_url", "http://localhost:8000"
    )

    if not api_key:
        click.echo(
            "Error: Not logged in. Run 'openrunner login' first "
            "or set OPENRUNNER_API_KEY.",
            err=True,
        )
        raise SystemExit(1)

    return APIClient(base_url=base_url, api_key=api_key)


def _resolve_project_id(client: "APIClient", project_name: str | None) -> str | None:
    """Resolve a project name to its UUID. Returns None if not found."""
    if project_name is None:
        return None
    # If it looks like a UUID already, use it directly
    if len(project_name) == 36 and project_name.count("-") == 4:
        return project_name
    projects = client.list_projects()
    for p in projects:
        pname = p.get("name", p.get("slug", ""))
        if pname == project_name:
            return p.get("id")
    return None


def _format_size(size_bytes: int) -> str:
    """Format bytes into human-readable size."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    if size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


@main.group()
def artifact() -> None:
    """Artifact management commands."""
    pass


@artifact.command("list")
@click.argument("project", required=False)
@click.option("--project", "-p", "project_opt", default=None, help="Project name")
def artifact_list(project: str | None, project_opt: str | None) -> None:
    """List artifacts in a project.

    PROJECT can be given as positional arg or via --project/-p.
    """
    project_name = project or project_opt
    if not project_name:
        click.echo("Error: Project name required. Use: openrunner artifact list <project>", err=True)
        raise SystemExit(1)

    client = _get_client()

    project_id = _resolve_project_id(client, project_name)
    if project_id is None:
        click.echo(f"Project '{project_name}' not found.")
        client.close()
        return

    artifacts = client.list_artifacts(project_id)
    if not artifacts:
        click.echo(f"No artifacts in project '{project_name}'.")
        client.close()
        return

    click.echo(f"{'NAME':<30} {'TYPE':<12} {'VERSION':<10} {'CREATED'}")
    click.echo("-" * 75)
    for art in artifacts:
        name = art.get("name", "")[:30]
        atype = art.get("type", "")[:12]
        ver = art.get("latest_version")
        ver_str = f"v{ver}" if ver is not None else "---"
        created = art.get("created_at", "")[:10]
        click.echo(f"{name:<30} {atype:<12} {ver_str:<10} {created}")

    client.close()


@artifact.command("get")
@click.argument("name")
@click.option("--root", "-r", default=".", help="Download directory (default: .)")
def artifact_get(name: str, root: str) -> None:
    """Download an artifact to a local directory.

    NAME can use colon syntax: my-dataset:latest or my-model:v3.
    If no version/alias is given, downloads the latest version.
    """
    client = _get_client()

    # Parse name:alias_or_version syntax
    alias: str | None = None
    version: int | None = None
    artifact_name = name

    if ":" in name:
        artifact_name, ref = name.rsplit(":", 1)
        if ref.startswith("v") and ref[1:].isdigit():
            version = int(ref[1:])
        elif ref.isdigit():
            version = int(ref)
        else:
            alias = ref

    # Find artifact by listing all accessible projects
    projects = client.list_projects()
    artifact_detail = None
    target_version_id = None

    for proj in projects:
        pid = proj.get("id", "")
        arts = client.list_artifacts(pid)
        for art in arts:
            if art.get("name") == artifact_name:
                artifact_detail = client.get_artifact_detail(str(art["id"]))
                break
        if artifact_detail:
            break

    if artifact_detail is None:
        click.echo(f"Artifact '{artifact_name}' not found.")
        client.close()
        return

    versions = artifact_detail.get("versions", [])
    if not versions:
        click.echo(f"No versions found for artifact '{artifact_name}'.")
        client.close()
        return

    # Resolve the target version
    if version is not None:
        for v in versions:
            if v.get("version") == version and v.get("state") == "confirmed":
                target_version_id = v["id"]
                break
        if target_version_id is None:
            click.echo(f"Version v{version} not found for '{artifact_name}'.")
            client.close()
            return
    elif alias is not None:
        # Check aliases
        aliases = client.list_aliases(str(artifact_detail["id"]))
        for a in aliases:
            if a.get("alias_name") == alias:
                target_version_id = a["version_id"]
                break
        if target_version_id is None:
            click.echo(f"Alias '{alias}' not found for '{artifact_name}'.")
            client.close()
            return
    else:
        # Latest confirmed version
        confirmed = [v for v in versions if v.get("state") == "confirmed"]
        if confirmed:
            confirmed.sort(key=lambda v: v.get("version", 0), reverse=True)
            target_version_id = confirmed[0]["id"]
        else:
            click.echo(f"No confirmed versions for '{artifact_name}'.")
            client.close()
            return

    # Get download URLs
    download_info = client.get_artifact_download_urls(target_version_id)
    if download_info is None or not download_info.get("files"):
        click.echo("No files to download.")
        client.close()
        return

    # Download each file
    dest_dir = Path(root) / artifact_name
    dest_dir.mkdir(parents=True, exist_ok=True)

    files = download_info["files"]
    total = len(files)

    click.echo(f"Downloading {total} file(s) to {dest_dir}/")

    downloaded = 0
    for file_entry in files:
        fpath = file_entry.get("path", "unknown")
        is_ref = file_entry.get("is_reference", False)

        if is_ref:
            ref_uri = file_entry.get("reference_uri", "")
            click.echo(f"  [ref] {fpath} -> {ref_uri}")
            # Write a .ref file with the URI
            ref_file = dest_dir / f"{fpath}.ref"
            ref_file.parent.mkdir(parents=True, exist_ok=True)
            ref_file.write_text(ref_uri, encoding="utf-8")
            downloaded += 1
            continue

        url = file_entry.get("presigned_url", "")
        if not url:
            click.echo(f"  [skip] {fpath} -- no URL")
            continue

        data = client.download_file_from_presigned_url(url)
        if data is None:
            click.echo(f"  [fail] {fpath}")
            continue

        out_path = dest_dir / fpath
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(data)
        click.echo(f"  {fpath} ({_format_size(len(data))})")
        downloaded += 1

    click.echo(f"Downloaded {downloaded}/{total} files.")
    client.close()


@artifact.command("info")
@click.argument("name")
def artifact_info(name: str) -> None:
    """Show artifact details, versions, and aliases.

    NAME is the artifact name to look up across accessible projects.
    """
    client = _get_client()

    # Find artifact by name across all projects
    projects = client.list_projects()
    artifact_detail = None

    for proj in projects:
        pid = proj.get("id", "")
        arts = client.list_artifacts(pid)
        for art in arts:
            if art.get("name") == name:
                artifact_detail = client.get_artifact_detail(str(art["id"]))
                break
        if artifact_detail:
            break

    if artifact_detail is None:
        click.echo(f"Artifact '{name}' not found.")
        client.close()
        return

    # Header
    click.echo(f"Artifact: {artifact_detail.get('name', name)}")
    click.echo(f"Type:     {artifact_detail.get('type', '---')}")
    desc = artifact_detail.get("description")
    if desc:
        click.echo(f"Desc:     {desc}")
    click.echo(f"Created:  {artifact_detail.get('created_at', '---')[:19]}")
    click.echo()

    # Aliases
    artifact_id = str(artifact_detail["id"])
    aliases = client.list_aliases(artifact_id)
    if aliases:
        click.echo("Aliases:")
        for a in aliases:
            click.echo(f"  {a.get('alias_name', '---')} -> version {a.get('version_id', '---')[:8]}")
        click.echo()

    # Versions table
    versions = artifact_detail.get("versions", [])
    if versions:
        click.echo(f"{'VERSION':<10} {'STATE':<12} {'STAGE':<14} {'SIZE':<12} {'CREATED'}")
        click.echo("-" * 65)
        for v in versions:
            ver = f"v{v.get('version', '?')}"
            state = v.get("state", "---")
            stage = v.get("stage", "development")
            size = v.get("size_bytes")
            size_str = _format_size(size) if size else "---"
            created = v.get("created_at", "---")[:10]
            click.echo(f"{ver:<10} {state:<12} {stage:<14} {size_str:<12} {created}")
    else:
        click.echo("No versions.")

    client.close()


@artifact.group("cache")
def artifact_cache() -> None:
    """Artifact cache management."""
    pass


@artifact_cache.command("cleanup")
@click.option("--max-size", type=float, default=None, help="Max cache size in GB")
def cache_cleanup(max_size: float | None) -> None:
    """Clean up the local artifact cache.

    Without --max-size, removes all cached artifacts.
    With --max-size, evicts oldest files until the cache is under the limit.
    """
    from openrunner.cache import ArtifactCache

    cache = ArtifactCache()
    cache_dir = cache._dir

    if not cache_dir.exists():
        click.echo("No artifact cache found.")
        return

    # Calculate current cache size
    total_size = 0
    file_count = 0
    files_with_atime: list[tuple[Path, float, int]] = []

    for f in cache_dir.rglob("*"):
        if f.is_file():
            stat = f.stat()
            total_size += stat.st_size
            file_count += 1
            files_with_atime.append((f, stat.st_atime, stat.st_size))

    click.echo(
        f"Cache: {_format_size(total_size)} in {file_count} files at {cache_dir}"
    )

    if max_size is not None:
        max_bytes = int(max_size * 1024 * 1024 * 1024)
        if total_size <= max_bytes:
            click.echo(
                f"Cache ({_format_size(total_size)}) is within limit "
                f"({_format_size(max_bytes)}). No cleanup needed."
            )
            return

        # Sort by access time (oldest first) and evict
        files_with_atime.sort(key=lambda x: x[1])
        removed = 0
        freed = 0
        for fpath, _, fsize in files_with_atime:
            if total_size - freed <= max_bytes:
                break
            fpath.unlink(missing_ok=True)
            freed += fsize
            removed += 1

        click.echo(f"Removed {removed} files, freed {_format_size(freed)}.")
    else:
        # Remove everything
        import shutil

        shutil.rmtree(str(cache_dir), ignore_errors=True)
        click.echo(f"Removed all cached artifacts ({_format_size(total_size)}).")


# ---------------------------------------------------------------------------
# sweep command group
# ---------------------------------------------------------------------------


@main.group()
def sweep() -> None:
    """Hyperparameter sweep commands."""
    pass


@sweep.command("create")
@click.argument("config_file")
@click.option("--project", "-p", default=None, help="Project name")
def sweep_create(config_file: str, project: str | None) -> None:
    """Create a new hyperparameter sweep from a YAML or JSON config file.

    CONFIG_FILE should be a path to a YAML or JSON file containing the
    sweep configuration (method, metric, parameters, early_terminate).
    """
    import json as json_module

    config_path = Path(config_file)

    if not config_path.exists():
        click.echo(f"Error: Config file '{config_file}' not found.", err=True)
        raise SystemExit(1)

    content = config_path.read_text(encoding="utf-8")

    # Try YAML first, then JSON
    config = None
    if config_path.suffix in (".yaml", ".yml"):
        try:
            import yaml

            config = yaml.safe_load(content)
        except ImportError:
            click.echo(
                "Error: PyYAML is required for YAML config files. "
                "Install with: pip install pyyaml",
                err=True,
            )
            raise SystemExit(1)
        except Exception as e:
            click.echo(f"Error parsing YAML: {e}", err=True)
            raise SystemExit(1)

    if config is None:
        try:
            config = json_module.loads(content)
        except json_module.JSONDecodeError as e:
            click.echo(f"Error parsing config file: {e}", err=True)
            raise SystemExit(1)

    # Use the SDK sweep function
    from openrunner.sweep import sweep as create_sweep_fn

    sweep_id = create_sweep_fn(config, project=project)
    if sweep_id:
        click.echo(f"Created sweep: {sweep_id}")
    else:
        click.echo("Failed to create sweep.", err=True)
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# launch command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("image")
@click.argument("command")
@click.option("--project", "-p", default=None, help="Project name or ID")
@click.option("--name", "-n", default=None, help="Job name")
@click.option("--env", "-e", multiple=True, help="Env var as KEY=VALUE (repeatable)")
@click.option("--gpu", type=int, default=None, help="Number of GPUs")
@click.option("--wait", "do_wait", is_flag=True, help="Wait for job to finish")
def launch(
    image: str,
    command: str,
    project: str | None,
    name: str | None,
    env: tuple[str, ...],
    gpu: int | None,
    do_wait: bool,
) -> None:
    """Launch a remote execution job.

    IMAGE is the Docker image to run. COMMAND is the entrypoint command.

    Examples:

        openrunner launch pytorch/pytorch:latest "python train.py"

        openrunner launch -p my-project -e LR=0.001 nvidia/cuda "python train.py"
    """
    from openrunner.launch import launch as launch_fn

    settings = _load_settings()
    api_key = settings.get("api_key")
    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    # Set env vars for SDK settings
    import os
    os.environ.setdefault("OPENRUNNER_API_KEY", api_key)
    base_url = settings.get("base_url", "http://localhost:8000")
    os.environ.setdefault("OPENRUNNER_BASE_URL", base_url)

    resolved_project = project
    if resolved_project is None:
        click.echo("Error: --project is required for launch.", err=True)
        raise SystemExit(1)

    # Parse env vars
    env_dict: dict[str, str] | None = None
    if env:
        env_dict = {}
        for e_str in env:
            if "=" in e_str:
                k, v = e_str.split("=", 1)
                env_dict[k] = v
            else:
                click.echo(f"Warning: ignoring malformed env var '{e_str}' (expected KEY=VALUE)")

    # Resource config
    resources: dict[str, int] | None = None
    if gpu is not None:
        resources = {"gpu_count": gpu}

    job = launch_fn(
        project=resolved_project,
        image=image,
        command=command,
        name=name,
        env=env_dict,
        resources=resources,
    )
    if job is None:
        click.echo("Failed to create job.", err=True)
        raise SystemExit(1)

    click.echo(f"Job created: {job.id}")
    click.echo(f"  Name:  {job.name}")
    click.echo(f"  Image: {job.image}")
    click.echo(f"  State: {job.state}")

    if do_wait:
        click.echo("Waiting for job to complete...")
        final_state = job.wait()
        click.echo(f"Job finished with state: {final_state}")


# ---------------------------------------------------------------------------
# jobs command
# ---------------------------------------------------------------------------


@main.command()
@click.option("--project", "-p", required=True, help="Project name or ID")
@click.option("--state", "-s", default=None, help="Filter by state")
def jobs(project: str, state: str | None) -> None:
    """List jobs for a project."""
    settings = _load_settings()
    api_key = settings.get("api_key")
    base_url = settings.get("base_url", "http://localhost:8000")

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    client = APIClient(base_url=base_url, api_key=api_key)

    # Resolve project name to ID
    project_id = project
    if len(project) != 36 or project.count("-") != 4:
        projects = client.list_projects()
        for p in projects:
            pname = p.get("name", p.get("slug", ""))
            if pname == project:
                project_id = p.get("id", project)
                break

    job_list = client.list_jobs(project_id)
    if not job_list:
        click.echo("No jobs found.")
        client.close()
        return

    click.echo(f"{'ID':<38} {'NAME':<20} {'STATE':<12} {'IMAGE':<30}")
    click.echo("-" * 100)
    for j in job_list:
        jid = str(j.get("id", ""))
        jname = (j.get("name", "") or "")[:20]
        jstate = j.get("state", "")
        jimage = (j.get("image", "") or "")[:30]
        click.echo(f"{jid:<38} {jname:<20} {jstate:<12} {jimage:<30}")

    client.close()


# ---------------------------------------------------------------------------
# job logs command (placeholder)
# ---------------------------------------------------------------------------


@main.group("job")
def job_group() -> None:
    """Job management commands."""
    pass


@job_group.command("logs")
@click.argument("job_id")
def job_logs(job_id: str) -> None:
    """Get job logs (placeholder).

    JOB_ID is the UUID of the job.
    """
    settings = _load_settings()
    api_key = settings.get("api_key")
    base_url = settings.get("base_url", "http://localhost:8000")

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    client = APIClient(base_url=base_url, api_key=api_key)

    job_data = client.get_job(job_id)
    if job_data is None:
        click.echo(f"Job '{job_id}' not found.")
        client.close()
        return

    logs_url = job_data.get("logs_url")
    if logs_url:
        click.echo(f"Logs URL: {logs_url}")
    else:
        click.echo(f"Job {job_id} (state: {job_data.get('state', 'unknown')})")
        click.echo("No logs URL available yet.")
        click.echo("Logs will be available after the job starts running.")

    client.close()


# ---------------------------------------------------------------------------
# sweep command group
# ---------------------------------------------------------------------------


@sweep.command("agent")
@click.argument("sweep_id")
@click.option("--count", "-n", type=int, default=None, help="Maximum number of runs")
@click.option(
    "--function",
    "-f",
    default=None,
    help="Python function path (module:function)",
)
def sweep_agent(
    sweep_id: str, count: int | None, function: str | None
) -> None:
    """Run a sweep agent for the given SWEEP_ID.

    The agent will repeatedly request parameter suggestions from the server
    and execute the training function. If --function is provided, it should
    be a Python dotted path like 'my_module:train_fn'.

    Without --function, a placeholder agent is started that prints
    suggested parameters without executing anything.
    """
    import json as json_module

    from openrunner.sweep import agent as agent_fn

    if function:
        # Import the function from the provided path
        try:
            module_path, func_name = function.rsplit(":", 1)
            import importlib

            mod = importlib.import_module(module_path)
            train_fn = getattr(mod, func_name)
        except (ValueError, ImportError, AttributeError) as e:
            click.echo(f"Error loading function '{function}': {e}", err=True)
            raise SystemExit(1)
    else:
        # Placeholder: just print params
        def train_fn(params: dict) -> None:
            click.echo(f"Suggested params: {json_module.dumps(params, indent=2)}")
            return None

    click.echo(f"Starting sweep agent for {sweep_id}...")
    agent_fn(sweep_id, function=train_fn, count=count)
    click.echo("Sweep agent finished.")
