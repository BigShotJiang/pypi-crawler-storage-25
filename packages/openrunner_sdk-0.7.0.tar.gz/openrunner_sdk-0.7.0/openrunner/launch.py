"""OpenRunner Launch -- create and manage remote execution jobs.

Public API:
    openrunner.launch(project, image, command, ...) -> LaunchJob
    openrunner.launch.from_run(run_id, image, command) -> LaunchJob
"""

from __future__ import annotations

import logging
import time
from typing import Any

from openrunner.api_client import APIClient
from openrunner.settings import SDKSettings

logger = logging.getLogger("openrunner")


class LaunchJob:
    """Represents a submitted remote execution job.

    Provides .id, .state, .wait() for monitoring job progress.
    """

    def __init__(
        self,
        data: dict[str, Any],
        client: APIClient,
    ) -> None:
        self._client = client
        self._data = data
        self.id: str = data["id"]
        self.state: str = data["state"]
        self.name: str = data.get("name", "")
        self.image: str = data.get("image", "")
        self.command: str = data.get("command", "")

    def refresh(self) -> None:
        """Refresh job state from the server."""
        try:
            result = self._client.get_job(self.id)
            if result is not None:
                self._data = result
                self.state = result.get("state", self.state)
        except Exception as e:
            logger.warning("LaunchJob.refresh failed: %s", e)

    def wait(
        self,
        poll_interval: float = 5.0,
        timeout: float | None = None,
    ) -> str:
        """Block until the job finishes, fails, or is canceled.

        Args:
            poll_interval: Seconds between state polls (default 5).
            timeout: Maximum seconds to wait (None = wait forever).

        Returns:
            Final job state string.
        """
        start = time.monotonic()
        terminal_states = {"finished", "failed", "canceled"}

        while self.state not in terminal_states:
            if timeout is not None and (time.monotonic() - start) > timeout:
                logger.warning("LaunchJob.wait timed out after %.0fs", timeout)
                break
            time.sleep(poll_interval)
            self.refresh()

        return self.state

    def cancel(self) -> bool:
        """Cancel the job. Returns True on success."""
        try:
            result = self._client.cancel_job(self.id)
            if result is not None:
                self.state = result.get("state", "canceled")
                return True
            return False
        except Exception as e:
            logger.warning("LaunchJob.cancel failed: %s", e)
            return False

    def __repr__(self) -> str:
        return f"LaunchJob(id={self.id!r}, state={self.state!r}, name={self.name!r})"


def launch(
    project: str,
    image: str,
    command: str,
    *,
    name: str | None = None,
    args: list[str] | None = None,
    env: dict[str, str] | None = None,
    resources: dict[str, Any] | None = None,
    run_id: str | None = None,
    sweep_id: str | None = None,
) -> LaunchJob | None:
    """Create a remote execution job.

    Args:
        project: Project name or ID.
        image: Docker image to run.
        command: Entrypoint command.
        name: Human-readable job name (defaults to image name).
        args: List of command arguments.
        env: Environment variables for the container.
        resources: Resource config (cpu, memory, gpu_count, gpu_type).
        run_id: Link to an existing run.
        sweep_id: Link to an existing sweep.

    Returns:
        LaunchJob object, or None on failure.
    """
    try:
        settings = SDKSettings()
        if not settings.api_key:
            logger.warning("openrunner.launch: no API key set")
            return None

        client = APIClient(
            base_url=settings.base_url,
            api_key=settings.api_key,
        )

        # Resolve project name to project ID
        project_id = _resolve_project_id(client, project)
        if project_id is None:
            logger.warning("openrunner.launch: project '%s' not found", project)
            return None

        job_name = name or image.split("/")[-1].split(":")[0]

        body: dict[str, Any] = {
            "name": job_name,
            "image": image,
            "command": command,
        }
        if args is not None:
            body["args"] = args
        if env is not None:
            body["env_vars"] = env
        if resources is not None:
            body["resource_config"] = resources
        if run_id is not None:
            body["run_id"] = run_id
        if sweep_id is not None:
            body["sweep_id"] = sweep_id

        result = client.create_job(project_id, body)
        if result is None:
            logger.warning("openrunner.launch: failed to create job")
            return None

        return LaunchJob(result, client)

    except Exception as e:
        logger.warning("openrunner.launch failed: %s", e)
        return None


def from_run(
    run_id: str,
    image: str,
    command: str,
    *,
    name: str | None = None,
    env: dict[str, str] | None = None,
    resources: dict[str, Any] | None = None,
) -> LaunchJob | None:
    """Re-launch a job linked to a previous run.

    Fetches the run's config and passes it as environment variables
    merged with any additional env provided.

    Args:
        run_id: The run ID to link to.
        image: Docker image to run.
        command: Entrypoint command.
        name: Human-readable job name.
        env: Additional environment variables.
        resources: Resource config.

    Returns:
        LaunchJob object, or None on failure.
    """
    try:
        settings = SDKSettings()
        if not settings.api_key:
            logger.warning("openrunner.launch.from_run: no API key set")
            return None

        client = APIClient(
            base_url=settings.base_url,
            api_key=settings.api_key,
        )

        # Fetch the run to get project_id and config
        run_data = client.get_run(run_id)
        if run_data is None:
            logger.warning("openrunner.launch.from_run: run '%s' not found", run_id)
            return None

        project_id = run_data.get("project_id")
        if project_id is None:
            logger.warning("openrunner.launch.from_run: run has no project_id")
            return None

        # Merge run config into env vars
        run_config = run_data.get("config", {})
        merged_env: dict[str, str] = {}
        for k, v in run_config.items():
            merged_env[k] = str(v)
        if env:
            merged_env.update(env)

        job_name = name or f"rerun-{run_id}"

        body: dict[str, Any] = {
            "name": job_name,
            "image": image,
            "command": command,
            "run_id": run_id,
        }
        if merged_env:
            body["env_vars"] = merged_env
        if resources is not None:
            body["resource_config"] = resources

        result = client.create_job(project_id, body)
        if result is None:
            logger.warning("openrunner.launch.from_run: failed to create job")
            return None

        return LaunchJob(result, client)

    except Exception as e:
        logger.warning("openrunner.launch.from_run failed: %s", e)
        return None


def _resolve_project_id(client: APIClient, project: str) -> str | None:
    """Resolve a project name to its ID. If it looks like a UUID, use as-is."""
    # If it looks like a UUID, use directly
    if len(project) == 36 and project.count("-") == 4:
        return project

    projects = client.list_projects()
    for p in projects:
        if p.get("name") == project or p.get("slug") == project:
            return p.get("id")
    return None
