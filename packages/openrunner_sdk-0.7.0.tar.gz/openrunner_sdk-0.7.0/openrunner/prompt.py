"""Prompt management SDK client.

Provides a high-level API for fetching, rendering, and publishing
versioned prompt templates from the OpenRunner server.

Usage::

    from openrunner import Prompt

    # Fetch latest template
    template = Prompt.get("my-prompt")

    # Render with variables
    rendered = Prompt.render("my-prompt", {"name": "Alice"})

    # Publish a new version
    Prompt.publish("my-prompt", "Hello {{name}}", model_config={"model": "gpt-4"})
"""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

logger = logging.getLogger("openrunner")


def _get_client() -> httpx.Client:
    """Create an httpx client configured for the OpenRunner server."""
    base_url = os.environ.get(
        "OPENRUNNER_BASE_URL",
        os.environ.get("WANDB_BASE_URL", "http://localhost:8000"),
    )
    api_key = os.environ.get(
        "OPENRUNNER_API_KEY",
        os.environ.get("WANDB_API_KEY", ""),
    )
    return httpx.Client(
        base_url=f"{base_url.rstrip('/')}/api/v1",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=30.0,
    )


def _resolve_project_id(client: httpx.Client, project: str | None = None) -> str | None:
    """Resolve a project name to its UUID.

    If project is already a UUID-like string, return as-is.
    Otherwise, list projects and find by name or slug.
    """
    resolved_project = project or os.environ.get(
        "OPENRUNNER_PROJECT",
        os.environ.get("WANDB_PROJECT", "uncategorized"),
    )

    # Check if it looks like a UUID already
    if len(resolved_project) == 36 and resolved_project.count("-") == 4:
        return resolved_project

    try:
        response = client.get("/projects")
        response.raise_for_status()
        projects = response.json()
        if isinstance(projects, dict):
            projects = projects.get("projects", projects.get("items", []))
        for p in projects:
            if p.get("name") == resolved_project or p.get("slug") == resolved_project:
                return p["id"]
    except Exception as e:
        logger.warning("Failed to resolve project '%s': %s", resolved_project, e)

    return None


class Prompt:
    """SDK client for versioned prompt management.

    All methods are class methods that create short-lived HTTP connections.
    Methods are defensive -- they log warnings and return None on failure.
    """

    @classmethod
    def get(
        cls,
        name: str,
        version: int | None = None,
        project: str | None = None,
    ) -> str | None:
        """Fetch a prompt template from the server.

        Args:
            name: Prompt name within the project.
            version: Specific version number, or None for latest.
            project: Project name/slug/ID. Defaults to OPENRUNNER_PROJECT env.

        Returns:
            The template string, or None on failure.
        """
        try:
            client = _get_client()
            project_id = _resolve_project_id(client, project)
            if project_id is None:
                logger.warning("Prompt.get: could not resolve project")
                return None

            # List prompts to find by name
            response = client.get(f"/projects/{project_id}/prompts")
            response.raise_for_status()
            prompts = response.json()

            prompt_id = None
            for p in prompts:
                if p.get("name") == name:
                    prompt_id = p["id"]
                    break

            if prompt_id is None:
                logger.warning("Prompt.get: prompt '%s' not found", name)
                return None

            # Get specific version or latest
            if version is not None:
                response = client.get(f"/prompts/{prompt_id}/versions/{version}")
                response.raise_for_status()
                return response.json().get("template")
            else:
                # Get prompt detail which includes versions
                response = client.get(f"/prompts/{prompt_id}")
                response.raise_for_status()
                data = response.json()
                versions = data.get("versions", [])
                if not versions:
                    logger.warning("Prompt.get: no versions for '%s'", name)
                    return None
                # Versions are sorted descending, first is latest
                return versions[0].get("template")

        except Exception as e:
            logger.warning("Prompt.get failed: %s", e)
            return None
        finally:
            try:
                client.close()
            except Exception:
                pass

    @classmethod
    def render(
        cls,
        name: str,
        variables: dict[str, str],
        version: int | None = None,
        project: str | None = None,
    ) -> str | None:
        """Fetch a prompt template and render it with variables.

        Args:
            name: Prompt name within the project.
            variables: Variable values to substitute in the template.
            version: Specific version number, or None for latest.
            project: Project name/slug/ID.

        Returns:
            The rendered string, or None on failure.
        """
        try:
            client = _get_client()
            project_id = _resolve_project_id(client, project)
            if project_id is None:
                logger.warning("Prompt.render: could not resolve project")
                return None

            # Find prompt by name
            response = client.get(f"/projects/{project_id}/prompts")
            response.raise_for_status()
            prompts = response.json()

            prompt_id = None
            for p in prompts:
                if p.get("name") == name:
                    prompt_id = p["id"]
                    break

            if prompt_id is None:
                logger.warning("Prompt.render: prompt '%s' not found", name)
                return None

            # Call render endpoint
            body: dict[str, Any] = {"variables": variables}
            if version is not None:
                body["version"] = version
            response = client.post(f"/prompts/{prompt_id}/render", json=body)
            response.raise_for_status()
            return response.json().get("rendered")

        except Exception as e:
            logger.warning("Prompt.render failed: %s", e)
            return None
        finally:
            try:
                client.close()
            except Exception:
                pass

    @classmethod
    def publish(
        cls,
        name: str,
        template: str,
        model_config: dict[str, Any] | None = None,
        description: str | None = None,
        project: str | None = None,
    ) -> dict[str, Any] | None:
        """Create or update a prompt version.

        If the prompt doesn't exist, creates it first.
        Always creates a new version with the provided template.

        Args:
            name: Prompt name within the project.
            template: The prompt template text with {{variable}} placeholders.
            model_config: Optional model configuration (model, temperature, etc.).
            description: Prompt description (used only if creating new prompt).
            project: Project name/slug/ID.

        Returns:
            Version info dict, or None on failure.
        """
        try:
            client = _get_client()
            project_id = _resolve_project_id(client, project)
            if project_id is None:
                logger.warning("Prompt.publish: could not resolve project")
                return None

            # Find or create prompt by name
            response = client.get(f"/projects/{project_id}/prompts")
            response.raise_for_status()
            prompts = response.json()

            prompt_id = None
            for p in prompts:
                if p.get("name") == name:
                    prompt_id = p["id"]
                    break

            if prompt_id is None:
                # Create the prompt
                body: dict[str, Any] = {"name": name}
                if description is not None:
                    body["description"] = description
                response = client.post(
                    f"/projects/{project_id}/prompts", json=body
                )
                response.raise_for_status()
                prompt_id = response.json()["id"]

            # Create a new version
            version_body: dict[str, Any] = {"template": template}
            if model_config is not None:
                version_body["model_config"] = model_config
            response = client.post(
                f"/prompts/{prompt_id}/versions", json=version_body
            )
            response.raise_for_status()
            return response.json()

        except Exception as e:
            logger.warning("Prompt.publish failed: %s", e)
            return None
        finally:
            try:
                client.close()
            except Exception:
                pass
