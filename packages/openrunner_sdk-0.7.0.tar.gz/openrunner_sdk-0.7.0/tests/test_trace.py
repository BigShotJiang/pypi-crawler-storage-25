"""Tests for the @openrunner.trace decorator and tracing infrastructure."""

from __future__ import annotations

import asyncio
import time
import threading
from unittest.mock import patch

import pytest

from openrunner.trace import (
    SpanData,
    TraceData,
    _active_traces,
    _capture_inputs,
    _capture_output,
    _finish_trace,
    _get_parent_span_id,
    _get_trace_id,
    _register_span,
    _safe_serialize,
    _set_parent_span_id,
    _set_trace_id,
    _start_trace,
    trace,
)


# ---------------------------------------------------------------------------
# _safe_serialize
# ---------------------------------------------------------------------------


class TestSafeSerialize:
    def test_primitives(self):
        assert _safe_serialize(42) == 42
        assert _safe_serialize(3.14) == 3.14
        assert _safe_serialize("hello") == "hello"
        assert _safe_serialize(True) is True
        assert _safe_serialize(None) is None

    def test_dict(self):
        result = _safe_serialize({"a": 1, "b": "two"})
        assert result == {"a": 1, "b": "two"}

    def test_list(self):
        result = _safe_serialize([1, 2, 3])
        assert result == [1, 2, 3]

    def test_nested_dict(self):
        result = _safe_serialize({"a": {"b": [1, 2]}})
        assert result == {"a": {"b": [1, 2]}}

    def test_non_serializable_falls_back_to_str(self):
        obj = object()
        result = _safe_serialize(obj)
        assert isinstance(result, str)

    def test_large_list_capped(self):
        big_list = list(range(200))
        result = _safe_serialize(big_list)
        assert len(result) == 100  # capped at 100

    def test_large_dict_capped(self):
        big_dict = {f"key_{i}": i for i in range(100)}
        result = _safe_serialize(big_dict)
        assert len(result) == 50  # capped at 50


# ---------------------------------------------------------------------------
# Context management
# ---------------------------------------------------------------------------


class TestContextManagement:
    def test_trace_id_get_set(self):
        _set_trace_id(None)
        assert _get_trace_id() is None
        _set_trace_id("trace-123")
        assert _get_trace_id() == "trace-123"
        _set_trace_id(None)

    def test_parent_span_id_get_set(self):
        _set_parent_span_id(None)
        assert _get_parent_span_id() is None
        _set_parent_span_id("span-456")
        assert _get_parent_span_id() == "span-456"
        _set_parent_span_id(None)


# ---------------------------------------------------------------------------
# SpanData / TraceData
# ---------------------------------------------------------------------------


class TestSpanData:
    def test_to_dict(self):
        span = SpanData(
            id="span-1",
            trace_id="trace-1",
            parent_id=None,
            name="test_func",
            inputs={"x": 1},
            outputs={"result": 2},
            status="success",
            duration_ms=10.5,
        )
        d = span.to_dict()
        assert d["id"] == "span-1"
        assert d["name"] == "test_func"
        assert d["inputs"] == {"x": 1}
        assert d["outputs"] == {"result": 2}
        assert d["duration_ms"] == 10.5
        assert d["parent_id"] is None

    def test_error_span(self):
        span = SpanData(
            id="span-2",
            trace_id="trace-1",
            parent_id="span-1",
            name="failing_func",
            status="error",
            error="ValueError: bad input",
            duration_ms=5.0,
        )
        d = span.to_dict()
        assert d["status"] == "error"
        assert d["error"] == "ValueError: bad input"
        assert d["parent_id"] == "span-1"


class TestTraceData:
    def test_to_dict(self):
        trace_data = TraceData(
            id="trace-1",
            name="my_trace",
        )
        span = SpanData(
            id="span-1",
            trace_id="trace-1",
            parent_id=None,
            name="root",
            duration_ms=100.0,
        )
        trace_data.spans.append(span)

        d = trace_data.to_dict()
        assert d["id"] == "trace-1"
        assert d["name"] == "my_trace"
        assert len(d["spans"]) == 1
        assert d["spans"][0]["name"] == "root"


# ---------------------------------------------------------------------------
# Trace lifecycle (_start_trace, _register_span, _finish_trace)
# ---------------------------------------------------------------------------


class TestTraceLifecycle:
    def setup_method(self):
        _active_traces.clear()

    def test_start_and_finish_trace(self):
        trace_data = _start_trace("test")
        assert trace_data.id in _active_traces

        finished = _finish_trace(trace_data.id)
        assert finished is not None
        assert finished.id == trace_data.id
        assert trace_data.id not in _active_traces

    def test_finish_nonexistent_returns_none(self):
        assert _finish_trace("nonexistent") is None

    def test_register_span(self):
        trace_data = _start_trace("test")
        span = SpanData(
            id="span-1",
            trace_id=trace_data.id,
            parent_id=None,
            name="my_span",
            duration_ms=50.0,
        )
        _register_span(span)
        assert len(_active_traces[trace_data.id].spans) == 1
        _finish_trace(trace_data.id)


# ---------------------------------------------------------------------------
# @trace decorator -- sync
# ---------------------------------------------------------------------------


class TestTraceDecoratorSync:
    def setup_method(self):
        _active_traces.clear()
        _set_trace_id(None)
        _set_parent_span_id(None)

    def test_basic_sync_trace(self):
        """@trace preserves function return value."""
        @trace
        def add(a, b):
            return a + b

        # Suppress sender
        with patch("openrunner.trace._send_trace"):
            result = add(3, 4)
        assert result == 7

    def test_sync_trace_preserves_name(self):
        """Decorated function preserves __name__."""
        @trace
        def my_function(x):
            return x

        assert my_function.__name__ == "my_function"

    def test_sync_trace_captures_error(self):
        """@trace re-raises exceptions."""
        @trace
        def fail():
            raise ValueError("boom")

        with patch("openrunner.trace._send_trace"):
            with pytest.raises(ValueError, match="boom"):
                fail()

    def test_sync_nested_spans(self):
        """Nested @trace calls create parent-child spans."""
        collected_traces = []

        def mock_send(t):
            collected_traces.append(t)

        @trace
        def outer(x):
            return inner(x + 1)

        @trace
        def inner(y):
            return y * 2

        with patch("openrunner.trace._send_trace", side_effect=mock_send):
            result = outer(3)

        assert result == 8
        assert len(collected_traces) == 1
        t = collected_traces[0]
        assert len(t.spans) == 2

        # One should be root (no parent), one should be child
        root_spans = [s for s in t.spans if s.parent_id is None]
        child_spans = [s for s in t.spans if s.parent_id is not None]
        assert len(root_spans) == 1
        assert len(child_spans) == 1
        assert child_spans[0].parent_id == root_spans[0].id

    def test_sync_trace_measures_duration(self):
        """@trace captures duration > 0."""
        collected_traces = []

        @trace
        def slow():
            time.sleep(0.01)
            return "done"

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            slow()

        assert len(collected_traces) == 1
        span = collected_traces[0].spans[0]
        assert span.duration_ms > 5  # at least 5ms for 10ms sleep

    def test_custom_name(self):
        """@trace(name=...) uses custom span name."""
        collected_traces = []

        @trace(name="custom_operation")
        def my_func():
            return 42

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            my_func()

        assert collected_traces[0].spans[0].name == "custom_operation"


# ---------------------------------------------------------------------------
# @trace decorator -- async
# ---------------------------------------------------------------------------


class TestTraceDecoratorAsync:
    def setup_method(self):
        _active_traces.clear()
        _set_trace_id(None)
        _set_parent_span_id(None)

    def test_basic_async_trace(self):
        """@trace works with async functions."""
        @trace
        async def async_add(a, b):
            return a + b

        with patch("openrunner.trace._send_trace"):
            result = asyncio.run(async_add(5, 6))
        assert result == 11

    def test_async_trace_preserves_name(self):
        """Async decorated function preserves __name__."""
        @trace
        async def my_async_func(x):
            return x

        assert my_async_func.__name__ == "my_async_func"

    def test_async_trace_captures_error(self):
        """@trace re-raises async exceptions."""
        @trace
        async def async_fail():
            raise RuntimeError("async boom")

        with patch("openrunner.trace._send_trace"):
            with pytest.raises(RuntimeError, match="async boom"):
                asyncio.run(async_fail())

    def test_async_nested_spans(self):
        """Nested async @trace calls create parent-child spans."""
        collected_traces = []

        @trace
        async def outer(x):
            return await inner(x + 1)

        @trace
        async def inner(y):
            return y * 2

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            result = asyncio.run(outer(3))

        assert result == 8
        assert len(collected_traces) == 1
        t = collected_traces[0]
        assert len(t.spans) == 2

        root_spans = [s for s in t.spans if s.parent_id is None]
        child_spans = [s for s in t.spans if s.parent_id is not None]
        assert len(root_spans) == 1
        assert len(child_spans) == 1


# ---------------------------------------------------------------------------
# Input/output capture
# ---------------------------------------------------------------------------


class TestInputOutputCapture:
    def test_capture_inputs(self):
        def func(a, b, c=10):
            pass

        result = _capture_inputs(func, (1, 2), {"c": 3})
        assert result == {"a": 1, "b": 2, "c": 3}

    def test_capture_inputs_defaults(self):
        def func(a, b=5):
            pass

        result = _capture_inputs(func, (1,), {})
        assert result == {"a": 1, "b": 5}

    def test_capture_output(self):
        result = _capture_output(42)
        assert result == {"result": 42}

    def test_capture_output_dict(self):
        result = _capture_output({"key": "value"})
        assert result == {"result": {"key": "value"}}

    def test_capture_output_none(self):
        result = _capture_output(None)
        assert result == {"result": None}
