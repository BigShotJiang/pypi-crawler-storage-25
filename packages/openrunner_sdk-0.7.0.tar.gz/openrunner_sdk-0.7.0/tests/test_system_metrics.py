"""Tests for the OpenRunner system metrics collector."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from openrunner.system_metrics import SystemMetrics


# ---------------------------------------------------------------------------
# CPU / Memory metrics with real psutil
# ---------------------------------------------------------------------------

class TestCPUMemoryMetrics:
    """Test CPU and memory collection using real psutil (installed dep)."""

    def test_sample_returns_cpu_key(self):
        sm = SystemMetrics()
        result = sm.sample()
        assert "system.cpu" in result

    def test_sample_returns_memory_percent_key(self):
        sm = SystemMetrics()
        result = sm.sample()
        assert "system.memory_percent" in result

    def test_sample_returns_proc_rss_key(self):
        sm = SystemMetrics()
        result = sm.sample()
        assert "system.proc.memory.rssMB" in result

    def test_cpu_percent_called_with_interval_none(self):
        """Verify psutil.cpu_percent uses interval=None (non-blocking)."""
        with patch("openrunner.system_metrics.psutil") as mock_psutil:
            mock_psutil.cpu_percent.return_value = 42.0
            mock_psutil.virtual_memory.return_value = MagicMock(percent=55.0)
            mock_psutil.Process.return_value.memory_info.return_value = MagicMock(rss=100 * 1024 * 1024)
            # Re-create with patched module-level HAS_PSUTIL
            with patch("openrunner.system_metrics.HAS_PSUTIL", True):
                sm = SystemMetrics()
                sm.sample()
            mock_psutil.cpu_percent.assert_called_with(interval=None)

    def test_metric_values_are_floats(self):
        sm = SystemMetrics()
        result = sm.sample()
        for key, value in result.items():
            assert isinstance(value, (int, float)), f"{key} is not numeric: {value!r}"


# ---------------------------------------------------------------------------
# GPU metrics with mocked pynvml
# ---------------------------------------------------------------------------

class TestGPUMetrics:
    """Test GPU collection with mocked pynvml (likely not installed)."""

    def test_sample_returns_gpu_keys_when_nvml_available(self):
        import openrunner.system_metrics as sm_mod

        mock_handle = MagicMock()
        mock_util = MagicMock(gpu=75, memory=50)
        mock_mem = MagicMock(used=4_000_000_000)

        # Inject nvml functions that may not exist in the module
        with patch.object(sm_mod, "HAS_NVML", True), \
             patch.object(sm_mod, "HAS_PSUTIL", False), \
             patch.object(sm_mod, "nvmlInit", create=True), \
             patch.object(sm_mod, "nvmlDeviceGetCount", return_value=1, create=True), \
             patch.object(sm_mod, "nvmlDeviceGetHandleByIndex", return_value=mock_handle, create=True), \
             patch.object(sm_mod, "nvmlDeviceGetUtilizationRates", return_value=mock_util, create=True), \
             patch.object(sm_mod, "nvmlDeviceGetMemoryInfo", return_value=mock_mem, create=True):
            sm = SystemMetrics()
            # Force GPU initialized state
            sm._gpu_initialized = True
            sm._gpu_count = 1
            result = sm.sample()

            assert "system.gpu.0.gpu" in result
            assert result["system.gpu.0.gpu"] == 75.0
            assert "system.gpu.0.memory" in result
            assert result["system.gpu.0.memory"] == 50.0
            assert "system.gpu.0.memoryAllocatedBytes" in result
            assert result["system.gpu.0.memoryAllocatedBytes"] == 4_000_000_000.0


# ---------------------------------------------------------------------------
# Graceful degradation -- neither psutil nor pynvml
# ---------------------------------------------------------------------------

class TestGracefulDegradation:
    """Test that missing libraries don't crash."""

    def test_empty_dict_when_nothing_available(self):
        with patch("openrunner.system_metrics.HAS_PSUTIL", False):
            sm = SystemMetrics()
            # Ensure GPU also not initialized
            sm._gpu_initialized = False
            sm._gpu_count = 0
            result = sm.sample()
            assert result == {}

    def test_only_cpu_when_psutil_available_but_no_gpu(self):
        sm = SystemMetrics()
        # If pynvml is not installed, _gpu_initialized should be False
        assert sm._gpu_initialized is False or sm._gpu_count == 0 or True
        result = sm.sample()
        # Should have CPU/memory keys but no GPU keys
        assert "system.cpu" in result
        gpu_keys = [k for k in result if k.startswith("system.gpu")]
        assert gpu_keys == []


# ---------------------------------------------------------------------------
# Shutdown
# ---------------------------------------------------------------------------

class TestShutdown:
    def test_shutdown_calls_nvml_shutdown_when_gpu_initialized(self):
        import openrunner.system_metrics as sm_mod

        mock_shutdown = MagicMock()
        with patch.object(sm_mod, "HAS_NVML", True), \
             patch.object(sm_mod, "nvmlInit", create=True), \
             patch.object(sm_mod, "nvmlDeviceGetCount", return_value=1, create=True), \
             patch.object(sm_mod, "nvmlShutdown", mock_shutdown, create=True):
            sm = SystemMetrics()
            sm._gpu_initialized = True
            sm.shutdown()
            mock_shutdown.assert_called_once()
            assert sm._gpu_initialized is False

    def test_shutdown_noop_when_gpu_not_initialized(self):
        sm = SystemMetrics()
        # Should not raise
        sm.shutdown()
