"""Tests for the OpenRunner CLI commands (login, sync, ls).

Uses Click's CliRunner for testing CLI invocations and monkeypatch
to redirect ~/.openrunner/ to tmp_path for isolation.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from openrunner.cli import main


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def settings_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ~/.openrunner/ to tmp_path/.openrunner for test isolation."""
    openrunner_dir = tmp_path / ".openrunner"
    openrunner_dir.mkdir()
    monkeypatch.setattr(
        "openrunner.cli._settings_dir",
        lambda: openrunner_dir,
    )
    return openrunner_dir


class TestLogin:
    """Test 1: `openrunner login` prompts for API key and server URL."""

    def test_login_stores_settings(self, runner, settings_dir):
        result = runner.invoke(
            main,
            ["login"],
            input="my-api-key\nhttp://myserver:8000\n",
        )
        assert result.exit_code == 0
        assert "Login successful" in result.output

        settings_file = settings_dir / "settings.json"
        assert settings_file.exists()
        settings = json.loads(settings_file.read_text())
        assert settings["api_key"] == "my-api-key"
        assert settings["base_url"] == "http://myserver:8000"

    def test_login_uses_default_url(self, runner, settings_dir):
        result = runner.invoke(
            main,
            ["login"],
            input="my-api-key\n\n",  # empty input = default
        )
        assert result.exit_code == 0
        settings = json.loads(
            (settings_dir / "settings.json").read_text()
        )
        assert settings["base_url"] == "http://localhost:8000"

    def test_login_updates_existing_settings(self, runner, settings_dir):
        # Write existing settings
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "old-key", "base_url": "http://old:8000"})
        )
        result = runner.invoke(
            main,
            ["login"],
            input="new-key\nhttp://new:8000\n",
        )
        assert result.exit_code == 0
        settings = json.loads(
            (settings_dir / "settings.json").read_text()
        )
        assert settings["api_key"] == "new-key"
        assert settings["base_url"] == "http://new:8000"


class TestSyncAll:
    """Test 2: `openrunner sync --all` discovers offline runs and syncs each."""

    def test_sync_all_discovers_and_syncs(
        self, runner, settings_dir, tmp_path
    ):
        # Set up settings
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        # Create offline run dirs
        offline_dir = tmp_path / "offline"
        offline_dir.mkdir()
        for run_id in ["run1", "run2"]:
            d = offline_dir / run_id
            d.mkdir()
            (d / "meta.json").write_text(json.dumps({"id": run_id, "project_id": "p1"}))
            (d / "config.json").write_text(json.dumps({"lr": 0.1}))

        with patch("openrunner.cli.OfflineStorage") as mock_storage, \
             patch("openrunner.cli.OfflineSync") as mock_sync_cls, \
             patch("openrunner.cli.APIClient"):
            mock_storage.list_offline_runs.return_value = [
                offline_dir / "run1",
                offline_dir / "run2",
            ]
            mock_syncer = MagicMock()
            mock_syncer.sync.return_value = True
            mock_sync_cls.return_value = mock_syncer

            result = runner.invoke(main, ["sync", "--all"])
            assert result.exit_code == 0
            assert "2/2" in result.output
            assert mock_sync_cls.call_count == 2


class TestSyncPath:
    """Test 3: `openrunner sync <path>` syncs a specific offline run directory."""

    def test_sync_specific_path(self, runner, settings_dir, tmp_path):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        run_dir = tmp_path / "my_run"
        run_dir.mkdir()
        (run_dir / "meta.json").write_text(json.dumps({"id": "my_run"}))
        (run_dir / "config.json").write_text(json.dumps({}))

        with patch("openrunner.cli.OfflineSync") as mock_sync_cls, \
             patch("openrunner.cli.APIClient"):
            mock_syncer = MagicMock()
            mock_syncer.sync.return_value = True
            mock_sync_cls.return_value = mock_syncer

            result = runner.invoke(main, ["sync", str(run_dir)])
            assert result.exit_code == 0
            assert "1/1" in result.output
            mock_sync_cls.assert_called_once()


class TestLsProjects:
    """Test 4: `openrunner ls` lists projects from server."""

    def test_ls_lists_projects(self, runner, settings_dir):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        with patch("openrunner.cli.APIClient") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.list_projects.return_value = [
                {"name": "project-a", "id": "p1"},
                {"name": "project-b", "id": "p2"},
            ]
            mock_client_cls.return_value = mock_client

            result = runner.invoke(main, ["ls"])
            assert result.exit_code == 0
            assert "project-a" in result.output
            assert "project-b" in result.output


class TestLsRuns:
    """Test 5: `openrunner ls --project <name>` lists runs within a project."""

    def test_ls_project_lists_runs(self, runner, settings_dir):
        (settings_dir / "settings.json").write_text(
            json.dumps({"api_key": "test-key", "base_url": "http://localhost:8000"})
        )

        with patch("openrunner.cli.APIClient") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.list_projects.return_value = [
                {"name": "myproject", "id": "proj-id-1"},
            ]
            mock_client.list_runs.return_value = [
                {"id": "run1", "display_name": "first-run", "state": "finished"},
                {"id": "run2", "display_name": "second-run", "state": "running"},
            ]
            mock_client_cls.return_value = mock_client

            result = runner.invoke(main, ["ls", "-p", "myproject"])
            assert result.exit_code == 0
            assert "run1" in result.output
            assert "run2" in result.output


class TestEntryPoint:
    """Test 6: CLI entry point `openrunner` is registered in pyproject.toml."""

    def test_pyproject_has_entry_point(self):
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject_path.read_text()
        assert 'openrunner = "openrunner.cli:main"' in content

    def test_click_dependency(self):
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject_path.read_text()
        assert "click" in content
