"""Tests for openrunner.plot -- Python-native chart helper functions."""

from __future__ import annotations

import json

import numpy as np
import pytest

from openrunner.media import PlotlyChart, Table
from openrunner import plot


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _assert_valid_plotly(chart: PlotlyChart) -> dict:
    """Assert that a PlotlyChart serializes to valid Plotly JSON."""
    assert isinstance(chart, PlotlyChart)
    result = chart._serialize()
    assert "data" in result
    assert "layout" in result
    assert isinstance(result["data"], list)
    assert len(result["data"]) > 0
    # Verify JSON-serializable
    json.dumps(result)
    return result


def _make_table(columns: list[str], data: list[list]) -> Table:
    """Create a Table from columns and data."""
    return Table(columns=columns, data=data)


# ---------------------------------------------------------------------------
# line()
# ---------------------------------------------------------------------------

class TestLine:
    """Tests for plot.line()."""

    def test_basic_line(self) -> None:
        """Line plot from a simple table."""
        table = _make_table(["x", "y"], [[1, 2], [3, 4], [5, 6]])
        chart = plot.line(table, "x", "y", title="Test Line")
        result = _assert_valid_plotly(chart)

        trace = result["data"][0]
        assert trace["type"] == "scatter"
        assert trace["mode"] == "lines"
        assert trace["x"] == [1, 3, 5]
        assert trace["y"] == [2, 4, 6]
        assert trace["name"] == "y"
        assert result["layout"]["title"]["text"] == "Test Line"

    def test_line_no_title(self) -> None:
        """Line plot with no title omits the title key."""
        table = _make_table(["a", "b"], [[1, 10]])
        chart = plot.line(table, "a", "b")
        result = _assert_valid_plotly(chart)
        assert "title" not in result["layout"]

    def test_line_bad_table(self) -> None:
        """Non-Table input raises ValueError."""
        with pytest.raises(ValueError, match="openrunner.Table"):
            plot.line({"x": [1], "y": [2]}, "x", "y")

    def test_line_missing_column(self) -> None:
        """Missing column name raises ValueError."""
        table = _make_table(["x", "y"], [[1, 2]])
        with pytest.raises(ValueError, match="Column 'z' not found"):
            plot.line(table, "x", "z")

    def test_line_axis_labels(self) -> None:
        """Axis labels are set from column names."""
        table = _make_table(["epoch", "loss"], [[1, 0.5], [2, 0.3]])
        chart = plot.line(table, "epoch", "loss")
        result = _assert_valid_plotly(chart)
        assert result["layout"]["xaxis"]["title"] == "epoch"
        assert result["layout"]["yaxis"]["title"] == "loss"

    def test_line_empty_table(self) -> None:
        """Line plot from empty table produces empty data arrays."""
        table = _make_table(["x", "y"], [])
        chart = plot.line(table, "x", "y")
        result = _assert_valid_plotly(chart)
        assert result["data"][0]["x"] == []
        assert result["data"][0]["y"] == []


# ---------------------------------------------------------------------------
# scatter()
# ---------------------------------------------------------------------------

class TestScatter:
    """Tests for plot.scatter()."""

    def test_basic_scatter(self) -> None:
        """Scatter plot uses marker mode."""
        table = _make_table(["x", "y"], [[1, 2], [3, 4]])
        chart = plot.scatter(table, "x", "y", title="Scatter")
        result = _assert_valid_plotly(chart)

        trace = result["data"][0]
        assert trace["type"] == "scatter"
        assert trace["mode"] == "markers"
        assert trace["x"] == [1, 3]
        assert trace["y"] == [2, 4]
        assert result["layout"]["title"]["text"] == "Scatter"

    def test_scatter_bad_table(self) -> None:
        """Non-Table input raises ValueError."""
        with pytest.raises(ValueError, match="openrunner.Table"):
            plot.scatter([[1, 2]], "x", "y")


# ---------------------------------------------------------------------------
# bar()
# ---------------------------------------------------------------------------

class TestBar:
    """Tests for plot.bar()."""

    def test_basic_bar(self) -> None:
        """Bar chart from a simple table."""
        table = _make_table(
            ["category", "count"],
            [["A", 10], ["B", 20], ["C", 15]],
        )
        chart = plot.bar(table, "category", "count", title="Bar Chart")
        result = _assert_valid_plotly(chart)

        trace = result["data"][0]
        assert trace["type"] == "bar"
        assert trace["x"] == ["A", "B", "C"]
        assert trace["y"] == [10, 20, 15]

    def test_bar_missing_column(self) -> None:
        """Missing column raises ValueError."""
        table = _make_table(["a"], [[1]])
        with pytest.raises(ValueError, match="Column 'b' not found"):
            plot.bar(table, "a", "b")


# ---------------------------------------------------------------------------
# histogram()
# ---------------------------------------------------------------------------

class TestHistogram:
    """Tests for plot.histogram()."""

    def test_basic_histogram(self) -> None:
        """Histogram from a table column."""
        table = _make_table(
            ["values"],
            [[v] for v in [1.0, 2.0, 2.5, 3.0, 3.5, 4.0]],
        )
        chart = plot.histogram(table, "values", title="Distribution")
        result = _assert_valid_plotly(chart)

        trace = result["data"][0]
        assert trace["type"] == "histogram"
        assert trace["x"] == [1.0, 2.0, 2.5, 3.0, 3.5, 4.0]

    def test_histogram_empty(self) -> None:
        """Histogram from empty table produces empty x array."""
        table = _make_table(["v"], [])
        chart = plot.histogram(table, "v")
        result = _assert_valid_plotly(chart)
        assert result["data"][0]["x"] == []


# ---------------------------------------------------------------------------
# line_series()
# ---------------------------------------------------------------------------

class TestLineSeries:
    """Tests for plot.line_series()."""

    def test_multi_series(self) -> None:
        """Multi-series line plot with named series."""
        xs = [[1, 2, 3], [1, 2, 3]]
        ys = [[10, 20, 30], [15, 25, 35]]
        chart = plot.line_series(xs, ys, keys=["train", "val"], title="Multi")
        result = _assert_valid_plotly(chart)

        assert len(result["data"]) == 2
        assert result["data"][0]["name"] == "train"
        assert result["data"][1]["name"] == "val"
        assert result["data"][0]["y"] == [10, 20, 30]
        assert result["data"][1]["y"] == [15, 25, 35]

    def test_line_series_default_keys(self) -> None:
        """Default keys are series_0, series_1, etc."""
        chart = plot.line_series([[1], [2]], [[3], [4]])
        result = _assert_valid_plotly(chart)
        assert result["data"][0]["name"] == "series_0"
        assert result["data"][1]["name"] == "series_1"

    def test_line_series_length_mismatch(self) -> None:
        """Mismatched xs/ys raises ValueError."""
        with pytest.raises(ValueError, match="same length"):
            plot.line_series([[1]], [[2], [3]])


# ---------------------------------------------------------------------------
# pr_curve()
# ---------------------------------------------------------------------------

class TestPRCurve:
    """Tests for plot.pr_curve()."""

    def test_binary_pr_curve(self) -> None:
        """Binary PR curve produces valid Plotly output."""
        np.random.seed(42)
        y_true = [0, 0, 0, 1, 1, 1, 1, 1]
        y_probas = [0.1, 0.2, 0.3, 0.6, 0.7, 0.8, 0.9, 0.95]

        chart = plot.pr_curve(y_true, y_probas, title="PR Test")
        result = _assert_valid_plotly(chart)

        # Should have 1 trace (positive class)
        assert len(result["data"]) == 1
        assert "AP=" in result["data"][0]["name"]
        assert result["layout"]["title"]["text"] == "PR Test"
        assert result["layout"]["xaxis"]["title"] == "Recall"
        assert result["layout"]["yaxis"]["title"] == "Precision"

    def test_binary_pr_curve_2d(self) -> None:
        """Binary PR curve with 2D probabilities."""
        y_true = [0, 0, 1, 1]
        y_probas = [[0.9, 0.1], [0.8, 0.2], [0.3, 0.7], [0.1, 0.9]]

        chart = plot.pr_curve(y_true, y_probas)
        result = _assert_valid_plotly(chart)
        assert len(result["data"]) == 1

    def test_multiclass_pr_curve(self) -> None:
        """Multi-class PR curve produces one trace per class."""
        y_true = [0, 0, 1, 1, 2, 2]
        y_probas = [
            [0.8, 0.1, 0.1],
            [0.7, 0.2, 0.1],
            [0.1, 0.8, 0.1],
            [0.2, 0.7, 0.1],
            [0.1, 0.1, 0.8],
            [0.1, 0.2, 0.7],
        ]

        chart = plot.pr_curve(
            y_true, y_probas, labels=["cat", "dog", "bird"]
        )
        result = _assert_valid_plotly(chart)
        assert len(result["data"]) == 3
        assert "cat" in result["data"][0]["name"]
        assert "dog" in result["data"][1]["name"]
        assert "bird" in result["data"][2]["name"]

    def test_pr_curve_custom_labels(self) -> None:
        """Custom labels appear in trace names."""
        y_true = [0, 0, 1, 1]
        y_probas = [0.1, 0.2, 0.8, 0.9]
        chart = plot.pr_curve(
            y_true, y_probas, labels=["Negative", "Positive"]
        )
        result = _assert_valid_plotly(chart)
        assert "Positive" in result["data"][0]["name"]


# ---------------------------------------------------------------------------
# roc_curve()
# ---------------------------------------------------------------------------

class TestROCCurve:
    """Tests for plot.roc_curve()."""

    def test_binary_roc_curve(self) -> None:
        """Binary ROC curve produces valid Plotly output with baseline."""
        y_true = [0, 0, 0, 1, 1, 1, 1, 1]
        y_probas = [0.1, 0.2, 0.3, 0.6, 0.7, 0.8, 0.9, 0.95]

        chart = plot.roc_curve(y_true, y_probas, title="ROC Test")
        result = _assert_valid_plotly(chart)

        # 1 ROC trace + 1 diagonal baseline
        assert len(result["data"]) == 2
        assert "AUC=" in result["data"][0]["name"]

        # Baseline trace
        baseline = result["data"][1]
        assert baseline["x"] == [0, 1]
        assert baseline["y"] == [0, 1]
        assert baseline["line"]["dash"] == "dash"

    def test_binary_roc_curve_2d(self) -> None:
        """Binary ROC curve with 2D probabilities."""
        y_true = [0, 0, 1, 1]
        y_probas = [[0.9, 0.1], [0.8, 0.2], [0.3, 0.7], [0.1, 0.9]]

        chart = plot.roc_curve(y_true, y_probas)
        result = _assert_valid_plotly(chart)
        assert len(result["data"]) == 2  # 1 ROC + 1 baseline

    def test_multiclass_roc_curve(self) -> None:
        """Multi-class ROC curve produces one trace per class + baseline."""
        y_true = [0, 0, 1, 1, 2, 2]
        y_probas = [
            [0.8, 0.1, 0.1],
            [0.7, 0.2, 0.1],
            [0.1, 0.8, 0.1],
            [0.2, 0.7, 0.1],
            [0.1, 0.1, 0.8],
            [0.1, 0.2, 0.7],
        ]

        chart = plot.roc_curve(
            y_true, y_probas, labels=["cat", "dog", "bird"]
        )
        result = _assert_valid_plotly(chart)
        # 3 class traces + 1 baseline
        assert len(result["data"]) == 4
        assert "cat" in result["data"][0]["name"]

    def test_roc_curve_axis_labels(self) -> None:
        """ROC curve has correct axis labels."""
        y_true = [0, 1, 0, 1]
        y_probas = [0.1, 0.9, 0.2, 0.8]
        chart = plot.roc_curve(y_true, y_probas)
        result = _assert_valid_plotly(chart)
        assert result["layout"]["xaxis"]["title"] == "False Positive Rate"
        assert result["layout"]["yaxis"]["title"] == "True Positive Rate"


# ---------------------------------------------------------------------------
# confusion_matrix()
# ---------------------------------------------------------------------------

class TestConfusionMatrix:
    """Tests for plot.confusion_matrix()."""

    def test_basic_confusion_matrix(self) -> None:
        """Confusion matrix heatmap from predictions."""
        y_true = [0, 0, 1, 1, 2, 2]
        y_pred = [0, 1, 1, 1, 2, 0]

        chart = plot.confusion_matrix(
            y_true, y_pred,
            class_names=["cat", "dog", "bird"],
            title="CM Test",
        )
        result = _assert_valid_plotly(chart)

        trace = result["data"][0]
        assert trace["type"] == "heatmap"
        assert trace["x"] == ["cat", "dog", "bird"]
        assert trace["y"] == ["cat", "dog", "bird"]

        # Check matrix values
        # True: [0,0,1,1,2,2] Pred: [0,1,1,1,2,0]
        # class 0: TP=1, FP(->1)=1
        # class 1: TP=2
        # class 2: TP=1, FP(->0)=1
        z = trace["z"]
        assert z[0] == [1, 1, 0]  # true=0: predicted 0 once, 1 once
        assert z[1] == [0, 2, 0]  # true=1: predicted 1 twice
        assert z[2] == [1, 0, 1]  # true=2: predicted 0 once, 2 once

        # Check annotations exist
        assert "annotations" in result["layout"]
        assert len(result["layout"]["annotations"]) == 9  # 3x3

    def test_confusion_matrix_auto_labels(self) -> None:
        """Without class_names, labels are inferred from unique values."""
        y_true = [0, 1, 0, 1]
        y_pred = [0, 0, 1, 1]

        chart = plot.confusion_matrix(y_true, y_pred)
        result = _assert_valid_plotly(chart)

        trace = result["data"][0]
        assert trace["x"] == ["0", "1"]
        assert trace["y"] == ["0", "1"]

    def test_confusion_matrix_annotations(self) -> None:
        """Cell annotations have correct values."""
        y_true = [0, 0, 1, 1]
        y_pred = [0, 0, 0, 1]

        chart = plot.confusion_matrix(
            y_true, y_pred, class_names=["neg", "pos"]
        )
        result = _assert_valid_plotly(chart)

        annotations = result["layout"]["annotations"]
        texts = [a["text"] for a in annotations]
        # CM: [[2,0],[1,1]]
        assert "2" in texts
        assert "1" in texts
        assert "0" in texts

    def test_confusion_matrix_title(self) -> None:
        """Custom title is applied."""
        y_true = [0, 1]
        y_pred = [0, 1]
        chart = plot.confusion_matrix(y_true, y_pred, title="My CM")
        result = _assert_valid_plotly(chart)
        assert result["layout"]["title"]["text"] == "My CM"


# ---------------------------------------------------------------------------
# plot_table()
# ---------------------------------------------------------------------------

class TestPlotTable:
    """Tests for plot.plot_table()."""

    def test_basic_plot_table(self) -> None:
        """plot_table with explicit field mappings."""
        table = _make_table(
            ["epoch", "loss", "acc"],
            [[1, 0.5, 0.8], [2, 0.3, 0.9]],
        )
        chart = plot.plot_table(
            data_table=table,
            fields={"x": "epoch", "y": "loss"},
        )
        result = _assert_valid_plotly(chart)

        trace = result["data"][0]
        assert trace["x"] == [1, 2]
        assert trace["y"] == [0.5, 0.3]

    def test_plot_table_default_columns(self) -> None:
        """plot_table with no fields uses first two columns."""
        table = _make_table(["a", "b"], [[1, 10], [2, 20]])
        chart = plot.plot_table(data_table=table)
        result = _assert_valid_plotly(chart)

        trace = result["data"][0]
        assert trace["x"] == [1, 2]
        assert trace["y"] == [10, 20]

    def test_plot_table_no_table(self) -> None:
        """plot_table without data_table raises ValueError."""
        with pytest.raises(ValueError, match="data_table is required"):
            plot.plot_table()

    def test_plot_table_too_few_columns(self) -> None:
        """plot_table with 1-column table and no fields raises ValueError."""
        table = _make_table(["only"], [[1]])
        with pytest.raises(ValueError, match="at least 2 columns"):
            plot.plot_table(data_table=table)

    def test_plot_table_vega_spec_ignored(self) -> None:
        """vega_spec_name is accepted but ignored (compatibility)."""
        table = _make_table(["x", "y"], [[1, 2]])
        chart = plot.plot_table(
            vega_spec_name="custom_vega_spec",
            data_table=table,
            fields={"x": "x", "y": "y"},
        )
        _assert_valid_plotly(chart)


# ---------------------------------------------------------------------------
# Integration: logging workflow
# ---------------------------------------------------------------------------

class TestPlotIntegration:
    """Integration-style tests verifying charts work with the log pipeline."""

    def test_chart_is_plotly_chart_instance(self) -> None:
        """All plot functions return PlotlyChart instances."""
        table = _make_table(["x", "y"], [[1, 2]])

        assert isinstance(plot.line(table, "x", "y"), PlotlyChart)
        assert isinstance(plot.scatter(table, "x", "y"), PlotlyChart)

        table2 = _make_table(["label", "value"], [["a", 1]])
        assert isinstance(plot.bar(table2, "label", "value"), PlotlyChart)
        assert isinstance(plot.histogram(table2, "value"), PlotlyChart)

    def test_chart_serialization_roundtrip(self) -> None:
        """Chart serializes to JSON-compatible dict and back."""
        table = _make_table(["x", "y"], [[1, 2], [3, 4]])
        chart = plot.line(table, "x", "y", title="Test")
        result = chart._serialize()

        # Full JSON roundtrip
        json_str = json.dumps(result)
        loaded = json.loads(json_str)
        assert loaded["data"][0]["x"] == [1, 3]
        assert loaded["data"][0]["y"] == [2, 4]

    def test_layout_template(self) -> None:
        """All charts use plotly_white template."""
        table = _make_table(["x", "y"], [[1, 2]])
        chart = plot.line(table, "x", "y")
        result = chart._serialize()
        assert result["layout"]["template"] == "plotly_white"
