"""Tests for the SDK alert() method and APIClient.create_alert."""

from __future__ import annotations

import json
import logging

import httpx
import pytest

from openrunner.api_client import APIClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_transport(status_code: int = 201, json_data: dict | None = None):
    """Build an httpx.MockTransport that returns *json_data*."""
    body = json.dumps(json_data or {}).encode()

    def _handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code, content=body)

    return httpx.MockTransport(_handler)


def _capture_transport(status_code: int = 201, json_data: dict | None = None):
    """Build a transport that captures the request for assertion."""
    body = json.dumps(json_data or {}).encode()
    captured = {}

    def _handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(status_code, content=body)

    return httpx.MockTransport(_handler), captured


# ---------------------------------------------------------------------------
# APIClient.create_alert
# ---------------------------------------------------------------------------


class TestCreateAlert:
    def test_sends_post_with_correct_payload(self):
        """create_alert sends POST /runs/{run_id}/alerts with title, text, level."""
        resp_data = {
            "id": "some-uuid",
            "run_id": "abc12345",
            "title": "Loss spike",
            "text": "Loss > 5.0",
            "level": "WARN",
        }
        transport, captured = _capture_transport(201, resp_data)
        client = APIClient("http://localhost:8000", "or_testkey", transport=transport)

        result = client.create_alert(
            "abc12345", title="Loss spike", text="Loss > 5.0", level="WARN"
        )

        assert result == resp_data
        assert captured["method"] == "POST"
        assert "/runs/abc12345/alerts" in captured["url"]
        assert captured["body"]["title"] == "Loss spike"
        assert captured["body"]["text"] == "Loss > 5.0"
        assert captured["body"]["level"] == "WARN"

    def test_default_level_is_info(self):
        """When level is not specified, it defaults to INFO."""
        transport, captured = _capture_transport(201, {"id": "x"})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        client.create_alert("run1", title="Test")

        assert captured["body"]["level"] == "INFO"

    def test_text_omitted_when_none(self):
        """When text is None, the 'text' key is not in the payload."""
        transport, captured = _capture_transport(201, {"id": "x"})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        client.create_alert("run1", title="Test", text=None)

        assert "text" not in captured["body"]

    def test_server_error_returns_none(self, caplog):
        """Server 500 returns None and logs a warning."""
        transport = _mock_transport(500, {"detail": "error"})
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            result = client.create_alert("run1", title="Test")

        assert result is None

    def test_connection_error_returns_none(self, caplog):
        """Network failure returns None, never raises."""
        def _raise(request):
            raise httpx.ConnectError("Connection refused")

        transport = httpx.MockTransport(_raise)
        client = APIClient("http://localhost:8000", "or_k", transport=transport)

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            result = client.create_alert("run1", title="Test")

        assert result is None


# ---------------------------------------------------------------------------
# Run.alert() (via mock)
# ---------------------------------------------------------------------------


class TestRunAlert:
    def test_run_alert_delegates_to_client(self):
        """Run.alert() calls APIClient.create_alert with correct args."""
        from unittest.mock import MagicMock, patch

        from openrunner.run import Run

        resp = {"id": "alert-uuid", "title": "Test", "level": "ERROR"}

        with patch.object(Run, "__init__", lambda self, **kw: None):
            run = Run.__new__(Run)
            run._id = "test-run"
            run._client = MagicMock()
            run._client.create_alert.return_value = resp

            result = run.alert("Test", text="Details", level="ERROR")

        assert result == resp
        run._client.create_alert.assert_called_once_with(
            "test-run", title="Test", text="Details", level="ERROR"
        )

    def test_run_alert_never_raises(self, caplog):
        """Run.alert() catches exceptions and returns None."""
        from unittest.mock import MagicMock, patch

        from openrunner.run import Run

        with patch.object(Run, "__init__", lambda self, **kw: None):
            run = Run.__new__(Run)
            run._id = "test-run"
            run._client = MagicMock()
            run._client.create_alert.side_effect = RuntimeError("boom")

            with caplog.at_level(logging.WARNING, logger="openrunner"):
                result = run.alert("Test")

        assert result is None


# ---------------------------------------------------------------------------
# Module-level openrunner.alert()
# ---------------------------------------------------------------------------


class TestModuleLevelAlert:
    def test_no_active_run_returns_none(self, caplog):
        """openrunner.alert() returns None when no active run."""
        import openrunner

        original = openrunner._active_run
        openrunner._active_run = None

        try:
            with caplog.at_level(logging.WARNING, logger="openrunner"):
                result = openrunner.alert("Test")
            assert result is None
            assert "no active run" in caplog.text
        finally:
            openrunner._active_run = original

    def test_delegates_to_active_run(self):
        """openrunner.alert() delegates to _active_run.alert()."""
        from unittest.mock import MagicMock

        import openrunner

        original = openrunner._active_run
        mock_run = MagicMock()
        mock_run.alert.return_value = {"id": "x"}
        openrunner._active_run = mock_run

        try:
            result = openrunner.alert("Title", text="Body", level="WARN")
            assert result == {"id": "x"}
            mock_run.alert.assert_called_once_with(
                title="Title", text="Body", level="WARN"
            )
        finally:
            openrunner._active_run = original
