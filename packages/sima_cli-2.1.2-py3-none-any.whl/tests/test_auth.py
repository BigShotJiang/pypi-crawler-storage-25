import unittest
from unittest.mock import patch

from sima_cli.auth import devportal


class _FakeCookies:
    def set(self, *args, **kwargs):
        pass


class _FakeSession:
    def __init__(self, response, name="session"):
        self.headers = {}
        self.cookies = _FakeCookies()
        self._response = response
        self.name = name

    def get(self, *args, **kwargs):
        return self._response


class _FakeResponse:
    status_code = 302
    headers = {"Location": "https://docs.sima.ai/login?show-request-form=1"}


class TestDevportalLogin(unittest.TestCase):
    def test_request_access_redirect_does_not_recurse_login(self):
        fake_session = _FakeSession(_FakeResponse())

        with patch.object(devportal.requests, "Session", return_value=fake_session), \
             patch.object(devportal, "get_cached_access_token", return_value="access-token"), \
             patch.object(devportal, "login_external") as login_external:
            session, valid = devportal.validate_session()

        self.assertIs(session, fake_session)
        self.assertFalse(valid)
        login_external.assert_not_called()


if __name__ == "__main__":
    unittest.main()
