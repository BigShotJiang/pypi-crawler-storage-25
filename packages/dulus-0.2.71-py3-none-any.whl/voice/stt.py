"""Speech-to-text (STT) backends.

Backend priority (tried in order):
  1. NVIDIA Riva    — cloud, whisper-large-v3 via gRPC, needs NVIDIA_API_KEY.
                       pip install nvidia-riva-client
  2. faster-whisper — local, offline, fast, best for coding vocab.
                       pip install faster-whisper
  3. openai-whisper — local, offline, original OpenAI Whisper library.
                       pip install openai-whisper
  4. OpenAI Whisper API — cloud, needs OPENAI_API_KEY.
                          pip install openai  (already in requirements)

All backends receive raw PCM (int16, 16 kHz, mono) and return a text string.
Keyterms are passed as initial_prompt to local Whisper backends so that
coding-domain vocabulary (grep, MCP, TypeScript, …) is recognised correctly.
Riva does not accept initial_prompt; keyterms are ignored on that path.
"""

from __future__ import annotations

import io
import os
import struct
import tempfile
from pathlib import Path
from typing import List, Optional

from .recorder import SAMPLE_RATE, CHANNELS, BYTES_PER_SAMPLE

# ── Cached model handles ──────────────────────────────────────────────────

_faster_whisper_model = None
_openai_whisper_model = None
# Serializes the model loader so concurrent callers (e.g. the boot-time
# prewarm thread + the wake-word listener firing on the user's first word)
# don't both fall into the `is None` branch and load the model twice.
_whisper_load_lock = __import__("threading").Lock()


def prewarm_whisper() -> bool:
    """Trigger the local Whisper model load + dummy transcribe.

    Designed to be called from a background thread at REPL boot so the wake
    word + /voice paths are instant on first real audio. Returns True if
    the load completed, False if no local backend is installed.
    """
    try:
        import faster_whisper  # noqa: F401
    except Exception:
        return False
    try:
        _get_faster_whisper_model()
        return True
    except Exception:
        return False

# Model size: "tiny", "base", "small", "medium", "large-v2", "large-v3"
# "base" is a good balance of speed and accuracy for coding dictation.
# Override with env var DULUS_WHISPER_MODEL.
DEFAULT_MODEL_SIZE = os.environ.get("DULUS_WHISPER_MODEL", "medium")

# ── NVIDIA Riva (whisper-large-v3 via NVCF gRPC) ─────────────────────────
RIVA_SERVER       = os.environ.get("DULUS_RIVA_SERVER", "grpc.nvcf.nvidia.com:443")
RIVA_FUNCTION_ID  = os.environ.get("DULUS_RIVA_FUNCTION_ID",
                                   "b702f636-f60c-4a3d-a6f4-f3568c13bd7d")


def _riva_available() -> bool:
    """Riva backend is usable iff the client lib is installed AND we have a key."""
    if not os.environ.get("NVIDIA_API_KEY"):
        return False
    try:
        import riva.client  # noqa: F401
        return True
    except ImportError:
        return False


def _transcribe_nvidia_riva(
    pcm_bytes: bytes,
    language: Optional[str],
    translate: bool = False,
) -> str:
    """Transcribe via NVIDIA NVCF Riva (whisper-large-v3, gRPC).

    Riva expects a real audio container — we wrap raw PCM in WAV.
    `language=None` or "auto" → "multi" (Riva auto-detect).
    `translate=True` adds custom_configuration "task:translate" so foreign
    speech comes back as English.
    """
    import riva.client
    api_key = os.environ["NVIDIA_API_KEY"]
    auth = riva.client.Auth(
        None,             # ssl_cert
        True,             # use_ssl
        RIVA_SERVER,
        [("function-id", RIVA_FUNCTION_ID),
         ("authorization", f"Bearer {api_key}")],
    )
    asr = riva.client.ASRService(auth)
    lang_code = "multi" if (not language or language == "auto") else language
    config = riva.client.RecognitionConfig(
        encoding=riva.client.AudioEncoding.LINEAR_PCM,
        sample_rate_hertz=SAMPLE_RATE,
        audio_channel_count=CHANNELS,
        language_code=lang_code,
        max_alternatives=1,
        enable_automatic_punctuation=True,
    )
    if translate:
        riva.client.add_custom_configuration_to_config(config, "task:translate")
    wav = _pcm_to_wav(pcm_bytes)
    resp = asr.offline_recognize(wav, config)
    parts = []
    for r in resp.results:
        if r.alternatives:
            parts.append(r.alternatives[0].transcript)
    return " ".join(parts).strip()


# ── OGG/audio file → PCM conversion ──────────────────────────────────────

def _audio_file_to_pcm(audio_bytes: bytes, suffix: str = ".ogg") -> bytes:
    """Convert an audio file (OGG, MP3, etc.) to raw int16 PCM (16kHz mono) via ffmpeg."""
    import subprocess
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
        f.write(audio_bytes)
        f.flush()
        tmp_in = f.name
    try:
        r = subprocess.run(
            ["ffmpeg", "-y", "-i", tmp_in, "-f", "s16le", "-ar", str(SAMPLE_RATE),
             "-ac", str(CHANNELS), "-acodec", "pcm_s16le", "-"],
            capture_output=True, timeout=30,
        )
        if r.returncode != 0:
            raise RuntimeError(f"ffmpeg failed: {r.stderr[:200]}")
        return r.stdout
    finally:
        Path(tmp_in).unlink(missing_ok=True)


# ── WAV helper ────────────────────────────────────────────────────────────

def _pcm_to_wav(pcm_bytes: bytes) -> bytes:
    """Wrap raw int16 PCM in a minimal WAV container."""
    num_samples = len(pcm_bytes) // BYTES_PER_SAMPLE
    byte_rate = SAMPLE_RATE * CHANNELS * BYTES_PER_SAMPLE
    block_align = CHANNELS * BYTES_PER_SAMPLE
    data_size = len(pcm_bytes)
    header = struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF",
        36 + data_size,
        b"WAVE",
        b"fmt ",
        16,          # chunk size
        1,           # PCM format
        CHANNELS,
        SAMPLE_RATE,
        byte_rate,
        block_align,
        16,          # bits per sample
        b"data",
        data_size,
    )
    return header + pcm_bytes


# ── Availability ──────────────────────────────────────────────────────────

def check_stt_availability() -> tuple[bool, str | None]:
    """Return (available, reason_if_not)."""
    if _riva_available():
        return True, None
    try:
        import faster_whisper  # noqa: F401
        return True, None
    except ImportError:
        pass
    try:
        import whisper  # noqa: F401
        return True, None
    except ImportError:
        pass
    if os.environ.get("OPENAI_API_KEY"):
        return True, None

    return False, (
        "No STT backend available.\n"
        "Install one of:\n"
        "  pip install nvidia-riva-client  (cloud, whisper-large-v3 — set NVIDIA_API_KEY)\n"
        "  pip install faster-whisper      (local, recommended)\n"
        "  pip install openai-whisper      (local, original)\n"
        "  Set OPENAI_API_KEY to use the OpenAI Whisper cloud API"
    )


def get_stt_backend_name() -> str:
    """Return a human-readable name of the backend that will be used.

    Must match the priority order in ``transcribe()`` — local Whisper
    first, Riva only as a fallback when no local backend is installed.
    """
    try:
        import faster_whisper  # noqa: F401
        return f"faster-whisper ({DEFAULT_MODEL_SIZE}, local)"
    except ImportError:
        pass
    try:
        import whisper  # noqa: F401
        return f"openai-whisper ({DEFAULT_MODEL_SIZE}, local)"
    except ImportError:
        pass
    if _riva_available() and not os.environ.get("DULUS_WAKE_FORCE_LOCAL"):
        return "NVIDIA Riva (whisper-large-v3, cloud)"
    if os.environ.get("OPENAI_API_KEY"):
        return "OpenAI Whisper API"
    return "(none)"


# ── faster-whisper ────────────────────────────────────────────────────────

def _get_faster_whisper_model():
    global _faster_whisper_model
    # Double-checked locking: the unsynchronized peek skips the lock once the
    # model is loaded; concurrent first-callers serialize through the lock
    # and re-check inside it so only one actually runs the loader.
    if _faster_whisper_model is not None:
        return _faster_whisper_model
    with _whisper_load_lock:
        if _faster_whisper_model is not None:
            return _faster_whisper_model
        try:
            import input as _dulus_input
            _dulus_input.safe_print_notification("\n  ⏳ Loading Whisper model (" + DEFAULT_MODEL_SIZE + ")...")
        except Exception:
            pass

        from faster_whisper import WhisperModel
        # Use CPU by default; set device="cuda" if GPU available.
        device = "cuda" if _has_cuda() else "cpu"
        compute = "float16" if device == "cuda" else "int8"
        _faster_whisper_model = WhisperModel(
            DEFAULT_MODEL_SIZE,
            device=device,
            compute_type=compute,
        )
        # NOTE: removed the dummy-silence warm-up transcribe() call. On CPU+int8
        # that pass took several seconds and blocked startup; the first real
        # transcription absorbs the same cost only once, at the moment the user
        # actually speaks — not while they're waiting for the prompt.

        try:
            import input as _dulus_input
            _dulus_input.safe_print_notification("  ✅ Whisper model loaded and ready.\n")
        except Exception:
            pass
    return _faster_whisper_model


def _has_cuda() -> bool:
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        pass
    try:
        import ctranslate2
        return "cuda" in ctranslate2.get_supported_compute_types("cuda")
    except Exception:
        return False


def _transcribe_faster_whisper(
    pcm_bytes: bytes,
    keyterms: List[str],
    language: Optional[str],
) -> str:
    import numpy as np

    model = _get_faster_whisper_model()

    # Convert int16 PCM to float32 normalised array
    audio = np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32) / 32768.0

    initial_prompt = _keyterms_to_prompt(keyterms)
    lang = None if not language or language == "auto" else language

    # Force Spanish context when language is set to "es" — prevents
    # the model from hallucinating English on short wake-word utterances.
    if lang == "es" and not initial_prompt:
        initial_prompt = "Transcripción en español."
    elif lang == "es":
        initial_prompt = "Transcripción en español: " + initial_prompt

    segments, _info = model.transcribe(
        audio,
        language=lang,
        initial_prompt=initial_prompt,
        condition_on_previous_text=False,  # avoid language drift on short audio
        vad_filter=True,          # skip silent regions
        vad_parameters=dict(
            min_silence_duration_ms=300,
        ),
    )
    return " ".join(seg.text for seg in segments).strip()


# ── openai-whisper ────────────────────────────────────────────────────────

def _get_openai_whisper_model():
    global _openai_whisper_model
    if _openai_whisper_model is None:
        import whisper
        _openai_whisper_model = whisper.load_model(DEFAULT_MODEL_SIZE)
    return _openai_whisper_model


def _transcribe_openai_whisper(
    pcm_bytes: bytes,
    keyterms: List[str],
    language: Optional[str],
) -> str:
    import numpy as np

    model = _get_openai_whisper_model()
    audio = np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32) / 32768.0

    initial_prompt = _keyterms_to_prompt(keyterms)

    # Force Spanish context when language is set to "es"
    if language == "es" and not initial_prompt:
        initial_prompt = "Transcripción en español."
    elif language == "es":
        initial_prompt = "Transcripción en español: " + initial_prompt

    options: dict = {"initial_prompt": initial_prompt} if initial_prompt else {}
    if language and language != "auto":
        options["language"] = language

    result = model.transcribe(audio, **options)
    return result.get("text", "").strip()


# ── OpenAI Whisper API ────────────────────────────────────────────────────

def _transcribe_openai_api(
    pcm_bytes: bytes,
    language: Optional[str],
) -> str:
    from openai import OpenAI

    client = OpenAI()  # uses OPENAI_API_KEY from env
    wav = _pcm_to_wav(pcm_bytes)

    kwargs: dict = {"model": "whisper-1", "file": ("audio.wav", io.BytesIO(wav), "audio/wav")}
    if language and language != "auto":
        kwargs["language"] = language

    transcript = client.audio.transcriptions.create(**kwargs)
    return transcript.text.strip()


# ── Keyterms → prompt ─────────────────────────────────────────────────────

def _keyterms_to_prompt(keyterms: List[str]) -> str:
    """Convert a list of keywords into a Whisper initial_prompt string.

    Whisper treats the initial_prompt as preceding context; sprinkling the
    coding vocabulary terms nudges the model to prefer these spellings.
    """
    if not keyterms:
        return ""
    # Keep it short — Whisper truncates at ~224 tokens.
    return ", ".join(keyterms[:40])


# ── Public entry point ────────────────────────────────────────────────────

def transcribe(
    pcm_bytes: bytes,
    keyterms: Optional[List[str]] = None,
    language: str = "auto",
) -> str:
    """Transcribe raw PCM audio to text.

    Args:
        pcm_bytes: Raw int16 PCM, 16 kHz, mono.
        keyterms:  Coding-domain vocabulary hints (improves accuracy).
        language:  BCP-47 language code, or 'auto' for detection.

    Returns:
        Transcribed text, or empty string if audio contains no speech.
    """
    if not pcm_bytes:
        return ""

    terms = keyterms or []
    lang = None if language == "auto" else language

    # faster-whisper (local) — FIRST. Riva (cloud) was previously the
    # default whenever NVIDIA_API_KEY existed, which meant every wake-word
    # audio chunk hit the NVIDIA gRPC endpoint and starved concurrent TLS
    # calls (e.g. /say cold-starts to elevenlabs.io). Local Whisper is
    # ~instant after warm-up and zero-network.
    try:
        import faster_whisper  # noqa: F401
        return _transcribe_faster_whisper(pcm_bytes, terms, lang)
    except ImportError:
        pass

    # NVIDIA Riva (whisper-large-v3, cloud) — opt-in fallback when no local
    # Whisper is installed. Skip if DULUS_WAKE_FORCE_LOCAL is set.
    if _riva_available() and not os.environ.get("DULUS_WAKE_FORCE_LOCAL"):
        try:
            return _transcribe_nvidia_riva(pcm_bytes, lang)
        except Exception as e:
            print(f"  [STT] Riva failed, falling back: {e}")

    # openai-whisper (local, fallback)
    try:
        import whisper  # noqa: F401
        return _transcribe_openai_whisper(pcm_bytes, terms, lang)
    except ImportError:
        pass

    # OpenAI Whisper API (cloud, last resort)
    if os.environ.get("OPENAI_API_KEY"):
        return _transcribe_openai_api(pcm_bytes, lang)

    raise RuntimeError(
        "No STT backend available.\n"
        "Install nvidia-riva-client (set NVIDIA_API_KEY), faster-whisper,\n"
        "or set OPENAI_API_KEY to use the OpenAI Whisper cloud API."
    )


def transcribe_audio_file(
    audio_bytes: bytes,
    suffix: str = ".ogg",
    language: str = "auto",
) -> str:
    """Transcribe an audio file (OGG, MP3, etc.) to text.

    Converts to PCM via ffmpeg, then runs through the STT pipeline.
    Falls back to OpenAI Whisper API (which accepts OGG natively) if
    ffmpeg is not available.
    """
    # Try ffmpeg conversion → local STT
    try:
        pcm = _audio_file_to_pcm(audio_bytes, suffix)
    except (RuntimeError, FileNotFoundError):
        pcm = None

    if pcm is not None:
        try:
            return transcribe(pcm, language=language)
        except RuntimeError:
            pass  # local STT backend failed, fall through to cloud API

    # Fallback: OpenAI Whisper API accepts OGG directly
    if os.environ.get("OPENAI_API_KEY"):
        from openai import OpenAI
        client = OpenAI()
        kwargs: dict = {"model": "whisper-1", "file": (f"audio{suffix}", io.BytesIO(audio_bytes), "audio/ogg")}
        lang = None if language == "auto" else language
        if lang:
            kwargs["language"] = lang
        transcript = client.audio.transcriptions.create(**kwargs)
        return transcript.text.strip()

    raise RuntimeError(
        "Cannot transcribe audio file.\n"
        "Install ffmpeg for local conversion, or set OPENAI_API_KEY for cloud STT."
    )
