"""Experiment creation and management module.

This module provides functions to create new LeCrapaud experiments,
setting up directories, targets, and database records.
"""

import os
from pathlib import Path

import pandas as pd
import joblib
from datetime import datetime

# Set up coverage file path
os.environ["COVERAGE_FILE"] = str(Path(".coverage").resolve())

# Internal imports
from lecrapaud.directories import tmp_dir
from lecrapaud.models import Experiment, Target
from lecrapaud.db.session import get_db
from lecrapaud.services import ArtifactService


def create_experiment(
    data: pd.DataFrame,
    experiment_name: str,
    date_column: str | None = None,
    group_column: str | None = None,
    **kwargs: dict,
) -> "Experiment":
    """Create a new LeCrapaud experiment from data.

    Sets up the experiment directory structure, registers targets in the
    database, and creates the experiment record with associated metadata.

    Args:
        data: Input data as a DataFrame.
        experiment_name: Name for the experiment. A timestamp suffix is
                        added automatically for new experiments.
        date_column: Column name containing dates for time series experiments.
        group_column: Column name for grouping data.
        **kwargs: Additional context parameters. Must include:
            - target_numbers: List of target column indices.
            - target_clf: List of target numbers that are classification tasks.
            - time_series: Whether this is a time series experiment.

            Optional:
            - target_quant: Dict mapping target_number → alpha quantile in [0, 1]
              for quantile regression targets. Targets in this dict are trained
              with pinball loss at the given alpha (objective='quantile' for
              LightGBM, 'reg:quantileerror' for XGBoost, 'Quantile:alpha=q' for
              CatBoost). Hyperopt metric defaults to PINBALL_{round(α*100)}.
            - target_survival: List of target_numbers using survival analysis
              (right-censored, ±duration encoding). Phase 2 — XGBoost only.

    Returns:
        Experiment: The created experiment database record.

    Raises:
        ValueError: If target_numbers or target_clf are not provided,
                   if date_column is missing for time series experiments,
                   or if experiment_name is not provided.

    Example:
        >>> experiment = create_experiment(
        ...     data=df,
        ...     experiment_name="my_experiment",
        ...     target_numbers=[0, 1, 2],
        ...     target_clf=[0],
        ...     target_quant={2: 0.90},  # TARGET_2 = Q90 quantile regression
        ... )
    """
    if "target_numbers" not in kwargs or "target_clf" not in kwargs:
        raise ValueError(
            "You should specify context in kwargs to create experiment. target_clf and target_numbers must be present"
        )

    # Validate target_quant: a dict[int, float] with alphas in (0, 1).
    target_quant = kwargs.get("target_quant", {}) or {}
    if not isinstance(target_quant, dict):
        raise ValueError(
            f"target_quant must be a dict[int, float], got {type(target_quant).__name__}"
        )
    for tn, alpha in target_quant.items():
        if not isinstance(tn, int):
            raise ValueError(f"target_quant keys must be int target numbers, got {tn!r}")
        if not (0 < alpha < 1):
            raise ValueError(
                f"target_quant alphas must be strictly between 0 and 1, "
                f"got alpha={alpha} for target {tn}"
            )
    # A target cannot be both classification and quantile.
    target_clf = set(kwargs.get("target_clf", []) or [])
    overlap = target_clf & set(target_quant.keys())
    if overlap:
        raise ValueError(
            f"Targets {sorted(overlap)} appear in both target_clf and target_quant. "
            "A target must have exactly one type."
        )

    # Validate target_survival: list[int], no overlap with target_clf or target_quant.
    target_survival = kwargs.get("target_survival") or []
    if not isinstance(target_survival, list):
        raise ValueError(
            f"target_survival must be a list[int], got {type(target_survival).__name__}"
        )
    target_survival_set = set(target_survival)
    for tn in target_survival_set:
        if not isinstance(tn, int):
            raise ValueError(f"target_survival entries must be int, got {tn!r}")
    overlap_clf = target_clf & target_survival_set
    overlap_quant = set(target_quant.keys()) & target_survival_set
    if overlap_clf or overlap_quant:
        raise ValueError(
            f"target_survival overlaps with other type lists "
            f"(target_clf={sorted(overlap_clf)}, target_quant={sorted(overlap_quant)}). "
            "A target must have exactly one type."
        )

    # Validate target_ranking. Two accepted forms:
    #   - list[int]                — uses `date_column` as query group (default).
    #   - dict[int, str]           — explicit query-group column per target,
    #                                useful if you want to group differently
    #                                than by date (e.g. by sector within date).
    # Each entry's group column becomes a query group for the learning-to-rank
    # objective (lambdarank / rank:ndcg / YetiRankPairwise).
    target_ranking = kwargs.get("target_ranking") or []
    if isinstance(target_ranking, dict):
        target_ranking_set = set(target_ranking.keys())
        for tn, col in target_ranking.items():
            if not isinstance(tn, int):
                raise ValueError(f"target_ranking keys must be int, got {tn!r}")
            if not isinstance(col, str) or not col:
                raise ValueError(
                    f"target_ranking value for target {tn} must be a non-empty "
                    f"column name string, got {col!r}"
                )
    elif isinstance(target_ranking, list):
        target_ranking_set = set(target_ranking)
        for tn in target_ranking_set:
            if not isinstance(tn, int):
                raise ValueError(f"target_ranking entries must be int, got {tn!r}")
        if target_ranking_set and not date_column:
            raise ValueError(
                "target_ranking (list form) requires date_column to be set — "
                "each DATE becomes a query group. Pass dict form "
                "{target_number: group_column} to use a different column."
            )
    else:
        raise ValueError(
            f"target_ranking must be a list[int] or dict[int, str], "
            f"got {type(target_ranking).__name__}"
        )
    overlap_clf_r = target_clf & target_ranking_set
    overlap_quant_r = set(target_quant.keys()) & target_ranking_set
    overlap_surv_r = target_survival_set & target_ranking_set
    if overlap_clf_r or overlap_quant_r or overlap_surv_r:
        raise ValueError(
            f"target_ranking overlaps with other type lists "
            f"(target_clf={sorted(overlap_clf_r)}, "
            f"target_quant={sorted(overlap_quant_r)}, "
            f"target_survival={sorted(overlap_surv_r)}). "
            "A target must have exactly one type."
        )

    if isinstance(data, str):
        raise ValueError("Loading experiments from file path is no longer supported. Pass a DataFrame directly.")

    experiment_name = f"{experiment_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    if kwargs.get("time_series") and not date_column:
        raise ValueError("date_column must be provided for time series experiments")

    if experiment_name is None:
        raise ValueError("experiment_name must be provided")

    dates = {}
    if date_column:
        dates["start_date"] = pd.to_datetime(data[date_column].iat[0])
        dates["end_date"] = pd.to_datetime(data[date_column].iat[-1])

    groups = {}
    if group_column:
        groups["number_of_groups"] = data[group_column].nunique()
        groups["list_of_groups"] = sorted(data[group_column].unique().tolist())

    with get_db() as db:
        all_targets = Target.get_all(db=db)
        targets = [
            target
            for target in all_targets
            if int(target.name.split("_")[-1]) in kwargs["target_numbers"]
        ]
        number_of_targets = len(targets)

        # Historical: every experiment used to get a per-experiment
        # directory at `tmp/<experiment_name>/` to hold scalers, models
        # and predictions on disk. The file→DB migration moved all
        # artifacts into `ExperimentArtifact` rows, so the directory is
        # now never written to. We keep computing `experiment.path` for
        # backwards compatibility with old DB rows (and the alembic
        # migration script that walks them), but no longer `mkdir` it.
        experiment_dir = f"{tmp_dir}/{experiment_name}"

        # Create or update experiment (without targets relation)
        experiment = Experiment.upsert(
            db=db,
            name=experiment_name,
            path=str(Path(experiment_dir).resolve()),
            size=data.shape[0],
            number_of_targets=number_of_targets,
            **groups,
            **dates,
            context={
                "date_column": date_column,
                "group_column": group_column,
                "experiment_name": experiment_name,
                **kwargs,
            },
        )

        # Set targets relationship after creation/update
        experiment.targets = targets
        experiment.save(db=db)

        return experiment
