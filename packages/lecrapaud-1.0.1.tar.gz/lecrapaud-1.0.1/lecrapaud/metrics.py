"""Metric callables for hyperopt and evaluation.

Centralises sklearn / domain-specific metric computations so callers can
look up `compute_metric(name, y_true, y_pred, ...)` without repeating the
sklearn import + parameter wrangling.

Supports the metrics declared in `lecrapaud.utils.METRICS_CONFIG`:
- Classification: LOGLOSS, ROC_AUC, AVG_PRECISION (alias PR_AUC),
  ACCURACY, PRECISION, RECALL, F1
- Regression: RMSE, MAE, MAPE, R2, HUBER
- Quantile: PINBALL_{10,25,50,75,90}
- Survival: CONCORDANCE_INDEX, IBS  (Phase 2 — requires lifelines)
"""

from typing import Optional

import numpy as np
from sklearn.metrics import (
    log_loss,
    roc_auc_score,
    average_precision_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    mean_squared_error,
    mean_absolute_error,
    mean_absolute_percentage_error,
    r2_score,
    mean_pinball_loss,
)

from lecrapaud.utils import METRICS_CONFIG


def _huber_loss(y_true, y_pred, delta: float = 1.0) -> float:
    """Mean Huber loss with configurable delta.

    Quadratic for |residual| ≤ delta, linear above. Default δ=1.0 matches
    the sklearn convention; tune delta to the target's typical scale if
    used for hyperopt comparisons across different targets.
    """
    residuals = np.asarray(y_true) - np.asarray(y_pred)
    abs_r = np.abs(residuals)
    quad = np.minimum(abs_r, delta)
    lin = abs_r - quad
    return float(np.mean(0.5 * quad ** 2 + delta * lin))


def _pinball_for_alpha(alpha: float):
    """Build a pinball-loss callable bound to a specific alpha."""
    def _f(y_true, y_pred) -> float:
        return float(mean_pinball_loss(y_true, y_pred, alpha=alpha))
    return _f


def compute_metric(
    metric: str,
    y_true,
    y_pred,
    *,
    y_pred_proba=None,
    delta: float = 1.0,
    average: str = "binary",
    groups=None,
) -> float:
    """Compute a metric value by name.

    Args:
        metric: Metric name as registered in METRICS_CONFIG.
        y_true: Ground-truth labels / values.
        y_pred: Hard predictions for classification, point predictions for
            regression / quantile.
        y_pred_proba: Class probabilities (shape: [n_samples, n_classes]).
            Required for LOGLOSS, ROC_AUC, AVG_PRECISION/PR_AUC.
        delta: Threshold for HUBER metric (ignored for others).
        average: Averaging mode for PRECISION / RECALL / F1 (sklearn convention).
        groups: Per-row group id array — required for ranking metrics
            (NDCG, RANK_IC, RANK_IC_IR, TOP_BOTTOM_SPREAD). Each row's group
            id determines its query; metrics are aggregated across queries.

    Returns:
        The computed scalar metric value.

    Raises:
        ValueError: if `metric` is unknown or required inputs are missing.
    """
    if metric not in METRICS_CONFIG:
        raise ValueError(
            f"Unknown metric: {metric!r}. "
            f"Valid metrics: {sorted(METRICS_CONFIG.keys())}"
        )

    # Classification metrics needing probabilities
    if metric == "LOGLOSS":
        if y_pred_proba is None:
            raise ValueError("LOGLOSS requires y_pred_proba")
        return float(log_loss(y_true, y_pred_proba))
    if metric == "ROC_AUC":
        if y_pred_proba is None:
            raise ValueError("ROC_AUC requires y_pred_proba")
        # sklearn handles binary (n_classes=2 → score on positive class) and
        # multiclass (one-vs-rest) automatically when shape matches.
        return float(roc_auc_score(y_true, y_pred_proba, multi_class="ovr"))
    if metric in ("AVG_PRECISION", "PR_AUC"):
        if y_pred_proba is None:
            raise ValueError(f"{metric} requires y_pred_proba")
        # Binary case: pass positive-class probabilities only.
        proba = np.asarray(y_pred_proba)
        if proba.ndim == 2 and proba.shape[1] == 2:
            proba = proba[:, 1]
        return float(average_precision_score(y_true, proba))

    # Classification metrics on hard labels
    if metric == "ACCURACY":
        return float(accuracy_score(y_true, y_pred))
    if metric == "PRECISION":
        return float(precision_score(y_true, y_pred, average=average, zero_division=0))
    if metric == "RECALL":
        return float(recall_score(y_true, y_pred, average=average, zero_division=0))
    if metric == "F1":
        return float(f1_score(y_true, y_pred, average=average, zero_division=0))

    # Regression metrics
    if metric == "RMSE":
        return float(np.sqrt(mean_squared_error(y_true, y_pred)))
    if metric == "MAE":
        return float(mean_absolute_error(y_true, y_pred))
    if metric == "MAPE":
        return float(mean_absolute_percentage_error(y_true, y_pred))
    if metric == "R2":
        return float(r2_score(y_true, y_pred))
    if metric == "HUBER":
        return _huber_loss(y_true, y_pred, delta=delta)

    # Quantile metrics — alpha is encoded in the metric name and stored on
    # METRICS_CONFIG[metric]["alpha"] for direct lookup.
    if metric.startswith("PINBALL_"):
        alpha = METRICS_CONFIG[metric].get("alpha")
        if alpha is None:
            raise ValueError(f"PINBALL metric {metric!r} has no alpha in METRICS_CONFIG")
        return float(mean_pinball_loss(y_true, y_pred, alpha=alpha))

    # Survival metrics — Phase 2.
    if metric == "CONCORDANCE_INDEX":
        return _concordance_index_signed_duration(y_true, y_pred)
    if metric == "IBS":
        raise NotImplementedError(
            "IBS (integrated Brier score) is reserved for survival Phase 2 "
            "and not yet implemented."
        )

    # Ranking metrics — Phase 3. All require `groups` (an array of per-row
    # group ids, e.g. dates) to compute per-query aggregations.
    if metric.startswith("NDCG_AT_") or metric in ("RANK_IC", "RANK_IC_IR", "TOP_BOTTOM_SPREAD"):
        return _ranking_metric(metric, y_true, y_pred, groups=groups)

    raise ValueError(f"No implementation registered for metric {metric!r}")


def _ranking_metric(
    metric: str,
    y_true,
    y_pred,
    *,
    groups=None,
) -> float:
    """Compute a ranking metric aggregated across query groups.

    Args:
        metric: NDCG_AT_K / RANK_IC / RANK_IC_IR / TOP_BOTTOM_SPREAD.
        y_true: ground-truth scores per row (e.g. forward returns or relevance).
        y_pred: model's predicted scores per row.
        groups: per-row group identifier (e.g. date). Required.
            All rows with the same `groups[i]` are scored together as one query.

    Returns:
        Aggregated metric value (mean across groups for NDCG/IC,
        mean/std for IC_IR, top-bottom-decile spread mean for SPREAD).
    """
    if groups is None:
        raise ValueError(
            f"{metric!r} requires `groups` (per-row group ids). "
            "Pass groups=df[date_column].values when calling compute_metric."
        )
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    groups = np.asarray(groups)

    if metric.startswith("NDCG_AT_"):
        from lecrapaud.utils import METRICS_CONFIG
        from sklearn.metrics import ndcg_score
        k = METRICS_CONFIG[metric].get("k")
        if k is None:
            raise ValueError(f"NDCG metric {metric!r} has no `k` in METRICS_CONFIG")
        # Per-group NDCG; average across groups.
        scores = []
        for g in np.unique(groups):
            mask = groups == g
            if mask.sum() < 2:
                continue
            yt = y_true[mask].reshape(1, -1)
            yp = y_pred[mask].reshape(1, -1)
            # ndcg_score requires non-negative relevance scores; shift if needed.
            yt_shifted = yt - yt.min() if yt.min() < 0 else yt
            scores.append(ndcg_score(yt_shifted, yp, k=min(k, mask.sum())))
        if not scores:
            return float("nan")
        return float(np.mean(scores))

    if metric in ("RANK_IC", "RANK_IC_IR"):
        # Per-group Spearman rank correlation between y_true and y_pred,
        # then mean (RANK_IC) or mean / std (RANK_IC_IR) across groups.
        from scipy.stats import spearmanr
        ics = []
        for g in np.unique(groups):
            mask = groups == g
            if mask.sum() < 2:
                continue
            corr, _ = spearmanr(y_true[mask], y_pred[mask])
            if not np.isnan(corr):
                ics.append(corr)
        if not ics:
            return float("nan")
        ics = np.asarray(ics)
        if metric == "RANK_IC":
            return float(ics.mean())
        # RANK_IC_IR — Information Ratio of the IC series. Standard quant
        # finance convention: mean / std (no annualisation here, the caller
        # applies √252 if needed).
        std = ics.std()
        if std == 0:
            return float("nan")
        return float(ics.mean() / std)

    if metric == "TOP_BOTTOM_SPREAD":
        # Per group: rank by y_pred, take top decile vs bottom decile of y_true,
        # report mean(top_decile_return) − mean(bottom_decile_return).
        # Mean across groups.
        spreads = []
        for g in np.unique(groups):
            mask = groups == g
            if mask.sum() < 10:  # need ≥10 to compute deciles meaningfully
                continue
            yt = y_true[mask]
            yp = y_pred[mask]
            order = np.argsort(yp)[::-1]  # descending
            n = len(order)
            top_n = max(1, n // 10)
            top_idx = order[:top_n]
            bot_idx = order[-top_n:]
            spreads.append(yt[top_idx].mean() - yt[bot_idx].mean())
        if not spreads:
            return float("nan")
        return float(np.mean(spreads))

    raise ValueError(f"Unknown ranking metric {metric!r}")


def _concordance_index_signed_duration(y_true, y_pred) -> float:
    """Harrell's concordance index on signed-duration survival labels.

    Convention (matches XGBoost `survival:cox` data format):
        |y_true| = duration ; sign(y_true) = event flag
            +duration → event observed at that time
            -duration → right-censored at that time

    `y_pred` is the model's risk score (higher = higher hazard, i.e. shorter
    expected survival). For each pair (i, j) where subject i had the event
    *before* subject j was last observed, we ask whether risk_i > risk_j.

    Returns:
        c ∈ [0, 1]. 0.5 = no discrimination; 1.0 = perfect ordering.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)

    durations = np.abs(y_true)
    events = y_true > 0  # True if event observed; False if censored

    n = len(y_true)
    if n < 2:
        return float("nan")

    concordant = 0.0
    comparable = 0
    for i in range(n):
        if not events[i]:
            # Censored subjects can never be the "earlier event" in a pair.
            continue
        for j in range(n):
            if i == j:
                continue
            # Pair is comparable if i had the event strictly before j was last seen.
            # When durations are tied, only count if both events observed.
            if durations[j] > durations[i] or (
                durations[j] == durations[i] and events[j] and j > i
            ):
                comparable += 1
                if y_pred[i] > y_pred[j]:
                    concordant += 1.0
                elif y_pred[i] == y_pred[j]:
                    concordant += 0.5

    if comparable == 0:
        return float("nan")
    return concordant / comparable


def get_pinball_alpha(metric: str) -> Optional[float]:
    """Return the alpha quantile encoded in a PINBALL_* metric name, or None."""
    if not metric.startswith("PINBALL_"):
        return None
    return METRICS_CONFIG.get(metric, {}).get("alpha")
