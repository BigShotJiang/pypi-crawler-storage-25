"""sklearn-style wrappers for deep learning tabular models.

Exposes TabNet (via pytorch-tabnet) and FT-Transformer (via
rtdl-revisiting-models) behind a common `fit(X, y, sample_weight=None)` /
`predict(X)` / `predict_proba(X)` API so they plug into LeCrapaudModel's
existing `fit_sklearn` path without any special-casing.

Both are **tabular** models — they take 2D `(n_samples, n_features)` input,
not the 3D `(samples, timesteps, features)` shape that the recurrent /
sequence models in `torch_models.py` consume.
"""
from __future__ import annotations

from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import pytorch_lightning as pl
from sklearn.base import BaseEstimator, ClassifierMixin, RegressorMixin
from torch.utils.data import DataLoader, TensorDataset


# ─── Common ──────────────────────────────────────────────────────────────


_DEFAULT_DEVICE = "cpu"


def _to_2d(X):
    """Cast X to a contiguous float32 numpy array of shape (n, p)."""
    arr = X.values if hasattr(X, "values") else np.asarray(X)
    if arr.ndim != 2:
        raise ValueError(f"Expected 2D input, got shape {arr.shape}")
    return np.ascontiguousarray(arr, dtype=np.float32)


def _to_1d(y):
    """Cast y to a 1D numpy array."""
    arr = y.values if hasattr(y, "values") else np.asarray(y)
    return arr.ravel()


# ─── TabNet (Arik & Pfister 2019) ────────────────────────────────────────


class _TabNetBase(BaseEstimator):
    """Common sklearn-style wrapper around pytorch-tabnet's models.

    Hides the eval_set / max_epochs / batch_size dance behind `fit(X, y)`
    so the wrapper plugs straight into `LeCrapaudModel.fit_sklearn` like
    any sklearn estimator.
    """

    def __init__(
        self,
        n_d: int = 8,
        n_a: int = 8,
        n_steps: int = 3,
        gamma: float = 1.3,
        lambda_sparse: float = 1e-3,
        mask_type: str = "entmax",
        max_epochs: int = 50,
        patience: int = 10,
        batch_size: int = 256,
        virtual_batch_size: int = 128,
        learning_rate: float = 2e-2,
        random_state: int = 42,
    ):
        self.n_d = n_d
        self.n_a = n_a
        self.n_steps = n_steps
        self.gamma = gamma
        self.lambda_sparse = lambda_sparse
        self.mask_type = mask_type
        self.max_epochs = max_epochs
        self.patience = patience
        self.batch_size = batch_size
        self.virtual_batch_size = virtual_batch_size
        self.learning_rate = learning_rate
        self.random_state = random_state

    def _instantiate_tabnet(self, model_cls):
        return model_cls(
            n_d=self.n_d,
            n_a=self.n_a,
            n_steps=self.n_steps,
            gamma=self.gamma,
            lambda_sparse=self.lambda_sparse,
            mask_type=self.mask_type,
            optimizer_fn=torch.optim.Adam,
            optimizer_params=dict(lr=self.learning_rate),
            seed=self.random_state,
            verbose=0,
            device_name=_DEFAULT_DEVICE,
        )

    def _common_fit(self, model, X, y, eval_metric=None):
        X = _to_2d(X)
        y = _to_1d(y)
        model.fit(
            X,
            y,
            max_epochs=self.max_epochs,
            patience=self.patience,
            batch_size=self.batch_size,
            virtual_batch_size=min(self.virtual_batch_size, self.batch_size),
            num_workers=0,
            drop_last=False,
        )
        self._tabnet_model = model
        return self


class TabNetClassifierWrapper(_TabNetBase, ClassifierMixin):
    """sklearn-style binary/multiclass classifier backed by TabNet."""

    def fit(self, X, y, sample_weight: Optional[np.ndarray] = None):
        # pytorch-tabnet doesn't accept sample_weight; ignore silently.
        from pytorch_tabnet.tab_model import TabNetClassifier

        model = self._instantiate_tabnet(TabNetClassifier)
        self._common_fit(model, X, y)
        self.classes_ = model.classes_
        return self

    def predict(self, X):
        return self._tabnet_model.predict(_to_2d(X))

    def predict_proba(self, X):
        return self._tabnet_model.predict_proba(_to_2d(X))

    def get_params(self, deep=True):
        return {
            k: v for k, v in vars(self).items()
            if not k.startswith("_") and k != "classes_"
        }


class TabNetRegressorWrapper(_TabNetBase, RegressorMixin):
    """sklearn-style regressor backed by TabNet."""

    def fit(self, X, y, sample_weight: Optional[np.ndarray] = None):
        from pytorch_tabnet.tab_model import TabNetRegressor

        model = self._instantiate_tabnet(TabNetRegressor)
        X = _to_2d(X)
        y = _to_1d(y).reshape(-1, 1).astype(np.float32)  # TabNetReg needs 2D y
        model.fit(
            X,
            y,
            max_epochs=self.max_epochs,
            patience=self.patience,
            batch_size=self.batch_size,
            virtual_batch_size=min(self.virtual_batch_size, self.batch_size),
            num_workers=0,
            drop_last=False,
        )
        self._tabnet_model = model
        return self

    def predict(self, X):
        return self._tabnet_model.predict(_to_2d(X)).ravel()

    def get_params(self, deep=True):
        return {
            k: v for k, v in vars(self).items()
            if not k.startswith("_")
        }


# ─── FT-Transformer (Gorishniy et al. 2021) ──────────────────────────────


class _FTLightning(pl.LightningModule):
    """Lightning module wrapping an `rtdl_revisiting_models.FTTransformer`.

    Plugs the FT-Transformer's `nn.Module` into a thin training step /
    loss / optimizer combo. Numeric features only — categorical inputs are
    not exposed by the sklearn-style wrapper.
    """

    def __init__(
        self,
        model: nn.Module,
        target_type: str,
        num_class: int | None,
        learning_rate: float,
        weight_decay: float,
    ):
        super().__init__()
        self.model = model
        self.target_type = target_type
        self.num_class = num_class
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        if target_type == "regression":
            self._loss = nn.MSELoss()
        elif num_class is not None and num_class > 2:
            self._loss = nn.CrossEntropyLoss()
        else:
            self._loss = nn.BCEWithLogitsLoss()

    def forward(self, x_num):
        # rtdl FT-Transformer expects (x_cont, x_cat) — we pass only cont
        return self.model(x_num, None)

    def training_step(self, batch, batch_idx):
        x, y = batch
        out = self.forward(x).squeeze(-1)
        if self.target_type == "classification" and (self.num_class or 0) > 2:
            loss = self._loss(out, y.long())
        else:
            loss = self._loss(out, y.float())
        self.log("train_loss", loss, on_epoch=True, on_step=False)
        return loss

    def configure_optimizers(self):
        return torch.optim.AdamW(
            self.parameters(),
            lr=self.learning_rate,
            weight_decay=self.weight_decay,
        )


class _FTTransformerBase(BaseEstimator):
    """Common sklearn-style wrapper around rtdl-revisiting-models FT-Transformer."""

    def __init__(
        self,
        d_token: int = 64,
        n_blocks: int = 3,
        attention_n_heads: int = 8,
        ffn_d_hidden_multiplier: float = 4 / 3,
        attention_dropout: float = 0.2,
        ffn_dropout: float = 0.1,
        residual_dropout: float = 0.0,
        max_epochs: int = 30,
        batch_size: int = 256,
        learning_rate: float = 1e-4,
        weight_decay: float = 1e-5,
        random_state: int = 42,
    ):
        self.d_token = d_token
        self.n_blocks = n_blocks
        self.attention_n_heads = attention_n_heads
        self.ffn_d_hidden_multiplier = ffn_d_hidden_multiplier
        self.attention_dropout = attention_dropout
        self.ffn_dropout = ffn_dropout
        self.residual_dropout = residual_dropout
        self.max_epochs = max_epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.random_state = random_state

    def _build_model(self, n_features: int, d_out: int) -> nn.Module:
        from rtdl_revisiting_models import FTTransformer

        # rtdl exposes `ffn_d_hidden=None` + `ffn_d_hidden_multiplier=…` so
        # the hidden dim is computed as `d_block * multiplier`. Don't pass
        # an explicit `ffn_d_hidden` value (would conflict).
        return FTTransformer(
            n_cont_features=n_features,
            cat_cardinalities=[],
            d_out=d_out,
            n_blocks=self.n_blocks,
            d_block=self.d_token,
            attention_n_heads=self.attention_n_heads,
            attention_dropout=self.attention_dropout,
            ffn_d_hidden=None,
            ffn_d_hidden_multiplier=self.ffn_d_hidden_multiplier,
            ffn_dropout=self.ffn_dropout,
            residual_dropout=self.residual_dropout,
        )

    def _fit_lightning(
        self,
        X,
        y,
        target_type: str,
        num_class: int | None,
    ):
        X = _to_2d(X)
        y_arr = _to_1d(y).astype(np.float32)
        d_out = num_class if (target_type == "classification" and (num_class or 0) > 2) else 1

        torch.manual_seed(self.random_state)
        backbone = self._build_model(n_features=X.shape[1], d_out=d_out)
        module = _FTLightning(
            model=backbone,
            target_type=target_type,
            num_class=num_class,
            learning_rate=self.learning_rate,
            weight_decay=self.weight_decay,
        )

        loader = DataLoader(
            TensorDataset(
                torch.tensor(X), torch.tensor(y_arr, dtype=torch.float32)
            ),
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=0,
        )
        trainer = pl.Trainer(
            max_epochs=self.max_epochs,
            enable_progress_bar=False,
            enable_model_summary=False,
            logger=False,
            enable_checkpointing=False,
            accelerator="cpu",
        )
        trainer.fit(module, loader)
        self._ft_module = module
        return self


class FTTransformerClassifierWrapper(_FTTransformerBase, ClassifierMixin):
    """sklearn-style classifier backed by FT-Transformer."""

    def fit(self, X, y, sample_weight: Optional[np.ndarray] = None):
        y_arr = _to_1d(y)
        self.classes_ = np.unique(y_arr)
        num_class = len(self.classes_)
        self._fit_lightning(X, y_arr, "classification", num_class)
        return self

    def predict_proba(self, X):
        self._ft_module.eval()
        with torch.no_grad():
            out = self._ft_module(torch.tensor(_to_2d(X)))
            if (len(self.classes_) or 0) > 2:
                probs = torch.softmax(out, dim=-1).cpu().numpy()
            else:
                p = torch.sigmoid(out.squeeze(-1)).cpu().numpy()
                probs = np.stack([1 - p, p], axis=1)
        return probs

    def predict(self, X):
        probs = self.predict_proba(X)
        return self.classes_[np.argmax(probs, axis=1)]

    def get_params(self, deep=True):
        return {
            k: v for k, v in vars(self).items()
            if not k.startswith("_") and k != "classes_"
        }


class FTTransformerRegressorWrapper(_FTTransformerBase, RegressorMixin):
    """sklearn-style regressor backed by FT-Transformer."""

    def fit(self, X, y, sample_weight: Optional[np.ndarray] = None):
        self._fit_lightning(X, y, "regression", None)
        return self

    def predict(self, X):
        self._ft_module.eval()
        with torch.no_grad():
            out = self._ft_module(torch.tensor(_to_2d(X))).squeeze(-1)
        return out.cpu().numpy()

    def get_params(self, deep=True):
        return {
            k: v for k, v in vars(self).items()
            if not k.startswith("_")
        }
