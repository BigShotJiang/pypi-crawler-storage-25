"""PyTorch / Lightning implementations of every recurrent / sequence model.

This module replaces the previous Keras/TensorFlow stack. All recurrent and
transformer architectures live here as small `nn.Module` builders, plus a
shared `LeCrapaudLightningModule` that exposes a Keras-style training loop
to `LeCrapaudModel.fit_recurrent()`.

Why not use Keras 3 + torch backend? We wanted native PyTorch code so we can
(a) save weights with safetensors instead of pickle, (b) drop the heavy
TensorFlow dependency entirely (~1.1 GB), and (c) integrate naturally with
the broader PyTorch tabular DL ecosystem (pytorch-tabnet, rtdl).

Each architecture is registered via `@register_torch_model("NAME")` and the
public `build_torch_model(name)` factory returns a callable with signature

    (params: dict, input_shape: tuple[int, int],
     target_type: str, num_class: int | None) -> nn.Module

The signature mirrors the old Keras `get_model_constructor` return so that
`search_space.dl_recurrent_models` entries stay shape-compatible.
"""
from __future__ import annotations

import math
from typing import Callable, Dict, Optional

import numpy as np
import pytorch_lightning as pl
import torch
import torch.nn as nn
import torch.nn.functional as F


# ─── Registry ──────────────────────────────────────────────────────────

_TORCH_BUILDERS: Dict[str, Callable] = {}


def register_torch_model(name: str) -> Callable:
    """Decorator: register an `nn.Module` builder under a model name."""

    def decorator(fn: Callable) -> Callable:
        if name in _TORCH_BUILDERS:
            raise ValueError(f"torch model {name!r} already registered")
        _TORCH_BUILDERS[name] = fn
        return fn

    return decorator


def list_torch_recurrent_models() -> list[str]:
    return sorted(_TORCH_BUILDERS)


# ─── Positional encoding ───────────────────────────────────────────────

class PositionalEncoding(nn.Module):
    """Fixed sinusoidal positional encoding (Vaswani 2017).

    Computed once and stored as a non-trainable buffer; broadcasts over
    the batch dimension at every forward pass.
    """

    def __init__(self, num_timesteps: int, dim: int):
        super().__init__()
        pe = torch.zeros(num_timesteps, dim)
        pos = torch.arange(num_timesteps, dtype=torch.float32).unsqueeze(1)
        div = torch.exp(
            torch.arange(0, dim, 2, dtype=torch.float32) * (-math.log(10000.0) / dim)
        )
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div[: pe.shape[1] // 2 + dim % 2])[
            :, : pe.shape[1] - pe.shape[1] // 2
        ]
        self.register_buffer("pe", pe.unsqueeze(0))  # (1, T, d)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, T, d)
        return x + self.pe[:, : x.size(1), : x.size(2)]


# ─── Causal Conv1d for TCN ─────────────────────────────────────────────

class _CausalConv1d(nn.Module):
    """1D conv with left-only padding so output[t] only depends on input[<=t]."""

    def __init__(self, in_ch: int, out_ch: int, kernel_size: int, dilation: int = 1):
        super().__init__()
        self.pad_left = (kernel_size - 1) * dilation
        self.conv = nn.Conv1d(in_ch, out_ch, kernel_size, dilation=dilation)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, channels, time)
        x = F.pad(x, (self.pad_left, 0))
        return self.conv(x)


class _TCNBlock(nn.Module):
    """One residual TCN block: causal conv → ReLU → dropout → causal conv → +residual."""

    def __init__(
        self,
        in_ch: int,
        out_ch: int,
        kernel_size: int,
        dilation: int,
        dropout: float,
    ):
        super().__init__()
        self.conv1 = _CausalConv1d(in_ch, out_ch, kernel_size, dilation)
        self.conv2 = _CausalConv1d(out_ch, out_ch, kernel_size, dilation)
        self.dropout = nn.Dropout(dropout)
        self.proj = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.dropout(F.relu(self.conv1(x)))
        out = self.dropout(F.relu(self.conv2(out)))
        return out + self.proj(x)


# ─── Helpers ───────────────────────────────────────────────────────────

def _last_step(x: torch.Tensor) -> torch.Tensor:
    """Take the final timestep of (batch, T, d) -> (batch, d)."""
    return x[:, -1, :]


def _mean_pool(x: torch.Tensor) -> torch.Tensor:
    """Global average pool over time of (batch, T, d) -> (batch, d)."""
    return x.mean(dim=1)


# ─── Body builders ─────────────────────────────────────────────────────

class _Lambda(nn.Module):
    """Wrap a stateless function as an nn.Module — for chaining in Sequential."""

    def __init__(self, fn: Callable):
        super().__init__()
        self.fn = fn

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fn(x)


def _stacked_rnn(
    rnn_cls,
    in_size: int,
    hidden_size: int,
    num_layers: int,
    bidirectional: bool,
    dropout: float,
) -> nn.Module:
    """Build a stacked LSTM/GRU + last-timestep extractor."""
    rnn = rnn_cls(
        input_size=in_size,
        hidden_size=hidden_size,
        num_layers=num_layers,
        batch_first=True,
        bidirectional=bidirectional,
        dropout=dropout if num_layers > 1 else 0.0,
    )

    class _RNNBody(nn.Module):
        def __init__(self, rnn: nn.Module):
            super().__init__()
            self.rnn = rnn

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            out, _ = self.rnn(x)
            return _last_step(out)

    return _RNNBody(rnn)


@register_torch_model("LSTM")
def _build_lstm(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    p = params["model_params"]
    return _stacked_rnn(
        nn.LSTM,
        in_size=in_dim,
        hidden_size=p["units"],
        num_layers=params["num_layers"],
        bidirectional=False,
        dropout=p.get("dropout", 0.0),
    )


@register_torch_model("BiLSTM")
def _build_bilstm(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    p = params["model_params"]
    return _stacked_rnn(
        nn.LSTM,
        in_size=in_dim,
        hidden_size=p["units"],
        num_layers=params["num_layers"],
        bidirectional=True,
        dropout=p.get("dropout", 0.0),
    )


@register_torch_model("GRU")
def _build_gru(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    p = params["model_params"]
    return _stacked_rnn(
        nn.GRU,
        in_size=in_dim,
        hidden_size=p["units"],
        num_layers=params["num_layers"],
        bidirectional=False,
        dropout=p.get("dropout", 0.0),
    )


@register_torch_model("BiGRU")
def _build_bigru(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    p = params["model_params"]
    return _stacked_rnn(
        nn.GRU,
        in_size=in_dim,
        hidden_size=p["units"],
        num_layers=params["num_layers"],
        bidirectional=True,
        dropout=p.get("dropout", 0.0),
    )


def _build_tcn_body(
    in_dim: int, num_layers: int, p: dict, bidirectional: bool
) -> nn.Module:
    """TCN body (causal dilated convolutions) with optional bidirectional pass."""
    nb_filters = p["nb_filters"]
    kernel_size = p["kernel_size"]
    dropout = p["dropout_rate"]

    def _make_stack() -> nn.Sequential:
        layers = []
        in_ch = in_dim
        for i in range(num_layers):
            layers.append(_TCNBlock(in_ch, nb_filters, kernel_size, 2**i, dropout))
            in_ch = nb_filters
        return nn.Sequential(*layers)

    class _TCNBody(nn.Module):
        def __init__(self, bidirectional: bool):
            super().__init__()
            self.bidirectional = bidirectional
            self.forward_stack = _make_stack()
            if bidirectional:
                self.backward_stack = _make_stack()

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            # x: (batch, T, d) → (batch, d, T) for Conv1d
            xt = x.transpose(1, 2)
            out = self.forward_stack(xt)
            if self.bidirectional:
                rev = torch.flip(xt, dims=[-1])
                out_rev = torch.flip(self.backward_stack(rev), dims=[-1])
                out = torch.cat([out, out_rev], dim=1)
            # back to (batch, T, channels) and pool
            out = out.transpose(1, 2)
            return _last_step(out)

    return _TCNBody(bidirectional)


@register_torch_model("TCN")
def _build_tcn(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    return _build_tcn_body(
        in_dim, params["num_layers"], params["model_params"], bidirectional=False
    )


@register_torch_model("BiTCN")
def _build_bitcn(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    return _build_tcn_body(
        in_dim, params["num_layers"], params["model_params"], bidirectional=True
    )


@register_torch_model("CNN-1D")
def _build_cnn_1d(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    p = params["model_params"]
    num_layers = params["num_layers"]
    layers = []
    in_ch = in_dim
    for _ in range(num_layers):
        layers.append(
            _CausalConv1d(in_ch, p["nb_filters"], p["kernel_size"], dilation=1)
        )
        layers.append(nn.ReLU())
        layers.append(nn.Dropout(p["dropout_rate"]))
        in_ch = p["nb_filters"]

    body = nn.Sequential(*layers)

    class _CNNBody(nn.Module):
        def __init__(self, body: nn.Module):
            super().__init__()
            self.body = body

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            xt = x.transpose(1, 2)
            out = self.body(xt)
            return out.mean(dim=2)  # global average pool over time

    return _CNNBody(body)


@register_torch_model("Seq2Seq")
def _build_seq2seq(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    p = params["model_params"]

    class _Seq2Seq(nn.Module):
        def __init__(self):
            super().__init__()
            self.encoder = nn.LSTM(
                in_dim,
                p["units"],
                batch_first=True,
                dropout=p.get("dropout", 0.0),
            )
            self.norm_h = nn.LayerNorm(p["units"])
            self.norm_c = nn.LayerNorm(p["units"])
            self.decoder = nn.LSTM(
                p["units"],
                p["units"],
                batch_first=True,
                dropout=p.get("dropout", 0.0),
            )
            self.decoder_timesteps = max(num_timesteps // 5, 2)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            _, (h_n, c_n) = self.encoder(x)
            h = self.norm_h(h_n[-1])
            c = self.norm_c(c_n[-1])
            decoder_input = h.unsqueeze(1).expand(-1, self.decoder_timesteps, -1)
            out, _ = self.decoder(
                decoder_input,
                (h.unsqueeze(0).contiguous(), c.unsqueeze(0).contiguous()),
            )
            return _last_step(out)

    return _Seq2Seq()


# ─── Transformer family ────────────────────────────────────────────────

class _TransformerEncoderStack(nn.Module):
    def __init__(
        self,
        in_dim: int,
        num_timesteps: int,
        head_size: int,
        num_heads: int,
        ff_dim: int,
        num_layers: int,
        dropout: float,
        causal: bool,
    ):
        super().__init__()
        d_model = head_size * num_heads
        self.input_proj = nn.Linear(in_dim, d_model)
        self.pos_enc = PositionalEncoding(num_timesteps, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=num_heads,
            dim_feedforward=ff_dim,
            dropout=dropout,
            activation="relu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.norm = nn.LayerNorm(d_model)
        self.causal = causal
        self.num_timesteps = num_timesteps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.input_proj(x)
        x = self.pos_enc(x)
        mask = None
        if self.causal:
            mask = nn.Transformer.generate_square_subsequent_mask(x.size(1)).to(x.device)
        x = self.encoder(x, mask=mask)
        return self.norm(x)


@register_torch_model("BERT")
def _build_bert(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    p = params["model_params"]
    stack = _TransformerEncoderStack(
        in_dim=in_dim,
        num_timesteps=num_timesteps,
        head_size=p["head_size"],
        num_heads=p["num_heads"],
        ff_dim=p["ff_dim"],
        num_layers=params["num_layers"],
        dropout=p.get("dropout", 0.0),
        causal=False,
    )

    class _BERT(nn.Module):
        def __init__(self, stack: nn.Module):
            super().__init__()
            self.stack = stack

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            return self.stack(x)[:, 0, :]  # [CLS] = first position

    return _BERT(stack)


@register_torch_model("GPT")
def _build_gpt(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    p = params["model_params"]
    stack = _TransformerEncoderStack(
        in_dim=in_dim,
        num_timesteps=num_timesteps,
        head_size=p["head_size"],
        num_heads=p["num_heads"],
        ff_dim=p["ff_dim"],
        num_layers=params["num_layers"],
        dropout=p.get("dropout", 0.0),
        causal=True,
    )

    class _GPT(nn.Module):
        def __init__(self, stack: nn.Module):
            super().__init__()
            self.stack = stack

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            return self.stack(x)[:, -1, :]  # autoregressive last token

    return _GPT(stack)


@register_torch_model("Transformer")
def _build_transformer(in_dim: int, num_timesteps: int, params: dict) -> nn.Module:
    """Full encoder-decoder Transformer (Vaswani 2017).

    Encoder: bidirectional self-attention.
    Decoder: causal self-attention + cross-attention to encoder.
    """
    p = params["model_params"]
    d_model = p["head_size"] * p["num_heads"]
    decoder_timesteps = max(num_timesteps // 5, 2)

    class _FullTransformer(nn.Module):
        def __init__(self):
            super().__init__()
            self.input_proj = nn.Linear(in_dim, d_model)
            self.pos_enc = PositionalEncoding(num_timesteps, d_model)
            enc_layer = nn.TransformerEncoderLayer(
                d_model=d_model,
                nhead=p["num_heads"],
                dim_feedforward=p["ff_dim"],
                dropout=p.get("dropout", 0.0),
                batch_first=True,
                norm_first=True,
            )
            self.encoder = nn.TransformerEncoder(enc_layer, num_layers=params["num_layers"])
            dec_layer = nn.TransformerDecoderLayer(
                d_model=d_model,
                nhead=p["num_heads"],
                dim_feedforward=p["ff_dim"],
                dropout=p.get("dropout", 0.0),
                batch_first=True,
                norm_first=True,
            )
            self.decoder = nn.TransformerDecoder(dec_layer, num_layers=params["num_layers"])
            self.norm = nn.LayerNorm(d_model)
            self.decoder_seed = nn.Parameter(torch.zeros(1, decoder_timesteps, d_model))

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            x = self.input_proj(x)
            x = self.pos_enc(x)
            memory = self.encoder(x)
            batch = x.size(0)
            tgt = self.decoder_seed.expand(batch, -1, -1)
            causal = nn.Transformer.generate_square_subsequent_mask(tgt.size(1)).to(x.device)
            dec_out = self.decoder(tgt, memory, tgt_mask=causal)
            return self.norm(_mean_pool(dec_out))

    return _FullTransformer()


# ─── Lightning module (training loop) ───────────────────────────────────


class LeCrapaudLightningModule(pl.LightningModule):
    """Train a recurrent / sequence body + projection head + output head.

    Glues together the architecture-specific body (LSTM, BERT, …) with the
    optional BERT-pooler projection head and the final output Dense, then
    handles loss / optimizer / metrics inside Lightning's standard hooks.
    """

    def __init__(
        self,
        body: nn.Module,
        body_out_dim: int,
        target_type: str,
        num_class: int | None,
        head_units: int | None,
        head_activation: str,
        l2: float,
        learning_rate: float,
        clipnorm: float,
    ):
        super().__init__()
        self.save_hyperparameters(ignore=["body"])
        self.body = body
        self.target_type = target_type
        self.l2 = l2
        self.learning_rate = learning_rate
        self.clipnorm = clipnorm

        # Optional projection head (BERT pooler / classifier head pattern)
        head_in = body_out_dim
        head_layers: list[nn.Module] = []
        if head_units:
            head_layers.append(nn.Linear(body_out_dim, head_units))
            head_layers.append(nn.Tanh() if head_activation == "tanh" else nn.ReLU())
            head_in = head_units
        self.projection_head = nn.Sequential(*head_layers) if head_layers else nn.Identity()

        # Output head
        out_dim = num_class if (num_class is not None and num_class > 2) else 1
        self.output = nn.Linear(head_in, out_dim)
        self.num_class = num_class

        # Loss
        if target_type == "regression":
            self._loss = nn.MSELoss()
        elif num_class is not None and num_class > 2:
            self._loss = nn.CrossEntropyLoss()
        else:
            self._loss = nn.BCEWithLogitsLoss()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.body(x)
        z = self.projection_head(z)
        out = self.output(z)
        if self.target_type == "classification" and (self.num_class or 0) <= 2:
            # Probabilities for binary clf at inference; logits at train time
            # (BCEWithLogitsLoss wants logits internally — squeeze done outside).
            return out.squeeze(-1)
        return out

    def _shared_step(self, batch, stage: str):
        x, y = batch
        logits = self.forward(x)
        if self.target_type == "classification" and (self.num_class or 0) > 2:
            loss = self._loss(logits, y.long())
        elif self.target_type == "classification":
            loss = self._loss(logits, y.float())
        else:
            loss = self._loss(logits.squeeze(-1) if logits.ndim > 1 else logits, y.float())
        self.log(f"{stage}_loss", loss, prog_bar=False, on_step=False, on_epoch=True)
        return loss

    def training_step(self, batch, batch_idx):
        return self._shared_step(batch, "train")

    def validation_step(self, batch, batch_idx):
        return self._shared_step(batch, "val")

    def configure_optimizers(self):
        opt = torch.optim.Adam(
            self.parameters(),
            lr=self.learning_rate,
            weight_decay=self.l2,
        )
        return opt


# ─── Public factory used by search_space.get_model_constructor ─────────


def build_torch_model(model_name: str) -> Callable:
    """Return a closure with the same signature as the previous Keras
    `get_model_constructor` return: `(params, input_shape, target_type,
    num_class)` → returns a `LeCrapaudLightningModule` ready for training.
    """
    if model_name not in _TORCH_BUILDERS:
        raise ValueError(
            f"Unknown recurrent model: {model_name!r}. "
            f"Available: {sorted(_TORCH_BUILDERS)}"
        )

    body_builder = _TORCH_BUILDERS[model_name]

    def constructor(
        params: dict,
        input_shape: tuple[int, int],
        target_type: str,
        num_class: Optional[int] = None,
    ):
        num_timesteps, in_dim = input_shape
        body = body_builder(in_dim, num_timesteps, params)

        # Probe the body output dim with a dummy forward.
        body.eval()
        with torch.no_grad():
            probe = torch.zeros(1, num_timesteps, in_dim)
            body_out_dim = body(probe).shape[-1]
        body.train()

        module = LeCrapaudLightningModule(
            body=body,
            body_out_dim=body_out_dim,
            target_type=target_type,
            num_class=num_class,
            head_units=params.get("head_units"),
            head_activation=params.get("head_activation", "relu"),
            l2=params.get("l2", 0.0),
            learning_rate=params.get("learning_rate", 1e-3),
            clipnorm=params.get("clipnorm", 1.0),
        )
        module.model_name = model_name  # mirror keras `.model_name` attr
        # Reconstruction context for ArtifactService.save_model / load_model.
        # Lets safetensors-based loading rebuild the body via this same
        # factory before loading state_dict on top.
        module.lecrapaud_config = {
            "model_name": model_name,
            "params": params,
            "input_shape": list(input_shape),
            "target_type": target_type,
            "num_class": num_class,
        }
        return module

    return constructor
