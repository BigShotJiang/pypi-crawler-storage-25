"""Utility functions and logging setup for LeCrapaud.

This module provides various utility functions used throughout the LeCrapaud
framework, including logging configuration, file operations, text processing,
metrics handling, and JSON serialization helpers.

The module also defines the METRICS_CONFIG dictionary for optimization metrics
and EVAL_METRIC_MAPPING for library-specific metric translations.
"""

import pandas as pd
import numpy as np
import logging
from logging.handlers import RotatingFileHandler
import shutil
import os
import subprocess
from datetime import datetime, date
from ftfy import fix_text
import unicodedata
import re
import string

from lecrapaud.directories import logger_dir
from lecrapaud.config import LOGGING_LEVEL, PYTHON_ENV


_LECRAPAUD_LOGGER_ALREADY_CONFIGURED = False


def setup_logger():
    """Configure and return the LeCrapaud logger.

    Sets up logging with both console and file handlers based on the
    current environment (Development, Production, Test, Worker).
    Also initializes Sentry integration if configured.

    The logger is configured only once; subsequent calls return the
    existing logger instance.

    Returns:
        logging.Logger: Configured logger instance for LeCrapaud.
    """
    name = "lecrapaud"

    global _LECRAPAUD_LOGGER_ALREADY_CONFIGURED
    if _LECRAPAUD_LOGGER_ALREADY_CONFIGURED:  # ← bail out if done before
        return logging.getLogger(name)

    print(
        f"Setting up logger for {name} with PYTHON_ENV {PYTHON_ENV} and LOGGING_LEVEL {LOGGING_LEVEL}"
    )
    # ------------------------------------------------------------------ #
    #  Real configuration happens only on the FIRST call                 #
    # ------------------------------------------------------------------ #
    fmt = "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    logging.basicConfig(format=fmt, datefmt=datefmt)  # root format
    formatter = logging.Formatter(fmt, datefmt=datefmt)

    logger = logging.getLogger(name)

    log_level = getattr(logging, LOGGING_LEVEL.upper(), logging.INFO)
    logger.setLevel(log_level)

    # pick a file according to environment
    env_file = {
        "Development": "dev.log",
        "Production": "prod.log",
        "Test": "test.log",
        "Worker": "worker.log",
    }.get(PYTHON_ENV, "app.log")

    if logger_dir:
        file_handler = RotatingFileHandler(
            f"{logger_dir}/{env_file}",
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(log_level)
        logger.addHandler(file_handler)

    try:
        from lecrapaud.integrations.sentry_integration import init_sentry

        if init_sentry():
            logger.info("Sentry logging enabled")
    except Exception as exc:
        logger.info(f"Sentry logging disabled: {exc}")

    _LECRAPAUD_LOGGER_ALREADY_CONFIGURED = True
    return logger


logger = setup_logger()


def get_df_name(obj, namespace):
    """Get the variable name of an object in a given namespace.

    Args:
        obj: The object to find the name of.
        namespace: Dictionary of name-to-object mappings (e.g., locals()).

    Returns:
        str: The variable name that references the object.
    """
    return [name for name in namespace if namespace[name] is obj][0]


def pprint(item):
    """Pretty print an item to the logger with all rows visible.

    Args:
        item: Item to print (typically a pandas DataFrame).
    """
    with pd.option_context("display.max_rows", None):
        logger.info(item)


def object_to_dict(obj):
    """Recursively convert an object and its attributes to a dictionary.

    Args:
        obj: Object to convert. Can be a dict, list, or object with __dict__.

    Returns:
        dict or list: Dictionary representation of the object.
    """
    if isinstance(obj, dict):
        return {k: object_to_dict(v) for k, v in obj.items()}
    elif hasattr(obj, "__dict__"):
        return {k: object_to_dict(v) for k, v in obj.__dict__.items()}
    elif isinstance(obj, list):
        return [object_to_dict(i) for i in obj]
    else:
        return obj


def copy_any(src, dst):
    """Copy a file or directory to a destination.

    Uses shutil.copytree for directories and shutil.copy2 for files.
    copy2 preserves file metadata.

    Args:
        src: Source path (file or directory).
        dst: Destination path.
    """
    if os.path.isdir(src):
        # Copy folder using copytree
        shutil.copytree(src, dst)
    else:
        # Copy file using copy2 (which preserves metadata)
        shutil.copy2(src, dst)


def contains_best(folder_path):
    """Check if a folder contains saved model files.

    Searches recursively for files with '.best' or '.keras' in their names,
    which indicate saved LeCrapaud models.

    Args:
        folder_path: Path to the directory to search.

    Returns:
        bool: True if model files are found, False otherwise.
    """
    # Iterate over all files and folders in the specified directory
    for root, dirs, files in os.walk(folder_path):
        # Check each file and folder name for '.best' or '.keras'
        for name in files + dirs:
            if ".best" in name or ".keras" in name:
                return True
    return False


def get_folder_sizes(directory=os.path.expanduser("~")):
    """Calculate and display folder sizes in a directory.

    Uses the 'du' command to calculate sizes and logs results
    sorted by size in descending order.

    Args:
        directory: Directory to analyze. Defaults to user's home directory.
    """
    folder_sizes = {}

    for folder in os.listdir(directory):
        folder_path = os.path.join(directory, folder)
        if os.path.isdir(folder_path):
            try:
                size = (
                    subprocess.check_output(["du", "-sk", folder_path])
                    .split()[0]
                    .decode("utf-8")
                )
                folder_sizes[folder] = int(size)
            except subprocess.CalledProcessError:
                logger.info(f"Skipping {folder_path}: Permission Denied")

    sorted_folders = sorted(folder_sizes.items(), key=lambda x: x[1], reverse=True)
    logger.info(f"{'Folder':<50}{'Size (MB)':>10}")
    logger.info("=" * 60)
    for folder, size in sorted_folders:
        logger.info(f"{folder:<50}{size / (1024*1024):>10.2f}")


def create_cron_job(
    script_path,
    venv_path,
    log_file,
    pythonpath,
    cwd,
    job_frequency="* * * * *",
    cron_name="My Custom Cron Job",
):
    """
    Creates a cron job to run a Python script with a virtual environment, logging output, and setting PYTHONPATH and CWD.

    Parameters:
    - script_path (str): Path to the Python script to run.
    - venv_path (str): Path to the virtual environment's Python interpreter.
    - log_file (str): Path to the log file for output.
    - pythonpath (str): Value for the PYTHONPATH environment variable.
    - cwd (str): Working directory from which the script should run.
    - job_frequency (str): Cron timing syntax (default is every minute).
    - cron_name (str): Name to identify the cron job.
    """
    # Construct the cron command
    cron_command = (
        f"{job_frequency} /bin/zsh -c 'pgrep -fl python | grep -q {os.path.basename(script_path)} "
        f'|| (echo -e "Cron job {cron_name} started at $(date)" >> {log_file} && cd {cwd} && '
        f"PYTHONPATH={pythonpath} {venv_path}/bin/python {script_path} >> {log_file} 2>&1)'"
    )

    # Check existing cron jobs and remove any with the same comment
    subprocess.run(f"(crontab -l | grep -v '{cron_name}') | crontab -", shell=True)

    # Add the new cron job with the comment
    full_cron_job = f"{cron_command} # {cron_name}\n"
    subprocess.run(f'(crontab -l; echo "{full_cron_job}") | crontab -', shell=True)
    logger.info(f"Cron job created: {full_cron_job}")


def remove_all_cron_jobs():
    """
    Removes all cron jobs for the current user.
    """
    try:
        # Clear the user's crontab
        subprocess.run("crontab -r", shell=True, check=True)
        logger.info("All cron jobs have been removed successfully.")
    except subprocess.CalledProcessError:
        logger.info(
            "Failed to remove cron jobs. There may not be any cron jobs to remove, or there could be a permissions issue."
        )


def serialize_timestamp(dict: dict):
    """Convert timestamp objects to ISO format strings in a list of dicts.

    Args:
        dict: List of dictionaries that may contain datetime objects.

    Returns:
        list: List of dictionaries with timestamps converted to ISO strings.
    """
    def convert(obj):
        if isinstance(obj, (datetime, date, pd.Timestamp)):
            return obj.isoformat()

        return obj

    return [{k: convert(v) for k, v in item.items()} for item in dict]


def remove_accents(text: str) -> str:
    """
    Cleans the text of:
    - Broken Unicode
    - Accents
    - Control characters (including \x00, \u0000, etc.)
    - Escape sequences
    - Non-printable characters
    - Excessive punctuation (like ........ or !!!!)
    """

    # Step 1: Fix mojibake and broken Unicode
    text = fix_text(text)

    # Step 2 bis: Normalize accents
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ASCII", "ignore").decode("utf8")

    # Step 3: Remove known weird tokens
    text = text.replace("<|endoftext|>", "")
    text = text.replace("\u0000", "").replace("\x00", "")

    # Step 4: Remove raw control characters (e.g., \x1f)
    text = "".join(c for c in text if unicodedata.category(c)[0] != "C" or c == "\n")

    # Step 5: Remove literal escape sequences like \xNN
    text = re.sub(r"\\x[0-9a-fA-F]{2}", "", text)

    # Step 6: Remove non-printable characters
    printable = set(string.printable)
    text = "".join(c for c in text if c in printable)

    # Step 7: Collapse repeated punctuation (e.g., ........ → .)
    text = re.sub(r"([!?.])\1{2,}", r"\1", text)  # !!!!!! → !
    text = re.sub(r"([-—])\1{1,}", r"\1", text)  # ------ → -
    text = re.sub(r"([,.]){4,}", r"\1", text)  # ...... → .

    return text.strip()


def serialize_for_json(obj):
    """
    Recursively convert any object into a JSON-serializable structure.
    Handles NumPy types, datetime objects, and class instances.
    """
    import numpy as np
    from datetime import datetime, date
    import pandas as pd

    # Handle NumPy types
    if isinstance(obj, (np.integer, np.int64, np.int32, np.int16)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.float64, np.float32, np.float16)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, np.bool_):
        return bool(obj)

    # Handle datetime types
    elif isinstance(obj, (datetime, date, pd.Timestamp)):
        return obj.isoformat()

    # Handle basic Python types
    elif isinstance(obj, (str, int, float, bool, type(None))):
        return obj
    elif isinstance(obj, dict):
        return {str(k): serialize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple, set)):
        return [serialize_for_json(v) for v in obj]
    elif isinstance(obj, type):
        # A class/type object like int, str, etc.
        return obj.__name__
    elif hasattr(obj, "__class__"):
        # For other objects, return their string representation
        return f"{obj.__class__.__name__}()"
    else:
        return str(obj)


def strip_timestamp_suffix(name: str) -> str:
    """Remove timestamp suffix from an experiment name.

    Removes suffixes matching the pattern '_YYYYMMDD_HHMMSS' from the end
    of experiment names.

    Args:
        name: Experiment name potentially containing a timestamp suffix.

    Returns:
        str: Name with timestamp suffix removed.

    Example:
        >>> strip_timestamp_suffix("my_experiment_20240115_143022")
        'my_experiment'
    """
    if name is None:
        raise ValueError("name cannot be None")
    # Matches an underscore followed by 8 digits, another underscore, then 6 digits at the end
    return re.sub(r"_\d{8}_\d{6}$", "", name)


def get_run_dir(
    base_dir: str,
    experiment_name: str,
    target_name: str,
    model_name: str,
    run_id: str = None,
) -> tuple[str, str]:
    """Generate a run directory path following the new folder structure.

    Creates a directory structure for storing run artifacts:
    {base_dir}/{base_experiment_name}/{target_name}/{model_name}/{run_id}/

    The base_experiment_name is derived by stripping the timestamp suffix
    from the full experiment name, so runs from different experiment sessions
    with the same base name are grouped together.

    Args:
        base_dir: Base directory (typically 'tmp').
        experiment_name: Full experiment name (may include timestamp suffix).
        target_name: Target identifier (e.g., 'TARGET_1').
        model_name: Model type identifier (e.g., 'lgb', 'xgb', 'catboost').
        run_id: Optional run identifier. If not provided, generates a
                timestamp in YYYYMMDD_HHMMSS format.

    Returns:
        tuple[str, str]: A tuple of (run_directory_path, run_id).
            The directory is created if it doesn't exist.

    Example:
        >>> run_dir, run_id = get_run_dir("tmp", "stock_pred_20260128_175156", "TARGET_1", "lgb")
        >>> # Returns: ("tmp/stock_pred/TARGET_1/lgb/20260128_180000", "20260128_180000")
    """
    from pathlib import Path

    base_name = strip_timestamp_suffix(experiment_name)

    if run_id is None:
        run_id = datetime.now().strftime("%Y%m%d_%H%M%S")

    run_dir = Path(base_dir) / base_name / target_name / model_name / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    return str(run_dir), run_id


def validate_no_nan_inf(df: pd.DataFrame, stage: str) -> None:
    """
    Validate that a DataFrame contains no NaN or Inf values.
    Raises a comprehensive ValueError if issues are found.

    Args:
        df: DataFrame to validate
        stage: Name of the processing stage (e.g., "feature engineering", "model preprocessing")
    """
    # Check for NaN values
    nan_mask = df.isnull()
    nan_counts = nan_mask.sum()
    cols_with_nan = nan_counts[nan_counts > 0].sort_values(ascending=False)

    # Check for Inf values (only in numeric columns)
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    inf_counts = {}
    for col in numeric_cols:
        try:
            values = df[col].to_numpy(dtype=float, na_value=np.nan)
            inf_count = np.isinf(values).sum()
            if inf_count > 0:
                inf_counts[col] = inf_count
        except (TypeError, ValueError):
            continue
    cols_with_inf = pd.Series(inf_counts).sort_values(ascending=False) if inf_counts else pd.Series(dtype=int)
    inf_mask = pd.DataFrame()
    if len(cols_with_inf) > 0:
        inf_mask = df[cols_with_inf.index].apply(
            lambda x: np.isinf(x.to_numpy(dtype=float, na_value=np.nan))
        )

    if len(cols_with_nan) == 0 and len(cols_with_inf) == 0:
        return  # All good

    # Build comprehensive error message
    error_parts = [
        f"Data validation failed after {stage}.",
        f"Total rows: {len(df):,}",
    ]

    if len(cols_with_nan) > 0:
        total_nan = nan_counts.sum()
        rows_with_nan = nan_mask.any(axis=1).sum()
        error_parts.append("")
        error_parts.append("=== NaN VALUES DETECTED ===")
        error_parts.append(f"Total NaN values: {total_nan:,}")
        error_parts.append(f"Rows affected: {rows_with_nan:,} ({100*rows_with_nan/len(df):.1f}%)")
        error_parts.append(f"Columns with NaN ({len(cols_with_nan)}):")
        for col, count in cols_with_nan.head(20).items():
            pct = 100 * count / len(df)
            error_parts.append(f"  - {col}: {count:,} ({pct:.1f}%)")
        if len(cols_with_nan) > 20:
            error_parts.append(f"  ... and {len(cols_with_nan) - 20} more columns")

        # Show sample rows with NaN
        sample_nan_rows = df[nan_mask.any(axis=1)].head(3)
        if not sample_nan_rows.empty:
            nan_cols_in_sample = [col for col in cols_with_nan.index[:10] if col in sample_nan_rows.columns]
            if nan_cols_in_sample:
                error_parts.append("")
                error_parts.append("Sample rows with NaN (first 3, showing affected columns):")
                error_parts.append(sample_nan_rows[nan_cols_in_sample].to_string())

    if len(cols_with_inf) > 0:
        total_inf = cols_with_inf.sum()
        rows_with_inf = inf_mask.any(axis=1).sum() if not inf_mask.empty else 0
        error_parts.append("")
        error_parts.append("=== INFINITE VALUES DETECTED ===")
        error_parts.append(f"Total Inf values: {total_inf:,}")
        error_parts.append(f"Rows affected: {rows_with_inf:,} ({100*rows_with_inf/len(df):.1f}%)")
        error_parts.append(f"Columns with Inf ({len(cols_with_inf)}):")
        for col, count in cols_with_inf.head(20).items():
            pct = 100 * count / len(df)
            error_parts.append(f"  - {col}: {count:,} ({pct:.1f}%)")
        if len(cols_with_inf) > 20:
            error_parts.append(f"  ... and {len(cols_with_inf) - 20} more columns")

    error_parts.append("")
    error_parts.append("=== SUGGESTED ACTIONS ===")
    error_parts.append("1. Check your input data for missing values before calling fit()")
    error_parts.append("2. Ensure date columns are properly formatted")
    error_parts.append("3. Check encoding/scaling columns exist and have valid values")

    raise ValueError("\n".join(error_parts))


# Metrics configuration for optimization
# direction: "minimize" or "maximize"
# valid_for: "classification", "regression", "quantile", "survival", or "both"
#
# Target type overview:
#   - "regression": continuous output, MSE/MAE/Huber loss family
#   - "classification": discrete output, logloss / ROC-AUC / PR-AUC
#   - "quantile": continuous output trained with pinball loss at alpha=q
#   - "survival": right-censored duration, Cox proportional hazards
METRICS_CONFIG = {
    # Classification metrics
    "LOGLOSS": {"direction": "minimize", "valid_for": "classification"},
    "ROC_AUC": {"direction": "maximize", "valid_for": "classification"},
    # AVG_PRECISION = area under precision-recall curve (sklearn average_precision_score).
    # PR_AUC is an alias kept for the literature naming convention.
    "AVG_PRECISION": {"direction": "maximize", "valid_for": "classification"},
    "PR_AUC": {"direction": "maximize", "valid_for": "classification"},
    "ACCURACY": {"direction": "maximize", "valid_for": "classification"},
    "PRECISION": {"direction": "maximize", "valid_for": "classification"},
    "RECALL": {"direction": "maximize", "valid_for": "classification"},
    "F1": {"direction": "maximize", "valid_for": "classification"},
    # Regression metrics
    "RMSE": {"direction": "minimize", "valid_for": "regression"},
    "MAE": {"direction": "minimize", "valid_for": "regression"},
    "MAPE": {"direction": "minimize", "valid_for": "regression"},
    "R2": {"direction": "maximize", "valid_for": "regression"},
    "HUBER": {"direction": "minimize", "valid_for": "regression"},
    # Quantile regression metrics — one per supported alpha. Pinball loss is
    # the canonical metric: it equals the training objective, so hyperopt and
    # training are aligned (no silent fallback to RMSE).
    "PINBALL_10": {"direction": "minimize", "valid_for": "quantile", "alpha": 0.10},
    "PINBALL_25": {"direction": "minimize", "valid_for": "quantile", "alpha": 0.25},
    "PINBALL_50": {"direction": "minimize", "valid_for": "quantile", "alpha": 0.50},
    "PINBALL_75": {"direction": "minimize", "valid_for": "quantile", "alpha": 0.75},
    "PINBALL_90": {"direction": "minimize", "valid_for": "quantile", "alpha": 0.90},
    # Survival metrics
    "CONCORDANCE_INDEX": {"direction": "maximize", "valid_for": "survival"},
    "IBS": {"direction": "minimize", "valid_for": "survival"},  # integrated Brier score
    # Ranking / learning-to-rank metrics. Each evaluation is per-group (per
    # date in panel data); aggregations across groups are reported as the
    # mean (NDCG, IC) or mean / std (IC_IR).
    "NDCG_AT_10":        {"direction": "maximize", "valid_for": "ranking", "k": 10},
    "NDCG_AT_50":        {"direction": "maximize", "valid_for": "ranking", "k": 50},
    "RANK_IC":           {"direction": "maximize", "valid_for": "ranking"},
    "RANK_IC_IR":        {"direction": "maximize", "valid_for": "ranking"},
    "TOP_BOTTOM_SPREAD": {"direction": "maximize", "valid_for": "ranking"},
}


# Target types that produce continuous outputs (vs. discrete classes).
# Used to mutualise branches like "if target_type in CONTINUOUS_TARGET_TYPES".
CONTINUOUS_TARGET_TYPES = frozenset({"regression", "quantile", "survival"})


def is_continuous_target_type(target_type: str) -> bool:
    """Return True if the target type produces a continuous output.

    Used to share code paths between regression / quantile / survival
    (no class weights, no stratify, no num_class, etc.).
    """
    return target_type in CONTINUOUS_TARGET_TYPES


def get_default_metric(target_type: str) -> str:
    """Get the default optimization metric for a target type."""
    defaults = {
        "regression": "RMSE",
        "classification": "LOGLOSS",
        "quantile": "PINBALL_50",
        "survival": "CONCORDANCE_INDEX",
        "ranking": "NDCG_AT_10",
    }
    if target_type not in defaults:
        raise ValueError(
            f"Unknown target_type: {target_type!r}. "
            f"Valid types: {sorted(defaults.keys())}"
        )
    return defaults[target_type]


def get_metric_direction(metric: str) -> str:
    """Get the optimization direction for a metric ('minimize' or 'maximize')."""
    if metric not in METRICS_CONFIG:
        raise ValueError(
            f"Unknown metric: {metric}. Valid metrics: {list(METRICS_CONFIG.keys())}"
        )
    return METRICS_CONFIG[metric]["direction"]


def is_metric_better(new_score: float, best_score: float, metric: str) -> bool:
    """Check if new_score is better than best_score for the given metric."""
    direction = get_metric_direction(metric)
    if direction == "minimize":
        return new_score < best_score
    else:
        return new_score > best_score


def get_initial_best_score(metric: str) -> float:
    """Get the initial 'worst' score for a metric (to be improved upon)."""
    import numpy as np

    direction = get_metric_direction(metric)
    return np.inf if direction == "minimize" else -np.inf


# =============================================================================
# Objective abstraction (Step 0 / RFC econophysics)
#
# Users pick an *abstract* objective name (e.g. "huber", "tweedie", "quantile")
# in their context and lecrapaud translates to the library-native string at
# train time. This avoids users needing to know the 3 different conventions
# (LightGBM "huber", XGBoost "reg:pseudohubererror", CatBoost "Huber:delta=1").
#
# Look-up: OBJECTIVE_MAPPING[abstract][library] → native string OR None.
# Unsupported (abstract, lib) combos map to None — the dispatch must raise.
# =============================================================================
OBJECTIVE_MAPPING: dict[str, dict[str, str | None]] = {
    # Regression
    "rmse":       {"lightgbm": "regression",       "xgboost": "reg:squarederror",       "catboost": "RMSE"},
    "mae":        {"lightgbm": "regression_l1",    "xgboost": "reg:absoluteerror",      "catboost": "MAE"},
    "huber":      {"lightgbm": "huber",            "xgboost": "reg:pseudohubererror",   "catboost": "Huber"},
    # XGBoost has no native MAPE objective (only as eval_metric) → None means
    # "raise NotImplementedError if user picks this combo".
    "mape":       {"lightgbm": "mape",             "xgboost": None,                      "catboost": "MAPE"},
    "tweedie":    {"lightgbm": "tweedie",          "xgboost": "reg:tweedie",            "catboost": "Tweedie"},
    "poisson":    {"lightgbm": "poisson",          "xgboost": "count:poisson",          "catboost": "Poisson"},
    "gamma":      {"lightgbm": "gamma",            "xgboost": "reg:gamma",              "catboost": None},
    # Classification
    "logloss":    {"lightgbm": "binary",           "xgboost": "binary:logistic",        "catboost": "Logloss"},
    "multiclass": {"lightgbm": "multiclass",       "xgboost": "multi:softprob",         "catboost": "MultiClass"},
    # Quantile (alpha is appended/added by the dispatcher)
    "quantile":   {"lightgbm": "quantile",         "xgboost": "reg:quantileerror",      "catboost": "Quantile"},
    # Survival — XGBoost only.
    "cox":        {"lightgbm": None,               "xgboost": "survival:cox",           "catboost": None},
    "aft":        {"lightgbm": None,               "xgboost": "survival:aft",           "catboost": None},
    # Learning-to-rank objectives. All 3 boosters support ranking but with
    # different group encodings (set_group sizes vs group_id arrays) — handled
    # in model.py dispatch.
    # `lambdarank` = NDCG-optimised pairwise; `pairwise` = raw pairwise.
    "lambdarank": {"lightgbm": "lambdarank",       "xgboost": "rank:ndcg",              "catboost": "YetiRankPairwise"},
    "pairwise":   {"lightgbm": "rank_xendcg",      "xgboost": "rank:pairwise",          "catboost": "PairLogit"},
}


# Whitelist: which target_type each abstract objective is valid for.
# Used by validate_objective_for_target_type() to refuse mismatches like
# "huber" + classification target.
OBJECTIVE_VALID_FOR_TYPE: dict[str, set[str]] = {
    "rmse":       {"regression"},
    "mae":        {"regression"},
    "huber":      {"regression"},
    "mape":       {"regression"},
    "tweedie":    {"regression"},
    "poisson":    {"regression"},
    "gamma":      {"regression"},
    "logloss":    {"classification"},
    "multiclass": {"classification"},
    "quantile":   {"quantile"},
    "cox":        {"survival"},
    "aft":        {"survival"},
    "lambdarank": {"ranking"},
    "pairwise":   {"ranking"},
}


# Defaults per target_type — used when no `target_objective[n]` is specified.
# Picked to match the lib-native default behavior of each target_type:
DEFAULT_OBJECTIVE_FOR_TYPE: dict[str, str] = {
    "regression": "rmse",
    "classification": "logloss",  # binary; multiclass is auto-selected when num_class > 2
    "quantile": "quantile",
    "survival": "cox",
    "ranking": "lambdarank",
}


def validate_objective_for_target_type(objective: str, target_type: str) -> None:
    """Raise if the abstract objective is not valid for the target type.

    Examples:
        validate_objective_for_target_type("huber", "regression")  # OK
        validate_objective_for_target_type("huber", "classification")  # raises
    """
    if objective not in OBJECTIVE_VALID_FOR_TYPE:
        raise ValueError(
            f"Unknown abstract objective: {objective!r}. "
            f"Valid: {sorted(OBJECTIVE_VALID_FOR_TYPE.keys())}"
        )
    valid_types = OBJECTIVE_VALID_FOR_TYPE[objective]
    if target_type not in valid_types:
        raise ValueError(
            f"Objective '{objective}' is incompatible with target_type "
            f"'{target_type}'. Valid target_types for this objective: {sorted(valid_types)}."
        )


def resolve_native_objective(objective: str, library: str) -> str:
    """Look up the lib-native objective string for an abstract name.

    Raises NotImplementedError if the lib does not support this objective
    natively (e.g. cox+lightgbm, mape+xgboost).

    Most callers should prefer `resolve_native_objective_with_fallback()` which
    degrades gracefully instead of stopping the run.
    """
    if objective not in OBJECTIVE_MAPPING:
        raise ValueError(
            f"Unknown abstract objective: {objective!r}. "
            f"Valid: {sorted(OBJECTIVE_MAPPING.keys())}"
        )
    if library not in OBJECTIVE_MAPPING[objective]:
        raise ValueError(
            f"Unknown library: {library!r}. "
            f"Valid: {sorted(OBJECTIVE_MAPPING[objective].keys())}"
        )
    native = OBJECTIVE_MAPPING[objective][library]
    if native is None:
        raise NotImplementedError(
            f"Objective '{objective}' is not natively supported by {library}. "
            f"Pick a different model or change the target_objective."
        )
    return native


def resolve_sklearn_model_config(
    base_config: dict,
    abstract_objective: str | None,
    quantile_alpha: float | None = None,
    objective_params: dict | None = None,
) -> tuple:
    """Resolve (create_model, search_params) for a sklearn model given an objective.

    Two mechanisms (search_space.py opt-in):

      1. `objective_models` (full class swap, e.g. linear → HuberRegressor):
         - base_config["objective_models"][abstract_objective] supplies a new
           create_model + search_params dict with the right hyperparams for
           that class.
         - Used by `linear` to swap LinearRegression → HuberRegressor /
           QuantileRegressor / PoissonRegressor / GammaRegressor / TweedieRegressor.

      2. `objective_param_overrides` (param-level override, e.g. tree criterion):
         - base_config["objective_param_overrides"][abstract_objective] supplies
           constants merged into search_params (just override `criterion`,
           `loss`, etc.).
         - Used by `tree`, `forest`, `sgd`, `svm`, `adaboost`, `gb`.

    For models without either field, returns (base_config["create_model"],
    base_config["search_params"]) unchanged.

    Quantile-specific extras (alpha for QuantileRegressor / GBR quantile loss)
    are injected here when `abstract_objective == "quantile"` and the resolved
    class supports an `alpha` (or `quantile`) parameter.
    """
    create_model = base_config["create_model"]
    search_params = dict(base_config["search_params"])

    if abstract_objective is None:
        return create_model, search_params

    # Mechanism 1: full class swap
    obj_models = base_config.get("objective_models", {})
    if abstract_objective in obj_models:
        override = obj_models[abstract_objective]
        create_model = override["create_model"]
        search_params = dict(override["search_params"])
        # Quantile injection: QuantileRegressor takes `quantile` param, not alpha
        if abstract_objective == "quantile" and quantile_alpha is not None:
            search_params["quantile"] = quantile_alpha
        if abstract_objective == "huber" and objective_params:
            # HuberRegressor uses `epsilon` (≥ 1.0). Allow user to pin via
            # objective_params={"delta": 1.35}.
            delta = objective_params.get("delta")
            if delta is not None:
                search_params["epsilon"] = max(1.0001, float(delta))
        if abstract_objective == "tweedie" and objective_params:
            vp = objective_params.get("variance_power")
            if vp is not None:
                search_params["power"] = float(vp)
        return create_model, search_params

    # Mechanism 2: param-level overrides
    overrides = base_config.get("objective_param_overrides", {}).get(abstract_objective)
    if overrides is not None:
        search_params = {**search_params, **overrides}
        # GradientBoostingRegressor with loss="quantile" needs `alpha=q`.
        if abstract_objective == "quantile" and quantile_alpha is not None:
            search_params["alpha"] = quantile_alpha
        return create_model, search_params

    # No override registered for this objective on this model — keep defaults.
    # (Caller decides whether to log a warning.)
    return create_model, search_params


def resolve_native_objective_with_fallback(
    objective: str,
    library: str,
    target_type: str,
) -> tuple[str, str]:
    """Resolve abstract → native, falling back to the type's default on lib gaps.

    Behavior:
    - If `objective` is supported by `library` → return (native_string, objective).
    - If `objective` is NOT supported (e.g. mape+xgboost, cox+lightgbm) →
      log a WARNING and fall back to DEFAULT_OBJECTIVE_FOR_TYPE[target_type].
      Return (native_for_default, default_objective).

    The 2-tuple lets callers know which objective was actually used so they
    can store it for audit / model comparison ("did this run actually train
    on the requested objective, or did it degrade?").

    Cross-type mismatches (e.g. huber+classification) are NOT handled here —
    those should be caught upfront by validate_objective_for_target_type.
    """
    try:
        return resolve_native_objective(objective, library), objective
    except NotImplementedError:
        default_obj = DEFAULT_OBJECTIVE_FOR_TYPE.get(target_type)
        if default_obj is None:
            # Target type has no default mapping — this would be a bug, not
            # a user error. Re-raise to surface the problem.
            raise
        # Default for the type should always be supported by every booster
        # we care about; if not, raise (something is broken in our config).
        native = resolve_native_objective(default_obj, library)
        logger.warning(
            f"Objective {objective!r} is not natively supported by {library} for "
            f"target_type={target_type!r}; falling back to default {default_obj!r} "
            f"({native!r}). Hyperopt will compare this model against others on the "
            f"chosen evaluation metric — the model that ends up best will reflect "
            f"the metric, not the originally requested training objective."
        )
        return native, default_obj


def validate_metric_for_target_type(metric: str, target_type: str) -> None:
    """Validate that a metric is appropriate for the given target type.

    Raises loudly on unknown metric or type/metric mismatch. This is the
    "no silent fallback" guard — without it, a `quantile` target with a
    misconfigured metric would degrade to RMSE and silently train the
    median model.
    """
    if metric not in METRICS_CONFIG:
        raise ValueError(
            f"Unknown metric: {metric}. Valid metrics: {sorted(METRICS_CONFIG.keys())}"
        )
    valid_for = METRICS_CONFIG[metric]["valid_for"]
    if valid_for != "both" and valid_for != target_type:
        valid_metrics = sorted(
            k for k, v in METRICS_CONFIG.items()
            if v["valid_for"] in (target_type, "both")
        )
        raise ValueError(
            f"Metric '{metric}' is only valid for {valid_for}, not {target_type}. "
            f"Valid {target_type} metrics: {valid_metrics}"
        )


# Mapping from our metric names to library-specific eval_metric names
# Format: {metric: {library: {binary: name, multiclass: name} or name}}
#
# Mapping notes (verified against official docs):
# - XGBoost: objective for quantile is "reg:quantileerror" (param: quantile_alpha);
#   eval metric is "quantile". Objective for Huber is "reg:pseudohubererror";
#   eval metric is "mphe" (mean pseudo-Huber error).
# - LightGBM: objective and eval share the same name ("quantile", "huber"),
#   with `alpha` controlling the quantile level (or the Huber threshold).
# - CatBoost: loss/eval syntax is "Quantile:alpha=X" and "Huber:delta=X"
#   (delta is mandatory for Huber).
#
# Why PINBALL_10/25/50/75/90 all map to the same XGBoost/LightGBM eval string:
# in those libraries the alpha is a *model parameter* (quantile_alpha or alpha),
# not part of the eval metric name. The booster reads the alpha from its own
# config and reports the pinball loss accordingly. CatBoost is the only one
# that encodes alpha in the eval string itself ("Quantile:alpha=0.10").
# Lecrapaud keeps PINBALL_q as separate hyperopt metrics because a hyperopt
# comparison needs the actual α-specific pinball value (computed in
# `lecrapaud.metrics.compute_metric` independently of library-side reporting).
EVAL_METRIC_MAPPING = {
    # XGBoost mappings
    "xgboost": {
        "LOGLOSS": {"binary": "logloss", "multiclass": "mlogloss"},
        "ROC_AUC": {"binary": "auc", "multiclass": "auc"},
        "AVG_PRECISION": {"binary": "aucpr", "multiclass": "aucpr"},
        "PR_AUC": {"binary": "aucpr", "multiclass": "aucpr"},
        "RMSE": "rmse",
        "MAE": "mae",
        "MAPE": "mape",
        "HUBER": "mphe",
        "PINBALL_10": "quantile",
        "PINBALL_25": "quantile",
        "PINBALL_50": "quantile",
        "PINBALL_75": "quantile",
        "PINBALL_90": "quantile",
        # XGBoost only ships Cox negative log-likelihood as native eval for
        # survival models — used here for early stopping. The real Harrell's
        # concordance index is computed lecrapaud-side via
        # `lecrapaud.metrics._concordance_index_signed_duration` for hyperopt
        # comparison across models.
        "CONCORDANCE_INDEX": "cox-nloglik",
    },
    # LightGBM mappings
    "lightgbm": {
        "LOGLOSS": {"binary": "binary_logloss", "multiclass": "multi_logloss"},
        "ROC_AUC": {"binary": "auc", "multiclass": "auc_mu"},
        "AVG_PRECISION": {"binary": "average_precision", "multiclass": "average_precision"},
        "PR_AUC": {"binary": "average_precision", "multiclass": "average_precision"},
        "RMSE": "rmse",
        "MAE": "mae",
        "MAPE": "mape",
        "HUBER": "huber",
        "PINBALL_10": "quantile",
        "PINBALL_25": "quantile",
        "PINBALL_50": "quantile",
        "PINBALL_75": "quantile",
        "PINBALL_90": "quantile",
    },
    # CatBoost mappings
    "catboost": {
        "LOGLOSS": {"binary": "Logloss", "multiclass": "MultiClass"},
        "ROC_AUC": {"binary": "AUC", "multiclass": "AUC"},
        "AVG_PRECISION": {"binary": "PRAUC", "multiclass": "PRAUC"},
        "PR_AUC": {"binary": "PRAUC", "multiclass": "PRAUC"},
        "ACCURACY": {"binary": "Accuracy", "multiclass": "Accuracy"},
        "RMSE": "RMSE",
        "MAE": "MAE",
        "MAPE": "MAPE",
        "R2": "R2",
        # CatBoost Huber requires `delta` — eval delta is configured at the
        # objective level; eval_metric just reuses the same string.
        "HUBER": "Huber",
        "PINBALL_10": "Quantile:alpha=0.10",
        "PINBALL_25": "Quantile:alpha=0.25",
        "PINBALL_50": "Quantile:alpha=0.50",
        "PINBALL_75": "Quantile:alpha=0.75",
        "PINBALL_90": "Quantile:alpha=0.90",
    },
}


def get_feature_search_range(n_samples: int, n_available_features: int, max_features: int = None) -> tuple[int, int]:
    """
    Calculate the [min, max] range of features to explore based on number of observations.

    Uses curse of dimensionality principles:
    - min_features: log₂(n) with floor at 10
    - max_features: min(√n, n/10) - the more conservative of the two

    Args:
        n_samples: Number of observations
        n_available_features: Number of features available after ranking
        max_features: Optional user-specified maximum (overrides computed max)

    Returns:
        (min_features, max_features): Tuple of min and max features to search
    """
    import numpy as np

    # Minimum: log₂(n) with floor at 10
    min_features = max(10, int(np.log2(max(n_samples, 1))))

    # Maximum: min(√n, n/10) - the more conservative of the two
    max_by_sqrt = int(np.sqrt(n_samples))
    max_by_ratio = n_samples // 10
    computed_max = min(max_by_sqrt, max_by_ratio)

    # Use user-specified max_features if provided, otherwise use computed
    if max_features is not None:
        final_max = min(max_features, n_available_features)
    else:
        final_max = min(computed_max, n_available_features)

    # Ensure max >= min
    final_max = max(final_max, min_features)

    # Cap at available features
    final_max = min(final_max, n_available_features)
    min_features = min(min_features, final_max)

    return min_features, final_max


def get_eval_metric(metric: str, library: str, is_binary: bool = True) -> str:
    """
    Get the library-specific eval_metric name for a given metric.

    Args:
        metric: Our metric name (e.g., "LOGLOSS", "ROC_AUC")
        library: The library name ("xgboost", "lightgbm", "catboost")
        is_binary: Whether it's binary classification (vs multiclass)

    Returns:
        The library-specific eval_metric name
    """
    library = library.lower()
    if library not in EVAL_METRIC_MAPPING:
        raise ValueError(f"Unknown library: {library}")

    lib_mapping = EVAL_METRIC_MAPPING[library]
    if metric not in lib_mapping:
        # Fallback to default for this library
        logger.warning(
            f"Metric '{metric}' not available as eval_metric for {library}. "
            f"Using library default."
        )
        return None

    mapping = lib_mapping[metric]
    if isinstance(mapping, dict):
        return mapping["binary"] if is_binary else mapping["multiclass"]
    return mapping
