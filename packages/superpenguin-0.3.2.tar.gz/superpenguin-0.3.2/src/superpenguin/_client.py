"""Background event submitter — batches and POSTs cost events to the API."""

from __future__ import annotations

import atexit
import json
import logging
import queue
import threading
import time
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen

from superpenguin._version import __version__

logger = logging.getLogger("superpenguin")

# Sent on every ingest POST. Cloudflare's WAF on app.superpenguin.ai
# blocks the stdlib default ``Python-urllib/<py>`` UA with error 1010
# ("owner has banned your access based on browser signature"), which
# silently dropped 100% of events in 0.3.0–0.3.1. Identifying the SDK
# explicitly fixes that AND gives us per-version request analytics
# server-side.
_USER_AGENT = f"superpenguin-python/{__version__}"

_SENTINEL = object()


class SuperPenguinClient:
    """Batched HTTP client that queues cost events and flushes them
    to the server in a background daemon thread.

    ``flush()`` stops the worker, drains remaining items, sends them
    synchronously, and restarts the worker so nothing is lost.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://app.superpenguin.ai",
        flush_interval: float = 5.0,
        batch_size: int = 50,
        max_queue: int = 1000,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._queue: queue.Queue[dict[str, Any] | object] = queue.Queue(
            maxsize=max_queue
        )
        self._flush_interval = flush_interval
        self._batch_size = batch_size
        self._shutdown = threading.Event()
        self._lifecycle_lock = threading.Lock()
        self._thread = self._start_worker()
        atexit.register(self.shutdown)

    def submit(self, event: dict[str, Any]) -> None:
        """Enqueue a cost event for background submission. Non-blocking."""
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            logger.warning("superpenguin: event queue full, dropping event")

    def flush(self) -> None:
        """Stop worker, drain queue, send everything, restart worker."""
        with self._lifecycle_lock:
            self._stop_worker()
            self._drain_and_send()
            self._thread = self._start_worker()

    def shutdown(self) -> None:
        """Final flush on interpreter exit. Does not restart the worker."""
        with self._lifecycle_lock:
            self._stop_worker()
            self._drain_and_send()

    # -- internals ------------------------------------------------------------

    def _start_worker(self) -> threading.Thread:
        self._shutdown.clear()
        t = threading.Thread(target=self._run, daemon=True, name="sp-flush")
        t.start()
        return t

    def _stop_worker(self) -> None:
        self._shutdown.set()
        try:
            self._queue.put_nowait(_SENTINEL)
        except queue.Full:
            pass
        self._thread.join(timeout=10.0)

    def _drain_and_send(self) -> None:
        batch: list[dict[str, Any]] = []
        while True:
            try:
                item = self._queue.get_nowait()
                if item is _SENTINEL:
                    continue
                batch.append(item)  # type: ignore[arg-type]
            except queue.Empty:
                break
        if batch:
            self._send(batch)

    def _run(self) -> None:
        while not self._shutdown.is_set():
            batch: list[dict[str, Any]] = []
            deadline = time.monotonic() + self._flush_interval
            while time.monotonic() < deadline and len(batch) < self._batch_size:
                if self._shutdown.is_set():
                    break
                timeout = min(0.5, max(0.05, deadline - time.monotonic()))
                try:
                    item = self._queue.get(timeout=timeout)
                    if item is _SENTINEL:
                        break
                    batch.append(item)  # type: ignore[arg-type]
                except queue.Empty:
                    continue
            if batch:
                self._send(batch)

    def _send(self, events: list[dict[str, Any]], *, _retries: int = 2) -> None:
        url = f"{self._base_url}/api/sdk/ingest"
        body = json.dumps({"events": events}).encode()

        for attempt in range(_retries + 1):
            req = Request(url, data=body, method="POST")
            req.add_header("Content-Type", "application/json")
            req.add_header("Authorization", f"Bearer {self._api_key}")
            # Must be set explicitly: stdlib defaults to ``Python-urllib/<py>``
            # which Cloudflare's WAF rule on app.superpenguin.ai rejects (1010).
            req.add_header("User-Agent", _USER_AGENT)
            try:
                with urlopen(req, timeout=10) as resp:
                    resp.read()
                logger.debug("superpenguin: sent %d event(s)", len(events))
                return
            except (URLError, OSError) as exc:
                if attempt < _retries:
                    time.sleep(0.3 * (attempt + 1))
                    continue
                logger.warning(
                    "superpenguin: failed to send %d event(s) after %d attempts: %s",
                    len(events),
                    _retries + 1,
                    exc,
                )
            except Exception:
                logger.warning(
                    "superpenguin: unexpected error sending events", exc_info=True
                )
                return
