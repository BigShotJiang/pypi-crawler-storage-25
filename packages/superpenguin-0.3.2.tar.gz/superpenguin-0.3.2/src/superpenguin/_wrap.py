"""wrap() — transparent LLM client wrapping for automatic cost tracking."""

from __future__ import annotations

import functools
import logging
import time
from typing import Any, TypeVar

from superpenguin._pricing import calculate_cost_micros

logger = logging.getLogger("superpenguin")

T = TypeVar("T")

_OPENAI_RESOURCES: list[tuple[list[str], str]] = [
    (["chat", "completions"], "chat.completions"),
    (["completions"], "completions"),
    (["embeddings"], "embeddings"),
    (["responses"], "responses"),
]
_ANTHROPIC_RESOURCES: list[tuple[list[str], str]] = [
    (["messages"], "messages"),
]

# Google google-genai SDK exposes generate_content / generate_content_stream
# (and async equivalents under client.aio.models.*).
# Each entry: (attribute path on client, resource name, method name, is_async, is_stream)
_GOOGLE_METHODS: list[tuple[list[str], str, str, bool, bool]] = [
    (["models"],      "models", "generate_content",        False, False),
    (["models"],      "models", "generate_content_stream", False, True),
    (["aio", "models"], "models", "generate_content",        True,  False),
    (["aio", "models"], "models", "generate_content_stream", True,  True),
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def wrap(
    client: T,
    *,
    name: str | None = None,
    metadata: dict[str, Any] | None = None,
    tags: list[str] | None = None,
    **provider_kwargs: Any,
) -> T:
    """Wrap a supported client for automatic cost / usage tracking.

    The original client is modified in-place and returned.

    Supported providers (auto-detected from ``type(client).__module__``):

      * **LLM** — OpenAI, Anthropic, Google google-genai. Tracks tokens,
        cache hits, vision, tool use, latency, status code.
      * **Voice STT** — Deepgram (REST transcribe_url / transcribe_file,
        sync + async). Tracks audio_seconds + cost.
      * **Voice TTS** — ElevenLabs (text_to_speech.convert /
        convert_as_stream / text_to_sound_effects, sync + async). Tracks
        characters + cost.

    Args:
        client: An OpenAI, Anthropic, google-genai, Deepgram, or
            ElevenLabs client instance (or async equivalent where the
            SDK provides one).
        name: Override the default event name (e.g. ``"chat.completions"``).
            Only honored by LLM wrappers today.
        metadata: Default metadata attached to every event. Keys:
            ``customer_id``, ``feature``, ``team``, ``environment``,
            ``prompt_key``, ``prompt_version``, or any custom string tags.
            Per-call override via ``extra_body["sp_metadata"] = {...}`` is
            currently LLM-only; voice clients use the wrap-time defaults.
        tags: Tags attached to every event. Reserved; not yet promoted
            onto voice rows.
        **provider_kwargs: Provider-specific options. Currently:
            * ``tier="growth"`` (deepgram only) routes rows to the
              Growth-plan discounted SKU.
            Unknown kwargs raise ``TypeError`` for non-voice providers.

    Usage::

        import superpenguin as sp
        from openai import OpenAI

        sp.init(api_key="sp_...")
        client = sp.wrap(OpenAI(), metadata={"customer_id": "acme_123"})
        client.chat.completions.create(model="gpt-4o", messages=[...])

        # Google Gemini (AI Studio or Vertex AI — same SDK):
        from google import genai
        gclient = sp.wrap(genai.Client(api_key="..."))
        gclient.models.generate_content(model="gemini-2.5-pro", contents="hi")

        # Deepgram (standalone, not via LiveKit Agents):
        from deepgram import DeepgramClient
        dg = sp.wrap(DeepgramClient(api_key="..."), metadata={"feature": "podcasts"})
        result = dg.listen.rest.v("1").transcribe_url({"url": "..."})

        # ElevenLabs (standalone, not via LiveKit Agents):
        from elevenlabs.client import ElevenLabs
        el = sp.wrap(ElevenLabs(api_key="..."), metadata={"customer_id": "acme"})
        audio = el.text_to_speech.convert(voice_id="...", text="Hello", model_id="eleven_flash_v2_5")
    """
    provider = _detect_provider(client)
    if provider is None:
        raise ValueError(
            f"Unsupported client type: {type(client).__name__}. "
            "sp.wrap() supports OpenAI, Anthropic, google-genai, "
            "Deepgram, and ElevenLabs clients."
        )

    # Voice providers ship as their own modules so we can keep the
    # token-pricing path here lean and so users without those SDKs
    # installed don't pay an import cost.
    if provider == "deepgram":
        from superpenguin._deepgram import wrap_deepgram_client

        return wrap_deepgram_client(
            client, name=name, metadata=metadata, tags=tags, **provider_kwargs,
        )
    if provider == "elevenlabs":
        from superpenguin._elevenlabs import wrap_elevenlabs_client

        return wrap_elevenlabs_client(
            client, name=name, metadata=metadata, tags=tags, **provider_kwargs,
        )

    # LLM wrappers don't accept provider-specific kwargs today. Reject
    # unknown kwargs explicitly so a typo (e.g. wrap(openai_client,
    # tier="growth")) fails loud instead of silently ignoring.
    if provider_kwargs:
        unknown = ", ".join(sorted(provider_kwargs))
        raise TypeError(
            f"wrap() got unexpected keyword argument(s) {unknown!r} for "
            f"provider {provider!r}. These are only valid for voice "
            "providers (deepgram, elevenlabs)."
        )

    extra: dict[str, Any] = {}
    if name:
        extra["name"] = name
    if metadata:
        extra["metadata"] = metadata
    if tags:
        extra["tags"] = tags

    if provider == "google":
        for attr_path, resource_name, method, is_async, is_stream in _GOOGLE_METHODS:
            _patch_method(
                client, attr_path, provider, resource_name, method,
                is_async, is_stream, extra,
            )
        return client

    is_async = "Async" in type(client).__name__
    resources = _OPENAI_RESOURCES if provider == "openai" else _ANTHROPIC_RESOURCES
    for attr_path, resource_name in resources:
        _patch_resource(client, attr_path, provider, resource_name, is_async, extra)

    return client


# ---------------------------------------------------------------------------
# Provider detection
# ---------------------------------------------------------------------------


def _detect_provider(client: Any) -> str | None:
    module = getattr(type(client), "__module__", "") or ""
    if module.startswith("openai"):
        return "openai"
    if module.startswith("anthropic"):
        return "anthropic"
    if module.startswith("google.genai") or module.startswith("google_genai"):
        return "google"
    if module.startswith("deepgram"):
        return "deepgram"
    if module.startswith("elevenlabs"):
        return "elevenlabs"
    return None


# ---------------------------------------------------------------------------
# Monkey-patching
# ---------------------------------------------------------------------------


def _patch_resource(
    client: Any,
    attr_path: list[str],
    provider: str,
    resource_name: str,
    is_async: bool,
    extra: dict[str, Any],
) -> None:
    obj = client
    for attr in attr_path:
        obj = getattr(obj, attr, None)
        if obj is None:
            return

    original_create = getattr(obj, "create", None)
    if original_create is None:
        return

    wrapped = _make_wrapper(
        original_create, provider, resource_name, is_async, extra,
        force_stream=None,
    )
    try:
        obj.create = wrapped
    except (AttributeError, TypeError):
        logger.debug("superpenguin: could not patch %s.create", resource_name)


def _patch_method(
    client: Any,
    attr_path: list[str],
    provider: str,
    resource_name: str,
    method_name: str,
    is_async: bool,
    is_stream: bool,
    extra: dict[str, Any],
) -> None:
    """Patch ``client.<attr_path>.<method_name>`` with a tracked wrapper.

    Used by providers (Google) whose entry points aren't named ``.create``
    and whose streaming variants are separate methods rather than a
    ``stream=True`` flag.
    """
    obj = client
    for attr in attr_path:
        obj = getattr(obj, attr, None)
        if obj is None:
            return

    original = getattr(obj, method_name, None)
    if original is None:
        return

    wrapped = _make_wrapper(
        original, provider, resource_name, is_async, extra,
        force_stream=is_stream,
    )
    try:
        setattr(obj, method_name, wrapped)
    except (AttributeError, TypeError):
        logger.debug("superpenguin: could not patch %s.%s", resource_name, method_name)


def _make_wrapper(
    original_fn: Any,
    provider: str,
    resource_name: str,
    is_async: bool,
    extra: dict[str, Any],
    *,
    force_stream: bool | None,
) -> Any:
    if is_async:

        @functools.wraps(original_fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await _track_async(
                original_fn, provider, resource_name, extra, args, kwargs,
                force_stream=force_stream,
            )

        return async_wrapper

    @functools.wraps(original_fn)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        return _track_sync(
            original_fn, provider, resource_name, extra, args, kwargs,
            force_stream=force_stream,
        )

    return sync_wrapper


# ---------------------------------------------------------------------------
# Sync tracking
# ---------------------------------------------------------------------------


def _track_sync(
    fn: Any,
    provider: str,
    resource_name: str,
    extra: dict[str, Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    force_stream: bool | None = None,
) -> Any:
    started_at = time.time()
    is_stream = (
        force_stream if force_stream is not None else kwargs.get("stream", False)
    )
    kwargs, call_meta = _consume_call_metadata(kwargs)
    has_vision = _detect_has_vision(kwargs)
    fallback_model = _extract_fallback_model(provider, args, kwargs)

    if is_stream and provider == "openai" and resource_name in (
        "chat.completions", "completions",
    ):
        kwargs = dict(kwargs)
        opts = dict(kwargs.get("stream_options") or {})
        opts["include_usage"] = True
        kwargs["stream_options"] = opts

    try:
        result = fn(*args, **kwargs)
    except Exception as exc:
        _submit_error(provider, resource_name, extra, call_meta, has_vision, exc, started_at)
        raise

    if is_stream:
        acc = _make_accumulator(provider, resource_name)

        def on_done() -> None:
            data = acc.result()
            data.setdefault("model", fallback_model)
            _submit_success(
                provider, resource_name, extra, call_meta, has_vision,
                data, started_at, time.time(), streaming=True,
            )

        return _SyncStreamProxy(result, acc, on_done)

    output = _normalize_response(provider, result, resource_name)
    output.setdefault("model", fallback_model)
    _submit_success(
        provider, resource_name, extra, call_meta, has_vision,
        output, started_at, time.time(), streaming=False,
    )
    return result


# ---------------------------------------------------------------------------
# Async tracking
# ---------------------------------------------------------------------------


async def _track_async(
    fn: Any,
    provider: str,
    resource_name: str,
    extra: dict[str, Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    force_stream: bool | None = None,
) -> Any:
    started_at = time.time()
    is_stream = (
        force_stream if force_stream is not None else kwargs.get("stream", False)
    )
    kwargs, call_meta = _consume_call_metadata(kwargs)
    has_vision = _detect_has_vision(kwargs)
    fallback_model = _extract_fallback_model(provider, args, kwargs)

    if is_stream and provider == "openai" and resource_name in (
        "chat.completions", "completions",
    ):
        kwargs = dict(kwargs)
        opts = dict(kwargs.get("stream_options") or {})
        opts["include_usage"] = True
        kwargs["stream_options"] = opts

    try:
        result = await fn(*args, **kwargs)
    except Exception as exc:
        _submit_error(provider, resource_name, extra, call_meta, has_vision, exc, started_at)
        raise

    # Google's async generate_content_stream returns a coroutine that yields
    # an async iterator (not the iterator directly). We've already awaited it
    # above, so `result` is the async iterator and we can wrap it normally.
    if is_stream:
        acc = _make_accumulator(provider, resource_name)

        def on_done() -> None:
            data = acc.result()
            data.setdefault("model", fallback_model)
            _submit_success(
                provider, resource_name, extra, call_meta, has_vision,
                data, started_at, time.time(), streaming=True,
            )

        return _AsyncStreamProxy(result, acc, on_done)

    output = _normalize_response(provider, result, resource_name)
    output.setdefault("model", fallback_model)
    _submit_success(
        provider, resource_name, extra, call_meta, has_vision,
        output, started_at, time.time(), streaming=False,
    )
    return result


# ---------------------------------------------------------------------------
# Stream proxies
# ---------------------------------------------------------------------------


class _SyncStreamProxy:
    def __init__(self, stream: Any, accumulator: Any, on_done: Any) -> None:
        self._stream = stream
        self._accumulator = accumulator
        self._on_done = on_done
        self._done = False

    def __iter__(self) -> Any:
        try:
            for chunk in self._stream:
                self._accumulator(chunk)
                yield chunk
        finally:
            self._finish()

    def __enter__(self) -> _SyncStreamProxy:
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args: Any) -> Any:
        self._finish()
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
        return None

    def close(self) -> None:
        self._finish()
        if hasattr(self._stream, "close"):
            self._stream.close()

    def _finish(self) -> None:
        if not self._done:
            self._done = True
            try:
                self._on_done()
            except Exception:
                logger.debug("superpenguin: error in stream callback", exc_info=True)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


class _AsyncStreamProxy:
    def __init__(self, stream: Any, accumulator: Any, on_done: Any) -> None:
        self._stream = stream
        self._accumulator = accumulator
        self._on_done = on_done
        self._done = False

    async def __aiter__(self) -> Any:
        try:
            async for chunk in self._stream:
                self._accumulator(chunk)
                yield chunk
        finally:
            self._finish()

    async def __aenter__(self) -> _AsyncStreamProxy:
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> Any:
        self._finish()
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*args)
        return None

    def _finish(self) -> None:
        if not self._done:
            self._done = True
            try:
                self._on_done()
            except Exception:
                logger.debug("superpenguin: error in stream callback", exc_info=True)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


# ---------------------------------------------------------------------------
# Stream accumulators — only capture cost-relevant fields (tokens, model)
# ---------------------------------------------------------------------------


class _OpenAIAccumulator:
    def __init__(self) -> None:
        self.model: str | None = None
        self.usage: dict[str, int] | None = None
        self.has_tools: bool = False

    def __call__(self, chunk: Any) -> None:
        if getattr(chunk, "model", None):
            self.model = chunk.model

        usage = getattr(chunk, "usage", None)
        if usage:
            self.usage = {
                "input_tokens": getattr(usage, "prompt_tokens", 0) or 0,
                "output_tokens": getattr(usage, "completion_tokens", 0) or 0,
                "total_tokens": getattr(usage, "total_tokens", 0) or 0,
            }
            details = getattr(usage, "prompt_tokens_details", None)
            if details and getattr(details, "cached_tokens", None):
                self.usage["cached_tokens"] = details.cached_tokens

        choices = getattr(chunk, "choices", None)
        if choices:
            delta = getattr(choices[0], "delta", None)
            if delta and getattr(delta, "tool_calls", None):
                self.has_tools = True

    def result(self) -> dict[str, Any]:
        out: dict[str, Any] = {"has_tools": self.has_tools}
        if self.model:
            out["model"] = self.model
        if self.usage:
            out["usage"] = self.usage
        return out


class _AnthropicAccumulator:
    def __init__(self) -> None:
        self.model: str | None = None
        self.input_tokens: int = 0
        self.output_tokens: int = 0
        self.cache_read_tokens: int = 0
        self.has_tools: bool = False

    def __call__(self, event: Any) -> None:
        event_type = getattr(event, "type", "")
        if event_type == "message_start":
            msg = getattr(event, "message", None)
            if msg:
                self.model = getattr(msg, "model", None)
                usage = getattr(msg, "usage", None)
                if usage:
                    self.input_tokens = getattr(usage, "input_tokens", 0) or 0
                    self.cache_read_tokens = (
                        getattr(usage, "cache_read_input_tokens", 0) or 0
                    )
        elif event_type == "content_block_start":
            block = getattr(event, "content_block", None)
            if block and getattr(block, "type", "") == "tool_use":
                self.has_tools = True
        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage:
                self.output_tokens = getattr(usage, "output_tokens", 0) or 0

    def result(self) -> dict[str, Any]:
        total = self.input_tokens + self.output_tokens
        return {
            "model": self.model,
            "has_tools": self.has_tools,
            "usage": {
                "input_tokens": self.input_tokens,
                "output_tokens": self.output_tokens,
                "total_tokens": total,
                "cached_tokens": self.cache_read_tokens,
            },
        }


class _OpenAIResponsesAccumulator:
    def __init__(self) -> None:
        self.model: str | None = None
        self.usage: dict[str, int] | None = None
        self.has_tools: bool = False

    def __call__(self, event: Any) -> None:
        event_type = getattr(event, "type", "")
        if event_type == "response.output_item.done":
            item = getattr(event, "item", None)
            if item and getattr(item, "type", "") == "function_call":
                self.has_tools = True
        elif event_type == "response.completed":
            resp = getattr(event, "response", None)
            if resp:
                self.model = getattr(resp, "model", None)
                usage = getattr(resp, "usage", None)
                if usage:
                    inp = getattr(usage, "input_tokens", 0) or 0
                    out = getattr(usage, "output_tokens", 0) or 0
                    self.usage = {
                        "input_tokens": inp,
                        "output_tokens": out,
                        "total_tokens": inp + out,
                    }

    def result(self) -> dict[str, Any]:
        out: dict[str, Any] = {"has_tools": self.has_tools}
        if self.model:
            out["model"] = self.model
        if self.usage:
            out["usage"] = self.usage
        return out


class _GoogleAccumulator:
    """Accumulate token counts from streaming google-genai chunks.

    Each chunk may carry a ``usage_metadata`` field (Google reports the
    cumulative running totals on the final chunk, sometimes earlier too).
    We keep the latest observed values.
    """

    def __init__(self) -> None:
        self.model: str | None = None
        self.input_tokens: int = 0
        self.output_tokens: int = 0
        self.cached_tokens: int = 0
        self.has_tools: bool = False

    def __call__(self, chunk: Any) -> None:
        if getattr(chunk, "model_version", None):
            self.model = chunk.model_version

        usage = getattr(chunk, "usage_metadata", None)
        if usage:
            self.input_tokens = (
                getattr(usage, "prompt_token_count", 0) or self.input_tokens
            )
            self.output_tokens = (
                getattr(usage, "candidates_token_count", 0) or self.output_tokens
            )
            self.cached_tokens = (
                getattr(usage, "cached_content_token_count", 0) or self.cached_tokens
            )

        candidates = getattr(chunk, "candidates", None) or []
        for cand in candidates:
            content = getattr(cand, "content", None)
            for part in getattr(content, "parts", None) or []:
                if getattr(part, "function_call", None):
                    self.has_tools = True

    def result(self) -> dict[str, Any]:
        out: dict[str, Any] = {"has_tools": self.has_tools}
        if self.model:
            out["model"] = self.model
        if self.input_tokens or self.output_tokens or self.cached_tokens:
            out["usage"] = {
                "input_tokens": self.input_tokens,
                "output_tokens": self.output_tokens,
                "total_tokens": self.input_tokens + self.output_tokens,
                "cached_tokens": self.cached_tokens,
            }
        return out


def _make_accumulator(provider: str, resource_name: str = "") -> Any:
    if provider == "openai":
        if resource_name == "responses":
            return _OpenAIResponsesAccumulator()
        return _OpenAIAccumulator()
    if provider == "google":
        return _GoogleAccumulator()
    return _AnthropicAccumulator()


# ---------------------------------------------------------------------------
# Response normalization (non-streaming)
# ---------------------------------------------------------------------------


def _normalize_response(
    provider: str, response: Any, resource_name: str = "",
) -> dict[str, Any]:
    if provider == "openai":
        if resource_name == "responses":
            return _normalize_openai_responses(response)
        return _normalize_openai(response)
    if provider == "google":
        return _normalize_google(response)
    return _normalize_anthropic(response)


def _normalize_openai(response: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}

    if getattr(response, "model", None):
        out["model"] = response.model

    choices = getattr(response, "choices", None)
    if choices:
        msg = getattr(choices[0], "message", None)
        out["has_tools"] = bool(msg and getattr(msg, "tool_calls", None))

    usage = getattr(response, "usage", None)
    if usage:
        out["usage"] = {
            "input_tokens": getattr(usage, "prompt_tokens", 0) or 0,
            "output_tokens": getattr(usage, "completion_tokens", 0) or 0,
            "total_tokens": getattr(usage, "total_tokens", 0) or 0,
        }
        details = getattr(usage, "prompt_tokens_details", None)
        if details and getattr(details, "cached_tokens", None):
            out["usage"]["cached_tokens"] = details.cached_tokens

    return out


def _normalize_openai_responses(response: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}

    if getattr(response, "model", None):
        out["model"] = response.model

    output_items = getattr(response, "output", None) or []
    out["has_tools"] = any(
        getattr(item, "type", "") == "function_call" for item in output_items
    )

    usage = getattr(response, "usage", None)
    if usage:
        inp = getattr(usage, "input_tokens", 0) or 0
        outp = getattr(usage, "output_tokens", 0) or 0
        out["usage"] = {
            "input_tokens": inp,
            "output_tokens": outp,
            "total_tokens": inp + outp,
        }

    return out


def _normalize_google(response: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}

    if getattr(response, "model_version", None):
        out["model"] = response.model_version

    has_tools = False
    for cand in getattr(response, "candidates", None) or []:
        content = getattr(cand, "content", None)
        for part in getattr(content, "parts", None) or []:
            if getattr(part, "function_call", None):
                has_tools = True
                break
        if has_tools:
            break
    out["has_tools"] = has_tools

    usage = getattr(response, "usage_metadata", None)
    if usage:
        inp = getattr(usage, "prompt_token_count", 0) or 0
        outp = getattr(usage, "candidates_token_count", 0) or 0
        cached = getattr(usage, "cached_content_token_count", 0) or 0
        out["usage"] = {
            "input_tokens": inp,
            "output_tokens": outp,
            "total_tokens": inp + outp,
            "cached_tokens": cached,
        }

    return out


def _normalize_anthropic(response: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}

    if getattr(response, "model", None):
        out["model"] = response.model

    content_blocks = getattr(response, "content", None)
    if content_blocks:
        out["has_tools"] = any(
            getattr(b, "type", "") == "tool_use" for b in content_blocks
        )

    usage = getattr(response, "usage", None)
    if usage:
        inp = getattr(usage, "input_tokens", 0) or 0
        outp = getattr(usage, "output_tokens", 0) or 0
        cached = getattr(usage, "cache_read_input_tokens", 0) or 0
        out["usage"] = {
            "input_tokens": inp,
            "output_tokens": outp,
            "total_tokens": inp + outp,
            "cached_tokens": cached,
        }

    return out


# ---------------------------------------------------------------------------
# Per-call metadata extraction
# ---------------------------------------------------------------------------

_KNOWN_META_KEYS = frozenset({
    "customer_id", "feature", "team", "environment",
    "prompt_key", "prompt_version",
})


def _consume_call_metadata(
    kwargs: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Extract per-call metadata and return (sanitized_kwargs, call_meta).

    Reads ``extra_body["sp_metadata"]`` (preferred) or ``extra_body["metadata"]``
    and **strips both keys from extra_body** before the request leaves the
    SDK. This is required because providers like Anthropic strictly validate
    request bodies and reject unknown fields with
    ``400 Extra inputs are not permitted``. OpenAI happens to silently
    discard unknown body fields, but we don't want to rely on that.

    Behavior:
      * If ``extra_body`` is missing, not a dict, or has no metadata key, the
        original ``kwargs`` is returned unchanged (no copy).
      * If a metadata key is found, returns a shallow copy of ``kwargs`` with
        a sanitized ``extra_body``. ``extra_body`` is removed entirely if it
        becomes empty after the strip.
      * ``call_meta`` carries only the recognized canonical fields plus a
        ``custom_tags`` map for any string-valued unknown keys (matches the
        wrap-time metadata contract).
    """
    extra_body = kwargs.get("extra_body")
    if not isinstance(extra_body, dict):
        return kwargs, {}

    raw = extra_body.get("sp_metadata") or extra_body.get("metadata")
    if not isinstance(raw, dict):
        return kwargs, {}

    sanitized_extra_body = {
        k: v for k, v in extra_body.items() if k not in ("sp_metadata", "metadata")
    }
    sanitized_kwargs = dict(kwargs)
    if sanitized_extra_body:
        sanitized_kwargs["extra_body"] = sanitized_extra_body
    else:
        sanitized_kwargs.pop("extra_body", None)

    result: dict[str, Any] = {}
    custom_tags: dict[str, str] = {}

    for key, value in raw.items():
        if key in _KNOWN_META_KEYS:
            result[key] = value
        elif isinstance(value, str):
            custom_tags[key] = value

    if custom_tags:
        result["custom_tags"] = custom_tags

    return sanitized_kwargs, result


def _extract_call_metadata(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Backward-compatible wrapper used by _litellm._capture_litellm_input.

    Returns only the extracted metadata (no sanitized kwargs). Safe to use
    when the kwargs dict is synthesized internally and never forwarded to a
    provider's HTTP API.
    """
    _, call_meta = _consume_call_metadata(kwargs)
    return call_meta


def _extract_fallback_model(
    provider: str, args: tuple[Any, ...], kwargs: dict[str, Any],
) -> str:
    """Pull the model name off the call args, in case the response omits it."""
    model = kwargs.get("model")
    if model:
        return str(model)
    # OpenAI/Anthropic/Google all accept ``model`` as a keyword; positional
    # ``model`` is rare. Return empty string if nothing is available.
    return ""


def _detect_has_vision(kwargs: dict[str, Any]) -> bool:
    messages = kwargs.get("messages") or []
    for msg in messages:
        content = msg.get("content") if isinstance(msg, dict) else None
        if isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "image_url":
                    return True
    return False


# ---------------------------------------------------------------------------
# Event submission
# ---------------------------------------------------------------------------


def _submit_success(
    provider: str,
    resource_name: str,
    extra: dict[str, Any],
    call_meta: dict[str, Any],
    has_vision: bool,
    output_data: dict[str, Any],
    started_at: float,
    ended_at: float,
    *,
    streaming: bool,
) -> None:
    _submit(
        provider, resource_name, extra, call_meta, has_vision,
        output_data, started_at, ended_at, 200, streaming=streaming,
    )


def _submit_error(
    provider: str,
    resource_name: str,
    extra: dict[str, Any],
    call_meta: dict[str, Any],
    has_vision: bool,
    exc: Exception,
    started_at: float,
) -> None:
    status_code = getattr(exc, "status_code", 500)
    _submit(
        provider, resource_name, extra, call_meta, has_vision,
        {}, started_at, time.time(), status_code, streaming=False,
    )


def _submit(
    provider: str,
    resource_name: str,
    extra: dict[str, Any],
    call_meta: dict[str, Any],
    has_vision: bool,
    output_data: dict[str, Any],
    started_at: float,
    ended_at: float,
    status_code: int,
    *,
    streaming: bool,
) -> None:
    from superpenguin import get_client

    usage = output_data.get("usage", {})
    input_tokens = usage.get("input_tokens", 0)
    output_tokens = usage.get("output_tokens", 0)
    cached_tokens = usage.get("cached_tokens", 0)
    model = output_data.get("model", "")

    cost_micros = calculate_cost_micros(
        model, input_tokens, output_tokens, cached_tokens,
    )

    from superpenguin._context import merged_metadata

    merged_meta = merged_metadata(extra.get("metadata"), call_meta)

    event: dict[str, Any] = {
        "provider": provider,
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cached_tokens": cached_tokens,
        "cost_usd_micros": cost_micros,
        "latency_ms": round((ended_at - started_at) * 1000),
        "status_code": status_code,
        "streaming": streaming,
        "has_tools": output_data.get("has_tools", False),
        "has_vision": has_vision,
    }

    for key in (
        "customer_id", "feature", "team", "environment",
        "prompt_key", "prompt_version",
    ):
        val = merged_meta.get(key)
        if val is not None:
            event[key] = str(val) if key == "prompt_version" else val

    if merged_meta.get("custom_tags"):
        event["custom_tags"] = merged_meta["custom_tags"]

    try:
        get_client().submit(event)
    except Exception:
        logger.debug("superpenguin: failed to submit event", exc_info=True)
