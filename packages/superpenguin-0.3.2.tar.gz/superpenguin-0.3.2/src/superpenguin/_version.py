"""Single source of truth for the SDK version string.

Lives in its own module so internal modules (notably ``_client``) can
import it without creating a circular import: ``superpenguin/__init__``
already imports from ``_client``, so ``_client`` cannot import back
from ``superpenguin``.

When bumping versions, update this file AND ``pyproject.toml``
(the build system reads the latter directly). A future cleanup is to
wire ``[tool.hatch.version] path = "src/superpenguin/_version.py"`` so
the toml stops drifting.
"""

from __future__ import annotations

__version__ = "0.3.2"

__all__ = ["__version__"]
