"""Regression tests for the per-call extra_body metadata strip.

The bug (fixed in 0.3.1):
    sp.wrap() reads ``extra_body["sp_metadata"]`` for tracking but used to
    forward it to the provider's HTTP body unchanged. OpenAI silently
    drops unknown body fields so this happened to work; Anthropic strictly
    validates and returns ``400 sp_metadata: Extra inputs are not permitted``.

The fix:
    ``_consume_call_metadata`` now returns a sanitized kwargs dict with
    ``sp_metadata`` and ``metadata`` removed from ``extra_body`` before the
    request leaves the SDK. ``extra_body`` itself is removed if it becomes
    empty after the strip.
"""

from __future__ import annotations

from typing import Any

import pytest

import superpenguin
from superpenguin._wrap import _consume_call_metadata


# ---------------------------------------------------------------------------
# Unit tests on _consume_call_metadata
# ---------------------------------------------------------------------------


def test_strips_sp_metadata_from_extra_body() -> None:
    kwargs = {
        "model": "gpt-5.4",
        "messages": [{"role": "user", "content": "hi"}],
        "extra_body": {"sp_metadata": {"customer_id": "cust_a"}},
    }
    sanitized, call_meta = _consume_call_metadata(kwargs)

    assert "sp_metadata" not in sanitized.get("extra_body", {})
    # extra_body is empty after the strip, so it should be removed entirely.
    assert "extra_body" not in sanitized
    assert call_meta == {"customer_id": "cust_a"}


def test_strips_metadata_alias_from_extra_body() -> None:
    kwargs = {
        "extra_body": {"metadata": {"customer_id": "cust_b"}},
    }
    sanitized, call_meta = _consume_call_metadata(kwargs)

    assert "extra_body" not in sanitized
    assert call_meta == {"customer_id": "cust_b"}


def test_preserves_other_extra_body_keys() -> None:
    kwargs = {
        "extra_body": {
            "sp_metadata": {"customer_id": "cust_c"},
            "user": "real-anthropic-user-id",
            "anthropic_beta": ["computer-use-2025-01-24"],
        },
    }
    sanitized, call_meta = _consume_call_metadata(kwargs)

    assert sanitized["extra_body"] == {
        "user": "real-anthropic-user-id",
        "anthropic_beta": ["computer-use-2025-01-24"],
    }
    assert call_meta == {"customer_id": "cust_c"}


def test_does_not_mutate_original_kwargs() -> None:
    original = {
        "model": "claude-opus-4-7",
        "extra_body": {"sp_metadata": {"customer_id": "cust_d"}},
    }
    snapshot = {
        "model": "claude-opus-4-7",
        "extra_body": {"sp_metadata": {"customer_id": "cust_d"}},
    }
    _consume_call_metadata(original)

    assert original == snapshot
    assert original["extra_body"] == {"sp_metadata": {"customer_id": "cust_d"}}


def test_passthrough_when_no_extra_body() -> None:
    kwargs: dict[str, Any] = {"model": "gpt-5.4"}
    sanitized, call_meta = _consume_call_metadata(kwargs)
    assert sanitized is kwargs
    assert call_meta == {}


def test_passthrough_when_extra_body_has_no_metadata() -> None:
    kwargs = {"extra_body": {"user": "real-user-id"}}
    sanitized, call_meta = _consume_call_metadata(kwargs)
    assert sanitized is kwargs
    assert call_meta == {}


def test_custom_tags_collected_for_unknown_string_keys() -> None:
    kwargs = {
        "extra_body": {
            "sp_metadata": {
                "customer_id": "cust_e",
                "request_source": "cron",
                "tenant_tier": "enterprise",
                "should_be_dropped": 42,
            }
        }
    }
    sanitized, call_meta = _consume_call_metadata(kwargs)

    assert "extra_body" not in sanitized
    assert call_meta["customer_id"] == "cust_e"
    assert call_meta["custom_tags"] == {
        "request_source": "cron",
        "tenant_tier": "enterprise",
    }


# ---------------------------------------------------------------------------
# End-to-end test: a fake Anthropic-shaped client must not see sp_metadata
# ---------------------------------------------------------------------------


class _CapturingClient:
    """Stand-in for the global SuperPenguin client (captures emitted rows)."""

    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    def submit(self, event: dict[str, Any]) -> None:
        self.events.append(event)


@pytest.fixture(autouse=True)
def _swap_client(monkeypatch: pytest.MonkeyPatch) -> _CapturingClient:
    fake = _CapturingClient()
    monkeypatch.setattr(superpenguin, "_client", fake)
    return fake


class _CapturedKwargsClient:
    """Records the kwargs that hit the underlying provider call.

    Mimics the surface shape ``sp.wrap()`` recognizes for Anthropic via
    duck-typing on ``client.messages.create``.
    """

    def __init__(self) -> None:
        self.received_kwargs: dict[str, Any] | None = None
        self.messages = self  # so client.messages.create resolves to self

    def create(self, **kwargs: Any) -> Any:
        self.received_kwargs = kwargs

        class _Resp:
            id = "msg_test"
            model = kwargs.get("model", "claude-opus-4-7")
            stop_reason = "end_turn"
            content: list[Any] = []
            usage = type("U", (), {"input_tokens": 10, "output_tokens": 5})()

        return _Resp()


# Trick the provider detector into routing this to the Anthropic path.
_CapturedKwargsClient.__module__ = "anthropic.fake"


def test_anthropic_does_not_receive_sp_metadata_in_extra_body(
    _swap_client: _CapturingClient,
) -> None:
    """The actual regression: Anthropic 400'd because sp_metadata was forwarded."""
    fake_client = _CapturedKwargsClient()
    wrapped = superpenguin.wrap(fake_client)

    wrapped.messages.create(
        model="claude-opus-4-7",
        max_tokens=100,
        messages=[{"role": "user", "content": "hi"}],
        extra_body={
            "sp_metadata": {"customer_id": "cust_acme_123"},
            "user": "real-anthropic-user",
        },
    )

    assert fake_client.received_kwargs is not None
    forwarded_extra_body = fake_client.received_kwargs.get("extra_body", {})
    # The bug: sp_metadata used to land here and Anthropic returned 400.
    assert "sp_metadata" not in forwarded_extra_body
    assert "metadata" not in forwarded_extra_body
    # Other extra_body keys must still flow through to Anthropic.
    assert forwarded_extra_body == {"user": "real-anthropic-user"}

    # And the row we emit still carries the per-call customer_id.
    assert len(_swap_client.events) == 1
    assert _swap_client.events[0]["customer_id"] == "cust_acme_123"


def test_anthropic_extra_body_removed_entirely_when_only_sp_metadata(
    _swap_client: _CapturingClient,
) -> None:
    """If sp_metadata is the only key, extra_body should not be forwarded at all."""
    fake_client = _CapturedKwargsClient()
    wrapped = superpenguin.wrap(fake_client)

    wrapped.messages.create(
        model="claude-opus-4-7",
        max_tokens=100,
        messages=[{"role": "user", "content": "hi"}],
        extra_body={"sp_metadata": {"customer_id": "cust_x"}},
    )

    assert fake_client.received_kwargs is not None
    assert "extra_body" not in fake_client.received_kwargs
