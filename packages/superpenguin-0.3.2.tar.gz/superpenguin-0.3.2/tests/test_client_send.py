"""Regression tests for ``SuperPenguinClient._send`` — the HTTP path
that ships queued events to the dashboard.

These tests cover the wire format, NOT the worker thread / batching
behavior (those are covered by ``test_voice.py`` via ``submit_voice_event``).

Bug 1 (0.3.0–0.3.1, fixed in 0.3.2)
-----------------------------------
Cloudflare's WAF on app.superpenguin.ai rejects the urllib stdlib
default ``User-Agent: Python-urllib/<py>`` with ``error code: 1010``,
which silently dropped 100% of events for every wrapped provider. The
fix sets an explicit SDK user-agent. ``test_send_includes_user_agent``
asserts that header lands on every outgoing request and is NEVER the
stdlib default.
"""

from __future__ import annotations

import io
import re
from typing import Any
from unittest.mock import patch

import pytest

import superpenguin
from superpenguin._client import SuperPenguinClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeResponse(io.BytesIO):
    """Minimal context-manager-compatible stand-in for an http.client.HTTPResponse."""

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()


def _make_client() -> SuperPenguinClient:
    """Build a client without starting the background worker.

    We invoke ``_send`` directly, so the worker would just race the
    test. Construction normally spawns a daemon thread; we let it
    spawn, then immediately stop it so it doesn't push anything.
    """
    client = SuperPenguinClient(
        api_key="sp_test_key",
        base_url="https://app.example.test",
        flush_interval=60.0,  # never auto-flush during the test
        batch_size=10_000,
    )
    # Prevent the daemon thread from sending anything — we drive _send
    # directly and assert on the captured Request.
    client._stop_worker()
    return client


# ---------------------------------------------------------------------------
# Bug 1 regression — explicit User-Agent on every POST
# ---------------------------------------------------------------------------


def test_send_includes_user_agent() -> None:
    """``_send`` must set ``User-Agent: superpenguin-python/<version>``
    on every Request. Without it, urllib defaults to
    ``Python-urllib/<py>`` which Cloudflare's WAF on
    app.superpenguin.ai rejects with HTTP 403 (1010), silently
    dropping 100% of events."""
    client = _make_client()

    captured: list[Any] = []

    def fake_urlopen(req: Any, timeout: float = 0) -> _FakeResponse:
        captured.append(req)
        return _FakeResponse(b'{"accepted": 1}')

    with patch("superpenguin._client.urlopen", side_effect=fake_urlopen):
        client._send([{"provider": "openai", "cost_usd_micros": 100}])

    assert len(captured) == 1, "expected one POST"
    req = captured[0]

    # urllib normalizes header names to title-case ("User-agent").
    ua = req.get_header("User-agent")
    assert ua is not None, "User-Agent header was not set"
    assert re.match(r"^superpenguin-python/\d+\.\d+\.\d+", ua), (
        f"User-Agent should start with 'superpenguin-python/<semver>', got {ua!r}"
    )
    assert "Python-urllib" not in ua, (
        "User-Agent must not be the stdlib default — Cloudflare WAF blocks it"
    )

    # Sanity: the other required headers are still there.
    assert req.get_header("Content-type") == "application/json"
    assert req.get_header("Authorization") == "Bearer sp_test_key"


def test_send_user_agent_carries_sdk_version() -> None:
    """The UA version must match ``superpenguin.__version__`` so
    server-side analytics can attribute requests to a specific SDK
    release without inferring it from the body."""
    client = _make_client()

    captured: list[Any] = []

    def fake_urlopen(req: Any, timeout: float = 0) -> _FakeResponse:
        captured.append(req)
        return _FakeResponse(b"{}")

    with patch("superpenguin._client.urlopen", side_effect=fake_urlopen):
        client._send([{"provider": "anthropic"}])

    ua = captured[0].get_header("User-agent")
    assert ua == f"superpenguin-python/{superpenguin.__version__}"


# ---------------------------------------------------------------------------
# Sanity: the URL we POST to is actually built from `base_url`.
# Cheap insurance against a future refactor of the URL composition.
# ---------------------------------------------------------------------------


def test_send_posts_to_ingest_path() -> None:
    client = _make_client()
    captured: list[Any] = []

    def fake_urlopen(req: Any, timeout: float = 0) -> _FakeResponse:
        captured.append(req)
        return _FakeResponse(b"{}")

    with patch("superpenguin._client.urlopen", side_effect=fake_urlopen):
        client._send([{"provider": "openai"}])

    req = captured[0]
    assert req.full_url == "https://app.example.test/api/sdk/ingest"
    assert req.get_method() == "POST"


# ---------------------------------------------------------------------------
# Default base_url (Bug 2 alignment)
# ---------------------------------------------------------------------------


def test_default_base_url_is_app_superpenguin_ai() -> None:
    """The default ingest host shipped in 0.3.0–0.3.1 was
    api.carrotlabs.ai, which currently 404s on /api/sdk/ingest. The
    canonical default is the dashboard host. This test guards against
    accidental reverts."""
    # init() reads the module-level _DEFAULT_BASE_URL when no override is
    # provided — exercise that path rather than hard-coding the string,
    # so the test fails if either constant drifts.
    assert superpenguin._DEFAULT_BASE_URL == "https://app.superpenguin.ai"

    # And a freshly constructed client (the lower-level constructor) carries
    # the same default.
    client = SuperPenguinClient(api_key="sp_test")
    try:
        assert client._base_url == "https://app.superpenguin.ai"
    finally:
        client._stop_worker()


if __name__ == "__main__":  # pragma: no cover
    pytest.main([__file__, "-v"])
