// sherpa-onnx/csrc/offline-stream.h
//
// Copyright (c)  2023  Xiaomi Corporation

#ifndef SHERPA_ONNX_CSRC_OFFLINE_STREAM_H_
#define SHERPA_ONNX_CSRC_OFFLINE_STREAM_H_
#include <stdint.h>

#include <memory>
#include <string>
#include <vector>

#include "sherpa-onnx/csrc/context-graph.h"
#include "sherpa-onnx/csrc/features.h"
#include "sherpa-onnx/csrc/parse-options.h"

namespace sherpa_onnx {

struct OfflineRecognitionResult {
  // Recognition results.
  // For English, it consists of space separated words.
  // For Chinese, it consists of Chinese words without spaces.
  std::string text;

  // Decoded results at the token level.
  // For instance, for BPE-based models it consists of a list of BPE tokens.
  std::vector<std::string> tokens;

  std::string lang;

  // emotion target of the audio.
  std::string emotion;

  // event target of the audio.
  std::string event;

  /// timestamps.size() == tokens.size()
  /// timestamps[i] records the time in seconds when tokens[i] is decoded.
  std::vector<float> timestamps;

  /// durations[i] contains the duration (in seconds) for tokens[i] (TDT models
  /// only)
  std::vector<float> durations;

  /// ys_log_probs[i] contains the log probability (confidence) for tokens[i].
  std::vector<float> ys_log_probs;

  // Word IDs from FST decoding (CTC models with FST decoder only).
  std::vector<int32_t> words;

  // Segment-level data (from Whisper with segment timestamps enabled).
  // These are parallel vectors: segment_timestamps.size() ==
  // segment_durations.size() == segment_texts.size()
  std::vector<float> segment_timestamps;   // start time of each segment
  std::vector<float> segment_durations;    // duration of each segment
  std::vector<std::string> segment_texts;  // text of each segment

  std::string AsJsonString() const;
};

struct WhisperTag {
  int32_t dim = 80;
};

struct CEDTag {};

// It uses a neural network model, a preprocessor, to convert
// audio samples to features
struct MoonshineTag {};

// It is based on Wav2Vec, accepting raw audio samples as input
struct OmnilingualAsrTag {};

class OfflineStream {
 public:
  explicit OfflineStream(const FeatureExtractorConfig &config = {},
                         ContextGraphPtr context_graph = {});

  explicit OfflineStream(WhisperTag tag);
  explicit OfflineStream(CEDTag tag);
  explicit OfflineStream(MoonshineTag tag);
  explicit OfflineStream(OmnilingualAsrTag tag);
  ~OfflineStream();

  /**
     @param sampling_rate The sampling_rate of the input waveform. If it does
                          not equal to  config.sampling_rate, we will do
                          resampling inside.
     @param waveform Pointer to a 1-D array of size n. It must be normalized to
                     the range [-1, 1].
     @param n Number of entries in waveform

     Caution: You can only invoke this function once so you have to input
              all the samples at once
   */
  void AcceptWaveform(int32_t sampling_rate, const float *waveform,
                      int32_t n) const;

  /// Return feature dim of this extractor.
  ///
  /// Note: if it is Moonshine, then it returns the number of audio samples
  /// currently received.
  int32_t FeatureDim() const;

  // Get all the feature frames of this stream in a 1-D array, which is
  // flattened from a 2-D array of shape (num_frames, feat_dim).
  std::vector<float> GetFrames() const;

  /** Set the recognition result for this stream. */
  void SetResult(const OfflineRecognitionResult &r);

  /** Get the recognition result of this stream */
  const OfflineRecognitionResult &GetResult() const;

  /** Get the ContextGraph of this stream */
  const ContextGraphPtr &GetContextGraph() const;

  // Generic per-stream option mechanism (key-value string pairs).
  void SetOption(const std::string &key, const std::string &value);
  bool HasOption(const std::string &key) const;

  // Returns the value for the given key, or an empty string if the key
  // does not exist. No exception is thrown for missing keys.
  const std::string &GetOption(const std::string &key) const;
  int32_t GetOptionInt(const std::string &key, int32_t default_value = 0) const;
  float GetOptionFloat(const std::string &key,
                       float default_value = 0.0f) const;

 private:
  class Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace sherpa_onnx

#endif  // SHERPA_ONNX_CSRC_OFFLINE_STREAM_H_
