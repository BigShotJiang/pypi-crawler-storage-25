// sherpa-onnx/csrc/offline-recognizer-impl.cc
//
// Copyright (c)  2023  Xiaomi Corporation

#include "sherpa-onnx/csrc/offline-recognizer-impl.h"

#include <memory>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

#if __ANDROID_API__ >= 9

#include "android/asset_manager.h"
#include "android/asset_manager_jni.h"
#endif

#if __OHOS__
#include "rawfile/raw_file_manager.h"
#endif

#include "fst/extensions/far/far.h"
#include "kaldifst/csrc/kaldi-fst-io.h"
#include "onnxruntime_cxx_api.h"  // NOLINT
#include "sherpa-onnx/csrc/file-utils.h"
#include "sherpa-onnx/csrc/fst-utils.h"
#include "sherpa-onnx/csrc/macros.h"
#include "sherpa-onnx/csrc/offline-recognizer-canary-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-cohere-transcribe-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-ctc-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-fire-red-asr-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-funasr-nano-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-moonshine-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-moonshine-v2-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-paraformer-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-paraformer-tpl-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-qwen3-asr-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-sense-voice-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-sense-voice-tpl-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-transducer-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-transducer-nemo-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-whisper-impl.h"
#include "sherpa-onnx/csrc/offline-recognizer-whisper-tpl-impl.h"
#include "sherpa-onnx/csrc/text-utils.h"

#if SHERPA_ONNX_ENABLE_RKNN
#include "sherpa-onnx/csrc/rknn/offline-paraformer-model-rknn.h"
#include "sherpa-onnx/csrc/rknn/offline-sense-voice-model-rknn.h"
#endif

#if SHERPA_ONNX_ENABLE_AXERA
#include "sherpa-onnx/csrc/axera/offline-sense-voice-model-axera.h"
#endif

#if SHERPA_ONNX_ENABLE_AXCL
#include "sherpa-onnx/csrc/axcl/offline-sense-voice-model-axcl.h"
#endif

#if SHERPA_ONNX_ENABLE_ASCEND_NPU
#include "sherpa-onnx/csrc/ascend/offline-paraformer-model-ascend.h"
#include "sherpa-onnx/csrc/ascend/offline-recognizer-zipformer-ctc-ascend-impl.h"
#include "sherpa-onnx/csrc/ascend/offline-sense-voice-model-ascend.h"
#include "sherpa-onnx/csrc/ascend/offline-whisper-model-ascend.h"
#endif

#if SHERPA_ONNX_ENABLE_QNN
#include "sherpa-onnx/csrc/qnn/offline-paraformer-model-qnn.h"
#include "sherpa-onnx/csrc/qnn/offline-recognizer-zipformer-ctc-qnn-impl.h"
#include "sherpa-onnx/csrc/qnn/offline-sense-voice-model-qnn.h"
#endif

namespace sherpa_onnx {

std::unique_ptr<OfflineRecognizerImpl> OfflineRecognizerImpl::Create(
    const OfflineRecognizerConfig &config) {
  if (config.model_config.provider == "rknn") {
#if SHERPA_ONNX_ENABLE_RKNN
    if (!config.model_config.sense_voice.model.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelRknn>>(
          config);
    } else if (!config.model_config.paraformer.model.empty()) {
      return std::make_unique<
          OfflineRecognizerParaformerTplImpl<OfflineParaformerModelRknn>>(
          config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice and Paraformer models are currently supported "
          "by rknn for non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }
#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_RKNN=ON if you "
        "want to use rknn. See also "
        "https://k2-fsa.github.io/sherpa/onnx/rknn/install.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (config.model_config.provider == "axera") {
#if SHERPA_ONNX_ENABLE_AXERA
    if (!config.model_config.sense_voice.model.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelAxera>>(
          config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice models are currently supported by Axera NPU for "
          "non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }
#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_AXERA=ON if you "
        "want to use axera. See also "
        "https://k2-fsa.github.io/sherpa/onnx/axera/install.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (config.model_config.provider == "axcl") {
#if SHERPA_ONNX_ENABLE_AXCL
    if (!config.model_config.sense_voice.model.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelAxcl>>(
          config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice models are currently supported by axcl for "
          "non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }

#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_AXCL=ON if you "
        "want to use axcl. See also "
        "https://k2-fsa.github.io/sherpa/onnx/axcl/install.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (config.model_config.provider == "ascend") {
#if SHERPA_ONNX_ENABLE_ASCEND_NPU
    if (!config.model_config.sense_voice.model.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelAscend>>(
          config);
    } else if (!config.model_config.paraformer.model.empty()) {
      return std::make_unique<
          OfflineRecognizerParaformerTplImpl<OfflineParaformerModelAscend>>(
          config);
    } else if (!config.model_config.zipformer_ctc.model.empty()) {
      return std::make_unique<OfflineRecognizerZipformerCtcAscendImpl>(config);
    } else if (!config.model_config.whisper.encoder.empty()) {
      return std::make_unique<
          OfflineRecognizerWhisperTplImpl<OfflineWhisperModelAscend>>(config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice, Paraformer, Whisper, and Zipformer CTC models are "
          "currently supported by Ascend NPU for non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }
#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_ASCEND_NPU=ON if "
        "you want to use Ascend NPU. See also "
        "https://k2-fsa.github.io/sherpa/onnx/ascend/install.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (config.model_config.provider == "qnn") {
#if SHERPA_ONNX_ENABLE_QNN
    if (!config.model_config.sense_voice.model.empty() ||
        !config.model_config.sense_voice.qnn_config.context_binary.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelQnn>>(
          config);
    } else if (!config.model_config.zipformer_ctc.model.empty() ||
               !config.model_config.zipformer_ctc.qnn_config.context_binary
                    .empty()) {
      return std::make_unique<OfflineRecognizerZipformerCtcQnnImpl>(config);
    } else if (!config.model_config.paraformer.model.empty() ||
               !config.model_config.paraformer.qnn_config.context_binary
                    .empty()) {
      return std::make_unique<
          OfflineRecognizerParaformerTplImpl<OfflineParaformerModelQnn>>(
          config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice, Paraformer, and Zipformer CTC models are currently "
          "supported by QNN for non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }
#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_QNN=ON if "
        "you want to use qnn. See also "
        "https://k2-fsa.github.io/sherpa/onnx/qnn/build.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (!config.model_config.sense_voice.model.empty()) {
    return std::make_unique<OfflineRecognizerSenseVoiceImpl>(config);
  }

  if (!config.model_config.funasr_nano.encoder_adaptor.empty()) {
    return std::make_unique<OfflineRecognizerFunASRNanoImpl>(config);
  }

  if (!config.model_config.qwen3_asr.conv_frontend.empty()) {
    return std::make_unique<OfflineRecognizerQwen3ASRImpl>(config);
  }

  if (!config.model_config.paraformer.model.empty()) {
    return std::make_unique<OfflineRecognizerParaformerImpl>(config);
  }

  if (!config.model_config.nemo_ctc.model.empty() ||
      !config.model_config.zipformer_ctc.model.empty() ||
      !config.model_config.tdnn.model.empty() ||
      !config.model_config.wenet_ctc.model.empty() ||
      !config.model_config.omnilingual.model.empty() ||
      !config.model_config.medasr.model.empty() ||
      !config.model_config.fire_red_asr_ctc.model.empty() ||
      !config.model_config.dolphin.model.empty()) {
    return std::make_unique<OfflineRecognizerCtcImpl>(config);
  }

  if (!config.model_config.whisper.encoder.empty()) {
    return std::make_unique<OfflineRecognizerWhisperImpl>(config);
  }

  if (!config.model_config.cohere_transcribe.encoder.empty()) {
    return std::make_unique<OfflineRecognizerCohereTranscribeImpl>(config);
  }

  if (!config.model_config.fire_red_asr.encoder.empty()) {
    return std::make_unique<OfflineRecognizerFireRedAsrImpl>(config);
  }

  if (!config.model_config.moonshine.preprocessor.empty()) {
    return std::make_unique<OfflineRecognizerMoonshineImpl>(config);
  }

  if (!config.model_config.moonshine.merged_decoder.empty()) {
    return std::make_unique<OfflineRecognizerMoonshineV2Impl>(config);
  }

  if (!config.model_config.canary.encoder.empty()) {
    return std::make_unique<OfflineRecognizerCanaryImpl>(config);
  }

  // TODO(fangjun): Refactor it. We only need to use model type for the
  // following models:
  //  1. transducer and nemo_transducer
  if (!config.model_config.model_type.empty()) {
    const auto &model_type = config.model_config.model_type;
    if (model_type == "transducer") {
      return std::make_unique<OfflineRecognizerTransducerImpl>(config);
    } else if (model_type == "nemo_transducer") {
      return std::make_unique<OfflineRecognizerTransducerNeMoImpl>(config);
    } else if (model_type == "paraformer") {
      return std::make_unique<OfflineRecognizerParaformerImpl>(config);
    } else if (model_type == "nemo_ctc" || model_type == "tdnn" ||
               model_type == "zipformer2_ctc" || model_type == "wenet_ctc" ||
               model_type == "telespeech_ctc") {
      return std::make_unique<OfflineRecognizerCtcImpl>(config);
    } else if (model_type == "whisper") {
      // unreachable
      return std::make_unique<OfflineRecognizerWhisperImpl>(config);
    } else if (model_type == "moonshine") {
      // unreachable
      return std::make_unique<OfflineRecognizerMoonshineImpl>(config);
    } else {
      SHERPA_ONNX_LOGE(
          "Invalid model_type: %s. Trying to load the model to get its type",
          model_type.c_str());
    }
  }

  Ort::Env env(ORT_LOGGING_LEVEL_ERROR);

  Ort::SessionOptions sess_opts;
  sess_opts.SetIntraOpNumThreads(1);
  sess_opts.SetInterOpNumThreads(1);

  std::string model_filename;
  if (!config.model_config.transducer.encoder_filename.empty()) {
    model_filename = config.model_config.transducer.encoder_filename;
  } else if (!config.model_config.paraformer.model.empty()) {
    model_filename = config.model_config.paraformer.model;
  } else if (!config.model_config.nemo_ctc.model.empty()) {
    model_filename = config.model_config.nemo_ctc.model;
  } else if (!config.model_config.telespeech_ctc.empty()) {
    model_filename = config.model_config.telespeech_ctc;
  } else if (!config.model_config.tdnn.model.empty()) {
    model_filename = config.model_config.tdnn.model;
  } else if (!config.model_config.zipformer_ctc.model.empty()) {
    model_filename = config.model_config.zipformer_ctc.model;
  } else if (!config.model_config.wenet_ctc.model.empty()) {
    model_filename = config.model_config.wenet_ctc.model;
  } else if (!config.model_config.whisper.encoder.empty()) {
    model_filename = config.model_config.whisper.encoder;
  } else {
    SHERPA_ONNX_LOGE("Please provide a model");
    SHERPA_ONNX_EXIT(-1);
  }

  auto encoder_sess = std::make_unique<Ort::Session>(
      env, SHERPA_ONNX_TO_ORT_PATH(model_filename), sess_opts);

  Ort::ModelMetadata meta_data = encoder_sess->GetModelMetadata();

  Ort::AllocatorWithDefaultOptions allocator;  // used in the macro below

  auto model_type =
      LookupCustomModelMetaData(meta_data, "model_type", allocator);
  if (model_type.empty()) {
    SHERPA_ONNX_LOGE(
        "No model_type in the metadata!\n\n"
        "Please refer to the following URLs to add metadata"
        "\n"
        "(0) Transducer models from icefall"
        "\n    "
        "https://github.com/k2-fsa/icefall/blob/master/egs/librispeech/ASR/"
        "pruned_transducer_stateless7/export-onnx.py#L303"
        "\n"
        "(1) Nemo CTC models\n    "
        "https://huggingface.co/csukuangfj/"
        "sherpa-onnx-nemo-ctc-en-citrinet-512/blob/main/add-model-metadata.py"
        "\n"
        "(2) Paraformer"
        "\n    "
        "https://huggingface.co/csukuangfj/"
        "paraformer-onnxruntime-python-example/blob/main/add-model-metadata.py"
        "\n    "
        "(3) Whisper"
        "\n    "
        "(4) Tdnn models of the yesno recipe from icefall"
        "\n    "
        "https://github.com/k2-fsa/icefall/tree/master/egs/yesno/ASR/tdnn"
        "\n"
        "(5) Zipformer CTC models from icefall"
        "\n    "
        "https://github.com/k2-fsa/icefall/blob/master/egs/librispeech/ASR/"
        "zipformer/export-onnx-ctc.py"
        "\n"
        "(6) CTC models from WeNet"
        "\n    "
        "https://github.com/k2-fsa/sherpa-onnx/blob/master/scripts/wenet/run.sh"
        "\n"
        "(7) CTC models from TeleSpeech"
        "\n    "
        "https://github.com/Tele-AI/TeleSpeech-ASR"
        "\n"
        "\n");
    SHERPA_ONNX_EXIT(-1);
  }

  if (model_type == "conformer" || model_type == "zipformer" ||
      model_type == "zipformer2") {
    return std::make_unique<OfflineRecognizerTransducerImpl>(config);
  }

  if (model_type == "paraformer") {
    return std::make_unique<OfflineRecognizerParaformerImpl>(config);
  }

  if ((model_type == "EncDecHybridRNNTCTCBPEModel" ||
       model_type == "EncDecRNNTBPEModel") &&
      !config.model_config.transducer.decoder_filename.empty() &&
      !config.model_config.transducer.joiner_filename.empty()) {
    return std::make_unique<OfflineRecognizerTransducerNeMoImpl>(config);
  }

  if (model_type == "EncDecCTCModelBPE" || model_type == "EncDecCTCModel" ||
      model_type == "EncDecHybridRNNTCTCBPEModel" || model_type == "tdnn" ||
      model_type == "zipformer2_ctc" || model_type == "wenet_ctc" ||
      model_type == "telespeech_ctc") {
    return std::make_unique<OfflineRecognizerCtcImpl>(config);
  }

  if (strncmp(model_type.c_str(), "whisper", 7) == 0) {
    return std::make_unique<OfflineRecognizerWhisperImpl>(config);
  }

  SHERPA_ONNX_LOGE(
      "\nUnsupported model_type: %s\n"
      "We support only the following model types at present: \n"
      " - Non-streaming transducer models from icefall\n"
      " - Non-streaming Paraformer models from FunASR\n"
      " - EncDecCTCModelBPE models from NeMo\n"
      " - EncDecCTCModel models from NeMo\n"
      " - EncDecHybridRNNTCTCBPEModel models from NeMo\n"
      " - EncDecRNNTBPEModel models from NeMO"
      " - Whisper models\n"
      " - Tdnn models\n"
      " - Zipformer CTC models\n"
      " - WeNet CTC models\n"
      " - TeleSpeech CTC models\n",
      model_type.c_str());

  SHERPA_ONNX_EXIT(-1);
}

template <typename Manager>
std::unique_ptr<OfflineRecognizerImpl> OfflineRecognizerImpl::Create(
    Manager *mgr, const OfflineRecognizerConfig &config) {
  if (config.model_config.provider == "rknn") {
#if SHERPA_ONNX_ENABLE_RKNN
    if (!config.model_config.sense_voice.model.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelRknn>>(
          mgr, config);
    } else if (!config.model_config.paraformer.model.empty()) {
      return std::make_unique<
          OfflineRecognizerParaformerTplImpl<OfflineParaformerModelRknn>>(
          mgr, config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice and Paraformer models are currently supported "
          "by rknn for non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }
#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_RKNN=ON if you "
        "want to use rknn. See also "
        "https://k2-fsa.github.io/sherpa/onnx/rknn/install.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (config.model_config.provider == "axera") {
#if SHERPA_ONNX_ENABLE_AXERA
    if (!config.model_config.sense_voice.model.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelAxera>>(
          mgr, config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice models are currently supported by Axera NPU for "
          "non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }
#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_AXERA=ON if you "
        "want to use axera. See also "
        "https://k2-fsa.github.io/sherpa/onnx/axera/install.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (config.model_config.provider == "axcl") {
#if SHERPA_ONNX_ENABLE_AXCL
    if (!config.model_config.sense_voice.model.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelAxcl>>(
          mgr, config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice models are currently supported by axcl for "
          "non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }

#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_AXCL=ON if you "
        "want to use axcl. See also "
        "https://k2-fsa.github.io/sherpa/onnx/axcl/install.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (config.model_config.provider == "ascend") {
#if SHERPA_ONNX_ENABLE_ASCEND_NPU
    if (!config.model_config.sense_voice.model.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelAscend>>(
          mgr, config);
    } else if (!config.model_config.paraformer.model.empty()) {
      return std::make_unique<
          OfflineRecognizerParaformerTplImpl<OfflineParaformerModelAscend>>(
          mgr, config);
    } else if (!config.model_config.zipformer_ctc.model.empty()) {
      return std::make_unique<OfflineRecognizerZipformerCtcAscendImpl>(mgr,
                                                                       config);
    } else if (!config.model_config.whisper.encoder.empty()) {
      return std::make_unique<
          OfflineRecognizerWhisperTplImpl<OfflineWhisperModelAscend>>(mgr,
                                                                      config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice, Paraformer, Whisper, and Zipformer CTC models are "
          "currently supported by Ascend NPU for non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }
#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_ASCEND_NPU=ON if "
        "you want to use Ascend NPU. See also "
        "https://k2-fsa.github.io/sherpa/onnx/ascend/install.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (config.model_config.provider == "qnn") {
#if SHERPA_ONNX_ENABLE_QNN
    if (!config.model_config.sense_voice.model.empty() ||
        !config.model_config.sense_voice.qnn_config.context_binary.empty()) {
      return std::make_unique<
          OfflineRecognizerSenseVoiceTplImpl<OfflineSenseVoiceModelQnn>>(
          mgr, config);
    } else if (!config.model_config.zipformer_ctc.model.empty() ||
               !config.model_config.zipformer_ctc.qnn_config.context_binary
                    .empty()) {
      return std::make_unique<OfflineRecognizerZipformerCtcQnnImpl>(mgr,
                                                                    config);
    } else if (!config.model_config.paraformer.model.empty() ||
               !config.model_config.paraformer.qnn_config.context_binary
                    .empty()) {
      return std::make_unique<
          OfflineRecognizerParaformerTplImpl<OfflineParaformerModelQnn>>(
          mgr, config);
    } else {
      SHERPA_ONNX_LOGE(
          "Only SenseVoice, Paraformer, and Zipformer CTC models are currently "
          "supported by QNN for non-streaming ASR.");
      SHERPA_ONNX_EXIT(-1);
      return nullptr;
    }
#else
    SHERPA_ONNX_LOGE(
        "Please rebuild sherpa-onnx with -DSHERPA_ONNX_ENABLE_QNN=ON if "
        "you want to use qnn. See also "
        "https://k2-fsa.github.io/sherpa/onnx/qnn/build.html");
    SHERPA_ONNX_EXIT(-1);
    return nullptr;
#endif
  }

  if (!config.model_config.sense_voice.model.empty()) {
    return std::make_unique<OfflineRecognizerSenseVoiceImpl>(mgr, config);
  }

  if (!config.model_config.funasr_nano.encoder_adaptor.empty()) {
    return std::make_unique<OfflineRecognizerFunASRNanoImpl>(mgr, config);
  }

  if (!config.model_config.paraformer.model.empty()) {
    return std::make_unique<OfflineRecognizerParaformerImpl>(mgr, config);
  }

  if (!config.model_config.nemo_ctc.model.empty() ||
      !config.model_config.zipformer_ctc.model.empty() ||
      !config.model_config.tdnn.model.empty() ||
      !config.model_config.wenet_ctc.model.empty() ||
      !config.model_config.omnilingual.model.empty() ||
      !config.model_config.medasr.model.empty() ||
      !config.model_config.fire_red_asr_ctc.model.empty() ||
      !config.model_config.dolphin.model.empty()) {
    return std::make_unique<OfflineRecognizerCtcImpl>(mgr, config);
  }

  if (!config.model_config.whisper.encoder.empty()) {
    return std::make_unique<OfflineRecognizerWhisperImpl>(mgr, config);
  }

  if (!config.model_config.cohere_transcribe.encoder.empty()) {
    return std::make_unique<OfflineRecognizerCohereTranscribeImpl>(mgr, config);
  }

  if (!config.model_config.fire_red_asr.encoder.empty()) {
    return std::make_unique<OfflineRecognizerFireRedAsrImpl>(mgr, config);
  }

  if (!config.model_config.moonshine.preprocessor.empty()) {
    return std::make_unique<OfflineRecognizerMoonshineImpl>(mgr, config);
  }

  if (!config.model_config.moonshine.merged_decoder.empty()) {
    return std::make_unique<OfflineRecognizerMoonshineV2Impl>(mgr, config);
  }

  if (!config.model_config.canary.encoder.empty()) {
    return std::make_unique<OfflineRecognizerCanaryImpl>(mgr, config);
  }

  if (!config.model_config.qwen3_asr.conv_frontend.empty()) {
    return std::make_unique<OfflineRecognizerQwen3ASRImpl>(mgr, config);
  }

  // TODO(fangjun): Refactor it. We only need to use model type for the
  // following models:
  //  1. transducer and nemo_transducer
  if (!config.model_config.model_type.empty()) {
    const auto &model_type = config.model_config.model_type;
    if (model_type == "transducer") {
      return std::make_unique<OfflineRecognizerTransducerImpl>(mgr, config);
    } else if (model_type == "nemo_transducer") {
      return std::make_unique<OfflineRecognizerTransducerNeMoImpl>(mgr, config);
    } else if (model_type == "paraformer") {
      return std::make_unique<OfflineRecognizerParaformerImpl>(mgr, config);
    } else if (model_type == "nemo_ctc" || model_type == "tdnn" ||
               model_type == "zipformer2_ctc" || model_type == "wenet_ctc" ||
               model_type == "telespeech_ctc") {
      return std::make_unique<OfflineRecognizerCtcImpl>(mgr, config);
    } else if (model_type == "whisper") {
      return std::make_unique<OfflineRecognizerWhisperImpl>(mgr, config);
    } else if (model_type == "moonshine") {
      // unreachable code
      return std::make_unique<OfflineRecognizerMoonshineImpl>(mgr, config);
    } else {
      SHERPA_ONNX_LOGE(
          "Invalid model_type: %s. Trying to load the model to get its type",
          model_type.c_str());
    }
  }

  Ort::Env env(ORT_LOGGING_LEVEL_ERROR);

  Ort::SessionOptions sess_opts;
  sess_opts.SetIntraOpNumThreads(1);
  sess_opts.SetInterOpNumThreads(1);

  std::string model_filename;
  if (!config.model_config.transducer.encoder_filename.empty()) {
    model_filename = config.model_config.transducer.encoder_filename;
  } else if (!config.model_config.paraformer.model.empty()) {
    model_filename = config.model_config.paraformer.model;
  } else if (!config.model_config.nemo_ctc.model.empty()) {
    model_filename = config.model_config.nemo_ctc.model;
  } else if (!config.model_config.tdnn.model.empty()) {
    model_filename = config.model_config.tdnn.model;
  } else if (!config.model_config.zipformer_ctc.model.empty()) {
    model_filename = config.model_config.zipformer_ctc.model;
  } else if (!config.model_config.wenet_ctc.model.empty()) {
    model_filename = config.model_config.wenet_ctc.model;
  } else if (!config.model_config.telespeech_ctc.empty()) {
    model_filename = config.model_config.telespeech_ctc;
  } else if (!config.model_config.whisper.encoder.empty()) {
    model_filename = config.model_config.whisper.encoder;
  } else {
    SHERPA_ONNX_LOGE("Please provide a model");
    SHERPA_ONNX_EXIT(-1);
  }

  auto buf = ReadFile(mgr, model_filename);

  auto encoder_sess =
      std::make_unique<Ort::Session>(env, buf.data(), buf.size(), sess_opts);

  Ort::ModelMetadata meta_data = encoder_sess->GetModelMetadata();

  Ort::AllocatorWithDefaultOptions allocator;  // used in the macro below

  auto model_type =
      LookupCustomModelMetaData(meta_data, "model_type", allocator);
  if (model_type.empty()) {
    SHERPA_ONNX_LOGE(
        "No model_type in the metadata!\n\n"
        "Please refer to the following URLs to add metadata"
        "\n"
        "(0) Transducer models from icefall"
        "\n    "
        "https://github.com/k2-fsa/icefall/blob/master/egs/librispeech/ASR/"
        "pruned_transducer_stateless7/export-onnx.py#L303"
        "\n"
        "(1) Nemo CTC models\n    "
        "https://huggingface.co/csukuangfj/"
        "sherpa-onnx-nemo-ctc-en-citrinet-512/blob/main/add-model-metadata.py"
        "\n"
        "(2) Paraformer"
        "\n    "
        "https://huggingface.co/csukuangfj/"
        "paraformer-onnxruntime-python-example/blob/main/add-model-metadata.py"
        "\n    "
        "(3) Whisper"
        "\n    "
        "(4) Tdnn models of the yesno recipe from icefall"
        "\n    "
        "https://github.com/k2-fsa/icefall/tree/master/egs/yesno/ASR/tdnn"
        "\n"
        "(5) Zipformer CTC models from icefall"
        "\n    "
        "https://github.com/k2-fsa/icefall/blob/master/egs/librispeech/ASR/"
        "zipformer/export-onnx-ctc.py"
        "\n"
        "(6) CTC models from WeNet"
        "\n    "
        "https://github.com/k2-fsa/sherpa-onnx/blob/master/scripts/wenet/run.sh"
        "\n"
        "(7) CTC models from TeleSpeech"
        "\n    "
        "https://github.com/Tele-AI/TeleSpeech-ASR"
        "\n"
        "\n");
    SHERPA_ONNX_EXIT(-1);
  }

  if (model_type == "conformer" || model_type == "zipformer" ||
      model_type == "zipformer2") {
    return std::make_unique<OfflineRecognizerTransducerImpl>(mgr, config);
  }

  if (model_type == "paraformer") {
    return std::make_unique<OfflineRecognizerParaformerImpl>(mgr, config);
  }

  if ((model_type == "EncDecHybridRNNTCTCBPEModel" ||
       model_type == "EncDecRNNTBPEModel") &&
      !config.model_config.transducer.decoder_filename.empty() &&
      !config.model_config.transducer.joiner_filename.empty()) {
    return std::make_unique<OfflineRecognizerTransducerNeMoImpl>(mgr, config);
  }

  if (model_type == "EncDecCTCModelBPE" || model_type == "EncDecCTCModel" ||
      model_type == "EncDecHybridRNNTCTCBPEModel" || model_type == "tdnn" ||
      model_type == "zipformer2_ctc" || model_type == "wenet_ctc" ||
      model_type == "telespeech_ctc") {
    return std::make_unique<OfflineRecognizerCtcImpl>(mgr, config);
  }

  if (strncmp(model_type.c_str(), "whisper", 7) == 0) {
    return std::make_unique<OfflineRecognizerWhisperImpl>(mgr, config);
  }

  SHERPA_ONNX_LOGE(
      "\nUnsupported model_type: %s\n"
      "We support only the following model types at present: \n"
      " - Non-streaming transducer models from icefall\n"
      " - Non-streaming Paraformer models from FunASR\n"
      " - EncDecCTCModelBPE models from NeMo\n"
      " - EncDecCTCModel models from NeMo\n"
      " - EncDecHybridRNNTCTCBPEModel models from NeMo\n"
      " - EncDecRNNTBPEModel models from NeMo\n"
      " - Whisper models\n"
      " - Tdnn models\n"
      " - Zipformer CTC models\n"
      " - WeNet CTC models\n"
      " - TeleSpeech CTC models\n",
      model_type.c_str());

  SHERPA_ONNX_EXIT(-1);
}

OfflineRecognizerImpl::OfflineRecognizerImpl(
    const OfflineRecognizerConfig &config)
    : config_(config) {
  // TODO(fangjun): Refactor this function

  if (!config.rule_fsts.empty()) {
    std::vector<std::string> files;
    SplitStringToVector(config.rule_fsts, ",", false, &files);
    itn_list_.reserve(files.size());
    for (const auto &f : files) {
      if (config.model_config.debug) {
        SHERPA_ONNX_LOGE("rule fst: %s", f.c_str());
      }
      itn_list_.push_back(std::make_unique<kaldifst::TextNormalizer>(f));
    }
  }

  if (!config.rule_fars.empty()) {
    if (config.model_config.debug) {
      SHERPA_ONNX_LOGE("Loading FST archives");
    }
    std::vector<std::string> files;
    SplitStringToVector(config.rule_fars, ",", false, &files);

    itn_list_.reserve(files.size() + itn_list_.size());

    for (const auto &f : files) {
      if (config.model_config.debug) {
        SHERPA_ONNX_LOGE("rule far: %s", f.c_str());
      }
      std::unique_ptr<fst::FarReader<fst::StdArc>> reader(
          fst::FarReader<fst::StdArc>::Open(f));
      for (; !reader->Done(); reader->Next()) {
        std::unique_ptr<fst::StdConstFst> r(
            fst::CastOrConvertToConstFst(reader->GetFst()->Copy()));

        itn_list_.push_back(
            std::make_unique<kaldifst::TextNormalizer>(std::move(r)));
      }
    }

    if (config.model_config.debug) {
      SHERPA_ONNX_LOGE("FST archives loaded!");
    }
  }

  if (!config.hr.lexicon.empty() && !config.hr.rule_fsts.empty()) {
    auto hr_config = config.hr;
    hr_config.debug = config.model_config.debug;
    hr_ = std::make_unique<HomophoneReplacer>(hr_config);
  }
}

template <typename Manager>
OfflineRecognizerImpl::OfflineRecognizerImpl(
    Manager *mgr, const OfflineRecognizerConfig &config)
    : config_(config) {
  if (!config.rule_fsts.empty()) {
    std::vector<std::string> files;
    SplitStringToVector(config.rule_fsts, ",", false, &files);
    itn_list_.reserve(files.size());
    for (const auto &f : files) {
      if (config.model_config.debug) {
        SHERPA_ONNX_LOGE("rule fst: %s", f.c_str());
      }
      auto buf = ReadFile(mgr, f);
      std::istringstream is(std::string(buf.data(), buf.size()));
      itn_list_.push_back(std::make_unique<kaldifst::TextNormalizer>(is));
    }
  }

  if (!config.rule_fars.empty()) {
    std::vector<std::string> files;
    SplitStringToVector(config.rule_fars, ",", false, &files);
    itn_list_.reserve(files.size() + itn_list_.size());

    for (const auto &f : files) {
      if (config.model_config.debug) {
        SHERPA_ONNX_LOGE("rule far: %s", f.c_str());
      }

      auto buf = ReadFile(mgr, f);

      auto fsts = ReadFstsFromFar(buf);
      for (auto &r : fsts) {
        itn_list_.push_back(
            std::make_unique<kaldifst::TextNormalizer>(std::move(r)));
      }
    }  // for (const auto &f : files)
  }  // if (!config.rule_fars.empty())

  if (!config.hr.lexicon.empty() && !config.hr.rule_fsts.empty()) {
    auto hr_config = config.hr;
    hr_config.debug = config.model_config.debug;
    hr_ = std::make_unique<HomophoneReplacer>(mgr, hr_config);
  }
}

std::string OfflineRecognizerImpl::ApplyInverseTextNormalization(
    std::string text) const {
  text = RemoveInvalidUtf8Sequences(text);

  if (!itn_list_.empty()) {
    for (const auto &tn : itn_list_) {
      text = tn->Normalize(text);
    }
  }

  return text;
}

std::string OfflineRecognizerImpl::ApplyHomophoneReplacer(
    std::string text) const {
  if (hr_) {
    text = hr_->Apply(text);
  }

  return text;
}

void OfflineRecognizerImpl::SetConfig(const OfflineRecognizerConfig &config) {
  config_ = config;
}

#if __ANDROID_API__ >= 9
template OfflineRecognizerImpl::OfflineRecognizerImpl(
    AAssetManager *mgr, const OfflineRecognizerConfig &config);

template std::unique_ptr<OfflineRecognizerImpl> OfflineRecognizerImpl::Create(
    AAssetManager *mgr, const OfflineRecognizerConfig &config);
#endif

#if __OHOS__
template OfflineRecognizerImpl::OfflineRecognizerImpl(
    NativeResourceManager *mgr, const OfflineRecognizerConfig &config);
template std::unique_ptr<OfflineRecognizerImpl> OfflineRecognizerImpl::Create(
    NativeResourceManager *mgr, const OfflineRecognizerConfig &config);
#endif

}  // namespace sherpa_onnx
