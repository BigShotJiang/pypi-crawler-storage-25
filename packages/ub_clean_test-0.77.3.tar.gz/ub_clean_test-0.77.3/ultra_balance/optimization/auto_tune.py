import json
import os
import random

class AutoTuner:
    """
    自动调参模块：自动寻找最优控制参数
    让机器人自己试、自己记住最好的
    """
    
    def __init__(self, param_ranges, memory_file='tuner_memory.json'):
        """
        param_ranges: 参数范围 {'kp': [50, 300], 'kd': [10, 60]}
        """
        self.param_ranges = param_ranges
        self.memory_file = memory_file
        self.best_params = self._load_best()
    
    def _load_best(self):
        """加载最优参数"""
        if os.path.exists(self.memory_file):
            with open(self.memory_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_best(self):
        """保存最优参数"""
        with open(self.memory_file, 'w') as f:
            json.dump(self.best_params, f, indent=2)
    
    def suggest_params(self):
        """
        建议一组参数（基于历史最优 + 随机探索）
        """
        if self.best_params:
            # 在最优参数附近微调
            params = {}
            for name, (min_val, max_val) in self.param_ranges.items():
                best = self.best_params.get(name, (min_val + max_val) / 2)
                # 在最优值 ±20% 范围内随机
                delta = (max_val - min_val) * 0.2
                params[name] = random.uniform(best - delta, best + delta)
                params[name] = max(min_val, min(max_val, params[name]))
        else:
            # 第一次：随机探索
            params = {}
            for name, (min_val, max_val) in self.param_ranges.items():
                params[name] = random.uniform(min_val, max_val)
        return params
    
    def update_best(self, params, score):
        """
        更新最优参数
        score: 越小越好（如误差）
        """
        # 如果还没有最优，或者新参数更好
        if not self.best_params or score < self.best_params.get('_score', float('inf')):
            self.best_params = {**params, '_score': score}
            self._save_best()
            return True
        return False
    
    def get_best(self):
        """获取当前最优参数"""
        best = {k: v for k, v in self.best_params.items() if not k.startswith('_')}
        return best