import time

class SelfReflection:
    """
    自我反思模块：回顾过去，总结教训
    """
    
    def __init__(self):
        self.history = []  # 历史记录
        self.lessons = []  # 学到的教训
    
    def record_event(self, event_type, details, success=True):
        """记录一个事件"""
        event = {
            'type': event_type,
            'details': details,
            'success': success,
            'timestamp': time.time()
        }
        self.history.append(event)
        return f"已记录: {event_type}"
    
    def reflect(self):
        """反思最近的事件，总结教训"""
        lessons = []
        
        # 分析失败的事件
        failures = [e for e in self.history if not e['success']]
        if failures:
            last_failure = failures[-1]
            lesson = f"从 {last_failure['type']} 学到: {last_failure['details'].get('reason', '未知原因')}"
            lessons.append(lesson)
        
        # 分析成功的事件
        successes = [e for e in self.history if e['success']]
        if successes:
            last_success = successes[-1]
            lesson = f"从 {last_success['type']} 学到: 这样做是对的"
            lessons.append(lesson)
        
        # 保存教训
        for l in lessons:
            if l not in self.lessons:
                self.lessons.append(l)
        
        return lessons
    
    def get_lessons(self):
        """获取所有学到的教训"""
        return self.lessons
    
    def improve_next_time(self, event_type):
        """根据教训，改进下次行动"""
        for lesson in self.lessons:
            if event_type in lesson:
                return f"改进建议: {lesson}"
        return "暂无改进建议"