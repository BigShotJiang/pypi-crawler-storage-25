import random
import math

class CuriosityModule:
    """
    好奇机制：主动探索未知
    """
    
    def __init__(self):
        self.known_places = set()      # 去过的地方
        self.known_objects = set()     # 见过的物体
        self.known_actions = set()     # 做过的动作
        self.exploration_history = []  # 探索记录
    
    def is_place_known(self, place):
        """这个地方去过吗"""
        return place in self.known_places
    
    def is_object_known(self, obj):
        """这个物体见过吗"""
        return obj in self.known_objects
    
    def is_action_known(self, action):
        """这个动作做过吗"""
        return action in self.known_actions
    
    def get_curiosity_score(self, place, obj, action):
        """
        计算对某件事的好奇程度
        越未知，越好奇
        """
        score = 0
        if not self.is_place_known(place):
            score += 1
        if not self.is_object_known(obj):
            score += 1
        if not self.is_action_known(action):
            score += 1
        return score / 3.0
    
    def explore(self, place=None, obj=None, action=None):
        """
        主动探索
        """
        if place and not self.is_place_known(place):
            self.known_places.add(place)
            self.exploration_history.append(f"探索了新地方: {place}")
            return f"去探索了 {place}！"
        
        if obj and not self.is_object_known(obj):
            self.known_objects.add(obj)
            self.exploration_history.append(f"发现了新物体: {obj}")
            return f"发现了 {obj}！"
        
        if action and not self.is_action_known(action):
            self.known_actions.add(action)
            self.exploration_history.append(f"尝试了新动作: {action}")
            return f"尝试了 {action}！"
        
        return "没有新东西可探索"
    
    def suggest_exploration(self):
        """
        建议去哪里探索
        """
        suggestions = []
        # 随机生成探索建议
        possible_places = ['厨房', '客厅', '卧室', '书房', '阳台']
        possible_objects = ['红色方块', '蓝色杯子', '绿色球', '黄色盒子', '白色纸张']
        possible_actions = ['跳跃', '旋转', '挥手', '蹲下', '转圈']
        
        for p in possible_places:
            if not self.is_place_known(p):
                suggestions.append(f"去{p}看看")
                break
        for o in possible_objects:
            if not self.is_object_known(o):
                suggestions.append(f"看看{o}")
                break
        for a in possible_actions:
            if not self.is_action_known(a):
                suggestions.append(f"试试{a}")
                break
        
        return suggestions if suggestions else ["到处看看"]
    
    def get_curiosity_status(self):
        """
        获取好奇状态
        """
        return {
            'known_places': len(self.known_places),
            'known_objects': len(self.known_objects),
            'known_actions': len(self.known_actions),
            'exploration_count': len(self.exploration_history)
        }