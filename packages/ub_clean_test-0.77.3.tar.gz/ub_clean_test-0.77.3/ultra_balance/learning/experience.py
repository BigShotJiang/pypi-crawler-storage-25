import json
import os

class ExperienceMemory:
    """
    经验记忆模块：记录成功/失败的经验
    让机器人能“记住”之前做过的事
    """
    
    def __init__(self, memory_file='memory.json'):
        self.memory_file = memory_file
        self.memory = self._load_memory()
    
    def _load_memory(self):
        """加载记忆文件"""
        if os.path.exists(self.memory_file):
            with open(self.memory_file, 'r') as f:
                return json.load(f)
        return {'success': {}, 'fail': {}}
    
    def _save_memory(self):
        """保存记忆"""
        with open(self.memory_file, 'w') as f:
            json.dump(self.memory, f, indent=2)
    
    def remember(self, command, result):
        """
        记住一次执行结果
        result: {'success': True, 'path': [...], 'time': 3.2}
        """
        if result.get('success'):
            if command not in self.memory['success']:
                self.memory['success'][command] = []
            self.memory['success'][command].append(result)
        else:
            if command not in self.memory['fail']:
                self.memory['fail'][command] = []
            self.memory['fail'][command].append(result)
        self._save_memory()
    
    def recall(self, command):
        """
        回忆之前成功的经验
        返回: 最佳经验 (用时最短的)
        """
        if command in self.memory['success']:
            best = min(self.memory['success'][command], key=lambda x: x.get('time', 999))
            return best
        return None
    
    def forget(self, command=None):
        """忘记经验（可选）"""
        if command:
            self.memory['success'].pop(command, None)
            self.memory['fail'].pop(command, None)
        else:
            self.memory = {'success': {}, 'fail': {}}
        self._save_memory()