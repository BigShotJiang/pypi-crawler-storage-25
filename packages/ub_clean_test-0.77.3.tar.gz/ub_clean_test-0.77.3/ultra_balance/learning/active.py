class ActiveLearner:
    """
    主动学习模块：不确定就问
    """
    
    def __init__(self):
        self.knowledge = {}
        self.uncertain_threshold = 0.3
    
    def ask(self, question):
        """主动提问"""
        return f"🤔 我不确定，请问：{question}"
    
    def learn_from_answer(self, query, answer):
        """从答案中学习"""
        self.knowledge[query] = answer
        return f"✅ 学会了：{query} 是 {answer}"
    
    def predict(self, query):
        """预测，不确定就返回 None"""
        if query in self.knowledge:
            return self.knowledge[query]
        
        # 模拟不确定性评估
        if len(query) < 5:
            return None  # 太短，不确定
        return None
    
    def handle_uncertainty(self, query):
        """处理不确定的情况"""
        if query in self.knowledge:
            return self.knowledge[query]
        
        # 生成问题
        question = f"“{query}”是什么意思？"
        return self.ask(question)
    
    def learn_from_interaction(self, query, user_teaching=None):
        """从交互中学习"""
        if user_teaching:
            return self.learn_from_answer(query, user_teaching)
        
        result = self.predict(query)
        if result is None:
            return self.handle_uncertainty(query)
        return result