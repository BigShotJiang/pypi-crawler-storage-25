import time

class ImitationLearner:
    """
    模仿学习模块：看人做一遍就会
    """
    
    def __init__(self):
        self.demonstrations = {}  # 存储演示的动作序列
        self.current_demo = []    # 当前正在录制的演示
        self.recording = False
    
    def start_recording(self, name):
        """开始录制一个动作"""
        self.recording = True
        self.current_demo = []
        self.current_name = name
        return f"开始录制: {name}"
    
    def record_step(self, action, params=None):
        """记录一步动作"""
        if self.recording:
            step = {
                'action': action,
                'params': params,
                'timestamp': time.time()
            }
            self.current_demo.append(step)
            return f"记录: {action}"
        return "未在录制中"
    
    def stop_recording(self):
        """停止录制并保存"""
        if self.recording and self.current_demo:
            self.demonstrations[self.current_name] = self.current_demo
            self.recording = False
            return f"保存成功: {self.current_name}，共 {len(self.current_demo)} 步"
        return "没有录制的动作"
    
    def imitate(self, name):
        """模仿已录制的动作"""
        if name not in self.demonstrations:
            return f"没有找到演示: {name}"
        
        demo = self.demonstrations[name]
        result = []
        for step in demo:
            result.append(f"执行: {step['action']} {step.get('params', '')}")
        return result
    
    def list_demonstrations(self):
        """列出所有已保存的演示"""
        return list(self.demonstrations.keys())