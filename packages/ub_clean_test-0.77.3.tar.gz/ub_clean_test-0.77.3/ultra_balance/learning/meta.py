class MetaLearner:
    """
    元学习模块：学会如何学习
    """
    
    def __init__(self):
        self.strategies = {
            'imitation': {'used': 0, 'success': 0, 'avg_time': 0},
            'curiosity': {'used': 0, 'success': 0, 'avg_time': 0},
            'reflection': {'used': 0, 'success': 0, 'avg_time': 0},
            'trial_error': {'used': 0, 'success': 0, 'avg_time': 0},
        }
        self.current_strategy = 'imitation'
    
    def select_strategy(self, task_type):
        """根据任务类型选择最佳学习策略"""
        # 简单规则：不同任务选不同方法
        if task_type in ['grasp', 'move']:
            return 'imitation'
        elif task_type in ['explore', 'find']:
            return 'curiosity'
        elif task_type in ['avoid', 'correct']:
            return 'reflection'
        else:
            return 'trial_error'
    
    def record_result(self, strategy, success, time_taken):
        """记录学习结果"""
        if strategy in self.strategies:
            self.strategies[strategy]['used'] += 1
            if success:
                self.strategies[strategy]['success'] += 1
            
            # 更新平均时间
            old = self.strategies[strategy]['avg_time']
            n = self.strategies[strategy]['used']
            self.strategies[strategy]['avg_time'] = (old * (n-1) + time_taken) / n
    
    def get_best_strategy(self):
        """获取成功率最高的策略"""
        best = None
        best_rate = -1
        for name, data in self.strategies.items():
            if data['used'] > 0:
                rate = data['success'] / data['used']
                if rate > best_rate:
                    best_rate = rate
                    best = name
        return best, best_rate
    
    def analyze_performance(self):
        """分析学习效果"""
        report = []
        for name, data in self.strategies.items():
            if data['used'] > 0:
                rate = data['success'] / data['used']
                report.append(f"{name}: 成功率 {rate:.0%} (平均 {data['avg_time']:.1f}秒)")
        return report
    
    def suggest_improvement(self):
        """建议改进学习策略"""
        best, rate = self.get_best_strategy()
        if best:
            return f"建议优先使用 {best} 策略，成功率 {rate:.0%}"
        return "暂无足够数据，请多尝试"