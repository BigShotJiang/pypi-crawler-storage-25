class EmotionalExpression:
    """
    情感表达模块：根据情绪调整输出
    """
    
    def __init__(self):
        self.current_emotion = 'neutral'
        
        # 不同情绪的说话风格
        self.styles = {
            '开心': {
                'suffix': '！',
                'tone': '兴奋',
                'template': '{} 真好呀{}'
            },
            '生气': {
                'suffix': '！！',
                'tone': '严肃',
                'template': '{} 请不要这样{}'
            },
            '难过': {
                'suffix': '...',
                'tone': '低落',
                'template': '{} 唉{}'
            },
            '害怕': {
                'suffix': '！',
                'tone': '紧张',
                'template': '{} 我好怕{}'
            },
            '惊讶': {
                'suffix': '！！',
                'tone': '激动',
                'template': '{} 真的吗{}'
            },
            'neutral': {
                'suffix': '。',
                'tone': '平静',
                'template': '{} {}'
            }
        }
    
    def set_emotion(self, emotion):
        """设置当前情绪"""
        if emotion in self.styles:
            self.current_emotion = emotion
            return f"情绪已设为: {emotion}"
        return f"不支持的情绪: {emotion}"
    
    def express(self, message):
        """根据当前情绪表达消息"""
        style = self.styles.get(self.current_emotion, self.styles['neutral'])
        suffix = style['suffix']
        
        # 根据情绪调整消息
        if self.current_emotion == '开心':
            msg = f"{message}{suffix}"
        elif self.current_emotion == '生气':
            msg = f"{message}！{suffix}"
        elif self.current_emotion == '难过':
            msg = f"{message}...{suffix}"
        else:
            msg = f"{message}{suffix}"
        
        return {
            'text': msg,
            'tone': style['tone'],
            'emotion': self.current_emotion
        }
    
    def express_to(self, message, target_emotion):
        """针对目标情绪表达"""
        original = self.current_emotion
        self.set_emotion(target_emotion)
        result = self.express(message)
        self.set_emotion(original)
        return result