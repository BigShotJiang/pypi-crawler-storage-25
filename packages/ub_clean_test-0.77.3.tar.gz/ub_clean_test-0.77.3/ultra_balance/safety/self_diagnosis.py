class SelfDiagnosis:
    """
    自检系统：检查机器人自身状态
    """
    
    def __init__(self):
        self.battery_level = 100  # 百分比
        self.motor_temp = 25      # 摄氏度
        self.sensor_status = {
            'camera': True,
            'mic': True,
            'imu': True,
            'encoder': True
        }
        self.last_check = None
    
    def check_battery(self):
        """检查电池"""
        if self.battery_level < 10:
            return False, f"电量过低 ({self.battery_level}%)，需要充电"
        elif self.battery_level < 20:
            return True, f"电量不足 ({self.battery_level}%)，建议充电"
        return True, f"电量充足 ({self.battery_level}%)"
    
    def check_motor(self):
        """检查电机温度"""
        if self.motor_temp > 80:
            return False, f"电机过热 ({self.motor_temp}°C)，需要冷却"
        elif self.motor_temp > 60:
            return True, f"电机温度偏高 ({self.motor_temp}°C)，注意散热"
        return True, f"电机温度正常 ({self.motor_temp}°C)"
    
    def check_sensors(self):
        """检查传感器"""
        failed = [name for name, status in self.sensor_status.items() if not status]
        if failed:
            return False, f"传感器故障: {', '.join(failed)}"
        return True, "所有传感器正常"
    
    def run_diagnosis(self):
        """运行完整自检"""
        results = {
            'battery': self.check_battery(),
            'motor': self.check_motor(),
            'sensors': self.check_sensors()
        }
        
        # 总体状态
        all_ok = all(r[0] for r in results.values())
        status = "✅ 系统正常" if all_ok else "⚠️ 存在问题"
        
        return {
            'status': status,
            'details': results,
            'can_work': all_ok
        }
    
    def simulate_degradation(self):
        """模拟状态恶化（用于演示）"""
        self.battery_level -= 5
        self.motor_temp += 3
        if self.motor_temp > 70:
            self.sensor_status['camera'] = False