import time

class FaultRecovery:
    """
    故障恢复模块：检测故障并尝试修复
    """
    
    def __init__(self):
        self.fault_log = []
        self.recovery_attempts = 0
        self.in_safe_mode = False
    
    def detect_fault(self, fault_type, details=None):
        """
        检测故障
        fault_type: 'motor_overheat', 'sensor_failure', 'low_battery', etc.
        """
        fault = {
            'type': fault_type,
            'details': details,
            'timestamp': time.time(),
            'recovered': False
        }
        self.fault_log.append(fault)
        return fault
    
    def recover(self, fault):
        """
        尝试修复故障
        """
        fault_type = fault['type']
        
        if fault_type == 'motor_overheat':
            # 降速运行
            self.recovery_attempts += 1
            fault['recovered'] = True
            return True, "电机过热，已降速运行"
        
        elif fault_type == 'sensor_failure':
            # 切换到备用传感器
            self.recovery_attempts += 1
            fault['recovered'] = True
            return True, "传感器故障，已切换到备用"
        
        elif fault_type == 'low_battery':
            # 返回充电
            self.recovery_attempts += 1
            fault['recovered'] = True
            return True, "电量不足，正在返回充电"
        
        elif fault_type == 'communication_error':
            # 重试连接
            self.recovery_attempts += 1
            fault['recovered'] = True
            return True, "通信故障，已重新连接"
        
        else:
            # 未知故障，进入安全模式
            self.in_safe_mode = True
            return False, f"未知故障 ({fault_type})，已进入安全模式"
    
    def safe_mode_action(self):
        """
        安全模式下的行为
        """
        if self.in_safe_mode:
            return "正在执行安全协议：停止运动，等待检修"
        return "正常运行"
    
    def get_status(self):
        """
        获取当前状态
        """
        recent_faults = [f for f in self.fault_log if not f['recovered']]
        return {
            'in_safe_mode': self.in_safe_mode,
            'pending_faults': len(recent_faults),
            'recovery_attempts': self.recovery_attempts,
            'message': self.safe_mode_action()
        }