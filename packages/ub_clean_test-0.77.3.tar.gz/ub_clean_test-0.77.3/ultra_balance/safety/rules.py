class SafetyRules:
    """
    安全规则库：定义机器人不能做的事
    """
    
    def __init__(self):
        # 禁止区域（坐标范围）
        self.forbidden_zones = [
            {'name': 'cliff', 'x_range': (8, 10), 'y_range': (-10, 10), 'danger': 'high'},
            {'name': 'water', 'x_range': (-10, -8), 'y_range': (-10, 10), 'danger': 'high'},
        ]
        
        # 禁止物体
        self.forbidden_objects = ['fire', 'electricity', 'sharp']
        
        # 禁止动作
        self.forbidden_actions = ['hit_human', 'break_glass', 'touch_fire']
    
    def is_position_safe(self, x, y):
        """检查位置是否安全"""
        for zone in self.forbidden_zones:
            if zone['x_range'][0] <= x <= zone['x_range'][1] and \
               zone['y_range'][0] <= y <= zone['y_range'][1]:
                return False, zone['name'], zone['danger']
        return True, None, None
    
    def is_object_safe(self, obj_name):
        """检查物体是否安全"""
        return obj_name not in self.forbidden_objects
    
    def is_action_safe(self, action_name):
        """检查动作是否安全"""
        return action_name not in self.forbidden_actions
    
    def check_task(self, task):
        """
        检查整个任务是否安全
        task: {'type': 'move', 'target': (x,y), 'object': 'red'}
        """
        warnings = []
        
        # 检查目标位置
        if task.get('target'):
            safe, danger, level = self.is_position_safe(task['target'][0], task['target'][1])
            if not safe:
                warnings.append(f"目标位置 {task['target']} 在危险区域: {danger}")
        
        # 检查目标物体
        if task.get('object'):
            if not self.is_object_safe(task['object']):
                warnings.append(f"目标物体 {task['object']} 是禁止触碰的")
        
        return warnings