from ultra_balance.perception.emotion import EmotionRecognizer

# 创建情感识别器
recognizer = EmotionRecognizer()

print("=" * 50)
print("情感识别演示")
print("=" * 50)

# 测试句子
test_sentences = [
    "太好了！今天天气真好！",
    "烦死了，怎么又坏了！",
    "唉，今天好难过...",
    "吓死我了，刚才差点撞到！",
    "哇！你居然会这个！",
    "把杯子拿给我。"
]

print("\n[情感识别]")
for text in test_sentences:
    result = recognizer.recognize(text)
    response = recognizer.respond_to_emotion(result['emotion'])
    print(f"  用户说: {text}")
    print(f"    情绪: {result['emotion']} (置信度: {result['confidence']})")
    print(f"    回应: {response}\n")