from ultra_balance.reasoning.intent_understanding import IntentUnderstanding

# 创建意图理解器
iu = IntentUnderstanding()

print("=" * 50)
print("意图理解演示")
print("=" * 50)

tests = [
    "我渴了",
    "好渴",
    "有点渴",
    "我饿了",
    "好饿",
    "热死了",
    "有点热",
    "好冷",
    "天黑了",
    "太亮了",
]

print("\n[意图理解]")
for t in tests:
    result = iu.understand(t)
    print(f"  用户说: {t}")
    print(f"  机器人: {result}\n")

print("\n[意图状态]")
print(f"  当前意图: {iu.get_intent_status()}")
print(f"  建议行动: {iu.suggest_action()}")