from ultra_balance.reasoning.error_reflection import ErrorReflection


def main():
    print("\n" + "🔄" * 20)
    print("  ub-clean-test 0.63.0 错误反思模块演示")
    print("🔄" * 20)
    
    er = ErrorReflection()
    
    # 1. 错误记录
    print("\n" + "=" * 50)
    print(" 📝 错误记录")
    print("=" * 50)
    
    error_id1 = er.record_error(
        error_type="推理矛盾",
        description="推理得出'企鹅会飞'，但常识告诉企鹅不会飞",
        context={"premise": "所有鸟都会飞", "fact": "企鹅是鸟"},
        severity=8
    )
    print(f"  记录错误1: {error_id1}")
    
    error_id2 = er.record_error(
        error_type="信息不足",
        description="判断是否需要带伞，但不知道是否下雨",
        context={"task": "出门决策"},
        severity=6
    )
    print(f"  记录错误2: {error_id2}")
    
    # 2. 原因分析
    print("\n" + "=" * 50)
    print(" 🔍 原因分析")
    print("=" * 50)
    
    cause1 = er.analyze_cause(error_id1)
    print(f"  错误1原因: {cause1['cause']}")
    print(f"  建议: {cause1['suggestions']}")
    
    cause2 = er.analyze_cause(error_id2)
    print(f"\n  错误2原因: {cause2['cause']}")
    print(f"  建议: {cause2['suggestions']}")
    
    # 3. 教训提取
    print("\n" + "=" * 50)
    print(" 📖 教训提取")
    print("=" * 50)
    
    lesson_id = er.extract_lesson(error_id1)
    print(f"  从错误1提取教训: {lesson_id}")
    
    # 查看教训内容
    for lesson in er.lessons:
        if lesson.lesson_id == lesson_id:
            print(f"  教训内容: {lesson.content}")
    
    # 4. 行为修正
    print("\n" + "=" * 50)
    print(" 🔧 行为修正")
    print("=" * 50)
    
    # 应用修正
    er.apply_correction(error_id1, "检查前提条件：所有鸟都会飞？企鹅特殊例外")
    
    rule = er.get_correction_rule("推理矛盾")
    print(f"  修正规则: {rule}")
    
    # 5. 自我改进
    print("\n" + "=" * 50)
    print(" 📈 自我改进")
    print("=" * 50)
    
    improvement = er.improve()
    print(f"  改进项数: {len(improvement['improvements'])}")
    for imp in improvement['improvements'][:3]:
        print(f"    - {imp}")
    print(f"  应用教训数: {improvement['lessons_applied']}")
    
    # 6. 防止重复犯错
    print("\n" + "=" * 50)
    print(" ⚠️ 执行前检查")
    print("=" * 50)
    
    check1 = er.check_before_action("推理企鹅是否会飞")
    print(f"  动作: 推理企鹅是否会飞")
    print(f"  安全: {check1['safe']}")
    if check1['warnings']:
        print(f"  警告: {check1['warnings'][0]}")
    
    check2 = er.check_before_action("新任务")
    print(f"\n  动作: 新任务")
    print(f"  安全: {check2['safe']}")
    
    # 7. 反思报告
    print("\n" + "=" * 50)
    print(" 📊 反思报告")
    print("=" * 50)
    
    report = er.reflect()
    print(f"  总错误数: {report['total_errors']}")
    print(f"  已解决: {report['resolved_count']}")
    print(f"  常见错误: {report['common_errors']}")
    print(f"  最近教训: {report['lessons_learned'][0] if report['lessons_learned'] else '无'}")
    
    # 8. 统计报告
    print("\n" + "=" * 50)
    print(" 📈 统计报告")
    print("=" * 50)
    
    stats = er.get_statistics()
    print(f"  总错误: {stats['total_errors']}")
    print(f"  解决率: {stats['resolution_rate']:.0%}")
    print(f"  高严重性: {stats['high_severity_count']}")
    print(f"  教训总数: {stats['total_lessons']}")
    print(f"  修正规则: {stats['correction_rules']}")
    
    print("\n" + "✅" * 20)
    print("  所有错误反思演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()