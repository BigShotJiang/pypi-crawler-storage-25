from ultra_balance.perception.temperature import TemperaturePerception

# 创建温度感知器
tp = TemperaturePerception()

print("=" * 50)
print("温度感知演示")
print("=" * 50)

tests = [
    "极冷",
    "很冷",
    "冷",
    "凉快",
    "正常",
    "温暖",
    "热",
    "很热",
    "极热",
    "25度",
    "0度",
    "100度",
    "再热一点",
    "再冷一点",
    "升温",
    "降温",
]

print("\n[温度理解]")
for t in tests:
    result = tp.understand(t)
    print(f"  {t} → {result}")

print("\n[温度状态]")
temps = [-10, 0, 10, 18, 22, 26, 30, 35, 40]
for t in temps:
    tp.set_current_temp(t)
    print(f"  {t}度 → {tp.get_temp_status()}")
    print(f"         {tp.suggest_action()}")