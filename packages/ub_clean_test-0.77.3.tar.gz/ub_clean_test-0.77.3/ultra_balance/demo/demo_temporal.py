import time
from ultra_balance.reasoning.temporal import TemporalReasoner

# 创建时序推理器
reasoner = TemporalReasoner()

print("=" * 50)
print("时序推理演示")
print("=" * 50)

# 理解顺序
print("\n[理解顺序]")
print(reasoner.understand_order("先拿水杯，再倒水"))
print(reasoner.understand_order("先去厨房，然后拿红色方块"))

# 估计耗时
print("\n[估计耗时]")
print(reasoner.estimate_time("去厨房"))
print(reasoner.estimate_time("充电"))
print(reasoner.estimate_time("拿水杯"))

# 安排时序
print("\n[安排时序]")
plan = reasoner.schedule(["充电", "去厨房", "拿水杯", "回来"])
for step in plan['order']:
    print(f"  {step}")
print(f"  {plan['message']}")

# 记录事件
print("\n[记录事件]")
print(reasoner.record_event("拿红色方块"))
time.sleep(0.5)
print(reasoner.record_event("去厨房"))
time.sleep(0.5)
print(reasoner.record_event("和主人说话"))

# 回忆事件
print("\n[回忆事件]")
print(reasoner.recall_event("拿红色方块"))
print(reasoner.recall_event("去厨房"))
print(reasoner.recall_event("和主人说话"))