from ultra_balance.reasoning.causal import CausalReasoner

# 创建因果推理器
reasoner = CausalReasoner()

print("=" * 50)
print("因果推理演示")
print("=" * 50)

# 预测结果
print("\n[预测结果]")
actions = ['touch_fire', 'fall', 'low_battery', 'overheat', 'hit_wall']
for action in actions:
    effect = reasoner.predict_effect(action)
    print(f"  如果 {action} → 会导致 {effect}")

# 解释原因
print("\n[解释原因]")
effects = ['burn', 'hurt', 'stop', 'damage_motor', 'damage']
for effect in effects:
    cause = reasoner.explain_cause(effect)
    print(f"  出现 {effect} → 可能是因为 {cause}")

# 情景推理
print("\n[情景推理]")
situations = [
    "floor has water",
    "battery is low",
    "motor is hot",
    "fire nearby"
]
for sit in situations:
    advice = reasoner.reason(sit)
    print(f"  情景: {sit}")
    print(f"    建议: {advice}")

# 假设推理
print("\n[假设推理]")
whatif = reasoner.what_if("touch_fire", "kitchen")
print(f"  假设: {whatif}")