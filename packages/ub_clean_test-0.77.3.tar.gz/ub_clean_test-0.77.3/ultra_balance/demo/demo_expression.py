from ultra_balance.expression.emotion import EmotionalExpression

# 创建情感表达模块
express = EmotionalExpression()

print("=" * 50)
print("情感表达演示")
print("=" * 50)

# 测试不同情绪下的表达
emotions = ['开心', '生气', '难过', '害怕', '惊讶', 'neutral']
messages = [
    "任务完成了",
    "杯子拿来了",
    "我帮你打扫好了",
    "发现一个障碍物"
]

print("\n[不同情绪下的表达]")
for emotion in emotions:
    express.set_emotion(emotion)
    for msg in messages[:2]:
        result = express.express(msg)
        print(f"  情绪 {emotion}: '{result['text']}' (语气: {result['tone']})")
    print()

# 针对情绪的回应
print("\n[针对情绪的回应]")
express.set_emotion('neutral')
responses = [
    ("你开心吗？", '开心'),
    ("你生气了吗？", '生气'),
    ("你难过了？", '难过')
]
for msg, target_emotion in responses:
    result = express.express_to(msg, target_emotion)
    print(f"  用户问: {msg}")
    print(f"    机器人回应: '{result['text']}' (情绪: {result['emotion']})\n")