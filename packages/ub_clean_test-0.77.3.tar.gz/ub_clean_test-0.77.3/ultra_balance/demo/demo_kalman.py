import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.core.estimators import KalmanFilter

# 生成带噪声的模拟数据
true_value = 10.0
measurements = true_value + np.random.randn(100) * 2.0

# 初始化卡尔曼滤波器
kf = KalmanFilter(dim_x=1, dim_z=1)
kf.F = np.array([[1.0]])        # 状态转移矩阵
kf.H = np.array([[1.0]])        # 观测矩阵
kf.Q = np.array([[0.01]])       # 过程噪声
kf.R = np.array([[1.0]])        # 观测噪声

# 滤波
filtered = []
for z in measurements:
    kf.predict()
    kf.update(np.array([z]))
    filtered.append(kf.x[0])

# 画图
plt.figure(figsize=(10, 6))
plt.plot(measurements, 'b.', alpha=0.5, label='Measurements (noisy)')
plt.plot(filtered, 'r-', linewidth=2, label='Kalman Filter')
plt.axhline(y=true_value, color='g', linestyle='--', label='True Value')
plt.xlabel('Step')
plt.ylabel('Value')
plt.title('Kalman Filter Demonstration')
plt.legend()
plt.grid(True)
plt.show()