from ultra_balance.reasoning.active_learning import ActiveLearning


def main():
    print("\n" + "📚" * 20)
    print("  ub-clean-test 0.62.0 主动学习模块演示")
    print("📚" * 20)
    
    al = ActiveLearning()
    
    # 1. 知识缺口检测
    print("\n" + "=" * 50)
    print(" 🔍 知识缺口检测")
    print("=" * 50)
    
    gaps = al.detect_gaps("出门")
    print(f"  任务: 出门")
    print(f"  知识缺口: {gaps}")
    
    gaps2 = al.detect_gaps("做饭")
    print(f"  任务: 做饭")
    print(f"  知识缺口: {gaps2}")
    
    # 2. 主动提问
    print("\n" + "=" * 50)
    print(" ❓ 主动提问")
    print("=" * 50)
    
    question = al.ask_question("天气")
    print(f"  关于天气: {question}")
    
    question2 = al.ask_question("带伞")
    print(f"  关于带伞: {question2}")
    
    # 3. 从答案学习
    print("\n" + "=" * 50)
    print(" 📖 从答案学习")
    print("=" * 50)
    
    result = al.learn_from_answer("请问今天下雨吗？", "是的，下雨了")
    print(f"  问: 请问今天下雨吗？")
    print(f"  答: 是的，下雨了")
    print(f"  学到: {result['knowledge']} (置信度 {result['confidence']:.0%})")
    
    result2 = al.learn_from_answer("需要带伞吗？", "需要")
    print(f"\n  问: 需要带伞吗？")
    print(f"  答: 需要")
    print(f"  学到: {result2['knowledge']} (置信度 {result2['confidence']:.0%})")
    
    # 4. 知识验证
    print("\n" + "=" * 50)
    print(" ✅ 知识验证")
    print("=" * 50)
    
    al.add_knowledge("今天下雨", "fact", "user", confidence=0.7)
    
    result = al.verify_knowledge("今天下雨", "看到有人打伞")
    print(f"  验证: 今天下雨")
    print(f"  证据: 看到有人打伞")
    print(f"  结果: {result['explanation']}")
    
    result2 = al.verify_knowledge("今天下雨", "天气晴朗")
    print(f"\n  验证: 今天下雨")
    print(f"  证据: 天气晴朗")
    print(f"  结果: {result2['explanation']}")
    
    # 5. 经验积累
    print("\n" + "=" * 50)
    print(" 📝 经验积累")
    print("=" * 50)
    
    al.record_experience("出门带伞", success=True, details={"weather": "rainy"})
    al.record_experience("出门不带伞", success=False, details={"weather": "rainy"})
    
    success_rate = al.get_success_rate("出门")
    print(f"  出门任务成功率: {success_rate:.0%}")
    
    # 6. 好奇心驱动探索
    print("\n" + "=" * 50)
    print(" 🤔 好奇心驱动探索")
    print("=" * 50)
    
    exploration = al.explore()
    print(f"  探索主题: {exploration['topic']}")
    print(f"  当前置信度: {exploration['current_confidence']:.0%}")
    if exploration['question']:
        print(f"  提问: {exploration['question']}")
    
    # 7. 统计报告
    print("\n" + "=" * 50)
    print(" 📊 学习统计")
    print("=" * 50)
    
    stats = al.get_statistics()
    print(f"  总知识量: {stats['total_knowledge']}")
    print(f"  用户教会: {stats['learned_from_user']}")
    print(f"  高置信度知识: {stats['high_confidence_count']}")
    print(f"  提问次数: {stats['questions_asked']}")
    print(f"  已回答: {stats['questions_answered']}")
    print(f"  经验总数: {stats['total_experiences']}")
    print(f"  成功率: {stats['success_rate']:.0%}")
    
    print("\n" + "✅" * 20)
    print("  所有主动学习演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()