import time
import json
import random
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from enum import Enum

# ========== 原有导入 ==========
try:
    from ultra_balance.safety.self_diagnosis import SelfDiagnosis as OriginalSelfDiagnosis
    HAS_ORIGINAL_DIAGNOSIS = True
except ImportError:
    HAS_ORIGINAL_DIAGNOSIS = False
    print("警告: safety.self_diagnosis 模块未找到，跳过原有演示")

# ========== v0.76.0 新增导入 ==========
try:
    from ultra_balance.monitoring.thermal_monitor import (
        ThermalMonitor, MultiJointThermalMonitor, ThermalConfig
    )
    from ultra_balance.monitoring.power_monitor import PowerMonitor, BatteryConfig
    from ultra_balance.monitoring.heartbeat import HeartbeatMonitor, HeartbeatConfig
    from ultra_balance.monitoring.stall_detector import StallDetector, StallConfig
    HAS_V076_MODULES = True
except ImportError as e:
    HAS_V076_MODULES = False
    print(f"警告: v0.76.0 模块未找到 ({e})，跳过新增演示")


class CheckStatus(Enum):
    """检查状态"""
    PASS = "PASS"
    WARNING = "WARNING"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"


@dataclass
class CheckResult:
    """检查结果"""
    name: str
    status: CheckStatus
    message: str
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class EnhancedSelfDiagnosis:
    """
    增强版自检系统（v0.76.0 新增）
    
    集成所有监控模块，提供统一的硬件状态检查和报告。
    """
    
    def __init__(self, robot_name: str = "xiangxi_robot"):
        self.robot_name = robot_name
        
        # 监控模块
        self.thermal_monitor: Optional[MultiJointThermalMonitor] = None
        self.power_monitor: Optional[PowerMonitor] = None
        self.heartbeat_monitors: Dict[str, HeartbeatMonitor] = {}
        self.stall_detectors: Dict[str, StallDetector] = {}
        
        # 检查结果历史
        self.check_history: List[CheckResult] = []
        
        # 配置
        self.config = {
            'joint_temperature_warning': 60.0,
            'joint_temperature_critical': 75.0,
            'battery_soc_warning': 0.30,
            'battery_soc_critical': 0.15,
            'heartbeat_max_delay': 0.05,
            'heartbeat_max_loss_rate': 0.10,
            'motor_current_warning': 15.0,
            'motor_current_critical': 25.0,
        }
    
    def attach_thermal_monitor(self, monitor: MultiJointThermalMonitor):
        self.thermal_monitor = monitor
    
    def attach_power_monitor(self, monitor: PowerMonitor):
        self.power_monitor = monitor
    
    def attach_heartbeat_monitor(self, name: str, monitor: HeartbeatMonitor):
        self.heartbeat_monitors[name] = monitor
    
    def attach_stall_detector(self, name: str, detector: StallDetector):
        self.stall_detectors[name] = detector
    
    def check_joint_temperatures(self) -> CheckResult:
        """检查关节温度"""
        if self.thermal_monitor is None:
            return CheckResult(
                name="关节温度",
                status=CheckStatus.UNKNOWN,
                message="热监控器未连接"
            )
        
        stats = self.thermal_monitor.get_all_statistics()
        
        max_temp = 0.0
        warnings = []
        criticals = []
        
        for joint, info in stats.items():
            temp = info['current_temperature']
            max_temp = max(max_temp, temp)
            
            if temp >= self.config['joint_temperature_critical']:
                criticals.append(joint)
            elif temp >= self.config['joint_temperature_warning']:
                warnings.append(joint)
        
        if criticals:
            status = CheckStatus.FAIL
            message = f"关节过热: {criticals}"
        elif warnings:
            status = CheckStatus.WARNING
            message = f"关节温度偏高: {warnings}"
        else:
            status = CheckStatus.PASS
            message = "所有关节温度正常"
        
        return CheckResult(
            name="关节温度",
            status=status,
            message=message,
            details={
                'max_temperature': max_temp,
                'warnings': warnings,
                'criticals': criticals,
            }
        )
    
    def check_power_system(self) -> CheckResult:
        """检查电源系统"""
        if self.power_monitor is None:
            return CheckResult(
                name="电源系统",
                status=CheckStatus.UNKNOWN,
                message="电量监控器未连接"
            )
        
        stats = self.power_monitor.get_statistics()
        soc = stats['soc']
        voltage = stats['voltage']
        
        if soc <= self.config['battery_soc_critical']:
            status = CheckStatus.FAIL
            message = f"电量严重不足: {soc*100:.1f}%"
        elif soc <= self.config['battery_soc_warning']:
            status = CheckStatus.WARNING
            message = f"电量偏低: {soc*100:.1f}%"
        else:
            status = CheckStatus.PASS
            message = f"电量充足: {soc*100:.1f}%"
        
        return CheckResult(
            name="电源系统",
            status=status,
            message=message,
            details={
                'soc': soc,
                'voltage': voltage,
                'current': stats['current'],
                'remaining_time': stats['remaining_time']
            }
        )
    
    def check_communication(self) -> CheckResult:
        """检查通信状态"""
        if not self.heartbeat_monitors:
            return CheckResult(
                name="通信状态",
                status=CheckStatus.UNKNOWN,
                message="无心跳监控器"
            )
        
        lost_channels = []
        warning_channels = []
        
        for name, monitor in self.heartbeat_monitors.items():
            stats = monitor.get_statistics()
            
            if stats['connection_lost']:
                lost_channels.append(name)
            elif (stats['avg_delay_ms'] > self.config['heartbeat_max_delay'] * 1000 or
                  stats['avg_loss_rate'] > self.config['heartbeat_max_loss_rate']):
                warning_channels.append(name)
        
        if lost_channels:
            status = CheckStatus.FAIL
            message = f"通信中断: {lost_channels}"
        elif warning_channels:
            status = CheckStatus.WARNING
            message = f"通信质量差: {warning_channels}"
        else:
            status = CheckStatus.PASS
            message = "所有通信通道正常"
        
        return CheckResult(
            name="通信状态",
            status=status,
            message=message,
            details={'lost': lost_channels, 'warning': warning_channels}
        )
    
    def check_motors(self) -> CheckResult:
        """检查电机状态"""
        if not self.stall_detectors:
            return CheckResult(
                name="电机状态",
                status=CheckStatus.UNKNOWN,
                message="无堵转检测器"
            )
        
        stalled = []
        emergency = []
        high_current = []
        
        for name, detector in self.stall_detectors.items():
            stats = detector.get_statistics()
            
            if stats['is_emergency']:
                emergency.append(name)
            elif stats['is_stalled']:
                stalled.append(name)
            elif stats['current'] >= self.config['motor_current_critical']:
                emergency.append(name)
            elif stats['current'] >= self.config['motor_current_warning']:
                high_current.append(name)
        
        if emergency:
            status = CheckStatus.FAIL
            message = f"电机紧急状态: {emergency}"
        elif stalled:
            status = CheckStatus.WARNING
            message = f"电机堵转: {stalled}"
        elif high_current:
            status = CheckStatus.WARNING
            message = f"电机电流偏高: {high_current}"
        else:
            status = CheckStatus.PASS
            message = "所有电机正常"
        
        return CheckResult(
            name="电机状态",
            status=status,
            message=message,
            details={'stalled': stalled, 'emergency': emergency, 'high_current': high_current}
        )
    
    def run_full_diagnosis(self) -> List[CheckResult]:
        """运行完整自检"""
        results = [
            self.check_joint_temperatures(),
            self.check_power_system(),
            self.check_communication(),
            self.check_motors(),
        ]
        
        self.check_history.extend(results)
        
        if len(self.check_history) > 100:
            self.check_history = self.check_history[-100:]
        
        return results
    
    def get_summary(self, results: List[CheckResult]) -> Dict[str, Any]:
        """获取自检摘要"""
        summary = {
            'robot_name': self.robot_name,
            'timestamp': time.time(),
            'overall_status': CheckStatus.PASS.value,
            'checks': [],
            'failures': [],
            'warnings': [],
            'can_work': True
        }
        
        overall_status = CheckStatus.PASS
        
        for result in results:
            summary['checks'].append({
                'name': result.name,
                'status': result.status.value,
                'message': result.message
            })
            
            if result.status == CheckStatus.FAIL:
                overall_status = CheckStatus.FAIL
                summary['failures'].append(result.name)
                summary['can_work'] = False
            elif result.status == CheckStatus.WARNING and overall_status == CheckStatus.PASS:
                overall_status = CheckStatus.WARNING
                summary['warnings'].append(result.name)
        
        summary['overall_status'] = overall_status.value
        
        return summary
    
    def generate_report(self, results: List[CheckResult]) -> str:
        """生成自检报告"""
        summary = self.get_summary(results)
        
        lines = []
        lines.append("=" * 60)
        lines.append(f"湘西紫机器人自检报告 (v0.76.0)")
        lines.append("=" * 60)
        lines.append(f"机器人: {self.robot_name}")
        lines.append(f"时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"总体状态: {summary['overall_status']}")
        lines.append(f"能否工作: {'是' if summary['can_work'] else '否'}")
        lines.append("-" * 60)
        
        for result in results:
            icon = "?" if result.status == CheckStatus.PASS else "??" if result.status == CheckStatus.WARNING else "?"
            lines.append(f"{icon} {result.name}: {result.message}")
        
        lines.append("-" * 60)
        
        if summary['failures']:
            lines.append(f"? 故障项: {summary['failures']}")
        if summary['warnings']:
            lines.append(f"?? 警告项: {summary['warnings']}")
        
        if not summary['failures'] and not summary['warnings']:
            lines.append("? 所有检查通过，系统正常！")
        
        lines.append("=" * 60)
        
        return "\n".join(lines)


# ========== 原有演示 ==========

def demo_original_self_diagnosis():
    """演示：原有自检系统"""
    print("\n" + "="*60)
    print("【原有功能】基础自检系统演示")
    print("="*60)
    
    if not HAS_ORIGINAL_DIAGNOSIS:
        print("?? safety.self_diagnosis 模块未安装，跳过此演示")
        return
    
    robot = OriginalSelfDiagnosis()
    
    # 第一次自检
    print("\n[第一次自检]")
    result = robot.run_diagnosis()
    print(f"状态: {result['status']}")
    print(f"电池: {result['details']['battery'][1]}")
    print(f"电机: {result['details']['motor'][1]}")
    print(f"传感器: {result['details']['sensors'][1]}")
    print(f"能否工作: {'是' if result['can_work'] else '否'}")
    
    # 模拟工作一段时间
    print("\n[模拟工作...]")
    for i in range(5):
        time.sleep(0.3)
        robot.simulate_degradation()
        print(f"第{i+1}次工作后: 电量={robot.battery_level}%，温度={robot.motor_temp}°C")
    
    # 第二次自检
    print("\n[第二次自检]")
    result = robot.run_diagnosis()
    print(f"状态: {result['status']}")
    print(f"电池: {result['details']['battery'][1]}")
    print(f"电机: {result['details']['motor'][1]}")
    print(f"传感器: {result['details']['sensors'][1]}")
    print(f"能否工作: {'是' if result['can_work'] else '否'}")


# ========== v0.76.0 新增演示 ==========

def demo_enhanced_basic():
    """演示：增强版基础自检"""
    print("\n" + "="*60)
    print("【新增功能】增强版自检 - 正常状态")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    diagnosis = EnhancedSelfDiagnosis(robot_name="xiangxi_test")
    
    # 创建并附加监控器（模拟正常状态）
    thermal = MultiJointThermalMonitor()
    for joint in ['joint1', 'joint2', 'joint3']:
        thermal.add_joint(joint, T_amb=25.0)
    
    power = PowerMonitor(capacity_mah=5000)
    power.update(24.5, 5.0)
    
    heartbeat = HeartbeatMonitor(expected_interval=0.02)
    for _ in range(10):
        seq = heartbeat.send_heartbeat()
        heartbeat.receive_heartbeat(seq)
    
    stall = StallDetector(joint_name='joint1')
    stall.update(1.0, 0.98, 5.0)
    
    diagnosis.attach_thermal_monitor(thermal)
    diagnosis.attach_power_monitor(power)
    diagnosis.attach_heartbeat_monitor('main', heartbeat)
    diagnosis.attach_stall_detector('joint1', stall)
    
    # 运行自检
    results = diagnosis.run_full_diagnosis()
    
    # 打印报告
    print(diagnosis.generate_report(results))


def demo_enhanced_warning():
    """演示：增强版自检 - 警告状态"""
    print("\n" + "="*60)
    print("【新增功能】增强版自检 - 警告状态")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    diagnosis = EnhancedSelfDiagnosis(robot_name="xiangxi_test")
    
    # 模拟警告状态
    thermal = MultiJointThermalMonitor()
    thermal.add_joint('joint1', T_amb=25.0)
    thermal['joint1'].temperature = 65.0  # 高温警告
    
    power = PowerMonitor(capacity_mah=5000)
    power.update(22.0, 8.0)
    power.soc = 0.25  # 低电量警告
    
    heartbeat = HeartbeatMonitor(expected_interval=0.02)
    for _ in range(5):
        seq = heartbeat.send_heartbeat()
        if random.random() > 0.3:
            heartbeat.receive_heartbeat(seq)
    
    stall = StallDetector(joint_name='joint1')
    stall.update(1.0, 0.5, 12.0)  # 电流偏高
    
    diagnosis.attach_thermal_monitor(thermal)
    diagnosis.attach_power_monitor(power)
    diagnosis.attach_heartbeat_monitor('main', heartbeat)
    diagnosis.attach_stall_detector('joint1', stall)
    
    results = diagnosis.run_full_diagnosis()
    print(diagnosis.generate_report(results))


def demo_enhanced_failure():
    """演示：增强版自检 - 故障状态"""
    print("\n" + "="*60)
    print("【新增功能】增强版自检 - 故障状态")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    diagnosis = EnhancedSelfDiagnosis(robot_name="xiangxi_test")
    
    # 模拟故障状态
    thermal = MultiJointThermalMonitor()
    thermal.add_joint('joint1', T_max=75.0)
    thermal['joint1'].temperature = 80.0  # 过热
    
    power = PowerMonitor(capacity_mah=5000)
    power.update(20.5, 10.0)
    power.soc = 0.08  # 紧急电量
    
    heartbeat = HeartbeatMonitor(expected_interval=0.02)
    heartbeat.connection_lost = True  # 断线
    
    stall = StallDetector(joint_name='joint1')
    stall.update(1.5, 0.01, 20.0, dt=0.5)
    stall.is_emergency = True  # 堵转紧急
    
    diagnosis.attach_thermal_monitor(thermal)
    diagnosis.attach_power_monitor(power)
    diagnosis.attach_heartbeat_monitor('main', heartbeat)
    diagnosis.attach_stall_detector('joint1', stall)
    
    results = diagnosis.run_full_diagnosis()
    print(diagnosis.generate_report(results))


def demo_enhanced_continuous():
    """演示：增强版自检 - 连续监控"""
    print("\n" + "="*60)
    print("【新增功能】增强版自检 - 连续监控")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    diagnosis = EnhancedSelfDiagnosis(robot_name="xiangxi_monitor")
    
    thermal = MultiJointThermalMonitor()
    thermal.add_joint('joint1')
    
    power = PowerMonitor(capacity_mah=5000)
    
    heartbeat = HeartbeatMonitor()
    
    stall = StallDetector(joint_name='joint1')
    
    diagnosis.attach_thermal_monitor(thermal)
    diagnosis.attach_power_monitor(power)
    diagnosis.attach_heartbeat_monitor('main', heartbeat)
    diagnosis.attach_stall_detector('joint1', stall)
    
    voltage = 25.0
    
    for cycle in range(5):
        print(f"\n--- 自检周期 {cycle + 1} ---")
        
        # 模拟状态变化
        temp = 25.0 + cycle * 8
        thermal['joint1'].temperature = temp
        
        voltage = max(20.0, voltage - 0.8)
        power.update(voltage, 6.0)
        
        seq = heartbeat.send_heartbeat()
        if cycle != 3:
            heartbeat.receive_heartbeat(seq)
        
        if cycle < 3:
            stall.update(1.0, 0.95, 5.0)
        else:
            stall.update(1.0, 0.02, 18.0)
        
        results = diagnosis.run_full_diagnosis()
        summary = diagnosis.get_summary(results)
        
        print(f"  总体状态: {summary['overall_status']}, 能否工作: {'是' if summary['can_work'] else '否'}")
        for r in results:
            icon = "?" if r.status == CheckStatus.PASS else "??" if r.status == CheckStatus.WARNING else "?"
            print(f"  {icon} {r.name}: {r.status.value}")
    
    print(f"\n历史检查记录: {len(diagnosis.check_history)} 条")


# ========== 主函数 ==========

def run_all_demos():
    """运行所有演示"""
    print("\n" + "="*70)
    print("湘西紫框架 v0.76.0 - 自检系统演示")
    print("="*70)
    
    # 原有演示
    demo_original_self_diagnosis()
    print("\n" + "-"*40)
    time.sleep(0.5)
    
    # 新增演示
    demos = [
        ("正常状态自检", demo_enhanced_basic),
        ("警告状态自检", demo_enhanced_warning),
        ("故障状态自检", demo_enhanced_failure),
        ("连续监控自检", demo_enhanced_continuous),
    ]
    
    for name, demo_func in demos:
        try:
            demo_func()
        except Exception as e:
            print(f"\n? 演示 '{name}' 出错: {e}")
            import traceback
            traceback.print_exc()
        
        print("\n" + "-"*40)
        time.sleep(0.5)
    
    print("\n" + "="*70)
    print("所有演示完成！")
    print("="*70)


if __name__ == "__main__":
    run_all_demos()
