from ultra_balance.learning.experience import ExperienceMemory

# 创建记忆模块
memory = ExperienceMemory('demo_memory.json')

# 模拟第一次执行任务
print("=" * 40)
print("第一次执行任务")
print("=" * 40)

command = "拿红色方块"
print(f"执行: {command}")
# 模拟执行（需要 Vision + WBC）
result1 = {'success': True, 'path': [20, 50], 'time': 3.5}
memory.remember(command, result1)
print(f"  结果: 成功, 用时 {result1['time']}秒")

# 模拟第二次执行（应该回忆）
print("\n" + "=" * 40)
print("第二次执行相同任务")
print("=" * 40)

recalled = memory.recall(command)
if recalled:
    print(f"回忆成功! 上次经验: 位置 {recalled['path']}, 用时 {recalled['time']}秒")
    print(f"直接执行, 省去了重新计算的时间")
else:
    print("没有记忆, 需要重新学习")

# 查看所有记忆
print("\n" + "=" * 40)
print("记忆库内容")
print("=" * 40)
print(f"成功经验: {memory.memory['success']}")