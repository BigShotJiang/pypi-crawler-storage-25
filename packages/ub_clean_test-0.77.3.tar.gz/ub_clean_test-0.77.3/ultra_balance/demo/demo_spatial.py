from ultra_balance.reasoning.spatial import SpatialReasoner

# 创建空间推理器
reasoner = SpatialReasoner()

print("=" * 50)
print("空间推理演示")
print("=" * 50)

# 理解方位
print("\n[理解方位]")
print(f"左边是: {reasoner.understand_direction('左')}")
print(f"右边是: {reasoner.understand_direction('右')}")
print(f"前面是: {reasoner.understand_direction('前')}")

# 相对位置
print("\n[相对位置]")
print(reasoner.get_relative_position('杯子', '桌子'))
print(reasoner.get_relative_position('冰箱', '椅子'))
print(reasoner.get_relative_position('门', '冰箱'))

# 空间问题
print("\n[空间问题]")
print(reasoner.answer_question("杯子在哪"))
print(reasoner.answer_question("冰箱在哪"))
print(reasoner.answer_question("杯子在桌子上面吗"))