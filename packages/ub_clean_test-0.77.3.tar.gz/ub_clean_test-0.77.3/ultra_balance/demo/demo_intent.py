from ultra_balance.perception.intent import IntentRecognizer

# 创建意图识别器
recognizer = IntentRecognizer()

print("=" * 50)
print("意图识别演示")
print("=" * 50)

# 测试各种指令
commands = [
    "去厨房",
    "拿红色方块",
    "看看那边",
    "跟着我",
    "停下来",
    "等一下",
    "告诉我时间",
    "帮我拿水",
    "随便说点什么",
]

print("\n[指令意图识别]")
for cmd in commands:
    result = recognizer.recognize(cmd)
    print(f"  指令: {cmd}")
    print(f"    意图: {result['intent']}, 目标: {result['target']}, 置信度: {result['confidence']}")
    print()

# 从动作猜意图
print("[动作意图猜测]")
actions = ['walk_toward', 'stop', 'look_around', 'reach_out', 'dance']
for action in actions:
    guess = recognizer.guess_intent_from_action(action)
    print(f"  动作: {action} → {guess}")