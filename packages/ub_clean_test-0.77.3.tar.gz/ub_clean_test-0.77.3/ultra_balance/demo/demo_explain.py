from ultra_balance.explain.explainer import Explainer

# 创建解释器
explainer = Explainer()

print("=" * 50)
print("可解释性演示")
print("=" * 50)

# 模拟决策过程
print("\n[模拟决策]")

# 拿杯子决策
reasons = ["看到桌上有个蓝色杯子", "主人说过喜欢蓝色", "杯子离我最近"]
explainer.record_decision("拿杯子", "拿蓝色杯子", reasons)
print("  拿杯子: 选择蓝色杯子")

# 走路决策
reasons = ["左边有椅子挡住", "右边是空路", "目标在右边"]
explainer.record_decision("走路", "往右走", reasons)
print("  走路: 选择往右走")

# 回应决策
reasons = ["用户说'太好了'", "检测到开心情绪", "需要热情回应"]
explainer.record_decision("回应", "开心回应", reasons)
print("  回应: 选择开心回应")

# 解释决策
print("\n[解释决策]")
print(f"  拿杯子: {explainer.explain('拿杯子')}")
print(f"  走路: {explainer.explain('走路')}")
print(f"  回应: {explainer.explain('回应')}")

print(f"\n[最近一次决策]")
print(f"  {explainer.explain_last()}")

# 推理路径
print(f"\n[推理路径]")
path = explainer.get_reasoning_path('拿杯子')
if path:
    print(f"  任务: {path['task']}")
    print(f"  选择: {path['choice']}")
    print(f"  原因: {', '.join(path['reasons'])}")
    print(f"  推理步数: {path['steps']}")