from ultra_balance.perception.touch import TouchPerception

# 创建触觉感知器
tp = TouchPerception()

print("=" * 50)
print("触觉感知演示")
print("=" * 50)

tests = [
    "极软",
    "很软",
    "软",
    "适中",
    "硬",
    "很硬",
    "极硬",
    "光滑",
    "粗糙",
    "黏",
    "湿",
    "热",
    "再轻一点",
    "再重一点",
    "再用力一点",
]

print("\n[触觉理解]")
for t in tests:
    result = tp.understand(t)
    print(f"  {t} → {result}")

print("\n[触觉状态]")
pressures = [1, 2, 3, 5, 8, 10, 12]
for p in pressures:
    tp.set_current_pressure(p)
    print(f"  {p}牛 → {tp.get_touch_status()}")
    print(f"         {tp.suggest_adjustment()}")