from ultra_balance.reasoning.time_perception import TimePerception

# 创建时间感知器
tp = TimePerception()

print("=" * 50)
print("时间感知演示")
print("=" * 50)

print(f"\n当前时间: {tp.get_current_time()}")

tests = [
    "马上",
    "一会儿",
    "5分钟后",
    "10秒后",
    "下午3点",
    "晚上8点",
    "好久",
]

print("\n[时间理解]")
for t in tests:
    result = tp.understand(t)
    print(f"  {t} → {result}")

print("\n[时间规划]")
print(f"  等5分钟: {tp.schedule('5分钟后', None)}")
print(f"  等一会儿: {tp.schedule('一会儿', None)}")