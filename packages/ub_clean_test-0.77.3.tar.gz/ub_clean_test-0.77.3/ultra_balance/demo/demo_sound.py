from ultra_balance.perception.sound import SoundPerception

# 创建声音感知器
sp = SoundPerception()

print("=" * 50)
print("声音感知演示")
print("=" * 50)

tests = [
    "极静",
    "很安静",
    "安静",
    "正常",
    "有点吵",
    "吵",
    "很吵",
    "极吵",
    "50分贝",
    "80分贝",
    "再大声一点",
    "再小声一点",
    "调大",
    "调小",
]

print("\n[声音理解]")
for t in tests:
    result = sp.understand(t)
    print(f"  {t} → {result}")

print("\n[声音状态]")
volumes = [10, 20, 30, 50, 65, 70, 80, 90]
for v in volumes:
    sp.set_current_volume(v)
    print(f"  {v}分贝 → {sp.get_sound_status()}")
    print(f"         {sp.suggest_action()}")