from ultra_balance.reasoning.universal import UniversalReasoning, UnifiedRequest, TaskType


def main():
    print("\n" + "🌐" * 20)
    print("  ub-clean-test 0.71.0 通用推理模块演示")
    print("🌐" * 20)
    
    ur = UniversalReasoning()
    
    # 1. 能力查询
    print("\n" + "=" * 50)
    print(" 🔧 能力查询")
    print("=" * 50)
    
    modules = ur._modules
    loaded = sum(1 for m in modules.values() if m is not None)
    print(f"  已加载模块: {loaded}/{len(modules)}")
    
    # 2. 推理任务
    print("\n" + "=" * 50)
    print(" 🧠 推理任务")
    print("=" * 50)
    
    request1 = UnifiedRequest(
        task_type=TaskType.REASONING,
        input={"major": "所有人都会死", "minor": "苏格拉底是人", "conclusion": "苏格拉底会死"}
    )
    response1 = ur.reason(request1)
    print(f"  三段论推理:")
    print(f"    成功: {response1.success}")
    # 确保 confidence 是数字
    conf1 = response1.confidence if isinstance(response1.confidence, (int, float)) else 0.7
    print(f"    置信度: {conf1:.0%}")
    print(f"    结果: {response1.result.get('explanation', 'N/A')}")
    
    # 3. 决策任务
    print("\n" + "=" * 50)
    print(" 📊 决策任务")
    print("=" * 50)
    
    request2 = UnifiedRequest(
        task_type=TaskType.DECISION,
        input={
            "options": [
                {"name": "坐公交", "pros": ["便宜", "环保"], "cons": ["慢"]},
                {"name": "打车", "pros": ["快", "舒适"], "cons": ["贵"]},
            ]
        }
    )
    response2 = ur.reason(request2)
    print(f"  多方案比较:")
    print(f"    成功: {response2.success}")
    print(f"    结果: {response2.result.get('analysis', 'N/A')}")
    
    # 4. 对话任务
    print("\n" + "=" * 50)
    print(" 💬 对话任务")
    print("=" * 50)
    
    response3 = ur.reason_text("你好", "dialogue")
    print(f"  输入: 你好")
    print(f"    成功: {response3.success}")
    print(f"    响应: {response3.result.get('response', 'N/A')}")
    
    # 5. 规划任务
    print("\n" + "=" * 50)
    print(" 🎯 规划任务")
    print("=" * 50)
    
    response4 = ur.reason_text("导航到会议室", "planning")
    print(f"  任务: 导航到会议室")
    print(f"    成功: {response4.success}")
    print(f"    结果: {response4.result}")
    
    # 6. 统计
    print("\n" + "=" * 50)
    print(" 📊 统计报告")
    print("=" * 50)
    
    stats = ur.get_statistics()
    print(f"  版本: {stats['version']}")
    print(f"  总请求数: {stats['total_requests']}")
    print(f"  成功率: {stats['success_rate']:.0%}")
    
    print("\n" + "✅" * 20)
    print("  所有通用推理演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()