import numpy as np
from ultra_balance.optimization.auto_tune import AutoTuner

# 定义参数范围
param_ranges = {
    'kp': [50, 300],
    'kd': [10, 60],
}

# 创建自动调参器
tuner = AutoTuner(param_ranges)

# 模拟一个系统：误差 = kp*0.1 + kd*0.01 + 噪声
def simulate_error(kp, kd):
    """模拟系统性能：参数越好，误差越小"""
    # 最优参数大约在 kp=150, kd=25
    error = abs(kp - 150) * 0.1 + abs(kd - 25) * 0.5 + np.random.randn() * 5
    return max(0, error)

print("=" * 50)
print("自动调参演示：机器人自己找最优参数")
print("=" * 50)

# 自动调参循环
n_trials = 10
best_score = float('inf')

for i in range(n_trials):
    # 1. 建议参数
    params = tuner.suggest_params()
    print(f"\n第 {i+1} 次尝试: kp={params['kp']:.1f}, kd={params['kd']:.1f}")
    
    # 2. 测试性能（模拟）
    error = simulate_error(params['kp'], params['kd'])
    print(f"  误差: {error:.2f}")
    
    # 3. 更新最优
    if tuner.update_best(params, error):
        print(f"  ★ 新纪录！")
        best_score = error

print("\n" + "=" * 50)
print("调参完成！")
print(f"最优参数: kp={tuner.get_best()['kp']:.1f}, kd={tuner.get_best()['kd']:.1f}")
print(f"最优误差: {best_score:.2f}")