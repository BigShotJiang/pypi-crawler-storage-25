import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.planning.zmp import ZMPCalculator

# 创建 ZMP 计算器
zmp_calc = ZMPCalculator()

# 模拟一个双足站立状态
foot_positions = [
    (-0.1, 0.1),   # 左脚
    (0.1, 0.1),    # 右脚
]

# 模拟质心运动
time = np.linspace(0, 2, 100)
com_x = 0.05 * np.sin(2 * np.pi * 0.5 * time)  # 质心左右摆动
com_y = np.zeros_like(time)
com_acc_x = -0.05 * (2 * np.pi * 0.5)**2 * np.sin(2 * np.pi * 0.5 * time)

zmp_x = []
zmp_y = []
stable = []

for i in range(len(time)):
    zmp = zmp_calc.compute_zmp_from_com(
        com_pos=(com_x[i], com_y[i]),
        com_acc=(com_acc_x[i], 0)
    )
    zmp_x.append(zmp[0])
    zmp_y.append(zmp[1])
    stable.append(zmp_calc.is_stable(zmp, foot_positions))

# 画图
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))

# 质心和 ZMP 位置
ax1.plot(time, com_x, 'b-', label='COM x')
ax1.plot(time, zmp_x, 'r--', label='ZMP x')
ax1.set_xlabel('Time (s)')
ax1.set_ylabel('X Position (m)')
ax1.set_title('COM vs ZMP')
ax1.legend()
ax1.grid(True)

# 稳定性判断
ax2.plot(time, stable, 'g-', linewidth=2)
ax2.set_xlabel('Time (s)')
ax2.set_ylabel('Stable')
ax2.set_title('Stability (1=stable, 0=unstable)')
ax2.set_ylim(-0.1, 1.1)
ax2.grid(True)

plt.tight_layout()
plt.show()