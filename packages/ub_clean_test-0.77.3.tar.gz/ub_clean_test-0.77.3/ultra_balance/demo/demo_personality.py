from ultra_balance.personality.tuner import PersonalityTuner

# 创建人格调节器
personality = PersonalityTuner()

print("=" * 50)
print("人格调节演示")
print("=" * 50)

# 默认性格
print(f"\n[默认性格] {personality.get_personality()['name']}")
print(f"  回应: {personality.express('好的，马上')}")

# 切换活泼型
print("\n[切换为活泼型]")
print(personality.preset('活泼'))
print(f"  回应: {personality.express('好的，马上')}")
print(f"  回应: {personality.express('知道了')}")

# 切换严肃型
print("\n[切换为严肃型]")
print(personality.preset('严肃'))
print(f"  回应: {personality.express('好的，马上')}")

# 切换温和型
print("\n[切换为温和型]")
print(personality.preset('温和'))
print(f"  回应: {personality.express('好的，马上')}")

# 手动调节
print("\n[手动调节]")
print(personality.set_trait('幽默', 0.2))
print(personality.set_trait('外向', 0.3))
print(f"  当前性格: {personality.get_personality()['name']}")
print(f"  回应: {personality.express('好的，马上')}")