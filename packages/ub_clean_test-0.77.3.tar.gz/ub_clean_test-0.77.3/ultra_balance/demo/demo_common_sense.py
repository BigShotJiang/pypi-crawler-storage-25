from ultra_balance.reasoning.common_sense import CommonSense

def main():
    print("\n" + "🧠" * 20)
    print(" ub-clean-test 0.59.0 常识推理模块演示")
    print("🧠" * 20)
    
    cs = CommonSense()
    
    print("\n" + "=" * 50)
    print(" ☀️ 日常常识")
    print("=" * 50)
    for test in ["起床后", "睡觉前", "下雨天", "饿了"]:
        result = cs.daily(test)
        print(f" {result['explanation']}")
    
    print("\n" + "=" * 50)
    print(" 👋 社交常识")
    print("=" * 50)
    for test in ["见到长辈", "别人帮忙", "做错事", "告别"]:
        result = cs.social(test)
        print(f" {result['explanation']}")
    
    print("\n" + "=" * 50)
    print(" ⚡ 物理常识")
    print("=" * 50)
    for test in ["水往", "火会", "太阳从", "先看到闪电"]:
        result = cs.physics(test)
        print(f" {result['explanation']}")
    
    print("\n" + "=" * 50)
    print(" 🤔 综合推理")
    print("=" * 50)
    for test in ["外面下雨了要出门", "生病了不舒服", "去别人家做客"]:
        result = cs.reason(test)
        print(f" {result['explanation']}")
    
    print("\n" + "✅" * 20)
    print(" 所有常识推理演示跑通！")
    print("✅" * 20)

if __name__ == "__main__":
    main()