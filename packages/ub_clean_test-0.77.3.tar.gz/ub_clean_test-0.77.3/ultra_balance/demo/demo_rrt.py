import numpy as np
import matplotlib.pyplot as plt
import random

class SimpleRRT:
    def __init__(self, start, goal, obstacles, bounds, max_iter=500, step=0.5):
        self.start = start
        self.goal = goal
        self.obstacles = obstacles
        self.bounds = bounds
        self.max_iter = max_iter
        self.step = step
        self.nodes = [start]
    
    def plan(self):
        for _ in range(self.max_iter):
            # 随机采样
            if random.random() < 0.1:
                rand = self.goal
            else:
                rand = [random.uniform(self.bounds[0], self.bounds[1]),
                        random.uniform(self.bounds[2], self.bounds[3])]
            
            # 找最近节点
            nearest = min(self.nodes, key=lambda n: np.hypot(n[0]-rand[0], n[1]-rand[1]))
            
            # 向随机点扩展
            dx = rand[0] - nearest[0]
            dy = rand[1] - nearest[1]
            dist = np.hypot(dx, dy)
            if dist > self.step:
                dx = dx / dist * self.step
                dy = dy / dist * self.step
            new = [nearest[0] + dx, nearest[1] + dy]
            
            # 碰撞检测（简化）
            collide = False
            for ox, oy, r in self.obstacles:
                if np.hypot(new[0]-ox, new[1]-oy) < r:
                    collide = True
                    break
            if collide:
                continue
            
            self.nodes.append(new)
            
            # 到达目标
            if np.hypot(new[0]-self.goal[0], new[1]-self.goal[1]) < self.step:
                # 回溯路径
                path = [self.goal, new]
                while path[-1] != self.start:
                    # 简化：找最近父节点
                    parent = min(self.nodes, key=lambda n: np.hypot(n[0]-path[-1][0], n[1]-path[-1][1]))
                    path.append(parent)
                path.reverse()
                return path, self.nodes
        return None, self.nodes

# 参数
start = [1, 1]
goal = [9, 6]
obstacles = [[2,2,0.5], [3,4,0.6], [5,3,0.8], [7,5,0.5], [8,2,0.7]]
bounds = [0, 10, 0, 10]

rrt = SimpleRRT(start, goal, obstacles, bounds)
path, nodes = rrt.plan()

fig, ax = plt.subplots(figsize=(8,8))
for ox, oy, r in obstacles:
    ax.add_patch(plt.Circle((ox, oy), r, color='gray', alpha=0.7))

for node in nodes:
    if node != start:
        parent = min(nodes, key=lambda n: np.hypot(n[0]-node[0], n[1]-node[1]) if n != node else 999)
        ax.plot([node[0], parent[0]], [node[1], parent[1]], 'b-', alpha=0.3)

if path:
    path = np.array(path)
    ax.plot(path[:,0], path[:,1], 'r-', linewidth=2, label='Path')

ax.plot(start[0], start[1], 'go', markersize=10, label='Start')
ax.plot(goal[0], goal[1], 'ro', markersize=10, label='Goal')
ax.set_xlim(0,10); ax.set_ylim(0,10); ax.set_aspect('equal')
ax.grid(True); ax.legend()
plt.show()