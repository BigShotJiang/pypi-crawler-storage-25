from ultra_balance.reasoning.layout import LayoutReasoner

# 创建布局推理器
layout = LayoutReasoner()

print("=" * 50)
print("空间布局推理演示")
print("=" * 50)

questions = [
    "沙发在哪里",
    "冰箱在哪里",
    "电脑在哪里",
    "厨房在客厅的哪边",
    "怎么从客厅去厨房",
    "怎么从卧室去书房",
    "怎么从客厅去书房",
]

print("\n[空间布局问答]")
for q in questions:
    print(f"\n用户问: {q}")
    print(f"机器人答: {layout.answer(q)}")