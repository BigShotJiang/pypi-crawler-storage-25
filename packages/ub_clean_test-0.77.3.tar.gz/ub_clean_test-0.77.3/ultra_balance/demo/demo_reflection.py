import time
from ultra_balance.learning.reflection import SelfReflection

# 创建反思模块
reflector = SelfReflection()

print("=" * 50)
print("自我反思演示")
print("=" * 50)

# 记录一些事件
print("\n[记录事件]")
print(reflector.record_event("抓取", {"object": "红色方块", "reason": "力度太大"}, success=False))
time.sleep(0.1)
print(reflector.record_event("走路", {"to": "厨房", "reason": "地面有水"}, success=False))
time.sleep(0.1)
print(reflector.record_event("抓取", {"object": "蓝色杯子", "reason": "力度刚好"}, success=True))
time.sleep(0.1)
print(reflector.record_event("说话", {"to": "主人", "content": "你好"}, success=True))

# 反思
print("\n[反思]")
lessons = reflector.reflect()
for l in lessons:
    print(f"  💡 {l}")

# 查看所有教训
print("\n[已学到的教训]")
for l in reflector.get_lessons():
    print(f"  📝 {l}")

# 改进建议
print("\n[改进建议]")
print(f"下次抓取: {reflector.improve_next_time('抓取')}")
print(f"下次走路: {reflector.improve_next_time('走路')}")