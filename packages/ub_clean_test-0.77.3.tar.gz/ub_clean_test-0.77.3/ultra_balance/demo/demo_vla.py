from ultra_balance.perception.vla import SimpleVLA

# 创建VLA模型
vla = SimpleVLA()

# 测试指令列表
commands = [
    "请往前走",
    "快点跑",
    "停下来",
    "向左转",
    "向右转",
    "挥挥手",
    "蹲下来",
    "站起来",
]

print("=" * 40)
print("VLA 演示：机器人听懂人话")
print("=" * 40)

for cmd in commands:
    print(f"\n用户说: {cmd}")
    action = vla.understand(cmd)
    instruction = vla.act(action)
    print(f"  理解成: {action}")
    print(f"  执行: {instruction}")