from ultra_balance.reasoning.knowledge_update import KnowledgeUpdate, KnowledgeType


def main():
    print("\n" + "📚" * 20)
    print("  ub-clean-test 0.64.0 知识更新模块演示")
    print("📚" * 20)
    
    ku = KnowledgeUpdate()
    
    # 1. 用户教学
    print("\n" + "=" * 50)
    print(" 🧑‍🏫 用户教学")
    print("=" * 50)
    
    result1 = ku.teach("记住：我家门牌号是101")
    print(f"  {result1['message']}")
    
    result2 = ku.teach("重要：用户不喜欢等待")
    print(f"  {result2['message']}")
    
    result3 = ku.teach("客厅在右边")
    print(f"  {result3['message']}")
    
    # 2. 添加知识
    print("\n" + "=" * 50)
    print(" 📝 添加知识")
    print("=" * 50)
    
    kid1 = ku.add_knowledge(
        content="咖啡厅在二楼",
        knowledge_type=KnowledgeType.FACT,
        source="user",
        confidence=0.85,
        tags=["位置", "导航"]
    )
    print(f"  添加知识ID: {kid1}")
    print(f"  内容: 咖啡厅在二楼")
    
    # 3. 查询知识
    print("\n" + "=" * 50)
    print(" 🔍 查询知识")
    print("=" * 50)
    
    results = ku.query_knowledge("门牌")
    print(f"  查询'门牌':")
    for r in results:
        print(f"    - {r['content']} (置信度 {r['confidence']:.0%})")
    
    results2 = ku.query_knowledge("位置")
    print(f"\n  查询'位置':")
    for r in results2:
        print(f"    - {r['content']} (来源: {r['source']})")
    
    # 4. 获取知识详情
    print("\n" + "=" * 50)
    print(" 📄 知识详情")
    print("=" * 50)
    
    if results:
        detail = ku.get_knowledge(results[0]['id'])
        if detail:
            print(f"  ID: {detail['id']}")
            print(f"  内容: {detail['content']}")
            print(f"  类型: {detail['type']}")
            print(f"  来源: {detail['source']}")
            print(f"  版本: {detail['version']}")
    
    # 5. 更新知识
    print("\n" + "=" * 50)
    print(" ✏️ 更新知识")
    print("=" * 50)
    
    # 找到门牌号知识并更新
    door_knowledge = ku.query_knowledge("门牌")
    if door_knowledge:
        success = ku.update_knowledge(
            knowledge_id=door_knowledge[0]['id'],
            new_content="我家门牌号是102",
            reason="搬家了"
        )
        print(f"  更新门牌号: {'成功' if success else '失败'}")
        
        # 验证更新
        updated = ku.get_knowledge(door_knowledge[0]['id'])
        if updated:
            print(f"  新内容: {updated['content']}")
            print(f"  版本: {updated['version']}")
    
    # 6. 知识冲突检测
    print("\n" + "=" * 50)
    print(" ⚠️ 冲突检测")
    print("=" * 50)
    
    conflicts = ku.detect_conflicts("客厅在左边", KnowledgeType.FACT)
    print(f"  新知识: 客厅在左边")
    print(f"  冲突数: {len(conflicts)}")
    
    if conflicts:
        for c in conflicts:
            print(f"    与已有知识冲突: {c['existing_content']}")
    
    # 7. 解决冲突
    print("\n" + "=" * 50)
    print(" 🔧 解决冲突")
    print("=" * 50)
    
    resolution = ku.resolve_conflict(conflicts, strategy="user_priority")
    print(f"  冲突数: {resolution['conflicts_count']}")
    print(f"  建议: {resolution['recommendation']}")
    
    # 8. 版本历史
    print("\n" + "=" * 50)
    print(" 📜 版本历史")
    print("=" * 50)
    
    if door_knowledge:
        history = ku.get_version_history(door_knowledge[0]['id'])
        print(f"  门牌号知识更新历史:")
        for h in history:
            print(f"    - {h['action']}: {h['old_content']} → {h['new_content']}")
            print(f"      原因: {h['reason']}")
    
    # 9. 统计报告
    print("\n" + "=" * 50)
    print(" 📊 知识统计")
    print("=" * 50)
    
    stats = ku.get_statistics()
    print(f"  总知识量: {stats['total_knowledge']}")
    print(f"  用户教的知识: {stats['user_taught_count']}")
    print(f"  高置信度知识: {stats['high_confidence_count']}")
    print(f"  总更新次数: {stats['total_updates']}")
    print(f"  平均置信度: {stats['avg_confidence']:.0%}")
    
    # 按类型统计
    print(f"\n  按类型分布:")
    for ktype, count in stats['by_type'].items():
        print(f"    - {ktype}: {count}")
    
    print("\n" + "✅" * 20)
    print("  所有知识更新演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()