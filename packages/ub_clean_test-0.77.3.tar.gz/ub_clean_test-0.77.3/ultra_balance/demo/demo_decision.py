from ultra_balance.reasoning.decision import DecisionReasoning

def main():
    print("\n" + "🎯" * 20)
    print(" ub-clean-test 0.60.0 决策推理模块演示")
    print("🎯" * 20)
    
    dr = DecisionReasoning()
    
    print("\n" + "=" * 50)
    print(" 📊 多方案比较")
    print("=" * 50)
    
    options = [
        {"name": "坐公交", "pros": ["便宜", "环保"], "cons": ["慢", "拥挤"]},
        {"name": "打车", "pros": ["快", "舒适"], "cons": ["贵"]},
        {"name": "骑自行车", "pros": ["健康", "环保", "便宜"], "cons": ["累", "慢"]},
    ]
    
    result = dr.compare_options(options)
    print(f" {result['analysis']}")
    print(f" 排名: {' > '.join(result['ranking'])}")
    
    print("\n" + "=" * 50)
    print(" ⚖️ 权衡利弊")
    print("=" * 50)
    
    pros = ["便宜", "快速", "方便"]
    cons = ["质量差", "噪音大"]
    result = dr.weigh_pros_cons(pros, cons)
    print(f" {result['analysis']}")
    
    weights = {"便宜": 0.8, "快速": 0.9, "方便": 0.7, "质量差": 0.5, "噪音大": 0.3}
    result = dr.weigh_pros_cons(pros, cons, weights)
    print(f" 加权后: {result['analysis']}")
    
    print("\n" + "=" * 50)
    print(" 🏆 多条件择优")
    print("=" * 50)
    
    candidates = [
        {"name": "机器人A", "价格": 5000, "速度": 10, "质量": 8},
        {"name": "机器人B", "价格": 8000, "速度": 15, "质量": 9},
        {"name": "机器人C", "价格": 3000, "速度": 5, "质量": 6},
    ]
    
    criteria = ["价格", "速度", "质量"]
    weights = {"价格": 0.5, "速度": 0.3, "质量": 0.2}
    
    result = dr.choose_best(candidates, criteria, weights)
    print(f" {result['analysis']}")
    
    print("\n" + "=" * 50)
    print(" ⚠️ 风险评估")
    print("=" * 50)
    
    risk_options = [
        {"name": "保守投资", "risk": "低", "reward": "低"},
        {"name": "稳健投资", "risk": "中", "reward": "中"},
        {"name": "激进投资", "risk": "高", "reward": "高"},
    ]
    
    result = dr.risk_assessment(risk_options)
    print(f" {result['analysis']}")
    for opt in result['ranking']:
        print(f"   {opt['name']}: 风险{opt['risk']}, 回报{opt['reward']}")
    
    print("\n" + "✅" * 20)
    print(" 所有决策推理演示跑通！")
    print("✅" * 20)

if __name__ == "__main__":
    main()