import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.control.wbc import WholeBodyControl

# 创建WBC控制器
wbc = WholeBodyControl(num_joints=12)

# 模拟时间
time = np.linspace(0, 5, 100)

# 模拟关节状态
q = np.zeros((len(time), 12))
q_dot = np.zeros((len(time), 12))

# 任务序列
walk_targets = [0.5 * np.sin(t) for t in time]      # 走路目标：左右摆动
arm_targets = [0.3 * np.cos(t) for t in time]       # 手臂目标：前后摆动

torques = []
for i, t in enumerate(time):
    tasks = {
        'walk': np.array([walk_targets[i], 0]),
        'arm': np.array([arm_targets[i], 0, 0])
    }
    tau = wbc.compute_torques(q[i], q_dot[i], None, tasks)
    torques.append(tau)

torques = np.array(torques)

# 画图
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))

# 走路任务 vs 上肢任务
ax1.plot(time, walk_targets, 'b-', label='Walk Target')
ax1.plot(time, arm_targets, 'r-', label='Arm Target')
ax1.set_xlabel('Time (s)')
ax1.set_ylabel('Target')
ax1.set_title('WBC - Task Coordination')
ax1.legend()
ax1.grid(True)

# 关节力矩
for i in range(4):
    ax2.plot(time, torques[:, i], label=f'Joint {i+1}')
ax2.set_xlabel('Time (s)')
ax2.set_ylabel('Torque (Nm)')
ax2.set_title('WBC - Joint Torques')
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.show()