from ultra_balance.perception.brightness import BrightnessPerception

# 创建亮度感知器
bp = BrightnessPerception()

print("=" * 50)
print("亮度感知演示")
print("=" * 50)

tests = [
    "极暗",
    "很暗",
    "暗",
    "微亮",
    "正常",
    "亮",
    "很亮",
    "刺眼",
    "100勒克斯",
    "500流明",
    "再亮一点",
    "再暗一点",
    "调亮",
    "调暗",
]

print("\n[亮度理解]")
for t in tests:
    result = bp.understand(t)
    print(f"  {t} → {result}")

print("\n[亮度状态]")
lux_values = [1, 10, 30, 50, 100, 200, 400, 800]
for lux in lux_values:
    bp.set_current_brightness(lux)
    print(f"  {lux}勒克斯 → {bp.get_brightness_status()}")
    print(f"         {bp.need_light()}")