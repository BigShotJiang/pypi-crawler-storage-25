import time
from ultra_balance.learning.imitation import ImitationLearner

# 创建模仿学习模块
learner = ImitationLearner()

print("=" * 50)
print("模仿学习演示")
print("=" * 50)

# 录制一个动作
print("\n[录制动作: 拿水杯]")
print(learner.start_recording("拿水杯"))
print(learner.record_step("move_to", {"x": 100, "y": 50}))
time.sleep(0.1)
print(learner.record_step("reach_out", {"height": 0.5}))
time.sleep(0.1)
print(learner.record_step("grasp", {"force": 10}))
time.sleep(0.1)
print(learner.record_step("lift", {"height": 0.3}))
print(learner.stop_recording())

# 录制另一个动作
print("\n[录制动作: 挥手]")
print(learner.start_recording("挥手"))
print(learner.record_step("raise_arm", {"angle": 90}))
time.sleep(0.1)
print(learner.record_step("wave", {"count": 3}))
time.sleep(0.1)
print(learner.record_step("lower_arm", {}))
print(learner.stop_recording())

# 查看已录制的演示
print("\n[已录制的演示]")
for name in learner.list_demonstrations():
    print(f"  - {name}")

# 模仿执行
print("\n[模仿: 拿水杯]")
for step in learner.imitate("拿水杯"):
    print(f"  {step}")

print("\n[模仿: 挥手]")
for step in learner.imitate("挥手"):
    print(f"  {step}")