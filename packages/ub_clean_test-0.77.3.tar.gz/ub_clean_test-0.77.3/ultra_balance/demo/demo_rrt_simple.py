import matplotlib.pyplot as plt
import random
import math

# 设置随机种子
random.seed(42)

# 参数
start = (1, 1)
goal = (9, 6)
obstacles = [(2,2,0.5), (3,4,0.6), (5,3,0.8), (7,5,0.5), (8,2,0.7)]
bounds = (0, 10, 0, 10)
step = 0.5
max_iter = 500

nodes = [start]
path_found = False

def distance(p1, p2):
    return math.hypot(p1[0]-p2[0], p1[1]-p2[1])

def steer(from_node, to_node):
    dx = to_node[0] - from_node[0]
    dy = to_node[1] - from_node[1]
    d = math.hypot(dx, dy)
    if d < step:
        return to_node
    return (from_node[0] + dx/d * step, from_node[1] + dy/d * step)

def collide(p):
    for ox, oy, r in obstacles:
        if distance(p, (ox, oy)) < r:
            return True
    return False

for _ in range(max_iter):
    # 采样
    if random.random() < 0.1:
        rand = goal
    else:
        rand = (random.uniform(bounds[0], bounds[1]), random.uniform(bounds[2], bounds[3]))
    
    # 找最近节点
    nearest = min(nodes, key=lambda n: distance(n, rand))
    
    # 扩展
    new = steer(nearest, rand)
    
    # 碰撞检测
    if collide(new):
        continue
    
    nodes.append(new)
    
    # 到达目标
    if distance(new, goal) < step:
        # 回溯路径
        path = [goal, new]
        while path[-1] != start:
            # 简化：找最近父节点
            parent = min(nodes, key=lambda n: distance(n, path[-1]))
            if parent == path[-1]:
                break
            path.append(parent)
        path.reverse()
        path_found = True
        break

# 绘图
fig, ax = plt.subplots(figsize=(8,8))
for ox, oy, r in obstacles:
    ax.add_patch(plt.Circle((ox, oy), r, color='gray', alpha=0.7))

for i, node in enumerate(nodes):
    if i > 0:
        # 简单连线
        parent = min(nodes[:i], key=lambda n: distance(n, node))
        ax.plot([node[0], parent[0]], [node[1], parent[1]], 'b-', alpha=0.3, linewidth=0.5)

if path_found:
    path_x = [p[0] for p in path]
    path_y = [p[1] for p in path]
    ax.plot(path_x, path_y, 'r-', linewidth=2, label='Path')

ax.plot(start[0], start[1], 'go', markersize=10, label='Start')
ax.plot(goal[0], goal[1], 'ro', markersize=10, label='Goal')
ax.set_xlim(0,10); ax.set_ylim(0,10); ax.set_aspect('equal')
ax.grid(True); ax.legend()
plt.title('RRT Path Planning (Simplified)')
plt.show()