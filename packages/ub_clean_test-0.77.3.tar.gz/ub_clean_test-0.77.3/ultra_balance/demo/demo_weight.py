from ultra_balance.perception.weight import WeightPerception

# 创建重量感知器
wp = WeightPerception()

print("=" * 50)
print("重量感知演示")
print("=" * 50)

tests = [
    "很轻",
    "轻",
    "正常",
    "重",
    "很重",
    "5公斤",
    "500克",
    "1吨",
    "2斤",
    "再轻一点",
    "再重一点",
    "减轻",
    "加重",
]

print("\n[重量理解]")
for t in tests:
    result = wp.understand(t)
    print(f"  {t} → {result}")

print("\n[重量判断]")
weights = [0.2, 0.8, 2.0, 5.0, 8.0, 12.0]
for w in weights:
    wp.set_current_weight(w)
    print(f"  {w}公斤 → {wp.get_weight_status()}")
    print(f"         {wp.can_carry()}")