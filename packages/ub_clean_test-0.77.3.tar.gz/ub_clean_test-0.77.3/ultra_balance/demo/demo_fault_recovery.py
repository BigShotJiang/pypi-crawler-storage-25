from ultra_balance.safety.fault_recovery import FaultRecovery

# 创建故障恢复模块
robot = FaultRecovery()

print("=" * 50)
print("故障恢复演示")
print("=" * 50)

# 模拟各种故障
faults = [
    ('motor_overheat', {'temp': 85}),
    ('sensor_failure', {'sensor': 'camera'}),
    ('low_battery', {'level': 8}),
    ('communication_error', {'retry': 3}),
    ('unknown_fault', {})
]

for fault_type, details in faults:
    print(f"\n[检测到故障] {fault_type}")
    fault = robot.detect_fault(fault_type, details)
    
    success, msg = robot.recover(fault)
    print(f"  修复结果: {'✅ 成功' if success else '❌ 失败'}")
    print(f"  消息: {msg}")
    
    status = robot.get_status()
    print(f"  当前状态: {status['message']}")

print("\n" + "=" * 50)
print("最终状态")
print("=" * 50)
status = robot.get_status()
print(f"安全模式: {'是' if status['in_safe_mode'] else '否'}")
print(f"待处理故障: {status['pending_faults']}")
print(f"修复尝试次数: {status['recovery_attempts']}")
print(f"状态: {status['message']}")