import time
import random
import threading
from typing import Dict

# ========== 原有导入 ==========
try:
    from ultra_balance.safety.rules import SafetyRules
    HAS_SAFETY_RULES = True
except ImportError:
    HAS_SAFETY_RULES = False
    print("警告: safety.rules 模块未找到，跳过原有演示")

# ========== v0.76.0 新增导入 ==========
try:
    from ultra_balance.monitoring.thermal_monitor import (
        ThermalMonitor, MultiJointThermalMonitor, ThermalConfig
    )
    from ultra_balance.monitoring.power_monitor import PowerMonitor, BatteryConfig
    from ultra_balance.monitoring.heartbeat import HeartbeatMonitor, HeartbeatConfig
    from ultra_balance.monitoring.stall_detector import StallDetector, StallConfig
    from ultra_balance.monitoring.safety_guard import SafetyGuard, SafetyLevel, SafetyConfig
    HAS_V076_MODULES = True
except ImportError as e:
    HAS_V076_MODULES = False
    print(f"警告: v0.76.0 模块未找到 ({e})，跳过新增演示")


class MockRobot:
    """模拟机器人，用于演示"""
    
    def __init__(self, joint_names=None):
        self.joint_names = joint_names or ['joint1', 'joint2', 'joint3', 'joint4']
        self.joint_positions = {j: 0.0 for j in self.joint_names}
        self.joint_velocities = {j: 0.0 for j in self.joint_names}
        self.joint_torques = {j: 0.0 for j in self.joint_names}
        self.joint_currents = {j: 0.0 for j in self.joint_names}
        
        self.battery_voltage = 24.0
        self.battery_current = 0.0
        
        self.running = False
        self.task_thread = None
    
    def start_task(self, task_func):
        self.running = True
        self.task_thread = threading.Thread(target=task_func, args=(self,))
        self.task_thread.start()
    
    def stop(self):
        self.running = False
        if self.task_thread:
            self.task_thread.join(timeout=2.0)


# ========== 原有演示 ==========

def demo_original_safety_rules():
    """演示：原有安全规则"""
    print("\n" + "="*60)
    print("【原有功能】基础安全规则库演示")
    print("="*60)
    
    if not HAS_SAFETY_RULES:
        print("?? safety.rules 模块未安装，跳过此演示")
        return
    
    safety = SafetyRules()
    
    # 检查位置
    print("\n[位置检查]")
    test_positions = [(0, 0), (9, 5), (-9, 3)]
    for x, y in test_positions:
        safe, danger, level = safety.is_position_safe(x, y)
        status = "? 安全" if safe else "? 危险"
        print(f"  位置 ({x}, {y}): {status}")
    
    # 检查物体
    print("\n[物体检查]")
    test_objects = ["red_block", "fire", "blue cube", "electricity"]
    for obj in test_objects:
        safe = safety.is_object_safe(obj)
        status = "? 安全" if safe else "? 禁止触碰"
        print(f"  物体 '{obj}': {status}")
    
    # 检查任务
    print("\n[任务检查]")
    tasks = [
        {"type": "move", "target": (0, 0), "object": "red_block"},
        {"type": "move", "target": (9, 5), "object": "red_block"},
        {"type": "move", "target": (0, 0), "object": "fire"},
    ]
    
    for task in tasks:
        warnings = safety.check_task(task)
        if warnings:
            print(f"  任务 {task['type']} -> {task.get('object', 'N/A')}:")
            for w in warnings:
                print(f"    ?? {w}")
        else:
            print(f"  任务 {task['type']} -> {task.get('object', 'N/A')}: ? 安全")


# ========== v0.76.0 新增演示 ==========

def demo_basic_thermal():
    """演示：基础热监控"""
    print("\n" + "="*60)
    print("【新增功能】基础热监控")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    monitor = ThermalMonitor(
        joint_name='joint1',
        R_th=2.0,
        C_th=100.0,
        T_amb=25.0,
        T_max=80.0,
        T_warning=65.0
    )
    
    test_cases = [
        (5.0, 1.0, 5.0, "正常负载"),
        (15.0, 2.0, 5.0, "高负载"),
        (25.0, 3.0, 5.0, "过载")
    ]
    
    for torque, velocity, duration, desc in test_cases:
        print(f"\n--- {desc} ---")
        monitor.reset(25.0)
        
        for i in range(int(duration / 0.1)):
            temp = monitor.update(torque, velocity, dt=0.1)
            if i % 10 == 0:
                print(f"  t={i*0.1:.1f}s: T={temp:.1f}°C, "
                      f"降额={monitor.derating_factor:.2f}, "
                      f"状态={monitor.status}")
            
            if monitor.is_overheat:
                print(f"  ?? 过热警报！温度={temp:.1f}°C")
                break


def demo_multi_joint_thermal():
    """演示：多关节热监控"""
    print("\n" + "="*60)
    print("【新增功能】多关节热监控")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    monitor = MultiJointThermalMonitor()
    
    joints = ['shoulder', 'elbow', 'wrist']
    for joint in joints:
        monitor.add_joint(joint, T_max=75.0)
    
    torques = {'shoulder': 8.0, 'elbow': 5.0, 'wrist': 2.0}
    velocities = {'shoulder': 1.5, 'elbow': 1.0, 'wrist': 0.5}
    
    for i in range(50):
        temps = monitor.update_all(torques, velocities, dt=0.1)
        
        if i % 10 == 0:
            print(f"\nt={i*0.1:.1f}s:")
            for joint, temp in temps.items():
                m = monitor[joint]
                print(f"  {joint}: T={temp:.1f}°C, 降额={m.derating_factor:.2f}")
        
        if monitor.any_overheat:
            print(f"\n?? 过热关节: {monitor.get_overheat_joints()}")
            break


def demo_power_monitor():
    """演示：电量监控"""
    print("\n" + "="*60)
    print("【新增功能】电量监控")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    monitor = PowerMonitor(
        capacity_mah=5000,
        nominal_voltage=24.0,
        full_voltage=25.2,
        empty_voltage=20.0
    )
    
    discharge_current = 10.0
    voltage_drop_rate = 0.01
    
    for i in range(100):
        voltage = 25.2 - voltage_drop_rate * i * 0.5
        soc = monitor.update(voltage, discharge_current, dt=0.5)
        
        if i % 15 == 0:
            stats = monitor.get_statistics()
            remaining = stats['remaining_time']
            rem_str = f"{remaining:.0f}s" if remaining else "∞"
            print(f"\nt={i*0.5:.0f}s: SOC={soc*100:.1f}%, "
                  f"电压={voltage:.2f}V, "
                  f"状态={monitor.status}, "
                  f"降额={monitor.derating_factor:.2f}")
        
        if monitor.emergency_battery:
            print(f"\n? 紧急电量！SOC={soc*100:.1f}%")
            break


def demo_heartbeat():
    """演示：心跳检测"""
    print("\n" + "="*60)
    print("【新增功能】心跳检测")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    monitor = HeartbeatMonitor(
        name='main_controller',
        expected_interval=0.02,
        timeout_multiplier=3.0
    )
    
    print("\n--- 正常通信 ---")
    for i in range(30):
        seq = monitor.send_heartbeat()
        time.sleep(0.02)
        monitor.receive_heartbeat(seq)
        
        if i % 10 == 0:
            stats = monitor.get_statistics()
            print(f"  包 {i}: 延迟={stats['avg_delay_ms']:.1f}ms, "
                  f"丢包率={stats['avg_loss_rate']*100:.1f}%")
    
    print("\n--- 模拟断线 ---")
    for i in range(20):
        seq = monitor.send_heartbeat()
        time.sleep(0.05)
        monitor.check_connection()
        
        if i % 5 == 0:
            stats = monitor.get_statistics()
            print(f"  包 {i}: 连接={'断线' if monitor.connection_lost else '正常'}")


def demo_stall_detector():
    """演示：堵转检测"""
    print("\n" + "="*60)
    print("【新增功能】堵转检测")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    detector = StallDetector(
        joint_name='joint1',
        stall_time_threshold=0.2,
        emergency_time_threshold=0.5
    )
    
    print("\n--- 正常运行 ---")
    for i in range(20):
        detector.update(desired_velocity=1.0, actual_velocity=0.98, current=5.0, dt=0.02)
        if i % 5 == 0:
            print(f"  t={i*0.02:.1f}s: 状态={detector.status}")
        time.sleep(0.02)
    
    print("\n--- 模拟堵转 ---")
    detector.reset()
    for i in range(30):
        detector.update(desired_velocity=1.5, actual_velocity=0.005, current=15.0, dt=0.02)
        
        if i % 5 == 0:
            print(f"  t={i*0.02:.1f}s: 状态={detector.status}, "
                  f"持续时间={detector.stall_duration:.2f}s")
        
        if detector.is_emergency:
            print(f"\n? 堵转紧急停止！")
            break
        
        time.sleep(0.02)


def demo_safety_guard_integrated():
    """演示：统一安全守护"""
    print("\n" + "="*60)
    print("【新增功能】统一安全守护（集成演示）")
    print("="*60)
    
    if not HAS_V076_MODULES:
        print("?? v0.76.0 模块未安装，跳过此演示")
        return
    
    thermal = MultiJointThermalMonitor()
    thermal.add_joint('joint1', T_max=70.0)
    thermal.add_joint('joint2', T_max=70.0)
    
    power = PowerMonitor(capacity_mah=3000)
    
    heartbeat = HeartbeatMonitor(expected_interval=0.02)
    
    stall = StallDetector(joint_name='joint1')
    
    guard = SafetyGuard(name='robot_main')
    guard.attach_thermal_monitor(thermal)
    guard.attach_power_monitor(power)
    guard.attach_heartbeat_monitor(heartbeat)
    guard.attach_stall_detector(stall)
    
    guard.set_joint_limits(
        torque_limits={'joint1': 20.0, 'joint2': 15.0},
        velocity_limits={'joint1': 5.0, 'joint2': 5.0}
    )
    
    torques = {'joint1': 5.0, 'joint2': 3.0}
    velocities = {'joint1': 1.0, 'joint2': 0.8}
    
    voltage = 25.0
    heartbeat_seq = 0
    
    print("\n模拟机器人运行...")
    
    for step in range(80):
        thermal.update_all(torques, velocities, dt=0.1)
        
        voltage = max(20.0, voltage - 0.02)
        power.update(voltage, 8.0, dt=0.1)
        
        heartbeat_seq += 1
        heartbeat.send_heartbeat()
        if step % 5 != 0:
            heartbeat.receive_heartbeat(heartbeat_seq)
        
        stall.update(
            desired_velocity=velocities['joint1'],
            actual_velocity=velocities['joint1'] * (0.99 if step < 40 else 0.01),
            current=torques['joint1'] * 2,
            dt=0.1
        )
        
        safe_t, safe_v, level, msg = guard.check_command(torques, velocities)
        
        if step % 15 == 0:
            print(f"\n步骤 {step}: 安全等级={level.name}, 降额={guard._get_min_derating():.2f}")
            print(f"  原始力矩: {torques} -> 安全力矩: {dict(safe_t)}")
        
        if level == SafetyLevel.EMERGENCY:
            print(f"\n? 触发紧急停止！")
            break
        
        time.sleep(0.03)


# ========== 主函数 ==========

def run_all_demos():
    """运行所有演示"""
    print("\n" + "="*70)
    print("湘西紫框架 v0.76.0 - 安全监控系统演示")
    print("="*70)
    
    # 原有演示
    demo_original_safety_rules()
    print("\n" + "-"*40)
    time.sleep(0.5)
    
    # 新增演示
    demos = [
        ("基础热监控", demo_basic_thermal),
        ("多关节热监控", demo_multi_joint_thermal),
        ("电量监控", demo_power_monitor),
        ("心跳检测", demo_heartbeat),
        ("堵转检测", demo_stall_detector),
        ("统一安全守护", demo_safety_guard_integrated),
    ]
    
    for name, demo_func in demos:
        try:
            demo_func()
        except Exception as e:
            print(f"\n? 演示 '{name}' 出错: {e}")
            import traceback
            traceback.print_exc()
        
        print("\n" + "-"*40)
        time.sleep(0.5)
    
    print("\n" + "="*70)
    print("所有演示完成！")
    print("="*70)


if __name__ == "__main__":
    run_all_demos()
