import numpy as np
import matplotlib.pyplot as plt

# 模拟 PPO 学习曲线
episodes = 100
rewards = np.cumsum(np.random.randn(episodes) * 2 + 10)
rewards = np.maximum(rewards, 0)

plt.plot(rewards)
plt.xlabel('Episode')
plt.ylabel('Cumulative Reward')
plt.title('PPO Learning (Simulated)')
plt.grid()
plt.show()