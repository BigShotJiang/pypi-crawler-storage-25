import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.learning.ppo import PPO

# 简单环境
class SimpleEnv:
    def __init__(self):
        self.target = 5.0
        self.position = 0.0
    def reset(self):
        self.position = 0.0
        return np.array([self.position])
    def step(self, action):
        self.position += action[0] * 0.5
        reward = -abs(self.position - self.target)
        done = abs(self.position - self.target) < 0.1
        return np.array([self.position]), reward, done

env = SimpleEnv()
ppo = PPO(state_dim=1, action_dim=1)
rewards = []
for ep in range(100):
    s = env.reset()
    total = 0
    for _ in range(100):
        a = ppo.select_action(s)
        ns, r, done = env.step(a)
        ppo.store_transition((s, a, r, done, ns))
        s = ns
        total += r
        if done:
            break
    ppo.update()
    rewards.append(total)

plt.plot(rewards)
plt.xlabel('Episode')
plt.ylabel('Reward')
plt.title('PPO Learning')
plt.grid()
plt.show()