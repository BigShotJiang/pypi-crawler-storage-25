import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.control.mpc import SimpleMPC

# 创建 MPC 控制器
mpc = SimpleMPC(dt=0.05, horizon=20)

# 初始状态 [位置, 速度]
x0 = np.array([1.0, 0.0])
x_target = np.array([0.0, 0.0])

# 仿真
time = np.arange(0, 5, mpc.dt)
x_history = []
u_history = []

x = x0.copy()
for t in time:
    u = mpc.solve(x, x_target)
    x = mpc.dynamics(x, u)
    x_history.append(x.copy())
    u_history.append(u)

x_history = np.array(x_history)
u_history = np.array(u_history)

# 画图
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6))

# 位置和速度
ax1.plot(time, x_history[:, 0], 'b-', label='Position')
ax1.plot(time, x_history[:, 1], 'r-', label='Velocity')
ax1.set_xlabel('Time (s)')
ax1.set_ylabel('State')
ax1.set_title('MPC - State Trajectory')
ax1.legend()
ax1.grid(True)

# 控制量
ax2.plot(time, u_history, 'g-', label='Control Input')
ax2.set_xlabel('Time (s)')
ax2.set_ylabel('Control')
ax2.set_title('MPC - Control Sequence')
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.show()