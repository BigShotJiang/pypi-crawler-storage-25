from ultra_balance.learning.curiosity import CuriosityModule

# 创建好奇模块
curious = CuriosityModule()

print("=" * 50)
print("好奇机制演示")
print("=" * 50)

print("\n[初始状态]")
status = curious.get_curiosity_status()
print(f"已知地方: {status['known_places']}, 已知物体: {status['known_objects']}, 已知动作: {status['known_actions']}")

print("\n[探索建议]")
suggestions = curious.suggest_exploration()
for s in suggestions:
    print(f"  💡 {s}")

print("\n[主动探索]")
print(curious.explore(place="厨房"))
print(curious.explore(obj="红色方块"))
print(curious.explore(action="跳跃"))

print("\n[第二次探索建议]")
suggestions = curious.suggest_exploration()
for s in suggestions:
    print(f"  💡 {s}")

print("\n[继续探索]")
print(curious.explore(place="客厅"))
print(curious.explore(obj="蓝色杯子"))
print(curious.explore(action="旋转"))

print("\n[最终状态]")
status = curious.get_curiosity_status()
print(f"已知地方: {status['known_places']}, 已知物体: {status['known_objects']}, 已知动作: {status['known_actions']}")
print(f"探索记录: {status['exploration_count']} 次")

print("\n[探索历史]")
for h in curious.exploration_history:
    print(f"  📝 {h}")