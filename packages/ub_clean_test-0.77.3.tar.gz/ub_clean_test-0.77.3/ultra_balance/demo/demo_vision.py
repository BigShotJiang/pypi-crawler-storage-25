import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.perception.vision import SimpleVision

# 创建视觉感知模块
vision = SimpleVision()

# 模拟一张图像 (100x100)
image = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)

# 检测所有物体
objects = vision.detect_objects(image)

print("=" * 40)
print("视觉感知演示：机器人看到什么")
print("=" * 40)

for obj in objects:
    print(f"  看到: {obj['color']} 物体 在位置 ({obj['x']}, {obj['y']})")

# 检测红色物体
red_pos, found = vision.detect_color(image, 'red')
if found:
    print(f"\n  红色物体在: {red_pos}")

# 画图
plt.figure(figsize=(8, 6))
plt.imshow(image)
plt.title("机器人看到的画面")
plt.grid(True)

# 标注物体位置
for obj in objects:
    plt.plot(obj['x'], obj['y'], 'ro', markersize=10)
    plt.text(obj['x']+5, obj['y'], obj['color'], fontsize=12)

plt.show()