from ultra_balance.learning.meta import MetaLearner

# 创建元学习器
meta = MetaLearner()

print("=" * 50)
print("元学习演示")
print("=" * 50)

# 模拟不同任务的学习
tasks = [
    ('grasp', 'imitation', True, 3.2),
    ('grasp', 'imitation', True, 2.8),
    ('grasp', 'trial_error', False, 8.5),
    ('explore', 'curiosity', True, 5.1),
    ('explore', 'curiosity', True, 4.2),
    ('avoid', 'reflection', True, 2.5),
    ('avoid', 'reflection', False, 3.0),
]

print("\n[记录学习结果]")
for task, strategy, success, time_taken in tasks:
    meta.record_result(strategy, success, time_taken)
    status = "✅" if success else "❌"
    print(f"  {task} 用 {strategy} 策略: {status} 耗时 {time_taken}秒")

# 分析性能
print("\n[性能分析]")
for line in meta.analyze_performance():
    print(f"  {line}")

# 最佳策略
print("\n[最佳策略]")
best, rate = meta.get_best_strategy()
print(f"  {best} 策略成功率 {rate:.0%}")

# 改进建议
print("\n[改进建议]")
print(f"  {meta.suggest_improvement()}")