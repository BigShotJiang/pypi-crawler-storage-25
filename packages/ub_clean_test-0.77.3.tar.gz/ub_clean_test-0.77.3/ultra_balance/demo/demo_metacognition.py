from ultra_balance.reasoning.metacognition import MetaCognition


def main():
    print("\n" + "🧠" * 20)
    print("  ub-clean-test 0.61.0 元认知推理模块演示")
    print("🧠" * 20)
    
    mc = MetaCognition()
    
    # 1. 置信度评估
    print("\n" + "=" * 50)
    print(" 📊 置信度评估")
    print("=" * 50)
    
    context1 = {"reasoning_steps": 1, "source": "direct_fact"}
    conf1 = mc.assess_confidence("今天下雨", context1)
    print(f" 直接事实置信度: {conf1:.0%}")
    
    context2 = {"reasoning_steps": 3, "source": "inference"}
    conf2 = mc.assess_confidence("路滑要小心", context2)
    print(f" 三步推理置信度: {conf2:.0%}")
    
    context3 = {"reasoning_steps": 2, "source": "common_sense", "has_contradiction": True}
    conf3 = mc.assess_confidence("企鹅会飞", context3)
    print(f" 有矛盾的推理置信度: {conf3:.0%}")
    
    # 2. 知识溯源
    print("\n" + "=" * 50)
    print(" 🔍 知识溯源")
    print("=" * 50)
    
    result = mc.trace_knowledge("水往低处流")
    print(f"  知识: 水往低处流")
    print(f"  来源: {result['source']}")
    print(f"  版本: {result['version']}")
    
    # 3. 推理回溯
    print("\n" + "=" * 50)
    print(" 🔗 推理回溯")
    print("=" * 50)
    
    # 模拟记录推理
    mc.record_trace("下雨→地湿", ["下雨了"], "地湿了", 0.9, "user_rule")
    mc.record_trace("地湿→路滑", ["地湿了"], "路滑", 0.85, "inference")
    mc.record_trace("路滑→小心", ["路滑"], "要小心", 0.8, "inference")
    
    traces = mc.trace_reasoning("要小心")
    print(f"  推理链长度: {len(traces)}")
    for t in traces:
        print(f"    步骤{t['step']}: {t['rule']} → {t['output']} ({t['confidence']:.0%})")
    
    # 4. 生成解释
    print("\n" + "=" * 50)
    print(" 💬 生成解释")
    print("=" * 50)
    
    explanation = mc.explain("要小心")
    print(f"  {explanation}")
    
    # 5. 不确定性识别
    print("\n" + "=" * 50)
    print(" ❓ 不确定性识别")
    print("=" * 50)
    
    context = {
        "required_info": ["下雨", "时间"],
        "provided_info": ["时间"],
        "known_facts": {"天气": "晴天"}
    }
    result = mc.check_uncertainty("要不要带伞", context)
    print(f"  是否确定: {result['is_certain']}")
    print(f"  置信度: {result['confidence']:.0%}")
    print(f"  缺失信息: {result['missing_info']}")
    
    # 6. 主动提问
    print("\n" + "=" * 50)
    print(" 🤔 主动提问")
    print("=" * 50)
    
    question = mc.ask({"missing_info": ["下雨"]})
    print(f"  机器人问: {question}")
    
    question2 = mc.ask({"missing_info": ["未知信息"]})
    print(f"  机器人问: {question2}")
    
    # 7. 自我评估
    print("\n" + "=" * 50)
    print(" 📈 自我评估")
    print("=" * 50)
    
    evaluation = mc.self_evaluate()
    print(f"  已知知识数量: {evaluation['known_count']}")
    print(f"  推理总次数: {evaluation['total_inferences']}")
    print(f"  平均置信度: {evaluation['confidence_average']:.0%}")
    print(f"  未知示例: {', '.join(evaluation['unknown_examples'])}")
    
    # 8. 矛盾检测
    print("\n" + "=" * 50)
    print(" ⚠️ 矛盾检测")
    print("=" * 50)
    
    existing = ["今天下雨", "外面很热"]
    result = mc.detect_contradiction("今天晴天", existing)
    print(f"  新事实: 今天晴天")
    print(f"  已有事实: {existing}")
    print(f"  发现矛盾: {result['has_contradiction']}")
    if result['has_contradiction']:
        print(f"    矛盾: {result['contradictions'][0]['existing']} vs {result['contradictions'][0]['new']}")
    
    print("\n" + "✅" * 20)
    print("  所有元认知推理演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()