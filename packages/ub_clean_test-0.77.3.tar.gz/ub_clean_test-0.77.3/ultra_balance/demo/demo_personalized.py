from ultra_balance.memory.personalized import PersonalizedMemory

# 创建个性化记忆
memory = PersonalizedMemory('demo_personal.json')

print("=" * 50)
print("个性化记忆演示")
print("=" * 50)

# 模拟不同用户
users = ['user_zhang', 'user_li', 'user_wang']

# 第一次见面
print("\n[第一次见面]")
for uid in users:
    print(f"  {uid}: {memory.greet(uid)}")

# 记住用户信息
print("\n[记住用户]")
print(memory.remember_user('user_zhang', name='张先生', info={'color': '蓝色', 'drink': '咖啡'}))
print(memory.remember_user('user_li', name='李女士', info={'color': '红色', 'drink': '茶'}))
print(memory.remember_user('user_wang', name='小王', info={'color': '绿色', 'drink': '可乐'}))

# 记录几次交互
print("\n[记录交互]")
memory.add_interaction('user_zhang', '今天天气真好', '是的，张先生')
memory.add_interaction('user_zhang', '帮我拿杯咖啡', '好的，马上')
memory.add_interaction('user_li', '把灯打开', '好的，李女士')
memory.add_interaction('user_li', '谢谢', '不客气')

# 再次见面
print("\n[再次见面]")
for uid in users:
    print(f"  {uid}: {memory.greet(uid)}")

# 回忆偏好
print("\n[回忆偏好]")
print(f"  张先生喜欢什么颜色？ {memory.recall_preference('user_zhang', 'color')}")
print(f"  李女士喜欢什么饮料？ {memory.recall_preference('user_li', 'drink')}")
print(f"  小王喜欢什么？ {memory.recall_preference('user_wang', 'color')}")