from ultra_balance.reasoning.emotion_understanding import EmotionUnderstanding

# 创建情感理解器
eu = EmotionUnderstanding()

print("=" * 50)
print("情感理解演示")
print("=" * 50)

tests = [
    "我开心",
    "我很开心",
    "我有点难过",
    "我非常生气",
    "我害怕",
    "我很惊讶",
    "我开心，因为今天天气好",
    "我难过，因为考试没考好",
]

print("\n[情感理解]")
for t in tests:
    result = eu.understand(t)
    print(f"  用户说: {t}")
    print(f"  机器人: {result}\n")