import time
import random
import numpy as np

# ========== 原有导入 ==========
try:
    from ultra_balance.perception.vla import SimpleVLA
    from ultra_balance.perception.vision import SimpleVision
    from ultra_balance.control.wbc import WholeBodyControl
    from ultra_balance.planning.task_planner import TaskPlanner
    HAS_TASK_PLANNER = True
except ImportError as e:
    HAS_TASK_PLANNER = False
    print(f"警告: TaskPlanner 模块未找到 ({e})，跳过原有演示")

# ========== v0.77.0 新增导入 ==========
try:
    from ultra_balance.decision.behavior_tree import (
        BehaviorTree, BehaviorTreeBuilder,
        NodeStatus, Blackboard, RobotActions
    )
    from ultra_balance.decision.task_state_machine import (
        TaskStateMachine, Task, TaskStatus
    )
    from ultra_balance.reasoning.universal import UniversalReasoning
    HAS_V077_MODULES = True
except ImportError as e:
    HAS_V077_MODULES = False
    print(f"警告: v0.77.0 模块未找到 ({e})，跳过新增演示")


# ========== 原有演示 ==========

def demo_original_task_planner():
    """演示1：原有 TaskPlanner"""
    print("\n" + "="*60)
    print("【原有功能】TaskPlanner 演示")
    print("="*60)
    
    if not HAS_TASK_PLANNER:
        print("?? TaskPlanner 模块未安装，跳过此演示")
        return
    
    # 创建各模块
    vla = SimpleVLA()
    vision = SimpleVision()
    wbc = WholeBodyControl()
    
    # 创建任务规划器
    planner = TaskPlanner(vla, vision, wbc)
    
    # 生成模拟图像
    image = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
    
    # 测试指令
    commands = [
        "拿红色方块",
        "去蓝色那边",
        "捡起绿色的",
        "把黄色的拿过来",
    ]
    
    print("\n机器人听懂→看懂→行动")
    print("-" * 40)
    
    for cmd in commands:
        result = planner.execute(cmd, image)
        print(f"指令: {cmd}")
        print(f"结果: {result}\n")


# ========== v0.77.0 新增演示 ==========

def demo_behavior_tree_basic():
    """演示2：基础行为树"""
    print("\n" + "="*60)
    print("【新增功能】基础行为树")
    print("="*60)
    
    if not HAS_V077_MODULES:
        print("?? v0.77.0 模块未安装，跳过此演示")
        return
    
    # 构建简单的行为树
    tree = (BehaviorTreeBuilder("简单任务")
            .sequence("主流程")
                .action("step1", "步骤1")
                .action("step2", "步骤2")
                .action("step3", "步骤3")
            .end()
            .build())
    
    # 注册动作回调
    def step_action(step_name):
        def _action(bb):
            print(f"    执行: {step_name}")
            bb.set('last_step', step_name)
            return True
        return _action
    
    for node in tree.root.children:
        if hasattr(node, 'action'):
            node.register_callback(node.action, step_action(node.action))
    
    # 执行
    print("\n执行行为树:")
    status = tree.tick_until_done()
    print(f"\n结果: {status.value}")
    print(f"黑板数据: {tree.blackboard.to_dict()}")


def demo_selector_fallback():
    """演示3：选择器（失败回退）"""
    print("\n" + "="*60)
    print("【新增功能】选择器 - 失败回退")
    print("="*60)
    
    if not HAS_V077_MODULES:
        print("?? v0.77.0 模块未安装，跳过此演示")
        return
    
    # 模拟可能失败的动作
    attempt_count = 0
    
    def try_action(bb):
        nonlocal attempt_count
        attempt_count += 1
        if attempt_count < 3:
            print(f"    尝试 {attempt_count} 失败")
            return False
        print(f"    尝试 {attempt_count} 成功")
        return True
    
    def fallback_action(bb):
        print("    执行回退动作")
        return True
    
    tree = (BehaviorTreeBuilder("失败回退")
            .selector("尝试或回退")
                .action(try_action, "可能失败的动作")
                .action(fallback_action, "回退动作")
            .end()
            .build())
    
    print("\n执行行为树:")
    status = tree.tick_until_done()
    print(f"\n结果: {status.value}")


def demo_pickup_pillow():
    """演示4：捡枕头任务（模拟）"""
    print("\n" + "="*60)
    print("【新增功能】捡枕头任务 - 行为树驱动")
    print("="*60)
    
    if not HAS_V077_MODULES:
        print("?? v0.77.0 模块未安装，跳过此演示")
        return
    
    # 模拟状态
    pillow_detected = False
    search_count = 0
    
    def condition_pillow(bb):
        return pillow_detected
    
    def action_search(bb):
        nonlocal search_count, pillow_detected
        search_count += 1
        print(f"    搜索枕头... (第 {search_count} 次)")
        if search_count >= 2:
            pillow_detected = True
            print("    发现枕头！")
        return True
    
    def action_move_to_pillow(bb):
        print("    移动到枕头位置")
        return True
    
    def action_grasp(bb):
        print("    抓取枕头")
        # 模拟可能掉落
        if random.random() < 0.3:
            print("    ?? 枕头掉落！")
            return False
        return True
    
    def action_place(bb):
        print("    放置枕头到目标位置")
        return True
    
    tree = (BehaviorTreeBuilder("捡枕头")
            .selector("任务选择")
                .sequence("主流程")
                    .condition(condition_pillow, "检测枕头")
                    .action(action_move_to_pillow, "移动到枕头")
                    .action(action_grasp, "抓取枕头")
                    .action(action_place, "放置枕头")
                .end()
                .action(action_search, "搜索枕头")
            .end()
            .build())
    
    print("\n执行捡枕头任务:")
    status = tree.tick_until_done(max_ticks=20)
    print(f"\n结果: {status.value}")


def demo_task_state_machine():
    """演示5：任务状态机"""
    print("\n" + "="*60)
    print("【新增功能】任务状态机 - 暂停/恢复/重试")
    print("="*60)
    
    if not HAS_V077_MODULES:
        print("?? v0.77.0 模块未安装，跳过此演示")
        return
    
    # 创建简单任务
    step = 0
    
    def task_action(bb):
        nonlocal step
        step += 1
        print(f"    执行步骤 {step}")
        
        # 模拟第3步失败
        if step == 3:
            print("    ?? 步骤3失败")
            return False
        
        time.sleep(0.1)
        return step >= 5
    
    tree = (BehaviorTreeBuilder("测试任务")
            .repeater(10, "重复执行")
                .action(task_action, "执行步骤")
            .end()
            .build())
    
    task = Task(
        name="测试任务",
        behavior_tree=tree,
        max_retries=2
    )
    
    tsm = TaskStateMachine()
    
    print("\n启动任务:")
    tsm.start_task(task)
    
    for i in range(20):
        status = tsm.tick()
        print(f"  tick {i+1}: {status.value}, 状态: {tsm.state.value}")
        
        if i == 3:
            print("\n暂停任务...")
            tsm.pause()
            time.sleep(0.5)
            print("恢复任务...")
            tsm.resume()
        
        if tsm.is_completed():
            break
        
        if tsm.is_failed():
            print(f"\n任务失败，重试次数: {tsm.retry_count}")
            if tsm.retry():
                print("正在重试...")
            else:
                break
    
    print(f"\n最终状态: {tsm.state.value}")
    print(f"统计: {tsm.get_statistics()}")


def demo_universal_reasoning_task():
    """演示6：UniversalReasoning 生成行为树"""
    print("\n" + "="*60)
    print("【新增功能】UniversalReasoning 生成行为树")
    print("="*60)
    
    if not HAS_V077_MODULES:
        print("?? v0.77.0 模块未安装，跳过此演示")
        return
    
    ur = UniversalReasoning()
    
    tasks = ["捡枕头", "堆积木", "擦桌子"]
    
    for task_name in tasks:
        print(f"\n任务: {task_name}")
        response = ur.reason_task(task_name)
        
        if response.success:
            result = response.result
            print(f"  行为树: {result['behavior_tree']['name']}")
            print(f"  根节点类型: {result['behavior_tree']['root']['type']}")
            print(f"  JSON 长度: {len(result['behavior_tree_json'])} 字符")
        else:
            print(f"  失败: {response.explanation}")


# ========== 主函数 ==========

def main():
    print("\n" + "="*70)
    print("湘西紫框架 v0.77.0 - 任务规划演示")
    print("="*70)
    
    # 原有演示
    demo_original_task_planner()
    print("\n" + "-"*40)
    time.sleep(0.5)
    
    # 新增演示
    demos = [
        ("基础行为树", demo_behavior_tree_basic),
        ("选择器回退", demo_selector_fallback),
        ("捡枕头任务", demo_pickup_pillow),
        ("任务状态机", demo_task_state_machine),
        ("UniversalReasoning任务", demo_universal_reasoning_task),
    ]
    
    for name, demo_func in demos:
        try:
            demo_func()
        except Exception as e:
            print(f"\n? 演示 '{name}' 出错: {e}")
            import traceback
            traceback.print_exc()
        
        print("\n" + "-"*40)
        time.sleep(0.5)
    
    print("\n" + "="*70)
    print("所有演示完成！")
    print("="*70)


if __name__ == "__main__":
    main()
