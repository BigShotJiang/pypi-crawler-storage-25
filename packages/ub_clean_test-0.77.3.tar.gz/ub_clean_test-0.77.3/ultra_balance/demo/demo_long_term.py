import time
from ultra_balance.memory.long_term import LongTermMemory

# 创建长期记忆
memory = LongTermMemory('demo_memory.json')

print("=" * 50)
print("长期记忆演示")
print("=" * 50)

# 记住事实
print("\n[记住事实]")
print(memory.remember_fact('danger_zone', 'kitchen_has_fire'))
print(memory.remember_fact('safe_place', 'living_room'))

# 回忆事实
print("\n[回忆事实]")
print(f"危险区域在哪？ {memory.recall_fact('danger_zone')}")
print(f"安全区域在哪？ {memory.recall_fact('safe_place')}")

# 记住事件
print("\n[记住事件]")
print(memory.remember_event("主人说：厨房有火别靠近", importance=5))
time.sleep(0.1)
print(memory.remember_event("机器人成功拿了红色方块", importance=3))
time.sleep(0.1)
print(memory.remember_event("主人说：喜欢蓝色", importance=4))

# 回忆事件
print("\n[最近事件]")
for e in memory.recall_events(3):
    print(f"  {e['event']} (重要程度: {e['importance']})")

# 记住偏好
print("\n[记住偏好]")
print(memory.remember_preference('主人', 'color', 'blue'))
print(memory.remember_preference('主人', 'speed', 'fast'))

# 回忆偏好
print("\n[回忆偏好]")
print(f"主人喜欢什么颜色？ {memory.recall_preference('主人', 'color')}")
print(f"主人喜欢什么速度？ {memory.recall_preference('主人', 'speed')}")

print("\n" + "=" * 50)
print("记忆已保存，下次启动还能记住")
print("=" * 50)