from ultra_balance.reasoning.logical import LogicalReasoning

def main():
    print("\n" + "🧠" * 20)
    print(" ub-clean-test 0.58.0 逻辑推理模块演示")
    print("🧠" * 20)

    r = LogicalReasoning()

    print("\n" + "=" * 50)
    print(" 📐 三段论推理")
    print("=" * 50)
    result1 = r.syllogism('所有人都会死', '苏格拉底是人', '苏格拉底会死')
    print(" " + result1['explanation'])
    result2 = r.syllogism('所有猫都爱吃鱼', '小花是猫', '小花爱吃鱼')
    print(" " + result2['explanation'])

    print("\n" + "=" * 50)
    print(" 🌧️ 条件推理")
    print("=" * 50)
    result3 = r.if_then('下雨', '地湿', '下雨了')
    print(" " + result3['explanation'])
    result4 = r.if_then('下雨', '地湿', '天气晴朗')
    print(" " + result4['explanation'])

    print("\n" + "=" * 50)
    print(" 💧 逆向推理")
    print("=" * 50)
    result5 = r.reverse_reason('下雨', '地湿', '地湿了')
    print(" " + result5['explanation'])
    print(" 可能原因: " + ', '.join(result5['possible_causes']))

    print("\n" + "=" * 50)
    print(" 🔗 链式推理")
    print("=" * 50)
    result6 = r.chain_reason(["下雨→地湿", "地湿→路滑", "路滑→小心"], ["下雨了"])
    print(" " + result6['explanation'])
    if result6['derived_facts']:
        print(" 推导出: " + ' → '.join(result6['derived_facts']))

    print("\n" + "✅" * 20)
    print(" 所有推理演示跑通！")
    print("✅" * 20)

if __name__ == "__main__":
    main()