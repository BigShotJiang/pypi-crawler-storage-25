from ultra_balance.perception.color import ColorPerception

# 创建颜色感知器
cp = ColorPerception()

print("=" * 50)
print("颜色感知演示")
print("=" * 50)

tests = [
    "红",
    "蓝",
    "绿",
    "黄",
    "紫",
    "深红",
    "浅蓝",
    "暗绿",
]

print("\n[颜色理解]")
for t in tests:
    result = cp.understand(t)
    print(f"  {t} → {result}")

print("\n[颜色偏好]")
print(cp.remember_preference("张三", "蓝"))
print(cp.remember_preference("张三", "深蓝"))
print(cp.remember_preference("李四", "红"))
print(f"  张三喜欢的颜色: {cp.get_preference('张三')}")
print(f"  李四喜欢的颜色: {cp.get_preference('李四')}")

print("\n[颜色搭配]")
print(f"  红和绿: {cp.color_match('红', '绿')}")
print(f"  蓝和白: {cp.color_match('蓝', '白')}")
print(f"  红和蓝: {cp.color_match('红', '蓝')}")

print("\n[颜色推荐]")
print(f"  给张三推荐: {cp.recommend('张三')}")
print(f"  给李四推荐: {cp.recommend('李四')}")