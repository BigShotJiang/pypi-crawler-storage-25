from ultra_balance.reasoning.compositional import CompositionalReasoner

# 模拟机器人
class MockRobot:
    def __init__(self):
        self.last_seen_color = 'red'
    
    def execute_task(self, task):
        return f"执行: {task}"

# 创建推理器
reasoner = CompositionalReasoner()
robot = MockRobot()

print("=" * 50)
print("组合推理演示")
print("=" * 50)

# 测试各种指令
commands = [
    "先拿杯子，再倒水，然后端过来",
    "如果杯子是红色的就拿，蓝色的就不拿",
    "一边扫地，一边播音乐",
    "不要拿红色的杯子",
    "把蓝色方块拿给我"
]

print("\n[组合推理]")
for cmd in commands:
    print(f"\n用户说: {cmd}")
    result = reasoner.execute(cmd, robot)
    for r in result:
        print(f"  机器人: {r}")