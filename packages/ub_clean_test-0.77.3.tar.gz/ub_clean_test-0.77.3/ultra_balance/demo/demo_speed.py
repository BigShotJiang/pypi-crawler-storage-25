from ultra_balance.perception.speed import SpeedPerception

# 创建速度感知器
sp = SpeedPerception()

print("=" * 50)
print("速度感知演示")
print("=" * 50)

tests = [
    "很慢",
    "慢",
    "正常",
    "快",
    "很快",
    "5米/秒",
    "10公里/小时",
    "再快一点",
    "慢一点",
    "加速",
    "减速",
]

print("\n[速度理解]")
for t in tests:
    result = sp.understand(t)
    print(f"  {t} → {result}")

print("\n[速度状态]")
speeds = [0.5, 1.0, 2.0, 3.0, 4.0, 5.0]
for s in speeds:
    sp.set_current_speed(s)
    print(f"  {s}米/秒 → {sp.get_speed_status()}")