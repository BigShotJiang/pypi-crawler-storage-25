from ultra_balance.learning.active import ActiveLearner

# 创建主动学习器
learner = ActiveLearner()

print("=" * 50)
print("主动学习演示")
print("=" * 50)

# 测试各种情况
queries = [
    "红色的杯子",
    "蓝色的方块",
    "厨房的位置",
    "主人的名字",
    "红色的杯子"  # 重复，应该学会了
]

print("\n[主动学习过程]")
for query in queries:
    result = learner.learn_from_interaction(query)
    print(f"  用户问: {query}")
    print(f"  机器人: {result}")
    
    # 如果是提问，模拟用户回答
    if result.startswith("🤔"):
        # 模拟用户回答
        answer = "红色杯子在桌上"
        print(f"  用户答: {answer}")
        learner.learn_from_answer(query, answer)
    print()

# 查看学到的知识
print("\n[已学知识]")
for k, v in learner.knowledge.items():
    print(f"  {k} → {v}")