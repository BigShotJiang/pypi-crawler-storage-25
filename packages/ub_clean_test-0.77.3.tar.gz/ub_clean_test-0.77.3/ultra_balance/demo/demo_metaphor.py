from ultra_balance.reasoning.metaphor import MetaphorUnderstanding

# 创建比喻理解器
mu = MetaphorUnderstanding()

print("=" * 50)
print("比喻理解演示")
print("=" * 50)

tests = [
    "时间就是金钱",
    "光阴似箭",
    "火上浇油",
    "画蛇添足",
    "心里石头落了地",
    "心在滴血",
    "等了一万年",
    "笑死我了",
    "饿死了",
]

print("\n[比喻理解]")
for t in tests:
    result = mu.understand(t)
    print(f"  用户说: {t}")
    print(f"  机器人: {result}\n")