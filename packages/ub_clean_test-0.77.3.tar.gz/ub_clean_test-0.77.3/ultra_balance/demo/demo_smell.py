from ultra_balance.perception.smell import SmellPerception

# 创建嗅觉感知器
sp = SmellPerception()

print("=" * 50)
print("嗅觉感知演示")
print("=" * 50)

tests = [
    "极香",
    "很香",
    "香",
    "有点香",
    "无味",
    "有点臭",
    "臭",
    "很臭",
    "极臭",
    "刺鼻",
    "酸",
    "甜",
    "花香",
    "果香",
    "焦味",
    "再香一点",
    "再淡一点",
]

print("\n[气味理解]")
for t in tests:
    result = sp.understand(t)
    print(f"  {t} → {result}")

print("\n[气味状态]")
intensities = [0, 2, 4, 6, 8, 10]
for i in intensities:
    sp.set_current_intensity(i)
    print(f"  {i}级 → {sp.get_smell_status()}")
    print(f"         {sp.suggest_action()}")