from ultra_balance.reasoning.dialogue import DialogueManager


def main():
    print("\n" + "💬" * 20)
    print("  ub-clean-test 0.66.0 多轮对话模块演示")
    print("💬" * 20)
    
    dm = DialogueManager()
    
    conversations = [
        "你好",
        "今天天气怎么样？",
        "那明天呢？",
        "去厨房",
        "打开灯",
        "那个",
        "再见"
    ]
    
    print("\n" + "=" * 50)
    print(" 💬 多轮对话演示")
    print("=" * 50)
    
    for user_input in conversations:
        print(f"\n  👤 用户: {user_input}")
        
        result = dm.generate_response(user_input)
        
        print(f"    意图: {result['intent']}")
        if result['entities']:
            print(f"    实体: {result['entities']}")
        if result['context_used']:
            print(f"    🔗 {result['inference']}")
        print(f"  🤖 机器人: {result['response']}")
    
    print("\n" + "=" * 50)
    print(" 🧠 多轮推理演示")
    print("=" * 50)
    
    dm2 = DialogueManager()
    dm2.generate_response("我想去超市")
    dm2.generate_response("怎么去那里")
    dm2.generate_response("它远吗")
    
    reasoning = dm2.multi_turn_reason("刚才说的那个地方")
    print(f"  当前输入: 刚才说的那个地方")
    print(f"  推理结果: {reasoning['reasoning']}")
    print(f"  引用轮次: {[t+1 for t in reasoning['referenced_turns']]}")
    print(f"  置信度: {reasoning['confidence']:.0%}")
    
    print("\n" + "=" * 50)
    print(" 📝 上下文管理演示")
    print("=" * 50)
    
    dm3 = DialogueManager()
    dm3.generate_response("我喜欢蓝色")
    dm3.generate_response("红色呢")
    
    context = dm3.get_all_context()
    print(f"  当前上下文: {context}")
    
    print("\n" + "=" * 50)
    print(" 📊 对话统计")
    print("=" * 50)
    
    stats = dm.get_statistics()
    print(f"  总对话轮次: {stats['total_turns']}")
    print(f"  意图分布: {stats['intent_distribution']}")
    print(f"  上下文变量: {stats['context_variables']}")
    
    print("\n" + "=" * 50)
    print(" 📜 对话历史摘要")
    print("=" * 50)
    print(dm.get_history_summary())
    
    print("\n" + "✅" * 20)
    print("  所有多轮对话演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()