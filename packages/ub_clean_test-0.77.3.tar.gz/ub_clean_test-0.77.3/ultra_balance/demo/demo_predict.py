import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.prediction.state_predictor import StatePredictor

# 创建预测器
predictor = StatePredictor(dt=0.1)

# 当前状态 [x, y, vx, vy, ax, ay]
state = [0, 0, 2, 0, 0, 0]  # 向右以 2m/s 匀速运动

# 障碍物位置和半径
obstacle_pos = (5, 0)
obstacle_radius = 0.5

# 预测轨迹
traj_x, traj_y = predictor.predict_trajectory(state, steps=50)

# 检查是否碰撞
will_hit, step = predictor.will_collide(state, obstacle_pos, obstacle_radius, steps=50)

print("=" * 50)
print("状态预测演示")
print("=" * 50)
print(f"初始状态: x={state[0]}, vx={state[2]}")
print(f"障碍物位置: {obstacle_pos}, 半径: {obstacle_radius}")
print(f"预测结果: {'会碰撞' if will_hit else '不会碰撞'}")
if will_hit:
    print(f"将在第 {step} 步（{step*0.1:.1f}秒后）碰撞")

# 画图
plt.figure(figsize=(8, 6))
plt.plot(traj_x, traj_y, 'b-', linewidth=2, label='Predicted Path')
plt.plot(state[0], state[1], 'go', markersize=10, label='Start')
circle = plt.Circle(obstacle_pos, obstacle_radius, color='r', alpha=0.5, label='Obstacle')
plt.gca().add_patch(circle)
plt.xlabel('X (m)')
plt.ylabel('Y (m)')
plt.title('State Prediction: Will It Collide?')
plt.axis('equal')
plt.grid(True)
plt.legend()
plt.show()