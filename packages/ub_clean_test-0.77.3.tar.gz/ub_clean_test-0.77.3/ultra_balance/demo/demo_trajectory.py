import numpy as np
import matplotlib.pyplot as plt

# 五次多项式轨迹（手算）
def quintic(t, q0, qf, T):
    a0 = q0
    a1 = 0
    a2 = 0
    a3 = (20*qf - 20*q0) / (2*T**3)
    a4 = (30*q0 - 30*qf) / (2*T**4)
    a5 = (12*qf - 12*q0) / (2*T**5)
    return a0 + a1*t + a2*t**2 + a3*t**3 + a4*t**4 + a5*t**5

q0, qf, T = 0, 1.5, 2
t = np.linspace(0, T, 100)
q = [quintic(ti, q0, qf, T) for ti in t]

plt.plot(t, q)
plt.xlabel('Time (s)')
plt.ylabel('Position')
plt.title('Quintic Trajectory')
plt.grid()
plt.show()