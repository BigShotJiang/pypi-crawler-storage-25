import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.control.adaptive import AdaptiveGainScheduler

# 模拟一个变化的系统
time = np.linspace(0, 20, 1000)
error = np.sin(time) * 2.0          # 模拟误差
velocity = np.cos(time)              # 模拟速度

# 自适应控制器
adaptive = AdaptiveGainScheduler(base_kp=100, base_kd=20)

kp_history = []
kd_history = []

for i in range(len(time)):
    state = {
        'velocity': velocity[i],
        'contact_force': 100 * np.sin(time[i] * 0.5)  # 模拟接触力
    }
    kp, kd = adaptive.update(error[i], state)
    kp_history.append(kp)
    kd_history.append(kd)

# 画图
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))

# 上面的图：误差和速度
ax1.plot(time, error, 'b-', label='Error')
ax1.plot(time, velocity, 'g-', label='Velocity')
ax1.set_xlabel('Time (s)')
ax1.set_ylabel('Value')
ax1.set_title('System State')
ax1.legend()
ax1.grid(True)

# 下面的图：增益变化
ax2.plot(time, kp_history, 'r-', label='Kp')
ax2.plot(time, kd_history, 'm-', label='Kd')
ax2.set_xlabel('Time (s)')
ax2.set_ylabel('Gain')
ax2.set_title('Adaptive Gains')
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.show()