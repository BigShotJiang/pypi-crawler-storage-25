from ultra_balance.reasoning.strategy import StrategyGeneration


def main():
    print("\n" + "🎯" * 20)
    print("  ub-clean-test 0.69.0 策略生成模块演示")
    print("🎯" * 20)
    
    sg = StrategyGeneration()
    
    # 1. 生成策略
    print("\n" + "=" * 50)
    print(" 🎯 生成策略")
    print("=" * 50)
    
    strategies = sg.generate_strategy("导航到会议室", {"safety_first": True})
    print(f"  目标: 导航到会议室")
    for s in strategies:
        print(f"    - {s.name}: {s.description[:40]}...")
    
    # 2. 策略评估
    print("\n" + "=" * 50)
    print(" 📊 策略评估")
    print("=" * 50)
    
    for s in strategies[:2]:
        evaluation = sg.evaluate_strategy(s)
        print(f"  {s.name}:")
        print(f"    评分: {evaluation['score']:.0%}")
        print(f"    推荐: {evaluation['recommendation']}")
        print(f"    分析: {evaluation['analysis']}")
    
    # 3. 策略优化
    print("\n" + "=" * 50)
    print(" 🔧 策略优化")
    print("=" * 50)
    
    original = strategies[0]
    print(f"  原始策略: {original.name}")
    print(f"    预估时间: {original.estimated_time}秒")
    print(f"    成功率: {original.success_rate:.0%}")
    
    optimized = sg.optimize_strategy(original, "速度太慢")
    print(f"  优化后: {optimized.name}")
    print(f"    预估时间: {optimized.estimated_time}秒")
    print(f"    成功率: {optimized.success_rate:.0%}")
    
    # 4. 选择最佳策略
    print("\n" + "=" * 50)
    print(" 🏆 选择最佳策略")
    print("=" * 50)
    
    best = sg.select_best_strategy(strategies, {"priority": "safety"})
    print(f"  最佳策略: {best['best_strategy']}")
    print(f"  评分: {best['score']:.0%}")
    print(f"  理由: {best['reason']}")
    
    # 5. 执行策略
    print("\n" + "=" * 50)
    print(" ⚡ 执行策略")
    print("=" * 50)
    
    result = sg.execute_strategy(strategies[0])
    print(f"  执行结果: {result['message']}")
    print(f"  策略ID: {result['strategy_id']}")
    print(f"  执行步骤: {len(result['execution_log'])}步")
    
    # 6. 策略学习
    print("\n" + "=" * 50)
    print(" 📖 策略学习")
    print("=" * 50)
    
    if result['success']:
        learn_result = sg.learn_from_execution(result['strategy_id'], "执行成功")
    else:
        learn_result = sg.learn_from_execution(result['strategy_id'], "执行失败")
    print(f"  {learn_result['message']}")
    
    # 7. 策略组合
    print("\n" + "=" * 50)
    print(" 🔗 策略组合")
    print("=" * 50)
    
    composed = sg.compose_strategies(strategies[:2], "sequential")
    print(f"  组合策略: {composed.name}")
    print(f"    步骤数: {len(composed.steps)}")
    print(f"    总时间: {composed.estimated_time}秒")
    print(f"    成功率: {composed.success_rate:.0%}")
    
    # 8. 统计报告
    print("\n" + "=" * 50)
    print(" 📊 策略统计")
    print("=" * 50)
    
    stats = sg.get_statistics()
    print(f"  总策略数: {stats['total_strategies']}")
    print(f"  完成策略: {stats['completed_count']}")
    print(f"  失败策略: {stats['failed_count']}")
    print(f"  成功率: {stats['success_rate']:.0%}")
    print(f"  平均置信度: {stats['avg_confidence']:.0%}")
    print(f"  策略类型: {stats['strategy_types']}")
    
    print("\n" + "✅" * 20)
    print("  所有策略生成演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()