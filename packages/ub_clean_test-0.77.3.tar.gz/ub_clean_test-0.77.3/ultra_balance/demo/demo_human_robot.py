from ultra_balance.reasoning.human_robot import HumanRobotCollaboration


def main():
    print("\n" + "🤝" * 20)
    print("  ub-clean-test 0.68.0 人机协作模块演示")
    print("🤝" * 20)
    
    hrc = HumanRobotCollaboration()
    
    # 1. 理解人类指令
    print("\n" + "=" * 50)
    print(" 🧠 理解人类指令")
    print("=" * 50)
    
    instructions = [
        "去厨房",
        "拿杯子",
        "放下手机",
        "今天天气怎么样",
        "停止",
        "跟着我",
        "报告状态",
    ]
    
    for inst in instructions:
        result = hrc.understand_instruction(inst)
        print(f"  指令: {inst}")
        print(f"    意图: {result['intent']}, 置信度: {result['confidence']:.0%}")
        print(f"    响应: {result['response']}")
        print()
    
    # 2. 主动汇报
    print("\n" + "=" * 50)
    print(" 📢 主动汇报")
    print("=" * 50)
    
    report = hrc.report_status("status", {"position": "客厅"})
    print(f"  状态汇报: {report}")
    
    alert = hrc.report_status("alert", {"message": "检测到障碍物"})
    print(f"  警报: {alert}")
    
    question = hrc.report_status("question", {"question": "是否继续前进？"})
    print(f"  询问: {question}")
    
    # 3. 请求帮助
    print("\n" + "=" * 50)
    print(" 🆘 请求帮助")
    print("=" * 50)
    
    help_request = hrc.request_help("打开这扇门", "我的手无法够到门把手")
    print(f"  帮助请求: {help_request}")
    
    # 4. 适应性响应
    print("\n" + "=" * 50)
    print(" 🔄 适应性响应")
    print("=" * 50)
    
    # 切换到详细模式用户
    hrc.set_current_human("human_2")
    print("  用户: 用户B (详细模式)")
    
    result = hrc.adaptive_response("去厨房")
    print(f"    响应: {result['response']}")
    
    # 切换到简洁模式用户
    hrc.set_current_human("human_1")
    print("  用户: 用户A (简洁模式)")
    
    result = hrc.adaptive_response("去厨房")
    print(f"    响应: {result['response']}")
    
    # 5. 信任建立
    print("\n" + "=" * 50)
    print(" ⭐ 信任建立")
    print("=" * 50)
    
    print(f"  初始信任度: {hrc.get_trust_level('human_1')}")
    
    for i in range(3):
        new_trust = hrc.update_trust("human_1", True, f"任务{i+1}")
        print(f"  第{i+1}次成功 → 信任度: {new_trust.value}")
    
    # 一次失败
    new_trust = hrc.update_trust("human_1", False, "失败任务")
    print(f"  失败一次 → 信任度: {new_trust.value}")
    
    # 6. 协作任务管理
    print("\n" + "=" * 50)
    print(" 📋 协作任务管理")
    print("=" * 50)
    
    task_id = hrc.create_collaboration_task(
        description="搬运箱子到仓库",
        human_role="指挥",
        robot_role="执行"
    )
    print(f"  创建任务: {task_id}")
    
    hrc.complete_collaboration_task(task_id, success=True)
    print(f"  任务完成: {task_id}")
    
    # 7. 统计报告
    print("\n" + "=" * 50)
    print(" 📊 协作统计")
    print("=" * 50)
    
    stats = hrc.get_statistics()
    print(f"  总用户数: {stats['total_humans']}")
    print(f"  当前用户: {stats['current_human']}")
    print(f"  总指令数: {stats['total_instructions']}")
    print(f"  协作任务: {stats['total_collaboration_tasks']}")
    print(f"  完成任务: {stats['completed_tasks']}")
    print(f"  信任分布: {stats['trust_distribution']}")
    
    print("\n" + "✅" * 20)
    print("  所有人机协作演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()