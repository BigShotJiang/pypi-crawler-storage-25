from ultra_balance.reasoning.humor import HumorUnderstanding

# 创建幽默理解器
hu = HumorUnderstanding()

print("=" * 50)
print("幽默理解演示")
print("=" * 50)

tests = [
    "哈哈",
    "呵呵",
    "开个玩笑",
    "为什么电脑总是冷？",
    "因为它有风扇！",
    "哈哈，真好笑",
    "讲个笑话吧",
]

print("\n[幽默理解]")
for t in tests:
    if "讲个笑话" in t:
        joke = hu.tell_joke()
        print(f"  用户说: {t}")
        print(f"  机器人: {joke}")
        punchline = hu.tell_punchline()
        print(f"  机器人: {punchline}\n")
    else:
        result = hu.understand(t)
        print(f"  用户说: {t}")
        print(f"  机器人: {result}\n")

print("\n[主动讲笑话]")
joke = hu.tell_joke()
print(f"  机器人: {joke}")
punchline = hu.tell_punchline()
print(f"  机器人: {punchline}")