import numpy as np
import matplotlib.pyplot as plt
from ultra_balance.control.lipm import LIPM

# 创建LIPM模型 (质心高度1m)
lipm = LIPM(z_c=1.0)

# 初始状态
x0 = 0.2       # 质心初始位置 (偏离0.2m)
x_dot0 = 0.0   # 初始速度
T_step = 0.8   # 单步时间0.8秒

# 计算第一步落脚点
p = lipm.compute_next_footstep(x0, x_dot0, T_step)
print(f"计算出的落脚点: {p:.3f} m")

# 仿真单步内质心运动
time, x, x_dot = lipm.simulate_step(x0, x_dot0, p, T_step)

# 画图
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6))

# 质心位置
ax1.plot(time, x, 'b-', linewidth=2)
ax1.axhline(y=p, color='r', linestyle='--', label='Footstep (p)')
ax1.set_xlabel('Time (s)')
ax1.set_ylabel('Position (m)')
ax1.set_title('LIPM - Center of Mass Position')
ax1.legend()
ax1.grid(True)

# 质心速度
ax2.plot(time, x_dot, 'g-', linewidth=2)
ax2.set_xlabel('Time (s)')
ax2.set_ylabel('Velocity (m/s)')
ax2.set_title('LIPM - Center of Mass Velocity')
ax2.grid(True)

plt.tight_layout()
plt.show()