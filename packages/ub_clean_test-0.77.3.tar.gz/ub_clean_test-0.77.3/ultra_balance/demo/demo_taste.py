from ultra_balance.perception.taste import TastePerception

# 创建味觉感知器
tp = TastePerception()

print("=" * 50)
print("味觉感知演示")
print("=" * 50)

tests = [
    "甜",
    "很甜",
    "微辣",
    "太咸",
    "非常苦",
    "有点酸",
    "再甜一点",
    "再辣一点",
    "淡一点",
]

print("\n[味道理解]")
for t in tests:
    result = tp.understand(t)
    print(f"  {t} → {result}")

print("\n[味道状态]")
tp.set_taste_intensity('甜', 2)
tp.set_taste_intensity('酸', 4)
tp.set_taste_intensity('辣', 6)
tp.set_taste_intensity('咸', 8)
print(f"  当前味道: {tp.get_taste_status()}")
print(f"  建议: {tp.suggest_action()}")