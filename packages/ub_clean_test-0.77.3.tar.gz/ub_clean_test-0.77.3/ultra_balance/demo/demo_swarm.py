from ultra_balance.reasoning.swarm import SwarmIntelligence, RobotRole


def main():
    print("\n" + "🐝" * 20)
    print("  ub-clean-test 0.67.0 多机器人协作模块演示")
    print("🐝" * 20)
    
    swarm = SwarmIntelligence()
    
    # 1. 注册机器人
    print("\n" + "=" * 50)
    print(" 🤖 机器人注册")
    print("=" * 50)
    
    swarm.register_robot("robot_5", "清洁机器人C", RobotRole.WORKER, ["清洁", "导航"])
    swarm.register_robot("robot_6", "巡逻机器人", RobotRole.SCOUT, ["巡逻", "侦察"])
    
    for rid, robot in swarm.robots.items():
        print(f"  {robot.name} ({robot.role.value}) - 能力: {robot.capabilities}")
    
    # 2. 添加任务
    print("\n" + "=" * 50)
    print(" 📋 任务分配")
    print("=" * 50)
    
    task1 = swarm.add_task("搬运货物到仓库", ["搬运", "导航"], priority=8)
    print(f"  任务1: {task1} - 搬运货物到仓库")
    
    task2 = swarm.add_task("侦察前方区域", ["侦察", "拍照"], priority=6)
    print(f"  任务2: {task2} - 侦察前方区域")
    
    task3 = swarm.add_task("清洁大厅", ["清洁"], priority=5)
    print(f"  任务3: {task3} - 清洁大厅")
    
    # 3. 查看任务分配结果
    print("\n" + "=" * 50)
    print(" 📊 任务分配结果")
    print("=" * 50)
    
    for task in swarm.tasks.values():
        if task.assigned_to:
            robot = swarm.robots.get(task.assigned_to)
            print(f"  {task.description} → {robot.name if robot else '未知'}")
    
    # 4. 完成任务
    print("\n" + "=" * 50)
    print(" ✅ 完成任务")
    print("=" * 50)
    
    for task in swarm.tasks.values():
        if task.assigned_to:
            swarm.complete_task(task.id, success=True)
            print(f"  完成: {task.description}")
    
    # 5. 消息通信
    print("\n" + "=" * 50)
    print(" 💬 消息通信")
    print("=" * 50)
    
    swarm.send_message("robot_1", "robot_2", "需要支援", "request")
    swarm.send_message("robot_1", "all", "注意前方有障碍物", "warning")
    
    messages = swarm.get_messages("robot_2", limit=5)
    for msg in messages:
        print(f"  robot_2 收到来自 {msg['from']}: {msg['content']}")
    
    # 6. 协作决策
    print("\n" + "=" * 50)
    print(" 🗳️ 协作决策")
    print("=" * 50)
    
    decision = swarm.collaborative_decision("如何快速清理仓库", {})
    print(f"  问题: 如何快速清理仓库")
    print(f"  决策: {decision['decision']}")
    print(f"  置信度: {decision['confidence']:.0%}")
    print(f"  投票详情: {decision['votes']}")
    
    # 7. 负载均衡
    print("\n" + "=" * 50)
    print(" ⚖️ 负载均衡")
    print("=" * 50)
    
    rebalance = swarm.rebalance_tasks()
    print(f"  重新分配任务数: {rebalance['reassigned']}")
    
    # 8. 状态同步
    print("\n" + "=" * 50)
    print(" 📡 状态同步")
    print("=" * 50)
    
    status = swarm.sync_status()
    print(f"  总机器人: {status['total_robots']}")
    print(f"  领导者: {status['leader_id']}")
    for robot in status['robots']:
        print(f"    {robot['name']}: {robot['status']}, 电量{robot['battery']:.0f}%")
    
    # 9. 任务分解
    print("\n" + "=" * 50)
    print(" 🔨 任务分解")
    print("=" * 50)
    
    subtasks = swarm.decompose_task("从仓库搬运货物到二楼")
    print(f"  复杂任务: 从仓库搬运货物到二楼")
    print(f"  分解为 {len(subtasks)} 个子任务:")
    for i, sub in enumerate(subtasks, 1):
        print(f"    {i}. {sub['description']} (需要: {sub['capabilities']})")
    
    # 10. 心跳检测
    print("\n" + "=" * 50)
    print(" 💓 心跳检测")
    print("=" * 50)
    
    for rid in swarm.robots.keys():
        swarm.heartbeat(rid)
    
    offline = swarm.check_health()
    print(f"  在线机器人: {len(swarm.robots) - len(offline)}/{len(swarm.robots)}")
    
    # 11. 统计报告
    print("\n" + "=" * 50)
    print(" 📊 协作统计")
    print("=" * 50)
    
    stats = swarm.get_statistics()
    print(f"  总机器人: {stats['total_robots']}")
    print(f"  活跃机器人: {stats['active_robots']}")
    print(f"  繁忙机器人: {stats['busy_robots']}")
    print(f"  总任务数: {stats['total_tasks']}")
    print(f"  完成任务: {stats['completed_tasks']}")
    print(f"  总消息数: {stats['total_messages']}")
    print(f"  平均电量: {stats['avg_battery']:.0f}%")
    
    print("\n" + "✅" * 20)
    print("  所有多机器人协作演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()