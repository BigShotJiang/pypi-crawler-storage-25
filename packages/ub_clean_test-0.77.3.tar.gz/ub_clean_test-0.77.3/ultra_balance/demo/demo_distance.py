from ultra_balance.perception.distance import DistancePerception

# 创建距离感知器
dp = DistancePerception()

print("=" * 50)
print("距离感知演示")
print("=" * 50)

tests = [
    "很近",
    "近",
    "有点远",
    "远",
    "很远",
    "5米",
    "10厘米",
    "1公里",
    "往前一点",
    "再往前",
    "后退一点",
]

print("\n[距离理解]")
for t in tests:
    result = dp.understand(t)
    print(f"  {t} → {result}")

print("\n[距离判断]")
distances = [0.5, 1.0, 2.0, 5.0, 10.0, 20.0]
for d in distances:
    near = dp.is_near(d)
    far = dp.is_far(d)
    status = ""
    if near:
        status = "很近"
    elif far:
        status = "很远"
    else:
        status = "中等"
    print(f"  {d}米 → {status}")