from ultra_balance.reasoning.transfer_learning import TransferLearning


def main():
    print("\n" + "🔄" * 20)
    print("  ub-clean-test 0.65.0 迁移学习模块演示")
    print("🔄" * 20)
    
    tl = TransferLearning()
    
    # 1. 记录经验
    print("\n" + "=" * 50)
    print(" 📝 记录经验")
    print("=" * 50)
    
    exp_id1 = tl.record_experience(
        task="去超市买菜",
        domain="购物",
        solution="列清单 → 去超市 → 按清单选购 → 结账",
        steps=["列清单", "去超市", "选购", "结账"],
        success=True,
        context={"预算": 100},
        confidence=0.85
    )
    print(f"  记录经验1: {exp_id1}")
    
    exp_id2 = tl.record_experience(
        task="做番茄炒蛋",
        domain="做饭",
        solution="准备食材 → 切番茄打蛋 → 炒 → 调味",
        steps=["准备", "切配", "炒制", "调味"],
        success=True,
        context={"人数": 2},
        confidence=0.9
    )
    print(f"  记录经验2: {exp_id2}")
    
    # 2. 查找相似经验
    print("\n" + "=" * 50)
    print(" 🔍 查找相似经验")
    print("=" * 50)
    
    similar = tl.find_similar_experiences("去商场购物", "购物", threshold=0.3)
    print(f"  当前任务: 去商场购物")
    print(f"  找到 {len(similar)} 个相似经验:")
    for s in similar[:3]:
        print(f"    - {s['task']} (相似度 {s['similarity']:.0%})")
    
    # 3. 知识迁移
    print("\n" + "=" * 50)
    print(" 🔄 知识迁移")
    print("=" * 50)
    
    # 先记录一个导航经验
    tl.record_experience(
        task="导航到火车站",
        domain="导航",
        solution="打开地图 → 输入火车站 → 规划路线 → 开始导航",
        steps=["打开地图", "输入目的地", "规划路线", "开始导航"],
        success=True,
        confidence=0.9
    )
    
    result = tl.transfer_knowledge(
        source_task="导航到火车站",
        target_task="导航到商场",
        source_domain="导航",
        target_domain="购物"
    )
    print(f"  源任务: 导航到火车站 (导航)")
    print(f"  目标任务: 导航到商场 (购物)")
    print(f"  迁移方案: {result['transferred_solution'][:50]}...")
    print(f"  置信度: {result['confidence']:.0%}")
    print(f"  说明: {result['explanation']}")
    
    # 4. 类比推理
    print("\n" + "=" * 50)
    print(" 🧠 类比推理")
    print("=" * 50)
    
    analogy = tl.analogical_reasoning("如何做红烧肉", "做饭")
    print(f"  问题: 如何做红烧肉")
    if analogy['analogy_found']:
        print(f"  类比来源: {analogy['source_problem']} ({analogy['source_domain']})")
        print(f"  相似度: {analogy['similarity']:.0%}")
        print(f"  参考方案: {analogy['solution'][:50]}...")
    
    # 5. 泛化经验
    print("\n" + "=" * 50)
    print(" 📊 泛化经验")
    print("=" * 50)
    
    # 收集两个经验ID
    exp_ids = [exp_id1, exp_id2]
    generalized = tl.generalize_experience(exp_ids)
    if generalized['generalized_rule']:
        print(f"  泛化规则: {generalized['generalized_rule']}")
        print(f"  共同步骤: {generalized['common_steps']}")
        print(f"  置信度: {generalized['confidence']:.0%}")
    
    # 6. 迁移建议
    print("\n" + "=" * 50)
    print(" 💡 迁移建议")
    print("=" * 50)
    
    suggestions = tl.suggest_transfer("购物", "去超市买菜")
    print(f"  当前领域: 购物")
    print(f"  建议从以下领域迁移:")
    for s in suggestions['suggestions'][:3]:
        print(f"    - {s['source_domain']} (相似度 {s['similarity']:.0%})")
        print(f"      示例: {s['example_task']}")
    
    # 7. 领域相似度学习
    print("\n" + "=" * 50)
    print(" 📖 学习领域相似度")
    print("=" * 50)
    
    tl.learn_domain_similarity("编程", "调试", 0.85)
    print(f"  学习: 编程 ↔ 调试 相似度 85%")
    
    # 验证
    sim = tl.domain_similarity.get("编程", {}).get("调试", 0)
    print(f"  验证相似度: {sim:.0%}")
    
    # 8. 统计报告
    print("\n" + "=" * 50)
    print(" 📈 迁移学习统计")
    print("=" * 50)
    
    stats = tl.get_statistics()
    print(f"  总经验数: {stats['total_experiences']}")
    print(f"  成功经验: {stats['successful_experiences']}")
    print(f"  成功率: {stats['success_rate']:.0%}")
    print(f"  迁移规则数: {stats['total_transfer_rules']}")
    print(f"  迁移次数: {stats['total_transfers']}")
    print(f"  领域列表: {', '.join(stats['domains'][:5])}...")
    
    print("\n" + "✅" * 20)
    print("  所有迁移学习演示跑通！")
    print("✅" * 20)


if __name__ == "__main__":
    main()