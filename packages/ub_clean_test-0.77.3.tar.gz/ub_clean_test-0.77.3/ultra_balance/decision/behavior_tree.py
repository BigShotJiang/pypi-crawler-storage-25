import time
import json
from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass, field
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class NodeStatus(Enum):
    """节点执行状态"""
    SUCCESS = "success"
    FAILURE = "failure"
    RUNNING = "running"
    IDLE = "idle"


class Blackboard:
    """
    黑板 - 行为树节点间共享数据
    
    用于存储任务执行过程中的临时数据，
    如目标位置、当前状态、错误信息等。
    """
    
    def __init__(self):
        self._data: Dict[str, Any] = {}
        self._history: List[Dict[str, Any]] = []
    
    def set(self, key: str, value: Any):
        """设置值"""
        self._data[key] = value
        logger.debug(f"黑板设置: {key} = {value}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取值"""
        return self._data.get(key, default)
    
    def has(self, key: str) -> bool:
        """检查键是否存在"""
        return key in self._data
    
    def delete(self, key: str):
        """删除键"""
        if key in self._data:
            del self._data[key]
    
    def clear(self):
        """清空所有数据"""
        self._data.clear()
    
    def snapshot(self) -> Dict[str, Any]:
        """保存快照"""
        snapshot = self._data.copy()
        self._history.append(snapshot)
        return snapshot
    
    def restore(self, snapshot: Dict[str, Any]):
        """恢复快照"""
        self._data = snapshot.copy()
    
    def to_dict(self) -> Dict[str, Any]:
        """导出为字典"""
        return self._data.copy()
    
    def __repr__(self) -> str:
        return f"Blackboard({self._data})"


class Node:
    """
    行为树节点基类
    
    所有行为树节点都必须继承此类，并实现 tick 方法。
    """
    
    def __init__(self, name: str = None):
        self.name = name or self.__class__.__name__
        self.status = NodeStatus.IDLE
        self.parent: Optional['Node'] = None
        self.blackboard: Optional[Blackboard] = None
    
    def tick(self) -> NodeStatus:
        """
        执行节点逻辑
        
        Returns:
            NodeStatus: 执行状态
        """
        raise NotImplementedError("子类必须实现 tick 方法")
    
    def reset(self):
        """重置节点状态"""
        self.status = NodeStatus.IDLE
    
    def set_blackboard(self, blackboard: Blackboard):
        """设置黑板"""
        self.blackboard = blackboard
    
    def to_dict(self) -> Dict[str, Any]:
        """导出为字典（用于序列化）"""
        return {
            'type': self.__class__.__name__,
            'name': self.name,
            'status': self.status.value
        }
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name}, status={self.status.value})"


class CompositeNode(Node):
    """
    组合节点基类
    
    包含多个子节点的节点。
    """
    
    def __init__(self, children: List[Node] = None, name: str = None):
        super().__init__(name)
        self.children = children or []
        for child in self.children:
            child.parent = self
        self._current_index = 0
    
    def add_child(self, child: Node):
        """添加子节点"""
        child.parent = self
        self.children.append(child)
    
    def remove_child(self, child: Node):
        """移除子节点"""
        if child in self.children:
            self.children.remove(child)
            child.parent = None
    
    def set_blackboard(self, blackboard: Blackboard):
        """递归设置黑板"""
        super().set_blackboard(blackboard)
        for child in self.children:
            child.set_blackboard(blackboard)
    
    def reset(self):
        """重置所有子节点"""
        super().reset()
        self._current_index = 0
        for child in self.children:
            child.reset()
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data['children'] = [c.to_dict() for c in self.children]
        return data


class Sequence(CompositeNode):
    """
    顺序节点
    
    按顺序执行子节点：
    - 如果子节点返回 SUCCESS，继续执行下一个
    - 如果子节点返回 FAILURE，立即返回 FAILURE
    - 如果子节点返回 RUNNING，保存位置并返回 RUNNING
    - 所有子节点返回 SUCCESS，则返回 SUCCESS
    """
    
    def tick(self) -> NodeStatus:
        logger.debug(f"Sequence '{self.name}' 开始执行，当前索引: {self._current_index}")
        
        while self._current_index < len(self.children):
            child = self.children[self._current_index]
            
            # 如果子节点是 IDLE，先执行
            if child.status == NodeStatus.IDLE:
                logger.debug(f"  执行子节点: {child.name}")
            
            status = child.tick()
            child.status = status
            
            if status == NodeStatus.FAILURE:
                self.status = NodeStatus.FAILURE
                logger.debug(f"Sequence '{self.name}' 失败于子节点: {child.name}")
                return self.status
            
            elif status == NodeStatus.RUNNING:
                self.status = NodeStatus.RUNNING
                logger.debug(f"Sequence '{self.name}' 运行中于子节点: {child.name}")
                return self.status
            
            elif status == NodeStatus.SUCCESS:
                self._current_index += 1
                continue
        
        # 所有子节点都成功
        self.status = NodeStatus.SUCCESS
        logger.debug(f"Sequence '{self.name}' 成功完成")
        return self.status


class Selector(CompositeNode):
    """
    选择节点（或门）
    
    按顺序执行子节点：
    - 如果子节点返回 SUCCESS，立即返回 SUCCESS
    - 如果子节点返回 FAILURE，继续执行下一个
    - 如果子节点返回 RUNNING，保存位置并返回 RUNNING
    - 所有子节点返回 FAILURE，则返回 FAILURE
    """
    
    def tick(self) -> NodeStatus:
        logger.debug(f"Selector '{self.name}' 开始执行，当前索引: {self._current_index}")
        
        while self._current_index < len(self.children):
            child = self.children[self._current_index]
            
            status = child.tick()
            child.status = status
            
            if status == NodeStatus.SUCCESS:
                self.status = NodeStatus.SUCCESS
                logger.debug(f"Selector '{self.name}' 成功于子节点: {child.name}")
                return self.status
            
            elif status == NodeStatus.RUNNING:
                self.status = NodeStatus.RUNNING
                logger.debug(f"Selector '{self.name}' 运行中于子节点: {child.name}")
                return self.status
            
            elif status == NodeStatus.FAILURE:
                self._current_index += 1
                continue
        
        # 所有子节点都失败
        self.status = NodeStatus.FAILURE
        logger.debug(f"Selector '{self.name}' 所有子节点失败")
        return self.status


class Parallel(CompositeNode):
    """
    并行节点
    
    同时执行所有子节点：
    - 可配置成功条件：全部成功 / 任意成功 / 指定数量成功
    - 可配置失败条件：任意失败 / 全部失败
    
    策略：
    - success_policy: "all" | "any" | number
    - failure_policy: "any" | "all"
    """
    
    def __init__(self, children: List[Node] = None, name: str = None,
                 success_policy: Union[str, int] = "all",
                 failure_policy: str = "any"):
        super().__init__(children, name)
        self.success_policy = success_policy
        self.failure_policy = failure_policy
    
    def tick(self) -> NodeStatus:
        logger.debug(f"Parallel '{self.name}' 开始执行")
        
        success_count = 0
        failure_count = 0
        running_count = 0
        
        for child in self.children:
            status = child.tick()
            child.status = status
            
            if status == NodeStatus.SUCCESS:
                success_count += 1
            elif status == NodeStatus.FAILURE:
                failure_count += 1
            elif status == NodeStatus.RUNNING:
                running_count += 1
        
        # 检查失败条件
        if self.failure_policy == "any" and failure_count > 0:
            self.status = NodeStatus.FAILURE
            logger.debug(f"Parallel '{self.name}' 失败（任意失败）")
            return self.status
        elif self.failure_policy == "all" and failure_count == len(self.children):
            self.status = NodeStatus.FAILURE
            logger.debug(f"Parallel '{self.name}' 失败（全部失败）")
            return self.status
        
        # 检查成功条件
        if self.success_policy == "all" and success_count == len(self.children):
            self.status = NodeStatus.SUCCESS
            logger.debug(f"Parallel '{self.name}' 成功（全部成功）")
            return self.status
        elif self.success_policy == "any" and success_count > 0:
            self.status = NodeStatus.SUCCESS
            logger.debug(f"Parallel '{self.name}' 成功（任意成功）")
            return self.status
        elif isinstance(self.success_policy, int) and success_count >= self.success_policy:
            self.status = NodeStatus.SUCCESS
            logger.debug(f"Parallel '{self.name}' 成功（{success_count}>={self.success_policy}）")
            return self.status
        
        # 仍在运行
        self.status = NodeStatus.RUNNING
        return self.status
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data['success_policy'] = self.success_policy
        data['failure_policy'] = self.failure_policy
        return data


class DecoratorNode(Node):
    """
    装饰节点基类
    
    包含单个子节点，用于修改子节点的行为。
    """
    
    def __init__(self, child: Node = None, name: str = None):
        super().__init__(name)
        self.child = child
        if child:
            child.parent = self
    
    def set_child(self, child: Node):
        """设置子节点"""
        self.child = child
        child.parent = self
    
    def set_blackboard(self, blackboard: Blackboard):
        """递归设置黑板"""
        super().set_blackboard(blackboard)
        if self.child:
            self.child.set_blackboard(blackboard)
    
    def reset(self):
        """重置子节点"""
        super().reset()
        if self.child:
            self.child.reset()
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        if self.child:
            data['child'] = self.child.to_dict()
        return data


class Inverter(DecoratorNode):
    """
    取反节点
    
    将子节点的 SUCCESS 变为 FAILURE，FAILURE 变为 SUCCESS，
    RUNNING 保持不变。
    """
    
    def tick(self) -> NodeStatus:
        if not self.child:
            self.status = NodeStatus.FAILURE
            return self.status
        
        status = self.child.tick()
        self.child.status = status
        
        if status == NodeStatus.SUCCESS:
            self.status = NodeStatus.FAILURE
        elif status == NodeStatus.FAILURE:
            self.status = NodeStatus.SUCCESS
        else:
            self.status = status
        
        return self.status


class Repeater(DecoratorNode):
    """
    重复节点
    
    重复执行子节点指定次数或无限次。
    
    参数：
    - max_loops: 最大循环次数（-1 表示无限循环）
    - until_success: True 表示直到成功才停止
    - until_failure: True 表示直到失败才停止
    """
    
    def __init__(self, child: Node = None, name: str = None,
                 max_loops: int = -1,
                 until_success: bool = False,
                 until_failure: bool = False):
        super().__init__(child, name)
        self.max_loops = max_loops
        self.until_success = until_success
        self.until_failure = until_failure
        self._loop_count = 0
    
    def tick(self) -> NodeStatus:
        if not self.child:
            self.status = NodeStatus.FAILURE
            return self.status
        
        while self.max_loops == -1 or self._loop_count < self.max_loops:
            status = self.child.tick()
            self.child.status = status
            self._loop_count += 1
            
            if self.until_success and status == NodeStatus.SUCCESS:
                self.status = NodeStatus.SUCCESS
                return self.status
            
            if self.until_failure and status == NodeStatus.FAILURE:
                self.status = NodeStatus.FAILURE
                return self.status
            
            if status == NodeStatus.RUNNING:
                self.status = NodeStatus.RUNNING
                return self.status
            
            # 重置子节点以便下次循环
            self.child.reset()
        
        # 达到最大循环次数
        self.status = NodeStatus.SUCCESS if not self.until_failure else NodeStatus.FAILURE
        return self.status
    
    def reset(self):
        super().reset()
        self._loop_count = 0
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data['max_loops'] = self.max_loops
        data['until_success'] = self.until_success
        data['until_failure'] = self.until_failure
        data['loop_count'] = self._loop_count
        return data


class Condition(Node):
    """
    条件节点
    
    检查某个条件是否满足，满足返回 SUCCESS，否则返回 FAILURE。
    
    条件可以是：
    - 函数：lambda bb: bb.get("has_pillow")
    - 字符串：从黑板读取键值
    - 字典：比较黑板中的多个值
    """
    
    def __init__(self, condition: Union[str, Callable, Dict], name: str = None):
        super().__init__(name)
        self.condition = condition
    
    def tick(self) -> NodeStatus:
        if self.blackboard is None:
            self.status = NodeStatus.FAILURE
            return self.status
        
        result = False
        
        if callable(self.condition):
            # 函数条件
            result = self.condition(self.blackboard)
        elif isinstance(self.condition, str):
            # 字符串条件：检查黑板中该键是否为 True
            result = bool(self.blackboard.get(self.condition, False))
        elif isinstance(self.condition, dict):
            # 字典条件：检查多个键值是否匹配
            result = True
            for key, expected in self.condition.items():
                actual = self.blackboard.get(key)
                if actual != expected:
                    result = False
                    break
        
        self.status = NodeStatus.SUCCESS if result else NodeStatus.FAILURE
        logger.debug(f"Condition '{self.name}' 结果: {self.status.value}")
        return self.status
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data['condition'] = str(self.condition) if callable(self.condition) else self.condition
        return data


class Action(Node):
    """
    动作节点
    
    执行具体的动作，动作可以是：
    - 函数：lambda bb: do_something(bb)
    - 字符串：预定义的动作名称
    
    动作函数应返回 NodeStatus 或布尔值。
    """
    
    def __init__(self, action: Union[str, Callable], name: str = None):
        super().__init__(name)
        self.action = action
        self._action_callbacks: Dict[str, Callable] = {}
    
    def register_callback(self, name: str, callback: Callable):
        """注册动作回调"""
        self._action_callbacks[name] = callback
    
    def tick(self) -> NodeStatus:
        logger.debug(f"Action '{self.name}' 开始执行")
        
        if callable(self.action):
            # 函数动作
            result = self.action(self.blackboard)
        elif isinstance(self.action, str) and self.action in self._action_callbacks:
            # 注册的回调
            result = self._action_callbacks[self.action](self.blackboard)
        else:
            # 默认：从黑板读取动作参数
            logger.warning(f"Action '{self.name}' 未找到对应的回调: {self.action}")
            result = False
        
        if isinstance(result, NodeStatus):
            self.status = result
        elif isinstance(result, bool):
            self.status = NodeStatus.SUCCESS if result else NodeStatus.FAILURE
        else:
            self.status = NodeStatus.SUCCESS if result else NodeStatus.FAILURE
        
        logger.debug(f"Action '{self.name}' 结果: {self.status.value}")
        return self.status
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data['action'] = str(self.action) if callable(self.action) else self.action
        return data


class BehaviorTree:
    """
    行为树
    
    管理行为树的执行、重置、序列化。
    """
    
    def __init__(self, root: Node = None, name: str = "BehaviorTree"):
        self.name = name
        self.root = root
        self.blackboard = Blackboard()
        
        if root:
            root.set_blackboard(self.blackboard)
        
        self._tick_count = 0
        self._last_tick_time: Optional[float] = None
    
    def tick(self) -> NodeStatus:
        """
        执行一次行为树
        
        Returns:
            NodeStatus: 根节点的执行状态
        """
        if self.root is None:
            logger.error("行为树根节点为空")
            return NodeStatus.FAILURE
        
        self._tick_count += 1
        self._last_tick_time = time.time()
        
        logger.debug(f"行为树 '{self.name}' 第 {self._tick_count} 次 tick")
        
        status = self.root.tick()
        self.root.status = status
        
        return status
    
    def tick_until_done(self, max_ticks: int = 1000) -> NodeStatus:
        """
        执行行为树直到完成
        
        Args:
            max_ticks: 最大执行次数（防止死循环）
            
        Returns:
            NodeStatus: 最终状态
        """
        for _ in range(max_ticks):
            status = self.tick()
            if status != NodeStatus.RUNNING:
                return status
        
        logger.warning(f"行为树达到最大执行次数 {max_ticks}，强制停止")
        return NodeStatus.RUNNING
    
    def reset(self):
        """重置行为树"""
        self._tick_count = 0
        if self.root:
            self.root.reset()
        logger.debug(f"行为树 '{self.name}' 已重置")
    
    def set_blackboard_value(self, key: str, value: Any):
        """设置黑板值"""
        self.blackboard.set(key, value)
    
    def get_blackboard_value(self, key: str, default: Any = None) -> Any:
        """获取黑板值"""
        return self.blackboard.get(key, default)
    
    def to_dict(self) -> Dict[str, Any]:
        """导出为字典"""
        return {
            'name': self.name,
            'tick_count': self._tick_count,
            'blackboard': self.blackboard.to_dict(),
            'root': self.root.to_dict() if self.root else None
        }
    
    def to_json(self) -> str:
        """导出为 JSON 字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, default=str)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BehaviorTree':
        """从字典恢复（简化版，实际需要递归构建节点）"""
        # 注：完整反序列化需要根据 type 字段动态构建节点
        # 这里提供一个基础框架
        tree = cls(name=data.get('name', 'BehaviorTree'))
        # 恢复黑板数据
        for key, value in data.get('blackboard', {}).items():
            tree.blackboard.set(key, value)
        return tree
    
    def __repr__(self) -> str:
        return f"BehaviorTree(name={self.name}, ticks={self._tick_count})"


# ========== 预定义动作回调 ==========

class RobotActions:
    """
    机器人常用动作回调集合
    
    用于注册到 Action 节点中。
    """
    
    def __init__(self):
        self.callbacks: Dict[str, Callable] = {}
        self._register_defaults()
    
    def _register_defaults(self):
        """注册默认动作"""
        self.callbacks['log'] = self._log
        self.callbacks['wait'] = self._wait
        self.callbacks['set_flag'] = self._set_flag
        self.callbacks['clear_flag'] = self._clear_flag
    
    def _log(self, bb: Blackboard) -> bool:
        """日志动作"""
        message = bb.get('log_message', 'Action executed')
        level = bb.get('log_level', 'info')
        getattr(logger, level, logger.info)(message)
        return True
    
    def _wait(self, bb: Blackboard) -> NodeStatus:
        """等待动作"""
        duration = bb.get('wait_duration', 1.0)
        start_time = bb.get('_wait_start', None)
        
        if start_time is None:
            bb.set('_wait_start', time.time())
            return NodeStatus.RUNNING
        
        elapsed = time.time() - start_time
        if elapsed >= duration:
            bb.delete('_wait_start')
            return NodeStatus.SUCCESS
        
        return NodeStatus.RUNNING
    
    def _set_flag(self, bb: Blackboard) -> bool:
        """设置标志"""
        flag_name = bb.get('flag_name', 'flag')
        bb.set(flag_name, True)
        return True
    
    def _clear_flag(self, bb: Blackboard) -> bool:
        """清除标志"""
        flag_name = bb.get('flag_name', 'flag')
        bb.delete(flag_name)
        return True
    
    def register(self, name: str, callback: Callable):
        """注册自定义动作"""
        self.callbacks[name] = callback
    
    def get(self, name: str) -> Optional[Callable]:
        """获取动作回调"""
        return self.callbacks.get(name)


# ========== 行为树构建器 ==========

class BehaviorTreeBuilder:
    """
    行为树构建器
    
    提供流式 API 构建行为树。
    
    使用示例：
        tree = (BehaviorTreeBuilder("捡枕头")
                .selector()
                    .sequence()
                        .condition("pillow_detected")
                        .action("move_to_pillow")
                        .action("grasp_pillow")
                        .action("move_to_target")
                        .action("release_pillow")
                    .end()
                    .action("search_pillow")
                .end()
                .build())
    """
    
    def __init__(self, name: str = "BehaviorTree"):
        self.name = name
        self._stack: List[Node] = []
        self._root: Optional[Node] = None
    
    def _push(self, node: Node) -> 'BehaviorTreeBuilder':
        if self._stack:
            parent = self._stack[-1]
            if isinstance(parent, CompositeNode):
                parent.add_child(node)
            elif isinstance(parent, DecoratorNode):
                parent.set_child(node)
        else:
            self._root = node
        self._stack.append(node)
        return self
    
    def _pop(self) -> 'BehaviorTreeBuilder':
        if self._stack:
            self._stack.pop()
        return self
    
    def sequence(self, name: str = None) -> 'BehaviorTreeBuilder':
        """添加顺序节点"""
        return self._push(Sequence(name=name))
    
    def selector(self, name: str = None) -> 'BehaviorTreeBuilder':
        """添加选择节点"""
        return self._push(Selector(name=name))
    
    def parallel(self, name: str = None, success_policy: str = "all", failure_policy: str = "any") -> 'BehaviorTreeBuilder':
        """添加并行节点"""
        return self._push(Parallel(name=name, success_policy=success_policy, failure_policy=failure_policy))
    
    def inverter(self, name: str = None) -> 'BehaviorTreeBuilder':
        """添加取反节点"""
        return self._push(Inverter(name=name))
    
    def repeater(self, max_loops: int = -1, name: str = None) -> 'BehaviorTreeBuilder':
        """添加重复节点"""
        return self._push(Repeater(name=name, max_loops=max_loops))
    
    def condition(self, condition: Union[str, Callable, Dict], name: str = None) -> 'BehaviorTreeBuilder':
        """添加条件节点"""
        self._push(Condition(condition, name=name))
        return self._pop()
    
    def action(self, action: Union[str, Callable], name: str = None) -> 'BehaviorTreeBuilder':
        """添加动作节点"""
        self._push(Action(action, name=name))
        return self._pop()
    
    def end(self) -> 'BehaviorTreeBuilder':
        """结束当前复合节点"""
        return self._pop()
    
    def build(self) -> BehaviorTree:
        """构建行为树"""
        if self._root is None:
            raise ValueError("行为树没有根节点")
        return BehaviorTree(self._root, self.name)


# ========== 示例：构建捡枕头行为树 ==========

def create_pickup_pillow_tree() -> BehaviorTree:
    """
    创建捡枕头行为树
    
    结构：
        Selector（选择器）
        ├── Sequence（主流程）
        │   ├── Condition：是否检测到枕头
        │   ├── Action：移动到枕头
        │   ├── Action：抓取枕头
        │   ├── Action：移动到目标位置
        │   └── Action：释放枕头
        └── Action：搜索枕头
    """
    return (BehaviorTreeBuilder("捡枕头任务")
            .selector("任务选择")
                .sequence("主流程")
                    .condition("pillow_detected", "检测枕头")
                    .action("move_to_pillow", "移动到枕头")
                    .action("grasp_pillow", "抓取枕头")
                    .action("move_to_target", "移动到目标")
                    .action("release_pillow", "释放枕头")
                .end()
                .action("search_pillow", "搜索枕头")
            .end()
            .build())
