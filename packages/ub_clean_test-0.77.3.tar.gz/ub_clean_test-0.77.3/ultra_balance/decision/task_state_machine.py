import time
import json
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging

from .behavior_tree import BehaviorTree, NodeStatus, Blackboard

logger = logging.getLogger(__name__)


class TaskState(Enum):
    """任务状态"""
    IDLE = "idle"               # 空闲
    RUNNING = "running"         # 运行中
    PAUSED = "paused"           # 暂停
    COMPLETED = "completed"     # 完成
    FAILED = "failed"           # 失败
    RECOVERING = "recovering"   # 恢复中


class TaskStatus(Enum):
    """任务执行结果"""
    SUCCESS = "success"
    FAILURE = "failure"
    RUNNING = "running"


@dataclass
class TaskSnapshot:
    """任务快照"""
    task_id: str
    state: TaskState
    blackboard_data: Dict[str, Any]
    behavior_tree_state: Dict[str, Any]
    retry_count: int
    elapsed_time: float
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'task_id': self.task_id,
            'state': self.state.value,
            'blackboard_data': self.blackboard_data,
            'behavior_tree_state': self.behavior_tree_state,
            'retry_count': self.retry_count,
            'elapsed_time': self.elapsed_time,
            'timestamp': self.timestamp
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


@dataclass
class Task:
    """
    任务定义
    
    Attributes:
        name: 任务名称
        behavior_tree: 行为树
        max_retries: 最大重试次数
        timeout: 超时时间（秒），0 表示无限制
        on_success: 成功回调
        on_failure: 失败回调
        on_retry: 重试回调
    """
    name: str
    behavior_tree: BehaviorTree
    max_retries: int = 3
    timeout: float = 0.0
    on_success: Optional[Callable] = None
    on_failure: Optional[Callable] = None
    on_retry: Optional[Callable] = None
    
    def __post_init__(self):
        self.id = f"{self.name}_{int(time.time() * 1000)}"


class TaskStateMachine:
    """
    任务状态机
    
    管理任务的生命周期：启动、暂停、恢复、重试、完成。
    """
    
    def __init__(self):
        self._current_task: Optional[Task] = None
        self._state: TaskState = TaskState.IDLE
        self._retry_count: int = 0
        self._start_time: Optional[float] = None
        self._pause_time: Optional[float] = None
        self._total_paused_time: float = 0.0
        
        self._snapshots: List[TaskSnapshot] = []
        self._history: List[Dict[str, Any]] = []
    
    @property
    def state(self) -> TaskState:
        """当前状态"""
        return self._state
    
    @property
    def current_task(self) -> Optional[Task]:
        """当前任务"""
        return self._current_task
    
    @property
    def retry_count(self) -> int:
        """当前重试次数"""
        return self._retry_count
    
    @property
    def elapsed_time(self) -> float:
        """已用时间（秒）"""
        if self._start_time is None:
            return 0.0
        
        if self._state == TaskState.PAUSED:
            return self._pause_time - self._start_time - self._total_paused_time
        
        return time.time() - self._start_time - self._total_paused_time
    
    def start_task(self, task: Task) -> bool:
        """
        启动任务
        
        Args:
            task: 任务对象
            
        Returns:
            是否成功启动
        """
        if self._state not in [TaskState.IDLE, TaskState.COMPLETED, TaskState.FAILED]:
            logger.warning(f"无法启动任务，当前状态: {self._state.value}")
            return False
        
        self._current_task = task
        self._state = TaskState.RUNNING
        self._retry_count = 0
        self._start_time = time.time()
        self._total_paused_time = 0.0
        
        # 重置行为树
        task.behavior_tree.reset()
        
        # 初始化黑板数据
        task.behavior_tree.set_blackboard_value('task_id', task.id)
        task.behavior_tree.set_blackboard_value('task_name', task.name)
        task.behavior_tree.set_blackboard_value('retry_count', 0)
        
        self._log_event('start', {'task': task.name, 'task_id': task.id})
        logger.info(f"任务启动: {task.name} (ID: {task.id})")
        
        return True
    
    def tick(self) -> TaskStatus:
        """
        执行一次任务
        
        Returns:
            TaskStatus: 本次执行结果
        """
        if self._state != TaskState.RUNNING:
            return TaskStatus.FAILURE
        
        if self._current_task is None:
            self._state = TaskState.FAILED
            return TaskStatus.FAILURE
        
        task = self._current_task
        
        # 检查超时
        if task.timeout > 0 and self.elapsed_time > task.timeout:
            logger.warning(f"任务超时: {task.name}, 已用时间: {self.elapsed_time:.2f}s")
            self._handle_failure("timeout")
            return TaskStatus.FAILURE
        
        # 执行行为树
        bt_status = task.behavior_tree.tick()
        
        if bt_status == NodeStatus.SUCCESS:
            self._handle_success()
            return TaskStatus.SUCCESS
        
        elif bt_status == NodeStatus.FAILURE:
            self._handle_failure("behavior_tree_failure")
            return TaskStatus.FAILURE
        
        else:
            return TaskStatus.RUNNING
    
    def run_until_done(self, max_ticks: int = 1000) -> TaskStatus:
        """
        运行任务直到完成
        
        Args:
            max_ticks: 最大执行次数
            
        Returns:
            TaskStatus: 最终状态
        """
        for _ in range(max_ticks):
            status = self.tick()
            if status != TaskStatus.RUNNING:
                return status
            
            # 如果是暂停状态，等待
            while self._state == TaskState.PAUSED:
                time.sleep(0.1)
        
        logger.warning(f"达到最大执行次数 {max_ticks}")
        return TaskStatus.RUNNING
    
    def pause(self) -> bool:
        """
        暂停任务
        
        Returns:
            是否成功暂停
        """
        if self._state != TaskState.RUNNING:
            logger.warning(f"无法暂停，当前状态: {self._state.value}")
            return False
        
        self._state = TaskState.PAUSED
        self._pause_time = time.time()
        
        self._log_event('pause', {'elapsed': self.elapsed_time})
        logger.info(f"任务暂停: {self._current_task.name}")
        
        return True
    
    def resume(self) -> bool:
        """
        恢复任务
        
        Returns:
            是否成功恢复
        """
        if self._state != TaskState.PAUSED:
            logger.warning(f"无法恢复，当前状态: {self._state.value}")
            return False
        
        self._state = TaskState.RUNNING
        if self._pause_time:
            self._total_paused_time += time.time() - self._pause_time
            self._pause_time = None
        
        self._log_event('resume', {'elapsed': self.elapsed_time})
        logger.info(f"任务恢复: {self._current_task.name}")
        
        return True
    
    def retry(self) -> bool:
        """
        重试任务
        
        Returns:
            是否成功重试
        """
        if self._current_task is None:
            return False
        
        if self._retry_count >= self._current_task.max_retries:
            logger.warning(f"已达到最大重试次数: {self._current_task.max_retries}")
            self._state = TaskState.FAILED
            return False
        
        self._retry_count += 1
        self._state = TaskState.RECOVERING
        
        # 重置行为树
        self._current_task.behavior_tree.reset()
        
        # 更新重试计数
        self._current_task.behavior_tree.set_blackboard_value('retry_count', self._retry_count)
        
        # 调用重试回调
        if self._current_task.on_retry:
            self._current_task.on_retry(self)
        
        self._state = TaskState.RUNNING
        
        self._log_event('retry', {'retry_count': self._retry_count})
        logger.info(f"任务重试: {self._current_task.name} (第 {self._retry_count} 次)")
        
        return True
    
    def save_snapshot(self) -> TaskSnapshot:
        """
        保存任务快照
        
        Returns:
            TaskSnapshot: 快照对象
        """
        if self._current_task is None:
            raise ValueError("没有当前任务")
        
        snapshot = TaskSnapshot(
            task_id=self._current_task.id,
            state=self._state,
            blackboard_data=self._current_task.behavior_tree.blackboard.to_dict(),
            behavior_tree_state=self._current_task.behavior_tree.to_dict(),
            retry_count=self._retry_count,
            elapsed_time=self.elapsed_time
        )
        
        self._snapshots.append(snapshot)
        logger.debug(f"保存快照: {snapshot.task_id} at {snapshot.elapsed_time:.2f}s")
        
        return snapshot
    
    def restore_snapshot(self, snapshot: TaskSnapshot) -> bool:
        """
        从快照恢复任务
        
        Args:
            snapshot: 快照对象
            
        Returns:
            是否成功恢复
        """
        if self._current_task is None:
            logger.error("没有当前任务")
            return False
        
        if snapshot.task_id != self._current_task.id:
            logger.error(f"快照任务 ID 不匹配: {snapshot.task_id} != {self._current_task.id}")
            return False
        
        # 恢复状态
        self._state = snapshot.state
        self._retry_count = snapshot.retry_count
        
        # 恢复黑板数据
        for key, value in snapshot.blackboard_data.items():
            self._current_task.behavior_tree.blackboard.set(key, value)
        
        self._log_event('restore', {'snapshot': snapshot.to_dict()})
        logger.info(f"从快照恢复: {snapshot.task_id}")
        
        return True
    
    def get_latest_snapshot(self) -> Optional[TaskSnapshot]:
        """获取最新的快照"""
        return self._snapshots[-1] if self._snapshots else None
    
    def cancel(self):
        """取消任务"""
        if self._current_task:
            self._log_event('cancel', {'task': self._current_task.name})
            logger.info(f"任务取消: {self._current_task.name}")
        
        self._state = TaskState.IDLE
        self._current_task = None
        self._retry_count = 0
        self._start_time = None
    
    def reset(self):
        """重置状态机"""
        self.cancel()
        self._snapshots.clear()
        self._history.clear()
        self._total_paused_time = 0.0
    
    def is_completed(self) -> bool:
        """任务是否已完成"""
        return self._state == TaskState.COMPLETED
    
    def is_failed(self) -> bool:
        """任务是否已失败"""
        return self._state == TaskState.FAILED
    
    def is_running(self) -> bool:
        """任务是否在运行中"""
        return self._state == TaskState.RUNNING
    
    def is_paused(self) -> bool:
        """任务是否已暂停"""
        return self._state == TaskState.PAUSED
    
    def _handle_success(self):
        """处理任务成功"""
        if self._current_task is None:
            return
        
        self._state = TaskState.COMPLETED
        
        self._log_event('success', {
            'task': self._current_task.name,
            'elapsed': self.elapsed_time,
            'retries': self._retry_count
        })
        
        if self._current_task.on_success:
            self._current_task.on_success(self)
        
        logger.info(f"任务成功: {self._current_task.name} (耗时: {self.elapsed_time:.2f}s)")
    
    def _handle_failure(self, reason: str):
        """处理任务失败"""
        if self._current_task is None:
            return
        
        self._log_event('failure', {
            'task': self._current_task.name,
            'reason': reason,
            'retry_count': self._retry_count
        })
        
        logger.warning(f"任务失败: {self._current_task.name}, 原因: {reason}")
        
        # 尝试重试
        if self.retry():
            return
        
        # 无法重试，标记为失败
        self._state = TaskState.FAILED
        
        if self._current_task.on_failure:
            self._current_task.on_failure(self)
        
        logger.error(f"任务最终失败: {self._current_task.name}")
    
    def _log_event(self, event: str, data: Dict[str, Any]):
        """记录事件"""
        self._history.append({
            'event': event,
            'timestamp': time.time(),
            'data': data
        })
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            'state': self._state.value,
            'current_task': self._current_task.name if self._current_task else None,
            'retry_count': self._retry_count,
            'elapsed_time': self.elapsed_time,
            'snapshots_count': len(self._snapshots),
            'history_count': len(self._history)
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """导出为字典"""
        return {
            'state': self._state.value,
            'current_task': self._current_task.name if self._current_task else None,
            'retry_count': self._retry_count,
            'elapsed_time': self.elapsed_time,
            'snapshots': [s.to_dict() for s in self._snapshots],
            'history': self._history
        }
