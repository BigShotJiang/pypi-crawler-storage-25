from enum import Enum, auto
from typing import Dict, Optional, List, Any
from dataclasses import dataclass, field
import time
import logging

logger = logging.getLogger(__name__)


class SafetyLevel(Enum):
    """安全等级"""
    NORMAL = 0        # 正常运行
    DERATED = 1       # 降额运行
    PAUSED = 2        # 暂停等待
    EMERGENCY = 3     # 紧急停止（需人工复位）


class SafetyTrigger(Enum):
    """安全触发源"""
    NONE = auto()
    THERMAL = auto()
    POWER = auto()
    HEARTBEAT = auto()
    STALL = auto()
    MANUAL = auto()


@dataclass
class SafetyConfig:
    """安全配置"""
    # 降额参数
    derating_torque_factor: float = 0.7   # 降额时力矩系数
    derating_velocity_factor: float = 0.5  # 降额时速度系数
    
    # 暂停参数
    paused_torque_factor: float = 0.1     # 暂停时力矩系数
    paused_velocity_factor: float = 0.0   # 暂停时速度系数
    
    # 紧急停止参数
    emergency_torque_factor: float = 0.0
    emergency_velocity_factor: float = 0.0
    
    # 恢复参数
    recovery_cooldown_time: float = 5.0   # 恢复冷却时间 (s)
    max_auto_recovery_attempts: int = 3   # 最大自动恢复次数
    
    # 力矩/速度绝对限制
    max_torque: float = 50.0              # 最大力矩 (Nm)
    max_velocity: float = 10.0            # 最大速度 (rad/s)


class SafetyGuard:
    """
    统一安全守护器
    
    整合热监控、电量监控、心跳监控和堵转检测，
    提供统一的安全状态机和指令修正。
    """
    
    def __init__(self,
                 name: str = "default",
                 config: Optional[SafetyConfig] = None,
                 **kwargs):
        """
        初始化安全守护器
        
        Args:
            name: 守护器名称
            config: 安全配置
            **kwargs: 覆盖配置
        """
        self.name = name
        
        if config is None:
            config = SafetyConfig(**kwargs)
        elif kwargs:
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        
        self.config = config
        
        # 子监控器
        self.thermal_monitor = None
        self.power_monitor = None
        self.heartbeat_monitor = None
        self.stall_detector = None
        
        # 关节限制
        self.torque_limits: Dict[str, float] = {}
        self.velocity_limits: Dict[str, float] = {}
        
        # 当前状态
        self.safety_level = SafetyLevel.NORMAL
        self.trigger_source = SafetyTrigger.NONE
        self.trigger_details: Dict[str, Any] = {}
        
        # 历史
        self.level_history: List[tuple] = []
        self.last_level_change_time = time.time()
        
        # 恢复状态
        self.recovery_attempts = 0
        self.emergency_latch = False  # 紧急停止锁存
        
        logger.info(f"安全守护器 {name} 初始化")
    
    def attach_thermal_monitor(self, monitor):
        """附加热监控器"""
        self.thermal_monitor = monitor
        logger.info(f"安全守护器 {self.name} 已附加热监控器")
    
    def attach_power_monitor(self, monitor):
        """附加电量监控器"""
        self.power_monitor = monitor
        logger.info(f"安全守护器 {self.name} 已附加电量监控器")
    
    def attach_heartbeat_monitor(self, monitor):
        """附加心跳监控器"""
        self.heartbeat_monitor = monitor
        logger.info(f"安全守护器 {self.name} 已附加心跳监控器")
    
    def attach_stall_detector(self, detector):
        """附加堵转检测器"""
        self.stall_detector = detector
        logger.info(f"安全守护器 {self.name} 已附加堵转检测器")
    
    def set_joint_limits(self, 
                         torque_limits: Dict[str, float],
                         velocity_limits: Dict[str, float]):
        """设置关节限制"""
        self.torque_limits = torque_limits
        self.velocity_limits = velocity_limits
    
    def evaluate_safety_level(self) -> SafetyLevel:
        """
        评估当前安全等级
        
        优先级：EMERGENCY > PAUSED > DERATED > NORMAL
        """
        # 检查紧急停止锁存
        if self.emergency_latch:
            return SafetyLevel.EMERGENCY
        
        # 检查各监控器状态
        level = SafetyLevel.NORMAL
        trigger = SafetyTrigger.NONE
        details = {}
        
        # 1. 堵转检测（最高优先级）
        if self.stall_detector:
            if hasattr(self.stall_detector, 'any_emergency'):
                if self.stall_detector.any_emergency:
                    level = SafetyLevel.EMERGENCY
                    trigger = SafetyTrigger.STALL
                    details['stall'] = self.stall_detector.get_emergency_joints()
            elif self.stall_detector.is_emergency:
                level = SafetyLevel.EMERGENCY
                trigger = SafetyTrigger.STALL
        
        # 2. 心跳检测
        if level.value < SafetyLevel.EMERGENCY.value and self.heartbeat_monitor:
            if hasattr(self.heartbeat_monitor, 'get_any_lost'):
                if self.heartbeat_monitor.get_any_lost():
                    level = SafetyLevel.EMERGENCY
                    trigger = SafetyTrigger.HEARTBEAT
            elif self.heartbeat_monitor.connection_lost:
                level = SafetyLevel.EMERGENCY
                trigger = SafetyTrigger.HEARTBEAT
        
        # 3. 电量监控
        if level.value < SafetyLevel.EMERGENCY.value and self.power_monitor:
            if self.power_monitor.emergency_battery:
                level = SafetyLevel.PAUSED
                trigger = SafetyTrigger.POWER
                details['power'] = self.power_monitor.soc
        
        # 4. 热监控
        if level.value < SafetyLevel.PAUSED.value and self.thermal_monitor:
            if hasattr(self.thermal_monitor, 'any_overheat'):
                if self.thermal_monitor.any_overheat:
                    level = SafetyLevel.PAUSED
                    trigger = SafetyTrigger.THERMAL
                    details['thermal'] = self.thermal_monitor.get_overheat_joints()
            elif self.thermal_monitor.is_overheat:
                level = SafetyLevel.PAUSED
                trigger = SafetyTrigger.THERMAL
        
        # 5. 降额检查
        if level.value == SafetyLevel.NORMAL.value:
            min_derating = self._get_min_derating()
            if min_derating < 0.5:
                level = SafetyLevel.DERATED
            elif min_derating < 1.0:
                level = SafetyLevel.DERATED
        
        # 更新状态
        if level != self.safety_level:
            self._transition_to(level, trigger, details)
        
        return self.safety_level
    
    def _get_min_derating(self) -> float:
        """获取最小降额因子"""
        factors = [1.0]
        
        if self.thermal_monitor:
            if hasattr(self.thermal_monitor, 'min_derating_factor'):
                factors.append(self.thermal_monitor.min_derating_factor)
            else:
                factors.append(self.thermal_monitor.derating_factor)
        
        if self.power_monitor:
            factors.append(self.power_monitor.derating_factor)
        
        if self.heartbeat_monitor:
            if hasattr(self.heartbeat_monitor, 'min_derating_factor'):
                factors.append(self.heartbeat_monitor.min_derating_factor)
            else:
                factors.append(self.heartbeat_monitor.derating_factor)
        
        if self.stall_detector:
            if hasattr(self.stall_detector, 'min_derating_factor'):
                factors.append(self.stall_detector.min_derating_factor)
            else:
                factors.append(self.stall_detector.derating_factor)
        
        return min(factors)
    
    def _transition_to(self, 
                       new_level: SafetyLevel, 
                       trigger: SafetyTrigger,
                       details: dict):
        """状态转换"""
        old_level = self.safety_level
        self.safety_level = new_level
        self.trigger_source = trigger
        self.trigger_details = details
        self.last_level_change_time = time.time()
        
        self.level_history.append((time.time(), old_level, new_level, trigger))
        
        # 紧急停止需要锁存
        if new_level == SafetyLevel.EMERGENCY:
            self.emergency_latch = True
        
        # 日志
        if new_level.value > old_level.value:
            logger.warning(f"安全守护器 {self.name}: {old_level.name} -> {new_level.name} "
                         f"(触发: {trigger.name}, 详情: {details})")
        else:
            logger.info(f"安全守护器 {self.name}: {old_level.name} -> {new_level.name}")
    
    def check_command(self,
                      torques: Dict[str, float],
                      velocities: Dict[str, float]) -> tuple:
        """
        检查并修正控制指令
        
        Args:
            torques: 期望力矩 {joint: torque}
            velocities: 期望速度 {joint: velocity}
            
        Returns:
            (修正后力矩, 修正后速度, 安全等级, 状态消息)
        """
        # 更新安全等级
        self.evaluate_safety_level()
        
        cfg = self.config
        
        # 根据安全等级确定修正系数
        if self.safety_level == SafetyLevel.EMERGENCY:
            torque_factor = cfg.emergency_torque_factor
            velocity_factor = cfg.emergency_velocity_factor
        elif self.safety_level == SafetyLevel.PAUSED:
            torque_factor = cfg.paused_torque_factor
            velocity_factor = cfg.paused_velocity_factor
        elif self.safety_level == SafetyLevel.DERATED:
            torque_factor = cfg.derating_torque_factor
            velocity_factor = cfg.derating_velocity_factor
        else:
            torque_factor = 1.0
            velocity_factor = 1.0
        
        # 结合各监控器的降额因子
        min_derating = self._get_min_derating()
        torque_factor = min(torque_factor, min_derating)
        velocity_factor = min(velocity_factor, min_derating)
        
        # 修正指令
        safe_torques = {}
        safe_velocities = {}
        
        for joint, t in torques.items():
            # 应用降额
            t_safe = t * torque_factor
            
            # 应用绝对限制
            limit = self.torque_limits.get(joint, cfg.max_torque)
            t_safe = max(-limit, min(limit, t_safe))
            
            safe_torques[joint] = t_safe
        
        for joint, v in velocities.items():
            v_safe = v * velocity_factor
            limit = self.velocity_limits.get(joint, cfg.max_velocity)
            v_safe = max(-limit, min(limit, v_safe))
            safe_velocities[joint] = v_safe
        
        return safe_torques, safe_velocities, self.safety_level, self.get_status_message()
    
    def get_status_message(self) -> str:
        """获取状态消息"""
        messages = {
            SafetyLevel.NORMAL: "系统正常运行",
            SafetyLevel.DERATED: "降额运行中，请检查系统状态",
            SafetyLevel.PAUSED: "暂停等待中，系统正在恢复",
            SafetyLevel.EMERGENCY: "紧急停止！需人工检查后复位"
        }
        
        base_msg = messages.get(self.safety_level, "未知状态")
        
        if self.trigger_details:
            base_msg += f" (触发: {self.trigger_details})"
        
        return base_msg
    
    def manual_reset(self) -> bool:
        """
        手动复位
        
        Returns:
            True 表示复位成功
        """
        # 检查是否可以复位
        if self.safety_level == SafetyLevel.EMERGENCY:
            # 检查紧急条件是否解除
            can_reset = True
            
            if self.stall_detector:
                if hasattr(self.stall_detector, 'any_emergency'):
                    if self.stall_detector.any_emergency:
                        can_reset = False
                elif self.stall_detector.is_emergency:
                    can_reset = False
            
            if self.heartbeat_monitor:
                if hasattr(self.heartbeat_monitor, 'get_any_lost'):
                    if self.heartbeat_monitor.get_any_lost():
                        can_reset = False
                elif self.heartbeat_monitor.connection_lost:
                    can_reset = False
            
            if can_reset:
                self.emergency_latch = False
                self.safety_level = SafetyLevel.NORMAL
                self.trigger_source = SafetyTrigger.NONE
                self.trigger_details = {}
                self.recovery_attempts = 0
                logger.info(f"安全守护器 {self.name} 手动复位成功")
                return True
            else:
                logger.warning(f"安全守护器 {self.name} 手动复位失败：紧急条件未解除")
                return False
        
        return True
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        stats = {
            'name': self.name,
            'safety_level': self.safety_level.name,
            'trigger_source': self.trigger_source.name,
            'trigger_details': self.trigger_details,
            'min_derating_factor': self._get_min_derating(),
            'emergency_latch': self.emergency_latch,
            'recovery_attempts': self.recovery_attempts,
            'time_in_current_level': time.time() - self.last_level_change_time
        }
        
        # 附加子监控器统计
        if self.thermal_monitor:
            if hasattr(self.thermal_monitor, 'get_all_statistics'):
                stats['thermal'] = self.thermal_monitor.get_all_statistics()
        
        if self.power_monitor:
            stats['power'] = self.power_monitor.get_statistics()
        
        if self.heartbeat_monitor:
            if hasattr(self.heartbeat_monitor, 'get_all_statistics'):
                stats['heartbeat'] = self.heartbeat_monitor.get_all_statistics()
        
        if self.stall_detector:
            if hasattr(self.stall_detector, 'get_all_statistics'):
                stats['stall'] = self.stall_detector.get_all_statistics()
        
        return stats
    
    def __repr__(self) -> str:
        return f"SafetyGuard(name={self.name}, level={self.safety_level.name})"
