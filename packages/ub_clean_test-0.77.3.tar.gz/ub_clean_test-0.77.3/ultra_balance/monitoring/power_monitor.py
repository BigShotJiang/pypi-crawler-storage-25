import time
import math
from typing import Optional, List, Tuple
from dataclasses import dataclass
from collections import deque
import logging

logger = logging.getLogger(__name__)


@dataclass
class BatteryConfig:
    """电池配置参数"""
    capacity_mah: float = 10000.0     # 额定容量 (mAh)
    nominal_voltage: float = 24.0     # 额定电压 (V)
    full_voltage: float = 25.2        # 满电电压 (V)
    empty_voltage: float = 20.0       # 空电电压 (V)
    
    # 低电量阈值
    low_battery_soc: float = 0.20     # 低电量 SOC 阈值
    critical_battery_soc: float = 0.10  # 临界电量 SOC 阈值
    emergency_battery_soc: float = 0.05  # 紧急电量 SOC 阈值
    
    # 库仑计参数
    coulomb_efficiency: float = 0.98  # 库仑效率
    
    # 电压修正参数
    voltage_filter_alpha: float = 0.1 # 电压低通滤波系数


class PowerMonitor:
    """
    电池电量监控器
    
    使用库仑计（电流积分）为主，电压修正为辅的方式估算 SOC。
    """
    
    def __init__(self, config: Optional[BatteryConfig] = None, **kwargs):
        """
        初始化电量监控器
        
        Args:
            config: 电池配置
            **kwargs: 覆盖配置参数
        """
        if config is None:
            config = BatteryConfig(**kwargs)
        elif kwargs:
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        
        self.config = config
        
        # 容量转换：mAh -> As (库仑)
        self.capacity_coulomb = config.capacity_mah * 3.6  # 1mAh = 3.6C
        
        # 当前状态
        self.soc = 1.0                     # State of Charge (0-1)
        self.voltage = config.nominal_voltage
        self.filtered_voltage = config.nominal_voltage
        self.current = 0.0
        self.power = 0.0
        
        # 累计统计
        self.total_energy_consumed = 0.0   # 总耗能 (J)
        self.total_charge_consumed = 0.0   # 总耗电量 (C)
        
        # 历史记录
        self.voltage_history = deque(maxlen=100)
        self.current_history = deque(maxlen=100)
        self.power_history = deque(maxlen=100)
        self.soc_history = deque(maxlen=100)
        
        # 时间记录
        self.start_time = time.time()
        self.last_update_time = self.start_time
        
        # 状态标志
        self.low_battery = False
        self.critical_battery = False
        self.emergency_battery = False
        
        # 功率预测
        self.avg_power = 0.0
        
        logger.info(f"电量监控初始化: "
                   f"容量={config.capacity_mah:.0f}mAh, "
                   f"额定电压={config.nominal_voltage:.1f}V")
    
    def update(self, 
               voltage: float, 
               current: float, 
               dt: Optional[float] = None) -> float:
        """
        更新电量状态
        
        Args:
            voltage: 当前电压 (V)
            current: 当前电流 (A)，正值表示放电
            dt: 时间步长 (s)
            
        Returns:
            当前 SOC (0-1)
        """
        now = time.time()
        if dt is None:
            dt = now - self.last_update_time
            dt = min(dt, 0.5)  # 限制最大步长
        
        if dt <= 0:
            return self.soc
        
        self.voltage = voltage
        self.current = current
        self.power = voltage * current
        
        # 电压滤波
        alpha = self.config.voltage_filter_alpha
        self.filtered_voltage = alpha * voltage + (1 - alpha) * self.filtered_voltage
        
        # 库仑计更新
        charge_consumed = current * dt * self.config.coulomb_efficiency
        self.total_charge_consumed += charge_consumed
        self.total_energy_consumed += self.power * dt
        
        # 基于库仑计的 SOC
        soc_coulomb = max(0.0, 1.0 - self.total_charge_consumed / self.capacity_coulomb)
        
        # 基于电压的 SOC（线性插值）
        cfg = self.config
        voltage_range = cfg.full_voltage - cfg.empty_voltage
        if voltage_range > 0:
            soc_voltage = (self.filtered_voltage - cfg.empty_voltage) / voltage_range
            soc_voltage = max(0.0, min(1.0, soc_voltage))
        else:
            soc_voltage = 0.5
        
        # 融合 SOC（库仑计为主，电压修正为辅）
        # 电压修正权重随 SOC 降低而增加
        voltage_weight = 0.1 + 0.3 * (1.0 - soc_coulomb)
        self.soc = (1.0 - voltage_weight) * soc_coulomb + voltage_weight * soc_voltage
        self.soc = max(0.0, min(1.0, self.soc))
        
        # 更新平均功率（指数移动平均）
        power_alpha = 0.05
        self.avg_power = power_alpha * self.power + (1.0 - power_alpha) * self.avg_power
        
        # 更新状态标志
        self.low_battery = self.soc <= cfg.low_battery_soc
        self.critical_battery = self.soc <= cfg.critical_battery_soc
        self.emergency_battery = self.soc <= cfg.emergency_battery_soc
        
        # 记录历史
        self.voltage_history.append(voltage)
        self.current_history.append(current)
        self.power_history.append(self.power)
        self.soc_history.append(self.soc)
        
        self.last_update_time = now
        
        # 日志（状态变化时）
        if self.critical_battery and not getattr(self, '_last_critical', False):
            logger.warning(f"临界电量！SOC={self.soc*100:.1f}%")
        if self.emergency_battery and not getattr(self, '_last_emergency', False):
            logger.error(f"紧急电量！SOC={self.soc*100:.1f}%，即将关机")
        
        setattr(self, '_last_critical', self.critical_battery)
        setattr(self, '_last_emergency', self.emergency_battery)
        
        return self.soc
    
    @property
    def remaining_capacity_mah(self) -> float:
        """剩余容量 (mAh)"""
        return self.soc * self.config.capacity_mah
    
    @property
    def remaining_energy_joules(self) -> float:
        """剩余能量 (J)"""
        return self.soc * self.capacity_coulomb * self.config.nominal_voltage
    
    @property
    def remaining_time(self) -> Optional[float]:
        """
        预估剩余运行时间 (s)
        
        基于当前平均功率估算，如果功率为0则返回无限大
        """
        if self.avg_power <= 0.01:
            return float('inf')
        return self.remaining_energy_joules / self.avg_power
    
    @property
    def derating_factor(self) -> float:
        """
        基于电量的降额因子
        
        - SOC > 20%: 1.0
        - SOC 10%-20%: 线性降额 0.5-1.0
        - SOC 5%-10%: 线性降额 0.1-0.5
        - SOC < 5%: 0.0
        """
        cfg = self.config
        
        if self.soc >= cfg.low_battery_soc:
            return 1.0
        elif self.soc >= cfg.critical_battery_soc:
            # 20% -> 10%: 1.0 -> 0.5
            ratio = (self.soc - cfg.critical_battery_soc) / (cfg.low_battery_soc - cfg.critical_battery_soc)
            return 0.5 + 0.5 * ratio
        elif self.soc >= cfg.emergency_battery_soc:
            # 10% -> 5%: 0.5 -> 0.1
            ratio = (self.soc - cfg.emergency_battery_soc) / (cfg.critical_battery_soc - cfg.emergency_battery_soc)
            return 0.1 + 0.4 * ratio
        else:
            return 0.0
    
    @property
    def status(self) -> str:
        """状态字符串"""
        if self.emergency_battery:
            return "EMERGENCY"
        elif self.critical_battery:
            return "CRITICAL"
        elif self.low_battery:
            return "LOW"
        else:
            return "NORMAL"
    
    def predict_soc(self, 
                    future_power: float, 
                    duration: float) -> float:
        """
        预测未来 SOC
        
        Args:
            future_power: 预期功率 (W)
            duration: 持续时间 (s)
            
        Returns:
            预测 SOC
        """
        energy_consumed = future_power * duration
        soc_delta = energy_consumed / (self.capacity_coulomb * self.config.nominal_voltage)
        return max(0.0, self.soc - soc_delta)
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        remaining = self.remaining_time
        return {
            'soc': self.soc,
            'soc_percent': self.soc * 100,
            'voltage': self.voltage,
            'filtered_voltage': self.filtered_voltage,
            'current': self.current,
            'power': self.power,
            'avg_power': self.avg_power,
            'remaining_capacity_mah': self.remaining_capacity_mah,
            'remaining_time': remaining if remaining != float('inf') else None,
            'status': self.status,
            'derating_factor': self.derating_factor,
            'total_energy_consumed': self.total_energy_consumed,
            'runtime': time.time() - self.start_time
        }
    
    def reset(self):
        """重置监控器（更换电池后调用）"""
        self.soc = 1.0
        self.total_charge_consumed = 0.0
        self.total_energy_consumed = 0.0
        self.low_battery = False
        self.critical_battery = False
        self.emergency_battery = False
        self.start_time = time.time()
        logger.info("电量监控已重置")
