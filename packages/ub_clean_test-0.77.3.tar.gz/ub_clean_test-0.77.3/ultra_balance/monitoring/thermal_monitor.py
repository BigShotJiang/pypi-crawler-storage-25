import time
import math
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from collections import deque
import logging

logger = logging.getLogger(__name__)


@dataclass
class ThermalConfig:
    """热模型配置参数"""
    R_th: float = 2.0          # 热阻 (K/W)
    C_th: float = 100.0        # 热容 (J/K)
    T_amb: float = 25.0        # 环境温度 (°C)
    T_max: float = 80.0        # 最高允许温度 (°C)
    T_warning: float = 65.0    # 预警温度 (°C)
    T_derating_start: float = 60.0   # 开始降额温度 (°C)
    
    # 功率损耗模型参数
    k_torque: float = 0.5      # 力矩相关损耗系数
    k_velocity: float = 0.1    # 速度相关损耗系数
    k_constant: float = 2.0    # 常数损耗 (W)
    
    # 冷却风扇参数（如果有）
    fan_enabled: bool = False
    fan_cooling_factor: float = 1.5  # 风扇开启时的散热增强倍数


class ThermalMonitor:
    """
    单关节热监控器
    
    使用一阶热模型实时估计电机温度，提供：
    - 温度预测
    - 过热预警
    - 降额因子计算
    - 温度历史记录
    """
    
    def __init__(self, 
                 joint_name: str,
                 config: Optional[ThermalConfig] = None,
                 **kwargs):
        """
        初始化热监控器
        
        Args:
            joint_name: 关节名称
            config: 热模型配置，如不提供则使用默认配置
            **kwargs: 覆盖配置参数
        """
        self.joint_name = joint_name
        
        if config is None:
            config = ThermalConfig(**kwargs)
        elif kwargs:
            # 用 kwargs 覆盖 config 中的值
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        
        self.config = config
        
        # 当前状态
        self.temperature = config.T_amb
        self.power_loss = 0.0
        self.last_update_time = time.time()
        
        # 历史记录
        self.history = deque(maxlen=1000)
        self.derating_history = deque(maxlen=100)
        
        # 统计
        self.max_temperature = config.T_amb
        self.overheat_count = 0
        self.total_energy_loss = 0.0
        
        # 状态标志
        self.is_overheat = False
        self.is_warning = False
        
        logger.info(f"关节 {joint_name} 热监控初始化: "
                   f"R_th={config.R_th:.2f}K/W, "
                   f"C_th={config.C_th:.1f}J/K, "
                   f"T_max={config.T_max:.1f}°C")
    
    def estimate_power_loss(self, torque: float, velocity: float) -> float:
        """
        估算功率损耗
        
        使用简化模型：P_loss = k_torque * torque? + k_velocity * velocity? + k_constant
        
        Args:
            torque: 关节力矩 (Nm)
            velocity: 关节角速度 (rad/s)
            
        Returns:
            估算的功率损耗 (W)
        """
        cfg = self.config
        return (cfg.k_torque * torque * torque + 
                cfg.k_velocity * abs(velocity) + 
                cfg.k_constant)
    
    def update(self, 
               torque: float, 
               velocity: float, 
               dt: Optional[float] = None) -> float:
        """
        更新温度估计
        
        Args:
            torque: 当前力矩 (Nm)
            velocity: 当前角速度 (rad/s)
            dt: 时间步长 (s)，如不提供则自动计算
            
        Returns:
            当前估计温度 (°C)
        """
        # 计算时间步长
        now = time.time()
        if dt is None:
            dt = now - self.last_update_time
            dt = min(dt, 0.1)  # 限制最大步长 100ms
        
        if dt <= 0:
            return self.temperature
        
        # 估算功率损耗
        self.power_loss = self.estimate_power_loss(torque, velocity)
        self.total_energy_loss += self.power_loss * dt
        
        # 热平衡方程
        cfg = self.config
        
        # 散热功率（考虑风扇）
        cooling_factor = cfg.fan_cooling_factor if cfg.fan_enabled else 1.0
        heat_out = cooling_factor * (self.temperature - cfg.T_amb) / cfg.R_th
        
        # 温度变化
        dT = (self.power_loss - heat_out) / cfg.C_th * dt
        
        # 更新温度
        self.temperature += dT
        
        # 环境温度下限（不会低于环境温度）
        self.temperature = max(self.temperature, cfg.T_amb)
        
        # 更新状态标志
        self.is_warning = self.temperature >= cfg.T_warning
        self.is_overheat = self.temperature >= cfg.T_max
        
        if self.is_overheat:
            self.overheat_count += 1
        
        # 更新历史
        self.max_temperature = max(self.max_temperature, self.temperature)
        self.history.append({
            'time': now,
            'temperature': self.temperature,
            'power_loss': self.power_loss,
            'torque': torque,
            'velocity': velocity
        })
        
        self.derating_history.append(self.derating_factor)
        
        self.last_update_time = now
        
        # 日志（仅在状态变化时）
        if self.is_warning and not getattr(self, '_last_warning', False):
            logger.warning(f"关节 {self.joint_name} 温度预警: {self.temperature:.1f}°C")
        if self.is_overheat and not getattr(self, '_last_overheat', False):
            logger.error(f"关节 {self.joint_name} 过热: {self.temperature:.1f}°C")
        
        setattr(self, '_last_warning', self.is_warning)
        setattr(self, '_last_overheat', self.is_overheat)
        
        return self.temperature
    
    @property
    def derating_factor(self) -> float:
        """
        降额因子
        
        返回 0-1 之间的值：
        - 1.0: 温度正常，满功率运行
        - 0.0: 过热，需停机
        
        降额曲线在 T_derating_start 到 T_max 之间线性下降
        """
        cfg = self.config
        
        if self.temperature <= cfg.T_derating_start:
            return 1.0
        elif self.temperature >= cfg.T_max:
            return 0.0
        else:
            # 线性插值
            range_temp = cfg.T_max - cfg.T_derating_start
            if range_temp <= 0:
                return 1.0
            factor = (cfg.T_max - self.temperature) / range_temp
            return max(0.0, min(1.0, factor))
    
    @property
    def is_safe(self) -> bool:
        """是否安全（未过热）"""
        return not self.is_overheat
    
    @property
    def status(self) -> str:
        """状态字符串"""
        if self.is_overheat:
            return "OVERHEAT"
        elif self.is_warning:
            return "WARNING"
        else:
            return "NORMAL"
    
    def predict_temperature(self, 
                            future_torque: float, 
                            future_velocity: float,
                            duration: float) -> float:
        """
        预测未来温度
        
        Args:
            future_torque: 预期力矩
            future_velocity: 预期速度
            duration: 持续时间 (s)
            
        Returns:
            预测温度 (°C)
        """
        future_power = self.estimate_power_loss(future_torque, future_velocity)
        cfg = self.config
        
        # 稳态温度
        T_steady = cfg.T_amb + future_power * cfg.R_th
        
        # 一阶响应
        tau = cfg.R_th * cfg.C_th
        T_pred = T_steady + (self.temperature - T_steady) * math.exp(-duration / tau)
        
        return T_pred
    
    def time_to_temperature(self, target_temp: float) -> Optional[float]:
        """
        计算到达目标温度所需时间
        
        Args:
            target_temp: 目标温度
            
        Returns:
            预计时间 (s)，如果无法到达则返回 None
        """
        if target_temp <= self.temperature:
            return 0.0
        
        cfg = self.config
        T_steady = cfg.T_amb + self.power_loss * cfg.R_th
        
        if target_temp >= T_steady:
            # 目标温度高于稳态温度，无法到达
            return None
        
        tau = cfg.R_th * cfg.C_th
        # 一阶响应反解
        try:
            ratio = (T_steady - target_temp) / (T_steady - self.temperature)
            if ratio <= 0:
                return None
            return -tau * math.log(ratio)
        except (ValueError, ZeroDivisionError):
            return None
    
    def reset(self, temperature: Optional[float] = None):
        """重置监控器"""
        self.temperature = temperature if temperature is not None else self.config.T_amb
        self.max_temperature = self.temperature
        self.overheat_count = 0
        self.total_energy_loss = 0.0
        self.history.clear()
        self.derating_history.clear()
        self.last_update_time = time.time()
        logger.info(f"关节 {self.joint_name} 热监控已重置")
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        return {
            'joint_name': self.joint_name,
            'current_temperature': self.temperature,
            'max_temperature': self.max_temperature,
            'power_loss': self.power_loss,
            'derating_factor': self.derating_factor,
            'status': self.status,
            'overheat_count': self.overheat_count,
            'total_energy_loss': self.total_energy_loss,
            'time_to_max': self.time_to_temperature(self.config.T_max)
        }


class MultiJointThermalMonitor:
    """
    多关节热监控器
    
    统一管理多个关节的热状态，提供批量更新和综合降额因子。
    """
    
    def __init__(self, joint_configs: Optional[Dict[str, ThermalConfig]] = None):
        """
        初始化多关节监控器
        
        Args:
            joint_configs: 关节配置字典 {joint_name: ThermalConfig}
        """
        self.monitors: Dict[str, ThermalMonitor] = {}
        self.joint_configs = joint_configs or {}
    
    def add_joint(self, 
                  joint_name: str, 
                  config: Optional[ThermalConfig] = None,
                  **kwargs):
        """
        添加关节
        
        Args:
            joint_name: 关节名称
            config: 热模型配置
            **kwargs: 配置参数
        """
        if config is None and joint_name in self.joint_configs:
            config = self.joint_configs[joint_name]
        
        self.monitors[joint_name] = ThermalMonitor(joint_name, config, **kwargs)
    
    def update_all(self, 
                   torques: Dict[str, float], 
                   velocities: Dict[str, float],
                   dt: Optional[float] = None) -> Dict[str, float]:
        """
        批量更新所有关节温度
        
        Args:
            torques: 各关节力矩 {joint_name: torque}
            velocities: 各关节速度 {joint_name: velocity}
            dt: 时间步长
            
        Returns:
            各关节当前温度 {joint_name: temperature}
        """
        temperatures = {}
        for name, monitor in self.monitors.items():
            torque = torques.get(name, 0.0)
            velocity = velocities.get(name, 0.0)
            temperatures[name] = monitor.update(torque, velocity, dt)
        return temperatures
    
    def get_derating_factors(self) -> Dict[str, float]:
        """获取各关节降额因子"""
        return {name: m.derating_factor for name, m in self.monitors.items()}
    
    @property
    def min_derating_factor(self) -> float:
        """最严格的降额因子（所有关节的最小值）"""
        if not self.monitors:
            return 1.0
        return min(m.derating_factor for m in self.monitors.values())
    
    @property
    def any_overheat(self) -> bool:
        """是否有任何关节过热"""
        return any(m.is_overheat for m in self.monitors.values())
    
    @property
    def any_warning(self) -> bool:
        """是否有任何关节温度预警"""
        return any(m.is_warning for m in self.monitors.values())
    
    def get_overheat_joints(self) -> List[str]:
        """获取过热关节列表"""
        return [name for name, m in self.monitors.items() if m.is_overheat]
    
    def get_warning_joints(self) -> List[str]:
        """获取预警关节列表"""
        return [name for name, m in self.monitors.items() if m.is_warning]
    
    def get_all_statistics(self) -> dict:
        """获取所有关节统计信息"""
        return {name: m.get_statistics() for name, m in self.monitors.items()}
    
    def reset_all(self):
        """重置所有监控器"""
        for monitor in self.monitors.values():
            monitor.reset()
    
    def __getitem__(self, joint_name: str) -> ThermalMonitor:
        """获取指定关节监控器"""
        return self.monitors[joint_name]
    
    def __len__(self) -> int:
        return len(self.monitors)
    
    def __contains__(self, joint_name: str) -> bool:
        return joint_name in self.monitors
