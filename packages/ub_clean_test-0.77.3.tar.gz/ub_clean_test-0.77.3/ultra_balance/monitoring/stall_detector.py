import time
from typing import Optional, List
from dataclasses import dataclass
from collections import deque
import logging

logger = logging.getLogger(__name__)


@dataclass
class StallConfig:
    """堵转检测配置"""
    # 速度阈值
    desired_velocity_threshold: float = 0.1   # 期望速度阈值 (rad/s)
    actual_velocity_threshold: float = 0.02   # 实际速度阈值 (rad/s)
    
    # 电流阈值
    current_threshold: float = 10.0           # 电流阈值 (A)
    
    # 时间阈值
    stall_time_threshold: float = 0.2         # 堵转确认时间 (s)
    emergency_time_threshold: float = 0.5     # 紧急停止时间 (s)
    
    # 恢复参数
    recovery_timeout: float = 2.0             # 恢复超时 (s)
    recovery_attempts: int = 3                # 最大恢复尝试次数


class StallDetector:
    """
    电机堵转检测器
    
    监测期望速度、实际速度和电流，判断是否发生堵转。
    """
    
    def __init__(self, 
                 joint_name: str,
                 config: Optional[StallConfig] = None,
                 **kwargs):
        """
        初始化堵转检测器
        
        Args:
            joint_name: 关节名称
            config: 配置参数
            **kwargs: 覆盖配置
        """
        self.joint_name = joint_name
        
        if config is None:
            config = StallConfig(**kwargs)
        elif kwargs:
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        
        self.config = config
        
        # 当前状态
        self.desired_velocity = 0.0
        self.actual_velocity = 0.0
        self.current = 0.0
        
        # 堵转检测状态
        self.stall_condition_active = False
        self.stall_start_time: Optional[float] = None
        self.is_stalled = False
        self.is_emergency = False
        
        # 历史记录
        self.velocity_history = deque(maxlen=50)
        self.current_history = deque(maxlen=50)
        
        # 统计
        self.stall_count = 0
        self.emergency_count = 0
        self.total_stall_duration = 0.0
        
        # 恢复状态
        self.in_recovery = False
        self.recovery_start_time: Optional[float] = None
        self.recovery_attempts = 0
        
        logger.info(f"关节 {joint_name} 堵转检测初始化: "
                   f"期望速度阈值={config.desired_velocity_threshold:.3f}rad/s, "
                   f"实际速度阈值={config.actual_velocity_threshold:.3f}rad/s, "
                   f"电流阈值={config.current_threshold:.1f}A")
    
    def update(self, 
               desired_velocity: float, 
               actual_velocity: float, 
               current: float,
               dt: Optional[float] = None) -> bool:
        """
        更新堵转检测
        
        Args:
            desired_velocity: 期望速度 (rad/s)
            actual_velocity: 实际速度 (rad/s)
            current: 当前电流 (A)
            dt: 时间步长（未使用，保留接口）
            
        Returns:
            True 表示当前处于堵转状态
        """
        now = time.time()
        
        self.desired_velocity = desired_velocity
        self.actual_velocity = actual_velocity
        self.current = current
        
        # 记录历史
        self.velocity_history.append(actual_velocity)
        self.current_history.append(current)
        
        # 检查堵转条件
        cfg = self.config
        
        desired_ok = abs(desired_velocity) > cfg.desired_velocity_threshold
        actual_low = abs(actual_velocity) < cfg.actual_velocity_threshold
        current_high = current > cfg.current_threshold
        
        stall_active = desired_ok and actual_low and current_high
        
        # 状态机
        was_stalled = self.is_stalled
        
        if stall_active:
            if self.stall_start_time is None:
                self.stall_start_time = now
            else:
                stall_duration = now - self.stall_start_time
                
                # 检查是否达到紧急停止阈值
                if stall_duration >= cfg.emergency_time_threshold:
                    if not self.is_emergency:
                        self.is_emergency = True
                        self.emergency_count += 1
                        logger.error(f"关节 {self.joint_name} 堵转紧急停止！"
                                   f"持续 {stall_duration:.3f}s")
                    
                # 检查是否确认堵转
                elif stall_duration >= cfg.stall_time_threshold:
                    if not self.is_stalled:
                        self.is_stalled = True
                        self.stall_count += 1
                        logger.warning(f"关节 {self.joint_name} 检测到堵转！"
                                     f"期望速度={desired_velocity:.3f}, "
                                     f"实际速度={actual_velocity:.3f}, "
                                     f"电流={current:.2f}A")
        else:
            # 堵转条件消失
            if self.stall_start_time is not None:
                stall_duration = now - self.stall_start_time
                self.total_stall_duration += stall_duration
            
            self.stall_start_time = None
            self.is_stalled = False
            self.is_emergency = False
            
            if was_stalled:
                logger.info(f"关节 {self.joint_name} 堵转已解除")
        
        return self.is_stalled
    
    @property
    def derating_factor(self) -> float:
        """
        基于堵转状态的降额因子
        
        - 正常: 1.0
        - 堵转确认: 0.3（限制力矩防止烧毁）
        - 紧急停止: 0.0
        """
        if self.is_emergency:
            return 0.0
        elif self.is_stalled:
            return 0.3
        else:
            return 1.0
    
    @property
    def stall_duration(self) -> float:
        """当前堵转持续时间"""
        if self.stall_start_time is None:
            return 0.0
        return time.time() - self.stall_start_time
    
    @property
    def status(self) -> str:
        """状态字符串"""
        if self.is_emergency:
            return "EMERGENCY"
        elif self.is_stalled:
            return "STALLED"
        elif self.stall_condition_active:
            return "WARNING"
        else:
            return "NORMAL"
    
    def get_recovery_action(self) -> dict:
        """
        获取恢复动作建议
        
        Returns:
            包含动作类型和参数的字典
        """
        if self.is_emergency:
            return {
                'action': 'emergency_stop',
                'description': '立即断电，需人工检查'
            }
        elif self.is_stalled:
            # 建议反向微动
            return {
                'action': 'backoff',
                'direction': -1 if self.desired_velocity > 0 else 1,
                'magnitude': 0.1,
                'description': '反向微动尝试脱困'
            }
        else:
            return {
                'action': 'none',
                'description': '正常运行'
            }
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        return {
            'joint_name': self.joint_name,
            'status': self.status,
            'is_stalled': self.is_stalled,
            'is_emergency': self.is_emergency,
            'stall_duration': self.stall_duration,
            'derating_factor': self.derating_factor,
            'stall_count': self.stall_count,
            'emergency_count': self.emergency_count,
            'total_stall_duration': self.total_stall_duration,
            'desired_velocity': self.desired_velocity,
            'actual_velocity': self.actual_velocity,
            'current': self.current
        }
    
    def reset(self):
        """重置检测器"""
        self.stall_start_time = None
        self.is_stalled = False
        self.is_emergency = False
        self.in_recovery = False
        self.recovery_start_time = None
        self.recovery_attempts = 0
        logger.info(f"关节 {self.joint_name} 堵转检测已重置")


class MultiStallDetector:
    """
    多关节堵转检测器
    """
    
    def __init__(self):
        self.detectors: dict = {}
    
    def add_joint(self, 
                  joint_name: str, 
                  config: Optional[StallConfig] = None,
                  **kwargs):
        """添加关节"""
        self.detectors[joint_name] = StallDetector(joint_name, config, **kwargs)
    
    def update_all(self,
                   desired_velocities: dict,
                   actual_velocities: dict,
                   currents: dict) -> dict:
        """
        批量更新所有关节
        
        Returns:
            各关节堵转状态 {joint_name: is_stalled}
        """
        results = {}
        for name, detector in self.detectors.items():
            desired = desired_velocities.get(name, 0.0)
            actual = actual_velocities.get(name, 0.0)
            current = currents.get(name, 0.0)
            results[name] = detector.update(desired, actual, current)
        return results
    
    @property
    def any_stalled(self) -> bool:
        """是否有任何关节堵转"""
        return any(d.is_stalled for d in self.detectors.values())
    
    @property
    def any_emergency(self) -> bool:
        """是否有任何关节紧急停止"""
        return any(d.is_emergency for d in self.detectors.values())
    
    def get_stalled_joints(self) -> List[str]:
        """获取堵转关节列表"""
        return [name for name, d in self.detectors.items() if d.is_stalled]
    
    def get_emergency_joints(self) -> List[str]:
        """获取紧急停止关节列表"""
        return [name for name, d in self.detectors.items() if d.is_emergency]
    
    @property
    def min_derating_factor(self) -> float:
        """最严格的降额因子"""
        if not self.detectors:
            return 1.0
        return min(d.derating_factor for d in self.detectors.values())
    
    def get_all_statistics(self) -> dict:
        """获取所有关节统计"""
        return {name: d.get_statistics() for name, d in self.detectors.items()}
    
    def __getitem__(self, name: str) -> StallDetector:
        return self.detectors[name]
