import time
import math
from typing import Optional, List, Tuple
from dataclasses import dataclass, field
from collections import deque
import logging

logger = logging.getLogger(__name__)


@dataclass
class HeartbeatConfig:
    """心跳配置"""
    expected_interval: float = 0.02     # 预期心跳间隔 (s)
    timeout_multiplier: float = 3.0     # 超时倍数（连续超过此时长视为断线）
    warning_delay_threshold: float = 0.05  # 延迟预警阈值 (s)
    max_packet_loss_rate: float = 0.1   # 最大丢包率
    
    # 降额参数
    derating_start_delay: float = 0.05  # 开始降额的延迟 (s)
    derating_start_loss_rate: float = 0.05  # 开始降额的丢包率
    
    # 历史窗口
    history_window_size: int = 100


class HeartbeatMonitor:
    """
    通信心跳监控器
    
    监测通信质量，提供延迟、丢包率统计和断线检测。
    """
    
    def __init__(self, 
                 name: str = "default",
                 config: Optional[HeartbeatConfig] = None,
                 **kwargs):
        """
        初始化心跳监控器
        
        Args:
            name: 监控器名称
            config: 配置参数
            **kwargs: 覆盖配置
        """
        self.name = name
        
        if config is None:
            config = HeartbeatConfig(**kwargs)
        elif kwargs:
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        
        self.config = config
        
        # 序列号管理
        self.send_seq = 0
        self.last_received_seq = -1
        
        # 时间记录
        self.last_send_time: Optional[float] = None
        self.last_receive_time: Optional[float] = None
        
        # 历史记录
        self.delay_history = deque(maxlen=config.history_window_size)
        self.loss_history = deque(maxlen=config.history_window_size)
        self.interval_history = deque(maxlen=config.history_window_size)
        
        # 统计
        self.total_sent = 0
        self.total_received = 0
        self.total_lost = 0
        
        # 当前状态
        self.current_delay: Optional[float] = None
        self.current_interval: Optional[float] = None
        self.connection_lost = False
        self.connection_warning = False
        
        # 平滑值（指数移动平均）
        self.avg_delay = 0.0
        self.avg_loss_rate = 0.0
        
        logger.info(f"心跳监控 {name} 初始化: 预期间隔={config.expected_interval*1000:.1f}ms")
    
    def send_heartbeat(self) -> int:
        """
        发送心跳
        
        Returns:
            序列号
        """
        self.send_seq += 1
        self.last_send_time = time.time()
        self.total_sent += 1
        
        return self.send_seq
    
    def receive_heartbeat(self, seq_num: int):
        """
        接收心跳
        
        Args:
            seq_num: 收到的序列号
        """
        now = time.time()
        
        # 计算延迟（如果知道发送时间）
        # 注：实际系统中延迟需要时间戳同步，这里简化处理
        
        # 检查丢包
        if self.last_received_seq >= 0:
            lost = seq_num - self.last_received_seq - 1
            if lost > 0:
                self.total_lost += lost
                self.loss_history.append(1.0)  # 标记为丢包
            else:
                self.loss_history.append(0.0)
        
        # 计算间隔
        if self.last_receive_time is not None:
            self.current_interval = now - self.last_receive_time
            self.interval_history.append(self.current_interval)
        
        self.last_received_seq = seq_num
        self.last_receive_time = now
        self.total_received += 1
        
        # 更新统计
        self._update_statistics()
        
        # 更新连接状态
        self._update_connection_status(now)
    
    def _update_statistics(self):
        """更新统计数据"""
        # 平均延迟（基于间隔估算）
        if len(self.interval_history) > 0:
            avg_interval = sum(self.interval_history) / len(self.interval_history)
            self.current_delay = max(0, avg_interval - self.config.expected_interval)
            self.delay_history.append(self.current_delay)
            
            # 指数移动平均
            alpha = 0.1
            self.avg_delay = alpha * self.current_delay + (1 - alpha) * self.avg_delay
        
        # 平均丢包率
        if len(self.loss_history) > 0:
            self.avg_loss_rate = sum(self.loss_history) / len(self.loss_history)
    
    def _update_connection_status(self, now: float):
        """更新连接状态"""
        cfg = self.config
        
        if self.last_receive_time is None:
            self.connection_lost = True
            return
        
        time_since_last = now - self.last_receive_time
        timeout_threshold = cfg.expected_interval * cfg.timeout_multiplier
        
        was_lost = self.connection_lost
        self.connection_lost = time_since_last > timeout_threshold
        self.connection_warning = (self.avg_delay > cfg.warning_delay_threshold or 
                                   self.avg_loss_rate > cfg.max_packet_loss_rate)
        
        # 状态变化日志
        if self.connection_lost and not was_lost:
            logger.error(f"心跳监控 {self.name}: 通信中断！")
        elif not self.connection_lost and was_lost:
            logger.info(f"心跳监控 {self.name}: 通信恢复")
    
    def check_connection(self) -> bool:
        """
        检查连接状态
        
        Returns:
            True 表示连接正常
        """
        self._update_connection_status(time.time())
        return not self.connection_lost
    
    @property
    def derating_factor(self) -> float:
        """
        基于通信质量的降额因子
        
        综合考虑延迟和丢包率：
        - 正常: 1.0
        - 延迟或丢包率超标: 线性降额
        - 断线: 0.0
        """
        if self.connection_lost:
            return 0.0
        
        cfg = self.config
        
        # 基于延迟的降额
        if self.avg_delay <= cfg.derating_start_delay:
            delay_factor = 1.0
        elif self.avg_delay >= cfg.warning_delay_threshold:
            delay_factor = 0.3
        else:
            range_delay = cfg.warning_delay_threshold - cfg.derating_start_delay
            if range_delay > 0:
                ratio = (self.avg_delay - cfg.derating_start_delay) / range_delay
                delay_factor = 1.0 - 0.7 * ratio
            else:
                delay_factor = 1.0
        
        # 基于丢包率的降额
        if self.avg_loss_rate <= cfg.derating_start_loss_rate:
            loss_factor = 1.0
        elif self.avg_loss_rate >= cfg.max_packet_loss_rate:
            loss_factor = 0.3
        else:
            range_loss = cfg.max_packet_loss_rate - cfg.derating_start_loss_rate
            if range_loss > 0:
                ratio = (self.avg_loss_rate - cfg.derating_start_loss_rate) / range_loss
                loss_factor = 1.0 - 0.7 * ratio
            else:
                loss_factor = 1.0
        
        return min(delay_factor, loss_factor)
    
    @property
    def status(self) -> str:
        """状态字符串"""
        if self.connection_lost:
            return "LOST"
        elif self.connection_warning:
            return "WARNING"
        else:
            return "NORMAL"
    
    @property
    def packet_loss_rate(self) -> float:
        """丢包率"""
        return self.avg_loss_rate
    
    @property
    def latency_ms(self) -> float:
        """当前延迟 (ms)"""
        return self.avg_delay * 1000 if self.avg_delay else 0.0
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        total_packets = self.total_sent
        loss_rate = self.total_lost / total_packets if total_packets > 0 else 0.0
        
        return {
            'name': self.name,
            'status': self.status,
            'connection_lost': self.connection_lost,
            'avg_delay_ms': self.latency_ms,
            'avg_loss_rate': self.avg_loss_rate,
            'derating_factor': self.derating_factor,
            'total_sent': self.total_sent,
            'total_received': self.total_received,
            'total_lost': self.total_lost,
            'overall_loss_rate': loss_rate,
            'last_receive_ago': (time.time() - self.last_receive_time) if self.last_receive_time else None
        }
    
    def reset(self):
        """重置监控器"""
        self.send_seq = 0
        self.last_received_seq = -1
        self.last_send_time = None
        self.last_receive_time = None
        self.total_sent = 0
        self.total_received = 0
        self.total_lost = 0
        self.connection_lost = False
        self.connection_warning = False
        self.avg_delay = 0.0
        self.avg_loss_rate = 0.0
        self.delay_history.clear()
        self.loss_history.clear()
        self.interval_history.clear()
        logger.info(f"心跳监控 {self.name} 已重置")


class MultiHeartbeatMonitor:
    """
    多通道心跳监控器
    
    用于监控多个通信通道（如多个执行器）
    """
    
    def __init__(self):
        self.monitors: dict = {}
    
    def add_channel(self, name: str, config: Optional[HeartbeatConfig] = None, **kwargs):
        """添加通信通道"""
        self.monitors[name] = HeartbeatMonitor(name, config, **kwargs)
    
    def send_heartbeat(self, name: str) -> int:
        """发送心跳"""
        return self.monitors[name].send_heartbeat()
    
    def receive_heartbeat(self, name: str, seq_num: int):
        """接收心跳"""
        self.monitors[name].receive_heartbeat(seq_num)
    
    def check_all(self) -> bool:
        """检查所有通道"""
        return all(m.check_connection() for m in self.monitors.values())
    
    def get_any_lost(self) -> List[str]:
        """获取断线通道列表"""
        return [name for name, m in self.monitors.items() if m.connection_lost]
    
    @property
    def min_derating_factor(self) -> float:
        """最严格的降额因子"""
        if not self.monitors:
            return 1.0
        return min(m.derating_factor for m in self.monitors.values())
    
    def get_all_statistics(self) -> dict:
        """获取所有通道统计"""
        return {name: m.get_statistics() for name, m in self.monitors.items()}
    
    def __getitem__(self, name: str) -> HeartbeatMonitor:
        return self.monitors[name]
