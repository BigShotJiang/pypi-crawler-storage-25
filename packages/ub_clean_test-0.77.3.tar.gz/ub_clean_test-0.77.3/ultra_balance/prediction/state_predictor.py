import numpy as np

class StatePredictor:
    """
    状态预测模块：根据当前状态预测未来轨迹
    让机器人能“预判”危险
    """
    
    def __init__(self, dt=0.1):
        self.dt = dt
    
    def predict_position(self, x0, v0, a0, steps=10):
        """
        预测未来位置
        x0: 初始位置
        v0: 初始速度
        a0: 初始加速度
        steps: 预测步数
        """
        positions = []
        x = x0
        v = v0
        a = a0
        
        for i in range(steps):
            v = v + a * self.dt
            x = x + v * self.dt
            positions.append(x)
        
        return positions
    
    def predict_trajectory(self, state, steps=20):
        """
        预测未来轨迹
        state: [x, y, vx, vy, ax, ay]
        """
        x, y, vx, vy, ax, ay = state
        traj_x = []
        traj_y = []
        
        for i in range(steps):
            vx = vx + ax * self.dt
            vy = vy + ay * self.dt
            x = x + vx * self.dt
            y = y + vy * self.dt
            traj_x.append(x)
            traj_y.append(y)
        
        return traj_x, traj_y
    
    def will_collide(self, state, obstacle_pos, obstacle_radius, steps=20):
        """
        预测是否会碰撞
        """
        traj_x, traj_y = self.predict_trajectory(state, steps)
        
        for i in range(len(traj_x)):
            dx = traj_x[i] - obstacle_pos[0]
            dy = traj_y[i] - obstacle_pos[1]
            dist = np.sqrt(dx**2 + dy**2)
            if dist < obstacle_radius:
                return True, i  # 会在第 i 步碰撞
        return False, -1