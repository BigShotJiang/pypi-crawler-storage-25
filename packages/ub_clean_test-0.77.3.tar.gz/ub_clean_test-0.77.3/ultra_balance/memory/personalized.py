import json
import os

class PersonalizedMemory:
    """
    个性化记忆模块：记住不同用户的信息
    """
    
    def __init__(self, memory_file='personal_memory.json'):
        self.memory_file = memory_file
        self.memory = self._load()
    
    def _load(self):
        if os.path.exists(self.memory_file):
            with open(self.memory_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save(self):
        with open(self.memory_file, 'w') as f:
            json.dump(self.memory, f, indent=2)
    
    def remember_user(self, user_id, name=None, info=None):
        """记住一个用户"""
        if user_id not in self.memory:
            self.memory[user_id] = {
                'name': name or user_id,
                'info': info or {},
                'history': []
            }
        elif name:
            self.memory[user_id]['name'] = name
        if info:
            self.memory[user_id]['info'].update(info)
        self._save()
        return f"已记住用户: {self.memory[user_id]['name']}"
    
    def get_user(self, user_id):
        """获取用户信息"""
        return self.memory.get(user_id, None)
    
    def add_interaction(self, user_id, user_said, robot_said):
        """记录一次交互"""
        if user_id not in self.memory:
            self.remember_user(user_id)
        
        self.memory[user_id]['history'].append({
            'user': user_said,
            'robot': robot_said
        })
        # 只保留最近 50 条
        if len(self.memory[user_id]['history']) > 50:
            self.memory[user_id]['history'] = self.memory[user_id]['history'][-50:]
        self._save()
    
    def greet(self, user_id):
        """根据记忆打招呼"""
        user = self.get_user(user_id)
        if not user:
            return "你好，我是新来的，你叫什么名字？"
        
        name = user.get('name', '朋友')
        history_count = len(user.get('history', []))
        
        if history_count == 0:
            return f"你好，{name}！很高兴见到你。"
        elif history_count < 5:
            return f"你好，{name}！又见面了。"
        else:
            return f"嘿，{name}！老朋友了，今天想做什么？"
    
    def recall_preference(self, user_id, key):
        """回忆用户的偏好"""
        user = self.get_user(user_id)
        if user:
            return user.get('info', {}).get(key, None)
        return None