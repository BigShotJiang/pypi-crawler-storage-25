import json
import os
import time

class LongTermMemory:
    """
    长期记忆模块：记住重要事件，重启也不丢
    """
    
    def __init__(self, memory_file='long_term_memory.json'):
        self.memory_file = memory_file
        self.memory = self._load()
    
    def _load(self):
        """加载记忆文件"""
        if os.path.exists(self.memory_file):
            with open(self.memory_file, 'r') as f:
                data = json.load(f)
                return {
                    'facts': data.get('facts', {}),
                    'events': data.get('events', []),
                    'preferences': data.get('preferences', {})
                }
        return {
            'facts': {},
            'events': [],
            'preferences': {}
        }
    
    def _save(self):
        """保存记忆"""
        with open(self.memory_file, 'w') as f:
            json.dump(self.memory, f, indent=2)
    
    def remember_fact(self, key, value):
        """记住一个事实"""
        self.memory['facts'][key] = value
        self._save()
        return f"已记住: {key} = {value}"
    
    def recall_fact(self, key):
        """回忆一个事实"""
        return self.memory['facts'].get(key, "不知道")
    
    def remember_event(self, event, importance=1):
        """记住一个重要事件"""
        event_record = {
            'event': event,
            'timestamp': time.time(),
            'importance': importance
        }
        self.memory['events'].append(event_record)
        if len(self.memory['events']) > 100:
            self.memory['events'] = self.memory['events'][-100:]
        self._save()
        return f"已记住事件: {event}"
    
    def recall_events(self, limit=10):
        """回忆最近的事件"""
        return self.memory['events'][-limit:]
    
    def remember_preference(self, user, key, value):
        """记住用户偏好"""
        if user not in self.memory['preferences']:
            self.memory['preferences'][user] = {}
        self.memory['preferences'][user][key] = value
        self._save()
        return f"已记住 {user} 的偏好: {key} = {value}"
    
    def recall_preference(self, user, key):
        """回忆用户偏好"""
        return self.memory['preferences'].get(user, {}).get(key, "不知道")