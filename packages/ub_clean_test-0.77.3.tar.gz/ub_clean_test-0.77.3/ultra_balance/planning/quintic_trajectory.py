import numpy as np
from typing import Tuple, List, Optional, Union
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class TrajectoryPoint:
    """轨迹点数据类"""
    time: float
    position: float
    velocity: float
    acceleration: float
    
    def to_dict(self) -> dict:
        return {
            'time': self.time,
            'position': self.position,
            'velocity': self.velocity,
            'acceleration': self.acceleration
        }


class QuinticTrajectory:
    """
    五次多项式轨迹生成器
    
    边界条件：起点 (p0, v0, a0)，终点 (pT, vT, aT)，总时间 T
    
    轨迹方程：
        p(t) = a0 + a1*t + a2*t? + a3*t? + a4*t? + a5*t?
        v(t) = a1 + 2*a2*t + 3*a3*t? + 4*a4*t? + 5*a5*t?
        a(t) = 2*a2 + 6*a3*t + 12*a4*t? + 20*a5*t?
    """
    
    def __init__(self, 
                 p0: float, v0: float, a0: float,
                 pT: float, vT: float, aT: float,
                 T: float):
        """
        初始化轨迹生成器
        
        Args:
            p0: 起始位置
            v0: 起始速度
            a0: 起始加速度
            pT: 终点位置
            vT: 终点速度
            aT: 终点加速度
            T: 总时间（必须 > 0）
            
        Raises:
            ValueError: 如果 T <= 0
        """
        if T <= 0:
            raise ValueError(f"时间 T 必须大于 0，当前值: {T}")
        
        self.p0 = p0
        self.v0 = v0
        self.a0 = a0
        self.pT = pT
        self.vT = vT
        self.aT = aT
        self.T = T
        
        # 计算系数
        self._compute_coefficients()
        
        logger.debug(f"五次多项式轨迹初始化: T={T:.3f}s, "
                    f"起点({p0:.3f}, {v0:.3f}, {a0:.3f}) -> "
                    f"终点({pT:.3f}, {vT:.3f}, {aT:.3f})")
    
    def _compute_coefficients(self):
        """
        计算五次多项式系数
        
        系数求解矩阵：
        [a0]   [1   0   0     0      0      0  ] [p0]
        [a1]   [0   1   0     0      0      0  ] [v0]
        [a2] = [0   0  1/2    0      0      0  ] [a0]
        [a3]   [*   *   *     *      *      *  ] [pT]
        [a4]   [*   *   *     *      *      *  ] [vT]
        [a5]   [*   *   *     *      *      *  ] [aT]
        """
        T = self.T
        T2 = T * T
        T3 = T2 * T
        T4 = T3 * T
        T5 = T4 * T
        
        # a0, a1, a2 直接由初始条件确定
        self.a0 = self.p0
        self.a1 = self.v0
        self.a2 = self.a0 / 2.0
        
        # a3, a4, a5 由终点条件求解
        # 构造线性方程组并直接给出解析解（避免矩阵求逆，提高效率）
        self.a3 = (20 * self.pT - 20 * self.p0 - 
                   (8 * self.vT + 12 * self.v0) * T - 
                   (3 * self.a0 - self.aT) * T2) / (2 * T3)
        
        self.a4 = (30 * self.p0 - 30 * self.pT + 
                   (14 * self.vT + 16 * self.v0) * T + 
                   (3 * self.a0 - 2 * self.aT) * T2) / (2 * T4)
        
        self.a5 = (12 * self.pT - 12 * self.p0 - 
                   (6 * self.vT + 6 * self.v0) * T - 
                   (self.a0 - self.aT) * T2) / (2 * T5)
        
        self._coefficients = np.array([self.a0, self.a1, self.a2, 
                                       self.a3, self.a4, self.a5])
    
    @property
    def coefficients(self) -> np.ndarray:
        """返回多项式系数 [a0, a1, a2, a3, a4, a5]"""
        return self._coefficients.copy()
    
    def position(self, t: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        """
        计算指定时刻的位置
        
        Args:
            t: 时间（0 <= t <= T）或时间数组
            
        Returns:
            位置值或位置数组
        """
        t = np.asarray(t)
        self._validate_time(t)
        
        t2 = t * t
        t3 = t2 * t
        t4 = t3 * t
        t5 = t4 * t
        
        return (self.a0 + self.a1 * t + self.a2 * t2 + 
                self.a3 * t3 + self.a4 * t4 + self.a5 * t5)
    
    def velocity(self, t: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        """
        计算指定时刻的速度
        
        Args:
            t: 时间（0 <= t <= T）或时间数组
            
        Returns:
            速度值或速度数组
        """
        t = np.asarray(t)
        self._validate_time(t)
        
        t2 = t * t
        t3 = t2 * t
        t4 = t3 * t
        
        return (self.a1 + 2 * self.a2 * t + 3 * self.a3 * t2 + 
                4 * self.a4 * t3 + 5 * self.a5 * t4)
    
    def acceleration(self, t: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        """
        计算指定时刻的加速度
        
        Args:
            t: 时间（0 <= t <= T）或时间数组
            
        Returns:
            加速度值或加速度数组
        """
        t = np.asarray(t)
        self._validate_time(t)
        
        t2 = t * t
        t3 = t2 * t
        
        return (2 * self.a2 + 6 * self.a3 * t + 
                12 * self.a4 * t2 + 20 * self.a5 * t3)
    
    def jerk(self, t: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        """
        计算指定时刻的加加速度
        
        Args:
            t: 时间（0 <= t <= T）或时间数组
            
        Returns:
            加加速度值或加加速度数组
        """
        t = np.asarray(t)
        self._validate_time(t)
        
        t2 = t * t
        
        return (6 * self.a3 + 24 * self.a4 * t + 60 * self.a5 * t2)
    
    def _validate_time(self, t: np.ndarray):
        """验证时间是否在有效范围内"""
        if np.any(t < 0) or np.any(t > self.T):
            logger.warning(f"时间超出范围 [0, {self.T}]，将被裁剪")
    
    def sample(self, num_points: int = 100) -> Tuple[np.ndarray, np.ndarray, 
                                                        np.ndarray, np.ndarray]:
        """
        采样轨迹
        
        Args:
            num_points: 采样点数
            
        Returns:
            (时间序列, 位置序列, 速度序列, 加速度序列)
        """
        t = np.linspace(0, self.T, num_points)
        return t, self.position(t), self.velocity(t), self.acceleration(t)
    
    def get_max_values(self) -> dict:
        """
        获取轨迹的极值
        
        Returns:
            包含最大速度、最大加速度、最大加加速度的字典
        """
        # 高密度采样以逼近真实极值
        t = np.linspace(0, self.T, 1000)
        vel = self.velocity(t)
        acc = self.acceleration(t)
        jerk = self.jerk(t)
        
        return {
            'max_velocity': float(np.max(np.abs(vel))),
            'max_acceleration': float(np.max(np.abs(acc))),
            'max_jerk': float(np.max(np.abs(jerk))),
            'rms_acceleration': float(np.sqrt(np.mean(acc**2)))
        }
    
    def to_trajectory_points(self, num_points: int = 100) -> List[TrajectoryPoint]:
        """
        转换为轨迹点列表
        
        Args:
            num_points: 采样点数
            
        Returns:
            TrajectoryPoint 对象列表
        """
        t, pos, vel, acc = self.sample(num_points)
        return [TrajectoryPoint(float(t[i]), float(pos[i]), 
                               float(vel[i]), float(acc[i])) 
                for i in range(num_points)]


class MultiSegmentTrajectory:
    """
    多段轨迹拼接
    
    支持将多个五次多项式轨迹段无缝拼接，保证段间位置、速度、加速度连续。
    """
    
    def __init__(self):
        self.segments: List[QuinticTrajectory] = []
        self.waypoints: List[Tuple[float, float, float]] = []
        self.segment_times: List[float] = []
    
    def add_segment(self, 
                    pT: float, vT: float, aT: float, 
                    T: float):
        """
        添加轨迹段
        
        Args:
            pT: 终点位置
            vT: 终点速度
            aT: 终点加速度
            T: 本段时长
        """
        if len(self.waypoints) == 0:
            # 第一段，起点默认为原点
            p0, v0, a0 = 0.0, 0.0, 0.0
        else:
            p0, v0, a0 = self.waypoints[-1]
        
        segment = QuinticTrajectory(p0, v0, a0, pT, vT, aT, T)
        self.segments.append(segment)
        self.waypoints.append((pT, vT, aT))
        self.segment_times.append(T)
        
        logger.debug(f"添加轨迹段 {len(self.segments)}: T={T:.3f}s, "
                    f"终点({pT:.3f}, {vT:.3f}, {aT:.3f})")
    
    def add_waypoints(self, 
                      waypoints: List[Tuple[float, float, float]], 
                      times: List[float]):
        """
        批量添加路径点
        
        Args:
            waypoints: 路径点列表，每个元素为 (位置, 速度, 加速度)
            times: 每段时长列表
            
        Raises:
            ValueError: 如果 waypoints 和 times 长度不匹配
        """
        if len(waypoints) != len(times):
            raise ValueError(f"waypoints 数量({len(waypoints)})与 "
                           f"times 数量({len(times)})不匹配")
        
        for (pT, vT, aT), T in zip(waypoints, times):
            self.add_segment(pT, vT, aT, T)
    
    def sample(self, num_points_per_segment: int = 100) -> Tuple[np.ndarray, ...]:
        """
        采样完整轨迹
        
        Args:
            num_points_per_segment: 每段采样点数
            
        Returns:
            (时间序列, 位置序列, 速度序列, 加速度序列)
        """
        all_t = []
        all_pos = []
        all_vel = []
        all_acc = []
        
        t_offset = 0.0
        
        for segment, T in zip(self.segments, self.segment_times):
            t = np.linspace(0, T, num_points_per_segment)
            pos = segment.position(t)
            vel = segment.velocity(t)
            acc = segment.acceleration(t)
            
            all_t.append(t + t_offset)
            all_pos.append(pos)
            all_vel.append(vel)
            all_acc.append(acc)
            
            t_offset += T
        
        return (np.concatenate(all_t), np.concatenate(all_pos),
                np.concatenate(all_vel), np.concatenate(all_acc))
    
    @property
    def total_time(self) -> float:
        """总时长"""
        return sum(self.segment_times)
    
    @property
    def segment_count(self) -> int:
        """轨迹段数量"""
        return len(self.segments)
    
    def get_segment_max_values(self) -> List[dict]:
        """获取每段的极值"""
        return [seg.get_max_values() for seg in self.segments]
    
    def validate_continuity(self, tolerance: float = 1e-6) -> bool:
        """
        验证段间连续性
        
        Args:
            tolerance: 容差
            
        Returns:
            是否所有连接点都连续
        """
        for i in range(len(self.segments) - 1):
            seg1 = self.segments[i]
            seg2 = self.segments[i+1]
            
            p1 = seg1.position(seg1.T)
            p2 = seg2.position(0)
            v1 = seg1.velocity(seg1.T)
            v2 = seg2.velocity(0)
            a1 = seg1.acceleration(seg1.T)
            a2 = seg2.acceleration(0)
            
            if (abs(p1 - p2) > tolerance or 
                abs(v1 - v2) > tolerance or 
                abs(a1 - a2) > tolerance):
                logger.error(f"段 {i} 和段 {i+1} 之间不连续: "
                           f"Δp={abs(p1-p2):.6f}, "
                           f"Δv={abs(v1-v2):.6f}, "
                           f"Δa={abs(a1-a2):.6f}")
                return False
        
        return True


# 便捷函数
def quintic_trajectory(p0: float, v0: float, a0: float,
                       pT: float, vT: float, aT: float,
                       T: float, num_points: int = 100) -> Tuple[np.ndarray, ...]:
    """
    便捷函数：生成单段五次多项式轨迹
    
    Args:
        p0, v0, a0: 起点状态
        pT, vT, aT: 终点状态
        T: 总时间
        num_points: 采样点数
        
    Returns:
        (时间序列, 位置序列, 速度序列, 加速度序列)
    """
    traj = QuinticTrajectory(p0, v0, a0, pT, vT, aT, T)
    return traj.sample(num_points)


def multi_waypoint_trajectory(waypoints: List[Tuple[float, float, float]],
                              times: List[float],
                              num_points_per_segment: int = 100) -> Tuple[np.ndarray, ...]:
    """
    便捷函数：生成多点轨迹
    
    Args:
        waypoints: 路径点列表 [(p1,v1,a1), (p2,v2,a2), ...]
        times: 每段时长列表 [T1, T2, ...]
        num_points_per_segment: 每段采样点数
        
    Returns:
        (时间序列, 位置序列, 速度序列, 加速度序列)
    """
    traj = MultiSegmentTrajectory()
    traj.add_waypoints(waypoints, times)
    return traj.sample(num_points_per_segment)
