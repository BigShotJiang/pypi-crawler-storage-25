class TaskPlanner:
    """
    任务规划器：把高级指令分解成低级动作
    串起 VLA（听懂）+ Vision（看懂）+ WBC（动作）
    """

    def __init__(self, vla, vision, wbc):
        self.vla = vla          # 听懂指令
        self.vision = vision    # 看懂物体
        self.wbc = wbc          # 执行动作

    def execute(self, command, image):
        """
        执行自然语言指令
        image: 当前视觉图像
        """
        print(f"\n[任务规划] 收到指令: {command}")

        # 1. 听懂指令 → 提取目标
        target_color = self._extract_color(command)
        print(f"[1] 听懂: 目标物体是 {target_color} 色")

        # 2. 看懂物体 → 需要图像
        objects = self.vision.detect_objects(image)
        print(f"  调试: vision返回的物体 = {objects}")
        target = self._find_target(objects, target_color)
        if target is None:
            return f"没找到 {target_color} 色物体"
        print(f"[2] 看到: {target_color} 色物体在位置 ({target['x']}, {target['y']})")

        # 3. 规划路径 → 走过去
        print(f"[3] 规划: 移动到 ({target['x']}, {target['y']})")

        # 4. 执行动作 → 抓起来
        print(f"[4] 执行: 抓取 {target_color} 色物体")

        return "任务完成"

    def _extract_color(self, command):
        """从指令中提取颜色关键词"""
        color_map = {
            '红': 'red', 'red': 'red',
            '蓝': 'blue', 'blue': 'blue',
            '绿': 'green', 'green': 'green',
            '黄': 'yellow', 'yellow': 'yellow',
        }
        cmd_lower = command.lower()
        for cn, en in color_map.items():
            if cn in cmd_lower:
                return en
        return 'unknown'

    def _find_target(self, objects, target_color):
        """从物体列表中找到目标颜色"""
        print(f"  调试: target_color = {target_color}")
        for obj in objects:
            if obj['color'].lower() == target_color.lower():
                return obj
        return None