import numpy as np

class ZMPCalculator:
    """
    零力矩点 (Zero Moment Point) 计算器
    用于双足机器人稳定性判断
    公式来源：宇树机器人核心公式 (图7434)
    """
    
    def __init__(self):
        pass
    
    def compute_zmp_from_forces(self, forces, positions, g=9.81):
        """
        根据足底受力计算 ZMP
        forces: 各足受力 [Fz1, Fz2, ...]
        positions: 各足位置 [(x1,y1), (x2,y2), ...]
        """
        total_force = sum(forces)
        if total_force == 0:
            return (0, 0)
        
        zmp_x = sum(f * pos[0] for f, pos in zip(forces, positions)) / total_force
        zmp_y = sum(f * pos[1] for f, pos in zip(forces, positions)) / total_force
        
        return (zmp_x, zmp_y)
    
    def compute_zmp_from_com(self, com_pos, com_acc, z_c=1.0, g=9.81):
        """
        根据质心运动计算 ZMP
        com_pos: 质心位置 (x, y)
        com_acc: 质心加速度 (x_ddot, y_ddot)
        z_c: 质心高度
        """
        x, y = com_pos
        x_ddot, y_ddot = com_acc
        
        p_x = x - (z_c / g) * x_ddot
        p_y = y - (z_c / g) * y_ddot
        
        return (p_x, p_y)
    
    def is_stable(self, zmp, foot_positions):
        """
        判断 ZMP 是否在支撑多边形内
        zmp: (x, y)
        foot_positions: 足底位置列表 [(x1,y1), (x2,y2), ...]
        """
        # 简化为矩形支撑域（实际应使用凸包算法）
        if len(foot_positions) == 0:
            return False
        
        xs = [p[0] for p in foot_positions]
        ys = [p[1] for p in foot_positions]
        
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        
        return (min_x <= zmp[0] <= max_x) and (min_y <= zmp[1] <= max_y)