class Explainer:
    """
    可解释性模块：解释决策原因
    """
    
    def __init__(self):
        self.decision_log = []
    
    def record_decision(self, task, choice, reasons):
        """记录决策过程"""
        self.decision_log.append({
            'task': task,
            'choice': choice,
            'reasons': reasons
        })
    
    def explain(self, task):
        """解释某个任务的决策"""
        for log in reversed(self.decision_log):
            if log['task'] == task:
                reasons = '，'.join(log['reasons'])
                return f"选择 {log['choice']}，因为 {reasons}"
        return "没有找到相关记录"
    
    def explain_last(self):
        """解释最近一次决策"""
        if self.decision_log:
            last = self.decision_log[-1]
            reasons = '，'.join(last['reasons'])
            return f"刚才选择 {last['choice']}，因为 {reasons}"
        return "还没有任何决策记录"
    
    def get_reasoning_path(self, task):
        """获取推理路径"""
        for log in reversed(self.decision_log):
            if log['task'] == task:
                return {
                    'task': task,
                    'choice': log['choice'],
                    'reasons': log['reasons'],
                    'steps': len(log['reasons'])
                }
        return None