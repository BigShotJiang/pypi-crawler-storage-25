import json
import os

class UnitreeExperiences:
    def __init__(self):
        self.experiences = {}
        self._load_all()
    
    def _load_all(self):
        base_path = os.path.dirname(__file__)
        
        # 加载捡枕头经验
        pickup_path = os.path.join(base_path, "all_pickup_experiences.json")
        if os.path.exists(pickup_path):
            with open(pickup_path, 'r') as f:
                self.experiences["pickup"] = json.load(f)
            print(f"? 加载捡枕头经验: {len(self.experiences['pickup'])} 个")
        
        # 加载堆叠积木经验
        block_path = os.path.join(base_path, "blockstacking_experiences.json")
        if os.path.exists(block_path):
            with open(block_path, 'r') as f:
                self.experiences["blockstacking"] = json.load(f)
            print(f"? 加载堆叠积木经验: {len(self.experiences['blockstacking'])} 个")
        
        # 加载擦桌子经验
        wipe_path = os.path.join(base_path, "wipe_table.json")
        if os.path.exists(wipe_path):
            with open(wipe_path, 'r') as f:
                self.experiences["wipe_table"] = json.load(f)
            print(f"? 加载擦桌子经验: {len(self.experiences['wipe_table'])} 个")
        
        # 加载叠毛巾经验
        fold_path = os.path.join(base_path, "fold_towel.json")
        if os.path.exists(fold_path):
            with open(fold_path, 'r') as f:
                self.experiences["fold_towel"] = json.load(f)
            print(f"? 加载叠毛巾经验: {len(self.experiences['fold_towel'])} 个")
        
        # 加载倒药水经验
        pour_path = os.path.join(base_path, "pour_medicine.json")
        if os.path.exists(pour_path):
            with open(pour_path, 'r') as f:
                self.experiences["pour_medicine"] = json.load(f)
            print(f"? 加载倒药水经验: {len(self.experiences['pour_medicine'])} 个")
    
    def query(self, task):
        task_lower = task.lower()
        
        # 捡枕头相关
        if any(k in task_lower for k in ["捡", "pickup", "枕头"]):
            if "pickup" in self.experiences:
                exps = self.experiences["pickup"]
                return {
                    "found": True,
                    "task": "pickup_pillow",
                    "sample_count": len(exps),
                    "avg_frames": sum(e['frames'] for e in exps) / len(exps),
                    "avg_change": sum(e['avg_change'] for e in exps) / len(exps)
                }
        
        # 堆叠积木相关
        if any(k in task_lower for k in ["堆", "积木", "block", "stack"]):
            if "blockstacking" in self.experiences:
                exps = self.experiences["blockstacking"]
                return {
                    "found": True,
                    "task": "block_stacking",
                    "sample_count": len(exps),
                    "avg_frames": sum(e['frames'] for e in exps) / len(exps),
                    "avg_change": sum(e['avg_change'] for e in exps) / len(exps)
                }
        
        # 擦桌子相关
        if any(k in task_lower for k in ["擦", "桌子", "wipe", "table"]):
            if "wipe_table" in self.experiences:
                exps = self.experiences["wipe_table"]
                return {
                    "found": True,
                    "task": "wipe_table",
                    "sample_count": len(exps),
                    "avg_frames": sum(e['frames'] for e in exps) / len(exps),
                    "avg_change": sum(e['avg_change'] for e in exps) / len(exps)
                }
        
        # 叠毛巾相关
        if any(k in task_lower for k in ["叠", "毛巾", "fold", "towel"]):
            if "fold_towel" in self.experiences:
                exps = self.experiences["fold_towel"]
                return {
                    "found": True,
                    "task": "fold_towel",
                    "sample_count": len(exps),
                    "avg_frames": sum(e['frames'] for e in exps) / len(exps),
                    "avg_change": sum(e['avg_change'] for e in exps) / len(exps)
                }
        
        # 倒药水相关
        if any(k in task_lower for k in ["倒", "药水", "pour", "medicine"]):
            if "pour_medicine" in self.experiences:
                exps = self.experiences["pour_medicine"]
                return {
                    "found": True,
                    "task": "pour_medicine",
                    "sample_count": len(exps),
                    "avg_frames": sum(e['frames'] for e in exps) / len(exps),
                    "avg_change": sum(e['avg_change'] for e in exps) / len(exps)
                }
        
        return {"found": False}
