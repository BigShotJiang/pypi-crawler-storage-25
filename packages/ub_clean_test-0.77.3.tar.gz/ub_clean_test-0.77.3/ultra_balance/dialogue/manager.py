class DialogueManager:
    """
    对话管理模块：记住上下文，主动聊天
    """
    
    def __init__(self):
        self.context = []  # 对话历史
        self.topic = None  # 当前话题
        self.user_emotion = 'neutral'
    
    def update_emotion(self, emotion):
        self.user_emotion = emotion
    
    def add_turn(self, user, robot):
        """添加一轮对话"""
        self.context.append({'user': user, 'robot': robot})
        if len(self.context) > 10:
            self.context.pop(0)
    
    def get_context(self, n=3):
        """获取最近 n 轮对话"""
        return self.context[-n:]
    
    def respond(self, user_input):
        """根据上下文生成回应"""
        # 检测话题
        if '天气' in user_input:
            self.topic = 'weather'
            response = self._weather_response(user_input)
        elif '心情' in user_input or '开心' in user_input or '难过' in user_input:
            self.topic = 'emotion'
            response = self._emotion_response(user_input)
        elif '名字' in user_input:
            self.topic = 'name'
            response = "我叫小清，你可以叫我清清！"
        elif '你好' in user_input:
            response = self._greeting_response()
        elif '再见' in user_input:
            response = "再见！期待下次聊天！"
        else:
            response = self._default_response(user_input)
        
        self.add_turn(user_input, response)
        return response
    
    def _weather_response(self, text):
        if '好' in text:
            return "今天天气真好！要不要出去走走？"
        else:
            return "天气不太好呢，记得带伞哦。"
    
    def _emotion_response(self, text):
        if self.user_emotion == '开心':
            return "看到你开心，我也开心！有什么好事吗？"
        elif self.user_emotion == '难过':
            return "别难过，我在这里陪你。想聊聊吗？"
        else:
            return "心情很重要哦，希望你能开心起来！"
    
    def _greeting_response(self):
        last = self.context[-1] if self.context else None
        if last and '你好' in last['user']:
            return "哈哈，我们刚打过招呼呢！"
        return "你好！今天想聊点什么？"
    
    def _default_response(self, text):
        # 主动追问
        if len(self.context) > 2:
            return "嗯嗯，然后呢？"
        elif self.user_emotion == '开心':
            return "听起来不错！还有别的吗？"
        else:
            return "原来如此，能多说一点吗？"