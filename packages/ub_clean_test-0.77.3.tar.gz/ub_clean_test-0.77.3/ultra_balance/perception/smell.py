import re

class SmellPerception:
    """
    嗅觉感知模块：理解气味概念
    """
    
    def __init__(self):
        # 模糊气味词映射（强度 0-10）
        self.fuzzy_smells = {
            '极香': {'强度': 10, '类型': '香', '比喻': '像花海'},
            '很香': {'强度': 8, '类型': '香', '比喻': '像香水'},
            '香': {'强度': 6, '类型': '香', '比喻': '像花香'},
            '有点香': {'强度': 4, '类型': '香', '比喻': '淡淡的花香'},
            '无味': {'强度': 0, '类型': '无', '比喻': '没有味道'},
            '有点臭': {'强度': 3, '类型': '臭', '比喻': '微微的异味'},
            '臭': {'强度': 5, '类型': '臭', '比喻': '像垃圾'},
            '很臭': {'强度': 7, '类型': '臭', '比喻': '像粪坑'},
            '极臭': {'强度': 9, '类型': '臭', '比喻': '像腐肉'},
            '刺鼻': {'强度': 8, '类型': '刺激', '比喻': '像化学品'},
            '酸': {'强度': 5, '类型': '酸', '比喻': '像醋'},
            '甜': {'强度': 5, '类型': '甜', '比喻': '像糖果'},
        }
        
        # 具体气味类型
        self.smell_types = {
            '花香': '花香味，清新自然',
            '果香': '水果味，香甜可口',
            '草木': '青草味，清新',
            '食物': '食物香味，诱人',
            '焦味': '烧焦味，刺鼻',
            '霉味': '发霉味，潮湿',
            '烟味': '烟味，呛人',
            '化学味': '化学品味，刺鼻',
        }
        
        # 气味强度调整
        self.intensity_adjust = {
            '再香一点': 1,
            '香一点': 1,
            '再淡一点': -1,
            '淡一点': -1,
            '再浓一点': 1,
            '浓一点': 1,
        }
        
        self.current_intensity = 5.0
        self.current_smell_type = '花香'
    
    def parse_smell_word(self, text):
        """解析模糊气味词"""
        # 按长度从长到短排序
        for word in sorted(self.fuzzy_smells.keys(), key=len, reverse=True):
            if word in text:
                return word, self.fuzzy_smells[word]
        return None, None
    
    def parse_smell_type(self, text):
        """解析具体气味类型"""
        for stype, desc in self.smell_types.items():
            if stype in text:
                return stype, desc
        return None, None
    
    def parse_intensity(self, text):
        """解析气味强度调整"""
        for word, delta in self.intensity_adjust.items():
            if word in text:
                return delta, word
        return None, None
    
    def understand(self, text):
        """理解气味表达"""
        # 模糊气味词
        word, info = self.parse_smell_word(text)
        if info:
            return f"{word}：{info['比喻']}，强度{info['强度']}级"
        
        # 具体气味类型
        stype, desc = self.parse_smell_type(text)
        if stype:
            return f"{stype}：{desc}"
        
        # 强度调整
        delta, word = self.parse_intensity(text)
        if delta:
            new_intensity = self.current_intensity + delta
            new_intensity = max(0, min(10, new_intensity))
            return f"{word}，气味强度从 {self.current_intensity} 变为 {new_intensity:.0f} 级"
        
        return "我不太理解这个气味"
    
    def set_current_intensity(self, intensity):
        """设置当前气味强度"""
        self.current_intensity = max(0, min(10, intensity))
    
    def set_smell_type(self, smell_type):
        """设置当前气味类型"""
        if smell_type in self.smell_types:
            self.current_smell_type = smell_type
    
    def get_smell_status(self):
        """获取气味状态"""
        if self.current_intensity < 2:
            return f"气味很淡，几乎闻不到"
        elif self.current_intensity < 5:
            return f"淡淡的{self.current_smell_type}味"
        elif self.current_intensity < 8:
            return f"明显的{self.current_smell_type}味"
        else:
            return f"浓郁的{self.current_smell_type}味"
    
    def is_pleasant(self):
        """判断是否好闻"""
        return self.current_smell_type in ['花香', '果香', '草木', '食物']
    
    def suggest_action(self):
        """建议行动"""
        if self.current_intensity > 7:
            if not self.is_pleasant():
                return "气味太重，建议通风"
            else:
                return "香味很浓，可以开窗透气"
        elif self.current_intensity < 3:
            return "气味很淡，无需处理"
        else:
            return "气味正常"