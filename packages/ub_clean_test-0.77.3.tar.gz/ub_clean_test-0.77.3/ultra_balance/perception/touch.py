import re

class TouchPerception:
    """
    触觉感知模块：理解触觉概念
    """
    
    def __init__(self):
        # 模糊触觉词映射
        self.fuzzy_touch = {
           '极硬': {'硬度': 100, '比喻': '像钻石', '压力': 12},
           '很硬': {'硬度': 95, '比喻': '像钢铁', '压力': 10},
           '极软': {'硬度': 10, '比喻': '像棉花', '压力': 1},
           '很软': {'硬度': 30, '比喻': '像海绵', '压力': 2},
           '适中': {'硬度': 70, '比喻': '像木头', '压力': 5},
           '硬': {'硬度': 85, '比喻': '像石头', '压力': 8},
           '软': {'硬度': 50, '比喻': '像橡胶', '压力': 3},
        }
        
        # 表面质感映射
        self.textures = {
            '光滑': '表面光滑，摩擦小',
            '粗糙': '表面粗糙，摩擦大',
            '黏': '有粘性，容易粘手',
            '湿': '潮湿，有水',
            '干': '干燥，无水',
            '热': '温度高，烫手',
            '冰': '温度低，冰冷',
            '温': '温度适中，温暖',
        }
        
        # 压力调整（牛）
        self.pressure_adjust = {
            '再轻一点': -1,
            '轻一点': -1,
            '再重一点': 1,
            '重一点': 1,
            '再用力一点': 2,
            '轻点': -0.5,
        }
        
        self.current_pressure = 5.0
        self.current_texture = '光滑'
    
    def parse_touch_word(self, text):
        """解析模糊触觉词"""
        for word, info in self.fuzzy_touch.items():
            if word in text:
                # 调试输出
                if word in ['很硬', '极硬']:
                    print(f"DEBUG: 匹配到 {word}，硬度={info['硬度']}")
                return word, info
        return None, None
    
    def parse_texture(self, text):
        """解析表面质感"""
        for tex, desc in self.textures.items():
            if tex in text:
                return tex, desc
        return None, None
    
    def parse_pressure(self, text):
        """解析压力调整"""
        for word, delta in self.pressure_adjust.items():
            if word in text:
                return delta, word
        return None, None
    
    def understand(self, text):
        """理解触觉表达"""
        # 模糊触觉词
        word, info = self.parse_touch_word(text)
        if info:
            return f"{word}：硬度{info['硬度']}，{info['比喻']}，压力约{info['压力']}牛"
        
        # 表面质感
        tex, desc = self.parse_texture(text)
        if tex:
            return f"{tex}：{desc}"
        
        # 压力调整
        delta, word = self.parse_pressure(text)
        if delta:
            new_pressure = self.current_pressure + delta
            new_pressure = max(0, new_pressure)
            return f"{word}，压力从 {self.current_pressure} 变为 {new_pressure:.1f} 牛"
        
        return "我不太理解这个触觉"
    
    def set_current_pressure(self, pressure):
        """设置当前压力"""
        self.current_pressure = pressure
    
    def set_texture(self, texture):
        """设置当前质感"""
        if texture in self.textures:
            self.current_texture = texture
    
    def get_touch_status(self):
        """获取触觉状态"""
        return f"当前压力 {self.current_pressure} 牛，表面{self.current_texture}"
    
    def is_too_hard(self):
        """判断是否太硬"""
        return self.current_pressure > 8
    
    def is_too_soft(self):
        """判断是否太软"""
        return self.current_pressure < 3
    
    def suggest_adjustment(self):
        """建议调整"""
        if self.is_too_hard():
            return "压力太大，建议轻一点"
        elif self.is_too_soft():
            return "压力太小，建议重一点"
        else:
            return "压力适中"