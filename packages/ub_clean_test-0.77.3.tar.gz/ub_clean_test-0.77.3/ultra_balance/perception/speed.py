import re

class SpeedPerception:
    """
    速度感知模块：理解速度概念
    """
    
    def __init__(self):
        # 模糊速度词映射（米/秒）——按长度从长到短排列
        self.fuzzy_speeds = {
            '很快': 6.0,
            '很慢': 0.5,
            '飞快': 8.0,
            '快': 3.0,
            '慢': 1.0,
            '正常': 2.0,
        }
        
        # 相对速度调整（米/秒）
        self.relative_adjust = {
            '再快一点': 0.5,
            '快一点': 0.5,
            '再慢一点': -0.5,
            '慢一点': -0.5,
            '加速': 1.0,
            '减速': -1.0,
        }
        
        self.current_speed = 2.0  # 当前速度（米/秒）
    
    def parse_speed_word(self, text):
        """解析模糊速度词"""
        for word, speed in self.fuzzy_speeds.items():
            if word in text:
                return speed, word
        return None, None
    
    def parse_exact_speed(self, text):
        """解析具体速度，如“5米/秒”、“10公里/小时”"""
        patterns = [
            (r'(\d+(?:\.\d+)?)\s*米/秒', 1.0),
            (r'(\d+(?:\.\d+)?)\s*公里/小时', 1000/3600),
            (r'(\d+(?:\.\d+)?)\s*km/h', 1000/3600),
            (r'(\d+(?:\.\d+)?)\s*m/s', 1.0),
        ]
        
        for pattern, factor in patterns:
            match = re.search(pattern, text.lower())
            if match:
                value = float(match.group(1))
                return value * factor, f"{value}{text[match.end():]}"
        return None, None
    
    def parse_relative_speed(self, text):
        """解析相对速度调整"""
        for word, delta in self.relative_adjust.items():
            if word in text:
                return delta, word
        return None, None
    
    def understand(self, text):
        """理解速度表达"""
        # 模糊速度词
        speed, word = self.parse_speed_word(text)
        if speed:
            return f"{word} 大概 {speed} 米/秒"
        
        # 具体速度
        speed, desc = self.parse_exact_speed(text)
        if speed:
            return f"{desc} 是 {speed:.2f} 米/秒"
        
        # 相对速度
        delta, word = self.parse_relative_speed(text)
        if delta:
            new_speed = self.current_speed + delta
            return f"{word}，速度从 {self.current_speed} 变为 {new_speed:.1f} 米/秒"
        
        return "我不太理解这个速度"
    
    def set_current_speed(self, speed):
        """设置当前速度"""
        self.current_speed = speed
    
    def is_too_fast(self, limit=3.0):
        """判断是否太快"""
        return self.current_speed > limit
    
    def is_too_slow(self, limit=1.0):
        """判断是否太慢"""
        return self.current_speed < limit
    
    def get_speed_status(self):
        """获取速度状态描述"""
        if self.is_too_fast():
            return f"当前速度 {self.current_speed} 米/秒，有点快"
        elif self.is_too_slow():
            return f"当前速度 {self.current_speed} 米/秒，有点慢"
        else:
            return f"当前速度 {self.current_speed} 米/秒，正常"