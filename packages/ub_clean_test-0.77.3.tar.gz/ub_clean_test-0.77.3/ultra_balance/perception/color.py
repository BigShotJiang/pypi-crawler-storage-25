import re

class ColorPerception:
    """
    颜色感知模块：理解颜色概念
    """
    
    def __init__(self):
        # 基本颜色映射
        self.colors = {
            '红': {'波长': '620-750nm', '情感': '热情、活力', 'rgb': (255,0,0)},
            '橙': {'波长': '590-620nm', '情感': '温暖、快乐', 'rgb': (255,165,0)},
            '黄': {'波长': '570-590nm', '情感': '明亮、希望', 'rgb': (255,255,0)},
            '绿': {'波长': '495-570nm', '情感': '自然、平静', 'rgb': (0,255,0)},
            '蓝': {'波长': '450-495nm', '情感': '冷静、信任', 'rgb': (0,0,255)},
            '紫': {'波长': '380-450nm', '情感': '神秘、高贵', 'rgb': (128,0,128)},
            '粉': {'波长': '约620nm', '情感': '温柔、可爱', 'rgb': (255,192,203)},
            '棕': {'波长': '约600nm', '情感': '稳重、朴实', 'rgb': (139,69,19)},
            '黑': {'波长': '无光', '情感': '神秘、庄重', 'rgb': (0,0,0)},
            '白': {'波长': '全光谱', '情感': '纯洁、简约', 'rgb': (255,255,255)},
            '灰': {'波长': '中性', '情感': '中性、沉稳', 'rgb': (128,128,128)},
        }
        
        # 颜色深浅修饰
        self.shades = {
            '深': 0.6,
            '浅': 0.4,
            '暗': 0.5,
            '亮': 0.8,
        }
        
        # 颜色搭配规则
        self.color_combinations = {
            ('红', '绿'): '圣诞配色，醒目喜庆',
            ('蓝', '白'): '清爽干净，像天空',
            ('黑', '白'): '经典百搭',
            ('红', '黄'): '热情活力，像麦当劳',
            ('蓝', '黄'): '对比鲜明',
            ('紫', '黄'): '互补色，强烈对比',
        }
        
        self.user_preferences = {}  # 用户颜色偏好
    
    def parse_color(self, text):
        """解析颜色"""
        # 先处理深浅
        shade = None
        for s in self.shades:
            if s in text:
                shade = s
                text = text.replace(s, '')
        
        # 再匹配基本颜色
        for color in self.colors:
            if color in text:
                if shade:
                    return f"{shade}{color}", self.colors[color]
                return color, self.colors[color]
        return None, None
    
    def understand(self, text):
        """理解颜色表达"""
        color_name, info = self.parse_color(text)
        if color_name:
            return f"{color_name}：波长{info['波长']}，象征{info['情感']}"
        return "我不太理解这个颜色"
    
    def remember_preference(self, user, color):
        """记住用户颜色偏好"""
        if user not in self.user_preferences:
            self.user_preferences[user] = []
        if color not in self.user_preferences[user]:
            self.user_preferences[user].append(color)
        return f"已记住 {user} 喜欢 {color}"
    
    def get_preference(self, user):
        """获取用户颜色偏好"""
        return self.user_preferences.get(user, [])
    
    def color_match(self, color1, color2):
        """判断颜色搭配"""
        key = (color1, color2)
        if key in self.color_combinations:
            return self.color_combinations[key]
        key2 = (color2, color1)
        if key2 in self.color_combinations:
            return self.color_combinations[key2]
        return f"{color1}和{color2}可以搭配，但效果一般"
    
    def recommend(self, user):
        """根据偏好推荐颜色"""
        prefs = self.get_preference(user)
        if not prefs:
            return "还不知道你喜欢什么颜色，告诉我吧"
        return f"根据你的偏好，推荐 {prefs[0]} 系列的颜色"