import numpy as np

class SimpleVision:
    """
    简化版视觉感知 (Vision Perception)
    检测颜色、计算位置
    来源：英伟达 + 宇树视觉相关
    """

    def __init__(self):
        # 颜色阈值 (HSV格式)
        self.color_ranges = {
            'red': ([0, 100, 100], [10, 255, 255]),
            'blue': ([100, 100, 100], [130, 255, 255]),
            'green': ([40, 100, 100], [80, 255, 255]),
            'yellow': ([20, 100, 100], [30, 255, 255]),
        }

    def detect_color(self, image, color_name):
        """
        检测指定颜色的物体
        返回: 物体中心坐标 (x, y), 是否找到
        """
        if color_name not in self.color_ranges:
            return None, False

        # 模拟检测（实际应该用OpenCV）
        # 这里返回模拟数据
        h, w = image.shape[:2]
        center = (w//2, h//2)
        return center, True

    def detect_objects(self, image):
        """
        检测所有预设颜色的物体
        返回: 物体列表 [{'color': 'red', 'x': 100, 'y': 150}, ...]
        """
        objects = []
        h, w = image.shape[:2]
        colors = ['red', 'blue', 'green', 'yellow']
        for i, color in enumerate(colors):
            x = w // (len(colors) + 1) * (i + 1)
            y = h // 2
            objects.append({'color': color, 'x': x, 'y': y})
        return objects

    def get_position(self, obj):
        """
        获取物体位置 (x, y)
        """
        return obj.get('x', 0), obj.get('y', 0)