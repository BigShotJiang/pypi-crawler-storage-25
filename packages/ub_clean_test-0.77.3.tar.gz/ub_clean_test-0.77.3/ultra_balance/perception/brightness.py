import re

class BrightnessPerception:
    """
    亮度感知模块：理解亮度概念
    """
    
    def __init__(self):
        # 模糊亮度词映射（勒克斯）——按长度从长到短排列
        self.fuzzy_brightness = {
            '极暗': 1,
            '很暗': 10,
            '很亮': 600,
            '刺眼': 1000,
            '暗': 30,
            '微亮': 50,
            '正常': 100,
            '亮': 200,
        }
        
        # 相对亮度调整（勒克斯）
        self.relative_adjust = {
            '再亮一点': 20,
            '亮一点': 20,
            '再暗一点': -20,
            '暗一点': -20,
            '调亮': 30,
            '调暗': -30,
        }
        
        self.current_brightness = 100.0
        self.dark_threshold = 50.0
        self.bright_threshold = 400.0
    
    def parse_brightness_word(self, text):
        """解析模糊亮度词"""
        for word, lux in self.fuzzy_brightness.items():
            if word in text:
                return lux, word
        return None, None
    
    def parse_exact_brightness(self, text):
        """解析具体亮度"""
        patterns = [
            (r'(\d+(?:\.\d+)?)\s*勒克斯', 1.0),
            (r'(\d+(?:\.\d+)?)\s*流明', 1.0),
            (r'(\d+(?:\.\d+)?)\s*lux', 1.0),
            (r'(\d+(?:\.\d+)?)\s*lm', 1.0),
        ]
        
        for pattern, factor in patterns:
            match = re.search(pattern, text.lower())
            if match:
                value = float(match.group(1))
                return value * factor, f"{value}{text[match.end():]}"
        return None, None
    
    def parse_relative_brightness(self, text):
        """解析相对亮度调整"""
        for word, delta in self.relative_adjust.items():
            if word in text:
                return delta, word
        return None, None
    
    def understand(self, text):
        """理解亮度表达"""
        # 模糊亮度词
        lux, word = self.parse_brightness_word(text)
        if lux is not None:
            return f"{word} 大概 {lux} 勒克斯"
        
        # 具体亮度
        lux, desc = self.parse_exact_brightness(text)
        if lux is not None:
            return f"{desc} 是 {lux:.1f} 勒克斯"
        
        # 相对亮度
        delta, word = self.parse_relative_brightness(text)
        if delta:
            new_lux = self.current_brightness + delta
            new_lux = max(0, new_lux)
            return f"{word}，亮度从 {self.current_brightness} 变为 {new_lux:.0f} 勒克斯"
        
        return "我不太理解这个亮度"
    
    def set_current_brightness(self, lux):
        """设置当前亮度"""
        self.current_brightness = lux
    
    def is_dark(self):
        return self.current_brightness < self.dark_threshold
    
    def is_bright(self):
        return self.current_brightness > self.bright_threshold
    
    def need_light(self):
        if self.is_dark():
            return f"当前亮度 {self.current_brightness} 勒克斯，太暗了，建议开灯"
        elif self.is_bright():
            return f"当前亮度 {self.current_brightness} 勒克斯，太亮了，建议调暗"
        else:
            return f"当前亮度 {self.current_brightness} 勒克斯，亮度合适"
    
    def get_brightness_status(self):
        if self.is_dark():
            return f"当前亮度 {self.current_brightness} 勒克斯，很暗"
        elif self.is_bright():
            return f"当前亮度 {self.current_brightness} 勒克斯，很亮"
        else:
            return f"当前亮度 {self.current_brightness} 勒克斯，正常"