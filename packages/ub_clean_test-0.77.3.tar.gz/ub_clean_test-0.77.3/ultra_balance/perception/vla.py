class SimpleVLA:
    """
    简化版视觉-语言-动作模型 (Visual-Language-Action)
    模拟：听懂简单指令 → 执行动作
    来源：英伟达 (图7229)
    """
    
    def __init__(self):
        # 指令-动作映射表
        self.command_map = {
            '走': 'walk',
            '跑': 'run',
            '停': 'stop',
            '左转': 'turn_left',
            '右转': 'turn_right',
            '挥手': 'wave',
            '蹲下': 'squat',
            '站起': 'stand',
            '前进': 'forward',
            '后退': 'backward',
        }
        
    def understand(self, text):
        """
        理解自然语言指令
        返回: 动作名称
        """
        text = text.lower()
        for keyword, action in self.command_map.items():
            if keyword in text:
                return action
        return 'unknown'
    
    def act(self, action):
        """
        根据动作返回控制指令
        """
        actions = {
            'walk': {'type': 'walk', 'params': {'speed': 0.5}},
            'run': {'type': 'walk', 'params': {'speed': 1.5}},
            'stop': {'type': 'stop', 'params': {}},
            'turn_left': {'type': 'turn', 'params': {'angle': -90}},
            'turn_right': {'type': 'turn', 'params': {'angle': 90}},
            'wave': {'type': 'arm', 'params': {'action': 'wave'}},
            'squat': {'type': 'posture', 'params': {'height': 0.5}},
            'stand': {'type': 'posture', 'params': {'height': 1.0}},
            'forward': {'type': 'walk', 'params': {'direction': 'forward'}},
            'backward': {'type': 'walk', 'params': {'direction': 'backward'}},
        }
        return actions.get(action, {'type': 'unknown', 'params': {}})