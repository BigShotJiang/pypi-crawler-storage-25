class IntentRecognizer:
    """
    意图识别模块：猜别人想做什么
    """
    
    def __init__(self):
        # 意图-关键词映射
        self.intent_keywords = {
            'go_to': ['去', '走到', '到', '前往'],
            'grab': ['拿', '抓', '取', '拿起来'],
            'look': ['看', '看看', '观察'],
            'follow': ['跟', '跟着', '过来'],
            'stop': ['停', '停下', '别动'],
            'wait': ['等', '等一下', '稍等'],
            'ask': ['问', '告诉', '说'],
            'help': ['帮', '帮忙', '协助'],
        }
        
        # 上下文偏好
        self.context = {}
    
    def recognize(self, text):
        """
        识别意图
        """
        text_lower = text.lower()
        
        for intent, keywords in self.intent_keywords.items():
            for kw in keywords:
                if kw in text_lower:
                    # 提取目标（如果有）
                    target = self._extract_target(text_lower, kw)
                    return {
                        'intent': intent,
                        'target': target,
                        'confidence': 0.8
                    }
        
        return {'intent': 'unknown', 'target': None, 'confidence': 0.2}
    
    def _extract_target(self, text, keyword):
        """提取目标物体"""
        # 简单提取：关键词后面的词
        parts = text.split(keyword)
        if len(parts) > 1:
            target = parts[1].strip()[:20]
            return target if target else None
        return None
    
    def guess_intent_from_action(self, action):
        """
        从动作猜意图
        """
        if action == 'walk_toward':
            return '可能想靠近你'
        elif action == 'stop':
            return '可能想停下来'
        elif action == 'look_around':
            return '可能在找东西'
        elif action == 'reach_out':
            return '可能想拿东西'
        else:
            return '不知道想做什么'
    
    def update_context(self, key, value):
        """更新上下文"""
        self.context[key] = value