import re

class WeightPerception:
    """
    重量感知模块：理解重量概念
    """
    
    def __init__(self):
        # 模糊重量词映射（公斤）
        self.fuzzy_weights = {
            '很轻': 0.1,
            '轻': 0.5,
            '正常': 2.0,
            '重': 5.0,
            '很重': 10.0,
            '非常重': 20.0,
        }
        
        # 相对重量调整（公斤）
        self.relative_adjust = {
            '再轻一点': -0.5,
            '轻一点': -0.5,
            '再重一点': 0.5,
            '重一点': 0.5,
            '减轻': -1.0,
            '加重': 1.0,
        }
        
        self.current_weight = 2.0  # 当前重量（公斤）
        self.carry_limit = 10.0    # 可承受重量（公斤）
    
    def parse_weight_word(self, text):
        """解析模糊重量词"""
        for word, weight in self.fuzzy_weights.items():
            if word in text:
                return weight, word
        return None, None
    
    def parse_exact_weight(self, text):
        """解析具体重量，如“5公斤”、“10克”、“1吨”"""
        patterns = [
            (r'(\d+(?:\.\d+)?)\s*公斤', 1.0),      # 公斤
            (r'(\d+(?:\.\d+)?)\s*千克', 1.0),      # 千克
            (r'(\d+(?:\.\d+)?)\s*克', 0.001),      # 克
            (r'(\d+(?:\.\d+)?)\s*吨', 1000.0),     # 吨
            (r'(\d+(?:\.\d+)?)\s*斤', 0.5),        # 市斤
        ]
        
        for pattern, factor in patterns:
            match = re.search(pattern, text.lower())
            if match:
                value = float(match.group(1))
                return value * factor, f"{value}{text[match.end():]}"
        return None, None
    
    def parse_relative_weight(self, text):
        """解析相对重量调整"""
        for word, delta in self.relative_adjust.items():
            if word in text:
                return delta, word
        return None, None
    
    def understand(self, text):
        """理解重量表达"""
        # 模糊重量词
        weight, word = self.parse_weight_word(text)
        if weight:
            return f"{word} 大概 {weight} 公斤"
        
        # 具体重量
        weight, desc = self.parse_exact_weight(text)
        if weight:
            return f"{desc} 是 {weight:.2f} 公斤"
        
        # 相对重量
        delta, word = self.parse_relative_weight(text)
        if delta:
            new_weight = self.current_weight + delta
            new_weight = max(0, new_weight)
            return f"{word}，重量从 {self.current_weight} 变为 {new_weight:.1f} 公斤"
        
        return "我不太理解这个重量"
    
    def set_current_weight(self, weight):
        """设置当前重量"""
        self.current_weight = weight
    
    def can_carry(self, weight=None):
        """判断是否拿得动"""
        w = weight if weight is not None else self.current_weight
        if w <= self.carry_limit:
            return f"重量 {w} 公斤，可以拿得动"
        else:
            return f"重量 {w} 公斤，超过承受能力（{self.carry_limit}公斤），拿不动"
    
    def get_weight_status(self):
        """获取重量状态描述"""
        if self.current_weight < 1.0:
            return f"当前重量 {self.current_weight} 公斤，很轻"
        elif self.current_weight < 3.0:
            return f"当前重量 {self.current_weight} 公斤，正常"
        elif self.current_weight < 8.0:
            return f"当前重量 {self.current_weight} 公斤，有点重"
        else:
            return f"当前重量 {self.current_weight} 公斤，很重"