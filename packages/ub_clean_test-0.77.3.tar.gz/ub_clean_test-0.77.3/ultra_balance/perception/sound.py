import re

class SoundPerception:
    """
    声音感知模块：理解声音概念
    """
    
    def __init__(self):
        # 模糊声音词映射（分贝）
        self.fuzzy_sounds = {
            '极静': 10,
            '很安静': 20,
            '安静': 30,
            '正常': 50,
            '有点吵': 65,
            '吵': 70,
            '很吵': 80,
            '极吵': 90,
        }
        
        # 相对音量调整（分贝）
        self.relative_adjust = {
            '再大声一点': 5,
            '大声一点': 5,
            '再小声一点': -5,
            '小声一点': -5,
            '调大': 10,
            '调小': -10,
        }
        
        self.current_volume = 50.0
        self.quiet_threshold = 40.0
        self.loud_threshold = 65.0
    
    def parse_sound_word(self, text):
        """解析模糊声音词"""
        for word, db in self.fuzzy_sounds.items():
            if word in text:
                return db, word
        return None, None
    
    def parse_exact_sound(self, text):
        """解析具体音量"""
        patterns = [
            (r'(\d+(?:\.\d+)?)\s*分贝', 1.0),
            (r'(\d+(?:\.\d+)?)\s*db', 1.0),
        ]
        
        for pattern, factor in patterns:
            match = re.search(pattern, text.lower())
            if match:
                value = float(match.group(1))
                return value * factor, f"{value}{text[match.end():]}"
        return None, None
    
    def parse_relative_sound(self, text):
        """解析相对音量调整"""
        for word, delta in self.relative_adjust.items():
            if word in text:
                return delta, word
        return None, None
    
    def understand(self, text):
        """理解声音表达"""
        # 模糊声音词
        db, word = self.parse_sound_word(text)
        if db is not None:
            return f"{word} 大概 {db} 分贝"
        
        # 具体音量
        db, desc = self.parse_exact_sound(text)
        if db is not None:
            return f"{desc} 是 {db:.1f} 分贝"
        
        # 相对音量
        delta, word = self.parse_relative_sound(text)
        if delta:
            new_db = self.current_volume + delta
            new_db = max(0, new_db)
            return f"{word}，音量从 {self.current_volume} 变为 {new_db:.0f} 分贝"
        
        return "我不太理解这个声音"
    
    def set_current_volume(self, db):
        """设置当前音量"""
        self.current_volume = db
    
    def is_quiet(self):
        return self.current_volume < self.quiet_threshold
    
    def is_loud(self):
        return self.current_volume > self.loud_threshold
    
    def get_sound_status(self):
        if self.is_quiet():
            return f"当前音量 {self.current_volume} 分贝，很安静"
        elif self.is_loud():
            return f"当前音量 {self.current_volume} 分贝，有点吵"
        else:
            return f"当前音量 {self.current_volume} 分贝，正常"
    
    def suggest_action(self):
        if self.is_loud():
            return "有点吵，建议关窗或调低音量"
        elif self.is_quiet():
            return "很安静，适合休息或学习"
        else:
            return "音量正常，无需调整"