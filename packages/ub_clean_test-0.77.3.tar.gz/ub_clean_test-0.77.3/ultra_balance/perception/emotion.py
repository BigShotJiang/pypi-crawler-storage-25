class EmotionRecognizer:
    """
    情感识别模块：从文字中识别情绪
    """
    
    def __init__(self):
        # 情绪词库
        self.emotion_keywords = {
            '开心': ['好开心', '太好了', '哈哈', '耶', '棒'],
            '生气': ['烦', '气死', '讨厌', '怎么又', '不行'],
            '难过': ['难过', '伤心', '唉', '算了', '呜呜'],
            '害怕': ['怕', '吓死', '危险', '不要', '救命'],
            '惊讶': ['哇', '天哪', '真的吗', '居然', '没想到'],
        }
        
        self.current_emotion = 'neutral'
    
    def recognize(self, text):
        """从文字中识别情绪"""
        text_lower = text.lower()
        
        for emotion, keywords in self.emotion_keywords.items():
            for kw in keywords:
                if kw in text_lower:
                    self.current_emotion = emotion
                    return {
                        'emotion': emotion,
                        'confidence': 0.7,
                        'trigger_word': kw
                    }
        
        self.current_emotion = 'neutral'
        return {'emotion': 'neutral', 'confidence': 0.3, 'trigger_word': None}
    
    def respond_to_emotion(self, emotion):
        """根据情绪返回回应"""
        responses = {
            '开心': '看到你开心，我也开心！',
            '生气': '对不起，别生气了，我会注意的。',
            '难过': '别难过，我在这里陪你。',
            '害怕': '别怕，有我在呢。',
            '惊讶': '哇，真的吗？太厉害了！',
            'neutral': '好的，我知道了。'
        }
        return responses.get(emotion, '嗯，我听到了。')
    
    def get_current_emotion(self):
        return self.current_emotion