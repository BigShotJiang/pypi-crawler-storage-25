import re

class TastePerception:
    """
    味觉感知模块：理解味道概念
    """
    
    def __init__(self):
        # 基本味道映射（强度 0-10）
        self.basic_tastes = {
            '甜': {'强度': 5, '比喻': '像糖', '建议': '糖分较高'},
            '酸': {'强度': 5, '比喻': '像柠檬', '建议': '酸性较强'},
            '苦': {'强度': 5, '比喻': '像咖啡', '建议': '苦味明显'},
            '辣': {'强度': 5, '比喻': '像辣椒', '建议': '辣味刺激'},
            '咸': {'强度': 5, '比喻': '像盐', '建议': '盐分较高'},
        }
        
        # 强度修饰词
        self.intensity_modifiers = {
            '微': 2,
            '有点': 3,
            '比较': 5,
            '很': 7,
            '非常': 8,
            '太': 9,
            '极': 10,
        }
        
        # 强度调整
        self.intensity_adjust = {
            '再甜一点': {'味道': '甜', 'delta': 1},
            '甜一点': {'味道': '甜', 'delta': 1},
            '再酸一点': {'味道': '酸', 'delta': 1},
            '酸一点': {'味道': '酸', 'delta': 1},
            '再苦一点': {'味道': '苦', 'delta': 1},
            '苦一点': {'味道': '苦', 'delta': 1},
            '再辣一点': {'味道': '辣', 'delta': 1},
            '辣一点': {'味道': '辣', 'delta': 1},
            '再咸一点': {'味道': '咸', 'delta': 1},
            '咸一点': {'味道': '咸', 'delta': 1},
            '淡一点': {'delta': -1},
            '再淡一点': {'delta': -1},
        }
        
        self.current_tastes = {taste: 5 for taste in self.basic_tastes}
    
    def parse_taste(self, text):
        """解析味道表达"""
        # 先匹配强度修饰词
        intensity = 5
        intensity_word = None
        for word, val in self.intensity_modifiers.items():
            if word in text:
                intensity = val
                intensity_word = word
                text = text.replace(word, '')
        
        # 再匹配基本味道
        for taste, info in self.basic_tastes.items():
            if taste in text:
                final_intensity = intensity
                return taste, final_intensity, info
        return None, None, None
    
    def parse_adjust(self, text):
        """解析味道调整"""
        for word, adj in self.intensity_adjust.items():
            if word in text:
                return {'word': word, **adj}
        return None
    
    def understand(self, text):
        """理解味道表达"""
        # 味道调整
        adj = self.parse_adjust(text)
        if adj:
            taste = adj.get('味道')
            delta = adj.get('delta', 0)
            if taste:
                old = self.current_tastes.get(taste, 5)
                new = max(0, min(10, old + delta))
                self.current_tastes[taste] = new
                return f"{adj['word']}，{taste}味从 {old} 变为 {new} 级"
            else:
                return "味道调淡了一点"
        
        # 基本味道
        taste, intensity, info = self.parse_taste(text)
        if taste:
            if intensity < 3:
                desc = f"微微的{taste}味"
            elif intensity < 6:
                desc = f"{taste}味"
            elif intensity < 8:
                desc = f"很{taste}"
            else:
                desc = f"非常{taste}"
            return f"{desc}：{info['比喻']}，强度{intensity}级"
        
        return "我不太理解这个味道"
    
    def set_taste_intensity(self, taste, intensity):
        """设置某种味道的强度"""
        if taste in self.current_tastes:
            self.current_tastes[taste] = max(0, min(10, intensity))
    
    def get_taste_status(self):
        """获取当前味道状态"""
        status = []
        for taste, intensity in self.current_tastes.items():
            if intensity > 0:
                if intensity < 3:
                    status.append(f"微微{taste}")
                elif intensity < 6:
                    status.append(f"{taste}")
                elif intensity < 8:
                    status.append(f"很{taste}")
                else:
                    status.append(f"非常{taste}")
        if not status:
            return "几乎没有味道"
        return "、".join(status)
    
    def is_too_strong(self, taste=None):
        """判断是否太浓"""
        if taste:
            return self.current_tastes.get(taste, 0) > 7
        return any(v > 7 for v in self.current_tastes.values())
    
    def suggest_action(self):
        """建议行动"""
        strong = [t for t, v in self.current_tastes.items() if v > 7]
        if strong:
            return f"{'、'.join(strong)}味太重，建议调整"
        return "味道适中"