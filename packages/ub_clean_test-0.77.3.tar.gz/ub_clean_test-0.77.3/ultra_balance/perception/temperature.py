import re

class TemperaturePerception:
    """
    温度感知模块：理解温度概念
    """
    
    def __init__(self):
        # 模糊温度词映射（摄氏度）
        self.fuzzy_temps = {
            '极冷': -20,
            '很冷': 0,
            '冷': 10,
            '凉快': 18,
            '正常': 22,
            '温暖': 25,
            '热': 30,
            '很热': 38,
            '极热': 40,
        }
        
        # 相对温度调整（摄氏度）
        self.relative_adjust = {
            '再热一点': 2,
            '热一点': 2,
            '再冷一点': -2,
            '冷一点': -2,
            '升温': 3,
            '降温': -3,
        }
        
        self.current_temp = 22.0
        self.comfort_min = 18.0
        self.comfort_max = 26.0
    
    def parse_temp_word(self, text):
        """解析模糊温度词"""
        for word, temp in self.fuzzy_temps.items():
            if word in text:
                return temp, word
        return None, None
    
    def parse_exact_temp(self, text):
        """解析具体温度"""
        patterns = [
            (r'(\d+(?:\.\d+)?)\s*度', 1.0),
            (r'(\d+(?:\.\d+)?)\s*摄氏度', 1.0),
        ]
        
        for pattern, factor in patterns:
            match = re.search(pattern, text)
            if match:
                value = float(match.group(1))
                return value * factor, f"{value}{text[match.end():]}"
        return None, None
    
    def parse_relative_temp(self, text):
        """解析相对温度调整"""
        for word, delta in self.relative_adjust.items():
            if word in text:
                return delta, word
        return None, None
    
    def understand(self, text):
        """理解温度表达"""
        # 模糊温度词
        temp, word = self.parse_temp_word(text)
        if temp is not None:
            return f"{word} 大概 {temp} 度"
        
        # 具体温度
        temp, desc = self.parse_exact_temp(text)
        if temp is not None:
            return f"{desc} 是 {temp:.1f} 度"
        
        # 相对温度
        delta, word = self.parse_relative_temp(text)
        if delta:
            new_temp = self.current_temp + delta
            return f"{word}，温度从 {self.current_temp} 变为 {new_temp:.1f} 度"
        
        return "我不太理解这个温度"
    
    def set_current_temp(self, temp):
        """设置当前温度"""
        self.current_temp = temp
    
    def is_comfortable(self):
        """判断是否舒适"""
        return self.comfort_min <= self.current_temp <= self.comfort_max
    
    def get_temp_status(self):
        """获取温度状态"""
        if self.current_temp < self.comfort_min:
            return f"当前温度 {self.current_temp} 度，有点冷"
        elif self.current_temp > self.comfort_max:
            return f"当前温度 {self.current_temp} 度，有点热"
        else:
            return f"当前温度 {self.current_temp} 度，舒适"
    
    def suggest_action(self):
        """建议行动"""
        if self.current_temp < self.comfort_min:
            return "有点冷，建议开暖气或加衣服"
        elif self.current_temp > self.comfort_max:
            return "有点热，建议开空调或风扇"
        else:
            return "温度舒适，无需调整"