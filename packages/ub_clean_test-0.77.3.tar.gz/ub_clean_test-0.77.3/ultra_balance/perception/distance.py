import re

class DistancePerception:
    """
    距离感知模块：理解距离概念
    """
    
    def __init__(self):
        # 模糊距离词映射（米）
        self.fuzzy_distances = {
            '很近': 0.5,
            '近': 1.0,
            '有点远': 5.0,
            '远': 10.0,
            '很远': 20.0,
            '非常远': 50.0,
        }
        
        # 相对移动词映射（米）
        self.relative_moves = {
            '往前一点': 0.5,
            '往前': 1.0,
            '再往前': 0.5,
            '往左一点': 0.5,
            '往右一点': 0.5,
            '后退一点': 0.5,
        }
    
    def parse_distance_word(self, text):
        """解析模糊距离词"""
        for word, meters in self.fuzzy_distances.items():
            if word in text:
                return meters, word
        return None, None
    
    def parse_exact_distance(self, text):
        """解析具体距离，如“5米”、“10厘米”"""
        # 匹配数字+单位
        patterns = [
            (r'(\d+(?:\.\d+)?)\s*米', 1.0),      # 米
            (r'(\d+(?:\.\d+)?)\s*厘米', 0.01),   # 厘米
            (r'(\d+(?:\.\d+)?)\s*公里', 1000.0), # 公里
        ]
        
        for pattern, factor in patterns:
            match = re.search(pattern, text)
            if match:
                value = float(match.group(1))
                return value * factor, f"{value}{text[match.end():]}"
        return None, None
    
    def parse_relative_move(self, text):
        """解析相对移动指令"""
        for word, meters in self.relative_moves.items():
            if word in text:
                return meters, word
        return None, None
    
    def understand(self, text):
        """理解距离表达"""
        # 模糊距离词
        meters, word = self.parse_distance_word(text)
        if meters:
            return f"{word} 大概 {meters} 米"
        
        # 具体距离
        meters, desc = self.parse_exact_distance(text)
        if meters:
            return f"{desc} 是 {meters} 米"
        
        # 相对移动
        meters, word = self.parse_relative_move(text)
        if meters:
            return f"{word} 移动 {meters} 米"
        
        return "我不太理解这个距离"
    
    def is_near(self, distance, threshold=2.0):
        """判断距离是否近"""
        return distance <= threshold
    
    def is_far(self, distance, threshold=10.0):
        """判断距离是否远"""
        return distance >= threshold