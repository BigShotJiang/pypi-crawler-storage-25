class PersonalityTuner:
    """
    人格调节模块：调整机器人的性格
    """
    
    def __init__(self):
        # 性格参数 (0-1)
        self.traits = {
            '外向': 0.5,    # 0=内向, 1=外向
            '乐观': 0.5,    # 0=悲观, 1=乐观
            '幽默': 0.5,    # 0=严肃, 1=幽默
            '热情': 0.5,    # 0=冷淡, 1=热情
        }
        
        self.personality_name = '平衡型'
    
    def set_trait(self, trait, value):
        """设置性格参数"""
        if trait in self.traits:
            self.traits[trait] = max(0, min(1, value))
            self._update_name()
            return f"已将 {trait} 设为 {value:.1f}"
        return f"不支持的性格: {trait}"
    
    def _update_name(self):
        """根据参数更新性格名称"""
        if self.traits['外向'] > 0.7:
            if self.traits['幽默'] > 0.7:
                self.personality_name = '活泼型'
            else:
                self.personality_name = '热情型'
        elif self.traits['外向'] < 0.3:
            if self.traits['乐观'] > 0.7:
                self.personality_name = '温和型'
            else:
                self.personality_name = '安静型'
        else:
            self.personality_name = '平衡型'
    
    def get_personality(self):
        """获取当前性格"""
        return {
            'name': self.personality_name,
            'traits': self.traits.copy()
        }
    
    def express(self, message):
        """根据性格表达消息"""
        style = ''
        
        # 外向性影响
        if self.traits['外向'] > 0.7:
            style += '！' * int(self.traits['外向'] * 2)
        elif self.traits['外向'] < 0.3:
            style += '...'
        
        # 幽默性影响
        if self.traits['幽默'] > 0.7:
            message = message.replace('好的', '好嘞~').replace('知道了', '明白啦！')
        
        # 乐观性影响
        if self.traits['乐观'] > 0.7:
            style = '！' + style
        elif self.traits['乐观'] < 0.3:
            style = style + '唉'
        
        return f"{message}{style}"
    
    def preset(self, name):
        """使用预设性格"""
        presets = {
            '活泼': {'外向': 0.9, '乐观': 0.8, '幽默': 0.9, '热情': 0.9},
            '温和': {'外向': 0.4, '乐观': 0.8, '幽默': 0.5, '热情': 0.6},
            '严肃': {'外向': 0.3, '乐观': 0.4, '幽默': 0.2, '热情': 0.3},
            '安静': {'外向': 0.2, '乐观': 0.5, '幽默': 0.3, '热情': 0.4},
        }
        
        if name in presets:
            for trait, value in presets[name].items():
                self.traits[trait] = value
            self._update_name()
            return f"已切换为 {name} 型性格"
        return f"不支持的预设: {name}"