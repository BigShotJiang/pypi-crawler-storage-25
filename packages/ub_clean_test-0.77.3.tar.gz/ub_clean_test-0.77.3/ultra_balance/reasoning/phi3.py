import subprocess

class Phi3Client:
    def __init__(self):
        self.available = self._check()
    
    def _check(self):
        try:
            result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
            return "phi3:mini" in result.stdout
        except:
            return False
    
    def chat(self, prompt):
        if not self.available:
            return None
        try:
            result = subprocess.run(["ollama", "run", "phi3:mini", prompt], capture_output=True, text=True, timeout=30)
            return result.stdout.strip()
        except:
            return None