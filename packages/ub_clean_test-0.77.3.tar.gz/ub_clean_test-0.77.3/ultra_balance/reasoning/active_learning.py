from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import random


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


@dataclass
class KnowledgeItem:
    content: str
    category: str
    source: str
    confidence: float
    usage_count: int = 0
    success_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_used: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class QuestionRecord:
    question: str
    context: str
    answer: Optional[str] = None
    answered: bool = False
    asked_at: str = field(default_factory=lambda: datetime.now().isoformat())


class ActiveLearning:
    
    def __init__(self):
        self.knowledge_base: Dict[str, KnowledgeItem] = {}
        self.question_history: List[QuestionRecord] = []
        self.learning_log: List[Dict] = []
        self.confidence_threshold = 0.6
        self.curiosity_level = 0.7
        self._init_base_knowledge()
    
    def _init_base_knowledge(self):
        base_knowledge = [
            ("下雨天要带伞", "common_sense", "system"),
            ("水往低处流", "common_sense", "system"),
            ("见到长辈要打招呼", "common_sense", "system"),
            ("如果下雨，地会湿", "rule", "system"),
            ("所有人都会死", "fact", "system"),
        ]
        for content, category, source in base_knowledge:
            self.add_knowledge(content, category, source, confidence=0.9)
    
    def detect_gaps(self, task: str, context: Dict = None) -> List[str]:
        if context is None:
            context = {}
        
        gaps = []
        task_requirements = {
            "出门": ["天气", "带伞", "锁门"],
            "做饭": ["食材", "厨具", "菜谱"],
            "学习": ["教材", "时间", "目标"],
            "工作": ["任务", "截止时间", "工具"],
            "旅行": ["目的地", "交通", "住宿"],
        }
        
        for key, requirements in task_requirements.items():
            if key in task:
                for req in requirements:
                    if not self.has_knowledge(req):
                        gaps.append(req)
        
        explicit_needs = context.get("needs", [])
        gaps.extend([n for n in explicit_needs if not self.has_knowledge(n)])
        
        return gaps
    
    def has_knowledge(self, topic: str) -> bool:
        for key in self.knowledge_base.keys():
            if topic in key or key in topic:
                item = self.knowledge_base[key]
                if item.confidence >= self.confidence_threshold:
                    return True
        return False
    
    def get_knowledge_confidence(self, topic: str) -> float:
        for key, item in self.knowledge_base.items():
            if topic in key or key in topic:
                return item.confidence
        return 0.0
    
    def ask_question(self, gap: str, context: str = "") -> str:
        question_templates = {
            "天气": "请问今天天气怎么样？",
            "带伞": "需要带伞吗？",
            "锁门": "出门前记得锁门吗？",
            "食材": "请问需要什么食材？",
            "时间": "请问什么时候开始？",
            "目的地": "请问目的地是哪里？",
            "交通": "请问选择什么交通工具？",
        }
        
        for key, question in question_templates.items():
            if key in gap:
                return question
        
        return f"请问关于“{gap}”的信息是什么？"
    
    def ask_uncertain(self, topic: str, current_confidence: float) -> str:
        if current_confidence >= self.confidence_threshold:
            return None
        
        templates = [
            f"关于“{topic}”，我不太确定，能确认一下吗？",
            f"“{topic}”是这样吗？请告诉我是否正确。",
            f"我需要确认一下：“{topic}”，对吗？",
        ]
        return random.choice(templates)
    
    def learn_from_answer(self, question: str, answer: str, context: str = "") -> Dict:
        q_record = QuestionRecord(
            question=question,
            context=context,
            answer=answer,
            answered=True
        )
        self.question_history.append(q_record)
        
        knowledge = self._extract_knowledge(question, answer)
        
        if knowledge:
            self.add_knowledge(
                content=knowledge,
                category="learned",
                source="user_teaching",
                confidence=0.8
            )
            self._log_learning("learn_from_answer", knowledge, success=True)
            
            return {
                "learned": True,
                "knowledge": knowledge,
                "confidence": 0.8
            }
        
        self._log_learning("learn_from_answer", answer, success=False)
        
        return {
            "learned": False,
            "knowledge": None,
            "confidence": 0.0
        }
    
    def _extract_knowledge(self, question: str, answer: str) -> Optional[str]:
        if "下雨" in question and "是" in answer:
            return "今天下雨"
        if "下雨" in question and "不" in answer:
            return "今天不下雨"
        if "带伞" in question and "是" in answer:
            return "需要带伞"
        if "锁门" in question and "是" in answer:
            return "出门要锁门"
        
        if len(answer) > 2 and len(answer) < 50:
            return answer
        
        return None
    
    def add_knowledge(self, content: str, category: str, source: str, confidence: float = 0.7):
        key = content
        if key not in self.knowledge_base:
            self.knowledge_base[key] = KnowledgeItem(
                content=content,
                category=category,
                source=source,
                confidence=confidence
            )
        else:
            old = self.knowledge_base[key]
            old.confidence = (old.confidence + confidence) / 2
            old.usage_count += 1
    
    def verify_knowledge(self, knowledge: str, evidence: str) -> Dict:
        if knowledge not in self.knowledge_base:
            return {
                "verified": False,
                "new_confidence": 0.0,
                "explanation": f"知识“{knowledge}”不存在"
            }
        
        item = self.knowledge_base[knowledge]
        
        if self._supports(knowledge, evidence):
            new_confidence = min(1.0, item.confidence + 0.2)
            self.knowledge_base[knowledge].confidence = new_confidence
            self.knowledge_base[knowledge].success_count += 1
            
            return {
                "verified": True,
                "new_confidence": new_confidence,
                "explanation": f"证据支持“{knowledge}”，置信度提升至{new_confidence:.0%}"
            }
        elif self._contradicts(knowledge, evidence):
            new_confidence = max(0.0, item.confidence - 0.3)
            self.knowledge_base[knowledge].confidence = new_confidence
            
            return {
                "verified": False,
                "new_confidence": new_confidence,
                "explanation": f"证据与“{knowledge}”矛盾，置信度降至{new_confidence:.0%}"
            }
        
        return {
            "verified": None,
            "new_confidence": item.confidence,
            "explanation": f"证据与“{knowledge}”无关，置信度不变"
        }
    
    def _supports(self, knowledge: str, evidence: str) -> bool:
        support_pairs = [
            ("下雨", "雨伞"),
            ("下雨", "雨衣"),
            ("下雨", "打伞"),
            ("下雨", "湿"),
            ("热", "开空调"),
            ("冷", "穿衣服"),
        ]
        for k, e in support_pairs:
            if k in knowledge and e in evidence:
                return True
        return False
    
    def _contradicts(self, knowledge: str, evidence: str) -> bool:
        contradict_pairs = [
            ("下雨", "晴天"),
            ("下雨", "太阳"),
            ("下雨", "晴朗"),
            ("热", "冷"),
            ("冷", "热"),
        ]
        for k, e in contradict_pairs:
            if k in knowledge and e in evidence:
                return True
        return False
    
    def record_experience(self, task: str, success: bool, details: Dict = None):
        experience = {
            "task": task,
            "success": success,
            "timestamp": datetime.now().isoformat(),
            "details": details or {}
        }
        self.learning_log.append(experience)
        
        if success:
            self._reinforce_related_knowledge(task)
    
    def _reinforce_related_knowledge(self, task: str):
        for key, item in self.knowledge_base.items():
            if task in key or key in task:
                item.success_count += 1
                item.confidence = min(1.0, item.confidence + 0.05)
                item.last_used = datetime.now().isoformat()
    
    def get_success_rate(self, task: str = None) -> float:
        relevant_logs = self.learning_log
        if task:
            relevant_logs = [l for l in self.learning_log if l.get("task") and task in l["task"]]
        
        if not relevant_logs:
            return 0.0
        
        successes = sum(1 for l in relevant_logs if l.get("success", False))
        return successes / len(relevant_logs)
    
    def explore(self) -> Dict:
        low_conf_items = [(k, v) for k, v in self.knowledge_base.items() 
                          if v.confidence < self.confidence_threshold]
        
        if low_conf_items and random.random() < self.curiosity_level:
            topic, item = min(low_conf_items, key=lambda x: x[1].confidence)
            question = self.ask_uncertain(topic, item.confidence)
            return {
                "topic": topic,
                "current_confidence": item.confidence,
                "question": question
            }
        
        new_topics = ["机器学习", "天气预报", "股票行情", "新闻摘要"]
        topic = random.choice(new_topics)
        
        return {
            "topic": topic,
            "current_confidence": 0.0,
            "question": f"我想学习{topic}，你能教我吗？"
        }
    
    def get_statistics(self) -> Dict:
        total = len(self.knowledge_base)
        learned = sum(1 for v in self.knowledge_base.values() 
                      if v.source == "user_teaching")
        high_conf = sum(1 for v in self.knowledge_base.values() 
                        if v.confidence >= 0.8)
        
        return {
            "total_knowledge": total,
            "learned_from_user": learned,
            "high_confidence_count": high_conf,
            "questions_asked": len(self.question_history),
            "questions_answered": sum(1 for q in self.question_history if q.answered),
            "total_experiences": len(self.learning_log),
            "success_rate": self.get_success_rate(),
            "curiosity_level": self.curiosity_level
        }
    
    def _log_learning(self, action: str, content: str, success: bool):
        self.learning_log.append({
            "action": action,
            "content": content,
            "success": success,
            "timestamp": datetime.now().isoformat()
        })