from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import uuid


class TrustLevel(Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    NONE = "none"


class AssistanceType(Enum):
    EXPLAIN = "explain"
    DEMONSTRATE = "demonstrate"
    SUGGEST = "suggest"
    WARN = "warn"
    EXECUTE = "execute"


@dataclass
class Human:
    id: str
    name: str
    preferences: Dict[str, Any]
    trust_level: TrustLevel = TrustLevel.MEDIUM
    interaction_history: List[Dict] = field(default_factory=list)


@dataclass
class Instruction:
    id: str
    content: str
    from_human: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    executed: bool = False
    feedback: Optional[str] = None


@dataclass
class CollaborationTask:
    id: str
    description: str
    human_role: str
    robot_role: str
    status: str = "pending"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_at: Optional[str] = None


class HumanRobotCollaboration:
    """
    人机协作模块 (0.68.0)
    能力：理解人类指令、主动汇报、请求帮助、适应性响应、信任建立
    """
    
    def __init__(self):
        self.humans: Dict[str, Human] = {}
        self.instructions: List[Instruction] = []
        self.collaboration_tasks: List[CollaborationTask] = []
        self.assistance_history: List[Dict] = []
        self.current_human_id: Optional[str] = None
        
        # 初始化示例人类
        self._init_example_humans()
    
    def _init_example_humans(self):
        """初始化示例人类"""
        example_humans = [
            ("human_1", "用户A", {"语言": "中文", "详细程度": "简洁", "偏好": "快速响应"}),
            ("human_2", "用户B", {"语言": "中文", "详细程度": "详细", "偏好": "安全优先"}),
            ("human_3", "管理员", {"语言": "中文", "详细程度": "专业", "偏好": "精确控制"}),
        ]
        for hid, name, prefs in example_humans:
            self.register_human(hid, name, prefs)
        self.current_human_id = "human_1"
    
    # ========== 1. 人类注册 ==========
    def register_human(self, human_id: str, name: str, preferences: Dict = None) -> bool:
        """
        注册人类用户
        
        参数：
            human_id: 人类ID
            name: 名称
            preferences: 偏好设置
            
        返回：
            是否成功
        """
        if human_id in self.humans:
            return False
        
        if preferences is None:
            preferences = {}
        
        human = Human(
            id=human_id,
            name=name,
            preferences=preferences
        )
        self.humans[human_id] = human
        
        self._log_assistance("register_human", human_id, f"{name} 已注册")
        return True
    
    def set_current_human(self, human_id: str) -> bool:
        """设置当前交互的人类"""
        if human_id in self.humans:
            self.current_human_id = human_id
            return True
        return False
    
    # ========== 2. 理解人类指令 ==========
    def understand_instruction(self, instruction: str, context: Dict = None) -> Dict:
        """
        理解人类指令
        
        参数：
            instruction: 指令文本
            context: 上下文
            
        返回：
            {
                "intent": str,
                "entities": Dict,
                "confidence": float,
                "response": str
            }
        """
        if context is None:
            context = {}
        
        # 意图识别
        intent = self._recognize_intent(instruction)
        
        # 实体提取
        entities = self._extract_entities(instruction)
        
        # 置信度评估
        confidence = self._calculate_confidence(instruction, intent, entities)
        
        # 生成响应
        response = self._generate_response(intent, entities, context)
        
        # 记录指令
        if confidence > 0.5:
            self._record_instruction(instruction, intent, entities)
        
        return {
            "intent": intent,
            "entities": entities,
            "confidence": confidence,
            "response": response
        }
    
    def _recognize_intent(self, instruction: str) -> str:
        """识别指令意图"""
        instruction_lower = instruction.lower()
        
        intent_patterns = {
            "move": ["去", "走到", "移动到", "前进", "后退", "左转", "右转"],
            "pick": ["拿", "取", "抓", "捡", "拾取"],
            "place": ["放", "放置", "摆放", "放下"],
            "ask": ["什么", "哪里", "怎么", "为什么", "多少", "?"],
            "stop": ["停", "停止", "停下", "别动"],
            "follow": ["跟着", "跟随", "跟我来"],
            "wait": ["等", "等待", "稍等"],
            "report": ["报告", "汇报", "状态", "情况"],
        }
        
        for intent, patterns in intent_patterns.items():
            for pattern in patterns:
                if pattern in instruction_lower:
                    return intent
        
        return "unknown"
    
    def _extract_entities(self, instruction: str) -> Dict:
        """提取实体"""
        entities = {}
        
        # 位置实体
        places = ["厨房", "客厅", "卧室", "餐厅", "书房", "门口", "窗边"]
        for place in places:
            if place in instruction:
                entities["place"] = place
                break
        
        # 物体实体
        objects = ["水", "杯子", "手机", "遥控器", "书", "笔", "钥匙", "钱包"]
        for obj in objects:
            if obj in instruction:
                entities["object"] = obj
                break
        
        # 方向实体
        directions = ["前", "后", "左", "右", "上", "下"]
        for direction in directions:
            if direction in instruction:
                entities["direction"] = direction
                break
        
        return entities
    
    def _calculate_confidence(self, instruction: str, intent: str, entities: Dict) -> float:
        """计算指令理解置信度"""
        confidence = 0.5
        
        if intent != "unknown":
            confidence += 0.2
        
        if entities:
            confidence += 0.2
        
        if len(instruction) > 2:
            confidence += 0.1
        
        return min(1.0, confidence)
    
    def _generate_response(self, intent: str, entities: Dict, context: Dict) -> str:
        """生成响应"""
        # 获取当前用户的偏好
        human = self.humans.get(self.current_human_id)
        detail_level = human.preferences.get("详细程度", "简洁") if human else "简洁"
        
        if intent == "move":
            place = entities.get("place", "目标位置")
            if detail_level == "详细":
                return f"好的，正在向{place}移动。已规划最优路径，预计需要30秒。"
            return f"好的，去{place}。"
        
        elif intent == "pick":
            obj = entities.get("object", "物品")
            if detail_level == "详细":
                return f"好的，正在抓取{obj}。已确认物体位置，准备执行抓取动作。"
            return f"好的，拿{obj}。"
        
        elif intent == "place":
            obj = entities.get("object", "物品")
            return f"好的，放下{obj}。"
        
        elif intent == "ask":
            return "根据当前信息，我建议您检查一下周围环境。需要我详细说明吗？"
        
        elif intent == "stop":
            return "已停止。"
        
        elif intent == "follow":
            return "好的，我会跟着您。"
        
        elif intent == "wait":
            return "好的，我会等待您的下一个指令。"
        
        elif intent == "report":
            return self._generate_status_report()
        
        else:
            if detail_level == "详细":
                return f"我不太确定您的意思。您是想让我移动、拿取物品，还是其他操作？请说得更清楚一些。"
            return "请再说一遍？"
    
    def _generate_status_report(self) -> str:
        """生成状态报告"""
        return f"当前状态正常。电池电量{self._get_battery():.0f}%，所有系统运行良好。"
    
    def _get_battery(self) -> float:
        """获取电池电量（模拟）"""
        import random
        return random.uniform(70, 100)
    
    def _record_instruction(self, instruction: str, intent: str, entities: Dict):
        """记录指令"""
        inst_id = str(uuid.uuid4())[:8]
        inst = Instruction(
            id=inst_id,
            content=instruction,
            from_human=self.current_human_id
        )
        self.instructions.append(inst)
    
    # ========== 3. 主动汇报 ==========
    def report_status(self, status_type: str, details: Dict = None) -> str:
        """
        主动向人类汇报状态
        
        参数：
            status_type: 状态类型 (status/alert/question)
            details: 详细信息
            
        返回：
            汇报内容
        """
        if details is None:
            details = {}
        
        human = self.humans.get(self.current_human_id)
        detail_level = human.preferences.get("详细程度", "简洁") if human else "简洁"
        
        if status_type == "status":
            if detail_level == "详细":
                return f"【状态汇报】当前电量{self._get_battery():.0f}%，位置: {details.get('position', '未知')}，所有功能正常。"
            return f"当前状态正常，电量{self._get_battery():.0f}%。"
        
        elif status_type == "alert":
            return f"?? 注意: {details.get('message', '检测到异常')}"
        
        elif status_type == "question":
            return f"? 请问: {details.get('question', '需要您的确认')}"
        
        return "状态正常"
    
    # ========== 4. 请求帮助 ==========
    def request_help(self, task: str, reason: str) -> str:
        """
        向人类请求帮助
        
        参数：
            task: 任务描述
            reason: 需要帮助的原因
            
        返回：
            帮助请求消息
        """
        message = f"我需要帮助: {task}\n原因: {reason}\n请指导我完成这个任务。"
        
        self._log_assistance("request_help", task, reason)
        
        return message
    
    def provide_help(self, instruction: str) -> Dict:
        """
        人类提供帮助（处理请求）
        
        参数：
            instruction: 帮助指令
            
        返回：
            处理结果
        """
        result = self.understand_instruction(instruction)
        return result
    
    # ========== 5. 适应性响应 ==========
    def adaptive_response(self, user_input: str, context: Dict = None) -> Dict:
        """
        根据用户偏好适应性响应
        
        参数：
            user_input: 用户输入
            context: 上下文
            
        返回：
            适应性响应
        """
        if context is None:
            context = {}
        
        # 获取用户偏好
        human = self.humans.get(self.current_human_id)
        if not human:
            human = self.humans.get("human_1")
        
        # 根据偏好调整响应风格
        detail_level = human.preferences.get("详细程度", "简洁") if human else "简洁"
        response_style = human.preferences.get("偏好", "快速响应") if human else "快速响应"
        
        # 理解指令
        understanding = self.understand_instruction(user_input, context)
        
        # 根据偏好调整响应
        if detail_level == "简洁":
            understanding["response"] = self._simplify_response(understanding["response"])
        elif detail_level == "详细":
            understanding["response"] = self._detail_response(understanding["response"])
        
        if response_style == "安全优先":
            understanding["response"] = f"【安全确认】{understanding['response']}"
        
        # 记录交互
        self._record_interaction(human, user_input, understanding["response"])
        
        return understanding
    
    def _simplify_response(self, response: str) -> str:
        """简化响应"""
        # 简单截断或简化
        if len(response) > 50:
            return response[:50] + "..."
        return response
    
    def _detail_response(self, response: str) -> str:
        """详细响应"""
        # 添加更多细节
        if "好的" in response and "正在" not in response:
            response = response.replace("好的", "好的，我已收到指令")
        return response
    
    def _record_interaction(self, human: Human, user_input: str, response: str):
        """记录交互历史"""
        human.interaction_history.append({
            "input": user_input,
            "response": response,
            "timestamp": datetime.now().isoformat()
        })
        # 保持最近50条
        if len(human.interaction_history) > 50:
            human.interaction_history = human.interaction_history[-50:]
    
    # ========== 6. 信任建立 ==========
    def update_trust(self, human_id: str, success: bool, task: str) -> TrustLevel:
        """
        根据任务执行结果更新信任度
        
        参数：
            human_id: 人类ID
            success: 是否成功
            task: 任务描述
            
        返回：
            新的信任等级
        """
        if human_id not in self.humans:
            return TrustLevel.NONE
        
        human = self.humans[human_id]
        current_trust = human.trust_level
        
        # 信任度调整
        if success:
            # 成功提升信任
            if current_trust == TrustLevel.NONE:
                new_trust = TrustLevel.LOW
            elif current_trust == TrustLevel.LOW:
                new_trust = TrustLevel.MEDIUM
            elif current_trust == TrustLevel.MEDIUM:
                new_trust = TrustLevel.HIGH
            else:
                new_trust = TrustLevel.HIGH
        else:
            # 失败降低信任
            if current_trust == TrustLevel.HIGH:
                new_trust = TrustLevel.MEDIUM
            elif current_trust == TrustLevel.MEDIUM:
                new_trust = TrustLevel.LOW
            else:
                new_trust = TrustLevel.NONE
        
        human.trust_level = new_trust
        
        self._log_assistance("update_trust", human_id, 
                            f"{current_trust.value} → {new_trust.value}")
        
        return new_trust
    
    def get_trust_level(self, human_id: str) -> str:
        """获取信任等级"""
        if human_id in self.humans:
            return self.humans[human_id].trust_level.value
        return TrustLevel.NONE.value
    
    # ========== 7. 协作任务管理 ==========
    def create_collaboration_task(self, description: str, human_role: str, 
                                   robot_role: str) -> str:
        """
        创建协作任务
        
        参数：
            description: 任务描述
            human_role: 人类角色
            robot_role: 机器人角色
            
        返回：
            任务ID
        """
        task_id = f"COLAB_{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.collaboration_tasks)}"
        
        task = CollaborationTask(
            id=task_id,
            description=description,
            human_role=human_role,
            robot_role=robot_role
        )
        self.collaboration_tasks.append(task)
        
        self._log_assistance("create_task", task_id, description)
        
        return task_id
    
    def complete_collaboration_task(self, task_id: str, success: bool = True) -> bool:
        """
        完成协作任务
        
        参数：
            task_id: 任务ID
            success: 是否成功
            
        返回：
            是否成功
        """
        for task in self.collaboration_tasks:
            if task.id == task_id:
                task.status = "completed" if success else "failed"
                task.completed_at = datetime.now().isoformat()
                
                # 更新信任度
                if success:
                    self.update_trust(self.current_human_id, True, task.description)
                
                return True
        return False
    
    # ========== 8. 统计报告 ==========
    def get_statistics(self) -> Dict:
        """获取协作统计"""
        total_instructions = len(self.instructions)
        
        # 信任度分布
        trust_dist = {t.value: 0 for t in TrustLevel}
        for human in self.humans.values():
            trust_dist[human.trust_level.value] += 1
        
        return {
            "total_humans": len(self.humans),
            "current_human": self.current_human_id,
            "total_instructions": total_instructions,
            "total_collaboration_tasks": len(self.collaboration_tasks),
            "completed_tasks": len([t for t in self.collaboration_tasks 
                                    if t.status == "completed"]),
            "trust_distribution": trust_dist,
            "assistance_count": len(self.assistance_history)
        }
    
    def _log_assistance(self, action: str, target: str, detail: str):
        """记录协作日志"""
        self.assistance_history.append({
            "action": action,
            "target": target,
            "detail": detail,
            "timestamp": datetime.now().isoformat()
        })
