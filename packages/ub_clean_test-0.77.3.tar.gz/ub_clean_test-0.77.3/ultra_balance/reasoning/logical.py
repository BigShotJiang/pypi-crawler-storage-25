from typing import Dict, List
from enum import Enum


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4


class LogicalReasoning:
    
    def __init__(self):
        self.common_sense = None
    
    def syllogism(self, major: str, minor: str, conclusion: str) -> Dict:
        import re
        
        minor_match = re.search(r'(.+)是(.+)', minor)
        if not minor_match:
            return {"valid": False, "confidence": Confidence.UNCERTAIN,
                    "explanation": "❌ 小前提格式不对，应该是“X是Y”"}
        
        subject = minor_match.group(1)
        category = minor_match.group(2)
        
        if conclusion.startswith(subject):
            if category in major:
                idx = major.find(category)
                attr = major[idx + len(category):].strip()
                if attr.startswith("都"):
                    attr = attr[1:]
                expected = f"{subject}{attr}"
                if conclusion == expected:
                    return {"valid": True, "confidence": Confidence.CERTAIN,
                            "explanation": f"✅ 推理成立：{major}，{minor}，所以{conclusion}"}
        
        if minor in major and conclusion in major:
            return {"valid": True, "confidence": Confidence.LIKELY,
                    "explanation": f"🔍 推理合理：{major}，{minor}，所以{conclusion}"}
        
        return {"valid": False, "confidence": Confidence.UNCERTAIN,
                "explanation": "❌ 推理不成立：前提无法推出结论"}
    
    def if_then(self, condition: str, consequence: str, fact: str) -> Dict:
        if self._match_condition(condition, fact):
            return {"result": consequence, "confidence": Confidence.CERTAIN,
                    "explanation": f"🌧️ 根据“如果{condition}，{consequence}”，因为{fact}，所以{consequence}"}
        return {"result": None, "confidence": Confidence.UNCERTAIN,
                "explanation": f"⚠️ 事实“{fact}”不匹配条件“{condition}”，无法推出结论"}
    
    def reverse_reason(self, condition: str, consequence: str, fact: str) -> Dict:
        if self._match_condition(consequence, fact):
            causes = [condition, "其他原因（如洒水车、漏水等）"]
            return {"possible_causes": causes, "confidence": Confidence.POSSIBLE,
                    "explanation": f"💧 {fact}，可能因为{condition}，也可能是{causes[1]}（置信度60%）"}
        return {"possible_causes": [], "confidence": Confidence.UNCERTAIN,
                "explanation": f"❓ {fact} 不是“{consequence}”的匹配结果"}
    
    def chain_reason(self, rules: List[str], facts: List[str], max_steps: int = 5) -> Dict:
        parsed = []
        for r in rules:
            if "→" in r or "->" in r:
                parts = r.replace("->", "→").split("→")
                if len(parts) == 2:
                    parsed.append((parts[0].strip(), parts[1].strip()))
        
        known = set()
        for f in facts:
            known.add(f)
            known.add(f.rstrip("了"))
        
        derived = []
        steps = 0
        changed = True
        
        while changed and steps < max_steps:
            changed = False
            for cond, cons in parsed:
                cond_variants = [cond, cond + "了"]
                if any(c in known for c in cond_variants) and cons not in known:
                    known.add(cons)
                    derived.append(cons)
                    changed = True
                    steps += 1
                    if steps >= max_steps:
                        break
        
        if derived:
            chain = " → ".join(facts + derived)
            return {"derived_facts": derived, "chain": chain,
                    "explanation": f"🔗 链式推理：{chain}。共推出{len(derived)}个新事实"}
        return {"derived_facts": [], "chain": [],
                "explanation": f"📭 没有推出新事实，已知道：{', '.join(facts)}"}
    
    def _match_condition(self, condition: str, fact: str) -> bool:
        if condition in fact:
            return True
        if condition.rstrip("了") in fact.rstrip("了"):
            return True
        if condition + "了" in fact:
            return True
        syn = {"下雨": ["下雨了", "下起雨", "有雨"], "天黑了": ["天暗了", "晚上", "夜晚"]}
        for k, v in syn.items():
            if condition == k:
                for vv in v:
                    if vv in fact:
                        return True
        return False