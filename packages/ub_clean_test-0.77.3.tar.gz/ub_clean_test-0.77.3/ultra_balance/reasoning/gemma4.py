class Gemma4Client:
    def __init__(self):
        self.available = False