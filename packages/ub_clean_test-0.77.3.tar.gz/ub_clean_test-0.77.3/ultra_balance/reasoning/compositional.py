import re

class CompositionalReasoner:
    """
    组合推理模块：理解复杂句子
    """
    
    def __init__(self):
        self.task_queue = []
    
    def parse(self, text):
        """
        解析复杂句子，返回任务列表
        """
        text_lower = text.lower()
        
        # 多步指令
        if '先' in text_lower and '再' in text_lower:
            return self._parse_sequence(text_lower)
        
        # 条件指令
        if '如果' in text_lower and '就' in text_lower:
            return self._parse_conditional(text_lower)
        
        # 并行指令
        if '一边' in text_lower and '一边' in text_lower:
            return self._parse_parallel(text_lower)
        
        # 否定指令
        if '不要' in text_lower or '别' in text_lower:
            return self._parse_negative(text_lower)
        
        # 简单指令
        return [{'type': 'simple', 'content': text}]
    
    def _parse_sequence(self, text):
        """解析多步指令"""
        result = []
        parts = text.replace('先', '|').replace('再', '|').replace('然后', '|').split('|')
        for p in parts:
            p = p.strip().strip('，').strip('。')
            if p:
                result.append({'type': 'task', 'content': p})
        return result
    
    def _parse_conditional(self, text):
        """解析条件指令"""
        if '如果' in text and '就' in text:
            if_pos = text.find('如果')
            then_pos = text.find('就', if_pos)
            condition = text[if_pos + 2:then_pos].strip()
            # 取“就”之后到下一个逗号或结束
            action_part = text[then_pos + 1:].strip()
            comma_pos = action_part.find('，')
            if comma_pos > 0:
                action = action_part[:comma_pos].strip()
            else:
                action = action_part
            return [{'type': 'conditional', 'condition': condition, 'action': action}]
        return [{'type': 'simple', 'content': text}]
    
    def _parse_parallel(self, text):
        """解析并行指令"""
        parts = text.split('一边')
        tasks = []
        for p in parts:
            p = p.strip()
            if p:
                tasks.append({'type': 'parallel', 'content': p})
        return tasks
    
    def _parse_negative(self, text):
        """解析否定指令"""
        action = text.replace('不要', '').replace('别', '').strip()
        return [{'type': 'negative', 'action': action}]
    
    def execute(self, text, robot):
        """
        执行解析后的指令
        robot: 机器人实例（需要实现 execute_task 方法）
        """
        tasks = self.parse(text)
        results = []
        
        for task in tasks:
            if task['type'] in ['simple', 'task']:
                result = robot.execute_task(task['content'])
            elif task['type'] == 'conditional':
                if self._check_condition(task['condition'], robot):
                    result = robot.execute_task(task['action'])
                else:
                    result = f"条件不满足，跳过 {task['action']}"
            elif task['type'] == 'parallel':
                result = robot.execute_task(task['content'])
            elif task['type'] == 'negative':
                result = f"已阻止：{task['action']}"
            else:
                result = f"未知任务: {task}"
            results.append(result)
        
        return results
    
    def _check_condition(self, condition, robot):
        """检查条件是否满足（简化版）"""
        if '红色' in condition:
            return getattr(robot, 'last_seen_color', 'red') == 'red'
        elif '蓝色' in condition:
            return getattr(robot, 'last_seen_color', 'blue') == 'blue'
        return True