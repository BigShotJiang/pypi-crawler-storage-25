class MetaphorUnderstanding:
    """
    比喻理解模块：理解比喻、成语、隐喻、夸张
    """
    
    def __init__(self):
        # 比喻库
        self.metaphors = {
            '时间就是金钱': '意思是时间很宝贵，要珍惜',
            '光阴似箭': '意思是时间过得很快',
            '度日如年': '意思是时间过得很慢，很难熬',
            '一石二鸟': '意思是一举两得',
            '雪中送炭': '意思是在别人困难时给予帮助',
            '锦上添花': '意思是让好的更好',
            '火上浇油': '意思是让事情更糟',
            '画蛇添足': '意思是多此一举',
            '杯弓蛇影': '意思是疑神疑鬼',
            '对牛弹琴': '意思是跟不懂的人讲道理',
        }
        
        # 隐喻库
        self.metaphors_extended = {
            '心里石头落了地': '意思是终于放心了',
            '心在滴血': '意思是非常心痛',
            '脑袋炸了': '意思是头疼，想不清楚',
            '手忙脚乱': '意思是忙不过来',
            '眼高手低': '意思是要求高，能力低',
        }
        
        # 夸张库
        self.hyperbole = {
            '等了一万年': '意思是等了很久',
            '饿死了': '意思是饿了，不是真的死',
            '笑死我了': '意思是很好笑，不是真的死',
            '累死了': '意思是累了，不是真的死',
            '烦死了': '意思是烦，不是真的死',
        }
    
    def understand(self, text):
        """理解比喻表达"""
        # 比喻
        if text in self.metaphors:
            return f"“{text}” {self.metaphors[text]}"
        
        # 隐喻
        if text in self.metaphors_extended:
            return f"“{text}” {self.metaphors_extended[text]}"
        
        # 夸张
        if text in self.hyperbole:
            return f"“{text}” {self.hyperbole[text]}"
        
        return "我不太理解这个比喻"