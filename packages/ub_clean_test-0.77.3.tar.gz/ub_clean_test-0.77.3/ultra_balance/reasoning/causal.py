class CausalReasoner:
    """
    因果推理模块：理解“为什么”和“会导致什么”
    """
    
    def __init__(self):
        # 因果规则库
        self.causal_rules = {
            'touch_fire': 'burn',
            'fall': 'hurt',
            'low_battery': 'stop',
            'overheat': 'damage_motor',
            'hit_wall': 'damage',
            'water_on_floor': 'slip',
        }
        
        # 反向推理：结果 → 原因
        self.reverse_rules = {
            'burn': 'touch_fire',
            'hurt': 'fall',
            'stop': 'low_battery',
            'damage_motor': 'overheat',
            'damage': 'hit_wall',
            'slip': 'water_on_floor',
        }
    
    def predict_effect(self, action):
        """
        预测某个动作会导致什么结果
        """
        if action in self.causal_rules:
            return self.causal_rules[action]
        return "unknown"
    
    def explain_cause(self, effect):
        """
        解释某个结果是由什么原因导致的
        """
        if effect in self.reverse_rules:
            return self.reverse_rules[effect]
        return "unknown"
    
    def reason(self, situation):
        """
        综合推理：给定情况，应该做什么
        """
        if 'fire' in situation:
            return "不要靠近，会烧伤"
        elif 'water' in situation and 'floor' in situation:
            return "地面有水，小心滑倒"
        elif 'battery' in situation and 'low' in situation:
            return "电量不足，需要充电"
        elif 'motor' in situation and 'hot' in situation:
            return "电机过热，需要冷却"
        else:
            return "情况正常，可以继续"
    
    def what_if(self, action, context):
        """
        假设推理：如果做A，在B环境下会怎样
        """
        effect = self.predict_effect(action)
        if effect == 'burn':
            return f"如果{action}，在{context}下会烧伤"
        elif effect == 'hurt':
            return f"如果{action}，在{context}下会受伤"
        elif effect == 'stop':
            return f"如果{action}，在{context}下会停止工作"
        else:
            return f"如果{action}，在{context}下可能{effect}"