from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import random
import hashlib


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


@dataclass
class Experience:
    """经验记录"""
    id: str
    task: str
    domain: str
    solution: str
    steps: List[str]
    success: bool
    context: Dict
    confidence: float
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    used_count: int = 0


@dataclass
class TransferRule:
    """迁移规则"""
    id: str
    source_domain: str
    target_domain: str
    mapping: Dict[str, str]  # 源领域概念到目标领域概念的映射
    confidence: float
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


class TransferLearning:
    """
    迁移学习模块 (0.65.0)
    能力：经验泛化、领域映射、相似度计算、知识迁移、类比推理
    """
    
    def __init__(self):
        self.experiences: List[Experience] = []
        self.transfer_rules: List[TransferRule] = []
        self.domain_similarity: Dict[str, Dict[str, float]] = {}
        self.transfer_log: List[Dict] = []
        
        # 初始化领域相似度
        self._init_domain_similarity()
        # 初始化示例经验
        self._init_example_experiences()
    
    def _init_domain_similarity(self):
        """初始化领域间相似度"""
        domains = ["导航", "做饭", "清洁", "购物", "学习", "工作", "娱乐"]
        
        # 预定义一些相似度（简化版）
        similarities = {
            ("导航", "购物"): 0.7, ("导航", "清洁"): 0.5,
            ("做饭", "清洁"): 0.6, ("做饭", "购物"): 0.6,
            ("学习", "工作"): 0.8, ("学习", "娱乐"): 0.4,
            ("工作", "购物"): 0.5, ("工作", "娱乐"): 0.3,
        }
        
        for domain in domains:
            self.domain_similarity[domain] = {}
            for other in domains:
                if domain == other:
                    self.domain_similarity[domain][other] = 1.0
                elif (domain, other) in similarities:
                    self.domain_similarity[domain][other] = similarities[(domain, other)]
                elif (other, domain) in similarities:
                    self.domain_similarity[domain][other] = similarities[(other, domain)]
                else:
                    self.domain_similarity[domain][other] = 0.3  # 默认低相似度
    
    def _init_example_experiences(self):
        """初始化示例经验"""
        examples = [
            Experience(
                id=self._generate_id("导航到超市"),
                task="导航到超市",
                domain="导航",
                solution="打开地图 → 输入目的地 → 选择路线 → 开始导航",
                steps=["定位", "搜索目的地", "规划路线", "开始导航"],
                success=True,
                context={"起点": "家", "终点": "超市"},
                confidence=0.9
            ),
            Experience(
                id=self._generate_id("煮面条"),
                task="煮面条",
                domain="做饭",
                solution="烧水 → 下面条 → 煮3-5分钟 → 捞出",
                steps=["烧水", "放面", "计时", "捞出"],
                success=True,
                context={"食材": "面条", "时间": "5分钟"},
                confidence=0.85
            ),
            Experience(
                id=self._generate_id("扫地"),
                task="扫地",
                domain="清洁",
                solution="拿扫把 → 从里向外扫 → 收集垃圾 → 倒掉",
                steps=["准备工具", "清扫", "收集", "处理"],
                success=True,
                context={"区域": "客厅"},
                confidence=0.9
            ),
        ]
        for exp in examples:
            self.experiences.append(exp)
    
    def _generate_id(self, content: str) -> str:
        """生成ID"""
        hash_val = hashlib.md5(content.encode()).hexdigest()[:8]
        return f"EXP_{hash_val}"
    
    # ========== 1. 记录经验 ==========
    def record_experience(self, task: str, domain: str, solution: str, 
                          steps: List[str], success: bool, 
                          context: Dict = None, confidence: float = 0.7) -> str:
        """
        记录成功或失败的经验
        
        参数：
            task: 任务名称
            domain: 领域
            solution: 解决方案描述
            steps: 步骤列表
            success: 是否成功
            context: 上下文
            confidence: 置信度
            
        返回：
            经验ID
        """
        if context is None:
            context = {}
        
        exp_id = self._generate_id(task)
        
        experience = Experience(
            id=exp_id,
            task=task,
            domain=domain,
            solution=solution,
            steps=steps,
            success=success,
            context=context,
            confidence=confidence
        )
        self.experiences.append(experience)
        
        self._log_transfer("record_experience", task, domain, success)
        
        return exp_id
    
    # ========== 2. 查找相似经验 ==========
    def find_similar_experiences(self, task: str, domain: str, 
                                  threshold: float = 0.5) -> List[Dict]:
        """
        查找相似的经验
        
        参数：
            task: 当前任务
            domain: 当前领域
            threshold: 相似度阈值
            
        返回：
            相似经验列表
        """
        similar = []
        
        for exp in self.experiences:
            # 计算相似度
            similarity = self._calculate_similarity(task, exp.task, domain, exp.domain)
            
            if similarity >= threshold:
                similar.append({
                    "id": exp.id,
                    "task": exp.task,
                    "domain": exp.domain,
                    "solution": exp.solution,
                    "steps": exp.steps,
                    "similarity": similarity,
                    "success": exp.success,
                    "confidence": exp.confidence
                })
        
        # 按相似度排序
        similar.sort(key=lambda x: x["similarity"], reverse=True)
        
        return similar
    
    def _calculate_similarity(self, task1: str, task2: str, 
                               domain1: str, domain2: str) -> float:
        """计算两个任务的相似度"""
        similarity = 0.0
        
        # 1. 领域相似度
        domain_sim = self.domain_similarity.get(domain1, {}).get(domain2, 0.3)
        similarity += domain_sim * 0.5
        
        # 2. 任务名关键词相似度
        keywords1 = set(task1)
        keywords2 = set(task2)
        common = len(keywords1 & keywords2)
        total = len(keywords1 | keywords2)
        task_sim = common / total if total > 0 else 0
        similarity += task_sim * 0.3
        
        # 3. 任务长度相似度（简单启发）
        len_sim = 1.0 - abs(len(task1) - len(task2)) / max(len(task1), len(task2))
        similarity += len_sim * 0.2
        
        return min(1.0, similarity)
    
    # ========== 3. 知识迁移 ==========
    def transfer_knowledge(self, source_task: str, target_task: str,
                           source_domain: str, target_domain: str) -> Dict:
        """
        将知识从一个任务迁移到另一个任务
        
        参数：
            source_task: 源任务
            target_task: 目标任务
            source_domain: 源领域
            target_domain: 目标领域
            
        返回：
            {
                "transferred_solution": str,
                "adapted_steps": List[str],
                "confidence": float,
                "explanation": str
            }
        """
        # 查找源任务的经验
        source_exp = None
        for exp in self.experiences:
            if exp.task == source_task and exp.domain == source_domain:
                source_exp = exp
                break
        
        if not source_exp:
            return {
                "transferred_solution": None,
                "adapted_steps": [],
                "confidence": 0.0,
                "explanation": f"未找到源任务“{source_task}”的经验"
            }
        
        # 计算领域相似度
        domain_sim = self.domain_similarity.get(source_domain, {}).get(target_domain, 0.3)
        
        # 如果领域相似度过低，迁移意义不大
        if domain_sim < 0.4:
            return {
                "transferred_solution": source_exp.solution,
                "adapted_steps": source_exp.steps,
                "confidence": source_exp.confidence * domain_sim * 0.5,
                "explanation": f"领域相似度较低({domain_sim:.0%})，迁移可能不准确"
            }
        
        # 进行迁移适配
        adapted_steps = self._adapt_steps(source_exp.steps, source_domain, target_domain)
        transferred_solution = self._adapt_solution(source_exp.solution, source_domain, target_domain)
        
        # 迁移置信度 = 源经验置信度 × 领域相似度
        transfer_confidence = source_exp.confidence * domain_sim
        
        # 记录迁移
        self._log_transfer("transfer", source_task, target_task, transfer_confidence)
        
        # 创建迁移规则
        self._create_transfer_rule(source_domain, target_domain, adapted_steps)
        
        return {
            "transferred_solution": transferred_solution,
            "adapted_steps": adapted_steps,
            "confidence": transfer_confidence,
            "explanation": f"从{source_domain}迁移到{target_domain}，相似度{domain_sim:.0%}"
        }
    
    def _adapt_steps(self, steps: List[str], source_domain: str, target_domain: str) -> List[str]:
        """适配步骤到目标领域"""
        # 领域概念映射
        mappings = {
            ("导航", "购物"): {"定位": "到达商场", "搜索目的地": "寻找商品", "规划路线": "规划购物路线"},
            ("做饭", "清洁"): {"烧水": "准备清洁剂", "下面条": "喷洒", "煮": "擦拭", "捞出": "清理"},
            ("清洁", "做饭"): {"拿扫把": "拿锅", "清扫": "清洗", "收集": "装盘", "倒掉": "上菜"},
        }
        
        adapted = []
        for step in steps:
            new_step = step
            for (src, tgt), mapping in mappings.items():
                if source_domain == src and target_domain == tgt:
                    for old, new in mapping.items():
                        if old in step:
                            new_step = step.replace(old, new)
                            break
            adapted.append(new_step)
        
        return adapted if adapted else steps
    
    def _adapt_solution(self, solution: str, source_domain: str, target_domain: str) -> str:
        """适配解决方案描述"""
        # 简单适配：替换领域关键词
        replacements = {
            ("导航", "购物"): ("导航", "购物", "地图", "商场"),
            ("做饭", "清洁"): ("做饭", "清洁", "食材", "工具"),
        }
        
        adapted = solution
        for (src, tgt), (old1, new1, old2, new2) in replacements.items():
            if source_domain == src and target_domain == tgt:
                adapted = adapted.replace(old1, new1)
                adapted = adapted.replace(old2, new2)
        
        return adapted
    
    def _create_transfer_rule(self, source_domain: str, target_domain: str, 
                               mapping: Dict[str, str]):
        """创建迁移规则"""
        rule_id = f"TR_{source_domain}_{target_domain}_{len(self.transfer_rules)}"
        
        rule = TransferRule(
            id=rule_id,
            source_domain=source_domain,
            target_domain=target_domain,
            mapping=mapping,
            confidence=0.7
        )
        self.transfer_rules.append(rule)
    
    # ========== 4. 类比推理 ==========
    def analogical_reasoning(self, problem: str, domain: str) -> Dict:
        """
        类比推理：从相似问题中找解决方案
        
        参数：
            problem: 当前问题
            domain: 领域
            
        返回：
            {
                "analogy_found": bool,
                "source_problem": str,
                "solution": str,
                "similarity": float
            }
        """
        # 查找相似经验
        similar = self.find_similar_experiences(problem, domain, threshold=0.4)
        
        if not similar:
            return {
                "analogy_found": False,
                "source_problem": None,
                "solution": None,
                "similarity": 0.0,
                "message": "没有找到类似问题的经验"
            }
        
        best = similar[0]
        
        return {
            "analogy_found": True,
            "source_problem": best["task"],
            "source_domain": best["domain"],
            "solution": best["solution"],
            "similarity": best["similarity"],
            "confidence": best["confidence"],
            "message": f"发现类似问题“{best['task']}”(相似度{best['similarity']:.0%})，可以参考其解决方案"
        }
    
    # ========== 5. 泛化经验 ==========
    def generalize_experience(self, experience_ids: List[str]) -> Dict:
        """
        从多个经验中泛化出通用规则
        
        参数：
            experience_ids: 经验ID列表
            
        返回：
            {
                "generalized_rule": str,
                "common_steps": List[str],
                "confidence": float
            }
        """
        # 收集经验
        exps = [e for e in self.experiences if e.id in experience_ids]
        
        if len(exps) < 2:
            return {
                "generalized_rule": None,
                "common_steps": [],
                "confidence": 0.0,
                "message": "需要至少2个经验才能泛化"
            }
        
        # 提取共同步骤模式
        all_steps = [exp.steps for exp in exps]
        
        # 找最长公共子序列（简化版：找常见关键词）
        common_keywords = self._find_common_keywords(all_steps)
        
        # 生成泛化规则
        generalized_rule = self._generate_generalized_rule(exps, common_keywords)
        
        # 计算平均置信度
        avg_confidence = sum(e.confidence for e in exps) / len(exps)
        
        self._log_transfer("generalize", f"{len(exps)}经验", generalized_rule[:50], avg_confidence)
        
        return {
            "generalized_rule": generalized_rule,
            "common_steps": common_keywords,
            "confidence": avg_confidence,
            "experience_count": len(exps)
        }
    
    def _find_common_keywords(self, all_steps: List[List[str]]) -> List[str]:
        """找共同关键词"""
        from collections import Counter
        
        all_words = []
        for steps in all_steps:
            for step in steps:
                all_words.extend(step.split())
        
        counter = Counter(all_words)
        common = [word for word, count in counter.items() if count >= len(all_steps) * 0.5]
        
        return common[:5]
    
    def _generate_generalized_rule(self, exps: List[Experience], 
                                    common_keywords: List[str]) -> str:
        """生成泛化规则"""
        domains = set(e.domain for e in exps)
        
        if len(domains) == 1:
            domain = list(domains)[0]
            return f"在{domain}领域，{', '.join(common_keywords)}是关键步骤"
        else:
            return f"在{', '.join(domains)}等领域，{', '.join(common_keywords)}是通用步骤"
    
    # ========== 6. 领域相似度学习 ==========
    def learn_domain_similarity(self, domain1: str, domain2: str, similarity: float):
        """
        学习领域间相似度
        
        参数：
            domain1: 领域1
            domain2: 领域2
            similarity: 相似度(0-1)
        """
        if domain1 not in self.domain_similarity:
            self.domain_similarity[domain1] = {}
        if domain2 not in self.domain_similarity:
            self.domain_similarity[domain2] = {}
        
        self.domain_similarity[domain1][domain2] = similarity
        self.domain_similarity[domain2][domain1] = similarity
        
        self._log_transfer("learn_similarity", f"{domain1}-{domain2}", f"{similarity}", similarity)
    
    # ========== 7. 迁移建议 ==========
    def suggest_transfer(self, current_domain: str, current_task: str) -> Dict:
        """
        根据当前任务，建议可以从哪些领域迁移知识
        
        返回：
            {
                "suggestions": List[Dict],
                "best_domain": str,
                "best_similarity": float
            }
        """
        suggestions = []
        
        for domain in self.domain_similarity.get(current_domain, {}):
            similarity = self.domain_similarity[current_domain][domain]
            if similarity > 0.5 and domain != current_domain:
                # 查找该领域的成功经验
                domain_exps = [e for e in self.experiences if e.domain == domain and e.success]
                if domain_exps:
                    suggestions.append({
                        "source_domain": domain,
                        "similarity": similarity,
                        "example_task": domain_exps[0].task,
                        "example_solution": domain_exps[0].solution[:50] + "..."
                    })
        
        suggestions.sort(key=lambda x: x["similarity"], reverse=True)
        
        best = suggestions[0] if suggestions else None
        
        return {
            "suggestions": suggestions,
            "best_domain": best["source_domain"] if best else None,
            "best_similarity": best["similarity"] if best else 0.0
        }
    
    # ========== 8. 统计报告 ==========
    def get_statistics(self) -> Dict:
        """获取迁移学习统计"""
        success_exps = sum(1 for e in self.experiences if e.success)
        
        return {
            "total_experiences": len(self.experiences),
            "successful_experiences": success_exps,
            "success_rate": success_exps / len(self.experiences) if self.experiences else 0,
            "total_transfer_rules": len(self.transfer_rules),
            "total_transfers": len(self.transfer_log),
            "domains": list(self.domain_similarity.keys())
        }
    
    def _log_transfer(self, action: str, source: str, target: str, confidence: float):
        """记录迁移日志"""
        self.transfer_log.append({
            "action": action,
            "source": source,
            "target": target,
            "confidence": confidence,
            "timestamp": datetime.now().isoformat()
        })