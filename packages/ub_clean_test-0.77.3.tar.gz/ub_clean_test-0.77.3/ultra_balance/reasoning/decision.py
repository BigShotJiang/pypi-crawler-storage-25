from typing import Dict, List
from enum import Enum


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4


class DecisionReasoning:
    
    def __init__(self):
        self.common_sense = None
        self.decision_history = []
    
    def compare_options(self, options: List[Dict]) -> Dict:
        if not options:
            return {
                "best": None,
                "ranking": [],
                "analysis": "没有可比较的方案"
            }
        
        scored_options = []
        for opt in options:
            name = opt.get("name", "未命名")
            pros = opt.get("pros", [])
            cons = opt.get("cons", [])
            score = len(pros) - len(cons)
            if "score" in opt:
                score = opt["score"]
            scored_options.append({
                "name": name,
                "score": score,
                "pros": pros,
                "cons": cons
            })
        
        scored_options.sort(key=lambda x: x["score"], reverse=True)
        best = scored_options[0]["name"]
        ranking = [opt["name"] for opt in scored_options]
        analysis = self._generate_analysis(scored_options)
        
        return {
            "best": best,
            "ranking": ranking,
            "analysis": analysis,
            "details": scored_options
        }
    
    def weigh_pros_cons(self, pros: List[str], cons: List[str], weights: Dict[str, float] = None) -> Dict:
        if weights is None:
            weights = {}
        
        pro_score = 0
        con_score = 0
        
        for pro in pros:
            weight = weights.get(pro, 1.0)
            pro_score += weight
        
        for con in cons:
            weight = weights.get(con, 1.0)
            con_score += weight
        
        total_score = pro_score - con_score
        
        if total_score > 0:
            verdict = "建议采纳"
        elif total_score < 0:
            verdict = "不建议采纳"
        else:
            verdict = "利弊相当"
        
        analysis = f"优点({len(pros)}项)得分{pro_score:.1f}，缺点({len(cons)}项)得分{con_score:.1f}，综合{verdict}"
        
        return {
            "verdict": verdict,
            "score": total_score,
            "analysis": analysis,
            "pro_score": pro_score,
            "con_score": con_score
        }
    
    def choose_best(self, candidates: List[Dict], criteria: List[str], weights: Dict[str, float] = None) -> Dict:
        if not candidates:
            return {
                "best": None,
                "scores": {},
                "analysis": "没有候选方案"
            }
        
        if weights is None:
            weights = {c: 1.0 for c in criteria}
        
        normalized = {}
        for c in criteria:
            values = [cand.get(c, 0) for cand in candidates]
            max_val = max(values) if values else 1
            min_val = min(values) if values else 0
            
            if max_val == min_val:
                normalized[c] = {i: 1.0 for i in range(len(candidates))}
            else:
                normalized[c] = {}
                for i, val in enumerate(values):
                    if c == "价格" or c == "成本" or c == "花费":
                        normalized[c][i] = (max_val - val) / (max_val - min_val)
                    else:
                        normalized[c][i] = (val - min_val) / (max_val - min_val)
        
        scores = {}
        for i, cand in enumerate(candidates):
            total = 0
            for c in criteria:
                weight = weights.get(c, 1.0)
                total += normalized[c][i] * weight
            scores[cand["name"]] = total
        
        best = max(scores, key=scores.get)
        
        analysis = f"综合评分: {best} 最优"
        for name, score in sorted(scores.items(), key=lambda x: x[1], reverse=True):
            analysis += f"\n  {name}: {score:.2f}"
        
        return {
            "best": best,
            "scores": scores,
            "analysis": analysis
        }
    
    def risk_assessment(self, options: List[Dict]) -> Dict:
        risk_map = {"低": 1, "中": 2, "高": 3}
        reward_map = {"低": 1, "中": 2, "高": 3}
        
        evaluated = []
        for opt in options:
            name = opt.get("name", "未命名")
            risk_str = opt.get("risk", "中")
            reward_str = opt.get("reward", "中")
            
            risk_val = risk_map.get(risk_str, 2)
            reward_val = reward_map.get(reward_str, 2)
            ratio = reward_val / risk_val if risk_val > 0 else 0
            
            evaluated.append({
                "name": name,
                "risk": risk_str,
                "reward": reward_str,
                "ratio": ratio
            })
        
        evaluated.sort(key=lambda x: x["ratio"], reverse=True)
        best = evaluated[0]["name"]
        analysis = f"推荐: {best} (风险:{evaluated[0]['risk']}, 回报:{evaluated[0]['reward']})"
        
        return {
            "recommendation": best,
            "ranking": evaluated,
            "analysis": analysis
        }
    
    def multi_step_decision(self, steps: List[Dict]) -> Dict:
        path = []
        for step in steps:
            question = step.get("question", "")
            path.append(question)
        
        return {
            "path": path,
            "final": "决策完成",
            "analysis": " → ".join(path)
        }
    
    def _generate_analysis(self, scored_options: List[Dict]) -> str:
        if not scored_options:
            return "无方案"
        
        best = scored_options[0]
        analysis = f"最佳方案: {best['name']} (得分{best['score']})\n"
        
        if best['pros']:
            analysis += f"  优点: {', '.join(best['pros'])}\n"
        if best['cons']:
            analysis += f"  缺点: {', '.join(best['cons'])}"
        
        if len(scored_options) > 1:
            analysis += f"\n其他方案: {', '.join([opt['name'] for opt in scored_options[1:]])}"
        
        return analysis