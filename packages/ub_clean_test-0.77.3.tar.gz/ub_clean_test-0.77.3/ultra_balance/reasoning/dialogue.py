from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import hashlib


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


class Intent(Enum):
    GREET = "greet"
    QUESTION = "question"
    COMMAND = "command"
    FEEDBACK = "feedback"
    CLARIFY = "clarify"
    FAREWELL = "farewell"
    UNKNOWN = "unknown"


@dataclass
class Turn:
    turn_id: int
    user_input: str
    bot_response: str
    intent: Intent
    entities: Dict[str, Any]
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Context:
    key: str
    value: Any
    confidence: float
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())


class DialogueManager:
    
    def __init__(self, max_history: int = 20):
        self.history: List[Turn] = []
        self.context: Dict[str, Context] = {}
        self.max_history = max_history
        self.current_turn = 0
        self._init_intent_patterns()
        self._init_entity_patterns()
    
    def _init_intent_patterns(self):
        self.intent_patterns = {
            Intent.GREET: ["你好", "嗨", "早上好", "下午好", "晚上好", "hello", "hi", "您好"],
            Intent.QUESTION: ["什么", "哪个", "怎么", "如何", "为什么", "哪里", "几", "多少", "？", "?"],
            Intent.COMMAND: ["做", "去", "拿", "打开", "关闭", "开始", "停止", "帮", "请"],
            Intent.FAREWELL: ["再见", "拜拜", "bye", "下次见", "告辞", "88"],
            Intent.FEEDBACK: ["对", "不对", "是", "不是", "正确", "错误", "好的", "可以", "不行", "嗯", "哦"],
        }
    
    def _init_entity_patterns(self):
        self.entity_patterns = {
            "time": ["今天", "明天", "昨天", "现在", "然后", "之后", "之前", "早上", "晚上"],
            "place": ["这里", "那里", "家", "公司", "厨房", "客厅", "卧室", "卫生间", "门口"],
            "object": ["水", "饭", "门", "窗", "灯", "空调", "电视", "手机", "钥匙", "钱包"],
            "number": ["一", "二", "三", "四", "五", "1", "2", "3", "4", "5", "十", "百"],
            "person": ["我", "你", "他", "她", "我们", "你们", "他们", "大家"],
        }
    
    def recognize_intent(self, user_input: str) -> Intent:
        user_input_lower = user_input.lower()
        for pattern in ["再见", "拜拜", "bye", "下次见"]:
            if pattern in user_input_lower:
                return Intent.FAREWELL
        for pattern in ["你好", "嗨", "hello", "hi", "您好"]:
            if pattern in user_input_lower:
                return Intent.GREET
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if pattern in user_input_lower:
                    return intent
        return Intent.UNKNOWN
    
    def extract_entities(self, user_input: str) -> Dict[str, Any]:
        entities = {}
        user_input_lower = user_input.lower()
        for entity_type, patterns in self.entity_patterns.items():
            for pattern in patterns:
                if pattern in user_input_lower:
                    if entity_type not in entities:
                        entities[entity_type] = []
                    if pattern not in entities[entity_type]:
                        entities[entity_type].append(pattern)
        return entities
    
    def update_context(self, key: str, value: Any, confidence: float = 0.8):
        self.context[key] = Context(key=key, value=value, confidence=confidence)
    
    def get_context(self, key: str) -> Optional[Any]:
        if key in self.context:
            return self.context[key].value
        return None
    
    def get_all_context(self) -> Dict[str, Any]:
        return {k: v.value for k, v in self.context.items()}
    
    def clear_context(self, key: str = None):
        if key:
            self.context.pop(key, None)
        else:
            self.context.clear()
    
    def infer_from_context(self, user_input: str) -> Dict:
        inferred = {}
        explanation = []
        if "它" in user_input or "这个" in user_input or "那个" in user_input:
            last_object = self.get_context("last_object")
            if last_object:
                inferred["object"] = last_object
                explanation.append(f"指代之前的“{last_object}”")
        if "也" in user_input:
            last_action = self.get_context("last_action")
            if last_action:
                inferred["action"] = last_action
                explanation.append(f"“也”表示执行相同动作“{last_action}”")
        if "然后" in user_input or "之后" in user_input:
            last_time = self.get_context("last_time")
            if last_time:
                inferred["next_time"] = last_time
                explanation.append(f"时间关联到之前的“{last_time}”")
        if "那里" in user_input or "这边" in user_input:
            last_place = self.get_context("last_place")
            if last_place:
                inferred["place"] = last_place
                explanation.append(f"指代之前的“{last_place}”")
        return {
            "has_inference": len(inferred) > 0,
            "inferred_info": inferred,
            "explanation": "; ".join(explanation) if explanation else "无上下文推理"
        }
    
    def need_clarification(self, user_input: str) -> Dict:
        # 精确匹配
        exact_match = ["再见", "拜拜", "bye", "你好", "嗨", "hello", "hi", "您好"]
        if user_input in exact_match:
            return {"need": False, "reason": None, "clarification_question": None}

        # 包含匹配
        if "再见" in user_input or "拜拜" in user_input:
            return {"need": False, "reason": None, "clarification_question": None}
        if "你好" in user_input or "嗨" in user_input:
            return {"need": False, "reason": None, "clarification_question": None}

        if len(user_input) < 2:
            return {"need": True, "reason": "输入太短", "clarification_question": "能说详细一点吗？"}

        has_object = any(o in user_input for o in self.entity_patterns["object"])

        if "去" in user_input and not has_object:
            return {"need": True, "reason": "缺少目的地", "clarification_question": "请问要去哪里？"}

        if "拿" in user_input and not has_object:
            return {"need": True, "reason": "缺少物品", "clarification_question": "请问要拿什么？"}

        ambiguous_words = ["那个", "这个", "那里", "这里"]
        for word in ambiguous_words:
            if word in user_input and user_input.strip() == word:
                if not self.get_context("last_object"):
                    return {"need": True, "reason": f"指代不明（{word}）", "clarification_question": f"你说的{word}具体指什么？"}
        return {"need": False, "reason": None, "clarification_question": None}
    
    def ask_clarification(self, user_input: str) -> Optional[str]:
        clarification = self.need_clarification(user_input)
        if clarification["need"]:
            return clarification["clarification_question"]
        return None
    
    def _update_context_from_input(self, user_input: str, entities: Dict):
        if "去" in user_input or "做" in user_input or "打开" in user_input:
            self.update_context("last_action", user_input[:30])
        if "object" in entities and entities["object"]:
            self.update_context("last_object", entities["object"][0])
        if "place" in entities and entities["place"]:
            self.update_context("last_place", entities["place"][0])
        if "time" in entities and entities["time"]:
            self.update_context("last_time", entities["time"][0])
        self.update_context("last_input", user_input)
    
    def _generate_by_intent(self, user_input: str, intent: Intent, entities: Dict, inference: Dict) -> str:
        if intent == Intent.GREET:
            return "你好！有什么我可以帮你的吗？"
        elif intent == Intent.QUESTION:
            if "last_object" in self.context and "什么" in user_input:
                obj = self.get_context("last_object")
                return f"刚才提到的是{obj}。"
            if "时间" in user_input:
                time = self.get_context("last_time")
                if time:
                    return f"之前说的是{time}。"
            return "让我想想... 你能提供更多信息吗？"
        elif intent == Intent.COMMAND:
            if "action" in self.get_all_context() and "也" in user_input:
                action = self.get_context("last_action")
                if action:
                    return f"好的，{action}"
            for obj in self.entity_patterns["object"]:
                if obj in user_input:
                    return f"好的，正在{user_input}。"
            return f"收到命令：{user_input[:30]}..."
        elif intent == Intent.FAREWELL:
            return "再见！下次见。"
        elif intent == Intent.FEEDBACK:
            if any(word in user_input for word in ["对", "是", "好", "嗯", "哦"]):
                return "好的，我明白了。"
            else:
                return "抱歉，我会改进的。"
        else:
            last_response = self.get_last_response()
            if last_response:
                return f"我不太确定你的意思。刚才我说：{last_response[:30]}... 能再说清楚一点吗？"
            return "我不太明白你的意思，能再说一遍吗？"
    
    def generate_response(self, user_input: str) -> Dict:
        intent = self.recognize_intent(user_input)
        entities = self.extract_entities(user_input)
        inference = self.infer_from_context(user_input)
        self._update_context_from_input(user_input, entities)
        clarification = self.need_clarification(user_input)
        if clarification["need"]:
            response = clarification["clarification_question"]
        else:
            response = self._generate_by_intent(user_input, intent, entities, inference)
        turn = Turn(turn_id=self.current_turn, user_input=user_input, bot_response=response, intent=intent, entities=entities)
        self.history.append(turn)
        self.current_turn += 1
        if len(self.history) > self.max_history:
            self.history.pop(0)
        return {"response": response, "intent": intent.value, "entities": entities, "context_used": inference["has_inference"], "inference": inference["explanation"] if inference["has_inference"] else None}
    
    def multi_turn_reason(self, user_input: str, history_count: int = 3) -> Dict:
        referenced_turns = []
        reasoning_parts = []
        recent_history = self.history[-history_count:] if self.history else []
        for i, turn in enumerate(recent_history):
            if any(word in user_input for word in ["刚才", "之前", "刚刚", "前面", "刚才说的"]):
                referenced_turns.append(turn.turn_id)
                reasoning_parts.append(f"引用第{turn.turn_id+1}轮: {turn.user_input[:30]}...")
        if "它" in user_input or "那个" in user_input:
            for turn in reversed(recent_history):
                if turn.entities.get("object"):
                    referenced_turns.append(turn.turn_id)
                    reasoning_parts.append(f"指代第{turn.turn_id+1}轮的{turn.entities['object'][0]}")
                    break
        if reasoning_parts:
            reasoning = f"多轮推理: {'; '.join(reasoning_parts)}"
            confidence = 0.7
        else:
            reasoning = "单轮推理，未引用历史"
            confidence = 0.9
        return {"reasoning": reasoning, "referenced_turns": referenced_turns, "confidence": confidence}
    
    def get_last_response(self) -> Optional[str]:
        if self.history:
            return self.history[-1].bot_response
        return None
    
    def get_history_summary(self) -> str:
        if not self.history:
            return "暂无对话历史"
        summary = f"共{len(self.history)}轮对话\n"
        for turn in self.history[-5:]:
            summary += f"  {turn.turn_id+1}. 用户: {turn.user_input[:30]}\n"
            summary += f"     机器人: {turn.bot_response[:40]}\n"
        return summary
    
    def get_statistics(self) -> Dict:
        intent_counts = {}
        for turn in self.history:
            intent = turn.intent.value
            intent_counts[intent] = intent_counts.get(intent, 0) + 1
        return {"total_turns": len(self.history), "intent_distribution": intent_counts, "context_variables": len(self.context), "context_keys": list(self.context.keys())}