import re

class IntentUnderstanding:
    """
    意图理解模块：理解隐含需求和意图
    """
    
    def __init__(self):
        # 意图映射
        self.intents = {
            '渴': {
                'keywords': ['渴', '想喝水', '口干', '喝水'],
                'action': '拿水',
                'response': '你渴了，我去帮你拿水',
                'question': '想喝水吗？',
            },
            '饿': {
                'keywords': ['饿', '想吃东西', '肚子叫', '吃饭'],
                'action': '拿食物',
                'response': '你饿了，要不要吃点东西？',
                'question': '想吃点什么？',
            },
            '热': {
                'keywords': ['热', '好热', '开空调', '风扇'],
                'action': '开空调',
                'response': '你热了，要不要开空调？',
                'question': '需要降温吗？',
            },
            '冷': {
                'keywords': ['冷', '好冷', '开暖气', '加衣服'],
                'action': '开暖气',
                'response': '你冷了，要不要开暖气？',
                'question': '需要加衣服吗？',
            },
            '困': {
                'keywords': ['困', '想睡', '累了', '睡觉'],
                'action': '关灯',
                'response': '你困了，需要关灯吗？',
                'question': '要休息了吗？',
            },
            '暗': {
                'keywords': ['暗', '天黑', '看不见', '开灯'],
                'action': '开灯',
                'response': '天黑了，需要开灯吗？',
                'question': '要开灯吗？',
            },
            '亮': {
                'keywords': ['亮', '刺眼', '太亮', '关灯'],
                'action': '关灯',
                'response': '太亮了，需要关灯吗？',
                'question': '要调暗一点吗？',
            },
        }
        
        # 强度修饰词
        self.intensity_modifiers = {
            '有点': 3,
            '比较': 4,
            '很': 7,
            '非常': 8,
            '好': 7,
            '太': 9,
        }
        
        self.current_intent = None
        self.current_intensity = 5
    
    def parse_intent(self, text):
        """解析意图"""
        # 先匹配强度
        intensity = 5
        for word, val in self.intensity_modifiers.items():
            if word in text:
                intensity = val
                break
        
        # 匹配意图
        for intent_name, intent_info in self.intents.items():
            for keyword in intent_info['keywords']:
                if keyword in text:
                    return intent_name, intent_info, intensity
        return None, None, None
    
    def understand(self, text):
        """理解意图"""
        intent_name, intent_info, intensity = self.parse_intent(text)
        
        if intent_info:
            self.current_intent = intent_name
            self.current_intensity = intensity
            
            # 根据强度调整回应
            if intensity >= 7:
                return f"{intent_info['response']}，看起来挺急的。"
            elif intensity <= 3:
                return f"{intent_info['response']}，不急的话可以等等。"
            else:
                return f"{intent_info['response']}"
        
        return "我不太明白你的意思"
    
    def suggest_action(self):
        """根据当前意图建议行动"""
        if self.current_intent:
            intent_info = self.intents.get(self.current_intent)
            if intent_info:
                return f"建议：{intent_info['action']}"
        return "暂无建议"
    
    def get_intent_status(self):
        """获取当前意图状态"""
        if self.current_intent:
            intensity_desc = ""
            if self.current_intensity >= 7:
                intensity_desc = "很"
            elif self.current_intensity <= 3:
                intensity_desc = "有点"
            return f"{intensity_desc}{self.current_intent}"
        return "无明显意图"