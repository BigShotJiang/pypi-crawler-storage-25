from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import uuid
import random


class StrategyType(Enum):
    NAVIGATION = "navigation"
    MANIPULATION = "manipulation"
    SEARCH = "search"
    AVOIDANCE = "avoidance"
    OPTIMIZATION = "optimization"


class StrategyStatus(Enum):
    PROPOSED = "proposed"
    EVALUATING = "evaluating"
    APPROVED = "approved"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Strategy:
    id: str
    name: str
    description: str
    strategy_type: StrategyType
    steps: List[str]
    preconditions: List[str]
    expected_outcome: str
    confidence: float
    status: StrategyStatus = StrategyStatus.PROPOSED
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    executed_at: Optional[str] = None
    execution_result: Optional[str] = None


@dataclass
class StrategyOption:
    name: str
    description: str
    steps: List[str]
    pros: List[str]
    cons: List[str]
    estimated_time: float
    success_rate: float
    risk_level: str  # low/medium/high


class StrategyGeneration:
    """
    策略生成模块 (0.69.0)
    能力：自主规划、方案生成、策略评估、策略优化、执行跟踪
    """
    
    def __init__(self):
        self.strategies: Dict[str, Strategy] = {}
        self.strategy_history: List[Dict] = []
        self.strategy_templates: Dict[str, List[StrategyOption]] = {}
        
        self._init_strategy_templates()
    
    def _init_strategy_templates(self):
        """初始化策略模板"""
        
        # 导航策略模板
        self.strategy_templates["navigation"] = [
            StrategyOption(
                name="最短路径策略",
                description="通过计算最短路径到达目标",
                steps=["获取当前位置", "计算最短路径", "沿路径移动", "到达目标"],
                pros=["速度快", "效率高"],
                cons=["可能经过拥挤区域", "无法应对动态障碍"],
                estimated_time=30,
                success_rate=0.85,
                risk_level="low"
            ),
            StrategyOption(
                name="安全优先策略",
                description="选择最安全的路径，避开高风险区域",
                steps=["扫描环境", "识别安全区域", "规划安全路径", "谨慎移动", "到达目标"],
                pros=["安全性高", "适合危险环境"],
                cons=["速度慢", "耗能多"],
                estimated_time=60,
                success_rate=0.95,
                risk_level="low"
            ),
            StrategyOption(
                name="探索策略",
                description="探索未知区域，寻找最优路径",
                steps=["标记未知区域", "探索优先", "记录发现", "动态调整", "到达目标"],
                pros=["能发现新路径", "适应未知环境"],
                cons=["耗时长", "不确定性高"],
                estimated_time=120,
                success_rate=0.70,
                risk_level="medium"
            ),
        ]
        
        # 搜索策略模板
        self.strategy_templates["search"] = [
            StrategyOption(
                name="广度优先搜索",
                description="系统性地搜索所有区域",
                steps=["划分搜索区域", "逐个区域搜索", "标记已搜索", "找到目标"],
                pros=["不会遗漏", "全面"],
                cons=["耗时长", "效率低"],
                estimated_time=90,
                success_rate=0.95,
                risk_level="low"
            ),
            StrategyOption(
                name="启发式搜索",
                description="根据线索优先搜索可能性高的区域",
                steps=["分析线索", "确定高概率区域", "优先搜索", "扩展搜索", "找到目标"],
                pros=["效率高", "快速"],
                cons=["可能遗漏", "依赖线索质量"],
                estimated_time=45,
                success_rate=0.80,
                risk_level="medium"
            ),
        ]
        
        # 操作策略模板
        self.strategy_templates["manipulation"] = [
            StrategyOption(
                name="直接抓取",
                description="直接接近并抓取目标物体",
                steps=["定位目标", "接近目标", "调整姿态", "抓取", "确认"],
                pros=["简单快速"],
                cons=["需要精确控制", "可能失败"],
                estimated_time=15,
                success_rate=0.85,
                risk_level="low"
            ),
            StrategyOption(
                name="辅助抓取",
                description="使用辅助工具或多次尝试抓取",
                steps=["评估难度", "选择工具", "辅助抓取", "验证"],
                pros=["成功率高", "适应复杂物体"],
                cons=["需要工具", "耗时"],
                estimated_time=30,
                success_rate=0.95,
                risk_level="low"
            ),
        ]
    
    # ========== 1. 生成策略 ==========
    def generate_strategy(self, goal: str, context: Dict = None) -> List[StrategyOption]:
        """
        根据目标生成多个策略方案
        
        参数：
            goal: 目标描述
            context: 上下文信息
            
        返回：
            策略选项列表
        """
        if context is None:
            context = {}
        
        strategies = []
        
        # 根据目标类型选择合适的模板
        if "导航" in goal or "去" in goal or "移动到" in goal:
            strategies = self.strategy_templates.get("navigation", [])
        elif "搜索" in goal or "找" in goal or "寻找" in goal:
            strategies = self.strategy_templates.get("search", [])
        elif "抓取" in goal or "拿" in goal or "取" in goal:
            strategies = self.strategy_templates.get("manipulation", [])
        else:
            # 通用策略
            strategies = [
                StrategyOption(
                    name="直接执行",
                    description="直接按标准流程执行",
                    steps=["分析任务", "执行", "验证结果"],
                    pros=["简单"],
                    cons=["可能不够优化"],
                    estimated_time=30,
                    success_rate=0.80,
                    risk_level="low"
                ),
                StrategyOption(
                    name="分步执行",
                    description="将任务分解为多个子任务逐步执行",
                    steps=["任务分解", "子任务规划", "逐步执行", "汇总结果"],
                    pros=["可控性强", "易于调试"],
                    cons=["耗时较长"],
                    estimated_time=60,
                    success_rate=0.90,
                    risk_level="low"
                ),
            ]
        
        # 根据上下文调整
        if context.get("time_constraint"):
            strategies.sort(key=lambda x: x.estimated_time)
        
        if context.get("safety_first"):
            strategies.sort(key=lambda x: 0 if x.risk_level == "low" else 1)
        
        return strategies
    
    # ========== 2. 策略评估 ==========
    def evaluate_strategy(self, strategy: StrategyOption, 
                          criteria: Dict[str, float] = None) -> Dict:
        """
        评估策略方案
        
        参数：
            strategy: 策略选项
            criteria: 评估标准权重
            
        返回：
            {
                "score": float,
                "analysis": str,
                "recommendation": str
            }
        """
        if criteria is None:
            criteria = {
                "speed": 0.3,
                "success_rate": 0.4,
                "safety": 0.2,
                "simplicity": 0.1
            }
        
        # 计算各项得分（归一化到0-1）
        speed_score = max(0, 1 - strategy.estimated_time / 120)  # 120秒为基准
        success_score = strategy.success_rate
        safety_score = 1.0 if strategy.risk_level == "low" else 0.5 if strategy.risk_level == "medium" else 0.0
        simplicity_score = 1.0 / max(1, len(strategy.steps)) * 3  # 步骤越少得分越高
        
        # 加权总分
        total_score = (
            criteria.get("speed", 0.3) * speed_score +
            criteria.get("success_rate", 0.4) * success_score +
            criteria.get("safety", 0.2) * safety_score +
            criteria.get("simplicity", 0.1) * simplicity_score
        )
        
        # 生成分析
        analysis = self._generate_analysis(strategy, total_score, {
            "speed": speed_score,
            "success": success_score,
            "safety": safety_score
        })
        
        # 推荐意见
        if total_score >= 0.8:
            recommendation = "强烈推荐"
        elif total_score >= 0.6:
            recommendation = "推荐"
        elif total_score >= 0.4:
            recommendation = "可以考虑"
        else:
            recommendation = "不推荐"
        
        return {
            "score": total_score,
            "analysis": analysis,
            "recommendation": recommendation,
            "details": {
                "speed_score": speed_score,
                "success_score": success_score,
                "safety_score": safety_score
            }
        }
    
    def _generate_analysis(self, strategy: StrategyOption, score: float, 
                           scores: Dict) -> str:
        """生成策略分析"""
        analysis = f"策略“{strategy.name}”综合评分{score:.0%}。"
        
        if scores["speed"] > 0.7:
            analysis += " 速度快"
        elif scores["speed"] < 0.3:
            analysis += " 速度较慢"
        
        if scores["success"] > 0.8:
            analysis += " 成功率高"
        elif scores["success"] < 0.6:
            analysis += " 成功率偏低"
        
        if strategy.risk_level == "low":
            analysis += " 风险低"
        elif strategy.risk_level == "high":
            analysis += " 风险较高"
        
        return analysis
    
    # ========== 3. 策略优化 ==========
    def optimize_strategy(self, strategy: StrategyOption, 
                          feedback: str = None) -> StrategyOption:
        """
        优化策略
        
        参数：
            strategy: 原始策略
            feedback: 反馈信息
            
        返回：
            优化后的策略
        """
        optimized = StrategyOption(
            name=strategy.name + "(优化版)",
            description=strategy.description,
            steps=strategy.steps.copy(),
            pros=strategy.pros.copy(),
            cons=strategy.cons.copy(),
            estimated_time=strategy.estimated_time,
            success_rate=strategy.success_rate,
            risk_level=strategy.risk_level
        )
        
        # 根据反馈优化
        if feedback:
            if "慢" in feedback or "速度" in feedback:
                optimized.estimated_time *= 0.8
                optimized.cons.append("优化后速度提升")
            if "失败" in feedback or "成功率" in feedback:
                optimized.success_rate = min(0.95, optimized.success_rate + 0.1)
                optimized.steps.insert(1, "增加验证步骤")
            if "风险" in feedback:
                optimized.risk_level = "low"
                optimized.steps.insert(1, "增加安全检查")
        else:
            # 通用优化
            optimized.estimated_time *= 0.9
            optimized.success_rate = min(0.95, optimized.success_rate + 0.05)
        
        return optimized
    
    # ========== 4. 选择最佳策略 ==========
    def select_best_strategy(self, strategies: List[StrategyOption], 
                             preferences: Dict = None) -> Dict:
        """
        选择最佳策略
        
        参数：
            strategies: 策略列表
            preferences: 偏好设置
            
        返回：
            最佳策略及理由
        """
        if preferences is None:
            preferences = {"priority": "balanced"}
        
        best_strategy = None
        best_score = -1
        evaluations = []
        
        for strategy in strategies:
            # 根据偏好调整评估权重
            if preferences.get("priority") == "speed":
                criteria = {"speed": 0.5, "success_rate": 0.3, "safety": 0.1, "simplicity": 0.1}
            elif preferences.get("priority") == "safety":
                criteria = {"speed": 0.1, "success_rate": 0.3, "safety": 0.5, "simplicity": 0.1}
            elif preferences.get("priority") == "success":
                criteria = {"speed": 0.2, "success_rate": 0.6, "safety": 0.1, "simplicity": 0.1}
            else:
                criteria = {"speed": 0.25, "success_rate": 0.35, "safety": 0.25, "simplicity": 0.15}
            
            evaluation = self.evaluate_strategy(strategy, criteria)
            evaluations.append({
                "name": strategy.name,
                "score": evaluation["score"],
                "recommendation": evaluation["recommendation"]
            })
            
            if evaluation["score"] > best_score:
                best_score = evaluation["score"]
                best_strategy = strategy
        
        return {
            "best_strategy": best_strategy.name if best_strategy else None,
            "score": best_score,
            "reason": f"综合评分最高 ({best_score:.0%})",
            "all_evaluations": evaluations
        }
    
    # ========== 5. 执行策略 ==========
    def execute_strategy(self, strategy: StrategyOption, 
                         context: Dict = None) -> Dict:
        """
        执行策略
        
        参数：
            strategy: 策略选项
            context: 执行上下文
            
        返回：
            执行结果
        """
        if context is None:
            context = {}
        
        # 创建策略记录
        strategy_id = f"STRAT_{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.strategies)}"
        
        recorded_strategy = Strategy(
            id=strategy_id,
            name=strategy.name,
            description=strategy.description,
            strategy_type=self._infer_strategy_type(strategy.name),
            steps=strategy.steps,
            preconditions=[],
            expected_outcome="成功执行",
            confidence=strategy.success_rate,
            status=StrategyStatus.EXECUTING
        )
        self.strategies[strategy_id] = recorded_strategy
        
        # 模拟执行
        execution_log = []
        success = True
        
        for i, step in enumerate(strategy.steps, 1):
            execution_log.append({
                "step": i,
                "action": step,
                "status": "completed",
                "timestamp": datetime.now().isoformat()
            })
        
        # 根据成功率决定结果
        import random
        actual_success = random.random() < strategy.success_rate
        
        if actual_success:
            recorded_strategy.status = StrategyStatus.COMPLETED
            recorded_strategy.execution_result = "成功"
            result_message = f"策略“{strategy.name}”执行成功"
        else:
            recorded_strategy.status = StrategyStatus.FAILED
            recorded_strategy.execution_result = "失败"
            result_message = f"策略“{strategy.name}”执行失败"
        
        recorded_strategy.executed_at = datetime.now().isoformat()
        
        # 记录历史
        self._log_strategy(strategy_id, result_message, actual_success)
        
        return {
            "success": actual_success,
            "strategy_id": strategy_id,
            "message": result_message,
            "execution_log": execution_log,
            "steps_completed": len(execution_log)
        }
    
    def _infer_strategy_type(self, name: str) -> StrategyType:
        """推断策略类型"""
        if "路径" in name or "导航" in name:
            return StrategyType.NAVIGATION
        if "搜索" in name:
            return StrategyType.SEARCH
        if "抓取" in name:
            return StrategyType.MANIPULATION
        return StrategyType.OPTIMIZATION
    
    # ========== 6. 策略学习 ==========
    def learn_from_execution(self, strategy_id: str, feedback: str) -> Dict:
        """
        从执行结果学习，改进策略
        
        参数：
            strategy_id: 策略ID
            feedback: 反馈信息
            
        返回：
            学习结果
        """
        if strategy_id not in self.strategies:
            return {"learned": False, "message": "策略不存在"}
        
        strategy = self.strategies[strategy_id]
        
        # 根据反馈更新策略成功率
        if "成功" in feedback:
            new_confidence = min(0.95, strategy.confidence + 0.05)
        else:
            new_confidence = max(0.5, strategy.confidence - 0.1)
        
        old_confidence = strategy.confidence
        strategy.confidence = new_confidence
        
        self._log_strategy(strategy_id, f"置信度: {old_confidence:.0%} → {new_confidence:.0%}", True)
        
        return {
            "learned": True,
            "strategy_id": strategy_id,
            "old_confidence": old_confidence,
            "new_confidence": new_confidence,
            "message": f"已学习反馈，策略置信度从{old_confidence:.0%}调整至{new_confidence:.0%}"
        }
    
    # ========== 7. 策略组合 ==========
    def compose_strategies(self, strategies: List[StrategyOption], 
                           composition_type: str = "sequential") -> StrategyOption:
        """
        组合多个策略
        
        参数：
            strategies: 策略列表
            composition_type: 组合类型 (sequential/parallel/conditional)
            
        返回：
            组合策略
        """
        combined_steps = []
        combined_pros = []
        combined_cons = []
        total_time = 0
        avg_success = 0
        
        if composition_type == "sequential":
            for s in strategies:
                combined_steps.extend([f"[{s.name}] {step}" for step in s.steps])
                combined_pros.extend(s.pros)
                combined_cons.extend(s.cons)
                total_time += s.estimated_time
                avg_success += s.success_rate
        elif composition_type == "parallel":
            combined_steps.append(f"并行执行: {', '.join([s.name for s in strategies])}")
            for s in strategies:
                total_time = max(total_time, s.estimated_time)
                avg_success += s.success_rate
        else:
            # conditional
            combined_steps.append(f"根据条件选择: {', '.join([s.name for s in strategies])}")
            for s in strategies:
                avg_success += s.success_rate
                total_time = s.estimated_time
        
        avg_success /= len(strategies)
        
        composed = StrategyOption(
            name=f"组合策略_{composition_type}",
            description=f"组合了{len(strategies)}个策略",
            steps=combined_steps,
            pros=list(set(combined_pros))[:3],
            cons=list(set(combined_cons))[:2],
            estimated_time=total_time,
            success_rate=avg_success,
            risk_level="medium"
        )
        
        return composed
    
    # ========== 8. 统计报告 ==========
    def get_statistics(self) -> Dict:
        """获取策略生成统计"""
        completed = [s for s in self.strategies.values() 
                     if s.status == StrategyStatus.COMPLETED]
        failed = [s for s in self.strategies.values() 
                  if s.status == StrategyStatus.FAILED]
        
        strategy_types = {}
        for s in self.strategies.values():
            stype = s.strategy_type.value
            strategy_types[stype] = strategy_types.get(stype, 0) + 1
        
        return {
            "total_strategies": len(self.strategies),
            "completed_count": len(completed),
            "failed_count": len(failed),
            "success_rate": len(completed) / len(self.strategies) if self.strategies else 0,
            "strategy_types": strategy_types,
            "avg_confidence": sum(s.confidence for s in self.strategies.values()) / len(self.strategies) if self.strategies else 0,
            "total_executions": len(self.strategy_history)
        }
    
    def _log_strategy(self, strategy_id: str, action: str, success: bool):
        """记录策略日志"""
        self.strategy_history.append({
            "strategy_id": strategy_id,
            "action": action,
            "success": success,
            "timestamp": datetime.now().isoformat()
        })
