from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import hashlib
import uuid


class RobotRole(Enum):
    LEADER = "leader"
    WORKER = "worker"
    SCOUT = "scout"
    SUPPORT = "support"


class TaskStatus(Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Robot:
    id: str
    name: str
    role: RobotRole
    capabilities: List[str]
    status: str = "idle"
    position: Tuple[float, float] = (0, 0)
    battery: float = 100.0
    current_task: Optional[str] = None
    last_heartbeat: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Task:
    id: str
    description: str
    required_capabilities: List[str]
    priority: int = 5
    status: TaskStatus = TaskStatus.PENDING
    assigned_to: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_at: Optional[str] = None


@dataclass
class Message:
    id: str
    from_robot: str
    to_robot: str
    content: str
    msg_type: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class SwarmIntelligence:
    """
    多机器人协作模块 (0.67.0)
    能力：机器人注册、任务分配、消息通信、协作决策、负载均衡
    """
    
    def __init__(self):
        self.robots: Dict[str, Robot] = {}
        self.tasks: Dict[str, Task] = {}
        self.messages: List[Message] = []
        self.collaboration_log: List[Dict] = []
        self.leader_id: Optional[str] = None
        
        # 初始化示例机器人
        self._init_example_robots()
    
    def _init_example_robots(self):
        """初始化示例机器人"""
        example_robots = [
            ("robot_1", "搬运机器人A", RobotRole.WORKER, ["搬运", "导航"]),
            ("robot_2", "搬运机器人B", RobotRole.WORKER, ["搬运", "导航"]),
            ("robot_3", "侦察机器人", RobotRole.SCOUT, ["侦察", "导航", "拍照"]),
            ("robot_4", "维修机器人", RobotRole.SUPPORT, ["维修", "检查"]),
        ]
        for rid, name, role, caps in example_robots:
            self.register_robot(rid, name, role, caps)
    
    # ========== 1. 机器人注册 ==========
    def register_robot(self, robot_id: str, name: str, role: RobotRole, 
                       capabilities: List[str]) -> bool:
        """
        注册机器人
        
        参数：
            robot_id: 机器人ID
            name: 机器人名称
            role: 角色
            capabilities: 能力列表
            
        返回：
            是否成功
        """
        if robot_id in self.robots:
            return False
        
        robot = Robot(
            id=robot_id,
            name=name,
            role=role,
            capabilities=capabilities
        )
        self.robots[robot_id] = robot
        
        # 如果没有领导者，第一个注册的成为领导者
        if not self.leader_id and role == RobotRole.WORKER:
            self.leader_id = robot_id
            robot.role = RobotRole.LEADER
        
        self._log_collaboration("register", robot_id, f"{name} 已注册")
        return True
    
    def unregister_robot(self, robot_id: str) -> bool:
        """注销机器人"""
        if robot_id not in self.robots:
            return False
        
        # 如果是领导者，选举新领导者
        if robot_id == self.leader_id:
            self._elect_new_leader()
        
        del self.robots[robot_id]
        self._log_collaboration("unregister", robot_id, "机器人已注销")
        return True
    
    def _elect_new_leader(self):
        """选举新领导者"""
        available = [r for r in self.robots.values() if r.status == "idle"]
        if available:
            self.leader_id = available[0].id
            available[0].role = RobotRole.LEADER
            self._log_collaboration("elect", self.leader_id, "新领导者选举完成")
    
    # ========== 2. 任务分配 ==========
    def add_task(self, description: str, required_capabilities: List[str], 
                 priority: int = 5) -> str:
        """
        添加任务
        
        参数：
            description: 任务描述
            required_capabilities: 所需能力
            priority: 优先级 1-10
            
        返回：
            任务ID
        """
        task_id = f"TASK_{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.tasks)}"
        
        task = Task(
            id=task_id,
            description=description,
            required_capabilities=required_capabilities,
            priority=priority
        )
        self.tasks[task_id] = task
        
        self._log_collaboration("add_task", task_id, description)
        
        # 自动分配
        self.assign_task(task_id)
        
        return task_id
    
    def assign_task(self, task_id: str) -> Optional[str]:
        """
        分配任务给最合适的机器人
        
        返回：
            被分配的机器人ID
        """
        if task_id not in self.tasks:
            return None
        
        task = self.tasks[task_id]
        
        # 找到最合适的机器人
        best_robot = None
        best_score = -1
        
        for robot in self.robots.values():
            if robot.status != "idle":
                continue
            
            # 计算匹配分数
            score = self._calculate_match_score(robot, task)
            
            if score > best_score:
                best_score = score
                best_robot = robot
        
        if best_robot and best_score > 0:
            task.assigned_to = best_robot.id
            task.status = TaskStatus.ASSIGNED
            best_robot.status = "busy"
            best_robot.current_task = task_id
            
            self._log_collaboration("assign_task", task_id, f"分配给 {best_robot.name}")
            
            # 发送通知
            self.send_message(self.leader_id, best_robot.id, 
                            f"分配任务: {task.description}", "task_assignment")
            
            return best_robot.id
        
        return None
    
    def _calculate_match_score(self, robot: Robot, task: Task) -> float:
        """计算机器人与任务的匹配分数"""
        score = 0.0
        
        # 能力匹配
        matching_caps = set(robot.capabilities) & set(task.required_capabilities)
        score += len(matching_caps) * 2
        
        # 电池电量
        score += robot.battery / 100
        
        # 优先级加成
        score += task.priority / 10
        
        return score
    
    def complete_task(self, task_id: str, success: bool = True) -> bool:
        """
        完成任务
        
        参数：
            task_id: 任务ID
            success: 是否成功
            
        返回：
            是否成功
        """
        if task_id not in self.tasks:
            return False
        
        task = self.tasks[task_id]
        task.status = TaskStatus.COMPLETED if success else TaskStatus.FAILED
        task.completed_at = datetime.now().isoformat()
        
        # 释放机器人
        if task.assigned_to and task.assigned_to in self.robots:
            robot = self.robots[task.assigned_to]
            robot.status = "idle"
            robot.current_task = None
            
            # 根据结果调整电池
            if success:
                robot.battery = max(0, robot.battery - 5)
            else:
                robot.battery = max(0, robot.battery - 10)
        
        self._log_collaboration("complete_task", task_id, 
                                f"成功" if success else "失败")
        return True
    
    # ========== 3. 消息通信 ==========
    def send_message(self, from_robot: str, to_robot: str, 
                     content: str, msg_type: str = "info") -> Optional[str]:
        """
        发送消息
        
        参数：
            from_robot: 发送者
            to_robot: 接收者（"all" 表示广播）
            content: 消息内容
            msg_type: 消息类型
            
        返回：
            消息ID
        """
        if from_robot not in self.robots:
            return None
        
        if to_robot == "all":
            # 广播
            for robot in self.robots.values():
                if robot.id != from_robot:
                    self._send_single_message(from_robot, robot.id, content, msg_type)
            msg_id = f"BROADCAST_{datetime.now().timestamp()}"
        else:
            if to_robot not in self.robots:
                return None
            msg_id = self._send_single_message(from_robot, to_robot, content, msg_type)
        
        self._log_collaboration("send_message", f"{from_robot}→{to_robot}", content[:50])
        
        return msg_id
    
    def _send_single_message(self, from_robot: str, to_robot: str, 
                              content: str, msg_type: str) -> str:
        """发送单条消息"""
        msg_id = str(uuid.uuid4())[:8]
        message = Message(
            id=msg_id,
            from_robot=from_robot,
            to_robot=to_robot,
            content=content,
            msg_type=msg_type
        )
        self.messages.append(message)
        return msg_id
    
    def get_messages(self, robot_id: str, limit: int = 10) -> List[Dict]:
        """获取机器人的消息"""
        robot_msgs = [m for m in self.messages if m.to_robot == robot_id]
        robot_msgs.sort(key=lambda x: x.timestamp, reverse=True)
        
        return [{
            "id": m.id,
            "from": m.from_robot,
            "content": m.content,
            "type": m.msg_type,
            "timestamp": m.timestamp
        } for m in robot_msgs[:limit]]
    
    # ========== 4. 协作决策 ==========
    def collaborative_decision(self, problem: str, context: Dict = None) -> Dict:
        """
        协作决策：多个机器人共同决策
        
        参数：
            problem: 问题描述
            context: 上下文
            
        返回：
            {
                "decision": str,
                "votes": Dict,
                "confidence": float
            }
        """
        if context is None:
            context = {}
        
        votes = {}
        active_robots = [r for r in self.robots.values() if r.status == "idle"]
        
        if not active_robots:
            return {
                "decision": "无可用机器人",
                "votes": {},
                "confidence": 0.0
            }
        
        # 每个机器人投票
        for robot in active_robots:
            vote = self._get_robot_vote(robot, problem, context)
            votes[robot.name] = vote
        
        # 统计投票结果
        vote_counts = {}
        for vote in votes.values():
            vote_counts[vote] = vote_counts.get(vote, 0) + 1
        
        if vote_counts:
            decision = max(vote_counts, key=vote_counts.get)
            confidence = vote_counts[decision] / len(active_robots)
        else:
            decision = "无法决定"
            confidence = 0.0
        
        self._log_collaboration("collaborative_decision", problem, decision)
        
        return {
            "decision": decision,
            "votes": votes,
            "confidence": confidence
        }
    
    def _get_robot_vote(self, robot: Robot, problem: str, context: Dict) -> str:
        """获取机器人的投票"""
        # 基于能力和角色投票
        if "导航" in robot.capabilities and "位置" in problem:
            return "方案A"
        if "搬运" in robot.capabilities and "移动" in problem:
            return "方案B"
        if robot.role == RobotRole.LEADER:
            return "方案A"
        return "方案B"
    
    # ========== 5. 负载均衡 ==========
    def rebalance_tasks(self) -> Dict:
        """
        重新平衡任务负载
        
        返回：
            {
                "reassigned": int,
                "new_assignments": Dict
            }
        """
        reassigned = 0
        new_assignments = {}
        
        # 获取繁忙和空闲机器人
        busy_robots = [r for r in self.robots.values() if r.status == "busy"]
        idle_robots = [r for r in self.robots.values() if r.status == "idle"]
        
        # 如果某个机器人任务太多，重新分配
        for robot in busy_robots:
            if robot.current_task and len(busy_robots) > len(idle_robots) * 2:
                # 重新分配任务
                task_id = robot.current_task
                if task_id in self.tasks:
                    new_robot = self.assign_task(task_id)
                    if new_robot and new_robot != robot.id:
                        reassigned += 1
                        new_assignments[task_id] = new_robot
                        robot.status = "idle"
                        robot.current_task = None
        
        self._log_collaboration("rebalance", f"{reassigned}个任务", "负载均衡完成")
        
        return {
            "reassigned": reassigned,
            "new_assignments": new_assignments
        }
    
    # ========== 6. 状态同步 ==========
    def sync_status(self) -> Dict:
        """
        同步所有机器人状态
        
        返回：
            全局状态快照
        """
        status = {
            "timestamp": datetime.now().isoformat(),
            "total_robots": len(self.robots),
            "leader_id": self.leader_id,
            "robots": [],
            "pending_tasks": len([t for t in self.tasks.values() 
                                  if t.status == TaskStatus.PENDING]),
            "active_tasks": len([t for t in self.tasks.values() 
                                  if t.status == TaskStatus.IN_PROGRESS])
        }
        
        for robot in self.robots.values():
            status["robots"].append({
                "id": robot.id,
                "name": robot.name,
                "role": robot.role.value,
                "status": robot.status,
                "battery": robot.battery,
                "current_task": robot.current_task
            })
        
        return status
    
    def heartbeat(self, robot_id: str) -> bool:
        """
        机器人心跳
        
        参数：
            robot_id: 机器人ID
            
        返回：
            是否成功
        """
        if robot_id not in self.robots:
            return False
        
        self.robots[robot_id].last_heartbeat = datetime.now().isoformat()
        return True
    
    def check_health(self) -> List[str]:
        """
        检查机器人健康状态
        
        返回：
            失联机器人列表
        """
        offline = []
        now = datetime.now()
        
        for robot in self.robots.values():
            last = datetime.fromisoformat(robot.last_heartbeat)
            if (now - last).seconds > 60:  # 超过1分钟无心跳
                offline.append(robot.id)
        
        return offline
    
    # ========== 7. 任务分解 ==========
    def decompose_task(self, complex_task: str) -> List[Dict]:
        """
        将复杂任务分解为子任务
        
        参数：
            complex_task: 复杂任务描述
            
        返回：
            子任务列表
        """
        subtasks = []
        
        # 示例分解规则
        if "搬运" in complex_task and "仓库" in complex_task:
            subtasks = [
                {"description": "导航到仓库", "capabilities": ["导航"], "priority": 8},
                {"description": "找到目标物品", "capabilities": ["侦察", "拍照"], "priority": 7},
                {"description": "搬运物品", "capabilities": ["搬运"], "priority": 9},
                {"description": "送到目的地", "capabilities": ["导航", "搬运"], "priority": 8},
            ]
        elif "清洁" in complex_task:
            subtasks = [
                {"description": "扫描区域", "capabilities": ["侦察"], "priority": 5},
                {"description": "清扫地面", "capabilities": ["清洁"], "priority": 6},
                {"description": "倒垃圾", "capabilities": ["搬运"], "priority": 4},
            ]
        else:
            subtasks = [
                {"description": complex_task, "capabilities": ["通用"], "priority": 5}
            ]
        
        # 添加子任务
        for sub in subtasks:
            self.add_task(sub["description"], sub["capabilities"], sub["priority"])
        
        return subtasks
    
    # ========== 8. 统计报告 ==========
    def get_statistics(self) -> Dict:
        """获取协作统计"""
        active_robots = len([r for r in self.robots.values() if r.status != "offline"])
        busy_robots = len([r for r in self.robots.values() if r.status == "busy"])
        completed_tasks = len([t for t in self.tasks.values() 
                               if t.status == TaskStatus.COMPLETED])
        
        return {
            "total_robots": len(self.robots),
            "active_robots": active_robots,
            "busy_robots": busy_robots,
            "idle_robots": active_robots - busy_robots,
            "total_tasks": len(self.tasks),
            "completed_tasks": completed_tasks,
            "pending_tasks": len([t for t in self.tasks.values() 
                                   if t.status == TaskStatus.PENDING]),
            "failed_tasks": len([t for t in self.tasks.values() 
                                  if t.status == TaskStatus.FAILED]),
            "total_messages": len(self.messages),
            "leader_id": self.leader_id,
            "avg_battery": sum(r.battery for r in self.robots.values()) / len(self.robots) if self.robots else 0
        }
    
    def _log_collaboration(self, action: str, target: str, detail: str):
        """记录协作日志"""
        self.collaboration_log.append({
            "action": action,
            "target": target,
            "detail": detail,
            "timestamp": datetime.now().isoformat()
        })