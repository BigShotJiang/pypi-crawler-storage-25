import time
from datetime import datetime

class TemporalReasoner:
    """
    时序推理模块：理解时间顺序、估计耗时、安排时序
    """
    
    def __init__(self):
        self.event_timeline = []  # 事件时间线
        self.task_durations = {   # 任务耗时估计（秒）
            '去厨房': 5,
            '拿水杯': 3,
            '倒水': 2,
            '充电': 600,
            '走路': 2,
            '抓取': 1,
        }
    
    def understand_order(self, text):
        """理解事情发生的顺序"""
        if '先' in text and '再' in text:
            parts = text.split('再')
            first = parts[0].replace('先', '').strip()
            second = parts[1].strip()
            return f"理解顺序: {first} → {second}"
        elif '然后' in text:
            parts = text.split('然后')
            first = parts[0].strip()
            second = parts[1].strip()
            return f"理解顺序: {first} → {second}"
        else:
            return "无法理解顺序"
    
    def estimate_time(self, task):
        """估计任务耗时"""
        duration = self.task_durations.get(task, 5)
        return f"{task} 大约需要 {duration} 秒"
    
    def schedule(self, tasks):
        """安排多任务的时间顺序"""
        total_time = 0
        schedule = []
        for task in tasks:
            duration = self.task_durations.get(task, 5)
            schedule.append(f"{task}: {duration}秒")
            total_time += duration
        return {
            'order': schedule,
            'total_time': total_time,
            'message': f"总耗时约 {total_time} 秒"
        }
    
    def record_event(self, event):
        """记录事件发生的时间"""
        event_record = {
            'event': event,
            'timestamp': time.time(),
            'time_str': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.event_timeline.append(event_record)
        return f"已记录: {event} 发生在 {event_record['time_str']}"
    
    def recall_event(self, event):
        """回忆事件发生的时间"""
        for e in reversed(self.event_timeline):
            if event in e['event']:
                return f"{event} 发生在 {e['time_str']}"
        return "不记得了"