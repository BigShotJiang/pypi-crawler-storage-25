import re

class LayoutReasoner:
    """
    空间布局推理模块：理解房间布局
    """
    
    def __init__(self):
        # 房间布局（简化的网格）
        self.rooms = {
            '客厅': {'x': 0, 'y': 0, 'objects': ['沙发', '电视', '茶几']},
            '厨房': {'x': 1, 'y': 0, 'objects': ['冰箱', '灶台', '水槽']},
            '卧室': {'x': 0, 'y': 1, 'objects': ['床', '衣柜', '书桌']},
            '书房': {'x': 1, 'y': 1, 'objects': ['书架', '电脑', '台灯']},
        }
        
        # 房间相邻关系
        self.adjacent = {
            '客厅': ['厨房', '卧室'],
            '厨房': ['客厅'],
            '卧室': ['客厅', '书房'],
            '书房': ['卧室']
        }
    
    def find_room_of_object(self, obj):
        """找到物体所在的房间"""
        for room, info in self.rooms.items():
            if obj in info['objects']:
                return room
        return None
    
    def get_relative_position(self, room1, room2):
        """获取两个房间的相对位置"""
        if room1 not in self.rooms or room2 not in self.rooms:
            return "不知道"
        
        x1, y1 = self.rooms[room1]['x'], self.rooms[room1]['y']
        x2, y2 = self.rooms[room2]['x'], self.rooms[room2]['y']
        
        if x1 < x2:
            return f"{room2} 在 {room1} 的右边"
        elif x1 > x2:
            return f"{room2} 在 {room1} 的左边"
        elif y1 < y2:
            return f"{room2} 在 {room1} 的下面"
        elif y1 > y2:
            return f"{room2} 在 {room1} 的上面"
        else:
            return f"{room1} 和 {room2} 在同一位置"
    
    def get_path(self, from_room, to_room):
        """获取从A房间到B房间的路径（简化版）"""
        if from_room == to_room:
            return f"已经在 {to_room}"
        
        if to_room in self.adjacent.get(from_room, []):
            return f"从 {from_room} 直接走到 {to_room}"
        
        # BFS找路径
        visited = set()
        queue = [(from_room, [from_room])]
        
        while queue:
            current, path = queue.pop(0)
            if current == to_room:
                steps = ' → '.join(path)
                return f"从 {from_room} 到 {to_room}: {steps}"
            
            visited.add(current)
            for neighbor in self.adjacent.get(current, []):
                if neighbor not in visited:
                    queue.append((neighbor, path + [neighbor]))
        
        return f"没有找到从 {from_room} 到 {to_room} 的路"
    
    def answer(self, question):
        """回答空间布局问题"""
        # 物体位置
        for obj in ['沙发', '电视', '冰箱', '床', '书桌', '电脑', '灶台', '水槽']:
            if obj in question and ('在哪' in question or '在哪里' in question):
                room = self.find_room_of_object(obj)
                if room:
                    return f"{obj} 在 {room}"
                return f"不知道 {obj} 在哪"
        
        # 提取所有房间名
        all_rooms = list(self.rooms.keys())
        found_rooms = [r for r in all_rooms if r in question]
        
        # 相对位置
        if ('左边' in question or '右边' in question or '上面' in question or '下面' in question or '哪边' in question) and len(found_rooms) >= 2:
            return self.get_relative_position(found_rooms[0], found_rooms[1])
        
        # 路径规划
        if ('怎么从' in question or '怎么去' in question) and len(found_rooms) >= 2:
            return self.get_path(found_rooms[0], found_rooms[1])
        
        return "不太明白你在问什么"