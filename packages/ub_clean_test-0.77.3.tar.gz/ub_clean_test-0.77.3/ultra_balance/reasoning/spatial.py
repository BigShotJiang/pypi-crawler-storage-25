class SpatialReasoner:
    """
    空间推理模块：理解方位、相对位置、空间关系
    """
    
    def __init__(self):
        # 物体位置数据库
        self.objects = {
            '桌子': {'x': 0, 'y': 0, 'z': 0.8, 'size': 'large'},
            '杯子': {'x': 0.2, 'y': 0.1, 'z': 0.9, 'size': 'small'},
            '冰箱': {'x': 2, 'y': 0, 'z': 1.5, 'size': 'large'},
            '椅子': {'x': -1, 'y': 0.5, 'z': 0.5, 'size': 'medium'},
            '门': {'x': 3, 'y': 0, 'z': 2, 'size': 'large'},
        }
        
        # 机器人当前位置
        self.robot_pos = {'x': 0, 'y': 0, 'z': 0}
    
    def understand_direction(self, direction):
        """理解方位"""
        directions = {
            '左': 'x 负方向',
            '右': 'x 正方向',
            '前': 'y 正方向',
            '后': 'y 负方向',
            '上': 'z 正方向',
            '下': 'z 负方向'
        }
        return directions.get(direction, '未知方向')
    
    def get_relative_position(self, obj1, obj2):
        """获取相对位置"""
        if obj1 not in self.objects or obj2 not in self.objects:
            return f"不知道 {obj1} 或 {obj2} 的位置"
        
        pos1 = self.objects[obj1]
        pos2 = self.objects[obj2]
        
        dx = pos1['x'] - pos2['x']
        dy = pos1['y'] - pos2['y']
        dz = pos1['z'] - pos2['z']
        
        relation = []
        if abs(dx) > 0.1:
            relation.append('右边' if dx > 0 else '左边')
        if abs(dy) > 0.1:
            relation.append('前面' if dy > 0 else '后面')
        if abs(dz) > 0.1:
            relation.append('上面' if dz > 0 else '下面')
        
        if not relation:
            return f"{obj1} 和 {obj2} 在同一位置"
        return f"{obj1} 在 {obj2} 的 {' '.join(relation)}"
    
    def is_inside(self, obj, container):
        """判断是否在里面"""
        if container not in self.objects:
            return f"不知道 {container} 在哪"
        # 简化的判断：容器是桌子/柜子
        if container in ['桌子', '柜子']:
            return f"{obj} 在 {container} 上面"  # 不是里面
        return f"{obj} 不在 {container} 里面"
    
    def answer_question(self, question):
        """回答空间问题"""
        if '在哪' in question:
            for obj in self.objects:
                if obj in question:
                    pos = self.objects[obj]
                    return f"{obj} 在 ({pos['x']}, {pos['y']}, {pos['z']})"
        elif '左边' in question or '右边' in question:
            return self.understand_direction('左' if '左边' in question else '右')
        elif '上面' in question:
            return self.get_relative_position('杯子', '桌子')
        
        return "不太明白你在问什么"