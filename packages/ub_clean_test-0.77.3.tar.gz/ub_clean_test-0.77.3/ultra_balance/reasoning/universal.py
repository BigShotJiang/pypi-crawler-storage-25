from typing import Dict, List, Any, Optional, Union
from .phi3 import Phi3Client
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import uuid
import time
import re


class TaskType(Enum):
    PERCEPTION = "perception"
    REASONING = "reasoning"
    DECISION = "decision"
    LEARNING = "learning"
    DIALOGUE = "dialogue"
    COLLABORATION = "collaboration"
    PLANNING = "planning"
    MEMORY = "memory"
    CREATIVITY = "creativity"
    VALUE = "value"


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


@dataclass
class UnifiedRequest:
    task_type: TaskType
    input: Any
    context: Dict[str, Any] = field(default_factory=dict)
    user_id: Optional[str] = None
    priority: int = 5


@dataclass
class UnifiedResponse:
    success: bool
    result: Any
    confidence: float
    explanation: str
    task_type: TaskType
    processing_time: float
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class UniversalReasoning:
    
    def __init__(self):
        self.version = "0.77.2"
        self.request_history: List[UnifiedResponse] = []
        self._modules = {}
        
        try:
            from ultra_balance.knowledge.load_experiences import UnitreeExperiences
            self.unitree_exp = UnitreeExperiences()
        except Exception as e:
            print(f"?? 宇树经验加载失败: {e}")
            self.unitree_exp = None
        
        self._init_modules()
        
        try:
            from .phi3 import Phi3Client
            self.phi3 = Phi3Client()
            if self.phi3.available:
                print("? phi3:mini 已加载")
            else:
                print("?? phi3:mini 不可用")
        except Exception as e:
            self.phi3 = None
            print(f"?? phi3:mini 加载失败: {e}")
    
    def _init_modules(self):
        try:
            from ultra_balance.reasoning.logical import LogicalReasoning
            self._modules["logical"] = LogicalReasoning()
        except:
            self._modules["logical"] = None
        
        try:
            from ultra_balance.reasoning.common_sense import CommonSense
            self._modules["common_sense"] = CommonSense()
        except:
            self._modules["common_sense"] = None
        
        try:
            from ultra_balance.reasoning.decision import DecisionReasoning
            self._modules["decision"] = DecisionReasoning()
        except:
            self._modules["decision"] = None
        
        try:
            from ultra_balance.reasoning.dialogue import DialogueManager
            self._modules["dialogue"] = DialogueManager()
        except:
            self._modules["dialogue"] = None
        
        try:
            from ultra_balance.reasoning.strategy import StrategyGeneration
            self._modules["strategy"] = StrategyGeneration()
        except:
            self._modules["strategy"] = None
    
    def reason(self, request: UnifiedRequest) -> UnifiedResponse:
        start_time = time.time()
        
        try:
            result = self._route(request)
            confidence = 0.8
            explanation = f"处理了{request.task_type.value}任务"
            success = True
        except Exception as e:
            result = {"error": str(e)}
            confidence = 0.0
            explanation = f"处理出错: {str(e)}"
            success = False
        
        processing_time = time.time() - start_time
        
        response = UnifiedResponse(
            success=success,
            result=result,
            confidence=confidence,
            explanation=explanation,
            task_type=request.task_type,
            processing_time=processing_time
        )
        
        self.request_history.append(response)
        return response
    
    def _route(self, request: UnifiedRequest) -> Any:
        if request.task_type == TaskType.REASONING:
            return self._handle_reasoning(request)
        elif request.task_type == TaskType.DECISION:
            return self._handle_decision(request)
        elif request.task_type == TaskType.DIALOGUE:
            return self._handle_dialogue(request)
        elif request.task_type == TaskType.PLANNING:
            return self._handle_planning(request)
        else:
            return {"message": f"处理{request.task_type.value}任务", "input": request.input}
    
    def _handle_reasoning(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        input_str = str(input_data).lower()
        
        # 1. Phi-3 处理
        if hasattr(self, 'phi3') and self.phi3 and self.phi3.available:
            if any(k in input_str for k in ["翻译", "代码", "写", "计算", "什么意思", "英文", "中文", "等于", "多少", "加", "减", "乘", "除", "=", "+", "-", "*", "/"]):
                result = self.phi3.chat(str(input_data))
                if result:
                    return {"type": "phi3", "result": result, "source": "phi3:mini"}
        
        # 2. 宇树经验查询
        if hasattr(self, 'unitree_exp') and self.unitree_exp:
            if any(k in input_str for k in ["捡", "pickup", "枕头", "堆", "积木", "block", "stack", "擦", "桌子", "wipe", "table", "叠", "毛巾", "fold", "towel", "倒", "药水", "pour", "medicine"]):
                result = self.unitree_exp.query(input_str)
                if result.get("found"):
                    return result
        
        # 3. 翻译降级
        if "翻译" in input_str:
            trans_dict = {
                "我要喝水": "I want to drink water",
                "你好": "Hello",
                "谢谢": "Thank you",
                "再见": "Goodbye",
                "早上好": "Good morning",
            }
            for cn, en in trans_dict.items():
                if cn in str(input_data):
                    return {"result": en, "explanation": f"「{cn}」→「{en}」", "source": "builtin"}
        
        # 4. 计算降级
        if any(op in input_str for op in ['+', '-', '等于', '多少', '加', '减']):
            nums = re.findall(r'\d+\.?\d*', str(input_data))
            if len(nums) >= 2:
                a, b = float(nums[0]), float(nums[1])
                if '+' in input_str or '加' in input_str:
                    result = a + b
                    return {"result": result, "explanation": f"{a}+{b}={result}", "source": "builtin"}
                elif '-' in input_str or '减' in input_str:
                    result = a - b
                    return {"result": result, "explanation": f"{a}-{b}={result}", "source": "builtin"}
        
        # 5. 代码降级
        if "冒泡" in input_str:
            code = '''def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return arr'''
            return {"result": code, "explanation": "冒泡排序 Python 实现", "source": "builtin"}
        
        if "斐波那契" in input_str:
            code = '''def fibonacci(n):
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n+1):
        a, b = b, a + b
    return b'''
            return {"result": code, "explanation": "斐波那契数列", "source": "builtin"}
        
        # 6. 字符串格式的三段论（交互模式兼容）
        if isinstance(input_data, str):
            if "所有人都会死" in input_data and "苏格拉底" in input_data:
                return {
                    "result": "推理成立",
                    "explanation": "所有人都会死，苏格拉底是人，所以苏格拉底会死",
                    "type": "syllogism",
                    "valid": True,
                    "source": "builtin"
                }
        
        # 7. 字典格式的三段论（demo 模式）
        if self._modules.get("logical") and isinstance(input_data, dict):
            if "major" in input_data:
                result = self._modules["logical"].syllogism(
                    input_data.get("major", ""),
                    input_data.get("minor", ""),
                    input_data.get("conclusion", "")
                )
                return result
        
        # 8. 日常常识
        if self._modules.get("common_sense") and isinstance(input_data, str):
            result = self._modules["common_sense"].daily(input_data)
            return result
        
        return {"type": "reasoning_result", "input": input_data, "conclusion": f"推理: {input_data}"}
    
    def _handle_decision(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        
        if self._modules.get("decision") and isinstance(input_data, dict):
            if "options" in input_data:
                result = self._modules["decision"].compare_options(input_data["options"])
                return result
        
        return {"type": "decision_result", "input": input_data, "decision": "已做出决策"}
    
    def _handle_dialogue(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        
        if self._modules.get("dialogue") and isinstance(input_data, str):
            result = self._modules["dialogue"].generate_response(input_data)
            return result
        
        return {"type": "dialogue_result", "response": f"收到: {input_data}"}
    
    def _handle_planning(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        
        if self._modules.get("strategy") and isinstance(input_data, str):
            strategies = self._modules["strategy"].generate_strategy(input_data)
            if strategies:
                return {"strategies": [s.name for s in strategies], "best": strategies[0].name}
        
        return {"type": "planning_result", "plan": f"规划: {input_data}", "steps": ["分析", "执行", "验证"]}
    
    def reason_text(self, text: str, task_type: str = "reasoning") -> UnifiedResponse:
        task_map = {
            "reasoning": TaskType.REASONING,
            "decision": TaskType.DECISION,
            "dialogue": TaskType.DIALOGUE,
            "planning": TaskType.PLANNING,
            "learning": TaskType.LEARNING,
            "collaboration": TaskType.COLLABORATION,
        }
        ttype = task_map.get(task_type, TaskType.REASONING)
        
        request = UnifiedRequest(task_type=ttype, input=text)
        return self.reason(request)
    
    def reason_dict(self, data: Dict, task_type: str = "reasoning") -> UnifiedResponse:
        task_map = {
            "reasoning": TaskType.REASONING,
            "decision": TaskType.DECISION,
            "dialogue": TaskType.DIALOGUE,
            "planning": TaskType.PLANNING,
        }
        ttype = task_map.get(task_type, TaskType.REASONING)
        
        request = UnifiedRequest(task_type=ttype, input=data)
        return self.reason(request)
    
    def get_statistics(self) -> Dict:
        success_count = sum(1 for r in self.request_history if r.success)
        
        return {
            "version": self.version,
            "total_requests": len(self.request_history),
            "success_rate": success_count / len(self.request_history) if self.request_history else 1.0,
            "avg_confidence": sum(r.confidence for r in self.request_history) / len(self.request_history) if self.request_history else 0,
        }
    
    # ========== v0.77.0 新增：任务推理 ==========
    
    def reason_task(self, task_name: str) -> UnifiedResponse:
        """
        任务推理入口 v0.77.0
        
        根据任务名称生成行为树
        
        Args:
            task_name: 任务名称（如 "捡枕头"、"堆积木"）
            
        Returns:
            UnifiedResponse 包含行为树 JSON
        """
        start_time = time.time()
        
        try:
            # 预定义任务模板
            task_templates = {
                "捡枕头": self._create_pickup_pillow_tree,
                "pickup_pillow": self._create_pickup_pillow_tree,
                "堆积木": self._create_block_stacking_tree,
                "block_stacking": self._create_block_stacking_tree,
                "擦桌子": self._create_wipe_table_tree,
                "wipe_table": self._create_wipe_table_tree,
                "叠毛巾": self._create_fold_towel_tree,
                "fold_towel": self._create_fold_towel_tree,
                "倒药水": self._create_pour_medicine_tree,
                "pour_medicine": self._create_pour_medicine_tree,
            }
            
            # 查找任务模板
            creator = task_templates.get(task_name)
            if creator is None:
                # 尝试经验库查询
                if hasattr(self, 'unitree_exp') and self.unitree_exp:
                    exp = self.unitree_exp.query(task_name)
                    if exp.get('found'):
                        tree = self._create_tree_from_experience(exp)
                    else:
                        tree = self._create_default_tree(task_name)
                else:
                    tree = self._create_default_tree(task_name)
            else:
                tree = creator()
            
            result = {
                'task_name': task_name,
                'behavior_tree': tree.to_dict(),
                'behavior_tree_json': tree.to_json()
            }
            
            success = True
            explanation = f"为任务「{task_name}」生成行为树"
            confidence = 0.8
            
        except Exception as e:
            result = {"error": str(e)}
            success = False
            explanation = f"生成行为树失败: {str(e)}"
            confidence = 0.0
        
        processing_time = time.time() - start_time
        
        response = UnifiedResponse(
            success=success,
            result=result,
            confidence=confidence,
            explanation=explanation,
            task_type=TaskType.PLANNING,
            processing_time=processing_time
        )
        
        self.request_history.append(response)
        return response
    
    def _create_pickup_pillow_tree(self):
        """创建捡枕头行为树"""
        from ultra_balance.decision.behavior_tree import BehaviorTreeBuilder
        
        return (BehaviorTreeBuilder("捡枕头")
                .selector("任务选择")
                    .sequence("主流程")
                        .condition("pillow_detected", "检测枕头")
                        .action("move_to_object", "移动到枕头")
                        .action("grasp_object", "抓取枕头")
                        .action("move_to_target", "移动到目标")
                        .action("release_object", "释放枕头")
                    .end()
                    .action("search_object", "搜索枕头")
                .end()
                .build())
    
    def _create_block_stacking_tree(self):
        """创建堆积木行为树"""
        from ultra_balance.decision.behavior_tree import BehaviorTreeBuilder
        
        return (BehaviorTreeBuilder("堆积木")
                .selector("任务选择")
                    .sequence("主流程")
                        .condition("block_detected", "检测积木")
                        .action("move_to_block", "移动到积木")
                        .action("grasp_block", "抓取积木")
                        .action("move_to_stack", "移动到堆叠位置")
                        .action("place_block", "放置积木")
                    .end()
                    .action("search_block", "搜索积木")
                .end()
                .build())
    
    def _create_wipe_table_tree(self):
        """创建擦桌子行为树"""
        from ultra_balance.decision.behavior_tree import BehaviorTreeBuilder
        
        return (BehaviorTreeBuilder("擦桌子")
                .sequence("主流程")
                    .action("move_to_table", "移动到桌子")
                    .action("grasp_cloth", "抓取抹布")
                    .repeater(5, "擦拭循环")
                        .sequence("单次擦拭")
                            .action("wipe_forward", "向前擦")
                            .action("wipe_backward", "向后擦")
                        .end()
                    .end()
                    .action("release_cloth", "放下抹布")
                .end()
                .build())
    
    def _create_fold_towel_tree(self):
        """创建叠毛巾行为树"""
        from ultra_balance.decision.behavior_tree import BehaviorTreeBuilder
        
        return (BehaviorTreeBuilder("叠毛巾")
                .sequence("主流程")
                    .action("move_to_towel", "移动到毛巾")
                    .action("flatten_towel", "展平毛巾")
                    .action("fold_half", "对折")
                    .action("fold_quarter", "再对折")
                    .action("press_towel", "压实")
                .end()
                .build())
    
    def _create_pour_medicine_tree(self):
        """创建倒药水行为树"""
        from ultra_balance.decision.behavior_tree import BehaviorTreeBuilder
        
        return (BehaviorTreeBuilder("倒药水")
                .sequence("主流程")
                    .action("move_to_bottle", "移动到药瓶")
                    .action("grasp_bottle", "抓取药瓶")
                    .action("move_to_cup", "移动到杯子")
                    .action("tilt_bottle", "倾斜倒入")
                    .action("upright_bottle", "回正药瓶")
                    .action("return_bottle", "放回药瓶")
                .end()
                .build())
    
    def _create_default_tree(self, task_name: str):
        """创建默认行为树"""
        from ultra_balance.decision.behavior_tree import BehaviorTreeBuilder
        
        return (BehaviorTreeBuilder(task_name)
                .sequence("默认流程")
                    .action("approach", f"接近{task_name}")
                    .action("execute", f"执行{task_name}")
                    .action("verify", "验证结果")
                .end()
                .build())
    
    def _create_tree_from_experience(self, exp: dict):
        """从经验数据创建行为树"""
        from ultra_balance.decision.behavior_tree import BehaviorTreeBuilder
        
        task = exp.get('task', 'unknown')
        steps = exp.get('steps', ['approach', 'execute', 'verify'])
        
        builder = BehaviorTreeBuilder(task)
        seq = builder.sequence("经验流程")
        
        for step in steps:
            seq.action(step, step)
        
        return seq.end().build()
