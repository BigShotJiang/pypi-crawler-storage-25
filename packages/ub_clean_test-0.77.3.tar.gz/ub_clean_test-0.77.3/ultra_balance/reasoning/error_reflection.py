from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import random


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


@dataclass
class ErrorRecord:
    """错误记录"""
    error_id: str
    error_type: str  # reasoning / perception / decision / execution
    description: str
    context: Dict
    cause: Optional[str] = None
    fix: Optional[str] = None
    severity: int = 5  # 1-10, 10最严重
    occurred_at: str = field(default_factory=lambda: datetime.now().isoformat())
    resolved_at: Optional[str] = None
    resolved: bool = False


@dataclass
class Lesson:
    """学到的教训"""
    lesson_id: str
    content: str
    from_error_id: str
    applied_count: int = 0
    success_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


class ErrorReflection:
    """
    错误反思模块 (0.63.0)
    能力：错误记录、原因分析、教训提取、行为修正、自我改进
    """
    
    def __init__(self):
        self.error_history: List[ErrorRecord] = []
        self.lessons: List[Lesson] = []
        self.correction_rules: Dict[str, str] = {}  # 错误类型 -> 修正规则
        self.reflection_log: List[Dict] = []
        
        # 初始化修正规则
        self._init_correction_rules()
    
    def _init_correction_rules(self):
        """初始化预置修正规则"""
        self.correction_rules = {
            "推理矛盾": "检查前提条件，重新推理",
            "信息不足": "主动提问获取更多信息",
            "执行失败": "检查硬件状态，重试或降级",
            "超时": "缩短推理链，使用更简单的规则",
            "重复错误": "记录到教训库，下次主动规避",
        }
    
    # ========== 1. 错误记录 ==========
    def record_error(self, error_type: str, description: str, 
                     context: Dict = None, severity: int = 5) -> str:
        """
        记录错误
        
        参数：
            error_type: 错误类型
            description: 错误描述
            context: 上下文
            severity: 严重程度 1-10
            
        返回：
            错误ID
        """
        if context is None:
            context = {}
        
        error_id = f"ERR_{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.error_history)}"
        
        error = ErrorRecord(
            error_id=error_id,
            error_type=error_type,
            description=description,
            context=context,
            severity=severity
        )
        self.error_history.append(error)
        
        self._log_reflection("record_error", error_id, description)
        
        return error_id
    
    # ========== 2. 原因分析 ==========
    def analyze_cause(self, error_id: str) -> Dict:
        """
        分析错误原因
        
        参数：
            error_id: 错误ID
            
        返回：
            {
                "cause": str,
                "confidence": float,
                "suggestions": List[str]
            }
        """
        # 查找错误
        error = None
        for e in self.error_history:
            if e.error_id == error_id:
                error = e
                break
        
        if not error:
            return {
                "cause": "未找到错误记录",
                "confidence": 0.0,
                "suggestions": []
            }
        
        # 根据错误类型和描述分析原因
        cause = self._infer_cause(error)
        suggestions = self._get_suggestions(error)
        
        # 更新错误记录
        error.cause = cause
        self._log_reflection("analyze_cause", error_id, cause)
        
        return {
            "cause": cause,
            "confidence": 0.7,
            "suggestions": suggestions
        }
    
    def _infer_cause(self, error: ErrorRecord) -> str:
        """推断错误原因"""
        desc = error.description.lower()
        error_type = error.error_type
        
        # 常见错误模式
        if "缺" in desc or "not found" in desc or "不存在" in desc:
            return "缺少必要信息或资源"
        if "超时" in desc or "timeout" in desc:
            return "执行时间过长，可能因为推理链太深或资源繁忙"
        if "矛盾" in desc or "conflict" in desc:
            return "知识库中存在矛盾信息"
        if "执行" in desc and "失败" in desc:
            return "硬件或API调用失败"
        if "推理" in desc and "错误" in desc:
            return "推理规则不适用或前提条件不满足"
        
        return f"未知原因，错误类型: {error_type}"
    
    def _get_suggestions(self, error: ErrorRecord) -> List[str]:
        """获取修正建议"""
        suggestions = []
        
        for key, rule in self.correction_rules.items():
            if key in error.description or key in error.error_type:
                suggestions.append(rule)
        
        if not suggestions:
            suggestions = ["重新审视任务", "检查输入是否正确", "尝试简化问题"]
        
        return suggestions
    
    # ========== 3. 教训提取 ==========
    def extract_lesson(self, error_id: str) -> Optional[str]:
        """
        从错误中提取教训
        
        参数：
            error_id: 错误ID
            
        返回：
            教训ID
        """
        # 查找错误
        error = None
        for e in self.error_history:
            if e.error_id == error_id:
                error = e
                break
        
        if not error or not error.cause:
            return None
        
        # 生成教训内容
        lesson_content = self._generate_lesson(error)
        
        # 检查是否已有类似教训
        for existing in self.lessons:
            if lesson_content in existing.content:
                return existing.lesson_id
        
        # 创建新教训
        lesson_id = f"LSN_{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.lessons)}"
        lesson = Lesson(
            lesson_id=lesson_id,
            content=lesson_content,
            from_error_id=error_id
        )
        self.lessons.append(lesson)
        
        self._log_reflection("extract_lesson", lesson_id, lesson_content)
        
        return lesson_id
    
    def _generate_lesson(self, error: ErrorRecord) -> str:
        """生成教训文本"""
        templates = [
            f"避免{error.error_type}类型的错误：{error.cause}，建议{error.context.get('fix', '检查条件')}",
            f"当遇到{error.description}时，应该先{self._get_suggestions(error)[0]}",
            f"错误教训：{error.cause}会导致{error.error_type}，下次注意规避",
        ]
        return random.choice(templates)
    
    # ========== 4. 行为修正 ==========
    def apply_correction(self, error_id: str, fix: str) -> bool:
        """
        应用修正
        
        参数：
            error_id: 错误ID
            fix: 修正方案
            
        返回：
            是否成功
        """
        for error in self.error_history:
            if error.error_id == error_id:
                error.fix = fix
                error.resolved = True
                error.resolved_at = datetime.now().isoformat()
                
                # 将修正加入规则库
                self.correction_rules[error.error_type] = fix
                
                self._log_reflection("apply_correction", error_id, fix)
                return True
        
        return False
    
    def get_correction_rule(self, error_type: str) -> Optional[str]:
        """获取错误类型的修正规则"""
        return self.correction_rules.get(error_type)
    
    # ========== 5. 自我改进 ==========
    def improve(self) -> Dict:
        """
        自我改进：回顾错误，应用教训
        
        返回：
            {
                "improvements": List[str],
                "lessons_applied": int
            }
        """
        improvements = []
        lessons_applied = 0
        
        # 找出未解决的高严重性错误
        unresolved_errors = [e for e in self.error_history if not e.resolved]
        high_severity = [e for e in unresolved_errors if e.severity >= 7]
        
        for error in high_severity:
            # 分析原因
            cause_result = self.analyze_cause(error.error_id)
            
            # 提取教训
            lesson_id = self.extract_lesson(error.error_id)
            
            if lesson_id:
                improvements.append(f"针对{error.error_type}: {cause_result['cause']}")
                lessons_applied += 1
        
        # 应用已有教训
        for lesson in self.lessons:
            if lesson.applied_count < 3:  # 每条教训至少应用3次
                lesson.applied_count += 1
                improvements.append(f"应用教训: {lesson.content[:50]}...")
        
        return {
            "improvements": improvements,
            "lessons_applied": lessons_applied,
            "total_lessons": len(self.lessons)
        }
    
    # ========== 6. 反思报告 ==========
    def reflect(self) -> Dict:
        """
        生成反思报告
        
        返回：
            {
                "total_errors": int,
                "resolved_count": int,
                "common_errors": List[str],
                "lessons_learned": List[str],
                "recommendations": List[str]
            }
        """
        # 统计错误类型
        error_types = {}
        for error in self.error_history:
            error_types[error.error_type] = error_types.get(error.error_type, 0) + 1
        
        # 最常见的错误类型
        common_errors = sorted(error_types.items(), key=lambda x: x[1], reverse=True)[:3]
        common_errors_str = [f"{etype}({count}次)" for etype, count in common_errors]
        
        # 已学教训
        lessons_learned = [l.content for l in self.lessons[-5:]]  # 最近5条
        
        # 改进建议
        recommendations = []
        for error in self.error_history:
            if not error.resolved and error.severity >= 7:
                recommendations.append(f"建议优先解决: {error.description}")
        
        return {
            "total_errors": len(self.error_history),
            "resolved_count": sum(1 for e in self.error_history if e.resolved),
            "common_errors": common_errors_str,
            "lessons_learned": lessons_learned,
            "recommendations": recommendations[:3]
        }
    
    # ========== 7. 防止重复犯错 ==========
    def check_before_action(self, action: str, context: Dict = None) -> Dict:
        """
        执行前检查，防止重复犯错
        
        参数：
            action: 即将执行的动作
            context: 上下文
            
        返回：
            {
                "safe": bool,
                "warnings": List[str],
                "suggestions": List[str]
            }
        """
        if context is None:
            context = {}
        
        warnings = []
        suggestions = []
        
        # 检查历史教训
        for lesson in self.lessons:
            if any(word in action for word in lesson.content.split()):
                warnings.append(f"之前犯过类似错误: {lesson.content[:50]}")
                suggestions.append("建议先确认条件是否满足")
        
        # 检查相关错误
        for error in self.error_history:
            if error.error_type in action and not error.resolved:
                warnings.append(f"存在未解决的{error.error_type}问题")
                if error.fix:
                    suggestions.append(error.fix)
        
        safe = len(warnings) == 0
        
        return {
            "safe": safe,
            "warnings": warnings,
            "suggestions": suggestions
        }
    
    # ========== 8. 统计报告 ==========
    def get_statistics(self) -> Dict:
        """获取错误反思统计"""
        resolved = sum(1 for e in self.error_history if e.resolved)
        high_severity = sum(1 for e in self.error_history if e.severity >= 7)
        
        return {
            "total_errors": len(self.error_history),
            "resolved_errors": resolved,
            "resolution_rate": resolved / len(self.error_history) if self.error_history else 0,
            "high_severity_count": high_severity,
            "total_lessons": len(self.lessons),
            "lessons_applied": sum(l.applied_count for l in self.lessons),
            "correction_rules": len(self.correction_rules)
        }
    
    def _log_reflection(self, action: str, target: str, detail: str):
        """记录反思日志"""
        self.reflection_log.append({
            "action": action,
            "target": target,
            "detail": detail,
            "timestamp": datetime.now().isoformat()
        })