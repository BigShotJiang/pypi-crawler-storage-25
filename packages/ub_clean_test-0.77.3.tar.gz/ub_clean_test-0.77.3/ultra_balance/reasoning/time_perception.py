import time
from datetime import datetime, timedelta

class TimePerception:
    """
    时间感知模块：理解时间概念
    """
    
    def __init__(self):
        # 模糊时间词映射（秒）
        self.fuzzy_times = {
            '马上': 5,
            '立刻': 3,
            '一会儿': 30,
            '等一下': 60,
            '稍等': 15,
            '好久': 300,
            '很久': 600,
        }
    
    def get_current_time(self):
        """获取当前时间"""
        now = datetime.now()
        return now.strftime("%Y年%m月%d日 %H:%M:%S")
    
    def get_current_hour(self):
        """获取当前小时"""
        return datetime.now().hour
    
    def parse_time_word(self, text):
        """解析时间词"""
        for word, seconds in self.fuzzy_times.items():
            if word in text:
                return seconds, word
        return None, None
    
    def parse_relative_time(self, text):
        """解析相对时间，如“5分钟后”"""
        import re
        match = re.search(r'(\d+)\s*分钟', text)
        if match:
            minutes = int(match.group(1))
            return minutes * 60, f"{minutes}分钟后"
        match = re.search(r'(\d+)\s*秒', text)
        if match:
            return int(match.group(1)), f"{match.group(1)}秒后"
        return None, None
    
    def parse_time_point(self, text):
        """解析具体时间点，如“下午3点”"""
        import re
        # 匹配“下午3点”、“3点”、“15点”
        match = re.search(r'(上午|下午|中午|晚上)?(\d{1,2})点', text)
        if match:
            period = match.group(1) or ''
            hour = int(match.group(2))
            if period == '下午' and hour < 12:
                hour += 12
            elif period == '晚上' and hour < 12:
                hour += 12
            elif period == '中午' and hour == 12:
                hour = 12
            return hour
        return None
    
    def understand(self, text):
        """理解时间表达"""
        # 模糊时间词
        seconds, word = self.parse_time_word(text)
        if seconds:
            return f"{word} 大概 {seconds} 秒"
        
        # 相对时间
        seconds, desc = self.parse_relative_time(text)
        if seconds:
            return f"{desc}，即 {seconds} 秒"
        
        # 具体时间点
        hour = self.parse_time_point(text)
        if hour:
            now = datetime.now()
            target = now.replace(hour=hour, minute=0, second=0)
            if target < now:
                target += timedelta(days=1)
            wait_seconds = (target - now).total_seconds()
            return f"{text}，还有 {int(wait_seconds/60)} 分钟"
        
        return "我不太理解这个时间"
    
    def schedule(self, text, callback):
        """时间规划（模拟）"""
        seconds, _ = self.parse_relative_time(text)
        if not seconds:
            seconds, _ = self.parse_time_word(text)
        
        if seconds:
            return f"好的，{seconds}秒后提醒你"
        return "我不太理解什么时候提醒"