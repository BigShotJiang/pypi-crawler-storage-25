import re

class EmotionUnderstanding:
    """
    情感理解模块：理解情绪背后的原因
    """
    
    def __init__(self):
        # 基本情绪映射
        self.emotions = {
            '开心': {'强度': 5, '回应': '看到你开心，我也开心！', '追问': '有什么好事吗？'},
            '难过': {'强度': 5, '回应': '别难过，我在这里陪你。', '追问': '发生什么事了？'},
            '生气': {'强度': 5, '回应': '别生气了，消消气。', '追问': '是什么让你这么生气？'},
            '害怕': {'强度': 5, '回应': '别怕，有我在呢。', '追问': '你害怕什么？'},
            '惊讶': {'强度': 5, '回应': '哇，真的吗？', '追问': '是什么让你这么惊讶？'},
        }
        
        # 强度修饰词
        self.intensity_modifiers = {
            '有点': 3,
            '比较': 4,
            '很': 7,
            '非常': 8,
            '太': 9,
            '超级': 10,
        }
        
        # 原因连接词
        self.cause_words = ['因为', '由于', '所以', '因此']
        
        self.current_emotion = 'neutral'
        self.current_intensity = 5
    
    def parse_emotion(self, text):
        """解析情绪"""
        # 先匹配强度
        intensity = 5
        intensity_word = None
        for word, val in self.intensity_modifiers.items():
            if word in text:
                intensity = val
                intensity_word = word
                text = text.replace(word, '')
        
        # 再匹配情绪
        for emotion in self.emotions:
            if emotion in text:
                return emotion, intensity, self.emotions[emotion]
        return None, None, None
    
    def parse_cause(self, text):
        """解析原因"""
        for word in self.cause_words:
            if word in text:
                parts = text.split(word, 1)
                if len(parts) > 1:
                    return parts[1].strip()
        return None
    
    def understand(self, text):
        """理解情感表达"""
        # 提取原因
        cause = self.parse_cause(text)
        
        # 解析情绪
        emotion, intensity, info = self.parse_emotion(text)
        if emotion:
            self.current_emotion = emotion
            self.current_intensity = intensity
            
            # 根据强度调整回应
            if intensity <= 3:
                desc = f"有点{emotion}"
            elif intensity <= 6:
                desc = f"{emotion}"
            elif intensity <= 8:
                desc = f"很{emotion}"
            else:
                desc = f"非常{emotion}"
            
            response = info['回应']
            if cause:
                return f"你{desc}，因为{cause}。{response}"
            else:
                return f"你{desc}。{response} {info['追问']}"
        
        return "我不太理解你的情绪"
    
    def respond_to_emotion(self, emotion, intensity=5):
        """根据情绪回应"""
        if emotion in self.emotions:
            info = self.emotions[emotion]
            if intensity <= 3:
                return f"有点{emotion}啊，{info['回应']}"
            elif intensity <= 7:
                return f"{emotion}了，{info['回应']}"
            else:
                return f"这么{emotion}，{info['回应']}"
        return "嗯，我听到了"
    
    def get_current_emotion(self):
        """获取当前情绪"""
        if self.current_emotion == 'neutral':
            return "情绪平稳"
        
        desc = "很" if self.current_intensity > 7 else ""
        if self.current_intensity < 4:
            desc = "有点"
        return f"{desc}{self.current_emotion}"