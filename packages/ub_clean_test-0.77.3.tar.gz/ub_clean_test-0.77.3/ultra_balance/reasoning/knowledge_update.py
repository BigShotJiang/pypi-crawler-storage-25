from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import hashlib


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


class KnowledgeType(Enum):
    FACT = "fact"           # 事实
    RULE = "rule"           # 规则
    COMMON_SENSE = "common_sense"  # 常识
    PREFERENCE = "preference"      # 偏好
    SKILL = "skill"                # 技能


@dataclass
class KnowledgeItem:
    """知识条目"""
    id: str
    content: str
    knowledge_type: KnowledgeType
    source: str  # user / system / learned
    confidence: float
    tags: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    expires_at: Optional[str] = None
    version: int = 1
    usage_count: int = 0
    success_count: int = 0


@dataclass
class UpdateRecord:
    """更新记录"""
    update_id: str
    action: str  # add / update / delete / replace
    knowledge_id: str
    old_content: Optional[str]
    new_content: Optional[str]
    reason: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class KnowledgeUpdate:
    """
    知识更新模块 (0.64.0)
    能力：用户教新知识、更新已有知识、删除过时知识、知识版本管理、知识冲突解决
    """
    
    def __init__(self):
        self.knowledge_base: Dict[str, KnowledgeItem] = {}
        self.update_history: List[UpdateRecord] = []
        self.conflict_resolution_strategy = "confidence"  # confidence / time / user_priority
        self.version_counter = 1
        
        # 初始化基础知识
        self._init_base_knowledge()
    
    def _init_base_knowledge(self):
        """初始化基础知识"""
        base_knowledge = [
            ("水在100度沸腾", KnowledgeType.FACT, 0.9, ["物理", "科学"]),
            ("红灯停绿灯行", KnowledgeType.RULE, 0.95, ["交通", "安全"]),
            ("吃饭前要洗手", KnowledgeType.COMMON_SENSE, 0.85, ["卫生", "日常"]),
            ("用户喜欢简洁回答", KnowledgeType.PREFERENCE, 0.7, ["用户偏好"]),
        ]
        for content, ktype, conf, tags in base_knowledge:
            self.add_knowledge(content, ktype, "system", conf, tags)
    
    # ========== 1. 添加新知识 ==========
    def add_knowledge(self, content: str, knowledge_type: KnowledgeType, 
                      source: str, confidence: float = 0.7, 
                      tags: List[str] = None, expires_at: str = None) -> str:
        """
        添加新知识
        
        参数：
            content: 知识内容
            knowledge_type: 知识类型
            source: 来源
            confidence: 置信度
            tags: 标签
            expires_at: 过期时间
            
        返回：
            知识ID
        """
        if tags is None:
            tags = []
        
        # 检查是否已存在
        existing_id = self._find_similar_knowledge(content)
        if existing_id:
            # 如果存在，更新而不是添加
            return self.update_knowledge(existing_id, content, f"更新已有知识", confidence)
        
        # 生成唯一ID
        knowledge_id = self._generate_id(content)
        
        # 检查冲突
        conflicts = self.detect_conflicts(content, knowledge_type)
        if conflicts and self.conflict_resolution_strategy == "user_priority":
            # 如果有冲突且策略是用户优先，提示用户
            pass
        
        item = KnowledgeItem(
            id=knowledge_id,
            content=content,
            knowledge_type=knowledge_type,
            source=source,
            confidence=confidence,
            tags=tags,
            expires_at=expires_at,
            version=1
        )
        
        self.knowledge_base[knowledge_id] = item
        
        # 记录更新
        self._record_update("add", knowledge_id, None, content, f"用户添加: {content[:50]}")
        
        return knowledge_id
    
    def _generate_id(self, content: str) -> str:
        """生成知识ID"""
        hash_val = hashlib.md5(content.encode()).hexdigest()[:8]
        return f"KNW_{self.version_counter:04d}_{hash_val}"
    
    def _find_similar_knowledge(self, content: str) -> Optional[str]:
        """查找相似知识"""
        for kid, item in self.knowledge_base.items():
            if item.content == content or content in item.content or item.content in content:
                return kid
        return None
    
    # ========== 2. 用户教学 ==========
    def teach(self, user_input: str, category: str = "general") -> Dict:
        """
        用户教学：从自然语言中学习新知识
        
        参数：
            user_input: 用户输入，如 "你应该记住：我家的门牌号是101"
            category: 分类
            
        返回：
            {
                "learned": bool,
                "knowledge_id": str,
                "content": str,
                "message": str
            }
        """
        # 提取知识
        extracted = self._extract_knowledge_from_text(user_input)
        
        if not extracted:
            return {
                "learned": False,
                "knowledge_id": None,
                "content": None,
                "message": "我没能从这句话中提取出知识，请说得更明确些。例如：'记住：客厅在右边'"
            }
        
        # 确定知识类型
        ktype = self._infer_knowledge_type(user_input, category)
        
        # 添加知识
        knowledge_id = self.add_knowledge(
            content=extracted,
            knowledge_type=ktype,
            source="user",
            confidence=0.8,
            tags=[category]
        )
        
        return {
            "learned": True,
            "knowledge_id": knowledge_id,
            "content": extracted,
            "message": f"? 已记住：{extracted}"
        }
    
    def _extract_knowledge_from_text(self, text: str) -> Optional[str]:
        """从文本中提取知识"""
        # 常见教学模式
        patterns = [
            ("记住：", "记住："),
            ("记住:", "记住:"),
            ("你要记住", "你要记住"),
            ("记得", "记得"),
            ("重要：", "重要："),
            ("重要:", "重要:"),
            ("学习：", "学习："),
            ("学习:", "学习:"),
        ]
        
        for pattern, marker in patterns:
            if pattern in text:
                parts = text.split(pattern, 1)
                if len(parts) > 1:
                    knowledge = parts[1].strip()
                    if len(knowledge) > 2:
                        return knowledge
        
        # 如果没有明确标记，且文本较短，可能本身就是知识
        if len(text) < 50 and "？" not in text and "?" not in text:
            return text.strip()
        
        return None
    
    def _infer_knowledge_type(self, text: str, category: str) -> KnowledgeType:
        """推断知识类型"""
        if "如果" in text and "那么" in text:
            return KnowledgeType.RULE
        if "喜欢" in text or "偏好" in text or "prefer" in text:
            return KnowledgeType.PREFERENCE
        if category in ["skill", "技能"]:
            return KnowledgeType.SKILL
        
        return KnowledgeType.FACT
    
    # ========== 3. 更新知识 ==========
    def update_knowledge(self, knowledge_id: str, new_content: str, 
                         reason: str, new_confidence: float = None) -> bool:
        """
        更新已有知识
        
        参数：
            knowledge_id: 知识ID
            new_content: 新内容
            reason: 更新原因
            new_confidence: 新置信度
            
        返回：
            是否成功
        """
        if knowledge_id not in self.knowledge_base:
            return False
        
        old_item = self.knowledge_base[knowledge_id]
        old_content = old_item.content
        
        # 更新内容
        old_item.content = new_content
        old_item.updated_at = datetime.now().isoformat()
        old_item.version += 1
        
        if new_confidence is not None:
            old_item.confidence = new_confidence
        
        # 记录更新
        self._record_update("update", knowledge_id, old_content, new_content, reason)
        
        return True
    
    # ========== 4. 删除知识 ==========
    def delete_knowledge(self, knowledge_id: str, reason: str) -> bool:
        """
        删除知识
        
        参数：
            knowledge_id: 知识ID
            reason: 删除原因
            
        返回：
            是否成功
        """
        if knowledge_id not in self.knowledge_base:
            return False
        
        old_item = self.knowledge_base[knowledge_id]
        
        # 记录删除
        self._record_update("delete", knowledge_id, old_item.content, None, reason)
        
        # 删除
        del self.knowledge_base[knowledge_id]
        
        return True
    
    # ========== 5. 知识查询 ==========
    def query_knowledge(self, query: str, knowledge_type: KnowledgeType = None) -> List[Dict]:
        """
        查询知识
        
        参数：
            query: 查询关键词
            knowledge_type: 知识类型过滤
            
        返回：
            匹配的知识列表
        """
        results = []
        
        for kid, item in self.knowledge_base.items():
            # 检查是否过期
            if item.expires_at and datetime.now().isoformat() > item.expires_at:
                continue
            
            # 类型过滤
            if knowledge_type and item.knowledge_type != knowledge_type:
                continue
            
            # 关键词匹配
            if query.lower() in item.content.lower() or any(tag in query for tag in item.tags):
                results.append({
                    "id": kid,
                    "content": item.content,
                    "type": item.knowledge_type.value,
                    "confidence": item.confidence,
                    "source": item.source,
                    "tags": item.tags
                })
        
        # 按置信度排序
        results.sort(key=lambda x: x["confidence"], reverse=True)
        
        return results
    
    def get_knowledge(self, knowledge_id: str) -> Optional[Dict]:
        """获取单个知识"""
        if knowledge_id not in self.knowledge_base:
            return None
        
        item = self.knowledge_base[knowledge_id]
        return {
            "id": item.id,
            "content": item.content,
            "type": item.knowledge_type.value,
            "source": item.source,
            "confidence": item.confidence,
            "tags": item.tags,
            "version": item.version,
            "created_at": item.created_at,
            "updated_at": item.updated_at,
            "usage_count": item.usage_count,
            "success_count": item.success_count
        }
    
    # ========== 6. 知识冲突检测 ==========
    def detect_conflicts(self, new_knowledge: str, knowledge_type: KnowledgeType) -> List[Dict]:
        """
        检测新知识与已有知识的冲突
        
        参数：
            new_knowledge: 新知识
            knowledge_type: 知识类型
            
        返回：
            冲突列表
        """
        conflicts = []
        
        for kid, item in self.knowledge_base.items():
            if item.knowledge_type != knowledge_type:
                continue
            
            # 简单冲突检测：相反内容
            if self._is_opposite(new_knowledge, item.content):
                conflicts.append({
                    "existing_id": kid,
                    "existing_content": item.content,
                    "existing_confidence": item.confidence,
                    "existing_source": item.source,
                    "conflict_type": "opposite"
                })
            
            # 矛盾检测
            if self._is_contradictory(new_knowledge, item.content):
                conflicts.append({
                    "existing_id": kid,
                    "existing_content": item.content,
                    "existing_confidence": item.confidence,
                    "existing_source": item.source,
                    "conflict_type": "contradiction"
                })
        
        return conflicts
    
    def _is_opposite(self, a: str, b: str) -> bool:
        """判断两个知识是否相反"""
        opposites = [
            ("是", "不是"), ("是", "否"),
            ("可以", "不可以"), ("能", "不能"),
            ("喜欢", "讨厌"), ("喜欢", "不喜欢"),
            ("要", "不要"), ("应该", "不应该"),
            ("开", "关"), ("开", "关"),
            ("热", "冷"), ("热", "冷"),
            ("高", "低"), ("高", "低"),
            ("快", "慢"), ("快", "慢"),
        ]
        
        for pos, neg in opposites:
            if pos in a and neg in b:
                return True
            if neg in a and pos in b:
                return True
        return False
    
    def _is_contradictory(self, a: str, b: str) -> bool:
        """判断两个知识是否矛盾"""
        contradictions = [
            ("下雨", "晴天"), ("晴天", "下雨"),
            ("白天", "晚上"), ("晚上", "白天"),
            ("上班", "休息"), ("休息", "上班"),
        ]
        
        for ca, cb in contradictions:
            if ca in a and cb in b:
                return True
            if cb in a and ca in b:
                return True
        return False
    
    def resolve_conflict(self, conflicts: List[Dict], strategy: str = None) -> Dict:
        """
        解决知识冲突
        
        参数：
            conflicts: 冲突列表
            strategy: 解决策略 (confidence / time / user_priority)
            
        返回：
            解决结果
        """
        if strategy is None:
            strategy = self.conflict_resolution_strategy
        
        resolutions = []
        
        for conflict in conflicts:
            existing = conflict["existing_content"]
            existing_conf = conflict["existing_confidence"]
            existing_source = conflict["existing_source"]
            
            if strategy == "confidence":
                # 置信度高的胜出
                # 这里简化处理，实际需要比较新旧置信度
                resolution = "keep_existing" if existing_conf >= 0.7 else "replace"
            elif strategy == "time":
                # 新的胜出（这里假设用户教的是新的）
                resolution = "replace"
            else:
                # 用户优先：用户教的知识优先
                resolution = "replace" if existing_source == "system" else "keep_existing"
            
            resolutions.append({
                "existing_content": existing,
                "resolution": resolution,
                "strategy_used": strategy
            })
        
        return {
            "conflicts_count": len(conflicts),
            "resolutions": resolutions,
            "recommendation": "建议用户确认" if len(conflicts) > 0 else "无冲突"
        }
    
    # ========== 7. 知识版本管理 ==========
    def get_version_history(self, knowledge_id: str) -> List[Dict]:
        """获取知识的版本历史"""
        history = []
        
        for record in self.update_history:
            if record.knowledge_id == knowledge_id:
                history.append({
                    "action": record.action,
                    "old_content": record.old_content,
                    "new_content": record.new_content,
                    "reason": record.reason,
                    "timestamp": record.timestamp
                })
        
        return history
    
    def rollback(self, knowledge_id: str, version: int) -> bool:
        """
        回滚到指定版本
        
        参数：
            knowledge_id: 知识ID
            version: 目标版本号
            
        返回：
            是否成功
        """
        if knowledge_id not in self.knowledge_base:
            return False
        
        # 查找历史记录中该版本的旧内容
        history = self.get_version_history(knowledge_id)
        
        # 简化：回滚到上一个版本
        if len(history) >= 1:
            last_update = history[-1]
            if last_update["old_content"]:
                self.update_knowledge(
                    knowledge_id, 
                    last_update["old_content"], 
                    f"回滚到版本{version}",
                    new_confidence=None
                )
                return True
        
        return False
    
    # ========== 8. 知识统计 ==========
    def get_statistics(self) -> Dict:
        """获取知识库统计"""
        by_type = {}
        for item in self.knowledge_base.values():
            t = item.knowledge_type.value
            by_type[t] = by_type.get(t, 0) + 1
        
        user_taught = sum(1 for item in self.knowledge_base.values() if item.source == "user")
        high_conf = sum(1 for item in self.knowledge_base.values() if item.confidence >= 0.8)
        
        return {
            "total_knowledge": len(self.knowledge_base),
            "by_type": by_type,
            "user_taught_count": user_taught,
            "high_confidence_count": high_conf,
            "total_updates": len(self.update_history),
            "avg_confidence": sum(i.confidence for i in self.knowledge_base.values()) / len(self.knowledge_base) if self.knowledge_base else 0
        }
    
    def _record_update(self, action: str, kid: str, old: str, new: str, reason: str):
        """记录更新"""
        update_id = f"UP_{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.update_history)}"
        record = UpdateRecord(
            update_id=update_id,
            action=action,
            knowledge_id=kid,
            old_content=old,
            new_content=new,
            reason=reason
        )
        self.update_history.append(record)