from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


@dataclass
class ReasoningTrace:
    """推理轨迹记录"""
    step: int
    rule: str
    input_facts: List[str]
    output: str
    confidence: float
    source: str  # 来源：rule / common_sense / user_input / inference
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class MetaCognition:
    """
    元认知推理模块 (0.61.0)
    能力：自知之明、置信度评估、知识溯源、推理回溯、主动提问
    """
    
    def __init__(self):
        self.reasoning_traces: List[ReasoningTrace] = []  # 推理轨迹
        self.knowledge_sources: Dict[str, str] = {}  # 知识来源映射
        self.uncertainties: List[Dict] = []  # 不确定性记录
        self.confidence_threshold = 0.6  # 置信度阈值，低于此值触发提问
        
        # 预置知识来源
        self._init_knowledge_sources()
    
    def _init_knowledge_sources(self):
        """初始化知识来源"""
        self.knowledge_sources = {
            "下雨→地湿": "用户定义规则",
            "所有人都会死": "用户输入的前提",
            "水往低处流": "物理常识 (0.59.0)",
            "见到长辈要打招呼": "社交常识 (0.59.0)",
            "起床后刷牙": "日常常识 (0.59.0)",
        }
    
    # ========== 1. 置信度评估 ==========
    def assess_confidence(self, conclusion: str, context: Dict = None) -> float:
        """
        评估推理结论的可信度
        
        参数：
            conclusion: 推理结论
            context: 上下文，包含推理步数、信息来源等
            
        返回：
            置信度 (0-1)
        """
        if context is None:
            context = {}
        
        confidence = 1.0
        
        # 因素1：推理步数（步数越多置信度越低）
        steps = context.get("reasoning_steps", 1)
        confidence *= (0.9 ** (steps - 1))
        
        # 因素2：信息来源可靠性
        source = context.get("source", "unknown")
        source_reliability = {
            "direct_fact": 1.0,
            "user_rule": 0.9,
            "common_sense": 0.8,
            "inference": 0.7,
            "analogy": 0.5,
            "unknown": 0.4
        }
        confidence *= source_reliability.get(source, 0.5)
        
        # 因素3：是否有矛盾
        if context.get("has_contradiction", False):
            confidence *= 0.5
        
        # 因素4：信息完整性
        info_completeness = context.get("info_completeness", 1.0)
        confidence *= info_completeness
        
        # 因素5：历史准确性（如果有）
        if context.get("similar_past_accuracy"):
            confidence *= context["similar_past_accuracy"]
        
        return max(0.0, min(1.0, confidence))
    
    # ========== 2. 知识溯源 ==========
    def trace_knowledge(self, knowledge: str) -> Dict:
        """
        追溯知识的来源
        
        参数：
            knowledge: 知识内容
            
        返回：
            {
                "source": str,
                "version": str,
                "explanation": str
            }
        """
        for key, source in self.knowledge_sources.items():
            if key in knowledge or knowledge in key:
                return {
                    "source": source,
                    "version": self._extract_version(source),
                    "explanation": f"这条知识来自{source}"
                }
        
        return {
            "source": "未知",
            "version": "unknown",
            "explanation": "无法追溯知识来源"
        }
    
    def _extract_version(self, source: str) -> str:
        """从来源中提取版本号"""
        import re
        match = re.search(r'(\d+\.\d+\.\d+)', source)
        return match.group(0) if match else "unknown"
    
    # ========== 3. 推理回溯 ==========
    def trace_reasoning(self, conclusion: str) -> List[Dict]:
        """
        回溯推理链
        
        参数：
            conclusion: 结论
            
        返回：
            推理链列表，每条包含步骤、规则、输入、输出
        """
        traces = []
        
        # 从记录中查找
        for trace in reversed(self.reasoning_traces):
            if trace.output == conclusion or conclusion in trace.output:
                traces.append({
                    "step": trace.step,
                    "rule": trace.rule,
                    "input_facts": trace.input_facts,
                    "output": trace.output,
                    "confidence": trace.confidence,
                    "source": trace.source
                })
        
        return traces
    
    def explain(self, conclusion: str) -> str:
        """
        生成人类可读的解释
        
        参数：
            conclusion: 结论
            
        返回：
            解释文本
        """
        traces = self.trace_reasoning(conclusion)
        
        if not traces:
            return f"“{conclusion}” 没有找到推理记录，可能是直接给出的信息。"
        
        explanation = f"推理过程：\n"
        for i, trace in enumerate(reversed(traces), 1):
            explanation += f"  {i}. 根据规则“{trace['rule']}”，"
            explanation += f"已知 {', '.join(trace['input_facts'])}，"
            explanation += f"推出 {trace['output']}"
            explanation += f" (置信度 {trace['confidence']:.0%})\n"
        
        return explanation
    
    # ========== 4. 不确定性识别 ==========
    def check_uncertainty(self, query: str, context: Dict = None) -> Dict:
        """
        检查信息是否确定
        
        参数：
            query: 查询内容
            context: 上下文
            
        返回：
            {
                "is_certain": bool,
                "confidence": float,
                "missing_info": List[str],
                "contradictions": List[str]
            }
        """
        if context is None:
            context = {}
        
        missing_info = []
        contradictions = []
        
        # 检查是否有缺失信息
        required_info = context.get("required_info", [])
        provided_info = context.get("provided_info", [])
        
        for req in required_info:
            if req not in provided_info:
                missing_info.append(req)
        
        # 检查是否有矛盾
        known_facts = context.get("known_facts", {})
        for fact, value in known_facts.items():
            if fact in query and value != context.get(fact):
                contradictions.append(f"已知{fact}是{value}，但查询暗示不同")
        
        confidence = self.assess_confidence(query, context)
        is_certain = confidence >= self.confidence_threshold and len(missing_info) == 0
        
        return {
            "is_certain": is_certain,
            "confidence": confidence,
            "missing_info": missing_info,
            "contradictions": contradictions
        }
    
    # ========== 5. 主动提问 ==========
    def ask(self, context: Dict) -> str:
        """
        根据缺失信息生成提问
        
        参数：
            context: 上下文，包含 missing_info
            
        返回：
            提问文本
        """
        missing_info = context.get("missing_info", [])
        
        if not missing_info:
            return "我没有问题，信息充足。"
        
        # 根据缺失信息类型生成提问
        question_templates = {
            "下雨": "请问下雨了吗？",
            "天气": "请问天气怎么样？",
            "时间": "请问现在是什么时间？",
            "位置": "请问具体位置在哪里？",
            "数量": "请问有多少？",
            "颜色": "请问是什么颜色？",
        }
        
        for info in missing_info:
            for key, question in question_templates.items():
                if key in info:
                    return question
        
        # 默认提问
        return f"请问关于“{missing_info[0]}”的信息是什么？"
    
    # ========== 6. 记录推理 ==========
    def record_trace(self, rule: str, inputs: List[str], output: str, 
                     confidence: float, source: str = "inference"):
        """
        记录推理轨迹
        """
        step = len(self.reasoning_traces) + 1
        trace = ReasoningTrace(
            step=step,
            rule=rule,
            input_facts=inputs,
            output=output,
            confidence=confidence,
            source=source
        )
        self.reasoning_traces.append(trace)
    
    # ========== 7. 自我评估 ==========
    def self_evaluate(self) -> Dict:
        """
        自我评估：知道什么、不知道什么
        """
        known_topics = set()
        unknown_topics = []
        
        # 从知识来源提取已知主题
        for key in self.knowledge_sources.keys():
            known_topics.add(key.split("→")[0] if "→" in key else key)
        
        # 常见未知主题（演示用）
        common_unknown = ["股票行情", "天气预报", "新闻事件"]
        
        return {
            "known_count": len(known_topics),
            "known_topics": list(known_topics)[:10],  # 只显示前10个
            "unknown_examples": common_unknown,
            "confidence_average": self._avg_confidence(),
            "total_inferences": len(self.reasoning_traces)
        }
    
    def _avg_confidence(self) -> float:
        """计算平均置信度"""
        if not self.reasoning_traces:
            return 0.0
        total = sum(t.confidence for t in self.reasoning_traces)
        return total / len(self.reasoning_traces)
    
    # ========== 8. 矛盾检测 ==========
    def detect_contradiction(self, new_fact: str, existing_facts: List[str]) -> Dict:
        """
        检测新事实与已有事实是否矛盾
        """
        contradictions = []
        
        # 简单矛盾检测：直接冲突
        for fact in existing_facts:
            if self._is_opposite(new_fact, fact):
                contradictions.append({
                    "existing": fact,
                    "new": new_fact,
                    "type": "direct_opposite"
                })
        
        return {
            "has_contradiction": len(contradictions) > 0,
            "contradictions": contradictions
        }
    
    def _is_opposite(self, fact1: str, fact2: str) -> bool:
        """判断两个事实是否相反"""
        opposites = [
            ("下雨", "晴天"), ("晴天", "下雨"),
            ("热", "冷"), ("冷", "热"),
            ("高", "低"), ("低", "高"),
            ("大", "小"), ("小", "大"),
            ("快", "慢"), ("慢", "快"),
        ]
        for a, b in opposites:
            if (a in fact1 and b in fact2) or (b in fact1 and a in fact2):
                return True
        return False