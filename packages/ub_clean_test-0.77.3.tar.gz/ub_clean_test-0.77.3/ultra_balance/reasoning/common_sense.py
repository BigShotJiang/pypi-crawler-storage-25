from typing import Dict, List
from enum import Enum


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4


class CommonSense:
    
    def __init__(self):
        self.daily_knowledge = {
            "起床后": ["刷牙", "洗脸", "吃早饭", "穿衣服"],
            "睡觉前": ["刷牙", "洗脸", "关灯", "盖被子"],
            "吃饭前": ["洗手", "摆碗筷"],
            "吃饭后": ["洗碗", "擦嘴"],
            "下雨天": ["带伞", "穿雨衣", "关窗户"],
            "出门前": ["锁门", "带钥匙", "关灯", "关空调"],
            "洗澡": ["调水温", "拿衣服", "擦干"],
            "生病": ["看医生", "吃药", "多喝水", "休息"],
            "饿了": ["吃饭", "找吃的", "做饭"],
            "渴了": ["喝水", "喝饮料"],
        }
        
        self.social_knowledge = {
            "见到长辈": ["打招呼", "问好", "微笑"],
            "见到老师": ["说老师好", "敬礼"],
            "别人帮忙": ["说谢谢", "微笑"],
            "做错事": ["道歉", "说对不起"],
            "别人道歉": ["没关系", "原谅"],
            "初次见面": ["自我介绍", "握手", "你好"],
            "告别": ["再见", "挥手", "路上小心"],
            "接电话": ["说你好", "自报家门"],
            "打电话": ["先问好", "自我介绍", "说正事"],
            "做客": ["敲门", "带礼物", "换鞋"],
        }
        
        self.physics_knowledge = {
            "水往": ["低处流", "下流"],
            "火会": ["烫手", "烧东西", "热"],
            "冰": ["冷", "会融化", "0度结冰"],
            "热胀冷缩": ["受热膨胀", "遇冷收缩"],
            "太阳从": ["东边升起", "西边落下"],
            "月亮": ["晚上出现", "反射太阳光"],
            "重力": ["往下掉", "地球吸引"],
            "摩擦": ["生热", "减速"],
            "浮力": ["轻的往上浮", "重的往下沉"],
            "电": ["会触电", "能照明", "能驱动"],
            "声音": ["靠振动", "空气中传播"],
            "光速": ["比声音快"],
            "先看到闪电": ["后听到雷声"],
        }
    
    def daily(self, query: str) -> Dict:
        for key, value in self.daily_knowledge.items():
            if key in query:
                return {
                    "result": value,
                    "explanation": f"☀️ 日常常识：{query}，通常{', '.join(value)}"
                }
        return {
            "result": [],
            "explanation": f"🤔 暂时不知道“{query}”的日常常识"
        }
    
    def social(self, query: str) -> Dict:
        for key, value in self.social_knowledge.items():
            if key in query:
                return {
                    "result": value,
                    "explanation": f"👋 社交常识：{query}，应该{', '.join(value)}"
                }
        return {
            "result": [],
            "explanation": f"🤔 暂时不知道“{query}”的社交常识"
        }
    
    def physics(self, query: str) -> Dict:
        for key, value in self.physics_knowledge.items():
            if key in query:
                return {
                    "result": value,
                    "explanation": f"⚡ 物理常识：{key}{value[0] if value else ''}"
                }
        return {
            "result": [],
            "explanation": f"🤔 暂时不知道“{query}”的物理常识"
        }
    
    def reason(self, situation: str) -> Dict:
        if "下雨" in situation and "出门" in situation:
            suggestions = self.daily_knowledge.get("下雨天", [])
            return {
                "suggestions": suggestions,
                "explanation": f"🌧️ 下雨天要出门，建议{', '.join(suggestions)}"
            }
        if "生病" in situation or "不舒服" in situation:
            suggestions = self.daily_knowledge.get("生病", [])
            return {
                "suggestions": suggestions,
                "explanation": f"🤒 生病了，建议{', '.join(suggestions)}"
            }
        if "做客" in situation or "去别人家" in situation:
            suggestions = self.social_knowledge.get("做客", [])
            return {
                "suggestions": suggestions,
                "explanation": f"🏠 去别人家做客，记得{', '.join(suggestions)}"
            }
        return {
            "suggestions": [],
            "explanation": f"🤔 暂时不知道“{situation}”该怎么做"
        }
    
    def get_all(self) -> Dict:
        return {
            "daily": self.daily_knowledge,
            "social": self.social_knowledge,
            "physics": self.physics_knowledge
        }