import re
import random

class HumorUnderstanding:
    """
    幽默理解模块：理解笑话和幽默
    """
    
    def __init__(self):
        # 幽默关键词
        self.humor_keywords = ['哈哈', '呵呵', '好笑', '搞笑', '玩笑', '幽默', '逗']
        
        # 笑话库
        self.jokes = [
            ("为什么电脑总是冷？", "因为它有风扇！"),
            ("为什么机器人不会冷？", "因为它有CPU（中央处理器）！"),
            ("为什么程序员总是分不清万圣节和圣诞节？", "因为 Oct 31 = Dec 25！"),
            ("为什么手机要充电？", "因为它没电了！"),
            ("为什么机器人不吃饭？", "因为它吃电！"),
        ]
        
        self.laughed = False
        self.current_joke = None
    
    def is_humor(self, text):
        """判断是否是幽默表达"""
        for kw in self.humor_keywords:
            if kw in text:
                return True
        return False
    
    def parse_joke(self, text):
        """解析笑话（检测是否包含笑点）"""
        if '？' in text and '因为' in text:
            return True
        if '为什么' in text:
            return True
        return False
    
    def understand(self, text):
        """理解幽默"""
        # 检测是否在笑
        if self.is_humor(text):
            self.laughed = True
            return "哈哈，你在笑什么？有什么好玩的事？"
        
        # 检测是否是笑话
        if self.parse_joke(text):
            # 简单回应
            responses = [
                "哈哈，这个笑话不错！",
                "有意思！再来一个？",
                "哈哈，我笑了！",
                "这个好，还有吗？",
            ]
            return random.choice(responses)
        
        return "我不太懂这个幽默"
    
    def tell_joke(self):
        """讲一个笑话"""
        joke, punchline = random.choice(self.jokes)
        self.current_joke = (joke, punchline)
        return joke
    
    def tell_punchline(self):
        """说出笑点"""
        if self.current_joke:
            joke, punchline = self.current_joke
            self.current_joke = None
            return punchline
        return "我先给你讲个笑话吧"
    
    def respond_to_humor(self, text):
        """回应幽默"""
        responses = [
            "哈哈，你挺幽默的！",
            "这个有意思！",
            "嘿嘿，我笑了。",
            "你真是个有趣的人！",
        ]
        return random.choice(responses)