"""Command-line interface for kamera-einleser."""

from pathlib import Path
from typing import Annotated, Optional

import typer
from InquirerPy import inquirer
from rich.console import Console

from . import __version__
from .checksum import load_index
from .config import Config, get_config
from .interactive import (
    interactive_settings,
    manage_rclone_targets,
    manage_source_directories,
    show_current_config,
)
from .models import LocalSource, RuntimeOptions, SourceRef, parse_source_spec
from .rclone import check_rclone_available, list_iso_names_on_all_targets
from .services.file_scanner import cleanup_source_files

app = typer.Typer(
    name="kamera-einleser",
    help="Einfacher & solider Medien-Importeur. Archiviert Videoaufnahmen von SSD/iPhone in ISO-Dateien pro Tag.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"kamera-einleser version {__version__}")
        raise typer.Exit()


# Prozessweite Laufzeitoptionen, von --verbose/--quiet befüllt.
_runtime_options = RuntimeOptions()


def get_runtime_options() -> RuntimeOptions:
    """Liefert die aktuellen, prozessweiten RuntimeOptions (Root-CLI-Flags)."""
    return _runtime_options


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-v",
            help="Zeige Version an",
            callback=version_callback,
            is_eager=True,
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            help="Ausführliche Ausgabe (zusätzliche Debug-Informationen).",
        ),
    ] = False,
    quiet: Annotated[
        bool,
        typer.Option(
            "--quiet",
            "-q",
            help="Stille Ausgabe (nur Fehler auf stderr).",
        ),
    ] = False,
) -> None:
    """Kamera-Einleser: Archiviert Videoaufnahmen von SSD/iPhone in ISO-Dateien pro Tag."""
    global _runtime_options
    try:
        _runtime_options = RuntimeOptions(verbose=verbose, quiet=quiet)
    except ValueError as exc:
        err_console.print(f"[red]❌ {exc}[/red]")
        raise typer.Exit(2) from exc


@app.command()
def settings() -> None:
    """
    Öffne die interaktiven Einstellungen.

    Ermöglicht die Konfiguration von:
    - Quellverzeichnissen
    - rclone Zielen
    - Arbeitsverzeichnis
    - Archiv-Einstellungen
    """
    interactive_settings()


config_app = typer.Typer(
    name="config",
    help="Konfiguration anzeigen, setzen und auflisten.",
    no_args_is_help=False,
    invoke_without_command=True,
)
app.add_typer(config_app, name="config")


@config_app.callback()
def _config_root(ctx: typer.Context) -> None:
    """Ohne Subcommand: aktuelle Konfiguration ausgeben (wie bisher)."""
    if ctx.invoked_subcommand is None:
        show_current_config()


@config_app.command("show")
def config_show() -> None:
    """Zeigt die aktuelle Konfiguration in Tabellen-Form an."""
    show_current_config()


@config_app.command("path")
def config_path() -> None:
    """Gibt den Pfad der aktiven Konfigurationsdatei auf stdout aus."""
    typer.echo(str(get_config().config_path))


@config_app.command("list")
def config_list() -> None:
    """Listet alle Config-Schlüssel und -Werte als TOML auf stdout."""
    import tomli_w

    cfg = get_config()
    from .config import _sanitize_for_toml

    typer.echo(tomli_w.dumps(_sanitize_for_toml(cfg.list_all())).rstrip())


@config_app.command("get")
def config_get(
    key: Annotated[str, typer.Argument(help="Config-Schlüssel, z.B. 'working_directory'")],
) -> None:
    """Gibt den Wert eines Config-Schlüssels auf stdout aus."""
    cfg = get_config()
    try:
        value = cfg.get_value(key)
    except KeyError as exc:
        err_console.print(f"[red]❌ {exc}[/red]")
        raise typer.Exit(2) from exc
    typer.echo(value if not isinstance(value, (list, dict)) else repr(value))


@config_app.command("set")
def config_set(
    key: Annotated[str, typer.Argument(help="Config-Schlüssel")],
    value: Annotated[str, typer.Argument(help="Neuer Wert (String, Zahl, Boolean)")],
) -> None:
    """Setzt einen Config-Schlüssel und persistiert die Änderung."""
    cfg = get_config()
    try:
        coerced = cfg.set_value(key, value)
    except (KeyError, TypeError, ValueError) as exc:
        err_console.print(f"[red]❌ {exc}[/red]")
        raise typer.Exit(2) from exc
    cfg.save()
    console.print(f"[green]✅[/green] {key} = {coerced!r}")


# Hinweis: `_process_single_source` wurde in 1.5.0 entfernt; die Archive-
# Pipeline läuft ausschliesslich über `api._process_source`, das zusätzlich
# RcloneSource + per-source Workdir-Resolver abdeckt.


def _startup_guard_against_empty_index(cfg: "Config") -> None:
    """Hartes Abbruch-Signal, wenn der Index leer ist aber Remotes ISOs haben.

    Motivation: auf einem frisch eingerichteten zweiten Rechner ohne
    migrierten Index würde `archive` alle Dateien neu archivieren, Base-
    Namen vergeben und beim Upload an `rclone --immutable` scheitern.
    Stunden verschwendet, für nichts.

    Der Guard fängt das vor dem ersten Byte Netz-Transfer ab und verweist
    auf `kamera-einleser index rebuild`. Mit `--force` lässt sich der
    Guard bewusst überstimmen.
    """
    csv_path = cfg.get_checksum_index_path()
    local_has_entries = bool(load_index(csv_path))
    if local_has_entries:
        return

    # Index leer → Remote-Ziele fragen
    remote_names = list_iso_names_on_all_targets(verbose=False)
    if not remote_names:
        # Index leer UND Remote leer → erster Lauf auf neuem Setup,
        # alles korrekt. Kein Guard nötig.
        return

    err_console.print(
        "[red]❌ Abbruch: lokaler Checksum-Index ist leer, "
        f"aber auf den konfigurierten Targets existieren {len(remote_names)} "
        "ISO(s).[/red]"
    )
    err_console.print(
        "\n[yellow]Ohne Index würden alle Dateien neu archiviert, Base-Namen "
        "vergeben und beim Upload an rclone --immutable abgelehnt.[/yellow]"
    )

    # Ab 1.9.0: Wenn auf dem ersten Target eine Remote-Index-CSV liegt, ist
    # `index pull` der Sekunden-schnelle Weg — den expliziten Hinweis darauf
    # bevorzugen wir gegenüber dem stundenlangen `index rebuild`.
    from .services.remote_index import remote_index_exists

    if remote_index_exists(cfg):
        err_console.print(
            "\n[bold green]Empfohlen[/bold green] — Remote-Index gefunden:\n"
            "    [bold]kamera-einleser index pull[/bold]\n"
            "\n(holt die fertige CSV inkl. SHA-256 vom NAS — Sekunden statt Stunden)"
        )
    err_console.print(
        "\n[dim]Disaster-Recovery (kein Remote-Index, oder Audit nötig):\n"
        "    kamera-einleser index rebuild\n"
        "\nOder, wenn du bewusst von vorne archivieren willst (z.B. nach "
        "kompletter Remote-Löschung): [bold]--force[/bold].[/dim]"
    )
    raise typer.Exit(2)


# ---------------------------------------------------------------------------
# `kamera-einleser index ...` — Operator-Kommandos rund um den Checksum-Index
# ---------------------------------------------------------------------------
index_app = typer.Typer(
    name="index",
    help="Operator-Befehle für den Checksum-Index (rebuild, ...).",
    no_args_is_help=True,
)
app.add_typer(index_app, name="index")


@index_app.command("push")
def index_push(
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Zeige nur, was passieren würde — kein Upload.",
        ),
    ] = False,
) -> None:
    """Lädt die lokale Index-CSV ins erste rclone-Target hoch.

    Konvention (1.9.0): das erste konfigurierte Target hostet den Index direkt
    in seinem Root als `checksum_index.csv` (z.B. `lyssach-nas:/Originalmedien/
    checksum_index.csv`). Strategie ist Replace — die lokale Version ersetzt
    die Remote-Version.

    Auf dem Erst-Rechner ist der allererste `push` zugleich die Migration:
    deine bestehende lokale CSV (mit allen historischen SHA-256-Werten) wandert
    auf den NAS und steht damit allen weiteren Rechnern via `index pull` zur
    Verfügung. Folgeläufe von `archive` pushen automatisch.
    """
    from .services.remote_index import push_remote_index

    result = push_remote_index(dry_run=dry_run, console=console, cfg=get_config())
    if not result.ok:
        err_console.print(f"[red]❌ {result.message}[/red]")
        raise typer.Exit(1)


@index_app.command("pull")
def index_pull(
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            help="Existierende lokale CSV überschreiben.",
        ),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Zeige nur, was passieren würde — kein Download.",
        ),
    ] = False,
) -> None:
    """Lädt den Remote-Index vom ersten rclone-Target lokal herunter.

    Auf einem Zweit-Rechner der typische erste Schritt: holt die zentrale CSV
    inklusive aller SHA-256-Werte vom NAS, ohne mounten oder ISOs herunterladen
    zu müssen. Sekunden statt Stunden.

    Wenn lokal schon eine CSV existiert, wird ohne `--force` abgebrochen, damit
    nicht aus Versehen frisch erfasste Einträge überschrieben werden.
    """
    from .services.remote_index import pull_remote_index

    cfg = get_config()
    local_csv = cfg.get_checksum_index_path()
    if local_csv.exists() and not force and not dry_run:
        err_console.print(
            f"[yellow]⚠️  Lokale CSV existiert bereits: {local_csv}\n"
            "   Mit [bold]--force[/bold] überschreiben oder vorher manuell "
            "wegsichern.[/yellow]"
        )
        raise typer.Exit(2)

    result = pull_remote_index(dry_run=dry_run, console=console, cfg=cfg)
    if not result.ok:
        err_console.print(f"[red]❌ {result.message}[/red]")
        raise typer.Exit(1)


@index_app.command("rebuild")
def index_rebuild(
    prune: Annotated[
        bool,
        typer.Option(
            "--prune",
            help="Entferne Index-Einträge, deren ISO auf keinem Target mehr existiert.",
        ),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Zeige nur, was passieren würde — keine Änderung, kein Download.",
        ),
    ] = False,
    target: Annotated[
        Optional[str],
        typer.Option(
            "--target",
            help="Nur einem konkreten Target-Namen vertrauen (z.B. 'Lyssach NAS').",
        ),
    ] = None,
) -> None:
    """Baut den Index aus den tatsächlichen ISOs auf den Targets neu auf.

    **Disaster-Recovery-Pfad** — nicht der Standard-Weg auf Zweit-Rechnern.
    Für den normalen Workflow `kamera-einleser index pull` verwenden, das
    holt den fertigen Index inkl. SHA-256 in Sekunden vom NAS.

    `index rebuild` ist nur sinnvoll, wenn:
    - der Remote-Index korrupt oder gelöscht ist
    - du verifizieren willst, dass Index und tatsächliche ISOs übereinstimmen
    - du nach einem Audit-Lauf alle SHA-256 frisch berechnen willst

    Pro fehlende ISO wird die Datei via rclone heruntergeladen, gemountet,
    mit SHA-256 indexiert und wieder gelöscht — sequentiell, eine nach der
    anderen, damit nie mehr als eine ISO gleichzeitig lokal liegt.
    """
    from .index_ops import rebuild_index_from_remotes

    result = rebuild_index_from_remotes(
        prune=prune,
        dry_run=dry_run,
        target_filter=target,
        console=console,
        cfg=get_config(),
    )
    if result.failed:
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# `kamera-einleser cache ...` — Operator-Kommandos rund um den lokalen
# ISO-Cache (ab 1.8.0)
# ---------------------------------------------------------------------------
cache_app = typer.Typer(
    name="cache",
    help="Lokaler ISO-Cache verwalten (list, prune).",
    no_args_is_help=True,
)
app.add_typer(cache_app, name="cache")


@cache_app.command("list")
def cache_list() -> None:
    """Listet alle lokalen ISOs mit Grösse, Alter und Index-Status."""
    from rich.table import Table

    from .cache_ops import list_local_iso_cache
    from .utils import format_size

    cfg = get_config()
    entries = list_local_iso_cache(cfg=cfg)

    if not entries:
        console.print("[dim]Keine ISOs im lokalen Cache.[/dim]")
        return

    table = Table(title="Lokaler ISO-Cache (älteste zuerst)")
    table.add_column("ISO", style="cyan")
    table.add_column("Tag", style="dim")
    table.add_column("Grösse", justify="right")
    table.add_column("mtime", style="dim")
    table.add_column("Index")

    total = 0
    for e in entries:
        total += e.size
        marker = "[green]✓[/green]" if e.in_index else "[yellow]—[/yellow]"
        table.add_row(
            e.path.name,
            e.day_key,
            format_size(e.size),
            e.mtime.strftime("%Y-%m-%d %H:%M"),
            marker,
        )

    console.print(table)
    limit = cfg.get_iso_cache_max_bytes()
    limit_str = format_size(limit) if limit > 0 else "[dim]unlimited[/dim]"
    console.print(
        f"\n[bold]Total:[/bold] {format_size(total)} in {len(entries)} "
        f"ISO(s)   |   Limit: {limit_str}"
    )


@cache_app.command("prune")
def cache_prune(
    max_size_gb: Annotated[
        float,
        typer.Option(
            "--max-size-gb",
            help="Obergrenze in GB (Default: aus Config iso_cache_max_bytes).",
        ),
    ] = 0.0,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Nur zeigen, was gelöscht würde — Filesystem bleibt unberührt.",
        ),
    ] = False,
) -> None:
    """Entfernt älteste indexierte ISOs bis unter Limit.

    Ohne `--max-size-gb` wird der Wert aus `iso_cache_max_bytes` in der
    Config verwendet. Nur ISOs, die im Checksum-Index stehen, werden
    gelöscht (= verifiziert auf mindestens einem Remote-Target).
    """
    from .cache_ops import prune_local_iso_cache

    cfg = get_config()
    if max_size_gb > 0:
        max_bytes = int(max_size_gb * 10**9)
    else:
        max_bytes = cfg.get_iso_cache_max_bytes()

    prune_local_iso_cache(
        max_bytes=max_bytes,
        dry_run=dry_run,
        cfg=cfg,
        console=console,
    )


@app.command()
def archive(
    source: Annotated[
        Optional[Path],
        typer.Argument(
            help="Quellverzeichnis zum Archivieren (optional, sonst alle konfigurierten Quellen)",
        ),
    ] = None,
    name: Annotated[
        Optional[str],
        typer.Option(
            "--name",
            "-n",
            help="Name für das Archiv (ignoriert, Tag wird verwendet)",
        ),
    ] = None,
    no_upload: Annotated[
        bool,
        typer.Option(
            "--no-upload",
            help="Nur Archiv erstellen, nicht hochladen",
        ),
    ] = False,
    no_cleanup: Annotated[
        bool,
        typer.Option(
            "--no-cleanup",
            help="ISO-Dateien nach Upload nicht löschen (Standard: bleiben erhalten)",
        ),
    ] = False,
    delete_source: Annotated[
        bool,
        typer.Option(
            "--delete-source",
            help="Originaldateien nach erfolgreichem Backup löschen (fragt am Ende interaktiv nach)",
        ),
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            help=(
                "Startup-Guard umgehen: auch archivieren, wenn der lokale "
                "Index leer ist obwohl auf Targets ISOs liegen. Nur bewusst "
                "verwenden — sonst droht massenhafter immutable-Upload-Fehler."
            ),
        ),
    ] = False,
    full_pull: Annotated[
        bool,
        typer.Option(
            "--full-pull",
            help=(
                "Für rclone-Quellen: Index-Prefilter umgehen und alle Dateien "
                "erneut pullen. Standard ist effizienter Diff-Pull."
            ),
        ),
    ] = False,
    prune_cache: Annotated[
        Optional[bool],
        typer.Option(
            "--prune-cache/--no-prune-cache",
            help=(
                "Nach erfolgreichem Lauf den lokalen ISO-Cache auto-prunen "
                "(Default: folgt Config iso_cache_max_bytes). "
                "--prune-cache erzwingt auch bei Config=0, --no-prune-cache "
                "überspringt selbst bei gesetztem Limit."
            ),
        ),
    ] = None,
) -> None:
    """
    Archiviere Kameraaufnahmen und synchronisiere sie zu den konfigurierten Zielen.

    Dieser Befehl:
    1. Erstellt ISO-Dateien pro Tag (gruppiert nach Aufnahmedatum)
    2. Führt Integritätsprüfung durch
    3. Synchronisiert zu allen konfigurierten rclone-Zielen (in Jahresordner)
    4. Fragt am Ende optional nach dem Löschen der Originaldateien

    Bei mehreren konfigurierten Quellen werden diese sequenziell verarbeitet.
    Die Frage nach dem Löschen kommt erst ganz am Ende, nachdem alle Quellen
    erfolgreich archiviert wurden.
    """
    cfg = get_config()

    # Check rclone availability
    if not no_upload:
        if not check_rclone_available():
            console.print(
                "[red]❌ Fehler: rclone ist nicht installiert oder nicht im PATH[/red]"
            )
            raise typer.Exit(1)

    # Fix B (1.6.0): Startup-Guard gegen leeren Index + volles Remote.
    # Verhindert das "Second-Mac"-Problem: frisch geklonter Rechner, Index
    # noch leer, Archive würde ISOs mit Base-Namen neu bauen und auf das
    # Remote drücken — wo `rclone --immutable` sie alle ablehnt. Statt
    # stundenlang ins Leere zu arbeiten, fordern wir explizit `index rebuild`
    # an. Kann mit `--force` übersteuert werden.
    if not no_upload and not force:
        _startup_guard_against_empty_index(cfg)

    # Determine source directories to process (lokal + rclone)
    sources_to_process: list[SourceRef] = []

    if source:
        source_path = source.resolve()
        if not source_path.exists():
            console.print(f"[red]❌ Fehler: Quellverzeichnis existiert nicht: {source_path}[/red]")
            raise typer.Exit(1)
        sources_to_process = [LocalSource(path=source_path)]
    else:
        source_dirs = cfg.get_source_directories()
        if not source_dirs:
            console.print(
                "[red]❌ Fehler: Kein Quellverzeichnis angegeben und keines konfiguriert[/red]"
            )
            console.print("Verwende 'kamera-einleser settings' um Quellverzeichnisse zu konfigurieren.")
            raise typer.Exit(1)

        parsed: list[SourceRef] = []
        for entry in source_dirs:
            try:
                ref = parse_source_spec(entry)
            except ValueError as exc:
                console.print(f"[red]❌ Ungültige Quelle '{entry}': {exc}[/red]")
                continue
            if isinstance(ref, LocalSource) and not ref.path.exists():
                # Info-Level: es ist normal, dass Wechselmedien (SD, SSD)
                # nicht permanent am Rechner hängen.
                console.print(
                    f"[dim]ℹ️  Lokal-Quelle nicht angeschlossen (übersprungen): {ref.path}[/dim]"
                )
                continue
            parsed.append(ref)

        if not parsed:
            console.print(
                "[red]❌ Fehler: Keine der konfigurierten Quellen ist aktuell erreichbar[/red]"
            )
            raise typer.Exit(1)

        sources_to_process = parsed
        if len(parsed) > 1:
            console.print(
                f"\nℹ️  Verarbeite automatisch alle {len(parsed)} konfigurierten Quellen"
            )

    # Check targets configuration
    if not no_upload:
        targets = cfg.get_rclone_targets()
        if not targets:
            console.print(
                "[red]❌ Fehler: Keine rclone-Ziele konfiguriert[/red]"
            )
            console.print("Verwende 'kamera-einleser settings' um Ziele zu konfigurieren.")
            raise typer.Exit(1)

    # Arbeitsverzeichnisse (Primär + optional Fallback) werden pro Quelle
    # nach Platzbedarf aufgelöst (siehe Config.resolve_working_directory).
    primary_wd = cfg.get_working_directory()
    fallback_wd = cfg.get_working_directory_fallback()

    console.print("\n" + "=" * 60)
    console.print("[bold]🎬 Kamera-Einleser: Archivierung starten[/bold]")
    console.print("=" * 60)
    console.print(f"\n[bold]Quellen:[/bold] {len(sources_to_process)} zu verarbeiten")
    for s in sources_to_process:
        console.print(f"   - {s.describe()}")
    console.print(f"[bold]Arbeitsverzeichnis (primär):[/bold] {primary_wd or '(Temp)'}")
    if fallback_wd:
        console.print(f"[bold]Arbeitsverzeichnis (Fallback):[/bold] {fallback_wd}")
    if not no_upload:
        console.print(f"[bold]Ziele:[/bold] {len(cfg.get_rclone_targets())} konfiguriert")

    # Process each source sequentially
    all_success = True
    all_archive_files: list[Path] = []
    successful_sources: list[SourceRef] = []
    failed_sources: list[SourceRef] = []

    for i, src in enumerate(sources_to_process, 1):
        console.print(f"\n{'#' * 60}")
        console.print(f"[bold]Quelle {i}/{len(sources_to_process)}: {src.describe()}[/bold]")
        console.print(f"{'#' * 60}")

        # Alle Quellen laufen durch api._process_source; der Resolver dort
        # wählt pro Quelle den passenden Arbeitsordner (primär → Fallback).
        from .api import _process_source as _api_process_source

        success, archive_files = _api_process_source(
            source=src,
            working_dir_override=None,
            no_upload=no_upload,
            verbose=True,
            full_pull=full_pull,
            cfg=cfg,
        )

        all_archive_files.extend(archive_files)

        if success:
            successful_sources.append(src)
        else:
            failed_sources.append(src)
            all_success = False

    # Summary
    console.print("\n" + "=" * 60)
    console.print("[bold]📊 Zusammenfassung[/bold]")
    console.print("=" * 60)
    console.print(f"   Erfolgreich: {len(successful_sources)}/{len(sources_to_process)}")

    if successful_sources:
        for s in successful_sources:
            console.print(f"   [green]✅ {s.describe()}[/green]")

    if failed_sources:
        for s in failed_sources:
            console.print(f"   [red]❌ {s.describe()}[/red]")

    # Originaldateien löschen: nur bei lokalen Quellen sinnvoll
    local_successful = [s for s in successful_sources if isinstance(s, LocalSource)]
    if delete_source and all_success and local_successful:
        console.print("\n" + "-" * 60)
        console.print("[bold]Originaldateien löschen?[/bold]")
        console.print("-" * 60)

        for src in local_successful:
            should_delete = inquirer.confirm(
                message=f"Originaldateien löschen? ({src.path})",
                default=False,
            ).execute()

            if should_delete:
                cleanup_source_files(src.path, verbose=True)
            else:
                console.print(f"[yellow]⚠️ Originaldateien behalten: {src.path}[/yellow]")

    # Auto-Prune des lokalen ISO-Caches (1.8.0):
    # CLI-Flag --prune-cache / --no-prune-cache überstimmt die Config.
    # Default (prune_cache=None) folgt Config iso_cache_max_bytes > 0.
    if all_success:
        cache_limit = cfg.get_iso_cache_max_bytes()
        if prune_cache is True:
            should_prune = True
            effective_limit = cache_limit if cache_limit > 0 else 0
        elif prune_cache is False:
            should_prune = False
            effective_limit = 0
        else:
            should_prune = cache_limit > 0
            effective_limit = cache_limit

        if should_prune and effective_limit > 0:
            from .cache_ops import prune_local_iso_cache

            prune_local_iso_cache(
                max_bytes=effective_limit,
                dry_run=False,
                cfg=cfg,
                console=console,
            )

    # Final message
    console.print("\n" + "=" * 60)
    if all_success:
        console.print("[bold green]🎉 Alles erfolgreich erledigt![/bold green]")
    else:
        console.print("[bold yellow]⚠️ Abgeschlossen mit Fehlern[/bold yellow]")
    console.print("=" * 60 + "\n")

    if not all_success:
        raise typer.Exit(1)


@app.command()
def sources() -> None:
    """Zeige und verwalte Quellverzeichnisse."""
    manage_source_directories()


@app.command()
def targets() -> None:
    """Zeige und verwalte rclone Ziele."""
    manage_rclone_targets()




if __name__ == "__main__":
    app()

