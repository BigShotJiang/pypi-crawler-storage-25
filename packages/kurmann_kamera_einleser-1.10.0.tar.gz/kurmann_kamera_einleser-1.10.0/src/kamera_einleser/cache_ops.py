"""Operator-Befehle rund um den lokalen ISO-Cache (ab 1.8.0).

Der lokale ISO-Cache ist *kein* echtes Backup. Die Sicherungen liegen auf
den rclone-Targets (NAS, Cloud). Der lokale Cache existiert nur, damit
Folge-Läufe schnell bleiben (Fall A: Mount-basierter Subset-Check) und
Teil-Uploads wiederholt werden können, ohne die Pipeline neu zu bauen.

Um zu verhindern, dass die Arbeits-Festplatte überläuft, kann ein
grössenbasiertes Limit gesetzt werden (`Config.get_iso_cache_max_bytes`).
Wird es überschritten, prunt dieser Service die ältesten ISOs — aber
**nur** solche, die im Checksum-Index stehen (= verifiziert auf mindestens
einem Remote-Target gespeichert).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from .checksum import get_iso_names_from_index, load_index
from .config import get_config
from .services.file_scanner import get_existing_isos
from .utils import format_size

if TYPE_CHECKING:
    from .config import Config


@dataclass
class CacheEntry:
    """Ein einzelner Eintrag im lokalen ISO-Cache."""

    path: Path
    size: int
    mtime: datetime
    in_index: bool  # ISO-Name steht im Checksum-Index → safe to delete
    day_key: str  # "YYYY-MM-DD" aus Dateinamen


@dataclass
class PruneResult:
    """Ergebnis von `prune_local_iso_cache`."""

    deleted: list[Path] = field(default_factory=list)
    freed_bytes: int = 0
    kept_unindexed: list[Path] = field(default_factory=list)
    skipped_too_large: Path | None = None
    total_before: int = 0
    total_after: int = 0
    dry_run: bool = False


def list_local_iso_cache(cfg: "Config | None" = None) -> list[CacheEntry]:
    """Sammelt alle `.iso`-Dateien aus Primary- und Fallback-Working-Dir.

    Für jede ISO:
    - Dateigrösse und mtime aus dem Filesystem
    - `in_index`-Flag via Abgleich mit `checksum_index.csv`
    - `day_key` aus dem Dateinamen (`Originalmedien-YYYY-MM-DD[...].iso`)

    Returns:
        Liste, aufsteigend sortiert nach mtime (älteste zuerst).
    """
    config = cfg if cfg is not None else get_config()

    indexed_names = get_iso_names_from_index(load_index(config.get_checksum_index_path()))

    entries: list[CacheEntry] = []
    seen_paths: set[Path] = set()

    for volume_path_str in (
        config.get_working_directory(),
        config.get_working_directory_fallback(),
    ):
        if not volume_path_str:
            continue
        volume = Path(volume_path_str).expanduser()
        if not volume.exists():
            continue

        by_day = get_existing_isos(volume)
        for day_key, paths in by_day.items():
            for p in paths:
                if p in seen_paths:
                    continue
                seen_paths.add(p)
                try:
                    stat = p.stat()
                except OSError:
                    continue
                entries.append(
                    CacheEntry(
                        path=p,
                        size=stat.st_size,
                        mtime=datetime.fromtimestamp(stat.st_mtime),
                        in_index=p.name in indexed_names,
                        day_key=day_key,
                    )
                )

    entries.sort(key=lambda e: e.mtime)
    return entries


def prune_local_iso_cache(
    *,
    max_bytes: int,
    dry_run: bool = False,
    cfg: "Config | None" = None,
    console: Console | None = None,
) -> PruneResult:
    """Entfernt die ältesten indexierten ISOs, bis die Gesamtsumme ≤ `max_bytes`.

    Safety-Regeln:

    - Nur ISOs löschen, deren Name im Checksum-Index steht (= verifiziert
      auf mindestens einem Remote-Target hochgeladen). ISOs ohne
      Index-Eintrag wandern in `result.kept_unindexed`.
    - Einzelne ISO > `max_bytes` → nicht löschen (wäre die neueste oder
      einzige). Warnung, `result.skipped_too_large` gesetzt.
    - `dry_run=True` lässt die Platte unberührt, meldet aber genau das,
      was gelöscht würde.

    Args:
        max_bytes: Obergrenze für die Summe aller Cache-ISOs. `0` =
            kein Pruning; Result hat `deleted=[]`.
        dry_run: Trocken-Lauf.
        cfg: Explicit Config instance (DI).
        console: rich-Console für Output; Default neuer Console.

    Returns:
        PruneResult mit Detail-Infos.
    """
    cons = console or Console()
    config = cfg if cfg is not None else get_config()

    entries = list_local_iso_cache(cfg=config)
    total = sum(e.size for e in entries)
    result = PruneResult(total_before=total, total_after=total, dry_run=dry_run)

    if max_bytes <= 0:
        cons.print("[dim]Cache-Limit deaktiviert (iso_cache_max_bytes = 0) — nichts zu tun.[/dim]")
        return result

    if total <= max_bytes:
        cons.print(
            f"[dim]Cache ({format_size(total)}) unter Limit ({format_size(max_bytes)}) "
            "— nichts zu tun.[/dim]"
        )
        return result

    cons.print(
        f"[bold]🧹 Cache-Prune[/bold] — aktuell {format_size(total)}, "
        f"Limit {format_size(max_bytes)}"
    )

    # Einzelne ISOs, die grösser als das ganze Limit sind, schliessen wir
    # vom Pruning aus (sonst würde die einzige ISO eines riesigen Tages
    # zuerst wegfliegen).
    oversized = [e for e in entries if e.size > max_bytes]
    if oversized:
        result.skipped_too_large = oversized[0].path
        cons.print(
            f"[yellow]⚠️  ISO grösser als Limit — wird nicht geprunt: "
            f"{oversized[0].path.name} ({format_size(oversized[0].size)})[/yellow]"
        )

    # Älteste zuerst iterieren, nur indexierte prunen
    current = total
    for entry in entries:
        if current <= max_bytes:
            break
        if entry.size > max_bytes:
            continue  # oversized bleibt
        if not entry.in_index:
            result.kept_unindexed.append(entry.path)
            cons.print(
                f"[yellow]   ⏭  Nicht im Index, bleibt: {entry.path.name}[/yellow]"
            )
            continue

        cons.print(
            f"   {'📋 ' if dry_run else '🗑️  '}"
            f"{entry.path.name} ({format_size(entry.size)}, "
            f"{entry.mtime.strftime('%Y-%m-%d %H:%M')})"
        )
        if not dry_run:
            try:
                entry.path.unlink()
            except OSError as exc:
                cons.print(f"[red]   ❌ {entry.path.name}: {exc}[/red]")
                continue

        result.deleted.append(entry.path)
        result.freed_bytes += entry.size
        current -= entry.size

    result.total_after = current

    cons.print(
        f"\n[bold]✓ Prune {'geplant' if dry_run else 'abgeschlossen'}[/bold] "
        f"(gelöscht={len(result.deleted)}, freigegeben={format_size(result.freed_bytes)}, "
        f"übrig={format_size(result.total_after)}, "
        f"übersprungen_nicht_im_index={len(result.kept_unindexed)})"
    )
    return result
