"""Operator-Befehle rund um den Checksum-Index.

Ergänzung zu 1.5.0: wenn der lokale Index verloren geht oder divergiert,
kann er aus den tatsächlichen ISOs auf den Remote-Targets neu aufgebaut
werden. Bewusst operator-getriggert, nicht automatisch bei jedem Lauf.
"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from .checksum import get_iso_names_from_index, load_index, prune_index_entries
from .config import get_config
from .rclone import list_iso_locations_on_all_targets
from .services.iso_mounter import update_checksum_index_for_iso

if TYPE_CHECKING:
    from .config import Config


@dataclass
class RebuildResult:
    """Zusammenfassung eines `index rebuild`-Laufs."""

    added: list[str] = field(default_factory=list)
    skipped_already_indexed: list[str] = field(default_factory=list)
    pruned: list[str] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)
    dry_run: bool = False


def rebuild_index_from_remotes(
    *,
    prune: bool = False,
    dry_run: bool = False,
    target_filter: str | None = None,
    console: Console | None = None,
    cfg: "Config | None" = None,
) -> RebuildResult:
    """Baut den Checksum-Index aus den ISOs auf den Remote-Targets auf.

    Schritte:
    1. `rclone lsf` pro Target → Menge der tatsächlich vorhandenen ISOs
    2. Vergleich mit bereits indexierten ISO-Namen
    3. Für jede Remote-ISO, die noch NICHT im Index ist: Download in Temp-Datei,
       mounten, Dateien indexieren, Temp-Datei löschen
    4. Wenn `prune=True`: alle Index-Einträge entfernen, deren `iso_name` auf
       keinem Target mehr gefunden wird (Phantom-Einträge)

    `dry_run=True` meldet, was geschehen würde, ohne den Index zu verändern
    und ohne ISOs herunterzuladen.

    `target_filter` beschränkt die Rebuild-Quelle auf **ein** Target (Name).

    `cfg` ist eine explizite Config-Instanz (DI); fällt auf `get_config()`
    zurück, wenn nicht übergeben.

    Fehler einzelner ISOs (Download/Mount) werden in `result.failed` gesammelt
    und stoppen den Gesamtlauf nicht.
    """
    cons = console or Console()
    config = cfg if cfg is not None else get_config()
    csv_path = config.get_checksum_index_path()
    result = RebuildResult(dry_run=dry_run)

    cons.print("[bold]🔁 Index-Rebuild[/bold]")
    cons.print(f"   Index-Datei: {csv_path}")

    locations = list_iso_locations_on_all_targets(verbose=True, cfg=config)
    if target_filter:
        locations = {
            n: (t, p) for n, (t, p) in locations.items() if t == target_filter
        }
        cons.print(f"   Filter auf Target: {target_filter}")

    already_indexed = get_iso_names_from_index(load_index(csv_path))

    to_add = sorted(n for n in locations if n not in already_indexed)
    result.skipped_already_indexed = sorted(
        n for n in locations if n in already_indexed
    )

    cons.print(
        f"   Remote-ISOs: {len(locations)} | "
        f"bereits indexiert: {len(result.skipped_already_indexed)} | "
        f"neu aufzunehmen: {len(to_add)}"
    )

    for iso_name in to_add:
        target_name, remote_path = locations[iso_name]
        cons.print(f"\n[cyan]→ {iso_name}[/cyan] von {target_name}")
        if dry_run:
            cons.print("   [dim](dry-run — kein Download)[/dim]")
            result.added.append(iso_name)
            continue
        ok, reason = _download_and_index(iso_name, remote_path, cons, cfg=config)
        if ok:
            result.added.append(iso_name)
        else:
            result.failed.append((iso_name, reason))

    if prune:
        # Phantom-Einträge: indexiert, aber auf keinem Target (mehr) vorhanden
        phantom = sorted(already_indexed - set(locations.keys()))
        if phantom:
            cons.print(f"\n[yellow]Phantom-Einträge:[/yellow] {len(phantom)}")
            for name in phantom:
                cons.print(f"   − {name}")
            if not dry_run:
                prune_index_entries(csv_path, set(phantom))
            result.pruned = phantom

    cons.print(
        f"\n[bold]✓ Rebuild abgeschlossen[/bold]"
        f" (added={len(result.added)}"
        f" skipped={len(result.skipped_already_indexed)}"
        f" pruned={len(result.pruned)}"
        f" failed={len(result.failed)}"
        f" dry_run={dry_run})"
    )
    return result


def _download_and_index(
    iso_name: str,
    remote_path: str,
    console: Console,
    *,
    cfg: "Config | None" = None,
) -> tuple[bool, str]:
    """Download eine ISO in eine Temp-Datei, indexiere sie, räume auf."""
    tmp_dir = Path(tempfile.mkdtemp(prefix="index-rebuild-"))
    local_iso = tmp_dir / iso_name
    try:
        console.print(f"   📥 Download {remote_path} → {local_iso}")
        proc = subprocess.run(
            ["rclone", "copyto", remote_path, str(local_iso), "--stats-one-line"]
        )
        if proc.returncode != 0 or not local_iso.exists():
            return False, "rclone-Download fehlgeschlagen"

        if not update_checksum_index_for_iso(local_iso, verbose=True, cfg=cfg):
            return False, "Mount/Index fehlgeschlagen"
        return True, "ok"
    except Exception as e:  # pragma: no cover — subprocess-Fehler
        return False, str(e)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
