"""Rclone upload module for transferring archives to remote targets."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any

from rich.console import Console

from .config import get_config
from .utils import format_size

if TYPE_CHECKING:
    from .config import Config
    from .models import RcloneSource

console = Console()

# Mindest-Freiplatz-Puffer relativ zur Quellen-Grösse. Hintergrund: rclone
# schreibt .partial-Dateien und braucht während Multi-Thread-Copies kurz
# zusätzlichen Platz; ein 10%-Puffer hat sich in der Praxis bewährt.
PULL_FREE_SPACE_SAFETY = 1.10


def check_rclone_available() -> bool:
    """Check if rclone is installed and available."""
    result = subprocess.run(
        ["rclone", "version"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def get_rclone_source_size(rclone_path: str) -> int | None:
    """Liefert die Gesamt-Bytezahl einer rclone-Quelle via `rclone size --json`.

    Args:
        rclone_path: rclone-Pfad, z.B. "synology:/volume1/Fotos".

    Returns:
        Anzahl Bytes, oder None bei Fehler / ungültigem JSON.
    """
    result = subprocess.run(
        ["rclone", "size", "--json", rclone_path],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return None
    try:
        data = json.loads(result.stdout)
        return int(data.get("bytes", 0))
    except (json.JSONDecodeError, TypeError, ValueError):
        return None


def pull_rclone_source_to_dir(
    source: "RcloneSource",
    destination_dir: Path,
    excludes: list[str] | None = None,
    verbose: bool = True,
    skip_filenames: set[str] | None = None,
) -> bool:
    """Zieht eine rclone-Quelle (z.B. Synology-NAS) nach `destination_dir`.

    Nutzt `rclone copy` mit Metadaten-Erhalt (mtime, wo unterstützt). Der
    Zielordner wird angelegt, falls er nicht existiert. Ausschluss-Muster
    werden als `--exclude` weitergereicht (Glob-Syntax wie rclone sie kennt).

    `skip_filenames` aktiviert den **Index-Prefilter** (1.5.0 Fix 3): alle
    darin enthaltenen Dateinamen werden via `rclone --filter-from` remote-
    seitig übersprungen. Dadurch wird bei wiederholten Läufen nur übertragen,
    was noch nicht archiviert ist. Passe-partout für jedes rclone-Backend,
    weil rein auf Dateinamen basierend (keine Server-Hashes nötig).

    Args:
        source: RcloneSource-Instanz aus `kamera_einleser.models`.
        destination_dir: lokales Zielverzeichnis (wird angelegt).
        excludes: optionale Liste von rclone-Glob-Excludes.
        verbose: bei True wird rclone stdout/stderr durchgereicht.
        skip_filenames: Set bereits indexierter Dateinamen (NFC-normalisiert).
            Wenn gesetzt und non-empty, wird eine Filter-Datei generiert und
            an rclone übergeben. Auf `None` oder leer = kein Prefilter (voller
            Pull, äquivalent zum `--full-pull`-Modus der CLI).

    Returns:
        True bei erfolgreichem Kopieren, False bei Fehler.
    """
    # Import lokal, um Zirkular-Import mit models → archive → rclone zu
    # vermeiden. Der Typ-Hint im Signatur ist ein String (forward ref).
    destination_dir.mkdir(parents=True, exist_ok=True)

    # Pre-flight: Grösse der Quelle ermitteln und mit freiem Platz vergleichen.
    # rclone size --json dauert ~1 s und verhindert "no space left on device"
    # mitten im Kopier-Lauf (Reliability-Fix 1.4.0).
    source_bytes = get_rclone_source_size(source.rclone_path)
    if source_bytes is not None:
        free_bytes = shutil.disk_usage(destination_dir).free
        required = int(source_bytes * PULL_FREE_SPACE_SAFETY)
        if verbose:
            console.print(
                f"[dim]💾 Quell-Grösse: {format_size(source_bytes)} | "
                f"Frei am Ziel: {format_size(free_bytes)} | "
                f"Benötigt (inkl. 10 % Puffer): {format_size(required)}[/dim]"
            )
        if free_bytes < required:
            if verbose:
                console.print(
                    f"[red]❌ Zu wenig Speicherplatz in {destination_dir}.[/red]\n"
                    f"   Benötigt: {format_size(required)} "
                    f"(Quelle {format_size(source_bytes)} + 10 % Puffer)\n"
                    f"   Verfügbar: {format_size(free_bytes)}"
                )
            return False
    elif verbose:
        console.print(
            "[yellow]⚠️ Konnte Quell-Grösse nicht ermitteln — "
            "überspringe Speicherplatz-Check.[/yellow]"
        )

    cmd: list[str] = [
        "rclone",
        "copy",
        "--metadata",
        source.rclone_path,
        str(destination_dir),
    ]
    for pattern in excludes or []:
        cmd.extend(["--exclude", pattern])

    # Fix 3 (1.5.0): Index-Prefilter. Schreibt eine Liste bereits archivierter
    # Dateinamen in eine Temp-Datei und übergibt sie rclone via --filter-from.
    # rclone skippt diese Files dann bereits am Remote, d.h. sie werden nie
    # übertragen und verbrauchen kein Netz.
    filter_path: Path | None = None
    if skip_filenames:
        filter_path = destination_dir.parent / f".rclone-filter-{destination_dir.name}.txt"
        _write_exclude_filter_file(filter_path, skip_filenames)
        cmd.extend(["--filter-from", str(filter_path)])
        if verbose:
            console.print(
                f"[dim]📋 Index-Prefilter aktiv: {len(skip_filenames)} "
                f"bereits archivierte Dateinamen werden übersprungen.[/dim]"
            )

    if verbose:
        cmd.extend(["-v", "--stats", "5s", "--stats-one-line"])

    if verbose:
        console.print(f"\n[bold]📥 Ziehe rclone-Quelle:[/bold] {source.rclone_path}")
        console.print(f"   → {destination_dir}")

    try:
        result = (
            subprocess.run(cmd)
            if verbose
            else subprocess.run(cmd, capture_output=True)
        )
    finally:
        if filter_path is not None and filter_path.exists():
            try:
                filter_path.unlink()
            except OSError:
                pass

    if result.returncode != 0:
        if verbose:
            console.print("[red]❌ rclone copy fehlgeschlagen[/red]")
        return False

    if verbose:
        console.print("[green]✅ rclone-Quelle ins Staging übernommen[/green]")
    return True


def _get_year_from_iso_name(iso_name: str) -> str:
    """
    Extract year from an ISO filename.

    Args:
        iso_name: ISO filename (e.g., "Originalmedien-2025-12-24.iso")

    Returns:
        Year string (e.g., "2025")
    """
    # Originalmedien-YYYY-MM-DD.iso or Originalmedien-YYYY-MM-DD-Teil-N.iso
    stem = Path(iso_name).stem  # e.g., Originalmedien-2025-12-24
    key_part = stem.replace("Originalmedien-", "")  # e.g., 2025-12-24 or 2025-12-24-Teil-2
    return key_part[:4]  # First 4 chars = year


def copy_iso_to_target(
    iso_path: Path,
    target: dict[str, Any],
    verbose: bool = True,
) -> bool:
    """
    Copy an ISO file to a single rclone target, organized in a year folder.

    The ISO file is placed in a year subfolder on the target, e.g.,
    target_path/2025/Originalmedien-2025-12-24.iso

    Args:
        iso_path: Path to the ISO file to copy
        target: rclone target configuration dict with 'name' and 'path' keys
        verbose: If True, print progress messages

    Returns:
        True if copy was successful, False otherwise
    """
    target_name = target.get("name", target.get("path", "Unknown"))
    target_path = target.get("path", "")

    if not target_path:
        if verbose:
            console.print("[red]❌ Fehler: Ungültiges Ziel (kein Pfad)[/red]")
        return False

    # Determine year folder
    year = _get_year_from_iso_name(iso_path.name)
    remote_path = f"{target_path}/{year}"

    if verbose:
        # Get file size
        file_size = iso_path.stat().st_size
        formatted_size = format_size(file_size)

        console.print(f"\n[bold]📤 Kopiere zu: {target_name}[/bold]")
        console.print(f"   ISO: {iso_path.name}")
        console.print(f"   Grösse: {formatted_size}")
        console.print(f"   Ziel: {remote_path}/{iso_path.name}")

    try:
        # Use rclone copyto for single file to specific remote path
        # Note: No --exclude filters for single file operations
        #
        # WARNUNG: `--immutable` NIEMALS entfernen. Es ist die einzige Schicht,
        # die verhindert, dass eine bereits archivierte ISO auf dem Server
        # durch eine namensgleiche, aber inhaltlich verschiedene ISO
        # überschrieben wird (Fall: lokaler Index verloren, neue Files eines
        # bereits archivierten Tages). Ohne --immutable → stilles Überschreiben,
        # also Datenverlust-Pfad. Regression-Test: tests/test_rclone.py
        # → TestCopyIsoToTarget::test_uses_immutable_flag.
        cmd = [
            "rclone",
            "copyto",
            str(iso_path),
            f"{remote_path}/{iso_path.name}",
            "--immutable",
            "--stats", "5s",
            "--stats-one-line",
            "-v",
        ]

        if verbose:
            result = subprocess.run(cmd)
        else:
            result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            if verbose:
                console.print(f"[red]❌ Fehler beim Kopieren von {iso_path.name}[/red]")
            return False

        if verbose:
            console.print("[green]✅ Kopie abgeschlossen[/green]")
        return True

    except Exception as e:
        if verbose:
            console.print(f"[red]❌ Fehler beim Kopieren: {e}[/red]")
        return False


def upload_to_target(
    archive_files: list[Path],
    target: dict[str, Any],
    verbose: bool = True,
) -> bool:
    """
    Upload archive files (ISO files) to a single rclone target.

    ISO files are copied to year-organized folders on the target.

    Args:
        archive_files: List of archive file paths (ISOs) to upload
        target: rclone target configuration dict with 'name' and 'path' keys
        verbose: If True, print progress messages

    Returns:
        True if upload was successful, False otherwise
    """
    target_name = target.get("name", target.get("path", "Unknown"))
    target_path = target.get("path", "")

    if not target_path:
        if verbose:
            console.print("[red]❌ Fehler: Ungültiges Ziel (kein Pfad)[/red]")
        return False

    if verbose:
        console.print(f"\n[bold]🔄 Übertrage zu: {target_name}[/bold]")
        console.print(f"   Ziel: {target_path}")

    try:
        for archive_file in archive_files:
            if archive_file.suffix == ".iso":
                if not copy_iso_to_target(archive_file, target, verbose=verbose):
                    return False
            else:
                # Legacy support: use copy for other file types
                if not _copy_single_file(archive_file, target_path, verbose=verbose):
                    return False

        if verbose:
            console.print("[green]✅ Transfer abgeschlossen[/green]")
        return True

    except Exception as e:
        if verbose:
            console.print(f"[red]❌ Fehler beim Transfer: {e}[/red]")
        return False


def _copy_single_file(file_path: Path, target_path: str, verbose: bool = True) -> bool:
    """
    Copy a single file to a remote target (legacy support for non-ISO files).

    Args:
        file_path: Path to the file to copy
        target_path: rclone target path
        verbose: If True, print progress messages

    Returns:
        True if copy was successful, False otherwise
    """
    if verbose:
        console.print(f"   Datei: {file_path.name}")

    # Note: No --exclude filters for single file operations
    cmd = [
        "rclone",
        "copy",
        str(file_path),
        target_path,
        "--stats", "5s",
        "--stats-one-line",
        "-v",
    ]

    if verbose:
        result = subprocess.run(cmd)
    else:
        result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        if verbose:
            console.print(f"[red]❌ Fehler beim Übertragen von {file_path.name}[/red]")
        return False

    return True


def upload_to_all_targets(
    archive_files: list[Path],
    verbose: bool = True,
    cfg: "Config | None" = None,
) -> tuple[bool, list[str], list[str]]:
    """
    Upload archive files to all configured rclone targets in order.

    Args:
        archive_files: List of archive file paths to upload
        verbose: If True, print progress messages
        cfg: Explicit Config instance (DI). Fallback auf `get_config()`.

    Returns:
        Tuple of (all_successful, list of successful targets, list of failed targets)
    """
    config = cfg if cfg is not None else get_config()
    targets = config.get_rclone_targets()

    if not targets:
        if verbose:
            console.print(
                "[red]❌ Fehler: Keine rclone-Ziele konfiguriert[/red]"
            )
        return False, [], []

    if verbose:
        console.print(f"\n[bold]📤 Starte Upload zu {len(targets)} Ziel(en)...[/bold]")
        for i, target in enumerate(targets, 1):
            console.print(f"   {i}. {target.get('name', target.get('path', 'Unknown'))}")

    successful_targets: list[str] = []
    failed_targets: list[str] = []

    for target in targets:
        target_name = target.get("name", target.get("path", "Unknown"))

        success = upload_to_target(archive_files, target, verbose=verbose)

        if success:
            successful_targets.append(target_name)
        else:
            failed_targets.append(target_name)
            if verbose:
                console.print(f"[red]❌ {target_name} fehlgeschlagen![/red]")
            # Continue with next target even if one fails

    all_successful = len(failed_targets) == 0

    if verbose:
        console.print(f"\n{'=' * 50}")
        console.print("[bold]📊 Upload-Zusammenfassung[/bold]")
        console.print(f"{'=' * 50}")
        console.print(f"   Erfolgreich: {len(successful_targets)}/{len(targets)}")
        if successful_targets:
            for name in successful_targets:
                console.print(f"   [green]✅ {name}[/green]")
        if failed_targets:
            for name in failed_targets:
                console.print(f"   [red]❌ {name}[/red]")

    return all_successful, successful_targets, failed_targets


def list_iso_names_on_target(
    target: dict[str, Any],
    verbose: bool = False,
) -> set[str]:
    """
    List ISO filenames found on a single rclone target.

    Searches recursively for .iso files on the target.

    Args:
        target: rclone target configuration dict with 'name' and 'path' keys
        verbose: If True, print progress messages

    Returns:
        Set of ISO filenames found on the target
    """
    target_name = target.get("name", target.get("path", "Unknown"))
    target_path = target.get("path", "")

    if not target_path:
        return set()

    try:
        cmd = [
            "rclone", "lsf",
            "--include", "*.iso",
            "--recursive",
            target_path,
        ]
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            if verbose:
                console.print(f"[yellow]⚠️  Konnte Ziel {target_name} nicht prüfen[/yellow]")
            return set()

        names: set[str] = set()
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if line and line.endswith(".iso"):
                # lsf returns paths like "2025/Originalmedien-2025-12-24.iso"
                names.add(Path(line).name)
        return names
    except Exception as e:
        if verbose:
            console.print(f"[yellow]⚠️  Fehler beim Prüfen von {target_name}: {e}[/yellow]")
        return set()


def list_iso_locations_on_all_targets(
    verbose: bool = False,
    cfg: "Config | None" = None,
) -> dict[str, tuple[str, str]]:
    """Liefert pro ISO-Name den ersten gefundenen Ort (Target-Name, rclone-Pfad).

    Mehrere Targets können dieselbe ISO hosten; zum Download reicht irgendeine
    Kopie. Nur das Erst-Treffer-Mapping wird zurückgegeben.

    Args:
        verbose: bei True wird pro Target ein Log geschrieben.
        cfg: Explicit Config instance (DI). Fallback auf `get_config()`.

    Returns:
        dict `iso_name → (target_name, full_rclone_path)`.
    """
    config = cfg if cfg is not None else get_config()
    targets = config.get_rclone_targets()
    result: dict[str, tuple[str, str]] = {}
    if not targets:
        return result

    for target in targets:
        target_name = target.get("name", target.get("path", "Unknown"))
        target_path = target.get("path", "")
        if not target_path:
            continue
        if verbose:
            console.print(f"   🔍 Prüfe Ziel: {target_name}...")
        try:
            cmd = ["rclone", "lsf", "--include", "*.iso", "--recursive", target_path]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if proc.returncode != 0:
                if verbose:
                    console.print(
                        f"[yellow]⚠️  Konnte Ziel {target_name} nicht prüfen[/yellow]"
                    )
                continue
            for line in proc.stdout.strip().split("\n"):
                line = line.strip()
                if not line.endswith(".iso"):
                    continue
                iso_name = Path(line).name
                full_path = f"{target_path}/{line}"
                # Nur ersten Treffer behalten (Reihenfolge = Target-Priorität)
                result.setdefault(iso_name, (target_name, full_path))
        except Exception as e:
            if verbose:
                console.print(
                    f"[yellow]⚠️  Fehler beim Prüfen von {target_name}: {e}[/yellow]"
                )
    return result


def list_iso_names_on_all_targets(
    verbose: bool = False,
    cfg: "Config | None" = None,
) -> set[str]:
    """
    List ISO filenames found on any configured rclone target.

    Args:
        verbose: If True, print progress messages
        cfg: Explicit Config instance (DI). Fallback auf `get_config()`.

    Returns:
        Set of ISO filenames found across all targets
    """
    config = cfg if cfg is not None else get_config()
    targets = config.get_rclone_targets()

    if not targets:
        return set()

    all_names: set[str] = set()
    for target in targets:
        target_name = target.get("name", target.get("path", "Unknown"))
        if verbose:
            console.print(f"   🔍 Prüfe Ziel: {target_name}...")
        names = list_iso_names_on_target(target, verbose=verbose)
        if verbose:
            console.print(f"      {len(names)} ISO-Datei(en) gefunden")
        all_names.update(names)

    return all_names


def _write_exclude_filter_file(path: Path, filenames: set[str]) -> None:
    """Schreibt eine rclone-Filter-Datei: eine Zeile pro Dateiname als Exclude.

    Format: `- filename.ext` (Glob wird von rclone interpretiert). Die Muster
    sind absichtlich NICHT pfad-verankert (kein führender `/`), so matchen sie
    den Dateinamen in jedem Unterordner der Quelle. Das deckt Projekt­strukturen
    mit Unter­ordnern (`Media/`, `Media 2/` etc.) automatisch mit ab.

    Für rclone-Glob-Metazeichen (`*`, `?`, `[`, `]`, `{`, `}`) in Filenames wird
    via `[x]`-Klassen escaped, sodass Literal-Match garantiert ist.
    """
    def _escape(name: str) -> str:
        # rclone-Filter nutzt Glob. Jedes Metazeichen in `[]`-Class einpacken.
        special = set("*?[]{}!")
        return "".join(f"[{c}]" if c in special else c for c in name)

    with open(path, "w", encoding="utf-8") as f:
        for name in sorted(filenames):
            f.write(f"- {_escape(name)}\n")
