"""File-Scanner-Service: Quell-Verzeichnis-Scan, Tag-/Monat-Gruppierung,
Disk-Space-Check, Existing-ISOs-Scan und Source-Cleanup.

Stellt die Datenstruktur `FileInfo` und alle rein-lokalen Filesystem-
Operationen bereit, die im Archive-Flow gebraucht werden. Kein Netzwerk,
kein `hdiutil`.
"""

from __future__ import annotations

import re
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from rich.console import Console

from ..utils import should_exclude

console = Console()


def _is_iso_date(name: str) -> bool:
    """Prüft, ob `name` genau das Muster `YYYY-MM-DD` hat (als Datum gültig)."""
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", name):
        return False
    try:
        datetime.strptime(name, "%Y-%m-%d")
        return True
    except ValueError:
        return False


@dataclass
class FileInfo:
    """Informationen über eine zu archivierende Datei."""

    path: Path  # Absoluter Pfad
    relative_path: Path  # Pfad relativ zum Quell-Root
    size: int
    timestamp: datetime
    month_key: str  # "YYYY-MM"
    day_key: str  # "YYYY-MM-DD"


# --- Grössen / Disk-Space ----------------------------------------------------


def calculate_directory_size(directory: Path) -> int:
    """Summe aller Dateigrössen unterhalb `directory` (rekursiv).

    Lese-Fehler bei einzelnen Dateien werden still übersprungen, damit der
    Lauf nicht an Meta-Files scheitert.
    """
    total_size = 0
    for item in directory.rglob("*"):
        if item.is_file():
            try:
                total_size += item.stat().st_size
            except OSError:
                pass
    return total_size


def check_disk_space(path: Path, required_bytes: int) -> tuple[bool, int]:
    """Ist genug Platz an `path` (oder nächstem existierendem Ahn) frei?

    Returns:
        (genug_platz, frei_in_bytes).
    """
    try:
        check_path = path
        while not check_path.exists() and check_path.parent != check_path:
            check_path = check_path.parent

        disk_usage = shutil.disk_usage(check_path)
        return disk_usage.free >= required_bytes, disk_usage.free
    except OSError:
        return False, 0


# --- Timestamps + Scan -------------------------------------------------------


def get_newest_file_timestamp(
    directory: Path, excludes: list[str] | None = None
) -> datetime:
    """`mtime` der neusten nicht-excluded Datei unter `directory`.

    Fallback: aktueller Zeitpunkt, wenn nichts gefunden wurde.
    """
    if excludes is None:
        excludes = []

    newest_time = 0.0

    for item in directory.rglob("*"):
        if item.is_file() and not should_exclude(item.name, excludes):
            try:
                mtime = item.stat().st_mtime
                if mtime > newest_time:
                    newest_time = mtime
            except OSError:
                pass

    if newest_time == 0.0:
        return datetime.now()

    return datetime.fromtimestamp(newest_time)


def get_all_files_with_month(
    source_path: Path,
    excludes: list[str] | None = None,
) -> dict[str, list[FileInfo]]:
    """Alle Dateien rekursiv, gruppiert nach `YYYY-MM`."""
    if excludes is None:
        excludes = []

    files_by_month: dict[str, list[FileInfo]] = {}

    for item in source_path.rglob("*"):
        if item.is_file() and not should_exclude(item.name, excludes):
            try:
                stat = item.stat()
                timestamp = datetime.fromtimestamp(stat.st_mtime)
                month_key = timestamp.strftime("%Y-%m")
                day_key = timestamp.strftime("%Y-%m-%d")

                file_info = FileInfo(
                    path=item,
                    relative_path=item.relative_to(source_path),
                    size=stat.st_size,
                    timestamp=timestamp,
                    month_key=month_key,
                    day_key=day_key,
                )

                if month_key not in files_by_month:
                    files_by_month[month_key] = []
                files_by_month[month_key].append(file_info)
            except OSError:
                pass

    for key in files_by_month:
        files_by_month[key].sort(key=lambda f: str(f.relative_path))

    return files_by_month


def get_all_files_with_day(
    source_path: Path,
    excludes: list[str] | None = None,
) -> dict[str, list[FileInfo]]:
    """Alle Dateien rekursiv, gruppiert nach `YYYY-MM-DD`.

    Sonderfall: liegt die Quelle unterhalb eines Top-Level-Ordners, der exakt
    auf `YYYY-MM-DD` matcht (z.B. `2026-04-23/…`), wird dieses Datum als
    `day_key` verwendet — unabhängig vom mtime — und der Datumsordner aus
    dem relativen Pfad entfernt. So bleiben schon vorsortierte Projekte
    stabil, auch wenn ihr mtime später angefasst wurde.
    """
    if excludes is None:
        excludes = []

    files_by_day: dict[str, list[FileInfo]] = {}

    for item in source_path.rglob("*"):
        if item.is_file() and not should_exclude(item.name, excludes):
            try:
                stat = item.stat()
                timestamp = datetime.fromtimestamp(stat.st_mtime)
                relative_path = item.relative_to(source_path)

                # Falls Top-Level-Ordner ein ISO-Datum ist: nutze es statt mtime
                if (
                    len(relative_path.parts) > 1
                    and _is_iso_date(relative_path.parts[0])
                ):
                    day_key = relative_path.parts[0]
                    # Datum aus Pfad entfernen (Datei landet direkt an der Wurzel)
                    remaining = Path(*relative_path.parts[1:])
                    relative_path = remaining
                    month_key = day_key[:7]
                else:
                    day_key = timestamp.strftime("%Y-%m-%d")
                    month_key = timestamp.strftime("%Y-%m")

                file_info = FileInfo(
                    path=item,
                    relative_path=relative_path,
                    size=stat.st_size,
                    timestamp=timestamp,
                    month_key=month_key,
                    day_key=day_key,
                )

                if day_key not in files_by_day:
                    files_by_day[day_key] = []
                files_by_day[day_key].append(file_info)
            except OSError:
                pass

    for key in files_by_day:
        files_by_day[key].sort(key=lambda f: str(f.relative_path))

    return files_by_day


# --- Existing-ISOs-Scan ------------------------------------------------------


def get_existing_isos(working_dir: Path) -> dict[str, list[Path]]:
    """Findet lokal bereits gebaute ISOs im Arbeitsverzeichnis.

    Returns:
        `{day_key: [Path, ...]}`. Mehrere Paths pro Tag sind möglich (Teil-2,
        Teil-3 …).
    """
    isos: dict[str, list[Path]] = {}

    if not working_dir.exists():
        return isos

    for item in working_dir.iterdir():
        if item.suffix == ".iso" and item.name.startswith("Originalmedien-"):
            stem = item.stem
            key_part = stem.replace("Originalmedien-", "")
            if "-Teil-" in key_part:
                day_key = key_part.split("-Teil-")[0]
            else:
                day_key = key_part
            if day_key not in isos:
                isos[day_key] = []
            isos[day_key].append(item)

    return isos


# --- Source-Cleanup ----------------------------------------------------------


def cleanup_source_files(source_path: Path, verbose: bool = True) -> bool:
    """Löscht das Quell-Verzeichnis (nach erfolgreichem Archive + Upload).

    Returns:
        True auch wenn das Verzeichnis gar nicht mehr existiert (idempotent).
        False nur bei echten OS-Fehlern.
    """
    if verbose:
        console.print(f"\n[bold]🗑️ Lösche Originaldateien: {source_path}[/bold]")

    try:
        if source_path.exists() and source_path.is_dir():
            shutil.rmtree(source_path)
            if verbose:
                console.print("   [green]✅ Originaldateien gelöscht[/green]")
            return True
        if verbose:
            console.print("   [yellow]⚠️ Verzeichnis existiert nicht mehr[/yellow]")
        return True
    except Exception as e:
        if verbose:
            console.print(f"   [red]❌ Fehler beim Löschen: {e}[/red]")
        return False
