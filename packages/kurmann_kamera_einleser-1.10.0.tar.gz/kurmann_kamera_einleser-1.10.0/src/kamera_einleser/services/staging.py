"""Staging-Service: Kopiert Dateien in ein Temp-Verzeichnis für den ISO-Bau.

Zwei Funktionen:
- `copy_files_to_staging`: nutzt macOS `ditto`, um Dateien mit Metadaten
  (Resource-Forks, extended attributes, Creation-Date) in einen Staging-Ordner
  zu legen. Damit enthält die später gebaute ISO eine exakte Kopie der
  Original-Dateien samt Finder-sichtbaren Eigenschaften.
- `has_non_hidden_files`: rekursiver Helfer, ob ein Ordner etwas Sichtbares
  enthält. Wird vom Archive-Flow genutzt, um leere bzw. reine Metadata-
  Ordner zu erkennen und zu überspringen.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from ..utils import format_size

if TYPE_CHECKING:
    from .file_scanner import FileInfo

console = Console()


def has_non_hidden_files(directory: Path) -> bool:
    """Gibt True zurück, wenn das Verzeichnis irgendwo eine nicht-versteckte
    Datei oder Unterordner enthält.

    Eine Komponente gilt als versteckt, wenn ihr Name mit einem Punkt beginnt.
    Der Check ist rekursiv.
    """
    for item in directory.rglob("*"):
        relative = item.relative_to(directory)
        is_hidden = any(part.startswith(".") for part in relative.parts)
        if not is_hidden:
            return True
    return False


def copy_files_to_staging(
    files: list["FileInfo"],
    staging_dir: Path,
    verbose: bool = True,
) -> bool:
    """Kopiert `files` in `staging_dir` unter Erhalt der relativen Pfadstruktur.

    Nutzt macOS `ditto`, damit Resource-Forks, erweiterte Attribute und
    andere HFS+/APFS-Metadaten erhalten bleiben. Die resultierende Staging-
    Kopie ist eine bit-genaue Abbildung der Quelle.

    Args:
        files: Liste der zu kopierenden Dateien.
        staging_dir: Zielverzeichnis (wird für jede Datei bei Bedarf angelegt).
        verbose: Steuert CLI-Ausgabe über den rich-Console.

    Returns:
        True wenn alle Kopien erfolgreich waren, False sobald mindestens eine
        fehlschlug.
    """
    if verbose:
        total_size = sum(f.size for f in files)
        console.print(
            f"\n[bold]📂 Kopiere {len(files)} Datei(en) "
            f"({format_size(total_size)}) ins Staging[/bold]"
        )

    success = True
    copied_count = 0

    sorted_files = sorted(files, key=lambda f: str(f.relative_path))

    for file_info in sorted_files:
        dest_path = staging_dir / file_info.relative_path
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            result = subprocess.run(
                ["ditto", str(file_info.path), str(dest_path)],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                raise RuntimeError(
                    result.stderr.strip() or f"ditto exited with {result.returncode}"
                )
            copied_count += 1

            if verbose:
                size_gib = file_info.size / (1024**3)
                console.print(f"   {file_info.relative_path} ({size_gib:.2f} GiB)")

        except Exception as e:
            if verbose:
                console.print(
                    f"[red]❌ Fehler beim Kopieren von {file_info.relative_path}: {e}[/red]"
                )
            success = False

    if verbose:
        console.print(
            f"   [green]✅ {copied_count} Datei(en) ins Staging kopiert[/green]"
        )

    return success
