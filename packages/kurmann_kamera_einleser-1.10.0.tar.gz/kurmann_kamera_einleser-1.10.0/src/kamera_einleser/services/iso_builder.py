"""ISO-Builder-Service: baut, benennt und verifiziert ISO-Dateien.

- Benennungs-Helper (`get_iso_name`, `get_iso_volume_name`, `get_year_from_day_key`)
- Kollisionsschutz (`get_unique_iso_path`: lokal vorhandene ODER im Index
  bekannte Basename werden übersprungen; das Tool wählt automatisch
  `-Teil-2.iso`, `-Teil-3.iso`, …).
- Bau via `hdiutil makehybrid -udf` (`create_iso`).
- Verify via `hdiutil imageinfo` (`verify_archive`).
- Aufräumen (`cleanup_archive_files`).
"""

from __future__ import annotations

import shlex
import shutil
import subprocess
from pathlib import Path

from rich.console import Console

from ..utils import format_size

console = Console()


# --- Benennungs-Helper --------------------------------------------------------


def get_iso_name(day_key: str) -> str:
    """ISO-Dateiname für einen Tag (`Originalmedien-YYYY-MM-DD.iso`)."""
    return f"Originalmedien-{day_key}.iso"


def get_iso_volume_name(day_key: str) -> str:
    """Volume-Name der ISO (`Originalmedien-YYYY-MM-DD`)."""
    return f"Originalmedien-{day_key}"


def get_year_from_day_key(day_key: str) -> str:
    """Jahr aus einem `YYYY-MM-DD`-Schlüssel."""
    return day_key[:4]


def get_unique_iso_path(
    output_dir: Path,
    day_key: str,
    known_names: set[str] | None = None,
) -> Path:
    """Liefert einen freien ISO-Pfad für den Tag, mit `-Teil-N`-Fortsetzung.

    Überschreibt niemals existierende ISOs. Wenn `Originalmedien-YYYY-MM-DD.iso`
    **entweder** bereits im `output_dir` liegt **oder** in der optionalen Menge
    `known_names` (typischerweise die Checksum-Index-Einträge inkl. bereits
    hochgeladener Remote-ISOs) vermerkt ist, wird automatisch `-Teil-2.iso`,
    `-Teil-3.iso`, … probiert, bis ein freier Name gefunden ist.
    """
    if known_names is None:
        known_names = set()

    base_name = f"Originalmedien-{day_key}"
    iso_name = f"{base_name}.iso"
    iso_path = output_dir / iso_name

    if not iso_path.exists() and iso_name not in known_names:
        return iso_path

    suffix = 2
    while True:
        iso_name = f"{base_name}-Teil-{suffix}.iso"
        iso_path = output_dir / iso_name
        if not iso_path.exists() and iso_name not in known_names:
            original_name = f"{base_name}.iso"
            if (output_dir / original_name).exists():
                reason = "im Arbeitsverzeichnis"
            elif original_name in known_names:
                reason = "auf einem Ziel"
            else:
                reason = "bereits vergeben"
            console.print(
                f"[yellow]⚠️  ISO-Datei für {day_key} existiert bereits ({reason}). "
                f"Verwende Suffix: {iso_name}[/yellow]"
            )
            return iso_path
        suffix += 1


# --- Bau ---------------------------------------------------------------------


def _run_shell(cmd: str, verbose: bool = True) -> int:
    """`subprocess.run` mit optionaler Live-stdout-Ausgabe."""
    if verbose:
        process = subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        if process.stdout:
            for line in process.stdout:
                print(line, end="")
        process.wait()
        return process.returncode
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.returncode


def create_iso(
    staging_dir: Path,
    iso_path: Path,
    volume_name: str,
    verbose: bool = True,
) -> bool:
    """Baut eine UDF-ISO aus `staging_dir` via `hdiutil makehybrid`.

    Returns:
        True bei Erfolg, False bei hdiutil-Fehler.
    """
    if verbose:
        console.print(f"\n[bold]💿 Erstelle ISO: {iso_path.name}[/bold]")
        console.print(f"   Volume-Name: {volume_name}")

    cmd = (
        f"hdiutil makehybrid "
        f"-o {shlex.quote(str(iso_path))} "
        f"{shlex.quote(str(staging_dir))} "
        f"-udf "
        f"-default-volume-name {shlex.quote(volume_name)}"
    )

    returncode = _run_shell(cmd, verbose=verbose)

    if returncode != 0:
        if verbose:
            console.print("[red]❌ Fehler beim Erstellen der ISO-Datei[/red]")
        return False

    if verbose:
        iso_size = iso_path.stat().st_size if iso_path.exists() else 0
        console.print(
            f"[green]✅ ISO erstellt: {iso_path.name} ({format_size(iso_size)})[/green]"
        )

    return True


# --- Verify ------------------------------------------------------------------


def verify_archive(archive_files: list[Path], verbose: bool = True) -> bool:
    """Prüft die Integrität einer Liste von ISO-Dateien via `hdiutil imageinfo`.

    Returns:
        True wenn jede ISO lesbar und non-empty ist, sonst False.
    """
    if not archive_files:
        return False

    if verbose:
        console.print("\n[bold]🔍 Führe Integritätstest durch...[/bold]")

    try:
        for archive_file in archive_files:
            if verbose:
                console.print(f"   Prüfe: {archive_file.name}")

            if not archive_file.exists():
                if verbose:
                    console.print(f"[red]   ❌ {archive_file.name} existiert nicht![/red]")
                return False

            if archive_file.stat().st_size == 0:
                if verbose:
                    console.print(f"[red]   ❌ {archive_file.name} ist leer![/red]")
                return False

            cmd = f"hdiutil imageinfo {shlex.quote(str(archive_file))}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

            if result.returncode != 0:
                if verbose:
                    console.print(f"[red]   ❌ {archive_file.name} ist ungültig![/red]")
                return False

            if verbose:
                console.print(f"   [green]✅ {archive_file.name} ist intakt[/green]")

        if verbose:
            console.print(f"   [green]✅ Alle {len(archive_files)} Archive intakt[/green]")
        return True

    except Exception as e:
        if verbose:
            console.print(f"[red]❌ Fehler beim Integritätstest: {e}[/red]")
        return False


# --- Cleanup -----------------------------------------------------------------


def cleanup_archive_files(archive_files: list[Path], verbose: bool = True) -> bool:
    """Löscht lokale ISO-Dateien (nach erfolgreichem Upload)."""
    if verbose:
        console.print("\n[bold]🗑️ Lösche lokale Archive...[/bold]")

    success = True
    for af in archive_files:
        try:
            if af.exists():
                if af.is_dir():
                    shutil.rmtree(af)
                else:
                    af.unlink()
                if verbose:
                    console.print(f"   [green]✅ Gelöscht: {af.name}[/green]")
        except Exception as e:
            if verbose:
                console.print(f"   [red]❌ Fehler beim Löschen von {af.name}: {e}[/red]")
            success = False

    return success
