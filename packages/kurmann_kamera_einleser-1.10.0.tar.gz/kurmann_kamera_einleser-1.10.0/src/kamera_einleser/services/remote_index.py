"""Remote-Index-Sync (ab 1.9.0).

Der Checksum-Index `checksum_index.csv` lebt zusätzlich zur lokalen Kopie
auch im **ersten konfigurierten rclone-Target** (typisch das lokale NAS),
direkt im `target_path`-Root neben den Year-Ordnern. Damit:

- bleibt die SHA-Information bei einem Index-Verlust auf dem Erst-Rechner
  erhalten (rebuild aus Remote-Index = volle SHA-Historie),
- braucht ein Zweit-Rechner kein Mount, kein hdiutil, keine Stunden — er
  pullt die ein paar KB grosse CSV einmal und hat den vollen Index inklusive
  SHA-256 zur Hand.

Synchronisationsstrategie: **Replace** (last-writer-wins). Lokale CSV
ersetzt Remote-CSV. Konflikte sind unwahrscheinlich, weil Kamera-Einleser
typisch nicht gleichzeitig auf mehreren Rechnern läuft. Sollte es doch
einmal vorkommen, schützen `--immutable` auf den ISOs selbst und der
Append-Only-Charakter des Index (Einträge werden nie modifiziert) vor
echtem Datenverlust — höchstens muss ein Rechner seine SHA-Werte für
ein paar Sessions neu erfassen.

Im ersten Lauf nach dem Update auf 1.9.0 ist `push_remote_index` automatisch
die Migration: die lokale CSV (mit Jahren von SHA-256-Werten) landet einmalig
auf dem NAS.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from ..config import get_config

if TYPE_CHECKING:
    from ..config import Config


# Dateiname des Remote-Index. Liegt im `target_path`-Root des ersten Targets.
REMOTE_INDEX_FILENAME = "checksum_index.csv"


@dataclass
class IndexSyncResult:
    """Ergebnis eines pull/push-Laufs."""

    ok: bool
    direction: str  # "pull" | "push"
    remote_path: str
    local_path: Path
    bytes_transferred: int = 0
    message: str = ""


def get_remote_index_path(cfg: "Config | None" = None) -> str | None:
    """Liefert den vollständigen rclone-Pfad des Remote-Index.

    Konvention: erstes konfiguriertes rclone-Target (typisch das lokale NAS)
    hostet den Index direkt im `target_path`-Root unter dem Namen
    `REMOTE_INDEX_FILENAME`. Beispiel:

        Targets[0] = {"name": "Lyssach NAS", "path": "lyssach-nas:/Originalmedien"}
        → "lyssach-nas:/Originalmedien/checksum_index.csv"

    Returns:
        Vollständiger rclone-Pfad oder `None`, wenn kein erstes Target
        konfiguriert ist.
    """
    config = cfg if cfg is not None else get_config()
    targets = config.get_rclone_targets()
    if not targets:
        return None
    first = targets[0]
    target_path = first.get("path", "").rstrip("/")
    if not target_path:
        return None
    return f"{target_path}/{REMOTE_INDEX_FILENAME}"


def _remote_file_exists(remote_path: str) -> bool:
    """Prüft ob die Remote-Datei via `rclone lsf` sichtbar ist."""
    proc = subprocess.run(
        ["rclone", "lsf", remote_path],
        capture_output=True,
        text=True,
        timeout=30,
    )
    return proc.returncode == 0 and bool(proc.stdout.strip())


def push_remote_index(
    *,
    dry_run: bool = False,
    console: Console | None = None,
    cfg: "Config | None" = None,
) -> IndexSyncResult:
    """Pusht die lokale CSV in den ersten rclone-Target.

    Erste Ausführung nach 1.9.0 = Migration: lokale CSV mit allen
    historischen SHA-256-Werten landet auf dem NAS.

    Folge-Ausführungen: nach jedem erfolgreichen `archive`-Lauf wird die
    aktualisierte lokale CSV hochgeschoben. Strategie ist **Replace** —
    die lokale Version ersetzt die Remote-Version (last-writer-wins).

    Args:
        dry_run: meldet, was getan würde, ohne rclone aufzurufen.
        console: rich-Console für Log-Output.
        cfg: Explicit Config-Instanz (DI).

    Returns:
        IndexSyncResult.ok = True bei Erfolg oder Dry-Run.
    """
    cons = console or Console()
    config = cfg if cfg is not None else get_config()
    local_csv = config.get_checksum_index_path()
    remote_path = get_remote_index_path(config)

    if not remote_path:
        return IndexSyncResult(
            ok=False,
            direction="push",
            remote_path="",
            local_path=local_csv,
            message="Kein erstes rclone-Target konfiguriert.",
        )

    if not local_csv.exists():
        return IndexSyncResult(
            ok=False,
            direction="push",
            remote_path=remote_path,
            local_path=local_csv,
            message=f"Lokale CSV existiert nicht: {local_csv}",
        )

    size = local_csv.stat().st_size
    cons.print(
        f"[cyan]📤 Index-Push:[/cyan] {local_csv} → [bold]{remote_path}[/bold] "
        f"({size:,} Bytes)"
    )

    if dry_run:
        cons.print("   [dim](dry-run — kein Upload)[/dim]")
        return IndexSyncResult(
            ok=True,
            direction="push",
            remote_path=remote_path,
            local_path=local_csv,
            bytes_transferred=size,
            message="dry-run",
        )

    proc = subprocess.run(
        ["rclone", "copyto", str(local_csv), remote_path, "--stats-one-line"],
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        cons.print(
            f"[red]❌ rclone copyto fehlgeschlagen: "
            f"{(proc.stderr or proc.stdout).strip()}[/red]"
        )
        return IndexSyncResult(
            ok=False,
            direction="push",
            remote_path=remote_path,
            local_path=local_csv,
            message=proc.stderr.strip() or proc.stdout.strip(),
        )

    cons.print("[green]   ✅ Index hochgeladen.[/green]")
    return IndexSyncResult(
        ok=True,
        direction="push",
        remote_path=remote_path,
        local_path=local_csv,
        bytes_transferred=size,
    )


def pull_remote_index(
    *,
    dry_run: bool = False,
    console: Console | None = None,
    cfg: "Config | None" = None,
) -> IndexSyncResult:
    """Pullt den Remote-Index in die lokale CSV.

    Wenn die lokale CSV bereits existiert, wird sie überschrieben.
    Aufrufer muss vorher entscheiden, ob das gewünscht ist (CLI hat
    `--force` für genau diesen Fall).

    Args:
        dry_run: meldet, was getan würde, ohne rclone aufzurufen.
        console: rich-Console für Log-Output.
        cfg: Explicit Config-Instanz (DI).

    Returns:
        IndexSyncResult.ok = True bei Erfolg oder Dry-Run.
        Bei `Remote nicht vorhanden` ist ok=False mit klarer Message.
    """
    cons = console or Console()
    config = cfg if cfg is not None else get_config()
    local_csv = config.get_checksum_index_path()
    remote_path = get_remote_index_path(config)

    if not remote_path:
        return IndexSyncResult(
            ok=False,
            direction="pull",
            remote_path="",
            local_path=local_csv,
            message="Kein erstes rclone-Target konfiguriert.",
        )

    cons.print(
        f"[cyan]📥 Index-Pull:[/cyan] {remote_path} → [bold]{local_csv}[/bold]"
    )

    if not _remote_file_exists(remote_path):
        cons.print(
            f"[yellow]⚠️  Remote-Index existiert noch nicht: {remote_path}\n"
            "   Auf dem Erst-Rechner einmal `kamera-einleser index push` "
            "ausführen, um zu migrieren.[/yellow]"
        )
        return IndexSyncResult(
            ok=False,
            direction="pull",
            remote_path=remote_path,
            local_path=local_csv,
            message="Remote-Index nicht vorhanden",
        )

    if dry_run:
        cons.print("   [dim](dry-run — kein Download)[/dim]")
        return IndexSyncResult(
            ok=True,
            direction="pull",
            remote_path=remote_path,
            local_path=local_csv,
            message="dry-run",
        )

    local_csv.parent.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        ["rclone", "copyto", remote_path, str(local_csv), "--stats-one-line"],
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        cons.print(
            f"[red]❌ rclone copyto fehlgeschlagen: "
            f"{(proc.stderr or proc.stdout).strip()}[/red]"
        )
        return IndexSyncResult(
            ok=False,
            direction="pull",
            remote_path=remote_path,
            local_path=local_csv,
            message=proc.stderr.strip() or proc.stdout.strip(),
        )

    size = local_csv.stat().st_size if local_csv.exists() else 0
    cons.print(f"[green]   ✅ Index heruntergeladen ({size:,} Bytes).[/green]")
    return IndexSyncResult(
        ok=True,
        direction="pull",
        remote_path=remote_path,
        local_path=local_csv,
        bytes_transferred=size,
    )


def remote_index_exists(cfg: "Config | None" = None) -> bool:
    """True, wenn ein Remote-Index auf dem ersten Target sichtbar ist.

    Genutzt vom Startup-Guard, um auf einem frisch eingerichteten Zweit-
    Rechner gezielt zu `index pull` zu raten statt zum teuren `index rebuild`.
    """
    remote_path = get_remote_index_path(cfg)
    if not remote_path:
        return False
    try:
        return _remote_file_exists(remote_path)
    except (subprocess.TimeoutExpired, OSError):
        return False
