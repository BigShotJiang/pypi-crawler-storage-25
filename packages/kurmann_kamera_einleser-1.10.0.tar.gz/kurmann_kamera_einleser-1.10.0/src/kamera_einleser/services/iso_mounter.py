"""ISO-Mounter-Service: read-only Mount einer ISO via `hdiutil attach` für
Indexierung und Kollisions-Checks.

Zwei Hauptfunktionen:

- `update_checksum_index_for_iso`: wird nach erfolgreichem Upload aufgerufen.
  Mountet die ISO, delegiert an `checksum.index_iso_files` um alle SHA-256
  zu berechnen, schreibt die Einträge via `checksum.append_to_index` und
  unmountet garantiert (finally-Block).
- `check_files_in_existing_iso`: wird im Archive-Flow für den "Fall A"
  genutzt — vergleicht Source-Dateien gegen bereits existierende lokale
  ISOs (NFC-normalisierter relativer Pfad + Grösse). Liefert die Teilmenge
  der noch nicht archivierten Dateien zurück.
"""

from __future__ import annotations

import plistlib
import subprocess
import unicodedata
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from ..checksum import append_to_index, index_iso_files
from ..config import get_config

if TYPE_CHECKING:
    from ..config import Config
    from .file_scanner import FileInfo

console = Console()


def update_checksum_index_for_iso(
    iso_path: Path,
    verbose: bool = True,
    cfg: "Config | None" = None,
) -> bool:
    """Mountet die ISO, indexiert alle Files, schreibt in den CSV-Index.

    Args:
        iso_path: Pfad zur ISO-Datei.
        verbose: steuert CLI-Ausgabe.
        cfg: Explicit Config instance (DI). Fallback auf `get_config()`.

    Returns:
        True bei Erfolg, False bei jedem Fehler (Mount, Indexierung, I/O).
    """
    config = cfg if cfg is not None else get_config()
    csv_path = config.get_checksum_index_path()

    if verbose:
        console.print("[cyan]🔑 Aktualisiere Checksummen-Index...[/cyan]")

    mount_point = None
    try:
        result = subprocess.run(
            ["hdiutil", "attach", str(iso_path), "-readonly", "-nobrowse", "-plist"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            if verbose:
                console.print(
                    "[yellow]⚠️  Konnte ISO nicht mounten für Indexierung[/yellow]"
                )
            return False

        plist_data = plistlib.loads(result.stdout.encode())
        for entity in plist_data.get("system-entities", []):
            mp = entity.get("mount-point")
            if mp:
                mount_point = Path(mp)
                break

        if not mount_point or not mount_point.exists():
            if verbose:
                console.print("[yellow]⚠️  Mount-Point nicht gefunden[/yellow]")
            return False

        entries = index_iso_files(mount_point, iso_path.name)

        if entries:
            append_to_index(csv_path, entries)

            if verbose:
                for entry in entries[:3]:
                    hash_short = entry["sha256"][:12] + "..."
                    console.print(f"   {entry['dateiname']} → sha256: {hash_short}")
                if len(entries) > 3:
                    console.print(f"   ... und {len(entries) - 3} weitere")

                console.print(
                    f"[green]   ✅ {len(entries)} Datei(en) im Checksummen-Index "
                    f"erfasst ({csv_path.name})[/green]"
                )
        elif verbose:
            console.print("[yellow]   ⚠️  Keine indexierbaren Dateien gefunden[/yellow]")

        return True

    except Exception as e:
        if verbose:
            console.print(f"[yellow]⚠️  Fehler beim Indexieren: {e}[/yellow]")
        return False
    finally:
        if mount_point:
            try:
                subprocess.run(
                    ["hdiutil", "detach", str(mount_point), "-quiet"],
                    capture_output=True,
                    timeout=30,
                )
            except Exception:
                pass


def check_files_in_existing_iso(
    files: list["FileInfo"],
    existing_iso_paths: list[Path],
    verbose: bool = True,
) -> list["FileInfo"]:
    """Liefert die Teilmenge von `files`, die NICHT in bestehenden ISOs liegt.

    Mountet jede ISO readonly, scannt sie vollständig und baut ein Set aus
    (NFC-normalisiertem relativer Pfad, Grösse). Source-Dateien, die in dem
    Set auftauchen, werden als "bereits archiviert" betrachtet.

    Returns:
        Liste der fehlenden Dateien. Leer = alles bereits archiviert.
    """
    if not existing_iso_paths:
        return list(files)

    found_files: set[tuple[str, int]] = set()

    for iso_path in existing_iso_paths:
        if not iso_path.exists():
            continue

        mount_point = None
        try:
            result = subprocess.run(
                ["hdiutil", "attach", str(iso_path), "-readonly", "-nobrowse", "-plist"],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                if verbose:
                    console.print(
                        f"[yellow]⚠️  Konnte {iso_path.name} nicht mounten[/yellow]"
                    )
                continue

            plist_data = plistlib.loads(result.stdout.encode())
            for entity in plist_data.get("system-entities", []):
                mp = entity.get("mount-point")
                if mp:
                    mount_point = Path(mp)
                    break

            if not mount_point or not mount_point.exists():
                continue

            for item in mount_point.rglob("*"):
                if item.is_file():
                    try:
                        rel_path = unicodedata.normalize(
                            "NFC", str(item.relative_to(mount_point))
                        )
                        file_size = item.stat().st_size
                        found_files.add((rel_path, file_size))
                    except (OSError, ValueError):
                        pass

        except Exception as e:
            if verbose:
                console.print(
                    f"[yellow]⚠️  Fehler beim Prüfen von {iso_path.name}: {e}[/yellow]"
                )
        finally:
            if mount_point:
                try:
                    subprocess.run(
                        ["hdiutil", "detach", str(mount_point), "-quiet"],
                        capture_output=True,
                        timeout=30,
                    )
                except Exception:
                    pass

    missing: list["FileInfo"] = []
    for f in files:
        key = (unicodedata.normalize("NFC", str(f.relative_path)), f.size)
        if key not in found_files:
            missing.append(f)

    return missing
