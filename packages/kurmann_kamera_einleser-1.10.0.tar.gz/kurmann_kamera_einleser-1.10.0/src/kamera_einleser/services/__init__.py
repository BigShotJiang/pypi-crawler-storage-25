"""Service-Layer: fokussierte Module für ISO-Pipeline-Schritte."""
