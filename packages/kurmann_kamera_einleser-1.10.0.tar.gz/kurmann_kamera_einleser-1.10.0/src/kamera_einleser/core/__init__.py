"""Core-Layer: hoch-level Orchestration. Komponiert Services zu Gesamtabläufen."""
