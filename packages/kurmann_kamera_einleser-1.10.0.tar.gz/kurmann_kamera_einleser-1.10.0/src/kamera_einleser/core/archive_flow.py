"""Archive-Flow: der Orchestrator der ISO-Erstellung pro Quell-Verzeichnis.

Komponiert die Services unter `services/` zum kompletten Pipeline-Ablauf:

  Source-Scan → Disk-Space-Check → Idempotenz (Fall A/C) → Staging
  → ISO-Bau → Integritätsprüfung (upstream).

Die Funktion bekommt ein fertiges `output_dir` rein — Working-Dir-Resolver
und Pull-Schritt passieren eine Ebene darüber in `api._process_source`.
"""

from __future__ import annotations

import shutil
import tempfile
import unicodedata
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from ..checksum import (
    filenames_indexed_for_day,
    get_iso_names_from_index,
    load_index,
)
from ..config import get_config
from ..services.file_scanner import (
    calculate_directory_size,
    check_disk_space,
    get_all_files_with_day,
    get_existing_isos,
)
from ..services.iso_builder import create_iso, get_unique_iso_path
from ..services.iso_mounter import check_files_in_existing_iso
from ..services.staging import copy_files_to_staging, has_non_hidden_files
from ..utils import format_size

if TYPE_CHECKING:
    from ..config import Config

console = Console()

# Disk-Space-Sicherheit beim Output-Dir-Check (ISO-Build selbst).
SAFETY_MARGIN_FACTOR = 1.2


def create_archive(
    source_path: Path,
    output_dir: Path,
    archive_name: str | None = None,
    verbose: bool = True,
    cfg: "Config | None" = None,
) -> tuple[bool, list[Path]]:
    """Erstellt ISO-Archive aus einem Quell-Verzeichnis — eines pro Tag.

    Dateien werden nach Modification-Day gruppiert und pro Tag in eine
    `Originalmedien-YYYY-MM-DD.iso` (bzw. `-Teil-N.iso` bei Namens-
    kollisionen) verpackt.

    Existierende ISOs werden NIE überschrieben. Fall A (lokale ISO vorhanden
    → Subset-Check) und Fall C (Index kennt alle Files → Skip ohne Server-
    Kommunikation) entscheiden pro Tag, ob gebaut wird.

    Args:
        source_path: Quellverzeichnis.
        output_dir: Ziel für die ISO-Dateien (vom Resolver vorgegeben).
        archive_name: Historischer Parameter, wird ignoriert.
        verbose: Steuert CLI-Ausgabe.
        cfg: Explicit Config instance (DI). Fallback auf `get_config()`.

    Returns:
        (success, list[Path]) — Liste aller neu erzeugten ISOs.
    """
    config = cfg if cfg is not None else get_config()
    excludes = config.get_excludes()

    # Validate source path
    if not source_path.exists():
        if verbose:
            console.print(
                f"[red]❌ Fehler: Quellverzeichnis existiert nicht: {source_path}[/red]"
            )
        return False, []

    if not source_path.is_dir():
        if verbose:
            console.print(
                f"[red]❌ Fehler: Quelle ist kein Verzeichnis: {source_path}[/red]"
            )
        return False, []

    # Source-Grösse + Tag-Gruppierung
    if verbose:
        console.print(f"\n[bold]📊 Analysiere {source_path.name}...[/bold]")

    source_size_bytes = calculate_directory_size(source_path)
    if verbose:
        console.print(f"   Gesamtgröße: {format_size(source_size_bytes)}")

    if verbose:
        console.print("\n[bold]📁 Gruppiere Dateien nach Tag...[/bold]")

    files_by_day = get_all_files_with_day(source_path, excludes)

    if not files_by_day:
        if verbose:
            console.print(
                "[dim]ℹ️  Keine Dateien zum Archivieren (Quelle ist leer "
                "oder enthält nur ausgeschlossene Dateien)[/dim]"
            )
            console.print("[dim]   Quelle wird übersprungen[/dim]")
        return True, []

    if verbose:
        console.print(
            f"   Gefunden: {sum(len(f) for f in files_by_day.values())} "
            f"Datei(en) in {len(files_by_day)} Tag(en)"
        )
        for day_key in sorted(files_by_day.keys()):
            files = files_by_day[day_key]
            day_size = sum(f.size for f in files)
            console.print(
                f"   - {day_key}: {len(files)} Datei(en) ({format_size(day_size)})"
            )

    # Disk-Space-Check (Output-Dir)
    if verbose:
        console.print("\n[bold]💾 Prüfe verfügbaren Speicherplatz...[/bold]")

    required_space = int(source_size_bytes * SAFETY_MARGIN_FACTOR)
    has_space, available_space = check_disk_space(output_dir, required_space)

    if verbose:
        console.print(f"   Verfügbar: {format_size(available_space)}")
        console.print(
            f"   Benötigt: {format_size(required_space)} (inkl. 20% Sicherheitsmarge)"
        )

    if not has_space:
        if verbose:
            console.print("[red]❌ Nicht genug Speicherplatz[/red]")
        return False, []

    if verbose:
        console.print("   [green]✅ Genug Speicherplatz vorhanden[/green]")

    output_dir.mkdir(parents=True, exist_ok=True)

    # Existing ISOs für Idempotenz-Check
    existing_isos = get_existing_isos(output_dir)

    if verbose:
        console.print("\n[bold]🔍 Prüfe bestehende ISOs...[/bold]")

    csv_path = config.get_checksum_index_path()
    local_index = load_index(csv_path)
    all_known_iso_names = get_iso_names_from_index(local_index)

    if verbose:
        if all_known_iso_names:
            console.print(
                f"   📋 {len(all_known_iso_names)} ISO-Datei(en) im "
                f"lokalen Index gefunden"
            )
        else:
            console.print("   📋 Keine ISOs im lokalen Index gefunden")
        console.print("   ℹ️  Kollisionserkennung basiert auf lokalem Index")
        console.print(
            "   ℹ️  Remote-Kollisionen werden beim Transfer mit rclone "
            "--immutable erkannt"
        )

    # Tages-Schleife
    all_isos: list[Path] = []
    skipped_days = 0

    for day_key in sorted(files_by_day.keys()):
        files = files_by_day[day_key]

        if verbose:
            console.print(f"\n{'=' * 60}")
            console.print(f"[bold]📅 Verarbeite Tag: {day_key}[/bold]")
            console.print(f"{'=' * 60}")

        # Fall A: lokale ISO vorhanden → Subset-Check
        if day_key in existing_isos:
            if verbose:
                console.print(
                    f"\n[bold]🔍 Prüfe bestehende ISO(s) für {day_key}...[/bold]"
                )
            missing_files = check_files_in_existing_iso(
                files, existing_isos[day_key], verbose=verbose
            )
            if not missing_files:
                if verbose:
                    console.print(
                        f"[green]✅ Alle {len(files)} Datei(en) bereits in "
                        f"ISO vorhanden – überspringe Tag {day_key}[/green]"
                    )
                skipped_days += 1
                continue
            if verbose:
                console.print(
                    f"[yellow]⚠️  {len(missing_files)} von {len(files)} "
                    f"Datei(en) fehlen in bestehenden ISOs – erstelle neue "
                    f"ISO[/yellow]"
                )
            files = missing_files
        else:
            # Fall C (1.5.0): keine lokale ISO, aber Index kennt alle Files
            # → Skip ohne Rebuild. Verhindert Duplicate-Content wenn lokale
            # ISO weg ist, aber Remote-Kopie noch existiert.
            indexed_filenames = filenames_indexed_for_day(local_index, day_key)
            if indexed_filenames:
                source_filenames = {
                    unicodedata.normalize("NFC", f.path.name) for f in files
                }
                if source_filenames.issubset(indexed_filenames):
                    if verbose:
                        console.print(
                            f"[dim]📋 Alle {len(files)} Datei(en) laut Index "
                            f"archiviert (ISO lokal nicht präsent) – überspringe "
                            f"Tag {day_key}[/dim]"
                        )
                    skipped_days += 1
                    continue

        # Staging + Build
        staging_dir = None
        try:
            # Fix (1.9.1): Staging landet im Working-Dir (output_dir),
            # nicht im System-Temp. Sonst übersieht der Pre-Flight-Check
            # in api._process_source den Staging-Footprint — er prüft nur
            # das Working-Dir gegen LOCAL_WORKDIR_SAFETY (2.5×) bzw.
            # REMOTE_PIPELINE_SAFETY (3.5×), die Staging implizit
            # einschliessen. System-Temp lag aber bislang separat (oft
            # auf der internen SSD) und konnte unbemerkt vollaufen,
            # während das gewählte Working-Dir auf einer externen SSD
            # noch reichlich Platz hatte. Symptom: ditto-Fehler
            # "No space left on device" mitten im Lauf.
            output_dir.mkdir(parents=True, exist_ok=True)
            staging_dir = Path(
                tempfile.mkdtemp(
                    prefix=f"kamera-einleser-{day_key}-",
                    dir=str(output_dir),
                )
            )

            if not copy_files_to_staging(files, staging_dir, verbose=verbose):
                return False, all_isos

            if not has_non_hidden_files(staging_dir):
                if verbose:
                    console.print(
                        f"[yellow]⚠️  Nur versteckte Dateien für Tag "
                        f"{day_key} – überspringe ISO-Erstellung[/yellow]"
                    )
                skipped_days += 1
                continue

            iso_path = get_unique_iso_path(
                output_dir, day_key, known_names=all_known_iso_names
            )

            volume_name = iso_path.stem

            if not create_iso(staging_dir, iso_path, volume_name, verbose=verbose):
                # Fix D (1.6.0): partielle ISO entsorgen, damit nicht zig GB
                # Müll im Working-Dir liegen bleiben (hdiutil-EPERM-bei-
                # Disk-full).
                if iso_path.exists():
                    try:
                        partial_size = iso_path.stat().st_size
                        iso_path.unlink()
                        if verbose:
                            console.print(
                                f"[dim]🧹 Partielle ISO entfernt: "
                                f"{iso_path.name} ({format_size(partial_size)})[/dim]"
                            )
                    except OSError as exc:
                        if verbose:
                            console.print(
                                f"[yellow]⚠️  Konnte partielle ISO nicht "
                                f"entfernen ({iso_path}): {exc}[/yellow]"
                            )
                return False, all_isos

            all_isos.append(iso_path)

            # Checksum-Index wird ERST nach erfolgreichem Upload befüllt —
            # siehe api._index_after_upload (Fix 1 aus 1.5.0).

            if verbose:
                console.print(f"[green]✅ Tag {day_key} verarbeitet[/green]")

        finally:
            # Staging immer aufräumen
            if staging_dir and staging_dir.exists():
                try:
                    shutil.rmtree(staging_dir)
                except Exception:
                    pass

    if verbose:
        created_count = len(all_isos)
        if skipped_days > 0:
            console.print(
                f"\n[bold green]✅ {created_count} ISO-Datei(en) erstellt, "
                f"{skipped_days} Tag(e) übersprungen (bereits archiviert)[/bold green]"
            )
        else:
            console.print(
                f"\n[bold green]✅ {created_count} ISO-Datei(en) erstellt[/bold green]"
            )

    return True, all_isos
