"""Public API: Facade über den bestehenden Archivierungs-Workflow.

Folgt dem kurmann-python-api Skill:
- Einstieg via Request/Result
- Laufzeit-Optionen getrennt via RuntimeOptions
- Event-Callbacks via ArchiveEvents
- Teiloperationen (`build_isos`, `verify`, `upload`) bleiben im service-Layer
  aufrufbar und werden von `archive()` orchestriert.

Bestehende Module (`archive.py`, `rclone.py`, `restore.py`) dienen aktuell
als Service-Schicht. Eine physische Aufteilung in `services/` folgt in einem
späteren PR; das hier ist der stabile Public-API-Einstiegspunkt.
"""

from __future__ import annotations

import re
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import Config

from .checksum import all_indexed_filenames, get_iso_names_from_index, load_index
from .config import (
    LOCAL_WORKDIR_SAFETY,
    WorkingDirectoryUnavailableError,
    get_config,
)
from .core.archive_flow import create_archive
from .models import (
    ArchiveEvents,
    ArchiveRequest,
    ArchiveResult,
    LocalSource,
    RcloneSource,
    RuntimeOptions,
    SourceRef,
)
from .rclone import (
    check_rclone_available,
    get_rclone_source_size,
    pull_rclone_source_to_dir,
    upload_to_all_targets,
)
from .services.file_scanner import (
    calculate_directory_size,
    cleanup_source_files,
    get_existing_isos,
)
from .services.iso_builder import verify_archive
from .services.iso_mounter import update_checksum_index_for_iso

# Pipeline-Footprint-Konstanten leben in config.py; siehe dort die Begründung
# für LOCAL_WORKDIR_SAFETY, REMOTE_PIPELINE_SAFETY, SPLIT_PIPELINE_PER_VOLUME_SAFETY.


def archive(
    request: ArchiveRequest,
    options: RuntimeOptions | None = None,
    events: ArchiveEvents | None = None,
    cfg: "Config | None" = None,
) -> ArchiveResult:
    """Orchestriert einen kompletten Archivierungs-Lauf über N Quellen.

    `cfg` ist eine explizite Config-Instanz (DI ab 1.7.0). Fällt auf
    `get_config()` zurück, damit bestehende Aufrufer ohne Anpassung
    weiterlaufen. Neue Aufrufer (Tests, Integrations) sollten die
    Config bewusst injizieren.
    """
    options = options or RuntimeOptions()
    events = events or ArchiveEvents()
    verbose = options.is_verbose
    config = cfg if cfg is not None else get_config()

    if not request.no_upload and not check_rclone_available():
        return ArchiveResult(success=False, message="rclone ist nicht installiert")

    result = ArchiveResult(success=True)

    for source in request.sources:
        if events.on_source_started:
            events.on_source_started(source)

        # request.working_dir (falls explizit gesetzt) überstimmt den Resolver.
        ok, isos = _process_source(
            source,
            request.working_dir,
            request.no_upload,
            verbose,
            full_pull=request.full_pull,
            cfg=config,
        )

        result.iso_files.extend(isos)
        if ok:
            result.processed_sources.append(source)
        else:
            result.failed_sources.append(source)
            result.success = False

        if events.on_source_finished:
            events.on_source_finished(source, ok)

    if (
        result.success
        and request.delete_source
        and not options.dry_run
    ):
        for source in result.processed_sources:
            if isinstance(source, LocalSource):
                cleanup_source_files(source.path, verbose=verbose)

    # 1.9.0: Lokalen Index nach erfolgreichem Lauf zum NAS pushen, damit
    # andere Rechner via `index pull` synchron bleiben. Best-effort —
    # Push-Fehler kippen das Gesamt-Result nicht (ISOs sind ja schon hoch).
    if (
        result.success
        and not request.no_upload
        and not options.dry_run
        and result.iso_files
    ):
        from .services.remote_index import push_remote_index

        push_result = push_remote_index(cfg=config)
        if not push_result.ok:
            from rich.console import Console

            Console(stderr=True).print(
                f"[yellow]⚠️  Index-Push fehlgeschlagen: {push_result.message}\n"
                "   Lauf war trotzdem erfolgreich. Bei Gelegenheit manuell "
                "[bold]kamera-einleser index push[/bold] ausführen.[/yellow]"
            )

    return result


def _process_source(
    source: SourceRef,
    working_dir_override: Path | None,
    no_upload: bool,
    verbose: bool,
    full_pull: bool = False,
    cfg: "Config | None" = None,
) -> tuple[bool, list[Path]]:
    """Verarbeitet eine einzelne Quelle: (Pull) → Staging → ISO → Verify → Upload.

    `working_dir_override` hat Vorrang; sonst wird via
    `Config.resolve_working_directory` anhand der Quell-Grösse und des
    Quell-Typs ein Pfad gewählt (primär → fallback → ggf. Temp).

    `full_pull=True` übergeht den Index-Prefilter für rclone-Quellen und zieht
    jede Datei erneut. Für lokale Quellen ist der Flag irrelevant.

    `cfg` ist eine explizite Config-Instanz (DI). Fallback auf `get_config()`.
    """
    pull_dir: Path | None = None
    cfg = cfg if cfg is not None else get_config()

    try:
        if isinstance(source, RcloneSource):
            source_bytes = get_rclone_source_size(source.rclone_path) or 0
            # Split-Pipeline (1.6.0): Pull → Primary, ISO → Fallback wenn beide
            # mit ~1.5× source frei sind. Sonst Single-Volume (3.5× source auf
            # einer Disk). Beides via Config-Resolver gekapselt.
            try:
                if working_dir_override is not None:
                    pull_root = iso_dir = working_dir_override
                else:
                    pull_root, iso_dir = cfg.resolve_split_pipeline(
                        source_bytes, is_rclone_source=True
                    )
            except WorkingDirectoryUnavailableError as exc:
                from rich.console import Console

                Console(stderr=True).print(f"[red]❌ {exc}[/red]")
                return False, []

            if verbose and pull_root != iso_dir:
                from rich.console import Console

                Console().print(
                    f"[dim]🔀 Split-Pipeline: Pull → {pull_root} | "
                    f"ISO → {iso_dir}[/dim]"
                )

            working_dir = iso_dir  # für create_archive (output_dir)

            excludes = cfg.get_excludes() if hasattr(cfg, "get_excludes") else None
            pull_dir = Path(
                tempfile.mkdtemp(
                    prefix=f"rclone-pull-{_slugify(source.remote)}-",
                    dir=str(pull_root),
                )
            )

            # Fix 3: Index-Prefilter. Liest die bereits indexierten Dateinamen
            # und übergibt sie an rclone, damit nur neue Dateien gepullt werden.
            # Mit full_pull=True wird der Filter explizit deaktiviert.
            skip_names: set[str] | None = None
            if not full_pull:
                csv_path = cfg.get_checksum_index_path()
                skip_names = all_indexed_filenames(load_index(csv_path))

            if not pull_rclone_source_to_dir(
                source,
                pull_dir,
                excludes,
                verbose,
                skip_filenames=skip_names,
            ):
                return False, []
            source_path = pull_dir
        elif isinstance(source, LocalSource):
            source_bytes = (
                calculate_directory_size(source.path) if source.path.exists() else 0
            )
            required = int(source_bytes * LOCAL_WORKDIR_SAFETY) if source_bytes else 0
            try:
                working_dir = working_dir_override or cfg.resolve_working_directory(
                    required,
                    is_rclone_source=False,
                    source_bytes_for_error=source_bytes,
                    safety_factor_for_error=LOCAL_WORKDIR_SAFETY,
                )
            except WorkingDirectoryUnavailableError as exc:
                from rich.console import Console

                Console(stderr=True).print(f"[red]❌ {exc}[/red]")
                return False, []
            source_path = source.path
        else:  # pragma: no cover - defensive
            raise TypeError(f"Unbekannter Source-Typ: {type(source).__name__}")

        success, archive_files = create_archive(
            source_path=source_path,
            output_dir=working_dir,
            archive_name=None,
            verbose=verbose,
            cfg=cfg,
        )
        if not success:
            return False, []

        if not archive_files:
            existing = get_existing_isos(working_dir)
            all_isos: list[Path] = []
            for iso_list in existing.values():
                all_isos.extend(iso_list)
            archive_files = sorted(all_isos)
            if not archive_files:
                return True, []

        if not verify_archive(archive_files, verbose=verbose):
            return False, archive_files

        if not no_upload:
            all_ok, _, _ = upload_to_all_targets(
                archive_files, verbose=verbose, cfg=cfg
            )
            if not all_ok:
                # Kein Index-Write bei fehlgeschlagenem Upload — verhindert
                # Phantom-Einträge (Index kennt ISO, aber kein Target hat sie).
                return False, archive_files

        # Fix 1 (1.5.0): Index-Write erst JETZT, nach verify + upload success.
        # Überspringe ISOs, die schon im Index sind (Fall: Retry-Upload
        # einer bereits gebauten + indexierten ISO).
        _index_after_upload(archive_files, verbose=verbose, cfg=cfg)

        return True, archive_files
    finally:
        if pull_dir is not None and pull_dir.exists():
            shutil.rmtree(pull_dir, ignore_errors=True)


def _slugify(name: str) -> str:
    """Dateisystem-sichere Kurzform eines Remote-Namens."""
    return re.sub(r"[^A-Za-z0-9_-]+", "-", name).strip("-") or "remote"


def _index_after_upload(
    iso_paths: list[Path],
    verbose: bool = True,
    cfg: "Config | None" = None,
) -> None:
    """Nimmt jede ISO in den Checksum-Index auf, falls noch nicht enthalten.

    Wird ausschliesslich nach erfolgreichem Upload aufgerufen. So enthält
    der Index nur ISOs, die tatsächlich auf mindestens einem Target
    angekommen sind.
    """
    config = cfg if cfg is not None else get_config()
    csv_path = config.get_checksum_index_path()
    already_indexed = get_iso_names_from_index(load_index(csv_path))

    for iso_path in iso_paths:
        if iso_path.name in already_indexed:
            continue
        update_checksum_index_for_iso(iso_path, verbose=verbose, cfg=config)


__all__ = [
    "archive",
    "ArchiveRequest",
    "ArchiveResult",
    "ArchiveEvents",
    "RuntimeOptions",
    "LocalSource",
    "SourceRef",
]
