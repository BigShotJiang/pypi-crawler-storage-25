"""Configuration management for kamera-einleser.

TOML ist das primäre Format (XDG-konform unter
`$XDG_CONFIG_HOME/kamera-einleser/config.toml`).

Der Config-Ordner heisst bewusst `kamera-einleser` (Tool-Name, nicht
PyPI-Paketname). Legacy-YAML-Dateien im selben Ordner werden beim ersten
Aufruf automatisch nach TOML migriert; die YAML-Datei wird zu
`config.yaml.bak`.
"""

import copy
import os
import shutil
import sys
from pathlib import Path
from typing import Any

import tomli_w
import yaml

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover - py3.10 fallback
    import tomli as tomllib

# Default configuration values
DEFAULT_CONFIG = {
    "source_directories": [],
    "rclone_targets": [],
    "working_directory": "",
    "working_directory_fallback": "",  # Sekundär (z.B. externe SSD), wenn primär fehlt / voll
    "iso_cache_max_bytes": 500_000_000_000,  # 500 GB Cache-Limit; 0 = unlimited
    "archive_split_size_bytes": 20_000_000_000,  # 20 billion bytes (legacy, kept for compatibility)
    "excludes": ["._*", ".DS_Store"],
    "checksum_index_path": "",  # Path to the checksum index CSV file (empty = default)
}

APP_SLUG = "kamera-einleser"

# --- Pipeline-Footprint-Konstanten ----------------------------------------
#
# Drei Multiplikatoren steuern die Disk-Space-Buchhaltung des Resolvers.
# Sie wurden alle aus echten Vorfällen kalibriert.
#
# LOCAL_WORKDIR_SAFETY (× 2.5):
#   Lokale Quellen → Staging + ISO leben gleichzeitig auf der Working-Dir-
#   Disk. Quelle selbst zählt nicht, weil sie nicht kopiert wird.
#
# REMOTE_PIPELINE_SAFETY (× 3.5):
#   rclone-Quellen, Single-Volume-Modus → Pull + Staging + ISO summieren
#   sich auf derselben APFS-Container. Mathematische Untergrenze ist 3.0×;
#   die zusätzlichen 17 % puffern hdiutil-Temp + UDF-Padding + Hintergrund.
#
# SPLIT_PIPELINE_PULL_VOLUME_SAFETY (× 1.5):
#   Pull-Volume im Split-Modus → nur 1× Pull-Daten + 0.5× Puffer.
#
# SPLIT_PIPELINE_ISO_VOLUME_SAFETY (× 2.5):
#   ISO-Volume im Split-Modus → 1× Staging + 1× ISO + 0.5× Puffer.
#   Ab 1.9.1 lebt Staging auf dem ISO-Volume (vorher in System-Temp,
#   was den Pre-Flight-Check umgangen hat → Disk-full mitten im Lauf).
LOCAL_WORKDIR_SAFETY = 2.5
REMOTE_PIPELINE_SAFETY = 3.5
SPLIT_PIPELINE_PULL_VOLUME_SAFETY = 1.5
SPLIT_PIPELINE_ISO_VOLUME_SAFETY = 2.5
# Backwards-compat-Alias: alter Name war single-purpose, neue Konstanten
# sind klarer. Hat aussen niemand benutzt, drinnen wird er nicht mehr
# referenziert — bleibt nur stehen für externe Skripte, die ihn pinnen.
SPLIT_PIPELINE_PER_VOLUME_SAFETY = SPLIT_PIPELINE_PULL_VOLUME_SAFETY


class WorkingDirectoryUnavailableError(RuntimeError):
    """Raised wenn kein Arbeitsverzeichnis mit genug Platz auffindbar ist.

    Trägt strukturierte Diagnose-Daten (1.10.0): Quell-Grösse, Safety-Faktor,
    pro-Kandidat Frei-/Benötigt-Bytes, Fallback-Konfigurations-Status. Die
    `__str__`-Repräsentation rendert daraus eine operator-freundliche
    Mehrzeilen-Meldung mit Footprint-Aufschlüsselung und Tipp.

    Attributes:
        source_bytes: Quell-Grösse in Byte (0 = unbekannt).
        safety_factor: Multiplikator, der zu `required_bytes` führte
            (z.B. 3.5 für REMOTE_PIPELINE_SAFETY).
        attempted: Liste `(label, path, free_bytes_or_None, problem)` pro
            geprüftem Kandidat. `free_bytes` ist `None`, wenn der Pfad
            gar nicht erreichbar war.
        required_bytes: berechnetes Gesamt-Required (= source × factor).
        is_rclone_source: True wenn rclone-Pipeline (Pull + Staging + ISO),
            False für lokale Quelle (Staging + ISO).
        has_fallback_configured: True wenn `working_directory_fallback` gesetzt.
    """

    def __init__(
        self,
        message: str = "",
        *,
        source_bytes: int = 0,
        safety_factor: float = 0.0,
        required_bytes: int = 0,
        attempted: "list[tuple[str, str, int | None, str]] | None" = None,
        is_rclone_source: bool = False,
        has_fallback_configured: bool = False,
    ) -> None:
        super().__init__(message or "Kein Arbeitsverzeichnis verfügbar")
        self.source_bytes = source_bytes
        self.safety_factor = safety_factor
        self.required_bytes = required_bytes
        self.attempted = attempted or []
        self.is_rclone_source = is_rclone_source
        self.has_fallback_configured = has_fallback_configured

    def __str__(self) -> str:
        # Wenn keine strukturierten Daten vorhanden → fallback auf args[0]
        if not self.source_bytes and not self.attempted:
            return super().__str__()

        lines: list[str] = []
        lines.append(
            "Kein Arbeitsverzeichnis mit ausreichend Platz für die "
            f"{'rclone-' if self.is_rclone_source else 'lokale '}Pipeline."
        )

        if self.attempted:
            lines.append("")
            lines.append("Geprüfte Kandidaten:")
            for label, path, free, problem in self.attempted:
                if free is None:
                    lines.append(f"   • {label} '{path}' — {problem}")
                else:
                    fehlt = max(self.required_bytes - free, 0)
                    lines.append(
                        f"   • {label} '{path}' — "
                        f"{_format_size(free)} frei, "
                        f"{_format_size(self.required_bytes)} benötigt "
                        f"(fehlt {_format_size(fehlt)})"
                    )

        # Footprint-Aufschlüsselung
        if self.source_bytes and self.safety_factor:
            lines.append("")
            lines.append(
                f"Pipeline-Footprint bei Quell-Grösse {_format_size(self.source_bytes)} "
                f"× {self.safety_factor:.1f}:"
            )
            src = self.source_bytes
            if self.is_rclone_source:
                lines.append(f"   = Pull (1.0× = {_format_size(src)})")
                lines.append(f"   + Staging (1.0× = {_format_size(src)})")
                lines.append(f"   + ISO (1.0× = {_format_size(src)})")
                puffer_x = self.safety_factor - 3.0
            else:
                lines.append(f"   = Staging (1.0× = {_format_size(src)})")
                lines.append(f"   + ISO (1.0× = {_format_size(src)})")
                puffer_x = self.safety_factor - 2.0
            if puffer_x > 0:
                lines.append(
                    f"   + Puffer ({puffer_x:.1f}× = {_format_size(int(src * puffer_x))})"
                )
            lines.append(
                f"   → Total: {_format_size(self.required_bytes)}"
            )

        # Tipp je nach Situation
        lines.append("")
        if not self.has_fallback_configured:
            lines.append(
                "Tipp: zusätzliches Working-Dir auf einer grösseren Disk "
                "konfigurieren:"
            )
            lines.append(
                "   kamera-einleser config set working_directory_fallback "
                "/Volumes/.../Kamera-Einleser"
            )
        else:
            lines.append(
                "Tipp: Working-Dir aufräumen oder Fallback freischaufeln. "
                "`kamera-einleser cache list` zeigt alte ISOs zum Löschen."
            )

        return "\n".join(lines)


def _format_size(num_bytes: int) -> str:
    """Kompakter Bytes-Formatter (lokale Kopie, um Zirkular-Import zu vermeiden)."""
    size = float(num_bytes)
    for unit in ["B", "KiB", "MiB", "GiB", "TiB"]:
        if size < 1024:
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} {unit}"
        size /= 1024
    return f"{size:.1f} PiB"


def _xdg_config_home() -> Path:
    """Gibt `$XDG_CONFIG_HOME` zurück, Fallback `~/.config`."""
    value = os.environ.get("XDG_CONFIG_HOME")
    if value:
        return Path(value)
    return Path.home() / ".config"


def _xdg_data_home() -> Path:
    """Gibt `$XDG_DATA_HOME` zurück, Fallback `~/.local/share`.

    Für persistente Daten (Checksum-Index), getrennt von der Config.
    """
    value = os.environ.get("XDG_DATA_HOME")
    if value:
        return Path(value)
    return Path.home() / ".local" / "share"


def default_checksum_index_path() -> Path:
    """Primärer Pfad der Checksum-Index-Datei (XDG-konform).

    Liegt bewusst **nicht** im Working-Dir — der Index ist eine stabile
    Datenbank, nicht ein Working-File. Damit bleibt er zugänglich, auch
    wenn das Working-Dir auf einer externen SSD liegt, die gerade nicht
    angeschlossen ist.
    """
    return _xdg_data_home() / APP_SLUG / "checksum_index.csv"


def default_config_path() -> Path:
    """Primärer Pfad der Konfigurationsdatei (TOML, XDG-konform)."""
    return _xdg_config_home() / APP_SLUG / "config.toml"


def legacy_yaml_paths() -> list[Path]:
    """Kandidaten-Pfade für die alte YAML-Konfiguration (Migrations-Quellen)."""
    return [_xdg_config_home() / APP_SLUG / "config.yaml"]


# Rückwärtskompatibler Modul-Level-Alias
DEFAULT_CONFIG_PATH = default_config_path()


def strip_quotes(value: str) -> str:
    """
    Remove leading and trailing quotes from a string.

    Handles both single (') and double (") quotes, including multiple layers.

    Args:
        value: String that may contain quotes

    Returns:
        String with quotes removed
    """
    if not value:
        return value

    # Strip both types of quotes repeatedly until no more quotes are found
    while value and value[0] in ("'", '"') and value[-1] in ("'", '"'):
        value = value[1:-1]

    return value


class Config:
    """Configuration manager for kamera-einleser."""

    def __init__(self, config_path: Path | None = None):
        """
        Initialize the configuration manager.

        Args:
            config_path: Path to the configuration file. If None, uses the
                XDG-konforme TOML-Default.
        """
        self.config_path = config_path or default_config_path()
        self._config: dict[str, Any] = {}
        self._migrated_from: Path | None = None
        self.load()

    def load(self) -> None:
        """Konfiguration laden.

        Reihenfolge:
        1. TOML-Datei unter `self.config_path` (falls vorhanden)
        2. YAML-Datei mit gleichem Stamm (wenn TOML-Endung explizit erwartet)
        3. Legacy-YAML-Pfade (nur wenn `self.config_path` der Default ist)
        4. Defaults
        """
        loaded: dict[str, Any] | None = None

        if self.config_path.exists():
            loaded = self._load_file(self.config_path)
        else:
            # Geschwister-YAML mit gleichem Stamm (z.B. bei config_path=...config.toml)
            sibling_yaml = self.config_path.with_suffix(".yaml")
            if sibling_yaml.exists():
                loaded = self._load_file(sibling_yaml)
                self._migrated_from = sibling_yaml
            elif self.config_path == default_config_path():
                for legacy in legacy_yaml_paths():
                    if legacy.exists():
                        loaded = self._load_file(legacy)
                        self._migrated_from = legacy
                        break

        if loaded is None:
            self._config = copy.deepcopy(DEFAULT_CONFIG)
            return

        # Auto-Cleanup ab 1.7.0: nur bekannte Felder übernehmen (Legacy-
        # Reste wie archive_directories/restore_directory/auto_mount/
        # current_archive_directory werden beim nächsten save() aus der
        # Datei entfernt).
        self._config = copy.deepcopy(DEFAULT_CONFIG)
        for key, value in loaded.items():
            if key in DEFAULT_CONFIG:
                self._config[key] = value
        self._normalize_directory_list("source_directories")

        # Auto-Cleanup pro rclone-Target: smb_url war nur für das entfernte
        # SMB-Mount-Feature nötig. Wird stillschweigend ausgefiltert.
        cleaned_targets: list[dict[str, Any]] = []
        for t in self._config.get("rclone_targets", []):
            if not isinstance(t, dict):
                continue
            cleaned_targets.append(
                {k: v for k, v in t.items() if k != "smb_url"}
            )
        self._config["rclone_targets"] = cleaned_targets

        # Auto-Migration: wenn Daten aus einer YAML-Quelle stammen, TOML
        # schreiben und die YAML-Datei als .bak sichern.
        if self._migrated_from is not None:
            self._perform_migration()

    def _load_file(self, path: Path) -> dict[str, Any]:
        """Lädt YAML oder TOML anhand der Dateiendung."""
        if path.suffix == ".toml":
            with open(path, "rb") as f:
                return tomllib.load(f) or {}
        # Default: YAML (auch für .yml, leere Endung)
        with open(path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def _perform_migration(self) -> None:
        """Schreibt TOML und sichert die YAML-Quelle als `.bak`."""
        assert self._migrated_from is not None
        source = self._migrated_from
        self.save()
        backup = source.with_suffix(source.suffix + ".bak")
        try:
            source.replace(backup)
        except OSError:
            # Migration darf nie fatal sein — Logs im CLI-Layer
            pass

    def _normalize_directory_list(self, config_key: str) -> None:
        """
        Normalize a directory list to ensure all entries are strings.

        Args:
            config_key: The config key for the directory list to normalize
        """
        directories = self._config.get(config_key, [])
        if not directories:
            return

        normalized = []
        for item in directories:
            if isinstance(item, dict):
                # Handle legacy format where entries might be dicts with 'path' key
                path = str(item.get("path", ""))
                if path:  # Only add non-empty paths
                    normalized.append(path)
            elif isinstance(item, str):
                if item:  # Only add non-empty strings
                    normalized.append(item)
            elif item:  # Any other non-empty type
                normalized.append(str(item))

        self._config[config_key] = normalized

    def save(self) -> None:
        """Konfiguration persistieren.

        Format wird über die Dateiendung bestimmt:
        - `.toml` (neu, Default): tomli_w
        - `.yaml` / `.yml` (Legacy): PyYAML — nur für Tests/Rückwärts­kompatibilität
        """
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        if self.config_path.suffix == ".toml":
            with open(self.config_path, "wb") as f:
                tomli_w.dump(_sanitize_for_toml(self._config), f)
        else:
            with open(self.config_path, "w", encoding="utf-8") as f:
                yaml.dump(self._config, f, default_flow_style=False, allow_unicode=True)

    # --- Generisches Schlüssel-Interface (für `config set/get/list`) ---

    def list_all(self) -> dict[str, Any]:
        """Gibt eine Kopie der aktuellen Konfiguration zurück."""
        return copy.deepcopy(self._config)

    def get_value(self, key: str) -> Any:
        """Liefert den Wert eines bekannten Config-Schlüssels."""
        if key not in DEFAULT_CONFIG:
            raise KeyError(f"Unbekannter Config-Schlüssel: {key}")
        return self._config.get(key, DEFAULT_CONFIG[key])

    def set_value(self, key: str, value: str) -> Any:
        """Setzt einen bekannten Config-Schlüssel; castet den Wert auf den Default-Typ.

        Listen-/Dict-Felder müssen über ihre dedizierten add_/remove_-Methoden
        gepflegt werden — hier absichtlich `TypeError`, um Daten-Verlust zu
        vermeiden.
        """
        if key not in DEFAULT_CONFIG:
            raise KeyError(f"Unbekannter Config-Schlüssel: {key}")

        default_value = DEFAULT_CONFIG[key]
        if isinstance(default_value, (list, dict)):
            raise TypeError(
                f"Der Schlüssel '{key}' ist strukturiert — bitte die "
                "entsprechenden add_/remove_-Befehle verwenden."
            )

        coerced: Any
        if isinstance(default_value, bool):
            coerced = _parse_bool(value)
        elif isinstance(default_value, int):
            coerced = int(value)
        else:
            coerced = strip_quotes(value)

        self._config[key] = coerced
        return coerced

    # Source directories
    def get_source_directories(self) -> list[str]:
        """Get list of source directories."""
        return self._config.get("source_directories", [])

    def set_source_directories(self, directories: list[str]) -> None:
        """Set list of source directories."""
        self._config["source_directories"] = [strip_quotes(d) for d in directories]

    def add_source_directory(self, directory: str) -> bool:
        """Add a source directory if it doesn't exist."""
        directory = strip_quotes(directory)
        dirs = self.get_source_directories()
        if directory not in dirs:
            dirs.append(directory)
            self._config["source_directories"] = dirs
            return True
        return False

    def remove_source_directory(self, directory: str) -> bool:
        """Remove a source directory."""
        dirs = self.get_source_directories()
        if directory in dirs:
            dirs.remove(directory)
            self._config["source_directories"] = dirs
            return True
        return False

    # rclone targets
    def get_rclone_targets(self) -> list[dict[str, Any]]:
        """
        Get list of rclone targets in order.
        Each target is a dict with 'name' and 'path' keys.
        """
        return self._config.get("rclone_targets", [])

    def set_rclone_targets(self, targets: list[dict[str, Any]]) -> None:
        """Set list of rclone targets."""
        self._config["rclone_targets"] = targets

    def add_rclone_target(self, name: str, path: str, position: int | None = None) -> bool:
        """
        Add an rclone target.

        Args:
            name: Display name for the target
            path: rclone target path (e.g., 'nas:/backups')
            position: Position in the list (None = append at end)
        """
        path = strip_quotes(path)
        targets = self.get_rclone_targets()
        target = {"name": name, "path": path}

        # Check if target with same path already exists
        for t in targets:
            if t.get("path") == path:
                return False

        if position is None:
            targets.append(target)
        else:
            targets.insert(position, target)

        self._config["rclone_targets"] = targets
        return True

    def remove_rclone_target(self, path: str) -> bool:
        """Remove an rclone target by path."""
        targets = self.get_rclone_targets()
        for i, t in enumerate(targets):
            if t.get("path") == path:
                targets.pop(i)
                self._config["rclone_targets"] = targets
                return True
        return False

    def update_rclone_target(self, index: int, name: str, path: str) -> bool:
        """
        Update an existing rclone target.

        Args:
            index: Index of the target to update
            name: New name for the target
            path: New path for the target

        Returns:
            True if successful, False otherwise
        """
        path = strip_quotes(path)
        targets = self.get_rclone_targets()
        if 0 <= index < len(targets):
            targets[index] = {"name": name, "path": path}
            self._config["rclone_targets"] = targets
            return True
        return False

    def move_rclone_target(self, path: str, direction: int) -> bool:
        """
        Move an rclone target up or down in the list.

        Args:
            path: rclone target path to move
            direction: -1 to move up, 1 to move down
        """
        targets = self.get_rclone_targets()
        for i, t in enumerate(targets):
            if t.get("path") == path:
                new_pos = i + direction
                if 0 <= new_pos < len(targets):
                    targets.pop(i)
                    targets.insert(new_pos, t)
                    self._config["rclone_targets"] = targets
                    return True
                return False
        return False

    # Working directory
    def get_working_directory(self) -> str:
        """Get the working directory for ISO archive creation."""
        return self._config.get("working_directory", "")

    def set_working_directory(self, directory: str) -> None:
        """Set the working directory for ISO archive creation."""
        self._config["working_directory"] = strip_quotes(directory)

    def get_working_directory_fallback(self) -> str:
        """Sekundäres Arbeitsverzeichnis (z.B. externe SSD).

        Wird genutzt, wenn das primäre Arbeitsverzeichnis nicht gemountet ist
        oder zu wenig Platz hat.
        """
        return self._config.get("working_directory_fallback", "")

    def set_working_directory_fallback(self, directory: str) -> None:
        self._config["working_directory_fallback"] = strip_quotes(directory)

    def get_effective_working_directory(self) -> Path:
        """Get the effective working directory, using temp dir if not configured."""
        working_dir = self.get_working_directory()
        if working_dir:
            return Path(working_dir)
        # Default to system temp directory
        import tempfile

        return Path(tempfile.gettempdir())

    def resolve_working_directory(
        self,
        required_bytes: int,
        *,
        is_rclone_source: bool = False,
        source_bytes_for_error: int = 0,
        safety_factor_for_error: float = 0.0,
    ) -> Path:
        """Liefert ein Arbeitsverzeichnis, das existiert und Platz hat.

        Reihenfolge:
        1. `working_directory`, wenn erreichbar und `free >= required_bytes`
        2. `working_directory_fallback`, wenn erreichbar und `free >= required_bytes`
        3. System-Temp — **nur** bei lokalen Quellen
        4. Sonst `WorkingDirectoryUnavailableError`

        Für rclone-Quellen ist Schritt 3 bewusst ausgeschlossen: System-Temp
        kann auf macOS im RAM liegen und 200+ GB Pull sprengt das System.

        Args:
            required_bytes: Benötigter Platz (inkl. Puffer) in Byte.
            is_rclone_source: True für rclone-Quellen (kein Temp-Fallback).
            source_bytes_for_error: Quell-Grösse für die Footprint-Aufschlüsselung
                in der Fehlermeldung (1.10.0). Wird nur bei Exception genutzt.
            safety_factor_for_error: Verwendeter Safety-Multiplikator
                (z.B. 3.5). Wird nur bei Exception genutzt.

        Raises:
            WorkingDirectoryUnavailableError: wenn kein Pfad passt.
        """
        candidates: list[tuple[str, str]] = []
        primary = self.get_working_directory()
        if primary:
            candidates.append(("primär", primary))
        fallback = self.get_working_directory_fallback()
        if fallback:
            candidates.append(("fallback", fallback))

        # Strukturierte Diagnose für die Exception (1.10.0).
        # Tuple = (label, path_str, free_bytes_or_None, problem_text)
        attempted: list[tuple[str, str, int | None, str]] = []
        for label, raw in candidates:
            path = Path(raw).expanduser()
            # Nur ein Level nach oben — für externe SSDs muss der Mount-Point
            # (z.B. /Volumes/Samsung2TB) existieren, den Sub-Ordner legen wir an.
            probe = path if path.exists() else path.parent
            if not probe.exists():
                attempted.append((label, str(path), None, "Pfad nicht erreichbar"))
                continue
            free = shutil.disk_usage(probe).free
            if free < required_bytes:
                attempted.append((label, str(path), free, "zu wenig Platz"))
                continue
            path.mkdir(parents=True, exist_ok=True)
            return path

        if not is_rclone_source:
            return self.get_effective_working_directory()

        raise WorkingDirectoryUnavailableError(
            source_bytes=source_bytes_for_error,
            safety_factor=safety_factor_for_error,
            required_bytes=required_bytes,
            attempted=attempted,
            is_rclone_source=is_rclone_source,
            has_fallback_configured=bool(fallback),
        )

    def resolve_split_pipeline(
        self,
        source_bytes: int,
        *,
        is_rclone_source: bool = False,
    ) -> tuple[Path, Path]:
        """Wählt zwei Pfade für die Pipeline: `(pull_dir, iso_dir)`.

        **Split-Modus** (Primary UND Fallback verfügbar mit jeweils
        `~1.5× source_bytes` frei):
            pull_dir  = Primary  (typisch: schnelle interne SSD)
            iso_dir   = Fallback (typisch: grosse externe SSD)
            → entkoppelt Pull-Lese vom ISO-Schreib-Pfad, beide Volumes
              brauchen je nur `1.5×` statt zusammen `3.5×`.

        **Single-Volume-Modus** (Fallback wenn Split nicht möglich):
            Routes via `resolve_working_directory(source_bytes × full_factor)`.
            Returns `(single, single)` — pull und iso landen am selben Ort.

        Args:
            source_bytes: Quell-Grösse in Byte (vom Caller ermittelt, z.B.
                via `rclone size --json` oder `calculate_directory_size`).
            is_rclone_source: True für rclone-Quellen (Single-Volume nutzt
                dann `REMOTE_PIPELINE_SAFETY × 3.5`); False für lokale
                Quellen (`LOCAL_WORKDIR_SAFETY × 2.5`).

        Raises:
            WorkingDirectoryUnavailableError: rclone-Quelle und kein
                geeignetes Volume gefunden.
        """
        # 1.9.1: Split-Modus prüft ASYMMETRISCH: Pull-Volume nur 1.5×
        # (reine Pull-Daten + Puffer), ISO-Volume 2.5× (Staging + ISO +
        # Puffer). Vorher beides 1.5× — fiel auf, weil Staging in
        # System-Temp lag und den Pre-Flight umging.
        pull_required = int(source_bytes * SPLIT_PIPELINE_PULL_VOLUME_SAFETY)
        iso_required = int(source_bytes * SPLIT_PIPELINE_ISO_VOLUME_SAFETY)

        primary_str = self.get_working_directory()
        fallback_str = self.get_working_directory_fallback()

        if primary_str and fallback_str:
            primary = Path(primary_str).expanduser()
            fallback = Path(fallback_str).expanduser()
            if self._volume_has_space(
                primary, pull_required
            ) and self._volume_has_space(fallback, iso_required):
                primary.mkdir(parents=True, exist_ok=True)
                fallback.mkdir(parents=True, exist_ok=True)
                return primary, fallback

        # Single-Volume-Fallback
        full_factor = (
            REMOTE_PIPELINE_SAFETY if is_rclone_source else LOCAL_WORKDIR_SAFETY
        )
        single = self.resolve_working_directory(
            int(source_bytes * full_factor),
            is_rclone_source=is_rclone_source,
            source_bytes_for_error=source_bytes,
            safety_factor_for_error=full_factor,
        )
        return single, single

    def _volume_has_space(self, path: Path, required_bytes: int) -> bool:
        """Helper für `resolve_split_pipeline`: prüft Mount + Freiplatz."""
        probe = path if path.exists() else path.parent
        if not probe.exists():
            return False
        return shutil.disk_usage(probe).free >= required_bytes

    # Archive settings
    def get_archive_split_size_bytes(self) -> int:
        """Get the archive split size in bytes (legacy, kept for compatibility)."""
        return self._config.get("archive_split_size_bytes", 20_000_000_000)

    def set_archive_split_size_bytes(self, size: int) -> None:
        """Set the archive split size in bytes (legacy, kept for compatibility)."""
        self._config["archive_split_size_bytes"] = size

    # ISO-Cache-Limit (ab 1.8.0)
    def get_iso_cache_max_bytes(self) -> int:
        """Obergrenze für den lokalen ISO-Cache in Byte.

        Ist sie überschritten, prunt `cache_ops.prune_local_iso_cache`
        die ältesten bereits-im-Index-indizierten ISOs. `0` deaktiviert
        das Limit.
        """
        return self._config.get("iso_cache_max_bytes", 500_000_000_000)

    # Excludes
    def get_excludes(self) -> list[str]:
        """Get list of exclude patterns for rclone and archiving."""
        return self._config.get("excludes", ["._*", ".DS_Store"])

    def set_excludes(self, excludes: list[str]) -> None:
        """Set list of exclude patterns."""
        self._config["excludes"] = excludes

    def is_configured(self) -> bool:
        """Check if the configuration has at least one source and one target."""
        return bool(self.get_source_directories()) and bool(self.get_rclone_targets())

    # Checksum index path
    def get_checksum_index_path(self) -> Path:
        """Pfad zur Checksum-Index-CSV.

        Reihenfolge:
        1. `checksum_index_path` explizit in der Config → verwenden (Escape-Hatch
           für User mit abweichender Struktur).
        2. Neuer Default unter `$XDG_DATA_HOME/kamera-einleser/checksum_index.csv`.
           Wenn die Datei dort existiert → diesen Pfad.
        3. Auto-Migration: existiert die Datei noch am alten Ort
           (`{working_directory}/checksum_index.csv`)? Falls ja, verschieben
           wir sie einmalig auf den neuen Pfad.
        4. Return neuer Default (Datei ggf. nicht existent — `load_index`
           behandelt das als leeren Index).
        """
        configured_path = self._config.get("checksum_index_path", "")
        if configured_path:
            return Path(strip_quotes(configured_path))

        new_default = default_checksum_index_path()
        if new_default.exists():
            return new_default

        # Einmalige Migration vom Working-Dir-Standort
        legacy_path = self.get_effective_working_directory() / "checksum_index.csv"
        if legacy_path.exists() and legacy_path != new_default:
            try:
                new_default.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(legacy_path), str(new_default))
            except OSError:
                # Migration darf nie fatal sein; bei Misserfolg alten Pfad
                # weiter benutzen.
                return legacy_path

        return new_default


# Global configuration instance
_config: Config | None = None


def get_config(config_path: Path | None = None) -> Config:
    """Get the global configuration instance."""
    global _config
    if _config is None or (config_path is not None and _config.config_path != config_path):
        _config = Config(config_path)
    return _config


def _parse_bool(raw: str) -> bool:
    truthy = {"1", "true", "yes", "on", "ja"}
    falsy = {"0", "false", "no", "off", "nein"}
    value = raw.strip().lower()
    if value in truthy:
        return True
    if value in falsy:
        return False
    raise ValueError(f"Boolean erwartet (true/false), erhalten: {raw!r}")


def _sanitize_for_toml(data: dict[str, Any]) -> dict[str, Any]:
    """TOML erlaubt keine `None`-Werte — durch leere Strings ersetzen."""
    return {k: ("" if v is None else v) for k, v in data.items()}
