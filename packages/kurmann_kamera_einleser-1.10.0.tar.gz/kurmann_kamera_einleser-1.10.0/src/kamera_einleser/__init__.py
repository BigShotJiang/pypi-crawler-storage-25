"""Kamera-Einleser: Einfacher & solider Medien-Importeur."""

from importlib.metadata import PackageNotFoundError, version

from .models import (
    ArchiveEvents,
    ArchiveRequest,
    ArchiveResult,
    LocalSource,
    RcloneSource,
    RuntimeOptions,
    SourceKind,
    SourceRef,
)

try:
    __version__ = version("kurmann-kamera-einleser")
except PackageNotFoundError:
    try:
        __version__ = version("kamera-einleser")
    except PackageNotFoundError:
        __version__ = "0.0.0+unknown"

__all__ = [
    "__version__",
    "ArchiveEvents",
    "ArchiveRequest",
    "ArchiveResult",
    "LocalSource",
    "RcloneSource",
    "RuntimeOptions",
    "SourceKind",
    "SourceRef",
]
