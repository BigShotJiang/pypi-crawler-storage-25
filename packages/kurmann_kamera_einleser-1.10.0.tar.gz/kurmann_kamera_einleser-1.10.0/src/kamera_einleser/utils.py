"""Shared utility functions for kamera-einleser."""

from fnmatch import fnmatch


def format_size(size_bytes: int) -> str:
    """Format bytes into human-readable string.

    Uses binary units (GiB, MiB, KiB) for accurate representation
    of file and disk sizes based on powers of 1024.

    Args:
        size_bytes: Size in bytes

    Returns:
        Human-readable size string
    """
    if size_bytes >= 1024**3:
        return f"{size_bytes / (1024**3):.2f} GiB"
    elif size_bytes >= 1024**2:
        return f"{size_bytes / (1024**2):.2f} MiB"
    elif size_bytes >= 1024:
        return f"{size_bytes / 1024:.2f} KiB"
    return f"{size_bytes} Bytes"


def should_exclude(filename: str, excludes: list[str]) -> bool:
    """Check if a filename matches any of the exclude patterns.

    Args:
        filename: The filename to check (just the name, not the full path)
        excludes: List of glob patterns to exclude (e.g. ['._*', '.DS_Store'])

    Returns:
        True if the filename matches any exclude pattern, False otherwise
    """
    for pattern in excludes:
        if fnmatch(filename, pattern):
            return True
    return False
