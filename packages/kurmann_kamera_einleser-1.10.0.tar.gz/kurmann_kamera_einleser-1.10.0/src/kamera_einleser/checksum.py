"""Checksum index management for ISO archives."""

import csv
import hashlib
import unicodedata
from pathlib import Path


def compute_sha256(file_path: Path) -> str:
    """
    Compute SHA-256 hash of a file.

    Reads the file in chunks to efficiently handle large video files.

    Args:
        file_path: Path to the file to hash

    Returns:
        SHA-256 hash as hexadecimal string
    """
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        # Read in 64KB chunks for efficient processing
        for chunk in iter(lambda: f.read(65536), b""):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()


def load_index(csv_path: Path) -> dict[str, dict]:
    """
    Load the checksum index from a CSV file.

    Args:
        csv_path: Path to the CSV file

    Returns:
        Dictionary with SHA-256 hash as key and dict with 'dateiname',
        'iso_name', 'relativer_pfad' as value. Empty dict if file doesn't exist.
    """
    if not csv_path.exists():
        return {}

    index = {}
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            sha256 = row.get("sha256", "")
            if sha256:
                index[sha256] = {
                    "dateiname": row.get("dateiname", ""),
                    "iso_name": row.get("iso_name", ""),
                    "relativer_pfad": row.get("relativer_pfad", ""),
                }
    return index


def filenames_indexed_for_day(index: dict[str, dict], day_key: str) -> set[str]:
    """Dateinamen im Index, deren ISO-Name zum angegebenen Tag gehört.

    Das schliesst `Originalmedien-YYYY-MM-DD.iso` und alle `-Teil-N`-Varianten
    ein. Verglichen wird NFC-normalisiert, damit macOS-Umlaute (NFD) mit
    Linux/NAS-Resultaten (NFC) matchen.

    Args:
        index: Das via `load_index()` geladene Dict.
        day_key: Datum im Format `YYYY-MM-DD`.

    Returns:
        Set aller NFC-normalisierten Dateinamen aus dem Index für diesen Tag.
    """
    prefix = f"Originalmedien-{day_key}"
    result: set[str] = set()
    for entry in index.values():
        iso_name = entry.get("iso_name", "")
        if not iso_name:
            continue
        # Exakter Tag oder -Teil-N-Fortsetzung
        if iso_name == f"{prefix}.iso" or iso_name.startswith(f"{prefix}-Teil-"):
            name = entry.get("dateiname", "")
            if name:
                result.add(unicodedata.normalize("NFC", name))
    return result


def all_indexed_filenames(index: dict[str, dict]) -> set[str]:
    """Alle `dateiname`-Werte aus dem Index, NFC-normalisiert.

    Wird für den rclone-Pre-Filter beim Pull von Netzlaufwerk-Quellen genutzt:
    alles, was hier enthalten ist, ist bereits in mindestens einer archivierten
    ISO und muss nicht erneut über das Netz gezogen werden.
    """
    result: set[str] = set()
    for entry in index.values():
        name = entry.get("dateiname", "")
        if name:
            result.add(unicodedata.normalize("NFC", name))
    return result


def prune_index_entries(csv_path: Path, iso_names: set[str]) -> int:
    """Entfernt alle Zeilen aus dem Index, deren `iso_name` in der Menge liegt.

    Schreibt die Datei atomisch (Temp-File + `os.replace`) zurück, damit ein
    Abbruch während des Schreibens den Index nicht zerstört.

    Args:
        csv_path: Pfad zur CSV-Index-Datei.
        iso_names: Set der ISO-Namen, die entfernt werden sollen.

    Returns:
        Anzahl entfernter Zeilen. 0, wenn die Datei nicht existiert oder nichts
        zu entfernen war.
    """
    import os
    import tempfile

    if not csv_path.exists() or not iso_names:
        return 0

    with open(csv_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or [
            "sha256",
            "dateiname",
            "iso_name",
            "relativer_pfad",
        ]
        rows = list(reader)

    kept = [r for r in rows if r.get("iso_name", "") not in iso_names]
    removed = len(rows) - len(kept)
    if removed == 0:
        return 0

    tmp_fd, tmp_path = tempfile.mkstemp(
        prefix=".checksum-index.", suffix=".tmp", dir=str(csv_path.parent)
    )
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(kept)
        os.replace(tmp_path, csv_path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise

    return removed


def get_iso_names_from_index(index: dict[str, dict]) -> set[str]:
    """
    Extract unique ISO names from a loaded checksum index.

    Args:
        index: Checksum index dictionary returned by load_index()

    Returns:
        Set of unique ISO filenames found in the index
    """
    iso_names: set[str] = set()
    for entry in index.values():
        iso_name = entry.get("iso_name", "")
        if iso_name:
            iso_names.add(iso_name)
    return iso_names


def append_to_index(csv_path: Path, entries: list[dict]) -> None:
    """
    Append new entries to the checksum index CSV file.

    Creates the file with header if it doesn't exist yet.

    Args:
        csv_path: Path to the CSV file
        entries: List of dicts with keys: 'sha256', 'dateiname', 'iso_name', 'relativer_pfad'
    """
    file_exists = csv_path.exists()

    # Ensure parent directory exists
    csv_path.parent.mkdir(parents=True, exist_ok=True)

    with open(csv_path, "a", encoding="utf-8", newline="") as f:
        fieldnames = ["sha256", "dateiname", "iso_name", "relativer_pfad"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)

        # Write header if file is new
        if not file_exists:
            writer.writeheader()

        # Write all entries
        writer.writerows(entries)


def index_iso_files(iso_mount_path: Path, iso_name: str) -> list[dict]:
    """
    Index all files in a mounted ISO archive.

    Args:
        iso_mount_path: Path to the mounted ISO
        iso_name: Name of the ISO file (e.g., 'Originalmedien-2026-01-15.iso')

    Returns:
        List of dicts ready to be appended to the index, each with keys:
        'sha256', 'dateiname', 'iso_name', 'relativer_pfad'
    """
    entries = []

    for item in iso_mount_path.rglob("*"):
        if not item.is_file():
            continue

        # Skip hidden files and macOS metadata files
        filename = item.name
        if filename.startswith(".") or filename.startswith("._"):
            continue

        try:
            # Compute hash
            sha256 = compute_sha256(item)

            # Get relative path within the ISO
            rel_path = item.relative_to(iso_mount_path)

            entries.append(
                {
                    "sha256": sha256,
                    "dateiname": filename,
                    "iso_name": iso_name,
                    "relativer_pfad": str(rel_path),
                }
            )
        except (OSError, ValueError):
            # Skip files that can't be read or processed
            continue

    return entries
