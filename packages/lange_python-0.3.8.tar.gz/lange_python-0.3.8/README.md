# lange-python

Python helpers and clients for Lange services.

## Distribution CLI

Publish a distribution artifact to the app services distribution system:

```bash
export LANGE_LABS_API_KEY="your-api-key"
lange distribution publish \
  --path ./dist/app.dmg \
  --version 1.2.3 \
  --distribution-name desktop-app \
  --os macos
```

Apply a macOS app update after downloading the published zip artifact:

```python
from pathlib import Path

from lange.distribution import DistributionClient

client = DistributionClient(distribution_name="desktop-app", api_key="your-api-key")

update_metadata = client.update(
    current_version="1.2.3",
    installed_app_path=Path("/Applications/Desktop App.app"),
)

print(update_metadata["version"])
# The caller should now shut down so the detached helper can replace the app bundle.
```

## Tunnel worker

```python
from lange.tunnel import Tunnel

tunnel = Tunnel(
    host="wss://tunnel.lange-labs.com",
    api_key="your-bearer-token",
    target="http://localhost:3000",
)

tunnel.start()
# ...
tunnel.stop()
```
