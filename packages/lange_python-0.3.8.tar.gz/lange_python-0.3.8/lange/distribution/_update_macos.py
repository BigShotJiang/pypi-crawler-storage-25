"""macOS-specific helpers for the distribution update workflow."""

from __future__ import annotations

import shutil
import stat
import subprocess
import zipfile
from pathlib import Path
from shlex import quote


def extract_macos_app_from_zip(archive_path: str | Path) -> Path:
    """
    Extract a macOS update archive and return the only top-level ``.app`` bundle.

    :param archive_path: Path to the downloaded zip archive.
    :returns: Absolute path to the extracted ``.app`` bundle.
    :raises ValueError: If the archive is not a zip or does not contain exactly one top-level app bundle.
    """
    normalized_archive_path = Path(archive_path).expanduser().resolve()

    if normalized_archive_path.suffix.lower() != ".zip":
        raise ValueError("macOS update artifacts must be .zip files.")

    destination_path = normalized_archive_path.parent / "extracted"
    if destination_path.exists():
        shutil.rmtree(destination_path)
    destination_path.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(normalized_archive_path) as archive:
        archive.extractall(destination_path)

    app_bundles = [
        child.resolve()
        for child in destination_path.iterdir()
        if child.is_dir() and child.suffix == ".app"
    ]

    if len(app_bundles) != 1:
        raise ValueError("macOS update archives must contain exactly one top-level .app bundle.")

    return app_bundles[0]


def spawn_macos_update_process(
    *,
    source_app_path: str | Path,
    installed_app_path: str | Path,
    current_process_id: int,
    workspace_path: str | Path,
    wait_for_exit_timeout: float,
) -> dict[str, str]:
    """
    Generate and launch the detached macOS helper process that applies the update.

    :param source_app_path: Extracted replacement app bundle.
    :param installed_app_path: Installed app bundle that should be replaced.
    :param current_process_id: PID that must exit before replacement begins.
    :param workspace_path: Temporary workspace for helper files and logs.
    :param wait_for_exit_timeout: Maximum number of seconds to wait for the PID to exit.
    :returns: Metadata about the spawned helper process and generated files.
    :raises RuntimeError: If the helper process could not be launched.
    """
    normalized_source_app_path = Path(source_app_path).expanduser().resolve()
    normalized_installed_app_path = Path(installed_app_path).expanduser().resolve()
    normalized_workspace_path = Path(workspace_path).expanduser().resolve()

    normalized_workspace_path.mkdir(parents=True, exist_ok=True)

    backup_app_path = normalized_installed_app_path.parent / f"{normalized_installed_app_path.name}.previous"
    script_path = normalized_workspace_path / "apply-update.sh"
    log_path = normalized_workspace_path / "apply-update.log"
    script_contents = _build_macos_update_script(
        source_app_path=normalized_source_app_path,
        installed_app_path=normalized_installed_app_path,
        backup_app_path=backup_app_path,
        current_process_id=current_process_id,
        wait_for_exit_timeout=wait_for_exit_timeout,
    )

    script_path.write_text(script_contents, encoding="utf-8")
    current_mode = script_path.stat().st_mode
    script_path.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    with log_path.open("ab") as log_file:
        try:
            process = subprocess.Popen(
                ["/bin/bash", str(script_path)],
                stdout=log_file,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
        except OSError as error:
            raise RuntimeError(f"Failed to launch the macOS updater helper process: {error}") from error

    return {
        "script_path": str(script_path),
        "log_path": str(log_path),
        "process_id": str(process.pid),
    }


def _build_macos_update_script(
    *,
    source_app_path: Path,
    installed_app_path: Path,
    backup_app_path: Path,
    current_process_id: int,
    wait_for_exit_timeout: float,
) -> str:
    """
    Build the shell script that applies the macOS app replacement with rollback.

    :param source_app_path: Extracted replacement app bundle.
    :param installed_app_path: Installed app bundle that should be replaced.
    :param backup_app_path: Temporary backup location used for rollback.
    :param current_process_id: PID that must exit before replacement begins.
    :param wait_for_exit_timeout: Maximum number of seconds to wait for the PID to exit.
    :returns: Shell script source code.
    """
    timeout_seconds = max(int(wait_for_exit_timeout), 0)

    return f"""#!/bin/bash
set -euo pipefail

SOURCE_APP={quote(str(source_app_path))}
TARGET_APP={quote(str(installed_app_path))}
BACKUP_APP={quote(str(backup_app_path))}
TARGET_PID={int(current_process_id)}
TIMEOUT_SECONDS={timeout_seconds}
WAITED_SECONDS=0

restore_backup() {{
  if [ -d "$BACKUP_APP" ]; then
    rm -rf "$TARGET_APP"
    mv "$BACKUP_APP" "$TARGET_APP"
  fi
}}

while kill -0 "$TARGET_PID" 2>/dev/null; do
  if [ "$WAITED_SECONDS" -ge "$TIMEOUT_SECONDS" ]; then
    echo "Timed out waiting for process $TARGET_PID to exit."
    exit 1
  fi
  sleep 1
  WAITED_SECONDS=$((WAITED_SECONDS + 1))
done

rm -rf "$BACKUP_APP"

trap 'restore_backup' ERR

if [ -d "$TARGET_APP" ]; then
  mv "$TARGET_APP" "$BACKUP_APP"
fi

/usr/bin/ditto "$SOURCE_APP" "$TARGET_APP"
rm -rf "$BACKUP_APP"
"""
