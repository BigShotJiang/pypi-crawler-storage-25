from setuptools import setup, find_packages

setup(
    packages=find_packages(),
    package_data={'qvac': ['bin/*.dll']},
    include_package_data=True,
)
