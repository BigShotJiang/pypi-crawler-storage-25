"""
QVAC Virtual Camera - Python API
Send frames to the QVAC DirectShow virtual camera

Example:
    from qvac import QVACCamera
    import numpy as np
    
    with QVACCamera() as cam:
        frame = np.zeros((720, 1280, 3), dtype=np.uint8)
        cam.send_frame(frame)
"""

from .camera import QVACCamera

__version__ = "1.0.0"
__all__ = ["QVACCamera"]
