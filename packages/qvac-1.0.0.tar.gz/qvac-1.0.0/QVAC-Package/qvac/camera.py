"""
QVAC Virtual Camera interface
"""

import mmap
import struct
import numpy as np
from typing import Optional, Union


class QVACCamera:
    """
    Interface to QVAC Virtual Camera
    
    Send frames to the virtual camera that can be used in OBS, Zoom, Teams, etc.
    
    Attributes:
        width (int): Frame width (default: 1280)
        height (int): Frame height (default: 720)
        
    Example:
        >>> import numpy as np
        >>> from qvac import QVACCamera
        >>> 
        >>> with QVACCamera() as cam:
        ...     frame = np.zeros((720, 1280, 3), dtype=np.uint8)
        ...     cam.send_frame(frame)
    """
    
    def __init__(self, width: int = 1280, height: int = 720):
        """
        Initialize QVAC Camera
        
        Args:
            width: Frame width (default: 1280)
            height: Frame height (default: 720)
        """
        self.width = width
        self.height = height
        self.frame_num = 0
        self.mm: Optional[mmap.mmap] = None
        
    def open(self) -> 'QVACCamera':
        """
        Open connection to virtual camera
        
        Returns:
            Self for chaining
            
        Raises:
            RuntimeError: If shared memory cannot be opened
        """
        try:
            # Calculate required size
            size = 16 + (self.width * self.height * 4)
            
            # Try to open existing or create new
            self.mm = mmap.mmap(-1, size, "QVACVirtualCameraFrameData")
            return self
        except Exception as e:
            raise RuntimeError(f"Failed to open virtual camera: {e}")
        
    def close(self):
        """Close connection to virtual camera"""
        if self.mm:
            self.mm.close()
            self.mm = None
            
    def __enter__(self) -> 'QVACCamera':
        """Context manager entry"""
        return self.open()
        
    def __exit__(self, *args):
        """Context manager exit"""
        self.close()
        
    def send_frame(self, frame: np.ndarray) -> bool:
        """
        Send a frame to the virtual camera
        
        Args:
            frame: Numpy array of shape (height, width, 3) in RGB/BGR format
                   or (height, width, 4) in RGBA/BGRA format
                   Will be automatically resized if dimensions don't match
                   
        Returns:
            True if frame was sent successfully
            
        Raises:
            RuntimeError: If camera is not opened
            
        Example:
            >>> frame = np.zeros((720, 1280, 3), dtype=np.uint8)
            >>> cam.send_frame(frame)
            True
        """
        if self.mm is None:
            raise RuntimeError("Camera not opened. Use 'with QVACCamera()' or call open() first")
            
        # Handle different input formats
        if len(frame.shape) == 2:
            # Grayscale - convert to RGB
            frame = np.stack([frame, frame, frame], axis=2)
            
        h, w = frame.shape[:2]
        channels = frame.shape[2] if len(frame.shape) > 2 else 1
        
        # Resize if needed
        if h != self.height or w != self.width:
            try:
                import cv2
                frame = cv2.resize(frame, (self.width, self.height))
            except ImportError:
                raise RuntimeError("OpenCV is required for frame resizing. Install with: pip install opencv-python")
            h, w = self.height, self.width
        
        # Convert to BGRA if needed
        if channels == 3:
            try:
                import cv2
                frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGRA)
            except ImportError:
                # Manual conversion
                bgra = np.zeros((h, w, 4), dtype=np.uint8)
                bgra[:, :, :3] = frame
                bgra[:, :, 3] = 255
                frame = bgra
        
        # Ensure uint8
        if frame.dtype != np.uint8:
            frame = frame.astype(np.uint8)
        
        # Write to shared memory
        try:
            self.frame_num += 1
            self.mm.seek(0)
            
            # Write header: width, height, stride, frame_number
            self.mm.write(struct.pack('IIII', w, h, w * 4, self.frame_num))
            
            # Write frame data
            self.mm.write(frame.tobytes())
            
            return True
        except Exception as e:
            print(f"Warning: Failed to send frame: {e}")
            return False
    
    def send_numpy(self, frame: np.ndarray) -> bool:
        """
        Alias for send_frame()
        
        Args:
            frame: Numpy array
            
        Returns:
            True if successful
        """
        return self.send_frame(frame)
    
    @property
    def is_open(self) -> bool:
        """Check if camera is open"""
        return self.mm is not None
    
    def __repr__(self) -> str:
        status = "open" if self.is_open else "closed"
        return f"QVACCamera(width={self.width}, height={self.height}, status={status})"
