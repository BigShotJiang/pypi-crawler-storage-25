"""
QVAC Virtual Camera - Python Package Setup
"""

from setuptools import setup, find_packages

with open("README_PYTHON.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="qvac",
    version="1.0.0",
    author="QVAC Project",
    description="Python API for QVAC Virtual Camera",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.19.0",
        "opencv-python>=4.5.0",
    ],
    python_requires=">=3.6",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Multimedia :: Video",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: Microsoft :: Windows",
    ],
    keywords="virtual camera directshow video streaming",
)
