"""
QVAC Virtual Camera - Drawing App
Draw on a canvas and stream it to the virtual camera
"""

import cv2
import numpy as np
from qvac_simple import QVACCamera
import time

class DrawingApp:
    def __init__(self):
        self.width = 1280
        self.height = 720
        self.canvas = np.ones((self.height, self.width, 3), dtype=np.uint8) * 255  # White background
        self.drawing = False
        self.last_point = None
        self.brush_color = (0, 0, 0)  # Black
        self.brush_size = 3
        self.frame_counter = 0
        
    def mouse_callback(self, event, x, y, flags, param):
        """Handle mouse events for drawing"""
        if event == cv2.EVENT_LBUTTONDOWN:
            self.drawing = True
            self.last_point = (x, y)
            
        elif event == cv2.EVENT_MOUSEMOVE:
            if self.drawing and self.last_point:
                cv2.line(self.canvas, self.last_point, (x, y), self.brush_color, self.brush_size)
                self.last_point = (x, y)
                
        elif event == cv2.EVENT_LBUTTONUP:
            self.drawing = False
            self.last_point = None
            
    def add_activity_pixel(self, frame):
        """Add a tiny moving pixel in the corner to prevent camera shutdown"""
        # Oscillate a single pixel in bottom-right corner
        x = self.width - 2
        y = self.height - 2
        
        # Alternate between two colors every frame
        if self.frame_counter % 2 == 0:
            frame[y, x] = [255, 255, 255]
        else:
            frame[y, x] = [254, 254, 254]
            
        self.frame_counter += 1
        
    def run(self):
        """Run the drawing app"""
        print("=" * 60)
        print("QVAC Virtual Camera - Drawing App")
        print("=" * 60)
        print()
        print("Instructions:")
        print("  • Draw with left mouse button")
        print("  • Press 'c' to clear canvas")
        print("  • Press 'r' for red brush")
        print("  • Press 'g' for green brush")
        print("  • Press 'b' for blue brush")
        print("  • Press 'k' for black brush")
        print("  • Press '+' to increase brush size")
        print("  • Press '-' to decrease brush size")
        print("  • Press 'q' to quit")
        print()
        print("Open OBS and add 'QVAC Virtual Camera' to see your drawing!")
        print()
        
        # Create window
        cv2.namedWindow('QVAC Drawing App')
        cv2.setMouseCallback('QVAC Drawing App', self.mouse_callback)
        
        # Open virtual camera
        with QVACCamera() as cam:
            while True:
                # Create display frame with info
                display = self.canvas.copy()
                
                # Add brush info
                info_text = f"Brush: {self.brush_size}px | Color: {self.brush_color}"
                cv2.putText(display, info_text, (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (128, 128, 128), 2)
                
                # Show local preview
                cv2.imshow('QVAC Drawing App', display)
                
                # Send to virtual camera (with activity pixel)
                output_frame = self.canvas.copy()
                self.add_activity_pixel(output_frame)
                cam.send_frame(output_frame)
                
                # Handle keyboard
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                elif key == ord('c'):
                    self.canvas = np.ones((self.height, self.width, 3), dtype=np.uint8) * 255
                    print("Canvas cleared")
                elif key == ord('r'):
                    self.brush_color = (0, 0, 255)  # Red
                    print("Brush: Red")
                elif key == ord('g'):
                    self.brush_color = (0, 255, 0)  # Green
                    print("Brush: Green")
                elif key == ord('b'):
                    self.brush_color = (255, 0, 0)  # Blue
                    print("Brush: Blue")
                elif key == ord('k'):
                    self.brush_color = (0, 0, 0)  # Black
                    print("Brush: Black")
                elif key == ord('+') or key == ord('='):
                    self.brush_size = min(50, self.brush_size + 1)
                    print(f"Brush size: {self.brush_size}")
                elif key == ord('-') or key == ord('_'):
                    self.brush_size = max(1, self.brush_size - 1)
                    print(f"Brush size: {self.brush_size}")
                
                # Maintain ~30 FPS
                time.sleep(1/30)
        
        cv2.destroyAllWindows()
        print("\nDrawing app closed!")


if __name__ == "__main__":
    app = DrawingApp()
    app.run()
