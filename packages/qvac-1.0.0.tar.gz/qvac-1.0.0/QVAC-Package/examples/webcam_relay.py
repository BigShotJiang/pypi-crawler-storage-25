"""
Webcam Relay - Forward webcam to virtual camera
"""

from qvac import QVACCamera
import cv2

print("Webcam Relay - Press 'q' to quit")
print("=" * 50)

# Open webcam
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("ERROR: Could not open webcam")
    exit(1)

print("Webcam opened successfully")
print("Forwarding to QVAC Virtual Camera...")
print()

with QVACCamera() as cam:
    frame_count = 0
    
    while True:
        ret, frame = cap.read()
        if not ret:
            print("ERROR: Failed to read frame")
            break
            
        # Send to virtual camera
        cam.send_frame(frame)
        
        # Show preview
        cv2.imshow('Webcam Relay (Press Q to quit)', frame)
        
        frame_count += 1
        if frame_count % 30 == 0:
            print(f"Frames sent: {frame_count}")
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()
print(f"\nTotal frames sent: {frame_count}")
