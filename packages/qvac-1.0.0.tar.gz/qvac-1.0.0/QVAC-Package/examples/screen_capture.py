"""
Screen Capture - Share screen as virtual camera
"""

from qvac import QVACCamera
import numpy as np
from PIL import ImageGrab
import time

print("Screen Capture - Press Ctrl+C to stop")
print("=" * 50)
print()
print("Capturing screen and sending to QVAC Virtual Camera...")
print("Open OBS/Zoom and select 'QVAC Virtual Camera' to see your screen")
print()

with QVACCamera() as cam:
    frame_count = 0
    
    try:
        while True:
            # Capture screen
            screen = ImageGrab.grab()
            frame = np.array(screen)
            
            # Convert RGB to BGR
            frame = frame[:, :, ::-1]
            
            # Send to camera
            cam.send_frame(frame)
            
            frame_count += 1
            if frame_count % 30 == 0:
                print(f"Frames sent: {frame_count}")
            
            # 30 FPS
            time.sleep(1/30)
            
    except KeyboardInterrupt:
        print(f"\n\nStopped. Total frames sent: {frame_count}")
