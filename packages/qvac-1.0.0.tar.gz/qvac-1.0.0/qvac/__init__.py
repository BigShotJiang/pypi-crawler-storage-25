from .camera import QVACCamera
from .installer import install, uninstall, is_installed

__version__ = "1.0.0"
__all__ = ["QVACCamera", "install", "uninstall", "is_installed"]
