import os
import sys
import subprocess
import winreg
import shutil
from pathlib import Path
import ctypes


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def get_install_dir():
    return Path(os.environ.get('ProgramFiles', 'C:\\Program Files')) / 'QVAC'


def get_dll_path():
    package_dir = Path(__file__).parent
    dll_path = package_dir / 'bin' / 'QVAC-DirectShow.dll'
    if dll_path.exists():
        return dll_path
    
    build_path = package_dir.parent / 'build' / 'Release' / 'Release' / 'QVAC-DirectShow.dll'
    if build_path.exists():
        return build_path
    
    return None


def is_installed():
    install_dir = get_install_dir()
    dll_path = install_dir / 'QVAC-DirectShow.dll'
    
    if not dll_path.exists():
        return False
    
    try:
        key = winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, 
                            r"CLSID\{51D5E7D6-4B6D-4C5E-9CF7-4F6B2B3A4D01}",
                            0, winreg.KEY_READ)
        winreg.CloseKey(key)
        return True
    except:
        return False


def install(force=False):
    if not is_admin():
        raise PermissionError("Administrator privileges required. Run as administrator or use: sudo python -c 'import qvac; qvac.install()'")
    
    if is_installed() and not force:
        print("QVAC Virtual Camera is already installed")
        return True
    
    dll_source = get_dll_path()
    if not dll_source:
        raise FileNotFoundError("QVAC-DirectShow.dll not found. Make sure the package is properly installed.")
    
    install_dir = get_install_dir()
    install_dir.mkdir(parents=True, exist_ok=True)
    
    dll_dest = install_dir / 'QVAC-DirectShow.dll'
    
    print(f"Installing QVAC Virtual Camera...")
    print(f"  Source: {dll_source}")
    print(f"  Destination: {dll_dest}")
    
    shutil.copy2(dll_source, dll_dest)
    
    print("  Registering DLL...")
    result = subprocess.run(['regsvr32', '/s', str(dll_dest)], capture_output=True)
    if result.returncode != 0:
        raise RuntimeError(f"Failed to register DLL: {result.stderr.decode()}")
    
    print("  Adding to Video Capture Sources...")
    try:
        key = winreg.CreateKey(winreg.HKEY_CLASSES_ROOT,
                              r"CLSID\{860BB310-5D01-11d0-BD3B-00A0C911CE86}\Instance\{51D5E7D6-4B6D-4C5E-9CF7-4F6B2B3A4D01}")
        winreg.SetValueEx(key, "CLSID", 0, winreg.REG_SZ, "{51D5E7D6-4B6D-4C5E-9CF7-4F6B2B3A4D01}")
        winreg.SetValueEx(key, "FriendlyName", 0, winreg.REG_SZ, "QVAC Virtual Camera")
        winreg.CloseKey(key)
    except Exception as e:
        print(f"  Warning: Could not add to Video Capture Sources: {e}")
    
    print("✓ QVAC Virtual Camera installed successfully!")
    print(f"  Location: {dll_dest}")
    print("  The virtual camera is now available in OBS, Zoom, Teams, etc.")
    
    return True


def uninstall():
    if not is_admin():
        raise PermissionError("Administrator privileges required. Run as administrator or use: sudo python -c 'import qvac; qvac.uninstall()'")
    
    if not is_installed():
        print("QVAC Virtual Camera is not installed")
        return True
    
    install_dir = get_install_dir()
    dll_path = install_dir / 'QVAC-DirectShow.dll'
    
    print("Uninstalling QVAC Virtual Camera...")
    
    if dll_path.exists():
        print("  Unregistering DLL...")
        subprocess.run(['regsvr32', '/u', '/s', str(dll_path)], capture_output=True)
    
    print("  Removing registry entries...")
    try:
        winreg.DeleteKey(winreg.HKEY_CLASSES_ROOT,
                        r"CLSID\{860BB310-5D01-11d0-BD3B-00A0C911CE86}\Instance\{51D5E7D6-4B6D-4C5E-9CF7-4F6B2B3A4D01}")
    except:
        pass
    
    print("  Removing files...")
    if dll_path.exists():
        dll_path.unlink()
    
    if install_dir.exists() and not any(install_dir.iterdir()):
        install_dir.rmdir()
    
    print("✓ QVAC Virtual Camera uninstalled successfully!")
    
    return True


def main():
    import argparse
    parser = argparse.ArgumentParser(description='QVAC Virtual Camera Installer')
    parser.add_argument('action', choices=['install', 'uninstall', 'status'], 
                       help='Action to perform')
    parser.add_argument('--force', action='store_true', 
                       help='Force reinstall if already installed')
    
    args = parser.parse_args()
    
    if args.action == 'status':
        if is_installed():
            print("✓ QVAC Virtual Camera is installed")
            print(f"  Location: {get_install_dir() / 'QVAC-DirectShow.dll'}")
        else:
            print("✗ QVAC Virtual Camera is not installed")
    elif args.action == 'install':
        install(force=args.force)
    elif args.action == 'uninstall':
        uninstall()


if __name__ == '__main__':
    main()
