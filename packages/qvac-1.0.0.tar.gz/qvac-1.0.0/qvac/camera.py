import mmap
import struct
import numpy as np
from typing import Optional


class QVACCamera:
    def __init__(self, width: int = 1280, height: int = 720):
        self.width = width
        self.height = height
        self.frame_num = 0
        self.mm: Optional[mmap.mmap] = None
        
    def open(self) -> 'QVACCamera':
        try:
            size = 16 + (self.width * self.height * 4)
            self.mm = mmap.mmap(-1, size, "QVACVirtualCameraFrameData")
            return self
        except Exception as e:
            raise RuntimeError(f"Failed to open virtual camera: {e}")
        
    def close(self):
        if self.mm:
            self.mm.close()
            self.mm = None
            
    def __enter__(self) -> 'QVACCamera':
        return self.open()
        
    def __exit__(self, *args):
        self.close()
        
    def send_frame(self, frame: np.ndarray) -> bool:
        if self.mm is None:
            raise RuntimeError("Camera not opened. Use 'with QVACCamera()' or call open() first")
            
        if len(frame.shape) == 2:
            frame = np.stack([frame, frame, frame], axis=2)
            
        h, w = frame.shape[:2]
        channels = frame.shape[2] if len(frame.shape) > 2 else 1
        
        if h != self.height or w != self.width:
            try:
                import cv2
                frame = cv2.resize(frame, (self.width, self.height))
            except ImportError:
                raise RuntimeError("OpenCV required for resizing. Install: pip install opencv-python")
            h, w = self.height, self.width
        
        if channels == 3:
            try:
                import cv2
                frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGRA)
            except ImportError:
                bgra = np.zeros((h, w, 4), dtype=np.uint8)
                bgra[:, :, :3] = frame
                bgra[:, :, 3] = 255
                frame = bgra
        
        if frame.dtype != np.uint8:
            frame = frame.astype(np.uint8)
        
        try:
            self.frame_num += 1
            self.mm.seek(0)
            self.mm.write(struct.pack('IIII', w, h, w * 4, self.frame_num))
            self.mm.write(frame.tobytes())
            return True
        except Exception as e:
            print(f"Warning: Failed to send frame: {e}")
            return False
    
    @property
    def is_open(self) -> bool:
        return self.mm is not None
    
    def __repr__(self) -> str:
        status = "open" if self.is_open else "closed"
        return f"QVACCamera(width={self.width}, height={self.height}, status={status})"
