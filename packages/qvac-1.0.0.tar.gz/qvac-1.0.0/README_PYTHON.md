# QVAC Virtual Camera

DirectShow virtual camera with Python API for Windows. Send custom video frames from Python to any application that supports webcams (OBS Studio, Zoom, Microsoft Teams, Discord, etc.).

## Features

- **DirectShow Virtual Camera**: Works with all DirectShow-compatible applications
- **Easy Python API**: Simple interface for sending frames
- **Automatic Installation**: Install/uninstall virtual camera from Python
- **Frame Conversion**: Automatic RGB/BGR/RGBA/BGRA conversion and resizing
- **Production Ready**: Fully tested and documented

## Installation

```bash
pip install qvac
```

## Quick Start

### 1. Install the Virtual Camera

```python
import qvac

# Requires administrator privileges
qvac.install()
```

Or from command line:
```bash
# Windows (run as administrator)
qvac install
```

### 2. Send Frames

```python
from qvac import QVACCamera
import numpy as np

# Create a red frame
frame = np.zeros((720, 1280, 3), dtype=np.uint8)
frame[:, :] = [255, 0, 0]

# Send to virtual camera
with QVACCamera() as cam:
    cam.send_frame(frame)
```

### 3. Use in Applications

The virtual camera appears as "QVAC Virtual Camera" in:
- OBS Studio
- Zoom
- Microsoft Teams
- Discord
- Any DirectShow-compatible application

## Usage Examples

### Webcam Relay

```python
from qvac import QVACCamera
import cv2

cap = cv2.VideoCapture(0)

with QVACCamera() as cam:
    while True:
        ret, frame = cap.read()
        if ret:
            cam.send_frame(frame)
```

### Screen Capture

```python
from qvac import QVACCamera
from PIL import ImageGrab
import numpy as np
import time

with QVACCamera() as cam:
    while True:
        screen = np.array(ImageGrab.grab())
        cam.send_frame(screen)
        time.sleep(1/30)
```

### Video File Playback

```python
from qvac import QVACCamera
import cv2

cap = cv2.VideoCapture('video.mp4')

with QVACCamera() as cam:
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        cam.send_frame(frame)
```

## API Reference

### Installation Functions

```python
import qvac

# Install virtual camera (requires admin)
qvac.install()

# Uninstall virtual camera (requires admin)
qvac.uninstall()

# Check if installed
if qvac.is_installed():
    print("Virtual camera is installed")
```

### QVACCamera Class

```python
from qvac import QVACCamera

# Create camera instance
cam = QVACCamera(width=1280, height=720)

# Open connection
cam.open()

# Send frame (numpy array)
frame = np.zeros((720, 1280, 3), dtype=np.uint8)
cam.send_frame(frame)

# Close connection
cam.close()

# Or use context manager (recommended)
with QVACCamera() as cam:
    cam.send_frame(frame)
```

## Command Line Interface

```bash
# Install virtual camera
qvac install

# Uninstall virtual camera
qvac uninstall

# Check installation status
qvac status
```

## Requirements

- Windows 7 or later
- Python 3.6+
- NumPy
- OpenCV (for frame resizing/conversion)
- Administrator privileges (for install/uninstall)

## Frame Format

- **Resolution**: 1280x720 (default, configurable)
- **Color Format**: RGB, BGR, RGBA, or BGRA (automatically converted)
- **Data Type**: numpy.ndarray with dtype=uint8
- **Shape**: (height, width, 3) or (height, width, 4)

Frames are automatically:
- Resized if dimensions don't match
- Converted from grayscale to RGB if needed
- Converted to BGRA format for the virtual camera

## Troubleshooting

### Permission Error

If you get a permission error during installation:
```python
# Run Python as administrator, then:
import qvac
qvac.install()
```

### Camera Not Found

If the camera doesn't appear in applications:
1. Verify installation: `qvac status`
2. Restart the application
3. Try reinstalling: `qvac.install(force=True)`

### Import Error

If you get "ModuleNotFoundError":
```bash
pip install numpy opencv-python
```

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions, please visit the GitHub repository.
