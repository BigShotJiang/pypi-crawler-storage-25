# scikit-causal

`scikit-causal` is an intentionally non-installable placeholder distribution
that reserves this package name for the `skcausal` project.

Any attempt to install it should fail with a message explaining that the real
project is distributed as `skcausal` and imported as `skcausal`.

Install the real package with:

```bash
pip install skcausal
```