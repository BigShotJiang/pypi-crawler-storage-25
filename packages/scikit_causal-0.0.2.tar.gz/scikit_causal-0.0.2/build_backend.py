"""Build backend for the reserved `scikit-causal` placeholder distribution."""

from __future__ import annotations

from hatchling.build import build_sdist as _build_sdist
from hatchling.build import get_requires_for_build_sdist as _get_requires_for_build_sdist

INSTALL_ERROR = """The `scikit-causal` distribution is intentionally not installable.

This package name is reserved for the `skcausal` project to protect users from
typosquatting and dependency confusion.

Install the real package instead:

    pip install skcausal

Then import it as:

    import skcausal
"""


def _raise_install_error() -> None:
    raise RuntimeError(INSTALL_ERROR)


def build_sdist(sdist_directory: str, config_settings: dict[str, object] | None = None) -> str:
    return _build_sdist(sdist_directory, config_settings)


def get_requires_for_build_sdist(config_settings: dict[str, object] | None = None) -> list[str]:
    return _get_requires_for_build_sdist(config_settings)


def build_wheel(
    wheel_directory: str,
    config_settings: dict[str, object] | None = None,
    metadata_directory: str | None = None,
) -> str:
    _raise_install_error()


def get_requires_for_build_wheel(config_settings: dict[str, object] | None = None) -> list[str]:
    _raise_install_error()


def prepare_metadata_for_build_wheel(
    metadata_directory: str,
    config_settings: dict[str, object] | None = None,
) -> str:
    _raise_install_error()


def build_editable(
    wheel_directory: str,
    config_settings: dict[str, object] | None = None,
    metadata_directory: str | None = None,
) -> str:
    _raise_install_error()


def get_requires_for_build_editable(config_settings: dict[str, object] | None = None) -> list[str]:
    _raise_install_error()


def prepare_metadata_for_build_editable(
    metadata_directory: str,
    config_settings: dict[str, object] | None = None,
) -> str:
    _raise_install_error()