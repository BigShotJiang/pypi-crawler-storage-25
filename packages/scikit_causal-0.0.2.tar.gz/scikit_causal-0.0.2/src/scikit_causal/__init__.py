"""Placeholder package for the reserved `scikit-causal` distribution."""

from __future__ import annotations

import warnings

__all__ = ["INSTALL_HINT", "__version__"]

__version__ = "0.0.2"
INSTALL_HINT = (
    "The `scikit-causal` distribution is an intentionally non-installable "
    "placeholder that reserves the name for the `skcausal` project. Install "
    "`skcausal` instead."
)

warnings.warn(INSTALL_HINT, UserWarning, stacklevel=2)