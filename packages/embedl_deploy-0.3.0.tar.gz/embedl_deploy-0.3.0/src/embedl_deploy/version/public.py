# Copyright (C) 2026 Embedl AB

"""The hardcoded public version of the package."""

PUBLIC_VERSION = '0.3.0'
