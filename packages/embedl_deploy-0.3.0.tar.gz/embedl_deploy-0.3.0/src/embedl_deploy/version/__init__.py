# Copyright (C) 2026 Embedl AB

"""Determine the version of the package."""
