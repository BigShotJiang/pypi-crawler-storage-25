# Copyright (C) 2026 Embedl AB

"""Public quantization API.

Users import from here::

    from embedl_deploy.quantize import insert_qdq, optimize_qdq, calibrate
"""

from embedl_deploy._internal.core.quantize.calibrate import (
    calibrate_qdq,
    calibrate_smooth_quant,
)
from embedl_deploy._internal.core.quantize.config import (
    CalibrationMethod,
    ModulesToSkip,
    QuantConfig,
    SmoothQuantConfig,
    TensorQuantConfig,
)
from embedl_deploy._internal.core.quantize.main import (
    configure,
    freeze_weight_quantization,
    quantize,
)
from embedl_deploy._internal.core.quantize.qat import (
    disable_fake_quant,
    enable_fake_quant,
    freeze_bn_stats,
    prepare_qat,
)
from embedl_deploy._internal.core.quantize.stubs import (
    QuantStub,
    WeightFakeQuantize,
)

__all__ = [
    "CalibrationMethod",
    "QuantConfig",
    "QuantStub",
    "ModulesToSkip",
    "SmoothQuantConfig",
    "TensorQuantConfig",
    "WeightFakeQuantize",
    "calibrate_qdq",
    "calibrate_smooth_quant",
    "configure",
    "disable_fake_quant",
    "enable_fake_quant",
    "freeze_bn_stats",
    "freeze_weight_quantization",
    "prepare_qat",
    "quantize",
]
