# Copyright (C) 2026 Embedl AB

"""Abstract ``nn.Module`` marker bases and tracing helpers."""

# mypy: disable-error-code="misc"
# torch lacks type stubs, so nn.Module resolves to Any.

from abc import ABC
from typing import TypeAlias

from torch import fx, nn

from embedl_deploy._internal.core.quantize.stubs import QuantStub

ActivationLike: TypeAlias = (
    nn.ReLU
    | nn.ReLU6
    | nn.GELU
    | nn.SiLU
    | nn.Mish
    | nn.Hardswish
    | nn.Hardsigmoid
    | nn.LeakyReLU
    | nn.PReLU
    | nn.ELU
    | nn.Sigmoid
    | nn.Tanh
)


class ConvertedModule(nn.Module, ABC):
    """Marker base for modules that must stay opaque during FX tracing.

    Conversion patterns replace high-level ops (e.g.
    ``nn.MultiheadAttention``) with sub-modules that fusion patterns
    later match on.  Subclassing ``ConvertedModule`` tells
    :func:`~embedl_deploy._internal.core.modules.symbolic_trace`
    to treat them as leaf nodes so they remain as single
    ``call_module`` nodes in the graph.
    """


class FusedModule(nn.Module, ABC):
    """Marker base for all backend-specific fused modules.

    Backend packages (e.g. ``tensorrt``) subclass this for their concrete
    fused modules (``FusedConvBNAct``, etc.).  The generic Q/DQ insertion
    pass in :mod:`~embedl_deploy._internal.core.quantize.prepare` uses
    ``isinstance(mod, FusedModule)`` to identify fused nodes without
    knowing backend-specific types.
    """

    #: Positional argument indices that should receive a
    #: :class:`~embedl_deploy._internal.core.quantize.stubs.QuantStub`.
    #: The Q/DQ insertion pass uses this to decide which inputs of the
    #: fused node to quantize.  Every subclass must set this explicitly.
    inputs_to_quantize: set[int]

    def __init__(self) -> None:
        super().__init__()
        #: Maps each index in :attr:`inputs_to_quantize` to a
        #: :class:`~embedl_deploy._internal.core.quantize.stubs.QuantStub`.
        self.input_quant_stubs: dict[int, QuantStub] = {
            idx: QuantStub({self}) for idx in self.inputs_to_quantize
        }


class _LeafTracer(fx.Tracer):
    """Tracer that keeps converted and fused modules as leaf nodes."""

    def is_leaf_module(self, m: nn.Module, module_qualified_name: str) -> bool:
        if isinstance(m, (ConvertedModule, FusedModule, QuantStub)):
            return True
        result: bool = super().is_leaf_module(m, module_qualified_name)
        return result


def symbolic_trace(model: nn.Module) -> fx.GraphModule:
    """Trace `model` keeping converted and fused modules opaque.

    Works like :func:`torch.fx.symbolic_trace` but treats any module that
    inherits from
    :class:`~embedl_deploy._internal.core.modules.ConvertedModule` or
    :class:`~embedl_deploy._internal.core.modules.FusedModule`
    as a leaf module so that they remain as single
    ``call_module`` nodes in the graph.

    :param model:
        The module to trace.
    :returns:
        A :class:`~torch.fx.GraphModule` with converted and fused modules
        preserved as opaque nodes.
    """
    graph = _LeafTracer().trace(model)
    return fx.GraphModule(model, graph)
