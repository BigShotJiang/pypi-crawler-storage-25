# Copyright (C) 2026 Embedl AB

"""Backend-agnostic quantization: modules, Q/DQ insertion and optimization."""
