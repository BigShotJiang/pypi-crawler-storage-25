# Copyright (C) 2026 Embedl AB

"""Pattern-based preparation passes for Q/DQ and SmoothQuant."""

from torch import fx

from embedl_deploy._internal.core.backend import get_backend
from embedl_deploy._internal.core.plan import (
    apply_transformation_plan,
    get_transformation_plan,
)


def prepare_smooth_quant(model: fx.GraphModule) -> None:
    """Populate weight references on each ``SmoothQuantObserver``.

    Runs the active backend's smooth-quant patterns on `model` via
    :func:`~embedl_deploy._internal.core.plan.get_transformation_plan`
    and
    :func:`~embedl_deploy._internal.core.plan.apply_transformation_plan`.
    The deep copy is bypassed by setting ``_deep_copy_done`` on the
    model beforehand.

    :param model:
        A fused ``GraphModule`` produced by the transformation step.
    """
    backend = get_backend()
    setattr(model, "_deep_copy_done", True)
    plan = get_transformation_plan(model, backend.smooth_patterns)
    if not plan.matches:
        return
    apply_transformation_plan(plan)


def prepare_qdq(model: fx.GraphModule) -> None:
    """Insert and optimize Q/DQ stubs using pattern-based rewrites.

    Iteratively applies the active backend's quantized patterns until
    no new matches are found.  The model must already have its fused
    modules configured via
    :func:`~embedl_deploy._internal.core.quantize.main.configure`.

    :param model:
        A configured ``GraphModule`` with enabled ``input_quant_stubs``.
    """
    backend = get_backend()
    setattr(model, "_deep_copy_done", True)
    while True:
        plan = get_transformation_plan(model, backend.quantized_patterns)
        if not plan.matches:
            break
        model = apply_transformation_plan(plan).model
