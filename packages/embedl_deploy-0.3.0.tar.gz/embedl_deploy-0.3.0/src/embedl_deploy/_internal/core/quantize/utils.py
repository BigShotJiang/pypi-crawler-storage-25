# Copyright (C) 2026 Embedl AB

"""Shared helpers for quantization passes."""

from dataclasses import dataclass, field

from torch import fx

from embedl_deploy._internal.core.modules import FusedModule
from embedl_deploy._internal.core.quantize.stubs import (
    QuantStub,
    SmoothQuantObserver,
    WeightFakeQuantize,
)


@dataclass
class ModelQuants:
    """Quantization modules grouped by category."""

    #: Activation quant stubs (input and softmax).
    stubs: list[QuantStub] = field(default_factory=list)

    #: Weight fake-quantize modules.
    weight: list[WeightFakeQuantize] = field(default_factory=list)

    #: Smooth-quant observers.
    smooth: list[SmoothQuantObserver] = field(default_factory=list)


def get_model_quants(
    model: fx.GraphModule,
    *,
    include_enabled: bool = True,
    include_disabled: bool = False,
) -> ModelQuants:
    """Collect quantization modules from `model` by category.

    Collects ``stubs`` from both
    :class:`~embedl_deploy._internal.core.modules.FusedModule` attributes and
    a flat module walk (so that graph-level
    :class:`~embedl_deploy._internal.core.quantize.stubs.QuantStub` nodes
    inserted by ``prepare_qdq`` are included).  Collects ``weight`` and
    ``smooth`` modules from
    :class:`~embedl_deploy._internal.core.modules.FusedModule` attributes.

    :param model:
        A configured ``GraphModule`` containing fused modules.
    :param include_enabled:
        Include modules whose ``enabled`` flag is ``True``.
    :param include_disabled:
        Include modules whose ``enabled`` flag is ``False``.
    :returns:
        An :class:`~embedl_deploy._internal.core.quantize.utils.ModelQuants`
        with the matching modules in each category.
    """

    def _include(
        obj: QuantStub | WeightFakeQuantize | SmoothQuantObserver,
    ) -> bool:
        return (include_enabled and obj.enabled) or (
            include_disabled and not obj.enabled
        )

    result = ModelQuants()

    for mod in model.modules():
        if isinstance(mod, QuantStub) and _include(mod):
            result.stubs.append(mod)
            continue

        if not isinstance(mod, FusedModule):
            continue

        input_stubs: dict[int, QuantStub] = getattr(
            mod, "input_quant_stubs", {}
        )
        for stub in input_stubs.values():
            if _include(stub):
                result.stubs.append(stub)

        wfq = getattr(mod, "weight_fake_quant", None)
        if isinstance(wfq, WeightFakeQuantize) and _include(wfq):
            result.weight.append(wfq)

        obs = getattr(mod, "smooth_quant_observer", None)
        if isinstance(obs, SmoothQuantObserver) and _include(obs):
            result.smooth.append(obs)

    return result
