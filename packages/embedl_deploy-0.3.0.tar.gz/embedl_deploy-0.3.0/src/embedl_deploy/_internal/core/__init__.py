# Copyright (C) 2026 Embedl AB

"""Backend-agnostic core: Pattern ABC, matching/replacement utilities."""
