# Copyright (C) 2026 Embedl AB

"""Matching utilities for pattern implementations.

These functions are called by
:class:`~embedl_deploy._internal.core.pattern.Pattern` subclasses inside their
:meth:`~embedl_deploy._internal.core.pattern.Pattern.match` methods to find
occurrences of operation chains in ``torch.fx`` graphs.
"""

import itertools
import types

from torch import fx

from embedl_deploy._internal.core.pattern import (
    Fork,
    ModType,
    NodeCheck,
    Pattern,
    PatternMatch,
    SharedNodeCheck,
    Tree,
    TreeMatch,
    Trunk,
    Wildcard,
    get_module,
)


class _SharedNodeCheckSession:
    """Checkpoint/rollback scope for ``SharedNodeCheck`` cache entries.

    Between permutation attempts inside a fork, call :meth:`rollback`
    explicitly.  On normal exit (success) cache entries survive so that
    enclosing sessions can still enforce cross-fork shared-node
    constraints.  On failure exit (no permutation matched and the block
    falls through) ``__exit__`` rolls back automatically.
    """

    def __init__(self) -> None:
        self._checkpoint = SharedNodeCheck.checkpoint()
        self._succeeded = False

    def __enter__(self) -> "_SharedNodeCheckSession":
        return self

    def success(self) -> None:
        """Mark this session as successful — skip rollback on exit."""
        self._succeeded = True

    def __exit__(self, *args: object) -> None:
        if not self._succeeded:
            self.rollback()

    def rollback(self) -> None:
        """Reset every cache event logged since this session started."""
        SharedNodeCheck.rollback_to(self._checkpoint)


def _node_matches(node: fx.Node, checks: ModType | NodeCheck) -> bool:
    """Return whether `node` satisfies `checks`."""
    if isinstance(checks, (type, types.UnionType)):
        return isinstance(get_module(node), checks)
    return checks(node)


def _match_trunk_at(
    tip_node: fx.Node,
    trunk: Trunk,
) -> TreeMatch | None:
    """Try to match a straight `trunk` ending at `tip_node`.

    Walks the graph **backward** from `tip_node`, checking each node against
    the corresponding trunk entry (last entry first).

    :param tip_node:
        The graph node to start matching from (the trunk's last entry).
    :param trunk:
        The sequence of type/predicate entries, listed root-to-tip.
    :returns:
        A :class:`~embedl_deploy._internal.core.pattern.TreeMatch` on success,
        or ``None``.
    """
    nodes: list[fx.Node | Wildcard] = []
    args: list[fx.Node] = [tip_node]

    for entry in reversed(trunk):
        if len(args) != 1:
            return None
        current = args[0]

        if not isinstance(entry, Wildcard):
            if not _node_matches(current, entry):
                return None
            nodes.append(current)
            args = [a for a in current.args if isinstance(a, fx.Node)]
            continue

        absorbed: list[fx.Node] = []
        while True:
            if not _node_matches(current, entry.check):
                break
            absorbed.append(current)
            args = [a for a in current.args if isinstance(a, fx.Node)]
            if entry.quantifier == "?":
                break
            if len(args) != 1:
                break
            current = args[0]

        absorbed.reverse()
        if entry.quantifier == "+" and not absorbed:
            return None
        nodes.append(Wildcard(entry.check, entry.quantifier, tuple(absorbed)))

    nodes.reverse()

    return TreeMatch(
        pre_trunk_nodes=args,
        trunk_nodes=nodes,
    )


def _match_fork_at(
    tip_node: fx.Node,
    fork: Fork,
) -> TreeMatch | None:
    """Try to match a `fork` whose output trunk ends at `tip_node`.

    First matches the output trunk, then checks that the trunk's input node is
    a ``call_function`` invoking ``fork.operator``.  Every permutation of the
    fork's input branches is tried against the function node's arguments.

    :param tip_node:
        The graph node to start matching from (the output trunk's last entry).
    :param fork:
        The branching topology to match.
    :returns:
        A :class:`~embedl_deploy._internal.core.pattern.TreeMatch` on success,
        or ``None``.
    """

    trunk = _match_trunk_at(tip_node, fork.output)
    if trunk is None:
        return None

    fork_node = trunk.pre_trunk_nodes[0]
    if getattr(fork.operator, "is_node_check", False):
        if not fork.operator(fork_node):
            return None
    elif (
        fork_node.op != "call_function"
        or fork_node.target is not fork.operator
    ):
        return None

    args = [a for a in fork_node.args if isinstance(a, fx.Node)]
    perms = (
        itertools.permutations(range(len(fork.inputs)))
        if fork.perms_override is None
        else fork.perms_override
    )
    with _SharedNodeCheckSession() as session:
        for perm in perms:
            session.rollback()
            if len(perm) != len(args):
                continue
            fork_matched = True
            tree_matches = [TreeMatch() for _ in fork.inputs]
            for arg_idx, input_idx in enumerate(perm):
                tree_match = _match_tree_at(
                    args[arg_idx], fork.inputs[input_idx]
                )
                if tree_match is None:
                    fork_matched = False
                    break
                tree_matches[input_idx] = tree_match
            if fork_matched:
                session.success()
                return TreeMatch(
                    pre_trunk_nodes=[fork_node],
                    trunk_nodes=trunk.trunk_nodes,
                    nested=tree_matches,
                )
    return None


def _match_tree_at(
    tip_node: fx.Node,
    tree: Tree,
) -> TreeMatch | None:
    """Dispatch to trunk or fork matching depending on `tree` type.

    :param tip_node:
        The graph node to start matching from.
    :param tree:
        A :data:`~embedl_deploy._internal.core.pattern.Trunk` or
        :class:`~embedl_deploy._internal.core.pattern.Fork` describing the
        expected topology.
    :returns:
        A :class:`~embedl_deploy._internal.core.pattern.TreeMatch` on success,
        or ``None``.
    """
    if isinstance(tree, Fork):
        return _match_fork_at(tip_node, tree)
    return _match_trunk_at(tip_node, tree)


def match_tree(
    graph_module: fx.GraphModule,
    pattern: Pattern,
) -> list[PatternMatch]:
    """Match a branching topology described by ``pattern.tree``.

    Walks the graph in **reverse** order and, for each node, tries to match
    the ``pattern.tree`` sequence **backward** starting from the last entry.
    Reverse iteration ensures that when a
    :class:`~embedl_deploy._internal.core.pattern.Wildcard` produces both a
    long and a short match at the same root, the longer match appears first
    in the returned list.

    When a :class:`~embedl_deploy._internal.core.pattern.Fork` is encountered,
    every permutation of its ``branches`` is tried against the function-node's
    arguments.

    :param graph_module:
        The traced graph to search.
    :param pattern:
        The :class:`~embedl_deploy._internal.core.pattern.Pattern` instance to
        record in the returned
        :class:`~embedl_deploy._internal.core.pattern.PatternMatch`.
    :returns:
        All matches found (may overlap).
    :raises ValueError:
        If `pattern` has no tree to match.
    """
    tree = pattern.tree
    if tree is None:
        raise ValueError("``pattern`` has no tree to match.")

    matches: list[PatternMatch] = []
    with _SharedNodeCheckSession() as session:
        for node in reversed(list(graph_module.graph.nodes)):
            session.rollback()
            matched = _match_tree_at(node, tree)
            if matched is not None:
                matches.append(
                    PatternMatch(
                        pattern=pattern,
                        graph_module=graph_module,
                        tree_match=matched,
                    )
                )

    return matches
