# Copyright (C) 2026 Embedl AB

"""Core abstractions: Pattern ABC and PatternMatch dataclass.

Every fusion, conversion, and quantization rule is a
:class:`~embedl_deploy._internal.core.pattern.Pattern` subclass.  The two
methods — :meth:`~embedl_deploy._internal.core.pattern.Pattern.match` and
:meth:`~embedl_deploy._internal.core.pattern.Pattern.replace` — encapsulate
what to look for and how to rewrite the graph.
"""

import types
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal, TypedDict, TypeVar, overload

from torch import fx, nn

_M = TypeVar("_M", bound=nn.Module)


@overload
def resolve_module(node: fx.Node) -> nn.Module: ...


@overload
def resolve_module(node: fx.Node, cls: type[_M]) -> _M: ...


def resolve_module(
    node: fx.Node, cls: type[nn.Module] = nn.Module
) -> nn.Module:
    """Resolve the ``nn.Module`` that a ``call_module`` node refers to.

    :param node:
        A ``call_module`` graph node.
    :param cls:
        The expected module type.  The returned module is checked with
        ``isinstance`` and a ``LookupError`` is raised on mismatch.
    :returns:
        The ``nn.Module`` instance, narrowed to `cls`.
    :raises LookupError:
        If `node` is not a ``call_module`` node, the target module
        cannot be found, or the module is not an instance of `cls`.
    """
    if not (
        node.op == "call_module"
        and isinstance(node.target, str)
        and isinstance(node.graph.owning_module, fx.GraphModule)
    ):
        raise LookupError(f"node {node.name!r} is not a call_module node")
    try:
        mod = node.graph.owning_module.get_submodule(node.target)
    except AttributeError:
        raise LookupError(
            f"module {node.target!r} not found in graph"
        ) from None
    if not isinstance(mod, cls):
        raise LookupError(f"expected {cls.__name__}, got {type(mod).__name__}")
    return mod


def get_module(node: fx.Node) -> nn.Module | None:
    """Get the ``nn.Module`` that a ``call_module`` node refers to.

    :returns:
        The ``nn.Module`` instance, or ``None`` if not found."""
    try:
        return resolve_module(node, nn.Module)
    except LookupError:
        return None


#: A single module type or a union of module types for ``isinstance`` checks.
ModType = type[nn.Module] | types.UnionType

#: A callable predicate that inspects a node and returns whether it matches.
NodeCheck = Callable[[fx.Node], bool]


@dataclass(frozen=True)
class Wildcard:
    """Zero or more consecutive nodes to absorb during matching.

    When a :class:`~embedl_deploy._internal.core.pattern.Wildcard` appears in a
    :data:`~embedl_deploy._internal.core.pattern.Trunk`, the matcher walks
    backward through nodes that satisfy `checks`.  The absorbed nodes are
    recorded in `nodes` and the
    :class:`~embedl_deploy._internal.core.pattern.Wildcard` itself is stored as
    an entry in
    :attr:`~embedl_deploy._internal.core.pattern.TreeMatch.trunk_nodes`.
    """

    #: Module types for ``isinstance`` checks, or a predicate on nodes.
    check: ModType | NodeCheck
    #: Quantifier for the wildcard: ``"*"`` matches zero or more,
    #: ``"+"`` matches one or more, ``"?"`` matches zero or one.
    quantifier: str = "*"
    #: Nodes absorbed during matching (empty in pattern definitions).
    nodes: tuple[fx.Node, ...] = ()

    @property
    def name(self) -> list[str]:
        """Node names of absorbed nodes, for use in serialization."""
        return [n.name for n in self.nodes]


#: A straight (non-branching) sequence of entries, listed root-to-tip
#: (i.e. earliest-in-graph first).  Each entry is either a module type
#: (for ``isinstance`` checks), a
#: :data:`~embedl_deploy._internal.core.pattern.NodeCheck` predicate,
#: or a :class:`~embedl_deploy._internal.core.pattern.Wildcard`.
Trunk = tuple[ModType | NodeCheck | Wildcard, ...]


def node_check(
    fn: Callable[[fx.Node], bool],
) -> Callable[[fx.Node], bool]:
    """Mark a function as a ``Fork.operator`` predicate.

    When the matcher encounters a
    :class:`~embedl_deploy._internal.core.pattern.Fork` whose ``operator``
    carries the ``is_node_check`` attribute, it calls the operator with the
    candidate node and expects a ``bool``. Without the marker the operator is
    identity-compared against ``node.target``.

    :param fn:
        A :data:`~embedl_deploy._internal.core.pattern.NodeCheck` callable.
    :returns:
        The same callable, with ``is_node_check = True`` attached.
    """
    setattr(fn, "is_node_check", True)
    return fn


class SharedNodeCheck:
    """Constrain multiple fork branches to the same physical node.

    On the first call, delegates to an inner ``NodeCheck`` and caches the
    matched node.  Subsequent calls succeed only when the candidate is the
    exact same ``fx.Node`` instance.  A class-level log records every
    cache event so the matcher can checkpoint and rollback.
    """

    _log: list["SharedNodeCheck"] = []

    def __init__(self, inner: NodeCheck) -> None:
        self._inner = inner
        self._cached: fx.Node | None = None

    def __call__(self, node: fx.Node) -> bool:
        if self._cached is None:
            if not self._inner(node):
                return False
            self._cached = node
            SharedNodeCheck._log.append(self)
            return True
        return node is self._cached

    def reset(self) -> None:
        """Clear the cached node."""
        self._cached = None

    @classmethod
    def checkpoint(cls) -> int:
        """Return a rollback point for use with ``rollback_to``."""
        return len(cls._log)

    @classmethod
    def rollback_to(cls, checkpoint: int) -> None:
        """Reset and discard every log entry from `checkpoint` onward."""
        for entry in cls._log[checkpoint:]:
            entry.reset()
        del cls._log[checkpoint:]


@dataclass(frozen=True)
class Fork:
    """A ``call_function`` merge point where multiple branches converge.

    Describes a pattern where several input branches feed into a function node
    (e.g. ``operator.add``) whose result continues through an output trunk.
    """

    #: The input branches feeding into the function node.  Each branch
    #: is itself a :data:`~embedl_deploy._internal.core.pattern.Tree`
    #: (a :data:`~embedl_deploy._internal.core.pattern.Trunk` or
    #: another :class:`~embedl_deploy._internal.core.pattern.Fork`).
    #: An empty tuple means the branch accepts any single node.
    inputs: tuple["Tree", ...]
    #: The function that the fork node must invoke.  There are two
    #: modes, selected by the presence of the ``is_node_check``
    #: attribute (set by the :func:`node_check` decorator):
    #:
    #: **Identity compare** (default) — the fork node's ``target``
    #: is checked with ``is`` against this value.  Use for concrete
    #: functions like ``operator.add`` or
    #: ``torch.ops.aten.conv2d.default``.
    #:
    #: **Predicate** (``@node_check``) — called with the fork node;
    #: must return ``True`` for the match to succeed.  Use when a
    #: single function target is not sufficient, e.g. when the match
    #: also depends on argument shapes or metadata.
    operator: Callable[..., Any]
    #: The straight chain of modules after the merge node.
    output: Trunk
    #: Optional override of the permitted mappings from the arguments of the
    #: ``operator`` to the branches in ``inputs``. Only ``fx.Node`` arguments
    #: are considered (``None`` and scalar arguments are ignored). Each
    #: mapping is a tuple whose length equals the expected number of such
    #: arguments. At index *i*, a value of *k* in a mapping means that the
    #: *i*-th argument of the ``operator`` must match the *k*-th branch in
    #: ``inputs``. A mapping may not be longer than ``inputs``, but it may be
    #: shorter if some of the branches are optional.
    #:
    #: .. code-block:: python
    #:
    #:     fork = Fork(
    #:         inputs=(
    #:             (),                     # input tensor
    #:             (_is_attr("weight"),),
    #:             (_is_attr("bias"),),    # optional
    #:         ),
    #:         operator=torch.ops.aten.conv2d.default,
    #:         output=(),
    #:         perms_override=((0, 1, 2), (0, 1)),
    #:     )
    #:
    #: The two entries in ``perms_override`` cover the two shapes of the
    #: ``aten.conv2d.default`` call: ``(0, 1, 2)`` matches when bias is
    #: present, ``(0, 1)`` matches when it is absent.
    #:
    #: By default the ``perms_override`` is ``None``. In that case, the
    #: arguments of the ``operator`` are checked against all full-length
    #: permutations of the branches in ``inputs`` until one matches.
    perms_override: tuple[tuple[int, ...], ...] | None = None

    def __post_init__(self) -> None:
        if self.perms_override is None:
            return
        valid_set = set(range(len(self.inputs)))
        for perm in self.perms_override:
            perm_set = set(perm)
            if not perm_set <= valid_set:
                raise ValueError(
                    f"perms_override entry {perm!r} contains "
                    f"out-of-range indices"
                )
            if len(perm_set) < len(perm):
                raise ValueError(
                    f"perms_override entry {perm!r} contains "
                    f"duplicate indices"
                )


#: A pattern topology: either a straight
#: :data:`~embedl_deploy._internal.core.pattern.Trunk` or a branching
#: :class:`~embedl_deploy._internal.core.pattern.Fork`.
Tree = Trunk | Fork


class Pattern(ABC):
    """A graph transformation rule: find a sub-graph and replace it.

    Subclasses implement
    :meth:`~embedl_deploy._internal.core.pattern.Pattern.match` to locate
    occurrences and
    :meth:`~embedl_deploy._internal.core.pattern.Pattern.replace` to rewrite
    each occurrence in the graph.

    Patterns with
    :attr:`~embedl_deploy._internal.core.pattern.Pattern.is_conversion` set to
    ``True`` are applied in a first pass to rewrite graph topology before
    fusion patterns are matched.
    """

    tree: Tree | None = None
    """The pattern topology to match, if using tree-based matching."""

    is_conversion: bool = False
    """If ``True``, this pattern is a structural conversion that must
    be applied before fusion matching."""

    symbolic_trace_only: bool = False
    """If ``True``, this pattern removes nodes that are artifacts of
    ``symbolic_trace``. This pattern has no effect on graphs exported with
    ``torch.export`` because the nodes never appear in those graphs."""

    export_graph_only: bool = False
    """If ``True``, this pattern targets nodes that only appear in
    ``torch.export`` aten graphs and has no effect on symbolic-trace output."""

    @abstractmethod
    def match(self, graph_module: fx.GraphModule) -> list["PatternMatch"]:
        """Find all occurrences of this pattern in `graph_module`.

        Returns a list of
        :class:`~embedl_deploy._internal.core.pattern.PatternMatch` objects,
        each describing one non-overlapping occurrence — the matched nodes, the
        original ``nn.Module`` instances, etc.
        """

    @abstractmethod
    def replace(
        self,
        pattern_match: "PatternMatch",
    ) -> list[fx.Node]:
        """Replace one matched occurrence in-place in a graph_module.

        Swaps the matched nodes with the appropriate fused or quantized module.
        The graph is modified in place; callers must call
        ``graph_module.graph.lint()`` and ``graph_module.recompile()`` after
        all replacements are done.

        :param pattern_match:
            The pattern match to replace.
        :returns:
            The replacement nodes inserted into the graph.
        """


class SerializedTreeMatch(TypedDict):
    """JSON-serializable representation of a ``TreeMatch``."""

    nested: list["SerializedTreeMatch"]
    pre_trunk_nodes: list[str]
    trunk_nodes: list[str | list[str]]


@dataclass
class TreeMatch:
    """Result of matching a ``pattern.tree`` against a sub-graph.

    For a :data:`~embedl_deploy._internal.core.pattern.Trunk` match the matched
    nodes and modules are stored directly.  For a
    :class:`~embedl_deploy._internal.core.pattern.Fork` match the output-trunk
    nodes are stored here and each input branch is a nested
    :class:`~embedl_deploy._internal.core.pattern.TreeMatch` in
    :attr:`~embedl_deploy._internal.core.pattern.TreeMatch.nested`.
    """

    #: The nodes immediately before the matched trunk.  For a
    #: :data:`~embedl_deploy._internal.core.pattern.Trunk` match this
    #: is the predecessor of the earliest matched module node.  For a
    #: :class:`~embedl_deploy._internal.core.pattern.Fork` match this
    #: is the ``call_function`` node that merges the input branches.
    pre_trunk_nodes: list[fx.Node] = field(default_factory=list)
    #: Matched nodes in chain order.  Each entry is either a single
    #: ``fx.Node`` or a :class:`~embedl_deploy._internal.core.pattern.Wildcard`
    #: carrying the absorbed nodes in its ``nodes`` attribute.
    trunk_nodes: list[fx.Node | Wildcard] = field(default_factory=list)
    #: Per-branch sub-matches, indexed the same as
    #: :attr:`~embedl_deploy._internal.core.pattern.Fork.inputs`.
    #: Empty entries represent optional branches that were absent.
    nested: list["TreeMatch"] = field(default_factory=list)

    def get_input_nodes(self) -> tuple[fx.Node, ...]:
        """Collect the external input nodes of a ``TreeMatch``.

        Recursively walks nested sub-matches and returns the
        :attr:`~embedl_deploy._internal.core.pattern.TreeMatch.pre_trunk_nodes`
        of each leaf (non-fork) match.  These are the nodes that feed *into*
        the matched sub-graph.
        """
        input_nodes: list[fx.Node] = []
        for tree in self.nested:
            input_nodes.extend(tree.get_input_nodes())
        if not self.nested:
            input_nodes.extend(self.pre_trunk_nodes)
        return tuple(input_nodes)

    def get_tree_nodes(self) -> tuple[fx.Node, ...]:
        """Collect all internal nodes of a ``TreeMatch``.

        Returns every node that should be erased when the match is replaced:
        nested branch nodes, fork ``call_function`` nodes, and output-trunk
        ``call_module`` nodes.
        :class:`~embedl_deploy._internal.core.pattern.Wildcard` entries are
        expanded into their absorbed nodes.
        """
        tree_nodes: list[fx.Node] = []
        for tree in self.nested:
            tree_nodes.extend(tree.get_tree_nodes())
        if self.nested:
            tree_nodes.extend(self.pre_trunk_nodes)
        for entry in self.trunk_nodes:
            if isinstance(entry, Wildcard):
                tree_nodes.extend(entry.nodes)
            else:
                tree_nodes.append(entry)
        return tuple(tree_nodes)

    @overload
    def get_node(
        self,
        index: int,
        *args: int,
        is_wildcard: Literal[False] = ...,
    ) -> fx.Node: ...

    @overload
    def get_node(
        self,
        index: int,
        *args: int,
        is_wildcard: Literal[True],
    ) -> Wildcard: ...

    def get_node(
        self,
        index: int,
        *args: int,
        is_wildcard: bool = False,
    ) -> fx.Node | Wildcard:
        """Look up a matched node by positional indices.

        With a single `index`, returns ``trunk_nodes[index]``.  For a
        :class:`~embedl_deploy._internal.core.pattern.Wildcard` position the
        returned value is the
        :class:`~embedl_deploy._internal.core.pattern.Wildcard` itself
        (access its ``nodes`` attribute for the absorbed nodes).  With
        additional indices the lookup descends into
        :attr:`~embedl_deploy._internal.core.pattern.TreeMatch.nested`
        sub-matches first.

        :param index:
            Index into
            :attr:`~embedl_deploy._internal.core.pattern.TreeMatch.trunk_nodes`
            (or :attr:`~embedl_deploy._internal.core.pattern.TreeMatch.nested`
            when `args` are given).
        :param args:
            Additional indices forwarded recursively into nested sub-matches.
        :param is_wildcard:
            If ``True``, assert the entry is a
            :class:`~embedl_deploy._internal.core.pattern.Wildcard` and return
            it.  If ``False`` (default), assert it is an ``fx.Node``.
        :returns:
            The matched ``fx.Node`` or
            :class:`~embedl_deploy._internal.core.pattern.Wildcard`.
        """
        if args:
            nested = self.nested[index]
            if is_wildcard:
                return nested.get_node(*args, is_wildcard=True)
            return nested.get_node(*args)
        entry = self.trunk_nodes[index]
        assert isinstance(entry, Wildcard if is_wildcard else fx.Node)
        return entry

    def serialize(self) -> SerializedTreeMatch:
        """Serialize this match to a JSON-serializable dict."""
        return {
            "nested": [nm.serialize() for nm in self.nested],
            "pre_trunk_nodes": [n.name for n in self.pre_trunk_nodes],
            "trunk_nodes": [n.name for n in self.trunk_nodes],
        }


@dataclass
class PatternMatch:
    """One matched occurrence of a ``Pattern`` in a graph."""

    #: The pattern that produced this match.
    pattern: Pattern
    #: The graph module that produced this match.
    graph_module: fx.GraphModule
    #: Structured match result produced by
    #: :func:`~embedl_deploy._internal.core.match.match_tree`.  Contains
    #: the matched nodes, modules, and nested per-branch sub-matches
    #: for :class:`~embedl_deploy._internal.core.pattern.Fork`
    #: topologies.
    tree_match: TreeMatch
    #: Whether to apply this match during transformation.
    apply: bool = True

    def __repr__(self) -> str:
        pat = type(self.pattern).__name__
        node_names = [n.name for n in self.tree_match.get_tree_nodes()]
        return f"PatternMatch({pat}: {' -> '.join(node_names)})"
