# Copyright (C) 2026 Embedl AB

"""Backend discovery and selection."""

import importlib
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from embedl_deploy._internal.core.pattern import Pattern

_INTERNAL_DIR = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Backend:
    """A collection of patterns for a specific hardware target."""

    #: Structural rewrite patterns, applied iteratively.
    conversion_patterns: Sequence[Pattern]
    #: Fusion patterns, applied in a single pass after conversions.
    fusion_patterns: Sequence[Pattern]
    #: SmoothQuant preparation patterns.
    smooth_patterns: Sequence[Pattern]
    #: Q/DQ stub insertion patterns for quantisation.
    quantized_patterns: Sequence[Pattern]


class _BackendState:
    """Module-level mutable state for backend discovery and selection."""

    #: The currently selected backend.
    backend: Backend | None = None
    #: Cached discovery result.
    backends: dict[str, Backend] | None = None

    @classmethod
    def reset(cls) -> None:
        """Clear cached discovery results and the active backend."""
        cls.backend = None
        cls.backends = None


def _discover_backends() -> dict[str, Backend]:
    """Scan ``_internal/`` for importable backend packages.

    Each subdirectory (except ``core``) is tried as
    ``embedl_deploy._internal.<name>.backend``.  Directories whose
    module cannot be found are skipped; import errors from
    transitive dependencies are propagated.  Results are cached
    after the first call.

    :returns:
        Mapping of backend name to ``Backend`` instance.
    """
    backends = _BackendState.backends
    if backends is None:
        backends = {}
        for entry in sorted(_INTERNAL_DIR.iterdir()):
            if (
                not entry.is_dir()
                or entry.name.startswith("_")
                or entry.name == "core"
            ):
                continue
            module_path = f"embedl_deploy._internal.{entry.name}.backend"
            try:
                mod = importlib.import_module(module_path)
            except ModuleNotFoundError as e:
                if e.name == module_path:
                    continue
                raise
            backend = getattr(mod, "BACKEND", None)
            if isinstance(backend, Backend):
                backends[entry.name] = backend
        _BackendState.backends = backends
    return backends


def get_backend() -> Backend:
    """Return the active backend, discovering it if necessary.

    If no backend has been set via :func:`set_backend`, the installed
    backends are discovered automatically.  When exactly one is found
    it becomes the active backend.

    :returns:
        The active :class:`Backend`.
    :raises RuntimeError:
        If no backends are installed, or if multiple backends are
        installed and none has been explicitly selected.
    """
    backend = _BackendState.backend
    if backend is None:
        backends = _discover_backends()
        if len(backends) == 0:
            raise RuntimeError(
                "No backends found — install at least one backend"
            )
        if len(backends) > 1:
            names = ", ".join(sorted(backends))
            raise RuntimeError(
                f"Multiple backends found ({names}). "
                "Call set_backend() to select one."
            )
        backend = next(iter(backends.values()))
        _BackendState.backend = backend
    return backend


def set_backend(name: str) -> None:
    """Select the active backend by name.

    :param name:
        The name of a discovered backend (e.g. ``"tensorrt"``).
    :raises ValueError:
        If `name` does not match any installed backend.
    """
    backends = _discover_backends()
    if name not in backends:
        available = ", ".join(sorted(backends)) or "(none)"
        raise ValueError(
            f"Backend {name!r} not found. " f"Available backends: {available}"
        )
    _BackendState.backend = backends[name]
