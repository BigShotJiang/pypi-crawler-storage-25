# Copyright (C) 2026 Embedl AB

"""Replacement utilities for pattern implementations.

These functions are called by
:class:`~embedl_deploy._internal.core.pattern.Pattern` subclasses inside their
:meth:`~embedl_deploy._internal.core.pattern.Pattern.replace` methods to swap
matched nodes with fused or quantized ``nn.Module`` instances.
"""

from collections.abc import Callable

from torch import fx, nn

from embedl_deploy._internal.core.pattern import PatternMatch

#: A callable replacement that receives the graph module and the
#: preceding node's outputs, inserts arbitrary subgraph nodes, and
#: returns the list of all created nodes (last node is the output).
ReplacementFn = Callable[
    [fx.GraphModule, tuple[fx.Node, ...]],
    list[fx.Node],
]


def _graph_order(graph_module: fx.GraphModule) -> Callable[[fx.Node], int]:
    """Return a key function mapping nodes to their graph position."""
    order = {n: i for i, n in enumerate(graph_module.graph.nodes)}
    return order.__getitem__


def get_replaced_nodes(
    graph_module: fx.GraphModule,
) -> dict[fx.Node, fx.Node]:
    """Return the replaced-node mapping attached to ``graph_module``.

    Creates and attaches an empty mapping on first access.  The dict maps
    erased original nodes to their replacement fused nodes, allowing successive
    :func:`~embedl_deploy._internal.core.replace.replace_tree` calls to resolve
    nodes that were removed by earlier replacements.
    """
    replaced_nodes: dict[fx.Node, fx.Node]
    if hasattr(graph_module, '_replaced_nodes'):
        replaced_nodes = getattr(graph_module, '_replaced_nodes')
    else:
        replaced_nodes = {}
        setattr(graph_module, '_replaced_nodes', replaced_nodes)
    return replaced_nodes


def get_auto_name(graph_module: fx.GraphModule, module: nn.Module) -> str:
    """Generate a unique submodule name from the module's class name."""
    base = type(module).__name__
    i = 0
    while hasattr(graph_module, f"{base}_{i}"):
        i += 1
    return f"{base}_{i}"


def _insert_replacements(
    graph_module: fx.GraphModule,
    replacements: list[nn.Module | fx.Node | ReplacementFn],
    prev_args: tuple[fx.Node, ...],
    old_output_node: fx.Node,
) -> list[fx.Node]:
    """Insert replacement items into the graph, chaining outputs."""
    nodes: list[fx.Node] = []
    for item in replacements:
        if isinstance(item, nn.Module):
            name = get_auto_name(graph_module, item)
            graph_module.add_module(name, item)
            arg_count = getattr(item, '_arg_count', None)
            if arg_count is not None:
                prev_args = prev_args[:arg_count]
            with graph_module.graph.inserting_before(old_output_node):
                nodes.append(graph_module.graph.call_module(name, prev_args))
        elif isinstance(item, fx.Node):
            item.args = prev_args + item.args[1:]
            prev_node = max(prev_args, key=_graph_order(graph_module))
            prev_node.append(item)
            nodes.append(item)
        else:
            nodes.extend(item(graph_module, prev_args))
        prev_args = (nodes[-1],) if nodes else prev_args
    return nodes


def replace_tree(
    pattern_match: PatternMatch,
    replacements: list[nn.Module | fx.Node | ReplacementFn],
) -> list[fx.Node]:
    """Replace `pattern_match` tree match with a chain of replacements.

    Each element in `replacements` is one of:

    *  An ``nn.Module`` — registered on the graph module and inserted
       as a new ``call_module`` node.
    *  An ``fx.Node`` from the matched tree — kept in place and
       rewired to receive the preceding element's output.
    *  A :data:`~embedl_deploy._internal.core.replace.ReplacementFn`
       callable — called with ``(graph_module, prev_args)`` to insert an
       arbitrary subgraph.  Must return the list of all created nodes, last
       being the output.

    Elements are chained sequentially: the first receives the tree's external
    inputs, each subsequent element receives the output of the previous one.
    An empty `replacements` sequence removes the matched tree entirely, wiring
    the tree's external input through to downstream users.

    Module names are derived automatically from the module class name.

    :param pattern_match:
        The pattern match to replace.
    :param replacements:
        List of ``nn.Module``, ``fx.Node``, or
        :data:`~embedl_deploy._internal.core.replace.ReplacementFn`.
    :returns:
        The replacement nodes inserted into the graph.  Empty when
        `replacements` is empty (the matched tree is simply removed).
    :raises ValueError:
        If the matched tree in `pattern_match` has no nodes to replace. If
        `replacements` is empty but there are multiple input nodes.
    """
    graph_module = pattern_match.graph_module
    tree_match = pattern_match.tree_match

    tree_nodes = tree_match.get_tree_nodes()
    if not tree_nodes:
        msg = "The matched tree in ``pattern_match`` has no nodes to replace."
        raise ValueError(msg)
    input_nodes = tree_match.get_input_nodes()
    if not replacements and len(input_nodes) != 1:
        msg = "``replacements`` is empty but there are multiple input nodes"
        raise ValueError(msg)

    old_output_node = tree_nodes[-1]
    old_output_users = list(old_output_node.users)

    replaced_nodes = get_replaced_nodes(graph_module)
    input_nodes = tuple(replaced_nodes.get(n, n) for n in input_nodes)
    tree_nodes = tuple(replaced_nodes.get(n, n) for n in tree_nodes)
    replacements = [
        replaced_nodes.get(r, r) if isinstance(r, fx.Node) else r
        for r in replacements
    ]

    replacement_nodes = _insert_replacements(
        graph_module,
        replacements,
        input_nodes,
        old_output_node,
    )
    new_output_node = ([input_nodes[0]] + replacement_nodes)[-1]
    for user in old_output_users:
        user.replace_input_with(old_output_node, new_output_node)

    for node in reversed(tree_nodes):
        if node in replacements:
            continue
        if len(node.users) > 0:
            continue
        graph_module.graph.erase_node(node)
        replaced_nodes[node] = new_output_node
        replaced_nodes.update(
            {
                k: new_output_node
                for k, v in replaced_nodes.items()
                if v is node
            }
        )

    return replacement_nodes
