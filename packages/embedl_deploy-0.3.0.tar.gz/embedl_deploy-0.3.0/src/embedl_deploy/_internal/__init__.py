# Copyright (C) 2026 Embedl AB

"""Private implementation details — not part of the public API."""
