# Copyright (C) 2026 Embedl AB

"""General-purpose conversion patterns.

Structural rewrites that are not attention-specific: assertion cleanup,
``Flatten → Linear`` rewritten as ``Conv2d(1×1)`` for TensorRT, and
``nn.Identity`` / identity-``AdaptiveAvgPool2d`` removal.
"""

import operator
from typing import TypeAlias

import torch
from torch import fx, nn

from embedl_deploy._internal.core.match import match_tree
from embedl_deploy._internal.core.pattern import (
    Pattern,
    PatternMatch,
    Tree,
    Wildcard,
    get_module,
    resolve_module,
)
from embedl_deploy._internal.core.replace import (
    ReplacementFn,
    get_replaced_nodes,
    replace_tree,
)
from embedl_deploy._internal.tensorrt.patterns.utils import get_input_shape


def _is_assert_noise(node: fx.Node) -> bool:
    """Return ``True`` for helper nodes typically used in assertions.

    These nodes are graph noise in exported inference graphs and usually feed
    directly into ``eq`` / ``_assert`` checks.
    """
    if node.op == "call_function" and node.target is getattr:
        return True
    if node.op == "call_method" and node.target in {"dim", "size"}:
        return True
    return False


def _is_eq(node: fx.Node) -> bool:
    """Return ``True`` when `node` is an equality comparison."""
    return node.op == "call_function" and node.target is operator.eq


def _is_assert(node: fx.Node) -> bool:
    """Return ``True`` when `node` is a torch assertion op."""
    target = getattr(torch, "_assert", None)
    return node.op == "call_function" and node.target is target


_OPTIONAL_ASSERT_NOISE = Wildcard(_is_assert_noise, quantifier="+")


def _is_dead_assert_noise(node: fx.Node) -> bool:
    """Return ``True`` for assertion-noise nodes with no users."""
    return _is_assert_noise(node) and len(node.users) == 0


class RemoveAssertPattern(Pattern):
    """Remove assertion subgraphs such as ``getattr → eq → _assert``.

    timm models often contain shape checks in the traced FX graph (for
    example ``assert x.dim() == 4``). They are not runtime compute ops and can
    be safely erased for deployment graphs.
    """

    is_conversion = True
    symbolic_trace_only = True
    tree: Tree = (_OPTIONAL_ASSERT_NOISE, _is_eq, _is_assert)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        return replace_tree(pattern_match, [])


class RemoveDeadAssertPattern(Pattern):
    """Remove dead assertion nodes left after assert removal.

    ``RemoveAssertPattern`` can erase ``eq``/``_assert`` while leaving the
    other ``getattr`` input dead. This cleanup pass removes those dead nodes.
    """

    is_conversion = True
    symbolic_trace_only = True
    tree: Tree = (_is_dead_assert_noise,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        return replace_tree(pattern_match, [])


def _is_export_assert(node: fx.Node) -> bool:
    """Return ``True`` for ``torch.export`` device/dtype guard nodes.

    ``torch.export`` inserts ``aten._assert_tensor_metadata.default`` and
    ``aten._assert_async.msg`` nodes to enforce the device, dtype, and layout
    of tensors at the export site.  These guards always fail when the model is
    moved to a different device (e.g. CPU export → CUDA inference) and must be
    removed for deployment.

    Both ops return ``None`` and have no downstream users, so removal is safe.
    """
    if node.op != "call_function":
        return False
    target = node.target
    _metadata = getattr(
        getattr(torch.ops, "aten", None),
        "_assert_tensor_metadata",
        None,
    )
    _async = getattr(
        getattr(torch.ops, "aten", None),
        "_assert_async",
        None,
    )
    if _metadata is not None and target is getattr(_metadata, "default", None):
        return True
    if _async is not None and target is getattr(_async, "msg", None):
        return True
    return False


class RemoveExportAssertPattern(Pattern):
    """Remove ``torch.export`` tensor-metadata guard nodes.

    ``torch.export`` inserts ``aten._assert_tensor_metadata`` calls to enforce
    the device/dtype/layout of inputs at export time.  These guards always
    raise when the model is run on a device other than the one used during
    export (e.g. CPU-exported model deployed on CUDA).

    Unlike :class:`RemoveAssertPattern` this pattern is not
    ``symbolic_trace_only`` — it targets ``torch.export`` graph modules
    specifically.
    """

    is_conversion = True
    export_graph_only = True
    tree: Tree = (_is_export_assert,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        return replace_tree(pattern_match, [])


def _is_flatten(node: fx.Node) -> bool:
    """Return ``True`` when `node` is a flatten call with shape metadata."""
    if node.op == "call_function":
        is_flat = node.target is torch.flatten
    elif node.op == "call_method":
        is_flat = node.target == "flatten"
    else:
        is_flat = isinstance(get_module(node), nn.Flatten)
    if not is_flat:
        return False
    shape = get_input_shape(node)
    return shape is not None


ElementWiseLike: TypeAlias = (
    nn.Dropout
    | nn.Dropout2d
    | nn.ReLU
    | nn.ReLU6
    | nn.LeakyReLU
    | nn.ELU
    | nn.GELU
    | nn.SiLU
    | nn.Hardswish
    | nn.Hardsigmoid
)

#: Optional element-wise ops that can appear between a ``flatten`` and
#: a ``Linear`` (activations, dropout).
_OPTIONAL_EW = Wildcard(ElementWiseLike)


def _get_reshape_insert(
    flatten_node: fx.Node,
    linear: nn.Linear,
) -> ReplacementFn:
    """Return a replacement function for reshaping conv inputs."""

    def _insert(
        graph_module: fx.GraphModule,
        prev_args: tuple[fx.Node, ...],
    ) -> list[fx.Node]:
        old_shape = get_input_shape(flatten_node)
        assert old_shape is not None
        new_shape = torch.Size([-1, linear.in_features, 1, 1])
        if old_shape[1:] == new_shape[1:]:
            return []
        replaced = get_replaced_nodes(graph_module)
        resolved = replaced.get(flatten_node, flatten_node)
        with graph_module.graph.inserting_before(resolved):
            node = graph_module.graph.call_method(
                "reshape", (prev_args[0], *new_shape)
            )
        return [node]

    return _insert


def _linear_to_conv1x1(linear: nn.Linear) -> nn.Conv2d:
    """Convert a ``Linear`` layer to an equivalent ``Conv2d(1×1)``."""
    conv = nn.Conv2d(
        linear.in_features,
        linear.out_features,
        kernel_size=1,
        bias=linear.bias is not None,
    )
    conv.weight.data = linear.weight.data.clone().reshape(
        linear.out_features,
        linear.in_features,
        1,
        1,
    )
    if linear.bias is not None:
        assert conv.bias is not None
        conv.bias.data = linear.bias.data.clone()
    return conv


class FlattenLinearToConv1x1Pattern(Pattern):
    """Replace ``Flatten (4D→2D) → Linear`` with ``Conv2d(1×1) → Flatten``.

    Many classification networks end with::

        ``AdaptiveAvgPool2d → flatten → [Dropout → ReLU →] Linear``

    This conversion rewrites the tail into::

        ``AdaptiveAvgPool2d → [Dropout → ReLU →] Conv2d(1×1) → flatten``

    Element-wise ops between flatten and Linear (activations, dropout) are
    absorbed by a :class:`~embedl_deploy._internal.core.pattern.Wildcard` and
    moved in front of the ``Conv2d`` in the replacement.

    The resulting ``Conv2d`` can then be matched by downstream fusion and Q/DQ
    patterns.

    This is a *structural* conversion — it changes graph topology rather than
    collapsing a chain into a fused module.  It must be applied **before**
    fusion patterns.
    """

    is_conversion = True
    tree: Tree = (_is_flatten, _OPTIONAL_EW, nn.Linear)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match
        flatten_node = tree_match.get_node(0)
        wild_nodes = tree_match.get_node(1, is_wildcard=True).nodes
        linear = resolve_module(tree_match.get_node(2), nn.Linear)
        reshape_insert = _get_reshape_insert(flatten_node, linear)
        conv = _linear_to_conv1x1(linear)
        return replace_tree(
            pattern_match, [*wild_nodes, reshape_insert, conv, flatten_node]
        )


def _is_identity_adaptive_avg_pool(node: fx.Node) -> bool:
    """Return ``True`` when ``node`` is an identity ``AdaptiveAvgPool2d``.

    The pool is identity when its ``output_size`` matches the spatial
    dimensions of the input tensor.  Requires shape metadata (``tensor_meta``)
    on the input node.

    ``None`` in ``output_size`` means "keep the input dimension", which is
    always identity for that axis.
    """
    mod = get_module(node)
    if not isinstance(mod, nn.AdaptiveAvgPool2d):
        return False

    shape = get_input_shape(node)
    if shape is None or len(shape) != 4:
        return False

    in_h: int = shape[2]
    in_w: int = shape[3]
    if isinstance(mod.output_size, tuple):
        out_h, out_w = mod.output_size
    else:
        out_h = out_w = mod.output_size
    out_h = out_h or in_h
    out_w = out_w or in_w
    return (in_h == out_h) and (in_w == out_w)


class RemoveIdentityAdaptiveAvgPoolPattern(Pattern):
    """Remove ``AdaptiveAvgPool2d`` where output size equals input size.

    When ``output_size == (H, W)`` of the incoming feature map the pooling
    operation is a mathematical identity and can be safely erased.  This is
    common in ConvNeXt-style architectures.

    Assumes shapes have already been propagated into
    ``node.meta['tensor_meta']`` (e.g. via a prior ``ShapeProp`` pass). Nodes
    with missing shape metadata are skipped with a warning.
    """

    is_conversion = True
    tree: Tree = (_is_identity_adaptive_avg_pool,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        return replace_tree(pattern_match, [])


def _is_identity_passthrough(node: fx.Node) -> bool:
    """Return ``True`` when `node` is an identity operation that passes through its input."""
    mod = get_module(node)
    return isinstance(mod, nn.Identity)


class RemoveIdentityPattern(Pattern):
    """Remove ``nn.Identity`` modules from the graph.

    ``nn.Identity`` is a no-op module that passes its input through unchanged.
    These operations can be safely removed from the graph without affecting
    model behavior.  This simplifies the graph for downstream optimization
    and fusion patterns.
    """

    is_conversion = True
    symbolic_trace_only = True
    tree: Tree = (_is_identity_passthrough,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        return replace_tree(pattern_match, [])
