# Copyright (C) 2026 Embedl AB

"""Quantization-aware ``Pattern`` subclasses for TensorRT.

These patterns run *after* fusion and insert
:class:`~embedl_deploy._internal.core.quantize.stubs.QuantStub` nodes
ahead of fused modules that declare quantized inputs.
"""

import torch
from torch import fx, nn

from embedl_deploy._internal.core.match import match_tree
from embedl_deploy._internal.core.modules import FusedModule
from embedl_deploy._internal.core.pattern import (
    Pattern,
    PatternMatch,
    Tree,
    TreeMatch,
    Wildcard,
    get_module,
    resolve_module,
)
from embedl_deploy._internal.core.quantize.config import TensorQuantConfig
from embedl_deploy._internal.core.quantize.stubs import QuantStub
from embedl_deploy._internal.core.replace import (
    ReplacementFn,
    get_auto_name,
    get_replaced_nodes,
    replace_tree,
)
from embedl_deploy._internal.tensorrt.modules.attention import (
    FusedScaledDotProductAttention,
)
from embedl_deploy._internal.tensorrt.modules.pool import (
    FusedAdaptiveAvgPool2d,
)
from embedl_deploy._internal.tensorrt.modules.swin_attention import (
    FusedSwinAttention,
)
from embedl_deploy._internal.tensorrt.patterns.utils import get_input_shape

#: Head sizes for which TensorRT has a fused INT8 MHA kernel.
INT8_MHA_HEAD_SIZES: frozenset[int] = frozenset({16, 32, 64})

#: Maximum sequence length supported by the fused INT8 MHA kernel.
#:
#: TensorRT's fused INT8 multi-head attention kernel (SM75–SM90, SM120,
#: SM121) only supports head sizes in :data:`INT8_MHA_HEAD_SIZES` and
#: sequence lengths at most :data:`INT8_MHA_MAX_SEQ`.  Outside those
#: bounds, quantising the softmax output forces an unfused FP32
#: softmax + INT8 requantise path that is slower than leaving the
#: attention block in FP16.
# Reference:
# pylint: disable-next=line-too-long
# https://docs.nvidia.com/deeplearning/tensorrt/latest/inference-library/work-with-transformers.html
INT8_MHA_MAX_SEQ: int = 512


def _has_quant_stubs(node: fx.Node) -> bool:
    """Return ``True`` for a ``FusedModule`` with enabled ``input_quant_stubs``."""
    mod = get_module(node)
    if isinstance(mod, FusedModule) and any(
        s.enabled for s in mod.input_quant_stubs.values()
    ):
        return True
    return False


def _get_stub_insert(fused_node: fx.Node) -> ReplacementFn:
    """Return a replacement function that inserts ``QuantStub`` nodes.

    For each entry in the fused module's ``input_quant_stubs``, a
    ``call_module`` node is inserted before the fused module and the
    corresponding input is rewired through it.
    """
    mod = resolve_module(fused_node, FusedModule)
    input_quant_stubs = mod.input_quant_stubs

    def _insert(
        graph_module: fx.GraphModule,
        prev_args: tuple[fx.Node, ...],
    ) -> list[fx.Node]:
        resolved = get_replaced_nodes(graph_module).get(fused_node, fused_node)
        nodes: list[fx.Node] = []
        new_args = list(prev_args)
        for idx in list(input_quant_stubs):
            stub = input_quant_stubs[idx]
            if not stub.enabled:
                continue
            input_quant_stubs.pop(idx)
            name = get_auto_name(graph_module, stub)
            graph_module.add_module(name, stub)
            with graph_module.graph.inserting_after(prev_args[idx]):
                stub_node = graph_module.graph.call_module(
                    name, (prev_args[idx],)
                )
            nodes.append(stub_node)
            new_args[idx] = stub_node
        resolved.args = tuple(new_args)
        nodes.append(resolved)
        return nodes

    return _insert


class InsertQuantStubsPattern(Pattern):
    """Insert ``QuantStub`` nodes before each quantized ``FusedModule`` input.

    Matches any :class:`~embedl_deploy._internal.core.modules.FusedModule`
    whose
    :attr:`~embedl_deploy._internal.core.modules.FusedModule.input_quant_stubs`
    is non-empty.  The replacement inserts a ``call_module`` node for each stub
    and rewires the fused module's inputs through them.
    """

    tree: Tree = (_has_quant_stubs,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        fused_node = pattern_match.tree_match.get_node(0)
        stub_insert = _get_stub_insert(fused_node)
        return replace_tree(pattern_match, [stub_insert])


def _is_transparent_node(node: fx.Node) -> bool:
    """Return ``True`` for ops that do not change the quantization domain."""
    mod = get_module(node)
    if mod is not None:
        return isinstance(
            mod,
            (
                nn.MaxPool2d,
                nn.AvgPool2d,
                nn.AdaptiveAvgPool2d,
                nn.Dropout,
                nn.Dropout2d,
                nn.Flatten,
            ),
        )
    if node.op in ("call_method", "call_function"):
        return node.target in {
            "view",
            "reshape",
            "flatten",
            "contiguous",
            "permute",
            "transpose",
            torch.flatten,
            torch.reshape,
        }
    return False


def _in_transparent_chain(node: fx.Node) -> bool:
    """Transparent node with exactly one downstream user."""
    return _is_transparent_node(node) and len(node.users) == 1


class PropagateQuantStubPattern(Pattern):
    """Move ``QuantStub`` nodes before chains of transparent operations.

    Matches one or more single-user transparent operations (pooling, reshape,
    flatten, …) followed by a
    :class:`~embedl_deploy._internal.core.quantize.stubs.QuantStub` and
    rewrites the graph so the ``QuantStub`` precedes the transparent chain.
    """

    tree: Tree = (
        Wildcard(_in_transparent_chain, quantifier="+"),
        QuantStub,
    )

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tm = pattern_match.tree_match
        transparent_chain = tm.get_node(0, is_wildcard=True).nodes
        quant_stub = tm.get_node(1)
        return replace_tree(pattern_match, [quant_stub, *transparent_chain])


def _needs_surround(node: fx.Node) -> bool:
    """Return ``True`` for a surround-type ``FusedModule`` not yet surrounded.

    For :class:`FusedScaledDotProductAttention`, surrounding is skipped
    when the head size or sequence length fall outside TensorRT's fused
    INT8 MHA constraints (:data:`INT8_MHA_HEAD_SIZES`,
    :data:`INT8_MHA_MAX_SEQ`).  The internal ``softmax_quant`` is also
    disabled so the attention block stays entirely in FP16.
    """
    mod = get_module(node)
    if not isinstance(
        mod,
        (
            FusedAdaptiveAvgPool2d,
            FusedScaledDotProductAttention,
            FusedSwinAttention,
        ),
    ):
        return False
    if getattr(mod, "_surrounded", False):
        return False
    if isinstance(mod, FusedScaledDotProductAttention):
        head_dim = mod.attention.head_dim
        shape = get_input_shape(node)
        seq_len = shape[-2] if shape is not None and len(shape) >= 3 else None
        if head_dim not in INT8_MHA_HEAD_SIZES or (
            seq_len is not None and seq_len > INT8_MHA_MAX_SEQ
        ):
            mod.softmax_quant.enabled = False
            return False
    return True


class SurroundWithQuantStubsPattern(Pattern):
    """Add input stubs for fused modules that need quantization on both sides.

    Matches a
    :class:`~embedl_deploy._internal.tensorrt.modules.pool.FusedAdaptiveAvgPool2d`
    or
    :class:`~embedl_deploy._internal.tensorrt.modules.attention.FusedScaledDotProductAttention`
    followed by a ``QuantStub`` and adds an enabled ``QuantStub`` (with the
    same config) to the fused module's ``input_quant_stubs`` for each input
    argument.  The actual graph nodes can be inserted later by
    :class:`InsertQuantStubsPattern`.
    """

    tree: Tree = (_needs_surround, QuantStub)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tm = pattern_match.tree_match
        fused_node = tm.get_node(0)
        fused_mod = resolve_module(fused_node, FusedModule)
        input_quant_stubs = fused_mod.input_quant_stubs
        quant_stub_node = tm.get_node(1)
        quant_stub_mod = resolve_module(quant_stub_node, QuantStub)
        for idx in range(len(fused_node.args)):
            stub = QuantStub(
                {fused_mod},
                quant_stub_mod.config.n_bits,
                quant_stub_mod.config.symmetric,
                quant_stub_mod.config.calibration_method,
            )
            stub.enabled = quant_stub_mod.enabled
            input_quant_stubs[idx] = stub
        setattr(fused_mod, "_surrounded", True)
        return [fused_node, quant_stub_node]


def _has_duplicate_quant_stubs(node: fx.Node) -> bool:
    """``True`` when ≥2 ``QuantStub`` users share the same config.

    Attaches a ``_duplicate_quant_stubs`` dict mapping each duplicated
    :class:`TensorQuantConfig` to its list of ``QuantStub`` user nodes.
    """
    quant_stubs: dict[TensorQuantConfig, list[fx.Node]] = {}
    for user in node.users:
        mod = get_module(user)
        if isinstance(mod, QuantStub):
            quant_stubs.setdefault(mod.config, []).append(user)
    quant_stubs = {
        cfg: nodes for cfg, nodes in quant_stubs.items() if len(nodes) > 1
    }
    if not quant_stubs:
        return False
    setattr(node, "_duplicate_quant_stubs", quant_stubs)
    return True


class DeduplicateQuantStubsPattern(Pattern):
    """Merge duplicate ``QuantStub`` nodes that share a producer and config.

    When a node feeds two or more
    :class:`~embedl_deploy._internal.core.quantize.stubs.QuantStub` nodes
    whose
    :class:`~embedl_deploy._internal.core.quantize.config.TensorQuantConfig` is
    identical, all but one are removed
    and their downstream users are redirected through the kept stub.
    """

    tree: Tree = (_has_duplicate_quant_stubs,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        patten_matches = match_tree(graph_module, pattern=self)
        for pm in patten_matches:
            producer = pm.tree_match.get_node(0)
            quant_stubs = getattr(producer, "_duplicate_quant_stubs")
            pm.tree_match = TreeMatch(
                pre_trunk_nodes=[producer],
                trunk_nodes=[
                    Wildcard(QuantStub, nodes=tuple(stubs))
                    for stubs in quant_stubs.values()
                ],
            )
            delattr(producer, "_duplicate_quant_stubs")
        return patten_matches

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        gm = pattern_match.graph_module

        kept: list[fx.Node] = []
        replaced_nodes = get_replaced_nodes(gm)
        for i in range(len(pattern_match.tree_match.trunk_nodes)):
            wildcard = pattern_match.tree_match.get_node(i, is_wildcard=True)
            keep, *duplicates = wildcard.nodes
            kept.append(keep)
            keep_mod = resolve_module(keep, QuantStub)
            for dup in duplicates:
                dup_mod = resolve_module(dup, QuantStub)
                keep_mod.consumers |= dup_mod.consumers
                dup.replace_all_uses_with(keep)
                gm.graph.erase_node(dup)
                replaced_nodes[dup] = keep
                assert isinstance(dup.target, str)
                if hasattr(gm, dup.target):
                    delattr(gm, dup.target)

        return kept
