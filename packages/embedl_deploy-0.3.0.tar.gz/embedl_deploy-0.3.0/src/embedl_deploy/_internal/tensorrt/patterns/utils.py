# Copyright (C) 2026 Embedl AB

"""Shared utilities for TensorRT pattern implementations."""

import logging
from collections.abc import Callable
from typing import TypeAlias

import torch
from torch import fx, nn
from torch.fx.node import Target

from embedl_deploy._internal.core.pattern import node_check

_LOG = logging.getLogger(__name__)


def get_input_shape(node: fx.Node) -> torch.Size | None:
    """Return the shape of the first input to `node`, or ``None``.

    Always attempts to read the shape from ``tensor_meta`` first. The result is
    cached on the node as ``_input_shape`` so that later calls can fall back to
    it if upstream replacements invalidate ``tensor_meta``.  Logs a warning
    and returns ``None`` when neither source is available on the first call;
    subsequent calls return the cached ``None`` silently.
    """
    shape: torch.Size | None
    try:
        shape = node.args[0].meta["tensor_meta"].shape  # type: ignore[union-attr]
        setattr(node, '_input_shape', shape)
        return shape
    except (AttributeError, IndexError, KeyError):
        pass

    if hasattr(node, '_input_shape'):
        shape = getattr(node, '_input_shape')
        return shape

    _LOG.warning(
        "Skipping %s: missing shape metadata on input node",
        node.target,
    )
    shape = None
    setattr(node, '_input_shape', shape)
    return shape


RegistryPredicate: TypeAlias = Callable[[fx.Node], bool]
RegistryFactory: TypeAlias = Callable[[fx.Node], nn.Module]
RegistryEntry: TypeAlias = tuple[RegistryPredicate, RegistryFactory]
Registry: TypeAlias = dict[Target, RegistryEntry]

is_true: RegistryPredicate = lambda _: True
make_cls: Callable[[type], RegistryFactory] = lambda cls: lambda _: cls()


def is_registry_op(registry: Registry) -> RegistryPredicate:
    """Return a predicate that matches ``call_function`` nodes in `registry`."""

    @node_check
    def predicate(node: fx.Node) -> bool:
        if node.op != "call_function":
            return False
        entry_predicate, _ = registry.get(node.target, (None, None))
        if entry_predicate is None:
            return False
        return entry_predicate(node)

    return predicate


def make_registry_op(registry: Registry) -> RegistryFactory:
    """Return a factory that builds an ``nn.Module`` from `registry`."""

    def factory(node: fx.Node) -> nn.Module:
        _, entry_factory = registry.get(node.target, (None, None))
        if entry_factory is None:
            raise ValueError(f"Unsupported target: {node.target}")
        return entry_factory(node)

    return factory
