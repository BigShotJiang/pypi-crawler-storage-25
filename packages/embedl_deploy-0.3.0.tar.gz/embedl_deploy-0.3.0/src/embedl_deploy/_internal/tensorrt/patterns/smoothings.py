# Copyright (C) 2026 Embedl AB

"""Pattern that populates downstream nodes of every ``SmoothQuantObserver``."""

from typing import cast

import torch
from torch import fx

from embedl_deploy._internal.core.match import match_tree
from embedl_deploy._internal.core.pattern import (
    Pattern,
    PatternMatch,
    Tree,
    TreeMatch,
    Wildcard,
    get_module,
    resolve_module,
)
from embedl_deploy._internal.tensorrt.modules.linear import (
    FusedLayerNorm,
    FusedLinearLike,
)

_SHAPE_ONLY_TARGETS = {
    "view",
    "reshape",
    "flatten",
    "contiguous",
    "permute",
    "transpose",
    torch.flatten,
    torch.reshape,
}


def _is_shape_only_node(node: fx.Node) -> bool:
    """Return ``True`` for ops that only reshape a tensor."""
    if node.op in ("call_method", "call_function"):
        return node.target in _SHAPE_ONLY_TARGETS
    return False


def _find_downstream_linears(start: fx.Node) -> list[fx.Node]:
    """Find ``FusedLinear`` / ``FusedLinearAct`` reachable through shape-only ops."""
    linears: list[fx.Node] = []
    stack = list(start.users)
    while stack:
        current = stack.pop()
        if isinstance(get_module(current), FusedLinearLike):
            linears.append(current)
        elif _is_shape_only_node(current):
            stack.extend(current.users)
    return linears


def _is_smoothable_layer_norm(node: fx.Node) -> bool:
    """Match predicate for the tree pattern.

    Returns ``True`` for a ``FusedLayerNorm`` with ``elementwise_affine=True``,
    an observer whose ``downstream_linears`` have not yet been populated, and
    at least one downstream linear.  Attaches the downstream node list to the
    graph node as ``_smoothable_downstream`` for retrieval in
    :meth:`PrepareSmoothQuantPattern.match`.
    """
    mod = get_module(node)
    if not isinstance(mod, FusedLayerNorm):
        return False
    if mod.smooth_quant_observer.downstream_linears:
        return False
    if not mod.layer_norm.elementwise_affine:
        return False
    downstream = _find_downstream_linears(node)
    if not downstream:
        return False
    setattr(node, "_smoothable_downstream", downstream)
    return True


class PrepareSmoothQuantPattern(Pattern):
    """Populate downstream linears on eligible ``FusedLayerNorm`` observers.

    Matches each ``FusedLayerNorm`` whose
    :class:`~embedl_deploy._internal.core.quantize.stubs.SmoothQuantObserver` has an
    empty ``downstream_linears`` list, ``elementwise_affine=True``, and at
    least one downstream ``FusedLinear`` / ``FusedLinearAct`` reachable through
    shape-only ops.  Populates ``downstream_linears`` on the existing observer.

    No graph topology is changed.
    """

    tree: Tree = (_is_smoothable_layer_norm,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        matches = match_tree(graph_module, pattern=self)
        for pm in matches:
            ln_node = pm.tree_match.get_node(0)
            downstream = getattr(ln_node, "_smoothable_downstream")
            pm.tree_match = TreeMatch(
                pre_trunk_nodes=pm.tree_match.pre_trunk_nodes,
                trunk_nodes=[
                    ln_node,
                    Wildcard(FusedLinearLike, nodes=tuple(downstream)),
                ],
            )
            delattr(ln_node, "_smoothable_downstream")
        return matches

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        ln_node = pattern_match.tree_match.get_node(0)
        ln_mod = resolve_module(ln_node, FusedLayerNorm)
        downstream = pattern_match.tree_match.get_node(
            1,
            is_wildcard=True,
        ).nodes

        ln_mod.smooth_quant_observer.downstream_linears = [
            cast(FusedLinearLike, resolve_module(node)).linear
            for node in downstream
        ]

        return [ln_node]
