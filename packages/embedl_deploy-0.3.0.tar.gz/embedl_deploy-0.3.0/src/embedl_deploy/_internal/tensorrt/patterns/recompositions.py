# Copyright (C) 2026 Embedl AB

"""Aten recomposition ``Pattern`` subclasses for TensorRT.

Recompositions convert lowered ``torch.ops.aten`` function calls back into
the node types required so that downstream fusion patterns can
match.  They run **before** fusion patterns as conversions.
"""

# TODO Split this file
# pylint: disable=too-many-lines

import logging
import operator
from collections.abc import Callable
from typing import TypeAlias, cast

import torch
from torch import fx, nn
from torch.fx.node import Argument, Target

from embedl_deploy._internal.core.match import match_tree
from embedl_deploy._internal.core.pattern import (
    Fork,
    Pattern,
    PatternMatch,
    SharedNodeCheck,
    Tree,
    TreeMatch,
    Wildcard,
    node_check,
)
from embedl_deploy._internal.core.replace import (
    ReplacementFn,
    get_auto_name,
    replace_tree,
)
from embedl_deploy._internal.tensorrt.patterns.utils import (
    Registry,
    RegistryFactory,
    get_input_shape,
    is_registry_op,
    is_true,
    make_cls,
    make_registry_op,
)

_LOG = logging.getLogger(__name__)


def _is_attr(name: str) -> Callable[[fx.Node], bool]:
    """Return a predicate matching ``get_attr`` nodes for attribute `name`."""

    def check(node: fx.Node) -> bool:
        return (
            node.op == "get_attr"
            and isinstance(node.target, str)
            and node.target.rpartition(".")[2] == name
        )

    return check


def _is_call_to(target: Target) -> Callable[[fx.Node], bool]:
    """Return a predicate matching ``call_function`` nodes with `target`."""

    def check(node: fx.Node) -> bool:
        return node.op == "call_function" and node.target is target

    return check


def _resolve_get_attr(node: fx.Node) -> torch.Tensor:
    """Follow a ``get_attr`` node to the actual tensor."""
    assert isinstance(node.target, str)
    obj: object = node.graph.owning_module
    for part in node.target.split("."):
        obj = getattr(obj, part)
    assert isinstance(obj, torch.Tensor)
    return obj


def _make_conv2d(conv_node: fx.Node) -> nn.Conv2d:
    """Construct an ``nn.Conv2d`` from an ``aten.conv2d.default`` node."""
    _IntPair: TypeAlias = tuple[int, int]
    _Conv2dArgs: TypeAlias = tuple[
        fx.Node, fx.Node, fx.Node | None, _IntPair, _IntPair, _IntPair, int
    ]
    args = cast(_Conv2dArgs, conv_node.args)
    weight = _resolve_get_attr(args[1])
    weight_shape = cast(tuple[int, int, int, int], weight.shape)
    bias = None
    if len(args) > 2 and args[2] is not None:
        bias = _resolve_get_attr(args[2])
    stride: _IntPair = args[3] if len(args) > 3 else (1, 1)
    padding: _IntPair = args[4] if len(args) > 4 else (0, 0)
    dilation: _IntPair = args[5] if len(args) > 5 else (1, 1)
    groups = args[6] if len(args) > 6 else 1
    conv = nn.Conv2d(
        in_channels=weight_shape[1] * groups,
        out_channels=weight_shape[0],
        kernel_size=weight_shape[2:],
        stride=stride,
        padding=padding,
        dilation=dilation,
        groups=groups,
        bias=bias is not None,
    )
    conv.weight = nn.Parameter(weight)
    if bias is not None:
        assert conv.bias is not None
        conv.bias = nn.Parameter(bias)
    # Only the input tensor should be passed as an arg to the new node.
    setattr(conv, '_arg_count', 1)
    return conv


class AtenConv2dPattern(Pattern):
    """Recompose ``aten.conv2d.default`` into an ``nn.Conv2d`` module.

    ``torch.export.export().module()`` lowers ``nn.Conv2d`` modules into
    ``aten.conv2d.default`` function calls with explicit weight and bias
    ``get_attr`` nodes.  This pattern reconstructs the original ``nn.Conv2d``
    module and inserts it as a ``call_module`` node, enabling downstream fusion
    patterns to match.

    The weight and bias ``get_attr`` nodes are included in the tree via a
    ``Fork`` whose ``perms_override`` omits the bias branch when it is
    absent.  They are erased automatically by ``replace_tree``.
    """

    is_conversion = True
    tree: Tree = Fork(
        inputs=(
            (),  # input tensor
            (_is_attr("weight"),),
            (_is_attr("bias"),),  # optional
        ),
        operator=torch.ops.aten.conv2d.default,
        output=(),
        perms_override=((0, 1, 2), (0, 1)),
    )

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        conv_node = tree_match.pre_trunk_nodes[0]
        conv = _make_conv2d(conv_node)
        return replace_tree(pattern_match, [conv])


@node_check
def _is_batchnorm2d(node: fx.Node) -> bool:
    """Return ``True`` when a ``batch_norm`` node has 4-D input."""
    is_batchnorm = False
    if node.op == "call_function":
        is_batchnorm = node.target is torch.ops.aten.batch_norm.default
    if not is_batchnorm:
        return False
    shape = get_input_shape(node)
    return shape is not None and len(shape) == 4


def _make_batchnorm2d(bn_node: fx.Node) -> nn.BatchNorm2d:
    """Construct an ``nn.BatchNorm2d`` from an aten node."""
    _BNArgs: TypeAlias = tuple[
        fx.Node,
        fx.Node | None,
        fx.Node | None,
        fx.Node | None,
        fx.Node | None,
        bool,
        float,
        float,
        bool,
    ]
    args = cast(_BNArgs, bn_node.args)
    shape = get_input_shape(bn_node)
    assert shape is not None
    num_features = shape[1]
    momentum = args[6] if len(args) > 6 else 0.1
    eps = args[7] if len(args) > 7 else 1e-5
    bn = nn.BatchNorm2d(
        num_features=num_features,
        eps=eps,
        momentum=momentum,
        affine=args[1] is not None,
        track_running_stats=args[3] is not None,
    )
    if args[1] is not None:
        assert args[2] is not None
        bn.weight = nn.Parameter(_resolve_get_attr(args[1]))
        bn.bias = nn.Parameter(_resolve_get_attr(args[2]))
    if args[3] is not None:
        assert args[4] is not None
        bn.running_mean = _resolve_get_attr(args[3])
        bn.running_var = _resolve_get_attr(args[4])
    # Only the input tensor should be passed as an arg to the new node.
    setattr(bn, '_arg_count', 1)
    return bn


class AtenBNPattern(Pattern):
    """Recompose ``aten.batch_norm.default`` into an ``nn.BatchNorm2d`` module.

    ``torch.export.export().module()`` lowers ``nn.BatchNorm2d`` modules into
    ``aten.batch_norm.default`` function calls with explicit weight, bias,
    running-mean, and running-var ``get_attr`` nodes.  This pattern
    reconstructs the original ``nn.BatchNorm2d`` module and inserts it as a
    ``call_module`` node, enabling downstream fusion patterns to match.

    Only 4-D-input calls match, ``BatchNorm1d``/``3d`` are left as aten nodes.

    All four ``get_attr`` branches are optional — the ``perms_override``
    omits weight and bias for ``affine=False`` and running-mean and
    running-var for ``track_running_stats=False``.
    """

    is_conversion = True
    tree: Tree = Fork(
        inputs=(
            (),  # input tensor
            (_is_attr("weight"),),  # optional, absent when affine=False
            (_is_attr("bias"),),  # optional, absent when affine=False
            (_is_attr("running_mean"),),  # optional, absent when trs=False
            (_is_attr("running_var"),),  # optional, absent when trs=False
        ),
        operator=_is_batchnorm2d,
        output=(),
        perms_override=((0, 1, 2, 3, 4), (0, 3, 4), (0, 1, 2), (0,)),
    )

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        bn_node = tree_match.pre_trunk_nodes[0]
        bn_node.graph.eliminate_dead_code()
        bn = _make_batchnorm2d(bn_node)
        return replace_tree(pattern_match, [bn])


def _is_relu6(node: fx.Node) -> bool:
    """Return ``True`` when a ``hardtanh`` node clamps to [0, 6]."""
    args, kwargs = node.args, node.kwargs
    min_val = args[1] if len(args) > 1 else kwargs.get("min_val", -1.0)
    max_val = args[2] if len(args) > 2 else kwargs.get("max_val", 1.0)
    min_val, max_val = cast(tuple[float, float], (min_val, max_val))
    return min_val == 0.0 and max_val == 6.0


def _make_gelu(node: fx.Node) -> nn.GELU:
    """Construct an ``nn.GELU`` from an aten node."""
    approximate = cast(str, node.kwargs.get("approximate", "none"))
    return nn.GELU(approximate=approximate)


def _make_leaky_relu(node: fx.Node) -> nn.LeakyReLU:
    """Construct an ``nn.LeakyReLU`` from an aten node."""
    args = node.args
    negative_slope = cast(float, args[1]) if len(args) > 1 else 0.01
    return nn.LeakyReLU(negative_slope=negative_slope)


def _make_elu(node: fx.Node) -> nn.ELU:
    """Construct an ``nn.ELU`` from an aten node."""
    args = node.args
    alpha = cast(float, args[1]) if len(args) > 1 else 1.0
    return nn.ELU(alpha=alpha)


def _make_prelu(node: fx.Node) -> nn.PReLU:
    """Construct an ``nn.PReLU`` from an aten node."""
    weight = _resolve_get_attr(cast(fx.Node, node.args[1]))
    prelu = nn.PReLU(num_parameters=weight.numel())
    prelu.weight = nn.Parameter(weight)
    # Only the input tensor should be passed as an arg to the new node.
    setattr(prelu, '_arg_count', 1)
    return prelu


_ACTIVATION_REGISTRY: Registry = {
    torch.ops.aten.elu.default: (is_true, _make_elu),
    torch.ops.aten.elu_.default: (is_true, _make_elu),
    torch.ops.aten.gelu.default: (is_true, _make_gelu),
    torch.ops.aten.hardsigmoid.default: (is_true, make_cls(nn.Hardsigmoid)),
    torch.ops.aten.hardsigmoid_.default: (is_true, make_cls(nn.Hardsigmoid)),
    torch.ops.aten.hardswish.default: (is_true, make_cls(nn.Hardswish)),
    torch.ops.aten.hardswish_.default: (is_true, make_cls(nn.Hardswish)),
    torch.ops.aten.hardtanh.default: (_is_relu6, make_cls(nn.ReLU6)),
    torch.ops.aten.hardtanh_.default: (_is_relu6, make_cls(nn.ReLU6)),
    torch.ops.aten.leaky_relu.default: (is_true, _make_leaky_relu),
    torch.ops.aten.leaky_relu_.default: (is_true, _make_leaky_relu),
    torch.ops.aten.mish.default: (is_true, make_cls(nn.Mish)),
    torch.ops.aten.mish_.default: (is_true, make_cls(nn.Mish)),
    torch.ops.aten.prelu.default: (is_true, _make_prelu),
    torch.ops.aten.relu.default: (is_true, make_cls(nn.ReLU)),
    torch.ops.aten.relu_.default: (is_true, make_cls(nn.ReLU)),
    torch.ops.aten.sigmoid.default: (is_true, make_cls(nn.Sigmoid)),
    torch.ops.aten.silu.default: (is_true, make_cls(nn.SiLU)),
    torch.ops.aten.silu_.default: (is_true, make_cls(nn.SiLU)),
    torch.ops.aten.tanh.default: (is_true, make_cls(nn.Tanh)),
}


class AtenActivationPattern(Pattern):
    """Recompose aten activation calls into ``ActivationLike`` modules.

    ``torch.export.export().module()`` lowers activation modules
    (``nn.ReLU``, ``nn.GELU``, ``nn.PReLU``, etc.) into ``aten`` function
    calls.  This pattern matches those calls and reconstructs the
    corresponding ``nn.Module``, inserting it as a ``call_module`` node so
    that downstream fusion patterns can match.

    The activation type and hyperparameters (e.g. ``negative_slope`` for
    ``nn.LeakyReLU``) are reconstructed from the aten node's arguments.
    ``nn.ReLU6`` is reconstructed from ``aten.hardtanh.default`` with
    ``min_val=0`` and ``max_val=6``. ``aten.hardtanh.default`` nodes with
    other clamp bounds are left as aten nodes.

    ``nn.PReLU`` carries a learnable weight tensor exposed as a
    ``get_attr`` node.  The ``Fork`` with ``perms_override`` matches
    this branch when present and lets ``replace_tree`` erase it.
    """

    is_conversion = True
    tree: Tree = Fork(
        inputs=(
            (),  # input tensor
            (_is_attr("weight"),),  # optional — present for PReLU
        ),
        operator=is_registry_op(_ACTIVATION_REGISTRY),
        output=(),
        perms_override=((0,), (0, 1)),
    )

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        act_node = tree_match.pre_trunk_nodes[0]
        act = make_registry_op(_ACTIVATION_REGISTRY)(act_node)
        return replace_tree(pattern_match, [act])


def _is_aten_add(node: fx.Node) -> bool:
    """Return ``True`` for ``aten.add.Tensor`` / ``aten.add_.Tensor`` with ``alpha=1``."""
    is_add = False
    if node.op == "call_function":
        is_add = node.target in (
            torch.ops.aten.add.Tensor,
            torch.ops.aten.add_.Tensor,
        )
    if not is_add:
        return False
    alpha = node.kwargs.get("alpha", 1)
    assert isinstance(alpha, int | float)
    return alpha == 1


def _get_add_insert(add_node: fx.Node) -> ReplacementFn:
    """Return a replacement function that inserts an ``operator.add`` node."""

    def _insert(
        graph_module: fx.GraphModule,
        prev_args: tuple[fx.Node, ...],
    ) -> list[fx.Node]:
        with graph_module.graph.inserting_before(add_node):
            node = graph_module.graph.call_function(operator.add, prev_args)
        return [node]

    return _insert


class AtenAddPattern(Pattern):
    """Recompose ``aten.add.Tensor`` / ``aten.add_.Tensor`` into ``operator.add``.

    ``torch.export.export().module()`` lowers Python's ``+`` operator on
    tensors into ``aten.add.Tensor`` and ``+=`` into ``aten.add_.Tensor``.
    Downstream fusion patterns (e.g. ``ConvBNAddActPattern``) match
    ``operator.add`` ``call_function`` nodes. This pattern rewrites both
    targets so that those fusions can match — the in-place form is what
    torchvision residual blocks (``out += identity``) emit.

    The aten ops carry an ``alpha`` parameter because they are also the
    lowering of ``torch.add(input, other, alpha=...)``. However, since it
    is only the lowering of the ``+`` / ``+=`` operators on tensors that
    needs to be recomposed, only nodes with ``alpha=1`` are matched.
    ``aten.add.Scalar`` and ``aten.add.out`` nodes are ignored.
    """

    is_conversion = True
    tree: Tree = (_is_aten_add,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        add_node = tree_match.get_node(0)
        add_insert = _get_add_insert(add_node)
        return replace_tree(pattern_match, [add_insert])


class AtenAdaptiveAvgPool2dPattern(Pattern):
    """Recompose ``aten.adaptive_avg_pool2d.default`` into ``nn.AdaptiveAvgPool2d``.

    ``torch.export.export().module()`` lowers ``nn.AdaptiveAvgPool2d`` modules
    into ``aten.adaptive_avg_pool2d.default`` function calls with the output
    size embedded as a literal ``list[int]`` argument.  This pattern
    reconstructs the original ``nn.AdaptiveAvgPool2d`` module and inserts it
    as a ``call_module`` node, enabling downstream fusion and conversion
    patterns to match.
    """

    is_conversion = True
    tree: Tree = (_is_call_to(torch.ops.aten.adaptive_avg_pool2d.default),)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        pool_node = tree_match.get_node(0)
        output_size = cast(list[int], pool_node.args[1])
        pool = nn.AdaptiveAvgPool2d(tuple(output_size))
        return replace_tree(pattern_match, [pool])


def _make_linear(linear_node: fx.Node) -> nn.Linear:
    """Construct an ``nn.Linear`` from an ``aten.linear.default`` node."""
    _LinearArgs: TypeAlias = tuple[fx.Node, fx.Node, fx.Node | None]
    args = cast(_LinearArgs, linear_node.args)
    weight = _resolve_get_attr(args[1])
    out_features, in_features = weight.shape
    bias = None
    if len(args) > 2 and args[2] is not None:
        bias = _resolve_get_attr(args[2])
    linear = nn.Linear(
        in_features=in_features,
        out_features=out_features,
        bias=bias is not None,
    )
    linear.weight = nn.Parameter(weight)
    if bias is not None:
        assert linear.bias is not None
        linear.bias = nn.Parameter(bias)
    # Only the input tensor should be passed as an arg to the new node.
    setattr(linear, '_arg_count', 1)
    return linear


class AtenLinearPattern(Pattern):
    """Recompose ``aten.linear.default`` into an ``nn.Linear`` module.

    ``torch.export.export().module()`` lowers ``nn.Linear`` modules into
    ``aten.linear.default`` function calls with explicit weight and bias
    ``get_attr`` nodes.  This pattern reconstructs the original ``nn.Linear``
    module and inserts it as a ``call_module`` node, enabling downstream fusion
    patterns to match.

    The weight and bias ``get_attr`` nodes are included in the tree via a
    ``Fork`` whose ``perms_override`` omits the bias branch when it is
    absent. They are erased automatically by ``replace_tree``.
    """

    is_conversion = True
    tree: Tree = Fork(
        inputs=(
            (),  # input tensor
            (_is_attr("weight"),),
            (_is_attr("bias"),),  # optional
        ),
        operator=torch.ops.aten.linear.default,
        output=(),
        perms_override=((0, 1, 2), (0, 1)),
    )

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        linear_node = tree_match.pre_trunk_nodes[0]
        linear = _make_linear(linear_node)
        return replace_tree(pattern_match, [linear])


def _make_flatten(flatten_node: fx.Node) -> nn.Flatten:
    """Construct an ``nn.Flatten`` from an ``aten.flatten.using_ints`` node.

    Note that ``torch.export`` omits scalar arguments that equal the aten
    schema defaults. The aten schema uses ``start_dim=0`` and ``end_dim=-1`` as
    default values. ``nn.Flatten`` defaults to ``start_dim=1``, so
    ``nn.Flatten()`` exports as ``(x, 1)`` — start_dim is present because 1 !=
    0. But ``nn.Flatten(start_dim=0)`` exports as ``(x,)`` — start_dim is
    omitted because 0 matches the aten default.  The fallback here must
    therefore use the aten defaults, not the ``nn.Flatten`` defaults.
    """
    args = cast(tuple[fx.Node, int, int], flatten_node.args)
    start_dim = args[1] if len(args) > 1 else 0
    end_dim = args[2] if len(args) > 2 else -1
    flatten = nn.Flatten(start_dim=start_dim, end_dim=end_dim)
    # Only the input tensor should be passed as an arg to the new node.
    setattr(flatten, '_arg_count', 1)
    return flatten


class AtenFlattenPattern(Pattern):
    """Recompose ``aten.flatten.using_ints`` into an ``nn.Flatten`` module.

    ``torch.export.export().module()`` lowers ``nn.Flatten`` and
    ``torch.flatten`` into ``aten.flatten.using_ints`` function calls with
    scalar ``start_dim`` and ``end_dim`` arguments. This pattern reconstructs
    the ``nn.Flatten`` module and inserts it as a ``call_module`` node,
    enabling downstream fusion patterns to match.
    """

    is_conversion = True
    tree: Tree = (_is_call_to(torch.ops.aten.flatten.using_ints),)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        flatten_node = tree_match.get_node(0)
        flatten = _make_flatten(flatten_node)
        return replace_tree(pattern_match, [flatten])


def _make_layer_norm(ln_node: fx.Node) -> nn.LayerNorm:
    """Construct an ``nn.LayerNorm`` from an ``aten.layer_norm.default`` node."""
    args = ln_node.args
    normalized_shape = cast(list[int], args[1])
    weight_node = args[2] if len(args) > 2 else None
    bias_node = args[3] if len(args) > 3 else None
    eps = cast(float, args[4]) if len(args) > 4 else 1e-5
    has_weight = weight_node is not None
    has_bias = bias_node is not None
    ln = nn.LayerNorm(
        normalized_shape=normalized_shape,
        eps=eps,
        elementwise_affine=has_weight,
        bias=has_bias,
    )
    if has_weight:
        assert isinstance(weight_node, fx.Node)
        ln.weight = nn.Parameter(_resolve_get_attr(weight_node))
    if has_bias:
        assert isinstance(bias_node, fx.Node)
        ln.bias = nn.Parameter(_resolve_get_attr(bias_node))
    # Only the input tensor should be passed as an arg to the new node.
    setattr(ln, '_arg_count', 1)
    return ln


class AtenLayerNormPattern(Pattern):
    """Recompose ``aten.layer_norm.default`` into an ``nn.LayerNorm`` module.

    ``torch.export.export().module()`` lowers ``nn.LayerNorm`` modules into
    ``aten.layer_norm.default`` function calls with separate ``get_attr`` nodes
    for the weight and bias when those are present.  This pattern reconstructs
    the original ``nn.LayerNorm`` module and inserts it as a ``call_module``
    node, enabling downstream fusion patterns to match.

    The weight and bias ``get_attr`` nodes are included in the tree via a
    ``Fork`` with three permutations: weight + bias
    (``elementwise_affine=True``), weight only (``elementwise_affine=True,
    bias=False``), and neither (``elementwise_affine=False``).  Matched
    ``get_attr`` nodes are erased automatically by ``replace_tree``.
    """

    is_conversion = True
    tree: Tree = Fork(
        inputs=(
            (),  # input tensor
            (_is_attr("weight"),),  # optional
            (_is_attr("bias"),),  # optional
        ),
        operator=torch.ops.aten.layer_norm.default,
        output=(),
        perms_override=((0, 1, 2), (0, 1), (0,)),
    )

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        ln_node = tree_match.pre_trunk_nodes[0]
        ln = _make_layer_norm(ln_node)
        return replace_tree(pattern_match, [ln])


def _make_max_pool2d(pool_node: fx.Node) -> nn.MaxPool2d:
    """Construct an ``nn.MaxPool2d`` from an ``aten.max_pool2d.default`` node."""
    args = pool_node.args
    kernel_size = cast(list[int], args[1])
    stride = cast(list[int], args[2]) if len(args) > 2 else kernel_size
    padding = cast(list[int], args[3]) if len(args) > 3 else [0, 0]
    dilation = cast(list[int], args[4]) if len(args) > 4 else [1, 1]
    ceil_mode = cast(bool, args[5]) if len(args) > 5 else False
    return nn.MaxPool2d(
        kernel_size=tuple(kernel_size),
        stride=tuple(stride),
        padding=tuple(padding),
        dilation=tuple(dilation),
        ceil_mode=ceil_mode,
    )


class AtenMaxPool2dPattern(Pattern):
    """Recompose ``aten.max_pool2d.default`` into an ``nn.MaxPool2d`` module.

    ``torch.export.export().module()`` lowers ``nn.MaxPool2d`` modules into
    ``aten.max_pool2d.default`` function calls with kernel size, stride,
    padding, dilation, and ceil-mode as literal arguments.  This pattern
    reconstructs the original ``nn.MaxPool2d`` module and inserts it as a
    ``call_module`` node, enabling downstream fusion patterns
    (``StemConvBNActMaxPoolPattern``, etc.) to match.

    ``nn.MaxPool2d(return_indices=True)`` is lowered to
    ``aten.max_pool2d_with_indices.default`` instead, which produces a tuple
    output with ``getitem`` consumers rather than a tensor output. Therefore
    that variant is not covered by this pattern.
    """

    is_conversion = True
    tree: Tree = (_is_call_to(torch.ops.aten.max_pool2d.default),)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        pool_node = tree_match.get_node(0)
        pool = _make_max_pool2d(pool_node)
        return replace_tree(pattern_match, [pool])


_ShapeOpEntry: TypeAlias = tuple[str, bool]

_SHAPE_OP_REGISTRY: dict[object, _ShapeOpEntry] = {
    torch.ops.aten.view.default: ("view", True),
    torch.ops.aten.reshape.default: ("reshape", True),
    torch.ops.aten.permute.default: ("permute", True),
    torch.ops.aten.transpose.int: ("transpose", False),
    torch.ops.aten.contiguous.default: ("contiguous", False),
}


def _is_shape_op(node: fx.Node) -> bool:
    """Return ``True`` for aten shape ops in the registry."""
    return node.op == "call_function" and node.target in _SHAPE_OP_REGISTRY


def _get_shape_op_insert(
    shape_node: fx.Node,
) -> ReplacementFn:
    """Return a replacement inserting a ``call_method`` node."""
    method_name, varargs_as_list = _SHAPE_OP_REGISTRY[shape_node.target]

    def _insert(
        graph_module: fx.GraphModule,
        prev_args: tuple[fx.Node, ...],
    ) -> list[fx.Node]:
        if varargs_as_list:
            varargs = cast(list[Argument], shape_node.args[1])
        else:
            varargs = list(shape_node.args[1:])
        args = (prev_args[0], *varargs)
        with graph_module.graph.inserting_before(shape_node):
            node = graph_module.graph.call_method(
                method_name, args, shape_node.kwargs
            )
        return [node]

    return _insert


class AtenShapeOpsPattern(Pattern):
    """Recompose aten shape ops into ``call_method`` nodes.

    ``torch.export.export().module()`` lowers tensor method calls such as
    ``.view()``, ``.reshape()``, ``.permute()``, ``.transpose()``, and
    ``.contiguous()`` into ``aten`` function calls.  Downstream patterns
    (``PropagateQuantStubPattern``, ``PrepareSmoothQuantPattern``) match
    these operations by their ``call_method`` target string.  This pattern
    rewrites the aten nodes back to ``call_method`` nodes so that those
    downstream predicates continue to match.
    """

    is_conversion = True
    tree: Tree = (_is_shape_op,)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        shape_node = tree_match.get_node(0)
        shape_insert = _get_shape_op_insert(shape_node)
        return replace_tree(pattern_match, [shape_insert])


def _is_4d_input(node: fx.Node) -> bool:
    """Return ``True`` when `node` has a 4-D input tensor."""
    shape = get_input_shape(node)
    return shape is not None and len(shape) == 4


def _make_dropout(
    cls: type[nn.Dropout | nn.Dropout2d],
    inplace: bool,
) -> RegistryFactory:
    """Return a factory that builds `cls` from an aten dropout node.

    The aten node's ``train`` argument is mirrored onto the fresh module so
    that an eval-mode export yields a module with ``training=False``.
    """

    def factory(node: fx.Node) -> nn.Module:
        args = node.args
        p = cast(float, args[1]) if len(args) > 1 else 0.5
        train = cast(bool, args[2]) if len(args) > 2 else True
        dropout = cls(p=p, inplace=inplace)
        if not train:
            dropout.eval()
        return dropout

    return factory


_DROPOUT_REGISTRY: Registry = {
    torch.ops.aten.dropout.default: (
        is_true,
        _make_dropout(nn.Dropout, inplace=False),
    ),
    torch.ops.aten.dropout_.default: (
        is_true,
        _make_dropout(nn.Dropout, inplace=True),
    ),
    torch.ops.aten.feature_dropout.default: (
        _is_4d_input,
        _make_dropout(nn.Dropout2d, inplace=False),
    ),
    torch.ops.aten.feature_dropout_.default: (
        _is_4d_input,
        _make_dropout(nn.Dropout2d, inplace=True),
    ),
}


class AtenDropoutPattern(Pattern):
    """Recompose aten dropout calls into ``nn.Dropout`` / ``nn.Dropout2d``.

    ``torch.export.export().module()`` lowers dropout modules into aten
    function calls:

    - ``nn.Dropout`` -> ``aten.dropout.default``
    - ``nn.Dropout(inplace=True)`` -> ``aten.dropout_.default``
    - ``nn.Dropout2d`` -> ``aten.feature_dropout.default``
    - ``nn.Dropout2d(inplace=True)`` -> ``aten.feature_dropout_.default``

    This pattern matches those calls and reconstructs the corresponding
    ``nn.Module``, inserting it as a ``call_module`` node so that downstream
    fusion patterns can match.

    Because ``F.dropout`` and ``torch.dropout`` share the same aten op path as
    ``nn.Dropout``, this pattern will also match functional-form dropout
    calls. They are indistinguishable after ``torch.export``.

    ``nn.Dropout1d`` and ``nn.Dropout3d`` also lower to
    ``aten.feature_dropout`` — the aten op does not encode the source rank.
    This pattern only matches the 4-D (``nn.Dropout2d``) case; 1-D and 3-D
    feature-dropout nodes are left in the graph as aten nodes.

    Note that the ``GraphModule`` returned by ``.module()`` defaults to
    ``training=True`` regardless of the source model's mode. The recomposed
    ``nn.Dropout`` / ``nn.Dropout2d`` mirrors the aten node's ``train``
    argument onto its initial ``training`` flag so the starting state matches
    export time.
    """

    is_conversion = True
    tree: Tree = (is_registry_op(_DROPOUT_REGISTRY),)

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(graph_module, pattern=self)

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match

        dropout_node = tree_match.get_node(0)
        dropout = make_registry_op(_DROPOUT_REGISTRY)(dropout_node)
        return replace_tree(pattern_match, [dropout])


# Shared components for MHA recomposition
# Used by both the need_weights=True and need_weights=False patterns

# Two graph-level flags carry context between predicates within a single
# match attempt. They live on the graph (not on a node) because the
# writer and the readers run on different nodes during the same attempt,
# so there is no shared node to attach them to.
#
# The module path of the MHA candidate under match (e.g.,
# ``transformer.layers.0.self_attn``)
_MHA_ACTIVE_PREFIX_ATTR = "_mha_active_prefix"

# A boolean flag that is set when the outer tree's optional ``Wildcard``
# absorbs a trailing transpose (the ``batch_first=True`` bookend).
_MHA_TIP_TRANSPOSE_ATTR = "_mha_tip_transpose"


# Predicates


@node_check
def _is_mha_in_proj_linear(node: fx.Node) -> bool:
    """Match the in-proj ``aten.linear.default`` of a canonical MHA.

    Q-branch Fork ``operator``. Accepts linears whose weight is
    ``*.in_proj_weight``.
    """
    if (
        node.op != "call_function"
        or node.target is not torch.ops.aten.linear.default
        or len(node.args) < 2
    ):
        return False

    weight_node = node.args[1]
    return (
        isinstance(weight_node, fx.Node)
        and weight_node.op == "get_attr"
        and isinstance(weight_node.target, str)
        and weight_node.target.endswith(".in_proj_weight")
    )


@node_check
def _is_mha_out_proj_linear(node: fx.Node) -> bool:
    """Match ``aten.linear.default`` at an ``nn.MultiheadAttention.out_proj``.

    Outer MHA Fork ``operator``. Accepts only linears whose weight is
    ``<mha>.out_proj.weight`` under a module with the structural signature
    of ``nn.MultiheadAttention``. Detects and warns on unsupported
    variants (``_qkv_same_embed_dim=False``, ``add_bias_kv=True``,
    ``batch_first=False``).

    The outer tree's tip ``Wildcard(quantifier="?")`` matches zero or one
    transpose, so it can absorb nothing in two cases:

    - **Duplicate match attempt.** The matcher tries the "absorb 0"
      branch even when a downstream transpose exists. The candidate then
      has a ``view → transpose`` chain hanging off the linear's only
      user. This predicate detects that and rejects so an
      already-recomposed MHA is not re-matched.
    - **Genuine** ``batch_first=False``. No trailing transpose exists at
      all; the variant is unsupported and rejected with a warning.

    ``_is_mha_tip_transpose`` signals via the graph-level flag
    ``_MHA_TIP_TRANSPOSE_ATTR`` when the wildcard *did* absorb a
    transpose. This predicate consumes that flag (reads it, then clears
    it via ``delattr``) so the next match attempt starts fresh; without
    the clear, a stale ``True`` from a prior candidate would mislead the
    next one into accepting a duplicate.
    """
    if (
        node.op != "call_function"
        or node.target is not torch.ops.aten.linear.default
        or len(node.args) < 2
    ):
        return False

    weight_node = node.args[1]

    if (
        not isinstance(weight_node, fx.Node)
        or weight_node.op != "get_attr"
        or not isinstance(weight_node.target, str)
        or not weight_node.target.endswith(".out_proj.weight")
    ):
        return False

    tip_exists = (
        len(users := list(node.users)) == 1
        and users[0].target is torch.ops.aten.view.default
        and any(
            isinstance(user, fx.Node)
            and user.target is torch.ops.aten.transpose.int
            for user in users[0].users
        )
    )

    tip_node = getattr(node.graph, _MHA_TIP_TRANSPOSE_ATTR, None)
    if (
        isinstance(tip_node, fx.Node)
        and len(tip_node.args) >= 1
        and isinstance(tip_node.args[0], fx.Node)
        and len(tip_node.args[0].args) >= 1
        and tip_node.args[0].args[0] is node
    ):
        delattr(node.graph, _MHA_TIP_TRANSPOSE_ATTR)
    elif tip_exists:
        # Wildcard skipped an existing transpose; duplicate match.
        return False

    prefix = weight_node.target.removesuffix(".out_proj.weight")
    parent: object = node.graph.owning_module
    for part in prefix.split("."):
        parent = getattr(parent, part)

    # Skip silently when the parent is not an ``nn.MultiheadAttention``-shaped
    # module — non-MHA modules with an ``out_proj`` Linear child must not
    # produce spurious "Skipping MHA at ..." warnings.
    if not (
        hasattr(parent, "in_proj_weight") or hasattr(parent, "q_proj_weight")
    ):
        return False

    reasons: list[str] = []
    if hasattr(parent, "q_proj_weight"):
        reasons.append("_qkv_same_embed_dim=False not supported")
    if getattr(parent, "bias_k", None) is not None:
        reasons.append("add_bias_kv=True not supported")
    if not tip_exists:
        reasons.append("batch_first=False not supported")
    if reasons:
        _LOG.warning("Skipping MHA at %s: %s", prefix, "; ".join(reasons))
        return False

    setattr(node.graph, _MHA_ACTIVE_PREFIX_ATTR, prefix)
    return True


def _is_mha_tip_transpose(node: fx.Node) -> bool:
    """Match ``aten.transpose.int`` and signal the outer MHA tree tip."""
    if (
        node.op != "call_function"
        or node.target is not torch.ops.aten.transpose.int
    ):
        return False

    setattr(node.graph, _MHA_TIP_TRANSPOSE_ATTR, node)
    return True


# Tree toolbox


def _is_select_int_idx(idx: int) -> Callable[[fx.Node], bool]:
    """Return a predicate matching ``aten.select.int(x, 0, idx)`` nodes."""

    def check(node: fx.Node) -> bool:
        return (
            node.op == "call_function"
            and node.target is torch.ops.aten.select.int
            and len(node.args) >= 3
            and cast(int, node.args[2]) == idx
        )

    return check


_is_view_default = _is_call_to(torch.ops.aten.view.default)
_is_transpose_int = _is_call_to(torch.ops.aten.transpose.int)
_is_contiguous_default = _is_call_to(torch.ops.aten.contiguous.default)
_is_unflatten_int = _is_call_to(torch.ops.aten.unflatten.int)
_is_unsqueeze_default = _is_call_to(torch.ops.aten.unsqueeze.default)
_is_squeeze_dim = _is_call_to(torch.ops.aten.squeeze.dim)


# Build helpers


def _find_get_attr_by_suffix(
    nodes: list[fx.Node], suffix: str
) -> fx.Node | None:
    """Return ``get_attr`` in `nodes` whose target ends with `suffix`."""
    for node in nodes:
        if node.op == "get_attr":
            assert isinstance(node.target, str)
            if node.target.endswith(suffix):
                return node
    return None


def _recover_head_dim(trunk_nodes: list[fx.Node]) -> int:
    """Recover ``head_dim`` from a Q/K/V view node in `trunk_nodes`.

    ``need_weights=True`` graphs reshape Q/K/V to
    ``[seq, bsz * num_heads, head_dim]`` (3-element, head_dim at index 2).
    ``need_weights=False`` (SDPA) graphs reshape to
    ``[bsz, num_heads, seq, head_dim]`` (4-element, head_dim at index 3).
    """
    for node in trunk_nodes:
        if (
            node.op == "call_function"
            and node.target is torch.ops.aten.view.default
            and len(node.args) >= 2
        ):
            shape = node.args[1]
            if isinstance(shape, list) and len(shape) == 3:
                return int(cast(int, shape[2]))
            if isinstance(shape, list) and len(shape) == 4:
                return int(cast(int, shape[3]))
    raise ValueError("No 3-element or 4-element view shape in trunk_nodes.")


def _get_mha_insert(mha: nn.MultiheadAttention) -> ReplacementFn:
    """Return a replacement that inserts a self-attention MHA call_module.

    Self-attention triplicates the source tensor as the Q/K/V inputs (the
    ``SharedNodeCheck`` pinning all three branches to a single ``contiguous``
    node enforces this structurally), so the insertion emits ``call_module(mha,
    (x, x, x))`` followed by ``getitem(..., 0)`` to extract ``attn_output``
    from the ``(attn_output, attn_weights)`` tuple that
    ``nn.MultiheadAttention.forward`` returns. The ``attn_weights`` element is
    dropped, and ``_is_softmax_with_dead_branch`` splices its sibling ``view →
    mean`` chain into the trunk so ``replace_tree`` erases that as well.

    The triplicated call signature and the tuple unwrap can't be expressed via
    the ``_arg_count`` ``setattr`` used by other recompositions in this file,
    so the nodes are emitted manually here. The returned ``[call_module,
    getitem]`` pair gives ``replace_tree`` both the head of the inserted block
    (wired to the source input) and the tail (the value that downstream
    consumers should read).

    Dropping ``attn_weights`` is safe because ``_is_softmax_with_dead_branch``
    rejects the match when the ``view → mean`` chain has live users, so by the
    time this insert runs the second tuple element is guaranteed to be
    unconsumed.

    The call defaults to ``need_weights=True`` even when the source graph
    came from the SDPA path. This ``call_module`` is a structural
    placeholder that ``DecomposeMultiheadAttentionPattern`` replaces with
    explicit submodules before any forward pass, so the kwarg has no
    observable effect. Consumers that skip the decomposition step would
    re-execute the slow ``bmm + softmax + bmm`` path and need to override
    this default.
    """

    def _insert(
        graph_module: fx.GraphModule,
        prev_args: tuple[fx.Node, ...],
    ) -> list[fx.Node]:
        (source_input,) = prev_args
        name = get_auto_name(graph_module, mha)
        graph_module.add_module(name, mha)
        graph = graph_module.graph

        with graph.inserting_after(source_input):
            mha_call = graph.call_module(
                name, (source_input, source_input, source_input)
            )
        with graph.inserting_after(mha_call):
            attn_output = graph.call_function(operator.getitem, (mha_call, 0))

        return [mha_call, attn_output]

    return _insert


def _make_multihead_attention(
    trunk_nodes: list[fx.Node],
) -> nn.MultiheadAttention:
    """Construct an ``nn.MultiheadAttention`` from the recovered MHA trunk.

    Always built with ``batch_first=True``, ``dropout=0.0``, and the
    device/dtype of ``in_proj_weight``. Non-canonical variants
    (``_qkv_same_embed_dim=False``, ``add_bias_kv=True``,
    ``add_zero_attn=True``, ``batch_first=False``) are filtered upstream.
    """
    in_proj_weight_node = _find_get_attr_by_suffix(
        trunk_nodes, ".in_proj_weight"
    )
    in_proj_bias_node = _find_get_attr_by_suffix(trunk_nodes, ".in_proj_bias")
    out_proj_weight_node = _find_get_attr_by_suffix(
        trunk_nodes, ".out_proj.weight"
    )
    out_proj_bias_node = _find_get_attr_by_suffix(
        trunk_nodes, ".out_proj.bias"
    )
    assert in_proj_weight_node is not None
    assert out_proj_weight_node is not None

    in_proj_weight = _resolve_get_attr(in_proj_weight_node)
    embed_dim = in_proj_weight.shape[1]
    head_dim = _recover_head_dim(trunk_nodes)
    num_heads = embed_dim // head_dim

    mha = nn.MultiheadAttention(
        embed_dim=embed_dim,
        num_heads=num_heads,
        dropout=0.0,
        bias=in_proj_bias_node is not None,
        batch_first=True,
        device=in_proj_weight.device,
        dtype=in_proj_weight.dtype,
    )

    mha.in_proj_weight = nn.Parameter(in_proj_weight)
    if in_proj_bias_node is not None:
        mha.in_proj_bias = nn.Parameter(_resolve_get_attr(in_proj_bias_node))
    mha.out_proj.weight = nn.Parameter(_resolve_get_attr(out_proj_weight_node))
    if out_proj_bias_node is not None:
        assert mha.out_proj.bias is not None
        mha.out_proj.bias = nn.Parameter(_resolve_get_attr(out_proj_bias_node))

    return mha


# need_weights=True components for AtenMultiheadAttentionPattern.
#
# With ``need_weights=True`` (the default ``mha(x, x, x)`` call),
# ``torch.export`` emits the explicit ``bmm + softmax + bmm`` lowering
# because the fused SDPA kernel can't return the intermediate attention
# weights. The patterns below match those explicit aten nodes.

_MHA_SOFTMAX_DEAD_BRANCH_ATTR = "_mha_softmax_dead_branch"


@node_check
def _is_mha_bmm(node: fx.Node) -> bool:
    """Match ``aten.bmm.default`` whose args contain no ``aten.cat``.

    ``add_zero_attn=True`` inserts ``aten.cat`` nodes that pad K and V
    with zeros. The ``cat`` output feeds directly into the bmm, so a
    single-hop check on each arg is sufficient.
    """
    if (
        node.op != "call_function"
        or node.target is not torch.ops.aten.bmm.default
    ):
        return False

    for arg in node.args:
        if (
            isinstance(arg, fx.Node)
            and arg.op == "call_function"
            and arg.target is torch.ops.aten.cat.default
        ):
            prefix = getattr(node.graph, _MHA_ACTIVE_PREFIX_ATTR, "<unknown>")
            _LOG.warning(
                "Skipping MHA at %s: add_zero_attn=True not supported",
                prefix,
            )
            return False

    return True


def _is_softmax_with_dead_branch(node: fx.Node) -> bool:
    """Match ``aten.softmax.int`` with a ``need_weights`` view→mean sibling.

    With the default ``need_weights=True``, ``torch.export`` emits a
    ``view → mean`` chain off the softmax that produces
    ``attn_output_weights`` (the per-head softmax averaged across heads),
    the second element of ``nn.MultiheadAttention.forward``'s output
    tuple. The recomposed ``nn.MultiheadAttention`` produces both tuple
    elements from its own internal kernel, so this chain becomes
    redundant once recomposition runs and is erased alongside the main
    body.

    The chain is not a fork convergence so it does not fit ``Fork``. As a
    narrow workaround for MHA, this predicate collects the two chain nodes and
    stashes them on the softmax node as ``_MHA_SOFTMAX_DEAD_BRANCH_ATTR``.
    ``AtenMultiheadAttentionPattern.match`` retrieves the attribute, deletes
    it, and splices the nodes into the flat trunk so ``replace_tree`` erases
    them.

    Rejects the match with a warning when ``mean`` has live users — that
    signals the source model consumes ``attn_weights`` and recomposing
    would erase a live node, silently dropping a value the source reads.
    """

    if (
        node.op != "call_function"
        or node.target is not torch.ops.aten.softmax.int
    ):
        return False

    users = list(node.users)
    if len(users) != 2:
        return False

    live_bmm = next(
        (user for user in users if user.target is torch.ops.aten.bmm.default),
        None,
    )
    dead_view = next(
        (user for user in users if user.target is torch.ops.aten.view.default),
        None,
    )
    if live_bmm is None or dead_view is None:
        return False

    if len(dead_view.users) != 1:
        return False

    (dead_mean,) = dead_view.users
    if dead_mean.target is not torch.ops.aten.mean.dim:
        return False

    if dead_mean.users:
        prefix = getattr(node.graph, _MHA_ACTIVE_PREFIX_ATTR, "<unknown>")
        _LOG.warning(
            "Skipping MHA at %s: attn_weights consumed by user code",
            prefix,
        )
        return False

    setattr(node, _MHA_SOFTMAX_DEAD_BRANCH_ATTR, [dead_view, dead_mean])
    return True


_is_mul_tensor = _is_call_to(torch.ops.aten.mul.Tensor)


# SharedNodeCheck pinning the three Q/K/V branches to the same contiguous
# (need_weights=True pattern only).
_shared_contiguous = SharedNodeCheck(_is_contiguous_default)


# Q branch: in-proj Fork whose output trunk spans linear → ... → contiguous
# → select(0) → view → transpose → mul. The source-tensor input %x hangs
# off the Fork's first branch (a single transpose, for batch_first=True).
_MHA_Q_BRANCH: Tree = Fork(
    inputs=(
        (_is_transpose_int,),
        (_is_attr("in_proj_weight"),),
        (_is_attr("in_proj_bias"),),  # optional
    ),
    operator=_is_mha_in_proj_linear,
    output=(
        _is_unflatten_int,
        _is_unsqueeze_default,
        _is_transpose_int,
        _is_squeeze_dim,
        _shared_contiguous,
        _is_select_int_idx(0),
        _is_view_default,
        _is_transpose_int,
        _is_mul_tensor,
    ),
    perms_override=((0, 1, 2), (0, 1)),
)

# K branch: select(1) → view → transpose → K-transpose. Rooted at the
# shared contiguous so the SharedNodeCheck fires.
_MHA_K_BRANCH: Tree = (
    _shared_contiguous,
    _is_select_int_idx(1),
    _is_view_default,
    _is_transpose_int,
    _is_transpose_int,
)

# V branch: select(2) → view → transpose. Also rooted at shared contiguous.
_MHA_V_BRANCH: Tree = (
    _shared_contiguous,
    _is_select_int_idx(2),
    _is_view_default,
    _is_transpose_int,
)

# Fork at the Q·Kᵀ bmm: branches are Q (in-proj Fork) and K (trunk). The
# output trunk is a single softmax whose dead need_weights branch is
# collected by _is_softmax_with_dead_branch.
_MHA_QK_BMM_FORK: Tree = Fork(
    inputs=(_MHA_Q_BRANCH, _MHA_K_BRANCH),
    operator=torch.ops.aten.bmm.default,
    output=(_is_softmax_with_dead_branch,),
)

# Fork at the attention·V bmm: branches are the Q·Kᵀ subtree (attn weights)
# and V. The output trunk runs transpose → contiguous → view up to the
# out-proj linear. (batch_first=False is rejected by
# _is_mha_out_proj_linear before the matcher reaches this Fork.)
_MHA_ATTN_V_BMM_FORK: Tree = Fork(
    inputs=(_MHA_QK_BMM_FORK, _MHA_V_BRANCH),
    operator=_is_mha_bmm,
    output=(
        _is_transpose_int,
        _is_contiguous_default,
        _is_view_default,
    ),
)

# Outer Fork at the out-proj linear. Output trunk runs view → transpose
# (the batch_first=True bookend). The trailing transpose is
# Wildcard-optional so that match_tree can reach _is_mha_out_proj_linear
# for batch_first=False graphs (the operator rejects and warns).
# _is_mha_tip_transpose signals the operator via a graph attribute so it
# can distinguish a duplicate (Wildcard absorbed nothing but the
# transpose exists) from a genuine batch_first=False graph.
_MHA_TREE: Tree = Fork(
    inputs=(
        _MHA_ATTN_V_BMM_FORK,
        (_is_attr("weight"),),
        (_is_attr("bias"),),  # optional
    ),
    operator=_is_mha_out_proj_linear,
    output=(
        _is_view_default,
        Wildcard(_is_mha_tip_transpose, quantifier="?"),
    ),
    perms_override=((0, 1, 2), (0, 1)),
)


class AtenMultiheadAttentionPattern(Pattern):
    """Recompose an exported ``nn.MultiheadAttention`` subgraph into a module.

    ``torch.export.export().module()`` lowers ``nn.MultiheadAttention``
    into a long chain of ``aten`` calls. This pattern expresses the
    exported topology as nested ``Fork`` instances rooted at the out-proj
    linear and rebuilds a single ``nn.MultiheadAttention`` ``call_module``
    so downstream fusion patterns can match. ``SharedNodeCheck`` pins the
    three Q/K/V branches to the same ``contiguous`` node.

    .. code-block:: text

                     x
                     │
                     transpose
                     │
                     linear ← in_proj_weight, in_proj_bias?
                     │
                     unflatten
                     │
                     unsqueeze
                     │
                     transpose
                     │
                     squeeze
                     │
                     contiguous (shared by Q/K/V)
                     │
        ┌────────────┬────────────┐
        │            │            │
        select(0)    select(1)    select(2)
        │            │            │
        view         view         view
        │            │            │
        transpose    transpose    transpose
        │            │            │
        mul          transpose    │
        [Q, scaled]  [Kᵀ]         [V]
        │            │            │
        └──── bmm ───┘            │
              │                   │
              softmax ─── view    │
              │           │       │
              │           mean    │
              │         (erased)  │
              │                   │
              └───── bmm ─────────┘
                     │
                     transpose
                     │
                     contiguous
                     │
                     view
                     │
                     linear ← out_proj.weight, out_proj.bias?
                     │
                     view
                     │
                     transpose?    (batch_first bookend;
                                    Wildcard quantifier="?")

    Only canonical self-attention is supported: ``batch_first=True``,
    ``_qkv_same_embed_dim=True``, ``add_bias_kv=False``, and
    ``add_zero_attn=False``. Non-canonical variants are skipped with a
    warning naming the offending flag.

    The ``view → mean`` chain off the softmax computes
    ``attn_output_weights`` (the second tuple element of the MHA output).
    When unconsumed, ``match`` splices it into the trunk so
    ``replace_tree`` erases it alongside the main body. When consumed
    downstream, ``_is_softmax_with_dead_branch`` rejects the match with
    a warning instead of silently dropping the live weights.
    """

    is_conversion = True
    tree: Tree = _MHA_TREE

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        matches = match_tree(graph_module, pattern=self)

        for pattern_match in matches:
            tree_match = pattern_match.tree_match
            source_input = next(iter(tree_match.get_input_nodes()))
            # Walk the nested Forks to reach the softmax: the outer
            # ``_MHA_TREE`` (out-proj) Fork's nested[0] is the
            # ``_MHA_ATTN_V_BMM_FORK`` (attn·V) Fork, whose nested[0] is
            # the ``_MHA_QK_BMM_FORK`` (Q·Kᵀ) Fork, whose trunk_nodes[0]
            # is the softmax.
            softmax_node = tree_match.get_node(0, 0, 0)
            dead_branch = cast(
                list[fx.Node],
                getattr(softmax_node, _MHA_SOFTMAX_DEAD_BRANCH_ATTR),
            )
            delattr(softmax_node, _MHA_SOFTMAX_DEAD_BRANCH_ATTR)

            seen: set[fx.Node] = set()
            trunk_nodes: list[fx.Node | Wildcard] = []
            for node in tree_match.get_tree_nodes():
                if node in seen:
                    continue
                seen.add(node)
                trunk_nodes.append(node)
                if node is softmax_node:
                    for dead in dead_branch:
                        seen.add(dead)
                        trunk_nodes.append(dead)

            pattern_match.tree_match = TreeMatch(
                pre_trunk_nodes=[source_input],
                trunk_nodes=trunk_nodes,
            )

        return matches

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match
        trunk_nodes = cast(list[fx.Node], tree_match.trunk_nodes)
        mha = _make_multihead_attention(trunk_nodes)
        # Mirror the source graph module's training state so eval-time
        # behavior is preserved
        mha.train(pattern_match.graph_module.training)
        return replace_tree(pattern_match, [_get_mha_insert(mha)])


# need_weights=False components for AtenSDPAMultiheadAttentionPattern.
#
# With ``need_weights=False``, ``torch.export`` collapses Q·Kᵀ → softmax
# → ·V into a single ``aten.scaled_dot_product_attention.default`` node
# (the bmms and softmax are hidden inside the fused kernel). The Q/K/V
# branches gain an extra ``view`` (reshaping to 4-D) and the Q branch
# drops the ``mul`` scaling (SDPA handles it internally). There is no
# ``view → mean`` chain because there are no ``attn_weights`` to compute.

_is_permute_default = _is_call_to(torch.ops.aten.permute.default)

# Separate SharedNodeCheck so the two MHA patterns don't interfere.
_sdpa_shared_contiguous = SharedNodeCheck(_is_contiguous_default)

_MHA_SDPA_Q_BRANCH: Tree = Fork(
    inputs=(
        (_is_transpose_int,),
        (_is_attr("in_proj_weight"),),
        (_is_attr("in_proj_bias"),),  # optional
    ),
    operator=_is_mha_in_proj_linear,
    output=(
        _is_unflatten_int,
        _is_unsqueeze_default,
        _is_transpose_int,
        _is_squeeze_dim,
        _sdpa_shared_contiguous,
        _is_select_int_idx(0),
        _is_view_default,
        _is_transpose_int,
        _is_view_default,
    ),
    perms_override=((0, 1, 2), (0, 1)),
)

_MHA_SDPA_K_BRANCH: Tree = (
    _sdpa_shared_contiguous,
    _is_select_int_idx(1),
    _is_view_default,
    _is_transpose_int,
    _is_view_default,
)

_MHA_SDPA_V_BRANCH: Tree = (
    _sdpa_shared_contiguous,
    _is_select_int_idx(2),
    _is_view_default,
    _is_transpose_int,
    _is_view_default,
)

_MHA_SDPA_FORK: Tree = Fork(
    inputs=(_MHA_SDPA_Q_BRANCH, _MHA_SDPA_K_BRANCH, _MHA_SDPA_V_BRANCH),
    operator=torch.ops.aten.scaled_dot_product_attention.default,
    output=(
        _is_permute_default,
        _is_view_default,
    ),
)

_MHA_SDPA_TREE: Tree = Fork(
    inputs=(
        _MHA_SDPA_FORK,
        (_is_attr("weight"),),
        (_is_attr("bias"),),  # optional
    ),
    operator=_is_mha_out_proj_linear,
    output=(
        _is_view_default,
        Wildcard(_is_mha_tip_transpose, quantifier="?"),
    ),
    perms_override=((0, 1, 2), (0, 1)),
)


class AtenSDPAMultiheadAttentionPattern(Pattern):
    """Recompose an SDPA-based exported ``nn.MultiheadAttention`` subgraph.

    When ``need_weights=False``, ``torch.export`` uses
    ``aten.scaled_dot_product_attention`` instead of explicit
    ``bmm + softmax + bmm``. This pattern matches that variant and
    reconstructs a single ``nn.MultiheadAttention`` ``call_module`` node.

    Only canonical self-attention is supported: ``batch_first=True``,
    ``_qkv_same_embed_dim=True``, ``add_bias_kv=False``, and
    ``add_zero_attn=False``.
    """

    is_conversion = True
    tree: Tree = _MHA_SDPA_TREE

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        matches = match_tree(graph_module, pattern=self)

        for pattern_match in matches:
            tree_match = pattern_match.tree_match
            source_input = next(iter(tree_match.get_input_nodes()))

            seen: set[fx.Node] = set()
            trunk_nodes: list[fx.Node | Wildcard] = []
            for node in tree_match.get_tree_nodes():
                if node in seen:
                    continue
                seen.add(node)
                trunk_nodes.append(node)

            pattern_match.tree_match = TreeMatch(
                pre_trunk_nodes=[source_input],
                trunk_nodes=trunk_nodes,
            )

        return matches

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match
        trunk_nodes = cast(list[fx.Node], tree_match.get_tree_nodes())
        mha = _make_multihead_attention(trunk_nodes)
        mha.train(pattern_match.graph_module.training)
        return replace_tree(pattern_match, [_get_mha_insert(mha)])
