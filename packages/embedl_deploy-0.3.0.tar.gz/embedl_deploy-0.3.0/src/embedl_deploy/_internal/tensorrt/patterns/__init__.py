# Copyright (C) 2026 Embedl AB

"""TensorRT pattern implementations and curated pattern lists."""
