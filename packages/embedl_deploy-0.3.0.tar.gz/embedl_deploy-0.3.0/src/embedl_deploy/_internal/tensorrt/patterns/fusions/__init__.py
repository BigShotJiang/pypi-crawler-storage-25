# Copyright (C) 2026 Embedl AB

"""Fusion patterns for TensorRT."""
