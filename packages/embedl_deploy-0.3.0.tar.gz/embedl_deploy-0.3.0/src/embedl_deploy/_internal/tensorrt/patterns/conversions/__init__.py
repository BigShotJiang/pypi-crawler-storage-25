# Copyright (C) 2026 Embedl AB

"""Conversion ``Pattern`` subclasses for TensorRT.

Conversions are *structural* rewrites that change the graph topology so that
downstream fusion patterns can match.  They run **before** fusion patterns.

Submodules:

* :mod:`~embedl_deploy._internal.tensorrt.patterns.conversions.attention`
  — MHA / Swin decomposition and raw-SDPA composition.
* :mod:`~embedl_deploy._internal.tensorrt.patterns.conversions.general`
  — assertion cleanup, ``Flatten → Linear`` to ``Conv2d(1×1)``, identity
  removal.
"""
