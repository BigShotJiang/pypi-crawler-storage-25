# Copyright (C) 2026 Embedl AB

"""Fusion ``Pattern`` subclasses for pointwise activation and element-wise
TensorRT patterns."""

import operator
from typing import cast

from torch import fx

from embedl_deploy._internal.core.match import match_tree
from embedl_deploy._internal.core.modules import ActivationLike
from embedl_deploy._internal.core.pattern import (
    Fork,
    Pattern,
    PatternMatch,
    Tree,
    resolve_module,
)
from embedl_deploy._internal.core.replace import replace_tree
from embedl_deploy._internal.tensorrt.modules.pointwise import FusedActAdd


class ActAddPattern(Pattern):
    """Match ``Act → add(·, residual)`` and fuse into :class:`FusedActAdd`.

    Placing this pattern before the Conv-based fusion patterns prevents
    TensorRT from attempting to merge the upstream convolution into an
    activation-fused kernel when the activation output feeds a residual add.
    With ``Act → add`` absorbed into a single pointwise leaf, the upstream
    ``Conv → BN`` is matched by :class:`ConvBNPattern` and quantized
    independently.
    """

    tree: Tree = Fork(
        (
            (ActivationLike,),
            (),
        ),
        operator.add,
        (),
    )

    def match(self, graph_module: fx.GraphModule) -> list[PatternMatch]:
        return match_tree(
            graph_module,
            pattern=self,
        )

    def replace(self, pattern_match: PatternMatch) -> list[fx.Node]:
        assert pattern_match.pattern is self
        tree_match = pattern_match.tree_match
        act = cast(ActivationLike, resolve_module(tree_match.get_node(0, 0)))
        fused_module = FusedActAdd(act)
        return replace_tree(pattern_match, [fused_module])
