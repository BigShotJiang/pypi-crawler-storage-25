# Copyright (C) 2026 Embedl AB

"""TensorRT-specific fused and quantized ``nn.Module`` classes."""
