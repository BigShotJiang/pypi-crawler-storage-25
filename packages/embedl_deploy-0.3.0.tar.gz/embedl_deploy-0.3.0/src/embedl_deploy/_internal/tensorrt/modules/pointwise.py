# Copyright (C) 2026 Embedl AB

"""Fused ``nn.Module`` classes for pointwise activation and element-wise
operations."""

import torch

from embedl_deploy._internal.core.modules import ActivationLike, FusedModule


class FusedActAdd(FusedModule):
    """Fused ``Act → add(·, residual)`` pointwise op.

    Absorbing the activation and residual add into a single leaf module
    prevents TensorRT from attempting to merge the upstream convolution into an
    activation-fused kernel when the activation output is consumed by a
    subsequent add.  The Q/DQ insertion pass places quantization stubs on both
    inputs so that both the activated feature map and the skip connection are
    quantized at their respective scales.

    ``forward()`` accepts two tensors:

    * ``x`` — the main feature map passed through the activation.
    * ``residual`` — the skip-connection tensor added element-wise after the
      activation.
    """

    inputs_to_quantize: set[int] = {0, 1}

    def __init__(self, act: ActivationLike) -> None:
        super().__init__()
        self.act = act

    def forward(self, x: torch.Tensor, residual: torch.Tensor) -> torch.Tensor:
        """Apply ``act(x) + residual``."""
        return self.act(x) + residual

    def __repr__(self) -> str:
        return f"FusedActAdd({type(self.act).__name__})"
