# Copyright (C) 2026 Embedl AB

"""Swin Transformer attention sub-modules.

These ``nn.Module`` subclasses replace the opaque
``ShiftedWindowAttention`` in the FX graph.  Window partition/reverse
are spatial rearrangements that need no quantization.
:class:`SwinAttention` holds the learnt relative-position bias and
computes the shifted-window attention mask.
"""

from dataclasses import dataclass, field

import torch
import torch.nn.functional as F
from torch import nn

from embedl_deploy._internal.core.modules import ConvertedModule, FusedModule
from embedl_deploy._internal.core.quantize.stubs import QuantStub


@dataclass
class SwinSpatialState:
    """Shared mutable state for spatial dimensions.

    Written by :class:`SwinWindowPartition` during forward, read by
    :class:`SwinAttention` and :class:`SwinWindowReverse`.
    ``copy.deepcopy`` preserves the shared reference.
    """

    batch_size: int = 0
    height: int = 0
    width: int = 0
    pad_height: int = 0
    pad_width: int = 0
    #: Effective shift size after clamping for small feature maps.
    effective_shift_size: list[int] = field(
        default_factory=lambda: [0, 0],
    )


class SwinWindowPartition(ConvertedModule):
    """Pad, cyclic-shift, and window-partition a spatial tensor.

    :param window_size:
        Window dimensions ``[Wh, Ww]``.
    :param shift_size:
        Cyclic shift ``[sh, sw]`` (zero for non-shifted blocks).
    :param spatial_state:
        Shared state written during forward so that
        :class:`SwinAttention` and :class:`SwinWindowReverse`
        can read the dynamic spatial dimensions.
    """

    def __init__(
        self,
        window_size: list[int],
        shift_size: list[int],
        spatial_state: SwinSpatialState,
    ) -> None:
        super().__init__()
        self.window_size = list(window_size)
        self.shift_size = list(shift_size)
        self._spatial_state = spatial_state

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Partition *x* into non-overlapping windows.

        :param x:
            Input tensor ``[B, H, W, C]``.
        :returns:
            Windowed tensor ``[B*nW, Ws*Ws, C]``.
        """
        # pylint: disable-next=invalid-name
        B, H, W, C = x.shape

        # Pad to multiples of window size.
        ws_h, ws_w = self.window_size
        pad_b = (ws_h - H % ws_h) % ws_h
        pad_r = (ws_w - W % ws_w) % ws_w
        x = F.pad(x, (0, 0, 0, pad_r, 0, pad_b))
        # pylint: disable-next=invalid-name
        _, pad_H, pad_W, _ = x.shape

        # Clamp shift size when the window covers the whole feature map.
        eff_shift = list(self.shift_size)
        if ws_h >= pad_H:
            eff_shift[0] = 0
        if ws_w >= pad_W:
            eff_shift[1] = 0

        # Write spatial state for downstream modules.
        st = self._spatial_state
        st.batch_size = B
        st.height = H
        st.width = W
        st.pad_height = pad_H
        st.pad_width = pad_W
        st.effective_shift_size = eff_shift

        # Cyclic shift.
        if sum(eff_shift) > 0:
            x = torch.roll(
                x,
                shifts=(-eff_shift[0], -eff_shift[1]),
                dims=(1, 2),
            )

        # Window partition.
        x = x.view(
            B,
            pad_H // ws_h,
            ws_h,
            pad_W // ws_w,
            ws_w,
            C,
        )
        num_windows = (pad_H // ws_h) * (pad_W // ws_w)
        x = x.permute(0, 1, 3, 2, 4, 5).reshape(
            B * num_windows,
            ws_h * ws_w,
            C,
        )
        return x

    def __repr__(self) -> str:
        return (
            f"SwinWindowPartition("
            f"window_size={self.window_size}, "
            f"shift_size={self.shift_size})"
        )


class SwinAttention(ConvertedModule):
    """Windowed multi-head self-attention with relative position bias.

    :param relative_position_bias_table:
        Learnt bias table, shape
        ``[(2*Wh-1)*(2*Ww-1), num_heads]``.
    :param relative_position_index:
        Pre-computed index into the bias table, shape
        ``[Wh*Ww * Wh*Ww]``.
    :param window_size:
        Window dimensions ``[Wh, Ww]``.
    :param num_heads:
        Number of attention heads.
    :param head_dim:
        Dimension of each head.
    :param attention_dropout:
        Dropout on attention weights (training only).
    :param spatial_state:
        Shared state written by :class:`SwinWindowPartition`.
    """

    # pylint: disable-next=too-many-arguments,too-many-positional-arguments
    def __init__(
        self,
        relative_position_bias_table: nn.Parameter,
        relative_position_index: torch.Tensor,
        window_size: list[int],
        num_heads: int,
        head_dim: int,
        attention_dropout: float,
        spatial_state: SwinSpatialState,
    ) -> None:
        super().__init__()
        self.relative_position_bias_table = relative_position_bias_table
        self.register_buffer(
            "relative_position_index",
            relative_position_index,
        )
        self.window_size = list(window_size)
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.attention_dropout = attention_dropout
        self._spatial_state = spatial_state

    def _get_relative_position_bias(self) -> torch.Tensor:
        """Compute relative position bias ``[1, nH, N, N]``."""
        # pylint: disable-next=invalid-name
        N = self.window_size[0] * self.window_size[1]
        assert isinstance(self.relative_position_index, torch.Tensor)
        bias = self.relative_position_bias_table[self.relative_position_index]
        bias = bias.view(N, N, -1).permute(2, 0, 1).contiguous()
        return bias.unsqueeze(0)

    def _compute_attn_mask(  # pylint: disable=too-many-locals
        self,
    ) -> torch.Tensor | None:
        """Build shifted-window attention mask, or ``None``."""
        st = self._spatial_state
        eff_shift = st.effective_shift_size
        if sum(eff_shift) == 0:
            return None

        pad_H = st.pad_height  # pylint: disable=invalid-name
        pad_W = st.pad_width  # pylint: disable=invalid-name
        ws_h, ws_w = self.window_size
        num_windows = (pad_H // ws_h) * (pad_W // ws_w)

        attn_mask = torch.zeros(
            (pad_H, pad_W),
            device=self.relative_position_bias_table.device,
        )
        h_slices = (
            (0, -ws_h),
            (-ws_h, -eff_shift[0]),
            (-eff_shift[0], None),
        )
        w_slices = (
            (0, -ws_w),
            (-ws_w, -eff_shift[1]),
            (-eff_shift[1], None),
        )
        count = 0
        for h_start, h_end in h_slices:
            for w_start, w_end in w_slices:
                attn_mask[h_start:h_end, w_start:w_end] = count
                count += 1

        attn_mask = attn_mask.view(
            pad_H // ws_h,
            ws_h,
            pad_W // ws_w,
            ws_w,
        )
        attn_mask = attn_mask.permute(0, 2, 1, 3).reshape(
            num_windows,
            ws_h * ws_w,
        )
        attn_mask = attn_mask.unsqueeze(1) - attn_mask.unsqueeze(2)
        attn_mask = attn_mask.masked_fill(
            attn_mask != 0,
            -100.0,
        ).masked_fill(attn_mask == 0, 0.0)
        return attn_mask

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
    ) -> torch.Tensor:
        """Compute windowed attention with relative position bias.

        :param q:
            Query ``[B*nW, num_heads, Ws*Ws, head_dim]``.
        :param k:
            Key ``[B*nW, num_heads, Ws*Ws, head_dim]``.
        :param v:
            Value ``[B*nW, num_heads, Ws*Ws, head_dim]``.
        :returns:
            Attention output ``[B*nW, Ws*Ws, C]``.
        """
        scale = self.head_dim ** (-0.5)
        attn = torch.matmul(q, k.transpose(-2, -1)) * scale

        attn = attn + self._get_relative_position_bias()

        attn_mask = self._compute_attn_mask()
        if attn_mask is not None:
            # pylint: disable-next=invalid-name
            B = self._spatial_state.batch_size
            nW = attn.size(0) // B  # pylint: disable=invalid-name
            attn = attn.view(B, nW, self.num_heads, -1, attn.size(-1))
            attn = attn + attn_mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, attn.size(-2), attn.size(-1))

        attn = F.softmax(attn, dim=-1)
        if self.training and self.attention_dropout > 0.0:
            attn = F.dropout(attn, p=self.attention_dropout)

        x = torch.matmul(attn, v)
        x = (
            x.transpose(1, 2)
            .contiguous()
            .view(
                x.size(0),
                -1,
                self.num_heads * self.head_dim,
            )
        )
        return x

    def __repr__(self) -> str:
        embed_dim = self.num_heads * self.head_dim
        return (
            f"SwinAttention("
            f"embed_dim={embed_dim}, "
            f"num_heads={self.num_heads}, "
            f"head_dim={self.head_dim}, "
            f"window_size={self.window_size})"
        )


class SwinWindowReverse(ConvertedModule):
    """Reverse window-partition, cyclic-shift, and unpad.

    :param window_size:
        Window dimensions ``[Wh, Ww]``.
    :param spatial_state:
        Shared state written by :class:`SwinWindowPartition`.
    """

    def __init__(
        self,
        window_size: list[int],
        spatial_state: SwinSpatialState,
    ) -> None:
        super().__init__()
        self.window_size = list(window_size)
        self._spatial_state = spatial_state

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Reverse window partition, shift, and padding.

        :param x:
            Windowed tensor ``[B*nW, Ws*Ws, C]``.
        :returns:
            Spatial tensor ``[B, H, W, C]``.
        """
        st = self._spatial_state
        # pylint: disable=invalid-name
        B = st.batch_size
        pad_H = st.pad_height
        pad_W = st.pad_width
        H = st.height
        W = st.width
        # pylint: enable=invalid-name
        eff_shift = st.effective_shift_size
        ws_h, ws_w = self.window_size
        C = x.size(-1)  # pylint: disable=invalid-name

        # Reverse window partition.
        x = x.view(
            B,
            pad_H // ws_h,
            pad_W // ws_w,
            ws_h,
            ws_w,
            C,
        )
        x = x.permute(0, 1, 3, 2, 4, 5).reshape(B, pad_H, pad_W, C)

        # Reverse cyclic shift.
        if sum(eff_shift) > 0:
            x = torch.roll(
                x,
                shifts=(eff_shift[0], eff_shift[1]),
                dims=(1, 2),
            )

        # Remove padding.
        x = x[:, :H, :W, :].contiguous()
        return x

    def __repr__(self) -> str:
        return f"SwinWindowReverse(window_size={self.window_size})"


class FusedSwinAttention(FusedModule):
    """Fused wrapper for :class:`SwinAttention`.

    Adds an internal
    :class:`~embedl_deploy._internal.core.quantize.stubs.QuantStub`
    between the softmax output and the second batched matrix multiply.

    :param attention:
        The :class:`SwinAttention` from the decomposed Swin block.
    """

    inputs_to_quantize: set[int] = set()

    def __init__(self, attention: SwinAttention) -> None:
        super().__init__()
        self.attention = attention
        self.softmax_quant = QuantStub(
            consumers={self},
            n_bits=8,
            symmetric=True,
            fixed_calibration=(1.0 / 127, 0),
        )

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
    ) -> torch.Tensor:
        """Compute windowed attention with internal quantization.

        :param q:
            Query ``[B*nW, num_heads, Ws*Ws, head_dim]``.
        :param k:
            Key ``[B*nW, num_heads, Ws*Ws, head_dim]``.
        :param v:
            Value ``[B*nW, num_heads, Ws*Ws, head_dim]``.
        :returns:
            Attention output ``[B*nW, Ws*Ws, C]``.
        """
        if not self.softmax_quant.enabled:
            return self.attention(q, k, v)

        a = self.attention
        scale = a.head_dim ** (-0.5)
        attn_weight = torch.matmul(q, k.transpose(-2, -1)) * scale

        # pylint: disable-next=protected-access
        attn_weight = attn_weight + a._get_relative_position_bias()

        # pylint: disable-next=protected-access
        attn_mask = a._compute_attn_mask()
        if attn_mask is not None:
            # pylint: disable-next=protected-access,invalid-name
            B = a._spatial_state.batch_size
            nW = attn_weight.size(0) // B  # pylint: disable=invalid-name
            n = attn_weight.size(-2)
            attn_weight = attn_weight.view(
                B,
                nW,
                a.num_heads,
                n,
                attn_weight.size(-1),
            )
            attn_weight = attn_weight + attn_mask.unsqueeze(1).unsqueeze(0)
            attn_weight = attn_weight.view(
                -1,
                a.num_heads,
                n,
                attn_weight.size(-1),
            )

        attn_weight = torch.softmax(attn_weight, dim=-1)
        attn_weight = self.softmax_quant(attn_weight)
        if a.training and a.attention_dropout > 0.0:
            attn_weight = F.dropout(
                attn_weight,
                p=a.attention_dropout,
            )
        x = torch.matmul(attn_weight, v)
        return (
            x.transpose(1, 2)
            .contiguous()
            .view(
                x.size(0),
                -1,
                a.num_heads * a.head_dim,
            )
        )

    def __repr__(self) -> str:
        a = self.attention
        qdq = "yes" if self.softmax_quant.enabled else "no"
        return (
            f"FusedSwinAttention("
            f"num_heads={a.num_heads}, "
            f"head_dim={a.head_dim}, "
            f"window_size={a.window_size}, "
            f"internal_qdq={qdq})"
        )
