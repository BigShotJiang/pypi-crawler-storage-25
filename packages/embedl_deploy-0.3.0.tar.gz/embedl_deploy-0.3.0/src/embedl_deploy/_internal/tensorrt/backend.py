# Copyright (C) 2026 Embedl AB

"""TensorRT backend descriptor."""

from embedl_deploy._internal.core.backend import Backend
from embedl_deploy._internal.tensorrt.plan import (
    TENSORRT_CONVERSION_PATTERNS,
    TENSORRT_FUSION_PATTERNS,
    TENSORRT_QUANTIZED_PATTERNS,
    TENSORRT_SMOOTH_PATTERNS,
)

BACKEND = Backend(
    conversion_patterns=TENSORRT_CONVERSION_PATTERNS,
    fusion_patterns=TENSORRT_FUSION_PATTERNS,
    smooth_patterns=TENSORRT_SMOOTH_PATTERNS,
    quantized_patterns=TENSORRT_QUANTIZED_PATTERNS,
)
