# Copyright (C) 2026 Embedl AB

"""TensorRT backend — curated pattern lists.

For convenience when creating transformation plans.
"""

from embedl_deploy._internal.core.pattern import Pattern
from embedl_deploy._internal.tensorrt.patterns.conversions.attention import (
    ComposeParallelLinearsPattern,
    ComposeScaledDotProductAttentionPattern,
    DecomposeMultiheadAttentionPattern,
    DecomposeSwinAttentionPattern,
)
from embedl_deploy._internal.tensorrt.patterns.conversions.general import (
    FlattenLinearToConv1x1Pattern,
    RemoveAssertPattern,
    RemoveDeadAssertPattern,
    RemoveExportAssertPattern,
    RemoveIdentityAdaptiveAvgPoolPattern,
    RemoveIdentityPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.attention import (
    MHAInProjectionPattern,
    ScaledDotProductAttentionPattern,
    SwinAttentionPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.conv import (
    ConvBNActPattern,
    ConvBNAddActPattern,
    ConvBNPattern,
    StemConvBNActMaxPoolPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.linear import (
    LayerNormPattern,
    LinearActPattern,
    LinearPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.pointwise import (
    ActAddPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.pool import (
    AdaptiveAvgPoolPattern,
)
from embedl_deploy._internal.tensorrt.patterns.quantizations import (
    DeduplicateQuantStubsPattern,
    InsertQuantStubsPattern,
    PropagateQuantStubPattern,
    SurroundWithQuantStubsPattern,
)
from embedl_deploy._internal.tensorrt.patterns.recompositions import (
    AtenActivationPattern,
    AtenAdaptiveAvgPool2dPattern,
    AtenAddPattern,
    AtenBNPattern,
    AtenConv2dPattern,
    AtenDropoutPattern,
    AtenFlattenPattern,
    AtenLayerNormPattern,
    AtenLinearPattern,
    AtenMaxPool2dPattern,
    AtenMultiheadAttentionPattern,
    AtenSDPAMultiheadAttentionPattern,
    AtenShapeOpsPattern,
)
from embedl_deploy._internal.tensorrt.patterns.smoothings import (
    PrepareSmoothQuantPattern,
)

# The order matters: at each graph node the inspector tries every
# pattern and keeps the longest match.  Longer / more specific
# patterns must precede shorter / more general ones.

TENSORRT_RECOMPOSITION_PATTERNS: list[Pattern] = [
    AtenMultiheadAttentionPattern(),
    AtenSDPAMultiheadAttentionPattern(),
    AtenConv2dPattern(),
    AtenBNPattern(),
    AtenActivationPattern(),
    AtenAddPattern(),
    AtenAdaptiveAvgPool2dPattern(),
    AtenDropoutPattern(),
    AtenFlattenPattern(),
    AtenLinearPattern(),
    AtenLayerNormPattern(),
    AtenMaxPool2dPattern(),
    AtenShapeOpsPattern(),
]

TENSORRT_CONVERSION_PATTERNS: list[Pattern] = [
    DecomposeMultiheadAttentionPattern(),
    DecomposeSwinAttentionPattern(),
    ComposeScaledDotProductAttentionPattern(),
    ComposeParallelLinearsPattern(),
    FlattenLinearToConv1x1Pattern(),
    RemoveIdentityPattern(),
    RemoveAssertPattern(),
    RemoveDeadAssertPattern(),
    RemoveExportAssertPattern(),
    RemoveIdentityAdaptiveAvgPoolPattern(),
]

TENSORRT_FUSION_PATTERNS: list[Pattern] = [
    StemConvBNActMaxPoolPattern(),
    ConvBNAddActPattern(),
    ActAddPattern(),
    ConvBNActPattern(),
    LinearActPattern(),
    ConvBNPattern(),
    LinearPattern(),
    LayerNormPattern(),
    MHAInProjectionPattern(),
    ScaledDotProductAttentionPattern(),
    SwinAttentionPattern(),
    AdaptiveAvgPoolPattern(),
]

TENSORRT_SMOOTH_PATTERNS: list[Pattern] = [
    PrepareSmoothQuantPattern(),
]

TENSORRT_QUANTIZED_PATTERNS: list[Pattern] = [
    InsertQuantStubsPattern(),
    PropagateQuantStubPattern(),
    DeduplicateQuantStubsPattern(),
    SurroundWithQuantStubsPattern(),
]

TENSORRT_PATTERNS: list[Pattern] = (
    TENSORRT_CONVERSION_PATTERNS + TENSORRT_FUSION_PATTERNS
)
