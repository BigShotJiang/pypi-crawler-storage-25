# Copyright (C) 2026 Embedl AB

"""Public re-exports of TensorRT fused ``nn.Module`` classes.

Users import from here::

    from embedl_deploy.tensorrt.modules import FusedConvBNAct, FusedConvBN
"""

from embedl_deploy._internal.tensorrt.modules.attention import (
    FusedMHAInProjection,
    FusedScaledDotProductAttention,
)
from embedl_deploy._internal.tensorrt.modules.conv import (
    FusedConvBN,
    FusedConvBNAct,
    FusedConvBNActMaxPool,
    FusedConvBNAddAct,
)
from embedl_deploy._internal.tensorrt.modules.linear import (
    FusedLayerNorm,
    FusedLinear,
    FusedLinearAct,
)
from embedl_deploy._internal.tensorrt.modules.pool import (
    FusedAdaptiveAvgPool2d,
)

__all__ = [
    "FusedAdaptiveAvgPool2d",
    "FusedConvBN",
    "FusedConvBNAddAct",
    "FusedConvBNAct",
    "FusedConvBNActMaxPool",
    "FusedLayerNorm",
    "FusedLinear",
    "FusedLinearAct",
    "FusedMHAInProjection",
    "FusedScaledDotProductAttention",
]
