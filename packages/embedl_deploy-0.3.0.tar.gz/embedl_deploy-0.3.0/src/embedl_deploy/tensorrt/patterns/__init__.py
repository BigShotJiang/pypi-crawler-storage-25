# Copyright (C) 2026 Embedl AB

"""Public re-exports of TensorRT pattern classes.

Users import from here::

    from embedl_deploy.tensorrt.patterns import ConvBNPattern
"""

from embedl_deploy._internal.tensorrt.patterns.conversions.attention import (
    DecomposeMultiheadAttentionPattern,
)
from embedl_deploy._internal.tensorrt.patterns.conversions.general import (
    FlattenLinearToConv1x1Pattern,
    RemoveAssertPattern,
    RemoveDeadAssertPattern,
    RemoveIdentityAdaptiveAvgPoolPattern,
    RemoveIdentityPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.attention import (
    MHAInProjectionPattern,
    ScaledDotProductAttentionPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.conv import (
    ConvBNActPattern,
    ConvBNAddActPattern,
    ConvBNPattern,
    StemConvBNActMaxPoolPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.linear import (
    LayerNormPattern,
    LinearActPattern,
    LinearPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.pointwise import (
    ActAddPattern,
)
from embedl_deploy._internal.tensorrt.patterns.fusions.pool import (
    AdaptiveAvgPoolPattern,
)

__all__ = [
    "ActAddPattern",
    "AdaptiveAvgPoolPattern",
    "ConvBNAddActPattern",
    "ConvBNPattern",
    "ConvBNActPattern",
    "DecomposeMultiheadAttentionPattern",
    "FlattenLinearToConv1x1Pattern",
    "LayerNormPattern",
    "LinearPattern",
    "LinearActPattern",
    "MHAInProjectionPattern",
    "RemoveAssertPattern",
    "RemoveDeadAssertPattern",
    "RemoveIdentityPattern",
    "RemoveIdentityAdaptiveAvgPoolPattern",
    "ScaledDotProductAttentionPattern",
    "StemConvBNActMaxPoolPattern",
]
