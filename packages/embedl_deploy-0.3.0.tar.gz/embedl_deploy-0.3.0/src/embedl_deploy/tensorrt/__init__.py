# Copyright (C) 2026 Embedl AB

"""TensorRT backend — curated pattern lists and convenience API.

Quick start::

    import torch
    from torchvision.models import resnet50
    from embedl_deploy import transform
    from embedl_deploy.tensorrt import TENSORRT_PATTERNS

    model = resnet50(weights=None).eval()
    deployed = transform(model, patterns=TENSORRT_PATTERNS).model

Pattern lists
-------------
``TENSORRT_RECOMPOSITION_PATTERNS``
    Lift aten-level ops back into ``nn.Module`` nodes (for
    ``torch.export`` output).
``TENSORRT_CONVERSION_PATTERNS``
    Structural conversions applied *before* fusion (e.g. ``Flatten→Linear →
    Conv1×1→Flatten``).
``TENSORRT_FUSION_PATTERNS``
    Fusion-only patterns (``Conv→BN→ReLU``, Stem, residual, etc.).
``TENSORRT_PATTERNS``
    Union of conversions + fusions (the default for most users).
``TENSORRT_QUANTIZED_PATTERNS``
    Q/DQ stub insertion, propagation, deduplication, and surround.
"""

from embedl_deploy._internal.tensorrt.plan import (
    TENSORRT_CONVERSION_PATTERNS,
    TENSORRT_FUSION_PATTERNS,
    TENSORRT_PATTERNS,
    TENSORRT_QUANTIZED_PATTERNS,
    TENSORRT_RECOMPOSITION_PATTERNS,
)

__all__ = [
    "TENSORRT_PATTERNS",
    "TENSORRT_CONVERSION_PATTERNS",
    "TENSORRT_FUSION_PATTERNS",
    "TENSORRT_QUANTIZED_PATTERNS",
    "TENSORRT_RECOMPOSITION_PATTERNS",
]
