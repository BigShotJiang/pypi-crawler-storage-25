# Copyright (C) 2026 Embedl AB

"""Python package to make AI models deployment-ready for any hardware."""

from embedl_deploy._internal.core.plan import (
    TransformationPlan,
    TransformationResult,
    apply_transformation_plan,
    get_transformation_plan,
    transform,
)
from embedl_deploy.version.public import PUBLIC_VERSION

__version__ = PUBLIC_VERSION

__all__ = [
    "__version__",
    "TransformationPlan",
    "TransformationResult",
    "apply_transformation_plan",
    "get_transformation_plan",
    "transform",
]
