# Copyright (C) 2026 Embedl AB

"""Backend discovery and selection."""

from embedl_deploy._internal.core.backend import (
    Backend,
    get_backend,
    set_backend,
)

__all__ = [
    "Backend",
    "get_backend",
    "set_backend",
]
