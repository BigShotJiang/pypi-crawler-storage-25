"""Stride browser daemon server.

Asyncio server on a Unix domain socket that maintains a persistent Chromium
browser instance shared across CLI commands. Auto-starts on first command,
auto-stops after 15 minutes idle.

Protocol: newline-delimited JSON over Unix socket.
  -> {"id": "abc", "method": "x_search", "args": {"query": "...", "max_results": 50}}\n
  <- {"id": "abc", "result": [...], "error": null}\n

Windows is not supported (requires Unix domain sockets and fcntl).
"""

import asyncio
import dataclasses
import json
import logging
import os
import signal
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

from stride.browser.service import BrowserNotAvailableError, BrowserService, NotLoggedInError
from stride.config import load_config

# Daemon file locations
STRIDE_DIR = Path.home() / ".stride"
SOCKET_PATH = STRIDE_DIR / "daemon.sock"
PID_FILE = STRIDE_DIR / "daemon.pid"
LOG_FILE = STRIDE_DIR / "daemon.log"

# Idle timeout: shut down after 15 minutes of no requests
IDLE_TIMEOUT = 15 * 60  # seconds

# Rate-limiting: 3s spacing between actions on the same platform
RATE_LIMIT_SPACING = 3  # seconds

logger = logging.getLogger("stride.daemon")


def _setup_logging() -> None:
    """Configure rotating file logger for daemon."""
    STRIDE_DIR.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(
        str(LOG_FILE), maxBytes=1_048_576, backupCount=3
    )
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    )
    root = logging.getLogger()
    root.addHandler(handler)
    root.setLevel(logging.INFO)


def _dataclass_to_dict(obj: object) -> object:
    """Convert dataclasses to dicts for JSON serialization."""
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    if isinstance(obj, list):
        return [_dataclass_to_dict(item) for item in obj]
    return obj


class DaemonServer:
    """Browser daemon server managing shared Chromium instance."""

    def __init__(self) -> None:
        from stride.channel.reddit import RedditChannel
        from stride.channel.x import XChannel

        self._browser_service: BrowserService | None = None
        self._x_channel: XChannel | None = None
        self._reddit_channel: RedditChannel | None = None
        self._last_request_time: float = time.time()
        self._server: asyncio.AbstractServer | None = None
        self._shutdown_event = asyncio.Event()

        # Per-platform rate-limiting locks (one browser action at a time per platform)
        self._x_lock = asyncio.Lock()
        self._reddit_lock = asyncio.Lock()

        # Track last action time per platform for rate spacing
        self._x_last_action: float = 0.0
        self._reddit_last_action: float = 0.0

    def _build_dispatch_table(self) -> dict:
        """Build method dispatch table. Login methods are deliberately excluded
        because they require headless=False (visible browser), which the daemon
        does not support."""
        return {
            "x_search": self._x_search,
            "x_feed": self._x_feed,
            "x_post": self._x_post,
            "x_reply": self._x_reply,
            "x_status": self._x_status,
            "reddit_search": self._reddit_search,
            "reddit_feed": self._reddit_feed,
            "reddit_browse": self._reddit_browse,
            "reddit_comments": self._reddit_comments,
            "reddit_post": self._reddit_post,
            "reddit_reply": self._reddit_reply,
            "reddit_status": self._reddit_status,
            "shutdown": self._handle_shutdown,
        }

    async def start(self) -> None:
        """Start the daemon: browser, channels, socket server."""
        _setup_logging()
        logger.info("Daemon starting...")

        # Stale socket cleanup
        if SOCKET_PATH.exists():
            if await self._check_existing_daemon():
                logger.error("Another daemon is already running. Exiting.")
                sys.exit(1)
            else:
                logger.info("Removing stale socket file.")
                SOCKET_PATH.unlink()

        # Start browser service
        config = load_config()
        self._browser_service = BrowserService(
            profile_dir=config.browser.profile_dir,
            headless=True,
        )
        try:
            await self._browser_service.start()
        except Exception as exc:
            logger.error("Failed to start browser: %s", exc)
            sys.exit(1)

        # Create channel instances with shared browser
        from stride.channel.reddit import RedditChannel
        from stride.channel.x import XChannel

        self._x_channel = XChannel(browser_service=self._browser_service)
        self._reddit_channel = RedditChannel(browser_service=self._browser_service)

        # Write PID file
        STRIDE_DIR.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(str(os.getpid()))

        # Start Unix socket server
        self._server = await asyncio.start_unix_server(
            self._handle_client, path=str(SOCKET_PATH)
        )
        logger.info("Daemon listening on %s (PID %d)", SOCKET_PATH, os.getpid())

        # Set up signal handlers
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, lambda: asyncio.create_task(self._graceful_shutdown()))

        # Start idle timeout checker
        asyncio.create_task(self._idle_checker())

        # Wait for shutdown
        await self._shutdown_event.wait()

    async def _check_existing_daemon(self) -> bool:
        """Check if an existing daemon is running by trying to connect to the socket."""
        try:
            reader, writer = await asyncio.open_unix_connection(str(SOCKET_PATH))
            writer.close()
            await writer.wait_closed()
            return True
        except (ConnectionRefusedError, FileNotFoundError, OSError):
            return False

    async def _handle_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        """Handle a single client connection (may send multiple requests)."""
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break  # Client disconnected

                self._last_request_time = time.time()

                try:
                    request = json.loads(line.decode("utf-8"))
                except json.JSONDecodeError as e:
                    response = {"id": None, "result": None, "error": f"Invalid JSON: {e}"}
                    writer.write((json.dumps(response) + "\n").encode("utf-8"))
                    await writer.drain()
                    continue

                req_id = request.get("id")
                method = request.get("method", "")
                args = request.get("args", {})

                logger.info("Request: method=%s id=%s", method, req_id)

                dispatch = self._build_dispatch_table()
                handler = dispatch.get(method)

                if handler is None:
                    response = {
                        "id": req_id,
                        "result": None,
                        "error": f"Unknown method: {method}",
                    }
                else:
                    try:
                        result = await handler(**args)
                        # Convert dataclasses to dicts for JSON serialization
                        result = _dataclass_to_dict(result)
                        response = {"id": req_id, "result": result, "error": None}
                    except NotLoggedInError as e:
                        response = {
                            "id": req_id,
                            "result": None,
                            "error": str(e),
                            "error_type": "NotLoggedInError",
                        }
                    except BrowserNotAvailableError as e:
                        response = {
                            "id": req_id,
                            "result": None,
                            "error": str(e),
                            "error_type": "BrowserNotAvailableError",
                        }
                    except Exception as e:
                        logger.exception("Error handling method %s", method)
                        response = {
                            "id": req_id,
                            "result": None,
                            "error": str(e),
                        }

                writer.write((json.dumps(response) + "\n").encode("utf-8"))
                await writer.drain()
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("Client handler error")
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def _rate_limited(self, platform: str):
        """Apply per-platform rate limiting: wait if needed, then record action time."""
        if platform == "x":
            lock = self._x_lock
            last = self._x_last_action
        else:
            lock = self._reddit_lock
            last = self._reddit_last_action

        async with lock:
            now = time.time()
            elapsed = now - last
            if elapsed < RATE_LIMIT_SPACING:
                await asyncio.sleep(RATE_LIMIT_SPACING - elapsed)

            # Execute is handled by caller, but we yield control inside lock
            # The caller will call _record_action after completing
            yield

    async def _with_rate_limit(self, platform: str, coro):
        """Execute a coroutine with per-platform rate limiting."""
        if platform == "x":
            lock = self._x_lock
        else:
            lock = self._reddit_lock

        async with lock:
            # Wait for rate limit spacing
            now = time.time()
            if platform == "x":
                elapsed = now - self._x_last_action
            else:
                elapsed = now - self._reddit_last_action

            if elapsed < RATE_LIMIT_SPACING:
                await asyncio.sleep(RATE_LIMIT_SPACING - elapsed)

            try:
                result = await coro
                return result
            finally:
                # Record action time after completion
                if platform == "x":
                    self._x_last_action = time.time()
                else:
                    self._reddit_last_action = time.time()

    # --- X method handlers ---
    # Channels are initialized in start() before any request, so assert non-None.

    async def _x_search(self, **kwargs):
        assert self._x_channel is not None
        return await self._with_rate_limit(
            "x", self._x_channel.search_tweets(**kwargs)
        )

    async def _x_feed(self, **kwargs):
        assert self._x_channel is not None
        return await self._with_rate_limit(
            "x", self._x_channel.get_home_timeline(**kwargs)
        )

    async def _x_post(self, **kwargs):
        assert self._x_channel is not None
        return await self._with_rate_limit(
            "x", self._x_channel.post(**kwargs)
        )

    async def _x_reply(self, **kwargs):
        assert self._x_channel is not None
        return await self._with_rate_limit(
            "x", self._x_channel.reply(**kwargs)
        )

    async def _x_status(self, **kwargs):
        assert self._x_channel is not None
        return await self._with_rate_limit(
            "x", self._x_channel.check_status()
        )

    # --- Reddit method handlers ---

    async def _reddit_search(self, **kwargs):
        assert self._reddit_channel is not None
        return await self._with_rate_limit(
            "reddit", self._reddit_channel.search_posts(**kwargs)
        )

    async def _reddit_feed(self, **kwargs):
        assert self._reddit_channel is not None
        return await self._with_rate_limit(
            "reddit", self._reddit_channel.get_home_feed(**kwargs)
        )

    async def _reddit_browse(self, **kwargs):
        assert self._reddit_channel is not None
        return await self._with_rate_limit(
            "reddit", self._reddit_channel.get_subreddit_posts(**kwargs)
        )

    async def _reddit_comments(self, **kwargs):
        assert self._reddit_channel is not None
        return await self._with_rate_limit(
            "reddit", self._reddit_channel.get_post_comments(**kwargs)
        )

    async def _reddit_post(self, **kwargs):
        assert self._reddit_channel is not None
        return await self._with_rate_limit(
            "reddit", self._reddit_channel.post(**kwargs)
        )

    async def _reddit_reply(self, **kwargs):
        assert self._reddit_channel is not None
        return await self._with_rate_limit(
            "reddit", self._reddit_channel.reply(**kwargs)
        )

    async def _reddit_status(self, **kwargs):
        assert self._reddit_channel is not None
        return await self._with_rate_limit(
            "reddit", self._reddit_channel.check_status()
        )

    # --- Control methods ---

    async def _handle_shutdown(self, **kwargs):
        """Handle shutdown request from client."""
        logger.info("Shutdown requested via socket.")
        asyncio.create_task(self._graceful_shutdown())
        return {"status": "shutting_down"}

    async def _idle_checker(self) -> None:
        """Background task that shuts down the daemon after idle timeout."""
        while not self._shutdown_event.is_set():
            await asyncio.sleep(60)
            elapsed = time.time() - self._last_request_time
            if elapsed >= IDLE_TIMEOUT:
                logger.info("Idle timeout reached (%.0fs). Shutting down.", elapsed)
                await self._graceful_shutdown()
                return

    async def _graceful_shutdown(self) -> None:
        """Gracefully shut down: close browser, remove socket + pid files."""
        if self._shutdown_event.is_set():
            return  # Already shutting down
        self._shutdown_event.set()

        logger.info("Graceful shutdown starting...")

        # Close the server (stop accepting new connections)
        if self._server:
            self._server.close()
            try:
                await self._server.wait_closed()
            except Exception:
                pass

        # Stop browser
        if self._browser_service:
            try:
                await self._browser_service.stop()
            except Exception:
                logger.exception("Error stopping browser")

        # Clean up files
        if SOCKET_PATH.exists():
            try:
                SOCKET_PATH.unlink()
            except Exception:
                pass
        if PID_FILE.exists():
            try:
                PID_FILE.unlink()
            except Exception:
                pass

        logger.info("Daemon stopped.")


async def main() -> None:
    """Entry point for the daemon process."""
    server = DaemonServer()
    await server.start()


if __name__ == "__main__":
    asyncio.run(main())
