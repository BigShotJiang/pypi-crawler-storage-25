"""Stride daemon client.

Connects to the daemon's Unix socket, auto-starting the daemon if needed.
Race-safe startup via file lock ensures only one daemon starts.

Windows is not supported (requires Unix domain sockets and fcntl).
"""

import asyncio
import fcntl
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

from stride.browser.service import BrowserNotAvailableError, NotLoggedInError

# Daemon file locations (must match daemon.py)
STRIDE_DIR = Path.home() / ".stride"
SOCKET_PATH = STRIDE_DIR / "daemon.sock"
PID_FILE = STRIDE_DIR / "daemon.pid"
LOCK_FILE = STRIDE_DIR / "daemon.lock"

# How long to wait for daemon to start
STARTUP_TIMEOUT = 10  # seconds
STARTUP_POLL_INTERVAL = 0.2  # seconds

# How long to wait for a response from the daemon
SEND_TIMEOUT = 120  # seconds

# Map error type names to exception classes for reconstruction
ERROR_TYPES: dict[str, type[Exception]] = {
    "NotLoggedInError": NotLoggedInError,
    "BrowserNotAvailableError": BrowserNotAvailableError,
}


class DaemonConnectionError(Exception):
    """Raised when the daemon cannot be connected to or started."""

    pass


class DaemonClient:
    """Client for the Stride browser daemon.

    Usage:
        client = await DaemonClient.connect_or_start()
        result = await client.send("x_search", {"query": "test", "max_results": 50})
        await client.close()
    """

    def __init__(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        self._reader = reader
        self._writer = writer

    @staticmethod
    async def connect_or_start() -> "DaemonClient":
        """Connect to running daemon or auto-start one.

        Race-safe: uses file lock so concurrent CLI invocations don't
        start multiple daemons.

        Raises DaemonConnectionError if daemon cannot be started within timeout.
        """
        # 1. Try connecting to existing daemon
        try:
            return await DaemonClient._connect()
        except (ConnectionRefusedError, FileNotFoundError, OSError):
            pass

        # 2. Acquire file lock (blocking -- waits for other starters)
        STRIDE_DIR.mkdir(parents=True, exist_ok=True)
        lock_fd = open(str(LOCK_FILE), "w")
        try:
            # LOCK_EX (blocking) ensures racing CLIs wait rather than fail
            fcntl.flock(lock_fd, fcntl.LOCK_EX)

            # 3. Double-check after acquiring lock (another process may have started it)
            try:
                return await DaemonClient._connect()
            except (ConnectionRefusedError, FileNotFoundError, OSError):
                pass

            # 4. Start daemon as detached subprocess
            subprocess.Popen(
                [sys.executable, "-m", "stride.daemon"],
                start_new_session=True,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            # 5. Poll for socket availability
            start = time.monotonic()
            while time.monotonic() - start < STARTUP_TIMEOUT:
                await asyncio.sleep(STARTUP_POLL_INTERVAL)
                try:
                    return await DaemonClient._connect()
                except (ConnectionRefusedError, FileNotFoundError, OSError):
                    continue

            raise DaemonConnectionError(
                f"Daemon did not start within {STARTUP_TIMEOUT}s. "
                f"Check {STRIDE_DIR / 'daemon.log'} for errors."
            )
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            lock_fd.close()

    @staticmethod
    async def _connect() -> "DaemonClient":
        """Connect to the daemon socket. Raises on failure."""
        reader, writer = await asyncio.open_unix_connection(str(SOCKET_PATH))
        return DaemonClient(reader, writer)

    async def send(self, method: str, args: dict | None = None, timeout: float = SEND_TIMEOUT) -> dict:
        """Send a request to the daemon and return the result.

        Args:
            method: The daemon method name (e.g. "x_search").
            args: Arguments dict to pass to the method.
            timeout: How long to wait for a response (default 120s).

        Returns:
            The result dict from the daemon.

        Raises:
            NotLoggedInError: If the daemon reports the user is not logged in.
            BrowserNotAvailableError: If the daemon reports the browser is unavailable.
            DaemonConnectionError: If the connection drops or times out.
        """
        request = {
            "id": str(uuid.uuid4()),
            "method": method,
            "args": args or {},
        }

        try:
            self._writer.write((json.dumps(request) + "\n").encode("utf-8"))
            await self._writer.drain()
        except (ConnectionResetError, BrokenPipeError) as e:
            raise DaemonConnectionError(f"Lost connection to daemon: {e}") from e

        try:
            line = await asyncio.wait_for(
                self._reader.readline(), timeout=timeout
            )
        except asyncio.TimeoutError:
            raise DaemonConnectionError(
                f"Daemon did not respond within {timeout}s"
            ) from None
        except (ConnectionResetError, BrokenPipeError) as e:
            raise DaemonConnectionError(f"Lost connection to daemon: {e}") from e

        if not line:
            raise DaemonConnectionError("Daemon closed the connection unexpectedly")

        response = json.loads(line.decode("utf-8"))

        # Reconstruct typed errors
        error = response.get("error")
        if error:
            error_type_name = response.get("error_type", "")
            error_class = ERROR_TYPES.get(error_type_name)
            if error_class:
                raise error_class(error)
            raise DaemonConnectionError(f"Daemon error: {error}")

        return response.get("result")

    async def close(self) -> None:
        """Close the connection to the daemon."""
        try:
            self._writer.close()
            await self._writer.wait_closed()
        except Exception:
            pass

    @staticmethod
    def is_running() -> bool:
        """Check if the daemon appears to be running (PID file exists and process alive)."""
        if not PID_FILE.exists():
            return False
        try:
            pid = int(PID_FILE.read_text().strip())
            # os.kill with signal 0 checks if process exists without sending a signal
            os.kill(pid, 0)
            return True
        except (ValueError, ProcessLookupError, PermissionError):
            return False
