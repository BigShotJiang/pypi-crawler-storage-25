"""Stride CLI entry point."""

import asyncio
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel

from stride.channel.cli import channel_app

app = typer.Typer(
    name="stride",
    help="Distribution automation for indie builders.",
    no_args_is_help=True,
)
app.add_typer(channel_app, name="channel")

# Daemon command group
daemon_app = typer.Typer(
    name="daemon",
    help="Manage the browser daemon (auto-starts on first command).",
    no_args_is_help=True,
)
app.add_typer(daemon_app, name="daemon")

console = Console()

STRIDE_DIR = Path.home() / ".stride"
BROWSER_PROFILE_DIR = STRIDE_DIR / "browser-profile"
CONFIG_PATH = STRIDE_DIR / "config.toml"


def reset_browser_profile(confirm_msg: str = "This will delete all saved browser sessions (X, Reddit, etc.). Continue?") -> None:
    """Shared helper to delete and recreate the browser profile directory."""
    if not typer.confirm(confirm_msg):
        raise typer.Abort()

    if BROWSER_PROFILE_DIR.exists():
        shutil.rmtree(BROWSER_PROFILE_DIR)
    BROWSER_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    console.print("[green]Browser profile reset. You will need to log in again to all channels.[/green]")


@app.command()
def setup():
    """Install Playwright + Chromium and initialize Stride config directory."""

    # Create directories
    STRIDE_DIR.mkdir(exist_ok=True)
    BROWSER_PROFILE_DIR.mkdir(exist_ok=True)

    # Create default config if it doesn't exist
    if not CONFIG_PATH.exists():
        import tomli_w

        default_config = {
            "browser": {
                "profile_dir": str(BROWSER_PROFILE_DIR),
                "headless": True,
            },
        }
        CONFIG_PATH.write_bytes(tomli_w.dumps(default_config).encode())
        console.print(f"[green]Created config at {CONFIG_PATH}[/green]")

    # Install Playwright Chromium
    console.print("Installing Chromium browser...")
    result = subprocess.run(
        [sys.executable, "-m", "playwright", "install", "chromium"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        console.print("[green]Chromium installed successfully.[/green]")
    else:
        console.print(f"[red]Failed to install Chromium:[/red]\n{result.stderr}")
        raise typer.Exit(1)

    console.print(
        "\n[bold green]Setup complete![/bold green]\n"
        "Next steps:\n"
        "  stride channel x login       # Log in to X\n"
        "  stride channel reddit login   # Log in to Reddit"
    )


@app.command("help")
def help_command():
    """Show a quick-start guide with all available commands."""
    guide = """[bold]Stride CLI[/bold] - Distribution automation for indie builders

[bold cyan]Getting started:[/bold cyan]
  stride setup                          Install Playwright + Chromium
  stride channel x login                Log in to X (opens visible browser)
  stride channel reddit login           Log in to Reddit (opens visible browser)

[bold cyan]X commands:[/bold cyan]
  stride channel x status
  stride channel x post "text" [--image PATH] [--self-reply TEXT] [--thread TEXT]
  stride channel x reply <url> "text"
  stride channel x search "query" [--max N] [--json]
  stride channel x feed [--max N] [--json]
  stride channel x help | reset

[bold cyan]Reddit commands:[/bold cyan]
  stride channel reddit status
  stride channel reddit post -s <sub> -t "Title" [-b "Body"] [--url URL] [--image PATH]
  stride channel reddit reply <url> "text"
  stride channel reddit search "query" [-s <sub>] [--sort X] [--time X] [--max N] [--json]
  stride channel reddit feed [--max N] [--json]
  stride channel reddit browse <subreddit> [--sort X] [--max N] [--json]
  stride channel reddit comments <url> [--max N] [--json]
  stride channel reddit help | reset

[bold cyan]Daemon commands:[/bold cyan]
  stride daemon status                  Show if daemon is running, PID, uptime
  stride daemon stop                    Stop the running daemon
  stride daemon restart                 Stop + start (useful after config changes)

[bold cyan]Utility:[/bold cyan]
  stride reset                          Reset all browser sessions
  stride help                           This guide
  stride --help                         Argument docs

[dim]The daemon auto-starts on first command. Subsequent commands are faster (~2-3s).[/dim]
[dim]For AI agent integration, see skill.md[/dim]"""

    console.print(Panel(guide, title="Quick Start", border_style="cyan"))


@app.command()
def reset():
    """Reset browser profile, clearing all saved sessions."""
    reset_browser_profile()


# --- Daemon commands ---


@daemon_app.command("status")
def daemon_status():
    """Show if the browser daemon is running, PID, and uptime."""
    from stride.daemon_client import DaemonClient, PID_FILE

    if not DaemonClient.is_running():
        console.print("[dim]Daemon is not running.[/dim]")
        return

    try:
        pid = int(PID_FILE.read_text().strip())
    except (ValueError, FileNotFoundError):
        console.print("[dim]Daemon is not running.[/dim]")
        return

    # Calculate uptime from PID file modification time
    try:
        start_time = PID_FILE.stat().st_mtime
        uptime_secs = int(time.time() - start_time)
        mins, secs = divmod(uptime_secs, 60)
        hours, mins = divmod(mins, 60)
        if hours > 0:
            uptime_str = f"{hours}h {mins}m {secs}s"
        elif mins > 0:
            uptime_str = f"{mins}m {secs}s"
        else:
            uptime_str = f"{secs}s"
    except Exception:
        uptime_str = "unknown"

    console.print(f"[green]Daemon is running[/green] (PID {pid}, uptime {uptime_str})")


@daemon_app.command("stop")
def daemon_stop():
    """Stop the running browser daemon."""
    from stride.daemon import PID_FILE, SOCKET_PATH
    from stride.daemon_client import DaemonClient

    if not DaemonClient.is_running():
        # Clean up stale files if the process is dead
        if SOCKET_PATH.exists():
            SOCKET_PATH.unlink()
            console.print("[dim]Cleaned up stale socket file.[/dim]")
        if PID_FILE.exists():
            PID_FILE.unlink()
            console.print("[dim]Cleaned up stale PID file.[/dim]")
        console.print("[dim]Daemon is not running.[/dim]")
        return

    async def _stop():
        try:
            client = await DaemonClient._connect()
            await client.send("shutdown")
            await client.close()
        except Exception:
            pass

    asyncio.run(_stop())

    # Wait briefly for daemon to finish cleanup
    for _ in range(10):
        if not DaemonClient.is_running():
            break
        time.sleep(0.5)

    if DaemonClient.is_running():
        console.print("[yellow]Daemon may still be shutting down.[/yellow]")
    else:
        console.print("[green]Daemon stopped.[/green]")


@daemon_app.command("restart")
def daemon_restart():
    """Stop and restart the browser daemon (useful after config changes)."""
    from stride.daemon_client import DaemonClient

    # Stop if running
    if DaemonClient.is_running():
        daemon_stop()

    # Start by connecting (auto-starts daemon)
    async def _start():
        try:
            client = await DaemonClient.connect_or_start()
            await client.close()
            console.print("[green]Daemon started.[/green]")
        except Exception as e:
            console.print(f"[red]Failed to start daemon:[/red] {e}")
            raise typer.Exit(1)

    asyncio.run(_start())
