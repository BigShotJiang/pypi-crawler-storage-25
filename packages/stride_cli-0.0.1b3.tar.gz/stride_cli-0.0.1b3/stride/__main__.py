"""Allow running stride as `python -m stride`."""

from stride.cli import app

app()
