"""Stride CLI — Distribution automation for indie builders."""

__version__ = "0.0.1b2"
