"""Output formatting for CLI commands.

Supports JSON output (for AI agent integration) and Rich table output (for humans).
"""

import json

from rich.console import Console
from rich.table import Table


def output_results(
    items: list[dict],
    as_json: bool,
    console: Console,
    columns: list[str],
) -> None:
    """Output a list of result dicts as JSON or Rich Table.

    When as_json is True, prints valid JSON to stdout via print() (not Rich Console).
    When as_json is False, renders a Rich Table with the specified columns.
    """
    if as_json:
        print(json.dumps(items, ensure_ascii=False))
        return

    if not items:
        console.print("[dim]No results found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold cyan")
    for col in columns:
        table.add_column(col)

    for item in items:
        row = []
        for col in columns:
            val = item.get(col, "")
            text = str(val) if val is not None else ""
            # Truncate long text fields
            if col in ("text", "title") and len(text) > 80:
                text = text[:77] + "..."
            # Prepend URL as dim line above text/title column
            if col in ("text", "title") and item.get("url"):
                text = f"[dim]{item['url']}[/dim]\n{text}"
            row.append(text)
        table.add_row(*row)

    console.print(table)


def output_single(
    item: dict,
    as_json: bool,
    console: Console,
) -> None:
    """Output a single item as JSON or Rich-formatted key/value pairs.

    When as_json is True, prints valid JSON to stdout via print() (not Rich Console).
    When as_json is False, prints each key/value pair via Rich Console.
    """
    if as_json:
        print(json.dumps(item, ensure_ascii=False))
        return

    for key, value in item.items():
        console.print(f"[bold]{key}:[/bold] {value}")
