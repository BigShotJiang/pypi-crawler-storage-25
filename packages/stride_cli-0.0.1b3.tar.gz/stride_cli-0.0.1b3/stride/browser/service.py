"""Shared browser service for all channels.

Manages a persistent Chromium instance with anti-detection and session persistence.
Ported from stride-server/src/services/browser.py.
"""

import logging
import time
from pathlib import Path

from playwright.async_api import BrowserContext, Page, Playwright, async_playwright

logger = logging.getLogger(__name__)


class BrowserNotAvailableError(Exception):
    """Raised when Playwright/Chromium is not installed."""

    pass


class NotLoggedInError(Exception):
    """Raised when the browser session is not logged in to a platform."""

    pass

# Pages older than this are considered stale and will be cleaned up
STALE_PAGE_MAX_AGE = 120  # seconds

# User agent template — major version filled dynamically from bundled Chromium
_UA_TEMPLATE = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/{major}.0.0.0 Safari/537.36"
)

# Anti-detection stealth script injected into every page
STEALTH_SCRIPT = """
Object.defineProperty(navigator, 'webdriver', {
    get: () => undefined
});
Object.defineProperty(navigator, 'languages', {
    get: () => ['en-US', 'en']
});
Object.defineProperty(navigator, 'plugins', {
    get: () => [1, 2, 3, 4, 5]
});
window.chrome = { runtime: {} };
"""


class BrowserService:
    """Manages a persistent Chromium browser with anti-detection features.

    Args:
        profile_dir: Path to the persistent browser profile directory.
        headless: Whether to run in headless mode (default True).
    """

    def __init__(self, profile_dir: str, headless: bool = True):
        self._profile_dir = profile_dir
        self._headless = headless
        self._playwright: Playwright | None = None
        self._context: BrowserContext | None = None
        self._active_pages: dict[Page, float] = {}

    async def start(self) -> None:
        """Start the browser with persistent profile."""
        if self._context:
            return

        # Ensure profile directory exists
        Path(self._profile_dir).mkdir(parents=True, exist_ok=True)

        self._playwright = await async_playwright().start()

        # Detect bundled Chromium version so the UA always matches
        temp = await self._playwright.chromium.launch(headless=True)
        major = temp.version.split(".")[0]
        await temp.close()
        user_agent = _UA_TEMPLATE.format(major=major)

        self._context = await self._playwright.chromium.launch_persistent_context(
            user_data_dir=self._profile_dir,
            headless=self._headless,
            user_agent=user_agent,
            viewport={"width": 1280, "height": 900},
            args=["--disable-blink-features=AutomationControlled"],
        )

        # Apply stealth script to all new pages
        await self._context.add_init_script(STEALTH_SCRIPT)
        logger.info("Browser started (headless=%s, profile=%s, chrome=%s)", self._headless, self._profile_dir, major)

    async def new_page(self) -> Page:
        """Create a new page, cleaning up stale pages first."""
        if not self._context:
            raise RuntimeError("Browser not started. Call start() first.")

        # Clean up stale pages
        now = time.time()
        stale = [p for p, t in self._active_pages.items() if now - t > STALE_PAGE_MAX_AGE]
        for page in stale:
            try:
                await page.close()
            except Exception:
                pass
            self._active_pages.pop(page, None)

        page = await self._context.new_page()
        self._active_pages[page] = time.time()
        return page

    async def close_page(self, page: Page) -> None:
        """Close a page and remove from tracking."""
        self._active_pages.pop(page, None)
        if not page.is_closed():
            try:
                await page.close()
            except Exception:
                pass

    async def stop(self) -> None:
        """Stop the browser and clean up."""
        for page in list(self._active_pages):
            await self.close_page(page)

        if self._context:
            try:
                await self._context.close()
            except Exception:
                pass
            self._context = None

        if self._playwright:
            try:
                await self._playwright.stop()
            except Exception:
                pass
            self._playwright = None

        self._active_pages.clear()
        logger.info("Browser stopped.")
