"""X (Twitter) channel implementation.

Browser-based automation for posting, replying, and checking login status on X.
Ported from stride-server/src/services/x_browser.py with new post() features
(image upload, community posting, threads, self-reply).
"""

import re
from pathlib import Path
from urllib.parse import quote as url_quote

from playwright.async_api import Page

from stride.browser.service import BrowserNotAvailableError, BrowserService, NotLoggedInError
from stride.channel.base import ChannelStatus, PostResult, ReplyResult
from stride.config import load_config

# Valid image/video extensions for X uploads
_VALID_MEDIA_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".mp4"}


def _parse_metric(text: object) -> int:
    """Convert human-readable metric text to integer.

    Examples: "622" -> 622, "9.4K" -> 9400, "20M" -> 20000000, "1,234" -> 1234.
    Returns 0 on parse failure.
    """
    if text is None:
        return 0
    s = str(text).strip()
    if not s:
        return 0
    # Remove commas (e.g. "1,234")
    s = s.replace(",", "")
    # Check for K/M/B suffix
    s_upper = s.upper()
    try:
        if s_upper.endswith("K"):
            return int(float(s_upper[:-1]) * 1_000)
        if s_upper.endswith("M"):
            return int(float(s_upper[:-1]) * 1_000_000)
        if s_upper.endswith("B"):
            return int(float(s_upper[:-1]) * 1_000_000_000)
        return int(float(s))
    except (ValueError, TypeError):
        return 0


# JavaScript function to extract tweets from the DOM.
# Runs inside page.evaluate() for a single efficient DOM traversal.
_EXTRACT_TWEETS_JS = """
() => {
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    const results = [];
    for (const article of articles) {
        try {
            // tweet_id + username from status link
            const statusLinks = article.querySelectorAll('a[href*="/status/"]');
            let tweetId = null;
            let username = null;
            for (const link of statusLinks) {
                const match = link.href.match(/\\/([^\\/]+)\\/status\\/(\\d+)$/);
                if (match) {
                    username = match[1];
                    tweetId = match[2];
                    break;
                }
            }
            if (!tweetId || !username) continue;

            // text
            const textEl = article.querySelector('[data-testid="tweetText"]');
            const text = textEl ? textEl.innerText : '';

            // created_at from time element
            const timeEl = article.querySelector('time[datetime]');
            const createdAt = timeEl ? timeEl.getAttribute('datetime') : '';

            // avatar
            const avatarImg = article.querySelector('img[src*="pbs.twimg.com/profile_images"]');
            const avatarUrl = avatarImg ? avatarImg.src : '';

            // views from analytics link
            let views = '';
            const analyticsLink = article.querySelector('a[href*="/analytics"]');
            if (analyticsLink) {
                const span = analyticsLink.querySelector('span');
                if (span) views = span.innerText.trim();
            }

            // is_retweet
            const socialContext = article.querySelector('[data-testid="socialContext"]');
            const isRetweet = socialContext ? socialContext.innerText.toLowerCase().includes('repost') : false;

            // is_reply
            const isReply = article.innerText.includes('Replying to');

            // quoted tweet text
            let quotedTweetText = '';
            const quoteTweet = article.querySelector('[data-testid="quoteTweet"]');
            if (quoteTweet) {
                const qtText = quoteTweet.querySelector('[data-testid="tweetText"]');
                if (qtText) quotedTweetText = qtText.innerText;
            }

            // media image (first photo)
            let mediaUrl = '';
            const tweetPhoto = article.querySelector('[data-testid="tweetPhoto"] img');
            if (tweetPhoto && tweetPhoto.src && tweetPhoto.src.includes('pbs.twimg.com/media')) {
                mediaUrl = tweetPhoto.src;
            }

            // Detect reply restriction (e.g. "only subscribers can reply")
            // Restricted reply icons have SVG opacity 0.4 vs normal 1.0
            let replyRestricted = false;
            const replyBtn = article.querySelector('[data-testid="reply"]');
            if (!replyBtn) {
                replyRestricted = true;
            } else {
                const svg = replyBtn.querySelector('svg');
                if (svg) {
                    const svgOpacity = parseFloat(getComputedStyle(svg).opacity);
                    if (!isNaN(svgOpacity) && svgOpacity < 0.6) {
                        replyRestricted = true;
                    }
                }
            }

            results.push({
                tweet_id: tweetId,
                username: username,
                text: text,
                created_at: createdAt,
                avatar_url: avatarUrl,
                views: views,
                is_retweet: isRetweet,
                is_reply: isReply,
                quoted_tweet_text: quotedTweetText,
                media_url: mediaUrl,
                reply_restricted: replyRestricted
            });
        } catch (e) {
            // Skip individual tweet extraction errors
        }
    }
    return results;
}
"""


def _extract_tweet_id(url: str) -> str | None:
    """Extract tweet ID from a URL like https://x.com/user/status/123."""
    match = re.search(r"/status/(\d+)", url)
    return match.group(1) if match else None


class XChannel:
    """X channel using browser automation."""

    def __init__(self, headless: bool | None = None, profile_dir: str | None = None, browser_service: BrowserService | None = None):
        if browser_service:
            self._browser = browser_service
            self._owns_browser = False
        else:
            self._owns_browser = True
            config = load_config()
            self._headless = headless if headless is not None else config.browser.headless
            self._profile_dir = profile_dir or config.browser.profile_dir
            self._browser: BrowserService | None = None

    async def _get_browser(self) -> BrowserService:
        if self._browser is None:
            try:
                self._browser = BrowserService(
                    profile_dir=self._profile_dir,
                    headless=self._headless,
                )
                await self._browser.start()
            except Exception as exc:
                self._browser = None
                raise BrowserNotAvailableError(
                    "Browser not available. Run 'stride setup' first to install Chromium."
                ) from exc
        return self._browser

    async def _cleanup(self) -> None:
        if self._owns_browser and self._browser:
            await self._browser.stop()
            self._browser = None
        # When _owns_browser is False, do nothing -- page cleanup
        # is handled by close_page() in the method's finally block

    async def search_tweets(self, query: str, max_results: int = 50) -> list[dict]:
        """Search tweets via browser (Latest tab).

        Navigates to X search, scrolls to load results, extracts from DOM.
        Returns list of tweet dicts with views converted to int.
        Raises NotLoggedInError if not logged in.
        Raises BrowserNotAvailableError if browser can't start.
        Returns [] on unexpected errors.
        """
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            encoded_query = url_quote(query)
            await page.goto(
                f"https://x.com/search?q={encoded_query}&f=live",
                wait_until="domcontentloaded",
            )
            try:
                await page.wait_for_selector('article[data-testid="tweet"]', timeout=15000)
            except Exception:
                pass  # fallback: continue anyway

            if "/login" in page.url:
                raise NotLoggedInError("Not logged in to X")

            all_tweets: dict[str, dict] = {}
            no_new_count = 0
            max_scrolls = 15

            for _i in range(max_scrolls):
                batch = await page.evaluate(_EXTRACT_TWEETS_JS)
                new_count = 0
                for tweet in batch:
                    tid = tweet.get("tweet_id")
                    if tid and tid not in all_tweets:
                        # Convert views string to int
                        tweet["views"] = _parse_metric(tweet.get("views", ""))
                        all_tweets[tid] = tweet
                        new_count += 1

                if len(all_tweets) >= max_results:
                    break

                if new_count == 0:
                    no_new_count += 1
                    if no_new_count >= 2:
                        break
                else:
                    no_new_count = 0

                await page.evaluate("window.scrollBy(0, window.innerHeight * 2)")
                await page.wait_for_timeout(2500)

            return list(all_tweets.values())[:max_results]
        except (BrowserNotAvailableError, NotLoggedInError):
            raise
        except Exception:
            return []
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def get_home_timeline(self, max_results: int = 100) -> list[dict]:
        """Scrape home timeline tweets via browser.

        Opens browser, scrolls to load tweets, extracts from DOM.
        Returns list of tweet dicts with views converted to int.
        Raises NotLoggedInError if not logged in.
        Raises BrowserNotAvailableError if browser can't start.
        Returns [] on unexpected errors.
        """
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            await page.goto("https://x.com/home", wait_until="domcontentloaded")
            try:
                await page.wait_for_selector('article[data-testid="tweet"]', timeout=15000)
            except Exception:
                pass  # fallback: continue anyway

            if "/login" in page.url:
                raise NotLoggedInError("Not logged in to X")

            all_tweets: dict[str, dict] = {}
            no_new_count = 0
            max_scrolls = 15

            for _i in range(max_scrolls):
                batch = await page.evaluate(_EXTRACT_TWEETS_JS)
                new_count = 0
                for tweet in batch:
                    tid = tweet.get("tweet_id")
                    if tid and tid not in all_tweets:
                        tweet["views"] = _parse_metric(tweet.get("views", ""))
                        all_tweets[tid] = tweet
                        new_count += 1

                if len(all_tweets) >= max_results:
                    break

                if new_count == 0:
                    no_new_count += 1
                    if no_new_count >= 2:
                        break
                else:
                    no_new_count = 0

                await page.evaluate("window.scrollBy(0, window.innerHeight * 2)")
                await page.wait_for_timeout(2500)

            return list(all_tweets.values())[:max_results]
        except (BrowserNotAvailableError, NotLoggedInError):
            raise
        except Exception:
            return []
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def login(self) -> bool:
        """Open visible browser for X login. User logs in manually, cookies are saved."""
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            await page.goto("https://x.com/login", wait_until="domcontentloaded")

            # Wait for user to complete login (detect navigation away from /login)
            # Timeout after 120 seconds
            try:
                await page.wait_for_url(
                    lambda url: "/login" not in url and "x.com" in url,
                    timeout=120_000,
                )
                # Give extra time for session to fully establish
                await page.wait_for_timeout(3000)
                return True
            except Exception:
                return False
        except BrowserNotAvailableError:
            return False
        finally:
            await self._cleanup()

    async def check_status(self) -> ChannelStatus:
        """Check if X session is valid by navigating to home and checking for login redirect."""
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            await page.goto("https://x.com/home", wait_until="domcontentloaded")

            # Wait for actual page content (Cloudflare challenge may delay loading)
            try:
                await page.wait_for_selector(
                    '[data-testid="AppTabBar_Profile_Link"], [data-testid="loginButton"], [data-testid="tweet"]',
                    timeout=30000,
                )
            except Exception:
                # Fallback: just wait a bit if no selector found
                await page.wait_for_timeout(5000)

            current_url = page.url
            if "/login" in current_url:
                return ChannelStatus(connected=False, error="Session expired")

            # Try to extract username from page
            username = ""
            try:
                # Look for the profile link in the sidebar
                link = await page.query_selector('a[data-testid="AppTabBar_Profile_Link"]')
                if link:
                    href = await link.get_attribute("href")
                    if href:
                        username = href.strip("/")
            except Exception:
                pass

            return ChannelStatus(connected=True, username=username)
        except BrowserNotAvailableError as e:
            return ChannelStatus(connected=False, error=str(e))
        except Exception as e:
            return ChannelStatus(connected=False, error=str(e))
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def _reply_internal(
        self,
        page: Page,
        tweet_id_or_url: str,
        text: str,
        capture_url: bool = False,
    ) -> ReplyResult:
        """Core reply logic that operates on an existing page.

        Navigates to the target tweet URL. Does NOT close the page or browser.
        Reused by reply(), self-reply, and thread.

        Args:
            page: An existing Playwright page.
            tweet_id_or_url: Tweet URL or ID to reply to.
            text: Reply text.
            capture_url: If True, attempt to capture the reply URL from toast
                (needed for thread chaining). When False, skip the 5s toast wait.
        """
        page.set_default_timeout(30000)

        # Navigate to tweet
        tweet_id = _extract_tweet_id(tweet_id_or_url)
        if tweet_id:
            nav_url = f"https://x.com/i/status/{tweet_id}"
        else:
            nav_url = tweet_id_or_url

        await page.goto(nav_url, wait_until="domcontentloaded")
        # Wait for page content to load (Cloudflare may delay)
        try:
            await page.wait_for_selector(
                '[data-testid="tweet"], [data-testid="tweetTextarea_0"], [data-testid="reply"]',
                timeout=30000,
            )
        except Exception:
            await page.wait_for_timeout(5000)

        # Check login redirect
        if "/login" in page.url:
            return ReplyResult(success=False, error="Not logged in. Run 'stride channel x login' first.")

        # Check for reply restriction
        restriction = page.get_by_text(re.compile(r"Only .+ can reply"))
        if await restriction.first.is_visible(timeout=2000):
            msg = await restriction.first.inner_text()
            return ReplyResult(success=False, error=f"Reply restricted: {msg}")

        # Find reply box (use .first — page may have both inline and offscreen editors)
        reply_box = page.locator('[data-testid="tweetTextarea_0"]').first
        if not await reply_box.is_visible(timeout=3000):
            # Click reply button to open reply box
            reply_button = page.locator('[data-testid="reply"]').first
            await reply_button.click()
            await page.wait_for_timeout(2000)

        # Re-check reply box visibility
        reply_box = page.locator('[data-testid="tweetTextarea_0"]').first
        if not await reply_box.is_visible(timeout=3000):
            return ReplyResult(
                success=False,
                error="Reply box not found. Tweet may be protected/deleted or X UI changed.",
            )

        # Type reply
        await reply_box.click()
        await page.wait_for_timeout(500)
        await page.keyboard.type(text, delay=20)
        await page.wait_for_timeout(1000)

        # Click post button (prefer inline, fallback to regular)
        post_button = page.locator('[data-testid="tweetButtonInline"]')
        if not await post_button.is_visible(timeout=3000):
            post_button = page.locator('[data-testid="tweetButton"]')

        await post_button.click()
        await page.wait_for_timeout(3000)

        # URL capture (optional, for thread chaining)
        captured_url = ""
        if capture_url:
            try:
                toast_link = page.locator('[data-testid="toast"] a[href*="/status/"]')
                await toast_link.wait_for(state="visible", timeout=5000)
                href = await toast_link.get_attribute("href")
                if href:
                    if href.startswith("/"):
                        captured_url = f"https://x.com{href}"
                    else:
                        captured_url = href
            except Exception:
                # Fallback: check page URL
                if "/status/" in page.url:
                    captured_url = page.url

        return ReplyResult(success=True, url=captured_url)

    async def reply(self, target_url: str, content: str) -> ReplyResult:
        """Reply to a tweet via browser automation."""
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            result = await self._reply_internal(page, target_url, content, capture_url=False)
            return result
        except BrowserNotAvailableError as e:
            return ReplyResult(success=False, error=str(e))
        except Exception as e:
            return ReplyResult(success=False, error=str(e))
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def post(self, content: str, **kwargs: object) -> PostResult:
        """Post a tweet via browser automation.

        Supports image upload, community posting, self-reply, and threading.

        Kwargs:
            image: str path to image/video file
            community: str community URL
            self_reply: str text for a self-reply
            thread: list[str] texts for thread replies
        """
        image = str(kwargs["image"]) if kwargs.get("image") else None
        community = str(kwargs["community"]) if kwargs.get("community") else None
        self_reply = str(kwargs["self_reply"]) if kwargs.get("self_reply") else None
        thread_items: list[str] = []
        raw_thread = kwargs.get("thread")
        if raw_thread is not None:
            if isinstance(raw_thread, list):
                thread_items = [str(t) for t in raw_thread]
            else:
                thread_items = [str(raw_thread)]

        # 1. Validate inputs upfront (before launching browser)
        if image:
            image_path = Path(image)
            if not image_path.is_file():
                return PostResult(success=False, error=f"Image file not found: {image}")
            if image_path.suffix.lower() not in _VALID_MEDIA_EXTENSIONS:
                return PostResult(
                    success=False,
                    error=f"Invalid image format '{image_path.suffix}'. Supported: {', '.join(sorted(_VALID_MEDIA_EXTENSIONS))}",
                )

        if self_reply and thread_items:
            return PostResult(
                success=False,
                error="Cannot use both --self-reply and --thread. They are mutually exclusive.",
            )

        if community and (self_reply or thread_items):
            return PostResult(
                success=False,
                error="Cannot use --community with --self-reply or --thread. They are incompatible.",
            )

        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            page.set_default_timeout(30000)

            # 2. Navigate to compose
            if community:
                await page.goto(community, wait_until="domcontentloaded")
                try:
                    await page.wait_for_selector('[data-testid="tweetTextarea_0"]', timeout=10000)
                except Exception:
                    pass  # fallback: continue anyway
                if "/login" in page.url:
                    return PostResult(success=False, error="Not logged in. Run 'stride channel x login' first.")
                # Try to find compose area in community
                editor = page.locator('[data-testid="tweetTextarea_0"]')
                if not await editor.is_visible(timeout=10000):
                    return PostResult(
                        success=False,
                        error="Could not find compose area in community. Verify the community URL is correct.",
                    )
            else:
                await page.goto("https://x.com/compose/post", wait_until="domcontentloaded")
                # The compose URL opens a modal dialog over the home page.
                # Both the modal AND the inline home composer have the same testids,
                # so we MUST scope all selectors to the modal.
                modal = page.locator('[role="dialog"][aria-modal="true"]')
                try:
                    await modal.wait_for(state="visible", timeout=30000)
                except Exception:
                    pass
                # Check for login redirect
                if "/login" in page.url:
                    return PostResult(success=False, error="Not logged in. Run 'stride channel x login' first.")
                editor = modal.locator('[data-testid="tweetTextarea_0"]')
                if not await editor.is_visible(timeout=5000):
                    return PostResult(success=False, error="Could not find tweet editor")

            # 3. Type the text
            await editor.click()
            await page.keyboard.type(content, delay=20)

            # 4. Image upload (if --image)
            if image:
                file_input = page.locator('[role="dialog"][aria-modal="true"] input[data-testid="fileInput"]')
                if not await file_input.first.is_visible(timeout=3000):
                    file_input = page.locator('input[data-testid="fileInput"]').first
                await file_input.first.set_input_files(image)
                # Wait for upload preview
                attachments = page.locator('[data-testid="attachments"]')
                try:
                    await attachments.wait_for(state="visible", timeout=10000)
                except Exception:
                    return PostResult(success=False, error="Image upload failed. Preview did not appear within timeout.")

            # 5. Post the tweet — use the modal's button specifically
            post_btn = page.locator('[role="dialog"][aria-modal="true"] [data-testid="tweetButton"]')
            if not await post_btn.is_visible(timeout=3000):
                post_btn = page.locator('[data-testid="tweetButton"]').first
            await post_btn.click()
            await page.wait_for_timeout(3000)

            # 6. Capture posted tweet URL (needed for self-reply/thread)
            posted_url = ""
            if self_reply or thread_items:
                # Primary: toast link
                try:
                    toast_link = page.locator('[data-testid="toast"] a[href*="/status/"]')
                    await toast_link.wait_for(state="visible", timeout=5000)
                    href = await toast_link.get_attribute("href")
                    if href:
                        if href.startswith("/"):
                            posted_url = f"https://x.com{href}"
                        else:
                            posted_url = href
                except Exception:
                    pass

                # Fallback 1: check page URL
                if not posted_url and "/status/" in page.url:
                    posted_url = page.url

                if not posted_url:
                    error_msg = "Posted successfully but could not capture tweet URL for thread/reply."
                    return PostResult(success=True, error=error_msg)

            # 7. Self-reply (if --self-reply)
            if self_reply and posted_url:
                reply_result = await self._reply_internal(page, posted_url, self_reply, capture_url=False)
                if not reply_result.success:
                    return PostResult(
                        success=True,
                        url=posted_url,
                        error=f"Tweet posted but self-reply failed: {reply_result.error}",
                    )

            # 8. Thread (if --thread)
            if thread_items and posted_url:
                current_url = posted_url
                for i, thread_text in enumerate(thread_items):
                    reply_result = await self._reply_internal(page, current_url, thread_text, capture_url=True)
                    if not reply_result.success:
                        return PostResult(
                            success=True,
                            url=posted_url,
                            error=f"Thread partially posted ({i} of {len(thread_items)}). "
                            f"Failed at tweet {i + 1}: {reply_result.error}",
                        )
                    if reply_result.url:
                        current_url = reply_result.url
                    else:
                        # URL capture failed mid-thread, stop
                        return PostResult(
                            success=True,
                            url=posted_url,
                            error=f"Thread partially posted ({i + 1} of {len(thread_items)}). "
                            f"Could not capture URL after tweet {i + 1}.",
                        )

            return PostResult(success=True, url=posted_url)
        except BrowserNotAvailableError as e:
            return PostResult(success=False, error=str(e))
        except Exception as e:
            return PostResult(success=False, error=str(e))
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()
