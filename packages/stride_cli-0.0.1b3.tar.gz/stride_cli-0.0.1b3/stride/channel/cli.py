"""Channel command group -- `stride channel <platform> <action>`.

Commands try the daemon first for faster execution, falling back to direct
browser launch if the daemon is unavailable.
"""

import asyncio
import dataclasses
import json
import sys
from pathlib import Path
from typing import Any, Optional

import typer
from rich.console import Console
from rich.panel import Panel

from stride.browser.service import BrowserNotAvailableError, NotLoggedInError

console = Console()

channel_app = typer.Typer(
    name="channel",
    help="Manage distribution channels (X, Reddit, etc.).",
    no_args_is_help=True,
)


async def _via_daemon_or_direct(method: str, args: dict[str, Any], fallback_fn: Any) -> Any:
    """Try daemon first, fall back to direct browser call.

    The daemon may not be running or may fail to start. In that case,
    fall back to direct browser launch (the pre-daemon behavior).
    Note: if the daemon IS running, the fallback will likely fail because
    the daemon holds the Chromium profile lock.
    """
    try:
        from stride.daemon_client import DaemonClient, DaemonConnectionError

        client = await DaemonClient.connect_or_start()
        try:
            result = await client.send(method, args)
            return result
        finally:
            await client.close()
    except (NotLoggedInError, BrowserNotAvailableError):
        # These are real errors from the daemon, don't fall back
        raise
    except Exception:
        # Daemon unavailable -- fall back to direct browser
        return await fallback_fn()


# --- X commands ---

x_app = typer.Typer(name="x", help="X (Twitter) channel commands.", no_args_is_help=True)
channel_app.add_typer(x_app, name="x")


@x_app.command("login")
def x_login():
    """Log in to X via browser (opens a visible browser window)."""
    from stride.channel.x import XChannel

    async def _run():
        channel = XChannel(headless=False)
        success = await channel.login()
        if success:
            console.print("[green]X login successful. Session saved.[/green]")
        else:
            console.print("[red]X login failed or timed out.[/red]")
            raise typer.Exit(1)

    asyncio.run(_run())


@x_app.command("status")
def x_status():
    """Check X session status."""

    async def _run():
        async def _direct():
            from stride.channel.x import XChannel

            channel = XChannel()
            status = await channel.check_status()
            return dataclasses.asdict(status)

        result = await _via_daemon_or_direct("x_status", {}, _direct)

        if result.get("connected"):
            console.print(f"[green]Connected to X as @{result.get('username', '')}[/green]")
        else:
            console.print(f"[red]Not connected to X.[/red] {result.get('error', '')}")
            console.print("Run: stride channel x login")

    asyncio.run(_run())


@x_app.command("post")
def x_post(
    text: str = typer.Argument(help="Tweet text to post"),
    image: Optional[Path] = typer.Option(None, "--image", help="Path to image/video file", exists=True),
    community: Optional[str] = typer.Option(None, "--community", help="Community URL to post in"),
    self_reply: Optional[str] = typer.Option(None, "--self-reply", help="Text for a self-reply after posting"),
    thread: Optional[list[str]] = typer.Option(None, "--thread", help="Thread reply texts (use multiple --thread flags)"),
):
    """Post a tweet to X.

    Supports image upload, community posting, self-reply, and threading.
    """
    # CLI-level validation: mutually exclusive options
    if self_reply and thread:
        console.print("[red]Cannot use both --self-reply and --thread. They are mutually exclusive.[/red]")
        raise typer.Exit(1)
    if community and (self_reply or thread):
        console.print("[red]Cannot use --community with --self-reply or --thread.[/red]")
        raise typer.Exit(1)

    async def _run():
        kwargs: dict[str, object] = {"content": text}
        if image:
            kwargs["image"] = str(image)
        if community:
            kwargs["community"] = community
        if self_reply:
            kwargs["self_reply"] = self_reply
        if thread:
            kwargs["thread"] = thread

        async def _direct():
            from stride.channel.x import XChannel

            channel = XChannel()
            result = await channel.post(
                text,
                image=str(image) if image else None,
                community=community,
                self_reply=self_reply,
                thread=thread,
            )
            return dataclasses.asdict(result)

        result = await _via_daemon_or_direct("x_post", kwargs, _direct)

        if result.get("success"):
            console.print("[green]Posted successfully.[/green]")
            if result.get("url"):
                console.print(f"URL: {result['url']}")
            if result.get("error"):
                console.print(f"[yellow]Note: {result['error']}[/yellow]")
        else:
            console.print(f"[red]Failed to post:[/red] {result.get('error', 'Unknown error')}")
            raise typer.Exit(1)

    asyncio.run(_run())


@x_app.command("reply")
def x_reply(
    url: str = typer.Argument(help="Tweet URL to reply to"),
    text: str = typer.Argument(help="Reply text"),
):
    """Reply to a tweet on X."""

    async def _run():
        async def _direct():
            from stride.channel.x import XChannel

            channel = XChannel()
            result = await channel.reply(url, text)
            return dataclasses.asdict(result)

        result = await _via_daemon_or_direct(
            "x_reply", {"target_url": url, "content": text}, _direct
        )

        if result.get("success"):
            console.print("[green]Reply posted successfully.[/green]")
        else:
            console.print(f"[red]Failed to reply:[/red] {result.get('error', 'Unknown error')}")
            raise typer.Exit(1)

    asyncio.run(_run())


@x_app.command("search")
def x_search(
    query: str = typer.Argument(help="Search query"),
    max_results: int = typer.Option(50, "--max", "-n", help="Maximum results to return"),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON (for AI agent integration)"),
):
    """Search tweets on X (Latest tab)."""

    async def _run():
        async def _direct():
            from stride.channel.x import XChannel

            channel = XChannel()
            return await channel.search_tweets(query, max_results=max_results)

        try:
            results = await _via_daemon_or_direct(
                "x_search", {"query": query, "max_results": max_results}, _direct
            )
        except NotLoggedInError:
            if as_json:
                print(json.dumps({"error": "Not logged in to X"}))
            else:
                console.print("[red]Not logged in to X.[/red] Run: stride channel x login")
            raise typer.Exit(1)
        except BrowserNotAvailableError:
            if as_json:
                print(json.dumps({"error": "Browser not available. Run 'stride setup' first."}))
            else:
                console.print("[red]Browser not available.[/red] Run: stride setup")
            raise typer.Exit(1)

        from stride.output import output_results

        # Add URL for chaining (search -> reply)
        for tweet in results:
            tweet["url"] = f"https://x.com/{tweet.get('username', '')}/status/{tweet.get('tweet_id', '')}"

        output_results(
            results,
            as_json=as_json,
            console=console,
            columns=["username", "text", "views", "created_at"],
        )

    asyncio.run(_run())


@x_app.command("feed")
def x_feed(
    max_results: int = typer.Option(100, "--max", "-n", help="Maximum results to return"),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON (for AI agent integration)"),
):
    """Get home timeline from X."""

    async def _run():
        async def _direct():
            from stride.channel.x import XChannel

            channel = XChannel()
            return await channel.get_home_timeline(max_results=max_results)

        try:
            results = await _via_daemon_or_direct(
                "x_feed", {"max_results": max_results}, _direct
            )
        except NotLoggedInError:
            if as_json:
                print(json.dumps({"error": "Not logged in to X"}))
            else:
                console.print("[red]Not logged in to X.[/red] Run: stride channel x login")
            raise typer.Exit(1)
        except BrowserNotAvailableError:
            if as_json:
                print(json.dumps({"error": "Browser not available. Run 'stride setup' first."}))
            else:
                console.print("[red]Browser not available.[/red] Run: stride setup")
            raise typer.Exit(1)

        from stride.output import output_results

        for tweet in results:
            tweet["url"] = f"https://x.com/{tweet.get('username', '')}/status/{tweet.get('tweet_id', '')}"

        output_results(
            results,
            as_json=as_json,
            console=console,
            columns=["username", "text", "views", "created_at"],
        )

    asyncio.run(_run())


@x_app.command("help")
def x_help():
    """Show X-specific guidance and tips."""
    guide = """[bold]X (Twitter) Channel Guide[/bold]

[bold cyan]Posting:[/bold cyan]
  - Tweets have a 280 character limit
  - Image formats: .png, .jpg, .jpeg, .gif, .webp, .mp4
  - Use --self-reply for a follow-up tweet to your own post
  - Use --thread with multiple flags for longer threads
  - --self-reply and --thread are mutually exclusive
  - --community is incompatible with --self-reply and --thread

[bold cyan]Search & Feed:[/bold cyan]
  stride channel x search "just launched" --max 20
  stride channel x search "indie hacker" --json
  stride channel x feed --max 50
  stride channel x feed --json

[bold cyan]Rate limits:[/bold cyan]
  - X may throttle posting if you post too frequently
  - Space posts out by at least a few minutes
  - Replies have similar rate limits

[bold cyan]Thread syntax:[/bold cyan]
  stride channel x post "Main tweet" --thread "Reply 1" --thread "Reply 2"

[bold cyan]Reset:[/bold cyan]
  stride channel x reset
  Note: This resets ALL channel sessions (X and Reddit share one browser profile)."""

    console.print(Panel(guide, title="X Guide", border_style="blue"))


@x_app.command("reset")
def x_reset():
    """Reset browser session for X (clears all channel sessions)."""
    # Stop daemon first -- it holds the Chromium profile lock
    _stop_daemon_if_running()

    from stride.cli import reset_browser_profile

    reset_browser_profile(
        confirm_msg="This will reset the browser profile, clearing ALL channel sessions (X and Reddit share one profile). Continue?"
    )


# --- Reddit commands ---

reddit_app = typer.Typer(
    name="reddit", help="Reddit channel commands.", no_args_is_help=True
)
channel_app.add_typer(reddit_app, name="reddit")


@reddit_app.command("login")
def reddit_login():
    """Log in to Reddit via browser (opens a visible browser window)."""
    from stride.channel.reddit import RedditChannel

    async def _run():
        channel = RedditChannel(headless=False)
        success = await channel.login()
        if success:
            console.print("[green]Reddit login successful. Session saved.[/green]")
        else:
            console.print("[red]Reddit login failed or timed out.[/red]")
            raise typer.Exit(1)

    asyncio.run(_run())


@reddit_app.command("status")
def reddit_status():
    """Check Reddit session status."""

    async def _run():
        async def _direct():
            from stride.channel.reddit import RedditChannel

            channel = RedditChannel()
            status = await channel.check_status()
            return dataclasses.asdict(status)

        result = await _via_daemon_or_direct("reddit_status", {}, _direct)

        if result.get("connected"):
            console.print(f"[green]Connected to Reddit as u/{result.get('username', '')}[/green]")
        else:
            console.print(f"[red]Not connected to Reddit.[/red] {result.get('error', '')}")
            console.print("Run: stride channel reddit login")

    asyncio.run(_run())


@reddit_app.command("post")
def reddit_post(
    subreddit: str = typer.Option(..., "--subreddit", "-s", help="Target subreddit"),
    title: str = typer.Option(..., "--title", "-t", help="Post title"),
    body: str = typer.Option("", "--body", "-b", help="Post body text"),
    url: Optional[str] = typer.Option(None, "--url", help="URL for link posts"),
    image: Optional[Path] = typer.Option(None, "--image", help="Path to image file", exists=True),
):
    """Post to a subreddit on Reddit.

    Supports text posts (default), link posts (--url), and image posts (--image).
    """
    # CLI-level validation: mutually exclusive options
    if image and url:
        console.print("[red]Cannot use both --image and --url. Only one post type at a time.[/red]")
        raise typer.Exit(1)

    # Warn if body is provided with url or image
    if body and (url or image):
        post_type = "link" if url else "image"
        print(f"Warning: --body is ignored for {post_type} posts.", file=sys.stderr)

    async def _run():
        kwargs = {
            "content": body,
            "subreddit": subreddit,
            "title": title,
        }
        if url:
            kwargs["url"] = url
        if image:
            kwargs["image"] = str(image)

        async def _direct():
            from stride.channel.reddit import RedditChannel

            channel = RedditChannel()
            result = await channel.post(
                body,
                subreddit=subreddit,
                title=title,
                url=url,
                image=str(image) if image else None,
            )
            return dataclasses.asdict(result)

        try:
            result = await _via_daemon_or_direct("reddit_post", kwargs, _direct)
        except NotLoggedInError:
            console.print("[red]Not logged in to Reddit.[/red] Run: stride channel reddit login")
            raise typer.Exit(1)
        except BrowserNotAvailableError:
            console.print("[red]Browser not available.[/red] Run: stride setup")
            raise typer.Exit(1)

        if result.get("success"):
            console.print("[green]Posted successfully.[/green]")
            if result.get("url"):
                console.print(f"URL: {result['url']}")
        else:
            console.print(f"[red]Failed to post:[/red] {result.get('error', 'Unknown error')}")
            raise typer.Exit(1)

    asyncio.run(_run())


@reddit_app.command("reply")
def reddit_reply(
    url: str = typer.Argument(help="Reddit post URL to reply to"),
    text: str = typer.Argument(help="Comment text"),
):
    """Reply to a post on Reddit."""

    async def _run():
        async def _direct():
            from stride.channel.reddit import RedditChannel

            channel = RedditChannel()
            result = await channel.reply(url, text)
            return dataclasses.asdict(result)

        try:
            result = await _via_daemon_or_direct(
                "reddit_reply", {"target_url": url, "content": text}, _direct
            )
        except NotLoggedInError:
            console.print("[red]Not logged in to Reddit.[/red] Run: stride channel reddit login")
            raise typer.Exit(1)
        except BrowserNotAvailableError:
            console.print("[red]Browser not available.[/red] Run: stride setup")
            raise typer.Exit(1)

        if result.get("success"):
            console.print("[green]Comment posted successfully.[/green]")
        else:
            console.print(f"[red]Failed to comment:[/red] {result.get('error', 'Unknown error')}")
            raise typer.Exit(1)

    asyncio.run(_run())


@reddit_app.command("search")
def reddit_search(
    query: str = typer.Argument(help="Search query"),
    subreddit: Optional[str] = typer.Option(None, "--subreddit", "-s", help="Limit search to a subreddit"),
    sort: str = typer.Option("relevance", "--sort", help="Sort order: relevance, hot, top, new, comments"),
    time: str = typer.Option("week", "--time", help="Time filter: hour, day, week, month, year, all"),
    max_results: int = typer.Option(30, "--max", "-n", help="Maximum results to return"),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON (for AI agent integration)"),
):
    """Search Reddit posts."""

    async def _run():
        daemon_args = {
            "query": query,
            "sort": sort,
            "time_filter": time,
            "max_results": max_results,
        }
        if subreddit:
            daemon_args["subreddit"] = subreddit

        async def _direct():
            from stride.channel.reddit import RedditChannel

            channel = RedditChannel()
            results = await channel.search_posts(
                query,
                subreddit=subreddit,
                sort=sort,
                time_filter=time,
                max_results=max_results,
            )
            return [dataclasses.asdict(r) for r in results]

        try:
            results = await _via_daemon_or_direct("reddit_search", daemon_args, _direct)
        except NotLoggedInError:
            if as_json:
                print(json.dumps({"error": "Not logged in to Reddit"}))
            else:
                console.print("[red]Not logged in to Reddit.[/red] Run: stride channel reddit login")
            raise typer.Exit(1)
        except BrowserNotAvailableError:
            if as_json:
                print(json.dumps({"error": "Browser not available. Run 'stride setup' first."}))
            else:
                console.print("[red]Browser not available.[/red] Run: stride setup")
            raise typer.Exit(1)

        from stride.output import output_results

        items = results if isinstance(results, list) else []
        for item in items:
            if item.get("permalink"):
                item["url"] = f"https://www.reddit.com{item['permalink']}"

        output_results(
            items,
            as_json=as_json,
            console=console,
            columns=["subreddit", "title", "score", "comment_count", "author"],
        )

    asyncio.run(_run())


@reddit_app.command("browse")
def reddit_browse(
    subreddit: str = typer.Argument(help="Subreddit name (e.g. 'python' or 'r/python')"),
    sort: str = typer.Option("hot", "--sort", help="Sort order: hot, new, top"),
    max_results: int = typer.Option(30, "--max", "-n", help="Maximum results to return"),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON (for AI agent integration)"),
):
    """Browse posts from a subreddit."""
    # Strip "r/" prefix if provided
    if subreddit.startswith("r/"):
        subreddit = subreddit[2:]

    async def _run():
        async def _direct():
            from stride.channel.reddit import RedditChannel

            channel = RedditChannel()
            results = await channel.get_subreddit_posts(
                subreddit, sort=sort, max_results=max_results
            )
            return [dataclasses.asdict(r) for r in results]

        try:
            results = await _via_daemon_or_direct(
                "reddit_browse",
                {"subreddit": subreddit, "sort": sort, "max_results": max_results},
                _direct,
            )
        except NotLoggedInError:
            if as_json:
                print(json.dumps({"error": "Not logged in to Reddit"}))
            else:
                console.print("[red]Not logged in to Reddit.[/red] Run: stride channel reddit login")
            raise typer.Exit(1)
        except BrowserNotAvailableError:
            if as_json:
                print(json.dumps({"error": "Browser not available. Run 'stride setup' first."}))
            else:
                console.print("[red]Browser not available.[/red] Run: stride setup")
            raise typer.Exit(1)

        from stride.output import output_results

        items = results if isinstance(results, list) else []
        for item in items:
            if item.get("permalink"):
                item["url"] = f"https://www.reddit.com{item['permalink']}"

        output_results(
            items,
            as_json=as_json,
            console=console,
            columns=["subreddit", "title", "score", "comment_count", "author"],
        )

    asyncio.run(_run())


@reddit_app.command("feed")
def reddit_feed(
    max_results: int = typer.Option(30, "--max", "-n", help="Maximum results to return"),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON (for AI agent integration)"),
):
    """Get your Reddit home feed (based on subscribed subreddits)."""

    async def _run():
        async def _direct():
            from stride.channel.reddit import RedditChannel

            channel = RedditChannel()
            results = await channel.get_home_feed(max_results=max_results)
            return [dataclasses.asdict(r) for r in results]

        try:
            results = await _via_daemon_or_direct(
                "reddit_feed", {"max_results": max_results}, _direct
            )
        except NotLoggedInError:
            if as_json:
                print(json.dumps({"error": "Not logged in to Reddit"}))
            else:
                console.print("[red]Not logged in to Reddit.[/red] Run: stride channel reddit login")
            raise typer.Exit(1)
        except BrowserNotAvailableError:
            if as_json:
                print(json.dumps({"error": "Browser not available. Run 'stride setup' first."}))
            else:
                console.print("[red]Browser not available.[/red] Run: stride setup")
            raise typer.Exit(1)

        from stride.output import output_results

        items = results if isinstance(results, list) else []
        for item in items:
            if item.get("permalink"):
                item["url"] = f"https://www.reddit.com{item['permalink']}"

        output_results(
            items,
            as_json=as_json,
            console=console,
            columns=["subreddit", "title", "score", "comment_count", "author"],
        )

    asyncio.run(_run())


@reddit_app.command("comments")
def reddit_comments(
    url: str = typer.Argument(help="Reddit post URL or permalink (e.g. /r/sub/comments/...)"),
    max_results: int = typer.Option(50, "--max", "-n", help="Maximum comments to return"),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON (for AI agent integration)"),
):
    """Get comments from a Reddit post."""

    async def _run():
        async def _direct():
            from stride.channel.reddit import RedditChannel

            channel = RedditChannel()
            results = await channel.get_post_comments(url, max_results=max_results)
            return [dataclasses.asdict(r) for r in results]

        try:
            results = await _via_daemon_or_direct(
                "reddit_comments", {"post_url": url, "max_results": max_results}, _direct
            )
        except NotLoggedInError:
            if as_json:
                print(json.dumps({"error": "Not logged in to Reddit"}))
            else:
                console.print("[red]Not logged in to Reddit.[/red] Run: stride channel reddit login")
            raise typer.Exit(1)
        except BrowserNotAvailableError:
            if as_json:
                print(json.dumps({"error": "Browser not available. Run 'stride setup' first."}))
            else:
                console.print("[red]Browser not available.[/red] Run: stride setup")
            raise typer.Exit(1)

        from stride.output import output_results

        items = results if isinstance(results, list) else []
        output_results(
            items,
            as_json=as_json,
            console=console,
            columns=["author", "text", "score", "depth"],
        )

    asyncio.run(_run())


@reddit_app.command("help")
def reddit_help():
    """Show Reddit-specific guidance and tips."""
    guide = """[bold]Reddit Channel Guide[/bold]

[bold cyan]Post types:[/bold cyan]
  - Text post (default): --subreddit, --title, --body
  - Link post: --subreddit, --title, --url (--body is ignored)
  - Image post: --subreddit, --title, --image (--body is ignored)
  - --image and --url are mutually exclusive

[bold cyan]Search, Feed & Browse:[/bold cyan]
  stride channel reddit search "indie hacker" --max 20
  stride channel reddit search "python tools" -s python --json
  stride channel reddit feed --max 20 --json
  stride channel reddit browse python --sort hot
  stride channel reddit comments https://reddit.com/r/.../comments/... --json

[bold cyan]Image formats:[/bold cyan]
  .png, .jpg, .jpeg, .gif, .webp

[bold cyan]Subreddit rules:[/bold cyan]
  - Each subreddit has its own rules for posting
  - Some require minimum karma or account age
  - Check subreddit rules before posting
  - Rate limits apply per subreddit

[bold cyan]Tips:[/bold cyan]
  - Use descriptive titles for better engagement
  - Follow subreddit formatting conventions
  - Space out posts to avoid rate limits

[bold cyan]Reset:[/bold cyan]
  stride channel reddit reset
  Note: This resets ALL channel sessions (X and Reddit share one browser profile)."""

    console.print(Panel(guide, title="Reddit Guide", border_style="orange1"))


@reddit_app.command("reset")
def reddit_reset():
    """Reset browser session for Reddit (clears all channel sessions)."""
    # Stop daemon first -- it holds the Chromium profile lock
    _stop_daemon_if_running()

    from stride.cli import reset_browser_profile

    reset_browser_profile(
        confirm_msg="This will reset the browser profile, clearing ALL channel sessions (X and Reddit share one profile). Continue?"
    )


def _stop_daemon_if_running() -> None:
    """Send shutdown to daemon if it's running, before profile operations."""
    try:
        from stride.daemon_client import DaemonClient

        if DaemonClient.is_running():
            import time

            async def _stop():
                try:
                    client = await DaemonClient._connect()
                    await client.send("shutdown")
                    await client.close()
                except Exception:
                    pass

            asyncio.run(_stop())
            # Wait briefly for daemon to finish cleanup
            for _ in range(10):
                if not DaemonClient.is_running():
                    break
                time.sleep(0.5)
            console.print("[dim]Stopped daemon before resetting profile.[/dim]")
    except Exception:
        pass
