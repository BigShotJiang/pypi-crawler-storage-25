"""Reddit channel implementation.

Browser-based automation for posting, replying, and checking login status on Reddit.
Ported from stride-server/src/services/reddit_browser.py with new post() features
(URL/link posts, image posts).
"""

from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote as url_quote

from playwright.async_api import Page

from stride.browser.service import BrowserNotAvailableError, BrowserService, NotLoggedInError
from stride.channel.base import ChannelStatus, PostResult, ReplyResult
from stride.config import load_config

# Valid image extensions for Reddit uploads
_VALID_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp"}


@dataclass
class RedditPost:
    title: str
    permalink: str
    author: str = ""
    score: int = 0
    comment_count: int = 0
    subreddit: str = ""


@dataclass
class RedditComment:
    author: str
    text: str
    score: int = 0
    depth: int = 0
    thing_id: str = ""


# JS to extract posts from subreddit pages (shreddit-post custom elements)
_EXTRACT_POSTS_JS = """
() => {
    const posts = [];
    for (const el of document.querySelectorAll('shreddit-post')) {
        try {
            const title = el.getAttribute('post-title') || '';
            const permalink = el.getAttribute('permalink') || '';
            const author = el.getAttribute('author') || '';
            const score = el.getAttribute('score') || '0';
            const commentCount = el.getAttribute('comment-count') || '0';
            const subreddit = el.getAttribute('subreddit-prefixed-name') || '';
            if (title && author) {
                posts.push({ title, permalink, author, score: parseInt(score) || 0,
                             comment_count: parseInt(commentCount) || 0, subreddit });
            }
        } catch(e) {}
    }
    return posts;
}
"""

# JS to extract posts from search results (different DOM structure, link-based)
_EXTRACT_SEARCH_JS = """
() => {
    const posts = [];
    const seen = new Set();
    // Search results don't use shreddit-post; extract from comment links
    const links = document.querySelectorAll('a[href*="/comments/"]');
    for (const link of links) {
        const href = link.getAttribute('href') || '';
        if (!href || seen.has(href)) continue;
        const match = href.match(/\\/r\\/([^\\/]+)\\/comments\\/([^\\/]+)/);
        if (!match) continue;
        let title = '';
        const text = link.textContent.trim();
        if (text.length > 10 && !text.match(/^\\d+ (comment|vote|point)/)) {
            title = text;
        }
        if (!title) {
            const parent = link.closest('[class*="result"], [class*="Post"], li, div');
            if (parent) {
                const h = parent.querySelector('h2, h3, [slot="title"]');
                if (h) title = h.textContent.trim();
            }
        }
        if (!title) title = text || href;
        if (!seen.has(href)) {
            seen.add(href);
            posts.push({
                title: title.substring(0, 300),
                permalink: href,
                author: '',
                score: 0,
                comment_count: 0,
                subreddit: 'r/' + match[1]
            });
        }
    }
    return posts;
}
"""

# JS to extract comments from a post page (shreddit-comment custom elements)
_EXTRACT_COMMENTS_JS = """
() => {
    const comments = [];
    for (const el of document.querySelectorAll('shreddit-comment')) {
        try {
            const author = el.getAttribute('author') || '';
            const score = el.getAttribute('score') || '0';
            const depth = el.getAttribute('depth') || '0';
            const thingId = el.getAttribute('thingid') || '';
            const contentEl = el.querySelector('[id^="comment-content"] p, [slot="comment"] p, .md p');
            let text = '';
            if (contentEl) {
                text = contentEl.closest('.md, [id^="comment-content"]')?.innerText || contentEl.innerText || '';
            }
            if (author && text) {
                comments.push({
                    author,
                    text: text.substring(0, 2000),
                    score: parseInt(score) || 0,
                    depth: parseInt(depth) || 0,
                    thing_id: thingId
                });
            }
        } catch(e) {}
    }
    return comments;
}
"""


def _normalize_reddit_url(url: str) -> str:
    """Normalize Reddit URLs: prepend domain if URL starts with /r/."""
    if url.startswith("/r/"):
        return f"https://www.reddit.com{url}"
    return url


class RedditChannel:
    """Reddit channel using browser automation."""

    def __init__(self, headless: bool | None = None, profile_dir: str | None = None, browser_service: BrowserService | None = None):
        if browser_service:
            self._browser = browser_service
            self._owns_browser = False
        else:
            self._owns_browser = True
            config = load_config()
            self._headless = headless if headless is not None else config.browser.headless
            self._profile_dir = profile_dir or config.browser.profile_dir
            self._browser: BrowserService | None = None

    async def _get_browser(self) -> BrowserService:
        if self._browser is None:
            try:
                self._browser = BrowserService(
                    profile_dir=self._profile_dir,
                    headless=self._headless,
                )
                await self._browser.start()
            except Exception as exc:
                self._browser = None
                raise BrowserNotAvailableError(
                    "Browser not available. Run 'stride setup' first to install Chromium."
                ) from exc
        return self._browser

    async def _cleanup(self) -> None:
        if self._owns_browser and self._browser:
            await self._browser.stop()
            self._browser = None
        # When _owns_browser is False, do nothing -- page cleanup
        # is handled by close_page() in the method's finally block

    async def _check_logged_in(self, page: Page) -> bool:
        """Check if current page shows a logged-in Reddit session.

        Inspects the DOM for user indicators (u/ links, user menu).
        Note: assumes new Reddit (Shreddit) UI at www.reddit.com.
        Old Reddit (old.reddit.com) has different selectors.
        """
        result = await page.evaluate("""() => {
            const links = document.querySelectorAll('a[href*="/user/"]');
            for (const link of links) {
                const text = link.textContent || '';
                if (text.startsWith('u/')) return true;
            }
            const userMenu = document.querySelector('[id="USER_DROPDOWN_ID"], [data-testid="user-drawer-button"]');
            return !!userMenu;
        }""")
        return result

    async def _scroll_and_extract(
        self,
        page: Page,
        js_fn: str,
        dedup_key: str,
        max_results: int,
        max_scrolls: int = 8,
    ) -> list[dict]:
        """Scroll a page and extract items using a JS function, deduplicating by key."""
        all_items: dict[str, dict] = {}
        no_new_count = 0

        for _i in range(max_scrolls):
            batch = await page.evaluate(js_fn)
            new_count = 0
            for item in batch:
                key = item.get(dedup_key, "")
                if key and key not in all_items:
                    all_items[key] = item
                    new_count += 1

            if len(all_items) >= max_results:
                break

            if new_count == 0:
                no_new_count += 1
                if no_new_count >= 2:
                    break
            else:
                no_new_count = 0

            await page.evaluate("window.scrollBy(0, window.innerHeight * 2)")
            await page.wait_for_timeout(2500)

        return list(all_items.values())[:max_results]

    async def search_posts(
        self,
        query: str,
        subreddit: str | None = None,
        sort: str = "relevance",
        time_filter: str = "week",
        max_results: int = 30,
    ) -> list[RedditPost]:
        """Search Reddit posts. Optionally scoped to a subreddit.

        Raises NotLoggedInError if not logged in.
        Raises BrowserNotAvailableError if browser can't start.
        Returns [] on unexpected errors.
        """
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()

            encoded_q = url_quote(query)
            if subreddit:
                url = (
                    f"https://www.reddit.com/r/{subreddit}/search/"
                    f"?q={encoded_q}&restrict_sr=1&sort={sort}&t={time_filter}"
                )
            else:
                url = (
                    f"https://www.reddit.com/search/"
                    f"?q={encoded_q}&sort={sort}&t={time_filter}"
                )

            await page.goto(url, wait_until="domcontentloaded")
            try:
                await page.wait_for_selector('shreddit-post, a[href*="/comments/"]', timeout=10000)
            except Exception:
                pass  # fallback: continue anyway

            if "/login" in page.url:
                raise NotLoggedInError("Not logged in to Reddit")

            # Search results may use shreddit-post or link-based layout
            # Try shreddit-post first, fall back to link extraction
            all_posts = await self._scroll_and_extract(
                page, _EXTRACT_POSTS_JS, "permalink", max_results
            )
            if not all_posts:
                all_posts = await self._scroll_and_extract(
                    page, _EXTRACT_SEARCH_JS, "permalink", max_results
                )

            return [
                RedditPost(
                    title=p["title"],
                    permalink=p["permalink"],
                    author=p.get("author", ""),
                    score=p.get("score", 0),
                    comment_count=p.get("comment_count", 0),
                    subreddit=p.get("subreddit", ""),
                )
                for p in all_posts
            ]
        except (BrowserNotAvailableError, NotLoggedInError):
            raise
        except Exception:
            return []
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def get_subreddit_posts(
        self,
        subreddit: str,
        sort: str = "hot",
        max_results: int = 30,
    ) -> list[RedditPost]:
        """Scrape posts from a subreddit.

        Raises NotLoggedInError if not logged in.
        Raises BrowserNotAvailableError if browser can't start.
        Returns [] on unexpected errors.
        """
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            await page.goto(
                f"https://www.reddit.com/r/{subreddit}/{sort}/",
                wait_until="domcontentloaded",
            )
            try:
                await page.wait_for_selector('shreddit-post', timeout=10000)
            except Exception:
                pass  # fallback: continue anyway

            if "/login" in page.url:
                raise NotLoggedInError("Not logged in to Reddit")

            all_posts = await self._scroll_and_extract(
                page, _EXTRACT_POSTS_JS, "permalink", max_results
            )

            return [
                RedditPost(
                    title=p["title"],
                    permalink=p["permalink"],
                    author=p.get("author", ""),
                    score=p.get("score", 0),
                    comment_count=p.get("comment_count", 0),
                    subreddit=p.get("subreddit", f"r/{subreddit}"),
                )
                for p in all_posts
            ]
        except (BrowserNotAvailableError, NotLoggedInError):
            raise
        except Exception:
            return []
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def get_home_feed(self, max_results: int = 30) -> list[RedditPost]:
        """Get the logged-in user's home feed.

        Raises NotLoggedInError if not logged in.
        Raises BrowserNotAvailableError if browser can't start.
        Returns [] on unexpected errors.
        """
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            await page.goto(
                "https://www.reddit.com/",
                wait_until="domcontentloaded",
            )
            try:
                await page.wait_for_selector('shreddit-post', timeout=10000)
            except Exception:
                pass  # fallback: continue anyway

            if "/login" in page.url:
                raise NotLoggedInError("Not logged in to Reddit")

            all_posts = await self._scroll_and_extract(
                page, _EXTRACT_POSTS_JS, "permalink", max_results
            )

            return [
                RedditPost(
                    title=p["title"],
                    permalink=p["permalink"],
                    author=p.get("author", ""),
                    score=p.get("score", 0),
                    comment_count=p.get("comment_count", 0),
                    subreddit=p.get("subreddit", ""),
                )
                for p in all_posts
            ]
        except (BrowserNotAvailableError, NotLoggedInError):
            raise
        except Exception:
            return []
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def get_post_comments(
        self,
        post_url: str,
        max_results: int = 50,
    ) -> list[RedditComment]:
        """Scrape comments from a Reddit post URL.

        Raises NotLoggedInError if not logged in.
        Raises BrowserNotAvailableError if browser can't start.
        Returns [] on unexpected errors.
        """
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()

            normalized_url = _normalize_reddit_url(post_url)

            await page.goto(normalized_url, wait_until="domcontentloaded")
            try:
                await page.wait_for_selector('shreddit-comment', timeout=10000)
            except Exception:
                pass  # fallback: continue anyway

            if "/login" in page.url:
                raise NotLoggedInError("Not logged in to Reddit")

            # Scroll to load more comments (fixed 3 scrolls)
            for _ in range(3):
                await page.evaluate("window.scrollBy(0, window.innerHeight * 2)")
                await page.wait_for_timeout(2000)

            raw = await page.evaluate(_EXTRACT_COMMENTS_JS)

            return [
                RedditComment(
                    author=c["author"],
                    text=c["text"],
                    score=c.get("score", 0),
                    depth=c.get("depth", 0),
                    thing_id=c.get("thing_id", ""),
                )
                for c in raw[:max_results]
            ]
        except (BrowserNotAvailableError, NotLoggedInError):
            raise
        except Exception:
            return []
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def login(self) -> bool:
        """Open visible browser for Reddit login. User logs in manually, cookies are saved."""
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            await page.goto("https://www.reddit.com/login/", wait_until="domcontentloaded")

            # Wait for user to complete login (detect navigation to home or other page)
            try:
                await page.wait_for_url(
                    lambda url: "/login" not in url and "reddit.com" in url,
                    timeout=120_000,
                )
                await page.wait_for_timeout(3000)
                return True
            except Exception:
                return False
        except BrowserNotAvailableError:
            return False
        finally:
            await self._cleanup()

    async def check_status(self) -> ChannelStatus:
        """Check if Reddit session is valid."""
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            await page.goto("https://www.reddit.com/settings/", wait_until="domcontentloaded")
            try:
                await page.wait_for_selector('a[href*="/user/"], [href*="/login"]', timeout=10000)
            except Exception:
                pass  # fallback: continue anyway

            # If redirected to login, not logged in
            if "/login" in page.url or "/register" in page.url:
                return ChannelStatus(connected=False, error="Session expired")

            # Extract username from settings page links
            username = ""
            try:
                # Settings page has a "Manage Communities" link with /user/USERNAME/communities
                all_links = await page.query_selector_all('a[href*="/user/"]')
                for link in all_links:
                    href = await link.get_attribute("href") or ""
                    if "/user/" in href and "/communities" in href:
                        # Extract username from /user/USERNAME/communities
                        parts = href.split("/user/")[-1].split("/")
                        if parts[0]:
                            username = parts[0]
                            break
            except Exception:
                pass

            return ChannelStatus(connected=True, username=username)
        except BrowserNotAvailableError as e:
            return ChannelStatus(connected=False, error=str(e))
        except Exception as e:
            return ChannelStatus(connected=False, error=str(e))
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def post(self, content: str, **kwargs: object) -> PostResult:
        """Post to a subreddit via browser automation.

        Supports text posts, link posts (--url), and image posts (--image).

        Kwargs:
            subreddit: Target subreddit name (required).
            title: Post title (required).
            url: URL for link posts.
            image: str path to image file.
        """
        subreddit = str(kwargs.get("subreddit", ""))
        title = str(kwargs.get("title", ""))
        url_link = str(kwargs["url"]) if kwargs.get("url") else None
        image = str(kwargs["image"]) if kwargs.get("image") else None

        if not subreddit:
            return PostResult(success=False, error="subreddit is required")
        if not title:
            return PostResult(success=False, error="title is required")

        # 1. Validate inputs upfront (before launching browser)
        if image:
            image_path = Path(image)
            if not image_path.is_file():
                return PostResult(success=False, error=f"Image file not found: {image}")
            if image_path.suffix.lower() not in _VALID_IMAGE_EXTENSIONS:
                return PostResult(
                    success=False,
                    error=f"Invalid image format '{image_path.suffix}'. Supported: {', '.join(sorted(_VALID_IMAGE_EXTENSIONS))}",
                )

        if image and url_link:
            return PostResult(
                success=False,
                error="Cannot use both --image and --url. Only one post type at a time.",
            )

        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            page.set_default_timeout(30000)

            # Navigate to submit page (supports both r/subreddit and user/username)
            if subreddit.startswith("user/"):
                submit_url = f"https://www.reddit.com/{subreddit}/submit/?type=TEXT"
            else:
                submit_url = f"https://www.reddit.com/r/{subreddit}/submit"
            await page.goto(submit_url, wait_until="domcontentloaded")
            try:
                await page.wait_for_selector('faceplate-form, r-post-type-select, textarea[placeholder*="Title"]', timeout=10000)
            except Exception:
                pass  # fallback: continue anyway

            # Check for login redirect
            if "/login" in page.url:
                return PostResult(success=False, error="Not logged in. Run 'stride channel reddit login' first.")

            if url_link:
                # TODO: Link post support — Reddit's new Shreddit UI uses tabs
                # ("Text", "Image & Video", "Link", "Poll", "AMA") inside
                # <r-post-type-select> shadow DOM. Need to click the "Link" tab
                # (xpath: /div/faceplate-tracker[3]) then fill the URL input
                # that appears. Current selectors don't work with the new UI.
                return PostResult(
                    success=False,
                    error="Link posts are not yet supported. Reddit's new UI requires updated selectors.",
                )

            elif image:
                # TODO: Image post support — Reddit's new Shreddit UI uses tabs
                # ("Text", "Image & Video", "Link", "Poll", "AMA") inside
                # <r-post-type-select> shadow DOM. Need to click the "Image & Video"
                # tab then upload via file input. Current selectors untested with
                # the new UI.
                return PostResult(
                    success=False,
                    error="Image posts are not yet supported. Reddit's new UI requires updated selectors.",
                )

            else:
                # 2. Text post (default)
                title_input = await page.wait_for_selector(
                    'textarea[placeholder*="Title"], input[placeholder*="Title"], [name="title"]',
                    timeout=10_000,
                )
                if not title_input:
                    if not await self._check_logged_in(page):
                        raise NotLoggedInError("Not logged in to Reddit. Run 'stride channel reddit login' first.")
                    return PostResult(
                        success=False,
                        error="Could not find title input. The subreddit may not exist or requires different permissions.",
                    )
                await title_input.click()
                await page.keyboard.type(title, delay=20)

                # Fill body if provided
                if content:
                    # Use :visible to avoid hidden contenteditable elements
                    body_input = page.locator('div[contenteditable="true"][role="textbox"]:visible')
                    if await body_input.count() > 0:
                        await body_input.first.click()
                        await page.wait_for_timeout(500)
                        await page.keyboard.type(content, delay=20)

            await page.wait_for_timeout(1000)

            # Click submit button (Reddit uses shadow DOM web components)
            submit_btn = page.get_by_role("button", name="Post", exact=True)
            if not await submit_btn.is_visible(timeout=5000):
                return PostResult(success=False, error="Could not find submit button")

            await submit_btn.click()

            # 5. Capture the post URL from redirect
            # Reddit briefly redirects to /submitted/?created=t3_XXXXX before
            # stripping the param. Poll quickly to catch it.
            from urllib.parse import parse_qs, urlparse

            post_url = ""
            for _ in range(20):  # Poll for up to 10 seconds
                await page.wait_for_timeout(500)
                current = page.url
                if "created=" in current:
                    parsed = urlparse(current)
                    created_id = parse_qs(parsed.query).get("created", [None])[0]
                    if created_id:
                        # Wait for the page to render, then find the post link
                        await page.wait_for_timeout(2000)
                        post_link = await page.query_selector(f'shreddit-post[id="{created_id}"] a[href*="/comments/"]')
                        if not post_link:
                            post_link = await page.query_selector(f'a[href*="/comments/"]')
                        if post_link:
                            href = await post_link.get_attribute("href")
                            if href:
                                post_url = f"https://www.reddit.com{href}" if href.startswith("/") else href
                    break
                # If we've left the submit page, post likely succeeded
                if "/submit" not in current:
                    break

            if not post_url:
                # Fallback: use whatever URL we ended up on
                post_url = page.url

            # Check if still on submit page (no redirect happened)
            if page.url.endswith("/submit") or page.url.endswith("/submit/"):
                return PostResult(success=False, error="Post submission may have failed. Still on submit page.")

            # 7. Success
            return PostResult(success=True, url=post_url)
        except (BrowserNotAvailableError, NotLoggedInError):
            raise
        except Exception as e:
            return PostResult(success=False, error=str(e))
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()

    async def reply(self, target_url: str, content: str) -> ReplyResult:
        """Reply to a Reddit post via browser automation.

        Ported from stride-server/src/services/reddit_browser.py reply_to_post().
        """
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            page.set_default_timeout(30000)

            # Normalize URL
            normalized_url = _normalize_reddit_url(target_url)

            await page.goto(normalized_url, wait_until="domcontentloaded")
            try:
                await page.wait_for_selector('comment-composer-host, shreddit-comment', timeout=10000)
            except Exception:
                pass  # fallback: continue anyway

            # Check login redirect
            if "/login" in page.url:
                return ReplyResult(success=False, error="Not logged in. Run 'stride channel reddit login' first.")

            # Step 1: Scroll comment-composer-host into view and click to expand
            await page.evaluate("""
                () => {
                    const host = document.querySelector('comment-composer-host');
                    if (host) host.scrollIntoView({ block: 'center' });
                }
            """)
            await page.wait_for_timeout(1000)

            # Get bounding box via JS
            host_box = await page.evaluate("""
                () => {
                    const host = document.querySelector('comment-composer-host');
                    if (!host) return null;
                    const r = host.getBoundingClientRect();
                    return { x: r.x + r.width / 2, y: r.y + r.height / 2, w: r.width, h: r.height };
                }
            """)

            if not host_box or host_box["w"] == 0:
                if not await self._check_logged_in(page):
                    raise NotLoggedInError("Not logged in to Reddit. Run 'stride channel reddit login' first.")
                return ReplyResult(success=False, error="Comment composer not found on page")

            await page.mouse.click(host_box["x"], host_box["y"])
            await page.wait_for_timeout(2000)

            # Step 2: Find and click the visible expanded textbox, then type
            comment_box = page.locator('div[contenteditable="true"][role="textbox"]:visible')
            if await comment_box.count() == 0:
                return ReplyResult(success=False, error="Textbox did not expand after click")

            await comment_box.first.click()
            await page.wait_for_timeout(500)
            await page.keyboard.type(content, delay=20)
            await page.wait_for_timeout(1000)

            # Step 3: Click the Comment button (pierces shadow DOM via get_by_role)
            comment_btn = page.get_by_role("button", name="Comment", exact=True)
            if not await comment_btn.is_visible(timeout=3000):
                return ReplyResult(success=False, error="Comment button not found or not visible")

            await comment_btn.click()
            await page.wait_for_timeout(3000)

            return ReplyResult(success=True)
        except (BrowserNotAvailableError, NotLoggedInError):
            raise
        except Exception as e:
            return ReplyResult(success=False, error=str(e))
        finally:
            if page and not page.is_closed() and self._browser:
                await self._browser.close_page(page)
            if self._owns_browser:
                await self._cleanup()
