"""Base channel protocol.

All distribution channels (X, Reddit, etc.) implement this interface.
"""

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass
class ChannelStatus:
    connected: bool
    username: str = ""
    error: str = ""


@dataclass
class PostResult:
    success: bool
    url: str = ""
    error: str = ""


@dataclass
class ReplyResult:
    success: bool
    url: str = ""
    error: str = ""


@runtime_checkable
class Channel(Protocol):
    """Protocol that all distribution channels must implement."""

    async def login(self) -> bool:
        """Open visible browser for one-time authentication. Returns True on success."""
        ...

    async def check_status(self) -> ChannelStatus:
        """Check if the current session is valid."""
        ...

    async def post(self, content: str, **kwargs: object) -> PostResult:
        """Create a new post on the platform."""
        ...

    async def reply(self, target_url: str, content: str) -> ReplyResult:
        """Reply to an existing post on the platform."""
        ...
