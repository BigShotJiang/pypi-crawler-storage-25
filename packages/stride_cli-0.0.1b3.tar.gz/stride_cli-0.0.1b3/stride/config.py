"""Stride CLI configuration management.

Config file lives at ~/.stride/config.toml.
"""

from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore[no-redef]


STRIDE_DIR = Path.home() / ".stride"
CONFIG_PATH = STRIDE_DIR / "config.toml"


@dataclass
class BrowserConfig:
    profile_dir: str = str(STRIDE_DIR / "browser-profile")
    headless: bool = True


@dataclass
class Config:
    browser: BrowserConfig = field(default_factory=BrowserConfig)


def load_config() -> Config:
    """Load config from ~/.stride/config.toml, falling back to defaults."""
    if not CONFIG_PATH.exists():
        return Config()

    data = tomllib.loads(CONFIG_PATH.read_text())
    browser_data = data.get("browser", {})
    browser = BrowserConfig(
        profile_dir=browser_data.get("profile_dir", str(STRIDE_DIR / "browser-profile")),
        headless=browser_data.get("headless", True),
    )
    return Config(browser=browser)
