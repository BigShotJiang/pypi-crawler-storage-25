# stride-cli

Distribution automation CLI for indie builders. Post, reply, search, and engage across X and Reddit via local browser automation. No API keys needed.

## Install

```bash
# Recommended (isolated install)
pipx install stride-cli
# or
uv tool install stride-cli

# First-time setup (installs Chromium)
stride setup

# Log in to your accounts
stride channel x login       # Opens browser for X login
stride channel reddit login  # Opens browser for Reddit login
```

## What it does

Stride CLI automates social media distribution using a real browser on your machine. No API keys, no rate limit fees, no platform restrictions.

```bash
# Post to X
stride channel x post "just shipped v2, feedback welcome"
stride channel x post "hello" --image screenshot.png
stride channel x post "main tweet" --thread "reply 1" --thread "reply 2"

# Reply on X
stride channel x reply https://x.com/user/status/123 "great insight, thanks for sharing"

# Search X (find engagement targets)
stride channel x search "just launched no users" --max 20
stride channel x search "indie hacker" --json    # JSON output for AI tools

# Browse your X feed
stride channel x feed --max 50

# Post to Reddit
stride channel reddit post -s SideProject -t "Show: My new tool" -b "Built this over the weekend..."

# Reply on Reddit
stride channel reddit reply https://reddit.com/r/sub/comments/abc/title "helpful comment"

# Search Reddit
stride channel reddit search "side project marketing" --max 20
stride channel reddit browse python --sort hot

# Get post comments (for context before replying)
stride channel reddit comments https://reddit.com/r/sub/comments/abc/title
```

## AI Tool Integration

Add Stride capabilities to Claude Code, Cursor, or any AI tool:

```
Read and follow instructions at https://strideday.com/skill.md
```

Your AI assistant will know how to use the CLI and apply distribution methodology.

## Features

- **X**: Post (with images, threads, self-reply, community), reply, search, feed
- **Reddit**: Post, reply, search, browse subreddits, read comments, feed
- **Browser daemon**: Auto-starts on first command, keeps Chromium warm for fast subsequent commands (~2s)
- **Rate limiting**: Per-platform queues prevent account flagging
- **--json flag**: Structured output on all search/browse/feed commands for AI agent integration
- **No API keys**: Everything runs through a real browser on your machine

## How it works

Stride uses Playwright to automate a real Chromium browser with a persistent profile. Your login sessions are saved locally at `~/.stride/browser-profile/`. All actions run headless (invisible) by default.

A background daemon keeps the browser warm between commands, so the first command takes ~3s and subsequent commands take ~2s.

## Links

- Website: https://www.strideday.com
- Free distribution audit: https://www.strideday.com/audit
- AI skill definition: https://www.strideday.com/skill.md
