"""CLI smoke tests (subprocess).

These test that CLI commands are properly wired up and produce expected help text.
"""

import re
import subprocess
import sys

import pytest

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def run_stride(*args: str) -> subprocess.CompletedProcess:
    """Run a stride CLI command and return the result."""
    result = subprocess.run(
        [sys.executable, "-m", "stride", *args],
        capture_output=True,
        text=True,
        cwd=None,
    )
    # Strip ANSI escape codes so assertions work in CI
    result.stdout = _ANSI_RE.sub("", result.stdout)
    result.stderr = _ANSI_RE.sub("", result.stderr)
    return result


class TestMainCommands:
    def test_help_flag(self):
        result = run_stride("--help")
        assert result.returncode == 0
        assert "channel" in result.stdout

    def test_help_command(self):
        result = run_stride("help")
        assert result.returncode == 0
        assert "setup" in result.stdout
        assert "channel" in result.stdout
        assert "reset" in result.stdout

    def test_reset_help(self):
        result = run_stride("reset", "--help")
        assert result.returncode == 0


class TestXCommands:
    def test_x_help_flag(self):
        result = run_stride("channel", "x", "--help")
        assert result.returncode == 0
        for cmd in ["post", "reply", "login", "status", "help", "reset"]:
            assert cmd in result.stdout

    def test_x_post_help(self):
        result = run_stride("channel", "x", "post", "--help")
        assert result.returncode == 0
        assert "--image" in result.stdout
        assert "--community" in result.stdout
        assert "--self-reply" in result.stdout
        assert "--thread" in result.stdout

    def test_x_help_command(self):
        result = run_stride("channel", "x", "help")
        assert result.returncode == 0

    def test_x_reset_help(self):
        result = run_stride("channel", "x", "reset", "--help")
        assert result.returncode == 0


class TestRedditCommands:
    def test_reddit_help_flag(self):
        result = run_stride("channel", "reddit", "--help")
        assert result.returncode == 0
        for cmd in ["post", "reply", "login", "status", "help", "reset"]:
            assert cmd in result.stdout

    def test_reddit_post_help(self):
        result = run_stride("channel", "reddit", "post", "--help")
        assert result.returncode == 0
        assert "--url" in result.stdout
        assert "--image" in result.stdout
        assert "--subreddit" in result.stdout
        assert "--title" in result.stdout

    def test_reddit_help_command(self):
        result = run_stride("channel", "reddit", "help")
        assert result.returncode == 0

    def test_reddit_reset_help(self):
        result = run_stride("channel", "reddit", "reset", "--help")
        assert result.returncode == 0


class TestDaemonCommands:
    def test_daemon_status_help(self):
        result = run_stride("daemon", "status", "--help")
        assert result.returncode == 0

    def test_daemon_stop_help(self):
        result = run_stride("daemon", "stop", "--help")
        assert result.returncode == 0

    def test_daemon_restart_help(self):
        result = run_stride("daemon", "restart", "--help")
        assert result.returncode == 0

    def test_daemon_help_flag(self):
        result = run_stride("daemon", "--help")
        assert result.returncode == 0
        for cmd in ["status", "stop", "restart"]:
            assert cmd in result.stdout

    def test_help_lists_daemon(self):
        """The main help command should list daemon commands."""
        result = run_stride("help")
        assert result.returncode == 0
        assert "daemon" in result.stdout.lower()
