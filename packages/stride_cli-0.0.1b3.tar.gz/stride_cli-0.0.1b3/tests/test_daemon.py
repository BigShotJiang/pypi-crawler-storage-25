"""Tests for the browser daemon (Step 7).

Tests cover:
- Rate queue spacing (3s between same-platform actions, independent queues)
- Idle timeout (shutdown after 15 min, reset on each request)
- Protocol serialization (JSON encoding/decoding, large payloads, unicode)
- Stale socket cleanup (daemon starts despite stale socket file)
- Error type serialization/deserialization (NotLoggedInError, BrowserNotAvailableError)
- Method dispatch (valid methods succeed, unknown methods return error)
- Daemon rejects login methods (not in dispatch table)
"""

import asyncio
import json
import os
import tempfile
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from stride.browser.service import BrowserNotAvailableError, NotLoggedInError


class TestRateQueue:
    """Test per-platform rate-limiting in the daemon server."""

    def _make_daemon_server(self):
        """Create a DaemonServer with mocked channels and browser."""
        with patch("stride.daemon.load_config") as mock_config:
            mock_config.return_value = MagicMock()
            mock_config.return_value.browser.profile_dir = "/tmp/test"
            mock_config.return_value.browser.headless = True

            from stride.daemon import DaemonServer

            server = DaemonServer()
            # Mock the channels
            server._x_channel = MagicMock()
            server._reddit_channel = MagicMock()
            server._browser_service = MagicMock()
            return server

    def test_rate_limit_spacing_same_platform(self):
        """Two X actions should be spaced at least 3s apart."""
        server = self._make_daemon_server()

        # Mock search_tweets to return quickly
        server._x_channel.search_tweets = AsyncMock(return_value=[])

        async def _run():
            t1 = time.monotonic()
            await server._x_search(query="test1", max_results=1)
            t2 = time.monotonic()
            await server._x_search(query="test2", max_results=1)
            t3 = time.monotonic()

            # First call should be fast
            assert t2 - t1 < 1.0, "First call should not be delayed"
            # Second call should have waited ~3s (rate limit spacing)
            assert t3 - t2 >= 2.5, f"Second call should wait ~3s, got {t3 - t2:.1f}s"

        asyncio.run(_run())

    def test_rate_limit_independent_queues(self):
        """X and Reddit queues should be independent (no cross-platform delay)."""
        server = self._make_daemon_server()

        server._x_channel.search_tweets = AsyncMock(return_value=[])
        server._reddit_channel.search_posts = AsyncMock(return_value=[])

        async def _run():
            t1 = time.monotonic()
            await server._x_search(query="test", max_results=1)
            t2 = time.monotonic()
            # Reddit action should NOT wait for X rate limit
            await server._reddit_search(query="test", max_results=1)
            t3 = time.monotonic()

            # Both should complete quickly (no cross-platform waiting)
            assert t3 - t2 < 1.0, f"Reddit should not wait for X, took {t3 - t2:.1f}s"

        asyncio.run(_run())


class TestIdleTimeout:
    """Test idle timeout behavior."""

    def test_idle_timeout_value(self):
        """Idle timeout should be 15 minutes."""
        from stride.daemon import IDLE_TIMEOUT

        assert IDLE_TIMEOUT == 15 * 60

    def test_last_request_time_updates(self):
        """_last_request_time should be set on server creation."""
        with patch("stride.daemon.load_config") as mock_config:
            mock_config.return_value = MagicMock()
            mock_config.return_value.browser.profile_dir = "/tmp/test"

            from stride.daemon import DaemonServer

            server = DaemonServer()
            # Should have a recent timestamp
            assert time.time() - server._last_request_time < 2.0


class TestProtocolSerialization:
    """Test JSON protocol encoding/decoding."""

    def test_basic_json_encoding(self):
        """Basic JSON request/response encoding."""
        request = {"id": "test-1", "method": "x_search", "args": {"query": "test", "max_results": 50}}
        encoded = json.dumps(request) + "\n"
        decoded = json.loads(encoded.strip())
        assert decoded == request

    def test_large_payload(self):
        """Large payloads (50+ tweet results) should serialize correctly."""
        tweets = [
            {
                "tweet_id": f"id_{i}",
                "username": f"user_{i}",
                "text": f"Tweet text number {i} with some content " * 5,
                "views": i * 100,
                "is_retweet": False,
                "is_reply": False,
            }
            for i in range(100)
        ]
        response = {"id": "test-large", "result": tweets, "error": None}
        encoded = json.dumps(response) + "\n"
        decoded = json.loads(encoded.strip())
        assert len(decoded["result"]) == 100
        assert decoded["result"][99]["tweet_id"] == "id_99"

    def test_unicode_payload(self):
        """Unicode content should survive JSON roundtrip."""
        request = {
            "id": "unicode-1",
            "method": "x_post",
            "args": {"content": "Hello from Japan! Built a tool for builders."},
        }
        encoded = json.dumps(request, ensure_ascii=False) + "\n"
        decoded = json.loads(encoded.strip())
        assert decoded["args"]["content"] == request["args"]["content"]

    def test_newline_delimiter(self):
        """Multiple messages should be delimited by newlines."""
        msg1 = json.dumps({"id": "1", "method": "x_search", "args": {}})
        msg2 = json.dumps({"id": "2", "method": "reddit_search", "args": {}})
        stream = f"{msg1}\n{msg2}\n"
        messages = [json.loads(line) for line in stream.strip().split("\n")]
        assert len(messages) == 2
        assert messages[0]["id"] == "1"
        assert messages[1]["id"] == "2"


class TestStaleSocketCleanup:
    """Test stale socket detection and cleanup."""

    def test_check_existing_daemon_returns_false_for_nonexistent(self):
        """_check_existing_daemon should return False when socket doesn't exist."""
        with patch("stride.daemon.load_config") as mock_config:
            mock_config.return_value = MagicMock()
            mock_config.return_value.browser.profile_dir = "/tmp/test"

            from stride.daemon import DaemonServer

            server = DaemonServer()

            async def _run():
                with patch("asyncio.open_unix_connection", side_effect=FileNotFoundError):
                    result = await server._check_existing_daemon()
                    assert result is False

            asyncio.run(_run())

    def test_check_existing_daemon_returns_false_for_refused(self):
        """_check_existing_daemon should return False when connection is refused."""
        with patch("stride.daemon.load_config") as mock_config:
            mock_config.return_value = MagicMock()
            mock_config.return_value.browser.profile_dir = "/tmp/test"

            from stride.daemon import DaemonServer

            server = DaemonServer()

            async def _run():
                with patch("asyncio.open_unix_connection", side_effect=ConnectionRefusedError):
                    result = await server._check_existing_daemon()
                    assert result is False

            asyncio.run(_run())

    def test_check_existing_daemon_returns_true_when_connected(self):
        """_check_existing_daemon should return True when a daemon responds."""
        with patch("stride.daemon.load_config") as mock_config:
            mock_config.return_value = MagicMock()
            mock_config.return_value.browser.profile_dir = "/tmp/test"

            from stride.daemon import DaemonServer

            server = DaemonServer()

            async def _run():
                mock_writer = AsyncMock()
                with patch("asyncio.open_unix_connection", return_value=(AsyncMock(), mock_writer)):
                    result = await server._check_existing_daemon()
                    assert result is True
                    mock_writer.close.assert_called_once()

            asyncio.run(_run())


class TestErrorSerialization:
    """Test error type serialization and deserialization."""

    def test_not_logged_in_error_roundtrip(self):
        """NotLoggedInError should survive daemon serialization roundtrip."""
        from stride.daemon_client import ERROR_TYPES

        # Simulate daemon serialization
        error = NotLoggedInError("Not logged in to X")
        wire = {
            "id": "test",
            "result": None,
            "error": str(error),
            "error_type": "NotLoggedInError",
        }
        serialized = json.dumps(wire)
        deserialized = json.loads(serialized)

        # Client-side reconstruction
        error_type_name = deserialized.get("error_type", "")
        error_class = ERROR_TYPES.get(error_type_name)
        assert error_class is NotLoggedInError
        reconstructed = error_class(deserialized["error"])
        assert str(reconstructed) == "Not logged in to X"

    def test_browser_not_available_error_roundtrip(self):
        """BrowserNotAvailableError should survive daemon serialization roundtrip."""
        from stride.daemon_client import ERROR_TYPES

        error = BrowserNotAvailableError("Playwright not installed")
        wire = {
            "id": "test",
            "result": None,
            "error": str(error),
            "error_type": "BrowserNotAvailableError",
        }
        serialized = json.dumps(wire)
        deserialized = json.loads(serialized)

        error_type_name = deserialized.get("error_type", "")
        error_class = ERROR_TYPES.get(error_type_name)
        assert error_class is BrowserNotAvailableError

    def test_unknown_error_type_not_in_map(self):
        """Unknown error types should not be in ERROR_TYPES."""
        from stride.daemon_client import ERROR_TYPES

        assert ERROR_TYPES.get("ValueError") is None
        assert ERROR_TYPES.get("RuntimeError") is None

    def test_daemon_client_raises_typed_errors(self):
        """DaemonClient.send() should raise typed exceptions from daemon responses."""
        from stride.daemon_client import DaemonClient, DaemonConnectionError

        async def _run():
            # Create a mock reader that returns a NotLoggedInError response
            response = json.dumps({
                "id": "test",
                "result": None,
                "error": "Not logged in to X",
                "error_type": "NotLoggedInError",
            }) + "\n"

            reader = AsyncMock()
            reader.readline = AsyncMock(return_value=response.encode("utf-8"))
            writer = AsyncMock()

            client = DaemonClient(reader, writer)

            with pytest.raises(NotLoggedInError, match="Not logged in to X"):
                await client.send("x_search", {"query": "test"})

        asyncio.run(_run())

    def test_daemon_client_raises_connection_error_for_unknown(self):
        """DaemonClient should raise DaemonConnectionError for untyped errors."""
        from stride.daemon_client import DaemonClient, DaemonConnectionError

        async def _run():
            response = json.dumps({
                "id": "test",
                "result": None,
                "error": "Something went wrong",
            }) + "\n"

            reader = AsyncMock()
            reader.readline = AsyncMock(return_value=response.encode("utf-8"))
            writer = AsyncMock()

            client = DaemonClient(reader, writer)

            with pytest.raises(DaemonConnectionError, match="Something went wrong"):
                await client.send("x_search", {"query": "test"})

        asyncio.run(_run())


class TestMethodDispatch:
    """Test daemon method dispatch table."""

    def test_valid_methods_in_dispatch(self):
        """All expected methods should be in the dispatch table."""
        with patch("stride.daemon.load_config") as mock_config:
            mock_config.return_value = MagicMock()
            mock_config.return_value.browser.profile_dir = "/tmp/test"

            from stride.daemon import DaemonServer

            server = DaemonServer()
            # Mock channels so dispatch table can be built
            server._x_channel = MagicMock()
            server._reddit_channel = MagicMock()
            dispatch = server._build_dispatch_table()

            expected = [
                "x_search", "x_feed", "x_post", "x_reply", "x_status",
                "reddit_search", "reddit_feed", "reddit_browse",
                "reddit_comments", "reddit_post", "reddit_reply",
                "reddit_status", "shutdown",
            ]
            for method in expected:
                assert method in dispatch, f"Missing method: {method}"

    def test_unknown_method_not_in_dispatch(self):
        """Unknown methods should not be in dispatch table."""
        with patch("stride.daemon.load_config") as mock_config:
            mock_config.return_value = MagicMock()
            mock_config.return_value.browser.profile_dir = "/tmp/test"

            from stride.daemon import DaemonServer

            server = DaemonServer()
            server._x_channel = MagicMock()
            server._reddit_channel = MagicMock()
            dispatch = server._build_dispatch_table()

            assert "nonexistent_method" not in dispatch
            assert "x_delete" not in dispatch

    def test_login_methods_excluded(self):
        """Login methods must NOT be in the dispatch table (require visible browser)."""
        with patch("stride.daemon.load_config") as mock_config:
            mock_config.return_value = MagicMock()
            mock_config.return_value.browser.profile_dir = "/tmp/test"

            from stride.daemon import DaemonServer

            server = DaemonServer()
            server._x_channel = MagicMock()
            server._reddit_channel = MagicMock()
            dispatch = server._build_dispatch_table()

            assert "x_login" not in dispatch
            assert "reddit_login" not in dispatch


class TestDataclassConversion:
    """Test dataclass to dict conversion for JSON serialization."""

    def test_dataclass_to_dict(self):
        """Dataclasses should be converted to dicts."""
        import dataclasses

        from stride.daemon import _dataclass_to_dict

        @dataclasses.dataclass
        class TestResult:
            success: bool
            url: str

        result = TestResult(success=True, url="https://x.com/status/123")
        converted = _dataclass_to_dict(result)
        assert isinstance(converted, dict)
        assert converted["success"] is True
        assert converted["url"] == "https://x.com/status/123"

    def test_list_of_dataclasses(self):
        """Lists of dataclasses should be converted to lists of dicts."""
        import dataclasses

        from stride.daemon import _dataclass_to_dict

        @dataclasses.dataclass
        class Post:
            title: str
            score: int

        posts = [Post(title="Test 1", score=10), Post(title="Test 2", score=20)]
        converted = _dataclass_to_dict(posts)
        assert isinstance(converted, list)
        assert len(converted) == 2
        assert converted[0]["title"] == "Test 1"

    def test_plain_dict_passthrough(self):
        """Plain dicts should pass through unchanged."""
        from stride.daemon import _dataclass_to_dict

        data = {"key": "value"}
        assert _dataclass_to_dict(data) is data

    def test_plain_value_passthrough(self):
        """Plain values should pass through unchanged."""
        from stride.daemon import _dataclass_to_dict

        assert _dataclass_to_dict(42) == 42
        assert _dataclass_to_dict("hello") == "hello"


class TestDaemonClientIsRunning:
    """Test DaemonClient.is_running() static method."""

    def test_not_running_when_no_pid_file(self, tmp_path):
        """is_running should return False when PID file doesn't exist."""
        with patch("stride.daemon_client.PID_FILE", tmp_path / "nonexistent.pid"):
            from stride.daemon_client import DaemonClient

            assert DaemonClient.is_running() is False

    def test_not_running_when_pid_invalid(self, tmp_path):
        """is_running should return False when PID file contains invalid data."""
        pid_file = tmp_path / "daemon.pid"
        pid_file.write_text("not_a_number")
        with patch("stride.daemon_client.PID_FILE", pid_file):
            from stride.daemon_client import DaemonClient

            assert DaemonClient.is_running() is False

    def test_not_running_when_process_dead(self, tmp_path):
        """is_running should return False when PID refers to a dead process."""
        pid_file = tmp_path / "daemon.pid"
        pid_file.write_text("99999999")  # Very unlikely to be a real PID
        with patch("stride.daemon_client.PID_FILE", pid_file):
            from stride.daemon_client import DaemonClient

            assert DaemonClient.is_running() is False

    def test_running_when_process_alive(self, tmp_path):
        """is_running should return True when PID refers to a live process."""
        pid_file = tmp_path / "daemon.pid"
        pid_file.write_text(str(os.getpid()))  # Current process is definitely alive
        with patch("stride.daemon_client.PID_FILE", pid_file):
            from stride.daemon_client import DaemonClient

            assert DaemonClient.is_running() is True
