"""Open browser with test profile for manual login.

Opens a visible browser using the same BrowserService fingerprint as tests.
Log in to X and Reddit manually, then close the browser window.
Sessions persist in test-browser-profile/.

Usage:
    cd cli && uv run python tests/setup_test_accounts.py
"""

import asyncio
from pathlib import Path

from stride.browser.service import BrowserService

PROFILE_DIR = str(Path(__file__).parent / "test-browser-profile")


async def main():
    print(f"Test browser profile: {PROFILE_DIR}")
    Path(PROFILE_DIR).mkdir(parents=True, exist_ok=True)

    browser = BrowserService(profile_dir=PROFILE_DIR, headless=False)
    await browser.start()

    page = await browser.new_page()
    await page.goto("https://x.com", wait_until="domcontentloaded")

    print()
    print("Browser is open. Log in to your test accounts:")
    print("  1. X  — https://x.com/login")
    print("  2. Reddit — https://www.reddit.com/login")
    print()
    print("Close the browser window when done.")

    # Wait until the browser is closed by the user
    try:
        await page.wait_for_event("close", timeout=0)
    except Exception:
        pass

    await browser.stop()
    print("Sessions saved.")


if __name__ == "__main__":
    asyncio.run(main())
