"""Unit tests for output formatting module and _parse_metric utility."""

import json
from io import StringIO

from rich.console import Console

from stride.channel.x import _parse_metric
from stride.output import output_results, output_single


class TestParseMetric:
    def test_integer_string(self):
        assert _parse_metric("622") == 622

    def test_k_suffix(self):
        assert _parse_metric("9.4K") == 9400

    def test_k_suffix_lowercase(self):
        assert _parse_metric("9.4k") == 9400

    def test_m_suffix(self):
        assert _parse_metric("20M") == 20000000

    def test_m_suffix_lowercase(self):
        assert _parse_metric("20m") == 20000000

    def test_b_suffix(self):
        assert _parse_metric("1.5B") == 1500000000

    def test_b_suffix_lowercase(self):
        assert _parse_metric("1.5b") == 1500000000

    def test_commas(self):
        assert _parse_metric("1,234") == 1234

    def test_empty_string(self):
        assert _parse_metric("") == 0

    def test_none(self):
        assert _parse_metric(None) == 0

    def test_invalid_string(self):
        assert _parse_metric("abc") == 0

    def test_whitespace(self):
        assert _parse_metric("  ") == 0

    def test_float_string(self):
        assert _parse_metric("3.14") == 3

    def test_zero(self):
        assert _parse_metric("0") == 0

    def test_large_number_with_commas(self):
        assert _parse_metric("1,234,567") == 1234567


class TestOutputResults:
    def test_json_output_is_valid(self, capsys):
        items = [{"name": "Alice", "score": 42}]
        console = Console()
        output_results(items, as_json=True, console=console, columns=["name", "score"])
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert isinstance(parsed, list)
        assert len(parsed) == 1
        assert parsed[0]["name"] == "Alice"

    def test_json_empty_list(self, capsys):
        console = Console()
        output_results([], as_json=True, console=console, columns=["name"])
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed == []

    def test_json_special_characters(self, capsys):
        items = [{"text": 'Hello "world"\nnewline \u2603'}]
        console = Console()
        output_results(items, as_json=True, console=console, columns=["text"])
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed[0]["text"] == 'Hello "world"\nnewline \u2603'

    def test_rich_table_not_empty(self, capsys):
        items = [{"name": "Bob", "score": 99}]
        # Use a string buffer to capture Rich output
        buf = StringIO()
        console = Console(file=buf, force_terminal=True)
        output_results(items, as_json=False, console=console, columns=["name", "score"])
        output = buf.getvalue()
        assert "Bob" in output
        assert "99" in output

    def test_rich_empty_results(self):
        buf = StringIO()
        console = Console(file=buf, force_terminal=True)
        output_results([], as_json=False, console=console, columns=["name"])
        output = buf.getvalue()
        assert "No results found" in output

    def test_json_goes_to_stdout_not_rich(self, capsys):
        """JSON output must use print() (stdout), not Rich Console."""
        buf = StringIO()
        console = Console(file=buf)
        items = [{"key": "val"}]
        output_results(items, as_json=True, console=console, columns=["key"])
        # Rich console buffer should be empty
        assert buf.getvalue() == ""
        # stdout should have JSON
        captured = capsys.readouterr()
        assert json.loads(captured.out) == [{"key": "val"}]


class TestOutputSingle:
    def test_json_output(self, capsys):
        item = {"name": "Test", "value": 42}
        console = Console()
        output_single(item, as_json=True, console=console)
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed["name"] == "Test"
        assert parsed["value"] == 42

    def test_rich_output(self):
        buf = StringIO()
        console = Console(file=buf, force_terminal=True)
        output_single({"name": "Test"}, as_json=False, console=console)
        output = buf.getvalue()
        assert "name" in output
        assert "Test" in output
