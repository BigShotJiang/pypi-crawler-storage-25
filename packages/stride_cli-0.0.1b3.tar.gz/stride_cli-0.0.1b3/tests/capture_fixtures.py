"""Capture real X and Reddit page HTML for test fixtures.

Uses the stride-server's logged-in browser profile to load real pages,
waits for JS rendering, then saves the rendered DOM as HTML fixtures.

Usage:
    cd cli && uv run python tests/capture_fixtures.py

Re-run this whenever X or Reddit changes their UI to update fixtures.
"""

import asyncio
import re
import sys
from pathlib import Path

from playwright.async_api import async_playwright

# Use stride-server's existing logged-in browser profile
PROFILE_DIR = str(Path.home() / "workspaces" / "stride" / "stride-server" / "data" / "browser-profile")
FIXTURES_DIR = Path(__file__).parent / "fixtures"

# Pages to capture: (filename, url, description, wait_seconds)
PAGES_TO_CAPTURE = [
    # X pages
    ("x_home.html", "https://x.com/home", "X home (logged in)", 5),
    ("x_tweet.html", None, "X tweet with reply box (will find one from timeline)", 5),
    ("x_compose.html", "https://x.com/compose/post", "X compose dialog", 3),
    # Reddit pages
    ("reddit_home.html", "https://www.reddit.com/", "Reddit home (logged in)", 5),
    ("reddit_submit.html", "https://www.reddit.com/r/test/submit", "Reddit submit page", 5),
    ("reddit_post.html", None, "Reddit post with comments (will find one)", 5),
]


def strip_scripts(html: str) -> str:
    """Remove all <script> tags, <meta http-equiv="refresh">, and <noscript> blocks.

    We only need the DOM structure for selector testing, not live JS.
    Without this, captured X pages try to redirect/reload when opened locally.
    """
    # Remove <script>...</script> blocks
    html = re.sub(r"<script[\s>].*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
    # Remove <noscript>...</noscript> blocks (often contain redirect meta tags)
    html = re.sub(r"<noscript>.*?</noscript>", "", html, flags=re.DOTALL | re.IGNORECASE)
    # Remove meta refresh tags
    html = re.sub(r'<meta[^>]*http-equiv=["\']refresh["\'][^>]*>', "", html, flags=re.IGNORECASE)
    return html


async def capture_page(context, url: str, wait_seconds: int = 5) -> str | None:
    """Load a page and return the rendered DOM HTML (scripts stripped)."""
    page = await context.new_page()
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        await page.wait_for_timeout(wait_seconds * 1000)
        # Get the fully rendered DOM (after JS execution)
        html = await page.content()
        # Strip scripts so fixtures can be opened in browser without redirects
        return strip_scripts(html)
    except Exception as e:
        print(f"  ERROR: {e}")
        return None
    finally:
        await page.close()


async def find_tweet_url(context) -> str:
    """Find a real tweet URL from the home timeline to capture."""
    page = await context.new_page()
    try:
        await page.goto("https://x.com/home", wait_until="domcontentloaded", timeout=30000)
        await page.wait_for_timeout(8000)
        # Find the first tweet link with status ID
        links = await page.query_selector_all('a[href*="/status/"]')
        for link in links:
            href = await link.get_attribute("href")
            if href and "/status/" in href and "/analytics" not in href:
                url = f"https://x.com{href}" if href.startswith("/") else href
                print(f"  Found tweet: {url}")
                return url
        print("  WARNING: Could not find any tweet on timeline")
        return ""
    except Exception as e:
        print(f"  ERROR finding tweet: {e}")
        return ""
    finally:
        await page.close()


async def find_reddit_post_url(context) -> str:
    """Find a real Reddit post URL to capture."""
    page = await context.new_page()
    try:
        await page.goto("https://www.reddit.com/r/test/hot/", wait_until="domcontentloaded")
        await page.wait_for_timeout(5000)
        # Find the first post link
        post = await page.query_selector('shreddit-post')
        if post:
            permalink = await post.get_attribute("permalink")
            if permalink:
                return f"https://www.reddit.com{permalink}"
        return "https://www.reddit.com/r/test/comments/latest"
    finally:
        await page.close()


async def main():
    FIXTURES_DIR.mkdir(exist_ok=True)

    print(f"Using browser profile: {PROFILE_DIR}")
    print(f"Saving fixtures to: {FIXTURES_DIR}")
    print()

    pw = await async_playwright().start()
    context = await pw.chromium.launch_persistent_context(
        user_data_dir=PROFILE_DIR,
        headless=False,  # Visible so we can see what's happening
        viewport={"width": 1280, "height": 900},
        args=["--disable-blink-features=AutomationControlled"],
    )

    try:
        # Find dynamic URLs first
        print("Finding a tweet URL from timeline...")
        tweet_url = await find_tweet_url(context)
        print(f"  Found: {tweet_url}")

        print("Finding a Reddit post URL...")
        reddit_post_url = await find_reddit_post_url(context)
        print(f"  Found: {reddit_post_url}")
        print()

        captured = 0
        skipped = 0
        for filename, url, description, wait_seconds in PAGES_TO_CAPTURE:
            # Fill in dynamic URLs
            if filename == "x_tweet.html":
                url = tweet_url
            elif filename == "reddit_post.html":
                url = reddit_post_url

            if not url:
                print(f"Skipping {description} (no URL found)")
                skipped += 1
                continue

            print(f"Capturing {description}...")
            print(f"  URL: {url}")
            html = await capture_page(context, url, wait_seconds)

            if html is None:
                print(f"  SKIPPED (page failed to load)")
                skipped += 1
                continue

            # Save to fixtures
            filepath = FIXTURES_DIR / filename
            filepath.write_text(html, encoding="utf-8")
            size_kb = len(html) / 1024
            print(f"  Saved: {filepath} ({size_kb:.0f} KB)")
            captured += 1
            print()

    finally:
        await context.close()
        await pw.stop()

    print("Done! Fixtures saved to tests/fixtures/")
    print("You can now run browser tests with: uv run pytest tests/test_x_browser.py tests/test_reddit_browser.py -v")


if __name__ == "__main__":
    asyncio.run(main())
