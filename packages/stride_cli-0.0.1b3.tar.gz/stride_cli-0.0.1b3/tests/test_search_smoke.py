"""CLI smoke tests for search/browse/comments commands (subprocess).

Tests that all 5 new commands are properly wired and their help text shows expected flags.
"""

import re
import subprocess
import sys

import pytest

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def run_stride(*args: str) -> subprocess.CompletedProcess:
    """Run a stride CLI command and return the result."""
    result = subprocess.run(
        [sys.executable, "-m", "stride", *args],
        capture_output=True,
        text=True,
        cwd=None,
    )
    # Strip ANSI escape codes so assertions work in CI
    result.stdout = _ANSI_RE.sub("", result.stdout)
    result.stderr = _ANSI_RE.sub("", result.stderr)
    return result


class TestXSearchCommands:
    def test_x_search_help(self):
        result = run_stride("channel", "x", "search", "--help")
        assert result.returncode == 0
        assert "--json" in result.stdout
        assert "--max" in result.stdout

    def test_x_feed_help(self):
        result = run_stride("channel", "x", "feed", "--help")
        assert result.returncode == 0
        assert "--json" in result.stdout
        assert "--max" in result.stdout

    def test_x_help_lists_search(self):
        result = run_stride("channel", "x", "--help")
        assert result.returncode == 0
        assert "search" in result.stdout
        assert "feed" in result.stdout


class TestRedditSearchCommands:
    def test_reddit_search_help(self):
        result = run_stride("channel", "reddit", "search", "--help")
        assert result.returncode == 0
        assert "--json" in result.stdout
        assert "--max" in result.stdout
        assert "--subreddit" in result.stdout
        assert "--sort" in result.stdout
        assert "--time" in result.stdout

    def test_reddit_browse_help(self):
        result = run_stride("channel", "reddit", "browse", "--help")
        assert result.returncode == 0
        assert "--json" in result.stdout
        assert "--max" in result.stdout
        assert "--sort" in result.stdout

    def test_reddit_comments_help(self):
        result = run_stride("channel", "reddit", "comments", "--help")
        assert result.returncode == 0
        assert "--json" in result.stdout
        assert "--max" in result.stdout

    def test_reddit_help_lists_search_browse_comments(self):
        result = run_stride("channel", "reddit", "--help")
        assert result.returncode == 0
        assert "search" in result.stdout
        assert "browse" in result.stdout
        assert "comments" in result.stdout


class TestDaemonSmokeTests:
    """Daemon commands should be reachable via the CLI."""

    def test_daemon_status_help(self):
        result = run_stride("daemon", "status", "--help")
        assert result.returncode == 0

    def test_daemon_stop_help(self):
        result = run_stride("daemon", "stop", "--help")
        assert result.returncode == 0
