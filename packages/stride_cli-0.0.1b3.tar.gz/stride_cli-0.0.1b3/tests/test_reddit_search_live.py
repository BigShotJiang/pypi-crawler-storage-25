"""Live browser tests for Reddit search/browse/comments.

Requires: test account maxchen_builds logged in at tests/test-browser-profile/
Run: cd cli && uv run pytest tests/test_reddit_search_live.py -v -m live
Debug: HEADLESS=false uv run pytest tests/test_reddit_search_live.py -v -m live
"""

import pytest

from stride.channel.reddit import RedditComment, RedditPost

pytestmark = pytest.mark.live


class TestRedditSearch:
    async def test_search_returns_results(self, reddit_channel):
        results = await reddit_channel.search_posts("python", max_results=10)
        assert len(results) > 0, "Search returned no results"

    async def test_search_result_type(self, reddit_channel):
        results = await reddit_channel.search_posts("indie hacker", max_results=5)
        assert len(results) > 0, "Search returned no results"
        for post in results:
            assert isinstance(post, RedditPost)
            assert post.title, "Missing title"
            assert post.permalink, "Missing permalink"

    async def test_search_with_subreddit(self, reddit_channel):
        results = await reddit_channel.search_posts(
            "python", subreddit="python", max_results=5
        )
        # May return 0 if search is scoped too narrowly, but should not error
        assert isinstance(results, list)

    async def test_search_fields_populated(self, reddit_channel):
        results = await reddit_channel.search_posts("programming", max_results=5)
        if results:
            post = results[0]
            assert post.title
            assert post.permalink


class TestRedditBrowse:
    async def test_browse_returns_results(self, reddit_channel):
        results = await reddit_channel.get_subreddit_posts("python", max_results=10)
        assert len(results) > 0, "Browse returned no results"

    async def test_browse_result_type(self, reddit_channel):
        results = await reddit_channel.get_subreddit_posts("python", max_results=5)
        assert len(results) > 0
        for post in results:
            assert isinstance(post, RedditPost)
            assert post.title
            assert post.permalink
            assert post.subreddit

    async def test_browse_max_results(self, reddit_channel):
        results = await reddit_channel.get_subreddit_posts("python", max_results=3)
        assert len(results) <= 3


class TestRedditComments:
    async def test_comments_returns_results(self, reddit_channel):
        # First get a post to read comments from
        posts = await reddit_channel.get_subreddit_posts("python", sort="hot", max_results=5)
        assert len(posts) > 0, "No posts found to read comments from"

        # Find a post with comments
        for post in posts:
            if post.comment_count > 0:
                comments = await reddit_channel.get_post_comments(
                    f"https://www.reddit.com{post.permalink}", max_results=10
                )
                if comments:
                    assert len(comments) > 0
                    return

        pytest.skip("No posts with comments found in hot r/python")

    async def test_comments_result_type(self, reddit_channel):
        posts = await reddit_channel.get_subreddit_posts("AskReddit", sort="hot", max_results=3)
        assert len(posts) > 0

        post = posts[0]
        comments = await reddit_channel.get_post_comments(
            f"https://www.reddit.com{post.permalink}", max_results=5
        )
        if comments:
            for comment in comments:
                assert isinstance(comment, RedditComment)
                assert comment.author
                assert comment.text
