"""Tests for channel shared browser refactor (Step 5).

Verify that channels accept an external BrowserService and do NOT call
browser.stop() when using a shared browser, but DO call it when owning
their own browser.
"""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def make_mock_browser_service():
    """Create a mock BrowserService."""
    browser = AsyncMock()
    page = AsyncMock()
    page.url = "https://x.com/home"
    # is_closed() is synchronous in Playwright, so use a regular MagicMock
    page.is_closed = MagicMock(return_value=False)
    page.evaluate = AsyncMock(return_value=[])
    page.wait_for_selector = AsyncMock()
    page.wait_for_timeout = AsyncMock()
    page.goto = AsyncMock()
    page.query_selector = AsyncMock(return_value=None)
    page.query_selector_all = AsyncMock(return_value=[])
    browser.new_page = AsyncMock(return_value=page)
    browser.close_page = AsyncMock()
    browser.start = AsyncMock()
    browser.stop = AsyncMock()
    return browser, page


@pytest.fixture
def mock_config():
    """Patch load_config to avoid needing real config."""
    config = MagicMock()
    config.browser.headless = True
    config.browser.profile_dir = "/tmp/test-profile"
    with patch("stride.channel.x.load_config", return_value=config), \
         patch("stride.channel.reddit.load_config", return_value=config):
        yield config


class TestXChannelSharedBrowser:
    """Test XChannel with and without shared browser_service."""

    def test_with_browser_service_does_not_stop(self, mock_config):
        """XChannel with external browser_service should NOT call browser.stop()."""
        from stride.channel.x import XChannel

        browser, page = make_mock_browser_service()
        channel = XChannel(browser_service=browser)

        assert channel._owns_browser is False
        assert channel._browser is browser

        # Run a method that triggers cleanup
        asyncio.run(channel.search_tweets("test", max_results=1))

        # browser.stop() should NOT have been called
        browser.stop.assert_not_called()
        # But close_page should have been called for the page
        browser.close_page.assert_called()

    def test_without_browser_service_does_stop(self, mock_config):
        """XChannel without browser_service DOES call browser.stop()."""
        from stride.channel.x import XChannel

        browser, page = make_mock_browser_service()
        channel = XChannel()

        assert channel._owns_browser is True
        assert channel._browser is None

        # Inject mock browser to avoid real browser startup
        channel._browser = browser
        asyncio.run(channel.search_tweets("test", max_results=1))

        # browser.stop() SHOULD have been called via _cleanup
        browser.stop.assert_called()

    def test_get_browser_returns_injected_service(self, mock_config):
        """When browser_service is provided, _get_browser returns it directly."""
        from stride.channel.x import XChannel

        browser, _ = make_mock_browser_service()
        channel = XChannel(browser_service=browser)

        result = asyncio.run(channel._get_browser())
        assert result is browser
        # start() should NOT be called since we provided an external service
        browser.start.assert_not_called()

    def test_cleanup_is_noop_with_shared_browser(self, mock_config):
        """_cleanup should be a no-op when _owns_browser is False."""
        from stride.channel.x import XChannel

        browser, _ = make_mock_browser_service()
        channel = XChannel(browser_service=browser)

        asyncio.run(channel._cleanup())

        # browser.stop() should NOT be called
        browser.stop.assert_not_called()
        # _browser should still be set (not cleared)
        assert channel._browser is browser

    def test_cleanup_stops_with_owned_browser(self, mock_config):
        """_cleanup should stop browser when _owns_browser is True."""
        from stride.channel.x import XChannel

        browser, _ = make_mock_browser_service()
        channel = XChannel()
        channel._browser = browser

        asyncio.run(channel._cleanup())

        browser.stop.assert_called_once()
        assert channel._browser is None


class TestRedditChannelSharedBrowser:
    """Test RedditChannel with and without shared browser_service."""

    def test_with_browser_service_does_not_stop(self, mock_config):
        """RedditChannel with external browser_service should NOT call browser.stop()."""
        from stride.channel.reddit import RedditChannel

        browser, page = make_mock_browser_service()
        page.url = "https://www.reddit.com/search/?q=test"
        channel = RedditChannel(browser_service=browser)

        assert channel._owns_browser is False
        assert channel._browser is browser

        asyncio.run(channel.search_posts("test", max_results=1))

        browser.stop.assert_not_called()
        browser.close_page.assert_called()

    def test_without_browser_service_does_stop(self, mock_config):
        """RedditChannel without browser_service DOES call browser.stop()."""
        from stride.channel.reddit import RedditChannel

        browser, page = make_mock_browser_service()
        page.url = "https://www.reddit.com/search/?q=test"
        channel = RedditChannel()

        assert channel._owns_browser is True

        channel._browser = browser
        asyncio.run(channel.search_posts("test", max_results=1))

        browser.stop.assert_called()

    def test_get_browser_returns_injected_service(self, mock_config):
        """When browser_service is provided, _get_browser returns it directly."""
        from stride.channel.reddit import RedditChannel

        browser, _ = make_mock_browser_service()
        channel = RedditChannel(browser_service=browser)

        result = asyncio.run(channel._get_browser())
        assert result is browser
        browser.start.assert_not_called()

    def test_cleanup_is_noop_with_shared_browser(self, mock_config):
        """_cleanup should be a no-op when _owns_browser is False."""
        from stride.channel.reddit import RedditChannel

        browser, _ = make_mock_browser_service()
        channel = RedditChannel(browser_service=browser)

        asyncio.run(channel._cleanup())

        browser.stop.assert_not_called()
        assert channel._browser is browser

    def test_cleanup_stops_with_owned_browser(self, mock_config):
        """_cleanup should stop browser when _owns_browser is True."""
        from stride.channel.reddit import RedditChannel

        browser, _ = make_mock_browser_service()
        channel = RedditChannel()
        channel._browser = browser

        asyncio.run(channel._cleanup())

        browser.stop.assert_called_once()
        assert channel._browser is None
