"""Live browser tests for X channel.

Requires: test account @maxchen_builds logged in at tests/test-browser-profile/
Run: cd cli && uv run pytest tests/test_x_live.py -v -m live
Debug: HEADLESS=false uv run pytest tests/test_x_live.py -v -m live
"""

import pytest

from tests.conftest import delete_tweet, test_text

pytestmark = pytest.mark.live


class TestXStatus:
    async def test_status_connected(self, x_channel):
        status = await x_channel.check_status()
        assert status.connected, f"Not connected: {status.error}"
        assert "maxchen" in status.username.lower(), f"Unexpected username: {status.username}"


class TestXPost:
    async def test_post_basic(self, x_channel):
        text = test_text("basic post")
        result = await x_channel.post(text)
        assert result.success, f"Post failed: {result.error}"
        # Clean up
        if result.url:
            await delete_tweet(result.url)

    async def test_post_with_self_reply(self, x_channel):
        text = test_text("main tweet")
        reply_text = test_text("self reply")
        result = await x_channel.post(text, self_reply=reply_text)
        assert result.success, f"Post with self-reply failed: {result.error}"
        # Clean up (deleting the main tweet should remove the thread)
        if result.url:
            await delete_tweet(result.url)

    async def test_post_with_thread(self, x_channel):
        text = test_text("thread start")
        thread_items = [test_text("thread reply 1"), test_text("thread reply 2")]
        result = await x_channel.post(text, thread=thread_items)
        assert result.success, f"Thread post failed: {result.error}"
        if result.url:
            await delete_tweet(result.url)

    async def test_post_with_image(self, x_channel, test_image):
        text = test_text("image post")
        result = await x_channel.post(text, image=test_image)
        assert result.success, f"Image post failed: {result.error}"
        if result.url:
            await delete_tweet(result.url)


class TestXReply:
    async def test_reply_to_own_tweet(self, x_channel):
        # Post a tweet with self-reply to get the URL back (basic post doesn't capture URL)
        main_text = test_text("reply target")
        dummy_reply = test_text("setup self-reply")
        main_result = await x_channel.post(main_text, self_reply=dummy_reply)
        assert main_result.success, f"Setup tweet failed: {main_result.error}"
        assert main_result.url, "No URL returned for setup tweet"

        # Now reply to it via the reply() method
        reply_text = test_text("test reply")
        reply_result = await x_channel.reply(main_result.url, reply_text)
        assert reply_result.success, f"Reply failed: {reply_result.error}"

        # Clean up
        await delete_tweet(main_result.url)
