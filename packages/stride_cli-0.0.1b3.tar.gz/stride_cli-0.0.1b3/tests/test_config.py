"""Config loading tests."""

from pathlib import Path
from unittest.mock import patch

from stride.config import Config, BrowserConfig, load_config, CONFIG_PATH, STRIDE_DIR


class TestLoadConfig:
    def test_missing_file_returns_defaults(self, tmp_path):
        """load_config() with missing file returns defaults."""
        fake_path = tmp_path / "nonexistent" / "config.toml"
        with patch("stride.config.CONFIG_PATH", fake_path):
            config = load_config()
        assert config.browser.headless is True
        assert "browser-profile" in config.browser.profile_dir

    def test_valid_toml_returns_parsed_values(self, tmp_path):
        """load_config() with valid TOML returns parsed values."""
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[browser]\nprofile_dir = "/custom/path"\nheadless = false\n'
        )
        with patch("stride.config.CONFIG_PATH", config_file):
            config = load_config()
        assert config.browser.profile_dir == "/custom/path"
        assert config.browser.headless is False

    def test_partial_toml_fills_defaults(self, tmp_path):
        """load_config() with partial TOML fills in defaults for missing keys."""
        config_file = tmp_path / "config.toml"
        config_file.write_text("[browser]\nheadless = false\n")
        with patch("stride.config.CONFIG_PATH", config_file):
            config = load_config()
        assert config.browser.headless is False
        # profile_dir should have the default value
        assert "browser-profile" in config.browser.profile_dir
