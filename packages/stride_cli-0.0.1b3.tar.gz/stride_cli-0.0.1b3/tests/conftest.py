"""Shared fixtures and helpers for Stride CLI tests."""

import os
import struct
import tempfile
import time
import zlib
from pathlib import Path

import pytest

from stride.browser.service import BrowserService

# Test browser profile with logged-in test accounts (@maxchen_builds)
TEST_PROFILE_DIR = str(Path(__file__).parent / "test-browser-profile")

# Test account info
X_TEST_USERNAME = "maxchen_builds"
REDDIT_TEST_USERNAME = "maxchen_builds"


def test_text(prefix: str = "thought") -> str:
    """Generate unique-ish natural-sounding content for test posts."""
    ts = int(time.time()) % 100000  # Short number, less robotic
    phrases = [
        f"just had a {prefix} about building side projects {ts}",
        f"random {prefix} of the day, shipping is underrated {ts}",
        f"quick {prefix} on getting early users {ts}",
    ]
    import hashlib
    idx = int(hashlib.md5(f"{prefix}{ts}".encode()).hexdigest(), 16) % len(phrases)
    return phrases[idx]


def make_test_png(width: int = 100, height: int = 100) -> bytes:
    """Create a valid PNG file with a solid blue color (no PIL needed)."""

    def _chunk(chunk_type: bytes, data: bytes) -> bytes:
        c = chunk_type + data
        crc = struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)
        return struct.pack(">I", len(data)) + c + crc

    signature = b"\x89PNG\r\n\x1a\n"
    ihdr_data = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # 8-bit RGB
    ihdr = _chunk(b"IHDR", ihdr_data)
    # Each row: filter byte (0) + RGB pixels
    row = b"\x00" + (b"\x33\x66\xff") * width  # solid blue
    raw_data = row * height
    idat = _chunk(b"IDAT", zlib.compress(raw_data))
    iend = _chunk(b"IEND", b"")
    return signature + ihdr + idat + iend


@pytest.fixture
def x_channel():
    """X channel using test account profile."""
    from stride.channel.x import XChannel

    headless = os.environ.get("HEADLESS", "true").lower() != "false"
    return XChannel(headless=headless, profile_dir=TEST_PROFILE_DIR)


@pytest.fixture
def reddit_channel():
    """Reddit channel using test account profile."""
    from stride.channel.reddit import RedditChannel

    headless = os.environ.get("HEADLESS", "true").lower() != "false"
    return RedditChannel(headless=headless, profile_dir=TEST_PROFILE_DIR)


@pytest.fixture
def test_image(tmp_path):
    """Create a temporary 1x1 PNG image for upload tests."""
    img_path = tmp_path / "test_image.png"
    img_path.write_bytes(make_test_png())
    return str(img_path)


async def delete_tweet(tweet_url: str) -> bool:
    """Best-effort delete a tweet via browser. Returns True if likely deleted."""
    if not tweet_url:
        return False
    try:
        headless = os.environ.get("HEADLESS", "true").lower() != "false"
        browser = BrowserService(profile_dir=TEST_PROFILE_DIR, headless=headless)
        await browser.start()
        page = await browser.new_page()
        try:
            await page.goto(tweet_url, wait_until="domcontentloaded")
            await page.wait_for_timeout(3000)

            # Click the "..." more menu on the tweet
            more_btn = page.locator('[data-testid="caret"]').first
            if not await more_btn.is_visible(timeout=3000):
                more_btn = page.locator('[aria-label="More"]').first
            await more_btn.click()
            await page.wait_for_timeout(1000)

            # Click "Delete"
            delete_item = page.get_by_role("menuitem").filter(has_text="Delete")
            await delete_item.click()
            await page.wait_for_timeout(1000)

            # Confirm deletion
            confirm_btn = page.get_by_test_id("confirmationSheetConfirm")
            if not await confirm_btn.is_visible(timeout=2000):
                confirm_btn = page.get_by_role("button").filter(has_text="Delete")
            await confirm_btn.click()
            await page.wait_for_timeout(2000)
            return True
        finally:
            await browser.close_page(page)
            await browser.stop()
    except Exception as e:
        print(f"  Cleanup warning (tweet delete): {e}")
        return False


async def delete_reddit_post(post_url: str) -> bool:
    """Best-effort delete a Reddit post via browser. Returns True if likely deleted."""
    if not post_url or "/comments/" not in post_url:
        return False
    try:
        headless = os.environ.get("HEADLESS", "true").lower() != "false"
        browser = BrowserService(profile_dir=TEST_PROFILE_DIR, headless=headless)
        await browser.start()
        page = await browser.new_page()
        try:
            await page.goto(post_url, wait_until="domcontentloaded")
            await page.wait_for_timeout(5000)

            # Click the "..." menu near the post title
            overflow = page.locator("shreddit-post-overflow-menu").first
            await overflow.click()
            await page.wait_for_timeout(1000)

            # Click "Delete" in the dropdown
            delete_item = page.locator("#post-overflow-delete")
            await delete_item.click()
            await page.wait_for_timeout(1000)

            # Confirm with "Yes, Delete"
            confirm_btn = page.get_by_role("button", name="Yes, Delete")
            if await confirm_btn.first.is_visible(timeout=3000):
                await confirm_btn.first.click()
                await page.wait_for_timeout(3000)
            return True
        finally:
            await browser.close_page(page)
            await browser.stop()
    except Exception as e:
        print(f"  Cleanup warning (reddit delete): {e}")
        return False
