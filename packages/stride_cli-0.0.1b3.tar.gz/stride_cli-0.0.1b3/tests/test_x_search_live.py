"""Live browser tests for X search/feed.

Requires: test account @maxchen_builds logged in at tests/test-browser-profile/
Run: cd cli && uv run pytest tests/test_x_search_live.py -v -m live
Debug: HEADLESS=false uv run pytest tests/test_x_search_live.py -v -m live
"""

import pytest

pytestmark = pytest.mark.live


class TestXSearch:
    async def test_search_returns_results(self, x_channel):
        results = await x_channel.search_tweets("python", max_results=10)
        assert len(results) > 0, "Search returned no results"

    async def test_search_result_fields(self, x_channel):
        results = await x_channel.search_tweets("javascript", max_results=5)
        assert len(results) > 0, "Search returned no results"
        for tweet in results:
            assert "tweet_id" in tweet, "Missing tweet_id field"
            assert "text" in tweet, "Missing text field"
            assert "username" in tweet, "Missing username field"
            assert "views" in tweet, "Missing views field"
            assert isinstance(tweet["views"], int), "views should be int"

    async def test_search_max_results(self, x_channel):
        results = await x_channel.search_tweets("the", max_results=5)
        assert len(results) <= 5, f"Expected at most 5 results, got {len(results)}"

    async def test_search_dedup(self, x_channel):
        results = await x_channel.search_tweets("python programming", max_results=20)
        tweet_ids = [t["tweet_id"] for t in results]
        assert len(tweet_ids) == len(set(tweet_ids)), "Duplicate tweet_ids found"

    async def test_search_with_quotes(self, x_channel):
        """Test that queries with double quotes (like engagement queries) work."""
        results = await x_channel.search_tweets('"just launched"', max_results=5)
        # May return 0 results if no matching tweets, but should not error
        assert isinstance(results, list)


class TestXFeed:
    async def test_feed_returns_results(self, x_channel):
        results = await x_channel.get_home_timeline(max_results=10)
        assert len(results) > 0, "Feed returned no results"

    async def test_feed_result_fields(self, x_channel):
        results = await x_channel.get_home_timeline(max_results=5)
        assert len(results) > 0, "Feed returned no results"
        for tweet in results:
            assert "tweet_id" in tweet
            assert "text" in tweet
            assert "username" in tweet

    async def test_feed_max_results(self, x_channel):
        results = await x_channel.get_home_timeline(max_results=5)
        assert len(results) <= 5
