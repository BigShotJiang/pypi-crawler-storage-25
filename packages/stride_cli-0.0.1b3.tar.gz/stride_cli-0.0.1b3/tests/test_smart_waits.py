"""Tests for smart waits (Step 1).

Verify that wait_for_selector is called instead of wait_for_timeout for each
replaced location, and that the fallback (selector timeout) still allows the
method to proceed.
"""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def make_mock_page(url="https://x.com/home"):
    """Create a mock Playwright page with standard behavior."""
    page = AsyncMock()
    page.url = url
    # is_closed() is synchronous in Playwright, so use a regular MagicMock
    page.is_closed = MagicMock(return_value=False)
    page.evaluate = AsyncMock(return_value=[])
    page.wait_for_selector = AsyncMock()
    page.wait_for_timeout = AsyncMock()
    page.goto = AsyncMock()
    page.query_selector = AsyncMock(return_value=None)
    page.query_selector_all = AsyncMock(return_value=[])
    return page


def make_mock_browser_service(page):
    """Create a mock BrowserService that returns the given page."""
    browser = AsyncMock()
    browser.new_page = AsyncMock(return_value=page)
    browser.close_page = AsyncMock()
    browser.start = AsyncMock()
    browser.stop = AsyncMock()
    return browser


@pytest.fixture
def mock_config():
    """Patch load_config to avoid needing real config."""
    config = MagicMock()
    config.browser.headless = True
    config.browser.profile_dir = "/tmp/test-profile"
    with patch("stride.channel.x.load_config", return_value=config), \
         patch("stride.channel.reddit.load_config", return_value=config):
        yield config


class TestXSmartWaits:
    """Test that X channel methods use wait_for_selector instead of fixed waits."""

    def test_search_tweets_uses_selector(self, mock_config):
        """search_tweets should wait_for_selector for tweet articles, not fixed timeout."""
        from stride.channel.x import XChannel

        page = make_mock_page(url="https://x.com/search?q=test&f=live")
        browser = make_mock_browser_service(page)

        with patch.object(XChannel, "_get_browser", return_value=browser):
            channel = XChannel()
            channel._browser = browser
            result = asyncio.run(channel.search_tweets("test", max_results=5))

        # Should have called wait_for_selector with tweet article selector
        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if 'article[data-testid="tweet"]' in str(call)
        ]
        assert len(selector_calls) >= 1, "Expected wait_for_selector for tweet articles"
        assert selector_calls[0].kwargs.get("timeout") == 15000

    def test_search_tweets_selector_timeout_continues(self, mock_config):
        """If wait_for_selector times out, search_tweets should still proceed."""
        from stride.channel.x import XChannel

        page = make_mock_page(url="https://x.com/search?q=test&f=live")
        page.wait_for_selector = AsyncMock(side_effect=Exception("Timeout"))
        browser = make_mock_browser_service(page)

        with patch.object(XChannel, "_get_browser", return_value=browser):
            channel = XChannel()
            channel._browser = browser
            # Should not raise -- the exception is caught and we proceed
            result = asyncio.run(channel.search_tweets("test", max_results=5))
            assert isinstance(result, list)

    def test_get_home_timeline_uses_selector(self, mock_config):
        """get_home_timeline should wait_for_selector for tweet articles."""
        from stride.channel.x import XChannel

        page = make_mock_page(url="https://x.com/home")
        browser = make_mock_browser_service(page)

        with patch.object(XChannel, "_get_browser", return_value=browser):
            channel = XChannel()
            channel._browser = browser
            asyncio.run(channel.get_home_timeline(max_results=5))

        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if 'article[data-testid="tweet"]' in str(call)
        ]
        assert len(selector_calls) >= 1

    def test_post_community_uses_selector(self, mock_config):
        """post() with community should wait_for_selector for textarea."""
        from stride.channel.x import XChannel

        page = make_mock_page(url="https://x.com/community/123")
        # Make editor visible
        editor_locator = AsyncMock()
        editor_locator.is_visible = AsyncMock(return_value=True)
        editor_locator.click = AsyncMock()
        page.locator = MagicMock(return_value=editor_locator)

        browser = make_mock_browser_service(page)

        with patch.object(XChannel, "_get_browser", return_value=browser):
            channel = XChannel()
            channel._browser = browser
            asyncio.run(channel.post("test", community="https://x.com/community/123"))

        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if 'tweetTextarea_0' in str(call)
        ]
        assert len(selector_calls) >= 1


class TestRedditSmartWaits:
    """Test that Reddit channel methods use wait_for_selector instead of fixed waits."""

    def test_search_posts_uses_selector(self, mock_config):
        """search_posts should wait_for_selector for shreddit-post/comment links."""
        from stride.channel.reddit import RedditChannel

        page = make_mock_page(url="https://www.reddit.com/search/?q=test")
        browser = make_mock_browser_service(page)

        with patch.object(RedditChannel, "_get_browser", return_value=browser):
            channel = RedditChannel()
            channel._browser = browser
            asyncio.run(channel.search_posts("test", max_results=5))

        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if 'shreddit-post' in str(call) or '/comments/' in str(call)
        ]
        assert len(selector_calls) >= 1

    def test_get_subreddit_posts_uses_selector(self, mock_config):
        """get_subreddit_posts should wait_for_selector for shreddit-post."""
        from stride.channel.reddit import RedditChannel

        page = make_mock_page(url="https://www.reddit.com/r/python/hot/")
        browser = make_mock_browser_service(page)

        with patch.object(RedditChannel, "_get_browser", return_value=browser):
            channel = RedditChannel()
            channel._browser = browser
            asyncio.run(channel.get_subreddit_posts("python", max_results=5))

        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if 'shreddit-post' in str(call)
        ]
        assert len(selector_calls) >= 1

    def test_get_home_feed_uses_selector(self, mock_config):
        """get_home_feed should wait_for_selector for shreddit-post."""
        from stride.channel.reddit import RedditChannel

        page = make_mock_page(url="https://www.reddit.com/")
        browser = make_mock_browser_service(page)

        with patch.object(RedditChannel, "_get_browser", return_value=browser):
            channel = RedditChannel()
            channel._browser = browser
            asyncio.run(channel.get_home_feed(max_results=5))

        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if 'shreddit-post' in str(call)
        ]
        assert len(selector_calls) >= 1

    def test_get_post_comments_uses_selector(self, mock_config):
        """get_post_comments should wait_for_selector for shreddit-comment."""
        from stride.channel.reddit import RedditChannel

        page = make_mock_page(url="https://www.reddit.com/r/python/comments/abc123/test/")
        browser = make_mock_browser_service(page)

        with patch.object(RedditChannel, "_get_browser", return_value=browser):
            channel = RedditChannel()
            channel._browser = browser
            asyncio.run(channel.get_post_comments("https://www.reddit.com/r/python/comments/abc123/test/", max_results=5))

        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if 'shreddit-comment' in str(call)
        ]
        assert len(selector_calls) >= 1

    def test_check_status_uses_selector(self, mock_config):
        """check_status should wait_for_selector for user/login indicators."""
        from stride.channel.reddit import RedditChannel

        page = make_mock_page(url="https://www.reddit.com/settings/")
        browser = make_mock_browser_service(page)

        with patch.object(RedditChannel, "_get_browser", return_value=browser):
            channel = RedditChannel()
            channel._browser = browser
            asyncio.run(channel.check_status())

        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if '/user/' in str(call) or '/login' in str(call)
        ]
        assert len(selector_calls) >= 1

    def test_reply_uses_selector(self, mock_config):
        """reply should wait_for_selector for comment-composer-host."""
        from stride.channel.reddit import RedditChannel

        page = make_mock_page(url="https://www.reddit.com/r/python/comments/abc123/test/")
        # Mock evaluate to return host_box with width > 0
        async def mock_evaluate(js):
            if "scrollIntoView" in js:
                return None
            if "getBoundingClientRect" in js:
                return {"x": 100, "y": 100, "w": 200, "h": 50}
            return []
        page.evaluate = mock_evaluate

        # Mock locator for textbox
        textbox_locator = AsyncMock()
        textbox_locator.count = AsyncMock(return_value=1)
        textbox_locator.first = AsyncMock()
        textbox_locator.first.click = AsyncMock()

        btn_locator = AsyncMock()
        btn_locator.is_visible = AsyncMock(return_value=True)
        btn_locator.click = AsyncMock()

        def mock_locator(selector):
            return textbox_locator

        def mock_get_by_role(role, name=None, exact=None):
            return btn_locator

        page.locator = mock_locator
        page.get_by_role = mock_get_by_role
        page.mouse = AsyncMock()
        page.keyboard = AsyncMock()

        browser = make_mock_browser_service(page)

        with patch.object(RedditChannel, "_get_browser", return_value=browser):
            channel = RedditChannel()
            channel._browser = browser
            asyncio.run(channel.reply("https://www.reddit.com/r/python/comments/abc123/test/", "Test reply"))

        selector_calls = [
            call for call in page.wait_for_selector.call_args_list
            if 'comment-composer-host' in str(call) or 'shreddit-comment' in str(call)
        ]
        assert len(selector_calls) >= 1

    def test_post_uses_selector(self, mock_config):
        """post should wait_for_selector for form container."""
        from stride.channel.reddit import RedditChannel

        page = make_mock_page(url="https://www.reddit.com/r/test/submit")
        # Mock title input selector
        title_input = AsyncMock()
        title_input.click = AsyncMock()

        async def mock_wait_selector(sel, timeout=None):
            if "Title" in sel:
                return title_input
            return None

        page.wait_for_selector = AsyncMock(side_effect=mock_wait_selector)

        # Mock body input and submit button
        body_locator = AsyncMock()
        body_locator.count = AsyncMock(return_value=0)
        submit_btn = AsyncMock()
        submit_btn.is_visible = AsyncMock(return_value=True)
        submit_btn.click = AsyncMock()

        page.locator = MagicMock(return_value=body_locator)
        page.get_by_role = MagicMock(return_value=submit_btn)
        page.keyboard = AsyncMock()

        browser = make_mock_browser_service(page)

        with patch.object(RedditChannel, "_get_browser", return_value=browser):
            channel = RedditChannel()
            channel._browser = browser
            asyncio.run(channel.post("body text", subreddit="test", title="Test Post"))

        # The first wait_for_selector should be for the form container
        first_call = page.wait_for_selector.call_args_list[0]
        assert "faceplate-form" in str(first_call) or "r-post-type-select" in str(first_call) or "Title" in str(first_call)

    def test_selector_timeout_allows_fallback(self, mock_config):
        """If wait_for_selector times out, methods should still proceed."""
        from stride.channel.reddit import RedditChannel

        page = make_mock_page(url="https://www.reddit.com/search/?q=test")
        page.wait_for_selector = AsyncMock(side_effect=Exception("Timeout"))
        browser = make_mock_browser_service(page)

        with patch.object(RedditChannel, "_get_browser", return_value=browser):
            channel = RedditChannel()
            channel._browser = browser
            result = asyncio.run(channel.search_posts("test", max_results=5))
            assert isinstance(result, list)
