"""Input validation tests for channel methods.

These call channel methods but mock the browser so no real browser is launched.
Validation errors should be caught BEFORE any browser interaction.
"""

import asyncio

import pytest

from stride.channel.x import XChannel
from stride.channel.reddit import RedditChannel


class TestXPostValidation:
    """Test X post() input validation (returns errors before launching browser)."""

    def test_image_file_not_found(self):
        channel = XChannel()
        result = asyncio.run(channel.post("hello", image="/nonexistent/file.png"))
        assert not result.success
        assert "not found" in result.error.lower()

    def test_invalid_image_extension(self, tmp_path):
        bad_file = tmp_path / "file.txt"
        bad_file.write_text("not an image")
        channel = XChannel()
        result = asyncio.run(channel.post("hello", image=str(bad_file)))
        assert not result.success
        assert "invalid image format" in result.error.lower()

    def test_self_reply_and_thread_mutually_exclusive(self):
        channel = XChannel()
        result = asyncio.run(
            channel.post("hello", self_reply="followup", thread=["reply1"])
        )
        assert not result.success
        assert "mutually exclusive" in result.error.lower()

    def test_community_with_thread_incompatible(self):
        channel = XChannel()
        result = asyncio.run(
            channel.post("hello", community="https://x.com/i/communities/123", thread=["reply1"])
        )
        assert not result.success
        assert "incompatible" in result.error.lower()

    def test_community_with_self_reply_incompatible(self):
        channel = XChannel()
        result = asyncio.run(
            channel.post(
                "hello",
                community="https://x.com/i/communities/123",
                self_reply="followup",
            )
        )
        assert not result.success
        assert "incompatible" in result.error.lower()


class TestRedditPostValidation:
    """Test Reddit post() input validation (returns errors before launching browser)."""

    def test_image_and_url_mutually_exclusive(self, tmp_path):
        img = tmp_path / "photo.png"
        img.write_bytes(b"\x89PNG")
        channel = RedditChannel()
        result = asyncio.run(
            channel.post(
                "",
                subreddit="test",
                title="Test",
                url="https://example.com",
                image=str(img),
            )
        )
        assert not result.success
        assert "both" in result.error.lower() or "one post type" in result.error.lower()

    def test_missing_subreddit(self):
        channel = RedditChannel()
        result = asyncio.run(channel.post("body", title="Test"))
        assert not result.success
        assert "subreddit" in result.error.lower()

    def test_image_file_not_found(self):
        channel = RedditChannel()
        result = asyncio.run(
            channel.post("", subreddit="test", title="Test", image="/nonexistent/file.png")
        )
        assert not result.success
        assert "not found" in result.error.lower()

    def test_invalid_image_extension(self, tmp_path):
        bad_file = tmp_path / "file.txt"
        bad_file.write_text("not an image")
        channel = RedditChannel()
        result = asyncio.run(
            channel.post("", subreddit="test", title="Test", image=str(bad_file))
        )
        assert not result.success
        assert "invalid image format" in result.error.lower()
