"""Live browser tests for Reddit channel.

Requires: test account maxchen_builds logged in at tests/test-browser-profile/
Run: cd cli && uv run pytest tests/test_reddit_live.py -v -m live
Debug: HEADLESS=false uv run pytest tests/test_reddit_live.py -v -m live

Known limitations:
- Link posts and image posts are not yet supported (Reddit's new Shreddit UI
  uses shadow DOM tabs that need updated selectors).
- Posting to user profiles (user/USERNAME) may fail due to Reddit server issues.
  Use a real subreddit (e.g. r/test) as fallback.
"""

import pytest

from tests.conftest import delete_reddit_post, test_text

pytestmark = pytest.mark.live

# Use r/test as default test subreddit
# Can also use "user/maxchen_builds" for own profile (if Reddit isn't broken)
TEST_SUBREDDIT = "test"


class TestRedditStatus:
    async def test_status_connected(self, reddit_channel):
        status = await reddit_channel.check_status()
        assert status.connected, f"Not connected: {status.error}"
        assert "maxchen" in status.username.lower(), f"Unexpected username: {status.username}"


class TestRedditPost:
    async def test_post_text(self, reddit_channel):
        title = test_text("text post title")
        body = test_text("text post body content")
        result = await reddit_channel.post(
            body, subreddit=TEST_SUBREDDIT, title=title
        )
        assert result.success, f"Text post failed: {result.error}"
        if result.url:
            await delete_reddit_post(result.url)

    @pytest.mark.skip(reason="Reddit Shreddit UI link post tabs not yet supported")
    async def test_post_with_url(self, reddit_channel):
        title = test_text("link post title")
        result = await reddit_channel.post(
            "",
            subreddit=TEST_SUBREDDIT,
            title=title,
            url="https://www.strideday.com",
        )
        assert result.success, f"Link post failed: {result.error}"
        if result.url:
            await delete_reddit_post(result.url)

    @pytest.mark.skip(reason="Reddit Shreddit UI image post tabs not yet supported")
    async def test_post_with_image(self, reddit_channel, test_image):
        title = test_text("image post title")
        result = await reddit_channel.post(
            "",
            subreddit=TEST_SUBREDDIT,
            title=title,
            image=test_image,
        )
        assert result.success, f"Image post failed: {result.error}"
        if result.url:
            await delete_reddit_post(result.url)


class TestRedditReply:
    async def test_reply_to_own_post(self, reddit_channel):
        # First create a post to reply to
        title = test_text("reply target post")
        body = test_text("this post is for testing replies")
        post_result = await reddit_channel.post(
            body, subreddit=TEST_SUBREDDIT, title=title
        )
        assert post_result.success, f"Setup post failed: {post_result.error}"
        assert post_result.url, "No URL returned for setup post"

        # Now reply to it
        reply_text = test_text("test comment reply")
        reply_result = await reddit_channel.reply(post_result.url, reply_text)
        assert reply_result.success, f"Reply failed: {reply_result.error}"

        # Clean up
        await delete_reddit_post(post_result.url)
