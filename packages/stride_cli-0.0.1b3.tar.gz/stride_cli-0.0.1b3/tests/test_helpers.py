"""Unit tests for pure logic helper functions."""

from stride.channel.x import _extract_tweet_id
from stride.channel.reddit import _normalize_reddit_url


class TestExtractTweetId:
    def test_standard_url(self):
        assert _extract_tweet_id("https://x.com/user/status/123") == "123"

    def test_twitter_url(self):
        assert _extract_tweet_id("https://twitter.com/user/status/456") == "456"

    def test_anonymous_url(self):
        assert _extract_tweet_id("https://x.com/i/status/789") == "789"

    def test_non_twitter_url(self):
        assert _extract_tweet_id("https://google.com") is None

    def test_empty_string(self):
        assert _extract_tweet_id("") is None


class TestNormalizeRedditUrl:
    def test_relative_url(self):
        assert _normalize_reddit_url("/r/python/comments/abc") == "https://www.reddit.com/r/python/comments/abc"

    def test_full_url_passthrough(self):
        url = "https://www.reddit.com/r/python/comments/abc"
        assert _normalize_reddit_url(url) == url

    def test_empty_string_passthrough(self):
        assert _normalize_reddit_url("") == ""
