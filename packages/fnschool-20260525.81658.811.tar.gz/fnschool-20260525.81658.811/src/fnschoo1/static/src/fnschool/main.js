var up_char = '\u2191'
var down_char = '\u2193'

$(document).ready(function () {
  var messages = $('.messages')
  if (messages.length) {
    messages.css({
      position: 'absolute',
      top: $('.navbar').height() * 1.45,
    })
    setTimeout(function () {
      messages.hide()
    }, 25000)
  }
  var close_btn = $('.btn-close')
  if (close_btn.length) {
    close_btn.on('click', function () {
      close_btn.closest('.alert').hide()
    })
  }
})

function make_table_row_highlight(query, time_data) {
  var highlight_elements = $(query)
  var highlight_elements_toggled = []
  highlight_elements.each(function (index, element) {
    var element = $(element)
    var time_value = element.data(time_data)
    var seconds_diff = Math.floor((new Date() - new Date(time_value)) / 1000)
    if (seconds_diff < 46) {
      highlight_elements_toggled.push(element)
      element.toggleClass('fn-highlight')
      var table_container = $(element.closest('.table-container'))
      if (table_container.length) {
        var container = table_container
        var thead = $(element.closest('table').find('thead'))
        var pos =
          element.offset().top -
          container.offset().top +
          container.scrollTop() -
          thead.height()
        container.animate({ scrollTop: pos }, 1)
      }
    }
  })

  setTimeout(function () {
    $(highlight_elements_toggled).each(function (index, element) {
      element = $(element)
      element.toggleClass('fn-highlight')
    })
  }, 10 * 1000)
}

function get_cookie(name) {
  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) {
    return parts.pop().split(';').shift()
  }
  return null
}

function delete_cookie(name) {
  document.cookie = name + `=; max-age=0; path=/`
}

function set_cookies(cookies) {
  cookies = new Map(Object.entries(cookies))
  for (var [key, value] of cookies) {
    set_simple_cookie(key, value)
  }
}

function set_simple_cookie(key, value) {
  var cookie_enabled = get_cookie('cookie_enabled')
  if (cookie_enabled != '1') {
    return
  }
  const expiry_date = new Date()
  expiry_date.setFullYear(expiry_date.getFullYear() + 6)
  document.cookie = `${key}=${value}; expires=${expiry_date.toUTCString()}; path=/`
}

function get_search_params_from_cookie(name) {
  var cookie_value = get_cookie(name)
  if (cookie_value == null) {
    return null
  }
  var search_params = new URLSearchParams(cookie_value)
  return search_params
}

function set_search_params_from_cookie(name, key, value) {
  var params = get_search_params_from_cookie(name)
  params = params == null ? new URLSearchParams() : params
  if (value === '' || value === null || value === undefined) {
    params.delete(key)
  } else {
    if (params.has(key)) {
      params.delete(key)
    }
    params.append(key, value)
  }
  set_simple_cookie(name, params.toString())
  return params
}

function set_sort_params_from_cookie(name, key) {
  var cookie_name = name
  key = 'sort_' + key
  var params = get_search_params_from_cookie(cookie_name)
  var value = params == null ? '' : params.get(key, '')
  value =
    value == '' || value == null
      ? '+'
      : value == '+'
        ? '-'
        : value == '-'
          ? ''
          : ''
  params = set_search_params_from_cookie(cookie_name, key, value)

  var trigger_element = $(`.${key}`).add(`[name='${key}']`).first()
  var element_text = trigger_element.text()
  element_text = element_text.replace(up_char, '').replace(down_char, '')
  trigger_element.text(element_text)

  set_sort_element_arrows(cookie_name)

  return params
}

function update_href(query) {
  query = new Map(Object.entries(query))
  var url = new URL(window.location.href)
  var params = new URLSearchParams(url.search)
  for (var [key, value] of query) {
    params.set(key, value)
  }

  for (var [key, value] of params) {
    if (value === undefined || value === '' || value === null) {
      params.delete(key)
    }
  }

  url.search = params.toString()
  window.location.href = url.href
}
function open_small_window(url) {
  const size_times = 1 / 4
  const width = Math.round(screen.width * size_times)
  const height = Math.round(screen.height * size_times)
  const left = Math.round((screen.width - width) / 2)
  const _top = Math.round((screen.height - height) / 2)

  const left0 = Math.round((screen.width - height) / 2)
  const _top0 = Math.round((screen.height - width) / 2)

  var _width_ = width
  var _height_ = Math.round(height * 1.2)
  var _left_ = left
  var _top_ = _top

  const windowFeatures = `width=${_width_},height=${_height_},left=${_left_},top=${_top_},resizable=yes,scrollbars=yes`
  window.open(url, '_blank', windowFeatures)
}

function set_sort_element_arrows(cookie_name) {
  var params = get_search_params_from_cookie(cookie_name)
  if (params == null) {
    return
  }

  for (var [key, value] of params) {
    if (key.startsWith('sort_')) {
      var trigger_element = $(`.${key}`).add(`[name='${key}']`).first()
      if (trigger_element.length > 0) {
        var element_text = trigger_element.text()
        element_text = element_text.replace(up_char, '').replace(down_char, '')
        trigger_element.text(
          element_text +
            (value == '+' ? up_char : value == '-' ? down_char : '')
        )
      }
    }
  }
}

$(document).ready(function () {
  var cookie_consent_element = $('#cookieConsent')
  var cookie_acceptance_element = $('#acceptCookies')
  var cookie_denial_element = $('#rejectCookies')
  if (document.cookie.indexOf('cookie_enabled=1') === -1) {
    cookie_consent_element.show()
  }

  cookie_acceptance_element.on('click', function () {
    const expiry_date = new Date()
    expiry_date.setFullYear(expiry_date.getFullYear() + 6)
    document.cookie = `cookie_enabled=1; expires=${expiry_date.toUTCString()}; path=/`
    cookie_consent_element.hide()
  })

  cookie_denial_element.on('click', function () {
    cookie_consent_element.hide()
  })
})

function set_page_size() {
  const page_size = document.querySelector('#page_size').value
  set_simple_cookie('page_size', page_size)
  update_href({ per_page: page_size })
}

$(document).ready(function () {
  page_size_forms = $('[name="page_size"]')
  if (page_size_forms.length > 0) {
    page_size_forms.on('submit', function (event) {
      event.preventDefault()
      set_page_size()
    })
  }
})

function set_page(num) {
  update_href({ page: num })
}

// The end.
