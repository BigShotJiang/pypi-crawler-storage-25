


import os
from pathlib import Path

from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

AS_SITE = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.yeah.net'
EMAIL_PORT = 465 
EMAIL_USE_SSL = True    
EMAIL_USE_TLS = False
EMAIL_HOST_USER = 'larryw3i@yeah.net'
EMAIL_HOST_PASSWORD = 'GChZXcGTnh7pse5P'

AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
]
ACCOUNT_ACTIVATION_DAYS = 1

AS_LOCAL=False
AS_SITE=not AS_LOCAL

# The end.
