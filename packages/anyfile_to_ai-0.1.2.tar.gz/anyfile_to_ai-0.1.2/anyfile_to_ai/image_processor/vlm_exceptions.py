"""VLM-specific exception types for image processing."""

from .exceptions import ImageProcessingError


class VLMConfigurationError(ImageProcessingError):
    """Exception raised for VLM configuration issues."""

    def __init__(self, message: str, config_field: str | None = None, suggested_fix: str | None = None):
        super().__init__(message)
        self.config_field = config_field
        self.suggested_fix = suggested_fix


class VLMModelLoadError(ImageProcessingError):
    """Exception raised when VLM model loading fails."""

    def __init__(self, message: str, model_name: str | None = None, error_reason: str | None = None):
        super().__init__(message)
        self.model_name = model_name
        self.error_reason = error_reason


class VLMProcessingError(ImageProcessingError):
    """Exception raised during VLM processing operations."""

    def __init__(self, message: str, image_path: str | None = None, model_name: str | None = None, error_details: str | None = None):
        super().__init__(message)
        self.image_path = image_path
        self.model_name = model_name
        self.error_details = error_details


class VLMTimeoutError(VLMProcessingError):
    """Exception raised when VLM processing exceeds timeout."""

    def __init__(self, message: str, timeout_seconds: int | None = None, actual_time: float | None = None, **kwargs):
        super().__init__(message, **kwargs)
        self.timeout_seconds = timeout_seconds
        self.actual_time = actual_time


class VLMModelNotFoundError(VLMConfigurationError):
    """Exception raised when specified VLM model is not available."""

    def __init__(self, message: str, model_name: str | None = None, available_models: list | None = None, **kwargs):
        super().__init__(message, **kwargs)
        self.model_name = model_name
        self.available_models = available_models or []


class VLMMemoryError(VLMProcessingError):
    """Exception raised when VLM processing fails due to memory constraints."""

    def __init__(
        self,
        message: str,
        image_path: str | None = None,
        model_name: str | None = None,
        error_details: str | None = None,
        attempted_tokens: int | None = None,
        **kwargs,
    ):
        super().__init__(message, image_path=image_path, model_name=model_name, error_details=error_details, **kwargs)
        self.attempted_tokens = attempted_tokens


class VLMContextLengthError(VLMProcessingError):
    """Exception raised when VLM processing fails due to context length limits."""

    def __init__(
        self,
        message: str,
        image_path: str | None = None,
        model_name: str | None = None,
        error_details: str | None = None,
        attempted_tokens: int | None = None,
        **kwargs,
    ):
        super().__init__(message, image_path=image_path, model_name=model_name, error_details=error_details, **kwargs)
        self.attempted_tokens = attempted_tokens
