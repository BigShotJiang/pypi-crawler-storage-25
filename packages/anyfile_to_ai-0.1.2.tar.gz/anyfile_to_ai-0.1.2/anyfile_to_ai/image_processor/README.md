# Image VLM Text Description Module

A Python module for processing images with Vision Language Models (VLM) to generate descriptive text. Features real VLM integration using MLX framework for Apple Silicon optimization.

## Installation & Setup

### Prerequisites
- Python 3.13 or higher
- Apple Silicon Mac (for MLX optimization)
- UV package manager (recommended) or pip

### Dependencies Installation

Using UV (recommended):
```bash
uv add mlx-vlm>=0.3.3 pillow>=11.3.0 torch>=2.8.0
```

Using pip:
```bash
pip install mlx-vlm>=0.3.3 pillow>=11.3.0 torch>=2.8.0
```

### Provider and Model Configuration

**Required**: Set `VISION_MODEL` (or pass `--vision-model`) before using the module.

```bash
# Default local MLX path
export PROVIDER=mlx
export VISION_MODEL=mlx-community/Qwen2-VL-2B-Instruct-4bit

# Remote provider example
export PROVIDER=lmstudio
export BASE_URL=http://127.0.0.1:1234/v1
export VISION_MODEL=qwen/qwen3-vl-8b
```

### Optional Environment Variables

```bash
# Timeout behavior when VLM processing fails
export VLM_TIMEOUT_BEHAVIOR=error  # options: error, fallback, continue

# Auto-download models if not available
export VLM_AUTO_DOWNLOAD=true  # options: true, false
```

### Verify Installation
```bash
python -m anyfile_to_ai.image_processor --help
```

## CLI Usage

### Basic Image Processing
```bash
# Process single image
python -m anyfile_to_ai.image_processor image.jpg

# Process multiple images
python -m anyfile_to_ai.image_processor *.jpg *.png

# Process with different description styles
python -m anyfile_to_ai.image_processor image.jpg --style brief
python -m anyfile_to_ai.image_processor image.jpg --style detailed
python -m anyfile_to_ai.image_processor image.jpg --style technical
```

### Output Formats
```bash
# JSON output
python -m anyfile_to_ai.image_processor image.jpg --format json

# CSV output
python -m anyfile_to_ai.image_processor *.jpg --format csv

# Plain text (default)
python -m anyfile_to_ai.image_processor image.jpg --format plain
```

### Advanced Options
```bash
# Batch processing with custom settings
python -m anyfile_to_ai.image_processor *.jpg --batch-size 2 --max-length 300

# Save output to file
python -m anyfile_to_ai.image_processor *.jpg --format json --output results.json

# Verbose progress tracking
python -m anyfile_to_ai.image_processor *.jpg --verbose

# Quiet mode (results only)
python -m anyfile_to_ai.image_processor image.jpg --quiet

# Override provider/model for one run
python -m anyfile_to_ai.image_processor image.jpg \
  --provider lmstudio \
  --base-url http://127.0.0.1:1234/v1 \
  --vision-model qwen/qwen3-vl-8b
```

### CLI Options
- `--style`: Description style (`detailed`, `brief`, `technical`)
- `--max-length`: Maximum description length (50-1000 chars)
- `--batch-size`: Images to process simultaneously (1-10)
- `--timeout`: Processing timeout per image in seconds
- `--format`: Output format (`plain`, `json`, `csv`)
- `--output`: Save results to file
- `--provider`: Provider override (`mlx`, `lmstudio`, `ollama`)
- `--base-url`: Base URL override for remote providers
- `--vision-model`: Vision model override
- `--verbose`: Enable progress output
- `--quiet`: Suppress all output except results

## Python API Usage

### Basic Image Processing

```python
from anyfile_to_ai.image_processor import process_image, create_config

# Simple single image processing
result = process_image('image.jpg')
if result.success:
    print(f"Description: {result.description}")
    print(f"Confidence: {result.confidence_score}")
```

### Batch Processing
```python
from anyfile_to_ai.image_processor import process_images

# Process multiple images
image_paths = ['img1.jpg', 'img2.png', 'img3.jpeg']
results = process_images(image_paths)

print(f"Processed {results.successful_count}/{results.total_images} images")
for result in results.results:
    if result.success:
        print(f"{result.image_path}: {result.description}")
```

### Advanced Configuration

```python
from anyfile_to_ai.image_processor import process_images, create_config

# Custom configuration
config = create_config(
    description_style="technical",
    max_length=300,
    batch_size=2
)

results = process_images(image_paths, config)
```

### Progress Tracking (Unified System)

The image_processor now supports the unified progress tracking system:

```python
from anyfile_to_ai.image_processor import process_images
from anyfile_to_ai.progress_tracker import ProgressEmitter, CLIProgressConsumer

# Create progress emitter
emitter = ProgressEmitter(total=len(image_paths), label="Processing images")
emitter.add_consumer(CLIProgressConsumer())

# Process with progress tracking
results = process_images(image_paths, progress_emitter=emitter)

# The progress bar will show:
# Processing images |████████████████| 100% (10/10 images)
```

#### Streaming with Progress

```python
from anyfile_to_ai.image_processor import process_images_streaming, create_config
from anyfile_to_ai.progress_tracker import ProgressEmitter, CLIProgressConsumer

# Create progress emitter for streaming
emitter = ProgressEmitter(total=len(image_paths), label="Streaming images")
emitter.add_consumer(CLIProgressConsumer())

# Stream processing with progress updates
for i, result in enumerate(process_images_streaming(image_paths)):
    emitter.update(1)
    print(f"Completed: {result.image_path}")

emitter.complete()
```

#### Legacy Progress Callback (Deprecated)

The old callback-based progress is still supported but deprecated:

```python
from anyfile_to_ai.image_processor import process_images_streaming, create_config

def progress_handler(current, total):
    print(f"Processing {current}/{total} images...")

# This works but emits a deprecation warning
config = create_config(progress_callback=progress_handler)

for result in process_images_streaming(image_paths, config):
    print(f"Completed: {result.image_path}")
```

**Migration**: Use `progress_emitter` parameter instead of `progress_callback`.

### Image Validation
```python
from anyfile_to_ai.image_processor import validate_image, get_supported_formats

# Validate image before processing
try:
    img_doc = validate_image('image.jpg')
    print(f"Valid image: {img_doc.format}, {img_doc.width}x{img_doc.height}")
except Exception as e:
    print(f"Invalid image: {e}")

# Check supported formats
formats = get_supported_formats()
print(f"Supported formats: {formats}")
```

## Configuration Options

### ProcessingConfig Parameters

- **description_style** (`str`): Style of description
  - `"detailed"`: Comprehensive descriptions (default)
  - `"brief"`: Short, concise descriptions
  - `"technical"`: Technical/analytical descriptions
- **max_description_length** (`int`): Max characters (50-1000, default: 500)
- **batch_size** (`int`): Concurrent processing (1-10, default: 4)
- **timeout_seconds** (`int`): Per-image timeout (default: 60)
- **progress_callback** (`Callable[[int, int], None]`): Progress tracking function

### VLM-Specific Options

- **vlm_timeout_behavior** (`str`): How to handle timeouts
  - `"error"`: Raise exception (default)
  - `"fallback"`: Use fallback description
  - `"continue"`: Skip and continue processing
- **auto_download_models** (`bool`): Auto-download models (default: `True`)
- **validate_model_before_load** (`bool`): Validate model availability (default: `True`)

## Environment Setup

### Model Configuration
```python
import os
from anyfile_to_ai.image_processor import validate_model_availability

# Check if model is available
model_name = "qwen/qwen3-vl-8b"
os.environ["PROVIDER"] = "lmstudio"
os.environ["BASE_URL"] = "http://127.0.0.1:1234/v1"
os.environ["VISION_MODEL"] = model_name

is_available = validate_model_availability(model_name)
if not is_available:
    print("Model will be downloaded on first use")
```

### Performance Optimization
```bash
# For faster processing on Apple Silicon
export VISION_MODEL=mlx-community/gemma-3-4b-it-4bit

# For remote providers
export PROVIDER=lmstudio
export BASE_URL=http://127.0.0.1:1234/v1

# For memory-constrained environments
export VLM_AUTO_DOWNLOAD=false
```

## Error Handling

### Exception Types

```python
from anyfile_to_ai.image_processor.exceptions import (
    ImageProcessingError,
    ImageNotFoundError,
    UnsupportedFormatError,
    CorruptedImageError
)
from anyfile_to_ai.image_processor.vlm_exceptions import (
    VLMConfigurationError,
    VLMModelLoadError,
    VLMProcessingError,
    VLMTimeoutError
)

try:
    result = process_image('image.jpg')
except ImageNotFoundError:
    print("Image file not found")
except UnsupportedFormatError:
    print("Unsupported image format")
except VLMConfigurationError as e:
    print(f"VLM config error: {e}")
    if e.suggested_fix:
        print(f"Fix: {e.suggested_fix}")
except VLMModelLoadError as e:
    print(f"Model loading failed: {e}")
except VLMTimeoutError:
    print("VLM processing timed out")
```

### Common Issues & Solutions

**VLM Configuration Error**:
```bash
# Error: VISION_MODEL not set
export VISION_MODEL=google/gemma-3-4b

# Error: BASE_URL required for remote providers
export PROVIDER=lmstudio
export BASE_URL=http://127.0.0.1:1234/v1
```

**Model Loading Issues**:
```python
# Check available models
from anyfile_to_ai.image_processor import get_available_models
print(get_available_models())
```

**Memory Issues**:
```python
# Use smaller batch size
config = create_config(batch_size=1)
```

## Data Models

### Core Objects

```python
# Image metadata
ImageDocument(file_path, format, width, height, file_size, is_large_image)

# Processing result for single image
DescriptionResult(
    image_path, description, confidence_score, processing_time,
    model_used, success, technical_metadata, vlm_processing_time, model_version
)

# Batch processing result
ProcessingResult(
    success, results, total_images, successful_count,
    failed_count, total_processing_time, error_message
)
```

## Shared Formatter Migration

Markdown output now routes through `anyfile_to_ai.output_formatter` by default for contract alignment.

- Roll back with `ANYFILE_OUTPUT_FORMATTER_IMAGE_SHARED=0`.
- `--include-metadata` now maps to normalized metadata groups in shared formatter output.

## Examples with Sample Data

```python
# Example with project sample images
sample_image = "sample-data/images/DJI_20250817104854_0118_D.JPG"

# Quick processing
result = process_image(sample_image)
print(f"Description: {result.description}")

# Batch process all samples
import glob
sample_images = glob.glob("sample-data/images/*.jpg")
results = process_images(sample_images)

# Technical analysis
config = create_config(description_style="technical")
tech_result = process_image(sample_image, config)
print(f"Technical analysis: {tech_result.description}")
```

## Supported Image Formats

- **JPEG** (.jpg, .jpeg)
- **PNG** (.png)
- **GIF** (.gif)
- **BMP** (.bmp)
- **WebP** (.webp)

Check programmatically:
```python
from anyfile_to_ai.image_processor import get_supported_formats
print(get_supported_formats())  # ['bmp', 'gif', 'jpeg', 'png', 'webp']
```

## Cancellation Support

The image processor supports cooperative cancellation for batch and streaming operations:

### Batch Processing with Cancellation

```python
from anyfile_to_ai.image_processor import process_images, create_config
from anyfile_to_ai.progress_tracker import CancellationToken, OperationCancelledError

# Create cancellation token
token = CancellationToken()
config = create_config(description_style="detailed")

# Process images with cancellation support
try:
    results = process_images(
        ["image1.jpg", "image2.jpg", "image3.jpg"],
        config=config,
        cancel_token=token
    )
    print(f"Processed {results.successful_count} images")
except OperationCancelledError as e:
    print(f"Processing cancelled: {e.message}")
```

### Streaming with Cancellation

```python
from anyfile_to_ai.image_processor import process_images_streaming, create_config
from anyfile_to_ai.progress_tracker import CancellationToken, OperationCancelledError

token = CancellationToken()
config = create_config(description_style="brief")

processed = []
try:
    for result in process_images_streaming(
        ["img1.jpg", "img2.jpg", "img3.jpg"],
        config=config,
        cancel_token=token
    ):
        if result.success:
            processed.append(result)
            print(f"Processed: {result.image_path}")
        
        # Cancel after 2 images
        if len(processed) >= 2:
            token.cancel()
except OperationCancelledError:
    print(f"Cancelled after processing {len(processed)} images")
```

### Best Practices

1. **Check at iteration boundaries**: Cancellation is checked before processing each image
2. **Clean up VLM resources**: Resources are cleaned up before raising `OperationCancelledError`
3. **Handle partial results**: Process completed results before cancellation

```python
from anyfile_to_ai.image_processor import process_images_streaming
from anyfile_to_ai.progress_tracker import CancellationToken, OperationCancelledError

def process_with_limit(image_paths, max_images=None):
    """Process images with optional limit via cancellation."""
    token = CancellationToken()
    results = []
    
    try:
        for result in process_images_streaming(image_paths, cancel_token=token):
            results.append(result)
            
            # Cancel if limit reached
            if max_images and len(results) >= max_images:
                token.cancel()
    except OperationCancelledError:
        print(f"Cancelled after {len(results)} images")
    
    return results
```

## Token Reduction Fallback

The image processor supports automatic token reduction fallback when VLM processing fails due to memory or context length constraints. This feature progressively reduces the `max_tokens` parameter to allow processing to succeed with smaller outputs.

### How It Works

When processing fails with a memory or context error, the system automatically retries with progressively smaller token limits:

1. Initial attempt with full tokens
2. On memory/context error, retry with smaller tokens
3. Continue until success or all levels exhausted

### Configuration

```python
from anyfile_to_ai.image_processor.config import VLMConfig
from anyfile_to_ai.image_processor.vlm_processor import VLMProcessor

# Enable token fallback (default: True)
config = VLMConfig(
    model_name="mlx-community/Qwen2-VL-2B-Instruct-4bit",
    enable_token_fallback=True,  # Enable/disable fallback
    token_fallback_levels=[8192, 4096, 2048, 1024, 512]  # Custom levels
)

# Use process_with_fallback for automatic retry
processor = VLMProcessor()
result = processor.process_with_fallback(
    image_path="large_image.jpg",
    prompt="Describe this image",
    config=config,
    initial_max_tokens=8192
)
```

### Default Behavior

- **Fallback enabled by default**: `enable_token_fallback=True`
- **Default levels**: `[8192, 4096, 2048, 1024, 512]` (capped at initial max_tokens)
- **Automatic detection**: Memory and context errors are detected automatically

### Error Types

The system recognizes these error types for fallback:

- `VLMMemoryError`: Out-of-memory conditions
- `VLMContextLengthError`: Context length exceeded

```python
from anyfile_to_ai.image_processor.exceptions import VLMMemoryError, VLMContextLengthError

try:
    result = processor.process_with_fallback("image.jpg", "describe", config)
except VLMMemoryError as e:
    print(f"Memory error after trying {e.attempted_tokens} tokens")
except VLMContextLengthError as e:
    print(f"Context error after trying {e.attempted_tokens} tokens")
except VLMProcessingError as e:
    print(f"All fallback levels exhausted: {e}")
```

### Disabling Fallback

```python
# Disable fallback for immediate error propagation
config = VLMConfig(
    model_name="test-model",
    enable_token_fallback=False
)

# Falls back to standard process_image_with_vlm behavior
result = processor.process_with_fallback("image.jpg", "describe", config)
```

### Backward Compatibility

The existing `process_image_with_vlm()` method remains unchanged and does not use token fallback. Use `process_with_fallback()` for the new retry behavior.
