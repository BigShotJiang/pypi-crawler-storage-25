"""Markdown formatting for audio transcription results."""

import csv
import io
from typing import Any
from anyfile_to_ai.audio_processor.models import TranscriptionSegment


def format_markdown(result: dict[str, Any]) -> str:
    """
    Format audio transcription result as markdown.

    Args:
        result: Dictionary with transcription data:
            - filename: str - Audio filename
            - duration: float - Duration in seconds
            - model: str - Whisper model used
            - language: str - Language code
            - segments: List[Dict] - Transcript segments with optional timestamps/speakers
            - metadata: dict | None - Optional processing metadata

    Returns:
        str: Markdown-formatted transcript with structure:
            - YAML frontmatter (if metadata present)
            - H1: Transcription title with filename
            - Metadata: Duration, Model, Language as bullet list
            - H2: Segments with timestamps and speakers (if available)
            - Content: Transcript text (no escaping)
            - Extended Metadata section (if present)

    Note:
        Special characters are NOT escaped per research.md decision (2025-10-02).
        Fallback: If no speakers/timestamps, output as plain paragraphs.
    """
    from anyfile_to_ai.output_formatter import format_markdown as format_markdown_shared

    payload = {
        "content": result.get("text", ""),
        "filename": result.get("filename", "audio.mp3"),
        "duration": result.get("duration", 0.0),
        "model": result.get("model", "unknown"),
        "language": result.get("language", "en"),
        "segments": result.get("segments", []),
        "metadata": result.get("metadata"),
        "legacy_audio_heading": True,
        "legacy_audio_document": True,
        "legacy_audio_timestamp_no_centiseconds": True,
    }
    return format_markdown_shared("audio", payload, include_metadata=result.get("metadata") is not None)


def _format_duration(seconds: float) -> str:
    """Format duration as HH:MM:SS."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def _format_timestamp(seconds: float) -> str:
    """Format timestamp as HH:MM:SS."""
    return _format_duration(seconds)


def format_timestamp(seconds: float) -> str:
    """
    Format timestamp in HH:MM:SS.CC format (centisecond precision).

    Args:
        seconds: Time in seconds (0.0 to 7200.0)

    Returns:
        str: Formatted timestamp (e.g., "00:01:23.45")

    Raises:
        ValueError: If seconds is negative or exceeds 7200.0
    """
    if seconds < 0.0:
        msg = f"Timestamp cannot be negative: {seconds}"
        raise ValueError(msg)
    if seconds > 7200.0:
        msg = f"Timestamp exceeds maximum duration (2 hours): {seconds}"
        raise ValueError(msg)

    # Convert once to centiseconds to handle rounding rollover correctly
    total_centiseconds = round(seconds * 100)
    hours = total_centiseconds // 360000
    remaining = total_centiseconds % 360000
    minutes = remaining // 6000
    remaining = remaining % 6000
    secs = remaining // 100
    centiseconds = remaining % 100

    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{centiseconds:02d}"


def format_segments_markdown(segments: list[TranscriptionSegment], include_text: bool = True) -> str:
    """
    Format timestamped segments for markdown output.

    Args:
        segments: List of TranscriptionSegment objects
        include_text: Whether to include full text (default: True)

    Returns:
        str: Formatted string with one line per segment
    """
    if not segments:
        return ""

    lines = []
    for segment in segments:
        timestamp = format_timestamp(segment.start)
        if include_text:
            lines.append(f"[{timestamp}] {segment.text}")
        else:
            lines.append(f"[{timestamp}]")

    return "\n".join(lines)


def format_segments_csv(segments: list[TranscriptionSegment]) -> str:
    """
    Format timestamped segments as CSV.

    Args:
        segments: List of TranscriptionSegment objects

    Returns:
        str: CSV string with header row: start,end,text
    """
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["start", "end", "text"])

    for segment in segments:
        writer.writerow([f"{segment.start:.2f}", f"{segment.end:.2f}", segment.text])

    return output.getvalue()
