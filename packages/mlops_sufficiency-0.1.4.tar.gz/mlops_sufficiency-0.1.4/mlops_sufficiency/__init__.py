"""
mlops_sufficiency
=================
Biblioteca para avaliação de suficiência de treinamento de modelos de IA,
desenvolvida para o projeto de mestrado em MLOps aplicado à detecção de
resíduos urbanos.

Autor: Yago de Jesus Martins
"""

from .evaluator import TrainingSufficiencyEvaluator
from .metrics import InferenceMetricsCollector
from .drift import DataDriftDetector
from .report import SufficiencyReport
from .api_client import VideoAPIClient

__all__ = [
    "TrainingSufficiencyEvaluator",
    "InferenceMetricsCollector",
    "DataDriftDetector",
    "SufficiencyReport",
    "VideoAPIClient",
]

__version__ = "0.1.0"
__author__ = "Yago de Jesus Martins"

_BANNER = r"""
  _  _  _    ___                                 _  __  __  _
 | \/ || |  / _ \  _ __  ___   ___  _   _  __  (_)|  \/  || |  _ __
 | |\/| || || | | || '_ \/ __| / __|| | | ||  _|| || |\/| || | | '__|
 | |  | || || |_| || |_) \__ \ \__ \| |_| || |  | || |  | || |_| |
 |_|  |_||_| \___/ | .__/|___/ |___/ \__,_||_|  |_||_|  |_||_(_)_|
                    |_|

""".format(version=__version__)

print(_BANNER)
