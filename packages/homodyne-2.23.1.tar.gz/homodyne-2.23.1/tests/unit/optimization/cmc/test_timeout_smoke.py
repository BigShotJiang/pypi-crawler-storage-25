"""Smoke tests for CMC timeout mitigation settings.

These tests ensure the lighter defaults and shard sizing helpers do not regress
and that a tiny laminar-flow run completes quickly with reduced settings.
"""

from __future__ import annotations

import numpy as np
import pytest

# Require ArviZ for CMC imports; skip module if missing optional dependency
pytest.importorskip("arviz", reason="ArviZ required for CMC unit tests")

from homodyne.optimization.cmc import core  # noqa: E402
from homodyne.optimization.cmc.core import (
    _resolve_max_points_per_shard,
    fit_mcmc_jax,
)
from homodyne.optimization.cmc.results import CMCResult


class _MockParameterSpace:
    """Minimal ParameterSpace substitute for tests."""

    def __init__(self) -> None:
        bounds = {
            "contrast": (0.0, 1.0),
            "offset": (0.5, 1.5),
            "D0": (100.0, 1e5),
            "alpha": (-2.0, 2.0),
            "D_offset": (-1e5, 1e5),
            "gamma_dot_t0": (1e-6, 0.5),
            "beta": (-2.0, 2.0),
            "gamma_dot_t_offset": (-0.1, 0.1),
            "phi0": (-10.0, 10.0),
        }
        self._bounds = bounds

    def get_bounds(self, name: str):
        base = name.split("_")[0]
        return self._bounds.get(base, (-1.0, 1.0))

    def get_prior(self, name: str):
        # No custom priors for this smoke test
        raise KeyError(name)


@pytest.mark.unit
def test_resolve_max_points_per_shard_laminar_large_pool():
    # v2.22.2: Reduced shard sizes after reparameterization fixes bimodal posteriors
    # With n_phi=1, angle_factor=0.6, base=5K (for 3M) → scaled=3K (MIN_SHARD_SIZE_LAMINAR)
    # With n_phi=10+, angle_factor=0.85, base=5K → scaled=4,250
    assert _resolve_max_points_per_shard("laminar_flow", 3_000_000, "auto") == 3_000
    # Multi-angle dataset should scale differently (n_phi=10 gets angle_factor=0.85)
    assert (
        _resolve_max_points_per_shard("laminar_flow", 3_000_000, "auto", n_phi=10)
        == 4_250
    )
    # 1B dataset: base=10K * 0.6 = 6K, but max_shards=100K cap → 1B/100K = 10K
    assert (
        _resolve_max_points_per_shard("laminar_flow", 1_000_000_000, "auto", n_phi=3)
        == 10_000
    )


@pytest.mark.unit
def test_suggested_timeout_clamps_and_scales():
    # cost: chains=2, warmup+samples=2000, max_per_shard=3k → cost=12M
    cost = 2 * (500 + 1500) * 3_000
    # raw = 5 * 5e-5 * 12,000,000 = 3,000s → within [600, 7200]
    suggested, exceeded = core._compute_suggested_timeout(
        cost_per_shard=cost, max_timeout=7200
    )
    assert suggested == 3_000
    assert not exceeded

    # Smaller cost should respect min clamp 600s
    small_cost = 2 * (5 + 10) * 100
    suggested_small, exceeded_small = core._compute_suggested_timeout(
        cost_per_shard=small_cost, max_timeout=7200
    )
    assert suggested_small == 600
    assert not exceeded_small

    # Very large cost should clamp to max and report exceeded
    huge_cost = 4 * 4000 * 60_000  # Production scenario that caused timeouts
    suggested_huge, exceeded_huge = core._compute_suggested_timeout(
        cost_per_shard=huge_cost, max_timeout=7200
    )
    assert suggested_huge == 7200
    assert exceeded_huge


@pytest.mark.unit
def test_laminar_flow_smoke_run_completes_quickly():
    # Tiny synthetic dataset (single phi angle, off-diagonal time pairs)
    # Note: t1 != t2 required since CMC filters diagonal points (t1==t2)
    t1 = np.linspace(0.1, 0.5, 12)
    t2 = t1 + 0.05  # Off-diagonal: t2 > t1
    data = 1.0 + 0.01 * np.random.randn(len(t1))
    phi = np.zeros_like(t1)

    cmc_cfg = {
        "enable": True,
        "sharding": {"strategy": "stratified", "max_points_per_shard": 1000},
        "per_shard_timeout": 30,
        "per_shard_mcmc": {
            "num_warmup": 5,
            "num_samples": 10,
            "num_chains": 1,
            "target_accept_prob": 0.8,
        },
    }

    result = fit_mcmc_jax(
        data=data,
        t1=t1,
        t2=t2,
        phi=phi,
        q=0.005,
        L=2e6,
        analysis_mode="laminar_flow",
        cmc_config=cmc_cfg,
        parameter_space=_MockParameterSpace(),
        dt=0.1,
        progress_bar=False,
    )

    assert isinstance(result, CMCResult)
    assert result.samples is not None
