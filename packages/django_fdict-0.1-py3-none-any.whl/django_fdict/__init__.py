from django.db.models import Case, F, Q, Value, When
from itertools import zip_longest

__all__ = ("FDict",)

MISSING = object()


class FDict(dict):
    def wrap_value(self, value, output_field=None):
        if hasattr(value, "resolve_expression"):
            return value
        return Value(value, output_field=output_field)

    def get_wrapped_items(self, output_field=None):
        for k, v in self.items():
            yield self.wrap_item(k), self.wrap_value(v, output_field=output_field)

    def wrap_item(self, key):
        if isinstance(key, (list, tuple)):
            return key
        else:
            return (key,)

    def unpack_tuple(self, ky, val):
        result = {}
        for k, v in zip_longest(ky, val, fillvalue=MISSING):
            if k is MISSING or v is MISSING:
                raise TypeError("The length of the keys and subscript do not match")
            if isinstance(k, F):
                result[k.name] = v
            elif k != v:
                return
        yield Q(**result)

    def generate_case_when(self, name, default=None, output_field=None):
        return Case(
            *[
                When(condition=condition, then=val)
                for key, val in self.get_wrapped_items(output_field=output_field)
                for condition in self.unpack_tuple(name, key)
            ],
            default=self.wrap_value(default),
            output_field=output_field,
        )

    def normalize_key(self, key):
        if isinstance(key, F):
            return (key,)
        if isinstance(key, (list, tuple)) and any(isinstance(ky, F) for ky in key):
            return key

    def __getitem__(self, item):
        field_keys = self.normalize_key(item)
        if field_keys:
            return self.generate_case_when(field_keys)
        else:
            return super().__getitem__(item)

    def get(self, key, default=None, output_field=None):
        field_keys = self.normalize_key(key)
        if field_keys:
            return self.generate_case_when(field_keys, default, output_field)
        else:
            return super().get(key, default)

    def __repr__(self):
        return f"FDict({super().__repr__()})"
