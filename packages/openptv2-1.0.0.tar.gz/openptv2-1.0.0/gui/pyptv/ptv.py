"""PyPTV core functionality module.

This module provides the core functionality for the PyPTV package, including
image processing, calibration, tracking, and other utilities.
"""

# Standard library imports
import importlib
import os
import sys
import re
from pathlib import Path
from typing import List, Sequence, Tuple

# Third-party imports
import numpy as np
from scipy.optimize import least_squares, minimize
from scipy import sparse
from imageio.v3 import imread
from skimage.util import img_as_ubyte
from skimage.color import rgb2gray

# Backend imports from optv
from optv.calibration import Calibration
from optv.parameters import (
    ControlParams,
    SequenceParams,
    TrackingParams,
    TargetParams,
    VolumeParams,
)
from optv.correspondences import correspondences, MatchedCoords
from optv.image_processing import preprocess_image
from optv.orientation import point_positions
from optv.segmentation import target_recognition
from optv.tracking_framebuf import TargetArray
from optv.tracker import Tracker, default_naming
from optv.transforms import convert_arr_pixel_to_metric, convert_arr_metric_to_pixel

"""
example from Tracker documentation: 
        dict naming - a dictionary with naming rules for the frame buffer 
            files. Keys: 'corres', 'linkage', 'prio'. Values can be either
            strings or bytes. Strings will be automatically encoded to UTF-8 bytes.
            If None, uses default_naming.

    default_naming = {
        'corres': 'res/rt_is',
        'linkage': 'res/ptv_is',
        'prio': 'res/added'
    }            
"""

# PyPTV imports
from .parameter_manager import ParameterManager

# Constants
NAMES = ["cc", "xh", "yh", "k1", "k2", "k3", "p1", "p2", "scale", "shear"]
DEFAULT_FRAME_NUM = 123456789
DEFAULT_HIGHPASS_FILTER_SIZE = 25
DEFAULT_NO_FILTER = 0
SHORT_BASE = "cam"  # Use this as the short base for camera file naming


def _prepare_output_path(filename: str) -> Path:
    """Return a writable output path, creating parent directories when needed."""
    output_path = Path(filename)
    parent = output_path.parent

    if parent != Path("."):
        try:
            parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise OSError(
                "Unable to prepare output directory "
                f"'{parent}' for '{output_path.name}'. "
                "Please choose a writable experiment folder or change the folder permissions."
            ) from exc

    return output_path


def _raise_output_write_error(output_path: Path, exc: OSError) -> None:
    """Raise an actionable write error for generated output files."""
    if isinstance(exc, PermissionError):
        raise PermissionError(
            f"Cannot write output file '{output_path}'. "
            f"PyPTV does not have permission to write to '{output_path.parent}'. "
            "Please change the folder permissions or move the experiment to a user-writable directory."
        ) from exc

    raise OSError(f"Failed to write output file '{output_path}': {exc}") from exc


def _ensure_directory_writable(directory: Path, label: str) -> Path:
    """Create and probe an output directory before writing generated files."""
    directory = Path(directory)
    print(f"Checking {label} directory {directory}")
    probe_path = _prepare_output_path(str(directory / ".pyptv_write_probe"))

    try:
        with open(probe_path, "w", encoding="utf-8") as probe_file:
            probe_file.write("pyptv write probe\n")
    except OSError as exc:
        _raise_output_write_error(probe_path, exc)
    finally:
        try:
            probe_path.unlink(missing_ok=True)
        except OSError:
            pass

    print(f"{label} directory {directory} is writable.")
    return directory


def _ensure_target_output_writable(short_file_bases: List[str]) -> None:
    """Check target output directories before the first target file write."""
    checked_dirs = set()

    for short_file_base in short_file_bases:
        directory = Path(short_file_base).parent
        directory_key = (
            str(directory.resolve()) if directory.exists() else str(directory)
        )
        if directory_key in checked_dirs:
            continue

        _ensure_directory_writable(directory, "Target output")
        checked_dirs.add(directory_key)


def image_split(img: np.ndarray, order=[0, 1, 3, 2]) -> List[np.ndarray]:
    """Split image into four quadrants."""
    list_of_images = [
        img[: img.shape[0] // 2, : img.shape[1] // 2],
        img[: img.shape[0] // 2, img.shape[1] // 2 :],
        img[img.shape[0] // 2 :, : img.shape[1] // 2],
        img[img.shape[0] // 2 :, img.shape[1] // 2 :],
    ]
    list_of_images = [list_of_images[i] for i in order]
    return list_of_images


def negative(img: np.ndarray) -> np.ndarray:
    """Convert an 8-bit image to its negative."""
    return 255 - img


def simple_highpass(img: np.ndarray, cpar: ControlParams) -> np.ndarray:
    """Apply a simple highpass filter to an image using liboptv preprocess_image."""
    return preprocess_image(img, DEFAULT_NO_FILTER, cpar, DEFAULT_HIGHPASS_FILTER_SIZE)


def _populate_cpar(ptv_params: dict, num_cams: int) -> ControlParams:
    """Populate a ControlParams object from a dictionary containing full parameters.

    Args:
        params: Full parameter dictionary with global num_cams and ptv section
    """
    # ptv_params = params.get('ptv', {})

    img_cal_list = ptv_params.get("img_cal", [])
    if len([x for x in img_cal_list if x is not None]) < num_cams:
        raise ValueError("img_cal_list is too short")

    cpar = ControlParams(num_cams)
    # Set required parameters directly from the dictionary, no defaults
    cpar.set_image_size((ptv_params["imx"], ptv_params["imy"]))
    cpar.set_pixel_size((ptv_params["pix_x"], ptv_params["pix_y"]))
    cpar.set_hp_flag(ptv_params["hp_flag"])
    cpar.set_allCam_flag(ptv_params["allcam_flag"])
    cpar.set_tiff_flag(ptv_params["tiff_flag"])
    cpar.set_chfield(ptv_params["chfield"])

    mm_params = cpar.get_multimedia_params()
    mm_params.set_n1(ptv_params["mmp_n1"])
    mm_params.set_layers([ptv_params["mmp_n2"]], [ptv_params["mmp_d"]])
    mm_params.set_n3(ptv_params["mmp_n3"])

    img_cal_list = ptv_params["img_cal"]

    for i in range(num_cams):  # Use global num_cams
        cpar.set_cal_img_base_name(i, img_cal_list[i])
    return cpar


def _populate_spar(seq_params: dict, num_cams: int) -> SequenceParams:
    """Populate a SequenceParams object from a dictionary.

    Raises ValueError if required sequence parameters are missing.
    No default values are provided to avoid silent failures.
    """
    required_params = ["first", "last", "base_name"]
    missing_params = [param for param in required_params if param not in seq_params]

    if missing_params:
        raise ValueError(
            f"Missing required sequence parameters: {missing_params}. "
            f"Available parameters: {list(seq_params.keys())}"
        )

    base_name_list = seq_params["base_name"]

    if len([x for x in base_name_list if x is not None]) < num_cams:
        raise ValueError(
            f"base_name_list length ({len(base_name_list)}) does not match num_cams ({num_cams})"
        )

    spar = SequenceParams(num_cams=num_cams)
    spar.set_first(seq_params["first"])
    spar.set_last(seq_params["last"])

    # Set base names for each camera
    for i in range(num_cams):
        spar.set_img_base_name(i, base_name_list[i])

    return spar


def _populate_vpar(crit_params: dict) -> VolumeParams:
    """Populate a VolumeParams object from a dictionary."""
    vpar = VolumeParams()
    vpar.set_X_lay(crit_params["X_lay"])
    vpar.set_Zmin_lay(crit_params["Zmin_lay"])
    vpar.set_Zmax_lay(crit_params["Zmax_lay"])

    # Set correspondence parameters
    vpar.set_eps0(crit_params["eps0"])
    vpar.set_cn(crit_params["cn"])
    vpar.set_cnx(crit_params["cnx"])
    vpar.set_cny(crit_params["cny"])
    vpar.set_csumg(crit_params["csumg"])
    vpar.set_corrmin(crit_params["corrmin"])

    return vpar


def _populate_track_par(track_params: dict) -> TrackingParams:
    """Populate a TrackingParams object from a dictionary.

    Raises ValueError if required tracking parameters are missing.
    No default values are provided to avoid silent tracking failures.
    """
    required_params = [
        "dvxmin",
        "dvxmax",
        "dvymin",
        "dvymax",
        "dvzmin",
        "dvzmax",
        "angle",
        "dacc",
        "flagNewParticles",
    ]
    missing_params = [param for param in required_params if param not in track_params]

    if missing_params:
        raise ValueError(
            f"Missing required tracking parameters: {missing_params}. "
            f"Available parameters: {list(track_params.keys())}"
        )

    track_par = TrackingParams()
    track_par.set_dvxmin(track_params["dvxmin"])
    track_par.set_dvxmax(track_params["dvxmax"])
    track_par.set_dvymin(track_params["dvymin"])
    track_par.set_dvymax(track_params["dvymax"])
    track_par.set_dvzmin(track_params["dvzmin"])
    track_par.set_dvzmax(track_params["dvzmax"])
    track_par.set_dangle(track_params["angle"])
    track_par.set_dacc(track_params["dacc"])
    track_par.set_add(track_params["flagNewParticles"])
    return track_par


def _populate_tpar(targ_params: dict, num_cams: int) -> TargetParams:
    """Populate a TargetParams object from a dictionary."""
    # targ_params = params.get('targ_rec', {})

    # Get global num_cams - the single source of truth
    # num_cams = params.get('num_cams', 0)

    tpar = TargetParams(num_cams)
    # Handle both 'targ_rec' and 'detect_plate' parameter variants
    if "targ_rec" in targ_params:
        params = targ_params["targ_rec"]
        tpar.set_grey_thresholds(params["gvthres"])
        tpar.set_pixel_count_bounds((params["nnmin"], params["nnmax"]))
        tpar.set_xsize_bounds((params["nxmin"], params["nxmax"]))
        tpar.set_ysize_bounds((params["nymin"], params["nymax"]))
        tpar.set_min_sum_grey(params["sumg_min"])
        tpar.set_max_discontinuity(params["disco"])
    elif "detect_plate" in targ_params:
        params = targ_params["detect_plate"]
        # Convert detect_plate keys to TargetParams fields
        # Ensure all required grey thresholds are present
        required_gvth_keys = ["gvth_1", "gvth_2", "gvth_3", "gvth_4"]
        missing_keys = [k for k in required_gvth_keys if k not in params]
        if missing_keys:
            raise ValueError(
                f"Missing required grey threshold keys in detect_plate: {missing_keys}"
            )
        tpar.set_grey_thresholds(
            [
                params["gvth_1"],
                params["gvth_2"],
                params["gvth_3"],
                params["gvth_4"],
            ]
        )
        # Remove default values - all parameters must be explicitly provided
        required_detect_keys = [
            "min_npix",
            "max_npix",
            "min_npix_x",
            "max_npix_x",
            "min_npix_y",
            "max_npix_y",
            "sum_grey",
            "tol_dis",
        ]
        missing_detect_keys = [k for k in required_detect_keys if k not in params]
        if missing_detect_keys:
            raise ValueError(
                f"Missing required detect_plate keys: {missing_detect_keys}"
            )

        tpar.set_pixel_count_bounds((params["min_npix"], params["max_npix"]))
        tpar.set_xsize_bounds((params["min_npix_x"], params["max_npix_x"]))
        tpar.set_ysize_bounds((params["min_npix_y"], params["max_npix_y"]))
        tpar.set_min_sum_grey(params["sum_grey"])
        tpar.set_max_discontinuity(params["tol_dis"])
    else:
        raise ValueError(
            "Target parameters must contain either 'targ_rec' or 'detect_plate' section."
        )
    return tpar


def _read_calibrations(cpar: ControlParams, num_cams: int) -> List[Calibration]:
    """Read calibration files for all cameras.

    Returns empty/default calibrations if files don't exist, which is normal
    for the calibration GUI before calibrations have been created.
    """
    cals = []
    for i_cam in range(num_cams):
        cal = Calibration()
        base_name = cpar.get_cal_img_base_name(i_cam)

        if not base_name:
            print(
                f"Calibration base name missing for camera {i_cam + 1} - using defaults"
            )
            cals.append(cal)
            continue

        ori_file = base_name + ".ori"
        addpar_file = base_name + ".addpar"

        # Check if calibration files exist and are readable
        ori_exists = os.path.isfile(ori_file) and os.access(ori_file, os.R_OK)
        addpar_exists = os.path.isfile(addpar_file) and os.access(addpar_file, os.R_OK)

        if ori_exists and addpar_exists:
            # Both files exist, load them
            cal.from_file(ori_file, addpar_file)
            print(f"Loaded calibration for camera {i_cam + 1} from {ori_file}")
        else:
            # Files don't exist yet - this is normal for calibration GUI
            # Create default/empty calibration
            print(
                f"Calibration files not found for camera {i_cam + 1} - using defaults"
            )
            print(
                f"  Missing: {ori_file if not ori_exists else ''} {addpar_file if not addpar_exists else ''}"
            )

        cals.append(cal)

    return cals


def py_start_proc_c(
    pm: ParameterManager,
) -> Tuple[
    ControlParams,
    SequenceParams,
    VolumeParams,
    TrackingParams,
    TargetParams,
    List[Calibration],
    dict,
]:
    """Read all parameters needed for processing using ParameterManager."""
    try:
        params = pm.parameters
        num_cams = pm.num_cams

        cpar = _populate_cpar(params["ptv"], num_cams)
        spar = _populate_spar(params["sequence"], num_cams)
        vpar = _populate_vpar(params["criteria"])
        track_par = _populate_track_par(params["track"])

        # Create a dict that contains targ_rec for _populate_tpar
        # Use targ_rec instead of detect_plate to match manual GUI operations
        target_params_dict = {"targ_rec": params["targ_rec"]}
        tpar = _populate_tpar(target_params_dict, num_cams)

        epar = params.get("examine")

        cals = _read_calibrations(cpar, num_cams)

        return cpar, spar, vpar, track_par, tpar, cals, epar

    except IOError as e:
        raise IOError(f"Failed to read parameter files: {e}")


def py_pre_processing_c(
    num_cams: int,
    list_of_images: List[np.ndarray],
    ptv_params: dict,
) -> List[np.ndarray]:
    """Apply pre-processing to a list of images."""
    # num_cams = len(list_of_images)
    cpar = _populate_cpar(ptv_params, num_cams)
    processed_images = []
    for i, img in enumerate(list_of_images):
        img_lp = img.copy()
        processed_images.append(simple_highpass(img_lp, cpar))

    return processed_images


def py_detection_proc_c(
    num_cams: int,
    list_of_images: List[np.ndarray],
    ptv_params: dict,
    target_params: dict,
    existing_target: bool = False,
) -> Tuple[List[TargetArray], List[MatchedCoords]]:
    """Detect targets in a list of images."""
    # num_cams = len(ptv_params.get('img_cal', []))

    if len(list_of_images) != num_cams:
        raise ValueError(
            f"Number of images ({len(list_of_images)}) must match number of cameras ({num_cams})"
        )

    cpar = _populate_cpar(ptv_params, num_cams)

    # Create a dict that contains targ_rec for _populate_tpar
    # target_params_dict = {'targ_rec': target_params}
    tpar = _populate_tpar(target_params, num_cams)

    cals = _read_calibrations(cpar, num_cams)

    detections = []
    corrected = []

    for i_cam, img in enumerate(list_of_images):
        if existing_target:
            raise NotImplementedError("Existing targets are not implemented")
        else:
            im = img.copy()
            targs = target_recognition(im, tpar, i_cam, cpar)

        targs.sort_y()
        # print(f"Camera {i_cam} detected {len(targs)} targets.")
        detections.append(targs)
        mc = MatchedCoords(targs, cpar, cals[i_cam])
        corrected.append(mc)

    return detections, corrected


def py_correspondences_proc_c(exp):
    """Provides correspondences"""
    frame = 123456789

    sorted_pos, sorted_corresp, num_targs = correspondences(
        exp.detections, exp.corrected, exp.cals, exp.vpar, exp.cpar
    )

    # img_base_names = [exp.spar.get_img_base_name(i) for i in range(exp.num_cams)]
    short_file_bases = exp.target_filenames
    print(f"short_file_bases: {short_file_bases}")
    _ensure_target_output_writable(short_file_bases)

    for i_cam in range(exp.num_cams):
        write_targets(exp.detections[i_cam], short_file_bases[i_cam], frame)

    print(f"Frame {frame} had {[s.shape[1] for s in sorted_pos]!r} correspondences.")

    return sorted_pos, sorted_corresp, num_targs


def py_determination_proc_c(
    num_cams: int,
    sorted_pos: List[np.ndarray],
    sorted_corresp: List[np.ndarray],
    corrected: List[MatchedCoords],
    cpar: ControlParams,
    vpar: VolumeParams,
    cals: List[Calibration],
) -> None:
    """Calculate 3D positions from 2D correspondences and save to file."""
    concatenated_pos = np.concatenate(sorted_pos, axis=1)
    concatenated_corresp = np.concatenate(sorted_corresp, axis=1)

    flat = np.array(
        [
            corr.get_by_pnrs(corresp)
            for corr, corresp in zip(corrected, concatenated_corresp)
        ]
    )

    pos, _ = point_positions(flat.transpose(1, 0, 2), cpar, cals, vpar)

    if num_cams < 4:
        print_corresp = -1 * np.ones((4, concatenated_corresp.shape[1]))
        print_corresp[: len(cals), :] = concatenated_corresp
    else:
        print_corresp = concatenated_corresp

    output_path = _prepare_output_path(
        f"{default_naming['corres'].decode()}.{DEFAULT_FRAME_NUM}"
    )

    print(f"Prepared {output_path} to write positions")

    try:
        with open(output_path, "w", encoding="utf-8") as rt_is:
            print(f"Opened {output_path}")
            rt_is.write(f"{pos.shape[0]}\n")
            for pix, pt in enumerate(pos):
                pt_args = (pix + 1,) + tuple(pt) + tuple(print_corresp[:, pix])
                rt_is.write("%4d %9.3f %9.3f %9.3f %4d %4d %4d %4d\n" % pt_args)
    except OSError as exc:
        _raise_output_write_error(output_path, exc)


def run_sequence_plugin(exp) -> None:
    """Load and run plugins for sequence processing."""
    plugin_dir = Path(os.getcwd()) / "plugins"
    print(f"Plugin directory: {plugin_dir}")

    # Check if plugin directory exists
    if not plugin_dir.exists():
        raise FileNotFoundError(f"Plugin directory not found: {plugin_dir}")

    if str(plugin_dir) not in sys.path:
        sys.path.append(str(plugin_dir))

    for filename in os.listdir(plugin_dir):
        if filename.endswith(".py") and filename != "__init__.py":
            plugin_name = filename[:-3]
            if plugin_name == exp.plugins.sequence_alg:
                try:
                    print(f"Loading plugin: {plugin_name}")
                    plugin = importlib.import_module(plugin_name)
                except ImportError as e:
                    print(f"Error loading {plugin_name}: {e}")
                    return

                if hasattr(plugin, "Sequence"):
                    print(f"Running sequence plugin: {exp.plugins.sequence_alg}")
                    try:
                        sequence = plugin.Sequence(exp=exp)
                        sequence.do_sequence()
                    except Exception as e:
                        print(f"Error running sequence plugin {plugin_name}: {e}")


def run_tracking_plugin(exp) -> None:
    """Load and run plugins for sequence processing."""
    plugin_dir = Path(os.getcwd()) / "plugins"
    print(f"Plugin directory: {plugin_dir}")

    # Check if plugin directory exists
    if not plugin_dir.exists():
        raise FileNotFoundError(f"Plugin directory not found: {plugin_dir}")

    if str(plugin_dir) not in sys.path:
        sys.path.append(str(plugin_dir))

    for filename in os.listdir(plugin_dir):
        if filename.endswith(".py") and filename != "__init__.py":
            plugin_name = filename[:-3]
            if plugin_name == exp.plugins.track_alg:
                try:
                    print(f"Loading plugin: {plugin_name}")
                    plugin = importlib.import_module(plugin_name)
                except ImportError as e:
                    print(f"Error loading {plugin_name}: {e}")
                    return

                if hasattr(plugin, "Tracking"):
                    print(f"Running tracking plugin: {exp.plugins.track_alg}")
                    try:
                        tracker = plugin.Tracking(exp=exp)
                        tracker.do_tracking()
                    except Exception as e:
                        print(f"Error running tracking plugin {plugin_name}: {e}")


def py_sequence_loop(exp) -> None:
    """Run a sequence of detection, stereo-correspondence, and determination.

    Args:
        exp: Either an Experiment object with pm attribute,
             or a MainGUI object with exp1.pm and cached parameter objects
    """

    # Handle both Experiment objects and MainGUI objects
    if hasattr(exp, "pm"):
        # Traditional experiment object
        pm = exp.pm
        num_cams = pm.num_cams
        cpar = exp.cpar
        spar = exp.spar
        vpar = exp.vpar
        tpar = exp.tpar
        cals = exp.cals
    elif hasattr(exp, "exp1") and hasattr(exp.exp1, "pm"):
        # MainGUI object - ensure parameter objects are initialized
        pm = exp.exp1.pm
        num_cams = exp.num_cams
        cpar = exp.cpar
        spar = exp.spar
        vpar = exp.vpar
        tpar = exp.tpar
        cals = exp.cals
    else:
        raise ValueError("Object must have either pm or exp1.pm attribute")

    existing_target = pm.get_parameter("pft_version").get("Existing_Target", False)

    first_frame = spar.get_first()
    last_frame = spar.get_last()
    # Generate short_file_bases once per experiment
    img_base_names = [spar.get_img_base_name(i) for i in range(num_cams)]
    short_file_bases = exp.target_filenames
    _ensure_target_output_writable(short_file_bases)

    for frame in range(first_frame, last_frame + 1):
        detections = []
        corrected = []
        for i_cam in range(num_cams):
            if existing_target:
                targs = read_targets(short_file_bases[i_cam], frame)
            else:
                imname = Path(img_base_names[i_cam] % frame)
                if not imname.exists():
                    raise FileNotFoundError(f"{imname} does not exist")
                else:
                    img = imread(imname)
                    if img.ndim > 2:
                        img = rgb2gray(img)
                    if img.dtype != np.uint8:
                        img = img_as_ubyte(img)
                if pm.get_parameter("ptv").get("negative", False):
                    print("Negative image")
                    img = negative(img)
                masking_params = pm.get_parameter("masking")
                if masking_params and masking_params.get("mask_flag", False):
                    try:
                        background_name = masking_params["mask_base_name"] % (i_cam + 1)
                        background = imread(background_name)
                        img = np.clip(img - background, 0, 255).astype(np.uint8)
                    except (ValueError, FileNotFoundError):
                        print("failed to read the mask")
                high_pass = simple_highpass(img, cpar)
                targs = target_recognition(high_pass, tpar, i_cam, cpar)

            if len(targs) > 0:
                targs.sort_y()

            detections.append(targs)
            matched_coords = MatchedCoords(targs, cpar, cals[i_cam])
            pos, _ = matched_coords.as_arrays()
            corrected.append(matched_coords)

        # AFter we finished all targs, we can move to correspondences
        sorted_pos, sorted_corresp, _ = correspondences(
            detections, corrected, cals, vpar, cpar
        )
        for i_cam in range(num_cams):
            write_targets(detections[i_cam], short_file_bases[i_cam], frame)
        print(
            "Frame "
            + str(frame)
            + " had "
            + repr([s.shape[1] for s in sorted_pos])
            + " correspondences."
        )
        sorted_pos = np.concatenate(sorted_pos, axis=1)
        sorted_corresp = np.concatenate(sorted_corresp, axis=1)
        flat = np.array(
            [
                corr.get_by_pnrs(corresp)
                for corr, corresp in zip(corrected, sorted_corresp)
            ]
        )
        pos, _ = point_positions(flat.transpose(1, 0, 2), exp.cpar, exp.cals, exp.vpar)
        if len(exp.cals) < 4:
            print_corresp = -1 * np.ones((4, sorted_corresp.shape[1]))
            print_corresp[: len(exp.cals), :] = sorted_corresp
        else:
            print_corresp = sorted_corresp

        output_path = _prepare_output_path(
            f"{default_naming['corres'].decode()}.{frame}"
        )
        try:
            with open(output_path, "w", encoding="utf8") as rt_is:
                rt_is.write(f"{pos.shape[0]}\n")
                for pix, pt in enumerate(pos):
                    pt_args = (pix + 1,) + tuple(pt) + tuple(print_corresp[:, pix])
                    rt_is.write("%4d %9.3f %9.3f %9.3f %4d %4d %4d %4d\n" % pt_args)
        except OSError as exc:
            _raise_output_write_error(output_path, exc)


def py_sequence_loop_python(exp) -> None:
    """Run detection, stereo-correspondence, and determination using the Python algorithms engine.

    Produces the same output files as py_sequence_loop (optv engine) so that
    results can be compared byte-for-byte.

    Args:
        exp: Same ProcessingExperiment object as py_sequence_loop expects.
    """
    from algorithms.segmentation import target_recognition as alg_target_recognition
    from algorithms.correspondences import (
        MatchedCoords as AlgMatchedCoords,
        correspondences as alg_correspondences,
    )
    from algorithms.orientation import point_positions as alg_point_positions
    from algorithms.track import default_naming as alg_default_naming
    from algorithms.parameters import ControlPar, VolumePar, TargetPar, MultimediaPar
    from algorithms.calibration import Calibration as AlgCalibration
    from algorithms.tracking_frame_buf import Frame, Target, read_targets

    # Handle both Experiment objects and MainGUI objects
    if hasattr(exp, "pm"):
        pm = exp.pm
        num_cams = pm.num_cams
        cpar = exp.cpar
        spar = exp.spar
        vpar = exp.vpar
        tpar = exp.tpar
        cals = exp.cals
    elif hasattr(exp, "exp1") and hasattr(exp.exp1, "pm"):
        pm = exp.exp1.pm
        num_cams = exp.num_cams
        cpar = exp.cpar
        spar = exp.spar
        vpar = exp.vpar
        tpar = exp.tpar
        cals = exp.cals
    else:
        raise ValueError("Object must have either pm or exp1.pm attribute")

    existing_target = pm.get_parameter("pft_version").get("Existing_Target", False)

    first_frame = spar.get_first()
    last_frame = spar.get_last()
    img_base_names = [spar.get_img_base_name(i) for i in range(num_cams)]
    short_file_bases = exp.target_filenames
    _ensure_target_output_writable(short_file_bases)

    # Convert optv ControlParams to algorithms ControlPar
    cpar_py = ControlPar(num_cams=num_cams)
    imx, imy = cpar.get_image_size()
    cpar_py.imx = imx
    cpar_py.imy = imy
    pix_x, pix_y = cpar.get_pixel_size()
    cpar_py.pix_x = pix_x
    cpar_py.pix_y = pix_y
    if hasattr(cpar, "get_hp_flag"):
        cpar_py.hp_flag = cpar.get_hp_flag()
    if hasattr(cpar, "get_allCam_flag"):
        cpar_py.all_cam_flag = cpar.get_allCam_flag()
    if hasattr(cpar, "get_tiff_flag"):
        cpar_py.tiff_flag = cpar.get_tiff_flag()
    if hasattr(cpar, "get_chfield"):
        cpar_py.chfield = cpar.get_chfield()
    # Copy multimedia params
    if hasattr(cpar, "get_multimedia_params"):
        optv_mm = cpar.get_multimedia_params()
        if hasattr(optv_mm, "get_n1"):
            cpar_py.mm.n1 = optv_mm.get_n1()
        if hasattr(optv_mm, "get_n3"):
            cpar_py.mm.n3 = optv_mm.get_n3()
        if hasattr(optv_mm, "get_nlay"):
            nlay = optv_mm.get_nlay()
            cpar_py.mm.nlay = nlay
        if hasattr(optv_mm, "get_d"):
            cpar_py.mm.d = list(optv_mm.get_d())
        if hasattr(optv_mm, "get_n2"):
            cpar_py.mm.n2 = list(optv_mm.get_n2())

    # Convert optv VolumeParams to algorithms VolumePar
    vpar_py = VolumePar()
    if hasattr(vpar, "get_X_lay"):
        try:
            vpar_py.x_lay = list(vpar.get_X_lay())
        except Exception:
            pass
    if hasattr(vpar, "get_Zmin_lay"):
        try:
            vpar_py.z_min_lay = list(vpar.get_Zmin_lay())
        except Exception:
            pass
    if hasattr(vpar, "get_Zmax_lay"):
        try:
            vpar_py.z_max_lay = list(vpar.get_Zmax_lay())
        except Exception:
            pass
    for attr in ("cn", "cnx", "cny", "csumg", "eps0", "corrmin"):
        getter = f"get_{attr}"
        if hasattr(vpar, getter):
            try:
                setattr(vpar_py, attr, getattr(vpar, getter)())
            except Exception:
                pass

    # Convert optv TargetParams to algorithms TargetPar
    tpar_py = TargetPar()
    if hasattr(tpar, "get_grey_thresholds"):
        try:
            tpar_py.gvthresh = list(tpar.get_grey_thresholds())
        except Exception:
            pass
    if hasattr(tpar, "get_max_discontinuity"):
        try:
            tpar_py.discont = tpar.get_max_discontinuity()
        except Exception:
            pass
    if hasattr(tpar, "get_pixel_count_bounds"):
        try:
            lo, hi = tpar.get_pixel_count_bounds()
            tpar_py.nnmin = lo
            tpar_py.nnmax = hi
        except Exception:
            pass
    if hasattr(tpar, "get_xsize_bounds"):
        try:
            lo, hi = tpar.get_xsize_bounds()
            tpar_py.nxmin = lo
            tpar_py.nxmax = hi
        except Exception:
            pass
    if hasattr(tpar, "get_ysize_bounds"):
        try:
            lo, hi = tpar.get_ysize_bounds()
            tpar_py.nymin = lo
            tpar_py.nymax = hi
        except Exception:
            pass
    if hasattr(tpar, "get_min_sum_grey"):
        try:
            tpar_py.sumg_min = tpar.get_min_sum_grey()
        except Exception:
            pass
    if hasattr(tpar, "get_cross_size"):
        try:
            tpar_py.cr_sz = tpar.get_cross_size()
        except Exception:
            pass
    if hasattr(tpar, "get_grey"):
        try:
            tpar_py.set_grey(tpar.get_grey())
        except Exception:
            pass

    # Convert optv Calibrations to algorithms Calibrations
    cals_py = []
    for cal in cals:
        py_cal = AlgCalibration()
        if hasattr(cal, "get_pos"):
            py_cal.set_pos(cal.get_pos())
        if hasattr(cal, "get_angles"):
            py_cal.set_angles(cal.get_angles())
        if hasattr(cal, "get_primary_point"):
            pp = cal.get_primary_point()
            py_cal.set_primary_point(pp)
        if hasattr(cal, "get_radial_distortion"):
            rd = cal.get_radial_distortion()
            py_cal.set_radial_distortion(rd)
        if hasattr(cal, "get_decentering"):
            dc = cal.get_decentering()
            py_cal.set_decentering(dc)
        if hasattr(cal, "get_affine"):
            at = cal.get_affine()
            py_cal.set_affine_trans(at)
        if hasattr(cal, "get_glass_vec"):
            gv = cal.get_glass_vec()
            py_cal.set_glass_vec(gv)
        cals_py.append(py_cal)

    for frame in range(first_frame, last_frame + 1):
        detections = []
        corrected = []
        for i_cam in range(num_cams):
            if existing_target:
                targs = read_targets(short_file_bases[i_cam], frame)
            else:
                imname = Path(img_base_names[i_cam] % frame)
                if not imname.exists():
                    raise FileNotFoundError(f"{imname} does not exist")
                else:
                    img = imread(imname)
                    if img.ndim > 2:
                        img = rgb2gray(img)
                    if img.dtype != np.uint8:
                        img = img_as_ubyte(img)
                if pm.get_parameter("ptv").get("negative", False):
                    print("Negative image")
                    img = negative(img)
                masking_params = pm.get_parameter("masking")
                if masking_params and masking_params.get("mask_flag", False):
                    try:
                        background_name = masking_params["mask_base_name"] % (i_cam + 1)
                        background = imread(background_name)
                        img = np.clip(img - background, 0, 255).astype(np.uint8)
                    except (ValueError, FileNotFoundError):
                        print("failed to read the mask")
                high_pass = simple_highpass(img, cpar)
                targs = alg_target_recognition(high_pass, tpar_py, i_cam, cpar_py)

            if len(targs) > 0:
                if hasattr(targs, "sort_y"):
                    targs.sort_y()
                else:
                    targs.sort(key=lambda t: t.y)

            detections.append(targs)
            matched_coords = AlgMatchedCoords(targs, cpar_py, cals_py[i_cam])
            pos, _ = matched_coords.as_arrays()
            corrected.append(matched_coords)

        # Build a Frame for algorithms correspondences
        frm = Frame(num_cams=num_cams)
        for i_cam in range(num_cams):
            n = len(detections[i_cam])
            frm.num_targets[i_cam] = n
            for tnum in range(n):
                t = detections[i_cam][tnum]
                frm.targets[i_cam][tnum].pnr = t.pnr if hasattr(t, "pnr") else tnum
                frm.targets[i_cam][tnum].tnr = -1
                frm.targets[i_cam][tnum].x = t.x if hasattr(t, "x") else 0
                frm.targets[i_cam][tnum].y = t.y if hasattr(t, "y") else 0
                frm.targets[i_cam][tnum].n = t.n if hasattr(t, "n") else 0
                frm.targets[i_cam][tnum].nx = t.nx if hasattr(t, "nx") else 0
                frm.targets[i_cam][tnum].ny = t.ny if hasattr(t, "ny") else 0
                frm.targets[i_cam][tnum].sumg = t.sumg if hasattr(t, "sumg") else 0

        match_counts = [0] * 4  # [4-cam, 3-cam, 2-cam, total]
        con = alg_correspondences(
            frm, corrected, vpar_py, cpar_py, cals_py, match_counts
        )
        # Convert n_tupel recarray to optv-style sorted_pos, sorted_corresp
        total = match_counts[3] if len(match_counts) > 3 else 0
        if total > 0:
            valid = con[:total]
            # Sort by correlation descending (highest quality first)
            order = np.argsort(-valid.corr)
            valid = valid[order]
            corresp = np.array([list(row.p) for row in valid]).T  # (num_cams, N)
            sorted_corresp = [corresp]
            sorted_pos = [np.zeros((3, corresp.shape[1]))]
        else:
            sorted_corresp = [np.zeros((num_cams, 0), dtype=int)]
            sorted_pos = [np.zeros((3, 0))]

        # Write targets
        for i_cam in range(num_cams):
            targs = detections[i_cam]
            output_path = _prepare_output_path(
                f"{short_file_bases[i_cam]}.{frame:04d}_targets"
            )
            try:
                with open(output_path, "w", encoding="utf8") as f:
                    f.write(f"{len(targs)}\n")
                    for t in targs:
                        pnr = t.pnr if hasattr(t, "pnr") else 0
                        x = t.x if hasattr(t, "x") else 0.0
                        y = t.y if hasattr(t, "y") else 0.0
                        n = t.n if hasattr(t, "n") else 0
                        nx = t.nx if hasattr(t, "nx") else 0
                        ny = t.ny if hasattr(t, "ny") else 0
                        sumg = t.sumg if hasattr(t, "sumg") else 0
                        tnr = t.tnr if hasattr(t, "tnr") else -1
                        f.write(
                            f"{pnr:4d} {x:9.4f} {y:9.4f} {n:5d} {nx:5d} "
                            f"{ny:5d} {sumg:5d} {tnr:5d}\n"
                        )
            except OSError as exc:
                _raise_output_write_error(output_path, exc)

        concatenated_corresp = np.concatenate(sorted_corresp, axis=1)
        concatenated_pos = np.concatenate(sorted_pos, axis=1)

        # Look up corrected coords for correspondence matches and compute 3D positions
        if concatenated_corresp.shape[1] > 0:
            flat = np.array(
                [
                    corr.get_by_pnrs(corresp)
                    for corr, corresp in zip(corrected, concatenated_corresp)
                ]
            )
            pos, _ = alg_point_positions(
                flat.transpose(1, 0, 2), cpar_py.mm, cals_py, vpar_py
            )
        else:
            pos = np.zeros((0, 3))

        if num_cams < 4:
            print_corresp = -1 * np.ones((4, concatenated_corresp.shape[1]), dtype=int)
            print_corresp[:num_cams, :] = concatenated_corresp
        else:
            print_corresp = concatenated_corresp

        corres_path = alg_default_naming["corres"]
        output_path = _prepare_output_path(f"{corres_path}.{frame}")
        try:
            with open(output_path, "w", encoding="utf8") as rt_is:
                rt_is.write(f"{pos.shape[0]}\n")
                for pix, pt in enumerate(pos):
                    pt_args = (pix + 1,) + tuple(pt) + tuple(print_corresp[:, pix])
                    rt_is.write("%4d %9.3f %9.3f %9.3f %4d %4d %4d %4d\n" % pt_args)
        except OSError as exc:
            _raise_output_write_error(output_path, exc)

        print(
            "Frame "
            + str(frame)
            + " had "
            + repr([s.shape[1] for s in sorted_pos])
            + " correspondences (python engine)."
        )


def py_trackcorr_init(exp):
    """Reads all the necessary stuff into Tracker"""

    # Generate short_file_bases once per experiment
    # img_base_names = [exp.spar.get_img_base_name(i) for i in range(exp.cpar.get_num_cams())]
    # exp.short_file_bases = exp.target_filenames
    target_filenames = getattr(exp, "target_filenames", None)
    if target_filenames is None:
        target_filenames = []

    try:
        target_filenames = list(target_filenames)
    except TypeError:
        target_filenames = []

    if not target_filenames:
        img_base_names = [
            exp.spar.get_img_base_name(i) for i in range(exp.cpar.get_num_cams())
        ]
        target_filenames = generate_short_file_bases(img_base_names)
        exp.target_filenames = target_filenames

    for cam_id, short_name in enumerate(target_filenames):
        # print(f"Setting tracker image base name for cam {cam_id+1}: {Path(short_name).resolve()}")
        exp.spar.set_img_base_name(cam_id, str(Path(short_name).resolve()) + ".")

    # print("exp.spar.img_base_names:", [exp.spar.get_img_base_name(i) for i in range(exp.cpar.get_num_cams())])

    # print(
    #     exp.track_par.get_dvxmin(), exp.track_par.get_dvxmax(),
    #     exp.track_par.get_dvymin(), exp.track_par.get_dvymax(),
    #     exp.track_par.get_dvzmin(), exp.track_par.get_dvzmax(),
    #     exp.track_par.get_dangle(), exp.track_par.get_dacc(),
    #     exp.track_par.get_add()
    # )

    print("Initializing Tracker with parameters:")

    # Get parameters from experiment object
    cpar = exp.cpar
    vpar = exp.vpar
    track_par = exp.track_par
    spar = exp.spar
    cals = exp.cals

    # Import engine-aware Tracker based on current engine setting
    from openptv2.engine import get_engine

    engine = get_engine()

    if engine == "python":
        from algorithms.track import Tracker as PythonTracker
        from algorithms.parameters_adapter import (
            ControlParams,
            VolumeParams,
            SequenceParams,
        )
        from algorithms.parameters import TrackPar

        # Convert optv parameters to Python adapter format
        cpar_py = ControlParams(cpar.get_num_cams())
        cpar_py._impl = cpar

        # Copy required attributes from optv object to adapter
        if hasattr(cpar, "get_num_cams"):
            cpar_py._num_cams = cpar.get_num_cams()
        if hasattr(cpar, "imx"):
            cpar_py._imx = cpar.imx
        if hasattr(cpar, "imy"):
            cpar_py._imy = cpar.imy
        if hasattr(cpar, "mm"):
            cpar_py._mm = cpar.mm
        if hasattr(cpar, "pix_x"):
            cpar_py._pix_x = cpar.pix_x
        if hasattr(cpar, "pix_y"):
            cpar_py._pix_y = cpar.pix_y

        if getattr(cpar_py, "pix_x", 0.0) == 0.0 or getattr(cpar_py, "pix_y", 0.0) == 0.0:
            try:
                ptv_params = exp.pm.get_parameter("ptv")
            except Exception:
                ptv_params = {}
            if getattr(cpar_py, "pix_x", 0.0) == 0.0:
                cpar_py._pix_x = ptv_params.get("pix_x", 1.0)
            if getattr(cpar_py, "pix_y", 0.0) == 0.0:
                cpar_py._pix_y = ptv_params.get("pix_y", 1.0)

        # Create VolumePar from optv VolumeParams
        from algorithms.parameters import VolumePar

        try:
            x_lay = list(vpar.get_X_lay()) if hasattr(vpar, "get_X_lay") else []
        except:
            x_lay = []

        try:
            z_min_lay = (
                list(vpar.get_Zmin_lay()) if hasattr(vpar, "get_Zmin_lay") else []
            )
        except:
            z_min_lay = []

        try:
            z_max_lay = (
                list(vpar.get_Zmax_lay()) if hasattr(vpar, "get_Zmax_lay") else []
            )
        except:
            z_max_lay = []

        vpar_py = VolumePar(
            x_lay=x_lay,
            z_min_lay=z_min_lay,
            z_max_lay=z_max_lay,
            cn=vpar.get_cn() if hasattr(vpar, "get_cn") else 0,
            cnx=vpar.get_cnx() if hasattr(vpar, "get_cnx") else 0,
            cny=vpar.get_cny() if hasattr(vpar, "get_cny") else 0,
            csumg=vpar.get_csumg() if hasattr(vpar, "get_csumg") else 0,
            eps0=vpar.get_eps0() if hasattr(vpar, "get_eps0") else 0,
            corrmin=vpar.get_corrmin() if hasattr(vpar, "get_corrmin") else 0,
        )

        # Convert track_par to Python format
        tpar_py = TrackPar(
            dvxmin=track_par.get_dvxmin(),
            dvxmax=track_par.get_dvxmax(),
            dvymax=track_par.get_dvymax(),
            dvymin=track_par.get_dvymin(),
            dvzmin=track_par.get_dvzmin(),
            dvzmax=track_par.get_dvzmax(),
            dacc=track_par.get_dacc(),
            dangle=track_par.get_dangle(),
            add=track_par.get_add(),
        )

        # Create a Python-compatible sequence parameters object
        from algorithms.parameters import SequencePar

        print(f"[DEBUG] spar type: {type(spar)}")
        print(f"[DEBUG] cpar.get_num_cams(): {cpar.get_num_cams()}")

        # Get num_cams from cpar (not spar, since optv SequenceParams doesn't have get_num_cams)
        num_cams = cpar.get_num_cams()

        img_base_list = []
        for i in range(num_cams):
            try:
                base_name = spar.get_img_base_name(i)
                img_base_list.append(base_name)
                print(f"[DEBUG] get_img_base_name({i}): {base_name}")
            except Exception as e:
                print(f"[DEBUG] get_img_base_name({i}) error: {e}")
                img_base_list.append("")

        print(f"[DEBUG] img_base_list: {img_base_list}")
        print(f"[DEBUG] spar.get_first(): {spar.get_first()}")
        print(f"[DEBUG] spar.get_last(): {spar.get_last()}")

        spar_py = SequencePar(
            img_base_name=img_base_list, first=spar.get_first(), last=spar.get_last()
        )

        # Convert optv Calibration objects to Python Calibration objects
        from algorithms.calibration import Calibration as PythonCalibration

        cals_py = []
        for cal in cals:
            # Extract parameters from optv calibration
            try:
                # Try to get interior parameters
                if hasattr(cal, "get_int_par"):
                    int_par = cal.get_int_par()
                elif hasattr(cal, "int_par"):
                    int_par = cal.int_par
                else:
                    # Create default interior
                    int_par = None

                # Try to get exterior parameters
                if hasattr(cal, "get_ext_par"):
                    ext_par = cal.get_ext_par()
                elif hasattr(cal, "ext_par"):
                    ext_par = cal.ext_par
                else:
                    ext_par = None

                # Try to get additional parameters
                if hasattr(cal, "get_add_par"):
                    add_par = cal.get_add_par()
                elif hasattr(cal, "add_par"):
                    add_par = cal.add_par
                else:
                    add_par = None

                # Try to get glass parameters
                if hasattr(cal, "get_glass_par"):
                    glass_par = cal.get_glass_par()
                elif hasattr(cal, "glass_par"):
                    glass_par = cal.glass_par
                else:
                    glass_par = None

                py_cal = PythonCalibration(
                    ext_par=ext_par,
                    int_par=int_par,
                    glass_par=glass_par,
                    added_par=add_par,
                )
                cals_py.append(py_cal)
            except Exception as e:
                print(f"[DEBUG] Error converting calibration: {e}")
                # Fallback: create a basic calibration
                cals_py.append(PythonCalibration())

        print(f"[DEBUG] Converted {len(cals_py)} calibrations")

        print(f"[ENGINE] Using Python engine: {PythonTracker}")

        tracker = PythonTracker(
            cpar_py, vpar_py, tpar_py, spar_py, cals_py, default_naming
        )
    else:
        from optv.tracker import Tracker as OptvTracker

        print(f"[ENGINE] Using optv engine: {OptvTracker}")
        tracker = OptvTracker(cpar, vpar, track_par, spar, cals, default_naming)

    return tracker


# ------- Utilities ----------#


def py_get_pix(
    x: List[List[int]], y: List[List[int]]
) -> Tuple[List[List[int]], List[List[int]]]:
    """Get target positions (stub function)."""
    return x, y


def py_calibration(selection, exp):
    """Calibration

    Args:
        selection: Calibration selection type
        exp: Either an Experiment object with pm attribute,
             or a MainGUI object with exp1.pm and cached parameter objects
    """
    if selection == 1:
        pass

    if selection == 2:
        pass

    if selection == 9:
        pass

    if selection == 12:
        """ Calibration with dumbbell ."""
        return calib_dumbbell(exp)

    if selection == 10:
        """ Calibration with particles ."""

        return calib_particles(exp)


def write_targets(targets: TargetArray, short_file_base: str, frame: int) -> bool:
    """Write targets to a file."""
    output_path = _prepare_output_path(f"{short_file_base}.{frame:04d}_targets")
    num_targets = len(targets)
    success = False
    if num_targets == 0:
        try:
            with open(output_path, "w", encoding="utf-8") as file:
                file.write("0\n")
        except OSError as exc:
            _raise_output_write_error(output_path, exc)
        return True  # No targets to write, but file created successfully

    try:
        target_arr = np.array(
            [
                ([t.pnr(), *t.pos(), *t.count_pixels(), t.sum_grey_value(), t.tnr()])
                for t in targets
            ]
        )
        np.savetxt(
            output_path,
            target_arr,
            fmt="%4d %9.4f %9.4f %5d %5d %5d %5d %5d",
            header=f"{num_targets}",
            comments="",
        )
        success = True
    except OSError as exc:
        _raise_output_write_error(output_path, exc)
    return success


def read_targets(short_file_base: str, frame: int) -> TargetArray:
    """Read targets from a file."""
    filename = f"{short_file_base}.{frame:04d}_targets"
    print(f" Reading targets from: filename: {filename}")

    if not os.path.exists(filename):
        raise FileNotFoundError(f"Targets file does not exist: {filename}")

    try:
        with open(filename, "r", encoding="utf-8") as file:
            num_targets = int(file.readline().strip())
            targs = TargetArray(num_targets)

            for tix in range(num_targets):
                line = file.readline().strip().split()

                if len(line) != 8:
                    raise ValueError(f"Bad format for file: {filename}")

                targ = targs[tix]
                targ.set_pnr(int(line[0]))
                targ.set_pos([float(line[1]), float(line[2])])
                targ.set_pixel_counts(int(line[3]), int(line[4]), int(line[5]))
                targ.set_sum_grey_value(int(line[6]))
                targ.set_tnr(int(line[7]))

    except IOError as err:
        print(f"Can't open targets file: {filename}")
        raise err

    return targs


def extract_cam_ids(file_bases: list[str]) -> list[int]:
    """
    Given a list of file base strings, extract the camera identification number from each.
    The camera id is the digit or number that is the main difference between the names,
    typically close to 'cam', 'c', 'img', etc.
    Returns a list of integers, one for each file base.
    """
    # Try to find all numbers in each string, and their context
    if not file_bases:
        raise ValueError("file_bases list is empty")

    # If input is a string, convert to a list
    if isinstance(file_bases, str):
        file_bases = [file_bases]

    # Remove frame number patterns like %d, %04d, etc.
    clean_bases = [re.sub(r"%0?\d*d", "", s) for s in file_bases]
    file_bases = clean_bases

    # Helper to extract all (number, context) pairs from a string
    def extract_number_context(s):
        # Find all numbers with up to 4 chars before and after
        matches = []
        for m in re.finditer(r"([a-zA-Z]{0,4})?(\d+)", s):
            prefix = m.group(1) or ""
            number = m.group(2)
            start = m.start(2)
            matches.append((number, prefix.lower(), start))
        return matches

    # Build a list of all numbers and their context for each string
    all_matches = [extract_number_context(s) for s in file_bases]

    # Transpose to group by position in the list
    # Find which number position varies the most across the list
    # (i.e., the one that is different between the names)
    candidate_indices = []
    maxlen = max(len(m) for m in all_matches) if all_matches else 0
    for idx in range(maxlen):
        nums = []
        for m in all_matches:
            if len(m) > idx:
                nums.append(m[idx][0])
            else:
                nums.append(None)
        # Count unique numbers (ignoring None)
        unique = set(n for n in nums if n is not None)
        candidate_indices.append((idx, len(unique)))

    # Pick the index with the most unique numbers (should be the cam id)
    candidate_indices.sort(key=lambda x: -x[1])
    if not candidate_indices or candidate_indices[0][1] <= 1:
        # fallback: just use the last number in each string
        fallback_ids = []
        for idx, s in enumerate(file_bases):
            found = re.findall(r"(\d+)", s)
            if found:
                fallback_ids.append(int(found[-1]))
            else:
                # fallback to default SHORT_BASE+idx+1
                fallback_ids.append(None)
        # If any fallback_ids are None, use default SHORT_BASE+idx+1
        if any(x is None for x in fallback_ids):
            fallback_ids = list(range(1, len(file_bases) + 1))
            print("fall back to default list", fallback_ids)

        return fallback_ids

    cam_idx = candidate_indices[0][0]

    # Now, for each string, get the number at cam_idx
    cam_ids = []
    for idx, m in enumerate(all_matches):
        if len(m) > cam_idx:
            cam_ids.append(int(m[cam_idx][0]))
        else:
            # fallback: last number or default SHORT_BASE+idx+1
            nums = re.findall(r"(\d+)", "".join([x[0] for x in m]))
            if nums:
                cam_ids.append(int(nums[-1]))
            else:
                cam_ids.append(f"{SHORT_BASE}{idx + 1}")
    # If any cam_ids are not int, fallback to default SHORT_BASE+idx+1
    if any(not isinstance(x, int) for x in cam_ids):
        cam_ids = list(range(1, len(file_bases) + 1))
        print("Fallback to default list {cam_ids}")

    return cam_ids


def generate_short_file_bases(img_base_names: List[str]) -> List[str]:
    """
    Given a list of image base names (full paths) for all cameras, generate a list of short_file_base strings for targets.
    The short file base will be in the same directory as the original, but with the filename replaced by SHORT_BASE + index.
    """
    ids = extract_cam_ids(img_base_names)
    short_bases = []
    for idx, full_path in enumerate(img_base_names):
        parent = Path(full_path).parent
        short_name = f"{SHORT_BASE}{ids[idx]}"
        short_bases.append(str(parent / short_name))
    return short_bases


def read_rt_is_file(filename) -> List[List[float]]:
    """Read data from an rt_is file and return the parsed values."""
    try:
        with open(filename, "r", encoding="utf-8") as file:
            num_rows = int(file.readline().strip())
            if num_rows == 0:
                raise ValueError("Failed to read the number of rows")

            data = []
            for _ in range(num_rows):
                line = file.readline().strip()
                if not line:
                    break

                values = line.split()
                if len(values) != 8:
                    raise ValueError("Incorrect number of values in line")

                x = float(values[1])
                y = float(values[2])
                z = float(values[3])
                p1 = int(values[4])
                p2 = int(values[5])
                p3 = int(values[6])
                p4 = int(values[7])

                data.append([x, y, z, p1, p2, p3, p4])

            return data

    except IOError as e:
        print(f"Can't open ascii file: {filename}")
        raise e


def full_scipy_calibration(
    cal: Calibration, XYZ: np.ndarray, targs: TargetArray, cpar: ControlParams, flags=[]
):
    """Full calibration using scipy.optimize"""
    from optv.transforms import convert_arr_metric_to_pixel
    from optv.imgcoord import image_coordinates

    def _residuals_k(x, cal, XYZ, xy, cpar):
        cal.set_radial_distortion(x)
        targets = convert_arr_metric_to_pixel(
            image_coordinates(XYZ, cal, cpar.get_multimedia_params()), cpar
        )
        xyt = np.array([t.pos() if t.pnr() != -999 else [np.nan, np.nan] for t in xy])
        residuals = np.nan_to_num(xyt - targets)
        return np.sum(residuals**2)

    def _residuals_p(x, cal, XYZ, xy, cpar):
        cal.set_decentering(x)
        targets = convert_arr_metric_to_pixel(
            image_coordinates(XYZ, cal, cpar.get_multimedia_params()), cpar
        )
        xyt = np.array([t.pos() if t.pnr() != -999 else [np.nan, np.nan] for t in xy])
        residuals = np.nan_to_num(xyt - targets)
        return np.sum(residuals**2)

    def _residuals_s(x, cal, XYZ, xy, cpar):
        cal.set_affine_trans(x)
        targets = convert_arr_metric_to_pixel(
            image_coordinates(XYZ, cal, cpar.get_multimedia_params()), cpar
        )
        xyt = np.array([t.pos() if t.pnr() != -999 else [np.nan, np.nan] for t in xy])
        residuals = np.nan_to_num(xyt - targets)
        return np.sum(residuals**2)

    def _residuals_combined(x, cal, XYZ, xy, cpar):
        cal.set_radial_distortion(x[:3])
        cal.set_decentering(x[3:5])
        cal.set_affine_trans(x[5:])

        targets = convert_arr_metric_to_pixel(
            image_coordinates(XYZ, cal, cpar.get_multimedia_params()), cpar
        )
        xyt = np.array([t.pos() if t.pnr() != -999 else [np.nan, np.nan] for t in xy])
        residuals = np.nan_to_num(xyt - targets)
        return residuals

    if any(flag in flags for flag in ["k1", "k2", "k3"]):
        sol = minimize(
            _residuals_k,
            cal.get_radial_distortion(),
            args=(cal, XYZ, targs, cpar),
            method="Nelder-Mead",
            tol=1e-11,
            options={"disp": True},
        )
        radial = sol.x
        cal.set_radial_distortion(radial)
    else:
        radial = cal.get_radial_distortion()

    if any(flag in flags for flag in ["p1", "p2"]):
        sol = minimize(
            _residuals_p,
            cal.get_decentering(),
            args=(cal, XYZ, targs, cpar),
            method="Nelder-Mead",
            tol=1e-11,
            options={"disp": True},
        )
        decentering = sol.x
        cal.set_decentering(decentering)
    else:
        decentering = cal.get_decentering()

    if any(flag in flags for flag in ["scale", "shear"]):
        sol = minimize(
            _residuals_s,
            cal.get_affine(),
            args=(cal, XYZ, targs, cpar),
            method="Nelder-Mead",
            tol=1e-11,
            options={"disp": True},
        )
        affine = sol.x
        cal.set_affine_trans(affine)

    else:
        affine = cal.get_affine()

    residuals = _residuals_combined(
        np.r_[radial, decentering, affine], cal, XYZ, targs, cpar
    )

    residuals /= 100

    return residuals


"""
Perform dumbbell calibration from existing target files, using a subset of
the camera set, assuming some cameras are known to have moved and some to have
remained relatively static (but we can alternate on subsequent runs).

Created on Tue Dec 15 13:39:40 2015
@author: yosef

Modified for PyPTV on 2025-08-01
@author: alexlib
"""

# These readers should go in a nice module, but I wait on Max to finish the
# proper bindings.


def dumbbell_target_func(targets, cpar, calibs, db_length, db_weight):
    """
    Calculate the ray convergence error for a set of targets and calibrations.

    Arguments:
    targets : np.ndarray
        Array of shape (num_cams, num_targets, 2), where num_cams is the number of cameras,
        num_targets is the total number of dumbbell endpoints (should be even, typically 2 per frame),
        and 2 corresponds to the (x, y) metric coordinates for each target in each camera.
    cpar : ControlParams
        A ControlParams object describing the overall setting.
    calibs : list of Calibration
        An array of per-camera Calibration objects.
    db_length : float
        Expected distance between two dumbbell points.
    db_weight : float
        Weight of the distance error in the target function.

    Returns:
    float
        The weighted ray convergence + length error measure.
    """
    from optv.orientation import multi_cam_point_positions

    num_cams = cpar.get_num_cams()
    num_targs = targets.shape[1]
    multimed_pars = cpar.get_multimedia_params()

    # Prepare the result arrays
    res = [np.zeros((num_cams, 3)) for _ in range(2)]
    res_current = None
    dtot = 0.0
    len_err_tot = 0.0
    dist = 0.0

    # Iterate over pairs of targets
    if num_targs % 2 != 0:
        raise ValueError("Number of targets must be even for dumbbell calibration")

    # Process each target pair
    for pt in range(0, num_targs, 2):
        # For each pair of targets (dumbbell ends)
        # Get their 2D positions in all cameras for this pair
        pair_targets = targets[:, pt : pt + 2, :]  # shape: (num_cams, 2, pos)
        # Compute their 3D positions using all cameras
        # Each column: [cam1_t1, cam2_t1, ..., camN_t1], [cam1_t2, ..., camN_t2]
        # So we need to transpose to (2, num_cams, pos)
        pair_targets = pair_targets.transpose(1, 0, 2)  # shape: (2, num_cams, pos)
        # Get 3D positions for each end
        xyz1, err1 = multi_cam_point_positions(
            pair_targets[0, np.newaxis], cpar, calibs
        )
        xyz2, err2 = multi_cam_point_positions(
            pair_targets[1, np.newaxis], cpar, calibs
        )
        # xyz1, xyz2 are (1, 3) arrays (single point)
        # Compute the distance between the two ends
        dist = np.linalg.norm(xyz1[0] - xyz2[0])
        # Accumulate squared length error for smooth objective
        len_err_tot += (dist - db_length) ** 2
        # Accumulate the ray convergence error (sum of distances from rays to intersection)
        # Use the error returned by point_positions
        dtot += err1 + err2

    # Calculate the total error
    len_err_tot /= 2.0  # since we counted pairs, divide by 2

    # Calculate the total error as a weighted sum of ray convergence and length error
    dtot /= num_targs / 2.0  # average over pairs
    if db_length <= 0:
        raise ValueError("Dumbbell length must be positive")

    if db_weight < 0:
        raise ValueError("Dumbbell weight must be non-negative")

    # Return the total error
    return dtot + db_weight * len_err_tot / (num_targs / 2.0)


def dumbbell_target_residuals(targets, cpar, calibs, db_length, db_weight):
    """Return residuals per target pair for least-squares optimization."""
    from optv.orientation import multi_cam_point_positions

    num_targs = targets.shape[1]
    if num_targs % 2 != 0:
        raise ValueError("Number of targets must be even for dumbbell calibration")
    if db_length <= 0:
        raise ValueError("Dumbbell length must be positive")
    if db_weight < 0:
        raise ValueError("Dumbbell weight must be non-negative")

    residuals = []
    for pt in range(0, num_targs, 2):
        pair_targets = targets[:, pt : pt + 2, :].transpose(1, 0, 2)
        xyz1, err1 = multi_cam_point_positions(
            pair_targets[0, np.newaxis], cpar, calibs
        )
        xyz2, err2 = multi_cam_point_positions(
            pair_targets[1, np.newaxis], cpar, calibs
        )
        dist = np.linalg.norm(xyz1[0] - xyz2[0])
        residuals.append(float(err1))
        residuals.append(float(err2))
        if db_weight > 0:
            residuals.append(np.sqrt(db_weight) * (dist - db_length))

    residuals = np.asarray(residuals, dtype=float)
    return np.nan_to_num(residuals, nan=1e6, posinf=1e6, neginf=-1e6)


def dumbbell_ba_residuals(
    calib_vec,
    targets,
    cpar,
    calibs,
    active_cams,
    db_length,
    db_weight,
    pos_scale=1.0,
):
    """Bundle adjustment residuals for dumbbell calibration.

    calib_vec packs active camera extrinsics and per-frame 3D endpoints.
    targets is shaped (num_cams, num_frames, 2, 2) in metric coordinates.
    """
    from optv.imgcoord import image_coordinates

    if db_length <= 0:
        raise ValueError("Dumbbell length must be positive")
    if db_weight < 0:
        raise ValueError("Dumbbell weight must be non-negative")

    num_cams, num_frames, num_pts, _ = targets.shape
    if num_pts != 2:
        raise ValueError("Targets must contain exactly 2 points per frame")

    active_cams = np.asarray(active_cams, dtype=bool)
    num_active = int(np.sum(active_cams))
    cam_params_len = num_active * 6
    if calib_vec.shape[0] < cam_params_len:
        raise ValueError("calib_vec too short for active camera parameters")

    calib_pars = calib_vec[:cam_params_len].reshape(-1, 2, 3)

    ptr = 0
    for cam, cal in enumerate(calibs):
        if not active_cams[cam]:
            continue
        pars = calib_pars[ptr]
        cal.set_pos(pars[0] * pos_scale)
        cal.set_angles(pars[1])
        ptr += 1

    points = calib_vec[cam_params_len:]
    expected_len = num_frames * 2 * 3
    if points.shape[0] != expected_len:
        raise ValueError(
            f"Expected {expected_len} point parameters, got {points.shape[0]}"
        )
    points = points.reshape(num_frames, 2, 3)

    mm_params = cpar.get_multimedia_params()
    residuals = []

    for frame_idx in range(num_frames):
        xyz = points[frame_idx]
        for cam in range(num_cams):
            proj = image_coordinates(xyz, calibs[cam], mm_params)
            diff = targets[cam, frame_idx] - proj
            residuals.extend(diff.ravel())

        if db_weight > 0:
            length_err = np.linalg.norm(xyz[0] - xyz[1]) - db_length
            residuals.append(np.sqrt(db_weight) * length_err)

    residuals = np.asarray(residuals, dtype=float)
    return np.nan_to_num(residuals, nan=1e6, posinf=1e6, neginf=-1e6)


def dumbbell_ba_jac_sparsity(
    targets: np.ndarray,
    active_cams: np.ndarray,
    db_weight: float,
) -> sparse.csr_matrix:
    """Return Jacobian sparsity pattern for dumbbell bundle adjustment."""
    num_cams, num_frames, num_pts, _ = targets.shape
    if num_pts != 2:
        raise ValueError("Targets must contain exactly 2 points per frame")

    active_cams = np.asarray(active_cams, dtype=bool)
    num_active = int(np.sum(active_cams))
    cam_params_len = num_active * 6

    per_frame_cam_residuals = num_cams * 4
    per_frame_len_residuals = 1 if db_weight > 0 else 0
    residuals_per_frame = per_frame_cam_residuals + per_frame_len_residuals
    total_residuals = num_frames * residuals_per_frame
    total_params = cam_params_len + num_frames * 6

    pattern = sparse.lil_matrix((total_residuals, total_params), dtype=bool)

    active_map = {}
    active_idx = 0
    for cam_idx, is_active in enumerate(active_cams):
        if is_active:
            active_map[cam_idx] = active_idx
            active_idx += 1

    row = 0
    for frame_idx in range(num_frames):
        point_base = cam_params_len + frame_idx * 6
        point_cols = list(range(point_base, point_base + 6))

        for cam_idx in range(num_cams):
            cam_cols = []
            if cam_idx in active_map:
                cam_base = active_map[cam_idx] * 6
                cam_cols = list(range(cam_base, cam_base + 6))

            for _ in range(4):
                if cam_cols:
                    pattern[row, cam_cols] = True
                pattern[row, point_cols] = True
                row += 1

        if db_weight > 0:
            pattern[row, point_cols] = True
            row += 1

    return pattern.tocsr()


def calib_convergence(
    calib_vec, targets, calibs, active_cams, cpar, db_length, db_weight, pos_scale=1.0
):
    """
    Mediated the ray_convergence function and the parameter format used by
    SciPy optimization routines, by taking a vector of variable calibration
    parameters and pouring it into the Calibration objects understood by
    OpenPTV.

    Arguments:
    calib_vec - 1D array. 3 elements: camera 1 position, 3 element: camera 1
        angles, next 6 for camera 2 etc.
    targets - a (c,t,2) array, for t target metric positions in each of c
        cameras.
    calibs - an array of per-camera Calibration objects. The permanent fields
        are retained, the variable fields get overwritten.
    active_cams - a sequence of True/False values stating whether the
        corresponding camera is free to move or just a parameter.
    cpar - a ControlParams object describing the overall setting.
    db_length - expected distance between two dumbbell points.
    db_weight - weight of the distance error in the target function.

    Returns:
    The weighted ray convergence + length error measure.
    """
    calib_pars = calib_vec.reshape(-1, 2, 3)

    for cam, cal in enumerate(calibs):
        if not active_cams[cam]:
            continue

        # Pop a parameters line:
        pars = calib_pars[0]
        calib_pars = calib_pars[1:]

        cal.set_pos(pars[0] * pos_scale)
        cal.set_angles(pars[1])

    return dumbbell_target_func(targets, cpar, calibs, db_length, db_weight)


def calib_convergence_residuals(
    calib_vec, targets, calibs, active_cams, cpar, db_length, db_weight, pos_scale=1.0
):
    """Return residual vector for least-squares optimization."""
    calib_pars = calib_vec.reshape(-1, 2, 3)

    for cam, cal in enumerate(calibs):
        if not active_cams[cam]:
            continue

        pars = calib_pars[0]
        calib_pars = calib_pars[1:]

        cal.set_pos(pars[0] * pos_scale)
        cal.set_angles(pars[1])

    return dumbbell_target_residuals(targets, cpar, calibs, db_length, db_weight)


def calib_dumbbell(cal_gui) -> None:
    """Calibration with dumbbell targets.

    Args:
        exp: Either an Experiment object with pm attribute,
             or a MainGUI object with exp1.pm and cached parameter objects
    """
    pm = cal_gui.experiment.pm
    cpar, spar, vpar, track_par, tpar, cals, epar = py_start_proc_c(pm)
    num_cams = cpar.get_num_cams()
    target_filenames = pm.get_target_filenames()

    # Get dumbbell length from parameters (or set default)
    dumbbell_params = pm.get_parameter("dumbbell") or {}
    db_length = dumbbell_params.get("dumbbell_scale")
    db_weight = dumbbell_params.get("dumbbell_penalty_weight")
    db_eps = float(dumbbell_params.get("dumbbell_eps") or 0.0)
    fixed_cam_param = int(dumbbell_params.get("dumbbell_fixed_camera") or 0)
    if db_length is None or float(db_length) <= 0:
        raise ValueError("dumbbell.dumbbell_scale must be > 0")
    if db_weight is None or float(db_weight) < 0:
        raise ValueError("dumbbell.dumbbell_penalty_weight must be >= 0")

    # Get frame range
    first_frame = spar.get_first()
    last_frame = spar.get_last()

    num_frames = last_frame - first_frame + 1
    # all_targs = [[] for pt in range(num_frames*2)] # 2 targets per fram
    all_targs = []
    coverage = np.zeros(num_cams, dtype=int)
    for frame in range(num_frames):
        frame_targets = []
        valid = True
        for cam in range(num_cams):
            targs = read_targets(target_filenames[cam], first_frame + frame)
            if len(targs) == 2:
                coverage[cam] += 1
            else:
                valid = False
            if len(targs) != 2:
                valid = False
                break
            frame_targets.append([targ.pos() for targ in targs])
        if valid:
            # Only add targets if all cameras have exactly two targets
            # for tix in range(2):
            #     all_targs[frame*2 + tix].extend([frame_targets[cam][tix] for cam in range(num_cams)])
            all_targs.append(frame_targets)

    if len(all_targs) == 0:
        raise ValueError(
            "No frames with two targets per camera found for dumbbell calibration"
        )

    all_targs = np.array(all_targs)
    assert all_targs.shape[1] == num_cams and all_targs.shape[2] == 2
    num_frames, n_cams, num_targs, num_pos = all_targs.shape

    metric_by_cam = []
    for cam in range(num_cams):
        cam_pixels = all_targs[:, cam, :, :].reshape(num_frames * num_targs, num_pos)
        cam_metric = convert_arr_pixel_to_metric(cam_pixels, cpar)
        metric_by_cam.append(cam_metric.reshape(num_frames, num_targs, num_pos))
    metric_by_cam = np.array(metric_by_cam)

    if db_eps > 0:
        from optv.orientation import multi_cam_point_positions

        keep_mask = np.ones(num_frames, dtype=bool)
        removed = 0
        for frame_idx in range(num_frames):
            frame_targets = metric_by_cam[:, frame_idx, :, :]
            xyz1, _err1 = multi_cam_point_positions(
                frame_targets[:, 0, :][np.newaxis], cpar, cals
            )
            xyz2, _err2 = multi_cam_point_positions(
                frame_targets[:, 1, :][np.newaxis], cpar, cals
            )
            dist = np.linalg.norm(xyz1[0] - xyz2[0])
            if abs(dist - db_length) > db_eps:
                keep_mask[frame_idx] = False
                removed += 1
        if removed > 0:
            print(f"Filtered {removed} frame(s) by dumbbell length eps {db_eps}")
        metric_by_cam = metric_by_cam[:, keep_mask, :, :]
        num_frames = metric_by_cam.shape[1]
        if num_frames == 0:
            raise ValueError("All frames filtered by dumbbell length eps")

    def _print_camera_residuals(label: str, metric_targets: np.ndarray) -> None:
        from optv.orientation import multi_cam_point_positions
        from optv.imgcoord import image_coordinates

        num_cams_local, num_frames_local, num_targs_local, _ = metric_targets.shape
        sums = np.zeros(num_cams_local, dtype=float)
        counts = np.zeros(num_cams_local, dtype=int)
        mm_params = cpar.get_multimedia_params()

        for frame_idx in range(num_frames_local):
            frame_targets = metric_targets[:, frame_idx, :, :]
            xyz1, _err1 = multi_cam_point_positions(
                frame_targets[:, 0, :][np.newaxis], cpar, cals
            )
            xyz2, _err2 = multi_cam_point_positions(
                frame_targets[:, 1, :][np.newaxis], cpar, cals
            )
            xyz = np.vstack([xyz1, xyz2])

            for cam in range(num_cams_local):
                proj = image_coordinates(xyz, cals[cam], mm_params)
                diff = frame_targets[cam] - proj
                mask = np.isfinite(diff).all(axis=1)
                if np.any(mask):
                    sums[cam] += float(np.sum(diff[mask] ** 2))
                    counts[cam] += int(np.sum(mask))

        rms = np.sqrt(sums / np.maximum(counts, 1))
        print(f"{label} per-camera RMS (metric): {rms.tolist()}")

    print(f"Using {num_frames} frame(s) for dumbbell calibration")
    per_frame_metric = metric_by_cam

    # Generate initial guess vector and bounds for optimization:
    if 1 <= fixed_cam_param <= num_cams:
        fixed_cam = fixed_cam_param - 1
        print(
            f"Fixing camera {fixed_cam + 1} from parameter dumbbell_fixed_camera; "
            f"coverage counts: {coverage.tolist()}"
        )
    else:
        fixed_cam = int(np.argmax(coverage)) if num_cams > 0 else 0
        print(
            f"Fixing camera {fixed_cam + 1} based on coverage counts: {coverage.tolist()}"
        )

    active = np.ones(num_cams)
    active[fixed_cam] = 0
    num_active = int(np.sum(active))
    if num_active == 0:
        raise ValueError("All cameras fixed; need at least one active camera")

    pos_scale = 1.0
    print(f"Position scale set to {pos_scale} (optimize in millimeters)")
    calib_vec = np.empty((num_active, 2, 3))
    active_ptr = 0
    for cam in range(num_cams):
        if active[cam]:
            calib_vec[active_ptr, 0] = cals[cam].get_pos() / pos_scale
            calib_vec[active_ptr, 1] = cals[cam].get_angles()
            active_ptr += 1

        # Positions within a neighbourhood of the initial guess, so we don't
        # converge to the trivial solution where all cameras are in the same
        # place.
    calib_vec = calib_vec.flatten()

    def _init_dumbbell_points(metric_targets: np.ndarray) -> np.ndarray:
        from optv.orientation import multi_cam_point_positions

        num_cams_local, num_frames_local, _, _ = metric_targets.shape
        points = np.zeros((num_frames_local, 2, 3), dtype=float)

        for frame_idx in range(num_frames_local):
            frame_targets = metric_targets[:, frame_idx, :, :]
            xyz1, _err1 = multi_cam_point_positions(
                frame_targets[:, 0, :][np.newaxis], cpar, cals
            )
            xyz2, _err2 = multi_cam_point_positions(
                frame_targets[:, 1, :][np.newaxis], cpar, cals
            )
            points[frame_idx, 0] = xyz1[0]
            points[frame_idx, 1] = xyz2[0]

        return points

    points_init = _init_dumbbell_points(per_frame_metric)
    x0 = np.concatenate([calib_vec, points_init.reshape(-1)])

    # Test optimizer-ready target function:
    print("Initial values (1 row per active camera, scaled pos, then angle):")
    print(calib_vec.reshape(num_active, -1))
    print("Current target function (sum of squared residuals):", end=" ")
    init_residuals = dumbbell_ba_residuals(
        x0, per_frame_metric, cpar, cals, active, db_length, db_weight, pos_scale
    )
    print(np.sum(init_residuals**2))
    _print_camera_residuals("Initial", per_frame_metric)

    # Optimization:
    method = "trf"
    loss = "soft_l1"
    print(f"Using least_squares method={method} loss={loss}")
    tol_steps = [
        (1e-6, 1e-6, 1e-5),
        (1e-5, 1e-5, 1e-4),
        (1e-4, 1e-4, 1e-3),
    ]
    max_rounds = 3
    nfev_per_round = 200
    min_improvement = 1e-3

    best_x = x0
    best_fun = float(np.sum(init_residuals**2))
    res = None

    jac_sparsity = dumbbell_ba_jac_sparsity(per_frame_metric, active, db_weight)

    for idx in range(max_rounds):
        xtol, ftol, gtol = tol_steps[min(idx, len(tol_steps) - 1)]
        res = least_squares(
            dumbbell_ba_residuals,
            best_x,
            args=(
                per_frame_metric,
                cpar,
                cals,
                active,
                db_length,
                db_weight,
                pos_scale,
            ),
            xtol=xtol,
            ftol=ftol,
            gtol=gtol,
            jac_sparsity=jac_sparsity,
            x_scale="jac",
            max_nfev=nfev_per_round,
            loss=loss,
            f_scale=1.0,
            verbose=2,
            method=method,
        )
        new_fun = float(np.sum(res.fun**2))
        improvement = (best_fun - new_fun) / max(best_fun, 1e-12)
        print(
            f"Adaptive round {idx + 1}: fun={new_fun:.6g} improvement={improvement:.3g} "
            f"xtol={xtol} ftol={ftol} gtol={gtol}"
        )
        best_x = res.x
        best_fun = new_fun
        if improvement < min_improvement:
            break

    if res is None:
        raise RuntimeError("Adaptive least_squares did not run")

    print("Result of dumbbell calibration")
    cam_params_len = num_active * 6
    print(best_x[:cam_params_len].reshape(num_active, -1))
    print("Success:", res.success, res.message)
    print("Final target function (sum of squared residuals):", end=" ")
    final_residuals = dumbbell_ba_residuals(
        best_x, per_frame_metric, cpar, cals, active, db_length, db_weight, pos_scale
    )
    print(np.sum(final_residuals**2))

    # convert calib_vec back to Calibration objects:
    cam_params_len = num_active * 6
    calib_pars = best_x[:cam_params_len].reshape(-1, 2, 3)

    for cam, cal in enumerate(cals):
        if not active[cam]:
            continue

        # Pop a parameters line:
        pars = calib_pars[0]
        calib_pars = calib_pars[1:]

        cal.set_pos(pars[0] * pos_scale)
        cal.set_angles(pars[1])

        _print_camera_residuals("Final", per_frame_metric)

        # Write the calibration results to files:
        ori_filename = cpar.get_cal_img_base_name(cam)
        addpar_filename = ori_filename + ".addpar"
        ori_filename = ori_filename + ".ori"
        cal.write(ori_filename.encode("utf-8"), addpar_filename.encode("utf-8"))


def calib_particles(exp):
    """Calibration with particles."""

    from optv.tracking_framebuf import Frame

    # Handle both Experiment objects and MainGUI objects
    if hasattr(exp, "pm"):
        # Traditional experiment object
        pm = exp.pm
        num_cams = pm.num_cams
        cpar = exp.cpar
        spar = exp.spar
        vpar = exp.vpar
        tpar = exp.tpar
        cals = exp.cals
    elif hasattr(exp, "exp1") and hasattr(exp.exp1, "pm"):
        # MainGUI object - ensure parameter objects are initialized
        pm = exp.exp1.pm
        num_cams = exp.num_cams
        cpar = exp.cpar
        spar = exp.spar
        vpar = exp.vpar
        tpar = exp.tpar
        cals = exp.cals
    else:
        raise ValueError("Object must have either pm or exp1.pm attribute")

    num_cams = cpar.get_num_cams()
    calibs = _read_calibrations(cpar, num_cams)

    targ_files = [
        spar.get_img_base_name(c).split("%d")[0].encode("utf-8")
        for c in range(num_cams)
    ]

    orient_params = pm.get_parameter("orient")
    shaking_params = pm.get_parameter("shaking")

    flags = [name for name in NAMES if orient_params.get(name) == 1]
    all_known = []
    all_detected = [[] for c in range(num_cams)]

    for frm_num in range(
        shaking_params["shaking_first_frame"], shaking_params["shaking_last_frame"] + 1
    ):
        frame = Frame(
            cpar.get_num_cams(),
            corres_file_base=("res/rt_is").encode("utf-8"),
            linkage_file_base=("res/ptv_is").encode("utf-8"),
            target_file_base=targ_files,
            frame_num=frm_num,
        )

        all_known.append(frame.positions())
        for cam in range(num_cams):
            all_detected[cam].append(frame.target_positions_for_camera(cam))

    all_known = np.vstack(all_known)

    targ_ix_all = []
    residuals_all = []
    targs_all = []
    for cam in range(num_cams):
        detects = np.vstack(all_detected[cam])
        assert detects.shape[0] == all_known.shape[0]

        have_targets = ~np.isnan(detects[:, 0])
        used_detects = detects[have_targets, :]
        used_known = all_known[have_targets, :]

        targs = TargetArray(len(used_detects))

        for tix, detect in enumerate(used_detects):
            targ = targs[tix]
            targ.set_pnr(tix)
            targ.set_pos(detect)

        residuals = full_scipy_calibration(
            calibs[cam], used_known, targs, exp.cpar, flags=flags
        )
        print(f"After scipy full calibration, {np.sum(residuals**2)}")

        print(f"Camera {cam + 1}")
        print((calibs[cam].get_pos()))
        print((calibs[cam].get_angles()))

        ori_filename = exp.cpar.get_cal_img_base_name(cam)
        addpar_filename = ori_filename + ".addpar"
        ori_filename = ori_filename + ".ori"
        calibs[cam].write(ori_filename.encode("utf-8"), addpar_filename.encode("utf-8"))

        targ_ix = [t.pnr() for t in targs if t.pnr() != -999]

        targs_all.append(targs)
        targ_ix_all.append(targ_ix)
        residuals_all.append(residuals)

    print("End calibration with particles")
    return targs_all, targ_ix_all, residuals_all


def clone_calibration(calibration_obj):
    """Return a copy of a Calibration object using all get/set methods."""
    from optv.calibration import Calibration
    import numpy as np

    new_cal = Calibration()
    new_cal.set_pos(np.array(calibration_obj.get_pos()))
    new_cal.set_angles(np.array(calibration_obj.get_angles()))
    new_cal.set_primary_point(np.array(calibration_obj.get_primary_point()))
    new_cal.set_radial_distortion(np.array(calibration_obj.get_radial_distortion()))
    new_cal.set_decentering(np.array(calibration_obj.get_decentering()))
    new_cal.set_affine_trans(np.array(calibration_obj.get_affine()))
    new_cal.set_glass_vec(np.array(calibration_obj.get_glass_vec()))
    return new_cal
