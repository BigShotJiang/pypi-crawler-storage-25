from importlib import metadata

__version__ = metadata.version("planpoint-sdk")
