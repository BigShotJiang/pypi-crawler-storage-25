# nexus-ai-base

Core configuration, registry, security primitives, and LLM abstractions for the nexus-ai ecosystem.

This is the foundation package that all other nexus-ai packages build on. Install it directly only if you are building a custom integration — most users should install `nexus-ai-orchestrator` or `nexus-ai` instead.

## Install

```bash
pip install nexus-ai-base[anthropic]
pip install nexus-ai-base[openai]
pip install nexus-ai-base[google]
pip install nexus-ai-base[local]
```

## What's included

- `NexusConfig` / `LLMConfig` / `RouterConfig` — dataclass-based configuration with YAML and env-var loading
- `SecretRef` — wraps API keys so they never appear in logs or `repr()`
- `ToolRegistry` — central registry for all tools available to the agent
- `SecurityConfig` / `ContentPolicy` / `MCPSecurityPolicy` / `ThreadPolicy` — layered security primitives
- `TokenBudgetConfig` — token usage tracking and conversation compression

## License

MIT
