from __future__ import annotations


class NexusError(Exception):
    """Base exception for all Nexus errors."""


class ConfigurationError(NexusError):
    """Invalid or missing configuration."""


class ToolNotFoundError(NexusError):
    """Named tool does not exist in the registry."""


class ToolExecutionError(NexusError):
    """A tool raised an error during execution."""

    def __init__(self, tool_name: str, cause: Exception):
        self.tool_name = tool_name
        self.cause = cause
        super().__init__(f"Tool '{tool_name}' failed: {cause}")


class ToolConflictError(NexusError):
    """A tool with this name is already registered."""


class IndexNotFoundError(NexusError):
    """Named LlamaIndex index does not exist."""


class MCPConnectionError(NexusError):
    """Failed to connect to an MCP server."""


class MCPTimeoutError(NexusError):
    """MCP tool call timed out."""


class A2AConnectionError(NexusError):
    """Failed to reach a remote A2A agent."""


class A2ATimeoutError(NexusError):
    """A2A task delegation timed out."""


class AgentNotFoundError(NexusError):
    """Named remote agent has not been discovered."""


class OrchestratorError(NexusError):
    """Top-level orchestration failure."""


class MaxToolCallsExceeded(NexusError):
    """The graph hit its tool-call budget before finishing."""


# ── Security ──────────────────────────────────────────────────────────────────

class SecurityError(NexusError):
    """Base class for security-related failures."""


class ThreadAuthError(SecurityError):
    """Access to a thread was denied — missing or invalid user token."""


class ToolBlockedError(SecurityError):
    """A tool call or result was blocked by a ContentPolicy hook."""


class ToolArgValidationError(SecurityError):
    """Tool arguments supplied by the LLM failed schema validation."""


# ── Token budget ──────────────────────────────────────────────────────────────

class TokenBudgetExceeded(NexusError):
    """A run exceeded its configured token budget."""
