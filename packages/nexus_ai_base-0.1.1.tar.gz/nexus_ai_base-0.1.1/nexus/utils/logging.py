"""Structured logging setup for Nexus."""
from __future__ import annotations

import logging
import sys
from typing import Optional


def configure_logging(
    level: str = "INFO",
    fmt: str = "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handler: Optional[logging.Handler] = None,
) -> None:
    """Configure the 'nexus' logger subtree."""
    nexus_logger = logging.getLogger("nexus")
    nexus_logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    if not nexus_logger.handlers:
        h = handler or logging.StreamHandler(sys.stdout)
        h.setFormatter(logging.Formatter(fmt))
        nexus_logger.addHandler(h)
        nexus_logger.propagate = False


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"nexus.{name}")
