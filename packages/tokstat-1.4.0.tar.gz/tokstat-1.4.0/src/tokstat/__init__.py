from tokstat.cli import __version__

__all__ = ["__version__"]
