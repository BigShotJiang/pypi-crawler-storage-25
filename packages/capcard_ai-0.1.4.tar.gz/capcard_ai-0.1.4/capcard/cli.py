"""capcard CLI — verify, init, lint, badge."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .validator import validate_card

_USAGE = """\
capcard — trust infrastructure for the agent economy

Commands:
  capcard verify <path>   Validate a capability_card.json
  capcard lint <path>     Warn about common quality issues (does not block)
  capcard init            Scaffold a starter capability_card.json
  capcard badge <path>    Print a README badge for your card

Options:
  -h, --help              Show this message
"""

_PLACEHOLDER_STRINGS = [
    "Describe what",
    "your-test-command-here",
    "github.com/username/",
    "Your Name",
    "UPDATE_AFTER_COMMIT",
]


def _cmd_lint(path: str) -> None:
    card_path = Path(path)
    if not card_path.exists():
        print(f"Error: file not found: {path}", file=sys.stderr)
        sys.exit(2)

    try:
        with open(card_path, encoding="utf-8") as f:
            card = json.load(f)
    except json.JSONDecodeError as e:
        print(f"Error: JSON parse error: {e}", file=sys.stderr)
        sys.exit(2)

    warnings: list[str] = []

    def _check_placeholder(field: str, value: str) -> None:
        for ph in _PLACEHOLDER_STRINGS:
            if ph.lower() in value.lower():
                warnings.append(f"  WARN {field} still contains placeholder text: {ph!r}")

    # Top-level fields
    if repo := card.get("repository", ""):
        _check_placeholder("repository", repo)

    if desc := card.get("description", ""):
        _check_placeholder("description", desc)

    # Authors
    for i, author in enumerate(card.get("authors", [])):
        if name := author.get("name", ""):
            _check_placeholder(f"authors[{i}].name", name)

    # Capabilities
    proven_ids: set[str] = set()
    for cap in card.get("capabilities", []):
        cid = cap.get("id", "?")
        if cdesc := cap.get("description", ""):
            _check_placeholder(f"capability '{cid}' description", cdesc)
        if cap.get("status") == "proven":
            proven_ids.add(cid)

    # Proofs
    proof_refs: set[str] = set()
    proofs = card.get("proofs", [])
    if not proofs and proven_ids:
        warnings.append(
            f"  WARN {len(proven_ids)} capability(s) have status=proven but no proofs[] array found"
        )
    for proof in proofs:
        for ref in proof.get("capability_refs", []):
            proof_refs.add(ref)

    unproven = proven_ids - proof_refs
    if unproven:
        for uid in sorted(unproven):
            warnings.append(f"  WARN capability '{uid}' is status=proven but has no proof entry referencing it")

    # Benchmarks
    for bench in card.get("benchmarks", []):
        bid = bench.get("id", "?")
        repro = bench.get("reproducibility") or {}
        if cmd := repro.get("command", ""):
            _check_placeholder(f"benchmark '{bid}' reproducibility.command", cmd)

    # Verification
    verif = card.get("verification", {})
    if isinstance(verif, dict):
        if ch := verif.get("commit_hash", ""):
            _check_placeholder("verification.commit_hash", ch)
        ts = verif.get("trust_score")
        if ts is None:
            warnings.append("  WARN verification.trust_score not set — run capcard verify to compute it")

    # Metadata staleness
    meta = card.get("metadata", {})
    if isinstance(meta, dict):
        created = meta.get("created")
        updated = meta.get("updated")
        if created and updated and created == updated:
            warnings.append("  WARN metadata.created == metadata.updated -- did you forget to update the timestamp?")

    name = card.get("name", path)
    if warnings:
        print(f"capcard lint: {len(warnings)} warning(s) in {name}\n")
        for w in warnings:
            print(w)
        print()
        print("Fix these before submitting to the registry.")
        sys.exit(1)
    else:
        print(f"capcard lint: {name} — no issues found")
        sys.exit(0)


def _detect_project() -> dict:
    here = Path.cwd()

    # Python — pyproject.toml
    pyproject = here / "pyproject.toml"
    if pyproject.exists():
        text = pyproject.read_text(encoding="utf-8")
        name, version = None, None
        for line in text.splitlines():
            if line.startswith("name") and "=" in line and name is None:
                name = line.split("=", 1)[1].strip().strip('"').strip("'")
            if line.startswith("version") and "=" in line and version is None:
                version = line.split("=", 1)[1].strip().strip('"').strip("'")
        if name:
            return {"name": name, "version": version or "0.1.0", "ecosystem": "python"}

    # Node — package.json
    pkg = here / "package.json"
    if pkg.exists():
        try:
            d = json.loads(pkg.read_text(encoding="utf-8"))
            return {"name": d.get("name", "my-project"), "version": d.get("version", "0.1.0"), "ecosystem": "node"}
        except json.JSONDecodeError:
            pass

    # Rust — Cargo.toml
    cargo = here / "Cargo.toml"
    if cargo.exists():
        text = cargo.read_text(encoding="utf-8")
        name, version = None, None
        for line in text.splitlines():
            if line.startswith("name") and "=" in line and name is None:
                name = line.split("=", 1)[1].strip().strip('"').strip("'")
            if line.startswith("version") and "=" in line and version is None:
                version = line.split("=", 1)[1].strip().strip('"').strip("'")
        if name:
            return {"name": name, "version": version or "0.1.0", "ecosystem": "rust"}

    # Go — go.mod
    gomod = here / "go.mod"
    if gomod.exists():
        text = gomod.read_text(encoding="utf-8")
        for line in text.splitlines():
            if line.startswith("module "):
                module = line.split(" ", 1)[1].strip()
                name = module.split("/")[-1]
                return {"name": name, "version": "0.1.0", "ecosystem": "go"}

    return {"name": here.name, "version": "0.1.0", "ecosystem": "unknown"}


def _cmd_init() -> None:
    out = Path.cwd() / "capability_card.json"
    if out.exists():
        print(f"capability_card.json already exists at {out}")
        print("Delete it first or edit it directly.")
        sys.exit(1)

    proj = _detect_project()
    name = proj["name"]
    version = proj["version"]
    ecosystem = proj.get("ecosystem", "unknown")
    today = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    _test_commands = {
        "python": "pytest tests/ -q",
        "node": "npm test",
        "rust": "cargo test",
        "go": "go test ./...",
    }
    test_cmd = _test_commands.get(ecosystem, "your-test-command-here")

    card = {
        "capcard_version": "1.0.0",
        "id": f"ai.capcard.{name.replace('-', '_').replace(' ', '_').lower()}",
        "name": name,
        "type": "library",
        "description": f"Describe what {name} does.",
        "version": version,
        "license": "MIT",
        "repository": f"https://github.com/username/{name}",
        "authors": [{"name": "Your Name", "role": "creator"}],
        "capabilities": [
            {
                "id": "my.first.capability",
                "name": "Example Capability",
                "category": "computation",
                "description": "Describe what this capability does and what evidence supports it.",
                "status": "empirically_confirmed",
                "tags": ["example"]
            }
        ],
        "benchmarks": [
            {
                "id": "bench.example",
                "name": "Example Benchmark",
                "capability_ref": "my.first.capability",
                "metric": "accuracy",
                "value": 0.95,
                "unit": "fraction",
                "direction": "higher_is_better",
                "reproducibility": {
                    "command": test_cmd,
                    "deterministic": True
                }
            }
        ],
        "verification": {
            "last_verified": today,
            "commit_hash": "UPDATE_AFTER_COMMIT"
        },
        "metadata": {
            "created": today,
            "updated": today,
            "schema_url": "https://capcard.ai/schema/v1/capability_card.schema.json"
        }
    }

    out.write_text(json.dumps(card, indent=2), encoding="utf-8")
    print(f"Created capability_card.json in {Path.cwd()}")
    if ecosystem != "unknown":
        print(f"Detected ecosystem: {ecosystem}")
    print()
    print("Next steps:")
    print("  1. Edit the file — fill in your real capabilities and benchmarks")
    print("  2. Set status honestly: proven / empirically_confirmed / experimental / conjecture")
    print("  3. Run: capcard verify capability_card.json")
    print()
    print("Get a signed trust score: https://capcard.ai/pricing.html")


def _cmd_verify(path: str) -> None:
    report = validate_card(path)
    print(json.dumps(report, indent=2))
    sys.exit(0 if report["valid"] else 1)


def _cmd_badge(path: str) -> None:
    report = validate_card(path)
    if not report["valid"]:
        print("Error: card is not valid — fix errors before generating a badge.", file=sys.stderr)
        sys.exit(1)

    score = report.get("trust_score")
    name = (report.get("card_name") or "capcard").replace(" ", "%20")
    color = "10b981" if score and score >= 0.8 else "f59e0b" if score and score >= 0.5 else "ef4444"
    score_str = str(score) if score is not None else "verified"

    badge_url = f"https://img.shields.io/badge/capcard-{score_str}-{color}"
    registry_url = "https://capcard.ai/registry.html"

    print(f"Markdown:")
    print(f"  [![CapCard]({badge_url})]({registry_url})")
    print()
    print(f"HTML:")
    print(f'  <a href="{registry_url}"><img src="{badge_url}" alt="CapCard"></a>')


def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print(_USAGE)
        sys.exit(0)

    cmd = args[0]

    if cmd == "verify":
        if len(args) < 2:
            print("Error: missing path.\n\nUsage: capcard verify <path>", file=sys.stderr)
            sys.exit(2)
        _cmd_verify(args[1])

    elif cmd == "lint":
        if len(args) < 2:
            print("Error: missing path.\n\nUsage: capcard lint <path>", file=sys.stderr)
            sys.exit(2)
        _cmd_lint(args[1])

    elif cmd == "init":
        _cmd_init()

    elif cmd == "badge":
        if len(args) < 2:
            print("Error: missing path.\n\nUsage: capcard badge <path>", file=sys.stderr)
            sys.exit(2)
        _cmd_badge(args[1])

    else:
        print(f"Unknown command: {cmd}\n\n{_USAGE}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
