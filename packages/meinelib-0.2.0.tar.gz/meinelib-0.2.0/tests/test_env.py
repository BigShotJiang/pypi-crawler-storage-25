"""Tests for meinelib.env."""
import os
import pytest
from meinelib.env import get_env, require_env


def test_require_env_present(monkeypatch):
    monkeypatch.setenv("MY_VAR", "hello")
    assert require_env("MY_VAR") == "hello"


def test_require_env_missing(monkeypatch):
    monkeypatch.delenv("MY_VAR", raising=False)
    with pytest.raises(EnvironmentError, match="MY_VAR"):
        require_env("MY_VAR")


def test_require_env_empty(monkeypatch):
    monkeypatch.setenv("MY_VAR", "")
    with pytest.raises(EnvironmentError, match="MY_VAR"):
        require_env("MY_VAR")


def test_get_env_present(monkeypatch):
    monkeypatch.setenv("MY_VAR", "world")
    assert get_env("MY_VAR") == "world"


def test_get_env_missing_returns_default(monkeypatch):
    monkeypatch.delenv("MY_VAR", raising=False)
    assert get_env("MY_VAR", default="fallback") == "fallback"


def test_get_env_missing_returns_none(monkeypatch):
    monkeypatch.delenv("MY_VAR", raising=False)
    assert get_env("MY_VAR") is None


def test_get_env_cast_int(monkeypatch):
    monkeypatch.setenv("PORT", "8080")
    assert get_env("PORT", cast=int) == 8080


def test_get_env_cast_float(monkeypatch):
    monkeypatch.setenv("RATIO", "0.75")
    assert get_env("RATIO", cast=float) == 0.75


def test_get_env_cast_failure(monkeypatch):
    monkeypatch.setenv("PORT", "not_a_number")
    with pytest.raises(ValueError, match="PORT"):
        get_env("PORT", cast=int)
