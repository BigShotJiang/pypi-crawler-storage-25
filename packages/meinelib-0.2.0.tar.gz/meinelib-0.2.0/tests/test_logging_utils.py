"""Tests for meinelib.logging_utils."""
import logging
import os
from meinelib.logging_utils import get_logger


def test_get_logger_returns_logger():
    logger = get_logger("test.basic")
    assert isinstance(logger, logging.Logger)


def test_get_logger_default_level():
    logger = get_logger("test.level")
    assert logger.level == logging.INFO


def test_get_logger_debug_level():
    logger = get_logger("test.debug", level="DEBUG")
    assert logger.level == logging.DEBUG


def test_get_logger_idempotent():
    logger1 = get_logger("test.idempotent")
    handler_count = len(logger1.handlers)
    logger2 = get_logger("test.idempotent")
    assert logger1 is logger2
    assert len(logger2.handlers) == handler_count


def test_get_logger_with_file(tmp_path):
    logfile = str(tmp_path / "test.log")
    logger = get_logger("test.file", logfile=logfile)
    logger.info("hello from test")
    assert os.path.exists(logfile)
    content = open(logfile).read()
    assert "hello from test" in content
