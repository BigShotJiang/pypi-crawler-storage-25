"""Tests for meinelib.timing."""
import time
import pytest
from meinelib.timing import timer, timed


def test_timer_returns_value():
    @timer
    def add(a, b):
        return a + b

    assert add(2, 3) == 5


def test_timer_prints(capsys):
    @timer
    def noop():
        pass

    noop()
    captured = capsys.readouterr()
    assert "[timer]" in captured.out
    assert "noop" in captured.out


def test_timed_prints(capsys):
    with timed("my_block"):
        pass
    captured = capsys.readouterr()
    assert "[timed]" in captured.out
    assert "my_block" in captured.out


def test_timed_no_label(capsys):
    with timed():
        pass
    captured = capsys.readouterr()
    assert "[timed]" in captured.out
    assert "block" in captured.out


def test_timed_elapsed_is_positive():
    start = time.perf_counter()
    with timed("sleep"):
        time.sleep(0.01)
    elapsed = time.perf_counter() - start
    assert elapsed >= 0.01


def test_timed_reraises():
    with pytest.raises(ValueError):
        with timed("err"):
            raise ValueError("boom")
