"""Tests for meinelib.debug."""
import os
import pytest
from meinelib.debug import dump, load_dump, json_dump, json_load


def test_dump_and_load(tmp_path):
    obj = {"key": "value", "nums": [1, 2, 3]}
    path = str(tmp_path / "test_obj")
    dump(obj, filename=path)
    assert os.path.exists(f"{path}.pickle")
    loaded = load_dump(path)
    assert loaded == obj


def test_dump_exit(tmp_path):
    path = str(tmp_path / "exit_test")
    with pytest.raises(SystemExit):
        dump({"x": 1}, filename=path, _exit=True)
    assert os.path.exists(f"{path}.pickle")


def test_json_dump_and_load(tmp_path):
    obj = {"a": 1, "b": [True, None, 2.5]}
    path = str(tmp_path / "test_data")
    json_dump(obj, filename=path)
    assert os.path.exists(f"{path}.json")
    loaded = json_load(path)
    assert loaded == obj


def test_json_load_with_explicit_extension(tmp_path):
    obj = {"explicit": True}
    path = str(tmp_path / "explicit")
    json_dump(obj, filename=path)
    loaded = json_load(str(tmp_path / "explicit.json"))
    assert loaded == obj


def test_json_dump_exit(tmp_path):
    path = str(tmp_path / "exit_json")
    with pytest.raises(SystemExit):
        json_dump({"x": 1}, filename=path, _exit=True)
    assert os.path.exists(f"{path}.json")


def test_load_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_dump(str(tmp_path / "nonexistent"))


def test_json_load_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError):
        json_load(str(tmp_path / "nonexistent"))
