"""Tests for meinelib.dicts."""
import pytest
from meinelib.dicts import deep_merge, flatten, pick, omit


# --- deep_merge ---

def test_deep_merge_simple():
    result = deep_merge({"a": 1}, {"b": 2})
    assert result == {"a": 1, "b": 2}


def test_deep_merge_override():
    result = deep_merge({"a": 1, "b": 2}, {"b": 99})
    assert result == {"a": 1, "b": 99}


def test_deep_merge_nested():
    base = {"db": {"host": "localhost", "port": 5432}}
    override = {"db": {"port": 5433, "name": "prod"}}
    result = deep_merge(base, override)
    assert result == {"db": {"host": "localhost", "port": 5433, "name": "prod"}}


def test_deep_merge_does_not_mutate():
    base = {"a": {"x": 1}}
    override = {"a": {"y": 2}}
    deep_merge(base, override)
    assert base == {"a": {"x": 1}}


# --- flatten ---

def test_flatten_simple():
    assert flatten({"a": 1, "b": 2}) == {"a": 1, "b": 2}


def test_flatten_nested():
    result = flatten({"a": {"b": 1, "c": {"d": 2}}})
    assert result == {"a.b": 1, "a.c.d": 2}


def test_flatten_custom_sep():
    result = flatten({"a": {"b": 1}}, sep="/")
    assert result == {"a/b": 1}


def test_flatten_empty():
    assert flatten({}) == {}


# --- pick ---

def test_pick_existing_keys():
    assert pick({"a": 1, "b": 2, "c": 3}, ["a", "c"]) == {"a": 1, "c": 3}


def test_pick_missing_keys_ignored():
    assert pick({"a": 1}, ["a", "z"]) == {"a": 1}


def test_pick_empty_keys():
    assert pick({"a": 1}, []) == {}


# --- omit ---

def test_omit_removes_keys():
    assert omit({"a": 1, "b": 2, "c": 3}, ["b"]) == {"a": 1, "c": 3}


def test_omit_missing_keys_ignored():
    assert omit({"a": 1}, ["z"]) == {"a": 1}


def test_omit_empty_keys():
    assert omit({"a": 1, "b": 2}, []) == {"a": 1, "b": 2}
