"""meinelib — small Python utility library."""

__version__ = "0.2.0"

from meinelib.debug import dump, load_dump, json_dump, json_load
from meinelib.timing import timer, timed
from meinelib.logging_utils import get_logger
from meinelib.env import get_env, require_env
from meinelib.dicts import deep_merge, flatten, pick, omit

__all__ = [
    "dump", "load_dump", "json_dump", "json_load",
    "timer", "timed",
    "get_logger",
    "get_env", "require_env",
    "deep_merge", "flatten", "pick", "omit",
]
