"""Logging setup helpers to reduce boilerplate."""
import logging
import sys
from typing import Optional


_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def get_logger(
    name: str,
    level: str = "INFO",
    logfile: Optional[str] = None,
    fmt: str = _LOG_FORMAT,
) -> logging.Logger:
    """Create and return a configured Logger instance.

    Params
    ------
    name: str - Logger name (typically __name__ of the calling module).
    level: str (default: INFO) - Logging level: DEBUG, INFO, WARNING, ERROR, CRITICAL.
    logfile: str (default: None) - If given, also writes log output to this file.
    fmt: str - Log format string (default includes timestamp, level, and name).

    Returns
    -------
    logging.Logger
    """
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    numeric_level = getattr(logging, level.upper(), logging.INFO)
    logger.setLevel(numeric_level)

    formatter = logging.Formatter(fmt, datefmt=_DATE_FORMAT)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    if logfile:
        file_handler = logging.FileHandler(logfile, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger
