"""Environment variable helpers with type casting and clear error messages."""
import os
from typing import Any, Callable, Optional, TypeVar

T = TypeVar("T")


def require_env(name: str) -> str:
    """Return the value of an environment variable, raising if it is not set.

    Params
    ------
    name: str - Environment variable name.

    Returns
    -------
    str - The variable value.

    Raises
    ------
    EnvironmentError - If the variable is not set or is empty.
    """
    value = os.environ.get(name)
    if not value:
        raise EnvironmentError(f"Required environment variable '{name}' is not set.")
    return value


def get_env(
    name: str,
    default: Optional[T] = None,
    cast: Optional[Callable[[str], T]] = None,
) -> Any:
    """Return the value of an environment variable, with optional default and cast.

    Params
    ------
    name: str - Environment variable name.
    default: Any (default: None) - Returned when the variable is not set.
    cast: Callable (default: None) - Function to convert the string value (e.g. int, float, bool).

    Returns
    -------
    The variable value, cast if requested, or the default.

    Raises
    ------
    ValueError - If the variable is set but the cast fails.
    """
    raw = os.environ.get(name)
    if raw is None:
        return default
    if cast is None:
        return raw
    try:
        return cast(raw)
    except (ValueError, TypeError) as exc:
        raise ValueError(
            f"Environment variable '{name}' has value '{raw}' which cannot be cast with {cast.__name__}."
        ) from exc
