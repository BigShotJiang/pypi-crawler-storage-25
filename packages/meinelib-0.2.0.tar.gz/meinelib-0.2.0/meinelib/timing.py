"""Lightweight timing utilities: decorator and context manager."""
import time
import functools
from contextlib import contextmanager
from typing import Any, Callable, Generator, Optional


def timer(func: Callable) -> Callable:
    """Decorator that prints the elapsed time of the wrapped function.

    Params
    ------
    func: Callable - The function to time.

    Example
    -------
    @timer
    def my_function():
        ...
    """
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        print(f"[timer] {func.__qualname__} took {elapsed:.4f}s")
        return result
    return wrapper


@contextmanager
def timed(label: Optional[str] = None) -> Generator[None, None, None]:
    """Context manager that prints the elapsed time of the wrapped block.

    Params
    ------
    label: str (default: None) - Label to print alongside elapsed time.

    Example
    -------
    with timed("my block"):
        heavy_computation()
    """
    tag = label or "block"
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        print(f"[timed] {tag} took {elapsed:.4f}s")
