"""Dictionary utility functions: deep_merge, flatten, pick, omit."""
from typing import Any, Dict, Iterable, List


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge two dicts. Values in override win on conflict.

    Params
    ------
    base: dict - Base dictionary.
    override: dict - Dictionary whose values take precedence.

    Returns
    -------
    dict - New merged dictionary (neither input is mutated).
    """
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def flatten(d: Dict[str, Any], sep: str = ".", prefix: str = "") -> Dict[str, Any]:
    """Flatten a nested dict into a single-level dict with dotted keys.

    Params
    ------
    d: dict - The dictionary to flatten.
    sep: str (default: '.') - Separator used to join nested keys.
    prefix: str (default: '') - Key prefix for recursive calls (not needed externally).

    Returns
    -------
    dict - Flattened dictionary.

    Example
    -------
    flatten({"a": {"b": 1, "c": {"d": 2}}})
    # → {"a.b": 1, "a.c.d": 2}
    """
    result: Dict[str, Any] = {}
    for key, value in d.items():
        full_key = f"{prefix}{sep}{key}" if prefix else key
        if isinstance(value, dict):
            result.update(flatten(value, sep=sep, prefix=full_key))
        else:
            result[full_key] = value
    return result


def pick(d: Dict[str, Any], keys: Iterable[str]) -> Dict[str, Any]:
    """Return a new dict with only the specified keys.

    Params
    ------
    d: dict - Source dictionary.
    keys: Iterable[str] - Keys to keep.

    Returns
    -------
    dict - Dictionary containing only the selected keys that exist in d.
    """
    return {k: d[k] for k in keys if k in d}


def omit(d: Dict[str, Any], keys: Iterable[str]) -> Dict[str, Any]:
    """Return a new dict excluding the specified keys.

    Params
    ------
    d: dict - Source dictionary.
    keys: Iterable[str] - Keys to remove.

    Returns
    -------
    dict - Dictionary without the excluded keys.
    """
    excluded: List[str] = list(keys)
    return {k: v for k, v in d.items() if k not in excluded}
