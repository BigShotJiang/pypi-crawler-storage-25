# Flowgentra

**Build production-grade AI agent workflows — in Rust or Python.**

Flowgentra is a graph-based framework for building LLM-powered agents. You connect nodes (functions) with edges, define how state flows between them, and let the engine handle execution, retries, memory, and observability.

---

## Choose your language

<div class="grid cards" markdown>

- **:fontawesome-brands-rust: Rust**

    ---

    Maximum performance, compile-time safety, zero overhead.
    
    Best for: production systems, latency-sensitive workloads, existing Rust services.

    [Get started with Rust →](getting-started/quickstart.md#rust)

- **:fontawesome-brands-python: Python**

    ---

    Rapid development, familiar tooling, full ML ecosystem access.
    
    Best for: prototyping, data science pipelines, Python-first teams.

    [Get started with Python →](getting-started/quickstart.md#python)

</div>

Both share the same Rust execution engine. The APIs mirror each other closely.

---

## What can you build?

- **ReAct agents** — reason, call tools, loop until they have an answer
- **RAG pipelines** — retrieve context and feed it to an LLM
- **Multi-step workflows** — conditional branching, parallel execution, subgraphs
- **Multi-agent systems** — supervisor orchestrates specialist agents
- **Conversational chatbots** — per-user memory, persistent sessions
- **Human-in-the-loop systems** — pause for review, resume on demand

---

## How it works

```
Input State
     │
     ▼
 [Node A] ──── condition ────► [Node B]
     │                              │
     └──── else ──────────────► [Node C]
                                    │
                                    ▼
                               Output State
```

Each **node** is a function that reads from state and writes to state. **Edges** connect nodes — fixed or conditional. The **engine** executes the graph, handles retries, persists checkpoints, and emits traces.

---

## Quick example

=== "Python"

    ```python
    from flowgentra_ai.graph import StateGraph, END
    from flowgentra_ai import State
    from flowgentra_ai.llm import LLMConfig, LLMClient, Message

    client = LLMClient.from_config(LLMConfig("openai", "gpt-4", api_key="sk-..."))

    def answer(state):
        response = client.chat([Message.user(state["question"])])
        state["answer"] = response.content
        return state

    builder = StateGraph()
    builder.add_node("answer", answer)
    builder.set_entry_point("answer")
    builder.add_edge("answer", END)
    graph = builder.compile()

    result = graph.invoke(State({"question": "What is Rust?"}))
    print(result["answer"])
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::{StateGraph, DynState};
    use flowgentra_ai::llm::{LLMConfig, LLMClient, Message};

    #[tokio::main]
    async fn main() -> anyhow::Result<()> {
        let client = LLMClient::from_config(LLMConfig::openai("gpt-4", "sk-..."));

        let graph = StateGraph::builder()
            .add_node("answer", move |mut state: DynState| {
                let client = client.clone();
                async move {
                    let q        = state.get_string("question").unwrap_or_default();
                    let response = client.chat(vec![Message::user(q)]).await?;
                    state.set("answer", response.content);
                    Ok(state)
                }
            })
            .entry("answer")
            .edge("answer", "__end__")
            .build();

        let mut state = DynState::new();
        state.set("question", "What is Rust?");
        let result = graph.invoke(state).await?;
        println!("{}", result.get_string("answer").unwrap());
        Ok(())
    }
    ```

---

## Documentation

| Section | Description |
|---------|-------------|
| [Installation](getting-started/installation.md) | Rust and Python setup |
| [Quick Start](getting-started/quickstart.md) | Working code in 5 minutes |
| [What is Flowgentra?](core-concepts/what-is-flowgentra.md) | Architecture overview |
| [State Management](core-concepts/state.md) | How state works |
| [Graph Execution](core-concepts/graphs.md) | How graphs execute |
| [Nodes](core-concepts/nodes.md) | All node types |
| **Guides** | |
| [Agents](guides/agents.md) | ZeroShotReAct, FewShot, Conversational, config-driven |
| [LLM Client](guides/llm-client.md) | Providers, retry, cache, fallback, structured output |
| [Tools](guides/tools.md) | Local tools, MCP, tool loop pattern |
| [RAG Pipeline](guides/rag.md) | Split, embed, index, retrieve, rerank |
| [Memory](guides/memory.md) | Conversation memory, checkpointing |
| [Supervisor](guides/supervisor.md) | 11 multi-agent orchestration strategies |
| [Human-in-the-Loop](guides/human-in-the-loop.md) | Interrupt, review, resume |
| [Observability](guides/observability.md) | Tracing, visualization, logging |
| **API Reference** | |
| [State](api/state.md) | State, PlainState |
| [Graph](api/graph.md) | StateGraph, MessageGraphBuilder, END |
| [Agent](api/agent.md) | AgentBuilder, AgentType, MemoryAwareAgent |
| [LLM](api/llm.md) | LLMClient, LLMConfig, Message, ToolDefinition |
| [Tools](api/tools.md) | ToolRegistry, JsonSchema, ToolNode |
| [RAG](api/rag.md) | Embeddings, VectorStore, Retriever, Document |
| [Memory](api/memory.md) | ConversationMemory, TokenBufferMemory, SummaryMemory |
| [Supervisor](api/supervisor.md) | Supervisor, SupervisorNodeConfig, OrchestrationStrategy |
| [Observability](api/observability.md) | ExecutionTracer, ExecutionTrace, init_tracing |
| [Utilities](api/utilities.md) | TextSplitters, PromptTemplate, OutputParsers, EvaluationNodeConfig |
| **Examples** | |
| [Chatbot](examples/chatbot.md) | Multi-user conversational agent |
| [RAG Agent](examples/rag-agent.md) | Knowledge base Q&A |
| [Multi-Agent](examples/multi-agent.md) | Research → Analysis → Writing pipeline |
| [Best Practices](best-practices.md) | Patterns for production |
| [FAQ](faq.md) | Common issues and solutions |
