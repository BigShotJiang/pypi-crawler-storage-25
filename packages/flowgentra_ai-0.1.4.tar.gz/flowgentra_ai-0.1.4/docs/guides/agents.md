# Agents

An **agent** is a graph that loops: it reasons, picks an action (usually a tool call or an LLM call), observes the result, and repeats — until it has a final answer.

Flowgentra gives you prebuilt agents for the most common patterns, so you don't have to build the loop from scratch.

---

## The five ways to create an agent

| Method | Best for |
|--------|----------|
| `AgentBuilder` + `ZeroShotReAct` | General-purpose tool-using agent |
| `AgentBuilder` + `FewShotReAct` | Specialized domain with example shots |
| `AgentBuilder` + `Conversational` | Multi-turn chat with memory |
| `Agent.from_config_path()` | Production, YAML-configured workflows |
| `MemoryAwareAgent` | Multi-user chatbots with per-user memory |

---

## ZeroShotReAct

The classic ReAct (Reason + Act) loop. The agent reasons step by step, decides which tool to call, observes the result, and loops until it has an answer — all without needing example demonstrations.

=== "Python"

    ```python
    from flowgentra_ai.agent import AgentBuilder, AgentType, ToolSpec

    # Define the tools available to the agent
    search = ToolSpec("web_search", "Search the web for up-to-date information")
    search.add_parameter("query", "string")
    search.set_required("query")

    calc = ToolSpec("calculator", "Perform arithmetic calculations")
    calc.add_parameter("expression", "string")
    calc.set_required("expression")

    # Build the agent
    agent = (
        AgentBuilder(AgentType.zero_shot_react())
        .with_name("research-assistant")
        .with_llm_config("gpt-4")
        .with_tool(search)
        .with_tool(calc)
        .with_system_prompt("You are a helpful research assistant. Think step by step.")
        .with_temperature(0.2)        # lower = more deterministic reasoning
        .with_max_tokens(2000)
        .with_retries(3)              # retry failed LLM calls
        .build_graph()
    )

    answer = agent.execute_input("What is the population of France divided by 1000?")
    print(answer)
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::agents::{AgentBuilder, AgentType, ToolSpec};

    let search = ToolSpec::new("web_search", "Search the web")
        .param("query", "string", true);

    let calc = ToolSpec::new("calculator", "Perform arithmetic")
        .param("expression", "string", true);

    let agent = AgentBuilder::new(AgentType::ZeroShotReAct)
        .with_name("research-assistant")
        .with_llm("gpt-4", "sk-...")
        .with_tool(search)
        .with_tool(calc)
        .with_system_prompt("You are a helpful research assistant.")
        .with_temperature(0.2)
        .with_retries(3)
        .build()
        .await?;

    let answer = agent.execute("What is the population of France divided by 1000?").await?;
    println!("{answer}");
    ```

### How ZeroShotReAct works internally

```
User query
    │
    ▼
[LLM: Reason]   ←──────────────────────────────┐
    │                                           │
    ▼                                           │
Has tool calls?                                 │
    │                                           │
    ├── Yes ──► [Execute tools] ──► [Observe] ──┘
    │
    └── No ───► [Final answer]
```

The agent loops until the LLM decides it has enough information and produces a final answer (no tool calls).

---

## FewShotReAct

Same loop as ZeroShot, but the system prompt includes worked examples of reasoning steps. This dramatically improves accuracy for specialized domains.

=== "Python"

    ```python
    agent = (
        AgentBuilder(AgentType.few_shot_react())
        .with_name("finance-analyst")
        .with_llm_config("gpt-4")
        .with_tool(data_tool)
        .with_memory_steps(8)     # remember last 8 steps of reasoning
        .with_system_prompt("""
    You are a financial analyst. Here are examples of how you reason:

    Q: What was Apple's revenue growth last year?
    Thought: I need to look up Apple's revenue for 2023 and 2022.
    Action: search({"query": "Apple revenue 2023 2022 annual report"})
    Observation: Apple's 2023 revenue was $383B, 2022 was $394B.
    Thought: Growth = (383-394)/394 = -2.8%.
    Answer: Apple's revenue declined 2.8% last year.
    """)
        .build_graph()
    )

    answer = agent.execute_input("What was Microsoft's revenue growth in 2023?")
    ```

---

## Conversational

Multi-turn dialogue with persistent memory. The agent remembers previous messages in the conversation.

=== "Python"

    ```python
    agent = (
        AgentBuilder(AgentType.conversational())
        .with_name("assistant")
        .with_llm_config("gpt-4")
        .with_temperature(0.7)
        .with_max_tokens(800)
        .with_system_prompt("You are a friendly, helpful assistant.")
        .with_memory_steps(20)    # keep last 20 conversation turns in context
        .build_graph()
    )

    # The agent maintains context across calls
    r1 = agent.execute_input("My name is Alice and I work in London.")
    r2 = agent.execute_input("What city did I say I work in?")   # answers "London"
    r3 = agent.execute_input("What's my name?")                  # answers "Alice"
    ```

=== "Rust"

    ```rust
    let agent = AgentBuilder::new(AgentType::Conversational)
        .with_name("assistant")
        .with_llm("gpt-4", "sk-...")
        .with_temperature(0.7)
        .with_system_prompt("You are a friendly assistant.")
        .with_memory_steps(20)
        .build()
        .await?;

    agent.execute("My name is Alice and I work in London.").await?;
    let r = agent.execute("What city do I work in?").await?;
    println!("{r}");  // "London"
    ```

---

## Config-driven agent

Define the graph structure in YAML and write handler functions in code. The engine auto-discovers handlers by name.

### handler.py / handler.rs

=== "Python"

    ```python
    # handlers.py
    from flowgentra_ai.handlers import register_handler

    @register_handler
    async def fetch_data(state):
        state["data"] = call_api(state.get("query"))
        return state

    @register_handler
    async def generate_response(state):
        from flowgentra_ai.llm import LLMClient, LLMConfig, Message
        client = LLMClient.from_config(LLMConfig("openai", "gpt-4", api_key="sk-..."))
        response = client.chat([Message.user(state["data"])])
        state["response"] = response.content
        return state
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::handlers::register_handler;

    #[register_handler]
    async fn fetch_data(mut state: DynState) -> Result<DynState> {
        state.set("data", call_api(&state.get_string("query").unwrap()).await?);
        Ok(state)
    }

    #[register_handler]
    async fn generate_response(mut state: DynState) -> Result<DynState> {
        let client = LLMClient::from_config(LLMConfig::openai("gpt-4", "sk-..."));
        let data = state.get_string("data").unwrap_or_default();
        let response = client.chat(vec![Message::user(data)]).await?;
        state.set("response", response.content);
        Ok(state)
    }
    ```

### agent.yaml

```yaml
name: my-agent
handlers:
  - fetch_data
  - generate_response
graph:
  entry: fetch_data
  edges:
    - from: fetch_data
      to: generate_response
    - from: generate_response
      to: __end__
```

### Running it

=== "Python"

    ```python
    from flowgentra_ai.agent import Agent

    agent = Agent.from_config_path("agent.yaml")
    agent.set_state("query", "What is Rust?")
    result = agent.run()
    print(result["response"])

    # With checkpointing
    result = agent.run_with_thread("session-123")
    ```

=== "Rust"

    ```rust
    let agent = Agent::from_config_path("agent.yaml").await?;
    agent.set_state("query", "What is Rust?");
    let result = agent.run().await?;
    println!("{}", result.get_string("response").unwrap());
    ```

---

## MemoryAwareAgent (Python)

High-level wrapper for multi-user conversations. Each user gets their own thread with isolated memory.

```python
from flowgentra_ai.agent import MemoryAwareAgent

agent = MemoryAwareAgent.from_config("agent.yaml")

# User Alice
agent.set_thread_id("user_alice")
response = agent.run_turn("Hello! My name is Alice.")
response = agent.run_turn("What's my name?")   # remembers "Alice"

# User Bob — completely separate conversation
agent.set_thread_id("user_bob")
response = agent.run_turn("Hi! I'm Bob.")

# Check memory usage
stats = agent.memory_stats()
print(f"{stats.message_count} messages, ~{stats.approximate_tokens} tokens")

# Get current thread
agent.thread_id()   # "user_bob"

# Clear a user's memory
agent.clear_memory()
```

---

## Adding tools to AgentBuilder

`ToolSpec` lets you describe a tool's interface. The actual implementation is handled by your `ToolRegistry` (or built-in tools).

=== "Python"

    ```python
    from flowgentra_ai.agent import ToolSpec

    # Basic tool
    tool = ToolSpec("get_weather", "Get current weather for a city")
    tool.add_parameter("city", "string")
    tool.add_parameter("unit", "string")    # "celsius" or "fahrenheit"
    tool.set_required("city")              # only city is required

    # Add to builder
    agent = (
        AgentBuilder(AgentType.zero_shot_react())
        .with_tool(tool)
        ...
    )
    ```

---

## Choosing the right agent type

| You want to... | Use |
|----------------|-----|
| Give the agent tools and let it figure out when to use them | `ZeroShotReAct` |
| Improve accuracy in a specialized domain with examples | `FewShotReAct` |
| Build a chatbot that remembers past messages | `Conversational` |
| Configure the graph in YAML without recompiling | `Agent.from_config_path` |
| Support many users each with their own memory | `MemoryAwareAgent` |

A common mistake is using `ZeroShotReAct` when you don't actually need tools. If your agent always calls the LLM and responds directly, a simple graph node is simpler and faster.
