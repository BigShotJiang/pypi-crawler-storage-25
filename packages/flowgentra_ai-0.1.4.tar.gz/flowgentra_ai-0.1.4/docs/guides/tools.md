# Tools

Tools give your agent the ability to act — search the web, run calculations, call APIs, read files. Flowgentra supports **local tools** you define yourself and **MCP tools** from external tool servers.

---

## Local tools

### Built-in tools

Flowgentra ships with four built-in tools:

=== "Python"

    ```python
    from flowgentra_ai.tools import ToolRegistry, CalculatorTool, SearchTool, WebRequestTool, FilesTool

    # Create registry with all built-ins
    registry = ToolRegistry.with_builtins()
    print(registry.list_names())  # ["calculator", "search", "web_request", "files"]

    # Call a tool directly
    result = registry.call_tool("calculator", {"operation": "add", "a": 17, "b": 8})
    print(result)  # 25

    # Validate input without calling
    registry.validate_input("calculator", {"operation": "add", "a": 1, "b": 2})
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::tools::{ToolRegistry, CalculatorTool};

    let mut registry = ToolRegistry::new();
    registry.register(CalculatorTool::default());

    let result = registry.call("calculator", serde_json::json!({"operation": "add", "a": 17, "b": 8})).await?;
    println!("{result}");  // 25
    ```

| Tool | Description | Operations |
|------|-------------|------------|
| `CalculatorTool` | Basic arithmetic | add, subtract, multiply, divide |
| `SearchTool` | Web search | Returns text results |
| `WebRequestTool` | HTTP requests | GET/POST to any URL |
| `FilesTool` | File operations | read, write, list directory |

---

## Tools in a graph (LLM function calling loop)

The most common pattern is an LLM-tool loop: the LLM decides which tools to call, your code executes them, and the result goes back to the LLM.

=== "Python"

    ```python
    from flowgentra_ai.graph import StateGraph, END
    from flowgentra_ai.tools import ToolRegistry, create_tool_node
    from flowgentra_ai.llm import LLMConfig, LLMClient, Message, ToolDefinition
    from flowgentra_ai import State

    registry = ToolRegistry.with_builtins()
    client   = LLMClient.from_config(LLMConfig("openai", "gpt-4", api_key="sk-..."))

    # Describe tools to the LLM
    tools = [
        ToolDefinition("calculator", "Perform arithmetic", {
            "type": "object",
            "properties": {
                "operation": {"type": "string", "enum": ["add","subtract","multiply","divide"]},
                "a": {"type": "number"},
                "b": {"type": "number"},
            },
            "required": ["operation", "a", "b"],
        })
    ]

    def llm_node(state):
        messages = state.get("messages") or []
        response = client.chat_with_tools(messages, tools)
        state["messages"] = messages + [response]
        return state

    def tool_executor(state):
        messages = state.get("messages") or []
        last = messages[-1]
        results = []
        for tc in last.tool_calls():
            result = registry.call_tool(tc.name, tc.arguments)
            results.append(Message.tool(str(result), tool_call_id=tc.id))
        state["messages"] = messages + results
        return state

    def router(state):
        messages = state.get("messages") or []
        if messages and messages[-1].has_tool_calls():
            return "tools"
        return "__end__"

    builder = StateGraph()
    builder.add_node("llm",   llm_node)
    builder.add_node("tools", tool_executor)
    builder.set_entry_point("llm")
    builder.add_conditional_edge("llm", router)
    builder.add_edge("tools", "llm")   # loop back for final answer
    graph = builder.compile()

    result = graph.invoke(State({
        "messages": [
            Message.system("You are a helpful math assistant."),
            Message.user("What is (17 * 8) + 45?"),
        ]
    }))

    # Print final assistant response
    for msg in result["messages"]:
        if msg.is_assistant() and not msg.has_tool_calls():
            print(msg.content)
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::{StateGraph, DynState};
    use flowgentra_ai::llm::{LLMClient, LLMConfig, Message, ToolDefinition};
    use flowgentra_ai::tools::ToolRegistry;
    use serde_json::json;

    let registry = ToolRegistry::with_builtins();
    let client   = LLMClient::from_config(LLMConfig::openai("gpt-4", "sk-..."));

    let tools = vec![
        ToolDefinition {
            name: "calculator".to_string(),
            description: "Perform arithmetic".to_string(),
            parameters: json!({
                "type": "object",
                "properties": {
                    "operation": {"type": "string"},
                    "a": {"type": "number"},
                    "b": {"type": "number"}
                },
                "required": ["operation","a","b"]
            }),
        }
    ];

    let graph = StateGraph::builder()
        .add_node("llm", move |mut state: DynState| {
            let client = client.clone();
            let tools  = tools.clone();
            async move {
                let messages: Vec<Message> = state.get_array("messages").unwrap_or_default();
                let response = client.chat_with_tools(messages.clone(), tools).await?;
                let mut all = messages;
                all.push(response);
                state.set("messages", all);
                Ok(state)
            }
        })
        .add_node("tools", move |mut state: DynState| {
            let registry = registry.clone();
            async move {
                let messages: Vec<Message> = state.get_array("messages").unwrap_or_default();
                let last = messages.last().unwrap();
                let mut tool_results = vec![];
                for tc in last.tool_calls() {
                    let result = registry.call(&tc.name, tc.arguments.clone()).await?;
                    tool_results.push(Message::tool(result.to_string(), &tc.id));
                }
                let mut all = messages;
                all.extend(tool_results);
                state.set("messages", all);
                Ok(state)
            }
        })
        .entry("llm")
        .conditional_edge("llm", |state: &DynState| {
            let msgs: Vec<Message> = state.get_array("messages").unwrap_or_default();
            if msgs.last().map(|m| m.has_tool_calls()).unwrap_or(false) {
                "tools"
            } else {
                "__end__"
            }
        })
        .edge("tools", "llm")
        .build();
    ```

---

## JSON Schema for tools

Use `JsonSchema` to build tool input schemas programmatically instead of writing raw JSON.

=== "Python"

    ```python
    from flowgentra_ai.tools import JsonSchema

    schema = (
        JsonSchema.object()
        .with_description("Weather query parameters")
        .with_required(["city"])
    )

    # All primitive types
    JsonSchema.string()
    JsonSchema.number()
    JsonSchema.integer()
    JsonSchema.boolean()
    JsonSchema.array()

    # Validate a value against the schema
    schema.validate({"city": "Paris"})   # passes
    schema.validate({})                  # raises — city is required
    ```

---

## MCP tools (external tool servers)

MCP (Model Context Protocol) lets you connect to external tool servers. This is useful when your tools live in a separate process or are provided by a third party.

### SSE transport (HTTP-based)

=== "Python"

    ```python
    from flowgentra_ai.types import MCPConfig

    config = MCPConfig(
        transport="sse",
        url="http://localhost:8080/sse",
    )
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::mcp::{MCPConfig, MCPConnectionType};

    let config = MCPConfig {
        transport: MCPConnectionType::Sse {
            url: "http://localhost:8080/sse".to_string(),
        },
        ..Default::default()
    };
    ```

### Stdio transport (subprocess)

```rust
// Rust
let config = MCPConfig {
    transport: MCPConnectionType::Stdio {
        command: "python".to_string(),
        args: vec!["tools_server.py".to_string()],
    },
    ..Default::default()
};
```

### Auto-reconnecting client

For long-running agents, use the reconnecting client — it automatically recovers from dropped connections.

=== "Rust"

    ```rust
    use flowgentra_ai::mcp::ReconnectingMCPClient;

    let client = ReconnectingMCPClient::new(config)
        .connect()
        .await?;

    // List available tools
    let tools = client.list_tools().await?;

    // Call a tool
    let result = client.call_tool("my_tool", json!({"param": "value"})).await?;
    ```

### MCP in YAML config

```yaml
# agent.yaml
tools:
  mcp:
    - name: my_tools
      transport: sse
      url: "http://localhost:8080/sse"
```

---

## ToolNode (convenience helper)

`create_tool_node` wraps a registry into a graph node. It automatically finds tool calls in the last message and executes them.

=== "Python"

    ```python
    from flowgentra_ai.tools import create_tool_node

    registry = ToolRegistry.with_builtins()
    tool_node = create_tool_node(registry)

    builder.add_node("tools", tool_node)
    ```

This is equivalent to the manual executor in the LLM loop example above, but shorter.

---

## Concurrent tool execution

When the LLM makes multiple tool calls at once, you can execute them in parallel:

=== "Rust"

    ```rust
    use futures::future::join_all;

    let futures: Vec<_> = tool_calls
        .iter()
        .map(|tc| registry.call(&tc.name, tc.arguments.clone()))
        .collect();

    let results = join_all(futures).await;
    ```

=== "Python"

    ```python
    import asyncio

    async def execute_tools_parallel(tool_calls, registry):
        tasks = [
            asyncio.create_task(registry.call_tool_async(tc.name, tc.arguments))
            for tc in tool_calls
        ]
        return await asyncio.gather(*tasks)
    ```
