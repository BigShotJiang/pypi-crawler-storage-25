# Multi-Agent Supervisor

When one agent isn't enough, you can compose multiple agent graphs under a **Supervisor** that decides which agent to call and when to stop.

Flowgentra's Supervisor has two modes:
- **Simple mode** — a Python/Rust router function you write
- **Strategy mode** — one of 11 built-in orchestration strategies

---

## Simple mode (router function)

Write a function that looks at state and returns the next agent's name, or `"FINISH"` to stop.

=== "Python"

    ```python
    from flowgentra_ai.supervision import Supervisor
    from flowgentra_ai import State

    def router(state):
        task = state.get_string("task") or ""
        if "research" in task:
            return "researcher"
        if "write" in task:
            return "writer"
        if state.get("research_done") and state.get("draft_done"):
            return "FINISH"
        return "researcher"   # default

    sup = Supervisor(router)
    sup.add_agent("researcher", research_graph)   # StateGraph or callable
    sup.add_agent("writer",     writer_graph)
    sup.max_rounds(10)          # prevent infinite loops
    sup.finish_marker("FINISH") # default is "FINISH"

    result = sup.run(State({"task": "research AI trends and write a summary"}))
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::agents::Supervisor;

    let sup = Supervisor::new(|state: &DynState| {
        let task = state.get_string("task").unwrap_or_default();
        if task.contains("research") { "researcher" }
        else if task.contains("write") { "writer" }
        else { "FINISH" }
    })
    .add_agent("researcher", research_graph)
    .add_agent("writer",     writer_graph)
    .max_rounds(10);

    let result = sup.run(initial_state).await?;
    ```

---

## Strategy mode (config-based)

Use `SupervisorNodeConfig` with a built-in strategy for more complex orchestration.

### Parallel — run all agents at once

All agents run simultaneously. Results are merged when all finish.

=== "Python"

    ```python
    from flowgentra_ai.supervision import (
        Supervisor, SupervisorNodeConfig,
        OrchestrationStrategy, ParallelMergeStrategy,
    )

    config = SupervisorNodeConfig(
        "coordinator",
        children=["researcher", "analyst", "writer"],
        strategy=OrchestrationStrategy.parallel(),
    )
    config.set_child_timeout_ms(30_000)   # 30s per child
    config.set_merge_strategy(ParallelMergeStrategy.latest())
    config.set_collect_stats(True)        # enable per-child timing stats

    sup = Supervisor.from_config(config)
    sup.add_agent("researcher", research_graph)
    sup.add_agent("analyst",   analyst_graph)
    sup.add_agent("writer",    writer_graph)

    result = sup.run(State({"topic": "AI trends 2024"}))
    ```

### Sequential — run agents as a pipeline

Agents run one after another, each receiving the output of the previous.

```python
config = SupervisorNodeConfig(
    "pipeline",
    children=["extract", "transform", "load"],
    strategy=OrchestrationStrategy.sequential(),
)
config.set_fail_fast(True)   # stop the whole pipeline on first failure
```

### Retry fallback — try agents until one succeeds

```python
config = SupervisorNodeConfig(
    "resilient",
    children=["primary_api", "backup_api", "local_fallback"],
    strategy=OrchestrationStrategy.retry_fallback(),
)
config.set_fallback_order(["primary_api", "backup_api", "local_fallback"])
```

### MapReduce — split input, process in parallel, merge

```python
config = SupervisorNodeConfig(
    "batch",
    children=["worker_a", "worker_b", "worker_c"],
    strategy=OrchestrationStrategy.map_reduce(),
)
config.set_map_key("input_chunks")   # state key holding a JSON array to split
config.set_reduce_key("results")     # state key for merged output
```

### Conditional routing — route based on state

```python
config = SupervisorNodeConfig(
    "smart_router",
    children=["code_agent", "writing_agent", "math_agent"],
    strategy=OrchestrationStrategy.conditional_routing(),
)
config.add_routing_rule("task_type == code",    "code_agent")
config.add_routing_rule("task_type == writing", "writing_agent")
config.add_routing_rule("task_type == math",    "math_agent")
# First matching rule wins; if none match, the first child is used
```

### Broadcast — send to all, pick best result

```python
config = SupervisorNodeConfig(
    "best_of_three",
    children=["agent_a", "agent_b", "agent_c"],
    strategy=OrchestrationStrategy.broadcast(),
)
config.set_selection_criteria("highest_score")   # or "first_success"
config.set_score_key("confidence")               # state key with quality score (0–1)
```

### Debate — agents critique each other

```python
config = SupervisorNodeConfig(
    "debate",
    children=["optimist", "pessimist", "realist"],
    strategy=OrchestrationStrategy.debate(),
)
config.set_debate_rounds(3)       # number of critique rounds
config.set_debate_key("question") # state key with the topic
```

### Round robin — distribute tasks across agents

```python
config = SupervisorNodeConfig(
    "load_balancer",
    children=["worker_1", "worker_2", "worker_3"],
    strategy=OrchestrationStrategy.round_robin(),
)
config.set_tasks_key("tasks")   # state["tasks"] should be a JSON array
```

### Autonomous — loop until goal is met

```python
config = SupervisorNodeConfig(
    "autonomous",
    children=["researcher", "analyst", "synthesizer"],
    strategy=OrchestrationStrategy.autonomous(),
)
config.set_goal("Produce a complete market analysis report")
config.set_required_outputs(["raw_data", "analysis", "final_report"])
config.add_output_owner("raw_data",     "researcher")
config.add_output_owner("analysis",     "analyst")
config.add_output_owner("final_report", "synthesizer")
config.set_max_iterations(10)
```

### Dynamic — LLM picks the next agent

```python
config = SupervisorNodeConfig(
    "llm_orchestrator",
    children=["researcher", "coder", "writer"],
    strategy=OrchestrationStrategy.dynamic(),
)
config.set_selector_prompt(
    "You are an orchestrator. Based on the current state, pick the next agent to call."
)
config.set_max_iterations(5)
```

---

## All 11 strategies at a glance

| Strategy | Best for |
|----------|----------|
| `sequential` | Dependent pipeline steps (A → B → C) |
| `parallel` | Independent tasks, want maximum speed |
| `autonomous` | Goal-directed, loop until all outputs present |
| `dynamic` | LLM decides who runs next |
| `round_robin` | Load balancing across interchangeable workers |
| `hierarchical` | Large tasks with sub-supervisors |
| `broadcast` | High-accuracy tasks — pick the best answer |
| `map_reduce` | Batch processing with fan-out + merge |
| `conditional_routing` | Route by task type |
| `retry_fallback` | Fault tolerance — try next agent if current fails |
| `debate` | High-stakes tasks — multi-agent critique improves quality |

---

## Agents as callables

You can register any callable as an agent, not just compiled graphs:

=== "Python"

    ```python
    def simple_agent(state):
        state["result"] = "processed by simple agent"
        return state

    sup.add_agent("simple", simple_agent)
    ```

---

## Collecting execution stats

=== "Python"

    ```python
    config.set_collect_stats(True)

    result = sup.run(initial_state)

    # Stats are stored in state under "_child_stats"
    stats = result.get("_child_stats") or []
    for s in stats:
        print(f"{s['name']}: {s['duration_ms']}ms, success={s['success']}")
    ```

---

## Skipping children conditionally

=== "Python"

    ```python
    config.add_skip_condition("writer", "skip_writing == true")
    # Writer is skipped when state["skip_writing"] is truthy
    ```
