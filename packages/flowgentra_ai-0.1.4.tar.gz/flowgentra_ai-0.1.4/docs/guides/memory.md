# Memory & Conversations

Memory in Flowgentra has two distinct concerns:

- **Conversation memory** — storing the messages in a chat session
- **Checkpointing** — persisting the entire graph state so you can resume or recover

---

## Conversation memory

### ConversationMemory

The simplest option. Stores messages in-memory per thread. Add an optional `max_messages` to create a sliding window.

=== "Python"

    ```python
    from flowgentra_ai.memory import ConversationMemory
    from flowgentra_ai.llm import Message

    mem = ConversationMemory(max_messages=100)   # None = unlimited

    # Add messages to a thread
    thread = "user-alice"
    mem.add_message(thread, Message.user("Hello!"))
    mem.add_message(thread, Message.assistant("Hi Alice!"))
    mem.add_message(thread, Message.user("What is Rust?"))

    # Retrieve (oldest first)
    messages = mem.messages(thread)            # all messages
    messages = mem.messages(thread, limit=5)  # last 5 messages

    # Clear a thread
    mem.clear(thread)
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::memory::{InMemoryConversationMemory, ConversationMemory};
    use flowgentra_ai::llm::Message;

    let mut mem = InMemoryConversationMemory::new(Some(100));

    mem.add("user-alice", Message::user("Hello!")).await;
    mem.add("user-alice", Message::assistant("Hi Alice!")).await;

    let messages = mem.get("user-alice", None).await;
    ```

### TokenBufferMemory

Stays within a token budget. When history exceeds the budget, the oldest messages are dropped.

=== "Python"

    ```python
    from flowgentra_ai.memory import TokenBufferMemory

    mem = TokenBufferMemory(max_tokens=2000)

    mem.add_message("thread-1", Message.user("Hello"))
    mem.add_message("thread-1", Message.assistant("Hi!"))
    # When budget exceeded, oldest messages are dropped automatically

    messages = mem.messages("thread-1")
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::memory::{TokenBufferMemory, BufferWindowConfig};

    let mem = TokenBufferMemory::new(BufferWindowConfig { max_tokens: 2000 });
    ```

### SummaryMemory

Instead of dropping old messages, summarizes them with an LLM. The summary replaces old messages — you keep the semantic content while using fewer tokens.

=== "Python"

    ```python
    from flowgentra_ai.memory import SummaryMemory, SummaryConfig
    from flowgentra_ai.llm import LLMConfig

    config = SummaryConfig(
        llm_config=LLMConfig("openai", "gpt-3.5-turbo", api_key="sk-..."),
        summary_threshold=20,   # summarize when history exceeds 20 messages
    )
    mem = SummaryMemory(config)

    # Use it like ConversationMemory
    mem.add_message("thread-1", Message.user("Tell me about Rust."))
    # ... 20 more messages ...
    messages = mem.messages("thread-1")   # older messages replaced by a summary message
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::memory::{SummaryMemory, SummaryConfig};
    use flowgentra_ai::llm::LLMConfig;

    let config = SummaryConfig {
        llm_config: LLMConfig::openai("gpt-3.5-turbo", "sk-..."),
        summary_threshold: 20,
    };
    let mem = SummaryMemory::new(config);
    ```

### Which memory type to use?

| Type | Token cost | Context preservation | Use when |
|------|-----------|---------------------|----------|
| `ConversationMemory` | Grows unbounded | Perfect | Short sessions, < 50 messages |
| `TokenBufferMemory` | Capped | Loses old messages | Cost is a concern, recency matters |
| `SummaryMemory` | Capped | Summarized (good) | Long sessions, need full context |

---

## Using memory in a graph

Here's how to wire conversation memory into a chatbot node:

=== "Python"

    ```python
    from flowgentra_ai.graph import StateGraph, END
    from flowgentra_ai.memory import ConversationMemory
    from flowgentra_ai.llm import LLMConfig, LLMClient, Message
    from flowgentra_ai import State

    mem    = ConversationMemory(max_messages=50)
    client = LLMClient.from_config(LLMConfig("openai", "gpt-4", api_key="sk-..."))

    def chat(state):
        thread = state["thread_id"]
        user_msg = Message.user(state["user_input"])
        mem.add_message(thread, user_msg)

        history  = mem.messages(thread)
        response = client.chat([
            Message.system("You are a helpful assistant."),
            *history,
        ])

        mem.add_message(thread, response)
        state["reply"] = response.content
        return state

    builder = StateGraph()
    builder.add_node("chat", chat)
    builder.set_entry_point("chat")
    builder.add_edge("chat", END)
    graph = builder.compile()

    # Turn 1
    r1 = graph.invoke(State({"thread_id": "u1", "user_input": "My name is Alice."}))

    # Turn 2 — agent remembers Alice
    r2 = graph.invoke(State({"thread_id": "u1", "user_input": "What's my name?"}))
    print(r2["reply"])   # "Your name is Alice."
    ```

---

## Checkpointing (graph-level persistence)

Checkpointing saves the entire graph state to disk after each node. This lets you:

- Resume a graph after a crash
- Implement human-in-the-loop review (pause the graph and resume later)
- Debug by replaying an execution

=== "Python"

    ```python
    # Enable checkpointing
    builder.set_checkpointer("./checkpoints")
    graph = builder.compile()

    # Run with a thread ID — state is saved after each node
    result = graph.invoke_with_thread("session-abc", State({"input": "data"}))

    # Resume (picks up from where it left off)
    result = graph.resume("session-abc")

    # Resume with state modifications (e.g., after human edit)
    result = graph.resume_with_state("session-abc", State({"draft": "edited draft"}))
    ```

=== "Rust"

    ```rust
    use flowgentra_ai::memory::FileCheckpointer;

    let graph = StateGraph::builder()
        .with_checkpointer(FileCheckpointer::new("./checkpoints"))
        // ... nodes
        .build();

    let result = graph.invoke_with_thread("session-abc", state).await?;
    let result = graph.resume("session-abc").await?;
    ```

### Checkpoint structure

Each checkpoint stores:

| Field | Description |
|-------|-------------|
| `state` | The full state dict at that point |
| `last_node` | Which node was last executed |
| `execution_path` | Full sequence of nodes executed |
| `extra` | Any metadata you attach |

### InMemoryCheckpointer (for testing)

=== "Rust"

    ```rust
    use flowgentra_ai::memory::InMemoryCheckpointer;

    let graph = StateGraph::builder()
        .with_checkpointer(InMemoryCheckpointer::new())
        .build();
    ```

---

## MemoryAwareAgent (high-level wrapper)

If you're building a multi-user chatbot, `MemoryAwareAgent` handles threading and memory management for you.

=== "Python"

    ```python
    from flowgentra_ai.agent import MemoryAwareAgent

    agent = MemoryAwareAgent.from_config("agent.yaml")

    # Each user_id gets isolated memory
    agent.set_thread_id("user_alice")
    r1 = agent.run_turn("Hello, my name is Alice.")
    r2 = agent.run_turn("What is my name?")   # "Alice"

    agent.set_thread_id("user_bob")
    r3 = agent.run_turn("Hi, I'm Bob.")       # fresh thread

    # Inspect memory usage
    stats = agent.memory_stats()
    print(f"{stats.message_count} total messages")
    print(f"{stats.user_messages} from user")
    print(f"{stats.assistant_messages} from assistant")
    print(f"~{stats.approximate_tokens} tokens")

    # Clear a user's memory
    agent.clear_memory()
    ```
