# Graph Workflows

Graphs are the core abstraction in FlowgentraAI. You define nodes (functions), connect them with edges, compile the graph, and invoke it with state.

## Building a Graph

```python
from flowgentra_ai.graph import StateGraph as StateGraphBuilder, END
from flowgentra_ai import State

def step_a(state):
    state["a"] = True
    return state

def step_b(state):
    state["b"] = True
    return state

builder = StateGraphBuilder()
builder.add_node("step_a", step_a)
builder.add_node("step_b", step_b)
builder.set_entry_point("step_a")
builder.add_edge("step_a", "step_b")
builder.add_edge("step_b", END)
graph = builder.compile()
```

### Node functions

Every node function must:

1. Accept a single `State` argument
2. Return a `State` (typically the same one, modified)

```python
def my_node(state: State) -> State:
    state["result"] = do_something(state["input"])
    return state
```

### Edge types

| Method | Description |
|--------|-------------|
| `add_edge(from, to)` | Fixed edge -- always goes from one node to another |
| `add_conditional_edge(from, router_fn)` | Dynamic routing based on state |
| `add_edge(from, END)` | Terminates the graph |

### Conditional edges

The router function receives state and returns the name of the next node (or `"__end__"`):

```python
def router(state):
    score = state["score"]
    if score > 0.8:
        return "accept"
    elif score > 0.5:
        return "review"
    return "reject"

builder.add_conditional_edge("evaluate", router)
```

## Invoking a Graph

```python
# Basic invoke
result = graph.invoke(State({"input": "data"}))

# With thread ID for checkpointing
result = graph.invoke_with_thread("thread-123", State({"input": "data"}))
```

## Inspecting a Graph

```python
graph.node_names()     # ["step_a", "step_b"]
graph.entry_point()    # "step_a"
graph.to_mermaid()     # Mermaid diagram string
graph.to_dot()         # Graphviz DOT string
graph.to_json()        # JSON structure
```

## Max Steps

Prevent infinite loops by setting a maximum number of steps:

```python
builder.set_max_steps(50)  # default is 1000
```

## Subgraphs

Compose graphs by embedding one graph inside another:

```python
# Build inner graph
inner_builder = StateGraphBuilder()
inner_builder.add_node("process", process_fn)
inner_builder.set_entry_point("process")
inner_builder.add_edge("process", END)
inner_graph = inner_builder.compile()

# Embed as a node in outer graph
outer_builder = StateGraphBuilder()
outer_builder.add_node("prepare", prepare_fn)
outer_builder.add_subgraph("inner", inner_graph)
outer_builder.set_entry_point("prepare")
outer_builder.add_edge("prepare", "inner")
outer_builder.add_edge("inner", END)
outer_graph = outer_builder.compile()

result = outer_graph.invoke(State({"data": "..."}))
```

## Checkpointing

Persist graph state to disk for recovery and human-in-the-loop:

```python
builder.set_checkpointer("./checkpoints")
graph = builder.compile()

# Invoke with a thread ID
result = graph.invoke_with_thread("thread-1", State({"input": "data"}))
```

See [Human-in-the-Loop](human-in-the-loop.md) for interrupt/resume patterns.

## Built-in Node Types

The builder offers specialized methods for common patterns:

### Retry Node

Automatically retries a function with exponential backoff:

```python
def flaky_fetch(state):
    # may fail intermittently
    data = fetch_api(state["url"])
    state["data"] = data
    return state

builder.add_retry_node("fetch", flaky_fetch, max_retries=3, backoff_ms=1000)
```

### Timeout Node

Enforces a time limit on a function:

```python
builder.add_timeout_node("slow_op", slow_fn, timeout_ms=5000, on_timeout="skip")
# on_timeout="error" raises an error; "skip" returns the original state
```

### LLM Node

Reads a prompt from state, calls the LLM, writes the response:

```python
from flowgentra_ai.llm import LLMClient, LLMConfig

client = LLMClient.from_config(LLMConfig("openai", "gpt-4", api_key="sk-..."))

builder.add_llm_node(
    "generate",
    client,
    prompt_key="user_query",
    output_key="llm_response",
    system_prompt="You are a helpful assistant.",
)
```

### Planner Node

LLM-driven dynamic routing. The planner reads `_reachable_nodes` from state and sets `_next_node`:

```python
builder.add_planner_node("planner", client)
```

### Evaluation Node

Iteratively refines output until a quality threshold:

```python
from flowgentra_ai.graph import EvaluationNodeConfig

config = EvaluationNodeConfig(
    name="refine",
    field_state="draft",
    min_confidence=0.85,
    max_retries=3,
    rubric="Is the writing clear and well-structured?",
)

def my_scorer(output, attempt):
    # Return (score 0-1, feedback string)
    if len(str(output)) > 100:
        return (0.9, "Good length")
    return (0.4, "Too short, expand the content")

builder.add_evaluation_node(handler=refine_fn, config=config, scorer=my_scorer)
```

## Message Graph

For chat-focused workflows, `MessageGraphBuilder` pre-configures message accumulation:

```python
from flowgentra_ai.graph import MessageGraphBuilder
from flowgentra_ai.llm import Message

def echo(messages):
    """Receives list of Messages, returns list of Messages."""
    last = messages[-1]
    return messages + [Message.assistant(f"Echo: {last.content}")]

builder = MessageGraphBuilder()
builder.add_node("echo", echo)
builder.set_entry_point("echo")
builder.add_edge("echo", "__end__")
graph = builder.compile()

result = graph.invoke([Message.user("Hello")])
for msg in result:
    print(f"{msg.role}: {msg.content}")
```
