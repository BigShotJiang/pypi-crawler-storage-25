//! Python bindings for ToolRegistry and related types

use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};
use std::sync::Arc;

use flowgentra_ai::core::tools::{ToolRegistry, JsonSchema, Tool};

use crate::error::to_py_err;
use crate::get_runtime;
use crate::{json_to_py, py_to_json};
use crate::builtin_tools::{PyCalculatorTool, PySearchTool, PyWebRequestTool, PyFilesTool};

// ─── Helper Function for Tool Extraction ────────────────────────────────────

/// Extract Arc<dyn Tool> from various Python tool types
fn extract_tool_arc(obj: &Bound<'_, PyAny>) -> PyResult<Arc<dyn Tool>> {
    use pyo3::types::PyAnyMethods;

    // Try CalculatorTool
    if let Ok(tool) = obj.extract::<PyRef<PyCalculatorTool>>() {
        return Ok(tool.inner.clone());
    }

    // Try SearchTool
    if let Ok(tool) = obj.extract::<PyRef<PySearchTool>>() {
        return Ok(tool.inner.clone());
    }

    // Try WebRequestTool
    if let Ok(tool) = obj.extract::<PyRef<PyWebRequestTool>>() {
        return Ok(tool.inner.clone());
    }

    // Try FilesTool
    if let Ok(tool) = obj.extract::<PyRef<PyFilesTool>>() {
        return Ok(tool.inner.clone());
    }

    Err(pyo3::exceptions::PyTypeError::new_err(
        "Tool must be a CalculatorTool, SearchTool, WebRequestTool, or FilesTool",
    ))
}

// ─── PyJsonSchema ──────────────────────────────────────────────────────────

/// JSON Schema for tool input/output validation.
///
/// Example:
///     schema = JsonSchema.object()
///     schema.description = "Calculator input"
#[pyclass(name = "JsonSchema")]
#[derive(Clone)]
pub struct PyJsonSchema {
    pub(crate) inner: JsonSchema,
}

#[pymethods]
impl PyJsonSchema {
    /// Create an object schema.
    #[staticmethod]
    fn object() -> Self {
        PyJsonSchema { inner: JsonSchema::object() }
    }

    /// Create a string schema.
    #[staticmethod]
    fn string() -> Self {
        PyJsonSchema { inner: JsonSchema::string() }
    }

    /// Create a number schema.
    #[staticmethod]
    fn number() -> Self {
        PyJsonSchema { inner: JsonSchema::number() }
    }

    /// Create an integer schema.
    #[staticmethod]
    fn integer() -> Self {
        PyJsonSchema { inner: JsonSchema::integer() }
    }

    /// Create a boolean schema.
    #[staticmethod]
    fn boolean() -> Self {
        PyJsonSchema { inner: JsonSchema::boolean() }
    }

    /// Create an array schema.
    #[staticmethod]
    fn array() -> Self {
        PyJsonSchema { inner: JsonSchema::array() }
    }

    /// Set description.
    fn with_description(&mut self, desc: &str) {
        self.inner.description = Some(desc.to_string());
    }

    /// Set required fields (for object schemas).
    fn with_required(&mut self, fields: Vec<String>) {
        self.inner.required = Some(fields);
    }

    /// Validate a value against this schema.
    fn validate(&self, value: &Bound<'_, PyAny>) -> PyResult<()> {
        let val = py_to_json(value)?;
        self.inner.validate(&val).map_err(to_py_err)
    }

    #[getter]
    fn schema_type(&self) -> String {
        self.inner.schema_type.clone()
    }

    #[getter]
    fn description(&self) -> Option<String> {
        self.inner.description.clone()
    }

    fn __repr__(&self) -> String {
        format!("JsonSchema(type='{}')", self.inner.schema_type)
    }
}

// ─── PyToolRegistry ────────────────────────────────────────────────────────

/// Central registry for managing tools.
///
/// Example:
///     registry = ToolRegistry.with_builtins()
///     print(registry.list_names())
///     result = registry.call_tool("calculator", {"operation": "add", "a": 2, "b": 3})
#[pyclass(name = "ToolRegistry")]
pub struct PyToolRegistry {
    inner: ToolRegistry,
}

#[pymethods]
impl PyToolRegistry {
    /// Create a tool registry with optional tools (Option D).
    ///
    /// Dict-based initialization with custom naming
    ///
    /// Args:
    ///     tools: Optional dict or list of Tool objects
    ///            - Dict: Maps custom names to Tool objects
    ///            - List: Uses tool's definition name
    ///
    /// Example:
    ///     # With dict (custom names)
    ///     registry = ToolRegistry(tools={
    ///         "calc": CalculatorTool(),
    ///         "web_search": SearchTool(),
    ///     })
    ///
    ///     # With list (auto-names from tool definitions)
    ///     registry = ToolRegistry(tools=[CalculatorTool(), SearchTool()])
    ///
    ///     # Empty registry
    ///     registry = ToolRegistry()
    #[new]
    #[pyo3(signature = (tools=None))]
    fn new(tools: Option<&Bound<'_, PyAny>>) -> PyResult<Self> {
        let mut registry = PyToolRegistry {
            inner: ToolRegistry::new(),
        };

        if let Some(tools_arg) = tools {
            // Check if it's a dict
            if let Ok(dict) = tools_arg.downcast::<PyDict>() {
                // Dictionary: custom names as keys
                for (key, value) in dict.iter() {
                    let name: String = key.extract()?;

                    // Try to get the Arc<dyn Tool> from various tool types
                    let tool_arc = extract_tool_arc(&value)?;

                    registry
                        .inner
                        .register(&name, tool_arc)
                        .map_err(to_py_err)?;
                }
            } else if let Ok(list) = tools_arg.downcast::<PyList>() {
                // List: auto-name from tool definition
                for item in list.iter() {
                    let tool_arc = extract_tool_arc(&item)?;
                    let def = tool_arc.definition();

                    registry
                        .inner
                        .register(&def.name, tool_arc)
                        .map_err(to_py_err)?;
                }
            } else {
                return Err(pyo3::exceptions::PyTypeError::new_err(
                    "tools must be a dict or list",
                ));
            }
        }

        Ok(registry)
    }

    /// Create a registry with all built-in tools pre-registered.
    #[staticmethod]
    fn with_builtins() -> Self {
        PyToolRegistry {
            inner: ToolRegistry::with_builtins(),
        }
    }

    /// Call a tool by name with JSON input.
    fn call_tool(&self, py: Python<'_>, name: &str, input: &Bound<'_, PyAny>) -> PyResult<PyObject> {
        let val = py_to_json(input)?;
        let rt = get_runtime();
        let result = rt
            .block_on(self.inner.call_tool(name, val))
            .map_err(to_py_err)?;
        json_to_py(py, &result)
    }

    /// Validate tool input without calling it.
    fn validate_input(&self, name: &str, input: &Bound<'_, PyAny>) -> PyResult<()> {
        let val = py_to_json(input)?;
        self.inner.validate_input(name, &val).map_err(to_py_err)
    }

    /// Get all tool definition names.
    fn list_names(&self) -> Vec<String> {
        self.inner
            .list_definitions()
            .into_iter()
            .map(|d| d.name)
            .collect()
    }

    /// Check if a tool is registered by name.
    fn has(&self, name: &str) -> bool {
        self.inner.has(name)
    }

    /// Get a tool definition by name (dict representation).
    fn get(&self, py: Python<'_>, name: &str) -> PyResult<Py<PyDict>> {
        let definition = self
            .inner
            .get_definition(name)
            .map_err(to_py_err)?;

        let dict = PyDict::new_bound(py);
        dict.set_item("name", &definition.name)?;
        dict.set_item("description", &definition.description)?;

        Ok(dict.into())
    }

    /// Get the number of registered tools.
    fn __len__(&self) -> usize {
        self.inner.len()
    }

    fn __repr__(&self) -> String {
        format!("ToolRegistry(tools={})", self.inner.len())
    }
}
