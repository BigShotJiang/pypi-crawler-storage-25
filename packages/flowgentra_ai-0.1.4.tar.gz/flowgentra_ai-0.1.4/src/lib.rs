//! Python bindings for FlowgentraAI via PyO3
//!
//! Exposes the core Rust library to Python through native extension module.

use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};
use serde_json::Value;

mod channel;
mod snapshot;
mod checkpointer;
mod py_reducers;
mod state;
mod agent;
mod agents;
mod llm;
mod llm_client;
mod config;
mod graph;
mod rag;
mod vector_store;
mod memory;
mod conversation_memory;
mod error;
mod tools;
mod tool_registry;
mod evaluation;
mod text_splitter;
mod prompt_parser;
mod message_graph;
mod supervisor;
mod routing;
mod observability;
mod mcp;
mod document_loader;
mod ingestion;
mod rag_eval;
mod reranker;
mod token_buffer_memory;
mod file_checkpointer;
mod chroma;
mod builtin_tools;
mod tool_node;
mod visualization;
mod advanced_nodes;
mod llm_reranker;
mod memory_aware_agent;
mod rag_config;
mod eval_config;
mod remaining;
mod planner_node;
mod builtin_node_bindings;
mod evaluation_node;

use agent::*;
use agents::*;
use llm::*;
use llm_client::*;
use config::*;
use graph::*;
use rag::*;
use vector_store::*;
use memory::*;
use conversation_memory::*;
use tools::*;
use tool_registry::*;
use evaluation::*;
use text_splitter::*;
use prompt_parser::*;
use message_graph::*;
use supervisor::*;
use routing::*;
use observability::*;
use mcp::*;
use document_loader::*;
use ingestion::*;
use rag_eval::*;
use reranker::*;
use token_buffer_memory::*;
use file_checkpointer::*;
use chroma::*;
use builtin_tools::*;
use tool_node::*;
use visualization::*;
use advanced_nodes::*;
use llm_reranker::*;
use memory_aware_agent::*;
use rag_config::*;
use eval_config::*;
use remaining::*;
use planner_node::*;
use builtin_node_bindings::*;
use evaluation_node::*;

// ─── Helpers ────────────────────────────────────────────────────────────────

/// Convert a serde_json::Value to a Python object
pub fn json_to_py(py: Python<'_>, val: &Value) -> PyResult<PyObject> {
    match val {
        Value::Null => Ok(py.None()),
        Value::Bool(b) => Ok(b.to_object(py)),
        Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                Ok(i.to_object(py))
            } else if let Some(f) = n.as_f64() {
                Ok(f.to_object(py))
            } else {
                Ok(py.None())
            }
        }
        Value::String(s) => Ok(s.to_object(py)),
        Value::Array(arr) => {
            let list = PyList::empty_bound(py);
            for item in arr {
                list.append(json_to_py(py, item)?)?;
            }
            Ok(list.into())
        }
        Value::Object(map) => {
            let dict = PyDict::new_bound(py);
            for (k, v) in map {
                dict.set_item(k, json_to_py(py, v)?)?;
            }
            Ok(dict.into())
        }
    }
}

/// Convert a Python object to serde_json::Value
pub fn py_to_json(obj: &Bound<'_, PyAny>) -> PyResult<Value> {
    if obj.is_none() {
        Ok(Value::Null)
    } else if let Ok(b) = obj.extract::<bool>() {
        Ok(Value::Bool(b))
    } else if let Ok(i) = obj.extract::<i64>() {
        Ok(Value::Number(i.into()))
    } else if let Ok(f) = obj.extract::<f64>() {
        Ok(serde_json::Number::from_f64(f)
            .map(Value::Number)
            .unwrap_or(Value::Null))
    } else if let Ok(s) = obj.extract::<String>() {
        Ok(Value::String(s))
    } else if let Ok(list) = obj.downcast::<PyList>() {
        let mut arr = Vec::new();
        for item in list.iter() {
            arr.push(py_to_json(&item)?);
        }
        Ok(Value::Array(arr))
    } else if let Ok(dict) = obj.downcast::<PyDict>() {
        let mut map = serde_json::Map::new();
        for (k, v) in dict.iter() {
            let key: String = k.extract()?;
            map.insert(key, py_to_json(&v)?);
        }
        Ok(Value::Object(map))
    } else {
        // Fallback: try string representation
        let s = obj.str()?.to_string();
        Ok(Value::String(s))
    }
}

/// Get or create a tokio runtime for blocking async calls
pub fn get_runtime() -> &'static tokio::runtime::Runtime {
    use std::sync::OnceLock;
    static RT: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RT.get_or_init(|| {
        tokio::runtime::Runtime::new().expect("Failed to create Tokio runtime")
    })
}

// ─── Python Module ──────────────────────────────────────────────────────────

/// FlowgentraAI Python module
#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // ── State Submodule ────────────────────────────────────────────────────────
    let state_module = PyModule::new_bound(m.py(), "state")?;
    state_module.add_class::<state::PyState>()?;
    state_module.add_class::<snapshot::PyStateSnapshot>()?;
    state_module.add_class::<checkpointer::PyMemoryCheckpointer>()?;
    state_module.add_class::<checkpointer::PyFileCheckpointer>()?;
    state_module.add_class::<py_reducers::PyAppendField>()?;
    state_module.add_class::<py_reducers::PyBinaryOperatorField>()?;
    m.add_submodule(&state_module)?;

    // ── Agent Submodule ────────────────────────────────────────────────────────
    let agent_module = PyModule::new_bound(m.py(), "agent")?;
    agent_module.add_class::<PyAgent>()?;
    agent_module.add_class::<PyAgentType>()?;
    agent_module.add_class::<PyToolSpec>()?;
    agent_module.add_class::<PyAgentBuilder>()?;
    agent_module.add_class::<PyGraphBasedAgent>()?;
    agent_module.add_class::<PyAgentConfig>()?;
    agent_module.add_class::<PyStateField>()?;
    m.add_submodule(&agent_module)?;

    // ── Graph Submodule ────────────────────────────────────────────────────────
    let graph_module = PyModule::new_bound(m.py(), "graph")?;
    graph_module.add_class::<PyStateGraphBuilder>()?;
    graph_module.add_class::<PyCompiledGraph>()?;
    graph_module.add("END", graph::PY_END)?;
    m.add_submodule(&graph_module)?;

    // ── LLM Submodule ─────────────────────────────────────────────────────────
    let llm_module = PyModule::new_bound(m.py(), "llm")?;
    llm_module.add_class::<PyLLMConfig>()?;
    llm_module.add_class::<PyResponseFormat>()?;
    llm_module.add_class::<PyMessage>()?;
    llm_module.add_class::<PyToolCall>()?;
    llm_module.add_class::<PyToolDefinition>()?;
    llm_module.add_class::<PyTokenUsage>()?;
    llm_module.add_class::<PyLLMClient>()?;
    llm_module.add_function(wrap_pyfunction!(py_estimate_tokens, &llm_module)?)?;
    llm_module.add_function(wrap_pyfunction!(py_model_pricing, &llm_module)?)?;
    m.add_submodule(&llm_module)?;

    // ── Tools Submodule ────────────────────────────────────────────────────────
    let tools_module = PyModule::new_bound(m.py(), "tools")?;
    tools_module.add_class::<PyToolCallRequest>()?;
    tools_module.add_class::<PyToolCallResult>()?;
    tools_module.add_class::<PyToolRegistry>()?;
    tools_module.add_class::<PyJsonSchema>()?;
    tools_module.add_class::<PyCalculatorTool>()?;
    tools_module.add_class::<PySearchTool>()?;
    tools_module.add_class::<PyWebRequestTool>()?;
    tools_module.add_class::<PyFilesTool>()?;
    tools_module.add_class::<PyToolNode>()?;
    tools_module.add_function(wrap_pyfunction!(tool_node::py_create_tool_node, &tools_module)?)?;
    tools_module.add_function(wrap_pyfunction!(tool_node::py_store_tool_calls, &tools_module)?)?;
    tools_module.add_function(wrap_pyfunction!(tool_node::py_check_tools_condition, &tools_module)?)?;
    m.add_submodule(&tools_module)?;

    // ── RAG Submodule ──────────────────────────────────────────────────────────
    let rag_module = PyModule::new_bound(m.py(), "rag")?;
    rag_module.add_class::<PyDocument>()?;
    rag_module.add_class::<PySearchResult>()?;
    rag_module.add_class::<PyTextChunk>()?;
    rag_module.add_class::<PyEmbeddings>()?;
    rag_module.add_class::<PyInMemoryVectorStore>()?;
    rag_module.add_class::<PyRetrievalConfig>()?;
    rag_module.add_class::<PyRetriever>()?;
    rag_module.add_class::<rag::PyPdfDocument>()?;
    rag_module.add_class::<PyVectorStoreType>()?;
    rag_module.add_class::<PyRAGConfig>()?;
    rag_module.add_class::<PyVectorStoreConfig>()?;
    rag_module.add_class::<PyEmbeddingsConfig>()?;
    rag_module.add_class::<PyRetrievalSettings>()?;
    rag_module.add_class::<PyPdfSettings>()?;
    rag_module.add_class::<PyRAGGraphConfig>()?;
    rag_module.add_class::<PyChromaStore>()?;
    rag_module.add_function(wrap_pyfunction!(rag::py_chunk_text_by_tokens, &rag_module)?)?;
    rag_module.add_function(wrap_pyfunction!(rag::py_extract_and_chunk, &rag_module)?)?;
    rag_module.add_function(wrap_pyfunction!(rag::py_extract_pdf, &rag_module)?)?;
    rag_module.add_function(wrap_pyfunction!(rag::py_bm25_score, &rag_module)?)?;
    rag_module.add_function(wrap_pyfunction!(rag::py_hybrid_merge, &rag_module)?)?;
    rag_module.add_function(wrap_pyfunction!(rag::py_dedup_by_id, &rag_module)?)?;
    rag_module.add_function(wrap_pyfunction!(rag::py_dedup_by_similarity, &rag_module)?)?;
    rag_module.add_function(wrap_pyfunction!(rag::py_decompose_query, &rag_module)?)?;
    m.add_submodule(&rag_module)?;

    // ── Memory Submodule ───────────────────────────────────────────────────────
    let memory_module = PyModule::new_bound(m.py(), "memory")?;
    memory_module.add_class::<PyCheckpoint>()?;
    memory_module.add_class::<PyCheckpointMetadata>()?;
    memory_module.add_class::<PyConversationMemory>()?;
    memory_module.add_class::<PyTokenBufferMemory>()?;
    memory_module.add_class::<PySummaryConfig>()?;
    memory_module.add_class::<PySummaryMemory>()?;
    m.add_submodule(&memory_module)?;

    // ── Text Processing Submodule ──────────────────────────────────────────────
    let text_module = PyModule::new_bound(m.py(), "text")?;
    text_module.add_class::<PyRecursiveCharacterTextSplitter>()?;
    text_module.add_class::<PyMarkdownTextSplitter>()?;
    text_module.add_class::<PyHTMLTextSplitter>()?;
    text_module.add_class::<PyTokenTextSplitter>()?;
    text_module.add_class::<PyCodeTextSplitter>()?;
    text_module.add_class::<PyPromptTemplate>()?;
    text_module.add_class::<PyJsonOutputParser>()?;
    text_module.add_class::<PyListOutputParser>()?;
    text_module.add_function(wrap_pyfunction!(py_chunk_text, &text_module)?)?;
    text_module.add_function(wrap_pyfunction!(py_extract_text, &text_module)?)?;
    m.add_submodule(&text_module)?;

    // ── Evaluation Submodule ───────────────────────────────────────────────────
    let eval_module = PyModule::new_bound(m.py(), "evaluation")?;
    eval_module.add_class::<PyEvaluationResult>()?;
    eval_module.add_class::<PyEvalQuery>()?;
    eval_module.add_class::<PyEvalResults>()?;
    eval_module.add_class::<PyQueryResult>()?;
    eval_module.add_class::<PyScoringConfig>()?;
    eval_module.add_class::<PyGradingConfig>()?;
    eval_module.add_class::<PyEvaluationConfig>()?;
    eval_module.add_class::<PyNodeResult>()?;
    eval_module.add_class::<PyEvaluationReport>()?;
    eval_module.add_function(wrap_pyfunction!(rag_eval::py_hit_rate, &eval_module)?)?;
    eval_module.add_function(wrap_pyfunction!(rag_eval::py_mrr, &eval_module)?)?;
    eval_module.add_function(wrap_pyfunction!(rag_eval::py_mean_ndcg, &eval_module)?)?;
    eval_module.add_function(wrap_pyfunction!(rag_eval::py_rag_evaluate, &eval_module)?)?;
    eval_module.add_function(wrap_pyfunction!(remaining::py_evaluate_output_score, &eval_module)?)?;
    m.add_submodule(&eval_module)?;

    // ── Observability Submodule ────────────────────────────────────────────────
    let obs_module = PyModule::new_bound(m.py(), "observability")?;
    obs_module.add_class::<PyExecutionTrace>()?;
    obs_module.add_class::<PyExecutionTracer>()?;
    obs_module.add_function(wrap_pyfunction!(observability::py_init_tracing, &obs_module)?)?;
    obs_module.add_function(wrap_pyfunction!(visualization::py_visualize_graph, &obs_module)?)?;
    obs_module.add_function(wrap_pyfunction!(visualization::py_graph_to_dot, &obs_module)?)?;
    obs_module.add_function(wrap_pyfunction!(visualization::py_graph_to_mermaid, &obs_module)?)?;
    m.add_submodule(&obs_module)?;

    // ── Advanced Nodes Submodule ───────────────────────────────────────────────
    let nodes_module = PyModule::new_bound(m.py(), "nodes")?;
    nodes_module.add_class::<PyMessageGraph>()?;
    nodes_module.add_class::<PyMessageGraphBuilder>()?;
    nodes_module.add_class::<PySupervisor>()?;
    nodes_module.add_class::<PyOrchestrationStrategy>()?;
    nodes_module.add_class::<PySupervisorNodeConfig>()?;
    nodes_module.add_class::<PyParallelAggregation>()?;
    nodes_module.add_class::<PyParallelMergeStrategy>()?;
    nodes_module.add_class::<PyChildExecutionStats>()?;
    nodes_module.add_class::<PyPlannerNode>()?;
    nodes_module.add_class::<PyRetryNode>()?;
    nodes_module.add_class::<PyTimeoutNode>()?;
    nodes_module.add_class::<PyEvaluationNodeConfig>()?;
    nodes_module.add_class::<PyJoinType>()?;
    nodes_module.add_class::<PyMergeStrategy>()?;
    nodes_module.add_class::<PyBranchConfig>()?;
    nodes_module.add_class::<PyLoopNodeConfig>()?;
    nodes_module.add_class::<PyParallelNodeConfig>()?;
    nodes_module.add_class::<PySubgraphNodeConfig>()?;
    nodes_module.add_class::<PyJoinNodeConfig>()?;
    m.add_submodule(&nodes_module)?;

    // ── Routing Submodule ──────────────────────────────────────────────────────
    let routing_module = PyModule::new_bound(m.py(), "routing")?;
    routing_module.add_class::<PyComparisonOp>()?;
    routing_module.add_class::<PyCondition>()?;
    routing_module.add_class::<PyConditionBuilder>()?;
    m.add_submodule(&routing_module)?;

    // ── Data Loading Submodule ────────────────────────────────────────────────
    let data_module = PyModule::new_bound(m.py(), "data")?;
    data_module.add_class::<PyFileType>()?;
    data_module.add_class::<PyLoadedDocument>()?;
    data_module.add_class::<PyIngestionPipeline>()?;
    data_module.add_class::<PyIngestionStats>()?;
    data_module.add_function(wrap_pyfunction!(document_loader::py_load_document, &data_module)?)?;
    data_module.add_function(wrap_pyfunction!(document_loader::py_load_directory, &data_module)?)?;
    m.add_submodule(&data_module)?;

    // ── Reranking Submodule ────────────────────────────────────────────────────
    let rerank_module = PyModule::new_bound(m.py(), "reranking")?;
    rerank_module.add_class::<PyNoopReranker>()?;
    rerank_module.add_class::<PyRRFReranker>()?;
    rerank_module.add_class::<PyCrossEncoderReranker>()?;
    rerank_module.add_class::<PyLLMReranker>()?;
    m.add_submodule(&rerank_module)?;

    // ── Advanced Agents Submodule ──────────────────────────────────────────────
    let advanced_module = PyModule::new_bound(m.py(), "advanced")?;
    advanced_module.add_class::<PyMemoryAwareAgent>()?;
    advanced_module.add_class::<PyMemoryStats>()?;
    m.add_submodule(&advanced_module)?;

    // ── MCP Submodule ─────────────────────────────────────────────────────────
    let mcp_module = PyModule::new_bound(m.py(), "mcp")?;
    mcp_module.add_class::<PyMCPConfig>()?;
    m.add_submodule(&mcp_module)?;

    // ── Utilities Submodule ────────────────────────────────────────────────────
    let utils_module = PyModule::new_bound(m.py(), "utils")?;
    utils_module.add_class::<PyVisualizationConfig>()?;
    utils_module.add_class::<PyChunkMetadata>()?;
    utils_module.add_class::<PyRetrieverStrategy>()?;
    utils_module.add_class::<PyRerankStrategy>()?;
    utils_module.add_class::<PyVectorStore>()?;
    utils_module.add_function(wrap_pyfunction!(py_from_config_path, &utils_module)?)?;
    m.add_submodule(&utils_module)?;

    Ok(())
}
