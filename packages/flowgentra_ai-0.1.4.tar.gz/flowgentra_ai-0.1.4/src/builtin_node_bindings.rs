//! Python bindings for built-in node types (Retry, Timeout, LLM Node)
//!
//! RetryGraphNode and TimeoutGraphNode wrap Python callables with retry/timeout
//! logic. They use the LangGraph-style dict I/O pattern: the Python callable
//! receives the full state dict and returns a partial update dict.

use pyo3::prelude::*;
use pyo3::exceptions::PyRuntimeError;
use pyo3::types::PyDict;
use std::sync::Arc;
use std::time::Duration;

use flowgentra_ai::core::state::{Context, DynState, DynStateUpdate};
use flowgentra_ai::core::state_graph::node::Node;
use flowgentra_ai::core::state_graph::StateGraphError;

use crate::get_runtime;
use crate::graph::{dynstate_to_pydict, pydict_to_dynstate};

// ─── PyRetryNode (standalone Python class) ──────────────────────────────────

/// A standalone retry wrapper for a Python callable (not graph-embedded).
///
/// For graph use, prefer builder.add_retry_node(...) instead.
///
/// The inner callable receives the current state dict and returns a partial
/// update dict. Retries up to `max_retries` times with exponential backoff.
///
/// Example:
///     def fetch(state: dict) -> dict:
///         return {"result": call_api(state["query"])}
///
///     retry = RetryNode("fetch", fetch, max_retries=3)
///     result = retry.run({"query": "hello", "result": None})
#[pyclass(name = "RetryNode")]
pub struct PyRetryNode {
    name: String,
    func: PyObject,
    max_retries: usize,
    backoff_ms: u64,
    backoff_multiplier: f64,
    max_backoff_ms: u64,
}

#[pymethods]
impl PyRetryNode {
    #[new]
    #[pyo3(signature = (name, func, max_retries=3, backoff_ms=1000, backoff_multiplier=2.0, max_backoff_ms=30000))]
    fn new(
        name: &str,
        func: PyObject,
        max_retries: usize,
        backoff_ms: u64,
        backoff_multiplier: f64,
        max_backoff_ms: u64,
    ) -> Self {
        PyRetryNode {
            name: name.to_string(),
            func,
            max_retries,
            backoff_ms,
            backoff_multiplier,
            max_backoff_ms,
        }
    }

    /// Execute the retry node with the given state dict.
    ///
    /// Args:
    ///     state_dict: Full current state as a plain dict.
    ///
    /// Returns:
    ///     Merged state dict after applying the partial update from the callable.
    fn run(&self, py: Python<'_>, state_dict: &Bound<'_, PyDict>) -> PyResult<PyObject> {
        let rt = get_runtime();
        let func = self.func.clone_ref(py);
        let max_retries = self.max_retries;
        let mut backoff = self.backoff_ms;
        let multiplier = self.backoff_multiplier;
        let max_backoff = self.max_backoff_ms;
        let name = self.name.clone();

        // Build a DynState from the input dict (no schema — standalone mode)
        let current_state = pydict_to_dynstate(state_dict)?;

        let result = rt.block_on(async move {
            let mut last_error = String::new();
            for attempt in 0..=max_retries {
                let call_result = Python::with_gil(|py| -> PyResult<DynState> {
                    let f = func.clone_ref(py);
                    let state_d = dynstate_to_pydict(py, &current_state)?;
                    let py_result = f.call1(py, (state_d,))?;
                    let update = py_result.bind(py).downcast::<PyDict>().map_err(|_| {
                        pyo3::exceptions::PyTypeError::new_err(format!(
                            "RetryNode '{}' callable must return a dict", name
                        ))
                    })?.clone();
                    // Merge partial update (no schema validation in standalone mode)
                    let merged = current_state.clone();
                    for (k, v) in update.iter() {
                        let key: String = k.extract()?;
                        let val = crate::py_to_json(&v)?;
                        merged.set(key, val);
                    }
                    Ok(merged)
                });

                match call_result {
                    Ok(new_state) => return Ok(new_state),
                    Err(e) => {
                        last_error = format!("{}", e);
                        if attempt < max_retries {
                            tokio::time::sleep(Duration::from_millis(backoff)).await;
                            backoff = ((backoff as f64 * multiplier) as u64).min(max_backoff);
                        }
                    }
                }
            }
            Err(last_error)
        });

        match result {
            Ok(new_state) => Python::with_gil(|py| {
                dynstate_to_pydict(py, &new_state).map(|d| d.into())
            }),
            Err(e) => Err(PyRuntimeError::new_err(format!(
                "RetryNode '{}' failed after {} retries: {}",
                self.name, self.max_retries, e
            ))),
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "RetryNode(name='{}', max_retries={}, backoff_ms={})",
            self.name, self.max_retries, self.backoff_ms
        )
    }
}

// ─── PyTimeoutNode (standalone Python class) ────────────────────────────────

/// A standalone timeout wrapper for a Python callable (not graph-embedded).
///
/// For graph use, prefer builder.add_timeout_node(...) instead.
///
/// The inner callable receives the current state dict and returns a partial
/// update dict. Raises an error or skips based on `on_timeout`.
///
/// Example:
///     timeout = TimeoutNode("slow_op", slow_fn, timeout_ms=5000)
///     result = timeout.run({"query": "hello", "result": None})
#[pyclass(name = "TimeoutNode")]
pub struct PyTimeoutNode {
    name: String,
    func: PyObject,
    timeout_ms: u64,
    on_timeout: String,
}

#[pymethods]
impl PyTimeoutNode {
    #[new]
    #[pyo3(signature = (name, func, timeout_ms, on_timeout="error"))]
    fn new(name: &str, func: PyObject, timeout_ms: u64, on_timeout: &str) -> Self {
        PyTimeoutNode {
            name: name.to_string(),
            func,
            timeout_ms,
            on_timeout: on_timeout.to_string(),
        }
    }

    /// Execute the timeout node with the given state dict.
    ///
    /// Args:
    ///     state_dict: Full current state as a plain dict.
    ///
    /// Returns:
    ///     Merged state dict, or original state if on_timeout="skip".
    fn run(&self, py: Python<'_>, state_dict: &Bound<'_, PyDict>) -> PyResult<PyObject> {
        let rt = get_runtime();
        let func = self.func.clone_ref(py);
        let timeout = Duration::from_millis(self.timeout_ms);
        let on_timeout = self.on_timeout.clone();
        let name = self.name.clone();
        let current_state = pydict_to_dynstate(state_dict)?;

        let result = rt.block_on(async move {
            let inner_future = async {
                Python::with_gil(|py| -> PyResult<DynState> {
                    let f = func.clone_ref(py);
                    let state_d = dynstate_to_pydict(py, &current_state)?;
                    let py_result = f.call1(py, (state_d,))?;
                    let update = py_result.downcast_bound::<PyDict>(py).map_err(|_| {
                        pyo3::exceptions::PyTypeError::new_err(format!(
                            "TimeoutNode '{}' callable must return a dict", name
                        ))
                    })?;
                    let merged = current_state.clone();
                    for (k, v) in update.iter() {
                        let key: String = k.extract()?;
                        let val = crate::py_to_json(&v)?;
                        merged.set(key, val);
                    }
                    Ok(merged)
                })
            };

            match tokio::time::timeout(timeout, inner_future).await {
                Ok(Ok(new_state)) => Ok(new_state),
                Ok(Err(e)) => Err(format!("Node '{}' error: {}", name, e)),
                Err(_) => match on_timeout.as_str() {
                    "skip" => Ok(current_state),
                    _ => Err(format!(
                        "Node '{}' timed out after {}ms",
                        name,
                        timeout.as_millis()
                    )),
                },
            }
        });

        match result {
            Ok(new_state) => Python::with_gil(|py| {
                dynstate_to_pydict(py, &new_state).map(|d| d.into())
            }),
            Err(e) => Err(PyRuntimeError::new_err(e)),
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "TimeoutNode(name='{}', timeout_ms={}, on_timeout='{}')",
            self.name, self.timeout_ms, self.on_timeout
        )
    }
}

// ─── Graph node adapters ────────────────────────────────────────────────────

/// Wraps a Python callable with retry logic as a Node<DynState>.
pub(crate) struct RetryGraphNode {
    pub name: String,
    pub func: PyObject,
    pub max_retries: usize,
    pub backoff_ms: u64,
    pub backoff_multiplier: f64,
    pub max_backoff_ms: u64,
    pub schema_fields: Arc<Vec<String>>,
}

#[async_trait::async_trait]
impl Node<DynState> for RetryGraphNode {
    async fn execute(&self, state: &DynState, _ctx: &Context) -> Result<DynStateUpdate, StateGraphError> {
        let func = Python::with_gil(|py| self.func.clone_ref(py));
        let schema_fields = self.schema_fields.clone();
        let node_name = self.name.clone();
        let mut backoff = self.backoff_ms;
        let mut last_error = String::new();

        for attempt in 0..=self.max_retries {
            let call_result = Python::with_gil(|py| -> PyResult<DynStateUpdate> {
                let f = func.clone_ref(py);
                let state_dict = dynstate_to_pydict(py, state)?;
                let py_result = f.call1(py, (state_dict,))?;
                let update = py_result.downcast_bound::<PyDict>(py).map_err(|_| {
                    pyo3::exceptions::PyTypeError::new_err(format!(
                        "RetryNode '{}' callable must return a dict", node_name
                    ))
                })?;
                // Validate keys against schema
                for (k, _) in update.iter() {
                    let key: String = k.extract()?;
                    if !schema_fields.contains(&key) {
                        return Err(PyRuntimeError::new_err(format!(
                            "RetryNode '{}' returned unknown key '{}'. Valid keys: {:?}",
                            node_name, key, schema_fields
                        )));
                    }
                }
                // Build partial update
                let mut state_update = DynStateUpdate::new();
                for (k, v) in update.iter() {
                    let key: String = k.extract()?;
                    let val = crate::py_to_json(&v)?;
                    state_update.insert(key, val);
                }
                Ok(state_update)
            });

            match call_result {
                Ok(update) => return Ok(update),
                Err(e) => {
                    last_error = format!("{}", e);
                    if attempt < self.max_retries {
                        tokio::time::sleep(Duration::from_millis(backoff)).await;
                        backoff = ((backoff as f64 * self.backoff_multiplier) as u64)
                            .min(self.max_backoff_ms);
                    }
                }
            }
        }

        Err(StateGraphError::ExecutionError {
            node: self.name.clone(),
            reason: format!("Failed after {} retries: {}", self.max_retries, last_error),
        })
    }

    fn name(&self) -> &str {
        &self.name
    }
}

/// Wraps a Python callable with a timeout as a Node<DynState>.
pub(crate) struct TimeoutGraphNode {
    pub name: String,
    pub func: PyObject,
    pub timeout_ms: u64,
    pub on_timeout: String,
    pub schema_fields: Arc<Vec<String>>,
}

#[async_trait::async_trait]
impl Node<DynState> for TimeoutGraphNode {
    async fn execute(&self, state: &DynState, _ctx: &Context) -> Result<DynStateUpdate, StateGraphError> {
        let func = Python::with_gil(|py| self.func.clone_ref(py));
        let timeout = Duration::from_millis(self.timeout_ms);
        let state_clone = state.clone();
        let schema_fields = self.schema_fields.clone();
        let node_name = self.name.clone();

        let inner_future = async {
            Python::with_gil(|py| -> PyResult<DynStateUpdate> {
                let f = func.clone_ref(py);
                let state_dict = dynstate_to_pydict(py, &state_clone)?;
                let py_result = f.call1(py, (state_dict,))?;
                let update = py_result.downcast_bound::<PyDict>(py).map_err(|_| {
                    pyo3::exceptions::PyTypeError::new_err(format!(
                        "TimeoutNode '{}' callable must return a dict", node_name
                    ))
                })?;
                for (k, _) in update.iter() {
                    let key: String = k.extract()?;
                    if !schema_fields.contains(&key) {
                        return Err(PyRuntimeError::new_err(format!(
                            "TimeoutNode '{}' returned unknown key '{}'. Valid keys: {:?}",
                            node_name, key, schema_fields
                        )));
                    }
                }
                let mut state_update = DynStateUpdate::new();
                for (k, v) in update.iter() {
                    let key: String = k.extract()?;
                    let val = crate::py_to_json(&v)?;
                    state_update.insert(key, val);
                }
                Ok(state_update)
            })
        };

        match tokio::time::timeout(timeout, inner_future).await {
            Ok(Ok(state_update)) => Ok(state_update),
            Ok(Err(e)) => Err(StateGraphError::ExecutionError {
                node: self.name.clone(),
                reason: format!("Python node error: {}", e),
            }),
            Err(_) => match self.on_timeout.as_str() {
                // on skip: return empty update (no changes)
                "skip" => Ok(DynStateUpdate::new()),
                _ => Err(StateGraphError::ExecutionError {
                    node: self.name.clone(),
                    reason: format!("Timed out after {}ms", self.timeout_ms),
                }),
            },
        }
    }

    fn name(&self) -> &str {
        &self.name
    }
}

/// Wraps an LLM client as a graph node that reads a prompt key and writes a response key.
pub(crate) struct LLMGraphNode {
    pub name: String,
    pub llm_client: Arc<dyn flowgentra_ai::core::llm::LLMClient>,
    pub system_prompt: Option<String>,
    pub prompt_key: String,
    pub output_key: String,
}

#[async_trait::async_trait]
impl Node<DynState> for LLMGraphNode {
    async fn execute(&self, state: &DynState, _ctx: &Context) -> Result<DynStateUpdate, StateGraphError> {
        use flowgentra_ai::core::llm::Message;

        let user_prompt = state
            .get(&self.prompt_key)
            .and_then(|v| v.as_str().map(String::from))
            .unwrap_or_default();

        if user_prompt.is_empty() {
            return Err(StateGraphError::ExecutionError {
                node: self.name.clone(),
                reason: format!("No prompt found at state key '{}'", self.prompt_key),
            });
        }

        let mut messages = Vec::new();
        if let Some(ref sys) = self.system_prompt {
            messages.push(Message::system(sys));
        }
        messages.push(Message::user(&user_prompt));

        let response = self.llm_client.chat(messages).await.map_err(|e| {
            StateGraphError::ExecutionError {
                node: self.name.clone(),
                reason: format!("LLM call failed: {}", e),
            }
        })?;

        let mut update = DynStateUpdate::new();
        update.insert(self.output_key.clone(), serde_json::json!(response.content));
        Ok(update)
    }

    fn name(&self) -> &str {
        &self.name
    }
}
