"""Language model interfaces and utilities.

This module provides LLM client abstractions and configuration for using various
language models with your workflows.

Examples:
    Create and use an LLM client:

        from flowgentra_ai.llm import LLMClient, LLMConfig, Message

        config = LLMConfig(model="gpt-4", temperature=0.7)
        client = LLMClient(config)
        
        messages = [Message(role="user", content="Hello")]
        response = client.call(messages)
"""

from flowgentra_ai._native import llm as _l

LLMConfig = _l.LLMConfig
Message = _l.Message
ToolCall = _l.ToolCall
ToolDefinition = _l.ToolDefinition
TokenUsage = _l.TokenUsage
LLMClient = _l.LLMClient

__all__ = [
    "LLMConfig",
    "Message",
    "ToolCall",
    "ToolDefinition",
    "TokenUsage",
    "LLMClient",
]
