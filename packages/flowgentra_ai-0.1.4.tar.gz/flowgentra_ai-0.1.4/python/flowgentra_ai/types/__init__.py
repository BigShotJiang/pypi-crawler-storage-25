"""Common types and utilities shared across modules.

This module provides shared types, utility functions, and configuration formats
used throughout the FlowgentraAI framework.

Examples:
    Use utility functions:

        from flowgentra_ai.types import (
            chunk_text,
            extract_text,
            estimate_tokens,
            model_pricing
        )

        chunks = chunk_text(long_text, chunk_size=1000)
        tokens = estimate_tokens(text, model="gpt-4")
        
    Work with common types:
    
        from flowgentra_ai.types import (
            Condition,
            ConditionBuilder,
            ComparisonOp,
            ResponseFormat,
            MCPConfig
        )
"""

from flowgentra_ai._native import routing as _ro, llm as _l, mcp as _mc, text as _tx, rag as _r, utils as _u

Condition = _ro.Condition
ConditionBuilder = _ro.ConditionBuilder
ComparisonOp = _ro.ComparisonOp
ResponseFormat = _l.ResponseFormat
estimate_tokens = _l.py_estimate_tokens
model_pricing = _l.py_model_pricing
MCPConfig = _mc.MCPConfig
chunk_text = _tx.py_chunk_text
extract_text = _tx.py_extract_text
chunk_text_by_tokens = _r.py_chunk_text_by_tokens
extract_and_chunk = _r.py_extract_and_chunk
from_config_path = _u.py_from_config_path

__all__ = [
    # Conditions
    "Condition",
    "ConditionBuilder",
    "ComparisonOp",
    # Configuration types
    "ResponseFormat",
    "MCPConfig",
    # Text processing
    "chunk_text",
    "extract_text",
    "estimate_tokens",
    "model_pricing",
    "chunk_text_by_tokens",
    "extract_and_chunk",
    # Configuration loading
    "from_config_path",
]
