"""Memory and persistence layer for conversations and state.

This module provides interfaces for persisting conversation history, managing checkpoints,
and implementing memory strategies for long-running workflows.

Examples:
    Use conversation memory:

        from flowgentra_ai.memory import ConversationMemory

        memory = ConversationMemory()
        # Add messages to memory and retrieve history
        
    Save checkpoints:
    
        from flowgentra_ai.memory import FileCheckpointer
        
        checkpointer = FileCheckpointer("./checkpoints")
        # Use with graph.compile(checkpointer=checkpointer)
"""

from flowgentra_ai._native import memory as _m, state as _s

Checkpoint = _m.Checkpoint
CheckpointMetadata = _m.CheckpointMetadata
ConversationMemory = _m.ConversationMemory
TokenBufferMemory = _m.TokenBufferMemory
SummaryConfig = _m.SummaryConfig
SummaryMemory = _m.SummaryMemory
FileCheckpointer = _s.FileCheckpointer

__all__ = [
    "Checkpoint",
    "CheckpointMetadata",
    "ConversationMemory",
    "TokenBufferMemory",
    "SummaryConfig",
    "SummaryMemory",
    "FileCheckpointer",
]
