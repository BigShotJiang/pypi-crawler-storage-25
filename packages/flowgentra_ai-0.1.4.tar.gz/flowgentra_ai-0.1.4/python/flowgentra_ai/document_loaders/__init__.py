"""Document loading and processing utilities.

This module provides tools for loading documents from various sources, processing PDFs,
and ingesting content into RAG systems.

Examples:
    Load documents:

        from flowgentra_ai.document_loaders import (
            load_document,
            load_directory,
            extract_pdf
        )

        doc = load_document("./document.pdf")
        docs = load_directory("./docs")
        
    Use ingestion pipeline:
    
        from flowgentra_ai.document_loaders import IngestionPipeline
        
        pipeline = IngestionPipeline()
        stats = pipeline.ingest(documents)
"""

from flowgentra_ai._native import data as _d, rag as _r

FileType = _d.FileType
LoadedDocument = _d.LoadedDocument
IngestionPipeline = _d.IngestionPipeline
IngestionStats = _d.IngestionStats
load_document = _d.py_load_document
load_directory = _d.py_load_directory
PdfDocument = _r.PdfDocument
extract_pdf = _r.py_extract_pdf

__all__ = [
    # Types
    "FileType",
    "LoadedDocument",
    "PdfDocument",
    # Loading functions
    "load_document",
    "load_directory",
    "extract_pdf",
    # Ingestion pipeline
    "IngestionPipeline",
    "IngestionStats",
]
