"""Retrieval-augmented generation (RAG) components.

This module provides document retrieval, embedding, vector stores, and text processing
for RAG workflows.

Examples:
    Set up RAG with vector stores:

        from flowgentra_ai.rag import (
            InMemoryVectorStore,
            Embeddings,
            RecursiveCharacterTextSplitter
        )

        splitter = RecursiveCharacterTextSplitter(chunk_size=1000)
        embeddings = Embeddings()
        store = InMemoryVectorStore(embeddings)
        
    Configure RAG retrieval:
    
        from flowgentra_ai.rag import RAGConfig, RetrievalConfig
        
        rag_config = RAGConfig(...)
        retrieval = RetrievalConfig(...)
"""

from flowgentra_ai._native import rag as _r, text as _tx, utils as _u

Document = _r.Document
SearchResult = _r.SearchResult
TextChunk = _r.TextChunk
Retriever = _r.Retriever
RetrievalConfig = _r.RetrievalConfig
Embeddings = _r.Embeddings
InMemoryVectorStore = _r.InMemoryVectorStore
VectorStoreType = _r.VectorStoreType
RAGConfig = _r.RAGConfig
VectorStoreConfig = _r.VectorStoreConfig
EmbeddingsConfig = _r.EmbeddingsConfig
RetrievalSettings = _r.RetrievalSettings
PdfSettings = _r.PdfSettings
RAGGraphConfig = _r.RAGGraphConfig
ChromaStore = _r.ChromaStore
bm25_score = _r.py_bm25_score
hybrid_merge = _r.py_hybrid_merge
dedup_by_id = _r.py_dedup_by_id
dedup_by_similarity = _r.py_dedup_by_similarity
decompose_query = _r.py_decompose_query
RecursiveCharacterTextSplitter = _tx.RecursiveCharacterTextSplitter
MarkdownTextSplitter = _tx.MarkdownTextSplitter
HTMLTextSplitter = _tx.HTMLTextSplitter
TokenTextSplitter = _tx.TokenTextSplitter
CodeTextSplitter = _tx.CodeTextSplitter
VectorStore = _u.VectorStore
ChunkMetadata = _u.ChunkMetadata
RetrieverStrategy = _u.RetrieverStrategy

__all__ = [
    # Document types
    "Document",
    "SearchResult",
    "TextChunk",
    "ChunkMetadata",
    # Retrieval
    "Retriever",
    "RetrievalConfig",
    "RetrieverStrategy",
    # Vector stores and embeddings
    "VectorStore",
    "Embeddings",
    "InMemoryVectorStore",
    "ChromaStore",
    # Text splitters
    "RecursiveCharacterTextSplitter",
    "MarkdownTextSplitter",
    "HTMLTextSplitter",
    "TokenTextSplitter",
    "CodeTextSplitter",
    # RAG configuration
    "VectorStoreType",
    "RAGConfig",
    "VectorStoreConfig",
    "EmbeddingsConfig",
    "RetrievalSettings",
    "PdfSettings",
    "RAGGraphConfig",
    # Utility functions
    "bm25_score",
    "hybrid_merge",
    "dedup_by_id",
    "dedup_by_similarity",
    "decompose_query",
]
