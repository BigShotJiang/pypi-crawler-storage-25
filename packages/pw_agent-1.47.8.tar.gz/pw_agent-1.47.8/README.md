# PW Agent 🧠

CLI coding assistant powered by your Ollama GPUs via [PastaWater](https://pastawater.io).

## Install

The recommended way to install `pw-agent` is using **pipx** to keep it isolated from your other Python packages:

```bash
pipx install pw-agent
```

*Alternatively, you can use standard pip:* `pip install pw-agent`

## Usage

```bash
pw-agent
```

First run guides you through setup — paste your API token, pick a GPU, start chatting.

## Features

- **Interactive REPL** with real-time streaming and a premium dashboard status bar.
- **Plan vs Build Modes**: Use `/plan` for read-only analysis and `/build` for execution.
- **Context Discovery**: Automatically finds `PW_AGENT.md` for project-specific rules.
- **Tab Autocomplete** for commands, file paths, and GPU slots.
- **Session Control**: Fresh sessions by default; use `-c` to resume where you left off.
- **File Injection**: `/add file.py` or `@file.py` — inject files into the LLM's context.
- **Batch Processing**: Model can run multiple tool calls in a single turn.
- **GPU Fleet Control**: `/models` to view GPUs and `/use N` to switch connections or slots.
- **AI Commits**: `/commit` to generate and apply git commit messages based on your diff.
- **Safety First**: `-y` flag for auto-approve; otherwise, every file edit requires confirmation.

## Connect

- **Cloud mode**: Use your PastaWater API token to access your remote fleet.
- **Direct mode**: Point at a local Ollama instance (`--brain http://localhost:11434`).

Get your token at [pastawater.io/settings](https://pastawater.io/settings?tab=cli)
