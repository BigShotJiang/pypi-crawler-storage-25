from mkpipe.spark import JdbcLoader

JAR_PACKAGES = ['com.amazon.redshift:redshift-jdbc42:2.1.0.31']


class RedshiftLoader(JdbcLoader, variant='redshift'):
    driver_name = 'redshift'
    driver_jdbc = 'com.amazon.redshift.jdbc42.Driver'
    _dialect = 'redshift'

    def build_jdbc_url(self):
        url = (
            f'jdbc:{self.driver_name}://{self.host}:{self.port}/{self.database}'
            f'?user={self.username}&password={self.password}'
        )
        if self.schema:
            url += f'&currentSchema={self.schema}'
        return url
