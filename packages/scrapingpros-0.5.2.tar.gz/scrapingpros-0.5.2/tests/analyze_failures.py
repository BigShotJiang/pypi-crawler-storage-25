"""Fetch failed jobs from the benchmark run and extract failure reasons."""

import json
from collections import Counter

from scrapingpros import ScrapingPros

TOKEN = "3Fupbo6Qui4bl2w62Cz6"
COL_ID = "54d4c3b5-9c04-42f7-a113-d8e952b40294"
RUN_ID = "c00be6ac-c225-4df4-b470-62e19a393494"


def short(s, n=60):
    if not s:
        return ""
    return s[:n] + ("..." if len(s) > n else "")


def main():
    client = ScrapingPros(TOKEN)

    # Pull all jobs without filter to see full set
    print("Fetching all terminal jobs...")
    all_jobs = client.get_run_jobs(COL_ID, RUN_ID, status_filter="completed,failed,timeout")
    print(f"Total: {len(all_jobs.items)}")

    # Split into success/fail using the same heuristic as Batch
    failures = []
    for j in all_jobs.items:
        ok = (
            j.status == "completed"
            and j.status_code is not None
            and 200 <= j.status_code < 300
            and not j.block_reason
        )
        if not ok:
            failures.append(j)

    print(f"Classified as failures: {len(failures)}")
    print()

    # For each failure, fetch the result to get the message/html
    print(f"{'IDX':>3}  {'DIFF':6}  {'DOMAIN':30}  {'STATUS':10}  {'HTTP':4}  {'BLOCK':25}  MESSAGE")
    print("-" * 130)
    reasons = Counter()
    for i, j in enumerate(failures, 1):
        custom_id = j.custom_id or ""
        diff = custom_id.split("-", 1)[0] if custom_id else "?"
        domain = custom_id.split("-", 1)[1] if "-" in custom_id else ""
        block = j.block_reason or ""
        # Try to fetch the result for more context
        try:
            r = client.get_job_result(COL_ID, RUN_ID, j.job_public_id)
            msg = r.message or ""
        except Exception as e:
            msg = f"[fetch failed: {e}]"
        print(f"{i:3d}  {diff:6}  {domain:30}  {j.status:10}  {j.status_code or '-':>4}  {block[:25]:25}  {short(msg, 60)}")

        # Categorize
        if j.status_code == 500:
            reasons["http_500"] += 1
        elif j.status_code == 404:
            reasons["http_404"] += 1
        elif j.status == "timeout":
            reasons["timeout"] += 1
        elif j.status == "failed":
            reasons["failed"] += 1
        elif j.block_reason and j.block_reason != "none":
            reasons[f"block_{j.block_reason}"] += 1
        else:
            reasons["other"] += 1

    print()
    print("=" * 50)
    print("REASONS SUMMARY")
    print("=" * 50)
    for reason, count in reasons.most_common():
        print(f"  {reason:20s} {count:3d}")

    client.close()


if __name__ == "__main__":
    main()
