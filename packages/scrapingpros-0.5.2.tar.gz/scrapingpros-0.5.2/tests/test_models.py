"""Tests for Pydantic models — serialization, defaults, and validation."""

from __future__ import annotations

import pytest

from scrapingpros.models import (
    ClickAction,
    CollectAction,
    CollectionPublic,
    CountryRequest,
    DownloadRequest,
    DownloadResponse,
    EvaluateAction,
    FailedJobPublic,
    InputAction,
    JobExecutionListPublic,
    JobExecutionPublic,
    KeyPressAction,
    MethodGET,
    MethodPOST,
    NetworkCaptureConfig,
    NewCollectionResponse,
    ProxyConfig,
    RunPublic,
    ScrapeRequest,
    ScrapeResponse,
    SelectAction,
    SelectorInvisibleCondition,
    SelectorVisibleCondition,
    UrlViabilityResult,
    ViabilityRunPublic,
    ViabilityTestRequest,
    WaitForSelectorAction,
    WaitForTimeoutAction,
    WhileControl,
)


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

class TestClickAction:
    def test_defaults(self):
        a = ClickAction(selector="css:button")
        assert a.type == "click"
        assert a.wait_for_navigation is False
        assert a.optional is False

    def test_with_options(self):
        a = ClickAction(selector="css:a", wait_for_navigation=True, optional=True)
        assert a.wait_for_navigation is True
        assert a.optional is True

    def test_serialization(self):
        data = ClickAction(selector="css:x").model_dump()
        assert data["type"] == "click"
        assert data["selector"] == "css:x"


class TestInputAction:
    def test_basic(self):
        a = InputAction(selector="css:#q", text="hello")
        assert a.type == "input"
        assert a.text == "hello"


class TestSelectAction:
    def test_basic(self):
        a = SelectAction(selector="css:#lang", value="en")
        assert a.type == "select"
        assert a.value == "en"


class TestKeyPressAction:
    def test_basic(self):
        a = KeyPressAction(key="Enter")
        assert a.type == "key-press"
        assert a.key == "Enter"


class TestWaitForSelectorAction:
    def test_basic(self):
        a = WaitForSelectorAction(selector="css:.loaded", time=5000)
        assert a.type == "wait-for-selector"
        assert a.time == 5000


class TestWaitForTimeoutAction:
    def test_basic(self):
        a = WaitForTimeoutAction(time=2000)
        assert a.type == "wait-for-timeout"


class TestEvaluateAction:
    def test_defaults(self):
        a = EvaluateAction(script="document.title")
        assert a.type == "evaluate"
        assert a.timeout == 30000

    def test_custom_timeout(self):
        a = EvaluateAction(script="1+1", timeout=5000)
        assert a.timeout == 5000


class TestCollectAction:
    def test_basic(self):
        a = CollectAction(extract={"titles": {"selector": "css:h2", "multiple": True}})
        assert a.type == "collect"
        assert "titles" in a.extract


class TestWhileControl:
    def test_basic_loop(self):
        loop = WhileControl(
            condition=SelectorVisibleCondition(selector="css:.next"),
            actions=[ClickAction(selector="css:.next", wait_for_navigation=True)],
        )
        assert loop.type == "while"
        assert loop.max_iterations == 20
        assert len(loop.actions) == 1

    def test_custom_max_iterations(self):
        loop = WhileControl(
            condition=SelectorInvisibleCondition(selector="css:.gone"),
            actions=[WaitForTimeoutAction(time=100)],
            max_iterations=5,
        )
        assert loop.max_iterations == 5


# ---------------------------------------------------------------------------
# HTTP Method
# ---------------------------------------------------------------------------

class TestHttpMethod:
    def test_get(self):
        m = MethodGET()
        assert m.method == "get"

    def test_post_without_payload(self):
        m = MethodPOST()
        assert m.method == "post"
        assert m.payload is None

    def test_post_with_payload(self):
        m = MethodPOST(payload={"key": "val"})
        assert m.payload == {"key": "val"}


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

class TestProxyConfig:
    def test_defaults(self):
        p = ProxyConfig()
        assert p.proxy == "any"
        assert p.max_retries == 3
        assert p.delay_seconds == 1
        assert p.backoff_factor == 2

    def test_custom(self):
        p = ProxyConfig(proxy="US", max_retries=5)
        assert p.proxy == "US"


# ---------------------------------------------------------------------------
# Network Capture
# ---------------------------------------------------------------------------

class TestNetworkCaptureConfig:
    def test_defaults(self):
        cfg = NetworkCaptureConfig()
        assert cfg.resource_types is None
        assert cfg.listen_after_load_ms is None

    def test_with_types(self):
        cfg = NetworkCaptureConfig(resource_types=["xhr", "fetch"], listen_after_load_ms=5000)
        assert cfg.resource_types == ["xhr", "fetch"]


# ---------------------------------------------------------------------------
# ScrapeRequest
# ---------------------------------------------------------------------------

class TestScrapeRequest:
    def test_minimal(self):
        req = ScrapeRequest(url="https://example.com")
        assert req.url == "https://example.com"
        assert req.format == "html"
        assert req.browser is False
        assert req.browser_type == "light"

    def test_markdown_format(self):
        req = ScrapeRequest(url="https://example.com", format="markdown")
        assert req.format == "markdown"

    def test_auto_prepend_https(self):
        req = ScrapeRequest(url="example.com")
        assert req.url == "https://example.com"

    def test_http_preserved(self):
        req = ScrapeRequest(url="http://example.com")
        assert req.url == "http://example.com"

    def test_empty_url_raises(self):
        with pytest.raises(Exception):
            ScrapeRequest(url="")

    def test_whitespace_url_raises(self):
        with pytest.raises(Exception):
            ScrapeRequest(url="   ")

    def test_full_request(self):
        req = ScrapeRequest(
            url="https://example.com",
            format="markdown",
            browser=True,
            browser_type="light",
            use_proxy="US",
            screenshot=True,
            actions=[ClickAction(selector="css:button")],
            extract={"title": "css:h1"},
            network_capture=NetworkCaptureConfig(resource_types=["xhr"]),
        )
        assert req.browser is True
        assert req.browser_type == "light"
        assert req.use_proxy == "US"
        assert len(req.actions) == 1

    def test_serialization_excludes_none(self):
        req = ScrapeRequest(url="https://example.com")
        data = req.model_dump(exclude_none=True)
        assert "url" in data
        assert "actions" not in data
        assert "extract" not in data

    def test_proxy_config_object(self):
        req = ScrapeRequest(url="https://x.com", use_proxy=ProxyConfig(proxy="BR"))
        assert isinstance(req.use_proxy, ProxyConfig)

    def test_browser_type_stealth(self):
        req = ScrapeRequest(url="https://example.com", browser=True, browser_type="stealth")
        assert req.browser_type == "stealth"
        data = req.model_dump(exclude_none=True)
        assert data["browser_type"] == "stealth"

    def test_block_resources(self):
        req = ScrapeRequest(
            url="https://example.com",
            browser=True,
            block_resources=["image", "font", "media"],
        )
        assert req.block_resources == ["image", "font", "media"]
        data = req.model_dump(exclude_none=True)
        assert data["block_resources"] == ["image", "font", "media"]

    def test_block_requests(self):
        req = ScrapeRequest(
            url="https://example.com",
            browser=True,
            block_requests=["google-analytics", "doubleclick"],
        )
        assert req.block_requests == ["google-analytics", "doubleclick"]

    def test_block_resources_none_excluded(self):
        req = ScrapeRequest(url="https://example.com")
        data = req.model_dump(exclude_none=True)
        assert "block_resources" not in data
        assert "block_requests" not in data

    def test_default_browser_type_is_light(self):
        req = ScrapeRequest(url="https://example.com", browser=True)
        assert req.browser_type == "light"

    def test_full_request_with_blocking(self):
        req = ScrapeRequest(
            url="https://example.com",
            browser=True,
            browser_type="stealth",
            block_resources=["image", "stylesheet"],
            block_requests=["analytics", "tracker"],
            retry_on_block=True,
        )
        assert req.browser_type == "stealth"
        assert req.block_resources == ["image", "stylesheet"]
        assert req.block_requests == ["analytics", "tracker"]
        assert req.retry_on_block is True


# ---------------------------------------------------------------------------
# v0.3.0 — async contract: MethodPOST.url, custom_id, JobExecution* expansion
# ---------------------------------------------------------------------------

class TestV030AsyncContract:
    def test_method_post_url(self):
        m = MethodPOST(url="https://api.example.com/graphql", payload={"query": "x"})
        assert m.url == "https://api.example.com/graphql"
        assert m.payload == {"query": "x"}

    def test_method_post_url_validation(self):
        with pytest.raises(Exception):
            MethodPOST(url="not-a-url")

    def test_method_post_url_optional(self):
        m = MethodPOST(payload={"a": 1})
        assert m.url is None

    def test_method_post_payload_can_be_list(self):
        m = MethodPOST(payload=[1, 2, 3])
        assert m.payload == [1, 2, 3]

    def test_scrape_request_custom_id(self):
        req = ScrapeRequest(url="https://example.com", custom_id="tour_123")
        assert req.custom_id == "tour_123"

    def test_scrape_response_url_and_custom_id(self):
        resp = ScrapeResponse(message="OK", url="https://example.com",
                              custom_id="tour_123", html="<h1>x</h1>")
        assert resp.url == "https://example.com"
        assert resp.custom_id == "tour_123"

    def test_job_execution_public_new_fields(self):
        from scrapingpros.models import JobExecutionPublic
        from datetime import datetime
        job = JobExecutionPublic(
            job_public_id="j1", run_public_id="r1", collection_id="c1",
            status="completed",
            url="https://example.com",
            custom_id="tour_123",
            queued_at="2026-04-23T12:00:00.123",
            started_at="2026-04-23T12:00:02.267",
            completed_at="2026-04-23T12:00:03.637",
            execution_time_ms=1370,
            retries_attempted=0,
            block_reason=None,
            url_truncated=False,
            protection_stack=["cloudflare"],
            rule_hits=["rule1"],
        )
        assert job.url == "https://example.com"
        assert job.custom_id == "tour_123"
        assert isinstance(job.queued_at, datetime)
        assert job.execution_time_ms == 1370
        assert job.protection_stack == ["cloudflare"]
        assert job.rule_hits == ["rule1"]
        assert job.url_truncated is False

    def test_job_execution_public_execution_time_sec_property(self):
        from scrapingpros.models import JobExecutionPublic
        job = JobExecutionPublic(
            job_public_id="j1", run_public_id="r1", collection_id="c1",
            status="completed", execution_time_ms=2500,
        )
        assert job.execution_time_sec == 2.5

    def test_job_execution_public_execution_time_sec_when_ms_none(self):
        from scrapingpros.models import JobExecutionPublic
        job = JobExecutionPublic(
            job_public_id="j1", run_public_id="r1", collection_id="c1",
            status="completed",
        )
        assert job.execution_time_ms is None
        assert job.execution_time_sec is None

    def test_job_execution_list_with_cursor(self):
        from scrapingpros.models import JobExecutionListPublic, JobExecutionPublic
        job = JobExecutionPublic(job_public_id="j1", run_public_id="r1",
                                 collection_id="c1", status="completed")
        lst = JobExecutionListPublic(items=[job], cursor_next="abc", has_more=True)
        assert lst.cursor_next == "abc"
        assert lst.has_more is True

    def test_job_execution_list_default_cursor_none(self):
        from scrapingpros.models import JobExecutionListPublic
        lst = JobExecutionListPublic(items=[])
        assert lst.cursor_next is None
        assert lst.has_more is False

    def test_scrape_request_serialization_includes_custom_id(self):
        req = ScrapeRequest(url="https://x.com", custom_id="abc")
        data = req.model_dump(exclude_none=True)
        assert data["custom_id"] == "abc"

    def test_job_execution_is_success_field(self):
        from scrapingpros.models import JobExecutionPublic
        # Success
        j = JobExecutionPublic(job_public_id="j1", run_public_id="r1",
                               collection_id="c1", status="completed",
                               status_code=200, is_success=True)
        assert j.is_success is True
        # Fail
        j2 = JobExecutionPublic(job_public_id="j2", run_public_id="r1",
                                collection_id="c1", status="completed",
                                status_code=500, is_success=False)
        assert j2.is_success is False
        # Legacy — null
        j3 = JobExecutionPublic(job_public_id="j3", run_public_id="r1",
                                collection_id="c1", status="completed")
        assert j3.is_success is None

    def test_success_criterion_on_run_public(self):
        from scrapingpros.models import RunPublic, SuccessCriterion
        run = RunPublic(
            run_id="r1", collection_id="c1", status="completed",
            success_criterion=SuccessCriterion(
                version="content_success_v1",
                rules=["status == 'completed'", "200 <= status_code < 300"],
            ),
        )
        assert run.success_criterion is not None
        assert run.success_criterion.version == "content_success_v1"
        assert len(run.success_criterion.rules) == 2

    def test_run_public_without_success_criterion(self):
        # Legacy runs (pre-migration) don't have success_criterion
        from scrapingpros.models import RunPublic
        run = RunPublic(run_id="r1", collection_id="c1", status="completed")
        assert run.success_criterion is None


# ---------------------------------------------------------------------------
# v0.5.0 features
# ---------------------------------------------------------------------------

class TestV050Features:
    """Tests for fields added in v0.5.0.

    Source of truth: ``issues/sdk-0.4.4-notes.md`` §1.1, §1.3, §3.2, §5.2.
    """

    # §1.1 — MethodPOST.content_type
    def test_method_post_content_type_form(self):
        m = MethodPOST(payload={"grant_type": "client_credentials"}, content_type="form")
        data = m.model_dump(exclude_none=True)
        assert data["content_type"] == "form"
        assert data["payload"] == {"grant_type": "client_credentials"}

    def test_method_post_content_type_json(self):
        m = MethodPOST(payload={"k": "v"}, content_type="json")
        assert m.content_type == "json"
        assert m.model_dump(exclude_none=True)["content_type"] == "json"

    def test_method_post_content_type_default_none(self):
        m = MethodPOST(payload={"k": "v"})
        assert m.content_type is None
        # exclude_none should drop it so backend default ("json") applies
        assert "content_type" not in m.model_dump(exclude_none=True)

    def test_method_post_content_type_invalid_raises(self):
        import pytest as _pytest
        from pydantic import ValidationError
        with _pytest.raises(ValidationError):
            MethodPOST(payload={"k": "v"}, content_type="multipart")  # type: ignore[arg-type]

    # §1.3 — JobExecutionPublic +3 fields
    def test_job_execution_client_id(self):
        from scrapingpros.models import JobExecutionPublic
        job = JobExecutionPublic(
            job_public_id="j1", run_public_id="r1", collection_id="c1",
            client_id="client_abc", status="completed",
        )
        assert job.client_id == "client_abc"

    def test_job_execution_validator_version(self):
        from scrapingpros.models import JobExecutionPublic
        job = JobExecutionPublic(
            job_public_id="j1", run_public_id="r1", collection_id="c1",
            status="completed", validator_version="0.1.6",
        )
        assert job.validator_version == "0.1.6"

    def test_job_execution_has_extractable_data_tristate(self):
        from scrapingpros.models import JobExecutionPublic
        # True
        j1 = JobExecutionPublic(job_public_id="j1", run_public_id="r1",
                                collection_id="c1", status="completed",
                                has_extractable_data=True)
        assert j1.has_extractable_data is True
        # False
        j2 = JobExecutionPublic(job_public_id="j2", run_public_id="r1",
                                collection_id="c1", status="completed",
                                has_extractable_data=False)
        assert j2.has_extractable_data is False
        # None (legacy / pre-migration)
        j3 = JobExecutionPublic(job_public_id="j3", run_public_id="r1",
                                collection_id="c1", status="completed")
        assert j3.has_extractable_data is None

    def test_job_execution_v050_fields_legacy_default_none(self):
        from scrapingpros.models import JobExecutionPublic
        job = JobExecutionPublic(job_public_id="j1", run_public_id="r1",
                                 collection_id="c1", status="completed")
        assert job.client_id is None
        assert job.validator_version is None
        assert job.has_extractable_data is None

    # §3.2 — WaitForSelectorAction.state
    def test_wait_for_selector_state_default_none(self):
        from scrapingpros.models import WaitForSelectorAction
        action = WaitForSelectorAction(selector="css:.results", time=5000)
        assert action.state is None
        # exclude_none drops it so server applies its heuristic
        assert "state" not in action.model_dump(exclude_none=True)

    def test_wait_for_selector_state_attached(self):
        from scrapingpros.models import WaitForSelectorAction
        action = WaitForSelectorAction(
            selector="css:script#__NEXT_DATA__", time=8000, state="attached",
        )
        assert action.state == "attached"
        assert action.model_dump(exclude_none=True)["state"] == "attached"

    def test_wait_for_selector_state_invalid_raises(self):
        import pytest as _pytest
        from pydantic import ValidationError
        from scrapingpros.models import WaitForSelectorAction
        with _pytest.raises(ValidationError):
            WaitForSelectorAction(selector="css:.x", time=1000, state="present")  # type: ignore[arg-type]

    # §5.2 — NetworkCaptureConfig.url_pattern
    def test_network_capture_url_pattern(self):
        cfg = NetworkCaptureConfig(
            resource_types=["xhr", "fetch"],
            url_pattern="*identitytoolkit.googleapis.com*",
        )
        assert cfg.url_pattern == "*identitytoolkit.googleapis.com*"
        data = cfg.model_dump(exclude_none=True)
        assert data["url_pattern"] == "*identitytoolkit.googleapis.com*"

    def test_network_capture_url_pattern_default_none(self):
        cfg = NetworkCaptureConfig(resource_types=["xhr"])
        assert cfg.url_pattern is None
        assert "url_pattern" not in cfg.model_dump(exclude_none=True)


# ---------------------------------------------------------------------------
# v0.5.1 — client aliases + batch_scrape convenience
# ---------------------------------------------------------------------------

class TestV051ClientAliases:
    def test_sync_client_is_subclass_of_scrapingpros(self):
        from scrapingpros import SyncClient, ScrapingPros
        # SyncClient is a thin subclass so that instantiating SyncClient
        # does NOT trigger the ScrapingPros DeprecationWarning, while still
        # exposing all the same behaviour.
        assert issubclass(SyncClient, ScrapingPros)
        assert SyncClient is not ScrapingPros

    def test_async_client_is_subclass_of_asyncscrapingpros(self):
        from scrapingpros import AsyncClient, AsyncScrapingPros
        assert issubclass(AsyncClient, AsyncScrapingPros)
        assert AsyncClient is not AsyncScrapingPros

    def test_aliases_in_all(self):
        import scrapingpros
        assert "SyncClient" in scrapingpros.__all__
        assert "AsyncClient" in scrapingpros.__all__

    def test_batch_scrape_method_exists_on_sync_client(self):
        from scrapingpros import SyncClient
        assert hasattr(SyncClient, "batch_scrape")
        assert callable(SyncClient.batch_scrape)

    def test_batch_scrape_method_exists_on_async_client(self):
        from scrapingpros import AsyncClient
        assert hasattr(AsyncClient, "batch_scrape")
        import inspect
        assert inspect.iscoroutinefunction(AsyncClient.batch_scrape)

    def test_run_and_wait_default_timeout_bumped(self):
        # Regression: 300s default was timing out legitimate browser/stealth
        # batches. v0.5.1 bumped to 3600s.
        from scrapingpros import ScrapingPros, AsyncScrapingPros
        import inspect
        for cls in (ScrapingPros, AsyncScrapingPros):
            sig = inspect.signature(cls.run_and_wait)
            assert sig.parameters["timeout"].default == 3600.0, (
                f"{cls.__name__}.run_and_wait timeout should default to 3600s "
                f"(got {sig.parameters['timeout'].default})"
            )

    def test_scrape_many_emits_deprecation_warning(self):
        import warnings
        from scrapingpros import SyncClient
        c = SyncClient("demo_x", base_url="http://localhost:9999")
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            try:
                c.scrape_many(["https://x.com"])
            except Exception:
                pass  # the network call will fail; we only care about the warning
        deprec = [x for x in w if issubclass(x.category, DeprecationWarning)]
        assert any("scrape_many" in str(x.message) for x in deprec), (
            f"scrape_many should emit DeprecationWarning; got {[str(x.message) for x in w]}"
        )

    def test_scrapingpros_emits_deprecation_warning(self):
        import warnings
        from scrapingpros import ScrapingPros
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            ScrapingPros("demo_x")
        deprec = [x for x in w if issubclass(x.category, DeprecationWarning)]
        assert any("ScrapingPros" in str(x.message) for x in deprec), (
            "ScrapingPros() should emit DeprecationWarning recommending SyncClient"
        )

    def test_syncclient_does_not_emit_deprecation_warning(self):
        import warnings
        from scrapingpros import SyncClient
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            SyncClient("demo_x")
        deprec = [x for x in w if issubclass(x.category, DeprecationWarning)
                  and "ScrapingPros" in str(x.message)]
        assert not deprec, "SyncClient should NOT emit the rename warning"

    def test_asyncscrapingpros_emits_deprecation_warning(self):
        import warnings
        from scrapingpros import AsyncScrapingPros
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            AsyncScrapingPros("demo_x")
        deprec = [x for x in w if issubclass(x.category, DeprecationWarning)]
        assert any("AsyncScrapingPros" in str(x.message) for x in deprec)

    def test_asyncclient_does_not_emit_deprecation_warning(self):
        import warnings
        from scrapingpros import AsyncClient
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            AsyncClient("demo_x")
        deprec = [x for x in w if issubclass(x.category, DeprecationWarning)
                  and "AsyncScrapingPros" in str(x.message)]
        assert not deprec, "AsyncClient should NOT emit the rename warning"


# ---------------------------------------------------------------------------
# v0.5.2 — fixes from sdk-concerns.md (Lupa + MLFQ sessions)
# ---------------------------------------------------------------------------

class TestV052Fixes:
    """Concerns sourced from C:/.../SP API/sdk-concerns.md."""

    # #11 — iter_results retries transient 5xx instead of dying.
    def test_is_transient_poll_error_helper(self):
        from scrapingpros.batch import _is_transient_poll_error
        from scrapingpros.exceptions import (
            APIError,
            ConnectionError as SPConnectionError,
            RateLimitError,
        )
        # Transient: connection drops, server 5xx, rate limit.
        assert _is_transient_poll_error(SPConnectionError("boom"))
        assert _is_transient_poll_error(APIError(500, "internal"))
        assert _is_transient_poll_error(APIError(502, "bad gateway"))
        assert _is_transient_poll_error(APIError(503, "unavailable"))
        assert _is_transient_poll_error(APIError(504, "gateway timeout"))
        assert _is_transient_poll_error(RateLimitError(429, "slow down"))
        # Not transient: 4xx semantic, programming bugs.
        assert not _is_transient_poll_error(APIError(404, "not found"))
        assert not _is_transient_poll_error(APIError(401, "unauth"))
        assert not _is_transient_poll_error(APIError(422, "validation"))
        assert not _is_transient_poll_error(ValueError("not even an APIError"))

    # #6 — _normalize_items validates URLs in dict items.
    def test_normalize_items_rejects_dict_with_missing_url(self):
        from scrapingpros.batch import _normalize_items
        with pytest.raises(ValueError, match="index 1.*missing a string"):
            _normalize_items([{"url": "https://ok.com"}, {"custom_id": "x"}])

    def test_normalize_items_rejects_dict_with_empty_url(self):
        from scrapingpros.batch import _normalize_items
        with pytest.raises(ValueError, match="index 0.*empty URL"):
            _normalize_items([{"url": "   "}])

    def test_normalize_items_auto_prepends_https_in_dicts(self):
        from scrapingpros.batch import _normalize_items
        out = _normalize_items([{"url": "example.com", "custom_id": "a"}])
        assert out[0]["url"] == "https://example.com"
        assert out[0]["custom_id"] == "a"

    def test_normalize_items_passes_through_extra_keys(self):
        from scrapingpros.batch import _normalize_items
        out = _normalize_items([{"url": "https://x.com", "browser": True, "weird": 1}])
        assert out[0] == {"url": "https://x.com", "browser": True, "weird": 1}

    # #15 — SubmitTimeout is a TimeoutError subclass.
    def test_submit_timeout_inherits_timeouterror(self):
        from scrapingpros import SubmitTimeout
        from scrapingpros.exceptions import TimeoutError as SPTimeoutError
        assert issubclass(SubmitTimeout, SPTimeoutError)

    # #15 — submit_batch signature has submit_timeout + on_submitted.
    def test_submit_batch_signature_v052(self):
        import inspect
        from scrapingpros import SyncClient, AsyncClient
        for cls in (SyncClient, AsyncClient):
            sig = inspect.signature(cls.submit_batch)
            assert "submit_timeout" in sig.parameters
            assert sig.parameters["submit_timeout"].default == 30.0
            assert "on_submitted" in sig.parameters

    # #1 — get_batch refresh kwarg + Batch.refresh() public method.
    def test_get_batch_refresh_kwarg(self):
        import inspect
        from scrapingpros import SyncClient, AsyncClient
        for cls in (SyncClient, AsyncClient):
            sig = inspect.signature(cls.get_batch)
            assert "refresh" in sig.parameters
            assert sig.parameters["refresh"].default is True

    def test_batch_refresh_method_public(self):
        from scrapingpros import Batch, AsyncBatch
        assert hasattr(Batch, "refresh")
        assert hasattr(AsyncBatch, "refresh")

    # #8 — SyncClient.iter_results / AsyncClient.iter_results shortcuts.
    def test_client_iter_results_shortcut(self):
        from scrapingpros import SyncClient, AsyncClient
        assert hasattr(SyncClient, "iter_results")
        assert hasattr(AsyncClient, "iter_results")

    # #15 — find_recent_batch present.
    def test_find_recent_batch_present(self):
        from scrapingpros import SyncClient, AsyncClient
        assert hasattr(SyncClient, "find_recent_batch")
        assert hasattr(AsyncClient, "find_recent_batch")

    # #7 — submit_batch_lenient present.
    def test_submit_batch_lenient_present(self):
        from scrapingpros import SyncClient
        assert hasattr(SyncClient, "submit_batch_lenient")


# ---------------------------------------------------------------------------
# ScrapeResponse
# ---------------------------------------------------------------------------

class TestScrapeResponse:
    def test_html_response(self):
        resp = ScrapeResponse(html="<h1>Hi</h1>", statusCode=200, message="OK")
        assert resp.html == "<h1>Hi</h1>"
        assert resp.markdown is None

    def test_markdown_response(self):
        resp = ScrapeResponse(markdown="# Hi", statusCode=200, message="OK")
        assert resp.markdown == "# Hi"
        assert resp.html is None

    def test_content_returns_markdown_when_available(self):
        resp = ScrapeResponse(message="OK", markdown="# Hello", html=None)
        assert resp.content == "# Hello"

    def test_content_returns_html_when_no_markdown(self):
        resp = ScrapeResponse(message="OK", html="<h1>Hello</h1>", markdown=None)
        assert resp.content == "<h1>Hello</h1>"

    def test_content_prefers_markdown(self):
        resp = ScrapeResponse(message="OK", html="<h1>Hi</h1>", markdown="# Hi")
        assert resp.content == "# Hi"

    def test_content_returns_none_when_empty(self):
        resp = ScrapeResponse(message="OK")
        assert resp.content is None

    def test_full_response(self):
        resp = ScrapeResponse(
            html="<h1>Hi</h1>",
            statusCode=200,
            message="OK",
            executionTime=1.5,
            extracted_data={"title": "Hi"},
            evaluate_results=["result1"],
            network_requests=[{"url": "https://api.com"}],
            potentiallyBlockedByCaptcha=False,
            timings={"queue_wait_ms": 10},
        )
        assert resp.executionTime == 1.5
        assert resp.potentiallyBlockedByCaptcha is False
        assert resp.timings["queue_wait_ms"] == 10


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

class TestDownloadRequest:
    def test_minimal(self):
        req = DownloadRequest(url="https://example.com/file.pdf")
        assert req.use_proxy is None

    def test_with_proxy(self):
        req = DownloadRequest(url="https://x.com/f.pdf", use_proxy="any")
        assert req.use_proxy == "any"


class TestDownloadResponse:
    def test_basic(self):
        resp = DownloadResponse(
            content="base64data",
            contentType="application/pdf",
            statusCode=200,
            message="OK",
        )
        assert resp.content == "base64data"
        assert resp.contentType == "application/pdf"


# ---------------------------------------------------------------------------
# Collections
# ---------------------------------------------------------------------------

class TestCollectionPublic:
    def test_basic(self):
        col = CollectionPublic(id="abc", name="my-batch")
        assert col.id == "abc"
        assert col.name == "my-batch"


class TestNewCollectionResponse:
    def test_basic(self):
        resp = NewCollectionResponse(id="abc", name="batch", message="Created")
        assert resp.duplicates_skipped == 0

    def test_with_duplicates(self):
        resp = NewCollectionResponse(message="Created", duplicates_skipped=3)
        assert resp.duplicates_skipped == 3


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------

class TestRunPublic:
    def test_defaults(self):
        run = RunPublic(run_id="r1", collection_id="c1")
        assert run.status == "in_progress"
        assert run.total_requests == 0
        assert run.failed_jobs == []

    def test_completed(self):
        run = RunPublic(
            run_id="r1",
            collection_id="c1",
            status="completed",
            total_requests=10,
            success_requests=8,
            failed_requests=2,
            failed_jobs=[
                FailedJobPublic(job_id="j1", url="https://fail.com", status="failed", error="timeout"),
            ],
        )
        assert run.success_requests == 8
        assert len(run.failed_jobs) == 1
        assert run.failed_jobs[0].error == "timeout"


class TestJobExecutionPublic:
    def test_basic(self):
        job = JobExecutionPublic(
            job_public_id="j1",
            run_public_id="r1",
            collection_id="c1",
            status="completed",
            status_code=200,
        )
        assert job.status == "completed"


class TestJobExecutionListPublic:
    def test_empty(self):
        lst = JobExecutionListPublic(items=[])
        assert len(lst.items) == 0


# ---------------------------------------------------------------------------
# Viability
# ---------------------------------------------------------------------------

class TestViabilityTestRequest:
    def test_basic(self):
        req = ViabilityTestRequest(urls=["https://example.com"])
        assert len(req.urls) == 1
        assert req.actions is None

    def test_with_actions(self):
        req = ViabilityTestRequest(
            urls=["https://example.com"],
            actions=[ClickAction(selector="css:button")],
        )
        assert len(req.actions) == 1


class TestUrlViabilityResult:
    def test_basic(self):
        r = UrlViabilityResult(
            url="https://example.com",
            captcha_detected=False,
            captcha_providers=[],
            javascript_detected=True,
            javascript_required=False,
            browser_confidence=0.3,
            content_type="text/html",
            rate_limited=False,
            soft_block=False,
            retry_after=None,
            login_wall=False,
            status_code=200,
            redirect_chain=[],
            protection_signals={},
            api_detected=False,
            api_endpoints=[],
            graphql_detected=False,
            api_auth_required=False,
            cloudflare_level="none",
            can_use_simple_request=True,
            can_use_extract_html=True,
            can_use_browser=True,
            recommended_strategy="simple",
            proxy_recommended=False,
            proxy_type="none",
        )
        assert r.recommended_strategy == "simple"
        assert r.javascript_detected is True


class TestViabilityRunPublic:
    def test_in_progress(self):
        run = ViabilityRunPublic(run_id="v1", status="in_progress", total_urls=3)
        assert run.completed_urls == 0
        assert run.results is None

    def test_completed(self):
        run = ViabilityRunPublic(run_id="v1", status="completed", total_urls=1, results=[])
        assert run.status == "completed"


# ---------------------------------------------------------------------------
# Proxy Endpoint Models
# ---------------------------------------------------------------------------

class TestCountryRequest:
    def test_defaults(self):
        req = CountryRequest(country_code="US")
        assert req.reason == ""

    def test_with_reason(self):
        req = CountryRequest(country_code="BR", reason="Need BR pricing")
        assert req.reason == "Need BR pricing"
