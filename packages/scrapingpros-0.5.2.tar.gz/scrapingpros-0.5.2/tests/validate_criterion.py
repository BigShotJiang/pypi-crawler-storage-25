"""Validate that SDK and server now agree on what counts as success.

Runs a small mixed batch, compares SDK's computed success/fail count
against the server's run stats at the end.
"""

import json
import sys
from pathlib import Path

from scrapingpros import ScrapingPros

TOKEN = "3Fupbo6Qui4bl2w62Cz6"
URLS_FILE = Path("C:/Users/Lucho/Claude Code Projects/SP API Worker Coordinator/urls-export/default.json")


def main():
    urls = json.loads(URLS_FILE.read_text())["urls"]
    # Use a slice — we only need enough to hit the edge cases (a mix of
    # easy+medium+hard so some succeed and some fail).
    sample = urls[:30]
    items = [
        {
            "url": u["url"],
            "custom_id": f'{u["difficulty"]}-{u["domain"]}',
            "browser": True,
        }
        for u in sample
    ]

    client = ScrapingPros(TOKEN)
    batch = client.submit_batch("criterion-check", items)
    print(f"Batch collection={batch.collection_id}")
    print(f"Batch run={batch.run_id}")
    print(f"Submitted: {len(items)}")
    sys.stdout.flush()

    # Drain with no printing — just let progress accumulate
    for _ in batch.iter_results(poll_interval=5.0, timeout=600):
        pass

    # Final run fetch (server-side truth)
    run = client.get_run(batch.collection_id, batch.run_id)
    server_success = run.success_requests or 0
    server_failed = run.failed_requests or 0
    server_timeout = run.timeout_requests or 0
    server_total = server_success + server_failed + server_timeout

    # SDK counts
    sdk_success = batch.success_count
    sdk_failed = batch.failed_count

    print()
    print("=" * 60)
    print("CRITERION COMPARISON")
    print("=" * 60)
    print(f"  Run status:         {run.status}")
    print(f"  Server total_req:   {run.total_requests}")
    print(f"  Server done total:  {server_total}")
    print()
    print(f"                        SDK     Server")
    print(f"  Success            {sdk_success:>5}   {server_success:>5}")
    print(f"  Failed             {sdk_failed:>5}   {server_failed + server_timeout:>5}  (failed+timeout)")
    print()
    if sdk_success == server_success and sdk_failed == (server_failed + server_timeout):
        print("  ✅ Criteria MATCH — SDK and server agree")
    else:
        delta_succ = sdk_success - server_success
        delta_fail = sdk_failed - (server_failed + server_timeout)
        print(f"  ❌ Mismatch: Δsuccess={delta_succ:+d}  Δfailed={delta_fail:+d}")
        print()
        print("  Investigating which jobs disagree...")
        mismatches = []
        for job in client.iter_run_jobs(batch.collection_id, batch.run_id):
            # Server verdict for this job:
            server_ok = job.status == "completed"
            # SDK verdict:
            sdk_ok = (
                job.status == "completed"
                and job.status_code is not None
                and 200 <= job.status_code < 300
                and not job.block_reason
            )
            if server_ok != sdk_ok:
                mismatches.append((job, server_ok, sdk_ok))
        print(f"  Jobs where verdicts disagree: {len(mismatches)}")
        for job, sv, sdk in mismatches[:10]:
            print(f"    {job.custom_id}: server={sv} sdk={sdk}  "
                  f"status={job.status} code={job.status_code} "
                  f"block={job.block_reason!r}")

    client.close()


if __name__ == "__main__":
    main()
